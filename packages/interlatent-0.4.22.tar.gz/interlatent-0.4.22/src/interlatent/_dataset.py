"""Build a LeRobot v3.0 dataset from the SDK's local staging cache.

At ``upload()`` time the SDK opens its transient SQLite staging cache,
walks the per-episode JPEG frames in :class:`MediaBuffer`, and feeds them
through ``lerobot.datasets.lerobot_dataset.LeRobotDataset.create()`` /
``add_frame()`` / ``save_episode()`` / ``finalize()`` to produce a
complete on-disk LeRobot v3.0 dataset ready for upload to the inbox.

The lerobot library handles parquet writing, mp4 encoding (via internal
ffmpeg invocation at ``save_episode`` time), tasks-table maintenance, and
stats computation. We do not re-implement those.

After ``finalize()`` we post-edit ``meta/episodes/.../parquet`` to add
an ``interlatent.episode_uuid`` column so the dashboard can join on the
SDK-generated UUID even though LeRobot's canonical identifier for an
episode is the integer ``episode_index``. We also stamp
``meta/info.json`` with a custom ``interlatent`` block describing the
failure-type mapping, metric names, and source environment / model.
"""
from __future__ import annotations

import json
import logging
import shutil
import sqlite3
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List

_LOG = logging.getLogger(__name__)

# Sentinel layer name written by ``Watcher.tick()``. Mirrors the constant
# in ``_watcher.py`` — kept duplicated here to avoid a tight import cycle.
_CTX_LAYER = "_ctx"


def _flatten_step_rows(rows: list) -> list[dict]:
    """Group SQLite rows by ``(episode_id, step)`` into one record per step.

    Each record is::

        {
            "episode_id": str,
            "step": int,
            "context": dict,         # parsed from the _ctx row's JSON blob
            "activations": dict,     # {layer_name: list[float]}
        }

    Activation rows from real layers carry their tensors; the ``_ctx`` row
    carries the per-step context dict that the watcher built (obs, action,
    reward, done, truncated, metrics, failure_type, ...).
    """
    by_step: dict[tuple[str, int], dict[str, Any]] = {}
    for row in rows:
        ep_id = row["episode_id"]
        step = int(row["step"])
        layer = row["layer"]
        key = (ep_id, step)
        rec = by_step.setdefault(key, {
            "episode_id": ep_id,
            "step": step,
            "context": {},
            "activations": {},
        })
        if layer == _CTX_LAYER:
            try:
                rec["context"] = json.loads(row["context"] or "{}")
            except (json.JSONDecodeError, TypeError):
                rec["context"] = {}
        else:
            try:
                tensor = json.loads(row["tensor"] or "[]")
                rec["activations"][layer] = tensor
            except (json.JSONDecodeError, TypeError):
                pass

    out = list(by_step.values())
    out.sort(key=lambda r: (r["episode_id"], r["step"]))
    return out


def _episode_order(records: list[dict]) -> list[str]:
    """Return episode UUIDs in first-appearance order across the records."""
    seen: list[str] = []
    seen_set: set[str] = set()
    for rec in records:
        eid = rec["episode_id"]
        if eid not in seen_set:
            seen.append(eid)
            seen_set.add(eid)
    return seen


def _discover_features(
    records: list[dict],
    *,
    cameras: list[str | None],
    image_shape: tuple[int, int] | None,
    record_activations: bool,
    has_failure_types: bool,
    metric_names: list[str],
) -> dict:
    """Build the LeRobot ``features`` dict from staged data.

    Sized lazily from the first staged record's observation / action and
    the first staged frame's HxW. Activation widths are taken from the
    first non-empty tensor seen per layer.
    """
    if not records:
        raise ValueError("Cannot discover features from an empty staging cache")

    first = records[0]
    obs = first["context"].get("observation") or []
    action = first["context"].get("action") or []

    features: dict[str, dict] = {
        "observation.state": {
            "dtype": "float32",
            "shape": (max(1, len(obs)),),
            "names": None,
        },
        "action": {
            "dtype": "float32",
            "shape": (max(1, len(action)),),
            "names": None,
        },
        "next.reward": {
            "dtype": "float32",
            "shape": (1,),
            "names": None,
        },
        "next.done": {
            "dtype": "bool",
            "shape": (1,),
            "names": None,
        },
        "annotation.interlatent.truncated": {
            "dtype": "bool",
            "shape": (1,),
            "names": None,
        },
    }

    # Failure type as int64 — info.json carries the {id -> name} mapping.
    if has_failure_types:
        features["annotation.interlatent.failure_type"] = {
            "dtype": "int64",
            "shape": (1,),
            "names": None,
        }

    # Per-metric scalar columns
    for name in metric_names:
        features[f"annotation.interlatent.metrics.{name}"] = {
            "dtype": "float32",
            "shape": (1,),
            "names": None,
        }

    # Camera features (videos encoded by lerobot at save_episode time)
    if cameras and image_shape is not None:
        H, W = image_shape
        for cam in cameras:
            key = f"observation.images.{cam}" if cam else "observation.images.default"
            features[key] = {
                "dtype": "video",
                "shape": (H, W, 3),
                "names": {"height": H, "width": W, "channels": 3},
            }

    # Activation features (one per hooked layer). The annotation.* prefix
    # keeps the dataset interoperable with stock LeRobot consumers.
    if record_activations:
        layer_widths: dict[str, int] = {}
        for rec in records:
            for layer, tensor in rec["activations"].items():
                if layer not in layer_widths and tensor:
                    layer_widths[layer] = len(tensor)
        for layer, width in layer_widths.items():
            features[f"annotation.interlatent.activations.{layer}"] = {
                "dtype": "float32",
                "shape": (width,),
                "names": None,
            }

    return features


class LeRobotRebuilder:
    """Build a LeRobot v3.0 dataset from local staging.

    Construction is cheap — the lerobot library import is deferred to
    :meth:`build_from_staging`. Users do not import this class directly;
    it is invoked by :class:`Interlatent.upload`.
    """

    def __init__(
        self,
        root: Path | str,
        *,
        fps: int,
        task: str,
        env_slug: str,
        model_id: str | None = None,
        repo_id: str | None = None,
    ) -> None:
        # ``root`` must NOT yet exist. ``LeRobotDataset.create()`` calls
        # ``root.mkdir(exist_ok=False)`` internally and will raise
        # FileExistsError otherwise.
        self.root = Path(root)
        self.fps = int(fps)
        self.task = task or env_slug or "rollout"
        self.env_slug = env_slug or "unknown"
        self.model_id = model_id
        # repo_id is required by LeRobotDataset.create even when we never
        # push to the Hub. Synthesize one that is stable per (env, model).
        self.repo_id = repo_id or f"interlatent/{(model_id or env_slug or 'session').strip('/')}"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build_from_staging(
        self,
        *,
        db_path: str,
        media,
        record_activations: bool = True,
    ) -> tuple[Path, list[str]]:
        """Read the staging cache and produce an on-disk LeRobot dataset.

        Returns ``(root, episode_uuids)`` where ``episode_uuids[i]`` is the
        SDK-generated UUID for the LeRobot ``episode_index = i``.

        Raises ``RuntimeError`` if ``lerobot`` or ``Pillow`` are not
        installed (both required at upload time).
        """
        try:
            from lerobot.datasets.lerobot_dataset import LeRobotDataset
        except ImportError as exc:
            raise RuntimeError(
                "lerobot is required at upload time. "
                "Install with: pip install 'interlatent[lerobot]'"
            ) from exc

        try:
            from PIL import Image
        except ImportError as exc:
            raise RuntimeError(
                "Pillow is required at upload time. "
                "Install with: pip install Pillow"
            ) from exc

        import numpy as np

        # 1. Load all rows from the staging SQLite.
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute(
                """
                SELECT episode_id, step, layer, tensor, context
                FROM activations
                ORDER BY episode_id, step, layer
                """
            ).fetchall()
        finally:
            conn.close()

        if not rows:
            return self.root, []

        records = _flatten_step_rows(rows)
        episode_uuids = _episode_order(records)

        # 2. Discover schema. Cameras + image shape come from the media
        #    buffer; activation widths from the first non-empty tensor.
        cameras: list[str | None] = []
        image_shape: tuple[int, int] | None = None
        if media is not None:
            for eid in episode_uuids:
                ep_cams = media.cameras_for_episode(eid)
                if ep_cams:
                    cameras = ep_cams
                    for _step, _cam, frame_path in media.iter_episode_frames(eid):
                        with Image.open(frame_path) as img:
                            arr = np.asarray(img)
                        if arr.ndim == 3 and arr.shape[2] == 3:
                            image_shape = (arr.shape[0], arr.shape[1])
                            break
                        if arr.ndim == 2:
                            image_shape = arr.shape  # type: ignore[assignment]
                            break
                if image_shape is not None:
                    break

        # Failure-type catalog — int64 ids 1..N, with 0 reserved for "no failure".
        failure_types: list[str] = []
        for rec in records:
            ft = rec["context"].get("failure_type")
            if ft and ft not in failure_types:
                failure_types.append(ft)
        failure_type_to_id = {ft: i + 1 for i, ft in enumerate(failure_types)}

        # Metric catalog — preserves first-seen order.
        metric_names: list[str] = []
        for rec in records:
            metrics = rec["context"].get("metrics") or {}
            for name in metrics:
                if name not in metric_names:
                    metric_names.append(name)

        features = _discover_features(
            records,
            cameras=cameras,
            image_shape=image_shape,
            record_activations=record_activations,
            has_failure_types=bool(failure_type_to_id),
            metric_names=metric_names,
        )

        # 3. Create the LeRobot dataset writer. ``LeRobotDataset.create``
        #    materializes meta/info.json and opens the parquet writers.
        dataset = LeRobotDataset.create(
            repo_id=self.repo_id,
            fps=self.fps,
            features=features,
            root=str(self.root),
            robot_type=self.env_slug or "custom",
            use_videos=bool(cameras and image_shape is not None),
        )

        # 4. Build per-episode lookups for the inner loop.
        records_by_episode: dict[str, list[dict]] = defaultdict(list)
        for rec in records:
            records_by_episode[rec["episode_id"]].append(rec)
        for eid in records_by_episode:
            records_by_episode[eid].sort(key=lambda r: r["step"])

        frames_by_episode: dict[str, dict[int, dict[str | None, Path]]] = {}
        if media is not None:
            for eid in episode_uuids:
                ep_frames: dict[int, dict[str | None, Path]] = {}
                for step, cam, path in media.iter_episode_frames(eid):
                    ep_frames.setdefault(step, {})[cam] = path
                frames_by_episode[eid] = ep_frames

        # 5. Stream frames into the dataset. ``finalize()`` MUST run even
        #    on error or the parquet files end up with truncated footers.
        try:
            for eid in episode_uuids:
                ep_records = records_by_episode.get(eid) or []
                if not ep_records:
                    continue
                ep_frames = frames_by_episode.get(eid, {})
                for rec in ep_records:
                    frame = self._build_frame(
                        rec=rec,
                        ep_frames=ep_frames,
                        features=features,
                        cameras=cameras,
                        record_activations=record_activations,
                        failure_type_to_id=failure_type_to_id,
                        metric_names=metric_names,
                        np=np,
                        Image=Image,
                    )
                    # add_frame() expects ``task`` to live inside the frame
                    # dict (it does ``frame.pop("task")`` internally) — it
                    # is not a kwarg.
                    frame["task"] = self.task
                    dataset.add_frame(frame)
                # numpy 2.x compat: lerobot's get_hf_features_from_features
                # maps every shape-(1,) feature to ``datasets.Value`` (scalar),
                # but its own ``validate_frame`` requires ``np.ndarray`` of
                # shape (1,). On numpy 2.x, HF then calls
                # ``float(np.array([0.0]))`` during encode and raises
                # "only 0-dimensional arrays can be converted to Python
                # scalars". Squeeze each shape-(1,) buffer entry to a Python
                # scalar before save_episode so HF gets what it expects.
                self._scalarize_singleton_columns(dataset, features)
                dataset.save_episode()
        finally:
            try:
                dataset.finalize()
            except Exception:
                _LOG.exception("LeRobotDataset.finalize() raised")

        # 6. Post-edit meta/episodes/.../parquet for the UUID column.
        self._inject_episode_uuids(self.root, episode_uuids)

        # 7. Stamp meta/info.json with the custom interlatent block.
        self._stamp_info_json(self.root, failure_type_to_id, metric_names)

        return self.root, episode_uuids

    @staticmethod
    def _scalarize_singleton_columns(dataset, features: dict) -> None:
        """Convert episode-buffer entries for shape-(1,) features from
        ``np.array([x])`` to plain scalars in place.

        See call site for the numpy-2.x rationale.
        """
        buf = getattr(dataset, "episode_buffer", None)
        if not isinstance(buf, dict):
            return
        for key, ft in features.items():
            if ft.get("shape") != (1,):
                continue
            col = buf.get(key)
            if not isinstance(col, list):
                continue
            for i, v in enumerate(col):
                if hasattr(v, "item") and hasattr(v, "shape") and v.shape == (1,):
                    try:
                        col[i] = v.item()
                    except Exception:
                        pass

    def cleanup(self) -> None:
        """Remove the on-disk dataset directory."""
        if self.root.exists():
            shutil.rmtree(self.root, ignore_errors=True)
        # If the caller nested us inside a fresh tempdir parent, reap that
        # parent too once it's empty — keeps /tmp tidy across many sessions.
        parent = self.root.parent
        try:
            if parent.exists() and not any(parent.iterdir()):
                parent.rmdir()
        except OSError:
            pass

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _build_frame(
        self,
        *,
        rec: dict,
        ep_frames: dict[int, dict[str | None, Path]],
        features: dict,
        cameras: list[str | None],
        record_activations: bool,
        failure_type_to_id: dict[str, int],
        metric_names: list[str],
        np,
        Image,
    ) -> dict[str, Any]:
        ctx = rec["context"]
        activations = rec["activations"]

        obs_dim = features["observation.state"]["shape"][0]
        action_dim = features["action"]["shape"][0]

        obs_vec = np.asarray(ctx.get("observation") or [], dtype=np.float32)
        if obs_vec.shape[0] != obs_dim:
            buf = np.zeros(obs_dim, dtype=np.float32)
            buf[: min(obs_vec.shape[0], obs_dim)] = obs_vec[:obs_dim]
            obs_vec = buf

        action_vec = np.asarray(ctx.get("action") or [], dtype=np.float32)
        if action_vec.shape[0] != action_dim:
            buf = np.zeros(action_dim, dtype=np.float32)
            buf[: min(action_vec.shape[0], action_dim)] = action_vec[:action_dim]
            action_vec = buf

        frame: dict[str, Any] = {
            "observation.state": obs_vec,
            "action": action_vec,
            "next.reward": np.array([float(ctx.get("reward", 0.0))], dtype=np.float32),
            "next.done": np.array([bool(ctx.get("done", False))], dtype=bool),
            "annotation.interlatent.truncated": np.array(
                [bool(ctx.get("truncated", False))], dtype=bool,
            ),
        }

        if "annotation.interlatent.failure_type" in features:
            ft = ctx.get("failure_type")
            ft_id = failure_type_to_id.get(ft, 0) if ft else 0
            frame["annotation.interlatent.failure_type"] = np.array([ft_id], dtype=np.int64)

        metrics = ctx.get("metrics") or {}
        for name in metric_names:
            val = metrics.get(name)
            try:
                v = 0.0 if val is None else float(val)
            except (TypeError, ValueError):
                v = 0.0
            frame[f"annotation.interlatent.metrics.{name}"] = np.array([v], dtype=np.float32)

        if record_activations:
            for key, spec in features.items():
                if not key.startswith("annotation.interlatent.activations."):
                    continue
                layer = key[len("annotation.interlatent.activations."):]
                width = spec["shape"][0]
                tensor = activations.get(layer)
                if tensor:
                    arr = np.asarray(tensor, dtype=np.float32)
                    if arr.shape != (width,):
                        buf = np.zeros(width, dtype=np.float32)
                        buf[: min(arr.shape[0], width)] = arr[:width]
                        arr = buf
                else:
                    arr = np.zeros(width, dtype=np.float32)
                frame[key] = arr

        if cameras:
            step_frames = ep_frames.get(rec["step"], {})
            for cam in cameras:
                feat_key = f"observation.images.{cam}" if cam else "observation.images.default"
                if feat_key not in features:
                    continue
                spec = features[feat_key]
                H, W = spec["shape"][:2]
                if cam in step_frames:
                    with Image.open(step_frames[cam]) as img:
                        if img.mode != "RGB":
                            img = img.convert("RGB")
                        img_arr = np.asarray(img, dtype=np.uint8)
                    if img_arr.ndim == 2:
                        img_arr = np.stack([img_arr] * 3, axis=-1).astype(np.uint8)
                    if img_arr.shape[:2] != (H, W):
                        # Resize would be ideal but introduces a Pillow
                        # dep on a specific filter; for now zero-pad.
                        buf = np.zeros((H, W, 3), dtype=np.uint8)
                        h2 = min(H, img_arr.shape[0])
                        w2 = min(W, img_arr.shape[1])
                        buf[:h2, :w2] = img_arr[:h2, :w2, :3]
                        img_arr = buf
                    frame[feat_key] = img_arr
                else:
                    frame[feat_key] = np.zeros((H, W, 3), dtype=np.uint8)

        return frame

    def _inject_episode_uuids(self, root: Path, episode_uuids: list[str]) -> None:
        """Append an ``interlatent.episode_uuid`` column to meta/episodes/...

        LeRobot keys episodes by integer ``episode_index``; the dashboard
        keys by SDK UUID. Carrying both lets the merge worker (and Modal)
        keep the join.
        """
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq
        except ImportError:
            _LOG.warning("pyarrow not installed; skipping episode-uuid post-edit")
            return

        episodes_dir = root / "meta" / "episodes"
        if not episodes_dir.exists():
            _LOG.warning(
                "meta/episodes/ not found in dataset at %s — skipping uuid post-edit",
                root,
            )
            return

        for parquet_path in sorted(episodes_dir.rglob("*.parquet")):
            table = pq.read_table(parquet_path)
            if "episode_index" not in table.column_names:
                continue
            ep_idx = table.column("episode_index").to_pylist()
            uuids = [
                episode_uuids[i] if 0 <= i < len(episode_uuids) else ""
                for i in ep_idx
            ]
            uuid_col = pa.array(uuids, type=pa.string())
            new_table = table.append_column("interlatent.episode_uuid", uuid_col)
            pq.write_table(new_table, parquet_path)

    def _stamp_info_json(
        self,
        root: Path,
        failure_type_to_id: dict[str, int],
        metric_names: list[str],
    ) -> None:
        info_path = root / "meta" / "info.json"
        if not info_path.exists():
            return
        with open(info_path, "r") as fh:
            info = json.load(fh)

        info["interlatent"] = {
            "environment_slug": self.env_slug,
            "model_id": self.model_id,
            "task": self.task,
            "failure_types": {
                str(idx): name for name, idx in failure_type_to_id.items()
            },
            "metric_names": list(metric_names),
        }

        with open(info_path, "w") as fh:
            json.dump(info, fh, indent=2)
