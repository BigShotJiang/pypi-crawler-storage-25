from setuptools import setup, find_packages
import os
import shutil
import subprocess
import sys


setup(
    name="stock_sdk",
    version="0.2.5",
    author="hamuna",
    packages=find_packages(include=['stock_sdk', 'stock_sdk.*']),
    package_dir={'stock_sdk': 'stock_sdk'},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    description="Hamuna Stock SDK - A股行情数据SDK",
    long_description_content_type="text/markdown",
    url="https://github.com/your-repo/stock_sdk",
    python_requires=">=3.12",
    install_requires=[
        "eltdx",
        "pandas",
        "httpx",
        "tqdm",
        "fake-useragent",
        "diskcache",
        "aiodecorators"
    ]
)

