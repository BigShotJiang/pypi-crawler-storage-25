import sys
import os
import traceback
import json
from . import log
from .flow_service import FlowSentinel
from .flow_engine import _safe_serialize

class SpineLink(FlowSentinel):
    """
    Direct-to-Log Bridge. No JSON side-cars.
    """
    def __init__(self):
        super().__init__()
        log.info("🧠 SPINE-LINK: Neural Bridge Active (Log-Only Mode).")

    def get_llm_payload(self, exc_type, exc_value, frame):
        """
        Gathers context from the live frame for the LLM.
        """
        # This captures data purely in memory to send to your LLM script
        return {
            "error_type": str(exc_type),
            "error_message": str(exc_value),
            "local_shapes": {k: _safe_serialize(v) for k, v in frame.f_locals.items()},
            "file": frame.f_code.co_filename,
            "line": frame.f_lineno
        }

    def harvest_last_failure_from_logs(self):
        """
        Parses debugflow.log instead of a JSON file.
        """
        log_path = os.path.join(os.getcwd(), "logs", "debugflow.log")
        if not os.path.exists(log_path):
            return "No logs found."

        with open(log_path, "r") as f:
            lines = f.readlines()
            # Grab the last 20 lines to find the [ERROR] block
            recent_logs = "".join(lines[-20:])
            return recent_logs

    def apply_patch(self, target_file, code_block):
        """Writes the LLM's fix and refreshes the Ghost map."""
        log.warning(f"🛠️  SPINE-LINK: Patching {os.path.basename(target_file)}")
        try:
            with open(target_file, "w") as f:
                f.write(code_block)
            self.ignite_ghost_pipeline()
            log.info("✅ Patch applied. HUD should refresh automatically.")
        except Exception as e:
            log.error(f"❌ Patch failed: {e}")

            
# --- Test Guard ---
if __name__ == "__main__":
    # This allows you to verify SpineLink standalone
    linker = SpineLink()
    print("SpineLink Module Ready for LLM integration.")