"""Tests for shared file collection."""

from pathlib import Path

from wyolet.symbol.shared.files import collect_py_files
from wyolet.symbol.shared.spec import load_spec

SPEC = load_spec()


def _make_files(tmp_path: Path, paths: list[str]) -> None:
    for p in paths:
        f = tmp_path / p
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text("# placeholder")


def _collect(tmp_path: Path, exclude: list[str] | None = None, **kwargs):
    combined_exclude = list(SPEC.checker.exclude) + (exclude or [])
    return collect_py_files(tmp_path, exclude=combined_exclude, **kwargs)


def test_collects_py_files(tmp_path: Path):
    _make_files(tmp_path, ["a.py", "b.py", "c.txt"])
    files = _collect(tmp_path)
    names = [f.name for f in files]
    assert "a.py" in names
    assert "b.py" in names
    assert "c.txt" not in names


def test_skips_hidden_dirs(tmp_path: Path):
    _make_files(tmp_path, [".hidden/mod.py", "visible.py"])
    files = _collect(tmp_path)
    names = [f.name for f in files]
    assert "visible.py" in names
    assert "mod.py" not in names


def test_skips_venv(tmp_path: Path):
    _make_files(tmp_path, ["venv/lib/pkg.py", ".venv/lib/pkg.py", "app.py"])
    files = _collect(tmp_path)
    assert len(files) == 1
    assert files[0].name == "app.py"


def test_skips_pycache(tmp_path: Path):
    _make_files(tmp_path, ["__pycache__/mod.cpython-313.py", "app.py"])
    files = _collect(tmp_path)
    assert len(files) == 1


def test_include_filter(tmp_path: Path):
    _make_files(tmp_path, ["src/app.py", "tests/test_app.py", "scripts/run.py"])
    files = _collect(tmp_path, include=["src/*"])
    names = [f.name for f in files]
    assert "app.py" in names
    assert "test_app.py" not in names
    assert "run.py" not in names


def test_exclude_filter(tmp_path: Path):
    _make_files(tmp_path, ["src/app.py", "tests/test_app.py", "scripts/run.py"])
    files = _collect(tmp_path, exclude=["tests/*", "scripts/*"])
    names = [f.name for f in files]
    assert "app.py" in names
    assert "test_app.py" not in names
    assert "run.py" not in names


def test_include_and_exclude(tmp_path: Path):
    _make_files(tmp_path, ["src/app.py", "src/vendor/lib.py", "tests/test_app.py"])
    files = _collect(tmp_path, include=["src/*.py", "src/**/*.py"], exclude=["src/vendor/*"])
    names = [f.name for f in files]
    assert "app.py" in names
    assert "lib.py" not in names
    assert "test_app.py" not in names
