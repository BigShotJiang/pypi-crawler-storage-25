# Tasks: feishu-bridge-bg-tasks

## 1. 数据层与 schema

- [x] 1.1 新建 `feishu_bridge/bg_tasks_db.py` —— SQLite schema + WAL 初始化 + `PRAGMA integrity_check` 包装 + migration helper
    - Validate: 从空库启动能创建 `bg_tasks` + `bg_runs`；重启幂等；`PRAGMA journal_mode=WAL`、`busy_timeout=5000`、`synchronous=NORMAL`、`foreign_keys=ON` 全部生效（查询验证）；CHECK constraint 拒绝 `kind != 'adhoc'`（本变更限制）
    - R3 schema：`bg_runs` 含 `wrapper_pid NOT NULL`、`wrapper_start_time_us NOT NULL`、`process_start_time_us`（μs 精度）、`session_resume_status`、`delivery_state CHECK IN ('not_ready','pending','enqueued','sent','delivery_failed')`、`enqueued_at`、`sent_at`（替代原 `delivered_at`）、`completion_detected_at`
- [x] 1.2 定义 `TaskState` enum + 合法状态转换表（含 `launching` 瞬态）
    - Validate: `TaskState.validate_transition(old, new)` 拒绝所有非法跳转（completed→running、orphan→running 等）；合法转换集：queued→{launching, cancelled}；launching→{running, failed}；running→{completed, failed, cancelled, timeout, orphan}
- [x] 1.3 实现 `BgTaskRepo` DAO：`insert_task / claim_queued_cas / set_state_guarded / get / list / set_cancel_requested / start_run / finish_run / mark_delivery_state / list_pending_deliveries`
    - Validate: 所有写操作透过 repo 方法；外部模块不直接写 SQL；`claim_queued_cas` 在并发 100 个 worker 同时认领 1 个 queued row 时只有一人返回 True；100 并发 `insert_task` ≤ 2s
- [x] 1.4 DB 损坏恢复模块：`integrity_check_and_maybe_quarantine()` + `rebuild_from_manifests(tasks_dir)`
    - Validate: 伪造损坏 DB（truncate 前 N 字节）启动 → 自动 quarantine → 从磁盘 `task.json.done` replay 回 DB；没有 manifest 的 `active/` 目录 → `state='orphan'`；`queued` pre-launch 任务丢失，日志明示

## 2. task-runner wrapper（新增二进制）

- [x] 2.1 新建 `feishu_bridge/task_runner.py` —— console_script entry point `task-runner`
    - Validate: `pip install -e .` 后 `which task-runner` 能定位；`task-runner --help` 列出所有必需参数（`--task-id`, `--db-path`, `--tasks-dir`, `--runner-token`）
- [x] 2.2 wrapper 生命周期 4 阶段（P→S→W→C）
    - **Phase P（pre-register）**：`setsid/setpgid` → 用 `libproc.proc_pidinfo(wrapper_self_pid)` 取自身 `wrapper_start_time_us` → INSERT `bg_runs`（仅 task_id/runner_token/wrapper_pid/wrapper_start_time_us/started_at，pid 字段暂 NULL，delivery_state='not_ready'）
    - **Phase S（spawn + link）**：`Popen(argv, shell=False, start_new_session=True)` → 立即 `libproc.proc_pidinfo(child_pid)` 取 `process_start_time_us` → **单事务** UPDATE `bg_runs SET pid=?, pgid=?, process_start_time_us=?` 并 `UPDATE bg_tasks SET state='running' WHERE state='launching' AND id=?`
    - **Phase W（wait + stream）**：`Popen.wait(timeout=0.5)` loop 同时覆盖子退出检测 + 500ms poll `bg_tasks.cancel_requested_at`；两个后台线程 (`_StreamCollector`) 流式写 `stdout.log/stderr.log` 并保留 4KB RAM tail window；`time.monotonic()` deadline 判 timeout；cancel 或 timeout → SIGTERM pgid → 5s grace → SIGKILL
    - **Phase C（commit + deliver）**：UTF-8 safe tail 4096B → 写 `task.json.tmp` + fsync + `os.rename` → `task.json.done` → rename active→completed 目录 → **单事务** UPDATE `bg_runs (finished_at, exit_code, signal, stdout_tail, stderr_tail, manifest_path, delivery_state='pending')` 和 `UPDATE bg_tasks.state=<terminal>` → UDS nudge `b'\x03' + uuid.bytes`
    - Validate: wrapper 进程组独立于 bridge（`ps -o pgid=` 不同）；每阶段边界 fault inject 后 reconciler 行为正确（详见 §7.5）；`runner_token` 与环境 `BG_TASK_TOKEN` 一致；μs 精度 start_time 区分快速重启 pid
- [x] 2.3 wrapper cancel/timeout 处理（Phase W 子任务）：500ms poll `cancel_requested_at` + monotonic deadline；两路径共用 `terminate_child_pgid(grace=5s)` helper
    - Validate: cancel 从 CLI 发出 → wrapper ≤ 500ms 检测 → SIGTERM 到 child pgid；子不响应 → 5s 后 SIGKILL；timeout 路径同样行为；finished_at 记录 monotonic+epoch 双时钟
- [x] 2.4 Phase C 单事务原子性（独立 task 以强调）：bg_runs 终态写入与 bg_tasks.state 同一事务；任一失败整体 rollback；事务外做 UDS nudge（nudge 失败不影响 DB 已 committed 状态）
    - Validate: 模拟 bg_tasks UPDATE 失败（例如 WHERE state 不匹配）→ bg_runs 不被 commit；重启 reconciler 看到仍是 running，从 manifest 重放

## 3. CLI 子命令

- [x] 3.1 扩展 `feishu_bridge/cli.py` 增加 `bg` 子命令组（enqueue / status / list / cancel）
    - Validate: `feishu-bridge-cli bg --help` 输出完整；每个子命令都有 `--help`
    - Evidence: argparse subparser group `bg` with four children (enqueue/status/list/cancel), dispatched via `_run_bg_command` in `feishu_bridge/cli.py`
- [x] 3.2 `bg enqueue` 实现：参数解析（argv 必须通过 `--` 分隔或 `--cmd-json`）→ JSON 序列化 `command_argv` → INSERT（状态 `queued`）→ UDS nudge → JSON stdout
    - Validate: bridge 不运行时仍能 enqueue 成功返回 task_id；DB 锁定 → 非零退出 + 明确错误；bare string 传入（未通过 `--` / `--cmd-json`）→ 非零退出拒绝；`--timeout-seconds` 省略时默认 1800；`--on-done-prompt` 缺失时非零退出
    - Evidence: 9 enqueue tests in `tests/unit/test_cli_bg.py` (positional argv, --cmd-json, reject bare, reject both-forms, missing --on-done-prompt rc=2, default timeout 1800, env overlay with `=` in value, env KEY without `=` rejected, enqueue-without-bridge-listening fail-open)
- [x] 3.3 `bg status / list / cancel` 实现
    - Validate: status 对不存在 task_id 退出码 1；list 按 `updated_at DESC` 限 `--limit`（默认 20）；cancel 已进入终态的 task 报错不改状态；cancel 仅设 `cancel_requested_at` + UDS nudge（从不直接改 state）
    - Evidence: 7 status/list/cancel tests (queued row report, unknown rc=1, list ordering DESC, list chat+state filter, cancel sets flag preserves state, cancel terminal refuses rc=1, cancel unknown rc=1)
- [x] 3.4 UDS wake client helper（CLI 侧）
    - Validate: wake.sock 不存在 / bridge 不在 → CLI 静默跳过 nudge（不影响 enqueue 成功）；存在时发送 payload 后立即 close，不等响应
    - Evidence: `_bg_nudge()` fail-open (FileNotFoundError / ConnectionRefusedError / OSError / timeout), 200ms settimeout, `test_nudge_delivered_to_listening_socket` verifies \\x01 delivery to bound AF_UNIX listener (17/17 tests pass in 1.96s)

## 4. Bridge 侧 supervisor + delivery watcher + wake 监听

- [x] 4.1 `feishu_bridge/bg_supervisor.py` —— `BgSupervisor` 单例（随 bridge 主进程 boot）
    - Validate: start/stop 幂等；stop 不 kill wrapper（wrapper 负责自己生命周期）；bridge SIGKILL 后现有 wrapper 仍跑完并写 manifest
- [x] 4.2 UDS listener 线程（parent dir 0700, socket 0600；`EADDRINUSE` 探测 + unlink 重建；bind 仍失败 WARN 不退出）
    - Validate: 伪造前次崩溃残留 wake.sock → 新 bridge 启动探测无 listener → unlink + rebind 成功；nudge 后 ≤100ms 触发扫描
- [x] 4.3 Poller 线程（1s fallback）扫描 `state='queued'` + `delivery_state IN ('pending','delivery_failed')`
    - Validate: UDS listener 完全禁用 → queued 任务 ≤1s 被 launch；pending delivery ≤1s 被补投
- [x] 4.4 Supervisor launch 路径：CAS claim `queued→launching` → 成功则 spawn `task-runner` wrapper（传 `--task-id`, `--db-path`, `--tasks-dir`, `--runner-token=<uuid4>` 并注入 env `BG_TASK_TOKEN`）→ 立即返回
    - Validate: 两个 supervisor 并发尝试同一 queued 行，只有一个 spawn wrapper；CAS 失败的一侧跳过不报错
- [x] 4.5 Delivery watcher 线程 —— 4 状态 outbox（`pending → enqueued → sent`，失败路径 `delivery_failed`）
    - 扫 `bg_runs.delivery_state='pending'` → 读 manifest → 构造合成 turn → `enqueue_turn(..., kind='bg_task_completion')` 成功 → UPDATE `delivery_state='enqueued', enqueued_at=now`
    - ChatTaskQueue 处理到该合成 turn 并投递飞书 API 成功 → UPDATE `delivery_state='sent', sent_at=now`
    - enqueue_turn 失败 / 飞书 API 失败 → UPDATE `delivery_state='delivery_failed', delivery_attempt_count += 1, delivery_error=<msg>`
    - **Stuck `enqueued` 扫描**：每次 poller tick 扫 `delivery_state='enqueued' AND enqueued_at < now - 5*60*1000` → 回滚 `pending` 重试（ChatTaskQueue consumer 可能因 bridge crash 未调 ack）
    - Validate: mock `lark_client.send` 失败 → `delivery_failed`，1s 后 poller 再试；attempt_count 达到 10 后停止重试并日志 ERROR；session 不可 resume → fallback 新 session + `session_resume_status='fresh_fallback'`；人工停 ChatTaskQueue consumer 模拟 stuck_enqueued → 5min 后自动 rollback pending

## 5. Completion 链路与 `_on_message` 重构

- [x] 5.1 重构 `feishu_bridge/main.py::_on_message` —— 抽取 enqueue 逻辑为 `enqueue_turn(chat_id, session_id, prompt, kind)`
    - Validate: 现有 `tests/test_*.py` 全部通过；`enqueue_turn` 对 `kind='human'` 行为与重构前 bit-identical（用 golden test 录入队快照）
    - Implementation (Option C — narrow core + extras): `FeishuBot.enqueue_turn(*, chat_id, session_key, prompt, kind, extras=None) -> (status, item)`。base item 内置 18 个字段默认值，`extras` 按 kind 合并。`_on_message` 人类分支改为 `self.enqueue_turn(kind='human', extras={thread_id, parent_id, message_id, sender_id, image_key, file_key, file_name, _todo_task_id, _card_message_id, _merge_forward_message_id, _feishu_urls})`。
    - Golden test `test_enqueue_turn_human_bit_identical_golden` in test_bridge.py — 冻结 19-field item dict，refactor 前后均通过。
    - 全回归：186 test_bridge.py + 33 test_task_runner.py + 22 test_bg_supervisor.py = 241 passed。
    - Code Review (Claude code-reviewer): APPROVE with warnings. MEDIUM #1 (extras 可覆盖 infra keys) 已应用 `_PROTECTED={bot_id, _cost_store, _quota_poller, _ledger, _queue_key}` guard + 回归测试。MEDIUM #2 (5.3 bypass 需 queue 层 API 改动) 已 forward-note 到 5.3 checkbox。Codex 跨模型评审本轮跳过（refactor bit-identical, golden 已兜底，risk 面小于 Section 4）。
- [x] 5.2 合成 turn 构造器：按 design.md §Synthetic Turn Format 拼 prompt；16KB 硬上限；**确定性 4 步截断顺序**
    - 步骤 1：stdout_tail / stderr_tail 各截到 1024B（UTF-8 boundary-safe）
    - 步骤 2：output_paths 保留 top 5（按字典序）
    - 步骤 3：on_done_prompt 截到剩余预算
    - 步骤 4：始终保留 `[bg-task:{id}]` 前缀 + manifest path line + state/reason/signal/duration/exit_code；这些不可被截
    - Validate: 构造各字段均超长的 fixture，断言截断顺序与最终大小 ≤16KB；`[bg-task:id]` 和 manifest path 在任何输入下均存在；多字节字符跨边界不破坏
    - 实装：新增 `feishu_bridge/bg_synthetic_turn.py`（纯函数 `build_synthetic_turn(...)`）+ 23 个 fixture-driven tests。
    - Code Review (Claude code-reviewer): 发现 MAJOR — `remaining<=0` fallback 分支用 raw byte slice 同时破坏 UTF-8 safety 与 step-4 preservation（长 `reason` → prelude 被从尾部切掉 State/Reason/Signal/Duration/Exit_code 行，并可能产生 mojibake）。已应用修复：对 `reason` (2048B)、`manifest_path` (1024B)、`signal` (64B) 在进入 prelude 前做 UTF-8 safe per-field cap；`remaining<=0` 分支转为 `assert`（step-4 pre-pass 已使其结构上不可达）。新增 4 个 M1 回归测试：长 reason 保 step-4 字段、多字节 reason 不破坏、短 reason 原样、超长 signal 被截断。tail boundary 测试 parametrize 至 5 个 offset 覆盖 emoji 所有切位。
    - 回归：全量 186 + 33 + 22 + 23 = 264 passed。Codex 跨模型评审本轮跳过（sandbox 阻塞了 codex exec 的所有 stdout 重定向路径；M1 已通过 Claude review 发现并修复 + 回归测试补全）。
- [x] 5.3 `enqueue_turn` 对 `kind='bg_task_completion'` 绕过 `MAX_PENDING_PER_SESSION=10`；人类消息仍受限
    - Validate: 同 session 预置 10 pending 人类消息 → 新的 bg completion 仍能入队；反之预置 1 bg completion + 10 人类 → 下一条人类消息被 backpressure
    - **Prerequisite (from 5.1 review)**: `ChatTaskQueue.enqueue` 目前无条件执行 `MAX_PENDING_PER_SESSION` 检查并抛 `SessionQueueFull`。bypass 需在 queue 层加参数（如 `bypass_backpressure: bool = False`）或新增 `enqueue_bypass()` 方法；`enqueue_turn` 里单独判断 kind 无法绕过。
    - 实装：`ChatTaskQueue.enqueue()` 新增 keyword-only `bypass_backpressure: bool = False`。cap 检查改为 `if not bypass_backpressure and pending and len(pending) >= MAX_PENDING_PER_SESSION`。`enqueue_turn` 传 `bypass_backpressure=(kind == "bg_task_completion")`，严格字符串匹配（'bg-task-completion' 这类拼写不绕过）。
    - 新增 7 个 tests：3 个 enqueue_turn kind→bypass 映射（human=False / bg_task_completion=True / 未知 kind=False 防拼写）+ 4 个真 ChatTaskQueue 行为（默认 cap 强制 / bypass 跳过 cap / bypass 不泄漏到后续 human / 空 session bypass 仍走 immediate）。
    - 回归：193 bridge + 33 task_runner + 22 bg_supervisor + 23 bg_synthetic_turn = 271 passed。
    - Codex 跨模型评审本轮跳过（change 面小、有 4 个真-queue 行为测试兜底、API shape 与 5.1 review 的建议一致）。
- [x] 5.4 Session resume fallback —— probe 契约
    - `sessions_index`（in-memory dict + `~/.feishu-bridge/sessions.json` 持久化）记录 `{session_id: {last_active_at, chat_id}}`；bridge 每次处理 human turn 更新 last_active_at
    - enqueue_turn 发现 `now - last_active_at > 24h` → 启动 sentinel probe：`claude -p --resume <session_id> -p ":probe:"` 5s timeout；成功 → 正常 resume；失败（timeout/session not found） → fork 新 session + prepend `[NOTE: original session no longer resumable at <timestamp>, resuming in fresh context]` 到 prompt
    - 记录 `bg_runs.session_resume_status ∈ {'resumed', 'fresh_fallback', 'resume_failed'}`
    - Validate: 模拟 session compact / `/new` / 15min 过期 → probe 失败 → `fresh_fallback` 生效且用户仍看到结果；session 存活 → `resumed`；probe 超时 → `resume_failed` 并 fallback
    - [x] 5.4a 基础模块 + 脚手架（本次 commit，不改 worker/watcher）
        - 实装：`feishu_bridge/session_resume.py` — `SessionsIndex`（threading.Lock + atomic tempfile+os.replace JSON 持久化）、`sentinel_probe(session_id, *, timeout_sec)` 按 design.md §Session Resume Fallback 的 5 种 outcome 分类（probe_ok / probe_timeout / session_not_found / probe_error / claude_not_found）、`resolve_resume_status(session_id, index, now_ms, probe_fn)` 纯策略、`build_fresh_fallback_prefix(reason)` 用 design.md line 419 的 verbatim NOTE 模板。Claude UUID 作为 key（`--resume` 消费对象），不用 bridge 的 session_key（bot:chat:thread）。
        - Scaffolding：`enqueue_turn(..., session_id=None)` 可选 keyword 参数，item dict 新增 `_bg_session_id`；human path 默认 None，5.4b delivery watcher 会填 Claude UUID。`_bg_session_id` 加入 extras protected keys 防止未来调用方静默覆盖。
        - 新增 26 个 tests：24 个 session_resume（SessionsIndex 持久化+并发 10 线程×20 sessions+损坏 JSON 恢复、4 种 probe 分类、resolve 6 种策略分支含 clock-rollback 未来时间戳兜底、probe 抛异常兜底为 resume_failed）+ 2 个 bridge（`_bg_session_id` 正向 round-trip + None 默认）。
        - 修复 code-reviewer 3 个 MAJOR：M1 `resolve_resume_status` 包 try/except 兜底 probe_fn 异常；M2 recency 检查要求 `0 <= age < threshold`（clock rollback 时 fail-closed 走 probe）；M3 补 `_bg_session_id` 到 protected keys 测试 + 新增 round-trip 测试。
        - 回归：558 unit passed（24 session_resume + 197 bridge + 其余）。1 pre-existing failure（`test_footer_no_model_no_workspace`）与本次无关。
    - [x] 5.4b 集成进 worker + delivery watcher（拆两段 commit）
        - [x] 5.4b-worker：worker post-turn `touch()` 接入（本次 commit）
            - `FeishuBot.__init__` 实例化 `SessionsIndex(~/.feishu-bridge/sessions.json)` 赋 `self._sessions_index`；ctor 失败降级 None 不阻塞启动
            - `enqueue_turn` item dict 加 `_sessions_index`（和 `_cost_store` / `_ledger` 同模式）；加入 extras protected keys
            - `worker.py:884` `session_map.put()` 之后立即调 `sessions_index.touch(session_id=effective_sid, chat_id=chat_id, now_ms=int(time.time()*1000))`；gated `not result.get("is_error")` 防止失败 turn 污染索引；外层 try/except 吞 touch 异常（disk full / JSON 竞争写不阻塞用户回复）
            - 新增 4 个 worker 测试：成功 turn 触发 touch（UUID+chat+epoch）/ 失败 turn 跳过 touch / 缺失 `_sessions_index` 不崩 / touch 抛异常不阻塞 cost_store 写入
            - 更新 HUMAN_TURN_GOLDEN + protected keys 测试增补 `_sessions_index`
            - 回归：562 unit passed（+4 vs 5.4a），golden snapshot 过
            - 修复 Codex cross-review MAJOR：`_on_card_action` 原本 hand-build item dict 绕过 `enqueue_turn` choke point，所有新增 infra 字段（`_sessions_index` / `_bg_session_id` / …）静默丢失。重构为调用 `self.enqueue_turn(chat_id=chat_id, session_key=msg_key, prompt=label, kind="human", extras={"sender_id": sender_id})`，消除根因而非点修补。新增 `test_on_card_action_threads_sessions_index_via_enqueue_turn` 回归测试。
            - 最终回归：563 unit passed（+5 vs 5.4a）
        - [x] 5.4b-watcher：delivery watcher 集成（和 §4.5 合并 commit）
            - watcher 扫 `bg_runs.delivery_state='pending'` 时调 `resolve_resume_status()`
            - `session_id` 经 `enqueue_turn(..., session_id=...)` 传到 item
            - fresh_fallback 时 prepend NOTE 到 prompt 首行
            - status/reason 写入 `bg_runs.session_resume_status`

## 6. Startup reconciler

- [x] 6.1 `BgSupervisor.reconcile()` —— bridge 启动时执行（`main.py` 主循环 before `ws_client.start()`）；顺序 6 步（integrity → stale launching → running 判活 → queued 续推 → delivery outbox → manifest-only 补写）
    - Validate: 启动日志含 `reconcile: {queued_relaunch, launching_reaped, running_attached, running_reaped, running_pending_reap, running_orphaned, running_manifest_applied, delivery_replayed, manifest_recovered}`
    - **Commit A 已实现**：skeleton + steps 1/2/4/5/6 + `_reset_stranded_enqueued` + `_log_retry_budget_exhausted`；main.py 接入 `reconcile()` 在 `start()` 之前同步执行
    - **Commit B 已实现**：step 3 running 活性三元组判定 + triage dispatcher（见 §6.3）
- [x] 6.2 Stale launching 回收：`UPDATE state='failed', reason='launch_interrupted' WHERE state='launching' AND claimed_at < now - 30_000`
    - Validate: 预置一个 `claimed_at=now-60s` 的 launching 行 → 启动后 state='failed'
- [x] 6.3 Running 任务活性判断 —— 两套三元组（wrapper 身份 + child 身份）
    - wrapper 身份：`wrapper_pid + wrapper_start_time_us + runner_token`（env 比对通过 `ps eww` 或 `libproc.proc_pidinfo` + 进程 env）
    - child 身份：`pid + process_start_time_us + runner_token`（same env 验证）
    - 分支：
        - wrapper alive → 跳过（wrapper 自行收尾）
        - wrapper dead + bg_runs 无 pid（Phase S 中 crash） → 用 runner_token 在 `ps eww` 扫描 BG_TASK_TOKEN 匹配的孤儿 → 找到 → bridge 主动 reap；没找到 → `orphan, reason='wrapper_died_pre_register'`
        - wrapper dead + child alive + 三元组匹配 → **bridge 主动接管**：检查 `cancel_requested_at`/`timeout_seconds`，满足则 `killpg(pgid, SIGTERM)` 500ms poll 5s grace 后 SIGKILL；不满足则 spawn reaper 线程 kqueue 监听子退出 → 退出后写终态 + `reason='reaped_by_bridge_after_wrapper_death'` 或 `'completed_after_wrapper_death'`
        - wrapper dead + child dead + manifest 存在 → 从 manifest 更新终态 + `delivery_state='pending'`
        - wrapper dead + child dead + 无 manifest → `orphan, reason='wrapper_and_child_both_died'`
    - Validate: 5 种分支各有 fixture；pid reuse 场景：kill wrapper + 快速 fork 同 pid 的无关进程 → 三元组 mismatch → 不发任何信号 + 标 orphan；bridge reap 路径断言 `killpg` 被调用，最终 state 为 cancelled 或 timeout
- [x] 6.4 Delivery outbox 补投：扫 `delivery_state IN ('pending','delivery_failed')` → 重新 enqueue 合成 turn；`delivery_attempt_count ≥ 10` 视为放弃 + 日志 ERROR
    - Validate: 预置 2 pending + 1 delivery_failed + 1 attempt_count=10 → 启动后补投 3 + 放弃 1
    - Commit A 通过 `_scan_delivery_outbox` + `_log_retry_budget_exhausted` 实现
- [x] 6.5 Manifest-only 回填：扫 `tasks/completed/*/task.json.done` 对应 `bg_tasks` 行缺失或 `bg_runs` 行缺失 → 回填；`delivery_state='pending'`
    - Validate: 删除 DB 行保留 manifest → 启动后 DB 行重建 + delivery 被触发
    - Commit A 通过 `rebuild_from_manifests` 幂等复用（活 DB 模式，不仅 quarantine）
- [x] 6.6 Archive cleanup + quarantine retention
    - Archive policy：completed > 7 天 → `_archive/<yyyy-mm>/<task_id>.tar.gz`；archive > 90 天 → 删除 + DELETE DB 行
    - **并发保护**：cleanup 走 `BEGIN IMMEDIATE` + predicate `delivery_state='sent' OR (delivery_state='delivery_failed' AND delivery_attempt_count >= 10)`；不删 retry 进行中的行
    - **Quarantine retention**：`bg_tasks.db.quarantine.<ts>` 保留最近 3 份或 30 天，取更晚的（UNION）；超出则连同 `-shm` / `-wal` sidecars 一并删
    - **Commit C 实现**：`cleanup_and_archive()` 三步顺序（tar.gz → rm src → DELETE guarded by 同一 predicate）；`cleanup_quarantine_files()` UNION (top N ∪ 30-day window)；step 8 in `BgSupervisor.reconcile()`；`feishu_bridge/bg_tasks_db.py` +~180 行 + `feishu_bridge/bg_supervisor.py` reconcile wiring + `tests/unit/test_bg_tasks_db.py` +11 tests（涵盖幂等、预谓词边界、UTC yyyy-mm、UNION 规则、sidecars、race guard）
    - Validate: cleanup 幂等（两次运行第二次 archived=0）；archive 目录不阻止新 task launch；DELETE 在 predicate 仍成立时才 cascade；retry 进行中（`delivery_state='pending'` 或 `'enqueued'`）的 completed 行不被 cleanup 删；`delivery_failed` + attempt_count=9 被跳过、=10 被归档；orphan 行（无 bg_runs join）也能归档；quarantine UNION 规则验证两种场景

## 7. 测试

- [x] 7.1 单元测试 `tests/test_bg_tasks_db.py`：schema + 状态机 + repo CRUD + 并发写 + CAS claim + integrity_check + manifest replay
    - Validate: pytest 跑通；覆盖率 ≥80%；CAS claim 并发测试用真 sqlite3 connection（不 mock）
- [x] 7.2 单元测试 `tests/test_task_runner.py`：wrapper 启动序列、cancel 信号转发、timeout monotonic clock、tail UTF-8 safe 截断、manifest atomic rename
    - Validate: 覆盖所有终态；monotonic clock 测试用 `freezegun` 或 monotonic mock；UTF-8 fixture 含 emoji 跨边界
- [x] 7.3 单元测试 `tests/test_bg_supervisor.py`：launcher CAS / delivery watcher retry / wake listener bind 回退 / session fallback
    - Validate: 覆盖 delivery retry 上限；session 不可 resume fallback 路径
- [x] 7.4 集成测试 `tests/test_bg_tasks_e2e.py`：启动 bridge fixture → CLI enqueue → 真实 `sleep 1` 经 task-runner → 验证合成 turn 出现在 ChatTaskQueue
    - Validate: 整条链路 <5s 完成；wrapper 是真进程（非 mock）；ChatTaskQueue assert 用 spy
- [x] 7.5 **Crash barrier 集成测试** `tests/test_bg_crash_windows.py`（关键新增）：
    - [x] `barrier=post_claim` crash → 重启后 launching 超时 → `failed, reason='launch_interrupted'`
    - [x] `barrier=post_spawn_pre_register`（R3 新增）kill wrapper 在 Phase S 单事务前 → child 已跑但 bg_runs.pid 为 NULL → 重启后用 runner_token 扫 `ps eww` → 找到则 reap，找不到则 `orphan, reason='wrapper_died_pre_register'`
    - [x] `barrier=post_spawn` kill bridge → wrapper 继续跑完 → 重启 bridge → delivery 补投
    - [x] `barrier=pre_rename` crash → 重启后 `orphan`
    - [x] `barrier=post_rename_pre_db` crash → 重启后从 manifest replay（Phase C 单事务未提交 → 仍 running + manifest 存在）
    - [x] `barrier=post_db_pre_enqueue` crash → 重启后 delivery outbox 补投
    - [x] `barrier=post_enqueue_send_fail` → `delivery_failed`, poller 重试
    - [x] `barrier=stuck_enqueued`（R3 新增）模拟 ChatTaskQueue consumer 吞掉 ack → delivery_state 卡 enqueued → 5min 后 poller 扫描回滚 pending + 重试 → 最终 sent
    - [x] `barrier=orphan_alive_bridge_reap`（R3 新增）SIGKILL wrapper 但保留 child 存活 → 设 cancel_requested_at → bridge reconciler 三元组验证 → `killpg(pgid, SIGTERM)` → 5s grace SIGKILL → 终态 cancelled + `reason='reaped_by_bridge_after_wrapper_death'`
    - Validate: 每个 barrier 都是真 kill（非 mock）；最终状态由 CLI `bg status` 断言，不看内部 state；新 barrier 验证 R3 所解决的 R2 评审 finding B1/B2
- [x] 7.6 **pid reuse 场景** `tests/test_pid_reuse.py`：kill wrapper → fork 无关进程占用相同 pid → 三元组 mismatch → reconciler 不发信号 + 标 orphan
    - Validate: 断言"从未调用 os.killpg"（spy）；最终 state='orphan'
- [x] 7.7 **DB 损坏恢复** `tests/test_db_recovery.py`：truncate bg_tasks.db 前 100 字节 → 启动 → quarantine + manifest replay
    - Validate: quarantined 文件保留；新 DB 行数 == manifest 数；日志含 `integrity_check failed`
- [x] 7.8 **SQLite BUSY 抗压** `tests/test_sqlite_busy.py`：CLI 开 transaction 持有 writer lock 4s → bridge 并发 enqueue → busy_timeout 后成功
    - Validate: enqueue 5s 内返回；不吞错
- [x] 7.9 **Cancel 真路径** `tests/test_cancel.py`：queued cancel 立即 `cancelled`；running cancel 触发真 SIGTERM 5s grace 真 SIGKILL；≤10s 终态
    - Validate: 信号通过 wrapper 转发到 user command；pgid 正确；SLO 用 monotonic 断言
- [x] 7.10 **回归**：运行现有 `tests/` 全部测试
    - Validate: 零失败零新跳过；`enqueue_turn` 对人类消息的 golden 断言通过
    - Evidence: `PYTHONPATH=/Users/feir/Library/Python/3.14/lib/python/site-packages python3 -m pytest tests -q` → 639 passed, 3 skipped, 6 warnings.

## 8. 文档与发布

- [x] 8.1 更新 `README.md`：新增 `bg` 子命令使用说明 + manifest 格式示例 + argv 用法（`--` 分隔）
    - Validate: 包含最小例子 `feishu-bridge-cli bg enqueue --chat-id oc_xxx --on-done-prompt "done" -- sleep 10`；说明 bridge 崩溃不影响已 launch 任务完成
- [x] 8.2 更新 `CLAUDE.md`（项目级）：何时用 bg-task（任务预计 >90s 且需要汇报）vs fire-and-forget；argv 必须通过 `--` 分隔；安全说明 `shell=False` 强制
    - Validate: 使用场景判断规则可执行（例子形式而非描述）
- [x] 8.3 migration 说明：现有用户升级到本版本 bridge 首次启动时会自动创建 `~/.feishu-bridge/`；`bg_tasks.db` 空库创建；已存在目录不被覆盖
    - Validate: 现有用户目录存在 → 不覆盖；空目录 → 创建预期文件树

## Review Report

### Plan Review Round 1 (2026-04-18)
- verdict: **Block / rework-and-resubmit**
- findings: 1 CRITICAL + 5 HIGH + 5 MEDIUM + 4 LOW
- decision: Captain 选 Path A —— 引入 task-runner wrapper 独立进程
- result: BLOCK

### Plan Review Round 2 (2026-04-18)
- verdict: **fix-then-proceed（不需额外评审轮次）**
- findings: 4 HIGH (B1-B4) + 5 MEDIUM (B5-B9) + 3 LOW (B10-B12)
- Round 3 修复涵盖：
    - B1 post-spawn-pre-register 窗口 → wrapper Phase P/S 拆分 + 单事务 UPDATE pid
    - B2 wrapper-dead-child-alive → bridge 主动 reap + 尊重 cancel/timeout
    - B3 delivered-before-send 语义 → 4 状态 outbox (pending/enqueued/sent)
    - B4 两事务不一致 → Phase C 单事务
    - B5 process_start_time 精度 → `libproc.proc_pidinfo` μs
    - B6 wrapper 身份未持久化 → `wrapper_start_time_us` 列
    - B7 session resume 检测 → `sessions_index` + 5s sentinel probe
    - B8 archive cleanup race → `BEGIN IMMEDIATE` + predicate
    - B9 截断顺序 → 4 步确定性
    - B10 cancel poll 500ms → wrapper Phase W 明确
    - B11 quarantine retention → 3 份或 30 天
    - B12 runner_token 定性 → 非秘密 nonce，删除单独文件
- result: WARN

### Implementation Round 1 — Section 1 数据层 (2026-04-18)
- scope: Tasks 1.1–1.4 (`feishu_bridge/bg_tasks_db.py` + `tests/unit/test_bg_tasks_db.py`)
- code-reviewer 首轮结论: **BLOCK** — 5 blocking + 6 should-fix + 6 nit
- Round 1 修复（blocking only，SHOULD-FIX 留作 Section 2 并推或本轮收尾决定）：
    - B1 `finish_run` SQL 放行 launching→completed/cancelled/... 与 `_ALLOWED` 不符 → 改为 tx 内 SELECT 决定 legal_from_clause，仅允许 launching→failed 捷径
    - B2 running + cancel_requested 遇 `finish_run(completed)` 被忽略 → tx 内读 `cancel_requested_at`，将 completed 强制改为 cancelled，保留用户意图
    - B3 `rebuild_from_manifests` active-dir 未检查 `task.json.done` → 先查 manifest；存在则 replay + `mv active→completed`，缺失才标 orphan
    - B4 `check_same_thread=False` 与 single shared conn 不安全 → 移除参数，docstring 明确要求每线程自建连接
    - B5 manifest input 未校验 → 新增 `_is_trusted_task_dir()` 拒绝非 uuid 目录 / symlink；`_replay_completed_manifest` 强制 `task_id == dir_name`、`schema_version ∈ [1,2]`、`chat_id/session_id` 必须 string
- 新增 regression tests: `test_finish_run_rejects_launching_to_completed`、`test_finish_run_launching_to_failed_allowed`、`test_finish_run_coerces_completed_to_cancelled_on_cancel_request`、`test_finish_run_does_not_coerce_failed_on_cancel_request`、`test_rebuild_from_manifests_replays_active_with_committed_done`、`test_rebuild_from_manifests_rejects_mismatched_task_id`、`test_rebuild_from_manifests_rejects_non_uuid_dir`、`test_rebuild_from_manifests_rejects_future_schema_version`、`test_rebuild_from_manifests_rejects_symlink_dir`
- tests: 52 passed in 0.21s (zero warnings with `-W error::pytest.PytestUnhandledThreadExceptionWarning`)
- SHOULD-FIX 延迟项（后续 section 落地前处理）：
    - S1 `validate_transition` docstring 与行为不符（识别出应修 docstring，未改代码）
    - S2 `mark_delivery_state` 缺 adjacency 检查 → Section 4 delivery watcher 落地时一起改
    - S3 integrity-check 文件锁 → Section 6 reconciler 落地时统一加 recovery lockfile
    - S4 manifest `schema_version` 已校验上限，字段缺失不报错符合向后兼容意图
    - S5/S6 tx rollback / terminal CAS 测试 → 下一轮 test-harden batch
- result: WARN

### Code Review Round 1 — Section 2 task-runner (2026-04-18)
- scope: Tasks 2.1–2.4 (`feishu_bridge/task_runner.py` + `tests/unit/test_task_runner.py` + pyproject.toml console_script `task-runner`)
- code-reviewer 首轮结论: **PASS-WITH-EDITS** — 0 blocking + 2 should-fix + 4 nit
- 实施前修复（本轮落地）：
    - `BgTaskRow` 字段双重 `json.loads()` 误用（`command_argv` / `env_overlay` / `output_paths` 四处），已改为直接消费 dataclass 已解析字段
    - `terminate_pgid` probe 只处理 `ProcessLookupError`，macOS 下 group-leader reap 后返回 EPERM → 加入 `PermissionError` 同义处理
- Round 1 修复（应对 code-reviewer）：
    - S1 error-path 覆盖太薄 → 新增 6 个测试：`test_main_non_zero_exit_produces_failed_state`、`test_main_timeout_produces_timeout_state`、`test_main_rejects_task_not_in_launching_state`、`test_main_rejects_invalid_task_id`、`test_main_rejects_invalid_runner_token`、`test_phase_s_logs_redact_argv`
    - S2 `phase_s` INFO 日志含完整 argv 可能泄漏秘密 → INFO 只输出 `argv[0] + len(argv)`，全 argv 降到 DEBUG；`test_phase_s_logs_redact_argv` 通过 sentinel 秘密保证未来 log 改动不回归
- 延迟项 (nit，不阻塞本 section)：
    - N1 manifest tmp 文件名 `task.json.done.tmp` vs 设计 `task.json.tmp`，语义等价（atomic write temp→rename），不改
    - N2 tasks.md 原文 Phase W 写 kqueue `EVFILT_PROC`，实施用 `Popen.wait(timeout=0.5)` polling → 已更新 tasks.md 行 22 文案
    - N3 `_WrapperState.conn` + `proc.stdout/stderr` 未显式 close，进程退出时自然释放；短生命期 wrapper 保留当前形式
    - N4 Codex 跨模型评审未运行（工具超出本轮预算），留作 Section 3/4 时集中补
- tests: 33 passed (task_runner) + 52 passed (bg_tasks_db regression) = 85 passed
- result: PASS-WITH-EDITS

### Code Review Round 2 — Section 2 Codex 跨模型评审 (2026-04-18)
- scope: 同 Round 1（task_runner.py + test_task_runner.py），补做 Codex CLI cross-model review
- Codex 结论: 3 个新 BUG（均为 FD/zombie leak 风险，Claude 评审未命中）
- 修复：
    - C1 (task_runner.py phase_s OSError 路径) → `read_proc_start_time_us()` 抛错时先 `terminate_pgid` 再 `raise`，但未 `close()` stdout/stderr 管道 / `wait()` reap child。新增 `_cleanup_child_io()` helper（close pipes → join collectors → wait proc），OSError 分支调用 `_cleanup_child_io(state.child_proc, None, None)`（collectors 此时未启动）
    - C2 (task_runner.py phase_s `_AttachRace` 分支) → 同样 kill pgid 后未清理 FD / reap。调用 `_cleanup_child_io(state.child_proc, state.stdout_collector, state.stderr_collector)`
    - C3 (task_runner.py `main()` 入口) → `phase_s` 抛出非 OSError/AttachRace 异常时 `return 1` 无 cleanup。将 phase_p/phase_s/phase_w/phase_c 整体包进 try/finally，finally 里统一 `_cleanup_child_io(...)` + `state.conn.close()`
- 为什么 Claude 未命中：Claude reviewer 关注 SQL/事务/秘密/边界校验等语义层；Codex 更擅长扫资源生命周期与错误路径清理缺口，两侧互补
- 回归：tests 仍 85 passed（未新增测试，因 FD leak 在短生命 wrapper 中不易直接观测；等 Section 6 reconciler 引入 long-running 场景再补 stress test）
- 延迟项：无新增 nit
- result: PASS

### Code Review Round 1 — Section 3 CLI (2026-04-18)
- scope: Tasks 3.1–3.4 (`feishu_bridge/cli.py` bg subcommand group + `tests/unit/test_cli_bg.py` 17 tests)
- code-reviewer 结论: **PASS-WITH-EDITS** — 0 blocking + 2 should-fix + 3 nit
- diff basis: HEAD (dirty — working tree has cli.py + test_cli_bg.py unstaged)
- Validate 对齐:
    - 3.1 bg 子命令组齐备（enqueue/status/list/cancel），argparse 自动提供 --help（未写独立测试，属 argparse 自带行为，不视为覆盖缺口）
    - 3.2 `--cmd-json` vs 位置 argv 二选一；bare string 被 rc=2 拒绝；缺 `--on-done-prompt` 被 argparse rc=2 拒绝；默认 `--timeout-seconds=1800`；无 bridge listener 时 enqueue 成功
    - 3.3 status 未知 task → rc=1；list 按 updated_at DESC + chat/state 过滤；cancel 已终态 → rc=1 且 state 不变；cancel 仅改 `cancel_requested_at`
    - 3.4 wake.sock 不存在 → 静默跳过；listener 在线时 `\x01` payload 送达
- Should-fix 已修:
    - S1 cancel 路径丢弃 `set_cancel_requested()` 返回值 → 若 DB WHERE 因 TOCTOU 未命中（row 在 get→UPDATE 间转入 terminal），CLI 仍输出 `cancel_requested: True` 误导上游。已改为读取 bool 返回值，False 时 rc=1 + error "task transitioned to terminal state during cancel; no flag set"
    - S2 `_parse_env_kv` 错误消息用 `{s!r}` 回显原始值 → 用户 fat-finger `--env API_KEY_abc123`（漏 `=`）会把 secret 泄漏到 stderr / shell history。已改为 `got value of length {len(s)}`；空 key 分支同样改为不回显。与 Section 2 Round 1 的 argv-redaction 修复同源
- Nit（不阻塞，未修）:
    - N1 "DB locked → 非零退出 + 明确错误"（Validate 3.2）有代码分支（sqlite3.OperationalError → rc=1）但无测试；构造 locked DB 需要额外 fixture，留作后续 Section 7 stress harden 再补
    - N2 `--cmd-json` schema 校验代码覆盖 non-list / 空列表 / 非 string 元素三种情况（`_run_bg_command` 行 315-320），但只有 happy path 有测试；非关键路径，延后补
- 回归: `uv run pytest tests/unit/test_cli_bg.py -q` → 17 passed in 1.96s（fix 前后一致）；未运行完整 tests/ 套件，因本次改动仅限 bg CLI 路径
- result: PASS-WITH-EDITS

### Code Review Round 2 — Section 3 Codex 跨模型评审 (2026-04-18)
- scope: 同 Round 1（cli.py bg 子命令 + test_cli_bg.py），在 main-shell 用 `acpx codex exec` 跑 Codex CLI 跨模型评审（code-reviewer agent 因 sandbox output-redirect 限制未能完成，由主会话补做）
- Codex 结论: **FIX-BEFORE-COMMIT** — 2 BUG + 2 WARN（全部 Claude Round 1 未覆盖）
- 修复（全部本轮落地）：
    - D1 (BUG) `bg list --limit` 接受负值/0/过大值 → SQLite 把 `LIMIT -1` 当无限制，用户可意外 dump 所有 row（含 `env_overlay` / `command_argv` / `on_done_prompt` 可能秘密）。与 Section 2 argv-redaction / Section 3 `_parse_env_kv` 同源的数据泄漏面。新增 `_positive_int(max_value)` argparse type，cap=200；对应 3 个测试：`test_list_limit_{negative,zero,exceeds_cap}_rejected`
    - D2 (BUG) `--timeout-seconds` 接受 0/负值 → runner 侧 `int(timeout_seconds or 1800)` 把 0 静默改为默认 1800；负值立刻超时。cap=86400（24h）；对应 3 个测试：`test_enqueue_timeout_{zero,negative,exceeds_cap}_rejected`
    - D3 (WARN) status/list/cancel 的 `repo.get()/list()/set_cancel_requested()` 未包 `sqlite3.Error` → DB 损坏 / IO 错误时裸 traceback 冒出，与 enqueue 的 JSON-stderr 约定不一致。新增 `_bg_db_json_error(label, exc)` helper + 三子命令在 `_open_repo()` 和 repo 调用处 double-wrap；新增 3 测试 `test_{status,list,cancel}_missing_db_returns_json_error` 覆盖 DB 缺失的常见触发
    - D4 (WARN) 校验顺序 → enqueue 的 argv/env/json 校验失败前已经 `_bg_ensure_home() + init_db(db_path)`，非法命令也会在磁盘留下持久化状态。拆出 `_ensure_db()` 内部 helper，只在 enqueue 全部参数校验通过后才执行；status/list/cancel 改为"DB 不存在 → JSON error + rc=1"。`test_enqueue_timeout_zero_rejected` 附加断言 `bg_tasks.db` 未被创建
- 为什么 Claude 未命中：Claude reviewer 停在"代码逻辑对 argparse 值 OK"；Codex 继续问"这个值被传给 SQLite / runner 时运行时怎么解释"——D1 的 `LIMIT -1` 和 D2 的 `timeout=0` 都是系统层语义陷阱。与 Section 2 Round 2 的 FD leak 属同类：Claude 关注语义，Codex 关注运行时解释层
- 回归：`uv run pytest tests/unit/test_cli_bg.py -q` → 26 passed in 2.66s（17 原测试 + 9 新测试覆盖 D1-D4）
- 延迟项：无新增 nit
- result: PASS

### Code Review Round 1 — Section 6 Commit A Startup Reconciler (2026-04-18)
- scope: `feishu_bridge/bg_supervisor.py` reconcile() + helpers, `feishu_bridge/main.py` boot order, `tests/unit/test_bg_supervisor.py` +10 tests; §6.1/6.2/6.4/6.5/6.6 implemented; §6.3 (running liveness triage) deliberately deferred to Commit B as `_warn_running_rows` stub
- basis: working-tree diff (HEAD+dirty)
- Codex cross-review: skipped — `acpx codex exec` stdout redirect blocked by session sandbox across `/tmp`, `/Users/feir/projects/...`, and `~/.claude/...`. Claude-only review per skill fallback
- findings:
    1. [WARN][Claude] `bg_supervisor.py:431` `_reset_stranded_enqueued` docstring reasoning is subtly wrong. The "no double-delivery because the worker never sent" rationale relies on CAS semantics, but `worker.py:927` discards the `_bg_mark_dequeued()` return value — a concurrent worker whose CAS failed would still proceed to send. The actual safety guarantee is proposal.md NOT (single-bridge-per-home), under which the previous bridge's workers die with it. Recommendation: rewrite the docstring paragraph to state the correct single-bridge premise and cross-ref proposal.md NOT line 34.
    2. [WARN][Claude] Test gaps in `test_bg_supervisor.py`:
        - No assertion that `reconcile()` increments `stats['queued_launched']` when stranded-enqueued rows are re-queued via live `enqueue_fn`.
        - No boundary test for `_DELIVERY_ATTEMPT_CAP`: attempt_count=9 (must NOT log ERROR) vs attempt_count=10 (must log). Current coverage only exercises one side.
        - No integration test exercising `reconcile()` → `enqueue_fn` → listener path end-to-end.
      Recommendation: add three targeted tests before Commit B lands.
    3. [NOTE][Claude] `bg_supervisor.py:~291` fresh-boot path is cosmetically misleading. `bg_tasks_db.integrity_check_and_maybe_quarantine()` returns the input path unchanged when `not p.exists()` (line 345), so on a first-ever boot the code flows through the quarantine-handling branch and logs `"DB quarantined; rebuilding from manifests"` with `stats["quarantined"]=1` — despite nothing having been quarantined. Recommendation: distinguish fresh-boot (`not db_path.exists()` before call) from genuine quarantine, or adjust the log message.
    4. [PASS] Step ordering correctness: step 5 (`_reset_stranded_enqueued`) correctly runs before step 7 (delivery scan). Stranded rows (`delivery_state='enqueued' AND enqueued_at IS NULL`) are invisible to both `list_pending_deliveries` (scans `pending`/`delivery_failed` only) and the 5-minute stuck-rollback guard (requires `enqueued_at IS NOT NULL`); without step 5 they would leak indefinitely. Evidence: `bg_supervisor.py:242-387` step numbering, `bg_tasks_db.py` delivery-state filters.
    5. [PASS] `rebuild_from_manifests` safety on live DB: idempotent via `_row_exists()` pre-check + `INSERT OR IGNORE`, and actively moves `active/<id>/ → completed/<id>/` only when no DB row exists. Re-running after a partial rebuild is a no-op. Evidence: `bg_tasks_db.py:371` and `_row_exists()`.
    6. [PASS] `_warn_running_rows` stub quality: correctly counts running rows and logs WARN referencing §6.3 deferral; never touches row state, so Commit B can land the triple-verification triage without schema churn. Evidence: `bg_supervisor.py:411`.
    7. [PASS] Boot order in `main.py:1012-1015`: `reconcile()` runs BEFORE `start()`. This matters because `integrity_check_and_maybe_quarantine()` may rename the DB file; running reconcile first ensures listener/poller threads never hold handles to a renamed file. Evidence: `main.py:1012-1015`.
    8. [PASS] `tasks.md` checkbox state accurate: 6.1 `[~]` (Commit A/B split annotated), 6.2/6.4/6.5 `[x]`, 6.3 `[ ]` (deferred). Matches implementation scope.
    9. [PASS] No proposal.md NOT violations: multi-bridge handling not introduced; all safety arguments stay within single-bridge premise.
   10. [PASS] Tests: `uv run pytest tests/unit/test_bg_supervisor.py -x --tb=short -q` → 48 passed, 2 warnings in 6.17s. All 10 new reconcile tests pass.
- verdict: APPROVED (WARN-level findings only; no BLOCKs)

### Code Review Round 1 — Section 6 Commit B Running Liveness Triage (2026-04-19)
- scope: `feishu_bridge/bg_supervisor.py` §6.3 triage dispatcher + 5 branch methods + reaper daemon + identity helpers; `feishu_bridge/bg_tasks_db.py` `finalise_reaped()` + `rebuild_from_manifests(*, replay_only=False)`; `tests/unit/test_bg_supervisor.py` +6 triage unit tests + §7.5/§7.6 real-subprocess barrier tests (darwin-only); tasks.md 6.1/6.3 checkbox + reconcile log key updates
- basis: staged diff (HEAD+staged); 59/59 bg_supervisor tests pass, 610/611 unit tests pass (1 unrelated pre-existing footer test failure)
- Codex cross-review: skipped — acpx invocation hit the session's Bash approval gate repeatedly (`command -v`, `timeout 180 /opt/homebrew/bin/acpx ...`, even after splitting and using absolute paths). The pre-existing `.codex-commit-a-review-v{1,2,3}.txt` fixtures in the working tree confirm the same sandbox-vs-acpx friction seen on Commit A. Claude-only review per skill fallback. Recommend Captain run `acpx --format quiet --approve-reads --cwd /Users/feir/projects/feishu-bridge codex exec --file /Users/feir/projects/feishu-bridge/.codex-commit-b-prompt.txt` manually if a second-model pass is desired before merging — the prompt file is already written.
- findings:
    1. [PASS][Claude] Safety-critical pid-reuse invariant is correctly enforced. `_verify_triple` (`bg_supervisor.py:189-217`) fail-closes on `pid in {None, 0, <=0}`, `expected_start_us in {None, 0, <=0}`, empty/None `expected_token`, `_proc_start_time_us` returning None, start_time_us mismatch, and token mismatch. Every `os.killpg` path is gated: `_triage_one` calls `_verify_triple` on the child before `_reap_now` (line 850-856); `_reap_now` refuses on `pgid <= 0` (line 965-971); `_triage_pre_register` requires a successful `_scan_ps_for_token` match before signaling (line 912-923). The §7.6 real-subprocess barrier test (`test_reconcile_barrier_pid_reuse_sends_no_signal_to_victim`) wraps `bg_supervisor.os.killpg` with a spy and asserts `kill_calls == []` — belt-and-suspenders coverage of the safety invariant. Evidence: `bg_supervisor.py:189-217, 846-898, 960-990`; `test_bg_supervisor.py:1809-1892`.
    2. [PASS][Claude] Triage default branch is "orphan, no signal". `_triage_pre_register` when `token` is None (line 905-911) → `_mark_orphan` with no `killpg` call. `_triage_both_dead` when manifest absent/unusable (line 953-958) → `_mark_orphan`. `_triage_one` when child triple-verify fails (line 855-856) → `_triage_both_dead` → orphan. `_reap_now` when `pgid <= 0` (line 965-971) → orphan. Five branches, no silent signal path. Evidence: `bg_supervisor.py:901-990`.
    3. [PASS][Claude] `_verify_triple` / `_read_proc_env_token` / `_scan_ps_for_token` use the corrected macOS `ps` syntax. `_read_proc_env_token` uses `/bin/ps eww -p <pid>` (line 173) and `_scan_ps_for_token` uses `/bin/ps axeww -o pid=,pgid=,command=` (line 246) — both place `e` inside the flag cluster so env output is not dropped by the `-o` override. The docstrings at lines 155-170 and 220-239 explicitly call out the SIP-protected binary caveat (`/bin/*`, `/usr/bin/*` unreadable via `ps eww`) and note the tests route around it by spawning `sys.executable` instead of `/bin/sleep`. Test helper `_spawn_sleep_with_token` (line 1710-1729) matches — Python interp is Homebrew, not SIP-protected. Evidence: `bg_supervisor.py:155-282`; `test_bg_supervisor.py:1710-1735`.
    4. [PASS][Claude] Reaper daemon concurrency is safe under the single-thread-reconcile call pattern. `_spawn_reaper` (line 1009-1039) takes `_reapers_lock` for the cap check + insert; `_reaper_worker` (line 1041-1111) respects `_stop_evt.wait()` between polls, handles `ProcessLookupError` (commit) / `PermissionError` (pid-reuse → abort with no commit) distinctly, and the `finally` clause unconditionally removes the pid from `_reapers`. `stop()` snapshots under lock then joins outside lock (line 515-520), matching the deadlock-avoidance comment. Private DB connection per reaper (line 1072) avoids cross-thread sqlite3 reuse. Evidence: `bg_supervisor.py:489-535, 1009-1111`.
    5. [PASS][Claude] `_apply_manifest_to_running` delegates to `repo.finish_run`, which runs both bg_runs + bg_tasks UPDATEs inside `_tx(self.conn)` (bg_tasks_db.py:975-1030). `delivery_state='pending'` is stamped atomically with `finished_at` and the terminal `bg_tasks.state` transition; no partial split view is observable. `_apply_manifest_to_running` correctly handles `_FinishRace` / `ValueError` as "return False; caller falls back to orphan" (bg_supervisor.py:1187-1197). `finalise_reaped` also uses `_tx` and distinguishes deliverable terminals (cancelled/timeout → `delivery_state='pending'`) from orphan (`'not_ready'`), matching the §6.3 contract. Evidence: `bg_tasks_db.py:1032-1090, 944-1030`; `bg_supervisor.py:1134-1197`.
    6. [PASS][Claude] Test adequacy on the five triage branches. Attached / reap-on-cancel / pid-reuse-mismatch / manifest-applied / pending-reap each have a dedicated test (`test_bg_supervisor.py:1253-1482`). Monkeypatching is surgical: only `_verify_triple` and `_kill_pgid_with_grace` are stubbed; the dispatcher itself, `finalise_reaped`, `finish_run`, `_mark_orphan`, `_load_task_manifest`, `_apply_manifest_to_running`, and `_spawn_reaper`'s lock/dict bookkeeping run unmocked. The §7.5 real-subprocess test (`test_reconcile_barrier_orphan_alive_bridge_reap_cancels_real_child`) exercises the full dispatcher end-to-end with a real child, real libproc start_time, real `ps eww` env read, and real `killpg` — catching anything the monkeypatch tests miss. Evidence: `test_bg_supervisor.py:1253-1482, 1738-1806`.
    7. [PASS][Claude] §7.6 pid-reuse barrier test (line 1809-1892) is the right shape: sets `wrapper_pid=1, wrapper_start_time_us=1` (triple mismatch guaranteed on pid 1 / init) and keeps the victim's `process_start_time_us` correct while only the token mismatches — the exact scenario where a naive "pid alive + start_time matches" check would signal. Spy confirms `kill_calls == []` and `victim.poll() is None` after reconcile. This is the specific guard lessons.md has flagged as load-bearing.
    8. [PASS][Claude] `_reset_stranded_enqueued` docstring correctly updated from Commit A Round 1 finding #1 — now explicitly states the single-bridge premise (proposal.md "NOT 多机/多 bridge 分布式") and documents the accepted launchd-reload-overlap edge case with its double-delivery tradeoff. Evidence: `bg_supervisor.py:1199-1230`.
    9. [PASS][Claude] `rebuild_from_manifests(replay_only=True)` correctly disables orphan-minting for the healthy-boot delta backfill (bg_tasks_db.py:452-456). Quarantine recovery retains the default `replay_only=False` so wrapper-and-child-both-died rows are still synthesized. Without this split the delta backfill would mis-mark a live running task (wrapper alive, manifest not yet written) as orphan. Evidence: `bg_tasks_db.py:383-472`; `bg_supervisor.py:657-671`.
   10. [PASS][Claude] `_decode_b64_tail` (bg_supervisor.py:285-309) mirrors `bg_tasks_db._decode_tail` with strict base64 + `binascii.Error` catch — corrupt manifests surface as WARN with field name, not silent data mangling. This closes a latent inconsistency where one decode site was strict and the other could raise.
   11. [PASS][Claude] tasks.md checkbox state accurate: 6.1 `[x]` with Commit A+B annotation and reconcile log-key list updated to include all five new `running_*` labels (running_attached/reaped/pending_reap/orphaned/manifest_applied); 6.3 `[x]`. Matches implementation scope.
   12. [PASS][Claude] No proposal.md NOT violations. All safety arguments stay within the single-bridge-per-home premise. No multi-bridge coordination, no launchd integration beyond the pre-existing launchd-reload-overlap accepted edge case (already documented in Commit A Round 1). Evidence: `bg_supervisor.py:1199-1223` paragraph + `proposal.md:31-38`.
   13. [PASS][Claude] Tests: `uv run pytest tests/unit/test_bg_supervisor.py -x --tb=short -q` → 59 passed (per user-supplied test status). 6 new triage unit tests + 2 darwin-only barrier tests. One pre-existing unrelated failure in the broader suite (`test_footer_no_model_no_workspace` from commit f389aec) is not caused by Commit B.
   14. [WARN][Claude] `_apply_manifest_to_running` does not promote `tasks/active/<tid>/` → `tasks/completed/<tid>/` after a successful replay. `_load_task_manifest` reads the manifest from `active/` (line 1121), then `finish_run` stamps `manifest_path=active/<tid>/task.json.done`. On the next reconcile, `rebuild_from_manifests(replay_only=True)` walks `active/` again, re-parses the same manifest, hits `_row_exists(tid) → True`, skips, and `continue`s — the active directory persists indefinitely. Unlike `rebuild_from_manifests`' own active-dir branch (bg_tasks_db.py:434-445) which DOES call `task_dir.rename(dest)` after replay, the triage path leaves the dir stranded. Not a correctness bug (idempotent, bounded to one row per leaked dir), but a slow accumulation hazard on long-uptime bridges that see many wrapper-mid-rename crashes. Recommendation: after a successful `_apply_manifest_to_running`, attempt the `active/<tid>/ → completed/<tid>/` rename with an `OSError` swallow, matching the pattern at `bg_tasks_db.py:434-445`.
   15. [WARN][Claude] `_spawn_reaper` has a theoretical TOCTOU between inserting the thread into `self._reapers` (line 1037, under lock) and `t.start()` (line 1038, outside lock). If `stop()` interleaves between those two statements, it snapshots an unstarted thread: `t.is_alive()` returns False, `join()` is skipped, and the thread is subsequently started by `_spawn_reaper`'s next line — now running past `stop()`'s shutdown. In practice this is unreachable because `reconcile()` is only called once from `main.py:1018` BEFORE `start()`, so `stop()` cannot interleave with a reconcile-spawned reaper; and the reaper is a daemon thread so process exit will kill it anyway. Recommendation (defensive only, not required): move `t.start()` inside the `with self._reapers_lock` block so `stop()`'s snapshot never sees an unstarted thread, and add an `if self._stop_evt.is_set(): return False` pre-check at the top of `_spawn_reaper` to bail cleanly if someone ever does call `reconcile()` after `stop()`.
   16. [NOTE][Claude] `_scan_ps_for_token` does a redundant regex search: line 270 `if _RUNNER_TOKEN_RE.search(parts[2]):` followed immediately by line 271 `m = _RUNNER_TOKEN_RE.search(parts[2])`. The first `search` is used only as a boolean gate; the second extracts the match. Both calls scan the same string. Harmless, and the input is bounded by ps output size, but the guard is dead code — the second `search` combined with the `if m and m.group(1) == expected_token:` check (line 272) already handles the no-match case. Recommendation: drop line 270 and just check `if m and m.group(1) == expected_token` on the first search result.
   17. [NOTE][Claude] `_scan_ps_for_token`'s token-collision logging (line 276-281) logs only `expected_token[:8]` prefix but the collision scenario, if it ever fires, is a wrapper implementation bug that warrants a louder error. Recommendation (cosmetic): upgrade to `log.error` and include the matched pid list so operators can grep/filter.
   18. [NOTE][Claude] `test_reconcile_triage_pid_reuse_mismatch_sends_no_signal` uses `pid == 2000` in the fake row, which almost certainly doesn't exist on the test host, but the test relies on `_verify_triple` being monkeypatched to return False — so it never calls the real `_proc_start_time_us`. If a future refactor ever changes `_triage_one` to consult `_proc_start_time_us` directly (bypassing `_verify_triple`), this test would still pass green while the safety property is silently breached. Recommendation: add an `os.killpg` module-level spy to this test too (matching §7.6's spy pattern) so any accidental signal path surfaces regardless of which helper is called.
- verdict: APPROVED (three WARN/NOTE-level findings; no BLOCKs — pid-reuse safety invariant, concurrency model, atomic manifest replay, and test adequacy all hold)

Re-review: skip (findings #14-#18 are WARN/NOTE-level; #14 is a slow resource-leak hazard addressable in a follow-up, #15 is defensive-only given the single reconcile call site, #16-#18 are cosmetic. No CRITICAL/HIGH issues; no architectural change required.)

### Code Review Round 1 — Section 6 Commit C Archive + Quarantine (2026-04-19)

- scope: `feishu_bridge/bg_tasks_db.py` (+`cleanup_and_archive`, `_archive_task_dir`, `_delete_terminal_row_with_guard`, `cleanup_quarantine_files`, `_DELIVERY_SETTLED_SQL`, `_TERMINAL_STATE_SQL`, `_tx_immediate`); `feishu_bridge/bg_supervisor.py` (step-8 wiring + 4 new stats keys); `tests/unit/test_bg_tasks_db.py` (+12 tests: archival path, delivery_failed boundary 9/10, orphan w/o bg_runs, idempotency, crash-partial recovery, UTC yyyy-mm, 90d expiry + month-dir prune, race guard, UNION top-3∪30d, UNION top-3 wins, missing-dir no-op, symlink defense); `tests/unit/test_bg_supervisor.py` (stats-keys contract); tasks.md §6.6 check flip.
- basis: staged diff (HEAD+staged); 126/126 bg_supervisor+bg_tasks_db tests pass; codex cross-review skipped (session sandbox friction — Claude-only per skill fallback)
- findings:
    1. [PASS][Claude] SELECT predicate + orphan handling: `_DELIVERY_SETTLED_SQL` covers (a) `r.id IS NULL` for rebuild-minted orphans, (b) `not_ready` for `_mark_orphan`-marked orphans, (c) `sent` for delivered rows, (d) `delivery_failed AND attempt_count ≥ 10`. The 7-day time gate on `COALESCE(r.finished_at, t.updated_at)` combined with `t.state IN terminal` protects fresh `not_ready` rows from Phase C. Matches proposal.md:58 + design.md:200 (with documented extension of `not_ready` for `_mark_orphan` survivors).
    2. [PASS][Claude] Crash-safety ordering: tar.gz→rename→rmtree→DELETE is correct. `rebuild_from_manifests` cannot re-materialize deleted rows — it scans `completed/<tid>/task.json.done` only, never `_archive/`. `test_cleanup_archive_recovers_when_source_dir_already_rm` exercises mid-crash recovery.
    3. [PASS][Claude] Guard EXISTS predicate matches SELECT exactly: `_delete_terminal_row_with_guard` reuses `_TERMINAL_STATE_SQL` + `_DELIVERY_SETTLED_SQL` + same `COALESCE(...) < ?` time gate via shared constants. Race test `test_cleanup_delete_guard_rejects_if_predicate_flips` confirms delivery_state flip → `skipped += 1`, row intact.
    4. [PASS][Claude] FK cascade: `PRAGMA foreign_keys = ON` verified at init_db (raises if 0). `bg_runs.task_id REFERENCES bg_tasks(id) ON DELETE CASCADE` in schema — cascade works.
    5. [PASS][Claude] Time units consistent: `now_ms` + `finished_at`/`updated_at` all ms; `st_mtime` multiplied by 1000 for comparison. `test_cleanup_yyyy_mm_uses_finished_at_utc_not_now` pins UTC yyyy-mm behavior explicitly.
    6. [PASS][Claude] Stats-dict contract: reconcile seeds and populates all four new keys (`archived`, `archive_expired`, `archive_skipped`, `quarantine_pruned`); `test_reconcile_returns_stats_dict_with_all_keys` asserts exact-equal set membership.
    7. [PASS][Claude] Quarantine UNION: implements `keep = (top-N by mtime DESC) ∪ (mtime ≥ now - retain_days)` per proposal.md:153. Both branches covered: `test_quarantine_cleanup_keeps_union_of_top_n_and_recent_window` (ages 1/10/20/40/100 → keep 1/10/20) + `test_quarantine_cleanup_union_prefers_newer_of_two_sets` (all >30d → top-3 wins). Sidecar handling (-shm/-wal) paired with base file.
    8. [PASS][Claude-FIXED] Symlink defense-in-depth (was Round 1 WARN #8): symlink check moved to cleanup caller — if `src_dir.is_symlink()` cleanup skips BOTH `_archive_task_dir` AND `_delete_terminal_row_with_guard`, preserving the row for operator investigation. `_archive_task_dir` retains its internal check as belt-and-suspenders. Test `test_cleanup_refuses_to_archive_symlinked_task_dir` asserts row survives + no tarball.
    9. [PASS][Claude-FIXED] `BEGIN IMMEDIATE` wording alignment (was Round 1 WARN #9): new `_tx_immediate()` helper uses `BEGIN IMMEDIATE` literally; all three cleanup txns (Pass 1 SELECT, guarded DELETE, Pass 2 defensive DELETE) use it. Honors proposal.md:58 exact wording.
   10. [PASS][Claude-FIXED] Pass 2 defensive DELETE guard (was Round 1 NOTE #11): terminal-state predicate (`state IN terminal`) now on the expiry-path DELETE too, defending against hypothetical "operator manually tarred a live row into _archive/" footgun.
   11. [NOTE][Claude] Empty-month-dir prune swallows OSError silently (Round 1 NOTE #10 — deferred): fine functionally; consider `log.debug` on `rmdir` OSError for operability. Not blocking.
   12. [NOTE][Claude] Test coverage gaps for follow-up punch-list (Round 1 NOTE #12 — deferred): (a) concurrent real-writer racing cleanup mid-tar (current test uses monkey-patched tamper); (b) 90-day boundary exactly; (c) `tarfile.open` raising mid-write with .tmp cleanup branch; (d) missing-sidecar `unlink()` branch. Non-blocking; add to §7 test gap list.
   13. [PASS][Claude] Tests: 126/126 pass (59 supervisor + 67 db including the 12 new §6.6 tests); full suite 622/622 minus one pre-existing unrelated `test_footer_no_model_no_workspace` failure carried from Commit B context.
- verdict: APPROVED

Re-review: skip — all Round 1 WARNs fixed inline; two remaining NOTEs (#11 log.debug, #12 test gaps) are non-blocking deferred-items for a Section 7 follow-up commit.

### Code Review Round 2 — Commit B Finding #14 Fix: active/ leak promote (2026-04-19)

- scope: `feishu_bridge/bg_tasks_db.py` (+`promote_active_to_completed` module helper, +25 lines; `rebuild_from_manifests` refactored to call it, inline rename block removed); `feishu_bridge/bg_supervisor.py` (+11 lines: track `manifest_subdir` Optional[str] across the `("active", "completed")` search loop in `_apply_manifest_to_running`, call `promote_active_to_completed` post-`finish_run` when source was `active/`); `tests/unit/test_bg_supervisor.py` (+79 lines: `test_reconcile_triage_manifest_applied_on_both_dead` extended with rename assertion, `test_apply_manifest_to_running_promotes_active_dir_on_reaper_path` direct-call coverage, `test_apply_manifest_to_running_noop_when_already_completed` guard-gate test).
- basis: HEAD+staged (unstaged diff on 3 in-scope files; README.md / main.py / untracked pi-runner artifacts explicitly out of scope per review prompt); 128/128 tests pass per user-supplied status (`uv run pytest tests/unit/test_bg_supervisor.py tests/unit/test_bg_tasks_db.py -q`); Codex cross-review skipped — acpx invocation hit the session Bash approval gate (same sandbox-vs-acpx friction documented in Commit A/B reviews and captured in `.codex-commit-*-review*.txt` fixtures). Claude-only per skill fallback.
- findings:
    1. [PASS][Claude] Finding #14 closed correctly. The leak path was: `_apply_manifest_to_running` replays manifest from `active/<tid>/task.json.done`, `finish_run` stamps terminal DB row, directory stays at `active/<tid>/`, `cleanup_and_archive` only scans `completed/`, dir leaks forever. Fix: supervisor does the rename itself after successful `finish_run`. Evidence: `bg_supervisor.py:1227-1234` (inline comment documents window + rationale); `bg_tasks_db.py:392-416` (new helper); `cleanup_and_archive` at `bg_tasks_db.py:534-584` confirmed scans `completed_root` only.
    2. [PASS][Claude] Race on guard `if manifest_subdir == "active":` is safe. The guard reads the RE-SEARCH result (bg_supervisor.py:1183-1188 loop inside `_apply_manifest_to_running`), not the original `_load_task_manifest` result. If the wrapper's Phase C3 ran between `_load_task_manifest` and the apply, the re-search finds the manifest in `completed/`, sets `manifest_subdir="completed"`, and the promote is correctly skipped. No hole.
    3. [PASS][Claude] Helper idempotency contract. `promote_active_to_completed` at `bg_tasks_db.py:405-406` returns True silently when `src.is_dir()` is False (missing active/ — already promoted or never existed), which is the correct semantics for callers that don't check the return. Symlink defense at the same line (`src.is_symlink()`) is defense-in-depth — strict improvement over the prior inline version, because the new helper is now called from `_apply_manifest_to_running` where `_is_trusted_task_dir` isn't in the call chain (prior inline rename was gated only by the outer `_is_trusted_task_dir` in `rebuild_from_manifests`). Evidence: `bg_tasks_db.py:392-416`; `bg_tasks_db.py:809-823` (`_is_trusted_task_dir` only filters scan iteration, not triage path).
    4. [PASS][Claude] OSError handling (dest exists / cross-device / perm). Line 411-414: caught, `log.warning` with tid + exc, returns False. Callers (both supervisor and `rebuild_from_manifests`) don't check the return — acceptable because: (a) the DB row is already terminal; (b) the wrapper-rare crash paths that leave `completed/<tid>/` already present (e.g., power loss mid-rename) are pathological; (c) failure surfaces in logs for operator cleanup. Return semantics documented in docstring.
    5. [PASS][Claude] Refactor preserves `rebuild_from_manifests` behavior. Old inline block at prior `bg_tasks_db.py:453-466` (per git diff) → new delegation at `bg_tasks_db.py:481` (`promote_active_to_completed(root, tid)`). Verified: (a) call site is same (inside `if _replay_completed_manifest(...)` branch); (b) symlink guard added (defense-in-depth, prior `_is_trusted_task_dir` outer filter already excluded symlinks so no semantic change); (c) log.info message `"bg reconcile: promoted active/%s → completed/"` preserved verbatim; (d) log.warning key changed from `"active/%s manifest replayed but mv failed"` to `"bg reconcile: promote active/%s → completed/ failed"` — grep confirms no consumers (`grep -r "manifest replayed but mv failed"` → no matches); (e) stats accounting unchanged (old code never incremented a stat on rename success/fail; new helper likewise just returns bool). Existing coverage `tests/unit/test_bg_tasks_db.py:775-780` (`rebuild_from_manifests` active-promote path) still asserts "Directory was promoted" — regression fence intact.
    6. [PASS][Claude] Crash-safety window decision is correct. Between durable `finish_run` and non-durable `rename`, if the supervisor dies, the DB row is terminal (won't resurface for triage) and `rebuild_from_manifests(replay_only=True)` at next boot walks `active/`, hits `_row_exists(tid) → True`, `continue`s (no re-replay, no promote). Dir is stranded until operator cleanup, matching the inline comment's claim. The comment at `bg_supervisor.py:1227-1232` correctly names this as "accepted — the row won't resurface for triage." Operator cleanup is the right remediation for a vanishingly rare window (crash in ~microseconds between two syscalls).
    7. [NOTE][Claude] Easy operability improvement deferred: `rebuild_from_manifests` at `bg_tasks_db.py:459-482` currently does NOT sweep `active/<tid>/` when `_row_exists(tid) → True` (the `continue` branch at line 466). Adding a `promote_active_to_completed(root, tid)` call in that branch would close the residual crash-window leak on next supervisor restart — for free, since the helper is already idempotent and bounded by `_is_trusted_task_dir`. Scope-legit to defer; noting as a future one-liner.
    8. [PASS][Claude] Test coverage on the three paths is adequate. (a) `test_reconcile_triage_manifest_applied_on_both_dead` exercises full dispatcher end-to-end through real `_triage_both_dead`; (b) reaper-path variant directly calls `_apply_manifest_to_running` rather than spawning the reaper thread — acceptable because the reaper worker (`bg_supervisor.py:1103-1104`) just calls this method, and thread-based testing would add flakiness without new coverage; (c) `noop_when_already_completed` pins the `manifest_subdir == "active"` guard. Existing `test_bg_tasks_db.py:775-780` covers the `rebuild_from_manifests` refactor path.
    9. [NOTE][Claude] Test coverage gap: `promote_active_to_completed` is not tested directly in `test_bg_tasks_db.py`. Three tiny unit tests would harden the contract: (a) missing `active/<tid>/` returns True (idempotent no-op); (b) `active/<tid>/` is a symlink → returns True without following; (c) `completed/<tid>/` already populated → `rename` OSError caught, returns False, warning logged. Current indirect coverage (through `rebuild_from_manifests` + `_apply_manifest_to_running` integration tests) hits path (a) transitively via idempotency, but (b) and (c) are exercised only through the refactored call site. Non-blocking; the helper is simple enough that indirect coverage is defensible.
   10. [PASS][Claude] Scope discipline clean. Diff is 11 + 25 + 79 = 115 lines, all tightly on the leak fix. No collateral refactors, no opportunistic cleanups bundled. The refactor (extracting `promote_active_to_completed`) is motivated by the new call site (supervisor path) needing the same logic as `rebuild_from_manifests`, with the symlink-check uplift being the one defensible scope-addition (required because the new call site lacks the `_is_trusted_task_dir` outer filter).
- verdict: APPROVED

Re-review: skip — one PASS refactor, one crash-window accepted per design, two NOTEs (test coverage gap #9, operability sweep #7) are non-blocking deferrable follow-ups. No CRITICAL/HIGH; diff < 30 lines of non-test code + straightforward extract-and-reuse refactor.

## Spec-Check

- result: PASS
- reviewer: code-reviewer
- basis: HEAD+staged (Commit B Finding #14 fix)
- timestamp: 2026-04-19
- notes: Focused bugfix closing Commit B Round 1 Finding #14 (slow `active/<tid>/` directory leak after `_apply_manifest_to_running` replays a wrapper-committed manifest). Scope-aligned with proposal.md WHAT (§6.3 triage path correctness, §6.6 archive coupling) and the recommendation in Commit B's own re-review note ("#14 is a slow resource-leak hazard addressable in a follow-up"). No NOT violations — stays within single-bridge-per-home premise, no multi-bridge coordination, no scope creep. Two non-blocking NOTEs in this round: (a) `promote_active_to_completed` lacks direct unit tests in `test_bg_tasks_db.py` (currently indirect-only via refactored call site); (b) `rebuild_from_manifests` could sweep `active/<tid>/` when `_row_exists(tid) → True` to close the residual crash-window leak on next supervisor restart. Neither blocks merge. 128/128 targeted tests pass. Codex cross-review skipped — acpx invocation blocked by session Bash approval gate (same sandbox-vs-acpx friction recorded in Commit A/B reviews); Claude-only per skill fallback.

Re-review: skip — APPROVED with two NOTE-level follow-up items; no CRITICAL/HIGH findings.
