import logging as _logging
import os

_FMT = '%(asctime)s  [%(levelname)s]  In %(name)s  %(message)s'
_DATEFMT = '%d-%b-%y %H:%M:%S'


class LoggerBase:
    def __init__(self, target: str = 'main') -> None:
        os.makedirs('log/', exist_ok=True)

        self._target = '[' + target.upper() + '] '
        self.logger = _logging.getLogger(target)

        if not self.logger.handlers:
            self.logger.setLevel(_logging.DEBUG)
            _formatter = _logging.Formatter(fmt=_FMT, datefmt=_DATEFMT)

            _fh = _logging.FileHandler(f'log/log_{target.upper()}.log',
                                       mode='a', encoding='utf-8')
            _fh.setFormatter(_formatter)

            _sh = _logging.StreamHandler()
            _sh.setFormatter(_formatter)

            self.logger.addHandler(_fh)
            self.logger.addHandler(_sh)

    def debug(self, msg, *args, **kwargs) -> None:
        self.logger.debug(self._target + msg, *args, **kwargs)

    def info(self, msg, *args, **kwargs) -> None:
        self.logger.info(self._target + msg, *args, **kwargs)

    def warn(self, msg, *args, **kwargs) -> None:
        self.logger.warning(self._target + msg, *args, **kwargs)

    def error(self, msg, *args, **kwargs) -> None:
        self.logger.error(self._target + msg, *args, **kwargs)

    def critical(self, msg, *args, **kwargs) -> None:
        self.logger.critical(self._target + msg, *args, **kwargs)

    def exception(self, msg, *args, **kwargs) -> None:
        self.logger.exception(self._target + msg, *args, **kwargs)


def disable_console_logging():
    for handler in _logging.root.handlers[:]:
        if isinstance(handler, _logging.StreamHandler):
            _logging.root.removeHandler(handler)
