from abc import ABC, abstractmethod


class GCSProgram(ABC):
    def __init__(self):
        self._started = False

    def start(self):
        if not self._started:
            self._start()
            self._started = True

    def stop(self):
        if not self._started:
            print(f'[WARNING] {self.__class__.__name__}.stop() called but program is not running.')
            return
        self._stop()
        self._started = False

    @abstractmethod
    def _start(self):
        pass

    @abstractmethod
    def _stop(self):
        pass

    def __del__(self):
        if self._started:
            self.stop()
