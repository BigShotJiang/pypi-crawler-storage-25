from __future__ import annotations

try:
    import polars as pl
    _HAS_POLARS = True
except ImportError:
    pl = None  # type: ignore[assignment]
    _HAS_POLARS = False

try:
    import pandas as pd
    _HAS_PANDAS = True
except ImportError:
    pd = None  # type: ignore[assignment]
    _HAS_PANDAS = False

if not _HAS_POLARS and not _HAS_PANDAS:
    raise ImportError('Data requires either polars or pandas to be installed.')

import numpy as np


class Data:
    """
    Backend-agnostic tabular data store.

    Uses Polars when available, falls back to Pandas.
    Internal storage is a plain list of rows; the DataFrame
    is rebuilt on demand and cached until the next mutation.
    """

    def __init__(self, headers: list[str]):
        self._headers = list(headers)
        self._dim = len(self._headers)
        self._rows: list[list] = []
        self._cache = None
        self._dirty = True

    # ------------------------------------------------------------------
    # Mutation
    # ------------------------------------------------------------------

    def push(self, row: list | tuple | np.ndarray) -> None:
        if len(row) != self._dim:
            return
        self._rows.append(list(row))
        self._dirty = True

    def pop(self, n: int = -1) -> dict | None:
        if not self._rows:
            return None
        n = max(0, min(n if n >= 0 else len(self._rows) + n, len(self._rows) - 1))
        row = self._rows.pop(n)
        self._dirty = True
        return dict(zip(self._headers, row))

    def pop_many(self, n: int) -> list[dict]:
        n = max(0, min(n, len(self._rows)))
        popped = self._rows[:n]
        self._rows = self._rows[n:]
        self._dirty = True
        return [dict(zip(self._headers, r)) for r in popped]

    def clear(self) -> None:
        self._rows = []
        self._dirty = True

    # ------------------------------------------------------------------
    # Read-only accessors (no cache needed — O(1) list access)
    # ------------------------------------------------------------------

    def front(self) -> dict | None:
        if not self._rows:
            return None
        return dict(zip(self._headers, self._rows[0]))

    def back(self) -> dict | None:
        if not self._rows:
            return None
        return dict(zip(self._headers, self._rows[-1]))

    def available(self) -> bool:
        return bool(self._rows)

    def copy(self) -> Data:
        new = Data(self._headers)
        new._rows = [r[:] for r in self._rows]
        return new

    # ------------------------------------------------------------------
    # DataFrame property (lazy, cached)
    # ------------------------------------------------------------------

    @property
    def df(self):
        if self._dirty:
            self._cache = self._build()
            self._dirty = False
        return self._cache

    def _build(self):
        if _HAS_POLARS:
            if not self._rows:
                return pl.DataFrame(schema={h: pl.Utf8 for h in self._headers})
            series = [
                pl.Series(h, [r[i] for r in self._rows], strict=False)
                for i, h in enumerate(self._headers)
            ]
            return pl.DataFrame(series)
        else:
            return pd.DataFrame(self._rows, columns=self._headers)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def headers(self) -> list[str]:
        return self._headers

    @property
    def dim(self) -> int:
        return self._dim

    @property
    def size(self) -> tuple[int, int]:
        return (len(self._rows), self._dim)

    @property
    def backend(self) -> str:
        return 'polars' if _HAS_POLARS else 'pandas'