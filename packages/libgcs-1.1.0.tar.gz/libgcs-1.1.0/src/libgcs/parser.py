from __future__ import annotations

import re


class StringParser:
    def __init__(self,
                 data_format: list[str],
                 delimiter: str,
                 header: str = '',
                 tail: str = ''):
        self._format = list(data_format)
        self._delimiter = delimiter
        self._header = header
        self._tail = tail
        self._blank: dict[str, None] = {k: None for k in self._format}
        self._re_collapse = re.compile(re.escape(delimiter) + '+')

    def parse(self, message: str) -> dict[str, int | float | str | None]:
        if self._header and not message.startswith(self._header):
            return dict(self._blank)

        body = message
        if self._header:
            body = body[len(self._header):]
        if self._tail and body.endswith(self._tail):
            body = body[:-len(self._tail)]

        body = self._re_collapse.sub(self._delimiter, body)
        parts = body.split(self._delimiter)

        result: dict[str, int | float | str | None] = {}
        for i, key in enumerate(self._format):
            raw = parts[i] if i < len(parts) else None
            result[key] = self._coerce(raw)
        return result

    @staticmethod
    def _coerce(value: str | None) -> int | float | str | None:
        if value is None or value == '':
            return None
        try:
            return int(value)
        except ValueError:
            pass
        if '.' in value:
            try:
                return float(value)
            except ValueError:
                pass
        return value


class BytesParser:
    def parse(self, data: bytes) -> dict:
        raise NotImplementedError('BytesParser.parse() is not implemented.')

    def unparse(self, fields: dict) -> bytes:
        raise NotImplementedError('BytesParser.unparse() is not implemented.')