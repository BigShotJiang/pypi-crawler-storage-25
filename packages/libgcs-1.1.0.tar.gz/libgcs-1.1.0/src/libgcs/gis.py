import math
from dataclasses import dataclass, field

_EARTH_RADIUS_M = 6_371_000.0


@dataclass(order=True, eq=True)
class GeoCoordinate:
    lat: float = field(default=0.0)
    lon: float = field(default=0.0)
    alt: float = field(default=0.0)

    def __post_init__(self):
        self.lat = self._coerce(self.lat)
        self.lon = self._coerce(self.lon)
        self.alt = self._coerce(self.alt)

    @staticmethod
    def _coerce(value) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0

    def valid(self) -> bool:
        return (1.0 <= abs(self.lat) <= 90.0) and (1.0 <= abs(self.lon) <= 180.0)

    def __str__(self) -> str:
        return f'GeoCoordinate(lat={self.lat}, lon={self.lon}, alt={self.alt})'

    def __repr__(self) -> str:
        return self.__str__()


class GeoPair:
    def __init__(self, home: GeoCoordinate, current: GeoCoordinate):
        self._home = home
        self._current = current
        self._ground = self._haversine()

    def _haversine(self) -> float:
        lat1 = math.radians(self._home.lat)
        lat2 = math.radians(self._current.lat)
        dlat = math.radians(self._current.lat - self._home.lat)
        dlon = math.radians(self._current.lon - self._home.lon)
        a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
        return _EARTH_RADIUS_M * 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))

    @property
    def ground_distance(self) -> float:
        return self._ground

    @property
    def line_of_sight(self) -> float:
        dalt = self._current.alt - self._home.alt
        return math.sqrt(self._ground ** 2 + dalt ** 2)

    @property
    def azimuth(self) -> float:
        lat1 = math.radians(self._home.lat)
        lat2 = math.radians(self._current.lat)
        dlon = math.radians(self._current.lon - self._home.lon)
        x = math.sin(dlon) * math.cos(lat2)
        y = math.cos(lat1) * math.sin(lat2) - math.sin(lat1) * math.cos(lat2) * math.cos(dlon)
        bearing = math.degrees(math.atan2(x, y))
        return (bearing + 360.0) % 360.0

    @property
    def elevation(self) -> float:
        dalt = self._current.alt - self._home.alt
        return math.degrees(math.atan2(dalt, self._ground))