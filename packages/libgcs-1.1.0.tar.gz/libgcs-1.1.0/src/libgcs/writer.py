from __future__ import annotations

import os
import time

from .file import FileUtil
from .gis import GeoCoordinate
from .queue import Queue
from ._base.threading import ThreadBase

# KML color palette: AABBGGRR (KML byte order), 8 colors cycling modulo 8
# Order: Yellow, Purple, Orange, Blue, Red, Green, Brown, White
_KML_COLORS = (
    'ff00ffff',  # Yellow
    'ffff00ff',  # Purple
    'ff0080ff',  # Orange
    'ffff0000',  # Blue
    'ff0000ff',  # Red
    'ff00ff00',  # Green
    'ff004080',  # Brown
    'ffffffff',  # White
)

_KML_LIVE_TEMPLATE = """\
<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2">
<NetworkLink>
  <Link>
    <href>{ref_path}</href>
    <refreshMode>onInterval</refreshMode>
    <refreshInterval>0.1</refreshInterval>
  </Link>
</NetworkLink>
</kml>
"""

_KML_TRACK_TEMPLATE = """\
<kml xmlns="http://www.opengis.net/kml/2.2" xmlns:gx="http://www.google.com/kml/ext/2.2">
<Folder>
  <name>Log</name>
  <Placemark>
    <name>Device Path Plotting</name>
    <Style>
      <LineStyle><color>{color}</color><width>3</width></LineStyle>
      <PolyStyle><color>99000000</color><fill>1</fill></PolyStyle>
    </Style>
    <LineString>
      <extrude>1</extrude>
      <gx:altitudeMode>absolute</gx:altitudeMode>
      <coordinates>
      </coordinates>
    </LineString>
  </Placemark>
</Folder>
</kml>
"""

# Number of lines from the end of the track KML that precede the coordinate block close tag.
# Structure (from bottom): </coordinates>, </LineString>, </Placemark>, </Folder>, </kml>
_KML_INSERT_LINE = -5


class FileWriter:
    def __init__(self,
                 base_name: str,
                 file_ext: str,
                 dev_idx: int,
                 color_idx: int | None = None):
        FileUtil.mkdir('data')

        color = _KML_COLORS[(dev_idx if color_idx is None else color_idx) % len(_KML_COLORS)]

        csv_raw = f'data/data_{base_name}_dev{dev_idx}.{file_ext}'
        self._csv_path = FileUtil.new_filename(csv_raw)

        save_raw = f'data/coord_save_{base_name}_dev{dev_idx}.kml'
        self._save_path = FileUtil.new_filename(save_raw)

        self._ref_path = f'data/coord_ref_dev{dev_idx}.kml'
        self._live_path = f'data/coord_live_dev{dev_idx}.kml'

        # Create (empty) CSV
        open(self._csv_path, 'w', encoding='utf-8').close()

        # Delete and recreate coord_ref each run
        if os.path.exists(self._ref_path):
            os.remove(self._ref_path)
        self._write_track_skeleton(self._ref_path, color)
        self._write_track_skeleton(self._save_path, color)

        # coord_live is written once if absent
        if not os.path.exists(self._live_path):
            abs_ref = os.path.abspath(self._ref_path)
            with open(self._live_path, 'w', encoding='utf-8') as f:
                f.write(_KML_LIVE_TEMPLATE.format(ref_path=abs_ref))

        # Track the insertion pointer for incremental KML updates
        self._ref_pos: int = 0
        self._save_pos: int = 0

    def append_csv(self, row: list) -> None:
        line = ','.join(str(v) for v in row) + '\n'
        with open(self._csv_path, 'a', encoding='utf-8') as f:
            f.write(line)

    def append_coord(self, coord: GeoCoordinate) -> None:
        if not coord.valid():
            return
        entry = f'        {coord.lon:.6f},{coord.lat:.6f},{coord.alt:.2f}'
        self._ref_pos = FileUtil.insert_at_line(
            self._ref_path, _KML_INSERT_LINE, entry, self._ref_pos
        )
        self._save_pos = FileUtil.insert_at_line(
            self._save_path, _KML_INSERT_LINE, entry, self._save_pos
        )

    @property
    def csv_path(self) -> str:
        return self._csv_path

    @property
    def ref_path(self) -> str:
        return self._ref_path

    @property
    def save_path(self) -> str:
        return self._save_path

    @property
    def live_path(self) -> str:
        return self._live_path

    @staticmethod
    def _write_track_skeleton(path: str, color: str) -> None:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(_KML_TRACK_TEMPLATE.format(color=color))


class ThreadFileWriter(ThreadBase):
    POLL_INTERVAL = 0.050

    def __init__(self,
                 file_writer: FileWriter,
                 queue_csv: Queue,
                 queue_coord: Queue,
                 timeout: float = 4.000):
        super().__init__('THREAD_FILE', timeout)
        self._writer = file_writer
        self._q_csv = queue_csv
        self._q_coord = queue_coord

    def _setup(self):
        pass

    def _loop(self):
        time.sleep(self.POLL_INTERVAL)
        self._flush_queues()

    def stop(self):
        self._on = False
        self._flush_queues()
        super().stop()

    def _flush_queues(self):
        while self._q_csv.available():
            row = self._q_csv.pop()
            if row is not None:
                self._writer.append_csv(row)
        while self._q_coord.available():
            coord = self._q_coord.pop()
            if coord is not None:
                self._writer.append_coord(coord)