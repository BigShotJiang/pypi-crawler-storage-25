---
name: project-libgcs
description: Purpose of libgcs and its relationship to VT-UGCS downstream app; what belongs in the library vs the app
metadata:
  type: project
---

libgcs is a Python library providing common/reusable GCS infrastructure. Its downstream consumer is VT-UGCS (vt-ugcs package), a Plotly Dash web-based ground control station for rocket/balloon telemetry.

**Why:** Any code that is not Dash/UI-specific and is shared across GCS applications belongs here.

**How to apply:** When adding features, keep them generic. UI callbacks, Dash layout, uplink command handling, and the `ProgramGUI` class all belong in vt-ugcs, not libgcs.

## Modules implemented as of 2026-05-25

- `queue.py` — `Queue` (deque wrapper, thread-safe via GIL)
- `serial_tools.py` — `SerialPort`, `SerialReader`, `SerialThread`, `ALL_BAUD`
- `file.py` — `FileUtil`, `File` ABC
- `gis.py` — `GeoCoordinate` (dataclass, valid(), coercion), `GeoPair` (haversine ground dist, LOS, azimuth, elevation)
- `data.py` — `Data` (pandas DataFrame wrapper: push/pop/pop_many/front/back/available/clear/copy)
- `parser.py` — `StringParser` (header/tail/delimiter/type-coercion), `BytesParser` stub
- `writer.py` — `FileWriter` (CSV + KML incremental writes), `ThreadFileWriter` (50 ms poll, flush on stop)
- `preference_tools.py` — `PreferenceTree` (JSON/TOML)
- `_base/` — `GCSProgram` ABC, `LoggerBase`, `ThreadBase`, exceptions

## Key known constraints

- `insert_at_line` in `FileUtil` uses `-5` from end of KML to find coordinate insertion point; depends on fixed KML skeleton line count.
- `StringParser` collapses consecutive delimiters before splitting — this shifts field alignment intentionally per FR-024.
- `GCSProgram.stop()` prints a WARNING to stdout (not logger) on double-stop.