# Memory Index

- [Project: libgcs purpose and downstream app](project_libgcs.md) — core library for VT-UGCS GCS; common reusable components only