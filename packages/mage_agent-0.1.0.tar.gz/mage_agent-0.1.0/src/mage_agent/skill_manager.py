from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mage_agent.core.http import MageApiClient


DEFAULT_CACHE_DIR = Path.home() / ".mage-agent" / "skills"


@dataclass
class SkillManager:
    """
    Handles base packaged skills and externally fetched full skills.
    """

    base_dir: Path
    cache_dir: Path = DEFAULT_CACHE_DIR

    def load_base_skills(self) -> dict[str, str]:
        return self._load_markdown_dir(self.base_dir)

    def load_cached_skills(self) -> dict[str, str]:
        return self._load_markdown_dir(self.cache_dir)

    def active_skills(self) -> dict[str, str]:
        # Cached full skills override base packaged defaults.
        skills = self.load_base_skills()
        skills.update(self.load_cached_skills())
        return skills

    def load(self, name: str) -> str:
        skills = self.active_skills()
        if name not in skills:
            raise KeyError(f"Skill not found: {name}")
        return skills[name]

    def fetch_and_cache(self, api: "MageApiClient") -> bool:
        """Fetch latest skills from the cluster and write them to cache_dir.

        Returns True if at least one skill was written. Fails gracefully —
        callers should warn the user but must not abort on failure.
        """
        try:
            manifest = api.get("/api/agent/skills")
            skills: dict = manifest.get("skills") or {}
            if not skills:
                return False
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            for name, content in skills.items():
                if isinstance(name, str) and isinstance(content, str):
                    (self.cache_dir / f"{name}.md").write_text(content)
            return True
        except Exception:
            return False

    def _load_markdown_dir(self, directory: Path) -> dict[str, str]:
        if not directory.exists() or not directory.is_dir():
            return {}
        result: dict[str, str] = {}
        for path in sorted(directory.glob("*.md")):
            result[path.stem] = path.read_text()
        return result
