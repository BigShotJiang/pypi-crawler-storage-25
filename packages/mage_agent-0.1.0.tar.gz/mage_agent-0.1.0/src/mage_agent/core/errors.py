class MageAgentError(Exception):
    """Base typed error for predictable MCP responses."""

    code = "INTERNAL_ERROR"

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message

    def to_dict(self) -> dict:
        return {"code": self.code, "message": self.message}


class ConfigError(MageAgentError):
    code = "CONFIG_INVALID"


class AuthRequiredError(MageAgentError):
    code = "AUTH_REQUIRED"


class AuthExpiredError(MageAgentError):
    code = "AUTH_EXPIRED"


class ApiError(MageAgentError):
    code = "API_ERROR"
