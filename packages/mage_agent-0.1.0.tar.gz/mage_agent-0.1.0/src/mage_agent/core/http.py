from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

import requests

from mage_agent.core.config import DEFAULT_API_KEY, AgentConfig
from mage_agent.core.errors import ApiError, AuthExpiredError

logger = logging.getLogger(__name__)


def _normalize_base_url(raw_url: str) -> str:
    url = raw_url.strip()
    if not url:
        return url
    if "://" not in url:
        if url.startswith("localhost") or url.startswith("127.0.0.1"):
            url = f"http://{url}"
        else:
            url = f"https://{url}"
    return url.rstrip("/")


class MageApiClient:
    def __init__(self, config: AgentConfig, timeout_seconds: int = 30):
        self._base_url = _normalize_base_url(config.effective_api_url)
        self._api_key = config.require_api_key()
        self._oauth_token = config.require_oauth_token()
        self._timeout_seconds = timeout_seconds

    def _headers(self) -> dict[str, str]:
        return {
            "Cookie": f"oauth_token={self._oauth_token}",
            "X-API-KEY": self._api_key,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    @property
    def api_key(self) -> str:
        return self._api_key

    def _request(self, method: str, path: str, json: dict | None = None) -> Any:
        url = f"{self._base_url}{path}"
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=self._headers(),
                json=json,
                timeout=self._timeout_seconds,
            )
        except requests.RequestException as exc:
            logger.error(
                "Mage API request failed method=%s url=%s payload=%s error=%s",
                method,
                url,
                json,
                exc,
            )
            raise ApiError(f"Request to Mage API failed: {exc}") from exc

        if response.status_code in (401, 403):
            logger.error(
                "Mage API auth failure method=%s url=%s status_code=%s payload=%s response=%s",
                method,
                url,
                response.status_code,
                json,
                response.text[:500],
            )
            raise AuthExpiredError(
                "Authentication expired or insufficient. Please run `mage-agent login`."
            )
        if response.status_code >= 400:
            detail = response.text[:500]
            logger.error(
                "Mage API error method=%s url=%s status_code=%s payload=%s response=%s",
                method,
                url,
                response.status_code,
                json,
                detail,
            )
            raise ApiError(f"Mage API error {response.status_code}: {detail}")

        if not response.content:
            return {}
        try:
            payload = response.json()
        except ValueError:
            return {"raw": response.text}
        if isinstance(payload, dict) and payload.get("error"):
            error = payload.get("error") or {}
            message = error.get("message") or "Unknown Mage API error."
            code = error.get("code")
            prefix = f"[{code}] " if code is not None else ""
            logger.error(
                "Mage API error method=%s url=%s status_code=%s payload=%s response=%s",
                method,
                url,
                response.status_code,
                json,
                response.text[:500],
            )
            raise ApiError(f"{prefix}{message}")
        return payload

    def get(self, path: str) -> Any:
        return self._request("GET", path)

    def post(self, path: str, payload: dict) -> Any:
        return self._request("POST", path, json=payload)

    def patch(self, path: str, payload: dict) -> Any:
        return self._request("PATCH", path, json=payload)

    def put(self, path: str, payload: dict) -> Any:
        return self._request("PUT", path, json=payload)

    def delete(self, path: str) -> Any:
        return self._request("DELETE", path)


@dataclass
class AuthResult:
    oauth_token: str


def authenticate_with_cluster(
    cluster_url: str,
    email: str,
    password: str,
    timeout_seconds: int = 30,
) -> AuthResult:
    """
    Authenticate against Mage cluster and return auth credentials.

    Supports common login endpoint variants for easier compatibility.
    """
    base = _normalize_base_url(cluster_url)
    session_path = "/api/sessions"
    payload = {
        "session": {
            "email": email,
            "password": password,
        }
    }
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-API-KEY": DEFAULT_API_KEY,
    }

    try:
        url = f"{base}{session_path}"
        response = requests.post(
            url=url,
            headers=headers,
            json=payload,
            timeout=timeout_seconds,
        )
    except requests.RequestException as exc:
        raise ApiError(f"Request to Mage API failed: {exc}") from exc

    if response.status_code >= 400:
        detail = response.text[:500]
        raise ApiError(f"Mage API error {response.status_code}: {detail}")

    try:
        body = response.json()
    except ValueError:
        body = {}

    if isinstance(body, dict) and body.get("error"):
        err = body.get("error") or {}
        message = err.get("message") or str(err)
        raise ApiError(message)

    token = body.get("session", {}).get("token")
    if token:
        return AuthResult(oauth_token=str(token))
    raise ApiError("No token returned by login endpoint.")
