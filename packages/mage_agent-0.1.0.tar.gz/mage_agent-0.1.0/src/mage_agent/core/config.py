from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from mage_agent.core.errors import AuthRequiredError, ConfigError

DEFAULT_CONFIG_PATH = Path.home() / ".mage-agent" / "config.json"
DEFAULT_API_KEY = "zkWlN0PkIKSN0C11CfUHUj84OT5XOJ6tDZ6bDRO2"


@dataclass
class AgentConfig:
    cluster_url: str | None = None
    api_key: str | None = None
    oauth_token: str | None = None

    @property
    def effective_api_url(self) -> str:
        url = self.cluster_url
        if not url:
            raise ConfigError("Missing `cluster_url` in config.")
        return url.rstrip("/")

    @classmethod
    def from_json(cls, payload: dict) -> "AgentConfig":
        cluster_url = payload.get("cluster_url")
        return cls(
            cluster_url=cluster_url,
            api_key=payload.get("api_key"),
            oauth_token=payload.get("oauth_token"),
        )

    def require_api_key(self) -> str:
        if self.api_key:
            return self.api_key
        if DEFAULT_API_KEY:
            return DEFAULT_API_KEY
        raise AuthRequiredError("Missing API key. Set config `api_key` or run `mage-agent login`.")

    def require_oauth_token(self) -> str:
        if not self.oauth_token:
            raise AuthRequiredError("Missing oauth token. Run `mage-agent login`.")
        return self.oauth_token


def load_config(path: Path | None = None) -> AgentConfig:
    cfg_path = path or DEFAULT_CONFIG_PATH
    if not cfg_path.exists():
        raise ConfigError(
            f"Config file not found at `{cfg_path}`. "
            "Create it or run `mage-agent login`."
        )
    try:
        data = json.loads(cfg_path.read_text())
    except json.JSONDecodeError as exc:
        raise ConfigError(f"Invalid JSON config: {exc}") from exc
    return AgentConfig.from_json(data)


def config_exists(path: Path | None = None) -> bool:
    cfg_path = path or DEFAULT_CONFIG_PATH
    return cfg_path.exists()


def save_config(config: AgentConfig, path: Path | None = None) -> Path:
    cfg_path = path or DEFAULT_CONFIG_PATH
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "cluster_url": config.cluster_url,
        "api_key": config.api_key,
        "oauth_token": config.oauth_token,
    }
    cfg_path.write_text(json.dumps(payload, indent=2) + "\n")
    cfg_path.chmod(0o600)  # owner read/write only; credentials must not be world-readable
    return cfg_path
