from mage_agent.mcp.server import McpServer


def run() -> None:
    McpServer().run_stdio()
