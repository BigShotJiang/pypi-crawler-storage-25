"""MCP runtime package."""
