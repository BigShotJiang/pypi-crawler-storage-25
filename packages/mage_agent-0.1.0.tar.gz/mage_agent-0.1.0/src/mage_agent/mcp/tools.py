from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from mage_agent.core.config import AgentConfig, load_config
from mage_agent.core.http import MageApiClient
from mage_agent.tools.blocks import BlockTools
from mage_agent.tools.executions import ExecutionTools
from mage_agent.tools.pipelines import PipelineTools
from mage_agent.tools.sync import SyncTools

ToolHandler = Callable[[dict[str, Any]], Any]


@dataclass
class ToolDef:
    name: str
    description: str
    input_schema: dict[str, Any]
    handler: ToolHandler


@dataclass
class SkillRuntime:
    config: AgentConfig

    @classmethod
    def from_config(cls) -> "SkillRuntime":
        return cls(config=load_config())

    def _api(self) -> MageApiClient:
        return MageApiClient(self.config)

    def pipelines(self) -> PipelineTools:
        return PipelineTools(self._api())

    def blocks(self) -> BlockTools:
        return BlockTools(self._api())

    def executions(self) -> ExecutionTools:
        return ExecutionTools(self._api())

    def sync(self) -> SyncTools:
        return SyncTools(self._api())


def build_tools() -> list[ToolDef]:
    return [
        ToolDef(
            name="pipeline_list",
            description="List pipelines. See skill://pipeline for guidance.",
            input_schema={
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .pipelines()
            .list_pipelines(),
        ),
        ToolDef(
            name="pipeline_get",
            description=(
                "Get one pipeline by UUID. "
                "See skill://pipeline for guidance."
            ),
            input_schema={
                "type": "object",
                "properties": {"uuid": {"type": "string"}},
                "required": ["uuid"],
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .pipelines()
            .get_pipeline(args["uuid"]),
        ),
        ToolDef(
            name="pipeline_create",
            description=(
                "Create a pipeline. "
                "See skill://pipeline for guidance."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "type": {
                        "type": "string",
                        "enum": ["python", "streaming", "integration"],
                    },
                    "payload": {"type": "object"},
                },
                "required": ["name"],
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .pipelines()
            .create_pipeline(
                args["name"],
                {
                    "type": args["type"],
                    **(args.get("payload") or {}),
                }
                if args.get("type")
                else args.get("payload"),
            ),
        ),
        ToolDef(
            name="pipeline_update",
            description=(
                "Update pipeline fields. "
                "See skill://pipeline for guidance."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "uuid": {"type": "string"},
                    "payload": {"type": "object"},
                },
                "required": ["uuid", "payload"],
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .pipelines()
            .update_pipeline(args["uuid"], args["payload"]),
        ),
        ToolDef(
            name="pipeline_delete",
            description=(
                "Delete a pipeline by UUID. "
                "See skill://pipeline for guidance."
            ),
            input_schema={
                "type": "object",
                "properties": {"uuid": {"type": "string"}},
                "required": ["uuid"],
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .pipelines()
            .delete_pipeline(args["uuid"]),
        ),
        ToolDef(
            name="block_list",
            description=(
                "List blocks for a pipeline. "
                "See skill://blocks for guidance."
            ),
            input_schema={
                "type": "object",
                "properties": {"pipeline_uuid": {"type": "string"}},
                "required": ["pipeline_uuid"],
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .blocks()
            .list_blocks(args["pipeline_uuid"]),
        ),
        ToolDef(
            name="block_get",
            description="Get block details. See skill://blocks for guidance.",
            input_schema={
                "type": "object",
                "properties": {
                    "pipeline_uuid": {"type": "string"},
                    "block_uuid": {"type": "string"},
                },
                "required": ["pipeline_uuid", "block_uuid"],
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config().blocks().get_block(
                args["pipeline_uuid"],
                args["block_uuid"],
            ),
        ),
        ToolDef(
            name="block_create",
            description="Create a block. See skill://blocks for guidance.",
            input_schema={
                "type": "object",
                "properties": {
                    "pipeline_uuid": {"type": "string"},
                    "name": {"type": "string"},
                    "type": {
                        "type": "string",
                        "enum": [
                            "callback",
                            "chart",
                            "conditional",
                            "custom",
                            "data_exporter",
                            "data_loader",
                            "dbt",
                            "extension",
                            "global_data_product",
                            "markdown",
                            "scratchpad",
                            "sensor",
                            "transformer",
                        ],
                    },
                    "language": {
                        "type": "string",
                        "enum": ["python", "sql", "r", "yaml", "markdown"],
                    },
                    "content": {"type": "string"},
                    "upstream_blocks": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "config": {"type": "object"},
                    "payload": {"type": "object"},
                },
                "required": ["pipeline_uuid", "name", "type"],
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .blocks()
            .create_block(
                pipeline_uuid=args["pipeline_uuid"],
                name=args["name"],
                block_type=args["type"],
                language=args.get("language", "python"),
                content=args.get("content"),
                upstream_blocks=args.get("upstream_blocks"),
                config=args.get("config"),
                payload=args.get("payload"),
            ),
        ),
        ToolDef(
            name="block_templates_list",
            description=(
                "List available block templates. "
                "See skill://blocks for guidance."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "force_refresh": {"type": "boolean"},
                },
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .blocks()
            .list_block_templates(force_refresh=args.get("force_refresh", False)),
        ),
        ToolDef(
            name="block_update",
            description=(
                "Update block fields. "
                "See skill://blocks for guidance."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "pipeline_uuid": {"type": "string"},
                    "block_uuid": {"type": "string"},
                    "payload": {"type": "object"},
                },
                "required": ["pipeline_uuid", "block_uuid", "payload"],
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .blocks()
            .update_block(
                args["pipeline_uuid"],
                args["block_uuid"],
                args["payload"],
            ),
        ),
        ToolDef(
            name="run_pipeline",
            description=(
                "Trigger a pipeline run. "
                "See skill://executions for guidance."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "pipeline_uuid": {"type": "string"},
                    "payload": {"type": "object"},
                },
                "required": ["pipeline_uuid"],
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .executions()
            .run_pipeline(
                args["pipeline_uuid"],
                args.get("payload"),
            ),
        ),
        ToolDef(
            name="run_logs",
            description=(
                "Fetch logs for a pipeline run. "
                "See skill://executions for guidance."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "pipeline_uuid": {"type": "string"},
                    "run_id": {"type": "string"},
                },
                "required": ["pipeline_uuid", "run_id"],
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .executions()
            .get_logs(
                args["pipeline_uuid"],
                args["run_id"],
            ),
        ),
        ToolDef(
            name="sync_project_to_local",
            description=(
                "Sync project source files to local disk. "
                "See skill://sync for guidance."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "local_project_dir": {"type": "string"},
                },
                "required": ["local_project_dir"],
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .sync()
            .sync_project_to_local(args["local_project_dir"]),
        ),
        ToolDef(
            name="sync_status",
            description=(
                "Compute remote/local sync status and conflicts. "
                "See skill://sync for guidance."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "local_project_dir": {"type": "string"},
                },
                "required": ["local_project_dir"],
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .sync()
            .sync_status(args["local_project_dir"]),
        ),
        ToolDef(
            name="sync_local_to_remote",
            description=(
                "Sync changed local source files to remote project. "
                "See skill://sync for guidance."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "local_project_dir": {"type": "string"},
                },
                "required": ["local_project_dir"],
                "additionalProperties": False,
            },
            handler=lambda args: SkillRuntime.from_config()
            .sync()
            .sync_local_to_remote(args["local_project_dir"]),
        ),
    ]
