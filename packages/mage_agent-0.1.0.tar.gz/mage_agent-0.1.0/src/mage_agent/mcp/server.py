from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from mage_agent.core.errors import MageAgentError
from mage_agent.mcp.tools import ToolDef, build_tools
from mage_agent.skill_manager import SkillManager


def _write(payload: dict[str, Any]) -> None:
    """
    MCP stdio transport: one JSON-RPC message per line (no embedded newlines).

    See: https://modelcontextprotocol.io/specification/2024-11-05/basic/transports
    """
    line = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    if "\n" in line or "\r" in line:
        raise ValueError("MCP stdio messages must not contain newline characters")
    sys.stdout.buffer.write((line + "\n").encode("utf-8"))
    sys.stdout.buffer.flush()


def _read_message() -> dict[str, Any] | None:
    while True:
        raw = sys.stdin.buffer.readline()
        if not raw:
            return None
        try:
            line = raw.decode("utf-8").strip()
        except UnicodeDecodeError:
            _write(_error(None, -32700, "Parse error"))
            continue
        if line:
            try:
                return json.loads(line)
            except json.JSONDecodeError:
                _write(_error(None, -32700, "Parse error"))
                continue


def _result(msg_id: Any, result: dict[str, Any]) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": msg_id, "result": result}


def _error(msg_id: Any, code: int, message: str) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": msg_id,
        "error": {"code": code, "message": message},
    }


def _negotiate_protocol_version(params: dict[str, Any]) -> str:
    """
    Prefer the client's requested revision when present so strict clients
    (e.g. Cursor) do not drop the connection after initialize.
    """
    requested = params.get("protocolVersion")
    if isinstance(requested, str) and requested.strip():
        return requested.strip()
    return "2024-11-05"


class McpServer:
    def __init__(self):
        self._tools = {tool.name: tool for tool in build_tools()}
        self._skill_manager = SkillManager(
            base_dir=Path(__file__).resolve().parent.parent / "skills"
        )
        self._resources = self._register_skill_resources()

    def run_stdio(self) -> None:
        while True:
            msg_id = None
            try:
                request = _read_message()
                if request is None:
                    return
                msg_id = request.get("id")
                method = request.get("method")
                params = request.get("params") or {}

                # JSON-RPC notifications omit "id"; never write a response.
                if "id" not in request:
                    if method in (
                        "notifications/initialized",
                        "initialized",
                    ):
                        continue
                    if method and str(method).startswith("notifications/"):
                        continue
                    continue

                if method == "initialize":
                    negotiated = _negotiate_protocol_version(params)
                    _write(
                        _result(
                            msg_id,
                            {
                                "protocolVersion": negotiated,
                                "capabilities": {
                                    "tools": {"listChanged": False},
                                    "resources": {
                                        "subscribe": False,
                                        "listChanged": False,
                                    },
                                },
                                "serverInfo": {
                                    "name": "mage-agent",
                                    "version": "0.1.0",
                                },
                                "instructions": (
                                    "Before performing any Mage operation, read the "
                                    "relevant skill resource for guidance: "
                                    "skill://pipeline for pipeline operations, "
                                    "skill://blocks for block operations, "
                                    "skill://executions for execution operations, "
                                    "and skill://sync for sync guidance."
                                ),
                            },
                        )
                    )
                    continue

                if method == "ping":
                    _write(_result(msg_id, {}))
                    continue

                if method == "tools/list":
                    _write(_result(msg_id, {"tools": self._list_tools()}))
                    continue

                if method == "tools/call":
                    tool_name = params.get("name")
                    arguments = params.get("arguments") or {}
                    _write(_result(msg_id, self._call_tool(tool_name, arguments)))
                    continue

                if method == "resources/list":
                    _write(_result(msg_id, {"resources": self._list_resources()}))
                    continue

                if method == "resources/read":
                    uri = params.get("uri")
                    _write(_result(msg_id, self._read_resource(uri)))
                    continue

                _write(
                    _error(
                        msg_id,
                        -32601,
                        f"Method not found: {method}",
                    )
                )
            except MageAgentError as exc:
                _write(
                    _error(
                        msg_id,
                        -32603,
                        f"{exc.code}: {exc.message}",
                    )
                )
            except Exception as exc:
                _write(_error(msg_id, -32603, str(exc)))

    def _list_tools(self) -> list[dict[str, Any]]:
        return [
            {
                "name": tool.name,
                "description": tool.description,
                "inputSchema": tool.input_schema,
            }
            for tool in self._tools.values()
        ]

    def _register_skill_resources(self) -> dict[str, dict[str, str]]:
        resources: dict[str, dict[str, str]] = {}
        for name in ("pipeline", "blocks", "executions", "sync"):
            uri = f"skill://{name}"
            resources[uri] = {
                "uri": uri,
                "name": name,
                "description": f"Guidance for {name} operations.",
                "mimeType": "text/markdown",
            }
        return resources

    def _list_resources(self) -> list[dict[str, str]]:
        return [self._resources[uri] for uri in sorted(self._resources.keys())]

    def _read_resource(self, uri: str | None) -> dict[str, Any]:
        if not uri or uri not in self._resources:
            return {
                "contents": [
                    {
                        "uri": uri or "",
                        "mimeType": "text/plain",
                        "text": "Resource not found.",
                    }
                ]
            }
        name = uri.replace("skill://", "", 1)
        try:
            content = self._skill_manager.load(name)
        except KeyError:
            content = f"# {name}\n\nNo skill content available."
        return {
            "contents": [
                {
                    "uri": uri,
                    "mimeType": "text/markdown",
                    "text": content,
                }
            ]
        }

    def _call_tool(self, tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        if tool_name not in self._tools:
            return {
                "isError": True,
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps(
                            {
                                "status": "error",
                                "error": {
                                    "code": "TOOL_NOT_FOUND",
                                    "message": f"Unknown tool: {tool_name}",
                                },
                            }
                        ),
                    }
                ],
            }

        tool: ToolDef = self._tools[tool_name]
        try:
            payload = tool.handler(arguments)
        except MageAgentError as exc:
            return {
                "isError": True,
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps(
                            {"status": "error", "error": exc.to_dict()}
                        ),
                    }
                ],
            }
        except Exception as exc:
            return {
                "isError": True,
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps(
                            {
                                "status": "error",
                                "error": {
                                    "code": "INTERNAL_ERROR",
                                    "message": str(exc),
                                },
                            }
                        ),
                    }
                ],
            }
        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps({"status": "ok", "data": payload}),
                }
            ],
            "isError": False,
        }
