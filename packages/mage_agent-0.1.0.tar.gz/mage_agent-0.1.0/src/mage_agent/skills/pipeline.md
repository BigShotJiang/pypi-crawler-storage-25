# Pipeline Skills

Use pipeline tools for listing, creating, updating, and deleting pipelines.

- Prefer `pipeline_list` before mutating operations.
- For create requests, send payload as `{"pipeline": {"name": "<name>", "type": "python"}}`.
- Set pipeline type explicitly when needed: `python`, `streaming`, or `integration`.
- Validate target pipeline UUID before update or delete.
- Return concise summaries with pipeline names and identifiers.

