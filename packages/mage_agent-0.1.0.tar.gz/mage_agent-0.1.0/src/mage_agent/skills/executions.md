# Execution Skills

Use execution tools to run pipelines and fetch logs.

- Use `run_pipeline` for execution triggers.
- Use `run_logs` for troubleshooting.
- Include run identifiers in summaries for traceability.

