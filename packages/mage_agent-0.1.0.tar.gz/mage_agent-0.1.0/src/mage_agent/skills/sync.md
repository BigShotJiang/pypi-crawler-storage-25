# Sync Skills

Use sync guidance when local and remote state diverge.

- `sync_project_to_local` syncs project files from remote repo path to local disk.
- `sync_status` compares remote and local with sync state and reports conflicts.
- `sync_local_to_remote` pushes local-only changes when there are no conflicts.
- Include only source files: `.py`, `.sql`, `.r`, `.yaml`, `.yml`, `.md`, `.txt`.
- Ignore hidden directories and hidden files during sync.
- Prefer explicit `push` or `pull` instructions based on source-of-truth mode.
- Surface conflicts and required user actions.
- Avoid destructive synchronization without user confirmation.

