# Block Skills

Use block tools to inspect and edit blocks within a pipeline.

- Use `block_create` to add new blocks with required fields (`name`, `type`, `language`).
- Use `block_templates_list` to inspect available templates before creating blocks.
- Include `upstream_blocks` (list of block UUIDs) when creating dependent blocks.
- If creating from a template, include template settings in `config`.
- Confirm `pipeline_uuid` and `block_uuid` before update operations.
- Preserve existing block metadata when only partial edits are needed.
- Explain changed fields clearly in responses.

