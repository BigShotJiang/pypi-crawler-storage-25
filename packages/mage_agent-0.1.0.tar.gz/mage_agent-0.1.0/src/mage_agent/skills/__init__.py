"""Bundled markdown skill files for fallback/testing."""
