from mage_agent.cli.main import main

if __name__ == "__main__":
    main()
