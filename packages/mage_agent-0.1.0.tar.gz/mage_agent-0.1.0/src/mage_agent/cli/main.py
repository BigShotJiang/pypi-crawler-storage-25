from __future__ import annotations

import argparse
import getpass
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any

from mage_agent.core.config import (AgentConfig, config_exists, load_config,
                                    save_config)
from mage_agent.core.errors import ApiError, ConfigError
from mage_agent.core.http import MageApiClient, authenticate_with_cluster
from mage_agent.mcp.main import run as run_mcp
from mage_agent.skill_manager import SkillManager
from mage_agent.tools.sync import SyncTools

SYNC_CHOICES_MAP = {"r": "remote", "l": "local", "s": "skip"}


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="mage-agent")
    shared_parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument(
        "--log-level",
        default=os.getenv("MAGE_AGENT_LOG_LEVEL", "INFO"),
        help="Logging level (DEBUG, INFO, WARNING, ERROR).",
    )
    shared_parser.add_argument(
        "--format-output",
        choices=["json", "human"],
        default="json",
        help="Output format for CLI responses.",
    )
    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser(
        "mcp",
        parents=[shared_parser],
        help="Start MCP server over stdio.",
    )
    login_parser = subparsers.add_parser(
        "login",
        parents=[shared_parser],
        help="Configure local Mage credentials.",
    )
    login_parser.add_argument("--cluster-url", help="Mage Pro cluster URL.")
    login_parser.add_argument("--email", help="Email for cluster authentication.")
    login_parser.add_argument("--password", help="Password for cluster authentication.")
    login_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing config without confirmation.",
    )
    sync_parser = subparsers.add_parser(
        "sync-project-to-local",
        parents=[shared_parser],
        help="Sync project source files to local disk.",
    )
    sync_parser.add_argument(
        "--local-project-dir",
        help="Local project directory for synced files.",
    )
    sync_status_parser = subparsers.add_parser(
        "sync-status",
        parents=[shared_parser],
        help="Show remote/local sync status and conflicts.",
    )
    sync_status_parser.add_argument(
        "--local-project-dir",
        help="Local project directory used for sync state.",
    )
    sync_push_parser = subparsers.add_parser(
        "sync-local-to-remote",
        parents=[shared_parser],
        help="Sync changed local files to remote project.",
    )
    sync_push_parser.add_argument(
        "--local-project-dir",
        help="Local project directory used for sync state.",
    )
    sync_parser2 = subparsers.add_parser(
        "sync",
        parents=[shared_parser],
        help="Run bidirectional sync with conflict prompts.",
    )
    sync_parser2.add_argument(
        "--local-project-dir",
        help="Local project directory used for sync state.",
    )

    args = parser.parse_args(argv)
    _configure_logging(args.log_level)

    try:
        if args.command == "mcp":
            run_mcp()
            return
        if args.command == "login":
            _run_login(args)
            return
        if args.command == "sync-project-to-local":
            _run_sync_project_to_local(args)
            return
        if args.command == "sync-status":
            _run_sync_status(args)
            return
        if args.command == "sync-local-to-remote":
            _run_sync_local_to_remote(args)
            return
        if args.command == "sync":
            _run_sync(args)
            return
    except (ConfigError, ApiError) as exc:
        _emit_error(args.format_output, exc.code, exc.message)
        raise SystemExit(1) from exc

    parser.print_help()


def _configure_logging(level_name: str) -> None:
    level = getattr(logging, str(level_name).upper(), logging.INFO)
    root_logger = logging.getLogger()
    if not root_logger.handlers:
        logging.basicConfig(
            level=level,
            format="%(asctime)s %(levelname)s %(name)s - %(message)s",
        )
    else:
        root_logger.setLevel(level)


def _prompt(field: str, default: str | None = None, secret: bool = False) -> str:
    suffix = f" [{default}]" if default else ""
    prompt_text = f"{field}{suffix}: "
    raw = getpass.getpass(prompt_text) if secret else input(prompt_text)
    value = raw.strip()
    return value or (default or "")


def _emit_success(
    output_format: str,
    *,
    data: Any | None = None,
    message: str | None = None,
) -> None:
    if output_format == "human":
        if message:
            sys.stdout.write(f"{message}\n")
        if data is not None:
            if isinstance(data, (dict, list)):
                sys.stdout.write(json.dumps(data, indent=2) + "\n")
            else:
                sys.stdout.write(f"{data}\n")
        return

    payload: dict[str, Any] = {"status": "ok"}
    if message is not None:
        payload["message"] = message
    if data is not None:
        payload["data"] = data
    sys.stdout.write(json.dumps(payload) + "\n")


def _emit_error(output_format: str, code: str, message: str) -> None:
    if output_format == "human":
        sys.stderr.write(f"Error [{code}]: {message}\n")
        return
    sys.stderr.write(
        json.dumps(
            {
                "status": "error",
                "error": {"code": code, "message": message},
            }
        )
        + "\n"
    )


def _run_login(args: argparse.Namespace) -> None:
    if config_exists() and not args.force:
        overwrite = _prompt("Config exists. Overwrite? (y/N)", default="N")
        if overwrite.lower() not in {"y", "yes"}:
            sys.stderr.write("Login cancelled. Existing config kept.\n")
            return

    cluster_url = (args.cluster_url or "").strip() or None
    email = (args.email or "").strip() or None
    password = (args.password or "").strip() or None

    if not cluster_url:
        cluster_url = _prompt("Cluster URL (required)", default="")
        cluster_url = cluster_url or None

    # Login must authenticate with cluster using email/password.
    if not cluster_url:
        raise ConfigError("`--cluster-url` is required for login authentication.")
    if not email:
        email = _prompt("Email", default="") or None
    if not password:
        password = _prompt("Password", secret=True) or None

    if not email or not password:
        raise ConfigError("Email and password are required.")

    auth = authenticate_with_cluster(
        cluster_url,
        email,
        password,
    )

    config = AgentConfig(
        cluster_url=cluster_url,
        oauth_token=auth.oauth_token,
    )
    path = save_config(config)

    skill_manager = SkillManager(
        base_dir=Path(__file__).resolve().parent.parent / "skills"
    )
    try:
        api = MageApiClient(config)
        fetched = skill_manager.fetch_and_cache(api)
    except Exception:
        fetched = False
    if not fetched:
        warning = (
            "Could not fetch remote skills; built-in fallback skills will be used."
        )
        if args.format_output == "human":
            sys.stderr.write(f"Warning: {warning}\n")
        else:
            sys.stderr.write(
                json.dumps({"status": "warning", "message": warning}) + "\n"
            )

    _emit_success(
        args.format_output,
        message="Authenticated and credentials saved.",
        data={"config_path": str(path)},
    )


def _run_sync_project_to_local(args: argparse.Namespace) -> None:
    local_project_dir = _require_local_project_dir(args)
    sync_tools = _build_sync_tools()
    result = sync_tools.sync_project_to_local(
        local_project_dir=local_project_dir
    )
    _emit_success(args.format_output, data=result)


def _run_sync_status(args: argparse.Namespace) -> None:
    local_project_dir = _require_local_project_dir(args)
    sync_tools = _build_sync_tools()
    result = sync_tools.sync_status(local_project_dir=local_project_dir)
    _emit_success(args.format_output, data=result)


def _run_sync_local_to_remote(args: argparse.Namespace) -> None:
    local_project_dir = _require_local_project_dir(args)
    sync_tools = _build_sync_tools()
    result = sync_tools.sync_local_to_remote(local_project_dir=local_project_dir)
    _emit_success(args.format_output, data=result)


def _run_sync(args: argparse.Namespace) -> None:
    local_project_dir = _require_local_project_dir(args)
    sync_tools = _build_sync_tools()
    context = sync_tools.build_sync_context(local_project_dir=local_project_dir)
    status = sync_tools.sync_status(local_project_dir=local_project_dir, context=context)
    conflicts = status.get("conflicts")
    conflict_resolutions: dict[str, str] = {}
    if isinstance(conflicts, list):
        for path in conflicts:
            if not isinstance(path, str):
                continue
            choice = _prompt(
                f"Conflict for {path}. Choose version [remote(r)/local(l)/skip(s)]",
                default="skip",
            ).strip().lower()
            if choice in {'r', 'l', 's'}:
                choice = SYNC_CHOICES_MAP.get(choice)
            if choice not in {"remote", "local", "skip"}:
                choice = "skip"
            conflict_resolutions[path] = choice

    result = sync_tools.sync_bidirectional(
        local_project_dir=local_project_dir,
        conflict_resolutions=conflict_resolutions,
        context=context,
    )
    _emit_success(args.format_output, data=result)


def _require_local_project_dir(args: argparse.Namespace) -> str:
    local_project_dir = (args.local_project_dir or "").strip() or None
    if not local_project_dir:
        local_project_dir = _prompt(
            "Local project directory",
            default=".mage-agent/local_sync",
        )
    if not local_project_dir:
        raise ConfigError("Local project directory is required.")
    return local_project_dir


def _build_sync_tools() -> SyncTools:
    config = load_config()
    api = MageApiClient(config)
    return SyncTools(api)
