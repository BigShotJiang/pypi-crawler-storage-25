"""Mage Agent package."""
