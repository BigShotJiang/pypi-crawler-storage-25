"""Python tool wrappers for Mage Pro API."""
