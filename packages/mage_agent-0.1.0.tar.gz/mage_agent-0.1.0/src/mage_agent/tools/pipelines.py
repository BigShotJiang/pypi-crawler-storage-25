from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from mage_agent.core.http import MageApiClient


@dataclass
class PipelineTools:
    api: MageApiClient

    def list_pipelines(self) -> Any:
        return self.api.get("/api/pipelines")

    def get_pipeline(self, uuid: str) -> Any:
        return self.api.get(f"/api/pipelines/{uuid}")

    def create_pipeline(self, name: str, payload: dict | None = None) -> Any:
        pipeline_payload: dict[str, Any] = {"name": name, "type": "python"}
        if payload:
            nested_pipeline = payload.get("pipeline")
            if isinstance(nested_pipeline, dict):
                pipeline_payload.update(nested_pipeline)
            else:
                pipeline_payload.update(payload)
        body = {"pipeline": pipeline_payload}
        return self.api.post("/api/pipelines", body)

    def update_pipeline(self, uuid: str, payload: dict) -> Any:
        return self.api.patch(f"/api/pipelines/{uuid}", payload)

    def delete_pipeline(self, uuid: str) -> Any:
        return self.api.delete(f"/api/pipelines/{uuid}")
