from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from mage_agent.core.http import MageApiClient

DEFAULT_BLOCK_TEMPLATES_CACHE_PATH = (
    Path.home() / ".mage-agent" / "cache" / "block_templates.json"
)
logger = logging.getLogger(__name__)


@dataclass
class BlockTools:
    api: MageApiClient

    def list_blocks(self, pipeline_uuid: str) -> Any:
        return self.api.get(f"/api/pipelines/{pipeline_uuid}/blocks")

    def create_block(
        self,
        pipeline_uuid: str,
        name: str,
        block_type: str,
        language: str = "python",
        content: str | None = None,
        upstream_blocks: list[str] | None = None,
        config: dict | None = None,
        payload: dict | None = None,
    ) -> Any:
        body: dict[str, Any] = {
            "name": name,
            "type": block_type,
            "language": language,
        }
        if content is not None:
            body["content"] = content
        if upstream_blocks is not None:
            body["upstream_blocks"] = upstream_blocks
        if config is not None:
            body["config"] = config
        if payload:
            nested = (
                payload.get("block")
                if isinstance(payload.get("block"), dict)
                else {}
            )
            if isinstance(nested, dict):
                body.update(nested)
            body.update({k: v for k, v in payload.items() if k != "block"})

        # If caller didn't provide config, infer a block template path.
        if "config" not in body or not isinstance(body["config"], dict):
            template_path = self._select_template_path(
                block_type=body.get("type"),
                language=body.get("language"),
            )
            if template_path:
                body["config"] = {"template_path": template_path}
            else:
                logger.warning(
                    "No matching block template found for block_type=%s language=%s",
                    body.get("type"),
                    body.get("language"),
                )

        return self.api.post(
            f"/api/pipelines/{pipeline_uuid}/blocks",
            {"block": body},
        )

    def get_block(self, pipeline_uuid: str, block_uuid: str) -> Any:
        return self.api.get(
            f"/api/pipelines/{pipeline_uuid}/blocks/{block_uuid}"
        )

    def update_block(
        self,
        pipeline_uuid: str,
        block_uuid: str,
        payload: dict,
    ) -> Any:
        content = payload.get("content")
        if content is None and isinstance(payload.get("block"), dict):
            content = payload["block"].get("content")
        block_payload = dict(uuid=block_uuid)
        if content is None:
            block_payload.update(payload)
        else:
            block_payload['content'] = content

        return self.api.post(
            "/api/pipeline_execution_frameworks/"
            f"{pipeline_uuid}/blocks",
            {"block": block_payload},
        )

    def list_block_templates(self, force_refresh: bool = False) -> list[dict[str, Any]]:
        cache_path = DEFAULT_BLOCK_TEMPLATES_CACHE_PATH
        cached = self._load_templates_from_cache(cache_path)
        if not force_refresh and cached is not None:
            return cached

        response = self.api.get("/api/block_templates?show_all=true")
        templates = self._extract_templates(response)
        self._write_templates_cache(cache_path, templates)
        return templates

    def _select_template_path(
        self,
        block_type: str | None,
        language: str | None,
    ) -> str | None:
        templates = self.list_block_templates()
        normalized_type = (block_type or "").lower()
        normalized_lang = (language or "").lower()

        # First pass: strict type + language match.
        for template in templates:
            t_type = str(
                template.get("type")
                or template.get("block_type")
                or template.get("template_type")
                or ""
            ).lower()
            t_lang = str(template.get("language") or "").lower()
            t_path = str(
                template.get("template_path") or template.get("path") or ""
            )
            if t_type == normalized_type and (
                not normalized_lang or t_lang == normalized_lang
            ):
                return t_path or None

        # Second pass: infer by template_path directory naming convention.
        for template in templates:
            t_path = str(
                template.get("template_path") or template.get("path") or ""
            )
            if normalized_type and normalized_type in t_path:
                return t_path
            if normalized_lang and f".{normalized_lang}" in t_path:
                return t_path
        return None

    def _load_templates_from_cache(
        self,
        cache_path: Path,
    ) -> list[dict[str, Any]] | None:
        if not cache_path.exists():
            return None
        try:
            payload = json.loads(cache_path.read_text())
        except (OSError, ValueError):
            return None

        fetched_at = payload.get("fetched_at")
        templates = payload.get("templates")
        if not isinstance(templates, list):
            return None
        if not isinstance(fetched_at, str):
            return None

        try:
            fetched_dt = datetime.fromisoformat(fetched_at)
        except ValueError:
            return None
        now = datetime.now(timezone.utc)
        if fetched_dt.date() != now.date():
            return None
        return [x for x in templates if isinstance(x, dict)]

    def _write_templates_cache(
        self,
        cache_path: Path,
        templates: list[dict[str, Any]],
    ) -> None:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "fetched_at": datetime.now(timezone.utc).isoformat(),
            "templates": templates,
        }
        cache_path.write_text(json.dumps(payload, indent=2) + "\n")

    def _extract_templates(self, response: Any) -> list[dict[str, Any]]:
        if isinstance(response, dict):
            for key in ("block_templates", "templates", "data", "items"):
                value = response.get(key)
                if isinstance(value, list):
                    return [x for x in value if isinstance(x, dict)]
        if isinstance(response, list):
            return [x for x in response if isinstance(x, dict)]
        return []
