from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from mage_agent.core.http import MageApiClient


@dataclass
class ExecutionTools:
    api: MageApiClient

    def run_pipeline(self, pipeline_uuid: str, payload: dict | None = None) -> Any:
        body = payload or {}
        return self.api.post(f"/api/pipelines/{pipeline_uuid}/runs", body)

    def get_logs(self, pipeline_uuid: str, run_id: str) -> Any:
        return self.api.get(f"/api/pipelines/{pipeline_uuid}/runs/{run_id}/logs")
