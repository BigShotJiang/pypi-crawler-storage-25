from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from mage_agent.core.http import MageApiClient

ALLOWED_SUFFIXES = {".py", ".sql", ".r", ".yaml", ".yml", ".md", ".txt"}
SYNC_STATE_FILE = ".mage-agent-sync-state.json"
logger = logging.getLogger(__name__)


@dataclass
class SyncTools:
    api: MageApiClient
    BROWSER_FOLDERS_BATCH_SIZE = 20

    def _browser_items_request(
        self,
        folders: list[str] | None = None,
        path: str | None = None,
        operation: str | None = None,
        browser_item_extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        browser_item: dict[str, Any] = {}
        if folders:
            browser_item["folders"] = folders
        if path:
            if operation == "create":
                browser_item["path"] = path
            else:
                browser_item["_pk"] = path
        if isinstance(browser_item_extra, dict):
            browser_item.update(browser_item_extra)
        payload = {
            "browser_item": browser_item,
            "api_key": self.api.api_key,
        }
        logger.debug(
            "Requesting browser items folders=%s path=%s",
            folders,
            path,
        )
        endpoint = "/api/browser_items"
        if operation and operation != "create":
            endpoint = f"{endpoint}?_operation={operation}"
        result = self.api.post(endpoint, payload)
        return result if isinstance(result, dict) else {}

    def _repo_path(self) -> str | None:
        status = self.api.get("/api/status")
        if not isinstance(status, dict):
            return None
        statuses = status.get("statuses")
        if not isinstance(statuses, list) or not statuses:
            return None
        first = statuses[0]
        if not isinstance(first, dict):
            return None
        value = first.get("repo_path") or first.get("repo_path_root")
        if not isinstance(value, str):
            return None
        value = value.strip()
        return value or None

    def _is_hidden(self, relative_path: str) -> bool:
        parts = Path(relative_path).parts
        return any(
            part.startswith(".") or part == "__pycache__"
            for part in parts
            if part not in {"", "."}
        )

    def _now_iso(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def _state_path(self, root: Path) -> Path:
        return root / SYNC_STATE_FILE

    def _load_state(self, root: Path) -> dict[str, Any]:
        path = self._state_path(root)
        if not path.exists():
            return {"version": 1, "repo_path": None, "last_sync_at": None, "files": {}}
        try:
            payload = json.loads(path.read_text())
        except (OSError, ValueError):
            return {"version": 1, "repo_path": None, "last_sync_at": None, "files": {}}
        if not isinstance(payload, dict):
            return {"version": 1, "repo_path": None, "last_sync_at": None, "files": {}}
        files = payload.get("files")
        if not isinstance(files, dict):
            payload["files"] = {}
        payload.setdefault("version", 1)
        payload.setdefault("repo_path", None)
        payload.setdefault("last_sync_at", None)
        return payload

    def _save_state(self, root: Path, state: dict[str, Any]) -> None:
        path = self._state_path(root)
        temp = path.with_suffix(".tmp")
        payload = dict(state)
        payload["last_sync_at"] = self._now_iso()
        temp.write_text(json.dumps(payload, indent=2) + "\n")
        temp.replace(path)

    def _file_content(self, full_path: str) -> str:
        detail = self._browser_items_request(
            path=full_path,
            operation="detail",
        )
        logger.info("Fetch file content for %s", full_path)
        browser_item = detail.get("browser_item")
        if not isinstance(browser_item, dict):
            return ""
        content = browser_item.get("content")
        return content if isinstance(content, str) else ""

    def _collect_local_files(self, root: Path) -> tuple[dict[str, str], dict[str, int | None]]:
        files: dict[str, str] = {}
        modified: dict[str, int | None] = {}
        for candidate in root.rglob("*"):
            if not candidate.is_file():
                continue
            if candidate.name == SYNC_STATE_FILE:
                continue
            relative = str(candidate.relative_to(root)).replace("\\", "/")
            if self._is_hidden(relative):
                continue
            if candidate.suffix.lower() not in ALLOWED_SUFFIXES:
                continue
            try:
                files[relative] = candidate.read_text()
                modified[relative] = int(candidate.stat().st_mtime)
            except (OSError, UnicodeDecodeError):
                continue
        return files, modified

    def _detect_changes(
        self,
        remote_paths: set[str],
        remote_modified: dict[str, int | None],
        local_files: dict[str, str],
        local_modified: dict[str, int | None],
        state: dict[str, Any],
    ) -> dict[str, list[str]]:
        tracked = state.get("files")
        tracked = tracked if isinstance(tracked, dict) else {}
        all_paths = sorted(remote_paths | set(local_files.keys()) | set(tracked.keys()))
        result = {
            "remote_to_local": [],
            "local_to_remote": [],
            "conflicts": [],
            "in_sync": [],
        }
        for path in all_paths:
            prev = tracked.get(path) if isinstance(tracked.get(path), dict) else {}
            prev_remote_modified = prev.get("last_synced_remote_modified_timestamp")
            prev_local_modified = prev.get("last_synced_local_modified_timestamp")
            remote_exists = path in remote_paths
            local_exists = path in local_files
            # If a tracked file no longer exists on either side, treat it as in sync.
            # Both sides converged on deletion, so this is not a conflict.
            if not remote_exists and not local_exists:
                result["in_sync"].append(path)
                continue
            remote_ts = remote_modified.get(path)
            local_ts = local_modified.get(path)
            remote_changed = remote_ts != prev_remote_modified
            local_changed = local_ts != prev_local_modified

            if not remote_changed and not local_changed:
                result["in_sync"].append(path)
            elif remote_changed and local_changed:
                result["conflicts"].append(path)
            elif remote_changed:
                result["remote_to_local"].append(path)
            elif local_changed:
                result["local_to_remote"].append(path)
            else:
                result["in_sync"].append(path)
        return result

    def _sync_remote_file_map(
        self,
        repo_path: str,
    ) -> tuple[set[str], dict[str, int | None], dict[str, int]]:
        flat = self._list_project_items(repo_path)
        logger.info("Scanned remote project tree entries=%s", len(flat))
        remote_paths: set[str] = set()
        remote_modified: dict[str, int | None] = {}
        stats = {
            "files_scanned": 0,
            "files_skipped_outside_repo": 0,
            "files_skipped_hidden": 0,
            "files_skipped_extension": 0,
        }

        for item in flat:
            if bool(item.get("folder")):
                continue
            full_path = str(item.get("path") or "").strip()
            if not full_path:
                continue
            stats["files_scanned"] += 1
            if not self._is_within_repo_path(full_path, repo_path):
                stats["files_skipped_outside_repo"] += 1
                logger.info("Skipping path outside repo_path: %s", full_path)
                continue

            relative_path = self._relative_repo_path(full_path, repo_path)
            if not relative_path:
                continue
            if self._is_hidden(relative_path):
                stats["files_skipped_hidden"] += 1
                logger.info("Skipping hidden path: %s", relative_path)
                continue

            suffix = Path(relative_path).suffix.lower()
            if suffix not in ALLOWED_SUFFIXES:
                stats["files_skipped_extension"] += 1
                logger.info("Skipping unsupported extension path: %s", relative_path)
                continue

            remote_paths.add(relative_path)
            modified = item.get("modified_timestamp")
            remote_modified[relative_path] = modified if isinstance(modified, int) else None
        return remote_paths, remote_modified, stats

    def _remote_path(self, repo_path: str, relative_path: str) -> str:
        return f"{repo_path.rstrip('/')}/{relative_path.lstrip('/')}"

    def _is_within_repo_path(self, path: str, repo_path: str) -> bool:
        repo_root = repo_path.rstrip("/")
        return bool(
            repo_root
            and (path == repo_root or path.startswith(f"{repo_root}/"))
        )

    def _relative_repo_path(self, full_path: str, repo_path: str) -> str:
        repo_root = repo_path.rstrip("/")
        return full_path[len(repo_root):].lstrip("/")

    def _apply_remote_to_local(
        self,
        repo_path: str,
        root: Path,
        paths: list[str],
        remote_paths: set[str],
        tracked_paths: set[str] | None = None,
    ) -> tuple[list[str], set[str]]:
        applied: list[str] = []
        failed: set[str] = set()
        tracked = tracked_paths or set()
        for relative_path in paths:
            try:
                destination = root / relative_path
                if relative_path not in remote_paths:
                    if relative_path not in tracked:
                        logger.warning(
                            "Skipped remote->local delete for untracked path: %s",
                            relative_path,
                        )
                        failed.add(relative_path)
                        continue
                    if destination.exists():
                        destination.unlink()
                    applied.append(relative_path)
                    logger.info("Synced remote->local delete: %s", relative_path)
                    continue
                content = self._file_content(self._remote_path(repo_path, relative_path))
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_text(content)
                applied.append(relative_path)
                logger.info("Synced remote->local file: %s", relative_path)
            except Exception as exc:
                logger.error(
                    "Failed to sync remote->local file=%s error=%s",
                    relative_path,
                    exc,
                )
                failed.add(relative_path)
        return applied, failed

    def _apply_local_to_remote(
        self,
        repo_path: str,
        paths: list[str],
        local_files: dict[str, str],
        remote_paths: set[str] | None = None,
        tracked_paths: set[str] | None = None,
    ) -> tuple[list[str], set[str]]:
        applied: list[str] = []
        failed: set[str] = set()
        tracked = tracked_paths or set()
        for relative_path in paths:
            try:
                remote_path = self._remote_path(repo_path, relative_path)
                local_content = local_files.get(relative_path)
                if local_content is None:
                    if relative_path not in tracked:
                        logger.warning(
                            "Skipped local->remote delete for untracked path: %s",
                            relative_path,
                        )
                        failed.add(relative_path)
                        continue
                    self._browser_items_request(path=remote_path, operation="delete")
                    applied.append(relative_path)
                    logger.info("Synced local->remote delete: %s", relative_path)
                    continue
                if remote_paths is not None and relative_path not in remote_paths:
                    # Create first for local-only files, then update content.
                    try:
                        self._browser_items_request(
                            path=remote_path,
                            operation="create",
                        )
                        logger.info("Created remote file before update: %s", relative_path)
                    except Exception as create_exc:
                        logger.warning(
                            "Create before update failed for file=%s error=%s; "
                            "proceeding to update",
                            relative_path,
                            create_exc,
                        )
                self._browser_items_request(
                    path=remote_path,
                    operation="update",
                    browser_item_extra={"content": local_content},
                )
                applied.append(relative_path)
                logger.info("Synced local->remote file: %s", relative_path)
            except Exception as exc:
                logger.error(
                    "Failed to sync local->remote file=%s error=%s",
                    relative_path,
                    exc,
                )
                failed.add(relative_path)
        return applied, failed

    def _refresh_state_for_synced_paths(
        self,
        state: dict[str, Any],
        repo_path: str,
        synced_paths: list[str],
        remote_paths: set[str],
        remote_modified: dict[str, int | None],
        local_modified: dict[str, int | None],
        failed_paths: set[str] | None = None,
    ) -> None:
        tracked = state.get("files") if isinstance(state.get("files"), dict) else {}
        failed = failed_paths or set()
        # Include previously tracked paths so entries for files deleted on both
        # sides can still be pruned even if they aren't present in current maps.
        paths_to_refresh = set(synced_paths) | set(tracked.keys())
        for path in sorted(paths_to_refresh):
            if path in failed:
                continue
            # Remove stale entries for files deleted on both sides.
            if path not in remote_paths and path not in local_modified:
                tracked.pop(path, None)
                continue
            tracked[path] = {
                "last_synced_remote_modified_timestamp": (
                    remote_modified.get(path) if path in remote_paths else None
                ),
                "last_synced_local_modified_timestamp": local_modified.get(path),
                "last_sync_at": self._now_iso(),
            }
        state["files"] = tracked
        state["repo_path"] = repo_path

    def _build_sync_context(
        self,
        root: Path,
    ) -> dict[str, Any]:
        repo_path = self._repo_path()
        state = self._load_state(root)
        context: dict[str, Any] = {
            "repo_path": repo_path,
            "state": state,
            "remote_paths": set(),
            "remote_modified": {},
            "remote_stats": {},
            "local_files": {},
            "local_modified": {},
            "changes": {
                "remote_to_local": [],
                "local_to_remote": [],
                "conflicts": [],
                "in_sync": [],
            },
        }
        if not repo_path:
            return context
        remote_paths, remote_modified, remote_stats = self._sync_remote_file_map(
            repo_path
        )
        local_files, local_modified = self._collect_local_files(root)
        changes = self._detect_changes(
            remote_paths,
            remote_modified,
            local_files,
            local_modified,
            state,
        )
        context.update(
            {
                "remote_paths": remote_paths,
                "remote_modified": remote_modified,
                "remote_stats": remote_stats,
                "local_files": local_files,
                "local_modified": local_modified,
                "changes": changes,
            }
        )
        return context

    def build_sync_context(self, local_project_dir: str) -> dict[str, Any]:
        root = Path(local_project_dir).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        return self._build_sync_context(root)

    def _list_project_items(self, repo_path: str) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        seen_paths: set[str] = set()
        pending = [repo_path]
        visited: set[str] = set()
        logger.info("Starting recursive folder traversal at repo_path=%s", repo_path)

        def nested_items(node: dict[str, Any]) -> list[dict[str, Any]]:
            results: list[dict[str, Any]] = []
            node_path = str(node.get("path") or "").strip()
            if node_path and not self._is_within_repo_path(node_path, repo_path):
                return results
            children = node.get("items")
            if not isinstance(children, list):
                return results
            for child in children:
                if not isinstance(child, dict):
                    continue
                child_path = str(child.get("path") or "").strip()
                if child_path and not self._is_within_repo_path(child_path, repo_path):
                    continue
                results.append(child)
                results.extend(nested_items(child))
            return results

        while pending:
            batch: list[str] = []
            while pending and len(batch) < self.BROWSER_FOLDERS_BATCH_SIZE:
                candidate = pending.pop()
                if candidate in visited:
                    logger.info("Skipping already visited folder: %s", candidate)
                    continue
                visited.add(candidate)
                batch.append(candidate)
            if not batch:
                continue

            logger.info("Traversing folder batch size=%s", len(batch))
            listing = self._browser_items_request(folders=batch)
            browser_item = listing.get("browser_item")
            if not isinstance(browser_item, dict):
                logger.warning(
                    "Skipping folder traversal: missing browser_item for folders=%s",
                    batch,
                )
                continue
            children = browser_item.get("items")
            if not isinstance(children, list):
                logger.warning(
                    "Skipping folder traversal: browser_item.items is not a list for folders=%s",
                    batch,
                )
                continue
            logger.info(
                "Found %s child items under folder batch size=%s",
                len(children),
                len(batch),
            )

            for child in children:
                if not isinstance(child, dict):
                    continue
                for candidate in [child, *nested_items(child)]:
                    child_path = str(candidate.get("path") or "").strip()
                    if not child_path or not self._is_within_repo_path(child_path, repo_path):
                        continue
                    if child_path in seen_paths:
                        continue
                    relative = self._relative_repo_path(child_path, repo_path)
                    if self._is_hidden(relative):
                        logger.info(
                            "Skipping hidden child path during traversal: %s",
                            child_path,
                        )
                        continue
                    seen_paths.add(child_path)
                    items.append(candidate)
                    if bool(candidate.get("folder")):
                        logger.info("Queueing subfolder for traversal: %s", child_path)
                        pending.append(child_path)
        logger.info(
            "Completed folder traversal visited_folders=%s discovered_items=%s",
            len(visited),
            len(items),
        )
        return items

    def sync_project_to_local(
        self,
        local_project_dir: str,
    ) -> Any:
        root = Path(local_project_dir).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        logger.info("Starting project sync to local_project_dir=%s", root)

        context = self._build_sync_context(root)
        repo_path = context["repo_path"]
        logger.info("Resolved remote repo_path=%s", repo_path)
        state = context["state"]

        summary: dict[str, Any] = {
            "local_project_dir": str(root),
            "repo_path": repo_path,
            "state_file": str(self._state_path(root)),
            "files_written": 0,
            "remote_to_local": [],
            "local_to_remote": [],
            "conflicts": [],
            "remote_scan_stats": {},
        }
        if not repo_path:
            logger.warning("Cannot sync project files: repo_path not found in /api/status")
            return summary

        tracked_paths = set(state.get("files", {}).keys()) if isinstance(
            state.get("files"), dict
        ) else set()
        remote_paths = context["remote_paths"]
        remote_modified = context["remote_modified"]
        changes = context["changes"]
        remote_stats = context["remote_stats"]
        summary["remote_scan_stats"] = remote_stats
        summary["local_to_remote"] = changes["local_to_remote"]
        summary["conflicts"] = changes["conflicts"]

        applied_pull, failed_pull = self._apply_remote_to_local(
            repo_path,
            root,
            changes["remote_to_local"],
            remote_paths,
            tracked_paths=tracked_paths,
        )
        summary["remote_to_local"] = applied_pull
        summary["files_written"] = len(applied_pull)

        refreshed_local, refreshed_local_modified = self._collect_local_files(root)
        self._refresh_state_for_synced_paths(
            state=state,
            repo_path=repo_path,
            synced_paths=applied_pull,
            remote_paths=remote_paths,
            remote_modified=remote_modified,
            local_modified=refreshed_local_modified,
            failed_paths=failed_pull,
        )
        self._save_state(root, state)

        logger.info(
            "Project sync complete files_written=%s local_to_remote=%s conflicts=%s",
            summary["files_written"],
            len(summary["local_to_remote"]),
            len(summary["conflicts"]),
        )

        return summary

    def sync_status(
        self,
        local_project_dir: str,
        context: dict[str, Any] | None = None,
    ) -> Any:
        root = Path(local_project_dir).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        context = context or self._build_sync_context(root)
        repo_path = context["repo_path"]
        summary: dict[str, Any] = {
            "local_project_dir": str(root),
            "repo_path": repo_path,
            "state_file": str(self._state_path(root)),
            "remote_to_local": [],
            "local_to_remote": [],
            "conflicts": [],
            "remote_scan_stats": {},
            "local_files_count": 0,
        }
        if not repo_path:
            return summary
        changes = context["changes"]
        remote_stats = context["remote_stats"]
        local_files = context["local_files"]
        summary["remote_to_local"] = changes["remote_to_local"]
        summary["local_to_remote"] = changes["local_to_remote"]
        summary["conflicts"] = changes["conflicts"]
        summary["remote_scan_stats"] = remote_stats
        summary["local_files_count"] = len(local_files)
        return summary

    def sync_local_to_remote(self, local_project_dir: str) -> Any:
        root = Path(local_project_dir).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        context = self._build_sync_context(root)
        repo_path = context["repo_path"]
        state = context["state"]
        summary: dict[str, Any] = {
            "local_project_dir": str(root),
            "repo_path": repo_path,
            "state_file": str(self._state_path(root)),
            "files_pushed": 0,
            "remote_to_local": [],
            "local_to_remote": [],
            "conflicts": [],
            "remote_scan_stats": {},
        }
        if not repo_path:
            return summary

        tracked_paths = set(state.get("files", {}).keys()) if isinstance(
            state.get("files"), dict
        ) else set()
        changes = context["changes"]
        remote_stats = context["remote_stats"]
        local_files = context["local_files"]
        summary["remote_to_local"] = changes["remote_to_local"]
        summary["conflicts"] = changes["conflicts"]
        summary["remote_scan_stats"] = remote_stats

        applied_push, failed_push = self._apply_local_to_remote(
            repo_path,
            changes["local_to_remote"],
            local_files,
            remote_paths=context["remote_paths"],
            tracked_paths=tracked_paths,
        )
        summary["local_to_remote"] = applied_push
        summary["files_pushed"] = len(applied_push)

        refreshed_remote_paths, refreshed_remote_modified, _ = self._sync_remote_file_map(
            repo_path
        )
        refreshed_local, refreshed_local_modified = self._collect_local_files(root)
        self._refresh_state_for_synced_paths(
            state=state,
            repo_path=repo_path,
            synced_paths=applied_push,
            remote_paths=refreshed_remote_paths,
            remote_modified=refreshed_remote_modified,
            local_modified=refreshed_local_modified,
            failed_paths=failed_push,
        )
        self._save_state(root, state)

        return summary

    def sync_bidirectional(
        self,
        local_project_dir: str,
        conflict_resolutions: dict[str, str] | None = None,
        context: dict[str, Any] | None = None,
    ) -> Any:
        root = Path(local_project_dir).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        context = context or self._build_sync_context(root)
        repo_path = context["repo_path"]
        state = context["state"]
        summary: dict[str, Any] = {
            "local_project_dir": str(root),
            "repo_path": repo_path,
            "state_file": str(self._state_path(root)),
            "pulled_files": [],
            "pushed_files": [],
            "conflicts": [],
            "conflicts_resolved_remote": [],
            "conflicts_resolved_local": [],
            "conflicts_skipped": [],
            "remote_scan_stats": {},
        }
        if not repo_path:
            return summary

        tracked_paths = set(state.get("files", {}).keys()) if isinstance(
            state.get("files"), dict
        ) else set()
        remote_paths = context["remote_paths"]
        remote_modified = context["remote_modified"]
        remote_stats = context["remote_stats"]
        changes = context["changes"]

        summary["remote_scan_stats"] = remote_stats
        summary["conflicts"] = changes["conflicts"]
        pulled_files, failed_pull = self._apply_remote_to_local(
            repo_path,
            root,
            changes["remote_to_local"],
            remote_paths,
            tracked_paths=tracked_paths,
        )
        summary["pulled_files"] = pulled_files
        local_writes = len(summary["pulled_files"]) > 0

        refreshed_local, refreshed_local_modified = self._collect_local_files(root)
        pushed_files, failed_push = self._apply_local_to_remote(
            repo_path,
            changes["local_to_remote"],
            refreshed_local,
            remote_paths=remote_paths,
            tracked_paths=tracked_paths,
        )
        summary["pushed_files"] = pushed_files
        remote_writes = len(summary["pushed_files"]) > 0

        resolutions = conflict_resolutions or {}
        conflict_local_files = refreshed_local
        failed_conflicts: set[str] = set()
        for path in changes["conflicts"]:
            decision = str(resolutions.get(path, "skip")).lower()
            if decision == "remote":
                applied, failed = self._apply_remote_to_local(
                    repo_path,
                    root,
                    [path],
                    remote_paths,
                    tracked_paths=tracked_paths,
                )
                if applied:
                    summary["conflicts_resolved_remote"].append(path)
                    local_writes = True
                else:
                    summary["conflicts_skipped"].append(path)
                failed_conflicts.update(failed)
            elif decision == "local":
                applied, failed = self._apply_local_to_remote(
                    repo_path,
                    [path],
                    conflict_local_files,
                    remote_paths=remote_paths,
                    tracked_paths=tracked_paths,
                )
                if applied:
                    summary["conflicts_resolved_local"].append(path)
                    remote_writes = True
                else:
                    summary["conflicts_skipped"].append(path)
                failed_conflicts.update(failed)
            else:
                summary["conflicts_skipped"].append(path)

        if remote_writes:
            logger.info("Fetching refreshed remote paths after sync.")
            refreshed_remote_paths, refreshed_remote_modified, _ = self._sync_remote_file_map(
                repo_path
            )
        else:
            refreshed_remote_paths = remote_paths
            refreshed_remote_modified = remote_modified

        if local_writes:
            refreshed_local, refreshed_local_modified = self._collect_local_files(root)
        else:
            refreshed_local = context["local_files"]
            refreshed_local_modified = context["local_modified"]

        synced_paths = sorted(refreshed_remote_paths | set(refreshed_local.keys()))
        failed_paths = set(failed_pull) | set(failed_push) | failed_conflicts
        self._refresh_state_for_synced_paths(
            state=state,
            repo_path=repo_path,
            synced_paths=synced_paths,
            remote_paths=refreshed_remote_paths,
            remote_modified=refreshed_remote_modified,
            local_modified=refreshed_local_modified,
            failed_paths=failed_paths,
        )
        self._save_state(root, state)

        return summary
