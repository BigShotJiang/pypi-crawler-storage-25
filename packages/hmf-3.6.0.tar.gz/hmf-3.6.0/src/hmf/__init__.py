"""A package for producing halo mass functions under Spherical Collapse."""

import contextlib
from importlib.metadata import PackageNotFoundError, version

with contextlib.suppress(PackageNotFoundError):
    __version__ = version(__name__)

from ._internals import (
    Component,
    Framework,
    cached_quantity,
    get_base_component,
    get_base_components,
    get_mdl,
    parameter,
)
from .alternatives import wdm
from .cosmology import Cosmology, GrowthFactor, cosmo, growth_factor
from .density_field import CAMB, Transfer, filters, halofit, transfer, transfer_models
from .halos import mass_definitions
from .helpers import functional, get_best_param_order, get_hmf, sample
from .mass_function import MassFunction, fitting_functions, hmf, integrate_hmf

__all__ = [
    "CAMB",
    "Component",
    "Cosmology",
    "Framework",
    "GrowthFactor",
    "MassFunction",
    "Transfer",
    "cached_quantity",
    "cosmo",
    "filters",
    "fitting_functions",
    "functional",
    "get_base_component",
    "get_base_components",
    "get_best_param_order",
    "get_hmf",
    "get_mdl",
    "growth_factor",
    "halofit",
    "hmf",
    "integrate_hmf",
    "mass_definitions",
    "parameter",
    "sample",
    "transfer",
    "transfer_models",
    "wdm",
]
