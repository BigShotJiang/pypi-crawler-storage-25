# mql2py

MQL5 EA emulator — run MetaTrader 5 Expert Advisors in Python without MetaTrader.

```python
pip install mql2py
```

```python
from mql2py import MQL5Runtime, Engine

rt = MQL5Runtime(symbol="EURUSD", initial_balance=10_000.0)
engine = Engine(my_ea, rt, bar_dataframe)
engine.run()
```

## CLI

```bash
mql2py-emulator MyEA.mq5 --bars data.parquet --balance 10000
```
