"""
mql2py — MQL5 EA emulator
==========================
Run MetaTrader 5 Expert Advisors in Python without MetaTrader.

Quick start:
    from mql2py import MQL5Runtime, Engine
    from mql2py.bridge import MQL5Bridge

    rt = MQL5Runtime(symbol="EURUSD", initial_balance=10_000.0)
    bridge = MQL5Bridge(rt, "/path/to/mql5/sources")
    ea = bridge.load("MyEA.mq5")

    engine = Engine(ea, rt, bar_dataframe)
    engine.run()

    # Access results
    for trade in rt.trades:
        print(trade.pnl_pips)
"""

from .runtime import MQL5Runtime, TradeRecord
from .types   import MqlRates, Position, OrderRequest, OrderResult
from .engine  import Engine

__all__ = [
    "MQL5Runtime",
    "TradeRecord",
    "Engine",
    "MqlRates",
    "Position",
    "OrderRequest",
    "OrderResult",
]
