# bridge.py — MQL5 bridge
#
# Resolves #include chains, transpiles all .mqh/.mq5 files in dependency
# order, assembles them into a single Python module, and executes it with
# the MQL5Runtime injected as `_rt`.
#
# Usage:
#   bridge = MQL5Bridge(runtime, project_root)
#   ea = bridge.load("SessionBreakout.mq5")
#   # ea has OnInit(), OnBar(), OnDeinit()

from __future__ import annotations
import os
import re
import sys
import types
import importlib
from pathlib import Path
from typing import Optional

from .runtime import MQL5Runtime
from .transpiler import transpile
from .types import MqlDateTime as _MqlDateTime, MqlRates as _MqlRates


class _Namespace:
    """Generic attribute container — used as a placeholder in auto-extended arrays."""
    def __getattr__(self, name):
        return None
    def __setattr__(self, name, val):
        object.__setattr__(self, name, val)


def _safe_format(fmt: str, args: tuple) -> str:
    """MQL5 StringFormat with None-safe coercion (None → 0 or empty string)."""
    if not args:
        return fmt
    import re as _re
    clean = []
    for a in args:
        if a is None:
            clean.append(0)
        else:
            clean.append(a)
    try:
        return fmt % tuple(clean)
    except (TypeError, ValueError):
        return fmt


class _AutoList(list):
    """A list that auto-extends with _Namespace() on out-of-bounds access.
    Used for MQL5 fixed-size arrays that Python initializes as empty lists."""

    def __getitem__(self, idx):
        if isinstance(idx, int):
            if idx >= len(self):
                self.extend([_Namespace() for _ in range(idx - len(self) + 1)])
            val = super().__getitem__(idx)
            if val is None:
                ns = _Namespace()
                super().__setitem__(idx, ns)
                return ns
        return super().__getitem__(idx)

    def __setitem__(self, idx, val):
        if isinstance(idx, int) and idx >= len(self):
            self.extend([_Namespace() for _ in range(idx - len(self) + 1)])
        super().__setitem__(idx, val)


# ---------------------------------------------------------------------------
# Include resolver
# ---------------------------------------------------------------------------

class IncludeResolver:
    """
    Walks #include directives and returns all .mqh files in dependency order
    (leaves first, so every file is defined before it's used).
    """

    def __init__(self, root: str):
        self.root   = Path(root)
        self._seen: set[str] = set()
        self._order: list[Path] = []

    def resolve(self, entry: str) -> list[Path]:
        """Return ordered list of files to compile, starting from entry point."""
        self._seen.clear()
        self._order.clear()
        self._walk(self.root / entry)
        return self._order

    def _walk(self, path: Path) -> None:
        key = str(path.resolve())
        if key in self._seen:
            return
        self._seen.add(key)

        if not path.exists():
            # Try searching under Kairos/ include dirs
            for candidate in self.root.rglob(path.name):
                if candidate.exists():
                    path = candidate
                    break
            else:
                return   # not found — skip silently, runtime will surface missing APIs

        source = path.read_text(encoding='utf-8', errors='replace')

        # Recurse into includes first (depth-first → topological order)
        for inc in self._find_includes(source, path.parent):
            self._walk(inc)

        self._order.append(path)

    def _find_includes(self, source: str, relative_to: Path) -> list[Path]:
        includes = []
        for m in re.finditer(r'#include\s+"([^"]+)"', source):
            inc_path = relative_to / m.group(1)
            if not inc_path.exists():
                # Try from project root
                inc_path = self.root / m.group(1)
            if not inc_path.exists():
                # Try stripping leading ../
                cleaned = re.sub(r'^(\.\./)+', '', m.group(1))
                inc_path = self.root / cleaned
            includes.append(inc_path)
        return includes


# ---------------------------------------------------------------------------
# MQL5Bridge
# ---------------------------------------------------------------------------

class MQL5Bridge:
    """
    Loads a .mq5 EA file (plus all its includes) into a live Python module
    with the MQL5Runtime injected, then returns an EA instance.
    """

    def __init__(self, runtime: MQL5Runtime, project_root: str):
        self.rt   = runtime
        self.root = Path(project_root)

        # Collect missing API calls during execution
        self.missing_apis: set[str] = set()

        # Extend runtime with "not implemented" fallbacks that record themselves
        self._patch_runtime_with_stubs()

    def load(self, ea_filename: str) -> object:
        """
        Transpile and load an EA from a .mq5 file.
        Returns the EA instance (has OnInit, OnBar, OnDeinit).
        """
        ea_path = self.root / ea_filename
        if not ea_path.exists():
            raise FileNotFoundError(f"EA file not found: {ea_path}")

        resolver = IncludeResolver(str(self.root))
        files    = resolver.resolve(ea_filename)

        # Transpile all files and concatenate
        combined_py = self._assemble(files)

        # Save transpiled source for debugging
        debug_path = self.root / "pipeline" / "results" / f"{ea_path.stem}_transpiled.py"
        debug_path.parent.mkdir(parents=True, exist_ok=True)
        debug_path.write_text(combined_py, encoding='utf-8')

        # Execute in a fresh module namespace with runtime injected
        module = types.ModuleType(ea_path.stem)
        module.__dict__['_rt'] = self.rt
        module.__dict__['__file__'] = str(ea_path)

        # Inject common names the transpiled code expects
        self._inject_builtins(module)

        # Inject a module-level __getattr__ so unknown MQL5 constants return 0
        # instead of NameError. This handles the long tail of color/property constants.
        _bridge_ref = self
        def _module_getattr(name: str):
            _bridge_ref.missing_apis.add(f'const:{name}')
            return 0
        module.__dict__['__getattr__'] = _module_getattr

        # Inject _AutoList so transpiled classes can use auto-extending lists
        # for MQL5 fixed-size arrays that get initialized as empty Python lists.
        module.__dict__['_AutoList'] = _AutoList

        # Register in sys.modules so @dataclass can resolve __module__ via sys.modules
        sys.modules[ea_path.stem] = module
        try:
            exec(compile(combined_py, str(ea_path), 'exec'), module.__dict__)
        except Exception as e:
            self._report_error(e, combined_py)
            raise

        # Patch all transpiled classes with a __getattr__ stub so that calls to
        # MQL5 API methods that weren't transpiled (e.g. SetPeriod on ATRCache)
        # degrade gracefully instead of raising AttributeError.
        self._patch_classes_with_stubs(module)

        # If CLogger is defined in module, create a proper KairosLogger instance
        if 'CLogger' in module.__dict__ and isinstance(module.__dict__['CLogger'], type):
            try:
                kl = module.__dict__['CLogger']()
                module.__dict__['KairosLogger'] = kl
            except Exception:
                pass

        # Instantiate all module-level globals tagged with # _mql5_ctor:ClassName.
        # The transpiler emits: g_sr: object = None  # _mql5_ctor:CSupportResistanceEngine
        # We scan the source, find those pairs, and instantiate them now that all
        # classes are defined.
        self._instantiate_module_globals(module, combined_py)

        # Find the EA class (largest class that has OnBar method)
        ea_class = self._find_ea_class(module)
        if ea_class is None:
            raise RuntimeError(f"No EA class with OnBar() found in {ea_filename}")

        instance = ea_class()
        # Inject runtime into instance so methods can call _rt
        instance.__dict__['_rt'] = self.rt

        # Wire module-level g_ea to the instance so free functions OnInit/OnTick
        # (which delegate to g_ea) work correctly.
        if 'g_ea' in module.__dict__:
            module.__dict__['g_ea'] = instance

        # If module has free-function OnInit/OnBar/OnTick, bind them to instance
        # so the engine can call ea.OnInit() uniformly.
        # Use type.__dict__ lookup (not hasattr) to avoid triggering __getattr__ stubs.
        for fn_name in ('OnInit', 'OnBar', 'OnTick', 'OnDeinit'):
            if fn_name in module.__dict__ and callable(module.__dict__[fn_name]):
                # Check if a real method exists directly on the class (not via __getattr__)
                real_method = type(instance).__dict__.get(fn_name)
                if real_method is None:
                    fn = module.__dict__[fn_name]
                    setattr(instance, fn_name, fn)

        # If the class has OnBar(symbol, tf) but no no-arg OnBar, and module has OnTick,
        # create an OnBar wrapper that calls OnTick (tick-driven EAs like Confluence).
        _class_onbar = type(instance).__dict__.get('OnBar')
        if _class_onbar is not None:
            import inspect as _inspect
            try:
                sig = _inspect.signature(_class_onbar)
                params = [p for p in sig.parameters if p != 'self']
                if len(params) > 0:
                    # OnBar takes extra args (e.g. symbol, tf) — check if module's
                    # OnTick free function (no args) is the real tick entry point.
                    _module_tick = module.__dict__.get('OnTick')
                    _module_bar  = module.__dict__.get('OnBar')
                    if _module_tick and callable(_module_tick):
                        # Use the module-level no-arg OnTick as OnBar
                        setattr(instance, 'OnBar', _module_tick)
                    elif _module_bar and callable(_module_bar):
                        setattr(instance, 'OnBar', _module_bar)
                    else:
                        # Wrap class OnTick/OnBar with fixed args from runtime
                        _inst   = instance
                        _rt_ref = self.rt
                        _sym    = self.rt.symbol
                        def _wrapped_onbar(_i=_inst, _s=_sym):
                            _i.OnTick(_s)
                        setattr(instance, 'OnBar', _wrapped_onbar)
            except (ValueError, TypeError):
                pass

        return instance

    # -----------------------------------------------------------------------
    def _copy_ohlcv(self, field: str, sym: str, tf: int, start: int, count: int, out) -> int:
        """Helper for CopyHigh/Low/Open/Close/Time/Volume — reads from runtime history."""
        history = self.rt._history
        if not history:
            return 0
        end_idx = self.rt._bar_idx - start + 1
        begin   = max(0, end_idx - count)
        bars    = history[begin:end_idx]
        vals    = [getattr(b, field) for b in bars]
        if out is None:
            return len(vals)
        if hasattr(out, 'clear'):
            out.clear()
            out.extend(vals)
        elif hasattr(out, '__setitem__'):
            for i, v in enumerate(vals):
                out[i] = v
        return len(vals)

    # Assembly
    # -----------------------------------------------------------------------

    def _assemble(self, files: list[Path]) -> str:
        """Transpile all files and join into one Python module."""
        parts = [
            "# === MQL5 Bridge — assembled module ===",
            "from __future__ import annotations",
            "import math",
            "from dataclasses import dataclass, field",
            "from enum import IntEnum",
            "from typing import Optional, List",
            "# _rt injected by MQL5Bridge.load()",
            "",
        ]

        for f in files:
            src = f.read_text(encoding='utf-8', errors='replace')
            py  = transpile(src, str(f.name))
            # Strip the per-file header (already added above)
            py_lines = py.splitlines()
            body = '\n'.join(
                l for l in py_lines
                if not l.startswith('# Auto-transpiled')
                and not l.startswith('# Generated by')
                and not l.startswith('from __future__')
                and not l.startswith('import math')
                and not l.startswith('from dataclasses')
                and not l.startswith('from enum')
                and not l.startswith('from typing')
                and not l.startswith('# _rt is injected')
            )
            parts.append(f"\n# {'='*60}")
            parts.append(f"# {f.name}")
            parts.append(f"# {'='*60}")
            parts.append(body)

        return '\n'.join(parts)

    # -----------------------------------------------------------------------
    # EA class discovery
    # -----------------------------------------------------------------------

    def _instantiate_module_globals(self, module: types.ModuleType, source: str) -> None:
        """
        Scan transpiled source for module-level globals tagged with # _mql5_ctor:ClassName
        and instantiate them. The transpiler emits lines like:
            g_sr: object = None  # _mql5_ctor:CSupportResistanceEngine
        After all classes are defined we can create the instances.
        """
        _tag_re = re.compile(r'^(\w+)\s*:\s*\w+\s*=\s*None\s*#\s*_mql5_ctor:(\w+)', re.MULTILINE)
        for m in _tag_re.finditer(source):
            var_name  = m.group(1)
            cls_name  = m.group(2)
            # Only instantiate at module level (not inside classes — those have 4-space indent)
            line_start = source.rfind('\n', 0, m.start()) + 1
            indent = m.start() - line_start
            if indent > 0:
                continue  # inside a class body — handled by _inject_self
            cls = module.__dict__.get(cls_name)
            if cls is not None and isinstance(cls, type):
                try:
                    instance = cls()
                    module.__dict__[var_name] = instance
                except Exception as e:
                    print(f"  [BRIDGE] Warning: could not instantiate {cls_name} for {var_name}: {e}")

    def _patch_classes_with_stubs(self, module: types.ModuleType) -> None:
        """
        Add __getattr__ to every transpiled class so missing MQL5 methods
        (e.g. SetPeriod on ATRCache) return a no-op callable instead of
        raising AttributeError. This handles version mismatches gracefully.
        """
        missing_bridge = self

        def _make_getattr(cls_name):
            def __getattr__(self, name):
                missing_bridge.missing_apis.add(f'{cls_name}.{name}')
                def _noop(*args, **kwargs):
                    return 0
                return _noop
            return __getattr__

        for name, obj in module.__dict__.items():
            if isinstance(obj, type) and obj.__module__ == module.__name__:
                if not hasattr(obj, '__getattr__'):
                    obj.__getattr__ = _make_getattr(name)

    def _find_ea_class(self, module: types.ModuleType) -> Optional[type]:
        """Find the top-level EA class — the one with OnBar or that ends in EA."""
        candidates = []
        for name, obj in module.__dict__.items():
            if isinstance(obj, type) and hasattr(obj, 'OnBar'):
                candidates.append((name, obj))

        if not candidates:
            # Fall back: class whose name ends with EA
            for name, obj in module.__dict__.items():
                if isinstance(obj, type) and name.endswith('EA'):
                    candidates.append((name, obj))

        if not candidates:
            return None

        # Prefer the one whose name matches the file
        return candidates[-1][1]

    # -----------------------------------------------------------------------
    # Runtime stub patching
    # -----------------------------------------------------------------------

    def _patch_runtime_with_stubs(self) -> None:
        """
        Add any MQL5 API method not yet on the runtime as a stub that:
        1. Records the call in missing_apis
        2. Returns a safe default
        3. Prints a warning the first time it's called
        """
        missing_bridge = self

        class _Stub:
            def __init__(self, name: str):
                self.name = name
                self._warned = False

            def __call__(self, *args, **kwargs):
                if not self._warned:
                    missing_bridge.missing_apis.add(self.name)
                    print(f"  [BRIDGE] NOT IMPLEMENTED: {self.name}() — returning default")
                    self._warned = True
                # Return sensible defaults by guessing from name
                name = self.name.lower()
                if 'double' in name or 'get' in name: return 0.0
                if 'integer' in name or 'total' in name: return 0
                if 'string' in name: return ""
                if 'select' in name: return False
                return None

        # Known API surface — patch any not already on runtime
        api_names = [
            'AccountInfoInteger', 'ArrayResize', 'ArraySetAsSeries',
            'ResetLastError', 'iTime',
            'CopyBuffer', 'IndicatorCreate',
            'PositionGetDouble', 'PositionGetString', 'OrderSend', 'OrderSelect',
            'FileOpen', 'FileClose', 'FileWrite', 'FileWriteString',
            'FileReadString', 'FileIsEnding', 'FileFlush',
            'FileSeek', 'FileTell', 'FileSize', 'FileIsExist', 'FileDelete',
            'FolderCreate',
            'ChartID', 'ChartSetInteger', 'ChartRedraw', 'ObjectsTotal',
            'EventSetTimer', 'EventKillTimer',
            'MessageBox',
            'TerminalInfoString', 'TerminalInfoInteger', 'TerminalInfoDouble',
            'AccountInfoString',
            'SymbolInfoString', 'SymbolInfoInteger', 'SymbolInfoDouble',
            'MathRand', 'MathSqrt', 'MathPow', 'MathCeil', 'MathRound', 'MathMod',
        ]

        for name in api_names:
            if not hasattr(self.rt, name):
                setattr(self.rt, name, _Stub(name))

    # -----------------------------------------------------------------------
    # Builtins injection
    # -----------------------------------------------------------------------

    def _inject_builtins(self, module: types.ModuleType) -> None:
        """Inject names that transpiled code references at module level."""
        import math as _math

        # MQL5 constants
        module.__dict__.update({
            # Order types
            'ORDER_TYPE_BUY': 0,
            'ORDER_TYPE_SELL': 1,
            'ORDER_TYPE_BUY_LIMIT': 2,
            'ORDER_TYPE_SELL_LIMIT': 3,
            'ORDER_TYPE_BUY_STOP': 4,
            'ORDER_TYPE_SELL_STOP': 5,

            # Symbol info
            'SYMBOL_POINT': 1,
            'SYMBOL_DIGITS': 2,
            'SYMBOL_TRADE_TICK_VALUE': 3,
            'SYMBOL_TRADE_TICK_SIZE': 4,
            'SYMBOL_TRADE_CONTRACT_SIZE': 5,
            'SYMBOL_VOLUME_MIN': 6,
            'SYMBOL_VOLUME_MAX': 7,
            'SYMBOL_VOLUME_STEP': 8,
            'SYMBOL_BID': 9,
            'SYMBOL_ASK': 10,
            'SYMBOL_SPREAD': 11,

            # Account info
            'ACCOUNT_BALANCE': 1,
            'ACCOUNT_EQUITY': 2,
            'ACCOUNT_MARGIN': 3,
            'ACCOUNT_FREE_MARGIN': 4,
            'ACCOUNT_MARGIN_LEVEL': 5,

            # Timeframes
            'PERIOD_M1': 1, 'PERIOD_M5': 5, 'PERIOD_M15': 15,
            'PERIOD_M30': 30, 'PERIOD_H1': 16385, 'PERIOD_H4': 16388,
            'PERIOD_D1': 16408, 'PERIOD_W1': 32769, 'PERIOD_MN1': 49153,
            'PERIOD_CURRENT': 0,

            # Position properties
            'POSITION_TYPE_BUY': 0, 'POSITION_TYPE_SELL': 1,
            'POSITION_TICKET': 1, 'POSITION_TYPE': 2,
            'POSITION_VOLUME': 3, 'POSITION_PRICE_OPEN': 4,
            'POSITION_SL': 5, 'POSITION_TP': 6,
            'POSITION_PRICE_CURRENT': 7, 'POSITION_PROFIT': 8,
            'POSITION_MAGIC': 9, 'POSITION_COMMENT': 10,
            'POSITION_SYMBOL': 11,

            # Deal properties
            'DEAL_TICKET': 1, 'DEAL_ORDER': 2, 'DEAL_TIME': 3,
            'DEAL_TYPE': 4, 'DEAL_ENTRY': 5, 'DEAL_SYMBOL': 6,
            'DEAL_VOLUME': 7, 'DEAL_PRICE': 8, 'DEAL_COMMISSION': 9,
            'DEAL_SWAP': 10, 'DEAL_PROFIT': 11, 'DEAL_MAGIC': 12,
            'DEAL_COMMENT': 13,

            # Deal types
            'DEAL_TYPE_BUY': 0, 'DEAL_TYPE_SELL': 1, 'DEAL_TYPE_BALANCE': 2,
            'DEAL_ENTRY_IN': 0, 'DEAL_ENTRY_OUT': 1, 'DEAL_ENTRY_INOUT': 2,

            # File constants
            'FILE_READ': 1, 'FILE_WRITE': 2, 'FILE_CSV': 8,
            'FILE_ANSI': 32, 'FILE_COMMON': 4096,

            # Chart objects
            'OBJ_HLINE': 0, 'OBJ_VLINE': 1, 'OBJ_TREND': 2,
            'OBJ_RECTANGLE': 3, 'OBJ_TEXT': 4, 'OBJ_ARROW': 5,
            'OBJPROP_COLOR': 1, 'OBJPROP_STYLE': 2, 'OBJPROP_WIDTH': 3,
            'OBJPROP_BACK': 4, 'OBJPROP_RAY_RIGHT': 5,
            'OBJPROP_TIME': 6, 'OBJPROP_PRICE': 7,
            'OBJPROP_TEXT': 8, 'OBJPROP_NAME': 9,

            # Colors (as ints)
            'clrRed': 255, 'clrGreen': 32768, 'clrBlue': 16711680,
            'clrYellow': 65535, 'clrWhite': 16777215, 'clrBlack': 0,
            'clrLime': 65280, 'clrAqua': 16776960, 'clrOrange': 42495,
            'clrGray': 8421504, 'clrDarkGray': 4210752,
            'clrDodgerBlue': 16748574, 'clrCrimson': 3937500,
            'clrSteelBlue': 11829830, 'clrRoyalBlue': 14772545,
            'clrSilver': 12632256, 'clrGold': 55295, 'clrPink': 13353215,
            'clrLightBlue': 15128749, 'clrLightGreen': 9498256,
            'clrLightGray': 13882323, 'clrDarkGreen': 25600,
            'clrNavy': 8388608, 'clrPurple': 8388736, 'clrTeal': 8421376,
            'clrMaroon': 128, 'clrOlive': 32896, 'clrIndigo': 8519755,
            'clrViolet': 15631086, 'clrMagenta': 16711935, 'clrCyan': 16776960,
            'clrCoral': 6737151, 'clrSalmon': 7504122, 'clrKhaki': 9234160,
            'clrTomato': 4678655, 'clrTurquoise': 13688896,
            'clrSlateBlue': 13458026, 'clrSlateGray': 9470064,
            'clrForestGreen': 2263842, 'clrSeaGreen': 5737262,
            'clrDarkSlateBlue': 9125192, 'clrDarkSlateGray': 5197615,
            'clrMediumBlue': 13434880, 'clrMediumAquamarine': 11206502,
            'clrChartreuse': 65407, 'clrSpringGreen': 8388352,
            'clrDeepSkyBlue': 16760576, 'clrDeepPink': 9639167,
            'clrHotPink': 11823615, 'clrSkyBlue': 15453831,
            'clrPowderBlue': 15130800, 'clrPaleGreen': 10025880,
            'clrLemonChiffon': 13499135, 'clrLavender': 16443110,
            'clrBeige': 14480885, 'clrIvory': 15794175, 'clrSnow': 16775930,
            'clrMintCream': 16449525, 'clrHoneydew': 15794160,
            'clrAliceBlue': 16775408, 'clrGhostWhite': 16316671,
            'clrWhiteSmoke': 16119285, 'clrSeashell': 15660543,
            'clrOldLace': 15136253, 'clrFloralWhite': 15792895,
            'clrNONE': 0,
            'clrLimeGreen': 3329330, 'clrDarkKhaki': 7059389,
            'clrBurlyWood': 8894686, 'clrCadetBlue': 10526303,
            'clrChocolate': 1993170, 'clrCornflowerBlue': 15570276,
            'clrDarkGoldenRod': 720930, 'clrDarkTurquoise': 13749760,
            'clrFireBrick': 2237106, 'clrFuchsia': 16711935,
            'clrGoldenRod': 2139610, 'clrGreenYellow': 3145645,
            'clrIndianRed': 6053069, 'clrLawnGreen': 64512,
            'clrLightPink': 12695295, 'clrMediumViolet': 8721863,
            'clrOrange': 42495, 'clrPaleTurquoise': 15658671,
            'clrPaleVioletRed': 9662683, 'clrPeachPuff': 12180223,
            'clrDarkOrange': 36095, 'clrOrangeRed': 17919,
            'clrDarkCyan': 9145088, 'clrDarkMagenta': 9109643,
            'clrDarkRed': 139, 'clrDarkBlue': 9109504,
            'clrLightCoral': 8421616, 'clrLightSalmon': 8036607,
            'clrLightSkyBlue': 16436871, 'clrLightSlateGray': 10061943,
            'clrLightSteelBlue': 14599344, 'clrLightYellow': 14745599,
            'clrMediumOrchid': 13850042, 'clrMediumPurple': 14381203,
            'clrMediumSeaGreen': 7451452, 'clrMediumSlateBlue': 15624315,
            'clrMediumSpringGreen': 16744272, 'clrMediumTurquoise': 13422920,
            'clrMediumVioletRed': 8721863, 'clrMistyRose': 14804223,
            'clrMoccasin': 11920639, 'clrNavajoWhite': 11394815,
            'clrPapayaWhip': 14021631, 'clrPeachPuff': 12180223,
            'clrPeru': 4163021, 'clrPlum': 14524637,
            'clrRosyBrown': 9408444, 'clrSaddleBrown': 1262987,
            'clrSandyBrown': 6333684, 'clrSienna': 2970272,
            'clrTan': 9221330, 'clrThistle': 14204888,
            'clrWheat': 11788021, 'clrYellowGreen': 3329434,

            # Line styles
            'STYLE_SOLID': 0, 'STYLE_DASH': 1, 'STYLE_DOT': 2,

            # Additional chart object properties
            'OBJPROP_TOOLTIP': 206, 'OBJPROP_SELECTED': 107,
            'OBJPROP_SELECTABLE': 107,
            'OBJPROP_HIDDEN': 208, 'OBJPROP_ZORDER': 209,
            'OBJPROP_FILL': 204, 'OBJPROP_READONLY': 207,
            'OBJPROP_XSIZE': 102, 'OBJPROP_YSIZE': 103,
            'OBJPROP_FONTSIZE': 101, 'OBJPROP_FONT': 100,
            'OBJPROP_ANCHOR': 203, 'OBJPROP_CORNER': 104,
            'OBJPROP_XDISTANCE': 105, 'OBJPROP_YDISTANCE': 106,
            'OBJPROP_LEVELCOLOR': 5, 'OBJPROP_LEVELSTYLE': 6,
            'OBJPROP_LEVELWIDTH': 7,
            'OBJPROP_ARROWCODE': 210,
            'ANCHOR_LEFT_UPPER': 0, 'ANCHOR_CENTER': 4,
            'ANCHOR_RIGHT_UPPER': 1, 'ANCHOR_LEFT_LOWER': 6,
            'ANCHOR_RIGHT_LOWER': 7, 'ANCHOR_UPPER': 2,
            'ANCHOR_LOWER': 8, 'ANCHOR_LEFT': 3, 'ANCHOR_RIGHT': 5,
            'ANCHOR_TOP': 2, 'ANCHOR_BOTTOM': 8,

            # Arrow codes
            'SYMBOL_ARROWUP': 241, 'SYMBOL_ARROWDOWN': 242,
            'SYMBOL_STOPSIGN': 251, 'SYMBOL_CHECKSIGN': 252,

            # Misc
            'INVALID_HANDLE': -1,
            'INT_MAX': 2147483647,
            'INT_MIN': -2147483648,

            # Filling modes
            'ORDER_FILLING_FOK': 0,
            'ORDER_FILLING_IOC': 1,
            'ORDER_FILLING_RETURN': 2,

            # Python stdlib
            'math': _math,

            # MQL5 predefined global variables (set from runtime)
            '_Symbol': self.rt.symbol,
            # KairosLogger — global singleton logger (CLogger("Kairos"))
            # Will be overwritten after module exec if CLogger is defined there
            'KairosLogger': type('CLogger', (), {
                'Info': lambda s, msg, kv=None: None,
                'Debug': lambda s, msg, kv=None: None,
                'Warn': lambda s, msg, kv=None: None,
                'Error': lambda s, msg, kv=None: None,
                'SetLevel': lambda s, level: None,
                'SetModule': lambda s, mod: None,
                '__getattr__': lambda s, n: (lambda *a, **kw: None),
            })(),
            '_Period': 16385,   # PERIOD_H1 — default; EA can override
            'Period':  lambda: 16385,  # MQL5 built-in function returning current period
            '_Point':  self.rt.SPEC['point'],
            '_Digits': self.rt.SPEC['digits'],

            # MQL5 built-in structs
            'MqlDateTime': _MqlDateTime,
            'MqlRates':    _MqlRates,

            # MQL5 built-in functions not on _rt
            'EnumToString': lambda v: str(v),
            'IntegerToString': lambda v, *a: str(int(v)) if v is not None else '0',
            'DoubleToString': lambda v, digits=2: f'{float(v):.{digits}f}',
            'StringToDouble': lambda s: float(s) if s else 0.0,
            'StringToInteger': lambda s: int(s) if s else 0,
            'StringLen': lambda s: len(s) if s else 0,
            'StringSubstr': lambda s, start, length=-1: (s[start:] if length < 0 else s[start:start+length]) if s else '',
            'StringFind': lambda s, sub, start=0: s.find(sub, start) if s else -1,
            'StringTrimLeft': lambda s: s.lstrip() if s else '',
            'StringTrimRight': lambda s: s.rstrip() if s else '',
            'StringGetCharacter': lambda s, i: ord(s[i]) if s and i < len(s) else 0,
            'StringToCharArray': lambda s, arr=None, start=0, count=-1, cp=0: [ord(c) for c in (s or '')],
            'CharArrayToString': lambda arr, start=0, count=-1, cp=0: ''.join(chr(c) for c in arr if c),
            'Print': lambda *args: print("[EA]", *args),
            'PrintFormat': lambda fmt, *args: print("[EA]", fmt % args if args else fmt),
            'Alert': lambda *args: None,
            'Comment': lambda *args: None,
            'GetLastError': lambda: 0,
            'ResetLastError': lambda: None,
            'MathLog': lambda x: __import__('math').log(x),
            'MathExp': lambda x: __import__('math').exp(x),
            'MathSin': lambda x: __import__('math').sin(x),
            'MathCos': lambda x: __import__('math').cos(x),
            'MathAtan': lambda x: __import__('math').atan(x),
            'MathLog10': lambda x: __import__('math').log10(x),
            'INIT_SUCCEEDED': 0,
            'INIT_FAILED': 1,
            'ArraySize': lambda arr: len(arr) if arr is not None else 0,
            'ArrayCopy': lambda dst, src, *args: dst.extend(src) or len(src),
            'ArrayFree': lambda arr: None,
            'ArraySort': lambda arr, *args: arr.sort() or 0,
            'ArrayInitialize': lambda arr, val: None,

            # Position/order query functions (delegate to runtime)
            'PositionsTotal': lambda magic=None: self.rt.PositionsTotal(magic),
            'PositionGetSymbol': lambda idx: getattr(self.rt.GetPositions()[idx] if idx < len(self.rt.GetPositions()) else type('P', (), {'symbol': ''})(), 'symbol', ''),
            'PositionGetDouble': lambda prop: self.rt.PositionGetDouble(prop),
            'PositionGetInteger': lambda prop: self.rt.PositionGetInteger(prop),
            'PositionGetString': lambda prop: '',
            'PositionSelect': lambda symbol: self.rt.PositionSelect(symbol),
            'PositionSelectByTicket': lambda ticket: self.rt.PositionSelectByTicket(ticket),
            'PositionModify': lambda ticket, sl, tp=0.0: self.rt.PositionModify(ticket, sl, tp),
            'HistorySelect': lambda f, t: self.rt.HistorySelect(f, t),
            'HistoryDealsTotal': lambda: self.rt.HistoryDealsTotal(),
            'HistoryDealSelect': lambda idx: self.rt.HistoryDealSelect(idx),
            'HistoryDealGetTicket': lambda idx: self.rt.HistoryDealGetTicket(idx),
            'HistoryDealGetDouble': lambda ticket, prop: self.rt.HistoryDealGetDouble(ticket, prop),
            'HistoryDealGetInteger': lambda ticket, prop: self.rt.HistoryDealGetInteger(ticket, prop),

            # Time formatting
            'TIME_DATE': 1, 'TIME_MINUTES': 2, 'TIME_SECONDS': 4,
            'TimeToString': lambda t, flags=6: __import__('datetime').datetime.utcfromtimestamp(int(t)).strftime(
                '%Y.%m.%d' + (' %H:%M:%S' if (int(flags) & 4) else ' %H:%M' if (int(flags) & 2) else '')
            ),
            'TimeLocal': lambda: (self.rt._bar.time if self.rt._bar else 0),
            'TimeCurrent': lambda: (self.rt._bar.time if self.rt._bar else 0),
            'StructToTime': lambda dt: int(__import__('datetime').datetime(
                dt.year, dt.month, dt.day,
                getattr(dt, 'hour', 0), getattr(dt, 'min', 0), getattr(dt, 'sec', 0)
            ).timestamp()),

            # Terminal info
            'TERMINAL_DATA_PATH': 1, 'TERMINAL_COMMONDATA_PATH': 2,
            'TERMINAL_PATH': 3, 'TERMINAL_LANGUAGE': 4,
            'TERMINAL_COMPANY': 5, 'TERMINAL_NAME': 6,
            'TERMINAL_BUILD': 7, 'TERMINAL_CONNECTED': 8,
            'TERMINAL_DLLS_ALLOWED': 9, 'TERMINAL_TRADE_ALLOWED': 10,
            'TERMINAL_X64': 11, 'TERMINAL_OPENCL_SUPPORT': 12,
            'TerminalInfoString': lambda prop: '/tmp/mt5_files',
            'TerminalInfoInteger': lambda prop: 0,
            'TerminalInfoDouble': lambda prop: 0.0,
            'AccountInfoString': lambda prop: '',

            # File seek origins
            'SEEK_SET': 0, 'SEEK_CUR': 1, 'SEEK_END': 2,

            # File operations (stubs — journal writes are no-ops in emulator)
            'FileOpen': lambda *args: -1,
            'FileClose': lambda handle: None,
            'FileWrite': lambda handle, *args: 0,
            'FileWriteString': lambda handle, s, length=-1: 0,
            'FileReadString': lambda handle, length=-1: '',
            'FileIsEnding': lambda handle: True,
            'FileSeek': lambda handle, offset, origin: True,
            'FileTell': lambda handle: 0,
            'FileSize': lambda handle: 0,
            'FileFlush': lambda handle: None,
            'FileIsExist': lambda path, common=0: False,
            'FileDelete': lambda path, common=0: False,
            'FolderCreate': lambda path, common=0: False,
            'MathRand': lambda: __import__('random').randint(0, 32767),
            'MathSqrt': lambda x: __import__('math').sqrt(x),
            'MathPow': lambda x, y: __import__('math').pow(x, y),
            'MathCeil': lambda x: __import__('math').ceil(x),
            'MathRound': lambda x: round(x),
            'MathMod': lambda x, y: x % y,

            # Symbol string info
            'SYMBOL_CURRENCY_BASE': 22, 'SYMBOL_CURRENCY_QUOTE': 23,
            'SYMBOL_CURRENCY_PROFIT': 23,  # profit currency = quote currency
            'SYMBOL_CURRENCY_MARGIN': 24, 'SYMBOL_DESCRIPTION': 20,
            'SYMBOL_PATH': 21,

            # Symbol filling/trade info
            'SYMBOL_FILLING_MODE': 50,
            'SYMBOL_FILLING_FOK': 1, 'SYMBOL_FILLING_IOC': 2,

            # Symbol trade mode
            'SYMBOL_TRADE_MODE': 30,
            'SYMBOL_TRADE_MODE_DISABLED': 0,
            'SYMBOL_TRADE_MODE_LONGONLY': 1,
            'SYMBOL_TRADE_MODE_SHORTONLY': 2,
            'SYMBOL_TRADE_MODE_CLOSEONLY': 3,
            'SYMBOL_TRADE_MODE_FULL': 4,
            'SYMBOL_TRADE_EXECUTION_REQUEST': 0,
            'SYMBOL_TRADE_EXECUTION_INSTANT': 1,
            'SYMBOL_TRADE_EXECUTION_MARKET': 2,
            'SYMBOL_TRADE_EXECUTION_EXCHANGE': 3,
            'SYMBOL_SWAP_MODE_DISABLED': 0,
            'SYMBOL_SWAP_MODE_POINTS': 1,
            'SYMBOL_SWAP_MODE_CURRENCY_SYMBOL': 2,
            'SYMBOL_SWAP_MODE_CURRENCY_MARGIN': 3,
            'SYMBOL_SWAP_MODE_CURRENCY_DEPOSIT': 4,
            'SYMBOL_SWAP_ROLLOVER3DAYS': 31,
            'SYMBOL_TRADE_STOPS_LEVEL': 32,
            'SYMBOL_TRADE_FREEZE_LEVEL': 33,
            'SymbolInfoString': lambda symbol, prop: (
                symbol[:3] if prop == 22 else  # base currency
                symbol[3:] if prop == 23 else  # quote currency
                ''
            ),
            'SymbolInfoInteger': lambda symbol, prop: self.rt.SymbolInfoInteger(symbol, prop),
            'SymbolInfoDouble':  lambda symbol, prop: self.rt.SymbolInfoDouble(symbol, prop),

            # Array operations
            'ArrayResize': lambda arr, new_size, reserve=0: (
                arr.extend([None] * max(0, new_size - len(arr))) or new_size
                if hasattr(arr, 'extend') else new_size
            ),
            'ArraySetAsSeries': lambda arr, flag: True,
            'ArrayIsSeries': lambda arr: False,
            'ArrayGetAsSeries': lambda arr: False,
            'ArrayMaximum': lambda arr, start=0, count=-1: arr.index(max(arr[start:] if count < 0 else arr[start:start+count])) if arr else -1,
            'ArrayMinimum': lambda arr, start=0, count=-1: arr.index(min(arr[start:] if count < 0 else arr[start:start+count])) if arr else -1,
            'ArrayFill': lambda arr, start, count, val: None,
            'ArraySwap': lambda arr1, arr2: None,

            # Indicator creation — return handles for CopyBuffer
            'iATR':  lambda sym, tf, period: self.rt.iATR(sym, tf, period),
            'iMA':   lambda sym, tf, period, shift, ma_method, applied_price: self.rt.iMA(sym, tf, period, shift, ma_method, applied_price),
            'iRSI':  lambda sym, tf, period, applied_price: self.rt.iRSI(sym, tf, period, applied_price),
            'iStochastic': lambda sym, tf, k, d, slowing, ma_method, price_field: self.rt.iStochastic(sym, tf, k, d, slowing, ma_method, price_field),
            'iCCI':  lambda sym, tf, period, applied_price: self.rt.iCCI(sym, tf, period, applied_price),
            'iMACD': lambda sym, tf, fast, slow, signal, applied_price: self.rt.iMACD(sym, tf, fast, slow, signal, applied_price),
            'iBands': lambda sym, tf, period, deviation, bands_shift, applied_price: self.rt.iBands(sym, tf, period, deviation, bands_shift, applied_price),
            # Indicator buffer copy — delegates to runtime handle registry
            'CopyBuffer': lambda handle, buf_idx, start, count, out: self.rt.CopyBuffer(handle, buf_idx, start, count, out),
            'IndicatorRelease': lambda handle: self.rt.IndicatorRelease(handle),
            'IndicatorCreate': lambda symbol, tf, indicator_type, *args: -1,

            # OHLCV copy functions — delegate to runtime history
            'CopyHigh': lambda sym, tf, start, count, out: self._copy_ohlcv('high', sym, tf, start, count, out),
            'CopyLow': lambda sym, tf, start, count, out: self._copy_ohlcv('low', sym, tf, start, count, out),
            'CopyOpen': lambda sym, tf, start, count, out: self._copy_ohlcv('open', sym, tf, start, count, out),
            'CopyClose': lambda sym, tf, start, count, out: self._copy_ohlcv('close', sym, tf, start, count, out),
            'CopyTime': lambda sym, tf, start, count, out: self._copy_ohlcv('time', sym, tf, start, count, out),
            'CopyVolume': lambda sym, tf, start, count, out: self._copy_ohlcv('tick_volume', sym, tf, start, count, out),

            # Misc MQL5 functions
            'ZeroMemory': lambda obj: None,   # clear struct — no-op (Python GC handles it)
            'memcpy': lambda dst, src, n: None,
            'memset': lambda ptr, val, n: None,
            'StringFormat': lambda fmt, *args: _safe_format(fmt, args),
            'sprintf': lambda fmt, *args: _safe_format(fmt, args),

            # Trade request/result structs and constants
            'MqlTradeRequest': _Namespace,
            'MqlTradeResult': _Namespace,
            'TRADE_ACTION_DEAL': 1, 'TRADE_ACTION_PENDING': 5,
            'TRADE_ACTION_SLTP': 6, 'TRADE_ACTION_MODIFY': 7,
            'TRADE_ACTION_REMOVE': 8, 'TRADE_ACTION_CLOSE_BY': 10,
            'ORDER_TYPE_MARKET': 0,
            'ORDER_TIME_GTC': 0, 'ORDER_TIME_DAY': 1,
            'ORDER_TIME_SPECIFIED': 2, 'ORDER_TIME_SPECIFIED_DAY': 3,
            'TRADE_RETCODE_DONE': 10009,
            'TRADE_RETCODE_REQUOTE': 10004,
            'TRADE_RETCODE_REJECT': 10006,
            'TRADE_RETCODE_PLACED': 10008,
            'ENUM_DAY_OF_WEEK': type('ENUM_DAY_OF_WEEK', (), {
                'SUNDAY': 0, 'MONDAY': 1, 'TUESDAY': 2, 'WEDNESDAY': 3,
                'THURSDAY': 4, 'FRIDAY': 5, 'SATURDAY': 6,
            }),
            'SUNDAY': 0, 'MONDAY': 1, 'TUESDAY': 2, 'WEDNESDAY': 3,
            'THURSDAY': 4, 'FRIDAY': 5, 'SATURDAY': 6,
            'SymbolInfoSessionTrade': lambda symbol, day, idx, frm, to: False,
            'SymbolInfoSessionQuote': lambda symbol, day, idx, frm, to: False,

            # Moving average methods
            'MODE_SMA': 0, 'MODE_EMA': 1, 'MODE_SMMA': 2, 'MODE_LWMA': 3,

            # iMA / indicator constants
            'PRICE_CLOSE': 0, 'PRICE_OPEN': 1, 'PRICE_HIGH': 2, 'PRICE_LOW': 3,
            'PRICE_MEDIAN': 4, 'PRICE_TYPICAL': 5, 'PRICE_WEIGHTED': 6,
            'VOLUME_TICK': 0, 'VOLUME_REAL': 1,

            # iBars / iHigh etc. — safe wrappers with bounds check
            'iBars': lambda sym, tf: len(self.rt._history),
            'iHigh':   lambda sym, tf, shift: (self.rt._history[self.rt._bar_idx - shift].high   if self.rt._history and 0 <= self.rt._bar_idx - shift < len(self.rt._history) else 0.0),
            'iLow':    lambda sym, tf, shift: (self.rt._history[self.rt._bar_idx - shift].low    if self.rt._history and 0 <= self.rt._bar_idx - shift < len(self.rt._history) else 0.0),
            'iClose':  lambda sym, tf, shift: (self.rt._history[self.rt._bar_idx - shift].close  if self.rt._history and 0 <= self.rt._bar_idx - shift < len(self.rt._history) else 0.0),
            'iOpen':   lambda sym, tf, shift: (self.rt._history[self.rt._bar_idx - shift].open   if self.rt._history and 0 <= self.rt._bar_idx - shift < len(self.rt._history) else 0.0),
            'iTime':   lambda sym, tf, shift: (self.rt._history[self.rt._bar_idx - shift].time   if self.rt._history and 0 <= self.rt._bar_idx - shift < len(self.rt._history) else 0),
            'iVolume': lambda sym, tf, shift: (self.rt._history[self.rt._bar_idx - shift].tick_volume if self.rt._history and 0 <= self.rt._bar_idx - shift < len(self.rt._history) else 0),

            # StringReplace (MQL5 modifies string in-place, Python returns new — treat as no-op)
            'StringReplace': lambda s, find, replace: (s.replace(find, replace) if isinstance(s, str) else s),

            # MQL tester/environment info
            'MQL_TESTER': 5, 'MQL_OPTIMIZATION': 6, 'MQL_VISUAL_MODE': 7,
            'MQL_FORWARD': 8, 'MQL_FRAME_MODE': 9,
            'MQLInfoInteger': lambda prop: (1 if prop == 5 else 0),  # MQL_TESTER=5 → True
            'MQLInfoString': lambda prop: '',
            'MQLInfoDouble': lambda prop: 0.0,

            # Symbol/market functions
            'SymbolSelect': lambda symbol, select=True: True,
            'SymbolExist': lambda symbol, local=True: True,
            'ChartSymbol': lambda chart_id=0: self.rt.symbol,
            'ChartPeriod': lambda chart_id=0: 16385,
            'IsConnected': lambda: True,
            'IsDemo': lambda: False,
            'IsOptimization': lambda: False,
            'IsTesting': lambda: True,
            'IsTradeAllowed': lambda: True,

            # Chart window functions (no-ops in emulator)
            'ChartID': lambda: 0,
            'ChartRedraw': lambda chart_id=0: None,
            'ChartSetInteger': lambda chart_id, prop, sub_window_or_value, value=None: True,
            'ChartSetDouble': lambda chart_id, prop, value: True,
            'ChartSetString': lambda chart_id, prop, value: True,
            'ChartGetInteger': lambda chart_id, prop, sub_window=0: 0,
            'ChartGetDouble': lambda chart_id, prop, sub_window=0: 0.0,
            'ChartGetString': lambda chart_id, prop: '',
            'ChartWindowFind': lambda chart_id, indicator_shortname: -1,
            'ChartWindowsTotal': lambda chart_id=0: 1,
            'ChartIndicatorAdd': lambda chart_id, sub_window, indicator_handle: True,
            'ChartIndicatorDelete': lambda chart_id, sub_window, indicator_shortname: True,
            'ChartIndicatorsTotal': lambda chart_id, sub_window: 0,

            # Chart object functions (drawing — no-ops in emulator)
            'ObjectsTotal': lambda chart_id=0, sub_window=-1, obj_type=-1: 0,
            'ObjectCreate': lambda chart_id, name, obj_type, sub_window, *args: True,
            'ObjectSetDouble': lambda chart_id, name, prop, *args: True,
            'ObjectSetInteger': lambda chart_id, name, prop, *args: True,
            'ObjectSetString': lambda chart_id, name, prop, *args: True,
            'ObjectGetDouble': lambda chart_id, name, prop, mod=0: 0.0,
            'ObjectGetInteger': lambda chart_id, name, prop, mod=0: 0,
            'ObjectGetString': lambda chart_id, name, prop, mod=0: '',
            'ObjectFind': lambda chart_id, name: -1,
            'ObjectDelete': lambda chart_id, name: True,
            'ObjectsDeleteAll': lambda chart_id, prefix='', obj_type=-1: 0,
            'ObjectMove': lambda chart_id, name, pt, time, price: True,
            'ObjectGetTimeByValue': lambda chart_id, name, value, line=0: 0,
            'ObjectGetValueByTime': lambda chart_id, name, time, line=0: 0.0,
            'ObjectName': lambda chart_id, idx, sub_window=-1, obj_type=-1: '',

            # Timeframe helpers
            'PeriodSeconds': lambda tf=0: {
                1: 60, 2: 120, 3: 180, 4: 240, 5: 300, 6: 360, 10: 600,
                12: 720, 15: 900, 20: 1200, 30: 1800,
                16385: 3600, 16386: 7200, 16387: 10800, 16388: 14400,
                16390: 21600, 16392: 28800, 16396: 43200,
                16408: 86400, 16416: 604800, 16432: 2592000,
                0: 3600,
            }.get(tf, 3600),

            # Order/trade management stubs (bare calls)
            'OrderSend': lambda req, result: False,
            'OrdersTotal': lambda: 0,
            'PositionsTotal': lambda: self.rt.PositionsTotal(),
            'GetLastError': lambda: 0,
            'ResetLastError': lambda: None,
        })

    # -----------------------------------------------------------------------
    # Error reporting
    # -----------------------------------------------------------------------

    def _report_error(self, error: Exception, source: str) -> None:
        """Print a helpful error with source context."""
        print(f"\n[BRIDGE] Transpilation/execution error: {error}")
        if hasattr(error, 'lineno') and error.lineno:
            lines = source.splitlines()
            lineno = error.lineno
            start  = max(0, lineno - 3)
            end    = min(len(lines), lineno + 3)
            print(f"  Near line {lineno}:")
            for i, l in enumerate(lines[start:end], start + 1):
                marker = '>>>' if i == lineno else '   '
                print(f"  {marker} {i:4d}: {l}")

    def report_missing(self) -> None:
        """Print a summary of all unimplemented MQL5 APIs called during the run.

        Methods ending in .Init are silently ignored — they are a common
        no-op pattern (a class may not need initialisation in the emulator).
        """
        if not self.missing_apis:
            print("\n[BRIDGE] All API calls were handled.")
            return

        # Filter out Init methods (e.g. CATRCache.Init) — they are expected no-ops
        significant = {api for api in self.missing_apis
                       if not api.endswith('.Init')}
        if significant:
            print(f"\n[BRIDGE] {len(significant)} unimplemented API(s) called:")
            for api in sorted(significant):
                print(f"  - {api}()")
        else:
            print("\n[BRIDGE] All API calls were handled (Init methods silently ignored).")
