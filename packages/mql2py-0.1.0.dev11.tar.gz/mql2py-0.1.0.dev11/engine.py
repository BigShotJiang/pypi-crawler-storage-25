# MQL5 Engine — feeds bars to an EA and produces a backtest report.
#
# Usage:
#   engine = Engine(ea, rt, df)
#   engine.run()
#   engine.report()

from __future__ import annotations
import os
from typing import TYPE_CHECKING, Type

import pandas as pd

from .runtime import MQL5Runtime, TradeRecord
from .types import MqlRates

if TYPE_CHECKING:
    from .ea_session_breakout import SessionBreakoutEA


class Engine:
    def __init__(self, ea, rt: MQL5Runtime, df: pd.DataFrame):
        self.ea = ea
        self.rt = rt
        self.df = df

    def run(self) -> None:
        history: list[MqlRates] = []
        df = self.df

        self.ea.OnInit()

        for idx, row in df.iterrows():
            bar = MqlRates(
                time        = int(row["time"].timestamp()),
                open        = float(row["open"]),
                high        = float(row["high"]),
                low         = float(row["low"]),
                close       = float(row["close"]),
                tick_volume = int(row["volume"]),
                spread      = int(row.get("spread_mean", 0) / self.rt.SPEC["point"]),
            )
            history.append(bar)
            self.rt._set_bar(bar, len(history) - 1, history)

            # Check SL/TP on open positions before EA logic
            self.rt._check_sl_tp()

            # Call EA OnBar (equivalent to OnBar in MQL5)
            self.ea.OnBar()

        try:
            self.ea.OnDeinit(0)
        except TypeError:
            self.ea.OnDeinit()

    def report(self, from_date: str = None, to_date: str = None,
               result_dir: str = None) -> None:
        trades = self.rt.trades
        if not trades:
            print("No trades.")
            return

        df = pd.DataFrame([t.__dict__ for t in trades])
        wins   = (df["exit_reason"] == "TP").sum()
        losses = (df["exit_reason"] == "SL").sum()
        total  = len(df)
        wr     = wins / total * 100

        gross_win  = df[df["pnl_pips"] > 0]["pnl_pips"].sum()
        gross_loss = df[df["pnl_pips"] < 0]["pnl_pips"].sum()
        pf = gross_win / abs(gross_loss) if gross_loss != 0 else float("inf")

        avg_win  = df[df["exit_reason"] == "TP"]["pnl_pips"].mean() if wins else 0
        avg_loss = df[df["exit_reason"] == "SL"]["pnl_pips"].mean() if losses else 0

        print()
        print("=" * 60)
        print("  SESSION BREAKOUT — EMULATOR RESULTS")
        print("=" * 60)
        print(f"  Total trades   : {total}")
        print(f"  Wins / Losses  : {wins} / {losses}")
        print(f"  Win rate       : {wr:.1f}%")
        print(f"  Avg win (pips) : {avg_win:.1f}")
        print(f"  Avg loss (pips): {avg_loss:.1f}")
        print(f"  Total pips     : {df['pnl_pips'].sum():.1f}")
        print(f"  Profit factor  : {pf:.2f}")
        print(f"  Initial balance: ${self.rt.initial_balance:,.2f}")
        print(f"  Final balance  : ${self.rt.balance:,.2f}")

        # Monthly breakdown
        df["month"] = df["close_time"].dt.to_period("M")
        monthly = df.groupby("month").agg(
            trades=("pnl_pips", "count"),
            wins=("exit_reason", lambda x: (x == "TP").sum()),
            pips=("pnl_pips", "sum"),
        ).reset_index()
        monthly["wr"] = (monthly["wins"] / monthly["trades"] * 100).round(1)

        recent = monthly.tail(24)
        if len(recent):
            print()
            print(f"  {'Month':<12} {'Trades':>6} {'Wins':>6} {'WR%':>6} {'Pips':>8}")
            print("  " + "-" * 42)
            for _, r in recent.iterrows():
                print(f"  {str(r['month']):<12} {r['trades']:>6} {r['wins']:>6} "
                      f"{r['wr']:>5.1f}% {r['pips']:>8.1f}")

        # Direction breakdown
        print()
        for d in ["BUY", "SELL"]:
            sub = df[df["direction"] == d]
            if len(sub):
                w = (sub["exit_reason"] == "TP").sum()
                print(f"  {d:<6}: {len(sub)} trades, "
                      f"WR {w/len(sub)*100:.1f}%, "
                      f"{sub['pnl_pips'].sum():.1f} pips")
        print("=" * 60)

        # Save CSVs
        if result_dir:
            os.makedirs(result_dir, exist_ok=True)
            trades_path = os.path.join(result_dir, "emulator_trades.csv")
            df.to_csv(trades_path, index=False)
            print(f"\nTrades written to {trades_path}")
