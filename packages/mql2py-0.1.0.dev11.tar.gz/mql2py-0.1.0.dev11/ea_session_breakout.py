# SessionBreakout EA — Python port for the MQL5 emulator.
#
# Structure mirrors SessionBreakout.mq5 exactly:
#   - Same phase state machine (ASIAN_BUILD → LONDON_BUILD → WATCH → RETEST → DONE)
#   - Same entry conditions (wick touch, close rejection, volume factor)
#   - Same TP resolution (Asian extreme if ≥ MinRR, else R:R projection)
#   - Same SL placement (retest candle extreme + ATR buffer)
#
# Instead of calling MQL5 globals, every API call goes through `rt` (MQL5Runtime).

from __future__ import annotations
from enum import IntEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .runtime import MQL5Runtime

from .types import (
    MqlRates, OrderRequest, OrderResult,
    ORDER_TYPE_BUY, ORDER_TYPE_SELL,
    SYMBOL_POINT, SYMBOL_DIGITS,
    ACCOUNT_BALANCE,
)

# ---------------------------------------------------------------------------
# Inputs — mirrors EA input defaults
# ---------------------------------------------------------------------------
class Inputs:
    Magic             = 303001
    RiskPct           = 1.0
    MaxLots           = 0.10
    AsianStartGMT     = 0
    AsianEndGMT       = 8
    LondonStartGMT    = 8
    LondonRangeEndGMT = 10
    TradingEndGMT     = 18
    GMTOffset         = 0
    BreakATR          = 1.0
    VolumeFactor      = 1.0
    VolumeLookback    = 20
    RetestBars        = 10
    SLBufferATR       = 0.3
    MinRR             = 1.5
    MaxSpread         = 30.0
    CooldownMins      = 30
    MaxSameDir        = 1
    MaxDDPct          = 10.0
    MaxDailyLoss      = 5.0
    MaxDailyTrades    = 5
    ATRMultiplier     = 1.5
    DrawLevels        = False


# ---------------------------------------------------------------------------
# Phase enum
# ---------------------------------------------------------------------------
class Phase(IntEnum):
    ASIAN_BUILD  = 0
    LONDON_BUILD = 1
    WATCH        = 2
    RETEST       = 3
    DONE         = 4


# ---------------------------------------------------------------------------
# EA class
# ---------------------------------------------------------------------------
class SessionBreakoutEA:
    def __init__(self, rt: "MQL5Runtime", inp: Inputs = None):
        self.rt  = rt
        self.inp = inp or Inputs()

        self._symbol = rt.symbol
        self._tf     = 16385  # PERIOD_H1

        # Day state
        self._phase:          Phase = Phase.ASIAN_BUILD
        self._day_start:      int   = 0
        self._asian_high:     float = 0.0
        self._asian_low:      float = float("inf")
        self._london_high:    float = 0.0
        self._london_low:     float = float("inf")
        self._broke_high:     bool  = False
        self._break_level:    float = 0.0
        self._retest_left:    int   = 0

    # -----------------------------------------------------------------------
    # Engine callbacks
    # -----------------------------------------------------------------------
    def OnInit(self) -> bool:
        return True

    def OnBar(self) -> None:
        bars: list[MqlRates] = []
        if self.rt.CopyRates(self._symbol, self._tf, 1, 1, bars) < 1:
            return

        bar     = bars[0]
        gmt_hour = self._gmt_hour(bar.time)

        if self._is_new_day(bar.time):
            self._reset_day(bar.time)

        if self._phase == Phase.ASIAN_BUILD:
            self._handle_asian_build(bar, gmt_hour)
        elif self._phase == Phase.LONDON_BUILD:
            self._handle_london_build(bar, gmt_hour)
        elif self._phase == Phase.WATCH:
            self._handle_watch(bar)
        elif self._phase == Phase.RETEST:
            self._handle_retest(bar)

    def OnDeinit(self) -> None:
        pass

    # -----------------------------------------------------------------------
    # Phase handlers — direct translation of MQL5 methods
    # -----------------------------------------------------------------------
    def _handle_asian_build(self, bar: MqlRates, gmt_hour: int) -> None:
        inp = self.inp
        if inp.AsianStartGMT <= gmt_hour < inp.LondonStartGMT:
            self._asian_high = self.rt.MathMax(self._asian_high, bar.high)
            self._asian_low  = self.rt.MathMin(self._asian_low,  bar.low)
            return

        if gmt_hour >= inp.LondonStartGMT:
            if self._asian_high <= self._asian_low or self._asian_high == 0:
                self._phase = Phase.DONE
                return
            self._london_high = bar.high
            self._london_low  = bar.low
            self._phase       = Phase.LONDON_BUILD

    def _handle_london_build(self, bar: MqlRates, gmt_hour: int) -> None:
        if gmt_hour < self.inp.LondonRangeEndGMT:
            self._london_high = self.rt.MathMax(self._london_high, bar.high)
            self._london_low  = self.rt.MathMin(self._london_low,  bar.low)
            return

        if self._london_high <= self._london_low:
            self._phase = Phase.DONE
            return

        self._phase = Phase.WATCH

    def _handle_watch(self, bar: MqlRates) -> None:
        if self._gmt_hour(bar.time) >= self.inp.TradingEndGMT:
            self._phase = Phase.DONE
            return

        atr = self._get_atr()
        if atr <= 0.0:
            return

        threshold = self.inp.BreakATR * atr

        if bar.close > self._london_high + threshold:
            self._broke_high    = True
            self._break_level   = self._london_high
            self._retest_left   = self.inp.RetestBars
            self._phase         = Phase.RETEST
            return

        if bar.close < self._london_low - threshold:
            self._broke_high    = False
            self._break_level   = self._london_low
            self._retest_left   = self.inp.RetestBars
            self._phase         = Phase.RETEST

    def _handle_retest(self, bar: MqlRates) -> None:
        if self._gmt_hour(bar.time) >= self.inp.TradingEndGMT:
            self._phase = Phase.DONE
            return

        self._retest_left -= 1
        if self._retest_left <= 0:
            self._phase = Phase.DONE
            return

        atr    = self._get_atr()
        avg_vol = self._avg_volume(self.inp.VolumeLookback)
        if atr <= 0.0 or avg_vol <= 0.0:
            return

        high_vol = bar.tick_volume >= avg_vol * self.inp.VolumeFactor

        if self._broke_high:
            if (bar.low <= self._break_level and
                    bar.close > self._break_level and high_vol):
                sl = bar.low - self.inp.SLBufferATR * atr
                tp = self._resolve_tp(ORDER_TYPE_BUY, bar.close, sl)
                if tp > bar.close:
                    if self._place_trade(ORDER_TYPE_BUY, bar.close, sl, tp):
                        self._phase = Phase.DONE
        else:
            if (bar.high >= self._break_level and
                    bar.close < self._break_level and high_vol):
                sl = bar.high + self.inp.SLBufferATR * atr
                tp = self._resolve_tp(ORDER_TYPE_SELL, bar.close, sl)
                if tp < bar.close:
                    if self._place_trade(ORDER_TYPE_SELL, bar.close, sl, tp):
                        self._phase = Phase.DONE

    # -----------------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------------
    def _resolve_tp(self, direction: int, entry: float, sl: float) -> float:
        sl_dist = abs(entry - sl)
        if sl_dist <= 0.0:
            return 0.0

        if direction == ORDER_TYPE_BUY:
            rr_tp       = entry + sl_dist * self.inp.MinRR
            asian_target = self._asian_high
        else:
            rr_tp       = entry - sl_dist * self.inp.MinRR
            asian_target = self._asian_low

        if asian_target > 0.0 and asian_target < float("inf"):
            rr = abs(asian_target - entry) / sl_dist
            if rr >= self.inp.MinRR:
                return asian_target

        return rr_tp

    def _place_trade(self, direction: int, entry: float,
                     sl: float, tp: float) -> bool:
        req = OrderRequest()
        req.symbol      = self._symbol
        req.orderType   = direction
        req.entryPrice  = 0.0
        req.slPrice     = sl
        req.tpPrice     = tp
        req.lots        = 0.0
        req.riskPercent = self.inp.RiskPct
        req.magic       = self.inp.Magic
        req.comment     = "SB_" + ("BUY" if direction == ORDER_TYPE_BUY else "SELL")

        result = OrderResult()
        self.rt.PlaceMarketOrder(req, result)
        return result.success

    def _get_atr(self) -> float:
        atr = self.rt.iATR(self._symbol, self._tf, 14, 1)
        if atr > 0.0:
            return atr
        point  = self.rt.SymbolInfoDouble(self._symbol, SYMBOL_POINT)
        digits = self.rt.SymbolInfoInteger(self._symbol, SYMBOL_DIGITS)
        pip    = point * 10.0 if digits in (5, 3) else point
        return pip * 30.0

    def _avg_volume(self, lookback: int) -> float:
        vols: list[int] = []
        got = self.rt.CopyTickVolume(self._symbol, self._tf, 1, lookback, vols)
        if got < lookback:
            return 0.0
        return sum(vols) / len(vols)

    def _gmt_hour(self, t: int) -> int:
        import pandas as pd
        offset_sec = self.inp.GMTOffset * 3600
        utc = max(0, t - offset_sec)
        return pd.Timestamp(utc, unit="s").hour

    def _is_new_day(self, t: int) -> bool:
        import pandas as pd
        day = pd.Timestamp(t, unit="s").date()
        return day != pd.Timestamp(self._day_start, unit="s").date()

    def _reset_day(self, t: int) -> None:
        self._day_start   = t
        self._phase       = Phase.ASIAN_BUILD
        self._asian_high  = 0.0
        self._asian_low   = float("inf")
        self._london_high = 0.0
        self._london_low  = float("inf")
        self._broke_high  = False
        self._break_level = 0.0
        self._retest_left = 0
