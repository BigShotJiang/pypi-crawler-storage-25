# MQL5Runtime — the fake MQL5 environment injected into every EA.
#
# Provides:
#   - Symbol info (point, digits, spread, bid/ask)
#   - Account info (balance, equity)
#   - Bar history access (CopyRates, CopyTickVolume, iATR)
#   - Order execution (market orders, SL/TP simulation)
#   - Position management (ManagePositions trail stub)
#
# The runtime holds mutable state that updates as the engine feeds bars.

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import pandas as pd

from .types import (
    MqlRates, OrderRequest, OrderResult, Position,
    ORDER_TYPE_BUY, ORDER_TYPE_SELL,
    SYMBOL_POINT, SYMBOL_DIGITS, SYMBOL_TRADE_TICK_VALUE,
    SYMBOL_TRADE_TICK_SIZE, SYMBOL_TRADE_CONTRACT_SIZE,
    SYMBOL_VOLUME_MIN, SYMBOL_VOLUME_MAX, SYMBOL_VOLUME_STEP,
    SYMBOL_BID, SYMBOL_ASK, SYMBOL_SPREAD,
    ACCOUNT_BALANCE, ACCOUNT_EQUITY,
)


# ---------------------------------------------------------------------------
# Trade record (closed)
# ---------------------------------------------------------------------------
@dataclass
class TradeRecord:
    ticket:      int
    direction:   str
    entry:       float
    sl:          float
    tp:          float
    lots:        float
    open_time:   pd.Timestamp
    close_time:  pd.Timestamp
    exit_price:  float
    exit_reason: str    # "TP" | "SL"
    pnl_pips:    float
    pnl_r:       float


# ---------------------------------------------------------------------------
# MQL5Runtime
# ---------------------------------------------------------------------------
class MQL5Runtime:
    # Symbol spec (EURUSD defaults — EA can override via set_symbol_spec)
    SPEC = {
        "point":         0.00001,
        "digits":        5,
        "tick_value":    10.0,     # USD per pip per lot (EURUSD standard account)
        "tick_size":     0.00001,
        "contract_size": 100_000,
        "vol_min":       0.01,
        "vol_max":       100.0,
        "vol_step":      0.01,
    }

    def __init__(self, symbol: str = "EURUSD", initial_balance: float = 10_000.0):
        self.symbol  = symbol
        self.balance         = initial_balance
        self.initial_balance = initial_balance
        self.equity          = initial_balance

        # Current bar (set by engine each step)
        self._bar:     Optional[MqlRates]   = None
        self._bar_idx: int                  = 0
        self._history: List[MqlRates]       = []   # all bars seen so far

        # Open positions
        self._positions: List[Position] = []
        self._next_ticket = 1

        # Indicator handles: handle_int → (type_str, period)
        self._indicator_handles: Dict[int, tuple] = {}

        # Closed trades
        self.trades: List[TradeRecord] = []

    # -----------------------------------------------------------------------
    # Engine interface — called by the bar feed loop
    # -----------------------------------------------------------------------
    def _set_bar(self, bar: MqlRates, idx: int, history: List[MqlRates]) -> None:
        self._bar     = bar
        self._bar_idx = idx
        self._history = history

    def _check_sl_tp(self) -> None:
        """Check open positions against current bar high/low."""
        closed = []
        for pos in self._positions:
            bar = self._bar
            hit_tp = hit_sl = False

            if pos.direction == ORDER_TYPE_BUY:
                if bar.low  <= pos.sl: hit_sl = True
                elif pos.tp != 0.0 and bar.high >= pos.tp: hit_tp = True
            else:
                if bar.high >= pos.sl: hit_sl = True
                elif pos.tp != 0.0 and bar.low  <= pos.tp: hit_tp = True

            if hit_tp or hit_sl:
                exit_px = pos.tp if hit_tp else pos.sl
                pnl_price = (exit_px - pos.entry) if pos.direction == ORDER_TYPE_BUY \
                            else (pos.entry - exit_px)
                sl_dist = abs(pos.entry - pos.sl)
                pnl_pips = pnl_price / self.SPEC["point"] / 10  # to pips
                pnl_r    = pnl_price / sl_dist if sl_dist else 0.0
                pnl_usd  = pnl_pips * self.SPEC["tick_value"] * pos.lots

                self.balance += pnl_usd
                self.equity   = self.balance

                self.trades.append(TradeRecord(
                    ticket      = pos.ticket,
                    direction   = "BUY" if pos.direction == ORDER_TYPE_BUY else "SELL",
                    entry       = pos.entry,
                    sl          = pos.sl,
                    tp          = pos.tp,
                    lots        = pos.lots,
                    open_time   = pd.Timestamp(pos.ticket, unit="s"),  # placeholder
                    close_time  = pd.Timestamp(self._bar.time, unit="s"),
                    exit_price  = exit_px,
                    exit_reason = "TP" if hit_tp else "SL",
                    pnl_pips    = round(pnl_pips, 1),
                    pnl_r       = round(pnl_r, 3),
                ))
                closed.append(pos)

        for pos in closed:
            self._positions.remove(pos)

    # -----------------------------------------------------------------------
    # MQL5 API stubs — called by EA code
    # -----------------------------------------------------------------------

    def SymbolInfoDouble(self, symbol: str, prop: int) -> float:
        s = self.SPEC
        return {
            SYMBOL_POINT:               s["point"],
            SYMBOL_TRADE_TICK_VALUE:    s["tick_value"],
            SYMBOL_TRADE_TICK_SIZE:     s["tick_size"],
            SYMBOL_TRADE_CONTRACT_SIZE: s["contract_size"],
            SYMBOL_VOLUME_MIN:          s["vol_min"],
            SYMBOL_VOLUME_MAX:          s["vol_max"],
            SYMBOL_VOLUME_STEP:         s["vol_step"],
            SYMBOL_BID: self._bar.close if self._bar else 0.0,
            SYMBOL_ASK: self._bar.close + self.SPEC["point"] * 2 if self._bar else 0.0,
            SYMBOL_SPREAD: self._bar.spread if self._bar else 0.0,
        }.get(prop, 0.0)

    def SymbolInfoInteger(self, symbol: str, prop: int) -> int:
        if prop == SYMBOL_DIGITS:
            return self.SPEC["digits"]
        # SYMBOL_TRADE_MODE = 30; return FULL (4) so ValidateMarket passes
        if prop == 30:
            return 4
        return 0

    def AccountInfoDouble(self, prop: int) -> float:
        if prop == ACCOUNT_BALANCE: return self.balance
        if prop == ACCOUNT_EQUITY:  return self.equity
        return 0.0

    def CopyRates(self, symbol: str, tf: int, start: int, count: int,
                  out: list) -> int:
        """Return `count` bars starting `start` bars back from current."""
        if not self._history:
            return 0
        # start=1 means the last completed bar
        end_idx = self._bar_idx - start + 1
        begin   = max(0, end_idx - count)
        bars    = self._history[begin:end_idx]
        if out is None:
            return len(bars)
        out.clear()
        out.extend(bars)
        return len(bars)

    def CopyTickVolume(self, symbol: str, tf: int, start: int,
                       count: int, out: list) -> int:
        end_idx = self._bar_idx - start + 1
        begin   = max(0, end_idx - count)
        vols    = [b.tick_volume for b in self._history[begin:end_idx]]
        if out is None:
            return len(vols)
        out.clear()
        out.extend(vols)
        return len(vols)

    def _compute_atr(self, period, shift: int = 1) -> float:
        period  = int(period)
        end_idx = self._bar_idx - shift
        begin   = max(0, end_idx - period - 1)
        bars    = self._history[begin:end_idx + 1]
        if len(bars) < 2:
            return self.SPEC["point"] * 300
        trs = []
        for i in range(1, len(bars)):
            prev_close = bars[i-1].close
            tr = max(
                bars[i].high - bars[i].low,
                abs(bars[i].high - prev_close),
                abs(bars[i].low  - prev_close),
            )
            trs.append(tr)
        return sum(trs[-period:]) / min(period, len(trs))

    def _alloc_handle(self, spec: tuple) -> int:
        handle = self._next_ticket + 10000
        self._indicator_handles[handle] = spec
        self._next_ticket += 1
        return handle

    def iATR(self, symbol: str, tf: int, period: int, shift: int = 1) -> float:
        """Handle mode (3 args) returns a fake handle; direct mode (4 args) returns value."""
        if shift != 1:
            return self._compute_atr(period, shift)
        return self._alloc_handle(('ATR', period))

    def _compute_ma(self, period: int, shift: int, ma_method: int, price_type: int) -> float:
        end_idx = self._bar_idx - shift
        begin   = max(0, end_idx - period)
        bars    = self._history[begin:end_idx + 1]
        if not bars:
            return self._bar.close if self._bar else 0.0
        closes = [b.close for b in bars[-period:]]
        if not closes:
            return self._bar.close if self._bar else 0.0
        if ma_method == 1:  # EMA
            k = 2.0 / (len(closes) + 1)
            ema = closes[0]
            for c in closes[1:]:
                ema = c * k + ema * (1 - k)
            return ema
        return sum(closes) / len(closes)  # SMA default

    def iMA(self, symbol: str, tf: int, period: int, shift: int,
            ma_method: int, applied_price: int) -> int:
        """Returns indicator handle for CopyBuffer."""
        return self._alloc_handle(('MA', period, shift, ma_method, applied_price))

    def iRSI(self, symbol: str, tf: int, period: int, applied_price: int) -> int:
        return self._alloc_handle(('RSI', period, applied_price))

    def iStochastic(self, symbol: str, tf: int, k: int, d: int, slowing: int,
                    ma_method: int, price_field: int) -> int:
        return self._alloc_handle(('STOCH', k, d, slowing))

    def iCCI(self, symbol: str, tf: int, period: int, applied_price: int) -> int:
        return self._alloc_handle(('CCI', period, applied_price))

    def iMACD(self, symbol: str, tf: int, fast: int, slow: int, signal: int,
              applied_price: int) -> int:
        return self._alloc_handle(('MACD', fast, slow, signal))

    def iBands(self, symbol: str, tf: int, period: int, deviation: float,
               bands_shift: int, applied_price: int) -> int:
        return self._alloc_handle(('BANDS', period, deviation, bands_shift))

    def CopyBuffer(self, handle: int, buffer_idx: int, start: int, count: int,
                   out: list) -> int:
        """Read `count` values from indicator handle into out-list."""
        if handle not in self._indicator_handles:
            return -1
        spec = self._indicator_handles[handle]
        ind_type = spec[0]
        if ind_type == 'ATR':
            period = spec[1]
            values = [self._compute_atr(period, start + i) for i in range(count)]
        elif ind_type == 'MA':
            period, ma_shift, ma_method, price_type = spec[1], spec[2], spec[3], spec[4]
            values = [self._compute_ma(period, start + i + ma_shift, ma_method, price_type)
                      for i in range(count)]
        else:
            # Unknown indicator — return zeros (non-fatal)
            values = [0.0] * count
        if out is None:
            return len(values)
        if hasattr(out, 'clear'):
            out.clear()
            out.extend(values)
        else:
            out[:] = values
        return len(values)

    def MathMax(self, a: float, b: float) -> float: return max(a, b)
    def MathMin(self, a: float, b: float) -> float: return min(a, b)
    def MathAbs(self, a: float) -> float: return abs(a)
    def MathFloor(self, a: float) -> float: return math.floor(a)
    def MathRound(self, a: float) -> float: return round(float(a))
    def MathCeil(self, a: float) -> float: return math.ceil(a)
    def MathPow(self, a: float, b: float) -> float: return math.pow(a, b)
    def MathSqrt(self, a: float) -> float: return math.sqrt(a)
    def MathMod(self, a: float, b: float) -> float: return math.fmod(a, b)
    def MathLog(self, a: float) -> float: return math.log(a)
    def MathLog10(self, a: float) -> float: return math.log10(a)
    def MathExp(self, a: float) -> float: return math.exp(a)
    def MathSin(self, a: float) -> float: return math.sin(a)
    def MathCos(self, a: float) -> float: return math.cos(a)
    def MathRand(self) -> int: return 0
    def MathIsValidNumber(self, a: float) -> bool: return a == a and abs(a) != float('inf')

    def NormalizeDouble(self, value: float, digits: int) -> float:
        return round(value, digits)

    def StringFormat(self, fmt: str, *args) -> str:
        return fmt % args if args else fmt

    def ObjectCreate(self, *args) -> bool: return True
    def ObjectSetDouble(self, *args): pass
    def ObjectSetInteger(self, *args): pass
    def ObjectSetString(self, *args): pass
    def ObjectFind(self, *args) -> int: return -1
    def ObjectDelete(self, *args): pass
    def ObjectsDeleteAll(self, *args): pass
    def Print(self, *args): 
        import sys
        print("[EA]", *args, file=sys.stderr)
    def Alert(self, *args): pass
    def Comment(self, *args): pass

    # File I/O stubs (journal writes are no-ops in emulator)
    def FileOpen(self, *args) -> int: return -1
    def FileClose(self, handle: int) -> None: pass
    def FileWrite(self, handle: int, *args) -> int: return 0
    def FileWriteString(self, handle: int, s: str, length: int = -1) -> int: return 0
    def FileReadString(self, handle: int, length: int = -1) -> str: return ''
    def FileIsEnding(self, handle: int) -> bool: return True
    def FileSeek(self, handle: int, offset: int, origin: int) -> bool: return True
    def FileTell(self, handle: int) -> int: return 0
    def FileSize(self, handle: int) -> int: return 0
    def FileFlush(self, handle: int) -> None: pass
    def FileIsExist(self, path: str, common: int = 0) -> bool: return False
    def FileDelete(self, path: str, common: int = 0) -> bool: return False
    def FolderCreate(self, path: str, common: int = 0) -> bool: return False

    # Array helpers
    def ArrayResize(self, arr, new_size: int, reserve: int = 0) -> int:
        if hasattr(arr, 'extend'):
            arr.extend([None] * max(0, new_size - len(arr)))
        return new_size
    def ArraySetAsSeries(self, arr, flag: bool) -> bool: return True
    def ArrayIsSeries(self, arr) -> bool: return False
    def ArrayGetAsSeries(self, arr) -> bool: return False

    # Indicator stubs (iTime in handle-based callers)
    def iTime(self, symbol: str, tf: int, shift: int) -> int:
        idx = self._bar_idx - shift
        if 0 <= idx < len(self._history):
            return self._history[idx].time
        return 0
    def TimeCurrent(self) -> int: return self._bar.time if self._bar else 0
    def TimeLocal(self)   -> int: return self._bar.time if self._bar else 0

    def TimeToStruct(self, t: int, out) -> None:
        ts = pd.Timestamp(t, unit="s")
        out.year  = ts.year
        out.month = ts.month
        out.day   = ts.day
        out.hour  = ts.hour
        out.min   = ts.minute
        out.sec   = ts.second
        out.day_of_week = ts.dayofweek

    # -----------------------------------------------------------------------
    # Order execution
    # -----------------------------------------------------------------------
    def PlaceMarketOrder(self, req: OrderRequest, result: OrderResult) -> None:
        """Execute a market order. Fills result in-place."""
        if not self._bar:
            result.success      = False
            result.rejectDetail = "no bar"
            return

        # Lot sizing
        lots = req.lots
        if lots <= 0.0:
            sl_dist  = abs((self._bar.close) - req.slPrice)
            sl_pips  = sl_dist / (self.SPEC["point"] * 10)
            risk_amt = self.balance * req.riskPercent / 100.0
            lots     = risk_amt / (sl_pips * self.SPEC["tick_value"])
            lots     = max(self.SPEC["vol_min"],
                       min(round(lots / self.SPEC["vol_step"]) * self.SPEC["vol_step"],
                           self.SPEC["vol_max"]))

        entry = self._bar.close  # market fill at bar close

        pos = Position(
            ticket    = self._next_ticket,
            direction = req.orderType,
            entry     = entry,
            sl        = req.slPrice,
            tp        = req.tpPrice,
            lots      = lots,
            magic     = req.magic,
            symbol    = req.symbol,
            comment   = req.comment,
        )
        self._positions.append(pos)
        self._next_ticket += 1

        result.success       = True
        result.ticket        = pos.ticket
        result.executedPrice = entry
        result.executedLots  = lots

    def OrderSend(self, request, result) -> bool:
        """MQL5 OrderSend — maps MqlTradeRequest → runtime actions.

        Handles three action types:
          - TRADE_ACTION_DEAL (1) with position > 0  → close existing position
          - TRADE_ACTION_DEAL (1) with position == 0  → open new position
          - TRADE_ACTION_SLTP  (6)                    → modify SL/TP in-place
        """
        if not self._bar:
            if result is not None:
                result.retcode = 10016  # invalid stops
            return False

        action      = getattr(request, 'action', 1) or 1
        position_ticket = getattr(request, 'position', 0) or 0

        # --- Close operation: TRADE_ACTION_DEAL with a position ticket ---
        if action == 1 and position_ticket > 0:
            for pos in self._positions[:]:
                if pos.ticket == position_ticket:
                    exit_px = request.price if (request.price and request.price > 0) else self._bar.close
                    pnl_price = (exit_px - pos.entry) if pos.direction == 0 else (pos.entry - exit_px)
                    sl_dist = abs(pos.entry - pos.sl) if (pos.sl or 0) > 0 else self.SPEC["point"] * 300
                    pnl_pips = pnl_price / self.SPEC["point"] / 10
                    pnl_r    = pnl_price / sl_dist if sl_dist else 0.0
                    pnl_usd  = pnl_pips * self.SPEC["tick_value"] * pos.lots

                    self.balance += pnl_usd
                    self.equity   = self.balance

                    self.trades.append(TradeRecord(
                        ticket      = pos.ticket,
                        direction   = "BUY" if pos.direction == 0 else "SELL",
                        entry       = pos.entry,
                        sl          = pos.sl,
                        tp          = pos.tp,
                        lots        = pos.lots,
                        open_time   = pd.Timestamp(pos.ticket, unit="s"),
                        close_time  = pd.Timestamp(self._bar.time, unit="s"),
                        exit_price  = exit_px,
                        exit_reason = "Close",
                        pnl_pips    = round(pnl_pips, 1),
                        pnl_r       = round(pnl_r, 3),
                    ))
                    self._positions.remove(pos)

                    if result is not None:
                        result.retcode = 10009   # TRADE_RETCODE_DONE
                        result.order   = position_ticket
                        result.volume  = pos.lots
                        result.price   = exit_px
                        result.comment = "closed"
                    return True
            # Position not found — still return True so the EA doesn't retry
            # (MQL5 semantics: retcode != DONE signals error)
            if result is not None:
                result.retcode = 10006   # TRADE_RETCODE_REJECT
                result.comment = "position not found"
            return False

        # --- Modify SL/TP: TRADE_ACTION_SLTP ---
        if action == 6:
            sl_ticket = getattr(request, 'position', 0) or 0
            if sl_ticket > 0:
                for pos in self._positions:
                    if pos.ticket == sl_ticket:
                        req_sl = getattr(request, 'sl', None)
                        req_tp = getattr(request, 'tp', None)
                        if req_sl is not None and req_sl > 0:
                            pos.sl = req_sl
                        if req_tp is not None and req_tp > 0:
                            pos.tp = req_tp
                        break
            if result is not None:
                result.retcode = 10009
            return True

        # --- Open new position ---
        lots = request.volume or 0.0
        sl_price = request.sl or 0.0
        tp_price = request.tp or 0.0
        order_type = request.type if request.type is not None else 0

        if lots <= 0.0:
            sl_dist = abs(self._bar.close - sl_price) if sl_price else self.SPEC["point"] * 300
            sl_pips = sl_dist / (self.SPEC["point"] * 10)
            risk_amt = self.balance * 0.01  # default 1% risk
            if sl_pips > 0:
                lots = risk_amt / (sl_pips * self.SPEC["tick_value"])
            lots = max(self.SPEC["vol_min"],
                       min(round(lots / self.SPEC["vol_step"]) * self.SPEC["vol_step"],
                           self.SPEC["vol_max"]))

        entry = request.price if (request.price and request.price > 0) else self._bar.close

        pos = Position(
            ticket    = self._next_ticket,
            direction = order_type,
            entry     = entry,
            sl        = sl_price,
            tp        = tp_price,
            lots      = lots,
            magic     = request.magic or 0,
            symbol    = request.symbol or self.symbol,
            comment   = request.comment or "",
        )
        self._positions.append(pos)
        self._next_ticket += 1

        if result is not None:
            result.retcode = 10009   # TRADE_RETCODE_DONE
            result.order   = pos.ticket
            result.volume  = lots
            result.price   = entry
            result.comment = "ok"

        return True

    def PositionsTotal(self, magic: Optional[int] = None) -> int:
        if magic is None:
            return len(self._positions)
        return sum(1 for p in self._positions if p.magic == magic)

    def GetPositions(self, magic: Optional[int] = None) -> List[Position]:
        if magic is None:
            return list(self._positions)
        return [p for p in self._positions if p.magic == magic]

    def PositionSelect(self, symbol: str) -> bool:
        for p in self._positions:
            if p.symbol == symbol:
                self._selected_position = p
                return True
        self._selected_position = None
        return False

    def PositionSelectByTicket(self, ticket: int) -> bool:
        for p in self._positions:
            if p.ticket == ticket:
                self._selected_position = p
                return True
        self._selected_position = None
        return False

    def PositionGetTicket(self, index: int) -> int:
        if 0 <= index < len(self._positions):
            return self._positions[index].ticket
        return 0

    def PositionGetInteger(self, prop: int) -> int:
        pos = getattr(self, '_selected_position', None)
        if pos is None and self._positions:
            pos = self._positions[0]
        if pos is None:
            return 0
        # POSITION_TICKET=1, POSITION_TYPE=2, POSITION_VOLUME=3, POSITION_MAGIC=9
        if prop == 1:   return pos.ticket             # POSITION_TICKET
        if prop == 2:   return pos.direction          # POSITION_TYPE
        if prop == 3:   return int(pos.lots)          # POSITION_VOLUME
        if prop == 9:   return pos.magic              # POSITION_MAGIC
        return 0

    def PositionModify(self, ticket: int, sl: float, tp: float = 0.0) -> bool:
        """Modify an open position's SL/TP by ticket. Returns True on success."""
        for pos in self._positions:
            if pos.ticket == ticket:
                pos.sl = sl
                if tp != 0.0:
                    pos.tp = tp
                return True
        return False

    def PositionGetDouble(self, prop: int) -> float:
        pos = getattr(self, '_selected_position', None)
        if pos is None and self._positions:
            pos = self._positions[0]
        if pos is None:
            return 0.0
        # POSITION_VOLUME=3 (bridge constant for lots-as-double),
        # POSITION_PRICE_OPEN=4, POSITION_SL=5, POSITION_TP=6
        if prop == 3:   return pos.lots      # POSITION_VOLUME (used as double)
        if prop == 4:   return pos.entry
        if prop == 5:   return pos.sl
        if prop == 6:   return pos.tp
        return 0.0

    def GetLastError(self) -> int:
        return 0

    def ResetLastError(self) -> None:
        pass

    def HistorySelect(self, from_time: int, to_time: int) -> bool:
        # In the emulator, closed trade history is always available via self.trades.
        # Store the filtered slice so HistoryDealsTotal/HistoryDealSelect can use it.
        self._history_deals = [
            t for t in self.trades
            if from_time <= int(t.close_time.timestamp()) <= to_time
        ]
        return True

    def HistoryDealsTotal(self) -> int:
        return len(getattr(self, '_history_deals', []))

    def HistoryDealGetTicket(self, index: int) -> int:
        deals = getattr(self, '_history_deals', [])
        if 0 <= index < len(deals):
            self._selected_deal = deals[index]
            return deals[index].ticket
        return 0

    def HistoryDealSelect(self, ticket: int) -> bool:
        """Select a deal by ticket number (not index)."""
        deals = getattr(self, '_history_deals', [])
        for deal in deals:
            if deal.ticket == ticket:
                self._selected_deal = deal
                return True
        self._selected_deal = None
        return False

    def HistoryDealGetDouble(self, ticket: int, prop: int) -> float:
        deal = getattr(self, '_selected_deal', None)
        if deal is None:
            return 0.0
        # DEAL_PROFIT=11, DEAL_VOLUME=7, DEAL_PRICE=8
        if prop == 11: return deal.pnl_pips * self.SPEC["tick_value"] * deal.lots
        if prop == 7:  return deal.lots
        if prop == 8:  return deal.exit_price
        return 0.0

    def HistoryDealGetInteger(self, ticket: int, prop: int) -> int:
        deal = getattr(self, '_selected_deal', None)
        if deal is None:
            return 0
        # DEAL_TICKET=1, DEAL_TYPE=4, DEAL_MAGIC=12
        if prop == 1:  return deal.ticket
        if prop == 4:  return 0 if deal.direction == "BUY" else 1
        if prop == 12: return 0  # magic not stored in TradeRecord
        return 0

    def IndicatorRelease(self, handle: int) -> bool:
        self._indicator_handles.pop(handle, None)
        return True
