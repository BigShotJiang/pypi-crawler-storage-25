# MQL5 type constants and enums
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Optional

# --- Order types ---
ORDER_TYPE_BUY  = 0
ORDER_TYPE_SELL = 1

# --- Symbol info constants ---
SYMBOL_POINT              = 1
SYMBOL_DIGITS             = 2
SYMBOL_TRADE_TICK_VALUE   = 3
SYMBOL_TRADE_TICK_SIZE    = 4
SYMBOL_TRADE_CONTRACT_SIZE = 5
SYMBOL_VOLUME_MIN         = 6
SYMBOL_VOLUME_MAX         = 7
SYMBOL_VOLUME_STEP        = 8
SYMBOL_BID                = 9
SYMBOL_ASK                = 10
SYMBOL_SPREAD             = 11

# --- Account info constants ---
ACCOUNT_BALANCE  = 1
ACCOUNT_EQUITY   = 2
ACCOUNT_MARGIN   = 3

# --- Timeframes ---
PERIOD_H1 = 16385

# --- MqlRates equivalent ---
@dataclass
class MqlRates:
    time:        int    = 0
    open:        float  = 0.0
    high:        float  = 0.0
    low:         float  = 0.0
    close:       float  = 0.0
    tick_volume: int    = 0
    spread:      int    = 0
    real_volume: int    = 0

# --- Order structures ---
@dataclass
class OrderRequest:
    symbol:      str   = ""
    orderType:   int   = ORDER_TYPE_BUY
    entryPrice:  float = 0.0   # 0 = market
    slPrice:     float = 0.0
    tpPrice:     float = 0.0
    lots:        float = 0.0   # 0 = auto-size
    riskPercent: float = 1.0
    magic:       int   = 0
    comment:     str   = ""

@dataclass
class OrderResult:
    success:       bool  = False
    ticket:        int   = 0
    executedPrice: float = 0.0
    executedLots:  float = 0.0
    rejectDetail:  str   = ""

# --- MqlDateTime equivalent ---
@dataclass
class MqlDateTime:
    year:    int = 0
    mon:     int = 0
    day:     int = 0
    hour:    int = 0
    min:     int = 0
    sec:     int = 0
    day_of_week: int = 0
    day_of_year: int = 0

# --- Open position ---
@dataclass
class Position:
    ticket:    int
    direction: int   # ORDER_TYPE_BUY / ORDER_TYPE_SELL
    entry:     float
    sl:        float
    tp:        float
    lots:      float
    magic:     int
    symbol:    str
    comment:   str   = ""
