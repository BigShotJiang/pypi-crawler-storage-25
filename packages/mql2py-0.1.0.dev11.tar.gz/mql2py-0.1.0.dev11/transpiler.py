# transpiler.py — MQL5 → Python source transpiler
#
# Converts MQL5 (.mq5/.mqh) source text into executable Python source.
# Handles the subset of MQL5 actually used in the Kairos framework.
#
# Strategy: line-by-line regex rewriting + context-aware block transforms.
# Unknown constructs are left as comments so errors surface at runtime, not
# at parse time.

from __future__ import annotations
import re
from typing import Optional


# ---------------------------------------------------------------------------
# Token-level rewrites (applied in order to every line)
# ---------------------------------------------------------------------------

# Each entry: (compiled_regex, replacement_string_or_callable)
_LINE_RULES: list[tuple] = [

    # --- Strip preprocessor guards (handled by bridge) ---
    (re.compile(r'^\s*#ifndef\b.*$'), ''),
    (re.compile(r'^\s*#ifdef\b.*$'),  ''),
    (re.compile(r'^\s*#endif\b.*$'),  ''),
    (re.compile(r'^\s*#define\s+\w+\s*$'), ''),   # bare defines (include guards)
    (re.compile(r'^\s*#include\b.*$'), ''),         # handled by bridge
    (re.compile(r'^\s*#property\b.*$'), ''),

    # --- ternary operators ---
    # Form 1: (cond ? a : b) — entire ternary parenthesized, cond has no comma/?
    (re.compile(r'\(([^(),?]+)\?([^():]+):([^()]+)\)'),
     lambda m: (f'({m.group(2).strip()} if {m.group(1).strip()} else {m.group(3).strip()})'
                if ',' not in m.group(1) else m.group(0))),
    # Form 1b: chained ternary (cond1) ? v1 : (cond2) ? v2 : v3
    # Must be matched before Form 2 to avoid partial match leaving ? dangling.
    (re.compile(r'\(([^()]+)\)\s*\?\s*([^:?]+?)\s*:\s*\(([^()]+)\)\s*\?\s*([^:?]+?)\s*:\s*([^,;()]+)'),
     lambda m: f'({m.group(2).strip()} if ({m.group(1).strip()}) else ({m.group(4).strip()} if ({m.group(3).strip()}) else {m.group(5).strip()}))'),
    # Form 2: (cond) ? a : b — condition parenthesized, values are simple exprs
    (re.compile(r'\(([^()]+)\)\s*\?\s*([^:,;]+?)\s*:\s*([^,;)]+)'),
     lambda m: f'({m.group(2).strip()} if ({m.group(1).strip()}) else {m.group(3).strip()})'),
    # Form 2b: cond ? (parenthesized_expr) : value — true-branch has parens
    (re.compile(r'(?<![=!<>?])(\b\w[\w.]*\b)\s*\?\s*\(([^()]+)\)\s*:\s*([^,;()]+)'),
     lambda m: f'(({m.group(2).strip()}) if {m.group(1).strip()} else {m.group(3).strip()})'),
    # Form 3: bare simple ternary: word ? word : word (not preceded by dot — not a member access)
    (re.compile(r'(?<!\.)(\b\w+\b)\s*\?\s*(\b\w+\b)\s*:\s*(\b\w+\b)'),
     lambda m: f'({m.group(2)} if {m.group(1)} else {m.group(3)})'),
    # Form 4: expr with array subscript: word[idx] ? a : b
    (re.compile(r'(\w+\[[^\]]+\])\s*\?\s*([^:,;()]+?)\s*:\s*([^,;()]+)'),
     lambda m: f'({m.group(2).strip()} if {m.group(1).strip()} else {m.group(3).strip()})'),
    # Form 5: general ternary as argument: expr ? a : b where expr has no comma/parens/={}/
    # Used for cases like: func(arg, cond ? a : b)
    # Condition must not start with keywords (return/if/while) or contain braces
    (re.compile(r'(?<!return )(?<!return\t)([^,()=?{}/\s][^,()={}]*?[^,()=?{}/\s])\s*\?\s*([^:,()]+?)\s*:\s*([^,();{}]+)'),
     lambda m: (f'({m.group(2).strip()} if {m.group(1).strip()} else {m.group(3).strip()})'
                if '?' not in m.group(1) and '?' not in m.group(2)
                and not re.match(r'^(return|if|while|for)\b', m.group(1).strip())
                else m.group(0))),

    # --- #define constants → Python assignments ---
    (re.compile(r'^\s*#define\s+(\w+)\s+(.+)$'),
     lambda m: f'{m.group(1)} = {_expr(m.group(2))}'),

    # --- input variables → class field in Inputs ---
    # input double InpBreakATR = 1.0;  →  InpBreakATR: float = 1.0
    (re.compile(r'^\s*input\s+group\s+"[^"]*"\s*;?\s*$'),
     ''),  # input group labels → skip
    (re.compile(
        r'^\s*input\s+(?:const\s+)?(\w+)\s+(\w+)\s*=\s*(.+?);'),
     lambda m: f'    {m.group(2)}: {_mql_type(m.group(1))} = {_expr(m.group(3))}'),

    # --- anonymous inline enum: enum { NAME = val };  →  NAME = val ---
    (re.compile(r'^\s*enum\s*\{\s*(\w+)\s*=\s*(\d+)\s*\}\s*;'),
     lambda m: f'{m.group(1)} = {m.group(2)}'),

    # --- enum block opener ---
    (re.compile(r'^\s*enum\s+(\w+)$'),
     lambda m: f'class {m.group(1)}(IntEnum):'),
    (re.compile(r'^\s*enum\s+(\w+)\s*$'),
     lambda m: f'class {m.group(1)}(IntEnum):'),

    # --- enum entries: FOO = 0,  →  FOO = 0 ---
    (re.compile(r'^(\s*)(\w+)\s*=\s*(-?\d+)\s*,?\s*(?://.*)?$'),
     lambda m: f'{m.group(1)}{m.group(2)} = {m.group(3)}'),
    # auto-increment enum entries (no value): FOO,
    # handled in block transformer

    # --- struct → dataclass ---
    # Single-line: struct Foo { Type name; ... } → multi-line dataclass
    (re.compile(r'^\s*struct\s+(\w+)\s*\{([^}]*)\}\s*;?$'),
     lambda m: _inline_struct(m.group(1), m.group(2))),
    (re.compile(r'^\s*struct\s+(\w+)$'),
     lambda m: f'@dataclass\nclass {m.group(1)}:'),

    # --- class declaration with inheritance ---
    # All MQL5 classes become @dataclass so field() annotations work uniformly.
    # init=False: MQL5 constructors are transpiled as def __init__; don't override.
    # eq=False: avoids conflicts if subclass defines __eq__.
    (re.compile(r'^\s*class\s+(\w+)\s*:\s*public\s+(\w+)$'),
     lambda m: f'@dataclass(init=False, eq=False)\nclass {m.group(1)}({m.group(2)}):'),
    (re.compile(r'^\s*class\s+(\w+)$'),
     lambda m: f'@dataclass(init=False, eq=False)\nclass {m.group(1)}:'),

    # --- constructor  ClassName::ClassName() → def __init__(self): ---
    # Make all constructor parameters optional (default=None) so that overloaded
    # constructors in MQL5 (zero-arg + one-arg) don't break when Python keeps only
    # the last definition and the EA tries to call ClassName() with no args.
    (re.compile(r'^\s*(\w+)::(\1)\s*\(\s*\)'),
     lambda m: f'    def __init__(self):'),
    (re.compile(r'^\s*(\w+)::(\1)\s*\(([^)]*)\)'),
     lambda m: f'    def __init__(self, {_params_optional(m.group(3))}):'),

    # --- access specifiers → strip ---
    (re.compile(r'^\s*(public|private|protected)\s*:\s*$'), ''),

    # --- constructor initializer list: :m_x(0), m_y(1) → strip ---
    (re.compile(r'^\s*:\s*\w+\s*\([^)]*\)(?:\s*,\s*\w+\s*\([^)]*\))*\s*$'), ''),

    # --- constructor declarations: ClassName(TypeName param); ---
    # Zero-param ClassName(); — only strip if it matches MQL5 class convention (C prefix)
    # since standalone calls like PurgeStaleTickets() must not be stripped.
    (re.compile(r'^\s*C[A-Z]\w+\s*\(\s*\)\s*;\s*$'), ''),
    # With typed parameters:
    (re.compile(
        r'^\s*[A-Z]\w+\s*\(\s*'
        r'(?:const\s+)?(?:double|float|int|uint|long|ulong|bool|string|datetime|'
        r'void|color|ENUM_\w+|[A-Z]\w+)\s+[&*]?\w+(?:\s*,\s*'
        r'(?:const\s+)?(?:double|float|int|uint|long|ulong|bool|string|datetime|'
        r'void|color|ENUM_\w+|[A-Z]\w+)\s+[&*]?\w+)*\s*\)\s*;\s*$'
    ), ''),

    # --- single-line method body: RetType Class::Method() { stmt; } → def M(): stmt ---
    (re.compile(
        r'^\s*(?:virtual\s+|static\s+|override\s+)?(?:const\s+)?(\w+)\s+(\w+)::(\w+)\s*\(([^)]*)\)'
        r'(?:\s*const)?\s*\{\s*([^}]+?)\s*;?\s*\}'),
     lambda m: (lambda body: f'    def {m.group(3)}(self{", " + _params(m.group(4)) if m.group(4).strip() else ""}): '
                             f'{"return " + _expr(body[7:].strip()) if body.startswith("return ") else _expr(body)}'
                )(m.group(5).strip().rstrip(";"))),

    # --- inline method with empty body: RetType Method(...) {} → def M(self, ...): pass ---
    (re.compile(
        r'^\s*(?:virtual\s+|static\s+|override\s+)?(?:const\s+)?'
        r'(?:double|float|int|uint|long|ulong|short|ushort|uchar|char|bool|string|void|datetime|color|ENUM_\w+|[A-Z]\w+)\s+'
        r'(\w+)\s*\(([^)]*)\)(?:\s*const)?\s*\{\s*\}'),
     lambda m: f'    def {m.group(1)}(self{", " + _params(m.group(2)) if m.group(2).strip() else ""}): pass'),

    # --- inline method (no scope): RetType Method() { stmt; } → def M(self): stmt ---
    # Must have a known or uppercase return type and braced single-statement body
    (re.compile(
        r'^\s*(?:virtual\s+|static\s+|override\s+)?(?:const\s+)?'
        r'(?:double|float|int|uint|long|ulong|short|ushort|uchar|char|bool|string|void|datetime|color|ENUM_\w+|[A-Z]\w+)\s+'
        r'(\w+)\s*\(([^)]*)\)(?:\s*const)?\s*\{\s*([^}]+?)\s*;?\s*\}'),
     lambda m: (lambda body: f'    def {m.group(1)}(self{", " + _params(m.group(2)) if m.group(2).strip() else ""}): '
                             f'{"return " + _expr(body[7:].strip()) if body.startswith("return ") else _expr(body)}'
                )(m.group(3).strip().rstrip(";"))),

    # --- destructor definition: ClassName::~ClassName() → def __del__(self): ---
    (re.compile(r'^\s*(\w+)::~\1\s*\(\s*\)'),
     lambda m: '    def __del__(self):'),
    # --- destructor declaration/inline: ~ClassName(); or virtual ~ClassName() {} → strip ---
    (re.compile(r'^\s*(?:\w+::)?(?:virtual\s+)?~\w+\s*\(\s*\)\s*\{?\s*\}?.*$'), ''),

    # --- method definition  RetType ClassName::Method(...) ---
    (re.compile(r'^\s*(?:virtual\s+|static\s+|override\s+)?'
                r'(?:const\s+)?(\w+)\s+(\w+)::(\w+)\s*\(([^)]*)\)(?:\s*const)?'),
     lambda m: f'    def {m.group(3)}(self, {_params(m.group(4))}):' if m.group(4).strip()
               else f'    def {m.group(3)}(self):'),

    # --- indented class method declaration (no ::, no braced body): adds self ---
    # Matches method declarations inside a class body (indented ≥3 spaces).
    # Must come BEFORE the standalone function rule so indented methods get self.
    (re.compile(r'^(\s{3,})(?:virtual\s+|static\s+|override\s+)?(?:const\s+)?'
                r'(?:double|float|int|uint|long|ulong|short|ushort|uchar|char|bool|string|void|datetime|color|ENUM_\w+|[A-Z]\w+)\s+'
                r'(\w+)\s*\(([^)]*)\)(?:\s*const)?$'),
     lambda m: (f'    def {m.group(2)}(self{", " + _params(m.group(3)) if m.group(3).strip() else ""}):')),

    # --- standalone function definition: bool IsNewBar(...) → def IsNewBar(...): ---
    # Requires lowercase return type (not a class constructor) and no :: in the line
    # Only matches at column 0 (no leading whitespace beyond optional spaces)
    (re.compile(r'^(?:static\s+)?(?:const\s+)?((?:double|float|int|uint|long|ulong|bool|string|datetime|void|ENUM_\w+))\s+(\w+)\s*\(([^)]*)\)(?:\s*const)?$'),
     lambda m: f'def {m.group(2)}({_params(m.group(3))}):'),

    # --- inline method (no scope)  void Method(...) const ---
    # Restrict return type to known MQL5 types to avoid matching "return Func(args);"
    (re.compile(r'^\s*(?:virtual\s+|static\s+|override\s+)?'
                r'(?:const\s+)?(?:double|float|int|uint|long|ulong|short|ushort|uchar|char|bool|string|void|datetime|color|ENUM_\w+)\s+'
                r'(\w+)\s*\(([^)]*)\)(?:\s*const)?(?:\s*=\s*0)?\s*;'),
     ''),  # pure declaration → skip
    # --- user-defined return type method declaration: UserType Method(...) const; ---
    (re.compile(r'^\s*(?:virtual\s+|static\s+|override\s+)?(?:const\s+)?[A-Z]\w+\s+'
                r'\w+\s*\([^)]*\)(?:\s*const)?(?:\s*=\s*0)?\s*;'),
     ''),  # pure declaration with user-defined return type → skip

    # --- strip MQL5 storage specifiers: static/extern on local var declarations ---
    (re.compile(r'^(\s*)static\s+(?=(?:double|float|int|long|uint|ulong|short|ushort|uchar|char|color|bool|string|datetime|ENUM_\w+)\s+\w)'),
     r'\1'),

    # --- variable declarations ---
    # double x = 1.0;  →  x: float = 1.0
    (re.compile(r'^\s*(double|float)\s+(\w+)\s*=\s*(.+?);'),
     lambda m: f'{m.group(2)}: float = {_expr(m.group(3))}'),
    (re.compile(r'^\s*(int|long|uint|ulong|short|ushort|uchar|char|color|ENUM_\w+)\s+(\w+)\s*=\s*(.+?);'),
     lambda m: f'{m.group(2)}: int = {_int_expr(m.group(3))}'),
    (re.compile(r'^\s*bool\s+(\w+)\s*=\s*(.+?);'),
     lambda m: f'{m.group(1)}: bool = {_expr(m.group(2))}'),
    (re.compile(r'^\s*string\s+(\w+)\s*=\s*(.+?);'),
     lambda m: f'{m.group(1)}: str = {_expr(m.group(2))}'),
    # declaration without initialiser
    (re.compile(r'^\s*(double|float)\s+(\w+)\s*;'),
     lambda m: f'{m.group(2)}: float = 0.0'),
    (re.compile(r'^\s*(int|long|uint|ulong|short|ushort|uchar|char|color|ENUM_\w+)\s+(\w+)\s*;'),
     lambda m: f'{m.group(2)}: int = 0'),
    (re.compile(r'^\s*bool\s+(\w+)\s*;'),
     lambda m: f'{m.group(1)}: bool = False'),
    (re.compile(r'^\s*string\s+(\w+)\s*;'),
     lambda m: f'{m.group(1)}: str = ""'),
    (re.compile(r'^\s*datetime\s+(\w+)\s*(?:=\s*(.+?))?\s*;'),
     lambda m: f'{m.group(1)}: int = {_int_expr(m.group(2)) if m.group(2) else "0"}'),
    # Multi-var declarations: int a, b, c;  →  a: int = 0\nb: int = 0\nc: int = 0
    (re.compile(r'^\s*(double|float)\s+((?:\w+\s*,\s*)+\w+)\s*;'),
     lambda m: '\n'.join(f'{v.strip()}: float = 0.0' for v in m.group(2).split(','))),
    (re.compile(r'^\s*(int|long|uint|ulong|short|ushort|uchar|char|color|ENUM_\w+)\s+((?:\w+\s*,\s*)+\w+)\s*;'),
     lambda m: '\n'.join(f'{v.strip()}: int = 0' for v in m.group(2).split(','))),
    (re.compile(r'^\s*bool\s+((?:\w+\s*,\s*)+\w+)\s*;'),
     lambda m: '\n'.join(f'{v.strip()}: bool = False' for v in m.group(1).split(','))),
    (re.compile(r'^\s*string\s+((?:\w+\s*,\s*)+\w+)\s*;'),
     lambda m: '\n'.join(f'{v.strip()}: str = ""' for v in m.group(1).split(','))),
    # Multi-var: datetime a, b;  → a: int = 0\nb: int = 0
    (re.compile(r'^\s*datetime\s+((?:\w+\s*,\s*)+\w+)\s*;'),
     lambda m: '\n'.join(f'{v.strip()}: int = 0' for v in m.group(1).split(','))),

    # --- user-defined type instantiation with args: CLogger log("name"); → log = CLogger("name") ---
    (re.compile(r'^\s*([A-Z]\w+)\s+(\w+)\s*\(([^)]*)\)\s*;'),
     lambda m: f'{m.group(2)} = {m.group(1)}({m.group(3)})'),

    # --- user-defined type variable with assignment: MqlRates bar = rates[i]; → bar = rates[i] ---
    (re.compile(r'^\s*([A-Z]\w+)\s+(\w+)\s*=\s*(.+?)\s*;'),
     lambda m: f'{m.group(2)} = {_expr(m.group(3))}'),

    # --- multi-variable user-defined type declaration: MqlRates cur, prev; → cur = None\nprev = None ---
    (re.compile(r'^\s*([A-Z]\w+)\s+[*&]?((?:\w+\s*,\s*)+\w+)\s*;'),
     lambda m: '\n'.join(f'{v.strip()} = None' for v in m.group(2).split(','))),

    # --- user-defined type field declaration without initializer (struct/class fields) ---
    # CLogger m_log;       →  m_log: object = None  # __init__ will instantiate
    # CNewsFilter *filter; →  filter: object = None  (pointer — stays None until assigned)
    # We tag value-type (non-pointer) fields with a comment so _inject_self can
    # insert `self.field = ClassName()` at the top of __init__.
    (re.compile(r'^\s*([A-Z]\w+)\s+[*&](\w+)\s*;'),
     lambda m: f'{m.group(2)}: object = None'),
    (re.compile(r'^\s*([A-Z]\w+)\s+(\w+)\s*;'),
     lambda m: f'{m.group(2)}: object = None  # _mql5_ctor:{m.group(1)}'),

    # --- array declarations → Python list ---
    # Class-level fields (≤4 leading spaces): tag with _mql5_list so _inject_self
    # can emit self.x = [...] in __init__.
    # Method-local variables (>4 spaces indent): emit = [...] directly.
    (re.compile(r'^\s*(\w+)\s+(\w+)\s*\[\s*\]\s*=\s*\{([^}]*)\}\s*;?\s*(?://.*|#.*)?$'),
     lambda m: (f'{m.group(2)}: list = None  # _mql5_list:[{m.group(3)}]'
                if len(m.group(0)) - len(m.group(0).lstrip()) <= 4
                else f'{m.group(2)} = [{m.group(3)}]')),
    (re.compile(r'^\s*(\w+)\s+(\w+)\s*\[\s*[\w+\-*/ ]+\s*\]\s*=\s*\{([^}]*)\}\s*;?\s*(?://.*|#.*)?$'),
     lambda m: (f'{m.group(2)}: list = None  # _mql5_list:[{m.group(3)}]'
                if len(m.group(0)) - len(m.group(0).lstrip()) <= 4
                else f'{m.group(2)} = [{m.group(3)}]')),
    # Without initializer (empty or sized)
    (re.compile(r'^\s*(?!return\b|if\b|for\b|while\b|else\b|switch\b|case\b|break\b|continue\b|delete\b)(\w+)\s+(\w+)\s*\[\s*\]\s*;?\s*(?://.*|#.*)?$'),
     lambda m: (f'{m.group(2)}: list = None  # _mql5_list:[]'
                if len(m.group(0)) - len(m.group(0).lstrip()) <= 4
                else f'{m.group(2)} = _AutoList()')),
    (re.compile(r'^\s*(?!return\b|if\b|for\b|while\b|else\b|switch\b|case\b|break\b|continue\b|delete\b)(\w+)\s+(\w+)\s*\[\s*[\w+\-*/ ]+\s*\]\s*;?\s*(?://.*|#.*)?$'),
     lambda m: (f'{m.group(2)}: list = None  # _mql5_list:[]'
                if len(m.group(0)) - len(m.group(0).lstrip()) <= 4
                else f'{m.group(2)} = _AutoList()')),

    # --- MQL5 type casts ---
    (re.compile(r'\((?:int|uint|long|ulong|short|ushort|uchar|char|double|float|bool|datetime|ENUM_\w+)\)\s*'), ''),
    (re.compile(r'\(string\)\s*'), 'str('),  # partial — needs closing paren

    # --- NULL → None ---
    (re.compile(r'\bNULL\b'), 'None'),

    # --- true/false → Python bools ---
    (re.compile(r'\btrue\b'), 'True'),
    (re.compile(r'\bfalse\b'), 'False'),

    # --- DBL_MAX ---
    (re.compile(r'\bDBL_MAX\b'), 'float("inf")'),

    # --- MQL5 Math functions ---
    (re.compile(r'\bMathMax\b'), '_rt.MathMax'),
    (re.compile(r'\bMathMin\b'), '_rt.MathMin'),
    (re.compile(r'\bMathAbs\b'), '_rt.MathAbs'),
    (re.compile(r'\bMathFloor\b'), '_rt.MathFloor'),
    (re.compile(r'\bMathSqrt\b'), 'math.sqrt'),
    (re.compile(r'\bMathPow\b'), 'math.pow'),
    (re.compile(r'\bMathLog\b'), 'math.log'),

    # --- MQL5 API → runtime calls ---
    (re.compile(r'\bSymbolInfoDouble\b'), '_rt.SymbolInfoDouble'),
    (re.compile(r'\bSymbolInfoInteger\b'), '_rt.SymbolInfoInteger'),
    (re.compile(r'\bAccountInfoDouble\b'), '_rt.AccountInfoDouble'),
    (re.compile(r'\bAccountInfoInteger\b'), '_rt.AccountInfoInteger'),
    (re.compile(r'\bCopyRates\b'), '_rt.CopyRates'),
    (re.compile(r'\bCopyTickVolume\b'), '_rt.CopyTickVolume'),
    (re.compile(r'\biATR\b'), '_rt.iATR'),
    (re.compile(r'\bNormalizeDouble\b'), '_rt.NormalizeDouble'),
    (re.compile(r'\bTimeToStruct\b'), '_rt.TimeToStruct'),
    (re.compile(r'\bObjectCreate\b'), '_rt.ObjectCreate'),
    (re.compile(r'\bObjectSetDouble\b'), '_rt.ObjectSetDouble'),
    (re.compile(r'\bObjectSetInteger\b'), '_rt.ObjectSetInteger'),
    (re.compile(r'\bObjectSetString\b'), '_rt.ObjectSetString'),
    (re.compile(r'\bObjectFind\b'), '_rt.ObjectFind'),
    (re.compile(r'\bObjectDelete\b'), '_rt.ObjectDelete'),
    (re.compile(r'\bObjectsDeleteAll\b'), '_rt.ObjectsDeleteAll'),
    (re.compile(r'\bPrint\b'), '_rt.Print'),
    (re.compile(r'\bAlert\b'), '_rt.Alert'),
    (re.compile(r'\bStringFormat\b'), '_rt.StringFormat'),
    (re.compile(r'\bArraySize\b'), 'len'),
    (re.compile(r'\bArrayResize\b'), '_rt.ArrayResize'),
    (re.compile(r'\bArraySetAsSeries\b'), '_rt.ArraySetAsSeries'),
    (re.compile(r'\bGetLastError\b'), '_rt.GetLastError'),
    (re.compile(r'\bResetLastError\b'), '_rt.ResetLastError'),
    (re.compile(r'\bTimeCurrent\b'), '_rt.TimeCurrent'),
    (re.compile(r'\biTime\b'), '_rt.iTime'),
    (re.compile(r'\bCopyBuffer\b'), '_rt.CopyBuffer'),
    (re.compile(r'\bIndicatorRelease\b'), '_rt.IndicatorRelease'),
    (re.compile(r'\bPositionSelect\b'), '_rt.PositionSelect'),
    (re.compile(r'\bPositionGetDouble\b'), '_rt.PositionGetDouble'),
    (re.compile(r'\bPositionGetInteger\b'), '_rt.PositionGetInteger'),
    (re.compile(r'\bPositionGetString\b'), '_rt.PositionGetString'),
    (re.compile(r'\bOrderSend\b'), '_rt.OrderSend'),
    (re.compile(r'\bOrderSelect\b'), '_rt.OrderSelect'),
    (re.compile(r'\bPositionModify\b'), '_rt.PositionModify'),
    (re.compile(r'\bHistorySelect\b'), '_rt.HistorySelect'),
    (re.compile(r'\bHistoryDealsTotal\b'), '_rt.HistoryDealsTotal'),
    (re.compile(r'\bHistoryDealSelect\b'), '_rt.HistoryDealSelect'),
    (re.compile(r'\bHistoryDealGetDouble\b'), '_rt.HistoryDealGetDouble'),
    (re.compile(r'\bHistoryDealGetInteger\b'), '_rt.HistoryDealGetInteger'),
    (re.compile(r'\bFileOpen\b'), '_rt.FileOpen'),
    (re.compile(r'\bFileClose\b'), '_rt.FileClose'),
    (re.compile(r'\bFileWrite\b'), '_rt.FileWrite'),
    (re.compile(r'\bFileFlush\b'), '_rt.FileFlush'),
    (re.compile(r'\bFileSeek\b'), '_rt.FileSeek'),
    (re.compile(r'\bFileIsExist\b'), '_rt.FileIsExist'),

    # --- C-style for loops → Python range ---
    # Must come BEFORE operator rewrites (&&→and, ++→+=1) since patterns match raw C syntax.
    # for(int i = 0; i < N; i++)     →  for i in range(0, N):
    # for(int i = lo; i <= hi; i++)  →  for i in range(lo, hi + 1):
    # for(int i = N-1; i >= 0; i--) →  for i in range(N-1, -1, -1):
    # Each pattern has two variants: with trailing { and without.

    # i < N, i++ or i += 1
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*<(?!=)\s*([^;]+);\s*\1\s*\+=\s*1\s*\)\s*\{$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3))}):\n{{'),
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*<(?!=)\s*([^;]+);\s*\1\s*\+=\s*1\s*\)\s*$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3))}):'),
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*<(?!=)\s*([^;]+);\s*\1\+\+\s*\)\s*\{$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3))}):\n{{'),
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*<(?!=)\s*([^;]+);\s*\1\+\+\s*\)\s*$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3))}):'),

    # i <= end, i++ or i += 1 (simple)
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*<=\s*([^;&)]+?);\s*\1\+\+\s*\)\s*\{$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3).strip())} + 1):\n{{'),
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*<=\s*([^;&)]+?);\s*\1\+\+\s*\)\s*$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3).strip())} + 1):'),
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*<=\s*([^;&)]+?);\s*\1\s*\+=\s*1\s*\)\s*\{$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3).strip())} + 1):\n{{'),
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*<=\s*([^;&)]+?);\s*\1\s*\+=\s*1\s*\)\s*$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3).strip())} + 1):'),

    # i <= end && flag, i++ — compound condition: emit range + early-exit guard
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*<=\s*([^;&]+?)\s*&&\s*([^;)]+?);\s*\1\+\+\s*\)\s*\{$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3).strip())} + 1):\n    if not ({_expr(m.group(4).strip())}): break\n{{'),
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*<=\s*([^;&]+?)\s*&&\s*([^;)]+?);\s*\1\+\+\s*\)\s*$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3).strip())} + 1):\n    if not ({_expr(m.group(4).strip())}): break'),

    # i > N, i -= 1
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*>(?!=)\s*([^;]+);\s*\1\s*-=\s*1\s*\)\s*\{$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3))} - 1, -1):\n{{'),
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*>(?!=)\s*([^;]+);\s*\1\s*-=\s*1\s*\)\s*$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3))} - 1, -1):'),

    # i >= N, i -= 1 or i--
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*>=\s*([^;]+);\s*\1\s*-=\s*1\s*\)\s*\{$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3))} - 1, -1):\n{{'),
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*>=\s*([^;]+);\s*\1\s*-=\s*1\s*\)\s*$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3))} - 1, -1):'),
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*>=\s*([^;]+);\s*\1--\s*\)\s*\{$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3))} - 1, -1):\n{{'),
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*>=\s*([^;]+);\s*\1--\s*\)\s*$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3))} - 1, -1):'),

    # fallback: for(init; cond; incr) { → with preserved brace
    (re.compile(r'^\s*for\s*\(([^)]*)\)\s*\{$'),
     lambda m: f'for _loop_item in []:  # TODO: C-style for({m.group(1)})\n{{'),
    # fallback: for(init; cond; incr) → no brace
    (re.compile(r'^\s*for\s*\(([^)]*)\)\s*$'),
     lambda m: f'for _loop_item in []:  # TODO: C-style for({m.group(1)})'),

    # single-line for-loop with body on same line (no braces):
    # for(int i = 0; i < N; i++) body;  →  for i in range(0, N):\n    body
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*<(?!=)\s*([^;]+);\s*\1(?:\+\+|\s*\+=\s*1)\s*\)\s*(.+?)\s*;?\s*$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3))}):\n    {m.group(4).strip()}'),
    (re.compile(
        r'^\s*for\s*\(\s*(?:int\s+)?(\w+)\s*=\s*([^;]+);\s*\1\s*>=\s*([^;]+);\s*\1(?:--|\s*-=\s*1)\s*\)\s*(.+?)\s*;?\s*$'),
     lambda m: f'for {m.group(1)} in range({_expr(m.group(2))}, {_expr(m.group(3))} - 1, -1):\n    {m.group(4).strip()}'),

    # --- C++ → Python operators ---
    (re.compile(r'\s*&&\s*'), ' and '),
    (re.compile(r'\s*\|\|\s*'), ' or '),
    (re.compile(r'(?<![=!<>])!(?!=)'), 'not '),
    # --- C++ address-of / pointer: &var → var (Python passes by reference) ---
    (re.compile(r'=\s*&(\w)'), r'= \1'),
    # Strip & in function call arguments: foo(&bar) → foo(bar)
    (re.compile(r'\(\s*&(\w)'), r'(\1'),
    (re.compile(r',\s*&(\w)'), r', \1'),

    # --- C++ // comments → Python # comments ---
    (re.compile(r'//(.*)$'), r'#\1'),

    # --- increment / decrement operators ---
    (re.compile(r'(\w+)\+\+'), r'\1 += 1'),
    (re.compile(r'(\w+)--'), r'\1 -= 1'),
    (re.compile(r'\+\+(\w+)'), r'\1 += 1'),
    (re.compile(r'--(\w+)'), r'\1 -= 1'),

    # --- if(cond) → if cond: ---  (condition must not contain ; or # which indicate inline body or comment)
    # When { is present on same line, preserve it so block transformer can handle the closing }
    (re.compile(r'^\s*if\s*\(([^;#]+)\)\s*\{$'),
     lambda m: f'if {m.group(1)}:\n{{'),
    (re.compile(r'^\s*if\s*\(([^;#]+)\)\s*$'),
     lambda m: f'if {m.group(1)}:'),
    # --- else if(cond) → elif cond: ---
    (re.compile(r'^\s*else\s+if\s*\(([^;#]+)\)\s*\{$'),
     lambda m: f'elif {m.group(1)}:\n{{'),
    (re.compile(r'^\s*else\s+if\s*\(([^;#]+)\)\s*$'),
     lambda m: f'elif {m.group(1)}:'),
    # --- else { → else: ---
    (re.compile(r'^\s*else\s*\{$'),
     lambda m: 'else:\n{'),
    (re.compile(r'^\s*else\s*$'),
     lambda m: 'else:'),

    # --- while(cond) { → while cond: ---
    (re.compile(r'^\s*while\s*\((.+)\)\s*\{$'),
     lambda m: f'while {m.group(1)}:\n{{'),
    (re.compile(r'^\s*while\s*\((.+)\)\s*$'),
     lambda m: f'while {m.group(1)}:'),

    # --- single-line if(cond) stmt; [// or # comment] → if cond: stmt ---
    (re.compile(r'^\s*if\s*\((.+)\)\s+(.+?);\s*(?:[/#].*)?$'),
     lambda m: f'if {m.group(1)}: {m.group(2).strip()}'),

    # --- single-line while(cond) stmt; → while cond: stmt ---
    (re.compile(r'^\s*while\s*\((.+)\)\s+(.+?);\s*(?:[/#].*)?$'),
     lambda m: f'while {m.group(1)}: {m.group(2).strip()}'),

    # --- Semicolons at end of statements ---
    (re.compile(r';(\s*)$'), r'\1'),

    # --- Curly braces → Python blocks (handled in block transform) ---
]


# ---------------------------------------------------------------------------
# Type mapping
# ---------------------------------------------------------------------------

def _inline_struct(name: str, body: str) -> str:
    """Convert single-line struct Foo { T f1; T f2; } to a block-transformed form."""
    # Emit as multi-line MQL5 style so _transform_blocks handles indentation:
    # @dataclass\nclass Name:\n{\n    field: type = default\n}
    fields = []
    for field in re.split(r';', body):
        field = field.strip()
        if not field:
            continue
        parts = field.split()
        if len(parts) >= 2:
            py_type = _mql_type(parts[0]) if parts[0] in (
                'double', 'float', 'int', 'uint', 'long', 'ulong', 'bool', 'string', 'datetime', 'color') else 'object'
            fname = parts[1]
            default = '0.0' if py_type == 'float' else ('0' if py_type == 'int' else ('False' if py_type == 'bool' else ('""' if py_type == 'str' else 'None')))
            fields.append(f'{fname}: {py_type} = {default}')
    body_str = '\n'.join(fields) if fields else 'pass'
    return f'@dataclass\nclass {name}:\n{{\n{body_str}\n}}'


def _mql_type(t: str) -> str:
    return {
        'double': 'float', 'float': 'float',
        'int': 'int', 'uint': 'int', 'long': 'int', 'ulong': 'int',
        'bool': 'bool', 'string': 'str', 'datetime': 'int',
        'void': 'None', 'color': 'int', 'uchar': 'int', 'char': 'int',
        'short': 'int', 'ushort': 'int', 'ENUM_TIMEFRAMES': 'int',
    }.get(t, t)


def _params(params_str: str) -> str:
    """Convert MQL5 parameter list to Python parameter list."""
    if not params_str.strip():
        return ''
    result = []
    for param in params_str.split(','):
        param = param.strip()
        # Strip const, &, *, type keywords
        param = re.sub(r'\bconst\b', '', param)
        param = re.sub(r'[&*]', '', param)
        param = re.sub(r'\b(double|float|int|uint|long|ulong|bool|string|datetime|'
                       r'void|color|ENUM_\w+|\w+)\s+', '', param, count=1)
        # Remove array brackets
        param = re.sub(r'\[\s*\]', '', param)
        param = param.strip()
        if param:
            result.append(param)
    return ', '.join(result)


def _params_optional(params_str: str) -> str:
    """Like _params but makes every parameter optional (default=None).
    Used for overloaded MQL5 constructors so ClassName() always works."""
    raw = _params(params_str)
    if not raw:
        return ''
    return ', '.join(f'{p}=None' for p in raw.split(', '))


_EXPR_API_MAP = [
    (re.compile(r'\biATR\b'),            '_rt.iATR'),
    (re.compile(r'\bCopyRates\b'),       '_rt.CopyRates'),
    (re.compile(r'\bCopyTickVolume\b'),  '_rt.CopyTickVolume'),
    (re.compile(r'\bMathMax\b'),         '_rt.MathMax'),
    (re.compile(r'\bMathMin\b'),         '_rt.MathMin'),
    (re.compile(r'\bMathAbs\b'),         '_rt.MathAbs'),
    (re.compile(r'\bMathFloor\b'),       '_rt.MathFloor'),
    (re.compile(r'\bMathCeil\b'),        '_rt.MathCeil'),
    (re.compile(r'\bMathSqrt\b'),        '_rt.MathSqrt'),
    (re.compile(r'\bMathPow\b'),         '_rt.MathPow'),
    (re.compile(r'\bMathRound\b'),       '_rt.MathRound'),
    (re.compile(r'\bNormalizeDouble\b'), '_rt.NormalizeDouble'),
    (re.compile(r'\bSymbolInfoDouble\b'),'_rt.SymbolInfoDouble'),
    (re.compile(r'\bSymbolInfoInteger\b'),'_rt.SymbolInfoInteger'),
    (re.compile(r'\bAccountInfoDouble\b'),'_rt.AccountInfoDouble'),
    (re.compile(r'\bTimeCurrent\b'),     '_rt.TimeCurrent'),
    (re.compile(r'\biTime\b'),           '_rt.iTime'),
    (re.compile(r'\bObjectCreate\b'),    '_rt.ObjectCreate'),
    (re.compile(r'\bObjectDelete\b'),    '_rt.ObjectDelete'),
    (re.compile(r'\bObjectFind\b'),      '_rt.ObjectFind'),
    (re.compile(r'\bObjectSetDouble\b'), '_rt.ObjectSetDouble'),
    (re.compile(r'\bObjectSetInteger\b'),'_rt.ObjectSetInteger'),
    (re.compile(r'\bObjectSetString\b'), '_rt.ObjectSetString'),
    (re.compile(r'\bObjectsDeleteAll\b'),'_rt.ObjectsDeleteAll'),
    (re.compile(r'\bPositionGetTicket\b'), '_rt.PositionGetTicket'),
    (re.compile(r'\bPositionSelectByTicket\b'), '_rt.PositionSelectByTicket'),
    (re.compile(r'\bPositionsTotal\b'), '_rt.PositionsTotal'),
]


def _int_expr(e: str) -> str:
    """Like _expr but converts C integer division (/) to Python floor division (//)."""
    e = _expr(e)
    # In C/MQL5, int/int = int (truncated). Convert bare / to // when not already //.
    e = re.sub(r'(?<!/)/(?!/)', '//', e)
    return e


def _expr(e: str) -> str:
    """Light expression cleanup."""
    if e is None:
        return 'None'
    e = e.strip().rstrip(';')
    # Remap MQL5 API calls that appear in RHS expressions
    for pat, repl in _EXPR_API_MAP:
        e = pat.sub(repl, e)
    e = e.replace('NULL', 'None')
    e = e.replace('true', 'True').replace('false', 'False')
    e = e.replace('DBL_MAX', 'float("inf")')
    # strip C-style casts
    e = re.sub(r'\((?:int|double|float|long|uint|ulong|short|ushort|uchar|char|bool|datetime|ENUM_\w+)\)\s*', '', e)
    # C++ logical operators → Python
    e = re.sub(r'\s*&&\s*', ' and ', e)
    e = re.sub(r'\s*\|\|\s*', ' or ', e)
    e = re.sub(r'(?<![=!<>])!(?!=)', 'not ', e)
    # ternary: cond ? a : b → a if cond else b
    m = re.match(r'^(.+?)\s*\?\s*([^:]+)\s*:\s*(.+)$', e)
    if m:
        e = f'({m.group(2).strip()} if {m.group(1).strip()} else {m.group(3).strip()})'
    return e


# ---------------------------------------------------------------------------
# Block-level transformer (handles { } → indentation)
# ---------------------------------------------------------------------------

_CONTROL_KEYWORDS = re.compile(
    r'^\s*(if\s+|if\s*\(|elif\s+|elif\s*\(|else\s*if\s*\(|for\s*[\w(]|while\s*[\w(]|else\s*:)')

def _transform_blocks(lines: list[str]) -> list[str]:
    """
    Convert C-style brace blocks to Python indentation.
    Also handles braceless single-statement control flow (if(...) \n statement).
    """
    out = []
    indent = 0
    i = 0

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Opening brace alone on its own line — check for immediately empty body
        if stripped == '{':
            indent += 1
            # Peek: if the block is empty or only comments, inject pass
            j = i + 1
            while j < len(lines) and (not lines[j].strip() or lines[j].strip().startswith('#')):
                j += 1
            if j < len(lines) and lines[j].strip() in ('}', '};'):
                # Find last non-blank output line
                last = next((l for l in reversed(out) if l.strip()), '')
                if last.rstrip().endswith(':'):
                    out.append('    ' * indent + 'pass')
            i += 1
            continue

        # Closing brace
        if stripped == '}' or stripped == '};':
            indent = max(0, indent - 1)
            i += 1
            continue

        # Line ending with { — convert to colon-terminated
        if stripped.endswith('{'):
            core = stripped[:-1].rstrip()
            if core:
                out.append('    ' * indent + core + ':')
            indent += 1
            i += 1
            continue

        # Line already colon-terminated by a line rule (for/while/if converted above)
        # and next line is { — just consume the brace, indent is already handled
        if stripped.endswith(':') and _CONTROL_KEYWORDS.match(stripped):
            out.append('    ' * indent + stripped)
            # Consume the following { if present
            j = i + 1
            while j < len(lines) and not lines[j].strip():
                j += 1
            if j < len(lines) and lines[j].strip() == '{':
                indent += 1
                # Check if block body has only comments (or is empty) — needs pass
                k = j + 1
                while k < len(lines) and (not lines[k].strip() or lines[k].strip().startswith('#')):
                    k += 1
                if k < len(lines) and lines[k].strip() in ('}', '};'):
                    out.append('    ' * indent + 'pass')
                i = j + 1
            else:
                # No brace follows — braceless single-statement body.
                # Consume the body line WITHOUT permanently incrementing indent,
                # so that a subsequent else:/elif: is at the correct level.
                # For nested braceless (body is itself a control statement), we
                # recurse: collect the body chain and re-run _transform_blocks on it.
                i += 1
                while i < len(lines) and not lines[i].strip():
                    out.append(''); i += 1
                if i < len(lines):
                    body_stripped = lines[i].strip()
                    if body_stripped.startswith('#'):
                        out.append('    ' * (indent + 1) + 'pass')
                    elif body_stripped not in ('{', '}', '};'):
                        if body_stripped.endswith(':') and _CONTROL_KEYWORDS.match(body_stripped):
                            # Nested braceless: collect body chain and recurse
                            sub_lines = [body_stripped]
                            i += 1
                            # Collect the immediate body of this nested control stmt
                            while i < len(lines) and not lines[i].strip():
                                i += 1
                            if i < len(lines):
                                sub_body = lines[i].strip()
                                if sub_body not in ('{', '}', '};'):
                                    sub_lines.append(sub_body)
                                    i += 1
                            # Recursively transform the sub-block (indent starts at 0)
                            sub_out = _transform_blocks(sub_lines)
                            for sub_line in sub_out:
                                # Preserve relative indentation from sub-output
                                if sub_line:
                                    out.append('    ' * (indent + 1) + sub_line)
                                else:
                                    out.append('')
                        else:
                            out.append('    ' * (indent + 1) + body_stripped)
                            i += 1
                    else:
                        out.append('    ' * (indent + 1) + 'pass')
            continue

        # Braceless single-statement control flow: if(...) with no { on this line
        # and the next non-blank line is NOT { or } — treat it as the body
        if (stripped.endswith(')')
                and _CONTROL_KEYWORDS.match(stripped)
                and not stripped.endswith('{')):
            # Peek ahead for the body line (skip blank lines)
            j = i + 1
            while j < len(lines) and not lines[j].strip():
                j += 1
            next_stripped = lines[j].strip() if j < len(lines) else ''
            if next_stripped and next_stripped not in ('{', '}', '};'):
                out.append('    ' * indent + stripped + ':')
                i += 1
                # Emit body with extra indent (skip blanks first)
                while i < len(lines) and not lines[i].strip():
                    out.append('')
                    i += 1
                if i < len(lines):
                    body_line = lines[i].strip()
                    # Don't consume structural braces as the body
                    if body_line not in ('{', '}', '};'):
                        out.append('    ' * (indent + 1) + body_line)
                        i += 1
                    else:
                        out.append('    ' * (indent + 1) + 'pass')
                continue

        # Normal line
        if stripped:
            out.append('    ' * indent + stripped)
        else:
            out.append('')
        i += 1

    return out


# ---------------------------------------------------------------------------
# Main transpile function
# ---------------------------------------------------------------------------

_CTOR_INIT_START = re.compile(r'^\s*:\s*\w+\s*\(')  # : m_x(

def _join_continuation_lines(lines: list[str]) -> list[str]:
    """
    Join lines where:
    1. Parentheses are unbalanced (multi-line calls and signatures).
    2. Constructor initializer lists (: m_x(v), m_y(v) across lines).
    """
    out = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        # Skip comment lines, preprocessor, empty
        if (stripped.startswith('//') or stripped.startswith('#')
                or stripped.startswith('/*') or not stripped):
            out.append(line)
            i += 1
            continue

        # Constructor initializer list: ": m_x(val)," — join until no trailing comma
        # and parens are balanced
        if _CTOR_INIT_START.match(stripped):
            joined = stripped
            i += 1
            while i < len(lines) and (
                    joined.rstrip().endswith(',') or
                    joined.count('(') != joined.count(')')):
                cont = lines[i].strip()
                if cont and not cont.startswith('//'):
                    joined += ' ' + cont
                i += 1
            # This whole thing will be stripped by the init-list rule later
            out.append(joined)
            continue

        depth = stripped.count('(') - stripped.count(')')

        # Detect enum entry: IDENTIFIER = NUMBER,  — never join these
        _is_enum_entry = bool(re.match(r'^\w+\s*=\s*-?\d+\s*,?\s*(?://.*)?$', stripped))

        # Peek at the next non-blank, non-comment line
        j = i + 1
        while j < len(lines) and (not lines[j].strip() or lines[j].strip().startswith('//')):
            j += 1
        next_stripped = lines[j].strip() if j < len(lines) else ''

        # Join when parens are unbalanced, OR when line ends with binary op, OR next starts with op
        ends_with_binary_op = (
            bool(re.search(r'[+\-|&]\s*(?://.*)?$', stripped))
            and depth == 0
            and not _is_enum_entry
        )
        next_starts_with_op = (
            bool(re.match(r'^[+\-|&?]', next_stripped))  # ? for ternary condition continuation
            and not _is_enum_entry
        )
        # Also join when we have an open ternary (unmatched ?) and next starts with :
        _q_count = stripped.count('?')
        _c_count = stripped.count(':')
        ends_with_ternary_q = (_q_count > _c_count) and not _is_enum_entry
        next_starts_with_colon = bool(re.match(r'^:', next_stripped)) and not _is_enum_entry and not re.match(r'^:\s*\w+\s*\(', next_stripped)

        if depth > 0 or ((ends_with_binary_op or next_starts_with_op or (ends_with_ternary_q and next_starts_with_colon)) and not stripped.endswith(';')):
            # Strip inline // comments from the initial line before joining.
            # This prevents things like: + ","   // Timestamp  becoming part of the expression.
            line_clean = re.sub(r'\s*//(?![^"\']*["\'])[^"\']*$', '', line.rstrip())
            joined = line_clean
            i += 1
            while i < len(lines):
                cont = lines[i].strip()
                if cont.startswith('//') or cont.startswith('#'):
                    i += 1
                    continue
                # Strip inline // comments before joining
                cont_clean = re.sub(r'\s*//(?![^"\']*["\'])[^"\']*$', '', cont).rstrip()
                depth += cont_clean.count('(') - cont_clean.count(')')
                joined += ' ' + cont_clean
                i += 1
                if depth > 0:
                    continue  # still unbalanced, must keep going
                if re.search(r'[+\-|&?]\s*$', cont_clean):
                    continue  # current line ends with op or ternary ? — keep going
                # Check if next non-blank line starts with an operator
                k = i
                while k < len(lines) and (not lines[k].strip() or lines[k].strip().startswith('//')):
                    k += 1
                next_cont = lines[k].strip() if k < len(lines) else ''
                if re.match(r'^[+\-|&?]', next_cont):
                    continue  # next line starts with operator — keep joining
                # Join ternary : branch if we have an unmatched ? in joined (open ternary)
                if re.match(r'^:', next_cont) and not re.match(r'^:\s*\w+\s*\(', next_cont):
                    # Count ? and : to determine if the ternary is still open
                    _q_count = joined.count('?')
                    _c_count = joined.count(':')
                    if _q_count > _c_count:
                        continue
                break
            out.append(joined)
        else:
            out.append(line)
            i += 1
    return out


def _transform_switch(lines: list[str]) -> list[str]:
    """
    Convert switch(expr)/case blocks into if/elif chains.
    Replaces the switch/case structure with Python if/elif, preserving surrounding braces
    so that _transform_blocks can handle indentation correctly.
    """
    out = []
    i = 0
    _switch_re  = re.compile(r'^(\s*)switch\s*\((.+)\)\s*$')
    _case_re    = re.compile(r'^(\s*)case\s+(.+?)\s*:\s*(.*)$')
    _default_re = re.compile(r'^(\s*)default\s*:\s*(.*)$')
    _break_re   = re.compile(r'^\s*break\s*;?\s*$')

    while i < len(lines):
        line = lines[i]
        m = _switch_re.match(line)
        if not m:
            out.append(line)
            i += 1
            continue

        indent_str, expr = m.group(1), m.group(2)
        i += 1
        # Skip the opening {
        while i < len(lines) and lines[i].strip() in ('', '{'):
            if lines[i].strip() == '{':
                i += 1
                break
            i += 1

        # Collect all cases
        first = True
        case_body: list[str] = []
        current_cond: str | None = None

        def flush_case():
            nonlocal current_cond
            if current_cond is not None:
                out.append(indent_str + current_cond + ' {')
                if case_body:
                    for bl in case_body:
                        out.append(bl)
                else:
                    out.append(indent_str + '    pass')
                out.append(indent_str + '}')
                case_body.clear()
                current_cond = None

        while i < len(lines):
            cl = lines[i]
            stripped_cl = cl.strip()
            if stripped_cl in ('}', '};'):
                flush_case()
                i += 1
                break
            if _break_re.match(stripped_cl):
                i += 1
                continue
            cm = _case_re.match(cl)
            dm = _default_re.match(cl)
            if cm:
                flush_case()
                kw = 'if' if first else 'elif'
                first = False
                body = cm.group(3).strip().rstrip(';')
                # strip trailing inline break (e.g. "stmt; break" or "stmt;   break;")
                body = re.sub(r'\s*;?\s*break\s*;?\s*$', '', body).strip()
                current_cond = f'{kw} ({expr} == {cm.group(2)})'
                if body:
                    case_body.append(indent_str + '    ' + body)
                i += 1
                continue
            if dm:
                flush_case()
                body = dm.group(2).strip().rstrip(';')
                body = re.sub(r'\s*;?\s*break\s*;?\s*$', '', body).strip()
                current_cond = 'else'
                if body:
                    case_body.append(indent_str + '    ' + body)
                i += 1
                continue
            # Regular line inside case body
            if current_cond is not None:
                case_body.append(cl)
            i += 1

    return out


def _split_multi_stmt_brace_lines(lines: list[str]) -> list[str]:
    """
    Split lines of the form `{ stmt1; stmt2; stmt3; }` (bare opening brace,
    multiple statements, closing brace — all on one line) into:
        {
            stmt1;
            stmt2;
        }
    This handles the MQL5 pattern where an if/for body is written as:
        if(cond)
        { s1; s2; }
    """
    result = []
    _bare_block = re.compile(r'^(\s*)\{([^{}]+)\}\s*$')
    for line in lines:
        m = _bare_block.match(line)
        if m:
            indent = m.group(1)
            body   = m.group(2)
            stmts  = [s.strip() for s in body.split(';') if s.strip()]
            if len(stmts) > 1:
                result.append(indent + '{\n')
                for s in stmts:
                    result.append(indent + '    ' + s + ';\n')
                result.append(indent + '}\n')
                continue
        result.append(line)
    return result


def _expand_single_line_blocks(lines: list[str]) -> list[str]:
    """
    Expand compound single-line blocks like:
      if(cond) { s1; s2; }
      else if(cond) { s1; }
      else { s1; }
    into multi-line form. Also handles lines where such a block appears after
    a leading statement (e.g. "stmt; if(c) { ... }").
    Runs repeatedly until no more expansions are possible (handles nesting).
    """
    # Matches innermost { body } (no nested braces) preceded by a control header
    # Also captures any prefix before the header and any trailing content after }
    _inner_re = re.compile(
        r'^(\s*)(.*?)'                                           # indent + prefix
        r'((?:else\s+if|if|while)\s*\([^)]*\)|else)\s*'        # control header
        r'\{([^{}]*)\}'                                          # { body }
        r'(.*)$'                                                 # trailing
    )

    def _expand_one(lines: list[str]) -> tuple[list[str], bool]:
        out = []
        changed = False
        for line in lines:
            m = _inner_re.match(line)
            if m:
                indent_str = m.group(1)
                prefix     = m.group(2).strip()  # statements before the inner control kw
                header     = m.group(3).strip()
                body       = m.group(4)
                trailing   = m.group(5).strip()
                changed = True
                # If prefix contains '{', split at the brace: outer block header + body stmts
                if '{' in prefix:
                    brace_pos = prefix.index('{')
                    outer_header = prefix[:brace_pos].strip()
                    inner_stmts  = prefix[brace_pos+1:].strip()
                    out.append(indent_str + outer_header + ' {')
                    extra_indent = indent_str + '    '
                    if inner_stmts:
                        for stmt in inner_stmts.rstrip(';').split(';'):
                            stmt = stmt.strip()
                            if stmt:
                                out.append(extra_indent + stmt + ';')
                    out.append(extra_indent + header + ' {')
                    for stmt in body.split(';'):
                        stmt = stmt.strip()
                        if stmt:
                            out.append(extra_indent + '    ' + stmt + ';')
                    out.append(extra_indent + '}')
                    # trailing '}' closes the outer block
                    out.append(indent_str + '}')
                    if trailing.strip('}').strip():
                        out.append(indent_str + trailing.strip('}').strip())
                else:
                    # No outer block — emit prefix stmts then the inner block
                    if prefix:
                        for stmt in prefix.rstrip(';').split(';'):
                            stmt = stmt.strip()
                            if stmt:
                                out.append(indent_str + stmt + ';')
                    out.append(indent_str + header + ' {')
                    for stmt in body.split(';'):
                        stmt = stmt.strip()
                        if stmt:
                            out.append(indent_str + '    ' + stmt + ';')
                    out.append(indent_str + '}')
                    if trailing:
                        out.append(indent_str + trailing)
            else:
                out.append(line)
        return out, changed

    for _ in range(8):  # max nesting depth
        lines, changed = _expand_one(lines)
        if not changed:
            break
    return lines


def _merge_overloaded_methods(lines: list[str]) -> list[str]:
    """
    MQL5 supports method overloading; Python doesn't.

    Three-pass approach:
    Pass 1: Scan whole file, collect all (class, method_name) → list of overload bodies.
    Pass 2: Re-emit lines, replacing each method's first occurrence with the merged
            definition and dropping all subsequent occurrences.

    Merging strategy for a method with N overloads:
    - Use the first overload as the base.
    - For each subsequent overload with extra params: add those params as optional
      (default=None) to the base signature and guard its body with
      `if extra_param is not None:`.
    - Overloads with identical param names (type-dispatch variants) are dropped —
      Python is dynamically typed.
    """
    _def_sig_re = re.compile(r'^(\s+)(def\s+(\w+)\s*\(self)(,\s*[^)]+)?(\):)(.*)')

    def _collect_body(lines_list, start):
        """Collect method body starting at index start. Returns (body_lines, next_i)."""
        sig_line = lines_list[start]
        m = _def_sig_re.match(sig_line)
        inline = m.group(6).strip() if m else ''
        if inline:
            return [sig_line], start + 1
        # The method body has lines indented MORE than the def signature itself.
        sig_indent = len(sig_line) - len(sig_line.lstrip())
        body = [sig_line]
        j = start + 1
        while j < len(lines_list):
            bl = lines_list[j]
            if not bl.strip():
                # Blank line — include it but peek ahead
                body.append(bl)
                j += 1
                continue
            cur_indent = len(bl) - len(bl.lstrip())
            if cur_indent <= sig_indent:
                # Back at or before the def's indent — end of body
                # Remove trailing blank lines we already consumed
                while body and not body[-1].strip():
                    body.pop()
                    j -= 1
                break
            body.append(bl)
            j += 1
        return body, j

    def _param_list(params_str):
        return [p.strip() for p in params_str.lstrip(', ').split(',') if p.strip()]

    def _build_merged(overloads):
        """overloads: list of (sig_match, body_lines). Returns merged lines."""
        if len(overloads) == 1:
            return overloads[0][1]

        # Detect if first overload is a pure delegate (single `return self.fn(...)`)
        # If so, reorder: put the longer real-implementation overload first.
        def _is_pure_delegate(body, fn_name):
            """True if body is just: return [self.]fn_name(...)"""
            body_content = [bl for bl in body[1:] if bl.strip()]
            if len(body_content) != 1:
                return False
            return bool(re.match(
                r'^\s*return\s+(?:self\.)?' + re.escape(fn_name) + r'\s*\(', body_content[0]
            ))

        fn_name_0 = overloads[0][0].group(3)  # method name from first overload
        if _is_pure_delegate(overloads[0][1], fn_name_0) and len(overloads) > 1:
            # Swap first (delegate) with longest real implementation
            def _arity(ov):
                return len(_param_list(ov[0].group(4) or ''))
            best_idx = max(range(1, len(overloads)), key=lambda i: _arity(overloads[i]))
            # Extract defaults from the delegate body before swapping
            delegate_body_content = [bl for bl in overloads[0][1][1:] if bl.strip()]
            overloads = [overloads[best_idx]] + [overloads[0]] + [
                overloads[i] for i in range(1, len(overloads)) if i != best_idx
            ]

        base_m, base_body = overloads[0]
        indent    = base_m.group(1)
        body_pad  = indent + '    '
        inner_pad = body_pad + '    '

        all_params      = _param_list(base_m.group(4) or '')
        seen_names      = {p.split('=')[0].strip() for p in all_params}
        extra_guards    = []

        has_type_dispatch = False
        # param_defaults: mapping from param_name → default_expr extracted from delegate overloads
        param_defaults: dict[str, str] = {}

        for ov_m, ov_body in overloads[1:]:
            ov_params = _param_list(ov_m.group(4) or '')
            ov_param_names = {p.split('=')[0].strip() for p in ov_params}
            # Params in base but not in this shorter overload = the ones this overload omits
            missing_from_ov = [p for p in all_params if p.split('=')[0].strip() not in ov_param_names]
            extra = [p for p in ov_params if p.split('=')[0].strip() not in seen_names]
            if not extra:
                # Shorter overload (or type-dispatch variant).
                # Try to extract default values for missing params from its delegate call.
                # Pattern: single-line body `return self.fn(a, b, DEFAULT_VAL)`
                body_content = [bl for bl in ov_body[1:] if bl.strip()]
                if len(body_content) == 1:
                    ret_m = re.match(r'^\s*return\s+(?:self\.)?\w+\s*\((.+)\)\s*$', body_content[0])
                    if ret_m and missing_from_ov:
                        call_args = [a.strip() for a in ret_m.group(1).split(',')]
                        # The last N args correspond to the missing params
                        n_missing = len(missing_from_ov)
                        if len(call_args) >= n_missing:
                            default_args = call_args[-n_missing:]
                            for mp, dv in zip(missing_from_ov, default_args):
                                pname = mp.split('=')[0].strip()
                                # Only record if it's not just the param name itself
                                if dv != pname:
                                    param_defaults[pname] = dv
                # Only mark as true type-dispatch if same arity (differs only in param types).
                # A shorter-arity delegate is NOT a type-dispatch — don't add str() coercion.
                if not missing_from_ov:
                    has_type_dispatch = True
                continue  # type-dispatch or delegate — don't add guard block
            for ep in extra:
                opt = ep if '=' in ep else f'{ep}=None'
                name = opt.split('=')[0].strip()
                if name not in seen_names:
                    all_params.append(opt)
                    seen_names.add(name)
            guard_param = extra[-1].split('=')[0].strip()
            ov_sig_m = _def_sig_re.match(ov_body[0])
            inline = ov_sig_m.group(6).strip() if ov_sig_m else ''
            if inline:
                guard_lines = [f'{body_pad}if {guard_param} is not None:',
                               f'{inner_pad}{inline}']
            else:
                guard_lines = [f'{body_pad}if {guard_param} is not None:']
                # Detect base indentation of the overload body (first non-blank body line)
                base_body_indent = 0
                for bl in ov_body[1:]:
                    if bl.strip():
                        base_body_indent = len(bl) - len(bl.lstrip())
                        break
                for bl in ov_body[1:]:
                    if bl.strip():
                        # Shift by (inner_pad - base_body_indent) to preserve relative indentation
                        cur_indent = len(bl) - len(bl.lstrip())
                        delta = cur_indent - base_body_indent
                        guard_lines.append(inner_pad + '    ' * (delta // 4) + bl.lstrip())
                    else:
                        guard_lines.append(bl)
            extra_guards.append(guard_lines)

        # Apply extracted defaults: params that were optional in delegate overloads
        # get a `if param is None: param = default_val` guard at the top of the body.
        for i_p, p in enumerate(all_params):
            pname = p.split('=')[0].strip()
            if pname in param_defaults and '=' not in p:
                all_params[i_p] = f'{pname}=None'

        params_str = ', '.join(all_params)
        new_sig = f'{indent}{base_m.group(2)}, {params_str}{base_m.group(5)}'

        base_sig_m  = _def_sig_re.match(base_body[0])
        base_inline = base_sig_m.group(6).strip() if base_sig_m else ''
        if base_inline:
            merged = [new_sig, f'{body_pad}{base_inline}']
        else:
            base_body_lines = list(base_body[1:])
            if has_type_dispatch and not extra_guards and not param_defaults:
                # Pure type-dispatch: all overloads have identical param names,
                # differing only in C++ type (e.g. Add(key, string) vs Add(key, double)).
                # Python is dynamically typed, so coerce the last non-self param to str
                # to match MQL5 string storage semantics.
                last_param = (all_params[-1].split('=')[0].strip() if all_params else None)
                if last_param and last_param not in ('self', 'cls'):
                    base_body_lines = [
                        f'{body_pad}{last_param} = str({last_param}) if not isinstance({last_param}, str) else {last_param}\n'
                    ] + base_body_lines
            # Inject `if param is None: param = default` for delegate-extracted defaults
            default_guards = []
            for pname, dval in param_defaults.items():
                default_guards.append(f'{body_pad}if {pname} is None: {pname} = {dval}\n')
            merged = [new_sig] + default_guards + base_body_lines

        for gl in extra_guards:
            merged.extend(gl)
        return merged

    # --- Pass 1: collect all overloads per (class_name, method_name) ---
    # Strategy: a "def" with leading whitespace is inside a class.
    # The owning class is the most recent "class X:" line seen at col 0.
    # NOTE: class declaration lines may contain embedded \n (e.g. "@dataclass\nclass Foo:")
    # so we search for "class X" anywhere in the line, not just at the start.
    # overloads_map: class_name → {method_name: [(sig_match, body_lines), ...]}
    overloads_map: dict[str, dict[str, list]] = {}
    current_class = '__top__'
    i = 0
    n = len(lines)
    _cls_re = re.compile(r'(?:^|\n)class\s+(\w+)')

    while i < n:
        line = lines[i]
        m_class = _cls_re.search(line)
        if m_class:
            current_class = m_class.group(1)
            overloads_map.setdefault(current_class, {})
            i += 1
            continue
        m_def = _def_sig_re.match(line)
        if m_def and current_class != '__top__':
            name = m_def.group(3)
            body, i = _collect_body(lines, i)
            overloads_map[current_class].setdefault(name, []).append((m_def, body))
            continue
        i += 1

    # Build merged bodies: class → method → merged_lines
    merged_map: dict[str, dict[str, list[str]]] = {}
    for cls, methods in overloads_map.items():
        merged_map[cls] = {}
        for name, ovs in methods.items():
            merged_map[cls][name] = _build_merged(ovs)

    # --- Pass 2: re-emit, replacing first occurrence of each method with merged,
    #             dropping subsequent occurrences ---
    emitted: dict[str, set[str]] = {}  # class → set of method names already emitted
    result = []
    current_class2 = '__top__'
    i = 0

    while i < n:
        line = lines[i]
        m_class = _cls_re.search(line)
        if m_class:
            current_class2 = m_class.group(1)
            emitted.setdefault(current_class2, set())
            result.append(line)
            i += 1
            continue
        m_def = _def_sig_re.match(line)
        if m_def and current_class2 != '__top__':
            name = m_def.group(3)
            _, next_i = _collect_body(lines, i)
            if name not in emitted.get(current_class2, set()):
                emitted.setdefault(current_class2, set()).add(name)
                result.extend(merged_map.get(current_class2, {}).get(name, [line]))
            # else: drop this occurrence (already emitted merged version)
            i = next_i
            continue
        result.append(line)
        i += 1

    return result


def _export_enum_members(lines: list[str]) -> list[str]:
    """
    After each IntEnum class definition, emit module-level aliases for every member
    so that MQL5 bare enum names (e.g. PHASE_ASIAN_BUILD) work without qualification.
    """
    _intenum_re = re.compile(r'^class\s+(\w+)\s*\(IntEnum\):')
    _member_re  = re.compile(r'^\s+(\w+)\s*=\s*-?\d+')

    result = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        m = _intenum_re.match(line)
        if m:
            enum_name = m.group(1)
            result.append(line)
            i += 1
            members = []
            while i < n and (not lines[i].strip() or lines[i][0] in ' \t'):
                result.append(lines[i])
                mm = _member_re.match(lines[i])
                if mm:
                    members.append(mm.group(1))
                i += 1
            # Emit module-level aliases after the class body
            for member in members:
                result.append(f'{member} = {enum_name}.{member}')
            result.append('')
        else:
            result.append(line)
            i += 1
    return result


def _inject_self(lines: list[str]) -> list[str]:
    """
    MQL5 member variables are referenced without `self.` inside methods.
    After stitching, each class body contains field declarations (name: type = val)
    and method bodies. This pass:
      1. Collects field names declared in the class body (before any def).
      2. Inside every method body (indented lines after a `def`), rewrites bare
         references to those field names → self.name.
      3. Also rewrites any bare `m_`-prefixed identifiers unconditionally, since
         MQL5 convention is that m_ always means a member field.

    Only rewrites whole-word occurrences that are NOT already prefixed with
    `self.`, `_rt.`, or a dot (i.e., not attribute accesses on other objects).
    """
    _class_re  = re.compile(r'^class\s+\w+')
    _def_re    = re.compile(r'^    def\s+\w+\s*\(self')
    _field_re  = re.compile(r'^    (\w+)\s*(?::\s*\S+)?\s*=')   # class-level field
    _type_ann_re = re.compile(r'^    (\w+)\s*:\s*\S+\s*$')       # bare annotation: name: type

    result = []
    i = 0
    n = len(lines)

    while i < n:
        line = lines[i]

        if not _class_re.match(line):
            result.append(line)
            i += 1
            continue

        # We're at a class header — collect the whole class block
        class_start = i
        class_lines = [line]
        i += 1

        # Collect every line that belongs to this class:
        # indented lines, blank lines, and # comments at col-0 that sit between
        # indented method blocks (stitch pass leaves #+--- markers at col 0).
        while i < n:
            cl = lines[i]
            if not cl.strip():
                class_lines.append(cl)
                i += 1
            elif cl[0] in ' \t':
                class_lines.append(cl)
                i += 1
            elif cl.startswith('#'):
                # col-0 comment between class members — include it
                class_lines.append(cl)
                i += 1
            else:
                break

        # Pass 1: collect declared field names, method names, and init tags
        fields: set[str] = set()
        methods: set[str] = set()
        ctor_fields: list[tuple[str, str]] = []   # (field_name, ClassName) value-type objects
        list_fields: list[tuple[str, str]] = []   # (field_name, init_expr) list fields
        _ctor_tag_re = re.compile(r'#\s*_mql5_ctor:(\w+)')
        _list_tag_re = re.compile(r'#\s*_mql5_list:(\[.*\])')
        _method_name_re = re.compile(r'^\s+def\s+(\w+)\s*\(self')
        for cl in class_lines[1:]:
            m = _field_re.match(cl)
            if m:
                fields.add(m.group(1))
                tag = _ctor_tag_re.search(cl)
                if tag:
                    ctor_fields.append((m.group(1), tag.group(1)))
                ltag = _list_tag_re.search(cl)
                if ltag:
                    list_fields.append((m.group(1), ltag.group(1)))
            m2 = _type_ann_re.match(cl)
            if m2:
                fields.add(m2.group(1))
            m3 = _method_name_re.match(cl)
            if m3 and m3.group(1) not in ('__init__', '__del__', '__str__', '__repr__'):
                methods.add(m3.group(1))
        # Remove Python keywords / builtins that should never get self.
        _skip = {'pass', 'None', 'True', 'False', 'self', 'cls'}
        fields -= _skip
        methods -= _skip

        # Pass 2: rewrite member references inside method bodies
        # Build patterns for field names and method names
        if fields:
            named_pat = re.compile(
                r'(?<![.\w])(' + '|'.join(re.escape(f) for f in sorted(fields, key=len, reverse=True)) + r')(?!\w)'
            )
        else:
            named_pat = None

        # Bare method calls: MethodName( → self.MethodName(  (not already prefixed)
        if methods:
            method_pat = re.compile(
                r'(?<![.\w])(' + '|'.join(re.escape(f) for f in sorted(methods, key=len, reverse=True)) + r')\s*\('
            )
        else:
            method_pat = None

        m_prefix_pat = re.compile(r'(?<![.\w])(m_\w+)')
        # Virtual dispatch methods — always qualify with self. regardless of class
        # (e.g. OnBar, OnTick called from base class OnBarInternal)
        _virtual_dispatch_pat = re.compile(
            r'(?<![.\w])(OnBar|OnTick|OnBarInternal|OnDeinit|GetSignals)\s*\('
        )

        in_method = False
        in_init = False
        init_ctor_inserted = False
        new_class_lines = [class_lines[0]]  # class header unchanged

        for cl in class_lines[1:]:
            stripped = cl.strip()

            # Track when we enter/leave a method
            if _def_re.match(cl):
                in_method = True
                in_init = bool(re.search(r'\bdef\s+__init__\s*\(', cl))
                init_ctor_inserted = False
                # Single-line method: def foo(self, ...): body_on_same_line
                # Apply self-injection to the body part after the colon
                _single_line_def = re.compile(r'^(\s+def\s+\w+\s*\(self[^)]*\)\s*:)\s*(.+)$')
                slm = _single_line_def.match(cl)
                if slm and slm.group(2).strip():
                    body = slm.group(2)
                    body = m_prefix_pat.sub(lambda mm: f'self.{mm.group(1)}', body)
                    if named_pat:
                        body = named_pat.sub(lambda mm: f'self.{mm.group(1)}', body)
                    if method_pat:
                        body = method_pat.sub(lambda mm: f'self.{mm.group(1)}(', body)
                    new_class_lines.append(f'{slm.group(1)} {body}')
                else:
                    new_class_lines.append(cl)
                continue

            if in_method and cl and cl[0] not in ' \t':
                in_method = False  # left method scope (shouldn't happen inside class)

            if not in_method or not stripped or stripped.startswith('#'):
                new_class_lines.append(cl)
                continue

            # Inside a method body: convert tagged local vars to immediate initializations
            _list_local_re = re.compile(r'^(\s*)(\w+)\s*:\s*\w+\s*=\s*None\s*#\s*_mql5_list:(\[.*\])\s*$')
            _ctor_local_re = re.compile(r'^(\s*)(\w+)\s*:\s*\w+\s*=\s*None\s*#\s*_mql5_ctor:(\w+)\s*$')
            if in_method:
                lm = _list_local_re.match(cl)
                if lm:
                    init = lm.group(3)
                    val = '_AutoList()' if init == '[]' else f'_AutoList({init})'
                    new_class_lines.append(f'{lm.group(1)}{lm.group(2)} = {val}')
                    continue
                cm = _ctor_local_re.match(cl)
                if cm:
                    new_class_lines.append(f'{cm.group(1)}{cm.group(2)} = {cm.group(3)}()')
                    continue

            # Rewrite: skip lines that are themselves field declarations (def, annotation)
            if _def_re.match(cl) or _field_re.match(cl) or _type_ann_re.match(cl):
                new_class_lines.append(cl)
                continue

            # Inject member initializations at the top of __init__
            if in_init and not init_ctor_inserted and (ctor_fields or list_fields):
                indent = len(cl) - len(cl.lstrip())
                pad = ' ' * indent
                for fname, cname in ctor_fields:
                    new_class_lines.append(f'{pad}self.{fname} = {cname}()')
                for fname, init_expr in list_fields:
                    if init_expr == '[]':
                        new_class_lines.append(f'{pad}self.{fname} = _AutoList()')
                    else:
                        new_class_lines.append(f'{pad}self.{fname} = _AutoList({init_expr})')
                init_ctor_inserted = True

            # Apply self. injection
            # 1. m_-prefixed identifiers (always member fields by MQL5 convention)
            cl = m_prefix_pat.sub(lambda m: f'self.{m.group(1)}', cl)
            # 2. Named fields collected from class body
            if named_pat:
                cl = named_pat.sub(lambda m: f'self.{m.group(1)}', cl)
            # 3. Bare own-method calls: MethodName( → self.MethodName(
            if method_pat:
                cl = method_pat.sub(lambda m: f'self.{m.group(1)}(', cl)
            # 4. Virtual dispatch methods (OnBar, OnTick, etc.) — qualify even if not in method set
            cl = _virtual_dispatch_pat.sub(lambda m: f'self.{m.group(1)}(', cl)

            new_class_lines.append(cl)

        # If the class has list/ctor fields but no __init__, generate one
        has_init = any(re.search(r'\bdef\s+__init__\s*\(', cl) for cl in new_class_lines)
        if not has_init and (ctor_fields or list_fields):
            # Insert __init__ right after the class header
            init_lines = ['    def __init__(self):\n']
            for fname, cname in ctor_fields:
                init_lines.append(f'        self.{fname} = {cname}()\n')
            for fname, init_expr in list_fields:
                if init_expr == '[]':
                    init_lines.append(f'        self.{fname} = _AutoList()\n')
                else:
                    init_lines.append(f'        self.{fname} = _AutoList({init_expr})\n')
            # Insert after the class header line
            new_class_lines = [new_class_lines[0]] + init_lines + new_class_lines[1:]

        result.extend(new_class_lines)

    return result


def _stitch_methods_into_classes(lines: list[str]) -> list[str]:
    """
    MQL5 separates class declaration from implementation (ClassName::Method outside the class).
    After transpilation, these `::` methods become module-level `def method(self, ...):` blocks.
    This pass collects ALL such stranded methods and appends them to the class they belong to
    (identified by the last `class X:` header that preceded a run of method blocks).

    Approach:
    1. Scan for class definitions and their declared-body span.
    2. Collect runs of module-level `def X(self, ...)` blocks that appear outside any class.
    3. Insert those blocks (4-space indented) immediately before the next class definition
       that follows, or at the insertion point after the last owning class body.

    Simpler equivalent: re-write all module-level `def X(self, ...)` bodies to be
    4-space indented (making them look like class methods), then rearrange so each
    method-group appears inside the last class whose field declarations it follows.

    For MQL5's pattern, ALL module-level `def(self,...)` are implementation methods of
    the most recently declared class.  We group them greedily.
    """
    _class_re  = re.compile(r'^class\s+(\w+)')
    _method_re = re.compile(r'^def\s+(\w+)\s*\(self')  # module-level def with self
    _free_re   = re.compile(r'^def\s+(\w+)\s*\((?!self)')  # module-level def WITHOUT self

    # Segment the lines into:
    #  ('class',  name, [header_lines])          — class definition block
    #  ('method', [lines])                        — module-level def(self) + body
    #  ('free',   [lines])                        — module-level def(no-self) + body
    #  ('other',  [lines])                        — everything else

    segments = []
    i = 0
    n = len(lines)

    def _collect_block(start: int) -> tuple[list[str], int]:
        """Collect def header + indented body."""
        block = [lines[start]]
        j = start + 1
        while j < n and (not lines[j].strip() or lines[j][0] in ' \t'):
            block.append(lines[j])
            j += 1
        return block, j

    while i < n:
        line = lines[i]
        cm = _class_re.match(line)
        if cm:
            # Collect the class header + its directly indented body
            block, j = _collect_block(i)
            segments.append(('class', cm.group(1), block))
            i = j
            continue
        mm = _method_re.match(line)
        if mm:
            block, j = _collect_block(i)
            segments.append(('method', block))
            i = j
            continue
        fm = _free_re.match(line)
        if fm:
            block, j = _collect_block(i)
            segments.append(('free', block))
            i = j
            continue
        # other line
        if segments and segments[-1][0] == 'other':
            segments[-1][1].append(line)
        else:
            segments.append(('other', [line]))
        i += 1

    # Now rebuild: for each class segment, attach all immediately-following method segments
    out_segments: list[tuple] = []
    i = 0
    while i < len(segments):
        seg = segments[i]
        if seg[0] == 'class':
            # Absorb all consecutive method blocks that follow
            class_name, class_lines = seg[1], list(seg[2])
            j = i + 1
            while j < len(segments) and segments[j][0] in ('method', 'other'):
                next_seg = segments[j]
                if next_seg[0] == 'method':
                    # Re-indent method block by 4 spaces and append to class body
                    for mline in next_seg[1]:
                        class_lines.append('    ' + mline if mline.strip() else mline)
                else:
                    # 'other' lines between methods — only absorb blank/comment lines
                    other_lines = next_seg[1]
                    if all(not l.strip() or l.strip().startswith('#') for l in other_lines):
                        class_lines.extend(other_lines)
                    else:
                        break
                j += 1
            out_segments.append(('class', class_name, class_lines))
            i = j
        else:
            out_segments.append(seg)
            i += 1

    # Flatten back to lines
    result = []
    for seg in out_segments:
        if seg[0] == 'class':
            result.extend(seg[2])
        elif seg[0] in ('method', 'free'):
            result.extend(seg[1])
        else:
            result.extend(seg[1])

    return result


def _add_global_declarations(lines: list[str]) -> list[str]:
    """
    Insert `global var1, var2, ...` at the top of module-level free functions
    (OnTick, OnInit, OnDeinit, OnBar) that assign to module-level variables.

    MQL5 has no scoping distinction — all global vars are visible everywhere.
    Python requires an explicit `global` statement inside a function before
    assigning to a module-level variable, otherwise Python treats it as local.

    Algorithm:
    1. First pass: collect all module-level variable names (lines at column 0
       that look like assignments outside any def/class).
    2. Second pass: for each module-level free function (def Foo(...): with no
       leading spaces and no `self` param), scan its body for assignments to
       any of those globals and prepend `global ...` after the def line.
    """
    _assign_re  = re.compile(r'^(\w+)\s*(?::\s*\w+)?\s*=')   # var = ... or var: type = ...
    _aug_re     = re.compile(r'^(\w+)\s*[+\-*/%&|^]=')        # var += ...
    _def_re     = re.compile(r'^def\s+(\w+)\s*\(')
    _class_re   = re.compile(r'^class\s+')
    _indent_re  = re.compile(r'^( +)')

    # Pass 1: collect module-level names (non-indented assignments outside defs/classes)
    global_names: set[str] = set()
    in_block = False   # inside a def or class at column 0
    block_indent = ''
    for line in lines:
        stripped = line.rstrip()
        if not stripped:
            continue
        if _class_re.match(stripped) or _def_re.match(stripped):
            in_block = True
            block_indent = '    '
            continue
        if in_block:
            # End of block when we see a non-indented, non-blank line
            if stripped and not stripped[0].isspace():
                in_block = False
            else:
                continue
        # Module-level line
        m = _assign_re.match(stripped)
        if m:
            global_names.add(m.group(1))

    if not global_names:
        return lines

    # Pass 2: for each module-level free function, inject global declaration
    result: list[str] = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        dm = _def_re.match(line)
        if dm and not line.startswith(' '):
            # Module-level function definition
            result.append(line)
            i += 1
            # Collect the function body
            body_lines: list[str] = []
            while i < n:
                bl = lines[i]
                if bl.strip() and not bl[0].isspace():
                    break   # end of function
                body_lines.append(bl)
                i += 1
            # Find which globals are assigned in this body
            assigned: set[str] = set()
            for bl in body_lines:
                stripped = bl.strip()
                ma = _assign_re.match(stripped)
                if ma and ma.group(1) in global_names:
                    assigned.add(ma.group(1))
                ma2 = _aug_re.match(stripped)
                if ma2 and ma2.group(1) in global_names:
                    assigned.add(ma2.group(1))
            if assigned:
                # Insert after any leading docstring/comment lines in body
                insert_at = 0
                for k, bl in enumerate(body_lines):
                    if bl.strip() and not bl.strip().startswith('#'):
                        insert_at = k
                        break
                global_line = '    global ' + ', '.join(sorted(assigned)) + '\n'
                body_lines.insert(insert_at, global_line)
            result.extend(body_lines)
        else:
            result.append(line)
            i += 1
    return result


def _strip_bare_constructor_calls(lines: list[str]) -> list[str]:
    """
    Strip bare ClassName() expressions that are constructor declaration remnants.
    When class LogKV: body contains LogKV() as a statement, Python tries to call
    the not-yet-defined class. Detect by tracking the current class name.
    """
    _class_re = re.compile(r'^class\s+(\w+)\s*(?:\(.*\))?:')
    _bare_call_re = re.compile(r'^\s+(\w+)\s*\(\s*\)\s*$')
    current_class = None
    out = []
    for line in lines:
        m = _class_re.match(line)
        if m:
            current_class = m.group(1)
            out.append(line)
            continue
        if current_class:
            bc = _bare_call_re.match(line)
            if bc and bc.group(1) == current_class:
                continue  # strip it
        out.append(line)
    return out


def _expand_ctor_initializer_lists(lines: list[str]) -> list[str]:
    """
    Convert MQL5 constructor initializer lists into explicit self.field = value
    assignments at the top of the constructor body.

    Input pattern (split across lines):
        ClassName::ClassName()
           : field1(val1),
             field2(val2),
             ...
        {
            body;
        }

    Output: replace the initializer lines with self.field = val statements
    injected into the body after '{'.
    """
    # Matches out-of-class ctor:  ClassName::ClassName()
    _ctor_re    = re.compile(r'^(\w+)::(\1)\s*\(\s*\)\s*$')
    # Matches inline ctor (inside class body, no ::):  [whitespace] ClassName()
    _inline_ctor_re = re.compile(r'^\s*(\w+)\s*\(\s*\)\s*$')
    # Matches a single initializer item: field(val) on its own line (multi-line form)
    _init_re    = re.compile(r'^[\s:,]+(\w+)\(([^)]*)\)\s*,?\s*$')
    # Extracts all field(val) pairs from a joined single-line initializer list
    _init_all_re = re.compile(r'\b(\w+)\(([^)]*)\)')

    def _parse_init_line(il: str) -> list[tuple[str, str]]:
        """Return [(field, val), ...] from an initializer line (single or joined)."""
        # Try single-item form first
        im = _init_re.match(il)
        if im:
            return [(im.group(1), im.group(2).strip())]
        # Joined form: `: field1(v1), field2(v2), ...`
        if il.lstrip().startswith(':') or re.match(r'^[\s:,]', il):
            pairs = _init_all_re.findall(il)
            return [(f, v.strip()) for f, v in pairs] if pairs else []
        return []

    result = []
    i = 0
    n = len(lines)

    def _peek_next_nonempty(idx: int) -> str:
        """Return the stripped content of the next non-blank, non-comment line."""
        k = idx
        while k < n:
            s = lines[k].strip()
            if s and not s.startswith('//'):
                return s
            k += 1
        return ''

    def _is_ctor_match(line_stripped: str) -> bool:
        """True if this line is a ctor signature (with or without ::)."""
        return bool(_ctor_re.match(line_stripped))

    def _is_inline_ctor(line_stripped: str, next_line: str) -> bool:
        """True if inline ctor: `ClassName()` followed by `: field(val),...` or `: ... {}`."""
        if not _inline_ctor_re.match(line_stripped):
            return False
        # Next line must start with `:` (initializer list) or inline `: ... {}` on this line
        return (next_line.startswith(':') or
                bool(re.search(r'\)\s*:\s*\w+\(', line_stripped)))

    while i < n:
        line = lines[i]
        stripped = line.rstrip()
        next_content = _peek_next_nonempty(i + 1)

        is_ctor = _is_ctor_match(stripped) or _is_inline_ctor(stripped, next_content)

        # Also handle single-line form: CName() : f1(v1), f2(v2) {}
        # where the ctor signature AND initializer list are on one joined line
        single_line_ctor = re.match(
            r'^(\s*\w+)\s*\(\s*\)\s*:(.*)\{.*\}', stripped
        )

        if single_line_ctor:
            # Extract all field(val) pairs from the initializer section
            init_section = single_line_ctor.group(2)
            pairs = _init_all_re.findall(init_section)
            if pairs:
                # Emit: ctor signature as just the name (drop the init list)
                ctor_sig = single_line_ctor.group(1).rstrip()
                result.append(ctor_sig + '()\n')
                result.append('{\n')
                for field_name, val in pairs:
                    val = val.replace('true', 'True').replace('false', 'False').replace('NULL', 'None')
                    result.append(f'   {field_name} = {val};\n')
                result.append('}\n')
                i += 1
                continue

        if is_ctor:
            result.append(line)
            i += 1
            # Collect initializer list lines (start with : or continuation)
            init_assignments = []
            while i < n:
                il = lines[i].rstrip()
                pairs = _parse_init_line(il)
                if pairs:
                    for field_name, val in pairs:
                        val = val.replace('true', 'True').replace('false', 'False').replace('NULL', 'None')
                        init_assignments.append(f'   {field_name} = {val};')
                    i += 1
                elif il.strip() in ('{', '') or il.strip().startswith('//'):
                    break
                elif il.strip() == '{}':
                    # Inline empty body
                    break
                elif re.match(r'^[\s:,]', il):
                    # Non-matching continuation line — skip
                    i += 1
                else:
                    break

            # Emit: if we found a '{' or '{}', insert the assignments into the body
            if i < n and lines[i].strip() in ('{', '{}'):
                if lines[i].strip() == '{}':
                    result.append('{\n')
                    for assign in init_assignments:
                        result.append(assign + '\n')
                    result.append('}\n')
                else:
                    result.append(lines[i])  # emit '{'
                    for assign in init_assignments:
                        result.append(assign + '\n')
                i += 1
            else:
                for assign in init_assignments:
                    result.append(assign + '\n')
        else:
            result.append(line)
            i += 1

    return result


# ---------------------------------------------------------------------------
# Fix by-reference integer counter parameters
# ---------------------------------------------------------------------------
_def_pat        = re.compile(r'^(\s*)def\s+(\w+)\s*\(([^)]*)\)\s*:')
_increment_pat  = re.compile(r'^\s+(\w+)\s*\+=\s*\d+\s*$')
_decrement_pat  = re.compile(r'^\s+(\w+)\s*-=\s*\d+\s*$')
_bare_assign_pat = re.compile(r'^\s+(\w+)\s*=\s*\1\s*[+\-]\s*\d+\s*$')
# Detect assignment to a plain parameter: `    param = <expr>` where expr is not
# a simple literal and param is not 'self'. Used to catch MqlRates output params.
_param_assign_pat = re.compile(r'^\s+(\w+)\s*=\s*(.+)$')


def _fix_int_ref_counters(lines: list[str]) -> list[str]:
    """
    Two-pass fix for MQL5 by-reference parameters that Python can't pass by ref.

    Handles two cases:
    A) int &count — parameter is incremented/decremented in body.
       Fix: add `return count` at end; rewrite call sites as `count = fn(...)`.

    B) MqlRates &cur / any output param — parameter is directly assigned in body
       (`cur = rates[0]`) when the function already has a bool return.
       Fix: change `return True/False` to `return (True/False, cur, prior)`;
       rewrite call sites that do `if not self.FetchBars(..., cur, prior):` to
       unpack the tuple and update the output vars.
    """
    # Build map: function_name → (mode, set_of_ref_params)
    # mode 'counter': param += N pattern (case A)
    # mode 'output':  param = expr pattern where fn has existing return (case B)
    ref_fn_params: dict[str, set[str]] = {}
    ref_fn_mode:   dict[str, str]      = {}   # 'counter' or 'output'

    i = 0
    while i < len(lines):
        m = _def_pat.match(lines[i])
        if m:
            fn_indent  = m.group(1)
            fn_name    = m.group(2)
            param_list = [p.strip() for p in m.group(3).split(',')]
            params = {p.split(':')[0].split('=')[0].strip() for p in param_list
                      if p.strip() not in ('self', 'cls', '')}
            body_start  = i + 1
            body_indent = fn_indent + '    '
            j = body_start
            while j < len(lines):
                stripped = lines[j]
                if stripped and not stripped[0].isspace() and j > body_start:
                    break
                if stripped and not stripped.startswith(body_indent) and j > body_start:
                    break
                j += 1
            body_lines = lines[body_start:j]

            # --- Case A: increment/decrement mutations ---
            mutated_counter = set()
            for bl in body_lines:
                mi = _increment_pat.match(bl)
                md = _decrement_pat.match(bl)
                if mi and mi.group(1) in params:
                    mutated_counter.add(mi.group(1))
                if md and md.group(1) in params:
                    mutated_counter.add(md.group(1))

            if mutated_counter:
                ref_fn_params[fn_name] = mutated_counter
                ref_fn_mode[fn_name]   = 'counter'
                last_body = j - 1
                while last_body >= body_start and not lines[last_body].strip():
                    last_body -= 1
                if last_body >= body_start:
                    last_line = lines[last_body].strip()
                    if not last_line.startswith('return'):
                        ret_vals = ', '.join(sorted(mutated_counter))
                        lines.insert(last_body + 1, body_indent + f'return {ret_vals}\n')
                        j += 1
                i = j
                continue

            # --- Case B: direct assignment to param AND existing bool return ---
            # Detect: `param = <expr>` where param is a function parameter and
            # the function body contains a `return True` or `return False`.
            has_bool_return = any(
                re.match(r'^\s*return\s+(True|False)\s*$', bl)
                for bl in body_lines
            )
            if has_bool_return:
                mutated_output = set()
                for bl in body_lines:
                    ma = _param_assign_pat.match(bl)
                    if ma:
                        pname = ma.group(1)
                        rhs   = ma.group(2).strip()
                        # Only count if it's a real param assignment, not a local var
                        # declared in this function (heuristic: must be in params)
                        if pname in params and '[' in rhs:
                            mutated_output.add(pname)
                if mutated_output:
                    ref_fn_params[fn_name] = mutated_output
                    ref_fn_mode[fn_name]   = 'output'
                    # Rewrite all `return True/False` to `return (True/False, param…)`
                    ret_suffix = ', ' + ', '.join(sorted(mutated_output))
                    for k in range(body_start, j):
                        rm = re.match(r'^(\s*)return\s+(True|False)\s*$', lines[k])
                        if rm:
                            lines[k] = f'{rm.group(1)}return ({rm.group(2)}{ret_suffix})\n'

            i = j
        else:
            i += 1

    if not ref_fn_params:
        return lines

    # Pass 2: Rewrite call sites
    result = []
    for line in lines:
        handled = False

        for fn_name, ref_params in ref_fn_params.items():
            mode = ref_fn_mode.get(fn_name, 'counter')

            # Match: optional `if [not] ` prefix + optional receiver + fn(args)
            call_re = re.compile(
                r'^(\s*)(if\s+(?:not\s+)?)?' +
                r'(?:[\w.]+\.)?' +
                re.escape(fn_name) +
                r'\s*\(([^)]*)\)\s*:?\s*$'
            )
            cm = call_re.match(line)
            if not cm:
                continue

            indent    = cm.group(1)
            if_prefix = cm.group(2) or ''
            call_args_str = cm.group(3)
            arg_names = [a.strip() for a in call_args_str.split(',')]
            matched_refs = [a for a in arg_names if a in ref_params]

            if mode == 'counter':
                if not matched_refs:
                    continue
                # Simple: lhs = fn(...)
                lhs = ', '.join(matched_refs)
                bare = line.strip().rstrip(':')
                result.append(f'{indent}{lhs} = {bare}\n')
                handled = True
                break
            else:
                # Output mode: fn returns (bool, param1, param2, ...)
                # The caller uses different variable names than the function params,
                # so we take the last N args from the call site as the output vars
                # (N = number of output params).
                n_out = len(ref_params)
                suffix = ':' if line.rstrip().endswith(':') else ''
                bare_call = re.sub(r'^\s*(if\s+(?:not\s+)?)?', '', line.strip()).rstrip(':').strip()
                # Extract last n_out arguments as output variable names
                all_args = [a.strip() for a in call_args_str.split(',')]
                if len(all_args) >= n_out:
                    out_vars_list = all_args[-n_out:]
                    out_vars = ', '.join(out_vars_list)
                    result.append(f'{indent}_ok, {out_vars} = {bare_call}\n')
                    if if_prefix.strip():
                        # if_prefix is e.g. 'if not ' — keep trailing space before _ok
                        pfx = if_prefix if if_prefix.endswith(' ') else if_prefix + ' '
                        result.append(f'{indent}{pfx}_ok{suffix}\n')
                    handled = True
                    break

        if not handled:
            result.append(line)

    return result


def transpile(source: str, filename: str = "<unknown>") -> str:
    """
    Transpile MQL5 source text to Python source text.
    Returns Python source as a string.
    """
    # Strip C-style block comments /* ... */ (may span multiple lines)
    source = re.sub(r'/\*.*?\*/', '', source, flags=re.DOTALL)

    lines = source.splitlines()

    # Pre-process: join multi-line expressions (unbalanced parens)
    lines = _join_continuation_lines(lines)

    # Expand single-line blocks: if(c) { s1; s2; } → multi-line
    lines = _split_multi_stmt_brace_lines(lines)
    lines = _expand_single_line_blocks(lines)

    # Convert MQL5 constructor initializer lists to self.field = value assignments.
    # Pattern: ClassName::ClassName() followed by lines starting with : or , field(val)
    lines = _expand_ctor_initializer_lists(lines)

    # Transform switch/case → if/elif (before line rules — works on raw MQL5)
    lines = _transform_switch(lines)

    result = []
    for line in lines:
        transformed = _apply_line_rules(line)
        # A rule may emit multiple lines (e.g. single-line method body)
        if '\n' in transformed:
            result.extend(transformed.split('\n'))
        else:
            result.append(transformed)

    # Block transform (braces → indentation)
    result = _transform_blocks(result)

    # Strip bare ClassName() constructor declaration remnants inside class bodies
    # e.g. "    LogKV()" appearing as a statement in class LogKV: body
    result = _strip_bare_constructor_calls(result)

    # Re-attach MQL5 ::Method implementations to their owning class
    result = _stitch_methods_into_classes(result)

    # Inject self. prefix on member variable references inside class method bodies
    result = _inject_self(result)

    # Export IntEnum members to module scope so MQL5 bare enum names work
    result = _export_enum_members(result)

    # Merge overloaded methods: make later definitions' params optional
    result = _merge_overloaded_methods(result)

    # Fix by-reference integer counter params: MQL5 `int &count` becomes Python
    # `count` (passed by value), so `count += 1` inside a function has no effect on
    # the caller. Detect functions where a param is incremented and make them return
    # the param, then rewrite call sites to capture the return value.
    result = _fix_int_ref_counters(result)

    # Inject `global var` declarations in module-level functions (OnTick/OnInit/etc.)
    # that assign to module-level variables — Python requires this, MQL5 does not.
    result = _add_global_declarations(result)

    # Convert any remaining _mql5_ctor tagged locals (in free functions or method bodies)
    # from `var: type = None  # _mql5_ctor:ClassName` to `var = ClassName()`
    # Class-level fields (4 spaces, no leading blank) are already handled by _inject_self.
    # Here we target lines with ANY indent that still have the tag.
    _local_ctor_re = re.compile(r'^(\s+)(\w+)\s*:\s*\w+\s*=\s*None\s*#\s*_mql5_ctor:(\w+)\s*$')
    result = [
        _local_ctor_re.sub(lambda m: f'{m.group(1)}{m.group(2)} = {m.group(3)}()', l)
        for l in result
    ]

    # Header
    header = [
        f"# Auto-transpiled from {filename}",
        "# Generated by pipeline/mql5/transpiler.py — DO NOT EDIT",
        "from __future__ import annotations",
        "import math",
        "from dataclasses import dataclass, field",
        "from enum import IntEnum",
        "from typing import Optional, List",
        "# _rt is injected by the bridge at module load time",
        "",
    ]

    return '\n'.join(header + result)


def _apply_line_rules(line: str) -> str:
    """Apply all line-level rewrite rules."""
    for pattern, replacement in _LINE_RULES:
        if callable(replacement):
            m = pattern.search(line)
            if m:
                # Full-line match
                if pattern.match(line):
                    line = replacement(m)
                    break
                else:
                    line = pattern.sub(replacement, line)
        else:
            if pattern.match(line.strip()) and replacement == '':
                line = ''
                break
            line = pattern.sub(replacement, line)
    return line
