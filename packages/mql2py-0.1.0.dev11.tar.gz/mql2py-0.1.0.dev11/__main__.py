"""
mql2py-emulator CLI — run MQL5 EAs from the command line.

Usage:
    mql2py-emulator HyperTrend.mq5
    mql2py-emulator HyperTrend.mq5 --from 2024 --to 2025 --balance 10000

Or via uv/python:
    uv run python -m mql2py HyperTrend.mq5
"""

import argparse
import os
import sys

import pandas as pd

from .runtime import MQL5Runtime
from .engine  import Engine
from .bridge  import MQL5Bridge


def main():
    parser = argparse.ArgumentParser(
        prog="mql2py-emulator",
        description="MQL5 EA emulator — run EAs against real bar data",
    )
    parser.add_argument("ea", help="EA file (.mq5) or name")
    parser.add_argument("--bars",    dest="bar_file",
                        default="",  # empty = error later unless user provides it
                        help="Path to bar data Parquet file")
    parser.add_argument("--from",    dest="from_date", default=None,
                        help="Start date (YYYY-MM-DD)")
    parser.add_argument("--to",      dest="to_date",   default=None,
                        help="End date (YYYY-MM-DD, exclusive)")
    parser.add_argument("--balance", type=float, default=10_000.0,
                        help="Initial balance (default: 10,000)")
    parser.add_argument("--symbol",  default="EURUSD",
                        help="Symbol (default: EURUSD)")
    parser.add_argument("--mql5-root", dest="mql5_root", default=None,
                        help="Path to MQL5 source root (default: current dir)")
    args = parser.parse_args()

    # --- Load bar data ---
    if not args.bar_file:
        print("Error: --bars is required. Provide a path to a Parquet file with bar data.")
        sys.exit(1)

    print(f"Loading bars from {args.bar_file} ...")
    df = pd.read_parquet(args.bar_file)
    df["time"] = pd.to_datetime(df["time"])
    print(f"  {len(df):,} bars  |  {df['time'].min().date()} → {df['time'].max().date()}")

    if args.from_date:
        df = df[df["time"] >= pd.Timestamp(args.from_date)]
        print(f"  filtering from {args.from_date}")
    if args.to_date:
        df = df[df["time"] < pd.Timestamp(args.to_date)]
    df = df.reset_index(drop=True)

    # --- Set up runtime and EA ---
    rt = MQL5Runtime(symbol=args.symbol, initial_balance=args.balance)

    mql5_root = args.mql5_root or os.getcwd()
    bridge = MQL5Bridge(rt, mql5_root)

    ea_name = args.ea
    if not ea_name.endswith(".mq5"):
        ea_name += ".mq5"

    ea = bridge.load(ea_name)
    ea._bridge = bridge

    # --- Run ---
    print(f"\nRunning {ea_name} ...")
    engine = Engine(ea, rt, df)
    engine.run()

    print(f"  {len(rt.trades)} trades closed")
    engine.report()

    # Report any stubbed MQL5 APIs
    bridge.report_missing()


if __name__ == "__main__":
    main()
