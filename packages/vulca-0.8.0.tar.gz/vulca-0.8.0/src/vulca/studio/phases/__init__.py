"""Studio pipeline phases."""
