"""
insAIts SDK - pip install insa-its
Multi-LLM Agent Communication Monitoring & Hallucination Detection

Open-core model: Apache 2.0 open-source core + proprietary features via PyPI.

Open-source features (FREE - available on GitHub):
- Real-time anomaly detection (fingerprint mismatch, low confidence)
- LLM fingerprint validation
- Hallucination detection (fact tracking, source grounding,
  phantom citation detection, confidence decay tracking)
- Cross-agent contradiction detection (unique to InsAIts)
- Forensic chain tracing (trace anomalies back to root cause)
- Anchor-aware context tracking
- Terminal dashboard for live monitoring
- LangChain, CrewAI, LangGraph, Slack integrations
- Local embeddings (sentence-transformers) + cloud embeddings
- Configurable Ollama model selection

Proprietary features (pip install only - not on GitHub):
- Edge/Hybrid Swarm Routing with automatic failover (V2.5)
- AI Lineage Oracle for compliance tracking (V2.5)
- Advanced anomaly detection (shorthand emergence, jargon, context loss)
- Decipher engine (translate AI-to-AI communication, cloud + local)
- Anchor drift detection + false-positive suppression
- Adaptive jargon dictionary with domain-specific knowledge
- Dictionary import/export/auto-expand

Contact: info@yuyai.pro for Lifetime access
"""

__version__ = "4.5.1"

# ---------------------------------------------------------------------------
# ALL imports are lazy (PEP 562) to keep `import insa_its` fast (<0.5s).
# Heavy modules (numpy, torch, sentence-transformers, cryptography) are only
# loaded when the specific symbol is first accessed.
# ---------------------------------------------------------------------------

# Map of attribute name -> (module_path, attribute_name_in_module)
_LAZY_IMPORTS = {
    # Config (lightweight — only imports os)
    "FREE_TIER_LIMITS": (".config", "FREE_TIER_LIMITS"),
    "FEATURES": (".config", "FEATURES"),
    "get_feature": (".config", "get_feature"),
    # Exceptions (lightweight — no heavy deps)
    "insAItsError": (".exceptions", "insAItsError"),
    "RateLimitError": (".exceptions", "RateLimitError"),
    "APIError": (".exceptions", "APIError"),
    "AuthenticationError": (".exceptions", "AuthenticationError"),
    "EmbeddingError": (".exceptions", "EmbeddingError"),
    "HallucinationError": (".exceptions", "HallucinationError"),
    "PremiumFeatureError": (".exceptions", "PremiumFeatureError"),
    # License — v4.5.0 trial clock (stdlib-only) + legacy LicenseManager (re-exported via package)
    "get_license_state": (".license", "get_license_state"),
    "validate_license_key": (".license", "validate_license_key"),
    "TRIAL_DAYS": (".license", "TRIAL_DAYS"),
    "LicenseManager": (".license", "LicenseManager"),
    "get_license_manager": (".license", "get_license_manager"),
    # Local LLM
    "set_default_model": (".local_llm", "set_default_model"),
    "get_default_model": (".local_llm", "get_default_model"),
    # Models (lightweight)
    "AnomalyResult": (".models", "AnomalyResult"),
    "MonitorResult": (".models", "MonitorResult"),
    "Severity": (".models", "Severity"),
    # Structured logging (lightweight)
    "StructuredLogger": (".structured_logging", "StructuredLogger"),
    # Core (heavy: imports numpy via embeddings)
    "insAItsMonitor": (".monitor", "insAItsMonitor"),
    "AnomalyDetector": (".detector", "AnomalyDetector"),
    "Anomaly": (".detector", "Anomaly"),
    # Hallucination (heavy: imports numpy via embeddings)
    "FactTracker": (".hallucination", "FactTracker"),
    "SourceGrounder": (".hallucination", "SourceGrounder"),
    "SelfConsistencyChecker": (".hallucination", "SelfConsistencyChecker"),
    "PhantomCitationDetector": (".hallucination", "PhantomCitationDetector"),
    "ConfidenceDecayTracker": (".hallucination", "ConfidenceDecayTracker"),
    "FactClaim": (".hallucination", "FactClaim"),
    # V3: Production hardening
    "ReadinessChecker": (".readiness", "ReadinessChecker"),
    "AgentCircuitBreaker": (".circuit_breaker", "AgentCircuitBreaker"),
    "InterventionEngine": (".interventions", "InterventionEngine"),
    "MetricsCollector": (".metrics", "MetricsCollector"),
    "SdkAuditLogger": (".audit", "AuditLogger"),
    # V3: Advanced detectors
    "SemanticDriftDetector": (".detectors", "SemanticDriftDetector"),
    "HallucinationChainDetector": (".detectors", "HallucinationChainDetector"),
    "JargonDriftDetector": (".detectors", "JargonDriftDetector"),
    "DriftResult": (".detectors", "DriftResult"),
    "UncertaintyPropagationDetector": (".detectors", "UncertaintyPropagationDetector"),
    "QueryIntentDetector": (".detectors", "QueryIntentDetector"),
    "ToolDescriptionDivergenceDetector": (".detectors", "ToolDescriptionDivergenceDetector"),
    "BehavioralFingerprintDetector": (".detectors", "BehavioralFingerprintDetector"),
    "CredentialPatternDetector": (".detectors", "CredentialPatternDetector"),
    "InformationFlowTracker": (".detectors", "InformationFlowTracker"),
    "ToolCallFrequencyAnomalyDetector": (".detectors", "ToolCallFrequencyAnomalyDetector"),
    # V3: AI-Targeted Intervention Monitor (heavy: imports numpy)
    "AIMonitor": (".ai_monitor", "AIMonitor"),
    "ClaudeCodeMonitor": (".ai_monitor", "ClaudeCodeMonitor"),
    "AIAnomaly": (".ai_monitor", "AIAnomaly"),
    "AIMonitorResult": (".ai_monitor", "AIMonitorResult"),
    "AnomalyType": (".ai_monitor", "AnomalyType"),
    "AISeverity": (".ai_monitor", "AISeverity"),
    "InterventionAction": (".ai_monitor", "InterventionAction"),
    "AIInterventionEngine": (".ai_monitor", "AIInterventionEngine"),
    "monitored": (".ai_monitor", "monitored"),
}

# Cache for resolved lazy imports
_LAZY_CACHE = {}


def __getattr__(name):
    """Module-level __getattr__ for lazy imports (PEP 562)."""
    # Check lazy import map
    if name in _LAZY_IMPORTS:
        if name in _LAZY_CACHE:
            return _LAZY_CACHE[name]
        import importlib
        module_path, attr_name = _LAZY_IMPORTS[name]
        mod = importlib.import_module(module_path, package=__name__)
        obj = getattr(mod, attr_name)
        _LAZY_CACHE[name] = obj
        return obj

    # Optional modules with availability flags
    if name == "EDGE_ROUTER_AVAILABLE":
        return _try_edge_router()[0]
    if name in ("EdgeRouter", "EmbeddingRouter", "PrivacyMode", "NodeType",
                "NodeHealth", "create_router", "get_privacy_modes"):
        avail, symbols = _try_edge_router()
        return symbols.get(name)

    if name == "LINEAGE_ORACLE_AVAILABLE":
        return _try_lineage_oracle()[0]
    if name in ("LineageOracle", "LineageRecord", "LineageAnomaly", "LineageStatus"):
        avail, symbols = _try_lineage_oracle()
        return symbols.get(name)

    if name == "PREMIUM_AVAILABLE":
        return _try_premium()

    if name == "DASHBOARD_AVAILABLE":
        return _try_dashboard()[0]
    if name == "InsAItsDashboard":
        return _try_dashboard()[1]
    if name == "LiveDashboard":
        return _try_dashboard()[1]  # Legacy alias
    if name == "SimpleDashboard":
        return None
    if name == "create_dashboard":
        return None

    if name == "MCP_SERVER_AVAILABLE":
        return _try_mcp()

    if name == "HOOK_AVAILABLE":
        return _try_hook()[0]
    if name == "run_hook":
        return _try_hook()[1]

    raise AttributeError(f"module 'insa_its' has no attribute {name!r}")


# ---------------------------------------------------------------------------
# Optional module loaders (cached after first call)
# ---------------------------------------------------------------------------
_edge_router_result = None
def _try_edge_router():
    global _edge_router_result
    if _edge_router_result is not None:
        return _edge_router_result
    try:
        from .edge_router import (
            EdgeRouter, EmbeddingRouter, PrivacyMode,
            NodeType, NodeHealth, create_router, get_privacy_modes,
        )
        _edge_router_result = (True, {
            "EdgeRouter": EdgeRouter, "EmbeddingRouter": EmbeddingRouter,
            "PrivacyMode": PrivacyMode, "NodeType": NodeType,
            "NodeHealth": NodeHealth, "create_router": create_router,
            "get_privacy_modes": get_privacy_modes,
        })
    except ImportError:
        _edge_router_result = (False, {
            "EdgeRouter": None, "EmbeddingRouter": None,
            "PrivacyMode": None, "NodeType": None,
            "NodeHealth": None, "create_router": None,
            "get_privacy_modes": None,
        })
    return _edge_router_result


_lineage_oracle_result = None
def _try_lineage_oracle():
    global _lineage_oracle_result
    if _lineage_oracle_result is not None:
        return _lineage_oracle_result
    try:
        from .lineage_oracle import (
            LineageOracle, LineageRecord, LineageAnomaly, LineageStatus,
        )
        _lineage_oracle_result = (True, {
            "LineageOracle": LineageOracle, "LineageRecord": LineageRecord,
            "LineageAnomaly": LineageAnomaly, "LineageStatus": LineageStatus,
        })
    except ImportError:
        _lineage_oracle_result = (False, {
            "LineageOracle": None, "LineageRecord": None,
            "LineageAnomaly": None, "LineageStatus": None,
        })
    return _lineage_oracle_result


_premium_result = None
def _try_premium():
    global _premium_result
    if _premium_result is not None:
        return _premium_result
    try:
        from .premium import PREMIUM_AVAILABLE
        _premium_result = PREMIUM_AVAILABLE
    except ImportError:
        _premium_result = False
    return _premium_result


_dashboard_result = None
def _try_dashboard():
    global _dashboard_result
    if _dashboard_result is not None:
        return _dashboard_result
    try:
        from .dashboard import InsAItsDashboard, DASHBOARD_AVAILABLE
        _dashboard_result = (DASHBOARD_AVAILABLE, InsAItsDashboard)
    except ImportError:
        _dashboard_result = (False, None)
    return _dashboard_result


_mcp_result = None
def _try_mcp():
    global _mcp_result
    if _mcp_result is not None:
        return _mcp_result
    try:
        from .mcp import MCP_AVAILABLE
        _mcp_result = MCP_AVAILABLE
    except ImportError:
        _mcp_result = False
    return _mcp_result


_hook_result = None
def _try_hook():
    global _hook_result
    if _hook_result is not None:
        return _hook_result
    try:
        from .hooks import run_hook
        _hook_result = (True, run_hook)
    except ImportError:
        _hook_result = (False, None)
    return _hook_result


__all__ = [
    # Core
    "insAItsMonitor",
    "AnomalyDetector",
    "Anomaly",
    "get_license_state",
    "validate_license_key",
    "TRIAL_DAYS",
    "LicenseManager",
    "get_license_manager",
    # Config
    "FREE_TIER_LIMITS",
    "FEATURES",
    "get_feature",
    # Exceptions
    "insAItsError",
    "RateLimitError",
    "APIError",
    "AuthenticationError",
    "EmbeddingError",
    "HallucinationError",
    "PremiumFeatureError",
    # Hallucination Detection
    "FactTracker",
    "SourceGrounder",
    "SelfConsistencyChecker",
    "PhantomCitationDetector",
    "ConfidenceDecayTracker",
    "FactClaim",
    # Local LLM
    "set_default_model",
    "get_default_model",
    # V3: Models + Production Hardening
    "AnomalyResult",
    "MonitorResult",
    "Severity",
    "ReadinessChecker",
    "AgentCircuitBreaker",
    "InterventionEngine",
    "MetricsCollector",
    "SdkAuditLogger",
    "StructuredLogger",
    # V3: Advanced Detectors
    "SemanticDriftDetector",
    "HallucinationChainDetector",
    "JargonDriftDetector",
    "DriftResult",
    "UncertaintyPropagationDetector",
    "QueryIntentDetector",
    # V3.1: Security Detectors
    "ToolDescriptionDivergenceDetector",
    "BehavioralFingerprintDetector",
    "CredentialPatternDetector",
    "InformationFlowTracker",
    "ToolCallFrequencyAnomalyDetector",
    # Edge Router (NEW in 2.5) - Proprietary
    "EdgeRouter",
    "EmbeddingRouter",
    "PrivacyMode",
    "NodeType",
    "NodeHealth",
    "create_router",
    "get_privacy_modes",
    "EDGE_ROUTER_AVAILABLE",
    # Lineage Oracle (NEW in 2.5) - Proprietary
    "LineageOracle",
    "LineageRecord",
    "LineageAnomaly",
    "LineageStatus",
    "LINEAGE_ORACLE_AVAILABLE",
    # Premium
    "PREMIUM_AVAILABLE",
    # Dashboard
    "InsAItsDashboard",
    "LiveDashboard",
    "SimpleDashboard",
    "create_dashboard",
    "DASHBOARD_AVAILABLE",
    # Hook
    "HOOK_AVAILABLE",
    # V3: AI-Targeted Intervention Monitor
    "AIMonitor",
    "ClaudeCodeMonitor",
    "AIAnomaly",
    "AIMonitorResult",
    "AnomalyType",
    "AISeverity",
    "InterventionAction",
    "AIInterventionEngine",
    "monitored",
]
