"""Базові класи для Node плагінів.

Node плагіни виконуються на різних етапах життєвого циклу ноди:
- ЕТАП 1 (URL): ON_NODE_CREATED
- ЕТАП 2 (HTML): ON_BEFORE_SCAN, ON_HTML_PARSED, ON_AFTER_SCAN
"""

import inspect
import logging
from abc import ABC, abstractmethod
from enum import Enum
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from graph_crawler.domain.context.crawl_context import CrawlContext
    from graph_crawler.domain.interfaces.control_channel import (
        ControlMessage,
        CrawlCommand,
        IControlChannel,
    )


class NodePluginType(str, Enum):
    """Типи плагінів для обробки Node."""

    # ЕТАП 1: URL_STAGE (при створенні ноди)
    ON_NODE_CREATED = "on_node_created"  # Після створення ноди

    # ЕТАП 2: HTML_STAGE (при скануванні)
    ON_BEFORE_SCAN = "on_before_scan"  # Перед скануванням
    ON_HTML_PARSED = "on_html_parsed"  # Після парсингу HTML в дерево
    ON_AFTER_SCAN = "on_after_scan"  # Після сканування

    # ЕТАП 3: CRAWL_STAGE (життєвий цикл краулінгу)
    BEFORE_CRAWL = "before_crawl"  # Перед початком краулінгу
    AFTER_CRAWL = "after_crawl"  # Після завершення краулінгу


class NodePluginContext(BaseModel):
    """
    Контекст для Node плагінів (Pydantic BaseModel).

    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    # Основні дані
    node: Any  # Node об'єкт

    # Етап 1: URL_STAGE (завжди доступні)
    url: str
    depth: int
    should_scan: bool
    can_create_edges: bool

    # Етап 2: HTML_STAGE INPUT (доступні тільки після парсингу HTML)
    html: Optional[str] = None
    html_tree: Optional[Any] = None  # Any замість BeautifulSoup (підтримка різних парсерів)
    parser: Optional[Any] = None  # Tree adapter/parser instance

    # Етап 2: HTML_STAGE OUTPUT (заповнюються плагінами)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    extracted_links: List[str] = Field(default_factory=list)

    # Додаткові дані від користувача (заповнюються плагінами)
    user_data: Dict[str, Any] = Field(default_factory=dict)

    # Флаги
    skip_link_extraction: bool = False  # Не витягувати посилання
    skip_metadata_extraction: bool = False  # Не витягувати метадані

    # Phase 1: AI Agent Integration - глобальний контекст краулінгу
    crawl_context: Optional[Any] = None  # CrawlContext

    # Phase 2: AI Agent Integration - канал керування
    control_channel: Optional[Any] = None  # IControlChannel

    def get_metadata(self, key: str, default: Any = None) -> Any:
        """
        Безпечно отримує значення з metadata.

        Args:
            key: Ключ метаданих
            default: Значення за замовчуванням

        Returns:
            Значення метаданих або default якщо ключ не знайдено
        """
        return self.metadata.get(key, default)

    def set_metadata(self, key: str, value: Any) -> None:
        """
        Встановлює значення в metadata.

        Args:
            key: Ключ метаданих
            value: Значення для збереження
        """
        self.metadata[key] = value

    def has_metadata(self, key: str) -> bool:
        """
        Перевіряє наявність ключа в metadata.

        Args:
            key: Ключ для перевірки

        Returns:
            True якщо ключ існує
        """
        return key in self.metadata

    def get_from_crawl_context(self, key: str, default: Any = None) -> Any:
        """
        Безпечно отримує значення з глобального crawl_context.

        Args:
            key: Ключ
            default: Значення за замовчуванням

        Returns:
            Значення або default
        """
        if self.crawl_context:
            return self.crawl_context.get(key, default)
        return default

    def set_in_crawl_context(self, key: str, value: Any) -> None:
        """
        Встановлює значення в глобальному crawl_context.

        Args:
            key: Ключ
            value: Значення
        """
        if self.crawl_context:
            self.crawl_context.set(key, value)

    def add_extracted_to_context(self, data: Dict[str, Any]) -> None:
        """
        Додає витягнуті дані до глобального контексту.

        Args:
            data: Словник з витягнутими даними
        """
        if self.crawl_context:
            self.crawl_context.add_extracted_data(data, self.url)

    def request_stop(self, reason: str = "Plugin requested stop") -> None:
        """
        Запитати зупинку краулінгу.

        Використовує control_channel якщо доступний, інакше crawl_context.

        Args:
            reason: Причина зупинки
        """
        # Phase 2: Спочатку пробуємо через control_channel
        if self.control_channel:
            from graph_crawler.domain.interfaces.control_channel import ControlMessage, CrawlCommand

            self.control_channel.send(
                ControlMessage(
                    command=CrawlCommand.STOP,
                    data={"reason": reason},
                    sender=f"plugin:{self.__class__.__name__}",
                )
            )
        # Fallback до crawl_context
        elif self.crawl_context:
            self.crawl_context.set("stop_requested", True)
            self.crawl_context.set("stop_reason", reason)

    def send_command(
        self, command: "CrawlCommand", data: Optional[Dict[str, Any]] = None, priority: int = 0
    ) -> bool:
        """
        Відправити команду через control_channel.

        Phase 2: AI Agent Integration

        Args:
            command: Тип команди
            data: Додаткові дані
            priority: Пріоритет команди

        Returns:
            True якщо команда відправлена успішно
        """
        if self.control_channel:
            from graph_crawler.domain.interfaces.control_channel import ControlMessage

            self.control_channel.send(
                ControlMessage(
                    command=command,
                    data=data or {},
                    sender=f"plugin:{self.__class__.__name__}",
                    priority=priority,
                )
            )
            return True
        return False

    def reprioritize_url(self, url: str, new_priority: int) -> bool:
        """
        Запросити зміну пріоритету URL.

        Phase 2: AI Agent Integration

        Args:
            url: URL для зміни пріоритету
            new_priority: Новий пріоритет

        Returns:
            True якщо команда відправлена
        """
        if self.control_channel:
            from graph_crawler.domain.interfaces.control_channel import ControlMessage, CrawlCommand

            self.control_channel.send(
                ControlMessage(
                    command=CrawlCommand.REPRIORITIZE,
                    data={"url": url, "priority": new_priority},
                    sender=f"plugin:{self.__class__.__name__}",
                )
            )
            return True
        return False

    def force_visit_url(self, url: str) -> bool:
        """
        Запросити примусове відвідування URL.

        Phase 2: AI Agent Integration

        Args:
            url: URL для відвідування

        Returns:
            True якщо команда відправлена
        """
        if self.control_channel:
            from graph_crawler.domain.interfaces.control_channel import ControlMessage, CrawlCommand

            self.control_channel.send(
                ControlMessage(
                    command=CrawlCommand.FORCE_VISIT,
                    data={"url": url},
                    sender=f"plugin:{self.__class__.__name__}",
                    priority=8,
                )
            )
            return True
        return False

    def __repr__(self):
        return f"NodePluginContext(url={self.url}, has_html={self.html is not None}, metadata_keys={list(self.metadata.keys())})"


class BaseNodePlugin(ABC):
    """
    Базовий клас для Node плагінів.

    Node плагіни виконуються на різних етапах життєвого циклу ноди:
    - ЕТАП 1 (URL): ON_NODE_CREATED
    - ЕТАП 2 (HTML): ON_BEFORE_SCAN, ON_HTML_PARSED, ON_AFTER_SCAN

    Example:
        class MyPlugin(BaseNodePlugin):
            @property
            def plugin_type(self):
                return NodePluginType.ON_HTML_PARSED

            def execute(self, context: NodePluginContext) -> NodePluginContext:
                # Your logic here
                if context.html_tree:
                    context.user_data['my_data'] = 'value'
                return context
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the plugin with optional configuration."""
        self.config = config or {}
        self.enabled = self.config.get("enabled", True)

    @property
    @abstractmethod
    def plugin_type(self) -> NodePluginType:
        """Return the plugin type (lifecycle stage)."""
        ...

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the plugin name."""
        ...

    @abstractmethod
    def execute(self, context: NodePluginContext) -> "NodePluginContext | Any":
        """
        Execute the plugin logic.

        Can be sync or async (return coroutine).

        Args:
            context: Context with node data

        Returns:
            Updated context (or coroutine that returns context)
        """
        ...

    def setup(self):
        """Ініціалізація плагіну."""
        pass

    def teardown(self):
        """Очищення ресурсів."""
        pass

    def __repr__(self):
        return f"{self.__class__.__name__}(type={self.plugin_type.value}, enabled={self.enabled})"


class NodePluginManager:
    """
    Async менеджер для управління Node плагінами.

    Координує виконання плагінів на різних етапах життєвого циклу.
    Метод execute() є async для підтримки async плагінів.
    """

    def __init__(self, event_bus=None):
        """
        Ініціалізує NodePluginManager.

        Args:
            event_bus: EventBus для публікації подій (опціонально,)
        """
        self.plugins: Dict[NodePluginType, List[BaseNodePlugin]] = {
            plugin_type: [] for plugin_type in NodePluginType
        }
        self.event_bus = event_bus

    def register(self, plugin: BaseNodePlugin):
        """Реєструє плагін."""
        if plugin.enabled:
            self.plugins[plugin.plugin_type].append(plugin)
            if hasattr(plugin, "setup") and callable(plugin.setup):
                plugin.setup()

    async def execute(
        self, plugin_type: NodePluginType, context: NodePluginContext
    ) -> NodePluginContext:
        """
        Async виконує всі плагіни вказаного типу .

        Плагіни виконуються послідовно, кожен отримує context від попереднього.
        Підтримує як sync, так і async плагіни.

        Args:
            plugin_type: Тип плагінів для виконання
            context: Контекст з даними

        Returns:
            Оновлений контекст
        """
        for plugin in self.plugins.get(plugin_type, []):
            if plugin.enabled:
                try:
                    # Подія перед виконанням плагіна
                    if self.event_bus:
                        from graph_crawler.domain.events import CrawlerEvent, EventType

                        self.event_bus.publish(
                            CrawlerEvent.create(
                                EventType.PLUGIN_STARTED,
                                data={
                                    "plugin_name": plugin.name,
                                    "plugin_type": plugin_type.value,
                                    "url": (context.url if hasattr(context, "url") else None),
                                },
                            )
                        )

                    result = plugin.execute(context)
                    if inspect.isawaitable(result):
                        context = await result
                    else:
                        context = result

                    # Подія після успішного виконання
                    if self.event_bus:
                        from graph_crawler.domain.events import CrawlerEvent, EventType

                        self.event_bus.publish(
                            CrawlerEvent.create(
                                EventType.PLUGIN_COMPLETED,
                                data={
                                    "plugin_name": plugin.name,
                                    "plugin_type": plugin_type.value,
                                    "url": (context.url if hasattr(context, "url") else None),
                                },
                            )
                        )

                except Exception as e:
                    # Логуємо помилку, але продовжуємо
                    logger.error("Plugin %s error: %s", plugin.name, e, exc_info=True)

                    # Подія про помилку
                    if self.event_bus:
                        from graph_crawler.domain.events import CrawlerEvent, EventType

                        self.event_bus.publish(
                            CrawlerEvent.create(
                                EventType.PLUGIN_FAILED,
                                data={
                                    "plugin_name": plugin.name,
                                    "plugin_type": plugin_type.value,
                                    "url": (context.url if hasattr(context, "url") else None),
                                    "error": str(e),
                                    "error_type": type(e).__name__,
                                },
                            )
                        )
        return context

    def has_plugins(self, plugin_type: NodePluginType) -> bool:
        """Перевіряє чи є плагіни вказаного типу."""
        return len(self.plugins.get(plugin_type, [])) > 0

    def execute_sync(
        self, plugin_type: NodePluginType, context: NodePluginContext
    ) -> NodePluginContext:
        """
        Синхронна версія execute() для виклику з sync коду.

        ВАЖЛИВО: Викликає тільки sync плагіни! Async плагіни будуть ігноровані
        з попередженням у логах.

        Args:
            plugin_type: Тип плагінів для виконання
            context: Контекст з даними

        Returns:
            Оновлений контекст
        """
        for plugin in self.plugins.get(plugin_type, []):
            if plugin.enabled:
                try:
                    result = plugin.execute(context)
                    if inspect.isawaitable(result):
                        # Async плагін в sync контексті - ігноруємо з попередженням
                        logger.warning(
                            "Plugin %s is async but called in sync context. "
                            "Skipping. Use execute() for async plugins.",
                            plugin.name
                        )
                        continue
                    context = result
                except Exception as e:
                    logger.error("Plugin %s failed: %s", plugin.name, e)
        return context

    async def teardown_all(self):
        """Async закриває всі плагіни."""
        for plugins_list in self.plugins.values():
            for plugin in plugins_list:
                teardown = plugin.teardown
                if callable(teardown):
                    result = teardown()
                    if inspect.isawaitable(result):
                        await result

    def __repr__(self):
        total = sum(len(plugins) for plugins in self.plugins.values())
        return f"NodePluginManager(total_plugins={total})"
