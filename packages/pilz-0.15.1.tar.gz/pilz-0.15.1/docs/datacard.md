# DataCard Format

The DataCard is a YAML file that describes your dataset for Pilz. It tells the system which features exist, which is the target variable, and where the data files are located.

## Full Example

```yaml
features:
  - name: age
    statistical: numerical
    type: int
  - name: gender
    statistical: categorial
    type: string
  - name: income
    statistical: numerical
    type: float
    missing_value: 0
  - name: city
    statistical: categorial
    type: string
target:
  feature_name: churn
  values:
    - 'Yes'
    - 'No'
infos:
  source: https://example.com/data
  license: MIT
train_files:
  - /path/to/train.csv
test_files:
  - /path/to/test.csv
```

## Sections

### `features`

List of feature definitions. Each feature has:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | Yes | Column name in the data file |
| `statistical` | string | Yes | `"categorial"` or `"numerical"` |
| `type` | string | Yes | Data type: `"int"`, `"float"`, `"string"` |
| `missing_value` | any | No | Value to replace nulls (optional) |

> **Note**: Use `"categorial"` (not `"categorical"`)

### `target`

Describes the target variable for classification:

```yaml
target:
  feature_name: churn
  values:
    - 'Yes'
    - 'No'
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `feature_name` | string | Yes | Column name of target |
| `values` | list | Yes | Possible class values |

### `infos`

Optional metadata dictionary:

```yaml
infos:
  source: https://example.com/data
  license: CC0
  date: 2024-01-01
```

### `train_files`

Paths to training data files:

```yaml
train_files:
  - /path/to/train.csv
  - /path/to/train2.csv  # Multiple files supported
```

Supported formats: `.csv`, `.parquet`

### `test_files`

Paths to test/evaluation data files:

```yaml
test_files:
  - /path/to/test.csv
```

## Auto-Generation

Instead of writing the DataCard manually, use:

```bash
pilz create-dc --src data.csv --out datacard.yaml
```

This interactive command prompts for feature types and target selection.

## Field Types

### FeatureType

| Value | Description |
|-------|-------------|
| `categorial` | Discrete categories (strings, integers representing groups) |
| `numerical` | Continuous values (integers, floats) |

### DataType

| Value | Description |
|-------|-------------|
| `int` | Integer values |
| `float` | Floating-point values |
| `string` | Text values |

## Generating DataCards

The `create-dc` command creates a DataCard from an existing dataset:

```bash
pilz create-dc --src /path/to/data.csv --out datacard.yaml
```

Example workflow:

1. Download dataset (e.g., from Kaggle)
2. Run `pilz create-dc --src Iris.csv --out datacard.yaml`
3. Edit the generated YAML to set correct file paths and adjust feature types
4. Update `train_files` and `test_files` with your actual paths