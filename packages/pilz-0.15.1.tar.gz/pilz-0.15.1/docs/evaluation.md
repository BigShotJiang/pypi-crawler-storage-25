# Evaluation

This document describes evaluation and inference workflows.

## Evaluation Settings

### Example eval_settings.yaml

```yaml
in_folders:
  - test
out_folder: eval
out_file: predictions.csv
max_parallel_where: 1000
```

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `in_folders` | list | - | Directories containing trained models |
| `out_folder` | string | - | Output directory for results |
| `out_file` | string | null | Output file path (.csv or .parquet) |
| `max_parallel_where` | int | 1000 | Split SQL into batches if exceeded |
| `keep_cols` | list | null | Columns to include in output |
| `max_workers` | int | 1 | Parallel processing threads |

## Eval Command

```bash
pilz eval --datacard datacard.yaml --evalsettings eval_settings.yaml
```

### What It Does

1. Loads trained models from `in_folders`
2. Runs inference on test data
3. Computes ROC curves for each class
4. Calculates multi-class accuracy
5. Generates HTML visualizations
6. Saves predictions to file

### Output Files

```
eval/
├── Yes_roc.html           # ROC curve for class "Yes"
├── No_roc.html            # ROC curve for class "No"
├── all_roc.html           # Combined ROC curves
├── multi_class_result.html # Per-class accuracy bar chart
└── predictions.csv        # Prediction scores
```

## Infer Command

```bash
pilz infer --datacard datacard.yaml --evalsettings eval_settings.yaml
```

Inference-only mode:
- Loads models and runs predictions
- **Skips** ROC curve computation
- Faster for production deployment
- Useful when you only need prediction scores

## ROC Curves

### How It Works

```mermaid
flowchart TB
    subgraph Input["Data"]
        P[Predictions] -->|Sort by score| PS[Sorted Scores]
    end

    subgraph Compute["Compute Rates"]
        PS --> TP[True Positive Rate]
        PS --> FP[False Positive Rate]
    end

    subgraph Output["Visualization"]
        TP --> PLOT[ROC Plot]
        FP --> PLOT
    end
```

### ROC HTML Format

```html
<!-- Interactive Altair chart -->
<!-- X-axis: False Positive Rate -->
<!-- Y-axis: True Positive Rate -->
<!-- Title: "<class> (AUC 0.8423)" -->
```

## Multi-Class Handling

For datasets with more than 2 classes, Pilz:

1. Trains separate models for each class (one-vs-rest)
2. Computes ROC for each class
3. Determines predicted class by highest score:

```python
predicted_class = argmax([score_yes, score_no])
```

4. Calculates per-class accuracy

```mermaid
flowchart LR
    subgraph Scores["Prediction Scores"]
        S1["Yes: 0.7"]
        S2["No: 0.3"]
    end

    S1 --> M[G矢MAX]
    S2 --> M
    M --> P[Predicted: Yes]
```

## SQL Rule Generation

Pilz generates SQL CASE statements for deployment:

```sql
SELECT
    CASE
        WHEN job = 'admin.' AND balance > 1000 THEN 0.85
        WHEN job = 'admin.' AND balance <= 1000 THEN 0.45
        ELSE 0.20
    END AS predicted_churn
FROM customers
```

### Large Rule Sets

If a tree has many nodes, SQL is split into batches:

```sql
-- Batch 1
SELECT
    CASE WHEN cond1 THEN score WHEN cond2 THEN score ... END as col1
FROM df

-- Batch 2
SELECT
    CASE WHEN cond10 THEN score ... END as col2
FROM df

-- Combined
col1 + col2
```

The `max_parallel_where` parameter controls this batching.

## Deployment Options

### Direct SQL

Copy the SQL CASE statement from model JSON and embed in your application:

```python
model = load_pilz("Yes/0.json")
sql = model.get_sql("result")
```

### Python Integration

```python
from pilz.model import Pilz, Pilze
import duckdb

# Load models
pilze = Pilze.load_folder("output/Yes")

# Execute predictions
df = duckdb.sql("""
    SELECT *, ({}) as score
    FROM test_data
""".format(pilze.get_sql("score"))).fetchdf()
```

## Understanding Outputs

### Prediction Scores

Each row gets a score per class:

| row_id | Yes | No | actual |
|--------|-----|-----|--------|
| 1 | 0.85 | 0.15 | Yes |
| 2 | 0.20 | 0.80 | No |
| 3 | 0.55 | 0.45 | Yes |

### ROC Curve Interpretation

- **AUC = 1.0**: Perfect classifier
- **AUC = 0.5**: Random guessing
- **AUC < 0.5**: Worse than random (flip predictions)

### Accuracy Bar Chart

Shows per-class prediction accuracy:

```
Class Yes:  ████████████████████ 85%
Class No:   ██████████████████   82%
```

## Performance Notes

- Models are cached in memory during evaluation
- Parallel processing available via `max_workers`
- Large rule sets are batched to avoid SQL length limits