# Training

This document describes the training algorithm, feature categorization, and configuration settings.

## Algorithm Overview

Pilz builds decision trees using a recursive algorithm with three-way splits. Unlike traditional binary trees, each node splits data into three branches: **Left** (low target rate), **Neutral** (medium target rate), and **Right** (high target rate).

```mermaid
flowchart TB
    A[Root: All Data] --> B{Stop Criteria?}
    B -->|No| C[Categorize Features]
    C --> D[Find Best Split]
    D --> E[Left: Low Rate]
    D --> F[Neutral: Medium Rate]
    D --> G[Right: High Rate]
    E --> H[Recurse]
    F --> H
    G --> H
    H --> B
    B -->|Yes| I[Create Spore]
    I --> J[(Leaf Node)]
```

## Training Settings

### Example train_settings.yaml

```yaml
n: 5
out_folder: 'output'
max_depth: 10
frac_eval_cat: 0.8
max_eval_fit: 1000
min_eval_fit: 10
n_dims: 3
n_cat: 5
calcs_per_dim: 1000
```

### Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `n` | int | - | **Number of trees** per target value |
| `out_folder` | string | - | Output directory for trained models |
| `max_depth` | int | - | Maximum tree depth |
| `frac_eval_cat` | float | 0.8 | Fraction of data for evaluation vs categorization |
| `max_eval_fit` | int | - | Maximum samples for training |
| `min_eval_fit` | int | - | Minimum samples before stopping |
| `n_dims` | int | 1 | Feature combinations to evaluate |
| `n_cat` | int | 5 | Number of categories per feature |
| `calcs_per_dim` | int | null | Max calculations per dimension (early exit) |
| `max_workers` | int | 1 | Number of parallel threads |

## Feature Categorization

Features are automatically binned to reduce cardinality and improve split quality.

### Categorical Features

Categories are grouped based on their **target rate** (proportion of positive samples):

```
Category A: 10 samples, 8 target → rate = 0.80
Category B: 20 samples, 4 target → rate = 0.20
Category C: 15 samples, 9 target → rate = 0.60
```

Groups with similar target rates are binned together:

- **Bin 0**: A (0.80)
- **Bin 1**: C (0.60)
- **Bin 2**: B (0.20)

### Numerical Features

Continuous values are split into quantile bins:

```
Values: 1, 2, 3, ..., 100

With n_cat=4:
- Bin 0: 1-25 (quantile 0-0.25)
- Bin 1: 26-50 (quantile 0.25-0.5)
- Bin 2: 51-75 (quantile 0.5-0.75)
- Bin 3: 76-100 (quantile 0.75-1.0)
```

## Three-Way Split Algorithm

### How It Works

1. **Categorize** each feature into bins
2. **Calculate** target rate for each category
3. **Sort** categories by target rate
4. **Split** into three groups using `neutral_faktor`:

```mermaid
flowchart LR
    subgraph Sorted["Categories sorted by target rate"]
        L["Low Rate"] --> N["Medium Rate"] --> R["High Rate"]
    end

    subgraph Split
        L2[Left] -->|"rate < neutral_faktor"| L3[Left Filter]
        N2[Neutral] -->|"rate ≈ neutral_faktor"| N3[Neutral Filter]
        R2[Right] -->|"rate > 1-neutral_faktor"| R3[Right Filter]
    end

    L --> L2
    N --> N2
    R --> R2
```

### Neutral State

The neutral branch handles ambiguous cases. Samples in the neutral zone continue to be refined in subsequent splits, allowing incremental decision refinement.

## Multi-Dimensional Splits (n_dims)

The `n_dims` parameter controls feature combinations:

| n_dims | Evaluation |
|--------|------------|
| 1 | Each feature individually |
| 2 | All pairs of features |
| 3 | All triplets of features |
| k | All k-tuples of features |

Example for `n_dims=2` with features [A, B, C]:

```
Evaluated combinations:
- A (single)
- B (single)
- C (single)
- A AND B (pair)
- A AND C (pair)
- B AND C (pair)
```

> **Warning**: Higher `n_dims` increases computation exponentially. Use `calcs_per_dim` to limit evaluations.

## Pseudocode

```
TRAIN_FOREST(dc, settings):
    FOR tree_index IN 0..settings.n:
        FOR target_class IN dc.target.values:
            IF NOT cached(target_class, tree_index):
                pilz = TRAIN_TREE(target_class, [], "")
                SAVE(pilz, tree_index)

TRAIN_TREE(target_filter, path_filters, depth):
    train_df = READ_DATA(target_filter, path_filters)

    IF train_df.is_final_size() OR depth.length >= settings.max_depth:
        RETURN [Spore(cuts=path_filters, score=train_df.score())]

    cater(train_df)

    left_filter, neutral_filter, right_filter = counter(train_df)

    IF left_filter IS NULL AND right_filter IS NULL:
        RETURN [Spore(cuts=path_filters, score=train_df.score())]

    left_spores   = TRAIN_TREE(target_filter, path_filters + [left_filter],   depth + "l")
    neutral_spores= TRAIN_TREE(target_filter, path_filters + [neutral_filter], depth + "n")
    right_spores  = TRAIN_TREE(target_filter, path_filters + [right_filter],  depth + "r")

    RETURN left_spores + neutral_spores + right_spores

CATER(train_df):
    FOR feat IN dc.features:
        categorized = FEAT_CATER(feat, train_df, settings.n_cat)
        IF categorized.is_useful():
            train_df.features.append(categorized)

CATEGORIZE_CATEGORICAL(feat, train_df, n):
    grouped = GROUP_BY(feat.name).agg(
        weight=SUM(weight),
        target_weight=SUM(target_weight)
    )
    grouped["target_rate"] = target_weight / weight
    grouped = SORT_BY(target_rate)

    large_cats = []
    small_cats = []

    FOR cat IN grouped:
        IF cat.weight > 1/n:
            large_cats.APPEND(cat)
        ELSE:
            small_cats.APPEND(cat)

    remaining_bins = n - LENGTH(large_cats)
    FOR cat IN small_cats:
        cat.bin = ASSIGN_QUANTILE_BIN(cat, remaining_bins)

    RETURN categorized_feature

CATEGORIZE_NUMERICAL(feat, train_df, n):
    sorted = SORT_BY(feat.name)
    cum_weights = CUMULATIVE_SUM(sorted.weight)

    cuts = []
    FOR i IN 1..n:
        quantile = i/n
        cut_point = INTERPOLATE(cum_weights, quantile)
        cuts.APPEND(cut_point)

    RETURN categorized_feature

FIND_BEST_SPLIT(train_df):
    scored_features = []
    FOR feat IN train_df.features:
        scored_features.APPEND((feat, feat.calc_diff()))

    scored_features = SORT_BY(scored_features.score, DESC)

    best = scored_features[0]

    FOR dim IN 2..settings.n_dims:
        FOR comb IN combinations(scored_features, dim):
            combined = CombinedFeature(comb)
            IF combined.calc_diff() > best.score:
                best = combined

            IF settings.calcs_per_dim AND counter > settings.calcs_per_dim:
                BREAK

    RETURN best.get_left_neutral_right_filters()
```

## Output

Training produces JSON files organized by target class:

```
output/
├── Yes/          # Target class "Yes"
│   ├── 0.json    # Tree 0
│   ├── 1.json    # Tree 1
│   └── ...
├── No/           # Target class "No"
│   ├── 0.json
│   ├── 1.json
│   └── ...
```

### JSON Structure

Each JSON file contains:

```json
{
    "spores": [
        {
            "cut": ["job = 'admin.'", "balance > 1000"],
            "score": 0.85,
            "depth": "lr"
        }
    ],
    "target": "Yes"
}
```

## Performance Tips

1. **Start with n=1**: Verify correctness before increasing trees
2. **Use n_dims=1 or 2**: Higher values are expensive
3. **Set calcs_per_dim**: Prevent runaway computation
4. **Adjust max_depth**: Prevent overfitting
5. **Tune n_cat**: More categories = more splits but risk of overfitting