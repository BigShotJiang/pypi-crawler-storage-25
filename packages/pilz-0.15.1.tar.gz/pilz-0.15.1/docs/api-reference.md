# API Reference

## CLI Commands

Pilz provides four commands via the `pilz` command-line tool.

### train

Train decision tree models.

```bash
pilz train --datacard <file.yaml> --trainsettings <file.yaml>
```

**Arguments:**

| Argument | Description |
|----------|-------------|
| `--datacard` | DataCard YAML file describing the dataset |
| `--trainsettings` | TrainSettings YAML file with training parameters |

**Example:**

```bash
pilz train --datacard dc.yaml --trainsettings train_settings.yaml
```

**Output:** JSON model files in the configured `out_folder`

---

### eval

Evaluate trained models and generate ROC curves.

```bash
pilz eval --datacard <file.yaml> --evalsettings <file.yaml>
```

**Arguments:**

| Argument | Description |
|----------|-------------|
| `--datacard` | DataCard YAML file |
| `--evalsettings` | EvalSettings YAML file |

**Example:**

```bash
pilz eval --datacard dc.yaml --evalsettings eval_settings.yaml
```

**Output:** Predictions, ROC curves, and accuracy charts

---

### infer

Run inference only (no metrics or visualizations).

```bash
pilz infer --datacard <file.yaml> --evalsettings <file.yaml>
```

**Arguments:**

| Argument | Description |
|----------|-------------|
| `--datacard` | DataCard YAML file |
| `--evalsettings` | EvalSettings YAML file |

**Example:**

```bash
pilz infer --datacard dc.yaml --evalsettings eval_settings.yaml
```

**Output:** Prediction scores only (faster for production)

---

### create-dc

Generate a DataCard from a dataset.

```bash
pilz create-dc --src <path> --out <file.yaml>
```

**Arguments:**

| Argument | Description |
|----------|-------------|
| `--src` | Path to CSV or Parquet file |
| `--out` | Output DataCard YAML file (with prompt if omitted) |

**Example:**

```bash
pilz create-dc --src data.csv --out datacard.yaml
```

**Interactive Prompts:**
- Select target column
- Select feature types (categorial/numerical) for each column
- Confirm missing value handling

---

## Configuration Files

### DataCard YAML

See [DataCard Format](./datacard.md) for detailed reference.

### TrainSettings YAML

```yaml
# Required
n: 5                           # Number of trees per target
out_folder: 'output'            # Output directory

# Optional
max_depth: 10                  # Maximum tree depth (default: unlimited)
frac_eval_cat: 0.8             # Data split ratio
max_eval_fit: 1000             # Maximum training samples
min_eval_fit: 10               # Minimum samples before stopping
n_dims: 3                      # Feature combinations
n_cat: 5                       # Categories per feature
calcs_per_dim: 1000            # Max evaluations per dimension
max_workers: 1                 # Parallel threads
```

### EvalSettings YAML

```yaml
# Required
in_folders:                    # List of model directories
  - test
out_folder: eval               # Output directory

# Optional
out_file: predictions.csv       # Output file (.csv or .parquet)
max_parallel_where: 1000       # SQL batching threshold
keep_cols:                     # Columns to include
  - id
  - date
max_workers: 1                 # Parallel threads
```

---

## File Formats

### Model JSON

```
output/
├── Yes/
│   ├── 0.json
│   ├── 1.json
│   └── ...
└── No/
    ├── 0.json
    ├── 1.json
    └── ...
```

Each JSON file structure:

```json
{
    "spores": [
        {
            "cut": [
                "job = 'admin.'",
                "balance > 1000"
            ],
            "score": 0.85,
            "depth": "lr"
        }
    ],
    "target": "Yes"
}
```

### Prediction Output

CSV or Parquet with columns:

| Column | Description |
|--------|-------------|
| `<target>_0` | Score from tree 0 |
| `<target>_1` | Score from tree 1 |
| ... | ... |
| `<target>` | Mean score across trees |
| `<original_target>` | Actual label (if target column present) |
| `correct` | 1 if prediction matches actual |
| `predicted_<target>` | Predicted class (multi-class only) |