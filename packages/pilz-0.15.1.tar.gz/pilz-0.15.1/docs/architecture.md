# Architecture

## Overview

Pilz follows a layered architecture with clear separation between CLI, services, and models.

```mermaid
graph TB
    subgraph CLI["CLI Layer"]
        CLI[("cli.py")]
    end

    subgraph Services["Service Layer"]
        Train[("train.py")]
        Eval[("eval.py")]
        Darkwing[("darkwing.py")]
        DCHelper[("datacardhelper.py")]
    end

    subgraph Models["Model Layer"]
        DC[("datacard.py")]
        Settings[("settings.py")]
        Pilz[("pilz.py")]
        DF[("dataframes.py")]
        Filter[("filter.py")]
    end

    subgraph External["External Libraries"]
        DuckDB[("DuckDB")]
        Polars[("Polars")]
        Sympy[("SymPy")]
    end

    CLI --> Train
    CLI --> Eval
    CLI --> DCHelper

    Train --> Darkwing
    Eval --> Darkwing

    Train --> DC
    Train --> Settings
    Train --> Pilz
    Train --> DF
    Train --> Filter

    Eval --> DC
    Eval --> Settings
    Eval --> Pilz
    Eval --> Filter

    Darkwing --> DC
    Darkwing --> Pilz
    Darkwing --> DF
    Darkwing --> Filter
    Darkwing --> Settings

    Darkwing --> DuckDB
    Darkwing --> Polars

    Filter --> Sympy
```

## CLI Layer

The CLI layer (`cli.py`) provides four commands using Typer:

| Command | Purpose |
|---------|---------|
| `train` | Train decision tree models |
| `eval` | Evaluate models and generate ROC curves |
| `infer` | Run inference only (no metrics) |
| `create-dc` | Generate datacard from CSV/Parquet |

## Service Layer

### Train Service

Handles the recursive tree-building algorithm:

```mermaid
flowchart LR
    A[Load Data] --> B[Categorize Features]
    B --> C[Find Best Split]
    C --> D{Stop\nCriteria?}
    D -->|No| E[Split Data]
    D -->|Yes| F[Create Spore]
    E --> G[Recurse Left]
    E --> H[Recurse Neutral]
    E --> I[Recurse Right]
    G --> F
    H --> F
    I --> F
    F --> J[(Save JSON)]
```

### Darkwing Service

Data access layer using DuckDB and Polars:

```mermaid
flowchart TB
    subgraph DataSources["Data Sources"]
        CSV[(CSV)]
        Parquet[(Parquet)]
    end

    subgraph Caching["Caching"]
        TrainCache[("Train Cache")]
        EvalCache[("Eval Cache")]
    end

    subgraph Operations["Operations"]
        Read[read_akt_train]
        Eval[get_eval_sr]
    end

    CSV --> Read
    Parquet --> Read
    CSV --> Eval
    Parquet --> Eval

    Read --> TrainCache
    Eval --> EvalCache
```

## Model Layer

### Data Flow

```mermaid
sequenceDiagram
    participant CLI
    participant Train
    participant Darkwing
    participant DF
    participant Filter
    participant DuckDB

    CLI->>Train: run()
    Train->>Darkwing: read_akt_train()
    Darkwing->>DuckDB: SQL query
    DuckDB-->>Darkwing: DataFrame
    Darkwing-->>Train: TrainDataframes
    Train->>DF: cater()
    Train->>DF: counter()
    DF->>Filter: Sympy expressions
    Filter-->>DF: SQL WHERE
    DF-->>Train: best feature
    Train->>Train: recurse
    Train-->>CLI: Pilz JSON
```

### Key Data Structures

#### Spore (Leaf Node)

A single rule in the decision tree:

```mermaid
classDiagram
    class Spore {
        +list~str~ cut
        +float score
        +str depth
    }
```

#### Pilz (Single Tree)

```mermaid
classDiagram
    class Pilz {
        +list~Spore~ spores
        +str target
        +str get_sql()
        +str get_where_sql()
    }
    class Spore
    Pilz "1" --> "*" Spore : contains
```

#### Pilze (Ensemble)

```mermaid
classDiagram
    class Pilze {
        +dict~str, Pilz~ pilze
        +str target
        +str get_sql()
    }
    class Pilz
    Pilze "1" --> "*" Pilz : contains
```

## Training Algorithm

### Three-Way Split

Unlike traditional binary decision trees, Pilz splits data into three branches:

```mermaid
flowchart TB
    A[Root] --> B[Left<br/>Low Target Rate]
    A --> C[Neutral<br/>Medium Target Rate]
    A --> D[Right<br/>High Target Rate]
```

### Feature Categorization

Features are automatically binned:

```mermaid
flowchart TB
    subgraph Categorical["Categorical Features"]
        C1["A, B, C, D, E"] -->|"Group by<br/>target rate"| C2["Bin 0: A, B<br/>Bin 1: C<br/>Bin 2: D, E"]
    end

    subgraph Numerical["Numerical Features"]
        N1["1, 2, 3, ..., 100"] -->|"Quantile<br/>bins"| N2["Bin 0: 1-25<br/>Bin 1: 26-50<br/>Bin 2: 51-75<br/>Bin 3: 76-100"]
    end
```

### Multi-Dimensional Splits

The `n_dims` parameter allows combining features:

```mermaid
flowchart LR
    subgraph D1["n_dims=1"]
        A1[Feature A]
        B1[Feature B]
    end

    subgraph D2["n_dims=2"]
        A2["A AND B"]
    end

    subgraph D3["n_dims=3"]
        A3["A AND B AND C"]
    end

    A1 --> A2
    B1 --> A2
    A2 --> A3
    B1 --> A3
    C1[Feature C] --> A3
```

## File Structure

```
src/pilz/
├── __init__.py          # Logging setup
├── cli.py               # CLI entry points
├── model/               # Data models
│   ├── datacard.py     # DataCard, Feature, Target
│   ├── dataframes.py   # Category handling
│   ├── filter.py       # SymPy to SQL
│   ├── pilz.py         # Spore, Pilz, Pilze
│   └── settings.py     # TrainSettings, EvalSettings
└── service/            # Business logic
    ├── darkwing.py      # Data access
    ├── datacardhelper.py # DataCard creation
    ├── eval.py          # Evaluation
    └── train.py         # Training
```

## Data Flow Summary

```
YAML Config
    │
    ▼
┌──────────────────────────────────────────┐
│              DataCard                      │
│  (features, target, file paths)           │
└──────────────────────────────────────────┘
    │
    ▼
┌──────────────────────────────────────────┐
│              Train Service                │
│                                          │
│  For each target value:                  │
│    For n trees:                          │
│      - Read filtered data                │
│      - Categorize features               │
│      - Find best split                   │
│      - Recurse (3 branches)              │
│      - Save Pilz to JSON                 │
└──────────────────────────────────────────┘
    │
    ▼
┌──────────────────────────────────────────┐
│           Trained Models                  │
│  (JSON files in out_folder)              │
└──────────────────────────────────────────┘
    │
    ▼
┌──────────────────────────────────────────┐
│              Eval Service                │
│                                          │
│  - Load Pilze from JSON                  │
│  - Generate SQL CASE statements         │
│  - Execute via DuckDB                    │
│  - Compute ROC curves                    │
│  - Save predictions                      │
└──────────────────────────────────────────┘
```