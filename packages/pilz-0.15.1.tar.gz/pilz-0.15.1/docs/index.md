# Pilz

Pilz is a decision tree-based machine learning library for classification tasks. It uses a novel approach with three-way splits (left/neutral/right) and generates SQL-based rules that can be executed directly in DuckDB.

## Key Features

- **Three-Way Split Decision Trees**: Unlike traditional binary trees, Pilz uses a neutral branch for ambiguous cases
- **Feature Categorization**: Automatically bins continuous and categorical features for better splits
- **Multi-Dimensional Splits**: Evaluates combinations of features (n_dims parameter)
- **SQL Rule Generation**: Outputs interpretable SQL WHERE clauses for deployment
- **Multi-Class Support**: Handles binary and multi-class classification

## Installation

```bash
pip install pilz
```

Or using uv:

```bash
uv init --python 3.13 pmushroom
cd mushroom
uv add pilz
source .venv/bin/activate
```

> **Note**: Pilz requires Python >= 3.13 and is currently available for macOS (ARM) and Linux (x86).

## Quick Start

### 1. Create a DataCard

Describe your dataset using a YAML file:

```bash
pilz create-dc --src data.csv --out datacard.yaml
```

### 2. Train a Model

```bash
pilz train --datacard datacard.yaml --trainsettings train_settings.yaml
```

### 3. Evaluate

```bash
pilz eval --datacard datacard.yaml --evalsettings eval_settings.yaml
```

### 4. Run Inference

```bash
pilz infer --datacard datacard.yaml --evalsettings eval_settings.yaml
```

## Documentation

### Getting Started
- [Installation & Quick Start](./index.md) - Overview and setup

### Core Concepts
- [Architecture](./architecture.md) - System design and data flow diagrams
- [DataCard Format](./datacard.md) - YAML configuration reference

### Usage Guides
- [Training](./training.md) - Training algorithm and settings reference
- [Evaluation](./evaluation.md) - Evaluation, inference, and deployment
- [API Reference](./api-reference.md) - CLI command reference

### Examples
- [Churn Prediction](./examples/churn.md) - Binary classification tutorial
- [Bank Term Deposit](./examples/bank-term-deposit.md) - Marketing prediction
- [MNIST Digits](./examples/mnist.md) - Multi-class classification
- [Iris Flowers](./examples/iris.md) - Simple 3-class problem

## Disclaimer

The documentation is still work in progress. The code is available at:
- GitLab: https://gitlab.com/gwhe/pilz