from pathlib import Path

from pydantic import BaseModel, Field


class EvalSettings(BaseModel):
    in_folders: list[Path] = Field(description="Name where the pilze was stored")
    out_folder: Path = Field(description="Name where the evaluation is stored")
    keep_cols: list[str] = Field(description="Columns keep for to infer", default=[])
    out_file: str | None = Field(description="Name of the output file", default=None)
    max_parallel_where: int = Field(
        description="Number of points for roc curve", default=100
    )


class TrainSettings(BaseModel):
    n: int = Field(description="Number of Pilze per target value", default=1)
    out_folder: Path = Field(description="Name where the pilz will be stored")
    n_cat: int = Field(description="Number of categories in one featerue", default=3)
    max_depth: int = Field(description="Max depth of the pilz", default=10)

    max_eval_fit: int = Field(
        description="Wieviel sollen max für training gleichzeitig benutzt werden",
        default=1000,
    )
    min_eval_fit: int = Field(
        description="Wieviel müssen fürs training mindestens benutzt werden", default=10
    )
    n_dims: int = Field(
        description="Wieviele dimensionen sollen auf einmal benutzt werden", default=3
    )
    calcs_per_dim: int | None = Field(
        description="Wieviele berechnungen sollen pro dimension gemacht werden",
        default=5000,
    )
    frac_eval_cat: float = Field(
        description="Wie groß ist der anteil der für eval benutzt werden soll",
        default=0.5,
    )

    neutral_faktor: float = Field(
        description="Faktor wie groß der Unterschied für Neutral sein soll. D.h. combs die nicht eindeutig zuzuweisen sind. Wenn der Wert 0 ist dann werden nur die absolut gliechen und die berreiche wo keine datan vorhanden sind als neutral eingstufft. Was keinen unterschied auf die auswahl des besten splits hat.",
        default=0.0,
        ge=0.0,
        le=1.0,
    )

    use_neutral_state: bool = Field(
        description="Falls ja wird eine dritte targeget kategorei erstellt in den alle Daten mit neutral landen. Falls neutral_faktor 0 ist sind das nur die absolut gleich sind oder die keine Datan im training haben. ",
        default=False,
    )

