# AGENTS.md - Pilz Machine Learning CLI

## Overview
- **Type**: Python CLI tool for ML (decision tree-based classification)
- **Python**: >=3.13 required
- **Entry point**: `pilz` command (from pyproject.toml)

## Quick Commands

```bash
# Install dev dependencies
uv sync

# Run examples
cd examples/mnist && ./run.sh

# CLI commands
pilz train --datacard <file.yaml> --trainsettings <file.yaml>
pilz eval --datacard <file.yaml> --evalsettings <file.yaml>
pilz infer --datacard <file.yaml> --evalsettings <file.yaml>
pilz create-dc --src <path> --out <file.yaml>
```

## Key Settings (from TrainSettings/EvalSettings)
- `max_workers`: Number of threads for parallel training/evaluation
- `n`: Number of trees per target value
- `n_cat`: Number of categories per feature
- `max_depth`: Max tree depth
- `n_dims`: Feature combinations to evaluate

## Architecture
- `src/pilz/cli.py` - CLI entry points
- `src/pilz/service/train.py` - Tree training logic
- `src/pilz/service/eval.py` - Evaluation logic
- `src/pilz/service/darkwing.py` - Data access layer
- `src/pilz/model/pilz.py` - Trained model representation (Spore, Pilz, Pilze)

## Gotchas
- YAML config files use `statistical: categorial` (not "categorical") for categorical features
- Requires both a datacard YAML and settings YAML
- venv at `.venv/` - activate before running pilz commands