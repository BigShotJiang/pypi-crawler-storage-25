import XCTest
import Foundation

/// SpecterQARunner — Main XCTest entry point.
///
/// This XCTestCase subclass boots an HTTP server inside the iOS Simulator
/// and keeps the test process alive indefinitely. External clients (Python,
/// shell scripts) send POST/GET requests to inject touches, type text, and
/// capture screenshots without any CGEvent or Accessibility permission.
///
/// Architecture mirrors WebDriverAgent / Maestro:
///   xcodebuild test-without-building  →  SpecterQARunnerTests/testServe()
///   HTTP server listens on :8222
///   Python client  →  POST /tap  →  XCUICoordinate.tap()
///
class SpecterQARunnerTests: XCTestCase {

    // MARK: - Entry point

    /// The single long-running test. xcodebuild keeps this alive until the
    /// HTTP server receives POST /shutdown or the process is killed.
    func testServe() throws {
        let port = resolvePort()
        let bundleId = resolveBundleId()

        let injector = TouchInjector(bundleId: bundleId)

        // Launch the app with retries. Springboard may not be ready
        // immediately after sim boot — retry up to 3 times.
        var launchAttempts = 0
        let maxAttempts = 3
        while injector.app.state != .runningForeground && launchAttempts < maxAttempts {
            launchAttempts += 1
            NSLog("[SpecterQA] Launching app '\(bundleId)' (attempt \(launchAttempts)/\(maxAttempts))...")
            do {
                injector.app.launch()
            } catch {
                NSLog("[SpecterQA] Launch attempt \(launchAttempts) failed: \(error)")
            }
            let launched = injector.app.wait(for: .runningForeground, timeout: 10)
            if launched {
                NSLog("[SpecterQA] App launched successfully on attempt \(launchAttempts)")
                break
            }
            if launchAttempts < maxAttempts {
                NSLog("[SpecterQA] Waiting before retry...")
                Thread.sleep(forTimeInterval: 3)
            }
        }
        if injector.app.state != .runningForeground {
            NSLog("[SpecterQA] WARNING: App failed to reach foreground after \(maxAttempts) attempts (state=\(injector.app.state.rawValue))")
        }

        let server = HTTPServer(port: port, injector: injector)

        try server.start()

        NSLog("[SpecterQA] Runner listening on port \(port) targeting bundle '\(bundleId)' (app state=\(injector.app.state.rawValue))")
        NSLog("[SpecterQA] Endpoints: GET /health  GET /source  GET /screenshot  POST /tap  POST /swipe  POST /type  POST /key  POST /press_button  POST /shutdown")

        // Keep the test thread alive by spinning the RunLoop indefinitely.
        // XCTest APIs (tap, swipe) must dispatch to the main thread.
        // CFRunLoopRun() alone exits after the first dispatched block completes.
        // Using CFRunLoopRunInMode in a loop ensures we stay alive.
        NSLog("[SpecterQA] Entering run loop (tap/swipe/type will work)...")
        while server.isRunning {
            CFRunLoopRunInMode(.defaultMode, 0.1, true)
        }

        NSLog("[SpecterQA] Runner stopped — test exiting cleanly.")
    }

    // MARK: - Configuration helpers

    /// Port resolution order:
    ///   1. SPECTERQA_PORT env var (set by launch.sh via xcodebuild)
    ///   2. Hard-coded default 8222
    private func resolvePort() -> UInt16 {
        if let raw = ProcessInfo.processInfo.environment["SPECTERQA_PORT"],
           let value = UInt16(raw) {
            return value
        }
        return 8222
    }

    /// Bundle ID of the app-under-test resolution order:
    ///   1. SPECTERQA_BUNDLE_ID env var
    ///   2. Hard-coded sentinel — callers should always supply this
    private func resolveBundleId() -> String {
        return ProcessInfo.processInfo.environment["SPECTERQA_BUNDLE_ID"]
            ?? "com.example.app"
    }
}
