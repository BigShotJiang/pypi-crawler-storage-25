"""SpecterQA iOS security primitives."""
