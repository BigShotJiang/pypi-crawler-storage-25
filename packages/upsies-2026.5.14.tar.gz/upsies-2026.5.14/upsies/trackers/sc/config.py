"""
Concrete :class:`~.TrackerConfigBase` subclass for SC
"""

import base64

from ... import utils
from .. import base

ScImagehost = utils.types.Imagehost(
    disallowed=(
        ()
        if utils.is_running_in_development_environment() else
        ('dummy',)
    ),
)


class ScTrackerConfig(base.TrackerConfigBase):
    base_url: base.config.base_url(
        base64.b64decode('aHR0cHM6Ly9zZWNyZXQtY2luZW1hLnB3Lw==').decode('ascii'),
    )

    username: base.config.username('')

    password: base.config.password('')

    cookies_filepath: base.config.cookies_filepath('')

    announce_url: base.config.announce_url('', autofetched=True)

    image_host: base.config.image_host(
        ScImagehost,
        default=('imgbox', 'freeimage'),
    )

    screenshots_count: base.config.screenshots_count(3, min=3, max=10)

    exclude: base.config.exclude(
        base.exclude_regexes.checksums,
        base.exclude_regexes.extras,
        base.exclude_regexes.garbage,
        base.exclude_regexes.images,
        base.exclude_regexes.nfo,
        base.exclude_regexes.samples,
    )

    confirm: base.config.confirm('no')


cli_arguments = {
    'submit': {
        ('--imdb', '--im'): {
            'help': 'IMDb ID or URL',
            'type': utils.argtypes.webdb_id('imdb'),
        },
        ('--screenshots-count', '--ssc'): {
            'help': ('How many screenshots to make '
                     f'(min={ScTrackerConfig.defaults["screenshots_count"].min}, '
                     f'max={ScTrackerConfig.defaults["screenshots_count"].max})'),
            'type': utils.argtypes.make_integer(
                min=ScTrackerConfig.defaults['screenshots_count'].min,
                max=ScTrackerConfig.defaults['screenshots_count'].max,
            ),
        },
        ('--screenshots', '--ss'): {
            'help': (
                'Path(s) to existing screenshot file(s)\n'
                'Directories are searched recursively.\n'
                'More screenshots are created if necessary.'
            ),
            'nargs': '+',
            'action': 'extend',
            'type': utils.argtypes.files_with_extension('png'),
            'metavar': 'SCREENSHOT',
        },
        ('--edition',): {
            'help': (
                'Edition information in the format "YEAR,TITLE,DISTRIBUTOR,CATALOGUE_NUMBER"\n'
                'Every value except for YEAR may be empty.'
            ),
        },
        ('--edition-year', '--ey'): {
            'help': 'Editon year (overloads YEAR from --edition)',
        },
        ('--edition-title', '--et'): {
            'help': 'Editon title (overloads TITLE from --edition)',
        },
        ('--edition-distributor', '--ed'): {
            'help': 'Editon year (overloads DISTRIBUTOR in --edition)',
        },
        ('--edition-catalogue-number', '--ec'): {
            'help': 'Editon year (overloads CATALOGUE_NUMBER in --edition)',
        },
        ('--poster', '--po'): {
            'help': 'Path or URL to poster image',
        },
        ('--trailer', '--tr'): {
            'help': 'Trailer URL (Vimeo or YouTube)',
        },
        ('--only-description', '--od'): {
            'help': 'Only generate description (do not submit)',
            'action': 'store_true',
            'group': 'generate-metadata',
        },
    },
}
