from ... import errors
from ..base import rules


class ScBannedGroup(rules.BannedGroup):
    banned_groups = {
        'aXXo',
        'BRRip',
        'CM8',
        'CrEwSaDe',
        'DNL',
        'FaNGDiNG0',
        'HD2DVD',
        'HDTime',
        'iPlanet',
        'mHD',
        'mSD',
        'NhaNc3',
        'nHD',
        'nikt0',
        'nSD',
        'PRODJi',
        'RARBG',
        'SANTi',
        'SPIRIT',
        'ViSION',
        'WAF',
        'x0r',
        'YIFY',
    }

    async def _check_custom(self):
        # No EVO encodes. WEB-DLs are fine.
        if (
                self.is_group('EVO')
                and 'WEB-DL' not in self.release_name.source
        ):
            raise errors.BannedGroup('EVO', additional_info='No encodes, only WEB-DL')
