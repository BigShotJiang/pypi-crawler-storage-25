"""
Hardcoded SC metadata from upload.php
"""

import re

from ... import utils

types = {
    'Movies': '0',
    # 'Music': '1',    # Not supported.
    # 'E-Books': '2',  # Not supported.
}

media = {
    'BDMV': lambda release: bool(re.search(r'^BD(?:25|50|66|100)$', release.source)),  # Do not match BDRip.
    '2160p': lambda release: release.resolution == '2160p',
    '1080p': lambda release: release.resolution == '1080p',
    '720p': lambda release: release.resolution == '720p',
    'DVD-R': lambda release: bool(re.search(r'^DVD(?:\d|\s|$)', release.source)),  # Do not match DVDRip/HDDVD.
    'SD': lambda release: release.resolution_int and release.resolution_int < 720,
}


tags = {
    'action': 'action',
    'adventure': 'adventure',
    'animation': 'animation',
    'anime': 'anime',
    'arthouse': 'arthouse',
    'badfilm': 'badfilm',
    'biography': 'biography',
    'camp': 'camp',
    'classic': 'classic',
    'comedy': 'comedy',
    'crime': 'crime',
    'criterion': 'criterion',
    'cult': 'cult',
    'documentary': 'documentary',
    'drama': 'drama',
    'erotic': 'erotic',
    'experimental': 'experimental',
    'fantasy': 'fantasy',
    'film.noir': 'film.noir',
    'giallo': 'giallo',
    'history': 'history',
    'horror': 'horror',
    'music': 'music',
    'musical': 'musical',
    'mystery': 'mystery',
    'neo.noir': 'neo.noir',
    'pre.code': 'pre.code',
    'romance': 'romance',
    'sci.fi': 'sci.fi',
    'short': 'short',
    'silent': 'silent',
    'television': 'television',
    'theatre': 'theatre',
    'thriller': 'thriller',
    'war': 'war',
    'western': 'western',
}


class ArtistImportance(utils.PrettyEnum):
    """
    Purpose of a person in a movie

    An instance's :attr:`value` is the value expected by the API. An instance's
    string representation should be human-readable and pretty.
    """
    ACTOR = 5
    DIRECTOR = 1
    WRITER = 2
    PRODUCER = 3
    COMPOSER = 4
    CINEMATOGRAPHER = 6
