from ... import errors
from .. import utils
from ..base import rules

import logging  # isort:skip
_log = logging.getLogger(__name__)


class CbrBannedGroup(rules.BannedGroup):
    # /wikis/28
    banned_groups = {
        '4K4U'
        'afm72',
        'Alcaide_Kira',
        'AROMA',
        'ASM',
        'Bandi',
        'BiTOR',
        'BLUDV',
        'Bluespots',
        'BOLS',
        'CaNNIBal',
        'Comando',
        'd3g',
        'DepraveD',
        'EMBER',
        'FGT',
        'FreetheFish',
        'Garshasp',
        'Ghost',
        'Grym',
        'HDS',
        'Hi10',
        'HiQVE',
        'Hiro360',
        'ImE',
        'ION10',
        'iVy',
        'Judas',
        'LAMA',
        'Langbard',
        'Lapumia',
        'LION',
        'MeGusta',
        'MONOLITH',
        'MRCS',
        'NaNi',
        'Natty',
        'nikt0',
        'OEPlus',
        'OFT',
        'OsC',
        'Panda',
        'PANDEMONiUM',
        'PHOCiS',
        'PiRaTeS',
        'PYC',
        'QxR',
        'r00t',
        'Ralphy',
        'RARBG',
        'RetroPeeps',
        'RZeroX',
        'S74Ll10n',
        'SAMPA',
        'Sicario',
        'SiCFoI',
        'Silence',
        'SkipTT',
        'SM737',
        'SPDVD',
        'STUTTERSHIT',
        'SWTYBLZ',
        't3nzin',
        'TAoE',
        'TEKNO3D',
        'Telly',
        'TGx',
        'Tigole',
        'TSP',
        'TSPxL',
        'TWA',
        'UnKn0wn',
        'VXT',
        'Vyndros',
        'W32',
        'Will1869',
        'x0r',
        'YIFY',
        'YTS.MX',
        'YTS',
    }


class CbrPortuguese(rules.TrackerRuleBase):
    """
    Check if has Portuguese audio or subtitles
    """

    async def _check(self):
        audio_languages = utils.mediainfo.audio.get_audio_languages(
            self.release_name.path,
            exclude_commentary=True,
        )
        subtitle_languages = utils.mediainfo.text.get_subtitles(self.release_name.path)

        _log.debug('Audio languages: %r', audio_languages)
        _log.debug('Subtitle languages: %r', subtitle_languages)

        valid_dub = any(
            language in ('pt', 'zx', 'un')
            for language in audio_languages
        )
        valid_sub = any(
            subtitle.language == 'pt'
            for subtitle in subtitle_languages
        )

        if not valid_dub and not valid_sub:
            raise errors.RuleBroken('Portuguese audio or subtitles is required')
