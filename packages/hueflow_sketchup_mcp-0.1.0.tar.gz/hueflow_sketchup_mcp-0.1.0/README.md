# Hueflow SketchUp MCP

> **SketchUp을 Claude AI에 연결하는 MCP 서버 (한국어 / SketchUp 2024-2026 지원)**
>
> 휴플로우 스튜디오의 인테리어 + AI 강의용으로 한국어화·재패키징한 버전입니다.
> Claude에게 "거실에 3x3x2.5m 방 만들어줘"라고 말하면 SketchUp이 실제로 모델을 만듭니다.

[![PyPI](https://img.shields.io/pypi/v/hueflow-sketchup-mcp)](https://pypi.org/project/hueflow-sketchup-mcp/)
[![SketchUp](https://img.shields.io/badge/SketchUp-2024%20%7C%202025%20%7C%202026-orange)]()
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## ⚡ 빠른 설치 (3단계)

### 1️⃣ SketchUp 플러그인 설치

[Releases 페이지](https://github.com/hueflow-studio/hueflow-sketchup-mcp/releases/latest)에서 **`hueflow_sketchup_mcp.rbz`** 다운로드.

SketchUp 실행 → **창(Window) → 확장 관리자(Extension Manager) → 확장 설치(Install Extension)** → 다운받은 .rbz 파일 선택.

설치 완료 후 SketchUp 재시작.

### 2️⃣ Claude Desktop 설정

**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`

위 파일을 메모장으로 열어서 다음 내용 추가:

```json
{
  "mcpServers": {
    "hueflow-sketchup": {
      "command": "uvx",
      "args": ["hueflow-sketchup-mcp"]
    }
  }
}
```

> 💡 **`uv`가 설치되어 있어야 합니다.** PowerShell에서 `where.exe uv` 입력해서 경로가 나오면 OK.
> 없으면: `winget install --id=astral-sh.uv -e` 실행.

### 3️⃣ 실행

1. **SketchUp 실행** — 자동으로 서버가 8080 포트에서 시작됨
2. **Claude Desktop 실행**
3. Claude에게 명령: *"스케치업에 가로 3미터 세로 4미터 높이 2.5미터 방 만들어줘"*

서버가 자동으로 안 켜지면 SketchUp 메뉴에서 **확장(Plugins) → Hueflow MCP 서버 → 서버 시작** 클릭.

---

## 🎯 할 수 있는 것 (21가지 도구)

| 분류 | 명령 예시 |
|------|----------|
| **모델 정보** | "현재 모델에 어떤 컴포넌트들 있어?" |
| **박스 생성** | "1.2x0.6x0.75m 책상 만들어줘" |
| **원/호** | "반지름 50cm 원 그려줘" |
| **푸시풀** | "이 면 1m 밀어줘" |
| **재질 적용** | "벽에 흰색 페인트 칠해줘" |
| **이동/회전/스케일** | "그 컴포넌트 90도 돌려줘" |
| **지붕 트러스** | "8m 폭에 킹포스트 트러스 만들어줘" |
| **Ruby 코드 실행** | 고급 사용자용 |

---

## ⚠️ 알려진 한계

- **SketchUp 무료 버전(웹 브라우저 버전)에서는 작동 안 함.** 데스크탑 SketchUp Pro 필요.
- 일부 복잡한 작업은 시간이 걸릴 수 있음 (타임아웃 120초).
- **포트 8080**이 다른 프로그램에서 사용 중이면 안 켜짐.

---

## 🩺 문제 해결

### "SketchUp에 연결할 수 없습니다"
1. SketchUp이 실행 중인지 확인
2. 메뉴 → 확장 → Hueflow MCP 서버 → 서버 상태 확인
3. 포트 8080 점유 여부: PowerShell에서 `netstat -an | findstr 8080`

### "uvx를 찾을 수 없습니다"
- `uv`가 설치 안 됨. PowerShell에서:
  ```
  winget install --id=astral-sh.uv -e
  ```
- 설치 후 **컴퓨터 재시작** (PATH 적용)

### 플러그인이 SketchUp에 안 보여요
- 확장 관리자에서 활성화 상태 확인
- SketchUp 완전 종료 후 재시작
- Ruby 콘솔(창 → Ruby 콘솔)에서 에러 메시지 확인

### 디버그 로그 위치
- **Windows**: `%TEMP%\sketchup_mcp_debug.log`
- **macOS**: `/tmp/sketchup_mcp_debug.log`

---

## 📚 강의 자료

이 패키지는 다음 강의에서 사용됩니다:

- **목포 건축사회** AI 실무 강좌 (6회차)
- **한솔 아카데미** AI 마스터클래스
- **Fastcampus** AI 인테리어 강의

강의 문의: [@hueflow_studio](https://www.instagram.com/hueflow_studio/)

---

## 🙏 크레딧

이 프로젝트는 다음 오픈소스 프로젝트를 기반으로 합니다:

- **[Tarkiin/SketchUp-MCP](https://github.com/Tarkiin/SketchUp-MCP)** — 원본 코드 (MIT License)
- **[mhyrr/sketchup-mcp](https://github.com/mhyrr/sketchup-mcp)** — 최초 SketchUp MCP 컨셉 (MIT License)

한국어화 / 재패키징 / 강의용 가이드 작성 © 2026 Hueflow Studio.

## 📜 라이선스

MIT License. 자세한 내용은 [LICENSE](LICENSE) 참조.
