"""Hueflow SketchUp MCP Server.

SketchUp을 Claude/Cursor/Gemini에 연결하는 MCP(Model Context Protocol) 서버.
SketchUp 2024/2025/2026 호환.

Based on Tarkiin/SketchUp-MCP (MIT License)
Korean localization & packaging by Hueflow Studio (@hueflow_studio)
"""

import asyncio

__version__ = "0.1.0"


def main():
    """CLI 엔트리포인트."""
    from .server import main as async_main
    asyncio.run(async_main())


__all__ = ["main"]
