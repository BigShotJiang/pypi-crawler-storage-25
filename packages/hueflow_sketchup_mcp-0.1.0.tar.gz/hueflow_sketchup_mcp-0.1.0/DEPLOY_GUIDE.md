# 📦 배포 가이드 (실장님 전용)

이 문서는 실장님이 노트북에서 따라할 PyPI + GitHub 업로드 가이드예요.
모든 명령어는 PowerShell에서 실행합니다.

---

## 🟦 STEP 0 — 사전 준비

### 0-1. PyPI 계정 만들기 (이미 만들었으면 스킵)

1. https://pypi.org/account/register/ 가입
2. 이메일 인증
3. **2단계 인증(2FA) 활성화 필수** — Google Authenticator 또는 Microsoft Authenticator 앱 사용
4. **API 토큰 발급**:
   - https://pypi.org/manage/account/token/
   - Token name: `hueflow-sketchup-mcp` (또는 아무거나)
   - Scope: 처음엔 "Entire account" 선택 (첫 업로드 후 패키지별로 좁힐 수 있음)
   - **생성된 토큰 (`pypi-...`로 시작) 어딘가에 잘 보관!** 다시 못 봄.

### 0-2. GitHub 계정 / Repo 준비

1. https://github.com/new 에서 새 repo 생성
2. Repo 이름: `hueflow-sketchup-mcp`
3. Public 선택
4. README 초기화는 **체크하지 말기** (우리가 이미 만든 게 있음)
5. **생성**

---

## 🟦 STEP 1 — 노트북에 작업 폴더 풀기

다운로드받은 ZIP 파일을 적당한 위치에 압축 해제. 예: `C:\Users\{사용자}\Documents\hueflow-sketchup-mcp\`

PowerShell 열고 그 폴더로 이동:

```powershell
cd C:\Users\{사용자}\Documents\hueflow-sketchup-mcp
```

---

## 🟦 STEP 2 — 빌드 도구 설치

```powershell
pip install --upgrade build twine
```

---

## 🟦 STEP 3 — 패키지 빌드

```powershell
python -m build
```

성공하면 `dist/` 폴더에 두 개 파일 생김:
- `hueflow_sketchup_mcp-0.1.0-py3-none-any.whl`
- `hueflow_sketchup_mcp-0.1.0.tar.gz`

---

## 🟦 STEP 4 — 빌드 검증

```powershell
twine check dist/*
```

`PASSED` 두 줄 나오면 OK.

---

## 🟦 STEP 5 — PyPI 업로드 ⚠️ 영구적!

```powershell
twine upload dist/*
```

- **Username**: `__token__` (밑줄 두 개 + token + 밑줄 두 개)
- **Password**: STEP 0-1에서 받은 토큰 (`pypi-...`로 시작하는 거)

성공하면 메시지 나옴:
```
View at:
https://pypi.org/project/hueflow-sketchup-mcp/0.1.0/
```

⚠️ **한 번 업로드된 버전은 같은 번호로 재업로드 불가능.** 수정사항 있으면 `pyproject.toml`의 `version = "0.1.0"`을 `0.1.1`로 올려서 다시 빌드해야 함.

---

## 🟦 STEP 6 — uvx로 동작 테스트

PyPI에 올라간 거 진짜 돌아가는지 확인:

```powershell
uvx hueflow-sketchup-mcp --help
```

(처음엔 다운로드 시간 좀 걸림. PyPI 인덱싱에 1~5분 정도 걸려서 바로 안 될 수도 있음.)

---

## 🟦 STEP 7 — GitHub에 코드 업로드

```powershell
# Git 초기화
git init
git branch -M main

# 파일 추가
git add .
git commit -m "Initial release: hueflow-sketchup-mcp v0.1.0"

# GitHub repo 연결 (URL은 본인 GitHub username으로 수정)
git remote add origin https://github.com/hueflow-studio/hueflow-sketchup-mcp.git

# 푸시
git push -u origin main
```

---

## 🟦 STEP 8 — GitHub Release 만들기 (.rbz 파일 배포용)

수강생들이 .rbz 파일을 다운로드할 수 있게 Release 페이지 만듭니다.

1. GitHub repo 페이지에서 우측 **Releases** 클릭
2. **Create a new release** 클릭
3. **Choose a tag** → `v0.1.0` 입력 → "Create new tag"
4. **Release title**: `v0.1.0 - 첫 배포`
5. **Description**:
   ```
   ## 🎉 첫 공개 배포

   ### 설치
   1. 아래 `hueflow_sketchup_mcp.rbz` 다운로드
   2. SketchUp → 창 → 확장 관리자 → 확장 설치 → .rbz 파일 선택
   3. claude_desktop_config.json에 다음 추가:

   ```json
   {
     "mcpServers": {
       "hueflow-sketchup": {
         "command": "uvx",
         "args": ["hueflow-sketchup-mcp"]
       }
     }
   }
   ```

   상세 설치 가이드: [README.md](README.md)
   ```
6. **Attach binaries**: `sketchup_plugin/hueflow_sketchup_mcp.rbz` 파일 드래그해서 업로드
7. **Publish release** 클릭

---

## ✅ 완료!

이제 수강생들에게 이렇게 안내 가능:

> 1. https://github.com/hueflow-studio/hueflow-sketchup-mcp/releases/latest 에서 .rbz 다운로드
> 2. SketchUp 확장 관리자에 설치
> 3. claude_desktop_config.json에 한 줄 추가

끝.

---

## 🔄 나중에 업데이트 할 때

코드 수정 후:

```powershell
# 1. pyproject.toml의 version을 0.1.0 → 0.1.1로 변경

# 2. 기존 dist/ 폴더 정리
Remove-Item -Recurse dist/

# 3. 다시 빌드
python -m build

# 4. PyPI 업로드
twine upload dist/*

# 5. GitHub 푸시
git add .
git commit -m "v0.1.1: <수정 내용>"
git push

# 6. 새 Release 생성 (위 STEP 8 반복, 태그를 v0.1.1로)
```
