from __future__ import annotations

from .client import OpenAIManinClient
from .prompts import PLANNER_SYSTEM_PROMPT, build_planner_input
from .schemas import RenderRequest, VideoPlan


class VideoPlanner:
    def __init__(self, client: OpenAIManinClient) -> None:
        self.client = client

    def create_plan(self, request: RenderRequest) -> VideoPlan:
        return self.client.plan_video(
            request=request,
            planner_input=build_planner_input(request),
            instructions=PLANNER_SYSTEM_PROMPT,
        )


