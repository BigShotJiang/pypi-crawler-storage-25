from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

from .schemas import QualityProfile


StageName = Literal["planner", "codegen", "repair"]


def _parse_bool(value: str | bool | None, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return value.strip().lower() in {"1", "true", "yes", "on"}


def load_dotenv(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip("'").strip('"')
    return values


class AppConfig(BaseModel):
    api_key: str | None = None
    planner_model_best: str = "gpt-5.4"
    planner_model_balanced: str = "gpt-5.4"
    planner_model_fast: str = "gpt-5.4-mini"
    codegen_model_best: str = "gpt-5.4"
    codegen_model_balanced: str = "gpt-5.4-mini"
    codegen_model_fast: str = "gpt-5.4-mini"
    repair_model_best: str = "gpt-5.4"
    repair_model_balanced: str = "gpt-5.4-mini"
    repair_model_fast: str = "gpt-5.4-mini"
    planner_fallback_best: str = "gpt-5.2"
    planner_fallback_balanced: str = "gpt-5.2"
    planner_fallback_fast: str = "gpt-5-mini"
    codegen_fallback_best: str = "gpt-5.2"
    codegen_fallback_balanced: str = "gpt-5-mini"
    codegen_fallback_fast: str = "gpt-5-mini"
    repair_fallback_best: str = "gpt-5.2"
    repair_fallback_balanced: str = "gpt-5-mini"
    repair_fallback_fast: str = "gpt-5-mini"
    allow_model_fallback: bool = False
    quality_profile: QualityProfile = QualityProfile.BALANCED
    output_dir: Path = Path("artifacts/output")
    open_on_complete: bool = False
    keep_artifacts: bool = True
    max_repair_attempts: int = 2
    allowed_imports: list[str] = Field(
        default_factory=lambda: ["manim", "math", "random", "numpy", "itertools", "statistics", "collections"]
    )
    allow_unsafe_python: bool = False
    python_executable: str = sys.executable

    @field_validator("output_dir", mode="before")
    @classmethod
    def _coerce_output_dir(cls, value: Any) -> Path:
        return Path(value).expanduser()

    def model_for(self, stage: StageName, profile: QualityProfile, fallback: bool = False) -> str:
        if stage == "planner":
            if fallback:
                if profile == QualityProfile.BEST:
                    return self.planner_fallback_best
                if profile == QualityProfile.FAST:
                    return self.planner_fallback_fast
                return self.planner_fallback_balanced
            if profile == QualityProfile.BEST:
                return self.planner_model_best
            if profile == QualityProfile.FAST:
                return self.planner_model_fast
            return self.planner_model_balanced

        if stage == "codegen":
            if fallback:
                if profile == QualityProfile.BEST:
                    return self.codegen_fallback_best
                if profile == QualityProfile.FAST:
                    return self.codegen_fallback_fast
                return self.codegen_fallback_balanced
            if profile == QualityProfile.BEST:
                return self.codegen_model_best
            if profile == QualityProfile.FAST:
                return self.codegen_model_fast
            return self.codegen_model_balanced

        if fallback:
            if profile == QualityProfile.BEST:
                return self.repair_fallback_best
            if profile == QualityProfile.FAST:
                return self.repair_fallback_fast
            return self.repair_fallback_balanced
        if profile == QualityProfile.BEST:
            return self.repair_model_best
        if profile == QualityProfile.FAST:
            return self.repair_model_fast
        return self.repair_model_balanced


def load_config(env_path: str | Path = ".env") -> AppConfig:
    env_file = Path(env_path)
    file_values = load_dotenv(env_file)
    source = {**file_values, **os.environ}
    allowed_imports_raw = source.get("MANIMGENAI_ALLOWED_IMPORTS")
    allowed_imports = (
        [chunk.strip() for chunk in allowed_imports_raw.split(",") if chunk.strip()]
        if allowed_imports_raw
        else None
    )
    return AppConfig(
        api_key=source.get("OPENAI_API_KEY"),
        planner_model_best=source.get("MANIMGENAI_MODEL_PLANNER_BEST", "gpt-5.4"),
        planner_model_balanced=source.get("MANIMGENAI_MODEL_PLANNER_BALANCED", "gpt-5.4"),
        planner_model_fast=source.get("MANIMGENAI_MODEL_PLANNER_FAST", "gpt-5.4-mini"),
        codegen_model_best=source.get("MANIMGENAI_MODEL_CODEGEN_BEST", "gpt-5.4"),
        codegen_model_balanced=source.get("MANIMGENAI_MODEL_CODEGEN_BALANCED", "gpt-5.4-mini"),
        codegen_model_fast=source.get("MANIMGENAI_MODEL_CODEGEN_FAST", "gpt-5.4-mini"),
        repair_model_best=source.get("MANIMGENAI_MODEL_REPAIR_BEST", "gpt-5.4"),
        repair_model_balanced=source.get("MANIMGENAI_MODEL_REPAIR_BALANCED", "gpt-5.4-mini"),
        repair_model_fast=source.get("MANIMGENAI_MODEL_REPAIR_FAST", "gpt-5.4-mini"),
        planner_fallback_best=source.get("MANIMGENAI_MODEL_FALLBACK_PLANNER_BEST", "gpt-5.2"),
        planner_fallback_balanced=source.get("MANIMGENAI_MODEL_FALLBACK_PLANNER_BALANCED", "gpt-5.2"),
        planner_fallback_fast=source.get("MANIMGENAI_MODEL_FALLBACK_PLANNER_FAST", "gpt-5-mini"),
        codegen_fallback_best=source.get("MANIMGENAI_MODEL_FALLBACK_CODEGEN_BEST", "gpt-5.2"),
        codegen_fallback_balanced=source.get("MANIMGENAI_MODEL_FALLBACK_CODEGEN_BALANCED", "gpt-5-mini"),
        codegen_fallback_fast=source.get("MANIMGENAI_MODEL_FALLBACK_CODEGEN_FAST", "gpt-5-mini"),
        repair_fallback_best=source.get("MANIMGENAI_MODEL_FALLBACK_REPAIR_BEST", "gpt-5.2"),
        repair_fallback_balanced=source.get("MANIMGENAI_MODEL_FALLBACK_REPAIR_BALANCED", "gpt-5-mini"),
        repair_fallback_fast=source.get("MANIMGENAI_MODEL_FALLBACK_REPAIR_FAST", "gpt-5-mini"),
        allow_model_fallback=_parse_bool(source.get("MANIMGENAI_ALLOW_MODEL_FALLBACK"), False),
        quality_profile=QualityProfile(source.get("MANIMGENAI_QUALITY_PROFILE", QualityProfile.BALANCED.value)),
        output_dir=Path(source.get("MANIMGENAI_OUTPUT_DIR", "artifacts/output")),
        open_on_complete=_parse_bool(source.get("MANIMGENAI_OPEN_ON_COMPLETE"), False),
        keep_artifacts=_parse_bool(source.get("MANIMGENAI_KEEP_ARTIFACTS"), True),
        max_repair_attempts=int(source.get("MANIMGENAI_MAX_REPAIR_ATTEMPTS", "2")),
        allowed_imports=allowed_imports
        or ["manim", "math", "random", "numpy", "itertools", "statistics", "collections"],
        allow_unsafe_python=_parse_bool(source.get("MANIMGENAI_ALLOW_UNSAFE_PYTHON"), False),
    )

