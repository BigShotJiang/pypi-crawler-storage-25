from __future__ import annotations

import importlib.metadata

from .client import OpenAIManinClient
from .prompts import CODER_SYSTEM_PROMPT, REPAIR_SYSTEM_PROMPT, build_coder_input, build_repair_input
from .schemas import RenderRequest, VideoPlan
from .validator import strip_code_fences


class CodeGenerator:
    def __init__(self, client: OpenAIManinClient) -> None:
        self.client = client
        self.manim_version = importlib.metadata.version("manim")

    def generate(self, plan: VideoPlan, request: RenderRequest) -> str:
        return strip_code_fences(
            self.client.generate_code(
                request=request,
                coder_input=build_coder_input(plan, request, self.manim_version),
                instructions=CODER_SYSTEM_PROMPT,
            )
        )

    def repair(self, plan: VideoPlan, request: RenderRequest, previous_code: str, failure_message: str) -> str:
        return strip_code_fences(
            self.client.repair_code(
                request=request,
                repair_input=build_repair_input(plan, request, previous_code, failure_message, self.manim_version),
                instructions=REPAIR_SYSTEM_PROMPT,
            )
        )


