from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any


class ArtifactManager:
    def __init__(self, base_dir: Path, output_name: str) -> None:
        slug = re.sub(r"[^a-zA-Z0-9_-]+", "-", output_name).strip("-") or "render"
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        self.root = base_dir / f"{timestamp}-{slug}"
        self.root.mkdir(parents=True, exist_ok=True)

    def path(self, *parts: str) -> Path:
        target = self.root.joinpath(*parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        return target

    def write_text(self, relative_path: str, content: str) -> Path:
        target = self.path(relative_path)
        target.write_text(content, encoding="utf-8")
        return target

    def write_json(self, relative_path: str, content: Any) -> Path:
        target = self.path(relative_path)
        target.write_text(json.dumps(content, indent=2, default=str), encoding="utf-8")
        return target


