from __future__ import annotations

import importlib.metadata
import shutil
import subprocess

from .config import AppConfig
from .schemas import DoctorCheck, DoctorReport


def run_doctor(config: AppConfig) -> DoctorReport:
    checks: list[DoctorCheck] = []

    try:
        openai_version = importlib.metadata.version("openai")
        checks.append(DoctorCheck(name="openai", ok=True, details=f"openai {openai_version}"))
    except importlib.metadata.PackageNotFoundError:
        checks.append(DoctorCheck(name="openai", ok=False, details="openai package is not installed"))

    try:
        manim_version = importlib.metadata.version("manim")
        checks.append(DoctorCheck(name="manim", ok=True, details=f"manim {manim_version}"))
    except importlib.metadata.PackageNotFoundError:
        checks.append(DoctorCheck(name="manim", ok=False, details="manim package is not installed"))

    ffmpeg_path = shutil.which("ffmpeg")
    checks.append(
        DoctorCheck(
            name="ffmpeg",
            ok=ffmpeg_path is not None,
            details=ffmpeg_path or "ffmpeg executable not found in PATH",
        )
    )

    process = subprocess.run(
        [config.python_executable, "-m", "manim", "--version"],
        capture_output=True,
        text=True,
        check=False,
    )
    checks.append(
        DoctorCheck(
            name="manim_cli",
            ok=process.returncode == 0,
            details=(process.stdout or process.stderr or "no output").strip(),
        )
    )

    checks.append(
        DoctorCheck(
            name="openai_api_key",
            ok=bool(config.api_key),
            details="configured" if config.api_key else "OPENAI_API_KEY is missing",
        )
    )

    return DoctorReport(python_executable=config.python_executable, checks=checks)


