from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator


class QualityProfile(str, Enum):
    BEST = "best"
    BALANCED = "balanced"
    FAST = "fast"


class AssetKind(str, Enum):
    IMAGE = "image"
    SVG = "svg"
    AUDIO = "audio"
    FONT = "font"
    DATA = "data"
    OTHER = "other"


class AssetSpec(BaseModel):
    path: Path
    kind: AssetKind = AssetKind.OTHER
    label: str | None = None
    description: str | None = None

    @field_validator("path", mode="before")
    @classmethod
    def _coerce_path(cls, value: Any) -> Path:
        return Path(value).expanduser()

    @model_validator(mode="after")
    def _auto_kind(self) -> "AssetSpec":
        if self.kind != AssetKind.OTHER:
            return self
        ext = self.path.suffix.lower()
        if ext in {".png", ".jpg", ".jpeg", ".webp"}:
            self.kind = AssetKind.IMAGE
        elif ext == ".svg":
            self.kind = AssetKind.SVG
        elif ext in {".mp3", ".wav", ".ogg"}:
            self.kind = AssetKind.AUDIO
        elif ext in {".ttf", ".otf"}:
            self.kind = AssetKind.FONT
        elif ext in {".json", ".csv", ".txt"}:
            self.kind = AssetKind.DATA
        return self


class PromptHint(BaseModel):
    audience: str | None = None
    visual_style: str | None = None
    duration_seconds: float | None = None
    aspect_ratio: str | None = None
    camera_notes: str | None = None
    must_include: list[str] = Field(default_factory=list)
    avoid: list[str] = Field(default_factory=list)


class PlannedScene(BaseModel):
    name: str
    purpose: str
    visual_description: str
    animation_steps: list[str] = Field(default_factory=list)
    estimated_duration_seconds: float = 4.0
    camera_notes: str = ""
    text_overlays: list[str] = Field(default_factory=list)
    formulas: list[str] = Field(default_factory=list)
    asset_labels: list[str] = Field(default_factory=list)


class VideoPlan(BaseModel):
    title: str
    objective: str
    target_audience: str = "general"
    scene_class: Literal["Scene", "ThreeDScene", "MovingCameraScene"] = "Scene"
    style_notes: str
    desired_duration_seconds: float = 10.0
    aspect_ratio: str = "16:9"
    global_visual_constraints: list[str] = Field(default_factory=list)
    scenes: list[PlannedScene] = Field(default_factory=list)
    assets_to_use: list[str] = Field(default_factory=list)
    risk_notes: list[str] = Field(default_factory=list)


class RenderRequest(BaseModel):
    prompt: str
    assets: list[AssetSpec] = Field(default_factory=list)
    output_dir: Path | None = None
    output_name: str = "manimgenai_video"
    quality_profile: QualityProfile = QualityProfile.BALANCED
    open_on_complete: bool | None = None
    keep_artifacts: bool | None = None
    max_repair_attempts: int | None = None
    model_primary: str | None = None
    model_repair: str | None = None
    manim_flags: list[str] = Field(default_factory=list)
    prompt_hints: PromptHint | None = None
    allow_unsafe_python: bool | None = None
    allow_model_fallback: bool | None = None

    @field_validator("output_dir", mode="before")
    @classmethod
    def _coerce_output_dir(cls, value: Any) -> Path | None:
        if value in (None, ""):
            return None
        return Path(value).expanduser()


class ValidationIssue(BaseModel):
    message: str
    severity: Literal["error", "warning"] = "error"


class ValidationResult(BaseModel):
    scene_name: str | None = None
    scene_names: list[str] = Field(default_factory=list)
    issues: list[ValidationIssue] = Field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return not any(issue.severity == "error" for issue in self.issues)


class RenderResult(BaseModel):
    status: Literal["success", "failed"]
    video_path: Path | None = None
    scene_name: str | None = None
    attempt_count: int = 0
    artifacts_dir: Path | None = None
    generated_code_path: Path | None = None
    logs_path: Path | None = None
    errors: list[str] = Field(default_factory=list)
    timings: dict[str, float] = Field(default_factory=dict)
    plan: VideoPlan | None = None


class DoctorCheck(BaseModel):
    name: str
    ok: bool
    details: str


class DoctorReport(BaseModel):
    python_executable: str
    checks: list[DoctorCheck] = Field(default_factory=list)

    @property
    def ok(self) -> bool:
        return all(check.ok for check in self.checks)


