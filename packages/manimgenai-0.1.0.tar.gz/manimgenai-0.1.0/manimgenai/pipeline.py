from __future__ import annotations

import shutil
import time
from pathlib import Path

from .artifacts import ArtifactManager
from .client import OpenAIManinClient
from .codegen import CodeGenerator
from .config import AppConfig, load_config
from .planner import VideoPlanner
from .renderer import RenderExecutionError, Renderer
from .schemas import RenderRequest, RenderResult
from .validator import validate_generated_code


def render_video(request: RenderRequest, config: AppConfig | None = None) -> RenderResult:
    config = config or load_config()
    output_dir = request.output_dir or config.output_dir
    artifacts_base = output_dir / "_artifacts"
    artifact_manager = ArtifactManager(artifacts_base, request.output_name)
    timings: dict[str, float] = {}
    open_on_complete = config.open_on_complete if request.open_on_complete is None else request.open_on_complete
    keep_artifacts = config.keep_artifacts if request.keep_artifacts is None else request.keep_artifacts
    max_repair_attempts = config.max_repair_attempts if request.max_repair_attempts is None else request.max_repair_attempts
    allow_unsafe_python = config.allow_unsafe_python if request.allow_unsafe_python is None else request.allow_unsafe_python

    for asset in request.assets:
        if not asset.path.exists():
            return RenderResult(
                status="failed",
                artifacts_dir=artifact_manager.root,
                errors=[f"Asset not found: {asset.path}"],
            )

    client = OpenAIManinClient(config)
    planner = VideoPlanner(client)
    generator = CodeGenerator(client)
    renderer = Renderer(config.python_executable)

    planning_started = time.perf_counter()
    plan = planner.create_plan(request)
    timings["planning_seconds"] = time.perf_counter() - planning_started
    artifact_manager.write_json("plan.json", plan.model_dump(mode="json"))
    artifact_manager.write_text("prompt.txt", request.prompt)

    generation_started = time.perf_counter()
    code = generator.generate(plan, request)
    timings["initial_codegen_seconds"] = time.perf_counter() - generation_started

    attempt_count = 0
    errors: list[str] = []
    last_log_path: Path | None = None
    generated_code_path: Path | None = None

    for attempt in range(max_repair_attempts + 1):
        attempt_count = attempt + 1
        generated_code_path = artifact_manager.write_text(f"attempts/attempt-{attempt_count}.py", code)
        validation = validate_generated_code(code, config.allowed_imports, allow_unsafe_python=allow_unsafe_python)
        artifact_manager.write_json(f"attempts/attempt-{attempt_count}-validation.json", validation.model_dump(mode="json"))

        if validation.is_valid and validation.scene_name:
            try:
                render_started = time.perf_counter()
                rendered_video, log_path = renderer.render(
                    code_file=generated_code_path,
                    scene_name=validation.scene_name,
                    output_name=request.output_name,
                    quality_profile=request.quality_profile,
                    manim_flags=request.manim_flags,
                    artifacts_dir=artifact_manager.root,
                )
                timings[f"render_attempt_{attempt_count}_seconds"] = time.perf_counter() - render_started
                final_video = renderer.publish_video(rendered_video, output_dir, request.output_name)
                last_log_path = log_path
                if open_on_complete:
                    renderer.open_file(final_video)
                result = RenderResult(
                    status="success",
                    video_path=final_video,
                    scene_name=validation.scene_name,
                    attempt_count=attempt_count,
                    artifacts_dir=artifact_manager.root,
                    generated_code_path=generated_code_path,
                    logs_path=log_path,
                    errors=errors,
                    timings=timings,
                    plan=plan,
                )
                if not keep_artifacts:
                    shutil.rmtree(artifact_manager.root, ignore_errors=True)
                    result.artifacts_dir = None
                    result.generated_code_path = None
                    result.logs_path = None
                return result
            except RenderExecutionError as exc:
                failure_message = str(exc)
                errors.append(f"Render attempt {attempt_count} failed: {failure_message}")
                artifact_manager.write_text(f"attempts/attempt-{attempt_count}-render-error.txt", failure_message)
        else:
            failure_message = "\n".join(issue.message for issue in validation.issues)
            errors.append(f"Validation attempt {attempt_count} failed: {failure_message}")

        if attempt >= max_repair_attempts:
            break

        repair_started = time.perf_counter()
        code = generator.repair(plan, request, code, failure_message)
        timings[f"repair_attempt_{attempt_count}_seconds"] = time.perf_counter() - repair_started

    return RenderResult(
        status="failed",
        scene_name=None,
        attempt_count=attempt_count,
        artifacts_dir=artifact_manager.root,
        generated_code_path=generated_code_path,
        logs_path=last_log_path,
        errors=errors,
        timings=timings,
        plan=plan,
    )


