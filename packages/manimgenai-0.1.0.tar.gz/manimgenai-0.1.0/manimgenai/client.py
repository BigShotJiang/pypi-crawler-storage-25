from __future__ import annotations

from typing import Any

from openai import APIError, BadRequestError, OpenAI
from pydantic import BaseModel

from .config import AppConfig
from .schemas import QualityProfile, RenderRequest, VideoPlan


class OpenAIManinClient:
    def __init__(self, config: AppConfig) -> None:
        if not config.api_key:
            raise ValueError("OPENAI_API_KEY is required to generate videos.")
        self.config = config
        self.client = OpenAI(api_key=config.api_key)

    def _reasoning_for_profile(self, profile: QualityProfile) -> dict[str, str]:
        if profile == QualityProfile.BEST:
            return {"effort": "high"}
        if profile == QualityProfile.FAST:
            return {"effort": "low"}
        return {"effort": "medium"}

    def _allow_fallback(self, request: RenderRequest) -> bool:
        return self.config.allow_model_fallback if request.allow_model_fallback is None else request.allow_model_fallback

    def _extract_text(self, response: Any) -> str:
        if getattr(response, "output_text", None):
            return str(response.output_text).strip()
        parts: list[str] = []
        for item in getattr(response, "output", []):
            if getattr(item, "type", None) != "message":
                continue
            for content in getattr(item, "content", []):
                if getattr(content, "type", None) == "output_text":
                    parts.append(getattr(content, "text", ""))
        return "\n".join(part for part in parts if part).strip()

    def _extract_parsed(self, response: Any, expected_type: type[BaseModel]) -> BaseModel:
        for item in getattr(response, "output", []):
            if getattr(item, "type", None) != "message":
                continue
            for content in getattr(item, "content", []):
                parsed = getattr(content, "parsed", None)
                if parsed is not None:
                    return parsed
        raise ValueError(f"OpenAI did not return a parsed {expected_type.__name__} payload.")

    def _pick_model(self, stage: str, profile: QualityProfile, override: str | None, use_fallback: bool) -> str:
        if use_fallback:
            return self.config.model_for(stage, profile, fallback=True)
        if override:
            return override
        return self.config.model_for(stage, profile, fallback=False)

    def _call_with_fallback(self, call: Any, allow_fallback: bool) -> Any:
        try:
            return call(False)
        except (BadRequestError, APIError):
            if not allow_fallback:
                raise
            return call(True)

    def plan_video(self, request: RenderRequest, planner_input: str, instructions: str) -> VideoPlan:
        profile = request.quality_profile

        def _call(use_fallback: bool) -> Any:
            model = self._pick_model("planner", profile, None, use_fallback)
            return self.client.responses.parse(
                model=model,
                instructions=instructions,
                input=planner_input,
                text_format=VideoPlan,
                reasoning=self._reasoning_for_profile(profile),
                text={"verbosity": "medium"},
            )

        response = self._call_with_fallback(_call, self._allow_fallback(request))
        return self._extract_parsed(response, VideoPlan)  # type: ignore[return-value]

    def generate_code(self, request: RenderRequest, coder_input: str, instructions: str) -> str:
        profile = request.quality_profile

        def _call(use_fallback: bool) -> Any:
            model = self._pick_model("codegen", profile, request.model_primary, use_fallback)
            return self.client.responses.create(
                model=model,
                instructions=instructions,
                input=coder_input,
                reasoning=self._reasoning_for_profile(profile),
                text={"verbosity": "medium"},
            )

        response = self._call_with_fallback(_call, self._allow_fallback(request))
        return self._extract_text(response)

    def repair_code(self, request: RenderRequest, repair_input: str, instructions: str) -> str:
        profile = request.quality_profile

        def _call(use_fallback: bool) -> Any:
            model = self._pick_model("repair", profile, request.model_repair, use_fallback)
            return self.client.responses.create(
                model=model,
                instructions=instructions,
                input=repair_input,
                reasoning=self._reasoning_for_profile(profile),
                text={"verbosity": "medium"},
            )

        response = self._call_with_fallback(_call, self._allow_fallback(request))
        return self._extract_text(response)

