from __future__ import annotations

import json

from .schemas import AssetSpec, RenderRequest, VideoPlan


PLANNER_SYSTEM_PROMPT = """
You are a senior Manim creative director and technical planner.
Your job is to turn a user video request into a concrete production plan that is easy to implement in Manim.

Rules:
- Produce a plan that is visually strong, technically realistic, and consistent with Manim Community.
- Prefer current, stable Manim APIs and avoid deprecated patterns.
- Select exactly one scene base class from: Scene, ThreeDScene, MovingCameraScene.
- Keep the plan achievable in one generated Python file.
- If the user leaves details unspecified, choose sensible defaults with polished motion and readable pacing.
- Only reference local assets that were explicitly provided.
- Avoid describing any technique that requires arbitrary Python execution, network calls, shelling out, or filesystem writes beyond Manim rendering.
- Return only valid JSON that matches the target schema.
""".strip()


CODER_SYSTEM_PROMPT = """
You are an expert Manim engineer writing production-ready code.
Given a validated plan, generate a single Python module that renders one final scene.

Hard requirements:
- Return only Python code. No markdown fences, no prose.
- Include all necessary imports.
- Generate one main scene class that is renderable by Manim.
- Use current Manim Community APIs and keep compatibility with the installed version provided in context.
- Make motion readable and polished, not overcrowded.
- Keep text legible and avoid off-screen placements.
- Use local assets only when their paths are explicitly supplied.
- Do not import or call dangerous modules such as subprocess, socket, requests, httpx, os.system, shutil, pathlib writes, eval, exec, compile, or open.
- No network access, no shell commands, no file writes inside generated code.
- Keep the code self-contained and deterministic.
""".strip()


REPAIR_SYSTEM_PROMPT = """
You are repairing a Manim Python module after validation or render failure.

Rules:
- Return only Python code.
- Preserve the original intent and visual outcome whenever possible.
- Fix the concrete failure first, then improve robustness only if needed.
- Keep one renderable main scene class.
- Do not introduce dangerous imports or arbitrary Python execution.
- Stay compatible with the reported Manim version.
""".strip()


USER_PROMPT_TEMPLATE_SHORT = """
Describe the video using this compact template:

Goal:
Audience:
Visual style:
Approx duration:
Camera or motion:
Important elements to show:
Things to avoid:
Assets to use (optional):
""".strip()


USER_PROMPT_TEMPLATE_PRO = """
Use this richer template when you want the highest quality:

Goal:
Audience:
Core concept or story:
Visual style and mood:
Approx duration in seconds:
Aspect ratio or output format:
Camera movement notes:
Objects, graphs, formulas, or text that must appear:
Scene progression beat by beat:
Assets to use (optional):
Non-negotiable constraints:
Things to avoid:
""".strip()


EXAMPLE_PROMPTS = [
    "Create a 12-second educational animation explaining why the derivative is the slope of the tangent line. Clean blue-and-gold style, smooth camera, large readable formulas, avoid clutter.",
    "Build a polished 3D animation of a saddle surface z = x^2 - y^2 with axes, rotating camera, highlighted saddle point, and a short text callout. Keep it elegant and not too dense.",
    "Use the attached SVG logo as the opening mark, then morph it into a network graph and finish with the title 'ManimGenAI'. Corporate, high contrast, 8 seconds, 16:9.",
]


def format_assets_for_prompt(assets: list[AssetSpec]) -> str:
    if not assets:
        return "No local assets were provided."
    lines = []
    for asset in assets:
        label = asset.label or asset.path.stem
        description = asset.description or ""
        lines.append(f"- {label}: kind={asset.kind.value}, path={asset.path}, description={description}")
    return "\n".join(lines)


def build_planner_input(request: RenderRequest) -> str:
    hints = request.prompt_hints.model_dump_json(indent=2) if request.prompt_hints else "{}"
    return "\n".join(
        [
            "USER VIDEO REQUEST:",
            request.prompt.strip(),
            "",
            "PROMPT HINTS (JSON):",
            hints,
            "",
            "LOCAL ASSETS:",
            format_assets_for_prompt(request.assets),
        ]
    )


def build_coder_input(plan: VideoPlan, request: RenderRequest, manim_version: str) -> str:
    return "\n".join(
        [
            f"Installed Manim version: {manim_version}",
            "",
            "RENDER PLAN:",
            plan.model_dump_json(indent=2),
            "",
            "ORIGINAL USER REQUEST:",
            request.prompt.strip(),
            "",
            "LOCAL ASSETS:",
            format_assets_for_prompt(request.assets),
        ]
    )


def build_repair_input(
    plan: VideoPlan,
    request: RenderRequest,
    previous_code: str,
    failure_message: str,
    manim_version: str,
) -> str:
    payload = {
        "manim_version": manim_version,
        "plan": plan.model_dump(),
        "prompt": request.prompt,
        "assets": [asset.model_dump(mode="json") for asset in request.assets],
        "failure_message": failure_message,
        "previous_code": previous_code,
    }
    return json.dumps(payload, indent=2, default=str)


