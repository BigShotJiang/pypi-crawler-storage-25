from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .config import AppConfig, load_config
from .doctor import run_doctor
from .pipeline import render_video
from .prompts import (
    CODER_SYSTEM_PROMPT,
    EXAMPLE_PROMPTS,
    PLANNER_SYSTEM_PROMPT,
    REPAIR_SYSTEM_PROMPT,
    USER_PROMPT_TEMPLATE_PRO,
    USER_PROMPT_TEMPLATE_SHORT,
)
from .schemas import AssetSpec, PromptHint, QualityProfile, RenderRequest


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="manimgenai", description="Generate polished Manim videos from prompts.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    render_parser = subparsers.add_parser("render", help="Generate and render a video from a prompt.")
    render_parser.add_argument("prompt", nargs="?", help="Prompt describing the video to generate.")
    render_parser.add_argument("--prompt-file", type=Path, help="Read the prompt from a UTF-8 text file.")
    render_parser.add_argument("--asset", action="append", default=[], help="Path to a local asset to expose to Manim.")
    render_parser.add_argument("--output-dir", type=Path)
    render_parser.add_argument("--output-name", default="manimgenai_video")
    render_parser.add_argument("--quality", choices=[profile.value for profile in QualityProfile], default=None)
    render_parser.add_argument("--open", dest="open_on_complete", action="store_true")
    render_parser.add_argument("--keep-artifacts", action="store_true")
    render_parser.add_argument("--max-repair-attempts", type=int)
    render_parser.add_argument("--model-primary")
    render_parser.add_argument("--model-repair")
    render_parser.add_argument("--manim-flag", action="append", default=[])
    render_parser.add_argument("--allow-unsafe-python", action="store_true")
    render_parser.add_argument("--allow-model-fallback", action="store_true")
    render_parser.add_argument("--json", action="store_true", help="Emit the render result as JSON.")
    render_parser.add_argument("--audience")
    render_parser.add_argument("--style")
    render_parser.add_argument("--duration", type=float)
    render_parser.add_argument("--aspect-ratio")
    render_parser.add_argument("--camera")
    render_parser.add_argument("--must-include", action="append", default=[])
    render_parser.add_argument("--avoid", action="append", default=[])

    doctor_parser = subparsers.add_parser("doctor", help="Check whether the environment is ready to render.")
    doctor_parser.add_argument("--json", action="store_true")

    prompt_parser = subparsers.add_parser("prompt-template", help="Show prompt templates.")
    prompt_parser.add_argument("--style", choices=["short", "pro"], default="pro")
    prompt_parser.add_argument("--system", choices=["planner", "coder", "repair", "all"])

    examples_parser = subparsers.add_parser("examples", help="Show example prompts.")
    examples_parser.add_argument("--json", action="store_true")

    build_parser = subparsers.add_parser("build-exe", help="Build an optional Windows one-folder executable via PyInstaller.")
    build_parser.add_argument("--name", default="manimgenai")
    build_parser.add_argument("--distpath", type=Path, default=Path("dist"))
    build_parser.add_argument("--workpath", type=Path, default=Path("build"))

    return parser


def _load_prompt(args: argparse.Namespace) -> str:
    if args.prompt_file:
        return args.prompt_file.read_text(encoding="utf-8").strip()
    if args.prompt:
        return args.prompt.strip()
    raise SystemExit("A prompt or --prompt-file is required.")


def _build_request(args: argparse.Namespace, config: AppConfig) -> RenderRequest:
    prompt_hints = PromptHint(
        audience=args.audience,
        visual_style=args.style,
        duration_seconds=args.duration,
        aspect_ratio=args.aspect_ratio,
        camera_notes=args.camera,
        must_include=args.must_include,
        avoid=args.avoid,
    )
    assets = [AssetSpec(path=Path(asset)) for asset in args.asset]
    quality = QualityProfile(args.quality) if args.quality else config.quality_profile
    return RenderRequest(
        prompt=_load_prompt(args),
        assets=assets,
        output_dir=args.output_dir,
        output_name=args.output_name,
        quality_profile=quality,
        open_on_complete=args.open_on_complete or None,
        keep_artifacts=args.keep_artifacts or None,
        max_repair_attempts=args.max_repair_attempts,
        model_primary=args.model_primary,
        model_repair=args.model_repair,
        manim_flags=args.manim_flag,
        prompt_hints=prompt_hints,
        allow_unsafe_python=args.allow_unsafe_python or None,
        allow_model_fallback=args.allow_model_fallback or None,
    )


def _print_json(data: Any) -> None:
    print(json.dumps(data, indent=2, default=str))


def _command_render(args: argparse.Namespace, config: AppConfig) -> int:
    request = _build_request(args, config)
    result = render_video(request, config=config)
    if args.json:
        _print_json(result.model_dump(mode="json"))
    else:
        if result.status == "success":
            print(f"Video generated: {result.video_path}")
            print(f"Scene: {result.scene_name}")
            print(f"Artifacts: {result.artifacts_dir}")
        else:
            print("Video generation failed.")
            for error in result.errors:
                print(f"- {error}")
            if result.artifacts_dir:
                print(f"Artifacts: {result.artifacts_dir}")
    return 0 if result.status == "success" else 1


def _command_doctor(args: argparse.Namespace, config: AppConfig) -> int:
    report = run_doctor(config)
    if args.json:
        _print_json(report.model_dump(mode="json"))
    else:
        print(f"Python: {report.python_executable}")
        for check in report.checks:
            status = "OK" if check.ok else "FAIL"
            print(f"[{status}] {check.name}: {check.details}")
    return 0 if report.ok else 1


def _command_prompt_template(args: argparse.Namespace) -> int:
    if args.system:
        payload = {
            "planner": PLANNER_SYSTEM_PROMPT,
            "coder": CODER_SYSTEM_PROMPT,
            "repair": REPAIR_SYSTEM_PROMPT,
        }
        if args.system == "all":
            _print_json(payload)
        else:
            print(payload[args.system])
        return 0
    print(USER_PROMPT_TEMPLATE_SHORT if args.style == "short" else USER_PROMPT_TEMPLATE_PRO)
    return 0


def _command_examples(args: argparse.Namespace) -> int:
    if args.json:
        _print_json(EXAMPLE_PROMPTS)
    else:
        for example in EXAMPLE_PROMPTS:
            print(f"- {example}")
    return 0


def _command_build_exe(args: argparse.Namespace) -> int:
    import importlib.util
    import subprocess

    if importlib.util.find_spec("PyInstaller") is None:
        print("PyInstaller is not installed. Install it with: pip install .[packaging]")
        return 1

    command = [
        sys.executable,
        "-m",
        "PyInstaller",
        "--noconfirm",
        "--clean",
        "--onedir",
        "--name",
        args.name,
        "--distpath",
        str(args.distpath),
        "--workpath",
        str(args.workpath),
        "main.py",
    ]
    process = subprocess.run(command, check=False)
    return process.returncode


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    config = load_config()
    if args.command == "render":
        return _command_render(args, config)
    if args.command == "doctor":
        return _command_doctor(args, config)
    if args.command == "prompt-template":
        return _command_prompt_template(args)
    if args.command == "examples":
        return _command_examples(args)
    if args.command == "build-exe":
        return _command_build_exe(args)
    parser.error(f"Unknown command: {args.command}")
    return 2


