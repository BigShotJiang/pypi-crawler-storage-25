from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

from .schemas import QualityProfile


QUALITY_TO_MANIM = {
    QualityProfile.BEST: "h",
    QualityProfile.BALANCED: "m",
    QualityProfile.FAST: "l",
}


class RenderExecutionError(RuntimeError):
    pass


class Renderer:
    def __init__(self, python_executable: str) -> None:
        self.python_executable = python_executable

    def render(
        self,
        code_file: Path,
        scene_name: str,
        output_name: str,
        quality_profile: QualityProfile,
        manim_flags: list[str],
        artifacts_dir: Path,
    ) -> tuple[Path, Path]:
        media_dir = artifacts_dir / "media"
        log_dir = artifacts_dir / "logs"
        media_dir.mkdir(parents=True, exist_ok=True)
        log_dir.mkdir(parents=True, exist_ok=True)

        command = [
            self.python_executable,
            "-m",
            "manim",
            "render",
            "--media_dir",
            str(media_dir),
            "--log_dir",
            str(log_dir),
            "--log_to_file",
            "--progress_bar",
            "none",
            "--format",
            "mp4",
            "-q",
            QUALITY_TO_MANIM[quality_profile],
            *manim_flags,
            str(code_file),
            scene_name,
            "-o",
            output_name,
        ]

        process = subprocess.run(command, capture_output=True, text=True)
        combined_output = "\n".join(part for part in [process.stdout, process.stderr] if part).strip()
        if process.returncode != 0:
            raise RenderExecutionError(combined_output or "Manim render failed without stderr output.")

        video_path = self._find_rendered_video(media_dir, output_name)
        if video_path is None:
            raise RenderExecutionError("Manim completed but the expected video file was not found.")
        log_file = self._latest_log(log_dir)
        return video_path, log_file

    def _find_rendered_video(self, media_dir: Path, output_name: str) -> Path | None:
        candidates = sorted(media_dir.rglob(f"{output_name}*.mp4"), key=lambda path: path.stat().st_mtime, reverse=True)
        return candidates[0] if candidates else None

    def _latest_log(self, log_dir: Path) -> Path:
        candidates = sorted(log_dir.rglob("*.log"), key=lambda path: path.stat().st_mtime, reverse=True)
        return candidates[0] if candidates else log_dir

    def publish_video(self, source: Path, output_dir: Path, output_name: str) -> Path:
        output_dir.mkdir(parents=True, exist_ok=True)
        destination = output_dir / f"{Path(output_name).stem}.mp4"
        shutil.copy2(source, destination)
        return destination

    def open_file(self, path: Path) -> None:
        if sys.platform.startswith("win"):
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.run(["open", str(path)], check=False)
        else:
            subprocess.run(["xdg-open", str(path)], check=False)


