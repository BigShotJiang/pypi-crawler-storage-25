from __future__ import annotations

import ast
from typing import Iterable

from .schemas import ValidationIssue, ValidationResult


DANGEROUS_IMPORTS = {
    "subprocess",
    "socket",
    "requests",
    "httpx",
    "shutil",
    "pathlib",
    "pickle",
    "multiprocessing",
    "asyncio",
}

DANGEROUS_CALLS = {
    "eval",
    "exec",
    "compile",
    "open",
    "input",
    "__import__",
    "system",
    "popen",
}

ALLOWED_BASES = {"Scene", "ThreeDScene", "MovingCameraScene"}


def strip_code_fences(code: str) -> str:
    cleaned = code.replace("```python", "").replace("```", "")
    return cleaned.strip()


def _extract_import_names(node: ast.AST) -> Iterable[str]:
    if isinstance(node, ast.Import):
        for alias in node.names:
            yield alias.name
    elif isinstance(node, ast.ImportFrom):
        yield node.module or ""


def _call_name(node: ast.Call) -> str | None:
    if isinstance(node.func, ast.Name):
        return node.func.id
    if isinstance(node.func, ast.Attribute):
        return node.func.attr
    return None


def extract_scene_names(code: str) -> list[str]:
    tree = ast.parse(code)
    class_bases: dict[str, list[str]] = {}
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            bases: list[str] = []
            for base in node.bases:
                if isinstance(base, ast.Name):
                    bases.append(base.id)
                elif isinstance(base, ast.Attribute):
                    bases.append(base.attr)
            class_bases[node.name] = bases

    resolved: list[str] = []

    def inherits_allowed(name: str, seen: set[str] | None = None) -> bool:
        seen = seen or set()
        if name in seen:
            return False
        seen.add(name)
        for base in class_bases.get(name, []):
            if base in ALLOWED_BASES:
                return True
            if base in class_bases and inherits_allowed(base, seen):
                return True
        return False

    for class_name in class_bases:
        if inherits_allowed(class_name):
            resolved.append(class_name)
    return resolved


def validate_generated_code(code: str, allowed_imports: list[str], allow_unsafe_python: bool = False) -> ValidationResult:
    issues: list[ValidationIssue] = []
    stripped = strip_code_fences(code)
    try:
        tree = ast.parse(stripped)
    except SyntaxError as exc:
        return ValidationResult(
            issues=[ValidationIssue(message=f"Syntax error: {exc.msg} at line {exc.lineno}", severity="error")]
        )

    if not allow_unsafe_python:
        for node in ast.walk(tree):
            for module_name in _extract_import_names(node):
                root = module_name.split(".")[0]
                if root in DANGEROUS_IMPORTS:
                    issues.append(ValidationIssue(message=f"Import '{module_name}' is not allowed."))
                elif module_name and root not in allowed_imports:
                    issues.append(ValidationIssue(message=f"Import '{module_name}' is outside the allowlist."))
            if isinstance(node, ast.Call):
                call_name = _call_name(node)
                if call_name in DANGEROUS_CALLS:
                    issues.append(ValidationIssue(message=f"Call '{call_name}' is not allowed."))

    scene_names = extract_scene_names(stripped)
    if not scene_names:
        issues.append(ValidationIssue(message="No renderable Manim scene class was found."))

    return ValidationResult(scene_name=scene_names[0] if scene_names else None, scene_names=scene_names, issues=issues)


