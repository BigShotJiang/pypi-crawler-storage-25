from pathlib import Path

from manimgenai.config import load_config, load_dotenv


def test_load_dotenv_reads_key_values(tmp_path: Path) -> None:
    env_path = tmp_path / ".env"
    env_path.write_text("OPENAI_API_KEY=test-key\nMANIMGENAI_KEEP_ARTIFACTS=false\n", encoding="utf-8")
    values = load_dotenv(env_path)
    assert values["OPENAI_API_KEY"] == "test-key"
    assert values["MANIMGENAI_KEEP_ARTIFACTS"] == "false"


def test_load_config_uses_env_file(tmp_path: Path) -> None:
    env_path = tmp_path / ".env"
    env_path.write_text(
        "OPENAI_API_KEY=test-key\nMANIMGENAI_MODEL_PLANNER_BALANCED=gpt-5.4\nMANIMGENAI_MODEL_CODEGEN_BALANCED=gpt-5.4-mini\nMANIMGENAI_OUTPUT_DIR=custom-out\n",
        encoding="utf-8",
    )
    config = load_config(env_path)
    assert config.api_key == "test-key"
    assert config.planner_model_balanced == "gpt-5.4"
    assert config.codegen_model_balanced == "gpt-5.4-mini"
    assert config.output_dir == Path("custom-out")

