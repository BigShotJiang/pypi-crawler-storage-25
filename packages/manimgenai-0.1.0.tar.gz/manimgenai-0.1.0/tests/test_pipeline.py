from pathlib import Path

from manimgenai.config import AppConfig
from manimgenai.pipeline import render_video
from manimgenai.schemas import QualityProfile, RenderRequest, VideoPlan


class FakePlanner:
    def __init__(self, client):
        self.client = client

    def create_plan(self, request: RenderRequest) -> VideoPlan:
        return VideoPlan(
            title="Demo",
            objective="Demo",
            style_notes="Clean",
            scenes=[],
        )


class FakeGenerator:
    def __init__(self, client):
        self.client = client

    def generate(self, plan: VideoPlan, request: RenderRequest) -> str:
        return "from manim import *\n\nclass Demo(Scene):\n    def construct(self):\n        self.add(Text('ok'))\n"

    def repair(self, plan: VideoPlan, request: RenderRequest, previous_code: str, failure_message: str) -> str:
        return previous_code


class FakeRenderer:
    def __init__(self, python_executable: str) -> None:
        self.python_executable = python_executable

    def render(self, code_file: Path, scene_name: str, output_name: str, quality_profile, manim_flags, artifacts_dir: Path):
        video_path = artifacts_dir / "media" / f"{output_name}.mp4"
        video_path.parent.mkdir(parents=True, exist_ok=True)
        video_path.write_bytes(b"video")
        log_path = artifacts_dir / "logs" / "render.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.write_text("ok", encoding="utf-8")
        return video_path, log_path

    def publish_video(self, source: Path, output_dir: Path, output_name: str) -> Path:
        output_dir.mkdir(parents=True, exist_ok=True)
        target = output_dir / f"{output_name}.mp4"
        target.write_bytes(source.read_bytes())
        return target

    def open_file(self, path: Path) -> None:
        return None


class FakeClient:
    def __init__(self, config):
        self.config = config


def test_render_video_success(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr("manimgenai.pipeline.OpenAIManinClient", FakeClient)
    monkeypatch.setattr("manimgenai.pipeline.VideoPlanner", FakePlanner)
    monkeypatch.setattr("manimgenai.pipeline.CodeGenerator", FakeGenerator)
    monkeypatch.setattr("manimgenai.pipeline.Renderer", FakeRenderer)

    config = AppConfig(api_key="test-key", output_dir=tmp_path / "out")
    request = RenderRequest(prompt="Create a simple text animation", output_name="demo", quality_profile=QualityProfile.BALANCED)
    result = render_video(request, config=config)

    assert result.status == "success"
    assert result.video_path is not None
    assert result.video_path.exists()
    assert result.scene_name == "Demo"
    assert result.attempt_count == 1


