from manimgenai.validator import extract_scene_names, validate_generated_code


VALID_CODE = """
from manim import *

class Demo(Scene):
    def construct(self):
        self.play(FadeIn(Text('Hi')))
"""


def test_extract_scene_names_finds_renderable_class() -> None:
    assert extract_scene_names(VALID_CODE) == ["Demo"]


def test_validate_generated_code_accepts_safe_scene() -> None:
    result = validate_generated_code(VALID_CODE, ["manim", "math", "random", "numpy"])
    assert result.is_valid
    assert result.scene_name == "Demo"


def test_validate_generated_code_rejects_dangerous_imports() -> None:
    code = "import subprocess\nfrom manim import *\nclass Demo(Scene):\n    def construct(self):\n        pass\n"
    result = validate_generated_code(code, ["manim", "math", "random", "numpy"])
    assert not result.is_valid
    assert any("not allowed" in issue.message for issue in result.issues)


