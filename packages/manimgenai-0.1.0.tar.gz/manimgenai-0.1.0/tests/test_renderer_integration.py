import sys
from pathlib import Path

import pytest

from manimgenai.renderer import Renderer
from manimgenai.schemas import QualityProfile


@pytest.mark.integration
def test_renderer_renders_simple_scene(tmp_path: Path) -> None:
    code_file = tmp_path / "simple_scene.py"
    code_file.write_text(
        "from manim import *\n\nclass Smoke(Scene):\n    def construct(self):\n        self.play(FadeIn(Text('Smoke test')))\n        self.wait(0.1)\n",
        encoding="utf-8",
    )
    renderer = Renderer(sys.executable)
    video_path, log_path = renderer.render(
        code_file=code_file,
        scene_name="Smoke",
        output_name="smoke",
        quality_profile=QualityProfile.FAST,
        manim_flags=[],
        artifacts_dir=tmp_path / "artifacts",
    )
    assert video_path.exists()
    assert log_path.exists()


