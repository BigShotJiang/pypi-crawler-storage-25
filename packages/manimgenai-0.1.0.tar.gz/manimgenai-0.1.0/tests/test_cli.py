from manimgenai.cli import main
from manimgenai.config import AppConfig
from manimgenai.schemas import RenderResult


def test_cli_examples_json(capsys) -> None:
    code = main(["examples", "--json"])
    captured = capsys.readouterr()
    assert code == 0
    assert "dot product" in captured.out.lower() or "derivative" in captured.out.lower()


def test_cli_doctor_json(monkeypatch, capsys) -> None:
    monkeypatch.setattr("manimgenai.cli.load_config", lambda: AppConfig(api_key="x"))
    monkeypatch.setattr(
        "manimgenai.cli.run_doctor",
        lambda config: type("Report", (), {"ok": True, "model_dump": lambda self, mode=None: {"checks": []}})(),
    )
    code = main(["doctor", "--json"])
    captured = capsys.readouterr()
    assert code == 0
    assert '"checks"' in captured.out


def test_cli_render_json(monkeypatch, capsys, tmp_path) -> None:
    monkeypatch.setattr("manimgenai.cli.load_config", lambda: AppConfig(api_key="x", output_dir=tmp_path / "out"))
    monkeypatch.setattr(
        "manimgenai.cli.render_video",
        lambda request, config: RenderResult(status="success", video_path=tmp_path / "out" / "demo.mp4", attempt_count=1),
    )
    code = main(["render", "hello", "--json"])
    captured = capsys.readouterr()
    assert code == 0
    assert '"status": "success"' in captured.out


