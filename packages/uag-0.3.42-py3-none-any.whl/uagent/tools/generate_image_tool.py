# tools/generate_image_tool.py
# -*- coding: utf-8 -*-
"""generate_image tool

Purpose:
- Generate an image from a text prompt, save it as a PNG file, and return the path.
- Automatically open the image after generation (can be disabled via environment variable UAGENT_IMAGE_OPEN=0).

Supported:
- provider: UAGENT_IMG_GENERATE_PROVIDER (fallback: UAGENT_PROVIDER)
- model/deployment: UAGENT_<PROVIDER>_IMG_GENERATE_DEPNAME

Note:
- Image generation APIs depend on provider/SDK support, subscription, and region.
  In case of error, check differences in model/permissions/response format.
"""

from __future__ import annotations
from .i18n_helper import make_tool_translator

_ = make_tool_translator(__file__)


import base64
import os
from ..env_utils import env_get
import ssl
import subprocess
import time
from typing import Any, Dict, List

from .context import get_callbacks

BUSY_LABEL = True
STATUS_LABEL = "tool:generate_image"


TOOL_SPEC: Dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "generate_image",
        "description": _(
            "tool.description",
            default="Generates an image from a text prompt, saves it as a PNG, and returns the file path. Automatically opens the image after generation (can be disabled with UAGENT_IMAGE_OPEN=0).",
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": _(
                        "param.prompt.description",
                        default="Instructions (prompt) for the image you want to generate.",
                    ),
                },
                "size": {
                    "type": "string",
                    "description": _(
                        "param.size.description",
                        default="Image size. E.g., 1024x1024 / 1024x1536 / 1536x1024",
                    ),
                    "default": "1024x1024",
                },
                "n": {
                    "type": "integer",
                    "description": _(
                        "param.n.description",
                        default="Number of images to generate (currently 1 is recommended).",
                    ),
                    "default": 1,
                    "minimum": 1,
                    "maximum": 4,
                },
                "output_dir": {
                    "type": "string",
                    "description": _(
                        "param.output_dir.description",
                        default="Directory to save images (relative or absolute). Defaults to outputs/image_generations if omitted.",
                    ),
                },
                "file_prefix": {
                    "type": "string",
                    "description": _(
                        "param.file_prefix.description",
                        default="Prefix for the saved filename (optional).",
                    ),
                    "default": "img",
                },
            },
            "required": ["prompt"],
        },
    },
}


def _get_provider() -> str:
    """Select provider for image generation."""
    p = (
        (
            env_get("UAGENT_IMG_GENERATE_PROVIDER")
            or env_get("UAGENT_PROVIDER")
            or "azure"
        )
        .strip()
        .lower()
    )
    if p not in ("azure", "openai", "bedrock", "gemini", "nvidia"):
        raise RuntimeError(
            f"invalid provider for image generation: {p!r} (UAGENT_IMG_GENERATE_PROVIDER/UAGENT_PROVIDER)"
        )
    return p


def _env_first(keys: List[str], *, required: bool, default: str = "") -> str:
    for k in keys:
        v = (env_get(k) or "").strip()
        if v:
            return v
    if required:
        raise RuntimeError(f"required env var is missing (tried: {', '.join(keys)})")
    return default


def _img_env(
    provider: str, mode: str, name: str, *, required: bool, default: str = ""
) -> str:
    """Resolve image env vars."""
    p = provider.strip().upper()
    m = mode.strip().upper()
    n = name.strip().upper()
    keys = [f"UAGENT_{p}_IMG_{m}_{n}", f"UAGENT_{p}_{n}"]
    return _env_first(keys, required=required, default=default)


def _ssl_verify_enabled() -> bool:
    """Default: no verification. Enable only if UAGENT_SSL_VERIFY=1/true/yes/on."""
    v = (env_get("UAGENT_SSL_VERIFY") or "").strip().lower()
    return v in ("1", "true", "yes", "on")


def _urlopen_kwargs() -> Dict[str, Any]:
    """Generate extra args for urllib. Return unverified context if verification is disabled."""
    if _ssl_verify_enabled():
        return {}
    ctx = ssl._create_unverified_context()
    return {"context": ctx}


def _get_image_depname(cb_get_env, provider: str) -> str:
    return _img_env(provider, "generate", "depname", required=True)


def _ensure_dir(p: str) -> str:
    p2 = os.path.expanduser(p)
    os.makedirs(p2, exist_ok=True)
    return p2


def _write_png_bytes(raw: bytes, out_path: str) -> None:
    with open(out_path, "wb") as f:
        f.write(raw)


def _write_png_from_b64(b64_data: str, out_path: str) -> None:
    raw = base64.b64decode(b64_data)
    _write_png_bytes(raw, out_path)


def _sanitize_size_for_provider(size: str) -> str:
    return size


def _save_many(outdir: str, prefix: str, ts: str, b64_list: List[str]) -> List[str]:
    saved: List[str] = []
    for i, b64 in enumerate(b64_list):
        fn = f"{prefix}_{ts}_{i+1}.png" if len(b64_list) > 1 else f"{prefix}_{ts}.png"
        out_path = os.path.join(outdir, fn)
        _write_png_from_b64(b64, out_path)
        saved.append(out_path)
    return saved


def _download_to_png(url: str, out_path: str) -> None:
    from urllib.request import Request, urlopen

    req = Request(url, headers={"User-Agent": "generate_image_tool"})
    with urlopen(req, **_urlopen_kwargs()) as resp:
        raw = resp.read()
    _write_png_bytes(raw, out_path)


def _open_image(file_path: str) -> None:
    """Open an image using the OS's default viewer."""
    try:
        if os.name == "nt":  # Windows
            os.startfile(file_path)
        elif hasattr(os, "uname") and os.uname().sysname == "Darwin":  # macOS
            subprocess.run(["open", file_path], check=False)
        else:  # Linux
            subprocess.run(["xdg-open", file_path], check=False)
    except Exception:
        pass


def _run_openai_images(
    provider: str, image_model: str, prompt: str, size: str, n: int
) -> Dict[str, Any]:
    try:
        from openai import AzureOpenAI, OpenAI
    except Exception as e:
        raise RuntimeError(
            _(
                "err.openai_import", default="Failed to import openai package: {err}"
            ).format(err=repr(e))
        )

    http_client = None
    try:
        from .. import util_providers as providers  # type: ignore

        http_client = providers.make_httpx_client(verify=_ssl_verify_enabled())
        if http_client is None:
            raise RuntimeError("httpx is not available")
    except Exception as e:
        raise RuntimeError(
            _("err.httpx_init", default="Failed to initialize httpx: {err}").format(
                err=repr(e)
            )
        )

    if provider == "azure":
        base_url = _img_env("azure", "generate", "base_url", required=True).rstrip("/")
        api_key = _img_env("azure", "generate", "api_key", required=True)
        api_version = _img_env("azure", "generate", "api_version", required=True)

        try:
            client = AzureOpenAI(
                azure_endpoint=base_url,
                api_key=api_key,
                api_version=api_version,
                http_client=http_client,
            )
        except TypeError:
            client = AzureOpenAI(
                azure_endpoint=base_url,
                api_key=api_key,
                api_version=api_version,
            )
    else:
        # OpenAI-compatible (openai / bedrock / nvidia)
        if provider == "nvidia":
            api_key = _img_env("nvidia", "generate", "api_key", required=True)
            base_url = _img_env(
                "nvidia",
                "generate",
                "base_url",
                required=False,
                default="https://integrate.api.nvidia.com/v1",
            ).rstrip("/")
        elif provider == "bedrock":
            api_key = _img_env("bedrock", "generate", "api_key", required=True)
            base_url = _img_env(
                "bedrock", "generate", "base_url", required=True
            ).rstrip("/")
        else:
            api_key = _img_env("openai", "generate", "api_key", required=True)
            base_url = _img_env(
                "openai",
                "generate",
                "base_url",
                required=False,
                default="https://api.openai.com/v1",
            ).rstrip("/")

        try:
            client = OpenAI(api_key=api_key, base_url=base_url, http_client=http_client)
        except TypeError:
            client = OpenAI(api_key=api_key, base_url=base_url)

    resp = client.images.generate(
        model=image_model,
        prompt=prompt,
        size=size,
        n=n,
    )

    b64_list: List[str] = []
    url_list: List[str] = []

    data_list = getattr(resp, "data", None) or []
    for item in data_list:
        b64 = getattr(item, "b64_json", None)
        if b64:
            b64_list.append(b64)
            continue
        url = getattr(item, "url", None)
        if url:
            url_list.append(url)

    if not b64_list and not url_list:
        raise RuntimeError(
            _(
                "err.empty_data",
                default="Image data was empty (resp.data is empty or b64_json/url is missing)",
            )
        )

    return {"b64_list": b64_list, "url_list": url_list}


def _run_gemini_images(image_model: str, prompt: str) -> List[str]:
    """Gemini image generation."""
    try:
        from google import genai  # type: ignore
    except Exception as e:
        raise RuntimeError(
            _(
                "err.gemini_import",
                default="Failed to import google-genai (pip install google-genai): {err}",
            ).format(err=repr(e))
        )

    api_key = _img_env("gemini", "generate", "api_key", required=True)
    client = genai.Client(api_key=api_key)

    # try 1: client.models.generate_images (Imagen 3/4, etc.)
    if hasattr(client, "models") and hasattr(client.models, "generate_images"):
        try:
            resp = client.models.generate_images(model=image_model, prompt=prompt)
            b64_list: List[str] = []
            for gi in getattr(resp, "generated_images", []) or []:
                img = getattr(gi, "image", None)
                if img is None:
                    continue

                # SDK v1.62+ uses image_bytes (bytes)
                raw_bytes = getattr(img, "image_bytes", None)
                if raw_bytes:
                    b64 = base64.b64encode(raw_bytes).decode("utf-8")
                else:
                    # Legacy SDK support
                    b64 = getattr(img, "bytes_base64_encoded", None) or getattr(
                        img, "data", None
                    )

                if b64:
                    b64_list.append(str(b64))
            if b64_list:
                return b64_list
        except Exception:
            pass

    # try 2: client.models.generate_content (Multimodal models, etc.)
    if hasattr(client, "models") and hasattr(client.models, "generate_content"):
        resp = client.models.generate_content(model=image_model, contents=prompt)
        b64_list2: List[str] = []
        cands = getattr(resp, "candidates", None) or []
        for cand in cands:
            content = getattr(cand, "content", None)
            parts = getattr(content, "parts", None) or []
            for part in parts:
                inline = getattr(part, "inline_data", None)
                if inline is None:
                    continue
                data = getattr(inline, "data", None)
                if data:
                    b64_list2.append(str(data))
        if b64_list2:
            return b64_list2

    raise RuntimeError(
        _(
            "err.gemini_fail",
            default="Failed to get image generation results from Gemini. The model might not support image generation, or the SDK response format is unexpected.",
        )
    )


def run_tool(args: Dict[str, Any]) -> str:
    cb = get_callbacks()

    prompt = str(args.get("prompt") or "").strip()
    if not prompt:
        return _("err.prompt_empty", default="[generate_image] prompt is empty")

    size = str(args.get("size") or "1024x1024")
    n = int(args.get("n") or 1)
    n = max(1, min(4, n))

    from uagent.utils.paths import get_image_generations_dir

    default_output_dir = str(get_image_generations_dir())
    output_dir = str(args.get("output_dir") or default_output_dir)
    file_prefix = str(args.get("file_prefix") or "img")

    provider = _get_provider()

    try:
        image_model = _get_image_depname(cb.get_env, provider)
    except Exception:
        return _(
            "err.depname_missing",
            default="[generate_image] Image model (deployment name) is not set.\nPlease set the environment variable UAGENT_<PROVIDER>_IMG_GENERATE_DEPNAME.",
        )

    try:
        outdir = _ensure_dir(output_dir)
    except Exception as e:
        return _(
            "err.mkdir_fail",
            default="[generate_image] Failed to create output_dir: {err}",
        ).format(err=e)

    ts = time.strftime("%Y%m%d_%H%M%S")

    try:
        size2 = _sanitize_size_for_provider(size)

        if provider in ("openai", "azure"):
            res = _run_openai_images(
                provider=provider,
                image_model=image_model,
                prompt=prompt,
                size=size2,
                n=n,
            )
            b64_list = res.get("b64_list") or []
            url_list = res.get("url_list") or []

            saved: List[str] = []
            if b64_list:
                saved.extend(_save_many(outdir, file_prefix, ts, b64_list))
            if url_list:
                for i, url in enumerate(url_list):
                    fn = (
                        f"{file_prefix}_{ts}_url_{i+1}.png"
                        if len(url_list) > 1
                        else f"{file_prefix}_{ts}_url.png"
                    )
                    out_path = os.path.join(outdir, fn)
                    _download_to_png(url, out_path)
                    saved.append(out_path)

        elif provider == "gemini":
            b64_list = _run_gemini_images(image_model=image_model, prompt=prompt)
            saved = _save_many(outdir, file_prefix, ts, b64_list)
        else:
            return _(
                "err.unsupported_provider",
                default="[generate_image] Unsupported provider={provider!r}",
            ).format(provider=provider)

    except Exception as e:
        return _(
            "err.gen_fail",
            default="[generate_image] Image generation failed.\nprovider={provider} model={model} size={size} n={n}\n{err}",
        ).format(provider=provider, model=image_model, size=size, n=n, err=repr(e))

    if not saved:
        return _("err.no_saved", default="[generate_image] Image data was empty")

    # Open by default. Disable via UAGENT_IMAGE_OPEN=0/false, etc.
    env_val = (env_get("UAGENT_IMAGE_OPEN") or "").strip().lower()
    should_open = env_val not in ("0", "false", "no", "off")

    if should_open:
        for p in saved:
            _open_image(p)

    if len(saved) == 1:
        return "[OK] generated: " + saved[0]
    return "[OK] generated:\n" + "\n".join(saved)
