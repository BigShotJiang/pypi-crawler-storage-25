"""
Output formatters for memory prediction results.
"""

from __future__ import annotations

import json
from typing import Any, Dict

from .estimator import PredictionResult


def format_verbose_layers(result: PredictionResult) -> str:
    """Format per-layer parameter breakdown."""
    layers = result.model_profile.layers
    if not layers:
        return ""

    try:
        from rich.console import Console
        from rich.table import Table
        import io

        console = Console(file=io.StringIO(), width=78)
        table = Table(
            title="Per-Layer Parameter Breakdown",
            show_header=True, header_style="bold", box=None, pad_edge=False,
        )
        table.add_column("Layer", style="cyan", min_width=30)
        table.add_column("Type", min_width=18)
        table.add_column("Params", justify="right", min_width=10)
        table.add_column("Memory", justify="right", min_width=9)
        table.add_column("Trainable", justify="center", min_width=9)

        total_bytes = sum(l.param_bytes for l in layers)
        for layer in layers:
            pct = layer.param_bytes / total_bytes * 100 if total_bytes else 0
            mem_str = _fmt_bytes(layer.param_bytes)
            trainable_str = "[green]✓[/green]" if layer.trainable else "[dim]✗[/dim]"
            table.add_row(
                layer.name or "(root)",
                layer.module_type,
                f"{layer.param_count:,}",
                f"{mem_str} ({pct:.1f}%)",
                trainable_str,
            )

        console.print(table)
        return console.file.getvalue()

    except ImportError:
        lines = [f"\n  {'Layer':<32} {'Type':<20} {'Params':>10} {'Memory':>10}"]
        lines.append("  " + "-" * 76)
        for layer in layers:
            lines.append(
                f"  {(layer.name or '(root)'):<32} {layer.module_type:<20} "
                f"{layer.param_count:>10,} {_fmt_bytes(layer.param_bytes):>10}"
            )
        return "\n".join(lines)


def _fmt_bytes(n: int) -> str:
    if n >= 1024**3:
        return f"{n / 1024**3:.3f} GB"
    if n >= 1024**2:
        return f"{n / 1024**2:.2f} MB"
    if n >= 1024:
        return f"{n / 1024:.1f} KB"
    return f"{n} B"


def format_table(result: PredictionResult, verbose: bool = False) -> str:
    """Format prediction result as a Rich table (returns console-renderable)."""
    try:
        from rich.console import Console
        from rich.panel import Panel
        from rich.table import Table
        from rich.text import Text
        import io

        console = Console(file=io.StringIO(), width=70)

        # Header
        mode = "Training" if result.training else "Inference"
        dtype_str = str(result.dtype).replace("torch.", "")
        header = f"{result.model_name} | Batch: {result.batch_size} | {dtype_str} | {mode}"

        # Memory breakdown table
        table = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
        table.add_column("Component", style="cyan", min_width=28)
        table.add_column("Memory", justify="right", min_width=10)
        table.add_column("% Total", justify="right", min_width=8)

        breakdown = result.breakdown_dict()
        for name, gb in breakdown.items():
            if gb < 0.001:
                continue
            pct = (gb / result.total_gb * 100) if result.total_gb > 0 else 0
            table.add_row(name, f"{gb:.3f} GB", f"{pct:.1f}%")

        table.add_row("─" * 28, "─" * 10, "─" * 8, style="dim")
        table.add_row("TOTAL (peak)", f"{result.total_gb:.3f} GB", "100%", style="bold")

        console.print(Panel(table, title=f"[bold]Kitsune Memory Prediction[/bold]", subtitle=header))

        # GPU fit status
        if result.target_gpu:
            fits = result.fits_on_gpu
            symbol = "[green]FITS[/green]" if fits else "[red]OOM[/red]"
            util = result.gpu_utilization_pct or 0
            console.print(
                f"\n  Target: [bold]{result.target_gpu.name}[/bold] "
                f"({result.target_gpu.vram_gb} GB) | "
                f"Usage: {util:.1f}% | {symbol}"
            )
            if result.headroom_gb is not None:
                if fits:
                    console.print(f"  Headroom: {result.headroom_gb:.2f} GB")
                else:
                    console.print(f"  [red]Over budget by: {abs(result.headroom_gb):.2f} GB[/red]")

        # Max batch size
        if result.max_batch_size is not None:
            console.print(f"\n  Max safe batch size: [bold]{result.max_batch_size}[/bold]")

        # Recommendations
        if result.recommendations:
            console.print("\n  [bold]Recommendations:[/bold]")
            for rec in result.recommendations[:5]:
                console.print(
                    f"    {rec.name}: "
                    f"[green]saves ~{rec.savings_gb:.2f} GB[/green]"
                    f"{f' ({rec.tradeoff})' if rec.tradeoff else ''}"
                )

        output = console.file.getvalue()
        if verbose:
            output += format_verbose_layers(result)
        return output

    except ImportError:
        return format_plain(result, verbose=verbose)


def format_plain(result: PredictionResult, verbose: bool = False) -> str:
    """Format prediction result as plain text."""
    lines = []
    mode = "Training" if result.training else "Inference"
    dtype_str = str(result.dtype).replace("torch.", "")

    lines.append("=" * 60)
    lines.append("  Kitsune Memory Prediction")
    lines.append("=" * 60)
    lines.append(f"  Model: {result.model_name} | Batch: {result.batch_size} | {dtype_str} | {mode}")
    lines.append("")

    # Breakdown
    lines.append(f"  {'Component':<30} {'Memory':>10} {'%':>7}")
    lines.append(f"  {'-' * 50}")
    breakdown = result.breakdown_dict()
    for name, gb in breakdown.items():
        if gb < 0.001:
            continue
        pct = (gb / result.total_gb * 100) if result.total_gb > 0 else 0
        lines.append(f"  {name:<30} {gb:>8.3f} GB {pct:>5.1f}%")
    lines.append(f"  {'-' * 50}")
    lines.append(f"  {'TOTAL (peak)':<30} {result.total_gb:>8.3f} GB {'100%':>6}")

    # GPU
    if result.target_gpu:
        lines.append("")
        fits = result.fits_on_gpu
        symbol = "FITS" if fits else "OOM!"
        util = result.gpu_utilization_pct or 0
        lines.append(
            f"  Target: {result.target_gpu.name} ({result.target_gpu.vram_gb} GB) "
            f"| Usage: {util:.1f}% | {symbol}"
        )

    # Max batch size
    if result.max_batch_size is not None:
        lines.append(f"  Max safe batch size: {result.max_batch_size}")

    # Recommendations
    if result.recommendations:
        lines.append("")
        lines.append("  Recommendations:")
        for rec in result.recommendations[:5]:
            tradeoff = f" ({rec.tradeoff})" if rec.tradeoff else ""
            lines.append(f"    {rec.name}: saves ~{rec.savings_gb:.2f} GB{tradeoff}")

    lines.append("=" * 60)
    output = "\n".join(lines)
    if verbose:
        output += "\n" + format_verbose_layers(result)
    return output


def format_json(result: PredictionResult) -> str:
    """Format prediction result as JSON."""
    data: Dict[str, Any] = {
        "model_name": result.model_name,
        "config": {
            "batch_size": result.batch_size,
            "input_shape": list(result.input_shape),
            "dtype": str(result.dtype).replace("torch.", ""),
            "optimizer": result.optimizer_type,
            "training": result.training,
        },
        "memory": {
            "total_gb": result.total_gb,
            "total_bytes": result.total_bytes,
            "breakdown": {
                "parameters_gb": result.param_gb,
                "gradients_gb": result.gradient_gb,
                "optimizer_gb": result.optimizer_gb,
                "activations_gb": result.activation_gb,
                "overhead_gb": result.overhead_bytes / (1024**3),
            },
        },
        "model_info": {
            "total_params": result.model_profile.total_params,
            "trainable_params": result.model_profile.trainable_params,
        },
    }

    if result.target_gpu:
        data["gpu"] = {
            "name": result.target_gpu.name,
            "vram_gb": result.target_gpu.vram_gb,
            "fits": result.fits_on_gpu,
            "utilization_pct": round(result.gpu_utilization_pct or 0, 1),
            "headroom_gb": round(result.headroom_gb or 0, 4),
        }

    if result.max_batch_size is not None:
        data["max_batch_size"] = result.max_batch_size

    if result.recommendations:
        data["recommendations"] = [
            {
                "name": r.name,
                "savings_gb": round(r.savings_gb, 4),
                "description": r.description,
                "tradeoff": r.tradeoff,
            }
            for r in result.recommendations[:5]
        ]

    return json.dumps(data, indent=2)
