"""
HuggingFace model integration for kitsune predict.

Loads any HuggingFace model on the meta device (no weights downloaded,
just architecture/shapes) and feeds it to predict_memory().

Usage:
    from kitsune.predict.hf_integration import load_hf_model, predict_hf_memory

    result = predict_hf_memory("bert-base-uncased", input_shape=(128,), batch_size=32)
"""

from __future__ import annotations

import logging
from typing import Optional, Tuple, Union

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


def load_hf_model(
    model_id: str,
    revision: Optional[str] = None,
) -> Tuple[nn.Module, Tuple[int, ...]]:
    """
    Load a HuggingFace model onto the meta device and infer its input shape.

    Uses the meta device so NO weights are downloaded — only the architecture
    is instantiated. This means the call is fast and uses no real memory.

    Args:
        model_id: HuggingFace model ID, e.g. "bert-base-uncased",
                  "meta-llama/Llama-2-7b", "openai/whisper-small".
        revision: Optional git revision (branch, tag, or commit hash).

    Returns:
        (model, input_shape) where input_shape is WITHOUT batch dimension.
        For text models: (seq_len,) as token IDs.
        For vision models: (C, H, W).

    Raises:
        ImportError: if transformers is not installed.
        ValueError: if the model type is not recognized.
    """
    try:
        from transformers import AutoConfig, AutoModel
    except ImportError:
        raise ImportError(
            "transformers not installed. Run: pip install transformers"
        )

    config = AutoConfig.from_pretrained(model_id, revision=revision)
    input_shape = _infer_input_shape(config)

    # Load model on meta device (no real memory, just shapes)
    with torch.device("meta"):
        model = AutoModel.from_config(config)

    model.eval()
    return model, input_shape


def predict_hf_memory(
    model_id: str,
    batch_size: int = 1,
    seq_len: Optional[int] = None,
    dtype: Union[torch.dtype, str] = torch.float32,
    optimizer: str = "adam",
    training: bool = False,
    gpu: Optional[str] = None,
    find_max_batch_size: bool = False,
    revision: Optional[str] = None,
):
    """
    Predict GPU memory for a HuggingFace model.

    Args:
        model_id: HuggingFace model ID (e.g. "bert-base-uncased").
        batch_size: Batch size.
        seq_len: Sequence length override. If None, uses model's max_position_embeddings.
        dtype: Dtype for computation.
        optimizer: Optimizer type (for training mode).
        training: If True, include gradients and optimizer states.
        gpu: Target GPU key.
        find_max_batch_size: If True, binary search for max batch size.
        revision: Optional git revision.

    Returns:
        PredictionResult from kitsune.predict.predict_memory.
    """
    from .estimator import predict_memory

    model, default_shape = load_hf_model(model_id, revision=revision)

    # Override seq_len if provided
    if seq_len is not None:
        input_shape = (seq_len,)
    else:
        input_shape = default_shape

    return predict_memory(
        model=model,
        input_shape=input_shape,
        batch_size=batch_size,
        dtype=dtype,
        optimizer=optimizer,
        training=training,
        gpu=gpu,
        find_max_batch_size=find_max_batch_size,
    )


def sweep_hf_batch_sizes(
    model_id: str,
    seq_len: Optional[int] = None,
    batch_sizes=None,
    dtype: Union[torch.dtype, str] = torch.float32,
    optimizer: str = "adam",
    training: bool = False,
    gpu: Optional[str] = None,
    revision: Optional[str] = None,
):
    """
    Sweep batch sizes for a HuggingFace model.

    Returns a SweepResult.
    """
    from .sweep import sweep_batch_sizes

    model, default_shape = load_hf_model(model_id, revision=revision)
    input_shape = (seq_len,) if seq_len is not None else default_shape

    return sweep_batch_sizes(
        model=model,
        input_shape=input_shape,
        batch_sizes=batch_sizes,
        dtype=dtype,
        optimizer=optimizer,
        training=training,
        gpu=gpu,
    )


# ─── Input shape inference ────────────────────────────────────────────────────

def _infer_input_shape(config) -> Tuple[int, ...]:
    """
    Infer the input shape from a HuggingFace config.

    Returns shape WITHOUT batch dimension.
    For text/sequence models: (seq_len,) — token IDs.
    For vision models: (C, H, W).
    For audio models: (samples,).
    """
    model_type = getattr(config, "model_type", "").lower()

    # ── Vision models ─────────────────────────────────────────────────────────
    vision_types = {
        "vit", "deit", "swin", "convnext", "efficientnet",
        "regnet", "resnet", "bit", "beit", "data2vec-vision",
        "dinov2", "levit", "poolformer", "pvt", "van",
    }
    if model_type in vision_types or "vit" in model_type:
        image_size = getattr(config, "image_size", 224)
        if isinstance(image_size, (list, tuple)):
            H, W = image_size[0], image_size[1]
        else:
            H = W = image_size
        num_channels = getattr(config, "num_channels", 3)
        return (num_channels, H, W)

    # ── Audio/speech models ────────────────────────────────────────────────────
    audio_types = {"wav2vec2", "hubert", "whisper", "speech2text", "speecht5"}
    if model_type in audio_types:
        # Return (samples,) — 1 second at 16kHz
        return (16000,)

    # ── Multimodal (treat as text for memory purposes) ────────────────────────
    # CLIP, BLIP, LLaVA — text encoder side dominates for most use-cases

    # ── Default: text/sequence model ─────────────────────────────────────────
    # Use max_position_embeddings capped at 512 to avoid absurdly large shapes
    max_pos = getattr(config, "max_position_embeddings", 512)
    seq_len = min(max_pos, 512)
    return (seq_len,)


def get_model_info(model_id: str, revision: Optional[str] = None) -> dict:
    """
    Return key model metadata without loading weights.

    Useful for pre-flight checks before running predict_hf_memory().
    """
    try:
        from transformers import AutoConfig
    except ImportError:
        raise ImportError("transformers not installed. Run: pip install transformers")

    config = AutoConfig.from_pretrained(model_id, revision=revision)
    input_shape = _infer_input_shape(config)

    return {
        "model_id": model_id,
        "model_type": getattr(config, "model_type", "unknown"),
        "inferred_input_shape": input_shape,
        "max_position_embeddings": getattr(config, "max_position_embeddings", None),
        "hidden_size": getattr(config, "hidden_size", None),
        "num_hidden_layers": getattr(config, "num_hidden_layers", None),
        "num_attention_heads": getattr(config, "num_attention_heads", None),
        "vocab_size": getattr(config, "vocab_size", None),
        "image_size": getattr(config, "image_size", None),
        "num_channels": getattr(config, "num_channels", None),
    }
