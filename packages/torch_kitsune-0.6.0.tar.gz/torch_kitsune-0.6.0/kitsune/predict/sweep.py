"""
Sweep mode: memory predictions across a range of batch sizes.

Produces a table showing how memory scales, which batch sizes fit on a target
GPU, and where the OOM boundary is. This is the shareable output — the
screenshot that gets posted.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple, Union

import torch
import torch.nn as nn

from .estimator import PredictionResult, predict_memory
from .gpu_database import GPUSpec, get_gpu_spec


@dataclass
class SweepResult:
    """Memory predictions across a range of batch sizes."""

    model_name: str
    input_shape: Tuple[int, ...]
    dtype: torch.dtype
    optimizer_type: str
    training: bool
    target_gpu: Optional[GPUSpec]

    rows: List[PredictionResult]  # one per batch size, ordered ascending

    @property
    def max_fitting_batch_size(self) -> Optional[int]:
        """Largest batch size that fits on target GPU, or None."""
        if self.target_gpu is None:
            return None
        fitting = [r for r in self.rows if r.fits_on_gpu]
        return fitting[-1].batch_size if fitting else None

    @property
    def oom_threshold_batch_size(self) -> Optional[int]:
        """Smallest batch size that causes OOM, or None if all fit."""
        if self.target_gpu is None:
            return None
        oom = [r for r in self.rows if not r.fits_on_gpu]
        return oom[0].batch_size if oom else None


def sweep_batch_sizes(
    model: nn.Module,
    input_shape: Union[Tuple[int, ...], List[int]],
    batch_sizes: Optional[Sequence[int]] = None,
    dtype: Union[torch.dtype, str] = torch.float32,
    optimizer: str = "adam",
    training: bool = True,
    gpu: Optional[str] = None,
) -> SweepResult:
    """
    Run memory predictions across a range of batch sizes.

    Args:
        model: PyTorch model.
        input_shape: Input shape WITHOUT batch dimension.
        batch_sizes: Specific batch sizes to test. Defaults to powers of 2: 1–512.
        dtype: Model/input dtype.
        optimizer: Optimizer type.
        training: Training or inference mode.
        gpu: Target GPU key for fit/OOM annotation.

    Returns:
        SweepResult with one PredictionResult per batch size.
    """
    if batch_sizes is None:
        batch_sizes = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512]

    target_gpu = get_gpu_spec(gpu) if gpu else None

    rows = []
    for bs in sorted(set(batch_sizes)):
        result = predict_memory(
            model=model,
            input_shape=input_shape,
            batch_size=bs,
            dtype=dtype,
            optimizer=optimizer,
            training=training,
            gpu=gpu,
        )
        rows.append(result)

    first = rows[0] if rows else None
    return SweepResult(
        model_name=first.model_name if first else "unknown",
        input_shape=tuple(input_shape),
        dtype=first.dtype if first else torch.float32,
        optimizer_type=optimizer,
        training=training,
        target_gpu=target_gpu,
        rows=rows,
    )


# ─── Formatters ──────────────────────────────────────────────────────────────

def format_sweep_table(sweep: SweepResult) -> str:
    """Format sweep results as a Rich table."""
    try:
        from rich.console import Console
        from rich.panel import Panel
        from rich.table import Table
        from rich.text import Text
        import io

        console = Console(file=io.StringIO(), width=80)

        mode = "Training" if sweep.training else "Inference"
        dtype_str = str(sweep.dtype).replace("torch.", "")
        subtitle = f"{sweep.model_name} | {dtype_str} | {mode}"
        if sweep.target_gpu:
            subtitle += f" | Target: {sweep.target_gpu.name} ({sweep.target_gpu.vram_gb}GB)"

        table = Table(
            show_header=True, header_style="bold",
            box=None, pad_edge=False,
        )
        table.add_column("Batch", justify="right", min_width=6)
        table.add_column("Params", justify="right", min_width=8)
        table.add_column("Grads", justify="right", min_width=8)
        table.add_column("Opt", justify="right", min_width=8)
        table.add_column("Act", justify="right", min_width=8)
        table.add_column("Total", justify="right", min_width=9, style="bold")

        if sweep.target_gpu:
            table.add_column("GPU%", justify="right", min_width=6)
            table.add_column("Fit?", justify="center", min_width=5)

        for r in sweep.rows:
            row_data = [
                str(r.batch_size),
                f"{r.param_gb:.3f}",
                f"{r.gradient_gb:.3f}",
                f"{r.optimizer_gb:.3f}",
                f"{r.activation_gb:.3f}",
                f"{r.total_gb:.3f} GB",
            ]
            if sweep.target_gpu:
                util = r.gpu_utilization_pct or 0
                fits = r.fits_on_gpu
                status = "[green]✓[/green]" if fits else "[red]✗ OOM[/red]"
                row_data += [f"{util:.1f}%", status]

            # Highlight the OOM boundary row
            if sweep.target_gpu and not r.fits_on_gpu:
                table.add_row(*row_data, style="red")
            elif sweep.target_gpu and r.fits_on_gpu:
                table.add_row(*row_data)
            else:
                table.add_row(*row_data)

        console.print(
            Panel(table, title="[bold]Kitsune Batch Size Sweep[/bold]", subtitle=subtitle)
        )

        if sweep.target_gpu:
            max_bs = sweep.max_fitting_batch_size
            oom_bs = sweep.oom_threshold_batch_size
            if max_bs is not None:
                console.print(f"\n  Max safe batch size: [bold green]{max_bs}[/bold green]")
            if oom_bs is not None:
                console.print(f"  OOM at batch size:   [bold red]{oom_bs}[/bold red]")

        return console.file.getvalue()

    except ImportError:
        return format_sweep_plain(sweep)


def format_sweep_plain(sweep: SweepResult) -> str:
    """Format sweep as plain text."""
    mode = "Training" if sweep.training else "Inference"
    dtype_str = str(sweep.dtype).replace("torch.", "")

    lines = ["=" * 70, "  Kitsune Batch Size Sweep", "=" * 70]
    lines.append(f"  Model: {sweep.model_name} | {dtype_str} | {mode}")
    if sweep.target_gpu:
        lines.append(f"  Target: {sweep.target_gpu.name} ({sweep.target_gpu.vram_gb} GB)")
    lines.append("")

    header = f"  {'Batch':>6}  {'Params':>8}  {'Grads':>8}  {'Opt':>8}  {'Act':>8}  {'Total':>9}"
    if sweep.target_gpu:
        header += f"  {'GPU%':>5}  {'Fit?':>5}"
    lines.append(header)
    lines.append("  " + "-" * (len(header) - 2))

    for r in sweep.rows:
        line = (
            f"  {r.batch_size:>6}  {r.param_gb:>7.3f}G  {r.gradient_gb:>7.3f}G  "
            f"{r.optimizer_gb:>7.3f}G  {r.activation_gb:>7.3f}G  {r.total_gb:>8.3f}G"
        )
        if sweep.target_gpu:
            util = r.gpu_utilization_pct or 0
            status = "FITS" if r.fits_on_gpu else "OOM!"
            line += f"  {util:>4.1f}%  {status}"
        lines.append(line)

    lines.append("  " + "-" * (len(header) - 2))

    if sweep.target_gpu:
        max_bs = sweep.max_fitting_batch_size
        oom_bs = sweep.oom_threshold_batch_size
        if max_bs:
            lines.append(f"  Max safe batch size: {max_bs}")
        if oom_bs:
            lines.append(f"  OOM at batch size:   {oom_bs}")

    lines.append("=" * 70)
    return "\n".join(lines)


def format_sweep_json(sweep: SweepResult) -> str:
    """Format sweep as JSON."""
    import json

    data = {
        "model_name": sweep.model_name,
        "config": {
            "input_shape": list(sweep.input_shape),
            "dtype": str(sweep.dtype).replace("torch.", ""),
            "optimizer": sweep.optimizer_type,
            "training": sweep.training,
        },
        "target_gpu": None,
        "max_fitting_batch_size": sweep.max_fitting_batch_size,
        "oom_threshold_batch_size": sweep.oom_threshold_batch_size,
        "rows": [],
    }

    if sweep.target_gpu:
        data["target_gpu"] = {
            "name": sweep.target_gpu.name,
            "vram_gb": sweep.target_gpu.vram_gb,
        }

    for r in sweep.rows:
        row = {
            "batch_size": r.batch_size,
            "total_gb": r.total_gb,
            "breakdown": {
                "params_gb": r.param_gb,
                "grads_gb": r.gradient_gb,
                "optimizer_gb": r.optimizer_gb,
                "activations_gb": r.activation_gb,
                "overhead_gb": r.overhead_bytes / (1024**3),
            },
        }
        if sweep.target_gpu:
            row["gpu_utilization_pct"] = round(r.gpu_utilization_pct or 0, 1)
            row["fits"] = r.fits_on_gpu
        data["rows"].append(row)

    return json.dumps(data, indent=2)
