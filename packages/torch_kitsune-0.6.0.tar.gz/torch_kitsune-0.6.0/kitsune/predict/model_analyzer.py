"""
Model introspection: parameter counting, layer enumeration, dtype detection.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn


@dataclass
class LayerInfo:
    """Information about a single model layer."""

    name: str
    module_type: str
    param_count: int
    param_bytes: int
    trainable: bool
    dtype: torch.dtype
    shape_info: Optional[Dict] = None


@dataclass
class ModelProfile:
    """Complete memory-relevant profile of a model."""

    model_name: str
    total_params: int
    trainable_params: int
    total_param_bytes: int
    trainable_param_bytes: int
    layers: List[LayerInfo] = field(default_factory=list)
    dtypes: Dict[str, int] = field(default_factory=dict)  # dtype -> count

    @property
    def total_param_gb(self) -> float:
        return self.total_param_bytes / (1024**3)

    @property
    def trainable_param_gb(self) -> float:
        return self.trainable_param_bytes / (1024**3)


def analyze_model(model: nn.Module) -> ModelProfile:
    """
    Analyze a PyTorch model's memory-relevant properties.

    Args:
        model: PyTorch model to analyze.

    Returns:
        ModelProfile with parameter counts, sizes, and layer breakdown.
    """
    model_name = type(model).__name__

    total_params = 0
    trainable_params = 0
    total_param_bytes = 0
    trainable_param_bytes = 0
    layers: List[LayerInfo] = []
    dtypes: Dict[str, int] = {}

    for name, module in model.named_modules():
        # Only count leaf modules (no double-counting)
        module_params = list(module.parameters(recurse=False))
        if not module_params:
            continue

        layer_param_count = 0
        layer_param_bytes = 0
        layer_trainable = False
        layer_dtype = torch.float32

        for p in module_params:
            numel = p.numel()
            nbytes = numel * p.element_size()
            layer_param_count += numel
            layer_param_bytes += nbytes
            total_params += numel
            total_param_bytes += nbytes

            if p.requires_grad:
                trainable_params += numel
                trainable_param_bytes += nbytes
                layer_trainable = True

            layer_dtype = p.dtype
            dtype_key = str(p.dtype)
            dtypes[dtype_key] = dtypes.get(dtype_key, 0) + numel

        layers.append(
            LayerInfo(
                name=name or "(root)",
                module_type=type(module).__name__,
                param_count=layer_param_count,
                param_bytes=layer_param_bytes,
                trainable=layer_trainable,
                dtype=layer_dtype,
            )
        )

    return ModelProfile(
        model_name=model_name,
        total_params=total_params,
        trainable_params=trainable_params,
        total_param_bytes=total_param_bytes,
        trainable_param_bytes=trainable_param_bytes,
        layers=layers,
        dtypes=dtypes,
    )


def get_model_dtype_bytes(model: nn.Module) -> int:
    """Return the element size in bytes of the model's primary dtype."""
    try:
        p = next(model.parameters())
        return p.element_size()
    except StopIteration:
        return 4  # default float32
