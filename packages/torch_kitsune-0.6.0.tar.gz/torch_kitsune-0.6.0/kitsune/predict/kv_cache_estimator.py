"""
KV-cache memory estimator for LLM inference.

KV-cache stores all past keys and values so the model doesn't recompute them
on each generation step. It is the dominant memory cost for long-context and
high-throughput LLM inference.

Formula
───────
  kv_bytes = 2 × num_layers × num_kv_heads × head_dim × seq_len × batch_size × dtype_size

  • 2      — one tensor for K, one for V
  • GQA    — Llama-2 / Mistral use num_kv_heads < num_heads (grouped-query attention)
  • MQA    — extreme case: num_kv_heads = 1

Total inference memory
──────────────────────
  total = weights + kv_cache + activations (decode step) + overhead (~15%)

  • weights  = model params in inference dtype (no gradients, no optimizer)
  • kv_cache = formula above
  • activations at decode step ≈ single forward pass, batch=1, seq=1 (tiny)

Sweep
─────
  Sweep seq_len (context window) to find the max context at a given batch size
  before OOM on a target GPU.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn


OVERHEAD_FRACTION = 0.15


@dataclass
class KVCacheConfig:
    """Architecture config for KV-cache estimation."""

    num_layers: int
    num_kv_heads: int         # GQA/MQA: may be < num_heads
    head_dim: int             # hidden_size // num_heads
    max_seq_len: int          # model's maximum context length
    model_name: str = "model"
    num_attention_heads: int = 0   # full heads count (for display)

    @classmethod
    def from_hf_config(cls, config) -> "KVCacheConfig":
        """Extract KV-cache config from a HuggingFace model config object."""
        num_layers = (
            getattr(config, "num_hidden_layers", None)
            or getattr(config, "n_layer", None)
            or getattr(config, "num_layers", None)
            or 12
        )
        num_heads = (
            getattr(config, "num_attention_heads", None)
            or getattr(config, "n_head", None)
            or 12
        )
        # GQA/MQA: num_key_value_heads may differ from num_attention_heads
        num_kv_heads = (
            getattr(config, "num_key_value_heads", None)
            or num_heads
        )
        hidden_size = (
            getattr(config, "hidden_size", None)
            or getattr(config, "n_embd", None)
            or getattr(config, "d_model", None)
            or 768
        )
        # Some models specify head_dim directly (e.g. Gemma)
        head_dim = getattr(config, "head_dim", None) or (hidden_size // num_heads)
        max_seq_len = (
            getattr(config, "max_position_embeddings", None)
            or getattr(config, "n_positions", None)
            or getattr(config, "max_sequence_length", None)
            or 2048
        )
        model_name = getattr(config, "_name_or_path", "") or getattr(config, "model_type", "model")

        return cls(
            num_layers=num_layers,
            num_kv_heads=num_kv_heads,
            head_dim=head_dim,
            max_seq_len=max_seq_len,
            model_name=model_name,
            num_attention_heads=num_heads,
        )

    @classmethod
    def from_model(cls, model: nn.Module) -> "KVCacheConfig":
        """Try to extract KV-cache config from a loaded nn.Module."""
        if hasattr(model, "config"):
            return cls.from_hf_config(model.config)
        raise ValueError(
            "Cannot auto-detect KV-cache config. Pass a model with .config or "
            "use KVCacheConfig(num_layers=..., num_kv_heads=..., head_dim=..., max_seq_len=...)"
        )


@dataclass
class KVCacheResult:
    """Memory breakdown for a single KV-cache configuration."""

    # Config
    kv_config: KVCacheConfig
    seq_len: int
    batch_size: int
    dtype: torch.dtype

    # Memory (bytes)
    kv_cache_bytes: int
    weight_bytes: int             # model weights (inference, no grads)
    activation_bytes: int         # decode-step activations (tiny)
    overhead_bytes: int

    # GPU target (optional)
    target_gpu_name: Optional[str] = None
    target_gpu_vram_gb: Optional[float] = None
    target_gpu_usable_gb: Optional[float] = None

    @property
    def total_bytes(self) -> int:
        return (
            self.weight_bytes
            + self.kv_cache_bytes
            + self.activation_bytes
            + self.overhead_bytes
        )

    @property
    def total_gb(self) -> float:
        return self.total_bytes / (1024 ** 3)

    @property
    def kv_cache_gb(self) -> float:
        return self.kv_cache_bytes / (1024 ** 3)

    @property
    def weight_gb(self) -> float:
        return self.weight_bytes / (1024 ** 3)

    @property
    def fits(self) -> Optional[bool]:
        if self.target_gpu_usable_gb is None:
            return None
        return self.total_gb <= self.target_gpu_usable_gb

    @property
    def gpu_utilization_pct(self) -> Optional[float]:
        if self.target_gpu_vram_gb is None:
            return None
        return (self.total_gb / self.target_gpu_vram_gb) * 100

    @property
    def headroom_gb(self) -> Optional[float]:
        if self.target_gpu_usable_gb is None:
            return None
        return self.target_gpu_usable_gb - self.total_gb

    @property
    def kv_pct_of_total(self) -> float:
        return (self.kv_cache_bytes / self.total_bytes * 100) if self.total_bytes > 0 else 0

    def breakdown_dict(self) -> Dict[str, float]:
        return {
            "Model weights": self.weight_gb,
            "KV cache": self.kv_cache_gb,
            "Activations (decode)": self.activation_bytes / (1024 ** 3),
            "Overhead (~15%)": self.overhead_bytes / (1024 ** 3),
        }

    def summary(self) -> str:
        status = ""
        if self.fits is not None:
            symbol = "FITS" if self.fits else "OOM"
            status = f" | {self.target_gpu_name} ({self.target_gpu_vram_gb}GB): {symbol}"
        return (
            f"seq={self.seq_len} bs={self.batch_size}: "
            f"{self.total_gb:.2f} GB total "
            f"(KV={self.kv_cache_gb:.2f} GB, {self.kv_pct_of_total:.0f}%)"
            f"{status}"
        )


@dataclass
class KVSweepResult:
    """KV-cache memory across a range of sequence lengths."""

    kv_config: KVCacheConfig
    batch_size: int
    dtype: torch.dtype
    results: List[KVCacheResult] = field(default_factory=list)

    @property
    def max_fitting_seq_len(self) -> Optional[int]:
        """Largest seq_len that fits on the target GPU."""
        fitting = [r for r in self.results if r.fits is True]
        return max(r.seq_len for r in fitting) if fitting else None

    @property
    def oom_threshold_seq_len(self) -> Optional[int]:
        """Smallest seq_len that OOMs."""
        oom = [r for r in self.results if r.fits is False]
        return min(r.seq_len for r in oom) if oom else None

    @property
    def target_gpu_name(self) -> Optional[str]:
        return self.results[0].target_gpu_name if self.results else None


def estimate_kv_cache(
    model_or_config: Union[nn.Module, KVCacheConfig],
    seq_len: int,
    batch_size: int = 1,
    dtype: Union[torch.dtype, str] = torch.float16,
    gpu: Optional[str] = None,
) -> KVCacheResult:
    """
    Estimate KV-cache memory for a given model configuration.

    Args:
        model_or_config: A model with .config, or a KVCacheConfig directly.
        seq_len: Context/sequence length (number of tokens).
        batch_size: Number of concurrent inference requests.
        dtype: Inference dtype (float16/bfloat16 most common for LLMs).
        gpu: Target GPU key (e.g. "a100-80gb").

    Returns:
        KVCacheResult with full breakdown.
    """
    if isinstance(dtype, str):
        dtype = _resolve_dtype(dtype)

    # Resolve config
    if isinstance(model_or_config, KVCacheConfig):
        kv_config = model_or_config
        model = None
    else:
        kv_config = KVCacheConfig.from_model(model_or_config)
        model = model_or_config

    dtype_size = torch.empty(0, dtype=dtype).element_size()

    # ── KV-cache bytes ────────────────────────────────────────────────────────
    # 2 = K + V
    kv_cache_bytes = (
        2
        * kv_config.num_layers
        * kv_config.num_kv_heads
        * kv_config.head_dim
        * seq_len
        * batch_size
        * dtype_size
    )

    # ── Weight bytes (params in inference dtype, no grads) ────────────────────
    if model is not None:
        weight_bytes = sum(p.numel() * dtype_size for p in model.parameters())
    else:
        # Approximate from config if no model
        weight_bytes = _estimate_weight_bytes_from_config(kv_config, dtype_size)

    # ── Decode-step activations (very small: seq=1 forward pass) ─────────────
    # Single token decode: batch_size × 1 × hidden_size × layers
    hidden_size = kv_config.num_attention_heads * kv_config.head_dim if kv_config.num_attention_heads else kv_config.num_kv_heads * kv_config.head_dim
    activation_bytes = int(
        batch_size
        * 1  # single decode token
        * hidden_size
        * kv_config.num_layers
        * dtype_size
        * 4   # Q, K, V, output projections active simultaneously
    )

    # ── Overhead ──────────────────────────────────────────────────────────────
    subtotal = weight_bytes + kv_cache_bytes + activation_bytes
    overhead_bytes = int(subtotal * OVERHEAD_FRACTION)

    # ── GPU target ────────────────────────────────────────────────────────────
    gpu_name = None
    gpu_vram_gb = None
    gpu_usable_gb = None
    if gpu:
        from .gpu_database import get_gpu_spec
        spec = get_gpu_spec(gpu)
        if spec:
            gpu_name = spec.name
            gpu_vram_gb = spec.vram_gb
            gpu_usable_gb = spec.usable_vram_gb

    return KVCacheResult(
        kv_config=kv_config,
        seq_len=seq_len,
        batch_size=batch_size,
        dtype=dtype,
        kv_cache_bytes=kv_cache_bytes,
        weight_bytes=weight_bytes,
        activation_bytes=activation_bytes,
        overhead_bytes=overhead_bytes,
        target_gpu_name=gpu_name,
        target_gpu_vram_gb=gpu_vram_gb,
        target_gpu_usable_gb=gpu_usable_gb,
    )


def sweep_kv_seq_lens(
    model_or_config: Union[nn.Module, KVCacheConfig],
    seq_lens: Optional[List[int]] = None,
    batch_size: int = 1,
    dtype: Union[torch.dtype, str] = torch.float16,
    gpu: Optional[str] = None,
) -> KVSweepResult:
    """
    Sweep KV-cache memory across context lengths to find the OOM boundary.

    Args:
        model_or_config: Model or KVCacheConfig.
        seq_lens: List of context lengths to test. Default: powers of 2 up to max.
        batch_size: Number of concurrent requests.
        dtype: Inference dtype.
        gpu: Target GPU key.

    Returns:
        KVSweepResult with per-length breakdown.
    """
    if isinstance(dtype, str):
        dtype = _resolve_dtype(dtype)

    # Resolve config once for sweep params
    if isinstance(model_or_config, KVCacheConfig):
        kv_config = model_or_config
    else:
        kv_config = KVCacheConfig.from_model(model_or_config)

    if seq_lens is None:
        # Powers of 2 up to model max, at least 8 points
        max_len = kv_config.max_seq_len
        seq_lens = []
        n = 512
        while n <= max_len:
            seq_lens.append(n)
            n *= 2
        if not seq_lens:
            seq_lens = [128, 256, 512, 1024]
        elif max_len not in seq_lens:
            seq_lens.append(max_len)
        seq_lens = sorted(set(seq_lens))

    results = [
        estimate_kv_cache(model_or_config, sl, batch_size, dtype, gpu)
        for sl in sorted(seq_lens)
    ]

    return KVSweepResult(
        kv_config=kv_config,
        batch_size=batch_size,
        dtype=dtype,
        results=results,
    )


def _estimate_weight_bytes_from_config(config: KVCacheConfig, dtype_size: int) -> int:
    """
    Rough weight size estimate when only KVCacheConfig is available (no model loaded).
    Formula: 12 × num_layers × hidden_size² × dtype_size  (transformer rule-of-thumb)
    """
    hidden_size = config.num_attention_heads * config.head_dim if config.num_attention_heads else config.num_kv_heads * config.head_dim
    if hidden_size <= 0:
        return 0
    # 12 × H² per layer (attention + FFN) — standard transformer approximation
    params_estimate = 12 * config.num_layers * hidden_size * hidden_size
    return params_estimate * dtype_size


def _resolve_dtype(s: str) -> torch.dtype:
    return {
        "float32": torch.float32, "fp32": torch.float32,
        "float16": torch.float16, "fp16": torch.float16,
        "bfloat16": torch.bfloat16, "bf16": torch.bfloat16,
    }.get(s.lower(), torch.float16)
