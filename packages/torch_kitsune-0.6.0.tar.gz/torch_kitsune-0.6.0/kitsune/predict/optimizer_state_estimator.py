"""
Optimizer state memory estimation.

Optimizer states are always stored in fp32 regardless of model dtype.
"""

from __future__ import annotations

from typing import Optional

import torch.nn as nn

# Multiplier = number of fp32 state tensors per parameter tensor
OPTIMIZER_STATE_MULTIPLIERS = {
    "adam": 2,       # m (momentum) + v (variance)
    "adamw": 2,     # same as adam
    "adam8bit": 2,   # same count but int8 — handled separately
    "sgd": 0,       # no state without momentum
    "sgd_momentum": 1,  # momentum buffer
    "adagrad": 1,   # sum of squares
    "rmsprop": 1,   # running average of squared gradients
    "none": 0,      # inference, no optimizer
}


def estimate_optimizer_memory(
    model: nn.Module,
    optimizer_type: str = "adam",
) -> int:
    """
    Estimate optimizer state memory in bytes.

    Optimizer states are always fp32 (4 bytes per element) regardless of
    the model's parameter dtype.

    Args:
        model: PyTorch model.
        optimizer_type: One of: adam, adamw, sgd, sgd_momentum, adagrad, rmsprop, none.

    Returns:
        Estimated optimizer state memory in bytes.
    """
    opt_key = optimizer_type.lower().replace("-", "").replace("_", "")

    # Normalize common variants
    if opt_key in ("adam", "adamw", "fusedadam"):
        multiplier = 2
    elif opt_key in ("sgd",):
        multiplier = 0
    elif opt_key in ("sgdmomentum", "sgd_momentum"):
        multiplier = 1
    elif opt_key in ("adagrad",):
        multiplier = 1
    elif opt_key in ("rmsprop",):
        multiplier = 1
    elif opt_key in ("none", "inference"):
        multiplier = 0
    else:
        # Unknown optimizer — assume Adam-like (2 states)
        multiplier = OPTIMIZER_STATE_MULTIPLIERS.get(opt_key, 2)

    # Count trainable parameter elements (states are always fp32 = 4 bytes)
    trainable_elements = sum(
        p.numel() for p in model.parameters() if p.requires_grad
    )

    return trainable_elements * 4 * multiplier


def estimate_gradient_memory(model: nn.Module) -> int:
    """
    Estimate gradient memory in bytes.

    Gradients have the same dtype and shape as their corresponding parameters.

    Args:
        model: PyTorch model.

    Returns:
        Estimated gradient memory in bytes.
    """
    return sum(
        p.numel() * p.element_size()
        for p in model.parameters()
        if p.requires_grad
    )
