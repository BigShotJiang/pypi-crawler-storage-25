"""
Core memory prediction orchestrator.

Combines parameter, gradient, optimizer, and activation estimates into
a unified PredictionResult.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn

from .activation_estimator import estimate_activation_memory
from .gpu_database import GPUSpec, find_cheapest_gpu, get_gpu_spec
from .model_analyzer import ModelProfile, analyze_model
from .optimizer_state_estimator import (
    estimate_gradient_memory,
    estimate_optimizer_memory,
)
from .recommendations import Recommendation, compute_recommendations


# Safety margin for CUDA allocator overhead, fragmentation, PyTorch internals
OVERHEAD_FRACTION = 0.15


@dataclass
class PredictionResult:
    """Complete memory prediction for a model configuration."""

    # Model info
    model_name: str
    model_profile: ModelProfile

    # Configuration
    batch_size: int
    input_shape: Tuple[int, ...]
    dtype: torch.dtype
    optimizer_type: str
    training: bool

    # Memory breakdown (bytes)
    param_bytes: int
    gradient_bytes: int
    optimizer_bytes: int
    activation_bytes: int
    overhead_bytes: int

    # Target GPU
    target_gpu: Optional[GPUSpec] = None

    # Recommendations
    recommendations: List[Recommendation] = field(default_factory=list)

    # Max batch size (if computed)
    max_batch_size: Optional[int] = None

    @property
    def total_bytes(self) -> int:
        return (
            self.param_bytes
            + self.gradient_bytes
            + self.optimizer_bytes
            + self.activation_bytes
            + self.overhead_bytes
        )

    @property
    def total_gb(self) -> float:
        return self.total_bytes / (1024**3)

    @property
    def param_gb(self) -> float:
        return self.param_bytes / (1024**3)

    @property
    def gradient_gb(self) -> float:
        return self.gradient_bytes / (1024**3)

    @property
    def optimizer_gb(self) -> float:
        return self.optimizer_bytes / (1024**3)

    @property
    def activation_gb(self) -> float:
        return self.activation_bytes / (1024**3)

    @property
    def fits_on_gpu(self) -> Optional[bool]:
        if self.target_gpu is None:
            return None
        return self.total_gb <= self.target_gpu.usable_vram_gb

    @property
    def gpu_utilization_pct(self) -> Optional[float]:
        if self.target_gpu is None:
            return None
        return (self.total_gb / self.target_gpu.vram_gb) * 100

    @property
    def headroom_gb(self) -> Optional[float]:
        if self.target_gpu is None:
            return None
        return self.target_gpu.usable_vram_gb - self.total_gb

    def breakdown_dict(self) -> Dict[str, float]:
        """Return memory breakdown as dict of component -> GB."""
        return {
            "Parameters": self.param_gb,
            "Gradients": self.gradient_gb,
            f"Optimizer ({self.optimizer_type})": self.optimizer_gb,
            "Activations": self.activation_gb,
            "Overhead (~15%)": self.overhead_bytes / (1024**3),
        }

    def summary(self) -> str:
        """One-line summary string."""
        status = ""
        if self.target_gpu:
            symbol = "FITS" if self.fits_on_gpu else "OOM"
            status = f" | {self.target_gpu.name} ({self.target_gpu.vram_gb}GB): {symbol}"
        return f"Peak: {self.total_gb:.2f} GB{status}"


def predict_memory(
    model: nn.Module,
    input_shape: Union[Tuple[int, ...], List[int]],
    batch_size: int = 1,
    dtype: Union[torch.dtype, str] = torch.float32,
    optimizer: str = "adam",
    training: bool = True,
    gpu: Optional[str] = None,
    find_max_batch_size: bool = False,
) -> PredictionResult:
    """
    Predict peak GPU memory for a model configuration.

    Args:
        model: PyTorch model to analyze.
        input_shape: Input shape WITHOUT batch dimension, e.g. (3, 224, 224).
        batch_size: Batch size.
        dtype: Model/input dtype ("float32", "float16", "bfloat16" or torch.dtype).
        optimizer: Optimizer type ("adam", "adamw", "sgd", "none").
        training: If True, includes gradients + optimizer states.
        gpu: Target GPU name (e.g. "a100-80gb"). None = no GPU comparison.
        find_max_batch_size: If True, binary search for max safe batch size.

    Returns:
        PredictionResult with full breakdown and recommendations.
    """
    # Resolve dtype
    if isinstance(dtype, str):
        dtype = _resolve_dtype(dtype)

    input_shape = tuple(input_shape)

    # Analyze model structure
    profile = analyze_model(model)

    # Estimate each component
    param_bytes = profile.total_param_bytes
    gradient_bytes = estimate_gradient_memory(model) if training else 0
    optimizer_bytes = estimate_optimizer_memory(model, optimizer) if training else 0
    activation_bytes = estimate_activation_memory(
        model, input_shape, batch_size, dtype, training
    )

    # Overhead
    subtotal = param_bytes + gradient_bytes + optimizer_bytes + activation_bytes
    overhead_bytes = int(subtotal * OVERHEAD_FRACTION)

    # Resolve target GPU
    target_gpu = get_gpu_spec(gpu) if gpu else None

    # Recommendations
    element_size = _dtype_element_size(dtype)
    recs = compute_recommendations(
        param_bytes=param_bytes,
        gradient_bytes=gradient_bytes,
        optimizer_bytes=optimizer_bytes,
        activation_bytes=activation_bytes,
        current_dtype_size=element_size,
        training=training,
    )

    result = PredictionResult(
        model_name=profile.model_name,
        model_profile=profile,
        batch_size=batch_size,
        input_shape=input_shape,
        dtype=dtype,
        optimizer_type=optimizer,
        training=training,
        param_bytes=param_bytes,
        gradient_bytes=gradient_bytes,
        optimizer_bytes=optimizer_bytes,
        activation_bytes=activation_bytes,
        overhead_bytes=overhead_bytes,
        target_gpu=target_gpu,
        recommendations=recs,
    )

    # Find max batch size if requested
    if find_max_batch_size and target_gpu:
        result.max_batch_size = _find_max_batch_size(
            model, input_shape, dtype, optimizer, training, target_gpu
        )

    return result


def _find_max_batch_size(
    model: nn.Module,
    input_shape: Tuple[int, ...],
    dtype: torch.dtype,
    optimizer: str,
    training: bool,
    gpu: GPUSpec,
) -> int:
    """Binary search for the maximum batch size that fits on the GPU."""
    available_bytes = int(gpu.usable_vram_gb * (1024**3))

    # Fixed costs (don't scale with batch size)
    profile = analyze_model(model)
    param_bytes = profile.total_param_bytes
    gradient_bytes = estimate_gradient_memory(model) if training else 0
    optimizer_bytes = estimate_optimizer_memory(model, optimizer) if training else 0
    fixed_bytes = param_bytes + gradient_bytes + optimizer_bytes

    # Binary search
    lo, hi = 1, 4096
    best = 1

    while lo <= hi:
        mid = (lo + hi) // 2
        act_bytes = estimate_activation_memory(model, input_shape, mid, dtype, training)
        total = fixed_bytes + act_bytes
        total_with_overhead = int(total * (1 + OVERHEAD_FRACTION))

        if total_with_overhead <= available_bytes:
            best = mid
            lo = mid + 1
        else:
            hi = mid - 1

    return best


def _resolve_dtype(dtype_str: str) -> torch.dtype:
    """Convert dtype string to torch.dtype."""
    mapping = {
        "float32": torch.float32,
        "fp32": torch.float32,
        "float16": torch.float16,
        "fp16": torch.float16,
        "half": torch.float16,
        "bfloat16": torch.bfloat16,
        "bf16": torch.bfloat16,
        "float64": torch.float64,
        "fp64": torch.float64,
    }
    return mapping.get(dtype_str.lower(), torch.float32)


def _dtype_element_size(dtype: torch.dtype) -> int:
    """Return element size in bytes for a dtype."""
    sizes = {
        torch.float32: 4,
        torch.float16: 2,
        torch.bfloat16: 2,
        torch.float64: 8,
    }
    return sizes.get(dtype, 4)
