"""
Output formatters for KV-cache memory estimates.
"""

from __future__ import annotations

import json
from typing import Optional

from .kv_cache_estimator import KVCacheResult, KVSweepResult


# ── Single result ─────────────────────────────────────────────────────────────


def format_kv_table(result: KVCacheResult) -> str:
    """Format a single KV-cache prediction as a Rich table."""
    try:
        import io

        from rich.console import Console
        from rich.panel import Panel
        from rich.table import Table

        console = Console(file=io.StringIO(), width=72)

        dtype_str = str(result.dtype).replace("torch.", "")
        attn_note = ""
        if result.kv_config.num_kv_heads < result.kv_config.num_attention_heads:
            attn_note = f" (GQA {result.kv_config.num_kv_heads} KV heads)"
        subtitle = (
            f"{result.kv_config.model_name} | "
            f"seq={result.seq_len} | batch={result.batch_size} | {dtype_str}{attn_note}"
        )

        table = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
        table.add_column("Component", style="cyan", min_width=28)
        table.add_column("Memory", justify="right", min_width=12)
        table.add_column("% Total", justify="right", min_width=8)

        total = result.total_bytes
        for name, gb in result.breakdown_dict().items():
            b = gb * (1024 ** 3)
            if b < 1024:
                continue
            pct = (b / total * 100) if total > 0 else 0
            table.add_row(name, f"{gb:.3f} GB", f"{pct:.1f}%")

        table.add_row("─" * 28, "─" * 12, "─" * 8, style="dim")
        table.add_row("TOTAL (peak)", f"{result.total_gb:.3f} GB", "100%", style="bold")

        console.print(Panel(table, title="[bold]Kitsune KV-Cache Estimate[/bold]", subtitle=subtitle))

        # Architecture details
        cfg = result.kv_config
        console.print(
            f"\n  Architecture: {cfg.num_layers} layers × "
            f"{cfg.num_kv_heads} KV heads × "
            f"{cfg.head_dim} head_dim"
        )
        console.print(f"  Max context: {cfg.max_seq_len:,} tokens")

        # GPU fit
        if result.fits is not None:
            fits = result.fits
            symbol = "[green]FITS[/green]" if fits else "[red]OOM[/red]"
            util = result.gpu_utilization_pct or 0
            console.print(
                f"\n  Target: [bold]{result.target_gpu_name}[/bold] "
                f"({result.target_gpu_vram_gb} GB) | "
                f"Usage: {util:.1f}% | {symbol}"
            )
            if result.headroom_gb is not None:
                if fits:
                    console.print(f"  Headroom: {result.headroom_gb:.2f} GB")
                else:
                    console.print(f"  [red]Over budget by: {abs(result.headroom_gb):.2f} GB[/red]")

        # KV-cache dominance note
        if result.kv_pct_of_total > 40:
            console.print(
                f"\n  [yellow]KV cache = {result.kv_pct_of_total:.0f}% of total[/yellow] — "
                "reduce seq_len, batch_size, or use fp8/int8 quantization."
            )

        return console.file.getvalue()

    except ImportError:
        return format_kv_plain(result)


def format_kv_plain(result: KVCacheResult) -> str:
    dtype_str = str(result.dtype).replace("torch.", "")
    lines = [
        "=" * 64,
        "  Kitsune KV-Cache Estimate",
        "=" * 64,
        f"  Model: {result.kv_config.model_name} | seq={result.seq_len} | "
        f"batch={result.batch_size} | {dtype_str}",
        "",
        f"  {'Component':<30} {'Memory':>10} {'%':>7}",
        "  " + "-" * 50,
    ]
    total = result.total_bytes
    for name, gb in result.breakdown_dict().items():
        b = gb * (1024 ** 3)
        if b < 1024:
            continue
        pct = (b / total * 100) if total > 0 else 0
        lines.append(f"  {name:<30} {gb:>8.3f} GB {pct:>5.1f}%")
    lines.append("  " + "-" * 50)
    lines.append(f"  {'TOTAL (peak)':<30} {result.total_gb:>8.3f} GB {'100%':>6}")

    if result.fits is not None:
        fits_str = "FITS" if result.fits else "OOM!"
        lines.append(
            f"\n  Target: {result.target_gpu_name} ({result.target_gpu_vram_gb} GB) "
            f"| {fits_str}"
        )

    lines.append("=" * 64)
    return "\n".join(lines)


def format_kv_json(result: KVCacheResult) -> str:
    dtype_str = str(result.dtype).replace("torch.", "")
    cfg = result.kv_config
    data = {
        "model": cfg.model_name,
        "config": {
            "num_layers": cfg.num_layers,
            "num_kv_heads": cfg.num_kv_heads,
            "num_attention_heads": cfg.num_attention_heads,
            "head_dim": cfg.head_dim,
            "max_seq_len": cfg.max_seq_len,
        },
        "request": {
            "seq_len": result.seq_len,
            "batch_size": result.batch_size,
            "dtype": dtype_str,
        },
        "memory": {
            "total_gb": round(result.total_gb, 3),
            "kv_cache_gb": round(result.kv_cache_gb, 3),
            "weights_gb": round(result.weight_gb, 3),
            "kv_pct_of_total": round(result.kv_pct_of_total, 1),
            "breakdown": {k: round(v, 4) for k, v in result.breakdown_dict().items()},
        },
    }
    if result.fits is not None:
        data["gpu"] = {
            "name": result.target_gpu_name,
            "vram_gb": result.target_gpu_vram_gb,
            "fits": result.fits,
            "utilization_pct": round(result.gpu_utilization_pct or 0, 1),
            "headroom_gb": round(result.headroom_gb or 0, 3),
        }
    return json.dumps(data, indent=2)


# ── Sweep ─────────────────────────────────────────────────────────────────────


def format_kv_sweep_table(sweep: KVSweepResult) -> str:
    """Format KV-cache sweep as a Rich table."""
    try:
        import io

        from rich.console import Console
        from rich.panel import Panel
        from rich.table import Table

        console = Console(file=io.StringIO(), width=80)

        dtype_str = str(sweep.dtype).replace("torch.", "")
        subtitle = (
            f"{sweep.kv_config.model_name} | batch={sweep.batch_size} | {dtype_str}"
        )
        if sweep.target_gpu_name:
            subtitle += f" | Target: {sweep.target_gpu_name}"

        table = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
        table.add_column("Context", justify="right", min_width=9)
        table.add_column("Weights", justify="right", min_width=9)
        table.add_column("KV Cache", justify="right", min_width=10)
        table.add_column("KV%", justify="right", min_width=5)
        table.add_column("Total", justify="right", min_width=10)
        if sweep.target_gpu_name:
            table.add_column("GPU%", justify="right", min_width=6)
            table.add_column("Fits?", justify="center", min_width=7)

        for r in sweep.results:
            ctx_str = f"{r.seq_len:,}"
            weights_str = f"{r.weight_gb:.2f} GB"
            kv_str = f"{r.kv_cache_gb:.3f} GB"
            kv_pct_str = f"{r.kv_pct_of_total:.0f}%"
            total_str = f"{r.total_gb:.3f} GB"

            if sweep.target_gpu_name:
                util_str = f"{r.gpu_utilization_pct:.1f}%" if r.gpu_utilization_pct is not None else "—"
                if r.fits is True:
                    fit_str = "[green]✓[/green]"
                    row_style = ""
                elif r.fits is False:
                    fit_str = "[red]✗ OOM[/red]"
                    row_style = "dim"
                else:
                    fit_str = "—"
                    row_style = ""
                table.add_row(ctx_str, weights_str, kv_str, kv_pct_str, total_str, util_str, fit_str, style=row_style)
            else:
                table.add_row(ctx_str, weights_str, kv_str, kv_pct_str, total_str)

        console.print(Panel(table, title="[bold]Kitsune KV-Cache Sweep[/bold]", subtitle=subtitle))

        max_ctx = sweep.max_fitting_seq_len
        oom_ctx = sweep.oom_threshold_seq_len
        if max_ctx:
            console.print(f"\n  Max context (fits): [bold]{max_ctx:,} tokens[/bold]")
        if oom_ctx:
            console.print(f"  OOM at: {oom_ctx:,} tokens")

        return console.file.getvalue()

    except ImportError:
        return format_kv_sweep_plain(sweep)


def format_kv_sweep_plain(sweep: KVSweepResult) -> str:
    dtype_str = str(sweep.dtype).replace("torch.", "")
    lines = [
        "=" * 72,
        "  Kitsune KV-Cache Context Sweep",
        "=" * 72,
        f"  {sweep.kv_config.model_name} | batch={sweep.batch_size} | {dtype_str}",
        "",
        f"  {'Context':>8}  {'KV Cache':>10}  {'KV%':>5}  {'Total':>10}  Status",
        "  " + "-" * 50,
    ]
    for r in sweep.results:
        status = ""
        if r.fits is True:
            status = "✓"
        elif r.fits is False:
            status = "OOM"
        lines.append(
            f"  {r.seq_len:>8,}  {r.kv_cache_gb:>9.3f}G  {r.kv_pct_of_total:>4.0f}%  "
            f"{r.total_gb:>9.3f}G  {status}"
        )
    lines.append("=" * 72)
    max_ctx = sweep.max_fitting_seq_len
    if max_ctx:
        lines.append(f"\n  Max context that fits: {max_ctx:,} tokens")
    return "\n".join(lines)


def format_kv_sweep_json(sweep: KVSweepResult) -> str:
    dtype_str = str(sweep.dtype).replace("torch.", "")
    cfg = sweep.kv_config
    data = {
        "model": cfg.model_name,
        "config": {
            "num_layers": cfg.num_layers,
            "num_kv_heads": cfg.num_kv_heads,
            "head_dim": cfg.head_dim,
            "max_seq_len": cfg.max_seq_len,
        },
        "batch_size": sweep.batch_size,
        "dtype": dtype_str,
        "max_fitting_seq_len": sweep.max_fitting_seq_len,
        "oom_threshold_seq_len": sweep.oom_threshold_seq_len,
        "sweep": [
            {
                "seq_len": r.seq_len,
                "kv_cache_gb": round(r.kv_cache_gb, 3),
                "total_gb": round(r.total_gb, 3),
                "kv_pct": round(r.kv_pct_of_total, 1),
                "fits": r.fits,
            }
            for r in sweep.results
        ],
    }
    return json.dumps(data, indent=2)
