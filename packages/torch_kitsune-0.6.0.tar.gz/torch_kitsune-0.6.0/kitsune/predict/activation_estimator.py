"""
Activation memory estimation via torch.fx symbolic tracing or meta-tensor fallback.

For training: all intermediate activations are kept for the backward pass.
For inference: only the peak set of concurrent activations matters.
"""

from __future__ import annotations

import logging
from typing import List, Optional, Tuple

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


def estimate_activation_memory(
    model: nn.Module,
    input_shape: Tuple[int, ...],
    batch_size: int = 1,
    dtype: torch.dtype = torch.float32,
    training: bool = True,
) -> int:
    """
    Estimate activation memory for a forward pass.

    Tries torch.fx symbolic tracing first, falls back to meta-tensor forward pass,
    and finally uses per-layer formulas as a last resort.

    Args:
        model: PyTorch model.
        input_shape: Shape of a single input (without batch dim), e.g. (3, 224, 224).
        batch_size: Batch size.
        dtype: Input tensor dtype.
        training: If True, all activations retained for backward. If False, only peak.

    Returns:
        Estimated activation memory in bytes.
    """
    full_shape = (batch_size, *input_shape)

    # Run all estimators and take the maximum.
    # FX tracing is best for simple feedforward networks but misses functional
    # ops inside complex modules (e.g. attention in TransformerEncoderLayer).
    # Meta-tensor hooks capture per-module outputs but miss in-module intermediates.
    # Taking the max avoids the "FX gives near-zero, we use it" failure mode.
    candidates = []

    fx_result = _estimate_via_fx(model, full_shape, dtype, training)
    if fx_result is not None:
        candidates.append(fx_result)

    meta_result = _estimate_via_meta_tensors(model, full_shape, dtype, training)
    if meta_result is not None:
        candidates.append(meta_result)

    if candidates:
        return max(candidates)

    # Last resort: per-layer formula estimation
    return _estimate_via_formulas(model, full_shape, dtype, training)


def _estimate_via_fx(
    model: nn.Module,
    input_shape: Tuple[int, ...],
    dtype: torch.dtype,
    training: bool,
) -> Optional[int]:
    """Estimate activations using torch.fx symbolic tracing + ShapeProp."""
    try:
        from torch.fx import symbolic_trace
        from torch.fx.passes.shape_prop import ShapeProp

        # Symbolic trace the model
        traced = symbolic_trace(model)

        # Create a sample input for shape propagation
        sample = torch.randn(*input_shape, dtype=dtype)
        ShapeProp(traced).propagate(sample)

        node_sizes: List[int] = []
        element_size = _dtype_size(dtype)

        for node in traced.graph.nodes:
            if node.op in ("call_function", "call_method", "call_module"):
                if hasattr(node, "meta") and "tensor_meta" in node.meta:
                    meta = node.meta["tensor_meta"]
                    if hasattr(meta, "shape"):
                        tensor_bytes = _tensor_size_bytes(meta.shape, element_size)
                        node_sizes.append(tensor_bytes)

        if not node_sizes:
            # ShapeProp didn't populate metadata — try alternative
            return _estimate_fx_by_output_shapes(traced, input_shape, dtype, training)

        if not training:
            # Inference: allocator reuses buffers; only ~2 tensors live at once.
            total_bytes = max(node_sizes) * 2 if node_sizes else 0
        else:
            total_bytes = sum(node_sizes)

        logger.debug(f"[fx] Activation memory estimate: {total_bytes / 1e9:.3f} GB")
        return total_bytes

    except Exception as e:
        logger.debug(f"[fx] Tracing failed: {e}")
        return None


def _estimate_fx_by_output_shapes(
    traced_module,
    input_shape: Tuple[int, ...],
    dtype: torch.dtype,
    training: bool,
) -> Optional[int]:
    """Walk fx graph nodes and compute output sizes from shape inference."""
    try:
        sample = torch.randn(*input_shape, dtype=dtype)

        # Run the model once to populate output shapes on nodes
        with torch.no_grad():
            traced_module(sample)

        total_bytes = 0
        element_size = _dtype_size(dtype)

        for node in traced_module.graph.nodes:
            if node.op in ("call_function", "call_method", "call_module"):
                if hasattr(node, "meta") and "val" in node.meta:
                    val = node.meta["val"]
                    if isinstance(val, torch.Tensor):
                        total_bytes += val.numel() * val.element_size()

        if total_bytes > 0:
            if not training:
                # Use max-size heuristic for inference
                val_sizes = []
                for node in traced_module.graph.nodes:
                    if node.op in ("call_function", "call_method", "call_module"):
                        if hasattr(node, "meta") and "val" in node.meta:
                            val = node.meta["val"]
                            if isinstance(val, torch.Tensor):
                                val_sizes.append(val.numel() * val.element_size())
                total_bytes = max(val_sizes) * 2 if val_sizes else total_bytes // 5
            return total_bytes

        return None
    except Exception:
        return None


def _estimate_via_meta_tensors(
    model: nn.Module,
    input_shape: Tuple[int, ...],
    dtype: torch.dtype,
    training: bool,
) -> Optional[int]:
    """
    Estimate activations by running a forward pass on the meta device.
    Meta tensors compute shapes without allocating real memory.
    """
    try:
        import copy

        # Deep copy to avoid modifying original model
        meta_model = copy.deepcopy(model)
        meta_model.to("meta")
        meta_model.eval()

        activation_sizes: List[int] = []

        def hook_fn(module, input, output):
            if isinstance(output, torch.Tensor):
                activation_sizes.append(output.numel() * _dtype_size(dtype))
            elif isinstance(output, (tuple, list)):
                for o in output:
                    if isinstance(o, torch.Tensor):
                        activation_sizes.append(o.numel() * _dtype_size(dtype))

        hooks = []
        for module in meta_model.modules():
            # Only leaf modules — containers (Sequential, ModuleList) would
            # double-count by capturing outputs already captured by children.
            if not list(module.children()):
                hooks.append(module.register_forward_hook(hook_fn))

        meta_input = torch.randn(*input_shape, dtype=dtype, device="meta")
        with torch.no_grad():
            meta_model(meta_input)

        for h in hooks:
            h.remove()

        total_bytes = sum(activation_sizes)

        if not training:
            # Inference with no_grad: only the largest active tensor matters
            # (allocator reuses buffers). Use max(sizes) × small concurrency factor.
            if activation_sizes:
                max_size = max(activation_sizes)
                # At any point only ~2-3 tensors are live (current + prev layer)
                total_bytes = max_size * 2
            else:
                total_bytes = 0

        logger.debug(f"[meta] Activation memory estimate: {total_bytes / 1e9:.3f} GB")
        return total_bytes

    except Exception as e:
        logger.debug(f"[meta] Meta-tensor estimation failed: {e}")
        return None


def _estimate_via_formulas(
    model: nn.Module,
    input_shape: Tuple[int, ...],
    dtype: torch.dtype,
    training: bool,
) -> int:
    """
    Last-resort estimation using per-layer-type formulas.
    Less accurate but works for any model.
    """
    batch_size = input_shape[0]
    element_size = _dtype_size(dtype)
    total_bytes = 0

    # Track the "current" tensor shape as we walk through layers
    # This is a rough approximation for sequential models
    current_elements = 1
    for d in input_shape:
        current_elements *= d

    for module in model.modules():
        if isinstance(module, nn.Linear):
            out_elements = batch_size * module.out_features
            total_bytes += out_elements * element_size
            current_elements = out_elements

        elif isinstance(module, (nn.Conv1d, nn.Conv2d, nn.Conv3d)):
            # Approximate output spatial dims as same as input (common with padding)
            out_channels = module.out_channels
            spatial = current_elements // (batch_size * module.in_channels) if module.in_channels > 0 else 1
            out_elements = batch_size * out_channels * spatial
            total_bytes += out_elements * element_size
            current_elements = out_elements

        elif isinstance(module, nn.MultiheadAttention):
            # Attention: Q, K, V projections + attention matrix
            embed_dim = module.embed_dim
            num_heads = module.num_heads
            # Assume seq_len is input_shape[1] if available
            seq_len = input_shape[1] if len(input_shape) > 2 else 512
            # QKV projections
            total_bytes += 3 * batch_size * seq_len * embed_dim * element_size
            # Attention scores: batch × heads × seq × seq
            total_bytes += batch_size * num_heads * seq_len * seq_len * element_size

        elif isinstance(module, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d)):
            total_bytes += current_elements * element_size

        elif isinstance(module, (nn.LayerNorm, nn.GroupNorm)):
            total_bytes += current_elements * element_size

        elif isinstance(module, (nn.ReLU, nn.GELU, nn.SiLU)):
            # Activation functions store a mask or input for backward
            total_bytes += current_elements * element_size

    if not training:
        total_bytes = int(total_bytes * 0.4)

    logger.debug(f"[formula] Activation memory estimate: {total_bytes / 1e9:.3f} GB")
    return max(total_bytes, batch_size * 1024)  # minimum 1KB per sample


def _dtype_size(dtype: torch.dtype) -> int:
    """Return element size in bytes for a dtype."""
    sizes = {
        torch.float32: 4,
        torch.float16: 2,
        torch.bfloat16: 2,
        torch.float64: 8,
        torch.int8: 1,
        torch.int16: 2,
        torch.int32: 4,
        torch.int64: 8,
    }
    return sizes.get(dtype, 4)


def _tensor_size_bytes(shape, element_size: int) -> int:
    """Compute tensor size in bytes from shape and element size."""
    numel = 1
    for dim in shape:
        numel *= dim
    return numel * element_size
