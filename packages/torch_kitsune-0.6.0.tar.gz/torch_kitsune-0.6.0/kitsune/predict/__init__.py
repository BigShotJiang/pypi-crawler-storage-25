"""
kitsune.predict — GPU Memory Prediction for PyTorch Models

"Never OOM again." Predict peak GPU memory, max batch size, and optimal
GPU before you run.

Usage:
    from kitsune.predict import predict_memory

    result = predict_memory(model, input_shape=(3, 224, 224), batch_size=32)
    print(result)
    # Peak: 3.71 GB | Target: T4 (16 GB) | Status: FITS

CLI:
    $ kitsune predict model.py:ResNet50 --batch-size 32 --gpu t4
"""

from .estimator import PredictionResult, predict_memory
from .sweep import SweepResult, sweep_batch_sizes
from .cost_calculator import PlanResult, plan_gpu
from .lora_estimator import LoRAConfig, LoRAPrediction, estimate_lora_memory
from .kv_cache_estimator import KVCacheConfig, KVCacheResult, KVSweepResult, estimate_kv_cache, sweep_kv_seq_lens

__all__ = [
    "predict_memory", "PredictionResult",
    "sweep_batch_sizes", "SweepResult",
    "plan_gpu", "PlanResult",
    "estimate_lora_memory", "LoRAConfig", "LoRAPrediction",
    "estimate_kv_cache", "sweep_kv_seq_lens", "KVCacheConfig", "KVCacheResult", "KVSweepResult",
]


def predict_hf_memory(model_id: str, **kwargs):
    """Predict GPU memory for a HuggingFace model. Requires `pip install transformers`."""
    from .hf_integration import predict_hf_memory as _impl
    return _impl(model_id, **kwargs)


def sweep_hf_batch_sizes(model_id: str, **kwargs):
    """Sweep batch sizes for a HuggingFace model. Requires `pip install transformers`."""
    from .hf_integration import sweep_hf_batch_sizes as _impl
    return _impl(model_id, **kwargs)


__all__ += ["predict_hf_memory", "sweep_hf_batch_sizes"]
