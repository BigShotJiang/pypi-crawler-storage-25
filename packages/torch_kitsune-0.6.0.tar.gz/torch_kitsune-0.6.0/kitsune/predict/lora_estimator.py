"""
LoRA / QLoRA fine-tuning memory estimator.

Estimates the *delta* memory from adding LoRA adapters to a frozen base model,
and the total memory for LoRA / QLoRA training configurations.

LoRA recap
──────────
  • Base model weights are frozen — no gradients, no optimizer states for them.
  • LoRA adds two low-rank matrices A (r×d_in) and B (d_out×r) per targeted layer.
    Total new params per layer = r*(d_in + d_out) instead of d_in*d_out.
  • Only adapter params need gradients + optimizer states.

QLoRA adds
──────────
  • Base model is quantized to 4-bit (bitsandbytes NF4) — ~0.5 bytes/param.
  • LoRA adapters remain in fp32/bf16.
  • Quantization overhead (lookup tables, block stats): ~20% of base 4-bit weight size.

Formulas
────────
  base_lora_bytes    = r * (d_in + d_out) * dtype_size  per layer
  adapter_param_bytes  = sum over all targeted layers
  adapter_grad_bytes   = adapter_param_bytes  (same dtype)
  adapter_opt_bytes    = adapter_param_bytes * optimizer_mult * (fp32_size / dtype_size)
  frozen_base_bytes    = base_param_bytes     (no grad, no opt state)
  qlora_base_bytes     = base_param_bytes * (4/32)  + quantization_overhead

  total_lora  = frozen_base + adapter_params + adapter_grads + adapter_opt + activations + overhead
  total_qlora = qlora_base  + adapter_params + adapter_grads + adapter_opt + activations + overhead
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn


# ── Defaults ─────────────────────────────────────────────────────────────────

DEFAULT_LORA_RANK = 16
# Covers LLaMA-style (q_proj/v_proj) and BERT-style (query/value) naming
DEFAULT_TARGET_MODULES = ("q_proj", "v_proj", "query", "value")
QLORA_QUANT_BITS = 4
QLORA_OVERHEAD_FRACTION = 0.20  # NF4 block stats + lookup tables


@dataclass
class LoRAConfig:
    """Configuration for a LoRA / QLoRA run."""

    rank: int = DEFAULT_LORA_RANK
    # Which module name substrings to target (matched against layer names)
    target_modules: Tuple[str, ...] = DEFAULT_TARGET_MODULES
    lora_alpha: float = 16.0          # scaling factor (does not affect memory)
    lora_dropout: float = 0.0         # dropout (does not affect memory meaningfully)
    use_qlora: bool = False           # quantize base model to 4-bit
    optimizer: str = "adamw"


@dataclass
class LoRAPrediction:
    """Memory breakdown for a LoRA / QLoRA fine-tuning configuration."""

    # Base model
    base_param_bytes: int             # full-precision params of frozen base
    quantized_base_bytes: int         # bytes after quantization (= base if not QLoRA)

    # Adapters (trainable)
    adapter_param_bytes: int
    adapter_grad_bytes: int
    adapter_opt_bytes: int

    # Activations + overhead
    activation_bytes: int
    overhead_bytes: int

    # Config
    config: LoRAConfig
    num_adapter_params: int           # count of trainable params
    num_targeted_layers: int          # how many layers got adapters
    targeted_layer_names: List[str] = field(default_factory=list)

    @property
    def total_bytes(self) -> int:
        return (
            self.quantized_base_bytes
            + self.adapter_param_bytes
            + self.adapter_grad_bytes
            + self.adapter_opt_bytes
            + self.activation_bytes
            + self.overhead_bytes
        )

    @property
    def total_gb(self) -> float:
        return self.total_bytes / (1024 ** 3)

    @property
    def base_gb(self) -> float:
        return self.quantized_base_bytes / (1024 ** 3)

    @property
    def adapter_gb(self) -> float:
        return (
            self.adapter_param_bytes
            + self.adapter_grad_bytes
            + self.adapter_opt_bytes
        ) / (1024 ** 3)

    @property
    def savings_vs_full_finetune_gb(self) -> float:
        """How much less memory vs. full fine-tuning (base + grads + optimizer)."""
        full_grad = self.base_param_bytes
        full_opt = self.base_param_bytes * 2  # Adam = 2× fp32
        full_total = self.base_param_bytes + full_grad + full_opt
        return (full_total - self.quantized_base_bytes - self.adapter_gb * (1024 ** 3)) / (1024 ** 3)

    def breakdown_dict(self) -> Dict[str, float]:
        return {
            "Base model (frozen)": self.quantized_base_bytes / (1024 ** 3),
            "LoRA adapters": self.adapter_param_bytes / (1024 ** 3),
            "Adapter gradients": self.adapter_grad_bytes / (1024 ** 3),
            f"Adapter optimizer ({self.config.optimizer})": self.adapter_opt_bytes / (1024 ** 3),
            "Activations": self.activation_bytes / (1024 ** 3),
            "Overhead (~15%)": self.overhead_bytes / (1024 ** 3),
        }

    def summary(self) -> str:
        label = "QLoRA" if self.config.lora_alpha and self.config.use_qlora else "LoRA"
        return (
            f"{label} r={self.config.rank}: {self.total_gb:.2f} GB total | "
            f"{self.num_adapter_params:,} trainable params "
            f"({self.num_targeted_layers} layers)"
        )


def estimate_lora_memory(
    model: nn.Module,
    input_shape: Union[Tuple[int, ...], List[int]],
    batch_size: int = 1,
    dtype: Union[torch.dtype, str] = torch.float32,
    config: Optional[LoRAConfig] = None,
    activation_bytes: Optional[int] = None,
) -> LoRAPrediction:
    """
    Estimate memory for LoRA or QLoRA fine-tuning.

    Args:
        model: The base model (full precision, not yet quantized).
        input_shape: Input shape WITHOUT batch dimension.
        batch_size: Batch size.
        dtype: Dtype for adapters (base model quantized if use_qlora=True).
        config: LoRA configuration (rank, target_modules, use_qlora, etc.).
        activation_bytes: Pre-computed activation bytes (to avoid re-tracing).
                          If None, computed via the standard activation estimator.

    Returns:
        LoRAPrediction with full memory breakdown.
    """
    if config is None:
        config = LoRAConfig()

    if isinstance(dtype, str):
        dtype = _resolve_dtype(dtype)

    input_shape = tuple(input_shape)
    dtype_size = _element_size(dtype)  # bytes per adapter param element

    # ── Base model params ────────────────────────────────────────────────────
    base_param_bytes = sum(p.numel() * p.element_size() for p in model.parameters())

    # ── Quantized base (QLoRA: 4-bit NF4) ───────────────────────────────────
    if config.use_qlora:
        bits_per_param = QLORA_QUANT_BITS
        quantized_base_bytes = int(
            base_param_bytes * bits_per_param / 32  # weight storage
            * (1 + QLORA_OVERHEAD_FRACTION)          # + quantization metadata
        )
    else:
        quantized_base_bytes = base_param_bytes

    # ── Identify targeted layers ─────────────────────────────────────────────
    targeted_layers: List[Tuple[str, nn.Module]] = []
    for name, module in model.named_modules():
        if isinstance(module, nn.Linear):
            if any(t in name for t in config.target_modules):
                targeted_layers.append((name, module))

    # ── Adapter param count ──────────────────────────────────────────────────
    # Each Linear(d_in, d_out) gets: A (r, d_in) + B (d_out, r)
    adapter_num_params = 0
    for _name, module in targeted_layers:
        d_out, d_in = module.weight.shape  # weight is (out_features, in_features)
        adapter_num_params += config.rank * (d_in + d_out)

    adapter_param_bytes = adapter_num_params * dtype_size

    # ── Adapter gradients (same dtype as adapters) ───────────────────────────
    adapter_grad_bytes = adapter_param_bytes

    # ── Adapter optimizer states (always fp32 for numerical stability) ───────
    fp32_adapter_bytes = adapter_num_params * 4  # fp32
    opt_mult = {"adam": 2, "adamw": 2, "sgd": 0, "none": 0}.get(config.optimizer.lower(), 2)
    adapter_opt_bytes = fp32_adapter_bytes * opt_mult

    # ── Activations (standard estimator, full model forward) ─────────────────
    if activation_bytes is None:
        from .activation_estimator import estimate_activation_memory
        activation_bytes = estimate_activation_memory(
            model, input_shape, batch_size, dtype, training=True
        )

    # ── Overhead ─────────────────────────────────────────────────────────────
    subtotal = (
        quantized_base_bytes
        + adapter_param_bytes
        + adapter_grad_bytes
        + adapter_opt_bytes
        + activation_bytes
    )
    overhead_bytes = int(subtotal * 0.15)

    return LoRAPrediction(
        base_param_bytes=base_param_bytes,
        quantized_base_bytes=quantized_base_bytes,
        adapter_param_bytes=adapter_param_bytes,
        adapter_grad_bytes=adapter_grad_bytes,
        adapter_opt_bytes=adapter_opt_bytes,
        activation_bytes=activation_bytes,
        overhead_bytes=overhead_bytes,
        config=config,
        num_adapter_params=adapter_num_params,
        num_targeted_layers=len(targeted_layers),
        targeted_layer_names=[n for n, _ in targeted_layers],
    )


def _element_size(dtype: torch.dtype) -> int:
    return torch.empty(0, dtype=dtype).element_size()


def _resolve_dtype(dtype_str: str) -> torch.dtype:
    mapping = {
        "float32": torch.float32,
        "fp32": torch.float32,
        "float16": torch.float16,
        "fp16": torch.float16,
        "bfloat16": torch.bfloat16,
        "bf16": torch.bfloat16,
    }
    return mapping.get(dtype_str.lower(), torch.float32)
