"""
GPU specifications database for memory prediction.

Contains VRAM, bandwidth, compute specs, and cloud pricing for common GPUs.

Pricing notes
─────────────
• price_per_hr_usd is the *lowest commonly available* on-demand rate across
  major providers (AWS, GCP, Azure, Lambda Labs, RunPod) as of mid-2025.
• spot_price_per_hr_usd is the approximate spot/preemptible price (Vast.ai /
  RunPod spot / GCP preemptible).  Spot prices fluctuate; treat as a floor.
• Consumer GPUs (RTX series, Apple Silicon) carry None — they are not rented
  as bare-metal cloud GPUs.  Use them for local cost estimates only.
• Prices change.  Treat these as planning estimates, not quotes.

Sources: Lambda Labs, RunPod, Vast.ai, AWS, GCP pricing pages (2025-05).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass(frozen=True)
class GPUSpec:
    """Specifications for a GPU."""

    name: str
    vram_gb: float
    memory_bandwidth_gbps: float
    fp16_tflops: float
    fp32_tflops: float
    architecture: str
    # Lowest on-demand $/hr available across major providers (None = not cloud-rented)
    price_per_hr_usd: Optional[float] = None
    # Approximate spot/preemptible $/hr — typically 2-4× cheaper than on-demand
    spot_price_per_hr_usd: Optional[float] = None

    @property
    def vram_bytes(self) -> int:
        return int(self.vram_gb * (1024**3))

    @property
    def usable_vram_gb(self) -> float:
        """Usable VRAM after CUDA/driver overhead (~200-500MB)."""
        overhead_gb = 0.5 if self.vram_gb >= 16 else 0.3
        return self.vram_gb - overhead_gb


# ─── GPU Database ────────────────────────────────────────────────────────────

GPU_DATABASE: Dict[str, GPUSpec] = {
    # ── NVIDIA Data Center ────────────────────────────────────────────────────
    "t4": GPUSpec(
        name="Tesla T4",
        vram_gb=16,
        memory_bandwidth_gbps=320,
        fp16_tflops=65,
        fp32_tflops=8.1,
        architecture="turing",
        price_per_hr_usd=0.35,        # GCP / Lambda Labs
        spot_price_per_hr_usd=0.11,   # GCP preemptible
    ),
    "a10g": GPUSpec(
        name="NVIDIA A10G",
        vram_gb=24,
        memory_bandwidth_gbps=600,
        fp16_tflops=125,
        fp32_tflops=31.2,
        architecture="ampere",
        price_per_hr_usd=0.76,        # AWS g5
        spot_price_per_hr_usd=0.23,   # AWS spot ~30%
    ),
    "a100-40gb": GPUSpec(
        name="NVIDIA A100 40GB",
        vram_gb=40,
        memory_bandwidth_gbps=1555,
        fp16_tflops=312,
        fp32_tflops=156,
        architecture="ampere",
        price_per_hr_usd=1.29,        # Lambda Labs
        spot_price_per_hr_usd=0.45,   # RunPod spot
    ),
    "a100-80gb": GPUSpec(
        name="NVIDIA A100 80GB",
        vram_gb=80,
        memory_bandwidth_gbps=2039,
        fp16_tflops=312,
        fp32_tflops=156,
        architecture="ampere",
        price_per_hr_usd=1.99,        # Lambda Labs / RunPod
        spot_price_per_hr_usd=0.69,   # RunPod spot
    ),
    "h100-sxm": GPUSpec(
        name="NVIDIA H100 SXM",
        vram_gb=80,
        memory_bandwidth_gbps=3350,
        fp16_tflops=990,
        fp32_tflops=495,
        architecture="hopper",
        price_per_hr_usd=3.29,        # Lambda Labs
        spot_price_per_hr_usd=1.19,   # RunPod spot
    ),
    "h100-pcie": GPUSpec(
        name="NVIDIA H100 PCIe",
        vram_gb=80,
        memory_bandwidth_gbps=2039,
        fp16_tflops=756,
        fp32_tflops=378,
        architecture="hopper",
        price_per_hr_usd=2.49,        # RunPod
        spot_price_per_hr_usd=0.99,   # RunPod spot
    ),
    "l4": GPUSpec(
        name="NVIDIA L4",
        vram_gb=24,
        memory_bandwidth_gbps=300,
        fp16_tflops=121,
        fp32_tflops=30.3,
        architecture="ada_lovelace",
        price_per_hr_usd=0.54,        # GCP
        spot_price_per_hr_usd=0.16,   # GCP preemptible
    ),
    "l40s": GPUSpec(
        name="NVIDIA L40S",
        vram_gb=48,
        memory_bandwidth_gbps=864,
        fp16_tflops=366,
        fp32_tflops=91.6,
        architecture="ada_lovelace",
        price_per_hr_usd=1.35,        # Lambda Labs / RunPod
        spot_price_per_hr_usd=0.49,   # RunPod spot
    ),
    # ── NVIDIA Data Center (additional) ──────────────────────────────────────
    "v100-16gb": GPUSpec(
        name="NVIDIA V100 16GB",
        vram_gb=16,
        memory_bandwidth_gbps=900,
        fp16_tflops=125,
        fp32_tflops=14,
        architecture="volta",
        price_per_hr_usd=0.55,        # AWS p3 / GCP
        spot_price_per_hr_usd=0.19,   # GCP preemptible
    ),
    "v100-32gb": GPUSpec(
        name="NVIDIA V100 32GB",
        vram_gb=32,
        memory_bandwidth_gbps=900,
        fp16_tflops=125,
        fp32_tflops=14,
        architecture="volta",
        price_per_hr_usd=0.80,        # AWS p3dn
        spot_price_per_hr_usd=0.28,   # AWS spot ~35%
    ),
    "a30": GPUSpec(
        name="NVIDIA A30",
        vram_gb=24,
        memory_bandwidth_gbps=933,
        fp16_tflops=165,
        fp32_tflops=10.3,
        architecture="ampere",
        price_per_hr_usd=0.60,        # CoreWeave
        spot_price_per_hr_usd=0.22,   # CoreWeave spot
    ),
    "a6000": GPUSpec(
        name="NVIDIA RTX A6000",
        vram_gb=48,
        memory_bandwidth_gbps=768,
        fp16_tflops=154,
        fp32_tflops=38.7,
        architecture="ampere",
        price_per_hr_usd=0.80,        # Lambda Labs
        spot_price_per_hr_usd=0.28,   # Vast.ai
    ),
    "h200": GPUSpec(
        name="NVIDIA H200 SXM",
        vram_gb=141,
        memory_bandwidth_gbps=4800,
        fp16_tflops=1979,
        fp32_tflops=989,
        architecture="hopper",
        price_per_hr_usd=4.99,        # Lambda Labs (2025 est.)
        spot_price_per_hr_usd=2.49,   # est. ~50%
    ),
    # ── Consumer GPUs (available via RunPod / Vast.ai) ────────────────────────
    "rtx-3090": GPUSpec(
        name="NVIDIA RTX 3090",
        vram_gb=24,
        memory_bandwidth_gbps=936,
        fp16_tflops=71,
        fp32_tflops=35.6,
        architecture="ampere",
        price_per_hr_usd=0.44,        # RunPod
        spot_price_per_hr_usd=0.16,   # Vast.ai
    ),
    "rtx-4090": GPUSpec(
        name="NVIDIA RTX 4090",
        vram_gb=24,
        memory_bandwidth_gbps=1008,
        fp16_tflops=165,
        fp32_tflops=82.6,
        architecture="ada_lovelace",
        price_per_hr_usd=0.74,        # RunPod
        spot_price_per_hr_usd=0.28,   # Vast.ai
    ),
    "rtx-4080": GPUSpec(
        name="NVIDIA RTX 4080",
        vram_gb=16,
        memory_bandwidth_gbps=717,
        fp16_tflops=97,
        fp32_tflops=48.7,
        architecture="ada_lovelace",
        price_per_hr_usd=0.55,        # RunPod
        spot_price_per_hr_usd=0.19,   # Vast.ai
    ),
    "rtx-3080": GPUSpec(
        name="NVIDIA RTX 3080",
        vram_gb=10,
        memory_bandwidth_gbps=760,
        fp16_tflops=47.4,
        fp32_tflops=29.8,
        architecture="ampere",
        price_per_hr_usd=0.30,        # RunPod / Vast.ai
        spot_price_per_hr_usd=0.11,   # Vast.ai
    ),
    "rtx-4070": GPUSpec(
        name="NVIDIA RTX 4070",
        vram_gb=12,
        memory_bandwidth_gbps=504,
        fp16_tflops=58.5,
        fp32_tflops=29.1,
        architecture="ada_lovelace",
        price_per_hr_usd=0.35,        # Vast.ai
        spot_price_per_hr_usd=0.12,   # Vast.ai
    ),
    "rtx-4070-ti": GPUSpec(
        name="NVIDIA RTX 4070 Ti",
        vram_gb=12,
        memory_bandwidth_gbps=672,
        fp16_tflops=80.1,
        fp32_tflops=40.1,
        architecture="ada_lovelace",
        price_per_hr_usd=0.40,        # Vast.ai
        spot_price_per_hr_usd=0.14,   # Vast.ai
    ),
    # ── Apple Silicon (unified memory — local only, not cloud-rented) ─────────
    "m1": GPUSpec(
        name="Apple M1",
        vram_gb=16,
        memory_bandwidth_gbps=68,
        fp16_tflops=5.5,
        fp32_tflops=2.6,
        architecture="apple_silicon",
        price_per_hr_usd=None,
        spot_price_per_hr_usd=None,
    ),
    "m1-pro": GPUSpec(
        name="Apple M1 Pro",
        vram_gb=32,
        memory_bandwidth_gbps=200,
        fp16_tflops=11,
        fp32_tflops=5.3,
        architecture="apple_silicon",
        price_per_hr_usd=None,
        spot_price_per_hr_usd=None,
    ),
    "m2-max": GPUSpec(
        name="Apple M2 Max",
        vram_gb=96,
        memory_bandwidth_gbps=400,
        fp16_tflops=27,
        fp32_tflops=13.5,
        architecture="apple_silicon",
        price_per_hr_usd=None,
        spot_price_per_hr_usd=None,
    ),
    "m3-max": GPUSpec(
        name="Apple M3 Max",
        vram_gb=128,
        memory_bandwidth_gbps=400,
        fp16_tflops=35,
        fp32_tflops=17.5,
        architecture="apple_silicon",
        price_per_hr_usd=None,
        spot_price_per_hr_usd=None,
    ),
    "m4-max": GPUSpec(
        name="Apple M4 Max",
        vram_gb=128,
        memory_bandwidth_gbps=546,
        fp16_tflops=42,
        fp32_tflops=21,
        architecture="apple_silicon",
        price_per_hr_usd=None,
        spot_price_per_hr_usd=None,
    ),
}

# Aliases for convenience
GPU_DATABASE["a100"] = GPU_DATABASE["a100-80gb"]
GPU_DATABASE["h100"] = GPU_DATABASE["h100-sxm"]


def get_gpu_spec(gpu_name: str) -> Optional[GPUSpec]:
    """
    Look up GPU specs by name. Case-insensitive, supports partial matching.

    Args:
        gpu_name: GPU identifier (e.g. "a100-80gb", "rtx-4090", "t4").

    Returns:
        GPUSpec if found, None otherwise.
    """
    if not gpu_name or not gpu_name.strip():
        return None

    key = gpu_name.lower().strip().replace(" ", "-")

    # Direct match
    if key in GPU_DATABASE:
        return GPU_DATABASE[key]

    # Try without dashes/spaces (handles "a10080gb", "rtx4090")
    normalized = key.replace("-", "")
    for db_key, spec in GPU_DATABASE.items():
        if db_key.replace("-", "") == normalized:
            return spec

    # Fuzzy: normalize both sides before substring check
    key_flat = key.replace("-", "").replace(" ", "")
    for db_key, spec in GPU_DATABASE.items():
        name_flat = spec.name.lower().replace(" ", "").replace("-", "")
        db_flat   = db_key.replace("-", "")
        if key_flat and (key_flat in db_flat or key_flat in name_flat):
            return spec

    return None


def list_gpus() -> List[GPUSpec]:
    """Return all GPUs in the database, sorted by VRAM."""
    seen = set()
    unique = []
    for spec in GPU_DATABASE.values():
        if spec.name not in seen:
            seen.add(spec.name)
            unique.append(spec)
    return sorted(unique, key=lambda g: g.vram_gb)


def find_cheapest_gpu(required_vram_gb: float) -> Optional[GPUSpec]:
    """
    Find the GPU with the least VRAM that still fits the workload.
    (Cost approximation: less VRAM ≈ cheaper.)

    Args:
        required_vram_gb: Minimum usable VRAM needed.

    Returns:
        Cheapest-fitting GPUSpec, or None if nothing fits.
    """
    candidates = [
        spec for spec in list_gpus()
        if spec.usable_vram_gb >= required_vram_gb
    ]
    return candidates[0] if candidates else None
