"""
CLI entry point for kitsune predict.

Usage:
    kitsune predict model.py:ModelClass --batch-size 32 --gpu a100-80gb
    kitsune predict model.py:ModelClass --max-batch-size --gpu t4
    kitsune list-gpus
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import Optional

import click


@click.group()
@click.version_option(package_name="torch-kitsune")
def main():
    """Kitsune — GPU Memory Prediction for PyTorch Models."""
    pass


@main.command()
@click.argument("model_spec", required=False, default=None)
@click.option("--hf", "hf_model_id", default=None, help='HuggingFace model ID, e.g. "bert-base-uncased". Alternative to MODEL_SPEC.')
@click.option("--seq-len", default=None, type=int, help="Sequence length override for HuggingFace text models.")
@click.option("--batch-size", "-b", default=1, help="Batch size to predict for.")
@click.option("--input-shape", "-s", default=None, help='Input shape without batch dim, e.g. "3,224,224". Auto-inferred for --hf models.')
@click.option("--dtype", "-d", default="float32", help="Model dtype: float32, float16, bfloat16.")
@click.option("--optimizer", "-o", default="adam", help="Optimizer: adam, adamw, sgd, none.")
@click.option("--training/--inference", default=True, help="Training or inference mode.")
@click.option("--gpu", "-g", default="auto", help='Target GPU key, e.g. "t4", "a100-80gb". Defaults to auto-detect local GPU.')
@click.option("--max-batch-size", is_flag=True, help="Find maximum safe batch size for target GPU.")
@click.option("--sweep", "do_sweep", is_flag=True, help="Show memory across a range of batch sizes.")
@click.option("--sweep-sizes", default=None, help='Comma-separated batch sizes for sweep, e.g. "1,2,4,8,16,32,64,128".')
@click.option("--format", "output_format", default="table", type=click.Choice(["table", "json", "plain"]))
@click.option("--verbose", "-v", is_flag=True, help="Show per-layer breakdown.")
@click.option("--ci", is_flag=True, help="CI mode: suppress output, exit 1 if over budget.")
@click.option("--budget", default=None, help='Memory budget for CI mode, e.g. "16GB", "8192MB". Exit 1 if prediction exceeds this.')
def predict(
    model_spec: Optional[str],
    hf_model_id: Optional[str],
    seq_len: Optional[int],
    batch_size: int,
    input_shape: Optional[str],
    dtype: str,
    optimizer: str,
    training: bool,
    gpu: Optional[str],
    max_batch_size: bool,
    do_sweep: bool,
    sweep_sizes: Optional[str],
    output_format: str,
    verbose: bool,
    ci: bool,
    budget: Optional[str],
):
    """Predict GPU memory usage for a PyTorch model.

    MODEL_SPEC: Path to model file and class name, e.g. "model.py:ResNet50"

    Or use --hf to load directly from HuggingFace:

        kitsune predict --hf bert-base-uncased --batch-size 32 --gpu t4

    CI/CD usage (exits 1 if over budget, 0 if fits):

        kitsune predict --hf bert-base-uncased --budget 8GB --ci
    """
    import torch

    from .estimator import predict_memory
    from .formatters import format_json, format_plain, format_table
    from .sweep import format_sweep_json, format_sweep_plain, format_sweep_table, sweep_batch_sizes

    # Parse --budget flag
    budget_gb: Optional[float] = None
    if budget:
        budget_gb = _parse_memory_budget(budget)
        if budget_gb is None:
            click.echo(f"Error: Invalid --budget '{budget}'. Use e.g. '16GB', '8192MB', '0.5TB'.", err=True)
            sys.exit(1)

    # Validate: need either MODEL_SPEC or --hf
    if not model_spec and not hf_model_id:
        click.echo("Error: Provide MODEL_SPEC (e.g. model.py:MyModel) or --hf <model-id>.", err=True)
        sys.exit(1)
    if model_spec and hf_model_id:
        click.echo("Error: Provide either MODEL_SPEC or --hf, not both.", err=True)
        sys.exit(1)

    # Resolve GPU: auto-detect local hardware if not specified
    resolved_gpu = _resolve_gpu(gpu)

    # ── HuggingFace path ──────────────────────────────────────────────────────
    if hf_model_id:
        try:
            from .hf_integration import load_hf_model, sweep_hf_batch_sizes, predict_hf_memory
        except ImportError as e:
            click.echo(f"Error: {e}", err=True)
            sys.exit(1)

        if do_sweep:
            batch_sizes_list = None
            if sweep_sizes:
                try:
                    batch_sizes_list = [int(x.strip()) for x in sweep_sizes.split(",")]
                except ValueError:
                    click.echo(f"Error: Invalid --sweep-sizes '{sweep_sizes}'.", err=True)
                    sys.exit(1)
            try:
                sweep = sweep_hf_batch_sizes(
                    model_id=hf_model_id,
                    seq_len=seq_len,
                    batch_sizes=batch_sizes_list,
                    dtype=dtype,
                    optimizer=optimizer,
                    training=training,
                    gpu=resolved_gpu,
                )
            except Exception as e:
                click.echo(f"Error loading HuggingFace model '{hf_model_id}': {e}", err=True)
                sys.exit(1)

            if output_format == "json":
                click.echo(format_sweep_json(sweep))
            elif output_format == "plain":
                click.echo(format_sweep_plain(sweep))
            else:
                click.echo(format_sweep_table(sweep))
            return

        try:
            result = predict_hf_memory(
                model_id=hf_model_id,
                batch_size=batch_size,
                seq_len=seq_len,
                dtype=dtype,
                optimizer=optimizer,
                training=training,
                gpu=resolved_gpu,
                find_max_batch_size=max_batch_size,
            )
        except Exception as e:
            click.echo(f"Error loading HuggingFace model '{hf_model_id}': {e}", err=True)
            sys.exit(1)

        if not ci:
            if output_format == "json":
                click.echo(format_json(result))
            elif output_format == "plain":
                click.echo(format_plain(result, verbose=verbose))
            else:
                click.echo(format_table(result, verbose=verbose))

        _ci_exit(result.total_gb, budget_gb, ci, result.target_gpu, result.fits_on_gpu)
        return

    # ── Local model path ──────────────────────────────────────────────────────
    if not input_shape:
        click.echo("Error: --input-shape is required for local models.", err=True)
        sys.exit(1)

    # Parse input shape
    try:
        shape = tuple(int(x.strip()) for x in input_shape.split(","))
    except ValueError:
        click.echo(f"Error: Invalid input shape '{input_shape}'. Use comma-separated ints, e.g. '3,224,224'", err=True)
        sys.exit(1)

    # Load model
    model = _load_model(model_spec)
    if model is None:
        sys.exit(1)

    # ── Sweep mode ────────────────────────────────────────────────────────────
    if do_sweep:
        batch_sizes = None
        if sweep_sizes:
            try:
                batch_sizes = [int(x.strip()) for x in sweep_sizes.split(",")]
            except ValueError:
                click.echo(f"Error: Invalid --sweep-sizes '{sweep_sizes}'. Use comma-separated ints.", err=True)
                sys.exit(1)

        sweep = sweep_batch_sizes(
            model=model,
            input_shape=shape,
            batch_sizes=batch_sizes,
            dtype=dtype,
            optimizer=optimizer,
            training=training,
            gpu=resolved_gpu,
        )

        if output_format == "json":
            click.echo(format_sweep_json(sweep))
        elif output_format == "plain":
            click.echo(format_sweep_plain(sweep))
        else:
            click.echo(format_sweep_table(sweep))

        # Exit non-zero if NO batch size fits
        if sweep.target_gpu and sweep.max_fitting_batch_size is None:
            sys.exit(1)
        return

    # ── Single batch prediction ───────────────────────────────────────────────
    result = predict_memory(
        model=model,
        input_shape=shape,
        batch_size=batch_size,
        dtype=dtype,
        optimizer=optimizer,
        training=training,
        gpu=resolved_gpu,
        find_max_batch_size=max_batch_size,
    )

    # Output
    if not ci:
        if output_format == "json":
            click.echo(format_json(result))
        elif output_format == "plain":
            click.echo(format_plain(result, verbose=verbose))
        else:
            click.echo(format_table(result, verbose=verbose))

    _ci_exit(result.total_gb, budget_gb, ci, result.target_gpu, result.fits_on_gpu)


@main.command("kv-cache")
@click.option("--hf", "hf_model_id", default=None, help="HuggingFace model ID (recommended — no weights downloaded).")
@click.option("--seq-len", "-s", default=None, type=int, help="Context length in tokens.")
@click.option("--batch-size", "-b", default=1, type=int, help="Number of concurrent inference requests.")
@click.option("--dtype", "-d", default="float16", help="KV dtype: float16 (default), bfloat16, float32.")
@click.option("--gpu", "-g", default=None, help='Target GPU key, e.g. "a100-80gb".')
@click.option("--sweep", "do_sweep", is_flag=True, help="Sweep context lengths to find the OOM boundary.")
@click.option("--sweep-sizes", default=None, help="Comma-separated context lengths, e.g. \"512,1024,2048,4096\".")
@click.option("--format", "output_format", default="table", type=click.Choice(["table", "json", "plain"]))
def kv_cache_cmd(
    hf_model_id,
    seq_len,
    batch_size,
    dtype,
    gpu,
    do_sweep,
    sweep_sizes,
    output_format,
):
    """Estimate KV-cache memory for LLM inference.

    KV-cache stores past keys and values — the dominant memory cost for
    long-context generation and high-throughput inference servers.

    Examples:

        kitsune kv-cache --hf bert-base-uncased --seq-len 512 --gpu t4

        kitsune kv-cache --hf gpt2 --sweep --gpu a100-40gb

        kitsune kv-cache --hf gpt2 --seq-len 1024 --batch-size 8 --gpu a100-80gb
    """
    from .kv_cache_estimator import estimate_kv_cache, sweep_kv_seq_lens
    from .kv_formatters import (
        format_kv_json,
        format_kv_plain,
        format_kv_sweep_json,
        format_kv_sweep_plain,
        format_kv_sweep_table,
        format_kv_table,
    )

    if not hf_model_id:
        click.echo("Error: --hf <model-id> is required for kv-cache.", err=True)
        sys.exit(1)

    try:
        from .hf_integration import load_hf_model
    except ImportError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    try:
        model, default_shape = load_hf_model(hf_model_id)
    except Exception as e:
        click.echo(f"Error loading HuggingFace model '{hf_model_id}': {e}", err=True)
        sys.exit(1)

    resolved_gpu = _resolve_gpu(gpu) if gpu else None

    if do_sweep:
        sweep_lens = None
        if sweep_sizes:
            try:
                sweep_lens = [int(x.strip()) for x in sweep_sizes.split(",")]
            except ValueError:
                click.echo(f"Error: Invalid --sweep-sizes '{sweep_sizes}'.", err=True)
                sys.exit(1)

        sweep = sweep_kv_seq_lens(
            model,
            seq_lens=sweep_lens,
            batch_size=batch_size,
            dtype=dtype,
            gpu=resolved_gpu,
        )

        if output_format == "json":
            click.echo(format_kv_sweep_json(sweep))
        elif output_format == "plain":
            click.echo(format_kv_sweep_plain(sweep))
        else:
            click.echo(format_kv_sweep_table(sweep))
        return

    # Single prediction
    if seq_len is None:
        # Default to the model's max or 512
        from .kv_cache_estimator import KVCacheConfig
        cfg = KVCacheConfig.from_hf_config(model.config)
        seq_len = min(cfg.max_seq_len, 2048)

    result = estimate_kv_cache(model, seq_len=seq_len, batch_size=batch_size, dtype=dtype, gpu=resolved_gpu)

    if output_format == "json":
        click.echo(format_kv_json(result))
    elif output_format == "plain":
        click.echo(format_kv_plain(result))
    else:
        click.echo(format_kv_table(result))

    if result.fits is False:
        sys.exit(1)


@main.command("lora")
@click.argument("model_spec", required=False, default=None)
@click.option("--hf", "hf_model_id", default=None, help="HuggingFace model ID.")
@click.option("--seq-len", default=None, type=int, help="Sequence length (HF text models).")
@click.option("--batch-size", "-b", default=1, help="Batch size.")
@click.option("--input-shape", "-s", default=None, help='Input shape, e.g. "3,224,224".')
@click.option("--dtype", "-d", default="float32", help="Adapter dtype: float32, float16, bfloat16.")
@click.option("--rank", "-r", default=16, type=int, help="LoRA rank (default 16).")
@click.option(
    "--target-modules",
    default="q_proj,v_proj,query,value",
    help='Comma-separated layer name substrings to target (default covers LLaMA + BERT naming).',
)
@click.option("--qlora", "use_qlora", is_flag=True, help="Quantize base model to 4-bit (QLoRA).")
@click.option("--optimizer", "-o", default="adamw", help="Adapter optimizer: adamw, adam, sgd, none.")
@click.option("--gpu", "-g", default=None, help='Target GPU key, e.g. "t4", "a100-80gb".')
@click.option("--format", "output_format", default="table", type=click.Choice(["table", "json", "plain"]))
def lora_cmd(
    model_spec,
    hf_model_id,
    seq_len,
    batch_size,
    input_shape,
    dtype,
    rank,
    target_modules,
    use_qlora,
    optimizer,
    gpu,
    output_format,
):
    """Estimate memory for LoRA or QLoRA fine-tuning.

    Only adapter parameters are trained — base model is frozen (LoRA) or
    quantized to 4-bit (QLoRA). Use this to estimate how much VRAM you need
    for parameter-efficient fine-tuning.

    Examples:

        kitsune lora --hf bert-base-uncased --rank 16 --gpu t4

        kitsune lora --hf llama-7b-style --qlora --rank 64 --gpu a100-40gb
    """
    from .lora_estimator import LoRAConfig, estimate_lora_memory
    from .lora_formatters import format_lora_json, format_lora_plain, format_lora_table

    # Parse target modules
    targets = tuple(t.strip() for t in target_modules.split(",") if t.strip())

    lora_config = LoRAConfig(
        rank=rank,
        target_modules=targets,
        use_qlora=use_qlora,
        optimizer=optimizer,
    )

    # Load model
    if hf_model_id:
        try:
            from .hf_integration import load_hf_model
        except ImportError as e:
            click.echo(f"Error: {e}", err=True)
            sys.exit(1)
        try:
            model, default_shape = load_hf_model(hf_model_id)
            resolved_shape = (seq_len,) if seq_len else default_shape
        except Exception as e:
            click.echo(f"Error loading HuggingFace model '{hf_model_id}': {e}", err=True)
            sys.exit(1)
    else:
        if not model_spec:
            click.echo("Error: Provide MODEL_SPEC or --hf <model-id>.", err=True)
            sys.exit(1)
        if not input_shape:
            click.echo("Error: --input-shape is required for local models.", err=True)
            sys.exit(1)
        try:
            resolved_shape = tuple(int(x.strip()) for x in input_shape.split(","))
        except ValueError:
            click.echo(f"Error: Invalid --input-shape '{input_shape}'.", err=True)
            sys.exit(1)
        model = _load_model(model_spec)
        if model is None:
            sys.exit(1)

    # Resolve GPU
    resolved_gpu = _resolve_gpu(gpu) if gpu else None

    # Run estimation
    pred = estimate_lora_memory(
        model=model,
        input_shape=resolved_shape,
        batch_size=batch_size,
        dtype=dtype,
        config=lora_config,
    )

    # Output
    if output_format == "json":
        click.echo(format_lora_json(pred, gpu_name=resolved_gpu))
    elif output_format == "plain":
        click.echo(format_lora_plain(pred, gpu_name=resolved_gpu))
    else:
        click.echo(format_lora_table(pred, gpu_name=resolved_gpu))


@main.command("plan")
@click.argument("model_spec", required=False, default=None)
@click.option("--hf", "hf_model_id", default=None, help="HuggingFace model ID.")
@click.option("--seq-len", default=None, type=int, help="Sequence length (HF text models).")
@click.option("--batch-size", "-b", default=1, help="Reference batch size.")
@click.option("--input-shape", "-s", default=None, help='Input shape, e.g. "3,224,224".')
@click.option("--dtype", "-d", default="float32", help="float32, float16, bfloat16.")
@click.option("--optimizer", "-o", default="adam", help="adam, adamw, sgd, none.")
@click.option("--training/--inference", default=True, help="Training or inference mode.")
@click.option("--daily-budget", default=None, type=float, help="Max $/day filter.")
@click.option("--min-batch-size", default=1, type=int, help="Exclude GPUs that can't run this batch size.")
@click.option("--format", "output_format", default="table", type=click.Choice(["table", "json", "plain"]))
def plan_cmd(
    model_spec,
    hf_model_id,
    seq_len,
    batch_size,
    input_shape,
    dtype,
    optimizer,
    training,
    daily_budget,
    min_batch_size,
    output_format,
):
    """Rank all GPUs by cost for a model. Find the cheapest option that fits.

    Examples:

        kitsune plan --hf bert-base-uncased --training

        kitsune plan model.py:ResNet50 --input-shape 3,224,224 --daily-budget 50
    """
    from .cost_calculator import format_plan_json, format_plan_plain, format_plan_table, plan_gpu

    # Validate inputs
    if not model_spec and not hf_model_id:
        click.echo("Error: Provide MODEL_SPEC or --hf <model-id>.", err=True)
        sys.exit(1)

    # Load model
    if hf_model_id:
        try:
            from .hf_integration import load_hf_model
        except ImportError as e:
            click.echo(f"Error: {e}", err=True)
            sys.exit(1)
        try:
            model, default_shape = load_hf_model(hf_model_id)
            resolved_shape = (seq_len,) if seq_len else default_shape
        except Exception as e:
            click.echo(f"Error loading HuggingFace model '{hf_model_id}': {e}", err=True)
            sys.exit(1)
    else:
        if not input_shape:
            click.echo("Error: --input-shape is required for local models.", err=True)
            sys.exit(1)
        try:
            resolved_shape = tuple(int(x.strip()) for x in input_shape.split(","))
        except ValueError:
            click.echo(f"Error: Invalid --input-shape '{input_shape}'.", err=True)
            sys.exit(1)
        model = _load_model(model_spec)
        if model is None:
            sys.exit(1)

    click.echo("Analyzing GPUs... ", nl=False, err=True)
    plan = plan_gpu(
        model=model,
        input_shape=resolved_shape,
        batch_size=batch_size,
        dtype=dtype,
        optimizer=optimizer,
        training=training,
        daily_budget=daily_budget,
        min_batch_size=min_batch_size,
    )
    click.echo("done", err=True)

    if output_format == "json":
        click.echo(format_plan_json(plan))
    elif output_format == "plain":
        click.echo(format_plan_plain(plan))
    else:
        click.echo(format_plan_table(plan))


@main.command("list-gpus")
def list_gpus_cmd():
    """List all GPUs in the database."""
    from .gpu_database import list_gpus

    try:
        from rich.console import Console
        from rich.table import Table

        console = Console()
        table = Table(title="Kitsune GPU Database")
        table.add_column("Key", style="cyan")
        table.add_column("Name")
        table.add_column("VRAM", justify="right")
        table.add_column("FP16 TFLOPS", justify="right")
        table.add_column("Bandwidth", justify="right")
        table.add_column("$/hr on-demand", justify="right")
        table.add_column("$/hr spot", justify="right")

        for spec in list_gpus():
            key = spec.name.lower().replace(" ", "-").replace("nvidia-", "")
            price_str = f"${spec.price_per_hr_usd:.2f}" if spec.price_per_hr_usd else "local"
            spot_str = f"${spec.spot_price_per_hr_usd:.2f}" if spec.spot_price_per_hr_usd else "—"
            table.add_row(
                key,
                spec.name,
                f"{spec.vram_gb:.0f} GB",
                f"{spec.fp16_tflops:.0f}",
                f"{spec.memory_bandwidth_gbps:.0f} GB/s",
                price_str,
                spot_str,
            )

        console.print(table)
        console.print(
            "[dim]On-demand: lowest rate (Lambda/RunPod/GCP/AWS, 2025-05). "
            "Spot: Vast.ai/RunPod spot — fluctuates, may be unavailable.[/dim]"
        )

    except ImportError:
        for spec in list_gpus():
            price_str = f"${spec.price_per_hr_usd:.2f}/hr" if spec.price_per_hr_usd else "local only"
            spot_str = f"  spot ${spec.spot_price_per_hr_usd:.2f}/hr" if spec.spot_price_per_hr_usd else ""
            click.echo(f"  {spec.name:<25} {spec.vram_gb:>5.0f} GB  {spec.fp16_tflops:>6.0f} FP16 TFLOPS  {price_str}{spot_str}")


def _parse_memory_budget(budget_str: str) -> Optional[float]:
    """
    Parse a human-readable memory budget string to GB.

    Accepts: "16GB", "16 GB", "8192MB", "0.5TB", "16384" (bare number = MB).
    Returns GB as float, or None if invalid.
    """
    import re

    s = budget_str.strip().upper().replace(" ", "")
    m = re.fullmatch(r"([0-9]*\.?[0-9]+)(TB|GB|MB|KB)?", s)
    if not m:
        return None
    value = float(m.group(1))
    unit = m.group(2) or "MB"
    multipliers = {"TB": 1024.0, "GB": 1.0, "MB": 1 / 1024.0, "KB": 1 / (1024.0**2)}
    return value * multipliers[unit]


def _ci_exit(
    total_gb: float,
    budget_gb: Optional[float],
    ci_mode: bool,
    target_gpu,
    fits_on_gpu: bool,
) -> None:
    """
    Handle CI exit codes:
    - If --budget set: exit 1 when total_gb > budget_gb, else exit 0.
    - Else if --gpu set: exit 1 when OOM, else exit 0.
    - If --ci without --budget or --gpu: just exit 0 (prediction succeeded).
    """
    if budget_gb is not None:
        over = total_gb > budget_gb
        if ci_mode:
            msg = (
                f"BUDGET {'EXCEEDED' if over else 'OK'}: "
                f"{total_gb:.3f} GB {'>' if over else '<='} {budget_gb:.3f} GB"
            )
            click.echo(msg, err=not over)
        if over:
            sys.exit(1)
        return

    if target_gpu and not fits_on_gpu:
        if ci_mode:
            click.echo(
                f"OOM: {total_gb:.3f} GB exceeds {target_gpu.vram_gb} GB on {target_gpu.name}",
                err=True,
            )
        sys.exit(1)


def _load_model(model_spec: str):
    """
    Load a model from a spec like "path/to/model.py:ClassName" or "module:ClassName".

    Returns instantiated model or None on failure.
    """
    import torch.nn as nn

    if ":" not in model_spec:
        click.echo(
            f"Error: MODEL_SPEC must be 'path/to/file.py:ClassName', got '{model_spec}'",
            err=True,
        )
        return None

    module_path, class_name = model_spec.rsplit(":", 1)

    try:
        # Try as a file path first
        path = Path(module_path)
        if path.exists() and path.suffix == ".py":
            spec = importlib.util.spec_from_file_location("_kitsune_model", path)
            if spec and spec.loader:
                module = importlib.util.module_from_spec(spec)
                sys.path.insert(0, str(path.parent))
                spec.loader.exec_module(module)
                sys.path.pop(0)
            else:
                click.echo(f"Error: Could not load module from '{module_path}'", err=True)
                return None
        else:
            # Try as a Python module
            module = importlib.import_module(module_path)

        # Get the class
        if not hasattr(module, class_name):
            click.echo(f"Error: '{class_name}' not found in '{module_path}'", err=True)
            return None

        model_class = getattr(module, class_name)

        # Instantiate
        model = model_class()
        if not isinstance(model, nn.Module):
            click.echo(f"Error: '{class_name}' is not a torch.nn.Module", err=True)
            return None

        model.eval()
        return model

    except Exception as e:
        click.echo(f"Error loading model: {e}", err=True)
        return None


def _resolve_gpu(gpu_flag: str) -> Optional[str]:
    """
    Resolve the --gpu flag value to a GPU key or None.

    "auto"  → detect local hardware and map to a database key
    None    → no GPU comparison
    other   → pass through as-is
    """
    if gpu_flag is None or gpu_flag == "none":
        return None

    if gpu_flag != "auto":
        return gpu_flag

    # Auto-detect local hardware
    try:
        import torch
        from kitsune.api.device_config import detect_hardware, DeviceType

        hw = detect_hardware()

        # Map hardware info to GPU database key
        name_lower = hw.device_name.lower()

        if hw.device_type.value == "apple_silicon":
            if "m4" in name_lower:
                return "m4-max"
            elif "m3" in name_lower and "max" in name_lower:
                return "m3-max"
            elif "m2" in name_lower and "max" in name_lower:
                return "m2-max"
            elif "m1" in name_lower and "pro" in name_lower:
                return "m1-pro"
            else:
                return "m1"
        elif torch.cuda.is_available():
            # Try to match by name
            from .gpu_database import get_gpu_spec
            spec = get_gpu_spec(hw.device_name)
            if spec:
                return hw.device_name
            # Fallback: match by VRAM
            if hw.total_memory_gb:
                vram = round(hw.total_memory_gb)
                mapping = {16: "t4", 24: "rtx-4090", 40: "a100-40gb", 80: "a100-80gb"}
                return mapping.get(vram)

    except Exception:
        pass

    return None


if __name__ == "__main__":
    main()
