"""
Optimization recommendations and memory savings calculations.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass
class Recommendation:
    """A single optimization recommendation."""

    name: str
    savings_bytes: int
    description: str
    tradeoff: str = ""

    @property
    def savings_gb(self) -> float:
        return self.savings_bytes / (1024**3)


def compute_recommendations(
    param_bytes: int,
    gradient_bytes: int,
    optimizer_bytes: int,
    activation_bytes: int,
    current_dtype_size: int = 4,
    training: bool = True,
) -> List[Recommendation]:
    """
    Generate optimization recommendations with estimated savings.

    Args:
        param_bytes: Total parameter memory in bytes.
        gradient_bytes: Gradient memory in bytes.
        optimizer_bytes: Optimizer state memory in bytes.
        activation_bytes: Activation memory in bytes.
        current_dtype_size: Current dtype element size (4 for fp32, 2 for fp16).
        training: Whether in training mode.

    Returns:
        List of applicable recommendations sorted by savings (descending).
    """
    recs: List[Recommendation] = []

    # Mixed precision (FP16/BF16)
    if current_dtype_size == 4:
        # Activations are halved; params/grads stay fp32 (master weights) or are halved
        # In practice, activations are the big win
        amp_savings = activation_bytes // 2
        if training:
            # Gradients can be fp16 in AMP
            amp_savings += gradient_bytes // 2
        if amp_savings > 0:
            recs.append(Recommendation(
                name="Mixed Precision (FP16)",
                savings_bytes=amp_savings,
                description="Use torch.amp.autocast for fp16 activations and gradients",
                tradeoff="Minimal accuracy impact for most models",
            ))

    # Gradient checkpointing (training only)
    if training and activation_bytes > 0:
        # Checkpointing saves ~70% of activation memory at cost of ~33% extra compute
        checkpoint_savings = int(activation_bytes * 0.7)
        if checkpoint_savings > 0:
            recs.append(Recommendation(
                name="Gradient Checkpointing",
                savings_bytes=checkpoint_savings,
                description="Recompute activations during backward instead of storing them",
                tradeoff="+33% compute time",
            ))

    # 8-bit quantization
    if current_dtype_size >= 4:
        quant8_savings = param_bytes - (param_bytes // 4)  # fp32 → int8 = 75% savings
        if training:
            # 8-bit optimizer (bitsandbytes) — optimizer states become int8
            quant8_savings = optimizer_bytes - (optimizer_bytes // 4)
            recs.append(Recommendation(
                name="8-bit Optimizer (bitsandbytes)",
                savings_bytes=quant8_savings,
                description="Use 8-bit Adam optimizer states instead of fp32",
                tradeoff="<0.1% accuracy impact typically",
            ))
        else:
            recs.append(Recommendation(
                name="INT8 Quantization",
                savings_bytes=quant8_savings,
                description="Quantize model weights to INT8 for inference",
                tradeoff="~1% accuracy loss for most models",
            ))

    # 4-bit quantization (inference or QLoRA)
    if param_bytes > 0:
        quant4_savings = param_bytes - (param_bytes // 8)  # fp32 → 4bit = 87.5% savings
        if not training:
            recs.append(Recommendation(
                name="4-bit Quantization (GPTQ/AWQ)",
                savings_bytes=quant4_savings,
                description="Quantize weights to 4-bit for inference",
                tradeoff="1-3% accuracy loss, requires calibration",
            ))
        else:
            # QLoRA: 4-bit base + small trainable adapters
            qlora_savings = int(param_bytes * 0.75)  # base model in 4-bit
            recs.append(Recommendation(
                name="QLoRA (4-bit base + LoRA)",
                savings_bytes=qlora_savings,
                description="Freeze base model in 4-bit, train small LoRA adapters",
                tradeoff="Reduced capacity vs full fine-tuning",
            ))

    # CPU offloading (training)
    if training and optimizer_bytes > 0:
        recs.append(Recommendation(
            name="CPU Offload (Optimizer)",
            savings_bytes=optimizer_bytes,
            description="Move optimizer states to CPU RAM (DeepSpeed ZeRO-Offload)",
            tradeoff="~10-30% slower training due to PCIe transfers",
        ))

    # Sort by savings descending
    recs.sort(key=lambda r: r.savings_bytes, reverse=True)
    return recs
