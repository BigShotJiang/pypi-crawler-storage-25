"""
GPU cost calculator — finds the cheapest GPU that fits a workload.

Given a model + config, ranks every GPU in the database by cost, shows
max batch size and $/1k-steps so engineers can make informed GPU choices
before starting a run.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Union

import torch
import torch.nn as nn

from .estimator import PredictionResult, predict_memory
from .gpu_database import GPUSpec, list_gpus


@dataclass
class GPUCostEntry:
    """Cost breakdown for a single GPU option."""

    gpu: GPUSpec
    prediction: PredictionResult
    max_batch_size: Optional[int]

    # Cost metrics (None if GPU has no pricing)
    cost_per_hr: Optional[float]
    spot_cost_per_hr: Optional[float]       # spot/preemptible rate (None if unavailable)
    cost_per_1k_steps: Optional[float]      # at the recommended max_batch_size
    cost_per_day: Optional[float]           # 24 hr continuous, on-demand

    fits: bool
    recommended: bool = False               # flagged as best value

    @property
    def gpu_utilization_pct(self) -> float:
        return self.prediction.gpu_utilization_pct or 0.0


@dataclass
class PlanResult:
    """Full GPU planning result — all options ranked by cost."""

    model_name: str
    input_shape: Tuple[int, ...]
    dtype: torch.dtype
    optimizer_type: str
    training: bool
    required_memory_gb: float              # prediction at batch_size=1

    entries: List[GPUCostEntry] = field(default_factory=list)

    @property
    def cheapest(self) -> Optional[GPUCostEntry]:
        """Lowest $/hr GPU that fits."""
        priced = [e for e in self.entries if e.fits and e.cost_per_hr is not None]
        return min(priced, key=lambda e: e.cost_per_hr) if priced else None

    @property
    def best_value(self) -> Optional[GPUCostEntry]:
        """Best $/1k-steps GPU (maximises batch size per dollar)."""
        priced = [
            e for e in self.entries
            if e.fits and e.cost_per_1k_steps is not None and e.max_batch_size
        ]
        return min(priced, key=lambda e: e.cost_per_1k_steps) if priced else None

    @property
    def fitting_gpus(self) -> List[GPUCostEntry]:
        return [e for e in self.entries if e.fits]

    @property
    def oom_gpus(self) -> List[GPUCostEntry]:
        return [e for e in self.entries if not e.fits]


def plan_gpu(
    model: nn.Module,
    input_shape: Union[Tuple[int, ...], List[int]],
    batch_size: int = 1,
    dtype: Union[torch.dtype, str] = torch.float32,
    optimizer: str = "adam",
    training: bool = True,
    daily_budget: Optional[float] = None,
    min_batch_size: int = 1,
) -> PlanResult:
    """
    Rank all GPUs by cost for a given model configuration.

    Args:
        model: PyTorch model to analyze.
        input_shape: Input shape WITHOUT batch dimension.
        batch_size: Reference batch size for memory check.
        dtype: Model dtype.
        optimizer: Optimizer type (training only).
        training: Training or inference mode.
        daily_budget: Optional $/day filter — only show GPUs within budget.
        min_batch_size: Exclude GPUs that can't run at least this batch size.

    Returns:
        PlanResult with all GPUs ranked cheapest-first.
    """
    if isinstance(dtype, str):
        from .estimator import _resolve_dtype
        dtype = _resolve_dtype(dtype)

    input_shape = tuple(input_shape)

    # Base prediction at batch_size=1 to get fixed costs
    base_result = predict_memory(
        model=model,
        input_shape=input_shape,
        batch_size=batch_size,
        dtype=dtype,
        optimizer=optimizer,
        training=training,
        gpu=None,
    )

    entries: List[GPUCostEntry] = []

    for gpu in list_gpus():
        # Skip Apple Silicon — unified memory semantics differ
        if gpu.architecture == "apple_silicon":
            continue

        # Check if model fits at the reference batch size
        result = predict_memory(
            model=model,
            input_shape=input_shape,
            batch_size=batch_size,
            dtype=dtype,
            optimizer=optimizer,
            training=training,
            gpu=gpu.name,
            find_max_batch_size=True,
        )

        fits = result.fits_on_gpu is True
        max_bs = result.max_batch_size

        # Skip if below min_batch_size requirement
        if fits and min_batch_size > 1 and (max_bs is None or max_bs < min_batch_size):
            fits = False

        # Cost calculations
        cost_per_hr = gpu.price_per_hr_usd
        cost_per_1k_steps = None
        cost_per_day = None

        if cost_per_hr is not None:
            cost_per_day = cost_per_hr * 24
            if fits and max_bs and max_bs >= 1:
                # Steps per second ≈ throughput / max_batch_size
                # We approximate: cost per 1k steps = ($/hr / steps_per_hr) * 1000
                # steps_per_hr = 3600 / time_per_step
                # We don't have actual throughput — use FP16 TFLOPS as a proxy.
                # This is a relative metric: lower is better.
                # Formula: $/1k-steps = $/hr / (fp16_tflops * 1e12 / model_flops * max_bs)
                # Since we don't have model flops, use $/hr / max_bs as a simpler proxy.
                cost_per_1k_steps = (cost_per_hr / max_bs) * 1000

        # Apply budget filter
        if daily_budget is not None and cost_per_day is not None:
            if cost_per_day > daily_budget:
                continue

        entry = GPUCostEntry(
            gpu=gpu,
            prediction=result,
            max_batch_size=max_bs,
            cost_per_hr=cost_per_hr,
            spot_cost_per_hr=gpu.spot_price_per_hr_usd,
            cost_per_1k_steps=cost_per_1k_steps,
            cost_per_day=cost_per_day,
            fits=fits,
        )
        entries.append(entry)

    # Sort: fitting GPUs first (by $/hr), then OOM GPUs (by VRAM needed)
    fitting = sorted(
        [e for e in entries if e.fits],
        key=lambda e: (e.cost_per_hr or 999, -( e.max_batch_size or 0)),
    )
    oom = sorted(
        [e for e in entries if not e.fits],
        key=lambda e: e.gpu.vram_gb,
    )
    entries = fitting + oom

    # Mark recommendations
    plan = PlanResult(
        model_name=base_result.model_name,
        input_shape=input_shape,
        dtype=dtype,
        optimizer_type=optimizer,
        training=training,
        required_memory_gb=base_result.total_gb,
        entries=entries,
    )

    # Flag cheapest and best-value
    cheapest = plan.cheapest
    best_val = plan.best_value
    for e in entries:
        if cheapest and e.gpu.name == cheapest.gpu.name:
            e.recommended = True
        elif best_val and e.gpu.name == best_val.gpu.name:
            e.recommended = True

    return plan


# ─── Formatters ──────────────────────────────────────────────────────────────

def format_plan_table(plan: PlanResult) -> str:
    """Format plan result as a Rich table."""
    try:
        from rich.console import Console
        from rich.panel import Panel
        from rich.table import Table
        import io

        console = Console(file=io.StringIO(), width=88)

        mode = "Training" if plan.training else "Inference"
        dtype_str = str(plan.dtype).replace("torch.", "")
        subtitle = (
            f"{plan.model_name} | {dtype_str} | {mode} | "
            f"Needs {plan.required_memory_gb:.2f} GB"
        )

        table = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
        table.add_column("GPU", min_width=22)
        table.add_column("VRAM", justify="right", min_width=6)
        table.add_column("$/hr", justify="right", min_width=6)
        table.add_column("spot/hr", justify="right", min_width=8)
        table.add_column("$/day", justify="right", min_width=7)
        table.add_column("Max Batch", justify="right", min_width=9)
        table.add_column("GPU%", justify="right", min_width=5)
        table.add_column("Status", justify="center", min_width=8)

        for entry in plan.entries:
            gpu = entry.gpu
            fits = entry.fits

            hr_str = f"${entry.cost_per_hr:.2f}" if entry.cost_per_hr else "—"
            spot_str = f"${entry.spot_cost_per_hr:.2f}" if entry.spot_cost_per_hr else "—"
            day_str = f"${entry.cost_per_day:.0f}" if entry.cost_per_day else "—"
            bs_str = str(entry.max_batch_size) if entry.max_batch_size else "—"
            util_str = f"{entry.gpu_utilization_pct:.0f}%"

            if not fits:
                status = "[red]OOM[/red]"
                row_style = "dim"
            elif entry.recommended:
                status = "[bold green]★ BEST[/bold green]"
                row_style = "bold"
            else:
                status = "[green]FITS[/green]"
                row_style = ""

            table.add_row(
                gpu.name, f"{gpu.vram_gb:.0f}GB",
                hr_str, spot_str, day_str, bs_str, util_str, status,
                style=row_style,
            )

        console.print(Panel(table, title="[bold]Kitsune GPU Plan[/bold]", subtitle=subtitle))

        # Summary callouts
        cheapest = plan.cheapest
        best_val = plan.best_value
        if cheapest:
            console.print(
                f"\n  [bold]Cheapest:[/bold] {cheapest.gpu.name} "
                f"(${cheapest.cost_per_hr:.2f}/hr, "
                f"max batch {cheapest.max_batch_size})"
            )
        if best_val and best_val.gpu.name != (cheapest.gpu.name if cheapest else ""):
            console.print(
                f"  [bold]Best value:[/bold] {best_val.gpu.name} "
                f"(${best_val.cost_per_hr:.2f}/hr, "
                f"max batch {best_val.max_batch_size}, "
                f"lowest $/1k-steps)"
            )

        console.print(
            "\n  [dim]Prices: lowest on-demand rate (Lambda/RunPod/GCP/AWS, 2025-05). "
            "Spot/preemptible can be 2-4× cheaper.[/dim]"
        )

        return console.file.getvalue()

    except ImportError:
        return format_plan_plain(plan)


def format_plan_plain(plan: PlanResult) -> str:
    """Format plan result as plain text."""
    mode = "Training" if plan.training else "Inference"
    dtype_str = str(plan.dtype).replace("torch.", "")

    lines = [
        "=" * 78,
        "  Kitsune GPU Plan",
        "=" * 78,
        f"  Model: {plan.model_name} | {dtype_str} | {mode}",
        f"  Required memory: {plan.required_memory_gb:.2f} GB",
        "",
        f"  {'GPU':<24} {'VRAM':>6}  {'$/hr':>6}  {'$/day':>6}  {'MaxBS':>6}  {'Mem':>8}  {'GPU%':>5}  Status",
        "  " + "-" * 74,
    ]

    for entry in plan.entries:
        gpu = entry.gpu
        hr_str = f"${entry.cost_per_hr:.2f}" if entry.cost_per_hr else "  —  "
        day_str = f"${entry.cost_per_day:.0f}" if entry.cost_per_day else "  — "
        bs_str = str(entry.max_batch_size) if entry.max_batch_size else "—"
        mem_str = f"{entry.prediction.total_gb:.2f}GB"
        util_str = f"{entry.gpu_utilization_pct:.0f}%"
        status = "OOM" if not entry.fits else ("★ BEST" if entry.recommended else "FITS")

        lines.append(
            f"  {gpu.name:<24} {gpu.vram_gb:>4.0f}GB  {hr_str:>6}  {day_str:>6}  "
            f"{bs_str:>6}  {mem_str:>8}  {util_str:>5}  {status}"
        )

    lines.append("  " + "-" * 74)

    cheapest = plan.cheapest
    if cheapest:
        lines.append(
            f"\n  Cheapest: {cheapest.gpu.name} (${cheapest.cost_per_hr:.2f}/hr, "
            f"max batch {cheapest.max_batch_size})"
        )
    lines.append(
        "  Prices: lowest on-demand rate (Lambda/RunPod/GCP/AWS, 2025-05)."
    )
    lines.append("=" * 78)
    return "\n".join(lines)


def format_plan_json(plan: PlanResult) -> str:
    """Format plan result as JSON."""
    import json

    data = {
        "model_name": plan.model_name,
        "config": {
            "input_shape": list(plan.input_shape),
            "dtype": str(plan.dtype).replace("torch.", ""),
            "optimizer": plan.optimizer_type,
            "training": plan.training,
        },
        "required_memory_gb": plan.required_memory_gb,
        "cheapest_gpu": plan.cheapest.gpu.name if plan.cheapest else None,
        "best_value_gpu": plan.best_value.gpu.name if plan.best_value else None,
        "gpus": [],
    }

    for entry in plan.entries:
        row = {
            "gpu": entry.gpu.name,
            "vram_gb": entry.gpu.vram_gb,
            "price_per_hr": entry.cost_per_hr,
            "spot_price_per_hr": entry.spot_cost_per_hr,
            "price_per_day": round(entry.cost_per_day, 2) if entry.cost_per_day else None,
            "max_batch_size": entry.max_batch_size,
            "predicted_memory_gb": round(entry.prediction.total_gb, 3),
            "gpu_utilization_pct": round(entry.gpu_utilization_pct, 1),
            "fits": entry.fits,
            "recommended": entry.recommended,
        }
        data["gpus"].append(row)

    return json.dumps(data, indent=2)
