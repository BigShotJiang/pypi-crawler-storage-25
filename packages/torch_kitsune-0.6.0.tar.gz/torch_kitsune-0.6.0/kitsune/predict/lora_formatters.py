"""
Output formatters for LoRA / QLoRA memory predictions.
"""

from __future__ import annotations

import json
from typing import Optional

from .lora_estimator import LoRAPrediction


def _fmt_gb(n: int) -> str:
    return f"{n / (1024**3):.3f} GB"


def format_lora_table(pred: LoRAPrediction, gpu_name: Optional[str] = None) -> str:
    """Format LoRA prediction as a Rich table."""
    try:
        import io

        from rich.console import Console
        from rich.panel import Panel
        from rich.table import Table

        console = Console(file=io.StringIO(), width=72)

        label = "QLoRA" if pred.config.use_qlora else "LoRA"
        quant_note = " (4-bit base)" if pred.config.use_qlora else ""
        subtitle = (
            f"{label} r={pred.config.rank} | "
            f"{pred.num_adapter_params:,} trainable params | "
            f"{pred.num_targeted_layers} layers{quant_note}"
        )

        table = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
        table.add_column("Component", style="cyan", min_width=30)
        table.add_column("Memory", justify="right", min_width=12)
        table.add_column("% Total", justify="right", min_width=8)

        total = pred.total_bytes
        for name, gb in pred.breakdown_dict().items():
            b = gb * (1024**3)
            if b < 1024:
                continue
            pct = (b / total * 100) if total > 0 else 0
            table.add_row(name, f"{gb:.3f} GB", f"{pct:.1f}%")

        table.add_row("─" * 30, "─" * 12, "─" * 8, style="dim")
        table.add_row("TOTAL (peak)", f"{pred.total_gb:.3f} GB", "100%", style="bold")

        console.print(Panel(table, title=f"[bold]Kitsune {label} Prediction[/bold]", subtitle=subtitle))

        # GPU fit check
        if gpu_name:
            from .gpu_database import get_gpu_spec

            spec = get_gpu_spec(gpu_name)
            if spec:
                fits = pred.total_gb <= spec.usable_vram_gb
                util = (pred.total_gb / spec.vram_gb) * 100
                symbol = "[green]FITS[/green]" if fits else "[red]OOM[/red]"
                console.print(
                    f"\n  Target: [bold]{spec.name}[/bold] ({spec.vram_gb} GB) | "
                    f"Usage: {util:.1f}% | {symbol}"
                )
                headroom = spec.usable_vram_gb - pred.total_gb
                if fits:
                    console.print(f"  Headroom: {headroom:.2f} GB")
                else:
                    console.print(f"  [red]Over budget by: {abs(headroom):.2f} GB[/red]")

        # Savings vs full fine-tuning
        savings = pred.savings_vs_full_finetune_gb
        if savings > 0:
            console.print(
                f"\n  [bold]vs. full fine-tuning:[/bold] saves ~{savings:.2f} GB "
                f"(only adapter params get gradients + optimizer states)"
            )

        # Targeted layers
        if pred.targeted_layer_names:
            if len(pred.targeted_layer_names) <= 6:
                layers_str = ", ".join(pred.targeted_layer_names)
            else:
                layers_str = ", ".join(pred.targeted_layer_names[:3]) + f" ... +{len(pred.targeted_layer_names) - 3} more"
            console.print(f"  Targeted layers: [dim]{layers_str}[/dim]")

        return console.file.getvalue()

    except ImportError:
        return format_lora_plain(pred, gpu_name=gpu_name)


def format_lora_plain(pred: LoRAPrediction, gpu_name: Optional[str] = None) -> str:
    """Format LoRA prediction as plain text."""
    label = "QLoRA" if pred.config.use_qlora else "LoRA"
    lines = [
        "=" * 64,
        f"  Kitsune {label} Memory Prediction",
        "=" * 64,
        f"  Rank: {pred.config.rank} | Trainable params: {pred.num_adapter_params:,} "
        f"| Layers: {pred.num_targeted_layers}",
        "",
        f"  {'Component':<32} {'Memory':>10} {'%':>7}",
        "  " + "-" * 52,
    ]

    total = pred.total_bytes
    for name, gb in pred.breakdown_dict().items():
        b = gb * (1024**3)
        if b < 1024:
            continue
        pct = (b / total * 100) if total > 0 else 0
        lines.append(f"  {name:<32} {gb:>8.3f} GB {pct:>5.1f}%")

    lines.append("  " + "-" * 52)
    lines.append(f"  {'TOTAL (peak)':<32} {pred.total_gb:>8.3f} GB {'100%':>6}")

    if gpu_name:
        from .gpu_database import get_gpu_spec

        spec = get_gpu_spec(gpu_name)
        if spec:
            fits = pred.total_gb <= spec.usable_vram_gb
            util = (pred.total_gb / spec.vram_gb) * 100
            symbol = "FITS" if fits else "OOM!"
            lines.append(f"\n  Target: {spec.name} ({spec.vram_gb} GB) | Usage: {util:.1f}% | {symbol}")

    savings = pred.savings_vs_full_finetune_gb
    if savings > 0:
        lines.append(f"\n  vs. full fine-tuning: saves ~{savings:.2f} GB")

    lines.append("=" * 64)
    return "\n".join(lines)


def format_lora_json(pred: LoRAPrediction, gpu_name: Optional[str] = None) -> str:
    """Format LoRA prediction as JSON."""
    data = {
        "mode": "qlora" if pred.config.use_qlora else "lora",
        "config": {
            "rank": pred.config.rank,
            "target_modules": list(pred.config.target_modules),
            "use_qlora": pred.config.use_qlora,
            "optimizer": pred.config.optimizer,
        },
        "adapter": {
            "trainable_params": pred.num_adapter_params,
            "targeted_layers": pred.num_targeted_layers,
            "targeted_layer_names": pred.targeted_layer_names,
        },
        "memory": {
            "total_gb": round(pred.total_gb, 3),
            "breakdown": {k: round(v, 4) for k, v in pred.breakdown_dict().items()},
        },
        "savings_vs_full_finetune_gb": round(pred.savings_vs_full_finetune_gb, 3),
    }

    if gpu_name:
        from .gpu_database import get_gpu_spec

        spec = get_gpu_spec(gpu_name)
        if spec:
            fits = pred.total_gb <= spec.usable_vram_gb
            data["gpu"] = {
                "name": spec.name,
                "vram_gb": spec.vram_gb,
                "fits": fits,
                "utilization_pct": round((pred.total_gb / spec.vram_gb) * 100, 1),
                "headroom_gb": round(spec.usable_vram_gb - pred.total_gb, 3),
            }

    return json.dumps(data, indent=2)
