"""
🏎️ TensorRT Optimizer Backend for Kitsune

Provides high-performance inference for NVIDIA GPUs by converting
PyTorch models to TensorRT engines.
"""

import os
import time
import logging
import numpy as np
from typing import Any, Dict, List, Optional, Union, Iterable

import torch
import torch.nn as nn

# Optional dependencies handled with graceful fallbacks
try:
    import tensorrt as trt
    import pycuda.driver as cuda
    import pycuda.autoinit
    TRT_AVAILABLE = True
    TRT_BASE_CALIBRATOR = trt.IInt8MinMaxCalibrator
except ImportError:
    TRT_AVAILABLE = False
    TRT_BASE_CALIBRATOR = object

try:
    import onnx
    from onnxsim import simplify
    ONNX_AVAILABLE = True
except ImportError:
    ONNX_AVAILABLE = False

logger = logging.getLogger(__name__)

class TRTCalibrator(TRT_BASE_CALIBRATOR):
    """
    Calibrator for TensorRT INT8 quantization.
    Uses Min-Max calibration based on a provided dataset.
    """
    def __init__(self, dataloader: Iterable, cache_file: str = "calibration.cache"):
        super().__init__()
        self.dataloader = iter(dataloader)
        self.cache_file = cache_file
        self.device_input = None
        self.batch_size = 1 # Will be updated on first batch

    def get_batch_size(self):
        return self.batch_size

    def get_batch(self, names):
        try:
            batch = next(self.dataloader)
            if isinstance(batch, (list, tuple)):
                batch = batch[0]
            
            # Update batch size
            self.batch_size = batch.shape[0]
            
            # Ensure on GPU and contiguous
            batch = batch.cuda().contiguous()
            
            # Allocate device memory if not already done
            if self.device_input is None:
                self.device_input = cuda.mem_alloc(batch.nbytes)
            
            # Copy to device
            cuda.memcpy_htod(self.device_input, batch.detach().cpu().numpy())
            return [int(self.device_input)]
        except StopIteration:
            return None

    def read_calibration_cache(self):
        if os.path.exists(self.cache_file):
            with open(self.cache_file, "rb") as f:
                return f.read()
        return None

    def write_calibration_cache(self, cache):
        with open(self.cache_file, "wb") as f:
            f.write(cache)

class KitsuneTRTWrapper(nn.Module):
    """
    lightweight nn.Module wrapper for a TensorRT engine.
    Handles memory allocation and execution.
    """
    def __init__(self, engine_path: str):
        super().__init__()
        self.engine_path = engine_path
        self.runtime = trt.Runtime(trt.Logger(trt.Logger.WARNING))
        
        with open(engine_path, "rb") as f:
            self.engine = self.runtime.deserialize_cuda_engine(f.read())
            
        self.context = self.engine.create_execution_context()
        self.stream = cuda.Stream()
        
        # Allocate buffers
        self.inputs = []
        self.outputs = []
        self.bindings = []
        
        for binding in self.engine:
            size = trt.volume(self.engine.get_binding_shape(binding)) * \
                   self.engine.get_binding_dtype(binding).itemsize
            device_mem = cuda.mem_alloc(size)
            self.bindings.append(int(device_mem))
            
            if self.engine.binding_is_input(binding):
                self.inputs.append({"name": binding, "device": device_mem, "size": size})
            else:
                self.outputs.append({"name": binding, "device": device_mem, "size": size, 
                                   "shape": self.engine.get_binding_shape(binding),
                                   "dtype": self._trt_to_numpy_dtype(self.engine.get_binding_dtype(binding))})

    def _trt_to_numpy_dtype(self, trt_dtype):
        if trt_dtype == trt.float32: return np.float32
        if trt_dtype == trt.float16: return np.float16
        if trt_dtype == trt.int8: return np.int8
        if trt_dtype == trt.int32: return np.int32
        return np.float32

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # 1. Copy input to device (async)
        # Note: We assume x is already on GPU or we move it
        x_np = x.detach().cpu().numpy().astype(np.float32) # Simplification: assume float32
        cuda.memcpy_htod_async(self.inputs[0]["device"], x_np, self.stream)
        
        # 2. Execute
        self.context.execute_async_v2(bindings=self.bindings, stream_handle=self.stream.handle)
        
        # 3. Copy output back to host
        out_data = np.empty(self.outputs[0]["shape"], dtype=self.outputs[0]["dtype"])
        cuda.memcpy_dtoh_async(out_data, self.outputs[0]["device"], self.stream)
        
        # 4. Sync
        self.stream.synchronize()
        
        return torch.from_numpy(out_data).to(x.device)

class TRTOptimizer:
    """
    Orchestrates the conversion of PyTorch models to TensorRT.
    """
    def __init__(self, precision: str = "fp16", workspace_gb: float = 4.0):
        self.precision = precision.lower()
        self.workspace_size = int(workspace_gb * (1024**3))
        
        if not TRT_AVAILABLE:
            raise RuntimeError("TensorRT (tensorrt, pycuda) not installed. Cannot use TRTOptimizer.")
        if not ONNX_AVAILABLE:
            raise RuntimeError("ONNX (onnx, onnxsim) not installed. Required for TRT conversion.")

    def optimize(
        self, 
        model: nn.Module, 
        sample_input: torch.Tensor, 
        calibration_data: Optional[Iterable] = None,
        engine_path: str = "model.trt"
    ) -> nn.Module:
        """
        Convert PyTorch model to TRT engine and return wrapper.
        """
        onnx_path = "model.onnx"
        
        # 1. Export to ONNX
        logger.info(f"🏎️ TRTOptimizer: Exporting to ONNX (opset 17)...")
        model.eval()
        torch.onnx.export(
            model, sample_input, onnx_path,
            export_params=True, opset_version=17,
            do_constant_folding=True,
            input_names=['input'], output_names=['output'],
            dynamic_axes={'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}}
        )
        
        # 2. Simplify ONNX
        logger.info(f"🏎️ TRTOptimizer: Simplifying ONNX graph...")
        onnx_model = onnx.load(onnx_path)
        model_simp, check = simplify(onnx_model)
        if check:
            onnx.save(model_simp, onnx_path)
        else:
            logger.warning("ONNX simplification failed, using original export.")
            
        # 3. Build TRT Engine
        logger.info(f"🏎️ TRTOptimizer: Building TRT engine (precision={self.precision})...")
        TRT_LOGGER = trt.Logger(trt.Logger.INFO)
        builder = trt.Builder(TRT_LOGGER)
        network = builder.create_network(1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))
        config = builder.create_builder_config()
        parser = trt.OnnxParser(network, TRT_LOGGER)
        
        config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, self.workspace_size)
        
        # Precision flags
        if self.precision == "fp16":
            if builder.platform_has_fast_fp16:
                config.set_flag(trt.BuilderFlag.FP16)
            else:
                logger.warning("Hardware does not support native FP16. Falling back to FP32.")
        elif self.precision == "int8":
            if builder.platform_has_fast_int8:
                config.set_flag(trt.BuilderFlag.INT8)
                if calibration_data:
                    config.int8_calibrator = TRTCalibrator(calibration_data)
                else:
                    logger.warning("INT8 requested but no calibration data provided. Using default Min-Max (low accuracy potential).")
                    config.int8_calibrator = TRTCalibrator([sample_input])
            else:
                logger.warning("Hardware does not support native INT8. Falling back.")

        with open(onnx_path, "rb") as model_file:
            if not parser.parse(model_file.read()):
                for error in range(parser.num_errors):
                    logger.error(parser.get_error(error))
                raise RuntimeError("Failed to parse ONNX model for TensorRT.")

        # Build engine
        engine = builder.build_serialized_network(network, config)
        with open(engine_path, "wb") as f:
            f.write(engine)
            
        # Cleanup temporary files
        if os.path.exists(onnx_path): os.remove(onnx_path)
        
        return KitsuneTRTWrapper(engine_path)
