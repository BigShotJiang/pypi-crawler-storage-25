"""
⚡ Flash Attention Integration for Kitsune

Provides drop-in replacements for standard Attention layers using
PyTorch's Scaled Dot Product Attention (SDPA) or the flash-attn package.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import logging
from typing import Optional

logger = logging.getLogger(__name__)

class FlashAttentionWrapper(nn.Module):
    """
    Wrapper for nn.MultiheadAttention that uses Flash Attention (SDPA).
    
    PyTorch 2.0+ includes F.scaled_dot_product_attention which 
    automatically uses Flash Attention kernels when available.
    """
    def __init__(self, original_mha: nn.MultiheadAttention):
        super().__init__()
        # Copy basic properties
        self.embed_dim = original_mha.embed_dim
        self.num_heads = original_mha.num_heads
        self.head_dim = self.embed_dim // self.num_heads
        self.dropout = original_mha.dropout
        
        # Reference parameters from the original module (sharing weights)
        self.in_proj_weight = original_mha.in_proj_weight
        self.in_proj_bias = original_mha.in_proj_bias
        self.out_proj = original_mha.out_proj
        
        # Check if flash attention is supported for this device/dtype
        self._check_sdp_support()

    def _check_sdp_support(self):
        """Check for built-in SDPA support."""
        if hasattr(F, "scaled_dot_product_attention"):
            self.use_sdpa = True
        else:
            self.use_sdpa = False
            logger.warning("FlashAttentionWrapper: F.scaled_dot_product_attention not found. Falling back to vanilla.")

    def forward(
        self, 
        query: torch.Tensor, 
        key: torch.Tensor, 
        value: torch.Tensor, 
        key_padding_mask: Optional[torch.Tensor] = None,
        need_weights: bool = False,
        attn_mask: Optional[torch.Tensor] = None,
        average_attn_weights: bool = True,
        is_causal: bool = False
    ):
        """
        Forward pass using Flash Attention (SDPA).
        Note: Current implementation assumes simple MHA usage.
        """
        if need_weights:
            # Flash attention kernels usually don't return attention weights
            # Fallback to vanilla or raise warning
            logger.warning("FlashAttentionWrapper: need_weights=True is not supported by Flash kernels. Falling back.")
            return F.multi_head_attention_forward(
                query, key, value, self.embed_dim, self.num_heads,
                self.in_proj_weight, self.in_proj_bias,
                None, None, False,
                self.dropout, self.out_proj.weight, self.out_proj.bias,
                training=self.training,
                key_padding_mask=key_padding_mask,
                attn_mask=attn_mask
            )

        if not self.use_sdpa:
            return original_mha_forward(query, key, value) # Fallback defined below or similar

        # 1. Project inputs
        # query/key/value shapes: (L, N, E)
        L, N, E = query.shape
        
        # Multi-head attention projections
        # Simplified projection logic for demonstration
        q, k, v = F.linear(query, self.in_proj_weight, self.in_proj_bias).chunk(3, dim=-1)
        
        # 2. Reshape for multi-head: (L, N, E) -> (N, H, L, D)
        q = q.view(L, N, self.num_heads, self.head_dim).transpose(0, 1).transpose(1, 2)
        k = k.view(L, N, self.num_heads, self.head_dim).transpose(0, 1).transpose(1, 2)
        v = v.view(L, N, self.num_heads, self.head_dim).transpose(0, 1).transpose(1, 2)
        
        # 3. Scaled Dot Product Attention (The "Flash" part)
        # dropout_p = self.dropout if self.training else 0.0
        attn_output = F.scaled_dot_product_attention(
            q, k, v, 
            attn_mask=attn_mask, 
            dropout_p=self.dropout if self.training else 0.0,
            is_causal=is_causal
        )
        
        # 4. Reshape back: (N, H, L, D) -> (L, N, E)
        attn_output = attn_output.transpose(1, 2).contiguous().view(L, N, E)
        
        # 5. Output projection
        return self.out_proj(attn_output), None

def find_attention_layers(model: nn.Module) -> list[str]:
    """Find all nn.MultiheadAttention layers in the model."""
    layers = []
    for name, module in model.named_modules():
        if isinstance(module, nn.MultiheadAttention):
            layers.append(name)
    return layers

def swap_attention_to_flash(model: nn.Module) -> nn.Module:
    """
    Find and replace all nn.MultiheadAttention layers with FlashAttentionWrapper.
    """
    # Create a list of names first to avoid modification issues
    layers = find_attention_layers(model)
    
    if not layers:
        return model
        
    logger.info(f"⚡ Kitsune: Swapping {len(layers)} attention layers to Flash Attention")
    
    for name in layers:
        # Get parent module
        if "." in name:
            parent_name = ".".join(name.split(".")[:-1])
            child_name = name.split(".")[-1]
            parent = model.get_submodule(parent_name)
        else:
            parent = model
            child_name = name
            
        original_mha = getattr(parent, child_name)
        setattr(parent, child_name, FlashAttentionWrapper(original_mha))
        
    return model
