"""
Supermemory integration for Kitsune.

Persists optimization results and hardware profiles across sessions so Kitsune
can recall what strategies worked best for a given model/hardware combination.

Usage:
    from kitsune import KitsuneMemory, optimize

    memory = KitsuneMemory(user_id="jeeth")

    # Optimize and automatically remember the result
    optimized = optimize(model, sample_input, memory=memory)

    # Recall past strategies for this hardware
    past = memory.recall_strategy(hardware="Apple M2")

    # Store a benchmark result manually
    memory.remember_optimization(
        model_name="ResNet18",
        hardware="Apple M2",
        strategy="jit_trace",
        speedup=2.2,
    )
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class KitsuneMemory:
    """
    Persistent memory for Kitsune optimization results powered by Supermemory.

    Stores benchmark results, hardware profiles, and optimization strategies so
    that future sessions can recall what worked best for a given configuration.

    Args:
        user_id: Scopes memory to a specific user. Defaults to "default".
        api_key: Supermemory API key. Falls back to SUPERMEMORY_API_KEY env var.

    Example:
        memory = KitsuneMemory(user_id="jeeth")
        optimized = kitsune.optimize(model, sample, memory=memory)
    """

    def __init__(self, user_id: str = "default", api_key: Optional[str] = None):
        try:
            from supermemory import Supermemory
        except ImportError as exc:
            raise ImportError(
                "supermemory is required for KitsuneMemory. "
                "Install it with: pip install supermemory"
            ) from exc

        resolved_key = api_key or os.environ.get("SUPERMEMORY_API_KEY")
        if not resolved_key:
            raise ValueError(
                "No Supermemory API key found. "
                "Set SUPERMEMORY_API_KEY in your environment or pass api_key= explicitly. "
                "Get a key at https://console.supermemory.ai"
            )

        self._client = Supermemory(api_key=resolved_key)
        self.user_id = user_id
        self.container_tag = f"user_{user_id}"

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def remember_optimization(
        self,
        model_name: str,
        hardware: str,
        strategy: str,
        speedup: float,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Store an optimization result for future recall.

        Args:
            model_name: Human-readable model name (e.g. "ResNet18").
            hardware:   Hardware description (e.g. "Apple M2", "Tesla T4").
            strategy:   Strategy used (e.g. "jit_trace", "compile").
            speedup:    Measured speedup multiplier (e.g. 2.2).
            metadata:   Optional extra fields to attach.
        """
        content = (
            f"Kitsune optimization result — "
            f"model: {model_name}, hardware: {hardware}, "
            f"strategy: {strategy}, speedup: {speedup:.2f}x"
        )

        record_meta: Dict[str, Any] = {
            "model": model_name,
            "hardware": hardware,
            "strategy": strategy,
            "speedup": speedup,
        }
        if metadata:
            record_meta.update(metadata)

        try:
            self._client.add(
                content=content,
                container_tags=[self.container_tag],
                metadata=record_meta,
            )
            logger.info(
                f"[KitsuneMemory] Stored: {model_name} on {hardware} "
                f"→ {strategy} ({speedup:.2f}x)"
            )
        except Exception as exc:
            logger.warning(f"[KitsuneMemory] Failed to store result: {exc}")

    def remember_benchmark(self, benchmark_results: Dict[str, Any]) -> None:
        """
        Store the full output of ``kitsune.benchmark_optimization()`` at once.

        Args:
            benchmark_results: Dict returned by ``benchmark_optimization()``.
        """
        hardware = benchmark_results.get("hardware", "unknown")
        for strategy, data in benchmark_results.get("strategies", {}).items():
            if "error" in data or "median_ms" not in data:
                continue
            self.remember_optimization(
                model_name="benchmark",
                hardware=hardware,
                strategy=strategy,
                speedup=data.get("speedup", 1.0),
                metadata={
                    "median_ms": data["median_ms"],
                    "device_type": benchmark_results.get("device_type", "unknown"),
                    "optimizations": ", ".join(data.get("optimizations", [])),
                },
            )

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def recall_strategy(
        self,
        model_name: Optional[str] = None,
        hardware: Optional[str] = None,
        limit: int = 5,
    ) -> List[Dict[str, Any]]:
        """
        Search for past optimization results.

        Args:
            model_name: Filter by model name (optional).
            hardware:   Filter by hardware description (optional).
            limit:      Maximum number of results to return.

        Returns:
            List of matching memory documents.
        """
        parts = ["Kitsune optimization"]
        if model_name:
            parts.append(model_name)
        if hardware:
            parts.append(hardware)
        query = " ".join(parts)

        try:
            response = self._client.search.documents(
                q=query,
                container_tags=[self.container_tag],
                limit=limit,
            )
            results = getattr(response, "results", response) or []
            return list(results)
        except Exception as exc:
            logger.warning(f"[KitsuneMemory] Search failed: {exc}")
            return []

    def get_profile(self) -> Optional[Any]:
        """
        Retrieve the Supermemory user profile for this user_id.

        Returns:
            Profile object, or None on failure.
        """
        try:
            return self._client.profile(container_tag=self.container_tag)
        except Exception as exc:
            logger.warning(f"[KitsuneMemory] Profile fetch failed: {exc}")
            return None

    def list_results(self, limit: int = 20) -> List[Dict[str, Any]]:
        """
        List stored optimization results for this user.

        Args:
            limit: Maximum number of documents to return.

        Returns:
            List of stored documents.
        """
        try:
            response = self._client.documents.list(
                container_tags=[self.container_tag],
                limit=limit,
            )
            return list(getattr(response, "results", response) or [])
        except Exception as exc:
            logger.warning(f"[KitsuneMemory] List failed: {exc}")
            return []

    def best_strategy_for(self, hardware: str) -> Optional[str]:
        """
        Return the strategy with the highest recorded speedup for a hardware type.

        Args:
            hardware: Hardware description to query (e.g. "Apple M2").

        Returns:
            Strategy name string, or None if no results found.
        """
        results = self.recall_strategy(hardware=hardware, limit=20)
        best_speedup = 0.0
        best_strategy = None

        for doc in results:
            meta = getattr(doc, "metadata", {}) or {}
            speedup = float(meta.get("speedup", 0))
            strategy = meta.get("strategy")
            if speedup > best_speedup and strategy:
                best_speedup = speedup
                best_strategy = strategy

        if best_strategy:
            logger.info(
                f"[KitsuneMemory] Best recalled strategy for {hardware}: "
                f"{best_strategy} ({best_speedup:.2f}x)"
            )
        return best_strategy
