"""
💎 Kitsune Quantization Utilities

Provides hardware-aware quantization for local AI models.
Focuses on memory reduction for Apple Silicon and RTX GPUs.
"""

import torch
import torch.nn as nn
import logging
from typing import Optional, Dict, Any

from .device_config import detect_hardware, DeviceType

logger = logging.getLogger(__name__)

def quantize_model_for_local_ai(
    model: nn.Module, 
    bits: int = 8, 
    device: Optional[torch.device] = None
) -> nn.Module:
    """
    Quantize a model for local AI usage based on hardware capabilities.
    
    Args:
        model: Model to quantize
        bits: Target bits (8 or 4)
        device: Target device
        
    Returns:
        Quantized model
    """
    hw = detect_hardware()
    if device is None:
        if hw.device_type == DeviceType.APPLE_SILICON:
            device = torch.device("mps")
        elif hw.device_type != DeviceType.CPU:
            device = torch.device("cuda")
        else:
            device = torch.device("cpu")
            
    logger.info(f"💎 Quantizing model for {hw.device_type.value} ({bits}-bit)")
    
    if bits == 8:
        return _quantize_int8(model, hw)
    elif bits == 4:
        return _quantize_4bit_simulated(model, hw)
    else:
        logger.warning(f"Unsupported bit depth: {bits}. Returning original model.")
        return model

def _quantize_int8(model: nn.Module, hw: Any) -> nn.Module:
    """Apply INT8 quantization."""
    if hw.device_type == DeviceType.CPU:
        # Use standard PyTorch CPU quantization
        from .device_config import prepare_int8_quantization
        # Needs sample input for calibration in a real scenario
        # Here we return model as-is if no sample input, or use dynamic quantization
        try:
            quantized_model = torch.quantization.quantize_dynamic(
                model, {nn.Linear}, dtype=torch.qint8
            )
            logger.info("  ✓ Dynamic INT8 quantization applied (CPU)")
            return quantized_model
        except Exception as e:
            logger.error(f"  ✗ Dynamic quantization failed: {e}")
            return model
            
    elif hw.device_type == DeviceType.APPLE_SILICON:
        # MPS doesn't support standard PyTorch quantization well yet
        # We can use weight-only quantization
        logger.info("  ⚠ MPS INT8 quantization is weight-only simulation")
        return _weight_only_quantization(model, bits=8)
        
    else:
        # CUDA
        if hw.supports_int8_tensor_cores:
            logger.info("  ✓ Hardware supports INT8 Tensor Cores")
            # In a real library, we'd use TensorRT or bitsandbytes here
            return _weight_only_quantization(model, bits=8)
        else:
            return _weight_only_quantization(model, bits=8)

def _quantize_4bit_simulated(model: nn.Module, hw: Any) -> nn.Module:
    """Simulate 4-bit quantization (weight-only)."""
    logger.info("  💎 4-bit Quantization (Local Dev AI Focus)")
    if hw.device_type == DeviceType.APPLE_SILICON:
        logger.info("  🍎 Optimizing for Apple Silicon Neural Engine (simulated)")
    
    return _weight_only_quantization(model, bits=4)

def _weight_only_quantization(model: nn.Module, bits: int = 8) -> nn.Module:
    """
    Simple weight-only quantization.
    This reduces memory footprint but might not improve speed without custom kernels.
    """
    for name, module in model.named_modules():
        if isinstance(module, nn.Linear):
            # Quantize weights
            w = module.weight.data
            
            # Simple Min-Max quantization
            q_min = -(2**(bits-1))
            q_max = 2**(bits-1) - 1
            
            scale = (w.max() - w.min()) / (q_max - q_min)
            zero_point = q_min - (w.min() / scale)
            
            # Simulated quantization (dequantize immediately for computation)
            w_q = torch.clamp(torch.round(w / scale + zero_point), q_min, q_max)
            w_dq = (w_q - zero_point) * scale
            
            module.weight.data = w_dq
            
    logger.info(f"  ✓ Weight-only {bits}-bit quantization applied to Linear layers")
    return model
