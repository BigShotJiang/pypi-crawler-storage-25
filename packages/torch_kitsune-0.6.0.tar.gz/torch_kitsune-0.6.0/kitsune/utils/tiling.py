"""
🧩 Tiled Inference Utility for Large Vision Models (LVMs)

Allows processing high-resolution images (4K, 8K) on local machines
with limited memory by splitting them into tiles.
"""

import torch
import torch.nn as nn
from typing import Tuple, List, Optional, Callable
import logging

from ..memory.pool import get_memory_pool

logger = logging.getLogger(__name__)

class TiledInference:
    """
    Utility for performing tiled inference on large images.
    
    This reduces peak memory usage by processing the image in overlapping tiles
    and stitching them back together.
    """
    def __init__(
        self, 
        tile_size: Tuple[int, int] = (1024, 1024), 
        overlap: int = 64,
        use_memory_pool: bool = True
    ):
        """
        Initialize TiledInference.
        
        Args:
            tile_size: (height, width) of each tile
            overlap: number of pixels to overlap between tiles
            use_memory_pool: whether to use Kitsune MemoryPool for tiles
        """
        self.tile_size = tile_size
        self.overlap = overlap
        self.use_memory_pool = use_memory_pool
        self.pool = get_memory_pool() if use_memory_pool else None

    def process(
        self, 
        model: nn.Module, 
        image: torch.Tensor,
        process_fn: Optional[Callable] = None
    ) -> torch.Tensor:
        """
        Process a large image using tiled inference.
        
        Args:
            model: The model to use for processing
            image: Input image tensor (C, H, W) or (B, C, H, W)
            process_fn: Optional custom processing function (model, tile) -> tile_out
            
        Returns:
            Processed image tensor
        """
        if image.dim() == 3:
            # (C, H, W) -> (1, C, H, W)
            image = image.unsqueeze(0)
            
        B, C, H, W = image.shape
        TH, TW = self.tile_size
        O = self.overlap
        
        device = image.device
        dtype = image.dtype
        
        # Determine output shape
        model.eval()
        with torch.no_grad():
            dummy_tile = image[:, :, :min(TH, H), :min(TW, W)]
            if process_fn:
                dummy_out = process_fn(model, dummy_tile)
            else:
                dummy_out = model(dummy_tile)
            out_C = dummy_out.shape[1]
            
        # Initialize output and weight (for averaging)
        output = torch.zeros((B, out_C, H, W), device=device, dtype=dtype)
        weights = torch.zeros((1, 1, H, W), device=device, dtype=dtype)
        
        # Calculate grid
        # To cover the whole image with overlap:
        # We start at 0, 0. Next start is TH - O.
        stride_h = TH - O
        stride_w = TW - O
        
        h_starts = []
        curr_h = 0
        while curr_h + TH < H:
            h_starts.append(curr_h)
            curr_h += stride_h
        h_starts.append(max(0, H - TH))
        
        w_starts = []
        curr_w = 0
        while curr_w + TW < W:
            w_starts.append(curr_w)
            curr_w += stride_w
        w_starts.append(max(0, W - TW))
        
        # Remove duplicates if any
        h_starts = sorted(list(set(h_starts)))
        w_starts = sorted(list(set(w_starts)))

        logger.info(f"TiledInference: Processing {H}x{W} image in {len(h_starts)}x{len(w_starts)} tiles")
        
        with torch.no_grad():
            for h_start in h_starts:
                for w_start in w_starts:
                    h_end = h_start + TH
                    w_end = w_start + TW
                    
                    # Extract tile
                    tile = image[:, :, h_start:min(h_end, H), w_start:min(w_end, W)]
                    
                    # Process tile
                    if process_fn:
                        tile_out = process_fn(model, tile)
                    else:
                        tile_out = model(tile)
                    
                    # Accumulate
                    # We might have processed a smaller tile if image < TH/TW
                    actual_h = tile_out.shape[2]
                    actual_w = tile_out.shape[3]
                    
                    output[:, :, h_start:h_start+actual_h, w_start:w_start+actual_w] += tile_out
                    weights[:, :, h_start:h_start+actual_h, w_start:w_start+actual_w] += 1.0
                    
                    if device.type == "mps":
                        torch.mps.synchronize()
                        if self.use_memory_pool:
                            torch.mps.empty_cache()

        return output / weights
