"""
Kitsune — GPU Planning for PyTorch

Never OOM again. Predict peak GPU memory, max batch size, and cheapest
GPU for any PyTorch model — before you run.

Quick start:
    >>> from kitsune.predict import predict_memory, plan_gpu, sweep_batch_sizes
    >>> result = predict_memory(model, input_shape=(3, 224, 224), gpu="t4")
    >>> print(result.summary())
    Peak: 3.71 GB | Tesla T4 (16 GB): FITS

    >>> plan = plan_gpu(model, input_shape=(3, 224, 224), training=True)
    >>> print(plan.cheapest.gpu.name, f"${plan.cheapest.cost_per_hr:.2f}/hr")
    NVIDIA RTX 3080 $0.30/hr

CLI:
    $ kitsune predict --hf bert-base-uncased --batch-size 32 --gpu t4
    $ kitsune plan --hf bert-large-uncased --training --daily-budget 50
    $ kitsune predict model.py:ResNet50 --input-shape 3,224,224 --sweep --gpu a100-80gb
"""

__version__ = "0.6.0"

from .predict import (
    PredictionResult,
    PlanResult,
    SweepResult,
    plan_gpu,
    predict_memory,
    sweep_batch_sizes,
    LoRAConfig,
    LoRAPrediction,
    estimate_lora_memory,
    KVCacheConfig,
    KVCacheResult,
    KVSweepResult,
    estimate_kv_cache,
    sweep_kv_seq_lens,
)


def predict_hf_memory(model_id: str, **kwargs):
    """Predict GPU memory for a HuggingFace model. Requires: pip install transformers"""
    from .predict.hf_integration import predict_hf_memory as _impl
    return _impl(model_id, **kwargs)


def sweep_hf_batch_sizes(model_id: str, **kwargs):
    """Sweep batch sizes for a HuggingFace model. Requires: pip install transformers"""
    from .predict.hf_integration import sweep_hf_batch_sizes as _impl
    return _impl(model_id, **kwargs)


__all__ = [
    "__version__",
    "predict_memory",
    "PredictionResult",
    "sweep_batch_sizes",
    "SweepResult",
    "plan_gpu",
    "PlanResult",
    "predict_hf_memory",
    "sweep_hf_batch_sizes",
    "estimate_lora_memory",
    "LoRAConfig",
    "LoRAPrediction",
    "estimate_kv_cache",
    "sweep_kv_seq_lens",
    "KVCacheConfig",
    "KVCacheResult",
    "KVSweepResult",
]
