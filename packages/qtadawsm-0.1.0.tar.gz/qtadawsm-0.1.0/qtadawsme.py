import argparse
from pathlib import Path
from qtadawsm_core import encode_text


def read_input(value: str) -> str:
    path = Path(value)
    if path.exists() and path.is_file():
        return path.read_text(encoding="utf-8")
    return value


def main():
    parser = argparse.ArgumentParser(description="Encode text/file to qtadaWsM whitespace-Morse")
    parser.add_argument("input", help="Input plain text or file path")
    parser.add_argument("-o", "--output", help="Output file")
    args = parser.parse_args()

    text = read_input(args.input)
    encoded = encode_text(text)

    if args.output:
        Path(args.output).write_text(encoded, encoding="utf-8")
    else:
        print(encoded, end="")


if __name__ == "__main__":
    main()