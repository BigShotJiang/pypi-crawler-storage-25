MORSE = {
    "A": ".-", "B": "-...", "C": "-.-.", "D": "-..", "E": ".",
    "F": "..-.", "G": "--.", "H": "....", "I": "..", "J": ".---",
    "K": "-.-", "L": ".-..", "M": "--", "N": "-.", "O": "---",
    "P": ".--.", "Q": "--.-", "R": ".-.", "S": "...", "T": "-",
    "U": "..-", "V": "...-", "W": ".--", "X": "-..-", "Y": "-.--",
    "Z": "--..",

    "0": "-----", "1": ".----", "2": "..---", "3": "...--",
    "4": "....-", "5": ".....", "6": "-....", "7": "--...",
    "8": "---..", "9": "----.",

    ".": ".-.-.-", ",": "--..--", "?": "..--..", "'": ".----.",
    "!": "-.-.--", "/": "-..-.", "(": "-.--.", ")": "-.--.-",
    "&": ".-...", ":": "---...", ";": "-.-.-.", "=": "-...-",
    "+": ".-.-.", "-": "-....-", "_": "..--.-", '"': ".-..-.",
    "$": "...-..-", "@": ".--.-.", " ": "/"
}

REVERSE_MORSE = {v: k for k, v in MORSE.items()}

DOT = " "
DASH = "\t"
LETTER_SEP = "\n"
WORD_SEP = "\n\n"


def encode_text(text: str) -> str:
    encoded_letters = []

    for char in text.upper():
        if char == "\n":
            encoded_letters.append("/")
            continue

        if char not in MORSE:
            raise ValueError(f"Unsupported character: {char!r}")

        if char == " ":
            encoded_letters.append("")
            continue

        morse = MORSE[char]
        encoded = "".join(DOT if s == "." else DASH for s in morse)
        encoded_letters.append(encoded)

    return LETTER_SEP.join(encoded_letters)


def decode_text(data: str) -> str:
    result = []

    for part in data.split(LETTER_SEP):
        if part == "":
            result.append(" ")
            continue

        morse = "".join(
            "." if c == DOT else "-" if c == DASH else ""
            for c in part
        )

        if morse == "/":
            result.append("\n")
        elif morse in REVERSE_MORSE:
            result.append(REVERSE_MORSE[morse])
        else:
            raise ValueError(f"Invalid whitespace-Morse sequence: {morse!r}")

    return "".join(result)