# qtadaWsM

Whitespace-Morse encoder/decoder.

Convert text into invisible whitespace (spaces/tabs/newlines) using a Morse-like encoding and decode it back.

## Installation

```bash
pip install qtadawsm