import argparse
from pathlib import Path
from qtadawsm_core import decode_text


def read_input(value: str) -> str:
    path = Path(value)
    if path.exists() and path.is_file():
        return path.read_text(encoding="utf-8")
    return value


def main():
    parser = argparse.ArgumentParser(description="Decode qtadaWsM whitespace-Morse text/file")
    parser.add_argument("input", help="Input whitespace-Morse string or file path")
    parser.add_argument("-o", "--output", help="Output file")
    args = parser.parse_args()

    data = read_input(args.input)
    decoded = decode_text(data)

    if args.output:
        Path(args.output).write_text(decoded, encoding="utf-8")
    else:
        print(decoded, end="")


if __name__ == "__main__":
    main()