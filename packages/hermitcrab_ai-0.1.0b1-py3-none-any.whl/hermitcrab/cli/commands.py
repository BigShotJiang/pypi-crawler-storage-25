"""CLI commands for hermitcrab."""

import asyncio
import os
import re
import select
import shutil
import signal
import sys
import tempfile
from pathlib import Path
from typing import Any

import typer
from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.history import FileHistory
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.patch_stdout import patch_stdout
from prompt_toolkit.shortcuts import print_formatted_text
from rich.console import Console
from rich.markdown import Markdown
from rich.table import Table
from rich.text import Text

from hermitcrab import __logo__, __version__
from hermitcrab.config.schema import Config, ModelAliasConfig

app = typer.Typer(
    name="hermitcrab",
    help=f"{__logo__} hermitcrab - Personal AI Assistant",
    no_args_is_help=True,
)

console = Console()
EXIT_COMMANDS = {"exit", "quit", "/exit", "/quit", ":q"}

# ---------------------------------------------------------------------------
# CLI input: prompt_toolkit for editing, paste, history, and display
# ---------------------------------------------------------------------------

_PROMPT_SESSION: PromptSession | None = None
_SAVED_TERM_ATTRS = None  # original termios settings, restored on exit
_ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def _build_job_models_from_config(config: Config) -> dict | None:
    """
    Build job_models dict from config for AgentLoop initialization.

    Args:
        config: Root configuration object.

    Returns:
        Dict mapping JobClass to model string (or None to skip).
        Returns None if no job models configured (use defaults).
    """
    from hermitcrab.agent.loop import JobClass

    job_models_config = config.agents.defaults.job_models

    # Check if any job models are actually configured
    has_config = (
        job_models_config.interactive_response
        or job_models_config.journal_synthesis is not None
        or job_models_config.distillation is not None
        or job_models_config.reflection is not None
        or job_models_config.summarisation is not None
        or job_models_config.subagent is not None
    )

    if not has_config:
        return None  # Use AgentLoop defaults

    primary_model = config.agents.defaults.model

    return {
        JobClass.INTERACTIVE_RESPONSE: job_models_config.get_model(
            "interactive_response", primary_model
        ),
        JobClass.JOURNAL_SYNTHESIS: job_models_config.get_model("journal_synthesis", primary_model),
        JobClass.DISTILLATION: job_models_config.get_model("distillation", primary_model),
        JobClass.REFLECTION: job_models_config.get_model("reflection", primary_model),
        JobClass.SUMMARISATION: job_models_config.get_model("summarisation", primary_model),
        JobClass.SUBAGENT: job_models_config.get_model("subagent", primary_model),
    }


def _build_runtime_model_aliases(config: Config) -> dict[str, str | ModelAliasConfig]:
    """Resolve any named-model references inside runtime aliases."""
    resolved_aliases: dict[str, str | ModelAliasConfig] = {}
    for alias, value in config.agents.model_aliases.items():
        if isinstance(value, ModelAliasConfig):
            resolved = config.resolve_model_config(value.model)
            resolved_aliases[alias] = ModelAliasConfig(
                model=value.model,
                reasoning_effort=value.reasoning_effort or resolved.reasoning_effort,
                thinking=value.thinking,
            )
            continue

        resolved_aliases[alias] = (
            value if value in config.models else (config.resolve_model_config(value).model or value)
        )

    return resolved_aliases


def _get_tty_stdin_fd() -> int | None:
    """Return the stdin file descriptor when attached to a TTY."""
    try:
        fd = sys.stdin.fileno()
    except (AttributeError, OSError, ValueError):
        return None
    return fd if os.isatty(fd) else None


def _atomic_write_text(path: Path, content: str) -> None:
    """Write text atomically to avoid leaving partial template files behind."""
    path.parent.mkdir(parents=True, exist_ok=True)

    tmp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            encoding="utf-8",
            dir=path.parent,
            delete=False,
        ) as tmp:
            tmp.write(content)
            tmp_path = Path(tmp.name)
        tmp_path.replace(path)
    except OSError:
        if tmp_path is not None:
            tmp_path.unlink(missing_ok=True)
        raise


def _should_render_progress(channels_config: Any, *, is_tool_hint: bool) -> bool:
    """Apply channel progress visibility rules consistently across CLI modes."""
    if channels_config is None:
        return True
    if is_tool_hint:
        return bool(channels_config.send_tool_hints)
    return bool(channels_config.send_progress)


def _build_reflection_config(config: Config) -> dict[str, Any]:
    """Build reflection promotion settings for AgentLoop."""
    return {
        "auto_promote": config.reflection.promotion.auto_promote,
        "target_files": config.reflection.promotion.target_files,
        "max_file_lines": config.reflection.promotion.max_file_lines,
        "notify_user": config.reflection.promotion.notify_user,
    }


def _build_agent_loop_kwargs(
    config: Config,
    provider: Any,
    *,
    cron_service: Any | None = None,
    session_manager: Any | None = None,
) -> dict[str, Any]:
    """Build the shared AgentLoop configuration used by CLI entrypoints."""
    return {
        "provider": provider,
        "workspace": config.workspace_path,
        "model": config.agents.defaults.model,
        "temperature": config.agents.defaults.temperature,
        "max_tokens": config.agents.defaults.max_tokens,
        "max_iterations": config.agents.defaults.max_tool_iterations,
        "memory_window": config.agents.defaults.memory_window,
        "brave_api_key": config.tools.web.search.api_key or None,
        "exec_config": config.tools.exec,
        "cron_service": cron_service,
        "restrict_to_workspace": config.tools.restrict_to_workspace,
        "session_manager": session_manager,
        "mcp_servers": config.tools.mcp_servers,
        "channels_config": config.channels,
        "job_models": _build_job_models_from_config(config),
        "distillation_enabled": config.agents.defaults.enable_distillation,
        "model_aliases": _build_runtime_model_aliases(config),
        "named_models": config.models,
        "reasoning_effort_config": {
            "reasoning_effort": config.agents.defaults.job_models.reasoning_effort,
        },
        "inactivity_timeout_s": config.agents.defaults.inactivity_timeout_s,
        "llm_max_retries": config.agents.defaults.llm_max_retries,
        "llm_retry_base_delay_s": config.agents.defaults.llm_retry_base_delay_s,
        "max_loop_seconds": config.agents.defaults.max_loop_seconds,
        "max_identical_tool_cycles": config.agents.defaults.max_identical_tool_cycles,
        "memory_context_max_chars": config.agents.defaults.memory_context_max_chars,
        "memory_context_max_items_per_category": config.agents.defaults.memory_context_max_items_per_category,
        "memory_context_max_item_chars": config.agents.defaults.memory_context_max_item_chars,
        "reflection_config": _build_reflection_config(config),
    }


def _flush_pending_tty_input() -> None:
    """Drop unread keypresses typed while the model was generating output."""
    fd = _get_tty_stdin_fd()
    if fd is None:
        return

    try:
        import termios

        termios.tcflush(fd, termios.TCIFLUSH)
        return
    except (ImportError, OSError, ValueError, termios.error):
        pass

    try:
        while True:
            ready, _, _ = select.select([fd], [], [], 0)
            if not ready:
                break
            if not os.read(fd, 4096):
                break
    except OSError:
        return


def _restore_terminal() -> None:
    """Restore terminal to its original state (echo, line buffering, etc.)."""
    if _SAVED_TERM_ATTRS is None:
        return
    try:
        import termios

        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, _SAVED_TERM_ATTRS)
    except (ImportError, OSError, ValueError, termios.error):
        pass


def _init_prompt_session() -> None:
    """Create the prompt_toolkit session with persistent file history."""
    global _PROMPT_SESSION, _SAVED_TERM_ATTRS

    # Save terminal state so we can restore it on exit
    try:
        import termios

        _SAVED_TERM_ATTRS = termios.tcgetattr(sys.stdin.fileno())
    except (ImportError, OSError, ValueError, termios.error):
        pass

    history_file = Path.home() / ".hermitcrab" / "history" / "cli_history"
    history_file.parent.mkdir(parents=True, exist_ok=True)

    key_bindings = _build_prompt_key_bindings()

    _PROMPT_SESSION = PromptSession(
        history=FileHistory(str(history_file)),
        enable_open_in_editor=False,
        multiline=True,
        key_bindings=key_bindings,
    )


def _build_prompt_key_bindings() -> KeyBindings:
    """Build prompt-toolkit bindings for submit-vs-newline behavior."""
    bindings = KeyBindings()

    @bindings.add("c-m")
    def _submit(event) -> None:
        event.current_buffer.validate_and_handle()

    @bindings.add("c-j")
    def _newline(event) -> None:
        event.current_buffer.insert_text("\n")

    return bindings


async def _watch_for_escape(on_escape) -> None:
    """Watch stdin for Esc while the agent is busy and trigger cancellation."""
    fd = _get_tty_stdin_fd()
    if fd is None:
        return

    try:
        import termios
        import tty

        saved = termios.tcgetattr(fd)
        tty.setcbreak(fd)
    except (ImportError, OSError, ValueError, termios.error):
        return

    loop = asyncio.get_running_loop()
    escape_pressed = asyncio.Event()

    def _on_stdin_ready() -> None:
        try:
            data = os.read(fd, 32)
        except OSError:
            return
        if b"\x1b" in data:
            escape_pressed.set()

    loop.add_reader(fd, _on_stdin_ready)
    try:
        await escape_pressed.wait()
        await on_escape()
    except asyncio.CancelledError:
        raise
    finally:
        loop.remove_reader(fd)
        try:
            termios.tcsetattr(fd, termios.TCSADRAIN, saved)
        except (OSError, ValueError, termios.error):
            pass


def _strip_ansi(text: str) -> str:
    """Remove terminal escape sequences from model output before plain rendering."""
    return _ANSI_ESCAPE_RE.sub("", text)


def _print_agent_response(
    response: str, render_markdown: bool, *, prompt_safe: bool = False
) -> None:
    """Render assistant response with consistent terminal styling."""
    content = response or ""
    try:
        if prompt_safe:
            clean = _strip_ansi(content)
            print_formatted_text("")
            print_formatted_text(HTML("<ansicyan>🦀 hermitcrab</ansicyan>"))
            print_formatted_text(clean)
            print_formatted_text("")
            return

        body = Markdown(content) if render_markdown else Text(content)
        console.print()
        console.print(f"[cyan]{__logo__} hermitcrab[/cyan]")
        console.print(body)
        console.print()
    except (BrokenPipeError, OSError, ValueError):
        return


def _load_runtime_config() -> Config:
    """Load config strictly for runtime commands that should fail clearly."""
    from hermitcrab.config.loader import ConfigLoadError, load_config

    try:
        return load_config(strict=True)
    except ConfigLoadError as exc:
        console.print("[red]Error: Failed to load config.[/red]")
        console.print(f"Path: {exc.path}")
        console.print(f"Reason: {exc}")
        console.print("Fix the file or run [cyan]hermitcrab doctor[/cyan] for diagnostics.")
        raise typer.Exit(1) from exc


def _is_exit_command(command: str) -> bool:
    """Return True when input should end interactive chat."""
    return command.lower() in EXIT_COMMANDS


async def _read_interactive_input_async() -> str:
    """Read user input using prompt_toolkit (handles paste, history, display).

    prompt_toolkit natively handles:
    - Multiline paste (bracketed paste mode)
    - History navigation (up/down arrows)
    - Clean display (no ghost characters or artifacts)
    - Ctrl+J inserts a newline; Enter submits
    """
    if _PROMPT_SESSION is None:
        raise RuntimeError("Call _init_prompt_session() first")
    try:
        with patch_stdout():
            return await _PROMPT_SESSION.prompt_async(
                HTML("<b fg='ansiblue'>You:</b> "),
            )
    except EOFError as exc:
        raise KeyboardInterrupt from exc


def version_callback(value: bool):
    if value:
        console.print(f"{__logo__} hermitcrab v{__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(None, "--version", "-v", callback=version_callback, is_eager=True),
):
    """hermitcrab - Personal AI Assistant."""
    pass


# ============================================================================
# Onboard / Setup
# ============================================================================


@app.command()
def onboard():
    """Initialize hermitcrab configuration and workspace."""
    from hermitcrab.config.loader import get_config_path, load_config, save_config
    from hermitcrab.config.schema import Config
    from hermitcrab.utils.helpers import get_workspace_path

    config_path = get_config_path()

    if config_path.exists():
        console.print(f"[yellow]Config already exists at {config_path}[/yellow]")
        console.print("  [bold]y[/bold] = overwrite with defaults (existing values will be lost)")
        console.print(
            "  [bold]N[/bold] = refresh config, keeping existing values and adding new fields"
        )
        if typer.confirm("Overwrite?"):
            config = Config()
            save_config(config)
            console.print(f"[green]✓[/green] Config reset to defaults at {config_path}")
        else:
            config = load_config()
            save_config(config)
            console.print(
                f"[green]✓[/green] Config refreshed at {config_path} (existing values preserved)"
            )
    else:
        save_config(Config())
        console.print(f"[green]✓[/green] Created config at {config_path}")

    # Create workspace
    workspace = get_workspace_path()

    if not workspace.exists():
        workspace.mkdir(parents=True, exist_ok=True)
        console.print(f"[green]✓[/green] Created workspace at {workspace}")

    # Create default bootstrap files
    _create_workspace_templates(workspace)

    console.print(f"\n{__logo__} hermitcrab is ready!")
    for line in _build_onboard_next_steps():
        console.print(line)


def _create_workspace_templates(workspace: Path):
    """Create default workspace template files from bundled templates."""
    from importlib.resources import files as pkg_files

    templates_dir = pkg_files("hermitcrab") / "templates"

    for item in templates_dir.iterdir():
        if not item.name.endswith(".md"):
            continue
        dest = workspace / item.name
        if not dest.exists():
            _atomic_write_text(dest, item.read_text(encoding="utf-8"))
            console.print(f"  [dim]Created {item.name}[/dim]")

    # Create category-based memory directories
    memory_dir = workspace / "memory"
    memory_dir.mkdir(exist_ok=True)

    for category in ["facts", "decisions", "goals", "tasks", "reflections"]:
        category_dir = memory_dir / category
        category_dir.mkdir(exist_ok=True)
        console.print(f"  [dim]Created memory/{category}/[/dim]")

    # Create knowledge base directories (reference library, not memory)
    knowledge_dir = workspace / "knowledge"
    knowledge_dir.mkdir(exist_ok=True)

    for category in ["articles", "books", "docs", "notes"]:
        category_dir = knowledge_dir / category
        category_dir.mkdir(exist_ok=True)
        console.print(f"  [dim]Created knowledge/{category}/[/dim]")

    scratchpads_dir = workspace / "scratchpads"
    scratchpads_dir.mkdir(exist_ok=True)
    (scratchpads_dir / "archive").mkdir(exist_ok=True)
    console.print("  [dim]Created scratchpads/ and scratchpads/archive/[/dim]")

    (workspace / "skills").mkdir(exist_ok=True)


def _build_onboard_next_steps() -> list[str]:
    """Build concise first-run guidance based on the local environment."""
    lines = ["\nNext steps:"]

    if shutil.which("ollama"):
        lines.extend(
            [
                "  1. Recommended local setup detected: [cyan]ollama[/cyan] is installed",
                "     Start it with [cyan]ollama serve[/cyan] and pull a model like [cyan]ollama pull qwen3.5:4b[/cyan]",
                "  2. Review [cyan]~/.hermitcrab/config.json[/cyan] and point your main model at Ollama or your preferred provider",
                "  3. Verify setup: [cyan]hermitcrab status[/cyan] or [cyan]hermitcrab doctor[/cyan]",
                '  4. Start chatting: [cyan]hermitcrab agent[/cyan] or [cyan]hermitcrab agent -m "Hello!"[/cyan]',
            ]
        )
        return lines

    lines.extend(
        [
            "  1. Choose a provider in [cyan]~/.hermitcrab/config.json[/cyan]",
            "     - Local: install [cyan]Ollama[/cyan] from https://ollama.com and use its local OpenAI-compatible endpoint",
            "     - Cloud: add an API key such as OpenRouter from https://openrouter.ai/keys",
            "  2. Verify setup: [cyan]hermitcrab status[/cyan] or [cyan]hermitcrab doctor[/cyan]",
            '  3. Start chatting: [cyan]hermitcrab agent[/cyan] or [cyan]hermitcrab agent -m "Hello!"[/cyan]',
        ]
    )
    return lines


def _make_provider(config: Config):
    """Create the appropriate LLM provider from config."""
    from hermitcrab.providers.custom_provider import CustomProvider
    from hermitcrab.providers.litellm_provider import LiteLLMProvider
    from hermitcrab.providers.ollama_provider import OllamaProvider
    from hermitcrab.providers.openai_codex_provider import OpenAICodexProvider

    model = config.agents.defaults.model
    resolved_model = config.resolve_model_config(model)
    provider_name = config.get_provider_name(model)
    p = config.get_provider(model)

    if provider_name is None:
        console.print("[red]Error: Could not resolve a provider for the selected model.[/red]")
        console.print(f"Model: {model}")
        console.print("Check [cyan]hermitcrab status[/cyan] or [cyan]hermitcrab doctor[/cyan].")
        raise typer.Exit(1)

    def _uses_ollama_anywhere() -> bool:
        candidates: set[str] = set()

        if model:
            candidates.add(model)

        job_models = config.agents.defaults.job_models
        for value in (
            job_models.interactive_response,
            job_models.journal_synthesis,
            job_models.distillation,
            job_models.reflection,
            job_models.summarisation,
            job_models.subagent,
        ):
            if isinstance(value, str) and value.strip():
                candidates.add(value.strip())

        for name, named_model in config.models.items():
            candidates.add(name)
            if named_model.model:
                candidates.add(named_model.model)

        for alias_name, alias_value in config.agents.model_aliases.items():
            candidates.add(alias_name)
            if isinstance(alias_value, str) and alias_value.strip():
                candidates.add(alias_value.strip())
            elif getattr(alias_value, "model", None):
                candidates.add(alias_value.model)

        return any(config.get_provider_name(candidate) == "ollama" for candidate in candidates)

    # OpenAI Codex (OAuth)
    if provider_name == "openai_codex" or model.startswith("openai-codex/"):
        return OpenAICodexProvider(default_model=resolved_model.model or model)

    # Custom: direct OpenAI-compatible endpoint, bypasses LiteLLM
    if provider_name == "custom":
        return CustomProvider(
            api_key=p.api_key if p else "no-key",
            api_base=config.get_api_base(model) or "http://localhost:8000/v1",
            default_model=resolved_model.model or model,
        )

    from hermitcrab.providers.registry import find_by_name

    def _request_config_resolver(request_model: str) -> dict[str, Any]:
        resolved_request = config.resolve_model_config(request_model)
        request_provider = config.get_provider(request_model)
        request_provider_name = config.get_provider_name(request_model)
        return {
            "model": resolved_request.model or request_model,
            "api_key": request_provider.api_key if request_provider else None,
            "api_base": config.get_api_base(request_model),
            "extra_headers": request_provider.extra_headers if request_provider else None,
            "provider_name": request_provider_name,
            "provider_options": resolved_request.provider_options or {},
            "reasoning_effort": resolved_request.reasoning_effort,
        }

    spec = find_by_name(provider_name)

    # Special handling for Ollama - show helpful message if misconfigured
    resolved_model_name = resolved_model.model or model

    if provider_name == "ollama" or "ollama" in resolved_model_name.lower():
        # Check if api_base is explicitly set to None/empty (not using default)
        ollama_config = config.providers.ollama if hasattr(config.providers, "ollama") else None
        api_base = config.get_api_base(model)

        # If user explicitly configured ollama provider but with null/empty api_base
        if ollama_config and ollama_config.api_base is None and api_base is None:
            console.print("[yellow]Warning: Ollama provider configured without api_base.[/yellow]")
            console.print("Using default: http://localhost:11434")
            console.print("\n[dim]If this is wrong, edit ~/.hermitcrab/config.json:[/dim]")
            console.print("""{
  "providers": {
    "ollama": {
      "apiBase": "http://localhost:11434"
    }
  },
  "agents": {
    "defaults": {
      "model": "ollama_chat/llama3.1"
    }
  }
}""")
            console.print("\n[dim]Notes:[/dim]")
            console.print("  • Use [bold]ollama_chat/[/bold] prefix for chat models (recommended)")
            console.print("  • Or [bold]ollama/[/bold] for text completion")
            console.print("  • api_base should NOT include /v1 suffix")

    if (
        not resolved_model_name.startswith("bedrock/")
        and not (p and p.api_key)
        and not (spec and (spec.is_oauth or spec.is_local))
    ):
        console.print("[red]Error: No API key configured for the selected provider.[/red]")
        console.print(f"Provider: {provider_name}")
        console.print(f"Model: {resolved_model_name}")
        console.print(
            "Set it in ~/.hermitcrab/config.json or run [cyan]hermitcrab doctor[/cyan]."
        )
        raise typer.Exit(1)

    fallback_provider = LiteLLMProvider(
        api_key=p.api_key if p else None,
        api_base=config.get_api_base(model),
        default_model=model,
        extra_headers=p.extra_headers if p else None,
        provider_name=provider_name,
        request_config_resolver=_request_config_resolver,
    )

    if provider_name == "ollama" or _uses_ollama_anywhere():
        return OllamaProvider(
            api_key=p.api_key if p else None,
            api_base=config.get_api_base(model),
            default_model=model,
            extra_headers=p.extra_headers if p else None,
            request_config_resolver=_request_config_resolver,
            fallback_provider=fallback_provider,
        )

    return fallback_provider


# ============================================================================
# Gateway / Server
# ============================================================================


@app.command()
def gateway(
    port: int = typer.Option(18790, "--port", "-p", help="Gateway port"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
    log_level: str = typer.Option(
        "INFO",
        "--log-level",
        help="Log level: TRACE, DEBUG, INFO, WARNING, ERROR",
    ),
):
    """Start the hermitcrab gateway."""
    from loguru import logger

    from hermitcrab.agent.loop import AgentLoop
    from hermitcrab.bus.queue import MessageBus
    from hermitcrab.channels.manager import ChannelManager
    from hermitcrab.config.loader import get_data_dir
    from hermitcrab.cron.service import CronService
    from hermitcrab.cron.types import CronJob
    from hermitcrab.heartbeat.service import HeartbeatService
    from hermitcrab.session.manager import SessionManager
    from hermitcrab.session.timeout_service import SessionTimeoutService

    configured_level = "DEBUG" if verbose else log_level.upper()
    logger.remove()
    logger.add(sys.stderr, level=configured_level)

    console.print(f"{__logo__} Starting hermitcrab gateway on port {port}...")
    console.print(f"[dim]Log level: {configured_level}[/dim]")

    config = _load_runtime_config()
    bus = MessageBus()
    provider = _make_provider(config)
    session_manager = SessionManager(config.workspace_path)

    # Create cron service first (callback set after agent creation)
    cron_store_path = get_data_dir() / "cron" / "jobs.json"
    cron = CronService(cron_store_path)

    # Create agent with cron service
    agent = AgentLoop(
        bus=bus,
        **_build_agent_loop_kwargs(
            config,
            provider,
            cron_service=cron,
            session_manager=session_manager,
        ),
    )

    # Set cron callback (needs agent)
    async def on_cron_job(job: CronJob) -> str | None:
        """Execute a cron job through the agent."""
        response = await agent.process_direct(
            job.payload.message,
            session_key=f"cron:{job.id}",
            channel=job.payload.channel or "cli",
            chat_id=job.payload.to or "direct",
        )
        if job.payload.deliver and job.payload.to:
            from hermitcrab.bus.events import OutboundMessage

            await bus.publish_outbound(
                OutboundMessage(
                    channel=job.payload.channel or "cli",
                    chat_id=job.payload.to,
                    content=response or "",
                )
            )
        return response

    cron.on_job = on_cron_job

    # Create channel manager
    channels = ChannelManager(config, bus)

    def _pick_heartbeat_target() -> tuple[str, str]:
        """Pick a routable channel/chat target for heartbeat-triggered messages."""
        enabled = set(channels.enabled_channels)
        # Prefer the most recently updated non-internal session on an enabled channel.
        for item in session_manager.list_sessions():
            key = item.get("key") or ""
            if ":" not in key:
                continue
            channel, chat_id = key.split(":", 1)
            if channel in {"cli", "system"}:
                continue
            if channel in enabled and chat_id:
                return channel, chat_id
        # Fallback keeps prior behavior but remains explicit.
        return "cli", "direct"

    # Create heartbeat service
    async def on_heartbeat_execute(tasks: str) -> str:
        """Phase 2: execute heartbeat tasks through the full agent loop."""
        channel, chat_id = _pick_heartbeat_target()

        async def _silent(*_args, **_kwargs):
            pass

        return await agent.process_direct(
            tasks,
            session_key="heartbeat",
            channel=channel,
            chat_id=chat_id,
            on_progress=_silent,
        )

    async def on_heartbeat_notify(response: str) -> None:
        """Deliver a heartbeat response to the user's channel."""
        from hermitcrab.bus.events import OutboundMessage

        channel, chat_id = _pick_heartbeat_target()
        if channel == "cli":
            return  # No external channel available to deliver to
        await bus.publish_outbound(
            OutboundMessage(channel=channel, chat_id=chat_id, content=response)
        )

    hb_cfg = config.gateway.heartbeat
    heartbeat = HeartbeatService(
        workspace=config.workspace_path,
        provider=provider,
        model=agent.model,
        on_execute=on_heartbeat_execute,
        on_notify=on_heartbeat_notify,
        interval_s=hb_cfg.interval_s,
        enabled=hb_cfg.enabled,
    )
    timeout_monitor = SessionTimeoutService(
        agent.process_expired_sessions,
        interval_s=min(60, max(5, config.agents.defaults.inactivity_timeout_s // 6)),
        enabled=True,
    )

    if channels.enabled_channels:
        console.print(f"[green]✓[/green] Channels enabled: {', '.join(channels.enabled_channels)}")
    else:
        console.print("[yellow]Warning: No channels enabled[/yellow]")

    cron_status = cron.status()
    if cron_status["jobs"] > 0:
        console.print(f"[green]✓[/green] Cron: {cron_status['jobs']} scheduled jobs")

    console.print(f"[green]✓[/green] Heartbeat: every {hb_cfg.interval_s}s")

    async def run():
        try:
            await cron.start()
            await heartbeat.start()
            await timeout_monitor.start()
            await asyncio.gather(
                agent.run(),
                channels.start_all(),
            )
        except KeyboardInterrupt:
            console.print("\nShutting down...")
        finally:
            await agent.close()
            timeout_monitor.stop()
            heartbeat.stop()
            cron.stop()
            agent.stop()
            await channels.stop_all()

    asyncio.run(run())


# ============================================================================
# Nostr Listen Mode
# ============================================================================


def _run_nostr_mode(
    agent_loop: Any,
    bus: Any,
    nostr_pubkey: str,
    markdown: bool,
    thinking_ctx: Any,
    timeout_monitor: Any,
) -> None:
    """
    Run agent in Nostr listen mode.

    Listens for encrypted DMs from the specified pubkey and responds via Nostr.

    Args:
        agent_loop: AgentLoop instance for processing messages.
        bus: MessageBus for communication.
        nostr_pubkey: Nostr pubkey (npub or hex) to listen for.
        markdown: Whether to render responses as Markdown.
        thinking_ctx: Context manager for "thinking" spinner.
        timeout_monitor: Session timeout monitor service.
    """

    # Normalize pubkey to hex
    try:
        if nostr_pubkey.startswith("npub"):
            from pynostr.key import PublicKey

            hex_pubkey = PublicKey.from_npub(nostr_pubkey).hex()
        else:
            hex_pubkey = nostr_pubkey
    except Exception as e:
        console.print(f"[red]Invalid Nostr pubkey format: {e}[/red]")
        console.print("Use npub... or hex format")
        raise typer.Exit(1)

    session_key = f"nostr:{hex_pubkey}"

    console.print(f"{__logo__} Nostr listen mode")
    console.print(f"Listening for DMs from: [cyan]{nostr_pubkey[:10]}...[/cyan]")
    console.print(f"Session key: [dim]{session_key}[/dim]")
    console.print("Press Ctrl+C to quit\n")

    def _exit_on_sigint(signum, frame):
        _restore_terminal()
        console.print("\nGoodbye!")
        os._exit(0)

    signal.signal(signal.SIGINT, _exit_on_sigint)

    async def run_nostr_listen():
        await timeout_monitor.start()
        bus_task = asyncio.create_task(agent_loop.run())
        turn_done = asyncio.Event()
        turn_done.set()
        turn_response: list[str] = []

        async def _consume_outbound():
            """Consume outbound messages and print responses."""
            while True:
                try:
                    msg = await asyncio.wait_for(bus.consume_outbound(), timeout=1.0)
                    if msg.metadata.get("_progress"):
                        if not msg.content or not msg.content.strip():
                            continue
                        is_tool_hint = msg.metadata.get("_tool_hint", False)
                        if _should_render_progress(
                            agent_loop.channels_config,
                            is_tool_hint=is_tool_hint,
                        ):
                            console.print(f"  [dim]↳ {msg.content}[/dim]")
                    elif not turn_done.is_set():
                        if msg.content:
                            turn_response.append(msg.content)
                        turn_done.set()
                    elif msg.content:
                        _print_agent_response(
                            msg.content,
                            render_markdown=markdown,
                            prompt_safe=True,
                        )
                except asyncio.TimeoutError:
                    continue
                except asyncio.CancelledError:
                    break

        outbound_task = asyncio.create_task(_consume_outbound())

        try:
            while True:
                try:
                    # Wait for inbound message via bus
                    msg = await asyncio.wait_for(bus.consume_inbound(), timeout=1.0)

                    if msg.session_key != session_key:
                        continue

                    turn_done.clear()
                    turn_response.clear()

                    console.print(
                        f"\n[cyan]Received message from Nostr:[/cyan] {msg.content[:50]}..."
                    )

                    with thinking_ctx():
                        await turn_done.wait()

                    if turn_response:
                        _print_agent_response(turn_response[0], render_markdown=markdown)

                except asyncio.TimeoutError:
                    continue
                except asyncio.CancelledError:
                    break
        finally:
            timeout_monitor.stop()
            agent_loop.stop()
            outbound_task.cancel()
            await asyncio.gather(bus_task, outbound_task, return_exceptions=True)
            await agent_loop.close()

    asyncio.run(run_nostr_listen())


# ============================================================================
# Agent Commands
# ============================================================================


@app.command()
def agent(
    message: str = typer.Option(None, "--message", "-m", help="Message to send to the agent"),
    session_id: str = typer.Option("cli:direct", "--session", "-s", help="Session ID"),
    markdown: bool = typer.Option(
        True, "--markdown/--no-markdown", help="Render assistant output as Markdown"
    ),
    logs: bool = typer.Option(
        False, "--logs/--no-logs", help="Show hermitcrab runtime logs during chat"
    ),
    nostr_pubkey: str | None = typer.Option(
        None,
        "--nostr-pubkey",
        help="Nostr pubkey (npub or hex) to listen for DMs. If provided, starts Nostr listen loop instead of console input.",
    ),
):
    """
    Interact with the agent directly.

    Use --nostr-pubkey to listen for Nostr DMs, or run without flags for interactive CLI mode.
    """
    from loguru import logger

    from hermitcrab.agent.loop import AgentLoop
    from hermitcrab.bus.queue import MessageBus
    from hermitcrab.config.loader import get_data_dir
    from hermitcrab.cron.service import CronService
    from hermitcrab.session.timeout_service import SessionTimeoutService

    config = _load_runtime_config()

    bus = MessageBus()
    provider = _make_provider(config)

    # Create cron service for tool usage (no callback needed for CLI unless running)
    cron_store_path = get_data_dir() / "cron" / "jobs.json"
    cron = CronService(cron_store_path)

    if logs:
        logger.enable("hermitcrab")
    else:
        logger.disable("hermitcrab")

    agent_loop = AgentLoop(
        bus=bus,
        **_build_agent_loop_kwargs(config, provider, cron_service=cron),
    )
    timeout_monitor = SessionTimeoutService(
        agent_loop.process_expired_sessions,
        interval_s=min(60, max(5, config.agents.defaults.inactivity_timeout_s // 6)),
        enabled=bool(nostr_pubkey or not message),
    )

    # Show spinner when logs are off (no output to miss); skip when logs are on
    def _thinking_ctx():
        if logs:
            from contextlib import nullcontext

            return nullcontext()
        # Animated spinner is safe to use with prompt_toolkit input handling
        return console.status("[dim]hermitcrab is thinking...[/dim]", spinner="dots")

    async def _cli_progress(content: str, *, tool_hint: bool = False) -> None:
        if not content or not content.strip():
            return
        ch = agent_loop.channels_config
        if ch and tool_hint and not ch.send_tool_hints:
            return
        if ch and not tool_hint and not ch.send_progress:
            return
        console.print(f"  [dim]↳ {content}[/dim]")

    if message:
        # Single message mode — direct call, no bus needed
        async def run_once():
            with _thinking_ctx():
                response = await agent_loop.process_direct(
                    message, session_id, on_progress=_cli_progress
                )
            _print_agent_response(response, render_markdown=markdown)
            await agent_loop.close()

        asyncio.run(run_once())
    elif nostr_pubkey:
        # Nostr DM listen mode
        _run_nostr_mode(
            agent_loop=agent_loop,
            bus=bus,
            nostr_pubkey=nostr_pubkey,
            markdown=markdown,
            thinking_ctx=_thinking_ctx,
            timeout_monitor=timeout_monitor,
        )
    else:
        # Interactive mode — route through bus like other channels
        from hermitcrab.bus.events import InboundMessage

        if _get_tty_stdin_fd() is None:
            console.print("[red]Error: Interactive mode requires a TTY on stdin.[/red]")
            console.print(
                "Use [cyan]hermitcrab agent -m \"...\"[/cyan] for one-shot mode or run from a terminal."
            )
            raise typer.Exit(1)

        _init_prompt_session()
        console.print(
            f"{__logo__} Interactive mode (type [bold]exit[/bold] or [bold]Ctrl+C[/bold] to quit; press [bold]Esc[/bold] while working to stop the current task)\n"
        )

        if ":" in session_id:
            cli_channel, cli_chat_id = session_id.split(":", 1)
        else:
            cli_channel, cli_chat_id = "cli", session_id

        def _exit_on_sigint(signum, frame):
            _restore_terminal()
            console.print("\nGoodbye!")
            os._exit(0)

        signal.signal(signal.SIGINT, _exit_on_sigint)

        async def run_interactive():
            await timeout_monitor.start()
            bus_task = asyncio.create_task(agent_loop.run())
            turn_done = asyncio.Event()
            turn_done.set()
            turn_response: list[str] = []

            async def _consume_outbound():
                while True:
                    try:
                        msg = await asyncio.wait_for(bus.consume_outbound(), timeout=1.0)
                        if msg.metadata.get("_progress"):
                            if not msg.content or not msg.content.strip():
                                continue
                            is_tool_hint = msg.metadata.get("_tool_hint", False)
                            if _should_render_progress(
                                agent_loop.channels_config,
                                is_tool_hint=is_tool_hint,
                            ):
                                console.print(f"  [dim]↳ {msg.content}[/dim]")
                        elif not turn_done.is_set():
                            if msg.content:
                                turn_response.append(msg.content)
                            turn_done.set()
                        elif msg.content:
                            _print_agent_response(
                                msg.content,
                                render_markdown=markdown,
                                prompt_safe=True,
                            )
                    except asyncio.TimeoutError:
                        continue
                    except asyncio.CancelledError:
                        break

            outbound_task = asyncio.create_task(_consume_outbound())

            try:
                while True:
                    try:
                        _flush_pending_tty_input()
                        user_input = await _read_interactive_input_async()
                        command = user_input.strip()
                        if not command:
                            continue

                        if _is_exit_command(command):
                            # Finalize session so journal/distillation/reflection run on exit.
                            console.print("[dim]Finalizing session before exit...[/dim]")
                            try:
                                await agent_loop.process_direct(
                                    "/new",
                                    session_key=f"{cli_channel}:{cli_chat_id}",
                                    channel=cli_channel,
                                    chat_id=cli_chat_id,
                                )
                                # Wait up to 20s for background tasks (journal/distillation/reflection)
                                done, pending = await agent_loop.wait_for_background_tasks(
                                    timeout_s=20.0
                                )
                                if done > 0:
                                    console.print(f"[dim]Background tasks completed: {done}[/dim]")
                                if pending > 0:
                                    console.print(
                                        f"[yellow]Background tasks still running: {pending} "
                                        "(continuing shutdown)[/yellow]"
                                    )
                            except Exception as e:
                                console.print(f"[yellow]Session finalization failed: {e}[/yellow]")
                            _restore_terminal()
                            console.print("\nGoodbye!")
                            break

                        turn_done.clear()
                        turn_response.clear()

                        await bus.publish_inbound(
                            InboundMessage(
                                channel=cli_channel,
                                sender_id="user",
                                chat_id=cli_chat_id,
                                content=user_input,
                            )
                        )

                        stop_requested = False

                        async def _stop_active_turn() -> None:
                            nonlocal stop_requested
                            if stop_requested:
                                return
                            stop_requested = True
                            console.print(
                                "  [yellow]Esc pressed - stopping active work...[/yellow]"
                            )
                            cancelled = await agent_loop.cancel_active_work(
                                f"{cli_channel}:{cli_chat_id}",
                                cancel_background=True,
                            )
                            if not cancelled:
                                console.print("  [dim]No active work to stop.[/dim]")

                        escape_task = asyncio.create_task(_watch_for_escape(_stop_active_turn))
                        try:
                            with _thinking_ctx():
                                await turn_done.wait()
                        finally:
                            escape_task.cancel()
                            await asyncio.gather(escape_task, return_exceptions=True)

                        if turn_response:
                            _print_agent_response(turn_response[0], render_markdown=markdown)
                    except KeyboardInterrupt:
                        _restore_terminal()
                        console.print("\nGoodbye!")
                        break
                    except EOFError:
                        _restore_terminal()
                        console.print("\nGoodbye!")
                        break
            finally:
                timeout_monitor.stop()
                agent_loop.stop()
                outbound_task.cancel()
                await asyncio.gather(bus_task, outbound_task, return_exceptions=True)
                await agent_loop.close()

        asyncio.run(run_interactive())


# ============================================================================
# Channel Commands
# ============================================================================


channels_app = typer.Typer(help="Manage channels")
app.add_typer(channels_app, name="channels")


@channels_app.command("status")
def channels_status():
    """Show channel status."""
    config = _load_runtime_config()

    table = Table(title="Channel Status")
    table.add_column("Channel", style="cyan")
    table.add_column("Enabled", style="green")
    table.add_column("Configuration", style="yellow")

    # Telegram
    tg = config.channels.telegram
    tg_config = f"token: {tg.token[:10]}..." if tg.token else "[dim]not configured[/dim]"
    table.add_row("Telegram", "✓" if tg.enabled else "✗", tg_config)

    # Email
    em = config.channels.email
    em_config = em.imap_host if em.imap_host else "[dim]not configured[/dim]"
    table.add_row("Email", "✓" if em.enabled else "✗", em_config)

    # Nostr
    nostr = config.channels.nostr
    nostr_config = (
        f"{nostr.protocol}, {len(nostr.relays)} relay(s)"
        if nostr.private_key
        else "[dim]not configured[/dim]"
    )
    table.add_row("Nostr", "✓" if nostr.enabled else "✗", nostr_config)

    console.print(table)


# ============================================================================
# Cron Commands
# ============================================================================

cron_app = typer.Typer(help="Manage scheduled tasks")
app.add_typer(cron_app, name="cron")


@cron_app.command("list")
def cron_list(
    all: bool = typer.Option(False, "--all", "-a", help="Include disabled jobs"),
):
    """List scheduled jobs."""
    from hermitcrab.config.loader import get_data_dir
    from hermitcrab.cron.service import CronService

    store_path = get_data_dir() / "cron" / "jobs.json"
    service = CronService(store_path)

    jobs = service.list_jobs(include_disabled=all)

    if not jobs:
        console.print("No scheduled jobs.")
        return

    table = Table(title="Scheduled Jobs")
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Schedule")
    table.add_column("Status")
    table.add_column("Next Run")

    import time
    from datetime import datetime as _dt
    from zoneinfo import ZoneInfo

    for job in jobs:
        # Format schedule
        if job.schedule.kind == "every":
            sched = f"every {(job.schedule.every_ms or 0) // 1000}s"
        elif job.schedule.kind == "cron":
            sched = (
                f"{job.schedule.expr or ''} ({job.schedule.tz})"
                if job.schedule.tz
                else (job.schedule.expr or "")
            )
        else:
            sched = "one-time"

        # Format next run
        next_run = ""
        if job.state.next_run_at_ms:
            ts = job.state.next_run_at_ms / 1000
            try:
                tz = ZoneInfo(job.schedule.tz) if job.schedule.tz else None
                next_run = _dt.fromtimestamp(ts, tz).strftime("%Y-%m-%d %H:%M")
            except Exception:
                next_run = time.strftime("%Y-%m-%d %H:%M", time.localtime(ts))

        status = "[green]enabled[/green]" if job.enabled else "[dim]disabled[/dim]"

        table.add_row(job.id, job.name, sched, status, next_run)

    console.print(table)


@cron_app.command("add")
def cron_add(
    name: str = typer.Option(..., "--name", "-n", help="Job name"),
    message: str = typer.Option(..., "--message", "-m", help="Message for agent"),
    every: int = typer.Option(None, "--every", "-e", help="Run every N seconds"),
    cron_expr: str = typer.Option(None, "--cron", "-c", help="Cron expression (e.g. '0 9 * * *')"),
    tz: str | None = typer.Option(
        None, "--tz", help="IANA timezone for cron (e.g. 'America/Vancouver')"
    ),
    at: str = typer.Option(None, "--at", help="Run once at time (ISO format)"),
    deliver: bool = typer.Option(False, "--deliver", "-d", help="Deliver response to channel"),
    to: str = typer.Option(None, "--to", help="Recipient for delivery"),
    channel: str = typer.Option(
        None, "--channel", help="Channel for delivery (e.g. 'telegram', 'email', 'nostr')"
    ),
):
    """Add a scheduled job."""
    from hermitcrab.config.loader import get_data_dir
    from hermitcrab.cron.service import CronService
    from hermitcrab.cron.types import CronSchedule

    if tz and not cron_expr:
        console.print("[red]Error: --tz can only be used with --cron[/red]")
        raise typer.Exit(1)

    # Determine schedule type
    if every:
        schedule = CronSchedule(kind="every", every_ms=every * 1000)
    elif cron_expr:
        schedule = CronSchedule(kind="cron", expr=cron_expr, tz=tz)
    elif at:
        import datetime

        dt = datetime.datetime.fromisoformat(at)
        schedule = CronSchedule(kind="at", at_ms=int(dt.timestamp() * 1000))
    else:
        console.print("[red]Error: Must specify --every, --cron, or --at[/red]")
        raise typer.Exit(1)

    store_path = get_data_dir() / "cron" / "jobs.json"
    service = CronService(store_path)

    try:
        job = service.add_job(
            name=name,
            schedule=schedule,
            message=message,
            deliver=deliver,
            to=to,
            channel=channel,
        )
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1) from e

    console.print(f"[green]✓[/green] Added job '{job.name}' ({job.id})")


@cron_app.command("remove")
def cron_remove(
    job_id: str = typer.Argument(..., help="Job ID to remove"),
):
    """Remove a scheduled job."""
    from hermitcrab.config.loader import get_data_dir
    from hermitcrab.cron.service import CronService

    store_path = get_data_dir() / "cron" / "jobs.json"
    service = CronService(store_path)

    if service.remove_job(job_id):
        console.print(f"[green]✓[/green] Removed job {job_id}")
    else:
        console.print(f"[red]Job {job_id} not found[/red]")


@cron_app.command("enable")
def cron_enable(
    job_id: str = typer.Argument(..., help="Job ID"),
    disable: bool = typer.Option(False, "--disable", help="Disable instead of enable"),
):
    """Enable or disable a job."""
    from hermitcrab.config.loader import get_data_dir
    from hermitcrab.cron.service import CronService

    store_path = get_data_dir() / "cron" / "jobs.json"
    service = CronService(store_path)

    job = service.enable_job(job_id, enabled=not disable)
    if job:
        status = "disabled" if disable else "enabled"
        console.print(f"[green]✓[/green] Job '{job.name}' {status}")
    else:
        console.print(f"[red]Job {job_id} not found[/red]")


@cron_app.command("run")
def cron_run(
    job_id: str = typer.Argument(..., help="Job ID to run"),
    force: bool = typer.Option(False, "--force", "-f", help="Run even if disabled"),
):
    """Manually run a job."""
    from loguru import logger

    from hermitcrab.agent.loop import AgentLoop
    from hermitcrab.bus.queue import MessageBus
    from hermitcrab.config.loader import get_data_dir
    from hermitcrab.cron.service import CronService
    from hermitcrab.cron.types import CronJob

    logger.disable("hermitcrab")

    config = _load_runtime_config()
    provider = _make_provider(config)
    bus = MessageBus()

    agent_loop = AgentLoop(
        bus=bus,
        **_build_agent_loop_kwargs(config, provider),
    )

    store_path = get_data_dir() / "cron" / "jobs.json"
    service = CronService(store_path)

    result_holder = []

    async def on_job(job: CronJob) -> str | None:
        response = await agent_loop.process_direct(
            job.payload.message,
            session_key=f"cron:{job.id}",
            channel=job.payload.channel or "cli",
            chat_id=job.payload.to or "direct",
        )
        result_holder.append(response)
        return response

    service.on_job = on_job

    async def run():
        return await service.run_job(job_id, force=force)

    if asyncio.run(run()):
        console.print("[green]✓[/green] Job executed")
        if result_holder:
            _print_agent_response(result_holder[0], render_markdown=True)
    else:
        console.print(f"[red]Failed to run job {job_id}[/red]")


# ============================================================================
# Status Commands
# ============================================================================


@app.command()
def status(
    as_json: bool = typer.Option(False, "--json", help="Print the status report as JSON"),
):
    """Show HermitCrab runtime and setup status."""
    from hermitcrab.cli.diagnostics import build_status_report, render_json_report

    report = build_status_report()
    if as_json:
        typer.echo(render_json_report(report), nl=False)
        return

    console.print(f"{__logo__} hermitcrab Status\n")
    config_status = "[green]valid[/green]" if report.config_valid else "[red]invalid[/red]"
    if not report.config_exists:
        config_status = "[red]missing[/red]"
    console.print(f"Config: {report.config_path} {config_status}")
    if report.config_error:
        console.print(f"  [red]{report.config_error}[/red]")

    workspace_status = "[green]ready[/green]" if report.workspace_exists else "[red]missing[/red]"
    console.print(f"Workspace: {report.workspace} {workspace_status}")
    console.print(
        "Bootstrap: "
        + ("[green]ready[/green]" if report.bootstrap_ready else "[yellow]incomplete[/yellow]")
    )

    console.print(f"Selected model: {report.selected_model}")
    if report.resolved_model and report.resolved_model != report.selected_model:
        console.print(f"Resolved model: {report.resolved_model}")
    console.print(f"Selected provider: {report.selected_provider or 'none'}")

    console.print("\n[bold]Providers[/bold]")
    for item in report.provider_statuses:
        marker = "[green]✓[/green]" if item.configured else "[dim]•[/dim]"
        selected = " [cyan](selected)[/cyan]" if item.selected else ""
        console.print(f"- {item.label}: {marker} {item.detail}{selected}")

    available_skills = sum(1 for skill in report.skill_statuses if skill.available)
    unavailable_skills = len(report.skill_statuses) - available_skills
    console.print("\n[bold]Skills[/bold]")
    console.print(
        f"- Available: {available_skills}  [dim](unavailable: {unavailable_skills})[/dim]"
    )
    for skill in [item for item in report.skill_statuses if not item.available][:3]:
        if skill.missing_requirements:
            console.print(f"- {skill.name}: [yellow]{skill.missing_requirements}[/yellow]")

    console.print("\n[bold]MCP[/bold]")
    console.print(
        f"- Configured servers: {report.mcp_servers_configured}"
        f"  [dim](valid: {report.mcp_servers_valid})[/dim]"
    )

    if report.next_steps:
        console.print("\n[bold]Next Steps[/bold]")
        for step in report.next_steps:
            console.print(f"- {step}")


@app.command()
def doctor(
    as_json: bool = typer.Option(False, "--json", help="Print the doctor report as JSON"),
):
    """Run first-run diagnostics and suggest concrete fixes."""
    from hermitcrab.cli.diagnostics import build_doctor_report, render_json_report

    report = build_doctor_report()
    if as_json:
        typer.echo(render_json_report(report), nl=False)
        return

    console.print(f"{__logo__} hermitcrab Doctor\n")
    for finding in report.findings:
        if finding.severity == "ok":
            marker = "[green]OK[/green]"
        elif finding.severity == "error":
            marker = "[red]ERROR[/red]"
        elif finding.severity == "warning":
            marker = "[yellow]WARN[/yellow]"
        else:
            marker = "[cyan]INFO[/cyan]"
        console.print(f"{marker} {finding.title}")
        console.print(f"  {finding.detail}")
        console.print(f"  Fix: {finding.remediation}\n")


# ============================================================================
# Journal Commands
# ============================================================================

journal_app = typer.Typer(help="Manage journal entries")
app.add_typer(journal_app, name="journal")


@journal_app.command("write")
def journal_write(
    content: str = typer.Option(
        "", "--content", "-c", help="Journal content (optional, prompts if not provided)"
    ),
    date: str = typer.Option(
        "", "--date", "-d", help="Date in YYYY-MM-DD format (defaults to today)"
    ),
    tag: list[str] = typer.Option([], "--tag", "-t", help="Tags (can be specified multiple times)"),
):
    """Write a journal entry."""
    from datetime import datetime, timezone

    from hermitcrab.agent.journal import JournalStore
    config = _load_runtime_config()
    workspace = config.workspace_path
    journal = JournalStore(workspace)

    # Parse date if provided
    entry_date = None
    if date:
        try:
            entry_date = datetime.strptime(date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except ValueError:
            console.print("[red]Invalid date format. Use YYYY-MM-DD.[/red]")
            raise typer.Exit(1)

    # Get content from option or prompt
    if not content:
        console.print("[cyan]Enter journal content (end with empty line):[/cyan]")
        lines = []
        while True:
            try:
                line = input()
                if not line.strip():
                    break
                lines.append(line)
            except EOFError:
                break
        content = "\n".join(lines)

    if not content.strip():
        console.print("[red]Journal content cannot be empty.[/red]")
        raise typer.Exit(1)

    # Write the entry
    try:
        file_path = journal.write_entry(
            content=content,
            tags=tag if tag else None,
            date=entry_date,
        )
        console.print(f"[green]✓ Journal entry written:[/green] {file_path}")
    except Exception as e:
        console.print(f"[red]Failed to write journal entry: {e}[/red]")
        raise typer.Exit(1)


@journal_app.command("read")
def journal_read(
    date: str = typer.Option(
        "", "--date", "-d", help="Date in YYYY-MM-DD format (defaults to today)"
    ),
    body_only: bool = typer.Option(
        False, "--body", "-b", help="Show body content only (no frontmatter)"
    ),
):
    """Read a journal entry."""
    from datetime import datetime, timezone

    from hermitcrab.agent.journal import JournalStore
    config = _load_runtime_config()
    workspace = config.workspace_path
    journal = JournalStore(workspace)

    # Parse date if provided
    entry_date = None
    if date:
        try:
            entry_date = datetime.strptime(date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except ValueError:
            console.print("[red]Invalid date format. Use YYYY-MM-DD.[/red]")
            raise typer.Exit(1)

    # Read the entry
    if body_only:
        content = journal.read_entry_body(entry_date)
    else:
        content = journal.read_entry(entry_date)

    if content is None:
        target_date = entry_date or datetime.now(timezone.utc)
        console.print(
            f"[yellow]No journal entry found for {target_date.strftime('%Y-%m-%d')}[/yellow]"
        )
        raise typer.Exit(0)

    # Display with markdown rendering
    console.print()
    console.print(Markdown(content))


@journal_app.command("list")
def journal_list(
    limit: int = typer.Option(10, "--limit", "-l", help="Number of entries to show"),
):
    """List recent journal entries."""
    from datetime import datetime, timezone

    from hermitcrab.agent.journal import JournalStore
    config = _load_runtime_config()
    workspace = config.workspace_path
    journal = JournalStore(workspace)

    entries = journal.list_entries(limit=limit)

    if not entries:
        console.print("[yellow]No journal entries found.[/yellow]")
        raise typer.Exit(0)

    console.print(f"\n[bold]Journal Entries[/bold] (showing {len(entries)} of {limit})\n")

    for entry_path in entries:
        date_str = entry_path.stem  # YYYY-MM-DD
        metadata = journal.get_entry_metadata(
            datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        )

        tags_str = ""
        if metadata and metadata.get("tags"):
            tags_str = f" [dim]({', '.join(metadata['tags'])})[/dim]"

        console.print(f"  [cyan]{date_str}[/cyan]{tags_str}")
        console.print(f"    [dim]{entry_path}[/dim]\n")


# ============================================================================
# OAuth Login
# ============================================================================

provider_app = typer.Typer(help="Manage providers")
app.add_typer(provider_app, name="provider")


_LOGIN_HANDLERS: dict[str, callable] = {}


def _register_login(name: str):
    def decorator(fn):
        _LOGIN_HANDLERS[name] = fn
        return fn

    return decorator


@provider_app.command("login")
def provider_login(
    provider: str = typer.Argument(
        ..., help="OAuth provider (e.g. 'openai-codex', 'github-copilot')"
    ),
):
    """Authenticate with an OAuth provider."""
    from hermitcrab.providers.registry import PROVIDERS

    key = provider.replace("-", "_")
    spec = next((s for s in PROVIDERS if s.name == key and s.is_oauth), None)
    if not spec:
        names = ", ".join(s.name.replace("_", "-") for s in PROVIDERS if s.is_oauth)
        console.print(f"[red]Unknown OAuth provider: {provider}[/red]  Supported: {names}")
        raise typer.Exit(1)

    handler = _LOGIN_HANDLERS.get(spec.name)
    if not handler:
        console.print(f"[red]Login not implemented for {spec.label}[/red]")
        raise typer.Exit(1)

    console.print(f"{__logo__} OAuth Login - {spec.label}\n")
    handler()


@_register_login("openai_codex")
def _login_openai_codex() -> None:
    try:
        from oauth_cli_kit import get_token, login_oauth_interactive

        token = None
        try:
            token = get_token()
        except Exception:
            pass
        if not (token and token.access):
            console.print("[cyan]Starting interactive OAuth login...[/cyan]\n")
            token = login_oauth_interactive(
                print_fn=lambda s: console.print(s),
                prompt_fn=lambda s: typer.prompt(s),
            )
        if not (token and token.access):
            console.print("[red]✗ Authentication failed[/red]")
            raise typer.Exit(1)
        console.print(
            f"[green]✓ Authenticated with OpenAI Codex[/green]  [dim]{token.account_id}[/dim]"
        )
    except ImportError:
        console.print("[red]oauth_cli_kit not installed. Run: pip install oauth-cli-kit[/red]")
        raise typer.Exit(1)


@_register_login("github_copilot")
def _login_github_copilot() -> None:
    import asyncio

    console.print("[cyan]Starting GitHub Copilot device flow...[/cyan]\n")

    async def _trigger():
        from litellm import acompletion

        await acompletion(
            model="github_copilot/gpt-4o",
            messages=[{"role": "user", "content": "hi"}],
            max_tokens=1,
        )

    try:
        asyncio.run(_trigger())
        console.print("[green]✓ Authenticated with GitHub Copilot[/green]")
    except Exception as e:
        console.print(f"[red]Authentication error: {e}[/red]")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
