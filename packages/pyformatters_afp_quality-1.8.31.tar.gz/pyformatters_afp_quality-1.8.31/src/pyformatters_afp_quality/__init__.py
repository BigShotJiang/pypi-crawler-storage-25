"""Sherpa AFP Quality formatter"""

__version__ = "1.8.31"
