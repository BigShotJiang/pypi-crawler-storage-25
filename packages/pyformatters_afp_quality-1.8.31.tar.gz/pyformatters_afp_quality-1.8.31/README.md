## Requirements

- Python 3.12+
- uv for package management and publishing
- Pydantic v2 for the data parts.

## Installation

```
pip install uv
uv sync --extra test
```

## Running tests

```
uv run pytest
```

## Linting

```
uv run ruff check .
uv run ruff format --check .
```

## Publish the Python Package to PyPI

- Increment the version of your package in `src/pyformatters_afp_quality/__init__.py`:

```python
"""Sherpa AFP Quality formatter"""

__version__ = 'x.y.z'
```

- Publish

```
uv build && uv publish
```
