from typing import TYPE_CHECKING

from open_prime_hunters_rando.parsing.file_manager import FileManager
from open_prime_hunters_rando.parsing.formats.entities.entity_types.area_volume import AreaVolume
from open_prime_hunters_rando.parsing.formats.entities.entity_types.artifact import Artifact
from open_prime_hunters_rando.parsing.formats.entities.entity_types.door import Door, DoorType
from open_prime_hunters_rando.parsing.formats.entities.entity_types.force_field import ForceField
from open_prime_hunters_rando.parsing.formats.entities.entity_types.item_spawn import ItemSpawn
from open_prime_hunters_rando.parsing.formats.entities.entity_types.object import Object
from open_prime_hunters_rando.parsing.formats.entities.entity_types.teleporter import Teleporter
from open_prime_hunters_rando.parsing.formats.entities.entity_types.trigger_volume import TriggerVolume
from open_prime_hunters_rando.parsing.formats.entities.enum import Message

if TYPE_CHECKING:
    from open_prime_hunters_rando.parsing.formats.entities.base_entity import Entity


def static_patches(file_manager: FileManager) -> None:
    _disable_boss_force_fields(file_manager)
    _disable_message_prompts(file_manager)
    _disable_new_arrival_registration_cutscenes(file_manager)
    _remove_elder_passage_top_lock_and_force_field(file_manager)
    _disable_alimbic_garden_cutscene(file_manager)
    _disable_fault_line_imperialist_cutscene(file_manager)
    _patch_sic_transit_inner_door(file_manager)
    _lock_fault_line_magmaul_door(file_manager)
    _fix_incubation_vault_03_portal_spawn(file_manager)
    _disable_helm_room_scan_door_cutscenes(file_manager)


def _disable_boss_force_fields(file_manager: FileManager) -> None:
    boss_force_fields = [
        ("Alinos", "High Ground", 10),
        ("Vesper Defense Outpost", "Weapons Complex", 31),
        ("Arcterra", "Sic Transit", 64),
    ]
    for area_name, room_name, force_field in boss_force_fields:
        entity_file = file_manager.get_entity_file(area_name, room_name)
        entity = entity_file.get_entity(force_field, ForceField)
        if entity.entity_id == 10:
            entity.layer_state[0] = False
            entity.layer_state[3] = False
        else:
            entity.active = False


def _disable_message_prompts(file_manager: FileManager) -> None:
    message_prompts_per_room = {
        "Celestial Archives": {
            "Celestial Gateway": [8, 24],  # Scan Visor and Enter Ship
            "Data Shrine 01": [54, 56],  # Unknown ship and Enter Morph Ball
            "Fan Room Beta": [8],  # Slench presence
        }
    }
    for area_name, room_names in message_prompts_per_room.items():
        for room_name, message_prompts in room_names.items():
            entity_file = file_manager.get_entity_file(area_name, room_name)
            for message_prompt in message_prompts:
                entity: Entity = entity_file.get_entity(message_prompt)
                assert isinstance(entity, TriggerVolume | AreaVolume)
                entity.active = False


def _disable_new_arrival_registration_cutscenes(file_manager: FileManager) -> None:
    entity_file = file_manager.get_entity_file("Celestial Archives", "New Arrival Registration")

    # Disable the first force field cutscene and force field, scans are now always active
    trigger_volume = entity_file.get_entity(34, TriggerVolume)
    trigger_volume.parent_id = 0

    # Disable the cutscene for deactivating the shield
    shield_key = entity_file.get_entity(49, ItemSpawn)
    shield_key.notify_entity_id = 31
    shield_key.collected_message = Message.SET_ACTIVE

    # Disable the second force field cutscene by linking directly to the Greater Ithrak enemy spawn
    artifact = entity_file.get_entity(19, Artifact)
    artifact.message1_target = 53
    artifact.message1 = Message.TRIGGER


def _remove_elder_passage_top_lock_and_force_field(file_manager: FileManager) -> None:
    entity_file = file_manager.get_entity_file("Alinos", "Elder Passage")
    trigger_volume = entity_file.get_entity(25, TriggerVolume)
    trigger_volume.parent_message = Message.NONE

    force_field = entity_file.get_entity(39, ForceField)
    force_field.layer_state[0] = False
    force_field.layer_state[3] = False


def _disable_alimbic_garden_cutscene(file_manager: FileManager) -> None:
    entity_file = file_manager.get_entity_file("Alinos", "Alimbic Gardens")
    trigger_volume = entity_file.get_entity(7, TriggerVolume)
    trigger_volume.active = False


def _disable_fault_line_imperialist_cutscene(file_manager: FileManager) -> None:
    entity_file = file_manager.get_entity_file("Arcterra", "Fault Line")
    imperialist = entity_file.get_entity(46, ItemSpawn)
    imperialist.notify_entity_id = 0
    imperialist.collected_message = Message.NONE


def _patch_sic_transit_inner_door(file_manager: FileManager) -> None:
    entity_file = file_manager.get_entity_file("Arcterra", "Sic Transit")
    door = entity_file.get_entity(24, Door)
    door.door_type = DoorType.THIN


def _lock_fault_line_magmaul_door(file_manager: FileManager) -> None:
    # The door from Sic Transit is a Magmaul door but not locked in game
    entity_file = file_manager.get_entity_file("Arcterra", "Fault Line")
    door = entity_file.get_entity(31, Door)
    door.locked = True


def _fix_incubation_vault_03_portal_spawn(file_manager: FileManager) -> None:
    # The portal from Docking Bay to Incubation Vault 03 spawned Samus at the room spawn and not at the portal
    entity_file = file_manager.get_entity_file("Celestial Archives", "Docking Bay")
    portal = entity_file.get_entity(7, Teleporter)
    portal.target_index = 27


def _disable_helm_room_scan_door_cutscenes(file_manager: FileManager) -> None:
    entity_file = file_manager.get_entity_file("Celestial Archives", "Helm Room")

    # Scan object that unlocks the door
    obj = entity_file.get_entity(9, Object)
    obj.scan_message_target = 8
    obj.scan_message = Message.UNLOCK

    # Trigger activates the cutscene showing the door
    trigger = entity_file.get_entity(17, TriggerVolume)
    trigger.active = False
