"""Shell command execution with safety checks.

Cross-platform: uses cmd.exe on Windows, /bin/sh on Unix.
Dangerous-command detection covers both platforms.
"""

import os
import re
import subprocess
import sys
from .base import Tool

# ── Unix dangerous patterns ───────────────────────────────────────────────────
_DANGEROUS_PATTERNS_UNIX = [
    (r"\brm\s+(-\w*)?-r\w*\s+(/|~|\$HOME)", "recursive delete on home/root"),
    (r"\brm\s+(-\w*)?-rf\s", "force recursive delete"),
    (r"\bmkfs\b", "format filesystem"),
    (r"\bdd\s+.*of=/dev/", "raw disk write"),
    (r">\s*/dev/sd[a-z]", "overwrite block device"),
    (r"\bchmod\s+(-R\s+)?777\s+/", "chmod 777 on root"),
    (r":\(\)\s*\{.*:\|:.*\}", "fork bomb"),
    (r"\bcurl\b.*\|\s*(sudo\s+)?bash", "pipe curl to bash"),
    (r"\bwget\b.*\|\s*(sudo\s+)?bash", "pipe wget to bash"),
]

# ── Windows dangerous patterns ────────────────────────────────────────────────
_DANGEROUS_PATTERNS_WIN = [
    (r"\brd\s+/s\s+/q\s+[a-zA-Z]:\\\\", "recursive delete of drive root"),
    (r"\brmdir\s+/s\s+/q\s+[a-zA-Z]:\\\\", "recursive delete of drive root"),
    (r"\bformat\s+[a-zA-Z]:", "format drive"),
    (r"\bdiskpart\b", "disk partition tool"),
    (r"\bdel\s+/[fsq]*\s+[a-zA-Z]:\\\\", "bulk delete from drive root"),
    (r"\bpowershell\b.*\|\s*iex\b", "pipe to Invoke-Expression"),
    (r"\bpowershell\b.*\bDownloadString\b.*\|\s*iex\b", "download and execute"),
]

_DANGEROUS_PATTERNS = (
    _DANGEROUS_PATTERNS_WIN if sys.platform == "win32" else _DANGEROUS_PATTERNS_UNIX
)


class BashTool(Tool):
    name = "bash"
    description = (
        "Execute a shell command. Returns stdout, stderr, and exit code. "
        "Use this for running tests, installing packages, git operations, etc."
    )
    parameters = {
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "The shell command to run"},
            "timeout": {"type": "integer", "description": "Timeout in seconds (default 120)"},
        },
        "required": ["command"],
    }

    def __init__(self):
        # Per-instance working directory — eliminates the global mutable state
        # race condition when multiple tools/agents run concurrently.
        self._cwd: str | None = None

    def reset_cwd(self) -> None:
        """Reset tracked working directory (called by Agent.reset)."""
        self._cwd = None

    def set_cwd(self, path: str) -> None:
        """Explicitly set the working directory (e.g. for multi-tenant use)."""
        self._cwd = path

    def execute(self, command: str, timeout: int = 120) -> str:
        warning = _check_dangerous(command)
        if warning:
            return (
                f"⚠ Blocked: {warning}\nCommand: {command}\n"
                "If intentional, modify the command to be more specific."
            )

        # Cap timeout to prevent LLM from passing absurdly large values that
        # would hang the server process indefinitely.
        timeout = max(1, min(int(timeout), 300))

        cwd = self._cwd or os.getcwd()

        # On Windows use cmd /c; on Unix pass as string with shell=True
        if sys.platform == "win32":
            shell_args = ["cmd", "/c", command]
            use_shell = False
        else:
            shell_args = command
            use_shell = True

        try:
            proc = subprocess.run(
                shell_args,
                shell=use_shell,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=cwd,
            )
            if proc.returncode == 0:
                self._cwd = _resolve_cwd(command, cwd)
            out = proc.stdout
            if proc.stderr:
                out += f"\n[stderr]\n{proc.stderr}"
            if proc.returncode != 0:
                out += f"\n[exit code: {proc.returncode}]"
            if len(out) > 15_000:
                out = (
                    out[:6000]
                    + f"\n\n... truncated ({len(out)} chars total) ...\n\n"
                    + out[-3000:]
                )
            return out.strip() or "(no output)"
        except subprocess.TimeoutExpired:
            return f"Error: timed out after {timeout}s"
        except Exception as e:
            return f"Error running command: {e}"


def _check_dangerous(cmd: str) -> str | None:
    for pattern, reason in _DANGEROUS_PATTERNS:
        if re.search(pattern, cmd):
            return reason
    return None


def _resolve_cwd(command: str, current_cwd: str) -> str:
    """Return updated working directory after any cd/Set-Location in command.
    Pure function — no global side effects.
    """
    separators = re.split(r"&&|;", command)
    result = current_cwd
    for part in separators:
        part = part.strip()
        m = re.match(r"(?:cd|Set-Location|sl)\s+(.+)", part, re.IGNORECASE)
        if m:
            target = m.group(1).strip().strip("'\"")
            if target:
                new_dir = os.path.normpath(
                    os.path.join(result, os.path.expanduser(target))
                )
                if os.path.isdir(new_dir):
                    result = new_dir
    return result
