"""
Auth API
========
Instagram login, logout, 2FA, and challenge resolver.
Web login flow using wbloks/fetch endpoint — 1:1 real browser emulation.

Login flow (captured from real Samsung Browser via mitmproxy):
    1. Load device cookies (if saved) → Instagram recognizes device
    2. Warm-up: GET instagram.com → GET /accounts/login/ (human-like)
       Extract: csrftoken, lsd, __rev, __hsi, __dyn, __csr, __bkv
    3. Encrypt password → #PWD_BROWSER:5:{timestamp}:{encrypted}
    4. Step 1: POST wbloks/fetch (send_login_request) → get auth params
    5. Step 2: POST wbloks/fetch (auth_login_request) → get sessionid
    6. Handle 2FA/challenge automatically if required
    7. Save device cookies + session for next time

Dependency: pip install pynacl cryptography

Module structure:
    - constants.py   → Endpoints, user-agent, device cookies
    - encryption.py  → Password encryption (AES-GCM + NaCl)
    - wbloks.py      → Wbloks form/URL builder
    - challenge.py   → Challenge auto-resolution
    - session.py     → Session management + exceptions
"""

import json
import os
import re
import time
import random
import logging
from typing import Any, Callable, Dict, Optional, Tuple

from .constants import (
    WBLOKS_BASE, LOGIN_APPID, AUTH_LOGIN_APPID,
    LOGIN_URL, TWO_FACTOR_URL,
    DEVICE_COOKIES, WEB_USER_AGENT, SEC_CH_UA,
)
from .encryption import EncryptionMixin
from .wbloks import WbloksMixin
from .challenge import ChallengeMixin
from .session import (
    SessionMixin,
    LoginError, TwoFactorRequired, CheckpointRequired,
)

logger = logging.getLogger("instaharvest_v2")


class AuthAPI(SessionMixin, EncryptionMixin, WbloksMixin, ChallengeMixin):
    """
    Instagram login/logout API.

    Usage:
        from instaharvest_v2 import Instagram
        ig = Instagram()
        ig.auth.login("username", "password")
        # Now ig.users, ig.media, ... are ready

        # Save session:
        ig.auth.save_session("session.json")

        # Load session next time:
        ig.auth.load_session("session.json")
    """

    def __init__(self, client):
        """
        Init.

        Args:
            client: Parameter client
        """
        self._client = client
        self._encryption_keys = None
        self._device_cookies_file = "device_cookies.json"
        self._server_revision = ""  # Dynamic x-instagram-ajax (__rev)
        # Wbloks dynamic params (extracted from login page HTML)
        self._wbloks_params = {
            "lsd": "",
            "__rev": "",
            "__hsi": "",
            "__dyn": "",
            "__csr": "",
            "__bkv": "",
            "__spin_b": "trunk",
            "__spin_t": "",
            "__hs": "",
        }

    # ═══════════════════════════════════════════════════════════
    # LAYER 1: BROWSER WARM-UP (anti-challenge)
    # ═══════════════════════════════════════════════════════════

    def _warm_up_session(self, session) -> str:
        """
        Warm up the session like a real browser before login.
        Extracts wbloks dynamic params needed for the login request.

        Flow:
            1. Load saved device cookies (if exist)
            2. GET instagram.com (collect mid, ig_did, datr)
            3. Wait 2-3s (human-like)
            4. GET /accounts/login/ (collect csrftoken + wbloks params)
            5. Wait 1-2s

        Extracts from HTML:
            - csrftoken (cookie)
            - lsd, __rev, __hsi, __dyn, __csr, __bkv, __hs, __spin_t

        Returns:
            str: CSRF token
        """
        # Load previously saved device cookies (Layer 2)
        self._load_device_cookies(session)

        # Step 1: Visit instagram.com main page
        logger.info("[Auth] Warming up session — visiting instagram.com...")
        try:
            session.get(
                "https://www.instagram.com/",
                headers={
                    "user-agent": WEB_USER_AGENT,
                    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                    "accept-language": "en-US,en;q=0.9",
                    "sec-ch-ua": SEC_CH_UA,
                    "sec-ch-ua-mobile": "?0",
                    "sec-ch-ua-platform": '"Windows"',
                    "sec-fetch-dest": "document",
                    "sec-fetch-mode": "navigate",
                    "sec-fetch-site": "none",
                    "sec-fetch-user": "?1",
                    "upgrade-insecure-requests": "1",
                },
                timeout=15,
            )
            logger.debug(f"[Auth] Main page cookies: {list(session.cookies.keys())}")
        except Exception as e:
            logger.warning(f"[Auth] Main page visit failed: {e}")

        # Human-like delay: 2-3 seconds
        delay1 = random.uniform(2.0, 3.5)
        logger.debug(f"[Auth] Waiting {delay1:.1f}s before login page...")
        time.sleep(delay1)

        # Step 2: Visit login page (this sets csrftoken + contains wbloks params)
        logger.info("[Auth] Visiting login page...")
        csrf_token = None
        try:
            login_page = session.get(
                "https://www.instagram.com/accounts/login/",
                headers={
                    "user-agent": WEB_USER_AGENT,
                    "referer": "https://www.instagram.com/",
                    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                    "sec-ch-ua": SEC_CH_UA,
                    "sec-ch-ua-mobile": "?0",
                    "sec-ch-ua-platform": '"Windows"',
                    "sec-fetch-dest": "document",
                    "sec-fetch-mode": "navigate",
                    "sec-fetch-site": "same-origin",
                },
                timeout=15,
            )

            page_html = login_page.text

            # Extract CSRF token
            for name, value in session.cookies.items():
                if name == "csrftoken":
                    csrf_token = value
                    break

            if not csrf_token:
                csrf_token = login_page.headers.get("x-csrftoken", "")
            if not csrf_token:
                match = re.search(r'"csrf_token":"([^"]+)"', page_html)
                if match:
                    csrf_token = match.group(1)

            # ── Extract wbloks dynamic params from login page HTML ──
            # __rev (server_revision) — also used as x-instagram-ajax
            rev_match = re.search(r'"server_revision":(\d+)', page_html)
            if rev_match:
                self._server_revision = rev_match.group(1)
                self._wbloks_params["__rev"] = rev_match.group(1)
            else:
                spin_match = re.search(r'__spin_r":(\d+)', page_html)
                if spin_match:
                    self._server_revision = spin_match.group(1)
                    self._wbloks_params["__rev"] = spin_match.group(1)

            # lsd token (anti-CSRF for wbloks)
            lsd_match = re.search(r'"LSD",\[\],\{"token":"([^"]+)"', page_html)
            if not lsd_match:
                lsd_match = re.search(r'"lsd"[,:]"([^"]+)"', page_html, re.IGNORECASE)
            if not lsd_match:
                lsd_match = re.search(r'name="lsd"\s+value="([^"]+)"', page_html)
            if lsd_match:
                self._wbloks_params["lsd"] = lsd_match.group(1)
                logger.debug(f"[Auth] lsd: {lsd_match.group(1)[:20]}...")

            # __hsi (host session ID)
            hsi_match = re.search(r'"hsi":"(\d+)"', page_html)
            if not hsi_match:
                hsi_match = re.search(r'__hsi":(\d+)', page_html)
            if hsi_match:
                self._wbloks_params["__hsi"] = hsi_match.group(1)

            # __dyn (dynamic modules hash)
            dyn_match = re.search(r'"__dyn":"([^"]+)"', page_html)
            if dyn_match:
                self._wbloks_params["__dyn"] = dyn_match.group(1)

            # __csr (client-side rendering hash)
            csr_match = re.search(r'"__csr":"([^"]+)"', page_html)
            if csr_match:
                self._wbloks_params["__csr"] = csr_match.group(1)

            # __bkv (bloks versioning ID — critical for wbloks/fetch URL!)
            bkv_match = re.search(r'versioningID":"([a-f0-9]{64})', page_html)
            if not bkv_match:
                bkv_match = re.search(r'"bloks_versioning_id":"([^"]+)"', page_html)
            if not bkv_match:
                bkv_match = re.search(r'__bkv["\s:]+([a-f0-9]{40,})', page_html)
            if bkv_match:
                self._wbloks_params["__bkv"] = bkv_match.group(1)
                logger.info(f"[Auth] __bkv: {bkv_match.group(1)[:30]}...")
            else:
                # Hardcoded fallback from captured traffic (Feb 2026)
                self._wbloks_params["__bkv"] = "29d0fd2d0bf67787771d758433b17814a729d9b4a57b07a39f1cc6507b480e39"
                logger.warning("[Auth] __bkv not found in HTML, using hardcoded fallback")

            # __hs (host segment)
            hs_match = re.search(r'"__hs":"([^"]+)"', page_html)
            if hs_match:
                self._wbloks_params["__hs"] = hs_match.group(1)

            # __spin_t (spin timestamp)
            spin_t_match = re.search(r'__spin_t":(\d+)', page_html)
            if spin_t_match:
                self._wbloks_params["__spin_t"] = spin_t_match.group(1)

            logger.info(f"[Auth] server_revision (__rev): {self._server_revision}")
            logger.info(f"[Auth] Wbloks params extracted: {[k for k,v in self._wbloks_params.items() if v]}")

        except Exception as e:
            logger.warning(f"[Auth] Login page visit failed: {e}")

        if not csrf_token:
            csrf_token = "missing"
            logger.warning("[Auth] CSRF token not found")

        # Save device cookies after warm-up (for next time)
        self._save_device_cookies(session)

        # Human-like delay before login POST
        delay2 = random.uniform(1.5, 2.5)
        logger.debug(f"[Auth] Waiting {delay2:.1f}s before login POST...")
        time.sleep(delay2)

        logger.info(f"[Auth] Warm-up complete. Cookies: {list(session.cookies.keys())}")
        return csrf_token

    # ═══════════════════════════════════════════════════════════
    # LAYER 2: DEVICE COOKIE PERSISTENCE
    # ═══════════════════════════════════════════════════════════

    def _save_device_cookies(self, session) -> None:
        """Save device-identifying cookies for future sessions."""
        cookies = {}
        for name, value in session.cookies.items():
            if name in DEVICE_COOKIES:
                cookies[name] = value

        if cookies:
            data = {
                "cookies": cookies,
                "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "user_agent": WEB_USER_AGENT,
            }
            try:
                with open(self._device_cookies_file, "w") as f:
                    json.dump(data, f, indent=2)
                logger.info(f"[Auth] Device cookies saved: {list(cookies.keys())}")
            except Exception as e:
                logger.warning(f"[Auth] Failed to save device cookies: {e}")

    def _load_device_cookies(self, session) -> bool:
        """Load saved device cookies into session."""
        if not os.path.exists(self._device_cookies_file):
            logger.debug("[Auth] No saved device cookies found")
            return False

        try:
            with open(self._device_cookies_file) as f:
                data = json.load(f)

            cookies = data.get("cookies", {})
            for name, value in cookies.items():
                session.cookies.set(name, value, domain=".instagram.com")

            logger.info(f"[Auth] Device cookies loaded: {list(cookies.keys())}")
            return True
        except Exception as e:
            logger.warning(f"[Auth] Failed to load device cookies: {e}")
            return False

    # ═══════════════════════════════════════════════════════════
    # MAIN LOGIN
    # ═══════════════════════════════════════════════════════════

    def login(
        self,
        username: str,
        password: str,
        verification_code: str = None,
        two_factor_callback: Optional[Callable[[], str]] = None,
        challenge_callback: Optional[Callable] = None,
        email_credentials: Optional[Tuple[str, str]] = None,
        device_cookies_file: str = "device_cookies.json",
    ) -> Dict[str, Any]:
        """
        Login to Instagram with username and password.

        Includes anti-challenge protection:
        - Browser warm-up (visits main page first)
        - Device cookie persistence (remembers device)
        - Automatic challenge resolution
        - Auto email code reading via IMAP

        Args:
            username: Instagram username
            password: Account password
            verification_code: 2FA code (if known in advance)
            two_factor_callback: Callback for 2FA code.
                Example: lambda: input("Enter 2FA code: ")
            challenge_callback: Callback for challenge verification code.
                Example: lambda ctx: input(f"Code sent to {ctx.contact_point}: ")
            email_credentials: Tuple of (email, app_password) for auto-reading
                Instagram verification codes from Gmail via IMAP.
                Example: ("user@gmail.com", "xxxx xxxx xxxx xxxx")
            device_cookies_file: Path to save device cookies (default: device_cookies.json)

        Returns:
            dict: {
                status: "ok",
                authenticated: True,
                user_id: "...",
                session_id: "...",
            }

        Raises:
            LoginError: Login failed
            TwoFactorRequired: 2FA code needed (no callback provided)
            CheckpointRequired: Challenge could not be auto-resolved
        """
        # Save email_credentials for re-login after challenge resolution
        self._email_credentials = email_credentials

        # Auto-create challenge_callback from email_credentials
        if email_credentials and not challenge_callback:
            from ...email_verifier import EmailVerifier
            email_addr, email_pass = email_credentials
            verifier = EmailVerifier(email_addr, email_pass)

            def _auto_email_callback(ctx=None):
                logger.info("[Auth] Auto-reading verification code from email...")
                code = verifier.get_instagram_code(max_wait=90, poll_interval=5)
                if code:
                    logger.info(f"[Auth] Got verification code from email: {code}")
                    return code
                raise LoginError("Verification code not found in email within 90 seconds")

            challenge_callback = _auto_email_callback

        self._device_cookies_file = device_cookies_file
        session = self._client._get_curl_session()

        # ─── Layer 1: Warm-up (prevents "unusual login" challenges) ───
        logger.info(f"[Auth] Starting login for @{username}")
        csrf_token = self._warm_up_session(session)

        # ─── Encrypt password ───
        try:
            enc_password = self._encrypt_password(password)
            logger.info("[Auth] Password encrypted with #PWD_BROWSER:10")
        except Exception as e:
            logger.warning(f"[Auth] Encryption failed, using plaintext: {e}")
            enc_password = f"#PWD_BROWSER:0:{int(time.time())}:{password}"

        # Dynamic x-instagram-ajax (extracted from login page)
        x_instagram_ajax = self._server_revision or "1034162388"

        # ─── Build wbloks login params (1:1 real browser) ───
        mid_value = ""
        for name, value in session.cookies.items():
            if name == "mid":
                mid_value = value
                break

        import uuid
        waterfall_id = str(uuid.uuid4())

        # Build the params JSON (matches real browser traffic exactly)
        login_params = {
            "server_params": {
                "credential_type": "password",
                "username_text_input_id": f"login:{random.randint(10,99)}",
                "password_text_input_id": f"login:{random.randint(100,199)}",
                "login_source": "Login",
                "login_credential_type": "none",
                "server_login_source": "login",
                "ar_event_source": "login_home_page",
                "should_trigger_override_login_success_action": 0,
                "should_trigger_override_login_2fa_action": 0,
                "is_caa_perf_enabled": 1,
                "reg_flow_source": "aymh_single_profile_native_integration_point",
                "caller": "gslr",
                "is_from_landing_page": 0,
                "is_from_empty_password": 0,
                "is_from_aymh": 0,
                "is_from_password_entry_page": 0,
                "is_from_assistive_id": 0,
                "is_from_msplit_fallback": 0,
                "two_step_login_type": "one_step_login",
                "is_vanilla_password_page_empty_password": 0,
                "left_nav_button_action": "BACK",
                "INTERNAL__latency_qpl_marker_id": 36707139,
                "INTERNAL__latency_qpl_instance_id": str(random.randint(10**13, 10**14)),
                "device_id": mid_value,
                "family_device_id": None,
                "waterfall_id": waterfall_id,
                "offline_experiment_group": None,
                "layered_homepage_experiment_group": None,
                "is_platform_login": 0,
                "is_from_logged_in_switcher": 0,
                "is_from_logged_out": 0,
                "access_flow_version": "pre_mt_behavior",
                "login_surface": "login_home",
            },
            "client_input_params": {
                "machine_id": "",
                "cloud_trust_token": None,
                "block_store_machine_id": "",
                "zero_balance_state": "",
                "contact_point": username,
                "password": enc_password,
                "accounts_list": [],
                "fb_ig_device_id": [],
                "secure_family_device_id": "",
                "encrypted_msisdn": "",
                "headers_infra_flow_id": "",
                "try_num": 1,
                "login_attempt_count": 1,
                "event_flow": "login_manual",
                "event_step": "home_page",
                "openid_tokens": {},
                "auth_secure_device_id": "",
                "client_known_key_hash": "",
                "has_whatsapp_installed": 0,
                "sso_token_map_json_string": "",
                "should_show_nested_nta_from_aymh": 0,
            },
        }

        params_json = json.dumps({"params": json.dumps(login_params)})
        wbloks_form = self._build_wbloks_form(params_json, csrf_token)
        wbloks_url = self._build_wbloks_url(LOGIN_APPID)

        # ─── POST login (wbloks/fetch) ───
        login_headers = {
            "user-agent": WEB_USER_AGENT,
            "content-type": "application/x-www-form-urlencoded;charset=UTF-8",
            "origin": "https://www.instagram.com",
            "referer": "https://www.instagram.com/accounts/login/",
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9",
            "sec-ch-ua": SEC_CH_UA,
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
        }

        logger.info(f"[Auth] Sending wbloks login request to {wbloks_url[:80]}...")

        resp = session.post(
            wbloks_url,
            headers=login_headers,
            data=wbloks_form,
            timeout=30,
            allow_redirects=False,
        )

        resp_text = resp.text
        logger.debug(f"[Auth] Wbloks response ({resp.status_code}): {resp_text[:500]}")

        # Parse wbloks response (format: for (;;);{...json...})
        result = {}
        try:
            json_text = resp_text
            if json_text.startswith("for (;;);"):
                json_text = json_text[len("for (;;);"):]
            result = json.loads(json_text)
        except Exception as e:
            logger.debug(f"Wbloks response JSON parse failed: {e}")

        # Check if login succeeded via Set-Cookie (ds_user_id cookie = success)
        ds_user_id_cookie = None
        session_id_cookie = None
        new_csrf = None
        for name, value in session.cookies.items():
            if name == "ds_user_id" and value:
                ds_user_id_cookie = value
            elif name == "sessionid" and value:
                session_id_cookie = value
            elif name == "csrftoken" and value:
                new_csrf = value

        # ─── Handle: SUCCESS via cookies ───
        if ds_user_id_cookie and session_id_cookie:
            logger.info(f"[Auth] ✅ Login success! ds_user_id={ds_user_id_cookie}")
            login_result = {
                "status": "ok",
                "authenticated": True,
                "user_id": ds_user_id_cookie,
                "session_id": session_id_cookie,
                "username": username,
            }
            self._handle_login_success(session, login_result, username)
            self._save_device_cookies(session)
            return login_result

        # ─── Handle: Wbloks auth_login_request (2-step flow) ───
        auth_encrypted_params = ""
        nonce = ""
        user_id_from_resp = ""

        payload = result.get("payload", {})
        payload_str = json.dumps(payload) if payload else resp_text

        if "auth_login_request_encrypted_params" in payload_str:
            enc_match = re.search(r'auth_login_request_encrypted_params["\\:]+\s*["\\]+(Ac[A-Za-z0-9_-]+)', payload_str)
            if enc_match:
                auth_encrypted_params = enc_match.group(1)

        if "nonce" in payload_str:
            nonce_match = re.search(r'"nonce"["\\:]+\s*["\\]+([A-Za-z0-9+/=]+)', payload_str)
            if nonce_match:
                nonce = nonce_match.group(1)

        if "user_id" in payload_str:
            uid_match = re.search(r'"user_id"["\\:]+\s*["\\]+(\d+)', payload_str)
            if uid_match:
                user_id_from_resp = uid_match.group(1)

        # Step 2: auth_login_request (if we got auth params)
        if auth_encrypted_params and nonce:
            logger.info("[Auth] Step 2: Sending auth_login_request...")

            auth_params = {
                "server_params": {
                    "credentials": [],
                    "login_source": "AccountsYouMayHave",
                    "auth_login_request_encrypted_params": auth_encrypted_params,
                    "INTERNAL__latency_qpl_marker_id": 36707139,
                    "INTERNAL__latency_qpl_instance_id": str(random.randint(10**13, 10**14)),
                    "device_id": mid_value,
                    "family_device_id": None,
                    "waterfall_id": str(uuid.uuid4()),
                    "offline_experiment_group": None,
                    "layered_homepage_experiment_group": None,
                    "is_platform_login": 0,
                    "is_from_logged_in_switcher": 0,
                    "is_from_logged_out": 0,
                    "access_flow_version": "pre_mt_behavior",
                    "login_surface": "unknown",
                },
                "client_input_params": {
                    "cloud_trust_token": None,
                    "block_store_machine_id": "",
                    "user_id": user_id_from_resp,
                    "nonce": nonce,
                    "network_bssid": None,
                    "lois_settings": {"lois_token": ""},
                    "aac": "",
                },
            }

            auth_params_json = json.dumps({"params": json.dumps(auth_params)})
            auth_form = self._build_wbloks_form(auth_params_json, new_csrf or csrf_token)
            auth_url = self._build_wbloks_url(AUTH_LOGIN_APPID)

            resp2 = session.post(
                auth_url,
                headers=login_headers,
                data=auth_form,
                timeout=30,
                allow_redirects=False,
            )

            logger.debug(f"[Auth] Auth login response ({resp2.status_code}): {resp2.text[:500]}")

            for name, value in session.cookies.items():
                if name == "ds_user_id" and value:
                    ds_user_id_cookie = value
                elif name == "sessionid" and value:
                    session_id_cookie = value

            if ds_user_id_cookie and session_id_cookie:
                logger.info(f"[Auth] ✅ Login success (step 2)! ds_user_id={ds_user_id_cookie}")
                login_result = {
                    "status": "ok",
                    "authenticated": True,
                    "user_id": ds_user_id_cookie,
                    "session_id": session_id_cookie,
                    "username": username,
                }
                self._handle_login_success(session, login_result, username)
                self._save_device_cookies(session)
                return login_result

        # ─── Fallback: Try legacy web_login_ajax endpoint ───
        logger.warning("[Auth] Wbloks login did not yield session — falling back to legacy endpoint")
        login_data = {
            "username": username,
            "enc_password": enc_password,
            "queryParams": "{}",
            "optIntoOneTap": "false",
            "trustedDeviceRecords": "{}",
        }
        login_headers["x-csrftoken"] = new_csrf or csrf_token
        login_headers["x-requested-with"] = "XMLHttpRequest"
        login_headers["x-ig-app-id"] = "1217981644879628"
        login_headers["x-instagram-ajax"] = x_instagram_ajax

        resp = session.post(
            LOGIN_URL,
            headers=login_headers,
            data=login_data,
            timeout=30,
            allow_redirects=False,
        )

        try:
            result = resp.json()
        except Exception as e:
            raise LoginError(f"Failed to parse login response: {resp.text[:200]}")

        logger.debug(f"[Auth] Legacy login response: {json.dumps(result, ensure_ascii=False)[:300]}")

        # ─── Handle: SUCCESS ───
        if result.get("authenticated"):
            login_result = self._handle_login_success(session, result, username)
            self._save_device_cookies(session)
            return login_result

        # ─── Handle: TWO-FACTOR ───
        if result.get("two_factor_required"):
            two_factor_info = result.get("two_factor_info", {})
            identifier = two_factor_info.get("two_factor_identifier", "")

            if verification_code:
                tfa_result = self._verify_two_factor(session, username, identifier, verification_code, csrf_token, login_headers)
                self._save_device_cookies(session)
                return tfa_result
            elif two_factor_callback:
                code = two_factor_callback()
                tfa_result = self._verify_two_factor(session, username, identifier, code, csrf_token, login_headers)
                self._save_device_cookies(session)
                return tfa_result
            else:
                raise TwoFactorRequired(
                    f"Two-factor authentication required. "
                    f"Provide verification_code or two_factor_callback parameter. "
                    f"Identifier: {identifier}"
                )

        # ─── Handle: CHECKPOINT (Layer 3 — auto-resolve) ───
        checkpoint_url = result.get("checkpoint_url")
        if not checkpoint_url and result.get("message") == "checkpoint_required":
            checkpoint_url = result.get("flow_render_data", {}).get("checkpoint_url", "")
        if checkpoint_url:
            logger.info(f"[Auth] Checkpoint triggered: {checkpoint_url}")
            return self._resolve_checkpoint(
                session, checkpoint_url, csrf_token,
                challenge_callback, username, password,
            )

        # ─── Handle: checkpoint_required without URL ───
        if result.get("message") == "checkpoint_required":
            logger.info("[Auth] checkpoint_required but no URL — probing for challenge...")
            challenge_url = self._probe_for_challenge(session, csrf_token, login_headers, login_data)
            if challenge_url:
                logger.info(f"[Auth] Challenge found: {challenge_url}")
                return self._resolve_checkpoint(
                    session, challenge_url, csrf_token,
                    challenge_callback, username, password,
                )
            raise LoginError(
                f"Checkpoint required but could not find challenge URL. "
                f"Please login via browser first to resolve the challenge."
            )

        # ─── Handle: AuthPlatformLoginChallengeException ───
        exception_name = result.get("exception_name", "")
        error_type = result.get("error_type", "")
        is_auth_platform = (
            "AuthPlatform" in exception_name
            or error_type == "AuthPlatformLoginChallengeException"
        )
        if is_auth_platform:
            ap_url = result.get("checkpoint_url", "/auth_platform/")
            logger.info(f"[Auth] AuthPlatform challenge detected: {ap_url[:80]}...")
            return self._resolve_checkpoint(
                session, ap_url,
                csrf_token, challenge_callback, username, password,
            )

        # ─── Handle: UserInvalidCredentials (might be a masked challenge!) ───
        error_type = result.get("error_type", "")
        user_exists = result.get("user", False)

        if error_type == "UserInvalidCredentials" and user_exists:
            logger.info("[Auth] UserInvalidCredentials with user=true — probing for hidden challenge...")
            challenge_url = self._probe_for_challenge(session, csrf_token, login_headers, login_data)

            if challenge_url:
                logger.info(f"[Auth] Hidden challenge found: {challenge_url}")
                resolve_result = self._resolve_checkpoint(
                    session, challenge_url, csrf_token,
                    challenge_callback, username, password,
                )
                if resolve_result.get("authenticated"):
                    return resolve_result
                logger.info("[Auth] Challenge resolved — retrying login...")
                time.sleep(2)
                return self.login(
                    username, password,
                    two_factor_callback=two_factor_callback,
                    challenge_callback=challenge_callback,
                    email_credentials=getattr(self, '_email_credentials', None),
                    device_cookies_file=self._device_cookies_file,
                )

            raise LoginError(
                f"Incorrect username or password for @{username}."
            )

        if error_type == "UserInvalidCredentials":
            raise LoginError(f"Username @{username} not found or password incorrect.")

        # ─── Handle: user=true, authenticated=false (needs checkpoint) ───
        if result.get("user") and not result.get("authenticated"):
            logger.info("[Auth] Password accepted but not authenticated — probing...")
            challenge_url = self._probe_for_challenge(session, csrf_token, login_headers, login_data)
            if challenge_url:
                return self._resolve_checkpoint(
                    session, challenge_url, csrf_token,
                    challenge_callback, username, password,
                )
            logger.info("[Auth] No challenge URL — trying auth_platform...")
            return self._resolve_checkpoint(
                session, "/auth_platform/", csrf_token,
                challenge_callback, username, password,
            )

        raise LoginError(f"Login failed: {json.dumps(result, ensure_ascii=False)}")


# Backward-compatible exports
__all__ = [
    "AuthAPI",
    "LoginError",
    "TwoFactorRequired",
    "CheckpointRequired",
    "WEB_USER_AGENT",
    "SEC_CH_UA",
]
