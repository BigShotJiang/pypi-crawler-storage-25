"""
GraphQL API
===========
Fetch data via Instagram GraphQL API.
Supports both legacy query_hash (GET) and modern doc_id (POST).

Two transport modes:
    - query_hash GET  → old style, still works for some queries
    - doc_id POST     → new style (2024+), required for newer endpoints

Full information can be retrieved with pagination via GraphQL.

Module structure:
    - registries.py      → QUERY_HASHES, DOC_IDS
    - transport.py       → GET/POST transport methods
    - parsers.py         → Response parsing (timeline connection, v2 media)
    - queries.py         → Read-only queries (followers, posts, comments, ...)
    - feeds.py           → Feed/timeline queries (timeline, liked, saved, ...)
    - mutations.py       → Write operations (like, save, unsave)
    - hash_validator.py  → Hash/doc_id expiry detection & validation
"""

from ...client import HttpClient
from .registries import QUERY_HASHES, DOC_IDS
from .queries import GraphQLQueries
from .feeds import GraphQLFeeds
from .mutations import GraphQLMutations
from .parsers import GraphQLParsers
from .transport import GraphQLTransport
from .hash_validator import HashValidator, GraphQLHashExpired


class GraphQLAPI(GraphQLQueries, GraphQLFeeds, GraphQLMutations):
    """
    Instagram GraphQL query API.

    Supports both legacy query_hash (GET) and modern doc_id (POST).
    Inherits all query, feed, and mutation methods via MRO.
    """

    def __init__(self, client: HttpClient):
        """
        Init.

        Args:
            client: Parameter client
        """
        super().__init__(client)


# Backward-compatible exports
__all__ = [
    "GraphQLAPI",
    "QUERY_HASHES",
    "DOC_IDS",
    "GraphQLQueries",
    "GraphQLFeeds",
    "GraphQLMutations",
    "GraphQLParsers",
    "GraphQLTransport",
    "HashValidator",
    "GraphQLHashExpired",
]

