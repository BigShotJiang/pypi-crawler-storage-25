"""
Async Instagram — Main Class
=============================
Async version of Instagram class. Full feature parity.
Uses curl_cffi.AsyncSession for non-blocking I/O.

Usage:
    async with AsyncInstagram.from_env(".env") as ig:
        user = await ig.users.get_by_username("cristiano")

    # Parallel — 50x faster!
    async with AsyncInstagram.from_env() as ig:
        tasks = [ig.users.get_by_username(u) for u in usernames]
        results = await asyncio.gather(*tasks)
"""

import logging
from typing import List, Optional

from .async_client import AsyncHttpClient
from .session_manager import SessionManager
from .proxy_manager import ProxyManager, RotationStrategy
from .proxy_health import ProxyHealthChecker
from .plugin import PluginManager
from .anti_detect import AntiDetect
from .async_rate_limiter import AsyncRateLimiter
from .speed_modes import get_mode
from .async_challenge import AsyncChallengeHandler
from .retry import RetryConfig
from .log_config import LogConfig, DebugLogger, set_debug_logger
from .events import EventEmitter, EventType, EventData
from .async_anon_client import AsyncAnonClient
from .api.async_users import AsyncUsersAPI
from .api.async_media import AsyncMediaAPI
from .api.async_friendships import AsyncFriendshipsAPI
from .api.async_feed import AsyncFeedAPI
from .api.async_stories import AsyncStoriesAPI
from .api.async_direct import AsyncDirectAPI
from .api.async_search import AsyncSearchAPI
from .api.async_upload import AsyncUploadAPI
from .api.async_hashtags import AsyncHashtagsAPI
from .api.async_insights import AsyncInsightsAPI
from .api.async_account import AsyncAccountAPI
from .api.async_notifications import AsyncNotificationsAPI
from .api.async_graphql import AsyncGraphQLAPI
from .api.async_location import AsyncLocationAPI
from .api.async_collections import AsyncCollectionsAPI
from .api.async_download import AsyncDownloadAPI
from .api.async_auth import AsyncAuthAPI
from .api.async_public import AsyncPublicAPI
from .api.async_growth import AsyncGrowthAPI
from .api.async_automation import AsyncAutomationAPI
from .api.async_monitor import AsyncMonitorAPI
from .api.async_bulk_download import AsyncBulkDownloadAPI
from .api.async_hashtag_research import AsyncHashtagResearchAPI
from .api.async_pipeline import AsyncPipelineAPI
from .api.async_ai_suggest import AsyncAISuggestAPI
from .api.async_audience import AsyncAudienceAPI
from .api.async_comment_manager import AsyncCommentManagerAPI
from .api.async_ab_test import AsyncABTestAPI
from .api.async_public_data import AsyncPublicDataAPI
from .api.async_export import AsyncExportAPI
from .api.async_analytics import AsyncAnalyticsAPI
from .api.async_scheduler import AsyncSchedulerAPI
from .api.async_discover import AsyncDiscoverAPI
from .batch import BatchAPI

logger = logging.getLogger("instaharvest_v2.async")


class AsyncInstagram:
    """
    Async Instagram Private API.

    Speed modes:
        🐢 SAFE  — 5 concurrent, human delays, ban-proof
        ⚡ FAST  — 15 concurrent, moderate delays, balanced
        🚀 TURBO — 50 concurrent, minimal delays, proxy required

    Usage:
        async with AsyncInstagram.from_env(mode='fast') as ig:
            results = await ig.batch.check_profiles(usernames)

    Parallel operations:
        async with AsyncInstagram.from_env(mode='turbo') as ig:
            tasks = [ig.users.get_by_username(u) for u in usernames]
            profiles = await asyncio.gather(*tasks)
    """

    def __init__(
        self,
        session_id: Optional[str] = None,
        csrf_token: Optional[str] = None,
        ds_user_id: Optional[str] = None,
        mid: str = "",
        ig_did: str = "",
        datr: str = "",
        user_agent: str = "",
        mode: str = "safe",
        rate_limiting: bool = True,
        challenge_callback=None,
        session_file: Optional[str] = None,
        retry: Optional[RetryConfig] = None,
        log_level: str = "WARNING",
        log_file: Optional[str] = None,
        log_format: Optional[str] = None,
        debug: bool = False,
        debug_log_file: Optional[str] = None,
    ):
        # ─── DEBUG MODE ──────────────────────────────────────
        """
        Init.

        Args:
            session_id: Parameter session_id
            csrf_token: Parameter csrf_token
            ds_user_id: Parameter ds_user_id
            mid: Parameter mid
            ig_did: Parameter ig_did
            datr: Parameter datr
            user_agent: Parameter user_agent
            mode: Parameter mode
            rate_limiting: Parameter rate_limiting
            challenge_callback: Parameter challenge_callback
            session_file: Parameter session_file
            retry: Parameter retry
            log_level: Parameter log_level
            log_file: Parameter log_file
            log_format: Parameter log_format
            debug: Parameter debug
            debug_log_file: Parameter debug_log_file
        """
        if debug:
            self._debug = DebugLogger(enabled=True, log_file=debug_log_file)
            set_debug_logger(self._debug)
            log_level = "DEBUG"
        else:
            self._debug = DebugLogger(enabled=False)

        # Logging
        LogConfig.configure(
            level=log_level,
            filename=log_file,
            format=log_format,
        )

        self._mode = get_mode(mode)
        self._session_file = session_file
        self._retry = retry or RetryConfig()
        self._events = EventEmitter()

        # Shared infrastructure
        self._session_mgr = SessionManager()
        self._proxy_mgr = ProxyManager()
        self._anti_detect = AntiDetect()
        self._rate_limiter = AsyncRateLimiter(
            mode=mode,
            proxy_count=0,
            enabled=rate_limiting,
        )
        self._challenge_handler = AsyncChallengeHandler(
            code_callback=challenge_callback,
        )
        self._plugin_mgr = PluginManager(event_emitter=self._events)
        self._proxy_health: Optional[ProxyHealthChecker] = None

        # Add initial session if provided
        if session_id:
            self._session_mgr.add_session(
                session_id=session_id,
                csrf_token=csrf_token or "",
                ds_user_id=ds_user_id or "",
                mid=mid,
                ig_did=ig_did,
                datr=datr,
                user_agent=user_agent,
            )

        # Async HTTP client
        self._client = AsyncHttpClient(
            session_manager=self._session_mgr,
            proxy_manager=self._proxy_mgr,
            anti_detect=self._anti_detect,
            rate_limiter=self._rate_limiter,
            challenge_handler=self._challenge_handler,
            session_refresh_callback=self._build_refresh_callback(),
            retry_config=self._retry,
            event_emitter=self._events,
        )

        # Async API modules
        self.users = AsyncUsersAPI(self._client)
        self.media = AsyncMediaAPI(self._client)
        self.friendships = AsyncFriendshipsAPI(self._client)
        self.graphql = AsyncGraphQLAPI(self._client)
        self.feed = AsyncFeedAPI(self._client, graphql=self.graphql)
        self.stories = AsyncStoriesAPI(self._client)
        self.direct = AsyncDirectAPI(self._client)
        self.search = AsyncSearchAPI(self._client)
        self.upload = AsyncUploadAPI(self._client)
        self.hashtags = AsyncHashtagsAPI(self._client)
        self.insights = AsyncInsightsAPI(self._client)
        self.account = AsyncAccountAPI(self._client)
        self.notifications = AsyncNotificationsAPI(self._client)
        self.location = AsyncLocationAPI(self._client)
        self.collections = AsyncCollectionsAPI(self._client)
        self.download = AsyncDownloadAPI(self._client)
        self.auth = AsyncAuthAPI(self._client)
        self.discover = AsyncDiscoverAPI(self._client)

        # High-level API modules (composing low-level APIs)
        self.export = AsyncExportAPI(
            self._client, self.users, self.friendships, self.media, self.hashtags
        )
        self.analytics = AsyncAnalyticsAPI(
            self._client, self.users, self.media, self.feed
        )
        self.scheduler = AsyncSchedulerAPI(self.upload, self.stories)
        self.growth = AsyncGrowthAPI(self._client, self.users, self.friendships)
        self.automation = AsyncAutomationAPI(
            self._client, self.direct, self.media, self.friendships, self.stories
        )
        self.monitor = AsyncMonitorAPI(self._client, self.users, self.feed, self.stories)
        self.bulk_download = AsyncBulkDownloadAPI(
            self._client, self.download, self.users, self.stories
        )
        self.hashtag_research = AsyncHashtagResearchAPI(self._client, self.hashtags)
        self.pipeline = AsyncPipelineAPI(
            self._client, self.users, self.friendships, self.media
        )
        self.ai_suggest = AsyncAISuggestAPI(
            self._client, self.users, self.hashtags, getattr(self, 'hashtag_research', None)
        )
        self.audience = AsyncAudienceAPI(self._client, self.users, self.friendships)
        self.comment_manager = AsyncCommentManagerAPI(self._client, self.media)
        self.ab_test = AsyncABTestAPI(
            self._client, self.upload, self.media, self.analytics
        )

        # Batch operations (async power)
        self.batch = BatchAPI(self)

        # Anonymous public API (TRUE async with AsyncAnonClient)
        self._anon_client = AsyncAnonClient(
            anti_detect=self._anti_detect,
            proxy_manager=self._proxy_mgr,
        )
        self.public = AsyncPublicAPI(self._anon_client)
        
        # Public Data analytics (Supermetrics-style, no login needed)
        self.public_data = AsyncPublicDataAPI(self.public)

    # ─── EVENT SYSTEM ────────────────────────────────────────

    def on(self, event_type, callback):
        """Register event listener."""
        self._events.on(event_type, callback)
        return self

    def off(self, event_type, callback):
        """Remove event listener."""
        self._events.off(event_type, callback)
        return self

    # ─── SESSION AUTO-REFRESH ────────────────────────────────

    def _build_refresh_callback(self):
        """Build session refresh callback for auto-retry on LoginRequired."""
        if not self._session_file:
            return None

        async def _refresh():
            import os
            if os.path.exists(self._session_file):
                try:
                    res = await self.auth.load_session(self._session_file)
                    if res:
                        self._sync_anon_cookies()
                    return res
                except Exception as e:
                    logger.debug(f"Session refresh from file failed: {e}")
            return False

        return _refresh

    # ─── SESSION CONVENIENCE ─────────────────────────────────

    async def save_session(self, filepath: str = "session.json") -> None:
        """Save current session to file."""
        await self.auth.save_session(filepath)

    async def load_session(self, filepath: str = "session.json") -> bool:
        """Load session from file."""
        res = await self.auth.load_session(filepath)
        if res:
            self._sync_anon_cookies()
        return res

    def _sync_anon_cookies(self):
        """
        Sync session cookies to AnonClient.
        Called after sessions are loaded post-init (from_env, from_cookie_file).
        """
        if self._session_mgr.session_count == 0:
            return
        sess = self._session_mgr.get_session()
        if not sess:
            return
        cookies = {
            "sessionid": sess.session_id,
            "ds_user_id": sess.ds_user_id,
        }
        if getattr(sess, 'csrf_token', None):
            cookies["csrftoken"] = sess.csrf_token
        if getattr(sess, 'mid', None):
            cookies["mid"] = sess.mid
        if getattr(sess, 'ig_did', None):
            cookies["ig_did"] = sess.ig_did
        if getattr(sess, 'datr', None):
            cookies["datr"] = sess.datr
        self._anon_client._cookies = cookies

    # ─── FACTORY METHODS ─────────────────────────────────────

    @classmethod
    def from_session_file(
        cls,
        filepath: str = "session.json",
        debug: bool = False,
        debug_log_file: Optional[str] = None,
        **kwargs,
    ) -> "AsyncInstagram":
        """Create async client from saved session file."""
        import json, os
        ig = cls(
            session_file=filepath,
            debug=debug,
            debug_log_file=debug_log_file,
            **kwargs,
        )
        # Load session synchronously (load_session is async, can't call here)
        if os.path.exists(filepath):
            with open(filepath, "r") as f:
                data = json.load(f)
            ig._session_mgr.add_session(
                session_id=data["session_id"],
                csrf_token=data["csrf_token"],
                ds_user_id=data.get("ds_user_id", data.get("user_id", "")),
                mid=data.get("mid", ""),
                ig_did=data.get("ig_did", ""),
                datr=data.get("datr", ""),
                user_agent=data.get("user_agent", ""),
                ig_www_claim=data.get("ig_www_claim", ""),
                rur=data.get("rur", ""),
            )
            ig._sync_anon_cookies()
        return ig

    @classmethod
    def anonymous(
        cls,
        mode: str = "safe",
        unlimited: bool = False,
        profile_strategies=None,
        posts_strategies=None,
    ) -> "AsyncInstagram":
        """
        Create anonymous-only async client (no login).

        Args:
            mode: Speed mode — 'safe', 'fast', 'turbo', or 'unlimited'
            unlimited: If True, force unlimited mode (no delays, no rate limits)
            profile_strategies: Custom profile strategy order.
                               Default: ["web_api", "graphql", "html_parse"]
            posts_strategies: Custom posts strategy order.
                             Default: ["web_api", "html_parse", "graphql", "mobile_feed"]

        Usage:
            async with AsyncInstagram.anonymous() as ig:
                profile = await ig.public.get_profile("cristiano")

            # Custom strategy + unlimited:
            async with AsyncInstagram.anonymous(
                unlimited=True,
                profile_strategies=["web_api", "html_parse"],
            ) as ig:
                tasks = [ig.public.get_profile(u) for u in usernames]
                results = await asyncio.gather(*tasks)
        """
        if unlimited:
            mode = "unlimited"
        instance = cls(mode=mode, rate_limiting=not unlimited)
        # Override with unlimited AsyncAnonClient + strategies
        instance._anon_client = AsyncAnonClient(
            anti_detect=instance._anti_detect,
            proxy_manager=instance._proxy_mgr,
            unlimited=unlimited,
            profile_strategies=profile_strategies,
            posts_strategies=posts_strategies,
        )
        instance.public = AsyncPublicAPI(instance._anon_client)
        return instance

    @classmethod
    def from_env(
        cls,
        env_path: str = ".env",
        mode: str = "safe",
        rate_limiting: bool = True,
        debug: bool = False,
        debug_log_file: Optional[str] = None,
    ) -> "AsyncInstagram":
        """
        Create async client from .env file.

        Args:
            env_path: Path to .env file
            mode: Speed mode — 'safe', 'fast', or 'turbo'
            rate_limiting: Enable/disable rate limiting
            debug: Enable structured debug logging
            debug_log_file: Debug log file path
        """
        instance = cls(
            mode=mode,
            rate_limiting=rate_limiting,
            debug=debug,
            debug_log_file=debug_log_file,
        )
        instance._session_mgr.load_from_env(env_path)

        if instance._session_mgr.session_count == 0:
            logger.warning(
                f"No sessions found! Check {env_path}. "
                "SESSION_ID, CSRF_TOKEN, DS_USER_ID are required."
            )

        # Debug: log session info
        if debug and instance._session_mgr.session_count > 0:
            sess = instance._session_mgr.get_session()
            if sess:
                instance._debug.session_info(
                    ds_user_id=sess.ds_user_id,
                    csrf_token=sess.csrf_token,
                    ig_www_claim=sess.ig_www_claim,
                    session_id=sess.session_id,
                    user_agent=sess.user_agent,
                )

        instance._sync_anon_cookies()
        return instance

    @classmethod
    def from_cookie_file(
        cls,
        cookie_path: str,
        debug: bool = False,
        **kwargs,
    ) -> "AsyncInstagram":
        """
        Create async client from browser-exported cookie JSON file.

        Usage:
            async with AsyncInstagram.from_cookie_file("cookies.json") as ig:
                user = await ig.users.get_by_username("cristiano")
        """
        instance = cls(debug=debug, **kwargs)
        sess = instance._session_mgr.load_from_browser_cookies(cookie_path)
        if not sess:
            raise ValueError(f"Failed to load cookies from {cookie_path}")
        instance._sync_anon_cookies()
        return instance

    @classmethod
    def from_cookie_dir(
        cls,
        dir_path: str,
        debug: bool = False,
        **kwargs,
    ) -> "AsyncInstagram":
        """
        Create async client with multiple sessions from a directory of cookie files.
        """
        instance = cls(debug=debug, **kwargs)
        count = instance._session_mgr.load_from_cookie_dir(dir_path)
        if count == 0:
            raise ValueError(f"No valid cookie files found in {dir_path}")
        instance._sync_anon_cookies()
        return instance

    # ─── PROXY MANAGEMENT ─────────────────────────────────────

    def add_proxies(self, proxy_urls: List[str]) -> "AsyncInstagram":
        """Add proxies and auto-update rate limiter concurrency."""
        self._proxy_mgr.add_proxies(proxy_urls)
        self._rate_limiter.update_proxy_count(self._proxy_mgr.active_count)
        return self

    def add_proxy(self, proxy_url: str) -> "AsyncInstagram":
        """Add a single proxy."""
        return self.add_proxies([proxy_url])

    def load_proxies_from_file(self, filepath: str) -> "AsyncInstagram":
        """Load proxies from file (one proxy per line)."""
        with open(filepath, "r") as f:
            proxies = [line.strip() for line in f if line.strip() and not line.startswith("#")]
        self.add_proxies(proxies)
        return self

    def set_proxy_strategy(self, strategy: str) -> "AsyncInstagram":
        """Change proxy rotation strategy."""
        strat_map = {
            "round_robin": RotationStrategy.ROUND_ROBIN,
            "random": RotationStrategy.RANDOM,
            "weighted": RotationStrategy.WEIGHTED,
        }
        self._proxy_mgr.set_strategy(strat_map.get(strategy, RotationStrategy.WEIGHTED))
        return self

    def start_proxy_health(self, interval: float = 300) -> None:
        """Start background proxy health checker."""
        if not self._proxy_health:
            self._proxy_health = ProxyHealthChecker(
                self._proxy_mgr, interval=interval, event_emitter=self._events,
            )
        self._proxy_health.start()

    def stop_proxy_health(self) -> None:
        """Stop proxy health checker."""
        if self._proxy_health:
            self._proxy_health.stop()

    # ─── Settings & Identity ───────────────────────────────────

    def set_rate_limiting(self, enabled: bool) -> "AsyncInstagram":
        """Enable/disable rate limiting."""
        self._rate_limiter.enabled = enabled
        return self

    def rotate_identity(self) -> "AsyncInstagram":
        """Force browser identity rotation (fingerprint, UA, headers)."""
        self._anti_detect.rotate_identity()
        return self

    def pool_status(self) -> dict:
        """Get session pool monitoring status."""
        return self._session_mgr.get_pool_status()

    def add_session(self, session_id: str, csrf_token: str, ds_user_id: str, **kwargs) -> "AsyncInstagram":
        """Add an additional account to the session pool."""
        self._session_mgr.add_session(
            session_id=session_id,
            csrf_token=csrf_token,
            ds_user_id=ds_user_id,
            **kwargs,
        )
        return self

    # ─── LOGIC & AUTH ────────────────────────────────────────

    async def login(self, username: str, password: str, **kwargs):
        """
        Login with username/password.
        Shortcut — calls await ig.auth.login().
        """
        return await self.auth.login(username, password, **kwargs)

    async def warm_up(self) -> bool:
        """
        Warm up the session by doing a basic request to instagram.com.
        """
        sess = self._session_mgr.get_session()
        if not sess:
            return False
        try:
            await self._client.get("/", rate_category="get_default")
            return getattr(sess, 'ig_www_claim', None) is not None
        except Exception as e:
            logger.debug(f"Warm-up failed: {e}")
            return False

    # ─── PLUGIN SYSTEM ───────────────────────────────────────

    def use(self, plugin) -> "AsyncInstagram":
        """Install a plugin. See Plugin base class."""
        self._plugin_mgr.install(plugin, self)
        return self

    def remove_plugin(self, name: str) -> bool:
        """Remove a plugin by name."""
        return self._plugin_mgr.uninstall(name)

    # ─── CONTEXT MANAGER ─────────────────────────────────────

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def close(self) -> None:
        """Clean up async resources."""
        await self._client.close()
        self.stop_proxy_health()
        # Close async anon client session
        if hasattr(self._anon_client, 'close'):
            await self._anon_client.close()

    def __repr__(self) -> str:
        sessions = self._session_mgr.session_count
        proxies = self._proxy_mgr.active_count
        mode = self._mode.name.upper()
        return f"<AsyncInstagram mode={mode} sessions={sessions} proxies={proxies}>"
