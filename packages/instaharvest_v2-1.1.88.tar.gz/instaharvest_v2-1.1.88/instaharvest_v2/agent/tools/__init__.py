"""
Agent Tools Package
===================
Aggregates all tool handler modules and exposes
the unified TOOL_HANDLERS registry.

Sub-modules:
    file_tools       — read_file, list_files
    analysis_tools   — analyze_data, create_chart
    network_tools    — http_request, search_web, send_dm, search_hashtags,
                       search_places, explore_feed
    instagram_tools  — get_profile, get_posts, search_users,
                       get_user_info, get_stories, get_hashtag_info,
                       get_my_account + 15 public anonymous + 22 Phase 4 tools
    media_tools      — download_media, follow_user, get_followers,
                       get_following, get_friendship_status, like_media,
                       comment_media, get_media_info + 18 Phase 4 tools
    growth_tools     — get_non_followers, get_fans, unfollow_non_followers,
                       follow_hashtag_users
    export_tools     — export_followers_csv, export_following_csv,
                       export_post_likers, export_to_json, save_to_sqlite,
                       save_to_jsonl
    system_tools     — write_file, append_to_file, copy_file, move_file,
                       delete_file, file_exists, get_file_info,
                       get_working_directory, create_directory,
                       list_directory, find_files, save_session_data,
                       load_session_data, list_sessions, get_env_var,
                       set_working_directory, get_system_info
    auth_tools       — login, validate_session, logout
    analytics_tools  — engagement_rate, best_posting_times, content_analysis,
                       profile_summary, compare, insights, audience, ab_test
    automation_tools — auto_dm, auto_like, auto_comment, scheduler, monitor
    pipeline_tools   — pipeline export, bulk_download, ai_suggest, comment_manager
"""

# ── File Tools ──────────────────────────────────────────────
from .file_tools import (
    handle_read_file,
    handle_list_files,
)

# ── Analysis Tools ──────────────────────────────────────────
from .analysis_tools import (
    handle_analyze_data,
    handle_create_chart,
)

# ── Network Tools ──────────────────────────────────────────
from .network_tools import (
    handle_http_request,
    handle_search_web,
    handle_send_dm,
    # Phase 4: Advanced Search
    handle_search_hashtags,
    handle_search_places,
    handle_explore_feed,
)

# ── Instagram Profile Tools ────────────────────────────────
from .instagram_tools import (
    handle_get_profile,
    handle_get_posts,
    handle_search_users,
    handle_get_user_info,
    handle_get_stories,
    handle_get_hashtag_info,
    handle_get_my_account,
    # Phase 3: Public Anonymous Tools
    handle_get_user_id,
    handle_is_public,
    handle_exists,
    handle_get_feed,
    handle_get_tagged_posts,
    handle_get_all_posts,
    handle_get_reels,
    handle_get_comments,
    handle_get_highlights,
    handle_get_similar_accounts,
    handle_get_post_by_shortcode,
    handle_get_post_by_url,
    handle_get_media_urls,
    handle_get_hashtag_posts,
    handle_get_location_posts,
    handle_run_diagnostics,
    # Phase 4: Upload & Content Creation
    handle_upload_photo,
    handle_upload_video,
    handle_upload_reel,
    handle_upload_story_photo,
    handle_upload_story_video,
    handle_upload_carousel,
    handle_delete_media,
    # Phase 4: Location
    handle_search_locations,
    handle_get_location_info,
    handle_get_nearby_locations,
    # Phase 4: Feed
    handle_get_timeline,
    handle_get_saved_posts,
    handle_get_liked_posts,
    # Phase 4: Users
    handle_get_full_profile,
    handle_parse_bio,
    # Phase 4: Hashtag Research
    handle_analyze_hashtag,
    handle_suggest_hashtags,
    # Phase 4: Notifications
    handle_get_notifications,
    handle_get_activity_counts,
    # Phase 4: Public Data Analytics
    handle_compare_profiles,
    handle_engagement_analysis,
    handle_build_report,
)

# ── Media & Social Tools ──────────────────────────────────
from .media_tools import (
    handle_download_media,
    handle_follow_user,
    handle_get_followers,
    handle_get_following,
    handle_get_friendship_status,
    handle_like_media,
    handle_comment_media,
    handle_get_media_info,
    # Phase 4: Advanced Media
    handle_get_likers,
    handle_save_media,
    handle_unsave_media,
    handle_get_comment_replies,
    handle_reply_to_comment,
    handle_edit_caption,
    # Phase 4: Advanced Friendships
    handle_block_user,
    handle_unblock_user,
    handle_mute_user,
    handle_unmute_user,
    handle_remove_follower,
    handle_get_pending_requests,
    handle_approve_request,
    handle_get_mutual_followers,
    # Phase 4: Stories Management
    handle_get_story_viewers,
    handle_react_to_story,
    handle_create_highlight,
    handle_get_all_highlights,
)

# ── Growth Tools ───────────────────────────────────────────
from .growth_tools import (
    handle_get_non_followers,
    handle_get_fans,
    handle_unfollow_non_followers,
    handle_follow_hashtag_users,
)

# ── Export & Pipeline Tools ────────────────────────────────
from .export_tools import (
    handle_export_followers_csv,
    handle_export_following_csv,
    handle_export_post_likers,
    handle_export_to_json,
    handle_save_to_sqlite,
    handle_save_to_jsonl,
)

# ── System Utility Tools ──────────────────────────────────
from .system_tools import (
    handle_write_file,
    handle_append_to_file,
    handle_copy_file,
    handle_move_file,
    handle_delete_file,
    handle_file_exists,
    handle_get_file_info,
    handle_get_working_directory,
    handle_create_directory,
    handle_list_directory,
    handle_find_files,
    handle_save_session_data,
    handle_load_session_data,
    handle_list_sessions,
    handle_get_env_var,
    handle_set_working_directory,
    handle_get_system_info,
)

# ── Auth Tools ─────────────────────────────────────────────
from .auth_tools import (
    handle_login,
    handle_validate_session,
    handle_logout,
)

# ── Analytics Tools (analytics, insights, audience, ab_test) ─
from .analytics_tools import (
    handle_get_engagement_rate,
    handle_get_best_posting_times,
    handle_get_content_analysis,
    handle_get_profile_summary,
    handle_compare_accounts,
    handle_get_account_insights,
    handle_get_media_insight,
    handle_get_business_info,
    handle_get_ads_accounts,
    handle_find_lookalike_audience,
    handle_get_audience_overlap,
    handle_get_audience_insights,
    handle_create_ab_test,
    handle_run_ab_test,
    handle_get_ab_results,
    handle_list_ab_tests,
)

# ── Automation Tools (automation, scheduler, monitor) ──────
from .automation_tools import (
    handle_auto_dm_new_followers,
    handle_auto_comment_hashtag,
    handle_auto_like_feed,
    handle_auto_like_hashtag,
    handle_auto_watch_stories,
    handle_get_action_log,
    handle_schedule_post,
    handle_schedule_story,
    handle_schedule_reel,
    handle_list_scheduled_jobs,
    handle_cancel_scheduled_job,
    handle_monitor_account,
    handle_unmonitor_account,
    handle_monitor_check_now,
    handle_get_monitor_events,
    handle_get_monitor_stats,
)

# ── Pipeline Tools (pipeline, bulk_download, ai_suggest, comment_manager)
from .pipeline_tools import (
    handle_pipeline_to_sqlite,
    handle_pipeline_to_jsonl,
    handle_bulk_download_posts,
    handle_bulk_download_stories,
    handle_bulk_download_highlights,
    handle_bulk_download_everything,
    handle_ai_suggest_hashtags,
    handle_ai_suggest_captions,
    handle_manage_comments,
    handle_auto_reply_comments,
    handle_delete_spam_comments,
    handle_get_comment_sentiment,
)

# ── Utility Tools (general purpose) ───────────────────────
from .utility_tools import (
    handle_json_parse,
    handle_csv_to_json,
    handle_json_to_csv,
    handle_calculate,
    handle_text_replace,
    handle_merge_files,
    handle_download_url,
)


# ═══════════════════════════════════════════════════════════
# TOOL REGISTRY — Maps tool names to handlers (161 tools)
# ═══════════════════════════════════════════════════════════

TOOL_HANDLERS = {
    # ── File I/O ──────────────────────────────────────────
    "read_file": handle_read_file,
    "list_files": handle_list_files,
    # ── Media download ────────────────────────────────────
    "download_media": handle_download_media,
    # ── Analysis & Visualization ──────────────────────────
    "analyze_data": handle_analyze_data,
    "create_chart": handle_create_chart,
    # ── Network ───────────────────────────────────────────
    "http_request": handle_http_request,
    "search_web": handle_search_web,
    # ── Instagram — Profile & Read (existing) ─────────────
    "get_profile": handle_get_profile,
    "get_posts": handle_get_posts,
    "search_users": handle_search_users,
    "get_user_info": handle_get_user_info,
    "get_stories": handle_get_stories,
    "get_hashtag_info": handle_get_hashtag_info,
    "get_my_account": handle_get_my_account,
    "get_media_info": handle_get_media_info,
    # ── Phase 3: Public Anonymous (login kerak emas!) ─────
    "get_user_id": handle_get_user_id,
    "is_public": handle_is_public,
    "exists": handle_exists,
    "get_feed": handle_get_feed,
    "get_tagged_posts": handle_get_tagged_posts,
    "get_all_posts": handle_get_all_posts,
    "get_reels": handle_get_reels,
    "get_comments": handle_get_comments,
    "get_highlights": handle_get_highlights,
    "get_similar_accounts": handle_get_similar_accounts,
    "get_post_by_shortcode": handle_get_post_by_shortcode,
    "get_post_by_url": handle_get_post_by_url,
    "get_media_urls": handle_get_media_urls,
    "get_hashtag_posts": handle_get_hashtag_posts,
    "get_location_posts": handle_get_location_posts,
    "run_diagnostics": handle_run_diagnostics,
    # ── Phase 4: Upload & Content Creation ────────────────
    "upload_photo": handle_upload_photo,
    "upload_video": handle_upload_video,
    "upload_reel": handle_upload_reel,
    "upload_story_photo": handle_upload_story_photo,
    "upload_story_video": handle_upload_story_video,
    "upload_carousel": handle_upload_carousel,
    "delete_media": handle_delete_media,
    # ── Phase 4: Advanced Media ───────────────────────────
    "get_likers": handle_get_likers,
    "save_media": handle_save_media,
    "unsave_media": handle_unsave_media,
    "get_comment_replies": handle_get_comment_replies,
    "reply_to_comment": handle_reply_to_comment,
    "edit_caption": handle_edit_caption,
    # ── Phase 4: Advanced Friendships ─────────────────────
    "block_user": handle_block_user,
    "unblock_user": handle_unblock_user,
    "mute_user": handle_mute_user,
    "unmute_user": handle_unmute_user,
    "remove_follower": handle_remove_follower,
    "get_pending_requests": handle_get_pending_requests,
    "approve_request": handle_approve_request,
    "get_mutual_followers": handle_get_mutual_followers,
    # ── Phase 4: Stories Management ───────────────────────
    "get_story_viewers": handle_get_story_viewers,
    "react_to_story": handle_react_to_story,
    "create_highlight": handle_create_highlight,
    "get_all_highlights": handle_get_all_highlights,
    # ── Phase 4: Growth ───────────────────────────────────
    "get_non_followers": handle_get_non_followers,
    "get_fans": handle_get_fans,
    "unfollow_non_followers": handle_unfollow_non_followers,
    "follow_hashtag_users": handle_follow_hashtag_users,
    # ── Phase 4: Export & Pipeline ────────────────────────
    "export_followers_csv": handle_export_followers_csv,
    "export_following_csv": handle_export_following_csv,
    "export_post_likers": handle_export_post_likers,
    "export_to_json": handle_export_to_json,
    "save_to_sqlite": handle_save_to_sqlite,
    "save_to_jsonl": handle_save_to_jsonl,
    # ── Phase 4: Location ─────────────────────────────────
    "search_locations": handle_search_locations,
    "get_location_info": handle_get_location_info,
    "get_nearby_locations": handle_get_nearby_locations,
    # ── Phase 4: Feed ─────────────────────────────────────
    "get_timeline": handle_get_timeline,
    "get_saved_posts": handle_get_saved_posts,
    "get_liked_posts": handle_get_liked_posts,
    # ── Phase 4: Users ────────────────────────────────────
    "get_full_profile": handle_get_full_profile,
    "parse_bio": handle_parse_bio,
    # ── Phase 4: Hashtag Research ─────────────────────────
    "analyze_hashtag": handle_analyze_hashtag,
    "suggest_hashtags": handle_suggest_hashtags,
    # ── Phase 4: Notifications ────────────────────────────
    "get_notifications": handle_get_notifications,
    "get_activity_counts": handle_get_activity_counts,
    # ── Phase 4: Public Data Analytics ────────────────────
    "compare_profiles": handle_compare_profiles,
    "engagement_analysis": handle_engagement_analysis,
    "build_report": handle_build_report,
    # ── Phase 4: Advanced Search ──────────────────────────
    "search_hashtags": handle_search_hashtags,
    "search_places": handle_search_places,
    "explore_feed": handle_explore_feed,
    # ── Instagram Write Actions ───────────────────────────
    "follow_user": handle_follow_user,
    "get_followers": handle_get_followers,
    "get_following": handle_get_following,
    "get_friendship_status": handle_get_friendship_status,
    "like_media": handle_like_media,
    "comment_media": handle_comment_media,
    "send_dm": handle_send_dm,
    # ── System Utility Tools ───────────────────────────────
    "write_file": handle_write_file,
    "append_to_file": handle_append_to_file,
    "copy_file": handle_copy_file,
    "move_file": handle_move_file,
    "delete_file": handle_delete_file,
    "file_exists": handle_file_exists,
    "get_file_info": handle_get_file_info,
    "get_working_directory": handle_get_working_directory,
    "create_directory": handle_create_directory,
    "list_directory": handle_list_directory,
    "find_files": handle_find_files,
    "save_session_data": handle_save_session_data,
    "load_session_data": handle_load_session_data,
    "list_sessions": handle_list_sessions,
    "get_env_var": handle_get_env_var,
    "set_working_directory": handle_set_working_directory,
    "get_system_info": handle_get_system_info,
    # ═══════════════════════════════════════════════════════
    # PHASE 5: Auth, Analytics, Automation, Pipeline (47 tools)
    # ═══════════════════════════════════════════════════════
    # ── Auth ──────────────────────────────────────────────
    "login": handle_login,
    "validate_session": handle_validate_session,
    "logout": handle_logout,
    # ── Analytics ─────────────────────────────────────────
    "get_engagement_rate": handle_get_engagement_rate,
    "get_best_posting_times": handle_get_best_posting_times,
    "get_content_analysis": handle_get_content_analysis,
    "get_profile_summary": handle_get_profile_summary,
    "compare_accounts": handle_compare_accounts,
    # ── Insights ──────────────────────────────────────────
    "get_account_insights": handle_get_account_insights,
    "get_media_insight": handle_get_media_insight,
    "get_business_info": handle_get_business_info,
    "get_ads_accounts": handle_get_ads_accounts,
    # ── Audience ──────────────────────────────────────────
    "find_lookalike_audience": handle_find_lookalike_audience,
    "get_audience_overlap": handle_get_audience_overlap,
    "get_audience_insights": handle_get_audience_insights,
    # ── A/B Testing ───────────────────────────────────────
    "create_ab_test": handle_create_ab_test,
    "run_ab_test": handle_run_ab_test,
    "get_ab_results": handle_get_ab_results,
    "list_ab_tests": handle_list_ab_tests,
    # ── Automation ────────────────────────────────────────
    "auto_dm_new_followers": handle_auto_dm_new_followers,
    "auto_comment_hashtag": handle_auto_comment_hashtag,
    "auto_like_feed": handle_auto_like_feed,
    "auto_like_hashtag": handle_auto_like_hashtag,
    "auto_watch_stories": handle_auto_watch_stories,
    "get_action_log": handle_get_action_log,
    # ── Scheduler ─────────────────────────────────────────
    "schedule_post": handle_schedule_post,
    "schedule_story": handle_schedule_story,
    "schedule_reel": handle_schedule_reel,
    "list_scheduled_jobs": handle_list_scheduled_jobs,
    "cancel_scheduled_job": handle_cancel_scheduled_job,
    # ── Monitor ───────────────────────────────────────────
    "monitor_account": handle_monitor_account,
    "unmonitor_account": handle_unmonitor_account,
    "monitor_check_now": handle_monitor_check_now,
    "get_monitor_events": handle_get_monitor_events,
    "get_monitor_stats": handle_get_monitor_stats,
    # ── Pipeline ──────────────────────────────────────────
    "pipeline_to_sqlite": handle_pipeline_to_sqlite,
    "pipeline_to_jsonl": handle_pipeline_to_jsonl,
    # ── Bulk Download ─────────────────────────────────────
    "bulk_download_posts": handle_bulk_download_posts,
    "bulk_download_stories": handle_bulk_download_stories,
    "bulk_download_highlights": handle_bulk_download_highlights,
    "bulk_download_everything": handle_bulk_download_everything,
    # ── AI Suggest ────────────────────────────────────────
    "ai_suggest_hashtags": handle_ai_suggest_hashtags,
    "ai_suggest_captions": handle_ai_suggest_captions,
    # ── Comment Manager ───────────────────────────────────
    "manage_comments": handle_manage_comments,
    "auto_reply_comments": handle_auto_reply_comments,
    "delete_spam_comments": handle_delete_spam_comments,
    "get_comment_sentiment": handle_get_comment_sentiment,
    # ── Utility Tools ─────────────────────────────────────
    "json_parse": handle_json_parse,
    "csv_to_json": handle_csv_to_json,
    "json_to_csv": handle_json_to_csv,
    "calculate": handle_calculate,
    "text_replace": handle_text_replace,
    "merge_files": handle_merge_files,
    "download_url": handle_download_url,
}
