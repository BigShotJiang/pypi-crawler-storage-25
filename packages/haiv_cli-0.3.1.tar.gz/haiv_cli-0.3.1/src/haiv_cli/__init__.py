"""haiv: Seamless management of a collaborative AI team."""

import io
import os
import shlex
import sys
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import cast

import haiv_core
import haiv_core.commands
import haiv_mail
import haiv_mail.commands

from haiv._infrastructure import env
from haiv.paths import get_haiv_root, Paths
from haiv._infrastructure.routing import find_route, RouteMatch
from haiv._infrastructure.loader import load_commands_module
from haiv._infrastructure.identity import detect_user, Identity, AmbiguousIdentityError
from haiv.util import module_to_folder

__version__ = "0.1.0"

# Package roots (computed once at import)
_core_root = module_to_folder(haiv_core)
_mail_root = module_to_folder(haiv_mail)

# Cached haiv_root lookup
_haiv_root: Path | None = None
_haiv_root_error: Exception | None = None

# Cached user detection
_user: Identity | None = None
_user_error: Exception | None = None


def _get_haiv_root_cached() -> Path:
    """Get haiv_root, caching the result (success or failure)."""
    global _haiv_root, _haiv_root_error

    if _haiv_root is None and _haiv_root_error is None:
        try:
            _haiv_root = get_haiv_root(cwd=Path.cwd())
        except Exception as e:
            _haiv_root_error = e

    if _haiv_root_error is not None:
        raise _haiv_root_error

    return cast(Path, _haiv_root)


def _detect_user_cached() -> Identity:
    """Detect user, caching the result (success or failure)."""
    global _user, _user_error

    if _user is None and _user_error is None:
        try:
            haiv_root = _get_haiv_root_cached()
            paths = Paths(_called_from=None, _pkg_root=None, _haiv_root=haiv_root, _core_root=_core_root)
            _user = detect_user(paths.users_dir)
            if _user is None:
                raise Exception(
                    "No user identity found.\n"
                    "Run 'hv users new --name <name>' to create one."
                )
        except Exception as e:
            _user_error = e

    if _user_error is not None:
        raise _user_error

    return cast(Identity, _user)


@dataclass
class CommandSource:
    """Tracks a command source and whether it was checked."""

    name: str
    path: str
    checked: bool
    error: str | None = None


def _handle_error(exc: Exception) -> None:
    """Handle an exception: print message, log traceback, exit."""
    from haiv.errors import handle_error
    handle_error(exc)


def _try_source(
    command_string: str,
    name: str,
    path: str,
    get_commands: Callable[[], ModuleType],
) -> tuple[RouteMatch | None, CommandSource]:
    """Try to find a command in a single source.

    Args:
        command_string: The command to find
        name: Source name for error reporting
        path: Source path for error reporting
        get_commands: Callable that returns the commands module

    Returns:
        (route, source) - route is None if not found or source unavailable
    """
    try:
        commands = get_commands()
        route = find_route(command_string, commands)
        return route, CommandSource(name, path, checked=True)
    except Exception as e:
        return None, CommandSource(name, path, checked=False, error=str(e))


def _get_project_commands() -> ModuleType:
    """Load haiv_project commands module."""
    haiv_root = _get_haiv_root_cached()
    os.environ[env.HV_ROOT] = str(haiv_root)

    paths = Paths(_called_from=None, _pkg_root=None, _haiv_root=haiv_root, _core_root=_core_root)
    return load_commands_module(paths.pkgs.project.commands_dir / "__init__.py")


def _get_user_commands() -> ModuleType:
    """Load haiv_user commands module."""
    haiv_root = _get_haiv_root_cached()
    user = _detect_user_cached()

    paths = Paths(_called_from=None, _pkg_root=None, _haiv_root=haiv_root, _user_name=user.name, _core_root=_core_root)
    return load_commands_module(paths.pkgs.user.commands_dir / "__init__.py")


def _find_command(
    command_string: str,
) -> tuple[RouteMatch | None, Path | None, list[CommandSource]]:
    """Try to find a command across all sources.

    Returns:
        (route, haiv_root, sources) - route is None if not found
    """
    sources: list[CommandSource] = []

    # Try haiv_user first (highest precedence)
    route, source = _try_source(
        command_string,
        "haiv_user",
        "users/{user}/src/haiv_user/commands/",
        _get_user_commands,
    )
    sources.append(source)
    if route is not None:
        return route, _haiv_root, sources

    # Try haiv_project next
    route, source = _try_source(
        command_string,
        "haiv_project",
        "src/haiv_project/commands/",
        _get_project_commands,
    )
    sources.append(source)
    if route is not None:
        return route, _haiv_root, sources

    # Try haiv_mail (installed infrastructure)
    route, source = _try_source(
        command_string,
        "haiv_mail",
        "(installed)",
        lambda: haiv_mail.commands,
    )
    sources.append(source)
    if route is not None:
        return route, _haiv_root, sources

    # Fall back to haiv_core (always available)
    route, source = _try_source(
        command_string,
        "haiv_core",
        "(installed)",
        lambda: haiv_core.commands,
    )
    sources.append(source)

    return route, _haiv_root, sources


def _print_not_found(command_string: str, sources: list[CommandSource]) -> None:
    """Print helpful error when command not found."""
    print(f"Unknown command: {command_string}", file=sys.stderr)

    checked = [s for s in sources if s.checked]
    not_checked = [s for s in sources if not s.checked]

    if checked:
        print("\nChecked:", file=sys.stderr)
        for s in checked:
            print(f"  ✓ {s.name} {s.path}", file=sys.stderr)

    if not_checked:
        print("\nCould not check:", file=sys.stderr)
        for s in not_checked:
            print(f"  ✗ {s.name} {s.path}", file=sys.stderr)
            if s.error:
                print(f"    {s.error}", file=sys.stderr)


def main():
    """Entry point for haiv CLI.

    Routes commands to the correct venv for execution:
    - Core/mail commands run in-process (already in the right venv)
    - Project/user commands relay to their own venv via subprocess
    """
    cast(io.TextIOWrapper, sys.stdout).reconfigure(encoding="utf-8")
    cast(io.TextIOWrapper, sys.stderr).reconfigure(encoding="utf-8")

    # HV_PROG allows the wrapper script to pass its name (e.g., when using python -c)
    prog = os.environ.get(env.HV_PROG) or Path(sys.argv[0]).name
    args = sys.argv[1:]

    if not args:
        print(f"{prog} v{__version__}")
        print(f"Usage: {prog} <command> [args...]")
        print(f"Run '{prog} help' for available commands")
        return

    # Claude Code hooks: hv --claude-hook <hook_name> [args...]
    if args[0] == "--claude-hook":
        from haiv_cli.claude_hooks_dispatch import dispatch
        dispatch(args[1:])
        return

    command_string = shlex.join(args)

    route, haiv_root, sources = _find_command(command_string)

    if route is None:
        _print_not_found(command_string, sources)
        sys.exit(1)
        raise AssertionError("unreachable")

    if route.file is None:
        raise RuntimeError(
            f"RouteMatch.file is None for '{command_string}'. "
            "This indicates a bug in find_route() - it should return None "
            "instead of a RouteMatch with file=None."
        )

    try:
        # Always surface ambiguous identity — it's a config problem the user must fix.
        # Other detection failures (no user) are fine; some commands don't need one.
        try:
            user = _detect_user_cached()
            haiv_username = user.name
        except AmbiguousIdentityError:
            raise
        except Exception:
            haiv_username = None

        # Check if command needs a different venv
        from haiv._infrastructure.venv_resolver import PyprojectVenvResolver
        from haiv.relay import run_route, subprocess_relay

        venv_match = PyprojectVenvResolver().resolve(route.file)

        if venv_match is not None:
            exit_code = subprocess_relay(
                venv_match.project_root,
                route,
                haiv_root=haiv_root,
                haiv_username=haiv_username,
            )
            sys.exit(exit_code)

        run_route(route, haiv_root=haiv_root, haiv_username=haiv_username)
    except Exception as exc:
        _handle_error(exc)


if __name__ == "__main__":
    main()
