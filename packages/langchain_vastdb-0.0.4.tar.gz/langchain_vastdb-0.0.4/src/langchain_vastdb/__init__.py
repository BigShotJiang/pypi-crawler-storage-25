"""langchain-vastdb — LangChain VectorStore integration for VAST Database."""

from langchain_vastdb.vectorstores import TypedColumn, VastDBVectorStore

__all__ = ["TypedColumn", "VastDBVectorStore"]
