import math
import operator

def nod(numbers):
    if not numbers:
        return 0
    return operator.reduce(operator.gcd, numbers)

def nok(numbers):
    if not numbers:
        return 0
    return operator.reduce(lambda a, b: abs(a * b) // operator.gcd(a, b), numbers)

def average(scores):
    if not scores:
        return 0
    return sum(scores) / len(scores)