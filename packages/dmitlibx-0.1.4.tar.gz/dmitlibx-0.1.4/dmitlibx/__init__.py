# Импорт функций
from .utils import *
from .math import *
from .vk import *