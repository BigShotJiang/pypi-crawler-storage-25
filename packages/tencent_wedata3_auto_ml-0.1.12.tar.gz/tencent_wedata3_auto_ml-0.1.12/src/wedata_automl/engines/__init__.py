"""
WeData AutoML Engines 模块

本模块包含 AutoML 训练引擎的实现。

模块结构（重构后）：
- flaml_trainer: FLAML 训练器（训练编排核心）
- data_loader: 数据加载、时区处理、Spark 转换、数据划分、特征存储
- metrics: 自定义指标、指标验证、估计器列表
- mlflow_manager: MLflow 实验设置、Tag 管理、模型记录/注册
- forecast_handler: 时序预测专用逻辑（ForecastModelWrapper、频率推断、预测保存）
- log_manager: FLAML 日志文件路径生成和清理
- trial_hook: Trial 回调钩子（独立模块，未在本次重构范围内）
"""

# 主要导出：FLAMLTrainer 是外部唯一需要的入口
from wedata_automl.engines.flaml_trainer import FLAMLTrainer

__all__ = ["FLAMLTrainer"]
