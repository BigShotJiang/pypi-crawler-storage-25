"""
FLAML 日志文件管理

提供 FLAML log 文件的路径生成和旧文件清理功能。
"""
import os
import time
import uuid
import tempfile
from typing import Optional
from datetime import datetime

from wedata_automl.utils.print_utils import safe_print


def generate_log_file_path(
    base_dir: Optional[str] = None,
    run_id: Optional[str] = None,
    use_timestamp: bool = True,
    use_uuid: bool = True
) -> str:
    """
    生成唯一的 FLAML log 文件路径

    解决的问题：
    1. 避免重复 fit() 时 log 被覆盖
    2. 支持多进程/多节点环境
    3. 便于日志管理和清理

    Args:
        base_dir: 基础目录，默认使用系统临时目录
        run_id: MLflow run ID，用于关联 log 文件
        use_timestamp: 是否在文件名中包含时间戳
        use_uuid: 是否在文件名中包含 UUID

    Returns:
        log 文件的完整路径

    Example:
        >>> path = generate_log_file_path()
        >>> # /tmp/wedata_automl/flaml_20251125_143022_abc123_run456.log
    """
    # 确定基础目录
    if base_dir is None:
        # 使用系统临时目录 + wedata_automl 子目录
        base_dir = os.path.join(tempfile.gettempdir(), "wedata_automl", "flaml_logs")

    # 确保目录存在
    os.makedirs(base_dir, exist_ok=True)

    # 构建文件名
    parts = ["flaml"]

    if use_timestamp:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        parts.append(timestamp)

    if use_uuid:
        short_uuid = str(uuid.uuid4())[:8]
        parts.append(short_uuid)

    if run_id:
        parts.append(f"run{run_id[:8]}")

    filename = "_".join(parts) + ".log"

    return os.path.join(base_dir, filename)


def cleanup_old_log_files(  # noqa: C901
    base_dir: Optional[str] = None,
    max_age_hours: int = 24,
    max_files: int = 100,
    dry_run: bool = False
) -> int:
    """
    清理旧的 FLAML log 文件

    解决的问题：
    1. 防止 log 文件累积过多
    2. 自动清理过期的 log 文件

    Args:
        base_dir: 基础目录，默认使用系统临时目录
        max_age_hours: 最大保留时间（小时），超过此时间的文件将被删除
        max_files: 最大保留文件数，超过此数量的旧文件将被删除
        dry_run: 是否只模拟运行（不实际删除）

    Returns:
        删除的文件数量

    Example:
        >>> # 删除 24 小时前的 log 文件
        >>> count = cleanup_old_log_files(max_age_hours=24)
        >>> print(f"Deleted {count} old log files")
    """
    if base_dir is None:
        base_dir = os.path.join(tempfile.gettempdir(), "wedata_automl", "flaml_logs")

    if not os.path.exists(base_dir):
        return 0

    import glob

    # 获取所有 log 文件
    log_files = glob.glob(os.path.join(base_dir, "flaml_*.log"))

    if not log_files:
        return 0

    # 按修改时间排序（最新的在前）
    log_files.sort(key=lambda x: os.path.getmtime(x) if os.path.exists(x) else float('-inf'), reverse=True)

    deleted_count = 0
    current_time = time.time()
    max_age_seconds = max_age_hours * 3600

    for i, log_file in enumerate(log_files):
        should_delete = False
        reason = ""

        # 检查是否超过最大文件数
        if i >= max_files:
            should_delete = True
            reason = f"exceeds max_files ({max_files})"

        # 检查是否超过最大保留时间
        file_age = current_time - os.path.getmtime(log_file)
        if file_age > max_age_seconds:
            should_delete = True
            reason = f"older than {max_age_hours} hours"

        if should_delete:
            if dry_run:
                safe_print(f"[DRY RUN] Would delete: {log_file} ({reason})")
            else:
                try:
                    os.remove(log_file)
                    deleted_count += 1
                    safe_print(f"Deleted old log file: {log_file} ({reason})")
                except Exception as e:
                    safe_print(f"Failed to delete {log_file}: {e}")

    return deleted_count
