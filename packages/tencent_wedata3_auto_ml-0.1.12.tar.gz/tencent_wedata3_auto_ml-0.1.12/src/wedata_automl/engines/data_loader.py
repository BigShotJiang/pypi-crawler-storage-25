"""
数据加载模块

负责数据加载、Spark 转 Pandas、时区处理、数据划分和特征存储查找等功能。
"""
import logging
import re
from typing import Any, Dict, List, Optional, Union

import pandas as pd

from wedata_automl.utils.print_utils import safe_print, print_separator
from wedata_automl.utils.spark_utils import compute_split_and_weights

logger = logging.getLogger(__name__)


# ============================================================================
# 时区处理
# ============================================================================

# 完整的 GMT 偏移到标准时区映射（优先使用常用城市时区）
_GMT_TO_TZ_MAPPING = {
    # UTC / GMT+0
    ('+', 0, 0): 'UTC',
    ('-', 0, 0): 'UTC',
    # GMT+1 ~ GMT+14
    ('+', 1, 0): 'Europe/Paris',
    ('+', 2, 0): 'Europe/Helsinki',
    ('+', 3, 0): 'Europe/Moscow',
    ('+', 3, 30): 'Asia/Tehran',
    ('+', 4, 0): 'Asia/Dubai',
    ('+', 4, 30): 'Asia/Kabul',
    ('+', 5, 0): 'Asia/Karachi',
    ('+', 5, 30): 'Asia/Kolkata',
    ('+', 5, 45): 'Asia/Kathmandu',
    ('+', 6, 0): 'Asia/Dhaka',
    ('+', 6, 30): 'Asia/Yangon',
    ('+', 7, 0): 'Asia/Bangkok',
    ('+', 8, 0): 'Asia/Shanghai',
    ('+', 8, 45): 'Australia/Eucla',
    ('+', 9, 0): 'Asia/Tokyo',
    ('+', 9, 30): 'Australia/Adelaide',
    ('+', 10, 0): 'Australia/Sydney',
    ('+', 10, 30): 'Australia/Lord_Howe',
    ('+', 11, 0): 'Pacific/Guadalcanal',
    ('+', 12, 0): 'Pacific/Auckland',
    ('+', 12, 45): 'Pacific/Chatham',
    ('+', 13, 0): 'Pacific/Tongatapu',
    ('+', 14, 0): 'Pacific/Kiritimati',
    # GMT-1 ~ GMT-12
    ('-', 1, 0): 'Atlantic/Azores',
    ('-', 2, 0): 'Atlantic/South_Georgia',
    ('-', 3, 0): 'America/Sao_Paulo',
    ('-', 3, 30): 'America/St_Johns',
    ('-', 4, 0): 'America/Halifax',
    ('-', 5, 0): 'America/New_York',
    ('-', 6, 0): 'America/Chicago',
    ('-', 7, 0): 'America/Denver',
    ('-', 8, 0): 'America/Los_Angeles',
    ('-', 9, 0): 'America/Anchorage',
    ('-', 9, 30): 'Pacific/Marquesas',
    ('-', 10, 0): 'Pacific/Honolulu',
    ('-', 11, 0): 'Pacific/Midway',
    ('-', 12, 0): 'Etc/GMT+12',
}


def normalize_timezone(tz_str: str) -> str:
    """
    将非标准时区格式转换为 pytz 兼容格式

    Args:
        tz_str: 时区字符串，如 'GMT+08:00'

    Returns:
        标准时区名，如 'Asia/Shanghai' 或 'Etc/GMT-8'
    """
    # GMT+XX:XX 或 GMT-XX:XX 格式
    match = re.match(r'GMT([+-])(\d{1,2}):?(\d{2})?', tz_str)
    if match:
        sign = match.group(1)
        hours = int(match.group(2))
        minutes = int(match.group(3)) if match.group(3) else 0

        # 尝试从映射表查找
        key = (sign, hours, minutes)
        if key in _GMT_TO_TZ_MAPPING:
            return _GMT_TO_TZ_MAPPING[key]

        # 对于整小时偏移，使用 Etc/GMT 格式
        # 注意：Etc 时区的符号是反的！GMT+8 对应 Etc/GMT-8
        if minutes == 0:
            etc_sign = '-' if sign == '+' else '+'
            return f"Etc/GMT{etc_sign}{hours}"

        # 对于非整小时且不在映射表中的，返回 UTC（降级处理）
        safe_print(f"⚠️  Unknown timezone offset: {tz_str}, falling back to UTC")
        return 'UTC'

    # UTC / Z 格式
    if tz_str.upper() in ('UTC', 'Z'):
        return 'UTC'

    # 已经是标准格式（如 Asia/Shanghai），直接返回
    return tz_str


# ============================================================================
# Spark 转 Pandas
# ============================================================================

def safe_to_pandas(spark_df, spark=None) -> pd.DataFrame:  # noqa: C901
    """
    安全地将 Spark DataFrame 转换为 Pandas DataFrame

    处理时区格式不兼容问题（如 'GMT+08:00' pytz 不识别）

    Args:
        spark_df: Spark DataFrame
        spark: SparkSession（可选，用于修改时区配置）

    Returns:
        Pandas DataFrame
    """
    try:
        return spark_df.toPandas()
    except Exception as e:
        error_msg = str(e)
        # 检查是否是时区格式问题
        if "UnknownTimeZoneError" in error_msg or "GMT" in error_msg:
            safe_print("⚠️  Timezone format issue detected, attempting fix...")

            # 方案 1: 尝试修改 Spark session 时区配置
            if spark is not None:
                try:
                    # 获取当前时区
                    current_tz = spark.conf.get("spark.sql.session.timeZone", "UTC")
                    safe_print(f"   Current timezone: {current_tz}")

                    # 将 GMT+XX:XX 格式转换为标准时区名
                    new_tz = normalize_timezone(current_tz)
                    if new_tz != current_tz:
                        safe_print(f"   Converting timezone to: {new_tz}")
                        spark.conf.set("spark.sql.session.timeZone", new_tz)

                        try:
                            result = spark_df.toPandas()
                            # 恢复原始时区设置
                            spark.conf.set("spark.sql.session.timeZone", current_tz)
                            safe_print("✅ Successfully converted with timezone fix")
                            return result
                        except Exception:
                            # 恢复原始时区设置
                            spark.conf.set("spark.sql.session.timeZone", current_tz)
                except Exception as tz_error:
                    safe_print(f"   Timezone fix failed: {tz_error}")

            # 方案 2: 将 timestamp 列转换为 string 再转换
            safe_print("   Trying alternative: convert timestamps to strings first...")
            try:
                from pyspark.sql.functions import col
                from pyspark.sql.types import TimestampType

                # 找出所有 timestamp 类型的列
                ts_cols = [
                    field.name for field in spark_df.schema.fields
                    if isinstance(field.dataType, (TimestampType,))
                ]

                if ts_cols:
                    safe_print(f"   Timestamp columns found: {ts_cols}")
                    # 将 timestamp 列转换为 string
                    for ts_col in ts_cols:
                        spark_df = spark_df.withColumn(
                            ts_col,
                            col(ts_col).cast("string")
                        )

                    # 转换为 Pandas
                    pdf = spark_df.toPandas()

                    # 将 string 转回 datetime
                    for ts_col in ts_cols:
                        pdf[ts_col] = pd.to_datetime(pdf[ts_col])

                    safe_print("✅ Successfully converted using string intermediary")
                    return pdf
                else:
                    # 没有 timestamp 列，直接抛出原始错误
                    raise e
            except Exception as alt_error:
                safe_print(f"   Alternative method failed: {alt_error}")
                raise e
        else:
            # 不是时区问题，直接抛出
            raise e


# ============================================================================
# 数据加载
# ============================================================================

def load_data(  # noqa: C901
    dataset: Union[pd.DataFrame, Any],
    task: str,
    data_source_table: Optional[str] = None,
    time_col: Optional[str] = None,
    spark=None
) -> pd.DataFrame:
    """
    加载数据并转换为 Pandas DataFrame

    Args:
        dataset: 数据集（表名、Spark DataFrame 或 Pandas DataFrame）
        task: 任务类型
        data_source_table: 数据源表名（用于打印信息）
        time_col: 时间列名（时序预测任务需要）
        spark: Spark session（如果 dataset 是表名）

    Returns:
        Pandas DataFrame
    """
    if isinstance(dataset, str):
        if spark is None:
            raise ValueError("Spark session is required when dataset is a table name")
        pdf = safe_to_pandas(spark.read.table(dataset), spark)
    elif hasattr(dataset, "toPandas"):
        # 尝试获取 SparkSession
        try:
            from pyspark.sql import SparkSession
            spark_session = SparkSession.getActiveSession()
        except Exception:
            spark_session = None
        pdf = safe_to_pandas(dataset, spark_session)
    else:
        pdf = dataset

    print_separator()
    safe_print("📊 Data Loading", show_timestamp=False, show_level=False)
    print_separator()
    if data_source_table:
        safe_print(f"Data source: {data_source_table}")
    safe_print(f"Dataset shape: {pdf.shape} (rows × columns)")
    safe_print(f"Memory usage: {pdf.memory_usage(deep=True).sum() / 1024**2:.2f} MB")

    # 时序预测任务：自动转换时间列为 datetime 类型
    if task == "forecast":
        if time_col and time_col in pdf.columns:
            if not pd.api.types.is_datetime64_any_dtype(pdf[time_col]):
                safe_print(f"Converting time column '{time_col}' to datetime...")
                try:
                    pdf[time_col] = pd.to_datetime(pdf[time_col])
                    safe_print(f"✅ Time column '{time_col}' converted to datetime64")
                except Exception as e:
                    safe_print(f"⚠️  Failed to convert time column: {e}")

    return pdf


# ============================================================================
# 数据划分
# ============================================================================

def prepare_data(  # noqa: C901
    pdf: pd.DataFrame,
    target_col: str,
    features: List[str],
    task: str,
    exclude_cols: Optional[List[str]] = None,
    sample_weight_col: Optional[str] = None,
    data_split_col: Optional[str] = None,
) -> tuple:
    """
    准备数据：确定特征列、数据划分

    Args:
        pdf: 原始数据 DataFrame
        target_col: 目标列名
        features: 已确定的特征列列表（如果为 None，自动确定）
        task: 任务类型
        exclude_cols: 排除的列
        sample_weight_col: 样本权重列
        data_split_col: 数据划分列

    Returns:
        (X_train, y_train, X_val, y_val, X_test, y_test, sample_weight_train, features)
    """
    exclude_cols = exclude_cols or []

    # 确定特征列
    disable_cols = set(exclude_cols) | {target_col}
    if sample_weight_col:
        disable_cols.add(sample_weight_col)
    if data_split_col:
        disable_cols.add(data_split_col)

    if features is None:
        features = [c for c in pdf.columns if c not in disable_cols]

    safe_print(f"Target column: '{target_col}'")
    safe_print(f"Feature columns: {len(features)} columns")
    if len(features) <= 20:
        safe_print(f"  Features: {', '.join(features)}")
    else:
        safe_print(f"  First 10 features: {', '.join(features[:10])}")
        safe_print(f"  ... and {len(features) - 10} more")

    # 数据划分
    safe_print("", show_timestamp=False, show_level=False)
    if data_split_col and data_split_col in pdf.columns:
        # 使用用户提供的划分列
        pdf["_automl_split_col"] = pdf[data_split_col]
        safe_print(f"✅ Using user-provided split column: '{data_split_col}'")
    else:
        # 自动划分
        safe_print("Auto-generating train/val/test split (60%/20%/20%)")
        if task == "classification":
            safe_print("  Using stratified split for classification")
        split_col, sample_weights = compute_split_and_weights(
            y=pdf[target_col].values,
            task=task,
            train_ratio=0.6,
            val_ratio=0.2,
            test_ratio=0.2,
            stratify=True if task == "classification" else False,
            random_state=42,
        )
        pdf["_automl_split_col"] = split_col.values
        pdf["_automl_sample_weight"] = sample_weights.values
        safe_print("✅ Split generated successfully")

    # 分割数据
    train_df = pdf[pdf["_automl_split_col"] == 0]
    val_df = pdf[pdf["_automl_split_col"] == 1]
    test_df = pdf[pdf["_automl_split_col"] == 2]

    X_train = train_df[features]
    y_train = train_df[target_col].values

    X_val = val_df[features]
    y_val = val_df[target_col].values

    X_test = test_df[features]
    y_test = test_df[target_col].values

    # 获取样本权重
    sample_weight_train = None
    if sample_weight_col and sample_weight_col in train_df.columns:
        # 使用用户提供的样本权重列
        sample_weight_train = train_df[sample_weight_col].values
        safe_print(f"✅ Using user-provided sample weights from column: '{sample_weight_col}'")
    elif "_automl_sample_weight" in train_df.columns:
        # 使用自动生成的样本权重（用于类别不平衡）
        sample_weight_train = train_df["_automl_sample_weight"].values

    safe_print("", show_timestamp=False, show_level=False)
    safe_print("Data split summary:")
    safe_print(f"  Train: {len(train_df):,} samples ({len(train_df)/len(pdf)*100:.1f}%)")
    safe_print(f"  Val:   {len(val_df):,} samples ({len(val_df)/len(pdf)*100:.1f}%)")
    safe_print(f"  Test:  {len(test_df):,} samples ({len(test_df)/len(pdf)*100:.1f}%)")
    safe_print(f"  Total: {len(pdf):,} samples")

    # 显示目标变量分布（分类任务）
    if task == "classification":
        safe_print("", show_timestamp=False, show_level=False)
        safe_print("Target distribution in training set:")
        train_dist = pd.Series(y_train).value_counts().sort_index()
        for label, count in train_dist.items():
            safe_print(f"  Class {label}: {count:,} samples ({count/len(y_train)*100:.1f}%)")

    return X_train, y_train, X_val, y_val, X_test, y_test, sample_weight_train, features


# ============================================================================
# 特征存储查找
# ============================================================================

def apply_feature_store_lookups(  # noqa: C901
    pdf: pd.DataFrame,
    feature_store_lookups: List[Dict[str, Any]],
    target_col: str,
    spark=None
) -> tuple:
    """
    使用 wedata-feature-engineering 的 FeatureStoreClient 从特征存储中查找特征并合并到数据集

    Args:
        pdf: 原始数据集
        feature_store_lookups: 特征查找配置列表
        target_col: 目标列名
        spark: Spark session

    Returns:
        (augmented_pdf, fs_client, feature_lookups, training_set) 元组
    """
    fs_client = None
    feature_lookups = None
    training_set = None

    if not feature_store_lookups:
        return pdf, fs_client, feature_lookups, training_set

    if spark is None:
        safe_print("⚠️  Spark session not available, skipping feature store lookups")
        return pdf, fs_client, feature_lookups, training_set

    try:
        # 使用 wedata-feature-engineering 的 FeatureStoreClient
        from wedata.feature_store.client import FeatureStoreClient
        from wedata.feature_store.entities.feature_lookup import FeatureLookup

        fs_client = FeatureStoreClient(spark=spark)

        # 构建 FeatureLookup 列表
        feature_lookups = []
        for lookup in feature_store_lookups:
            table_name = lookup.get("table_name")
            lookup_key = lookup.get("lookup_key")
            feature_names = lookup.get("feature_names")
            timestamp_lookup_key = lookup.get("timestamp_lookup_key")

            if not table_name or not lookup_key:
                safe_print(f"⚠️  Skipping invalid feature store lookup: {lookup}")
                continue

            safe_print(f"Looking up features from: {table_name}")
            safe_print(f"  Lookup key: {lookup_key}")
            if feature_names:
                safe_print(f"  Feature names: {feature_names}")
            if timestamp_lookup_key:
                safe_print(f"  Timestamp key: {timestamp_lookup_key}")

            # 创建 FeatureLookup 对象
            fl = FeatureLookup(
                table_name=table_name,
                lookup_key=lookup_key,
                feature_names=feature_names,
                timestamp_lookup_key=timestamp_lookup_key
            )
            feature_lookups.append(fl)

        if not feature_lookups:
            safe_print("⚠️  No valid feature lookups configured")
            return pdf, fs_client, feature_lookups, training_set

        # 将 pandas DataFrame 转换为 Spark DataFrame
        spark_df = spark.createDataFrame(pdf)
        original_cols = set(pdf.columns)

        # 使用 FeatureStoreClient 创建 training set
        training_set = fs_client.create_training_set(
            df=spark_df,
            feature_lookups=feature_lookups,
            label=target_col,
            exclude_columns=[]
        )

        # 加载合并后的数据并转换回 pandas
        augmented_df = training_set.load_df()
        pdf = augmented_df.toPandas()

        new_cols = set(pdf.columns) - original_cols
        safe_print("✅ Feature store lookup completed")
        safe_print(f"   Added {len(new_cols)} new columns")
        if new_cols:
            extra = f"... (+{len(new_cols) - 5} more)" if len(new_cols) > 5 else ""
            safe_print(f"   New columns: {', '.join(sorted(new_cols)[:5])}" + extra)

    except ImportError as e:
        safe_print(f"⚠️  wedata-feature-engineering not available: {e}")
        safe_print("   Falling back to manual feature lookup...")
        # 回退到手动查找
        pdf = _apply_feature_store_lookups_fallback(pdf, feature_store_lookups, spark)
    except Exception as e:
        safe_print(f"⚠️  Feature store lookup failed: {e}")
        logger.warning(f"Feature store lookup failed: {e}")

    safe_print(f"Dataset shape after feature lookups: {pdf.shape}")
    return pdf, fs_client, feature_lookups, training_set


def _apply_feature_store_lookups_fallback(
    pdf: pd.DataFrame,
    feature_store_lookups: List[Dict[str, Any]],
    spark
) -> pd.DataFrame:
    """
    手动特征查找的回退方法（当 wedata-feature-engineering 不可用时使用）
    """
    for lookup in feature_store_lookups:
        table_name = lookup.get("table_name")
        lookup_key = lookup.get("lookup_key")

        if not table_name or not lookup_key:
            continue

        try:
            feature_df = spark.read.table(table_name).toPandas()

            if isinstance(lookup_key, str):
                lookup_key = [lookup_key]

            missing_in_pdf = [k for k in lookup_key if k not in pdf.columns]
            missing_in_feature = [k for k in lookup_key if k not in feature_df.columns]

            if missing_in_pdf or missing_in_feature:
                continue

            original_cols = set(pdf.columns)
            pdf = pdf.merge(feature_df, on=lookup_key, how="left")
            new_cols = set(pdf.columns) - original_cols

            safe_print(f"✅ Added {len(new_cols)} features from {table_name} (fallback)")

        except Exception as e:
            safe_print(f"⚠️  Failed to lookup features from {table_name}: {e}")

    return pdf
