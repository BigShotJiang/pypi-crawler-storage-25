"""
AutoML 自定义指标模块

提供 FLAML 自定义评估指标（SMAPE、MDAPE、Deviance、Precision）以及
指标验证、默认指标和 FLAML 兼容指标映射功能。
"""
from typing import Callable, List, Optional, Union

import numpy as np

from wedata_automl.utils.print_utils import safe_print


# ============================================================================
# 支持的指标和估计器配置
# ============================================================================

SUPPORTED_METRICS = {
    "forecast": {
        "default": "smape",
        "supported": ["smape", "mse", "rmse", "mae", "mdape"]
    },
    "regression": {
        "default": "deviance",
        "supported": ["deviance", "rmse", "mae", "r2", "mse"]
    },
    "classification": {
        "default": "log_loss",
        "supported": ["f1", "log_loss", "precision", "accuracy", "roc_auc", "rmse", "mae"]
    }
}

SUPPORTED_ESTIMATORS = {
    "forecast": {
        # 默认使用统计模型 + 树模型
        "default": ["prophet", "arima", "sarimax"],
        # FLAML ts_forecast 支持的所有估计器
        "supported": [
            # 统计模型
            "prophet",       # Facebook Prophet
            "arima",         # ARIMA
            "sarimax",       # SARIMAX (带季节性的 ARIMA)
            "holt-winters",  # Holt-Winters 三次指数平滑
            # 树模型
            "lgbm",          # LightGBM
            "xgboost",       # XGBoost
            "xgb_limitdepth",  # XGBoost (限制深度)
            "rf",            # 随机森林
            "extra_tree",    # ExtraTrees
            "histgb",        # HistGradientBoosting
        ],
    },
    "regression": {
        "default": ["lgbm", "xgboost", "rf", "extra_tree"],
        "supported": ["lgbm", "xgboost", "rf", "extra_tree"],
    },
    "classification": {
        "default": ["lgbm", "xgboost", "rf", "extra_tree", "lrl1"],
        "supported": ["lgbm", "xgboost", "rf", "extra_tree", "lrl1"],
    }
}


# ============================================================================
# 指标辅助函数
# ============================================================================

def get_default_metric(task: str) -> str:
    """获取任务的默认指标"""
    if task in SUPPORTED_METRICS:
        return SUPPORTED_METRICS[task]["default"]
    return "accuracy"


def validate_metric(task: str, metric: str) -> str:
    """
    验证指标是否支持，不支持时降级为默认指标

    Args:
        task: 任务类型
        metric: 用户指定的指标

    Returns:
        经过验证的指标名称
    """
    if task not in SUPPORTED_METRICS:
        return metric

    supported = SUPPORTED_METRICS[task]["supported"]
    if metric.lower() not in [m.lower() for m in supported]:
        safe_print(f"⚠️  Metric '{metric}' is not in supported list for {task}: {supported}")
        safe_print(f"   Using default metric: {SUPPORTED_METRICS[task]['default']}")
        return SUPPORTED_METRICS[task]["default"]
    return metric.lower()


def get_flaml_metric(metric: str, task: str) -> Union[str, Callable]:
    """
    获取 FLAML 兼容的指标

    FLAML 内置支持: rmse, mse, mae, mape, r2, accuracy, log_loss, f1, roc_auc
    自定义支持: smape, mdape, deviance, precision

    注意：对于时序预测任务 (ts_forecast)，FLAML 的自定义指标接口与分类/回归不同，
    因此某些自定义指标需要映射到 FLAML 内置指标。

    Args:
        metric: 用户指定的指标名称
        task: 任务类型

    Returns:
        指标字符串或自定义指标函数
    """
    # FLAML 内置支持的指标直接返回
    flaml_builtin_metrics = ["rmse", "mse", "mae", "mape", "r2", "accuracy", "log_loss", "f1", "roc_auc"]
    if metric in flaml_builtin_metrics:
        return metric

    # 对于时序预测任务，某些自定义指标需要映射到 FLAML 内置指标
    # 因为 ts_forecast 的评估接口与分类/回归不同，自定义指标可能无法正常工作
    if task == "forecast":
        forecast_metric_mapping = {
            "smape": "mape",  # SMAPE 映射到 MAPE (FLAML 内置)
            "mdape": "mape",  # MDAPE 映射到 MAPE (FLAML 内置)
        }
        if metric in forecast_metric_mapping:
            mapped_metric = forecast_metric_mapping[metric]
            safe_print(f"ℹ️  For forecast task, metric '{metric}' is mapped to FLAML built-in '{mapped_metric}'")
            return mapped_metric

    # 非时序预测任务的自定义指标
    custom_metrics = {
        "smape": smape_metric,
        "mdape": mdape_metric,
        "deviance": deviance_metric,
        "precision": precision_metric,
    }

    if metric in custom_metrics:
        return custom_metrics[metric]
    else:
        # 未知指标，尝试直接使用
        safe_print(f"⚠️  Metric '{metric}' is not a known metric, using as-is")
        return metric


def get_estimator_list(
    task: str,
    estimator_list: Optional[List[str]],
    exclude_frameworks: Optional[List[str]] = None
) -> List[str]:
    """
    获取估计器列表

    Args:
        task: 任务类型
        estimator_list: 用户指定的估计器列表
        exclude_frameworks: 排除的框架

    Returns:
        处理后的估计器列表
    """
    exclude_frameworks = exclude_frameworks or []

    # 用户可能使用的别名映射到 FLAML 估计器名称
    estimator_alias_map = {
        "sklearn": ["rf", "extra_tree", "lrl1"],
        "lightgbm": ["lgbm"],
        "xgboost": ["xgboost"],
        "deep-ar": [],
        "deepar": [],
    }

    # 如果用户指定了 estimator_list，进行处理
    if estimator_list:
        expanded_estimators = []
        for est in estimator_list:
            est_lower = est.lower()
            if est_lower in estimator_alias_map:
                expanded_estimators.extend(estimator_alias_map[est_lower])
                if not estimator_alias_map[est_lower]:
                    safe_print(f"⚠️  Estimator '{est}' is not currently supported, skipping")
            else:
                expanded_estimators.append(est)

        # 对于 forecast 任务，过滤掉不支持的估计器
        if task == "forecast":
            supported = SUPPORTED_ESTIMATORS["forecast"]["supported"]
            filtered = [e for e in expanded_estimators if e in supported]
            if len(filtered) < len(expanded_estimators):
                unsupported = [e for e in expanded_estimators if e not in supported]
                safe_print(f"⚠️  Filtered out unsupported forecast estimators: {unsupported}")
                safe_print(f"   Supported: {supported}")
            return filtered if filtered else SUPPORTED_ESTIMATORS["forecast"]["default"]
        return expanded_estimators if expanded_estimators else SUPPORTED_ESTIMATORS.get(
            task, {"default": ["lgbm", "xgboost"]}
        )["default"]

    # 否则使用默认列表（排除 exclude_frameworks）
    if task in SUPPORTED_ESTIMATORS:
        all_estimators = SUPPORTED_ESTIMATORS[task]["default"].copy()
    else:
        all_estimators = ["lgbm", "xgboost", "rf", "extra_tree"]

    # 排除指定的框架（向后兼容）
    estimators = [e for e in all_estimators if e not in exclude_frameworks]
    return estimators


# ============================================================================
# 自定义指标函数
# ============================================================================

def smape_metric(X_val, y_val, estimator, labels=None, X_train=None, y_train=None,
                 weight_val=None, weight_train=None, *args, **kwargs):
    """
    SMAPE (Symmetric Mean Absolute Percentage Error) 自定义指标

    SMAPE = (1/n) * Σ(|y_pred - y_true| / ((|y_true| + |y_pred|) / 2)) * 100
    范围: 0% - 200%
    """
    y_pred = estimator.predict(X_val)
    y_true = np.array(y_val)
    y_pred = np.array(y_pred)

    # 避免除零
    denominator = (np.abs(y_true) + np.abs(y_pred)) / 2
    denominator = np.where(denominator == 0, 1e-10, denominator)

    smape = np.mean(np.abs(y_pred - y_true) / denominator) * 100
    return smape, {"smape": smape}


def mdape_metric(X_val, y_val, estimator, labels=None, X_train=None, y_train=None,
                 weight_val=None, weight_train=None, *args, **kwargs):
    """
    MDAPE (Median Absolute Percentage Error) 自定义指标

    MDAPE = median(|y_pred - y_true| / |y_true|) * 100
    """
    y_pred = estimator.predict(X_val)
    y_true = np.array(y_val)
    y_pred = np.array(y_pred)

    # 避免除零
    y_true_safe = np.where(y_true == 0, 1e-10, y_true)

    ape = np.abs(y_pred - y_true) / np.abs(y_true_safe) * 100
    mdape = np.median(ape)
    return mdape, {"mdape": mdape}


def deviance_metric(X_val, y_val, estimator, labels=None, X_train=None, y_train=None,
                    weight_val=None, weight_train=None, *args, **kwargs):
    """
    Deviance (偏差) 自定义指标 - 用于回归任务

    对于高斯分布，Deviance 等于 MSE
    Deviance = (1/n) * Σ(y_pred - y_true)^2

    注意：FLAML 优化时会最小化这个值
    """
    y_pred = estimator.predict(X_val)
    y_true = np.array(y_val)
    y_pred = np.array(y_pred)

    # 计算 MSE (均方误差) 作为 deviance
    deviance = np.mean((y_pred - y_true) ** 2)
    return deviance, {"deviance": deviance}


def precision_metric(X_val, y_val, estimator, labels=None, X_train=None, y_train=None,
                     weight_val=None, weight_train=None, *args, **kwargs):
    """
    Precision (精确率) 自定义指标 - 用于分类任务

    Precision = TP / (TP + FP)

    注意：FLAML 优化时会最小化 loss，所以返回 1 - precision
    """
    from sklearn.metrics import precision_score

    y_pred = estimator.predict(X_val)
    y_true = np.array(y_val)

    # 计算 precision (多分类使用 weighted 平均)
    if len(np.unique(y_true)) > 2:
        precision = precision_score(y_true, y_pred, average='weighted', zero_division=0)
    else:
        precision = precision_score(y_true, y_pred, zero_division=0)

    # 返回 1 - precision 以便 FLAML 最小化
    return 1 - precision, {"precision": precision}
