"""
MLflow 管理模块

负责 MLflow 实验设置、Run 管理、Tag 设置、模型记录/注册和日志上传等功能。
"""
import logging
import os
import traceback
import tempfile
from typing import Any, Dict, List, Optional

import mlflow
import numpy as np
import pandas as pd

from wedata_automl.utils.print_utils import safe_print, print_separator

logger = logging.getLogger(__name__)


# ============================================================================
# MLflow 用户和 Tag 管理
# ============================================================================

def setup_mlflow_user_id() -> str:
    """
    设置 MLflow Run 的 user_id

    从环境变量 QCLOUD_UIN 获取用户 UIN，并设置到 MLFLOW_TRACKING_USERNAME 环境变量。
    MLflow 在创建 Run 时会自动使用此环境变量作为 RunInfo.user_id。

    Returns:
        用户 UIN 字符串
    """
    user_uin = os.environ.get("KERNEL_WEDATA_QCLOUD_SUBUIN", "")
    if user_uin:
        # 设置 MLFLOW_TRACKING_USERNAME，MLflow 会使用它作为 RunInfo.user_id
        os.environ["MLFLOW_TRACKING_USERNAME"] = user_uin
        safe_print(f"✅ Set MLFLOW_TRACKING_USERNAME (user_id): {user_uin}")
    else:
        safe_print("⚠️  QCLOUD_SUBUIN not found, user_id will be empty")
    return user_uin


def _get_wedata_tags(task: str = "classification") -> Dict[str, str]:
    """
    获取 WeData 平台相关的 tags

    Args:
        task: 任务类型 (classification/regression/forecast)

    Returns:
        WeData tags 字典
    """
    workspace_id = os.environ.get("WEDATA_WORKSPACE_ID", "")
    user_uin = os.environ.get("KERNEL_WEDATA_QCLOUD_SUBUIN", "")
    workflow_id = os.environ.get("KERNEL_WEDATA_SUBMIT_FORM_WORKFLOW", "")

    datascience_type = "MACHINE_LEARNING"

    return {
        "wedata.project": workspace_id,
        "wedata.datascience.type": datascience_type,
        "wedata.workflowId": workflow_id,
        "mlflow.user": user_uin,
    }


def set_run_wedata_tags(task: str = "classification") -> None:
    """
    为当前 MLflow Run 设置 WeData 平台相关的 tags

    Args:
        task: 任务类型 (classification/regression/forecast)
    """
    try:
        tags = _get_wedata_tags(task)
        mlflow.set_tags(tags)

        safe_print("✅ Set WeData tags on Run:")
        safe_print(f"   wedata.project: {tags['wedata.project'] or '(empty)'}")
        safe_print(f"   wedata.datascience.type: {tags['wedata.datascience.type']}")
        safe_print(f"   wedata.workflowId: {tags['wedata.workflowId'] or '(empty)'}")
        safe_print(f"   mlflow.user: {tags['mlflow.user'] or '(empty)'}")

    except Exception as e:
        logger.warning(f"Failed to set Run WeData tags: {e}")
        safe_print(f"⚠️  Failed to set WeData tags on Run: {e}")


def set_model_version_wedata_tags(
    registered_model_name: str,
    model_version: str,
    task: str = "classification"
) -> None:
    """
    为注册的模型版本设置 WeData 平台相关的 tags

    Args:
        registered_model_name: 注册模型名称
        model_version: 模型版本号
        task: 任务类型 (classification/regression/forecast)
    """
    try:
        client = mlflow.tracking.MlflowClient()
        tags = _get_wedata_tags(task)

        for tag_key, tag_value in tags.items():
            try:
                client.set_model_version_tag(
                    name=registered_model_name,
                    version=str(model_version),
                    key=tag_key,
                    value=tag_value or ""
                )
            except Exception as e:
                logger.warning(f"Failed to set model version tag {tag_key}: {e}")

        safe_print(f"✅ Set WeData tags on model version: {registered_model_name} v{model_version}")
        safe_print(f"   wedata.project: {tags['wedata.project'] or '(empty)'}")
        safe_print(f"   wedata.datascience.type: {tags['wedata.datascience.type']}")
        safe_print(f"   mlflow.user: {tags['mlflow.user'] or '(empty)'}")

    except Exception as e:
        logger.warning(f"Failed to set model version WeData tags: {e}")
        safe_print(f"⚠️  Failed to set WeData tags on model version: {e}")


# ============================================================================
# MLflow Artifact 日志记录
# ============================================================================

def log_feature_list(features: List[str]):
    """记录特征列表到 MLflow"""
    mlflow.log_dict({"features": features}, "feature_list.json")


def log_best_config_overall(config: Dict[str, Any]):
    """记录最佳配置到 MLflow"""
    mlflow.log_dict(config, "best_config_overall.json")


def log_best_config_per_estimator(config: Dict[str, Any]):
    """记录每个估计器的最佳配置到 MLflow"""
    mlflow.log_dict(config, "best_config_per_estimator.json")


def log_engine_meta(meta: Dict[str, Any]):
    """记录引擎元数据到 MLflow"""
    mlflow.log_dict(meta, "engine_meta.json")


def write_failure_file(
    error: Exception,
    run_id: Optional[str] = None,
    experiment_name: Optional[str] = None,
    task: Optional[str] = None,
    fail_dir: Optional[str] = None,
) -> str:
    """
    在训练失败时写入 fail 文件

    Args:
        error: 异常对象
        run_id: MLflow Run ID（可选）
        experiment_name: 实验名称（可选）
        task: 任务类型（可选）
        fail_dir: fail 文件目录（可选，默认使用临时目录）

    Returns:
        生成的 fail 文件路径
    """
    import json
    from datetime import datetime

    # 确定 fail 目录
    if fail_dir is None:
        fail_dir = os.path.join(tempfile.gettempdir(), "wedata_automl", "fail")

    # 确保目录存在
    os.makedirs(fail_dir, exist_ok=True)

    # 生成文件名
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_id_part = run_id[:8] if run_id else "unknown"
    filename = f"fail_{run_id_part}_{timestamp}.json"
    filepath = os.path.join(fail_dir, filename)

    # 构建失败信息
    fail_info = {
        "error_type": type(error).__name__,
        "error_message": str(error),
        "traceback": traceback.format_exc(),
        "run_id": run_id,
        "experiment_name": experiment_name,
        "task": task,
        "timestamp": datetime.now().isoformat(),
    }

    # 写入文件
    try:
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(fail_info, f, indent=2, ensure_ascii=False)
        safe_print(f"❌ Failure recorded: {filepath}")
    except Exception as write_error:
        safe_print(f"⚠️  Failed to write failure file: {write_error}")
        # 尝试写入简化版本
        try:
            simple_info = {
                "error_type": type(error).__name__,
                "error_message": str(error)[:1000],
                "timestamp": datetime.now().isoformat(),
            }
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(simple_info, f, indent=2)
        except Exception:
            pass

    return filepath


# ============================================================================
# MLflow 实验设置
# ============================================================================

def setup_mlflow_experiment(  # noqa: C901
    experiment_name: str,
    experiment_id: Optional[str] = None,
    workspace_id: Optional[str] = None
) -> tuple:
    """
    设置 MLflow 实验

    Args:
        experiment_name: 实验名称
        experiment_id: 实验 ID（可选，优先使用）
        workspace_id: 项目 ID

    Returns:
        (experiment, experiment_name, experiment_id) 元组
    """
    safe_print("", show_timestamp=False, show_level=False)
    print_separator()
    safe_print("📝 MLflow Experiment Setup")
    print_separator()

    tracking_uri = mlflow.get_tracking_uri()
    safe_print(f"MLflow Tracking URI: {tracking_uri}")

    if tracking_uri.startswith('file://') and workspace_id:
        warning_msg = (
            f"⚠️  WARNING: Using local file system MLflow tracking ('{tracking_uri}')\n"
            "   Local MLflow does not support project ID validation.\n"
            "   For production use, please set MLflow tracking URI to a remote server:\n"
            "   Example: mlflow.set_tracking_uri('http://your-mlflow-server:5000')"
        )
        safe_print(warning_msg)
        logger.warning(warning_msg)

    if experiment_id:
        experiment = mlflow.get_experiment(experiment_id)
        if experiment is None:
            error_msg = (
                f"❌ Experiment with ID '{experiment_id}' not found.\n"
                "Please verify:\n"
                "  - The experiment ID is correct\n"
                "  - The experiment exists in the MLflow tracking server\n"
                f"  - MLflow tracking URI: {mlflow.get_tracking_uri()}"
            )
            logger.error(error_msg)
            raise ValueError(error_msg)
        experiment_name = experiment.name
        safe_print(f"Using experiment by ID: {experiment_id}")
        safe_print(f"Experiment name: '{experiment_name}'")
    else:
        pass  # use provided experiment_name

    try:
        mlflow.set_experiment(experiment_name)
    except Exception as e:
        error_msg = (
            f"❌ Failed to set experiment '{experiment_name}'. Error: {traceback.format_exc()}\n\n"
            "This may be due to:\n"
            "  1. MLflow backend permission issues\n"
            f"  2. Project ID '{workspace_id}' not found or invalid\n"
            "  3. MLflow tracking server connection issues\n"
            "  4. Backend API restrictions (e.g., project validation)\n\n"
            "Configuration:\n"
            f"  - MLflow tracking URI: {mlflow.get_tracking_uri()}\n"
            f"  - Project ID: {workspace_id}\n"
            f"  - Experiment name: {experiment_name}\n\n"
            "Please verify:\n"
            f"  - The project ID '{workspace_id}' exists in the backend\n"
            "  - You have permission to create experiments in this project\n"
            "  - The MLflow tracking server is accessible"
        )
        logger.error(error_msg)
        raise ValueError(error_msg) from e

    experiment = mlflow.get_experiment_by_name(experiment_name)

    if experiment is None:
        error_msg = (
            f"❌ Failed to create or get experiment '{experiment_name}'. "
            "This may be due to:\n"
            "  1. MLflow backend permission issues\n"
            f"  2. Project ID '{workspace_id}' validation failed\n"
            "  3. MLflow tracking server connection issues\n"
            "  4. Backend API restrictions\n\n"
            "Please check:\n"
            f"  - MLflow tracking URI: {mlflow.get_tracking_uri()}\n"
            f"  - Project ID: {workspace_id}\n"
            "  - Backend server logs for more details"
        )
        logger.error(error_msg)
        raise ValueError(error_msg)

    exp_id = experiment.experiment_id

    if experiment.creation_time == experiment.last_update_time:
        safe_print(f"✅ Created new experiment: '{experiment_name}' (ID: {exp_id})")
    else:
        safe_print(f"✅ Using existing experiment: '{experiment_name}' (ID: {exp_id})")

    if workspace_id:
        try:
            mlflow.set_experiment_tag("wedata.project", workspace_id)
            safe_print(f"✅ Set project ID tag: 'wedata.project' = '{workspace_id}'")
        except Exception as e:
            safe_print(f"⚠️  Failed to set project ID tag: {e}")
            logger.warning(f"Failed to set project ID tag: {e}")

    return experiment, experiment_name, exp_id


# ============================================================================
# 日志文件上传
# ============================================================================

def upload_log_file(log_file_path: str, auto_cleanup: bool = True):  # noqa: C901
    """
    上传 FLAML 日志文件到 MLflow

    Args:
        log_file_path: 日志文件路径
        auto_cleanup: 是否自动清理本地文件
    """
    safe_print("", show_timestamp=False, show_level=False)
    safe_print("📤 Uploading FLAML log file to MLflow...")
    try:
        if os.path.exists(log_file_path):
            mlflow.log_artifact(log_file_path, artifact_path="flaml_logs")
            safe_print(f"✅ Log file uploaded: {os.path.basename(log_file_path)}")

            if auto_cleanup:
                try:
                    os.remove(log_file_path)
                    safe_print(f"✅ Local log file cleaned up: {log_file_path}")
                except Exception as e:
                    safe_print(f"⚠️  Failed to cleanup local log file: {e}")
        else:
            safe_print(f"⚠️  Log file not found: {log_file_path}")
    except Exception as e:
        safe_print(f"⚠️  Failed to upload log file: {e}")
        if auto_cleanup:
            try:
                if os.path.exists(log_file_path):
                    os.remove(log_file_path)
            except Exception:
                pass


# ============================================================================
# 模型记录和注册
# ============================================================================

def log_model_with_mlflow(
    pipeline,
    task: str,
    parent_run_id: str,
    name_suffix: str = "",
    registered_model_name: Optional[str] = None,
    X_sample: Optional[pd.DataFrame] = None,
    y_sample: Optional[np.ndarray] = None
) -> tuple:
    """
    使用标准 MLflow 方式记录和注册模型（分类/回归任务）

    Args:
        pipeline: sklearn Pipeline
        task: 任务类型
        parent_run_id: 父 run 的 ID
        name_suffix: 模型名称后缀
        registered_model_name: 注册模型的名称（可选）
        X_sample: 用于推断签名的输入样本（可选）
        y_sample: 用于推断签名的输出样本（可选）

    Returns:
        (model_uri, model_version) 元组
    """
    from mlflow.models import infer_signature

    # 推断模型签名（分类/回归任务）
    signature = None
    input_example = None
    if X_sample is not None:
        try:
            y_pred = pipeline.predict(X_sample)
            signature = infer_signature(X_sample, y_pred)
            input_example = X_sample.head(5) if len(X_sample) > 5 else X_sample
            safe_print("✅ Model signature inferred successfully")
        except Exception as e:
            safe_print(f"⚠️  Failed to infer model signature: {e}")
            signature = None

    # 记录模型到 MLflow
    mlflow.sklearn.log_model(
        sk_model=pipeline,
        artifact_path=f"model{name_suffix}",
        signature=signature,
        input_example=input_example,
    )
    model_uri = f"runs:/{parent_run_id}/model{name_suffix}"
    safe_print(f"✅ Model logged to MLflow: {model_uri}")

    model_version = None
    safe_print("ℹ️  Model not registered in parent run (artifact only)")
    mlflow.set_tag("wedata.has_registered_model", "false")

    return model_uri, model_version


# ============================================================================
# TrialLogger（遗留代码，保留向后兼容）
# ============================================================================

class TrialLogger:
    """
    FLAML Trial 日志记录器

    用于记录每个 trial 的详细信息到 MLflow

    Note:
        此类已被 TrialHook 替代，保留用于向后兼容。
    """

    def __init__(self, parent_run_id: str, features: List[str], task: str, metric: str):
        self.parent_run_id = parent_run_id
        self.features = features
        self.task = task
        self.metric = metric
        self.trial_count = 0
        self.trial_runs = []

    def log_trial(self, config: Dict[str, Any], estimator: str, val_loss: float, train_time: float):
        """记录单个 trial 到 MLflow"""
        self.trial_count += 1

        try:
            with mlflow.start_run(run_name=f"trial_{self.trial_count}_{estimator}", nested=True) as trial_run:
                trial_run_id = trial_run.info.run_id

                try:
                    mlflow.delete_tag("mlflow.source.name")
                except Exception:
                    pass

                mlflow.log_param("estimator", estimator)
                mlflow.log_param("trial_number", self.trial_count)
                mlflow.log_param("parent_run_id", self.parent_run_id)
                mlflow.log_param("primaryMetric", self.metric)

                for key, value in config.items():
                    try:
                        mlflow.log_param(f"hp_{key}", value)
                    except Exception as e:
                        safe_print(f"⚠️  DEBUG: Failed to log param hp_{key}={value}: {e}")
                        mlflow.log_param(f"hp_{key}", str(value))

                mlflow.log_metric("val_loss", val_loss)
                mlflow.log_metric("train_time", train_time)

                metric_value = self._convert_val_loss_to_metric(val_loss)
                mlflow.log_metric(self.metric, metric_value)

                log_feature_list(self.features)

                mlflow.set_tag("wedata.has_registered_model", "false")

                trial_info = {
                    "run_id": trial_run_id,
                    "trial_number": self.trial_count,
                    "estimator": estimator,
                    "val_loss": val_loss,
                    "train_time": train_time,
                    "config": config,
                }
                self.trial_runs.append(trial_info)

                safe_print(
                    f"  Trial {self.trial_count:3d} | {estimator:15s} "
                    f"| val_loss={val_loss:.6f} | time={train_time:.2f}s"
                )
        except Exception as e:
            safe_print(f"❌ DEBUG: Exception in log_trial for trial {self.trial_count}: {e}")
            import traceback as tb
            safe_print(f"   Traceback: {tb.format_exc()}")
            raise

    def _convert_val_loss_to_metric(self, val_loss: float) -> float:
        """将 FLAML 的 val_loss 转换为用户指定的 metric 值"""
        maximize_metrics = [
            "accuracy", "f1", "macro_f1", "micro_f1", "weighted_f1",
            "roc_auc", "roc_auc_ovr", "roc_auc_ovo", "roc_auc_weighted",
            "precision", "recall", "ap",
            "r2",
        ]

        if self.metric in maximize_metrics:
            return 1.0 - val_loss
        else:
            return val_loss

    def get_best_trial(self) -> Optional[Dict[str, Any]]:
        """获取最佳 trial"""
        if not self.trial_runs:
            return None
        best_trial = min(self.trial_runs, key=lambda x: x["val_loss"])
        return best_trial
