"""CASE internal library."""
