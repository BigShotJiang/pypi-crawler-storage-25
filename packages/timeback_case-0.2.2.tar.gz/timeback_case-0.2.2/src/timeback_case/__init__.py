"""
Timeback CASE Client

A Python client for CASE (Competency and Academic Standards Exchange) v1.1 operations.
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("timeback-case")
except PackageNotFoundError:
    __version__ = "0.0.0"

from .client import CaseClient
from .exceptions import (
    APIError,
    AuthenticationError,
    CaseError,
    ForbiddenError,
    InputValidationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimebackError,
    ValidationError,
    ValidationIssue,
    create_input_validation_error,
)
from .types import (
    CFAssociation,
    CFAssociationInput,
    CFDefinitions,
    CFDocument,
    CFDocumentInput,
    CFItem,
    CFItemInput,
    CFItemWithChildGroups,
    CFPackage,
    CFPackageInput,
    CFPackageUploadResult,
    CFPackageUploadResultStats,
    CFPackageWithGroups,
    InputNodeURI,
    LinkURI,
    OptionalLinkURI,
)

__all__ = [
    "APIError",
    "AuthenticationError",
    "CFAssociation",
    "CFAssociationInput",
    "CFDefinitions",
    "CFDocument",
    "CFDocumentInput",
    "CFItem",
    "CFItemInput",
    "CFItemWithChildGroups",
    "CFPackage",
    "CFPackageInput",
    "CFPackageUploadResult",
    "CFPackageUploadResultStats",
    "CFPackageWithGroups",
    "CaseClient",
    "CaseError",
    "ForbiddenError",
    "InputNodeURI",
    "InputValidationError",
    "LinkURI",
    "NotFoundError",
    "OptionalLinkURI",
    "RateLimitError",
    "ServerError",
    "TimebackError",
    "ValidationError",
    "ValidationIssue",
    "__version__",
    "create_input_validation_error",
]
