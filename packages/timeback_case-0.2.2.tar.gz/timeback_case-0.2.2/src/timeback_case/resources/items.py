"""
CFItems Resource

CASE Framework Items — individual competencies, standards, and learning objectives.
"""

from __future__ import annotations

from typing import TYPE_CHECKING
from urllib.parse import quote

from timeback_common import validate_non_empty_string

from ..types.responses import CFItem

if TYPE_CHECKING:
    from ..lib.transport import Transport


class ItemsResource:
    """CASE Framework Items resource."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    @property
    def _base_path(self) -> str:
        return f"{self._transport.paths.base}/CFItems"

    async def list(self, params: dict[str, str | int] | None = None) -> dict[str, list[CFItem]]:
        """
        List all CASE items.

        Args:
            params: Optional query parameters (offset, limit, filter, sort, orderBy)

        Returns:
            Dict with CFItems key containing list of items
        """
        result = await self._transport.get(self._base_path, params=params)
        items = [CFItem.model_validate(i) for i in result.get("CFItems", [])]
        return {"CFItems": items}

    async def get(self, sourced_id: str) -> dict[str, CFItem]:
        """
        Get a CASE item by sourcedId.

        Args:
            sourced_id: The item's sourcedId

        Returns:
            Dict with CFItem key containing the item
        """
        validate_non_empty_string(sourced_id, "sourcedId")
        result = await self._transport.get(f"{self._base_path}/{quote(sourced_id, safe='')}")
        return {"CFItem": CFItem.model_validate(result.get("CFItem", result))}
