"""Fixture-driven tests for CASE packages resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_case.lib.testing import create_recording_transport
from timeback_case.resources.packages import PackagesResource

FIXTURES_DIR = fixtures_dir("case", "packages")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": PackagesResource(transport), "calls": transport.calls}


test_case_packages_fixtures = make_resource_fixture_test(
    name="case > packages",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
