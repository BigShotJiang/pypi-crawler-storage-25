"""Tests for CaseClient initialization and configuration."""

import os
from unittest.mock import patch

import pytest

from timeback_case import CaseClient


class TestCaseClientInit:
    """Tests for client initialization."""

    def test_staging_environment(self):
        """Staging environment should use staging URL."""
        client = CaseClient(env="staging", client_id="id", client_secret="secret")
        assert client._transport.base_url is not None

    def test_production_environment(self):
        """Production environment should use production URL."""
        client = CaseClient(env="production", client_id="id", client_secret="secret")
        assert "dev" not in client._transport.base_url
        assert "staging" not in client._transport.base_url

    def test_custom_base_url(self):
        """Custom base URL should override environment."""
        client = CaseClient(
            base_url="https://custom.example.com",
            auth_url="https://auth.example.com/oauth2/token",
            client_id="id",
            client_secret="secret",
        )
        assert client._transport.base_url == "https://custom.example.com"

    def test_explicit_credentials(self):
        """Explicit credentials should work."""
        client = CaseClient(
            env="staging",
            client_id="my-id",
            client_secret="my-secret",
        )
        assert client._provider is not None
        tm = client._provider.get_token_manager("case")
        assert tm is not None
        assert tm._config.client_id == "my-id"
        assert tm._config.client_secret == "my-secret"

    def test_missing_credentials_raises(self):
        """Missing credentials should raise ValueError."""
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("CASE_CLIENT_ID", None)
            os.environ.pop("CASE_CLIENT_SECRET", None)
            os.environ.pop("TIMEBACK_API_CLIENT_ID", None)
            os.environ.pop("TIMEBACK_API_CLIENT_SECRET", None)
            os.environ.pop("TIMEBACK_CLIENT_ID", None)
            os.environ.pop("TIMEBACK_CLIENT_SECRET", None)
            with pytest.raises(ValueError, match="Missing required environment variable"):
                CaseClient(env="staging")

    def test_default_platform_is_beyond_ai(self):
        """Default platform should be BEYOND_AI."""
        client = CaseClient(env="staging", client_id="id", client_secret="secret")
        assert client._transport.base_url is not None

    def test_beyond_ai_platform(self):
        """BEYOND_AI platform should succeed."""
        client = CaseClient(
            platform="BEYOND_AI",
            env="staging",
            client_id="id",
            client_secret="secret",
        )
        assert client._transport.base_url is not None

    def test_custom_provider(self):
        """Custom base URL and auth should work."""
        client = CaseClient(
            base_url="https://custom.api.com",
            auth_url="https://custom.auth.com/token",
            client_id="test-id",
            client_secret="test-secret",
        )
        assert client._transport.base_url == "https://custom.api.com"


class TestCaseClientTransport:
    """Tests for transport access."""

    def test_get_transport(self):
        """Client should expose transport via get_transport()."""
        client = CaseClient(env="staging", client_id="id", client_secret="secret")

        transport = client.get_transport()
        assert transport is not None
        assert transport.base_url is not None

    def test_transport_has_case_paths(self):
        """Transport should have CASE-specific paths."""
        client = CaseClient(env="staging", client_id="id", client_secret="secret")

        transport = client.get_transport()
        assert hasattr(transport, "paths")
        assert "/ims/case/v1p1" in transport.paths.base


class TestCaseClientCheckAuth:
    """Tests for check_auth."""

    @pytest.mark.asyncio
    async def test_check_auth_raises_without_provider(self):
        """check_auth should raise when no provider is set (custom transport)."""
        from timeback_common import CasePaths

        class MockTransport:
            base_url = "https://mock.api.com"
            paths = CasePaths()

            async def close(self) -> None:
                pass

        client = CaseClient(transport=MockTransport())

        with pytest.raises(RuntimeError, match="Cannot check auth"):
            await client.check_auth()

    def test_custom_transport_without_paths_raises(self):
        """Custom transport without paths should raise TypeError."""

        class BadTransport:
            base_url = "https://mock.api.com"

            async def close(self) -> None:
                pass

        with pytest.raises(TypeError, match="paths"):
            CaseClient(transport=BadTransport())


class TestCaseClientPlatformSupport:
    """Tests for platform-specific behavior."""

    def test_learnwith_ai_platform_succeeds(self):
        """LearnWith.AI platform should succeed (CASE is supported on LearnWith.AI)."""
        client = CaseClient(
            platform="LEARNWITH_AI",
            env="staging",
            client_id="id",
            client_secret="secret",
        )
        assert client._transport.base_url is not None

    def test_learnwith_ai_path_profile_succeeds(self):
        """Custom provider with LearnWith.AI pathProfile should succeed (CASE paths are set)."""
        from timeback_common import TimebackProvider

        provider = TimebackProvider(
            base_url="https://custom.api.com",
            auth_url="https://custom.auth.com/token",
            client_id="id",
            client_secret="secret",
            path_profile="LEARNWITH_AI",
        )
        client = CaseClient(provider=provider)
        assert client._transport.base_url == "https://custom.api.com"

    def test_learnwith_ai_path_profile_with_custom_case_paths_succeeds(self):
        """LearnWith.AI pathProfile with custom CASE paths should succeed."""
        from timeback_common import CasePaths, TimebackProvider

        provider = TimebackProvider(
            base_url="https://custom.api.com",
            auth_url="https://custom.auth.com/token",
            client_id="id",
            client_secret="secret",
            path_profile="LEARNWITH_AI",
            paths={"case": CasePaths()},
        )
        client = CaseClient(provider=provider)
        assert client._transport.base_url == "https://custom.api.com"


class TestCaseClientContextManager:
    """Tests for context manager support."""

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Client should work as async context manager."""
        async with CaseClient(env="staging", client_id="id", client_secret="secret") as client:
            assert client._provider is not None
