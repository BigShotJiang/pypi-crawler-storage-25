#    Copyright 2025 Genesis Corporation.
#
#    All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import typing as tp

from exordos_core.compute.dm import models
from exordos_core.compute.scheduler.driver import base


class RelativeCoreRamWeighter(base.MachinePoolAbstractWeighter):
    ALMOST_OVERUSED_THRESHOLD = 0.8

    def _usage_ratio(self, pool: models.MachinePool) -> float:
        """Some empirical formula to calculate the usage ratio of the pool."""

        # The pool is overused
        if pool.avail_cores < 0 or pool.avail_ram < 0:
            return 1.0

        # Unable to calculate ratio. Consider the pool overused
        if pool.all_cores == 0 or pool.all_ram == 0:
            return 1.0

        ratios = (
            (pool.all_cores - pool.avail_cores) / pool.all_cores,
            (pool.all_ram - pool.avail_ram) / pool.all_ram,
        )

        # The pool is almost overused
        if any(r > self.ALMOST_OVERUSED_THRESHOLD for r in ratios):
            return max(ratios)

        # Otherwise, all elements have equal weight
        return sum(ratios) / len(ratios)

    def weight(
        self,
        pools: tp.List[base.MachinePoolBundle],
    ) -> tp.Iterable[float]:
        """Assign weights to machine pools.

        Every machine pool gets a weight from range [0, 1].
        1 means the pool is the best for the node.
        0 means the pool is the worst for the node.
        """

        # Maximum weight gets a pool with relative maximal cores and ram
        usages = tuple(self._usage_ratio(p.pool) for p in pools)

        # The system is empty, all pools have equal weight
        if sum(usages) == 0:
            return (1 / len(pools) for _ in pools)

        return (1.0 - u / sum(usages) for u in usages)


class SimpleMachineWeighter(base.MachineAbstractWeighter):
    def _ratio(self, machine: models.Machine) -> int:
        """Some empirical formula to calculate the ratio of the machine."""
        # 1 cpu == 8192 Mb ram
        return machine.cores * 8192 + machine.ram

    def weight(
        self,
        machines: tp.List[base.MachineBundle],
    ) -> tp.Iterable[float]:
        """Assign weights to machines.

        Every machine gets a weight from range [0, 1].
        1 means the machine is the best for the node.
        0 means the machine is the worst for the node.
        """
        if not machines:
            return tuple()

        ratios = tuple(self._ratio(m.machine) for m in machines)

        # Normalize ratios
        sum_ratios = sum(ratios)
        return (1.0 - r / sum_ratios for r in ratios)
