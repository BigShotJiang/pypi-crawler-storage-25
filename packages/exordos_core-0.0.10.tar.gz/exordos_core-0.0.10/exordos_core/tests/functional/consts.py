# vim: tabstop=4 shiftwidth=4 softtabstop=4
#
# Copyright 2016 Eugene Frolov <eugene@frolov.net.ru>
#
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import os

_DATABASE_URI_DEFAULT = (
    "postgresql://exordos_core:exordos_core@127.0.0.1:5432/exordos_core"
)

DATABASE_URI = os.getenv("DATABASE_URI", _DATABASE_URI_DEFAULT)


def get_database_uri():
    return os.getenv("DATABASE_URI", _DATABASE_URI_DEFAULT)
