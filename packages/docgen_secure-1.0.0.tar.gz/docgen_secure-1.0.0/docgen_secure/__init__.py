"""DocGen Secure - Hybrid Security & Quality Analyzer"""
__version__ = "1.0.0"
