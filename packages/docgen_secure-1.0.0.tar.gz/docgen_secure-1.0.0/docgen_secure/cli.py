#!/usr/bin/env python3
"""
🛡️ DocGen Secure v3.0 - 10/10
Hybrid: Regex + AST + AI | GitHub | Detailed Results
"""
import sys, os, ast, re, json, random, time, ssl, logging, subprocess, tempfile, shutil
from pathlib import Path
from collections import defaultdict
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

SSL_CONTEXT = ssl.create_default_context()

# ============================================================
# RULES
# ============================================================
SECURITY_RULES = [
    ('hardcoded_password', '🔴 Hardcoded Password', r'(?i)password\s*[:=]\s*["\'][^"\']+["\']', 'Move to .env'),
    ('api_key_exposed', '🔴 API Key Exposed', r'(?:sk-|AIza|ghp_|xai-|gsk_|hf_)[a-zA-Z0-9]{20,}', 'Move to .env'),
    ('dangerous_eval', '🔴 Dangerous eval()', r'\beval\s*\(', 'Avoid eval()'),
    ('dangerous_exec', '🔴 Dangerous exec()', r'\bexec\s*\(', 'Avoid exec()'),
    ('dangerous_os_system', '🔴 Dangerous os.system()', r'\bos\.system\s*\(', 'Use subprocess.run()'),
    ('sql_injection_fstring', '🔴 SQL Injection (f-string)', r'execute\s*\(\s*f["\']', 'Parameterized queries'),
    ('sql_injection_format', '🔴 SQL Injection (.format)', r'execute\s*\(\s*["\'].*\.format\(', 'Parameterized queries'),
    ('sql_injection_percent', '🔴 SQL Injection (%)', r'execute\s*\(\s*["\'].*%[srd]', 'Parameterized queries'),
    ('sql_injection_concat', '🔴 SQL Injection (+)', r'execute\s*\(\s*["\'].*\+', 'Parameterized queries'),
    ('debug_mode', '🟡 Debug Mode ON', r'DEBUG\s*=\s*True', 'Set False in production'),
    ('weak_crypto_md5', '🟡 Weak Crypto (MD5)', r'\bhashlib\.md5\s*\(', 'Use SHA-256'),
    ('weak_crypto_sha1', '🟡 Weak Crypto (SHA1)', r'\bhashlib\.sha1\s*\(', 'Use SHA-256'),
    ('insecure_deserialization', '🔴 Insecure Pickle', r'\bpickle\.loads?\s*\(', 'Use JSON instead'),
    ('xxe_vulnerability', '🔴 XXE (XML)', r'xml\.etree\.ElementTree.*parse', 'Use defusedxml'),
    ('open_redirect', '🟡 Open Redirect', r'redirect\s*\(\s*request\.', 'Validate URLs'),
]

QUALITY_RULES = [
    ('missing_type_hints', '🟡 Missing Type Hints', None, 'Add type hints'),
    ('missing_docstring', '🟡 Missing Docstring', None, 'Add docstring'),
    ('function_too_long', '🟡 Function Too Long (>50 lines)', None, 'Split into smaller functions'),
    ('deep_nesting', '🟡 Deep Nesting (>3 levels)', None, 'Use early return pattern'),
    ('too_many_args', '🟡 Too Many Arguments (>5)', None, 'Use dataclass or dict'),
    ('bare_except', '🟡 Bare except:', None, 'Specify exception type'),
]

# ============================================================
# KEY MANAGER (Silent)
# ============================================================
def get_keys(prefix):
    keys = []
    for i in range(1, 100):
        k = os.getenv(f'{prefix}_{i}')
        if k: keys.append(k)
        else: break
    single = os.getenv(prefix)
    if single: keys.append(single)
    return keys

class KeyManager:
    def __init__(self):
        self.keys = {}
        self.index = {}
        self.last_used = {}
        for prefix in ['OR_KEY', 'GEMINI_KEY']:
            k = get_keys(prefix)
            if k:
                self.keys[prefix] = k
                self.index[prefix] = 0
                self.last_used[prefix] = 0
    
    def get_key(self, prefix):
        if prefix not in self.keys: return None
        keys = self.keys[prefix]
        elapsed = time.time() - self.last_used.get(prefix, 0)
        if elapsed < 0.3: time.sleep(0.3 - elapsed)
        idx = self.index[prefix] % len(keys)
        self.index[prefix] += 1
        self.last_used[prefix] = time.time()
        return keys[idx]

class AICaller:
    def __init__(self, key_manager):
        self.km = key_manager
        self.calls = 0
    
    def ask(self, prompt, max_tokens=400):
        # OpenRouter
        key = self.km.get_key('OR_KEY')
        if key:
            result = self._call_openrouter(key, prompt, max_tokens)
            if result: self.calls += 1; return result
        # Gemini
        key = self.km.get_key('GEMINI_KEY')
        if key:
            result = self._call_gemini(key, prompt, max_tokens)
            if result: self.calls += 1; return result
        return None
    
    def _call_openrouter(self, key, prompt, max_tokens):
        try:
            data = json.dumps({'model':'google/gemini-2.0-flash-001','messages':[{'role':'user','content':prompt}],'max_tokens':max_tokens,'temperature':0.1}).encode()
            req = Request('https://openrouter.ai/api/v1/chat/completions', data=data,
                headers={'Authorization':f'Bearer {key}','Content-Type':'application/json'})
            with urlopen(req, timeout=15, context=SSL_CONTEXT) as r:
                return json.loads(r.read())['choices'][0]['message']['content']
        except: return None
    
    def _call_gemini(self, key, prompt, max_tokens):
        try:
            data = json.dumps({'contents':[{'parts':[{'text':prompt}]}],'generationConfig':{'maxOutputTokens':max_tokens,'temperature':0.1}}).encode()
            req = Request(f'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={key}',
                data=data, headers={'Content-Type':'application/json'})
            with urlopen(req, timeout=15, context=SSL_CONTEXT) as r:
                return json.loads(r.read())['candidates'][0]['content']['parts'][0]['text']
        except: return None

# ============================================================
# ANALYZER
# ============================================================
class Analyzer:
    def __init__(self, lang='en', ai_caller=None, silent=False):
        self.silent = silent
        self.lang = lang
        self.ai = ai_caller
        self.issues = []
        self.files_analyzed = 0
        self.ai_scanned = 0
    
    def analyze_file(self, filepath, rel_path=''):
        path = Path(filepath)
        self.files_analyzed += 1
        display_name = rel_path or path.name
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                content = ''.join(lines)
        except: return
        
        # REGEX
        for i, line in enumerate(lines, 1):
            line_s = line.strip()
            if line_s.startswith('#') or line_s.startswith('"""'): continue
            for rule_id, title, pattern, fix in SECURITY_RULES:
                if pattern and re.search(pattern, line, re.IGNORECASE):
                    if rule_id == 'hardcoded_password' and ('your_' in line.lower() or 'example' in line.lower()): continue
                    if rule_id == 'api_key_exposed' and ('os.environ' in line): continue
                    if rule_id == 'debug_mode' and 'False' in line: continue
                    self.issues.append({'file':display_name,'line':i,'title':title,'fix':fix,'type':'security','severity':'high' if '🔴' in title else 'medium'})
                    break
        
        # AST
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef) and not node.name.startswith('_'):
                    # Type hints
                    if not all(a.annotation for a in node.args.args if a.arg != 'self') or not node.returns:
                        self.issues.append({'file':display_name,'line':node.lineno,'title':'🟡 Missing Type Hints','fix':f'Add types to {node.name}()','type':'quality','severity':'medium'})
                    # Docstring
                    if not ast.get_docstring(node):
                        self.issues.append({'file':display_name,'line':node.lineno,'title':'🟡 Missing Docstring','fix':f'Add docstring to {node.name}()','type':'quality','severity':'low'})
                    # Long function
                    if len(node.body) > 50:
                        self.issues.append({'file':display_name,'line':node.lineno,'title':f'🟡 Function Too Long ({len(node.body)} lines)','fix':f'Split {node.name}()','type':'quality','severity':'medium'})
                    # Args count
                    num_args = len([a for a in node.args.args if a.arg != 'self'])
                    if num_args > 5:
                        self.issues.append({'file':display_name,'line':node.lineno,'title':f'🟡 Too Many Args ({num_args})','fix':f'Use dataclass for {node.name}()','type':'quality','severity':'low'})
                    # Nesting
                    depth = self._max_nesting(node)
                    if depth > 3:
                        self.issues.append({'file':display_name,'line':node.lineno,'title':f'🟡 Deep Nesting ({depth} levels)','fix':'Use early return','type':'quality','severity':'medium'})
                elif isinstance(node, ast.ExceptHandler) and node.type is None:
                    self.issues.append({'file':display_name,'line':node.lineno,'title':'🟡 Bare except:','fix':'Specify exception','type':'quality','severity':'medium'})
        except SyntaxError: pass
        
        # AI Deep Scan
        if self.ai and len(content) < 8000:
            prompt = f"""Analyze this code for bugs and security. Return JSON array [{{"title":"...","fix":"...","severity":"high/medium/low"}}]. CODE:\n{content[:4000]}"""
            result = self.ai.ask(prompt, max_tokens=400)
            if result:
                self.ai_scanned += 1
                try:
                    match = re.search(r'\[.*\]', result, re.DOTALL)
                    if match:
                        for item in json.loads(match.group()):
                            if isinstance(item, dict):
                                self.issues.append({'file':display_name,'line':0,'title':f"🤖 {item.get('title','')}",'fix':item.get('fix',''),'type':'ai','severity':item.get('severity','medium')})
                except: pass
    
    def _max_nesting(self, node, depth=0):
        if not hasattr(node, 'body'): return depth
        max_d = depth
        for child in node.body:
            d = depth+1 if isinstance(child, (ast.If,ast.For,ast.While,ast.Try,ast.With)) else depth
            max_d = max(max_d, self._max_nesting(child, d))
        return max_d
    
    def _build_json(self):
        sev = defaultdict(int)
        for i in self.issues: sev[i.get('severity','medium')] += 1
        total = len(self.issues)
        score = max(0, min(10, 10 - sev['high']*0.8 - sev['medium']*0.2 - sev['low']*0.05))
        return {'files_analyzed':self.files_analyzed,'ai_scanned':self.ai_scanned,'score':round(score,1),'total':total,'critical':sev['high'],'warning':sev['medium'],'info':sev['low'],'issues':self.issues[:100]}

    def analyze_directory(self, dir_path):
        path = Path(dir_path)
        for f in sorted(path.rglob('*.py')):
            if f.is_file() and 'test_' not in f.name and '__pycache__' not in str(f) and '.git' not in str(f) and not f.name.startswith('.'):
                rel = str(f.relative_to(path))
                self.analyze_file(str(f), rel)
        return self.generate_report(dir_path) if not self.silent else self._build_json()
    
    def analyze_github(self, url, token=None):
        # Clone
        tmp = tempfile.mkdtemp()
        repo = url.rstrip('/').split('/')[-1].replace('.git','')
        clone_url = url
        if token:
            clone_url = f"https://x-access-token:{token}@github.com/{'/'.join(url.split('/')[-2:])}"
        subprocess.run(['git','clone','--depth','1',clone_url,tmp],capture_output=True,timeout=60)
        # Analyze
        self.analyze_directory(tmp)
        # Save to home
        dest = Path.home() / repo
        if dest.exists(): shutil.rmtree(dest)
        shutil.copytree(tmp, str(dest))
        shutil.rmtree(tmp, ignore_errors=True)
        print(f"\n📁 Saved: ~/{repo}/\n")
    
    def generate_report(self, target_path=None):
        if self.silent:
            return self._build_json()
        T = {
            'ar': {'security':'أمان','quality':'جودة','ai':'AI','total':'إجمالي','files':'ملف','score':'تقييم','critical':'حرج','fix_plan':'خطة الإصلاح','target':'الهدف'},
            'en': {'security':'Security','quality':'Quality','ai':'AI','total':'Total','files':'files','score':'Score','critical':'Critical','fix_plan':'Fix Plan','target':'Target'}
        }
        t = T.get(self.lang, T['en'])
        
        sev = defaultdict(int)
        for i in self.issues: sev[i.get('severity','medium')] += 1
        
        total = len(self.issues)
        # Better scoring
        score = max(0, min(10, 10 - sev['high']*0.8 - sev['medium']*0.2 - sev['low']*0.05))
        
        if score >= 9: grade = 'A+'
        elif score >= 8: grade = 'A'
        elif score >= 7: grade = 'B'
        elif score >= 6: grade = 'C'
        elif score >= 4: grade = 'D'
        else: grade = 'F'
        
        print(f"""
╔══════════════════════════════════════════════════╗
║      🛡️ DocGen Secure v3.0 Report              ║
╠══════════════════════════════════════════════════╣
║  {t['target']}: {str(target_path or ''):<38}║
║  {t['files']}: {self.files_analyzed:<41}║
╠══════════════════════════════════════════════════╣
║  ⭐ {t['score']}: {score:.1f}/10  |  🏆 {grade:<30}║
║  🔴 {t['critical']}: {sev['high']:<4} 🟡 Medium: {sev['medium']:<4} 🟢 Low: {sev['low']:<4} ⬜ {t['total']}: {total:<4}║
╚══════════════════════════════════════════════════╝
""")
        
        # Critical first
        for severity, icon, label in [('high','🔴','CRITICAL'),('medium','🟡','WARNING'),('low','🟢','INFO')]:
            items = [i for i in self.issues if i.get('severity')==severity]
            if items:
                print(f"  {icon} {label} ({len(items)}):")
                for item in items[:15]:
                    print(f"     📁 {item['file']}:{item['line']}  →  {item['title']}")
                    print(f"     💡 {item['fix']}\n")
        
        if total > 40:
            print(f"  ... +{total-40} more\n")
        
        print(f"═══════════════════════════════════════════════════")
        print(f"  🎯 {t['fix_plan']}:")
        print(f"     1. 🔴 → Fix immediately")
        print(f"     2. 🟡 → Fix before release")
        print(f"     3. 🟢 → Improve over time")
        print(f"═══════════════════════════════════════════════════\n")
        
        # JSON
        json_file = 'docgen_report.json'
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump({'target':str(target_path),'files':self.files_analyzed,'score':round(score,1),'grade':grade,'total':total,'by_severity':dict(sev),'issues':self.issues[:100]}, f, indent=2, ensure_ascii=False)
        print(f"📄 JSON: {json_file}\n")

# ============================================================
# CLI
# ============================================================
def main():
    import argparse
    p = argparse.ArgumentParser(description="🛡️ DocGen Secure v3.0")
    p.add_argument('target', nargs='?', help='File, directory, or GitHub URL')
    p.add_argument('--en', action='store_true', help='English')
    p.add_argument('--token', help='GitHub token')
    args = p.parse_args()
    
    if not args.target:
        p.print_help()
        return
    
    target = args.target
    lang = 'en' if args.en else 'ar'
    
    km = KeyManager()
    ai = AICaller(km)
    analyzer = Analyzer(lang=lang, ai_caller=ai)
    
    # Local first - check if directory exists
    if os.path.isdir(target):
        analyzer.analyze_directory(target)
        return
    
    # Local file
    if os.path.isfile(target):
        analyzer.analyze_file(target, Path(target).name)
        analyzer.generate_report(target)
        return
    
    # GitHub - convert name to URL
    if not target.startswith('http') and '/' in target and '.' not in target.split('/')[0]:
        target = 'https://github.com/' + target
    
    if 'github.com' in target:
        analyzer.analyze_github(target, args.token)
        return
    
    # Not found
    print(f"❌ Not found: {target}")
    return
    
    # Old code
    if os.path.isdir(target):
        analyzer.analyze_directory(target)
    elif os.path.isfile(target):
        analyzer.analyze_file(target, Path(target).name)
        analyzer.generate_report(target)
    else:
        print(f"❌ Not found: {target}")

if __name__ == '__main__':
    main()
