from setuptools import setup

setup(
    name="docgen-secure",
    version="1.0.0",
    packages=["docgen_secure"],
    install_requires=[],
    entry_points={
        "console_scripts": [
            "docgen-secure=docgen_secure.cli:main",
        ],
    },
)
