"""ProtoWall CLI — manage projects, invites, and access from the terminal."""

import json
import sys

from protowall.client import ProtoWallClient, ApiError


def _client():
    try:
        return ProtoWallClient()
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        raise SystemExit(1)


def _print(data):
    if isinstance(data, (dict, list)):
        print(json.dumps(data, indent=2))
    else:
        print(data)


def _error(e):
    print(f"Error: {e.message} ({e.code})", file=sys.stderr)
    raise SystemExit(1)


def cmd_projects(args):
    """List all projects."""
    try:
        _print(_client().list_projects())
    except ApiError as e:
        _error(e)


def cmd_project_get(args):
    """Get project detail."""
    if not args:
        print("Usage: protowall project <slug>", file=sys.stderr)
        raise SystemExit(1)
    try:
        _print(_client().get_project(args[0]))
    except ApiError as e:
        _error(e)


def cmd_project_create(args):
    """Create a new project."""
    if len(args) < 2:
        print("Usage: protowall project create <name> <destination_url> [nda_text]", file=sys.stderr)
        raise SystemExit(1)
    nda_text = args[2] if len(args) > 2 else None
    try:
        _print(_client().create_project(args[0], args[1], nda_text))
    except ApiError as e:
        _error(e)


def cmd_project_delete(args):
    """Delete a project."""
    if not args:
        print("Usage: protowall project delete <slug>", file=sys.stderr)
        raise SystemExit(1)
    try:
        _print(_client().delete_project(args[0]))
    except ApiError as e:
        _error(e)


def cmd_invites(args):
    """List invites for a project."""
    if not args:
        print("Usage: protowall invites <project-slug>", file=sys.stderr)
        raise SystemExit(1)
    try:
        _print(_client().list_invites(args[0]))
    except ApiError as e:
        _error(e)


def cmd_invite(args):
    """Send an invite."""
    if len(args) < 2:
        print("Usage: protowall invite <project-slug> <email>", file=sys.stderr)
        raise SystemExit(1)
    try:
        _print(_client().send_invite(args[0], args[1]))
    except ApiError as e:
        _error(e)


def cmd_revoke(args):
    """Revoke an invite."""
    if len(args) < 2:
        print("Usage: protowall revoke <project-slug> <invite-id>", file=sys.stderr)
        raise SystemExit(1)
    try:
        _print(_client().revoke_access(args[0], args[1]))
    except ApiError as e:
        _error(e)


def cmd_audit(args):
    """Get audit log for a project."""
    if not args:
        print("Usage: protowall audit <project-slug> [limit]", file=sys.stderr)
        raise SystemExit(1)
    limit = int(args[1]) if len(args) > 1 else 50
    try:
        _print(_client().get_audit_log(args[0], limit))
    except ApiError as e:
        _error(e)


def cmd_rotate_secret(args):
    """Rotate origin secret for a project."""
    if not args:
        print("Usage: protowall rotate-secret <project-slug>", file=sys.stderr)
        raise SystemExit(1)
    try:
        _print(_client().rotate_secret(args[0]))
    except ApiError as e:
        _error(e)


def cmd_usage(args):
    """Get project usage analytics (Pro)."""
    if not args:
        print("Usage: protowall usage <project-slug> [7d|30d]", file=sys.stderr)
        raise SystemExit(1)
    range_ = args[1] if len(args) > 1 else "7"
    try:
        _print(_client().get_project_usage(args[0], range_))
    except ApiError as e:
        _error(e)


def cmd_reviewer(args):
    """Get per-reviewer engagement (Pro)."""
    if len(args) < 2:
        print("Usage: protowall reviewer <project-slug> <invite-id> [7d|30d]", file=sys.stderr)
        raise SystemExit(1)
    range_ = args[2] if len(args) > 2 else "30"
    try:
        _print(_client().get_invitee_engagement(args[0], args[1], range_))
    except ApiError as e:
        _error(e)


def cmd_sessions(args):
    """List reviewer sessions with cached AI summaries (Pro). Read-only — no API cost, no cap consumed."""
    if len(args) < 2:
        print("Usage: protowall sessions <project-slug> <invite-id>", file=sys.stderr)
        raise SystemExit(1)
    try:
        _print(_client().list_reviewer_sessions(args[0], args[1]))
    except ApiError as e:
        _error(e)


def cmd_previews(args):
    """List project previews. Pass --open to filter to currently-resolving ones."""
    if not args:
        print("Usage: protowall previews <project-slug> [--open]", file=sys.stderr)
        raise SystemExit(1)
    status = "open" if "--open" in args[1:] else None
    try:
        _print(_client().list_previews(args[0], status=status))
    except ApiError as e:
        _error(e)


def cmd_preview_create(args):
    """Create a project preview (Pro)."""
    if len(args) < 3:
        print(
            "Usage: protowall preview create <project-slug> <slug-suffix> <destination-url> [--label=...] [--ref=...]\n"
            "Example: protowall preview create acme pr-42 https://acme-pr-42.preview.app --ref=github:acme/web#42",
            file=sys.stderr,
        )
        raise SystemExit(1)
    slug, suffix, dest = args[0], args[1], args[2]
    label = None
    external_ref = None
    for a in args[3:]:
        if a.startswith("--label="):
            label = a.split("=", 1)[1] or None
        elif a.startswith("--ref="):
            external_ref = a.split("=", 1)[1] or None
    try:
        _print(_client().create_preview(slug, suffix, dest, label=label, external_ref=external_ref))
    except ApiError as e:
        _error(e)


def cmd_preview_update(args):
    """Update destination_url, label, or external_ref on a preview."""
    if len(args) < 3:
        print(
            "Usage: protowall preview update <project-slug> <preview-id> [--url=...] [--label=...] [--ref=...]",
            file=sys.stderr,
        )
        raise SystemExit(1)
    slug, preview_id = args[0], args[1]
    destination_url = None
    label = None
    external_ref = None
    for a in args[2:]:
        if a.startswith("--url="):
            destination_url = a.split("=", 1)[1]
        elif a.startswith("--label="):
            label = a.split("=", 1)[1]
        elif a.startswith("--ref="):
            external_ref = a.split("=", 1)[1]
    if destination_url is None and label is None and external_ref is None:
        print("Pass at least one of --url, --label, --ref.", file=sys.stderr)
        raise SystemExit(1)
    try:
        _print(_client().update_preview(
            slug, preview_id,
            destination_url=destination_url, label=label, external_ref=external_ref,
        ))
    except ApiError as e:
        _error(e)


def cmd_preview_close(args):
    """Soft-close a preview. Idempotent."""
    if len(args) < 2:
        print("Usage: protowall preview close <project-slug> <preview-id>", file=sys.stderr)
        raise SystemExit(1)
    try:
        _print(_client().close_preview(args[0], args[1]))
    except ApiError as e:
        _error(e)


def cmd_requests(args):
    """List access requests. Pass a status to filter (pending / approved / declined)."""
    if not args:
        print("Usage: protowall requests <project-slug> [pending|approved|declined]", file=sys.stderr)
        raise SystemExit(1)
    status = args[1].upper() if len(args) > 1 else None
    if status and status not in ("PENDING", "APPROVED", "DECLINED"):
        print("Status must be one of: pending, approved, declined.", file=sys.stderr)
        raise SystemExit(1)
    try:
        _print(_client().list_access_requests(args[0], status=status))
    except ApiError as e:
        _error(e)


def cmd_request_approve(args):
    """Approve a pending access request — creates an Invite and sends the invite email."""
    if len(args) < 2:
        print("Usage: protowall request approve <project-slug> <request-id>", file=sys.stderr)
        raise SystemExit(1)
    try:
        _print(_client().approve_access_request(args[0], args[1]))
    except ApiError as e:
        if e.code == "invite_cap":
            print(
                f"Error: {e.message}\n"
                "Decline the request, revoke an existing invitee, or upgrade to Pro.",
                file=sys.stderr,
            )
            raise SystemExit(1)
        _error(e)


def cmd_request_decline(args):
    """Decline a pending access request. Silent — no email back to the requester."""
    if len(args) < 2:
        print("Usage: protowall request decline <project-slug> <request-id>", file=sys.stderr)
        raise SystemExit(1)
    try:
        _print(_client().decline_access_request(args[0], args[1]))
    except ApiError as e:
        _error(e)


def cmd_summarize_session(args):
    """Generate an AI summary for a session (Pro, counts against monthly cap)."""
    if len(args) < 3:
        print(
            "Usage: protowall summarize-session <project-slug> <invite-id> <session-start>\n"
            "Pass session_start as the ISO timestamp from `protowall sessions ...`.\n"
            "Counts against your monthly cap (default 50/month).",
            file=sys.stderr,
        )
        raise SystemExit(1)
    try:
        _print(_client().summarize_reviewer_session(args[0], args[1], args[2]))
    except ApiError as e:
        if e.code == "cap_exhausted":
            used = e.body.get("summaries_used")
            cap = e.body.get("summaries_cap")
            print(
                f"Error: monthly summary cap reached ({used}/{cap}). Resets at the start of next month.",
                file=sys.stderr,
            )
            raise SystemExit(1)
        _error(e)


COMMANDS = {
    "projects": ("List all projects", cmd_projects),
    "project": ("Get project detail: project <slug>", cmd_project_get),
    "project create": ("Create project: project create <name> <url>", cmd_project_create),
    "project delete": ("Delete project: project delete <slug>", cmd_project_delete),
    "invites": ("List invites: invites <slug>", cmd_invites),
    "invite": ("Send invite: invite <slug> <email>", cmd_invite),
    "revoke": ("Revoke access: revoke <slug> <invite-id>", cmd_revoke),
    "audit": ("Audit log: audit <slug> [limit]", cmd_audit),
    "usage": ("Project usage (Pro): usage <slug> [7d|30d]", cmd_usage),
    "reviewer": ("Reviewer engagement (Pro): reviewer <slug> <invite-id> [7d|30d]", cmd_reviewer),
    "sessions": ("List sessions + cached summaries (Pro, read-only): sessions <slug> <invite-id>", cmd_sessions),
    "summarize-session": ("Generate session summary (Pro, uses cap): summarize-session <slug> <invite-id> <session-start>", cmd_summarize_session),
    "previews": ("List previews (Pro): previews <slug> [--open]", cmd_previews),
    "preview create": ("Create preview (Pro): preview create <slug> <suffix> <url> [--label=...] [--ref=...]", cmd_preview_create),
    "preview update": ("Update preview (Pro): preview update <slug> <preview-id> [--url=...] [--label=...] [--ref=...]", cmd_preview_update),
    "preview close": ("Close preview (Pro): preview close <slug> <preview-id>", cmd_preview_close),
    "requests": ("List access requests: requests <slug> [pending|approved|declined]", cmd_requests),
    "request approve": ("Approve request: request approve <slug> <request-id>", cmd_request_approve),
    "request decline": ("Decline request: request decline <slug> <request-id>", cmd_request_decline),
    "rotate-secret": ("Rotate secret: rotate-secret <slug>", cmd_rotate_secret),
}


def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        print("ProtoWall CLI\n")
        print("Usage: protowall <command> [args]\n")
        print("Commands:")
        for name, (desc, _) in COMMANDS.items():
            print(f"  {name:20s} {desc}")
        print(f"\nSet PROTOWALL_API_KEY to authenticate.")
        print("Create a key at https://protowall.app/dashboard/")
        raise SystemExit(0)

    # Check for two-word commands (e.g. "project create")
    two_word = f"{args[0]} {args[1]}" if len(args) > 1 else ""
    if two_word in COMMANDS:
        _, handler = COMMANDS[two_word]
        handler(args[2:])
    elif args[0] in COMMANDS:
        _, handler = COMMANDS[args[0]]
        handler(args[1:])
    else:
        print(f"Unknown command: {args[0]}", file=sys.stderr)
        print("Run 'protowall help' for usage.", file=sys.stderr)
        raise SystemExit(1)
