from __future__ import annotations

from typing import TypeVar, TYPE_CHECKING
import functools

if TYPE_CHECKING:
    from typing import Any, Literal
    from linkmerce.common.extract import LoginHandler
    from linkmerce.common.load import DuckDBConnection
    from linkmerce.common.transform import Transformer, DuckDBTransformer
    from pathlib import Path

DuckDBResult = TypeVar("DuckDBResult", list[tuple], list[dict], bytes)


def prepare_extract(
        transformer_cls: type[Transformer],
        extract_options: dict | None = None,
        transform_options: dict | None = None,
        return_type: Literal["csv", "json", "parquet", "raw", "none"] = "json",
        **kwargs
    ) -> dict:
    """다음 2가지 경우에 모두 해당된다면 `Transformer` 객체를 생성하고   
    `extract_options`에 `transform` 메서드를 `parser`로 할당한다.
    1. `return_type`이 `"raw"`가 아닌 경우
    2. `extract_options`에 `parser`가 없는 경우

    그 외에 키워드 인자로 전달되는 값을 `extract_options`에 추가한다.
    """
    from linkmerce.utils.nested import merge
    extract_options = extract_options or dict()

    if (return_type != "raw") and ("parser" not in extract_options):
        transformer = transformer_cls(**(transform_options or dict()))
        extract_options["parser"] = transformer.transform

    return merge(extract_options, kwargs) if kwargs else extract_options


def prepare_duckdb_extract(
        transformer_cls: type[DuckDBTransformer],
        connection: DuckDBConnection,
        extract_options: dict | None = None,
        transform_options: dict | None = None,
        return_type: Literal["csv", "json", "parquet", "raw", "none"] = "json",
        **kwargs
    ) -> dict:
    """다음 2가지 경우에 모두 해당된다면 `DuckDBTransformer` 객체를 생성하고   
    `extract_options`에 `transform` 메서드를 `parser`로 할당한다.
    1. `return_type`이 `"raw"`가 아닌 경우
    2. `extract_options`에 `parser`가 없는 경우

    그 외에 키워드 인자로 전달되는 값을 `extract_options`에 추가한다.
    """
    from linkmerce.utils.nested import merge
    extract_options = extract_options or dict()

    if (return_type != "raw") and ("parser" not in extract_options):
        db_info = {"db_info": {"conn": connection}}
        transformer = transformer_cls(**merge(transform_options or dict(), db_info))
        extract_options["parser"] = transformer.transform

    return merge(extract_options, kwargs) if kwargs else extract_options


def with_duckdb_connection(tables: dict | None = None, table: str | None = None):
    """DuckDB 연결을 보장한다. `connection`이 없다면 연결을 생성하고, 실행 종료 후 연결을 닫는다.

    `return_type`에 따라 실행 결과를 형식에 맞게 변환하여 반환한다.
    - `"csv"`: 테이블 조회 결과를 CSV 형식의 `list[tuple]`로 반환한다.
    - `"json"`: 테이블 조회 결과를 JSON 형식의 `list[dict]`로 반환한다.
    - `"parquet"`: 테이블 조회 결과를 Parquet 바이너리로 반환한다.
    - `"raw"`: 함수 실행 결과를 그대로 반환한다.
    - `"none"`: 아무것도 반환하지 않는다.

    **NOTE** 조회 대상 테이블(`tables`)을 데코레이터 호출 시점에 지정할 수 있다.

    테이블이 여러 개라면 테이블 조회 결과는 `{table_key: DuckDBResult}` 구조로 반환한다.
    """
    tables = {"table": table} if table else tables

    def decorator(func):
        @functools.wraps(func)
        def wrapper(
                *args,
                connection: DuckDBConnection | None = None,
                return_type: Literal["csv", "json", "parquet", "raw", "none"] = "json",
                **kwargs
            ) -> DuckDBResult | dict[str, DuckDBResult] | Any | None:
            if connection is not None:
                result = func(*args, connection=connection, return_type=return_type, **kwargs)
                if return_type == "raw":
                    return result
                elif return_type == "none":
                    return None
                return fetch_all_duckdb_tables(connection, tables, return_type)

            from linkmerce.common.load import DuckDBConnection
            with DuckDBConnection() as temp_connection:
                result = func(*args, connection=temp_connection, return_type=return_type, **kwargs)
                if return_type == "raw":
                    return result
                elif return_type == "none":
                    return None
                return fetch_all_duckdb_tables(temp_connection, tables, return_type)

        return wrapper
    return decorator


def fetch_all_duckdb_tables(
        connection: DuckDBConnection,
        tables: dict | None = None,
        return_type: Literal["csv", "json", "parquet"] = "json",
    ) -> DuckDBResult | dict[str, DuckDBResult] | Any | None:
    """DuckDB 연결에서 테이블 데이터를 조회하여 지정된 형식으로 반환한다."""
    exists = connection.show_tables()
    if tables:
        tables = {key: name for key, name in tables.items() if name in exists}
    else:
        tables = {"table": exists}

    if not tables:
        tables = {table: table for table in connection.show_tables()}
        return fetch_all_duckdb_tables(connection, tables, return_type) if tables else None
    elif len(tables) == 1:
        return connection.fetch_all(return_type, f"SELECT * FROM {list(tables.values())[0]}")
    else:
        return {key: connection.fetch_all(return_type, f"SELECT * FROM {name}")
                for key, name in tables.items()}


def get_tables(transform_options: dict | None, tables: dict) -> dict:
    """`Transformer` 초기화 옵션에서 `tables` 값이 있다면 기본 테이블 정보에 덮어써서 반환한다."""
    if not isinstance(transform_options, dict):
        return tables
    return tables | (transform_options.get("tables") or dict())


def get_table(transform_options: dict | None, table_key: str = "table", default: str | None = None) -> str | None:
    """`Transformer` 초기화 옵션에서 `table_key`에 해당하는 테이블 명을 꺼낸다. 대상이 없으면 `default`를 반환한다."""
    if not isinstance(transform_options, dict):
        return default
    return (transform_options.get("tables") or dict()).get(table_key, default)


def handle_cookies(handler: LoginHandler, save_to: str | Path | None = None, mkdir: bool = True) -> str:
    """쿠키를 파일로 저장하고 쿠키를 문자열 형태로 반환한다."""
    cookies = handler.get_cookies(to="str")
    if not (cookies and save_to):
        return cookies

    from pathlib import Path
    file_path = save_to if isinstance(save_to, Path) else Path(save_to)
    if mkdir:
        file_path.parent.mkdir(parents=True, exist_ok=True)

    with open(file_path, 'w', encoding="utf-8") as file:
        file.write(cookies)
    return cookies
