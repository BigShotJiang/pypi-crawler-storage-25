from __future__ import annotations

from linkmerce.common.transform import JsonTransformer, ExcelTransformer, DuckDBTransformer

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Literal


class ProductOptionParser(JsonTransformer):
    """쿠팡 Wing 상품 목록을 파싱하는 클래스."""

    dtype = dict
    scope = "data.productList"
    fields = [
        "vendorInventoryId", "vendorInventoryItemId", "vendorItemId", "barcode",
        "vendorId", "productName", "itemName", "displayCategoryCode", "categoryId", "categoryName",
        "brand", "manufacture", "valid", "salePrice", "deliveryCharge", "viUnitSoldAgg",
        "stockQuantity", "createdOn", "modifiedOn"
    ]
    product_type: Literal["product", "option"] = "option"

    def parse(self, obj: list[dict], **kwargs) -> list[dict]:
        """`product_type = "option"`일 때 상품마다 `vendorInventoryItems`를 평탄화한 옵션 목록을 반환한다."""
        if self.product_type == "option":
            options = list()
            for product in obj:
                if not isinstance(product, dict):
                    continue
                for option in (product.get("vendorInventoryItems") or list()):
                    if isinstance(option, dict):
                        options.append(dict(product, **option))
            return options
        return obj


class ProductOption(DuckDBTransformer):
    """쿠팡 Wing 상품 목록을 변환 및 적재하는 클래스.

    - **Extractor**: `ProductOption`

    - **Parser** ( *parser_class: input_type -> output_type* ):
        `ProductOptionParser: dict -> list[dict]`

    - **Table** ( *table_key: table_name* ):
        `table: coupang_product`

    Parameters
    ----------
    **NOTE** DuckDB 쿼리 실행에 필요한 파라미터를 `transform` 메서드 호출 시 함께 전달해야 한다.

    is_deleted: bool
        삭제 상품 여부
    """

    extractor = "ProductOption"
    tables = {"table": "coupang_product"}
    parser = ProductOptionParser
    params = {"is_deleted": "$is_deleted"}


class ProductDetail(DuckDBTransformer):
    """쿠팡 Wing 상품의 상세 정보를 변환 및 적재하는 클래스.

    - **Extractor**: `ProductDetail`

    - **Parser** ( *parser_class: input_type -> output_type* ):
        `JsonTransformer: dict -> list[dict]`

    - **Table** ( *table_key: table_name* ):
        `table: coupang_product_detail`
    """

    extractor = "ProductDetail"
    queries = ["create", "bulk_insert", "bulk_insert_vendor", "bulk_insert_rfm"]
    tables = {"table": "coupang_product_detail"}
    parser = "json"
    parser_config = dict(
        dtype = dict,
        scope = "data",
        fields = [
            "vendorInventoryId", "vendorInventoryItemId", "vendorItemId", "productId", "itemId",
            "barcode", "itemName", "originalPrice", "salePrice", "stockQuantity"
        ],
    )

    def bulk_insert(
            self,
            result: list[dict],
            query_key: str = "bulk_insert",
            render: dict | Literal["tables"] | None = "tables",
            params: dict | None = None,
            referer: Literal["vendor", "rfm"] | None = None,
            **kwargs
        ) -> list:
        """`referer`가 전달되면 전용 `bulk_insert` 쿼리를 선택해 실행한다."""
        query_key = f"bulk_insert_{referer}" if referer else query_key
        return super().bulk_insert(result, query_key, render, params, **kwargs)


class VendorInventoryItemParser(ExcelTransformer):
    """쿠팡 Wing 상품 목록의 '가격/재고/판매상태' 다운로드 결과를 파싱하는 클래스."""

    header = 3
    fields = [
        "등록상품ID", "Product ID", "옵션 ID", "바코드", "쿠팡 노출 상품명", "업체 등록 상품명",
        "등록 옵션명", "판매상태", "할인율기준가", "판매가격", "판매수량", "잔여수량(재고)"
    ]


class EditableCatalogueParser(ExcelTransformer):
    """쿠팡 Wing 상품 목록의 '쿠팡상품정보' 다운로드 결과를 파싱하는 클래스."""

    sheet_name = "Template"
    header = 4
    fields = ["등록상품ID", "등록상품명", "쿠팡 노출상품명", "카테고리", "제조사", "브랜드", "검색어", "성인상품여부(Y/N)"]

    def select_fields(self, data: list[dict], **kwargs) -> list[dict]:
        """`등록상품ID` 값이 비어있는 행을 병합된 영역으로 인식하고 빈 셀에 이전 행 값을 채워 반환한다."""
        info = {field: None for field in self.fields}
        for i in range(len(data)):
            if data[i]["등록상품ID"]:
                info = {field: data[i].get(field) for field in self.fields}
            else:
                data[i].update(info)
        return data


class ProductDownload(DuckDBTransformer):
    """쿠팡 Wing 상품 목록을 변환 및 적재하는 클래스.

    - **Extractor**: `ProductDownload`

    - **Parser** ( *parser_class: input_type -> output_type* ):
        `VendorInventoryItemParser: bytes -> list[dict]`

    - **Table** ( *table_key: table_name* ):
        `table: coupang_product_download`

    Parameters
    ----------
    **NOTE** DuckDB 쿼리 실행에 필요한 파라미터를 `transform` 메서드 호출 시 함께 전달해야 한다.

    vendor_id: str
        업체 코드
    is_deleted: bool
        삭제 상품 여부
    """

    extractor = "ProductDownload"
    tables = {"table": "coupang_product_download"}
    params = {"vendor_id": "$vendor_id", "is_deleted": "$is_deleted"}

    def parse(self, obj: bytes, request_type = "VENDOR_INVENTORY_ITEM", **kwargs) -> list[dict]:
        """`request_type`에 따라 파서를 선택한다. `VENDOR_INVENTORY_ITEM`만 지원한다."""
        if request_type != "VENDOR_INVENTORY_ITEM":
            self.raise_parse_error(f"Parsing for request type '{request_type}' is not supported.")

        config = self.parser_config or dict()
        return VendorInventoryItemParser(**config).transform(obj, **kwargs)


class RocketInventory(DuckDBTransformer):
    """쿠팡 로켓그로스 재고현황을 변환 및 적재하는 클래스.

    - **Extractor**: `RocketInventory`

    - **Parser** ( *parser_class: input_type -> output_type* ):
        `JsonTransformer: dict -> list[dict]`

    - **Table** ( *table_key: table_name* ):
        `table: coupang_rocket_inventory`

    Parameters
    ----------
    **NOTE** DuckDB 쿼리 실행에 필요한 파라미터를 `transform` 메서드 호출 시 함께 전달해야 한다.

    vendor_id: str
        업체 코드
    """

    extractor = "RocketInventory"
    tables = {"table": "coupang_rocket_inventory"}
    parser = "json"
    parser_config = dict(
        dtype = dict,
        scope = "viProperties",
        fields = {
            ".": ["vendorItemId", "gmvForLast7Days", "gmvForLast30Days", "unitsSoldForLast7Days", "unitsSoldForLast30Days"],
            "listingDetails": ["vendorInventoryId", "productId"],
            "creturnConfigViewDto": [{key: None} for key in ["vendorInventoryItemId", "externalSkuId", "vendorId"]],
            "inventoryDetails": [
                "orderableQuantity", {"inProgressInboundStatistics.inProgressInboundQuantity": None},
                "daysOfCover", {"storageFee.monthlyStorageFeeAmount.amount": None}
            ]
        },
    )
    params = {"vendor_id": "$vendor_id"}


class RocketOption(DuckDBTransformer):
    """쿠팡 로켓그로스 재고현황을 변환 및 적재하는 클래스.

    **NOTE** 쿠팡 Wing 상품 목록을 다루는 `ProductOption` 클래스와 동일한 구성의 테이블을 가진다.

    - **Extractor**: `RocketInventory`

    - **Parser** ( *parser_class: input_type -> output_type* ):
        `JsonTransformer: dict -> list[dict]`

    - **Table** ( *table_key: table_name* ):
        `table: coupang_rocket_option`

    Parameters
    ----------
    **NOTE** DuckDB 쿼리 실행에 필요한 파라미터를 `transform` 메서드 호출 시 함께 전달해야 한다.

    vendor_id: str
        업체 코드
    """

    extractor = "RocketInventory"
    tables = {"table": "coupang_rocket_option"}
    parser = "json"
    parser_config = dict(
        dtype = dict,
        scope = "viProperties",
        fields = {
            ".": ["vendorItemId", "unitsSoldForLast30Days"],
            "listingDetails": ["vendorInventoryId", "productId", "vendorInventoryName", "productRegistrationDate"],
            "creturnConfigViewDto": [{key: None} for key in [
                "vendorInventoryItemId", "itemId", "externalSkuId", "vendorId", "productName", "itemName",
                "displayCategoryCodeLevel1", "displayCategoryCodeLevel2", "displayCategoryCodeLevel3",
                "displayCategoryCodeLevel4", "displayCategoryCodeLevel5", "onSale"
            ]],
            "creturnConfigViewDto.creturnCategoryLevelThresholdDto": [
                {"categoryId": None}, {"kanNameEn": None}
            ],
            "inventoryDetails": ["isHiddenByVendor", "orderableQuantity"],
            "pricing": ["salesPrice.amount"]
        },
    )
    params = {"vendor_id": "$vendor_id"}
