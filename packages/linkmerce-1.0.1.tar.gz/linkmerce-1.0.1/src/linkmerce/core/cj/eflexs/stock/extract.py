from __future__ import annotations
from linkmerce.core.cj.eflexs import CjEflexs

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Iterable, Literal
    import datetime as dt


class Stock(CjEflexs):
    """CJ대한통운 eFLEXs 상세재고조회 메뉴의 재고 내역을 조회하는 클래스.

    - **Menu**: 재고관리 > 재고조회 > 상세재고조회 (`IMSI0002M`)
    - **API**: https://eflexs-x.cjlogistics.com/IMSI0002M/selectDtlStckSearch.do
    - **Referer**: https://eflexs-x.cjlogistics.com/index.do

    Attributes
    ----------
    **NOTE** 인스턴스 생성 시 `configs` 인자로 아래 설정값들을 반드시 전달해야 한다.

    userid: str
        CJ eFLEXs 로그인을 위한 User ID
    passwd: str
        CJ eFLEXs 로그인을 위한 Password
    mail_info: dict[str, str]
        2단계 인증을 위한 이메일 정보. 다음 키값을 포함해야 한다.
            - `origin`: 메일 서비스 도메인.
            - `email`: 메일 계정 아이디.
            - `passwd`: 메일 계정 비밀번호.

    **NOTE** 인스턴스 생성 시 `options` 인자로 `RequestEach` Task 옵션을 전달할 수 있다.

    request_delay: float | int | tuple[int, int]
        고객별 요청 간 대기 시간(초). 기본값은 `1`
    tqdm_options: dict | None
        반복 요청 작업 작업의 진행도를 출력하는 `tqdm`에 전달할 매개변수
    """

    menu = "IMSI0002M"
    path = "/selectDtlStckSearch.do"
    date_format = "%Y%m%d"
    default_options = {"RequestEach": {"request_delay": 1}}

    @CjEflexs.with_session
    @CjEflexs.with_auth_info
    def extract(
            self,
            customer_id: int | str | Iterable[int | str],
            start_date: dt.date | str | Literal[":last_week:"] = ":last_week:",
            end_date: dt.date | str | Literal[":start_date:", ":today:"] = ":today:",
            **kwargs
        ) -> dict | list[dict]:
        """상세재고조회 화면에서 고객별 재고 내역을 조회해 JSON 형식으로 반환한다.

        Parameters
        ----------
        customer_id: int | str | Iterable[int | str]
            조회할 고객 ID. 단일 값 또는 배열을 입력한다.
        start_date: dt.date | str
            조회 시작일. `dt.date` 객체 또는 `"YYYY-MM-DD"` 형식의 문자열을 입력한다.
                - `":last_week:"`: 오늘 기준 7일 전 날짜 (기본값)
        end_date: dt.date | str
            조회 종료일. `dt.date` 객체 또는 `"YYYY-MM-DD"` 형식의 문자열을 입력한다.
                - `":start_date:"`: `start_date`와 동일한 날짜
                - `":today:"`: 오늘 날짜 (기본값)

        Returns
        -------
        dict | list[dict]
            고객별 재고 내역. `customer_id` 타입에 따라 반환 타입이 다르다.
                - `customer_id`가 `int | str` 타입일 때 -> `dict`
                - `customer_id`가 `Iterable[int | str]` 타입일 때 -> `list[dict]`
        """
        return (self.request_each(self.request_json)
                .partial(**self.set_date(start_date, end_date))
                .expand(customer_id=customer_id)
                .run())

    def set_date(self, start_date: dt.date | str, end_date: dt.date | str) -> dict[str, dt.date]:
        """미리 정의된 날짜 문자열이 주어진다면 `dt.date` 객체로 치환한다."""
        import datetime as dt

        if start_date == ":last_week:":
            start_date = dt.date.today() - dt.timedelta(days=7)

        if end_date == ":start_date:":
            end_date = start_date
        elif end_date == ":today:":
            end_date = dt.date.today()

        return {"start_date": start_date, "end_date": end_date}

    def build_request_data(
            self,
            customer_id: int | str,
            start_date: dt.date | str,
            end_date: dt.date | str,
            page: int = 0,
            page_size: int = 100000,
            **kwargs
        ) -> dict:
        return {
            "pgmId": self.menu,
            "requestDataIds": "dmMainParam",
            "@d1#strrId": str(customer_id),
            "@d1#oWhCd": None,
            "@d1#srchZoneCd": None,
            "@d1#srchZoneNm": None,
            "@d1#srchItemNm": None,
            "@d1#srchItemCd": None,
            "@d1#srchWcellNm": None,
            "@d1#srchWcellTcd": None,
            "@d1#srchLotNo": None,
            "@d1#srchItemRarcode": None,
            "@d1#srchHldScd": None,
            "@d1#fromCloseDate": str(start_date).replace('-', ''),
            "@d1#toCloseDate": str(end_date).replace('-', ''),
            "@d1#srchMallId": None,
            "@d1#page": page,
            "@d1#pageRow": page_size,
            "@d1#srchLotNo7": None,
            "@d1#srchLotNo10": None,
            "@d1#itemGcd": None,
            "@d#": "@d1#",
            "@d1#": "dmMainParam",
            "@d1#tp": "dm",
        }
