from __future__ import annotations
from linkmerce.common.extract import Extractor
from linkmerce.core.smartstore.sscenter.common import SmartstoreCenterLogin


class PartnerCenter(Extractor):
    """네이버 쇼핑파트너센터에서 데이터를 조회하는 공통 클래스.

    - **URL**: https://center.shopping.naver.com/main

    Attributes
    ----------
    **NOTE** 인스턴스 생성 시 `cookies` 인자로 로그인 쿠키 문자열을 전달해야 한다.
    """

    method: str | None = None
    origin: str = "https://hcenter.shopping.naver.com"
    path: str | None = None

    @property
    def url(self) -> str:
        return self.concat_path(self.origin, self.path)

    def post_init(self, **kwargs):
        return self.require_cookies(key="koa:sess")


###################################################################
####################### Partner Center Login ######################
###################################################################

class PartnerCenterLogin(SmartstoreCenterLogin):
    """네이버 쇼핑파트너센터 로그인을 수행하여 쿠키와 토큰을 발급하는 클래스.

    - **URL**: https://center.shopping.naver.com/login?target_uri=https%3A%2F%2Fcenter.shopping.naver.com%2Fmain

    스마트스토어센터 로그인 → 쇼핑파트너센터 전환 → 토큰 발급 순서로 워크플로우를 실행한다.
    1. `super().login`: `SmartstoreCenterLogin` 클래스에 정의된 스마트스토어 로그인을 수행하고 채널을 전환한다.
    2. `celogin`: 스마트스토어 로그인 세션을 가지고 `/v1/slogin2/login` API에 로그인 요청한다.
    3. `embrace_token`: 쇼핑파트너센터 내에서 권한이 필요한 메뉴로 이동하여 토큰을 발급받는다.
    """

    center_url = "https://center.shopping.naver.com"

    @SmartstoreCenterLogin.with_session
    def login(
            self,
            userid: str | None = None,
            passwd: str | None = None,
            channel_seq: int | str | None = None,
            cookies: str | None = None,
            **kwargs
        ) -> dict:
        """스마트스토어센터 로그인 수행 후 쇼핑파트너센터 대시보드로 이동해 토큰을 발급받는다.

        Parameters
        ----------
        userid: str | None
            스마트스토어센터 판매자 아이디/이메일
        passwd: str | None
            스마트스토어센터 판매자 비밀번호
        channel_seq: int | str | None
            채널 번호. 로그인 후 접속된 채널이 다르면 채널 번호에 맞는 채널로 전환한다.
        cookies: str | None
            네이버 로그인 쿠키 문자열. 판매자 아이디 로그인을 대체하여 네이버 아이디로 로그인한다.

        Returns
        -------
        dict
            접속된 스토어(채널) 정보
        """
        from linkmerce.utils.regex import regexp_extract
        login_info = super().login(userid, passwd, channel_seq, cookies)
        self.login_init(login_info["redirectUrl"])
        self.celogin(pincode=regexp_extract(r"\?pincode=(.*)$", login_info["redirectUrl"]))
        self.fetch_embrace_token(subject="main", login=False)
        self.fetch_adbridge()
        self.fetch_embrace_token(subject="brand-analytics.product", login=True)
        return login_info

    def _center_url(self, _: str) -> str:
        return f"https://{_}center.shopping.naver.com"

    ############################ Login Init ###########################

    def login_init(self, redirect_url: str):
        """스마트스토어센터 로그인 후 쇼핑파트너센터로 전환되는 동작을 수행한다."""
        self.redirect_begin(redirect_url)

        url = self.main_url + "/api/login/init"
        params = {"needLoginInfoForAngular": "true", "stateName": "home"}
        headers = self.get_login_header()
        self.request("GET", url, params=params, headers=headers)

        self.click_to_center()

    def redirect_begin(self, redirect_url: str):
        headers = self.build_headers(redirect_url, referer=self.main_url)
        self.request("GET", redirect_url, headers=headers)

    def get_login_header(self) -> dict[str, str]:
        headers = self.build_headers(self.main_url, referer=self.main_url)
        headers["x-current-state"] = self.main_url + "/#/home/dashboard"
        headers["x-current-statename"] = "work.channel-select"
        headers["x-to-statename"] = "work.channel-select"
        return headers

    def click_to_center(self):
        url = self.main_url + "/api/sell/center/front-history/click"
        body = {
            "actionId": "gnb.link",
            "actionLocationId": "shoppingPartner",
            "groupStateCode": "layout",
            "stateCode": "main.dashboard-pay",
        }
        headers = self.build_headers(url, origin=self.main_url, referer=self.main_url)
        self.request("POST", url, json=body, headers=headers)

    ########################### Center Login ##########################

    def celogin(self, pincode: str):
        """스마트스토어센터 로그인 정보를 가지고 쇼핑파트너센터 로그인 쿠키를 얻는다."""
        login_info = self.authenticate(pincode)
        link = self.fetch_link()
        pubkey = self.fetch_pubkey(link)

        url = self.center_url + "/oauth2/login"
        body = self.build_login_data(pincode, pubkey, login_info)
        headers = self.build_headers(url, contents="form", https=True, referer=(self.center_url + "/v1/slogin2/login"), origin=self.center_url)
        with self.request("POST", url, data=body, headers=headers, allow_redirects=False) as response:
            self.celogin_redirect(response.headers["location"])

    def authenticate(self, pincode: str) -> dict:
        url = self.center_url + "/oauth2/authenticate"
        body = {
            "clientId": "smartstore",
            "pincode": pincode,
            "redirectUri": (self.center_url + "/login/redirect"),
            "state": "xyz",
        }
        headers = self.build_headers(url, contents="json", origin=self.center_url, referer=(self.center_url + "/v1/slogin2/login"))
        with self.request("POST", url, json=body, headers=headers) as response:
            return response.json()

    def fetch_link(self) -> str:
        url = self.center_url + "/v1/slogin2/login"
        headers = self.build_headers(url, https=True, referer=self.center_url)
        with self.request("GET", url, headers=headers, allow_redirects=False) as response:
            return response.headers["Link"]

    def fetch_pubkey(self, link: str) -> str:
        from linkmerce.utils.regex import regexp_extract
        url = self.center_url + regexp_extract(r"(/_app/[^/]+/immutable/chunks/encrypt\.[^.]+\.js)", link)
        headers = self.build_headers(url, referer=self.center_url)
        with self.request("GET", url, headers=headers) as response:
            return regexp_extract(r"`(-----BEGIN PUBLIC KEY-----[^`]+-----END PUBLIC KEY-----)`", response.text)

    def build_login_data(self, pincode: str, pubkey: str, login_info: dict) -> dict:
        from urllib.parse import urlencode
        return_url = urlencode({"return-uri": f"{self.center_url}/v1/slogin2/redirect"})

        return {
            "pincode": pincode,
            "username": self.JSEncrypt(login_info["response"]["alternateName"], pubkey),
            "client_id": "smartstore",
            "redirect_uri": f"{self.center_url}/login/redirect?{return_url}",
            "target_uri": "",
            "response_type": "code",
            "state": "xyz",
            "authentication_id": login_info["identifier"],
        }

    def JSEncrypt(self, username: str, publicKey: str) -> bytes:
        from Crypto.PublicKey import RSA
        from Crypto.Cipher import PKCS1_v1_5
        import base64

        rsa_key = RSA.importKey(publicKey.encode("utf-8"))
        cipher = PKCS1_v1_5.new(rsa_key)
        return base64.b64encode(cipher.encrypt(username.encode("utf-8")))

    def celogin_redirect(self, redirect_url: str):
        headers = self.build_headers(redirect_url, referer=(self.center_url + "/v1/slogin2/login"))
        self.request("GET", redirect_url, headers=headers)

    ########################## Embrace Token ##########################

    def fetch_embrace_token(self, subject: str, login: bool = False, params: dict = dict()) -> str:
        """쇼핑파트너센터 로그인 쿠키를 가지고 특정 메뉴의 대시보드로 이동해 토큰을 발급받는다."""
        url = self.center_url + "/v2/members/me/embrace-token-at-url"
        params = dict(subject=subject, **params)
        referer = '/'.join(["https://center.shopping.naver.com", str(subject).replace('.', '/')])
        headers = self.build_headers(url, https=True, referer=referer)
        headers["Sec-Fetch-Dest"] = "iframe"
        with self.request("GET", url, params=params, headers=headers, allow_redirects=False) as response:
            self.redirect_embrace_token(response.headers["location"], subject, login=login)

    def redirect_embrace_token(self, redirect_url: str, referer: str, login: bool = False):
        headers = self.build_headers(redirect_url, https=True, referer=referer)
        self.request("GET", redirect_url, headers=headers)
        if login:
            self.login_by_token(redirect_url)

    def login_by_token(self, redirect_url: str):
        from linkmerce.utils.regex import regexp_extract
        self.get_member()

        url = self._center_url('h') + "/v1/login/by-token"
        params = dict(token=regexp_extract(r"\?token=(.*)$", redirect_url))
        headers = self.build_headers(url, referer=redirect_url)
        self.request("GET", url, params=params, headers=headers)

    def get_member(self):
        url = self._center_url('h') + "/graphql"
        headers = self.build_headers(url, referer=self.center_url)
        self.request("POST", url, data=self.build_member_data(), headers=headers)

    def build_member_data(self) -> dict:
        from linkmerce.utils.graphql import GraphQLFields
        query = (GraphQLFields([
            "token", "loginForced",
            {
                "member": [
                    "identifier", "name", "alternateName",
                    {
                        "memberOf": [
                        "identifier", "sequence", "name", "alternateName", "taxID",
                        {
                            "brands": [
                            "identifier", "name",
                            {"owns": [{"category": ["identifier", "name"]}]},
                            {"members": ["identifier", "name", "alternateName", "url"]},
                            {"mainEntityOfPage": ["identifier", "name", "alternateName", "url"]},
                            {"additionalProperties": ["propertyID", "value"]}
                            ]
                        },
                        {"termsOfSerivce": ["identifier"]},
                        "additionalType", "action", "potentialActions",
                        {"subOrganizations": ["sequence"]},
                        {"aggregateRatings": ["ratingValue", "additionalType", "potentialActions"]}
                        ]
                    },
                    {"roles": ["roleName"]},
                    {"authorities": ["authorityName"]}
                ]
            }
            ]).generate_fields(indent=2, prefix="query getMember ")[:(len("  __typename\n}")*-1)] + '}\n')
        return {"operationName": "getMember", "variables": dict(), "query": query}

    ############################ Ad Bridge ############################

    def fetch_adbridge(self) -> str:
        """쇼핑파트너센터 홈페이지 이동 후 광고 대시보드를 불러온다."""
        self.fetch_adcenter()

        url = self._center_url("ad") + "/adbridge/home"
        referer = self._center_url('a') + "/iframe/main.nhn"
        headers = self.build_headers(url, https=True, referer=referer)
        self.request("GET", url, headers=headers)

    def fetch_adcenter(self):
        from bs4 import BeautifulSoup
        url = self._center_url('a') + "/iframe/main.nhn"
        headers = self.build_headers(url, https=True, referer=self.center_url, metadata={
            "sec-fetch-dest": "iframe", "sec-fetch-mode": "navigate", "sec-fetch-site": "same-site"
        })
        with self.request("GET", url, headers=headers) as response:
            source = BeautifulSoup(response.text, "html.parser")
            iframe_url = source.select_one("#adInfoFrame").attrs["src"]
            self.redirect_adcenter(iframe_url, referer=url)

    def redirect_adcenter(self, iframe_url: str, referer: str):
        headers = self.build_headers(iframe_url, https=True, referer=referer)
        self.request("GET", iframe_url, headers=headers)
