"""
lxml converter - inherits from py_bs4 and overrides selector methods.

Key differences from bs4:
- Uses lxml.html instead of BeautifulSoup
- .cssselect() instead of .select() / .select_one()
- .xpath() instead of custom xpath implementation
- .text_content() instead of .text
- .get() for attributes instead of .get_attribute_list()
"""

from ssc_codegen.converters.base import ConverterContext
from ssc_codegen.converters.helpers import to_snake_case

from ssc_codegen.ast import VariableType as VT
import ssc_codegen.ast as a

# Import the bs4 converter to inherit from it
from ssc_codegen.converters import py_bs4
from ssc_codegen.converters import py_helpers

# Create new converter that extends bs4 (inherits all handlers)
PY_LXML_CONVERTER = py_bs4.PY_BASE_CONVERTER.extend()

# Override specific handlers for lxml
PY_TYPES = py_bs4.PY_TYPES.copy()
PY_TYPES[VT.DOCUMENT] = "HtmlElement"
PY_TYPES[VT.LIST_DOCUMENT] = "List[HtmlElement]"


@PY_LXML_CONVERTER(a.Imports)
def pre_imports(node: a.Imports, ctx: ConverterContext):
    runtime = ctx.meta.get("runtime_module")
    if runtime:
        base_imports = [
            "import json",
            "import re",
            "import sys",
            "from typing import TypedDict, Optional, Any, List, Dict, Union, Literal",
        ]
    else:
        base_imports = [
            "import json",
            "import re",
            "import sys",
            "from typing import TypedDict, Optional, Any, List, Dict, Union, Literal",
        ]
        if not py_helpers.module_is_rest_only(node):
            base_imports.append("from html import unescape as _html_unescape")
        base_imports.extend(py_helpers.rest_imports(node))

    # Get transform imports for Python (already collected during parsing)
    transform_imports = sorted(node.transform_imports.get("py", set()))

    return base_imports + transform_imports


@PY_LXML_CONVERTER.post(a.Imports)
def post_imports(node: a.Imports, ctx: ConverterContext):
    lines = []
    if not py_helpers.module_is_rest_only(node):
        lines.extend(
            [
                "from lxml import html",
                "from lxml.html import HtmlElement",
            ]
        )
    lines.extend(py_helpers.http_client_import(ctx))
    return lines


@PY_LXML_CONVERTER(a.Utilities)
def pre_utilities(node: a.Utilities, ctx: ConverterContext):
    runtime = ctx.meta.get("runtime_module")
    if runtime:
        names = py_helpers.runtime_export_names(
            node, include_fallback_html=True
        )
        return [f"from {runtime} import " + ", ".join(names), ""]

    if py_helpers.module_is_rest_only(node):
        lines = []
        lines.extend(py_helpers.rest_utilities(node))
        return lines

    lines = py_helpers.base_utility_lines(include_fallback_html=True)
    lines.extend(py_helpers.rest_utilities(node))
    return lines


# Override struct __init__ to use lxml instead of BeautifulSoup
@PY_LXML_CONVERTER(a.Init)
def pre_init(node: a.Init, ctx: ConverterContext):
    init_node_names: list[str] = []
    for i in node.body:
        if isinstance(i, a.InitField):
            name = to_snake_case(i.name)
            init_node_names.append(name)
    code = [
        f"{ctx.indent}def __init__(self, document: Union[str, HtmlElement]):",
        f"{ctx.indent * 2}if isinstance(document, HtmlElement):",
        f"{ctx.indent * 3}self._doc = document",
        f"{ctx.indent * 2}elif isinstance(document, str):",
        f"{ctx.indent * 3}self._doc = html.fromstring(document.strip() or FALLBACK_HTML_STR)",
    ]
    for name in init_node_names:
        code.append(
            f"{ctx.indent * 2}self._{name} = self._init_{name}(self._doc)"
        )
    return code


@PY_LXML_CONVERTER(a.InitField)
def pre_init_field(node: a.InitField, ctx: ConverterContext):
    name = to_snake_case(node.name)
    ret_type = PY_TYPES.get(node.ret, "Any")
    return [f"    def _init_{name}(self, v: HtmlElement) -> {ret_type}:"]


@PY_LXML_CONVERTER(a.Field)
def pre_struct_field(node: a.Field, ctx: ConverterContext):
    name = to_snake_case(node.name)
    ret_type = PY_TYPES.get(node.ret, "Any")

    if node.ret == VT.JSON:
        jsonify_node = [i for i in node.body if isinstance(i, a.Jsonify)][0]
        ret_type = ret_type.format(jsonify_node.schema_name)
        if jsonify_node.is_array:
            ret_type = f"List[{ret_type}]"
    elif node.ret == VT.NESTED:
        nested_node = [i for i in node.body if isinstance(i, a.Nested)][0]
        ret_type = ret_type.format(nested_node.struct_name)
        if nested_node.is_array:
            ret_type = f"List[{ret_type}]"

    if node.accept == VT.STRING:
        return [
            f"    def _parse_{name}(self, v: HtmlElement) -> Union[{ret_type}, _UnmatchedTableRow]:"
        ]
    return [f"    def _parse_{name}(self, v: HtmlElement) -> {ret_type}:"]


@PY_LXML_CONVERTER(a.Key)
def pre_struct_key(node: a.Key, ctx: ConverterContext):
    return ["    def _parse_key(self, v: HtmlElement) -> str:"]


@PY_LXML_CONVERTER(a.Value)
def pre_struct_value(node: a.Value, ctx: ConverterContext):
    ret_type = PY_TYPES.get(node.ret, "Any")

    if node.ret == VT.JSON:
        jsonify_node = [i for i in node.body if isinstance(i, a.Jsonify)][0]
        ret_type = ret_type.format(jsonify_node.schema_name)
        if jsonify_node.is_array:
            ret_type = f"List[{ret_type}]"
    elif node.ret == VT.NESTED:
        nested_node = [i for i in node.body if isinstance(i, a.Nested)][0]
        ret_type = ret_type.format(nested_node.struct_name)
        if nested_node.is_array:
            ret_type = f"List[{ret_type}]"

    return [f"    def _parse_value(self, v: HtmlElement) -> {ret_type}:"]


@PY_LXML_CONVERTER(a.PreValidate)
def pre_struct_pre_validate(node: a.PreValidate, ctx: ConverterContext):
    return ["    def _pre_validate(self, v: HtmlElement) -> None:"]


@PY_LXML_CONVERTER(a.SplitDoc)
def pre_struct_split_doc(node: a.SplitDoc, ctx: ConverterContext):
    return ["    def _split_doc(self, v: HtmlElement) -> List[HtmlElement]:"]


@PY_LXML_CONVERTER(a.TableConfig)
def pre_struct_table_config(node: a.TableConfig, ctx: ConverterContext):
    return ["    def _table_config(self, v: HtmlElement) -> HtmlElement:"]


@PY_LXML_CONVERTER(a.TableMatchKey)
def pre_struct_table_match_key(node: a.TableMatchKey, ctx: ConverterContext):
    return ["    def _table_match_key(self, v: HtmlElement) -> str:"]


@PY_LXML_CONVERTER(a.TableRow)
def pre_struct_table_row(node: a.TableRow, ctx: ConverterContext):
    return [
        "    def _parse_table_rows(self, v: HtmlElement) -> List[HtmlElement]:"
    ]


# SELECTORS - Main differences from bs4


@PY_LXML_CONVERTER(a.CssSelect)
def pre_expr_css_select(node: a.CssSelect, ctx: ConverterContext):
    if node.queries:
        lines: list[str] = []
        res_var = f"_res_{ctx.nxt}"
        for i, query in enumerate(node.queries):
            q = repr(query)
            if i == 0:
                lines.append(
                    f"{ctx.indent}{res_var} = {ctx.prv}.cssselect({q})"
                )
                lines.append(
                    f"{ctx.indent}{ctx.nxt} = {res_var}[0] if {res_var} else None"
                )
            else:
                lines.append(f"{ctx.indent}if {ctx.nxt} is None:")
                lines.append(
                    f"{ctx.indent}    {res_var} = {ctx.prv}.cssselect({q})"
                )
                lines.append(
                    f"{ctx.indent}    {ctx.nxt} = {res_var}[0] if {res_var} else None"
                )
        return lines
    query = repr(node.query)
    return f"{ctx.indent}{ctx.nxt} = {ctx.prv}.cssselect({query})[0]"


@PY_LXML_CONVERTER(a.CssSelectAll)
def pre_expr_css_select_all(node: a.CssSelectAll, ctx: ConverterContext):
    if node.queries:
        lines: list[str] = []
        for i, query in enumerate(node.queries):
            q = repr(query)
            if i == 0:
                lines.append(
                    f"{ctx.indent}{ctx.nxt} = {ctx.prv}.cssselect({q})"
                )
            else:
                lines.append(f"{ctx.indent}if not {ctx.nxt}:")
                lines.append(
                    f"{ctx.indent}    {ctx.nxt} = {ctx.prv}.cssselect({q})"
                )
        return lines
    query = repr(node.query)
    return f"{ctx.indent}{ctx.nxt} = {ctx.prv}.cssselect({query})"


@PY_LXML_CONVERTER(a.XpathSelect)
def pre_expr_xpath_select(node: a.XpathSelect, ctx: ConverterContext):
    if node.queries:
        lines: list[str] = []
        res_var = f"_res_{ctx.nxt}"
        for i, query in enumerate(node.queries):
            q = repr(query)
            if i == 0:
                lines.append(f"{ctx.indent}{res_var} = {ctx.prv}.xpath({q})")
                lines.append(
                    f"{ctx.indent}{ctx.nxt} = {res_var}[0] if {res_var} else None"
                )
            else:
                lines.append(f"{ctx.indent}if {ctx.nxt} is None:")
                lines.append(
                    f"{ctx.indent}    {res_var} = {ctx.prv}.xpath({q})"
                )
                lines.append(
                    f"{ctx.indent}    {ctx.nxt} = {res_var}[0] if {res_var} else None"
                )
        return lines
    query = repr(node.query)
    return f"{ctx.indent}{ctx.nxt} = {ctx.prv}.xpath({query})[0]"


@PY_LXML_CONVERTER(a.XpathSelectAll)
def pre_expr_xpath_select_all(node: a.XpathSelectAll, ctx: ConverterContext):
    if node.queries:
        lines: list[str] = []
        for i, query in enumerate(node.queries):
            q = repr(query)
            if i == 0:
                lines.append(f"{ctx.indent}{ctx.nxt} = {ctx.prv}.xpath({q})")
            else:
                lines.append(f"{ctx.indent}if not {ctx.nxt}:")
                lines.append(
                    f"{ctx.indent}    {ctx.nxt} = {ctx.prv}.xpath({q})"
                )
        return lines
    query = repr(node.query)
    return f"{ctx.indent}{ctx.nxt} = {ctx.prv}.xpath({query})"


@PY_LXML_CONVERTER(a.CssRemove)
def pre_expr_css_remove(node: a.CssRemove, ctx: ConverterContext):
    query = repr(node.query)
    return [
        f"{ctx.indent}[e.getparent().remove(e) for e in {ctx.prv}.cssselect({query}) if e.getparent() is not None]",
        f"{ctx.indent}{ctx.nxt} = {ctx.prv}",
    ]


@PY_LXML_CONVERTER(a.XpathRemove)
def pre_expr_xpath_remove(node: a.XpathRemove, ctx: ConverterContext):
    query = repr(node.query)
    return [
        f"{ctx.indent}[e.getparent().remove(e) for e in {ctx.prv}.xpath({query}) if e.getparent() is not None]",
        f"{ctx.indent}{ctx.nxt} = {ctx.prv}",
    ]


# EXTRACT - text, raw, attr


@PY_LXML_CONVERTER(a.Text)
def pre_expr_text(node: a.Text, ctx: ConverterContext):
    if node.accept == VT.DOCUMENT:
        return f"{ctx.indent}{ctx.nxt} = {ctx.prv}.text_content()"
    # LIST_DOCUMENT
    return f"{ctx.indent}{ctx.nxt} = [i.text_content() for i in {ctx.prv}]"


@PY_LXML_CONVERTER(a.Raw)
def pre_expr_raw(node: a.Raw, ctx: ConverterContext):
    if node.accept == VT.DOCUMENT:
        return f"{ctx.indent}{ctx.nxt} = html.tostring({ctx.prv}, encoding='unicode')"
    # LIST_DOCUMENT
    return f"{ctx.indent}{ctx.nxt} = [html.tostring(i, encoding='unicode') for i in {ctx.prv}]"


@PY_LXML_CONVERTER(a.Attr)
def pre_expr_attr(node: a.Attr, ctx: ConverterContext):
    keys = node.keys
    if node.accept == VT.DOCUMENT:
        if len(keys) == 1:
            return f"{ctx.indent}{ctx.nxt} = {ctx.prv}.get({keys[0]!r}, '')"
        # Multiple attributes: concatenate with space
        attrs = " + ' ' + ".join(f"{ctx.prv}.get({k!r}, '')" for k in keys)
        return f"{ctx.indent}{ctx.nxt} = {attrs}"
    # LIST_DOCUMENT
    if len(keys) == 1:
        return f"{ctx.indent}{ctx.nxt} = [i.get({keys[0]!r}, '') for i in {ctx.prv}]"
    # Multiple attributes
    attrs = " + ' ' + ".join(f"i.get({k!r}, '')" for k in keys)
    return f"{ctx.indent}{ctx.nxt} = [{attrs} for i in {ctx.prv}]"


# PREDICATES - CSS and XPath


@PY_LXML_CONVERTER(a.PredCss)
def pre_expr_pred_css(node: a.PredCss, ctx: ConverterContext):
    query = repr(node.query)
    cond = f"bool(i.cssselect({query}))"
    if ctx.index == 0:
        return ctx.indent + cond
    return ctx.indent + f"and {cond}"


@PY_LXML_CONVERTER(a.PredXpath)
def pre_expr_pred_xpath(node: a.PredXpath, ctx: ConverterContext):
    query = repr(node.query)
    cond = f"bool(i.xpath({query}))"
    if ctx.index == 0:
        return ctx.indent + cond
    return ctx.indent + f"and {cond}"


@PY_LXML_CONVERTER(a.PredHasAttr)
def pre_expr_pred_has_attr(node: a.PredHasAttr, ctx: ConverterContext):
    attrs = node.attrs
    if len(attrs) == 1:
        cond = f"{attrs[0]!r} in i.attrib"
    else:
        cond = f"any(attr in i.attrib for attr in {attrs!r})"
    if ctx.index == 0:
        return ctx.indent + cond
    return ctx.indent + f"and {cond}"


@PY_LXML_CONVERTER(a.PredAttrEq)
def pre_expr_pred_attr_eq(node: a.PredAttrEq, ctx: ConverterContext):
    name = node.name
    values = node.values
    if len(values) == 1:
        cond = f"i.get({name!r}, '') == {values[0]!r}"
    else:
        cond = f"i.get({name!r}, '') in {values!r}"
    if ctx.index == 0:
        return ctx.indent + cond
    return ctx.indent + f"and {cond}"


@PY_LXML_CONVERTER(a.PredAttrNe)
def pre_expr_pred_attr_ne(node: a.PredAttrNe, ctx: ConverterContext):
    name = node.name
    values = node.values
    if len(values) == 1:
        cond = f"i.get({name!r}, '') != {values[0]!r}"
    else:
        cond = f"i.get({name!r}, '') not in {values!r}"
    if ctx.index == 0:
        return ctx.indent + cond
    return ctx.indent + f"and {cond}"


@PY_LXML_CONVERTER(a.PredAttrStarts)
def pre_expr_pred_attr_starts(node: a.PredAttrStarts, ctx: ConverterContext):
    name = node.name
    values = node.values
    if len(values) == 1:
        cond = f"i.get({name!r}, '').startswith({values[0]!r})"
    else:
        cond = f"any(i.get({name!r}, '').startswith(v) for v in {values!r})"
    if ctx.index == 0:
        return ctx.indent + cond
    return ctx.indent + f"and {cond}"


@PY_LXML_CONVERTER(a.PredAttrEnds)
def pre_expr_pred_attr_ends(node: a.PredAttrEnds, ctx: ConverterContext):
    name = node.name
    values = node.values
    if len(values) == 1:
        cond = f"i.get({name!r}, '').endswith({values[0]!r})"
    else:
        cond = f"any(i.get({name!r}, '').endswith(v) for v in {values!r})"
    if ctx.index == 0:
        return ctx.indent + cond
    return ctx.indent + f"and {cond}"


@PY_LXML_CONVERTER(a.PredAttrContains)
def pre_expr_pred_attr_contains(
    node: a.PredAttrContains, ctx: ConverterContext
):
    name = node.name
    values = node.values
    if len(values) == 1:
        cond = f"{values[0]!r} in i.get({name!r}, '')"
    else:
        cond = f"any(v in i.get({name!r}, '') for v in {values!r})"
    if ctx.index == 0:
        return ctx.indent + cond
    return ctx.indent + f"and {cond}"


@PY_LXML_CONVERTER(a.PredAttrRe)
def pre_expr_pred_attr_re(node: a.PredAttrRe, ctx: ConverterContext):
    name = node.name
    pattern = repr(node.pattern)
    cond = f"bool(re.search({pattern}, i.get({name!r}, '')))"
    if ctx.index == 0:
        return ctx.indent + cond
    return ctx.indent + f"and {cond}"


@PY_LXML_CONVERTER(a.PredTextStarts)
def pre_expr_pred_text_starts(node: a.PredTextStarts, ctx: ConverterContext):
    values = node.values
    if len(values) == 1:
        cond = f"i.text_content().startswith({values[0]!r})"
    else:
        cond = f"any(i.text_content().startswith(v) for v in {values!r})"
    if ctx.index == 0:
        return ctx.indent + cond
    return ctx.indent + f"and {cond}"


@PY_LXML_CONVERTER(a.PredTextEnds)
def pre_expr_pred_text_ends(node: a.PredTextEnds, ctx: ConverterContext):
    values = node.values
    if len(values) == 1:
        cond = f"i.text_content().endswith({values[0]!r})"
    else:
        cond = f"any(i.text_content().endswith(v) for v in {values!r})"
    if ctx.index == 0:
        return ctx.indent + cond
    return ctx.indent + f"and {cond}"


@PY_LXML_CONVERTER(a.PredTextContains)
def pre_expr_pred_text_contains(
    node: a.PredTextContains, ctx: ConverterContext
):
    values = node.values
    if len(values) == 1:
        cond = f"{values[0]!r} in i.text_content()"
    else:
        cond = f"any(v in i.text_content() for v in {values!r})"
    if ctx.index == 0:
        return ctx.indent + cond
    return ctx.indent + f"and {cond}"


@PY_LXML_CONVERTER(a.PredTextRe)
def pre_expr_pred_text_re(node: a.PredTextRe, ctx: ConverterContext):
    pattern = repr(node.pattern)
    cond = f"bool(re.search({pattern}, i.text_content()))"
    if ctx.index == 0:
        return ctx.indent + cond
    return ctx.indent + f"and {cond}"
