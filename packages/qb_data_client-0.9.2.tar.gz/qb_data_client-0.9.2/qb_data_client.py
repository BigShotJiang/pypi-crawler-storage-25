from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Mapping, Optional

import getpass
import hashlib
import pandas as pd
import requests
import socket
import uuid


DEFAULT_ENDPOINT = "https:/data-api.qeubee.cn/sumscope/common/api/"


@dataclass
class QbDataClient:
    """
    债券市场查询客户端。

    - 通过 HTTP GET 调用服务端 API
    - 统一将结果转换为 pandas.DataFrame
    - 预留 access_key 能力（服务端暂未实现）
    """

    endpoint: str = DEFAULT_ENDPOINT
    access_key: Optional[str] = None
    timeout: int = 10
    user_id: str = field(init=False)
    _session: requests.Session = field(default_factory=requests.Session, init=False, repr=False)

    def __post_init__(self) -> None:
        self.user_id = self._build_user_id()

    def set_endpoint(self, endpoint: str) -> None:
        """设置服务端基础 endpoint，例如: http://host:port/sumscope/common/api/"""
        self.endpoint = endpoint.rstrip("/") + "/"

    def set_access_key(self, access_key: str) -> None:
        self.access_key = access_key

    # ---------- 内部通用方法 ----------

    def _build_url(self, api_name: str) -> str:
        return self.endpoint.rstrip("/") + f"/{api_name}"

    def _build_headers(self) -> Dict[str, str]:
        headers: Dict[str, str] = {}
        headers["User-Agent"]="QbDataClient/0.9.2"
        headers["X-User-Id"] = self.user_id
        if self.access_key:
            # 预留 access_key 透传方式，具体 header 名称可根据服务端实现调整
            headers["X-Access-Key"] = self.access_key
        return headers

    @staticmethod
    def _get_local_ip() -> str:
        try:
            return socket.gethostbyname(socket.gethostname()) or "unknown_ip"
        except Exception:
            return "unknown_ip"

    @staticmethod
    def _get_mac() -> str:
        try:
            return f"{uuid.getnode():012x}"
        except Exception:
            return "unknown_mac"

    @staticmethod
    def _get_username() -> str:
        try:
            return getpass.getuser() or "unknown_user"
        except Exception:
            return "unknown_user"

    def _build_user_id(self) -> str:
        raw = self._get_local_ip() + self._get_mac() + self._get_username()
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _request_json(self, api_name: str, params: Optional[Mapping[str, Any]] = None) -> Any:
        url = self._build_url(api_name)
        resp = self._session.get(url, params=params or {}, headers=self._build_headers(), timeout=self.timeout)
        resp.raise_for_status()
        return resp.json()

    @staticmethod
    def _to_dataframe(payload: Any) -> pd.DataFrame:
        """
        将常见 JSON 结构转换为 DataFrame：
        - 若为 list[dict]，直接构建 DataFrame
        - 若为 dict 且包含 'data' 字段，则对 data 递归转换
        - 其它结构尝试 DataFrame(payload)
        """
        if isinstance(payload, list):
            return pd.DataFrame(payload)
        if isinstance(payload, dict) and "data" in payload:
            data = payload["data"]
            if isinstance(data, list):
                return pd.DataFrame(data)
            return pd.json_normalize(data)
        try:
            return pd.DataFrame(payload)
        except Exception:
            return pd.DataFrame({"value": [payload]})

    def _get_df(self, api_name: str, params: Optional[Mapping[str, Any]] = None) -> pd.DataFrame:
        payload = self._request_json(api_name, params)
        return self._to_dataframe(payload)


    def top10_low_cdc_yield_municipal_bond(self) -> pd.DataFrame:
        return self._get_df("top10LowCdcYieldMunicipalBond")

    def top20_aa_corporate_bond_by_csi_valuation_yield(self) -> pd.DataFrame:
        return self._get_df("top20AaCorporateBondByCsiValuationYield")

    def get_cfets_valuation_yield_distribution_of_lgov_bond_within_3_years(self) -> pd.DataFrame:
        return self._get_df("getCfetsValuationYieldDistributionOfLgovBondWithin3Years")

    def list_top20_mtn_by_cbond_general_modified_duration(self) -> pd.DataFrame:
        return self._get_df("listTop20MtNByCbondGeneralModifiedDuration")

    def list_top10_urban_construct_bond_by_cbond_bpv(self) -> pd.DataFrame:
        return self._get_df("listTop10UrbanConstructBondByCbondBpv")

    def compare_valuation_yield_between_cbond_and_csi(self) -> pd.DataFrame:
        return self._get_df("compareValuationYieldBetweenCbondAndCsi")

    def list_top20_treasury_bond_by_cbond_convexity(self) -> pd.DataFrame:
        return self._get_df("listTop20TreasuryBondByCbondConvexity")

    def list_enterprise_bond_with_cfets_yield_gt_3_percent(self) -> pd.DataFrame:
        return self._get_df("listEnterpriseBondWithCfetsYieldGt3Percent")

    def list_top10_urban_construct_bond_by_cbond_spot_spread_yield(self) -> pd.DataFrame:
        return self._get_df("listTop10UrbanConstructBondByCbondSpotSpreadYield")

    def get_shcle_valuation_yield_curve_of_treasury_bond_within_1_year(self) -> pd.DataFrame:
        return self._get_df("getShcleValuationYieldCurveOfTreasuryBondWithin1Year")

    def list_bottom20_convertible_bond_by_current_yield(self) -> pd.DataFrame:
        return self._get_df("listBottom20ConvertibleBondByCurrentYield")

    def list_top10_lgov_bond_with_remaining_term_5_to_10_years_by_yield(self) -> pd.DataFrame:
        return self._get_df("listTop10LgovBondWithRemainingTerm5To10YearsByYield")

    def get_valuation_yield_distribution_of_abs_in_interbank_market(self) -> pd.DataFrame:
        return self._get_df("getValuationYieldDistributionOfAbsInInterbankMarket")

    def list_top10_aa_short_term_financing_bond_by_cbond_avg_settle_yield(self) -> pd.DataFrame:
        return self._get_df("listTop10AaShortTermFinancingBondByCbondAvgSettleYield")

    def get_corporate_bond_yield_curve_by_rating(self) -> pd.DataFrame:
        return self._get_df("getCorporateBondYieldCurveByRating")

    def get_municipal_bond_spread_analysis(self) -> pd.DataFrame:
        return self._get_df("getMunicipalBondSpreadAnalysis")

    def list_high_liquidity_treasury_bond(self) -> pd.DataFrame:
        return self._get_df("listHighLiquidityTreasuryBond")

    def get_ncd_issuance_scale_monthly(self) -> pd.DataFrame:
        return self._get_df("getNcdIssuanceScaleMonthly")

    def get_bond_index_performance(self) -> pd.DataFrame:
        return self._get_df("getBondIndexPerformance")

    def list_bond_with_rating_upgrade(self) -> pd.DataFrame:
        return self._get_df("listBondWithRatingUpgrade")

    def top_amount_ncd_weekly(self, top_n: int = 30, start_date: str = "", end_date: str = "") -> pd.DataFrame:
        params: Dict[str, Any] = {"topN": top_n}
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date
        return self._get_df("topAmountNcdWeekly", params)

    def top_change_rate_bond_yearly(self, top_n: int = 20) -> pd.DataFrame:
        return self._get_df("topChangeRateBondYearly", {"topN": top_n})

    def top_change_rate_sset_bond(self, start_date: str, end_date: str, top_n: int = 20) -> pd.DataFrame:
        params = {"start_date": start_date, "end_date": end_date, "topN": top_n}
        return self._get_df("topChangeRateSSETBond", params)

    def top_intraday_price_volatility_lgov_bond(self, top_n: int = 10) -> pd.DataFrame:
        return self._get_df("topIntradayPriceVolatilityLgovBond", {"topN": top_n})

    def top_price_range_aa_corporate_bond_weekly(self, top_n: int = 15) -> pd.DataFrame:
        return self._get_df("topPriceRangeAaCorporateBondWeekly", {"topN": top_n})

    def top_trade_count_broker_daily_bond(
        self,
        start_date: str,
        contributor_id: str,
        top_n: int = 20,
    ) -> pd.DataFrame:
        params = {
            "start_date": start_date,
            "contributor_id": contributor_id,
            "topN": top_n,
        }
        return self._get_df("topTradeCountBrokerDailyBond", params)

    def top_trade_count_convertible_bond_monthly(
        self,
        start_date: str,
        end_date: str,
        contributor_id: str,
        top_n: int = 30,
    ) -> pd.DataFrame:
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "contributor_id": contributor_id,
            "topN": top_n,
        }
        return self._get_df("topTradeCountConvertibleBondMonthly", params)

    def top_trade_municipal_bond(
        self,
        date: str,
        contributor_id: str,
        top_n: int = 20,
    ) -> pd.DataFrame:
        params = {
            "date": date,
            "contributor_id": contributor_id,
            "topN": top_n,
        }
        return self._get_df("topTradeMunicipalBond", params)

    def stock_5min_kline(self, sec_code_par: str, trade_dt: str) -> pd.DataFrame:
        """
        股票 5 分钟 K 线。
        sec_code_par 例如: 101800857.IB
        trade_dt 例如: 2024-05-20
        """
        params = {"sec_code_par": sec_code_par, "trade_dt": trade_dt}
        return self._get_df("stock5minKline", params)

    def bond_basic_info(self,ss_sec_code)  -> pd.DataFrame:
        params = {"ss_sec_code": ss_sec_code}
        return self._get_df("bondBasicInfo", params)

    def top_yield_prev_close_sset_bond(
        self,
        start_date: str,
        end_date: str,
        top_n: int = 20,
    ) -> pd.DataFrame:
        params = {
            "start_date": start_date,
            "end_date": end_date,
            "topN": top_n,
        }
        return self._get_df("topYieldPrevCloseSSETBond", params)


__all__ = ["QbDataClient", "DEFAULT_ENDPOINT"]

