# Qb Data Client (Python)

这是一个用于调用QB DATA API 的 Python 客户端，统一将返回结果转换为 `pandas.DataFrame`。完整 API 说明以贵司随项目分发的文档为准（例如仓库中的 `docs/api-docs.md`；PyPI 源码包未必包含该文件）。

## 环境准备

在 `python-client` 目录下安装依赖：

```bash
pip install qb-data-client
```

## 使用方式

```python
from qb_data_client import QbDataClient

client = QbDataClient()

# 设置认证信息
client.set_access_key("your-access-key")

df = client.top10_low_cdc_yield_municipal_bond()
print(df.head())
```

## contributor_id 说明

- 含义：交易所或经纪商缩写
- 多个经纪商：使用英文逗号（`,`）分隔，例如：`"UEDA,CFES"`

枚举值：

| contributor_id | 名称 |
|---|---|
| UEDA | 上田八木 |
| TPSH | 国利货币 |
| CNEX | 国际货币 |
| CCTB | 中诚保捷思 |
| TJXT | 天津信唐 |
| PATR | 平安利顺 |
| SSEC | 上海证券交易所 |
| SZEC | 深证证券交易所 |
| CFES | 外汇交易中心 |


