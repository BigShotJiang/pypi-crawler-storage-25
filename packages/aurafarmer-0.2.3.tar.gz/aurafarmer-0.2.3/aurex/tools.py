import subprocess
from pathlib import Path

# ── Tool schemas (OpenAI function-calling format) ──────────────────────────────
TOOL_DEFINITIONS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read the full contents of a file on disk.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to the file"}
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Create or overwrite a file with the given content.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path":    {"type": "string", "description": "Path to the file"},
                    "content": {"type": "string", "description": "Content to write"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": "Execute a shell command and return stdout + stderr.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Shell command to run"}
                },
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "List files and directories at a given path.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Directory path (default: .)"}
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search_files",
            "description": "Search for a text pattern inside files recursively.",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern":      {"type": "string", "description": "Text to search for"},
                    "path":         {"type": "string", "description": "Root directory (default: .)"},
                    "file_pattern": {"type": "string", "description": "Glob filter e.g. *.py"},
                },
                "required": ["pattern"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "delete_file",
            "description": "Delete a file from disk.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to the file to delete"}
                },
                "required": ["path"],
            },
        },
    },
]


# ── Implementations ────────────────────────────────────────────────────────────

def read_file(path: str) -> str:
    try:
        return Path(path).read_text(encoding="utf-8")
    except FileNotFoundError:
        return f"Error: '{path}' not found."
    except Exception as e:
        return f"Error reading file: {e}"


def write_file(path: str, content: str) -> str:
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"Wrote {len(content)} chars to '{path}'."
    except Exception as e:
        return f"Error writing file: {e}"


def run_command(command: str) -> str:
    try:
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True, timeout=60
        )
        out = result.stdout.strip()
        err = result.stderr.strip()
        parts = []
        if out:
            parts.append(out)
        if err:
            parts.append(f"[stderr]\n{err}")
        if not parts:
            parts.append(f"(exit code {result.returncode})")
        return "\n".join(parts)
    except subprocess.TimeoutExpired:
        return "Error: command timed out after 60 s."
    except Exception as e:
        return f"Error: {e}"


def list_files(path: str = ".") -> str:
    try:
        p = Path(path)
        lines = []
        for item in sorted(p.iterdir()):
            if item.is_dir():
                lines.append(f"  📁  {item.name}/")
            else:
                size = item.stat().st_size
                lines.append(f"  📄  {item.name}  ({size:,} B)")
        return "\n".join(lines) if lines else "(empty)"
    except Exception as e:
        return f"Error: {e}"


def search_files(pattern: str, path: str = ".", file_pattern: str = "*") -> str:
    cmd = f"grep -rn --include='{file_pattern}' '{pattern}' {path}"
    return run_command(cmd)


def delete_file(path: str) -> str:
    try:
        Path(path).unlink()
        return f"Deleted '{path}'."
    except FileNotFoundError:
        return f"Error: '{path}' not found."
    except Exception as e:
        return f"Error: {e}"


# ── Dispatcher ─────────────────────────────────────────────────────────────────

def execute_tool(name: str, args: dict) -> str:
    dispatch = {
        "read_file":    lambda a: read_file(a["path"]),
        "write_file":   lambda a: write_file(a["path"], a["content"]),
        "run_command":  lambda a: run_command(a["command"]),
        "list_files":   lambda a: list_files(a.get("path", ".")),
        "search_files": lambda a: search_files(
                            a["pattern"],
                            a.get("path", "."),
                            a.get("file_pattern", "*"),
                        ),
        "delete_file":  lambda a: delete_file(a["path"]),
    }
    fn = dispatch.get(name)
    if fn is None:
        return f"Unknown tool: {name}"
    try:
        return fn(args)
    except Exception as e:
        return f"Tool error: {e}"
