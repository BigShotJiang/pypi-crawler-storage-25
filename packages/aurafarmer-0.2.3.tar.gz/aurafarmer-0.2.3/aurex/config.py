import json
from pathlib import Path

API_KEYS = [
    "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",
    "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",
    "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",
    "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",
    "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",
]
API_KEY  = API_KEYS[0]
BASE_URL = "https://integrate.api.nvidia.com/v1"

MODELS: list[tuple[str, str]] = [
    ("Lunar-X2.8",             "moonshotai/kimi-k2.6"),
    ("Minex-3.8",              "mistralai/mistral-medium-3.5-128b"),
    ("Obsidian-O-3-reasoning", "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning"),
    ("Hydro-w9",               "deepseek-ai/deepseek-v4-flash"),
    ("Hydro-w10",              "deepseek-ai/deepseek-v4-pro"),
    ("Turbo-g6.5",             "z-ai/glm-5.1"),
    ("Turbo-g6",               "z-ai/glm-4.7"),
    ("Glazer-f16",             "minimaxai/minimax-m2.7"),
    ("Informer-x9",            "google/gemma-4-31b-it"),
    ("Minex-3.2",              "mistralai/mistral-small-4-119b-2603"),
    ("Obsidian-O-3-Better",    "nvidia/nemotron-3-super-120b-a12b"),
    ("Onyx-m6",                "qwen/qwen3.5-122b-a10b"),
    ("Onyx-m8",                "qwen/qwen3.5-397b-a17b"),
    ("Stalker-z2.8",           "stepfun-ai/step-3.5-flash"),
    ("Minex-2.8",              "mistralai/mistral-large-3-675b-instruct-2512"),
    ("Flagship-9",             "stockmark/stockmark-2-100b-instruct"),
    ("Onyx-m5-coder",          "qwen/qwen3-coder-480b-a35b-instruct"),
    ("Virus-O-8",              "openai/gpt-oss-120b"),
    ("Hybrid-l6",              "meta/llama-3.2-90b-vision-instruct"),
]

DEFAULT_DISPLAY = MODELS[0][0]
CONFIG_DIR      = Path.home() / ".aurex"
CONFIG_FILE     = CONFIG_DIR / "config.json"

def load_config() -> dict:
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {"model": DEFAULT_DISPLAY}

def save_config(cfg: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)

def get_model() -> str:
    return load_config().get("model", DEFAULT_DISPLAY)

def get_real_model() -> str:
    display = get_model()
    for fake, real in MODELS:
        if fake == display:
            return real
    return display

def set_model(display_name: str) -> None:
    cfg = load_config()
    cfg["model"] = display_name
    save_config(cfg)

def get_fast_mode() -> bool:
    return load_config().get("fast_mode", False)

def set_fast_mode(enabled: bool) -> None:
    cfg = load_config()
    cfg["fast_mode"] = enabled
    save_config(cfg)
