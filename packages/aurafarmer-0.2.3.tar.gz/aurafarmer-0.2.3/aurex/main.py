import os
import sys
from rich.console import Console
from rich.live import Live

from . import config, ui
from .agent import AurexAgent
from . import tools as tool_module

console = Console()

THINK_TAG    = "<think>"
THINK_INJECT = "\n\nThink carefully step by step before giving your final answer."

# ── Model command ──────────────────────────────────────────────────────────────
def handle_model_command(agent: AurexAgent) -> None:
    models  = config.MODELS
    current = config.get_model()
    ui.print_current_model(current)
    ui.print_model_list(models, current)

    try:
        choice = console.input("  [bold red]❯[/bold red] ").strip()
    except (KeyboardInterrupt, EOFError):
        return

    if not choice:
        ui.print_info(f"Keeping  aurex/{current}")
        return

    if choice.upper() == "C":
        try:
            custom = console.input("  [dim red]Custom model name →[/dim red] ").strip()
        except (KeyboardInterrupt, EOFError):
            return
        if custom:
            config.set_model(custom)
            ui.print_info(f"Model → aurex/{custom}")
    else:
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(models):
                fake, _ = models[idx]
                config.set_model(fake)
                console.print(f"\n  [dim]Model →[/dim] [bold red]aurex/{fake}[/bold red]\n")
            else:
                ui.print_error(f"Enter 1–{len(models)} or C.")
        except ValueError:
            ui.print_error("Invalid — enter a number or C.")

# ── Agent runner ───────────────────────────────────────────────────────────────
def run_agent(agent: AurexAgent, user_input: str) -> None:
    # Handle <think> tag
    think = THINK_TAG in user_input.lower()
    api_input = user_input.lower().replace(THINK_TAG, "").strip()
    # restore original casing without the tag
    api_input = user_input[:user_input.lower().find(THINK_TAG)].strip() if think else user_input
    if think:
        api_input += THINK_INJECT
        ui.show_thinking()

    full_text = ""
    stopped   = False

    spinner = ui.make_spinner()
    try:
        with Live(spinner, console=console, transient=True, refresh_per_second=15) as live:
            for event_type, data in agent.chat(api_input):

                if event_type == "text":
                    full_text += data
                    live.update(ui.make_spinner("writing..."))

                elif event_type == "tool_use":
                    live.update(ui.make_spinner(f"using {data['name']}..."))
                    ui.print_tool_use(live, data["name"], data["args"])

                elif event_type == "tool_res":
                    ui.print_tool_result(live, data["name"], data["result"])
                    live.update(spinner)

                elif event_type == "error":
                    live.console.print(f"\n  [bold red]✗[/bold red]  {data}\n")

    except KeyboardInterrupt:
        stopped = True
        console.print("\n  [dim red]⊘ stopped[/dim red]\n")

    if full_text and not stopped:
        ui.print_ai_response(full_text)
    elif full_text and stopped:
        # Still render whatever was collected before stop
        ui.print_ai_response(full_text)

# ── Main REPL ──────────────────────────────────────────────────────────────────
def main() -> None:
    os.system("clear" if os.name == "posix" else "cls")
    ui.print_banner()

    model = config.get_model()
    console.print(f"  [dim]Model  [bold red]aurex/{model}[/bold red][/dim]")
    console.print(f"  [dim]CWD    [bold red]{os.getcwd()}[/bold red][/dim]")
    console.print(f"  [dim]Type   [bold red]help[/bold red]  for all commands[/dim]")
    ui.print_separator()
    console.print()

    agent = AurexAgent()

    while True:
        try:
            user_input = console.input("[bold red]❯ [/bold red]").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[bold red]Goodbye.[/bold red]\n")
            sys.exit(0)

        if not user_input:
            continue

        cmd = user_input.lower().strip()

        if cmd in ("exit", "quit", "q"):
            console.print("\n[bold red]Goodbye.[/bold red]\n")
            sys.exit(0)
        elif cmd == "help":
            ui.print_help()
        elif cmd == "model":
            handle_model_command(agent)
        elif cmd == "clear":
            agent.clear_history()
            os.system("clear" if os.name == "posix" else "cls")
            ui.print_banner()
            ui.print_info("Conversation cleared.")
        elif cmd in ("files", "ls"):
            result = tool_module.list_files(".")
            console.print(f"\n  [dim red]{os.getcwd()}[/dim red]")
            console.print(result)
            console.print()
        else:
            run_agent(agent, user_input)

if __name__ == "__main__":
    main()
