import time
from rich.console import Console
from rich.live import Live
from rich.spinner import Spinner
from rich.rule import Rule
from rich.markdown import Markdown
from rich.panel import Panel

console = Console()

BANNER = """\
 █████╗ ██╗   ██╗██████╗ ███████╗██╗  ██╗
██╔══██╗██║   ██║██╔══██╗██╔════╝╚██╗██╔╝
███████║██║   ██║██████╔╝█████╗   ╚███╔╝ 
██╔══██║██║   ██║██╔══██╗██╔══╝   ██╔██╗ 
██║  ██║╚██████╔╝██║  ██║███████╗██╔╝ ██╗
╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝"""

TOOL_ICONS = {
    "read_file":    "📖",
    "write_file":   "✏️ ",
    "run_command":  "⚡",
    "list_files":   "📁",
    "search_files": "🔍",
    "delete_file":  "🗑️ ",
}

def print_banner() -> None:
    console.print(BANNER, style="bold red", justify="center")
    console.print("[dim]        AI Coding Agent[/dim]\n", justify="center")

def print_separator() -> None:
    console.print(Rule(style="dim red"))

def show_thinking() -> None:
    with Live(
        Spinner("dots2", text="[bold red]  deep thinking...[/bold red]"),
        console=console, transient=True, refresh_per_second=15,
    ):
        time.sleep(2.5)

def make_spinner(text="generating..."):
    return Spinner("dots2", text=f"[bold red]  ✦ Aurex[/bold red]  [dim red]{text}[/dim red]")

def print_ai_response(text: str) -> None:
    console.print()
    console.print(Rule("[bold red]  ✦ Aurex  [/bold red]", style="red"))
    console.print()
    console.print(Markdown(text))
    console.print()
    console.print(Rule(style="dim red"))
    console.print()

def print_tool_use(live, name: str, args: dict) -> None:
    icon = TOOL_ICONS.get(name, "🔧")
    live.console.print(f"\n  [bold red]{icon}  {name}[/bold red]")
    for k, v in args.items():
        val = str(v)
        if len(val) > 70:
            val = val[:70] + "…"
        live.console.print(f"     [dim red]{k}:[/dim red] {val}")
    live.console.print(Rule(style="dim red"))

def print_tool_result(live, name: str, result: str) -> None:
    MAX = 350
    display = result[:MAX] + (f"\n  … {len(result)-MAX} more chars" if len(result) > MAX else "")
    live.console.print(f"  [dim]{display}[/dim]")
    live.console.print()

def print_error(msg: str) -> None:
    console.print(f"\n  [bold red]✗[/bold red]  {msg}\n")

def print_info(msg: str) -> None:
    console.print(f"  [dim red]ℹ[/dim red]  {msg}")

def print_help() -> None:
    console.print()
    console.print(Rule("[bold red] Help [/bold red]", style="red"))
    console.print()

    sections = [
        ("Commands", [
            ("help",        "Show this"),
            ("model",       "Switch AI model"),
            ("clear",       "Wipe conversation history"),
            ("files / ls",  "List files in current folder"),
            ("exit / quit", "Quit Aurex"),
        ]),
        ("While AI is responding", [
            ("Ctrl+C",  "Stop the AI mid-response"),
        ]),
        ("Prompt tricks", [
            ("<think>",  "Append to prompt for deeper reasoning\n"
                         "               Example: fix this bug<think>"),
        ]),
        ("Model switching", [
            ("Type model", "Shows active model and numbered list"),
            ("Enter #",    "Pick a model by number"),
            ("Enter C",    "Type a fully custom model name"),
        ]),
    ]

    for title, rows in sections:
        console.print(f"  [bold red]{title}[/bold red]")
        for cmd, desc in rows:
            console.print(f"    [red]{cmd:<16}[/red] {desc}")
        console.print()

    console.print(Rule(style="dim red"))
    console.print()

def print_current_model(display: str) -> None:
    console.print(f"\n  Active  [bold red]aurex/{display}[/bold red]\n")

def print_model_list(models: list, current: str) -> None:
    console.print(Rule("[bold red] Models [/bold red]", style="red"))
    console.print()
    for i, (fake, _) in enumerate(models, 1):
        marker = "  [green]◀ active[/green]" if fake == current else ""
        console.print(f"  [dim red]{i:>2}[/dim red]  [white]aurex/{fake}[/white]{marker}")
    console.print()
    console.print("  [dim]Enter number  ·  C for custom  ·  Enter to keep[/dim]\n")
