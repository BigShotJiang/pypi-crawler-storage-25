# Aurex
Terminal AI Coding Agent powered by NVIDIA NIM.

## Install
```bash
pip install aurafarmer
```

## Run
```bash
aurex
```
