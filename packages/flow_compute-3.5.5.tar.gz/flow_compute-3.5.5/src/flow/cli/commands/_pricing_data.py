"""Shared data-fetch helpers for the pricing CLI command.

Extracted from ``pricing.py`` so Phase 2 (``flow pricing stats``) can reuse
them. These are Mithril-specific HTTP helpers; they fail closed by letting
HTTP and JSON errors bubble up to the caller for explicit handling.
"""

import json
import ssl
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib import request as urlreq
from urllib.parse import urlencode, urljoin

from flow.domain.parsers.instance_parser import extract_gpu_info
from flow.utils.parsing import parse_cost_string


def _resolve_api_context() -> tuple[str, str | None, str | None]:
    """Resolve Mithril API base URL, API key, and project from env/config."""
    import os

    api_base = os.getenv("MITHRIL_API_URL", "https://api.mithril.ai").rstrip("/") + "/"
    api_key = os.getenv("MITHRIL_API_KEY")
    project = os.getenv("MITHRIL_PROJECT_ID") or os.getenv("MITHRIL_PROJECT")

    if not api_key or not project:
        try:
            from flow.application.config.config import Config as _Cfg

            cfg = _Cfg.from_env(require_auth=False)
            if not api_key:
                api_key = cfg.auth_token or api_key
            if not project:
                project = (cfg.provider_config or {}).get("project") or project
            api_base = ((cfg.provider_config or {}).get("api_url") or api_base).rstrip("/") + "/"
        except Exception:  # noqa: BLE001
            pass

    return api_base, api_key, project


def _api_get_json(api_base: str, api_key: str | None, path: str, params: dict | None = None) -> Any:
    """HTTP GET against Mithril API, returns parsed JSON."""
    qs = f"?{urlencode(params)}" if params else ""
    url = urljoin(api_base, path.lstrip("/")) + qs
    headers: dict[str, str] = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    req = urlreq.Request(url, headers=headers, method="GET")
    ctx = ssl.create_default_context()
    with urlreq.urlopen(req, context=ctx, timeout=15) as resp:
        data = resp.read()
        return json.loads(data.decode("utf-8"))


def _fetch_instance_type_map(api_base: str, api_key: str | None) -> dict[str, tuple[str, int, str]]:
    """Fetch instance types. Returns {fid: (display_name, gpu_count, gpu_type)}."""
    result: dict[str, tuple[str, int, str]] = {}
    itypes = _api_get_json(api_base, api_key, "/v2/instance-types")
    if not isinstance(itypes, list):
        return result

    for it in itypes:
        try:
            fid = it.get("fid") or it.get("id")
            name = it.get("name") or fid
            gpu_count = 0
            gpu_type = ""

            # Try new format first
            if it.get("gpu_type"):
                gpu_type = extract_gpu_info(str(it["gpu_type"]))[0]
                gpu_count = int(it.get("num_gpus") or 0)

            # Fallback to legacy gpus array
            if not gpu_type:
                for g in it.get("gpus", []) or []:
                    try:
                        gpu_count += int(g.get("count", 0) or 0)
                        if not gpu_type:
                            detected = extract_gpu_info(str(g.get("name") or ""))[0]
                            if detected != "default":
                                gpu_type = detected
                    except Exception:  # noqa: BLE001
                        continue

            if not gpu_type:
                gpu_type = extract_gpu_info(str(name))[0]

            if fid:
                result[str(fid)] = (str(name), gpu_count or 0, gpu_type)
        except Exception:  # noqa: BLE001
            continue

    return result


def _fetch_price_history(
    api_base: str,
    api_key: str | None,
    fid_map: dict[str, tuple[str, int, str]],
    gpu_filter: str | None,
    region_filter: str | None,
    target_regions: list[str] | None = None,
) -> dict[tuple[str, str, int], dict[str, Any]]:
    """Fetch price history for ALL instance types, keyed by (gpu_type, region, gpu_count).

    Each GPU count tier is a distinct market with its own price dynamics
    (e.g., B200 1x $0.01-$14/GPU vs B200 8x $0.00-$112.50/GPU).
    Returns data for every available tier so callers can display per-config rows.

    Prices are normalized to per-GPU USD/hr.
    """
    # Include ALL FIDs (all GPU counts), not one per GPU type
    fid_to_gpu: dict[str, tuple[str, int]] = {}
    for fid, (_name, gpu_count, gpu_type) in fid_map.items():
        if gpu_filter and gpu_type != gpu_filter.lower():
            continue
        gc = gpu_count if gpu_count > 0 else 8
        fid_to_gpu[fid] = (gpu_type, gc)

    if not fid_to_gpu:
        return {}

    regions_to_query = target_regions or ([region_filter] if region_filter else [None])
    all_fids = ",".join(fid_to_gpu.keys())
    result: dict[tuple[str, str, int], dict[str, Any]] = {}

    # Request 14 days of history via start_time: 7d for the bid guide
    # (clipped via window_hours=168) plus 7d for week-over-week trends.
    start_time = (datetime.now(timezone.utc) - timedelta(days=14)).isoformat()

    for rgn in regions_to_query:
        params: dict[str, Any] = {
            "instance_types": all_fids,
            "num_samples": 1000,
            "start_time": start_time,
        }
        if rgn:
            params["region"] = rgn

        try:
            resp = _api_get_json(api_base, api_key, "/v2/pricing/history", params)
        except Exception:  # noqa: BLE001
            continue

        series_list = resp if isinstance(resp, list) else resp.get("series", [resp])

        for series in series_list:
            raw_prices = series.get("spot_prices", [])
            timestamps = series.get("timestamps", [])
            series_fid = series.get("instance_type") or series.get("instance_type_id", "")
            series_region = series.get("region") or rgn or ""

            if not raw_prices:
                continue

            # Forward-fill (LOCF)
            filled_prices: list[float] = []
            filled_timestamps: list[str] = []
            last_valid: float | None = None
            for p, t in zip(raw_prices, timestamps[: len(raw_prices)], strict=True):
                if p is not None:
                    parsed = parse_cost_string(p, default=-1.0)
                    if parsed > 0:
                        last_valid = parsed
                if last_valid is not None:
                    filled_prices.append(last_valid)
                    filled_timestamps.append(t if isinstance(t, str) else str(t))

            if not filled_prices:
                continue

            # Match series to GPU type via FID
            gpu_type, gpu_count = "", 8
            if series_fid and series_fid in fid_to_gpu:
                gpu_type, gpu_count = fid_to_gpu[series_fid]
            elif len(fid_to_gpu) == 1:
                gpu_type, gpu_count = next(iter(fid_to_gpu.values()))
            else:
                continue

            key = (gpu_type, series_region, gpu_count)
            if key not in result:
                per_gpu_prices = [p / gpu_count for p in filled_prices]
                result[key] = {
                    "spot_prices": per_gpu_prices,
                    "timestamps": filled_timestamps,
                    "gpu_count": gpu_count,
                }

    return result
