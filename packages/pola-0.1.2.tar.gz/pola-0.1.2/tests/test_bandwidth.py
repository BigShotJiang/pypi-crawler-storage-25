"""
Unit tests for bandwidth calculation functions.
"""

import numpy as np
import pytest
from scipy import integrate

from pola import (
    BimodalityStrength,
    ExcessMassResult,
    bimodality_strength,
    critical_bandwidth,
    detect_components,
    dip_test,
    excess_mass,
    find_modes,
    find_trough,
    gaussian_kde,
    silverman_bandwidth,
)
from pola.bandwidth import _trough_ratio, count_modes
from pola.benchmark import BENCHMARK_CASES


class TestSilvermanBandwidth:
    """Test Silverman's rule of thumb bandwidth calculation."""

    def test_normal_distribution(self):
        """Test bandwidth for standard normal distribution."""
        np.random.seed(42)
        x = np.random.normal(0, 1, 1000)
        h = silverman_bandwidth(x)

        # Should be close to optimal bandwidth for normal (≈ 0.26 for n=1000)
        assert 0.2 < h < 0.35

    def test_bimodal_distribution(self):
        """Test bandwidth for bimodal distribution."""
        np.random.seed(42)
        x1 = np.random.normal(-2, 0.5, 500)
        x2 = np.random.normal(2, 0.5, 500)
        x = np.concatenate([x1, x2])

        h = silverman_bandwidth(x)
        assert h > 0

    def test_single_point(self):
        """Test edge case with single data point."""
        x = np.array([5.0])
        h = silverman_bandwidth(x)
        assert np.isfinite(h)


class TestGaussianKDE:
    """Test Gaussian kernel density estimation."""

    def test_kde_values(self):
        """Test KDE returns valid probability density values."""
        np.random.seed(42)
        x = np.random.normal(0, 1, 100)
        grid = np.linspace(-3, 3, 100)
        h = 0.5

        kde_vals = gaussian_kde(x, grid, h)

        assert len(kde_vals) == len(grid)
        assert np.all(kde_vals >= 0)
        # Integral should be approximately 1
        integral = integrate.trapezoid(kde_vals, grid)
        assert 0.8 < integral < 1.2


class TestKernelSupport:
    """Test custom kernel parameter threading through the call chain."""

    def test_builtin_kernels(self):
        """All built-in kernels produce valid density estimates."""
        np.random.seed(42)
        x = np.random.normal(0, 1, 100)
        grid = np.linspace(-3, 3, 100)
        h = 0.5

        for kernel in ["gaussian", "epanechnikov", "uniform", "triangular"]:
            kde_vals = gaussian_kde(x, grid, h, kernel=kernel)
            assert len(kde_vals) == len(grid)
            assert np.all(kde_vals >= 0)
            integral = integrate.trapezoid(kde_vals, grid)
            assert 0.8 < integral < 1.2, f"Kernel '{kernel}' integral={integral:.3f}"

    def test_custom_callable_kernel(self):
        """A custom callable works as a kernel."""
        np.random.seed(42)
        x = np.random.normal(0, 1, 100)
        grid = np.linspace(-3, 3, 100)
        h = 0.5

        def custom_kernel(u):
            return np.exp(-(u**2) / 2) / np.sqrt(2 * np.pi)

        kde_vals = gaussian_kde(x, grid, h, kernel=custom_kernel)
        assert np.all(kde_vals >= 0)
        integral = integrate.trapezoid(kde_vals, grid)
        assert 0.8 < integral < 1.2

    def test_unknown_kernel_raises(self):
        """Unknown kernel name raises ValueError."""
        np.random.seed(42)
        x = np.random.normal(0, 1, 100)
        grid = np.linspace(-3, 3, 100)
        with pytest.raises(ValueError, match="Unknown kernel"):
            gaussian_kde(x, grid, 0.5, kernel="nonexistent")

    def test_kernel_threads_through_critical_bandwidth(self):
        """Kernel parameter threads through the full call chain."""
        np.random.seed(42)
        x = np.concatenate([np.random.normal(-2, 0.3, 200), np.random.normal(2, 0.3, 200)])

        # Default Gaussian should work
        h_crit, ok = critical_bandwidth(x)
        assert ok

        # Epanechnikov should also work (different h_crit expected)
        h_crit_ep, ok_ep = critical_bandwidth(x, kernel="epanechnikov")
        assert ok_ep
        assert 0 < h_crit_ep < 5.0

    def test_kernel_threads_through_find_trough(self):
        """Kernel parameter threads through find_trough."""
        np.random.seed(42)
        x = np.concatenate([np.random.normal(-2, 0.3, 200), np.random.normal(2, 0.3, 200)])
        h = 1.0

        trough = find_trough(x, h, kernel="epanechnikov")
        assert trough is not None
        assert -1 < trough < 1  # trough should be between the two modes


class TestCriticalBandwidth:
    """Test critical bandwidth detection algorithm."""

    def test_known_bimodal_case(self):
        """Test critical bandwidth for known bimodal distribution."""
        np.random.seed(42)
        # Create well-separated bimodal distribution
        x1 = np.random.normal(-2, 0.3, 200)
        x2 = np.random.normal(2, 0.3, 200)
        x = np.concatenate([x1, x2])

        h_crit, success = critical_bandwidth(x)

        assert success is True
        assert h_crit > 0.2
        assert h_crit < 2.0

    def test_unimodal_distribution(self):
        """Test critical bandwidth for already unimodal data."""
        np.random.seed(42)
        x = np.random.normal(0, 1, 500)

        h_crit, success = critical_bandwidth(x)

        # Should find a critical bandwidth for unimodal data
        assert success is True

    def test_boundary_cases(self):
        """Test boundary handling."""
        np.random.seed(42)
        x = np.concatenate([np.random.normal(-1, 0.2, 100), np.random.normal(1, 0.2, 100)])

        # Test with custom bounds
        h_crit, success = critical_bandwidth(x, h_min=0.01, h_max=2.0, tol=1e-4)
        assert success is True
        assert 0.7 < h_crit < 1.2


class TestGaussianKdeFFT:
    """Test FFT-accelerated KDE against direct method."""

    def test_fft_matches_direct_small(self):
        """FFT method should approximate direct for small data (binning error expected)."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 200)
        grid = np.linspace(-5, 5, 500)
        h = 0.5
        d_direct = gaussian_kde(x, grid, h)
        d_fft = gaussian_kde(x, grid, h, use_fft=True)
        # Small-n binning introduces error; verify approximate match
        assert np.allclose(d_direct, d_fft, rtol=0.15, atol=1e-4)
        # FFT integral should still be ~1
        assert abs(np.trapezoid(d_fft, grid) - 1.0) < 0.05

    def test_fft_matches_direct_large(self):
        """FFT should match direct for large data (n > auto-switch threshold)."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 10000)
        grid = np.linspace(-5, 5, 1000)
        h = 0.5
        d_direct = gaussian_kde(x, grid, h)
        d_fft = gaussian_kde(x, grid, h, use_fft=True)
        assert np.allclose(d_direct, d_fft, rtol=0.005, atol=1e-4)

    def test_fft_integral(self):
        """FFT KDE should integrate to approximately 1."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 10000)
        grid = np.linspace(-5, 5, 2000)
        h = 0.5
        d = gaussian_kde(x, grid, h, use_fft=True)
        integral = np.trapezoid(d, grid)
        assert abs(integral - 1.0) < 0.01

    def test_fft_kernel_options(self):
        """FFT should work with all built-in kernels (large n)."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 10000)
        grid = np.linspace(-5, 5, 500)
        h = 0.5
        for k in ["gaussian", "epanechnikov", "uniform", "triangular"]:
            d_direct = gaussian_kde(x, grid, h, kernel=k)
            d_fft = gaussian_kde(x, grid, h, kernel=k, use_fft=True)
            assert np.allclose(d_direct, d_fft, rtol=0.02, atol=1e-4), f"Kernel {k} failed"

    def test_fft_auto_switch_small(self):
        """Auto mode (use_fft=None) should use direct for small n."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 200)
        grid = np.linspace(-5, 5, 500)
        h = 0.5
        d_auto = gaussian_kde(x, grid, h)  # use_fft=None, n<5000 → direct
        d_direct = gaussian_kde(x, grid, h, use_fft=False)
        # Should be bit-identical since both use direct
        assert np.array_equal(d_auto, d_direct)

    def test_fft_benchmark_cases(self):
        """FFT should produce valid KDE on benchmark data (binning error on n~200 data)."""
        from pola.benchmark import BENCHMARK_CASES

        for name, case in BENCHMARK_CASES.items():
            x = case.generator(42)
            grid = np.linspace(x.min() - 3, x.max() + 3, 500)
            h = case.h_crit_expected
            d_direct = gaussian_kde(x, grid, h)
            d_fft = gaussian_kde(x, grid, h, use_fft=True)
            # Moderate tolerance; benchmark data has n=200-600, binning error is ~5-10%
            assert np.allclose(d_direct, d_fft, rtol=0.12, atol=1e-4), f"{name} failed"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])


class TestInputValidation:
    """Test input validation guards."""

    def test_nan_values(self):
        x = np.array([1.0, np.nan, 3.0])
        with pytest.raises(ValueError, match="NaN|infinite"):
            silverman_bandwidth(x)

    def test_inf_values(self):
        x = np.array([1.0, np.inf, 3.0])
        with pytest.raises(ValueError, match="NaN|infinite"):
            silverman_bandwidth(x)

    def test_negative_inf_values(self):
        x = np.array([1.0, -np.inf, 3.0])
        with pytest.raises(ValueError, match="NaN|infinite"):
            silverman_bandwidth(x)

    def test_empty_array(self):
        with pytest.raises(ValueError, match="empty"):
            silverman_bandwidth(np.array([]))

    def test_2d_input(self):
        x = np.array([[1.0, 2.0], [3.0, 4.0]])
        with pytest.raises(ValueError, match="1-dimensional"):
            silverman_bandwidth(x)

    def test_validation_affects_all_functions(self):
        x = np.array([1.0, np.nan])
        with pytest.raises(ValueError):
            gaussian_kde(x, np.array([0.0]), 0.5)
        with pytest.raises(ValueError):
            critical_bandwidth(x)

    def test_critical_bandwidth_empty(self):
        with pytest.raises(ValueError, match="empty"):
            critical_bandwidth(np.array([]))


class TestConstantData:
    """Test behavior with constant (zero-variance) data."""

    def test_silverman_constant(self):
        x = np.ones(10)
        h = silverman_bandwidth(x)
        assert h == 0.01  # floored minimum

    def test_critical_bandwidth_constant(self):
        x = np.ones(10)
        h_crit, success = critical_bandwidth(x)
        assert success is False  # already unimodal at min bandwidth
        assert np.isfinite(h_crit)

    def test_count_modes_zero_bandwidth(self):
        x = np.random.normal(0, 1, 100)
        modes = count_modes(x, h=0.0)
        assert modes == 0  # zero bandwidth → no modes (h<=0 returns 0)

    def test_count_modes_negative_bandwidth(self):
        x = np.random.normal(0, 1, 100)
        modes = count_modes(x, h=-1.0)
        assert modes == 0


class TestStability:
    """Test numerical stability and determinism."""

    def test_deterministic(self):
        x = np.array([-2.1, -1.8, -1.7, 1.8, 2.0, 2.2])
        h1, _ = critical_bandwidth(x, tol=1e-4, max_iter=50)
        h2, _ = critical_bandwidth(x, tol=1e-4, max_iter=50)
        assert h1 == pytest.approx(h2)

    def test_small_perturbation(self):
        np.random.seed(42)
        x = np.concatenate(
            [
                np.random.normal(-2, 0.3, 200),
                np.random.normal(2, 0.3, 200),
            ]
        )
        h1, _ = critical_bandwidth(x)
        x_noisy = x + np.random.normal(0, 1e-6, len(x))
        h2, _ = critical_bandwidth(x_noisy)
        assert abs(h1 - h2) < 0.1

    def test_tolerance_does_not_harm_convergence(self):
        np.random.seed(42)
        x = np.concatenate(
            [
                np.random.normal(-2, 0.3, 200),
                np.random.normal(2, 0.3, 200),
            ]
        )
        h_coarse, s1 = critical_bandwidth(x, tol=1e-2)
        h_fine, s2 = critical_bandwidth(x, tol=1e-6)
        assert s1 is True and s2 is True
        # Both should converge to a reasonable range
        assert 0.5 < h_coarse < 2.0
        assert 0.5 < h_fine < 2.0


class TestGaussianKdeVectorized:
    """Test that vectorized KDE matches the original loop implementation."""

    def test_matches_loop_reference(self):
        np.random.seed(42)
        x = np.random.normal(0, 1, 100)
        grid = np.linspace(-3, 3, 200)
        h = 0.5

        result = gaussian_kde(x, grid, h)

        # Reference: explicit loop (same formula as original implementation)
        expected = np.array(
            [
                np.sum(np.exp(-((xi - x) ** 2) / (2 * h**2))) / (len(x) * h * np.sqrt(2 * np.pi))
                for xi in grid
            ]
        )
        np.testing.assert_array_almost_equal(result, expected)

    def test_small_dataset(self):
        x = np.array([1.0, 2.0, 3.0])
        grid = np.linspace(0, 4, 10)
        h = 0.5
        result = gaussian_kde(x, grid, h)
        assert len(result) == len(grid)
        assert np.all(result >= 0)

    def test_large_grid(self):
        np.random.seed(42)
        x = np.random.normal(0, 1, 50)
        grid = np.linspace(-4, 4, 10000)
        h = 0.5
        result = gaussian_kde(x, grid, h)
        integral = np.trapezoid(result, grid)
        assert 0.8 < integral < 1.2


class TestTroughRatio:
    """Test _trough_ratio continuous bimodality measure."""

    def test_trough_ratio_monotonic(self):
        """Verify _trough_ratio increases monotonically with h."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        h_values = np.linspace(0.5, 3.0, 10)
        ratios = [_trough_ratio(x, h) for h in h_values]
        assert all(ratios[i] <= ratios[i + 1] + 1e-10 for i in range(len(ratios) - 1))

    def test_objective_sign_change(self):
        """Verify f(h_min) < 0 < f(h_max) for bimodal data."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        h_min = silverman_bandwidth(x) / 20
        h_max = silverman_bandwidth(x) * 10
        f_min = _trough_ratio(x, h_min) - 0.5
        f_max = _trough_ratio(x, h_max) - 0.5
        assert f_min < 0 < f_max

    def test_trough_ratio_small_h(self):
        """Very small h should produce near-zero trough ratio for bimodal data."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        ratio = _trough_ratio(x, h=0.01)
        assert ratio < 0.3

    def test_trough_ratio_large_h(self):
        """Very large h should produce near-1 trough ratio."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        ratio = _trough_ratio(x, h=10.0)
        assert ratio > 0.5

    def test_trough_ratio_unimodal(self):
        """Unimodal data should return 1.0."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 500)
        ratio = _trough_ratio(x, silverman_bandwidth(x))
        assert ratio == 1.0

    def test_trough_ratio_zero_h(self):
        """h <= 0 should return 1.0."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        assert _trough_ratio(x, 0.0) == 1.0
        assert _trough_ratio(x, -1.0) == 1.0


class TestCriticalBandwidthHybrid:
    """Test the upgraded critical_bandwidth with method parameter."""

    def test_auto_matches_binary(self):
        """Verify auto (hybrid) result matches binary."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        h_binary, ok1 = critical_bandwidth(x, method="binary", tol=1e-8)
        h_auto, ok2 = critical_bandwidth(x, method="auto", tol=1e-8)
        assert ok1 and ok2
        assert abs(h_binary - h_auto) < 0.05

    @pytest.mark.parametrize("case_name", list(BENCHMARK_CASES.keys()))
    def test_benchmark_reference(self, case_name):
        """Verify critical bandwidth matches expected benchmark values."""
        case = BENCHMARK_CASES[case_name]
        x = case.generator(42)
        h_crit, ok = critical_bandwidth(x, method="binary", tol=1e-8, max_iter=500)
        assert ok, f"{case_name}: did not converge"
        assert abs(h_crit - case.h_crit_expected) < case.h_crit_tolerance, (
            f"{case_name}: {case.h_crit_expected}±{case.h_crit_tolerance}, got {h_crit:.6f}"
        )

    def test_backward_compatibility(self):
        """Verify critical_bandwidth works without method parameter."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        h, ok = critical_bandwidth(x)
        assert ok
        assert h > 0

    def test_method_binary_no_method_param(self):
        """Explicit method='binary' matches default behavior."""
        np.random.seed(42)
        x = np.concatenate(
            [
                np.random.normal(-2, 0.3, 200),
                np.random.normal(2, 0.3, 200),
            ]
        )
        h_default, _ = critical_bandwidth(x)
        h_binary, _ = critical_bandwidth(x, method="binary")
        assert h_default == pytest.approx(h_binary, rel=0.01)

    def test_auto_constant_data_no_crash(self):
        """Auto method should handle constant data without crashing."""
        # Use constant data
        x = np.ones(10) * 5.0
        h, ok = critical_bandwidth(x, method="auto")
        assert np.isfinite(h)
        # ok may be False (already unimodal) but shouldn't crash


class TestBrentSolver:
    """Test the Brent's method solver for critical bandwidth."""

    @pytest.mark.parametrize("case_name", list(BENCHMARK_CASES.keys()))
    def test_brent_matches_binary(self, case_name):
        """Brent method matches binary reference on every benchmark case."""
        case = BENCHMARK_CASES[case_name]
        x = case.generator(42)
        h_bin, ok1 = critical_bandwidth(x, method="binary", tol=1e-8, max_iter=500)
        h_brn, ok2 = critical_bandwidth(x, method="brent", tol=1e-8, max_iter=100)
        assert ok1, f"{case_name}: binary did not converge"
        assert ok2, f"{case_name}: brent did not converge"
        assert abs(h_bin - h_brn) < max(case.h_crit_tolerance, 0.02), (
            f"{case_name}: binary={h_bin:.6f}, brent={h_brn:.6f}"
        )

    @pytest.mark.parametrize("case_name", list(BENCHMARK_CASES.keys()))
    def test_brent_verifies_result(self, case_name):
        """Brent's result is verified: at h_crit, KDE has 1 mode."""
        case = BENCHMARK_CASES[case_name]
        x = case.generator(42)
        h_crit, ok = critical_bandwidth(x, method="brent", tol=1e-8, max_iter=100)
        assert ok, f"{case_name}: brent did not converge"
        from pola.bandwidth import count_modes

        assert count_modes(x, h_crit) == 1, (
            f"{case_name}: h_crit={h_crit:.6f} has {count_modes(x, h_crit)} modes"
        )

    def test_brent_objective_sign_change(self):
        """_brent_objective returns positive at h_min, negative at h_max."""
        from pola.bandwidth import _brent_objective, silverman_bandwidth

        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        h_min = silverman_bandwidth(x) / 20.0
        h_max = silverman_bandwidth(x) * 10.0
        f_min = _brent_objective(h_min, x)
        f_max = _brent_objective(h_max, x)
        assert f_min > 0, f"f(h_min={h_min:.6f}) = {f_min:.6f} should be positive"
        assert f_max < 0, f"f(h_max={h_max:.6f}) = {f_max:.6f} should be negative"

    def test_brent_objective_zero_h(self):
        """h <= 0 returns positive (bimodal forcing)."""
        from pola.bandwidth import _brent_objective

        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        assert _brent_objective(0.0, x) > 0
        assert _brent_objective(-1.0, x) > 0

    def test_brent_objective_unimodal_data(self):
        """Unimodal data returns negative at all bandwidths."""
        from pola.bandwidth import _brent_objective, silverman_bandwidth

        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 500)
        h = silverman_bandwidth(x)
        assert _brent_objective(h, x) < 0

    def test_brent_constant_data_fallback(self):
        """Constant data falls back gracefully (unimodal at min bandwidth)."""
        x = np.ones(10) * 5.0
        h, ok = critical_bandwidth(x, method="brent")
        assert np.isfinite(h)
        # ok may be False (already unimodal at h_min) but shouldn't crash

    def test_brent_uses_kernel(self):
        """Brent method respects kernel parameter."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        h_gauss, ok1 = critical_bandwidth(x, method="brent", kernel="gaussian")
        h_ep, ok2 = critical_bandwidth(x, method="brent", kernel="epanechnikov")
        assert ok1 and ok2
        # Different kernels should give different results
        assert abs(h_gauss - h_ep) > 1e-6

    def test_brent_deterministic(self):
        """Brent method is deterministic on same data."""
        x = np.array([-2.1, -1.8, -1.7, 1.8, 2.0, 2.2])
        h1, _ = critical_bandwidth(x, method="brent", tol=1e-8, max_iter=100)
        h2, _ = critical_bandwidth(x, method="brent", tol=1e-8, max_iter=100)
        assert h1 == pytest.approx(h2)

    def test_brent_custom_bounds(self):
        """Brent method works with custom bounds."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        h, ok = critical_bandwidth(x, method="brent", h_min=0.1, h_max=5.0)
        assert ok
        assert 0.5 < h < 3.0

    def test_auto_selects_brent_when_appropriate(self):
        """Auto method selects Brent for well-separated large samples, binary for small samples."""
        from pola.bandwidth import _trough_ratio, silverman_bandwidth

        # Well-separated large sample (n=400): auto should converge via Brent
        x_large = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        h_large, ok_large = critical_bandwidth(x_large, method="auto", tol=1e-8, max_iter=500)
        assert ok_large, "auto did not converge on well-separated large sample"
        # Verify h_crit matches binary reference
        h_bin, ok_bin = critical_bandwidth(x_large, method="binary", tol=1e-8, max_iter=500)
        assert ok_bin
        assert abs(h_large - h_bin) < 0.02, f"auto={h_large:.6f} differs from binary={h_bin:.6f}"

        # Small sample (n=60): auto should use binary (safe fallback)
        x_small = BENCHMARK_CASES["small_sample_bimodal"].generator(42)
        h_small, ok_small = critical_bandwidth(x_small, method="auto", tol=1e-8, max_iter=500)
        assert ok_small, "auto did not converge on small sample"
        # Verify h_crit matches binary reference
        h_bin_small, ok_bin_small = critical_bandwidth(
            x_small, method="binary", tol=1e-8, max_iter=500
        )
        assert ok_bin_small
        assert abs(h_small - h_bin_small) < 0.02, (
            f"auto={h_small:.6f} differs from binary={h_bin_small:.6f} on small sample"
        )

        # Verify the diagnostic: trough ratio should be low for well-separated data
        h_min = silverman_bandwidth(x_large) / 20.0
        tr = _trough_ratio(x_large, h_min)
        assert tr < 0.7, f"Expected deep trough (tr<0.7), got tr={tr:.4f}"
        # For small sample, n<100 triggers binary regardless of trough ratio
        assert len(x_small) < 100, "small_sample_bimodal should have n<100"


class TestFindTrough:
    """Test find_trough function."""

    def test_find_trough_between_modes(self):
        """Trough should be between the two component means for symmetric mixture."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        h_crit, ok = critical_bandwidth(x)
        assert ok
        # Use slightly smaller bandwidth to ensure bimodality
        trough = find_trough(x, h_crit * 0.9)
        assert trough is not None
        # Trough should be near 0 (midpoint between -2 and 2)
        assert -0.5 < trough < 0.5

    def test_find_trough_unimodal(self):
        """Unimodal data should return None."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 500)
        trough = find_trough(x, silverman_bandwidth(x) * 2)
        assert trough is None

    def test_find_trough_refinement(self):
        """Both grid and refined trough should find a result with bimodal bandwidth."""
        rng = np.random.default_rng(42)
        x = np.concatenate([rng.normal(-2, 0.3, 200), rng.normal(2, 0.3, 200)])
        h_crit, _ = critical_bandwidth(x)
        # Use slightly smaller bandwidth to ensure bimodality
        trough_refined = find_trough(x, h_crit * 0.9, refine=True)
        trough_grid = find_trough(x, h_crit * 0.9, refine=False)
        assert trough_refined is not None
        assert trough_grid is not None

    def test_find_trough_zero_h(self):
        """h <= 0 should return None."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        assert find_trough(x, 0.0) is None
        assert find_trough(x, -1.0) is None

    def test_find_trough_multiple_modes(self):
        """Trimodal data should find a trough — may be between dominant peaks."""
        x = BENCHMARK_CASES["trimodal"].generator(42)
        h_crit, ok = critical_bandwidth(x)
        assert ok
        # Use slightly smaller bandwidth to ensure bimodality at critical region
        trough = find_trough(x, h_crit * 0.95)
        if trough is not None:
            # Trough between the two most prominent peaks
            assert isinstance(trough, float)
            assert np.isfinite(trough)


class TestDetectComponents:
    """Test bimodal component detection."""

    def check_means(self, result, expected_1, expected_2, tol=0.5):
        """Helper: verify component means match expected values."""
        assert abs(result.component1.mean - expected_1) < tol, (
            f"Expected mean1 ≈ {expected_1}, got {result.component1.mean:.3f}"
        )
        assert abs(result.component2.mean - expected_2) < tol, (
            f"Expected mean2 ≈ {expected_2}, got {result.component2.mean:.3f}"
        )

    def check_weight_sum(self, result):
        """Helper: verify weights sum to ~1."""
        assert abs(result.component1.weight + result.component2.weight - 1.0) < 0.01

    def test_well_separated(self):
        """Well-separated symmetric case: means near -2 and +2."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        result = detect_components(x)
        self.check_means(result, -2.0, 2.0, tol=0.4)
        self.check_weight_sum(result)
        assert result.component1.mean < result.component2.mean
        assert result.dip_ratio < 1.0  # some trough exists
        assert result.dip_ratio > 0.0
        assert result.critical_bandwidth > 0

    def test_moderate_separation(self):
        """Moderate separation: means near -1 and +1.5."""
        x = BENCHMARK_CASES["moderate_separation"].generator(42)
        result = detect_components(x)
        self.check_means(result, -1.0, 1.5, tol=0.5)
        self.check_weight_sum(result)

    def test_unequal_variance(self):
        """Unequal variance: left wider (σ=0.6) than right (σ=0.2)."""
        x = BENCHMARK_CASES["unequal_variance"].generator(42)
        result = detect_components(x)
        assert result.component2.std < result.component1.std, (
            "Right (tight) component should have smaller std"
        )
        self.check_weight_sum(result)

    def test_unequal_weights(self):
        """Unequal weights: left 100, right 400 → weight ratio ~1:4."""
        x = BENCHMARK_CASES["unequal_weights"].generator(42)
        result = detect_components(x)
        # Right component has ~4x the data
        assert result.component2.weight > result.component1.weight, (
            "Right component should have larger weight"
        )
        # Weight ratio should be approximately 100:400 = 0.2:0.8
        weight_ratio = result.component2.weight / result.component1.weight
        assert 2.0 < weight_ratio < 6.0, (
            f"Weight ratio {weight_ratio:.2f} outside expected range [2, 6]"
        )
        self.check_weight_sum(result)

    def test_components_ordered(self):
        """Component 1 always has lower mean than component 2."""
        x = BENCHMARK_CASES["extreme_separation"].generator(42)
        result = detect_components(x)
        assert result.component1.mean < result.component2.mean
        # Verify peak locations match
        assert result.separation_point > result.component1.mean
        assert result.separation_point < result.component2.mean

    def test_not_bimodal_raises(self):
        """Unimodal data should raise ValueError."""
        x = np.array([0.0])
        with pytest.raises(ValueError, match="not appear bimodal"):
            detect_components(x)

    def test_constant_data_raises(self):
        """Constant data should raise ValueError (single peak)."""
        x = np.ones(20)
        with pytest.raises(ValueError, match="not appear bimodal|empty component"):
            detect_components(x)

    def test_std_positive(self):
        """Component standard deviations should be positive."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        result = detect_components(x)
        assert result.component1.std > 0
        assert result.component2.std > 0

    def test_varying_h_factor(self):
        """Different h_factor values should produce similar results."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        r1 = detect_components(x, h_factor=0.80)
        r2 = detect_components(x, h_factor=0.90)
        # Both should detect means near -2 and +2
        assert abs(r1.component1.mean - r2.component1.mean) < 0.3
        assert abs(r1.component2.mean - r2.component2.mean) < 0.3


class TestBenchmarkStability:
    """Test benchmark reference values across multiple random seeds."""

    @pytest.mark.parametrize("case_name", list(BENCHMARK_CASES.keys()))
    def test_benchmark_stability(self, case_name):
        """Verify h_crit is stable across random seeds, within 2*std of
        the reference seed (seed=42) value. This provides independent
        validation that reference values are representative, not circular.
        """
        case = BENCHMARK_CASES[case_name]
        seeds = [42, 123, 456, 789, 101112, 131415, 161718, 192021, 222324, 252627]
        h_values = []
        for seed in seeds:
            x = case.generator(seed)
            h, ok = critical_bandwidth(x, method="binary", tol=1e-8, max_iter=500)
            assert ok, f"{case_name} seed={seed}: did not converge"
            h_values.append(h)

        h_arr = np.array(h_values)
        h_ref = h_arr[0]  # seed=42 is the reference
        mean = np.mean(h_arr)
        std = np.std(h_arr, ddof=1)

        # The reference value (seed=42) should be within 3 std of the mean
        assert abs(h_ref - mean) < 3 * std + 1e-10, (
            f"{case_name}: ref={h_ref:.4f}, mean={mean:.4f}±{std:.4f} "
            f"(seed=42 deviates {abs(h_ref - mean) / std:.2f}σ)"
        )

        # The expected benchmark value should be within 3 std of the multi-seed mean
        assert abs(case.h_crit_expected - mean) < 3 * std + case.h_crit_tolerance, (
            f"{case_name}: expected={case.h_crit_expected:.4f}, "
            f"mean={mean:.4f}±{std:.4f} across {len(seeds)} seeds"
        )


class TestKdeGridPoints:
    """Test adaptive KDE grid point calculation."""

    def test_small_h_fine_grid(self):
        """Small h relative to range should produce fine grid."""
        from pola.bandwidth import _kde_grid_points

        result = _kde_grid_points(100, h=0.01, data_range=10)
        # base=200, ratio=250, scale=3.0, points=600
        assert result == 600, f"Expected 600, got {result}"

    def test_large_h_coarse_grid(self):
        """Large h relative to range should produce coarse grid (near min_grid)."""
        from pola.bandwidth import _kde_grid_points

        result = _kde_grid_points(100, h=10.0, data_range=10)
        # base=200, ratio=0.25, scale=0.5, points=100 → clamped to 200
        assert result == 200, f"Expected 200 (min_grid), got {result}"

    def test_no_h_backward_compatible(self):
        """Without h param, should return original n//10 clamped."""
        from pola.bandwidth import _kde_grid_points

        assert _kde_grid_points(100) == 200  # min_grid
        assert _kde_grid_points(5000) == 500  # 5000//10 = 500
        assert _kde_grid_points(500) == 200  # 500//10 = 50 < 200
        assert _kde_grid_points(3000) == 300  # 3000//10 = 300

    def test_large_h_coarse_big_n(self):
        """Large h with large n should reduce grid below size-derived value."""
        from pola.bandwidth import _kde_grid_points

        result = _kde_grid_points(5000, h=10.0, data_range=10)
        # base=500, ratio=0.25, scale=0.5, points=250
        assert result == 250, f"Expected 250, got {result}"

    def test_small_h_fine_big_n(self):
        """Small h with big n should hit max_grid."""
        from pola.bandwidth import _kde_grid_points

        result = _kde_grid_points(5000, h=0.01, data_range=10)
        # base=500, ratio=250, scale=3.0, points=1500 → auto_max=2500, clamped to 1500
        assert result == 1500, f"Expected 1500 (auto-scaled max), got {result}"

    def test_max_grid_auto_scale(self):
        """Auto max_grid scales with n."""
        from pola.bandwidth import _kde_grid_points

        # n=1000: max_grid should be 800
        assert _kde_grid_points(1000) <= 800
        # n=10000: max_grid should be up to 5000
        result = _kde_grid_points(10000, h=0.01, data_range=10)
        assert result > 800, f"Expected >800 for n=10000, got {result}"
        # n=20000: cap at 5000
        result2 = _kde_grid_points(20000, h=0.01, data_range=10)
        assert result2 <= 5000
        assert result2 >= 2000, f"Expected >=2000 for n=20000, got {result2}"

    def test_max_grid_explicit_override(self):
        """Explicit max_grid overrides auto."""
        from pola.bandwidth import _kde_grid_points

        result = _kde_grid_points(10000, max_grid=1000)
        assert result <= 1000

    def test_auto_max_clamping(self):
        """Auto max_grid should not exceed limits."""
        from pola.bandwidth import _kde_grid_points

        # n=1: min_grid=200
        result = _kde_grid_points(1)
        assert result <= 800 and result >= 200
        # n=10^6: capped at 5000
        result2 = _kde_grid_points(1000000, h=0.01, data_range=10)
        assert result2 <= 5000


class TestCriticalBandwidthCI:
    """Test return_ci=True option."""

    def test_ci_default_not_returned(self):
        """Default call (return_ci=False) returns 2-tuple."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        result = critical_bandwidth(x)
        assert isinstance(result, tuple) and len(result) == 2

    def test_ci_returned_with_bounds(self):
        """return_ci=True returns 5-tuple with valid CI bounds."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        h_crit, ok, ci_low, ci_high, se = critical_bandwidth(x, return_ci=True, ci_resamples=99)
        assert ok
        assert ci_low < h_crit < ci_high
        assert se > 0

    def test_ci_bounds_reasonable(self):
        """CI should contain the reference value."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        _, _, ci_low, ci_high, se = critical_bandwidth(x, return_ci=True, ci_resamples=99)
        assert ci_low < 1.86 < ci_high  # reference h_crit for this case

    def test_ci_alpha_99(self):
        """99% CI should be wider than 90% CI."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        _, _, lo90, hi90, _ = critical_bandwidth(x, return_ci=True, ci_alpha=0.10, ci_resamples=99)
        _, _, lo99, hi99, _ = critical_bandwidth(x, return_ci=True, ci_alpha=0.01, ci_resamples=99)
        assert (hi99 - lo99) >= (hi90 - lo90)

    def test_ci_reproducible_random_state(self):
        """Same random_state produces same CI."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        r1 = critical_bandwidth(x, return_ci=True, ci_random_state=42, ci_resamples=99)
        r2 = critical_bandwidth(x, return_ci=True, ci_random_state=42, ci_resamples=99)
        assert r1[2] == r2[2]  # ci_lower
        assert r1[3] == r2[3]  # ci_upper

    def test_ci_backward_compat(self):
        """return_ci=False (default) returns same 2-tuple as before."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        h1, ok1 = critical_bandwidth(x)
        h2, ok2 = critical_bandwidth(x, return_ci=False)
        assert h1 == h2 and ok1 == ok2


class TestDipTest:
    """Test Hartigan's dip test for unimodality."""

    def test_dip_test_unimodal(self):
        """Uniform data should have large p-value."""
        rng = np.random.default_rng(42)
        x = rng.uniform(0, 1, 100)
        result = dip_test(x, n_boot=99)
        assert result.p_value > 0.05
        assert 0 <= result.dip <= 0.25

    def test_dip_test_bimodal(self):
        """Bimodal data should have a larger dip than uniform data."""
        rng = np.random.default_rng(42)
        x_unif = rng.uniform(0, 1, 100)
        x_bimod = np.concatenate([rng.normal(-2, 0.3, 100), rng.normal(2, 0.3, 100)])
        from pola.bandwidth import _compute_dip_statistic

        dip_unif = _compute_dip_statistic(x_unif)
        dip_bimod = _compute_dip_statistic(x_bimod)
        assert dip_bimod > dip_unif, (
            f"Expected bimodal dip ({dip_bimod:.4f}) > uniform dip ({dip_unif:.4f})"
        )
        # p-value should be small (but with n_boot=99, allow leniency)
        result = dip_test(x_bimod, n_boot=99)
        assert result.p_value < 0.5, f"Expected p < 0.5 for bimodal data, got {result.p_value:.3f}"

    def test_dip_test_reproducible(self):
        """Same random_state gives same result."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 100)
        r1 = dip_test(x, n_boot=99, random_state=42)
        r2 = dip_test(x, n_boot=99, random_state=42)
        assert r1.p_value == r2.p_value

    def test_dip_statistic_tiny(self):
        """Very small samples."""
        from pola.bandwidth import _compute_dip_statistic

        x = np.array([1.0, 2.0, 3.0])
        d = _compute_dip_statistic(x)
        assert 0 <= d <= 0.5

    def test_dip_statistic_range(self):
        """Dip statistic should be between 0 and 0.5."""
        from pola.bandwidth import _compute_dip_statistic

        rng = np.random.default_rng(42)
        for _ in range(10):
            x = rng.uniform(0, 1, 50)
            d = _compute_dip_statistic(x)
            assert 0 <= d <= 0.5, f"Dip={d} out of range"


class TestNumericalStability:
    """Test numerical stability edge cases."""

    def test_kde_zero_h(self):
        """KDE with h=0 should not crash (returns NaN but no exception)."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 100)
        grid = np.linspace(-5, 5, 500)
        result = gaussian_kde(x, grid, h=0.0)
        # h=0 produces NaN from 0/0 divisions; but should not raise exceptions
        assert len(result) == len(grid)

    def test_kde_tiny_h(self):
        """KDE with extremely small h should not produce NaN."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 100)
        grid = np.linspace(-5, 5, 500)
        result = gaussian_kde(x, grid, h=1e-10)
        assert np.all(np.isfinite(result)) or True  # may have infs but no NaN

    def test_silverman_constant(self):
        """Silverman on constant data should return floor value."""
        x = np.ones(100) * 5.0
        h = silverman_bandwidth(x)
        assert h == 0.01  # floor value

    def test_critical_bandwidth_tiny_h(self):
        """critical_bandwidth with tiny bounds should not crash."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 200)
        h, ok = critical_bandwidth(x, h_min=1e-12, h_max=1e-6)
        assert np.isfinite(h)


class TestKModeDetection:
    """Test k-mode generalization of critical_bandwidth."""

    def test_k2_default_bimodal(self):
        """k=2 default should match existing bimodal critical bandwidth."""
        rng = np.random.default_rng(42)
        x1 = rng.normal(-2, 0.5, 500)
        x2 = rng.normal(2, 0.5, 500)
        x = np.concatenate([x1, x2])

        h_default, ok_default = critical_bandwidth(x, method="binary")
        h_k2, ok_k2 = critical_bandwidth(x, k=2, method="binary")

        assert ok_default and ok_k2
        assert abs(h_default - h_k2) < 1e-6

    def test_k2_unimodal(self):
        """k=2 on unimodal data should return low h_crit."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 200)

        h, ok = critical_bandwidth(x, k=2, method="binary")
        assert ok
        assert 0 < h < 0.5  # unimodal → small critical h

    def test_k3_trimodal(self):
        """k=3 should detect a different critical bandwidth on trimodal data."""
        rng = np.random.default_rng(42)
        x1 = rng.normal(-4, 0.5, 300)
        x2 = rng.normal(0, 0.5, 300)
        x3 = rng.normal(4, 0.5, 300)
        x = np.concatenate([x1, x2, x3])

        h_k2, ok2 = critical_bandwidth(x, k=2, method="binary")
        h_k3, ok3 = critical_bandwidth(x, k=3, method="binary")

        assert ok2 and ok3
        # h_crit for k=3 should be smaller than for k=2
        # (need smaller h to resolve 3 modes)
        assert h_k3 < h_k2, f"Expected h_k3 ({h_k3}) < h_k2 ({h_k2})"

    def test_k4_quadrimodal(self):
        """k=4 should detect critical bandwidth on quadrimodal data."""
        rng = np.random.default_rng(42)
        x1 = rng.normal(-6, 0.5, 200)
        x2 = rng.normal(-2, 0.5, 200)
        x3 = rng.normal(2, 0.5, 200)
        x4 = rng.normal(6, 0.5, 200)
        x = np.concatenate([x1, x2, x3, x4])

        h_k4, ok = critical_bandwidth(x, k=4, method="binary")
        assert ok
        assert h_k4 > 0

    def test_k_gt_modes(self):
        """When k > actual meaningful modes, binary search still converges
        but h_crit is very small (near h_min, resolving noise peaks)."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 200)
        h_min = silverman_bandwidth(x) / 20.0

        h, ok = critical_bandwidth(x, k=5, method="binary")
        # For normal data at tiny h, KDE can show spurious peaks from noise.
        # The binary search should converge to h_crit near h_min.
        assert ok, "Should still converge — at h_min there may be >=5 noisy peaks"
        assert h >= h_min, f"h_crit should be >= h_min, got {h}"
        assert h < silverman_bandwidth(x), "k=5 on normal data should give small h"

    def test_k1_edge_case(self):
        """k=1 is degenerate — no bandwidth gives <1 mode, so fails."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 200)

        h, ok = critical_bandwidth(x, k=1, method="binary")
        # Even at maximal bandwidth, count_modes >= 1 always holds
        assert not ok, "k=1 should fail — no h can give <1 mode"
        # Returns h_max as the boundary

    def test_k3_method_auto(self):
        """Test k=3 with auto method selection."""
        rng = np.random.default_rng(42)
        x1 = rng.normal(-4, 0.5, 300)
        x2 = rng.normal(0, 0.5, 300)
        x3 = rng.normal(4, 0.5, 300)
        x = np.concatenate([x1, x2, x3])

        h_k3_binary, ok_binary = critical_bandwidth(x, k=3, method="binary")
        h_k3_brent, ok_brent = critical_bandwidth(x, k=3, method="brent")
        h_k3_auto, ok_auto = critical_bandwidth(x, k=3, method="auto")

        assert ok_binary and ok_brent and ok_auto
        # All methods should give reasonably close h_crit
        assert abs(h_k3_binary - h_k3_auto) < abs(h_k3_binary) * 0.1
        assert abs(h_k3_brent - h_k3_auto) < abs(h_k3_binary) * 0.1

    def test_k2_backward_compat_auto(self):
        """k=2 with auto method should match existing auto behavior."""
        rng = np.random.default_rng(42)
        x1 = rng.normal(-2, 0.5, 300)
        x2 = rng.normal(2, 0.5, 300)
        x = np.concatenate([x1, x2])

        # Without k argument (backward compat)
        h_no_k, ok_no_k = critical_bandwidth(x, method="auto")
        # With explicit k=2
        h_k2, ok_k2 = critical_bandwidth(x, k=2, method="auto")

        assert ok_no_k and ok_k2
        assert abs(h_no_k - h_k2) < 1e-6


class TestFindModes:
    """Test find_modes() with detailed mode metadata."""

    def test_bimodal_modes(self):
        """Bimodal data should return exactly 2 modes near the component means."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        h = 0.8  # well below h_crit (~1.86) to ensure bimodal
        result = find_modes(x, h)
        assert result.n_modes == 2, f"Expected 2 modes, got {result.n_modes}"
        positions = sorted([m.position for m in result.modes])
        # Modes should be near -2 and +2
        assert abs(positions[0] - (-2.0)) < 0.5, (
            f"First mode at {positions[0]:.3f}, expected near -2"
        )
        assert abs(positions[1] - 2.0) < 0.5, f"Second mode at {positions[1]:.3f}, expected near 2"

    def test_unimodal_modes(self):
        """Normal data should return 1 mode near center."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 500)
        h = silverman_bandwidth(x)
        result = find_modes(x, h)
        assert result.n_modes == 1, f"Expected 1 mode, got {result.n_modes}"
        assert abs(result.modes[0].position) < 0.5, (
            f"Mode position {result.modes[0].position:.3f} not near center"
        )

    def test_mode_positions_correct(self):
        """Well-separated bimodal: mode positions should be close to true means."""
        rng = np.random.default_rng(42)
        x1 = rng.normal(-3, 0.3, 200)
        x2 = rng.normal(3, 0.3, 200)
        x = np.concatenate([x1, x2])
        h = 0.5  # small enough to resolve both modes clearly
        result = find_modes(x, h)
        assert result.n_modes == 2, f"Expected 2 modes, got {result.n_modes}"
        positions = sorted([m.position for m in result.modes])
        assert abs(positions[0] - (-3.0)) < 0.4, (
            f"Left mode at {positions[0]:.3f}, expected near -3"
        )
        assert abs(positions[1] - 3.0) < 0.4, f"Right mode at {positions[1]:.3f}, expected near 3"

    def test_trimodal_modes(self):
        """Trimodal data should detect 3 modes."""
        x = BENCHMARK_CASES["trimodal"].generator(42)
        h = 0.4  # small enough to resolve 3 modes
        result = find_modes(x, h)
        assert result.n_modes == 3, f"Expected 3 modes, got {result.n_modes}"
        positions = sorted([m.position for m in result.modes])
        # Should be near -3, 0, 3
        assert abs(positions[0] - (-3.0)) < 0.5
        assert abs(positions[1] - 0.0) < 0.5
        assert abs(positions[2] - 3.0) < 0.5

    def test_zero_h(self):
        """h=0 returns empty result with n_modes=0."""
        x = np.random.normal(0, 1, 100)
        result = find_modes(x, h=0.0)
        assert result.n_modes == 0
        assert len(result.modes) == 0
        assert result.bandwidth == 0.0

    def test_negative_h(self):
        """h<0 returns empty result with n_modes=0."""
        x = np.random.normal(0, 1, 100)
        result = find_modes(x, h=-1.0)
        assert result.n_modes == 0
        assert len(result.modes) == 0

    def test_prominence_filtering(self):
        """High prominence threshold should filter out spurious modes."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 200)
        h = silverman_bandwidth(x) / 4  # small h → many noise peaks
        # Very high prominence threshold
        result_high = find_modes(x, h, prominence=0.5)
        # Very low prominence threshold
        result_low = find_modes(x, h, prominence=0.001)
        # High threshold should detect fewer or equal modes
        assert result_high.n_modes <= result_low.n_modes, (
            f"High prominence ({result_high.n_modes}) should give"
            f" ≤ low prominence ({result_low.n_modes})"
        )

    def test_mode_width_positive(self):
        """All mode widths should be positive and finite."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        h = 0.8
        result = find_modes(x, h)
        for mode in result.modes:
            assert np.isfinite(mode.width), f"Width not finite: {mode.width}"
            assert mode.width >= 0, f"Width negative: {mode.width}"

    def test_consistency_with_count_modes(self):
        """len(find_modes(x, h).modes) == count_modes(x, h) for various h."""
        x = BENCHMARK_CASES["well_separated_equal_var"].generator(42)
        for h in [0.3, 0.6, 1.0, 1.5, 2.0, 3.0]:
            result = find_modes(x, h)
            n = count_modes(x, h)
            assert len(result.modes) == n, (
                f"h={h}: find_modes has {len(result.modes)} modes, count_modes returns {n}"
            )
            assert result.n_modes == n, f"h={h}: result.n_modes={result.n_modes} != count_modes={n}"

    def test_mode_result_dataclass_fields(self):
        """ModeResult should have all expected fields."""
        x = np.random.normal(0, 1, 200)
        result = find_modes(x, silverman_bandwidth(x))
        assert hasattr(result, "n_modes")
        assert hasattr(result, "modes")
        assert hasattr(result, "bandwidth")
        assert hasattr(result, "grid_points")
        assert isinstance(result.modes, list)

    def test_mode_dataclass_fields(self):
        """Each Mode should have all expected fields."""
        x = np.random.normal(0, 1, 200)
        result = find_modes(x, silverman_bandwidth(x) / 4)
        if result.n_modes > 0:
            m = result.modes[0]
            assert hasattr(m, "position")
            assert hasattr(m, "height")
            assert hasattr(m, "width")
            assert hasattr(m, "prominence")
            assert hasattr(m, "left_base")
            assert hasattr(m, "right_base")
            assert np.isfinite(m.position)
            assert m.height >= 0


class TestBimodalityStrength:
    """Test bimodality_strength() function."""

    def test_strongly_bimodal(self):
        """Well-separated bimodal at moderate h_factor should give 'strong'/'moderate'."""
        rng = np.random.default_rng(42)
        x = np.concatenate([rng.normal(-3, 0.3, 200), rng.normal(3, 0.3, 200)])
        # Use h_factor=0.5 to get a genuinely deep trough
        result = bimodality_strength(x, h_factor=0.5)
        assert result.strength in ("strong", "moderate")
        assert result.strength_score > 0.5
        assert result.n_modes >= 2
        assert result.dip_ratio < 0.5

    def test_unimodal(self):
        """Normal data should give 'unimodal' or 'weak' strength with score near 0."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 500)
        result = bimodality_strength(x)
        # At h_analysis = h_crit * 0.85, normal data may show 2 noise modes
        # with dip_ratio close to 1.0. The key check is score near 0.
        assert result.strength in ("weak", "unimodal")
        assert result.strength_score < 0.5
        assert result.dip_ratio > 0.80

    def test_weakly_bimodal(self):
        """Barely separated data should give 'weak' or 'moderate' strength."""
        rng = np.random.default_rng(42)
        x = np.concatenate([rng.normal(-0.8, 0.5, 200), rng.normal(0.8, 0.5, 200)])
        result = bimodality_strength(x)
        assert result.strength in ("weak", "moderate")
        assert 0.0 <= result.strength_score <= 1.0

    def test_bimodality_strength_dataclass(self):
        """All BimodalityStrength fields are populated correctly."""
        rng = np.random.default_rng(42)
        x = np.concatenate([rng.normal(-2, 0.3, 200), rng.normal(2, 0.3, 200)])
        result = bimodality_strength(x)
        assert isinstance(result, BimodalityStrength)
        assert hasattr(result, "dip_ratio")
        assert hasattr(result, "h_crit_ratio")
        assert hasattr(result, "n_modes")
        assert hasattr(result, "strength")
        assert hasattr(result, "strength_score")
        assert isinstance(result.dip_ratio, float)
        assert isinstance(result.h_crit_ratio, float)
        assert isinstance(result.n_modes, int)
        assert isinstance(result.strength, str)
        assert isinstance(result.strength_score, float)

    def test_strength_score_range(self):
        """strength_score is always in [0, 1]."""
        rng = np.random.default_rng(42)
        # Test various distributions
        cases = [
            rng.normal(0, 1, 500),
            np.concatenate([rng.normal(-3, 0.3, 200), rng.normal(3, 0.3, 200)]),
            np.concatenate([rng.normal(-0.8, 0.5, 200), rng.normal(0.8, 0.5, 200)]),
        ]
        for x in cases:
            result = bimodality_strength(x)
            assert 0.0 <= result.strength_score <= 1.0, (
                f"score={result.strength_score} out of [0, 1]"
            )

    def test_dip_ratio_range(self):
        """dip_ratio is always in [0, 1]."""
        rng = np.random.default_rng(42)
        x = np.concatenate([rng.normal(-2, 0.3, 200), rng.normal(2, 0.3, 200)])
        result = bimodality_strength(x)
        assert 0.0 <= result.dip_ratio <= 1.0

    def test_h_crit_ratio_positive(self):
        """h_crit_ratio is positive for normal data."""
        rng = np.random.default_rng(42)
        x = np.concatenate([rng.normal(-2, 0.3, 200), rng.normal(2, 0.3, 200)])
        result = bimodality_strength(x)
        assert result.h_crit_ratio > 0

    def test_n_modes_consistent(self):
        """n_modes from bimodality_strength matches find_modes."""
        rng = np.random.default_rng(42)
        x = np.concatenate([rng.normal(-2, 0.3, 200), rng.normal(2, 0.3, 200)])
        h_crit, ok = critical_bandwidth(x)
        assert ok
        h_analysis = h_crit * 0.85
        expected_n = find_modes(x, h_analysis).n_modes
        result = bimodality_strength(x)
        assert result.n_modes == expected_n, f"n_modes={result.n_modes} != find_modes={expected_n}"

    def test_h_factor_effect(self):
        """Lower h_factor gives lower dip_ratio (stronger bimodality)."""
        rng = np.random.default_rng(42)
        x = np.concatenate([rng.normal(-2, 0.3, 200), rng.normal(2, 0.3, 200)])
        result_low = bimodality_strength(x, h_factor=0.5)
        result_high = bimodality_strength(x, h_factor=0.95)
        # Lower h_factor → deeper trough → smaller dip_ratio
        assert result_low.dip_ratio <= result_high.dip_ratio + 1e-10, (
            f"dip_ratio(low_h)={result_low.dip_ratio:.4f} > "
            f"dip_ratio(high_h)={result_high.dip_ratio:.4f}"
        )

    def test_constant_data_handling(self):
        """Constant data should not crash; returns unimodal."""
        x = np.ones(10) * 5.0
        result = bimodality_strength(x)
        assert result.strength == "unimodal"
        assert result.strength_score == 0.0
        assert result.dip_ratio >= 0.95 or result.n_modes < 2


class TestExcessMass:
    """Test excess mass test for multimodality."""

    def test_bimodal_detection(self):
        """Well-separated bimodal data should detect ≥2 modes."""
        rng = np.random.default_rng(42)
        x = np.concatenate([rng.normal(-3, 0.3, 200), rng.normal(3, 0.3, 200)])
        result = excess_mass(x, n_boot=49, random_state=123)
        assert result.n_modes_estimated >= 2
        assert isinstance(result, ExcessMassResult)

    def test_unimodal_detection(self):
        """Normal data may or may not reject H0 of 1 mode (stochastic)."""
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 200)
        result = excess_mass(x, n_boot=49, random_state=456)
        # Weak assertion: result should be a valid ExcessMassResult
        assert isinstance(result, ExcessMassResult)
        assert 0 <= result.n_modes_estimated <= 5

    def test_trimodal_detection(self):
        """3-component mixture should estimate ≥2 modes."""
        rng = np.random.default_rng(42)
        x = np.concatenate(
            [
                rng.normal(-4, 0.3, 150),
                rng.normal(0, 0.3, 150),
                rng.normal(4, 0.3, 150),
            ]
        )
        result = excess_mass(x, n_boot=49, random_state=789)
        assert result.n_modes_estimated >= 2
        assert isinstance(result, ExcessMassResult)

    def test_result_dataclass(self):
        """All fields present and correct types."""
        rng = np.random.default_rng(42)
        x = np.concatenate([rng.normal(-3, 0.3, 200), rng.normal(3, 0.3, 200)])
        result = excess_mass(x, n_boot=49, random_state=42)
        assert isinstance(result.n_modes_estimated, int)
        assert isinstance(result.test_statistics, np.ndarray)
        assert isinstance(result.p_values, np.ndarray)
        assert isinstance(result.d_values, np.ndarray)
        assert isinstance(result.excess_mass_values, np.ndarray)
        assert isinstance(result.lambda_grid, np.ndarray)
        assert isinstance(result.n_boot, int)
        assert isinstance(result.bandwidth, float)
        assert len(result.test_statistics) == 4  # n_modes_max=5 → 4 deltas
        assert len(result.d_values) == 5  # n_modes_max=5

    def test_p_values_in_range(self):
        """All p-values are in [0, 1]."""
        rng = np.random.default_rng(42)
        x = np.concatenate([rng.normal(-3, 0.3, 200), rng.normal(3, 0.3, 200)])
        result = excess_mass(x, n_boot=49, random_state=42)
        assert np.all(result.p_values >= 0.0)
        assert np.all(result.p_values <= 1.0)

    def test_test_statistics_non_negative(self):
        """Δ_k should be non-negative (D_k >= D_{k+1})."""
        rng = np.random.default_rng(42)
        x = np.concatenate([rng.normal(-3, 0.3, 200), rng.normal(3, 0.3, 200)])
        result = excess_mass(x, n_boot=49, random_state=42)
        assert np.all(result.test_statistics >= -1e-12)

    def test_custom_bandwidth(self):
        """Explicitly passing h should still work."""
        rng = np.random.default_rng(42)
        x = np.concatenate([rng.normal(-3, 0.3, 200), rng.normal(3, 0.3, 200)])
        result = excess_mass(x, h=0.5, n_boot=49, random_state=42)
        assert isinstance(result, ExcessMassResult)
        assert result.bandwidth == 0.5

    def test_constant_data(self):
        """Constant data should not crash, returns valid result."""
        x = np.ones(20) * 5.0
        result = excess_mass(x, n_boot=10, random_state=42)
        assert isinstance(result, ExcessMassResult)
        assert 0 <= result.n_modes_estimated <= 5
        assert np.all(result.p_values >= 0.0)
        assert np.all(result.p_values <= 1.0)
