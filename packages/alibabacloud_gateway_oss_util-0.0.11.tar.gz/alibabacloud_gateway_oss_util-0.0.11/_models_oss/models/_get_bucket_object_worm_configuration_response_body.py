# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from alibabacloud_oss20190517 import models as main_models
from darabonba.model import DaraModel

class GetBucketObjectWormConfigurationResponseBody(DaraModel):
    def __init__(
        self,
        object_worm_configuration: main_models.ObjectWormConfiguration = None,
    ):
        self.object_worm_configuration = object_worm_configuration

    def validate(self):
        if self.object_worm_configuration:
            self.object_worm_configuration.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.object_worm_configuration is not None:
            result['ObjectWormConfiguration'] = self.object_worm_configuration.to_map()

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('ObjectWormConfiguration') is not None:
            temp_model = main_models.ObjectWormConfiguration()
            self.object_worm_configuration = temp_model.from_map(m.get('ObjectWormConfiguration'))

        return self

