# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from _models_hcs_mgw import models as main_models
from darabonba.model import DaraModel

class ListJobResp(DaraModel):
    def __init__(
        self,
        import_job: List[main_models.GetJobResp] = None,
        next_marker: str = None,
        truncated: bool = None,
    ):
        # The queried tasks.
        self.import_job = import_job
        # The position from which the next list operation starts.
        self.next_marker = next_marker
        # Indicates whether the queried results are truncated.
        self.truncated = truncated

    def validate(self):
        if self.import_job:
            for v1 in self.import_job:
                 if v1:
                    v1.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        result['ImportJob'] = []
        if self.import_job is not None:
            for k1 in self.import_job:
                result['ImportJob'].append(k1.to_map() if k1 else None)

        if self.next_marker is not None:
            result['NextMarker'] = self.next_marker

        if self.truncated is not None:
            result['Truncated'] = self.truncated

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.import_job = []
        if m.get('ImportJob') is not None:
            for k1 in m.get('ImportJob'):
                temp_model = main_models.GetJobResp()
                self.import_job.append(temp_model.from_map(k1))

        if m.get('NextMarker') is not None:
            self.next_marker = m.get('NextMarker')

        if m.get('Truncated') is not None:
            self.truncated = m.get('Truncated')

        return self

