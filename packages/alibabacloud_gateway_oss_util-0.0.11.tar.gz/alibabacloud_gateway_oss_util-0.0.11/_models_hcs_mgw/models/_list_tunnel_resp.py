# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from _models_hcs_mgw import models as main_models
from darabonba.model import DaraModel

class ListTunnelResp(DaraModel):
    def __init__(
        self,
        import_tunnel: List[main_models.GetTunnelResp] = None,
        next_marker: str = None,
        truncated: bool = None,
    ):
        # The queried tunnels.
        self.import_tunnel = import_tunnel
        # The position from which the next list operation starts.
        self.next_marker = next_marker
        # Indicates whether the queried results are truncated.
        # 
        # Valid values:
        # 
        # *   true
        # *   false
        self.truncated = truncated

    def validate(self):
        if self.import_tunnel:
            for v1 in self.import_tunnel:
                 if v1:
                    v1.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        result['ImportTunnel'] = []
        if self.import_tunnel is not None:
            for k1 in self.import_tunnel:
                result['ImportTunnel'].append(k1.to_map() if k1 else None)

        if self.next_marker is not None:
            result['NextMarker'] = self.next_marker

        if self.truncated is not None:
            result['Truncated'] = self.truncated

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.import_tunnel = []
        if m.get('ImportTunnel') is not None:
            for k1 in m.get('ImportTunnel'):
                temp_model = main_models.GetTunnelResp()
                self.import_tunnel.append(temp_model.from_map(k1))

        if m.get('NextMarker') is not None:
            self.next_marker = m.get('NextMarker')

        if m.get('Truncated') is not None:
            self.truncated = m.get('Truncated')

        return self

