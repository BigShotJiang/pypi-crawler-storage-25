#!/usr/bin/env python
import warnings

# Filter RequestsDependencyWarning early to prevent log spam
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    try:
        from requests.exceptions import RequestsDependencyWarning

        warnings.filterwarnings("ignore", category=RequestsDependencyWarning)
    except ImportError:
        pass

# General urllib3/chardet mismatch warnings
warnings.filterwarnings("ignore", message=".*urllib3.*or chardet.*")
warnings.filterwarnings("ignore", message=".*urllib3.*or charset_normalizer.*")

import logging
import os
import sys
from typing import Any

import requests
from agent_utilities.base_utilities import to_boolean
from agent_utilities.mcp_utilities import (
    config,
    create_mcp_parser,
    create_mcp_server,
    ctx_confirm_destructive,
    ctx_progress,
)
from dotenv import find_dotenv, load_dotenv
from fastmcp import Context, FastMCP
from fastmcp.utilities.logging import get_logger
from pydantic import Field
from starlette.requests import Request
from starlette.responses import JSONResponse

from adguard_home_agent.api_client import Api

__version__ = "0.10.0"

logger = get_logger(name="TokenMiddleware")
logger.setLevel(logging.DEBUG)


def register_prompts(mcp: FastMCP):
    @mcp.prompt()
    def review_filtering_rules() -> str:
        """Review current filtering rules and blacklists."""
        return (
            "Please review the current filtering rules and blacklists to "
            "ensure optimal ad blocking and security."
        )

    @mcp.prompt()
    def optimize_dns_settings() -> str:
        """Optimize DNS settings for performance and privacy."""
        return (
            "Analyze the current DNS configuration and suggest "
            "optimizations for better performance and privacy."
        )

    @mcp.prompt()
    def analyze_query_log() -> str:
        """Analyze query logs for suspicious activity."""
        return (
            "Analyze the recent query logs to identify any suspicious "
            "domains or blocked requests that might indicate an issue."
        )

    @mcp.prompt()
    def configure_parental_controls() -> str:
        """Configure parental control settings."""
        return (
            "Help me configure parental controls to ensure a safe "
            "browsing environment for my family."
        )

    @mcp.prompt()
    def manage_clients() -> str:
        """Manage connected clients and their specific settings."""
        return (
            "I need to manage the connected clients, including assigning "
            "specific policies and identifying devices."
        )

    @mcp.prompt()
    def add_dns_rewrite() -> str:
        """Add a new DNS rewrite rule."""
        return (
            "I want to add a new DNS rewrite rule to redirect a domain "
            "to a specific IP address."
        )

    @mcp.prompt()
    def update_dns_rewrite() -> str:
        """Update an existing DNS rewrite rule."""
        return "I need to update an existing DNS rewrite rule."

    @mcp.prompt()
    def delete_dns_rewrite() -> str:
        """Delete a DNS rewrite rule."""
        return "I want to remove a DNS rewrite rule that is no longer needed."


def register_misc_tools(mcp: FastMCP):
    pass
    pass

    async def health_check(request: Request) -> JSONResponse:
        return JSONResponse({"status": "OK"})


def register_system_tools(mcp: FastMCP):
    @mcp.tool(tags={"system"})
    async def get_version(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get AdGuard Home version."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_version()

    @mcp.tool(tags={"system"})
    async def set_protection(
        enabled: bool = Field(..., description="Enable/disable protection"),
        duration: int | None = Field(None, description="Duration in milliseconds"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Set protection state."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.set_protection(enabled=enabled, duration=duration)

    @mcp.tool(tags={"system"})
    async def clear_cache(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Clear DNS cache."""
        if not await ctx_confirm_destructive(ctx, "clear cache"):
            return {"status": "cancelled", "message": "Operation cancelled by user"}
        await ctx_progress(ctx, 0, 100)
        client = Api(base_url=base_url, username=username, password=password)
        return client.clear_cache()


def register_access_tools(mcp: FastMCP):
    @mcp.tool(tags={"access"})
    async def get_access_list(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict[str, Any]:
        """List current access list (allowed/disallowed clients, blocked hosts)."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.access_list()

    @mcp.tool(tags={"access"})
    async def set_access_list(
        allowed_clients: list[str] | None = Field(
            None, description="List of allowed clients"
        ),
        disallowed_clients: list[str] | None = Field(
            None, description="List of disallowed clients"
        ),
        blocked_hosts: list[str] | None = Field(
            None, description="List of blocked hosts"
        ),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Set access list."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.set_access_list(
            allowed_clients=allowed_clients,
            disallowed_clients=disallowed_clients,
            blocked_hosts=blocked_hosts,
        )


def register_blocked_services_tools(mcp: FastMCP):
    @mcp.tool(tags={"blocked-services"})
    async def get_blocked_services_list(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> list[str]:
        """List blocked services."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_blocked_services_list()

    @mcp.tool(tags={"blocked-services"})
    async def get_all_blocked_services(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> list[dict[str, Any]]:
        """Get all available blocked services."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_all_blocked_services()

    @mcp.tool(tags={"blocked-services"})
    async def update_blocked_services(
        services: list[str] = Field(..., description="List of services to block"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Update blocked services list."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.update_blocked_services(services=services)


def register_filtering_tools(mcp: FastMCP):
    @mcp.tool(tags={"filtering"})
    async def set_filtering_rules(
        rules: list[str] = Field(..., description="List of filtering rules"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Set user-defined filtering rules."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.set_filtering_rules(rules=rules)

    @mcp.tool(tags={"filtering"})
    async def check_host_filtering(
        name: str = Field(..., description="Host name to check"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Check if a host is filtered."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.check_host_filtering(name=name)

    @mcp.tool(tags={"filtering"})
    async def set_filter_url_params(
        url: str = Field(..., description="URL of the filter"),
        name: str = Field(..., description="Name of the filter"),
        whitelist: bool = Field(False, description="Is it a whitelist?"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Set filter URL parameters."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.set_filter_url_params(url=url, name=name, whitelist=whitelist)

    @mcp.tool(tags={"filtering"})
    async def get_filtering_status(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get filtering status."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_filtering_status()

    @mcp.tool(tags={"filtering"})
    async def set_filtering_config(
        enabled: bool = Field(..., description="Enable filtering"),
        interval: int = Field(..., description="Update interval in hours"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Set filtering configuration."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.set_filtering_config(enabled=enabled, interval=interval)

    @mcp.tool(tags={"filtering"})
    async def add_filter_url(
        name: str = Field(..., description="Name of the filter"),
        url: str = Field(..., description="URL of the filter"),
        whitelist: bool = Field(False, description="Is it a whitelist?"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Add a filter URL."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.add_filter_url(name=name, url=url, whitelist=whitelist)

    @mcp.tool(tags={"filtering"})
    async def remove_filter_url(
        url: str = Field(..., description="URL of the filter to remove"),
        whitelist: bool = Field(False, description="Is it a whitelist?"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Remove a filter URL."""
        if not await ctx_confirm_destructive(ctx, "remove filter url"):
            return {"status": "cancelled", "message": "Operation cancelled by user"}
        await ctx_progress(ctx, 0, 100)
        client = Api(base_url=base_url, username=username, password=password)
        return client.remove_filter_url(url=url, whitelist=whitelist)

    @mcp.tool(tags={"filtering"})
    async def refresh_filters(
        whitelist: bool = Field(False, description="Refresh whitelists?"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Refresh all filters."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.refresh_filters(whitelist=whitelist)


def register_clients_tools(mcp: FastMCP):
    @mcp.tool(tags={"clients"})
    async def list_clients(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """List clients."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.list_clients()

    @mcp.tool(tags={"clients"})
    async def search_clients(
        query: str = Field(..., description="Query string (IP, name, or ClientID)"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> list[dict]:
        """Search for clients."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.search_clients(query=query)

    @mcp.tool(tags={"clients"})
    async def add_client(
        name: str = Field(..., description="Name of the client"),
        ids: list[str] = Field(
            ..., description="List of identifiers (IP, CIDR, MAC, ClientID)"
        ),
        use_global_settings: bool = Field(True, description="Use global settings"),
        filtering_enabled: bool = Field(True, description="Enable filtering"),
        parent_access: bool = Field(False, description="Enable parental control"),
        safe_search_enabled: bool = Field(False, description="Enable safe search"),
        safe_browsing_enabled: bool = Field(False, description="Enable safe browsing"),
        tags: list[str] | None = Field(None, description="Client tags"),
        upstreams: list[str] | None = Field(None, description="Upstream DNS servers"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Add a new client."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.add_client(
            name=name,
            ids=ids,
            use_global_settings=use_global_settings,
            filtering_enabled=filtering_enabled,
            parent_access=parent_access,
            safe_search_enabled=safe_search_enabled,
            safe_browsing_enabled=safe_browsing_enabled,
            tags=tags,
            upstreams=upstreams,
        )

    @mcp.tool(tags={"clients"})
    async def update_client(
        name: str = Field(..., description="Name of the client"),
        data: dict = Field(..., description="Client data to update"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Update a client."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.update_client(name=name, data=data)

    @mcp.tool(tags={"clients"})
    async def delete_client(
        name: str = Field(..., description="Name of the client"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Delete a client."""
        if not await ctx_confirm_destructive(ctx, "delete client"):
            return {"status": "cancelled", "message": "Operation cancelled by user"}
        await ctx_progress(ctx, 0, 100)
        client = Api(base_url=base_url, username=username, password=password)
        return client.delete_client(name=name)


def register_profile_tools(mcp: FastMCP):
    @mcp.tool(tags={"profile"})
    async def get_profile(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get current user profile info."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_profile()

    @mcp.tool(tags={"profile"})
    async def update_profile(
        profile_data: dict = Field(..., description="Profile data to update"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Update current user profile info."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.update_profile(profile_data=profile_data)


def register_dhcp_tools(mcp: FastMCP):
    @mcp.tool(tags={"dhcp"})
    async def get_dhcp_status(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get DHCP status."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_dhcp_status()

    @mcp.tool(tags={"dhcp"})
    async def get_dhcp_interfaces(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get available network interfaces for DHCP."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_dhcp_interfaces()

    @mcp.tool(tags={"dhcp"})
    async def set_dhcp_config(
        config: dict = Field(..., description="DHCP configuration"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Set DHCP configuration."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.set_dhcp_config(config=config)

    @mcp.tool(tags={"dhcp"})
    async def find_active_dhcp(
        interface: str = Field(..., description="Network interface to check"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Search for an active DHCP server on the network."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.find_active_dhcp(interface=interface)

    @mcp.tool(tags={"dhcp"})
    async def add_dhcp_static_lease(
        mac: str = Field(..., description="MAC address"),
        ip: str = Field(..., description="IP address"),
        hostname: str = Field(..., description="Hostname"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Add a static DHCP lease."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.add_dhcp_static_lease(mac=mac, ip=ip, hostname=hostname)

    @mcp.tool(tags={"dhcp"})
    async def remove_dhcp_static_lease(
        mac: str = Field(..., description="MAC address"),
        ip: str = Field(..., description="IP address"),
        hostname: str = Field(..., description="Hostname"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Remove a static DHCP lease."""
        if not await ctx_confirm_destructive(ctx, "remove dhcp static lease"):
            return {"status": "cancelled", "message": "Operation cancelled by user"}
        await ctx_progress(ctx, 0, 100)
        client = Api(base_url=base_url, username=username, password=password)
        return client.remove_dhcp_static_lease(mac=mac, ip=ip, hostname=hostname)

    @mcp.tool(tags={"dhcp"})
    async def update_dhcp_static_lease(
        mac: str = Field(..., description="MAC address"),
        ip: str = Field(..., description="IP address"),
        hostname: str = Field(..., description="Hostname"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Update a static DHCP lease."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.update_dhcp_static_lease(mac=mac, ip=ip, hostname=hostname)

    @mcp.tool(tags={"dhcp"})
    async def reset_dhcp(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Reset DHCP configuration."""
        if not await ctx_confirm_destructive(ctx, "reset dhcp"):
            return {"status": "cancelled", "message": "Operation cancelled by user"}
        await ctx_progress(ctx, 0, 100)
        client = Api(base_url=base_url, username=username, password=password)
        return client.reset_dhcp()

    @mcp.tool(tags={"dhcp"})
    async def reset_dhcp_leases(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Reset DHCP leases."""
        if not await ctx_confirm_destructive(ctx, "reset dhcp leases"):
            return {"status": "cancelled", "message": "Operation cancelled by user"}
        await ctx_progress(ctx, 0, 100)
        client = Api(base_url=base_url, username=username, password=password)
        return client.reset_dhcp_leases()


def register_settings_tools(mcp: FastMCP):
    @mcp.tool(tags={"settings"})
    async def get_parental_status(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get parental control status."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_parental_status()

    @mcp.tool(tags={"settings"})
    async def enable_parental_control(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Enable parental control."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.enable_parental_control()

    @mcp.tool(tags={"settings"})
    async def disable_parental_control(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Disable parental control."""
        if not await ctx_confirm_destructive(ctx, "disable parental control"):
            return {"status": "cancelled", "message": "Operation cancelled by user"}
        await ctx_progress(ctx, 0, 100)
        client = Api(base_url=base_url, username=username, password=password)
        return client.disable_parental_control()

    @mcp.tool(tags={"settings"})
    async def get_safebrowsing_status(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get safe browsing status."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_safebrowsing_status()

    @mcp.tool(tags={"settings"})
    async def enable_safebrowsing(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Enable safe browsing."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.enable_safebrowsing()

    @mcp.tool(tags={"settings"})
    async def disable_safebrowsing(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Disable safe browsing."""
        if not await ctx_confirm_destructive(ctx, "disable safebrowsing"):
            return {"status": "cancelled", "message": "Operation cancelled by user"}
        await ctx_progress(ctx, 0, 100)
        client = Api(base_url=base_url, username=username, password=password)
        return client.disable_safebrowsing()

    @mcp.tool(tags={"settings"})
    async def get_safesearch_status(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get safe search status."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_safesearch_status()


def register_query_log_tools(mcp: FastMCP):
    @mcp.tool(tags={"query-log"})
    async def get_query_log(
        time_from_millis: int = Field(..., description="Start time in milliseconds"),
        time_to_millis: int = Field(..., description="End time in milliseconds"),
        limit: int = Field(20, description="Max number of logs to return"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get query log."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_query_log(
            time_from_millis=time_from_millis,
            time_to_millis=time_to_millis,
            limit=limit,
        )

    @mcp.tool(tags={"query-log"})
    async def clear_query_log(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Clear query log."""
        if not await ctx_confirm_destructive(ctx, "clear query log"):
            return {"status": "cancelled", "message": "Operation cancelled by user"}
        await ctx_progress(ctx, 0, 100)
        client = Api(base_url=base_url, username=username, password=password)
        return client.clear_query_log()


def register_rewrites_tools(mcp: FastMCP):
    @mcp.tool(tags={"rewrites"})
    async def list_rewrites(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> list[dict]:
        """List DNS rewrites."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.list_rewrites()

    @mcp.tool(tags={"rewrites"})
    async def add_rewrite(
        domain: str = Field(..., description="Domain to rewrite"),
        answer: str = Field(..., description="Answer to rewrite to"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Add a DNS rewrite."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.add_rewrite(domain=domain, answer=answer)

    @mcp.tool(tags={"rewrites"})
    async def delete_rewrite(
        domain: str = Field(..., description="Domain to rewrite"),
        answer: str = Field(..., description="Answer to rewrite to"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Delete a DNS rewrite."""
        if not await ctx_confirm_destructive(ctx, "delete rewrite"):
            return {"status": "cancelled", "message": "Operation cancelled by user"}
        await ctx_progress(ctx, 0, 100)
        client = Api(base_url=base_url, username=username, password=password)
        return client.delete_rewrite(domain=domain, answer=answer)

    @mcp.tool(tags={"rewrites"})
    async def update_rewrite(
        target: dict = Field(..., description="Target rewrite rule"),
        update: dict = Field(..., description="Updated rewrite rule"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Update a DNS rewrite."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.update_rewrite(target=target, update=update)

    @mcp.tool(tags={"rewrites"})
    async def get_rewrite_settings(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get rewrite settings."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_rewrite_settings()

    @mcp.tool(tags={"rewrites"})
    async def update_rewrite_settings(
        enabled: bool = Field(..., description="Enable/disable rewrites"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Update rewrite settings."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.update_rewrite_settings(enabled=enabled)


def register_tls_tools(mcp: FastMCP):
    @mcp.tool(tags={"tls"})
    async def get_tls_status(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get TLS status."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_tls_status()

    @mcp.tool(tags={"tls"})
    async def configure_tls(
        config: dict = Field(..., description="TLS configuration"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Configure TLS."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.configure_tls(config=config)

    @mcp.tool(tags={"tls"})
    async def validate_tls(
        config: dict = Field(..., description="TLS configuration to validate"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Validate TLS configuration."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.validate_tls(config=config)


def register_mobile_tools(mcp: FastMCP):
    @mcp.tool(tags={"mobile"})
    async def get_doh_mobile_config(
        host: str = Field(..., description="Host name"),
        client_id: str = Field(..., description="Client ID"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> str:
        """Get DNS over HTTPS .mobileconfig."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_doh_mobile_config(host=host, client_id=client_id)

    @mcp.tool(tags={"mobile"})
    async def get_dot_mobile_config(
        host: str = Field(..., description="Host name"),
        client_id: str = Field(..., description="Client ID"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> str:
        """Get DNS over TLS .mobileconfig."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_dot_mobile_config(host=host, client_id=client_id)


def register_stats_tools(mcp: FastMCP):
    @mcp.tool(tags={"stats"})
    async def get_stats(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get overall statistics."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_stats()

    @mcp.tool(tags={"stats"})
    async def reset_stats(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Reset statistics."""
        if not await ctx_confirm_destructive(ctx, "reset stats"):
            return {"status": "cancelled", "message": "Operation cancelled by user"}
        await ctx_progress(ctx, 0, 100)
        client = Api(base_url=base_url, username=username, password=password)
        return client.reset_stats()

    @mcp.tool(tags={"stats"})
    async def get_stats_config(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get statistics configuration."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_stats_config()

    @mcp.tool(tags={"stats"})
    async def set_stats_config(
        interval: int = Field(
            ..., description="Statistics retention interval in milliseconds"
        ),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Set statistics configuration."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.set_stats_config(interval=interval)


def register_dns_tools(mcp: FastMCP):
    @mcp.tool(tags={"dns"})
    async def get_dns_info(
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Get general DNS parameters."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.get_dns_info()

    @mcp.tool(tags={"dns"})
    async def set_dns_config(
        config: dict = Field(..., description="DNS configuration"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Set general DNS parameters."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.set_dns_config(config=config)

    @mcp.tool(tags={"dns"})
    async def test_upstream_dns(
        upstreams: list[str] = Field(..., description="List of upstreams to test"),
        base_url: str = Field(
            default=os.environ.get("ADGUARD_URL", "http://localhost:3000"),
            description="The base URL of the AdGuard Home instance",
        ),
        username: str | None = Field(
            default=os.environ.get("ADGUARD_USERNAME", None),
            description="Username for authentication",
        ),
        password: str | None = Field(
            default=os.environ.get("ADGUARD_PASSWORD", None),
            description="Password for authentication",
        ),
        ctx: Context = Field(
            description="MCP context for progress reporting", default=None
        ),
    ) -> dict:
        """Test upstream configuration."""
        client = Api(base_url=base_url, username=username, password=password)
        return client.test_upstream_dns(upstreams=upstreams)


def get_mcp_instance() -> tuple[Any, Any, Any, Any]:
    """Initialize and return the MCP instance, args, and middlewares."""
    load_dotenv(find_dotenv())
    print(f"Adguard Home MCP v{__version__}", file=sys.stderr)
    parser = create_mcp_parser()

    args = parser.parse_known_args()[0]

    if hasattr(args, "help") and args.help:
        parser.print_help()

        sys.exit(0)

    if args.port < 0 or args.port > 65535:
        print(
            f"Error: Port {args.port} is out of valid range (0-65535).", file=sys.stderr
        )
        sys.exit(1)

    config["enable_delegation"] = args.enable_delegation
    config["audience"] = args.audience or config["audience"]
    config["delegated_scopes"] = args.delegated_scopes or config["delegated_scopes"]
    config["oidc_config_url"] = args.oidc_config_url or config["oidc_config_url"]
    config["oidc_client_id"] = args.oidc_client_id or config["oidc_client_id"]
    config["oidc_client_secret"] = (
        args.oidc_client_secret or config["oidc_client_secret"]
    )

    if config["enable_delegation"]:
        if args.auth_type != "oidc-proxy":
            logger.error("Token delegation requires auth-type=oidc-proxy")
            sys.exit(1)
        if not config["audience"]:
            logger.error("audience is required for delegation")
            sys.exit(1)
        if not all(
            [
                config["oidc_config_url"],
                config["oidc_client_id"],
                config["oidc_client_secret"],
            ]
        ):
            logger.error(
                "Delegation requires complete OIDC configuration "
                "(oidc-config-url, oidc-client-id, oidc-client-secret)"
            )
            sys.exit(1)

        try:
            logger.info(
                "Fetching OIDC configuration",
                extra={"oidc_config_url": config["oidc_config_url"]},
            )
            oidc_config_resp = requests.get(config["oidc_config_url"], timeout=30)
            oidc_config_resp.raise_for_status()
            oidc_config = oidc_config_resp.json()
            config["token_endpoint"] = oidc_config.get("token_endpoint")
            if not config["token_endpoint"]:
                logger.error("No token_endpoint found in OIDC configuration")
                raise ValueError("No token_endpoint found in OIDC configuration")
            logger.info(
                "OIDC configuration fetched successfully",
                extra={"token_endpoint": config["token_endpoint"]},
            )
        except Exception as e:
            print(f"Failed to fetch OIDC configuration: {e}", file=sys.stderr)
            logger.error(
                "Failed to fetch OIDC configuration",
                extra={"error_type": type(e).__name__, "error_message": str(e)},
            )
            sys.exit(1)

    args, mcp, middlewares = create_mcp_server(
        name="Adguard Home",
        version=__version__,
        instructions=(
            "AdGuard Home MCP Server - Manage DNS filtering, "
            "DHCP settings, and query logs."
        ),
    )

    DEFAULT_MISCTOOL = to_boolean(os.getenv("MISCTOOL", "True"))
    if DEFAULT_MISCTOOL:
        register_misc_tools(mcp)
    DEFAULT_SYSTEMTOOL = to_boolean(os.getenv("SYSTEMTOOL", "True"))
    if DEFAULT_SYSTEMTOOL:
        register_system_tools(mcp)
    DEFAULT_ACCESSTOOL = to_boolean(os.getenv("ACCESSTOOL", "True"))
    if DEFAULT_ACCESSTOOL:
        register_access_tools(mcp)
    DEFAULT_BLOCKED_SERVICESTOOL = to_boolean(os.getenv("BLOCKED_SERVICESTOOL", "True"))
    if DEFAULT_BLOCKED_SERVICESTOOL:
        register_blocked_services_tools(mcp)
    DEFAULT_FILTERINGTOOL = to_boolean(os.getenv("FILTERINGTOOL", "True"))
    if DEFAULT_FILTERINGTOOL:
        register_filtering_tools(mcp)
    DEFAULT_CLIENTSTOOL = to_boolean(os.getenv("CLIENTSTOOL", "True"))
    if DEFAULT_CLIENTSTOOL:
        register_clients_tools(mcp)
    DEFAULT_PROFILETOOL = to_boolean(os.getenv("PROFILETOOL", "True"))
    if DEFAULT_PROFILETOOL:
        register_profile_tools(mcp)
    DEFAULT_DHCPTOOL = to_boolean(os.getenv("DHCPTOOL", "True"))
    if DEFAULT_DHCPTOOL:
        register_dhcp_tools(mcp)
    DEFAULT_SETTINGSTOOL = to_boolean(os.getenv("SETTINGSTOOL", "True"))
    if DEFAULT_SETTINGSTOOL:
        register_settings_tools(mcp)
    DEFAULT_QUERY_LOGTOOL = to_boolean(os.getenv("QUERY_LOGTOOL", "True"))
    if DEFAULT_QUERY_LOGTOOL:
        register_query_log_tools(mcp)
    DEFAULT_REWRITESTOOL = to_boolean(os.getenv("REWRITESTOOL", "True"))
    if DEFAULT_REWRITESTOOL:
        register_rewrites_tools(mcp)
    DEFAULT_TLSTOOL = to_boolean(os.getenv("TLSTOOL", "True"))
    if DEFAULT_TLSTOOL:
        register_tls_tools(mcp)
    DEFAULT_MOBILETOOL = to_boolean(os.getenv("MOBILETOOL", "True"))
    if DEFAULT_MOBILETOOL:
        register_mobile_tools(mcp)
    DEFAULT_STATSTOOL = to_boolean(os.getenv("STATSTOOL", "True"))
    if DEFAULT_STATSTOOL:
        register_stats_tools(mcp)
    DEFAULT_DNSTOOL = to_boolean(os.getenv("DNSTOOL", "True"))
    if DEFAULT_DNSTOOL:
        register_dns_tools(mcp)
    register_prompts(mcp)

    for mw in middlewares:
        mcp.add_middleware(mw)
    registered_tags: list[str] = []
    return mcp, args, middlewares, registered_tags


def mcp_server() -> None:
    mcp, args, middlewares, registered_tags = get_mcp_instance()
    print(f"{'adguard-home-agent'} MCP v{__version__}", file=sys.stderr)
    print("\nStarting MCP Server", file=sys.stderr)
    print(f"  Transport: {args.transport.upper()}", file=sys.stderr)
    print(f"  Auth: {args.auth_type}", file=sys.stderr)
    print(f"  Dynamic Tags Loaded: {len(set(registered_tags))}", file=sys.stderr)

    if args.transport == "stdio":
        mcp.run(transport="stdio")
    elif args.transport == "streamable-http":
        mcp.run(transport="streamable-http", host=args.host, port=args.port)
    elif args.transport == "sse":
        mcp.run(transport="sse", host=args.host, port=args.port)
    else:
        logger.error("Invalid transport", extra={"transport": args.transport})
        sys.exit(1)


if __name__ == "__main__":
    mcp_server()
