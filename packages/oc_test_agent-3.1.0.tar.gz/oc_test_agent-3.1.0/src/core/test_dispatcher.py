"""
测试分发器 - 根据project动态选择测试文件
"""

import os
import yaml
from pathlib import Path
from typing import List, Optional


class TestDispatcher:
    """测试分发器 - 根据project参数选择对应的测试文件"""
    
    def __init__(self, config_path: Optional[str] = None):
        if config_path is None:
            current = Path(__file__).resolve().parent
            for parent in [current] + list(current.parents):
                config_path = parent / 'config' / 'test_dispatcher.yaml'
                if config_path.exists():
                    break
        
        self.config_path = config_path
        self.config = self._load_config()
        self.test_paths = self.config.get('test_paths', {})
        self.unknown_project_strategy = self.config.get('unknown_project', 'error')
    
    def _load_config(self) -> dict:
        if self.config_path and Path(self.config_path).exists():
            with open(self.config_path, 'r') as f:
                return yaml.safe_load(f) or {}
        return self._get_default_config()
    
    def _get_default_config(self) -> dict:
        return {
            'test_paths': {
                'test-agent': [
                    'tests/test_agent_daemon.py',
                    'tests/test_agent_behavior.py',
                    'tests/test_v3_0_core_services.py'
                ]
            },
            'unknown_project': 'error'
        }
    
    def get_test_paths(self, project: str) -> List[str]:
        if project in self.test_paths:
            return self.test_paths[project]
        
        if self.unknown_project_strategy == 'error':
            raise ValueError(f"未知项目: {project}")
        elif self.unknown_project_strategy == 'default':
            return self.test_paths.get('test-agent', [])
        
        return []
    
    def get_all_projects(self) -> List[str]:
        return list(self.test_paths.keys())
