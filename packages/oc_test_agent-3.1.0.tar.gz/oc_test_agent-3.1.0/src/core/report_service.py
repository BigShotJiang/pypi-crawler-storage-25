import logging
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, asdict
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class ResultFilter:
    project: Optional[str] = None
    version: Optional[str] = None
    case_id: Optional[str] = None
    test_id: Optional[str] = None
    status: Optional[str] = None
    limit: int = 20
    offset: int = 0


@dataclass
class BugFilter:
    project: Optional[str] = None
    version: Optional[str] = None
    case_id: Optional[str] = None
    test_id: Optional[str] = None
    status: Optional[str] = None
    severity: Optional[str] = None
    limit: int = 20
    offset: int = 0


@dataclass
class TestFilter:
    project: Optional[str] = None
    status: Optional[str] = None
    from_date: Optional[datetime] = None
    to_date: Optional[datetime] = None


@dataclass
class TestReport:
    test_id: str
    project: str
    status: str
    subsystems: List[Dict]
    summary: Dict
    report_git_commit: str
    bugs: List[Dict]
    duration: float
    started_at: str
    completed_at: str
    details: Optional[List[Dict]] = None


@dataclass
class TestSummary:
    passed: int
    failed: int
    errors: int
    skipped: int
    total: int


@dataclass
class CaseHistoryItem:
    result_id: str
    test_id: str
    version: str
    status: str
    duration: float
    executed_at: str


@dataclass
class CaseHistoryResult:
    case_id: str
    history: List[CaseHistoryItem]
    total: int
    limit: int
    offset: int


class ReportService:
    """测试报告服务 - 聚合测试结果和Bug报告"""
    
    def __init__(self, storage_service, config: Optional[Dict] = None):
        self.storage = storage_service
        self.config = config or {}
        
        report_config = self.config.get('report', {})
        pagination_config = report_config.get('pagination', {})
        self.default_page_size = pagination_config.get('default_page_size', 20)
        self.max_page_size = pagination_config.get('max_page_size', 100)

    def get_test_results(self, filters: ResultFilter) -> Dict[str, Any]:
        """获取测试结果"""
        
        limit = min(filters.limit, self.max_page_size)
        
        results = self.storage.get_case_history(
            case_id=filters.case_id or "",
            page=(filters.offset // limit) + 1,
            size=limit
        )
        
        if filters.test_id:
            results = {
                'results': [r for r in results.get('history', []) if r.get('test_id') == filters.test_id],
                'total': len(results.get('history', [])),
                'limit': limit,
                'offset': filters.offset
            }
        
        if filters.status:
            results = {
                'results': [r for r in results.get('results', []) or results.get('history', []) if r.get('status') == filters.status],
                'total': len(results.get('results', []) or results.get('history', [])),
                'limit': limit,
                'offset': filters.offset
            }
        
        return results

    def get_bug_reports(self, filters: BugFilter) -> Dict[str, Any]:
        """获取Bug报告"""
        
        if filters is None:
            filters = BugFilter()
        
        return self.storage.get_bugs(
            project=filters.project,
            version=filters.version,
            case_id=filters.case_id,
            test_id=filters.test_id,
            status=filters.status,
            severity=filters.severity,
            limit=filters.limit,
            offset=filters.offset
        )

    def generate_report(self, test_id: str, include_details: bool = False) -> TestReport:
        """生成完整的测试报告"""
        
        batch = self.storage.get_batch(test_id)
        if not batch:
            raise ValueError(f"测试批次不存在: {test_id}")
        
        summary = self._get_summary_for_batch(test_id)
        
        subsystems = []
        if batch.subsystems:
            try:
                import json
                subsystems = json.loads(batch.subsystems)
            except:
                pass
        
        summary_dict = asdict(summary) if isinstance(summary, TestSummary) else summary
        
        return TestReport(
            test_id=batch.id,
            project=batch.project,
            status=batch.status,
            subsystems=subsystems,
            summary=summary_dict,
            report_git_commit=batch.report_git_commit or "",
            bugs=[],
            duration=batch.duration or 0,
            started_at=batch.started_at.isoformat() if batch.started_at else "",
            completed_at=batch.completed_at.isoformat() if batch.completed_at else ""
        )

    def get_case_history(self, case_id: str, page: int, size: int) -> CaseHistoryResult:
        """获取用例的执行历史"""
        
        result = self.storage.get_case_history(case_id, page, size)
        
        history = [
            CaseHistoryItem(
                result_id=r.get('result_id', ''),
                test_id=r.get('test_id', ''),
                version=r.get('version', 'unknown'),
                status=r.get('status', ''),
                duration=r.get('duration', 0),
                executed_at=r.get('executed_at', '')
            )
            for r in result.get('history', [])
        ]
        
        return CaseHistoryResult(
            case_id=case_id,
            history=history,
            total=result.get('total', 0),
            limit=size,
            offset=(page - 1) * size
        )

    def get_test_summary(self, filters: TestFilter) -> TestSummary:
        """获取测试汇总统计"""
        
        stats = self.storage.get_statistics()
        
        return TestSummary(
            passed=stats.get('passed', 0),
            failed=stats.get('failed', 0),
            errors=stats.get('errors', 0),
            skipped=0,
            total=stats.get('total_tests', 0)
        )

    def _get_summary_for_batch(self, test_id: str) -> TestSummary:
        """计算测试批次汇总统计 - 优先从test_results表读取"""
        
        results = self.storage.get_case_history("", 1, 10000)
        batch_results = [r for r in results.get('history', []) if r.get('test_id') == test_id]
        
        if batch_results:
            passed = sum(1 for r in batch_results if r.get('status') == 'passed')
            failed = sum(1 for r in batch_results if r.get('status') == 'failed')
            errors = sum(1 for r in batch_results if r.get('status') == 'error')
            skipped = sum(1 for r in batch_results if r.get('status') == 'skipped')
            return TestSummary(
                passed=passed,
                failed=failed,
                errors=errors,
                skipped=skipped,
                total=len(batch_results)
            )
        
        batch = self.storage.get_batch(test_id)
        if batch and (batch.passed or batch.failed or batch.errors or batch.total):
            return TestSummary(
                passed=batch.passed or 0,
                failed=batch.failed or 0,
                errors=batch.errors or 0,
                skipped=0,
                total=batch.total or 0
            )
        
        return TestSummary(passed=0, failed=0, errors=0, skipped=0, total=0)

    def aggregate_by_project(self, filters: TestFilter) -> List[Dict]:
        """按项目聚合测试结果"""
        
        if filters is None:
            filters = TestFilter()
        
        batches = self.storage.get_all_batches(
            project=filters.project,
            status=filters.status,
            limit=1000,
            offset=0
        )
        
        project_stats = {}
        for batch in batches.get('tests', []):
            project = batch.get('project', 'unknown')
            if project not in project_stats:
                project_stats[project] = {
                    'project': project,
                    'total_tests': 0,
                    'passed': 0,
                    'failed': 0
                }
            
            summary = batch.get('summary', {})
            project_stats[project]['total_tests'] += 1
            project_stats[project]['passed'] += summary.get('passed', 0)
            project_stats[project]['failed'] += summary.get('failed', 0)
        
        return list(project_stats.values())

    def aggregate_by_version(self, project: str) -> List[Dict]:
        """按版本聚合测试结果"""
        
        batches = self.storage.get_all_batches(
            project=project,
            limit=1000,
            offset=0
        )
        
        version_stats = {}
        for batch in batches.get('tests', []):
            version = batch.get('version', 'unknown')
            if version not in version_stats:
                version_stats[version] = {
                    'version': version,
                    'test_count': 0
                }
            version_stats[version]['test_count'] += 1
        
        return list(version_stats.values())
