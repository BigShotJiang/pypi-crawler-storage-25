# TokenBee Python SDK

Official Python SDK for [TokenBee](https://tokenbee.dev) - The Intelligent LLM Inference Gateway with Observability, Compression, and Privacy.

## Features

- **Unified API**: Access multiple LLM providers (OpenAI, Anthropic, Google, Mistral, etc.) through a single interface.
- **Intelligent Compression**: Reduce token usage and latency with context-aware compression.
- **Privacy Guard**: Automatic PII masking and privacy-preserving inference.
- **Built-in Observability**: Automatic tracking of latency, costs, and token usage.

## Installation

```bash
pip install tokenbee-sdk
```

## Quick Start

```python
from tokenbee import TokenBee, TokenBeeModel, CompressionRate

# Initialize the client with your TokenBee API key 
# AND your LLM provider key (Bring Your Own Key - BYOK)
client = TokenBee(
    api_key="your_tokenbee_api_key",
    llm_key="your_llm_provider_key", # e.g. OpenAI or Anthropic key
    compression="auto",
    rate=CompressionRate.MEDIUM
)

# Send a request
response = client.send(
    model=TokenBeeModel.OPENAI_GPT_4O,
    input={
        "messages": [
            {"role": "user", "content": "Explain quantum entanglement in simple terms."}
        ]
    }
)

print(response["choices"][0]["message"]["content"])
```

## Bring Your Own Key (BYOK)

TokenBee is a **stateless** gateway. We do not store your LLM provider API keys in our database. You pass your provider key (OpenAI, Anthropic, etc.) through the SDK's `llm_key` parameter. The SDK sends this in the `X-LLM-Key` header, allowing the TokenBee proxy to forward requests to the provider on your behalf while you maintain full control over your billing and security.

## Advanced Usage

### Compression Control

You can specify the compression rate and method per request:

```python
response = client.send(
    model=TokenBeeModel.ANTHROPIC_CLAUDE_3_5_SONNET,
    input={
        "messages": [...],
        "compression": "on",
        "rate": CompressionRate.HIGH,
        "privacy": True
    }
)
```

### Supported Models

The SDK provides a `TokenBeeModel` enum with popular models:

- `TokenBeeModel.OPENAI_GPT_4O`
- `TokenBeeModel.ANTHROPIC_CLAUDE_3_5_SONNET`
- `TokenBeeModel.GEMINI_2_0_FLASH`
- ... and many others.

## License

MIT
