# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union
from typing_extensions import TypeAlias

__all__ = ["AnyType"]

AnyType: TypeAlias = Union[List[object], str, float, bool, object, None]
