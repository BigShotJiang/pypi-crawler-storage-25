import argparse


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="svci",
        description="A tool to install Python as SystemD or LaunchD service",
    )
    parser.add_argument(
        "--version", action="version", version="%(prog)s 0.1.0"
    )
    args = parser.parse_args()
    parser.print_help()


if __name__ == "__main__":
    main()
