# svci

Add your description here.

## Installation

```bash
pip install svci
```

## Usage

```python
import svci

print(svci.hello())
```
