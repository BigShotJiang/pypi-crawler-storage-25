from io import BytesIO

from bb_integrations_lib.protocols.pipelines import Step
from bb_integrations_lib.shared.model import RawData


class IncludeFileInReportStep(Step):
    def describe(self) -> str:
        return "Include file in process report"

    async def execute(self, i: RawData) -> RawData:
        content = i.data.getvalue() if isinstance(i.data, BytesIO) else i.data
        if isinstance(content, bytes):
            content = content.decode("utf-8", errors="replace")
        self.pipeline_context.included_files[i.file_name] = content
        return i