from datetime import UTC, datetime

from loguru import logger
from pydantic import BaseModel
from pymongo.asynchronous.database import AsyncDatabase

from bb_integrations_lib.protocols.pipelines import Step
from bb_integrations_lib.shared.model import RawData


class FuelQuestExportLink(BaseModel):
    """FuelQuest export linkage details stored in S&D order_v2 extra_data."""

    exported_at: datetime
    file_name: str
    pipeline_run_id: str


class MarkFuelQuestExportedStep(Step):
    """Marks one order as FuelQuest-exported after a confirmed SFTP upload so subsequent runs skip it."""

    def __init__(
        self,
        mongo_database: AsyncDatabase,
        pipeline_run_id: str,
        export_marker_key: str,
        file_to_order_context_key: str,
        *args,
        **kwargs,
    ):
        self.db = mongo_database
        self.pipeline_run_id = pipeline_run_id
        self.export_marker_key = export_marker_key
        self.file_to_order_context_key = file_to_order_context_key
        super().__init__(*args, **kwargs)

    def describe(self) -> str:
        return "Mark FuelQuest-exported order in Mongo extra_data"

    async def execute(self, i: RawData) -> None:
        file_to_order: dict[str, str] = self.pipeline_context.extra_data.get(
            self.file_to_order_context_key, {}
        )
        order_number = file_to_order.get(i.file_name)
        if order_number is None:
            logger.warning(
                f"No order_number mapping found for file {i.file_name}; skipping mark"
            )
            return

        link = FuelQuestExportLink(
            exported_at=datetime.now(UTC),
            file_name=i.file_name,
            pipeline_run_id=self.pipeline_run_id,
        )
        result = await self.db["order_v2"].update_one(
            filter={"number": int(order_number)},
            update={
                "$set": {
                    f"extra_data.{self.export_marker_key}": link.model_dump(mode="json")
                }
            },
        )
        if result.matched_count == 0:
            logger.warning(
                f"No order_v2 doc matched number={order_number} when marking FuelQuest export"
            )
        else:
            logger.debug(f"Marked order {order_number} exported ({i.file_name})")
