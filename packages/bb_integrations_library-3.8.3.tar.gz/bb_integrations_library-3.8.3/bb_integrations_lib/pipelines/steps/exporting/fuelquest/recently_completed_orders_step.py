from loguru import logger

from bb_integrations_lib.gravitate.sd_api import GravitateSDAPI
from bb_integrations_lib.protocols.pipelines import Step
from bb_integrations_lib.shared.model import GetOrderBolsAndDropsRequest


class RecentlyCompletedOrdersStep(Step):
    def __init__(
        self,
        sd_client: GravitateSDAPI,
        payload: GetOrderBolsAndDropsRequest,
        export_marker_key: str | None = None,
        *args,
        **kwargs,
    ):
        self.sd_client = sd_client
        self.payload = payload
        self.export_marker_key = export_marker_key

        super().__init__(*args, **kwargs)

    def describe(self) -> str:
        return "Get orders which have been recently completed"

    async def execute(self, i) -> list[dict]:
        response = await self.sd_client.get_bols_and_drops(self.payload)
        response.raise_for_status()
        orders = response.json()

        if not self.export_marker_key or not orders:
            return orders

        orders_with_extra = await self.sd_client.get_orders_by_numbers(
            [o["order_number"] for o in orders]
        )
        marked = {
            num
            for num, full in orders_with_extra.items()
            if full.get("extra_data", {}).get(self.export_marker_key)
        }
        retained = [o for o in orders if str(o["order_number"]) not in marked]
        skipped = len(orders) - len(retained)
        if skipped:
            logger.info(
                f"Skipped {skipped} already-exported orders "
                f"(extra_data.{self.export_marker_key} present)"
            )
        return retained
