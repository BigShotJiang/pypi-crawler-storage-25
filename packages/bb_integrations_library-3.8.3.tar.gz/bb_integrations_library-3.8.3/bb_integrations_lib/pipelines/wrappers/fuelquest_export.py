import uuid

from pymongo.asynchronous.database import AsyncDatabase

from bb_integrations_lib.gravitate.rita_api import GravitateRitaAPI
from bb_integrations_lib.gravitate.sd_api import GravitateSDAPI
from bb_integrations_lib.models.fuelquest import FuelQuestConfig
from bb_integrations_lib.pipelines.steps.exporting.fuelquest.mark_fuelquest_exported_step import (
    MarkFuelQuestExportedStep,
)
from bb_integrations_lib.pipelines.steps.exporting.fuelquest.recently_completed_orders_step import (
    RecentlyCompletedOrdersStep,
)
from bb_integrations_lib.pipelines.steps.exporting.fuelquest_export_delivery_plan_step import (
    FuelQuestExportDeliveryPlanStep,
)
from bb_integrations_lib.pipelines.steps.exporting.save_rawdata_to_disk import (
    SaveRawDataToDiskStep,
)
from bb_integrations_lib.pipelines.steps.exporting.sftp_export_file_step import (
    SFTPExportFileStep,
)
from bb_integrations_lib.protocols.pipelines import JobPipeline
from bb_integrations_lib.provider.ftp.client import FTPIntegrationClient
from bb_integrations_lib.secrets import SecretProvider
from bb_integrations_lib.shared.model import GetOrderBolsAndDropsRequest


class GenericFuelQuestExportPipeline(JobPipeline):
    """
    Reusable FuelQuest delivery-plan export pipeline.

    Pipeline flow:
        1. get_orders_to_export     - Fetch recently completed orders from S&D
                                      (skips orders already marked exported).
        2. generate_fuelquest_export - Build the FuelQuest delivery-plan file.
        3. ftp_export / save_to_disk - SFTP upload (prod) or local save (test).
        4. mark_exported (prod only) - Mark each order exported in Mongo.
    """

    @classmethod
    async def create(
        cls,
        config_id: str,
        tenant_name: str,
        rita_client: GravitateRitaAPI,
        sd_client: GravitateSDAPI,
        ftp_client: FTPIntegrationClient,
        mongo_db: AsyncDatabase,
        secret_provider: SecretProvider,
        pipeline_config: FuelQuestConfig,
        payload: GetOrderBolsAndDropsRequest,
        test_order_numbers: list[int] | None = None,
        send_reports: bool = True,
        export_marker_key: str = "fuelquest_exported",
        file_to_order_context_key: str = "fuelquest_file_to_order",
    ):
        is_test = test_order_numbers is not None
        pipeline_run_id = str(uuid.uuid4())

        steps = [
            {
                "id": "get_orders_to_export",
                "parent_id": None,
                "step": RecentlyCompletedOrdersStep(
                    sd_client=sd_client,
                    payload=payload,
                    export_marker_key=None if is_test else export_marker_key,
                ),
            },
            {
                "id": "generate_fuelquest_export",
                "parent_id": "get_orders_to_export",
                "step": FuelQuestExportDeliveryPlanStep(
                    rita_client=rita_client,
                    sd_client=sd_client,
                    config=pipeline_config,
                    config_id=config_id,
                    file_to_order_context_key=(
                        None if is_test else file_to_order_context_key
                    ),
                ),
            },

        ]

        if is_test:
            steps.append(
                {
                    "id": "save_to_disk",
                    "parent_id": "generate_fuelquest_export",
                    "step": SaveRawDataToDiskStep(),
                }
            )
        else:
            ftp_step = {
                    "id": "ftp_export",
                    "parent_id": "generate_fuelquest_export",
                    "step": SFTPExportFileStep(
                        ftp_client=ftp_client,
                        ftp_destination_dir=pipeline_config.ftp_destination_dir,
                    ),
                }
            mark_order_step = {
                    "id": "mark_exported",
                    "parent_id": "ftp_export",
                    "alt_input": "generate_fuelquest_export",
                    "step": MarkFuelQuestExportedStep(
                        mongo_database=mongo_db,
                        pipeline_run_id=pipeline_run_id,
                        export_marker_key=export_marker_key,
                        file_to_order_context_key=file_to_order_context_key,
                    ),
                }
            steps.extend([ftp_step, mark_order_step])

        return cls(
            job_steps=steps,
            rita_client=rita_client,
            secret_provider=secret_provider,
            pipeline_name=f"{tenant_name} FuelQuest Export",
            pipeline_config_id=config_id,
            catch_step_errors=True,
            send_reports=send_reports,
        )