import polars as pl


class StandardReadingParser:
    """PDI-compatible standard format parser.

    Produces columns: Store Number, Name, Tank Id, Tank Product, Carrier,
    Volume, Ullage, Read Time, and optionally Water / Disconnected.
    """

    def __init__(
        self,
        disconnected_column: bool = False,
        disconnected_only: bool = False,
        water_level_column: bool = False,
    ):
        self.disconnected_column = disconnected_column
        self.disconnected_only = disconnected_only
        self.water_level_column = water_level_column

    def parse(self, df: pl.DataFrame) -> pl.DataFrame:
        column_order = [
            "Store Number",
            "Name",
            "Tank Id",
            "Tank Product",
            "Carrier",
            "Volume",
            "Ullage",
            "Read Time",
        ]

        if self.water_level_column:
            column_order.append("Water")

        if self.disconnected_column:
            column_order.append("Disconnected")

        if self.disconnected_only:
            df = df.filter(pl.col("Disconnected") == True)

        return df.select(column_order)
