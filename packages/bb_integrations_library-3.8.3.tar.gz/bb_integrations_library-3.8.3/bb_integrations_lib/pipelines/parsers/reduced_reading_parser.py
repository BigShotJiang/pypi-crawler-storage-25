import polars as pl


class ReducedReadingParser:
    """Minimal column format parser with ISO timestamps."""

    def parse(self, df: pl.DataFrame) -> pl.DataFrame:
        df = df.with_columns(
            [
                (
                    pl.col("Read Time")
                    .str.replace(" UTC", "")
                    .str.to_datetime(format="%Y-%m-%d %H:%M:%S %z")
                    .dt.convert_time_zone("UTC")
                    .dt.strftime("%Y-%m-%dT%H:%M:%S.%3f")
                    .str.replace(r"\.(\d{3})\d*$", ".$1")
                    + pl.lit("Z")
                ).alias("read_time")
            ]
        )

        return df.select(
            [
                pl.col("Store Number").alias("store_number"),
                pl.col("Tank Id").alias("tank_id"),
                pl.col("read_time"),
                pl.col("Volume").alias("volume"),
            ]
        )
