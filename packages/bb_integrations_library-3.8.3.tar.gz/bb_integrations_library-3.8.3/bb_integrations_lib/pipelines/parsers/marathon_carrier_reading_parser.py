import polars as pl


class MarathonCarrierReadingParser:
    """Parser for Marathon Carrier export format.

    Produces columns: SiteNumber, SiteName, TankNum, Commodity, LastReading, LastReadingDate
    """

    def parse(self, df: pl.DataFrame) -> pl.DataFrame:
        return df.select([
            pl.col("Store Number").alias("SiteNumber"),
            pl.col("Name").alias("SiteName"),
            pl.col("Tank Id").alias("TankNum"),
            pl.col("Tank Product").alias("Commodity"),
            pl.col("Read Time").alias("LastReadingDate"),
            pl.col("Volume").cast(pl.Int64).alias("LastReading"),
        ])
