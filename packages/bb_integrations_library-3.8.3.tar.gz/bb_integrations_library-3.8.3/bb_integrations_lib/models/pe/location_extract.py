from typing import Optional

from bb_integrations_lib.models.pe.common import (
    EntityQueryConfig,
    MiddlewareAttribute,
    PEBaseModel,
)


class LocationQueryConfig(EntityQueryConfig):
    location_type_meanings: list[str] = []
    address_type_priority: list[str] = ["Shipping"]

    def to_payload(self) -> dict:
        p = super().to_payload()
        if self.location_type_meanings:
            p["LocationTypeMeanings"] = self.location_type_meanings
        return p


class PhoneDto(PEBaseModel):
    phone_type_meaning: Optional[str] = None
    phone_number: Optional[str] = None


class AddressDto(PEBaseModel):
    address_type_meaning: Optional[str] = None
    address_line1: Optional[str] = None
    address_line2: Optional[str] = None
    city: Optional[str] = None
    state_code: Optional[str] = None
    postal_code: Optional[str] = None
    country_code: Optional[str] = None
    country_name: Optional[str] = None


class LocationContactInfo(PEBaseModel):
    contact_name: Optional[str] = None
    phones: list[PhoneDto] = []
    addresses: list[AddressDto] = []


class LocationExtractDto(PEBaseModel):
    location_id: Optional[int] = None
    name: Optional[str] = None
    abbreviation: Optional[str] = None
    is_active: Optional[bool] = None
    country_code: Optional[str] = None
    state_province: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    time_zone_code: Optional[str] = None
    terminal_control_number: Optional[str] = None
    location_type_meaning: Optional[str] = None
    source_system_id: Optional[int] = None
    source_system_name: Optional[str] = None
    source_id: Optional[int] = None
    source_id_string: Optional[str] = None
    middleware_attributes: list[MiddlewareAttribute] = []
    contact_info: Optional[LocationContactInfo] = None
