from typing import Optional

from bb_integrations_lib.models.pe.common import (
    EntityQueryConfig,
    MiddlewareAttribute,
    PEBaseModel,
)


class ProductQueryConfig(EntityQueryConfig):
    product_type_meanings: list[str] = []

    def to_payload(self) -> dict:
        p = super().to_payload()
        if self.product_type_meanings:
            p["ProductTypeMeanings"] = self.product_type_meanings
        return p


class ProductExtractDto(PEBaseModel):
    product_id: Optional[int] = None
    name: Optional[str] = None
    abbreviation: Optional[str] = None
    is_active: Optional[bool] = None
    sort_order: Optional[int] = None
    product_type_meaning: Optional[str] = None
    source_system_id: Optional[int] = None
    source_system_name: Optional[str] = None
    source_id: Optional[int] = None
    source_id_string: Optional[str] = None
    middleware_attributes: list[MiddlewareAttribute] = []
