from typing import Optional
from pydantic import Field

from bb_integrations_lib.models.pe.common import (
    EntityQueryConfig,
    MiddlewareAttribute,
    PEBaseModel,
)


class CounterpartyQueryConfig(EntityQueryConfig):
    category_meanings: list[str] = []

    def to_payload(self) -> dict:
        p = super().to_payload()
        if self.category_meanings:
            p["CategoryMeanings"] = self.category_meanings
        return p


class CounterPartyCreditDto(PEBaseModel):
    credit_limit: Optional[float] = None
    # `to_pascal` would produce "ArBalance"; PE uses the acronym form.
    ar_balance: Optional[float] = Field(default=None, alias="ARBalance")
    credit_watch_percentage: Optional[float] = None
    credit_hold_percentage: Optional[float] = None
    credit_status_meaning: Optional[str] = None
    credit_status_override_meaning: Optional[str] = None
    is_active: Optional[bool] = None


class CounterPartyExtractDto(PEBaseModel):
    counter_party_id: Optional[int] = None
    name: Optional[str] = None
    abbreviation: Optional[str] = None
    is_active: Optional[bool] = None
    category_meaning: Optional[str] = None
    source_system_id: Optional[int] = None
    source_system_name: Optional[str] = None
    source_id: Optional[int] = None
    source_id_string: Optional[str] = None
    credit: Optional[CounterPartyCreditDto] = None
    middleware_attributes: list[MiddlewareAttribute] = []
