"""
Shonglish AI - African Code-Switching TTS
Revolutionary voice AI with emotional intelligence for Zimbabwe and beyond.

Get started: https://shonglish.ai
"""

__version__ = "0.0.1"
