__version__ = "0.0.1.dev0"

def hello():
    return 'Hello from rocm-sdk-device-gfx1010!'
