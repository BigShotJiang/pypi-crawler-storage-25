"""Biotailor Python SDK — programmatic access to the Biotailor bioinformatics platform."""

from biotailor.client import BiotailorClient
from biotailor.exceptions import (
    BiotailorAPIError,
    BiotailorError,
    BiotailorUploadError,
    BiotailorValidationError,
)
from biotailor.models import (
    Dataset,
    DefaultHardware,
    Job,
    JobStatus,
    Option,
    Output,
    ToolConfig,
    ToolParameter,
    Validation,
)
from biotailor.pipeline import Pipeline

__all__ = [
    "BiotailorClient",
    "BiotailorAPIError",
    "BiotailorError",
    "BiotailorUploadError",
    "BiotailorValidationError",
    "Dataset",
    "DefaultHardware",
    "Job",
    "JobStatus",
    "Option",
    "Output",
    "Pipeline",
    "ToolConfig",
    "ToolParameter",
    "Validation",
]

__version__ = "0.1.0"
