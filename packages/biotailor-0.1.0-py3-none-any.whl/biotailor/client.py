"""Biotailor API client."""

from __future__ import annotations

import json as _json
import logging
import re
import time
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger("biotailor")

from biotailor.exceptions import BiotailorAPIError, BiotailorValidationError
from biotailor.models import (
    Dataset,
    Job,
    JobStatus,
    ToolConfig,
    parse_dataset,
    parse_job,
    parse_tool_config,
)
from biotailor.pipeline import Pipeline
from biotailor.uploader import upload_files

__version__ = "0.1.0"

_API_KEY_PATTERN = re.compile(r"^btk_[a-fA-F0-9]+\.sk_[a-fA-F0-9]+$")


class BiotailorClient:
    """Main client for interacting with the Biotailor API.

    Args:
        api_key: API key in the format ``btk_<id>.sk_<secret>``.
        base_url: Base URL of the Biotailor API.
        timeout: Default request timeout in seconds.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.biotailor.com",
        timeout: int = 30,
        debug: bool = False,
    ):
        if not _API_KEY_PATTERN.match(api_key):
            raise BiotailorValidationError(
                "Invalid API key format. Expected 'btk_<id>.sk_<secret>'."
            )
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._debug = debug

        if debug:
            logging.basicConfig(
                level=logging.DEBUG,
                format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
            )
            logger.setLevel(logging.DEBUG)
        else:
            logger.setLevel(logging.WARNING)

        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": f"biotailor-python/{__version__}",
            }
        )

    # ------------------------------------------------------------------
    # Internal HTTP helpers
    # ------------------------------------------------------------------

    def _url(self, path: str) -> str:
        return f"{self._base_url}/{path.lstrip('/')}"

    def _log_request(self, method: str, url: str, body: Any = None) -> None:
        if not self._debug:
            return
        # Mask the API key in logged headers
        headers = dict(self._session.headers)
        if "Authorization" in headers:
            token = headers["Authorization"]
            # Show first 10 chars + last 4 chars of the key
            if isinstance(token, str) and len(token) > 20:
                headers["Authorization"] = token[:17] + "..." + token[-4:]
        logger.debug(">> %s %s", method, url)
        logger.debug("   Headers: %s", headers)
        if body is not None:
            logger.debug("   Body: %s", _json.dumps(body, indent=2, default=str))

    def _log_response(self, resp: requests.Response) -> None:
        if not self._debug:
            return
        logger.debug("<< %s %s", resp.status_code, resp.reason)
        logger.debug("   Response headers: %s", dict(resp.headers))
        try:
            logger.debug("   Response body: %s", resp.text[:2000])
        except Exception:
            logger.debug("   Response body: <unreadable>")

    def _handle_response(self, resp: requests.Response) -> Any:
        self._log_response(resp)
        if resp.status_code >= 400:
            try:
                body = resp.text
            except Exception:
                body = ""
            raise BiotailorAPIError(
                status_code=resp.status_code,
                message=resp.reason or "Unknown error",
                response_body=body,
            )
        if resp.status_code == 204 or not resp.content:
            return None
        return resp.json()

    def _get(self, path: str, **kwargs: Any) -> Any:
        url = self._url(path)
        self._log_request("GET", url)
        resp = self._session.get(url, timeout=self._timeout, **kwargs)
        return self._handle_response(resp)

    def _post(self, path: str, json: Any = None, **kwargs: Any) -> Any:
        url = self._url(path)
        self._log_request("POST", url, body=json)
        resp = self._session.post(url, json=json, timeout=self._timeout, **kwargs)
        return self._handle_response(resp)

    def _patch(self, path: str, json: Any = None, **kwargs: Any) -> Any:
        url = self._url(path)
        self._log_request("PATCH", url, body=json)
        resp = self._session.patch(url, json=json, timeout=self._timeout, **kwargs)
        return self._handle_response(resp)

    def _delete(self, path: str, **kwargs: Any) -> Any:
        url = self._url(path)
        self._log_request("DELETE", url)
        resp = self._session.delete(url, timeout=self._timeout, **kwargs)
        return self._handle_response(resp)

    # ------------------------------------------------------------------
    # Tools
    # ------------------------------------------------------------------

    def list_tools(self) -> List[ToolConfig]:
        """List all available bioinformatics tools.

        Returns:
            List of ToolConfig objects.
        """
        data = self._get("tools")
        if isinstance(data, list):
            return [parse_tool_config(t) for t in data]
        return []

    def get_tool(self, tool_id: str) -> ToolConfig:
        """Get a single tool config by ID.

        Args:
            tool_id: The tool identifier (e.g. ``"fastp-single"``).

        Returns:
            ToolConfig for the requested tool.

        Raises:
            BiotailorAPIError: If the tool is not found.
        """
        data = self._get(f"tools/{tool_id}")
        return parse_tool_config(data)

    # ------------------------------------------------------------------
    # Datasets
    # ------------------------------------------------------------------

    def list_datasets(self) -> List[Dataset]:
        """List all available datasets.

        Returns:
            List of Dataset objects.
        """
        data = self._get("datasets")
        if isinstance(data, list):
            return [parse_dataset(d) for d in data]
        return []

    # ------------------------------------------------------------------
    # Jobs — CRUD
    # ------------------------------------------------------------------

    def list_jobs(self) -> List[Job]:
        """List all jobs for the authenticated user.

        Returns:
            List of Job objects.
        """
        data = self._get("jobs")
        if isinstance(data, list):
            return [parse_job(j) for j in data]
        return []

    def get_job(self, job_id: str) -> Job:
        """Get a single job by ID.

        Args:
            job_id: The job identifier.

        Returns:
            Job object with current status and metadata.
        """
        data = self._get(f"jobs/{job_id}")
        if isinstance(data, dict) and "jobid" not in data:
            data["jobid"] = job_id
        return parse_job(data)

    def cancel_job(self, job_id: str) -> None:
        """Cancel a running job.

        Args:
            job_id: The job identifier.
        """
        self._post(f"jobs/{job_id}/cancel")

    # ------------------------------------------------------------------
    # Jobs — Run Pipeline
    # ------------------------------------------------------------------

    def run(self, pipeline: Pipeline, show_progress: bool = True) -> Job:
        """Execute a pipeline: create job, submit workflow, upload files.

        Args:
            pipeline: A configured Pipeline object.
            show_progress: Whether to show upload progress bars.

        Returns:
            Job object with the initial status.
        """
        workflow_json = pipeline.build_workflow()

        # Step A: Create job
        create_body: Dict[str, Any] = {
            "jobName": pipeline.name,
            "orgid": "null",
            "isprivate": True,
        }
        create_resp = self._post("jobs", json=create_body)
        job_id: str = create_resp["jobid"]

        # Step B: Submit workflow + get upload URLs
        run_body: Dict[str, Any] = {
            "workflow": workflow_json,
            "reactFlowWorkflow": {
                "nodes": [],
                "edges": [],
                "viewport": {"x": 0, "y": 0, "zoom": 1},
            },
        }
        run_resp = self._post(f"jobs/{job_id}/run", json=run_body)
        job_status = run_resp.get("jobStatus", "UPLOADING")

        # Step C: Upload files if needed
        upload_urls = run_resp.get("uploadURLs", [])
        upload_headers = run_resp.get("uploadHeaders", {})

        if upload_urls:
            multipart_results = upload_files(
                upload_urls=upload_urls,
                upload_headers=upload_headers,
                file_map=pipeline.get_file_map(),
                show_progress=show_progress,
            )
            logger.debug("Files uploaded: %s", multipart_results)

            # Step D: Confirm uploads (always called — backend needs this to advance job status)
            confirm_body: Dict[str, Any] = {"multipartFiles": multipart_results}
            self._post(f"jobs/{job_id}/confirm-uploaded", json=confirm_body)

        return Job(
            jobid=job_id,
            job_name=pipeline.name,
            job_status=JobStatus(job_status),
        )

    # ------------------------------------------------------------------
    # Jobs — Monitoring
    # ------------------------------------------------------------------

    def wait_for_completion(
        self,
        job_id: str,
        poll_interval: int = 10,
        timeout: Optional[int] = None,
        verbose: bool = True,
    ) -> Job:
        """Poll until a job reaches a terminal status.

        Args:
            job_id: The job identifier.
            poll_interval: Seconds between polls.
            timeout: Maximum seconds to wait (None = unlimited).
            verbose: Print status updates to stdout.

        Returns:
            Job in a terminal state.

        Raises:
            TimeoutError: If timeout is exceeded.
        """
        start = time.monotonic()
        last_status = None

        while True:
            job = self.get_job(job_id)
            if verbose and job.job_status != last_status:
                print(f"[biotailor] Job {job_id}: {job.job_status.value}")
                last_status = job.job_status

            if job.job_status in JobStatus.terminal_statuses():
                return job

            if timeout is not None and (time.monotonic() - start) >= timeout:
                raise TimeoutError(
                    f"Job {job_id} did not complete within {timeout}s "
                    f"(last status: {job.job_status.value})"
                )

            time.sleep(poll_interval)

    # ------------------------------------------------------------------
    # Jobs — Logs
    # ------------------------------------------------------------------

    def get_job_logs(self, job_id: str, process_id: str) -> str:
        """Fetch logs for a specific process within a job.

        Args:
            job_id: The job identifier.
            process_id: The process identifier.

        Returns:
            Log content as a string.
        """
        data = self._get(f"jobs/{job_id}/processes/{process_id}/logs")
        if isinstance(data, str):
            return data
        if isinstance(data, dict):
            return data.get("logs", data.get("log", str(data)))
        return str(data)

    # ------------------------------------------------------------------
    # Jobs — Outputs
    # ------------------------------------------------------------------

    def get_output_file_sizes(self, job_id: str) -> List[Dict[str, Any]]:
        """Get file sizes for all outputs of a job.

        Args:
            job_id: The job identifier.

        Returns:
            Dict mapping output keys to size information.
        """
        data = self._get(f"jobs/{job_id}/outputs/fileSize")
        return data if isinstance(data, list) else []

    def download_outputs(
        self,
        job_id: str,
        output_dir: str,
        process_id: Optional[str] = None,
        show_progress: bool = True,
    ) -> List[str]:
        """Download output files from a completed job.

        Args:
            job_id: The job identifier.
            output_dir: Local directory to save files to.
            process_id: If provided, download only outputs from this process.
            show_progress: Whether to show download progress bars.

        Returns:
            List of downloaded file paths.
        """
        import os

        if process_id:
            path = f"jobs/{job_id}/processes/{process_id}/outputs/request-download"
        else:
            path = f"jobs/{job_id}/outputs/request-download"

        data = self._post(path)
        if not isinstance(data, list):
            data = []

        # Flatten into a list of {id, url} items.
        # With process_id: response is [{id, url}, ...]
        # Without process_id: response is [{processId, outputs: [{id, url}, ...]}, ...]
        items: List[Dict[str, Any]] = []
        if process_id:
            items = data
        else:
            for process_entry in data:
                items.extend(process_entry.get("outputs", []))

        os.makedirs(output_dir, exist_ok=True)
        downloaded: List[str] = []

        for item in items:
            url = item.get("url", "")
            name = item.get("id", "")
            if not name:
                name = url.split("?")[0].rsplit("/", 1)[-1]

            dest = os.path.join(output_dir, name)
            _download_file(url, dest, show_progress=show_progress)
            downloaded.append(dest)

        return downloaded

    # ------------------------------------------------------------------
    # Convenience — run_and_wait
    # ------------------------------------------------------------------

    def run_and_wait(
        self,
        pipeline: Pipeline,
        output_dir: Optional[str] = None,
        poll_interval: int = 10,
        show_progress: bool = True,
    ) -> Job:
        """Run a pipeline and wait for it to complete (optionally download outputs).

        Args:
            pipeline: A configured Pipeline object.
            output_dir: If provided, download outputs on success.
            poll_interval: Seconds between status polls.
            show_progress: Whether to show progress bars.

        Returns:
            Job in a terminal state.
        """
        job = self.run(pipeline, show_progress=show_progress)
        job = self.wait_for_completion(job.jobid, poll_interval=poll_interval)

        if output_dir and job.job_status == JobStatus.SUCCEEDED:
            self.download_outputs(job.jobid, output_dir, show_progress=show_progress)

        return job


def _download_file(url: str, dest: str, show_progress: bool = True) -> None:
    """Download a file from a URL to a local path."""
    resp = requests.get(url, stream=True, timeout=300)
    resp.raise_for_status()
    total = int(resp.headers.get("content-length", 0))

    if show_progress:
        try:
            from tqdm import tqdm

            import os

            pbar = tqdm(
                total=total,
                unit="B",
                unit_scale=True,
                desc=os.path.basename(dest),
            )
        except ImportError:
            pbar = None
    else:
        pbar = None

    with open(dest, "wb") as f:
        for chunk in resp.iter_content(chunk_size=8192):
            f.write(chunk)
            if pbar:
                pbar.update(len(chunk))

    if pbar:
        pbar.close()
