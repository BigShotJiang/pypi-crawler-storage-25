"""Exception hierarchy for the Biotailor SDK."""


class BiotailorError(Exception):
    """Base exception for all Biotailor SDK errors."""


class BiotailorAPIError(BiotailorError):
    """Raised when the Biotailor API returns a non-2xx response."""

    def __init__(self, status_code: int, message: str, response_body: str = ""):
        self.status_code = status_code
        self.message = message
        self.response_body = response_body
        super().__init__(f"API error {status_code}: {message}")


class BiotailorValidationError(BiotailorError):
    """Raised for client-side validation failures."""


class BiotailorUploadError(BiotailorError):
    """Raised when a file upload to S3 fails."""
