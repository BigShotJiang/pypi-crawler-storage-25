"""Data models for the Biotailor SDK, mirroring backend types."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Union


# ---------------------------------------------------------------------------
# Job Status
# ---------------------------------------------------------------------------

class JobStatus(str, Enum):
    BUILDING = "BUILDING"
    UPLOADING = "UPLOADING"
    STARTING = "STARTING"
    RUNNING = "RUNNING"
    FAILED = "FAILED"
    SUCCEEDED = "SUCCEEDED"
    CANCELLED = "CANCELLED"

    @classmethod
    def terminal_statuses(cls) -> set[JobStatus]:
        return {cls.SUCCEEDED, cls.FAILED, cls.CANCELLED}


# ---------------------------------------------------------------------------
# Tool Config models
# ---------------------------------------------------------------------------

@dataclass
class Option:
    display_name: str
    value: Union[str, int, bool]
    description: Optional[str] = None


@dataclass
class Validation:
    required: Optional[bool] = None
    maximum: Optional[float] = None
    minimum: Optional[float] = None
    options: Optional[List[Option]] = None
    accepted_input_types: Optional[List[str]] = None
    accepted_compression_method: Optional[List[str]] = None


@dataclass
class ToolParameter:
    id: str
    display_name: str
    type: str  # 'string' | 'number' | 'boolean' | 'file' | 'string[]' | 'number[]'
    description: Optional[str] = None
    default_value: Optional[Any] = None
    is_pair_end_only: Optional[bool] = None
    is_single_end_only: Optional[bool] = None
    validation: Optional[Validation] = None
    alias: Optional[List[str]] = None


@dataclass
class Output:
    id: str
    display_name: str
    description: Optional[str] = None
    is_pair_end_only: Optional[bool] = None
    is_single_end_only: Optional[bool] = None
    file_type: Optional[str] = None
    file_name: Optional[str] = None
    compression_method: Optional[str] = None
    alias: Optional[List[str]] = None


@dataclass
class DefaultHardware:
    cpu: int
    ram_in_gb: int


@dataclass
class ToolConfig:
    toolid: str
    display_name: str
    category: str
    has_sepe: bool
    default_hardware: DefaultHardware
    parameters: List[ToolParameter] = field(default_factory=list)
    outputs: List[Output] = field(default_factory=list)
    description: Optional[str] = None


# ---------------------------------------------------------------------------
# Job model
# ---------------------------------------------------------------------------

@dataclass
class Job:
    jobid: str
    job_name: str
    job_status: JobStatus
    userid: Optional[str] = None
    orgid: Optional[str] = None
    start_timestamp: Optional[int] = None
    end_timestamp: Optional[int] = None
    workflow: Optional[Dict[str, Any]] = None
    raw: Optional[Dict[str, Any]] = None  # full API response


# ---------------------------------------------------------------------------
# Dataset model
# ---------------------------------------------------------------------------

@dataclass
class Dataset:
    dataset_id: str
    display_name: Optional[str] = None
    description: Optional[str] = None
    dataset_type: Optional[str] = None
    raw: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------------
# Workflow JSON types (used internally by Pipeline builder)
# ---------------------------------------------------------------------------

@dataclass
class Hardware:
    cpu: int
    ramInGB: int  # noqa: N815  — matches backend JSON key
    vmType: Optional[str] = None  # noqa: N815
    moreThan30GBStorage: Optional[bool] = True  # noqa: N815


@dataclass
class WorkflowOutput:
    outputId: str  # noqa: N815


@dataclass
class WorkflowInputFile:
    fileName: str  # noqa: N815
    fileSizeInByte: int  # noqa: N815


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

def _parse_option(data: dict) -> Option:
    return Option(
        display_name=data.get("displayName", ""),
        value=data.get("value", ""),
        description=data.get("description"),
    )


def _parse_validation(data: Optional[dict]) -> Optional[Validation]:
    if data is None:
        return None
    return Validation(
        required=data.get("required"),
        maximum=data.get("maximum"),
        minimum=data.get("minimum"),
        options=[_parse_option(o) for o in data["options"]] if data.get("options") else None,
        accepted_input_types=data.get("acceptedInputTypes"),
        accepted_compression_method=data.get("acceptedCompressionMethod"),
    )


def _parse_tool_parameter(data: dict) -> ToolParameter:
    return ToolParameter(
        id=data["id"],
        display_name=data.get("displayName", ""),
        type=data.get("type", "string"),
        description=data.get("description"),
        default_value=data.get("defaultValue"),
        is_pair_end_only=data.get("isPairEndOnly"),
        is_single_end_only=data.get("isSingleEndOnly"),
        validation=_parse_validation(data.get("validation")),
        alias=data.get("alias"),
    )


def _parse_output(data: dict) -> Output:
    return Output(
        id=data["id"],
        display_name=data.get("displayName", ""),
        description=data.get("description"),
        is_pair_end_only=data.get("isPairEndOnly"),
        is_single_end_only=data.get("isSingleEndOnly"),
        file_type=data.get("fileType"),
        file_name=data.get("fileName"),
        compression_method=data.get("compressionMethod"),
        alias=data.get("alias"),
    )


def parse_tool_config(data: dict) -> ToolConfig:
    hw = data.get("defaultHardware", {})
    return ToolConfig(
        toolid=data["toolid"],
        display_name=data.get("displayName", ""),
        category=data.get("category", ""),
        has_sepe=data.get("hasSEPE", False),
        default_hardware=DefaultHardware(cpu=hw.get("cpu", 2), ram_in_gb=hw.get("ramInGB", 4)),
        parameters=[_parse_tool_parameter(p) for p in data.get("parameters", [])],
        outputs=[_parse_output(o) for o in data.get("outputs", [])],
        description=data.get("description"),
    )


def parse_job(data: dict) -> Job:
    status_str = data.get("jobStatus", data.get("job_status", "BUILDING"))
    try:
        status = JobStatus(status_str)
    except ValueError:
        status = JobStatus.BUILDING
    return Job(
        jobid=data.get("jobid", ""),
        job_name=data.get("jobName", data.get("job_name", "")),
        job_status=status,
        userid=data.get("userid"),
        orgid=data.get("orgid"),
        start_timestamp=data.get("startTimestamp"),
        end_timestamp=data.get("endTimestamp"),
        workflow=data.get("workflow"),
        raw=data,
    )


def parse_dataset(data: dict) -> Dataset:
    return Dataset(
        dataset_id=data.get("datasetid", data.get("datasetId", "")),
        display_name=data.get("displayName"),
        description=data.get("description"),
        dataset_type=data.get("datasetType"),
        raw=data,
    )
