# Copyright 2026 Trossen Robotics
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#
#    * Neither the name of the copyright holder nor the names of its
#      contributors may be used to endorse or promote products derived from
#      this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""Discover command: discovers all arm controllers on a given subnet."""

from typing import Annotated

from rich.table import Table
import typer

import trossen_arm

from ..output import console, err_console


def discover(
    subnet: Annotated[
        str,
        typer.Option(help="Subnet prefix"),
    ] = "192.168.1",
    start: Annotated[
        int,
        typer.Option("--start", min=1, max=254, help="First host octet to probe"),
    ] = 1,
    end: Annotated[
        int,
        typer.Option("--end", min=1, max=254, help="Last host octet to probe"),
    ] = 254,
    timeout: Annotated[
        float,
        typer.Option(help="Per-host connection timeout in seconds"),
    ] = 0.01,
) -> None:
    """Discover connected arm controllers on a subnet."""
    console.print(
        f"Scanning [bold]{subnet}.{start} - {subnet}.{end}[/bold]"
        f"  (timeout={timeout}s)..."
    )

    try:
        discover_results = trossen_arm.TrossenArmDriver.discover(
            subnet=subnet,
            ip_start=start,
            ip_end=end,
            timeout=timeout,
        )
    except Exception as e:
        err_console.print(f"Error: {e}")
        raise typer.Exit(1)

    if not discover_results:
        console.print("No arms found.")
        return

    table = Table(title=f"Found {len(discover_results)} arm(s)")
    table.add_column("IP", no_wrap=True)
    table.add_column("Model")
    table.add_column("Firmware")
    table.add_column("Error State")

    for discover_result in discover_results:
        table.add_row(
            discover_result.ip,
            trossen_arm.MODEL_NAME[discover_result.model],
            discover_result.firmware_version,
            trossen_arm.ERROR_INFORMATION[discover_result.error_state],
        )

    console.print(table)
