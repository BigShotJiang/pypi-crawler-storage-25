# Copyright 2026 Trossen Robotics
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#
#    * Neither the name of the copyright holder nor the names of its
#      contributors may be used to endorse or promote products derived from
#      this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""Identify command: identify an arm by actuating its gripper."""

from enum import Enum
from typing import Annotated

import typer

import trossen_arm

from ..output import console, err_console


class ModelChoice(str, Enum):
    wxai_v0 = "wxai_v0"
    vxai_v0_right = "vxai_v0_right"
    vxai_v0_left = "vxai_v0_left"


class EndEffectorChoice(str, Enum):
    wxai_v0_base = "wxai_v0_base"
    wxai_v0_leader = "wxai_v0_leader"
    wxai_v0_follower = "wxai_v0_follower"
    vxai_v0_base = "vxai_v0_base"
    no_gripper = "no_gripper"


def identify(
    ip: Annotated[
        str,
        typer.Option("--ip", help="Arm IP address"),
    ],
    model: Annotated[
        ModelChoice,
        typer.Option(help="Arm model"),
    ] = ModelChoice.wxai_v0,
    end_effector: Annotated[
        EndEffectorChoice,
        typer.Option(help="End effector type"),
    ] = EndEffectorChoice.wxai_v0_leader,
) -> None:
    """Identify an arm at the given IP by opening and closing its gripper."""
    console.print(f"Connecting to arm at [bold]{ip}[/bold]...")

    try:
        driver = trossen_arm.TrossenArmDriver()
        driver.configure(
            model=getattr(trossen_arm.Model, model.value),
            end_effector=getattr(trossen_arm.StandardEndEffector, end_effector.value),
            serv_ip=ip,
            clear_error=False,
        )

        driver.set_all_modes(trossen_arm.Mode.position)

        driver.set_gripper_position(0.030, 2.0, True)

        driver.set_gripper_position(0.010, 2.0, True)

        console.print("Done.")
    except Exception as e:
        err_console.print(f"Error: {e}")
        raise typer.Exit(1)
