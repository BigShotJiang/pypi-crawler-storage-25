# Copyright 2026 Trossen Robotics
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#
#    * Neither the name of the copyright holder nor the names of its
#      contributors may be used to endorse or promote products derived from
#      this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

"""Main CLI app definition."""

import sys

try:
    import typer
    import typer.rich_utils
except ImportError:
    print(
        "Error: CLI dependencies are not installed.\n"
        "Install them with: pip install \"trossen_arm[cli]\"",
        file=sys.stderr,
    )
    sys.exit(1)

import trossen_arm

for notice in trossen_arm.Notice.__members__.values():
    trossen_arm.TrossenArmDriver.disable_notice(notice)

from .commands.discover import discover
from .commands.identify import identify
from .commands.usage import usage

# Override Typer's default styling for better readability on light and dark terminals.
typer.rich_utils.STYLE_ERRORS_PANEL_BORDER = "red1"
typer.rich_utils.STYLE_ERRORS_SUGGESTION = "bold"
typer.rich_utils.RICH_HELP = "Try [bold]'{command_path} {help_option}'[/] for help."

app = typer.Typer(
    name="trossen-arm",
    help="CLI for interacting with Trossen robotic arms.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

app.command()(discover)
app.command()(identify)
app.command()(usage)


def main() -> None:
    """Main entry point."""
    app()


if __name__ == "__main__":
    main()
