# YouTube Video Thumbnail

A simple youtube video thumbnail downloader with more qualities via youtube video link or id.

## Installation

```sh
pip3 install ytthumb
```

## Usage

### Get Thumbnail

```py
import ytthumb

video = 'https://youtu.be/rokGy0huYEA'  # link/id

# Basic Usage
print(ytthumb.get_thumbnail_url(video))
# => returns thumbnail link

# Advanced Usage
thumbnail = ytthumb.get_thumbnail_url(
    video=video,
    quality="sd"  # Not required
)
print(thumbnail)
# returns thumbnail link
```

### Download Thumbnail

```py
import ytthumb

ytthumb.download_thumbnail(
    video='https://youtu.be/rokGy0huYEA',
    filename='thumbnail.jpg',  # optional
    quality='sd'               # optional
    directory="thumbnails"     # optional
)
# Downloaded thumbnail will be in the 'thumbnail.jpg' file in 'thumbnails' directory
```

### Get Qualities

```py
import ytthumb

print(ytthumb.VALID_QUALITIES)
# return dictionary of qualities with full form
```

Output:

```
{
    "sd": "Standard Quality",
    "mq": "Medium Quality",
    "hq": "High Quality",
    "maxres": "Maximum Resolution",
}
```
