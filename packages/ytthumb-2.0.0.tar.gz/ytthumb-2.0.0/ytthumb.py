import os
import requests
import warnings
from urllib.parse import urlparse, parse_qs


VALID_QUALITIES = {
    "sd": "Standard Quality",
    "mq": "Medium Quality",
    "hq": "High Quality",
    "maxres": "Maximum Resolution",
}


@warnings.deprecated(
    "qualities() is deprecated, use VALID_QUALITIES directly instead",
    stacklevel=2,
)
def qualities(json=True):
    """
    json:
      True - for return qualities and full form as json (default)
      False - for return only qualities as list
    """

    if not json:
        qualities = []
        for i in VALID_QUALITIES:
            qualities.append(i)
    else:
        qualities = VALID_QUALITIES
    return qualities


def extract_id(video: str) -> str:
    """Extract YouTube video ID from URL or return if already ID."""

    # If already looks like an ID
    if "http" not in video:
        return video

    parsed = urlparse(video)

    # youtu.be/<id>
    if "youtu.be" in parsed.netloc:
        return parsed.path.strip("/")

    # youtube.com/watch?v=<id>
    if "youtube.com" in parsed.netloc:
        query = parse_qs(parsed.query)
        if "v" in query:
            return query["v"][0]

        # /embed/<id>
        if "/embed/" in parsed.path:
            return parsed.path.split("/embed/")[-1]

    raise ValueError("Invalid YouTube URL")


def get_thumbnail_url(video: str, quality: str = "sd") -> str:
    """Return thumbnail URL."""

    video_id = extract_id(video)

    if quality not in VALID_QUALITIES:
        quality = "sd"

    return f"https://img.youtube.com/vi/{video_id}/{quality}default.jpg"


@warnings.deprecated(
    "thumbnail() is deprecated, use get_thumbnail_url() instead",
    stacklevel=2,
)
def thumbnail(video, quality="sd"):
    """
    video:
      id - video id
      link - video link
    quality:
      sd - Standard Quality
      mq - Medium Quality
      hq - High Quality
      maxres - Maximum Resolution
    """
    return get_thumbnail_url(video, quality)


def download_thumbnail(
    video: str,
    filename="thumbnail.jpg",
    name: str | None = None,  # deprecated
    quality="sd",
    directory="thumbnails",
) -> str:
    """Download thumbnail and save locally."""

    if name is not None:
        warnings.warn(
            "name parameter is deprecated, use filename instead",
            FutureWarning,
        )
        filename = name

    url = get_thumbnail_url(video, quality)

    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
    except requests.RequestException as e:
        raise Exception(f"Download failed: {e}")

    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, filename)

    with open(path, "wb") as f:
        f.write(response.content)

    return path
