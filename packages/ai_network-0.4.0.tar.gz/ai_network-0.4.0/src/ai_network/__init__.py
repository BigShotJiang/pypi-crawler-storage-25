"""
AI-Network — DEPRECATED
========================

This package is deprecated. Use `ainternet` instead:

    pip install ainternet

All functionality has moved to the `ainternet` package.
"""

import warnings

warnings.warn(
    "ai-network is deprecated. Install 'ainternet' instead: pip install ainternet",
    DeprecationWarning,
    stacklevel=2,
)

# Still re-export for backwards compatibility
try:
    from ainternet import *
    from ainternet import __version__
except ImportError:
    __version__ = "0.3.0"

__all__ = ["__version__"]
