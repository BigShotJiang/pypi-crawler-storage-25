"""Panda3DEnv — Gymnasium base environment for RL training with Panda3D."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np


class Panda3DEnv:
    """Base class for Panda3D Gymnasium environments.

    Subclass and implement: _define_spaces(), _get_observation(),
    _apply_action(), _compute_reward(), _is_done().
    """

    metadata = {"render_modes": ["human", "rgb_array"]}

    def __init__(self, scene: str | None = None, window_type: str = "none",
                 step_dt: float = 1 / 60, render_mode: str | None = None):
        self.scene_path = scene
        self.step_dt = step_dt
        self.render_mode = render_mode
        self._window_type = "onscreen" if render_mode == "human" else ("offscreen" if render_mode == "rgb_array" else window_type)
        self._base = None
        self._init_engine()
        self.observation_space, self.action_space = self._define_spaces()

    def _init_engine(self) -> None:
        from panda3d.core import loadPrcFileData
        loadPrcFileData("p3d-env", f"window-type {self._window_type}\naudio-library-name none")
        from direct.showbase.ShowBase import ShowBase
        self._base = ShowBase()
        self.scene = self._base.render
        if self.scene_path and Path(self.scene_path).exists():
            from p3d.core.scene_builder import load_scene_yaml, build_scene
            build_scene(load_scene_yaml(self.scene_path), self._base)

    def _define_spaces(self):
        raise NotImplementedError

    def _get_observation(self) -> np.ndarray:
        raise NotImplementedError

    def _apply_action(self, action: Any) -> None:
        raise NotImplementedError

    def _compute_reward(self) -> float:
        raise NotImplementedError

    def _is_done(self) -> bool:
        raise NotImplementedError

    def reset(self, seed=None, options=None):
        if self.scene_path and Path(self.scene_path).exists():
            from p3d.core.scene_builder import load_scene_yaml, build_scene
            build_scene(load_scene_yaml(self.scene_path), self._base)
        return self._get_observation(), {}

    def step(self, action):
        self._apply_action(action)
        from panda3d.core import ClockObject
        ClockObject.getGlobalClock().setDt(self.step_dt)
        self._base.taskMgr.step()
        if self._window_type != "none":
            self._base.graphicsEngine.renderFrame()
        return self._get_observation(), self._compute_reward(), self._is_done(), False, {}

    def render(self):
        if self.render_mode == "rgb_array":
            self._base.graphicsEngine.renderFrame()
            from p3d.env.utils import screenshot_to_numpy
            return screenshot_to_numpy(self._base)
        if self.render_mode == "human":
            self._base.graphicsEngine.renderFrame()

    def close(self):
        if self._base:
            self._base.destroy()
            self._base = None
