"""Environment utilities — screenshot capture, observation helpers."""

from __future__ import annotations

from typing import Any

import numpy as np


def screenshot_to_numpy(base: Any) -> np.ndarray:
    """Capture the current frame as a numpy RGB array."""
    from panda3d.core import GraphicsOutput, Texture

    tex = base.win.getScreenshot()
    if tex is None:
        return np.zeros((1, 1, 3), dtype=np.uint8)

    xsize = tex.getXSize()
    ysize = tex.getYSize()

    image = tex.getRamImageAs("RGB")
    data = np.frombuffer(image, dtype=np.uint8)
    data = data.reshape((ysize, xsize, 3))
    # Panda3D returns bottom-up, flip to top-down
    data = np.flipud(data)
    return data
