# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2026 APlane Project LLC

__version__ = "0.10.0"
