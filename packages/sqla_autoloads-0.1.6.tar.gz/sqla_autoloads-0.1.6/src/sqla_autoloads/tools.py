from __future__ import annotations

from collections.abc import Callable, Sequence
from functools import lru_cache
from typing import Any, Final, TypeVar

import sqlalchemy as sa
from sqlalchemy import orm
from sqlalchemy.sql.selectable import Lateral


T = TypeVar("T", bound=orm.DeclarativeBase)
_R = TypeVar("_R")
_CursorT = TypeVar("_CursorT")


def unique_scalars(result: sa.Result[tuple[_R]]) -> Sequence[_R]:
    """Shorthand for ``result.unique().scalars().all()``.

    Use after ``session.execute(query)`` on queries built by :func:`sqla_select`
    to deduplicate rows produced by outer-join eager loading.

    Example (async)::

        users = unique_scalars(await session.execute(query))

    Example (sync)::

        users = unique_scalars(session.execute(query))
    """
    return result.unique().scalars().all()


@lru_cache
def _get_primary_key(model: type[T]) -> sa.ColumnElement[Any]:
    """Return the first primary-key column element for *model* (cached)."""
    return next(iter(model.__table__.primary_key))


@lru_cache
def _get_table_name(model: type[T]) -> str:
    """Return the table name for *model*, preferring ``__tablename__`` (cached)."""
    result = getattr(
        model,
        "__tablename__",
        model.__table__.description,
    )
    if not result:
        raise ValueError(f"Cannot determine tablename for {model}")

    return result


def get_table_name(model: type[T]) -> str:
    """Get the table name for a SQLAlchemy model.

    Args:
        model: SQLAlchemy model class.

    Returns:
        The table name as a string.

    Raises:
        ValueError: If the table name cannot be determined.
    """
    return _get_table_name(model)


def get_primary_key(model: type[T]) -> sa.ColumnElement[Any]:
    """Get the primary key column for a SQLAlchemy model.

    Args:
        model: SQLAlchemy model class.

    Returns:
        The primary key column element.
    """
    return _get_primary_key(model)


def get_table_names(query: sa.Select[tuple[T]]) -> Sequence[str]:
    """Extract all table names from a SQLAlchemy select query.

    This function traverses the query's FROM clause to identify all tables,
    including those in joins and aliases.

    Args:
        query: SQLAlchemy select query.

    Returns:
        Sequence of table names found in the query.
    """
    seen: set[str] = set()
    out: list[str] = []

    def add(name: str | None) -> None:
        if name and name not in seen:
            seen.add(name)
            out.append(name)

    for root in query.get_final_froms():
        stack: list[Any] = [root]
        while stack:
            node = stack.pop()

            if isinstance(node, sa.Table):
                add(node.name)
                continue

            if isinstance(node, sa.Join):
                stack.extend([node.left, node.right])
                continue

            add(getattr(node, "name", None))
            if hasattr(node, "element"):
                stack.append(node.element)

    return out


def add_conditions(
    *conditions: sa.ColumnExpressionArgument[bool],
) -> Callable[[sa.Select[tuple[T]]], sa.Select[tuple[T]]]:
    """Create a function that adds WHERE conditions to a select query.

    This is a helper function for creating condition functions that can be used
    with the sqla_select function's conditions parameter.

    Args:
        *conditions: SQLAlchemy column expressions that evaluate to boolean.

    Returns:
        A function that takes a select query and returns it with added conditions.

    Example:
        >>> condition_func = add_conditions(Role.active == True, Role.level > 3)
        >>> # Use with sqla_select:
        >>> query = sqla_select(
        ...     model=User, loads=("roles",), conditions={"roles": condition_func}
        ... )
    """

    def _add(query: sa.Select[tuple[T]]) -> sa.Select[tuple[T]]:
        return query.where(*conditions)

    return _add


def _find_from_by_name(root: sa.FromClause, name: str) -> sa.FromClause | None:
    """Find a subquery/alias/lateral/table with *name* in the FROM tree (iterative)."""
    stack: list[sa.FromClause] = [root]
    while stack:
        node = stack.pop()
        if isinstance(node, sa.Join):
            stack.append(node.left)
            stack.append(node.right)
            continue
        if getattr(node, "name", None) == name:
            return node
        element = getattr(node, "element", None)
        if element is not None:
            stack.append(element)
    return None


def resolve_col(query: sa.Select[Any], ref: str) -> sa.ColumnElement[Any]:
    """Resolve ``'alias.column'`` to a bound ColumnElement from *query*.

    Works on queries built by :func:`sqla_select`. Instead of
    ``sa.literal_column("posts.title")``, use::

        col = resolve_col(query, "posts.title")
        query = query.where(col == "hello")

    The *ref* format is ``alias_name.column_name`` where ``alias_name`` is
    the LATERAL/subquery alias (e.g. ``posts``, ``messages_received_messages``,
    ``categories_children``).  These are SQL identifiers — never dotted paths.
    Use ``sqla_laterals(query)`` or ``print(query)`` to discover alias names.

    Raises ``ValueError`` if alias or column not found.
    """
    alias_name, sep, col_name = ref.partition(".")
    if not sep:
        raise ValueError(f"Expected 'alias.column' format, got {ref!r}")
    for root in query.get_final_froms():
        found = _find_from_by_name(root, alias_name)
        if found is not None and hasattr(found, "c"):
            try:
                return found.c[col_name]
            except KeyError:
                raise ValueError(
                    f"Column {col_name!r} not found in alias {alias_name!r}. "
                    f"Available: {[c.key for c in found.c]}"
                ) from None
    raise ValueError(
        f"Alias {alias_name!r} not found in query. Available: {get_table_names(query)}"
    )


def sqla_laterals(query: sa.Select[Any]) -> dict[str, Lateral]:
    """Return ``{alias_name: lateral}`` for all LATERAL joins in *query*."""
    out: dict[str, Lateral] = {}
    for root in query.get_final_froms():
        stack: list[sa.FromClause] = [root]
        while stack:
            node = stack.pop()
            if isinstance(node, sa.Join):
                stack.append(node.left)
                stack.append(node.right)
                continue
            if isinstance(node, Lateral):
                name = getattr(node, "name", None)
                if name:
                    out[name] = node
    return out


# ---------------------------------------------------------------------------
# Pagination helpers
# ---------------------------------------------------------------------------

_PAGINATE_CTE_NAME: Final[str] = "_sqla_page_{name}"


def _resolve_order(
    model: type[T],
    order: tuple[str, str] | None,
) -> tuple[sa.ColumnElement[Any], sa.UnaryExpression[Any]]:
    """Return ``(column, order_clause)`` from an order spec or PK default."""
    if order is None:
        col = get_primary_key(model)
        direction = "asc"
    else:
        col_name, direction = order
        col = getattr(model, col_name)

    return col, getattr(col, direction.lower())()


def sqla_offset_query(
    model: type[T],
    *,
    loads: tuple[str, ...] = (),
    offset: int | None = None,
    limit: int | None = None,
    order: tuple[str, str] | None = None,
    where: Sequence[sa.ColumnExpressionArgument[bool]] = (),
    **sqla_kw: Any,
) -> sa.Select[tuple[T]]:
    """Build a paginated SELECT using offset/limit.

    When *loads* and *limit* are both provided, pagination is done via a CTE
    on the primary-key column so that eager-loading joins operate only on the
    page slice.  Without loads (or without a limit), a plain
    ``SELECT ... LIMIT ... OFFSET`` is returned.

    Args:
        model: SQLAlchemy model class.
        loads: Relationship dotted-paths forwarded to :func:`sqla_select`.
        offset: Number of rows to skip.
        limit: Maximum number of rows to return.
        order: ``("column", "asc"|"desc")``; defaults to ``(PK, "asc")``.
        where: Additional WHERE clauses.
        **sqla_kw: Extra keyword arguments forwarded to :func:`sqla_select`.

    Returns:
        A SQLAlchemy SELECT statement.
    """
    from .core import sqla_select

    col, order_clause = _resolve_order(model, order)

    if not loads or limit is None:
        stmt = sa.select(model).where(*where).order_by(order_clause)
        if limit is not None:
            stmt = stmt.limit(limit)
        if offset is not None:
            stmt = stmt.offset(offset)

        return stmt

    # CTE path: paginate PKs, then join to eager-loaded query
    cte_name = _PAGINATE_CTE_NAME.format(name=_get_table_name(model))
    col_key = col.key
    page_cte = (
        sa.select(col)
        .where(*where)
        .order_by(order_clause)
        .limit(limit)
        .offset(offset)
        .cte(cte_name)
    )

    assert col_key is not None

    return (
        sqla_select(model=model, loads=loads, **sqla_kw)
        .join(page_cte, col == page_cte.c[col_key])
        .order_by(order_clause)
    )


def sqla_cursor_query(
    model: type[T],
    *,
    loads: tuple[str, ...] = (),
    limit: int,
    after: _CursorT | None = None,
    before: _CursorT | None = None,
    order: tuple[str, str] | None = None,
    where: Sequence[sa.ColumnExpressionArgument[bool]] = (),
    **sqla_kw: Any,
) -> sa.Select[tuple[T]]:
    """Build a cursor-paginated SELECT.

    Supports forward (``after``), backward (``before``), or first-page
    (neither) cursors.  The query fetches ``limit + 1`` rows so the caller
    can detect whether more rows exist (``len(rows) > limit``), then slice
    ``rows[:limit]``.  When *before* is used the sort direction is flipped;
    the caller should reverse the result list.

    Args:
        model: SQLAlchemy model class.
        loads: Relationship dotted-paths forwarded to :func:`sqla_select`.
        limit: Page size (the query fetches ``limit + 1``).
        after: Forward cursor value (decoded value of the order column).
        before: Backward cursor value (decoded value of the order column).
        order: ``("column", "asc"|"desc")``; defaults to ``(PK, "asc")``.
        where: Additional WHERE clauses.
        **sqla_kw: Extra keyword arguments forwarded to :func:`sqla_select`.

    Returns:
        A SQLAlchemy SELECT statement.

    Raises:
        ValueError: If both *after* and *before* are provided.
    """
    from .core import sqla_select

    if after is not None and before is not None:
        raise ValueError("Cannot specify both 'after' and 'before' cursors")

    col, _ = _resolve_order(model, order)
    ascending = (order[1] if order else "asc").lower() == "asc"
    fetch_limit = limit + 1

    clauses = list(where)

    if after is not None:
        clauses.append(col > after if ascending else col < after)
        order_clause = col.asc() if ascending else col.desc()
    elif before is not None:
        clauses.append(col < before if ascending else col > before)
        order_clause = col.desc() if ascending else col.asc()  # flip
    else:
        order_clause = col.asc() if ascending else col.desc()

    if not loads:
        return sa.select(model).where(*clauses).order_by(order_clause).limit(fetch_limit)

    # CTE path
    cte_name = _PAGINATE_CTE_NAME.format(name=_get_table_name(model))
    col_key = col.key
    page_cte = (
        sa.select(col).where(*clauses).order_by(order_clause).limit(fetch_limit).cte(cte_name)
    )

    assert col_key is not None

    return (
        sqla_select(model=model, loads=loads, **sqla_kw)
        .join(page_cte, col == page_cte.c[col_key])
        .order_by(order_clause)
    )
