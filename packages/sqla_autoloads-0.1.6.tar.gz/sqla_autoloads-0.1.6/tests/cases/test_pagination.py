from __future__ import annotations

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from sqla_autoloads import sqla_cursor_query, sqla_offset_query

from ..models import Base, User

pytestmark = pytest.mark.anyio


class TestOffsetQuery:
    async def test_offset_no_loads(
        self, session: AsyncSession, seed_data: dict[str, list[Base]]
    ) -> None:
        query = sqla_offset_query(User, offset=0, limit=2)
        result = await session.execute(query)
        users = result.scalars().all()

        assert len(users) == 2
        assert users[0].id == 1
        assert users[1].id == 2

    @pytest.mark.lateral
    async def test_offset_with_loads(
        self, session: AsyncSession, seed_data: dict[str, list[Base]]
    ) -> None:
        query = sqla_offset_query(User, loads=("posts",), offset=0, limit=2)
        result = await session.execute(query)
        users = result.unique().scalars().all()

        assert len(users) == 2
        alice = next(u for u in users if u.name == "alice")
        assert len(alice.posts) == 3

    async def test_offset_second_page(
        self, session: AsyncSession, seed_data: dict[str, list[Base]]
    ) -> None:
        query = sqla_offset_query(User, offset=2, limit=1)
        result = await session.execute(query)
        users = result.scalars().all()

        assert len(users) == 1
        assert users[0].id == 3

    async def test_offset_with_where(
        self, session: AsyncSession, seed_data: dict[str, list[Base]]
    ) -> None:
        query = sqla_offset_query(
            User, limit=10, where=(User.active == True,)  # noqa: E712
        )
        result = await session.execute(query)
        users = result.scalars().all()

        assert all(u.active for u in users)
        assert len(users) == 2

    async def test_offset_no_limit(
        self, session: AsyncSession, seed_data: dict[str, list[Base]]
    ) -> None:
        query = sqla_offset_query(User)
        result = await session.execute(query)
        users = result.scalars().all()

        assert len(users) == 3

    async def test_offset_custom_order(
        self, session: AsyncSession, seed_data: dict[str, list[Base]]
    ) -> None:
        query = sqla_offset_query(User, order=("name", "desc"), limit=2)
        result = await session.execute(query)
        users = result.scalars().all()

        assert users[0].name == "charlie"
        assert users[1].name == "bob"


class TestCursorQueryOneSide:
    async def test_cursor_first_page(
        self, session: AsyncSession, seed_data: dict[str, list[Base]]
    ) -> None:
        query = sqla_cursor_query(User, limit=2)
        result = await session.execute(query)
        users = result.scalars().all()

        # limit+1 fetch: 3 rows returned, caller slices [:2]
        assert len(users) == 3
        assert users[0].id == 1

    async def test_cursor_after(
        self, session: AsyncSession, seed_data: dict[str, list[Base]]
    ) -> None:
        query = sqla_cursor_query(User, limit=10, after=1)
        result = await session.execute(query)
        users = result.scalars().all()

        assert all(u.id > 1 for u in users)

    @pytest.mark.lateral
    async def test_cursor_after_with_loads(
        self, session: AsyncSession, seed_data: dict[str, list[Base]]
    ) -> None:
        query = sqla_cursor_query(User, loads=("posts",), limit=10, after=1)
        result = await session.execute(query)
        users = result.unique().scalars().all()

        assert all(u.id > 1 for u in users)
        bob = next(u for u in users if u.name == "bob")
        assert len(bob.posts) == 1

    async def test_cursor_desc_order(
        self, session: AsyncSession, seed_data: dict[str, list[Base]]
    ) -> None:
        query = sqla_cursor_query(User, limit=2, order=("id", "desc"))
        result = await session.execute(query)
        users = result.scalars().all()

        # desc: 3, 2, 1 → first page limit+1=3
        assert users[0].id == 3


class TestCursorQueryTwoSide:
    async def test_cursor_before(
        self, session: AsyncSession, seed_data: dict[str, list[Base]]
    ) -> None:
        query = sqla_cursor_query(User, limit=10, before=3)
        result = await session.execute(query)
        users = result.scalars().all()

        # before=3 with asc flips to desc, so ids < 3 in desc order
        assert all(u.id < 3 for u in users)
        # flipped sort: highest first
        assert users[0].id == 2

    @pytest.mark.lateral
    async def test_cursor_before_with_loads(
        self, session: AsyncSession, seed_data: dict[str, list[Base]]
    ) -> None:
        query = sqla_cursor_query(User, loads=("posts",), limit=10, before=3)
        result = await session.execute(query)
        users = result.unique().scalars().all()

        assert all(u.id < 3 for u in users)
        alice = next(u for u in users if u.name == "alice")
        assert len(alice.posts) == 3

    async def test_cursor_both_raises(self) -> None:
        with pytest.raises(ValueError, match="Cannot specify both"):
            sqla_cursor_query(User, limit=10, after=1, before=5)
