import requests
from bs4 import BeautifulSoup
from typing import List
from mcp.server.fastmcp import FastMCP

# Initialize FastMCP server
mcp = FastMCP("daum_news_crawler")

@mcp.tool()
def get_crawling(keyword: str, numofpages: int) -> List:
    """
    Daum News titles are collected and stored in a list based on the number of news articles requested.
    
    Args:
        keyword (str): Keywords requested by users for Daum News search.
        numofpages (int): Number of Daum news pages to collect as requested by the user.
        
    Returns:
        list: Collected Daum News Titles.
    """
    daum_crawling = []
    
    for page in range(1, numofpages + 1):
        # Daum search URL structure: p parameter is used for paging
        url = f"https://search.daum.net/search?w=news&q={keyword}&p={page}"
        
        response = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'})
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Selectors for Daum News headlines (Updated for current Daum structure)
        headlines = soup.select("a.tit_main") or soup.select("a.tit-g")
        
        for headline in headlines:
            title = headline.get_text(strip=True)
            if title and title not in daum_crawling:
                daum_crawling.append(title)
                
    return daum_crawling

def main() -> None:
    # Initialize and run the server
    # Important: No print statements to stdout during mcp.run
    mcp.run(transport="stdio")

if __name__ == "__main__":
    main()