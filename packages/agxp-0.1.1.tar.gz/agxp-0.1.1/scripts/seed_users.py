"""
Seed initial system users into PostgreSQL database.
Creates the cold-start system user with fixed ID and admin privileges.

Usage:
    cd /home/ubuntu/agentxp
    source .venv/bin/activate && source .env
    python scripts/seed_users.py [--user-id <uuid>] [--email <email>] [--display-name <name>]
"""
import argparse
import asyncio
import uuid

from agxp.db.pool import get_pool, close_pool


async def seed_system_user(user_id: str, email: str, display_name: str) -> None:
    pool = await get_pool()

    # Check if user already exists
    existing = await pool.fetchrow(
        "SELECT id FROM users WHERE id = $1",
        uuid.UUID(user_id)
    )

    if existing:
        print(f"System user {user_id} already exists, skipping creation")
    else:
        # Create system user
        await pool.execute(
            """
            INSERT INTO users (id, email, display_name, is_active)
            VALUES ($1, $2, $3, true)
            """,
            uuid.UUID(user_id),
            email,
            display_name
        )
        print(f"Created system user: {user_id} ({email})")

    # Check credit account
    existing_account = await pool.fetchrow(
        "SELECT id FROM credit_accounts WHERE user_id = $1",
        uuid.UUID(user_id)
    )

    if existing_account:
        print(f"Credit account for user {user_id} already exists")
    else:
        # Create credit account with unlimited credits
        await pool.execute(
            """
            INSERT INTO credit_accounts (user_id, balance, tier, lifetime_earned)
            VALUES ($1, 999999999, 'admin', 999999999)
            """,
            uuid.UUID(user_id)
        )
        print(f"Created admin credit account for user {user_id} with unlimited credits")

    await close_pool()
    print("Done!")


async def main():
    parser = argparse.ArgumentParser(description="Seed initial system users")
    parser.add_argument(
        "--user-id",
        default="00000000-0000-0000-0000-000000000001",
        help="Fixed UUID for system user (default: 00000000-0000-0000-0000-000000000001)"
    )
    parser.add_argument(
        "--email",
        default="system@agxp.dev",
        help="System user email (default: system@agxp.dev)"
    )
    parser.add_argument(
        "--display-name",
        default="System Cold Start",
        help="System user display name (default: System Cold Start)"
    )
    args = parser.parse_args()

    await seed_system_user(args.user_id, args.email, args.display_name)


if __name__ == "__main__":
    asyncio.run(main())
