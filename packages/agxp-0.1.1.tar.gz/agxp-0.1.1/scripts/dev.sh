#!/usr/bin/env bash
# AGXP Phase 2 development startup script.
#
# Usage:
#   ./scripts/dev.sh              # start all services
#   ./scripts/dev.sh --check-only # validate dependencies only, don't start
#
# Loads .env from project root if present.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

# ── Load .env ──────────────────────────────────────────────────────────
if [ -f .env ]; then
    echo "[dotenv] Loading .env"
    set -a
    . .env
    set +a
else
    echo "[dotenv] No .env file found — using environment variables"
fi

# ── Validate required env vars ─────────────────────────────────────────
if [ -z "${DATABASE_URL:-}" ]; then
    echo "ERROR: DATABASE_URL is not set. Copy .env.example to .env and configure."
    exit 1
fi

# ── Parse DATABASE_URL for pg_isready ──────────────────────────────────
# Extract host and port from DATABASE_URL
DB_HOST=$(echo "$DATABASE_URL" | sed -E 's|.*@([^:/]+).*|\1|')
DB_PORT=$(echo "$DATABASE_URL" | sed -E 's|.*:([0-9]+)/.*|\1|')
[[ "$DB_PORT" =~ ^[0-9]+$ ]] || DB_PORT=5432

# ── Check PostgreSQL ───────────────────────────────────────────────────
echo "[check] PostgreSQL at ${DB_HOST}:${DB_PORT}..."
if pg_isready -h "$DB_HOST" -p "$DB_PORT" -q 2>/dev/null; then
    echo "[check] PostgreSQL: OK"
else
    echo "ERROR: PostgreSQL is not reachable at ${DB_HOST}:${DB_PORT}"
    echo "Start it with: sudo systemctl start postgresql"
    exit 1
fi

# ── Check Redis ────────────────────────────────────────────────────────
REDIS_URL="${REDIS_URL:-redis://localhost:6379/0}"
REDIS_HOST=$(echo "$REDIS_URL" | sed -E 's|redis://([^:/]+).*|\1|')
REDIS_PORT=$(echo "$REDIS_URL" | sed -E 's|redis://[^:]+:([0-9]+).*|\1|')
[[ "$REDIS_PORT" =~ ^[0-9]+$ ]] || REDIS_PORT=6379

echo "[check] Redis at ${REDIS_HOST}:${REDIS_PORT}..."
if redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" ping 2>/dev/null | grep -q PONG; then
    echo "[check] Redis: OK"
else
    echo "WARN: Redis is not reachable at ${REDIS_HOST}:${REDIS_PORT}"
    echo "      Celery tasks will not execute. Service will start in degraded mode."
fi

# ── Run Alembic migration ─────────────────────────────────────────────
echo "[migrate] Running alembic upgrade head..."
python -m alembic upgrade head

# ── --check-only mode ──────────────────────────────────────────────────
if [ "${1:-}" = "--check-only" ]; then
    echo "[check-only] All checks passed. Not starting services."
    exit 0
fi

# ── Start Celery worker (background) ──────────────────────────────────
echo "[start] Celery worker..."
python -m celery -A agxp.workers.celery_app worker --loglevel=info &
CELERY_PID=$!

# ── Trap to clean up Celery on exit ───────────────────────────────────
cleanup() {
    echo "[shutdown] Stopping Celery worker (PID $CELERY_PID)..."
    kill "$CELERY_PID" 2>/dev/null || true
    wait "$CELERY_PID" 2>/dev/null || true
    echo "[shutdown] Done."
}
trap cleanup EXIT INT TERM

# ── Start FastAPI ──────────────────────────────────────────────────────
echo "[start] FastAPI (uvicorn) on port 8000..."
python -m uvicorn agxp.api.app:app --reload --port 8000 --host 0.0.0.0
