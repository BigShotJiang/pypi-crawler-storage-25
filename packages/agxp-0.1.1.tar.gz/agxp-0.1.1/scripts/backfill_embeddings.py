"""
Backfill embeddings for experiences that have no embedding_situation.
Processes in batches, directly writes to DB (no Celery).

Usage:
    cd /home/ubuntu/agentxp
    source .venv/bin/activate && source .env
    python scripts/backfill_embeddings.py [--batch-size 50] [--limit 0]
"""
import argparse
import asyncio
import time
import uuid


async def main(batch_size: int, limit: int):
    from agxp.config.backends import EMBED_BACKEND
    from agxp.db.pool import get_pool
    from agxp.search.embed import ExperienceEmbedder

    pool = await get_pool()
    embedder = ExperienceEmbedder(EMBED_BACKEND)

    # Count how many need embedding
    row = await pool.fetchrow(
        "SELECT count(*) AS cnt FROM experiences WHERE embedding_situation IS NULL AND deleted_at IS NULL"
    )
    total = row["cnt"]
    if limit > 0:
        total = min(total, limit)
    print(f"Total to embed: {total}")

    processed = 0
    start = time.monotonic()

    while processed < total:
        rows = await pool.fetch(
            """
            SELECT id, situation, solution, lessons, failed_approaches, tags, environment
            FROM experiences
            WHERE embedding_situation IS NULL AND deleted_at IS NULL
            ORDER BY created_at
            LIMIT $1
            """,
            batch_size,
        )
        if not rows:
            break

        for row in rows:
            exp_id = str(row["id"])
            try:
                emb = await embedder.embed_experience(dict(row))
                await pool.execute(
                    """
                    UPDATE experiences SET
                        embedding_situation   = $1,
                        embedding_solution    = $2,
                        embedding_lessons     = $3,
                        embedding_failed      = $4,
                        embedding_tags        = $5,
                        embedding_environment = $6,
                        updated_at            = now()
                    WHERE id = $7
                    """,
                    emb["situation"],
                    emb["solution"],
                    emb["lessons"],
                    emb["failed_approaches"],
                    emb["tags"],
                    emb["environment"],
                    uuid.UUID(exp_id),
                )
                processed += 1
                if processed % 100 == 0:
                    elapsed = time.monotonic() - start
                    rate = processed / elapsed
                    eta = (total - processed) / rate if rate > 0 else 0
                    print(f"  {processed}/{total} ({rate:.1f}/s, ETA {eta/60:.0f}min)")
            except Exception as e:
                print(f"  ERROR {exp_id}: {e}")

    elapsed = time.monotonic() - start
    print(f"Done: {processed} embedded in {elapsed:.0f}s ({processed/elapsed:.1f}/s)")

    from agxp.db.pool import close_pool
    await close_pool()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch-size", type=int, default=50)
    parser.add_argument("--limit", type=int, default=0, help="0 = all")
    args = parser.parse_args()
    asyncio.run(main(args.batch_size, args.limit))
