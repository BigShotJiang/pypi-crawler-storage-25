#!/bin/bash
# AGXP Server startup script
# Usage: ./scripts/agxp-server.sh [start|stop|status]

set -e
cd /home/ubuntu/agentxp
PIDFILE="/tmp/agxp-server.pid"
LOGFILE="/tmp/agxp-server.log"

case "${1:-start}" in
  start)
    if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
      echo "Server already running (PID $(cat $PIDFILE))"
      exit 0
    fi
    source .env 2>/dev/null || true
    source .venv/bin/activate
    nohup uvicorn agxp.api.app:app --host 0.0.0.0 --port 8000 \
      >> "$LOGFILE" 2>&1 &
    echo $! > "$PIDFILE"
    echo "Server started (PID $!, log: $LOGFILE)"
    ;;
  stop)
    if [ -f "$PIDFILE" ]; then
      kill "$(cat "$PIDFILE")" 2>/dev/null && rm "$PIDFILE"
      echo "Server stopped"
    else
      echo "No PID file found"
    fi
    ;;
  status)
    if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
      echo "Running (PID $(cat $PIDFILE))"
    else
      echo "Not running"
    fi
    ;;
  *)
    echo "Usage: $0 {start|stop|status}"
    exit 1
    ;;
esac
