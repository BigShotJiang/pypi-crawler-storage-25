"""
Load cold-start experience data from JSONL file into PostgreSQL database.
Also indexes into FTS backend and dispatches embedding tasks.

Usage:
    cd /home/ubuntu/agentxp
    source .venv/bin/activate && source .env
    python scripts/load_jsonl_data.py --file path/to/your/data.jsonl [--batch-size 50] [--user-id <your-user-id>]
"""
import argparse
import asyncio
import json
import time
import uuid
from typing import Dict, Any

from agxp.api.routes.contribute import insert_experience, fts_index_experience, dispatch_embed, ContributeRequest, OutcomeType


async def load_jsonl(file_path: str, batch_size: int, user_id: str, limit: int) -> None:
    # Read all lines first
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = [line.strip() for line in f if line.strip()]

    # Apply limit if set
    if limit > 0:
        lines = lines[:limit]
        print(f"Applying limit: only loading first {limit} records")

    total = len(lines)
    print(f"Found {total} experiences in {file_path}")

    processed = 0
    skipped = 0
    start = time.monotonic()

    for i, line in enumerate(lines):
        try:
            data = json.loads(line)

            # Convert to ContributeRequest format
            # Map outcome_type string to enum
            if isinstance(data.get('outcome_type'), str):
                data['outcome_type'] = OutcomeType(data['outcome_type'])

            # Default language to 'en' if not present
            if 'language' not in data:
                data['language'] = 'en'

            # Remove extra fields that are not in ContributeRequest
            extra_fields = ['source_id', 'source_url', 'experience_id', 'id']
            for field in extra_fields:
                if field in data:
                    del data[field]

            req = ContributeRequest(**data)
            experience_id = str(uuid.uuid4())

            # Insert to DB
            await insert_experience(experience_id, req, user_id)

            # Index to FTS
            env = req.environment
            env_text = " ".join(f"{k}: {v}" for k, v in env.items()) if isinstance(env, dict) else ""
            tags_text = " ".join(req.tags) if req.tags else ""
            fts_doc = {
                "situation": req.situation,
                "solution": req.solution,
                "lessons": req.lessons,
                "failed_approaches": req.failed_approaches or "",
                "environment": env_text,
                "tags": tags_text,
            }
            await fts_index_experience(experience_id, fts_doc)

            # Dispatch embedding task
            dispatch_embed(experience_id, user_id)

            processed += 1

            if processed % 10 == 0:
                elapsed = time.monotonic() - start
                rate = processed / elapsed
                eta = (total - processed) / rate if rate > 0 else 0
                print(f"  Processed {processed}/{total} ({rate:.1f}/s, ETA {eta:.0f}s), skipped {skipped}")

        except Exception as e:
            skipped += 1
            print(f"  Skipping line {i+1}: {str(e)}")
            continue

    elapsed = time.monotonic() - start
    print(f"\nDone! Processed {processed} experiences, skipped {skipped} in {elapsed:.0f}s.")
    print(f"Embedding tasks are running asynchronously in the background.")


async def main():
    parser = argparse.ArgumentParser(description="Load JSONL experience data into PostgreSQL")
    parser.add_argument("--file", required=True, help="Path to JSONL file")
    parser.add_argument("--user-id", required=True, help="User ID to associate with imported experiences (UUID)")
    parser.add_argument("--batch-size", type=int, default=50, help="Batch size for processing")
    parser.add_argument("--limit", type=int, default=0, help="Only load first N records (0 = load all)")
    args = parser.parse_args()

    await load_jsonl(args.file, args.batch_size, args.user_id, args.limit)

    # Cleanup DB pool
    from agxp.db.pool import close_pool
    await close_pool()


if __name__ == "__main__":
    asyncio.run(main())
