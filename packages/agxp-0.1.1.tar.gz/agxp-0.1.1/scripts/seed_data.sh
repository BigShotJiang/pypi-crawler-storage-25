#!/bin/bash
set -euo pipefail

# AGXP Cold Start Data Seed Script
# Usage: ./scripts/seed_data.sh [OPTIONS]
# Options:
#   --file <path>       Path to JSONL data file (default: agxp/data/output.jsonl)
#   --user-id <uuid>    System user UUID (default: 00000000-0000-0000-0000-000000000001)
#   --limit <N>         Only load first N records (0 = load all, default: 0)
#   --help              Show this help message
#
# Examples:
#   # Test with first 10 records
#   ./scripts/seed_data.sh --limit 10
#
#   # Custom data file + limit
#   ./scripts/seed_data.sh --file /path/to/data.jsonl --limit 100
#
#   # Full import with custom user ID
#   ./scripts/seed_data.sh --user-id "your-uuid-here"

# Default values
JSONL_PATH="agxp/data/output.jsonl"
SYSTEM_USER_ID="00000000-0000-0000-0000-000000000001"
LIMIT="0"

# Parse named arguments
while [[ $# -gt 0 ]]; do
  case "$1" in
    --file)
      JSONL_PATH="$2"
      shift 2
      ;;
    --user-id)
      SYSTEM_USER_ID="$2"
      shift 2
      ;;
    --limit)
      LIMIT="$2"
      shift 2
      ;;
    --help)
      grep -E '^# (Usage:|Options:|  --|Examples:|#   #)' "$0" | sed 's/^# //'
      exit 0
      ;;
    *)
      echo "❌ Unknown option: $1"
      echo "Run --help for usage"
      exit 1
      ;;
  esac
done

echo "======================================"
echo "AGXP Cold Start Data Seeding Script"
echo "======================================"
echo ""

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "❌ ERROR: .env file not found in current directory"
    echo "Please copy .env.example to .env and configure your DATABASE_URL"
    exit 1
fi

# Load environment variables
echo "✅ Loading environment variables from .env"
set -a
source .env
set +a

# Check if DATABASE_URL is set
if [ -z "${DATABASE_URL:-}" ]; then
    echo "❌ ERROR: DATABASE_URL not found in .env file"
    exit 1
fi

# Check if virtual environment is active
if [ -z "${VIRTUAL_ENV:-}" ]; then
    echo "⚠️  Virtual environment not detected, trying to activate .venv..."
    if [ -d ".venv" ]; then
        source .venv/bin/activate
        echo "✅ Activated virtual environment: $VIRTUAL_ENV"
    else
        echo "❌ ERROR: .venv directory not found"
        echo "Please create and activate your virtual environment first"
        exit 1
    fi
fi

# Check if JSONL file exists
if [ ! -f "$JSONL_PATH" ]; then
    echo "❌ ERROR: JSONL file not found at $JSONL_PATH"
    exit 1
fi
echo "✅ Using data file: $JSONL_PATH"
echo ""

# Step 1: Seed system user
echo "======================================"
echo "Step 1/3: Creating system user"
echo "======================================"
python scripts/seed_users.py \
    --user-id "$SYSTEM_USER_ID" \
    --email "system@agxp.dev" \
    --display-name "System Cold Start"
echo ""

# Step 2: Import JSONL data
echo "======================================"
echo "Step 2/3: Importing experience data"
echo "======================================"
python scripts/load_jsonl_data.py \
    --file "$JSONL_PATH" \
    --user-id "$SYSTEM_USER_ID" \
    --limit "$LIMIT"
echo ""

# Step 3: Optional backfill embeddings
echo "======================================"
echo "Step 3/3: Optional embedding backfill"
echo "======================================"
read -p "Do you want to run embedding backfill now? (requires BGE-M3 model, ~3GB RAM) [y/N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Running embedding backfill (this may take a while)..."
    python scripts/backfill_embeddings.py --batch-size 20
    echo "✅ Embedding backfill completed!"
else
    echo "Skipping embedding backfill."
    echo "You can run it later with: python scripts/backfill_embeddings.py"
fi

echo ""
echo "======================================"
echo "✅ All done! Cold start data seeded successfully."
echo "======================================"
echo "System user ID: $SYSTEM_USER_ID"
echo "Data source: $JSONL_PATH"
echo ""
