# Contributing to AgentXP

## Development Philosophy

AgentXP follows strict **Test-Driven Development (TDD)**:

1. Write failing tests first
2. Implement the minimum code to make tests pass
3. Refactor

No feature ships without tests. Performance targets are enforced by automated benchmarks on every merge to main.

## Getting Started

```bash
git clone https://github.com/morningwilliam-byte/agxp
cd agxp
uv sync --dev
docker compose up -d
uv run alembic upgrade head
uv run pytest tests/unit/ -q   # should all pass on a clean checkout
```

## Project Structure

```
axp/                    # main Python package
├── cli/                # Typer CLI commands
├── services/           # FastAPI routers + business logic
├── search/             # BM25, vector, RRF, reranker, quality blend
├── cache/              # L1 TTLCache, L2 Redis, L3 mat. views, invalidation
├── db/                 # asyncpg connection, Alembic migrations, repositories
├── workers/            # Celery tasks
├── auth/               # API key hashing and middleware
└── observability/      # Prometheus metrics, OpenTelemetry tracing

tests/
├── unit/               # Pure logic tests, no I/O
├── integration/        # Requires running PostgreSQL + Redis
├── performance/        # pytest-benchmark + locust
└── compatibility/      # Python versions, OS, Redis/PG versions
```

## Writing Tests

### Unit Tests

No database, no Redis, no network calls. Mock all I/O.

```python
# tests/unit/test_search/test_rrf_fusion.py

def test_rrf_scores_decrease_monotonically():
    bm25_results = [("exp_a", 2.1), ("exp_b", 1.8), ("exp_c", 0.9)]
    vec_results  = [("exp_b", 0.92), ("exp_a", 0.85), ("exp_d", 0.71)]

    fused = rrf_fusion(bm25_results, vec_results, k=60)

    scores = [score for _, score in fused]
    assert scores == sorted(scores, reverse=True), "RRF scores must be monotonically decreasing"
```

### Integration Tests

Use `pytest` fixtures that spin up a real PostgreSQL + Redis (via Docker or testcontainers).

```python
# tests/integration/test_search_pipeline/test_end_to_end_query.py

@pytest.mark.asyncio
async def test_query_returns_relevant_result(db_session, redis_client, seeded_experiences):
    pipeline = SearchPipeline(db=db_session, redis=redis_client)
    results = await pipeline.query("feishu API indent_level ignored", domain="coding")

    assert len(results) > 0
    assert results[0].experience.lessons is not None
    assert results[0].score > 0.5
```

### Performance Tests

Use `pytest-benchmark` for latency targets. Tests fail CI if targets are missed.

```python
# tests/performance/test_latency_targets.py

def test_l2_cache_hit_p99_under_60ms(benchmark, redis_client, cached_query):
    result = benchmark.pedantic(
        cached_query.execute,
        iterations=100,
        rounds=10
    )
    # pytest-benchmark automatically checks --benchmark-max-time
    assert benchmark.stats["max"] < 0.060  # 60ms hard limit
```

### Performance Targets (must not regress)

| Test | Target |
|------|--------|
| L1 cache hit p99 | < 10ms |
| L2 cache hit p99 | < 60ms |
| Full search pipeline p99 | < 500ms |
| BM25 search alone p99 (1M docs) | < 10ms |
| pgvector HNSW alone p99 (1M docs) | < 30ms |
| Reranker (top-20) p99 | < 25ms |
| MRR@5 on eval set | > 0.75 |
| Combined cache hit rate | > 85% |

## Code Style

```bash
# Format
uv run ruff format axp/ tests/

# Lint
uv run ruff check axp/ tests/

# Type check
uv run mypy axp/
```

All three must pass before opening a PR. Pre-commit hooks enforce this:

```bash
uv run pre-commit install
```

## Database Migrations

```bash
# Create a new migration
uv run alembic revision --autogenerate -m "add experience subdomain index"

# Apply migrations
uv run alembic upgrade head

# Rollback one step
uv run alembic downgrade -1
```

Always review auto-generated migrations before committing. Ensure `downgrade()` is implemented.

## Adding a New Domain/Task Type

1. Add to `agxp/config/taxonomy.py` (domain + task_type lists)
2. Add compatibility tests in `tests/compatibility/test_agent_types.py`
3. Update `docs/API.md` with new valid values
4. Update seed data in `scripts/seed_data.py`

## Pull Request Checklist

- [ ] Tests written first (failing), then implementation
- [ ] All existing tests still pass: `uv run pytest`
- [ ] Performance benchmarks not regressed: `uv run pytest tests/performance/ --benchmark-only`
- [ ] Lint + type check pass: `uv run ruff check axp/ && uv run mypy axp/`
- [ ] New endpoints documented in `docs/API.md`
- [ ] Migration reviewed (both upgrade and downgrade)
- [ ] NDJSON output format preserved for CLI changes

## Commit Messages

Use conventional commits:

```
feat: add subdomain filter to query API
fix: correct RRF score when one ranker returns no results
perf: cache query embeddings in L2 with 24h TTL
test: add integration test for cross-region cache invalidation
docs: update API reference with vote endpoint examples
```
