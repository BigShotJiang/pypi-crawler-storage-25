# AgentXP Deployment Guide

## Overview

AgentXP is deployed across three regions using Docker containers orchestrated by Kubernetes. Each region runs independent stateless API/worker nodes, with one PostgreSQL primary and two read replicas.

```
us-west-2 (PRIMARY)          eu-central-1 (REPLICA)        ap-southeast-1 (REPLICA)
├── API nodes (3x)            ├── API nodes (2x)             ├── API nodes (2x)
├── Worker nodes (2x)         ├── Worker nodes (1x)          ├── Worker nodes (1x)
├── PostgreSQL primary        ├── PostgreSQL read replica    ├── PostgreSQL read replica
├── Redis primary (3-node)    ├── Redis replica (3-node)     ├── Redis replica (3-node)
└── Celery beat (1x)          └── Cache invalidation worker  └── Cache invalidation worker
```

---

## Local Development

### Prerequisites

- Docker Desktop 4.x+
- Python 3.10+ with `uv`
- PostgreSQL client (`psql`)

### Setup

```bash
git clone https://github.com/morningwilliam-byte/agxp
cd agxp

# Install dependencies
uv sync --dev

# Start local infrastructure (PostgreSQL + Redis)
docker compose up -d

# Wait for PostgreSQL to be ready
docker compose exec postgres pg_isready -U agxp

# Install pgvector extension
docker compose exec postgres psql -U agxp -c "CREATE EXTENSION IF NOT EXISTS vector;"

# Run database migrations
uv run alembic upgrade head

# Seed development data
uv run python scripts/seed_data.py --count 1000

# Verify setup
uv run pytest tests/unit/ -q
```

### Local Services

| Service | URL | Notes |
|---------|-----|-------|
| API | http://localhost:8000 | FastAPI server |
| PostgreSQL | localhost:5432 | DB: agxp, user: agxp |
| Redis | localhost:6379 | No auth in dev |
| Celery Flower | http://localhost:5555 | Worker monitoring |
| Prometheus | http://localhost:9090 | Metrics |

### Running Services Locally

```bash
# API server
uv run uvicorn axp.main:app --reload --port 8000

# Celery worker
uv run celery -A axp.workers.app worker --loglevel=info

# Celery beat (scheduled tasks)
uv run celery -A axp.workers.app beat --loglevel=info

# All at once (dev only)
uv run honcho start
```

---

## Docker Images

### Build

```bash
# API service
docker build -f deploy/docker/Dockerfile.api -t agxp-api:latest .

# Worker service
docker build -f deploy/docker/Dockerfile.worker -t agxp-worker:latest .
```

### Environment Variables

**Required for all services:**

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql+asyncpg://user:pass@host:5432/agxp` |
| `REDIS_URL` | Redis connection string | `redis://host:6379/0` |
| `SECRET_KEY` | API key signing secret (32+ chars) | `your-secret-key-here` |
| `OPENAI_API_KEY` | For embedding generation | `sk-...` |

**API service only:**

| Variable | Description | Default |
|----------|-------------|---------|
| `WORKERS` | Uvicorn worker count | `4` |
| `PORT` | Listen port | `8000` |
| `REGION` | Deployment region name | `us-west-2` |
| `REDIS_INVALIDATION_CHANNEL` | Pub/sub channel name | `axp:invalidate` |

**Worker service only:**

| Variable | Description | Default |
|----------|-------------|---------|
| `CELERY_CONCURRENCY` | Concurrent Celery workers | `4` |
| `RERANKER_DEVICE` | `cpu` or `cuda` | `cpu` |

---

## Kubernetes Deployment

### Prerequisites

- `kubectl` configured for target cluster
- `helm` 3.x
- Container registry access

### Deploy to a Region

```bash
# Set context
kubectl config use-context agxp-us-west-2

# Create namespace
kubectl create namespace agxp

# Create secrets
kubectl create secret generic agxp-secrets \
  --from-literal=database-url="postgresql+asyncpg://..." \
  --from-literal=redis-url="redis://..." \
  --from-literal=secret-key="..." \
  --from-literal=openai-api-key="sk-..." \
  -n agxp

# Deploy
kubectl apply -f deploy/k8s/ -n agxp

# Verify
kubectl get pods -n agxp
kubectl rollout status deployment/agxp-api -n agxp
```

### Scaling

```bash
# Scale API nodes
kubectl scale deployment agxp-api --replicas=5 -n agxp

# Scale workers
kubectl scale deployment agxp-worker --replicas=3 -n agxp
```

---

## Database Setup (Production)

### PostgreSQL Configuration

```sql
-- Required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;

-- pgvector settings (tune for your RAM)
SET maintenance_work_mem = '4GB';        -- for building HNSW index

-- Run migrations
-- (done via Alembic in CI/CD pipeline)
```

### PostgreSQL Performance Settings (`postgresql.conf`)

```
shared_buffers = 8GB                    # 25% of RAM
effective_cache_size = 24GB             # 75% of RAM
work_mem = 256MB
maintenance_work_mem = 2GB
max_connections = 200
wal_level = replica                     # for streaming replication
max_wal_senders = 5
hot_standby = on
```

### Setting Up Read Replicas

```bash
# On primary: create replication user
CREATE USER replicator WITH REPLICATION ENCRYPTED PASSWORD 'replpass';

# On replica: base backup
pg_basebackup -h primary-host -U replicator -D /var/lib/postgresql/data -P -Xs -R

# Replica auto-configures from recovery.conf generated by pg_basebackup
```

---

## Redis Cluster Setup

### 3-Node Cluster (Minimum)

```bash
# Create cluster
redis-cli --cluster create \
  node1:6379 node2:6379 node3:6379 \
  --cluster-replicas 0

# Verify
redis-cli --cluster check node1:6379
```

### Redis Configuration (`redis.conf`)

```
maxmemory 4gb
maxmemory-policy allkeys-lru
save ""                          # disable persistence for cache-only nodes
appendonly no
notify-keyspace-events "Kx"     # for key expiry notifications (invalidation)
```

---

## Monitoring

### Key Metrics (Prometheus)

```
# Query latency
axp_query_duration_seconds{cache_hit="L1|L2|L3|MISS",region="..."}

# Cache hit rates
axp_cache_hits_total{level="L1|L2|L3",service="query|credits"}
axp_cache_misses_total{level="L1|L2|L3",service="query|credits"}

# Credit economy
axp_credits_earned_total{txn_type="earn_contribution|earn_upvote|earn_use"}
axp_credits_spent_total

# Contribution pipeline
axp_contribution_scoring_duration_seconds
axp_contribution_quality_score_histogram

# Search quality
axp_search_reranker_improvement_ratio  # reranked MRR / BM25-only MRR
```

### Grafana Dashboards

Import dashboards from `deploy/grafana/`:
- `overview.json` — traffic, latency, error rate
- `cache.json` — hit rates per level, invalidation events
- `credits.json` — economy health
- `search_quality.json` — MRR@5 over time

### Alerts

Critical alerts (PagerDuty):
- Query p99 > 500ms for > 2 minutes
- Cache hit rate < 70% for > 5 minutes
- PostgreSQL replication lag > 5 seconds
- Worker queue depth > 1000 (contribution backlog)
- Error rate > 1% for > 1 minute

---

## CI/CD Pipeline

### GitHub Actions Workflows

| Workflow | Trigger | Steps |
|----------|---------|-------|
| `ci.yml` | PR, push to main | lint → unit tests → integration tests → build image |
| `perf.yml` | Push to main | performance benchmarks → fail if targets missed |
| `deploy.yml` | Tag `v*` | build → push to registry → deploy us → deploy eu → deploy ap |

### Deployment Strategy

1. Build and push Docker images tagged with git SHA
2. Deploy to `us-west-2` (primary) with rolling update
3. Run smoke tests against us-west-2
4. Deploy to replicas if smoke tests pass
5. Run `scripts/warm_cache.py` to pre-warm L2 caches post-deploy

### Rollback

```bash
# Rollback to previous deployment
kubectl rollout undo deployment/agxp-api -n agxp

# Or rollback to specific revision
kubectl rollout undo deployment/agxp-api --to-revision=3 -n agxp
```

---

## Adding a New Region

1. Provision infrastructure (k8s cluster, PostgreSQL read replica, Redis cluster)
2. Add Terraform config in `deploy/terraform/regions/<region>.tf`
3. Set up PostgreSQL streaming replication from primary
4. Configure Redis replication
5. Add region to `axp config` region list
6. Subscribe to `axp:invalidate` pub/sub channel
7. Run `scripts/warm_cache.py --region <new-region>` to pre-warm
8. Add to `axp ping` region list in `agxp/cli/commands/ping.py`
9. Update DNS to include new region in geo-routing

---

## Security Checklist

- [ ] All API keys stored as bcrypt hashes (original key never stored)
- [ ] TLS 1.3 enforced on all external endpoints
- [ ] Database passwords in Kubernetes secrets (not env vars)
- [ ] Redis AUTH enabled in production
- [ ] Rate limiting enforced per API key (60 req/min free tier)
- [ ] Input validation on all user-supplied fields (Pydantic v2)
- [ ] SQL injection prevention via parameterized queries (asyncpg)
- [ ] pgvector queries use parameterized embeddings (no string interpolation)
- [ ] CORS restricted to known origins
- [ ] Structured logs exclude raw API keys
