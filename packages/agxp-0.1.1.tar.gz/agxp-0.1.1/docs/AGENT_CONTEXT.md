# AGXP — Agent Context
> Used by `/tester` and `/review` skills to inject project-specific context into sub-agents.

---

## Project Overview
AGXP is a pure client-server AI agent collective memory platform. All functionality is exposed via a public HTTP API, with thin client wrappers for CLI, MCP server, and Claude Skills. There is no local database or offline functionality.

## Install Tiers
- **Base Client** (`pip install agxp`): Full client functionality including CLI commands, MCP server, and Skill support (~5MB). No server dependencies.
- **Server** (`pip install agxp[server]`): Full server stack for self-hosting. Includes FastAPI, asyncpg, celery, redis, embedding models, etc.

**When working on an issue, check which tier it targets.** Client code must not import server dependencies at module level.

---

## Tech Stack

### Client Side
- Python 3.11
- Typer (CLI framework)
- FastMCP (MCP server implementation)
- No local database, no embedded models
- All operations call remote HTTP API

### Server Side
- Python 3.11 + asyncio
- FastAPI + Uvicorn (async HTTP server)
- asyncpg (raw PostgreSQL client, no ORM at runtime)
- PostgreSQL 16 + pgvector 0.7 (vector search)
- Tantivy 0.25 (Rust-based full-text search engine)
- Celery + Redis 7.2 (async workers + caching)
- BAAI/bge-m3 (multilingual embedding model, 1024-dim)
- MiniLM-L6-v2 (cross-encoder reranking)
- Alembic (database migrations)
- pytest + pytest-asyncio 1.3.0 (testing)

---

## Repository Structure
```
agxp/
├── cli/                # CLI command implementations
│   ├── commands/       # Individual command modules (login/query/contribute/feedback/status/mcp/hook)
│   └── main.py         # CLI entry point
├── mcp/                # MCP server implementation
│   └── server.py       # MCP tools and server logic
├── api/                # Server API implementation
│   ├── routes/         # API route handlers
│   ├── middleware/     # API middleware (auth, rate limiting, etc.)
│   └── main.py         # Server entry point
├── server/             # Core server business logic
│   ├── auth/           # Authentication logic
│   ├── search/         # Search pipeline (vector + FTS + reranking)
│   ├── contribution/   # Experience submission and validation
│   ├── feedback/       # Feedback processing
│   ├── quality/        # Quality scoring logic
│   ├── credit/         # Credit accounting
│   └── models/         # Pydantic data models
├── config/             # Configuration and dependency injection
│   └── backends.py     # Server backend initialization
└── utils/              # Shared utilities
```

---

## Core Client Features

### CLI Commands
All commands output JSON by default for machine consumption, with `--no-json` flag for human-readable output.
- `login`: Github OAuth authentication flow with local callback server
- `query`: Search experience knowledge base with optional domain/task_type filters
- `contribute`: Submit new experience with full validation
- `feedback`: Rate experience usefulness
- `status`: Show server status, account information, and available commands
- `mcp`: Start MCP server for Claude Code/Cursor integration
- `hook`: Claude Code hook for automatic experience recording

### MCP Server Tools
MCP server implements the Model Context Protocol standard, exposing three native tools:
- `search_experiences(query: str, domain?: str, task_type?: str, limit?: int) -> dict`: Search knowledge base, returns results with pending feedback hints
- `contribute_experience(situation: str, solution: str, outcome_type: str, lessons: str, domain: str, task_type: str, ...) -> dict`: Submit new experience, returns experience ID and status
- `report_feedback(experience_id: str, useful: bool) -> dict`: Submit feedback, returns updated quality score and status

### Claude Skills
Three skill configurations are provided in `docs/skills/` that wrap CLI commands for direct use in Claude Code without MCP configuration:
- `agxp-search-experiences`
- `agxp-contribute-experience`
- `agxp-report-feedback`

---

## Server API
All client operations use the same public HTTP API:
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/query` | Search experiences |
| POST | `/api/v1/contribute` | Submit new experience |
| POST | `/api/v1/feedback` | Submit feedback |
| GET | `/api/v1/user/me` | Get current user info |
| GET | `/api/v1/auth/github` | Start OAuth flow |
| GET | `/api/v1/auth/github/callback` | OAuth callback |
| GET | `/health` | Health check |

Full API specification in `docs/API.md`.

---

## Test Conventions
```toml
# pyproject.toml
[tool.pytest.ini_options]
asyncio_default_fixture_loop_scope = "session"
asyncio_default_test_loop_scope = "session"
```

- **Unit tests**: `tests/unit/` — pure in-memory, no I/O, use fake/mocked dependencies, run in milliseconds
- **Integration tests**: `tests/integration/` — real dependencies (PostgreSQL, Redis, test API server)
- **Client tests**: `tests/client/` — test CLI and MCP functionality against test server
- Each test cleans up its own state; never depends on prior test execution

---

## Key Constraints (Review Checklist)

### Client Side
1. **No Local State**: Client must never store experience data locally, only authentication tokens in `~/.agxp/config.json`
2. **Stateless Operations**: All CLI commands must be stateless, no background processes or long-lived state
3. **API Compatibility**: Client must maintain backward compatibility with older server API versions
4. **Error Handling**: All API errors must be properly caught and formatted, both JSON and human-readable output formats must be supported
5. **No Secret Leaks**: Tokens must never be logged or printed to output, even in debug mode

### Server Side
1. **SQL Injection Prevention**:
   - Column names in dynamic queries must come from hardcoded whitelist only, never from user input
   - All values passed as positional parameters (asyncpg `$1`), never string-interpolated
2. **Async Correctness**:
   - No blocking I/O (DB calls, model inference, file I/O) directly in event loop — use `run_in_executor`
   - Never call `asyncio.run()` from inside an already running event loop
3. **Type Coercions**:
   - asyncpg returns `uuid.UUID` objects — must cast to `str()` before returning API responses
   - pgvector codec must be registered on pool initialization before any vector operations
4. **Tantivy 0.25 API Quirks**:
   - `doc["field"]` returns a list — always use `doc["field"][0]` to get the actual value
   - `parse_query(..., field_boosts=None)` raises exception — omit the kwarg entirely when no boosts needed
5. **Security**:
   - All API endpoints except `/health` and OAuth routes require valid Bearer token authentication
   - User input must be properly validated and sanitized to prevent XSS and injection attacks
   - OAuth flow must use CSRF protection with random state stored in Redis
   - Tokens must be hashed before storage, never stored in plaintext

---

## Quality Scoring Rules
Experience quality score (0-1) is calculated based on:
- 40%: Completeness of required fields
- 30%: Relevance and clarity of description
- 30%: User feedback (upvotes/downvotes)

Credit rewards based on final quality score:
- [0, 0.5): 5 credits
- [0.5, 0.7): 10 credits
- [0.7, 0.85): 25 credits
- [0.85, 1.0]: 50 credits
