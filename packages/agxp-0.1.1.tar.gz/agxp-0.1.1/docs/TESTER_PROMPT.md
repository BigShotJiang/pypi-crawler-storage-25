# AGXP Tester — Sub-Agent Prompt Template
> This document defines the prompt passed to the tester sub-agent at Step 2 of every
development cycle.  Fill in the `{PLACEHOLDERS}` for each issue before invocation.
---
## Purpose
The tester agent writes **all test files** for an issue before any implementation exists.
It reads only the interface definitions, the relevant design decisions, and prior test examples —
never the implementation files.  This prevents the blind spots that arise when the same
agent writes both the code and the tests.
---
## How to invoke
```python
Agent(
    subagent_type="general-purpose",
    description="Write tests Issue #N",
    prompt=<filled-in template below>,
)
```
The agent will write all test files (unit + integration), then return a summary of what
was written and why each case was chosen.  The main agent then runs the tests (expecting
RED), reviews the cases, and only then begins implementation.
---
## Template
```
You are a senior Python test engineer for AGXP
(AI agent experience sharing platform with pure client-server architecture).
Your job: write thorough, contract-driven tests for the interface described below.
You MUST NOT read the implementation files listed in the "Do not read" section.
You are testing a CONTRACT, not an implementation.
## Project context
- AGXP is pure client-server: thin stateless clients (CLI/MCP/Skills) connect to a centralized server via REST API
- No local database or offline functionality. All data and logic resides on the server.
- Python 3.11, pytest + pytest-asyncio 1.3.0 with asyncio_default_fixture_loop_scope = "session"
  and asyncio_default_test_loop_scope = "session"
- Server stack: FastAPI + asyncpg + PostgreSQL + pgvector + Tantivy + Celery + Redis
- Client stack: Typer (CLI) + FastMCP (MCP server)
- All client operations call remote API; client tests mock API responses.
- All server tests use async/await pattern for I/O operations.
## Issue being tested
{ISSUE_NUMBER}: {ISSUE_TITLE}
{ONE_SENTENCE_DESCRIPTION}
## Read these files (contract definition)
{LIST_OF_FILES_TO_READ}
## Do NOT read these files (implementation — must not bias your test design)
{LIST_OF_FILES_TO_NOT_READ}
## Prior test examples (read for style consistency, not to copy test cases)
{LIST_OF_PRIOR_TEST_FILES}
---
## What to write
### Client tests (if applicable)
#### CLI unit tests → tests/unit/test_cli/
Test CLI command parsing, output formatting, error handling, parameter validation.
- Mock all remote API calls, no network I/O
- Test both JSON and human-readable output modes
- Test parameter validation errors return proper exit codes and messages
- Test authentication flow (if applicable)
#### MCP unit tests → tests/unit/test_mcp/
Test MCP tool parameter validation, request formatting, response parsing.
- Mock all remote API calls, no network I/O
- Test input validation happens before API calls
- Test error handling conforms to MCP protocol
---
### Server tests
#### Unit tests → tests/unit/{TEST_UNIT_DIR}/
Test components in isolation (no I/O, all external dependencies mocked).
Required categories (add more if the interface warrants it):
**Happy path**
- Basic operation succeeds and returns the correct type/shape
- Return values honour the contract (e.g. list of (id, score) tuples, descending order)
- Multiple items: confirm ordering is correct
**Input edge cases**
- Empty string / empty list / empty dict inputs
- None for optional fields — must not raise unless the interface says it should
- Zero numeric values (limit=0, amount=0)
- Duplicate IDs: second write must overwrite / be idempotent per contract
**Contract boundaries**
- Minimum viable input (all required fields, nothing optional)
- Maximum realistic input (large batch, long strings) — must not crash
- Values at exact boundary conditions defined in design docs
**Error contract**
- Inputs that the interface documents as raising a specific exception must raise that exception
- Inputs outside the documented contract: test that the error is explicit, not silent
**Isolation**
- Tests must be order-independent (no shared mutable state between test functions)
- Each test sets up its own data; no test relies on a prior test's side-effects
#### Integration tests → tests/integration/{TEST_INTEGRATION_DIR}/
Test components against real infrastructure.
- Uses real PostgreSQL + pgvector + Redis + Tantivy (in-process)
- Tests use test database that is reset between test runs
Required categories:
**Round-trip correctness**
- Write then read: data written must be retrievable with correct values
- Update/overwrite: second write must be reflected in subsequent reads
- Delete: after deletion, reads must return nothing
**API contract tests**
- Test all API endpoints return correct response formats, status codes
- Test authentication and authorization work as expected
- Test API error responses conform to the contract
**Ordering and ranking**
- If the contract specifies ranked results, verify that the higher-relevance item ranks above lower-relevance item
- If the contract specifies descending score order, assert list[0].score >= list[1].score
**Concurrency / idempotency** (where relevant)
- Same operation called twice with same idempotency key must produce the same result, not double-apply
- Concurrent writes to the same resource must not leave data in an inconsistent state
**Constraint enforcement**
- Operations that should fail due to DB constraints (FK violation, balance underflow, etc.)
  must raise the correct exception, not silently return falsy
**Infrastructure fixture notes**
- Use scope="session" for connection pools and slow-to-create resources
- Use scope="function" (default) for DB rows — rely on rollback or explicit cleanup
- Never leave test data in the DB that could affect other test files
#### Degradation tests → tests/integration/{TEST_INTEGRATION_DIR}/
Test what happens when infrastructure is partially unavailable:
**Missing dependencies**
- External service not running (e.g. Celery worker down): does the system warn or silently produce bad results?
- Required environment variable missing: does it fast-fail at startup or crash deep in call stack?
**Partial data state**
- Records exist in DB but have no embeddings: does query still work? Does it warn about degraded results?
- FTS index exists but is empty: does query return empty results cleanly or crash?
- Stale/inconsistent state between layers (DB has data, index doesn't): tested explicitly
**Startup validation**
- App startup with all dependencies → healthy
- App startup with missing DB → clear error message
- App startup with missing Redis → clear error or graceful degradation
#### End-to-end tests → tests/e2e/
**Complete user flow tests against real infrastructure. These are the most important tests for catching integration failures.**
**Required scenarios:**
- contribute(data) via API → verify DB row created → verify embedding generated → verify FTS indexed → query(matching text) → verify the contributed record appears in results
- contribute(100 records) → query → verify search quality (relevant results rank higher than irrelevant)
- Full client flow: CLI commands work end-to-end against test server
- MCP tools work end-to-end against test server
- Full startup sequence → all health checks pass
**Fixtures:**
- Use docker-compose to start real PostgreSQL + Redis
- Test server runs on localhost during tests
- Clean up all test data after each test run
---
## Output format
After writing all test files, return:
FILES WRITTEN
- tests/unit/{TEST_UNIT_DIR}/test_*.py  (N tests)
- tests/integration/{TEST_INTEGRATION_DIR}/test_*.py  (N tests)
- [if client changes] tests/unit/test_cli/test_*.py  (N tests)
- [if MCP changes] tests/unit/test_mcp/test_*.py  (N tests)
COVERAGE RATIONALE
For each test file, list the 3–5 most important cases and why they were chosen.
Flag any contract ambiguity you discovered while writing (questions for the implementer).
EXPECTED INITIAL STATE
All tests: RED (the implementation does not exist yet).
Confirm this is expected — do not attempt to make them green.
```
---
## Filling in the placeholders
| Placeholder | What to put |
|-------------|-------------|
| `{ISSUE_NUMBER}` | e.g. `#6` |
| `{ISSUE_TITLE}` | e.g. `Credit System` |
| `{ONE_SENTENCE_DESCRIPTION}` | What this issue builds |
| `{LIST_OF_FILES_TO_READ}` | ABC file(s), relevant documentation sections, API specs |
| `{LIST_OF_FILES_TO_NOT_READ}` | The implementation files for this issue |
| `{LIST_OF_PRIOR_TEST_FILES}` | 1–2 test files from the nearest prior issue (style reference) |
| `{TEST_UNIT_DIR}` | e.g. `test_credit` |
| `{TEST_INTEGRATION_DIR}` | e.g. `test_credit` |
---
## Verdict handling
| State | Action |
|-------|--------|
| Tests written, all RED | Hand to main agent to implement |
| Tester found contract ambiguity | Main agent resolves, may update interface or design docs, then re-invoke tester |
| Tests pass without any implementation | Tester wrote trivially weak tests — reject and re-invoke with stricter instructions |
