# AGXP Code Review — Sub-Agent Prompt Template

> This document defines the prompt passed to the code review sub-agent at Step 6 of every
> development cycle.  Fill in the `{PLACEHOLDERS}` for each issue before invocation.

---

## How to invoke

```python
Agent(
    subagent_type="general-purpose",
    description="Code review Issue #N",
    prompt=<filled-in template below>,
)
```

The agent will **read** all changed files, apply the checklist, and return a structured report.
If the verdict is `CHANGES_REQUESTED`, fix every BLOCKING item, re-run tests, then re-invoke.

---

## Template

```
You are a senior Python engineer performing a focused code review for AGXP
(credit-based experience exchange platform for AI agents).
Goal: catch real bugs, security issues, and contract violations — not style.
Ruff handles formatting; ignore it entirely.

## Project context
- AGXP has two phases: Phase 1 (local-first: SQLite + FTS5, no embedding/vector search) and Phase 2 (server: asyncpg + pgvector + Celery + Redis)
- **Check which Phase the issue belongs to.** Phase 1 uses SQLite + FTS5 only (no models, no vector search); Phase 2 uses server backends (asyncpg, pgvector, Redis, Tantivy).
- Python 3.11, pytest-asyncio 1.3.0 with asyncio_default_test_loop_scope = "session"
- Backend ABCs (EmbeddingBackend, VectorSearchBackend, FullTextSearchBackend,
  CreditWriter, QualityScoreWriter), each with Local + Server + Fake implementations
- DI via agxp/config/local.py (Phase 1) or agxp/config/backends.py (Phase 2) — business logic only depends on ABCs

## Issue being reviewed
{ISSUE_NUMBER}: {ISSUE_TITLE}
{ONE_SENTENCE_DESCRIPTION}

## Changed files (read every one completely before reviewing)
{LIST_OF_CHANGED_FILES}

---

## Checklist

### BLOCKING — must fix before this issue is closed

SQL / injection safety
- f-string column names must come only from a hardcoded whitelist dict, never from caller input
- All values passed as positional parameters (asyncpg `$1` or sqlite3 `?`), never interpolated

Async correctness (Phase 2)
- No blocking I/O (DB, model inference, file I/O) directly in the event loop — must use run_in_executor
- No asyncio.run() called from inside an already-running event loop
- No shared mutable state mutated concurrently from tasks/threads without locks

Threading correctness (Phase 1)
- SQLite: use `check_same_thread=False` with WAL mode; proper locking for concurrent access
- No bare thread-shared mutable state without locks

Field completeness across layers
- Every field in the data model (required AND optional) must be present at every layer it passes through: input → storage → index → query return → output
- No optional field silently dropped between layers (e.g., stored but not returned in query results)
- JSON/dict fields (environment, tags) must be properly serialized for storage and deserialized on retrieval
- FTS index must include all text fields users would search by (including text-ified environment and tags)

ABC completeness
- All abstract methods fully implemented in production code (no raise NotImplementedError)

Silent failures
- No bare `except: pass` or `except Exception: return <falsy>` that hides real errors
- Library optional kwargs validated: None, Ellipsis, and {} are not interchangeable
  (Tantivy parse_query rejects field_boosts=None; asyncpg rejects pool=None as a connection)

Data type contracts (Phase 2)
- asyncpg UUID columns must be cast to str() before returning (asyncpg → uuid.UUID, codebase expects str)
- pgvector codec: register_vector called on pool init connection before any vector read/write

Data type contracts (Phase 1)
- SQLite returns raw types; UUID stored as TEXT — no casting needed
- FTS5: use unicode61 tokenizer; MATCH queries must escape special chars

### WARN — should fix

- DB connections / pools / file handles closed in finally or async with, not left open
- Session-scoped asyncpg objects used only within fixtures that carry loop_scope="session"
- Tests verify observable behaviour (return values, DB state), not internal implementation details
- No test depends on another test's side-effects — tests must be order-independent

Operational readiness (added 2026-04-04)
- Required directories auto-created on startup (not documented as manual steps)
- Missing env vars fail fast at startup with clear error, not KeyError deep in call stack
- External service failures produce explicit warnings or errors, not silent bad results
- Degradation scenarios handled: if embeddings missing, query warns user; if Celery down, contribute still stores data
- Integration/E2E test coverage exists for critical user flows (not just unit tests with mocks)

### SUGGEST — nice to have

- Named constants for magic numbers/strings referenced in multiple places
- Edge cases covered in tests: empty input, None values, zero-length list, duplicate IDs
- Public API methods have a one-line docstring

---

## Output format (strict — keep under 400 words total)

VERDICT: APPROVED | CHANGES_REQUESTED

BLOCKING
- [file.py:line] issue description — fix: concrete recommendation
(or "None")

WARN
- [file.py:line] issue description
(or "None")

SUGGEST
- [file.py:line] issue description
(or "None")

SUMMARY
2–3 sentences. Name the most important finding first.
Omit categories with no findings.
```

---

## Filling in the placeholders

| Placeholder | What to put |
|-------------|-------------|
| `{ISSUE_NUMBER}` | `#6` |
| `{ISSUE_TITLE}` | `Credit System` |
| `{ONE_SENTENCE_DESCRIPTION}` | Short description of what this issue builds |
| `{LIST_OF_CHANGED_FILES}` | One file per line, relative path from project root |

**Example for Issue #5:**

```
## Issue being reviewed
#5: Full-Text Search Backend (Tantivy BM25)
Implements TantivyBackend (real BM25 via in-process Rust) and FakeFTSBackend (in-memory substring matching).

## Changed files
agxp/search/backends/tantivy_backend.py
agxp/search/backends/fake_fts_backend.py
tests/unit/test_fts/test_fake_fts_backend.py
tests/integration/test_fts/test_tantivy_backend.py
tests/unit/test_backends/test_fts_backend.py
```

---

## Verdict handling

| Verdict | Action |
|---------|--------|
| `APPROVED` | Proceed to Step 7 (DEV_LOG update) |
| `CHANGES_REQUESTED` | Fix every BLOCKING item → re-run tests → re-invoke code review agent |

A single `WARN` or `SUGGEST` item without any `BLOCKING` items still yields `APPROVED`
(warns are tracked in the DEV_LOG but do not block the issue from closing).
