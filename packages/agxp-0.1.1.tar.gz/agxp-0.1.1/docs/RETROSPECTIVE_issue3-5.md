# 复盘报告：Issue #3–5 代码审查

**日期：** 2026-04-02  
**审查范围：** Issue #3（Embedding）、Issue #4（Vector Search）、Issue #5（FTS Tantivy）  
**审查方式：** 三个独立 Code Review sub-agents 并行审查  
**结论：** 全部三个 issue CHANGES_REQUESTED，共发现 10 项 BLOCKING 问题

---

## 一、发现的问题

### Issue #3 — Embedding Pipeline（3 项 BLOCKING）

| 编号 | 位置 | 问题描述 |
|------|------|----------|
| 3-1 | `workers/embed.py:43` | 用裸 `asyncpg.connect()` 而非项目 pool 单例，缺少 `register_vector` 注册，向 vector 列写入会在运行时触发 codec 错误 |
| 3-2 | `workers/embed.py:30` | `asyncio.run()` 在 Celery worker 进程中调用，切换到 gevent/eventlet 或从 async 上下文调用时会报"event loop is already running" |
| 3-3 | `bgem3_local_backend.py:29` | `_load()` 懒加载模型时无 `threading.Lock` 保护，多个 Celery task 并发首次调用会同时通过 `is None` 检查，造成重复加载和 race condition |

### Issue #4 — Vector Search Backend（3 项 BLOCKING）

| 编号 | 位置 | 问题描述 |
|------|------|----------|
| 4-1 | `pgvector_backend.py:62` | 未知 filter key 被静默丢弃，调用方无任何报错，却拿到未按预期过滤的结果，存在数据泄露风险 |
| 4-2 | `pgvector_backend.py:89` | `upsert()` 将 `experience_id`（str 类型）绑定到 UUID 列，asyncpg 在运行时抛出 `DataError` |
| 4-3 | `pool.py:20` | 模块级 `_pool` 单例无锁，并发首次调用时可能同时创建两个 pool，其中一个泄漏 |

### Issue #5 — Full-Text Search Backend（4 项 BLOCKING）

| 编号 | 位置 | 问题描述 |
|------|------|----------|
| 5-1 | `tantivy_backend.py:134` | `except Exception: return []` 吞掉所有异常，包括编程错误和索引损坏，应只捕获 `QueryParserError` |
| 5-2 | `tantivy_backend.py:63` | `IndexWriter` 跨线程共享，`_index_sync` 和 `_delete_sync` 均通过 `run_in_executor` 并发派发，但无 `threading.Lock`，存在写入 race condition |
| **5-3** | `tests/unit/test_fts/` | **所有 async 测试函数缺少 `@pytest.mark.asyncio` 或 `pytestmark`，测试从未真正运行，全部以 no-op 形式"通过"** |
| **5-4** | `tests/integration/test_fts/` | **同上，集成测试也全部是假绿** |

---

## 二、问题的根本原因

### 原因 A：测试是由实现者自己写的

Issues #3–5 的测试和实现代码都由同一个 agent（主 agent）完成。写实现的人写测试时，有两个系统性盲点：

1. **路径盲点**：测试者倾向于覆盖自己写过的代码路径，而不是合约要求的所有路径。5-3/5-4 的 `asyncio` marker 缺失，就是因为"实现者知道代码能跑"，没有从外部视角质疑测试本身的有效性。

2. **假设继承**：实现时做了某些假设（比如"asyncio_mode=auto 会自动处理"），测试时这些假设被无意识地继承，没有被质疑或验证。

### 原因 B：没有代码审查环节

Issues #3–5 完成后，直接进入下一个 issue，没有经过独立 code review。如果有审查环节，5-3/5-4（测试全是 no-op）这类问题会立刻被发现——这是任何审查者都会注意到的第一件事。

### 原因 C：跨组件依赖的验证缺口

3-1（`register_vector` 未注册）和 4-2（UUID/str 类型不匹配）都是**跨文件、跨组件的合约**问题——它们不会在单元测试中出现，只在真实的端到端调用链上触发。当前测试金字塔的集成测试覆盖了各个 backend 的独立行为，但没有测试 Celery worker → asyncpg → PostgreSQL 的完整写路径。

### 原因 D：并发安全被低估

3-3（`_load()` 无锁）、4-3（pool 单例无锁）、5-2（`IndexWriter` 无锁）三个问题都是并发 race condition。它们在单进程、单线程的开发环境下不会触发，因此测试全绿不代表生产安全。写共享可变状态时，没有养成"默认加锁"的习惯。

---

## 三、哪个环节做得不对

### 问题根源：开发工作流里缺少两个关键环节

对照当时约定的 6 步开发循环：

```
1. Design review
2. Write test scripts (red)        ← ❌ 由实现者自己写
3. Confirm environment
4. Backup + branch
5. Dev-test loop
6. Summary + decision              ← ❌ 没有独立代码审查
```

具体来说：

**步骤 2 做错了**：测试由主 agent 自己写，而主 agent 同时也是实现者。这是"自己给自己出考题"——出题者和答题者是同一个人，考题自然会避开自己不确定的地方。

**步骤 6 不完整**：Summary 只是记录 DEV_LOG，没有安排独立的 code review。Issues #3–5 全部跳过了审查就关闭，积累了 10 项未发现的 BLOCKING 问题。

---

## 四、以后应该怎么做

### 修正后的开发循环（8 步）

```
1. Design review          读 HARNESS.md + 相关设计文档
2. Tester sub-agent       /tester #N — 只读 ABC 和设计文档，不读实现，写测试（预期全 RED）
3. 确认测试质量           主 agent 检查测试案例是否真正覆盖合约，特别是：
                          · async 测试有没有 marker
                          · 边界条件有没有覆盖
                          · 并发场景有没有测试
4. 环境确认               验证权限、工具、基础设施
5. Backup + 分支
6. Dev loop               实现，直到测试全绿
7. Code Review sub-agent  /review #N — 独立审查，不跳过
8. DEV_LOG 更新
```

### 具体检查项（防止重蹈覆辙）

**并发安全（每次必查）**

每次写共享可变状态，无论是单例、缓存还是外部资源句柄，都要问自己：
> "如果两个线程同时首次访问这个对象，会发生什么？"

涉及以下模式时默认加锁：
- 模块级单例（`_pool`, `_model`, `_writer`）
- 懒加载（`if x is None: x = ...`）
- 外部资源句柄（DB writer, file handle, model instance）

**测试有效性验证（每次必查）**

写完测试后，立刻检查：
- 所有 `async def test_*` 函数是否有 `@pytest.mark.asyncio` 或模块级 `pytestmark`
- 至少运行一次 `pytest --collect-only` 确认测试函数被正确收集
- 检查 pytest 输出里有没有 warning 提示测试被跳过或以 sync 方式运行

**跨组件合约（每次必查）**

每次实现一个新组件，检查它与其他组件的接口边界：
- 类型是否匹配（UUID vs str、list vs tuple、None vs empty list）
- 初始化副作用是否已执行（`register_vector`、codec 注册）
- 环境变量缺失时是否给出清晰错误

**异常处理（每次必查）**

`except Exception:` 是 BLOCKING 级别的代码气味，每次出现都要：
1. 查文档，找到具体的异常类型
2. 只捕获那个具体类型
3. 其余异常让它传播

### 工具层面的保障

这次建立的 skill 体系提供了流程上的保障：

| Skill | 解决的问题 |
|-------|----------|
| `/tester #N` | 测试由独立 agent 从合约角度写，消除实现者盲点 |
| `/review #N` | 每个 issue 完成后强制独立审查，不允许跳过 |
| `/plan-project` | 项目启动时确保 Harness、TDD 流程、sub-agent 配置全部到位 |

---

## 五、本次复盘的价值

这次审查发现的最严重问题（5-3/5-4）揭示了一个反直觉的事实：

> **测试全绿不等于有测试覆盖。**  
> Issue #5 在 DEV_LOG 里记录"162 passed"，但实际上 FTS 相关的所有测试从未运行过。如果没有这次复盘，这个问题会一直潜伏，直到某天在生产环境发现 FTS 功能完全没有被验证过。

这也是为什么 code review 必须由独立 sub-agent 完成，而不是由实现者自我审查——独立审查者第一眼就会注意到"async 测试没有 marker"，而实现者的注意力会被"测试全绿"的结果所麻痹。
