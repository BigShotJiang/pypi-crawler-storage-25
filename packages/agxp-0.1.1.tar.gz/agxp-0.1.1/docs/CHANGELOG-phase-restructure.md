# Phase Restructure — Change Log

---

## v2.0 Restructure (Pure Client-Server)
> Date: 2026-04-16
> Backup: /tmp/agxp-backup-20260416-103022/

### Motivation
Strategic pivot: Eliminate all local database functionality to simplify product, ensure data consistency across users, and enable community sharing as the primary use case. All users now access a centralized knowledge base, with no local storage or offline capabilities. Dual integration support (MCP + Skills) provides flexible options for Claude Code users.

### Document Changes
| # | File | Change Summary | Status |
|---|------|---------------|--------|
| 1 | `CLAUDE.md` | Full rewrite: Removed all Phase 1 local architecture content, updated to pure client-server model, new roadmap, dual integration support | done |
| 2 | `docs/ARCHITECTURE.md` | Full rewrite: New pure client-server architecture diagram, updated tech stack, removed local mode sections, added dual integration description | done |
| 3 | `docs/AGENT_CONTEXT.md` | Full rewrite: Updated to pure client model, removed local backend references, new client command documentation, updated constraints | done |
| 4 | `docs/SKILLS_USAGE.md` | New document: Explains both MCP and Skill integration methods, provides installation instructions for both | done |
| 5 | `docs/skills/*.yaml` | New files: Three skill configuration files for direct CLI integration without MCP | done |
| 6 | `docs/LOCAL_SEARCH_DESIGN.md` | Deleted: Obsolete local architecture document | done |
| 7 | `docs/TEST_DESIGN_LOCAL_MVP.md` | Deleted: Obsolete local test document | done |
| 8 | `README.md` | Marked for update: Needs to reflect new pure client-server architecture | pending |

### Code Changes
| # | Area | Change Summary | Status |
|---|------|---------------|--------|
| 1 | `agxp/local/` | Deleted: Entire local database module removed | done |
| 2 | `agxp/store/` | Deleted: All local storage interfaces and implementations removed | done |
| 3 | `agxp/cli/commands/init_cmd.py` | Deleted: `agxp init` command removed (no local database to initialize) | done |
| 4 | `agxp/cli/commands/login.py` | New: Github OAuth authentication flow with local callback server | done |
| 5 | `agxp/cli/commands/query.py` | Rewritten: Full remote API call, added `--json` flag to output pure JSON array | done |
| 6 | `agxp/cli/commands/contribute.py` | Rewritten: Full remote API call, default JSON output, added `--no-json` flag for human-readable format | done |
| 7 | `agxp/cli/commands/feedback.py` | Rewritten: Full remote API call, default JSON output, added `--no-json` flag | done |
| 8 | `agxp/cli/commands/status.py` | Rewritten: Displays server status, account info, credit balance, available commands | done |
| 9 | `agxp/cli/commands/mcp_cmd.py` | Updated: Removed local database dependency, all MCP tools call remote API directly | done |
| 10 | `agxp/mcp/server.py` | Rewritten: Removed local store references, all tools use remote API, added anonymous token auto-creation | done |
| 11 | `agxp/api/routes/auth.py` | New: Github OAuth endpoints with CSRF protection using Redis state storage | done |
| 12 | `agxp/api/startup.py` | Updated: Added Github OAuth environment variable validation on server startup | done |
| 13 | `scripts/load_jsonl_data.py` | New: Batch import JSONL experience data into PostgreSQL, uses existing contribute validation logic | done |
| 14 | `scripts/seed_users.py` | New: Create system user for cold start data import with fixed ID and unlimited credits | done |
| 15 | `scripts/seed_data.sh` | New: Automation script for full cold start data import flow | done |
| 16 | `pyproject.toml` | Updated: Removed SQLite/FTS5 dependencies, removed local optional group, updated optional dependencies for server | done |

### Test Changes
| # | Area | Change Summary | Status |
|---|------|---------------|--------|
| 1 | `tests/unit/local/` | Deleted: All local database unit tests removed | done |
| 2 | `tests/integration/local/` | Deleted: All local integration tests removed | done |
| 3 | `tests/client/` | New: Added client CLI and MCP integration tests against test server | done |
| 4 | Full test suite | 749 tests passing after restructure | done |

---

## v1.0 Restructure (Phase 1/2 Split)
> Date: 2026-04-03
> Backup: /tmp/agxp-backup-20260403-140304/

### Motivation
Strategic shift: Local-first standalone tool becomes Phase 1 (primary product).
Server mode (PostgreSQL + Redis + Celery) becomes Phase 2 (community/enterprise).
Reason: lower adoption barrier — `pip install agxp && agxp init` vs deploying infrastructure.

---

## Document Changes

| # | File | Change Summary | Status |
|---|------|---------------|--------|
| 1 | `CLAUDE.md` | Rewritten: Phase 1/2 split, dual tech stack, dual interface table, new roadmap, updated status | done |
| 2 | `docs/ARCHITECTURE.md` | Phase annotation added to header (full Phase 1 section deferred to #11a) | done |
| 3 | `docs/AGENT_CONTEXT.md` | Rewritten: Phase-aware tech stack, triple-impl backend table, Phase-specific constraints | done |
| 4 | `pyproject.toml` | Core deps = Phase 1 only; `[project.optional-dependencies] server` = Phase 2; removed passlib, added hnswlib + bcrypt | done |
| 5 | `docs/TESTER_PROMPT.md` | Added Phase-aware project context; Phase-specific integration test instructions | done |
| 6 | `docs/CODE_REVIEW_PROMPT.md` | Added Phase-aware context; Phase 1 checklist (SQLite threading, hnswlib); split data type contracts by phase | done |
| 7 | `docs/HARNESS.md` | Added Phase annotation header; noted Phase 1 diagram to come in #11a | done |
| 8 | `docs/API.md` | Added Phase 2-only notice at top | done |
| 9 | `README.md` | Deferred — will update when Phase 1 CLI is implemented (#11c) | deferred |
| 10 | `docs/DEV_LOG.md` | Added Session 11: Phase restructure decision, new roadmap, tech stack rationale | done |

---

## Code / DB Changes

| # | Area | Change Summary | Status |
|---|------|---------------|--------|
| 1 | `pyproject.toml` | Moved server deps to optional group; added hnswlib; replaced passlib with bcrypt | done |
| 2 | `agxp/auth/keys.py` | Already uses `bcrypt` directly (fixed in Issue #10); no change needed for passlib removal | no change |
| 3 | Existing code imports | Need to verify no import breaks from dependency changes | pending verification |

---

## Test Verification

| Step | Result | Status |
|------|--------|--------|
| Full unit test suite after doc+dep changes | 285/285 passed (6.50s) | done |
| Code changes needed? | No — existing code unaffected, server deps still in .venv | done |
