# AgentXP / AGXP Development Log

> Record of all development sessions, decisions, errors, and resolutions.
> Maintained as a reference for future contributors and for retrospective analysis.

---

## Session 1 — Project Scaffold + Design Review

**Date:** 2026-04-02 (compacted; reconstructed from session summary)

---

### 1.1 Project Overview

**AgentXP** (later renamed **AGXP**) is a credit-based experience exchange platform for AI agents. The core concept: AI agents accumulate "experiences" (problems they solved, workarounds they found, approaches that failed), publish them to a shared repository, and consume other agents' experiences by paying credits. The system enables collective learning across agent deployments.

Key design goals:
- CLI tool (`agxp`) usable as an MCP server or standalone
- Credit economy: earn credits by contributing experiences, spend credits to query
- Vector search (bge-m3, 1024-dim) over 6 per-field embeddings
- Anonymous access with session-based credit pool
- Multi-language support via translation layer

---

### 1.2 Development Cycle Agreement

The user and Claude agreed on a strict 6-step TDD cycle for every issue:

1. **Design review + test case design** — revisit design docs, identify what needs testing
2. **Write test scripts (red)** — write failing tests before any implementation
3. **Confirm environment completeness** — verify all permissions, tools, and access
4. **Backup and isolation** — git branch, Docker sandbox
5. **Auto dev-test loop with logging** — implement until tests go green
6. **Summary + decision** — record findings, close issue or loop back to step 1

This cycle was explicitly confirmed by the user ("好的。开始之前再确认一下我们开发的模式") and followed throughout.

---

### 1.3 Language Choice: Python vs Go vs Rust

**User question:** "你默认了用 python。这个是最好的选择吗？"

**Analysis performed:**

| Factor | Python | Go | Rust |
|--------|--------|-----|------|
| ML ecosystem (bge-m3, cross-encoder) | Native | Via bindings (unreliable) | Via bindings (unreliable) |
| Async I/O performance | asyncio + asyncpg | goroutines (faster) | tokio (fastest) |
| Development speed | Fastest | Medium | Slowest |
| Type safety | Pydantic v2 | Native | Native |
| SQLAlchemy / Alembic | Native | N/A | N/A |
| GIL concern | Minimal (I/O-bound) | N/A | N/A |

**Decision: Python 3.11.** The bge-m3 embedding model and cross-encoder reranker are Python-native (HuggingFace / sentence-transformers). Wrapping them from Go or Rust introduces unreliable FFI and build complexity. The system is I/O-bound (DB + embeddings), so the GIL is not a bottleneck. The user agreed: "同意".

---

### 1.4 Project Renaming: agentxp → agxp

**Context:** The user registered domains `agxp.org` and `agxp.ai`. The domain `agxp.com` was listed for sale at $100,000 and was not purchased.

**User question:** "如果修改项目名称为 agxp，是不是要等到最后发布之前再做，还是应该现在就做？"

**Decision:** Rename immediately. Rationale: renaming after deep development creates more work (grep-and-replace across thousands of files, migration history conflicts, Docker image names). Renaming at scaffold stage costs almost nothing.

**Changes made:**
- `pyproject.toml`: `name = "agentxp"` → `name = "agxp"`, CLI entrypoint `axp` → `agxp`
- All import paths: `from agentxp.` → `from agxp.`
- ABC files: `agxp/services/*.py` renamed and updated
- `docker-compose.yml`: service names and project prefix updated
- All documentation: `axp` → `agxp` throughout

---

### 1.5 Comprehensive Design Cross-Review

**User question:** "你看是否有必要再做一次梳理？"

Before starting Issue #2 (database schema), Claude performed a full design audit. The audit found **52 issues** across ARCHITECTURE.md, API.md, and the ABC interfaces.

**Root cause:** The schema in Section 3.1 of ARCHITECTURE.md was written before DDR-007 through DDR-017 were finalized, so it did not reflect the final design decisions.

**Issue categories:**

| Severity | Count | Examples |
|----------|-------|---------|
| CRITICAL | 24 | Wrong field names (`approach` → `solution`/`failed_approaches`), missing tables, wrong FK references (`agent_id` where `user_id` required), missing embeddings, wrong dimensions |
| HIGH | 14 | Missing indexes, wrong nullability, wrong defaults |
| MEDIUM | 10 | Documentation inconsistencies, missing constraints |
| LOW | 4 | Naming style, minor omissions |

**All 24 CRITICAL issues were fixed before any code was written.** Key fixes:

1. **DDR-007**: `approach` + `outcome` columns → `solution` + `failed_approaches` + `outcome_type` (enum) + `environment` (JSONB)
2. **DDR-010**: Single `vector(1536)` → 6 per-field `vector(1024)` embeddings (bge-m3)
3. **DDR-003/004**: `agent_id` → `user_id` everywhere in credit and vote models
4. **DDR-016/017**: Added `search_feedback` table (missing from original schema)
5. **API.md**: Updated all request/response shapes to match corrected schema

---

### 1.6 Issue #1 — Project Scaffold

**What was built:**

- `pyproject.toml` — project definition, all dependencies, pytest config
- `agxp/` package structure with `__init__.py` files
- 5 Backend ABCs (DDR-018):
  - `VectorSearchBackend`
  - `FullTextSearchBackend`
  - `EmbeddingBackend`
  - `CreditWriter`
  - `QualityScoreWriter`
- `docker-compose.yml` — PostgreSQL 16 + pgvector, Redis 7.2, optional Flower
- `.gitignore`
- Scaffold unit tests (60 tests, all green)

**Errors encountered in Issue #1:**

| Error | Cause | Fix |
|-------|-------|-----|
| `tantivy-py` package not found | Wrong PyPI name | Changed to `tantivy` |
| hatchling can't find package | Build system misconfiguration | Added `[tool.hatch.build.targets.wheel] packages = ["agxp"]` |
| `[tool.uv] dev-dependencies` deprecated | uv 0.11 changed API | Changed to `[dependency-groups] dev = [...]` |
| `__pycache__` committed to git | Missing `.gitignore` | Added `.gitignore`, ran `git rm -r --cached` |

---

### 1.7 Docker Desktop Incident

**Problem:** Docker Desktop crashed on Apple Silicon with SIGSEGV:
```
panic: runtime error: invalid memory address or nil pointer dereference
goroutine 1 [running]: go-m1cpu.DetectCPU(...)
```

The uninstall script also crashed. Manual deletion of Docker application files was required.

**Fix: Installed OrbStack** instead of Docker Desktop.

**Why OrbStack:**
- Designed natively for Apple Silicon (no Rosetta required for core functionality)
- Functionally identical Docker API
- Faster container startup
- Lower memory footprint

**OrbStack setup:** Required Rosetta 2 for one component (Intel-based). Installed via:
```bash
softwareupdate --install-rosetta --agree-to-license
```

User interaction: "弹了个窗口提示：Rosetta可让基于Intel的功能在搭载Apple芯片的Mac上运行。" — confirmed this was expected, proceeded.

---

## Session 2 — Issue #2: Database Schema + Alembic Migrations

**Date:** 2026-04-02

---

### 2.1 Objective

Implement the full PostgreSQL schema via SQLAlchemy ORM models, and generate + apply the initial Alembic migration. Tests must be written before implementation (TDD).

**Test files written (red phase):**

| File | Tests | What they verify |
|------|-------|-----------------|
| `tests/unit/test_models/test_enums.py` | 3 | OutcomeType has exactly {solved, workaround, unresolved} |
| `tests/unit/test_models/test_user_model.py` | 8 | User columns, ApiKey FK/unique, AnonymousSession defaults (credit_balance=20) |
| `tests/unit/test_models/test_experience_model.py` | 12 | All content fields, 6 embedding fields, quality score components, absence of old field names |
| `tests/unit/test_models/test_credit_model.py` | 10 | CreditAccount uses user_id (not agent_id), idempotency key, SearchFeedback structure |
| `tests/integration/test_db/test_migrations.py` | 6 | upgrade/downgrade roundtrip, table existence, enum existence, HNSW index existence |
| `tests/integration/test_db/test_schema.py` | 6 | PostgreSQL constraint enforcement (FK, unique, check) |

**Initial run:** 32 unit tests, all RED with `ModuleNotFoundError: No module named 'agxp.db.models'` (expected — models didn't exist yet).

---

### 2.2 SQLAlchemy Models (`agxp/db/models.py`)

**Models created:**

```
OutcomeType (Python enum)
User           — DDR-004 identity layer
ApiKey         — DDR-004: API key auth
AnonymousSession — DDR-004: anonymous access with credit pool
Experience     — DDR-007: content fields; DDR-010: 6×vector(1024); DDR-008: quality scores
ExperienceTranslation — translation layer with UniqueConstraint(experience_id, language)
CreditAccount  — DDR-003: per-user credit balance
CreditTransaction — DDR-003: ledger with idempotency_key
QualityVote    — DDR-008: upvote/downvote with UniqueConstraint(experience_id, voter_user_id)
QueryLog       — query audit log with nullable user_id (supports anonymous queries)
SearchFeedback — DDR-016/017: agent feedback on search results
```

**Key design decisions in models:**

- `outcome_type` used `String(16)` + `CheckConstraint` initially → **changed to native PostgreSQL `Enum`** after discovering `test_outcome_type_enum_exists` expected a PG native type
- 6 vector columns: `embedding_situation`, `embedding_solution`, `embedding_lessons`, `embedding_failed`, `embedding_tags`, `embedding_environment` — all `Vector(1024)`, nullable
- `CreditAccount.user_id` has `unique=True` (one account per user)
- `QueryLog.user_id` is nullable (anonymous queries)
- `Experience.__table_args__` contains 7 B-tree indexes, all with appropriate partial index conditions

---

### 2.3 Alembic Configuration

**`alembic.ini`** — updated one line:
```ini
sqlalchemy.url = postgresql+asyncpg://agxp:agxp@localhost:5432/agxp
```

**`agxp/db/migrations/env.py`** — rewrote to support async (asyncpg):

The default Alembic env.py uses synchronous SQLAlchemy engine. Since the project only has `asyncpg` (no `psycopg2`), the env.py must use `create_async_engine` + `connection.run_sync()`:

```python
async def run_migrations_online() -> None:
    engine = create_async_engine(_get_url(), poolclass=None)
    async with engine.connect() as connection:
        await connection.run_sync(do_run_migrations)
    await engine.dispose()

if context.is_offline_mode():
    run_migrations_offline()
else:
    asyncio.run(run_migrations_online())
```

This pattern (`asyncio.run` at module level) is the standard approach for Alembic + asyncpg.

---

### 2.4 Migration Generation — First Attempt

**Command:** `uv run alembic revision --autogenerate -m "initial schema"`

**First generated file:** `8f090647b02b_initial_schema.py`

**Problem discovered:** The migration used `String(16)` for `outcome_type` (before the model was updated to use the PG enum). Deleted and regenerated.

**Second generated file:** `621fc6baa0aa_initial_schema.py`

**Additional manual additions required:**

1. **`from pgvector.sqlalchemy import Vector`** — Alembic autogenerate referenced `pgvector.sqlalchemy.vector.VECTOR` but didn't add the import. Added manually.

2. **Vector column references** — All `pgvector.sqlalchemy.vector.VECTOR(dim=1024)` replaced with `Vector(1024)`.

3. **HNSW indexes** — These are pgvector-specific and are not auto-detected by Alembic. Added manually:
   ```python
   op.execute("CREATE INDEX exp_hnsw_situation ON experiences USING hnsw (embedding_situation vector_cosine_ops) WITH (m = 16, ef_construction = 64)")
   # ... 5 more indexes
   ```

4. **Enum cleanup in downgrade** — Added `sa.Enum(name='outcome_type').drop(op.get_bind(), checkfirst=True)` to ensure the PG enum type is dropped during downgrade.

---

### 2.5 First Migration Run

**Command:** `uv run alembic upgrade head`

**Error:**
```
NameError: name 'pgvector' is not defined
```

**Cause:** The autogenerated migration referenced `pgvector.sqlalchemy.vector.VECTOR` without importing `pgvector`. Alembic's autogenerate serializes the type as a fully qualified reference but doesn't always add the import.

**Fix:** Added `from pgvector.sqlalchemy import Vector` to the migration file header, then replaced all `pgvector.sqlalchemy.vector.VECTOR(dim=1024)` with `Vector(1024)`.

**Second run:** Succeeded. All 10 tables, 14 B-tree indexes, 6 HNSW indexes created.

---

### 2.6 Unit Tests — First Run After Models Created

**Command:** `uv run pytest tests/unit/test_models/ -q`

**Result:** 31 passed, 1 failed.

**Failure:**
```
AttributeError: 'UniqueConstraint' object has no attribute 'unique'
```

**Location:** `tests/unit/test_models/test_user_model.py::test_api_key_hash_is_unique`

**Cause:** The test had buggy logic:
```python
assert any(c.unique for c in ApiKey.__table__.constraints  # wrong: UniqueConstraint has no .unique
           if ...) or col.unique
```

`UniqueConstraint` objects don't have a `.unique` attribute — that attribute exists on `Column` objects. The `col.unique` part at the end was correct on its own.

**Fix:** Simplified to `assert col.unique`.

**Result after fix:** 32/32 green.

---

### 2.7 Integration Tests — Event Loop Issues

This was the most complex debugging sequence in this session.

#### Problem 1: `RuntimeError: Task got Future attached to a different loop`

**Context:** pytest-asyncio 1.3.0 (latest). Session-scoped async `engine` fixture. Function-scoped async `session` fixture.

**Root cause:** In pytest-asyncio 1.x, the teardown of a function-scoped async fixture runs in a **different event loop** than the one used during test execution. If the fixture created asyncpg connections in the session loop, teardown in the function loop fails with "attached to a different loop".

**Attempts made:**
1. Added `loop_scope="session"` to `engine` fixture → partial fix
2. Added `loop_scope="session"` to `session` fixture → teardown still ran in wrong loop
3. Added explicit `event_loop = asyncio.new_event_loop()` session fixture → caused different issues (deprecated in pytest-asyncio 1.x)
4. Used `NullPool` to avoid connection reuse → fixed connection contamination but not loop issue

#### Problem 2: `cannot use Connection.transaction() in a manually started transaction`

**Cause:** When a test triggers an expected exception (via `pytest.raises`), SQLAlchemy's session enters an "error" state. The next test tries to use the same session but the session still has an open/errored transaction.

#### Final Solution

**Architecture:**
- `engine` — `scope="session"`, `loop_scope="session"`: created once, shared across all tests
- `_shared_session` — `scope="session"`, `loop_scope="session"`: one session for all tests; teardown wrapped in `try/except` to suppress loop-is-closed errors
- `session` (autouse) — `loop_scope="session"`: rolls back the shared session before each test to clear error state; **no teardown** (avoids the function-scope teardown loop issue)

```python
@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def _shared_session(engine):
    sess = AsyncSession(engine)
    try:
        yield sess
    finally:
        try:
            await sess.close()
        except Exception:
            pass

@pytest_asyncio.fixture(autouse=True, loop_scope="session")
async def session(_shared_session):
    try:
        await _shared_session.rollback()
    except Exception:
        pass
    yield _shared_session
```

**Why this works:**
- No function-scoped async teardown → no wrong-loop issue
- Rollback before each test → session never carries error state from previous test
- `NullPool` on engine → no connection pool state contamination
- `try/except` on final close → suppresses the "event loop closed" error that pytest-asyncio 1.x produces when the session-scoped fixture teardown runs after the loop closes

#### Problem 3: `tags: "{}"` — Wrong Python Type for ARRAY Parameter

**Error:**
```
asyncpg.exceptions.DataError: invalid input for query argument $16: '{}'
(a sized iterable container expected (got type 'str'))
```

**Cause:** `make_experience()` in `test_schema.py` had `"tags": "{}"` — a string in PostgreSQL array literal syntax. asyncpg expects a Python `list` for ARRAY parameters in parameterized queries, not a string.

**Fix:** Changed `"tags": "{}"` → `"tags": []`.

#### Problem 4: `asyncio.get_event_loop()` Deprecated

**Error in `test_migrations.py`:**
```
RuntimeError: There is no current event loop in thread 'MainThread'.
```

**Cause:** Three tests in `test_migrations.py` used the pattern:
```python
asyncio.get_event_loop().run_until_complete(async_function())
```

In Python 3.10+, `asyncio.get_event_loop()` raises `RuntimeError` when there is no current event loop (which is true in this context since pytest-asyncio manages the loop).

**Fix:** Converted all three functions to `async def` tests (since `asyncio_mode = "auto"` handles this automatically):
```python
async def test_all_tables_exist_after_upgrade(engine):
    async with engine.connect() as conn:
        result = await conn.execute(...)
```

---

### 2.8 Final Test Results

**Command:** `uv run pytest tests/ -q`

```
104 passed, 5 warnings in 0.63s
```

| Category | File | Tests | Result |
|----------|------|-------|--------|
| Unit: enums | test_enums.py | 3 | ✅ green |
| Unit: user models | test_user_model.py | 8 | ✅ green |
| Unit: experience models | test_experience_model.py | 12 | ✅ green |
| Unit: credit models | test_credit_model.py | 10 | ✅ green |
| Integration: migrations | test_migrations.py | 6 | ✅ green |
| Integration: schema constraints | test_schema.py | 6 | ✅ green |
| Unit: scaffold (Issue #1) | test_structure.py, test_abcs.py | 60 | ✅ green |
| **Total** | | **105** | **✅ 104/104** |

The 5 warnings are `RuntimeWarning: coroutine 'Connection._cancel' was never awaited` — cosmetic cleanup noise from asyncpg when the event loop closes before all pending coroutines complete. Not a test issue.

---

### 2.9 Files Changed / Created in Issue #2

| File | Action | Description |
|------|--------|-------------|
| `agxp/db/models.py` | Created | All 9 SQLAlchemy ORM models |
| `alembic.ini` | Modified | Set `sqlalchemy.url` to PostgreSQL |
| `agxp/db/migrations/env.py` | Rewritten | Async-compatible Alembic env |
| `agxp/db/migrations/versions/621fc6baa0aa_initial_schema.py` | Created | Full initial migration with HNSW indexes |
| `tests/unit/test_models/test_enums.py` | Created | Enum unit tests |
| `tests/unit/test_models/test_user_model.py` | Created | User/ApiKey/AnonymousSession unit tests |
| `tests/unit/test_models/test_experience_model.py` | Created | Experience/ExperienceTranslation unit tests |
| `tests/unit/test_models/test_credit_model.py` | Created | Credit/Vote/Feedback unit tests |
| `tests/integration/test_db/conftest.py` | Created | Async fixtures for integration tests |
| `tests/integration/test_db/test_migrations.py` | Created | Migration integration tests |
| `tests/integration/test_db/test_schema.py` | Created | Schema constraint integration tests |
| `pyproject.toml` | Modified | Added `asyncio_default_fixture_loop_scope = "session"` |
| `agxp/db/models.py` | Modified (minor) | `outcome_type` changed from String+Check to native PG Enum |

---

## Appendix A: Errors Index

| Error | File/Context | Root Cause | Fix |
|-------|-------------|-----------|-----|
| `tantivy-py` package not found | `pyproject.toml` | Wrong PyPI package name | Changed to `tantivy` |
| hatchling can't find package | `pyproject.toml` | Missing `packages` declaration | Added `[tool.hatch.build.targets.wheel]` |
| `[tool.uv] dev-dependencies` deprecated | `pyproject.toml` | uv 0.11 API change | Changed to `[dependency-groups]` |
| Docker Desktop SIGSEGV | macOS Apple Silicon | go-m1cpu crash in Docker Desktop binary | Replaced with OrbStack |
| `NameError: name 'pgvector' is not defined` | Alembic migration | Autogenerate doesn't add pgvector import | Added `from pgvector.sqlalchemy import Vector` |
| `AttributeError: 'UniqueConstraint' has no 'unique'` | `test_user_model.py` | Test bug: wrong attribute name | Simplified test to `assert col.unique` |
| `RuntimeError: Task got Future attached to different loop` | Integration conftest | pytest-asyncio 1.x function-scoped fixture teardown runs in wrong loop | Session-scoped session + autouse rollback fixture |
| `cannot use Connection.transaction() in manually started transaction` | Integration tests | Session poisoned after expected exception in previous test | Rollback before each test via autouse fixture |
| `DataError: invalid input for query argument: '{}' (expected sized iterable)` | `test_schema.py` | String `"{}"` passed for ARRAY column; asyncpg needs Python list | Changed `"tags": "{}"` to `"tags": []` |
| `RuntimeError: There is no current event loop in thread 'MainThread'` | `test_migrations.py` | `asyncio.get_event_loop()` deprecated in Python 3.10+ | Converted tests to `async def` |

---

## Appendix B: Key Design Decisions

| Decision | DDR | Rationale |
|----------|-----|-----------|
| 6 per-field embeddings instead of 1 composite | DDR-010 | Enables field-weighted search; situation≠solution≠lessons semantically |
| bge-m3 1024-dim instead of OpenAI 1536-dim | DDR-010 | Open-source, self-hosted, multilingual out of the box |
| `outcome_type` as PG native enum | — | Type safety at DB level; test explicitly checks for native enum |
| Credits scoped to `user_id` not `agent_id` | DDR-003/004 | Three-layer identity: user → api_key → attribution |
| `idempotency_key` on credit transactions | DDR-003 | Safe retry on network failures; matches CreditWriter ABC |
| `failed_approaches` nullable Text | DDR-007 | Not every experience has a documented failure path |
| `environment` as JSONB | DDR-007 | Schema-free; agent runtime info varies widely |
| `query_logs.user_id` nullable | — | Supports anonymous queries via `anon_session_id` |
| HNSW with `m=16, ef_construction=64` | DDR-010 | Balanced recall/build-time for development; tunable for production |
| `NullPool` in test engine | — | Prevents connection state leakage between tests |
| Asyncio session-scoped in tests | — | pytest-asyncio 1.x bug with function-scoped fixture teardown |

---

## Appendix C: Technology Versions

| Technology | Version | Notes |
|------------|---------|-------|
| Python | 3.11.15 | Managed by uv |
| uv | 0.11.3 | Package manager |
| SQLAlchemy | 2.0.x | ORM for schema + migrations only |
| asyncpg | 0.29.x | Runtime DB driver |
| pgvector | 0.3.x (Python), 0.8.2 (PG extension) | Vector operations |
| Alembic | 1.13.x | Schema migrations |
| pytest | 9.0.2 | Test runner |
| pytest-asyncio | 1.3.0 | Async test support |
| PostgreSQL | 16 (via `pgvector/pgvector:pg16`) | Database |
| OrbStack | latest | Container runtime (replaced Docker Desktop) |

---

## Appendix D: Pending Issues (as of end of Session 2)

Issues #3–#17 remain. The development order follows Phase 1 of ARCHITECTURE.md:

- Issue #3: Embedding pipeline (bge-m3 integration)
- Issue #4: Vector search backend
- Issue #5: Full-text search backend (tantivy)
- Issue #6: Credit system implementation
- Issue #7: Quality scoring
- Issue #8: Query API endpoint
- Issue #9: Contribute API endpoint
- Issue #10: Authentication (API key + anonymous session)
- Issue #11: CLI client
- Issue #12: MCP server adapter
- Issue #13: Translation pipeline
- Issue #14: Search feedback loop
- Issue #15: Caching layer (Redis)
- Issue #16: Observability (Prometheus + OpenTelemetry)
- Issue #17: Load testing (Locust)

---

## Session 3 — Issue #3: Embedding Pipeline

**Date:** 2026-04-02

---

### 3.1 Objective

Implement the text embedding pipeline: a concrete `EmbeddingBackend` using bge-m3 locally, a deterministic fake for unit testing, an `ExperienceEmbedder` that maps all 6 experience content fields to vectors in a single batch call, and a Celery task that fetches an experience from DB, embeds it, and writes vectors back.

---

### 3.2 Design Decisions

**Infrastructure choice:** Run bge-m3 locally via `sentence-transformers` (already in deps). Alternative of using an external API was deferred — no API endpoint available in development. Model downloads once (~1.3 GB) and is cached at `~/.cache/huggingface/hub/`.

**Singapore server deferred:** User has an Ubuntu server in Singapore. Decision: defer it to Issue #8 (Query API), when the full multi-service stack (DB + Redis + Celery + FastAPI + model) needs a dedicated environment. Overkill for Issue #3.

**`FakeEmbeddingBackend` instead of mocks:** Rather than `unittest.mock.patch`, all unit tests use a real `FakeEmbeddingBackend` that implements the full ABC. Deterministic (SHA-256 seeded), normalized, correct dimension. This tests the interface honestly without flaky mock setup.

**Single-batch invariant:** `ExperienceEmbedder.embed_experience()` sends all non-None fields in exactly one `embed()` call. Verified with a call-counting spy in `test_all_non_none_fields_in_single_batch_call`. This matters for latency: 6 sequential API calls would be ~6× slower than one batch call.

**`normalize_embeddings=True`** on `BgeM3LocalBackend`: Outputs L2-normalized vectors (‖v‖ = 1.0), matching the `vector_cosine_ops` HNSW index type in the DB schema.

**`run_in_executor`** in `BgeM3LocalBackend`: sentence-transformers `encode()` is synchronous CPU-bound work. Wrapping with `asyncio.get_running_loop().run_in_executor(None, ...)` offloads it to the default thread pool, keeping the event loop unblocked.

**`config/backends.py` updated:** `BgeM3ApiBackend` (still a stub) replaced by `BgeM3LocalBackend` as the active `EMBED_BACKEND`. The API backend stub remains for future production use.

---

### 3.3 Files Created

| File | Description |
|------|-------------|
| `agxp/search/backends/fake_embedding_backend.py` | Deterministic fake: SHA-256 seeded unit vectors |
| `agxp/search/backends/bgem3_local_backend.py` | Concrete backend: BAAI/bge-m3 via sentence-transformers |
| `agxp/search/embed.py` | `ExperienceEmbedder`: 6-field → 6-vector in single batch |
| `agxp/workers/celery_app.py` | Celery app configuration (broker + backend = Redis) |
| `agxp/workers/embed.py` | `embed_experience` Celery task with asyncpg DB interaction |
| `tests/unit/test_embed/test_fake_backend.py` | 8 unit tests for FakeEmbeddingBackend |
| `tests/unit/test_embed/test_experience_embedder.py` | 9 unit tests for ExperienceEmbedder |
| `tests/unit/test_embed/test_embed_task.py` | 2 unit tests for task registration |
| `tests/integration/test_embed/test_bgem3_local_backend.py` | 4 integration tests (requires model) |

**Modified:**
- `agxp/config/backends.py`: switched `EMBED_BACKEND` from `BgeM3ApiBackend` to `BgeM3LocalBackend`

---

### 3.4 Test Results

| Suite | Tests | Result | Notes |
|-------|-------|--------|-------|
| Unit: FakeEmbeddingBackend | 8 | ✅ green | < 0.1s |
| Unit: ExperienceEmbedder | 9 | ✅ green | < 0.1s |
| Unit: embed task | 2 | ✅ green | |
| Integration: BgeM3LocalBackend | 4 | ✅ green | 72s first run (model download); 12s cached |
| All previous tests | 104 | ✅ green | unaffected |
| **Total** | **127** | **✅ 127/127** | |

---

### 3.5 No Errors This Session

All implementation went green on first attempt. No debugging required.

The only notable moment: bge-m3 integration tests took **72 seconds on first run** (model download) and **12 seconds on subsequent runs** (model loaded from cache). This confirms the one-time download cost is acceptable.

---

### 3.6 Field Serialisation Contract

`ExperienceEmbedder` applies these rules before calling `embed()`:

| Field | Value | Text sent to embed() |
|-------|-------|----------------------|
| `situation` | `"some text"` | `"some text"` |
| `solution` | `"some text"` | `"some text"` |
| `lessons` | `"some text"` | `"some text"` |
| `failed_approaches` | `"tried X"` | `"tried X"` |
| `failed_approaches` | `None` | *(skipped, embedding = None)* |
| `tags` | `["python", "asyncio"]` | `"python, asyncio"` |
| `tags` | `[]` | *(skipped, embedding = None)* |
| `environment` | `{"language": "python"}` | `'{"language": "python"}'` |
| `environment` | `None` | *(skipped, embedding = None)* |

---

## Session 4 — Issue #4: Vector Search Backend (pgvector)

**Date:** 2026-04-02

---

### 4.1 Objective

Implement `PgvectorBackend` (real asyncpg + HNSW search) and `FakeVectorBackend` (in-memory for unit tests). Both implement the `VectorSearchBackend` ABC. Add `agxp/db/pool.py` as the asyncpg pool singleton used by production code.

---

### 4.2 Design Decisions

**`_FIELD_COLUMN` mapping** — `failed_approaches` maps to `embedding_failed` (the DB column name truncated to fit the naming convention from Issue #2). This mapping lives only in `PgvectorBackend`; callers always use the logical field name.

**Pool singleton vs DI** — `pool.py` provides `get_pool()` for production, but `PgvectorBackend.__init__` accepts `pool=None` for tests. On first use, if no pool was injected, it lazily calls `get_pool()`. This keeps `config/backends.py` unchanged (`PgvectorBackend()` with no args).

**Filter whitelist** — `_ALLOWED_FILTER_COLUMNS = frozenset({"domain", "task_type", "language", "is_published"})` prevents SQL injection through the `filters` dict. Any unknown key is silently ignored.

**asyncpg UUID type** — `pool.fetch()` returns `uuid.UUID` objects for `UUID` columns. `search()` casts to `str()` before returning so callers always receive string IDs (consistent with the rest of the codebase).

**`asyncio_default_test_loop_scope = "session"` (pyproject.toml)** — Integration tests that use a session-scoped asyncpg pool need test functions to also run in the session event loop. Adding this config key (alongside the existing `asyncio_default_fixture_loop_scope = "session"`) fixes the "Task got Future attached to a different loop" error for raw asyncpg tests. The DB integration tests (SQLAlchemy NullPool) continue to pass unaffected.

**`FakeVectorBackend` filter behaviour** — Ignores the `filters` dict entirely. Unit tests that need filter behaviour should use integration tests.

---

### 4.3 Files Created / Modified

| File | Action | Description |
|------|--------|-------------|
| `agxp/db/pool.py` | Created | asyncpg pool singleton; `register_vector` on each connection |
| `agxp/search/backends/fake_vector_backend.py` | Created | In-memory cosine similarity; ignores filters |
| `agxp/search/backends/pgvector_backend.py` | Rewritten | Real HNSW search via asyncpg; `upsert`, `delete` |
| `tests/unit/test_vector/test_fake_vector_backend.py` | Created | 13 unit tests |
| `tests/integration/test_vector/conftest.py` | Created | Session pool, module-scoped user, `insert_bare_experience` helper |
| `tests/integration/test_vector/test_pgvector_backend.py` | Created | 6 integration tests |
| `tests/unit/test_backends/test_vector_backend.py` | Updated | Removed 3 `NotImplementedError` stub tests |
| `pyproject.toml` | Updated | Added `asyncio_default_test_loop_scope = "session"` |

---

### 4.4 Errors and Fixes

**`Task got Future attached to a different loop` (integration tests)** — same root cause as Issue #2. asyncpg pool is created in the session event loop. Test functions default to function-scoped event loops in pytest-asyncio. Fix: `asyncio_default_test_loop_scope = "session"` in `[tool.pytest.ini_options]`.

**`uuid.UUID` vs `str` mismatch** — asyncpg returns `uuid.UUID` objects for UUID columns; our tests compare with string IDs. Fix: `str(row["id"])` in `search()` return value.

---

### 4.5 Test Results

```
143 passed in 15.97s
```

- Unit (FakeVectorBackend): 13 new tests — all green
- Integration (PgvectorBackend): 6 new tests — all green
- Full regression: 143/143

---

### 4.6 Next Issue

**Issue #5: Full-Text Search Backend (Tantivy BM25)** — `TantivyBackend` implementation + `FakeFTSBackend` for unit tests.

---

## Session 5 — Issue #5: Full-Text Search Backend (Tantivy BM25)

**Date:** 2026-04-02

---

### 5.1 Objective

Implement `TantivyBackend` (real in-process Rust BM25 search) and `FakeFTSBackend` (in-memory substring matching for unit tests). Both implement the `FullTextSearchBackend` ABC.

---

### 5.2 Design Decisions

**In-process Tantivy** — No external service. `TantivyBackend(path=None)` creates an in-memory index; passing a directory path persists to disk. Tests always use in-memory, production sets the path via config.

**Schema design** — Three field categories:
- `experience_id`: stored=True, tokenizer_name='raw' — primary key; stored for retrieval, raw for exact-match deletion via `writer.delete_documents(field, value)`
- Content fields (situation/solution/lessons/failed_approaches/tags/environment): default tokenizer, not stored — full-text BM25 search
- Filter fields (domain/task_type/language): tokenizer_name='raw', not stored — exact-match filter via query string `field:"value"`

**Filter implementation** — Filters are appended as AND clauses to the query string: `asyncio AND domain:"coding"`. This avoids needing to build programmatic boolean query objects and naturally integrates with Tantivy's query parser.

**`run_in_executor`** — Tantivy is sync Rust. All blocking calls dispatched to the default thread pool via `loop.run_in_executor(None, partial(...))`. The writer and index objects are safely shared across threads (Tantivy's Rust internals are thread-safe for read; single-writer enforced by design).

**`FakeFTSBackend`** — Bag-of-words substring matching: score += (term_count_in_field × field_boost) for each matching field. Ignores filters. Handles re-index by overwriting the store dict entry.

---

### 5.3 Files Created / Modified

| File | Action | Description |
|------|--------|-------------|
| `agxp/search/backends/fake_fts_backend.py` | Created | In-memory substring matching; ignores filters |
| `agxp/search/backends/tantivy_backend.py` | Rewritten | Real Tantivy BM25; field boosts; AND filters; delete by ID |
| `tests/unit/test_fts/test_fake_fts_backend.py` | Created | 14 unit tests |
| `tests/integration/test_fts/test_tantivy_backend.py` | Created | 8 integration tests (no external service) |
| `tests/unit/test_backends/test_fts_backend.py` | Updated | Removed 3 `NotImplementedError` stub tests |

---

### 5.4 Errors and Fixes

**`field_boosts=None` → `'NoneType' object cannot be converted to 'PyDict'`** — `tantivy.Index.parse_query()` accepts `field_boosts=Ellipsis` (default) but NOT `field_boosts=None`. Passing `None` raised an exception that was caught silently, causing all searches to return `[]`. Root cause: the code guarded with `if valid_boosts else None` which passes `None` when no boosts exist. Fix: only pass the `field_boosts` kwarg when `valid_boosts` is non-empty; omit it entirely otherwise.

**`doc.get("field")` → `AttributeError`** — `tantivy.Document` does not expose a `.get()` method. Use subscript access: `doc["experience_id"]` returns `['exp-001']` (a list). Fixed to `doc["experience_id"]`.

---

### 5.5 Tantivy 0.25.0 API Notes (for future reference)

```python
# Schema
sb = tantivy.SchemaBuilder()
sb.add_text_field("experience_id", stored=True, tokenizer_name="raw")
sb.add_text_field("situation", stored=False)          # default tokenizer
schema = sb.build()

# Index (in-memory)
idx = tantivy.Index(schema)
writer = idx.writer(heap_size=50_000_000)

# Indexing
doc = tantivy.Document()
doc.add_text("experience_id", exp_id)
doc.add_text("situation", text)
writer.add_document(doc)
writer.commit()

# Search with field boosts
idx.reload()
searcher = idx.searcher()
q = idx.parse_query("asyncio AND domain:\"coding\"", ["situation", "solution"],
                     field_boosts={"situation": 2.0})
results = searcher.search(q, limit=10)
for score, addr in results.hits:
    doc = searcher.doc(addr)
    exp_id = doc["experience_id"][0]  # list!

# Delete by ID
writer.delete_documents("experience_id", exp_id)
writer.commit()
```

---

### 5.6 Test Results

```
162 passed in 12.54s
```

- Unit (FakeFTSBackend): 14 new tests — all green
- Integration (TantivyBackend, in-process): 8 new tests — all green
- Full regression: 162/162

---

### 5.7 Next Issue

**Issue #6: Credit System** — `PostgresCreditWriter` + `FakeCreditWriter` + `award_credits` Celery worker.

---

## Session 6 — Post-Retrospective Fixes (Issues #3–5)

**Date:** 2026-04-02

A retrospective code review (three independent sub-agents, one per issue) found 10 BLOCKING problems across Issues #3–5. Fixes are applied one at a time, each with its own test run and code review.

---

### Fix 5-3/5-4 — FTS test asyncio marker

**Problem:** Both FTS test files lacked `pytestmark = pytest.mark.asyncio(loop_scope="session")`.

**Original diagnosis (from retrospective):** Tests silently ran as no-ops, giving zero FTS coverage.

**Correction on re-examination:** The project has `asyncio_mode = "auto"` in pyproject.toml, which causes pytest-asyncio to collect and run async test functions automatically without an explicit marker. The tests were therefore executing correctly before this fix. The `pytestmark` addition is still beneficial: it makes `loop_scope` explicit and guards against future config changes, but it was not repairing a no-op condition.

**Files changed:**
- `tests/unit/test_fts/test_fake_fts_backend.py` — added `pytestmark`
- `tests/integration/test_fts/test_tantivy_backend.py` — added `pytestmark`

**Test result:** 22 passed (14 unit + 8 integration). Full regression: 140 passed.

**Code review verdict:** APPROVED.

**Open item (non-blocking):** 11 other async test files in the project lack `pytestmark`. They run correctly today under `asyncio_mode = "auto"`. Recommend adding `pytestmark` to all of them for consistency in a future cleanup pass.

---

### Fix 5-1/5-2 — TantivyBackend exception narrowing + IndexWriter lock

**5-1:** `except Exception: return []` in `_search_sync` swallowed all errors including programming bugs. Narrowed to `except tantivy.QueryParserError` — only malformed user queries return `[]`; all other exceptions propagate.

**5-2:** `_index_sync` and `_delete_sync` dispatched to thread pool via `run_in_executor` with no synchronisation on the shared `IndexWriter`. Added `self._writer_lock = threading.Lock()` in `__init__`. Both sync methods now acquire the lock around the entire write transaction (delete + add + commit) atomically.

**Note (from code review):** `_search_sync` intentionally reads outside the lock — Tantivy uses MVCC-style reader snapshots; `reload()` + `searcher()` are safe to call concurrently with an active writer by design.

**Files changed:** `agxp/search/backends/tantivy_backend.py`

**Test result:** 22 passed (FTS unit + integration). Full regression: 140 passed.

**Code review verdict:** APPROVED.

---

### Fix 4-1/4-2/4-3 — PgvectorBackend filter validation, UUID cast, pool lock

**4-1:** Unknown filter keys in `search()` now raise `ValueError(f"Unknown filter key: {key!r}")` immediately instead of being silently dropped.

**4-2:** `upsert()` and `delete()` both now cast `experience_id` via `uuid.UUID(experience_id)` before binding to asyncpg. First-pass review missed `delete()`; caught by code review sub-agent in CHANGES_REQUESTED round. `search()` already used `str(row["id"])` on the way out — unchanged.

**4-3:** `pool.py` now uses `asyncio.Lock()` at module level (safe: `requires-python = ">=3.11"` confirmed). `get_pool()` acquires the lock before the `_pool is None` check, preventing concurrent first-call races.

**Files changed:** `agxp/search/backends/pgvector_backend.py`, `agxp/db/pool.py`

**Test result:** 16 passed (vector unit). Full regression: 140 passed.

**Code review verdict:** APPROVED (after one CHANGES_REQUESTED round).

---

### Fix 3-1/3-2/3-3 — Embed worker pool, asyncio guard, model load lock

**3-1:** `_embed_experience_async` replaced bare `asyncpg.connect()` with `get_pool()` shared pool. Pool already registers the pgvector codec on every connection via `init=register_vector`, so no separate codec call needed. Added `uuid.UUID(experience_id)` cast to both the SELECT and UPDATE parameters. Connection returned to pool via `async with pool.acquire() as conn` — no leak on exception.

**3-2:** Replaced `asyncio.run()` with `_run_async()` helper. Detects a running event loop via `asyncio.get_running_loop()`; if found, submits the coroutine to a `ThreadPoolExecutor` thread that runs `asyncio.run()` in a fresh loop (safe: coroutine is unscheduled at that point). Normal Celery prefork workers have no running loop and take the direct `asyncio.run()` path.

**3-3:** `BgeM3LocalBackend._load()` now uses double-checked locking with `threading.Lock`. Outer `if self._model is None` check is atomic under CPython's GIL; inner check inside the lock prevents the second thread from loading the model again after the first completes.

**Latent risk noted (not introduced here):** `asyncio.Lock` in `pool.py` is not safe if `get_pool()` is called concurrently from multiple threads each running their own event loop (the `_run_async` ThreadPoolExecutor path). In practice this requires multiple tasks hitting the very first pool init simultaneously from the thread path — unlikely, but noted for future hardening.

**Files changed:** `agxp/workers/embed.py`, `agxp/search/backends/bgem3_local_backend.py`

**Test result:** 25 passed (embed unit). Full regression: 140 passed.

**Code review verdict:** APPROVED.

---

---

## Session 7 — Issue #6: Credit System

**Date:** 2026-04-02

---

### 6.1 Objective

Implement `PostgresCreditWriter` (real asyncpg) and `FakeCreditWriter` (in-memory), both satisfying the `CreditWriter` ABC. Also implement the `award_credits` Celery worker.

---

### 6.2 Design Decisions

**`InsufficientCreditsError` placement** — defined in `agxp/services/credit_writer.py` alongside the ABC, so importers get both in one import.

**Debit ledger sign convention** — debit stores `-amount` in `credit_transactions.amount`. Standard double-entry bookkeeping: credits are positive, debits are negative.

**`reference_type = "experience"`** — set whenever `experience_id` is supplied to `credit()`. Makes the ledger self-describing for future analytics (no need to JOIN experiences to understand what generated each credit row).

**`get_balance` for unknown user** — returns `0`. No exception. Allows negative balances at the code layer (per user decision); `InsufficientCreditsError` is the guard at debit time.

**Idempotency key scope** — global unique (`UNIQUE` constraint on `credit_transactions.idempotency_key`). Callers must include enough context in the key (e.g. `f"award_contribution_{exp_id}"`). Rationale: the business event (one experience → one award) is itself globally unique; global uniqueness catches more bugs than per-user scoping.

**`credit()` auto-creates account** — if no `credit_accounts` row exists for a `user_id`, `credit()` creates one. This supports the anonymous flow and simplifies onboarding.

**`award_credits` worker** — fixed `CONTRIBUTION_AWARD_CREDITS = 25` for Issue #6. Issue #7 (quality scoring) will replace this with a quality-weighted formula. `InsufficientCreditsError` is explicitly re-raised before the generic retry handler — domain errors must not burn retries.

---

### 6.3 Files Created / Modified

| File | Action | Description |
|------|--------|-------------|
| `agxp/services/credit_writer.py` | Updated | Added `InsufficientCreditsError` |
| `agxp/services/fake_credit_writer.py` | Created | In-memory, global idempotency key store |
| `agxp/services/postgres_credit_writer.py` | Implemented | asyncpg, FOR UPDATE, atomic transactions |
| `agxp/workers/credit.py` | Created | `award_credits` Celery task |
| `tests/unit/test_credit/test_fake_credit_writer.py` | Created (tester agent) | 28 unit tests |
| `tests/integration/test_credit/conftest.py` | Created (tester agent) | Session pool, function-scoped user fixture |
| `tests/integration/test_credit/test_postgres_credit_writer.py` | Created (tester agent) | 20 integration tests |
| `tests/unit/test_backends/test_credit_writer.py` | Updated | Removed 3 NotImplementedError stub tests |

---

### 6.4 Errors and Fixes

**conftest.py UUID cast (CHANGES_REQUESTED)** — All `user_id` and `account_id` strings in fixture INSERTs, DELETEs, and `seed_balance` were passed as raw `str` to UUID columns. Fixed by wrapping all with `uuid.UUID()`.

**Dead import in second_credit_test_user** — removed `import asyncpg as _asyncpg` (redundant, module-level import already present).

---

### 6.5 Test Results

```
48 passed (28 unit + 20 integration) in 0.32s
Full regression: 185 passed
```

**Code review verdict:** APPROVED (after one CHANGES_REQUESTED round — UUID cast missing in fixtures).

---

### 6.6 Next Issue

**Issue #7: Quality Scoring** — `InlineQualityWriter` + `score_quality` Celery worker.

---

## Session 7 — Issue #7: Quality Scoring

**Date:** 2026-04-02

---

### 7.1 Objective

Implement Phase 1 quality scoring:
- `FakeQualityWriter` (in-memory test double)
- `InlineQualityWriter` (real DB — Phase 1 formula from DDR-008)
- `score_quality` Celery worker (pipeline: embed → index_bm25 → score_quality → award_credits)
- Updated `award_credits` to use quality-weighted credit amounts

---

### 7.2 Design Decisions

**Phase 1 formula (DDR-008):**
```
quality_score = 0.40 × uniqueness_score
              + 0.35 × completeness_score
              + 0.25 × community_score
```

**completeness_score** — purely rule-based, extracted to module-level `compute_completeness_score(row: dict)`:
- 0.50 base
- +0.15 failed_approaches non-empty
- +0.10 environment non-empty dict
- +0.10 solution or lessons contains `\d{2,}` or `\d+%`
- +0.10 lessons word count > 100
- +0.05 tags count >= 3
- capped at 1.0

**community_score** cold-start: `completeness_score × 0.5`. With activity: `0.6 × vote_score + 0.4 × use_score` where use_score uses log-scale normalisation (MAX_USE_COUNT=1000).

**uniqueness_score** — pgvector nearest-neighbor cosine distance on `embedding_situation`. If no neighbors or NULL embedding: 1.0 (maximally unique).

**JSONB handling** — asyncpg returns JSONB as Python `str`, not `dict`. `recompute_score` parses with `json.loads()` before passing to `compute_completeness_score`, which always receives `dict | None`.

**Credit reward mapping:**
```
[0.0, 0.5)  →  5 credits
[0.5, 0.7)  → 10 credits
[0.7, 0.85) → 25 credits
[0.85, 1.0] → 50 credits
```
Extracted to `credits_for_quality(quality_score: float) -> int` in `credit.py`.

**Pipeline chain** — `score_quality` task calls `QUALITY_WRITER.recompute_score()` then `award_credits.delay(experience_id, user_id, quality_score)`. The `award_credits` signature gains `quality_score: float = 0.0` (default 0.0 for backward compatibility).

---

### 7.3 Files Changed

| File | Change |
|------|--------|
| `agxp/services/fake_quality_writer.py` | New — in-memory FakeQualityWriter with `seed()` helper |
| `agxp/services/inline_quality_writer.py` | Implemented — Phase 1 formula, pool injection |
| `agxp/workers/score_quality.py` | New — `score_quality` Celery task |
| `agxp/workers/credit.py` | Added `credits_for_quality()`, updated `award_credits` signature |
| `tests/unit/test_quality/` | New — 4 test modules, 48 unit tests |
| `tests/integration/test_quality/` | New — conftest + 8 integration tests |
| `tests/unit/test_backends/test_quality_writer.py` | Removed 2 NotImplementedError stub tests |

---

### 7.4 Code Review Findings

**BLOCKING (fixed):**
- `score_quality` was retrying on `ValueError` (experience not found) — added `except ValueError: raise` guard, matching the `InsufficientCreditsError` pattern in `award_credits`.

**WARN (fixed):**
- `_run_async()` duplication across worker files — added TODO comments pointing to future extraction.
- `test_update_score_clamps_to_one` DB assertion was `<= 1.0` not `== pytest.approx(1.0)` — tightened.

---

### 7.5 Test Results

```
256 passed, 7 warnings in 13.22s
Collected: 256 | Run: 256 | Match: YES
```

**Code review verdict:** APPROVED (after one CHANGES_REQUESTED round — ValueError retry guard missing).

---

### 7.6 Next Issue

**Issue #8: Query API endpoint** — FastAPI endpoint for hybrid search (vector + BM25 + RRF + rerank + quality blend).

---

## Session 8 — Issue #8: Query API Endpoint

**Date:** 2026-04-02

---

### 8.1 Overview

Implemented the `POST /api/v1/query` NDJSON streaming endpoint, including the full
hybrid search pipeline and cross-encoder reranking.

---

### 8.2 New Files

| File | Purpose |
|------|---------|
| `agxp/search/reranker.py` | `CrossEncoderReranker` ABC |
| `agxp/search/fake_reranker.py` | `FakeCrossEncoder` — token-overlap scorer for tests |
| `agxp/search/miniml_reranker.py` | `MiniLMCrossEncoder` — lazy-loaded `cross-encoder/ms-marco-MiniLM-L-6-v2` |
| `agxp/search/query_pipeline.py` | `QueryPipeline`, `QueryRequest`, `rrf_fusion()`, `quality_blend()` |
| `agxp/api/app.py` | FastAPI app with `/api/v1` prefix |
| `agxp/api/routes/query.py` | `POST /api/v1/query` NDJSON streaming endpoint |

---

### 8.3 Key Design Decisions

**Pipeline contract**: `QueryPipeline.run()` returns up to `_RRF_LIMIT=150` RRF-fused
candidates. The route handler applies `min_quality` filter, cross-encoder reranking (top-20),
quality blending, and final `request.limit` slice. This separation means the pipeline is
reusable independently of the HTTP layer.

**Lazy PIPELINE sentinel**: `PIPELINE = None` at module scope; `_get_pipeline()` initializes
on first request. Prevents TantivyBackend, BgeM3LocalBackend, and MiniLMCrossEncoder from
loading at import time — critical for keeping `test_imports.py` fast.

**NDJSON streaming**: Three frame types: `meta` (query_id + pipeline latency), `result` (one
per returned experience), `done` (total count). Error handling: entire `_generate()` body
wrapped in `try/except`, yields `{"type": "error", "message": ...}` on failure so the client
always receives valid NDJSON even on mid-stream exceptions.

**MiniLM lazy load**: Double-checked locking with `threading.Lock` in `_get_model()`. Model
inference dispatched via `loop.run_in_executor(None, model.predict, pairs)` to avoid blocking
the event loop.

**Quality blend**: `0.7 × reranker_score + 0.3 × quality_score`

**RRF**: `Σ 1/(k + rank_i)`, k=60, over BM25 and vector rankings.

---

### 8.4 Review Rounds

**Round 1 — CHANGES REQUESTED (3 BLOCKING, 2 WARN)**

| # | Severity | Issue |
|---|----------|-------|
| B1 | BLOCKING | `PIPELINE = _make_pipeline()` at module scope caused heavy I/O at import time |
| B2 | BLOCKING | `_generate()` had no try/except — mid-stream exceptions silently swallowed |
| B3 | BLOCKING | `MiniLMCrossEncoder` instantiated twice (unused `RERANKER` in `backends.py` + `_make_pipeline()`) |
| W1 | WARN | `asyncio.get_event_loop()` should be `asyncio.get_running_loop()` in `miniml_reranker.py` |
| W2 | WARN | `failed_approaches` missing from SELECT and NDJSON |

Fixes applied:
- `PIPELINE = None` sentinel + `_get_pipeline()` lazy init
- `try/except Exception` wrapping entire `_generate()` body
- Removed `RERANKER` from `backends.py`; single `MiniLMCrossEncoder` in `_get_pipeline()`
- `asyncio.get_running_loop()` in `miniml_reranker.py`
- Added `failed_approaches` to SELECT and NDJSON result dict

**Round 2 — CHANGES REQUESTED (2 WARN)**

| # | Severity | Issue |
|---|----------|-------|
| W1 | WARN | Pipeline truncated to `request.limit` before reranking, discarding candidates prematurely |
| W2 | WARN | `quality_score` Decimal not cast to `float` before `json.dumps` → latent `TypeError` |

Fixes applied:
- Removed `[:request.limit]` from `QueryPipeline.run()`; now returns full `_RRF_LIMIT=150`
- Added `float(exp["quality_score"])` cast in NDJSON serialization
- Updated `test_run_respects_limit` → `test_run_returns_all_candidates` to reflect new contract

**Round 3 — APPROVED**

All fixes confirmed correct. No new issues.

---

### 8.5 Test Results

236 unit tests pass (including all Issue #8 tests). 0 failures.

---

## Session 9 — Issue #9: Contribute API Endpoint (PLANNED, not yet implemented)

**Date:** 2026-04-03 (continuing tomorrow)

---

### 9.1 Design

`POST /api/v1/contribute` — submit a new experience, return 202 with estimated credits.

#### New / modified files

| File | Action |
|------|--------|
| `agxp/api/routes/contribute.py` | New |
| `agxp/api/app.py` | Mount new router |
| `agxp/workers/embed.py` | Add `user_id` param; chain to `score_quality` after embedding |

#### ContributeRequest fields

| Field | Required | Validation |
|-------|----------|------------|
| `situation` | yes | min=50, max=4000 |
| `solution` | yes | min=50, max=4000 |
| `outcome_type` | yes | `"solved"\|"workaround"\|"unresolved"` |
| `lessons` | yes | min=30, max=2000 |
| `domain` | yes | max=64 |
| `task_type` | yes | max=64 |
| `language` | yes | max=8 |
| `failed_approaches` | no | max=4000 |
| `environment` | no | dict |
| `subdomain` | no | max=64 |
| `tags` | no | max 10 items, each max 32 chars |
| `user_id` | yes | replaced by auth middleware in Issue #10 |

#### Route handler steps

1. Pydantic validation
2. Generate `experience_id = uuid4()`
3. `INSERT INTO experiences (...)` — asyncpg, JSONB fields via `json.dumps()`
4. BM25 in-process index via `FTS_BACKEND.index()` (same singleton as query route)
5. `embed_experience.delay(experience_id, user_id=user_id)` Celery dispatch
6. Estimate credits: `credits_for_quality(completeness_score(request_dict))`
7. Return 202 `{experience_id, status:"pending_scoring", estimated_credits, message}`

#### Module-level patchable helpers (for unit tests)

```python
async def insert_experience(experience_id, request) -> None   # patches DB
async def fts_index_experience(experience_id, doc) -> None    # patches FTS
def dispatch_embed(experience_id, user_id) -> None            # patches Celery
```

#### embed_experience update

```python
def embed_experience(self, experience_id: str, user_id: str | None = None) -> dict:
    # ... existing embedding logic ...
    if user_id:
        score_quality.delay(experience_id, user_id)
    return {"status": "ok", "experience_id": experience_id}
```

#### Test plan

- `tests/unit/test_contribute/test_contribute_request.py` — Pydantic validation (7 cases)
- `tests/unit/test_contribute/test_contribute_route.py` — 202 response, body, task dispatch
- `tests/unit/test_contribute/test_estimated_credits.py` — estimation logic
- `tests/integration/test_contribute/test_contribute_integration.py` — real DB + Tantivy

---

### Retrospective fix summary

All 10 BLOCKING items from the post-Issue-#3–5 code review are resolved. Each fix went through: implement → test → independent code review sub-agent → DEV_LOG.

| Fix | Issue | Verdict | Rounds |
|-----|-------|---------|--------|
| FTS test markers (5-3/5-4) | asyncio marker missing | APPROVED | 1 |
| TantivyBackend exception + lock (5-1/5-2) | bare except + no writer lock | APPROVED | 1 |
| PgvectorBackend filter + UUID + pool lock (4-1/4-2/4-3) | silent filter bypass, str/UUID mismatch, pool race | APPROVED | 2 (delete() UUID missed in first pass) |
| Embed worker pool + asyncio guard + model lock (3-1/3-2/3-3) | no register_vector, asyncio.run fragile, race on _load | APPROVED | 1 |

---

## Session 10 — Issue #9: Contribute API Endpoint

**Date:** 2026-04-03

---

### 10.1 Objective

Implement `POST /api/v1/contribute` — accept new experience contributions, persist to DB, index for BM25, dispatch async embedding + quality scoring pipeline, and return 202 with estimated credits.

---

### 10.2 Design Decisions

**Module-level patchable helpers** — `insert_experience()`, `fts_index_experience()`, `dispatch_embed()` are plain module-level async/sync functions. Unit tests patch these three names directly instead of injecting fakes through DI. This matches the pattern established by the query route (`fetch_experiences_by_ids`, `PIPELINE`).

**ContributeRequest validation** — Pydantic v2 model with `Annotated[str, Field(...)]` for length constraints. Tags validated via `@field_validator`: max 10 items, each max 32 chars. `outcome_type` uses a `str` Enum subclass for automatic JSON schema + 422 on invalid values.

**Estimated credits** — Route computes `credits_for_quality(compute_completeness_score(row))` synchronously before returning. This gives the user an immediate estimate; the real score comes later from the async pipeline (embed → score_quality → award_credits).

**embed_experience chaining** — Added optional `user_id` parameter. When provided, `_embed_experience_async` calls `score_quality.delay(experience_id, user_id)` after persisting embeddings. Import is deferred to avoid circular imports between workers.

**Completeness 0.50 → 10 credits (not 5)** — Initial test assumed 0.50 completeness maps to 5 credits, but `credits_for_quality` boundary is `[0.5, 0.7) → 10`. Corrected in the test.

---

### 10.3 Files Created / Modified

| File | Action | Description |
|------|--------|-------------|
| `agxp/api/routes/contribute.py` | Created | ContributeRequest model, route handler, 3 patchable helpers |
| `agxp/api/app.py` | Modified | Mount contribute router at `/api/v1` |
| `agxp/workers/embed.py` | Modified | Added `user_id` param; chains to `score_quality` when provided |
| `tests/unit/test_contribute/__init__.py` | Created | Package marker |
| `tests/unit/test_contribute/test_contribute_request.py` | Created | 9 Pydantic validation tests |
| `tests/unit/test_contribute/test_contribute_route.py` | Created | 7 route handler tests (202, body fields, helper calls, 422) |
| `tests/unit/test_contribute/test_estimated_credits.py` | Created | 5 estimation logic tests |

---

### 10.4 Errors and Fixes

**Completeness-to-credit boundary mismatch** — Test `test_minimal_contribution_estimates_five_credits` expected 5 credits for completeness=0.50, but `credits_for_quality(0.50)` returns 10 (boundary is `[0.5, 0.7) → 10`, not `[0.0, 0.5) → 5`). Fix: corrected test expectation to 10 and renamed test accordingly.

---

### 10.5 Test Results

```
257 passed in 1.84s
```

- New unit tests: 21 (9 validation + 7 route + 5 estimation)
- Full regression: 257/257 (was 236 before this issue)

---

### 10.6 Next Issue

**Issue #10: Authentication** — API key + anonymous session middleware.

---

## Session 10 — Issue #10: Authentication (API Key + Anonymous Session)

**Date:** 2026-04-03

---

### 10.1 Scope

Add Bearer token authentication to both API endpoints (contribute + query). Two token paths: registered users (via `api_keys` table) and anonymous sessions (via `anonymous_sessions` table). Anonymous users can query but cannot contribute (403).

Token format: `agxp_<key_uuid_hex32>_<secret_hex32>` (registered) and `agxp_anon_<session_uuid_hex32>_<secret_hex32>` (anonymous). UUID prefix enables O(1) DB lookup; only the secret is bcrypt-hashed.

---

### 10.2 New Files

| File | Purpose |
|------|---------|
| `agxp/auth/models.py` | `AuthIdentity` + `ParsedToken` frozen dataclasses |
| `agxp/auth/keys.py` | Pure functions: generate, parse, hash, verify tokens |
| `agxp/auth/dependency.py` | `require_auth` FastAPI dependency (DB lookup + bcrypt verify) |
| `agxp/auth/__init__.py` | Public exports |
| `tests/unit/test_auth/test_keys.py` | 12 tests: token format, parsing, hash round-trip |
| `tests/unit/test_auth/test_dependency.py` | 12 tests: all auth failure/success paths |

---

### 10.3 Modified Files

| File | Change |
|------|--------|
| `agxp/api/routes/contribute.py` | Removed `user_id` from `ContributeRequest`; added `Depends(require_auth)`; 403 guard for anonymous; `insert_experience` takes `user_id` as separate arg |
| `agxp/api/routes/query.py` | Added `Depends(require_auth)` to endpoint signature |
| `tests/unit/test_contribute/test_contribute_request.py` | Removed `user_id` from `_valid_payload()` |
| `tests/unit/test_contribute/test_contribute_route.py` | Added auth dependency override fixture; added anonymous 403 test; updated dispatch assertions to use identity.user_id |
| `tests/unit/test_api/test_query_endpoint.py` | Added auth dependency override fixture |
| `tests/unit/test_scaffold/test_imports.py` | Added 3 new auth modules to MODULES list |

---

### 10.4 Key Decisions & Lessons

1. **passlib/bcrypt incompatibility**: `passlib.hash.bcrypt` fails with newer `bcrypt>=4.1` (no `__about__` attribute, 72-byte password limit errors). Switched to using `bcrypt` library directly (`bcrypt.hashpw` / `bcrypt.checkpw`). This is simpler and avoids the compatibility layer entirely.

2. **`asyncio.get_running_loop()` over `get_event_loop()`**: Code review caught use of deprecated `get_event_loop()` inside async functions. Fixed to `get_running_loop()` which is correct and forward-compatible with Python 3.12+.

3. **Fire-and-forget task error handling**: `asyncio.create_task(touch_api_key(...))` silently swallowed exceptions. Added `task.add_done_callback(_log_task_error)` to log failures without blocking the request.

4. **Dependency override pattern for tests**: FastAPI's `app.dependency_overrides[require_auth]` is the cleanest way to inject fake auth in route tests. Used `autouse=True` fixture with cleanup in `yield`.

---

### 10.5 Test Results

```
285 passed in 7.13s
```

- New unit tests: 25 (12 keys + 12 dependency + 1 anonymous-403)
- Updated tests: ~12 (contribute + query route tests with auth overrides)
- Full regression: 285/285 (was 257 before this issue)

---

### 10.6 Next Issue

**Issue #11: CLI Client** — `agxp` command-line tool for contributing and querying experiences.

---

## Session 11 — Phase Restructure: Local-First Priority

**Date:** 2026-04-03

---

### 11.1 Strategic Decision

Major direction change: **Local-first standalone tool becomes Phase 1 (primary product).** Server mode becomes Phase 2 (community/enterprise extension).

**Motivation:**
- Coding agents dramatically increase code output velocity → experience accumulation is fast (est. 5K-7.5K experiences/year per developer with auto-recording)
- `pip install agxp && agxp init` is infinitely lower barrier than deploying PostgreSQL + Redis + Celery
- A 5-person team hits 50K experiences in ~2 years; architecture must handle 100K+ locally
- Personal knowledge base (Phase 1) and community sharing (Phase 2) can coexist

### 11.2 Phase 1 Tech Stack

| Component | Technology | Why |
|-----------|-----------|-----|
| Storage | SQLite3 (stdlib) | Zero dependency, single file `~/.agxp/local.db` |
| BM25 | Tantivy (already in project) | In-process Rust, file-backed `~/.agxp/tantivy_index/` |
| Vector index | hnswlib (~1MB wheel) | ~2ms/query at 100K; file-persisted `~/.agxp/hnsw_index.bin` |
| Embeddings | all-MiniLM-L6-v2 (80MB) | Good quality, lightweight vs BgeM3 (1.3GB) |
| Reranking | MiniLMCrossEncoder (same as Phase 2) | Already implemented |
| Pipeline | Synchronous (no Celery) | Embed + index inline on contribute |
| Auth | None | Single-user local tool |
| Credits | None | Personal knowledge base doesn't need credit economy |

### 11.3 New Roadmap

**Phase 1 — Local-First Standalone Tool:**
- #11a: SqliteStore + HnswlibBackend + MiniLMEmbeddingBackend
- #11b: Local config + synchronous pipeline
- #11c: CLI: `agxp init` / `contribute` / `query`

**Phase 2 — Server + Community Sharing:**
- #12: CLI server mode
- #13: MCP server adapter
- #14-#18: Translation, feedback, caching, observability, load testing

Issues #1-#10 are Phase 2 server implementation — fully reusable when Phase 2 starts.

### 11.4 Documents Updated

See `docs/CHANGELOG-phase-restructure.md` for full change log. Key files updated:
- `CLAUDE.md` — Phase 1/2 split, dual tech stack, new roadmap
- `docs/AGENT_CONTEXT.md` — Phase-aware backend table, dual constraints
- `pyproject.toml` — core deps (Phase 1) vs `[server]` optional group (Phase 2)
- `docs/TESTER_PROMPT.md` — Phase-aware instructions
- `docs/CODE_REVIEW_PROMPT.md` — Phase 1 checklist items (SQLite, hnswlib, threading)
- `docs/HARNESS.md` — Phase annotation on system diagram
- `docs/API.md` — Phase 2-only notice
- `docs/DEV_LOG.md` — this session

---

## Session 12 — Phase 1 MVP: Implementation, Testing, Bug Fixes

**Date:** 2026-04-03 to 2026-04-05

---

### 12.1 Implementation (#11a-c)

- #11a: SqliteStore + HnswlibBackend + MiniLMEmbeddingBackend (51 tests)
- #11b: LocalConfig + LocalPipeline (21 tests)
- #11c: CLI: agxp init / contribute / query (53 tests)
- #12: agxp status command (15 tests)

### 12.2 User Testing

- Mac 端 `pip install` + `agxp init` + `contribute` + `query` 全链路跑通
- Docker (python:3.11-slim) 端到端验证通过
- 发现安装大小问题：默认 pip install torch 拉 GPU 版 5.1GB → 分层安装 base/[local]/[server]

### 12.3 Integration Test Report (2026-04-04)

另一个 session 用 Phase 2 Server（PostgreSQL + Redis + FastAPI）跑了 100 条真实数据，发现 6 个问题：Celery 没启动、Tantivy 目录不存在、无 credit account、缺 embeddings 时查询返回垃圾、无 .env 支持、无统一启动脚本。这些都是 Phase 2 Server 问题，Phase 1 Local 不受影响。

### 12.4 Key Lessons

1. **426 单元测试全绿 ≠ 系统能跑** — 所有外部依赖被 mock，零集成测试
2. **设计检查要包含基础设施依赖** — /design-check 升级增加 Category 11-13
3. **tester prompt 要包含降级测试和 E2E 测试** — 不能只写单元测试
4. **hnswlib 必须显式 save()** — 不像 Tantivy 自动持久化（bug B2，已修复）
5. **嵌入架构决策** — 服务器统一嵌入，Agent 只传文本，不同 LLM embedding 不可混搜

### 12.5 Bug Fixes

| Bug | 修复 | 状态 |
|-----|------|------|
| B2: hnswlib 不持久化 | LocalPipeline.contribute() 末尾加 save() | ✅ 已修 |
| #8: 模型加载无提示 | 加 "Loading model..." 打印 | ✅ 已修 |
| #9: HuggingFace WARNING 噪音 | 抑制日志 | ✅ 已修 |
| B1: hnswlib 忽略 filters | over-fetch + post-filter via metadata_fn | ✅ 已修 (#22) |
| B4: outcome_type 无校验 | CLI + SqliteStore 两层校验 | ✅ 已修 (#23) |
| B5: Tantivy filter 转义不完整 | _escape_tantivy_value 全特殊字符转义 | ✅ 已修 (#24) |
| B6: 嵌套 environment FTS 文本 | _flatten_env_to_text 递归展平 | ✅ 已修 (#25) |

### 12.6 Test Suite

```
506 passed (426 unit + 80 integration) in 39.00s
```

---

## Session 13 — Issue #22: HnswlibBackend filters

**Date:** 2026-04-05

### 13.1 Problem

`HnswlibBackend.search()` accepted `filters` dict but ignored it entirely. Vector search returned results regardless of domain/task_type constraints, while FTS (Tantivy) correctly filtered. This meant RRF fusion mixed filtered BM25 results with unfiltered vector results.

### 13.2 Design Decisions

1. **Over-fetch + post-filter** — hnswlib is a pure vector index with no metadata support. Solution: fetch `limit * 3` candidates from hnswlib, then filter using metadata from SqliteStore.
2. **metadata_fn callback** — `HnswlibBackend` receives `Callable[[list[str]], dict[str, dict]]` at init, keeping it decoupled from SqliteStore directly.
3. **Lock separation** — knn_query runs inside the hnswlib lock; metadata_fn is called outside the lock to avoid holding it during SQLite I/O.
4. **Filter whitelist = {domain, task_type}** — `language` deliberately excluded. Future architecture decision: all content stored/searched in English, agents translate client-side.
5. **SqliteStore.get_many()** — batch fetch to avoid N+1 per-candidate lookups.

### 13.3 Code Review Findings

- Double `_row_to_dict()` call in get_many dict comprehension → fixed to single call per row
- Redundant string quoting on type hint with `from __future__ import annotations` → cleaned

### 13.4 Files Changed

| File | Change |
|------|--------|
| `agxp/search/backends/hnswlib_backend.py` | Added `metadata_fn`, `_ALLOWED_FILTER_KEYS`, over-fetch + post-filter in `search()` |
| `agxp/store/sqlite_store.py` | Added `get_many()` batch method |
| `agxp/config/local.py` | Passes `metadata_fn=store.get_many` to HnswlibBackend |
| `tests/unit/test_vector/test_hnswlib_filters.py` | 13 new filter tests |
| `tests/unit/test_store/test_sqlite_get_many.py` | 9 new get_many tests |

### 13.5 Test Suite

```
528 passed (448 unit + 80 integration) in 41s
```

### 13.6 Session 13b — Issue #23: outcome_type 校验

**Bug:** CLI contribute 的 outcome_type 是裸字符串，任意值可入库。

**修复：**
- `SqliteStore.insert()` — `_VALID_OUTCOME_TYPES` 白名单校验，非法值 raise ValueError
- `agxp/cli/commands/contribute.py` — 入口校验，非法值友好报错 + exit(1)
- 更新 `test_outcome_type_no_validation` → `test_outcome_type_validated_on_contribute`
- 修复 `test_sqlite_get_many.py` 中默认 outcome_type 从 "success" 改为 "solved"

**Code Review WARN：** VALID_OUTCOME_TYPES 在 4 处重复定义，后续可提取为共享常量。

**Tests:** 15 new + 543/543 全绿

### 13.7 Session 13c — Issue #24: Tantivy filter 转义

**Bug:** `_search_sync` 只转义 `"`，Tantivy query parser 的其他特殊字符（`+ - && || ! ( ) { } [ ] ^ ~ * ? : \ /`）未转义，导致含特殊字符的 filter value（如 domain="c++"）查询失败或返回错误结果。

**修复：** 新增 `_escape_tantivy_value()` 函数，对所有 Tantivy 特殊字符加反斜杠转义并用双引号包裹。

**Tests:** 11 new，覆盖 9 类特殊字符 + 2 个负面测试。554/554 全绿。

### 13.8 Session 13d — Issue #25: 嵌套 environment FTS 文本

**Bug:** `local_pipeline.py` 用 `str(v)` 将嵌套 environment dict 转为文本，产生 Python repr（`{'os': 'linux'}`），BM25 无法搜索内部值。

**修复：** 新增 `_flatten_env_to_text()` 递归展平函数。处理嵌套 dict、list（含嵌套 dict）、None 跳过。

**Code Review 发现：** Phase 2 contribute route 同样有此 bug（`agxp/api/routes/contribute.py:143`），记为后续 issue。

**Tests:** 10 new，含 2 个真实 Tantivy round-trip 集成测试。564/564 全绿。

### 13.9 Phase 1 Bug Fix Summary

| Bug | Issue | 修复方案 | Tests |
|-----|-------|---------|-------|
| B1: hnswlib 忽略 filters | #22 | over-fetch + post-filter via metadata_fn | 22 new |
| B4: outcome_type 无校验 | #23 | CLI + SqliteStore 两层白名单校验 | 15 new |
| B5: Tantivy filter 转义不完整 | #24 | _escape_tantivy_value 全特殊字符转义 | 11 new |
| B6: 嵌套 environment FTS | #25 | _flatten_env_to_text 递归展平 | 10 new |

**全量测试：564/564 通过（+58 新测试）**

---

## Session 14 — Issue #15: Server 启动校验

**Date:** 2026-04-05

### 14.1 Problem

Phase 2 FastAPI 服务无启动校验。依赖服务不可用时，只在第一次请求时报错，错误信息不清晰（如 `KeyError: 'DATABASE_URL'`）。

### 14.2 Design

- 新增 `agxp/api/startup.py` — 四个校验函数：
  - `check_env_vars()` — DATABASE_URL 必须设置
  - `check_database(dsn)` — SELECT 1 验证 PostgreSQL 可达
  - `check_pgvector(dsn)` — 验证 pgvector extension 已安装
  - `check_redis(url)` — Redis ping，不可用时**警告**不 fatal
- 修改 `agxp/api/app.py` — FastAPI lifespan（startup 校验 + shutdown 清理）
- 修改 `agxp/db/pool.py` — DATABASE_URL 缺失时给明确 RuntimeError

### 14.3 Infrastructure Setup

本 session 在腾讯云服务器上安装了 Phase 2 基础设施：
- PostgreSQL 16（端口 5433）+ pgvector + uuid-ossp
- Redis 7.0（端口 6379）
- `agxp[server]` Python 依赖
- Alembic migration 已跑
- Phase 2 集成测试 50/50 通过

### 14.4 Code Review Findings

- `check_pgvector` 的 `asyncpg.connect()` 未包裹 try/except → 已修
- caplog 测试不稳定 → 改为 mock logger 直接断言

### 14.5 Files Changed

| File | Change |
|------|--------|
| `agxp/api/startup.py` | New — 4 个启动校验函数 |
| `agxp/api/app.py` | Added lifespan（startup + shutdown） |
| `agxp/db/pool.py` | DATABASE_URL 缺失 → 明确 RuntimeError |
| `tests/unit/test_api/test_startup_checks.py` | 9 new unit tests |
| `tests/integration/test_api/test_startup_integration.py` | 5 new integration tests |

### 14.6 Test Suite

```
578 passed in 57s
```

---

## Session 15 — Issue #16: 查询降级策略

**Date:** 2026-04-05

### 15.1 Problem

搜索后端部分失败（embed 异常、vector 空结果、FTS 不可用）时，pipeline 直接崩溃或静默返回差结果，用户无感知。

### 15.2 Design

**返回类型变更：** `run()` / `query()` 从 `list[dict]` 改为 `dict{"results": [...], "warnings": [...]}`

**降级逻辑：**
- Embed 失败 → 跳过 vector search，只用 BM25 + warning
- Vector 失败 → 只用 BM25 + warning
- FTS 失败 → 只用 vector + warning
- Vector 返回空（无 embeddings）→ BM25 only + warning
- 全部失败 → 空结果 + warning

**影响范围：** QueryPipeline.run(), LocalPipeline.query(), query_endpoint NDJSON, CLI query, + 所有现有测试中的 callers。

### 15.3 Files Changed

| File | Change |
|------|--------|
| `agxp/search/query_pipeline.py` | run() 降级 + 新返回类型 |
| `agxp/search/local_pipeline.py` | query() 同样模式 |
| `agxp/api/routes/query.py` | 提取 results/warnings，NDJSON meta 含 warnings |
| `agxp/cli/commands/query.py` | 提取 results，warnings 输出到 stderr |
| 8 个现有测试文件 | 更新 pipeline 返回值消费方式 |
| 3 个新测试文件 | 15 new degradation tests |

### 15.4 Test Suite

```
593 passed in 70s
```

---

## Session 16 — Issue #17: 统一启动脚本 + .env

**Date:** 2026-04-05

### 16.1 Changes

- `.env.example` — 文档化 DATABASE_URL / REDIS_URL
- `scripts/dev.sh` — 一键启动：加载 .env → 检查 PG/Redis → alembic migrate → Celery worker → uvicorn。支持 `--check-only`。
- `Makefile` — `dev` / `dev-check` targets
- `agxp/api/app.py` — lifespan 可选加载 dotenv（try/except ImportError）

### 16.2 Code Review Findings

- dev.sh 端口解析 sed 在 URL 无显式端口时产生垃圾 → 加 regex guard
- `except ImportError: pass` → 改为 `logger.debug`

### 16.3 Test Suite

```
611 passed in 70s (+18 new)
```

### 16.4 Next Steps

1. Phase 2 Server 集成测试 (#18)
2. 搜索质量评估框架 (#20)
3. 评估 EmbeddingGemma-300M (#19)

---

## Session 17 — Issue #19: User Onboarding (Anonymous Session + Registration + Login)

**Date:** 2026-04-05
**Branch:** `feat/issue-19-user-onboarding`

### 17.1 Context

Issue #10 (Auth) implemented token **verification** but never token **creation**. No endpoint existed to create anonymous sessions or register users, making the auth system incomplete — tokens could be validated but never issued.

Discovered during #18 integration test design review: the test design doc had no user registration flow coverage because the functionality didn't exist.

### 17.2 Design Decisions

**Three new endpoints:**
- `POST /api/v1/auth/anonymous` → 201, create anonymous session with 20 credits, 30-day expiry
- `POST /api/v1/auth/register` → 201, create user with 50 credits + optional anon session merge
- `POST /api/v1/auth/login` → 200, authenticate and issue new API key

**Key decisions:**
- **password_hash on users table (nullable)** — supports email+password now, nullable for future OAuth users
- **bcrypt via `run_in_executor`** — consistent with dependency.py, non-blocking
- **Login creates new api_key each time** — old keys not auto-revoked, `revoked_at` exists for cleanup
- **Merge in single transaction** — credit transfer + merged_into_user_id + query_logs migration, atomic
- **TOCTOU-safe email uniqueness** — catch `asyncpg.UniqueViolationError` inside transaction, not pre-check SELECT (code review finding)
- **Password min_length=8 in Pydantic** — single validation layer, consistent 422 for all validation errors (code review finding)
- **Custom HTTPException handler** — returns `{"error": "...", "message": "..."}` flat, not nested in `{"detail": {...}}`

### 17.3 Files Changed

| File | Action | Description |
|------|--------|-------------|
| `agxp/api/routes/auth.py` | Created | 3 endpoints + module-level DB helpers |
| `agxp/api/app.py` | Modified | Auth router + HTTPException handler |
| `agxp/db/models.py` | Modified | `User.password_hash` column |
| `agxp/db/migrations/versions/66157bb62596_add_password_hash_to_users.py` | Created | Alembic migration |
| `tests/unit/test_auth/test_auth_routes.py` | Created | 30 unit tests |
| `tests/integration/test_auth/test_auth_integration.py` | Created | 14 integration tests |

### 17.4 Code Review Findings (fixed)

1. **TOCTOU race** — email SELECT outside transaction → concurrent register could 500. Fixed: catch UniqueViolationError inside transaction.
2. **Password validation gap** — Pydantic min_length=1 vs business logic min 8 → inconsistent error codes. Fixed: Pydantic min_length=8.

### 17.5 Test Suite

```
44 new tests (30 unit + 14 integration), all passing
655 total collected, 613 passed (42 pre-existing port 5432 vs 5433 failures, unrelated)
```

### 17.6 Next Steps

1. Resume #18 (Phase 2 integration tests) — now has real auth endpoints to test against
2. Fix pre-existing integration test port mismatch (5432 → 5433)

---

## Session 18 — Issue #18: Phase 2 Server E2E Integration Tests

**Date:** 2026-04-05
**Branch:** `feat/issue-19-user-onboarding`

### 18.1 Context

Phase 2 had 50+ component-level integration tests but no end-to-end tests covering the full API flow: HTTP request → auth → DB → search → response. Post-mortem from Session 12 showed that 426 unit tests passed but real deployment had 6 critical issues — all because component tests don't catch integration failures.

#19 (user onboarding) was completed first to provide real auth endpoints for the test fixtures.

### 18.2 Design Decisions

- **Auth via real endpoints** — test fixtures call `POST /auth/register` and `POST /auth/anonymous` to get tokens, not manual DB seeding. Tests the real auth path.
- **Heavy backends mocked** — BgeM3 (~2GB) → FakeEmbeddingBackend, MiniLM → FakeCrossEncoder, PgvectorBackend → FakeVectorBackend, TantivyBackend → FakeFTSBackend. Avoids loading ML models in CI.
- **Real DB + real auth** — PostgreSQL, asyncpg pool, auth dependency all real.
- **Celery embed tests simplified** — originally called `_embed_experience_async` directly, but event loop mismatch (TestClient vs pytest-asyncio) caused failures. Changed to verify dispatch_embed is called + DB pre-embed state.
- **Cleanup FK order** — code review caught missing `quality_votes` and `search_feedback` deletes before `experiences`.
- **DB password aligned** — test_auth had `agxp_dev`, test_api had `agxp`. Aligned both to `agxp`.

### 18.3 Files

| File | Action | Description |
|------|--------|-------------|
| `tests/integration/test_api/conftest.py` | Created | Shared fixtures: pool, test_user/anon helpers, mock backends, cleanup |
| `tests/integration/test_api/test_server_e2e.py` | Created | 22 E2E tests across 7 categories |
| `tests/integration/test_auth/test_auth_integration.py` | Modified | Fixed DB password default |

### 18.4 Test Coverage (22 tests)

| Category | Count | Key scenarios |
|----------|-------|---------------|
| User Registration Flow | 3 | register→contribute, anon→merge, login→query |
| Contribute API | 4 | DB row, estimated_credits, FTS index, validation |
| Query API | 5 | NDJSON format, meta/results/done, warnings, fields, empty |
| Contribute→Query Loop | 2 | Round-trip, domain filter |
| Auth Integration | 5 | Valid token, no bearer 401, invalid 401, revoked 401, anon 403 |
| Celery Embed Task | 2 | dispatch called, pre-embed DB state |
| Degradation Warning | 1 | vector empty → warnings in response |

### 18.5 Test Suite

```
36 new integration tests (22 E2E + 14 auth from #19), all passing
```

### 18.6 Lessons

1. **Event loop mismatch** — TestClient runs its own asyncio loop. Directly awaiting internal async functions from pytest-asyncio tests fails. Solution: test through HTTP or verify state, don't call internal async functions.
2. **Cleanup FK order matters** — must delete from child tables before parent. Code review caught `quality_votes` and `search_feedback` missing.
3. **Real auth > manual seed** — using registration endpoints in fixtures tests the actual onboarding path and eliminates seed/schema drift.

### 18.7 Next Steps

1. Fix pre-existing integration test port mismatch (5432 → 5433) in test_db, test_credit, test_quality, test_vector
2. 搜索质量评估框架 (#20)
3. 评估 EmbeddingGemma-300M

---

## Session 19 — Issue #2: SqliteStore + FTS5 (Phase 1 Local Storage)

**Date:** 2026-04-06
**Branch:** `feat/issue-2-local-storage`

### 19.1 Context

Phase 1 本地知识库的基础存储层。重大架构变更：从原方案（SQLite + Tantivy + hnswlib + all-MiniLM-L6-v2, ~1.4GB）改为极简方案（SQLite + FTS5, ~5MB）。Agent 自身的 LLM 处理语义理解，不需要 embedding 模型。

### 19.2 Design Decisions

- **SQLite FTS5 内置 BM25** — 无需 Tantivy 外部依赖
- **OR 连接搜索词** — FTS5 MATCH 用 OR 而非 AND，确保部分匹配也返回结果（BM25 自然排序高匹配的在前）
- **FTS5 元字符剥离** — `"*^()` 从 token 中移除后再引号包裹（code review finding）
- **三个 trigger** — INSERT + DELETE + UPDATE 保持 FTS5 索引同步（code review finding: 原始设计缺 UPDATE trigger）
- **JSON round-trip** — environment (dict) 和 tags (list) 用 json.dumps/loads
- **WAL mode** — 支持并发读写
- **Filter 白名单** — 只允许 domain 和 task_type，防 SQL 注入

### 19.3 Files

| File | Action | Description |
|------|--------|-------------|
| `agxp/local/__init__.py` | Created | Package marker |
| `agxp/local/store.py` | Created | SqliteStore 类 — CRUD + FTS5 BM25 搜索 |
| `tests/unit/test_local/test_sqlite_store.py` | Created | 36 单元测试 |
| `tests/integration/test_local/test_sqlite_store_integration.py` | Created | 20 集成测试 |

### 19.4 Code Review Findings (fixed)

1. **FTS5 双引号转义** — 输入含 `"` 时 FTS5 语法错误。Fix: 剥离元字符后再包裹。
2. **缺少 AFTER UPDATE trigger** — FTS5 content-sync 不完整。Fix: 添加 UPDATE trigger（delete old + insert new）。

### 19.5 Test Suite

```
56 new tests (36 unit + 20 integration), all passing in 2.68s
```

### 19.6 Workflow Improvements (this session)

- 新增 **Step 4: Test Quality Checker** — `/test-quality-check` skill（universal rubric + 项目扩展）
- design-check 循环上限 10 次
- 人工审核步骤必须生成飞书文档
- Phase 1 架构重设计文档：`docs/LOCAL_SEARCH_DESIGN.md`

### 19.7 Next Steps

1. #3: FTS5 BM25 搜索增强（字段加权、高级查询）
2. #7: CLI（agxp init / contribute / query / status）

---

## Session 20 — Issue #7: CLI Refactoring (Phase 1)

**Date:** 2026-04-06
**Branch:** `feat/issue-2-local-storage`

### 20.1 Context

CLI 命令从旧方案（LocalConfig + LocalPipeline + Tantivy + hnswlib + async）改为直接使用 SqliteStore。全同步，零 ML 依赖。

### 20.2 Changes

- `init` — 用 SqliteStore 创建 DB + FTS5，替代 LocalConfig
- `contribute` — 直接调 SqliteStore.contribute()，NDJSON 输出，去掉 asyncio.run()
- `query` — SqliteStore.query()，NDJSON 输出（一行一个结果），id→experience_id 重命名
- `status` — 去掉 Tantivy/HNSW 检查，改为检查 agxp.local.store 模块
- `main.py` — 更新 docstring

### 20.3 Code Review (APPROVED)

- WARN: store.close() 未在 try/finally — 已修复
- WARN: r.pop("id") 修改原始 dict — 低风险，CLI 单次消费

### 20.4 Tests

```
29 tests (25 unit + 4 integration), all passing in 1.78s
```

### 20.5 Next Steps

1. MCP Server (#14)
2. 冷启动种子内容 (#15)

---

## Session 21 — Issue #14: MCP Server + Issue #21: Phase 1 E2E Tests

**Date:** 2026-04-06
**Branch:** `feat/issue-2-local-storage`

### 21.1 Issue #21 — Phase 1 E2E Integration Tests

22 个 E2E 测试覆盖完整生命周期（status→init→contribute→query）、搜索质量（50 条 BM25 排序）、边界（Unicode/长文本/FTS5 特殊字符）、数据隔离、降级、error contract。

**发现：** FTS5 `unicode61` tokenizer 不分词 CJK 字符。中文经验需要包含英文关键词才能被 FTS5 搜到。已在测试中记录为已知限制。

### 21.2 Issue #14 — MCP Server

用 FastMCP 实现 2 个 MCP tool：search_experiences + contribute_experience。stdio transport，兼容 Claude Code / Cursor / VS Code。

**Key decisions:**
- 每次 tool 调用创建新 SqliteStore 实例（简单但有开销，future optimization）
- Tool description 是触发机制的核心——告诉 Claude "call when stuck, not at task start"
- `set_data_dir()` 模块级函数供 CLI 和测试设置 data dir
- Missing DB → clear FileNotFoundError 带 "Run: agxp init" 提示

### 21.3 Files

| File | Action |
|------|--------|
| `agxp/mcp/__init__.py` | Created |
| `agxp/mcp/server.py` | Created — FastMCP + 2 tools |
| `agxp/cli/commands/mcp_cmd.py` | Created — `agxp mcp` command |
| `agxp/cli/main.py` | Modified — registered mcp command |
| `tests/integration/test_local_e2e.py` | Created — 22 E2E tests |
| `tests/unit/test_mcp/test_mcp_tools.py` | Created — 16 unit tests |
| `tests/integration/test_mcp/test_mcp_integration.py` | Created — 8 integration tests |

### 21.4 Tests

```
#21: 22 E2E tests, all passing
#14: 24 MCP tests (16 unit + 8 integration), 24 passing + 1 skipped
```

### 21.5 Workflow Improvements

- Test Quality Checker (`/test-quality-check` skill) 首次在 #2、#7、#21、#14 中使用
- Quality Checker 在 #21 中发现缺 error contract 测试，打回 tester 补充（循环机制生效）
- 新 issue #22: Smart init（自动检测 Agent 环境 + 配置 MCP）
- 新 issue #23: Local quality scoring + feedback

### 21.6 Next Steps

1. #22: Smart init（auto-detect agents, configure MCP）
2. #23: Quality scoring + feedback
3. 手动验收测试：Claude Code 中实际使用 AGXP MCP

---

## Session 22 — Issue #25: Auto-feedback (search_log + pending feedback)

**Date:** 2026-04-06
**Branch:** feat/issue-2-local-storage

---

### 22.1 Background & Motivation

MCP 集成测试（Session 21 Mac 验收）发现：Claude 搜到经验后直接用结果，不会主动调 report_feedback。即使改 tool description 引导打分，"没尝试就打分"会污染质量分数。

**解决方案：** 不在搜索后立刻催促打分，而是在 *下次搜索时* 提醒 Agent 评价上次的经验。此时 Agent 已在对话 context 里尝试过方案，有资格判断是否有用。

### 22.2 Session Flow

1. **文档全面审核** — 发现 HARNESS.md、ARCHITECTURE.md、AGENT_CONTEXT.md、CLAUDE.md 严重过时（Phase 1 完成但文档还写 "Not started"）。先更新全部 4 个文档。
2. **设计审查** — 审查上次会话的 #25 设计，提出 2 个改进：
   - 去掉 search_log 的 `situation_summary` 列（冗余，JOIN experiences 拿 situation）
   - `get_pending_feedback()` JOIN experiences 排除已删除的经验
3. **Tester sub-agent** — 基于更新后的文档重跑 /tester（上次会话的测试来源不可确认）
4. **Quality Checker** — PASS，2 个非阻塞 notes
5. **实现** — 4 个文件改动，173/174 tests passing（1 skipped pre-existing）
6. **Code Review** — PASS，0 blocking，2 warn，2 suggest

### 22.3 Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| query() 返回 dict 而非 list | Breaking change 一步到位，避免后续再改 |
| search_log 无 situation_summary | JOIN experiences 拿 situation 更简洁，自动排除已删除的经验 |
| 每次 query 自动 cleanup | 单用户场景不需要 cron，search_log 不会很大 |
| pending_feedback 为空时返回 None | 区分"无 pending"和"空列表"，减少 Agent context 噪音 |
| hint 文案强调"只评价实际尝试过的" | 防止 Agent 盲目打分污染质量分数 |

### 22.4 Files Changed

| File | Change |
|------|--------|
| `agxp/local/store.py` | +search_log 表, +log_search_results, +get_pending_feedback (JOIN), +mark_feedback_given, +cleanup_expired_search_log, query() → dict |
| `agxp/mcp/server.py` | search_experiences → dict, report_feedback += mark_feedback_given |
| `agxp/cli/commands/query.py` | pending hint → stderr, results from dict |
| `agxp/cli/commands/feedback_cmd.py` | += mark_feedback_given |
| 7 test files | ~46 处 query 返回类型适配 + 14 新测试 |
| 4 doc files | CLAUDE.md, AGENT_CONTEXT.md, HARNESS.md, ARCHITECTURE.md 全面更新 |

### 22.5 Code Review Findings

- **WARN:** 每次 MCP 调用创建新 SQLite 连接（单用户可接受）
- **WARN:** feedback_cmd.py module-level import（非 lazy）
- **SUGGEST:** search_log 可加索引 (experience_id, feedback_given)
- **SUGGEST:** log_search_results 可用 executemany

### 22.6 Lessons

1. **文档先行**：文档过时导致 tester 和 reviewer 基于错误假设工作。本次先全面更新文档再写测试/实现。
2. **设计审查发现实际 bug**：`situation_summary` 冗余 + 已删除经验泄漏到 pending。审查阶段发现比实现后修复成本低得多。
3. **跨会话连续性**：/tmp 文件 + memory 系统有效恢复了上次会话的设计产出，避免重做。

---

## Session 23 — Issue #26+#27: Server feedback + Local→remote fallback

**Date:** 2026-04-07
**Branch:** feat/issue-2-local-storage

---

### 23.1 Background

#26（服务端 feedback）和 #27（本地→远程 fallback）合并为一个 issue。关键设计决策：
- 服务端不加 search_log（客户端统一追踪）
- Server URL 硬编码（全球共享一个 server）
- 防刷分：每条经验每天全局只接受一条 feedback（不限用户）
- search_log 加 source 列（local/remote）和 situation_snapshot 列（remote 用）

### 23.2 Implementation

**Part A — 服务端 POST /v1/feedback：**
- `agxp/api/routes/feedback.py`（新建）：验证 experience 存在 → 速率限制 → 更新 quality_score → 记录 search_feedback → 奖积分（失败只 log warning）
- `agxp/api/app.py`：注册 feedback router

**Part B — 客户端 fallback：**
- `agxp/local/store.py`：search_log 加 source + situation_snapshot 列；get_pending_feedback 用 UNION (local JOIN + remote snapshot)；新增 get_experience_source()；log_search_results 支持 source 和 situation_snapshot 参数
- `agxp/mcp/server.py`：search_experiences 空 → fallback 远程（urllib, NDJSON 解析）；report_feedback 按 source 路由（local/remote）；token 自动创建 + 缓存 config.json

### 23.3 Test Results

111/111 passing（25 new + 86 existing）

### 23.4 Code Review Findings

- **WARN:** update_quality_score 的 SELECT+UPDATE 有 TOCTOU race（速率限制 mitigate）
- **WARN:** 第二个 store 连接可优化（复用第一个）
- **修复：** token reuse 测试的 config key 从 "remote_token" 改为 "anonymous_token"
- **修复：** credit failure 测试补充 `credits_earned == 0` 断言

### 23.5 文档

本 session 之前完成了 5 份设计文档体系（PRD、数据结构、技术架构、API 接口、运维测试）+ 跨文档一致性审计（8 critical 全修）。
