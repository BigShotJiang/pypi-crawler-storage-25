# AGXP — Project-Specific Test Quality Rubric Extensions
> This file extends the universal rubric in `/test-quality-check` skill.
> The skill reads this file automatically if it exists in the project root.
---
## Architecture-Specific Rules
### Server Integration Tests
- **Real PostgreSQL required** — `localhost:5433`, database `agxp`
- **Real Redis required** — `localhost:6379`
- **Heavy ML backends may be mocked:**
  - `EMBED_BACKEND` → `FakeEmbeddingBackend` (OK — avoids loading BgeM3 ~2GB)
  - `MiniLMCrossEncoder` → `FakeCrossEncoder` (OK — avoids loading MiniLM)
  - `dispatch_embed` → no-op (OK — avoids Celery broker)
- **Auth tokens must come from real endpoints** — use `POST /api/v1/auth/register` or `/auth/anonymous`, NOT manual DB inserts
- **API tests must validate response format matches OpenAPI spec**
### Client Unit Tests (CLI / MCP)
- **All API calls must be mocked** — no real network requests in unit tests
- **Both output formats must be tested** — JSON and human-readable modes
- **Parameter validation must be tested** — invalid inputs should return proper errors before API calls are made
- **Exit codes must be tested** — all error scenarios return non-zero exit codes
---
## AGXP-Specific Auto-Rejection
In addition to the universal auto-rejection criteria:
1. Integration test that manually seeds `api_keys` or `users` table instead of using auth endpoints
2. FTS5 search test that doesn't verify BM25 ranking (just checks "result exists")
3. Vector search test that doesn't verify semantic relevance ranking
4. Client test that makes real network requests instead of mocking API calls
5. CLI test that doesn't test both JSON and human-readable output modes
---
## Cleanup Rules
- **Server tests**: delete test data using `test-e2e-` or `test-integ-` identifier prefix
- **FK dependency order for cleanup**: `search_feedback` → `quality_votes` → `experiences` → `api_keys` → `credit_accounts` → `users` → `anonymous_sessions`
- **No local .db files to cleanup** — all tests use remote database
