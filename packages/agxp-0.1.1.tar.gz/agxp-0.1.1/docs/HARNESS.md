# AGXP — Harness Design

> 系统骨架：所有组件的连接方式、依赖关系、测试策略，以及每个 Issue 在整体中的位置。
> 随开发进展持续更新。最后更新：Issue #25 设计审核 (2026-04-06)。
>
> **注意：** 系统组件地图展示了 Local 和 Server 两种模式。Local (`[local]`, ~5MB) 使用 SQLite + FTS5（内置 BM25），Agent 自身的 LLM 处理语义理解。Server (`[server]`, ~200MB) 使用 PostgreSQL + pgvector + Tantivy + Redis + Celery。详见 `docs/LOCAL_SEARCH_DESIGN.md`。

---

## 0. 设计硬性规则：字段完整性检查

> 每个 Issue 的设计阶段必须产出一张**字段映射表**，覆盖数据模型中所有字段（必填 + 可选）在每一层的流转情况。使用 `/design-check` skill 自动验证。

**层级定义：**

| 层 | 说明 |
|----|------|
| Input | CLI 参数 / API request body |
| Storage | SQLite (Phase 1) / PostgreSQL (Phase 2) |
| FTS Index | FTS5 (Phase 1) / Tantivy (Phase 2) BM25 索引 |
| Vector Index | N/A (Phase 1) / 嵌入向量 (Phase 2) |
| Query Return | pipeline.query() 返回的 dict |
| Output | CLI 输出 / API response body |

**规则：**
1. 每个字段必须在每一层标注 ✓（包含）、✗（不包含，设计决定）或 N/A
2. 标注 ✗ 的字段必须注明原因（如"不适合索引"、"隐私字段不返回"）
3. **禁止出现未标注（???）的字段** — 这是设计缺陷，不是实现缺陷
4. JSON/dict 字段（如 environment）必须说明内部结构和文本化方式

**教训（2026-04-03）：** LocalPipeline.query() 遗漏了 failed_approaches、environment、subdomain 三个可选字段的返回，因为设计阶段没有画字段映射表。

---

## 1. 系统组件地图

```
┌─────────────────────────────────────────────────────────────┐
│  ENTRY POINTS                                                │
│                                                              │
│   agxp query / contribute / feedback / status  ← CLI (Typer)│
│   agxp mcp                           ← MCP stdio server     │
│   POST /v1/query  POST /v1/contribute ← FastAPI (Phase 2)   │
└──────────────────────────┬──────────────────────────────────┘
                           │
              ┌────────────┴────────────┐
              │                         │
         LOCAL MODE                SERVER MODE
     (agxp[local], ~5MB)      (agxp[server], ~200MB)
              │                         │
     ┌────────┴────────┐    ┌──────────┴──────────┐
     │  SqliteStore     │    │  SEARCH PIPELINE    │
     │  + FTS5 (BM25)  │    │  embed→BM25→vector  │
     │  + search_log   │    │  →RRF→rerank→blend  │
     └─────────────────┘    └──────────┬──────────┘
                                       │
                            ┌──────────┴──────────┐
                            │  PostgreSQL+pgvector │
                            │  Tantivy BM25        │
                            │  Redis+Celery        │
                            └─────────────────────┘
```

---

## 2. 依赖注入：config/backends.py

所有可替换的 backend 在唯一一个地方配置。业务逻辑代码只依赖 ABC，不依赖具体实现。

```python
# agxp/config/backends.py  (当前状态)

EMBED_BACKEND:  EmbeddingBackend      = BgeM3LocalBackend()   # ✅ 工作
VECTOR_BACKEND: VectorSearchBackend   = PgvectorBackend()     # ⚠️ stub
FTS_BACKEND:    FullTextSearchBackend = TantivyBackend()      # ⚠️ stub
CREDIT_WRITER:  CreditWriter          = PostgresCreditWriter() # ⚠️ stub
QUALITY_WRITER: QualityScoreWriter    = InlineQualityWriter() # ⚠️ stub
```

**规则：** 换 backend 只改这一个文件。测试中通过构造函数参数传入 Fake 实现，不修改这个文件。

---

## 3. 数据流

### 3.1 Query 流（Issue #4–8 完成后）

```
CLI: agxp query "how to fix asyncio deadlock" --domain coding
  │
  ▼ HTTP POST /v1/query
  │   body: {query, domain, task_type, language, tried, filters}
  │
  ▼ QueryService.handle()
  │   ├─ auth: validate API key → resolve user_id
  │   ├─ credit check: balance ≥ 1 ?
  │   ├─ L1 cache miss → L2 Redis miss → L3 mat.view miss
  │   └─ full pipeline:
  │       ├─ EMBED_BACKEND.embed([query_text])         → query_vec[1024]
  │       ├─ parallel:
  │       │   ├─ FTS_BACKEND.search(query_text, ...)   → [(id, bm25), ...]
  │       │   └─ VECTOR_BACKEND.search(field, vec, ...) → [(id, cos), ...]
  │       ├─ RRF fusion → top-150
  │       ├─ cross-encoder rerank → top-20
  │       └─ quality blend → final ranking
  │   ├─ CREDIT_WRITER.debit(user_id, 1, "spend_query", ...)
  │   └─ log to query_logs table
  │
  ▼ NDJSON stream to CLI
      {"type":"meta", "credits_spent":1, "latency_ms":68, ...}
      {"type":"result", "rank":1, "score":0.92, "experience":{...}}
      {"type":"done"}
```

### 3.2 Contribution 流（Issue #5–9 完成后）

```
CLI: agxp contribute --domain coding --task-type debugging ...
  │
  ▼ HTTP POST /v1/contribute
  │   body: {situation, solution, failed_approaches, outcome_type,
  │          lessons, environment, tags, language}
  │
  ▼ ContributionService.handle()
  │   ├─ auth: validate API key → resolve user_id
  │   ├─ validate fields (min/max lengths, required fields)
  │   ├─ near-duplicate check: cosine(new_embed, top-5) > 0.92 → reject
  │   ├─ INSERT INTO experiences (is_published=false)
  │   └─ enqueue Celery chain:
  │       embed_experience.si(exp_id)
  │       | index_bm25.si(exp_id)
  │       | score_quality.si(exp_id)
  │       | award_credits.si(exp_id, user_id)
  │
  ▼ HTTP 202 Accepted
      {"experience_id": "...", "estimated_credits": 25, "status": "processing"}

  ── async ──────────────────────────────────────────────────────────
  Worker 1: embed_experience(exp_id)               ← ✅ Issue #3 done
    └─ EMBED_BACKEND.embed([sit, sol, les, ...])
    └─ UPDATE experiences SET embedding_* = ...

  Worker 2: index_bm25(exp_id)                     ← 🔲 Issue #5
    └─ FTS_BACKEND.index(exp_id, {situation, solution, lessons})

  Worker 3: score_quality(exp_id)                  ← 🔲 Issue #7
    └─ compute uniqueness + completeness
    └─ QUALITY_WRITER.recompute_score(exp_id)
    └─ UPDATE experiences SET is_published=true WHERE score >= threshold

  Worker 4: award_credits(exp_id, user_id)         ← 🔲 Issue #6
    └─ CREDIT_WRITER.credit(user_id, credits, "earn_contribution", ...)
```

### 3.3 Credit 流（Issue #6 完成后）

```
每次 query:
  PostgresCreditWriter.debit(user_id, 1, "spend_query", idem_key)
    └─ BEGIN
    └─ SELECT balance FROM credit_accounts WHERE user_id=? FOR UPDATE
    └─ IF balance < 1: RAISE InsufficientCreditsError
    └─ UPDATE credit_accounts SET balance = balance - 1
    └─ INSERT INTO credit_transactions (amount=-1, balance_after=...)
    └─ COMMIT

每次 contribution 被采用:
  PostgresCreditWriter.credit(user_id, N, "earn_contribution", exp_id, idem_key)
    └─ INSERT + UPDATE，无需锁（只加不减）

余额查询:
  先查 L1 TTLCache(30s) → L2 Redis(60s) → DB
```

---

## 4. 测试 Harness

### 4.1 三层测试金字塔

```
                    ┌─────────────────┐
                    │   e2e / perf    │  ✅ Phase 1 E2E + Phase 2 E2E
                    │                 │  全链路验证
                    └────────┬────────┘
               ┌─────────────┴──────────────┐
               │     integration tests       │  156 个 ✅
               │  (real DB / real SQLite)    │  14 test files
               └─────────────┬──────────────┘
          ┌───────────────────┴───────────────────┐
          │           unit tests                   │  593 个 ✅
          │  (pure logic, no I/O, Fakes/stubs)     │  50+ test files
          └────────────────────────────────────────┘

Total: 749 tests passing

Phase 1 Local subtotal: ~196 tests
  unit/test_local/:  85 (sqlite_store 36, scoring 23, search_log 8, agent_detect 18)
  unit/test_mcp/:    24 (mcp_tools 19, mcp_feedback 5)
  unit/test_cli/:    31 (cli_commands 27, cli_feedback 4)
  integration/test_local/:     20 (sqlite_store_integration)
  integration/test_mcp/:        9
  integration/test_cli/:        4
  integration/test_local_e2e:  23
```

### 4.2 Fixture 体系（现状 + 规划）

```
tests/
├── conftest.py                    ← 全局 markers (unit/integration/performance)
│
├── unit/
│   └── (no shared fixtures)      ← 每个测试文件自包含，用 FakeEmbeddingBackend
│
└── integration/
    ├── test_db/
    │   └── conftest.py           ← DB fixtures (已建)
    │       ├── engine             scope=session  asyncpg NullPool
    │       ├── _shared_session    scope=session  单一 AsyncSession
    │       └── session (autouse) loop_scope=session  每测试前 rollback
    │
    └── test_embed/
        └── (无 conftest)         ← backend fixture 在测试文件内 scope=module
```

**规划中的 fixtures（Issue #4+ 需要建立）：**

```python
# tests/integration/conftest.py  (待建)

@pytest_asyncio.fixture(scope="session")
async def db_pool():
    """asyncpg 连接池，供所有集成测试共用"""
    pool = await asyncpg.create_pool(TEST_DATABASE_URL, min_size=2, max_size=5)
    yield pool
    await pool.close()

@pytest.fixture(scope="session")
def fake_embed_backend():
    """FakeEmbeddingBackend 单例，所有不需要真实模型的集成测试用"""
    return FakeEmbeddingBackend()

@pytest.fixture(scope="module")
def real_embed_backend():
    """BgeM3LocalBackend，仅 embedding 相关集成测试用（已缓存，12s）"""
    return BgeM3LocalBackend()

# tests/unit/conftest.py  (待建)
@pytest.fixture
def fake_embed():
    return FakeEmbeddingBackend()

@pytest.fixture
def fake_fts():
    return FakeFTSBackend()       # 待 Issue #5 建立

@pytest.fixture
def fake_vector():
    return FakeVectorBackend()    # 待 Issue #4 建立

@pytest.fixture
def fake_credit():
    return FakeCreditWriter()     # 待 Issue #6 建立
```

### 4.3 测试隔离策略

| 层次 | 数据库 | Embedding | FTS | 策略 |
|------|--------|-----------|-----|------|
| unit | 无 | FakeEmbeddingBackend | FakeFTSBackend | 纯内存，毫秒级 |
| integration/db | 真实 PostgreSQL，每测试前 rollback | 无 | 无 | 真实约束验证 |
| integration/embed | 无 | BgeM3LocalBackend（缓存） | 无 | 真实向量验证 |
| integration/search | 真实 PostgreSQL | FakeEmbeddingBackend | 真实 Tantivy | 搜索逻辑验证 |
| e2e | 真实全栈 | BgeM3LocalBackend | 真实 Tantivy | 全链路延迟验证 |

### 4.4 每个 Issue 的测试

| Issue | Phase | Unit | Integration | Status |
|-------|-------|------|-------------|--------|
| #1 (scaffold) | 2 | 60 | 0 | ✅ |
| #2 (DB schema) | 2 | 33 | 12 | ✅ |
| #3 (embedding) | 2 | 19 | 4 | ✅ |
| #4 (vector search) | 2 | 13 | 6 | ✅ |
| #5 (FTS) | 2 | 14 | 8 | ✅ |
| #6 (credits) | 2 | 12 | 8 | ✅ |
| #7-server (quality) | 2 | 8 | 4 | ✅ |
| #8 (query API) | 2 | 15 | 10 | ✅ |
| #9 (contribute API) | 2 | 12 | 8 | ✅ |
| #10 (auth) | 2 | 10 | 6 | ✅ |
| #2-local (SqliteStore) | 1 | 36 | 20 | ✅ |
| #7-local (CLI) | 1 | 31 | 4 | ✅ |
| #14 (MCP) | 1 | 24 | 9 | ✅ |
| #21 (E2E) | 1 | 0 | 23 | ✅ |
| #22 (smart init) | 1 | 18 | 0 | ✅ |
| #23 (scoring) | 1 | 23 | 0 | ✅ |
| #25 (auto-feedback) | 1 | ~13 | ~1 | 🔲 tests written, impl pending |

---

## 5. ABC → 实现 → 测试双映射

每个 ABC 对应两种实现：一个 **Fake**（测试用）、一个 **Real**（生产用）。

```
ABC                      Real Implementation          Fake (test-only)
─────────────────────────────────────────────────────────────────────
EmbeddingBackend    →    BgeM3LocalBackend  ✅    FakeEmbeddingBackend ✅
                         BgeM3ApiBackend    ⚠️stub

VectorSearchBackend →    PgvectorBackend    ✅    FakeVectorBackend    ✅ Issue #4
FullTextSearchBackend→   TantivyBackend     ✅    FakeFTSBackend       ✅ Issue #5
CreditWriter        →    PostgresCreditWriter ✅  FakeCreditWriter     ✅ Issue #6
QualityScoreWriter  →    InlineQualityWriter  ✅  FakeQualityWriter    ✅ Issue #7
```

**测试中的注入方式：**
```python
# 单元测试：直接构造，传入 Fake
embedder = ExperienceEmbedder(FakeEmbeddingBackend())
service  = QueryService(
    vector=FakeVectorBackend(),
    fts=FakeFTSBackend(),
    embed=FakeEmbeddingBackend(),
    credits=FakeCreditWriter(),
)

# 集成测试：真实 backend，真实 DB
service = QueryService(
    vector=PgvectorBackend(pool=db_pool),
    fts=TantivyBackend(),
    embed=FakeEmbeddingBackend(),   # embedding 不是这个测试的关注点
    credits=PostgresCreditWriter(pool=db_pool),
)
```

---

## 6. 关键边界：已完成 vs 待建

### Phase 1 Local — 全部完成

```python
# 完整的本地搜索路径：
from agxp.local.store import SqliteStore
store = SqliteStore("~/.agxp/local.db")
exp_id = store.contribute({"situation": "...", "solution": "...", ...})
results = store.query("asyncio memory leak", filters={"domain": "coding"})
store.close()
```

MCP 路径也已打通：`agxp mcp` → search_experiences / contribute_experience / report_feedback。

### Phase 2 Server — 全部完成

所有 backend（EmbeddingBackend、VectorSearchBackend、FullTextSearchBackend、CreditWriter、QualityScoreWriter）已实现。

```python
# 完整路径：
POST /v1/contribute → ContributionService → Celery chain (embed → index → score → credit)
POST /v1/query → QueryService → embed → BM25+vector → RRF → rerank → blend → response
```

### 待建

```
#25  Auto-feedback: search_log + pending feedback（设计完成，测试已写，实现 pending）
#26  Auto-feedback: server-side（依赖 #25）
#27  Unified MCP: local → community cascade（待设计）
```

---

## 7. Issue 路线图

```
Phase 1: Local-First (COMPLETE — PR #24 merged)
─────────────────────────────────────────────
#2   ✅  SqliteStore + FTS5
#7   ✅  CLI: init/contribute/query/feedback/status/mcp
#14  ✅  MCP Server (search + contribute + feedback tools)
#21  ✅  E2E integration tests (23 tests)
#22  ✅  Smart init: auto-detect agents + configure MCP
#23  ✅  Quality scoring on contribute + feedback mechanism

Phase 1 continued:
#25  🔲  Auto-feedback: search_log + pending feedback on next search
#26  🔲  Auto-feedback: server-side (depends on #25)
#27  🔲  Unified MCP: local → community cascade

Phase 2: Server (COMPLETE)
──────────────────────────
#1-#10  ✅  Full server implementation (scaffold → auth)
#15-#17 ✅  Startup checks, degradation, scripts
#18     ✅  E2E integration tests
#19     ✅  User registration endpoint
```

