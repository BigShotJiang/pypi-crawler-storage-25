# AGXP — 运维、测试与质量保障手册

> 最后更新：2026-04-06
> 覆盖范围：Phase 1（本地模式）+ Phase 2（服务端模式）
> 测试总数：749（593 单元 + 156 集成）

---

# Part 1 — 运维设计

---

## 1. 部署拓扑

### 架构总览

```
┌───────────────────────────────────────────────────────────────────┐
│                     Mac Air（开发 / MCP 客户端）                    │
│                                                                    │
│   Claude Code / Cursor ──→ agxp mcp (stdio) ──→ SqliteStore       │
│                              │                    ~/.agxp/local.db │
│                              │  MCP Protocol                       │
│                              ▼                                     │
│   agxp CLI ──→ SqliteStore + FTS5                                  │
│                 本地模式，零外部依赖                                  │
└────────────────────────────┬──────────────────────────────────────┘
                             │ HTTPS（Phase 2，未来）
                             ▼
┌───────────────────────────────────────────────────────────────────┐
│                腾讯云单节点（2C4G → 4C8G 升级中）                    │
│                                                                    │
│   ┌─────────────┐  ┌──────────────┐  ┌──────────────────┐         │
│   │ FastAPI      │  │ Celery Worker│  │ Celery Beat      │         │
│   │ :8000        │  │ (embed/score)│  │ (定时任务)        │         │
│   └──────┬───────┘  └──────┬───────┘  └──────────────────┘         │
│          │                 │                                        │
│   ┌──────┴─────────────────┴───────────────────────┐               │
│   │                                                │               │
│   │  PostgreSQL 16 + pgvector    Redis 7.2         │               │
│   │  :5433                       :6379             │               │
│   │  数据库 + 向量索引             缓存 + Celery Broker│               │
│   │                                                │               │
│   └────────────────────────────────────────────────┘               │
└───────────────────────────────────────────────────────────────────┘
```

### 文件系统布局

| 路径 | 说明 | 阶段 |
|------|------|------|
| `~/.agxp/` | 本地数据根目录 | Phase 1 |
| `~/.agxp/local.db` | SQLite 数据库（经验 + FTS5 索引） | Phase 1 |
| `~/.agxp/config.json` | 本地配置（MCP 路径、Agent 类型等） | Phase 1 |
| `/home/ubuntu/agentxp/` | 项目源码根目录 | 全部 |
| `/home/ubuntu/agentxp/agxp/` | Python 包 | 全部 |
| `/home/ubuntu/agentxp/agxp/db/migrations/` | Alembic 迁移脚本 | Phase 2 |
| `/home/ubuntu/agentxp/.env` | 环境变量（凭据、连接串） | Phase 2 |

---

## 2. 环境依赖清单

### 运行时依赖

| 组件 | 版本要求 | 用途 | 安装层级 |
|------|----------|------|----------|
| Python | >= 3.11 | 运行时 | Base |
| Typer | >= 0.12.0 | CLI 框架 | Base |
| Pydantic | >= 2.7.0 | 数据校验 | Base |
| pydantic-settings | >= 2.3.0 | 环境变量加载 | Base |
| orjson | >= 3.10.0 | 高性能 JSON 序列化 | Base |
| SQLite3 | 内置 (stdlib) | 本地经验存储 + FTS5 | Base (stdlib) |
| tantivy | >= 0.22.0 | BM25 全文检索 | Server |
| sentence-transformers | >= 3.0.0 | 嵌入模型（可选向量搜索） | Optional future (agxp[embed]) |
| hnswlib | >= 0.8.0 | HNSW 向量搜索（可选） | Optional future (agxp[embed]) |
| FastAPI | >= 0.115.0 | HTTP API 服务 | Server |
| uvicorn | >= 0.30.0 | ASGI 服务器 | Server |
| asyncpg | >= 0.29.0 | PostgreSQL 异步驱动 | Server |
| pgvector | >= 0.3.0 | 向量索引扩展 | Server |
| Redis (hiredis) | >= 5.0.0 | 缓存 + Celery Broker | Server |
| Celery | >= 5.3.0 | 异步任务队列 | Server |
| Alembic | >= 1.13.0 | 数据库迁移 | Server |
| SQLAlchemy | >= 2.0.0 | ORM（仅迁移用） | Server |
| bcrypt | >= 4.1.0 | 密码哈希 | Server |
| prometheus-client | >= 0.20.0 | 监控指标暴露 | Server |
| opentelemetry-api/sdk | >= 1.25.0 | 分布式追踪 | Server |

### 开发依赖

| 组件 | 版本要求 | 用途 |
|------|----------|------|
| pytest | >= 8.2.0 | 测试框架 |
| pytest-asyncio | >= 0.23.0 | 异步测试支持 |
| pytest-benchmark | >= 4.0.0 | 性能基准测试 |
| pytest-mock | >= 3.14.0 | Mock 工具 |
| ruff | >= 0.4.0 | 代码格式化 + Lint |
| mypy | >= 1.10.0 | 类型检查 |
| pre-commit | >= 3.7.0 | Git 钩子 |
| locust | >= 2.28.0 | 负载测试 |

### 基础设施依赖（Phase 2 服务端）

| 组件 | 版本 | 端口 | 部署位置 |
|------|------|------|----------|
| PostgreSQL 16 + pgvector | 16.x | 5433 | 腾讯云单节点 |
| Redis | 7.2.x | 6379 | 腾讯云单节点 |
| Celery Worker | 5.3.x | N/A | 腾讯云单节点 |
| FastAPI + Uvicorn | 0.115.x | 8000 | 腾讯云单节点 |

---

## 3. 凭据管理

### .env 规范

| 变量名 | 示例值 | 必填 | 说明 |
|--------|--------|------|------|
| `DATABASE_URL` | `postgresql+asyncpg://agxp:***@localhost:5433/agxp` | Phase 2 | PostgreSQL 连接串 |
| `REDIS_URL` | `redis://localhost:6379/0` | Phase 2 | Redis 连接串 |
| `CELERY_BROKER_URL` | `redis://localhost:6379/1` | Phase 2 | Celery Broker |
| `CELERY_RESULT_BACKEND` | `redis://localhost:6379/2` | Phase 2 | Celery 结果存储 |
| `SECRET_KEY` | 随机 32 字节 hex | Phase 2 | JWT 签名密钥 |
| `API_KEY_SALT` | 随机 16 字节 hex | Phase 2 | API Key 哈希盐 |
| `AGXP_DATA_DIR` | `~/.agxp` | Phase 1 | 本地数据目录（可选，有默认值） |

### 安全规则

| 规则 | 说明 |
|------|------|
| `.env` 不入版本库 | `.gitignore` 已包含 `.env*`（排除 `.env.example`） |
| 禁止硬编码凭据 | 所有密钥、密码、连接串必须通过环境变量注入 |
| 最小权限原则 | 数据库用户仅授予必要的 CRUD + DDL 权限 |
| 凭据轮换 | SECRET_KEY 和 API_KEY_SALT 每季度轮换一次 |
| 日志脱敏 | 日志中不得打印连接串、密码、API Key 明文 |

---

## 4. 备份与恢复

### Phase 1 本地备份

| 操作 | 命令 | 频率 |
|------|------|------|
| SQLite 热备份 | `sqlite3 ~/.agxp/local.db ".backup /path/to/backup.db"` | 每日 / 手动 |
| 文件复制备份 | `cp ~/.agxp/local.db ~/backups/agxp-$(date +%Y%m%d).db` | 需先确保无写入 |
| WAL checkpoint | `sqlite3 ~/.agxp/local.db "PRAGMA wal_checkpoint(TRUNCATE);"` | 备份前执行 |

### Phase 2 服务端备份

| 操作 | 命令 | 频率 |
|------|------|------|
| PostgreSQL 全量备份 | `pg_dump -h localhost -p 5433 -U agxp -Fc agxp > agxp-$(date +%Y%m%d).dump` | 每日 |
| PostgreSQL 仅数据 | `pg_dump -h localhost -p 5433 -U agxp --data-only -Fc agxp > data.dump` | 按需 |
| Redis RDB 快照 | `redis-cli -p 6379 BGSAVE` | 每日（自动） |
| Google Drive 备份 | `rclone copy /path/to/backup.dump gdrive:agxp-backups/` | 每周 |
| GCP 归档 | 使用 `/cloud-backup` skill | 每月 |

### 恢复 Runbook

**Phase 1 — 本地恢复：**

```bash
# 1. 停止 agxp 进程
# 2. 替换数据库文件
cp /path/to/backup.db ~/.agxp/local.db
# 3. 验证完整性
sqlite3 ~/.agxp/local.db "PRAGMA integrity_check;"
# 4. 重建 FTS5 索引（如果需要）
sqlite3 ~/.agxp/local.db "INSERT INTO experiences_fts(experiences_fts) VALUES('rebuild');"
# 5. 重启服务
```

**Phase 2 — 服务端恢复：**

```bash
# 1. 停止 FastAPI + Celery
systemctl stop agxp-api agxp-worker
# 2. 恢复 PostgreSQL
pg_restore -h localhost -p 5433 -U agxp -d agxp --clean --if-exists agxp-backup.dump
# 3. 运行迁移到最新版本
alembic upgrade head
# 4. 清除 Redis 缓存（防止脏数据）
redis-cli -p 6379 FLUSHDB
# 5. 重启服务
systemctl start agxp-api agxp-worker
# 6. 验证健康检查
curl http://localhost:8000/health
```

---

## 5. 监控指标

| 指标名称 | 类型 | 采集方式 | 目标值 | 说明 |
|----------|------|----------|--------|------|
| `agxp_query_latency_ms` | Histogram | Prometheus | P95 < 200ms | 搜索请求端到端延迟 |
| `agxp_fts5_query_ms` | Histogram | 日志 / 代码埋点 | P95 < 50ms | FTS5 BM25 查询时间（Phase 1） |
| `agxp_tantivy_query_ms` | Histogram | Prometheus | P95 < 30ms | Tantivy BM25 查询时间（Phase 2） |
| `agxp_vector_search_ms` | Histogram | Prometheus | P95 < 100ms | pgvector HNSW 搜索时间 |
| `agxp_rerank_ms` | Histogram | Prometheus | P95 < 150ms | MiniLM 交叉编码器重排序时间 |
| `agxp_api_response_ms` | Histogram | Prometheus | P95 < 500ms | API 总响应时间 |
| `agxp_contribute_count` | Counter | Prometheus | N/A | 贡献经验总数 |
| `agxp_query_count` | Counter | Prometheus | N/A | 查询请求总数 |
| `agxp_error_rate` | Gauge | Prometheus | < 1% | 5xx 错误率 |
| `agxp_celery_queue_length` | Gauge | Redis + Prometheus | < 100 | Celery 任务队列积压 |
| `agxp_pg_connections_active` | Gauge | pg_stat_activity | < 80% pool | PostgreSQL 活跃连接数 |
| `agxp_redis_memory_used_bytes` | Gauge | Redis INFO | < 80% maxmemory | Redis 内存使用 |
| `agxp_sqlite_db_size_bytes` | Gauge | 文件大小监控 | < 1GB | 本地 SQLite 文件大小 |

---

## 6. 告警规则

| 告警名称 | 条件 | 严重级别 | 响应动作 |
|----------|------|----------|----------|
| API 不可用 | HTTP 健康检查连续 3 次失败 | Critical | 检查 FastAPI 进程、端口占用、日志 |
| PostgreSQL 不可用 | `pg_isready -p 5433` 失败 | Critical | 检查 PG 进程、磁盘空间、WAL 日志 |
| Redis 不可用 | `redis-cli -p 6379 PING` 无响应 | Critical | 检查 Redis 进程、内存、RDB 文件 |
| Celery Worker 下线 | `celery inspect ping` 无响应 | High | 重启 Worker；检查 Redis Broker |
| 磁盘使用率 > 85% | `df -h` 根分区或数据分区 | High | 清理日志、归档旧备份、扩容 |
| PG 连接池耗尽 | 活跃连接 > `max_connections * 0.8` | High | 检查连接泄漏、增大连接池、重启服务 |
| API P95 延迟 > 1s | `agxp_api_response_ms` P95 > 1000 | Medium | 检查慢查询、Celery 积压、模型加载 |
| 错误率 > 5% | 5 分钟窗口内 5xx/total > 5% | Medium | 查看错误日志、回滚最近部署 |
| SQLite 文件 > 500MB | `~/.agxp/local.db` 文件大小 | Low | 清理旧数据、VACUUM |
| Celery 队列积压 > 500 | Redis 中待处理任务数 | Medium | 增加 Worker 并发、检查任务耗时 |

---

## 7. 灾难恢复

### RTO / RPO 目标

| 场景 | RTO（恢复时间目标） | RPO（数据丢失目标） | 说明 |
|------|---------------------|---------------------|------|
| Phase 1 本地数据丢失 | < 5 分钟 | 上次备份以来的数据 | 从备份文件恢复 |
| Phase 2 PG 数据库崩溃 | < 30 分钟 | < 24 小时（每日备份） | pg_restore + alembic upgrade |
| Phase 2 服务器宕机 | < 2 小时 | < 24 小时 | 新节点部署 + 数据恢复 |
| Phase 2 Redis 丢失 | < 5 分钟 | 0（缓存可重建） | 重启 Redis，缓存自动预热 |

### 服务器重建步骤（Phase 2 — 腾讯云单节点）

```
1. 开通新实例（4C8G，Ubuntu 22.04）
2. 安装基础设施：
   - PostgreSQL 16 + pgvector 扩展
   - Redis 7.2
   - Python 3.11 + venv
3. 恢复数据：
   - pg_restore 最近备份
   - alembic upgrade head（补齐增量迁移）
4. 部署应用：
   - git clone + pip install agxp[server]
   - 配置 .env（从安全存储获取凭据）
   - systemctl start agxp-api agxp-worker
5. 验证：
   - curl http://localhost:8000/health
   - celery inspect ping
   - 执行一次查询和贡献测试
6. 更新 DNS / 防火墙规则
```

---

# Part 2 — 测试设计

---

## 8. 测试策略总览

### 测试金字塔

```
                    ┌─────────────────────┐
                    │   E2E / 性能测试      │  23 (Phase 1 E2E)
                    │   全链路验证          │  + Phase 2 E2E
                    └──────────┬──────────┘
               ┌───────────────┴────────────────┐
               │       集成测试 (156 个)          │  14 个测试文件
               │   真实 DB / 真实 SQLite          │  真实基础设施
               └───────────────┬────────────────┘
          ┌────────────────────┴────────────────────┐
          │            单元测试 (593 个)              │  67 个测试文件
          │   纯逻辑，无 I/O，Fake/Stub 注入         │  毫秒级执行
          └─────────────────────────────────────────┘

                     总计：749 个测试通过
```

### 分层测试数量明细

| 层级 | 测试文件数 | 测试用例数 | 占比 |
|------|-----------|-----------|------|
| 单元测试 (`tests/unit/`) | 67 | 593 | 79.2% |
| 集成测试 (`tests/integration/`) | 14 | 156 | 20.8% |
| **总计** | **81** | **749** | **100%** |

### 按 Phase 分布

| 分类 | 单元测试 | 集成测试 | 小计 |
|------|----------|----------|------|
| Phase 1 本地（SqliteStore、CLI、MCP、E2E） | 142 | 56 | 198 |
| Phase 2 服务端（Backend、API、Auth、Pipeline） | 451 | 100 | 551 |
| **总计** | **593** | **156** | **749** |

### 按 Issue 分布

| Issue | Phase | 单元 | 集成 | 状态 |
|-------|-------|------|------|------|
| #1 (scaffold) | 2 | 60 | 0 | 完成 |
| #2 (DB schema) | 2 | 33 | 12 | 完成 |
| #3 (embedding) | 2 | 19 | 4 | 完成 |
| #4 (vector search) | 2 | 13 | 6 | 完成 |
| #5 (FTS) | 2 | 14 | 8 | 完成 |
| #6 (credits) | 2 | 12 | 8 | 完成 |
| #7-server (quality) | 2 | 8 | 4 | 完成 |
| #8 (query API) | 2 | 15 | 10 | 完成 |
| #9 (contribute API) | 2 | 12 | 8 | 完成 |
| #10 (auth) | 2 | 10 | 6 | 完成 |
| #2-local (SqliteStore) | 1 | 36 | 20 | 完成 |
| #7-local (CLI) | 1 | 31 | 4 | 完成 |
| #14 (MCP) | 1 | 24 | 9 | 完成 |
| #21 (E2E) | 1 | 0 | 23 | 完成 |
| #22 (smart init) | 1 | 18 | 0 | 完成 |
| #23 (scoring) | 1 | 23 | 0 | 完成 |
| #25 (auto-feedback) | 1 | ~13 | ~1 | 测试已写，实现 pending |

### 数据管理策略

| 层级 | 数据库 | Embedding | FTS | 策略 |
|------|--------|-----------|-----|------|
| 单元测试 | 无 | FakeEmbeddingBackend | FakeFTSBackend | 纯内存，毫秒级 |
| 集成/DB | 真实 PostgreSQL，每测试前 rollback | 无 | 无 | 真实约束验证 |
| 集成/Embed | 无 | BgeM3LocalBackend（缓存） | 无 | 真实向量验证 |
| 集成/Search | 真实 PostgreSQL | FakeEmbeddingBackend | 真实 Tantivy | 搜索逻辑验证 |
| 集成/Local | 真实 SQLite 文件 | N/A | 内置 FTS5 | 文件 I/O + WAL 验证 |
| E2E | 真实全栈 | 真实（或 Fake） | 真实 | 全链路延迟验证 |

### pytest 配置概要

| 配置项 | 值 | 说明 |
|--------|-----|------|
| `asyncio_mode` | `auto` | 异步测试自动检测 |
| `asyncio_default_fixture_loop_scope` | `session` | Fixture 默认使用 session 级事件循环 |
| `asyncio_default_test_loop_scope` | `session` | 测试默认使用 session 级事件循环 |
| `addopts` | `--strict-markers` | 未注册 marker 报错 |
| markers | `unit`, `integration`, `performance`, `compatibility` | 四种标记 |

### Fixture 体系

```
tests/
├── conftest.py                    ← 全局 markers (unit/integration/performance/compatibility)
│
├── unit/
│   └── (无共享 fixtures)          ← 每个测试文件自包含，用 Fake 实现注入
│
└── integration/
    ├── test_db/
    │   └── conftest.py           ← DB fixtures
    │       ├── engine             scope=session  asyncpg NullPool
    │       ├── _shared_session    scope=session  单一 AsyncSession
    │       └── session (autouse)  loop_scope=session  每测试前 rollback
    │
    ├── test_local/
    │   └── (fixtures 在文件内)   ← 真实 SQLite .db 文件 fixture
    │
    └── test_embed/
        └── (fixtures 在文件内)   ← backend fixture scope=module
```

---

## 9. Phase 1 本地测试

### 9.1 SqliteStore 单元测试（36 个）

| 文件 | 测试数 |
|------|--------|
| `tests/unit/test_local/test_sqlite_store.py` | 36 |

**目标：** 验证 SqliteStore 的 CRUD 操作、FTS5 搜索、字段完整性、边界条件。

**关键用例：**

| 用例分类 | 说明 |
|----------|------|
| 贡献经验 | 必填字段写入 → 返回有效 UUID |
| 查询搜索 | BM25 关键词匹配 → 结果按相关性排序 |
| 字段完整性 | 所有 15 列（id, domain, subdomain, task_type, situation, failed_approaches, solution, outcome_type, lessons, environment, tags, language, quality_score, created_at, updated_at）正确存取 |
| 空输入处理 | 空字符串查询 → 返回空列表，不崩溃 |
| 过滤器 | domain、task_type、language 过滤器正确过滤 |
| FTS5 特殊字符 | 搜索包含 `-`、`*`、`"` 的文本 → 正确转义 |

### 9.2 评分系统单元测试（23 个）

| 文件 | 测试数 |
|------|--------|
| `tests/unit/test_local/test_scoring.py` | 23 |

**目标：** 验证 contribute 时的质量评分计算和 feedback 机制。

**关键用例：**

| 用例分类 | 说明 |
|----------|------|
| 完整性评分 | 包含所有可选字段 → 高分；仅必填字段 → 低分 |
| 评分边界 | 分数范围 [0.0, 1.0]，不会超出 |
| 反馈更新 | upvote/downvote 正确修改质量分 |
| 衰减机制 | 旧评分随时间衰减 |

### 9.3 搜索日志单元测试（8 个）

| 文件 | 测试数 |
|------|--------|
| `tests/unit/test_local/test_search_log.py` | 8 |

**目标：** 验证搜索操作的日志记录，供后续 auto-feedback 使用。

### 9.4 Agent 检测单元测试（18 个）

| 文件 | 测试数 |
|------|--------|
| `tests/unit/test_local/test_agent_detect.py` | 18 |

**目标：** 验证 `agxp init` 时自动检测 Claude Code、Cursor 等 Agent 配置。

### 9.5 MCP 单元测试（24 个）

| 文件 | 测试数 |
|------|--------|
| `tests/unit/test_mcp/test_mcp_tools.py` | 19 |
| `tests/unit/test_mcp/test_mcp_feedback.py` | 5 |

**目标：** 验证 MCP 协议的 search_experiences、contribute_experience、report_feedback 工具。

**关键用例：**

| 用例分类 | 说明 |
|----------|------|
| 搜索工具 | 有效查询 → 返回格式正确的结果 |
| 贡献工具 | 完整数据 → 返回 experience_id |
| 参数校验 | 缺少必填字段 → 返回错误信息，不崩溃 |
| 反馈工具 | 有效 feedback → 更新评分 |

### 9.6 CLI 单元测试（31 个）

| 文件 | 测试数 |
|------|--------|
| `tests/unit/test_cli/test_cli_commands.py` | 27 |
| `tests/unit/test_cli/test_cli_feedback.py` | 4 |

**目标：** 验证 Typer CLI 命令的参数解析、输出格式、错误处理。

**关键用例：**

| 用例分类 | 说明 |
|----------|------|
| `agxp init` | 首次初始化 → 创建 `~/.agxp/` 目录和数据库 |
| `agxp contribute` | 有效数据 → 成功写入 + 显示质量分 |
| `agxp query` | 关键词搜索 → 显示格式化结果 |
| `agxp status` | 显示数据库统计信息 |
| `agxp mcp` | 启动 MCP stdio 服务器 |
| 错误处理 | 数据库不存在 → 提示先运行 `agxp init` |

### 9.7 Phase 1 集成测试（56 个）

| 文件 | 测试数 | 说明 |
|------|--------|------|
| `tests/integration/test_local/test_sqlite_store_integration.py` | 20 | SqliteStore 真实 SQLite 文件 |
| `tests/integration/test_mcp/test_mcp_integration.py` | 9 | MCP 集成 |
| `tests/integration/test_cli/test_cli_integration.py` | 4 | CLI 集成 |
| `tests/integration/test_local_e2e.py` | 23 | Phase 1 端到端 |

**关键用例：**

| 用例分类 | 文件 | 说明 |
|----------|------|------|
| 真实文件 I/O | sqlite_store_integration | 真实 `.db` 文件（非 `:memory:`） |
| FTS5 round-trip | sqlite_store_integration | contribute → FTS5 search → 找到经验 |
| WAL 模式 | sqlite_store_integration | 并发读写不死锁 |
| MCP 协议 | mcp_integration | 真实 SqliteStore 上的 MCP 工具调用 |
| CLI 全链路 | cli_integration | `agxp init` → `contribute` → `query` |
| E2E 流程 | test_local_e2e | 完整用户场景覆盖（23 个） |

---

## 10. Phase 2 服务端测试

### 10.1 Backend 单元测试

| 文件 | 说明 |
|------|------|
| `tests/unit/test_backends/test_embedding_backend.py` | EmbeddingBackend ABC + FakeEmbeddingBackend |
| `tests/unit/test_backends/test_vector_backend.py` | VectorSearchBackend + FakeVectorBackend |
| `tests/unit/test_backends/test_fts_backend.py` | FullTextSearchBackend + FakeFTSBackend |
| `tests/unit/test_backends/test_credit_writer.py` | CreditWriter + FakeCreditWriter |
| `tests/unit/test_backends/test_quality_writer.py` | QualityScoreWriter + FakeQualityWriter |
| `tests/unit/test_embed/test_fake_backend.py` | FakeEmbeddingBackend 详细测试 |
| `tests/unit/test_embed/test_experience_embedder.py` | ExperienceEmbedder 逻辑 |
| `tests/unit/test_embed/test_embed_task.py` | Celery embed 任务 |
| `tests/unit/test_embed/test_minilm_backend.py` | MiniLM 交叉编码器 |
| `tests/unit/test_fts/test_fake_fts_backend.py` | FakeFTSBackend |
| `tests/unit/test_fts/test_tantivy_filter_escaping.py` | Tantivy 过滤器转义 |
| `tests/unit/test_vector/test_fake_vector_backend.py` | FakeVectorBackend |
| `tests/unit/test_vector/test_hnswlib_backend.py` | HNSWlib backend |
| `tests/unit/test_vector/test_hnswlib_filters.py` | HNSWlib 过滤 |
| `tests/unit/test_credit/test_fake_credit_writer.py` | FakeCreditWriter |
| `tests/unit/test_quality/test_completeness_score.py` | 完整性评分逻辑 |
| `tests/unit/test_quality/test_credit_reward_mapping.py` | 积分奖励映射 |
| `tests/unit/test_quality/test_fake_quality_writer.py` | FakeQualityWriter |
| `tests/unit/test_quality/test_score_quality_task.py` | Celery 评分任务 |

**目标：** 验证所有 ABC 的 Fake 实现满足合约，以及纯逻辑组件的正确性。

**关键用例：**

| 用例分类 | 说明 |
|----------|------|
| ABC 合约 | Fake 实现的返回类型、排序、字段完整性与真实实现一致 |
| 空输入 | 空列表 embed → 返回空列表 |
| 幂等性 | 相同 idem_key 的 credit 操作不重复扣费 |
| 质量评分 | [0, 0.5)→5, [0.5, 0.7)→10, [0.7, 0.85)→25, [0.85, 1.0]→50 积分 |

### 10.2 搜索管道单元测试

| 文件 | 说明 |
|------|------|
| `tests/unit/test_search/test_query_pipeline.py` | 服务端搜索管道 |
| `tests/unit/test_search/test_local_pipeline.py` | 本地搜索管道 |
| `tests/unit/test_search/test_rrf_fusion.py` | RRF 融合算法 (k=60) |
| `tests/unit/test_search/test_quality_blend.py` | 0.7*reranker + 0.3*quality 混合评分 |
| `tests/unit/test_search/test_fake_reranker.py` | FakeCrossEncoder |
| `tests/unit/test_search/test_flatten_env.py` | environment dict 文本化 |
| `tests/unit/test_search/test_query_degradation.py` | 服务端降级场景 |
| `tests/unit/test_search/test_local_pipeline_degradation.py` | 本地降级场景 |

### 10.3 API 端点单元测试

| 文件 | 说明 |
|------|------|
| `tests/unit/test_api/test_query_endpoint.py` | POST /v1/query |
| `tests/unit/test_api/test_query_endpoint_warnings.py` | 查询降级警告 |
| `tests/unit/test_api/test_startup_checks.py` | 启动健康检查 |
| `tests/unit/test_contribute/test_contribute_request.py` | 贡献请求校验 |
| `tests/unit/test_contribute/test_contribute_route.py` | POST /v1/contribute |
| `tests/unit/test_contribute/test_estimated_credits.py` | 预估积分计算 |

### 10.4 认证单元测试

| 文件 | 说明 |
|------|------|
| `tests/unit/test_auth/test_auth_routes.py` | 注册/登录路由 |
| `tests/unit/test_auth/test_dependency.py` | FastAPI 依赖注入 |
| `tests/unit/test_auth/test_keys.py` | API Key 生成和验证 |

### 10.5 其他单元测试

| 文件 | 说明 |
|------|------|
| `tests/unit/test_models/test_experience_model.py` | Experience 数据模型 |
| `tests/unit/test_models/test_user_model.py` | User 数据模型 |
| `tests/unit/test_models/test_credit_model.py` | Credit 数据模型 |
| `tests/unit/test_models/test_enums.py` | 枚举类型 |
| `tests/unit/test_scaffold/test_imports.py` | 模块导入正确性 |
| `tests/unit/test_scaffold/test_structure.py` | 项目结构验证 |
| `tests/unit/test_config/test_dev_script.py` | 开发脚本 |
| `tests/unit/test_config/test_dotenv_loading.py` | .env 加载 |
| `tests/unit/test_config/test_env_example.py` | .env.example 完整性 |
| `tests/unit/test_config/test_local_config.py` | 本地配置 |
| `tests/unit/test_store/test_sqlite_store.py` | SQLite store（通用） |
| `tests/unit/test_store/test_sqlite_get_many.py` | 批量获取 |
| `tests/unit/test_store/test_sqlite_outcome_validation.py` | outcome 校验 |

### 10.6 Phase 2 集成测试（100 个）

| 文件 | 说明 |
|------|------|
| `tests/integration/test_db/test_schema.py` | 数据库 Schema 约束 |
| `tests/integration/test_db/test_migrations.py` | Alembic 迁移正确性 |
| `tests/integration/test_embed/test_bgem3_local_backend.py` | BgeM3 真实嵌入 |
| `tests/integration/test_fts/test_tantivy_backend.py` | Tantivy BM25 真实索引 |
| `tests/integration/test_vector/test_pgvector_backend.py` | pgvector 真实向量搜索 |
| `tests/integration/test_credit/test_postgres_credit_writer.py` | PostgreSQL 积分系统 |
| `tests/integration/test_quality/test_inline_quality_writer.py` | 质量评分写入 |
| `tests/integration/test_auth/test_auth_integration.py` | 认证全链路 |
| `tests/integration/test_api/test_startup_integration.py` | 启动检查集成 |
| `tests/integration/test_api/test_server_e2e.py` | 服务端 E2E |

**关键用例：**

| 用例分类 | 说明 |
|----------|------|
| Schema 约束 | FK 约束、UNIQUE 约束、CHECK 约束在真实 PG 上生效 |
| Alembic 迁移 | upgrade → downgrade → upgrade 可逆 |
| 向量搜索 | pgvector HNSW 索引正确返回 top-K |
| BM25 搜索 | Tantivy 索引写入 → 搜索 → 正确排序 |
| 积分幂等 | 相同 idem_key 不重复扣费 |
| 认证链路 | register → get API key → query with key → success |

---

## 11. 端到端测试

### 11.1 Phase 1 E2E（23 个）

| 文件 | 测试数 |
|------|--------|
| `tests/integration/test_local_e2e.py` | 23 |

**测试场景：**

| 场景 | 说明 |
|------|------|
| 初始化 → 贡献 → 查询 | `agxp init` → `contribute` → `query` 全流程 |
| 多经验搜索排序 | 贡献多条经验 → 搜索 → 验证相关性排序 |
| FTS5 BM25 匹配 | 关键词精确匹配 vs 模糊匹配 → 分数差异 |
| 过滤器组合 | domain + task_type + language 组合过滤 |
| MCP 工具调用 | search_experiences → contribute_experience → report_feedback |
| 质量评分流程 | contribute → 自动评分 → 查看分数 |
| 降级场景 | 数据库为空时查询 → 返回空结果 + 友好提示 |

### 11.2 Phase 2 E2E

| 文件 | 说明 |
|------|------|
| `tests/integration/test_api/test_server_e2e.py` | 服务端全链路 |

**测试场景：**

| 场景 | 说明 |
|------|------|
| 注册 → 贡献 → 查询 | POST /auth/register → POST /v1/contribute → POST /v1/query |
| Celery 异步处理 | contribute → 等待 Worker 完成 → 验证 embedding + FTS 索引 |
| 积分流转 | contribute 获得积分 → query 消耗积分 → 余额正确 |
| 启动健康检查 | 所有依赖就绪 → /health 返回 200 |
| 降级启动 | Redis 不可用 → 启动时明确告警 |

---

# Part 3 — 质量保障

---

## 12. 开发工作流（10 步强制流程）

> 每个 Issue 必须严格执行以下 10 步。步骤 0-1、2b、5 需要人工参与。

| 步骤 | 名称 | 执行者 | 说明 | 交付物 |
|------|------|--------|------|--------|
| 0 | Pre-flight 检查 | 自动 (`/preflight #N`) | 验证文档存在、skill 可用、执行计划合规 | 检查报告 |
| 1 | 环境检查 | **人工确认** | 权限、工具、基础设施就绪，循环上限（默认 20 次 / 20 分钟） | 确认记录 |
| 2a | 设计草案 + 设计检查 | 自动 (`/design-check`) | 读取 HARNESS.md + 设计文档，草拟设计，循环验证直到 PASS（最多 10 次） | 字段映射表 + 10 类检查清单 |
| 2b | 设计审核 | **人工审阅** | 生成飞书文档（设计摘要、scope、文件列表、关键决策、字段映射表），提供链接 | 飞书文档链接 |
| 3 | Tester 子代理 | 自动 (`/tester #N`) | 仅读 ABC 和设计文档，不读实现代码；写测试（必须全 RED） | 测试文件 |
| 4 | 测试质量检查 | 自动 (`/test-quality-check`) | 独立审核测试质量（通用 rubric + 项目扩展），不读实现。FAIL 则打回 tester（最多 3 次） | 质量报告 |
| 5 | 测试审核 | **人工审阅** | 生成飞书文档（测试内容、数量、覆盖范围、quality checker 报告），提供链接 | 飞书文档链接 |
| 6 | 备份 + 分支 | 自动 | 创建 tmp 目录备份待修改文件；创建 feature 分支 | 备份 + Git 分支 |
| 7 | Dev 循环 | 自动 | 实现代码直到所有测试绿色，不超过确认的循环上限 | 绿色测试套件 |
| 8 | Code Review 子代理 | 自动 (`/review #N`) | 独立代码审查，禁止自审。检查安全、合约、正确性 | 审查报告 |
| 9 | DEV_LOG 更新 | 自动 | 追加本次会话的决策和教训到 `docs/DEV_LOG.md` | DEV_LOG 更新 |

### 流程图

```
  ┌──────────────┐     ┌──────────────┐     ┌──────────────────┐
  │ 0. Preflight │────→│ 1. 环境检查   │────→│ 2a. 设计草案      │
  │   (自动)     │     │   (人工)     │     │ + /design-check  │
  └──────────────┘     └──────────────┘     │ (自动，最多10次)  │
                                             └────────┬─────────┘
                                                      │ PASS
                                             ┌────────▼─────────┐
                                             │ 2b. 设计审核      │
                                             │   (人工，飞书)    │
                                             └────────┬─────────┘
                                                      │ 批准
                              ┌────────────────────────▼──────┐
                              │ 3. /tester #N                 │
                              │ 写测试（仅读合约，不读实现）    │
                              └────────────────┬──────────────┘
                                               │
                              ┌────────────────▼──────────────┐
                              │ 4. /test-quality-check        │
                              │ 质量审核（最多循环3次）         │◄──┐
                              └────────────────┬──────────────┘   │
                                               │ FAIL             │
                                               └──────────────────┘
                                               │ PASS
                              ┌────────────────▼──────────────┐
                              │ 5. 测试审核（人工，飞书）       │
                              └────────────────┬──────────────┘
                                               │ 批准
                              ┌────────────────▼──────────────┐
                              │ 6. 备份 + 创建 feature 分支    │
                              └────────────────┬──────────────┘
                                               │
                              ┌────────────────▼──────────────┐
                              │ 7. Dev 循环（实现到测试全绿）   │
                              └────────────────┬──────────────┘
                                               │
                              ┌────────────────▼──────────────┐
                              │ 8. /review #N（独立代码审查）   │
                              └────────────────┬──────────────┘
                                               │ APPROVED
                              ┌────────────────▼──────────────┐
                              │ 9. 更新 DEV_LOG               │
                              └────────────────────────────────┘
```

---

## 13. Sub-Agent 体系

### 13.1 Tester 子代理（步骤 3）

| 属性 | 值 |
|------|-----|
| 触发命令 | `/tester #N` |
| 输入 | ABC 接口文件 + 设计文档 + 先前测试示例（风格参考） |
| 禁止读取 | 实现代码（Real + Fake 实现文件） |
| 输出 | 单元测试 + 集成测试文件，全部 RED |
| 模板路径 | `docs/TESTER_PROMPT.md` |

**核心原则：** 测试从合约出发，不从实现出发——防止确认偏差（confirmation bias）。

**测试分类要求：**

| 分类 | 单元测试要求 | 集成测试要求 |
|------|-------------|-------------|
| Happy path | 基本操作成功 + 正确返回类型/形状 | Round-trip 读写正确性 |
| 输入边界 | 空字符串/空列表/None/零值/重复 ID | 并发写入、幂等性验证 |
| 合约边界 | 最小/最大合法输入、DDR 中定义的边界值 | 排序和排名正确性 |
| 错误合约 | 文档化的异常必须抛出；未文档化的输入不能静默 | DB 约束违规 → 正确异常 |
| 降级场景 | N/A | 依赖缺失、部分数据状态、启动验证 |
| 测试隔离 | 无共享可变状态，顺序无关 | fixture 清理，不留测试残留数据 |

**输出格式要求：**

```
FILES WRITTEN
- tests/unit/{dir}/test_*.py  (N tests)
- tests/integration/{dir}/test_*.py  (N tests)

COVERAGE RATIONALE
- 每个测试文件列出 3-5 个最重要用例及选择原因
- 标注发现的合约歧义

EXPECTED INITIAL STATE
- 所有测试：RED（实现不存在）
```

### 13.2 测试质量检查子代理（步骤 4）

| 属性 | 值 |
|------|-----|
| 触发命令 | `/test-quality-check <test files>` |
| 输入 | 测试文件（只读测试，不读实现） |
| 输出 | PASS / FAIL + 质量报告 |
| 扩展规则 | `docs/TEST_QUALITY_CHECKER_PROMPT.md` |
| 重试上限 | FAIL 则打回 tester，最多循环 3 次 |

**AGXP 项目特有的自动拒绝规则：**

| 编号 | 规则 | 说明 |
|------|------|------|
| 5 | Phase 2 集成测试手动插入 `api_keys`/`users` 表 | 必须使用 auth 端点（register/anonymous） |
| 6 | Phase 1 集成测试使用 `:memory:` SQLite | 必须使用真实 `.db` 文件 |
| 7 | FTS5 搜索测试仅检查"结果存在" | 必须验证 BM25 排序正确性 |

**Phase 特定规则：**

| Phase | 集成测试要求 |
|-------|-------------|
| Phase 1 | 真实 SQLite 文件 + FTS5 round-trip + 无 embedding/vector mock |
| Phase 2 | 真实 PG (localhost:5433) + 真实 Redis (localhost:6379) + Auth token 来自真实端点 |

**清理规则：**

| Phase | 清理方式 |
|-------|----------|
| Phase 1 | fixture teardown 中删除测试 `.db` 文件 |
| Phase 2 | 用 `test-e2e-` 或 `test-integ-` 前缀标识测试数据，按 FK 顺序删除 |

**FK 依赖删除顺序：** `search_feedback` → `quality_votes` → `experiences` → `api_keys` → `credit_accounts` → `users`

### 13.3 Code Review 子代理（步骤 8）

| 属性 | 值 |
|------|-----|
| 触发命令 | `/review #N` |
| 输入 | 所有变更文件的完整内容 |
| 输出 | APPROVED / CHANGES_REQUESTED + 结构化报告 |
| 模板路径 | `docs/CODE_REVIEW_PROMPT.md` |
| 报告字数限制 | < 400 字 |

**审查清单分级：**

| 级别 | 检查项 | 处理方式 |
|------|--------|----------|
| **BLOCKING** | SQL 注入（f-string 列名非白名单）| 必须修复后重新审查 |
| **BLOCKING** | 异步错误（事件循环内阻塞 I/O）| 必须修复后重新审查 |
| **BLOCKING** | 线程错误（SQLite `check_same_thread`、无锁共享状态）| 必须修复后重新审查 |
| **BLOCKING** | 字段缺失（可选字段在某层被静默丢弃）| 必须修复后重新审查 |
| **BLOCKING** | ABC 未完全实现（残留 `NotImplementedError`）| 必须修复后重新审查 |
| **BLOCKING** | 静默失败（`except: pass` 或 `except Exception: return []`）| 必须修复后重新审查 |
| **BLOCKING** | 数据类型合约（asyncpg UUID 未转 str、pgvector 未注册）| 必须修复后重新审查 |
| **WARN** | 连接/文件句柄未在 finally/with 中关闭 | 记录到 DEV_LOG |
| **WARN** | 测试验证内部实现而非可观察行为 | 记录到 DEV_LOG |
| **WARN** | 操作就绪度（目录未自动创建、环境变量缺失未 fast-fail）| 记录到 DEV_LOG |
| **SUGGEST** | 魔法数字/字符串应提取为常量 | 建议改进 |
| **SUGGEST** | 边界测试覆盖不足 | 建议改进 |
| **SUGGEST** | 公共 API 缺少 docstring | 建议改进 |

**裁决规则：** 无 BLOCKING 项即 APPROVED（即使有 WARN/SUGGEST 项）。

### 13.4 设计检查（步骤 2a）

| 属性 | 值 |
|------|-----|
| 触发命令 | `/design-check` |
| 输入 | 设计草案 + HARNESS.md |
| 输出 | PASS / FAIL + 检查报告 |
| 循环上限 | 最多 10 次；超过仍未 PASS 则停止并报告用户 |

**10 类验证清单：**

| 编号 | 类别 | 检查内容 |
|------|------|----------|
| 1 | 字段映射表 | 每个字段在每一层（Input → Storage → FTS Index → Vector Index → Query Return → Output）标注 ✓/✗/N/A |
| 2 | 未标注字段 | 禁止出现 ??? — 每个 ✗ 必须注明原因 |
| 3 | JSON/dict 字段 | 说明内部结构和文本化方式 |
| 4 | ABC 合约 | 所有抽象方法都有实现计划 |
| 5 | 错误处理 | 明确说明异常传播路径 |
| 6 | 并发安全 | SQLite WAL / asyncpg 连接池 / Celery 幂等性 |
| 7 | 测试策略 | 明确单元/集成/E2E 测试分配 |
| 8 | 降级方案 | 依赖不可用时的行为定义 |
| 9 | 安全 | SQL 注入防护、认证路径 |
| 10 | 向后兼容 | 对已有 API/数据格式的影响 |

### 13.5 测试执行规则

| 规则 | 说明 |
|------|------|
| 禁止主代理直接运行 pytest | 必须委托给 `/run-tests` skill |
| 子代理必须显示完整原始输出 | 禁止 tail、summary、过滤 |
| 验证计数一致 | `collected_count == total_run`，不一致则发出 WARNING |
| 部分结果处理 | 子代理返回部分结果时，通知用户并询问是否重试 |

---

## 14. 代码安全约束

### 14.1 SQL 注入防护

| 规则 | Phase 1（SQLite） | Phase 2（asyncpg） |
|------|-------------------|---------------------|
| 列名来源 | 硬编码白名单 dict | 硬编码白名单 dict |
| 值绑定 | `?` 位置参数 | `$1`, `$2` 位置参数 |
| 禁止 | f-string 拼接用户输入 | f-string 拼接用户输入 |

**正确示例：**

```python
# 白名单列名
SORT_COLUMNS = {
    "created_at": "created_at",
    "quality_score": "quality_score",
    "domain": "domain",
}
col = SORT_COLUMNS.get(user_sort_field)
if col is None:
    raise ValueError(f"Invalid sort field: {user_sort_field}")

# Phase 1: sqlite3 参数绑定
cursor.execute(f"SELECT * FROM experiences WHERE domain = ? ORDER BY {col} DESC", (domain,))

# Phase 2: asyncpg 参数绑定
await conn.fetch(f"SELECT * FROM experiences WHERE domain = $1 ORDER BY {col} DESC", domain)
```

**错误示例（绝对禁止）：**

```python
# 用户输入直接拼入 SQL
cursor.execute(f"SELECT * FROM experiences WHERE {user_field} = '{user_value}'")
```

### 14.2 静默失败防护

| 规则 | 说明 |
|------|------|
| 禁止 `except: pass` | 所有异常必须被记录或传播 |
| 禁止 `except Exception: return []` | 错误不能被吞掉并返回假结果 |
| 可选 kwargs 验证 | `None`、`Ellipsis`、`{}` 不可互换 |
| 显式错误传播 | 库调用失败必须产生明确的错误信息 |

**Tantivy 0.25 特殊问题：**

| 陷阱 | 说明 |
|------|------|
| `doc["field"]` 返回列表 | 必须用 `doc["field"][0]` 取值 |
| `parse_query(field_boosts=None)` | 会抛异常 — 无 boost 时直接省略该参数 |

### 14.3 异步正确性（Phase 2）

| 规则 | 说明 |
|------|------|
| 禁止事件循环内阻塞 I/O | DB 查询、模型推理、文件 I/O 必须使用 `run_in_executor` |
| 禁止嵌套 `asyncio.run()` | 已在运行的事件循环中不能调用 `asyncio.run()` |
| 禁止无锁共享可变状态 | 多线程/多任务并发修改共享数据必须加锁 |

### 14.4 线程正确性（Phase 1）

| 规则 | 说明 |
|------|------|
| `check_same_thread=False` | 多线程访问 SQLite 必须显式启用 |
| WAL 模式 | 并发读写必须使用 `PRAGMA journal_mode=WAL` |
| FTS5 tokenizer | 使用 `unicode61` 支持多语言 |
| FTS5 索引重建 | Schema 变更后执行 `INSERT INTO fts_table(fts_table) VALUES('rebuild')` |

### 14.5 数据类型合约

| 规则 | Phase 1 | Phase 2 |
|------|---------|---------|
| UUID | SQLite 存储为 TEXT，无需转换 | asyncpg 返回 `uuid.UUID`，必须 `str()` 转换 |
| JSON 字段 | `json.dumps()` 写入，`json.loads()` 读取 | asyncpg JSONB 同样需要序列化/反序列化 |
| pgvector 编解码 | N/A | `register_vector` 必须在连接池初始化时调用 |
| FTS5 特殊字符 | MATCH 查询必须转义 `-`, `*`, `"` | Tantivy 使用 `parse_query` 自动处理 |

---

## 15. 回滚机制

### 15.1 Git 回滚

| 场景 | 操作 | 命令 |
|------|------|------|
| 撤销最近一次提交 | Git revert | `git revert HEAD` |
| 撤销特定提交 | Git revert | `git revert <commit-hash>` |
| 丢弃未提交的变更 | Git checkout | `git checkout -- <file>` |
| 回退到指定版本 | Git reset（谨慎） | `git reset --hard <commit-hash>`（仅限本地分支） |

### 15.2 数据库迁移回滚（Phase 2）

| 场景 | 操作 | 命令 |
|------|------|------|
| 回退一步 | Alembic downgrade | `alembic downgrade -1` |
| 回退到指定版本 | Alembic downgrade | `alembic downgrade <revision>` |
| 回退到初始状态 | Alembic downgrade | `alembic downgrade base` |
| 查看当前版本 | Alembic current | `alembic current` |
| 查看迁移历史 | Alembic history | `alembic history --verbose` |

**注意事项：**

| 项目 | 说明 |
|------|------|
| 迁移脚本路径 | `agxp/db/migrations/` |
| 数据库 URL | `postgresql+asyncpg://agxp:agxp@localhost:5433/agxp`（见 `alembic.ini`） |
| 降级前备份 | 务必先执行 `pg_dump` |
| 不可逆操作 | 含 `DROP COLUMN` 的迁移降级脚本需要重建列 |

### 15.3 临时文件备份回滚（步骤 6）

| 操作 | 说明 |
|------|------|
| 备份创建 | 每个 Issue 实现前，自动备份待修改文件到 `/tmp/agxp-backup-{issue}-{timestamp}/` |
| 回滚操作 | `cp /tmp/agxp-backup-{issue}-{timestamp}/* <original-path>` |
| 备份保留 | 临时目录在系统重启或 7 天后自动清理 |

### 15.4 回滚决策矩阵

| 场景 | 首选回滚方式 | 备选方式 | 需要人工确认 |
|------|-------------|----------|--------------|
| 代码变更引入 bug | `git revert` | tmp 备份恢复 | 否 |
| 数据库 Schema 变更失败 | `alembic downgrade` | `pg_restore` | 是 |
| 配置变更导致服务不可用 | 恢复 `.env` 备份 + 重启 | 手动修改 | 否 |
| SQLite 数据损坏 | 从备份恢复 `.db` 文件 | `PRAGMA integrity_check` + 修复 | 否 |
| 错误的数据迁移 | `alembic downgrade` + 数据修复脚本 | `pg_restore` 全量恢复 | 是 |
