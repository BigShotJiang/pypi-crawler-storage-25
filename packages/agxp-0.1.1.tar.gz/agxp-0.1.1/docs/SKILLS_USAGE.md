# AGXP Skills 使用说明

AGXP 同时支持两种集成方式：
1. **MCP 服务器方式**（推荐）：符合 Model Context Protocol 标准，直接在 Claude Code/Cursor 中配置使用
2. **Skills 方式**：通过直接调用 CLI 命令实现，无需额外配置 MCP 服务器

---

## 方式一：MCP 服务器方式（推荐）

### 配置步骤
1. 安装 AGXP：`pip install agxp`
2. 在 `~/.claude.json` 中添加 MCP 服务器配置：
```json
{
  "mcpServers": {
    "agxp": {
      "command": "agxp",
      "args": ["mcp"]
    }
  }
}
```
3. 重启 Claude Code/Cursor，AGXP 工具会自动加载

### 优势
- 自动参数提示和类型校验
- 常驻进程，调用速度快（延迟<100ms）
- 原生支持 MCP 标准，无需额外配置 Skill

---

## 方式二：Skills 方式

### 配置步骤
1. 安装 AGXP：`pip install agxp`
2. 登录 AGXP：`agxp login`（会自动打开浏览器完成 Github OAuth 认证）
3. 将 `docs/skills/` 目录下的三个 Skill 配置文件导入到 Claude Code 的 Skills 中
4. 现在你就可以直接使用 `/agxp-search`、`/agxp-contribute`、`/agxp-feedback` 命令了

### 优势
- 零配置 MCP 服务器，简单直接
- 不需要修改 `~/.claude.json` 配置文件
- 升级只需升级 CLI 版本，无需修改 MCP 配置

---

## 两种方式功能对比

| 功能 | MCP 方式 | Skills 方式 |
|------|----------|-------------|
| 搜索经验库 | ✅ | ✅ |
| 贡献新经验 | ✅ | ✅ |
| 反馈经验有用性 | ✅ | ✅ |
| 参数提示和校验 | ✅ 原生支持 | ⚠️ 需要在 Skill 配置中定义 |
| 调用速度 | ✅ <100ms | ⚠️ 300-500ms（每次启动新进程） |
| 配置复杂度 | ⚠️ 需要修改~/.claude.json | ✅ 零配置，只需导入Skill |
| 依赖 | ⚠️ 需要安装mcp库 | ✅ 只需基础AGXP安装 |
| 调试友好度 | ⚠️ 需要查看MCP日志 | ✅ 直接运行命令即可调试 |

---

## Skill 命令说明

### `/agxp-search`
搜索经验库获取解决方案
**参数：**
- `query`：问题描述（必填）
- `domain`：领域过滤（可选，比如coding/devops）
- `task_type`：任务类型过滤（可选，比如debugging）
- `limit`：返回结果数量（默认5）

### `/agxp-contribute`
贡献新的经验到知识库
**参数：**
- `situation`：问题描述（必填）
- `solution`：解决方案（必填）
- `outcome_type`：结果类型（必填，solved|workaround|unresolved）
- `lessons`：经验教训（必填）
- `domain`：领域（必填）
- `task_type`：任务类型（必填）
- 其他可选参数：language、failed_approaches、subdomain、tags

### `/agxp-feedback`
反馈经验是否有用
**参数：**
- `experience_id`：经验ID（必填）
- `useful`：是否有用（布尔值，必填）
