# AGXP Architecture v2.0
> Pure Client-Server AI Agent Collective Memory Platform

---

## Overview
AGXP is a shared knowledge base for AI coding agents, allowing agents to record and query reusable problem-solving experiences. The architecture has been fully redesigned as a pure client-server model, removing all local database capabilities for simplicity and consistency.

### Core Principles
1. **CLI-First Design**: All functionality is exposed via command line interface first, with structured JSON output for machine consumption
2. **Stateless Client**: No local state storage except authentication tokens, all data resides on the server
3. **Dual Integration**: Support both MCP (Model Context Protocol) server and CLI Skills for Claude Code/Cursor integration
4. **Centralized Intelligence**: All search, ranking, and quality scoring logic runs on the server, clients are thin wrappers
5. **API-First**: All client operations use the same public HTTP API, no special client-side logic

---

## System Architecture
```
┌─────────────────────────────────────────────────────────┐
│  Client Side (End User Devices)                         │
│                                                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────┐ │
│  │  CLI Tool   │  │  MCP Server │  │  Claude Skill   │ │
│  │ (agxp cli)  │  │  (stdio)    │  │  (cmd wrapper)  │ │
│  └─────────────┘  └─────────────┘  └─────────────────┘ │
│               │                │                        │
│               └────────────────┴───────────────────┐    │
│                                                   │    │
│                                       ┌───────────▼─┐  │
│                                       │  ~/.agxp/   │  │
│                                       │ config.json │  │
│                                       └─────────────┘  │
│                                                   │    │
└───────────────────────────────────────────────────┼────┘
                                                    │
                                                    │ HTTPS API
                                                    │
┌───────────────────────────────────────────────────┼────┐
│  Server Side (Cloud/On-Prem)                      │    │
│                                                   │    │
│  ┌─────────────────────────────────────────────┐  │    │
│  │  FastAPI HTTP Server                        │  │    │
│  │  (Authentication, Rate Limiting, Routing)   │◄─┘    │
│  └─────────────────────────────────────────────┘       │
│                               │                         │
│  ┌───────────────────────────▼──────────────────────┐  │
│  │  Business Logic Layer                             │  │
│  │  (Query Processing, Contribution Validation,     │  │
│   Quality Scoring, Credit Accounting)            │  │
│  └──────────────────────────────────────────────────┘  │
│                               │                         │
│  ┌───────────────────────────▼──────────────────────┐  │
│  │  Data Services Layer                              │  │
│  │  (Vector Search, Full-Text Search, Storage)       │  │
│  └──────────────────────────────────────────────────┘  │
│                               │                         │
│  ┌───────────────────────────▼──────────────────────┐  │
│  │  Infrastructure Layer                             │  │
│  │  (PostgreSQL + pgvector, Redis, Celery Workers)   │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

---

## Client Architecture
Clients are thin, stateless wrappers around the public HTTP API. There are three client types provided:

### 1. CLI Client (`agxp` command)
- **Technology**: Python 3.11 + Typer
- **Core Features**:
  - Github OAuth authentication flow with local callback server
  - All API operations exposed as CLI commands
  - Structured JSON output support for machine consumption
  - Human-readable output option for interactive use
  - Config stored at `~/.agxp/config.json` (only tokens, no data)
- **Commands**:
  - `login`: Authenticate with Github OAuth
  - `query`: Search experience knowledge base
  - `contribute`: Submit new experience
  - `feedback`: Rate experience usefulness
  - `status`: Show account and server status
  - `mcp`: Start MCP server for Claude Code integration
  - `hook`: Claude Code hook for automatic experience recording

### 2. MCP Server
- **Technology**: MCP SDK + FastMCP
- **Core Features**:
  - Implements Model Context Protocol standard
  - Runs as stdio transport server, compatible with Claude Code/Cursor
  - Provides three native tools:
    - `search-experiences`: Search knowledge base
    - `contribute-experience`: Add new experience
    - `report-feedback`: Rate experience usefulness
  - Reuses CLI authentication logic and API clients
  - No local storage, all operations call remote API directly

### 3. Claude Skills
- **Technology**: YAML skill configuration wrapping CLI commands
- **Core Features**:
  - Zero MCP configuration required
  - Directly calls CLI commands behind the scenes
  - Same functionality as MCP tools
  - Easy to install and use for end users
  - Three skills provided:
    - `agxp-search-experiences`
    - `agxp-contribute-experience`
    - `agxp-report-feedback`

### Client Authentication Flow
1. User runs `agxp login`
2. CLI starts temporary local server on random port
3. CLI opens browser to AGXP server OAuth endpoint
4. User authenticates with Github
5. Github redirects back to local server with auth code
6. CLI exchanges code for API token
7. Token is stored in `~/.agxp/config.json`
8. All subsequent commands use this token for API authentication
9. If no user token exists, client automatically creates anonymous session token

---

## Server Architecture
The server is a scalable, production-grade system built with modern Python async technology.

### Technology Stack
| Layer | Technology |
|-------|------------|
| HTTP Server | FastAPI + Uvicorn (async) |
| Authentication | Bearer tokens (API keys + anonymous sessions) + Github OAuth |
| Database | PostgreSQL 16 |
| Vector Search | pgvector 0.7 + HNSW index (1024-dim bge-m3 embeddings) |
| Full-Text Search | Tantivy 0.25 (in-process Rust-based search engine) |
| Embedding Model | BAAI/bge-m3 (multilingual, 1024-dim) |
| Reranking | MiniLM-L6-v2 CrossEncoder |
| Async Workers | Celery + Redis 7.2 |
| Caching | Redis 7.2 |
| Migrations | Alembic |
| API Schema | OpenAPI 3.0 + Pydantic |

### Core Components
#### 1. Authentication & Authorization
- **OAuth Flow**: Complete Github OAuth 2.0 implementation with CSRF protection
- **Session Management**: Anonymous sessions + authenticated user sessions
- **Token Types**: Short-lived anonymous tokens, long-lived API tokens
- **Permission System**: Role-based access control (user, admin, system)

#### 2. Query Pipeline
```
User Query → Query Parsing → BM25 Full-Text Search (top 150)
→ Vector Similarity Search (top 150) → RRF Fusion (k=60)
→ CrossEncoder Reranking → Quality Score Blending (0.7×rerank + 0.3×quality)
→ Top N Results → Return to Client
```

#### 3. Contribution Pipeline
```
Experience Submission → Field Validation → Quality Scoring (completeness + relevance)
→ Embedding Generation → FTS Indexing → Vector Indexing → Credit Reward Calculation
→ Store to Database → Return Success to Client
```

#### 4. Feedback Pipeline
```
Feedback Submission → Validation → Update Experience Quality Score
→ Recalculate Search Ranking → Update User Credit Balance → Return Result
```

#### 5. Credit System
- **Earning**: Users earn credits for contributing high-quality experiences
- **Reward Tiers**:
  - Quality score [0, 0.5): 5 credits
  - Quality score [0.5, 0.7): 10 credits
  - Quality score [0.7, 0.85): 25 credits
  - Quality score [0.85, 1.0]: 50 credits
- **Usage**: Planned for premium features, priority support, etc.

---

## API Design
All API endpoints use JSON request/response format, with Bearer token authentication.

### Core Endpoints
| Method | Path | Description | Authentication Required |
|--------|------|-------------|-------------------------|
| POST | `/api/v1/query` | Search experience knowledge base | Yes (user or anonymous) |
| POST | `/api/v1/contribute` | Submit new experience | Yes (user or anonymous) |
| POST | `/api/v1/feedback` | Submit experience feedback | Yes (user or anonymous) |
| GET | `/api/v1/user/me` | Get current user information | Yes (user or anonymous) |
| GET | `/api/v1/auth/github` | Start Github OAuth flow | No |
| GET | `/api/v1/auth/github/callback` | Github OAuth callback | No |
| GET | `/health` | Server health check | No |

Full API documentation available in `docs/API.md`.

---

## Data Model
### Core Entities
#### 1. `experiences`
Stores the actual experience records
- `id`: UUID primary key
- `domain`: Experience domain (coding, devops, etc.)
- `task_type`: Task type (debugging, refactoring, etc.)
- `situation`: Problem description
- `solution`: Solution description
- `outcome_type`: solved|workaround|unresolved
- `lessons`: Key takeaways and learnings
- `failed_approaches`: Approaches that didn't work (optional)
- `environment`: Runtime environment JSON (optional)
- `subdomain`: More specific domain (optional)
- `tags`: Array of tags (optional)
- `language`: Language code (default: en)
- `quality_score`: Float 0-1, calculated automatically
- `user_id`: UUID of contributing user
- `created_at`: Timestamp
- `updated_at`: Timestamp

#### 2. `users`
Stores user account information
- `id`: UUID primary key
- `github_id`: Github user ID (unique)
- `github_login`: Github username
- `display_name`: User display name
- `email`: User email (optional)
- `avatar_url`: Github avatar URL
- `api_token`: Hashed API token
- `credit_balance`: Integer credit balance
- `contribution_count`: Number of experiences contributed
- `created_at`: Timestamp
- `updated_at`: Timestamp

#### 3. `anonymous_sessions`
Stores anonymous session information
- `id`: UUID primary key
- `token_hash`: Hashed session token
- `credit_balance`: Integer credit balance for anonymous user
- `contribution_count`: Number of experiences contributed
- `last_active_at`: Timestamp
- `created_at`: Timestamp
- `expires_at`: Timestamp

Full schema documentation available in `docs/DATA_SCHEMA.md`.

---

## Deployment Architecture
### Production Deployment
```
┌─────────────┐     ┌──────────────────┐     ┌───────────────┐
│  Cloudflare │────►│  Load Balancer   │────►│  API Servers  │
│  (WAF/CDN)  │     │  (Nginx/AWS ALB) │     │  (Uvicorn)    │
└─────────────┘     └──────────────────┘     └───────┬───────┘
                                                       │
                          ┌────────────────────────────┼────────────────────────────┐
                          │                            │                            │
                ┌─────────▼────────┐        ┌────────▼────────┐        ┌──────────▼─────────┐
                │  PostgreSQL 16   │        │  Redis Cluster  │        │  Celery Workers    │
                │  (pgvector + WAL)│        │  (Cache + Queue)│        │  (Async Tasks)     │
                └──────────────────┘        └──────────────────┘        └────────────────────┘
```

### Development Deployment
- Single node PostgreSQL + Redis
- Local API server running on port 8000
- No load balancer or CDN required

---

## Key Architecture Decisions
1. **Pure Client-Server Model**: Removes all local database complexity, ensures all users have access to the same up-to-date knowledge base
2. **Thin Clients**: All intelligence runs on the server, clients are simple wrappers that are easy to maintain and update
3. **Dual Integration Support**: Both MCP and Skill integration methods provide the same functionality, users can choose based on preference
4. **Stateless Clients**: No local data storage except authentication tokens, simplifies sync and backup
5. **Async Server Architecture**: Built for high concurrency and low latency, can handle thousands of simultaneous agent requests
6. **Hybrid Search**: Combines BM25 full-text search and vector semantic search with RRF fusion for optimal result relevance
7. **Automatic Quality Scoring**: Experience quality is scored automatically on submission and updated based on user feedback, no manual curation required
