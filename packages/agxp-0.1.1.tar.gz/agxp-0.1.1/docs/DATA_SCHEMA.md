# AGXP Data Structure Design

> 数据架构设计文档 | 最后更新: 2026-04-06

---

## 目录

1. [数据架构概览](#1-数据架构概览)
2. [ER 图](#2-er-图)
3. [Phase 1 本地表详细字段定义](#3-phase-1-本地表详细字段定义)
4. [Phase 2 服务端表详细字段定义](#4-phase-2-服务端表详细字段定义)
5. [数据流图](#5-数据流图)
6. [增量同步设计](#6-增量同步设计)
7. [数据生命周期](#7-数据生命周期)
8. [数据一致性保障](#8-数据一致性保障)
9. [备份策略](#9-备份策略)
10. [未来扩展](#10-未来扩展)
11. [附录: DDL](#附录-ddl)

---

## 1. 数据架构概览

### 1.1 双层架构设计理念

AGXP 采用 **Phase 1 (本地) + Phase 2 (服务端)** 双层数据架构:

| 维度 | Phase 1 — 本地模式 | Phase 2 — 服务端模式 |
|------|-------------------|---------------------|
| 存储引擎 | SQLite 单文件 (`~/.agxp/local.db`) | PostgreSQL 16 + pgvector |
| 全文搜索 | SQLite FTS5 (BM25) | Tantivy 0.25 (in-process Rust BM25) |
| 向量搜索 | 无 (Agent 自身 LLM 处理语义) | pgvector HNSW (bge-m3, 1024-dim) |
| 用户系统 | 无 (单用户本地工具) | 多用户 (注册用户 + 匿名会话) |
| 积分系统 | 无 | CreditAccount + CreditTransaction |
| 质量评分 | 规则化 completeness scoring | InlineQualityWriter (uniqueness + completeness + community) |
| 部署形态 | pip install agxp[local], 零外部依赖 | pip install agxp[server], 需 PG + Redis |

### 1.2 分层原则

**本地层 (SQLite) 存储的数据:**
- 用户自己的 experiences (私有知识库)
- 搜索日志 search_log (用于 pending feedback 机制)
- FTS5 虚拟表 (BM25 索引, 与 experiences 表自动同步)

**服务端层 (PostgreSQL) 存储的数据:**
- 社区共享 experiences (含向量 embeddings)
- 用户身份 (users, api_keys, anonymous_sessions)
- 积分体系 (credit_accounts, credit_transactions)
- 质量评分细分 (uniqueness/completeness/community scores)
- 搜索反馈 (query_logs, search_feedback, quality_votes)
- 翻译 (experience_translations)

**决策规则:**
- 只在本地使用、无需共享的数据 -> SQLite
- 需要多用户共享、社区评价的数据 -> PostgreSQL
- 搜索索引跟随主存储: 本地用 FTS5, 服务端用 Tantivy + pgvector

### 1.3 两层之间的关系

本地模式和服务端模式是**独立运行**的, 当前不做实时同步:

```
Phase 1 (本地):
  CLI / MCP --> SqliteStore --> FTS5 --> BM25 结果 --> Agent 判断相关性

Phase 2 (服务端):
  HTTP API --> asyncpg --> Celery Workers --> Tantivy + pgvector --> RRF + Reranker --> 结果

未来 Fallback 路径:
  本地搜索结果为空 --> HTTP --> 远程服务器 --> 合并结果
```

本地 experiences 表的核心字段与服务端 experiences 表**保持一致** (domain, task_type, situation, solution, lessons 等), 以便未来实现本地数据上传至服务端共享。

---

## 2. ER 图

### Phase 1 — SQLite 本地模式

```
+-------------------+           +------------------------+
|   experiences     |           |   experiences_fts      |
|-------------------|           |  (FTS5 virtual table)  |
| id          TEXT PK|          |------------------------|
| domain       TEXT |<--trigger-->| situation             |
| subdomain    TEXT |           |  solution              |
| task_type    TEXT |           |  lessons               |
| situation    TEXT |           |  failed_approaches     |
| failed_approaches |           |  tags                  |
| solution     TEXT |           +------------------------+
| outcome_type TEXT |
| lessons      TEXT |
| environment  TEXT |    +-------------------+
| tags         TEXT |    |   search_log      |
| language     TEXT |    |-------------------|
| quality_score REAL|    | id      INTEGER PK|
| created_at   TEXT |    | experience_id TEXT|-----> experiences.id (逻辑关联)
| updated_at   TEXT |    | searched_at  TEXT |
+-------------------+    | feedback_given INT|
                         +-------------------+
```

### Phase 2 — PostgreSQL 服务端模式

```
+----------------+     +----------------+     +---------------------+
|    users       |     |   api_keys     |     | anonymous_sessions  |
|----------------|     |----------------|     |---------------------|
| id       UUID PK|<---| user_id    FK  |     | id            UUID PK|
| email   VARCHAR|     | id       UUID PK|    | temp_key_hash VARCHAR|
| github_id     |     | key_hash      |     | query_count    INT  |
| display_name  |     | label         |     | credit_balance INT  |
| password_hash |     | last_used_at  |     | created_at TIMESTAMPTZ|
| created_at    |     | revoked_at    |     | expires_at TIMESTAMPTZ|
| is_active BOOL|     | created_at    |     | merged_into_user_id FK|
+--------+-------+     +----------------+     +---------------------+
         |
         | 1:N                    1:1
         v                         v
+--------+----------+     +--------+---------+
|   experiences     |     | credit_accounts  |
|-------------------|     |------------------|
| id       UUID PK |     | id       UUID PK |
| user_id    FK --->|     | user_id    FK    |
| agent_type       |     | balance   BIGINT |
| domain  VARCHAR  |     | pending_balance  |
| subdomain        |     | tier     VARCHAR |
| task_type        |     | lifetime_earned  |
| situation  TEXT  |     | lifetime_spent   |
| failed_approaches|     | updated_at       |
| solution   TEXT  |     +--------+---------+
| outcome_type ENUM|              |
| lessons    TEXT  |              | 1:N
| environment JSONB|              v
| tags    TEXT[]   |     +--------+-----------+
| language VARCHAR |     | credit_transactions|
| translation_status|    |--------------------|
| embedding_*  x6  |    | id        UUID PK  |
| quality_score    |     | account_id   FK    |
| uniqueness_score |     | txn_type  VARCHAR  |
| completeness_score|    | amount    BIGINT   |
| community_score  |     | balance_after      |
| upvotes    INT   |     | idempotency_key    |
| downvotes  INT   |     | reference_id UUID  |
| use_count  INT   |     | reference_type     |
| is_published BOOL|     | description  TEXT   |
| created_at       |     | created_at         |
| updated_at       |     +--------------------+
| deleted_at       |
+---+------+-------+
    |      |
    |      | 1:N
    |      v
    |  +---+------------------------+
    |  | experience_translations    |
    |  |----------------------------|
    |  | id          UUID PK        |
    |  | experience_id  FK          |
    |  | language    VARCHAR         |
    |  | situation   TEXT            |
    |  | failed_approaches TEXT      |
    |  | solution    TEXT            |
    |  | lessons     TEXT            |
    |  | translated_at TIMESTAMPTZ  |
    |  +----------------------------+
    |  UNIQUE(experience_id, language)
    |
    +------+--------+
    |      |        |
    v      v        v
+---+---+ +--+---+ +---+----------+
|quality| |query | |search        |
|_votes | |_logs | |_feedback     |
|-------| |------| |--------------|
|id  PK | |id  PK| |id       PK   |
|exp_id | |user_id| |query_log_id FK|
|voter  | |anon_id| |experience_id FK|
| FK    | |agent  | |user_id     FK|
|vote   | |query  | |position  INT |
|SMALL  | |_text  | |was_useful BOOL|
|created| |tried  | |created_at    |
|updated| |filters| +--------------+
+-------+ |search |  UQ(query_log_id,
          |_fields|     experience_id)
          |result |
          |_ids   |
          |query  |
          |_embed |
          |latency|
          |cache  |
          |fallbk |
          |credits|
          |created|
          +-------+
```

---

## 3. Phase 1 本地表详细字段定义

### 3.1 experiences

主表, 存储所有经验记录。每条 experience 代表一次完整的问题解决经历。

| 字段 | 类型 | 约束 | 默认值 | 说明 |
|------|------|------|--------|------|
| id | TEXT | PRIMARY KEY | 应用层生成 UUID v4 | 经验唯一标识, 格式为 UUID v4 字符串 |
| domain | TEXT | NOT NULL | - | 领域分类, 如 "coding", "devops", "data" |
| subdomain | TEXT | 可 NULL | NULL | 子领域, 如 "python", "kubernetes" |
| task_type | TEXT | NOT NULL | - | 任务类型, 如 "debugging", "optimization" |
| situation | TEXT | NOT NULL | - | 问题场景描述 (搜索主字段) |
| failed_approaches | TEXT | 可 NULL | NULL | 尝试过但失败的方法 (质量加分项) |
| solution | TEXT | NOT NULL | - | 最终解决方案 |
| outcome_type | TEXT | NOT NULL, CHECK IN ('solved','workaround','unresolved') | - | 结果类型枚举 |
| lessons | TEXT | NOT NULL | - | 经验教训总结 |
| environment | TEXT | 可 NULL | NULL | 环境信息, 存储为 JSON 字符串 (如 `{"os":"linux","python":"3.11"}`) |
| tags | TEXT | 可 NULL | NULL | 标签列表, 存储为 JSON 数组字符串 (如 `["python","asyncio"]`) |
| language | TEXT | NOT NULL | 'en' | 内容语言, ISO 639-1 编码 |
| quality_score | REAL | NOT NULL | 0.0 | 质量评分 [0.0, 1.0], contribute 时由 completeness scoring 计算 |
| created_at | TEXT | NOT NULL | 应用层生成 ISO 8601 UTC | 创建时间 |
| updated_at | TEXT | NOT NULL | 应用层生成 ISO 8601 UTC | 最后更新时间 |

**质量评分规则** (来自 `agxp/local/scoring.py`):

| 条件 | 加分 |
|------|------|
| 基础分 (必填字段齐全) | +0.50 |
| failed_approaches 非空 | +0.15 |
| environment 非空 dict | +0.10 |
| solution 或 lessons 含数字/百分号 (量化结果) | +0.10 |
| lessons 字数 > 100 | +0.10 |
| tags 数量 >= 3 | +0.05 |
| **合计最高** | **1.00** |

**反馈调整**: 用户通过 `report_feedback` 提供反馈后, quality_score 增量调整:
- useful=true: +0.05
- useful=false: -0.03
- 调整后 clamp 到 [0.0, 1.0]

**注意事项:**
- `environment` 和 `tags` 在 SQLite 中存储为 JSON 字符串, 读取时由 `_row_to_dict()` 反序列化为 Python dict/list
- `id` 由应用层 `uuid.uuid4()` 生成, 不使用 SQLite 的 rowid
- FTS5 触发器通过 `rowid` (SQLite 内部行号) 关联, 非 `id` 列

### 3.2 experiences_fts (FTS5 虚拟表)

FTS5 content-sync 虚拟表, 提供 BM25 全文搜索能力。

| 字段 | 来源列 | 说明 |
|------|--------|------|
| situation | experiences.situation | 问题场景, 搜索权重最高 |
| solution | experiences.solution | 解决方案 |
| lessons | experiences.lessons | 经验教训 |
| failed_approaches | experiences.failed_approaches | 失败方法 (NULL 时以空串填充) |
| tags | experiences.tags | 标签 JSON 字符串 (unicode61 分词器自动提取关键词) |

**配置:**
- `content=experiences` — content-sync 模式, FTS5 不存储原始文本, 从 experiences 表读取
- `content_rowid=rowid` — 使用 experiences 表的 rowid 作为关联键
- `tokenize='unicode61'` — Unicode 分词器, 支持多语言

**触发器同步机制:**

| 触发器 | 事件 | 行为 |
|--------|------|------|
| `experiences_ai` | AFTER INSERT | 将新行的 5 个字段插入 FTS5 索引, NULL 值 COALESCE 为空串 |
| `experiences_ad` | AFTER DELETE | 通过 FTS5 的 'delete' 命令从索引中移除旧行 |
| `experiences_au` | AFTER UPDATE | 先 'delete' 旧行, 再 INSERT 新行 (两步操作) |

**搜索查询:**
```sql
SELECT e.*, bm25(experiences_fts) AS _score
FROM experiences_fts fts
JOIN experiences e ON e.rowid = fts.rowid
WHERE fts.experiences_fts MATCH ?
ORDER BY bm25(experiences_fts), e.quality_score DESC
LIMIT ?
```

- 用户输入经过 `_escape_fts5_query()` 转义: 每个 token 用双引号包裹, 以 OR 连接
- BM25 分数越小越相关 (负值), 作为主排序; quality_score 作为次排序

### 3.3 search_log

搜索日志表, 用于实现 pending feedback 机制 (Issue #25)。当用户搜索后, 记录返回的 experience_id; 下次搜索时, 提示用户对之前使用过的经验给予反馈。

| 字段 | 类型 | 约束 | 默认值 | 说明 |
|------|------|------|--------|------|
| id | INTEGER | PRIMARY KEY AUTOINCREMENT | 自增 | 日志唯一标识 |
| experience_id | TEXT | NOT NULL | - | 关联的经验 ID (逻辑外键, 指向 experiences.id) |
| searched_at | TEXT | NOT NULL | 应用层生成 ISO 8601 UTC | 搜索发生时间 |
| feedback_given | INTEGER | NOT NULL | 0 | 是否已给反馈: 0=未反馈, 1=已反馈 |

**注意事项:**
- `experience_id` 没有物理外键约束 (SQLite 不强制), 但 `get_pending_feedback()` 通过 JOIN experiences 排除已删除的经验
- 过期清理: `cleanup_expired_search_log()` 删除 searched_at 超过 24 小时的记录
- 同一个 experience_id 可能出现多次 (多次搜索均返回该经验)

---

## 4. Phase 2 服务端表详细字段定义

### 4.1 users

用户身份表, 支持邮箱注册和 GitHub OAuth 登录。

| 字段 | 类型 | 约束 | 默认值 | 说明 |
|------|------|------|--------|------|
| id | UUID | PRIMARY KEY | `gen_random_uuid()` | 用户唯一标识 |
| email | VARCHAR(256) | UNIQUE, 可 NULL | NULL | 邮箱地址 (邮箱注册时必填) |
| github_id | VARCHAR(64) | UNIQUE, 可 NULL | NULL | GitHub 用户 ID (OAuth 登录时填充) |
| display_name | VARCHAR(256) | 可 NULL | NULL | 显示名称 |
| password_hash | VARCHAR(128) | 可 NULL | NULL | 密码哈希 (bcrypt, 邮箱注册时使用) |
| created_at | TIMESTAMPTZ | NOT NULL | `now()` | 注册时间 |
| is_active | BOOLEAN | NOT NULL | true | 账户是否激活 |

**关联关系:**
- 1:N -> api_keys (一个用户可有多个 API key)
- 1:1 -> credit_accounts (一个用户一个积分账户)
- 1:N -> experiences (一个用户可贡献多条经验)

### 4.2 api_keys

API 密钥表, 用于 Bearer token 认证。

| 字段 | 类型 | 约束 | 默认值 | 说明 |
|------|------|------|--------|------|
| id | UUID | PRIMARY KEY | `gen_random_uuid()` | 密钥记录唯一标识 |
| user_id | UUID | NOT NULL, FK -> users.id ON DELETE CASCADE | - | 所属用户 |
| key_hash | VARCHAR(128) | NOT NULL, UNIQUE | - | API key 的 SHA-256 哈希 (不存储明文) |
| label | VARCHAR(128) | 可 NULL | NULL | 用户给密钥起的标签名 |
| last_used_at | TIMESTAMPTZ | 可 NULL | NULL | 最后使用时间 |
| revoked_at | TIMESTAMPTZ | 可 NULL | NULL | 吊销时间 (非空表示已吊销) |
| created_at | TIMESTAMPTZ | NOT NULL | `now()` | 创建时间 |

**索引:**
- `api_keys_user_id` — B-tree on (user_id)

### 4.3 anonymous_sessions

匿名会话表, 为未注册用户提供有限的查询能力。

| 字段 | 类型 | 约束 | 默认值 | 说明 |
|------|------|------|--------|------|
| id | UUID | PRIMARY KEY | `gen_random_uuid()` | 会话唯一标识 |
| temp_key_hash | VARCHAR(128) | NOT NULL, UNIQUE | - | 临时 key 的哈希 |
| query_count | INTEGER | NOT NULL | 0 | 已使用的查询次数 |
| credit_balance | INTEGER | NOT NULL | 20 | 剩余积分 (匿名用户初始 20) |
| created_at | TIMESTAMPTZ | NOT NULL | `now()` | 创建时间 |
| expires_at | TIMESTAMPTZ | NOT NULL | - | 过期时间 (应用层设为 created_at + 30 天) |
| merged_into_user_id | UUID | 可 NULL, FK -> users.id | NULL | 转正后合并到的用户 ID |

### 4.4 experiences (PostgreSQL 版本)

服务端经验表, 相比本地版本增加了向量 embeddings、多维质量评分和社区投票字段。

| 字段 | 类型 | 约束 | 默认值 | 说明 |
|------|------|------|--------|------|
| id | UUID | PRIMARY KEY | `gen_random_uuid()` | 经验唯一标识 |
| user_id | UUID | NOT NULL, FK -> users.id | - | 贡献者用户 ID |
| agent_type | VARCHAR(64) | 可 NULL | NULL | 贡献的 Agent 类型 (如 "claude", "gpt-4") |
| domain | VARCHAR(64) | NOT NULL | - | 领域分类 |
| subdomain | VARCHAR(64) | 可 NULL | NULL | 子领域 |
| task_type | VARCHAR(64) | NOT NULL | - | 任务类型 |
| situation | TEXT | NOT NULL | - | 问题场景描述 |
| failed_approaches | TEXT | 可 NULL | NULL | 失败方法 |
| solution | TEXT | NOT NULL | - | 解决方案 |
| outcome_type | ENUM('solved','workaround','unresolved') | NOT NULL | - | 结果类型 |
| lessons | TEXT | NOT NULL | - | 经验教训 |
| environment | JSONB | 可 NULL | NULL | 环境信息 (原生 JSONB) |
| tags | TEXT[] (ARRAY) | NOT NULL | '{}' | 标签数组 (原生 PostgreSQL 数组) |
| language | VARCHAR(8) | NOT NULL | 'en' | 内容语言 |
| translation_status | VARCHAR(16) | NOT NULL | 'not_needed' | 翻译状态 |
| embedding_situation | vector(1024) | 可 NULL | NULL | situation 字段的 bge-m3 向量 |
| embedding_solution | vector(1024) | 可 NULL | NULL | solution 字段的向量 |
| embedding_lessons | vector(1024) | 可 NULL | NULL | lessons 字段的向量 |
| embedding_failed | vector(1024) | 可 NULL | NULL | failed_approaches 字段的向量 |
| embedding_tags | vector(1024) | 可 NULL | NULL | tags 字段的向量 |
| embedding_environment | vector(1024) | 可 NULL | NULL | environment 字段的向量 |
| quality_score | FLOAT | NOT NULL | 0.0 | 综合质量评分 |
| uniqueness_score | FLOAT | 可 NULL | NULL | 唯一性评分 (Celery 异步计算) |
| completeness_score | FLOAT | 可 NULL | NULL | 完整性评分 |
| community_score | FLOAT | 可 NULL | NULL | 社区评分 (基于 upvotes/downvotes) |
| upvotes | INTEGER | NOT NULL | 0 | 点赞数 |
| downvotes | INTEGER | NOT NULL | 0 | 踩数 |
| use_count | INTEGER | NOT NULL | 0 | 被搜索命中并使用的次数 |
| is_published | BOOLEAN | NOT NULL | false | 是否公开发布 |
| created_at | TIMESTAMPTZ | NOT NULL | `now()` | 创建时间 |
| updated_at | TIMESTAMPTZ | NOT NULL | `now()` | 最后更新时间 (ON UPDATE 自动刷新) |
| deleted_at | TIMESTAMPTZ | 可 NULL | NULL | 软删除时间 (非空表示已删除) |

**B-tree 索引:**

| 索引名 | 列 | 条件 (partial) | 说明 |
|--------|---|----------------|------|
| exp_user_id | user_id | - | 按用户查询 |
| exp_domain_task | domain, task_type | `deleted_at IS NULL AND is_published = true` | 按领域+任务过滤 |
| exp_language | language | `deleted_at IS NULL` | 按语言过滤 |
| exp_subdomain | subdomain | `deleted_at IS NULL AND subdomain IS NOT NULL` | 按子领域过滤 |
| exp_quality | quality_score DESC | `deleted_at IS NULL AND is_published = true` | 按质量排序 |
| exp_use_count | use_count DESC | `deleted_at IS NULL AND is_published = true` | 按使用次数排序 |
| exp_created_at | created_at DESC | `deleted_at IS NULL` | 按创建时间排序 |

**HNSW 向量索引:**

| 索引名 | 列 | 参数 |
|--------|---|------|
| exp_hnsw_situation | embedding_situation | m=16, ef_construction=64, vector_cosine_ops |
| exp_hnsw_solution | embedding_solution | 同上 |
| exp_hnsw_lessons | embedding_lessons | 同上 |
| exp_hnsw_failed | embedding_failed | 同上 |
| exp_hnsw_tags | embedding_tags | 同上 |
| exp_hnsw_environment | embedding_environment | 同上 |

### 4.5 experience_translations

经验翻译表, 存储同一经验的多语言翻译版本。

| 字段 | 类型 | 约束 | 默认值 | 说明 |
|------|------|------|--------|------|
| id | UUID | PRIMARY KEY | `gen_random_uuid()` | 翻译记录唯一标识 |
| experience_id | UUID | NOT NULL, FK -> experiences.id ON DELETE CASCADE | - | 原始经验 ID |
| language | VARCHAR(8) | NOT NULL | - | 目标语言 |
| situation | TEXT | 可 NULL | NULL | 翻译后的场景描述 |
| failed_approaches | TEXT | 可 NULL | NULL | 翻译后的失败方法 |
| solution | TEXT | 可 NULL | NULL | 翻译后的解决方案 |
| lessons | TEXT | 可 NULL | NULL | 翻译后的经验教训 |
| translated_at | TIMESTAMPTZ | 可 NULL | NULL | 翻译完成时间 |

**唯一约束:** `uq_experience_translations_exp_lang` — UNIQUE(experience_id, language)

### 4.6 credit_accounts

积分账户表, 每个注册用户一个积分账户。

| 字段 | 类型 | 约束 | 默认值 | 说明 |
|------|------|------|--------|------|
| id | UUID | PRIMARY KEY | `gen_random_uuid()` | 账户唯一标识 |
| user_id | UUID | NOT NULL, FK -> users.id, UNIQUE | - | 所属用户 (一对一) |
| balance | BIGINT | NOT NULL | 0 | 当前可用余额 |
| pending_balance | BIGINT | NOT NULL | 0 | 待结算余额 (质量评分完成前冻结) |
| tier | VARCHAR(16) | NOT NULL | 'free' | 用户等级 (free / premium) |
| lifetime_earned | BIGINT | NOT NULL | 0 | 累计获得积分 |
| lifetime_spent | BIGINT | NOT NULL | 0 | 累计消耗积分 |
| updated_at | TIMESTAMPTZ | NOT NULL | `now()` | 最后更新时间 |

**积分奖励规则** (基于 quality_score):

| quality_score 区间 | 奖励积分 |
|-------------------|---------|
| [0, 0.5) | 5 |
| [0.5, 0.7) | 10 |
| [0.7, 0.85) | 25 |
| [0.85, 1.0] | 50 |

### 4.7 credit_transactions

积分交易流水表, 不可变 (append-only)。

| 字段 | 类型 | 约束 | 默认值 | 说明 |
|------|------|------|--------|------|
| id | UUID | PRIMARY KEY | `gen_random_uuid()` | 交易唯一标识 |
| account_id | UUID | NOT NULL, FK -> credit_accounts.id | - | 所属积分账户 |
| txn_type | VARCHAR(32) | NOT NULL | - | 交易类型 (如 "contribute_reward", "query_spend") |
| amount | BIGINT | NOT NULL | - | 交易金额 (正数=收入, 负数=支出) |
| balance_after | BIGINT | NOT NULL | - | 交易后余额 (快照, 用于审计) |
| idempotency_key | VARCHAR(128) | UNIQUE, 可 NULL | NULL | 幂等键 (防重复交易) |
| reference_id | UUID | 可 NULL | NULL | 关联对象 ID (如 experience_id) |
| reference_type | VARCHAR(32) | 可 NULL | NULL | 关联对象类型 (如 "experience", "query") |
| description | TEXT | 可 NULL | NULL | 交易描述 |
| created_at | TIMESTAMPTZ | NOT NULL | `now()` | 交易时间 |

**索引:**
- `credit_txn_account_created` — B-tree on (account_id, created_at)

### 4.8 quality_votes

社区质量投票表, 用户对经验进行赞/踩。

| 字段 | 类型 | 约束 | 默认值 | 说明 |
|------|------|------|--------|------|
| id | UUID | PRIMARY KEY | `gen_random_uuid()` | 投票记录唯一标识 |
| experience_id | UUID | NOT NULL, FK -> experiences.id | - | 被投票的经验 |
| voter_user_id | UUID | NOT NULL, FK -> users.id | - | 投票用户 |
| vote | SMALLINT | NOT NULL, CHECK IN (-1, 1) | - | 投票值: 1=赞, -1=踩 |
| created_at | TIMESTAMPTZ | NOT NULL | `now()` | 创建时间 |
| updated_at | TIMESTAMPTZ | NOT NULL | `now()` | 更新时间 (改票时刷新) |

**唯一约束:** `uq_quality_votes_exp_user` — UNIQUE(experience_id, voter_user_id)
- 每个用户对每条经验只能有一票, 可以修改 (update vote)

### 4.9 query_logs

查询日志表, 记录每次搜索请求的完整上下文。

| 字段 | 类型 | 约束 | 默认值 | 说明 |
|------|------|------|--------|------|
| id | UUID | PRIMARY KEY | `gen_random_uuid()` | 查询唯一标识 |
| user_id | UUID | 可 NULL, FK -> users.id | NULL | 查询用户 (注册用户) |
| anon_session_id | UUID | 可 NULL, FK -> anonymous_sessions.id | NULL | 查询会话 (匿名用户) |
| agent_type | VARCHAR(64) | 可 NULL | NULL | Agent 类型 |
| query_text | TEXT | NOT NULL | - | 原始查询文本 |
| query_language | VARCHAR(8) | 可 NULL | NULL | 查询语言 |
| tried_text | TEXT | 可 NULL | NULL | 用户描述的已尝试方法 |
| filters | JSONB | 可 NULL | NULL | 过滤条件 |
| search_fields | JSONB | 可 NULL | NULL | 搜索字段配置 |
| result_ids | UUID[] (ARRAY) | 可 NULL | NULL | 返回的经验 ID 列表 |
| query_embedding | vector(1024) | 可 NULL | NULL | 查询文本的向量 (用于缓存和分析) |
| latency_ms | INTEGER | 可 NULL | NULL | 查询耗时 (毫秒) |
| cache_hit_level | VARCHAR(4) | 可 NULL | NULL | 缓存命中级别 (如 "L1", "L2") |
| fallback_level | SMALLINT | 可 NULL | 0 | 降级级别 (0=正常, 1+=逐级降级) |
| credits_spent | INTEGER | NOT NULL | 1 | 本次查询消耗积分 |
| created_at | TIMESTAMPTZ | NOT NULL | `now()` | 查询时间 |

**索引:**
- `query_logs_user_created` — B-tree on (user_id, created_at) WHERE user_id IS NOT NULL
- `query_logs_created_at` — B-tree on (created_at)

### 4.10 search_feedback

搜索反馈表, 记录用户对搜索结果中每条经验的有用性评价。

| 字段 | 类型 | 约束 | 默认值 | 说明 |
|------|------|------|--------|------|
| id | UUID | PRIMARY KEY | `gen_random_uuid()` | 反馈记录唯一标识 |
| query_log_id | UUID | NOT NULL, FK -> query_logs.id | - | 关联的查询日志 |
| experience_id | UUID | NOT NULL, FK -> experiences.id | - | 被评价的经验 |
| user_id | UUID | 可 NULL, FK -> users.id | NULL | 反馈用户 |
| position | SMALLINT | NOT NULL | - | 结果列表中的位置（1-based，范围 1-20） |
| was_useful | BOOLEAN | NOT NULL | - | 是否有用 |
| created_at | TIMESTAMPTZ | NOT NULL | `now()` | 反馈时间 |

**约束:**
- `uq_search_feedback_query_exp` — UNIQUE(query_log_id, experience_id): 同一次查询对同一条经验只能反馈一次

**索引:**
- `search_feedback_exp_created` — B-tree on (experience_id, created_at)

---

## 5. 数据流图

### 5.1 本地模式数据流

```
                        Contribute 流程
                        ==============
CLI (agxp contribute)          MCP (contribute_experience tool)
        |                              |
        v                              v
+-------+------------------------------+-------+
|           SqliteStore.contribute()            |
|  1. uuid4() 生成 ID                           |
|  2. compute_completeness_score() 计算质量分    |
|  3. JSON 序列化 environment, tags              |
|  4. INSERT INTO experiences                    |
|  5. [自动] FTS5 触发器 experiences_ai 同步索引  |
+-----------------------------------------------+


                        Query 流程
                        ==========
CLI (agxp query)               MCP (search_experiences tool)
        |                              |
        v                              v
+-------+------------------------------+-------+
|            SqliteStore.query()                 |
|  1. cleanup_expired_search_log() 清理过期日志  |
|  2. _escape_fts5_query() 转义用户输入          |
|  3. 构建 WHERE (hardcoded whitelist 过滤)      |
|  4. FTS5 MATCH + BM25 排序 + quality_score     |
|  5. get_pending_feedback() 读取待反馈列表      |
|  6. log_search_results() 记录本次搜索结果      |
|  7. 返回 {results, pending_feedback, hint}     |
+-----------------------------------------------+
        |
        v
  Agent LLM 判断相关性, 选择最佳结果


                     Feedback 流程
                     =============
MCP (report_feedback tool)
        |
        v
+-------+------------------------------+
|  1. update_quality_score(id, delta)  |
|     useful: +0.05 / not_useful: -0.03|
|  2. mark_feedback_given(id)          |
+--------------------------------------+
```

### 5.2 服务端数据流

```
                     Contribute 流程
                     ==============
POST /api/v1/contribute
        |
        v
+-------+---------------------+
|  Auth middleware             |
|  (Bearer token -> user_id)  |
+-------+---------------------+
        |
        v
+-------+---------------------+
|  asyncpg: INSERT experience |
|  (is_published=false)       |
+-------+---------------------+
        |
        v
+-------+---------------------+
|  Celery task: score_quality |
|  1. BgeM3 生成 6 个向量     |
|  2. 计算 uniqueness_score   |
|  3. 计算 completeness_score |
|  4. 更新 quality_score      |
|  5. 积分奖励 (based on tier)|
|  6. is_published = true     |
+-----------------------------+


                       Query 流程
                       ==========
POST /api/v1/query
        |
        v
+-------+---------------------------+
|  Auth -> 扣积分 (credits_spent=1) |
+-------+---------------------------+
        |
        v
+-------+---------------------------+
|  Pipeline.run():                  |
|  1. BgeM3 embed query_text       |
|  2. pgvector HNSW 搜索 (top-150) |
|  3. Tantivy BM25 搜索 (top-150)  |
|  4. RRF 融合 (k=60)              |
|  5. MiniLM CrossEncoder rerank   |
|  6. Quality blend:               |
|     0.7 * reranker + 0.3 * quality|
|  7. LIMIT 应用                    |
+-------+---------------------------+
        |
        v
  记录 query_logs, 返回结果
```

### 5.3 Fallback 数据流 (未来)

```
agxp query "asyncio memory leak"
        |
        v
  SqliteStore.query() -> 本地搜索
        |
        +-- 有结果 --> 返回本地结果
        |
        +-- 结果为空 / 质量低 -->
                |
                v
          HTTP POST /api/v1/query (远程服务器)
                |
                v
          合并远程结果, 缓存到本地 search_log
                |
                v
          返回合并结果给 Agent
```

---

## 6. 增量同步设计

### 6.1 search_log 状态机 (Phase 1)

```
                  搜索触发
                     |
                     v
         +---------------------+
         | feedback_given = 0  |  <-- 初始状态
         | (待反馈)             |
         +----------+----------+
                    |
         +----------+----------+
         |                     |
    用户反馈              24h 过期
         |                     |
         v                     v
+--------+--------+   +--------+--------+
| feedback_given=1|   |    DELETE       |
| (已反馈)         |   | (过期清理)      |
+-----------------+   +-----------------+
```

**状态转换:**

| 当前状态 | 触发条件 | 目标状态 | 操作 |
|---------|---------|---------|------|
| feedback_given=0 | 用户调用 report_feedback | feedback_given=1 | `mark_feedback_given()` 批量更新该 experience_id 的所有记录 |
| feedback_given=0 | searched_at 超过 24h | 删除 | `cleanup_expired_search_log()` 在每次 query 时自动执行 |
| feedback_given=1 | searched_at 超过 24h | 删除 | 同上 (已反馈的过期记录也删除) |

### 6.2 Pending feedback 读取逻辑

```sql
SELECT DISTINCT sl.experience_id, e.situation
FROM search_log sl
JOIN experiences e ON e.id = sl.experience_id   -- 排除已删除的 experience
WHERE sl.feedback_given = 0
  AND sl.searched_at >= ?  -- 24h 内
ORDER BY sl.searched_at DESC
LIMIT 5
```

- JOIN experiences 确保只返回仍然存在的经验
- DISTINCT 去重 (同一经验可能在多次搜索中出现)
- 最多返回 5 条, 按最近搜索时间排序

---

## 7. 数据生命周期

### 7.1 experiences 生命周期

**Phase 1 (本地):**
```
created (contribute)
   |
   +--> quality_score 初始化 (completeness scoring)
   |
   +--> 被搜索命中 (query)
   |       |
   |       +--> search_log 记录
   |       |
   |       +--> feedback 调整 quality_score (+0.05 / -0.03)
   |
   +--> [可选] 删除 (delete) -- 触发 FTS5 'delete' 同步
```

**Phase 2 (服务端):**
```
created (contribute, is_published=false)
   |
   +--> Celery: 生成 embeddings (6 个向量)
   |
   +--> Celery: 计算 quality_score (uniqueness + completeness)
   |
   +--> is_published = true, 积分奖励
   |
   +--> 被搜索命中 (use_count++)
   |       |
   |       +--> query_logs 记录
   |       |
   |       +--> search_feedback 记录
   |       |
   |       +--> quality_votes (upvote/downvote)
   |       |
   |       +--> community_score 更新
   |
   +--> [可选] 翻译 (experience_translations)
   |
   +--> [可选] 软删除 (deleted_at 设为当前时间)
```

### 7.2 search_log 生命周期 (Phase 1)

```
created (log_search_results)
   |
   +--> 24h 内: get_pending_feedback() 可读取
   |       |
   |       +--> report_feedback() -> feedback_given = 1
   |
   +--> 24h 后: cleanup_expired_search_log() 删除
```

- TTL: 24 小时 (硬编码, 通过 `max_age_hours` 参数可调)
- 清理时机: 每次 `query()` 调用时自动触发

### 7.3 credit_transactions 生命周期 (Phase 2)

```
created (contribute_reward / query_spend / ...)
   |
   +--> 永久保留 (append-only, 不可修改, 不可删除)
   |
   +--> 用于审计: balance_after 快照确保可追溯
```

- credit_transactions 是 **不可变的 append-only 日志**
- 每笔交易记录 balance_after 快照, 可独立重建任意时刻的余额
- idempotency_key 防止重复交易

---

## 8. 数据一致性保障

### 8.1 SQL 注入防护

**Phase 1 (SQLite):**
- 列名过滤: `_ALLOWED_FILTERS = {"domain", "task_type"}` 硬编码白名单, 未知 key 静默忽略
- 值参数: 全部使用 `?` 占位符, 通过 `sqlite3.execute(sql, params)` 传入
- FTS5 查询: `_escape_fts5_query()` 对用户输入逐 token 双引号包裹, 防止 FTS5 语法注入

**Phase 2 (PostgreSQL):**
- 列名: 同样使用硬编码白名单
- 值参数: 使用 asyncpg 的 `$1, $2, ...` 位置参数
- JSONB: 通过 `json.dumps()` 序列化, 不拼接 SQL

### 8.2 FTS5 触发器同步 (Phase 1)

三个触发器确保 `experiences_fts` 与 `experiences` 表始终同步:
- INSERT: `experiences_ai` 触发器自动索引新行
- DELETE: `experiences_ad` 触发器自动从索引移除
- UPDATE: `experiences_au` 触发器先删除旧索引再插入新索引

NULL 值处理: `COALESCE(new.failed_approaches, '')` 和 `COALESCE(new.tags, '')` 确保 FTS5 不接收 NULL。

### 8.3 search_log 一致性 (Phase 1)

- `get_pending_feedback()` 通过 `JOIN experiences e ON e.id = sl.experience_id` 排除已删除的经验
- 即使 search_log 中的 experience_id 指向一个已删除的 experience, JOIN 会自动过滤掉

### 8.4 PostgreSQL 约束 (Phase 2)

**外键约束:**
- `api_keys.user_id` -> users.id (ON DELETE CASCADE)
- `experience_translations.experience_id` -> experiences.id (ON DELETE CASCADE)
- `credit_transactions.account_id` -> credit_accounts.id
- `quality_votes.experience_id` -> experiences.id
- `quality_votes.voter_user_id` -> users.id
- `search_feedback.query_log_id` -> query_logs.id
- `search_feedback.experience_id` -> experiences.id

**CHECK 约束:**
- `quality_votes.vote IN (-1, 1)` — 只允许赞(1)和踩(-1)

**UNIQUE 约束:**
- `users.email` — 邮箱唯一
- `users.github_id` — GitHub ID 唯一
- `api_keys.key_hash` — API key 哈希唯一
- `anonymous_sessions.temp_key_hash` — 临时 key 唯一
- `credit_accounts.user_id` — 一个用户一个积分账户
- `credit_transactions.idempotency_key` — 幂等键唯一
- `uq_experience_translations_exp_lang` — 同一经验同一语言只有一个翻译
- `uq_quality_votes_exp_user` — 同一用户对同一经验只能投一票
- `uq_search_feedback_query_exp` — 同一查询对同一经验只能反馈一次

### 8.5 软删除策略 (Phase 2)

- experiences 表使用 `deleted_at` 软删除, 非 NULL 表示已删除
- 所有 partial index 都包含 `WHERE deleted_at IS NULL` 条件
- 查询时自动排除已删除记录

---

## 9. 备份策略

### 9.1 本地模式 (SQLite)

```bash
# 方法 1: 直接复制 (WAL 模式下需要同时复制 .db, .db-wal, .db-shm)
cp ~/.agxp/local.db ~/.agxp/local.db.bak
cp ~/.agxp/local.db-wal ~/.agxp/local.db-wal.bak 2>/dev/null
cp ~/.agxp/local.db-shm ~/.agxp/local.db-shm.bak 2>/dev/null

# 方法 2: 使用 SQLite 在线备份 API (推荐, 保证一致性)
sqlite3 ~/.agxp/local.db ".backup '/path/to/backup.db'"

# 方法 3: rclone 上传到 Google Drive
rclone copy ~/.agxp/local.db gdrive:agxp-backup/
```

- 单文件架构使备份极其简单
- FTS5 虚拟表数据内嵌在同一个 `.db` 文件中, 无需额外处理
- 建议在 contribute 操作后定期备份

### 9.2 服务端模式 (PostgreSQL)

```bash
# 逻辑备份 (推荐用于小规模部署)
pg_dump -h localhost -p 5433 -U agxp agxp_db > agxp_backup.sql

# 增量备份: WAL archiving
# postgresql.conf:
#   wal_level = replica
#   archive_mode = on
#   archive_command = 'cp %p /path/to/wal_archive/%f'

# pgvector 索引备份:
# HNSW 索引包含在 pg_dump 中, 恢复后需要 REINDEX
```

- credit_transactions 为 append-only, 可作为审计依据
- 建议每日全量备份 + 持续 WAL 归档

---

## 10. 未来扩展

### 10.1 search_log 增加 source 列

当 Fallback 功能上线后, search_log 需要区分结果来源:

```sql
ALTER TABLE search_log ADD COLUMN source TEXT NOT NULL DEFAULT 'local';
-- source IN ('local', 'remote')
```

这样 pending feedback 可以区分本地搜索结果和远程搜索结果。

### 10.2 本地可选 embedding

`pip install agxp[embed]` 安装后 (+50MB ONNX runtime), 本地模式可启用向量搜索:

- experiences 表新增 `embedding_combined vector(384)` 列 (使用轻量模型)
- 搜索策略: BM25 + cosine similarity, RRF 融合
- 兼容: 无 embedding 时退回纯 BM25

### 10.3 本地 -> 服务端数据同步

未来可能增加的同步机制:
- `agxp push` 命令: 将本地 experiences 上传到服务端 (需要注册账号)
- 上传时服务端重新计算 embeddings 和 quality_score
- `experiences.id` 使用 UUID v4, 天然适合分布式 ID, 不会冲突

### 10.4 搜索分析扩展

服务端 query_logs 表已经记录了丰富的搜索上下文:
- `query_embedding` 可用于查询聚类分析 (发现热门话题)
- `latency_ms` + `cache_hit_level` 可用于性能监控
- `fallback_level` 可追踪降级频率

---

## 附录: DDL

### A.1 Phase 1 — SQLite DDL

```sql
-- experiences 主表
CREATE TABLE IF NOT EXISTS experiences (
    id TEXT PRIMARY KEY,
    domain TEXT NOT NULL,
    subdomain TEXT,
    task_type TEXT NOT NULL,
    situation TEXT NOT NULL,
    failed_approaches TEXT,
    solution TEXT NOT NULL,
    outcome_type TEXT NOT NULL CHECK(outcome_type IN ('solved','workaround','unresolved')),
    lessons TEXT NOT NULL,
    environment TEXT,
    tags TEXT,
    language TEXT NOT NULL DEFAULT 'en',
    quality_score REAL NOT NULL DEFAULT 0.0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- FTS5 全文搜索虚拟表
CREATE VIRTUAL TABLE IF NOT EXISTS experiences_fts USING fts5(
    situation, solution, lessons, failed_approaches, tags,
    content=experiences, content_rowid=rowid,
    tokenize='unicode61'
);

-- FTS5 同步触发器: INSERT
CREATE TRIGGER IF NOT EXISTS experiences_ai AFTER INSERT ON experiences BEGIN
    INSERT INTO experiences_fts(rowid, situation, solution, lessons, failed_approaches, tags)
    VALUES (new.rowid, new.situation, new.solution, new.lessons,
            COALESCE(new.failed_approaches, ''),
            COALESCE(new.tags, ''));
END;

-- FTS5 同步触发器: DELETE
CREATE TRIGGER IF NOT EXISTS experiences_ad AFTER DELETE ON experiences BEGIN
    INSERT INTO experiences_fts(experiences_fts, rowid, situation, solution, lessons, failed_approaches, tags)
    VALUES ('delete', old.rowid, old.situation, old.solution, old.lessons,
            COALESCE(old.failed_approaches, ''),
            COALESCE(old.tags, ''));
END;

-- FTS5 同步触发器: UPDATE
CREATE TRIGGER IF NOT EXISTS experiences_au AFTER UPDATE ON experiences BEGIN
    INSERT INTO experiences_fts(experiences_fts, rowid, situation, solution, lessons, failed_approaches, tags)
    VALUES ('delete', old.rowid, old.situation, old.solution, old.lessons,
            COALESCE(old.failed_approaches, ''),
            COALESCE(old.tags, ''));
    INSERT INTO experiences_fts(rowid, situation, solution, lessons, failed_approaches, tags)
    VALUES (new.rowid, new.situation, new.solution, new.lessons,
            COALESCE(new.failed_approaches, ''),
            COALESCE(new.tags, ''));
END;

-- 搜索日志表
CREATE TABLE IF NOT EXISTS search_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    experience_id TEXT NOT NULL,
    searched_at TEXT NOT NULL,
    feedback_given INTEGER NOT NULL DEFAULT 0
);

-- PRAGMA 设置 (连接时执行)
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
```

### A.2 Phase 2 — PostgreSQL DDL (Alembic 生成)

```sql
-- 扩展
CREATE EXTENSION IF NOT EXISTS vector;

-- users
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(256) UNIQUE,
    github_id VARCHAR(64) UNIQUE,
    display_name VARCHAR(256),
    password_hash VARCHAR(128),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    is_active BOOLEAN NOT NULL DEFAULT true
);

-- api_keys
CREATE TABLE api_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    key_hash VARCHAR(128) NOT NULL UNIQUE,
    label VARCHAR(128),
    last_used_at TIMESTAMPTZ,
    revoked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX api_keys_user_id ON api_keys(user_id);

-- anonymous_sessions
CREATE TABLE anonymous_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    temp_key_hash VARCHAR(128) NOT NULL UNIQUE,
    query_count INTEGER NOT NULL DEFAULT 0,
    credit_balance INTEGER NOT NULL DEFAULT 20,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at TIMESTAMPTZ NOT NULL,
    merged_into_user_id UUID REFERENCES users(id)
);

-- credit_accounts
CREATE TABLE credit_accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL UNIQUE REFERENCES users(id),
    balance BIGINT NOT NULL DEFAULT 0,
    pending_balance BIGINT NOT NULL DEFAULT 0,
    tier VARCHAR(16) NOT NULL DEFAULT 'free',
    lifetime_earned BIGINT NOT NULL DEFAULT 0,
    lifetime_spent BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- experiences
CREATE TABLE experiences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    agent_type VARCHAR(64),
    domain VARCHAR(64) NOT NULL,
    subdomain VARCHAR(64),
    task_type VARCHAR(64) NOT NULL,
    situation TEXT NOT NULL,
    failed_approaches TEXT,
    solution TEXT NOT NULL,
    outcome_type outcome_type NOT NULL,  -- ENUM('solved','workaround','unresolved')
    lessons TEXT NOT NULL,
    environment JSONB,
    tags TEXT[] NOT NULL DEFAULT '{}',
    language VARCHAR(8) NOT NULL DEFAULT 'en',
    translation_status VARCHAR(16) NOT NULL DEFAULT 'not_needed',
    embedding_situation vector(1024),
    embedding_solution vector(1024),
    embedding_lessons vector(1024),
    embedding_failed vector(1024),
    embedding_tags vector(1024),
    embedding_environment vector(1024),
    quality_score FLOAT NOT NULL DEFAULT 0.0,
    uniqueness_score FLOAT,
    completeness_score FLOAT,
    community_score FLOAT,
    upvotes INTEGER NOT NULL DEFAULT 0,
    downvotes INTEGER NOT NULL DEFAULT 0,
    use_count INTEGER NOT NULL DEFAULT 0,
    is_published BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ
);

-- experiences B-tree indexes (partial)
CREATE INDEX exp_user_id ON experiences(user_id);
CREATE INDEX exp_domain_task ON experiences(domain, task_type) WHERE deleted_at IS NULL AND is_published = true;
CREATE INDEX exp_language ON experiences(language) WHERE deleted_at IS NULL;
CREATE INDEX exp_subdomain ON experiences(subdomain) WHERE deleted_at IS NULL AND subdomain IS NOT NULL;
CREATE INDEX exp_quality ON experiences(quality_score DESC) WHERE deleted_at IS NULL AND is_published = true;
CREATE INDEX exp_use_count ON experiences(use_count DESC) WHERE deleted_at IS NULL AND is_published = true;
CREATE INDEX exp_created_at ON experiences(created_at DESC) WHERE deleted_at IS NULL;

-- experiences HNSW vector indexes
CREATE INDEX exp_hnsw_situation ON experiences USING hnsw (embedding_situation vector_cosine_ops) WITH (m = 16, ef_construction = 64);
CREATE INDEX exp_hnsw_solution ON experiences USING hnsw (embedding_solution vector_cosine_ops) WITH (m = 16, ef_construction = 64);
CREATE INDEX exp_hnsw_lessons ON experiences USING hnsw (embedding_lessons vector_cosine_ops) WITH (m = 16, ef_construction = 64);
CREATE INDEX exp_hnsw_failed ON experiences USING hnsw (embedding_failed vector_cosine_ops) WITH (m = 16, ef_construction = 64);
CREATE INDEX exp_hnsw_tags ON experiences USING hnsw (embedding_tags vector_cosine_ops) WITH (m = 16, ef_construction = 64);
CREATE INDEX exp_hnsw_environment ON experiences USING hnsw (embedding_environment vector_cosine_ops) WITH (m = 16, ef_construction = 64);

-- experience_translations
CREATE TABLE experience_translations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    experience_id UUID NOT NULL REFERENCES experiences(id) ON DELETE CASCADE,
    language VARCHAR(8) NOT NULL,
    situation TEXT,
    failed_approaches TEXT,
    solution TEXT,
    lessons TEXT,
    translated_at TIMESTAMPTZ,
    CONSTRAINT uq_experience_translations_exp_lang UNIQUE(experience_id, language)
);

-- credit_transactions
CREATE TABLE credit_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID NOT NULL REFERENCES credit_accounts(id),
    txn_type VARCHAR(32) NOT NULL,
    amount BIGINT NOT NULL,
    balance_after BIGINT NOT NULL,
    idempotency_key VARCHAR(128) UNIQUE,
    reference_id UUID,
    reference_type VARCHAR(32),
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX credit_txn_account_created ON credit_transactions(account_id, created_at);

-- quality_votes
CREATE TABLE quality_votes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    experience_id UUID NOT NULL REFERENCES experiences(id),
    voter_user_id UUID NOT NULL REFERENCES users(id),
    vote SMALLINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_quality_votes_vote_value CHECK (vote IN (-1, 1)),
    CONSTRAINT uq_quality_votes_exp_user UNIQUE(experience_id, voter_user_id)
);

-- query_logs
CREATE TABLE query_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    anon_session_id UUID REFERENCES anonymous_sessions(id),
    agent_type VARCHAR(64),
    query_text TEXT NOT NULL,
    query_language VARCHAR(8),
    tried_text TEXT,
    filters JSONB,
    search_fields JSONB,
    result_ids UUID[],
    query_embedding vector(1024),
    latency_ms INTEGER,
    cache_hit_level VARCHAR(4),
    fallback_level SMALLINT DEFAULT 0,
    credits_spent INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX query_logs_user_created ON query_logs(user_id, created_at) WHERE user_id IS NOT NULL;
CREATE INDEX query_logs_created_at ON query_logs(created_at);

-- search_feedback
CREATE TABLE search_feedback (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    query_log_id UUID NOT NULL REFERENCES query_logs(id),
    experience_id UUID NOT NULL REFERENCES experiences(id),
    user_id UUID REFERENCES users(id),
    position SMALLINT NOT NULL,
    was_useful BOOLEAN NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_search_feedback_query_exp UNIQUE(query_log_id, experience_id)
);
CREATE INDEX search_feedback_exp_created ON search_feedback(experience_id, created_at);
```
