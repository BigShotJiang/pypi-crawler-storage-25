# AGXP — 产品需求文档 (PRD)

> **Product Requirements Document**
> 版本：1.0
> 日期：2026-04-06
> 状态：Phase 1 Local 已完成，Phase 2 Server 已完成

---

## 目录

1. [产品概述与愿景](#1-产品概述与愿景)
2. [目标用户与使用场景](#2-目标用户与使用场景)
3. [核心功能需求（按优先级）](#3-核心功能需求按优先级)
4. [用户故事](#4-用户故事)
5. [非功能需求](#5-非功能需求)
6. [MVP 范围定义](#6-mvp-范围定义)
7. [后续迭代路线图](#7-后续迭代路线图)
8. [成功指标](#8-成功指标)
9. [约束条件与假设](#9-约束条件与假设)
10. [验收标准](#10-验收标准)

---

## 1. 产品概述与愿景

### 1.1 产品定位

**AGXP**（Agent Experience Platform）是一个面向 AI 编程 Agent 的可搜索经验知识库。Agent 在此记录和查询可复用的问题解决经验——什么有效、什么失败、为什么——让其他 Agent 不必重复踩坑。

AGXP 提供三个安装层级，从零依赖的本地工具到完整的社区共享服务，满足不同规模的使用需求。

### 1.2 核心问题

AI Agent 在不同用户和项目中**反复遇到相同问题**：

- 同一个库的同一个 bug，不同 Agent 各踩一遍
- 某个配置的陷阱，每次都要 debug 30 分钟才找到
- 一个 workaround 只有用过的 Agent 知道，其他 Agent 从零摸索
- Agent 的"经验"随 session 结束丢失，下次重新开始

**根因：** AI Agent 缺乏跨 session、跨用户、跨项目的集体记忆。

### 1.3 产品愿景

> _AI Agent 的集体记忆。_

每个 Agent 解决问题后，将经验贡献到共享知识库。当其他 Agent 遇到类似问题时，能在毫秒级找到相关经验。随着经验积累，Agent 群体的整体效率持续提升。

### 1.4 核心设计原则

| 原则 | 说明 | 实现方式 |
|------|------|---------|
| **零摩擦** | 一条命令安装，一条命令初始化，Agent 自动使用 | `pip install agxp[local] && agxp init` 即可使用 |
| **BM25 够用** | 本地搜索无需 embedding 模型，~5MB 安装 | SQLite FTS5 内置 BM25，技术内容关键词密集 |
| **Agent 自带语义能力** | 调用方本身是大模型，无需额外语义引擎 | Agent 从 BM25 top-20 中自主判断相关性 |
| **渐进增强** | 从单机到社区，按需升级，无需重写 | Base → Local KB → Server 三层架构 |
| **结构化经验** | 机器可读，不是博客文章 | situation / solution / lessons / failed_approaches 结构化字段 |
| **反馈驱动** | 搜索质量随使用自动提升 | auto-feedback 机制 + quality_score 排序 |

### 1.5 产品层级

| 层级 | 安装方式 | 大小 | 外部依赖 | 适用场景 |
|------|---------|------|---------|---------|
| **Base** | `pip install agxp` | ~5MB | 无 | CLI 框架，未来连接 AGXP 全球服务 |
| **Local KB** | `pip install agxp[local]` | ~5MB | 无 | 独立本地知识库，SQLite + FTS5，零外部服务 |
| **Server** | `pip install agxp[server]` | ~200MB | PostgreSQL + Redis | 团队/社区共享，多用户认证，积分经济 |

---

## 2. 目标用户与使用场景

### 2.1 用户画像

#### 画像 1：使用 AI 编程助手的开发者（主要用户）

| 属性 | 描述 |
|------|------|
| **身份** | 日常使用 Claude Code、Cursor、Copilot 等 AI 编程工具的开发者 |
| **动机** | 希望 Agent 更快、更准确地解决问题，减少 Agent 反复踩坑的时间 |
| **技术水平** | 熟悉 `pip install`，能编辑配置文件，但不想管理基础设施 |
| **决策因素** | 安装足够简单（一条命令）、即刻见效（第一次搜索就有用）、不侵入工作流 |
| **痛点** | Agent 每次 session 从零开始；同一个问题不同项目反复 debug |

**日常使用场景：**

1. 在新项目中 `agxp init`，Agent 自动发现并配置 MCP
2. Agent 遇到报错时自动查询 AGXP，找到其他 Agent 的解决经验
3. Agent 解决了一个非显而易见的问题后，自动贡献经验
4. 开发者通过 `agxp status` 了解本地知识库状态

#### 画像 2：AI Agent（实际客户端）

| 属性 | 描述 |
|------|------|
| **身份** | Claude Code、Cursor Agent、Copilot 等编程 AI 的运行时实例 |
| **交互方式** | CLI subprocess（NDJSON）或 MCP 工具调用 |
| **查询触发** | 被动触发——遇到报错、异常行为、或第 N 次重试时 |
| **贡献触发** | 任务结束时，如果学到了非显而易见的知识 |
| **需求** | 结构化、机器可读的经验（不是自然语言博客文章） |

**日常使用场景：**

1. 遇到 `asyncio RuntimeError` → 搜索 AGXP → 找到 `run_in_executor` workaround → 直接应用
2. 第 2 次重试相同操作前 → 搜索 AGXP → 避免重复失败
3. 发现某个库的未文档行为 → 贡献经验 → 其他 Agent 未来直接获益
4. 搜索后下次查询时 → 收到 pending feedback 提示 → 报告之前的经验是否有用

#### 画像 3：团队管理员（未来）

| 属性 | 描述 |
|------|------|
| **身份** | 开发团队的技术负责人 |
| **动机** | 团队内部经验共享，避免知识孤岛 |
| **需求** | 私有经验库、使用分析、认证和配额控制 |
| **决策因素** | 数据安全（私有部署 vs 云服务）、团队协作效率提升可量化 |

**日常使用场景：**

1. 搭建团队 AGXP 服务端，配置认证和配额
2. 查看使用分析：哪些经验被查询最多、哪些 Agent 贡献最活跃
3. 管理私有经验库：审核、删除低质量内容

---

## 3. 核心功能需求（按优先级）

### P0 — 必须有（MVP）

| ID | 功能 | 描述 | 状态 |
|----|------|------|------|
| F-01 | **本地经验存储** | SQLite + FTS5 单文件存储，WAL 模式，零外部依赖 | ✅ 已完成 |
| F-02 | **BM25 全文搜索** | FTS5 `MATCH` + `bm25()` 排序，字段加权，domain/task_type 过滤 | ✅ 已完成 |
| F-03 | **经验贡献** | 结构化字段写入 + FTS5 自动索引 + quality_score 自动计算 | ✅ 已完成 |
| F-04 | **CLI 命令集** | `agxp init / query / contribute / feedback / status / mcp` | ✅ 已完成 |
| F-05 | **MCP Server** | `search_experiences` + `contribute_experience` + `report_feedback` 三个 MCP 工具 | ✅ 已完成 |
| F-06 | **Auto-feedback** | search_log 记录搜索结果，下次查询时提示 pending feedback | ✅ 已完成 |
| F-07 | **质量评分** | 规则型 completeness_score（0.50 基础分 + 5 项加分），影响搜索排序 | ✅ 已完成 |
| F-08 | **Smart Init** | 自动检测已安装的 Agent（Claude Code、Cursor、VS Code、Windsurf），配置 MCP | ✅ 已完成 |
| F-09 | **NDJSON 输出** | CLI 输出为 NDJSON 格式，便于 Agent 解析 | ✅ 已完成 |

### P1 — 应该有（近期迭代）

| ID | 功能 | 描述 | 状态 |
|----|------|------|------|
| F-10 | **远程 Fallback** | 本地搜索无结果时，自动请求 AGXP 全球服务（单一硬编码 URL） | 待开发 |
| F-11 | **匿名 Session** | 20 次免费查询，无需注册 | ✅ 服务端已完成 |
| F-12 | **用户注册** | GitHub OAuth，合并匿名历史，+50 注册积分 | ✅ 服务端已完成 |
| F-13 | **服务端 Feedback** | 搜索反馈提交到服务端，驱动全局质量评分 | 待开发 |
| F-14 | **积分经济** | 查询消耗积分，贡献获得积分，里程碑奖金 | ✅ 服务端已完成 |

### P2 — 可以有（长期规划）

| ID | 功能 | 描述 | 状态 |
|----|------|------|------|
| F-15 | **翻译管线** | 跨语言经验搜索，bge-m3 多语言嵌入 | 待开发 |
| F-16 | **Redis 缓存** | 热点查询 L2 缓存，降低延迟 | 待开发 |
| F-17 | **可观测性** | Prometheus + OpenTelemetry 指标、追踪、告警 | 待开发 |
| F-18 | **私有经验库** | 团队独享的经验空间，500 积分解锁 | 待开发 |
| F-19 | **批量查询 API** | 一次请求多个查询，2000 积分解锁 | 待开发 |
| F-20 | **Web UI** | 浏览器端经验浏览和管理界面 | 待开发 |
| F-21 | **可选本地向量搜索** | `pip install agxp[embed]`（+50MB ONNX），本地也有向量搜索 | 待开发 |

---

## 4. 用户故事

### US-01：首次安装与初始化

**作为** 一个使用 Claude Code 的开发者，
**我想要** 一条命令完成安装和初始化，
**以便于** Agent 能立刻开始使用经验搜索。

| 验收条件 |
|---------|
| `pip install agxp[local]` 在 30 秒内完成，安装包 < 5MB |
| `agxp init` 创建 `~/.agxp/local.db`（SQLite + FTS5） |
| `agxp init` 自动检测已安装的 Agent（Claude Code、Cursor、VS Code、Windsurf） |
| 检测到的 Agent 自动写入 MCP 配置（如 `~/.claude/settings.json`） |
| 生成 `~/.agxp/prompt_snippet.md` 供非 MCP Agent 使用 |
| 重复执行 `agxp init` 是幂等的，不会覆盖已有配置 |

### US-02：首次搜索（本地）

**作为** 一个 AI Agent，
**我想要** 用关键词搜索本地经验库，
**以便于** 在遇到问题时快速找到之前的解决方案。

| 验收条件 |
|---------|
| `agxp query "asyncio memory leak"` 返回 NDJSON 格式结果 |
| 结果按 BM25 分数排序，quality_score 作为次级排序因子 |
| 支持 `--domain` 和 `--task-type` 过滤 |
| 支持 `--limit` 控制返回数量（默认 10） |
| 空库返回空结果（不报错） |
| FTS5 查询中的特殊字符被正确转义（`*`、`"`、`(`、`)`、`^`） |

### US-03：通过 MCP 搜索

**作为** Claude Code Agent，
**我想要** 通过 MCP 工具调用 `search_experiences`，
**以便于** 在推理过程中自然地查询经验库，无需显式的 CLI 调用。

| 验收条件 |
|---------|
| MCP server 暴露 `search_experiences` 工具，参数：query、domain、task_type、limit |
| 返回 `{results: [...], pending_feedback: [...], pending_feedback_hint: str}` |
| 结果中的 `id` 字段重命名为 `experience_id`（MCP 输出契约） |
| `updated_at` 字段从输出中移除 |
| 数据库不存在时抛出 `FileNotFoundError` 并提示运行 `agxp init` |

### US-04：贡献经验（CLI）

**作为** 一个 AI Agent，
**我想要** 在解决了一个非显而易见的问题后，通过 CLI 贡献经验，
**以便于** 未来的 Agent（包括自己）能找到这个解决方案。

| 验收条件 |
|---------|
| `agxp contribute --situation "..." --solution "..." --outcome-type solved --lessons "..." --domain coding --task-type debugging` 成功写入 |
| 返回 `{"experience_id": "<uuid>", "status": "stored"}` |
| FTS5 索引自动同步更新（通过 SQLite trigger） |
| quality_score 在写入时自动计算（completeness_score） |
| `outcome_type` 仅接受 `solved`、`workaround`、`unresolved` |
| 可选字段：`--failed-approaches`、`--environment`（JSON）、`--subdomain`、`--tags`（逗号分隔） |
| `--environment` 必须是合法 JSON 对象，否则报错 |

### US-05：通过 MCP 贡献经验

**作为** Claude Code Agent，
**我想要** 通过 MCP 工具调用 `contribute_experience`，
**以便于** 在任务结束时自动贡献经验。

| 验收条件 |
|---------|
| MCP server 暴露 `contribute_experience` 工具 |
| 接受与 CLI 相同的结构化字段（situation、solution、outcome_type、lessons 等） |
| 返回 `{"experience_id": "<uuid>", "status": "stored"}` |
| 无效 `outcome_type` 抛出 `ValueError` |

### US-06：Feedback 评价

**作为** 一个 AI Agent，
**我想要** 在尝试了搜索到的经验后报告是否有用，
**以便于** 搜索质量随时间自动提升。

| 验收条件 |
|---------|
| `agxp feedback --experience-id <id> --useful` 将 quality_score +0.05 |
| `agxp feedback --experience-id <id> --not-useful` 将 quality_score -0.03 |
| quality_score 始终 clamp 在 [0.0, 1.0] 范围内 |
| feedback 后 search_log 中对应条目标记为 `feedback_given=1` |
| 经验不存在时返回错误（exit code 1） |

### US-07：Auto-feedback 提示

**作为** 一个 AI Agent，
**我想要** 在每次搜索时收到之前未评价的经验提示，
**以便于** 不遗漏对搜索结果的反馈。

| 验收条件 |
|---------|
| 搜索结果中包含 `pending_feedback` 字段（list 或 null） |
| `pending_feedback` 包含最近 24 小时内、未给 feedback 的搜索结果 |
| 最多返回 5 条 pending 项，按时间倒序 |
| 每条包含 `experience_id` 和 `situation`（前 100 字符） |
| 包含 `pending_feedback_hint` 文本指导 Agent 如何操作 |
| 超过 24 小时的 search_log 条目自动清理 |

### US-08：MCP Feedback

**作为** Claude Code Agent，
**我想要** 通过 MCP 工具调用 `report_feedback`，
**以便于** 在推理过程中自然地给出反馈。

| 验收条件 |
|---------|
| MCP server 暴露 `report_feedback` 工具，参数：experience_id、useful（bool） |
| 返回 `{"experience_id": str, "quality_score": float, "status": "updated"}` |
| 经验不存在时抛出 `ValueError` |

### US-09：查看系统状态

**作为** 开发者，
**我想要** 查看 AGXP 的安装和使用状态，
**以便于** 了解知识库的规模和健康度。

| 验收条件 |
|---------|
| `agxp status` 显示：数据目录路径、数据库文件大小、经验总数 |
| 显示已安装的层级（Base / Local / Server） |
| 不需要 `[local]` 安装也能运行（仅用 stdlib sqlite3） |
| 未初始化时提示运行 `agxp init` |

### US-10：远程 Fallback（P1）

**作为** 一个 AI Agent，
**我想要** 本地搜索无结果时自动查询远程 AGXP 服务，
**以便于** 利用社区共享的全球经验库。

| 验收条件 |
|---------|
| 本地 FTS5 搜索返回 0 条结果时，自动发起 HTTP 请求到硬编码的 AGXP 服务 URL |
| 远程请求使用 Bearer token 认证（匿名 session 或注册用户） |
| 远程请求超时（3 秒）后降级为空结果，不阻塞 Agent |
| 远程结果与本地结果格式一致（NDJSON / MCP dict） |
| 每次远程查询消耗 1 积分 |
| 离线时（无网络）静默降级，不报错 |

### US-11：匿名体验 → 注册转化（P1）

**作为** 开发者，
**我想要** 不注册就能使用 AGXP 远程服务，
**以便于** 在体验到价值后再决定是否注册。

| 验收条件 |
|---------|
| `agxp init` 时自动创建匿名 session，获得 20 次免费查询积分 |
| 匿名 token 存储在 `~/.agxp/config.json` |
| 积分用完后提示注册 |
| `agxp login`（GitHub OAuth）合并匿名历史 + 剩余积分 + 50 注册积分 |

### US-12：多项目使用

**作为** 同时维护多个项目的开发者，
**我想要** 所有项目共享同一个本地知识库，
**以便于** 跨项目复用经验。

| 验收条件 |
|---------|
| 默认数据目录为 `~/.agxp/`，所有项目共享 |
| 支持 `--data-dir` 指定自定义路径（每个命令均支持） |
| 不同项目的经验通过 `domain`、`tags`、`environment` 区分 |

### US-13：质量评分驱动排序

**作为** 一个 AI Agent，
**我想要** 搜索结果按质量和相关性综合排序，
**以便于** 优先看到最有用的经验。

| 验收条件 |
|---------|
| 搜索结果首先按 BM25 分数排序 |
| 同等 BM25 分数下，按 quality_score 降序排列 |
| quality_score 由 completeness_score（写入时）和 feedback delta（使用后）共同决定 |
| 新贡献的经验 quality_score 在 [0.50, 1.00] 范围内（取决于字段完整度） |

### US-14：冷启动与种子内容（P1）

**作为** 首次安装 AGXP 的开发者，
**我想要** 本地知识库不是完全空的，
**以便于** 第一次搜索就能得到结果。

| 验收条件 |
|---------|
| 提供种子经验导入工具或内置种子数据集 |
| 种子内容覆盖常见的编程问题域（asyncio、git、Docker、testing 等） |
| 种子经验的 quality_score 预设为合理值 |

---

## 5. 非功能需求

### 5.1 性能

| 指标 | 本地（FTS5） | 服务端（完整管线） | 备注 |
|------|------------|------------------|------|
| 搜索 p50 延迟 | < 1ms | < 70ms | 本地为 SQLite 内存操作 |
| 搜索 p99 延迟 | < 5ms | < 200ms | 服务端含嵌入 + 重排序 |
| 贡献 p50 延迟 | < 5ms | < 100ms | 本地为 SQLite 写入 |
| 搜索吞吐量 | N/A（单用户） | 500 RPS（缓存命中） | 服务端水平扩展 |
| 贡献吞吐量 | N/A（单用户） | 20 RPS | 含异步嵌入 |
| FTS5 索引重建 | < 1s（万级数据） | N/A | 极端情况下的恢复操作 |

### 5.2 可靠性

| 指标 | 要求 | 实现方式 |
|------|------|---------|
| 离线可用性 | 本地功能 100% 可用，无网络依赖 | SQLite 单文件，零外部服务 |
| 数据持久性 | 单点故障不丢数据 | SQLite WAL 模式 + 文件系统 |
| 幂等初始化 | `agxp init` 多次执行安全 | `CREATE TABLE IF NOT EXISTS` + 配置跳过逻辑 |
| 远程降级 | 远程服务不可用时静默降级 | 3 秒超时 + 空结果降级 |
| 数据库损坏恢复 | 可从 FTS5 索引重建 | `INSERT INTO fts(fts) VALUES('rebuild')` |

### 5.3 安全

| 威胁 | 防护措施 | 实现方式 |
|------|---------|---------|
| SQL 注入 | 参数化查询 + 白名单 | 所有值用 `?` 占位符；filter 列名硬编码白名单 `_ALLOWED_FILTERS` |
| FTS5 注入 | 输入转义 | `_escape_fts5_query()` 剥离元字符，每个 token 加双引号 |
| API Key 泄露 | 本地存储加密（P1） | `~/.agxp/config.json` 文件权限 600 |
| 恶意经验内容 | 服务端质量评分 + 人工审核（P2） | 低质量自动降权，社区举报机制 |
| 认证绕过 | Bearer token + 服务端验证 | 每个请求校验 token 有效性和积分余额 |

### 5.4 可维护性

| 要求 | 实现方式 |
|------|---------|
| 可插拔架构 | 每个组件为 ABC + 多个实现，DI 切换 |
| 测试覆盖 | 单元测试 + 集成测试 + E2E 测试，当前 749 测试（593 unit + 156 integration） |
| Fake 实现 | 每个 ABC 有 Fake 实现用于测试，无需真实基础设施 |
| 代码风格 | Python 3.11 type hints，strict mypy |
| 文档 | CLAUDE.md（项目上下文）+ DEV_LOG.md（开发日志）+ 内联 docstring |

### 5.5 兼容性

| 维度 | 要求 |
|------|------|
| Python 版本 | 3.11+ |
| 操作系统 | macOS、Linux、Windows（WSL） |
| SQLite 版本 | 3.35+（FTS5 内置） |
| Agent 兼容 | Claude Code、Cursor、VS Code + Copilot、Windsurf |
| MCP 协议 | FastMCP（`mcp.server.fastmcp`） |
| 输出格式 | NDJSON（CLI）、JSON dict（MCP） |

---

## 6. MVP 范围定义

### 6.1 MVP 包含

| 组件 | 功能 |
|------|------|
| **SqliteStore** | 经验存储 + FTS5 索引 + WAL 模式 + search_log |
| **CLI 命令** | `init`、`query`、`contribute`、`feedback`、`status`、`mcp` |
| **MCP Server** | `search_experiences`、`contribute_experience`、`report_feedback` |
| **Quality Scoring** | 规则型 completeness_score（6 项评分规则） |
| **Auto-feedback** | search_log 追踪 + pending feedback 提示 |
| **Smart Init** | Agent 自动检测 + MCP 配置写入 |
| **Prompt Snippet** | 非 MCP Agent 的触发规则模板 |

### 6.2 MVP 不包含

| 功能 | 原因 | 计划阶段 |
|------|------|---------|
| 远程 Fallback | 本地先跑通，再接入全球服务 | Phase 1.5 |
| 用户注册/登录 | 本地模式无需身份系统 | Phase 1.5 |
| 积分经济 | 本地模式无需积分（无限使用） | Phase 1.5 |
| Web UI | CLI + MCP 是 Agent 的原生界面 | Phase 3+ |
| 定时任务（cron） | 本地模式不需要后台进程 | 不计划 |
| 向量搜索 | BM25 + Agent 语义能力已足够（~95% 命中率） | 可选升级 |
| 翻译管线 | 先解决单语言场景 | Phase 3 |

### 6.3 MVP 工作流图

```
开发者
  │
  ▼
pip install agxp[local]        ← 一条命令，~5MB
  │
  ▼
agxp init                       ← 创建 ~/.agxp/local.db
  │                                检测 Agent → 配置 MCP
  │                                生成 prompt_snippet.md
  ▼
Agent 工作中遇到问题
  │
  ├─ MCP ──→ search_experiences(query="...", domain="coding")
  │          │
  │          ▼
  │        SqliteStore.query()
  │          │
  │          ├─ FTS5 BM25 搜索 → top-N 结果
  │          ├─ 检查 search_log → 附加 pending_feedback
  │          ├─ 记录本次搜索到 search_log
  │          └─ 返回 {results, pending_feedback, pending_feedback_hint}
  │
  ├─ CLI ──→ agxp query "..." --domain coding
  │          │
  │          └─ 同上，输出为 NDJSON
  │
  ▼
Agent 应用解决方案
  │
  ├─ 有效 → report_feedback(id, useful=true)  → quality_score +0.05
  └─ 无效 → report_feedback(id, useful=false) → quality_score -0.03
  │
  ▼
Agent 学到新知识
  │
  ├─ MCP ──→ contribute_experience(situation="...", solution="...", ...)
  └─ CLI ──→ agxp contribute --situation "..." --solution "..." ...
             │
             ▼
           SqliteStore.contribute()
             │
             ├─ 生成 UUID
             ├─ 计算 completeness_score
             ├─ INSERT experiences → FTS5 trigger 自动同步
             └─ 返回 {experience_id, status: "stored"}
```

### 6.4 MVP 数据流图

```
┌─────────────┐     ┌──────────────────────────────────────────────┐
│  Agent/CLI  │     │              ~/.agxp/local.db                │
│             │     │                                              │
│  query ─────┼────→│  experiences_fts (FTS5)                      │
│             │     │    ↕ MATCH + bm25()                          │
│             │◄────┤  experiences (main table)                    │
│             │     │    ├─ id, domain, task_type                  │
│  contribute─┼────→│    ├─ situation, solution, lessons           │
│             │     │    ├─ failed_approaches, environment, tags   │
│             │     │    ├─ quality_score, created_at              │
│             │     │    └─ FTS5 sync triggers (ai/ad/au)         │
│             │     │                                              │
│  feedback ──┼────→│  search_log                                  │
│             │     │    ├─ experience_id, searched_at             │
│             │◄────┤    └─ feedback_given (0/1)                   │
└─────────────┘     └──────────────────────────────────────────────┘
```

---

## 7. 后续迭代路线图

### Phase 1 — 本地优先独立工具（已完成）

**目标：** `pip install agxp[local] && agxp init && agxp query "..."` 零外部服务，~5MB 安装。

| Issue | 内容 | 状态 |
|-------|------|------|
| #2 | SqliteStore + FTS5 本地经验存储 | ✅ 已完成 |
| #7 | CLI 命令集（init / query / contribute / status） | ✅ 已完成 |
| #14 | MCP Server（search + contribute 工具） | ✅ 已完成 |
| #21 | E2E 集成测试（23 个） | ✅ 已完成 |
| #22 | Smart Init：Agent 自动检测 + MCP 配置 | ✅ 已完成 |
| #23 | 质量评分（completeness_score + feedback 机制） | ✅ 已完成 |
| #25 | Auto-feedback：search_log + pending feedback | 🔲 进行中（测试已写，实现 pending） |

**技术栈：** Python 3.11、SQLite + FTS5、Typer、FastMCP。零模型、零向量搜索、零外部服务。

### Phase 1.5 — 远程 Fallback + 客户端注册（进行中）

**目标：** 本地搜索无结果时自动查询 AGXP 全球服务。零配置，匿名起步。

| Issue | 内容 | 状态 |
|-------|------|------|
| - | 远程 Fallback（本地 0 结果 → 自动请求远程） | 待开发 |
| - | 客户端匿名 Session（20 次免费查询） | 待开发 |
| - | 客户端注册/登录（GitHub OAuth 设备流） | 待开发 |
| - | 服务端 Feedback 提交 | 待开发 |

### Phase 2 — 服务端 + 社区共享（已完成）

**目标：** 支持多用户经验共享的中心化服务。

| Issue | 内容 | 状态 |
|-------|------|------|
| #1 | 项目脚手架 | ✅ 已完成 |
| #2-#10 | 完整服务端（DB + 嵌入 + 向量搜索 + FTS + 积分 + 质量评分 + Query API + Contribute API + 认证） | ✅ 已完成 |
| #15-#17 | 启动校验 + 查询降级 + 启动脚本 | ✅ 已完成 |
| #18 | E2E 集成测试（36 个） | ✅ 已完成 |
| #19 | 用户注册端点 | ✅ 已完成 |

**技术栈：** FastAPI、asyncpg、PostgreSQL 16 + pgvector、Celery + Redis、bge-m3、MiniLM cross-encoder。

**测试：** 749 collected，749 passing（593 unit + 156 integration）。

### Phase 3 — 全球部署

**目标：** 生产环境部署，多区域低延迟。

| 内容 | 状态 |
|------|------|
| 可观测性（Prometheus + OpenTelemetry） | 待开发 |
| 单区域生产部署（US-WEST-2） | 待开发 |
| 多区域只读副本（EU-CENTRAL-1、AP-SOUTHEAST-1） | 待开发 |
| Redis L2 缓存层 | 待开发 |
| 压力测试（Locust） | 待开发 |

### Phase 4 — SaaS 化

**目标：** 商业化，付费高级层。

| 内容 | 状态 |
|------|------|
| 付费高级层（私有库、批量 API、优先队列） | 规划中 |
| GitHub OAuth 设备流 | 规划中 |
| 团队管理后台 | 规划中 |
| 翻译管线（跨语言搜索） | 规划中 |
| Web UI（浏览器端） | 规划中 |

---

## 8. 成功指标

### 8.1 分阶段 KPI

| 指标 | Phase 1（本地） | Phase 1.5（远程 Fallback） | Phase 2（服务端） | Phase 3（全球部署） |
|------|---------------|------------------------|------------------|------------------|
| **安装数** | 100 | 500 | 2,000 | 10,000 |
| **周活用户（WAU）** | 30 | 150 | 600 | 3,000 |
| **经验总数（本地平均）** | 50/用户 | 50/用户 | N/A | N/A |
| **经验总数（服务端）** | N/A | 1,000 | 10,000 | 100,000 |
| **搜索命中率** | > 70%（本地库） | > 85%（本地 + 远程） | > 90% | > 95% |
| **贡献率**（搜索用户中贡献过经验的比例） | > 30% | > 25% | > 20% | > 20% |
| **Feedback 率**（搜索后给 feedback 的比例） | > 40% | > 35% | > 30% | > 30% |
| **匿名 → 注册转化率** | N/A | > 15% | > 20% | > 25% |

### 8.2 搜索质量指标

| 指标 | 目标值 | 计算方式 |
|------|-------|---------|
| MRR@5 | > 0.75 | 第一个相关结果的排名倒数 |
| NDCG@10 | > 0.70 | 归一化折损累积增益 |
| Recall@20 | > 0.85 | top-20 中包含相关结果的比例 |

### 8.3 延迟指标

| 路径 | p50 | p99 |
|------|-----|-----|
| 本地 FTS5 搜索 | < 1ms | < 5ms |
| 服务端 L2 缓存命中 | < 20ms | < 60ms |
| 服务端完整管线（BM25 + 向量 + 重排序） | < 70ms | < 200ms |

---

## 9. 约束条件与假设

### 9.1 硬约束

| 约束 | 说明 |
|------|------|
| **Base 安装 < 5MB** | 仅 CLI 框架 + Typer，不拉入 ML 库 |
| **Local KB 安装 < 5MB** | SQLite + FTS5 内置于 Python 标准库，无额外二进制 |
| **零外部服务依赖（本地模式）** | 不需要网络、不需要 Docker、不需要数据库服务 |
| **NDJSON 输出** | CLI 输出必须为 NDJSON，便于 Agent 程序化解析 |
| **SQL 注入防护** | 所有查询值用参数化占位符；filter 列名硬编码白名单 |
| **FTS5 输入转义** | 所有用户输入经过 `_escape_fts5_query()` 转义 |
| **服务端 URL 硬编码** | 单一全球服务器，不支持自建服务端（Phase 3 前） |
| **Python 3.11+** | 使用 `str | None` union type syntax 等 3.10+ 特性 |

### 9.2 技术假设

| 假设 | 依据 | 风险 |
|------|------|------|
| BM25 在技术内容上命中率 ≥ 90% | 编程经验充满精确关键词（库名、函数名、错误信息），是 BM25 最佳场景 | 低：有学术基准支持 |
| Agent 自身的 LLM 语义能力 >> 任何 embedding 模型 | Agent 就是大模型，判断 top-20 候选的相关性远超 cross-encoder | 低：架构前提 |
| SQLite FTS5 在万级数据规模下延迟 < 5ms | SQLite 内存映射 + B-tree 索引，单用户场景无并发瓶颈 | 极低 |
| Agent 会在合适时机自动触发搜索和贡献 | MCP 工具描述中包含触发条件（"when stuck"、"when you discover"） | 中：依赖 Agent 的推理能力 |
| `unicode61` tokenizer 足以支持多语言 FTS5 搜索 | CJK 分词不完美，但英文技术内容为主要场景 | 中：中文搜索可能需要额外处理 |

### 9.3 业务假设

| 假设 | 依据 | 风险 |
|------|------|------|
| 开发者愿意让 Agent 分享解决经验 | 经验是通用的编程知识，非商业机密 | 中：部分用户可能有隐私顾虑 |
| 20 次免费查询足以让用户体验到价值 | 匿名阶段降低注册门槛，让价值先于承诺 | 低：可调整额度 |
| 积分经济能驱动贡献行为 | 贡献即时获得积分（+5~+50，按质量分层），正反馈循环 | 中：需要种子内容避免冷启动 |
| 单一全球服务器（Phase 2）足以支撑初期用户 | 初期用户量小（< 2000），单节点 50 RPS 够用 | 低：Phase 3 扩展 |

---

## 10. 验收标准

### 10.1 MVP 整体验收

| # | 验收条件 | 验证方式 |
|---|---------|---------|
| 1 | `pip install agxp[local]` 在 60 秒内完成，安装后无额外下载 | 手动验证 |
| 2 | `agxp init` 创建数据库、检测 Agent、配置 MCP，全程 < 5 秒 | 手动验证 |
| 3 | `agxp contribute` 写入经验后 `agxp query` 能搜到 | E2E 测试 |
| 4 | MCP `search_experiences` + `contribute_experience` + `report_feedback` 功能正常 | 集成测试 |
| 5 | Auto-feedback：搜索后下次查询包含 pending feedback | E2E 测试 |
| 6 | Quality scoring：新经验的 quality_score 在 [0.50, 1.00] 范围内 | 单元测试 |
| 7 | Feedback 后 quality_score 正确更新（+0.05 / -0.03） | 单元测试 |
| 8 | FTS5 特殊字符不导致 SQL 错误 | 单元测试 |
| 9 | `agxp status` 正确显示安装状态和经验数量 | 手动验证 |
| 10 | 所有测试通过（当前 749 测试） | CI |

### 10.2 各功能验收条件

#### F-01 本地经验存储

| 条件 | 验证 |
|------|------|
| SQLite 文件创建在 `~/.agxp/local.db` | 文件存在检查 |
| WAL 模式启用 | `PRAGMA journal_mode` = `wal` |
| FTS5 虚拟表创建 | `SELECT * FROM experiences_fts LIMIT 0` 不报错 |
| 插入/删除/更新 trigger 自动同步 FTS5 | 写入后 FTS5 搜索能命中 |
| search_log 表创建 | `SELECT * FROM search_log LIMIT 0` 不报错 |

#### F-02 BM25 全文搜索

| 条件 | 验证 |
|------|------|
| FTS5 MATCH 搜索返回结果 | 写入经验后搜索命中 |
| 结果按 bm25() 分数排序 | 多条结果顺序正确 |
| domain / task_type 过滤生效 | 过滤后结果仅含目标域 |
| 特殊字符转义正确 | 输入 `*"(^)` 不报错 |
| 空查询返回空结果 | 不报错，结果为空 |

#### F-04 CLI 命令集

| 条件 | 验证 |
|------|------|
| `agxp --help` 显示所有命令 | 手动验证 |
| 每个命令 `--help` 显示参数说明 | 手动验证 |
| 未初始化时命令报错并提示 `agxp init` | exit code 1 |
| NDJSON 输出格式正确 | JSON 解析成功 |

#### F-05 MCP Server

| 条件 | 验证 |
|------|------|
| `agxp mcp` 启动 FastMCP server | 进程启动成功 |
| 3 个工具均可调用 | MCP 集成测试 |
| 工具描述包含触发条件 | docstring 检查 |
| 错误时抛出有意义的异常 | 异常消息检查 |

#### F-06 Auto-feedback

| 条件 | 验证 |
|------|------|
| 搜索结果写入 search_log | 搜索后查 search_log 表 |
| 下次搜索返回 pending_feedback | 连续两次搜索验证 |
| 24 小时过期自动清理 | 单元测试（模拟时间） |
| feedback 后标记为已完成 | feedback_given = 1 |
| 最多返回 5 条 pending | 超过 5 条时验证截断 |

#### F-07 质量评分

| 条件 | 验证 |
|------|------|
| 仅必填字段 → score = 0.50 | 单元测试 |
| + failed_approaches → +0.15 | 单元测试 |
| + environment → +0.10 | 单元测试 |
| + 可量化数据 → +0.10 | 单元测试 |
| + lessons > 100 词 → +0.10 | 单元测试 |
| + tags >= 3 → +0.05 | 单元测试 |
| 全部满足 → score = 1.00 | 单元测试 |

#### F-08 Smart Init

| 条件 | 验证 |
|------|------|
| 检测 Claude Code（`claude` 命令 + `~/.claude` 目录） | 单元测试（mock） |
| 检测 Cursor（`~/.cursor` 目录） | 单元测试（mock） |
| 检测 VS Code（`code` 命令或 `~/.config/Code` 目录） | 单元测试（mock） |
| 检测 Windsurf（`~/.windsurf` 目录） | 单元测试（mock） |
| MCP 配置写入为原子操作（temp file + rename） | 实现检查 |
| 已配置的 Agent 跳过（不覆盖） | 重复执行验证 |

---

## 附录 A：经验数据模型

```
experiences
├── id              TEXT PRIMARY KEY (UUID v4)
├── domain          TEXT NOT NULL          -- "coding" / "devops" / "research" / ...
├── subdomain       TEXT                   -- "asyncio" / "kubernetes" / ...
├── task_type       TEXT NOT NULL          -- "debugging" / "refactoring" / "testing" / ...
├── situation       TEXT NOT NULL          -- 问题描述（50-4000 字符）
├── failed_approaches TEXT                 -- 尝试过但失败的方法
├── solution        TEXT NOT NULL          -- 实际有效的做法（50-4000 字符）
├── outcome_type    TEXT NOT NULL          -- "solved" / "workaround" / "unresolved"
├── lessons         TEXT NOT NULL          -- 可迁移的洞见 / 根因（30-2000 字符）
├── environment     TEXT (JSON)            -- {"os": "linux", "python": "3.11", ...}
├── tags            TEXT (JSON array)      -- ["asyncio", "debugging", ...]
├── language        TEXT NOT NULL DEFAULT 'en'
├── quality_score   REAL NOT NULL DEFAULT 0.0
├── created_at      TEXT NOT NULL (ISO 8601)
└── updated_at      TEXT NOT NULL (ISO 8601)

experiences_fts (FTS5 virtual table)
├── situation
├── solution
├── lessons
├── failed_approaches
└── tags
    tokenize='unicode61'
    content=experiences (external content table)

search_log
├── id              INTEGER PRIMARY KEY AUTOINCREMENT
├── experience_id   TEXT NOT NULL
├── searched_at     TEXT NOT NULL (ISO 8601)
└── feedback_given  INTEGER NOT NULL DEFAULT 0
```

## 附录 B：质量评分公式

### 本地模式（规则型 completeness_score）

```
score = 0.50                              -- 基础分（所有必填字段已填）
      + 0.15 if failed_approaches 已填     -- 反例价值高
      + 0.10 if environment 已填           -- 环境信息增强可复现性
      + 0.10 if solution/lessons 含数字/% -- 可量化结果更有说服力
      + 0.10 if lessons 字数 > 100         -- 深度洞见
      + 0.05 if tags >= 3                  -- 可发现性
      = max 1.0
```

### Feedback Delta

```
useful=true  → quality_score += 0.05
useful=false → quality_score -= 0.03
clamp to [0.0, 1.0]
```

### 服务端模式（完整公式，Phase 2）

```
quality_score = 0.40 × uniqueness_score     -- 嵌入空间中与最近邻的余弦距离
              + 0.35 × completeness_score   -- 规则型（同上）
              + 0.25 × community_score      -- 投票 + 使用次数
```

## 附录 C：积分经济（服务端）

### 收入

| 事件 | 积分 |
|------|------|
| 创建匿名 session | +20 |
| 注册 | +50 |
| 每日补给 | +3/天 |
| 贡献（按质量评分即时奖励） | +5 ~ +50（质量分层：[0,0.5)→+5, [0.5,0.7)→+10, [0.7,0.85)→+25, [0.85,1.0]→+50） |
| 经验被点赞 | +2 |
| 经验被他人使用 | +1（上限 +500/条） |
| 推荐（双方） | +30 |

### 支出

| 事件 | 积分 |
|------|------|
| 查询 | -1 |

### 功能解锁

| 花费 | 功能 |
|------|------|
| 500 积分 | 私有经验库 |
| 1000 积分 | 优先评分队列 |
| 2000 积分 | 批量查询 API |

## 附录 D：核心设计决策索引

| DDR | 决策 | 一句话总结 |
|-----|------|-----------|
| DDR-001 | 查询触发 | 被动触发（出错/重试时），而非主动 |
| DDR-002 | 贡献触发 | 学到东西时触发，与是否查询过无关 |
| DDR-003 | 积分范围 | 归属用户，而非 API key 或 Agent |
| DDR-005 | 注册流程 | 先匿名，后注册（20 次免费查询） |
| DDR-006 | MCP 优先级 | Phase 1 即支持，非 Phase 2 |
| DDR-007 | 经验字段 | 将 approach 拆分为 failed_approaches + solution |
| DDR-008 | 质量评分 | Phase 1 规则型，Phase 2 数据驱动 |
| DDR-011 | `tried` 字段 | CLI `--tried` 映射到 failed_approaches 做反例搜索 |
| DDR-016 | 反馈机制 | 批量、位置加权、有激励 |
| DDR-018 | 可插拔接口 | 5 个 ABC 支撑架构演进 |
