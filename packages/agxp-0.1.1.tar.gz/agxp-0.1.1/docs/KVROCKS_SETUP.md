# Kvrocks 部署指南

AGXP 支持使用 Kvrocks 作为 Redis 的替代品，提供更高的性能和存储容量。

## 配置方式

### 1. 直接连接模式（单节点 Kvrocks）
和普通 Redis 完全兼容，直接配置 `REDIS_URL` 即可：
```env
REDIS_URL=redis://<username>:<password>@<kvrocks-host>:<port>/<db>
```

### 2. Sentinel 模式（Kvrocks 集群）
Kvrocks 支持 Redis Sentinel 协议进行集群管理，需要配置以下环境变量：

```env
# 启用 Sentinel 模式
REDIS_USE_SENTINEL=true

# Sentinel 节点地址列表，逗号分隔
REDIS_SENTINEL_HOSTS=sentinel1:2011,sentinel2:2011,sentinel3:2011

# Sentinel 密码（如果有）
REDIS_SENTINEL_PASSWORD=your_sentinel_password

# Kvrocks 主节点名称
REDIS_MASTER_NAME=kvrocks

# Kvrocks Namespace 密码（即创建 Namespace 时的 Token）
REDIS_NAMESPACE_PASSWORD=your_namespace_token

# 使用的数据库编号
REDIS_DB=0
```

## 兼容性说明

### 已验证兼容的功能
- ✅ 所有基础 Redis 命令（GET/SET/SETEX/DEL 等）
- ✅ Celery 作为 Broker 和 Result Backend
- ✅ OAuth 状态存储
- ✅ 所有需要 Redis 缓存的功能

### Kvrocks 特有配置
- Namespace 的认证直接使用对应的 Token 作为 Redis 密码传入即可
- Kvrocks 完全兼容 Redis 协议，无需修改业务代码

## 注意事项
1. 确保 Kvrocks 版本 >= 2.0，以支持完整的 Redis 协议兼容性
2. Sentinel 模式下，所有服务（API 服务器、Celery Worker）都需要使用相同的 Sentinel 配置
3. 如果使用 Namespace 功能，确保直接使用对应的 Token 作为密码
4. Kvrocks 的持久化配置和 Redis 不同，请参考 Kvrocks 官方文档进行优化
