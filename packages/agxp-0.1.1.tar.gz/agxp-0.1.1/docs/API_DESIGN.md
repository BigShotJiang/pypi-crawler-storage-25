# AGXP API & Interface Design

> 完整的接口设计文档，涵盖 CLI、MCP、HTTP API 三层接口及其数据格式定义。
> 基于实际代码编写，非理论设计。

---

## 目录

1. [接口总览与分层设计](#1-接口总览与分层设计)
2. [CLI 接口定义](#2-cli-接口定义)
3. [MCP 工具接口定义](#3-mcp-工具接口定义)
4. [HTTP API 接口定义（Phase 2 服务端）](#4-http-api-接口定义phase-2-服务端)
5. [接口间调用关系图](#5-接口间调用关系图)
6. [数据格式定义](#6-数据格式定义)
7. [错误码与错误处理](#7-错误码与错误处理)
8. [未来接口](#8-未来接口)

---

## 1. 接口总览与分层设计

### 1.1 三层接口架构图

```
┌─────────────────────────────────────────────────────────────────┐
│                         Agent / 用户                            │
└────────┬──────────────────────┬──────────────────────┬──────────┘
         │                      │                      │
         ▼                      ▼                      ▼
┌─────────────────┐  ┌──────────────────┐  ┌──────────────────────┐
│  Level 1: CLI   │  │ Level 2: MCP     │  │ Level 3: HTTP API    │
│  (Typer)        │  │ (FastMCP/stdio)  │  │ (FastAPI)            │
│                 │  │                  │  │                      │
│  agxp init      │  │ search_          │  │ POST /api/v1/query   │
│  agxp query     │  │   experiences    │  │ POST /api/v1/        │
│  agxp contribute│  │ contribute_      │  │   contribute         │
│  agxp feedback  │  │   experience     │  │ POST /api/v1/auth/*  │
│  agxp status    │  │ report_feedback  │  │                      │
│  agxp mcp       │  │                  │  │                      │
└────────┬────────┘  └────────┬─────────┘  └──────────┬───────────┘
         │                    │                        │
         ▼                    ▼                        ▼
┌─────────────────────────────────────────────────────────────────┐
│              Level 4: Storage / Backend Layer                    │
│                                                                 │
│  Phase 1 (Local):  SqliteStore + FTS5                           │
│  Phase 2 (Server): PostgreSQL + pgvector + Tantivy + Redis      │
└─────────────────────────────────────────────────────────────────┘
```

### 1.2 数据流向

| 调用路径 | 说明 |
|----------|------|
| CLI --> SqliteStore | 本地模式直连，同步调用 |
| CLI --> MCP Server | `agxp mcp` 启动 stdio MCP server，供 Agent 调用 |
| MCP --> SqliteStore | MCP 工具内部直接调用 SqliteStore |
| HTTP API --> Pipeline --> Backends | 服务端模式，经过 embedding + vector + FTS + reranker 完整管线 |

### 1.3 各层职责边界

| 层级 | 职责 | 认证 | 数据格式 |
|------|------|------|----------|
| **CLI** | 用户/脚本交互入口，参数校验，NDJSON 输出 | 无（本地单用户） | NDJSON stdout + 提示信息 stderr |
| **MCP** | Agent 工具调用接口（stdio transport），JSON-RPC | 无（本地单用户） | JSON dict（MCP 协议） |
| **HTTP API** | 远程服务端，多用户，信用系统 | Bearer Token | NDJSON streaming / JSON |
| **Storage** | 数据持久化，全文索引，向量检索 | N/A | 内部 dict/Row |

---

## 2. CLI 接口定义

入口：`agxp = agxp.cli.main:app`（Typer）

所有命令默认数据目录为 `~/.agxp`，可用 `--data-dir` 覆盖。

---

### 2.1 `agxp init`

初始化本地数据目录，创建 SQLite 数据库和 FTS5 索引。检测已安装的 Agent 并配置 MCP。幂等操作，可安全重复执行。

#### 参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `--data-dir` | string | 否 | `~/.agxp` | 数据目录路径 |
| `--skip-agent-config` | bool | 否 | `False` | 跳过 Agent 检测和 MCP 配置 |

#### 输出格式

人类可读文本（stdout），非 JSON：

```
✓ Database created at ~/.agxp/local.db

Detected agents:
  ✓ Claude Code — MCP configured
  · Cursor — already configured

Generated: ~/.agxp/agxp_prompt_snippet.md

AGXP ready.
```

若无 Agent 检测到：

```
✓ Database created at ~/.agxp/local.db

No agents detected.

AGXP ready.
```

#### Agent 检测范围

| Agent | 配置路径 |
|-------|----------|
| Claude Code | `~/.claude/settings.json` |
| Cursor | `~/.cursor/mcp.json` |
| VS Code | `.vscode/mcp.json` |
| Windsurf | `~/.windsurf/mcp.json` |

MCP 配置写入内容：`{"command": "agxp", "args": ["mcp"]}`

#### 退出码

| 码 | 含义 |
|----|------|
| 0 | 成功 |

---

### 2.2 `agxp query`

搜索本地经验知识库。输出 NDJSON 到 stdout，pending feedback 提示输出到 stderr。

#### 参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `QUERY_TEXT` | string | 是（位置参数） | - | 搜索查询文本 |
| `--domain` | string | 否 | `None` | 按 domain 过滤 |
| `--task-type` | string | 否 | `None` | 按 task_type 过滤 |
| `--limit` | int | 否 | `10` | 最大返回结果数 |
| `--data-dir` | string | 否 | `~/.agxp` | 数据目录路径 |

#### 输出格式

**stdout**（NDJSON，每行一个 JSON 对象）：

```jsonl
{"experience_id": "a1b2c3d4-...", "domain": "coding", "subdomain": "python", "task_type": "debugging", "situation": "...", "failed_approaches": "...", "solution": "...", "outcome_type": "solved", "lessons": "...", "environment": {"os": "linux"}, "tags": ["asyncio"], "language": "en", "quality_score": 0.65, "created_at": "2026-04-01T10:00:00+00:00"}
{"experience_id": "e5f6g7h8-...", "domain": "coding", "task_type": "refactoring", "situation": "...", "solution": "...", "outcome_type": "solved", "lessons": "...", "language": "en", "quality_score": 0.50, "created_at": "2026-04-02T14:30:00+00:00"}
```

每行输出字段：

| 字段 | 类型 | 说明 |
|------|------|------|
| `experience_id` | string (UUID) | 经验 ID |
| `domain` | string | 领域 |
| `subdomain` | string \| null | 子领域 |
| `task_type` | string | 任务类型 |
| `situation` | string | 问题描述 |
| `failed_approaches` | string \| null | 失败尝试 |
| `solution` | string | 解决方案 |
| `outcome_type` | string | 结果类型 |
| `lessons` | string | 经验教训 |
| `environment` | object \| null | 环境信息 |
| `tags` | list[string] \| null | 标签 |
| `language` | string | 语言代码 |
| `quality_score` | float | 质量分数 [0.0, 1.0] |
| `created_at` | string (ISO 8601) | 创建时间 |

注意：`updated_at` 字段不包含在输出中（内部字段）。

**stderr**（pending feedback 提示，仅当有未反馈的搜索结果时）：

```
Pending feedback from previous search:
  a1b2c3d4-...: FastAPI endpoint needed rate limiting without blocking...
Use: agxp feedback --experience-id <id> --useful/--not-useful
```

#### 示例

```bash
# 基本搜索
agxp query "asyncio memory leak"

# 带过滤条件
agxp query "rate limiting" --domain coding --task-type debugging --limit 5

# 指定数据目录
agxp query "docker network" --data-dir /tmp/test-agxp
```

#### 退出码

| 码 | 含义 |
|----|------|
| 0 | 成功（即使结果为空） |
| 1 | 未初始化（数据库不存在） |

---

### 2.3 `agxp contribute`

记录新经验到本地知识库。

#### 参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `--situation` | string | 是 | - | 问题描述 |
| `--solution` | string | 是 | - | 解决方案 |
| `--outcome-type` | string | 是 | - | 结果类型：`solved` \| `workaround` \| `unresolved` |
| `--lessons` | string | 是 | - | 经验教训/关键收获 |
| `--domain` | string | 是 | - | 领域（如 coding, devops） |
| `--task-type` | string | 是 | - | 任务类型（如 debugging, config） |
| `--language` | string | 否 | `"en"` | 语言代码 |
| `--failed-approaches` | string | 否 | `None` | 失败尝试记录 |
| `--environment` | string (JSON) | 否 | `None` | 环境信息（JSON 对象字符串） |
| `--subdomain` | string | 否 | `None` | 子领域 |
| `--tags` | string | 否 | `None` | 逗号分隔标签 |
| `--data-dir` | string | 否 | `~/.agxp` | 数据目录路径 |

#### 验证规则

| 规则 | 详情 |
|------|------|
| `outcome_type` 枚举 | 必须为 `solved`、`workaround`、`unresolved` 之一 |
| `--environment` JSON | 必须为有效 JSON 且为 object 类型（非 array/string） |
| `--tags` 解析 | 逗号分隔，自动 trim 空白，忽略空串 |

#### 质量评分规则（contribute 时自动计算）

| 条件 | 分数 |
|------|------|
| 基础分（所有必填字段存在） | +0.50 |
| `failed_approaches` 非空 | +0.15 |
| `environment` 非空 dict | +0.10 |
| `solution` 或 `lessons` 含数字/百分号 | +0.10 |
| `lessons` 字数 > 100 | +0.10 |
| `tags` 数量 >= 3 | +0.05 |
| **最大值** | **1.00** |

#### 输出格式

**stdout**（单行 JSON）：

```json
{"experience_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890", "status": "stored"}
```

#### 示例

```bash
# 最小必填参数
agxp contribute \
  --situation "FastAPI endpoint blocks on sync Redis call" \
  --solution "Switch to aioredis async client" \
  --outcome-type solved \
  --lessons "Always use async Redis client in FastAPI to avoid blocking the event loop" \
  --domain coding \
  --task-type debugging

# 完整参数
agxp contribute \
  --situation "FastAPI endpoint blocks on sync Redis call" \
  --solution "Switch to aioredis async client" \
  --outcome-type solved \
  --lessons "Always use async Redis client in FastAPI to avoid blocking the event loop" \
  --domain coding \
  --task-type debugging \
  --language en \
  --failed-approaches "Tried threading.Lock — blocked event loop entirely" \
  --environment '{"os": "linux", "python": "3.11", "framework": "fastapi"}' \
  --subdomain python \
  --tags "fastapi,redis,async"
```

#### 退出码

| 码 | 含义 |
|----|------|
| 0 | 成功 |
| 1 | 参数校验失败（invalid outcome_type / invalid JSON / 未初始化） |

---

### 2.4 `agxp feedback`

报告某条经验是否有用。更新 quality_score 以改进后续搜索排名。

#### 参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `--experience-id` | string | 是 | - | 经验 ID |
| `--useful / --not-useful` | bool | 是 | `None` | 经验是否有用 |
| `--data-dir` | string | 否 | `~/.agxp` | 数据目录路径 |

#### 质量分数调整

| 反馈 | delta | 说明 |
|------|-------|------|
| `--useful` | `+0.05` | `FEEDBACK_DELTA_USEFUL` |
| `--not-useful` | `-0.03` | `FEEDBACK_DELTA_NOT_USEFUL` |

分数始终 clamp 到 `[0.0, 1.0]` 范围。反馈成功后，该经验在 `search_log` 中标记为 `feedback_given=1`，后续搜索不再提示。

#### 输出格式

**stdout**（成功，单行 JSON）：

```json
{"experience_id": "a1b2c3d4-...", "quality_score": 0.7, "status": "updated"}
```

#### 示例

```bash
# 标记为有用
agxp feedback --experience-id a1b2c3d4-e5f6-7890-abcd-ef1234567890 --useful

# 标记为无用
agxp feedback --experience-id a1b2c3d4-e5f6-7890-abcd-ef1234567890 --not-useful
```

#### 退出码

| 码 | 含义 |
|----|------|
| 0 | 成功 |
| 1 | 未指定 --useful/--not-useful / 未初始化 / 经验不存在 |

---

### 2.5 `agxp status`

显示本地数据目录状态和已安装组件。不依赖 `[local]` 安装——仅使用 stdlib `sqlite3` 和 `os`。

#### 参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `--data-dir` | string | 否 | `~/.agxp` | 数据目录路径 |

#### 输出格式

人类可读文本（stdout）：

```
AGXP Status
────────────────────────────────────────
Data directory:  /home/user/.agxp
Database:        local.db (48.0 KB)
Experiences:     12

Install tiers:
  Base:    ✓ installed
  Local:   ✓ installed
  Server:  ✗ not installed
```

若未初始化：

```
Not initialized. Run: agxp init --data-dir ~/.agxp
```

#### 安装层级检测

| 层级 | 检测方式 |
|------|----------|
| Base | 始终 `✓ installed`（CLI 本身就是 base） |
| Local | `importlib.util.find_spec("agxp.local.store")` |
| Server | `importlib.util.find_spec("fastapi")` |

#### 退出码

| 码 | 含义 |
|----|------|
| 0 | 始终成功 |

---

### 2.6 `agxp mcp`

启动 MCP (Model Context Protocol) 服务器，使用 stdio transport。

#### 参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `--data-dir` | string | 否 | `~/.agxp` | 数据目录路径 |

#### 行为

1. 检查数据库文件存在
2. 导入 `agxp.mcp.server`（若 `mcp[cli]` 未安装则报错退出）
3. 调用 `set_data_dir(data_dir)`
4. 调用 `mcp_server.run(transport="stdio")`

MCP 服务器运行后，Agent 通过 JSON-RPC over stdio 调用工具。

#### Agent 配置示例

```json
{
  "mcpServers": {
    "agxp": {
      "command": "agxp",
      "args": ["mcp"]
    }
  }
}
```

#### 退出码

| 码 | 含义 |
|----|------|
| 0 | 正常退出 |
| 1 | 未初始化 / MCP 依赖未安装 |

---

## 3. MCP 工具接口定义

MCP 服务器名称：`agxp`
Transport：`stdio`（JSON-RPC 2.0）
框架：`mcp.server.fastmcp.FastMCP`

所有工具通过 `@mcp.tool()` 装饰器注册，由 FastMCP 自动生成 JSON Schema。

---

### 3.1 `search_experiences`

搜索 AGXP 经验库。

#### Tool Description（Agent 可见）

> Search the AGXP experience library for relevant knowledge.
>
> Use when: you encounter an error, unexpected API behavior, or are about to retry a failed approach. DO NOT call at task start -- call when stuck.

#### 参数 JSON Schema

```json
{
  "type": "object",
  "properties": {
    "query": {
      "type": "string",
      "description": "Your problem description (keywords work best)"
    },
    "domain": {
      "type": ["string", "null"],
      "default": null,
      "description": "Filter by domain (e.g. \"coding\", \"devops\", \"security\")"
    },
    "task_type": {
      "type": ["string", "null"],
      "default": null,
      "description": "Filter by task type (e.g. \"debugging\", \"deployment\")"
    },
    "limit": {
      "type": "integer",
      "default": 5,
      "description": "Maximum results to return (default 5)"
    }
  },
  "required": ["query"]
}
```

#### 返回值 Schema

```json
{
  "type": "object",
  "properties": {
    "results": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "experience_id": {"type": "string"},
          "domain": {"type": "string"},
          "subdomain": {"type": ["string", "null"]},
          "task_type": {"type": "string"},
          "situation": {"type": "string"},
          "failed_approaches": {"type": ["string", "null"]},
          "solution": {"type": "string"},
          "outcome_type": {"type": "string"},
          "lessons": {"type": "string"},
          "environment": {"type": ["object", "null"]},
          "tags": {"type": ["array", "null"]},
          "language": {"type": "string"},
          "quality_score": {"type": "number"},
          "created_at": {"type": "string"}
        }
      }
    },
    "pending_feedback": {
      "type": ["array", "null"],
      "items": {
        "type": "object",
        "properties": {
          "experience_id": {"type": "string"},
          "situation": {"type": "string"}
        }
      },
      "description": "Experiences from previous searches awaiting feedback"
    },
    "pending_feedback_hint": {
      "type": ["string", "null"],
      "description": "Guidance text telling the agent how to report feedback"
    }
  }
}
```

#### pending_feedback_hint 内容（固定文本）

> You received these experiences in a previous search. If you actually tried any and saw the result (success or failure), please call report_feedback(experience_id, useful=true/false) for each. Skip any experiences you did not use -- do not guess.

#### 示例调用与返回

调用：
```json
{
  "query": "asyncio memory leak in FastAPI",
  "domain": "coding",
  "limit": 3
}
```

返回：
```json
{
  "results": [
    {
      "experience_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
      "domain": "coding",
      "subdomain": "python",
      "task_type": "debugging",
      "situation": "FastAPI application leaking memory under high concurrency...",
      "failed_approaches": "Tried gc.collect() manually...",
      "solution": "Root cause was unclosed aiohttp sessions...",
      "outcome_type": "solved",
      "lessons": "Always use async context managers for HTTP sessions...",
      "environment": {"os": "linux", "python": "3.11"},
      "tags": ["fastapi", "asyncio", "memory"],
      "language": "en",
      "quality_score": 0.75,
      "created_at": "2026-04-01T10:00:00+00:00"
    }
  ],
  "pending_feedback": [
    {
      "experience_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
      "situation": "Docker container networking issue..."
    }
  ],
  "pending_feedback_hint": "You received these experiences in a previous search. If you actually tried any and saw the result (success or failure), please call report_feedback(experience_id, useful=true/false) for each. Skip any experiences you did not use — do not guess."
}
```

---

### 3.2 `contribute_experience`

向 AGXP 库贡献新经验。

#### Tool Description（Agent 可见）

> Contribute a new experience to the AGXP library.
>
> Use when: you discovered something non-obvious, unexpected, or undocumented during task execution. Trigger at end of task -- any new knowledge qualifies, not only after using AGXP.

#### 参数 JSON Schema

```json
{
  "type": "object",
  "properties": {
    "situation": {
      "type": "string",
      "description": "The problem you encountered (50-4000 chars)"
    },
    "solution": {
      "type": "string",
      "description": "What actually worked (50-4000 chars)"
    },
    "outcome_type": {
      "type": "string",
      "enum": ["solved", "workaround", "unresolved"],
      "description": "\"solved\", \"workaround\", or \"unresolved\""
    },
    "lessons": {
      "type": "string",
      "description": "Transferable insight or root cause (30-2000 chars)"
    },
    "domain": {
      "type": "string",
      "description": "Problem domain (e.g. \"coding\", \"devops\")"
    },
    "task_type": {
      "type": "string",
      "description": "Task type (e.g. \"debugging\", \"refactoring\")"
    },
    "language": {
      "type": "string",
      "default": "en",
      "description": "Language code (default \"en\")"
    },
    "failed_approaches": {
      "type": ["string", "null"],
      "default": null,
      "description": "What you tried that didn't work"
    },
    "environment": {
      "type": ["object", "null"],
      "default": null,
      "description": "Runtime environment (e.g. {\"os\": \"linux\", \"python\": \"3.11\"})"
    },
    "subdomain": {
      "type": ["string", "null"],
      "default": null,
      "description": "More specific domain (e.g. \"asyncio\", \"kubernetes\")"
    },
    "tags": {
      "type": ["array", "null"],
      "items": {"type": "string"},
      "default": null,
      "description": "Keyword tags for discoverability"
    }
  },
  "required": ["situation", "solution", "outcome_type", "lessons", "domain", "task_type"]
}
```

#### 返回值 Schema

```json
{
  "type": "object",
  "properties": {
    "experience_id": {"type": "string", "description": "UUID of created experience"},
    "status": {"type": "string", "enum": ["stored"]}
  }
}
```

#### 示例调用与返回

调用：
```json
{
  "situation": "FastAPI endpoint needed rate limiting without blocking the async event loop",
  "solution": "Created Redis-based token bucket using INCR+EXPIRE in a single pipeline with asyncio-redis",
  "outcome_type": "solved",
  "lessons": "Redis INCR+EXPIRE is only atomic when both commands are sent in a single pipeline",
  "domain": "coding",
  "task_type": "debugging",
  "failed_approaches": "Tried threading.Lock — blocked the async event loop entirely",
  "environment": {"os": "linux", "python": "3.11", "framework": "fastapi"},
  "tags": ["fastapi", "redis", "rate-limiting"]
}
```

返回：
```json
{
  "experience_id": "b2c3d4e5-f6a7-8901-bcde-f12345678901",
  "status": "stored"
}
```

#### 验证与错误

- `outcome_type` 不在 `{"solved", "workaround", "unresolved"}` 中时抛出 `ValueError`

---

### 3.3 `report_feedback`

报告某条经验是否有用。

#### Tool Description（Agent 可见）

> Report whether an experience was useful after trying it.
>
> Call after you've attempted a solution from a previous search. Helps improve search quality over time. Earns credit.

#### 参数 JSON Schema

```json
{
  "type": "object",
  "properties": {
    "experience_id": {
      "type": "string",
      "description": "The experience ID from search results"
    },
    "useful": {
      "type": "boolean",
      "description": "True if the experience helped, False if it didn't"
    }
  },
  "required": ["experience_id", "useful"]
}
```

#### 返回值 Schema

```json
{
  "type": "object",
  "properties": {
    "experience_id": {"type": "string"},
    "quality_score": {"type": "number", "description": "Updated score after feedback"},
    "status": {"type": "string", "enum": ["updated"]}
  }
}
```

#### 示例调用与返回

调用：
```json
{
  "experience_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "useful": true
}
```

返回：
```json
{
  "experience_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "quality_score": 0.8,
  "status": "updated"
}
```

#### 验证与错误

- `experience_id` 不存在时抛出 `ValueError: Experience not found: <id>`

---

## 4. HTTP API 接口定义（Phase 2 服务端）

Base URL: `/api/v1`
框架: FastAPI
认证: Bearer Token（所有端点需认证，匿名端点除外）

---

### 4.1 认证机制

#### Bearer Token

所有 API 请求（`/auth/*` 除外）必须包含：

```
Authorization: Bearer <token>
```

Token 格式：
- API Key: `agxp_<key_id>_<secret_hex>`（注册用户）
- Anonymous: `agxp_anon_<session_id>_<secret_hex>`（匿名会话）

Token 中的 secret 部分经 bcrypt 哈希后存储，原始 token 仅在创建时返回一次。

#### 身份模型 (AuthIdentity)

| 字段 | 类型 | 说明 |
|------|------|------|
| `user_id` | string | 用户 ID 或匿名会话 ID |
| `is_anonymous` | bool | 是否匿名 |

匿名用户限制：不可 contribute（返回 403）。

---

### 4.2 `POST /api/v1/auth/anonymous`

创建匿名会话。

#### 请求

无请求体。

#### 响应 (201 Created)

```json
{
  "token": "agxp_anon_550e8400-..._a1b2c3d4e5f6...",
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "credit_balance": 20,
  "expires_at": "2026-05-06T10:00:00+00:00"
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `token` | string | Bearer token（仅返回一次） |
| `session_id` | string (UUID) | 会话 ID |
| `credit_balance` | int | 初始信用额度：20 |
| `expires_at` | string (ISO 8601) | 过期时间（30 天后） |

---

### 4.3 `POST /api/v1/auth/register`

创建注册用户账号。

#### 请求

```json
{
  "email": "user@example.com",
  "password": "securepass123",
  "display_name": "My Agent",
  "anon_session_id": "550e8400-..."
}
```

| 字段 | 类型 | 必填 | 约束 | 说明 |
|------|------|------|------|------|
| `email` | string | 是 | 1-256 chars | 邮箱 |
| `password` | string | 是 | 8-128 chars | 密码 |
| `display_name` | string | 否 | max 256 chars | 显示名称 |
| `anon_session_id` | string | 否 | UUID | 要合并的匿名会话 ID |

#### 响应 (201 Created)

```json
{
  "token": "agxp_a1b2c3d4-..._e5f6a7b8c9d0...",
  "user_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "credit_balance": 70
}
```

`credit_balance` = 50（基础） + 匿名会话余额（如有合并）。

#### 错误响应

| HTTP Status | 场景 | 响应 |
|-------------|------|------|
| 409 | 邮箱已注册 | `{"error": "conflict", "message": "Email already registered"}` |
| 404 | 匿名会话不存在 | `{"error": "not_found", "message": "Anonymous session not found"}` |
| 400 | 匿名会话已合并 | `{"error": "bad_request", "message": "Anonymous session already merged"}` |
| 400 | 匿名会话已过期 | `{"error": "bad_request", "message": "Anonymous session has expired"}` |

---

### 4.4 `POST /api/v1/auth/login`

用户登录。

#### 请求

```json
{
  "email": "user@example.com",
  "password": "securepass123"
}
```

| 字段 | 类型 | 必填 | 约束 | 说明 |
|------|------|------|------|------|
| `email` | string | 是 | 1-256 chars | 邮箱 |
| `password` | string | 是 | 1-128 chars | 密码 |

#### 响应 (200 OK)

```json
{
  "token": "agxp_b2c3d4e5-..._f6a7b8c9d0e1...",
  "user_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}
```

每次登录创建新的 API key。

#### 错误响应

| HTTP Status | 场景 | 响应 |
|-------------|------|------|
| 401 | 邮箱或密码错误 | `{"error": "unauthorized", "message": "Invalid email or password"}` |

---

### 4.5 `POST /api/v1/query`

搜索经验库（服务端完整管线）。

#### 请求

```json
{
  "query": "how to handle rate limiting in async Python",
  "domain": "coding",
  "task_type": "debugging",
  "language": "en",
  "min_quality": 0.0,
  "limit": 10,
  "user_id": null
}
```

| 字段 | 类型 | 必填 | 默认值 | 约束 | 说明 |
|------|------|------|--------|------|------|
| `query` | string | 是 | - | 1-2000 chars | 搜索查询 |
| `domain` | string | 否 | `null` | - | 领域过滤 |
| `task_type` | string | 否 | `null` | - | 任务类型过滤 |
| `language` | string | 否 | `"en"` | - | 语言代码 |
| `min_quality` | float | 否 | `0.0` | - | 最低质量分数过滤 |
| `limit` | int | 否 | `10` | 1-50 | 最大返回数 |
| `user_id` | string | 否 | `null` | - | 用户 ID |

#### 处理管线

1. **EmbeddingBackend** -- 将 query 文本转为 1024 维向量
2. **并行检索** -- BM25 全文搜索 (Tantivy) + 向量检索 (pgvector)
3. **RRF 融合** -- k=60，输出 top-150 候选
4. **DB 查询** -- 获取完整经验数据
5. **min_quality 过滤** -- 按 quality_score 过滤
6. **Cross-encoder Reranking** -- MiniLM 对 top-20 重排
7. **Quality Blending** -- `0.7 * reranker_score + 0.3 * quality_score`
8. **NDJSON 流式输出**

#### 响应 (200 OK, NDJSON streaming)

```
Content-Type: application/x-ndjson
```

第 1 行 -- meta：
```json
{"type": "meta", "query_id": "550e8400-e29b-41d4-a716-446655440000", "latency_ms": 45, "warnings": []}
```

第 2..N 行 -- result：
```json
{"type": "result", "rank": 1, "score": 0.942831, "experience": {"id": "a1b2c3d4-...", "domain": "coding", "task_type": "debugging", "situation": "...", "solution": "...", "lessons": "...", "failed_approaches": "...", "outcome_type": "solved", "language": "en", "tags": ["fastapi", "redis"], "quality_score": 0.87}}
```

最后一行 -- done：
```json
{"type": "done", "total_results": 5}
```

异常时 -- error：
```json
{"type": "error", "message": "Internal pipeline error: ..."}
```

#### NDJSON 行类型

| `type` | 位置 | 字段 |
|--------|------|------|
| `meta` | 第 1 行 | `query_id`, `latency_ms`, `warnings` |
| `result` | 中间行 | `rank`, `score`, `experience` |
| `done` | 最后一行 | `total_results` |
| `error` | 异常时 | `message` |

#### result.experience 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | string (UUID) | 经验 ID |
| `domain` | string | 领域 |
| `task_type` | string | 任务类型 |
| `situation` | string | 问题描述 |
| `solution` | string | 解决方案 |
| `lessons` | string | 经验教训 |
| `failed_approaches` | string \| null | 失败尝试 |
| `outcome_type` | string | 结果类型 |
| `language` | string | 语言 |
| `tags` | list[string] | 标签（空列表而非 null） |
| `quality_score` | float \| null | 质量分数 |

---

### 4.6 `POST /api/v1/contribute`

提交新经验。

#### 请求

```json
{
  "situation": "FastAPI endpoint needed rate limiting without blocking the async event loop. Standard sync approaches would block other requests during rate check.",
  "solution": "Created Redis-based token bucket using INCR+EXPIRE in a single pipeline. Used asyncio-redis client to avoid blocking.",
  "outcome_type": "solved",
  "lessons": "Redis INCR+EXPIRE is only atomic when both commands are sent in a single pipeline.",
  "domain": "coding",
  "task_type": "debugging",
  "language": "en",
  "failed_approaches": "Tried threading.Lock — blocked the async event loop entirely.",
  "environment": {"language": "python", "framework": "fastapi", "version": "0.115"},
  "subdomain": "python",
  "tags": ["fastapi", "redis", "rate-limiting"]
}
```

| 字段 | 类型 | 必填 | 约束 | 说明 |
|------|------|------|------|------|
| `situation` | string | 是 | 50-4000 chars | 问题描述 |
| `solution` | string | 是 | 50-4000 chars | 解决方案 |
| `outcome_type` | enum | 是 | `solved` \| `workaround` \| `unresolved` | 结果类型 |
| `lessons` | string | 是 | 30-2000 chars | 经验教训 |
| `domain` | string | 是 | max 64 chars | 领域 |
| `task_type` | string | 是 | max 64 chars | 任务类型 |
| `language` | string | 是 | max 8 chars | 语言代码 |
| `failed_approaches` | string | 否 | max 4000 chars | 失败尝试 |
| `environment` | object | 否 | - | 环境信息 |
| `subdomain` | string | 否 | max 64 chars | 子领域 |
| `tags` | list[string] | 否 | max 10 items, 每个 max 32 chars | 标签 |

#### 处理流程

1. **认证检查** -- 匿名用户返回 403
2. **持久化** -- 插入 PostgreSQL `experiences` 表
3. **FTS 索引** -- Tantivy BM25 索引（同步，进程内）
4. **异步管线** -- 派发 Celery `embed_experience` 任务（embedding + quality scoring）
5. **估算信用** -- 基于 completeness score 估算信用奖励

#### 响应 (202 Accepted)

```json
{
  "experience_id": "550e8400-e29b-41d4-a716-446655440001",
  "status": "pending_scoring",
  "estimated_credits": 10,
  "message": "Experience accepted. Embedding and quality scoring in progress."
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `experience_id` | string (UUID) | 新经验 ID |
| `status` | string | 固定为 `"pending_scoring"` |
| `estimated_credits` | int | 预估信用奖励 |
| `message` | string | 状态说明 |

#### 信用奖励等级

| quality_score 范围 | 信用奖励 |
|--------------------|----------|
| [0, 0.5) | 5 |
| [0.5, 0.7) | 10 |
| [0.7, 0.85) | 25 |
| [0.85, 1.0] | 50 |

#### 错误响应

| HTTP Status | 场景 | 响应 |
|-------------|------|------|
| 403 | 匿名用户 contribute | `{"error": "forbidden", "message": "Anonymous users cannot contribute experiences."}` |
| 422 | Pydantic 验证失败 | FastAPI 标准验证错误格式 |

---

## 5. 接口间调用关系图

```
                     ┌──────────────┐
                     │  Agent/User  │
                     └──┬───┬───┬───┘
                        │   │   │
              ┌─────────┘   │   └─────────┐
              ▼             ▼             ▼
       ┌──────────┐  ┌──────────┐  ┌──────────────┐
       │   CLI    │  │   MCP    │  │  HTTP Client  │
       │  (Typer) │  │ (FastMCP)│  │   (Future)    │
       └────┬─────┘  └────┬─────┘  └──────┬────────┘
            │              │               │
            │  ┌───────────┘               │
            │  │                           │
            ▼  ▼                           ▼
       ┌────────────┐              ┌───────────────┐
       │ SqliteStore │              │  FastAPI App   │
       │   + FTS5    │              │  /api/v1/*     │
       │             │              └───────┬───────┘
       │ (Phase 1)   │                      │
       └─────────────┘               ┌──────┴──────┐
                                     ▼             ▼
                              ┌───────────┐  ┌──────────┐
                              │ Pipeline   │  │  Auth    │
                              │ (RRF+Rerank│  │ (bcrypt) │
                              └─────┬──────┘  └──────────┘
                                    │
                          ┌─────────┼─────────┐
                          ▼         ▼         ▼
                   ┌──────────┐ ┌───────┐ ┌────────┐
                   │ Embedding│ │  FTS  │ │ Vector │
                   │ (BgeM3)  │ │(Tantivy│ │(pgvec) │
                   └──────────┘ └───────┘ └────────┘
                                    │
                                    ▼
                            ┌───────────────┐
                            │  PostgreSQL    │
                            │  + pgvector    │
                            │  (Phase 2)     │
                            └───────────────┘
```

### 调用路径明细

| 路径 | 阶段 | 说明 |
|------|------|------|
| CLI --> SqliteStore | Phase 1 | 直接同步调用，单进程 |
| MCP --> SqliteStore | Phase 1 | MCP 工具内同步调用 SqliteStore |
| CLI --> MCP Server (stdio) | Phase 1 | `agxp mcp` 启动后，Agent 通过 stdio JSON-RPC 调用 |
| HTTP Client --> FastAPI --> Pipeline --> Backends | Phase 2 | 完整异步管线，含 embedding + vector + reranker |
| Contribute --> Celery --> Embedding + Quality | Phase 2 | 异步后台任务 |

---

## 6. 数据格式定义

### 6.1 Experience 数据模型

#### 本地 SQLite Schema

```sql
CREATE TABLE experiences (
    id TEXT PRIMARY KEY,                    -- UUID v4 string
    domain TEXT NOT NULL,                   -- 领域
    subdomain TEXT,                         -- 子领域
    task_type TEXT NOT NULL,                -- 任务类型
    situation TEXT NOT NULL,                -- 问题描述
    failed_approaches TEXT,                 -- 失败尝试
    solution TEXT NOT NULL,                 -- 解决方案
    outcome_type TEXT NOT NULL              -- solved|workaround|unresolved
        CHECK(outcome_type IN ('solved','workaround','unresolved')),
    lessons TEXT NOT NULL,                  -- 经验教训
    environment TEXT,                       -- JSON string（dict 序列化）
    tags TEXT,                              -- JSON string（list 序列化）
    language TEXT NOT NULL DEFAULT 'en',    -- 语言代码
    quality_score REAL NOT NULL DEFAULT 0.0,-- 质量分数 [0.0, 1.0]
    created_at TEXT NOT NULL,               -- ISO 8601 UTC
    updated_at TEXT NOT NULL                -- ISO 8601 UTC
);
```

#### FTS5 虚拟表

```sql
CREATE VIRTUAL TABLE experiences_fts USING fts5(
    situation, solution, lessons, failed_approaches, tags,
    content=experiences, content_rowid=rowid,
    tokenize='unicode61'
);
```

通过 `AFTER INSERT/UPDATE/DELETE` 触发器自动同步。

#### search_log 表

```sql
CREATE TABLE search_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    experience_id TEXT NOT NULL,            -- 关联的经验 ID
    searched_at TEXT NOT NULL,              -- ISO 8601 UTC
    feedback_given INTEGER NOT NULL DEFAULT 0  -- 0=pending, 1=given
);
```

#### Experience JSON Schema（完整）

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "required": ["domain", "task_type", "situation", "solution", "outcome_type", "lessons"],
  "properties": {
    "id": {
      "type": "string",
      "format": "uuid",
      "description": "UUID v4, auto-generated on contribute"
    },
    "domain": {
      "type": "string",
      "maxLength": 64,
      "examples": ["coding", "devops", "security", "research"]
    },
    "subdomain": {
      "type": ["string", "null"],
      "maxLength": 64,
      "examples": ["python", "kubernetes", "asyncio"]
    },
    "task_type": {
      "type": "string",
      "maxLength": 64,
      "examples": ["debugging", "refactoring", "deployment", "config"]
    },
    "situation": {
      "type": "string",
      "minLength": 50,
      "maxLength": 4000,
      "description": "Problem description and context"
    },
    "failed_approaches": {
      "type": ["string", "null"],
      "maxLength": 4000,
      "description": "What was tried and didn't work"
    },
    "solution": {
      "type": "string",
      "minLength": 50,
      "maxLength": 4000,
      "description": "What actually worked"
    },
    "outcome_type": {
      "type": "string",
      "enum": ["solved", "workaround", "unresolved"]
    },
    "lessons": {
      "type": "string",
      "minLength": 30,
      "maxLength": 2000,
      "description": "Transferable insight or root cause"
    },
    "environment": {
      "type": ["object", "null"],
      "description": "Runtime environment key-value pairs",
      "examples": [{"os": "linux", "python": "3.11", "framework": "fastapi"}]
    },
    "tags": {
      "type": ["array", "null"],
      "items": {"type": "string", "maxLength": 32},
      "maxItems": 10,
      "description": "Keyword tags for discoverability"
    },
    "language": {
      "type": "string",
      "maxLength": 8,
      "default": "en",
      "examples": ["en", "zh", "de"]
    },
    "quality_score": {
      "type": "number",
      "minimum": 0.0,
      "maximum": 1.0,
      "default": 0.0,
      "description": "Computed at contribute time, updated by feedback"
    },
    "created_at": {
      "type": "string",
      "format": "date-time"
    },
    "updated_at": {
      "type": "string",
      "format": "date-time"
    }
  }
}
```

### 6.2 NDJSON 输出格式规范

NDJSON (Newline-Delimited JSON)：每行一个完整 JSON 对象，以 `\n` 分隔。

#### CLI 查询输出（stdout）

每行一个搜索结果，无 meta/done 包装：

```jsonl
{"experience_id": "...", "domain": "coding", "task_type": "debugging", "situation": "...", "solution": "...", ...}
{"experience_id": "...", "domain": "coding", "task_type": "refactoring", "situation": "...", "solution": "...", ...}
```

字段名差异：CLI 输出使用 `experience_id`（非 `id`），且不包含 `updated_at`。

#### HTTP API 查询输出（streaming response）

三段式结构：meta --> result(s) --> done

```jsonl
{"type": "meta", "query_id": "...", "latency_ms": 45, "warnings": []}
{"type": "result", "rank": 1, "score": 0.94, "experience": {...}}
{"type": "result", "rank": 2, "score": 0.81, "experience": {...}}
{"type": "done", "total_results": 2}
```

### 6.3 pending_feedback 格式

pending_feedback 出现在搜索返回结果中（CLI stderr / MCP 返回值），提醒 Agent 对之前搜索到的经验给出反馈。

#### 结构

```json
{
  "pending_feedback": [
    {
      "experience_id": "a1b2c3d4-...",
      "situation": "FastAPI endpoint needed rate limiting..."
    }
  ],
  "pending_feedback_hint": "You received these experiences in a previous search. If you actually tried any and saw the result (success or failure), please call report_feedback(experience_id, useful=true/false) for each. Skip any experiences you did not use — do not guess."
}
```

#### 生成逻辑

- 来源：`search_log` 表中 `feedback_given=0` 且 `searched_at` 在 24 小时内的记录
- 去重：`DISTINCT` on `experience_id`
- 排序：最近搜索的在前
- 上限：最多 5 条
- 清理：每次查询前自动清理 24 小时以上的 search_log 记录

### 6.4 错误响应格式

#### CLI 错误（stderr）

```
Error: not initialized. Run: agxp init --data-dir ~/.agxp
Error: invalid outcome_type 'invalid'. Must be one of: solved, unresolved, workaround
Error: invalid JSON in --environment: Expecting value: line 1 column 1 (char 0)
Error: --environment must be a JSON object, got list
Error: specify --useful or --not-useful
Error: experience not found: a1b2c3d4-...
```

#### HTTP API 错误（JSON）

FastAPI 标准验证错误 (422):
```json
{
  "detail": [
    {
      "type": "string_too_short",
      "loc": ["body", "situation"],
      "msg": "String should have at least 50 characters",
      "input": "too short",
      "ctx": {"min_length": 50}
    }
  ]
}
```

业务错误:
```json
{
  "error": "forbidden",
  "message": "Anonymous users cannot contribute experiences."
}
```

认证错误:
```json
{
  "error": "unauthorized",
  "message": "Invalid email or password"
}
```

冲突错误:
```json
{
  "error": "conflict",
  "message": "Email already registered"
}
```

#### MCP 错误

MCP 工具内的错误通过 Python 异常传播，FastMCP 框架将其转为 JSON-RPC error response：

- `FileNotFoundError` -- 数据库不存在
- `ValueError` -- 参数校验失败（如无效 outcome_type、经验不存在）

---

## 7. 错误码与错误处理

### 7.1 CLI 退出码

| 退出码 | 含义 | 触发场景 |
|--------|------|----------|
| 0 | 成功 | 正常完成 |
| 1 | 用户错误 | 未初始化、参数无效、经验不存在 |

注意：当前实现仅使用 0 和 1。Phase 2 CLI（远程模式）将扩展为更细粒度的退出码（见 `docs/API.md`）。

### 7.2 HTTP Status Codes

| Status | 场景 |
|--------|------|
| 200 | 查询成功（NDJSON streaming） |
| 201 | 认证端点创建成功（anonymous/register） |
| 202 | Contribute 接受（后台处理中） |
| 400 | 请求参数错误（匿名会话已合并/过期） |
| 401 | 认证失败（无效邮箱或密码） |
| 403 | 权限不足（匿名用户 contribute） |
| 404 | 资源不存在（匿名会话不存在） |
| 409 | 冲突（邮箱已注册） |
| 422 | Pydantic 验证失败 |

### 7.3 MCP 错误处理

| 异常类型 | 触发场景 | 用户可见信息 |
|----------|----------|-------------|
| `FileNotFoundError` | `agxp init` 未运行 | "AGXP data directory not configured. Run: agxp init" |
| `FileNotFoundError` | 数据库文件不存在 | "Database not found at {path}. Run: agxp init --data-dir {dir}" |
| `ValueError` | 无效 outcome_type | "Invalid outcome_type 'xyz'. Must be one of: solved, unresolved, workaround" |
| `ValueError` | 经验不存在 | "Experience not found: {id}" |

### 7.4 常见错误场景

| 场景 | CLI 表现 | MCP 表现 | HTTP 表现 |
|------|----------|----------|-----------|
| 未初始化 | stderr + exit 1 | FileNotFoundError | N/A (server has its own DB) |
| 无效 outcome_type | stderr + exit 1 | ValueError | 422 (Pydantic enum) |
| 空查询文本 | 返回空结果 | 返回空 results | 422 (min_length=1) |
| 经验不存在（feedback） | stderr + exit 1 | ValueError | N/A (planned) |
| 匿名用户 contribute | N/A (local) | N/A (local) | 403 Forbidden |

---

## 8. 未来接口

### 8.1 `POST /api/v1/feedback`（服务端）

服务端反馈端点，当前尚未实现。将支持基于 query_id 的批量反馈：

```json
{
  "query_id": "550e8400-...",
  "results": [
    {"experience_id": "...", "position": 1, "was_useful": true},
    {"experience_id": "...", "position": 2, "was_useful": false}
  ]
}
```

预期响应：`204 No Content`

### 8.2 MCP 远程回退（Remote Fallback）

当前 MCP 工具仅连接本地 SqliteStore。未来计划：

- 当本地搜索结果不足时，自动 fallback 到远程 HTTP API
- 需要在 MCP server 中配置远程服务器 URL 和 token
- 合并本地 + 远程结果后返回给 Agent

### 8.3 服务端投票接口

`POST /api/v1/vote` -- 对经验质量投票（upvote/downvote），影响 quality_score 和贡献者信用。详见 `docs/API.md`。

### 8.4 信用系统接口

- `GET /api/v1/credits/status` -- 查询信用余额和等级
- `GET /api/v1/credits/history` -- 查询交易历史

### 8.5 CLI 远程模式

`pip install agxp[server]` 安装后，CLI 命令将支持远程模式，通过 HTTP API 连接到 AGXP 服务器。退出码将扩展为更细粒度（见 7.1 节）。
