"""
Issue #18 — Phase 2 Server E2E Integration Tests.

22 tests covering API layer → auth → DB → search backends → NDJSON response.
Complements the 14 tests in tests/integration/test_auth/ (Issue #19).

Requires:
  - PostgreSQL running at localhost:5433 with pgvector extension
  - Database "agxp" with schema applied
  - Redis running at localhost:6379

Heavy backends (BgeM3, MiniLM cross-encoder) are replaced by fakes via conftest.
"""
from __future__ import annotations

import json
import uuid

import pytest
import pytest_asyncio

from tests.integration.test_api.conftest import (
    create_test_anon,
    create_test_user,
    make_contribute_payload,
    unique_email,
)


# ============================================================================
# Helpers
# ============================================================================


def _parse_ndjson(response) -> list[dict]:
    """Parse an NDJSON response body into a list of dicts."""
    lines = response.text.strip().split("\n")
    return [json.loads(line) for line in lines if line.strip()]


def _auth_header(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


# ============================================================================
# 3.1 User Registration Full Flow (3 tests)
# ============================================================================


class TestUserRegistrationFlow:
    """Register → contribute, anon → register merge, login → query."""

    def test_register_then_contribute(self, client):
        """POST /auth/register → use token to POST /contribute → 202."""
        user = create_test_user(client)

        resp = client.post(
            "/api/v1/contribute",
            json=make_contribute_payload(),
            headers=_auth_header(user["token"]),
        )
        assert resp.status_code == 202, f"Expected 202, got {resp.status_code}: {resp.text}"
        body = resp.json()
        assert "experience_id" in body
        assert body["status"] == "pending_scoring"

    def test_anonymous_then_register_merge(self, client):
        """Anon → query → register(anon_session_id) → credits = 50 + 20."""
        anon = create_test_anon(client)

        # Query as anonymous (consumes 0 explicit credits here, just exercises flow)
        client.post(
            "/api/v1/query",
            json={"query": "test merge query", "language": "en"},
            headers=_auth_header(anon["token"]),
        )

        # Register with merge
        email = unique_email()
        reg_resp = client.post(
            "/api/v1/auth/register",
            json={
                "email": email,
                "password": "securepassword123",
                "anon_session_id": anon["session_id"],
            },
        )
        assert reg_resp.status_code == 201
        body = reg_resp.json()
        # 50 base + 20 anon credits
        assert body["credit_balance"] == 70

    def test_login_token_works_on_query(self, client):
        """Register → login → use login token to POST /query → not 401."""
        email = unique_email()
        client.post(
            "/api/v1/auth/register",
            json={"email": email, "password": "securepassword123"},
        )
        login_resp = client.post(
            "/api/v1/auth/login",
            json={"email": email, "password": "securepassword123"},
        )
        assert login_resp.status_code == 200
        token = login_resp.json()["token"]

        query_resp = client.post(
            "/api/v1/query",
            json={"query": "login token test", "language": "en"},
            headers=_auth_header(token),
        )
        assert query_resp.status_code == 200


# ============================================================================
# 3.2 Contribute API E2E (4 tests)
# ============================================================================


class TestContributeAPI:
    """Contribute endpoint: DB row, estimated credits, FTS indexing, validation."""

    async def test_contribute_creates_db_row(self, client, pool):
        """Valid contribute → 202, DB row exists with matching domain."""
        user = create_test_user(client)
        payload = make_contribute_payload(domain="cloud")

        resp = client.post(
            "/api/v1/contribute",
            json=payload,
            headers=_auth_header(user["token"]),
        )
        assert resp.status_code == 202
        exp_id = resp.json()["experience_id"]

        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT domain, user_id FROM experiences WHERE id = $1",
                uuid.UUID(exp_id),
            )
        assert row is not None, f"Experience {exp_id} not found in DB"
        assert row["domain"] == "cloud"
        assert str(row["user_id"]) == user["user_id"]

    def test_contribute_returns_estimated_credits(self, client):
        """202 response includes estimated_credits > 0."""
        user = create_test_user(client)

        resp = client.post(
            "/api/v1/contribute",
            json=make_contribute_payload(),
            headers=_auth_header(user["token"]),
        )
        assert resp.status_code == 202
        body = resp.json()
        assert "estimated_credits" in body
        assert body["estimated_credits"] > 0

    def test_contribute_indexes_in_fts(self, client):
        """After contribute, FakeFTSBackend.search finds the experience."""
        user = create_test_user(client)
        # Use unique text to avoid cross-test collisions
        unique_term = f"xyzzy{uuid.uuid4().hex[:6]}"
        payload = make_contribute_payload(
            situation=f"The {unique_term} problem requires debugging " + "a " * 20,
        )

        resp = client.post(
            "/api/v1/contribute",
            json=payload,
            headers=_auth_header(user["token"]),
        )
        assert resp.status_code == 202
        exp_id = resp.json()["experience_id"]

        # Verify FTS backend has the document
        import asyncio
        fts = client._fake_fts  # type: ignore[attr-defined]
        assert exp_id in fts._store, "Experience was not indexed in FTS backend"
        assert unique_term in fts._store[exp_id].get("situation", "")

    def test_contribute_validates_request(self, client):
        """Missing required field → 422."""
        user = create_test_user(client)

        # Missing 'solution' field
        payload = {
            "situation": "A " * 30,
            "outcome_type": "solved",
            "lessons": "C " * 20,
            "domain": "python",
            "task_type": "debugging",
            "language": "en",
        }
        resp = client.post(
            "/api/v1/contribute",
            json=payload,
            headers=_auth_header(user["token"]),
        )
        assert resp.status_code == 422


# ============================================================================
# 3.3 Query API E2E (5 tests)
# ============================================================================


class TestQueryAPI:
    """Query endpoint: NDJSON stream format, meta/result/done lines."""

    def test_query_returns_ndjson_stream(self, client):
        """Valid query request → 200 with application/x-ndjson content type."""
        user = create_test_user(client)

        resp = client.post(
            "/api/v1/query",
            json={"query": "how to fix memory leak", "language": "en"},
            headers=_auth_header(user["token"]),
        )
        assert resp.status_code == 200
        assert "application/x-ndjson" in resp.headers.get("content-type", "")

    def test_query_ndjson_has_meta_results_done(self, client):
        """NDJSON response has meta line, zero or more result lines, and done line."""
        user = create_test_user(client)

        resp = client.post(
            "/api/v1/query",
            json={"query": "debugging", "language": "en"},
            headers=_auth_header(user["token"]),
        )
        assert resp.status_code == 200
        lines = _parse_ndjson(resp)
        assert len(lines) >= 2, f"Expected at least meta + done, got {len(lines)} lines"

        types = [line["type"] for line in lines]
        assert types[0] == "meta", f"First line should be meta, got {types[0]}"
        assert types[-1] == "done", f"Last line should be done, got {types[-1]}"

    def test_query_meta_has_warnings_field(self, client):
        """Meta line contains warnings field (list)."""
        user = create_test_user(client)

        resp = client.post(
            "/api/v1/query",
            json={"query": "test warnings field", "language": "en"},
            headers=_auth_header(user["token"]),
        )
        lines = _parse_ndjson(resp)
        meta = lines[0]
        assert meta["type"] == "meta"
        assert "warnings" in meta
        assert isinstance(meta["warnings"], list)

    def test_query_result_contains_experience_fields(self, client):
        """Result lines contain situation/solution/lessons in experience object."""
        user = create_test_user(client)

        # First contribute something so there's a result to find
        unique_term = f"memoryleak{uuid.uuid4().hex[:6]}"
        payload = make_contribute_payload(
            situation=f"Debugging {unique_term} in production service " + "x " * 15,
            solution=f"Fixed {unique_term} by adding connection pooling " + "y " * 15,
            lessons=f"Always monitor {unique_term} connections in prod",
        )
        contrib_resp = client.post(
            "/api/v1/contribute",
            json=payload,
            headers=_auth_header(user["token"]),
        )
        assert contrib_resp.status_code == 202

        # Query for it
        resp = client.post(
            "/api/v1/query",
            json={"query": unique_term, "language": "en"},
            headers=_auth_header(user["token"]),
        )
        lines = _parse_ndjson(resp)
        result_lines = [l for l in lines if l["type"] == "result"]
        assert len(result_lines) >= 1, "Expected at least one result"

        exp = result_lines[0]["experience"]
        assert "situation" in exp
        assert "solution" in exp
        assert "lessons" in exp
        assert unique_term in exp["situation"]

    def test_query_empty_corpus_returns_zero_results(self, client):
        """Query with no matching content → done.total_results == 0."""
        user = create_test_user(client)

        # Query for something that doesn't exist
        resp = client.post(
            "/api/v1/query",
            json={"query": f"nonexistent{uuid.uuid4().hex}", "language": "en"},
            headers=_auth_header(user["token"]),
        )
        lines = _parse_ndjson(resp)
        done_line = [l for l in lines if l["type"] == "done"][0]
        assert done_line["total_results"] == 0


# ============================================================================
# 3.4 Contribute → Query Loop (2 tests)
# ============================================================================


class TestContributeQueryLoop:
    """End-to-end contribute → query integration."""

    def test_contribute_then_query_finds_experience(self, client):
        """Contribute an experience → query with matching text → result contains experience_id."""
        user = create_test_user(client)
        unique_term = f"asyncio{uuid.uuid4().hex[:6]}"

        payload = make_contribute_payload(
            situation=f"Problem with {unique_term} in event loop handling " + "a " * 15,
            solution=f"Resolved {unique_term} by using proper context managers " + "b " * 10,
            lessons=f"Lesson: always handle {unique_term} lifecycle",
        )
        contrib_resp = client.post(
            "/api/v1/contribute",
            json=payload,
            headers=_auth_header(user["token"]),
        )
        assert contrib_resp.status_code == 202
        exp_id = contrib_resp.json()["experience_id"]

        # Query for the unique term — FakeFTSBackend does substring match
        query_resp = client.post(
            "/api/v1/query",
            json={"query": unique_term, "language": "en"},
            headers=_auth_header(user["token"]),
        )
        assert query_resp.status_code == 200
        lines = _parse_ndjson(query_resp)
        result_ids = [l["experience"]["id"] for l in lines if l["type"] == "result"]
        assert exp_id in result_ids, (
            f"Expected {exp_id} in results, got {result_ids}"
        )

    def test_contribute_then_query_with_domain_filter(self, client):
        """Contribute(domain=python) → query(domain=python) finds it; query(domain=rust) doesn't."""
        user = create_test_user(client)
        unique_term = f"domainfilter{uuid.uuid4().hex[:6]}"

        payload = make_contribute_payload(
            domain="python",
            situation=f"The {unique_term} scenario in Python codebase " + "a " * 15,
            solution=f"Fixed {unique_term} using standard Python patterns " + "b " * 10,
            lessons=f"Lesson from {unique_term}: follow PEP conventions",
        )
        contrib_resp = client.post(
            "/api/v1/contribute",
            json=payload,
            headers=_auth_header(user["token"]),
        )
        assert contrib_resp.status_code == 202
        exp_id = contrib_resp.json()["experience_id"]

        # Query with matching domain
        resp_python = client.post(
            "/api/v1/query",
            json={"query": unique_term, "domain": "python", "language": "en"},
            headers=_auth_header(user["token"]),
        )
        lines_python = _parse_ndjson(resp_python)
        result_ids_python = [l["experience"]["id"] for l in lines_python if l["type"] == "result"]
        assert exp_id in result_ids_python, (
            f"Expected {exp_id} in python-domain results"
        )

        # Query with non-matching domain — FakeFTSBackend ignores filters,
        # but FakeVectorBackend also ignores filters. The result may still
        # appear due to fake backends. We verify the filter param is accepted
        # without error.
        resp_rust = client.post(
            "/api/v1/query",
            json={"query": unique_term, "domain": "rust", "language": "en"},
            headers=_auth_header(user["token"]),
        )
        assert resp_rust.status_code == 200
        # NOTE: Fake backends don't enforce domain filters. Real PgvectorBackend
        # and TantivyBackend do. This test verifies the API accepts the filter
        # parameter and processes it without error. Full filter enforcement is
        # covered by backend-specific integration tests.


# ============================================================================
# 3.5 Auth Integration (5 tests)
# ============================================================================


class TestAuthIntegration:
    """Auth enforcement on API endpoints."""

    def test_auth_registered_token_succeeds(self, client):
        """Token from /auth/register works on /query."""
        user = create_test_user(client)

        resp = client.post(
            "/api/v1/query",
            json={"query": "auth token test", "language": "en"},
            headers=_auth_header(user["token"]),
        )
        assert resp.status_code == 200

    def test_auth_no_bearer_returns_401(self, client):
        """No Authorization header → 401."""
        resp = client.post(
            "/api/v1/query",
            json={"query": "no auth", "language": "en"},
        )
        assert resp.status_code == 401
        body = resp.json()
        assert body["error"] == "unauthorized"

    def test_auth_invalid_token_returns_401(self, client):
        """Bearer garbage → 401."""
        resp = client.post(
            "/api/v1/query",
            json={"query": "bad token", "language": "en"},
            headers={"Authorization": "Bearer totally_invalid_garbage_token"},
        )
        assert resp.status_code == 401

    async def test_auth_revoked_key_returns_401(self, client, pool):
        """Revoked API key → 401."""
        user = create_test_user(client)

        # Revoke all keys for this user in DB
        async with pool.acquire() as conn:
            await conn.execute(
                "UPDATE api_keys SET revoked_at = NOW() WHERE user_id = $1",
                uuid.UUID(user["user_id"]),
            )

        resp = client.post(
            "/api/v1/query",
            json={"query": "revoked key test", "language": "en"},
            headers=_auth_header(user["token"]),
        )
        assert resp.status_code == 401

    def test_auth_anonymous_contribute_returns_403(self, client):
        """Anonymous token + POST /contribute → 403."""
        anon = create_test_anon(client)

        resp = client.post(
            "/api/v1/contribute",
            json=make_contribute_payload(),
            headers=_auth_header(anon["token"]),
        )
        assert resp.status_code == 403
        body = resp.json()
        assert body["error"] == "forbidden"


# ============================================================================
# 3.6 Celery Embed Task E2E (2 tests)
# ============================================================================


class TestCeleryEmbedTask:
    """Verify contribute triggers embed dispatch and DB row is created correctly.

    Note: Direct async calls to _embed_experience_async fail due to event loop
    mismatch (TestClient runs its own loop). Instead, we verify:
    1. The contribute endpoint triggers dispatch_embed (mocked as no-op in conftest)
    2. The DB row exists with NULL embeddings (pre-embed state)
    3. The estimated_credits response confirms quality scoring pipeline is wired
    """

    def test_contribute_dispatches_embed_and_creates_row(self, client):
        """Contribute creates DB row; dispatch_embed was called (mocked)."""
        from unittest.mock import MagicMock, patch

        mock_dispatch = MagicMock()

        with patch("agxp.api.routes.contribute.dispatch_embed", mock_dispatch):
            user = create_test_user(client)
            resp = client.post(
                "/api/v1/contribute",
                json=make_contribute_payload(),
                headers=_auth_header(user["token"]),
            )

        assert resp.status_code == 202
        exp_id = resp.json()["experience_id"]

        # dispatch_embed was called with (experience_id, user_id)
        mock_dispatch.assert_called_once()
        call_args = mock_dispatch.call_args
        assert call_args[0][0] == exp_id
        assert call_args[0][1] == user["user_id"]

    async def test_contribute_row_has_null_embeddings_before_worker(self, client, pool):
        """Before Celery worker runs, embeddings are NULL and quality_score is 0."""
        user = create_test_user(client)
        resp = client.post(
            "/api/v1/contribute",
            json=make_contribute_payload(
                failed_approaches="Tried restarting the service but it did not help " + "x " * 15,
                environment={"os": "linux", "python": "3.11"},
                tags=["debugging", "memory"],
            ),
            headers=_auth_header(user["token"]),
        )
        assert resp.status_code == 202
        exp_id = resp.json()["experience_id"]

        # Verify pre-embed state in DB
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT embedding_situation, quality_score FROM experiences WHERE id = $1",
                uuid.UUID(exp_id),
            )
        assert row is not None
        assert row["embedding_situation"] is None, "embeddings should be NULL before worker"
        assert float(row["quality_score"]) == 0.0, "quality_score should be 0.0 before scoring"


# ============================================================================
# 3.7 Degradation Warning (1 test)
# ============================================================================


class TestDegradationWarning:
    """Query pipeline degradation produces warnings in NDJSON meta."""

    def test_query_with_degradation_shows_warnings(self, client):
        """When vector search returns empty, meta.warnings is non-empty."""
        user = create_test_user(client)

        # Contribute something so BM25 finds it but vector returns empty
        unique_term = f"degradation{uuid.uuid4().hex[:6]}"
        payload = make_contribute_payload(
            situation=f"Testing {unique_term} warning scenario " + "a " * 20,
        )
        client.post(
            "/api/v1/contribute",
            json=payload,
            headers=_auth_header(user["token"]),
        )

        # The FakeVectorBackend has nothing upserted (dispatch_embed is mocked to no-op),
        # so vector search will return empty results. The pipeline should emit a warning
        # about vector returning 0 results (embeddings not generated yet).
        resp = client.post(
            "/api/v1/query",
            json={"query": unique_term, "language": "en"},
            headers=_auth_header(user["token"]),
        )
        assert resp.status_code == 200
        lines = _parse_ndjson(resp)
        meta = lines[0]
        assert meta["type"] == "meta"
        assert len(meta["warnings"]) > 0, (
            f"Expected degradation warnings, got empty: {meta['warnings']}"
        )
