"""
Shared fixtures for Issue #18 — Server E2E integration tests.

Provides:
  - asyncpg pool (session scope) for direct DB verification
  - TestClient with mocked heavy backends (no BgeM3, no MiniLM cross-encoder)
  - create_test_user / create_test_anon helpers
  - autouse cleanup fixture (function scope, test-e2e- email prefix)
"""
from __future__ import annotations

import os
import uuid

import asyncpg
import pytest
import pytest_asyncio

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+asyncpg://agxp:agxp@localhost:5433/agxp",
)
DSN = DATABASE_URL.replace("postgresql+asyncpg://", "postgresql://", 1)


# ---------------------------------------------------------------------------
# Session-scoped asyncpg pool for DB assertions
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture(scope="module", loop_scope="session")
async def pool():
    """Raw asyncpg pool for direct DB verification queries."""
    p = await asyncpg.create_pool(DSN, min_size=1, max_size=3)
    yield p
    await p.close()


# ---------------------------------------------------------------------------
# TestClient with mocked heavy backends
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def client():
    """
    FastAPI TestClient with heavy backends replaced by fakes.

    Mocks applied BEFORE app import resolves backends:
      - EMBED_BACKEND  → FakeEmbeddingBackend
      - VECTOR_BACKEND → FakeVectorBackend
      - reranker in _get_pipeline → FakeCrossEncoder
      - dispatch_embed  → no-op (skip Celery)
    """
    from unittest.mock import patch

    from tests.utils.backends.fake_embedding_backend import FakeEmbeddingBackend
    from tests.utils.backends.fake_fts_backend import FakeFTSBackend
    from tests.utils.backends.fake_vector_backend import FakeVectorBackend
    from tests.utils.backends.fake_reranker import FakeCrossEncoder
    from agxp.search.query_pipeline import QueryPipeline

    fake_embed = FakeEmbeddingBackend()
    fake_vector = FakeVectorBackend()
    fake_fts = FakeFTSBackend()
    fake_reranker = FakeCrossEncoder()

    pipeline = QueryPipeline(
        embed_backend=fake_embed,
        vector_backend=fake_vector,
        fts_backend=fake_fts,
        reranker=fake_reranker,
    )

    with (
        patch("agxp.config.backends.EMBED_BACKEND", fake_embed),
        patch("agxp.config.backends.VECTOR_BACKEND", fake_vector),
        patch("agxp.config.backends.FTS_BACKEND", fake_fts),
        patch("agxp.api.routes.query.PIPELINE", pipeline),
        patch("agxp.api.routes.contribute.dispatch_embed", lambda *a, **kw: None),
    ):
        from agxp.api.app import app
        from fastapi.testclient import TestClient

        with TestClient(app, raise_server_exceptions=False) as c:
            # Attach fake backends for tests that need direct access
            c._fake_fts = fake_fts  # type: ignore[attr-defined]
            c._fake_vector = fake_vector  # type: ignore[attr-defined]
            c._fake_embed = fake_embed  # type: ignore[attr-defined]
            c._pipeline = pipeline  # type: ignore[attr-defined]
            yield c


# ---------------------------------------------------------------------------
# Cleanup (autouse, function scope)
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture(autouse=True, loop_scope="session")
async def _cleanup(pool):
    """Delete test-e2e- rows after each test in dependency order."""
    yield
    async with pool.acquire() as conn:
        await conn.execute(
            "DELETE FROM credit_transactions WHERE account_id IN "
            "(SELECT id FROM credit_accounts WHERE user_id IN "
            "(SELECT id FROM users WHERE email LIKE 'test-e2e-%'))"
        )
        await conn.execute(
            "DELETE FROM credit_accounts WHERE user_id IN "
            "(SELECT id FROM users WHERE email LIKE 'test-e2e-%')"
        )
        await conn.execute(
            "DELETE FROM search_feedback WHERE experience_id IN "
            "(SELECT id FROM experiences WHERE user_id IN "
            "(SELECT id FROM users WHERE email LIKE 'test-e2e-%'))"
        )
        await conn.execute(
            "DELETE FROM quality_votes WHERE experience_id IN "
            "(SELECT id FROM experiences WHERE user_id IN "
            "(SELECT id FROM users WHERE email LIKE 'test-e2e-%'))"
        )
        await conn.execute(
            "DELETE FROM experiences WHERE user_id IN "
            "(SELECT id FROM users WHERE email LIKE 'test-e2e-%')"
        )
        await conn.execute(
            "DELETE FROM api_keys WHERE user_id IN "
            "(SELECT id FROM users WHERE email LIKE 'test-e2e-%')"
        )
        await conn.execute(
            "DELETE FROM query_logs WHERE anon_session_id IN "
            "(SELECT id FROM anonymous_sessions WHERE "
            "created_at > NOW() - INTERVAL '1 hour')"
        )
        await conn.execute(
            "DELETE FROM anonymous_sessions WHERE "
            "created_at > NOW() - INTERVAL '1 hour'"
        )
        await conn.execute("DELETE FROM users WHERE email LIKE 'test-e2e-%'")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def unique_email() -> str:
    """Generate a unique test email with test-e2e- prefix for cleanup."""
    return f"test-e2e-{uuid.uuid4().hex[:8]}@example.com"


def create_test_user(client) -> dict:
    """Register a new user via the API and return {"token", "user_id", "email"}."""
    email = unique_email()
    resp = client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": "securepassword123"},
    )
    assert resp.status_code == 201, f"Register failed: {resp.status_code} {resp.text}"
    body = resp.json()
    return {"token": body["token"], "user_id": body["user_id"], "email": email}


def create_test_anon(client) -> dict:
    """Create an anonymous session via the API and return {"token", "session_id"}."""
    resp = client.post("/api/v1/auth/anonymous")
    assert resp.status_code == 201, f"Anon session failed: {resp.status_code} {resp.text}"
    body = resp.json()
    return {"token": body["token"], "session_id": body["session_id"]}


def make_contribute_payload(**overrides) -> dict:
    """Build a valid contribute request body. Overrides replace defaults."""
    base = {
        "situation": "A " * 30,  # 60 chars > 50 min
        "solution": "B " * 30,
        "outcome_type": "solved",
        "lessons": "C " * 20,  # 40 chars > 30 min
        "domain": "python",
        "task_type": "debugging",
        "language": "en",
    }
    base.update(overrides)
    return base
