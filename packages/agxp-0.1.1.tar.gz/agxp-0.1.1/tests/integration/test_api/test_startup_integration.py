"""
Integration tests for agxp/api/startup.py against real infrastructure.

Requires:
  - PostgreSQL running at localhost:5433 (with pgvector extension)
  - Redis running at localhost:6379

Environment:
  DATABASE_URL=postgresql+asyncpg://agxp:agxp_dev@localhost:5433/agxp
  REDIS_URL=redis://localhost:6379/0
"""
import os

import pytest

from agxp.api.startup import (
    check_database,
    check_env_vars,
    check_pgvector,
    check_redis,
)

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+asyncpg://agxp:agxp_dev@localhost:5433/agxp",
)
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")

# Convert SQLAlchemy-style DSN to plain asyncpg DSN
DSN = DATABASE_URL.replace("postgresql+asyncpg://", "postgresql://", 1)


class TestStartupIntegration:
    """Integration tests running against real PostgreSQL + Redis."""

    def test_check_env_vars_with_real_env(self):
        """check_env_vars passes when DATABASE_URL is set in the real environment."""
        # Ensure the env var is set for this test
        original = os.environ.get("DATABASE_URL")
        os.environ["DATABASE_URL"] = DATABASE_URL
        try:
            check_env_vars()  # should not raise
        finally:
            if original is None:
                os.environ.pop("DATABASE_URL", None)
            else:
                os.environ["DATABASE_URL"] = original

    @pytest.mark.asyncio
    async def test_check_database_with_real_postgres(self):
        """SELECT 1 against real PostgreSQL at localhost:5433."""
        await check_database(DSN)  # should not raise

    @pytest.mark.asyncio
    async def test_check_pgvector_with_real_postgres(self):
        """pgvector extension check against real PostgreSQL."""
        await check_pgvector(DSN)  # should not raise

    @pytest.mark.asyncio
    async def test_check_redis_with_real_redis(self):
        """Redis ping against real Redis at localhost:6379."""
        result = await check_redis(REDIS_URL)
        assert result is True

    @pytest.mark.asyncio
    async def test_startup_checks_pass_with_real_infrastructure(self):
        """All startup checks pass end-to-end against real services."""
        original = os.environ.get("DATABASE_URL")
        os.environ["DATABASE_URL"] = DATABASE_URL
        try:
            check_env_vars()
            await check_database(DSN)
            await check_pgvector(DSN)
            redis_ok = await check_redis(REDIS_URL)
            assert redis_ok is True
        finally:
            if original is None:
                os.environ.pop("DATABASE_URL", None)
            else:
                os.environ["DATABASE_URL"] = original
