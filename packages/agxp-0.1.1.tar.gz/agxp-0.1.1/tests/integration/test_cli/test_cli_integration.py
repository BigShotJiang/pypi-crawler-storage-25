"""
Integration tests for CLI end-to-end flows (Issue #7).

These tests exercise CLI commands with mocked API responses, no external dependencies.
Each test uses tmp_path for config file isolation.
"""
import json
import os
import uuid
from unittest.mock import MagicMock, patch
from typer.testing import CliRunner

from agxp.cli.main import app

runner = CliRunner()


def _mock_api_response(url: str, method: str = "GET", status: int = 200, data: dict = None):
    """Helper to mock API responses."""
    mock_response = MagicMock()
    mock_response.getcode.return_value = status
    mock_response.read.return_value = json.dumps(data or {}).encode()
    mock_response.__enter__.return_value = mock_response
    return mock_response


def test_status_creates_anonymous_session(tmp_path):
    """Test agxp status creates anonymous session automatically if no config exists."""
    data_dir = str(tmp_path / "agxp_data")

    # Mock anonymous session creation API
    with patch("urllib.request.urlopen") as mock_urlopen:
        # First call: create anonymous session
        mock_urlopen.side_effect = [
            _mock_api_response(
                "/api/v1/auth/anonymous",
                method="POST",
                status=201,
                data={"token": "test-anon-token-123", "session_id": "test-session-id-123"}
            ),
            # Second call: health check
            _mock_api_response(
                "/health",
                data={"status": "ok", "version": "0.1.0", "features": ["search", "contribute"]}
            ),
            # Third call: user info
            _mock_api_response(
                "/api/v1/user/me",
                data={
                    "user_type": "anonymous",
                    "credit_balance": 50,
                    "experience_count": 0,
                    "search_count_today": 0,
                    "max_search_per_day": 50
                }
            )
        ]

        result = runner.invoke(app, ["status", "--data-dir", data_dir])
        assert result.exit_code == 0, f"status failed: {result.output}"
        assert "anonymous mode" in result.output
        assert "Credit Balance:  50 credits" in result.output

        # Verify config file was created with anonymous token
        config_path = f"{tmp_path}/agxp_data/config.json"
        with open(config_path, "r") as f:
            config = json.load(f)
        assert config["anonymous_token"] == "test-anon-token-123"


def test_status_json_output(tmp_path):
    """Test agxp status --json output format."""
    data_dir = str(tmp_path / "agxp_data")

    # Pre-create config with anonymous token
    config = {"anonymous_token": "test-anon-token-123"}
    os.makedirs(data_dir, exist_ok=True)
    with open(f"{data_dir}/config.json", "w") as f:
        json.dump(config, f)

    with patch("urllib.request.urlopen") as mock_urlopen:
        mock_urlopen.side_effect = [
            # Health check
            _mock_api_response("/health", data={"status": "ok", "version": "0.1.0"}),
            # User info
            _mock_api_response("/api/v1/user/me", data={
                "user_type": "anonymous",
                "credit_balance": 30,
                "experience_count": 2,
                "search_count_today": 5,
                "max_search_per_day": 50
            })
        ]

        result = runner.invoke(app, ["status", "--data-dir", data_dir, "--json"])
        assert result.exit_code == 0
        output = json.loads(result.output.strip())
        assert output["server_online"] is True
        assert output["login_status"] == "anonymous"
        assert output["user_info"]["credit_balance"] == 30
        assert output["user_info"]["experience_count"] == 2


def test_contribute_success(tmp_path):
    """Test agxp contribute with valid data."""
    data_dir = str(tmp_path / "agxp_data")

    # Pre-create config with logged-in token
    config = {"api_token": "test-user-token-123"}
    os.makedirs(data_dir, exist_ok=True)
    with open(f"{data_dir}/config.json", "w") as f:
        json.dump(config, f)

    with patch("urllib.request.urlopen") as mock_urlopen:
        mock_urlopen.return_value = _mock_api_response(
            "/api/v1/contribute",
            method="POST",
            status=202,
            data={"experience_id": str(uuid.uuid4()), "status": "pending_scoring", "estimated_credits": 10}
        )

        result = runner.invoke(app, [
            "contribute",
            "--data-dir", data_dir,
            "--situation", "Test situation with asyncio deadlock",
            "--solution", "Fixed by replacing asyncio.run() with await",
            "--outcome-type", "solved",
            "--lessons", "Never call asyncio.run() inside running event loop",
            "--domain", "coding",
            "--task-type", "debugging"
        ])

        assert result.exit_code == 0, f"contribute failed: {result.output}"
        output = json.loads(result.output.strip())
        assert "experience_id" in output
        assert output["status"] == "pending_scoring"
        assert output["estimated_credits"] == 10


def test_contribute_missing_required_fields(tmp_path):
    """Test agxp contribute shows error when required fields are missing."""
    data_dir = str(tmp_path / "agxp_data")

    # Pre-create config
    config = {"api_token": "test-user-token-123"}
    os.makedirs(data_dir, exist_ok=True)
    with open(f"{data_dir}/config.json", "w") as f:
        json.dump(config, f)

    # Missing --solution field
    result = runner.invoke(app, [
        "contribute",
        "--data-dir", data_dir,
        "--situation", "Test situation",
        "--outcome-type", "solved",
        "--lessons", "Test lesson",
        "--domain", "coding",
        "--task-type", "debugging"
    ])

    assert result.exit_code != 0
    assert "Missing option '--solution'" in result.output


def test_query_success(tmp_path):
    """Test agxp query returns results correctly."""
    data_dir = str(tmp_path / "agxp_data")

    # Pre-create config
    config = {"anonymous_token": "test-anon-token-123"}
    os.makedirs(data_dir, exist_ok=True)
    with open(f"{data_dir}/config.json", "w") as f:
        json.dump(config, f)

    # Mock query API response (NDJSON format)
    mock_response = MagicMock()
    mock_response.getcode.return_value = 200
    mock_response.read.return_value = b"""
{"type": "meta", "warnings": []}
{"type": "result", "experience": {"experience_id": "test-id-1", "situation": "Asyncio deadlock issue", "solution": "Fixed using await", "domain": "coding", "task_type": "debugging"}}
{"type": "result", "experience": {"experience_id": "test-id-2", "situation": "Another asyncio issue", "solution": "Fixed event loop nesting", "domain": "coding", "task_type": "debugging"}}
{"type": "done", "total_results": 2}
    """.strip()
    mock_response.__enter__.return_value = mock_response

    with patch("urllib.request.urlopen") as mock_urlopen:
        mock_urlopen.return_value = mock_response

        result = runner.invoke(app, [
            "query", "asyncio deadlock",
            "--data-dir", data_dir,
            "--limit", "10"
        ])

        assert result.exit_code == 0, f"query failed: {result.output}"
        lines = [l.strip() for l in result.output.strip().splitlines() if l.strip()]
        assert len(lines) == 2  # Only result lines are output

        # Parse results
        results = [json.loads(l) for l in lines]
        assert len(results) == 2
        assert results[0]["situation"] == "Asyncio deadlock issue"
        assert results[1]["solution"] == "Fixed event loop nesting"


def test_query_with_domain_filter(tmp_path):
    """Test agxp query with --domain filter passes filter to API."""
    data_dir = str(tmp_path / "agxp_data")

    # Pre-create config
    config = {"anonymous_token": "test-anon-token-123"}
    os.makedirs(data_dir, exist_ok=True)
    with open(f"{data_dir}/config.json", "w") as f:
        json.dump(config, f)

    # Mock empty response
    mock_response = MagicMock()
    mock_response.getcode.return_value = 200
    mock_response.read.return_value = b'{"type": "meta", "warnings": []}\n{"type": "done", "total_results": 0}'
    mock_response.__enter__.return_value = mock_response

    with patch("urllib.request.urlopen") as mock_urlopen:
        mock_urlopen.return_value = mock_response

        result = runner.invoke(app, [
            "query", "k8s deployment error",
            "--data-dir", data_dir,
            "--domain", "devops",
            "--task-type", "deployment"
        ])

        assert result.exit_code == 0

        # Verify API was called with correct filter parameters
        call_args = mock_urlopen.call_args
        req = call_args[0][0]
        assert req.method == "POST"
        data = json.loads(req.data)
        assert data["query"] == "k8s deployment error"
        assert data["domain"] == "devops"
        assert data["task_type"] == "deployment"


def test_feedback_success(tmp_path):
    """Test agxp feedback submits correctly."""
    data_dir = str(tmp_path / "agxp_data")

    # Pre-create config
    config = {"api_token": "test-user-token-123"}
    os.makedirs(data_dir, exist_ok=True)
    with open(f"{data_dir}/config.json", "w") as f:
        json.dump(config, f)

    with patch("urllib.request.urlopen") as mock_urlopen:
        mock_urlopen.return_value = _mock_api_response(
            "/api/v1/feedback",
            method="POST",
            status=200,
            data={"status": "success", "quality_score": 0.8}
        )

        result = runner.invoke(app, [
            "feedback",
            "--data-dir", data_dir,
            "--experience-id", "test-exp-id-123",
            "--useful"
        ])

        assert result.exit_code == 0, f"feedback failed: {result.output}"
        output = json.loads(result.output.strip())
        assert output["status"] == "success"
        assert output["quality_score"] == 0.8


def test_contribute_with_all_optional_fields(tmp_path):
    """Test agxp contribute with all optional fields parses correctly."""
    data_dir = str(tmp_path / "agxp_data")

    # Pre-create config
    config = {"api_token": "test-user-token-123"}
    os.makedirs(data_dir, exist_ok=True)
    with open(f"{data_dir}/config.json", "w") as f:
        json.dump(config, f)

    captured_data = {}
    def capture_request(*args, **kwargs):
        nonlocal captured_data
        req = args[0]
        captured_data = json.loads(req.data)
        return _mock_api_response(
            "/api/v1/contribute",
            method="POST",
            status=202,
            data={"experience_id": str(uuid.uuid4()), "status": "pending_scoring"}
        )

    with patch("urllib.request.urlopen") as mock_urlopen:
        mock_urlopen.side_effect = capture_request

        result = runner.invoke(app, [
            "contribute",
            "--data-dir", data_dir,
            "--situation", "Memory leak in long running Python service",
            "--solution", "Fixed using tracemalloc to find and fix cache issue",
            "--outcome-type", "solved",
            "--lessons", "Always profile memory for long running services",
            "--domain", "coding",
            "--task-type", "performance",
            "--language", "en",
            "--failed-approaches", "Tried restarting hourly, didn't solve root cause",
            "--environment", '{"os": "linux", "python": "3.11", "memory": "16GB"}',
            "--subdomain", "memory-management",
            "--tags", "python,memory,profiling,performance"
        ])

        assert result.exit_code == 0

        # Verify all fields were correctly parsed and sent
        assert captured_data["failed_approaches"] == "Tried restarting hourly, didn't solve root cause"
        assert captured_data["environment"] == {"os": "linux", "python": "3.11", "memory": "16GB"}
        assert captured_data["subdomain"] == "memory-management"
        assert captured_data["tags"] == ["python", "memory", "profiling", "performance"]
