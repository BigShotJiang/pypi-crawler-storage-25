"""
Integration tests for Alembic migrations.
Verifies upgrade and downgrade run cleanly.
"""
import pytest
from alembic import command
from alembic.config import Config

ALEMBIC_CFG_PATH = "alembic.ini"

EXPECTED_TABLES = {
    "users",
    "api_keys",
    "anonymous_sessions",
    "experiences",
    "experience_translations",
    "credit_accounts",
    "credit_transactions",
    "quality_votes",
    "query_logs",
    "search_feedback",
}


def get_alembic_cfg() -> Config:
    cfg = Config(ALEMBIC_CFG_PATH)
    return cfg


@pytest.mark.integration
def test_upgrade_head_succeeds():
    """alembic upgrade head must run without error."""
    cfg = get_alembic_cfg()
    command.upgrade(cfg, "head")


@pytest.mark.integration
async def test_all_tables_exist_after_upgrade(engine):
    """All expected tables must exist after upgrade head."""
    from sqlalchemy import text

    async with engine.connect() as conn:
        result = await conn.execute(
            text("SELECT tablename FROM pg_tables WHERE schemaname = 'public'")
        )
        tables = {row[0] for row in result}
    assert EXPECTED_TABLES <= tables, f"Missing tables: {EXPECTED_TABLES - tables}"


@pytest.mark.integration
async def test_outcome_type_enum_exists(engine):
    """outcome_type PostgreSQL enum must exist."""
    from sqlalchemy import text

    async with engine.connect() as conn:
        result = await conn.execute(
            text("SELECT typname FROM pg_type WHERE typname = 'outcome_type'")
        )
        row = result.fetchone()
    assert row is not None, "outcome_type enum not found in database"


@pytest.mark.integration
async def test_hnsw_indexes_exist(engine):
    """All 6 HNSW vector indexes must exist."""
    from sqlalchemy import text

    expected_indexes = {
        "exp_hnsw_situation",
        "exp_hnsw_solution",
        "exp_hnsw_lessons",
        "exp_hnsw_failed",
        "exp_hnsw_tags",
        "exp_hnsw_environment",
    }

    async with engine.connect() as conn:
        result = await conn.execute(
            text("SELECT indexname FROM pg_indexes WHERE tablename = 'experiences'")
        )
        indexes = {row[0] for row in result}
    missing = expected_indexes - indexes
    assert not missing, f"Missing HNSW indexes: {missing}"


@pytest.mark.integration
def test_downgrade_one_step_succeeds():
    """alembic downgrade -1 must run without error."""
    cfg = get_alembic_cfg()
    command.downgrade(cfg, "-1")


@pytest.mark.integration
def test_full_roundtrip():
    """upgrade → downgrade → upgrade must complete without error."""
    cfg = get_alembic_cfg()
    command.upgrade(cfg, "head")
    command.downgrade(cfg, "base")
    command.upgrade(cfg, "head")
