"""
Integration test fixtures for database tests.
Requires PostgreSQL running via docker compose.
"""
import os

import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.pool import NullPool

TEST_DATABASE_URL = os.getenv(
    "TEST_DATABASE_URL",
    "postgresql+asyncpg://agxp:agxp@localhost:5433/agxp",
)


@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def engine():
    eng = create_async_engine(TEST_DATABASE_URL, echo=False, poolclass=NullPool)
    yield eng
    await eng.dispose()


@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def _shared_session(engine):
    sess = AsyncSession(engine)
    try:
        yield sess
    finally:
        try:
            await sess.close()
        except Exception:
            pass


@pytest_asyncio.fixture(autouse=True, loop_scope="session")
async def session(_shared_session):
    """Yields the shared session, rolling back any state from the previous test."""
    try:
        await _shared_session.rollback()
    except Exception:
        pass
    yield _shared_session
