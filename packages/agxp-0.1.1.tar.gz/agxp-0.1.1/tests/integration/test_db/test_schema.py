"""
Integration tests for database schema constraints.
Verifies UniqueViolation, ForeignKeyViolation, and CheckViolation
are correctly enforced by PostgreSQL.
"""
import uuid

import pytest
from sqlalchemy import text


def make_user():
    return {
        "id": str(uuid.uuid4()),
        "email": f"{uuid.uuid4()}@test.com",
        "display_name": "Test User",
        "is_active": True,
    }


def make_experience(user_id: str):
    return {
        "id": str(uuid.uuid4()),
        "user_id": user_id,
        "domain": "coding",
        "task_type": "debugging",
        "situation": "x" * 60,
        "solution": "y" * 60,
        "outcome_type": "solved",
        "lessons": "z" * 35,
        "language": "en",
        "translation_status": "not_needed",
        "quality_score": 0.0,
        "upvotes": 0,
        "downvotes": 0,
        "use_count": 0,
        "is_published": False,
        "tags": [],
    }


@pytest.mark.integration
async def test_outcome_type_rejects_invalid_value(session):
    """Inserting an invalid outcome_type value must raise an error."""
    from asyncpg import DataError
    from sqlalchemy.exc import DBAPIError

    user = make_user()
    await session.execute(text(
        "INSERT INTO users (id, email, display_name, is_active) "
        "VALUES (:id, :email, :display_name, :is_active)"
    ), user)

    exp = make_experience(user["id"])
    exp["outcome_type"] = "invalid_value"

    with pytest.raises((DBAPIError, DataError, Exception)):
        await session.execute(text(
            "INSERT INTO experiences (id, user_id, domain, task_type, situation, "
            "solution, outcome_type, lessons, language, translation_status, "
            "quality_score, upvotes, downvotes, use_count, is_published, tags) "
            "VALUES (:id, :user_id, :domain, :task_type, :situation, :solution, "
            ":outcome_type, :lessons, :language, :translation_status, "
            ":quality_score, :upvotes, :downvotes, :use_count, :is_published, :tags)"
        ), exp)
        await session.flush()


@pytest.mark.integration
async def test_experience_translations_unique_constraint(session):
    """Duplicate (experience_id, language) must raise UniqueViolation."""
    from sqlalchemy.exc import IntegrityError

    user = make_user()
    await session.execute(text(
        "INSERT INTO users (id, email, display_name, is_active) "
        "VALUES (:id, :email, :display_name, :is_active)"
    ), user)

    exp = make_experience(user["id"])
    await session.execute(text(
        "INSERT INTO experiences (id, user_id, domain, task_type, situation, "
        "solution, outcome_type, lessons, language, translation_status, "
        "quality_score, upvotes, downvotes, use_count, is_published, tags) "
        "VALUES (:id, :user_id, :domain, :task_type, :situation, :solution, "
        ":outcome_type, :lessons, :language, :translation_status, "
        ":quality_score, :upvotes, :downvotes, :use_count, :is_published, :tags)"
    ), exp)

    trans_id_1 = str(uuid.uuid4())
    trans_id_2 = str(uuid.uuid4())
    await session.execute(text(
        "INSERT INTO experience_translations (id, experience_id, language) "
        "VALUES (:id, :experience_id, :language)"
    ), {"id": trans_id_1, "experience_id": exp["id"], "language": "zh"})

    with pytest.raises(IntegrityError):
        await session.execute(text(
            "INSERT INTO experience_translations (id, experience_id, language) "
            "VALUES (:id, :experience_id, :language)"
        ), {"id": trans_id_2, "experience_id": exp["id"], "language": "zh"})
        await session.flush()


@pytest.mark.integration
async def test_credit_transaction_idempotency_key_unique(session):
    """Duplicate idempotency_key in credit_transactions must raise UniqueViolation."""
    from sqlalchemy.exc import IntegrityError

    user = make_user()
    await session.execute(text(
        "INSERT INTO users (id, email, display_name, is_active) "
        "VALUES (:id, :email, :display_name, :is_active)"
    ), user)
    acct_id = str(uuid.uuid4())
    await session.execute(text(
        "INSERT INTO credit_accounts (id, user_id, balance, pending_balance, tier, "
        "lifetime_earned, lifetime_spent) "
        "VALUES (:id, :user_id, 0, 0, 'free', 0, 0)"
    ), {"id": acct_id, "user_id": user["id"]})

    idem_key = f"test-key-{uuid.uuid4()}"
    await session.execute(text(
        "INSERT INTO credit_transactions (id, account_id, txn_type, amount, "
        "balance_after, idempotency_key) "
        "VALUES (:id, :account_id, 'free_tier_grant', 100, 100, :idem_key)"
    ), {"id": str(uuid.uuid4()), "account_id": acct_id, "idem_key": idem_key})

    with pytest.raises(IntegrityError):
        await session.execute(text(
            "INSERT INTO credit_transactions (id, account_id, txn_type, amount, "
            "balance_after, idempotency_key) "
            "VALUES (:id, :account_id, 'free_tier_grant', 100, 200, :idem_key)"
        ), {"id": str(uuid.uuid4()), "account_id": acct_id, "idem_key": idem_key})
        await session.flush()


@pytest.mark.integration
async def test_quality_votes_unique_per_user(session):
    """Same user cannot vote twice on same experience."""
    from sqlalchemy.exc import IntegrityError

    user = make_user()
    await session.execute(text(
        "INSERT INTO users (id, email, display_name, is_active) "
        "VALUES (:id, :email, :display_name, :is_active)"
    ), user)
    exp = make_experience(user["id"])
    await session.execute(text(
        "INSERT INTO experiences (id, user_id, domain, task_type, situation, "
        "solution, outcome_type, lessons, language, translation_status, "
        "quality_score, upvotes, downvotes, use_count, is_published, tags) "
        "VALUES (:id, :user_id, :domain, :task_type, :situation, :solution, "
        ":outcome_type, :lessons, :language, :translation_status, "
        ":quality_score, :upvotes, :downvotes, :use_count, :is_published, :tags)"
    ), exp)

    await session.execute(text(
        "INSERT INTO quality_votes (id, experience_id, voter_user_id, vote) "
        "VALUES (:id, :exp_id, :user_id, 1)"
    ), {"id": str(uuid.uuid4()), "exp_id": exp["id"], "user_id": user["id"]})

    with pytest.raises(IntegrityError):
        await session.execute(text(
            "INSERT INTO quality_votes (id, experience_id, voter_user_id, vote) "
            "VALUES (:id, :exp_id, :user_id, -1)"
        ), {"id": str(uuid.uuid4()), "exp_id": exp["id"], "user_id": user["id"]})
        await session.flush()


@pytest.mark.integration
async def test_experience_foreign_key_to_users(session):
    """Inserting experience with non-existent user_id must fail."""
    from sqlalchemy.exc import IntegrityError

    exp = make_experience(str(uuid.uuid4()))  # random non-existent user_id
    with pytest.raises(IntegrityError):
        await session.execute(text(
            "INSERT INTO experiences (id, user_id, domain, task_type, situation, "
            "solution, outcome_type, lessons, language, translation_status, "
            "quality_score, upvotes, downvotes, use_count, is_published, tags) "
            "VALUES (:id, :user_id, :domain, :task_type, :situation, :solution, "
            ":outcome_type, :lessons, :language, :translation_status, "
            ":quality_score, :upvotes, :downvotes, :use_count, :is_published, :tags)"
        ), exp)
        await session.flush()


@pytest.mark.integration
async def test_credit_account_one_per_user(session):
    """One user cannot have two credit accounts."""
    from sqlalchemy.exc import IntegrityError

    user = make_user()
    await session.execute(text(
        "INSERT INTO users (id, email, display_name, is_active) "
        "VALUES (:id, :email, :display_name, :is_active)"
    ), user)

    await session.execute(text(
        "INSERT INTO credit_accounts (id, user_id, balance, pending_balance, tier, "
        "lifetime_earned, lifetime_spent) VALUES (:id, :uid, 0, 0, 'free', 0, 0)"
    ), {"id": str(uuid.uuid4()), "uid": user["id"]})

    with pytest.raises(IntegrityError):
        await session.execute(text(
            "INSERT INTO credit_accounts (id, user_id, balance, pending_balance, tier, "
            "lifetime_earned, lifetime_spent) VALUES (:id, :uid, 0, 0, 'free', 0, 0)"
        ), {"id": str(uuid.uuid4()), "uid": user["id"]})
        await session.flush()
