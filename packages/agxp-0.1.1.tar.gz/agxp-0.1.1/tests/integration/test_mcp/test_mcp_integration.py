"""
Integration tests for AGXP MCP server (pure API architecture).

All tests use mocked API responses, no external dependencies required.
"""
import json
import os
import uuid
from unittest.mock import MagicMock, patch
import pytest

from agxp.mcp.server import set_data_dir, _get_or_create_token


def _mock_api_response(status: int = 200, data: dict | list | None = None, is_ndjson: bool = False):
    """Helper to create mock API responses."""
    mock_resp = MagicMock()
    mock_resp.getcode.return_value = status
    if is_ndjson:
        lines = []
        lines.append(json.dumps({"type": "meta", "warnings": []}))
        if isinstance(data, list):
            for exp in data:
                lines.append(json.dumps({"type": "result", "experience": exp}))
        lines.append(json.dumps({"type": "done", "total_results": len(data) if data else 0}))
        mock_resp.read.return_value = "\n".join(lines).encode()
    else:
        mock_resp.read.return_value = json.dumps(data or {}).encode()
    mock_resp.__enter__.return_value = mock_resp
    return mock_resp


@pytest.fixture
def temp_data_dir(tmp_path):
    """Create temporary data directory and set it for MCP server."""
    data_dir = str(tmp_path / "agxp_test")
    os.makedirs(data_dir, exist_ok=True)
    set_data_dir(data_dir)
    yield data_dir
    set_data_dir(None)


@pytest.fixture
def mock_config_with_token(temp_data_dir):
    """Preconfigure test config with valid API token."""
    config = {"api_token": "test_user_token_12345"}
    with open(os.path.join(temp_data_dir, "config.json"), "w") as f:
        json.dump(config, f)
    return config


# ---------------------------------------------------------------------------
# Tool Signature Tests
# ---------------------------------------------------------------------------
def test_search_experiences_signature():
    """Verify search_experiences tool has correct signature and parameters."""
    from agxp.mcp.server import search_experiences
    import inspect

    sig = inspect.signature(search_experiences)
    params = list(sig.parameters.keys())
    assert params == ["query", "domain", "task_type", "limit"]
    assert sig.parameters["limit"].default == 5


def test_contribute_experience_signature():
    """Verify contribute_experience tool has correct signature and parameters."""
    from agxp.mcp.server import contribute_experience
    import inspect

    sig = inspect.signature(contribute_experience)
    params = list(sig.parameters.keys())
    required_params = ["situation", "solution", "outcome_type", "lessons", "domain", "task_type"]
    for p in required_params:
        assert p in params
    assert sig.parameters["language"].default == "en"


def test_report_feedback_signature():
    """Verify report_feedback tool has correct signature and parameters."""
    from agxp.mcp.server import report_feedback
    import inspect

    sig = inspect.signature(report_feedback)
    params = list(sig.parameters.keys())
    assert params == ["experience_id", "useful"]


# ---------------------------------------------------------------------------
# Tool Functionality Tests
# ---------------------------------------------------------------------------
def test_search_experiences_success(temp_data_dir, mock_config_with_token):
    """Test search_experiences tool correctly calls API and parses results."""
    from agxp.mcp.server import search_experiences

    test_results = [
        {
            "id": "exp_123",
            "situation": "Asyncio deadlock when calling asyncio.run() inside running loop",
            "solution": "Replace asyncio.run() with await and use existing loop",
            "domain": "coding",
            "task_type": "debugging"
        },
        {
            "id": "exp_456",
            "situation": "Another asyncio issue with nested tasks",
            "solution": "Use asyncio.create_task() properly",
            "domain": "coding",
            "task_type": "debugging"
        }
    ]

    captured_request = {}
    def capture_search(req, *args, **kwargs):
        nonlocal captured_request
        assert req.get_method() == "POST"
        assert req.full_url.endswith("/api/v1/query")
        assert req.get_header("Authorization") == "Bearer test_user_token_12345"
        captured_request = json.loads(req.data)
        return _mock_api_response(status=200, data=test_results, is_ndjson=True)

    with patch("urllib.request.urlopen") as mock_urlopen:
        mock_urlopen.side_effect = capture_search

        result = search_experiences(
            query="asyncio deadlock",
            domain="coding",
            task_type="debugging",
            limit=10
        )

        assert "results" in result
        assert len(result["results"]) == 2
        assert result["results"][0]["experience_id"] == "exp_123"
        assert result["results"][0]["situation"] == test_results[0]["situation"]
        assert result["results"][1]["experience_id"] == "exp_456"

        # Verify request parameters
        assert captured_request["query"] == "asyncio deadlock"
        assert captured_request["domain"] == "coding"
        assert captured_request["task_type"] == "debugging"
        assert captured_request["limit"] == 10


def test_contribute_experience_success(temp_data_dir, mock_config_with_token):
    """Test contribute_experience tool correctly sends data to API."""
    from agxp.mcp.server import contribute_experience

    test_exp_id = str(uuid.uuid4())
    captured_request = {}

    def capture_contribute(req, *args, **kwargs):
        nonlocal captured_request
        assert req.get_method() == "POST"
        assert req.full_url.endswith("/api/v1/contribute")
        assert req.get_header("Authorization") == "Bearer test_user_token_12345"
        captured_request = json.loads(req.data)
        return _mock_api_response(status=202, data={
            "experience_id": test_exp_id,
            "status": "pending_scoring",
            "estimated_credits": 15
        })

    with patch("urllib.request.urlopen") as mock_urlopen:
        mock_urlopen.side_effect = capture_contribute

        result = contribute_experience(
            situation="Memory leak in long running Python service due to unclosed connections",
            solution="Added connection pooling and proper context manager for database connections",
            outcome_type="solved",
            lessons="Always use context managers for external resources to prevent leaks",
            domain="coding",
            task_type="performance",
            language="en",
            failed_approaches="Tried restarting service periodically, didn't fix root cause",
            environment={"os": "linux", "python": "3.11", "postgres": "15"},
            subdomain="memory-management",
            tags=["python", "memory-leak", "database", "performance"]
        )

        assert result["experience_id"] == test_exp_id
        assert result["status"] == "pending_scoring"
        assert result["estimated_credits"] == 15

        # Verify all fields are sent correctly
        assert captured_request["situation"] == "Memory leak in long running Python service due to unclosed connections"
        assert captured_request["failed_approaches"] == "Tried restarting service periodically, didn't fix root cause"
        assert captured_request["environment"] == {"os": "linux", "python": "3.11", "postgres": "15"}
        assert captured_request["tags"] == ["python", "memory-leak", "database", "performance"]
        assert captured_request["subdomain"] == "memory-management"


def test_contribute_invalid_outcome_type(temp_data_dir, mock_config_with_token):
    """Test contribute_experience raises error for invalid outcome_type."""
    from agxp.mcp.server import contribute_experience

    with pytest.raises(ValueError, match="Invalid outcome_type"):
        contribute_experience(
            situation="Test situation",
            solution="Test solution",
            outcome_type="invalid_type",
            lessons="Test lesson",
            domain="coding",
            task_type="debugging"
        )


def test_report_feedback_success(temp_data_dir, mock_config_with_token):
    """Test report_feedback tool correctly sends rating to API."""
    from agxp.mcp.server import report_feedback

    test_exp_id = "exp_12345"
    captured_request = {}

    def capture_feedback(req, *args, **kwargs):
        nonlocal captured_request
        assert req.get_method() == "POST"
        assert req.full_url.endswith("/api/v1/feedback")
        assert req.get_header("Authorization") == "Bearer test_user_token_12345"
        captured_request = json.loads(req.data)
        return _mock_api_response(status=200, data={
            "experience_id": test_exp_id,
            "quality_score": 0.85,
            "status": "updated"
        })

    with patch("urllib.request.urlopen") as mock_urlopen:
        mock_urlopen.side_effect = capture_feedback

        result = report_feedback(
            experience_id=test_exp_id,
            useful=True
        )

        assert result["experience_id"] == test_exp_id
        assert result["status"] == "updated"
        assert result["quality_score"] == 0.85
        assert captured_request["useful"] == True
        assert captured_request["experience_id"] == test_exp_id


# ---------------------------------------------------------------------------
# Authentication / Session Tests
# ---------------------------------------------------------------------------
def test_auto_create_anonymous_session(temp_data_dir):
    """Test MCP server automatically creates anonymous session when no token exists."""
    # No pre-existing config
    assert not os.path.exists(os.path.join(temp_data_dir, "config.json"))

    captured_requests = []
    def handle_request(req, *args, **kwargs):
        captured_requests.append(req)
        if req.full_url.endswith("/api/v1/auth/anonymous"):
            # Return anonymous token
            return _mock_api_response(status=201, data={
                "token": "anon_test_token_123",
                "session_id": "session_456"
            })
        elif req.full_url.endswith("/api/v1/query"):
            # Return empty search results
            return _mock_api_response(status=200, data=[], is_ndjson=True)
        raise Exception(f"Unexpected request to {req.full_url}")

    with patch("urllib.request.urlopen") as mock_urlopen:
        mock_urlopen.side_effect = handle_request

        from agxp.mcp.server import search_experiences
        result = search_experiences(query="test query")

        # Should have made two requests: create anonymous session + search
        assert len(captured_requests) == 2
        assert captured_requests[0].full_url.endswith("/api/v1/auth/anonymous")
        assert captured_requests[1].full_url.endswith("/api/v1/query")
        assert captured_requests[1].get_header("Authorization") == "Bearer anon_test_token_123"

        # Config file should have been created with anonymous token
        assert os.path.exists(os.path.join(temp_data_dir, "config.json"))
        with open(os.path.join(temp_data_dir, "config.json"), "r") as f:
            config = json.load(f)
        assert config["anonymous_token"] == "anon_test_token_123"


# ---------------------------------------------------------------------------
# CLI Command Tests
# ---------------------------------------------------------------------------
def test_mcp_command_registered():
    """Verify `agxp mcp` command is properly registered in CLI."""
    from typer.testing import CliRunner
    from agxp.cli.main import app
    runner = CliRunner()
    # Try to run mcp --help, should not fail
    result = runner.invoke(app, ["mcp", "--help"])
    assert result.exit_code == 0, f"mcp --help failed with code {result.exit_code}: {result.output}"
    assert "Start the AGXP MCP server" in result.output


def test_mcp_server_has_tools_registered():
    """Verify MCP server has all three tools registered with correct names."""
    from agxp.mcp.server import mcp
    # Check that tool decorator was called for all three tools
    from agxp.mcp.server import search_experiences, contribute_experience, report_feedback
    assert search_experiences is not None
    assert contribute_experience is not None
    assert report_feedback is not None
