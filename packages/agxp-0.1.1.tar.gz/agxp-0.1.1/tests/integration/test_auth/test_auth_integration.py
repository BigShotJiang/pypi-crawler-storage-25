"""
Integration tests for Issue #19 — User Onboarding against real PostgreSQL.

Requires:
  - PostgreSQL running at localhost:5433 (with pgvector extension)
  - Database "agxp" with schema applied (including password_hash column on users)
  - Redis running at localhost:6379 (for contribute endpoint test)

Environment:
  DATABASE_URL=postgresql+asyncpg://agxp:agxp_dev@localhost:5433/agxp

These tests exercise the full HTTP flow: create tokens via onboarding endpoints,
then use them against protected endpoints (query, contribute).

Prerequisite: The password_hash column must exist on the users table.
If running against a schema without it, run:
  ALTER TABLE users ADD COLUMN password_hash VARCHAR(128) NULL;
"""
from __future__ import annotations

import os
import uuid

import asyncpg
import pytest
import pytest_asyncio
from fastapi.testclient import TestClient

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+asyncpg://agxp:agxp@localhost:5433/agxp",
)
DSN = DATABASE_URL.replace("postgresql+asyncpg://", "postgresql://", 1)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture(scope="module", loop_scope="session")
async def pool():
    """Create a raw asyncpg connection pool for direct DB verification."""
    p = await asyncpg.create_pool(DSN, min_size=1, max_size=3)
    yield p
    await p.close()


@pytest.fixture(scope="module")
def client():
    """TestClient with mocked lifespan to avoid full startup validation."""
    # We import app but override lifespan to skip Redis/env checks
    from agxp.api.app import app

    # Disable lifespan for integration tests — DB pool is managed separately
    with TestClient(app, raise_server_exceptions=False) as c:
        yield c


@pytest_asyncio.fixture(autouse=True, loop_scope="session")
async def _cleanup(pool):
    """Clean up test data after each test. Runs AFTER each test."""
    yield
    # Best-effort cleanup of test-created rows (by convention, test emails contain 'test')
    async with pool.acquire() as conn:
        # Delete in dependency order
        await conn.execute(
            "DELETE FROM credit_transactions WHERE account_id IN "
            "(SELECT id FROM credit_accounts WHERE user_id IN "
            "(SELECT id FROM users WHERE email LIKE '%test-integ-%'))"
        )
        await conn.execute(
            "DELETE FROM credit_accounts WHERE user_id IN "
            "(SELECT id FROM users WHERE email LIKE '%test-integ-%')"
        )
        await conn.execute(
            "DELETE FROM experiences WHERE user_id IN "
            "(SELECT id FROM users WHERE email LIKE '%test-integ-%')"
        )
        await conn.execute(
            "DELETE FROM api_keys WHERE user_id IN "
            "(SELECT id FROM users WHERE email LIKE '%test-integ-%')"
        )
        await conn.execute(
            "DELETE FROM query_logs WHERE anon_session_id IN "
            "(SELECT id FROM anonymous_sessions WHERE "
            "created_at > NOW() - INTERVAL '1 hour')"
        )
        await conn.execute(
            "DELETE FROM anonymous_sessions WHERE "
            "created_at > NOW() - INTERVAL '1 hour'"
        )
        await conn.execute("DELETE FROM users WHERE email LIKE '%test-integ-%'")


def _unique_email() -> str:
    """Generate a unique test email to avoid conflicts between test runs."""
    return f"test-integ-{uuid.uuid4().hex[:8]}@example.com"


# ============================================================================
# Test: Create anonymous session, then use token to query
# ============================================================================


class TestAnonymousFlow:
    """Anonymous session creation and token usage."""

    def test_create_anonymous_session(self, client):
        """POST /api/v1/auth/anonymous returns 201 with valid token."""
        response = client.post("/api/v1/auth/anonymous")
        assert response.status_code == 201, f"Expected 201, got {response.status_code}: {response.text}"

        body = response.json()
        assert body["credit_balance"] == 20
        assert body["token"].startswith("agxp_anon_")
        assert "session_id" in body
        assert "expires_at" in body

    def test_anonymous_token_can_query(self, client):
        """Anonymous token can be used to access the query endpoint."""
        # Step 1: Create anonymous session
        anon_resp = client.post("/api/v1/auth/anonymous")
        assert anon_resp.status_code == 201
        token = anon_resp.json()["token"]

        # Step 2: Use the token to query (expect 200 or valid response, not 401)
        query_resp = client.post(
            "/api/v1/query",
            json={"query_text": "test query", "language": "en"},
            headers={"Authorization": f"Bearer {token}"},
        )
        # Should NOT be 401 — the token is valid
        assert query_resp.status_code != 401, (
            f"Anonymous token was rejected: {query_resp.text}"
        )


# ============================================================================
# Test: Register user, then use token to contribute
# ============================================================================


class TestRegistrationFlow:
    """User registration and token usage."""

    def test_register_user(self, client):
        """POST /api/v1/auth/register returns 201 with valid token."""
        email = _unique_email()
        response = client.post(
            "/api/v1/auth/register",
            json={"email": email, "password": "securepassword123"},
        )
        assert response.status_code == 201, f"Expected 201, got {response.status_code}: {response.text}"

        body = response.json()
        assert body["credit_balance"] == 50
        assert body["token"].startswith("agxp_")
        assert not body["token"].startswith("agxp_anon_")
        assert "user_id" in body

    def test_registered_token_can_contribute(self, client):
        """Registered token can access the contribute endpoint."""
        email = _unique_email()
        reg_resp = client.post(
            "/api/v1/auth/register",
            json={"email": email, "password": "securepassword123"},
        )
        assert reg_resp.status_code == 201
        token = reg_resp.json()["token"]

        # Use token to contribute (expect 202 or at least not 401/403)
        contrib_resp = client.post(
            "/api/v1/contribute",
            json={
                "situation": "A" * 50,
                "solution": "B" * 50,
                "outcome_type": "solved",
                "lessons": "C" * 30,
                "domain": "cloud",
                "task_type": "debugging",
                "language": "en",
            },
            headers={"Authorization": f"Bearer {token}"},
        )
        assert contrib_resp.status_code not in (401, 403), (
            f"Registered token was rejected: {contrib_resp.text}"
        )

    def test_register_duplicate_email_409(self, client):
        """Registering with the same email twice returns 409."""
        email = _unique_email()

        # First registration
        resp1 = client.post(
            "/api/v1/auth/register",
            json={"email": email, "password": "securepassword123"},
        )
        assert resp1.status_code == 201

        # Second registration with same email
        resp2 = client.post(
            "/api/v1/auth/register",
            json={"email": email, "password": "anotherpassword123"},
        )
        assert resp2.status_code == 409
        body = resp2.json()
        assert body["error"] == "conflict"
        assert "message" in body


# ============================================================================
# Test: Register with anonymous session merge
# ============================================================================


class TestAnonymousMerge:
    """Anonymous session merge during registration."""

    def test_merge_credits_combined(self, client, pool):
        """Register with anon merge: credit_balance = 50 + remaining anon credits."""
        # Step 1: Create anonymous session
        anon_resp = client.post("/api/v1/auth/anonymous")
        assert anon_resp.status_code == 201
        session_id = anon_resp.json()["session_id"]
        anon_credits = anon_resp.json()["credit_balance"]  # Should be 20

        # Step 2: Register with merge
        email = _unique_email()
        reg_resp = client.post(
            "/api/v1/auth/register",
            json={
                "email": email,
                "password": "securepassword123",
                "anon_session_id": session_id,
            },
        )
        assert reg_resp.status_code == 201, f"Expected 201, got {reg_resp.status_code}: {reg_resp.text}"
        assert reg_resp.json()["credit_balance"] == 50 + anon_credits

    async def test_merge_sets_merged_into_user_id(self, client, pool):
        """After merge, anonymous_sessions.merged_into_user_id is set."""
        # Step 1: Create anonymous session
        anon_resp = client.post("/api/v1/auth/anonymous")
        assert anon_resp.status_code == 201
        session_id = anon_resp.json()["session_id"]

        # Step 2: Register with merge
        email = _unique_email()
        reg_resp = client.post(
            "/api/v1/auth/register",
            json={
                "email": email,
                "password": "securepassword123",
                "anon_session_id": session_id,
            },
        )
        assert reg_resp.status_code == 201
        user_id = reg_resp.json()["user_id"]

        # Step 3: Verify in DB
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT merged_into_user_id FROM anonymous_sessions WHERE id = $1",
                uuid.UUID(session_id),
            )
        assert row is not None
        assert str(row["merged_into_user_id"]) == user_id

    async def test_merge_migrates_query_logs(self, client, pool):
        """After merge, query_logs from the anonymous session are migrated to the new user."""
        # Step 1: Create anonymous session
        anon_resp = client.post("/api/v1/auth/anonymous")
        assert anon_resp.status_code == 201
        session_id = anon_resp.json()["session_id"]
        token = anon_resp.json()["token"]

        # Step 2: Make a query as anonymous user to create a query_log
        client.post(
            "/api/v1/query",
            json={"query_text": "integration test query", "language": "en"},
            headers={"Authorization": f"Bearer {token}"},
        )

        # Step 3: Register with merge
        email = _unique_email()
        reg_resp = client.post(
            "/api/v1/auth/register",
            json={
                "email": email,
                "password": "securepassword123",
                "anon_session_id": session_id,
            },
        )
        assert reg_resp.status_code == 201
        user_id = reg_resp.json()["user_id"]

        # Step 4: Verify query_logs were migrated
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT user_id FROM query_logs WHERE anon_session_id = $1",
                uuid.UUID(session_id),
            )
        # All query logs from this session should now have the new user_id
        for row in rows:
            assert str(row["user_id"]) == user_id


# ============================================================================
# Test: Login flow
# ============================================================================


class TestLoginFlow:
    """User login and token usage."""

    def test_login_returns_200(self, client):
        """Login with valid credentials returns 200."""
        email = _unique_email()
        # Register first
        reg_resp = client.post(
            "/api/v1/auth/register",
            json={"email": email, "password": "securepassword123"},
        )
        assert reg_resp.status_code == 201

        # Login
        login_resp = client.post(
            "/api/v1/auth/login",
            json={"email": email, "password": "securepassword123"},
        )
        assert login_resp.status_code == 200

        body = login_resp.json()
        assert "token" in body
        assert "user_id" in body

    def test_login_token_works_on_protected_endpoint(self, client):
        """Token from login can access a protected endpoint."""
        email = _unique_email()
        # Register
        client.post(
            "/api/v1/auth/register",
            json={"email": email, "password": "securepassword123"},
        )

        # Login
        login_resp = client.post(
            "/api/v1/auth/login",
            json={"email": email, "password": "securepassword123"},
        )
        assert login_resp.status_code == 200
        token = login_resp.json()["token"]

        # Use token on query endpoint
        query_resp = client.post(
            "/api/v1/query",
            json={"query_text": "test", "language": "en"},
            headers={"Authorization": f"Bearer {token}"},
        )
        assert query_resp.status_code != 401

    def test_login_wrong_password_401(self, client):
        """Login with wrong password returns 401."""
        email = _unique_email()
        # Register
        client.post(
            "/api/v1/auth/register",
            json={"email": email, "password": "securepassword123"},
        )

        # Login with wrong password
        login_resp = client.post(
            "/api/v1/auth/login",
            json={"email": email, "password": "wrongpassword123"},
        )
        assert login_resp.status_code == 401

    def test_login_nonexistent_email_401(self, client):
        """Login with non-existent email returns 401."""
        login_resp = client.post(
            "/api/v1/auth/login",
            json={"email": f"nonexistent-{uuid.uuid4().hex[:8]}@example.com", "password": "anything123"},
        )
        assert login_resp.status_code == 401

    def test_login_no_user_enumeration(self, client):
        """Wrong email and wrong password produce the same error response."""
        email = _unique_email()
        # Register
        client.post(
            "/api/v1/auth/register",
            json={"email": email, "password": "securepassword123"},
        )

        # Wrong password
        wrong_pwd = client.post(
            "/api/v1/auth/login",
            json={"email": email, "password": "wrongpassword123"},
        )

        # Non-existent email
        wrong_email = client.post(
            "/api/v1/auth/login",
            json={"email": f"fake-{uuid.uuid4().hex[:8]}@example.com", "password": "anything123"},
        )

        # Same status code and same error shape
        assert wrong_pwd.status_code == wrong_email.status_code == 401
        assert wrong_pwd.json()["error"] == wrong_email.json()["error"]
        assert wrong_pwd.json()["message"] == wrong_email.json()["message"]


# ============================================================================
# Test: Full end-to-end flow
# ============================================================================


class TestFullFlow:
    """Full lifecycle: anonymous -> query -> register with merge -> contribute -> login -> query."""

    def test_full_onboarding_lifecycle(self, client):
        """Exercise the complete onboarding flow end-to-end."""
        # 1. Create anonymous session
        anon_resp = client.post("/api/v1/auth/anonymous")
        assert anon_resp.status_code == 201
        anon_token = anon_resp.json()["token"]
        session_id = anon_resp.json()["session_id"]

        # 2. Query as anonymous
        query_resp = client.post(
            "/api/v1/query",
            json={"query_text": "how to fix memory leak", "language": "en"},
            headers={"Authorization": f"Bearer {anon_token}"},
        )
        assert query_resp.status_code != 401

        # 3. Register with merge
        email = _unique_email()
        reg_resp = client.post(
            "/api/v1/auth/register",
            json={
                "email": email,
                "password": "securepassword123",
                "anon_session_id": session_id,
            },
        )
        assert reg_resp.status_code == 201
        reg_token = reg_resp.json()["token"]

        # 4. Contribute as registered user
        contrib_resp = client.post(
            "/api/v1/contribute",
            json={
                "situation": "Memory leak in Python asyncio application when using aiohttp" + " " * 10,
                "solution": "Use async context managers and ensure proper cleanup of connections" + " " * 10,
                "outcome_type": "solved",
                "lessons": "Always use async with for aiohttp sessions",
                "domain": "python",
                "task_type": "debugging",
                "language": "en",
            },
            headers={"Authorization": f"Bearer {reg_token}"},
        )
        assert contrib_resp.status_code not in (401, 403)

        # 5. Login
        login_resp = client.post(
            "/api/v1/auth/login",
            json={"email": email, "password": "securepassword123"},
        )
        assert login_resp.status_code == 200
        login_token = login_resp.json()["token"]

        # 6. Query again with login token
        query_resp2 = client.post(
            "/api/v1/query",
            json={"query_text": "asyncio memory", "language": "en"},
            headers={"Authorization": f"Bearer {login_token}"},
        )
        assert query_resp2.status_code != 401
