"""
Integration test fixtures for credit system tests.
Requires PostgreSQL 16 running (OrbStack Docker or equivalent).

Fixture hierarchy:
  credit_pool        — session-scoped asyncpg pool (shared across all credit tests)
  credit_test_user   — function-scoped: creates a users row + credit_accounts row,
                       cleans up credit_transactions and credit_accounts on teardown,
                       then removes the user row.
"""

import os
import uuid

import asyncpg
import pytest_asyncio

# ---------------------------------------------------------------------------
# DSN resolution
# ---------------------------------------------------------------------------

_RAW_URL = os.getenv(
    "TEST_DATABASE_URL",
    "postgresql+asyncpg://agxp:agxp@localhost:5433/agxp",
).replace("postgresql+asyncpg://", "postgresql://", 1)


# ---------------------------------------------------------------------------
# Session-scoped pool
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def credit_pool():
    """
    Shared asyncpg connection pool for all credit integration tests.
    No pgvector codec needed here (credit tables carry no vector columns).
    """
    pool = await asyncpg.create_pool(_RAW_URL, min_size=2, max_size=5)
    yield pool
    await pool.close()


# ---------------------------------------------------------------------------
# Function-scoped test-user + credit-account factory
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture(scope="function", loop_scope="session")
async def credit_test_user(credit_pool):
    """
    Creates a user row and a corresponding credit_accounts row with an
    initial balance of 0.  Cleans up all credit data (transactions, account,
    user) after each test.

    Yields a dict:
        {
            "user_id":    str  — UUID string of the newly created user,
            "account_id": str  — UUID string of the credit_accounts row,
        }
    """
    user_id = str(uuid.uuid4())
    account_id = str(uuid.uuid4())

    await credit_pool.execute(
        "INSERT INTO users (id, display_name) VALUES ($1, $2)",
        uuid.UUID(user_id),
        "credit-integration-test-user",
    )
    await credit_pool.execute(
        """
        INSERT INTO credit_accounts (id, user_id, balance, pending_balance, tier,
                                     lifetime_earned, lifetime_spent)
        VALUES ($1, $2, 0, 0, 'free', 0, 0)
        """,
        uuid.UUID(account_id),
        uuid.UUID(user_id),
    )

    yield {"user_id": user_id, "account_id": account_id}

    # Cleanup — order matters because of FK constraints
    await credit_pool.execute(
        "DELETE FROM credit_transactions WHERE account_id = $1", uuid.UUID(account_id)
    )
    await credit_pool.execute(
        "DELETE FROM credit_accounts WHERE id = $1", uuid.UUID(account_id)
    )
    await credit_pool.execute("DELETE FROM users WHERE id = $1", uuid.UUID(user_id))


# ---------------------------------------------------------------------------
# Helper: seed initial balance directly via SQL (bypasses the writer)
# ---------------------------------------------------------------------------


async def seed_balance(pool: asyncpg.Pool, account_id: str, balance: int) -> None:
    """
    Directly update credit_accounts.balance for setup purposes.
    Used by tests that need a non-zero starting balance without going
    through the CreditWriter (avoiding circular dependency on the SUT).
    """
    await pool.execute(
        "UPDATE credit_accounts SET balance = $1 WHERE id = $2",
        balance,
        uuid.UUID(account_id),
    )
