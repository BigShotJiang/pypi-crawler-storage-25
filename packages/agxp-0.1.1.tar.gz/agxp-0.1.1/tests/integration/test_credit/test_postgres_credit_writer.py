"""
Integration tests for PostgresCreditWriter.

These tests run against a real PostgreSQL 16 instance.
Each test creates its own users / credit_accounts rows via the
`credit_test_user` fixture and deletes them on teardown.

Contract under test: agxp/services/credit_writer.py (CreditWriter ABC).
Implementation under test: agxp/services/postgres_credit_writer.py.

What is verified:
- Round-trip: credit/debit are reflected by get_balance()
- Transaction log: credit_transactions row exists after each operation
  with correct amount, balance_after, txn_type, description, idempotency_key
- Insufficient funds: debit below zero raises InsufficientCreditsError AND
  leaves the DB balance completely unchanged (no partial commit)
- Idempotency under concurrent load: same key called twice via asyncio.gather
  results in exactly one write
- FOR UPDATE row locking: two concurrent debits that together would overdraw
  — one succeeds, one raises InsufficientCreditsError; neither double-deducts
- User isolation: credits and debits on user A have no effect on user B
"""

import asyncio
import uuid

import asyncpg
import pytest
import pytest_asyncio

from agxp.services.credit_writer import CreditWriter, InsufficientCreditsError
from agxp.services.postgres_credit_writer import PostgresCreditWriter

from .conftest import seed_balance

pytestmark = pytest.mark.asyncio(loop_scope="session")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ikey() -> str:
    """Return a fresh unique idempotency key."""
    return str(uuid.uuid4())


def _make_writer(pool: asyncpg.Pool) -> PostgresCreditWriter:
    """Construct a PostgresCreditWriter wired to the test pool."""
    return PostgresCreditWriter(pool=pool)


# ---------------------------------------------------------------------------
# Instantiation
# ---------------------------------------------------------------------------


def test_postgres_credit_writer_is_subclass():
    assert issubclass(PostgresCreditWriter, CreditWriter)


# ---------------------------------------------------------------------------
# Round-trip: credit → get_balance
# ---------------------------------------------------------------------------


async def test_credit_roundtrip(credit_pool, credit_test_user):
    """
    credit() followed by get_balance() must return the credited amount.
    The return value of credit() must match get_balance() immediately after.
    """
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]

    returned = await writer.credit(
        user_id=uid,
        amount=50,
        txn_type="earn_contribution",
        description="round-trip test",
        experience_id=None,
        idempotency_key=_ikey(),
    )
    balance = await writer.get_balance(uid)
    assert returned == 50
    assert balance == 50


async def test_multiple_credits_accumulate(credit_pool, credit_test_user):
    """
    Multiple credit() calls must accumulate; get_balance() must reflect the sum.
    """
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]

    await writer.credit(uid, 10, "earn_contribution", "first",  None, _ikey())
    await writer.credit(uid, 30, "earn_contribution", "second", None, _ikey())
    await writer.credit(uid, 5,  "earn_contribution", "third",  None, _ikey())
    assert await writer.get_balance(uid) == 45


# ---------------------------------------------------------------------------
# Round-trip: debit → get_balance
# ---------------------------------------------------------------------------


async def test_debit_roundtrip(credit_pool, credit_test_user):
    """
    After a debit(), get_balance() must reflect the deduction.
    The return value of debit() must equal the post-debit balance.
    """
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]
    account_id = credit_test_user["account_id"]

    await seed_balance(credit_pool, account_id, 100)

    returned = await writer.debit(
        user_id=uid,
        amount=1,
        txn_type="spend_query",
        description="query cost",
        idempotency_key=_ikey(),
    )
    balance = await writer.get_balance(uid)
    assert returned == 99
    assert balance == 99


async def test_debit_to_zero(credit_pool, credit_test_user):
    """Debiting the entire balance must succeed and leave balance at exactly 0."""
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]
    account_id = credit_test_user["account_id"]

    await seed_balance(credit_pool, account_id, 5)
    balance = await writer.debit(uid, 5, "spend_query", "full drain", _ikey())
    assert balance == 0
    assert await writer.get_balance(uid) == 0


# ---------------------------------------------------------------------------
# Transaction log verification
# ---------------------------------------------------------------------------


async def test_credit_creates_transaction_row(credit_pool, credit_test_user):
    """
    After credit(), credit_transactions must contain exactly one new row
    with the correct amount, balance_after, txn_type, description,
    and idempotency_key.
    """
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]
    account_id = credit_test_user["account_id"]
    ikey = _ikey()

    await writer.credit(
        user_id=uid,
        amount=25,
        txn_type="earn_contribution",
        description="contribution reward",
        experience_id=None,
        idempotency_key=ikey,
    )

    rows = await credit_pool.fetch(
        "SELECT amount, balance_after, txn_type, description, idempotency_key "
        "FROM credit_transactions WHERE account_id = $1",
        account_id,
    )
    assert len(rows) == 1
    row = rows[0]
    assert row["amount"] == 25
    assert row["balance_after"] == 25
    assert row["txn_type"] == "earn_contribution"
    assert row["description"] == "contribution reward"
    assert row["idempotency_key"] == ikey


async def test_debit_creates_transaction_row(credit_pool, credit_test_user):
    """
    After debit(), credit_transactions must contain a row with a negative
    (or explicitly negative-signed) amount equal to the deducted value,
    plus the correct balance_after and txn_type.

    CONTRACT AMBIGUITY: the ABC says amount is int but does not specify
    whether the stored amount for a debit is negative (e.g. -1) or positive
    (1) with the sign implied by the direction. This test checks for -1
    as the most natural ledger convention; update if the implementation
    stores positive values for debits.
    """
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]
    account_id = credit_test_user["account_id"]

    await seed_balance(credit_pool, account_id, 100)
    ikey = _ikey()
    await writer.debit(uid, 1, "spend_query", "query cost", ikey)

    rows = await credit_pool.fetch(
        "SELECT amount, balance_after, txn_type, idempotency_key "
        "FROM credit_transactions WHERE account_id = $1",
        account_id,
    )
    assert len(rows) == 1
    row = rows[0]
    # Stored amount for a debit is expected to be negative in the ledger
    assert row["amount"] == -1
    assert row["balance_after"] == 99
    assert row["txn_type"] == "spend_query"
    assert row["idempotency_key"] == ikey


async def test_each_operation_appends_a_transaction_row(credit_pool, credit_test_user):
    """
    N operations must create exactly N rows in credit_transactions
    (assuming all use distinct idempotency keys).
    """
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]
    account_id = credit_test_user["account_id"]

    await seed_balance(credit_pool, account_id, 50)

    await writer.credit(uid, 10, "earn_contribution", "c1", None, _ikey())
    await writer.credit(uid, 10, "earn_contribution", "c2", None, _ikey())
    await writer.debit(uid, 5, "spend_query", "d1", _ikey())

    rows = await credit_pool.fetch(
        "SELECT id FROM credit_transactions WHERE account_id = $1",
        account_id,
    )
    assert len(rows) == 3


async def test_credit_with_experience_id_stored_in_transaction(credit_pool, credit_test_user):
    """
    When credit() is called with a non-None experience_id, the transaction
    row's reference_id must match the supplied experience_id.

    CONTRACT AMBIGUITY: the ABC accepts experience_id but does not name the
    column it maps to. We assume it maps to credit_transactions.reference_id
    per the model definition. Update if the implementation uses a different column.
    """
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]
    account_id = credit_test_user["account_id"]
    exp_id = str(uuid.uuid4())

    await writer.credit(
        user_id=uid,
        amount=20,
        txn_type="earn_contribution",
        description="award for exp",
        experience_id=exp_id,
        idempotency_key=_ikey(),
    )

    rows = await credit_pool.fetch(
        "SELECT reference_id FROM credit_transactions WHERE account_id = $1",
        account_id,
    )
    assert len(rows) == 1
    assert str(rows[0]["reference_id"]) == exp_id


# ---------------------------------------------------------------------------
# Insufficient funds
# ---------------------------------------------------------------------------


async def test_debit_raises_insufficient_credits_error(credit_pool, credit_test_user):
    """
    debit() when balance < amount must raise InsufficientCreditsError.
    """
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]
    account_id = credit_test_user["account_id"]

    await seed_balance(credit_pool, account_id, 3)

    with pytest.raises(InsufficientCreditsError):
        await writer.debit(uid, 10, "spend_query", "over budget", _ikey())


async def test_debit_insufficient_does_not_commit_partial_state(credit_pool, credit_test_user):
    """
    After InsufficientCreditsError the DB balance must be unchanged (no partial commit)
    and no credit_transactions row must have been inserted.
    """
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]
    account_id = credit_test_user["account_id"]

    await seed_balance(credit_pool, account_id, 3)

    with pytest.raises(InsufficientCreditsError):
        await writer.debit(uid, 10, "spend_query", "over budget", _ikey())

    # DB balance must be unchanged
    row = await credit_pool.fetchrow(
        "SELECT balance FROM credit_accounts WHERE id = $1", account_id
    )
    assert row["balance"] == 3

    # No transaction row must have been created
    txn_rows = await credit_pool.fetch(
        "SELECT id FROM credit_transactions WHERE account_id = $1", account_id
    )
    assert len(txn_rows) == 0


async def test_debit_zero_balance_raises(credit_pool, credit_test_user):
    """Attempting to debit any positive amount from a zero balance must raise."""
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]
    # balance starts at 0 (from fixture)
    with pytest.raises(InsufficientCreditsError):
        await writer.debit(uid, 1, "spend_query", "zero balance", _ikey())


# ---------------------------------------------------------------------------
# Idempotency under concurrency
# ---------------------------------------------------------------------------


async def test_concurrent_credit_same_key_applied_once(credit_pool, credit_test_user):
    """
    Two concurrent credit() calls with the same idempotency_key must result in
    exactly one write: balance is 10, not 20; exactly one transaction row exists.
    """
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]
    account_id = credit_test_user["account_id"]
    key = _ikey()

    results = await asyncio.gather(
        writer.credit(uid, 10, "earn_contribution", "concurrent-a", None, key),
        writer.credit(uid, 10, "earn_contribution", "concurrent-b", None, key),
        return_exceptions=True,
    )

    # Exactly one call must succeed (return an int); the other may raise or
    # also return the same balance (idempotent no-op).  Either way the
    # final balance must be 10, not 20.
    non_error_results = [r for r in results if isinstance(r, int)]
    assert len(non_error_results) >= 1
    assert max(non_error_results) == 10

    final_balance = await writer.get_balance(uid)
    assert final_balance == 10

    txn_rows = await credit_pool.fetch(
        "SELECT id FROM credit_transactions WHERE account_id = $1", account_id
    )
    assert len(txn_rows) == 1


async def test_concurrent_debit_same_key_applied_once(credit_pool, credit_test_user):
    """
    Two concurrent debit() calls with the same idempotency_key must result in
    exactly one write: balance is 99, not 98; exactly one transaction row.
    """
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]
    account_id = credit_test_user["account_id"]

    await seed_balance(credit_pool, account_id, 100)
    key = _ikey()

    results = await asyncio.gather(
        writer.debit(uid, 1, "spend_query", "concurrent-a", key),
        writer.debit(uid, 1, "spend_query", "concurrent-b", key),
        return_exceptions=True,
    )

    non_error_results = [r for r in results if isinstance(r, int)]
    assert len(non_error_results) >= 1
    # All successful results must be the same post-debit balance
    assert all(v == 99 for v in non_error_results)

    final_balance = await writer.get_balance(uid)
    assert final_balance == 99

    txn_rows = await credit_pool.fetch(
        "SELECT id FROM credit_transactions WHERE account_id = $1", account_id
    )
    assert len(txn_rows) == 1


# ---------------------------------------------------------------------------
# FOR UPDATE row lock: concurrent overdraft prevention
# ---------------------------------------------------------------------------


async def test_concurrent_debits_cannot_both_overdraw(credit_pool, credit_test_user):
    """
    Two concurrent debit(amount=6) calls against a balance of 10 must not both
    succeed (that would take balance to -2).  The FOR UPDATE lock in the
    PostgresCreditWriter must ensure exactly one succeeds (balance=4) and the
    other raises InsufficientCreditsError.

    Acceptable outcomes:
      - exactly one success (balance=4) and one InsufficientCreditsError
    Unacceptable outcomes:
      - both succeed (balance=-2)
      - both fail (balance=10 but money "lost")
    """
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]
    account_id = credit_test_user["account_id"]

    await seed_balance(credit_pool, account_id, 10)

    results = await asyncio.gather(
        writer.debit(uid, 6, "spend_query", "concurrent-debit-a", _ikey()),
        writer.debit(uid, 6, "spend_query", "concurrent-debit-b", _ikey()),
        return_exceptions=True,
    )

    successes = [r for r in results if isinstance(r, int)]
    errors    = [r for r in results if isinstance(r, InsufficientCreditsError)]

    assert len(successes) == 1, f"Expected exactly 1 success, got: {results}"
    assert len(errors) == 1,    f"Expected exactly 1 InsufficientCreditsError, got: {results}"
    assert successes[0] == 4

    final_balance = await writer.get_balance(uid)
    assert final_balance == 4


async def test_concurrent_debits_both_within_budget_both_succeed(credit_pool, credit_test_user):
    """
    Two concurrent debit(amount=3) calls against a balance of 100 must BOTH
    succeed (100 - 3 - 3 = 94).  The lock must not cause spurious failures.
    """
    writer = _make_writer(credit_pool)
    uid = credit_test_user["user_id"]
    account_id = credit_test_user["account_id"]

    await seed_balance(credit_pool, account_id, 100)

    results = await asyncio.gather(
        writer.debit(uid, 3, "spend_query", "concurrent-ok-a", _ikey()),
        writer.debit(uid, 3, "spend_query", "concurrent-ok-b", _ikey()),
        return_exceptions=True,
    )

    errors = [r for r in results if isinstance(r, Exception)]
    assert errors == [], f"Unexpected errors: {errors}"

    final_balance = await writer.get_balance(uid)
    assert final_balance == 94


# ---------------------------------------------------------------------------
# User isolation
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture(scope="function", loop_scope="session")
async def second_credit_test_user(credit_pool):
    """
    A second isolated user + credit_account for user-isolation tests.
    Mirrors credit_test_user but as a separate fixture so tests can
    hold two simultaneous users.
    """
    user_id    = str(uuid.uuid4())
    account_id = str(uuid.uuid4())

    await credit_pool.execute(
        "INSERT INTO users (id, display_name) VALUES ($1, $2)",
        uuid.UUID(user_id),
        "credit-integration-test-user-b",
    )
    await credit_pool.execute(
        """
        INSERT INTO credit_accounts (id, user_id, balance, pending_balance, tier,
                                     lifetime_earned, lifetime_spent)
        VALUES ($1, $2, 0, 0, 'free', 0, 0)
        """,
        uuid.UUID(account_id),
        uuid.UUID(user_id),
    )

    yield {"user_id": user_id, "account_id": account_id}

    await credit_pool.execute(
        "DELETE FROM credit_transactions WHERE account_id = $1", uuid.UUID(account_id)
    )
    await credit_pool.execute(
        "DELETE FROM credit_accounts WHERE id = $1", uuid.UUID(account_id)
    )
    await credit_pool.execute("DELETE FROM users WHERE id = $1", uuid.UUID(user_id))


async def test_credit_user_a_does_not_affect_user_b(
    credit_pool, credit_test_user, second_credit_test_user
):
    """Credits applied to user A must not appear in user B's balance."""
    writer = _make_writer(credit_pool)
    uid_a = credit_test_user["user_id"]
    uid_b = second_credit_test_user["user_id"]

    await writer.credit(uid_a, 100, "earn_contribution", "a earns", None, _ikey())

    assert await writer.get_balance(uid_b) == 0


async def test_debit_user_a_does_not_affect_user_b(
    credit_pool, credit_test_user, second_credit_test_user
):
    """Debits on user A must not alter user B's balance."""
    writer = _make_writer(credit_pool)
    uid_a = credit_test_user["user_id"]
    uid_b = second_credit_test_user["user_id"]
    acct_a = credit_test_user["account_id"]
    acct_b = second_credit_test_user["account_id"]

    await seed_balance(credit_pool, acct_a, 100)
    await seed_balance(credit_pool, acct_b, 50)

    await writer.debit(uid_a, 10, "spend_query", "a queries", _ikey())

    assert await writer.get_balance(uid_b) == 50


async def test_transaction_rows_are_user_scoped(
    credit_pool, credit_test_user, second_credit_test_user
):
    """
    Each user's credit_transactions rows are associated only with their
    own credit_accounts row; operations on user A must not create rows
    under user B's account_id.
    """
    writer = _make_writer(credit_pool)
    uid_a = credit_test_user["user_id"]
    uid_b = second_credit_test_user["user_id"]
    acct_b = second_credit_test_user["account_id"]

    await writer.credit(uid_a, 50, "earn_contribution", "a earns", None, _ikey())

    txn_rows_b = await credit_pool.fetch(
        "SELECT id FROM credit_transactions WHERE account_id = $1", acct_b
    )
    assert len(txn_rows_b) == 0


# ---------------------------------------------------------------------------
# get_balance: unknown user
# ---------------------------------------------------------------------------


async def test_get_balance_for_user_with_no_account(credit_pool):
    """
    get_balance() for a user_id that has no credit_accounts row.

    CONTRACT AMBIGUITY: the ABC says "return current credit balance" but does
    not specify what to do when no account exists. Two reasonable options:
      (a) raise an exception (e.g. KeyError or a domain-specific AccountNotFoundError)
      (b) return 0 (treat missing account as zero balance)

    This test documents the expected behaviour as returning 0, consistent with
    the FakeCreditWriter contract and the "new account" case. Update the
    assertion (or change to pytest.raises) if the implementation raises.
    """
    writer = _make_writer(credit_pool)
    # Use a user_id that was never inserted into the DB
    phantom_uid = str(uuid.uuid4())
    balance = await writer.get_balance(phantom_uid)
    assert balance == 0
