"""
Integration test fixtures for InlineQualityWriter tests.
Requires PostgreSQL 16 + pgvector running (OrbStack Docker or equivalent).

Fixture hierarchy:
  quality_pool         — session-scoped asyncpg pool (shared across all quality tests)
  quality_test_row     — function-scoped: creates a users row + an experiences row
                         with realistic text data sufficient to exercise all completeness
                         scoring bonuses.  Tears down both rows on completion.

Yields:
  quality_test_row → dict:
    {
        "user_id":       str  — UUID string of the created user,
        "experience_id": str  — UUID string of the created experience,
    }
"""

import os
import uuid

import asyncpg
import pytest_asyncio
from pgvector.asyncpg import register_vector

# ---------------------------------------------------------------------------
# DSN resolution
# ---------------------------------------------------------------------------

_RAW_URL = os.getenv(
    "TEST_DATABASE_URL",
    "postgresql+asyncpg://agxp:agxp@localhost:5433/agxp",
).replace("postgresql+asyncpg://", "postgresql://", 1)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _long_lessons(word_count: int) -> str:
    """Generate a lessons string with exactly `word_count` words."""
    return " ".join(["lesson"] * word_count)


# ---------------------------------------------------------------------------
# Session-scoped pool
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def quality_pool():
    """
    Shared asyncpg connection pool for all quality integration tests.
    pgvector codec registered so vector columns can be read/written.
    """
    pool = await asyncpg.create_pool(_RAW_URL, min_size=2, max_size=5)
    async with pool.acquire() as conn:
        await register_vector(conn)
    yield pool
    await pool.close()


# ---------------------------------------------------------------------------
# Function-scoped experience row factory
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture(scope="function", loop_scope="session")
async def quality_test_row(quality_pool):
    """
    Creates a user and an experience row with realistic text data that triggers
    all completeness scoring bonuses:

      - failed_approaches: non-empty string  (+0.15)
      - environment: non-empty dict           (+0.10)
      - solution: contains "40%" (quantifiable result)  (+0.10)
      - lessons: > 100 words                  (+0.10)
      - tags: 3 items                         (+0.05)

    The experience starts with quality_score=0.0 and is_published=False
    so that post-recompute assertions are clean.

    Yields a dict:
        {"user_id": str, "experience_id": str}
    """
    user_id = str(uuid.uuid4())
    experience_id = str(uuid.uuid4())

    # Create user row
    await quality_pool.execute(
        "INSERT INTO users (id, display_name) VALUES ($1, $2)",
        uuid.UUID(user_id),
        "quality-integration-test-user",
    )

    # Build a 101-word lessons string so it crosses the word-count threshold
    long_lessons = (
        "Increasing Lambda memory allocation is often the most effective way to reduce "
        "cold-start latency. The CPU allocation scales proportionally with memory, so "
        "computationally intensive initialisation code benefits directly. Always profile "
        "with AWS X-Ray before and after changes to confirm the improvement is real and "
        "not masked by warmup variance. Monitor cost impact: doubling memory doubles "
        "per-invocation cost, but if p99 latency drops significantly, the trade-off is "
        "usually worth it for user-facing endpoints. Set reserved concurrency carefully "
        "to avoid throttling under burst traffic. Consider provisioned concurrency for "
        "latency-critical paths. Document the configuration change in infrastructure "
        "code so future maintainers understand the reasoning behind the memory choice."
    )

    # Insert experience row
    await quality_pool.execute(
        """
        INSERT INTO experiences (
            id, user_id, domain, task_type, situation,
            failed_approaches, solution, outcome_type, lessons,
            environment, tags, language, translation_status,
            quality_score, upvotes, downvotes, use_count, is_published
        ) VALUES (
            $1,  $2,  $3,  $4,  $5,
            $6,  $7,  $8,  $9,
            $10, $11, $12, $13,
            $14, $15, $16, $17, $18
        )
        """,
        uuid.UUID(experience_id),
        uuid.UUID(user_id),
        "coding",
        "debugging",
        "When deploying to AWS Lambda the cold-start latency exceeded 3000ms causing "
        "user-facing timeouts. Needed to reduce p99 latency below 500ms.",
        "Tried increasing timeout only — cold-start still took 2800ms. "
        "Tried reducing package size — improved by only 100ms.",
        "Increased memory to 512MB and response time dropped by 40% immediately. "
        "Combined with provisioned concurrency reduced p99 to under 200ms.",
        "solved",
        long_lessons,
        '{"runtime": "python3.11", "memory": "256MB", "region": "us-east-1"}',
        ["aws", "lambda", "performance"],
        "en",
        "not_needed",
        0.0,
        0,
        0,
        0,
        False,
    )

    yield {"user_id": user_id, "experience_id": experience_id}

    # Cleanup — FK order: experiences first, then users
    await quality_pool.execute(
        "DELETE FROM experiences WHERE id = $1", uuid.UUID(experience_id)
    )
    await quality_pool.execute(
        "DELETE FROM users WHERE id = $1", uuid.UUID(user_id)
    )
