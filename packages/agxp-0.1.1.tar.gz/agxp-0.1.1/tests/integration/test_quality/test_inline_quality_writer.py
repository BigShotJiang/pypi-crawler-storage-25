"""
Integration tests for InlineQualityWriter.

These tests run against a real PostgreSQL 16 instance with pgvector.
Each test uses the `quality_test_row` fixture (function-scoped) which
creates and tears down its own user + experience rows.

Contract under test: agxp/services/quality_score_writer.py (QualityScoreWriter ABC).
Implementation under test: agxp/services/inline_quality_writer.py.

What is verified:
- recompute_score() returns a float in [0.0, 1.0]
- recompute_score() persists quality_score to the DB
- recompute_score() sets is_published = True in the DB
- recompute_score() writes completeness_score (NOT NULL after call)
- recompute_score() writes community_score (NOT NULL after call)
- Cold-start community_score == completeness_score × 0.5
- update_score() applies delta and persists to DB
- update_score() clamps result to 1.0
"""

import uuid

import asyncpg
import pytest

from agxp.services.inline_quality_writer import InlineQualityWriter

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_writer(pool: asyncpg.Pool) -> InlineQualityWriter:
    """Construct an InlineQualityWriter wired to the given test pool."""
    return InlineQualityWriter(pool=pool)


# ---------------------------------------------------------------------------
# recompute_score
# ---------------------------------------------------------------------------


async def test_recompute_score_returns_float_in_range(quality_pool, quality_test_row):
    """recompute_score() must return a float in [0.0, 1.0]."""
    writer = _make_writer(quality_pool)
    exp_id = quality_test_row["experience_id"]

    score = await writer.recompute_score(exp_id)

    assert isinstance(score, float)
    assert 0.0 <= score <= 1.0


async def test_recompute_score_updates_db_quality_score(quality_pool, quality_test_row):
    """
    After recompute_score(), SELECT quality_score FROM experiences WHERE id=$1
    must equal the returned value.
    """
    writer = _make_writer(quality_pool)
    exp_id = quality_test_row["experience_id"]

    returned_score = await writer.recompute_score(exp_id)

    row = await quality_pool.fetchrow(
        "SELECT quality_score FROM experiences WHERE id = $1",
        uuid.UUID(exp_id),
    )
    assert row is not None
    assert row["quality_score"] == pytest.approx(returned_score, abs=1e-6)


async def test_recompute_score_sets_is_published_true(quality_pool, quality_test_row):
    """
    After recompute_score(), is_published must be True in the DB.
    The fixture starts with is_published=False.
    """
    writer = _make_writer(quality_pool)
    exp_id = quality_test_row["experience_id"]

    await writer.recompute_score(exp_id)

    row = await quality_pool.fetchrow(
        "SELECT is_published FROM experiences WHERE id = $1",
        uuid.UUID(exp_id),
    )
    assert row is not None
    assert row["is_published"] is True


async def test_recompute_score_writes_completeness_score(quality_pool, quality_test_row):
    """
    After recompute_score(), completeness_score must be NOT NULL in the DB.
    The fixture starts with completeness_score=NULL.
    """
    writer = _make_writer(quality_pool)
    exp_id = quality_test_row["experience_id"]

    await writer.recompute_score(exp_id)

    row = await quality_pool.fetchrow(
        "SELECT completeness_score FROM experiences WHERE id = $1",
        uuid.UUID(exp_id),
    )
    assert row is not None
    assert row["completeness_score"] is not None


async def test_recompute_score_writes_community_score(quality_pool, quality_test_row):
    """
    After recompute_score(), community_score must be NOT NULL in the DB.
    The fixture starts with community_score=NULL.
    """
    writer = _make_writer(quality_pool)
    exp_id = quality_test_row["experience_id"]

    await writer.recompute_score(exp_id)

    row = await quality_pool.fetchrow(
        "SELECT community_score FROM experiences WHERE id = $1",
        uuid.UUID(exp_id),
    )
    assert row is not None
    assert row["community_score"] is not None


async def test_recompute_score_cold_start_community_score(quality_pool, quality_test_row):
    """
    With upvotes=0, downvotes=0, use_count=0 (cold-start), community_score must
    equal completeness_score × 0.5 (within 0.001 absolute tolerance).

    The fixture creates the experience in cold-start state.
    """
    writer = _make_writer(quality_pool)
    exp_id = quality_test_row["experience_id"]

    await writer.recompute_score(exp_id)

    row = await quality_pool.fetchrow(
        "SELECT completeness_score, community_score FROM experiences WHERE id = $1",
        uuid.UUID(exp_id),
    )
    assert row is not None
    expected_community = row["completeness_score"] * 0.5
    assert row["community_score"] == pytest.approx(expected_community, abs=0.001)


# ---------------------------------------------------------------------------
# update_score
# ---------------------------------------------------------------------------


async def test_update_score_applies_delta_to_db(quality_pool, quality_test_row):
    """
    Seed DB quality_score to 0.5 via recompute (or direct UPDATE), then call
    update_score(+0.1). The DB value must increase by 0.1.
    """
    writer = _make_writer(quality_pool)
    exp_id = quality_test_row["experience_id"]

    # Directly seed quality_score in DB to a known value
    await quality_pool.execute(
        "UPDATE experiences SET quality_score = $1 WHERE id = $2",
        0.5,
        uuid.UUID(exp_id),
    )

    new_score = await writer.update_score(exp_id, 0.1, "feedback")

    assert new_score == pytest.approx(0.6, abs=1e-6)

    row = await quality_pool.fetchrow(
        "SELECT quality_score FROM experiences WHERE id = $1",
        uuid.UUID(exp_id),
    )
    assert row is not None
    assert row["quality_score"] == pytest.approx(0.6, abs=1e-6)


async def test_update_score_clamps_to_one(quality_pool, quality_test_row):
    """
    When current score is high and delta would push above 1.0, the DB value
    must be clamped to exactly 1.0.
    """
    writer = _make_writer(quality_pool)
    exp_id = quality_test_row["experience_id"]

    # Seed quality_score near the top
    await quality_pool.execute(
        "UPDATE experiences SET quality_score = $1 WHERE id = $2",
        0.95,
        uuid.UUID(exp_id),
    )

    new_score = await writer.update_score(exp_id, 1.0, "vote")

    assert new_score <= 1.0
    assert new_score == pytest.approx(1.0)

    row = await quality_pool.fetchrow(
        "SELECT quality_score FROM experiences WHERE id = $1",
        uuid.UUID(exp_id),
    )
    assert row is not None
    assert row["quality_score"] == pytest.approx(1.0)
