"""
Integration tests for BgeM3LocalBackend.
Requires bge-m3 model download (~1.3 GB, cached after first run).
Run with: pytest -m integration
"""
import math

import pytest


@pytest.fixture(scope="module")
def backend():
    from agxp.search.backends.bgem3_local_backend import BgeM3LocalBackend
    return BgeM3LocalBackend()


@pytest.mark.integration
async def test_embed_returns_1024_dim(backend):
    result = await backend.embed(["test sentence for embedding"])
    assert len(result) == 1
    assert len(result[0]) == 1024


@pytest.mark.integration
async def test_embed_returns_normalized_vector(backend):
    result = await backend.embed(["normalize this please"])
    vec = result[0]
    norm = math.sqrt(sum(v * v for v in vec))
    assert abs(norm - 1.0) < 1e-4


@pytest.mark.integration
async def test_embed_batch_matches_individual(backend):
    texts = ["first sentence about debugging", "second sentence about python"]
    batch = await backend.embed(texts)
    single_0 = await backend.embed([texts[0]])
    single_1 = await backend.embed([texts[1]])
    for a, b in zip(batch[0][:20], single_0[0][:20]):
        assert abs(a - b) < 1e-5, "batch[0] should match single embed of texts[0]"
    for a, b in zip(batch[1][:20], single_1[0][:20]):
        assert abs(a - b) < 1e-5, "batch[1] should match single embed of texts[1]"


@pytest.mark.integration
async def test_embed_empty_list_returns_empty(backend):
    result = await backend.embed([])
    assert result == []
