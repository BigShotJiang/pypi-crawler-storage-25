"""
Integration test fixtures for vector search tests.
Requires PostgreSQL + pgvector running via OrbStack Docker.
"""
import os
import uuid

import asyncpg
import pytest_asyncio
from pgvector.asyncpg import register_vector

# Raw asyncpg DSN — strip SQLAlchemy driver prefix if present
_RAW_URL = os.getenv(
    "TEST_DATABASE_URL",
    "postgresql+asyncpg://agxp:agxp@localhost:5433/agxp",
).replace("postgresql+asyncpg://", "postgresql://", 1)


@pytest_asyncio.fixture(scope="session", loop_scope="session")
async def vector_pool():
    """Shared asyncpg pool with pgvector codec registered on every connection."""
    pool = await asyncpg.create_pool(_RAW_URL, init=register_vector, min_size=1, max_size=3)
    yield pool
    await pool.close()


@pytest_asyncio.fixture(scope="module", loop_scope="session")
async def test_user_id(vector_pool):
    """
    Creates one test user per module. Cleans up all experiences and the user
    at the end of the module.
    """
    uid = str(uuid.uuid4())
    await vector_pool.execute(
        "INSERT INTO users (id, display_name) VALUES ($1, $2)",
        uid,
        "vector-integration-test-user",
    )
    yield uid
    await vector_pool.execute("DELETE FROM experiences WHERE user_id = $1", uid)
    await vector_pool.execute("DELETE FROM users WHERE id = $1", uid)


async def insert_bare_experience(pool: asyncpg.Pool, user_id: str) -> str:
    """
    Insert a minimal experience row (no embeddings). Returns the new experience ID.
    Used by individual tests to set up data.
    """
    exp_id = str(uuid.uuid4())
    await pool.execute(
        """
        INSERT INTO experiences
            (id, user_id, domain, task_type, situation, solution, outcome_type, lessons)
        VALUES ($1, $2, 'testing', 'unit-test', 'test situation', 'test solution',
                'solved', 'test lessons')
        """,
        exp_id,
        user_id,
    )
    return exp_id
