"""
Integration tests for PgvectorBackend.

These tests require:
  - PostgreSQL + pgvector running (OrbStack Docker)
  - TEST_DATABASE_URL env var (or default postgresql://agxp:agxp@localhost:5433/agxp)

Each test inserts its own experience row and deletes it in teardown to keep the
database clean.
"""
import math
import uuid

import pytest

from agxp.search.backends.pgvector_backend import PgvectorBackend
from tests.integration.test_vector.conftest import insert_bare_experience


def _unit_vec(dim: int, hot: int) -> list[float]:
    v = [0.0] * dim
    v[hot] = 1.0
    return v


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

# backend is function-scoped: each test gets a fresh backend bound to vector_pool
@pytest.fixture
def backend(vector_pool):
    return PgvectorBackend(pool=vector_pool)


# ---------------------------------------------------------------------------
# search()
# ---------------------------------------------------------------------------


async def test_search_returns_nearest_after_upsert(backend, vector_pool, test_user_id):
    """Insert an experience, upsert its embedding, verify search returns it."""
    exp_id = await insert_bare_experience(vector_pool, test_user_id)
    try:
        vec = _unit_vec(1024, 0)
        await backend.upsert(exp_id, "situation", vec)
        results = await backend.search("situation", vec, limit=5, filters={})
        ids = [r[0] for r in results]
        assert exp_id in ids
        # Score should be close to 1.0 (same vector, cosine similarity = 1)
        score = next(score for rid, score in results if rid == exp_id)
        assert math.isclose(score, 1.0, abs_tol=1e-4)
    finally:
        await vector_pool.execute("DELETE FROM experiences WHERE id = $1", exp_id)


async def test_search_excludes_null_embeddings(backend, vector_pool, test_user_id):
    """Experiences without embeddings must not appear in search results."""
    exp_id = await insert_bare_experience(vector_pool, test_user_id)
    try:
        vec = _unit_vec(1024, 0)
        # Do NOT upsert — embedding stays NULL
        results = await backend.search("situation", vec, limit=10, filters={})
        ids = [r[0] for r in results]
        assert exp_id not in ids
    finally:
        await vector_pool.execute("DELETE FROM experiences WHERE id = $1", exp_id)


async def test_search_respects_limit(backend, vector_pool, test_user_id):
    """search() returns at most `limit` results."""
    exp_ids = []
    try:
        for i in range(4):
            exp_id = await insert_bare_experience(vector_pool, test_user_id)
            exp_ids.append(exp_id)
            # Give each a distinct but valid unit vector
            vec = _unit_vec(1024, i)
            await backend.upsert(exp_id, "situation", vec)

        results = await backend.search("situation", _unit_vec(1024, 0), limit=2, filters={})
        assert len(results) <= 2
    finally:
        for eid in exp_ids:
            await vector_pool.execute("DELETE FROM experiences WHERE id = $1", eid)


async def test_search_returns_results_in_descending_score_order(backend, vector_pool, test_user_id):
    """Closest result should have the highest score."""
    exp_close = await insert_bare_experience(vector_pool, test_user_id)
    exp_far = await insert_bare_experience(vector_pool, test_user_id)
    try:
        # exp_close shares dimension 0 with query
        await backend.upsert(exp_close, "situation", _unit_vec(1024, 0))
        # exp_far is orthogonal to query on dimension 1
        await backend.upsert(exp_far, "situation", _unit_vec(1024, 1))

        query = _unit_vec(1024, 0)
        results = await backend.search("situation", query, limit=5, filters={})
        ids = [r[0] for r in results]

        assert exp_close in ids
        assert exp_far in ids
        # exp_close must rank before exp_far
        assert ids.index(exp_close) < ids.index(exp_far)
        # Scores must be descending
        scores = [r[1] for r in results]
        assert all(scores[i] >= scores[i + 1] for i in range(len(scores) - 1))
    finally:
        for eid in [exp_close, exp_far]:
            await vector_pool.execute("DELETE FROM experiences WHERE id = $1", eid)


# ---------------------------------------------------------------------------
# upsert()
# ---------------------------------------------------------------------------


async def test_upsert_updates_embedding_column(backend, vector_pool, test_user_id):
    """After upsert, the embedding column in experiences table must be non-null."""
    exp_id = await insert_bare_experience(vector_pool, test_user_id)
    try:
        vec = _unit_vec(1024, 5)
        await backend.upsert(exp_id, "situation", vec)
        row = await vector_pool.fetchrow(
            "SELECT embedding_situation FROM experiences WHERE id = $1", exp_id
        )
        assert row["embedding_situation"] is not None
    finally:
        await vector_pool.execute("DELETE FROM experiences WHERE id = $1", exp_id)


# ---------------------------------------------------------------------------
# delete()
# ---------------------------------------------------------------------------


async def test_delete_clears_embedding_columns(backend, vector_pool, test_user_id):
    """delete() must set all embedding_* columns to NULL for the experience."""
    exp_id = await insert_bare_experience(vector_pool, test_user_id)
    try:
        vec = _unit_vec(1024, 3)
        await backend.upsert(exp_id, "situation", vec)
        await backend.delete(exp_id)

        row = await vector_pool.fetchrow(
            """
            SELECT embedding_situation, embedding_solution, embedding_lessons,
                   embedding_failed, embedding_tags, embedding_environment
            FROM experiences WHERE id = $1
            """,
            exp_id,
        )
        assert all(row[col] is None for col in row.keys())
    finally:
        await vector_pool.execute("DELETE FROM experiences WHERE id = $1", exp_id)
