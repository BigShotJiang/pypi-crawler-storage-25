"""
FakeCrossEncoder — deterministic CrossEncoderReranker for unit tests.

Scores by token overlap: |query_tokens ∩ text_tokens| / max(|query_tokens|, 1)
No model download, no GPU, milliseconds per call.
"""
from agxp.search.reranker import CrossEncoderReranker


class FakeCrossEncoder(CrossEncoderReranker):
    async def rerank(
        self,
        query: str,
        candidates: list[tuple[str, str]],
    ) -> list[tuple[str, float]]:
        if not candidates:
            return []

        query_tokens = set(query.lower().split())
        denom = max(len(query_tokens), 1)

        scored = []
        for exp_id, text in candidates:
            text_tokens = set(text.lower().split())
            overlap = len(query_tokens & text_tokens) / denom
            scored.append((exp_id, overlap))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored
