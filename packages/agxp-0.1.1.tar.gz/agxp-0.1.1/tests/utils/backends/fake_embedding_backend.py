"""Fake embedding backend for testing."""
from typing import List
import numpy as np

class FakeEmbeddingBackend:
    """Fake embedding backend that returns fixed 1024-dimensional vectors."""

    def embed(self, texts: List[str]) -> List[np.ndarray]:
        """Return fake embeddings for given texts."""
        return [np.random.rand(1024).astype(np.float32) for _ in texts]

    async def embed_async(self, texts: List[str]) -> List[np.ndarray]:
        """Async version of embed."""
        return self.embed(texts)
