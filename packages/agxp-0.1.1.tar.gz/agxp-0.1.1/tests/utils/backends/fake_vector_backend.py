"""Fake vector backend for testing."""
from typing import List, Dict, Any
import numpy as np

class FakeVectorBackend:
    """Fake vector search backend that stores vectors in memory."""

    def __init__(self):
        self._store: Dict[str, np.ndarray] = {}

    def upsert(self, experience_id: str, vector: np.ndarray) -> None:
        """Upsert a vector into the fake store."""
        self._store[experience_id] = vector

    def search(self, query_vector: np.ndarray, limit: int = 10, filters: Dict[str, Any] = None) -> List[str]:
        """Return all stored experience IDs (fake search)."""
        return list(self._store.keys())[:limit]

    def delete(self, experience_id: str) -> None:
        """Delete a vector from the store."""
        if experience_id in self._store:
            del self._store[experience_id]

    async def upsert_async(self, experience_id: str, vector: np.ndarray) -> None:
        """Async version of upsert."""
        self.upsert(experience_id, vector)

    async def search_async(self, query_vector: np.ndarray, limit: int = 10, filters: Dict[str, Any] = None) -> List[str]:
        """Async version of search."""
        return self.search(query_vector, limit, filters)
