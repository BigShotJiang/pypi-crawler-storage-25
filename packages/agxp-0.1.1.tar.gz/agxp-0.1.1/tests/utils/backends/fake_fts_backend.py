"""Fake FTS backend for testing."""
from typing import List, Dict, Any, Tuple
from agxp.search.backends.fts_backend import FullTextSearchBackend

class FakeFTSBackend(FullTextSearchBackend):
    """Fake full-text search backend that stores documents in memory."""

    def __init__(self):
        self._store: Dict[str, Dict[str, Any]] = {}

    async def index(self, experience_id: str, document: Dict[str, Any]) -> None:
        """Add or update a document in the full-text index."""
        self._store[experience_id] = document

    async def search(
        self,
        query: str,
        fields: list[str] = None,
        field_boosts: dict[str, float] = None,
        filters: dict = None,
        limit: int = 10,
    ) -> List[Tuple[str, float]]:
        """Search for documents containing the query as substring, return [(id, score), ...]."""
        results = []
        for exp_id, doc in self._store.items():
            if query.lower() in str(doc).lower():
                results.append((exp_id, 1.0))
                if len(results) >= limit:
                    break
        return results

    async def delete(self, experience_id: str) -> None:
        """Remove a document from the full-text index."""
        if experience_id in self._store:
            del self._store[experience_id]
