"""
Unit tests for estimated credit calculation in the contribute route.

The estimation uses credits_for_quality(completeness_score(request_dict))
to provide a quick pre-scoring estimate before the full async pipeline runs.

Pure function — no I/O.
"""

import pytest

from agxp.services.inline_quality_writer import compute_completeness_score
from agxp.workers.credit import credits_for_quality


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _minimal_request_as_row() -> dict:
    """Minimal valid contribution — only required fields, no optionals."""
    return {
        "failed_approaches": None,
        "environment": None,
        "solution": "B" * 50,
        "lessons": "C" * 30,
        "tags": None,
    }


def _estimate(row: dict) -> int:
    """Replicate the route's estimation logic."""
    return credits_for_quality(compute_completeness_score(row))


# ---------------------------------------------------------------------------
# 1. Minimal contribution → base completeness (0.50) → 5 credits
# ---------------------------------------------------------------------------


def test_minimal_contribution_estimates_ten_credits():
    """Minimal request with no optional fields → completeness 0.50 �� 10 credits.

    credits_for_quality boundary: [0.5, 0.7) → 10 credits.
    """
    row = _minimal_request_as_row()
    assert compute_completeness_score(row) == pytest.approx(0.50)
    assert _estimate(row) == 10


# ---------------------------------------------------------------------------
# 2. With failed_approaches → completeness 0.65 → 10 credits
# ---------------------------------------------------------------------------


def test_with_failed_approaches_estimates_ten_credits():
    """Adding failed_approaches bumps completeness to 0.65 → 10 credits."""
    row = _minimal_request_as_row()
    row["failed_approaches"] = "Tried increasing timeout but that didn't help"
    assert compute_completeness_score(row) == pytest.approx(0.65)
    assert _estimate(row) == 10


# ---------------------------------------------------------------------------
# 3. With failed_approaches + environment → completeness 0.75 → 25 credits
# ---------------------------------------------------------------------------


def test_with_failed_and_env_estimates_twentyfive_credits():
    """failed_approaches + environment → completeness 0.75 → 25 credits."""
    row = _minimal_request_as_row()
    row["failed_approaches"] = "Tried increasing timeout but that didn't help"
    row["environment"] = {"python": "3.11"}
    assert compute_completeness_score(row) == pytest.approx(0.75)
    assert _estimate(row) == 25


# ---------------------------------------------------------------------------
# 4. All bonuses → completeness 1.0 → 50 credits
# ---------------------------------------------------------------------------


def test_all_bonuses_estimates_fifty_credits():
    """All completeness bonuses triggered → score ~1.0 → 50 credits."""
    row = {
        "failed_approaches": "Tried increasing timeout",
        "environment": {"python": "3.11"},
        "solution": "Increased memory to 512MB and response time dropped 40%",
        "lessons": " ".join(["word"] * 101),
        "tags": ["aws", "lambda", "performance"],
    }
    score = compute_completeness_score(row)
    assert score >= 0.85
    assert _estimate(row) == 50


# ---------------------------------------------------------------------------
# 5. Estimation is deterministic
# ---------------------------------------------------------------------------


def test_estimation_is_deterministic():
    """Same input must produce the same estimated credits every time."""
    row = _minimal_request_as_row()
    row["failed_approaches"] = "Tried X"
    results = [_estimate(row) for _ in range(10)]
    assert len(set(results)) == 1
