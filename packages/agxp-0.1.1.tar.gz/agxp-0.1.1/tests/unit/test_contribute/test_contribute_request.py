"""
Unit tests for ContributeRequest Pydantic model validation.

Lives in: agxp/api/routes/contribute.py

Tests cover:
  1. Valid minimal request passes validation
  2. Valid full request (all optional fields) passes validation
  3. situation too short → ValidationError
  4. solution too short → ValidationError
  5. lessons too short → ValidationError
  6. invalid outcome_type → ValidationError
  7. tags exceed max 10 items → ValidationError
  8. single tag exceeds max 32 chars → ValidationError
  9. domain exceeds max 64 chars → ValidationError
"""

import pytest
from pydantic import ValidationError

from agxp.api.routes.contribute import ContributeRequest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _valid_payload(**overrides) -> dict:
    """Return a minimal valid ContributeRequest payload with optional overrides."""
    base = {
        "situation": "A" * 50,
        "solution": "B" * 50,
        "outcome_type": "solved",
        "lessons": "C" * 30,
        "domain": "cloud",
        "task_type": "debugging",
        "language": "en",
    }
    base.update(overrides)
    return base


# ---------------------------------------------------------------------------
# 1. Valid minimal request
# ---------------------------------------------------------------------------


def test_valid_minimal_request():
    """Minimal required fields must pass validation."""
    req = ContributeRequest(**_valid_payload())
    assert req.situation == "A" * 50
    assert req.outcome_type == "solved"


# ---------------------------------------------------------------------------
# 2. Valid full request with all optional fields
# ---------------------------------------------------------------------------


def test_valid_full_request():
    """All optional fields provided must pass validation."""
    req = ContributeRequest(**_valid_payload(
        failed_approaches="Tried X, Y, Z",
        environment={"python": "3.11", "os": "linux"},
        subdomain="serverless",
        tags=["aws", "lambda", "timeout"],
    ))
    assert req.subdomain == "serverless"
    assert req.tags == ["aws", "lambda", "timeout"]
    assert req.environment == {"python": "3.11", "os": "linux"}


# ---------------------------------------------------------------------------
# 3. situation too short
# ---------------------------------------------------------------------------


def test_situation_too_short():
    """situation with fewer than 50 chars must fail validation."""
    with pytest.raises(ValidationError) as exc_info:
        ContributeRequest(**_valid_payload(situation="short"))
    assert "situation" in str(exc_info.value)


# ---------------------------------------------------------------------------
# 4. solution too short
# ---------------------------------------------------------------------------


def test_solution_too_short():
    """solution with fewer than 50 chars must fail validation."""
    with pytest.raises(ValidationError) as exc_info:
        ContributeRequest(**_valid_payload(solution="short"))
    assert "solution" in str(exc_info.value)


# ---------------------------------------------------------------------------
# 5. lessons too short
# ---------------------------------------------------------------------------


def test_lessons_too_short():
    """lessons with fewer than 30 chars must fail validation."""
    with pytest.raises(ValidationError) as exc_info:
        ContributeRequest(**_valid_payload(lessons="short"))
    assert "lessons" in str(exc_info.value)


# ---------------------------------------------------------------------------
# 6. invalid outcome_type
# ---------------------------------------------------------------------------


def test_invalid_outcome_type():
    """outcome_type not in {solved, workaround, unresolved} must fail."""
    with pytest.raises(ValidationError) as exc_info:
        ContributeRequest(**_valid_payload(outcome_type="failed"))
    assert "outcome_type" in str(exc_info.value)


# ---------------------------------------------------------------------------
# 7. tags exceed max 10 items
# ---------------------------------------------------------------------------


def test_tags_exceed_max_items():
    """More than 10 tags must fail validation."""
    with pytest.raises(ValidationError) as exc_info:
        ContributeRequest(**_valid_payload(tags=[f"tag{i}" for i in range(11)]))
    assert "tags" in str(exc_info.value)


# ---------------------------------------------------------------------------
# 8. single tag exceeds max 32 chars
# ---------------------------------------------------------------------------


def test_tag_too_long():
    """A single tag longer than 32 chars must fail validation."""
    with pytest.raises(ValidationError) as exc_info:
        ContributeRequest(**_valid_payload(tags=["x" * 33]))
    assert "tags" in str(exc_info.value)


# ---------------------------------------------------------------------------
# 9. domain exceeds max 64 chars
# ---------------------------------------------------------------------------


def test_domain_too_long():
    """domain longer than 64 chars must fail validation."""
    with pytest.raises(ValidationError) as exc_info:
        ContributeRequest(**_valid_payload(domain="d" * 65))
    assert "domain" in str(exc_info.value)
