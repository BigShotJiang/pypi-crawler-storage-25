"""
Unit tests for POST /api/v1/contribute endpoint.

Strategy:
- Use FastAPI TestClient (synchronous HTTP client).
- Patch module-level helpers (insert_experience, fts_index_experience,
  dispatch_embed) to avoid real DB / FTS / Celery calls.
- Override require_auth dependency with a fake AuthIdentity.

The route handler is responsible for:
  1. Pydantic validation
  2. Auth check (registered users only, anonymous → 403)
  3. Generate experience_id
  4. INSERT into DB (patched)
  5. FTS index (patched)
  6. Celery dispatch (patched)
  7. Estimate credits
  8. Return 202 with experience_id, status, estimated_credits, message
"""

import uuid
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from agxp.api.app import app
from agxp.auth.dependency import require_auth
from agxp.auth.models import AuthIdentity


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_FAKE_USER_ID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"

_FAKE_REGISTERED_IDENTITY = AuthIdentity(
    user_id=_FAKE_USER_ID,
    anon_session_id=None,
    is_anonymous=False,
)

_FAKE_ANON_IDENTITY = AuthIdentity(
    user_id=None,
    anon_session_id=str(uuid.uuid4()),
    is_anonymous=True,
)


def _valid_body(**overrides) -> dict:
    """Return a valid contribute request body."""
    base = {
        "situation": "A" * 50,
        "solution": "B" * 50,
        "outcome_type": "solved",
        "lessons": "C" * 30,
        "domain": "cloud",
        "task_type": "debugging",
        "language": "en",
    }
    base.update(overrides)
    return base


def _patch_all():
    """Context manager that patches all three module-level helpers."""
    insert_mock = AsyncMock()
    fts_mock = AsyncMock()
    dispatch_mock = MagicMock()
    return (
        patch("agxp.api.routes.contribute.insert_experience", insert_mock),
        patch("agxp.api.routes.contribute.fts_index_experience", fts_mock),
        patch("agxp.api.routes.contribute.dispatch_embed", dispatch_mock),
        insert_mock,
        fts_mock,
        dispatch_mock,
    )


@pytest.fixture(autouse=True)
def _override_auth():
    """Override require_auth with a fake registered identity for all tests."""
    app.dependency_overrides[require_auth] = lambda: _FAKE_REGISTERED_IDENTITY
    yield
    app.dependency_overrides.clear()


# ---------------------------------------------------------------------------
# 1. Valid request returns 202
# ---------------------------------------------------------------------------


def test_contribute_returns_202():
    """A valid POST to /api/v1/contribute must return HTTP 202."""
    p_insert, p_fts, p_dispatch, _, _, _ = _patch_all()
    with p_insert, p_fts, p_dispatch:
        client = TestClient(app)
        response = client.post("/api/v1/contribute", json=_valid_body())
    assert response.status_code == 202


# ---------------------------------------------------------------------------
# 2. Response body has required fields
# ---------------------------------------------------------------------------


def test_contribute_response_body_fields():
    """Response must contain experience_id, status, estimated_credits, message."""
    p_insert, p_fts, p_dispatch, _, _, _ = _patch_all()
    with p_insert, p_fts, p_dispatch:
        client = TestClient(app)
        response = client.post("/api/v1/contribute", json=_valid_body())
    body = response.json()
    assert "experience_id" in body
    assert body["status"] == "pending_scoring"
    assert "estimated_credits" in body
    assert isinstance(body["estimated_credits"], int)
    assert "message" in body


# ---------------------------------------------------------------------------
# 3. insert_experience is called with correct experience_id and user_id
# ---------------------------------------------------------------------------


def test_contribute_calls_insert_experience():
    """insert_experience must be awaited with (experience_id, request, user_id)."""
    p_insert, p_fts, p_dispatch, insert_mock, _, _ = _patch_all()
    with p_insert, p_fts, p_dispatch:
        client = TestClient(app)
        response = client.post("/api/v1/contribute", json=_valid_body())
    insert_mock.assert_awaited_once()
    call_args = insert_mock.call_args[0]
    assert call_args[0] == response.json()["experience_id"]
    # Third arg is user_id from identity
    assert call_args[2] == _FAKE_USER_ID


# ---------------------------------------------------------------------------
# 4. fts_index_experience is called
# ---------------------------------------------------------------------------


def test_contribute_calls_fts_index():
    """fts_index_experience must be awaited exactly once."""
    p_insert, p_fts, p_dispatch, _, fts_mock, _ = _patch_all()
    with p_insert, p_fts, p_dispatch:
        client = TestClient(app)
        client.post("/api/v1/contribute", json=_valid_body())
    fts_mock.assert_awaited_once()


# ---------------------------------------------------------------------------
# 5. dispatch_embed is called with experience_id and user_id from identity
# ---------------------------------------------------------------------------


def test_contribute_dispatches_embed_task():
    """dispatch_embed must be called with (experience_id, identity.user_id)."""
    p_insert, p_fts, p_dispatch, _, _, dispatch_mock = _patch_all()
    with p_insert, p_fts, p_dispatch:
        client = TestClient(app)
        response = client.post("/api/v1/contribute", json=_valid_body())
    dispatch_mock.assert_called_once()
    call_args = dispatch_mock.call_args[0]
    assert call_args[0] == response.json()["experience_id"]
    assert call_args[1] == _FAKE_USER_ID


# ---------------------------------------------------------------------------
# 6. Invalid body returns 422
# ---------------------------------------------------------------------------


def test_contribute_rejects_missing_required_field():
    """Missing required field (situation) must return 422."""
    client = TestClient(app)
    body = _valid_body()
    del body["situation"]
    response = client.post("/api/v1/contribute", json=body)
    assert response.status_code == 422


# ---------------------------------------------------------------------------
# 7. estimated_credits is a positive integer
# ---------------------------------------------------------------------------


def test_contribute_estimated_credits_positive():
    """estimated_credits must be a positive integer (>= 5, the minimum tier)."""
    p_insert, p_fts, p_dispatch, _, _, _ = _patch_all()
    with p_insert, p_fts, p_dispatch:
        client = TestClient(app)
        response = client.post("/api/v1/contribute", json=_valid_body())
    assert response.json()["estimated_credits"] >= 5


# ---------------------------------------------------------------------------
# 8. Anonymous user → 403
# ---------------------------------------------------------------------------


def test_anonymous_user_returns_403():
    """Anonymous users must be rejected with 403."""
    app.dependency_overrides[require_auth] = lambda: _FAKE_ANON_IDENTITY
    p_insert, p_fts, p_dispatch, insert_mock, _, _ = _patch_all()
    with p_insert, p_fts, p_dispatch:
        client = TestClient(app)
        response = client.post("/api/v1/contribute", json=_valid_body())
    assert response.status_code == 403
    assert response.json()["error"] == "forbidden"
    insert_mock.assert_not_awaited()
