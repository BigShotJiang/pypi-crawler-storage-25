"""
Unit tests for Issue #26 — Server POST /api/v1/feedback endpoint.

Tests the HTTP contract for the feedback endpoint:
  - Auth required (Bearer token)
  - Request: {"experience_id": "uuid", "useful": bool}
  - Response 200: {"experience_id": "...", "quality_score": float, "status": "updated", "credits_earned": 1}
  - Response 404: experience not found
  - Response 429: this experience already received feedback today (global, not per-user)
  - Updates quality_score: +0.05 (useful) / -0.03 (not useful)
  - Awards 1 credit to user
  - Credit award failure only logs warning, doesn't fail the request

Strategy:
- Use FastAPI TestClient (synchronous HTTP client).
- Patch module-level helpers in agxp.api.routes.feedback:
  - update_quality_score (DB write)
  - check_feedback_rate_limit (search_feedback table check)
  - record_feedback (insert into search_feedback)
  - award_credit (credit writing)
  - get_experience (existence check)
- Override require_auth dependency with a fake AuthIdentity.
"""

import uuid
from unittest.mock import AsyncMock, patch, MagicMock

import pytest
from fastapi.testclient import TestClient

from agxp.api.app import app
from agxp.auth.dependency import require_auth
from agxp.auth.models import AuthIdentity

# ---------------------------------------------------------------------------
# Auth override
# ---------------------------------------------------------------------------

_FAKE_IDENTITY = AuthIdentity(
    user_id="aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
    anon_session_id=None,
    is_anonymous=False,
)


@pytest.fixture(autouse=True)
def _override_auth():
    """Override require_auth with a fake identity for all tests."""
    app.dependency_overrides[require_auth] = lambda: _FAKE_IDENTITY
    yield
    app.dependency_overrides.clear()


# ---------------------------------------------------------------------------
# Canned data
# ---------------------------------------------------------------------------

_VALID_EXPERIENCE_ID = str(uuid.uuid4())
_NONEXISTENT_EXPERIENCE_ID = str(uuid.uuid4())

_CANNED_EXPERIENCE = {
    "id": _VALID_EXPERIENCE_ID,
    "domain": "coding",
    "task_type": "debugging",
    "situation": "asyncio event loop blocks on database query",
    "solution": "Use run_in_executor for blocking I/O",
    "quality_score": 0.65,
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_patches(
    *,
    experience_exists: bool = True,
    rate_limited: bool = False,
    quality_score_after: float = 0.70,
    credit_award_fails: bool = False,
):
    """Return a context manager stack of patches for the feedback route."""
    # get_experience: returns experience dict or None
    mock_get = AsyncMock(
        return_value=_CANNED_EXPERIENCE if experience_exists else None
    )

    # check_feedback_rate_limit: returns True if rate-limited
    mock_rate_limit = AsyncMock(return_value=rate_limited)

    # update_quality_score: returns the new quality score
    mock_update_score = AsyncMock(return_value=quality_score_after)

    # record_feedback: records the feedback in search_feedback table
    mock_record = AsyncMock(return_value=None)

    # award_credit: awards 1 credit to user
    if credit_award_fails:
        mock_award = AsyncMock(side_effect=Exception("credit service unavailable"))
    else:
        mock_award = AsyncMock(return_value=None)

    return (
        patch("agxp.api.routes.feedback.get_experience", mock_get),
        patch("agxp.api.routes.feedback.check_feedback_rate_limit", mock_rate_limit),
        patch("agxp.api.routes.feedback.update_quality_score", mock_update_score),
        patch("agxp.api.routes.feedback.record_feedback", mock_record),
        patch("agxp.api.routes.feedback.award_credit", mock_award),
    )


def _post_feedback(experience_id: str, useful: bool, *, auth: bool = True):
    """Send POST /api/v1/feedback and return the response."""
    if not auth:
        app.dependency_overrides.clear()  # Remove auth override -> 401

    client = TestClient(app)
    return client.post(
        "/api/v1/feedback",
        json={"experience_id": experience_id, "useful": useful},
    )


# ===========================================================================
# 1. test_feedback_useful_updates_score
# ===========================================================================


def test_feedback_useful_updates_score():
    """POST /api/v1/feedback with useful=true -> 200, quality_score increased."""
    patches = _make_patches(quality_score_after=0.70)
    with patches[0], patches[1], patches[2], patches[3], patches[4]:
        response = _post_feedback(_VALID_EXPERIENCE_ID, useful=True)

    assert response.status_code == 200
    body = response.json()
    assert body["experience_id"] == _VALID_EXPERIENCE_ID
    assert body["quality_score"] == 0.70
    assert body["status"] == "updated"


# ===========================================================================
# 2. test_feedback_not_useful_updates_score
# ===========================================================================


def test_feedback_not_useful_updates_score():
    """POST /api/v1/feedback with useful=false -> 200, quality_score decreased."""
    patches = _make_patches(quality_score_after=0.62)
    with patches[0], patches[1], patches[2], patches[3], patches[4]:
        response = _post_feedback(_VALID_EXPERIENCE_ID, useful=False)

    assert response.status_code == 200
    body = response.json()
    assert body["quality_score"] == 0.62
    assert body["status"] == "updated"


# ===========================================================================
# 3. test_feedback_nonexistent_experience_returns_404
# ===========================================================================


def test_feedback_nonexistent_experience_returns_404():
    """experience_id not in DB -> 404."""
    patches = _make_patches(experience_exists=False)
    with patches[0], patches[1], patches[2], patches[3], patches[4]:
        response = _post_feedback(_NONEXISTENT_EXPERIENCE_ID, useful=True)

    assert response.status_code == 404


# ===========================================================================
# 4. test_feedback_requires_auth
# ===========================================================================


def test_feedback_requires_auth():
    """No Bearer token -> 401."""
    patches = _make_patches()
    with patches[0], patches[1], patches[2], patches[3], patches[4]:
        response = _post_feedback(_VALID_EXPERIENCE_ID, useful=True, auth=False)

    assert response.status_code == 401


# ===========================================================================
# 5. test_feedback_awards_credit
# ===========================================================================


def test_feedback_awards_credit():
    """Response includes credits_earned=1."""
    patches = _make_patches(quality_score_after=0.70)
    with patches[0], patches[1], patches[2], patches[3], patches[4]:
        response = _post_feedback(_VALID_EXPERIENCE_ID, useful=True)

    assert response.status_code == 200
    body = response.json()
    assert body["credits_earned"] == 1


# ===========================================================================
# 6. test_feedback_same_experience_twice_today_returns_429
# ===========================================================================


def test_feedback_same_experience_twice_today_returns_429():
    """Second feedback on same experience same day -> 429."""
    patches = _make_patches(rate_limited=True)
    with patches[0], patches[1], patches[2], patches[3], patches[4]:
        response = _post_feedback(_VALID_EXPERIENCE_ID, useful=True)

    assert response.status_code == 429


# ===========================================================================
# 7. test_feedback_same_experience_next_day_allowed
# ===========================================================================


def test_feedback_same_experience_next_day_allowed():
    """After 24h, same experience can receive feedback again (rate_limited=False)."""
    patches = _make_patches(rate_limited=False, quality_score_after=0.75)
    with patches[0], patches[1], patches[2], patches[3], patches[4]:
        response = _post_feedback(_VALID_EXPERIENCE_ID, useful=True)

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "updated"
    assert body["quality_score"] == 0.75


# ===========================================================================
# 8. test_feedback_invalid_experience_id_format
# ===========================================================================


def test_feedback_invalid_experience_id_format():
    """Non-UUID string -> 422 or 400."""
    patches = _make_patches()
    with patches[0], patches[1], patches[2], patches[3], patches[4]:
        response = _post_feedback("not-a-valid-uuid", useful=True)

    assert response.status_code in (400, 422)


# ===========================================================================
# 9. test_feedback_credit_failure_does_not_fail_request
# ===========================================================================


def test_feedback_credit_failure_does_not_fail_request():
    """Credit award failure only logs warning, doesn't fail the request."""
    patches = _make_patches(
        quality_score_after=0.70,
        credit_award_fails=True,
    )
    with patches[0], patches[1], patches[2], patches[3], patches[4]:
        response = _post_feedback(_VALID_EXPERIENCE_ID, useful=True)

    # Request should still succeed even though credit award failed
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "updated"
    assert body["quality_score"] == 0.70
    assert body["credits_earned"] == 0  # Credit failed, no credits awarded
