"""
Unit tests for query endpoint warning passthrough (Issue #16).

Verifies that warnings from PIPELINE.run() are included in the NDJSON meta block.

After Issue #16, PIPELINE.run() returns:
    {"results": [...], "warnings": [...]}

The meta NDJSON block should include:
    {"type": "meta", "query_id": "...", "latency_ms": N, "warnings": [...]}
"""

import json
from unittest.mock import AsyncMock, patch

import pytest
from fastapi.testclient import TestClient

from agxp.api.app import app
from agxp.auth.dependency import require_auth
from agxp.auth.models import AuthIdentity

# ---------------------------------------------------------------------------
# Auth override
# ---------------------------------------------------------------------------

_FAKE_IDENTITY = AuthIdentity(
    user_id="aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
    anon_session_id=None,
    is_anonymous=False,
)


@pytest.fixture(autouse=True)
def _override_auth():
    """Override require_auth with a fake identity for all tests."""
    app.dependency_overrides[require_auth] = lambda: _FAKE_IDENTITY
    yield
    app.dependency_overrides.clear()


# ---------------------------------------------------------------------------
# Canned data
# ---------------------------------------------------------------------------

_CANNED_EXPERIENCE_ROWS = {
    "exp_001": {
        "id": "exp_001",
        "domain": "cloud",
        "task_type": "debugging",
        "situation": "lambda timeout issue in aws production",
        "solution": "increase timeout and add retry logic",
        "lessons": "always set explicit timeouts",
        "outcome_type": "solved",
        "language": "en",
        "tags": ["aws", "lambda"],
        "quality_score": 0.85,
    },
}

_CANNED_RRF_RESULTS_WITH_WARNINGS = {
    "results": [{"experience_id": "exp_001", "rrf_score": 0.032}],
    "warnings": ["Vector search failed: index corrupted", "Embedding failed: model timeout"],
}

_CANNED_RRF_RESULTS_NO_WARNINGS = {
    "results": [{"experience_id": "exp_001", "rrf_score": 0.032}],
    "warnings": [],
}


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def _parse_ndjson(text: str) -> list[dict]:
    lines = [line.strip() for line in text.strip().splitlines() if line.strip()]
    return [json.loads(line) for line in lines]


# ---------------------------------------------------------------------------
# 1. Warnings included in meta NDJSON
# ---------------------------------------------------------------------------


def test_warnings_included_in_meta_ndjson():
    """When PIPELINE.run() returns warnings, the meta NDJSON block must contain them."""
    mock_pipeline = AsyncMock()
    mock_pipeline.run = AsyncMock(return_value=_CANNED_RRF_RESULTS_WITH_WARNINGS)

    with patch("agxp.api.routes.query.PIPELINE", mock_pipeline), patch(
        "agxp.api.routes.query.fetch_experiences_by_ids",
        new=AsyncMock(return_value=_CANNED_EXPERIENCE_ROWS),
    ):
        client = TestClient(app)
        response = client.post(
            "/api/v1/query",
            json={"query": "lambda timeout"},
        )

    assert response.status_code == 200
    lines = _parse_ndjson(response.text)
    meta = next((line for line in lines if line.get("type") == "meta"), None)
    assert meta is not None, "No meta line found in NDJSON response"
    assert "warnings" in meta
    assert meta["warnings"] == _CANNED_RRF_RESULTS_WITH_WARNINGS["warnings"]


# ---------------------------------------------------------------------------
# 2. No warnings — meta has empty list
# ---------------------------------------------------------------------------


def test_no_warnings_meta_has_empty_list():
    """When PIPELINE.run() returns no warnings, meta block has warnings: []."""
    mock_pipeline = AsyncMock()
    mock_pipeline.run = AsyncMock(return_value=_CANNED_RRF_RESULTS_NO_WARNINGS)

    with patch("agxp.api.routes.query.PIPELINE", mock_pipeline), patch(
        "agxp.api.routes.query.fetch_experiences_by_ids",
        new=AsyncMock(return_value=_CANNED_EXPERIENCE_ROWS),
    ):
        client = TestClient(app)
        response = client.post(
            "/api/v1/query",
            json={"query": "lambda timeout"},
        )

    assert response.status_code == 200
    lines = _parse_ndjson(response.text)
    meta = next((line for line in lines if line.get("type") == "meta"), None)
    assert meta is not None, "No meta line found in NDJSON response"
    assert "warnings" in meta
    assert meta["warnings"] == []
