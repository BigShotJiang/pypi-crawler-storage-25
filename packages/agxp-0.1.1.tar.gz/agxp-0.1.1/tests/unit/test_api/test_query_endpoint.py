"""
Unit tests for POST /api/v1/query endpoint.

Strategy:
- Use FastAPI TestClient (synchronous HTTP client).
- Patch agxp.api.routes.query.PIPELINE with a mock QueryPipeline that returns
  a fixed list of rrf results, bypassing real backends and DB access.
- Patch the DB experience fetch in the route handler to return canned rows.
- Override require_auth dependency with a fake AuthIdentity.

The route handler is responsible for:
  1. Calling PIPELINE.run(request) to get rrf results
  2. Fetching full experience data from DB for the returned experience_ids
  3. Applying min_quality filter
  4. Reranking with cross-encoder
  5. Quality blending
  6. Streaming NDJSON response

These tests verify the HTTP contract only. Business logic is tested in
test_query_pipeline.py, test_rrf_fusion.py, and test_quality_blend.py.
"""

import json
from unittest.mock import AsyncMock, patch

import pytest
from fastapi.testclient import TestClient

from agxp.api.app import app
from agxp.auth.dependency import require_auth
from agxp.auth.models import AuthIdentity

# ---------------------------------------------------------------------------
# Auth override
# ---------------------------------------------------------------------------

_FAKE_IDENTITY = AuthIdentity(
    user_id="aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
    anon_session_id=None,
    is_anonymous=False,
)


@pytest.fixture(autouse=True)
def _override_auth():
    """Override require_auth with a fake identity for all tests."""
    app.dependency_overrides[require_auth] = lambda: _FAKE_IDENTITY
    yield
    app.dependency_overrides.clear()


# ---------------------------------------------------------------------------
# Canned data shared across tests
# ---------------------------------------------------------------------------

_CANNED_RRF_RESULTS = {
    "results": [
        {"experience_id": "exp_001", "rrf_score": 0.032},
        {"experience_id": "exp_002", "rrf_score": 0.025},
    ],
    "warnings": [],
}

_CANNED_EXPERIENCE_ROWS = {
    "exp_001": {
        "id": "exp_001",
        "domain": "cloud",
        "task_type": "debugging",
        "situation": "lambda timeout issue in aws production",
        "solution": "increase timeout and add retry logic",
        "lessons": "always set explicit timeouts",
        "outcome_type": "solved",
        "language": "en",
        "tags": ["aws", "lambda", "timeout"],
        "quality_score": 0.85,
    },
    "exp_002": {
        "id": "exp_002",
        "domain": "infrastructure",
        "task_type": "configuration",
        "situation": "kubernetes pod scheduling failure",
        "solution": "update node affinity rules",
        "lessons": "label nodes before deploying workloads",
        "outcome_type": "solved",
        "language": "en",
        "tags": ["kubernetes", "scheduling"],
        "quality_score": 0.72,
    },
}

# ---------------------------------------------------------------------------
# Helper: parse NDJSON response body into a list of dicts
# ---------------------------------------------------------------------------


def _parse_ndjson(text: str) -> list[dict]:
    lines = [line.strip() for line in text.strip().splitlines() if line.strip()]
    return [json.loads(line) for line in lines]


# ---------------------------------------------------------------------------
# 1. POST with valid body returns 200
# ---------------------------------------------------------------------------


def test_query_endpoint_returns_200():
    """A valid POST to /api/v1/query must return HTTP 200."""
    mock_pipeline = AsyncMock()
    mock_pipeline.run = AsyncMock(return_value=_CANNED_RRF_RESULTS)

    with patch("agxp.api.routes.query.PIPELINE", mock_pipeline), patch(
        "agxp.api.routes.query.fetch_experiences_by_ids",
        new=AsyncMock(return_value=_CANNED_EXPERIENCE_ROWS),
    ):
        client = TestClient(app)
        response = client.post(
            "/api/v1/query",
            json={"query": "lambda timeout"},
        )
    assert response.status_code == 200


# ---------------------------------------------------------------------------
# 2. Response Content-Type includes ndjson
# ---------------------------------------------------------------------------


def test_query_endpoint_content_type_ndjson():
    """Response Content-Type must include 'application/x-ndjson'."""
    mock_pipeline = AsyncMock()
    mock_pipeline.run = AsyncMock(return_value=_CANNED_RRF_RESULTS)

    with patch("agxp.api.routes.query.PIPELINE", mock_pipeline), patch(
        "agxp.api.routes.query.fetch_experiences_by_ids",
        new=AsyncMock(return_value=_CANNED_EXPERIENCE_ROWS),
    ):
        client = TestClient(app)
        response = client.post(
            "/api/v1/query",
            json={"query": "lambda timeout"},
        )
    assert "application/x-ndjson" in response.headers.get("content-type", "")


# ---------------------------------------------------------------------------
# 3. First NDJSON line has type == "meta"
# ---------------------------------------------------------------------------


def test_query_response_has_meta_line():
    """The first parsed NDJSON line must have type == 'meta'."""
    mock_pipeline = AsyncMock()
    mock_pipeline.run = AsyncMock(return_value=_CANNED_RRF_RESULTS)

    with patch("agxp.api.routes.query.PIPELINE", mock_pipeline), patch(
        "agxp.api.routes.query.fetch_experiences_by_ids",
        new=AsyncMock(return_value=_CANNED_EXPERIENCE_ROWS),
    ):
        client = TestClient(app)
        response = client.post(
            "/api/v1/query",
            json={"query": "lambda timeout"},
        )
    lines = _parse_ndjson(response.text)
    assert len(lines) >= 1
    assert lines[0].get("type") == "meta"


# ---------------------------------------------------------------------------
# 4. Last NDJSON line has type == "done"
# ---------------------------------------------------------------------------


def test_query_response_has_done_line():
    """The last parsed NDJSON line must have type == 'done'."""
    mock_pipeline = AsyncMock()
    mock_pipeline.run = AsyncMock(return_value=_CANNED_RRF_RESULTS)

    with patch("agxp.api.routes.query.PIPELINE", mock_pipeline), patch(
        "agxp.api.routes.query.fetch_experiences_by_ids",
        new=AsyncMock(return_value=_CANNED_EXPERIENCE_ROWS),
    ):
        client = TestClient(app)
        response = client.post(
            "/api/v1/query",
            json={"query": "lambda timeout"},
        )
    lines = _parse_ndjson(response.text)
    assert len(lines) >= 1
    assert lines[-1].get("type") == "done"


# ---------------------------------------------------------------------------
# 5. Empty query string returns 422
# ---------------------------------------------------------------------------


def test_query_endpoint_rejects_empty_query():
    """POST with query='' must return HTTP 422 (validation error)."""
    client = TestClient(app)
    response = client.post(
        "/api/v1/query",
        json={"query": ""},
    )
    assert response.status_code == 422


# ---------------------------------------------------------------------------
# 6. limit > 50 returns 422
# ---------------------------------------------------------------------------


def test_query_endpoint_rejects_limit_over_50():
    """POST with limit=51 must return HTTP 422 (validation error)."""
    client = TestClient(app)
    response = client.post(
        "/api/v1/query",
        json={"query": "lambda timeout", "limit": 51},
    )
    assert response.status_code == 422
