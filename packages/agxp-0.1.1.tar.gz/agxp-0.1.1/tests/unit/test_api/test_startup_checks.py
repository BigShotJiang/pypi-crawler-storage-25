"""
Unit tests for agxp/api/startup.py — startup validation checks.

All external dependencies (asyncpg, redis) are mocked.
No real database or Redis connection is required.
"""
import logging
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from agxp.api.startup import (
    check_database,
    check_env_vars,
    check_pgvector,
    check_redis,
)


# ── check_env_vars ──────────────────────────────────────────────────


class TestCheckEnvVars:
    def test_check_env_vars_passes_when_set(self):
        """DATABASE_URL present in environment -> no error raised."""
        with patch.dict(
            "os.environ",
            {"DATABASE_URL": "postgresql+asyncpg://u:p@host/db"},
        ):
            check_env_vars()  # should not raise

    def test_check_env_vars_raises_when_missing(self):
        """DATABASE_URL absent -> RuntimeError with descriptive message."""
        with patch.dict("os.environ", {}, clear=True):
            with pytest.raises(RuntimeError, match="DATABASE_URL"):
                check_env_vars()


# ── check_database ──────────────────────────────────────────────────


class TestCheckDatabase:
    @pytest.mark.asyncio
    async def test_check_database_passes_on_healthy_db(self):
        """Mock asyncpg.connect succeeds, SELECT 1 runs -> no error."""
        mock_conn = AsyncMock()
        mock_conn.execute = AsyncMock(return_value="SELECT 1")
        mock_conn.close = AsyncMock()

        with patch("agxp.api.startup.asyncpg.connect", return_value=mock_conn):
            await check_database("postgresql://u:p@host/db")

        mock_conn.execute.assert_awaited_once_with("SELECT 1")
        mock_conn.close.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_check_database_raises_on_connection_failure(self):
        """asyncpg.connect raises -> RuntimeError with descriptive message."""
        with patch(
            "agxp.api.startup.asyncpg.connect",
            side_effect=OSError("Connection refused"),
        ):
            with pytest.raises(RuntimeError, match="(?i)database|postgres"):
                await check_database("postgresql://u:p@host/db")


# ── check_pgvector ──────────────────────────────────────────────────


class TestCheckPgvector:
    @pytest.mark.asyncio
    async def test_check_pgvector_passes_when_extension_exists(self):
        """fetchval returns 'vector' -> no error raised."""
        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(return_value="vector")
        mock_conn.close = AsyncMock()

        with patch("agxp.api.startup.asyncpg.connect", return_value=mock_conn):
            await check_pgvector("postgresql://u:p@host/db")

        mock_conn.fetchval.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_check_pgvector_raises_when_missing(self):
        """fetchval returns None -> RuntimeError mentioning pgvector."""
        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(return_value=None)
        mock_conn.close = AsyncMock()

        with patch("agxp.api.startup.asyncpg.connect", return_value=mock_conn):
            with pytest.raises(RuntimeError, match="(?i)pgvector"):
                await check_pgvector("postgresql://u:p@host/db")


# ── check_redis ─────────────────────────────────────────────────────


class TestCheckRedis:
    @pytest.mark.asyncio
    async def test_check_redis_returns_true_when_available(self):
        """Redis ping succeeds -> returns True."""
        mock_client = AsyncMock()
        mock_client.ping = AsyncMock(return_value=True)
        mock_client.aclose = AsyncMock()

        with patch("agxp.api.startup.redis.asyncio.from_url", return_value=mock_client):
            result = await check_redis("redis://localhost:6379/0")

        assert result is True
        mock_client.ping.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_check_redis_returns_false_when_unavailable(self):
        """Redis connection fails -> returns False (non-fatal)."""
        with patch(
            "agxp.api.startup.redis.asyncio.from_url",
            side_effect=ConnectionError("Connection refused"),
        ):
            result = await check_redis("redis://localhost:6379/0")

        assert result is False

    @pytest.mark.asyncio
    async def test_check_redis_logs_warning_when_unavailable(self):
        """Redis connection fails -> warning is logged."""
        with patch(
            "agxp.api.startup.redis.asyncio.from_url",
            side_effect=ConnectionError("Connection refused"),
        ), patch("agxp.api.startup.logger") as mock_logger:
            await check_redis("redis://localhost:6379/0")

        mock_logger.warning.assert_called_once()
        call_args = mock_logger.warning.call_args
        assert "redis" in call_args[0][0].lower()
