"""
Tests that all core modules are importable without errors.
If any import fails, the scaffold is broken.
"""

import importlib

import pytest

MODULES = [
    "agxp",
    "agxp.cli",
    "agxp.services",
    "agxp.search",
    "agxp.search.backends",
    "agxp.cache",
    "agxp.db",
    "agxp.workers",
    "agxp.auth",
    "agxp.observability",
    "agxp.config",
    "agxp.search.backends.vector_backend",
    "agxp.search.backends.fts_backend",
    "agxp.search.backends.embedding_backend",
    "agxp.search.backends.pgvector_backend",
    "agxp.search.backends.bgem3_api_backend",
    "agxp.services.credit_writer",
    "agxp.services.quality_score_writer",
    "agxp.services.postgres_credit_writer",
    "agxp.services.inline_quality_writer",
    "agxp.config.backends",
    "agxp.search.reranker",
    "agxp.search.fake_reranker",
    "agxp.search.query_pipeline",
    "agxp.api.app",
    "agxp.auth.models",
    "agxp.auth.keys",
    "agxp.auth.dependency",
]


@pytest.mark.parametrize("module", MODULES)
def test_module_importable(module):
    mod = importlib.import_module(module)
    assert mod is not None


def test_config_backends_has_required_names():
    from agxp.config import backends

    assert hasattr(backends, "VECTOR_BACKEND")
    assert hasattr(backends, "FTS_BACKEND")
    assert hasattr(backends, "EMBED_BACKEND")
    assert hasattr(backends, "CREDIT_WRITER")
    assert hasattr(backends, "QUALITY_WRITER")
