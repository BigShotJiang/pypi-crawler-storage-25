"""
Tests that the project directory structure is correctly set up.
All tests here should pass immediately after scaffold is complete.
"""

from pathlib import Path

ROOT = Path(__file__).parent.parent.parent.parent  # agentxp/


def test_agxp_package_exists():
    assert (ROOT / "agxp" / "__init__.py").exists()


def test_agxp_subpackages_exist():
    subpackages = [
        "cli",
        "services",
        "search",
        "search/backends",
        "cache",
        "db",
        "workers",
        "auth",
        "observability",
        "config",
    ]
    for sub in subpackages:
        assert (ROOT / "agxp" / sub / "__init__.py").exists(), f"Missing agxp/{sub}/__init__.py"


def test_tests_structure_exists():
    subdirs = ["unit", "integration", "performance", "compatibility"]
    for sub in subdirs:
        assert (ROOT / "tests" / sub).is_dir(), f"Missing tests/{sub}/"


def test_pyproject_toml_exists():
    assert (ROOT / "pyproject.toml").exists()


def test_docker_compose_exists():
    assert (ROOT / "docker-compose.yml").exists()


def test_makefile_exists():
    assert (ROOT / "Makefile").exists()


def test_backend_abc_files_exist():
    backend_files = [
        "agxp/search/backends/vector_backend.py",
        "agxp/search/backends/fts_backend.py",
        "agxp/search/backends/embedding_backend.py",
        "agxp/services/credit_writer.py",
        "agxp/services/quality_score_writer.py",
        "agxp/config/backends.py",
    ]
    for f in backend_files:
        assert (ROOT / f).exists(), f"Missing {f}"


def test_default_backend_impl_files_exist():
    impl_files = [
        "agxp/search/backends/pgvector_backend.py",
        "agxp/search/backends/bgem3_api_backend.py",
        "agxp/services/postgres_credit_writer.py",
        "agxp/services/inline_quality_writer.py",
    ]
    for f in impl_files:
        assert (ROOT / f).exists(), f"Missing {f}"
