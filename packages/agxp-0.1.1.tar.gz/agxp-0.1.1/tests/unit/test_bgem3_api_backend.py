"""
Unit tests for BgeM3ApiBackend with mocked HTTP requests.
"""
import pytest
from unittest.mock import patch, AsyncMock
from agxp.search.backends.bgem3_api_backend import BgeM3ApiBackend

@pytest.fixture
def backend():
    return BgeM3ApiBackend()

def test_backend_properties(backend):
    """Test backend static properties are correct."""
    assert backend.dimensions == 1024
    assert backend.max_tokens == 8192

@pytest.mark.asyncio
async def test_embed_single_text(backend):
    """Test embedding a single text with mocked API response."""
    mock_response = {
        "data": [
            {"embedding": [0.1] * 1024}
        ]
    }

    with patch("httpx.AsyncClient.post") as mock_post:
        mock_resp = AsyncMock()
        # raise_for_status is a sync method in httpx
        mock_resp.raise_for_status = lambda: None
        mock_resp.json.return_value = mock_response
        mock_post.return_value = mock_resp

        result = await backend.embed(["test text"])

        assert len(result) == 1
        assert len(result[0]) == 1024
        assert result[0] == [0.1] * 1024

        # Verify API call parameters
        mock_post.assert_called_once()
        call_args = mock_post.call_args
        assert "https://example.com/v1/embeddings" in str(call_args[0][0])
        assert call_args[1]["json"]["model"] == "BAAI/bge-m3"
        assert call_args[1]["json"]["input"] == ["test text"]

@pytest.mark.asyncio
async def test_embed_batch(backend):
    """Test embedding multiple texts with batching."""
    mock_responses = [
        # First batch: 2 texts -> 2 embeddings
        {"data": [{"embedding": [0.0] * 1024}, {"embedding": [1.0] * 1024}]},
        # Second batch: 2 texts -> 2 embeddings
        {"data": [{"embedding": [1.0] * 1024}, {"embedding": [2.0] * 1024}]},
        # Third batch: 1 text -> 1 embedding
        {"data": [{"embedding": [2.0] * 1024}]}
    ]

    with patch("httpx.AsyncClient.post") as mock_post:
        # Configure mock to return different responses for each batch
        def create_mock_resp(index):
            mock_resp = AsyncMock()
            # raise_for_status is a sync method in httpx
            mock_resp.raise_for_status = lambda: None
            mock_resp.json.return_value = mock_responses[index]
            return mock_resp

        mock_post.side_effect = [
            create_mock_resp(0),
            create_mock_resp(1),
            create_mock_resp(2)
        ]

        texts = [f"text {i}" for i in range(5)]
        result = await backend.embed(texts, batch_size=2)

        assert len(result) == 5
        assert len(result[0]) == 1024
        assert result[0][0] == 0.0
        assert result[1][0] == 1.0
        assert result[2][0] == 1.0
        assert result[3][0] == 2.0
        assert result[4][0] == 2.0

        # Verify 3 API calls were made (5 texts / 2 per batch = 3 batches)
        assert mock_post.call_count == 3

@pytest.mark.asyncio
async def test_embed_with_api_key(backend, monkeypatch):
    """Test API key is correctly passed in headers when set."""
    monkeypatch.setenv("BGEM3_API_KEY", "test-secret-key")

    mock_response = {"data": [{"embedding": [0.1] * 1024}]}

    with patch("httpx.AsyncClient.post") as mock_post:
        mock_resp = AsyncMock()
        # raise_for_status is a sync method in httpx
        mock_resp.raise_for_status = lambda: None
        mock_resp.json.return_value = mock_response
        mock_post.return_value = mock_resp

        await backend.embed(["test text"])

        # Verify authorization header is present
        call_args = mock_post.call_args
        headers = call_args[1]["headers"]
        assert "Authorization" in headers
        assert headers["Authorization"] == "Bearer test-secret-key"

@pytest.mark.asyncio
async def test_embed_custom_api_url(backend, monkeypatch):
    """Test custom API URL from environment variable is used."""
    custom_url = "https://my-custom-embedding-api.com/embed"
    monkeypatch.setenv("BGEM3_API_URL", custom_url)

    mock_response = {"data": [{"embedding": [0.1] * 1024}]}

    with patch("httpx.AsyncClient.post") as mock_post:
        mock_resp = AsyncMock()
        # raise_for_status is a sync method in httpx
        mock_resp.raise_for_status = lambda: None
        mock_resp.json.return_value = mock_response
        mock_post.return_value = mock_resp

        await backend.embed(["test text"])

        # Verify custom API URL is used
        call_args = mock_post.call_args
        assert str(call_args[0][0]) == custom_url

@pytest.mark.asyncio
async def test_embed_api_error(backend):
    """Test API errors are properly propagated."""
    with patch("httpx.AsyncClient.post") as mock_post:
        mock_resp = AsyncMock()
        # raise_for_status is a sync method, make it throw an exception
        def raise_error():
            raise Exception("API request failed with status 500")
        mock_resp.raise_for_status = raise_error
        mock_post.return_value = mock_resp

        with pytest.raises(Exception, match="API request failed"):
            await backend.embed(["test text"])
