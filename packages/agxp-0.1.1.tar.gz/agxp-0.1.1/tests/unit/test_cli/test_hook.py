"""
Unit tests for agxp hook command.
Tests simulate stdin input and verify hook behavior.
"""
import json
import os
from io import StringIO
from unittest.mock import patch
from typer.testing import CliRunner
from agxp.cli.main import app

runner = CliRunner()

_TEST_TRANSCRIPT_PATH = "/tmp/test_session_12345.jsonl"
_TEST_STATE_DIR = "/tmp/agxp_test_hooks"

# ---------------------------------------------------------------------------
# Test hook command
# ---------------------------------------------------------------------------
def test_hook_invalid_json():
    """Test hook handles invalid JSON input gracefully."""
    # Simulate stdin with invalid JSON
    input_data = "not valid json\n"
    result = runner.invoke(
        app, ["hook", "--state-dir", _TEST_STATE_DIR],
        input=input_data
    )

    assert result.exit_code == 0
    # Should return empty JSON object
    assert result.stdout.strip() == "{}"

def test_hook_non_bash_tool():
    """Test hook ignores events from tools other than Bash."""
    payload = {
        "hook_event_name": "PostToolUse",
        "tool_name": "Write",  # Not Bash
        "transcript_path": _TEST_TRANSCRIPT_PATH,
        "tool_response": {"success": True}
    }
    input_data = json.dumps(payload) + "\n"

    result = runner.invoke(
        app, ["hook", "--state-dir", _TEST_STATE_DIR],
        input=input_data
    )

    assert result.exit_code == 0
    assert result.stdout.strip() == "{}"

def test_hook_post_tool_use_success(tmp_path):
    """Test PostToolUse success event resets error state."""
    state_dir = tmp_path / "agxp_hooks"
    state_dir.mkdir(parents=True, exist_ok=True)

    # Create existing state file with error count
    session_id = "test_session_12345"
    state_file = state_dir / f"{session_id}.json"
    existing_state = {"count": 2, "fingerprint": "RuntimeError@test.py:main"}
    state_file.write_text(json.dumps(existing_state))

    payload = {
        "hook_event_name": "PostToolUse",
        "tool_name": "Bash",
        "transcript_path": f"/tmp/{session_id}.jsonl",
        "tool_response": {"success": True}
    }
    input_data = json.dumps(payload) + "\n"

    result = runner.invoke(
        app, ["hook", "--state-dir", str(state_dir)],
        input=input_data
    )

    assert result.exit_code == 0
    assert result.stdout.strip() == "{}"

    # Verify state was reset
    updated_state = json.loads(state_file.read_text())
    assert updated_state["count"] == 0
    assert updated_state["fingerprint"] == ""

def test_hook_post_tool_use_failure_first_time(tmp_path):
    """Test first PostToolUseFailure event increments count, no trigger."""
    state_dir = tmp_path / "agxp_hooks"

    payload = {
        "hook_event_name": "PostToolUseFailure",
        "tool_name": "Bash",
        "transcript_path": _TEST_TRANSCRIPT_PATH,
        "error": "RuntimeError: something went wrong\nFile \"test.py\", line 10, in main"
    }
    input_data = json.dumps(payload) + "\n"

    result = runner.invoke(
        app, ["hook", "--state-dir", str(state_dir)],
        input=input_data
    )

    assert result.exit_code == 0
    assert result.stdout.strip() == "{}"

    # Verify state was created
    session_id = "test_session_12345"
    state_file = state_dir / f"{session_id}.json"
    state = json.loads(state_file.read_text())
    assert state["count"] == 1
    assert state["fingerprint"] == "RuntimeError@test.py:main"

def test_hook_post_tool_use_failure_second_time(tmp_path):
    """Test second identical PostToolUseFailure event triggers AGXP suggestion."""
    state_dir = tmp_path / "agxp_hooks"
    state_dir.mkdir(parents=True, exist_ok=True)

    # Create existing state with count = 1
    session_id = "test_session_12345"
    state_file = state_dir / f"{session_id}.json"
    existing_state = {"count": 1, "fingerprint": "RuntimeError@test.py:main"}
    state_file.write_text(json.dumps(existing_state))

    payload = {
        "hook_event_name": "PostToolUseFailure",
        "tool_name": "Bash",
        "transcript_path": f"/tmp/{session_id}.jsonl",
        "error": "RuntimeError: something went wrong again\nFile \"test.py\", line 10, in main"
    }
    input_data = json.dumps(payload) + "\n"

    result = runner.invoke(
        app, ["hook", "--state-dir", str(state_dir)],
        input=input_data
    )

    assert result.exit_code == 0
    output = json.loads(result.stdout.strip())
    assert "hookSpecificOutput" in output
    assert "Should Call AGXP MCP Tool" in output["hookSpecificOutput"]["additionalContext"]

    # Verify count was reset
    updated_state = json.loads(state_file.read_text())
    assert updated_state["count"] == 0

def test_hook_post_tool_use_failure_different_error(tmp_path):
    """Test different error resets count and fingerprint."""
    state_dir = tmp_path / "agxp_hooks"
    state_dir.mkdir(parents=True, exist_ok=True)

    # Create existing state with count = 1 for RuntimeError
    session_id = "test_session_12345"
    state_file = state_dir / f"{session_id}.json"
    existing_state = {"count": 1, "fingerprint": "RuntimeError@test.py:main"}
    state_file.write_text(json.dumps(existing_state))

    # Send different error (ValueError)
    payload = {
        "hook_event_name": "PostToolUseFailure",
        "tool_name": "Bash",
        "transcript_path": f"/tmp/{session_id}.jsonl",
        "error": "ValueError: invalid input\nFile \"test.py\", line 20, in process_input"
    }
    input_data = json.dumps(payload) + "\n"

    result = runner.invoke(
        app, ["hook", "--state-dir", str(state_dir)],
        input=input_data
    )

    assert result.exit_code == 0
    assert result.stdout.strip() == "{}"

    # Verify state was updated with new fingerprint and count = 1
    updated_state = json.loads(state_file.read_text())
    assert updated_state["count"] == 1
    assert updated_state["fingerprint"] == "ValueError@test.py:process_input"

def test_hook_unknown_event(tmp_path):
    """Test unknown hook events are ignored gracefully."""
    state_dir = tmp_path / "agxp_hooks"
    payload = {
        "hook_event_name": "UnknownEvent",
        "tool_name": "Bash",
        "transcript_path": _TEST_TRANSCRIPT_PATH
    }
    input_data = json.dumps(payload) + "\n"

    result = runner.invoke(
        app, ["hook", "--state-dir", str(state_dir)],
        input=input_data
    )

    assert result.exit_code == 0
    assert result.stdout.strip() == "{}"

def test_get_error_fingerprint():
    """Test error fingerprint generation function."""
    from agxp.cli.commands.hook_cmd import get_error_fingerprint

    # Test standard Python error
    stderr = """Traceback (most recent call last):
  File "test.py", line 10, in main
    raise RuntimeError("something went wrong")
RuntimeError: something went wrong
"""
    assert get_error_fingerprint(stderr) == "RuntimeError@test.py:main"

    # Test error with no traceback
    stderr = "RecursionError: maximum recursion depth exceeded"
    assert get_error_fingerprint(stderr) == "RecursionError"

    # Test error with multiple trace levels
    stderr = """Traceback (most recent call last):
  File "main.py", line 5, in <module>
    test()
  File "utils.py", line 20, in test
    raise ValueError("invalid input")
ValueError: invalid input
"""
    assert get_error_fingerprint(stderr) == "ValueError@utils.py:test"
