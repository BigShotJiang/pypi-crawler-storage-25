"""
Unit tests for CLI commands (pure remote API mode).
All commands call remote API, no local database.
Tests use Typer's CliRunner and mock API responses.
"""
import json
import os
from unittest.mock import patch, MagicMock
from typer.testing import CliRunner
from agxp.cli.main import app

runner = CliRunner()

# ---------------------------------------------------------------------------
# Shared test data
# ---------------------------------------------------------------------------
_REQUIRED_CONTRIBUTE_ARGS = [
    "--situation", "The agent hit an asyncio deadlock when using nested event loops.",
    "--solution", "Replaced asyncio.run() with await in the existing event loop.",
    "--outcome-type", "solved",
    "--lessons", "Never call asyncio.run() from within a running event loop.",
    "--domain", "coding",
    "--task-type", "debugging",
]

_TEST_ANONYMOUS_TOKEN = "test_anon_token_12345"
_TEST_API_RESPONSE = {"experience_id": "test-uuid-123", "status": "success"}
_TEST_SEARCH_RESULTS = [
    {
        "experience_id": "exp-1",
        "situation": "Test situation 1",
        "solution": "Test solution 1",
        "outcome_type": "solved",
        "lessons": "Test lesson 1",
        "domain": "coding",
        "task_type": "debugging",
        "quality_score": 0.85
    },
    {
        "experience_id": "exp-2",
        "situation": "Test situation 2",
        "solution": "Test solution 2",
        "outcome_type": "workaround",
        "lessons": "Test lesson 2",
        "domain": "coding",
        "task_type": "debugging",
        "quality_score": 0.7
    }
]

# ---------------------------------------------------------------------------
# Shared mocks
# ---------------------------------------------------------------------------
def mock_api_post_success(url, *args, **kwargs):
    """Mock successful API POST response."""
    mock_resp = MagicMock()
    mock_resp.status = 200
    mock_resp.read.return_value = json.dumps(_TEST_API_RESPONSE).encode()
    mock_resp.__enter__ = lambda self: self
    mock_resp.__exit__ = lambda *args: None
    return mock_resp

def mock_api_post_error(url, *args, **kwargs):
    """Mock API error response."""
    from urllib.error import HTTPError
    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps({"message": "Invalid parameter"}).encode()
    raise HTTPError(url, 400, "Bad Request", {}, mock_resp)

def mock_search_api_response(url, *args, **kwargs):
    """Mock search API response with NDJSON format."""
    mock_resp = MagicMock()
    mock_resp.status = 200
    # NDJSON format: one result per line
    ndjson = "\n".join([
        json.dumps({"type": "result", "experience": res})
        for res in _TEST_SEARCH_RESULTS
    ])
    mock_resp.read.return_value = ndjson.encode()
    mock_resp.__enter__ = lambda self: self
    mock_resp.__exit__ = lambda *args: None
    return mock_resp

def mock_anonymous_auth_response(url, *args, **kwargs):
    """Mock anonymous auth API response."""
    mock_resp = MagicMock()
    mock_resp.status = 200
    mock_resp.read.return_value = json.dumps({"token": _TEST_ANONYMOUS_TOKEN}).encode()
    mock_resp.__enter__ = lambda self: self
    mock_resp.__exit__ = lambda *args: None
    return mock_resp

def mock_get_or_create_token(tmp_path):
    """Mock _get_or_create_token function to return test token and write to config."""
    config_dir = os.path.join(tmp_path, ".agxp")
    os.makedirs(config_dir, exist_ok=True)
    config_path = os.path.join(config_dir, "config.json")
    with open(config_path, "w") as f:
        json.dump({"anonymous_token": _TEST_ANONYMOUS_TOKEN}, f)
    return _TEST_ANONYMOUS_TOKEN

# ===========================================================================
# agxp init (command removed, no tests)
# ===========================================================================

# ===========================================================================
# agxp contribute
# ===========================================================================
class TestContribute:
    """Tests for `agxp contribute` command."""

    @patch("agxp.cli.commands.contribute.urllib.request.urlopen", side_effect=mock_api_post_success)
    @patch("agxp.cli.commands.contribute._get_or_create_token", return_value=_TEST_ANONYMOUS_TOKEN)
    def test_contribute_json_output_default(self, mock_token, mock_urlopen, tmp_path):
        """Contribute command should output JSON by default."""
        result = runner.invoke(app, ["contribute"] + _REQUIRED_CONTRIBUTE_ARGS + ["--data-dir", str(tmp_path)])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["experience_id"] == _TEST_API_RESPONSE["experience_id"]
        assert output["status"] == _TEST_API_RESPONSE["status"]

    @patch("agxp.cli.commands.contribute.urllib.request.urlopen", side_effect=mock_api_post_success)
    @patch("agxp.cli.commands.contribute._get_or_create_token", return_value=_TEST_ANONYMOUS_TOKEN)
    def test_contribute_human_readable_output(self, mock_token, mock_urlopen, tmp_path):
        """Contribute with --no-json should output human readable text."""
        result = runner.invoke(app, ["contribute"] + _REQUIRED_CONTRIBUTE_ARGS + ["--data-dir", str(tmp_path), "--no-json"])
        assert result.exit_code == 0
        assert "Success" in result.output
        assert "experience id" in result.output.lower()
        assert _TEST_API_RESPONSE["experience_id"] in result.output

    @patch("agxp.cli.commands.contribute.urllib.request.urlopen", side_effect=mock_api_post_error)
    @patch("agxp.cli.commands.contribute._get_or_create_token", return_value=_TEST_ANONYMOUS_TOKEN)
    def test_contribute_api_error_json_output(self, mock_token, mock_urlopen, tmp_path):
        """API errors should output JSON error by default."""
        result = runner.invoke(app, ["contribute"] + _REQUIRED_CONTRIBUTE_ARGS + ["--data-dir", str(tmp_path)])
        assert result.exit_code == 1
        output = json.loads(result.output)
        assert "error" in output
        assert "Invalid parameter" in output["error"]

    def test_contribute_missing_required_args(self, tmp_path):
        """Missing required arguments should show error."""
        result = runner.invoke(app, ["contribute", "--situation", "test", "--data-dir", str(tmp_path)])
        assert result.exit_code != 0
        assert "Missing option" in result.output

    def test_contribute_invalid_outcome_type(self, tmp_path):
        """Invalid outcome type should show error."""
        invalid_args = [a for a in _REQUIRED_CONTRIBUTE_ARGS]
        invalid_args[invalid_args.index("solved")] = "invalid_type"
        result = runner.invoke(app, ["contribute"] + invalid_args + ["--data-dir", str(tmp_path)])
        assert result.exit_code != 0
        assert "invalid outcome_type" in result.output.lower()

# ===========================================================================
# agxp query
# ===========================================================================
class TestQuery:
    """Tests for `agxp query` command."""

    @patch("agxp.cli.commands.query.urllib.request.urlopen", side_effect=mock_search_api_response)
    @patch("agxp.cli.commands.query._get_or_create_token", return_value=_TEST_ANONYMOUS_TOKEN)
    def test_query_default_ndjson_output(self, mock_token, mock_urlopen, tmp_path):
        """Query should output NDJSON by default (one result per line)."""
        result = runner.invoke(app, ["query", "test query", "--data-dir", str(tmp_path)])
        assert result.exit_code == 0
        lines = [line.strip() for line in result.output.split("\n") if line.strip()]
        assert len(lines) == 2
        res1 = json.loads(lines[0])
        res2 = json.loads(lines[1])
        assert res1["experience_id"] == "exp-1"
        assert res2["experience_id"] == "exp-2"

    @patch("agxp.cli.commands.query.urllib.request.urlopen", side_effect=mock_search_api_response)
    @patch("agxp.cli.commands.query._get_or_create_token", return_value=_TEST_ANONYMOUS_TOKEN)
    def test_query_json_array_output(self, mock_token, mock_urlopen, tmp_path):
        """Query with --json should output JSON array of results."""
        result = runner.invoke(app, ["query", "test query", "--json", "--data-dir", str(tmp_path)])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert isinstance(output, list)
        assert len(output) == 2
        assert output[0]["experience_id"] == "exp-1"

    @patch("agxp.cli.commands.query.urllib.request.urlopen", side_effect=mock_api_post_error)
    @patch("agxp.cli.commands.query._get_or_create_token", return_value=_TEST_ANONYMOUS_TOKEN)
    def test_query_api_error(self, mock_token, mock_urlopen, tmp_path):
        """API errors should return appropriate error."""
        result = runner.invoke(app, ["query", "test query", "--data-dir", str(tmp_path)])
        assert result.exit_code == 1
        assert "Error searching experiences" in result.output

# ===========================================================================
# agxp feedback
# ===========================================================================
class TestFeedback:
    """Tests for `agxp feedback` command."""

    @patch("agxp.cli.commands.feedback_cmd.urllib.request.urlopen", side_effect=mock_api_post_success)
    @patch("agxp.cli.commands.feedback_cmd._get_or_create_token", return_value=_TEST_ANONYMOUS_TOKEN)
    def test_feedback_success(self, mock_token, mock_urlopen, tmp_path):
        """Feedback command should work with --useful flag."""
        result = runner.invoke(app, ["feedback", "--experience-id", "test-exp-id", "--useful", "--data-dir", str(tmp_path)])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["status"] == "success"

    @patch("agxp.cli.commands.feedback_cmd.urllib.request.urlopen", side_effect=mock_api_post_success)
    @patch("agxp.cli.commands.feedback_cmd._get_or_create_token", return_value=_TEST_ANONYMOUS_TOKEN)
    def test_feedback_not_useful(self, mock_token, mock_urlopen, tmp_path):
        """Feedback should work with --not-useful flag."""
        result = runner.invoke(app, ["feedback", "--experience-id", "test-exp-id", "--not-useful", "--data-dir", str(tmp_path)])
        assert result.exit_code == 0
        output = json.loads(result.output)
        assert output["status"] == "success"

    def test_feedback_missing_flag(self, tmp_path):
        """Missing --useful/--not-useful should show error."""
        result = runner.invoke(app, ["feedback", "--experience-id", "test-exp-id", "--data-dir", str(tmp_path)])
        assert result.exit_code != 0
        assert "specify --useful or --not-useful" in result.output.lower()

# ===========================================================================
# agxp login
# ===========================================================================
class TestLogin:
    """Tests for `agxp login` command."""
    # Login command requires interaction with browser and local server, tested in integration tests
    pass
