"""
Unit tests for agxp login command.
Tests focus on unit testing individual functions rather than full server flow,
since socket server functionality is part of Python standard library.
"""
import json
import os
from unittest.mock import patch, MagicMock
from typer.testing import CliRunner
from agxp.cli.main import app

runner = CliRunner()

_TEST_TOKEN = "gho_github_oauth_token_123456789"

# ---------------------------------------------------------------------------
# Test internal helper functions
# ---------------------------------------------------------------------------
def test_get_config_path_default():
    """Test _get_config_path returns correct default path."""
    from agxp.cli.commands.login import _get_config_path, _DEFAULT_DATA_DIR
    default_path = _get_config_path(_DEFAULT_DATA_DIR)
    assert default_path == os.path.join(os.path.expanduser("~"), ".agxp", "config.json")

def test_get_config_path_custom():
    """Test _get_config_path returns correct custom path."""
    from agxp.cli.commands.login import _get_config_path
    custom_dir = "/tmp/test_agxp"
    path = _get_config_path(custom_dir)
    assert path == os.path.join(custom_dir, "config.json")

def test_read_write_config(tmp_path):
    """Test _read_config and _write_config functions work correctly."""
    from agxp.cli.commands.login import _read_config, _write_config

    test_config = {"api_token": _TEST_TOKEN, "other_key": "value"}

    # Write config
    _write_config(test_config, str(tmp_path))

    # Read back and verify
    read_config = _read_config(str(tmp_path))
    assert read_config == test_config

def test_read_config_nonexistent():
    """Test _read_config returns empty dict when config file doesn't exist."""
    from agxp.cli.commands.login import _read_config
    config = _read_config("/tmp/nonexistent_agxp_dir")
    assert config == {}

def test_find_available_port():
    """Test find_available_port returns a valid port number."""
    from agxp.cli.commands.login import find_available_port
    port = find_available_port()
    assert isinstance(port, int)
    assert 1024 <= port <= 65535

# ---------------------------------------------------------------------------
# Test command error cases (these don't require server)
# ---------------------------------------------------------------------------
def test_login_no_available_port(tmp_path):
    """Test login when no available port can be found."""
    with runner.isolated_filesystem(temp_dir=tmp_path) as fs:
        with patch("agxp.cli.commands.login.find_available_port", side_effect=RuntimeError("Could not find available port")):
            result = runner.invoke(
                app, ["login", "--data-dir", os.path.join(fs, ".agxp")],
                catch_exceptions=False
            )

            assert result.exit_code == 1
            # Errors are printed to stderr
            assert "❌ Could not find available port" in result.stderr

def test_auth_url_generation():
    """Test authentication URL is generated correctly."""
    from agxp.cli.commands.login import login
    from unittest.mock import patch

    with patch("agxp.cli.commands.login.find_available_port", return_value=8888):
        # We only need to test the URL generation part, not run the whole command
        server_url = "https://custom.agxp.com"
        expected_url = f"{server_url.rstrip('/')}/api/v1/auth/github?redirect_uri=http://localhost:8888/callback"

        # We can directly verify the URL construction logic
        from agxp.cli.commands.login import find_available_port
        port = find_available_port()
        callback_url = f"http://localhost:{port}/callback"
        auth_url = f"{server_url.rstrip('/')}/api/v1/auth/github?redirect_uri={callback_url}"

        assert auth_url == expected_url

# ---------------------------------------------------------------------------
# Test error fingerprint helper (imported from hook)
# ---------------------------------------------------------------------------
def test_get_error_fingerprint():
    """Test error fingerprint generation function works correctly."""
    from agxp.cli.commands.hook_cmd import get_error_fingerprint

    # Test standard Python error
    stderr = """Traceback (most recent call last):
  File "test.py", line 10, in main
    raise RuntimeError("something went wrong")
RuntimeError: something went wrong
"""
    assert get_error_fingerprint(stderr) == "RuntimeError@test.py:main"

    # Test error with no traceback
    stderr = "RecursionError: maximum recursion depth exceeded"
    assert get_error_fingerprint(stderr) == "RecursionError"

    # Test error with multiple trace levels
    stderr = """Traceback (most recent call last):
  File "main.py", line 5, in <module>
    test()
  File "utils.py", line 20, in test
    raise ValueError("invalid input")
ValueError: invalid input
"""
    assert get_error_fingerprint(stderr) == "ValueError@utils.py:test"
