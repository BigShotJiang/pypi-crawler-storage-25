"""
Static validation tests for scripts/dev.sh.

Verifies the dev startup script exists, is executable,
and contains all expected operational steps.
"""
from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[3]
DEV_SCRIPT = PROJECT_ROOT / "scripts" / "dev.sh"


@pytest.fixture()
def script_text() -> str:
    return DEV_SCRIPT.read_text()


class TestDevScriptExists:
    def test_dev_script_exists(self) -> None:
        assert DEV_SCRIPT.is_file(), f"scripts/dev.sh not found at {DEV_SCRIPT}"

    def test_dev_script_is_executable(self) -> None:
        mode = DEV_SCRIPT.stat().st_mode
        assert mode & stat.S_IXUSR, (
            "scripts/dev.sh must be executable (chmod +x)"
        )


class TestDevScriptContent:
    def test_dev_script_has_shebang(self, script_text: str) -> None:
        first_line = script_text.splitlines()[0]
        assert first_line.startswith("#!/"), (
            f"First line must be a shebang, got: {first_line!r}"
        )

    def test_dev_script_loads_dotenv(self, script_text: str) -> None:
        has_source = ". .env" in script_text or "source .env" in script_text
        has_dotenv_flag = "--dotenv" in script_text
        assert has_source or has_dotenv_flag, (
            "scripts/dev.sh must load .env (via '. .env', 'source .env', or '--dotenv')"
        )

    def test_dev_script_checks_postgres(self, script_text: str) -> None:
        assert "pg_isready" in script_text or "psql" in script_text, (
            "scripts/dev.sh must check PostgreSQL connectivity "
            "(expected 'pg_isready' or 'psql')"
        )

    def test_dev_script_checks_redis(self, script_text: str) -> None:
        assert "redis-cli" in script_text or "redis" in script_text.lower(), (
            "scripts/dev.sh must check Redis connectivity "
            "(expected 'redis-cli' or redis check)"
        )

    def test_dev_script_runs_migration(self, script_text: str) -> None:
        assert "alembic upgrade" in script_text, (
            "scripts/dev.sh must run 'alembic upgrade' for migrations"
        )

    def test_dev_script_starts_celery(self, script_text: str) -> None:
        assert "celery" in script_text.lower(), (
            "scripts/dev.sh must start a Celery worker"
        )

    def test_dev_script_starts_uvicorn(self, script_text: str) -> None:
        assert "uvicorn" in script_text, (
            "scripts/dev.sh must start uvicorn"
        )

    def test_dev_script_supports_check_only(self, script_text: str) -> None:
        assert "--check-only" in script_text, (
            "scripts/dev.sh must support --check-only flag"
        )
