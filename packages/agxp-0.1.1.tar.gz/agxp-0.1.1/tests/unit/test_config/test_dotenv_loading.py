"""
Tests for .env auto-loading in the FastAPI app lifespan.

Verifies that:
- When dotenv is available and .env exists, load_dotenv is called
- When dotenv is not installed, the lifespan still works without crashing
"""
from __future__ import annotations

import importlib
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


class TestLifespanLoadsDotenv:
    """Test that lifespan calls load_dotenv when available."""

    @pytest.mark.asyncio
    async def test_lifespan_loads_dotenv_when_file_exists(
        self, tmp_path, monkeypatch,
    ) -> None:
        """Create a temp .env, mock dotenv.load_dotenv, verify it's called."""
        # Create a fake .env file
        env_file = tmp_path / ".env"
        env_file.write_text("DATABASE_URL=postgresql+asyncpg://x:x@localhost/x\n")

        # Mock dotenv module
        mock_load = MagicMock()
        fake_dotenv = MagicMock()
        fake_dotenv.load_dotenv = mock_load

        # Set required env vars so startup checks don't fail
        monkeypatch.setenv("DATABASE_URL", "postgresql+asyncpg://x:x@localhost/x")
        monkeypatch.setenv("REDIS_URL", "redis://localhost:6379/0")

        # Patch dotenv into sys.modules and reimport app
        with patch.dict(sys.modules, {"dotenv": fake_dotenv}):
            # Patch startup checks to be no-ops
            with (
                patch("agxp.api.startup.check_env_vars"),
                patch("agxp.api.startup.check_database", new_callable=AsyncMock),
                patch("agxp.api.startup.check_pgvector", new_callable=AsyncMock),
                patch("agxp.api.startup.check_redis", new_callable=AsyncMock, return_value=True),
                patch("agxp.db.pool.get_pool", new_callable=AsyncMock),
                patch("agxp.db.pool.close_pool", new_callable=AsyncMock),
            ):
                # Force reimport to pick up patched dotenv
                if "agxp.api.app" in sys.modules:
                    importlib.reload(sys.modules["agxp.api.app"])
                    from agxp.api.app import lifespan
                else:
                    from agxp.api.app import lifespan

                fake_app = MagicMock()
                async with lifespan(fake_app):
                    pass

                # After the lifespan runs, load_dotenv should have been called
                # (only if the implementation loads dotenv in lifespan)
                # This test validates the contract: if dotenv is available, use it
                mock_load.assert_called()

    @pytest.mark.asyncio
    async def test_lifespan_works_without_dotenv_installed(
        self, monkeypatch,
    ) -> None:
        """When python-dotenv is not importable, lifespan must not crash."""
        monkeypatch.setenv("DATABASE_URL", "postgresql+asyncpg://x:x@localhost/x")
        monkeypatch.setenv("REDIS_URL", "redis://localhost:6379/0")

        # Verify the try/except ImportError pattern in app.py source code
        # This is a static check that the dotenv import is guarded
        from agxp.api import app as app_module
        import inspect
        source = inspect.getsource(app_module.lifespan)
        assert "ImportError" in source, (
            "lifespan must handle ImportError for dotenv gracefully"
        )
        assert "from dotenv" in source or "import dotenv" in source, (
            "lifespan must attempt to import dotenv"
        )
