"""
Static validation tests for .env.example file.

Ensures .env.example documents all required environment variables
with valid default values and no real secrets.
"""
from __future__ import annotations

from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[3]
ENV_EXAMPLE = PROJECT_ROOT / ".env.example"


@pytest.fixture()
def env_lines() -> list[str]:
    """Read .env.example lines, skipping blanks and comments."""
    text = ENV_EXAMPLE.read_text()
    return [
        line.strip()
        for line in text.splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]


@pytest.fixture()
def env_dict(env_lines: list[str]) -> dict[str, str]:
    """Parse .env.example into key=value dict."""
    result: dict[str, str] = {}
    for line in env_lines:
        if "=" in line:
            key, _, value = line.partition("=")
            result[key.strip()] = value.strip()
    return result


class TestEnvExampleExists:
    def test_env_example_exists(self) -> None:
        assert ENV_EXAMPLE.is_file(), f".env.example not found at {ENV_EXAMPLE}"


class TestEnvExampleContents:
    def test_env_example_contains_database_url(
        self, env_dict: dict[str, str]
    ) -> None:
        assert "DATABASE_URL" in env_dict, (
            ".env.example must contain DATABASE_URL"
        )

    def test_env_example_contains_redis_url(
        self, env_dict: dict[str, str]
    ) -> None:
        assert "REDIS_URL" in env_dict, (
            ".env.example must contain REDIS_URL"
        )

    def test_env_example_database_url_format(
        self, env_dict: dict[str, str]
    ) -> None:
        db_url = env_dict.get("DATABASE_URL", "")
        assert db_url.startswith("postgresql"), (
            f"DATABASE_URL must start with 'postgresql', got: {db_url!r}"
        )

    def test_env_example_redis_url_format(
        self, env_dict: dict[str, str]
    ) -> None:
        redis_url = env_dict.get("REDIS_URL", "")
        assert redis_url.startswith("redis://"), (
            f"REDIS_URL must start with 'redis://', got: {redis_url!r}"
        )

    def test_env_example_no_real_secrets(self) -> None:
        """Ensure .env.example contains only example/default values, not real secrets."""
        text = ENV_EXAMPLE.read_text().lower()
        forbidden = [
            "password123",
            "mysecret",
            "s3cr3t",
            "changeme",
            "hunter2",
            "sk-",      # API key prefix
            "ghp_",     # GitHub personal access token prefix
        ]
        for secret in forbidden:
            assert secret not in text, (
                f".env.example appears to contain a real secret: {secret!r}"
            )
