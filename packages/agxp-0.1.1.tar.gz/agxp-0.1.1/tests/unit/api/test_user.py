"""Test user info API endpoint."""
from fastapi.testclient import TestClient
from unittest.mock import patch, AsyncMock
import pytest
from agxp.api.app import app
from agxp.auth.models import AuthIdentity
from agxp.auth.dependency import require_auth

client = TestClient(app)

@pytest.mark.asyncio
async def test_user_me_anonymous():
    """Test /api/v1/user/me returns correct info for anonymous user."""
    # Override auth dependency
    def mock_require_auth():
        return AuthIdentity(
            user_id=None,
            anon_session_id="test-anon-id-123",
            is_anonymous=True
        )

    app.dependency_overrides[require_auth] = mock_require_auth

    try:
        # Mock database responses
        mock_pool = AsyncMock()
        mock_pool.fetchrow.return_value = {"credit_balance": 17}
        mock_pool.fetchval.side_effect = [3]  # today search count (3)

        with patch("agxp.api.routes.user.get_pool", return_value=mock_pool):
            response = client.get("/api/v1/user/me")
            assert response.status_code == 200
            data = response.json()
            assert data["user_type"] == "anonymous"
            assert data["credit_balance"] == 17
            assert data["experience_count"] == 0
            assert data["search_count_today"] == 3
            assert data["max_search_per_day"] == 50
            assert "server_version" in data
    finally:
        # Clear override
        app.dependency_overrides.clear()

@pytest.mark.asyncio
async def test_user_me_logged_in():
    """Test /api/v1/user/me returns correct info for logged in user."""
    # Override auth dependency
    def mock_require_auth():
        return AuthIdentity(
            user_id="test-user-id-123",
            anon_session_id=None,
            is_anonymous=False
        )

    app.dependency_overrides[require_auth] = mock_require_auth

    try:
        # Mock database responses
        mock_pool = AsyncMock()
        mock_pool.fetchrow.return_value = {"balance": 120}
        mock_pool.fetchval.side_effect = [5, 12]  # 5 contributed experiences, 12 searches today

        with patch("agxp.api.routes.user.get_pool", return_value=mock_pool):
            response = client.get("/api/v1/user/me")
            assert response.status_code == 200
            data = response.json()
            assert data["user_type"] == "logged_in"
            assert data["credit_balance"] == 120
            assert data["experience_count"] == 5
            assert data["search_count_today"] == 12
            assert data["max_search_per_day"] == 50
    finally:
        # Clear override
        app.dependency_overrides.clear()

@pytest.mark.asyncio
async def test_user_me_no_data():
    """Test /api/v1/user/me returns default values when no data exists."""
    # Override auth dependency
    def mock_require_auth():
        return AuthIdentity(
            user_id="test-user-id-123",
            anon_session_id=None,
            is_anonymous=False
        )

    app.dependency_overrides[require_auth] = mock_require_auth

    try:
        # Mock database responses returning None
        mock_pool = AsyncMock()
        mock_pool.fetchrow.return_value = None
        mock_pool.fetchval.return_value = None

        with patch("agxp.api.routes.user.get_pool", return_value=mock_pool):
            response = client.get("/api/v1/user/me")
            assert response.status_code == 200
            data = response.json()
            assert data["credit_balance"] == 0
            assert data["experience_count"] == 0
            assert data["search_count_today"] == 0
    finally:
        # Clear override
        app.dependency_overrides.clear()
