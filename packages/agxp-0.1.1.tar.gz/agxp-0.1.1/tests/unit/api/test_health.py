"""Test health check API endpoint."""
from fastapi.testclient import TestClient
from agxp.api.app import app

client = TestClient(app)

def test_health_endpoint():
    """Test /health endpoint returns ok status."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert "version" in data
    assert "features" in data
    assert isinstance(data["features"], list)
