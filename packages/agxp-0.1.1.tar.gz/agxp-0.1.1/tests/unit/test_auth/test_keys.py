"""
Unit tests for agxp.auth.keys — token generation, parsing, hashing.

All tests are pure (no I/O, no DB). Bcrypt round-trip tests are included
but kept to a minimum since bcrypt is intentionally slow.
"""
import uuid

import pytest

from agxp.auth.keys import (
    generate_anon_key,
    generate_api_key,
    hash_secret,
    parse_api_token,
    verify_secret,
)


# ---------------------------------------------------------------------------
# Token generation format
# ---------------------------------------------------------------------------


def test_generate_api_key_format():
    """Registered key starts with 'agxp_' and has correct total length."""
    key_id = str(uuid.uuid4())
    token, secret_hex = generate_api_key(key_id)
    assert token.startswith("agxp_")
    assert not token.startswith("agxp_anon_")
    # agxp_ (5) + 32 hex uuid + _ (1) + 32 hex secret = 70
    assert len(token) == 70
    assert len(secret_hex) == 32


def test_generate_anon_key_format():
    """Anonymous key starts with 'agxp_anon_' and has correct total length."""
    session_id = str(uuid.uuid4())
    token, secret_hex = generate_anon_key(session_id)
    assert token.startswith("agxp_anon_")
    # agxp_anon_ (10) + 32 hex uuid + _ (1) + 32 hex secret = 75
    assert len(token) == 75
    assert len(secret_hex) == 32


# ---------------------------------------------------------------------------
# Token parsing — valid tokens
# ---------------------------------------------------------------------------


def test_parse_valid_api_token():
    """Parsing a valid registered token returns correct ParsedToken."""
    key_id = str(uuid.uuid4())
    token, secret_hex = generate_api_key(key_id)
    parsed = parse_api_token(token)
    assert parsed is not None
    assert parsed.key_id == key_id
    assert parsed.secret_hex == secret_hex
    assert parsed.is_anonymous is False


def test_parse_valid_anon_token():
    """Parsing a valid anonymous token returns correct ParsedToken."""
    session_id = str(uuid.uuid4())
    token, secret_hex = generate_anon_key(session_id)
    parsed = parse_api_token(token)
    assert parsed is not None
    assert parsed.key_id == session_id
    assert parsed.secret_hex == secret_hex
    assert parsed.is_anonymous is True


# ---------------------------------------------------------------------------
# Token parsing — invalid tokens
# ---------------------------------------------------------------------------


def test_parse_invalid_prefix_returns_none():
    """A token with an unknown prefix returns None."""
    assert parse_api_token("sk-abcdef1234567890abcdef1234567890_abcdef1234567890abcdef1234567890") is None


def test_parse_truncated_token_returns_none():
    """A token that is too short returns None."""
    assert parse_api_token("agxp_abc123") is None


def test_parse_empty_string_returns_none():
    """An empty string returns None."""
    assert parse_api_token("") is None


def test_parse_non_hex_chars_returns_none():
    """A token with non-hex characters in the UUID or secret returns None."""
    assert parse_api_token("agxp_zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa") is None


# ---------------------------------------------------------------------------
# Hash + verify round-trip
# ---------------------------------------------------------------------------


def test_verify_secret_correct():
    """hash_secret then verify_secret with the same secret returns True."""
    secret = "deadbeef" * 4  # 32 hex chars
    hashed = hash_secret(secret)
    assert verify_secret(secret, hashed) is True


def test_verify_secret_wrong():
    """verify_secret with a different secret returns False."""
    secret = "deadbeef" * 4
    hashed = hash_secret(secret)
    assert verify_secret("cafebabe" * 4, hashed) is False


# ---------------------------------------------------------------------------
# Full round-trip: generate → parse → verify
# ---------------------------------------------------------------------------


def test_round_trip_api_key():
    """Generate, hash, parse, and verify a registered API key."""
    key_id = str(uuid.uuid4())
    token, secret_hex = generate_api_key(key_id)
    stored_hash = hash_secret(secret_hex)

    parsed = parse_api_token(token)
    assert parsed is not None
    assert parsed.key_id == key_id
    assert verify_secret(parsed.secret_hex, stored_hash) is True


def test_round_trip_anon_key():
    """Generate, hash, parse, and verify an anonymous key."""
    session_id = str(uuid.uuid4())
    token, secret_hex = generate_anon_key(session_id)
    stored_hash = hash_secret(secret_hex)

    parsed = parse_api_token(token)
    assert parsed is not None
    assert parsed.key_id == session_id
    assert verify_secret(parsed.secret_hex, stored_hash) is True
