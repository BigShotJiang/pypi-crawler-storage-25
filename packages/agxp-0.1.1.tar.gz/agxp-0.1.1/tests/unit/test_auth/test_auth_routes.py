"""
Unit tests for Issue #19 — User Onboarding auth routes.

Tests three new endpoints:
  POST /api/v1/auth/anonymous  — create anonymous session
  POST /api/v1/auth/register   — create user account
  POST /api/v1/auth/login      — authenticate user

Strategy:
- FastAPI TestClient (synchronous HTTP requests).
- Patch module-level DB helpers in agxp.api.routes.auth to avoid real DB calls.
- No dependency overrides needed — these endpoints CREATE auth, not verify it.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock, patch

import pytest
from fastapi.testclient import TestClient

from agxp.api.app import app

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_MODULE = "agxp.api.routes.auth"

_FAKE_USER_ID = str(uuid.uuid4())
_FAKE_SESSION_ID = str(uuid.uuid4())
_FAKE_KEY_ID = str(uuid.uuid4())
_FAKE_TOKEN = "agxp_" + "a" * 32 + "_" + "b" * 32
_FAKE_ANON_TOKEN = "agxp_anon_" + "a" * 32 + "_" + "b" * 32


# ============================================================================
# POST /api/v1/auth/anonymous
# ============================================================================


class TestAnonymousEndpoint:
    """Tests for POST /api/v1/auth/anonymous."""

    def test_anonymous_returns_201(self):
        """Happy path: anonymous session creation returns HTTP 201."""
        with patch(
            f"{_MODULE}.create_anonymous_session",
            new_callable=AsyncMock,
            return_value={
                "token": _FAKE_ANON_TOKEN,
                "session_id": _FAKE_SESSION_ID,
                "credit_balance": 20,
                "expires_at": (datetime.now(timezone.utc) + timedelta(days=30)).isoformat(),
            },
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post("/api/v1/auth/anonymous")

        assert response.status_code == 201

    def test_anonymous_response_fields(self):
        """Response must contain token, session_id, credit_balance, expires_at."""
        expires = datetime.now(timezone.utc) + timedelta(days=30)
        with patch(
            f"{_MODULE}.create_anonymous_session",
            new_callable=AsyncMock,
            return_value={
                "token": _FAKE_ANON_TOKEN,
                "session_id": _FAKE_SESSION_ID,
                "credit_balance": 20,
                "expires_at": expires.isoformat(),
            },
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post("/api/v1/auth/anonymous")

        body = response.json()
        assert "token" in body
        assert "session_id" in body
        assert "credit_balance" in body
        assert "expires_at" in body

    def test_anonymous_credit_balance_is_20(self):
        """Anonymous session starts with 20 credits."""
        with patch(
            f"{_MODULE}.create_anonymous_session",
            new_callable=AsyncMock,
            return_value={
                "token": _FAKE_ANON_TOKEN,
                "session_id": _FAKE_SESSION_ID,
                "credit_balance": 20,
                "expires_at": (datetime.now(timezone.utc) + timedelta(days=30)).isoformat(),
            },
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post("/api/v1/auth/anonymous")

        assert response.json()["credit_balance"] == 20

    def test_anonymous_token_format(self):
        """Anonymous token must start with 'agxp_anon_'."""
        with patch(
            f"{_MODULE}.create_anonymous_session",
            new_callable=AsyncMock,
            return_value={
                "token": _FAKE_ANON_TOKEN,
                "session_id": _FAKE_SESSION_ID,
                "credit_balance": 20,
                "expires_at": (datetime.now(timezone.utc) + timedelta(days=30)).isoformat(),
            },
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post("/api/v1/auth/anonymous")

        assert response.json()["token"].startswith("agxp_anon_")

    def test_anonymous_expires_at_roughly_30_days(self):
        """expires_at should be approximately 30 days in the future."""
        expires = datetime.now(timezone.utc) + timedelta(days=30)
        with patch(
            f"{_MODULE}.create_anonymous_session",
            new_callable=AsyncMock,
            return_value={
                "token": _FAKE_ANON_TOKEN,
                "session_id": _FAKE_SESSION_ID,
                "credit_balance": 20,
                "expires_at": expires.isoformat(),
            },
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post("/api/v1/auth/anonymous")

        body = response.json()
        # Parse the ISO timestamp and verify it's roughly 30 days from now
        exp = datetime.fromisoformat(body["expires_at"])
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        delta = exp - now
        assert 29 <= delta.days <= 31


# ============================================================================
# POST /api/v1/auth/register
# ============================================================================


class TestRegisterEndpoint:
    """Tests for POST /api/v1/auth/register."""

    def _valid_body(self, **overrides) -> dict:
        base = {
            "email": "test@example.com",
            "password": "securepassword123",
        }
        base.update(overrides)
        return base

    def test_register_returns_201(self):
        """Happy path: user registration returns HTTP 201."""
        with patch(
            f"{_MODULE}.create_user_account",
            new_callable=AsyncMock,
            return_value={
                "token": _FAKE_TOKEN,
                "user_id": _FAKE_USER_ID,
                "credit_balance": 50,
            },
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post("/api/v1/auth/register", json=self._valid_body())

        assert response.status_code == 201

    def test_register_response_fields(self):
        """Response must contain token, user_id, credit_balance."""
        with patch(
            f"{_MODULE}.create_user_account",
            new_callable=AsyncMock,
            return_value={
                "token": _FAKE_TOKEN,
                "user_id": _FAKE_USER_ID,
                "credit_balance": 50,
            },
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post("/api/v1/auth/register", json=self._valid_body())

        body = response.json()
        assert "token" in body
        assert "user_id" in body
        assert "credit_balance" in body

    def test_register_credit_balance_is_50(self):
        """Registered user starts with 50 credits."""
        with patch(
            f"{_MODULE}.create_user_account",
            new_callable=AsyncMock,
            return_value={
                "token": _FAKE_TOKEN,
                "user_id": _FAKE_USER_ID,
                "credit_balance": 50,
            },
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post("/api/v1/auth/register", json=self._valid_body())

        assert response.json()["credit_balance"] == 50

    def test_register_token_format(self):
        """Registered token starts with 'agxp_' but NOT 'agxp_anon_'."""
        with patch(
            f"{_MODULE}.create_user_account",
            new_callable=AsyncMock,
            return_value={
                "token": _FAKE_TOKEN,
                "user_id": _FAKE_USER_ID,
                "credit_balance": 50,
            },
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post("/api/v1/auth/register", json=self._valid_body())

        token = response.json()["token"]
        assert token.startswith("agxp_")
        assert not token.startswith("agxp_anon_")

    def test_register_with_anon_merge_credits_combined(self):
        """Register with anon_session_id merges credits: 50 + remaining anon credits."""
        anon_remaining = 15
        with patch(
            f"{_MODULE}.create_user_account",
            new_callable=AsyncMock,
            return_value={
                "token": _FAKE_TOKEN,
                "user_id": _FAKE_USER_ID,
                "credit_balance": 50 + anon_remaining,
            },
        ):
            client = TestClient(app, raise_server_exceptions=False)
            body = self._valid_body(anon_session_id=_FAKE_SESSION_ID)
            response = client.post("/api/v1/auth/register", json=body)

        assert response.status_code == 201
        assert response.json()["credit_balance"] == 65

    def test_register_duplicate_email_409(self):
        """Duplicate email returns 409 with error format."""
        with patch(
            f"{_MODULE}.create_user_account",
            new_callable=AsyncMock,
            side_effect=_make_http_error(409, "conflict", "Email already registered"),
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post("/api/v1/auth/register", json=self._valid_body())

        assert response.status_code == 409
        body = response.json()
        assert body["error"] == "conflict"
        assert "message" in body

    def test_register_missing_email_422(self):
        """Missing email returns 422 (Pydantic validation)."""
        client = TestClient(app, raise_server_exceptions=False)
        response = client.post("/api/v1/auth/register", json={"password": "securepassword123"})
        assert response.status_code == 422

    def test_register_missing_password_422(self):
        """Missing password returns 422 (Pydantic validation)."""
        client = TestClient(app, raise_server_exceptions=False)
        response = client.post("/api/v1/auth/register", json={"email": "test@example.com"})
        assert response.status_code == 422

    def test_register_password_too_short_422(self):
        """Password shorter than 8 characters returns 422 (Pydantic validation)."""
        client = TestClient(app, raise_server_exceptions=False)
        response = client.post(
            "/api/v1/auth/register",
            json=self._valid_body(password="short"),
        )
        assert response.status_code == 422

    def test_register_invalid_anon_session_404(self):
        """Invalid anon_session_id (not found) returns 404."""
        with patch(
            f"{_MODULE}.create_user_account",
            new_callable=AsyncMock,
            side_effect=_make_http_error(404, "not_found", "Anonymous session not found"),
        ):
            client = TestClient(app, raise_server_exceptions=False)
            body = self._valid_body(anon_session_id=str(uuid.uuid4()))
            response = client.post("/api/v1/auth/register", json=body)

        assert response.status_code == 404
        assert response.json()["error"] == "not_found"

    def test_register_already_merged_anon_session_400(self):
        """Already-merged anon_session_id returns 400."""
        with patch(
            f"{_MODULE}.create_user_account",
            new_callable=AsyncMock,
            side_effect=_make_http_error(400, "bad_request", "Anonymous session already merged"),
        ):
            client = TestClient(app, raise_server_exceptions=False)
            body = self._valid_body(anon_session_id=_FAKE_SESSION_ID)
            response = client.post("/api/v1/auth/register", json=body)

        assert response.status_code == 400
        assert response.json()["error"] == "bad_request"

    def test_register_expired_anon_session_400(self):
        """Expired anon_session_id returns 400."""
        with patch(
            f"{_MODULE}.create_user_account",
            new_callable=AsyncMock,
            side_effect=_make_http_error(400, "bad_request", "Anonymous session has expired"),
        ):
            client = TestClient(app, raise_server_exceptions=False)
            body = self._valid_body(anon_session_id=_FAKE_SESSION_ID)
            response = client.post("/api/v1/auth/register", json=body)

        assert response.status_code == 400
        assert response.json()["error"] == "bad_request"


# ============================================================================
# POST /api/v1/auth/login
# ============================================================================


class TestLoginEndpoint:
    """Tests for POST /api/v1/auth/login."""

    def _valid_body(self, **overrides) -> dict:
        base = {
            "email": "test@example.com",
            "password": "securepassword123",
        }
        base.update(overrides)
        return base

    def test_login_returns_200(self):
        """Happy path: valid credentials return HTTP 200."""
        with patch(
            f"{_MODULE}.authenticate_user",
            new_callable=AsyncMock,
            return_value={
                "token": _FAKE_TOKEN,
                "user_id": _FAKE_USER_ID,
            },
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post("/api/v1/auth/login", json=self._valid_body())

        assert response.status_code == 200

    def test_login_response_fields(self):
        """Response must contain token and user_id."""
        with patch(
            f"{_MODULE}.authenticate_user",
            new_callable=AsyncMock,
            return_value={
                "token": _FAKE_TOKEN,
                "user_id": _FAKE_USER_ID,
            },
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post("/api/v1/auth/login", json=self._valid_body())

        body = response.json()
        assert "token" in body
        assert "user_id" in body

    def test_login_wrong_email_401(self):
        """Non-existent email returns 401."""
        with patch(
            f"{_MODULE}.authenticate_user",
            new_callable=AsyncMock,
            side_effect=_make_http_error(401, "unauthorized", "Invalid email or password"),
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post(
                "/api/v1/auth/login",
                json=self._valid_body(email="nonexistent@example.com"),
            )

        assert response.status_code == 401

    def test_login_wrong_password_401(self):
        """Wrong password returns 401."""
        with patch(
            f"{_MODULE}.authenticate_user",
            new_callable=AsyncMock,
            side_effect=_make_http_error(401, "unauthorized", "Invalid email or password"),
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post(
                "/api/v1/auth/login",
                json=self._valid_body(password="wrongpassword123"),
            )

        assert response.status_code == 401

    def test_login_wrong_email_and_password_same_error(self):
        """Wrong email and wrong password produce identical error to prevent user enumeration."""
        error_msg = "Invalid email or password"

        with patch(
            f"{_MODULE}.authenticate_user",
            new_callable=AsyncMock,
            side_effect=_make_http_error(401, "unauthorized", error_msg),
        ):
            client = TestClient(app, raise_server_exceptions=False)
            wrong_email_resp = client.post(
                "/api/v1/auth/login",
                json=self._valid_body(email="nonexistent@example.com"),
            )

        with patch(
            f"{_MODULE}.authenticate_user",
            new_callable=AsyncMock,
            side_effect=_make_http_error(401, "unauthorized", error_msg),
        ):
            client = TestClient(app, raise_server_exceptions=False)
            wrong_pwd_resp = client.post(
                "/api/v1/auth/login",
                json=self._valid_body(password="wrongpassword123"),
            )

        # Both should have the exact same error body (no user enumeration)
        assert wrong_email_resp.json() == wrong_pwd_resp.json()
        assert wrong_email_resp.status_code == wrong_pwd_resp.status_code == 401

    def test_login_missing_email_422(self):
        """Missing email returns 422."""
        client = TestClient(app, raise_server_exceptions=False)
        response = client.post("/api/v1/auth/login", json={"password": "securepassword123"})
        assert response.status_code == 422

    def test_login_missing_password_422(self):
        """Missing password returns 422."""
        client = TestClient(app, raise_server_exceptions=False)
        response = client.post("/api/v1/auth/login", json={"email": "test@example.com"})
        assert response.status_code == 422


# ============================================================================
# Cross-cutting
# ============================================================================


class TestErrorFormat:
    """All error responses must follow {"error": "...", "message": "..."} format."""

    def test_register_conflict_error_format(self):
        """409 response has standard error format."""
        with patch(
            f"{_MODULE}.create_user_account",
            new_callable=AsyncMock,
            side_effect=_make_http_error(409, "conflict", "Email already registered"),
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post(
                "/api/v1/auth/register",
                json={"email": "dup@example.com", "password": "securepassword123"},
            )

        body = response.json()
        assert isinstance(body.get("error"), str)
        assert isinstance(body.get("message"), str)

    def test_login_unauthorized_error_format(self):
        """401 response has standard error format."""
        with patch(
            f"{_MODULE}.authenticate_user",
            new_callable=AsyncMock,
            side_effect=_make_http_error(401, "unauthorized", "Invalid email or password"),
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post(
                "/api/v1/auth/login",
                json={"email": "test@example.com", "password": "wrong"},
            )

        body = response.json()
        assert isinstance(body.get("error"), str)
        assert isinstance(body.get("message"), str)

    def test_register_not_found_error_format(self):
        """404 response has standard error format."""
        with patch(
            f"{_MODULE}.create_user_account",
            new_callable=AsyncMock,
            side_effect=_make_http_error(404, "not_found", "Anonymous session not found"),
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post(
                "/api/v1/auth/register",
                json={
                    "email": "test@example.com",
                    "password": "securepassword123",
                    "anon_session_id": str(uuid.uuid4()),
                },
            )

        body = response.json()
        assert isinstance(body.get("error"), str)
        assert isinstance(body.get("message"), str)


class TestContentType:
    """All endpoints accept JSON content type."""

    def test_anonymous_accepts_empty_json(self):
        """POST /auth/anonymous works without a request body."""
        with patch(
            f"{_MODULE}.create_anonymous_session",
            new_callable=AsyncMock,
            return_value={
                "token": _FAKE_ANON_TOKEN,
                "session_id": _FAKE_SESSION_ID,
                "credit_balance": 20,
                "expires_at": (datetime.now(timezone.utc) + timedelta(days=30)).isoformat(),
            },
        ):
            client = TestClient(app, raise_server_exceptions=False)
            response = client.post("/api/v1/auth/anonymous")

        assert response.status_code == 201

    def test_register_requires_json_body(self):
        """POST /auth/register without JSON body returns 422."""
        client = TestClient(app, raise_server_exceptions=False)
        response = client.post("/api/v1/auth/register")
        assert response.status_code == 422

    def test_login_requires_json_body(self):
        """POST /auth/login without JSON body returns 422."""
        client = TestClient(app, raise_server_exceptions=False)
        response = client.post("/api/v1/auth/login")
        assert response.status_code == 422


# ============================================================================
# Helpers
# ============================================================================


def _make_http_error(status_code: int, error: str, message: str):
    """Create an HTTPException side_effect for patching."""
    from fastapi import HTTPException

    return HTTPException(
        status_code=status_code,
        detail={"error": error, "message": message},
    )
