"""
Unit tests for agxp.auth.dependency — require_auth FastAPI dependency.

All DB calls are patched at module level. bcrypt is real (verify_secret is
CPU-bound but fast enough for tests with a single round-trip).
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock, patch

import pytest

from agxp.auth.dependency import require_auth
from agxp.auth.keys import generate_anon_key, generate_api_key, hash_secret

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_MODULE = "agxp.auth.dependency"


def _registered_row(key_id: str, secret_hex: str, *, revoked: bool = False) -> dict:
    """Build a fake api_keys row dict."""
    return {
        "id": uuid.UUID(key_id),
        "user_id": uuid.UUID(str(uuid.uuid4())),
        "key_hash": hash_secret(secret_hex),
        "revoked_at": datetime.now(timezone.utc) if revoked else None,
    }


def _anon_row(
    session_id: str,
    secret_hex: str,
    *,
    expired: bool = False,
    merged: bool = False,
) -> dict:
    """Build a fake anonymous_sessions row dict."""
    now = datetime.now(timezone.utc)
    return {
        "id": uuid.UUID(session_id),
        "temp_key_hash": hash_secret(secret_hex),
        "expires_at": now - timedelta(hours=1) if expired else now + timedelta(hours=24),
        "merged_into_user_id": uuid.UUID(str(uuid.uuid4())) if merged else None,
    }


# ---------------------------------------------------------------------------
# Missing / malformed header
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_missing_auth_header():
    """No Authorization header → 401."""
    from fastapi import HTTPException

    with pytest.raises(HTTPException) as exc_info:
        await require_auth(authorization=None)
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_wrong_scheme():
    """Non-Bearer scheme → 401."""
    from fastapi import HTTPException

    with pytest.raises(HTTPException) as exc_info:
        await require_auth(authorization="Basic abc123")
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_invalid_token_format():
    """Bearer token with invalid format → 401."""
    from fastapi import HTTPException

    with pytest.raises(HTTPException) as exc_info:
        await require_auth(authorization="Bearer not-a-valid-token")
    assert exc_info.value.status_code == 401


# ---------------------------------------------------------------------------
# Registered key — success
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_valid_registered_key():
    """Valid registered key → AuthIdentity with user_id."""
    key_id = str(uuid.uuid4())
    token, secret_hex = generate_api_key(key_id)
    row = _registered_row(key_id, secret_hex)

    with (
        patch(f"{_MODULE}.lookup_api_key", new_callable=AsyncMock, return_value=row),
        patch(f"{_MODULE}.touch_api_key", new_callable=AsyncMock) as mock_touch,
    ):
        identity = await require_auth(authorization=f"Bearer {token}")

    assert identity.user_id == str(row["user_id"])
    assert identity.anon_session_id is None
    assert identity.is_anonymous is False
    mock_touch.assert_called_once_with(str(row["id"]))


# ---------------------------------------------------------------------------
# Registered key — failure cases
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_unknown_key_id():
    """Key ID not found in DB → 401."""
    from fastapi import HTTPException

    key_id = str(uuid.uuid4())
    token, _ = generate_api_key(key_id)

    with patch(f"{_MODULE}.lookup_api_key", new_callable=AsyncMock, return_value=None):
        with pytest.raises(HTTPException) as exc_info:
            await require_auth(authorization=f"Bearer {token}")
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_revoked_key():
    """Revoked key → 401."""
    from fastapi import HTTPException

    key_id = str(uuid.uuid4())
    token, secret_hex = generate_api_key(key_id)
    row = _registered_row(key_id, secret_hex, revoked=True)

    with patch(f"{_MODULE}.lookup_api_key", new_callable=AsyncMock, return_value=row):
        with pytest.raises(HTTPException) as exc_info:
            await require_auth(authorization=f"Bearer {token}")
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_wrong_secret_registered():
    """Valid key_id but wrong secret → 401."""
    from fastapi import HTTPException

    key_id = str(uuid.uuid4())
    token, _ = generate_api_key(key_id)
    # Hash a *different* secret
    row = _registered_row(key_id, "a" * 32)

    with patch(f"{_MODULE}.lookup_api_key", new_callable=AsyncMock, return_value=row):
        with pytest.raises(HTTPException) as exc_info:
            await require_auth(authorization=f"Bearer {token}")
    assert exc_info.value.status_code == 401


# ---------------------------------------------------------------------------
# Anonymous session — success
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_valid_anon_session():
    """Valid anonymous token → AuthIdentity with anon_session_id."""
    session_id = str(uuid.uuid4())
    token, secret_hex = generate_anon_key(session_id)
    row = _anon_row(session_id, secret_hex)

    with patch(f"{_MODULE}.lookup_anon_session", new_callable=AsyncMock, return_value=row):
        identity = await require_auth(authorization=f"Bearer {token}")

    assert identity.user_id is None
    assert identity.anon_session_id == session_id
    assert identity.is_anonymous is True


# ---------------------------------------------------------------------------
# Anonymous session — failure cases
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_unknown_anon_session():
    """Session ID not found → 401."""
    from fastapi import HTTPException

    session_id = str(uuid.uuid4())
    token, _ = generate_anon_key(session_id)

    with patch(f"{_MODULE}.lookup_anon_session", new_callable=AsyncMock, return_value=None):
        with pytest.raises(HTTPException) as exc_info:
            await require_auth(authorization=f"Bearer {token}")
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_expired_anon_session():
    """Expired session → 401."""
    from fastapi import HTTPException

    session_id = str(uuid.uuid4())
    token, secret_hex = generate_anon_key(session_id)
    row = _anon_row(session_id, secret_hex, expired=True)

    with patch(f"{_MODULE}.lookup_anon_session", new_callable=AsyncMock, return_value=row):
        with pytest.raises(HTTPException) as exc_info:
            await require_auth(authorization=f"Bearer {token}")
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_merged_anon_session():
    """Merged session → 401."""
    from fastapi import HTTPException

    session_id = str(uuid.uuid4())
    token, secret_hex = generate_anon_key(session_id)
    row = _anon_row(session_id, secret_hex, merged=True)

    with patch(f"{_MODULE}.lookup_anon_session", new_callable=AsyncMock, return_value=row):
        with pytest.raises(HTTPException) as exc_info:
            await require_auth(authorization=f"Bearer {token}")
    assert exc_info.value.status_code == 401


@pytest.mark.asyncio
async def test_wrong_secret_anon():
    """Valid session_id but wrong secret → 401."""
    from fastapi import HTTPException

    session_id = str(uuid.uuid4())
    token, _ = generate_anon_key(session_id)
    row = _anon_row(session_id, "b" * 32)

    with patch(f"{_MODULE}.lookup_anon_session", new_callable=AsyncMock, return_value=row):
        with pytest.raises(HTTPException) as exc_info:
            await require_auth(authorization=f"Bearer {token}")
    assert exc_info.value.status_code == 401
