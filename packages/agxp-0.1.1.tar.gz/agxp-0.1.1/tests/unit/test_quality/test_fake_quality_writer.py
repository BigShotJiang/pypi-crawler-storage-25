"""
Unit tests for FakeQualityWriter.

All tests are pure in-memory — no I/O, no database, no network.
FakeQualityWriter is the test double for QualityScoreWriter used in unit tests
that exercise higher-level components (score_quality task, etc.).

Contract under test: agxp/services/quality_score_writer.py (QualityScoreWriter ABC).

Key contract points verified here:
- recompute_score() returns 0.0 for an unseeded experience
- recompute_score() returns the seeded value after seed()
- update_score() applies delta and returns new score
- update_score() clamps result above 1.0 to 1.0
- update_score() clamps result below 0.0 to 0.0
- update_score() on unseeded experience treats starting score as 0.0
- Both methods are async (awaitable)
- FakeQualityWriter is a subclass of QualityScoreWriter ABC
"""

import inspect
import uuid

import pytest

from agxp.services.fake_quality_writer import FakeQualityWriter
from agxp.services.quality_score_writer import QualityScoreWriter

pytestmark = pytest.mark.asyncio(loop_scope="session")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _exp_id() -> str:
    """Return a fresh unique experience_id string for test isolation."""
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Instantiation and ABC compliance
# ---------------------------------------------------------------------------


def test_fake_is_subclass_of_abc():
    """FakeQualityWriter must be a proper subclass of QualityScoreWriter."""
    assert issubclass(FakeQualityWriter, QualityScoreWriter)


# ---------------------------------------------------------------------------
# recompute_score
# ---------------------------------------------------------------------------


async def test_recompute_score_unseeded_returns_zero():
    """
    Contract: recompute_score() for an experience_id that has never been seeded
    must return 0.0 (not raise). Default score is zero.
    """
    writer = FakeQualityWriter()
    score = await writer.recompute_score(_exp_id())
    assert score == 0.0


async def test_recompute_score_after_seed():
    """
    seed(exp, 0.8) followed by recompute_score() must return 0.8.
    seed() is the test-helper to pre-load a score without side effects.
    """
    writer = FakeQualityWriter()
    exp_id = _exp_id()
    writer.seed(exp_id, 0.8)
    score = await writer.recompute_score(exp_id)
    assert score == pytest.approx(0.8)


# ---------------------------------------------------------------------------
# update_score
# ---------------------------------------------------------------------------


async def test_update_score_applies_delta():
    """
    seed(exp, 0.5), update(+0.2, reason) → 0.7.
    delta is added to current score and the new score is returned.
    """
    writer = FakeQualityWriter()
    exp_id = _exp_id()
    writer.seed(exp_id, 0.5)
    new_score = await writer.update_score(exp_id, 0.2, "feedback")
    assert new_score == pytest.approx(0.7)


async def test_update_score_clamps_above_one():
    """
    seed(exp, 0.9), update(+0.5) → 1.0 (clamped, not 1.4).
    Score must never exceed 1.0.
    """
    writer = FakeQualityWriter()
    exp_id = _exp_id()
    writer.seed(exp_id, 0.9)
    new_score = await writer.update_score(exp_id, 0.5, "vote")
    assert new_score == pytest.approx(1.0)


async def test_update_score_clamps_below_zero():
    """
    seed(exp, 0.1), update(-0.5) → 0.0 (clamped, not -0.4).
    Score must never fall below 0.0.
    """
    writer = FakeQualityWriter()
    exp_id = _exp_id()
    writer.seed(exp_id, 0.1)
    new_score = await writer.update_score(exp_id, -0.5, "vote")
    assert new_score == pytest.approx(0.0)


async def test_update_score_on_unseeded_experience():
    """
    No seed, update(+0.3) → 0.3.
    Updating an unknown experience treats it as starting from 0.0.
    """
    writer = FakeQualityWriter()
    exp_id = _exp_id()
    new_score = await writer.update_score(exp_id, 0.3, "use")
    assert new_score == pytest.approx(0.3)


# ---------------------------------------------------------------------------
# Async correctness
# ---------------------------------------------------------------------------


def test_recompute_score_is_async():
    """recompute_score() must return a coroutine (awaitable)."""
    writer = FakeQualityWriter()
    coro = writer.recompute_score(_exp_id())
    assert inspect.isawaitable(coro), "recompute_score() must be async/awaitable"
    # Close to avoid ResourceWarning
    coro.close()


def test_update_score_is_async():
    """update_score() must return a coroutine (awaitable)."""
    writer = FakeQualityWriter()
    coro = writer.update_score(_exp_id(), 0.1, "feedback")
    assert inspect.isawaitable(coro), "update_score() must be async/awaitable"
    coro.close()
