"""
Unit tests for credits_for_quality(quality_score: float) -> int.

Lives in: agxp/workers/credit.py
Pure function — no I/O.

Mapping (from Issue #7 spec):
  [0.0, 0.5)   →  5
  [0.5, 0.7)   → 10
  [0.7, 0.85)  → 25
  [0.85, 1.0]  → 50
"""

import pytest

from agxp.workers.credit import credits_for_quality


# ---------------------------------------------------------------------------
# Tier 1: [0.0, 0.5) → 5 credits
# ---------------------------------------------------------------------------


def test_score_zero_gives_five():
    """score=0.0 is the minimum; must map to 5 credits."""
    assert credits_for_quality(0.0) == 5


def test_score_below_half_gives_five():
    """score=0.49 is still in [0.0, 0.5); must map to 5 credits."""
    assert credits_for_quality(0.49) == 5


# ---------------------------------------------------------------------------
# Tier 2: [0.5, 0.7) → 10 credits
# ---------------------------------------------------------------------------


def test_score_at_half_gives_ten():
    """score=0.5 is the lower boundary of tier 2; must map to 10 credits."""
    assert credits_for_quality(0.5) == 10


def test_score_below_seventy_gives_ten():
    """score=0.69 is still in [0.5, 0.7); must map to 10 credits."""
    assert credits_for_quality(0.69) == 10


# ---------------------------------------------------------------------------
# Tier 3: [0.7, 0.85) → 25 credits
# ---------------------------------------------------------------------------


def test_score_at_seventy_gives_twentyfive():
    """score=0.7 is the lower boundary of tier 3; must map to 25 credits."""
    assert credits_for_quality(0.7) == 25


def test_score_below_eightyfive_gives_twentyfive():
    """score=0.84 is still in [0.7, 0.85); must map to 25 credits."""
    assert credits_for_quality(0.84) == 25


# ---------------------------------------------------------------------------
# Tier 4: [0.85, 1.0] → 50 credits
# ---------------------------------------------------------------------------


def test_score_at_eightyfive_gives_fifty():
    """score=0.85 is the lower boundary of tier 4; must map to 50 credits."""
    assert credits_for_quality(0.85) == 50


def test_score_one_gives_fifty():
    """score=1.0 is the maximum; must map to 50 credits."""
    assert credits_for_quality(1.0) == 50


# ---------------------------------------------------------------------------
# Boundary precision
# ---------------------------------------------------------------------------


def test_score_just_below_seventy_gives_ten():
    """score=0.6999... is still tier 2; must map to 10 credits."""
    assert credits_for_quality(0.6999) == 10


def test_score_just_below_eightyfive_gives_twentyfive():
    """score=0.8499... is still tier 3; must map to 25 credits."""
    assert credits_for_quality(0.8499) == 25
