"""
Unit tests for the score_quality Celery task.

Uses FakeQualityWriter injected via unittest.mock.patch so that no real DB or
Redis connection is required.

Contract under test:
  - score_quality task returns {"status": "ok", "experience_id": ..., "user_id": ...,
    "quality_score": ...}
  - score_quality chains to award_credits.delay(experience_id, user_id, quality_score)
  - score_quality retries on transient Exception (self.retry is called)
"""

import uuid
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from celery.exceptions import Retry

# Import backends module to ensure it's loaded before patching
import agxp.config.backends
from agxp.services.fake_quality_writer import FakeQualityWriter


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _exp_id() -> str:
    return str(uuid.uuid4())


def _user_id() -> str:
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Task importability and registration
# ---------------------------------------------------------------------------


def test_score_quality_task_is_importable():
    """score_quality must be importable from agxp.workers.score_quality."""
    from agxp.workers.score_quality import score_quality
    assert callable(score_quality)


def test_score_quality_task_name():
    """score_quality.name must match the canonical Celery task name."""
    from agxp.workers.score_quality import score_quality
    assert score_quality.name == "agxp.workers.score_quality.score_quality"


def test_score_quality_max_retries():
    """score_quality must be configured with max_retries=3."""
    from agxp.workers.score_quality import score_quality
    assert score_quality.max_retries == 3


# ---------------------------------------------------------------------------
# Happy path: returns correct result dict
# ---------------------------------------------------------------------------


def test_score_quality_returns_ok_status():
    """
    When QUALITY_WRITER.recompute_score returns 0.75, the task must return
    a dict with status=="ok".

    Strategy: patch agxp.config.backends.QUALITY_WRITER with a FakeQualityWriter
    pre-seeded to return 0.75, and mock award_credits.delay to avoid network I/O.
    """
    from agxp.workers.score_quality import score_quality

    exp_id = _exp_id()
    user_id = _user_id()

    fake_writer = FakeQualityWriter()
    fake_writer.seed(exp_id, 0.75)

    with patch("agxp.config.backends.QUALITY_WRITER",fake_writer):
        with patch("agxp.workers.score_quality.award_credits") as mock_award:
            mock_award.delay = MagicMock()
            result = score_quality.apply(args=[exp_id, user_id]).get()

    assert result["status"] == "ok"


def test_score_quality_result_contains_quality_score():
    """
    The returned dict must include quality_score equal to the value returned
    by QUALITY_WRITER.recompute_score.
    """
    from agxp.workers.score_quality import score_quality

    exp_id = _exp_id()
    user_id = _user_id()

    fake_writer = FakeQualityWriter()
    fake_writer.seed(exp_id, 0.75)

    with patch("agxp.config.backends.QUALITY_WRITER",fake_writer):
        with patch("agxp.workers.score_quality.award_credits") as mock_award:
            mock_award.delay = MagicMock()
            result = score_quality.apply(args=[exp_id, user_id]).get()

    assert "quality_score" in result
    assert result["quality_score"] == pytest.approx(0.75)
    assert result["experience_id"] == exp_id
    assert result["user_id"] == user_id


def test_score_quality_chains_to_award_credits():
    """
    After computing quality_score, the task must call
    award_credits.delay(experience_id, user_id, quality_score).
    """
    from agxp.workers.score_quality import score_quality

    exp_id = _exp_id()
    user_id = _user_id()

    fake_writer = FakeQualityWriter()
    fake_writer.seed(exp_id, 0.75)

    with patch("agxp.config.backends.QUALITY_WRITER",fake_writer):
        with patch("agxp.workers.score_quality.award_credits") as mock_award:
            mock_award.delay = MagicMock()
            score_quality.apply(args=[exp_id, user_id]).get()
            mock_award.delay.assert_called_once_with(exp_id, user_id, pytest.approx(0.75))


# ---------------------------------------------------------------------------
# Retry on transient error
# ---------------------------------------------------------------------------


def test_score_quality_retries_on_transient_error():
    """
    When QUALITY_WRITER.recompute_score raises a generic Exception (transient),
    the task must retry (raise celery.exceptions.Retry).

    We use task.apply() with throw=True so Celery propagates the Retry exception
    rather than silently catching it.
    """
    from agxp.workers.score_quality import score_quality

    exp_id = _exp_id()
    user_id = _user_id()

    failing_writer = MagicMock()
    failing_writer.recompute_score = AsyncMock(side_effect=ConnectionError("DB down"))

    with patch("agxp.config.backends.QUALITY_WRITER",failing_writer):
        with pytest.raises(Retry):
            score_quality.apply(args=[exp_id, user_id], throw=True).get()
