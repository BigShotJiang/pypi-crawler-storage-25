"""
Unit tests for compute_completeness_score(row: dict) -> float.

Lives in: agxp/services/inline_quality_writer.py
Pure function — no DB, no I/O.

Scoring rules (from Issue #7 spec):
  0.50  base
  +0.15  if failed_approaches is a non-empty string
  +0.10  if environment is non-None and non-empty dict
  +0.10  if solution or lessons contains a quantifiable result
           (regex: digit sequence of 2+ chars, OR percentage like "50%")
  +0.10  if lessons word count > 100
  +0.05  if len(tags) >= 3
  = min(sum, 1.0)
"""

import pytest

from agxp.services.inline_quality_writer import compute_completeness_score

# ---------------------------------------------------------------------------
# Helper: build a minimal "empty" row
# ---------------------------------------------------------------------------


def _empty_row() -> dict:
    """All optional fields absent/None — should yield only the 0.50 base score."""
    return {
        "failed_approaches": None,
        "environment": None,
        "solution": None,
        "lessons": None,
        "tags": None,
    }


def _long_lessons(word_count: int) -> str:
    """Generate a lessons string with exactly `word_count` words."""
    return " ".join(["word"] * word_count)


# ---------------------------------------------------------------------------
# Base score only
# ---------------------------------------------------------------------------


def test_base_score_only():
    """All optional fields None/empty → exactly 0.50."""
    row = _empty_row()
    assert compute_completeness_score(row) == pytest.approx(0.50)


# ---------------------------------------------------------------------------
# failed_approaches bonus (+0.15)
# ---------------------------------------------------------------------------


def test_failed_approaches_bonus():
    """Non-empty failed_approaches string adds +0.15 to the base score."""
    row = _empty_row()
    row["failed_approaches"] = "Tried increasing timeout only"
    assert compute_completeness_score(row) == pytest.approx(0.65)


def test_failed_approaches_empty_string_no_bonus():
    """Empty string for failed_approaches must NOT trigger the bonus."""
    row = _empty_row()
    row["failed_approaches"] = ""
    assert compute_completeness_score(row) == pytest.approx(0.50)


# ---------------------------------------------------------------------------
# environment bonus (+0.10)
# ---------------------------------------------------------------------------


def test_environment_bonus():
    """Non-empty environment dict adds +0.10 to the base score."""
    row = _empty_row()
    row["environment"] = {"python": "3.11"}
    assert compute_completeness_score(row) == pytest.approx(0.60)


def test_environment_empty_dict_no_bonus():
    """Empty dict for environment must NOT trigger the bonus."""
    row = _empty_row()
    row["environment"] = {}
    assert compute_completeness_score(row) == pytest.approx(0.50)


# ---------------------------------------------------------------------------
# quantifiable result bonus (+0.10)
# ---------------------------------------------------------------------------


def test_quantifiable_result_bonus_digits():
    """
    solution containing a digit sequence of 2+ chars (e.g. "30 seconds")
    must add +0.10.
    """
    row = _empty_row()
    row["solution"] = "Increased memory to 512MB and response time dropped 30 seconds"
    assert compute_completeness_score(row) == pytest.approx(0.60)


def test_quantifiable_result_bonus_percent():
    """
    lessons containing a percentage like "50%" must add +0.10.
    """
    row = _empty_row()
    row["lessons"] = "Performance improved by 50% after tuning"
    assert compute_completeness_score(row) == pytest.approx(0.60)


def test_quantifiable_result_bonus_in_lessons_digits():
    """
    lessons containing a digit sequence of 2+ chars must trigger the bonus
    even when solution is None.
    """
    row = _empty_row()
    row["lessons"] = "Reduced latency from 250ms to 80ms"
    assert compute_completeness_score(row) == pytest.approx(0.60)


def test_quantifiable_result_no_bonus_single_digit():
    """
    A single-digit number (e.g. "1") must NOT trigger the quantifiable bonus,
    because the spec requires a digit sequence of 2+ chars.
    Note: "1%" is ambiguous — this test uses a bare digit to confirm no bonus.
    """
    row = _empty_row()
    row["solution"] = "Tried 1 approach"
    # Single digit — no bonus
    assert compute_completeness_score(row) == pytest.approx(0.50)


# ---------------------------------------------------------------------------
# lessons word count bonus (+0.10)
# ---------------------------------------------------------------------------


def test_lessons_word_count_bonus():
    """lessons with 101 words must add +0.10 (word count > 100)."""
    row = _empty_row()
    row["lessons"] = _long_lessons(101)
    assert compute_completeness_score(row) == pytest.approx(0.60)


def test_lessons_word_count_no_bonus_exactly_100():
    """lessons with exactly 100 words must NOT add the bonus (> 100, not >= 100)."""
    row = _empty_row()
    row["lessons"] = _long_lessons(100)
    assert compute_completeness_score(row) == pytest.approx(0.50)


def test_lessons_word_count_no_bonus_fewer_than_hundred():
    """lessons with 99 words must NOT add the bonus."""
    row = _empty_row()
    row["lessons"] = _long_lessons(99)
    assert compute_completeness_score(row) == pytest.approx(0.50)


# ---------------------------------------------------------------------------
# tags bonus (+0.05)
# ---------------------------------------------------------------------------


def test_tags_bonus():
    """tags list with 3 or more items must add +0.05."""
    row = _empty_row()
    row["tags"] = ["aws", "lambda", "performance"]
    assert compute_completeness_score(row) == pytest.approx(0.55)


def test_tags_bonus_more_than_three():
    """tags list with more than 3 items must still add only +0.05."""
    row = _empty_row()
    row["tags"] = ["aws", "lambda", "performance", "python", "serverless"]
    assert compute_completeness_score(row) == pytest.approx(0.55)


def test_tags_no_bonus_fewer_than_three():
    """tags list with fewer than 3 items must NOT add the bonus."""
    row = _empty_row()
    row["tags"] = ["aws", "lambda"]
    assert compute_completeness_score(row) == pytest.approx(0.50)


def test_tags_no_bonus_empty_list():
    """Empty tags list must NOT add the bonus."""
    row = _empty_row()
    row["tags"] = []
    assert compute_completeness_score(row) == pytest.approx(0.50)


# ---------------------------------------------------------------------------
# Maximum score is capped at 1.0
# ---------------------------------------------------------------------------


def test_max_score_is_one():
    """
    All bonuses triggered simultaneously sum to 1.05, but the result must
    be clamped to 1.0. Verifies min(sum, 1.0) is applied.

    Bonuses:
      0.50 base
      +0.15 failed_approaches
      +0.10 environment
      +0.10 quantifiable result
      +0.10 lessons > 100 words (also triggers quantifiable via "250ms")
      +0.05 tags >= 3
      = 1.00 (but raw sum is 1.00 with 250ms in 101-word lessons)

    We use a solution with an explicit digit sequence to ensure quantifiable
    bonus fires independently of the lessons word-count content.
    """
    row = {
        "failed_approaches": "Tried increasing timeout only",
        "environment": {"runtime": "python3.11", "memory": "256MB"},
        "solution": "Increased memory to 512MB and response time dropped 40%",
        "lessons": _long_lessons(101),
        "tags": ["aws", "lambda", "performance"],
    }
    # All five bonuses: 0.50 + 0.15 + 0.10 + 0.10 + 0.10 + 0.05 = 1.00
    # (solution has "40%" which triggers quantifiable bonus)
    result = compute_completeness_score(row)
    assert result == pytest.approx(1.0)
    assert result <= 1.0
