"""
Unit tests for MCP Server Tools (pure remote API mode).
All tools call remote API, no local database.
Tests mock API responses to validate tool logic.
"""
from __future__ import annotations
import re
import json
from unittest.mock import patch, MagicMock
import pytest
UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
    re.IGNORECASE,
)
# Expected fields in search results
SEARCH_RESULT_FIELDS = {
    "experience_id",
    "domain",
    "task_type",
    "situation",
    "solution",
    "outcome_type",
    "lessons",
    "failed_approaches",
    "environment",
    "tags",
    "language",
    "quality_score",
}
_TEST_ANONYMOUS_TOKEN = "test_anon_token_12345"
_TEST_CONTRIBUTE_RESPONSE = {"experience_id": "test-uuid-12345", "status": "stored"}
_TEST_FEEDBACK_RESPONSE = {"experience_id": "test-uuid-12345", "quality_score": 0.85, "status": "updated"}
_TEST_SEARCH_RESULTS = [
    {
        "experience_id": "exp-1",
        "domain": "coding",
        "task_type": "debugging",
        "situation": "asyncio event loop blocks on database query",
        "solution": "Use run_in_executor for blocking I/O",
        "outcome_type": "solved",
        "lessons": "Never block the event loop",
        "quality_score": 0.85,
        "language": "en"
    },
    {
        "experience_id": "exp-2",
        "domain": "frontend",
        "task_type": "build",
        "situation": "webpack config error in React build",
        "solution": "Update babel preset",
        "outcome_type": "solved",
        "lessons": "Keep build tools updated",
        "quality_score": 0.7,
        "language": "en"
    },
    {
        "experience_id": "exp-3",
        "domain": "backend",
        "task_type": "deployment",
        "situation": "database migration error in Django",
        "solution": "Run makemigrations first",
        "outcome_type": "solved",
        "lessons": "Always run makemigrations before migrate",
        "quality_score": 0.75,
        "language": "en"
    }
]

# Import tools here once instead of in fixture
import agxp.mcp.server as mcp_server

# ============================================================================
# search_experiences — Happy Path
# ============================================================================
class TestSearchHappyPath:
    """search_experiences returns correct results from remote API."""

    @patch("agxp.mcp.server._query_remote_server", return_value=_TEST_SEARCH_RESULTS)
    def test_search_returns_dict_with_results_list(self, mock_query):
        """search returns dict with results list containing expected fields."""
        output = mcp_server.search_experiences(query="asyncio event loop blocking")

        assert isinstance(output, dict)
        assert "results" in output
        assert "pending_feedback" in output
        assert "pending_feedback_hint" in output
        results = output["results"]
        assert len(results) == len(_TEST_SEARCH_RESULTS)
        result = results[0]

        # Must have experience_id, NOT id
        assert "experience_id" in result
        assert "id" not in result
        assert result["experience_id"] == _TEST_SEARCH_RESULTS[0]["experience_id"]
        # Verify query was called with correct parameters
        mock_query.assert_called_once_with("asyncio event loop blocking", None, None, 5)

    @patch("agxp.mcp.server._query_remote_server", return_value=[_TEST_SEARCH_RESULTS[0]])
    def test_search_with_domain_filter(self, mock_query):
        """Domain filter parameter is passed to API."""
        output = mcp_server.search_experiences(query="error", domain="frontend")
        # Verify the query was called with domain filter
        mock_query.assert_called_once_with("error", "frontend", None, 5)

    @patch("agxp.mcp.server._query_remote_server", return_value=[_TEST_SEARCH_RESULTS[0]])
    def test_search_with_limit(self, mock_query):
        """Limit parameter is passed to API."""
        output = mcp_server.search_experiences(query="testlimit", limit=2)
        mock_query.assert_called_once_with("testlimit", None, None, 2)

    @patch("agxp.mcp.server._query_remote_server", return_value=[_TEST_SEARCH_RESULTS[0]])
    def test_search_with_task_type_filter(self, mock_query):
        """Task type filter parameter is passed to API."""
        output = mcp_server.search_experiences(query="alpha", task_type="deployment")
        mock_query.assert_called_once_with("alpha", None, "deployment", 5)

    @patch("agxp.mcp.server._query_remote_server", return_value=[_TEST_SEARCH_RESULTS[0]])
    def test_search_default_limit_is_five(self, mock_query):
        """Default limit should be 5 per the contract."""
        output = mcp_server.search_experiences(query="xylophone")
        mock_query.assert_called_once_with("xylophone", None, None, 5)

    @patch("agxp.mcp.server._query_remote_server", return_value=[])
    def test_search_empty_returns_empty_results(self, mock_query):
        """API returning no results returns dict with empty results list."""
        output = mcp_server.search_experiences(query="anything at all")
        assert isinstance(output, dict)
        assert output["results"] == []

    @patch("agxp.mcp.server._query_remote_server", side_effect=Exception("API error"))
    def test_search_api_error_returns_empty_results(self, mock_query):
        """API errors should return empty results, not raise exceptions (per contract)."""
        output = mcp_server.search_experiences(query="anything at all")
        assert isinstance(output, dict)
        assert output["results"] == []

# ============================================================================
# contribute_experience — Happy Path
# ============================================================================
class TestContributeHappyPath:
    """contribute_experience returns expected structure from remote API."""

    @patch("agxp.mcp.server._contribute_remote", return_value=_TEST_CONTRIBUTE_RESPONSE)
    def test_contribute_returns_experience_id_and_status(self, mock_contribute):
        """Return dict must have experience_id and status='stored'."""
        result = mcp_server.contribute_experience(
            situation="test situation for contribute",
            solution="test solution",
            outcome_type="solved",
            lessons="test lessons",
            domain="coding",
            task_type="debugging",
        )
        assert isinstance(result, dict)
        assert "experience_id" in result
        assert result["experience_id"] == _TEST_CONTRIBUTE_RESPONSE["experience_id"]
        assert result["status"] == _TEST_CONTRIBUTE_RESPONSE["status"]
        # Verify contribute was called with correct data
        call_args = mock_contribute.call_args
        data = call_args[0][0]
        assert data["situation"] == "test situation for contribute"
        assert data["solution"] == "test solution"
        assert data["outcome_type"] == "solved"

    @patch("agxp.mcp.server._contribute_remote", return_value=_TEST_CONTRIBUTE_RESPONSE)
    def test_contribute_with_all_optional_fields(self, mock_contribute):
        """All optional fields are correctly passed to API."""
        result = mcp_server.contribute_experience(
            situation="full experience with all fields",
            solution="comprehensive solution here",
            outcome_type="workaround",
            lessons="always fill all fields for completeness",
            domain="devops",
            task_type="infrastructure",
            language="zh",
            failed_approaches="tried approach A, failed because of X",
            environment={"os": "linux", "python": "3.11"},
            subdomain="kubernetes",
            tags=["docker", "k8s", "deployment"],
        )

        # Verify all parameters are sent to API
        call_args = mock_contribute.call_args
        data = call_args[0][0]
        assert data["situation"] == "full experience with all fields"
        assert data["solution"] == "comprehensive solution here"
        assert data["outcome_type"] == "workaround"
        assert data["lessons"] == "always fill all fields for completeness"
        assert data["domain"] == "devops"
        assert data["task_type"] == "infrastructure"
        assert data["language"] == "zh"
        assert data["failed_approaches"] == "tried approach A, failed because of X"
        assert data["environment"] == {"os": "linux", "python": "3.11"}
        assert data["subdomain"] == "kubernetes"
        assert data["tags"] == ["docker", "k8s", "deployment"]

    @patch("agxp.mcp.server._contribute_remote", return_value=_TEST_CONTRIBUTE_RESPONSE)
    def test_contribute_with_minimal_fields(self, mock_contribute):
        """Only required fields, all optional fields omitted."""
        result = mcp_server.contribute_experience(
            situation="minimal required fields only",
            solution="minimal solution",
            outcome_type="unresolved",
            lessons="minimal lesson",
            domain="coding",
            task_type="debugging",
        )

        call_args = mock_contribute.call_args
        data = call_args[0][0]
        # Required fields present
        assert all(key in data for key in ["situation", "solution", "outcome_type", "lessons", "domain", "task_type"])
        # Optional fields not present when omitted
        assert "failed_approaches" not in data
        assert "environment" not in data
        assert "subdomain" not in data
        assert "tags" not in data

# ============================================================================
# contribute_experience — Error Cases
# ============================================================================
class TestContributeErrors:
    """contribute_experience validates input per contract before calling API."""

    @patch("agxp.mcp.server._contribute_remote")
    def test_invalid_outcome_type_raises_error(self, mock_contribute):
        """outcome_type must be solved/workaround/unresolved; anything else raises."""
        with pytest.raises(ValueError, match="Invalid outcome_type"):
            mcp_server.contribute_experience(
                situation="bad outcome test",
                solution="some solution",
                outcome_type="invalid_type",
                lessons="lesson",
                domain="coding",
                task_type="debugging",
            )
        # Verify contribute was never called (validation happens before API call)
        mock_contribute.assert_not_called()

    @patch("agxp.mcp.server._contribute_remote")
    def test_invalid_outcome_type_partial_match_raises(self, mock_contribute):
        """Partial matches like 'solve' (instead of 'solved') must also raise."""
        with pytest.raises(ValueError, match="Invalid outcome_type"):
            mcp_server.contribute_experience(
                situation="partial outcome test",
                solution="some solution",
                outcome_type="solve",
                lessons="lesson",
                domain="coding",
                task_type="debugging",
            )
        # Verify contribute was never called
        mock_contribute.assert_not_called()

# ============================================================================
# report_feedback — Tests
# ============================================================================
class TestReportFeedback:
    """report_feedback sends feedback to remote API."""

    @patch("agxp.mcp.server._send_remote_feedback", return_value=_TEST_FEEDBACK_RESPONSE)
    def test_feedback_useful_returns_correct_response(self, mock_feedback):
        """Feedback with useful=True returns expected response."""
        result = mcp_server.report_feedback(
            experience_id="test-uuid-12345",
            useful=True
        )
        assert isinstance(result, dict)
        assert result["experience_id"] == _TEST_FEEDBACK_RESPONSE["experience_id"]
        assert result["quality_score"] == _TEST_FEEDBACK_RESPONSE["quality_score"]
        assert result["status"] == _TEST_FEEDBACK_RESPONSE["status"]
        # Verify feedback was called with correct parameters
        mock_feedback.assert_called_once_with("test-uuid-12345", True)

    @patch("agxp.mcp.server._send_remote_feedback", return_value=_TEST_FEEDBACK_RESPONSE)
    def test_feedback_not_useful_sends_correct_parameter(self, mock_feedback):
        """Feedback with useful=False sends correct value to API."""
        result = mcp_server.report_feedback(
            experience_id="test-uuid-12345",
            useful=False
        )
        mock_feedback.assert_called_once_with("test-uuid-12345", False)

    @patch("agxp.mcp.server._send_remote_feedback", side_effect=Exception("API error"))
    def test_feedback_api_error_raises(self, mock_feedback):
        """API errors should raise ValueError with error message."""
        with pytest.raises(ValueError, match="Failed to submit feedback"):
            mcp_server.report_feedback(
                experience_id="test-uuid-12345",
                useful=True
            )
