"""
Tests for QualityScoreWriter ABC and InlineQualityWriter default implementation.

Kept tests:
- test_quality_writer_is_abstract: QualityScoreWriter cannot be instantiated directly
- test_inline_quality_writer_is_subclass: InlineQualityWriter is registered subclass
- test_inline_quality_writer_instantiates: InlineQualityWriter() constructs without error

Removed (were testing stub/NotImplementedError behaviour that no longer applies
after Issue #7 full implementation):
- test_update_score_raises_not_implemented
- test_recompute_score_raises_not_implemented
"""

import pytest

from agxp.services.inline_quality_writer import InlineQualityWriter
from agxp.services.quality_score_writer import QualityScoreWriter


def test_quality_writer_is_abstract():
    """QualityScoreWriter is an ABC and must not be directly instantiable."""
    with pytest.raises(TypeError):
        QualityScoreWriter()  # type: ignore[abstract]


def test_inline_quality_writer_is_subclass():
    """InlineQualityWriter must be a proper subclass of QualityScoreWriter."""
    assert issubclass(InlineQualityWriter, QualityScoreWriter)


def test_inline_quality_writer_instantiates():
    """InlineQualityWriter() must construct without raising."""
    writer = InlineQualityWriter()
    assert writer is not None
