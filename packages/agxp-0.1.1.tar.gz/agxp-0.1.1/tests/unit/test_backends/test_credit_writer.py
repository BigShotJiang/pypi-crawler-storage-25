"""
Tests for CreditWriter ABC and PostgresCreditWriter default implementation.
"""

import pytest

from agxp.services.credit_writer import CreditWriter
from agxp.services.postgres_credit_writer import PostgresCreditWriter


def test_credit_writer_is_abstract():
    with pytest.raises(TypeError):
        CreditWriter()


def test_postgres_credit_writer_is_subclass():
    assert issubclass(PostgresCreditWriter, CreditWriter)


def test_postgres_credit_writer_instantiates():
    writer = PostgresCreditWriter()
    assert writer is not None


