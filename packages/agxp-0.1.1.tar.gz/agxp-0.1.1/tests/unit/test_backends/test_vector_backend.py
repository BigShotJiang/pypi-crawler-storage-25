"""
Tests for VectorSearchBackend ABC and PgvectorBackend subclass registration.
"""

import pytest

from agxp.search.backends.pgvector_backend import PgvectorBackend
from agxp.search.backends.vector_backend import VectorSearchBackend


def test_vector_backend_is_abstract():
    with pytest.raises(TypeError):
        VectorSearchBackend()


def test_pgvector_backend_is_subclass():
    assert issubclass(PgvectorBackend, VectorSearchBackend)


def test_pgvector_backend_instantiates():
    backend = PgvectorBackend()
    assert backend is not None
