"""
Tests for EmbeddingBackend ABC and BgeM3ApiBackend default implementation.
"""

import pytest

from agxp.search.backends.bgem3_api_backend import BgeM3ApiBackend
from agxp.search.backends.embedding_backend import EmbeddingBackend


def test_embedding_backend_is_abstract():
    with pytest.raises(TypeError):
        EmbeddingBackend()


def test_bgem3_backend_is_subclass():
    assert issubclass(BgeM3ApiBackend, EmbeddingBackend)


def test_bgem3_backend_instantiates():
    backend = BgeM3ApiBackend()
    assert backend is not None


def test_bgem3_dimensions_is_1024():
    backend = BgeM3ApiBackend()
    assert backend.dimensions == 1024


def test_bgem3_max_tokens_is_positive():
    backend = BgeM3ApiBackend()
    assert backend.max_tokens > 0


@pytest.mark.asyncio
async def test_bgem3_embed_makes_api_request():
    # Test that embed method makes proper API request (mock HTTP call)
    backend = BgeM3ApiBackend()

    # Mock response matching OpenAI embedding format
    mock_response_data = {
        "data": [
            {"embedding": [0.1] * 1024},
            {"embedding": [0.2] * 1024}
        ]
    }

    with pytest.MonkeyPatch.context() as mp:
        called_url = None
        called_payload = None

        async def mock_post(self, url, *args, **kwargs):
            nonlocal called_url, called_payload
            called_url = url
            called_payload = kwargs.get("json", {})

            mock_resp = type('MockResponse', (object,), {
                'status_code': 200,
                'json': lambda *args, **kwargs: mock_response_data,
                'raise_for_status': lambda *args: None
            })()
            return mock_resp

        mp.setattr("httpx.AsyncClient.post", mock_post)

        # Call embed method
        result = await backend.embed(texts=["hello", "world"])

        # Verify request was made correctly
        assert called_url == "https://example.com/v1/embeddings"
        assert called_payload["input"] == ["hello", "world"]
        assert called_payload["model"] == "BAAI/bge-m3"

        # Verify result format
        assert len(result) == 2
        assert len(result[0]) == 1024
        assert len(result[1]) == 1024
