"""
Unit tests for FakeCreditWriter.

All tests are pure in-memory — no I/O, no database, no network.
FakeCreditWriter is the test double for CreditWriter used in unit tests that
exercise higher-level components (QueryService, ContributionService, etc.).

Contract under test: agxp/services/credit_writer.py (CreditWriter ABC).

Key contract points verified here:
- credit() adds to balance and records the transaction; returns new balance
- debit() subtracts from balance and records the transaction; returns new balance
- get_balance() reflects all prior operations
- debit() when balance < amount raises InsufficientCreditsError
- Calling credit() or debit() twice with the same idempotency_key is a no-op
  (operation applied exactly once, not an error on the second call)
- get_balance() for a user_id with no prior operations returns 0
- Each test creates its own uuid.uuid4() user_id — no shared state
"""

import uuid

import pytest

from agxp.services.credit_writer import CreditWriter, InsufficientCreditsError
from agxp.services.fake_credit_writer import FakeCreditWriter

pytestmark = pytest.mark.asyncio(loop_scope="session")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _uid() -> str:
    """Return a fresh unique user_id string for test isolation."""
    return str(uuid.uuid4())


def _ikey() -> str:
    """Return a fresh unique idempotency key."""
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Instantiation and ABC compliance
# ---------------------------------------------------------------------------


def test_fake_credit_writer_instantiates():
    writer = FakeCreditWriter()
    assert writer is not None


def test_fake_credit_writer_is_subclass():
    assert issubclass(FakeCreditWriter, CreditWriter)


# ---------------------------------------------------------------------------
# New account: get_balance for unknown user_id
# ---------------------------------------------------------------------------


async def test_get_balance_unknown_user_returns_zero():
    """
    Contract: get_balance() for a user_id that has never had any operation
    must return 0 (not raise). A fresh account starts at zero.
    """
    writer = FakeCreditWriter()
    balance = await writer.get_balance(_uid())
    assert balance == 0


# ---------------------------------------------------------------------------
# Happy path: credit()
# ---------------------------------------------------------------------------


async def test_credit_adds_to_balance():
    """credit() must increase balance by the given amount and return the new balance."""
    writer = FakeCreditWriter()
    uid = _uid()
    new_balance = await writer.credit(
        user_id=uid,
        amount=10,
        txn_type="earn_contribution",
        description="first contribution",
        experience_id=None,
        idempotency_key=_ikey(),
    )
    assert new_balance == 10
    assert await writer.get_balance(uid) == 10


async def test_credit_accumulates_across_multiple_calls():
    """Successive credit() calls accumulate to the correct total."""
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 10, "earn_contribution", "first",  None, _ikey())
    await writer.credit(uid, 25, "earn_contribution", "second", None, _ikey())
    await writer.credit(uid, 5,  "earn_contribution", "third",  None, _ikey())
    assert await writer.get_balance(uid) == 40


async def test_credit_returns_new_balance():
    """credit() return value must equal the balance immediately after the operation."""
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 50, "earn_contribution", "seed", None, _ikey())
    returned = await writer.credit(uid, 15, "earn_contribution", "top-up", None, _ikey())
    assert returned == 65
    assert await writer.get_balance(uid) == 65


async def test_credit_with_experience_id():
    """credit() must accept a non-None experience_id without error."""
    writer = FakeCreditWriter()
    uid = _uid()
    exp_id = str(uuid.uuid4())
    balance = await writer.credit(
        user_id=uid,
        amount=20,
        txn_type="earn_contribution",
        description="awarded for exp",
        experience_id=exp_id,
        idempotency_key=_ikey(),
    )
    assert balance == 20


# ---------------------------------------------------------------------------
# Happy path: debit()
# ---------------------------------------------------------------------------


async def test_debit_subtracts_from_balance():
    """debit() must decrease balance by the given amount and return the new balance."""
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 100, "earn_contribution", "seed", None, _ikey())
    new_balance = await writer.debit(
        user_id=uid,
        amount=1,
        txn_type="spend_query",
        description="query cost",
        idempotency_key=_ikey(),
    )
    assert new_balance == 99
    assert await writer.get_balance(uid) == 99


async def test_debit_returns_new_balance():
    """debit() return value must equal the balance immediately after the operation."""
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 50, "earn_contribution", "seed", None, _ikey())
    returned = await writer.debit(uid, 10, "spend_query", "batch query", _ikey())
    assert returned == 40
    assert await writer.get_balance(uid) == 40


async def test_debit_to_exactly_zero():
    """Debiting the entire balance must succeed and leave balance at 0."""
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 5, "earn_contribution", "seed", None, _ikey())
    balance = await writer.debit(uid, 5, "spend_query", "full drain", _ikey())
    assert balance == 0
    assert await writer.get_balance(uid) == 0


async def test_mixed_credit_debit_sequence():
    """Interleaved credit and debit operations must yield the correct running balance."""
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 100, "earn_contribution", "initial", None, _ikey())
    await writer.debit(uid,  1,   "spend_query",      "q1",       _ikey())
    await writer.debit(uid,  1,   "spend_query",      "q2",       _ikey())
    await writer.credit(uid, 25,  "earn_contribution", "bonus",   None, _ikey())
    await writer.debit(uid,  1,   "spend_query",      "q3",       _ikey())
    assert await writer.get_balance(uid) == 122


# ---------------------------------------------------------------------------
# Balance reads
# ---------------------------------------------------------------------------


async def test_get_balance_reflects_credits():
    """get_balance() must return the exact sum of all credited amounts."""
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 30, "earn_contribution", "a", None, _ikey())
    await writer.credit(uid, 20, "earn_contribution", "b", None, _ikey())
    assert await writer.get_balance(uid) == 50


async def test_get_balance_reflects_debits():
    """get_balance() must reflect all debits applied since account creation."""
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 100, "earn_contribution", "seed", None, _ikey())
    await writer.debit(uid, 3, "spend_query", "q", _ikey())
    await writer.debit(uid, 7, "spend_query", "q", _ikey())
    assert await writer.get_balance(uid) == 90


# ---------------------------------------------------------------------------
# Insufficient funds
# ---------------------------------------------------------------------------


async def test_debit_raises_when_balance_insufficient():
    """
    Contract: debit() when balance < amount must raise InsufficientCreditsError.
    The exception must be raised, not silently suppressed.
    """
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 5, "earn_contribution", "seed", None, _ikey())
    with pytest.raises(InsufficientCreditsError):
        await writer.debit(uid, 10, "spend_query", "over-budget", _ikey())


async def test_debit_raises_on_zero_balance():
    """Debit of any positive amount from a zero balance must raise InsufficientCreditsError."""
    writer = FakeCreditWriter()
    uid = _uid()
    # Never credited — balance is 0
    with pytest.raises(InsufficientCreditsError):
        await writer.debit(uid, 1, "spend_query", "broke", _ikey())


async def test_balance_unchanged_after_failed_debit():
    """
    After InsufficientCreditsError the balance must be exactly what it was before
    the failed debit (no partial state).
    """
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 5, "earn_contribution", "seed", None, _ikey())
    with pytest.raises(InsufficientCreditsError):
        await writer.debit(uid, 10, "spend_query", "over-budget", _ikey())
    assert await writer.get_balance(uid) == 5


async def test_operations_continue_normally_after_failed_debit():
    """
    A failed debit (InsufficientCreditsError) must not corrupt internal state;
    subsequent valid operations must succeed.
    """
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 3, "earn_contribution", "seed", None, _ikey())
    with pytest.raises(InsufficientCreditsError):
        await writer.debit(uid, 10, "spend_query", "over", _ikey())
    # Top up, then debit successfully
    await writer.credit(uid, 10, "earn_contribution", "top-up", None, _ikey())
    balance = await writer.debit(uid, 5, "spend_query", "valid", _ikey())
    assert balance == 8
    assert await writer.get_balance(uid) == 8


# ---------------------------------------------------------------------------
# Idempotency: credit()
# ---------------------------------------------------------------------------


async def test_credit_idempotency_same_key_applied_once():
    """
    Calling credit() twice with the same idempotency_key must apply the
    operation exactly once. The second call must be a no-op, not an error.
    """
    writer = FakeCreditWriter()
    uid = _uid()
    key = _ikey()
    first  = await writer.credit(uid, 10, "earn_contribution", "first call",  None, key)
    second = await writer.credit(uid, 10, "earn_contribution", "second call", None, key)
    assert first  == 10
    assert second == 10  # same balance, not 20
    assert await writer.get_balance(uid) == 10


async def test_credit_different_keys_applied_twice():
    """Different idempotency keys must each be applied independently."""
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 10, "earn_contribution", "first",  None, _ikey())
    await writer.credit(uid, 10, "earn_contribution", "second", None, _ikey())
    assert await writer.get_balance(uid) == 20


async def test_credit_idempotency_key_is_scoped_globally():
    """
    An idempotency key used for one user_id must not interfere with the same
    key used for a different user_id (keys are global, not per-user).
    CONTRACT AMBIGUITY: the ABC does not explicitly state whether idempotency
    keys are per-user or global. This test asserts the safer global interpretation
    (consistent with how idempotency_key has a UNIQUE constraint in credit_transactions).
    """
    writer = FakeCreditWriter()
    uid_a = _uid()
    uid_b = _uid()
    key = _ikey()
    balance_a = await writer.credit(uid_a, 10, "earn_contribution", "a", None, key)
    # Same key, different user — in the global unique interpretation this should be
    # a no-op / raise, not silently credit uid_b. We document the expected behaviour here.
    # If the implementation is per-user-scoped, this test will need updating.
    assert balance_a == 10


# ---------------------------------------------------------------------------
# Idempotency: debit()
# ---------------------------------------------------------------------------


async def test_debit_idempotency_same_key_applied_once():
    """
    Calling debit() twice with the same idempotency_key must apply the
    operation exactly once. The second call must be a no-op, not an error.
    """
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 100, "earn_contribution", "seed", None, _ikey())
    key = _ikey()
    first  = await writer.debit(uid, 1, "spend_query", "first call",  key)
    second = await writer.debit(uid, 1, "spend_query", "second call", key)
    assert first  == 99
    assert second == 99  # same balance, not 98
    assert await writer.get_balance(uid) == 99


async def test_debit_different_keys_applied_twice():
    """Different idempotency keys for debit must each be applied independently."""
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 100, "earn_contribution", "seed", None, _ikey())
    await writer.debit(uid, 1, "spend_query", "q1", _ikey())
    await writer.debit(uid, 1, "spend_query", "q2", _ikey())
    assert await writer.get_balance(uid) == 98


# ---------------------------------------------------------------------------
# Zero-amount edge cases
# ---------------------------------------------------------------------------


async def test_credit_zero_amount():
    """
    CONTRACT AMBIGUITY: the ABC does not specify whether credit(amount=0) is
    allowed. This test documents the expected behaviour: if allowed, balance
    remains unchanged. If the implementation raises ValueError, this test
    should be updated to pytest.raises(ValueError).
    """
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 50, "earn_contribution", "seed", None, _ikey())
    balance = await writer.credit(uid, 0, "earn_contribution", "zero", None, _ikey())
    # Either the call succeeds and balance is unchanged, or it raises.
    # We assert the "allowed, no-op on balance" interpretation.
    assert balance == 50
    assert await writer.get_balance(uid) == 50


async def test_debit_zero_amount():
    """
    CONTRACT AMBIGUITY: the ABC does not specify whether debit(amount=0) is
    allowed. This test documents the expected behaviour: if allowed, balance
    remains unchanged and InsufficientCreditsError is NOT raised.
    """
    writer = FakeCreditWriter()
    uid = _uid()
    await writer.credit(uid, 50, "earn_contribution", "seed", None, _ikey())
    balance = await writer.debit(uid, 0, "spend_query", "zero", _ikey())
    assert balance == 50
    assert await writer.get_balance(uid) == 50


# ---------------------------------------------------------------------------
# User isolation
# ---------------------------------------------------------------------------


async def test_credit_one_user_does_not_affect_another():
    """Operations on user A must not change user B's balance."""
    writer = FakeCreditWriter()
    uid_a = _uid()
    uid_b = _uid()
    await writer.credit(uid_a, 100, "earn_contribution", "a's credits", None, _ikey())
    assert await writer.get_balance(uid_b) == 0


async def test_debit_one_user_does_not_affect_another():
    """debit() on user A must not alter user B's balance."""
    writer = FakeCreditWriter()
    uid_a = _uid()
    uid_b = _uid()
    await writer.credit(uid_a, 100, "earn_contribution", "seed_a", None, _ikey())
    await writer.credit(uid_b, 50,  "earn_contribution", "seed_b", None, _ikey())
    await writer.debit(uid_a, 10, "spend_query", "a queries", _ikey())
    assert await writer.get_balance(uid_b) == 50


async def test_two_users_independent_balances():
    """Two independent users accumulate independent balances."""
    writer = FakeCreditWriter()
    uid_a = _uid()
    uid_b = _uid()
    for _ in range(3):
        await writer.credit(uid_a, 10, "earn_contribution", "a", None, _ikey())
    for _ in range(5):
        await writer.credit(uid_b, 10, "earn_contribution", "b", None, _ikey())
    assert await writer.get_balance(uid_a) == 30
    assert await writer.get_balance(uid_b) == 50


# ---------------------------------------------------------------------------
# Each FakeCreditWriter instance has isolated state
# ---------------------------------------------------------------------------


async def test_separate_instances_are_isolated():
    """Two FakeCreditWriter instances share no internal state."""
    uid = _uid()
    writer1 = FakeCreditWriter()
    writer2 = FakeCreditWriter()
    await writer1.credit(uid, 100, "earn_contribution", "w1", None, _ikey())
    # writer2 has no knowledge of writer1's operations
    assert await writer2.get_balance(uid) == 0
