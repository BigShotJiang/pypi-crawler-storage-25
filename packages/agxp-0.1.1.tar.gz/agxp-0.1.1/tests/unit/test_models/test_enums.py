"""Unit tests for database enums."""
import pytest


def test_outcome_type_enum_values():
    from agxp.db.models import OutcomeType

    assert set(e.value for e in OutcomeType) == {"solved", "workaround", "unresolved"}


def test_outcome_type_has_exactly_three_values():
    from agxp.db.models import OutcomeType

    assert len(OutcomeType) == 3
