"""Unit tests for User, ApiKey, AnonymousSession models."""


def test_user_model_has_required_columns():
    from agxp.db.models import User

    cols = {c.name for c in User.__table__.columns}
    assert {"id", "email", "github_id", "display_name", "created_at", "is_active"} <= cols


def test_user_email_is_nullable():
    from agxp.db.models import User

    col = User.__table__.columns["email"]
    assert col.nullable is True


def test_user_is_active_defaults_true():
    from agxp.db.models import User

    col = User.__table__.columns["is_active"]
    assert col.default.arg is True


def test_api_key_has_required_columns():
    from agxp.db.models import ApiKey

    cols = {c.name for c in ApiKey.__table__.columns}
    assert {"id", "user_id", "key_hash", "label", "last_used_at", "revoked_at", "created_at"} <= cols


def test_api_key_user_id_is_foreign_key():
    from agxp.db.models import ApiKey

    fks = {fk.column.table.name for fk in ApiKey.__table__.foreign_keys}
    assert "users" in fks


def test_api_key_hash_is_unique():
    from agxp.db.models import ApiKey

    col = ApiKey.__table__.columns["key_hash"]
    assert col.unique


def test_anonymous_session_has_required_columns():
    from agxp.db.models import AnonymousSession

    cols = {c.name for c in AnonymousSession.__table__.columns}
    assert {
        "id", "temp_key_hash", "query_count", "credit_balance",
        "created_at", "expires_at", "merged_into_user_id",
    } <= cols


def test_anonymous_session_credit_balance_default_20():
    from agxp.db.models import AnonymousSession

    col = AnonymousSession.__table__.columns["credit_balance"]
    assert col.default.arg == 20


def test_anonymous_session_query_count_default_0():
    from agxp.db.models import AnonymousSession

    col = AnonymousSession.__table__.columns["query_count"]
    assert col.default.arg == 0
