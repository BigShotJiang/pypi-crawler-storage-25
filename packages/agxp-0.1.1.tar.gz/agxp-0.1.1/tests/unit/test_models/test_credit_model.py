"""Unit tests for CreditAccount and CreditTransaction models."""


def test_credit_account_uses_user_id_not_agent_id():
    from agxp.db.models import CreditAccount

    cols = {c.name for c in CreditAccount.__table__.columns}
    assert "user_id" in cols
    assert "agent_id" not in cols


def test_credit_account_has_pending_balance():
    from agxp.db.models import CreditAccount

    cols = {c.name for c in CreditAccount.__table__.columns}
    assert "pending_balance" in cols


def test_credit_account_user_id_is_unique():
    from agxp.db.models import CreditAccount
    from sqlalchemy import UniqueConstraint

    col = CreditAccount.__table__.columns["user_id"]
    has_unique = col.unique or any(
        isinstance(c, UniqueConstraint) and "user_id" in [cc.name for cc in c.columns]
        for c in CreditAccount.__table__.constraints
    )
    assert has_unique


def test_credit_account_balance_default_zero():
    from agxp.db.models import CreditAccount

    col = CreditAccount.__table__.columns["balance"]
    assert col.default.arg == 0


def test_credit_transaction_has_idempotency_key():
    from agxp.db.models import CreditTransaction

    cols = {c.name for c in CreditTransaction.__table__.columns}
    assert "idempotency_key" in cols


def test_credit_transaction_has_reference_type():
    from agxp.db.models import CreditTransaction

    cols = {c.name for c in CreditTransaction.__table__.columns}
    assert "reference_type" in cols


def test_credit_transaction_idempotency_key_is_unique():
    from agxp.db.models import CreditTransaction

    col = CreditTransaction.__table__.columns["idempotency_key"]
    assert col.unique or col.nullable  # unique when set, nullable for backward compat


def test_quality_vote_uses_voter_user_id():
    from agxp.db.models import QualityVote

    cols = {c.name for c in QualityVote.__table__.columns}
    assert "voter_user_id" in cols
    assert "voter_agent_id" not in cols


def test_search_feedback_model_exists():
    from agxp.db.models import SearchFeedback

    cols = {c.name for c in SearchFeedback.__table__.columns}
    assert {"id", "query_log_id", "experience_id", "position", "was_useful"} <= cols


def test_query_log_user_id_is_nullable():
    from agxp.db.models import QueryLog

    col = QueryLog.__table__.columns["user_id"]
    assert col.nullable is True
