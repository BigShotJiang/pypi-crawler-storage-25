"""Unit tests for Experience and ExperienceTranslation models."""

EMBEDDING_FIELDS = [
    "embedding_situation",
    "embedding_solution",
    "embedding_lessons",
    "embedding_failed",
    "embedding_tags",
    "embedding_environment",
]

QUALITY_COMPONENT_FIELDS = ["uniqueness_score", "completeness_score", "community_score"]

CONTENT_FIELDS = [
    "situation", "failed_approaches", "solution",
    "outcome_type", "lessons", "environment",
]


def test_experience_has_content_fields():
    from agxp.db.models import Experience

    cols = {c.name for c in Experience.__table__.columns}
    assert set(CONTENT_FIELDS) <= cols


def test_experience_has_no_old_approach_field():
    from agxp.db.models import Experience

    cols = {c.name for c in Experience.__table__.columns}
    assert "approach" not in cols
    assert "outcome" not in cols


def test_experience_has_six_embedding_fields():
    from agxp.db.models import Experience

    cols = {c.name for c in Experience.__table__.columns}
    assert set(EMBEDDING_FIELDS) <= cols


def test_experience_has_quality_component_fields():
    from agxp.db.models import Experience

    cols = {c.name for c in Experience.__table__.columns}
    assert set(QUALITY_COMPONENT_FIELDS) <= cols


def test_experience_quality_score_default_is_zero():
    from agxp.db.models import Experience

    col = Experience.__table__.columns["quality_score"]
    assert col.default.arg == 0.0


def test_experience_failed_approaches_is_nullable():
    from agxp.db.models import Experience

    col = Experience.__table__.columns["failed_approaches"]
    assert col.nullable is True


def test_experience_solution_is_not_nullable():
    from agxp.db.models import Experience

    col = Experience.__table__.columns["solution"]
    assert col.nullable is False


def test_experience_user_id_references_users():
    from agxp.db.models import Experience

    fks = {fk.column.table.name for fk in Experience.__table__.foreign_keys}
    assert "users" in fks


def test_experience_has_translation_status():
    from agxp.db.models import Experience

    cols = {c.name for c in Experience.__table__.columns}
    assert "translation_status" in cols


def test_experience_translation_has_unique_constraint():
    from agxp.db.models import ExperienceTranslation
    from sqlalchemy import UniqueConstraint

    constraints = {type(c) for c in ExperienceTranslation.__table__.constraints}
    assert UniqueConstraint in constraints


def test_experience_translation_has_required_columns():
    from agxp.db.models import ExperienceTranslation

    cols = {c.name for c in ExperienceTranslation.__table__.columns}
    assert {"id", "experience_id", "language", "situation", "solution", "lessons"} <= cols
