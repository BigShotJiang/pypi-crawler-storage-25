"""
Shared pytest fixtures for all test levels.
Integration and performance fixtures are added in Issue #2+.
"""


# ---------------------------------------------------------------------------
# Markers
# ---------------------------------------------------------------------------


def pytest_configure(config):
    config.addinivalue_line("markers", "unit: pure logic tests, no I/O")
    config.addinivalue_line("markers", "integration: requires PostgreSQL + Redis")
    config.addinivalue_line("markers", "performance: latency and throughput benchmarks")
    config.addinivalue_line("markers", "compatibility: cross-version and cross-OS tests")
