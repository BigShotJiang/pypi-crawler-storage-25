# AGXP — Claude Code Context
> This file is auto-loaded by Claude Code on every session. It is the single source of truth for onboarding a new agent into this project.

---

## Project Summary
AGXP is an AI agent experience-sharing tool — a searchable knowledge base where coding agents record and query reusable problem-solving experiences. The project uses a pure client-server architecture with no local database capabilities.

Two install tiers:
- **Base Client** (`pip install agxp`): Full client functionality including CLI commands, MCP server, and Claude Skill support (~5MB). No server dependencies.
- **Server** (`pip install agxp[server]`): Full server stack for self-hosting. Includes FastAPI, asyncpg, celery, redis, embedding models, etc.

**Repo:** https://github.com/morningwilliam-byte/agxp
**Working directory:** `/Users/cy/Documents/xvc/agxp`
**Active branch:** `main`

---

## Current Status (as of 2026-04-16)
### ✅ Completed Features
1. **Full Server Implementation**
   - Complete REST API with authentication, search, contribution, and feedback endpoints
   - Hybrid search: pgvector semantic search + Tantivy full-text search with RRF fusion
   - CrossEncoder reranking for optimal result relevance
   - Automatic quality scoring and credit reward system
   - Github OAuth authentication with anonymous session support
   - Production-grade async architecture with Celery workers and Redis caching
   - 700+ test suite (unit + integration)

2. **Full Client Implementation**
   - Complete CLI toolchain: `login`/`query`/`contribute`/`feedback`/`status`/`mcp`/`hook`
   - Structured JSON output support for all commands (default) with human-readable option
   - MCP server implementation compatible with Claude Code/Cursor, providing 3 native tools
   - Claude Skill configuration files for zero-MCP integration
   - Automatic anonymous session creation for unauthenticated users
   - No local database or state storage beyond authentication tokens

3. **DevOps Tools**
   - Cold start data import scripts: batch import JSONL experience data
   - System user creation script for data import and admin operations
   - One-click seed data loading shell script

### 🔄 Planned Features
| Issue | Content | Status |
|-------|---------|--------|
| #25 | Auto-feedback: search_log + pending feedback prompts | In progress |
| #26 | Server-side automatic feedback mechanism | Planned |
| #27 | Multi-source cascade search (public + private libraries) | Planned |

---

## Tech Stack

### Client Side
- Python 3.11
- Typer (CLI framework)
- FastMCP (MCP server implementation)
- No local database, no embedded models
- All operations call remote HTTPS API
- Config stored at `~/.agxp/config.json` (only authentication tokens)

### Server Side
- Python 3.11 + asyncio
- FastAPI + Uvicorn (async HTTP server)
- asyncpg (raw PostgreSQL client, no ORM at runtime)
- PostgreSQL 16 + pgvector 0.7 (HNSW index for 1024-dim vector search)
- Tantivy 0.25 (Rust-based full-text search engine)
- Celery + Redis 7.2 (async workers + query cache)
- BAAI/bge-m3 (multilingual embedding model, 1024-dim)
- MiniLM-L6-v2 (cross-encoder for result reranking)
- Alembic (database migrations)
- passlib / bcrypt (password/token hashing)

---

## Core Client Commands
All commands support structured JSON output by default, use `--no-json` for human-readable format:
- `agxp login`: Authenticate with Github OAuth, automatically opens browser and stores token locally
- `agxp query <query> [--domain <domain>] [--task-type <type>] [--limit <n>] [--json]`: Search experience knowledge base
- `agxp contribute --situation <text> --solution <text> --outcome-type <solved|workaround|unresolved> --lessons <text> --domain <domain> --task-type <type> [other optional flags]`: Submit new experience
- `agxp feedback --experience-id <id> --useful/--not-useful`: Rate experience usefulness
- `agxp status`: Show server status, account information, credit balance, and available commands
- `agxp mcp`: Start MCP server (stdio transport) for Claude Code/Cursor integration
- `agxp hook`: Claude Code hook for automatic experience recording during coding sessions

---

## MCP Server Tools
The MCP server implements Model Context Protocol standard, exposing three native tools:
1. `search_experiences(query: str, domain?: str, task_type?: str, limit?: int) -> dict`: Search knowledge base for pre-validated solutions. Use when encountering errors, unexpected behavior, or before retrying failed approaches.
2. `contribute_experience(situation: str, solution: str, outcome_type: str, lessons: str, domain: str, task_type: str, ...) -> dict`: Contribute new experience to the knowledge base. Use at the end of tasks when discovering non-obvious solutions.
3. `report_feedback(experience_id: str, useful: bool) -> dict`: Report whether an experience was useful after attempting the solution. Helps improve search quality over time.

---

## Architecture: Pure Client-Server Model
All intelligence and data storage runs on the server, clients are thin stateless wrappers around the public API. There is no local data storage or processing beyond what is necessary for API communication.

### Key Architecture Decisions
1. **CLI-First Design**: All functionality is exposed via CLI first, with structured output for machine consumption
2. **Dual Integration Support**: Both MCP server and Claude Skill integration methods provide identical functionality
3. **Stateless Clients**: No local state except authentication tokens, all data resides on the server
4. **Centralized Search & Scoring**: All search, ranking, and quality scoring logic runs on the server for consistency
5. **Async Server**: Built for high concurrency to handle thousands of simultaneous agent requests
6. **Hybrid Search**: Combines semantic vector search and keyword full-text search for optimal relevance
7. **Automatic Quality Scoring**: No manual curation required, quality is scored automatically and updated via user feedback

---

## Development Workflow (MANDATORY)
### Steps 0–1, 2b, 5 require human involvement. Other steps are automated.
0. **Pre-flight check**: `/preflight #N` — verify required docs exist, skills available, execution plan matches hard constraints.
1. **Environment check**: confirm with user: permissions, tools, infrastructure ready, loop limit (default: 20 iterations / 20 minutes).
2a. **Design draft + `/design-check`**: read `HARNESS.md` + relevant design docs, draft design, then run `/design-check` to verify completeness (field mapping table, 10-category checklist). **MUST PASS before showing to user.** Fix all BLOCKING items first. **Loop run `/design-check` until PASS, max 10 times.**
2b. **Design review (human)**: generate Feishu document (with design summary, scope, file list, key decisions, field mapping table), provide Feishu link to user for review. Wait for user approval.
3. **Tester sub-agent**: `/tester #N`: reads ABCs and design docs ONLY, not implementation; writes tests. Prompt template: `docs/TESTER_PROMPT.md`
4. **Test Quality Checker**: `/test-quality-check <test files>`: independently audit test quality (universal rubric + project extended `docs/TEST_QUALITY_CHECKER_PROMPT.md`). Read only test files, not implementation. FAIL → send back to tester, max 3 loops.
5. **Human review of tests**: **STOP.** Generate Feishu document (with test file content, test count, coverage, quality checker report), provide Feishu link to user for review. Wait for user approval before proceeding.
6. **Backup + branch**: create temp dir backup of files to be modified; create feature branch
7. **Dev loop**: implement until all tests are green, within confirmed limits
8. **Code Review sub-agent**: `/review #N`: independent review, NEVER skip. Prompt template: `docs/CODE_REVIEW_PROMPT.md`
9. **DEV_LOG update**: append session decisions and lessons to `docs/DEV_LOG.md`

---

## Sub-Agent Rules
- **Design check skill (Step 2a)**: `/design-check` — runs 10-category verification checklist, produces field mapping table, must PASS before human review. Max 10 loops.
- **Tester sub-agent (Step 3)**: reads contract docs and ABCs ONLY, not implementation — prevents confirmation bias in test writing
- **Test Quality Checker (Step 4)**: `/test-quality-check` skill — universal rubric + project extensions. Read only test files, FAIL → send back to tester, max 3 loops.
- **Code Review sub-agent (Step 8)**: reads all changed files against checklist — NEVER skip, NEVER self-review
- **Test execution**: NEVER run pytest directly in main agent. Always use `/run-tests` skill. Verify `collected_count == total_run`.

---

## Key Constraints (Always Check in Code Review)
### Client Side
- No local state storage beyond authentication tokens in `~/.agxp/config.json`
- All CLI commands must be stateless, no background processes
- All API errors must be properly formatted for both JSON and human-readable output
- Tokens must never be logged or printed in output, even in debug mode
- Client must maintain backward compatibility with older server API versions

### Server Side
1. **SQL Injection Prevention**:
   - Column names in dynamic queries must come from hardcoded whitelist only, never from user input
   - All values passed as positional parameters (asyncpg `$1`), never string-interpolated
2. **Async Correctness**:
   - No blocking I/O directly in event loop — use `run_in_executor` for CPU-bound or blocking operations
   - Never call `asyncio.run()` from inside an already running event loop
3. **Type Coercions**:
   - asyncpg returns `uuid.UUID` objects — must cast to `str()` before returning API responses
   - pgvector codec must be registered on pool initialization before any vector operations
4. **Tantivy 0.25 API Quirks**:
   - `doc["field"]` returns a list — always use `doc["field"][0]` to get the actual value
   - `parse_query(..., field_boosts=None)` raises exception — omit the kwarg entirely when no boosts needed
5. **Security**:
   - All API endpoints except `/health` and OAuth routes require valid Bearer token authentication
   - OAuth flow must use CSRF protection with random state stored in Redis
   - All tokens must be hashed before storage, never stored in plaintext
   - User input must be properly validated and sanitized to prevent injection attacks

---

## Roadmap
### Short Term (Next 30 Days)
- Issue #25: Auto-feedback with pending feedback prompts during search
- Skill store integration for one-click skill installation
- Experience export and sharing functionality
- Multi-organization support for enterprise deployments

### Long Term
- Issue #26: Server-side automatic feedback based on usage patterns
- Issue #27: Multi-source cascade search across public and private knowledge bases
- Agent-specific fine-tuning data generation from experience corpus
