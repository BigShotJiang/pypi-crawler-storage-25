"""
FastAPI auth dependency — Bearer token authentication.

Resolves a Bearer token into an AuthIdentity (registered user or anonymous
session).  DB helpers are module-level functions so unit tests can patch them
without touching DI machinery.
"""
from __future__ import annotations

import asyncio
import logging

from fastapi import Header, HTTPException

from agxp.auth.keys import parse_api_token, verify_secret
from agxp.auth.models import AuthIdentity

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Module-level patchable DB helpers
# ---------------------------------------------------------------------------


async def lookup_api_key(key_id: str) -> dict | None:
    """SELECT from api_keys by id.  Returns dict with user_id, key_hash, revoked_at."""
    from agxp.db.pool import get_pool

    pool = await get_pool()
    row = await pool.fetchrow(
        "SELECT id, user_id, key_hash, revoked_at FROM api_keys WHERE id = $1",
        key_id,
    )
    return dict(row) if row else None


async def touch_api_key(key_id: str) -> None:
    """UPDATE last_used_at — fire-and-forget, failure is non-fatal."""
    from agxp.db.pool import get_pool

    pool = await get_pool()
    await pool.execute(
        "UPDATE api_keys SET last_used_at = NOW() WHERE id = $1",
        key_id,
    )


async def lookup_anon_session(session_id: str) -> dict | None:
    """SELECT from anonymous_sessions by id."""
    from agxp.db.pool import get_pool

    pool = await get_pool()
    row = await pool.fetchrow(
        "SELECT id, temp_key_hash, expires_at, merged_into_user_id "
        "FROM anonymous_sessions WHERE id = $1",
        session_id,
    )
    return dict(row) if row else None


# ---------------------------------------------------------------------------
# FastAPI dependency
# ---------------------------------------------------------------------------

def _log_task_error(task: asyncio.Task) -> None:
    """Log exceptions from fire-and-forget tasks instead of silently dropping them."""
    if task.cancelled():
        return
    exc = task.exception()
    if exc is not None:
        logger.error("fire-and-forget task failed: %s", exc, exc_info=exc)


_UNAUTHORIZED = HTTPException(
    status_code=401,
    detail={"error": "unauthorized", "message": "Invalid or expired API key"},
)


async def require_auth(
    authorization: str | None = Header(None),
) -> AuthIdentity:
    """Resolve a Bearer token to an AuthIdentity or raise 401."""
    if not authorization or not authorization.startswith("Bearer "):
        raise _UNAUTHORIZED

    token = authorization[len("Bearer "):]
    parsed = parse_api_token(token)
    if parsed is None:
        raise _UNAUTHORIZED

    loop = asyncio.get_running_loop()

    if not parsed.is_anonymous:
        # Registered API key path
        row = await lookup_api_key(parsed.key_id)
        if row is None:
            raise _UNAUTHORIZED
        if row["revoked_at"] is not None:
            raise _UNAUTHORIZED

        valid = await loop.run_in_executor(
            None, verify_secret, parsed.secret_hex, row["key_hash"]
        )
        if not valid:
            raise _UNAUTHORIZED

        # Fire-and-forget last_used_at update
        task = asyncio.create_task(touch_api_key(str(row["id"])))
        task.add_done_callback(_log_task_error)

        return AuthIdentity(
            user_id=str(row["user_id"]),
            anon_session_id=None,
            is_anonymous=False,
        )
    else:
        # Anonymous session path
        row = await lookup_anon_session(parsed.key_id)
        if row is None:
            raise _UNAUTHORIZED
        if row["merged_into_user_id"] is not None:
            raise _UNAUTHORIZED

        from datetime import datetime, timezone

        if row["expires_at"].tzinfo is None:
            expires = row["expires_at"].replace(tzinfo=timezone.utc)
        else:
            expires = row["expires_at"]
        if expires <= datetime.now(timezone.utc):
            raise _UNAUTHORIZED

        valid = await loop.run_in_executor(
            None, verify_secret, parsed.secret_hex, row["temp_key_hash"]
        )
        if not valid:
            raise _UNAUTHORIZED

        return AuthIdentity(
            user_id=None,
            anon_session_id=str(row["id"]),
            is_anonymous=True,
        )
