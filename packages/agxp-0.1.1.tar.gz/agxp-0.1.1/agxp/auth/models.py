"""
Auth identity and token models.

AuthIdentity is the resolved identity returned by the auth dependency.
ParsedToken is the intermediate result of parsing a Bearer token.
"""
import dataclasses


@dataclasses.dataclass(frozen=True)
class AuthIdentity:
    """Resolved identity from a validated Bearer token."""

    user_id: str | None
    anon_session_id: str | None
    is_anonymous: bool


@dataclasses.dataclass(frozen=True)
class ParsedToken:
    """Result of parsing a raw Bearer token string."""

    key_id: str  # UUID with dashes
    secret_hex: str
    is_anonymous: bool
