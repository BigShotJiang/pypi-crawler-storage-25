"""
API key generation, parsing, and verification.

Pure functions — no I/O. Used by the auth dependency and by key-creation
endpoints (Issue #11).

Token formats:
  Registered:  agxp_<key_uuid_hex32>_<secret_hex32>
  Anonymous:   agxp_anon_<session_uuid_hex32>_<secret_hex32>

Only the secret portion is bcrypt-hashed for storage. The UUID prefix is a
plaintext row locator enabling O(1) DB lookup.
"""
from __future__ import annotations

import os
import uuid

import bcrypt as _bcrypt

from agxp.auth.models import ParsedToken

_REGISTERED_PREFIX = "agxp_"
_ANON_PREFIX = "agxp_anon_"
_SECRET_BYTES = 16  # 32 hex chars


def generate_api_key(key_id: str) -> tuple[str, str]:
    """
    Generate a registered API key token.

    Args:
        key_id: UUID string of the api_keys row.

    Returns:
        (plaintext_token, secret_hex) — caller stores bcrypt(secret_hex)
        in the key_hash column.
    """
    secret_hex = os.urandom(_SECRET_BYTES).hex()
    uid = uuid.UUID(key_id)
    token = f"{_REGISTERED_PREFIX}{uid.hex}_{secret_hex}"
    return token, secret_hex


def generate_anon_key(session_id: str) -> tuple[str, str]:
    """
    Generate an anonymous session token.

    Args:
        session_id: UUID string of the anonymous_sessions row.

    Returns:
        (plaintext_token, secret_hex)
    """
    secret_hex = os.urandom(_SECRET_BYTES).hex()
    uid = uuid.UUID(session_id)
    token = f"{_ANON_PREFIX}{uid.hex}_{secret_hex}"
    return token, secret_hex


def parse_api_token(token: str) -> ParsedToken | None:
    """
    Parse a Bearer token into its components.

    Returns None if the format is unrecognisable.
    """
    # Check anonymous prefix first (it starts with "agxp_" too).
    if token.startswith(_ANON_PREFIX):
        remainder = token[len(_ANON_PREFIX):]
        return _parse_remainder(remainder, is_anonymous=True)

    if token.startswith(_REGISTERED_PREFIX):
        remainder = token[len(_REGISTERED_PREFIX):]
        return _parse_remainder(remainder, is_anonymous=False)

    return None


def _parse_remainder(remainder: str, *, is_anonymous: bool) -> ParsedToken | None:
    """Parse '<uuid_hex32>_<secret_hex32>' from the token remainder."""
    parts = remainder.split("_", 1)
    if len(parts) != 2:
        return None

    uuid_hex, secret_hex = parts

    # Validate lengths: 32 hex chars each.
    if len(uuid_hex) != 32 or len(secret_hex) != 32:
        return None

    # Validate hex characters.
    try:
        int(uuid_hex, 16)
        int(secret_hex, 16)
    except ValueError:
        return None

    # Convert hex to standard UUID with dashes.
    key_id = str(uuid.UUID(uuid_hex))

    return ParsedToken(key_id=key_id, secret_hex=secret_hex, is_anonymous=is_anonymous)


def hash_secret(secret_hex: str) -> str:
    """Return a bcrypt hash of the secret, suitable for DB storage."""
    return _bcrypt.hashpw(
        secret_hex.encode(), _bcrypt.gensalt()
    ).decode()


def verify_secret(secret_hex: str, stored_hash: str) -> bool:
    """Verify a secret against a stored bcrypt hash."""
    return _bcrypt.checkpw(
        secret_hex.encode(), stored_hash.encode()
    )
