"""
Authentication module — API key + anonymous session auth.

Public API:
  - AuthIdentity: resolved identity dataclass
  - require_auth: FastAPI Depends() target
  - generate_api_key, generate_anon_key: token creation helpers
  - hash_secret, verify_secret: bcrypt wrappers
"""
from agxp.auth.dependency import require_auth
from agxp.auth.keys import (
    generate_anon_key,
    generate_api_key,
    hash_secret,
    verify_secret,
)
from agxp.auth.models import AuthIdentity

__all__ = [
    "AuthIdentity",
    "require_auth",
    "generate_api_key",
    "generate_anon_key",
    "hash_secret",
    "verify_secret",
]
