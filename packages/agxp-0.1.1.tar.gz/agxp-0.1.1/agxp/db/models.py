"""
SQLAlchemy ORM models for AgentXP.

Used by Alembic for migration generation (--autogenerate).
Runtime queries use asyncpg directly for performance.

Schema reflects all DDR decisions (DDR-003 through DDR-011, DDR-016/017).
"""
import enum
from datetime import datetime, timedelta, timezone

from pgvector.sqlalchemy import Vector
from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    SmallInteger,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.sql import func


def _now():
    return datetime.now(timezone.utc)


def _expires():
    return datetime.now(timezone.utc) + timedelta(days=30)


class Base(DeclarativeBase):
    pass


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class OutcomeType(enum.Enum):
    solved = "solved"
    workaround = "workaround"
    unresolved = "unresolved"


# ---------------------------------------------------------------------------
# Identity layer (DDR-004)
# ---------------------------------------------------------------------------


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, server_default=func.gen_random_uuid())
    email: Mapped[str | None] = mapped_column(String(256), unique=True, nullable=True)
    github_id: Mapped[str | None] = mapped_column(String(64), unique=True, nullable=True)
    display_name: Mapped[str | None] = mapped_column(String(256), nullable=True)
    password_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default="true")

    api_keys: Mapped[list["ApiKey"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    credit_account: Mapped["CreditAccount | None"] = relationship(back_populates="user", uselist=False)
    experiences: Mapped[list["Experience"]] = relationship(back_populates="user")


class ApiKey(Base):
    __tablename__ = "api_keys"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, server_default=func.gen_random_uuid())
    user_id: Mapped[str] = mapped_column(UUID(as_uuid=False), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    key_hash: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)
    label: Mapped[str | None] = mapped_column(String(128), nullable=True)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    user: Mapped["User"] = relationship(back_populates="api_keys")

    __table_args__ = (Index("api_keys_user_id", "user_id"),)


class AnonymousSession(Base):
    __tablename__ = "anonymous_sessions"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, server_default=func.gen_random_uuid())
    temp_key_hash: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)
    query_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    credit_balance: Mapped[int] = mapped_column(Integer, nullable=False, default=20, server_default="20")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    merged_into_user_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=True)


# ---------------------------------------------------------------------------
# Experiences (DDR-007, DDR-009, DDR-010)
# ---------------------------------------------------------------------------


class Experience(Base):
    __tablename__ = "experiences"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, server_default=func.gen_random_uuid())
    user_id: Mapped[str] = mapped_column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    agent_type: Mapped[str | None] = mapped_column(String(64), nullable=True)

    domain: Mapped[str] = mapped_column(String(64), nullable=False)
    subdomain: Mapped[str | None] = mapped_column(String(64), nullable=True)
    task_type: Mapped[str] = mapped_column(String(64), nullable=False)

    # Content fields (DDR-007)
    situation: Mapped[str] = mapped_column(Text, nullable=False)
    failed_approaches: Mapped[str | None] = mapped_column(Text, nullable=True)
    solution: Mapped[str] = mapped_column(Text, nullable=False)
    outcome_type: Mapped[str] = mapped_column(
        Enum("solved", "workaround", "unresolved", name="outcome_type"), nullable=False
    )
    lessons: Mapped[str] = mapped_column(Text, nullable=False)
    environment: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    tags: Mapped[list] = mapped_column(ARRAY(String(32)), nullable=False, server_default="{}")
    language: Mapped[str] = mapped_column(String(8), nullable=False, server_default="en")
    translation_status: Mapped[str] = mapped_column(String(16), nullable=False, server_default="not_needed")

    # Per-field vector embeddings (DDR-010, bge-m3 1024-dim)
    embedding_situation: Mapped[list | None] = mapped_column(Vector(1024), nullable=True)
    embedding_solution: Mapped[list | None] = mapped_column(Vector(1024), nullable=True)
    embedding_lessons: Mapped[list | None] = mapped_column(Vector(1024), nullable=True)
    embedding_failed: Mapped[list | None] = mapped_column(Vector(1024), nullable=True)
    embedding_tags: Mapped[list | None] = mapped_column(Vector(1024), nullable=True)
    embedding_environment: Mapped[list | None] = mapped_column(Vector(1024), nullable=True)

    # Quality score components (DDR-008)
    quality_score: Mapped[float] = mapped_column(nullable=False, default=0.0, server_default="0.0")
    uniqueness_score: Mapped[float | None] = mapped_column(nullable=True)
    completeness_score: Mapped[float | None] = mapped_column(nullable=True)
    community_score: Mapped[float | None] = mapped_column(nullable=True)
    upvotes: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    downvotes: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")
    use_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0, server_default="0")

    is_published: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    user: Mapped["User"] = relationship(back_populates="experiences")
    translations: Mapped[list["ExperienceTranslation"]] = relationship(back_populates="experience", cascade="all, delete-orphan")

    __table_args__ = (
        # B-tree indexes for filtering and sorting
        Index("exp_user_id", "user_id"),
        Index("exp_domain_task", "domain", "task_type", postgresql_where="deleted_at IS NULL AND is_published = true"),
        Index("exp_language", "language", postgresql_where="deleted_at IS NULL"),
        Index("exp_subdomain", "subdomain", postgresql_where="deleted_at IS NULL AND subdomain IS NOT NULL"),
        Index("exp_quality", "quality_score", postgresql_ops={"quality_score": "DESC"}, postgresql_where="deleted_at IS NULL AND is_published = true"),
        Index("exp_use_count", "use_count", postgresql_ops={"use_count": "DESC"}, postgresql_where="deleted_at IS NULL AND is_published = true"),
        Index("exp_created_at", "created_at", postgresql_ops={"created_at": "DESC"}, postgresql_where="deleted_at IS NULL"),
    )


class ExperienceTranslation(Base):
    __tablename__ = "experience_translations"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, server_default=func.gen_random_uuid())
    experience_id: Mapped[str] = mapped_column(UUID(as_uuid=False), ForeignKey("experiences.id", ondelete="CASCADE"), nullable=False)
    language: Mapped[str] = mapped_column(String(8), nullable=False)
    situation: Mapped[str | None] = mapped_column(Text, nullable=True)
    failed_approaches: Mapped[str | None] = mapped_column(Text, nullable=True)
    solution: Mapped[str | None] = mapped_column(Text, nullable=True)
    lessons: Mapped[str | None] = mapped_column(Text, nullable=True)
    translated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    experience: Mapped["Experience"] = relationship(back_populates="translations")

    __table_args__ = (UniqueConstraint("experience_id", "language", name="uq_experience_translations_exp_lang"),)


# ---------------------------------------------------------------------------
# Credits (DDR-003)
# ---------------------------------------------------------------------------


class CreditAccount(Base):
    __tablename__ = "credit_accounts"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, server_default=func.gen_random_uuid())
    user_id: Mapped[str] = mapped_column(UUID(as_uuid=False), ForeignKey("users.id"), unique=True, nullable=False)
    balance: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0, server_default="0")
    pending_balance: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0, server_default="0")
    tier: Mapped[str] = mapped_column(String(16), nullable=False, default="free", server_default="free")
    lifetime_earned: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0, server_default="0")
    lifetime_spent: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0, server_default="0")
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    user: Mapped["User"] = relationship(back_populates="credit_account")
    transactions: Mapped[list["CreditTransaction"]] = relationship(back_populates="account")


class CreditTransaction(Base):
    __tablename__ = "credit_transactions"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, server_default=func.gen_random_uuid())
    account_id: Mapped[str] = mapped_column(UUID(as_uuid=False), ForeignKey("credit_accounts.id"), nullable=False)
    txn_type: Mapped[str] = mapped_column(String(32), nullable=False)
    amount: Mapped[int] = mapped_column(BigInteger, nullable=False)
    balance_after: Mapped[int] = mapped_column(BigInteger, nullable=False)
    idempotency_key: Mapped[str | None] = mapped_column(String(128), unique=True, nullable=True)
    reference_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), nullable=True)
    reference_type: Mapped[str | None] = mapped_column(String(32), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    account: Mapped["CreditAccount"] = relationship(back_populates="transactions")

    __table_args__ = (Index("credit_txn_account_created", "account_id", "created_at"),)


# ---------------------------------------------------------------------------
# Votes
# ---------------------------------------------------------------------------


class QualityVote(Base):
    __tablename__ = "quality_votes"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, server_default=func.gen_random_uuid())
    experience_id: Mapped[str] = mapped_column(UUID(as_uuid=False), ForeignKey("experiences.id"), nullable=False)
    voter_user_id: Mapped[str] = mapped_column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    vote: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    __table_args__ = (
        UniqueConstraint("experience_id", "voter_user_id", name="uq_quality_votes_exp_user"),
        CheckConstraint("vote IN (-1, 1)", name="ck_quality_votes_vote_value"),
    )


# ---------------------------------------------------------------------------
# Query logs
# ---------------------------------------------------------------------------


class QueryLog(Base):
    __tablename__ = "query_logs"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, server_default=func.gen_random_uuid())
    user_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=True)
    anon_session_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), ForeignKey("anonymous_sessions.id"), nullable=True)
    agent_type: Mapped[str | None] = mapped_column(String(64), nullable=True)
    query_text: Mapped[str] = mapped_column(Text, nullable=False)
    query_language: Mapped[str | None] = mapped_column(String(8), nullable=True)
    tried_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    filters: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    search_fields: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    result_ids: Mapped[list | None] = mapped_column(ARRAY(UUID(as_uuid=False)), nullable=True)
    query_embedding: Mapped[list | None] = mapped_column(Vector(1024), nullable=True)
    latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    cache_hit_level: Mapped[str | None] = mapped_column(String(4), nullable=True)
    fallback_level: Mapped[int | None] = mapped_column(SmallInteger, nullable=True, default=0)
    credits_spent: Mapped[int] = mapped_column(Integer, nullable=False, default=1, server_default="1")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    feedback: Mapped[list["SearchFeedback"]] = relationship(back_populates="query_log")

    __table_args__ = (
        Index("query_logs_user_created", "user_id", "created_at", postgresql_where="user_id IS NOT NULL"),
        Index("query_logs_created_at", "created_at"),
    )


# ---------------------------------------------------------------------------
# Search feedback (DDR-016, DDR-017)
# ---------------------------------------------------------------------------


class SearchFeedback(Base):
    __tablename__ = "search_feedback"

    id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, server_default=func.gen_random_uuid())
    query_log_id: Mapped[str] = mapped_column(UUID(as_uuid=False), ForeignKey("query_logs.id"), nullable=False)
    experience_id: Mapped[str] = mapped_column(UUID(as_uuid=False), ForeignKey("experiences.id"), nullable=False)
    user_id: Mapped[str | None] = mapped_column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=True)
    position: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    was_useful: Mapped[bool] = mapped_column(Boolean, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    query_log: Mapped["QueryLog"] = relationship(back_populates="feedback")

    __table_args__ = (
        UniqueConstraint("query_log_id", "experience_id", name="uq_search_feedback_query_exp"),
        Index("search_feedback_exp_created", "experience_id", "created_at"),
    )
