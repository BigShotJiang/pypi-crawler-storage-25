"""
asyncpg connection pool singleton.

Usage:
    from agxp.db.pool import get_pool
    pool = await get_pool()

The pool is created lazily on first call and reused across the process.
pgvector codec is registered on every connection so vector columns can be
read and written as Python lists.

Tests inject their own pool via PgvectorBackend(pool=...) — this module is
not touched by the test suite.
"""
import asyncio
import os

import asyncpg
from pgvector.asyncpg import register_vector

_pool: asyncpg.Pool | None = None
_pool_lock = asyncio.Lock()


async def get_pool() -> asyncpg.Pool:
    global _pool
    async with _pool_lock:
        if _pool is None:
            raw = os.environ.get("DATABASE_URL")
            if not raw:
                raise RuntimeError(
                    "DATABASE_URL environment variable is not set. "
                    "Cannot create database connection pool."
                )
            dsn = raw.replace("postgresql+asyncpg://", "postgresql://", 1)

            # SSL configuration for Supabase compatibility
            ssl_mode = os.environ.get("PGSSLMODE", "prefer")
            connection_timeout = int(os.environ.get("PGCONNECT_TIMEOUT", "30"))

            _pool = await asyncpg.create_pool(
                dsn,
                init=register_vector,
                min_size=2,
                max_size=10,
                ssl=ssl_mode,
                timeout=connection_timeout,
                command_timeout=60,
                # TCP keepalive to prevent Supabase idle connection drops
                server_settings={
                    "tcp_keepalives_idle": "30",
                    "tcp_keepalives_interval": "10",
                    "tcp_keepalives_count": "5"
                }
            )
    return _pool


async def close_pool() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None
