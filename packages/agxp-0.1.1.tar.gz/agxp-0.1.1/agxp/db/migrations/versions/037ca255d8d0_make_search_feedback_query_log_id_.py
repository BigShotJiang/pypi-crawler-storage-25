"""make search_feedback.query_log_id nullable

Revision ID: 037ca255d8d0
Revises: 66157bb62596
Create Date: 2026-04-17 13:37:56.567278

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '037ca255d8d0'
down_revision: Union[str, Sequence[str], None] = '66157bb62596'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    # 1. 删除旧的唯一约束
    op.drop_constraint('uq_search_feedback_query_exp', 'search_feedback', type_='unique')

    # 2. 修改query_log_id字段为允许NULL
    op.alter_column('search_feedback', 'query_log_id',
               existing_type=sa.UUID(),
               nullable=True)

    # 3. 创建新的唯一约束，当query_log_id不为NULL时，(query_log_id, experience_id)唯一
    op.execute("""
        CREATE UNIQUE INDEX uq_search_feedback_query_exp_not_null
        ON search_feedback (query_log_id, experience_id)
        WHERE query_log_id IS NOT NULL
    """)


def downgrade() -> None:
    """Downgrade schema."""
    # 1. 删除新的唯一约束
    op.execute("DROP INDEX IF EXISTS uq_search_feedback_query_exp_not_null")

    # 2. 将query_log_id字段改回不允许NULL
    op.alter_column('search_feedback', 'query_log_id',
               existing_type=sa.UUID(),
               nullable=False)

    # 3. 恢复旧的唯一约束
    op.create_unique_constraint('uq_search_feedback_query_exp', 'search_feedback', ['query_log_id', 'experience_id'])

