"""add_password_hash_to_users

Revision ID: 66157bb62596
Revises: 621fc6baa0aa
Create Date: 2026-04-05 20:41:55.640988

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '66157bb62596'
down_revision: Union[str, Sequence[str], None] = '621fc6baa0aa'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.add_column('users', sa.Column('password_hash', sa.String(length=128), nullable=True))


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_column('users', 'password_hash')
