"""
award_credits — Celery task that credits a user after their experience is scored.

Pipeline position: embed → index_bm25 → score_quality → award_credits

The idempotency key is f"award_contribution_{experience_id}", which is globally
unique (one experience → one award, ever).  Retrying the task after a transient
failure is therefore safe.

Credit amount is quality-weighted (Issue #7):
  [0.0, 0.5)  →  5 credits
  [0.5, 0.7)  → 10 credits
  [0.7, 0.85) → 25 credits
  [0.85, 1.0] → 50 credits
"""
import asyncio
import concurrent.futures

from agxp.services.credit_writer import InsufficientCreditsError
from agxp.workers.celery_app import celery_app


def credits_for_quality(quality_score: float) -> int:
    """
    Map a quality score in [0.0, 1.0] to a credit reward amount.

    Boundaries:
      [0.0, 0.5)   →  5
      [0.5, 0.7)   → 10
      [0.7, 0.85)  → 25
      [0.85, 1.0]  → 50
    """
    if quality_score >= 0.85:
        return 50
    if quality_score >= 0.70:
        return 25
    if quality_score >= 0.50:
        return 10
    return 5


def _run_async(coro):
    """
    Run a coroutine from a synchronous Celery task context.
    See agxp/workers/embed.py for rationale.
    # TODO: extract to agxp/workers/_async_util.py (duplicated in embed.py and score_quality.py)
    """
    async def wrapped_coro():
        try:
            return await coro
        finally:
            # Close global connection pool after each run to avoid cross-loop references
            from agxp.db.pool import close_pool
            await close_pool()

    try:
        asyncio.get_running_loop()
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(asyncio.run, wrapped_coro()).result()
    except RuntimeError:
        return asyncio.run(wrapped_coro())


@celery_app.task(
    bind=True,
    name="agxp.workers.credit.award_credits",
    max_retries=3,
    default_retry_delay=10,
)
def award_credits(
    self,
    experience_id: str,
    user_id: str,
    quality_score: float = 0.0,
) -> dict:
    """
    Award quality-weighted contribution credits to user_id for experience_id.

    Args:
        experience_id: UUID string of the accepted experience.
        user_id:       UUID string of the contributing user.
        quality_score: Float in [0.0, 1.0] from score_quality worker.

    Returns:
        {"status": "ok", "experience_id": ..., "user_id": ..., "new_balance": N,
         "credits_awarded": N}
    """
    try:
        return _run_async(_award_credits_async(experience_id, user_id, quality_score))
    except InsufficientCreditsError:
        # Domain error — retrying will not help; propagate immediately.
        raise
    except Exception as exc:
        raise self.retry(exc=exc)


async def _award_credits_async(
    experience_id: str,
    user_id: str,
    quality_score: float,
) -> dict:
    from agxp.config.backends import CREDIT_WRITER

    amount = credits_for_quality(quality_score)
    idempotency_key = f"award_contribution_{experience_id}"

    new_balance = await CREDIT_WRITER.credit(
        user_id=user_id,
        amount=amount,
        txn_type="earn_contribution",
        description=(
            f"Contribution award for experience {experience_id} "
            f"(quality_score={quality_score:.3f})"
        ),
        experience_id=experience_id,
        idempotency_key=idempotency_key,
    )

    return {
        "status": "ok",
        "experience_id": experience_id,
        "user_id": user_id,
        "credits_awarded": amount,
        "new_balance": new_balance,
    }
