"""
embed_experience — Celery task that generates all 6 per-field embeddings
for an experience and writes them back to PostgreSQL.

Pipeline position: contribution accepted → embed → bm25-index → quality-score → award
"""
import asyncio
import concurrent.futures
import os

from agxp.workers.celery_app import celery_app


def _run_async(coro):
    """
    Run a coroutine from a synchronous Celery task.

    Standard prefork workers have no running event loop, so asyncio.run() is
    used directly. If a running loop is detected (gevent/eventlet pools, or a
    nested async caller), the coroutine is submitted to a fresh thread that
    creates its own event loop, avoiding re-entry errors.
    """
    async def wrapped_coro():
        try:
            return await coro
        finally:
            # Close global connection pool after each run to avoid cross-loop references
            from agxp.db.pool import close_pool
            await close_pool()

    try:
        asyncio.get_running_loop()
        # Already inside a running loop — run in a dedicated thread.
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(asyncio.run, wrapped_coro()).result()
    except RuntimeError:
        # No running loop (normal Celery prefork case).
        return asyncio.run(wrapped_coro())


@celery_app.task(
    bind=True,
    name="agxp.workers.embed.embed_experience",
    max_retries=3,
    default_retry_delay=10,
)
def embed_experience(self, experience_id: str, user_id: str | None = None) -> dict:
    """
    Embed all 6 content fields of an experience and persist vectors to DB.

    Args:
        experience_id: UUID string of the experience to embed.
        user_id:       UUID string of the contributing user (optional).
                       When provided, chains to score_quality after embedding.

    Returns:
        {"status": "ok", "experience_id": ...} on success.
    """
    try:
        return _run_async(_embed_experience_async(experience_id, user_id))
    except Exception as exc:
        raise self.retry(exc=exc)


async def _embed_experience_async(experience_id: str, user_id: str | None = None) -> dict:
    import uuid

    from agxp.config.backends import EMBED_BACKEND
    from agxp.db.pool import get_pool
    from agxp.search.embed import ExperienceEmbedder

    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT situation, solution, lessons, failed_approaches, tags, environment "
            "FROM experiences WHERE id = $1",
            uuid.UUID(experience_id),
        )
        if row is None:
            return {"status": "not_found", "experience_id": experience_id}

        embedder = ExperienceEmbedder(EMBED_BACKEND)
        emb = await embedder.embed_experience(dict(row))

        await conn.execute(
            """
            UPDATE experiences SET
                embedding_situation   = $1,
                embedding_solution    = $2,
                embedding_lessons     = $3,
                embedding_failed      = $4,
                embedding_tags        = $5,
                embedding_environment = $6,
                updated_at            = now()
            WHERE id = $7
            """,
            emb["situation"],
            emb["solution"],
            emb["lessons"],
            emb["failed_approaches"],
            emb["tags"],
            emb["environment"],
            uuid.UUID(experience_id),
        )
        if user_id:
            from agxp.workers.score_quality import score_quality
            score_quality.delay(experience_id, user_id)

        return {"status": "ok", "experience_id": experience_id}
