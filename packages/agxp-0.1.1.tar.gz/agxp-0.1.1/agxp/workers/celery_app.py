"""
Celery application instance for agxp async workers.
Broker and result backend both use Redis (already required for L2 cache).
Supports both direct Redis connection and Sentinel mode for Kvrocks compatibility.
"""
import os

from celery import Celery


def get_celery_config() -> dict:
    """Get Celery configuration based on environment variables."""
    use_sentinel = os.getenv("REDIS_USE_SENTINEL", "").lower() in ("true", "1", "yes")
    redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")

    if not use_sentinel:
        # Direct Redis connection mode
        return {
            "broker": redis_url,
            "backend": redis_url,
            "broker_transport_options": {},
        }

    # Sentinel mode configuration for Kvrocks
    sentinel_hosts = os.getenv("REDIS_SENTINEL_HOSTS", "")
    if not sentinel_hosts:
        raise ValueError("REDIS_SENTINEL_HOSTS is required when using Sentinel mode")

    sentinel_hosts_list = [
        host.strip()
        for host in sentinel_hosts.split(",")
        if host.strip()
    ]

    master_name = os.getenv("REDIS_MASTER_NAME", "mymaster")
    sentinel_password = os.getenv("REDIS_SENTINEL_PASSWORD")
    namespace_password = os.getenv("REDIS_NAMESPACE_PASSWORD")
    db = int(os.getenv("REDIS_DB", "0"))

    # Build broker URLs for Sentinel (password must be in URL for Kombu master connection)
    broker_urls = [
        f"sentinel://:{namespace_password}@{host}/{db}" if namespace_password else f"sentinel://{host}/{db}"
        for host in sentinel_hosts_list
    ]
    broker_url_str = ";".join(broker_urls)

    return {
        "broker": broker_url_str,
        "backend": broker_url_str,
        "broker_transport_options": {
            "master_name": master_name,
            "sentinel_kwargs": {"password": sentinel_password} if sentinel_password else {},
        },
        "result_backend_transport_options": {
            "master_name": master_name,
            "sentinel_kwargs": {"password": sentinel_password} if sentinel_password else {},
        }
    }


# Initialize Celery app
celery_config = get_celery_config()

celery_app = Celery(
    "agxp",
    broker=celery_config["broker"],
    backend=celery_config["backend"],
    include=["agxp.workers.embed", "agxp.workers.score_quality", "agxp.workers.credit"],
)

# Update Celery configuration with transport options
celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    broker_transport_options=celery_config.get("broker_transport_options", {}),
    result_backend_transport_options=celery_config.get("result_backend_transport_options", {}),
)
