"""
score_quality — Celery task that computes and persists quality scores.

Pipeline position: embed → index_bm25 → score_quality → award_credits

Calls QualityScoreWriter.recompute_score() (Phase 1: rule-based formula),
then chains to award_credits with the computed quality_score so that credit
amount is proportional to quality.
"""
import asyncio
import concurrent.futures

from agxp.workers.celery_app import celery_app
from agxp.workers.credit import award_credits


def _run_async(coro):
    """
    Run a coroutine from a synchronous Celery task context.
    See agxp/workers/embed.py for rationale.
    # TODO: extract to agxp/workers/_async_util.py (duplicated in embed.py and credit.py)
    """
    async def wrapped_coro():
        try:
            return await coro
        finally:
            # Close global connection pool after each run to avoid cross-loop references
            from agxp.db.pool import close_pool
            await close_pool()

    try:
        asyncio.get_running_loop()
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(asyncio.run, wrapped_coro()).result()
    except RuntimeError:
        return asyncio.run(wrapped_coro())


@celery_app.task(
    bind=True,
    name="agxp.workers.score_quality.score_quality",
    max_retries=3,
    default_retry_delay=10,
)
def score_quality(self, experience_id: str, user_id: str) -> dict:
    """
    Compute quality score for experience_id and chain to award_credits.

    Args:
        experience_id: UUID string of the indexed experience.
        user_id:       UUID string of the contributing user.

    Returns:
        {"status": "ok", "experience_id": ..., "user_id": ..., "quality_score": ...}
    """
    try:
        return _run_async(_score_quality_async(experience_id, user_id))
    except ValueError:
        # Domain error (experience not found) — retrying will not help.
        raise
    except Exception as exc:
        raise self.retry(exc=exc)


async def _score_quality_async(experience_id: str, user_id: str) -> dict:
    from agxp.config.backends import QUALITY_WRITER

    quality_score = await QUALITY_WRITER.recompute_score(experience_id)

    award_credits.delay(experience_id, user_id, quality_score)

    return {
        "status": "ok",
        "experience_id": experience_id,
        "user_id": user_id,
        "quality_score": quality_score,
    }
