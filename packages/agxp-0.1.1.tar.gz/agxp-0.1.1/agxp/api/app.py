"""
AGXP FastAPI application.

Lifespan validates all dependencies on startup and tears down the DB pool
on shutdown.
"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from starlette.requests import Request

from agxp.api.routes.auth import router as auth_router
from agxp.api.routes.contribute import router as contribute_router
from agxp.api.routes.feedback import router as feedback_router
from agxp.api.routes.query import router as query_router
from agxp.api.routes.health import router as health_router
from agxp.api.routes.user import router as user_router
from agxp.api.startup import check_database, check_env_vars, check_pgvector, check_redis
from agxp.db.pool import close_pool, get_pool

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: validate dependencies. Shutdown: release resources."""
    # 0. Load .env if python-dotenv is available
    try:
        from dotenv import load_dotenv
        load_dotenv()
        logger.info(".env loaded via python-dotenv")
    except ImportError:
        logger.debug("python-dotenv not installed, skipping .env loading")

    # 1. Environment variables
    check_env_vars()

    # 2. Database connectivity
    dsn = os.environ["DATABASE_URL"].replace(
        "postgresql+asyncpg://", "postgresql://", 1
    )
    await check_database(dsn)
    await check_pgvector(dsn)
    logger.info("PostgreSQL + pgvector: OK")

    # 3. Redis (non-fatal)
    from agxp.api.redis import is_sentinel_mode
    if is_sentinel_mode():
        # Use Sentinel configuration
        redis_ok = await check_redis()
    else:
        # Use direct URL connection
        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        redis_ok = await check_redis(redis_url)
    if redis_ok:
        logger.info("Redis: OK")
    else:
        logger.warning("Redis: unavailable — Celery tasks will not execute")

    # 4. Warm up DB pool
    await get_pool()
    logger.info("AGXP server ready")

    yield

    # Shutdown
    await close_pool()
    logger.info("AGXP server shutdown complete")


app = FastAPI(
    title="AGXP",
    version="0.1.0",
    description="Experience Exchange for Agents — credit-based knowledge repository",
    lifespan=lifespan,
)

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    """Return dict details as flat JSON, not wrapped in {"detail": ...}."""
    if isinstance(exc.detail, dict):
        return JSONResponse(status_code=exc.status_code, content=exc.detail)
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": "error", "message": str(exc.detail)},
    )



app.include_router(health_router)
app.include_router(auth_router, prefix="/api/v1")
app.include_router(query_router, prefix="/api/v1")
app.include_router(contribute_router, prefix="/api/v1")
app.include_router(feedback_router, prefix="/api/v1")
app.include_router(user_router)
