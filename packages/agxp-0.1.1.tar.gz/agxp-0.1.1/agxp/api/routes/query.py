"""
Query endpoint — POST /api/v1/query

Orchestrates the full search pipeline:
  1. PIPELINE.run() → RRF-ranked candidate list
  2. fetch_experiences_by_ids() → full experience data from DB
  3. min_quality post-filter
  4. Cross-encoder reranking (top-20)
  5. Quality blending
  6. NDJSON streaming response

PIPELINE and fetch_experiences_by_ids are module-level names so tests can
patch them without touching dependency injection machinery.
"""
from __future__ import annotations

import json
import time
import uuid
import os

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse

from agxp.auth.dependency import require_auth
from agxp.auth.models import AuthIdentity
from agxp.search.query_pipeline import QueryPipeline, QueryRequest, quality_blend

router = APIRouter()

# ---------------------------------------------------------------------------
# Module-level singletons (patched in tests)
# ---------------------------------------------------------------------------

# Lazy sentinel — initialized on first request so heavy backends (Tantivy index,
# BgeM3 model, MiniLM model) are NOT loaded at import time.
# Tests replace via patch("agxp.api.routes.query.PIPELINE", fake_pipeline).
PIPELINE: QueryPipeline | None = None


def _get_pipeline() -> QueryPipeline:
    global PIPELINE
    print(f"[DEBUG] 进入_get_pipeline函数，PIPELINE是否存在: {PIPELINE is not None}", flush=True)
    if PIPELINE is None:
        print(f"[DEBUG] 开始初始化Pipeline，先读环境变量", flush=True)
        # 先读环境变量，避免导入慢看不到日志
        reranker_type = os.getenv("RERANKER_TYPE", "fake").lower()

        print(f"[DEBUG] 选择重排器类型: {reranker_type}", flush=True)
        import logging
        logger = logging.getLogger(__name__)

        print(f"[DEBUG] 开始加载后端配置，向量模型加载可能比较慢...", flush=True)
        from agxp.config.backends import EMBED_BACKEND, FTS_BACKEND, VECTOR_BACKEND
        print(f"[DEBUG] 后端配置加载完成", flush=True)

        # 降级用的Fake重排器
        class FakeReranker:
            async def rerank(self, query, candidates):
                return [(c[0], 1.0) for c in candidates]

        try:
            if reranker_type == "api":
                print(f"[DEBUG] 初始化API重排器", flush=True)
                from agxp.search.reranker import SiliconFlowAPIReranker
                reranker = SiliconFlowAPIReranker()
                logger.info("✅ 使用API重排器，endpoint: %s, model: %s", reranker._api_url, reranker._model)
                print(f"[DEBUG] API重排器初始化成功", flush=True)
            elif reranker_type == "local":
                print(f"[DEBUG] 初始化本地重排器，注意第一次会下载模型，可能很慢...", flush=True)
                from agxp.search.reranker import LocalMiniLMReranker
                reranker = LocalMiniLMReranker()
                logger.info("✅ 使用本地MiniLM重排器")
                print(f"[DEBUG] 本地重排器初始化成功", flush=True)
            else:
                print(f"[DEBUG] 使用Fake重排器（默认，无重排序逻辑）", flush=True)
                reranker = FakeReranker()
        except Exception as e:
            logger.warning(f"❌ 初始化{reranker_type}重排器失败，降级到Fake重排器: {str(e)}")
            print(f"[ERROR] 重排器初始化失败: {str(e)}，用Fake降级", flush=True)
            reranker = FakeReranker()

        print(f"[DEBUG] 开始创建QueryPipeline实例", flush=True)
        PIPELINE = QueryPipeline(
            embed_backend=EMBED_BACKEND,
            vector_backend=VECTOR_BACKEND,
            fts_backend=FTS_BACKEND,
            reranker=reranker,
        )
        print(f"[DEBUG] Pipeline初始化完成", flush=True)
    return PIPELINE


# ---------------------------------------------------------------------------
# DB helper (patched in tests)
# ---------------------------------------------------------------------------


async def fetch_experiences_by_ids(experience_ids: list[str]) -> dict[str, dict]:
    """
    Fetch full experience rows for the given IDs.
    Returns {experience_id_str: row_dict}.
    Missing IDs are absent from the result dict.
    """
    if not experience_ids:
        return {}

    import uuid as _uuid

    from agxp.db.pool import get_pool

    pool = await get_pool()
    rows = await pool.fetch(
        """
        SELECT id, domain, task_type, situation, solution, lessons,
               failed_approaches, outcome_type, language, tags, quality_score
        FROM experiences
        WHERE id = ANY($1::uuid[])
          AND deleted_at IS NULL
        """,
        [_uuid.UUID(eid) for eid in experience_ids],
    )
    return {str(row["id"]): dict(row) for row in rows}


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.post("/query")
async def query_endpoint(
    request: QueryRequest,
    identity: AuthIdentity = Depends(require_auth),
) -> StreamingResponse:
    async def _generate():
        start = time.monotonic()
        try:
            pipeline = _get_pipeline()

            # Step 1: RRF-ranked candidates (with degradation)
            run_output = await pipeline.run(request)
            rrf_results = run_output["results"]
            pipeline_warnings = run_output.get("warnings", [])
            print(f"[QUERY FUNNEL 1/7] 收到查询请求: min_quality={request.min_quality}, limit={request.limit}, filters=domain={request.domain}, task_type={request.task_type}, language={request.language}", flush=True)

            # Step 2: Fetch full experience data
            exp_ids = [r["experience_id"] for r in rrf_results]
            experiences = await fetch_experiences_by_ids(exp_ids)
            print(f"[QUERY FUNNEL 6/7] 从数据库拉取到 {len(experiences)} 条完整经验记录（丢失的可能是已删除/不存在）", flush=True)

            # Step 3: min_quality post-filter
            filtered = [
                r for r in rrf_results
                if float(
                    (experiences.get(r["experience_id"]) or {}).get("quality_score", 0.0)
                ) >= request.min_quality
            ]
            filtered_out = len(rrf_results) - len(filtered)
            print(f"[QUERY FUNNEL 7/7] 经过min_quality={request.min_quality}过滤后剩 {len(filtered)} 条，过滤掉 {filtered_out} 条", flush=True)
            if filtered_out > 0:
                filtered_scores = [float((experiences.get(r['experience_id']) or {}).get('quality_score', 0.0)) for r in rrf_results if float((experiences.get(r['experience_id']) or {}).get('quality_score', 0.0)) < request.min_quality]
                print(f"  被过滤的质量分: {filtered_scores}", flush=True)

            # Step 4: Cross-encoder reranking on top-20
            top20 = filtered[:20]
            print(f"[QUERY FUNNEL 8/9] 进入交叉编码器重排序的有 {len(top20)} 条（取前20）", flush=True)
            candidates = [
                (
                    r["experience_id"],
                    (
                        str((experiences.get(r["experience_id"]) or {}).get("situation", ""))
                        + "\n\n"
                        + str((experiences.get(r["experience_id"]) or {}).get("lessons", ""))
                    ),
                )
                for r in top20
            ]
            reranked = await pipeline.reranker.rerank(request.query, candidates)
            reranker_scores = {exp_id: score for exp_id, score in reranked}
            print(f"[QUERY FUNNEL 9/9] 重排序完成，所有得分: {[round(s, 4) for s in reranker_scores.values()]}", flush=True)

            # Step 5: Quality blend + sort
            blended: list[tuple[str, float]] = []
            for r in top20:
                exp_id = r["experience_id"]
                exp = (experiences.get(exp_id) or {})
                r_score = reranker_scores.get(exp_id, 0.0)
                q_score = float(exp.get("quality_score", 0.0))
                final = quality_blend(r_score, q_score)
                blended.append((exp_id, final))

            blended.sort(key=lambda x: x[1], reverse=True)
            blended = blended[: request.limit]
            print(f"[QUERY FUNNEL FINAL] 最终返回 {len(blended)} 条结果给用户\n", flush=True)

            latency_ms = int((time.monotonic() - start) * 1000)

            # Step 6: Stream NDJSON
            yield json.dumps({
                "type": "meta",
                "query_id": str(uuid.uuid4()),
                "latency_ms": latency_ms,
                "warnings": pipeline_warnings,
            }) + "\n"

            for rank, (exp_id, final_score) in enumerate(blended, start=1):
                exp = (experiences.get(exp_id) or {})
                tags = exp.get("tags")
                yield json.dumps({
                    "type": "result",
                    "rank": rank,
                    "score": round(final_score, 6),
                    "experience": {
                        "id": exp_id,
                        "domain": exp.get("domain"),
                        "task_type": exp.get("task_type"),
                        "situation": exp.get("situation"),
                        "solution": exp.get("solution"),
                        "lessons": exp.get("lessons"),
                        "failed_approaches": exp.get("failed_approaches"),
                        "outcome_type": exp.get("outcome_type"),
                        "language": exp.get("language"),
                        "tags": list(tags) if tags is not None else [],
                        "quality_score": float(exp["quality_score"]) if exp.get("quality_score") is not None else None,
                    },
                }) + "\n"

            yield json.dumps({
                "type": "done",
                "total_results": len(blended),
            }) + "\n"

        except Exception as exc:
            yield json.dumps({
                "type": "error",
                "message": str(exc),
            }) + "\n"

    return StreamingResponse(_generate(), media_type="application/x-ndjson")
