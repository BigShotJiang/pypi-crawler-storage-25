"""
Auth onboarding endpoints — Issue #19.

POST /api/v1/auth/anonymous  — create anonymous session, return token
POST /api/v1/auth/register   — create user account, return token
POST /api/v1/auth/login      — authenticate user, return token
GET /api/v1/auth/github      — Github OAuth login redirect
GET /api/v1/auth/github/callback — Github OAuth callback

Module-level helpers (create_anonymous_session, create_user_account,
authenticate_user) are plain async functions so unit tests can patch them
without touching DI machinery.
"""
from __future__ import annotations

import asyncio
import httpx
import logging
import os
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode

logger = logging.getLogger(__name__)

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse, RedirectResponse, HTMLResponse
from pydantic import BaseModel, Field

from agxp.auth.keys import generate_anon_key, generate_api_key, hash_secret, verify_secret

router = APIRouter(prefix="/auth")

# Github OAuth configuration
GITHUB_CLIENT_ID = os.environ.get("GITHUB_CLIENT_ID")
GITHUB_CLIENT_SECRET = os.environ.get("GITHUB_CLIENT_SECRET")
OAUTH_REDIRECT_URI = os.environ.get("OAUTH_REDIRECT_URI")
GITHUB_OAUTH_URL = "https://github.com/login/oauth/authorize"
GITHUB_TOKEN_URL = "https://github.com/login/oauth/access_token"
GITHUB_API_URL = "https://api.github.com/user"
STATE_EXPIRE_SECONDS = 300  # 5 minutes

# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------


class RegisterRequest(BaseModel):
    email: str = Field(..., min_length=1, max_length=256)
    password: str = Field(..., min_length=8, max_length=128)
    display_name: str | None = Field(None, max_length=256)
    anon_session_id: str | None = None


class LoginRequest(BaseModel):
    email: str = Field(..., min_length=1, max_length=256)
    password: str = Field(..., min_length=1, max_length=128)


# ---------------------------------------------------------------------------
# Module-level patchable DB helpers
# ---------------------------------------------------------------------------


async def create_anonymous_session() -> dict:
    """Create an anonymous session row and return token + metadata."""
    from agxp.db.pool import get_pool

    loop = asyncio.get_running_loop()

    session_id = str(uuid.uuid4())
    token, secret_hex = generate_anon_key(session_id)
    key_hash = await loop.run_in_executor(None, hash_secret, secret_hex)

    expires_at = datetime.now(timezone.utc) + timedelta(days=30)

    pool = await get_pool()
    await pool.execute(
        "INSERT INTO anonymous_sessions (id, temp_key_hash, credit_balance, expires_at) "
        "VALUES ($1, $2, $3, $4)",
        uuid.UUID(session_id),
        key_hash,
        20,
        expires_at,
    )

    return {
        "token": token,
        "session_id": session_id,
        "credit_balance": 20,
        "expires_at": expires_at.isoformat(),
    }


async def create_user_account(
    email: str,
    password: str,
    display_name: str | None,
    anon_session_id: str | None,
) -> dict:
    """Create a registered user, API key, credit account, and optionally merge anon session."""
    import asyncpg

    from agxp.db.pool import get_pool

    loop = asyncio.get_running_loop()

    pool = await get_pool()

    # Hash password + API key secret in parallel (both are blocking bcrypt)
    password_hash = await loop.run_in_executor(None, hash_secret, password)

    user_id = str(uuid.uuid4())
    key_id = str(uuid.uuid4())
    token, secret_hex = generate_api_key(key_id)
    key_hash = await loop.run_in_executor(None, hash_secret, secret_hex)

    base_credits = 50
    merged_credits = 0

    async with pool.acquire() as conn:
        async with conn.transaction():
            # Create user — catch unique violation for email (TOCTOU-safe)
            try:
                await conn.execute(
                    "INSERT INTO users (id, email, display_name, password_hash) "
                    "VALUES ($1, $2, $3, $4)",
                    uuid.UUID(user_id),
                    email,
                    display_name,
                    password_hash,
                )
            except asyncpg.UniqueViolationError:
                raise HTTPException(
                    status_code=409,
                    detail={"error": "conflict", "message": "Email already registered"},
                )

            # Create API key
            await conn.execute(
                "INSERT INTO api_keys (id, user_id, key_hash) VALUES ($1, $2, $3)",
                uuid.UUID(key_id),
                uuid.UUID(user_id),
                key_hash,
            )

            # Handle anon session merge
            if anon_session_id is not None:
                anon_row = await conn.fetchrow(
                    "SELECT id, credit_balance, merged_into_user_id, expires_at "
                    "FROM anonymous_sessions WHERE id = $1",
                    uuid.UUID(anon_session_id),
                )
                if anon_row is None:
                    raise HTTPException(
                        status_code=404,
                        detail={"error": "not_found", "message": "Anonymous session not found"},
                    )
                if anon_row["merged_into_user_id"] is not None:
                    raise HTTPException(
                        status_code=400,
                        detail={"error": "bad_request", "message": "Anonymous session already merged"},
                    )
                expires = anon_row["expires_at"]
                if expires.tzinfo is None:
                    expires = expires.replace(tzinfo=timezone.utc)
                if expires <= datetime.now(timezone.utc):
                    raise HTTPException(
                        status_code=400,
                        detail={"error": "bad_request", "message": "Anonymous session has expired"},
                    )

                merged_credits = anon_row["credit_balance"]

                # Mark session as merged
                await conn.execute(
                    "UPDATE anonymous_sessions SET merged_into_user_id = $1 WHERE id = $2",
                    uuid.UUID(user_id),
                    uuid.UUID(anon_session_id),
                )

                # Migrate query logs
                await conn.execute(
                    "UPDATE query_logs SET user_id = $1 WHERE anon_session_id = $2",
                    uuid.UUID(user_id),
                    uuid.UUID(anon_session_id),
                )

            # Create credit account
            total_credits = base_credits + merged_credits
            await conn.execute(
                "INSERT INTO credit_accounts (id, user_id, balance, lifetime_earned) "
                "VALUES ($1, $2, $3, $3)",
                uuid.UUID(str(uuid.uuid4())),
                uuid.UUID(user_id),
                total_credits,
            )

    return {
        "token": token,
        "user_id": user_id,
        "credit_balance": total_credits,
    }


async def authenticate_user(email: str, password: str) -> dict:
    """Authenticate a user by email+password, create a new API key, return token."""
    from agxp.db.pool import get_pool

    loop = asyncio.get_running_loop()
    pool = await get_pool()

    _UNAUTHORIZED = HTTPException(
        status_code=401,
        detail={"error": "unauthorized", "message": "Invalid email or password"},
    )

    # Look up user
    row = await pool.fetchrow(
        "SELECT id, password_hash FROM users WHERE email = $1", email,
    )
    if row is None:
        raise _UNAUTHORIZED

    stored_hash = row["password_hash"]
    if stored_hash is None:
        # OAuth-only user, no password set
        raise _UNAUTHORIZED

    valid = await loop.run_in_executor(None, verify_secret, password, stored_hash)
    if not valid:
        raise _UNAUTHORIZED

    user_id = str(row["id"])

    # Create new API key
    key_id = str(uuid.uuid4())
    token, secret_hex = generate_api_key(key_id)
    key_hash = await loop.run_in_executor(None, hash_secret, secret_hex)

    await pool.execute(
        "INSERT INTO api_keys (id, user_id, key_hash) VALUES ($1, $2, $3)",
        uuid.UUID(key_id),
        uuid.UUID(user_id),
        key_hash,
    )

    return {
        "token": token,
        "user_id": user_id,
    }


# ---------------------------------------------------------------------------
# Github OAuth helpers
# ---------------------------------------------------------------------------

async def get_github_user_info(code: str) -> dict:
    """Exchange code for access token and get Github user info."""
    async with httpx.AsyncClient() as client:
        # Exchange code for access token
        token_response = await client.post(
            GITHUB_TOKEN_URL,
            data={
                "client_id": GITHUB_CLIENT_ID,
                "client_secret": GITHUB_CLIENT_SECRET,
                "code": code,
                "redirect_uri": OAUTH_REDIRECT_URI,
            },
            headers={"Accept": "application/json"},
        )
        token_data = token_response.json()
        if "error" in token_data:
            raise HTTPException(
                status_code=400,
                detail={"error": "oauth_error", "message": token_data["error_description"]}
            )

        access_token = token_data["access_token"]

        # Get user info
        user_response = await client.get(
            GITHUB_API_URL,
            headers={"Authorization": f"Bearer {access_token}"}
        )
        if user_response.status_code != 200:
            raise HTTPException(
                status_code=400,
                detail={"error": "oauth_error", "message": "Failed to get user info from Github"}
            )

        return user_response.json()


async def create_or_update_github_user(github_user: dict) -> dict:
    """Create a new user from Github info or update existing one. Returns API token."""
    from agxp.db.pool import get_pool

    github_id = str(github_user["id"])
    email = github_user.get("email")
    display_name = github_user.get("name") or github_user.get("login")

    pool = await get_pool()
    loop = asyncio.get_running_loop()

    async with pool.acquire() as conn:
        async with conn.transaction():
            # Check if user already exists with this github_id
            existing_user = await conn.fetchrow(
                "SELECT id FROM users WHERE github_id = $1", github_id
            )

            if existing_user:
                # User exists, create new API key
                user_id = str(existing_user["id"])
            else:
                # Check if email already exists (if email is provided)
                user_id = str(uuid.uuid4())
                if email:
                    existing_email_user = await conn.fetchrow(
                        "SELECT id, github_id FROM users WHERE email = $1", email
                    )
                    if existing_email_user:
                        if existing_email_user["github_id"]:
                            # Email already registered with another Github account
                            raise HTTPException(
                                status_code=409,
                                detail={
                                    "error": "conflict",
                                    "message": "This email is already registered with another account. "
                                              "Please login with your existing account and link Github in settings."
                                }
                            )
                        else:
                            # Email exists but not linked to Github, update the user
                            user_id = str(existing_email_user["id"])
                            await conn.execute(
                                "UPDATE users SET github_id = $1, display_name = COALESCE(display_name, $2) WHERE id = $3",
                                github_id, display_name, uuid.UUID(user_id)
                            )
                    else:
                        # Create new user
                        # Generate random password (user can set it later if needed)
                        random_password = secrets.token_urlsafe(16)
                        password_hash = await loop.run_in_executor(None, hash_secret, random_password)

                        await conn.execute(
                            "INSERT INTO users (id, email, github_id, display_name, password_hash) "
                            "VALUES ($1, $2, $3, $4, $5)",
                            uuid.UUID(user_id), email, github_id, display_name, password_hash
                        )

                        # Create credit account for new user
                        await conn.execute(
                            "INSERT INTO credit_accounts (id, user_id, balance, lifetime_earned) "
                            "VALUES ($1, $2, 50, 50)",
                            uuid.UUID(str(uuid.uuid4())), uuid.UUID(user_id)
                        )
                else:
                    # No email provided, create new user without email
                    random_password = secrets.token_urlsafe(16)
                    password_hash = await loop.run_in_executor(None, hash_secret, random_password)

                    await conn.execute(
                        "INSERT INTO users (id, github_id, display_name, password_hash) "
                        "VALUES ($1, $2, $3, $4)",
                        uuid.UUID(user_id), github_id, display_name, password_hash
                    )

                    # Create credit account
                    await conn.execute(
                        "INSERT INTO credit_accounts (id, user_id, balance, lifetime_earned) "
                        "VALUES ($1, $2, 50, 50)",
                        uuid.UUID(str(uuid.uuid4())), uuid.UUID(user_id)
                    )

            # Create new API key for the user
            key_id = str(uuid.uuid4())
            token, secret_hex = generate_api_key(key_id)
            key_hash = await loop.run_in_executor(None, hash_secret, secret_hex)

            await conn.execute(
                "INSERT INTO api_keys (id, user_id, key_hash) VALUES ($1, $2, $3)",
                uuid.UUID(key_id), uuid.UUID(user_id), key_hash
            )

    return {"token": token, "user_id": user_id}


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/anonymous", status_code=201)
async def anonymous_endpoint() -> JSONResponse:
    result = await create_anonymous_session()
    return JSONResponse(status_code=201, content=result)


@router.post("/register", status_code=201)
async def register_endpoint(request: RegisterRequest) -> JSONResponse:
    result = await create_user_account(
        email=request.email,
        password=request.password,
        display_name=request.display_name,
        anon_session_id=request.anon_session_id,
    )
    return JSONResponse(status_code=201, content=result)


@router.post("/login")
async def login_endpoint(request: LoginRequest) -> JSONResponse:
    result = await authenticate_user(
        email=request.email,
        password=request.password,
    )
    return JSONResponse(status_code=200, content=result)


@router.get("/github", response_model=None)
async def github_oauth_redirect(redirect_uri: str | None = None) -> RedirectResponse:
    """Redirect to Github OAuth authorization page."""
    if not GITHUB_CLIENT_ID or not OAUTH_REDIRECT_URI:
        raise HTTPException(
            status_code=501,
            detail={"error": "not_implemented", "message": "Github login is not enabled on this server"}
        )

    # Generate random state for CSRF protection
    state = secrets.token_urlsafe(32)

    # Store state in Redis with expiration
    try:
        from agxp.api.redis import get_redis_client
        redis_client = await get_redis_client()
        await redis_client.setex(f"oauth_state:{state}", STATE_EXPIRE_SECONDS, redirect_uri or "")
        await redis_client.aclose()
    except Exception as e:
        logger.error(f"Failed to store OAuth state in Redis: {e}")
        raise HTTPException(
            status_code=500,
            detail={"error": "internal_error", "message": "Login service is temporarily unavailable"}
        )

    # Build Github OAuth URL
    params = {
        "client_id": GITHUB_CLIENT_ID,
        "redirect_uri": OAUTH_REDIRECT_URI,
        "state": state,
        "scope": "user:email",
        "allow_signup": "true"
    }
    auth_url = f"{GITHUB_OAUTH_URL}?{urlencode(params)}"

    return RedirectResponse(auth_url)


@router.get("/github/callback", response_model=None)
async def github_oauth_callback(code: str, state: str) -> RedirectResponse | HTMLResponse:
    """Handle Github OAuth callback."""
    if not GITHUB_CLIENT_ID or not GITHUB_CLIENT_SECRET or not OAUTH_REDIRECT_URI:
        raise HTTPException(
            status_code=501,
            detail={"error": "not_implemented", "message": "Github login is not enabled on this server"}
        )

    # Verify state
    try:
        from agxp.api.redis import get_redis_client
        redis_client = await get_redis_client()
        stored_redirect_uri = await redis_client.get(f"oauth_state:{state}")

        if stored_redirect_uri is None:
            return HTMLResponse(
                content="""
                <html>
                    <body style="text-align: center; padding: 50px; font-family: sans-serif;">
                        <h1>Invalid or expired authorization request</h1>
                        <p>Please try logging in again.</p>
                    </body>
                </html>
                """,
                status_code=400
            )

        # Delete state from Redis to prevent reuse
        await redis_client.delete(f"oauth_state:{state}")
        await redis_client.aclose()
    except Exception as e:
        logger.error(f"Failed to verify OAuth state from Redis: {e}")
        return HTMLResponse(
            content="""
            <html>
                <body style="text-align: center; padding: 50px; font-family: sans-serif;">
                    <h1>Login service is temporarily unavailable</h1>
                    <p>Please try again later.</p>
                </body>
            </html>
            """,
            status_code=500
        )

    stored_redirect_uri = stored_redirect_uri.decode("utf-8")

    try:
        # Get user info from Github
        github_user = await get_github_user_info(code)

        # Create or update user
        auth_result = await create_or_update_github_user(github_user)
        token = auth_result["token"]

        if stored_redirect_uri:
            # Redirect to CLI callback with token
            redirect_url = f"{stored_redirect_uri}?token={token}"
            return RedirectResponse(redirect_url)
        else:
            # Show success page if no redirect URI provided
            return HTMLResponse(
                content=f"""
                <html>
                    <body style="text-align: center; padding: 50px; font-family: sans-serif;">
                        <h1>Login successful!</h1>
                        <p>You can now close this window and return to the CLI.</p>
                        <p style="font-family: monospace; background: #f5f5f5; padding: 10px; display: inline-block;">
                            Token: {token}
                        </p>
                    </body>
                </html>
                """
            )
    except HTTPException as e:
        error_message = e.detail.get("message", "Unknown error")
        return HTMLResponse(
            content=f"""
            <html>
                <body style="text-align: center; padding: 50px; font-family: sans-serif;">
                    <h1>Login failed</h1>
                    <p>{error_message}</p>
                    <p>Please try again later.</p>
                </body>
            </html>
            """,
            status_code=e.status_code
        )
    except Exception as e:
        return HTMLResponse(
            content=f"""
            <html>
                <body style="text-align: center; padding: 50px; font-family: sans-serif;">
                    <h1>Login failed</h1>
                    <p>An unexpected error occurred: {str(e)}</p>
                    <p>Please try again later.</p>
                </body>
            </html>
            """,
            status_code=500
        )
