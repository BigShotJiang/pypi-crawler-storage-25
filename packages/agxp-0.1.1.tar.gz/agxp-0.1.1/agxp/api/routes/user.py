"""User info API endpoints."""
from fastapi import APIRouter, Depends
from datetime import date
from agxp.auth.dependency import require_auth
from agxp.auth.models import AuthIdentity
from agxp.db.pool import get_pool

router = APIRouter(prefix="/api/v1/user", tags=["user"])

@router.get("/me", summary="Get current user status and statistics")
async def get_current_user_info(current_user: AuthIdentity = Depends(require_auth)):
    pool = await get_pool()
    user_id = current_user.user_id
    anon_session_id = current_user.anon_session_id
    is_anonymous = current_user.is_anonymous

    # Get credit balance
    credit_balance = 0
    if is_anonymous:
        credit_row = await pool.fetchrow(
            "SELECT credit_balance FROM anonymous_sessions WHERE id = $1",
            anon_session_id
        )
        if credit_row:
            credit_balance = credit_row["credit_balance"]
    else:
        credit_row = await pool.fetchrow(
            "SELECT balance FROM credit_accounts WHERE user_id = $1",
            user_id
        )
        if credit_row:
            credit_balance = credit_row["balance"]

    # Count user's contributed experiences
    experience_count = 0
    if not is_anonymous:
        experience_count = await pool.fetchval(
            "SELECT COUNT(*) FROM experiences WHERE user_id = $1 AND deleted_at IS NULL",
            user_id
        ) or 0

    # Count today's search queries
    today_start = date.today().strftime("%Y-%m-%d 00:00:00")
    search_count = 0
    if is_anonymous:
        search_count = await pool.fetchval(
            """
            SELECT COUNT(*) FROM query_logs
            WHERE anon_session_id = $1 AND created_at >= $2
            """,
            anon_session_id, today_start
        ) or 0
    else:
        search_count = await pool.fetchval(
            """
            SELECT COUNT(*) FROM query_logs
            WHERE user_id = $1 AND created_at >= $2
            """,
            user_id, today_start
        ) or 0

    return {
        "user_type": "anonymous" if is_anonymous else "logged_in",
        "credit_balance": credit_balance,
        "experience_count": experience_count,
        "search_count_today": search_count,
        "max_search_per_day": 50,
        "server_version": "0.1.0"
    }
