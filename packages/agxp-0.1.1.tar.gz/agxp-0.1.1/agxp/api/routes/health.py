"""Health check API endpoints."""
from fastapi import APIRouter

router = APIRouter()

@router.get("/health", summary="Service health check")
async def health_check():
    return {
        "status": "ok",
        "version": "0.1.0",
        "features": ["search", "contribute", "feedback", "auth"]
    }
