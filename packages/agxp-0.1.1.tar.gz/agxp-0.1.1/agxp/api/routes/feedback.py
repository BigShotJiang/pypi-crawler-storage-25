"""
Feedback endpoint — POST /api/v1/feedback

Accepts experience feedback (useful/not-useful), updates quality_score,
records in search_feedback, and awards 1 credit.

Rate limit: each experience can receive at most 1 feedback per day (global).

Module-level helpers are plain async functions so unit tests can patch them.
"""
from __future__ import annotations

import logging
import uuid as _uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, field_validator

from agxp.auth.dependency import require_auth
from agxp.auth.models import AuthIdentity

logger = logging.getLogger(__name__)

router = APIRouter()

# Feedback delta constants (same as local scoring)
FEEDBACK_DELTA_USEFUL = 0.05
FEEDBACK_DELTA_NOT_USEFUL = -0.03


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class FeedbackRequest(BaseModel):
    experience_id: str = Field(..., description="UUID of the experience")
    useful: bool = Field(..., description="Whether the experience was useful")
    query_log_id: str | None = Field(None, description="Optional UUID of the search query log that this feedback is associated with")
    position: int = Field(1, description="Optional position of the experience in the search results")

    @field_validator("experience_id")
    @classmethod
    def validate_uuid(cls, v: str) -> str:
        try:
            _uuid.UUID(v)
        except ValueError:
            raise ValueError(f"Invalid UUID: {v}")
        return v

    @field_validator("query_log_id")
    @classmethod
    def validate_query_log_id(cls, v: str | None) -> str | None:
        if v is None:
            return None
        try:
            _uuid.UUID(v)
        except ValueError:
            raise ValueError(f"Invalid UUID: {v}")
        return v


# ---------------------------------------------------------------------------
# Module-level patchable DB helpers
# ---------------------------------------------------------------------------


async def get_experience(experience_id: str) -> dict | None:
    """Fetch experience by ID. Returns dict or None if not found."""
    from agxp.db.pool import get_pool

    pool = await get_pool()
    row = await pool.fetchrow(
        "SELECT id, quality_score FROM experiences WHERE id = $1 AND deleted_at IS NULL",
        _uuid.UUID(experience_id),
    )
    if row is None:
        return None
    return {"id": str(row["id"]), "quality_score": float(row["quality_score"])}


async def check_feedback_rate_limit(experience_id: str) -> bool:
    """Return True if this experience already received feedback today."""
    from agxp.db.pool import get_pool

    pool = await get_pool()
    row = await pool.fetchrow(
        """
        SELECT count(*) AS cnt FROM search_feedback
        WHERE experience_id = $1
          AND created_at >= now()::date
        """,
        _uuid.UUID(experience_id),
    )
    return row["cnt"] > 0


async def update_quality_score(experience_id: str, delta: float) -> float:
    """Apply delta to quality_score, clamp to [0, 1], return new score."""
    from agxp.db.pool import get_pool

    pool = await get_pool()
    row = await pool.fetchrow(
        "SELECT quality_score FROM experiences WHERE id = $1 AND deleted_at IS NULL",
        _uuid.UUID(experience_id),
    )
    new_score = max(0.0, min(1.0, float(row["quality_score"]) + delta))
    await pool.execute(
        "UPDATE experiences SET quality_score = $1, updated_at = now() WHERE id = $2",
        new_score,
        _uuid.UUID(experience_id),
    )
    return new_score


async def record_feedback(
    user_id: str, experience_id: str, useful: bool, position: int = 1, query_log_id: str | None = None
) -> None:
    """Insert a row into search_feedback."""
    from agxp.db.pool import get_pool

    pool = await get_pool()
    await pool.execute(
        """
        INSERT INTO search_feedback (user_id, experience_id, was_useful, position, query_log_id)
        VALUES ($1, $2, $3, $4, $5)
        """,
        _uuid.UUID(user_id),
        _uuid.UUID(experience_id),
        useful,
        position,
        _uuid.UUID(query_log_id) if query_log_id else None,
    )


async def award_credit(user_id: str, experience_id: str) -> None:
    """Award 1 credit for giving feedback."""
    from agxp.db.pool import get_pool

    pool = await get_pool()
    # Ensure credit_account exists
    await pool.execute(
        """
        INSERT INTO credit_accounts (user_id, balance, pending_balance)
        VALUES ($1, 0, 0)
        ON CONFLICT (user_id) DO NOTHING
        """,
        _uuid.UUID(user_id),
    )
    await pool.execute(
        """
        UPDATE credit_accounts SET balance = balance + 1 WHERE user_id = $1
        """,
        _uuid.UUID(user_id),
    )
    await pool.execute(
        """
        INSERT INTO credit_transactions (user_id, amount, txn_type, description, experience_id)
        VALUES ($1, 1, 'earn_feedback', 'Feedback on experience', $2)
        """,
        _uuid.UUID(user_id),
        _uuid.UUID(experience_id),
    )


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.post("/feedback")
async def feedback_endpoint(
    request: FeedbackRequest,
    identity: AuthIdentity = Depends(require_auth),
) -> dict:
    """Accept feedback on an experience."""
    # 1. Check experience exists
    experience = await get_experience(request.experience_id)
    if experience is None:
        raise HTTPException(status_code=404, detail="Experience not found")

    # 2. Rate limit: 1 feedback per experience per day (global)
    is_limited = await check_feedback_rate_limit(request.experience_id)
    if is_limited:
        raise HTTPException(
            status_code=429,
            detail="This experience already received feedback today",
        )

    # 3. Update quality score
    delta = FEEDBACK_DELTA_USEFUL if request.useful else FEEDBACK_DELTA_NOT_USEFUL
    new_score = await update_quality_score(request.experience_id, delta)

    # 4. Record feedback
    await record_feedback(
        user_id=identity.user_id,
        experience_id=request.experience_id,
        useful=request.useful,
        position=request.position,
        query_log_id=request.query_log_id,
    )

    # 5. Award credit (failure is non-fatal)
    credits_earned = 1
    try:
        await award_credit(identity.user_id, request.experience_id)
    except Exception:
        logger.warning(
            "Failed to award credit for feedback on %s", request.experience_id,
            exc_info=True,
        )
        credits_earned = 0

    return {
        "experience_id": request.experience_id,
        "quality_score": round(new_score, 6),
        "status": "updated",
        "credits_earned": credits_earned,
    }
