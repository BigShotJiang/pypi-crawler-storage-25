"""
Contribute endpoint — POST /api/v1/contribute

Accepts a new experience contribution, persists it to the DB, indexes it for
BM25 full-text search, and dispatches the async embedding + quality scoring
pipeline.

Module-level helpers (insert_experience, fts_index_experience, dispatch_embed)
are plain functions so unit tests can patch them without touching DI machinery.
"""
from __future__ import annotations

import json
import uuid
from enum import Enum
from typing import Annotated

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, field_validator

from agxp.auth.dependency import require_auth
from agxp.auth.models import AuthIdentity
from agxp.services.inline_quality_writer import compute_completeness_score
from agxp.workers.credit import credits_for_quality

router = APIRouter()


# ---------------------------------------------------------------------------
# Request model
# ---------------------------------------------------------------------------


class OutcomeType(str, Enum):
    solved = "solved"
    workaround = "workaround"
    unresolved = "unresolved"


class ContributeRequest(BaseModel):
    situation: Annotated[str, Field(min_length=50, max_length=4000)]
    solution: Annotated[str, Field(min_length=50, max_length=4000)]
    outcome_type: OutcomeType
    lessons: Annotated[str, Field(min_length=30, max_length=2000)]
    domain: Annotated[str, Field(max_length=64)]
    task_type: Annotated[str, Field(max_length=64)]
    language: Annotated[str, Field(max_length=8)]

    failed_approaches: Annotated[str | None, Field(max_length=4000)] = None
    environment: dict | None = None
    subdomain: Annotated[str | None, Field(max_length=64)] = None
    tags: list[str] | None = None

    @field_validator("tags")
    @classmethod
    def validate_tags(cls, v: list[str] | None) -> list[str] | None:
        if v is None:
            return v
        if len(v) > 10:
            raise ValueError("tags must have at most 10 items")
        for tag in v:
            if len(tag) > 32:
                raise ValueError(f"each tag must be at most 32 characters, got {len(tag)}")
        return v


# ---------------------------------------------------------------------------
# Module-level patchable helpers
# ---------------------------------------------------------------------------


async def insert_experience(experience_id: str, request: ContributeRequest, user_id: str) -> None:
    """Insert a new experience row into PostgreSQL via asyncpg."""
    from agxp.db.pool import get_pool

    pool = await get_pool()
    await pool.execute(
        """
        INSERT INTO experiences (
            id, user_id, domain, subdomain, task_type,
            situation, failed_approaches, solution, outcome_type,
            lessons, environment, tags, language
        ) VALUES (
            $1, $2, $3, $4, $5,
            $6, $7, $8, $9,
            $10, $11, $12, $13
        )
        """,
        uuid.UUID(experience_id),
        uuid.UUID(user_id),
        request.domain,
        request.subdomain,
        request.task_type,
        request.situation,
        request.failed_approaches,
        request.solution,
        request.outcome_type.value,
        request.lessons,
        json.dumps(request.environment) if request.environment is not None else None,
        request.tags or [],
        request.language,
    )


async def fts_index_experience(experience_id: str, doc: dict) -> None:
    """Index the experience document in the BM25 full-text search backend."""
    from agxp.config.backends import FTS_BACKEND

    await FTS_BACKEND.index(experience_id, doc)


def dispatch_embed(experience_id: str, user_id: str) -> None:
    """Dispatch the Celery embed_experience task."""
    from agxp.workers.embed import embed_experience

    embed_experience.delay(experience_id, user_id=user_id)


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.post("/contribute", status_code=202)
async def contribute_endpoint(
    request: ContributeRequest,
    identity: AuthIdentity = Depends(require_auth),
) -> JSONResponse:
    if identity.is_anonymous:
        return JSONResponse(
            status_code=403,
            content={"error": "forbidden", "message": "Anonymous users cannot contribute experiences."},
        )

    experience_id = str(uuid.uuid4())

    # Step 1: Persist to DB
    await insert_experience(experience_id, request, identity.user_id)

    # Step 2: BM25 in-process index — include all searchable text fields
    env = request.environment
    env_text = " ".join(f"{k}: {v}" for k, v in env.items()) if isinstance(env, dict) else ""
    tags_text = " ".join(request.tags) if request.tags else ""
    fts_doc = {
        "situation": request.situation,
        "solution": request.solution,
        "lessons": request.lessons,
        "failed_approaches": request.failed_approaches or "",
        "environment": env_text,
        "tags": tags_text,
    }
    await fts_index_experience(experience_id, fts_doc)

    # Step 3: Dispatch async embedding pipeline
    dispatch_embed(experience_id, identity.user_id)

    # Step 4: Estimate credits from completeness score
    row_for_score = {
        "failed_approaches": request.failed_approaches,
        "environment": request.environment,
        "solution": request.solution,
        "lessons": request.lessons,
        "tags": request.tags,
    }
    estimated_credits = credits_for_quality(compute_completeness_score(row_for_score))

    return JSONResponse(
        status_code=202,
        content={
            "experience_id": experience_id,
            "status": "pending_scoring",
            "estimated_credits": estimated_credits,
            "message": "Experience accepted. Embedding and quality scoring in progress.",
        },
    )
