"""
Redis connection utility with Sentinel support for Kvrocks compatibility.

Supports two modes:
- Direct connection via REDIS_URL
- Sentinel mode via REDIS_USE_SENTINEL=true (for Kvrocks clusters)
"""

from __future__ import annotations

import logging
import os
from typing import Optional, Any, Callable
from functools import wraps

import redis.asyncio

logger = logging.getLogger(__name__)


def get_redis_url() -> str:
    """Get the configured Redis URL."""
    return os.getenv("REDIS_URL", "redis://localhost:6379/0")


def is_sentinel_mode() -> bool:
    """Check if Sentinel mode is enabled."""
    return os.getenv("REDIS_USE_SENTINEL", "").lower() in ("true", "1", "yes")


def get_sentinel_config() -> dict:
    """Parse Sentinel configuration from environment variables."""
    sentinel_hosts = os.getenv("REDIS_SENTINEL_HOSTS", "")
    if not sentinel_hosts:
        raise ValueError("REDIS_SENTINEL_HOSTS is required when using Sentinel mode")

    return {
        "sentinels": [tuple(host.split(":")) for host in sentinel_hosts.split(",") if host.strip()],
        "master_name": os.getenv("REDIS_MASTER_NAME", "mymaster"),
        "sentinel_password": os.getenv("REDIS_SENTINEL_PASSWORD"),
        "namespace_password": os.getenv("REDIS_NAMESPACE_PASSWORD"),
        "db": int(os.getenv("REDIS_DB", "0")),
    }


class LoggingRedisWrapper:
    """Wrapper for Redis client that logs all operations."""

    def __init__(self, redis_client: redis.asyncio.Redis):
        self._client = redis_client

    def __getattr__(self, name: str) -> Any:
        """Wrap all Redis command methods to add logging."""
        attr = getattr(self._client, name)

        if callable(attr) and not name.startswith('_'):
            @wraps(attr)
            async def wrapped(*args, **kwargs):
                try:
                    print(f"[REDIS] Operation: {name} {' '.join(map(str, args))}")
                    result = await attr(*args, **kwargs)
                    print(f"[REDIS] Operation {name} completed successfully")
                    return result
                except Exception as e:
                    print(f"[REDIS] Operation {name} failed: {e}")
                    raise

            return wrapped

        return attr

    async def aclose(self):
        """Forward close method to the underlying client."""
        return await self._client.aclose()


async def get_redis_client() -> redis.asyncio.Redis:
    """
    Create a Redis client based on environment configuration.

    Returns an async Redis client that must be closed after use with aclose().
    """
    if is_sentinel_mode():
        config = get_sentinel_config()
        sentinel = redis.asyncio.Sentinel(
            config["sentinels"],
            sentinel_kwargs={"password": config["sentinel_password"]}
            if config["sentinel_password"]
            else {},
            password=config["namespace_password"],  # Kvrocks Namespace 密码 (Token)
            db=config["db"],
        )
        client = sentinel.master_for(config["master_name"])
    else:
        client = redis.asyncio.from_url(get_redis_url())

    # Wrap client with logging
    return LoggingRedisWrapper(client)


async def ping_redis() -> bool:
    """
    Test Redis connectivity.

    Returns True if Redis responds to PING, False otherwise.
    """
    client = None
    try:
        client = await get_redis_client()
        await client.ping()
        return True
    except Exception:
        return False
    finally:
        if client:
            await client.aclose()
