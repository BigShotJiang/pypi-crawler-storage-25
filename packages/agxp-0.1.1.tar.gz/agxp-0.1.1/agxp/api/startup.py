"""
Startup validation checks for the AGXP server.

Each check verifies a specific dependency. Critical dependencies (PostgreSQL,
pgvector) raise RuntimeError on failure. Non-critical ones (Redis) log a
warning and return False.
"""
from __future__ import annotations

import logging
import os

import asyncpg
import redis.asyncio

logger = logging.getLogger(__name__)


def check_env_vars() -> None:
    """Verify required environment variables are set."""
    if not os.environ.get("DATABASE_URL"):
        raise RuntimeError(
            "DATABASE_URL environment variable is not set. "
            "Example: postgresql+asyncpg://user:pass@host:5432/dbname"
        )

    # Check Github OAuth environment variables (required for login functionality)
    required_oauth_vars = ["GITHUB_CLIENT_ID", "GITHUB_CLIENT_SECRET", "OAUTH_REDIRECT_URI"]
    missing_vars = [var for var in required_oauth_vars if not os.environ.get(var)]
    if missing_vars:
        logger.warning(
            "Github OAuth functionality will be disabled. Missing environment variables: %s. "
            "To enable Github login, set these variables and restart the server.",
            ", ".join(missing_vars)
        )


async def check_database(dsn: str) -> None:
    """Verify PostgreSQL is reachable by running SELECT 1."""
    try:
        conn = await asyncpg.connect(dsn)
    except Exception as exc:
        raise RuntimeError(
            f"Cannot connect to PostgreSQL database: {exc}"
        ) from exc
    try:
        await conn.execute("SELECT 1")
    finally:
        await conn.close()


async def check_pgvector(dsn: str) -> None:
    """Verify the pgvector extension is installed in the database."""
    try:
        conn = await asyncpg.connect(dsn)
    except Exception as exc:
        raise RuntimeError(
            f"Cannot connect to PostgreSQL to verify pgvector: {exc}"
        ) from exc
    try:
        result = await conn.fetchval(
            "SELECT extname FROM pg_extension WHERE extname = 'vector'"
        )
        if result is None:
            raise RuntimeError(
                "pgvector extension is not installed. "
                "Run: CREATE EXTENSION vector;"
            )
    finally:
        await conn.close()


async def check_redis(url: str | None = None) -> bool:
    """Ping Redis. Returns True if available, False with warning if not."""
    try:
        if url:
            from agxp.api.redis import LoggingRedisWrapper
            client = LoggingRedisWrapper(redis.asyncio.from_url(url))
        else:
            from agxp.api.redis import get_redis_client
            client = await get_redis_client()
        try:
            await client.ping()
            return True
        finally:
            await client.aclose()
    except Exception as exc:
        if url:
            logger.warning("Redis is not available at %s: %s", url, exc)
        else:
            logger.warning("Redis is not available with current configuration: %s", exc)
        return False
