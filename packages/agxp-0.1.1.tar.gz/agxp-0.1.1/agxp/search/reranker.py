"""
CrossEncoderReranker — abstract interface for cross-encoder reranking.

Implementations:
1. LocalMiniLMReranker: 本地cross-encoder/ms-marco-MiniLM-L-6-v2模型
2. SiliconFlowAPIReranker: 硅基流动API重排（支持通用重排API协议）
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import List, Tuple
import logging
import os

logger = logging.getLogger(__name__)


class CrossEncoderReranker(ABC):
    @abstractmethod
    async def rerank(
        self,
        query: str,
        candidates: list[tuple[str, str]],  # (experience_id, text_to_score)
    ) -> list[tuple[str, float]]:           # (experience_id, score) sorted descending
        """
        Score each (query, text) pair and return sorted by score descending.
        Empty candidates list must return an empty list.
        """
        ...


class LocalMiniLMReranker(CrossEncoderReranker):
    """本地MiniLM重排器，使用cross-encoder/ms-marco-MiniLM-L-6-v2模型"""
    def __init__(self, model_name: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"):
        from sentence_transformers import CrossEncoder
        print("Loading local reranking model (first run may download ~90MB)...")
        self._model = CrossEncoder(model_name)

    async def rerank(self, query: str, candidates: list[tuple[str, str]]) -> list[tuple[str, float]]:
        if not candidates:
            return []
        # 同步模型放到线程池执行避免阻塞事件循环
        import asyncio
        pairs = [(query, text) for (_, text) in candidates]
        scores = await asyncio.get_event_loop().run_in_executor(None, self._model.predict, pairs)
        # 按得分降序排序
        ranked = sorted(zip(candidates, scores), key=lambda x: x[1], reverse=True)
        return [(doc[0], float(score)) for doc, score in ranked]


class SiliconFlowAPIReranker(CrossEncoderReranker):
    """硅基流动API重排器，兼容通用RERANK API协议"""
    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None,
        api_url: str | None = None
    ):
        try:
            global aiohttp
            import aiohttp
        except ImportError:
            raise ImportError("需要安装aiohttp才能使用API重排器: pip install aiohttp")

        self._api_key = api_key or os.getenv("RERANK_API_KEY")
        if not self._api_key:
            raise ValueError("RERANK_API_KEY environment variable is required for API reranker")
        self._model = model or os.getenv("RERANK_MODEL", "BAAI/bge-reranker-v2-m3")
        self._api_url = api_url or os.getenv("RERANK_API_URL", "https://api.siliconflow.cn/v1/rerank")
        self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30))

    async def rerank(self, query: str, candidates: list[tuple[str, str]]) -> list[tuple[str, float]]:
        if not candidates:
            return []
        try:
            doc_texts = [text for (_, text) in candidates]
            payload = {
                "model": self._model,
                "query": query,
                "documents": doc_texts
            }
            headers = {
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json"
            }
            async with self._session.post(self._api_url, json=payload, headers=headers) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    logger.warning(f"重排API调用失败: {resp.status} {error_text[:100]}..., 降级使用原始排序")
                    return [(doc[0], 1.0) for doc in candidates]
                result = await resp.json()
                # 解析返回结果，按index对应原文档
                ranked = []
                for item in result["results"]:
                    idx = item["index"]
                    score = item["relevance_score"]
                    exp_id = candidates[idx][0]
                    ranked.append((exp_id, float(score)))
                # 按得分降序排序
                ranked.sort(key=lambda x: x[1], reverse=True)
                return ranked
        except Exception as e:
            logger.warning(f"重排API异常: {str(e)}, 降级使用原始排序")
            return [(doc[0], 1.0) for doc in candidates]
