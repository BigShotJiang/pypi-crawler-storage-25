"""
BgeM3LocalBackend — EmbeddingBackend using locally loaded bge-m3 model.
Requires optional dependencies: torch, transformers, sentence-transformers.
Only used for self-hosted deployments with GPU acceleration.
"""

import os
from typing import Optional
from agxp.search.backends.embedding_backend import EmbeddingBackend

# Lazy import dependencies only when this backend is actually used
_model: Optional[object] = None
_tokenizer: Optional[object] = None

class BgeM3LocalBackend(EmbeddingBackend):
    @property
    def dimensions(self) -> int:
        return 1024

    @property
    def max_tokens(self) -> int:
        return 8192

    def _load_model(self) -> None:
        """Lazy load the bge-m3 model and tokenizer on first use."""
        global _model, _tokenizer
        if _model is None or _tokenizer is None:
            try:
                from sentence_transformers import SentenceTransformer
            except ImportError:
                raise RuntimeError(
                    "BgeM3LocalBackend requires optional dependencies: "
                    "pip install sentence-transformers torch transformers"
                )

            model_name = os.getenv("BGEM3_LOCAL_MODEL_PATH", "BAAI/bge-m3")
            device = os.getenv("BGEM3_DEVICE", "cuda" if torch.cuda.is_available() else "cpu")

            _model = SentenceTransformer(model_name, device=device)
            _tokenizer = _model.tokenizer

    async def embed(
        self,
        texts: list[str],
        batch_size: int = 32,
    ) -> list[list[float]]:
        self._load_model()

        # Run inference in thread pool to avoid blocking event loop
        import asyncio
        from functools import partial

        embed_func = partial(
            _model.encode,
            texts,
            batch_size=batch_size,
            normalize_embeddings=True,
            convert_to_numpy=True
        )

        embeddings = await asyncio.get_event_loop().run_in_executor(None, embed_func)

        return embeddings.tolist()
