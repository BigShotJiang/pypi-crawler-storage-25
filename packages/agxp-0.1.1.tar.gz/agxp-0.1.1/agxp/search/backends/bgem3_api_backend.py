"""
BgeM3ApiBackend — EmbeddingBackend using bge-m3 via external API.
Implemented in Issue #3 (Search engine).
"""

from agxp.search.backends.embedding_backend import EmbeddingBackend


import os
import httpx

class BgeM3ApiBackend(EmbeddingBackend):
    @property
    def dimensions(self) -> int:
        return 1024

    @property
    def max_tokens(self) -> int:
        return 8192

    async def embed(
        self,
        texts: list[str],
        batch_size: int = 32,
    ) -> list[list[float]]:
        api_url = os.getenv("BGEM3_API_URL", "https://example.com/v1/embeddings")
        api_key = os.getenv("BGEM3_API_KEY", "")

        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        all_embeddings = []

        # Use httpx for async HTTP requests
        async with httpx.AsyncClient() as client:
            for i in range(0, len(texts), batch_size):
                batch_texts = texts[i:i + batch_size]
                
                payload = {
                    "model": "BAAI/bge-m3", 
                    "input": batch_texts
                }
                
                response = await client.post(api_url, headers=headers, json=payload)
                response.raise_for_status()

                data = response.json()
                # Assuming standard OpenAI-compatible API response format
                batch_embeddings = [item["embedding"] for item in data.get("data", [])]
                all_embeddings.extend(batch_embeddings)

        return all_embeddings
