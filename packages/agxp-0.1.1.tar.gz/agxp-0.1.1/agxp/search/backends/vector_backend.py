"""
VectorSearchBackend — abstract interface for vector similarity search.

Default implementation: PgvectorBackend (PostgreSQL + pgvector HNSW).
Future: QdrantBackend, MilvusBackend for distributed scale.
"""

from abc import ABC, abstractmethod


class VectorSearchBackend(ABC):
    @abstractmethod
    async def search(
        self,
        field: str,
        embedding: list[float],
        limit: int,
        filters: dict,
    ) -> list[tuple[str, float]]:
        """Return [(experience_id, score), ...] sorted by descending score."""
        ...

    @abstractmethod
    async def upsert(
        self,
        experience_id: str,
        field: str,
        embedding: list[float],
    ) -> None:
        """Insert or update the embedding for a given experience field."""
        ...

    @abstractmethod
    async def delete(self, experience_id: str) -> None:
        """Remove all field embeddings for an experience."""
        ...
