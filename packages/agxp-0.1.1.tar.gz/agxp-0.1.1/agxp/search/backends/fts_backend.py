"""
FullTextSearchBackend — abstract interface for BM25 full-text search.

Default implementation: TantivyBackend (in-process Rust via tantivy).
Future: TypesenseBackend, ElasticBackend for distributed scale.
"""

from abc import ABC, abstractmethod


class FullTextSearchBackend(ABC):
    @abstractmethod
    async def search(
        self,
        query: str,
        fields: list[str],
        field_boosts: dict[str, float],
        filters: dict,
        limit: int,
    ) -> list[tuple[str, float]]:
        """Return [(experience_id, bm25_score), ...] sorted by descending score."""
        ...

    @abstractmethod
    async def index(self, experience_id: str, document: dict) -> None:
        """Add or update a document in the full-text index."""
        ...

    @abstractmethod
    async def delete(self, experience_id: str) -> None:
        """Remove a document from the full-text index."""
        ...
