"""
PgvectorBackend — VectorSearchBackend backed by PostgreSQL + pgvector HNSW.

Each of the 6 per-field embeddings is stored as a dedicated column in the
`experiences` table.  HNSW indexes (m=16, ef_construction=64, cosine ops)
are defined in the initial migration.

Constructor accepts an optional `pool` argument for dependency injection in
tests.  Production code uses the module-level singleton from agxp.db.pool.
"""
from __future__ import annotations

import logging
import uuid

import asyncpg

logger = logging.getLogger(__name__)

from agxp.search.backends.vector_backend import VectorSearchBackend

# Maps the logical field name used by callers to the experiences column name.
_FIELD_COLUMN: dict[str, str] = {
    "situation": "embedding_situation",
    "solution": "embedding_solution",
    "lessons": "embedding_lessons",
    "failed_approaches": "embedding_failed",
    "tags": "embedding_tags",
    "environment": "embedding_environment",
}

# Only these keys are allowed in the `filters` dict to prevent column-name injection.
_ALLOWED_FILTER_COLUMNS: frozenset[str] = frozenset(
    {"domain", "task_type", "language", "is_published"}
)


class PgvectorBackend(VectorSearchBackend):
    def __init__(self, pool: asyncpg.Pool | None = None) -> None:
        self._pool = pool

    async def _get_pool(self) -> asyncpg.Pool:
        if self._pool is None:
            from agxp.db.pool import get_pool

            self._pool = await get_pool()
        return self._pool

    async def search(
        self,
        field: str,
        embedding: list[float],
        limit: int,
        filters: dict,
    ) -> list[tuple[str, float]]:
        """
        Return [(experience_id, cosine_similarity), ...] sorted by descending
        similarity.  Uses the HNSW index for sub-linear ANN search.
        """
        col = _FIELD_COLUMN[field]
        pool = await self._get_pool()

        # Build WHERE clause dynamically; params[0]=embedding, params[1]=limit
        conditions = [f"{col} IS NOT NULL", "deleted_at IS NULL"]
        params: list = [embedding, limit]

        for key, value in filters.items():
            if key not in _ALLOWED_FILTER_COLUMNS:
                raise ValueError(f"Unknown filter key: {key!r}")
            params.append(value)
            conditions.append(f"{key} = ${len(params)}")

        where = " AND ".join(conditions)
        sql = f"""
            SELECT id, 1 - ({col} <=> $1) AS score, quality_score,
                   completeness_score, community_score, uniqueness_score
            FROM experiences
            WHERE {where}
            ORDER BY {col} <=> $1
            LIMIT $2
        """

        # 打印查询日志，embedding只显示前5个元素避免日志过长
        short_embedding = params[0][:5] + ["..."] if len(params[0]) > 5 else params[0]
        log_params = [short_embedding] + params[1:]
        print(f"\n[PGVECTOR QUERY] SQL: {sql.strip()}", flush=True)
        print(f"[PGVECTOR PARAMS] {log_params}\n", flush=True)

        rows = await pool.fetch(sql, *params)
        print(f"[PGVECTOR RESULTS] 返回 {len(rows)} 条结果:", flush=True)
        for row in rows:
            comp = float(row["completeness_score"]) if row["completeness_score"] is not None else 0.0
            comm = float(row["community_score"]) if row["community_score"] is not None else 0.0
            uniq = float(row["uniqueness_score"]) if row["uniqueness_score"] is not None else 0.0
            print(f"  ID: {str(row['id'])[:8]}..., 相似度: {float(row['score']):.4f}, 质量分: {float(row['quality_score']):.4f} (唯一:{uniq:.2f}, 完整:{comp:.2f}, 社区:{comm:.2f})", flush=True)
        return [(str(row["id"]), float(row["score"])) for row in rows]

    async def upsert(
        self,
        experience_id: str,
        field: str,
        embedding: list[float],
    ) -> None:
        """Set the embedding column for the given field on an existing experience row."""
        col = _FIELD_COLUMN[field]
        pool = await self._get_pool()
        await pool.execute(
            f"UPDATE experiences SET {col} = $1, updated_at = now() WHERE id = $2",
            embedding,
            uuid.UUID(experience_id),
        )

    async def delete(self, experience_id: str) -> None:
        """Set all embedding columns to NULL for the given experience."""
        pool = await self._get_pool()
        await pool.execute(
            """
            UPDATE experiences SET
                embedding_situation   = NULL,
                embedding_solution    = NULL,
                embedding_lessons     = NULL,
                embedding_failed      = NULL,
                embedding_tags        = NULL,
                embedding_environment = NULL,
                updated_at            = now()
            WHERE id = $1
            """,
            uuid.UUID(experience_id),
        )
