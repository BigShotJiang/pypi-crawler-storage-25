"""
EmbeddingBackend — abstract interface for text embedding generation.

Default implementation: BgeM3ApiBackend (bge-m3 via API, 1024-dim multilingual).
Future: BgeM3LocalBackend (self-hosted GPU cluster).
"""

from abc import ABC, abstractmethod


class EmbeddingBackend(ABC):
    @abstractmethod
    async def embed(
        self,
        texts: list[str],
        batch_size: int = 32,
    ) -> list[list[float]]:
        """Return a list of 1024-dim embedding vectors, one per input text."""
        ...

    @property
    @abstractmethod
    def dimensions(self) -> int:
        """Embedding vector size. Always 1024 for bge-m3."""
        ...

    @property
    @abstractmethod
    def max_tokens(self) -> int:
        """Maximum number of tokens per input text."""
        ...
