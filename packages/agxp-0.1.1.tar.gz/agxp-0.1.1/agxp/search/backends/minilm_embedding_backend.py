"""
MiniLMEmbeddingBackend — lightweight local embedding using all-MiniLM-L6-v2.

384-dim, ~80MB model. Lazy-loaded on first embed() call.
Suitable for Phase 1 local-first mode where BgeM3 (1.3GB) is overkill.
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys
import threading

import numpy as np

from agxp.search.backends.embedding_backend import EmbeddingBackend


class MiniLMEmbeddingBackend(EmbeddingBackend):
    """Local sentence-transformers embedding with all-MiniLM-L6-v2."""

    _MODEL_NAME = "all-MiniLM-L6-v2"

    def __init__(self) -> None:
        self._model = None
        self._lock = threading.Lock()

    @property
    def dimensions(self) -> int:
        return 384

    @property
    def max_tokens(self) -> int:
        return 256

    def _get_model(self):
        """Lazy-load the sentence-transformers model (thread-safe)."""
        if self._model is None:
            with self._lock:
                if self._model is None:
                    print("Loading embedding model (first run may download ~90MB)...", file=sys.stderr, flush=True)
                    # Suppress noisy HuggingFace/transformers logs
                    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
                    logging.getLogger("sentence_transformers").setLevel(logging.WARNING)
                    logging.getLogger("transformers").setLevel(logging.ERROR)
                    logging.getLogger("huggingface_hub").setLevel(logging.ERROR)
                    from sentence_transformers import SentenceTransformer
                    self._model = SentenceTransformer(self._MODEL_NAME)
                    print("Embedding model ready.", file=sys.stderr, flush=True)
        return self._model

    async def embed(
        self,
        texts: list[str],
        batch_size: int = 32,
    ) -> list[list[float]]:
        if not texts:
            return []

        model = self._get_model()
        loop = asyncio.get_running_loop()

        def _encode():
            embeddings = model.encode(
                texts,
                batch_size=batch_size,
                normalize_embeddings=True,
                show_progress_bar=False,
            )
            return embeddings

        result = await loop.run_in_executor(None, _encode)

        # Convert numpy to list[list[float]]
        if isinstance(result, np.ndarray):
            return result.tolist()
        return [list(v) for v in result]
