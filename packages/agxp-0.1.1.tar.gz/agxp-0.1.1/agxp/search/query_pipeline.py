"""
QueryPipeline — orchestrates the hybrid search pipeline.

Pipeline steps (all inside run()):
  1. Embed query text with EmbeddingBackend
  2. Parallel: BM25 retrieval (FTS) + Vector retrieval (situation field)
  3. RRF fusion → top-150 unified candidate list
  4. Return top-150 RRF candidates (route handler applies limit after reranking)

Steps handled by the route handler (not in this class):
  5. Fetch full experience data from DB
  6. Apply min_quality filter
  7. Cross-encoder reranking (top-20)
  8. Quality blending
  9. NDJSON streaming

Pure helpers rrf_fusion and quality_blend are module-level functions so they
can be imported and tested independently.
"""
from __future__ import annotations

import asyncio
import logging

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

from agxp.search.backends.embedding_backend import EmbeddingBackend
from agxp.search.backends.fts_backend import FullTextSearchBackend
from agxp.search.backends.vector_backend import VectorSearchBackend
from agxp.search.reranker import CrossEncoderReranker

# BM25 field boosts (situation × 1.5, solution × 1.0, lessons × 2.0)
_BM25_FIELDS = ["situation", "solution", "lessons"]
_BM25_BOOSTS = {"situation": 1.5, "solution": 1.0, "lessons": 2.0}

# RRF and retrieval limits
_RETRIEVAL_LIMIT = 100
_RRF_LIMIT = 150


# ---------------------------------------------------------------------------
# QueryRequest
# ---------------------------------------------------------------------------


class QueryRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=2000)
    domain: str | None = None
    task_type: str | None = None
    language: str = "en"
    min_quality: float = 0.0
    limit: int = Field(default=10, ge=1, le=50)
    user_id: str | None = None


# ---------------------------------------------------------------------------
# Pure helper: RRF fusion
# ---------------------------------------------------------------------------


def rrf_fusion(
    rankings: list[list[tuple[str, float]]],
    k: int = 60,
    limit: int = 150,
) -> list[tuple[str, float]]:
    """
    Reciprocal Rank Fusion over multiple ranked lists.

    rrf_score(d) = Σ 1 / (k + rank_i(d))  [sum over all rankings]

    Args:
        rankings: List of ranked lists, each item is (experience_id, score).
                  Scores are used only for ordering within each list; the RRF
                  formula uses position, not score magnitude.
        k:        Constant to prevent high scores for top-ranked docs (default 60).
        limit:    Maximum number of results to return.

    Returns:
        [(experience_id, rrf_score)] sorted descending, up to `limit` items.
    """
    scores: dict[str, float] = {}
    for ranking in rankings:
        for rank, (exp_id, _) in enumerate(ranking, start=1):
            scores[exp_id] = scores.get(exp_id, 0.0) + 1.0 / (k + rank)
    result = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    return result[:limit]


# ---------------------------------------------------------------------------
# Pure helper: quality blend
# ---------------------------------------------------------------------------


def quality_blend(
    reranker_score: float,
    quality_score: float,
    alpha: float = 0.7,
) -> float:
    """
    Blend cross-encoder score with accumulated quality signal.

    final_score = alpha × reranker_score + (1 - alpha) × quality_score
    """
    return alpha * reranker_score + (1.0 - alpha) * quality_score


# ---------------------------------------------------------------------------
# QueryPipeline
# ---------------------------------------------------------------------------


class QueryPipeline:
    def __init__(
        self,
        embed_backend: EmbeddingBackend,
        vector_backend: VectorSearchBackend,
        fts_backend: FullTextSearchBackend,
        reranker: CrossEncoderReranker,
    ) -> None:
        self._embed = embed_backend
        self._vector = vector_backend
        self._fts = fts_backend
        self.reranker = reranker  # exposed for route handler

    async def run(self, request: QueryRequest) -> dict:
        """
        Execute steps 1-3 of the search pipeline with graceful degradation.

        Returns:
            dict with:
              - results: list of {"experience_id": str, "rrf_score": float}
              - warnings: list of str (empty if everything worked)
        """
        warnings: list[str] = []

        # 1. Build metadata filters
        filters: dict = {}
        if request.domain is not None:
            filters["domain"] = request.domain
        if request.task_type is not None:
            filters["task_type"] = request.task_type
        if request.language is not None:
            filters["language"] = request.language

        # 2. Embed query (needed for vector search)
        query_vec: list[float] | None = None
        try:
            query_vecs = await self._embed.embed([request.query])
            query_vec = query_vecs[0]
        except Exception as exc:
            logger.warning("Embedding failed: %s", exc)
            warnings.append(f"Embedding failed: {exc}")

        # 3. BM25 retrieval
        bm25_results: list[tuple[str, float]] = []
        try:
            bm25_results = await self._fts.search(
                query=request.query,
                fields=_BM25_FIELDS,
                field_boosts=_BM25_BOOSTS,
                filters=filters,
                limit=_RETRIEVAL_LIMIT,
            )
        except Exception as exc:
            logger.warning("BM25 search failed: %s", exc)
            warnings.append(f"BM25 search failed: {exc}")
        print(f"[QUERY FUNNEL 2/7] BM25全文搜索返回 {len(bm25_results)} 条结果", flush=True)

        # 4. Vector retrieval (skip if embed failed)
        vector_results: list[tuple[str, float]] = []
        if query_vec is not None:
            try:
                vector_results = await self._vector.search(
                    field="situation",
                    embedding=query_vec,
                    limit=_RETRIEVAL_LIMIT,
                    filters=filters,
                )
            except Exception as exc:
                logger.warning("Vector search failed: %s", exc)
                warnings.append(f"Vector search failed: {exc}")
        print(f"[QUERY FUNNEL 3/7] 向量搜索返回 {len(vector_results)} 条结果", flush=True)

        # 5. Warn if vector returned empty (embeddings may not exist yet)
        if query_vec is not None and not vector_results and not warnings:
            warnings.append(
                "Vector search returned 0 results — embeddings may not be generated yet"
            )

        # 6. If both backends returned empty, try PostgreSQL full-text fallback
        if not bm25_results and not vector_results:
            warnings.append(
                "Tantivy BM25 and vector search returned no results — "
                "falling back to PostgreSQL full-text search"
            )
            try:
                pg_results = await self._pg_fulltext_fallback(
                    request.query, filters, _RETRIEVAL_LIMIT
                )
                if pg_results:
                    bm25_results = pg_results
                    print(f"[QUERY FUNNEL 4/7] PG全文搜索fallback返回 {len(pg_results)} 条结果", flush=True)
            except Exception as exc:
                logger.warning("PG fulltext fallback failed: %s", exc)
                warnings.append(f"PG fulltext fallback also failed: {exc}")

        # 7. RRF fusion
        rankings = [r for r in [bm25_results, vector_results] if r]
        fused = rrf_fusion(rankings, limit=_RRF_LIMIT) if rankings else []
        print(f"[QUERY FUNNEL 5/7] RRF融合后得到 {len(fused)} 条唯一结果（去重后）", flush=True)

        results = [{"experience_id": exp_id, "rrf_score": score} for exp_id, score in fused]
        return {"results": results, "warnings": warnings}

    @staticmethod
    async def _pg_fulltext_fallback(
        query: str, filters: dict, limit: int
    ) -> list[tuple[str, float]]:
        """PostgreSQL to_tsvector fallback when Tantivy + vector are empty."""
        from agxp.db.pool import get_pool

        pool = await get_pool()

        # Build filter WHERE clauses
        where_parts = ["deleted_at IS NULL", "is_published = true"]
        params: list = []
        idx = 1

        # tsquery from user input
        tokens = query.strip().split()
        ts_tokens = " | ".join(tokens)  # OR matching
        where_parts.append(
            f"to_tsvector('english', situation || ' ' || solution || ' ' || lessons) "
            f"@@ to_tsquery('english', ${idx})"
        )
        params.append(ts_tokens)
        idx += 1

        for key in ("domain", "task_type", "language"):
            if key in filters:
                where_parts.append(f"{key} = ${idx}")
                params.append(filters[key])
                idx += 1

        where_sql = " AND ".join(where_parts)
        params.append(limit)

        rows = await pool.fetch(
            f"""
            SELECT id::text,
                   ts_rank(
                       to_tsvector('english', situation || ' ' || solution || ' ' || lessons),
                       to_tsquery('english', ${1})
                   ) AS score
            FROM experiences
            WHERE {where_sql}
            ORDER BY score DESC
            LIMIT ${idx}
            """,
            *params,
        )
        return [(row["id"], float(row["score"])) for row in rows]
