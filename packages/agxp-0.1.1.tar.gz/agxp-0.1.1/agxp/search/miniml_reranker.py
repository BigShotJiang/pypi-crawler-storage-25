"""
MiniLMCrossEncoder — CrossEncoderReranker backed by cross-encoder/ms-marco-MiniLM-L-6-v2.

Lazy-loads the model on first call (double-checked locking, thread-safe).
Model inference is CPU-bound; dispatched to the default thread pool executor
to avoid blocking the event loop.
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys
import threading

from agxp.search.reranker import CrossEncoderReranker

_MODEL_NAME = "cross-encoder/ms-marco-MiniLM-L-6-v2"


class MiniLMCrossEncoder(CrossEncoderReranker):
    def __init__(self) -> None:
        self._model = None
        self._load_lock = threading.Lock()

    def _get_model(self):
        if self._model is None:
            with self._load_lock:
                if self._model is None:
                    print("Loading reranking model (first run may download ~90MB)...", file=sys.stderr, flush=True)
                    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
                    logging.getLogger("sentence_transformers").setLevel(logging.WARNING)
                    logging.getLogger("transformers").setLevel(logging.ERROR)
                    logging.getLogger("huggingface_hub").setLevel(logging.ERROR)
                    from sentence_transformers import CrossEncoder
                    self._model = CrossEncoder(_MODEL_NAME)
                    print("Reranking model ready.", file=sys.stderr, flush=True)
        return self._model

    async def rerank(
        self,
        query: str,
        candidates: list[tuple[str, str]],
    ) -> list[tuple[str, float]]:
        if not candidates:
            return []

        model = self._get_model()
        pairs = [(query, text) for _, text in candidates]

        loop = asyncio.get_running_loop()
        raw_scores = await loop.run_in_executor(None, model.predict, pairs)

        result = [
            (exp_id, float(score))
            for (exp_id, _), score in zip(candidates, raw_scores)
        ]
        result.sort(key=lambda x: x[1], reverse=True)
        return result
