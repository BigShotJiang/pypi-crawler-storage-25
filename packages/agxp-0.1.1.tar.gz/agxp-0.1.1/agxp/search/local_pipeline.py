"""
LocalPipeline — synchronous contribute + async query for Phase 1 local mode.

Contribute: store → FTS index → embed → vector upsert (all inline, no Celery).
Query: embed → BM25 + vector → RRF → fetch from store → rerank → return.
"""
from __future__ import annotations

import asyncio
import logging

from agxp.search.backends.embedding_backend import EmbeddingBackend
from agxp.search.backends.fts_backend import FullTextSearchBackend
from agxp.search.backends.vector_backend import VectorSearchBackend
from agxp.search.query_pipeline import QueryRequest, rrf_fusion
from agxp.search.reranker import CrossEncoderReranker
from agxp.store.sqlite_store import SqliteStore

def _flatten_env_to_text(env: dict) -> str:
    """Recursively flatten nested environment dict to BM25-searchable text."""
    parts: list[str] = []
    for k, v in env.items():
        if isinstance(v, dict):
            parts.append(f"{k}: {_flatten_env_to_text(v)}")
        elif isinstance(v, list):
            items = [
                _flatten_env_to_text(item) if isinstance(item, dict) else str(item)
                for item in v if item is not None
            ]
            parts.append(f"{k}: {' '.join(items)}")
        elif v is not None:
            parts.append(f"{k}: {v}")
    return " ".join(parts)


logger = logging.getLogger(__name__)

_BM25_FIELDS = ["situation", "solution", "lessons"]
_BM25_BOOSTS = {"situation": 1.5, "solution": 1.0, "lessons": 2.0}
_RETRIEVAL_LIMIT = 100
_RRF_LIMIT = 150


class LocalPipeline:
    """Phase 1 local pipeline — contribute and query against local backends."""

    def __init__(
        self,
        store: SqliteStore,
        fts: FullTextSearchBackend,
        vector: VectorSearchBackend,
        embed: EmbeddingBackend,
        reranker: CrossEncoderReranker,
    ) -> None:
        self._store = store
        self._fts = fts
        self._vector = vector
        self._embed = embed
        self._reranker = reranker

    async def contribute(self, experience_id: str, data: dict) -> None:
        """Store, index, and embed an experience (all inline)."""
        # 1. Store in SQLite
        self._store.insert(experience_id, data)

        # 2. FTS index — include all searchable text fields
        env = data.get("environment")
        env_text = _flatten_env_to_text(env) if isinstance(env, dict) else ""
        tags = data.get("tags")
        tags_text = " ".join(tags) if isinstance(tags, list) else ""
        fts_doc = {
            "situation": data["situation"],
            "solution": data["solution"],
            "lessons": data["lessons"],
            "failed_approaches": data.get("failed_approaches", ""),
            "environment": env_text,
            "tags": tags_text,
        }
        await self._fts.index(experience_id, fts_doc)

        # 3. Embed and upsert into vector index
        text = data["situation"] + " " + data["solution"] + " " + data["lessons"]
        vecs = await self._embed.embed([text])
        await self._vector.upsert(experience_id, "situation", vecs[0])

        # 4. Persist vector index to disk (hnswlib is not auto-persisted)
        if hasattr(self._vector, "save"):
            self._vector.save()

    async def query(self, request: QueryRequest) -> dict:
        """Search local backends, rerank, and return enriched results with degradation."""
        warnings: list[str] = []

        # 1. Build filters
        filters: dict = {}
        if request.domain is not None:
            filters["domain"] = request.domain
        if request.task_type is not None:
            filters["task_type"] = request.task_type
        if request.language is not None:
            filters["language"] = request.language

        # 2. Embed query
        query_vec: list[float] | None = None
        try:
            query_vecs = await self._embed.embed([request.query])
            query_vec = query_vecs[0]
        except Exception as exc:
            logger.warning("Embedding failed: %s", exc)
            warnings.append(f"Embedding failed: {exc}")

        # 3. BM25 retrieval
        bm25_results: list[tuple[str, float]] = []
        try:
            bm25_results = await self._fts.search(
                query=request.query,
                fields=_BM25_FIELDS,
                field_boosts=_BM25_BOOSTS,
                filters=filters,
                limit=_RETRIEVAL_LIMIT,
            )
        except Exception as exc:
            logger.warning("BM25 search failed: %s", exc)
            warnings.append(f"BM25 search failed: {exc}")

        # 4. Vector retrieval (skip if embed failed)
        vector_results: list[tuple[str, float]] = []
        if query_vec is not None:
            try:
                vector_results = await self._vector.search(
                    field="situation",
                    embedding=query_vec,
                    limit=_RETRIEVAL_LIMIT,
                    filters=filters,
                )
            except Exception as exc:
                logger.warning("Vector search failed: %s", exc)
                warnings.append(f"Vector search failed: {exc}")

        # 5. Warn if vector returned empty
        if query_vec is not None and not vector_results and not warnings:
            warnings.append(
                "Vector search returned 0 results — embeddings may not be generated yet"
            )

        # 6. Check if all backends failed
        if not bm25_results and not vector_results:
            warnings.append("All search backends returned no results")
            return {"results": [], "warnings": warnings}

        # 7. RRF fusion
        rankings = [r for r in [bm25_results, vector_results] if r]
        fused = rrf_fusion(rankings, limit=_RRF_LIMIT) if rankings else []
        if not fused:
            return {"results": [], "warnings": warnings}

        # 8. Fetch full experience data from store
        experiences: dict[str, dict] = {}
        for exp_id, _ in fused:
            exp = self._store.get(exp_id)
            if exp is not None:
                experiences[exp_id] = exp

        if not experiences:
            return {"results": [], "warnings": warnings}

        # 9. Cross-encoder rerank top-20
        top20_ids = [exp_id for exp_id, _ in fused[:20] if exp_id in experiences]
        candidates = [
            (
                exp_id,
                experiences[exp_id]["situation"] + "\n\n" + experiences[exp_id]["lessons"],
            )
            for exp_id in top20_ids
        ]
        reranked = await self._reranker.rerank(request.query, candidates)
        reranker_scores = {exp_id: score for exp_id, score in reranked}

        # 10. Build results sorted by reranker score
        results = []
        for exp_id in top20_ids:
            score = reranker_scores.get(exp_id, 0.0)
            exp = experiences[exp_id]
            results.append({
                "experience_id": exp_id,
                "score": score,
                "situation": exp.get("situation"),
                "solution": exp.get("solution"),
                "lessons": exp.get("lessons"),
                "domain": exp.get("domain"),
                "task_type": exp.get("task_type"),
                "language": exp.get("language"),
                "tags": exp.get("tags"),
                "outcome_type": exp.get("outcome_type"),
                "failed_approaches": exp.get("failed_approaches"),
                "environment": exp.get("environment"),
                "subdomain": exp.get("subdomain"),
            })

        results.sort(key=lambda x: x["score"], reverse=True)
        return {"results": results[:request.limit], "warnings": warnings}
