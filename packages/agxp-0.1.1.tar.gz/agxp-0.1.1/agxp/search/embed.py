"""
ExperienceEmbedder — maps the 6 content fields of an Experience to embeddings.

All non-None fields are batched into a single embed() call to minimise latency.
Field serialisation rules:
  - tags:        list[str] → ", ".join(tags)  (None / [] → skip)
  - environment: dict      → json.dumps(...)   (None → skip)
  - all others:  str       → value as-is       (None / "" → skip)
"""
import json

from agxp.search.backends.embedding_backend import EmbeddingBackend

_FIELDS = ("situation", "solution", "lessons", "failed_approaches", "tags", "environment")


class ExperienceEmbedder:
    def __init__(self, backend: EmbeddingBackend) -> None:
        self._backend = backend

    async def embed_experience(
        self, exp: dict
    ) -> dict[str, list[float] | None]:
        """
        Returns {field: embedding_vector | None} for all 6 embedding fields.
        Non-embeddable fields (None / empty) map to None.
        """
        texts: dict[str, str] = {}
        for field in _FIELDS:
            text = _to_text(field, exp.get(field))
            if text:
                texts[field] = text

        result: dict[str, list[float] | None] = {f: None for f in _FIELDS}
        if not texts:
            return result

        field_order = list(texts.keys())
        embeddings = await self._backend.embed(list(texts.values()))
        for field, vec in zip(field_order, embeddings):
            result[field] = vec

        return result


def _to_text(field: str, value) -> str | None:
    if value is None:
        return None
    if field == "tags":
        if isinstance(value, list):
            joined = ", ".join(str(t) for t in value)
            return joined or None
        return str(value) or None
    if field == "environment":
        if isinstance(value, dict):
            return json.dumps(value, ensure_ascii=False)
        return str(value) or None
    text = str(value).strip()
    return text or None
