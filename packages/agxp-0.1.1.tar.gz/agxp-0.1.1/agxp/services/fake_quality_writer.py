"""
FakeQualityWriter — in-memory QualityScoreWriter for unit tests.

No database, no I/O. Use seed() to pre-load known scores before calling
recompute_score() or update_score() in tests.
"""
from agxp.services.quality_score_writer import QualityScoreWriter


class FakeQualityWriter(QualityScoreWriter):
    def __init__(self) -> None:
        self._scores: dict[str, float] = {}

    def seed(self, experience_id: str, score: float) -> None:
        """Pre-load a score for test setup. Not part of the ABC."""
        self._scores[experience_id] = score

    async def recompute_score(self, experience_id: str) -> float:
        """Return the seeded score, or 0.0 if not seeded."""
        return self._scores.get(experience_id, 0.0)

    async def update_score(
        self,
        experience_id: str,
        delta: float,
        reason: str,
    ) -> float:
        """Apply delta to the current score, clamp to [0.0, 1.0], return new score."""
        current = self._scores.get(experience_id, 0.0)
        new_score = max(0.0, min(1.0, current + delta))
        self._scores[experience_id] = new_score
        return new_score
