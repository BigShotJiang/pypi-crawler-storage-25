"""
PostgresCreditWriter — CreditWriter backed by direct PostgreSQL writes (asyncpg).

Guarantees:
- Atomicity: every operation is a single transaction (BEGIN … COMMIT).
- Overdraft prevention: debit() acquires SELECT … FOR UPDATE on the account row
  before checking the balance, serialising concurrent debits.
- Idempotency: idempotency_key has a UNIQUE constraint in credit_transactions;
  duplicate keys are detected at the start of each transaction and short-circuit
  without performing a second write.
- Ledger sign convention: credit() stores +amount, debit() stores -amount.
- reference_type: when experience_id is supplied to credit(), reference_type is
  set to "experience" so the ledger row is self-describing.
"""
from __future__ import annotations

import uuid

import asyncpg

from agxp.services.credit_writer import CreditWriter, InsufficientCreditsError


class PostgresCreditWriter(CreditWriter):
    def __init__(self, pool: asyncpg.Pool | None = None) -> None:
        self._pool = pool

    async def _get_pool(self) -> asyncpg.Pool:
        if self._pool is None:
            from agxp.db.pool import get_pool
            self._pool = await get_pool()
        return self._pool

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    async def get_balance(self, user_id: str) -> int:
        """Return current balance. Returns 0 if the user has no credit account."""
        pool = await self._get_pool()
        row = await pool.fetchrow(
            "SELECT balance FROM credit_accounts WHERE user_id = $1",
            uuid.UUID(user_id),
        )
        return int(row["balance"]) if row else 0

    async def credit(
        self,
        user_id: str,
        amount: int,
        txn_type: str,
        description: str,
        experience_id: str | None,
        idempotency_key: str,
    ) -> int:
        """
        Add credits to the user's account. Returns the new balance.
        Idempotent: a duplicate idempotency_key returns the original balance_after.
        Creates a credit_accounts row if one does not exist yet.
        """
        pool = await self._get_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                # --- idempotency check ---
                existing = await conn.fetchrow(
                    "SELECT balance_after FROM credit_transactions "
                    "WHERE idempotency_key = $1",
                    idempotency_key,
                )
                if existing:
                    return int(existing["balance_after"])

                # --- resolve account ---
                account = await conn.fetchrow(
                    "SELECT id, balance FROM credit_accounts WHERE user_id = $1",
                    uuid.UUID(user_id),
                )
                if account is None:
                    account_id = str(uuid.uuid4())
                    await conn.execute(
                        """
                        INSERT INTO credit_accounts
                            (id, user_id, balance, pending_balance, tier,
                             lifetime_earned, lifetime_spent)
                        VALUES ($1, $2, 0, 0, 'free', 0, 0)
                        """,
                        uuid.UUID(account_id),
                        uuid.UUID(user_id),
                    )
                    current_balance = 0
                else:
                    account_id = str(account["id"])
                    current_balance = int(account["balance"])

                new_balance = current_balance + amount

                # --- update account ---
                await conn.execute(
                    """
                    UPDATE credit_accounts
                    SET balance = $1,
                        lifetime_earned = lifetime_earned + $2,
                        updated_at = now()
                    WHERE id = $3
                    """,
                    new_balance,
                    amount,
                    uuid.UUID(account_id),
                )

                # --- append ledger row ---
                await conn.execute(
                    """
                    INSERT INTO credit_transactions
                        (account_id, txn_type, amount, balance_after,
                         idempotency_key, reference_id, reference_type, description)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                    """,
                    uuid.UUID(account_id),
                    txn_type,
                    amount,
                    new_balance,
                    idempotency_key,
                    uuid.UUID(experience_id) if experience_id else None,
                    "experience" if experience_id else None,
                    description,
                )

                return new_balance

    async def debit(
        self,
        user_id: str,
        amount: int,
        txn_type: str,
        description: str,
        idempotency_key: str,
    ) -> int:
        """
        Deduct credits from the user's account. Returns the new balance.
        Raises InsufficientCreditsError if balance < amount (atomically, no partial write).
        Idempotent: a duplicate idempotency_key returns the original balance_after.
        """
        pool = await self._get_pool()
        async with pool.acquire() as conn:
            async with conn.transaction():
                # --- idempotency check ---
                existing = await conn.fetchrow(
                    "SELECT balance_after FROM credit_transactions "
                    "WHERE idempotency_key = $1",
                    idempotency_key,
                )
                if existing:
                    return int(existing["balance_after"])

                # --- lock account row to serialise concurrent debits ---
                account = await conn.fetchrow(
                    "SELECT id, balance FROM credit_accounts "
                    "WHERE user_id = $1 FOR UPDATE",
                    uuid.UUID(user_id),
                )
                if account is None:
                    raise InsufficientCreditsError(user_id, 0, amount)

                current_balance = int(account["balance"])
                account_id = str(account["id"])

                if current_balance < amount:
                    raise InsufficientCreditsError(user_id, current_balance, amount)

                new_balance = current_balance - amount

                # --- update account ---
                await conn.execute(
                    """
                    UPDATE credit_accounts
                    SET balance = $1,
                        lifetime_spent = lifetime_spent + $2,
                        updated_at = now()
                    WHERE id = $3
                    """,
                    new_balance,
                    amount,
                    uuid.UUID(account_id),
                )

                # --- append ledger row (negative amount = debit convention) ---
                await conn.execute(
                    """
                    INSERT INTO credit_transactions
                        (account_id, txn_type, amount, balance_after,
                         idempotency_key, description)
                    VALUES ($1, $2, $3, $4, $5, $6)
                    """,
                    uuid.UUID(account_id),
                    txn_type,
                    -amount,
                    new_balance,
                    idempotency_key,
                    description,
                )

                return new_balance
