"""
CreditWriter — abstract interface for credit ledger writes.

Credits are scoped to user_id (DDR-003): all API keys under the same user
share one credit pool.

Default implementation: PostgresCreditWriter (direct DB writes).
Future: RedisCreditWriter (Redis-first, async DB flush) for high write throughput.
"""

from abc import ABC, abstractmethod


class InsufficientCreditsError(Exception):
    """Raised by CreditWriter.debit() when the user's balance is below the requested amount."""

    def __init__(self, user_id: str, balance: int, requested: int) -> None:
        self.user_id = user_id
        self.balance = balance
        self.requested = requested
        super().__init__(
            f"Insufficient credits for user {user_id}: balance={balance}, requested={requested}"
        )


class CreditWriter(ABC):
    @abstractmethod
    async def debit(
        self,
        user_id: str,
        amount: int,
        txn_type: str,
        description: str,
        idempotency_key: str,
    ) -> int:
        """Deduct credits. Returns new balance. Raises InsufficientCreditsError if balance < amount."""
        ...

    @abstractmethod
    async def credit(
        self,
        user_id: str,
        amount: int,
        txn_type: str,
        description: str,
        experience_id: str | None,
        idempotency_key: str,
    ) -> int:
        """Add credits. Returns new balance."""
        ...

    @abstractmethod
    async def get_balance(self, user_id: str) -> int:
        """Return current credit balance for a user (shared across all their API keys)."""
        ...
