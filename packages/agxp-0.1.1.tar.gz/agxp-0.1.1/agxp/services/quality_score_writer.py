"""
QualityScoreWriter — abstract interface for experience quality score updates.

Default implementation: InlineQualityWriter (direct DB UPDATE).
Future: BufferedQualityWriter (Redis buffer + batch flush) for high update throughput.
"""

from abc import ABC, abstractmethod


class QualityScoreWriter(ABC):
    @abstractmethod
    async def update_score(
        self,
        experience_id: str,
        delta: float,
        reason: str,
    ) -> float:
        """Apply a delta to the quality score. Returns new score.
        reason: "feedback" | "vote" | "use" | "recompute"
        """
        ...

    @abstractmethod
    async def recompute_score(
        self,
        experience_id: str,
    ) -> float:
        """Fully recompute quality score from raw signals. Returns new score."""
        ...
