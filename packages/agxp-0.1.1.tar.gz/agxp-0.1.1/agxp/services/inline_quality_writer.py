"""
InlineQualityWriter — QualityScoreWriter backed by direct PostgreSQL writes.

Phase 1 formula (DDR-008):
  quality_score = 0.40 × uniqueness_score
                + 0.35 × completeness_score
                + 0.25 × community_score

completeness_score is rule-based (no LLM).
uniqueness_score is the cosine distance to the nearest neighbor in embedding space.
community_score uses votes + use_count; cold-start floor = completeness_score × 0.5.
"""
from __future__ import annotations

import json
import math
import re
import uuid

import asyncpg

from agxp.services.quality_score_writer import QualityScoreWriter

# Regex: 2+ consecutive digits, OR a digit sequence followed by %
_QUANTIFIABLE_RE = re.compile(r"\d{2,}|\d+%")

# Upper bound for use_count normalisation; log-scale
_MAX_USE_COUNT = 1000


# ---------------------------------------------------------------------------
# Pure helper — no I/O; can be unit tested directly
# ---------------------------------------------------------------------------


def compute_completeness_score(row: dict) -> float:
    """
    Rule-based completeness score from experience field content.

    row keys used:
      failed_approaches: str | None
      environment:       dict | None   (pass a decoded dict, not a JSON string)
      solution:          str | None
      lessons:           str | None
      tags:              list[str] | None

    Returns a float in [0.0, 1.0].
    """
    score = 0.50

    # +0.15 if failed_approaches is a non-empty string
    fa = row.get("failed_approaches") or ""
    if fa.strip():
        score += 0.15

    # +0.10 if environment is a non-empty dict
    env = row.get("environment")
    if isinstance(env, dict) and env:
        score += 0.10

    # +0.10 if solution or lessons contains a quantifiable result
    text = (row.get("solution") or "") + " " + (row.get("lessons") or "")
    if _QUANTIFIABLE_RE.search(text):
        score += 0.10

    # +0.10 if lessons word count > 100
    lessons = row.get("lessons") or ""
    if len(lessons.split()) > 100:
        score += 0.10

    # +0.05 if tags count >= 3
    tags = row.get("tags") or []
    if len(tags) >= 3:
        score += 0.05

    return min(score, 1.0)


# ---------------------------------------------------------------------------
# Community score helper
# ---------------------------------------------------------------------------


def _compute_community_score(
    upvotes: int,
    downvotes: int,
    use_count: int,
    completeness_score: float,
) -> float:
    """
    Derive community score from votes + use_count.
    Cold-start (no activity): return completeness_score × 0.5.
    """
    if upvotes == 0 and downvotes == 0 and use_count == 0:
        return completeness_score * 0.5

    total_votes = upvotes + downvotes
    if total_votes > 0:
        raw_vote = (upvotes - downvotes) / total_votes  # [-1.0, 1.0]
        vote_score = (raw_vote + 1.0) / 2.0  # → [0.0, 1.0]
    else:
        vote_score = 0.5  # no votes yet but has uses

    use_score = math.log(use_count + 1) / math.log(_MAX_USE_COUNT + 1)

    return min(1.0, 0.6 * vote_score + 0.4 * use_score)


# ---------------------------------------------------------------------------
# InlineQualityWriter
# ---------------------------------------------------------------------------


class InlineQualityWriter(QualityScoreWriter):
    def __init__(self, pool: asyncpg.Pool | None = None) -> None:
        self._pool = pool

    async def _get_pool(self) -> asyncpg.Pool:
        if self._pool is None:
            from agxp.db.pool import get_pool
            self._pool = await get_pool()
        return self._pool

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    async def recompute_score(self, experience_id: str) -> float:
        """
        Compute quality_score from raw signals and persist to DB.

        Steps:
          1. Fetch experience row.
          2. Compute completeness_score (rule-based).
          3. Compute community_score (votes + uses, cold-start floor).
          4. Compute uniqueness_score (pgvector nearest-neighbor distance).
          5. Compute quality_score from the Phase 1 formula.
          6. UPDATE experiences with all four scores; set is_published = True.

        Returns the new quality_score.
        """
        pool = await self._get_pool()

        row = await pool.fetchrow(
            """
            SELECT situation, failed_approaches, solution, lessons,
                   environment, tags,
                   upvotes, downvotes, use_count,
                   embedding_situation
            FROM experiences
            WHERE id = $1 AND deleted_at IS NULL
            """,
            uuid.UUID(experience_id),
        )
        if row is None:
            raise ValueError(f"Experience not found: {experience_id}")

        # asyncpg returns JSONB as a JSON string; decode to dict for the helper
        env_raw = row["environment"]
        if isinstance(env_raw, str):
            try:
                env_decoded: dict | None = json.loads(env_raw)
            except (json.JSONDecodeError, TypeError):
                env_decoded = None
        else:
            env_decoded = env_raw  # already dict | None

        completeness = compute_completeness_score({
            "failed_approaches": row["failed_approaches"],
            "environment": env_decoded,
            "solution": row["solution"],
            "lessons": row["lessons"],
            "tags": list(row["tags"]) if row["tags"] else [],
        })

        community = _compute_community_score(
            upvotes=row["upvotes"],
            downvotes=row["downvotes"],
            use_count=row["use_count"],
            completeness_score=completeness,
        )

        uniqueness = await self._compute_uniqueness(pool, experience_id, row["embedding_situation"])

        quality = 0.40 * uniqueness + 0.35 * completeness + 0.25 * community

        await pool.execute(
            """
            UPDATE experiences
            SET quality_score      = $1,
                completeness_score = $2,
                community_score    = $3,
                uniqueness_score   = $4,
                is_published       = TRUE,
                updated_at         = now()
            WHERE id = $5
            """,
            quality,
            completeness,
            community,
            uniqueness,
            uuid.UUID(experience_id),
        )

        return quality

    async def update_score(
        self,
        experience_id: str,
        delta: float,
        reason: str,
    ) -> float:
        """
        Apply delta to the current quality_score, clamp to [0.0, 1.0], persist.
        reason is logged but not stored (future: audit log).
        Returns the new quality_score.
        """
        pool = await self._get_pool()

        row = await pool.fetchrow(
            "SELECT quality_score FROM experiences WHERE id = $1 AND deleted_at IS NULL",
            uuid.UUID(experience_id),
        )
        if row is None:
            raise ValueError(f"Experience not found: {experience_id}")

        new_score = max(0.0, min(1.0, float(row["quality_score"]) + delta))

        await pool.execute(
            "UPDATE experiences SET quality_score = $1, updated_at = now() WHERE id = $2",
            new_score,
            uuid.UUID(experience_id),
        )

        return new_score

    # ------------------------------------------------------------------
    # Private
    # ------------------------------------------------------------------

    @staticmethod
    async def _compute_uniqueness(
        pool: asyncpg.Pool,
        experience_id: str,
        embedding: object,
    ) -> float:
        """
        Cosine distance to the nearest neighbor in embedding_situation space.
        Returns 1.0 (maximally unique) when there is no embedding or no neighbors.
        """
        if embedding is None:
            return 1.0

        row = await pool.fetchrow(
            """
            SELECT 1 - (embedding_situation <=> $1) AS similarity
            FROM experiences
            WHERE id != $2
              AND deleted_at IS NULL
              AND embedding_situation IS NOT NULL
            ORDER BY embedding_situation <=> $1
            LIMIT 1
            """,
            embedding,
            uuid.UUID(experience_id),
        )

        if row is None:
            return 1.0  # only experience in the index

        similarity = float(row["similarity"])
        # cosine_distance = 1 - cosine_similarity; clamp to [0, 1]
        return max(0.0, min(1.0, 1.0 - similarity))
