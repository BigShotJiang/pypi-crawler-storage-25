"""
FakeCreditWriter — in-memory CreditWriter for unit tests.

Behaviour matches the PostgresCreditWriter contract:
- credit() / debit() are idempotent on idempotency_key (global uniqueness)
- debit() raises InsufficientCreditsError when balance < amount
- get_balance() returns 0 for unknown users (implicit zero-balance account)
- Each instance has its own isolated state (no class-level shared dicts)
"""
from __future__ import annotations

from agxp.services.credit_writer import CreditWriter, InsufficientCreditsError


class FakeCreditWriter(CreditWriter):
    def __init__(self) -> None:
        # user_id (str) → current balance (int)
        self._balances: dict[str, int] = {}
        # idempotency_key → balance_after returned on first call
        # Global scope: same key cannot be reused across users either.
        self._key_result: dict[str, int] = {}

    async def get_balance(self, user_id: str) -> int:
        return self._balances.get(user_id, 0)

    async def credit(
        self,
        user_id: str,
        amount: int,
        txn_type: str,
        description: str,
        experience_id: str | None,
        idempotency_key: str,
    ) -> int:
        if idempotency_key in self._key_result:
            return self._key_result[idempotency_key]

        current = self._balances.get(user_id, 0)
        new_balance = current + amount
        self._balances[user_id] = new_balance
        self._key_result[idempotency_key] = new_balance
        return new_balance

    async def debit(
        self,
        user_id: str,
        amount: int,
        txn_type: str,
        description: str,
        idempotency_key: str,
    ) -> int:
        if idempotency_key in self._key_result:
            return self._key_result[idempotency_key]

        current = self._balances.get(user_id, 0)
        if current < amount:
            raise InsufficientCreditsError(user_id, current, amount)

        new_balance = current - amount
        self._balances[user_id] = new_balance
        self._key_result[idempotency_key] = new_balance
        return new_balance
