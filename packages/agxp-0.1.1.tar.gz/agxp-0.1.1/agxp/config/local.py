"""
LocalConfig — wires all Phase 1 local backends from a single data_dir.

Usage:
    config = LocalConfig(data_dir="~/.agxp")
    config.store   → SqliteStore
    config.fts     → TantivyBackend (file-backed)
    config.vector  → HnswlibBackend (file-backed)
    config.embed   → MiniLMEmbeddingBackend
    config.reranker → MiniLMCrossEncoder
"""
from __future__ import annotations

import os

from agxp.search.backends.embedding_backend import EmbeddingBackend
from agxp.search.backends.fts_backend import FullTextSearchBackend
from agxp.search.backends.hnswlib_backend import HnswlibBackend
from agxp.search.backends.minilm_embedding_backend import MiniLMEmbeddingBackend
from agxp.search.backends.tantivy_backend import TantivyBackend
from agxp.search.backends.vector_backend import VectorSearchBackend
from agxp.search.miniml_reranker import MiniLMCrossEncoder
from agxp.search.reranker import CrossEncoderReranker
from agxp.store.sqlite_store import SqliteStore


class LocalConfig:
    """Phase 1 backend configuration — all local, zero external services."""

    def __init__(self, data_dir: str) -> None:
        os.makedirs(data_dir, exist_ok=True)

        tantivy_path = os.path.join(data_dir, "tantivy_index")
        os.makedirs(tantivy_path, exist_ok=True)

        self._store = SqliteStore(db_path=os.path.join(data_dir, "local.db"))
        self._fts = TantivyBackend(path=tantivy_path)
        self._vector = HnswlibBackend(
            dim=384,
            index_path=os.path.join(data_dir, "hnsw_index"),
            metadata_fn=self._store.get_many,
        )
        self._embed = MiniLMEmbeddingBackend()
        self._reranker = MiniLMCrossEncoder()

    @property
    def store(self) -> SqliteStore:
        return self._store

    @property
    def fts(self) -> FullTextSearchBackend:
        return self._fts

    @property
    def vector(self) -> VectorSearchBackend:
        return self._vector

    @property
    def embed(self) -> EmbeddingBackend:
        return self._embed

    @property
    def reranker(self) -> CrossEncoderReranker:
        return self._reranker
