"""
Backend wiring — swap implementations here, nowhere else.
All five pluggable backends (DDR-018) are configured in this module.
"""
import os
from agxp.search.backends.bgem3_api_backend import BgeM3ApiBackend
from agxp.search.backends.embedding_backend import EmbeddingBackend
from agxp.search.backends.fts_backend import FullTextSearchBackend
from agxp.search.backends.pgvector_backend import PgvectorBackend
from agxp.search.backends.vector_backend import VectorSearchBackend
from agxp.services.credit_writer import CreditWriter
from agxp.services.inline_quality_writer import InlineQualityWriter
from agxp.services.postgres_credit_writer import PostgresCreditWriter
from agxp.services.quality_score_writer import QualityScoreWriter

# Fake FTS backend for now (Tantivy was removed in pure client-server refactor)
class FakeFTSBackend(FullTextSearchBackend):
    async def index(self, *args, **kwargs) -> None:
        # Fake backend ignores all parameters for indexing
        pass
    async def search(self, query: str, limit: int = 10, **kwargs) -> list[tuple[str, float]]:
        # Ignore unsupported parameters like 'fields' for fake backend
        return []
    async def delete(self, experience_id: str) -> None:
        pass

# Embedding backend selection via environment variable
# Available options: "api" (default), "local"
embed_backend_type = os.getenv("EMBED_BACKEND", "api").lower()
if embed_backend_type == "local":
    from agxp.search.backends.bgem3_local_backend import BgeM3LocalBackend
    EMBED_BACKEND: EmbeddingBackend = BgeM3LocalBackend()
else:
    EMBED_BACKEND: EmbeddingBackend = BgeM3ApiBackend()

VECTOR_BACKEND: VectorSearchBackend = PgvectorBackend()
FTS_BACKEND: FullTextSearchBackend = FakeFTSBackend()
CREDIT_WRITER: CreditWriter = PostgresCreditWriter()
QUALITY_WRITER: QualityScoreWriter = InlineQualityWriter()
