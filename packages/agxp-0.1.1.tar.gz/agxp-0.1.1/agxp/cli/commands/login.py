"""
agxp login command - Authenticate with AGXP using Github OAuth.
"""
from __future__ import annotations

import http.server
import json
import os
import socketserver
import threading
import time
import webbrowser
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import typer

from agxp.cli.constants import AGXP_SERVER_URL

_DEFAULT_DATA_DIR = str(Path.home() / ".agxp")

# Global variable to store the received token
_received_token: str | None = None
_server_error: str | None = None

class CallbackHandler(http.server.SimpleHTTPRequestHandler):
    """Handle OAuth callback from AGXP server."""
    def do_GET(self):
        global _received_token, _server_error

        try:
            # Parse query parameters
            parsed_path = urlparse(self.path)
            query_params = parse_qs(parsed_path.query)

            if parsed_path.path == "/callback":
                if "token" in query_params:
                    _received_token = query_params["token"][0]

                    # Return success page
                    self.send_response(200)
                    self.send_header("Content-type", "text/html")
                    self.end_headers()
                    self.wfile.write(b"""
                        <html>
                            <body style="text-align: center; padding: 50px; font-family: sans-serif;">
                                <h1>Login successful!</h1>
                                <p>You can now close this window and return to the CLI.</p>
                            </body>
                        </html>
                    """)
                else:
                    # Return error page
                    error_msg = query_params.get("error", ["Unknown error"])[0]
                    _server_error = error_msg
                    self.send_response(400)
                    self.send_header("Content-type", "text/html")
                    self.end_headers()
                    self.wfile.write(f"""
                        <html>
                            <body style="text-align: center; padding: 50px; font-family: sans-serif;">
                                <h1>Login failed</h1>
                                <p>{error_msg}</p>
                                <p>Please try again later.</p>
                            </body>
                        </html>
                    """.encode("utf-8"))
            else:
                self.send_response(404)
                self.end_headers()
        except Exception as e:
            _server_error = str(e)
            self.send_response(500)
            self.end_headers()

        # Shutdown the server after handling the request
        threading.Thread(target=self.server.shutdown, daemon=True).start()

    def log_message(self, format, *args):
        """Disable logging for the callback server."""
        pass

def find_available_port(start_port: int = 8888, max_tries: int = 100) -> int:
    """Find an available port to run the callback server on."""
    for port in range(start_port, start_port + max_tries):
        try:
            with socketserver.TCPServer(("localhost", port), None):
                return port
        except OSError:
            continue
    raise RuntimeError(f"Could not find an available port between {start_port} and {start_port + max_tries}")

def _get_config_path(data_dir: str) -> str:
    """Return path to config.json."""
    if data_dir == _DEFAULT_DATA_DIR:
        return os.path.join(os.path.expanduser("~"), ".agxp", "config.json")
    return os.path.join(data_dir, "config.json")

def _read_config(data_dir: str) -> dict:
    """Read config file, return empty dict if not found."""
    config_path = _get_config_path(data_dir)
    if os.path.exists(config_path):
        with open(config_path, "r") as f:
            return json.load(f)
    return {}

def _write_config(config: dict, data_dir: str) -> None:
    """Write config to file, creating directories if needed."""
    config_path = _get_config_path(data_dir)
    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)

def login(
    server_url: str = typer.Option(
        None,
        help="AGXP server URL to authenticate with. Defaults to AGXP_SERVER_URL environment variable."
    ),
    data_dir: str = typer.Option(
        _DEFAULT_DATA_DIR,
        help="Directory to store AGXP data and configuration"
    ),
) -> None:
    """Authenticate with AGXP using Github OAuth."""
    if server_url is None:
        server_url = AGXP_SERVER_URL
    global _received_token, _server_error
    _received_token = None
    _server_error = None

    # Find available port for callback server
    try:
        port = find_available_port()
    except RuntimeError as e:
        typer.echo(f"❌ {str(e)}", err=True)
        raise typer.Exit(1)

    callback_url = f"http://localhost:{port}/callback"

    # Start callback server in a separate thread
    server = socketserver.TCPServer(("localhost", port), CallbackHandler)
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    try:
        # Build OAuth URL
        auth_url = f"{server_url.rstrip('/')}/api/v1/auth/github?redirect_uri={callback_url}"

        # Open browser or show URL for manual opening
        typer.echo("🌐 Opening Github login page in your browser...")
        typer.echo(f"If the browser doesn't open automatically, visit this URL:")
        typer.echo(f"   {auth_url}")
        typer.echo("")
        typer.echo("Waiting for authentication to complete... (timeout in 5 minutes)")

        try:
            webbrowser.open(auth_url)
        except Exception:
            # Ignore browser opening errors, user can manually visit the URL
            pass

        # Wait for token with timeout
        start_time = time.time()
        timeout = 300  # 5 minutes

        while time.time() - start_time < timeout and _received_token is None and _server_error is None:
            time.sleep(0.5)

        if _server_error:
            typer.echo(f"❌ Login failed: {_server_error}", err=True)
            raise typer.Exit(1)

        if _received_token is None:
            typer.echo("❌ Login timed out. Please try again.", err=True)
            raise typer.Exit(1)

        # Save token to config
        config = _read_config(data_dir)
        config["api_token"] = _received_token
        _write_config(config, data_dir)

        typer.echo("✅ Login successful!")
        typer.echo("Your API token has been saved to ~/.agxp/config.json")
        typer.echo("You can now use AGXP features like contributing experiences.")

    finally:
        # Ensure server is shutdown
        server.shutdown()
        server.server_close()
        server_thread.join(timeout=5)
