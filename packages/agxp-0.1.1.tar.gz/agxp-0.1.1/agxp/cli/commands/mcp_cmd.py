"""
agxp mcp — start the MCP (Model Context Protocol) server.

Runs on stdio transport, compatible with Claude Code, Cursor, VS Code.
"""
from __future__ import annotations

import os
from pathlib import Path

import typer

_DEFAULT_DATA_DIR = str(Path.home() / ".agxp")


def mcp(
    data_dir: str = typer.Option(_DEFAULT_DATA_DIR, "--data-dir", help="Data directory path for config"),
) -> None:
    """Start the AGXP MCP server (stdio transport)."""
    # Create data directory if it doesn't exist
    os.makedirs(data_dir, exist_ok=True)

    try:
        from agxp.mcp.server import mcp as mcp_server, set_data_dir
    except ImportError:
        typer.echo(
            "Error: MCP dependencies not installed.\n"
            'Run: pip install "agxp[local]"',
            err=True,
        )
        raise typer.Exit(code=1)

    set_data_dir(data_dir)
    mcp_server.run(transport="stdio")
