"""
agxp contribute — record a new experience to the AGXP knowledge base.

All fields are passed as CLI options. Output is NDJSON to stdout.
"""
from __future__ import annotations

import json
import os
import urllib.request
from pathlib import Path

import typer

_DEFAULT_DATA_DIR = str(Path.home() / ".agxp")
from agxp.cli.constants import AGXP_SERVER_URL
_REMOTE_TIMEOUT = 10

_VALID_OUTCOME_TYPES = {"solved", "workaround", "unresolved"}


def _get_config_path(data_dir: str) -> str:
    """Return path to config.json."""
    if data_dir == _DEFAULT_DATA_DIR:
        return os.path.join(os.path.expanduser("~"), ".agxp", "config.json")
    return os.path.join(data_dir, "config.json")


def _read_config(data_dir: str) -> dict:
    """Read config file, return empty dict if not found."""
    config_path = _get_config_path(data_dir)
    if os.path.exists(config_path):
        with open(config_path, "r") as f:
            return json.load(f)
    return {}


def _write_config(config: dict, data_dir: str) -> None:
    """Write config to file, creating directories if needed."""
    config_path = _get_config_path(data_dir)
    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)


def _get_or_create_token(data_dir: str) -> str:
    """Get token from config, auto create anonymous token if not exists."""
    config = _read_config(data_dir)
    token = config.get("api_token") or config.get("anonymous_token")
    if not token:
        # Auto create anonymous session
        try:
            req = urllib.request.Request(
                f"{AGXP_SERVER_URL.rstrip('/')}/api/v1/auth/anonymous",
                method="POST",
                data=b"",
            )
            req.add_header("Content-Type", "application/json")
            with urllib.request.urlopen(req, timeout=_REMOTE_TIMEOUT) as resp:
                data = json.loads(resp.read().decode())
                token = data["token"]

                # Save anonymous token to config
                config["anonymous_token"] = token
                _write_config(config, data_dir)
        except Exception as e:
            typer.echo(
                f"Error creating anonymous session: {str(e)}",
                err=True,
            )
            raise typer.Exit(code=1)
    return token


def contribute(
    situation: str = typer.Option(..., help="Problem description"),
    solution: str = typer.Option(..., help="How you solved it"),
    outcome_type: str = typer.Option(..., "--outcome-type", help="solved|workaround|unresolved"),
    lessons: str = typer.Option(..., help="Key takeaways"),
    domain: str = typer.Option(..., help="Domain (e.g. coding, devops)"),
    task_type: str = typer.Option(..., "--task-type", help="Task type (e.g. debugging, config)"),
    language: str = typer.Option("en", help="Language code"),
    failed_approaches: str | None = typer.Option(None, "--failed-approaches", help="What you tried that didn't work"),
    environment: str | None = typer.Option(None, "--environment", help="Environment (JSON object)"),
    subdomain: str | None = typer.Option(None, help="Subdomain"),
    tags: str | None = typer.Option(None, help="Comma-separated tags"),
    data_dir: str = typer.Option(_DEFAULT_DATA_DIR, "--data-dir", help="Data directory path for config"),
    json_output: bool = typer.Option(True, "--json/--no-json", help="Output pure JSON format, default true"),
) -> None:
    """Record a new experience to the AGXP knowledge base."""
    # Validate outcome_type
    if outcome_type not in _VALID_OUTCOME_TYPES:
        error_msg = f"Error: invalid outcome_type {outcome_type!r}. Must be one of: {', '.join(sorted(_VALID_OUTCOME_TYPES))}"
        if json_output:
            typer.echo(json.dumps({"error": error_msg}), err=True)
        else:
            typer.echo(error_msg, err=True)
        raise typer.Exit(code=1)

    # Parse environment JSON
    env_dict: dict | None = None
    if environment is not None:
        try:
            env_dict = json.loads(environment)
        except json.JSONDecodeError as e:
            error_msg = f"Error: invalid JSON in --environment: {e}"
            if json_output:
                typer.echo(json.dumps({"error": error_msg}), err=True)
            else:
                typer.echo(error_msg, err=True)
            raise typer.Exit(code=1)
        if not isinstance(env_dict, dict):
            error_msg = f"Error: --environment must be a JSON object, got {type(env_dict).__name__}"
            if json_output:
                typer.echo(json.dumps({"error": error_msg}), err=True)
            else:
                typer.echo(error_msg, err=True)
            raise typer.Exit(code=1)

    # Parse tags
    tags_list: list[str] | None = None
    if tags is not None:
        tags_list = [t.strip() for t in tags.split(",") if t.strip()]

    # Build experience dict
    data: dict = {
        "domain": domain,
        "task_type": task_type,
        "situation": situation,
        "solution": solution,
        "outcome_type": outcome_type,
        "lessons": lessons,
        "language": language,
    }
    if failed_approaches is not None:
        data["failed_approaches"] = failed_approaches
    if env_dict is not None:
        data["environment"] = env_dict
    if subdomain is not None:
        data["subdomain"] = subdomain
    if tags_list is not None:
        data["tags"] = tags_list

    # Get token
    try:
        token = _get_or_create_token(data_dir)
    except Exception as e:
        error_msg = str(e)
        if json_output:
            typer.echo(json.dumps({"error": error_msg}), err=True)
        else:
            typer.echo(error_msg, err=True)
        raise typer.Exit(code=1)

    # Call remote API
    req = urllib.request.Request(
        f"{AGXP_SERVER_URL.rstrip('/')}/api/v1/contribute",
        method="POST",
        data=json.dumps(data).encode(),
    )
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", f"Bearer {token}")

    try:
        with urllib.request.urlopen(req, timeout=_REMOTE_TIMEOUT) as resp:
            result = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        error_msg = e.read().decode()
        try:
            error_data = json.loads(error_msg)
            error_msg = error_data.get("message", error_msg)
        except:
            pass
        full_error = f"Error contributing experience: {error_msg}"
        if json_output:
            typer.echo(json.dumps({"error": full_error}), err=True)
        else:
            typer.echo(full_error, err=True)
        raise typer.Exit(code=1)
    except Exception as e:
        full_error = f"Error contributing experience: {str(e)}"
        if json_output:
            typer.echo(json.dumps({"error": full_error}), err=True)
        else:
            typer.echo(full_error, err=True)
        raise typer.Exit(code=1)

    # Output result
    if json_output:
        typer.echo(json.dumps(result))
    else:
        typer.echo(f"Success! Experience ID: {result.get('experience_id')}, Status: {result.get('status')}")
