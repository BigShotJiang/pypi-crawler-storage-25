"""
agxp feedback — report whether an experience was useful.

Updates the quality_score to improve search ranking over time.
"""
from __future__ import annotations

import json
import os
import urllib.request
from pathlib import Path

import typer

_DEFAULT_DATA_DIR = str(Path.home() / ".agxp")
from agxp.cli.constants import AGXP_SERVER_URL
_REMOTE_TIMEOUT = 10


def _get_config_path(data_dir: str) -> str:
    """Return path to config.json."""
    if data_dir == _DEFAULT_DATA_DIR:
        return os.path.join(os.path.expanduser("~"), ".agxp", "config.json")
    return os.path.join(data_dir, "config.json")


def _read_config(data_dir: str) -> dict:
    """Read config file, return empty dict if not found."""
    config_path = _get_config_path(data_dir)
    if os.path.exists(config_path):
        with open(config_path, "r") as f:
            return json.load(f)
    return {}


def _write_config(config: dict, data_dir: str) -> None:
    """Write config to file, creating directories if needed."""
    config_path = _get_config_path(data_dir)
    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)


def _get_or_create_token(data_dir: str) -> str:
    """Get token from config, auto create anonymous token if not exists."""
    config = _read_config(data_dir)
    token = config.get("api_token") or config.get("anonymous_token")
    if not token:
        # Auto create anonymous session
        try:
            req = urllib.request.Request(
                f"{AGXP_SERVER_URL.rstrip('/')}/api/v1/auth/anonymous",
                method="POST",
                data=b"",
            )
            req.add_header("Content-Type", "application/json")
            with urllib.request.urlopen(req, timeout=_REMOTE_TIMEOUT) as resp:
                data = json.loads(resp.read().decode())
                token = data["token"]

                # Save anonymous token to config
                config["anonymous_token"] = token
                _write_config(config, data_dir)
        except Exception as e:
            typer.echo(
                f"Error creating anonymous session: {str(e)}",
                err=True,
            )
            raise typer.Exit(code=1)
    return token


def feedback(
    experience_id: str = typer.Option(..., "--experience-id", help="Experience ID to give feedback on"),
    useful: bool = typer.Option(None, "--useful/--not-useful", help="Was the experience useful?"),
    data_dir: str = typer.Option(_DEFAULT_DATA_DIR, "--data-dir", help="Data directory path for config"),
    json_output: bool = typer.Option(True, "--json/--no-json", help="Output pure JSON format"),
) -> None:
    """Report whether an experience was useful after trying it."""
    if useful is None:
        error_msg = "Error: specify --useful or --not-useful"
        if json_output:
            typer.echo(json.dumps({"error": error_msg}), err=True)
        else:
            typer.echo(error_msg, err=True)
        raise typer.Exit(code=1)

    # Get token
    token = _get_or_create_token(data_dir)

    # Call remote API
    data = {"experience_id": experience_id, "useful": useful}
    req = urllib.request.Request(
        f"{AGXP_SERVER_URL.rstrip('/')}/api/v1/feedback",
        method="POST",
        data=json.dumps(data).encode(),
    )
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", f"Bearer {token}")

    try:
        with urllib.request.urlopen(req, timeout=_REMOTE_TIMEOUT) as resp:
            result = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        error_msg = e.read().decode()
        try:
            error_data = json.loads(error_msg)
            error_msg = error_data.get("message", error_msg)
        except:
            pass
        full_error = f"Error submitting feedback: {error_msg}"
        if json_output:
            typer.echo(json.dumps({"error": full_error}), err=True)
        else:
            typer.echo(full_error, err=True)
        raise typer.Exit(code=1)
    except Exception as e:
        full_error = f"Error submitting feedback: {str(e)}"
        if json_output:
            typer.echo(json.dumps({"error": full_error}), err=True)
        else:
            typer.echo(full_error, err=True)
        raise typer.Exit(code=1)

    # Output result
    if json_output:
        typer.echo(json.dumps(result))
    else:
        typer.echo(f"Success! Experience {experience_id} feedback recorded. Quality score: {result.get('quality_score', 'unknown')}, Status: {result.get('status', 'updated')}")
