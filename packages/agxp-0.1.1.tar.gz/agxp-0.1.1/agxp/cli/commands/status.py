"""
agxp status — display AGXP account status and server information.
"""
from __future__ import annotations

import json
import os
import urllib.request
from pathlib import Path

import typer

_DEFAULT_DATA_DIR = str(Path.home() / ".agxp")
from agxp.cli.constants import AGXP_SERVER_URL
_REMOTE_TIMEOUT = 5


def _get_config_path(data_dir: str) -> str:
    """Return path to config.json."""
    if data_dir == _DEFAULT_DATA_DIR:
        return os.path.join(os.path.expanduser("~"), ".agxp", "config.json")
    return os.path.join(data_dir, "config.json")


def _read_config(data_dir: str) -> dict:
    """Read config file, return empty dict if not found."""
    config_path = _get_config_path(data_dir)
    if os.path.exists(config_path):
        with open(config_path, "r") as f:
            return json.load(f)
    return {}


def status(
    data_dir: str = typer.Option(_DEFAULT_DATA_DIR, "--data-dir", help="Data directory path for config"),
    json_output: bool = typer.Option(False, "--json", help="Output pure JSON format, no extra prompts"),
) -> None:
    """Show AGXP account status and server information."""
    config = _read_config(data_dir)
    token = config.get("api_token") or config.get("anonymous_token")

    # Auto create anonymous token if not exists
    if not token:
        try:
            req = urllib.request.Request(
                f"{AGXP_SERVER_URL.rstrip('/')}/api/v1/auth/anonymous",
                method="POST",
                data=b""
            )
            req.add_header("Content-Type", "application/json")
            with urllib.request.urlopen(req, timeout=_REMOTE_TIMEOUT) as resp:
                data = json.load(resp)
                token = data["token"]
                # Save to config
                config["anonymous_token"] = token
                os.makedirs(os.path.dirname(_get_config_path(data_dir)), exist_ok=True)
                with open(_get_config_path(data_dir), "w") as f:
                    json.dump(config, f, indent=2)
        except Exception as e:
            if json_output:
                typer.echo(json.dumps({"error": f"Failed to create anonymous session: {str(e)}"}), err=True)
            else:
                typer.echo(f"Error creating anonymous session: {str(e)}", err=True)
            raise typer.Exit(code=1)

    # Fetch server health
    server_online = False
    health_info = {}
    try:
        req = urllib.request.Request(f"{AGXP_SERVER_URL.rstrip('/')}/health")
        with urllib.request.urlopen(req, timeout=_REMOTE_TIMEOUT) as resp:
            health_info = json.loads(resp.read())
            server_online = True
    except:
        pass

    # Fetch user info
    user_info = {}
    fetch_user_success = False
    if token and server_online:
        try:
            req = urllib.request.Request(
                f"{AGXP_SERVER_URL.rstrip('/')}/api/v1/user/me",
                headers={"Authorization": f"Bearer {token}"}
            )
            with urllib.request.urlopen(req, timeout=_REMOTE_TIMEOUT) as resp:
                user_info = json.loads(resp.read())
                fetch_user_success = True
        except:
            pass

    # JSON output
    if json_output:
        output = {
            "server": AGXP_SERVER_URL,
            "server_online": server_online,
            "server_version": health_info.get("version") if server_online else None,
            "login_status": "logged_in" if config.get("api_token") else "anonymous" if config.get("anonymous_token") else "not_logged_in",
            "config_directory": data_dir,
            "user_info": user_info if fetch_user_success else None
        }
        typer.echo(json.dumps(output, indent=2))
        return

    # Human readable output
    typer.echo("📊 AGXP Status")
    typer.echo("=" * 40)

    # Server info
    typer.echo(f"Server:          {AGXP_SERVER_URL}")
    if server_online:
        typer.echo(f"Server status:   ✓ online (version {health_info.get('version', 'unknown')})")
    else:
        typer.echo(f"Server status:   ✗ unreachable")

    # Auth status
    if config.get("api_token"):
        typer.echo(f"Login status:    ✓ logged in")
    elif config.get("anonymous_token"):
        typer.echo(f"Login status:    anonymous mode")
    else:
        typer.echo(f"Login status:    ✗ not logged in (run: agxp login)")

    # Config directory
    typer.echo(f"Config directory:{data_dir}")
    if not os.path.isdir(data_dir):
        os.makedirs(data_dir, exist_ok=True)
        typer.echo(f"                 created directory")

    # User info if logged in
    if fetch_user_success:
        typer.echo("")
        typer.echo("💳 Account Info:")
        typer.echo(f"  Type:            {user_info['user_type'].replace('_', ' ').title()}")
        typer.echo(f"  Credit Balance:  {user_info['credit_balance']} credits")
        typer.echo(f"  Experiences:     {user_info['experience_count']} contributed")
        typer.echo(f"  Searches Today:  {user_info['search_count_today']}/{user_info['max_search_per_day']}")
        if user_info.get("credit_balance", 0) < 10:
            typer.echo(f"  ⚠️  Low balance! Contribute an experience to get 30 credits.")

    # Install info
    typer.echo("")
    typer.echo("⚡ Installed commands:")
    typer.echo("  ✓ agxp login      — authenticate with Github")
    typer.echo("  ✓ agxp query      — search experiences")
    typer.echo("  ✓ agxp contribute — add new experience")
    typer.echo("  ✓ agxp feedback   — rate experience usefulness")
    typer.echo("  ✓ agxp status     — show this status page")
    typer.echo("  ✓ agxp mcp        — start MCP server for Claude Code")
    typer.echo("  ✓ agxp hook       — Claude Code hook integration")
