import json
import os
import re
import sys
from pathlib import Path

import typer

def get_error_fingerprint(stderr_output: str) -> str:
    # 匹配 Python 报错最后一行，例如 "RecursionError: maximum recursion depth exceeded"
    error_type_match = re.search(r'^([A-Za-z]+Error):', stderr_output, re.MULTILINE)
    error_type = error_type_match.group(1) if error_type_match else "UnknownError"
    
    # 匹配最后出错的文件和函数名，忽略行号
    # 例如从 'File "/src/db.py", line 45, in connect' 提取 db.py 和 connect
    trace_match = re.findall(r'File "([^"]+)", line \d+, in (\w+)', stderr_output)
    
    if trace_match:
        last_trace = trace_match[-1] # 拿到栈顶（最靠近报错发生点）的位置
        filename = last_trace[0].split('/')[-1] # 只取文件名
        func_name = last_trace[1]
        return f"{error_type}@{filename}:{func_name}"
    
    return error_type

def hook(
    state_dir: Path = typer.Option(
        Path.home() / ".agxp" / "states",
        "--state-dir",
        help="Directory to store hook session states"
    )
) -> None:
    """
    Hook endpoint for Claude Code.
    Reads JSON from STDIN continuously or as a one-shot. 
    Maintains error count and fingerprint persistently in state_dir based on session UUID.
    """
    os.makedirs(state_dir, exist_ok=True)

    try:
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue

            try:
                payload = json.loads(line)
            except json.JSONDecodeError:
                print(json.dumps({}))
                sys.stdout.flush()
                continue

            event = payload.get("hook_event_name")
            tool_name = payload.get("tool_name")
            transcript_path = payload.get("transcript_path")
            
            if tool_name != "Bash" or not transcript_path:
                print(json.dumps({}))
                sys.stdout.flush()
                continue
            
            # Extract UUID from transcript_path (e.g. .../UUID.jsonl -> UUID)
            session_id = Path(transcript_path).stem
            state_file = state_dir / f"{session_id}.json"
            
            # Read existing state json
            state = {"count": 0, "fingerprint": ""}
            if state_file.exists():
                try:
                    state = json.loads(state_file.read_text().strip())
                except (json.JSONDecodeError, ValueError):
                    pass

            if event == "PostToolUse":
                # Check if successful response. If so, reset error state.
                if payload.get("tool_response", {}).get("success") is True:
                    state = {"count": 0, "fingerprint": ""}
                    state_file.write_text(json.dumps(state))
                print(json.dumps({}))
                sys.stdout.flush()

            elif event == "PostToolUseFailure":
                error_str = payload.get("error", "")
                current_fingerprint = get_error_fingerprint(error_str)
                
                if current_fingerprint == state["fingerprint"]:
                    state["count"] += 1
                else:
                    state["fingerprint"] = current_fingerprint
                    state["count"] = 1
                
                if state["count"] >= 2:
                    # Reset count on trigger
                    state["count"] = 0
                    state_file.write_text(json.dumps(state))
                    
                    print(json.dumps({
                        "hookSpecificOutput": {
                            "hookEventName": "PostToolUseFailure",
                            "additionalContext": "Should Call AGXP MCP Tool for historical Experience。如果AGXP没有相关经验，下一次不用针对这个问题再调用历史经验了。"
                        }
                    }))
                else:
                    state_file.write_text(json.dumps(state))
                    print(json.dumps({}))
                sys.stdout.flush()

            else:
                # Other hook events can just be gracefully ignored
                print(json.dumps({}))
                sys.stdout.flush()

    except KeyboardInterrupt:
        sys.exit(0)


