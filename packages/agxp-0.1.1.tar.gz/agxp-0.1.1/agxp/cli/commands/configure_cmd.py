"""
AGXP Claude Configuration Command
Automatically configures AGXP hooks, MCP server, and SKILL file
in Claude Code settings, without modifying existing user configuration.
"""
import importlib.resources
import json
import os
import shutil
import sys
from pathlib import Path
from typing import Dict, List

import typer


def configure(
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Show changes without modifying configuration files"
    )
) -> None:
    """
    Configure AGXP integration with Claude Code:
    1. Adds AGXP PostToolUse and PostToolUseFailure hooks
    2. Adds AGXP MCP server configuration
    3. Installs AGXP SKILL.md to ~/.claude/skills/agxp/
    4. Does not modify or remove any existing user configuration
    """
    typer.echo("==========================================")
    typer.echo("  AGXP Claude Configuration")
    typer.echo("==========================================")
    typer.echo("")

    # Step 1: Create required state directory
    state_dir = Path.home() / ".agxp" / "states"
    if not dry_run:
        state_dir.mkdir(parents=True, exist_ok=True)
    typer.echo(f"Step 1: State directory {'would be' if dry_run else 'is'} ready at {state_dir}")

    # Step 2: Locate Claude settings file
    claude_settings_path = Path.home() / ".claude" / "settings.json"
    backup_path = claude_settings_path.with_suffix(".json.bak")
    config: Dict = {}

    # Read existing config if present
    if claude_settings_path.exists():
        try:
            with open(claude_settings_path, "r", encoding="utf-8") as f:
                config = json.load(f)
            typer.echo(f"Step 2: Loaded existing configuration from {claude_settings_path}")

            # Backup existing config
            if not dry_run:
                shutil.copy(claude_settings_path, backup_path)
                typer.echo(f"  ✓ Backup saved to {backup_path}")
        except json.JSONDecodeError as e:
            typer.echo(f"❌ Invalid JSON in {claude_settings_path}: {str(e)}", err=True)
            raise typer.Exit(1)
        except IOError as e:
            typer.echo(f"❌ Cannot read {claude_settings_path}: {str(e)}", err=True)
            raise typer.Exit(1)
    else:
        typer.echo(f"Step 2: No existing configuration found, will create new file at {claude_settings_path}")

    # Step 3: Configure hooks
    typer.echo("")
    typer.echo("Step 3: Configuring AGXP hooks...")

    # AGXP hook command string
    hook_command = f"agxp hook --state-dir {str(state_dir.expanduser())}"

    # Hook structure to add for each event
    agxp_hook_config = {
        "matcher": "Bash",
        "hooks": [
            {
                "type": "command",
                "command": hook_command
            }
        ]
    }

    # Get existing hooks (should be dict format)
    hooks_config = config.get("hooks", {})
    if not isinstance(hooks_config, dict):
        # If hooks is not dict (old format or invalid), convert to empty dict
        typer.echo("  · Converting old hook format to new structure")
        hooks_config = {}

    added_hooks = 0

    # Process both events
    for event_name in ["PostToolUse", "PostToolUseFailure"]:
        event_hooks = hooks_config.get(event_name, [])

        # Check if AGXP hook already exists for this event
        has_agxp_hook = False
        for hook_entry in event_hooks:
            if isinstance(hook_entry, dict) and hook_entry.get("matcher") == "Bash":
                # Check if any hook in this entry is our AGXP hook
                for h in hook_entry.get("hooks", []):
                    if isinstance(h, dict) and h.get("type") == "command" and "agxp hook" in h.get("command", ""):
                        has_agxp_hook = True
                        break
        if has_agxp_hook:
            typer.echo(f"  · AGXP {event_name} hook already exists")
            continue

        # Add the hook for this event
        event_hooks.append(agxp_hook_config)
        hooks_config[event_name] = event_hooks
        added_hooks +=1
        typer.echo(f"  {'Would add' if dry_run else 'Added'} AGXP {event_name} hook")

    if added_hooks > 0:
        config["hooks"] = hooks_config
    else:
        typer.echo("  · All AGXP hooks already exist, no changes needed")

    # Step 4: Configure MCP server
    typer.echo("")
    typer.echo("Step 4: Configuring AGXP MCP server...")

    agxp_mcp_config = {
        "command": "agxp",
        "args": ["mcp"]
    }

    mcp_servers = config.get("mcpServers", {})
    if "agxp" not in mcp_servers:
        mcp_servers["agxp"] = agxp_mcp_config
        config["mcpServers"] = mcp_servers
        typer.echo(f"  {'Would add' if dry_run else 'Added'} AGXP MCP server configuration")
    else:
        typer.echo("  · AGXP MCP server already exists, no changes needed")

    # Step 5: Install SKILL.md
    typer.echo("")
    typer.echo("Step 5: Installing AGXP SKILL file...")

    skill_dest = Path.home() / ".claude" / "skills" / "agxp" / "SKILL.md"

    # Locate the bundled SKILL.md from the package
    try:
        skill_source = importlib.resources.files("agxp.cli.data").joinpath("SKILL.md")
    except Exception as e:
        typer.echo(f"❌ Cannot locate bundled SKILL.md: {e}", err=True)
        raise typer.Exit(1)

    if skill_dest.exists():
        # Check if content is identical
        existing_content = skill_dest.read_text(encoding="utf-8")
        source_content = skill_source.read_text(encoding="utf-8")  # type: ignore[union-attr]
        if existing_content == source_content:
            typer.echo("  · SKILL.md already up to date, no changes needed")
        else:
            if not dry_run:
                skill_dest.write_text(source_content, encoding="utf-8")
            typer.echo(f"  {'Would update' if dry_run else 'Updated'} SKILL.md at {skill_dest}")
    else:
        if not dry_run:
            skill_dest.parent.mkdir(parents=True, exist_ok=True)
            source_content = skill_source.read_text(encoding="utf-8")  # type: ignore[union-attr]
            skill_dest.write_text(source_content, encoding="utf-8")
        typer.echo(f"  {'Would install' if dry_run else 'Installed'} SKILL.md to {skill_dest}")

    # Step 6: Write configuration back
    typer.echo("")
    if dry_run:
        typer.echo("Step 6: Dry run mode - no changes written to disk")
        typer.echo("")
        typer.echo("Proposed configuration changes:")
        typer.echo("-" * 50)
        typer.echo(json.dumps(config, indent=2))
        typer.echo("-" * 50)
    else:
        try:
            # Ensure parent directory exists
            claude_settings_path.parent.mkdir(parents=True, exist_ok=True)

            with open(claude_settings_path, "w", encoding="utf-8") as f:
                json.dump(config, f, indent=2, ensure_ascii=False)

            typer.echo(f"Step 6: Configuration successfully written to {claude_settings_path}")
            typer.echo("")
            typer.echo("✅ Configuration complete!")
            typer.echo("👉 Please restart Claude Code for changes to take effect.")
            typer.echo("")
            typer.echo("What was configured:")
            typer.echo("  1. PostToolUse Hook: Triggers after every tool execution")
            typer.echo("  2. PostToolUseFailure Hook: Triggers after tool execution failures")
            typer.echo("  3. MCP Server: Enables AGXP tools in Claude Code")
            typer.echo("  4. SKILL File: Installed to ~/.claude/skills/agxp/SKILL.md")
        except IOError as e:
            typer.echo(f"❌ Cannot write to {claude_settings_path}: {str(e)}", err=True)
            # Restore backup if we created one
            if backup_path.exists():
                shutil.copy(backup_path, claude_settings_path)
                typer.echo(f"  ✓ Restored original configuration from backup")
            raise typer.Exit(1)
