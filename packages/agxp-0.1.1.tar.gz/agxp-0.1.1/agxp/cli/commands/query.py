"""
agxp query — search the AGXP experience knowledge base.

Output is NDJSON to stdout (one JSON line per result).
"""
from __future__ import annotations

import json
import os
import urllib.request
from pathlib import Path

import typer

_DEFAULT_DATA_DIR = str(Path.home() / ".agxp")
from agxp.cli.constants import AGXP_SERVER_URL
_REMOTE_TIMEOUT = 10


def _get_config_path(data_dir: str) -> str:
    """Return path to config.json."""
    if data_dir == _DEFAULT_DATA_DIR:
        return os.path.join(os.path.expanduser("~"), ".agxp", "config.json")
    return os.path.join(data_dir, "config.json")


def _read_config(data_dir: str) -> dict:
    """Read config file, return empty dict if not found."""
    config_path = _get_config_path(data_dir)
    if os.path.exists(config_path):
        with open(config_path, "r") as f:
            return json.load(f)
    return {}


def _write_config(config: dict, data_dir: str) -> None:
    """Write config to file, creating directories if needed."""
    config_path = _get_config_path(data_dir)
    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)


def _get_or_create_token(data_dir: str) -> str:
    """Get token from config, auto create anonymous token if not exists."""
    config = _read_config(data_dir)
    token = config.get("api_token") or config.get("anonymous_token")
    if not token:
        # Auto create anonymous session
        try:
            req = urllib.request.Request(
                f"{AGXP_SERVER_URL.rstrip('/')}/api/v1/auth/anonymous",
                method="POST",
                data=b"",
            )
            req.add_header("Content-Type", "application/json")
            with urllib.request.urlopen(req, timeout=_REMOTE_TIMEOUT) as resp:
                data = json.loads(resp.read().decode())
                token = data["token"]

                # Save anonymous token to config
                config["anonymous_token"] = token
                _write_config(config, data_dir)
        except Exception as e:
            typer.echo(
                f"Error creating anonymous session: {str(e)}",
                err=True,
            )
            raise typer.Exit(code=1)
    return token


def query(
    query_text: str = typer.Argument(..., help="Search query"),
    domain: str | None = typer.Option(None, "--domain", help="Filter by domain"),
    task_type: str | None = typer.Option(None, "--task-type", help="Filter by task type"),
    limit: int = typer.Option(10, "--limit", help="Max results to return"),
    data_dir: str = typer.Option(_DEFAULT_DATA_DIR, "--data-dir", help="Data directory path for config"),
    json_output: bool = typer.Option(False, "--json", help="Output pure JSON array format, no extra prompts"),
) -> None:
    """Search the AGXP experience knowledge base."""
    token = _get_or_create_token(data_dir)

    # Call remote API
    body = {"query": query_text, "limit": limit}
    if domain is not None:
        body["domain"] = domain
    if task_type is not None:
        body["task_type"] = task_type

    req = urllib.request.Request(
        f"{AGXP_SERVER_URL.rstrip('/')}/api/v1/query",
        method="POST",
        data=json.dumps(body).encode(),
    )
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", f"Bearer {token}")

    try:
        with urllib.request.urlopen(req, timeout=_REMOTE_TIMEOUT) as resp:
            lines = resp.read().decode().strip().splitlines()
    except Exception as e:
        error_msg = f"Error searching experiences: {str(e)}"
        if json_output:
            typer.echo(json.dumps({"error": error_msg}), err=True)
        else:
            typer.echo(error_msg, err=True)
        raise typer.Exit(code=1)

    # Parse results
    results = []
    pending = None
    for line in lines:
        if not line.strip():
            continue
        obj = json.loads(line)
        if obj.get("type") == "result":
            exp = obj.get("experience", {})
            exp["experience_id"] = exp.pop("id", exp.get("experience_id"))
            exp.pop("updated_at", None)
            results.append(exp)
        elif obj.get("type") == "pending_feedback":
            pending = obj.get("feedback", [])

    # Show pending feedback hint on stderr only if not json mode
    if pending and not json_output:
        typer.echo("Pending feedback from previous search:", err=True)
        for p in pending:
            typer.echo(
                f"  {p['experience_id']}: {p['situation'][:100]}", err=True
            )
        typer.echo(
            "Use: agxp feedback --experience-id <id> --useful/--not-useful",
            err=True,
        )

    if json_output:
        # Output pure JSON array
        typer.echo(json.dumps(results, default=str))
    else:
        # Output NDJSON format (one per line)
        for r in results:
            typer.echo(json.dumps(r, default=str))
