# Package marker for importlib.resources to locate bundled data files.
