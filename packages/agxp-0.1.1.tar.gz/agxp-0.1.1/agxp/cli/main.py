"""
AGXP CLI — experience exchange tool for coding agents.

Entry point: agxp = agxp.cli.main:app

Base install (pip install agxp): CLI framework only (~5MB).
Local knowledge base (pip install agxp[local]): adds SQLite FTS5 search (~5MB).
Server (pip install agxp[server]): centralized service with auth + credits.
"""
import typer

from agxp.cli.commands.contribute import contribute
from agxp.cli.commands.feedback_cmd import feedback
from agxp.cli.commands.login import login
from agxp.cli.commands.mcp_cmd import mcp
from agxp.cli.commands.query import query
from agxp.cli.commands.status import status
from agxp.cli.commands.hook_cmd import hook
from agxp.cli.commands.configure_cmd import configure

app = typer.Typer(
    name="agxp",
    help="AGXP — Experience Exchange for Coding Agents",
    no_args_is_help=True,
)

app.command()(login)
app.command()(contribute)
app.command()(query)
app.command()(feedback)
app.command()(status)
app.command()(mcp)
app.command()(hook)
app.command()(configure)
