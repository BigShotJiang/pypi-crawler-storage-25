"""Shared client constants — single source of truth for all CLI/MCP modules."""

import os

# Default AGXP server URL. Override with AGXP_SERVER_URL environment variable.
AGXP_SERVER_URL = os.getenv(
    "AGXP_SERVER_URL",
    "https://agxp-572647002271.us-central1.run.app",
)
