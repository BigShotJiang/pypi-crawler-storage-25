import os
import random
from collections import defaultdict
from itertools import chain

import networkx as nx
import numpy as np
from joblib import Parallel, delayed
from tqdm.auto import tqdm

from .parallel import (
    get_edge_weight,
    get_sampling_value,
    normalize_probabilities,
    parallel_generate_walks,
    parallel_precompute_probabilities,
    validate_positive_number,
)
from .word2vec import Word2Vec


class Node2Vec:
    FIRST_TRAVEL_KEY = "first_travel_key"
    PROBABILITIES_KEY = "probabilities"
    NEIGHBORS_KEY = "neighbors"
    WEIGHT_KEY = "weight"
    NUM_WALKS_KEY = "num_walks"
    WALK_LENGTH_KEY = "walk_length"
    P_KEY = "p"
    Q_KEY = "q"

    def __init__(
        self,
        graph: nx.Graph,
        dimensions: int = 128,
        walk_length: int = 80,
        num_walks: int = 10,
        p: float = 1,
        q: float = 1,
        weight_key: str = "weight",
        workers: int = 1,
        sampling_strategy: dict = None,
        quiet: bool = False,
        temp_folder: str = None,
        seed: int = None,
    ):
        """
        Initiates the Node2Vec object, precomputes walking probabilities and generates the walks.

        :param graph: Input graph
        :param dimensions: Embedding dimensions (default: 128)
        :param walk_length: Number of nodes in each walk (default: 80)
        :param num_walks: Number of walks per node (default: 10)
        :param p: Return hyper parameter (default: 1)
        :param q: Inout parameter (default: 1)
        :param weight_key: On weighted graphs, this is the key for the weight attribute (default: 'weight')
        :param workers: Number of workers for parallel execution (default: 1)
        :param sampling_strategy: Node specific sampling strategies, supports setting node specific 'q', 'p', 'num_walks' and 'walk_length'.
        :param seed: Seed for the random number generator.
        Use these keys exactly. If not set, will use the global ones which were passed on the object initialization
        :param temp_folder: Path to folder with enough space to hold the memory map of self.d_graph (for big graphs); to be passed joblib.Parallel.temp_folder
        """

        self.graph = graph
        self.dimensions = dimensions
        self.walk_length = walk_length
        self.num_walks = num_walks
        self.p = validate_positive_number(p, "p")
        self.q = validate_positive_number(q, "q")
        self.weight_key = weight_key
        self.workers = workers
        self.quiet = quiet
        self.d_graph = defaultdict(dict)

        if sampling_strategy is None:
            self.sampling_strategy = {}
        else:
            self.sampling_strategy = sampling_strategy
            self._validate_sampling_strategy()

        self.temp_folder, self.require = None, None
        if temp_folder:
            if not os.path.isdir(temp_folder):
                raise NotADirectoryError("temp_folder does not exist or is not a directory. ({})".format(temp_folder))

            self.temp_folder = temp_folder
            self.require = "sharedmem"

        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)

        self._precompute_probabilities()
        self.walks = self._generate_walks()

    def _validate_sampling_strategy(self):
        """Validate node-specific p/q overrides eagerly."""
        for node, strategy in self.sampling_strategy.items():
            if not isinstance(strategy, dict):
                raise ValueError(f"sampling_strategy[{node!r}] must be a dictionary")
            for key in (self.P_KEY, self.Q_KEY):
                if key in strategy:
                    validate_positive_number(strategy[key], f"sampling_strategy[{node!r}][{key!r}]")

    def _precompute_probabilities(self):
        """
        Precomputes transition probabilities for each node.
        Uses parallel processing when workers > 1.
        """

        d_graph = self.d_graph

        # If only one worker, use sequential processing (faster for small graphs)
        if self.workers == 1:
            nodes_generator = self.graph.nodes() if self.quiet else tqdm(self.graph.nodes(), desc="Computing transition probabilities")

            for source in nodes_generator:
                self._compute_probabilities_for_source(source)
        else:
            # Parallel processing for multiple workers
            nodes_list = list(self.graph.nodes())

            if not self.quiet:
                # Show progress bar for parallel processing
                nodes_generator = tqdm(nodes_list, desc="Computing transition probabilities")
            else:
                nodes_generator = nodes_list

            # Process nodes in parallel
            # Note: tqdm progress may not update smoothly in parallel mode, but will show completion
            results = Parallel(n_jobs=self.workers, temp_folder=self.temp_folder, require=self.require)(
                delayed(parallel_precompute_probabilities)(
                    source,
                    self.graph,
                    self.p,
                    self.q,
                    self.weight_key,
                    self.sampling_strategy,
                    self.PROBABILITIES_KEY,
                )
                for source in nodes_list
            )

            # Close progress bar if used
            if not self.quiet:
                nodes_generator.close()

            # Merge results into d_graph
            for source, result in zip(nodes_list, results):
                # Init probabilities dict for first travel
                if self.PROBABILITIES_KEY not in d_graph[source]:
                    d_graph[source][self.PROBABILITIES_KEY] = dict()

                # Update probabilities for each current_node
                for current_node in result:
                    if current_node == "first_travel" or current_node == "neighbors":
                        continue

                    # Init probabilities dict
                    if self.PROBABILITIES_KEY not in d_graph[current_node]:
                        d_graph[current_node][self.PROBABILITIES_KEY] = dict()

                    # Store the computed probabilities
                    d_graph[current_node][self.PROBABILITIES_KEY][source] = result[current_node]

                # Store first_travel weights
                d_graph[source][self.FIRST_TRAVEL_KEY] = result["first_travel"]

                # Store neighbors
                d_graph[source][self.NEIGHBORS_KEY] = result["neighbors"]

    def _compute_probabilities_for_source(self, source):
        """
        Computes transition probabilities for a single source node.
        Used for sequential processing.
        """
        d_graph = self.d_graph

        # Init probabilities dict for first travel
        if self.PROBABILITIES_KEY not in d_graph[source]:
            d_graph[source][self.PROBABILITIES_KEY] = dict()

        for current_node in self.graph.neighbors(source):

            # Init probabilities dict
            if self.PROBABILITIES_KEY not in d_graph[current_node]:
                d_graph[current_node][self.PROBABILITIES_KEY] = dict()

            unnormalized_weights = list()
            d_neighbors = list()

            # Calculate unnormalized weights
            for destination in self.graph.neighbors(current_node):

                p = get_sampling_value(self.sampling_strategy, current_node, self.P_KEY, self.p)
                q = get_sampling_value(self.sampling_strategy, current_node, self.Q_KEY, self.q)

                weight = get_edge_weight(self.graph, current_node, destination, self.weight_key)

                if destination == source:  # Backwards probability
                    ss_weight = weight * 1 / p
                elif destination in self.graph[source]:  # If the neighbor is connected to the source
                    ss_weight = weight
                else:
                    ss_weight = weight * 1 / q

                # Assign the unnormalized sampling strategy weight, normalize during random walk
                unnormalized_weights.append(ss_weight)
                d_neighbors.append(destination)

            # Normalize
            d_graph[current_node][self.PROBABILITIES_KEY][source] = normalize_probabilities(
                unnormalized_weights,
                context=f"transition from {source!r} through {current_node!r}",
            )

        # Calculate first_travel weights for source
        first_travel_weights = []

        for destination in self.graph.neighbors(source):
            weight = get_edge_weight(self.graph, source, destination, self.weight_key)
            first_travel_weights.append(weight)

        d_graph[source][self.FIRST_TRAVEL_KEY] = normalize_probabilities(
            first_travel_weights,
            context=f"first travel from {source!r}",
        )

        # Save neighbors
        d_graph[source][self.NEIGHBORS_KEY] = list(self.graph.neighbors(source))

    def _generate_walks(self) -> list:
        """
        Generates the random walks which will be used as the skip-gram input.
        :return: List of walks. Each walk is a list of nodes.
        """

        # Split num_walks for each worker
        num_walks_lists = np.array_split(range(self.num_walks), self.workers)

        walk_results = Parallel(n_jobs=self.workers, temp_folder=self.temp_folder, require=self.require)(
            delayed(parallel_generate_walks)(
                self.d_graph,
                self.walk_length,
                len(num_walks),
                idx,
                self.sampling_strategy,
                self.NUM_WALKS_KEY,
                self.WALK_LENGTH_KEY,
                self.NEIGHBORS_KEY,
                self.PROBABILITIES_KEY,
                self.FIRST_TRAVEL_KEY,
                self.quiet,
            )
            for idx, num_walks in enumerate(num_walks_lists, 1)
        )

        walks = list(chain.from_iterable(walk_results))

        return walks

    def fit(self, **skip_gram_params) -> Word2Vec:
        """
        Creates the embeddings using Word2Vec.
        :param skip_gram_params: Parameters for Word2Vec - do not supply 'vector_size' it is
            taken from the Node2Vec 'dimensions' parameter
        :type skip_gram_params: dict
        :return: A Word2Vec model
        """

        if "workers" not in skip_gram_params:
            skip_gram_params["workers"] = self.workers

        if "vector_size" not in skip_gram_params:
            skip_gram_params["vector_size"] = self.dimensions

        if "sg" not in skip_gram_params:
            skip_gram_params["sg"] = 1

        return Word2Vec(self.walks, **skip_gram_params)
