"""
verdict/core.py — The engine. Experiment + Analysis.
Parallel execution for speed.
"""

import time
import random
import itertools
import numpy as np
from scipy import stats
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Optional, Callable


# ═══════════════════════════════════════════════
#  PRICING — OpenAI models (cost per token USD)
# ═══════════════════════════════════════════════

PRICING = {
    "gpt-4o": {"input": 2.50 / 1_000_000, "output": 10.00 / 1_000_000},
    "gpt-4o-mini": {"input": 0.15 / 1_000_000, "output": 0.60 / 1_000_000},
    "gpt-4.1": {"input": 2.00 / 1_000_000, "output": 8.00 / 1_000_000},
    "gpt-4.1-mini": {"input": 0.40 / 1_000_000, "output": 1.60 / 1_000_000},
    "gpt-4.1-nano": {"input": 0.10 / 1_000_000, "output": 0.40 / 1_000_000},
    "o3-mini": {"input": 1.10 / 1_000_000, "output": 4.40 / 1_000_000},
}


# ═══════════════════════════════════════════════
#  DATA CLASSES
# ═══════════════════════════════════════════════


@dataclass
class Variant:
    """
    One model to test.

    Parameters
    ----------
    name : str
        Display name. e.g., "gpt-4o"
    fn : Callable
        (config, query) → str or dict
        str: verdict estimates tokens
        dict: {"output": "...", "usage": {"input_tokens": N, "output_tokens": N}}
    config : dict
        Passed as first arg to fn.
    model : str, optional
        For pricing lookup.
    pricing : dict, optional
        Override: {"input": per_token, "output": per_token}
    """

    name: str
    fn: Callable
    config: dict = field(default_factory=dict)
    model: Optional[str] = None
    pricing: Optional[dict] = None

    def get_pricing(self) -> dict:
        if self.pricing:
            return self.pricing
        if self.model and self.model in PRICING:
            return PRICING[self.model]
        if self.name in PRICING:
            return PRICING[self.name]
        return {"input": 0.0, "output": 0.0}


@dataclass
class RunResult:
    """One execution of one variant on one query."""

    variant: str
    query: Any
    query_idx: int
    output: str
    latency_ms: float
    input_tokens: int
    output_tokens: int
    cost: float
    error: Optional[str]
    score: float = 0.0


# ═══════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════


def _get_query_text(query) -> str:
    """Extract display text from any query type."""
    if isinstance(query, str):
        return query
    if isinstance(query, dict):
        return query.get("query", str(query))
    return str(query)


def _estimate_tokens(text: str) -> int:
    """Rough token estimate. ~1.35 tokens per word."""
    if not text:
        return 0
    return max(1, int(len(text.split()) * 1.35))


# ═══════════════════════════════════════════════
#  EXPERIMENT
# ═══════════════════════════════════════════════


class Experiment:
    """
    Compare N models on M queries with statistical rigor.

    Parameters
    ----------
    name : str
        Experiment name for display.
    variants : list[Variant]
        Models to compare. At least 2.
    queries : list
        Test inputs. Strings or dicts.
    judge : Judge
        Evaluator that scores outputs.
    runs : int
        Runs per variant per query. Default 20.
    monthly_volume : int
        For cost projection. Default 10,000.
    seed : int, optional
        For reproducible run ordering.
    max_workers : int, optional
        Max parallel threads. Default 10.
        Higher = faster but may hit API rate limits.
    """

    def __init__(
        self,
        name: str = "verdict experiment",
        variants: list = None,
        queries: list = None,
        judge=None,
        runs: int = 20,
        monthly_volume: int = 10_000,
        seed: Optional[int] = None,
        max_workers: int = 10,
    ):
        self.name = name
        self.variants = variants or []
        self.queries = queries or []
        self.judge = judge
        self.runs = runs
        self.monthly_volume = monthly_volume
        self.seed = seed
        self.max_workers = max_workers

        if len(self.variants) < 2:
            raise ValueError("Need at least 2 variants to compare.")
        if not self.queries:
            raise ValueError("Need at least 1 query.")
        if self.judge is None:
            raise ValueError("Need a judge. Use Judge(criteria=[...]).")

    def run(self) -> "Analysis":
        """Execute experiment in parallel and return Analysis."""

        # Build queue
        queue = []
        for variant in self.variants:
            for q_idx, query in enumerate(self.queries):
                for _ in range(self.runs):
                    queue.append((variant, query, q_idx))

        if self.seed is not None:
            random.seed(self.seed)
        random.shuffle(queue)

        total = len(queue)
        print(f"\n  verdict — {self.name}")
        print(
            f"  {len(self.variants)} variants × {len(self.queries)} queries "
            f"× {self.runs} runs = {total} total\n"
        )

        # ── Execute all runs in parallel ─────────
        results = [None] * total
        done_count = 0

        print("  Running experiments...")
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_idx = {}
            for i, (variant, query, q_idx) in enumerate(queue):
                future = executor.submit(self._execute, variant, query, q_idx)
                future_to_idx[future] = i

            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                results[idx] = future.result()
                done_count += 1
                self._progress(done_count, total)

        self._progress(total, total, done=True)

        # ── Judge all outputs in parallel ────────
        done_count = 0

        print("  Judging outputs...")
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_idx = {}
            for i, result in enumerate(results):
                if result.error is None:
                    query_text = _get_query_text(result.query)
                    future = executor.submit(self.judge.score, result.output, query_text)
                    future_to_idx[future] = i
                else:
                    result.score = 0.0
                    done_count += 1

            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                results[idx].score = future.result()
                done_count += 1
                self._progress(done_count, total)

        self._progress(total, total, done=True)

        return Analysis(
            name=self.name,
            results=results,
            variants=self.variants,
            queries=self.queries,
            monthly_volume=self.monthly_volume,
        )

    def _execute(self, variant, query, q_idx):
        """Execute ONE run."""
        pricing = variant.get_pricing()
        start = time.perf_counter()

        try:
            raw = variant.fn(variant.config, query)

            if isinstance(raw, dict):
                output = raw.get("output", str(raw))
                usage = raw.get("usage", {})
                in_tok = usage.get("input_tokens", 0)
                out_tok = usage.get("output_tokens", 0)
            else:
                output = str(raw)
                in_tok = _estimate_tokens(_get_query_text(query))
                out_tok = _estimate_tokens(output)

            error = None

        except Exception as e:
            output = ""
            in_tok = 0
            out_tok = 0
            error = str(e)

        latency = (time.perf_counter() - start) * 1000
        cost = in_tok * pricing["input"] + out_tok * pricing["output"]

        return RunResult(
            variant=variant.name,
            query=query,
            query_idx=q_idx,
            output=output,
            latency_ms=latency,
            input_tokens=in_tok,
            output_tokens=out_tok,
            cost=cost,
            error=error,
        )

    def _progress(self, current, total, done=False):
        pct = current / total
        bar = "█" * int(pct * 40) + "░" * (40 - int(pct * 40))
        end = " ✓\n" if done else ""
        print(f"\r  [{bar}] {current}/{total}{end}", end="", flush=True)


# ═══════════════════════════════════════════════
#  ANALYSIS
# ═══════════════════════════════════════════════


class Analysis:
    """Statistics and comparisons. Created by Experiment.run()."""

    def __init__(self, name, results, variants, queries, monthly_volume):
        self.name = name
        self.results = results
        self.variants = variants
        self.queries = queries
        self.monthly_volume = monthly_volume

        # Group by variant
        self.by_variant = {}
        for v in variants:
            self.by_variant[v.name] = [r for r in results if r.variant == v.name]

        # Pre-compute arrays (successful runs only)
        self.scores = {}
        self.latencies = {}
        self.costs = {}
        for vname, runs in self.by_variant.items():
            ok = [r for r in runs if r.error is None]
            self.scores[vname] = (
                np.array([r.score for r in ok]) if ok else np.array([0.0])
            )
            self.latencies[vname] = (
                np.array([r.latency_ms for r in ok]) if ok else np.array([0.0])
            )
            self.costs[vname] = (
                np.array([r.cost for r in ok]) if ok else np.array([0.0])
            )

    def summary(self, vname: str) -> dict:
        """Full metrics for one variant."""
        s = self.scores[vname]
        l = self.latencies[vname]
        c = self.costs[vname]
        runs = self.by_variant[vname]
        errs = sum(1 for r in runs if r.error is not None)
        n = len(s)
        ci = 1.96 * np.std(s, ddof=1) / np.sqrt(n) if n > 1 else 0

        return {
            "name": vname,
            "score_mean": float(np.mean(s)),
            "score_ci": float(ci),
            "score_std": float(np.std(s, ddof=1)) if n > 1 else 0.0,
            "latency_median": float(np.median(l)),
            "latency_p95": float(np.percentile(l, 95))
            if len(l) > 1
            else float(np.max(l)),
            "cost_per_query": float(np.mean(c)),
            "cost_monthly": float(np.mean(c)) * self.monthly_volume,
            "total_runs": len(runs),
            "errors": errs,
            "failure_rate": errs / len(runs) if runs else 0,
        }

    def compare(self, name_a: str, name_b: str) -> dict:
        """Statistical comparison between two variants."""
        a = self.scores[name_a]
        b = self.scores[name_b]

        # Welch's t-test
        if len(a) > 1 and len(b) > 1:
            t_stat, p_val = stats.ttest_ind(a, b, equal_var=False)
        else:
            t_stat, p_val = 0.0, 1.0

        # Cohen's d
        std_a = np.std(a, ddof=1) if len(a) > 1 else 0.001
        std_b = np.std(b, ddof=1) if len(b) > 1 else 0.001
        pooled = np.sqrt((std_a**2 + std_b**2) / 2)
        d = (float(np.mean(a)) - float(np.mean(b))) / pooled if pooled > 0 else 0.0

        # 95% CI of difference
        se = np.sqrt(np.var(a, ddof=1) / len(a) + np.var(b, ddof=1) / len(b))
        diff = float(np.mean(a) - np.mean(b))

        sig = p_val < 0.05
        winner = "none"
        if sig:
            winner = name_a if np.mean(a) > np.mean(b) else name_b

        abs_d = abs(d)
        mag = (
            "negligible"
            if abs_d < 0.2
            else "small" if abs_d < 0.5 else "medium" if abs_d < 0.8 else "large"
        )

        return {
            "a": name_a,
            "b": name_b,
            "mean_a": float(np.mean(a)),
            "mean_b": float(np.mean(b)),
            "p": float(p_val),
            "d": float(d),
            "ci_lower": diff - 1.96 * se,
            "ci_upper": diff + 1.96 * se,
            "significant": sig,
            "winner": winner,
            "magnitude": mag,
        }

    def all_comparisons(self) -> list:
        names = [v.name for v in self.variants]
        return [self.compare(a, b) for a, b in itertools.combinations(names, 2)]

    def query_breakdown(self) -> list:
        rows = []
        for q_idx, query in enumerate(self.queries):
            row = {"query": _get_query_text(query)[:50]}
            for v in self.variants:
                v_scores = [
                    r.score
                    for r in self.by_variant[v.name]
                    if r.query_idx == q_idx and r.error is None
                ]
                row[v.name] = float(np.mean(v_scores)) if v_scores else 0.0
            rows.append(row)
        return rows

    def recommendation(self) -> dict:
        sums = {v.name: self.summary(v.name) for v in self.variants}

        best_name = max(sums, key=lambda v: sums[v]["score_mean"])

        costs_sorted = sorted(sums.items(), key=lambda x: x[1]["cost_per_query"])
        cheap_half = [v for v, _ in costs_sorted[: max(1, len(costs_sorted) // 2 + 1)]]
        value_name = max(cheap_half, key=lambda v: sums[v]["score_mean"])

        free = [v for v in sums if sums[v]["cost_per_query"] < 0.0001]
        free_name = max(free, key=lambda v: sums[v]["score_mean"]) if free else None

        return {
            "best": {"name": best_name, **sums[best_name]},
            "value": {"name": value_name, **sums[value_name]},
            "free": {"name": free_name, **sums[free_name]} if free_name else None,
        }

    def display(self):
        from verdict.display import print_report

        print_report(self)