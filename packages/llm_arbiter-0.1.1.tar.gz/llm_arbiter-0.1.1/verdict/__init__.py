"""
verdict — A/B testing for LLMs.
Don't pick your model on vibes. Pick it with statistical proof.
"""

__version__ = "0.1.0"

from verdict.core import Experiment, Variant, Analysis
from verdict.judge import Judge

__all__ = ["Experiment", "Variant", "Analysis", "Judge"]