"""
Unit tests for QAOA algorithm classes.

These tests use the real Cirq simulator to check that:
  - All constructors accept valid inputs without error
  - from_ising and the QUBO constructor produce the same internal Ising model
  - sample() returns arrays of the right shape and dtype
  - optimize() runs without error and updates hyperparameters
  - Invalid hyperparameters raise ValueError
"""
import numpy as np
import pytest
from bqs import QAOA, pQAOA, pQAOASingleParameters, SingleSliceQAOA, COBYLA
from bqs.utils.bqm import qubo_to_ising

# ---------------------------------------------------------------------------
# Shared problem fixture  (2-variable chain: x0 – x1 – x2 – x3)
# ---------------------------------------------------------------------------
N = 4
Q_FULL = np.zeros((N, N))
for i, j in [(0, 1), (1, 2), (2, 3)]:
    Q_FULL[i, j] = Q_FULL[j, i] = 0.5

Q_S1 = np.zeros((2, 2)); Q_S1[0, 1] = Q_S1[1, 0] = 0.5
Q_S2 = np.zeros((2, 2)); Q_S2[0, 1] = Q_S2[1, 0] = 0.5

J_FULL, H_FULL, OFF_FULL = qubo_to_ising(Q_FULL)
J_S1, H_S1, OFF_S1 = qubo_to_ising(Q_S1)
J_S2, H_S2, OFF_S2 = qubo_to_ising(Q_S2)

VAR_MAP = np.array([[0, 2], [1, 3]])       # 2-var slice, 2 copies
Q_SS = Q_S1.copy()
J_SS, H_SS, OFF_SS = qubo_to_ising(Q_SS)

NUM_SAMPLES = 8
NUM_ITER = 3


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _check_ising(alg, J_ref, h_ref, off_ref):
    """Circuit's stored Ising matches a reference."""
    assert np.allclose(alg.circuit._J, J_ref)
    assert np.allclose(alg.circuit._h, h_ref)
    assert abs(alg.circuit._ising_offset - off_ref) < 1e-10


def _run_short(alg):
    alg.set_optimizer(COBYLA)
    alg.optimize(num_samples_training=NUM_SAMPLES, num_iterations=NUM_ITER,
                 opt_arguments={"display": False})


# ---------------------------------------------------------------------------
# QAOA
# ---------------------------------------------------------------------------

class TestQAOA:

    def test_construct_qubo(self):
        alg = QAOA(Q_FULL)
        assert alg.circuit is not None
        assert alg.hyperparameters.shape == (2,)

    def test_construct_p3(self):
        alg = QAOA(Q_FULL, p=3)
        assert alg.hyperparameters.shape == (6,)

    def test_construct_fixed_hp(self):
        hp = np.array([1.0, 2.0])
        alg = QAOA(Q_FULL, hyperparameters=hp)
        assert np.allclose(alg.hyperparameters, hp)

    def test_invalid_hp_shape(self):
        with pytest.raises(ValueError):
            QAOA(Q_FULL, p=2, hyperparameters=np.array([1.0]))

    def test_from_ising_same_ising(self):
        alg_q = QAOA(Q_FULL)
        alg_i = QAOA.from_ising(J_FULL, H_FULL, OFF_FULL)
        _check_ising(alg_i, alg_q.circuit._J, alg_q.circuit._h, alg_q.circuit._ising_offset)

    def test_from_ising_sample_shape(self):
        alg = QAOA.from_ising(J_FULL, H_FULL, OFF_FULL)
        s = alg.circuit.sample(num_samples=NUM_SAMPLES)
        assert s.shape == (NUM_SAMPLES, N)
        assert set(np.unique(s)).issubset({-1, 1})

    def test_optimize_updates_hp(self):
        alg = QAOA(Q_FULL)
        hp_before = alg.hyperparameters.copy()
        _run_short(alg)
        # Optimizer is free to change hyperparameters; just check type/shape
        assert alg.hyperparameters.shape == hp_before.shape

    def test_sample_shape(self):
        alg = QAOA(Q_FULL)
        s = alg.circuit.sample(num_samples=NUM_SAMPLES)
        assert s.shape == (NUM_SAMPLES, N)

    def test_evaluate_samples_scalar(self):
        alg = QAOA(Q_FULL)
        s = alg.circuit.sample(num_samples=NUM_SAMPLES)
        e = alg.objective_function.evaluate_samples(s)
        assert isinstance(e, float)


# ---------------------------------------------------------------------------
# pQAOA
# ---------------------------------------------------------------------------

class TestPQAOA:

    def test_construct_qubo(self):
        alg = pQAOA(Q_FULL, [Q_S1, Q_S2])
        assert alg.circuit is not None
        assert alg.hyperparameters.shape == (2, 2)

    def test_construct_p3(self):
        alg = pQAOA(Q_FULL, [Q_S1, Q_S2], p=3)
        assert alg.hyperparameters.shape == (2, 6)

    def test_invalid_hp_shape(self):
        with pytest.raises(ValueError):
            pQAOA(Q_FULL, [Q_S1, Q_S2], hyperparameters=np.ones((3, 2)))

    def test_from_ising_sample_shape(self):
        alg = pQAOA.from_ising(J_FULL, H_FULL, OFF_FULL,
                                slice_isings=[(J_S1, H_S1, OFF_S1), (J_S2, H_S2, OFF_S2)])
        s = alg.circuit.sample(num_samples=NUM_SAMPLES)
        # cartesian=False → NUM_SAMPLES * rows
        assert s.shape == (NUM_SAMPLES, N)

    def test_from_ising_zip_sample_shape(self):
        alg = pQAOA.from_ising(J_FULL, H_FULL, OFF_FULL,
                                slice_isings=[(J_S1, H_S1, OFF_S1), (J_S2, H_S2, OFF_S2)],
                                cartesian=False)
        s = alg.circuit.sample(num_samples=NUM_SAMPLES)
        assert s.shape == (NUM_SAMPLES, N)

    def test_optimize_runs(self):
        alg = pQAOA(Q_FULL, [Q_S1, Q_S2])
        _run_short(alg)

    def test_full_ising_model_stored(self):
        alg = pQAOA.from_ising(J_FULL, H_FULL, OFF_FULL,
                                slice_isings=[(J_S1, H_S1, OFF_S1), (J_S2, H_S2, OFF_S2)])
        assert np.allclose(alg.circuit._J, J_FULL)
        assert np.allclose(alg.circuit._h, H_FULL)


# ---------------------------------------------------------------------------
# pQAOASingleParameters
# ---------------------------------------------------------------------------

class TestPQAOASingleParameters:

    def test_construct_qubo(self):
        alg = pQAOASingleParameters(Q_FULL, [Q_S1, Q_S2])
        assert alg.hyperparameters.shape == (2,)

    def test_from_ising(self):
        alg = pQAOASingleParameters.from_ising(
            J_FULL, H_FULL, OFF_FULL,
            slice_isings=[(J_S1, H_S1, OFF_S1), (J_S2, H_S2, OFF_S2)])
        s = alg.circuit.sample(num_samples=NUM_SAMPLES)
        assert s.shape[1] == N

    def test_invalid_hp_shape(self):
        with pytest.raises(ValueError):
            pQAOASingleParameters(Q_FULL, [Q_S1, Q_S2], p=1,
                                  hyperparameters=np.ones(5))

    def test_optimize_runs(self):
        alg = pQAOASingleParameters(Q_FULL, [Q_S1, Q_S2])
        _run_short(alg)


# ---------------------------------------------------------------------------
# SingleSliceQAOA
# ---------------------------------------------------------------------------

class TestSingleSliceQAOA:

    def test_construct_qubo(self):
        alg = SingleSliceQAOA(Q_FULL, Q_SS, VAR_MAP)
        assert alg.circuit is not None
        assert alg.hyperparameters.shape == (2,)

    def test_from_ising_same_ising(self):
        alg_q = SingleSliceQAOA(Q_FULL, Q_SS, VAR_MAP)
        alg_i = SingleSliceQAOA.from_ising(
            J_FULL, H_FULL, OFF_FULL,
            slice_J=J_SS, slice_h=H_SS, slice_offset=OFF_SS, var_map=VAR_MAP)
        _check_ising(alg_i, alg_q.circuit._J, alg_q.circuit._h, alg_q.circuit._ising_offset)

    def test_sample_shape(self):
        alg = SingleSliceQAOA(Q_FULL, Q_SS, VAR_MAP)
        s = alg.circuit.sample(num_samples=NUM_SAMPLES)
        # 2 slices, cartesian → NUM_SAMPLES² rows
        assert s.shape == (NUM_SAMPLES ** 2, N)
        assert set(np.unique(s)).issubset({-1, 0, 1})

    def test_from_ising_sample_shape(self):
        alg = SingleSliceQAOA.from_ising(
            J_FULL, H_FULL, OFF_FULL,
            slice_J=J_SS, slice_h=H_SS, slice_offset=OFF_SS, var_map=VAR_MAP)
        s = alg.circuit.sample(num_samples=NUM_SAMPLES)
        assert s.shape == (NUM_SAMPLES ** 2, N)

    def test_optimize_runs(self):
        alg = SingleSliceQAOA(Q_FULL, Q_SS, VAR_MAP)
        _run_short(alg)

    def test_p3(self):
        alg = SingleSliceQAOA(Q_FULL, Q_SS, VAR_MAP, p=3)
        assert alg.hyperparameters.shape == (6,)
