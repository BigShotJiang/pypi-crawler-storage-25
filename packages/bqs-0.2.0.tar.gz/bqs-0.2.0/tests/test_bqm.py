import numpy as np
import pytest
from bqs.utils.bqm import (
    qubo_energy, ising_energy, ising_evaluate_samples,
    qubo_to_ising, ising_to_qubo,
)


# ---------------------------------------------------------------------------
# qubo_to_ising / ising_to_qubo round-trip
# ---------------------------------------------------------------------------

def _random_symmetric_qubo(n, seed=0):
    rng = np.random.default_rng(seed)
    A = rng.standard_normal((n, n))
    Q = (A + A.T) / 2
    return Q


@pytest.mark.parametrize("n", [2, 4, 6])
def test_qubo_ising_roundtrip(n):
    Q = _random_symmetric_qubo(n, seed=n)
    J, h, offset = qubo_to_ising(Q)
    Q2, _ = ising_to_qubo(J, h, offset)
    # ising_to_qubo does not recover the diagonal of Q (diagonal enters offset),
    # but the off-diagonal and diagonal must give the same energy on all inputs.
    rng = np.random.default_rng(42)
    for _ in range(20):
        x = rng.integers(0, 2, size=n).astype(float)
        s = 2 * x - 1
        e_qubo = qubo_energy(Q, 0.0, x)
        e_ising = ising_energy(J, h, offset, s)
        assert abs(e_qubo - e_ising) < 1e-10, f"energy mismatch for x={x}"


@pytest.mark.parametrize("n", [2, 3, 5])
def test_ising_qubo_roundtrip(n):
    rng = np.random.default_rng(n + 7)
    J = np.triu(rng.standard_normal((n, n)), k=1)
    h = rng.standard_normal(n)
    offset = float(rng.standard_normal())
    Q, new_offset = ising_to_qubo(J, h, offset)
    J2, h2, offset2 = qubo_to_ising(Q, new_offset)
    # Same energy on all spin configs
    for _ in range(20):
        s = rng.choice([-1, 1], size=n).astype(float)
        x = (s + 1) / 2
        e_ising = ising_energy(J, h, offset, s)
        e_qubo = qubo_energy(Q, new_offset, x)
        assert abs(e_ising - e_qubo) < 1e-10


# ---------------------------------------------------------------------------
# ising_evaluate_samples
# ---------------------------------------------------------------------------

def test_ising_evaluate_samples_single():
    J = np.array([[0.0, 0.5], [0.0, 0.0]])
    h = np.array([0.25, 0.25])
    s = np.array([[1.0, -1.0]])
    expected = ising_energy(J, h, 0.0, s[0])
    assert abs(ising_evaluate_samples(J, h, 0.0, s) - expected) < 1e-12


def test_ising_evaluate_samples_batch_mean():
    rng = np.random.default_rng(99)
    n = 4
    J = np.triu(rng.standard_normal((n, n)), k=1)
    h = rng.standard_normal(n)
    offset = 1.5
    samples = rng.choice([-1, 1], size=(50, n)).astype(float)
    expected = np.mean([ising_energy(J, h, offset, s) for s in samples])
    result = ising_evaluate_samples(J, h, offset, samples)
    assert abs(result - expected) < 1e-10


# ---------------------------------------------------------------------------
# qubo_to_ising: known 2-variable case
# ---------------------------------------------------------------------------

def test_qubo_to_ising_2var():
    # Q = [[0, 1], [1, 0]]  → single coupling between x0 and x1
    Q = np.array([[0.0, 1.0], [1.0, 0.0]])
    J, h, offset = qubo_to_ising(Q)
    # J[0,1] = Q[0,1]/2 = 0.5
    assert abs(J[0, 1] - 0.5) < 1e-12
    # h = Q.sum(axis=0)*0.5 = [0.5, 0.5]
    assert abs(h[0] - 0.5) < 1e-12
    assert abs(h[1] - 0.5) < 1e-12
    # offset = tr(Q)/2 + sum_triu/2 = 0 + 0.5 = 0.5
    assert abs(offset - 0.5) < 1e-12
