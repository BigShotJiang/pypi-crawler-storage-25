from abc import abstractmethod
import numpy as np
import random as rnd
from typing import Optional

from ..utils import (
    QAOACostFunction, QAOACircuit, pQAOACircuit, pQAOASingleParametersCircuit,
    SingleSliceQAOACircuit, BaseVQA,
)
from ..quantum_tools import AbstractQuantumObjects


class BaseQAOA(BaseVQA):

    @staticmethod
    def _validate_hp_1d(hyperparameters: Optional[np.ndarray], p: int) -> np.ndarray:
        if isinstance(hyperparameters, np.ndarray):
            if len(hyperparameters) != 2 * p:
                raise ValueError("hyperparameters length must be 2*p.")
            return hyperparameters
        elif hyperparameters is None:
            return np.array([rnd.uniform(0.0, 2 * np.pi) for _ in range(2 * p)])
        raise ValueError("hyperparameters must be a np.ndarray or None.")

    def __init__(
        self,
        Q: np.ndarray,
        offset: float = 0.0,
        p: int = 1,
        hyperparameters: Optional[np.ndarray] = None,
        qubit_order: Optional[np.ndarray] = None,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ):
        self.Q = Q
        self.offset = float(offset)
        self.p = p
        self.qubit_order = qubit_order
        self.quantum_objects = quantum_objects
        self.hyperparameters = self._validate_hp_1d(hyperparameters, p)
        self.optimizer = None
        self.circuit = None
        super().__init__()

    @abstractmethod
    def _set_objective_function(self):
        pass

    @abstractmethod
    def _set_circuit(self):
        pass

    @abstractmethod
    def get_circuit(self):
        pass

    def optimize(self, num_samples_training: int, num_iterations: int, **kwargs) -> dict:
        if not self.optimizer:
            raise ValueError("No optimizer set.")
        results = self.optimizer.optimize(
            num_samples_training=num_samples_training,
            num_iterations=num_iterations,
            **kwargs,
        )
        self.hyperparameters = results["x"]
        self.circuit.hyperparameters = results["x"]
        return results


class QAOA(BaseQAOA):
    """Vanilla QAOA."""

    def __init__(
        self,
        Q: np.ndarray,
        offset: float = 0.0,
        p: int = 1,
        hyperparameters: Optional[np.ndarray] = None,
        qubit_order: Optional[np.ndarray] = None,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ):
        super().__init__(Q, offset, p, hyperparameters, qubit_order, quantum_objects)

    def _set_circuit(self):
        if self.Q is not None:
            self.circuit = QAOACircuit(
                Q=self.Q, offset=self.offset, p=self.p,
                hyperparameters=self.hyperparameters, qubit_order=self.qubit_order,
                quantum_objects=self.quantum_objects,
            )
        else:
            self.circuit = QAOACircuit.from_ising(
                J=self._J_in, h=self._h_in, offset=self.offset,
                p=self.p, hyperparameters=self.hyperparameters, qubit_order=self.qubit_order,
                quantum_objects=self.quantum_objects,
            )

    def _set_objective_function(self):
        self.objective_function = QAOACostFunction(
            self.circuit._J, self.circuit._h, self.circuit._ising_offset
        )

    def get_circuit(self):
        return self.circuit.qasm

    @classmethod
    def from_ising(
        cls,
        J: np.ndarray,
        h: np.ndarray,
        offset: float = 0.0,
        p: int = 1,
        hyperparameters: Optional[np.ndarray] = None,
        qubit_order: Optional[np.ndarray] = None,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ) -> "QAOA":
        obj = cls.__new__(cls)
        obj._J_in = np.asarray(J, dtype=float)
        obj._h_in = np.asarray(h, dtype=float)
        BaseQAOA.__init__(obj, Q=None, offset=offset, p=p, hyperparameters=hyperparameters,
                          qubit_order=qubit_order, quantum_objects=quantum_objects)
        return obj


class pQAOA(BaseQAOA):
    """
    Parallel QAOA: each slice has its own hyperparameters.

    Parameters
    ----------
    Q            : full-model QUBO (n_full × n_full)
    slice_Qs     : list of per-slice QUBOs; full vars = concat of slice vars in order
    slice_offsets: per-slice QUBO offsets (default all 0)
    cartesian    : True  → Cartesian-product sample gluing  (default, pQAOA)
                   False → element-wise zip sample gluing   (ppQAOA)
    """

    @staticmethod
    def _validate_hp_2d(hyperparameters: Optional[np.ndarray], n_slices: int, p: int) -> np.ndarray:
        if isinstance(hyperparameters, np.ndarray):
            if hyperparameters.ndim == 2 and hyperparameters.shape == (n_slices, 2 * p):
                return hyperparameters
            raise ValueError(f"hyperparameters must have shape ({n_slices}, {2*p}) for pQAOA.")
        elif hyperparameters is None:
            return np.array([
                [rnd.uniform(0.0, 2 * np.pi) for _ in range(2 * p)]
                for _ in range(n_slices)
            ])
        raise ValueError("hyperparameters must be a np.ndarray or None.")


    def __init__(
        self,
        Q: np.ndarray,
        slice_Qs: list,
        offset: float = 0.0,
        slice_offsets: Optional[list] = None,
        p: int = 1,
        hyperparameters: Optional[np.ndarray] = None,
        qubit_orders: Optional[list] = None,
        cartesian: bool = False,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ):
        self.slice_Qs = slice_Qs
        self.slice_offsets = slice_offsets or [0.0] * len(slice_Qs)
        self.qubit_orders = qubit_orders
        self.Q = Q
        self.offset = float(offset)
        self.p = p
        self.qubit_order = None
        self.cartesian = cartesian
        self.quantum_objects = quantum_objects
        self.hyperparameters = self._validate_hp_2d(hyperparameters, len(slice_Qs), p)
        self.optimizer = None
        self.circuit = None

        from ..utils.vqa_utils import BaseVQA as _BaseVQA
        _BaseVQA.__init__(self)


    def _set_circuit(self):
        if self.Q is not None:
            self.circuit = pQAOACircuit(
                hyperparameters=self.hyperparameters, Q=self.Q,
                slice_Qs=self.slice_Qs, slice_offsets=self.slice_offsets,
                p=self.p, qubit_orders=self.qubit_orders, cartesian=self.cartesian,
                quantum_objects=self.quantum_objects,
            )
        else:
            self.circuit = pQAOACircuit.from_ising(
                J=self._J_in, h=self._h_in, offset=self.offset,
                slice_isings=self._slice_isings, hyperparameters=self.hyperparameters,
                p=self.p, qubit_orders=self.qubit_orders, cartesian=self.cartesian,
                quantum_objects=self.quantum_objects,
            )


    def _set_objective_function(self):
        self.objective_function = QAOACostFunction(
            self.circuit._J, self.circuit._h, self.circuit._ising_offset
        )
        

    @classmethod
    def from_ising(
        cls,
        J: np.ndarray,
        h: np.ndarray,
        offset: float = 0.0,
        slice_isings: list = None,
        p: int = 1,
        hyperparameters: Optional[np.ndarray] = None,
        qubit_orders: Optional[list] = None,
        cartesian: bool = False,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ) -> "pQAOA":
        """
        slice_isings : list of (J_k, h_k) or (J_k, h_k, offset_k) tuples, one per slice.
        """
        obj = cls.__new__(cls)
        obj._J_in = np.asarray(J, dtype=float)
        obj._h_in = np.asarray(h, dtype=float)
        obj._slice_isings = slice_isings or []
        n_slices = len(obj._slice_isings)
        obj.Q = None
        obj.slice_Qs = None
        obj.slice_offsets = None
        obj.qubit_orders = qubit_orders
        obj.offset = float(offset)
        obj.p = p
        obj.qubit_order = None
        obj.cartesian = cartesian
        obj.quantum_objects = quantum_objects
        obj.hyperparameters = cls._validate_hp_2d(hyperparameters, n_slices, p)
        obj.optimizer = None
        obj.circuit = None
        from ..utils.vqa_utils import BaseVQA as _BaseVQA
        _BaseVQA.__init__(obj)
        return obj


    def set_optimizer(self, optimizer, **kwargs):
        self.circuit._hyperparameters_optimizer_format()
        super().set_optimizer(optimizer, **kwargs)
        self.circuit._hyperparameters_slice_format()


    def optimize(self, num_samples_training: int, num_iterations: int, **kwargs) -> dict:
        if not self.optimizer:
            raise ValueError("No optimizer set.")
        self.circuit._hyperparameters_optimizer_format()
        results = self.optimizer.optimize(
            num_samples_training=num_samples_training,
            num_iterations=num_iterations,
            **kwargs,
        )
        self.circuit.hyperparameters = results["x"]
        self.circuit._hyperparameters_slice_format()
        self.hyperparameters = self.circuit.hyperparameters
        return results


    def get_circuit(self) -> list:
        return [s.qasm for s in self.circuit.qaoa_slices]


class pQAOASingleParameters(pQAOA):
    """
    pQAOA where all slices share the same 2p hyperparameters.

    Parameters
    ----------
    cartesian : True  → Cartesian-product gluing (default)
                False → element-wise zip gluing
    """

    def __init__(
        self,
        Q: np.ndarray,
        slice_Qs: list,
        offset: float = 0.0,
        slice_offsets: Optional[list] = None,
        p: int = 1,
        hyperparameters: Optional[np.ndarray] = None,
        qubit_orders: Optional[list] = None,
        cartesian: bool = False,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ):
        self.slice_Qs = slice_Qs
        self.slice_offsets = slice_offsets or [0.0] * len(slice_Qs)
        self.qubit_orders = qubit_orders
        self.Q = Q
        self.offset = float(offset)
        self.p = p
        self.qubit_order = None
        self.cartesian = cartesian
        self.quantum_objects = quantum_objects
        self.hyperparameters = self._validate_hp_1d(hyperparameters, p)
        self.optimizer = None
        self.circuit = None

        from ..utils.vqa_utils import BaseVQA as _BaseVQA
        _BaseVQA.__init__(self)

    def _set_circuit(self):
        if self.Q is not None:
            self.circuit = pQAOASingleParametersCircuit(
                hyperparameters=self.hyperparameters, Q=self.Q,
                slice_Qs=self.slice_Qs, slice_offsets=self.slice_offsets,
                p=self.p, qubit_orders=self.qubit_orders, cartesian=self.cartesian,
                quantum_objects=self.quantum_objects,
            )
        else:
            self.circuit = pQAOASingleParametersCircuit.from_ising(
                J=self._J_in, h=self._h_in, offset=self.offset,
                slice_isings=self._slice_isings, hyperparameters=self.hyperparameters,
                p=self.p, qubit_orders=self.qubit_orders, cartesian=self.cartesian,
                quantum_objects=self.quantum_objects,
            )

    @classmethod
    def from_ising(
        cls,
        J: np.ndarray,
        h: np.ndarray,
        offset: float = 0.0,
        slice_isings: list = None,
        p: int = 1,
        hyperparameters: Optional[np.ndarray] = None,
        qubit_orders: Optional[list] = None,
        cartesian: bool = False,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ) -> "pQAOASingleParameters":
        """
        slice_isings : list of (J_k, h_k) or (J_k, h_k, offset_k) tuples, one per slice.
        """
        obj = cls.__new__(cls)
        obj._J_in = np.asarray(J, dtype=float)
        obj._h_in = np.asarray(h, dtype=float)
        obj._slice_isings = slice_isings or []
        obj.Q = None
        obj.slice_Qs = None
        obj.slice_offsets = None
        obj.qubit_orders = qubit_orders
        obj.offset = float(offset)
        obj.p = p
        obj.qubit_order = None
        obj.cartesian = cartesian
        obj.quantum_objects = quantum_objects
        obj.hyperparameters = cls._validate_hp_1d(hyperparameters, p)
        obj.optimizer = None
        obj.circuit = None
        from ..utils.vqa_utils import BaseVQA as _BaseVQA
        _BaseVQA.__init__(obj)
        return obj


class SingleSliceQAOA(BaseQAOA):
    """
    One circuit used to sample all slices; variable remapping applied per slice.

    Parameters
    ----------
    Q         : full model QUBO
    slice_Q   : slice QUBO (n_slice × n_slice)
    var_map   : int array (n_slice, num_slices); var_map[i,k] = full-model column for slice var i in copy k
    """

    def __init__(
        self,
        Q: np.ndarray,
        slice_Q: np.ndarray,
        var_map: np.ndarray,
        offset: float = 0.0,
        slice_offset: float = 0.0,
        p: int = 1,
        hyperparameters: Optional[np.ndarray] = None,
        qubit_order: Optional[np.ndarray] = None,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ):
        self.slice_Q = slice_Q
        self.slice_offset = float(slice_offset)
        self.var_map = np.asarray(var_map, dtype=int)
        super().__init__(Q, offset, p, hyperparameters, qubit_order, quantum_objects)


    def _set_circuit(self):
        if self.Q is not None:
            self.circuit = SingleSliceQAOACircuit(
                Q=self.Q, slice_Q=self.slice_Q, slice_offset=self.slice_offset,
                var_map=self.var_map, p=self.p,
                hyperparameters=self.hyperparameters, qubit_order=self.qubit_order,
                quantum_objects=self.quantum_objects,
            )
        else:
            self.circuit = SingleSliceQAOACircuit.from_ising(
                J=self._J_in, h=self._h_in, offset=self.offset,
                slice_J=self._slice_J_in, slice_h=self._slice_h_in,
                slice_offset=self.slice_offset, var_map=self.var_map,
                p=self.p, hyperparameters=self.hyperparameters, qubit_order=self.qubit_order,
                quantum_objects=self.quantum_objects,
            )


    def _set_objective_function(self):
        self.objective_function = QAOACostFunction(
            self.circuit._J, self.circuit._h, self.circuit._ising_offset
        )


    def get_circuit(self):
        return self.circuit.qasm


    @classmethod
    def from_ising(
        cls,
        J: np.ndarray,
        h: np.ndarray,
        offset: float = 0.0,
        slice_J: np.ndarray = None,
        slice_h: np.ndarray = None,
        slice_offset: float = 0.0,
        var_map: np.ndarray = None,
        p: int = 1,
        hyperparameters: Optional[np.ndarray] = None,
        qubit_order: Optional[np.ndarray] = None,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ) -> "SingleSliceQAOA":
        obj = cls.__new__(cls)
        obj._J_in = np.asarray(J, dtype=float)
        obj._h_in = np.asarray(h, dtype=float)
        obj._slice_J_in = np.asarray(slice_J, dtype=float)
        obj._slice_h_in = np.asarray(slice_h, dtype=float)
        obj.slice_Q = None
        obj.slice_offset = float(slice_offset)
        obj.var_map = np.asarray(var_map, dtype=int) if var_map is not None else None
        BaseQAOA.__init__(obj, Q=None, offset=offset, p=p, hyperparameters=hyperparameters,
                          qubit_order=qubit_order, quantum_objects=quantum_objects)
        return obj
