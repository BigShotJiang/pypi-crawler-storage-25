import numpy as np
from .abstract_quantum_objects import AbstractQuantumObjects

from cirq import NamedQubit, Circuit
from cirq import H, X, Y, Z, CNOT
from cirq import rx, ry, rz
from cirq import measure, Simulator


class CirqQuantumObjects(AbstractQuantumObjects):

    @staticmethod
    def qubit(index, **kwargs):
        return NamedQubit(str(index), **kwargs)
    

    @staticmethod
    def circuit(*args):
        return Circuit()
    

    @staticmethod
    def append(circuit: Circuit, operation):
        return circuit.append(operation)
    

    @staticmethod
    def sample(
        circuit: Circuit,
        qubit_name_to_object: dict,
        num_samples: int,
        **kwargs,
    ) -> np.ndarray:
        """
        Sample from the circuit.

        Parameters
        ----------
        qubit_name_to_object : dict {int_index: NamedQubit}
        num_samples          : number of shots

        Returns
        -------
        np.ndarray (num_samples, n) with values in {-1, +1}
        """
        qc = circuit.copy()
        n = len(qubit_name_to_object)

        # Add measurements keyed by integer index (str representation)
        for idx, qubit in qubit_name_to_object.items():
            qc.append(measure(qubit, key=str(idx)))

        param_resolver = kwargs.pop("param_resolver", None)

        result = Simulator().run(program=qc, repetitions=num_samples, param_resolver=param_resolver)

        # Build (num_samples, n) array in index order
        cols = [str(i) for i in range(n)]
        raw = result.data[cols].values  # shape (num_samples, n), values in {0, 1}
        return np.where(raw == 1, 1, -1).astype(np.int8)
    

    @staticmethod
    def H(qubit):
        return H(qubit)
    

    @staticmethod
    def X(qubit):
        return X(qubit)
    

    @staticmethod
    def Y(qubit):
        return Y(qubit)
    

    @staticmethod
    def Z(qubit):
        return Z(qubit)
    

    @staticmethod
    def CNOT(qubit1, qubit2):
        return CNOT(qubit1, qubit2)
    

    @staticmethod
    def rx(qubit, angle):
        return rx(angle)(qubit)
    

    @staticmethod
    def ry(qubit, angle):
        return ry(angle)(qubit)
    

    @staticmethod
    def rz(qubit, angle):
        return rz(angle)(qubit)
