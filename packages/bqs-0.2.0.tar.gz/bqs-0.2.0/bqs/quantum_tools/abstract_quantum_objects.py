from abc import abstractmethod
import numpy as np


class AbstractQuantumObjects:

    @abstractmethod
    def qubit(index, **kwargs):
        pass

    @abstractmethod
    def circuit(*args):
        pass

    @abstractmethod
    def append(circuit, operation):
        pass

    @abstractmethod
    def sample(
        circuit,
        qubit_name_to_object: dict,
        num_samples: int,
        **kwargs,
    ) -> np.ndarray:
        """
        Sample from the circuit.

        Parameters
        ----------
        circuit              : backend circuit object
        qubit_name_to_object : dict mapping integer variable index -> qubit object
        num_samples          : number of shots

        Returns
        -------
        np.ndarray of shape (num_samples, n) with values in {-1, +1}
        """
        pass

    @abstractmethod
    def H(qubit):
        pass

    @abstractmethod
    def X(qubit):
        pass

    @abstractmethod
    def Y(qubit):
        pass

    @abstractmethod
    def Z(qubit):
        pass

    @abstractmethod
    def CNOT(qubit1, qubit2):
        pass

    @abstractmethod
    def rx(qubit, angle):
        pass

    @abstractmethod
    def ry(qubit, angle):
        pass

    @abstractmethod
    def rz(qubit, angle):
        pass
