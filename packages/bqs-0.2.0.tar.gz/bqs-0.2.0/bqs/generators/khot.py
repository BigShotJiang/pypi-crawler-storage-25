import numpy as np


def _qubo_k_hot(Q: np.ndarray, var_indices, k: int = 1, scale: float = 1.0) -> float:
    """
    Add a k-hot (k-of-n) constraint to Q **in-place**.
    Returns the offset contribution k^2 * scale.
    """
    idx = np.asarray(var_indices, dtype=int)
    Q[np.ix_(idx, idx)] += scale
    Q[idx, idx] -= 2 * k * scale
    return float(k ** 2 * scale)


def k_hot(Q: np.ndarray, offset: float, var_indices, k: int = 1, scale: float = 1.0) -> float:
    """
    Apply a k-hot constraint to Q **in-place** and return the updated offset.

    Parameters
    ----------
    Q           : symmetric (n,n) QUBO matrix, modified in place
    offset      : current scalar offset
    var_indices : integer indices of the variables to constrain
    k           : number of variables that must be 1
    scale       : penalty strength

    Returns
    -------
    new_offset : float
    """
    if k >= len(var_indices):
        raise ValueError(
            f"k ({k}) must be less than the number of constrained variables ({len(var_indices)})."
        )
    return offset + _qubo_k_hot(Q, var_indices, k=k, scale=scale)
