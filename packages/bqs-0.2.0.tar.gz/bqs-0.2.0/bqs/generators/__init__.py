from .khot import k_hot
from .qubos import (
    qubo_fix_variables,
    traveling_salesperson_problem,
    visualize_tsp,
    vrp_slice,
    vehicle_routing_problem,
    multi_car_paint_shop_problem,
    psp_slice,
    multi_color_paint_shop_problem,
    split_multi_color_psp,
    visualize_paint_shop,
)
