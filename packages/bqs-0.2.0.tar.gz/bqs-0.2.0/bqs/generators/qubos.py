import random as rnd
import numpy as np
from itertools import combinations, chain
import matplotlib.pyplot as plt
import networkx as nx

from ..utils.bqm import qubo_to_ising
from .khot import _qubo_k_hot

# ---------------------------------------------------------------------------
# Internal builder helpers
# ---------------------------------------------------------------------------

def qubo_fix_variables(Q: np.ndarray, offset: float, var_to_idx: dict, vars_to_fix: dict):
    """
    Fix a set of QUBO variables to given values.

    Parameters
    ----------
    Q           : symmetric (n,n) QUBO matrix (not modified)
    offset      : current offset
    var_to_idx  : mapping variable_name -> column index in Q
    vars_to_fix : mapping variable_name -> value in {0,1}

    Returns
    -------
    Q_new     : reduced (n_free, n_free) QUBO matrix
    new_offset: updated offset
    free_vars : list of variable names remaining
    """
    n = len(Q)
    fixed_names = list(vars_to_fix.keys())
    fixed_idx = np.array([var_to_idx[v] for v in fixed_names], dtype=int)
    fixed_vals = np.array([vars_to_fix[v] for v in fixed_names], dtype=float)

    free_mask = np.ones(n, dtype=bool)
    free_mask[fixed_idx] = False
    free_idx = np.where(free_mask)[0]

    Q_free = Q[np.ix_(free_idx, free_idx)].copy()

    # Linear adjustment from fixed×free cross-terms
    linear_adj = 2.0 * (Q[np.ix_(free_idx, fixed_idx)] @ fixed_vals)
    Q_free[np.arange(len(free_idx)), np.arange(len(free_idx))] += linear_adj

    # Offset contribution from all fixed-variable terms
    Q_ff = Q[np.ix_(fixed_idx, fixed_idx)]
    new_offset = float(offset) + float(fixed_vals @ Q_ff @ fixed_vals)

    all_vars = [None] * n
    for name, i in var_to_idx.items():
        all_vars[i] = name
    free_vars = [all_vars[i] for i in free_idx]
    return Q_free, new_offset, free_vars


def _new_builder(vars_list):
    """Return (Q, offset, var_to_idx) for a pre-defined list of variables."""
    var_to_idx = {v: i for i, v in enumerate(vars_list)}
    Q = np.zeros((len(vars_list), len(vars_list)))
    return Q, 0.0, var_to_idx


def _add_quad(Q, var_to_idx, v1, v2, value):
    i, j = var_to_idx[v1], var_to_idx[v2]
    if i == j:
        Q[i, i] += value
    else:
        Q[i, j] += value / 2.0
        Q[j, i] += value / 2.0


def _add_lin(Q, var_to_idx, v, value):
    Q[var_to_idx[v], var_to_idx[v]] += value


def _scale(Q, factor):
    Q *= factor


def _to_ising(Q, offset, var_to_idx):
    var_names = [None] * len(var_to_idx)
    for name, i in var_to_idx.items():
        var_names[i] = name
    J, h, new_offset = qubo_to_ising(Q, offset)
    return J, h, new_offset, var_names

# ---------------------------------------------------------------------------
# Traveling Salesperson Problem
# ---------------------------------------------------------------------------

def traveling_salesperson_problem(distance_matrix, locations, starting_point=None, eps=1.0):
    """
    Build the TSP QUBO and return the reduced Ising model (starting point fixed).

    Parameters
    ----------
    distance_matrix : 2-D array-like, distance_matrix[i][j] = dist(locations[i], locations[j])
    locations       : list of location labels
    starting_point  : location fixed at position 0 (random if None)
    eps             : small positive regulariser for the objective scaling

    Returns
    -------
    J, h, offset, var_names  — Ising form with starting-point variables fixed
    """
    if starting_point is None:
        starting_point = rnd.choice(locations)

    loc_ind = {loc: i for i, loc in enumerate(locations)}
    n_loc = len(locations)

    all_vars = [(loc, pos) for loc in locations for pos in range(n_loc)]
    Q, offset, var_to_idx = _new_builder(all_vars)

    # Objective: distance between successive positions
    for loc1, loc2 in combinations(locations, 2):
        d = distance_matrix[loc_ind[loc1]][loc_ind[loc2]]
        for pos in range(n_loc):
            _add_quad(Q, var_to_idx, (loc1, pos), (loc2, (pos + 1) % n_loc), d)
            _add_quad(Q, var_to_idx, (loc2, pos), (loc1, (pos + 1) % n_loc), d)

    # Scale objective
    max_quad = float(np.triu(Q, k=1).max())
    if max_quad > 0:
        _scale(Q, 1.0 / (max_quad + eps))

    # 1-hot per position (each position has exactly one location)
    for pos in range(n_loc):
        idx = [var_to_idx[(loc, pos)] for loc in locations]
        offset += _qubo_k_hot(Q, idx, k=1)

    # 1-hot per location (each location appears exactly once)
    for loc in locations:
        idx = [var_to_idx[(loc, pos)] for pos in range(n_loc)]
        offset += _qubo_k_hot(Q, idx, k=1)

    # Fix starting point at position 0
    vars_to_fix = {(loc, 0): (1 if loc == starting_point else 0) for loc in locations}
    Q, offset, free_vars = qubo_fix_variables(Q, offset, var_to_idx, vars_to_fix)
    var_to_idx = {v: i for i, v in enumerate(free_vars)}

    J, h, offset, var_names = _to_ising(Q, offset, var_to_idx)
    return J, h, offset, var_names


def visualize_tsp(locations, starting_point, var_names, sol_array=None):
    """
    Visualize a TSP solution.

    Parameters
    ----------
    locations      : list of location labels
    starting_point : the fixed starting location
    var_names      : list of (loc, pos) tuples (from the generator)
    sol_array      : numpy array of {0,1} values aligned with var_names, or None
    """
    x_width, y_width = 0.3, 0.1

    # Reconstruct full solution (including fixed starting-point variables)
    sol = {}
    if sol_array is not None:
        sol = dict(zip(var_names, sol_array))
    for loc in locations:
        sol.setdefault((loc, 0), 1 if loc == starting_point else 0)

    on_nodes = [n for n, v in sol.items() if v == 1] if sol_array is not None else []
    counting_locations = {loc: k for k, loc in enumerate(locations)}

    g = nx.DiGraph()
    pos, labels = {}, {}
    n_loc = len(locations)

    for loc in locations:
        for p in range(n_loc):
            var = (loc, p)
            x = counting_locations[loc] * x_width
            y = p * y_width
            pos[var] = (x, y)
            labels[var] = loc
            g.add_node(var)

    if sol_array is not None:
        for var1, var2 in combinations(sol.keys(), 2):
            loc1, pos1 = var1
            loc2, pos2 = var2
            if sol.get(var1) == 1 and sol.get(var2) == 1:
                if pos2 - pos1 == 1:
                    g.add_edge(var1, var2)
                elif pos2 - pos1 == -1:
                    g.add_edge(var2, var1)

    nx.draw(nx.Graph())
    nx.draw_networkx_nodes(g, pos, nodelist=g.nodes, node_color='white', edgecolors='black')
    nx.draw_networkx_nodes(g, pos, nodelist=on_nodes, node_color='gray', edgecolors='black')
    nx.draw_networkx_edges(g, pos, edgelist=g.edges(), arrowsize=15, arrowstyle='-|>')
    nx.draw_networkx_labels(g, pos, labels=labels)
    plt.show()

# ---------------------------------------------------------------------------
# Vehicle Routing Problem
# ---------------------------------------------------------------------------

def vrp_slice(distance_matrix, locations, depot, vehicle_id=None, eps=1.0):
    J, h, offset, var_names = traveling_salesperson_problem(
        distance_matrix, locations, starting_point=depot, eps=eps
    )
    if vehicle_id is not None:
        var_names = [(vehicle_id, loc, pos) for loc, pos in var_names]
    return J, h, offset, var_names


def vehicle_routing_problem(distance_matrix, locations, number_of_vehicles, depot):
    """
    Build the full VRP QUBO (all vehicles combined with depot constraints).

    Returns
    -------
    J, h, offset, var_names  — Ising
    slice_isings             — list of (J_k, h_k, offset_k, var_names_k) per vehicle
    """
    loc_ind = {loc: i for i, loc in enumerate(locations)}
    n_loc = len(locations)
    n_vehicles = number_of_vehicles

    # Build per-vehicle slices (full, before depot fixing)
    all_vars = [
        (k, loc, pos)
        for k in range(n_vehicles)
        for loc in locations
        for pos in range(n_loc)
    ]
    Q, offset, var_to_idx = _new_builder(all_vars)

    for k in range(n_vehicles):
        for loc1, loc2 in combinations(locations, 2):
            d = distance_matrix[loc_ind[loc1]][loc_ind[loc2]]
            for pos in range(n_loc):
                _add_quad(Q, var_to_idx, (k, loc1, pos), (k, loc2, (pos + 1) % n_loc), d)
                _add_quad(Q, var_to_idx, (k, loc2, pos), (k, loc1, (pos + 1) % n_loc), d)

        max_quad = float(max(
            abs(Q[var_to_idx[(k, loc1, pos)], var_to_idx[(k, loc2, (pos + 1) % n_loc)]])
            for loc1, loc2 in combinations(locations, 2)
            for pos in range(n_loc)
        ) or 1.0)
        scale_k = 1.0 / (2.0 * max_quad + 1.0)
        for loc1, loc2 in combinations(locations, 2):
            for pos in range(n_loc):
                for v1, v2 in [
                    ((k, loc1, pos), (k, loc2, (pos + 1) % n_loc)),
                    ((k, loc2, pos), (k, loc1, (pos + 1) % n_loc)),
                ]:
                    i, j = var_to_idx[v1], var_to_idx[v2]
                    Q[i, j] *= scale_k
                    Q[j, i] *= scale_k

    # 1-hot per (vehicle, step)
    for k in range(n_vehicles):
        for step in range(n_loc):
            idx = [var_to_idx[(k, loc, step)] for loc in locations]
            offset += _qubo_k_hot(Q, idx, k=1)

    # Each non-depot location is visited by exactly one vehicle
    for loc in locations:
        if loc != depot:
            idx = [
                var_to_idx[(k, loc, step)]
                for k in range(n_vehicles)
                for step in range(n_loc)
            ]
            offset += _qubo_k_hot(Q, idx, k=1)

    # Fix depot variables
    vars_to_fix = {
        (k, loc, 0): (1 if loc == depot else 0)
        for k in range(n_vehicles)
        for loc in locations
    }
    Q, offset, free_vars = qubo_fix_variables(Q, offset, var_to_idx, vars_to_fix)
    var_to_idx = {v: i for i, v in enumerate(free_vars)}

    J, h, offset, var_names = _to_ising(Q, offset, var_to_idx)

    # Build per-vehicle slice Ising models
    slice_isings = [
        vrp_slice(distance_matrix, locations, depot, vehicle_id=k)
        for k in range(n_vehicles)
    ]

    return (J, h, offset, var_names), slice_isings

# ---------------------------------------------------------------------------
# Multi-car Paint Shop Problem
# ---------------------------------------------------------------------------

def multi_car_paint_shop_problem(seq_of_cars, groups_of_cars: list, black_cars: list):
    """
    Multi-car binary paint shop problem (SPIN variables: +1=black, -1=white).

    Returns
    -------
    J, h, offset, var_names  — Ising, variables are car labels from seq_of_cars
    fixed_variables          — dict {car: value} for cars whose colour was determined by constraints
    """
    assert len(groups_of_cars) == len(black_cars)

    # All cars appear exactly once as variables, but some may be fixed
    all_vars = list(dict.fromkeys(seq_of_cars))  # unique, preserving order
    var_to_idx = {v: i for i, v in enumerate(all_vars)}
    n = len(all_vars)
    Q_spin = np.zeros((n, n))  # will be used as Ising J/h directly
    offset = 0.0
    fixed_variables = {}

    # Objective: minimize colour switches (spin model: -1 per adjacent same-colour pair)
    for car1, car2 in zip(seq_of_cars, seq_of_cars[1:]):
        i, j = var_to_idx[car1], var_to_idx[car2]
        # energy contribution: -s_i * s_j  (reward same colour)
        # In Ising J form: J[i,j] = -1/n_seq  (upper triangular)
        if i < j:
            Q_spin[i, j] -= 1.0
        else:
            Q_spin[j, i] -= 1.0

    scale_factor = 1.0 / len(seq_of_cars)
    Q_spin *= scale_factor

    # Constraints: k-hot in spin basis
    # For SPIN variables: k-hot means sum of s_i = 2k - len(group)
    # Penalty: scale * (sum(s_i) - (2k - len(group)))^2
    # In terms of the quadratic model: add all pairs with coefficient 2*scale,
    # add linear terms with (2k - len(group) - 1) ... actually in SPIN:
    # (sum s_i - target)^2 = sum s_i^2 + 2*sum_{i<j} s_i s_j - 2*target*sum s_i + target^2
    # s_i^2 = 1 always, so constant = n_group
    # => penalty = 2*sum_{i<j} s_i s_j - 2*target*sum s_i + constant

    vars_to_fix_dict = {}

    for group, num_black in zip(groups_of_cars, black_cars):
        if num_black == 0:
            for var in group:
                vars_to_fix_dict[var] = -1
                fixed_variables[var] = -1
        elif num_black == len(group):
            for var in group:
                vars_to_fix_dict[var] = 1
                fixed_variables[var] = 1
        else:
            # Spin k-hot: num_black out of len(group) are +1
            # target = num_black - (len(group) - num_black) = 2*num_black - len(group)
            target = 2 * num_black - len(group)
            idx = [var_to_idx[v] for v in group if v in var_to_idx]
            for a, b in combinations(idx, 2):
                ia, ib = min(a, b), max(a, b)
                Q_spin[ia, ib] += 2.0
            for i in idx:
                Q_spin[i, i] -= 2.0 * target  # linear in spin
            offset += float(target ** 2 + len(group))  # constant term

    # Fix determined variables
    # For SPIN fixing we work directly on Q_spin as J/h representation
    # J is upper-triangular part, h is diagonal
    # Fix spin variable k = vk:
    # contribution to remaining: 2*vk * J[k, free] added to h[free]
    #                            vk * h[k] added to offset  (since s_k^2=1 not vk^2)
    # Actually for Ising: E = sum_{i<j} J[i,j] s_i s_j + sum_i h[i] s_i
    # Fixing s_k = vk: contribution J[k,j]*vk to h[j] for j>k,
    #                               J[i,k]*vk to h[i] for i<k,
    #                               h[k]*vk to offset

    if vars_to_fix_dict:
        # Convert to QUBO, fix, convert back
        # But this is SPIN — let's work in Ising directly
        h_vec = Q_spin.diagonal().copy()
        np.fill_diagonal(Q_spin, 0)
        J_mat = np.triu(Q_spin, k=1)

        fixed_names = list(vars_to_fix_dict.keys())
        fixed_vals = np.array([vars_to_fix_dict[v] for v in fixed_names], dtype=float)
        fixed_idx = np.array([var_to_idx[v] for v in fixed_names], dtype=int)
        free_mask = np.ones(n, dtype=bool)
        free_mask[fixed_idx] = False
        free_idx = np.where(free_mask)[0]

        J_free = J_mat[np.ix_(free_idx, free_idx)].copy()
        h_free = h_vec[free_idx].copy()

        # Coupling from fixed to free variables
        for k_idx, vk in zip(fixed_idx, fixed_vals):
            for fi_pos, fi in enumerate(free_idx):
                i, j = min(k_idx, fi), max(k_idx, fi)
                h_free[fi_pos] += J_mat[i, j] * vk
            offset += h_vec[k_idx] * vk

        # Fixed-fixed coupling to offset
        for a, va in zip(fixed_idx, fixed_vals):
            for b, vb in zip(fixed_idx, fixed_vals):
                if a < b:
                    offset += J_mat[a, b] * va * vb

        free_vars = [all_vars[i] for i in free_idx]
        return J_free, h_free, offset, free_vars, fixed_variables

    h_vec = Q_spin.diagonal().copy()
    np.fill_diagonal(Q_spin, 0)
    J_mat = np.triu(Q_spin, k=1)
    return J_mat, h_vec, offset, all_vars, fixed_variables


def psp_slice(seq_of_cars, groups_of_cars: list, black_cars: list, color=None):
    """
    PSP slice for pQAOA decomposition.  If color is given, variables are labelled
    (car, color) instead of car.
    """
    J, h, offset, var_names, fixed_vars = multi_car_paint_shop_problem(
        seq_of_cars, groups_of_cars, black_cars
    )
    if color is not None:
        var_names = [(v, color) for v in var_names]
        fixed_vars = {(k, color): v for k, v in fixed_vars.items()}
    return J, h, offset, var_names, fixed_vars


def multi_color_paint_shop_problem(
    seq_of_cars,
    groups_of_cars: list,
    colored_cars: dict,
):
    """
    Multi-color multi-car paint shop problem.

    Parameters
    ----------
    seq_of_cars         : sequence of car labels
    groups_of_cars      : list of groups for k-hot constraints
    colored_cars        : dict {color_key: [num_black_per_group, ...]}
    white_filler_colors : set of color keys treated as white fillers (for _split)

    Returns
    -------
    J, h, offset, var_names  — combined Ising model
    fixed_variables          — dict of all variables determined by constraints
    """
    car_count = sum(chain.from_iterable(colored_cars.values()))
    if car_count != len(seq_of_cars):
        raise ValueError(
            "Number of cars to be colored must equal the number of cars in the sequence."
        )

    # Collect all variable names across colors
    all_var_names = []
    per_color_data = {}

    for color, black_cars_list in colored_cars.items():
        J_c, h_c, off_c, vnames_c, fixed_c = psp_slice(
            seq_of_cars, groups_of_cars, black_cars_list, color=color
        )
        per_color_data[color] = (J_c, h_c, off_c, vnames_c, fixed_c)
        for v in vnames_c:
            if v not in all_var_names:
                all_var_names.append(v)

    n_total = len(all_var_names)
    global_idx = {v: i for i, v in enumerate(all_var_names)}
    J_total = np.zeros((n_total, n_total))
    h_total = np.zeros(n_total)
    offset_total = 0.0
    all_fixed = {}

    for color, (J_c, h_c, off_c, vnames_c, fixed_c) in per_color_data.items():
        offset_total += off_c
        all_fixed.update(fixed_c)
        for local_i, vname in enumerate(vnames_c):
            gi = global_idx[vname]
            h_total[gi] += h_c[local_i]
            for local_j, vname2 in enumerate(vnames_c):
                if local_i < local_j:
                    gj = global_idx[vname2]
                    ii, jj = min(gi, gj), max(gi, gj)
                    J_total[ii, jj] += J_c[local_i, local_j]

    # 1-hot per car across colors (each car gets exactly one color)
    # Build QUBO for the 1-hot and add it to J/h via Ising directly
    for car in seq_of_cars:
        color_vars = [v for v in all_var_names if v[0] == car]
        if len(color_vars) < 2:
            continue
        idx = [global_idx[v] for v in color_vars]
        # Spin 1-hot: target = 2*1 - len(idx) = 2 - n_colors
        target = 2 - len(idx)
        for a, b in combinations(idx, 2):
            ia, ib = min(a, b), max(a, b)
            J_total[ia, ib] += 2.0
        for i in idx:
            h_total[i] -= 2.0 * target
        offset_total += float(target ** 2 + len(idx))

    return J_total, h_total, offset_total, all_var_names, all_fixed


def split_multi_color_psp(
    J: np.ndarray,
    h: np.ndarray,
    offset: float,
    var_names: list,
    binary_sol: dict,
    white_filler_colors,
):
    """
    Decompose the multi-color PSP using a binary (multi-car) solution.
    Returns a list of (J_k, h_k, offset_k, var_names_k) sub-problems.
    """
    # White cars are fixed to -1 for non-filler colors
    white_cars = {car for car, val in binary_sol.items() if val == -1}

    vars_to_fix = {}
    for i, v in enumerate(var_names):
        car, color = v
        if car in white_cars and color not in white_filler_colors:
            vars_to_fix[v] = -1
        elif car not in white_cars and color in white_filler_colors:
            vars_to_fix[v] = -1

    # Fix variables in Ising form
    fixed_names = list(vars_to_fix.keys())
    fixed_vals = np.array([vars_to_fix[v] for v in fixed_names], dtype=float)
    var_to_idx = {v: i for i, v in enumerate(var_names)}
    fixed_idx = np.array([var_to_idx[v] for v in fixed_names], dtype=int)

    n = len(var_names)
    free_mask = np.ones(n, dtype=bool)
    free_mask[fixed_idx] = False
    free_idx = np.where(free_mask)[0]

    J_free = J[np.ix_(free_idx, free_idx)].copy()
    h_free = h[free_idx].copy()

    for k_pos, (k_idx, vk) in enumerate(zip(fixed_idx, fixed_vals)):
        for fi_pos, fi in enumerate(free_idx):
            i, j = min(k_idx, fi), max(k_idx, fi)
            h_free[fi_pos] += J[i, j] * vk
        offset += h[k_idx] * vk

    for a, va in zip(fixed_idx, fixed_vals):
        for b, vb in zip(fixed_idx, fixed_vals):
            if a < b:
                offset += J[a, b] * va * vb

    free_vars = [var_names[i] for i in free_idx]

    # Find connected components via adjacency of J_free
    n_free = len(free_idx)
    adj = nx.Graph()
    adj.add_nodes_from(range(n_free))
    rows, cols = np.where(J_free != 0)
    for r, c in zip(rows, cols):
        if r < c:
            adj.add_edge(r, c)
    # Also add isolated nodes with non-zero h
    for i in range(n_free):
        if h_free[i] != 0:
            adj.add_node(i)

    components = list(nx.connected_components(adj))
    sub_problems = []
    for comp in components:
        comp_idx = sorted(comp)
        comp_arr = np.array(comp_idx)
        J_c = J_free[np.ix_(comp_arr, comp_arr)]
        h_c = h_free[comp_arr]
        vnames_c = [free_vars[i] for i in comp_idx]
        sub_problems.append((J_c, h_c, 0.0, vnames_c))

    return sub_problems

# ---------------------------------------------------------------------------
# Visualization helpers
# ---------------------------------------------------------------------------

def visualize_paint_shop(seq_of_cars, groups_of_cars, var_names, sol_array=None, fixed_variables=None):
    """Visualize a binary (multi-car) paint shop solution."""
    rad = {car: 0.3 * (-1) ** num for num, car in enumerate(seq_of_cars)}
    line = nx.Graph()
    line.add_edges_from(zip(seq_of_cars, seq_of_cars[1:]))
    for group in groups_of_cars:
        for i, j in combinations(group, 2):
            line.add_edge(i, j)

    pos = {node: (num, 0) for num, node in enumerate(seq_of_cars)}

    sol = {}
    if sol_array is not None and var_names is not None:
        sol = dict(zip(var_names, sol_array))
    if fixed_variables:
        sol.update(fixed_variables)

    black_nodes = [node for node, value in sol.items() if value == 1]

    ax = plt.gca()
    nx.draw(nx.Graph())
    for edge in line.edges:
        style = "arc3, rad=0.3" if edge not in list(zip(seq_of_cars, seq_of_cars[1:])) else "arc3"
        ax.annotate("", xy=pos[edge[0]], xytext=pos[edge[1]],
                    arrowprops=dict(arrowstyle='-', color='black',
                                    connectionstyle=style, shrinkA=14, shrinkB=14))
    nx.draw_networkx_nodes(line, pos, nodelist=line.nodes, node_color='white', edgecolors='black', node_size=700)
    if black_nodes:
        nx.draw_networkx_nodes(line, pos, nodelist=black_nodes, node_color='black', node_size=700)
    plt.show()
