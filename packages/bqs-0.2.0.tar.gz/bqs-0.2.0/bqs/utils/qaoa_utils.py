import numpy as np
from typing import Optional
from concurrent.futures import ProcessPoolExecutor
from os import cpu_count

from .bqm import qubo_to_ising, ising_evaluate_samples
from .vqa_utils import VariationalCircuit, CostFunction
from ..quantum_tools import CirqQuantumObjects, AbstractQuantumObjects


########################################################################################################################
# QAOA circuit classes
########################################################################################################################

class QAOACircuit(VariationalCircuit):
    """
    Vanilla QAOA circuit.  Accepts a symmetric QUBO matrix Q and converts to Ising internally.
    """

    def __init__(
        self,
        Q: np.ndarray,
        offset: float = 0.0,
        p: int = 1,
        hyperparameters: Optional[np.ndarray] = None,
        qubit_order: Optional[np.ndarray] = None,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ):
        self.Q = Q
        self.offset = float(offset)
        J, h, ising_offset = qubo_to_ising(Q, offset)
        self._setup(J, h, ising_offset, p, hyperparameters, qubit_order,
                    quantum_objects or CirqQuantumObjects())


    def _setup(
        self,
        J: np.ndarray,
        h: np.ndarray,
        ising_offset: float,
        p: int,
        hyperparameters: Optional[np.ndarray],
        qubit_order: Optional[np.ndarray],
        qo: AbstractQuantumObjects,
    ):
        n = len(h)
        self.p = p
        self.n = n
        self._J = J
        self._h = h
        self._ising_offset = float(ising_offset)
        self._qo = qo
        if qubit_order is None:
            qubit_order = np.arange(n)
        self.qubit_order = qubit_order
        self._qubits = [qo.qubit(int(qubit_order[i])) for i in range(n)]
        qubit_name_to_object = {i: self._qubits[i] for i in range(n)}
        VariationalCircuit.__init__(
            self,
            hyperparameters=hyperparameters if hyperparameters is not None
                            else np.random.uniform(0.0, 2 * np.pi, 2 * p),
            qubit_name_to_object=qubit_name_to_object,
        )


    @classmethod
    def from_ising(
        cls,
        J: np.ndarray,
        h: np.ndarray,
        offset: float = 0.0,
        p: int = 1,
        hyperparameters: Optional[np.ndarray] = None,
        qubit_order: Optional[np.ndarray] = None,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ) -> "QAOACircuit":
        obj = object.__new__(cls)
        obj.Q = None
        obj.offset = float(offset)
        obj._setup(np.asarray(J, dtype=float), np.asarray(h, dtype=float),
                   float(offset), p, hyperparameters, qubit_order,
                   quantum_objects or CirqQuantumObjects())
        return obj
    

    def _append_zz_term(self, qc, qubits, i: int, j: int, gamma: float, J_ij: float):
        self._qo.append(qc, self._qo.CNOT(qubits[i], qubits[j]))
        self._qo.append(qc, self._qo.rz(qubits[j], gamma * J_ij))
        self._qo.append(qc, self._qo.CNOT(qubits[i], qubits[j]))


    def _append_z_term(self, qc, qubits, i: int, gamma: float, h_i: float):
        self._qo.append(qc, self._qo.rz(qubits[i], gamma * h_i))


    def _append_x_term(self, qc, qubits, i: int, beta: float):
        self._qo.append(qc, self._qo.rx(qubits[i], beta))


    def _get_cost_operator_circuit(self, qc, qubits, h: np.ndarray, J: np.ndarray, gamma: float):
        for i in np.nonzero(h)[0]:
            self._append_z_term(qc, qubits, int(i), gamma, float(h[i]))
        rows, cols = np.nonzero(np.triu(J, k=1))
        for i, j in zip(rows, cols):
            self._append_zz_term(qc, qubits, int(i), int(j), gamma, float(J[i, j]))


    def _get_mixer_operator_circuit(self, qc, qubits, n: int, beta: float):
        for i in range(n):
            self._append_x_term(qc, qubits, i, beta)
    

    def _get_qaoa_circuit(self, qubits: list, h: np.ndarray, J: np.ndarray,
                     beta_list: np.ndarray, gamma_list: np.ndarray):
        assert len(beta_list) == len(gamma_list)
        p = len(beta_list)
        n = len(h)

        qc = self._qo.circuit(n)
        for q in qubits:
            self._qo.append(qc, self._qo.H(q))

        for layer in range(p):
            self._get_cost_operator_circuit(qc, qubits, h, J, float(gamma_list[layer]))
            self._get_mixer_operator_circuit(qc, qubits, n, float(beta_list[layer]))

        return qc
    

    def get_circuit_from_hyperparameters(self, hyperparameters: Optional[np.ndarray] = None):
        if isinstance(hyperparameters, np.ndarray):
            self.hyperparameters = hyperparameters

        qc = self._get_qaoa_circuit(
            self._qubits,
            self._h,
            self._J,
            self.hyperparameters[: self.p],   # beta
            self.hyperparameters[self.p :],    # gamma
        )
        self.qasm = qc
        return qc


    def sample(
        self,
        num_samples: int = 100,
        hyperparameters: Optional[np.ndarray] = None,
        original_basis: bool = False,
        **kwargs,
    ) -> np.ndarray:
        """
        Returns np.ndarray of shape (num_samples, n) with ±1 spin values (or {0,1} binary
        when original_basis=True).
        """
        qc = self.get_circuit_from_hyperparameters(
            hyperparameters if isinstance(hyperparameters, np.ndarray) else self.hyperparameters
        )
        samples = self._qo.sample(
            circuit=qc,
            qubit_name_to_object=self.qubit_name_to_object,
            num_samples=num_samples,
            **kwargs,
        )
        return (samples + 1) // 2 if original_basis else samples


class pQAOACircuit(VariationalCircuit):
    """
    Parallel QAOA: independent QAOACircuits for each slice.

    Parameters
    ----------
    cartesian : bool
        True  → Cartesian-product gluing (pQAOA semantics)
        False → element-wise zip gluing  (ppQAOA semantics)
    """

    def __init__(
        self,
        hyperparameters: np.ndarray,
        Q: np.ndarray,
        slice_Qs: list,
        slice_offsets: Optional[list] = None,
        p: int = 1,
        qubit_orders: Optional[list] = None,
        cartesian: bool = False,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ):
        qo = quantum_objects or CirqQuantumObjects()
        self.Q = Q
        self._J, self._h, self._ising_offset = qubo_to_ising(Q)
        self.p = p
        self.cartesian = cartesian
        n_slices = len(slice_Qs)

        if slice_offsets is None:
            slice_offsets = [0.0] * n_slices
        if qubit_orders is None:
            qubit_orders = [None] * n_slices

        self.qaoa_slices = [
            QAOACircuit(
                Q=slice_Qs[k],
                offset=slice_offsets[k],
                p=p,
                hyperparameters=hyperparameters[k],
                qubit_order=qubit_orders[k],
                quantum_objects=qo,
            )
            for k in range(n_slices)
        ]
        self._optimizer_format = False

        super().__init__(hyperparameters=hyperparameters)


    def get_circuit_from_hyperparameters(self, hyperparameters: Optional[np.ndarray] = None):
        if isinstance(hyperparameters, np.ndarray) and len(hyperparameters) == len(self.qaoa_slices):
            self.hyperparameters = hyperparameters

        slice_hp = (
            self._format_slice(self.hyperparameters, self.p, len(self.qaoa_slices))
            if self._optimizer_format
            else self.hyperparameters
        )
        qasms = [
            s.get_circuit_from_hyperparameters(slice_hp[i])
            for i, s in enumerate(self.qaoa_slices)
        ]
        self.qasm = qasms
        return qasms


    @staticmethod
    def _parallel_sample(qaoa_slice, num_samples, hyperparameters, kwargs):
        return qaoa_slice.sample(num_samples=num_samples, hyperparameters=hyperparameters, **kwargs)


    def sample(
        self,
        num_samples: int = 100,
        hyperparameters: Optional[np.ndarray] = None,
        original_basis: bool = False,
        **kwargs,
    ) -> np.ndarray:
        parallel = kwargs.pop("parallel", False)

        hp = (
            self._format_slice(
                hyperparameters if isinstance(hyperparameters, np.ndarray) else self.hyperparameters,
                self.p,
                len(self.qaoa_slices),
            )
            if self._optimizer_format
            else (hyperparameters if isinstance(hyperparameters, np.ndarray) else self.hyperparameters)
        )

        if parallel:
            with ProcessPoolExecutor(max_workers=cpu_count()) as executor:
                futures = [
                    executor.submit(self._parallel_sample, s, num_samples, hp[i], kwargs)
                    for i, s in enumerate(self.qaoa_slices)
                ]
            list_of_samples = [f.result() for f in futures]
        else:
            list_of_samples = [
                s.sample(hyperparameters=hp[i], num_samples=num_samples, **kwargs)
                for i, s in enumerate(self.qaoa_slices)
            ]

        samples = self._glue_slices(list_of_samples)
        return (samples + 1) // 2 if original_basis else samples


    def _glue_slices(self, list_of_samples: list) -> np.ndarray:
        if self.cartesian:
            result = list_of_samples[0]
            for s in list_of_samples[1:]:
                m1, m2 = result.shape[0], s.shape[0]
                d1, d2 = result.shape[1], s.shape[1]
                out = np.empty((m1 * m2, d1 + d2), dtype=result.dtype)
                out[:, :d1] = np.repeat(result, m2, axis=0)
                out[:, d1:] = np.tile(s, (m1, 1))
                result = out
            return result
        else:
            return np.hstack(list_of_samples)


    def _hyperparameters_optimizer_format(self):
        if (
            isinstance(self.hyperparameters, np.ndarray) and
            all(isinstance(r, np.ndarray) for r in self.hyperparameters) and
            len(self.hyperparameters) == len(self.qaoa_slices)
        ):
            self.hyperparameters = np.concatenate(list(self.hyperparameters))
            self._optimizer_format = True
        elif (
            isinstance(self.hyperparameters, np.ndarray) and
            len(self.hyperparameters) == 2 * self.p * len(self.qaoa_slices)
        ):
            pass
        else:
            raise ValueError("Wrong hyperparameters format")


    def _hyperparameters_slice_format(self):
        if (
            isinstance(self.hyperparameters, np.ndarray) and
            len(self.hyperparameters) == 2 * self.p * len(self.qaoa_slices)
        ):
            self.hyperparameters = self._format_slice(
                self.hyperparameters, self.p, len(self.qaoa_slices)
            )
            self._optimizer_format = False
        elif (
            isinstance(self.hyperparameters, np.ndarray) and
            all(isinstance(r, np.ndarray) for r in self.hyperparameters) and
            len(self.hyperparameters) == len(self.qaoa_slices)
        ):
            pass
        else:
            raise ValueError("Wrong hyperparameters format")


    @staticmethod
    def _format_slice(hyperparameters: np.ndarray, p: int, num_slices: int) -> np.ndarray:
        return np.array([hyperparameters[i * 2 * p : (i + 1) * 2 * p] for i in range(num_slices)])


    @classmethod
    def from_ising(
        cls,
        J: np.ndarray,
        h: np.ndarray,
        offset: float = 0.0,
        slice_isings: list = None,
        hyperparameters: np.ndarray = None,
        p: int = 1,
        qubit_orders: Optional[list] = None,
        cartesian: bool = False,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ) -> "pQAOACircuit":
        """
        slice_isings : list of (J_k, h_k) or (J_k, h_k, offset_k) tuples, one per slice.
        hyperparameters : (n_slices, 2*p) array.
        """
        qo = quantum_objects or CirqQuantumObjects()
        obj = object.__new__(cls)
        obj.Q = None
        obj._J = np.asarray(J, dtype=float)
        obj._h = np.asarray(h, dtype=float)
        obj._ising_offset = float(offset)
        obj.p = p
        obj.cartesian = cartesian
        n_slices = len(slice_isings)
        if qubit_orders is None:
            qubit_orders = [None] * n_slices
        obj.qaoa_slices = [
            QAOACircuit.from_ising(
                J=slice_isings[k][0],
                h=slice_isings[k][1],
                offset=float(slice_isings[k][2]) if len(slice_isings[k]) > 2 else 0.0,
                p=p,
                hyperparameters=hyperparameters[k],
                qubit_order=qubit_orders[k],
                quantum_objects=qo,
            )
            for k in range(n_slices)
        ]
        obj._optimizer_format = False
        VariationalCircuit.__init__(obj, hyperparameters=hyperparameters)
        return obj


class pQAOASingleParametersCircuit(pQAOACircuit):
    """
    pQAOA where all slices share a single set of hyperparameters.

    Parameters
    ----------
    cartesian : bool
        True  → Cartesian-product gluing (pQAOA semantics)
        False → element-wise zip gluing  (ppQAOA semantics)
    """

    def __init__(
        self,
        hyperparameters: np.ndarray,
        Q: np.ndarray,
        slice_Qs: list,
        slice_offsets: Optional[list] = None,
        p: int = 1,
        qubit_orders: Optional[list] = None,
        cartesian: bool = False,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ):
        qo = quantum_objects or CirqQuantumObjects()
        self.Q = Q
        self._J, self._h, self._ising_offset = qubo_to_ising(Q)
        self.p = p
        n_slices = len(slice_Qs)

        if slice_offsets is None:
            slice_offsets = [0.0] * n_slices
        if qubit_orders is None:
            qubit_orders = [None] * n_slices

        self.qaoa_slices = [
            QAOACircuit(
                Q=slice_Qs[k],
                offset=slice_offsets[k],
                p=p,
                hyperparameters=hyperparameters,
                qubit_order=qubit_orders[k],
                quantum_objects=qo,
            )
            for k in range(n_slices)
        ]
        self._optimizer_format = False
        self.cartesian = cartesian
        self.hyperparameters = hyperparameters
        self.qasm = self.get_circuit_from_hyperparameters()


    def get_circuit_from_hyperparameters(self, hyperparameters: Optional[np.ndarray] = None):
        if isinstance(hyperparameters, np.ndarray) and len(hyperparameters) == 2 * self.p:
            self.hyperparameters = hyperparameters
        qasms = [s.get_circuit_from_hyperparameters(self.hyperparameters) for s in self.qaoa_slices]
        self.qasm = qasms
        return qasms
        

    def sample(
        self,
        num_samples: int = 100,
        hyperparameters: Optional[np.ndarray] = None,
        original_basis: bool = False,
        **kwargs,
    ) -> np.ndarray:
        parallel = kwargs.pop("parallel", False)
        hp = (
            hyperparameters
            if isinstance(hyperparameters, np.ndarray) and len(hyperparameters) == 2 * self.p
            else self.hyperparameters
        )

        if parallel:
            with ProcessPoolExecutor(max_workers=cpu_count()) as executor:
                futures = [
                    executor.submit(self._parallel_sample, s, num_samples, hp, kwargs)
                    for s in self.qaoa_slices
                ]
            list_of_samples = [f.result() for f in futures]
        else:
            list_of_samples = [
                s.sample(hyperparameters=hp, num_samples=num_samples, **kwargs)
                for s in self.qaoa_slices
            ]

        samples = self._glue_slices(list_of_samples)
        return (samples + 1) // 2 if original_basis else samples


    def _hyperparameters_optimizer_format(self):
        self._optimizer_format = True


    def _hyperparameters_slice_format(self):
        self._optimizer_format = False


    @staticmethod
    def _format_slice(hyperparameters: np.ndarray, p: int, num_slices: int) -> np.ndarray:
        return hyperparameters


    @classmethod
    def from_ising(
        cls,
        J: np.ndarray,
        h: np.ndarray,
        offset: float = 0.0,
        slice_isings: list = None,
        hyperparameters: np.ndarray = None,
        p: int = 1,
        qubit_orders: Optional[list] = None,
        cartesian: bool = False,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ) -> "pQAOASingleParametersCircuit":
        """
        slice_isings : list of (J_k, h_k) or (J_k, h_k, offset_k) tuples, one per slice.
        hyperparameters : shared (2*p,) array.
        """
        qo = quantum_objects or CirqQuantumObjects()
        obj = object.__new__(cls)
        obj.Q = None
        obj._J = np.asarray(J, dtype=float)
        obj._h = np.asarray(h, dtype=float)
        obj._ising_offset = float(offset)
        obj.p = p
        n_slices = len(slice_isings)
        if qubit_orders is None:
            qubit_orders = [None] * n_slices
        obj.qaoa_slices = [
            QAOACircuit.from_ising(
                J=slice_isings[k][0],
                h=slice_isings[k][1],
                offset=float(slice_isings[k][2]) if len(slice_isings[k]) > 2 else 0.0,
                p=p,
                hyperparameters=hyperparameters,
                qubit_order=qubit_orders[k],
                quantum_objects=qo,
            )
            for k in range(n_slices)
        ]
        obj._optimizer_format = False
        obj.cartesian = cartesian
        obj.hyperparameters = hyperparameters
        obj.qasm = obj.get_circuit_from_hyperparameters()
        return obj


class SingleSliceQAOACircuit(QAOACircuit):
    """
    One shared circuit replicated across num_slices, with a variable remapping.

    Parameters
    ----------
    var_map : int array (n_slice_vars, num_slices)
        var_map[i, k] = column in the full model corresponding to slice variable i in copy k.
    """

    def __init__(
        self,
        Q: np.ndarray,
        slice_Q: np.ndarray,
        slice_offset: float = 0.0,
        var_map: Optional[np.ndarray] = None,
        p: int = 1,
        hyperparameters: Optional[np.ndarray] = None,
        qubit_order: Optional[np.ndarray] = None,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ):
        # Full model
        super().__init__(Q=Q, p=p, hyperparameters=hyperparameters,
                         qubit_order=qubit_order, quantum_objects=quantum_objects)

        # Slice circuit (same backend as full model)
        self.slice_circuit = QAOACircuit(
            Q=slice_Q,
            offset=slice_offset,
            p=p,
            hyperparameters=self.hyperparameters,
            quantum_objects=self._qo,
        )

        if var_map is None:
            raise ValueError("var_map must be provided for SingleSliceQAOACircuit.")
        self.var_map = np.asarray(var_map, dtype=int)
        self.num_slices = self.var_map.shape[1]
        self.n_full = Q.shape[0]


    @staticmethod
    def _parallel_sample(slice_circ, num_samples, hyperparameters, kwargs):
        return slice_circ.sample(num_samples=num_samples, hyperparameters=hyperparameters, **kwargs)


    def sample(
        self,
        num_samples: int = 100,
        hyperparameters: Optional[np.ndarray] = None,
        original_basis: bool = False,
        **kwargs,
    ) -> np.ndarray:
        hp = (
            hyperparameters
            if isinstance(hyperparameters, np.ndarray) and len(hyperparameters) == 2 * self.p
            else self.hyperparameters
        )
        parallel = kwargs.pop("parallel", False)

        total = num_samples * self.num_slices
        if parallel:
            with ProcessPoolExecutor(max_workers=cpu_count()) as executor:
                futures = [
                    executor.submit(self._parallel_sample, self.slice_circuit, num_samples, hp, kwargs)
                    for _ in range(self.num_slices)
                ]
            slice_samples = np.vstack([f.result() for f in futures])
        else:
            slice_samples = self.slice_circuit.sample(num_samples=total, hyperparameters=hp, **kwargs)

        remapped = self._slice_to_model(slice_samples, num_samples)
        samples = self._glue_slices(remapped)
        return (samples + 1) // 2 if original_basis else samples


    def _slice_to_model(self, samples: np.ndarray, n_samples: int) -> list:
        """
        Remap slice samples to full-model variable columns.

        Returns list of num_slices arrays, each (n_samples, n_full).
        """
        chunks = samples.reshape(self.num_slices, n_samples, -1)
        out = []
        for k in range(self.num_slices):
            full = np.zeros((n_samples, self.n_full), dtype=int)
            full[:, self.var_map[:, k]] = chunks[k]
            out.append(full)
        return out


    @staticmethod
    def _glue_slices(list_of_samples: list) -> np.ndarray:
        """
        Cartesian-product combine groups that cover disjoint columns.
        Each group[k] is (n_k, n_full) with non-zero only in var_map[:,k].
        Summing is correct because columns never overlap.
        Broadcasting: (m1,1,n) + (1,m2,n) → (m1,m2,n) → (m1*m2,n).
        """
        result = list_of_samples[0]
        for s in list_of_samples[1:]:
            result = (result[:, np.newaxis, :] + s[np.newaxis, :, :]).reshape(-1, result.shape[1])
        return result


    @classmethod
    def from_ising(
        cls,
        J: np.ndarray,
        h: np.ndarray,
        offset: float = 0.0,
        slice_J: np.ndarray = None,
        slice_h: np.ndarray = None,
        slice_offset: float = 0.0,
        var_map: np.ndarray = None,
        p: int = 1,
        hyperparameters: Optional[np.ndarray] = None,
        qubit_order: Optional[np.ndarray] = None,
        quantum_objects: Optional[AbstractQuantumObjects] = None,
    ) -> "SingleSliceQAOACircuit":
        if var_map is None:
            raise ValueError("var_map must be provided for SingleSliceQAOACircuit.")
        qo = quantum_objects or CirqQuantumObjects()
        obj = object.__new__(cls)
        obj.Q = None
        obj.offset = float(offset)
        obj._setup(np.asarray(J, dtype=float), np.asarray(h, dtype=float),
                   float(offset), p, hyperparameters, qubit_order, qo)
        obj.slice_circuit = QAOACircuit.from_ising(
            J=np.asarray(slice_J, dtype=float),
            h=np.asarray(slice_h, dtype=float),
            offset=float(slice_offset),
            p=p,
            hyperparameters=obj.hyperparameters,
            quantum_objects=qo,
        )
        obj.var_map = np.asarray(var_map, dtype=int)
        obj.num_slices = obj.var_map.shape[1]
        obj.n_full = len(h)
        return obj


class QAOACostFunction(CostFunction):
    """
    Mean-field energy cost function for QAOA, using the Ising Hamiltonian.
    """

    def __init__(self, J: np.ndarray, h: np.ndarray, offset: float = 0.0):
        self._J = J
        self._h = h
        self._offset = float(offset)


    def evaluate_samples(self, samples: np.ndarray) -> float:
        """
        Average energy over a batch of ±1 spin samples.
        samples : np.ndarray (n_samples, n)
        """
        return ising_evaluate_samples(self._J, self._h, self._offset, samples)
