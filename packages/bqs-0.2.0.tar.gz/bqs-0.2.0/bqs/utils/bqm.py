import numpy as np


def qubo_energy(Q: np.ndarray, offset: float, x: np.ndarray) -> float:
    """E = x^T Q x + offset.  Q: symmetric (n,n), x: binary {0,1} (n,)."""
    return float(x @ Q @ x) + float(offset)


def ising_energy(J: np.ndarray, h: np.ndarray, offset: float, s: np.ndarray) -> float:
    """E = s^T J s + h^T s + offset.  J: upper-triangular (n,n), s: spin {-1,+1} (n,)."""
    return float(s @ J @ s) + float(h @ s) + float(offset)


def ising_evaluate_samples(J: np.ndarray, h: np.ndarray, offset: float, samples: np.ndarray) -> float:
    """
    True average energy over a batch of spin samples.  samples: (n_samples, n) of ±1.

    Vectorised as  mean( diag(S J Sᵀ) + S h )  without materialising the full (n,n) product.
    (S @ J) * S  gives each row s_i^T J element-wise, summing over columns gives s_i^T J s_i.
    """
    energies = (samples @ J * samples).sum(axis=1) + samples @ h
    return float(energies.mean()) + float(offset)


def qubo_to_ising(Q: np.ndarray, offset: float = 0.0):
    """
    Convert symmetric QUBO (Q, offset) to Ising (J, h, new_offset).

    Substitution x = (s+1)/2, s in {-1,+1}:
        J[i,j] = Q[i,j]/2  for i<j  (upper-triangular)
        h[i]   = Q.sum(axis=0)[i] / 2
        new_offset = offset + tr(Q)/2 + sum_{i<j} Q[i,j]/2
    """
    h = Q.sum(axis=0) * 0.5
    J = np.triu(Q, k=1) * 0.5
    new_offset = float(offset) + float(np.trace(Q)) * 0.5 + float(np.triu(Q, k=1).sum()) * 0.5
    return J, h, new_offset


def ising_to_qubo(J: np.ndarray, h: np.ndarray, offset: float = 0.0):
    """
    Convert Ising (J upper-triangular, h, offset) to symmetric QUBO (Q, new_offset).

    Substitution s = 2x-1, x in {0,1}:
        Q[i,j] = 2*J[i,j]   for i!=j  (symmetric off-diagonal)
        Q[i,i] = -2*(J.sum(axis=1)[i] + J.sum(axis=0)[i]) + 2*h[i]
        new_offset = offset + J.sum() - h.sum()
    """
    Q = 2.0 * (J + J.T)
    np.fill_diagonal(Q, -2.0 * (J.sum(axis=1) + J.sum(axis=0)) + 2.0 * h)
    new_offset = float(offset) + float(J.sum()) - float(h.sum())
    return Q, new_offset
