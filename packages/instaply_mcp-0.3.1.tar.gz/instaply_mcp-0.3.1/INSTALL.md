# Install Instaply

Instaply supports two install modes:

1. **One-click `.mcpb` bundle** for **Claude Desktop**
2. **Command-based MCP config** for **Claude Code, Codex, and other local MCP clients**

Same engine, same local SQLite database, same Playwright runner.

## What you need first

* A local MCP client installed:
  * **Claude Desktop**
  * **Claude Code**
  * **Codex**
* **Python 3.10 or newer** on your computer.
  * macOS: `brew install python@3.12` or grab the installer from
    [python.org/downloads](https://www.python.org/downloads/).
  * Windows: install from
    [python.org/downloads](https://www.python.org/downloads/) — make
    sure to check **"Add Python to PATH"** during install.
  * Linux: `sudo apt install python3` (or your distro's equivalent).

That's it. No accounts. No API keys.

## Option A: Claude Desktop (one-click)

1. **Download** [`instaply.mcpb`](dist/instaply.mcpb).
2. **Double-click** the downloaded file.
3. Claude Desktop opens with an install dialog. Click **Install**.
4. Restart Claude Desktop (full quit, not just close the window).

The Instaply tools are now available in any Claude conversation.

## Option B: Claude Code / Codex / manual MCP config

### Claude Code

```bash
claude mcp add instaply uvx instaply-mcp
```

### Codex

```bash
codex mcp add instaply uvx instaply-mcp
```

### Manual JSON/TOML-style config

If a client wants raw command + args instead of a helper command, use:

```json
{
  "command": "uvx",
  "args": ["instaply-mcp"]
}
```

Or the pure Python fallback:

```json
{
  "command": "python",
  "args": ["-m", "instaply_mcp"]
}
```

## First conversation — try this

Open a new chat in Claude Desktop and type:

> *"Save my Instaply profile: I'm Riya, riya@example.com, phone +1 415-555-0199, LinkedIn linkedin.com/in/riya, in San Francisco, US citizen."*

Claude calls `update_profile`. Then:

> *"Apply me to https://job-boards.greenhouse.io/vercel/jobs/5179639004"*

The first time `apply_to_job` runs, Instaply needs the Playwright
browser package (Instaply will tell Claude exactly what to do — Claude
will run the install for you in the background, ~150 MB Chromium
download, cached forever after that).

Once installed, a Chrome window opens, fills the form from your
profile, and pauses for you to solve any captcha and click Submit
yourself. When the confirmation page appears:

> *"That one's done."*

Claude calls `mark_complete` — the application is now in your local
audit trail.

## Free trial

The first **5 applications** work without any payment. After that,
Instaply asks for a license key.

To buy a key: visit [instaply.asion.ai/buy](https://instaply.asion.ai)
and complete the one-time payment via Razorpay. You'll receive a key
by email — paste it into `~/.instaply/license.jwt` (or set the
`INSTAPLY_LICENSE` environment variable). The key works forever and
across all your machines.

## Where your data lives

Single SQLite file:

```
~/.instaply/data.db        # profile, answers, applications, jobs cache
~/.instaply/license.jwt    # your license key, if you bought one
```

Override with the `INSTAPLY_DATA_DIR` environment variable.

Nothing leaves your computer. Instaply has no server you talk to. If
the original author disappears, every install keeps working forever.

## Uninstall

* In Claude Desktop: **Settings → Extensions → Instaply → Uninstall**.
* Then delete `~/.instaply/` to remove your data.

## Troubleshooting

**"Tools didn't appear after install"**
Quit Claude Desktop completely (right-click tray icon → Quit on
Windows, or `Cmd+Q` on Mac) and re-open. The tools tray refreshes on
launch.

**"Python not found"**
Install Python 3.10+ from python.org and re-launch Claude Desktop.

**"apply_to_job says Playwright isn't installed"**
The first call needs Playwright + Chromium. Tell Claude:
*"Run `pip install playwright && python -m playwright install chromium`."*
Or do it yourself once in a terminal — it's a one-time setup.

**Anything else**
[github.com/Ravendise/Instaply/issues](https://github.com/Ravendise/Instaply/issues)
