"""Instaply MCP server (local-first, zero-maintenance edition).

Runs entirely on the user's machine. No HTTP calls to instaply.asion.ai
or any other server the original author has to keep alive. The user
owns their data (single SQLite file at `~/.instaply/data.db`).

Tools exposed to Claude Desktop / Claude Code / Codex / other local MCP clients:

  update_profile(patch)        — sparse update of identity fields
  get_profile()                — read current profile
  save_answer(question, answer) — teach the agent an answer once
  list_answers(limit)          — review what the agent has learned
  delete_answer(answer_id)     — forget a saved answer
  list_applications(status?)   — local audit trail of what the agent did
  get_status()                 — counts by status + cache sizes
  apply_to_job(url)            — STUB until the worker port lands; for
                                  now records a queued row and tells
                                  the user how to invoke the worker

Why no `search_jobs` yet: that needs JobSpy / Greenhouse / Lever
adapters bundled into the package. Coming in the worker-port follow-up.

Install (Claude Code / Codex):
  claude mcp add instaply uvx instaply-mcp

Install (Claude Desktop): add to claude_desktop_config.json:
  {
    "mcpServers": {
      "instaply": {
        "command": "uvx",
        "args": ["instaply-mcp"]
      }
    }
  }

Equivalent manual command everywhere:
  python -m instaply_mcp

That's it. No INSTAPLY_TOKEN. No account on a server. The MCP server
pops a SQLite file into your home directory the first time you call a
tool and you're running.
"""
from __future__ import annotations

import asyncio
import json
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from . import db


# ─── MCP wiring ──────────────────────────────────────────────────
server = Server("instaply")


TOOLS: list[Tool] = [
    Tool(
        name="update_profile",
        description=(
            "Update the local Instaply profile. Sparse / partial — only include the fields you want to change. "
            "Pass null to delete a field. Common fields: full_name, first_name, last_name, email, phone, "
            "phone_e164, linkedin_url, github_url, portfolio_url, city, state, country, postal_code, "
            "current_company, current_title, school, degree, major, work_auth_status (one of "
            "'us_citizen', 'green_card', 'h1b', 'f1_opt', 'f1_cpt', 'other'), needs_sponsorship (bool), "
            "willing_to_relocate (bool), pronouns, gender, race_ethnicity, veteran_status, disability_status. "
            "Stored locally at ~/.instaply/data.db — never leaves the user's machine."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "patch": {"type": "object", "description": "Sparse dict of fields to update or null to delete"},
            },
            "required": ["patch"],
        },
    ),
    Tool(
        name="get_profile",
        description="Read the current local Instaply profile as a flat dict. No arguments.",
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="save_answer",
        description=(
            "Teach the agent an answer to a screening question. The agent will reuse this exact answer the "
            "next time the same question (or a normalized variant) appears on any job application. "
            "Re-saving a question with a new answer overwrites the previous one. "
            "Example: question='Are you currently a Wealthfront client?', answer='No'."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "question": {"type": "string", "description": "Question text as it appears on the form"},
                "answer": {"type": "string", "description": "The answer to save and reuse"},
            },
            "required": ["question", "answer"],
        },
    ),
    Tool(
        name="list_answers",
        description=(
            "List the saved answers in the answer vault, newest first. Each entry includes question_text, "
            "answer_text, times_used, last_used_at. Useful for reviewing or auditing what the agent has learned."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "minimum": 1, "maximum": 500, "default": 100},
            },
        },
    ),
    Tool(
        name="delete_answer",
        description=(
            "Forget a saved answer by id (from list_answers). The agent will re-ask the question on the next "
            "application that surfaces it."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "answer_id": {"type": "string", "description": "answer id from list_answers"},
            },
            "required": ["answer_id"],
        },
    ),
    Tool(
        name="list_applications",
        description=(
            "Local audit trail of jobs the agent has acted on. Each row has status (queued, in_progress, "
            "submitted, confirmed, failed, needs_review, captcha_required, verification_required, skipped), "
            "company_name, title, apply_url, queued_at / started_at / completed_at."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "status": {"type": "string", "description": "Optional status filter"},
                "limit": {"type": "integer", "minimum": 1, "maximum": 500, "default": 100},
            },
        },
    ),
    Tool(
        name="get_status",
        description=(
            "Quick summary: counts of applications by status + total jobs cached + total answers saved. "
            "Cheap to call; safe to call before deciding what to do next."
        ),
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="apply_to_job",
        description=(
            "Open the apply_url in the user's local Chrome (visible window), parse the form via the "
            "Instaply rules engine, fill identity fields + saved-answer reuse, and leave the browser "
            "open so the user can solve any captcha and click Submit themselves. "
            "Requires `pip install 'instaply-mcp[worker]'` + `python -m playwright install chromium` "
            "for the first run. Updates the local application record with what was filled and what "
            "still needs the user's eye. Returns a summary the model can read aloud."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "apply_url": {"type": "string", "description": "Full URL of the application form"},
                "company_name": {"type": "string", "description": "Optional — for nicer audit-trail display"},
                "title": {"type": "string", "description": "Optional — for nicer audit-trail display"},
                "headless": {"type": "boolean", "description": "Default false (visible window so the user can solve captcha)"},
            },
            "required": ["apply_url"],
        },
    ),
    Tool(
        name="mark_complete",
        description=(
            "Mark an application as submitted after the user has clicked Submit on the actual employer "
            "page and seen the confirmation. Sets status='submitted' + completed_at=now. Idempotent."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "application_id": {"type": "string", "description": "ID from list_applications or apply_to_job"},
            },
            "required": ["application_id"],
        },
    ),
]


@server.list_tools()
async def list_tools() -> list[Tool]:
    return TOOLS


def _result(payload: Any) -> list[TextContent]:
    return [TextContent(type="text", text=json.dumps(payload, indent=2, default=str))]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        if name == "update_profile":
            result = db.update_profile(arguments.get("patch", {}))
        elif name == "get_profile":
            result = db.get_profile()
        elif name == "save_answer":
            result = db.save_answer(arguments["question"], arguments["answer"])
        elif name == "list_answers":
            result = db.list_answers(arguments.get("limit", 100))
        elif name == "delete_answer":
            ok = db.delete_answer(arguments["answer_id"])
            result = {"ok": ok, "deleted": ok}
        elif name == "list_applications":
            result = db.list_applications(
                status=arguments.get("status"),
                limit=arguments.get("limit", 100),
            )
        elif name == "get_status":
            result = db.get_status_summary()
        elif name == "apply_to_job":
            apply_url = arguments["apply_url"]
            company = arguments.get("company_name") or _domain_of(apply_url) or "Unknown"
            title = arguments.get("title") or "Untitled role"
            headless = bool(arguments.get("headless", False))
            # Synthesize a stable external_id from the URL so re-queuing
            # the same URL is idempotent.
            import hashlib
            ext_id = "url:" + hashlib.sha256(apply_url.encode("utf-8")).hexdigest()[:16]
            job_id = db.upsert_job(
                source="manual",
                external_id=ext_id,
                company_name=company,
                title=title,
                apply_url=apply_url,
            )
            queued = db.queue_application(job_id)
            # Run the local Playwright worker. Imported lazily so the
            # base v0.2 install doesn't pay the playwright startup cost.
            from . import runner
            runner_result = runner.apply_locally_sync(
                application_id=queued["application_id"],
                apply_url=apply_url,
                headless=headless,
            )
            result = {"queued": queued, "runner": runner_result}
        elif name == "mark_complete":
            from datetime import datetime, timezone
            app_id = arguments["application_id"]
            ok = db.update_application(
                app_id,
                status="submitted",
                completed_at=datetime.now(timezone.utc).isoformat(),
            )
            result = {"ok": ok, "application_id": app_id, "status": "submitted" if ok else "unchanged"}
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]
        return _result(result)
    except KeyError as e:
        return [TextContent(type="text", text=f"Missing required argument: {e}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {type(e).__name__}: {e}")]


def _domain_of(url: str) -> str:
    try:
        from urllib.parse import urlparse
        host = urlparse(url).netloc or ""
        return host.split(".")[-2] if host.count(".") >= 1 else host
    except Exception:
        return ""


async def _run() -> None:
    async with stdio_server() as (read, write):
        await server.run(read, write, server.create_initialization_options())


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
