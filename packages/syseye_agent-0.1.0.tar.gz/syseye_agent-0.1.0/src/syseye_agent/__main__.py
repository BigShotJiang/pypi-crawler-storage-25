from syseye_agent.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
