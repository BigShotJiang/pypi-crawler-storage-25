from __future__ import annotations

import argparse

from syseye_agent import __version__
from syseye_agent.agent import Agent
from syseye_agent.config import AgentConfig


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="syseye-agent", description="SysEye CLI agent")
    subparsers = parser.add_subparsers(dest="command")

    def add_connect_arguments(command_parser: argparse.ArgumentParser) -> None:
        command_parser.add_argument("--server", required=True, help="Base URL of the SysEye backend")
        command_parser.add_argument("--token", required=True, help="Connection token from the site")
        command_parser.add_argument("--poll-interval", type=int, default=3)
        command_parser.add_argument("--heartbeat-interval", type=int, default=10)
        command_parser.add_argument("--request-timeout", type=int, default=15)
        command_parser.add_argument("--command-timeout", type=int, default=60)
        command_parser.add_argument("--state-file", default=None, help="Custom state file path")

    connect_parser = subparsers.add_parser("connect", help="Connect this machine and start the agent loop")
    add_connect_arguments(connect_parser)

    run_parser = subparsers.add_parser("run", help="Alias for connect")
    add_connect_arguments(run_parser)

    subparsers.add_parser("version", help="Print CLI version")

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "version":
        print(__version__)
        return 0

    if args.command not in {"connect", "run"}:
        parser.print_help()
        return 1

    config = AgentConfig(
        server_url=args.server,
        token=args.token,
        poll_interval=args.poll_interval,
        heartbeat_interval=args.heartbeat_interval,
        request_timeout=args.request_timeout,
        command_timeout=args.command_timeout,
        **({"state_file": args.state_file} if args.state_file else {}),
    )

    agent = Agent(config)
    agent.run()
    return 0
