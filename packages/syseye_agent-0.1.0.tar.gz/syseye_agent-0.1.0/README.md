# SysEye CLI agent

Installable Python CLI for SysEye agents.

What it does now:
- registers itself on the local backend using an API key
- stores the server `agentId` in `~/.syseye-agent/agent_id`
- sends heartbeat in the background loop
- is ready for task polling when internal task endpoints appear

Install from GitHub from any directory:

```bash
pipx install "git+https://github.com/Unkno394/SysEye.git#subdirectory=cli-agent"
```

If `pipx` is not installed yet:

```bash
sudo pacman -S python-pipx
```

Target flow after PyPI publish:

```bash
pipx install syseye-agent
```

Alternative via virtualenv:

```bash
git clone https://github.com/Unkno394/SysEye.git
cd SysEye/cli-agent
python -m venv .venv
source .venv/bin/activate
pip install setuptools wheel requests
pip install --no-build-isolation .
```

Run from any console:

```bash
syseye-agent connect --server http://localhost:5000 --token YOUR_CONNECTION_TOKEN
```

Version check:

```bash
syseye-agent version
```

Background mode on Linux:

```bash
nohup syseye-agent connect --server http://localhost:5000 --token YOUR_CONNECTION_TOKEN > ~/.syseye-agent/agent.log 2>&1 &
```

PyPI publication notes:
- package metadata lives in [`pyproject.toml`](./pyproject.toml)
- publishing guide lives in [`PUBLISHING.md`](./PUBLISHING.md)
