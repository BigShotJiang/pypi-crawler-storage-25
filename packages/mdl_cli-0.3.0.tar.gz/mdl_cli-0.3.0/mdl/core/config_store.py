from __future__ import annotations

import json
import os
from dataclasses import asdict, replace
from pathlib import Path

from mdl.core.config import Defaults, default_config_dir
from mdl.core.options import AppConfig

# Overrideable for tests and advanced users.
_ENV_CONFIG_DIR = "MDL_CONFIG_DIR"

SETTINGS_COMMANDS = {"config", "cover", "cookies", "preset", "audio-format", "video-format", "out"}

ALLOWED = {
    "cover": ["on", "off"],
    "cookies": ["none", "brave", "chrome", "chromium", "firefox", "edge"],
    "preset": ["safe", "fast"],
    "audio-format": ["flac", "mp3", "opus", "m4a"],
    "video-format": ["mp4", "mkv"],
}


def default_config() -> AppConfig:
    # Default audio format: m4a (YouTube typically provides AAC in m4a or Opus in webm;
    # "flac" outputs are transcodes, not true source FLAC).
    return AppConfig(
        preset="safe",
        cookies="none",
        cover=False,
        audio_format="m4a",
        video_format="mp4",
        out_dir=_default_out_dir(),
    )


def _config_dir() -> Path:
    raw = os.environ.get(_ENV_CONFIG_DIR)
    if raw:
        return _expand_path(raw)
    return default_config_dir("mdl")


def _config_file() -> Path:
    return _config_dir() / "config.json"


def load_config() -> AppConfig:
    cfg_file = _config_file()
    if not cfg_file.exists():
        return default_config()

    try:
        data = json.loads(cfg_file.read_text(encoding="utf-8"))
    except Exception:
        return default_config()

    cfg = default_config()

    preset = _norm_str(data.get("preset", cfg.preset))
    cookies = _norm_str(data.get("cookies", cfg.cookies))
    cover = bool(data.get("cover", cfg.cover))
    audio_format = _norm_str(data.get("audio_format", cfg.audio_format))
    video_format = _norm_str(data.get("video_format", cfg.video_format))
    out_dir = _normalize_out_dir(data.get("out_dir", cfg.out_dir), cfg.out_dir)

    preset = preset if preset in ALLOWED["preset"] else cfg.preset
    cookies = cookies if cookies in ALLOWED["cookies"] else cfg.cookies
    audio_format = audio_format if audio_format in ALLOWED["audio-format"] else cfg.audio_format
    video_format = video_format if video_format in ALLOWED["video-format"] else cfg.video_format

    return AppConfig(
        preset=preset,
        cookies=cookies,
        cover=cover,
        audio_format=audio_format,
        video_format=video_format,
        out_dir=out_dir,
    )


def save_config(cfg: AppConfig) -> None:
    cfg_dir = _config_dir()
    cfg_dir.mkdir(parents=True, exist_ok=True)
    payload = asdict(cfg)
    _config_file().write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def list_allowed_values(setting: str) -> list[str]:
    setting = _norm_str(setting)
    if setting not in ALLOWED:
        raise SystemExit(f"[mdl] ERROR: unknown setting '{setting}'.")
    return list(ALLOWED[setting])


def describe_config_value(cfg: AppConfig, setting: str) -> str:
    setting = _norm_str(setting)
    if setting == "cover":
        return "on" if cfg.cover else "off"
    if setting == "cookies":
        return cfg.cookies
    if setting == "preset":
        return cfg.preset
    if setting == "audio-format":
        return cfg.audio_format
    if setting == "video-format":
        return cfg.video_format
    if setting == "out":
        return cfg.out_dir
    raise SystemExit(f"[mdl] ERROR: unknown setting '{setting}'.")


def set_config_value(cfg: AppConfig, setting: str, value: str) -> AppConfig:
    setting = _norm_str(setting)

    if setting == "out":
        value_s = str(value).strip()
        if not value_s:
            raise SystemExit("[mdl] ERROR: out requires a PATH")
        out_dir = _normalize_out_dir(value_s, "")
        if not out_dir:
            raise SystemExit("[mdl] ERROR: out requires a PATH")
        return replace(cfg, out_dir=out_dir)

    value_n = _norm_str(value)

    if setting not in ALLOWED:
        raise SystemExit(f"[mdl] ERROR: unknown setting '{setting}'.")

    if value_n not in ALLOWED[setting]:
        allowed = ", ".join(ALLOWED[setting])
        raise SystemExit(f"[mdl] ERROR: invalid value '{value}'. Allowed: {allowed}")

    if setting == "cover":
        return replace(cfg, cover=(value_n == "on"))
    if setting == "cookies":
        return replace(cfg, cookies=value_n)
    if setting == "preset":
        return replace(cfg, preset=value_n)
    if setting == "audio-format":
        return replace(cfg, audio_format=value_n)
    if setting == "video-format":
        return replace(cfg, video_format=value_n)

    # unreachable
    raise SystemExit(f"[mdl] ERROR: unknown setting '{setting}'.")


def _norm_str(x: object) -> str:
    return str(x).strip().lower()


def _expand_path(value: str) -> Path:
    return Path(os.path.expandvars(value)).expanduser()


def _default_out_dir() -> str:
    try:
        return str(Path(Defaults.out_dir).resolve())
    except Exception:
        return str(Path(Defaults.out_dir))


def _normalize_out_dir(raw: object, fallback: str) -> str:
    try:
        value = str(raw).strip()
    except Exception:
        return fallback
    if not value:
        return fallback
    try:
        return str(_expand_path(value).resolve())
    except Exception:
        return fallback
