# Mozilla.ai Docs

## any-llm

- [Introduction](https://docs.mozilla.ai/index.md)
- [Quickstart](https://docs.mozilla.ai/quickstart.md): Install any-llm and make your first API call in 5 minutes
- [Providers](https://docs.mozilla.ai/providers.md): Complete list of LLM providers supported by any-llm including OpenAI, Anthropic, Mistral, and more
- [Getting Started](https://docs.mozilla.ai/cookbooks/any-llm-getting-started.md)
- [AnyLLM](https://docs.mozilla.ai/api-reference/any-llm.md): The AnyLLM class - provider interface with metadata access and reusability
- [Responses](https://docs.mozilla.ai/api-reference/responses.md): OpenResponses API for agentic AI systems
- [Completion](https://docs.mozilla.ai/api-reference/completion.md): Create chat completions with any provider
- [Embedding](https://docs.mozilla.ai/api-reference/embedding.md): Create text embeddings with any provider
- [Messages](https://docs.mozilla.ai/api-reference/messages.md): Anthropic Messages API for all providers
- [Exceptions](https://docs.mozilla.ai/api-reference/exceptions.md): Unified exception hierarchy for all providers
- [List Models](https://docs.mozilla.ai/api-reference/list-models.md): List available models for a provider
- [Batch](https://docs.mozilla.ai/api-reference/batch.md): Process multiple requests asynchronously at lower cost
- [Types](https://docs.mozilla.ai/api-reference/completion-1.md): Data models and types for completion operations
- [Responses](https://docs.mozilla.ai/api-reference/completion-1/responses.md): Data models for the OpenResponses API
- [Messages](https://docs.mozilla.ai/api-reference/completion-1/messages.md): Data models for the Anthropic Messages API
- [Model](https://docs.mozilla.ai/api-reference/completion-1/model.md): Data models for model operations
- [Provider](https://docs.mozilla.ai/api-reference/completion-1/provider.md): Data models for provider operations
- [Batch](https://docs.mozilla.ai/api-reference/completion-1/batch.md): Data models for batch operations
- [Overview](https://docs.mozilla.ai/managed-platform/overview.md): Cloud-hosted secure API key vaulting and usage tracking for LLM providers
- [Overview](https://docs.mozilla.ai/gateway/overview.md): FastAPI-based proxy server for budget enforcement, API key management, and usage analytics
- [Quick Start](https://docs.mozilla.ai/gateway/quickstart.md): Set up any-llm-gateway and make your first LLM completion request
- [Authentication](https://docs.mozilla.ai/gateway/authentication.md): Master key and virtual API key authentication for the gateway
- [Budget Management](https://docs.mozilla.ai/gateway/budget-management.md): Configure spending limits, budget tiers, and automatic resets
- [Configuration](https://docs.mozilla.ai/gateway/configuration.md): Configure the gateway using YAML files or environment variables
- [API Reference](https://docs.mozilla.ai/gateway/api-reference.md): Complete OpenAPI specification for the any-llm gateway
- [Troubleshooting](https://docs.mozilla.ai/gateway/troubleshooting.md): Common issues and solutions for the any-llm gateway
- [Docker Deployment](https://docs.mozilla.ai/gateway/docker-deployment.md): Deploy any-llm-gateway using Docker and Docker Compose

## encoderfile

- [Introduction](https://docs.mozilla.ai/encoderfile/index.md)
- [Getting Started](https://docs.mozilla.ai/encoderfile/getting-started.md)
- [Building with Docker](https://docs.mozilla.ai/encoderfile/building-encoderfiles/docker.md)
- [Building with Python](https://docs.mozilla.ai/encoderfile/python-library/building-with-python.md)
- [API Reference](https://docs.mozilla.ai/encoderfile/python-library/api-reference.md)
- [Token Classification (NER)](https://docs.mozilla.ai/encoderfile/cookbooks/token-classification-ner.md)
- [MCP Integration](https://docs.mozilla.ai/encoderfile/cookbooks/mcp-integration.md)
- [Matryoshka Embeddings](https://docs.mozilla.ai/encoderfile/cookbooks/matryoshka-embeddings.md)
- [Local RAG](https://docs.mozilla.ai/encoderfile/cookbooks/local-rag.md)
- [CVE Semantic Search](https://docs.mozilla.ai/encoderfile/cookbooks/qdrant-cve-search.md)
- [Transforms](https://docs.mozilla.ai/encoderfile/transforms/index.md)
- [Reference](https://docs.mozilla.ai/encoderfile/transforms/reference.md)
- [Encoderfile File Format](https://docs.mozilla.ai/encoderfile/reference/file_format.md)
- [CLI Reference](https://docs.mozilla.ai/encoderfile/reference/cli.md)
- [API Reference](https://docs.mozilla.ai/encoderfile/reference/api-reference.md)
- [Building Guide](https://docs.mozilla.ai/encoderfile/reference/building.md)
- [Contributing](https://docs.mozilla.ai/encoderfile/community/contributing.md)
- [Code of Conduct](https://docs.mozilla.ai/encoderfile/community/code_of_conduct.md)

## llamafile

- [Home](https://docs.mozilla.ai/llamafile/index.md)
- [Quickstart](https://docs.mozilla.ai/llamafile/getting-started/quickstart.md)
- [Example llamafiles](https://docs.mozilla.ai/llamafile/getting-started/example_llamafiles.md)
- [Running a llamafile](https://docs.mozilla.ai/llamafile/using-llamafile/running_llamafile.md)
- [Creating llamafiles](https://docs.mozilla.ai/llamafile/using-llamafile/creating_llamafiles.md)
- [Source installation](https://docs.mozilla.ai/llamafile/using-llamafile/source_installation.md)
- [Building DLLs](https://docs.mozilla.ai/llamafile/using-llamafile/building_dlls.md)
- [Technical details](https://docs.mozilla.ai/llamafile/reference/technical_details.md)
- [Supported Systems](https://docs.mozilla.ai/llamafile/reference/support.md)
- [Troubleshooting](https://docs.mozilla.ai/llamafile/reference/troubleshooting.md)
- [Overview](https://docs.mozilla.ai/llamafile/whisperfile/index.md)
- [Getting Started](https://docs.mozilla.ai/llamafile/whisperfile/getting-started.md)
- [Packaging](https://docs.mozilla.ai/llamafile/whisperfile/packaging.md)
- [Using GPUs](https://docs.mozilla.ai/llamafile/whisperfile/gpu.md)
- [Translation](https://docs.mozilla.ai/llamafile/whisperfile/translate.md)
- [Server](https://docs.mozilla.ai/llamafile/whisperfile/server.md)

## any-guardrail

- [Introduction](https://docs.mozilla.ai/any-guardrail/index.md)
- [Quick Start](https://docs.mozilla.ai/any-guardrail/quickstart.md)
- [Alinia Guardrail Usage](https://docs.mozilla.ai/any-guardrail/cookbook/alinia_guardrail_usage.md)
- [Any LLM as a Guardrail](https://docs.mozilla.ai/any-guardrail/cookbook/any_llm_as_a_guardrail.md)
- [Customer Service Policy Guardrail](https://docs.mozilla.ai/any-guardrail/cookbook/customer_service_policy_guardrail.md)
- [Custom Blocklists with Azure Content Safety](https://docs.mozilla.ai/any-guardrail/cookbook/azure_blocklist_slang_filter.md)
- [AnyGuardrail](https://docs.mozilla.ai/any-guardrail/api-reference/any_guardrail.md)
- [Types](https://docs.mozilla.ai/any-guardrail/api-reference/types.md)
- [Guardrails](https://docs.mozilla.ai/any-guardrail/api-reference/index.md)
- [Alinia](https://docs.mozilla.ai/any-guardrail/api-reference/index/alinia.md)
- [AnyLLM](https://docs.mozilla.ai/any-guardrail/api-reference/index/any-llm.md)
- [Azure Content Safety](https://docs.mozilla.ai/any-guardrail/api-reference/index/azure-content-safety.md)
- [Deepset](https://docs.mozilla.ai/any-guardrail/api-reference/index/deepset.md)
- [DuoGuard](https://docs.mozilla.ai/any-guardrail/api-reference/index/duo-guard.md)
- [FlowJudge](https://docs.mozilla.ai/any-guardrail/api-reference/index/flowjudge.md)
- [Glider](https://docs.mozilla.ai/any-guardrail/api-reference/index/glider.md)
- [GraniteGuardian](https://docs.mozilla.ai/any-guardrail/api-reference/index/granite-guardian.md)
- [HarmGuard](https://docs.mozilla.ai/any-guardrail/api-reference/index/harm-guard.md)
- [InjecGuard](https://docs.mozilla.ai/any-guardrail/api-reference/index/injec-guard.md)
- [Jasper](https://docs.mozilla.ai/any-guardrail/api-reference/index/jasper.md)
- [LlamaGuard](https://docs.mozilla.ai/any-guardrail/api-reference/index/llama-guard.md)
- [OffTopic](https://docs.mozilla.ai/any-guardrail/api-reference/index/off-topic.md)
- [Pangolin](https://docs.mozilla.ai/any-guardrail/api-reference/index/pangolin.md)
- [ProtectAI](https://docs.mozilla.ai/any-guardrail/api-reference/index/protectai.md)
- [Sentinel](https://docs.mozilla.ai/any-guardrail/api-reference/index/sentinel.md)
- [ShieldGemma](https://docs.mozilla.ai/any-guardrail/api-reference/index/shield-gemma.md)

## cq

- [Introduction](https://docs.mozilla.ai/cq/index.md)
- [Architecture](https://docs.mozilla.ai/cq/guides/architecture.md)
- [Development](https://docs.mozilla.ai/cq/guides/development.md)
- [CLI](https://docs.mozilla.ai/cq/components/cli.md)
- [CLI Development](https://docs.mozilla.ai/cq/components/cli/development.md)
- [Go SDK](https://docs.mozilla.ai/cq/components/go.md)
- [Go SDK Development](https://docs.mozilla.ai/cq/components/go/development.md)
- [Python SDK](https://docs.mozilla.ai/cq/components/python.md)
- [Python SDK Development](https://docs.mozilla.ai/cq/components/python/development.md)
- [Server](https://docs.mozilla.ai/cq/components/server.md)
- [Proposal](https://docs.mozilla.ai/cq/reference/cq-proposal.md)
- [Contributing](https://docs.mozilla.ai/cq/community/contributing.md)

## any-agent

- [Introduction](https://docs.mozilla.ai/any-agent/index.md)
- [Define and Run Agents](https://docs.mozilla.ai/any-agent/agents/index.md)
- [Models](https://docs.mozilla.ai/any-agent/agents/models.md)
- [Callbacks](https://docs.mozilla.ai/any-agent/agents/callbacks.md)
- [Frameworks](https://docs.mozilla.ai/any-agent/agents/index-1.md)
- [Agno](https://docs.mozilla.ai/any-agent/agents/index-1/agno.md)
- [Google ADK](https://docs.mozilla.ai/any-agent/agents/index-1/google-adk.md)
- [LangChain](https://docs.mozilla.ai/any-agent/agents/index-1/langchain.md)
- [LlamaIndex](https://docs.mozilla.ai/any-agent/agents/index-1/llama-index.md)
- [OpenAI Agents SDK](https://docs.mozilla.ai/any-agent/agents/index-1/openai.md)
- [smolagents](https://docs.mozilla.ai/any-agent/agents/index-1/smolagents.md)
- [TinyAgent](https://docs.mozilla.ai/any-agent/agents/index-1/tinyagent.md)
- [Tools](https://docs.mozilla.ai/any-agent/agents/tools.md)
- [Frameworks](https://docs.mozilla.ai/any-agent/core-concepts/frameworks.md)
- [Tracing](https://docs.mozilla.ai/any-agent/core-concepts/tracing.md)
- [Evaluation](https://docs.mozilla.ai/any-agent/core-concepts/evaluation.md)
- [Serving](https://docs.mozilla.ai/any-agent/core-concepts/serving.md)
- [Your First Agent](https://docs.mozilla.ai/any-agent/cookbook/your-first-agent.md)
- [Your First Agent Evaluation](https://docs.mozilla.ai/any-agent/cookbook/your-first-agent-evaluation.md)
- [Using Callbacks](https://docs.mozilla.ai/any-agent/cookbook/callbacks.md)
- [MCP Agent](https://docs.mozilla.ai/any-agent/cookbook/mcp-agent.md)
- [Serve with A2A](https://docs.mozilla.ai/any-agent/cookbook/serve-a2a.md)
- [Use an Agent as a Tool (A2A)](https://docs.mozilla.ai/any-agent/cookbook/a2a-as-tool.md)
- [Local Agent](https://docs.mozilla.ai/any-agent/cookbook/agent-with-local-llm.md)
- [Agent](https://docs.mozilla.ai/any-agent/api-reference/agent.md): AnyAgent, AgentCancel, and AgentRunError reference
- [Callbacks](https://docs.mozilla.ai/any-agent/api-reference/callbacks.md): Callback, Context, ConsolePrintSpan, and get\_default\_callbacks reference
- [Config](https://docs.mozilla.ai/any-agent/api-reference/config.md): AgentConfig, MCP configurations, AgentFramework, and serving configs
- [Evaluation](https://docs.mozilla.ai/any-agent/api-reference/evaluation.md): LlmJudge and AgentJudge reference
- [Logging](https://docs.mozilla.ai/any-agent/api-reference/logging.md): Logging setup and customization
- [Serving](https://docs.mozilla.ai/any-agent/api-reference/serving.md): ServerHandle reference
- [Tools](https://docs.mozilla.ai/any-agent/api-reference/tools.md): Built-in tools provided by any-agent
- [Tracing](https://docs.mozilla.ai/any-agent/api-reference/tracing.md): AgentTrace, AgentSpan, CostInfo, TokenInfo, and GenAI reference

## tinyagent

- [Introduction](https://docs.mozilla.ai/tinyagent/index.md)
- [Models](https://docs.mozilla.ai/tinyagent/guides/models.md)
- [Tools](https://docs.mozilla.ai/tinyagent/guides/tools.md)
- [Callbacks](https://docs.mozilla.ai/tinyagent/guides/callbacks.md)
- [Tracing](https://docs.mozilla.ai/tinyagent/guides/tracing.md)
- [Serving](https://docs.mozilla.ai/tinyagent/guides/serving.md)
- [Evaluation](https://docs.mozilla.ai/tinyagent/guides/evaluation.md)
- [Your first agent](https://docs.mozilla.ai/tinyagent/cookbook/your-first-agent.md)
- [Evaluating an agent](https://docs.mozilla.ai/tinyagent/cookbook/your-first-agent-evaluation.md)
- [MCP agent](https://docs.mozilla.ai/tinyagent/cookbook/mcp-agent.md)
- [Callbacks](https://docs.mozilla.ai/tinyagent/cookbook/callbacks.md)
- [Serve over A2A](https://docs.mozilla.ai/tinyagent/cookbook/serve-a2a.md)
- [Local LLM](https://docs.mozilla.ai/tinyagent/cookbook/agent-with-local-llm.md)
- [Agent](https://docs.mozilla.ai/tinyagent/api-reference/agent.md): TinyAgent, AgentCancel, and AgentRunError reference
- [Config](https://docs.mozilla.ai/tinyagent/api-reference/config.md): AgentConfig, MCP configurations, and serving configs
- [Callbacks](https://docs.mozilla.ai/tinyagent/api-reference/callbacks.md): Callback, Context, ConsolePrintSpan, and get\_default\_callbacks reference
- [Tracing](https://docs.mozilla.ai/tinyagent/api-reference/tracing.md): AgentTrace, AgentSpan, CostInfo, TokenInfo, and GenAI reference
- [Evaluation](https://docs.mozilla.ai/tinyagent/api-reference/evaluation.md): LlmJudge and AgentJudge reference
- [Tools](https://docs.mozilla.ai/tinyagent/api-reference/tools.md): Built-in tools provided by tinyagent
- [Serving](https://docs.mozilla.ai/tinyagent/api-reference/serving.md): ServerHandle reference


---

# Agent Instructions: Querying This Documentation

If you need additional information, you can query the documentation dynamically by asking a question.

Perform an HTTP GET request on a page URL with the `ask` query parameter:

```
GET https://docs.mozilla.ai/index.md?ask=<question>
```

The question should be specific, self-contained, and written in natural language.
The response will contain a direct answer to the question and relevant excerpts and sources from the documentation.

Use this mechanism when the answer is not explicitly present in the current page, you need clarification or additional context, or you want to retrieve related documentation sections.
