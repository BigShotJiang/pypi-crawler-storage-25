"""Calculator skill tools."""


def multiply_numbers(a: int, b: int) -> int:
    """Multiply two integers and return the exact product."""

    return a * b
