Use calculator tools for exact arithmetic. Prefer the tool result over mental math.
