"""Local pricing catalog backed by the LiteLLM model price database.

The bundled snapshot lives at `hajimi/data/litellm_prices.json`. Refresh it
with `python -m hajimi.pricing refresh` (or call `refresh_pricing_catalog()`
from async code) to pull the latest from upstream.

Source of truth:
https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json
"""

from __future__ import annotations

import json
import urllib.request
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import anyio

from hajimi.config.models import ModelPricing

LITELLM_PRICES_URL = (
    "https://raw.githubusercontent.com/BerriAI/litellm/main/"
    "model_prices_and_context_window.json"
)
BUNDLED_PRICES_PATH = Path(__file__).parent / "data" / "litellm_prices.json"

_CHAT_MODES = {"chat", "completion", "responses", None}

# Hardcoded fallbacks for models that are live but not yet reflected in the
# community snapshot.  Keys are model ids; values are per-1M-token USD.
_FALLBACKS: dict[str, ModelPricing] = {
    "deepseek-v4-flash": ModelPricing(
        input_per_1m=0.14, output_per_1m=0.28, cached_input_per_1m=0.0028
    ),
}


@dataclass(frozen=True, slots=True)
class CatalogEntry:
    """One model record from the LiteLLM price database."""

    id: str
    provider: str | None
    mode: str | None
    max_input_tokens: int | None
    max_output_tokens: int | None
    pricing: ModelPricing


@dataclass(slots=True)
class PricingCatalog:
    """Read-only model price + context-window catalog.

    Lookups are best-effort: exact key match first, then `<provider>/<model>`,
    then case-insensitive matches on the full id and on the last path segment.
    """

    entries: dict[str, CatalogEntry]
    _normalized: dict[str, str]
    _by_tail: dict[str, str]

    @classmethod
    def from_path(cls, path: str | Path) -> "PricingCatalog":
        raw = Path(path).read_bytes()
        return cls.from_mapping(json.loads(raw))

    @classmethod
    def from_bundled(cls) -> "PricingCatalog":
        return cls.from_path(BUNDLED_PRICES_PATH)

    @classmethod
    async def aload(cls, path: str | Path | None = None) -> "PricingCatalog":
        target = Path(path) if path else BUNDLED_PRICES_PATH
        async with await anyio.open_file(target, "rb") as fh:
            data = await fh.read()
        return cls.from_mapping(json.loads(data))

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any]) -> "PricingCatalog":
        entries: dict[str, CatalogEntry] = {}
        for key, info in data.items():
            if key == "sample_spec" or not isinstance(info, Mapping):
                continue
            if info.get("mode") not in _CHAT_MODES:
                continue
            input_cost = info.get("input_cost_per_token")
            output_cost = info.get("output_cost_per_token")
            if input_cost is None and output_cost is None:
                continue
            cache_read = info.get("cache_read_input_token_cost")
            pricing = ModelPricing(
                input_per_1m=float(input_cost or 0.0) * 1_000_000.0,
                output_per_1m=float(output_cost or 0.0) * 1_000_000.0,
                cached_input_per_1m=(
                    float(cache_read) * 1_000_000.0 if cache_read is not None else None
                ),
            )
            entries[key] = CatalogEntry(
                id=key,
                provider=info.get("litellm_provider"),
                mode=info.get("mode"),
                max_input_tokens=info.get("max_input_tokens"),
                max_output_tokens=info.get("max_output_tokens"),
                pricing=pricing,
            )
        normalized: dict[str, str] = {}
        by_tail: dict[str, str] = {}
        for key in entries:
            normalized.setdefault(key.lower(), key)
            if "/" in key:
                tail = key.rsplit("/", 1)[1]
                by_tail.setdefault(tail.lower(), key)
        return cls(entries=entries, _normalized=normalized, _by_tail=by_tail)

    def lookup(self, model_id: str, *, provider: str | None = None) -> CatalogEntry | None:
        """Best-effort entry lookup.

        Search order:
          1. exact `model_id`
          2. `<provider>/<model_id>` when `provider` is given
          3. case-insensitive `model_id`
          4. trailing-segment match (e.g. `qwen-flash` finds `dashscope/qwen-flash`)
        """

        if model_id in self.entries:
            return self.entries[model_id]
        if provider:
            candidate = f"{provider}/{model_id}"
            if candidate in self.entries:
                return self.entries[candidate]
        norm = model_id.lower()
        if norm in self._normalized:
            return self.entries[self._normalized[norm]]
        if norm in self._by_tail:
            return self.entries[self._by_tail[norm]]
        return None

    def pricing_for(
        self,
        model_id: str,
        *,
        provider: str | None = None,
    ) -> ModelPricing | None:
        entry = self.lookup(model_id, provider=provider)
        if entry is not None:
            # A zero pricing row is unreliable data, not a real free model.
            if entry.pricing.input_per_1m == 0.0 and entry.pricing.output_per_1m == 0.0:
                return None
            return entry.pricing
        return _FALLBACKS.get(model_id)

    def __len__(self) -> int:
        return len(self.entries)

    def __contains__(self, key: object) -> bool:
        return isinstance(key, str) and key in self.entries


async def refresh_pricing_catalog(
    *,
    url: str = LITELLM_PRICES_URL,
    path: str | Path | None = None,
    timeout: float = 30.0,
) -> Path:
    """Download the latest LiteLLM database and overwrite the bundled file."""

    target = Path(path) if path else BUNDLED_PRICES_PATH
    target.parent.mkdir(parents=True, exist_ok=True)

    def _fetch() -> bytes:
        request = urllib.request.Request(url, headers={"User-Agent": "hajimi"})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.read()

    data = await anyio.to_thread.run_sync(_fetch)
    target.write_bytes(data)
    return target


def _cli_refresh() -> None:
    """`python -m hajimi.pricing refresh` entry-point."""

    import sys

    args = sys.argv[1:]
    if args and args[0] in {"refresh", "update"}:
        path = anyio.from_thread.run(refresh_pricing_catalog) if False else None
        # Run via anyio synchronously.
        path = anyio.run(refresh_pricing_catalog)
        catalog = PricingCatalog.from_path(path)
        print(f"Refreshed {path} ({len(catalog)} priced chat models)")
        return
    print("Usage: python -m hajimi.pricing refresh", file=sys.stderr)
    sys.exit(1)


if __name__ == "__main__":
    _cli_refresh()


__all__ = [
    "BUNDLED_PRICES_PATH",
    "CatalogEntry",
    "LITELLM_PRICES_URL",
    "PricingCatalog",
    "refresh_pricing_catalog",
]
