"""MCP client adapters backed by the official Python SDK."""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any

from hajimi.config import MCPServerSettings, MCPSettings
from hajimi.tool import Tool


@dataclass(frozen=True, slots=True)
class MCPClient:
    settings: MCPServerSettings

    @asynccontextmanager
    async def session(self) -> AsyncIterator[Any]:
        ClientSession, transport = self._build_transport()
        async with transport as streams:
            read_stream, write_stream = streams[0], streams[1]
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()
                yield session

    async def list_tools(self) -> list[Tool]:
        async with self.session() as session:
            result = await session.list_tools()
            return [self._to_tool(tool) for tool in result.tools]

    def _to_tool(self, remote_tool: Any) -> Tool:
        remote_name = str(remote_tool.name)
        local_name = _local_tool_name(self.settings, remote_name)
        description = getattr(remote_tool, "description", None) or f"MCP tool {remote_name}."
        parameters = getattr(remote_tool, "inputSchema", None) or {"type": "object", "properties": {}}

        async def handler(**arguments: Any) -> Any:
            async with self.session() as session:
                result = await session.call_tool(remote_name, arguments=arguments)
                return _mcp_result_to_value(result)

        return Tool(
            name=local_name,
            description=description,
            parameters=parameters,
            handler=handler,
        )

    def _build_transport(self) -> tuple[Any, Any]:
        try:
            from mcp import ClientSession, StdioServerParameters
            from mcp.client.stdio import stdio_client
            from mcp.client.streamable_http import streamable_http_client
        except ImportError as exc:
            raise RuntimeError("MCP support requires `uv sync --extra mcp`.") from exc

        if self.settings.transport == "stdio":
            if not self.settings.command:
                raise ValueError(f"MCP server {self.settings.name!r} needs a command.")
            params = StdioServerParameters(
                command=self.settings.command,
                args=self.settings.args,
                env=self.settings.env or None,
                cwd=str(self.settings.cwd) if self.settings.cwd else None,
            )
            return ClientSession, stdio_client(params)

        if self.settings.transport in {"http", "streamable_http"}:
            if not self.settings.url:
                raise ValueError(f"MCP server {self.settings.name!r} needs a url.")
            return ClientSession, streamable_http_client(self.settings.url)

        raise ValueError(f"Unsupported MCP transport {self.settings.transport!r}.")


@dataclass(frozen=True, slots=True)
class MCPToolSource:
    settings: MCPSettings

    async def load_tools(self, server_names: list[str] | None = None) -> list[Tool]:
        if not self.settings.enabled:
            return []
        allowed = set(server_names) if server_names is not None else None
        tools: list[Tool] = []
        for server in self.settings.servers.values():
            if server.enabled and (allowed is None or server.name in allowed):
                tools.extend(await MCPClient(server).list_tools())
        return tools


def _local_tool_name(settings: MCPServerSettings, remote_name: str) -> str:
    prefix = settings.tool_prefix
    if prefix is None:
        prefix = settings.name
    return f"{prefix}_{remote_name}" if prefix else remote_name


def _mcp_result_to_value(result: Any) -> Any:
    structured = getattr(result, "structuredContent", None)
    if structured is not None:
        return structured

    contents = getattr(result, "content", None) or []
    values = [_content_to_value(content) for content in contents]
    if len(values) == 1:
        return values[0]
    return values


def _content_to_value(content: Any) -> Any:
    text = getattr(content, "text", None)
    if text is not None:
        return text

    data = getattr(content, "data", None)
    mime_type = getattr(content, "mimeType", None)
    if data is not None:
        return {"type": getattr(content, "type", "data"), "mime_type": mime_type, "data": data}

    if hasattr(content, "model_dump"):
        return content.model_dump()
    try:
        return json.loads(str(content))
    except json.JSONDecodeError:
        return str(content)
