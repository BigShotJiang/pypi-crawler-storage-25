"""High-level runtime API for routed agent execution."""

from __future__ import annotations

from collections.abc import AsyncIterator, Callable
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Any, Literal

import anyio

from hajimi.budget import BudgetMeter, CostReport, ExceededPolicy
from hajimi.config import AppConfig, ModelPricing, ModelSettings, load_config
from hajimi.core.builder import build_agent
from hajimi.corekit import Agent
from hajimi.llm import AnyLLMClient
from hajimi.observability import TraceManager, setup_observability
from hajimi.pricing import PricingCatalog
from hajimi.session import AgentSession, ContextManager, SessionStore, create_session_store
from hajimi.session.models import MessageRecord
from hajimi.session.tokens import TokenEstimator

type ClientFactory = Callable[[ModelSettings, TraceManager], AnyLLMClient]
type RouteMode = Literal["auto", "single", "subagents", "replicas"]


@dataclass(frozen=True, slots=True)
class RunOptions:
    """Advanced runtime controls for one task.

    All fields are optional. Defaults are conservative so that
    `await runtime.run_task("...")` behaves predictably for casual users while
    every dial remains explicit for power users.
    """

    mode: RouteMode = "auto"
    profiles: list[str] | None = None
    replicas: int | None = None
    session_id: str | None = None
    session_name: str | None = None
    use_session: bool = True
    # Budget controls (P1). `max_budget_tokens` keeps backwards compat as the
    # pre-flight input estimate cap; the others are enforced live across all
    # workers via a shared `BudgetMeter`.
    max_budget_tokens: int | None = None
    max_input_tokens: int | None = None
    max_output_tokens: int | None = None
    max_total_tokens: int | None = None
    max_cost_usd: float | None = None
    on_budget_exceeded: ExceededPolicy = "raise"
    pricing: dict[str, ModelPricing] | None = None
    # Per-call agent overrides (P4).
    model_name: str | None = None
    system_prompt: str | None = None
    max_tool_rounds: int | None = None
    extra_skills: list[str] | None = None
    extra_mcp_servers: list[str] | None = None
    tool_names_override: list[str] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class RoutePlan:
    """Resolved route for a user task."""

    mode: RouteMode
    reason: str
    profiles: list[str] = field(default_factory=list)
    replicas: int = 1
    max_budget_tokens: int | None = None
    estimated_input_tokens: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class WorkerResult:
    """Result from a routed worker agent."""

    name: str
    profile: str | None
    content: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class RuntimeStreamEvent:
    """One event in `AgentRuntime.stream_task` output."""

    kind: Literal["route", "token", "final"]
    text: str = ""
    content: str = ""
    plan: "RoutePlan | None" = None
    cost: "CostReport | None" = None


@dataclass(frozen=True, slots=True)
class RuntimeResult:
    """High-level runtime result with routing and replay metadata."""

    content: str
    plan: RoutePlan
    session_id: str | None = None
    trace_file: Path | None = None
    workers: list[WorkerResult] = field(default_factory=list)
    token_report: dict[str, Any] | None = None
    cost: CostReport | None = None


@dataclass(slots=True)
class AgentRuntime:
    """One-call and advanced routed execution facade.

    `Agent` remains the low-level execution primitive. This runtime adds a
    deterministic routing layer for normal users and exposes explicit knobs for
    advanced users who need reproducible multi-agent behavior.
    """

    config: AppConfig
    tracer: TraceManager
    store: SessionStore | None = None
    client_factory: ClientFactory | None = None
    skills_dir: str | Path = "skills"
    catalog: PricingCatalog | None = None

    @classmethod
    async def from_config(
        cls,
        config: AppConfig,
        *,
        tracer: TraceManager | None = None,
        store: SessionStore | None = None,
        client_factory: ClientFactory | None = None,
        skills_dir: str | Path = "skills",
        catalog: PricingCatalog | None = None,
    ) -> "AgentRuntime":
        active_tracer = tracer or await setup_observability(config.observability, config.repo_path)
        active_store = store
        if active_store is None and config.context.enabled:
            active_store = create_session_store(config.context, config.repo_path)
        active_catalog = catalog or PricingCatalog.from_bundled()
        return cls(
            config=config,
            tracer=active_tracer,
            store=active_store,
            client_factory=client_factory,
            skills_dir=skills_dir,
            catalog=active_catalog,
        )

    async def ask(self, question: str, **model_overrides: Any) -> str:
        """Answer a question with default automatic routing."""

        result = await self.run_task(question, options=RunOptions(), **model_overrides)
        return result.content

    async def run_task(
        self,
        task: str,
        *,
        options: RunOptions | None = None,
        **model_overrides: Any,
    ) -> RuntimeResult:
        """Run a task through single-agent, subagent, or replica routing."""

        active_options = options or RunOptions()
        plan = self.plan(task, active_options)
        _check_budget(plan)
        meter = self._build_budget(active_options)
        async with self.tracer.span(
            "runtime.run",
            kind="agent",
            attributes={
                "runtime.mode": plan.mode,
                "runtime.reason": plan.reason,
                "runtime.profiles": plan.profiles,
                "runtime.replicas": plan.replicas,
                "runtime.estimated_input_tokens": plan.estimated_input_tokens,
                "runtime.budget.active": meter is not None,
            },
        ) as span:
            span.add_event("runtime.route", plan.to_dict())
            if plan.mode == "single":
                result = await self._run_single(
                    task, options=active_options, plan=plan, model_overrides=model_overrides, meter=meter
                )
            elif plan.mode == "subagents":
                result = await self._run_subagents(
                    task, options=active_options, plan=plan, model_overrides=model_overrides, meter=meter
                )
            else:
                result = await self._run_replicas(
                    task, options=active_options, plan=plan, model_overrides=model_overrides, meter=meter
                )
            span.set_attribute("runtime.output.length", len(result.content))
            if result.cost is not None:
                span.set_attribute("runtime.cost.usd", round(result.cost.cost_usd, 6))
                span.set_attribute("runtime.cost.tokens", result.cost.total_tokens)
            return result

    def plan(self, task: str, options: RunOptions | None = None) -> RoutePlan:
        """Resolve the deterministic route for a task."""

        active_options = options or RunOptions()
        routing = self.config.agent.routing
        requested_mode = active_options.mode if active_options.mode != "auto" else routing.default_mode
        if not routing.enabled:
            requested_mode = "single"
        profiles = _profiles(active_options.profiles, routing.default_profiles)
        # Explicit per-call profiles are a strong intent signal: skip the
        # simple-task heuristic and force the subagents mode even on `auto`.
        explicit_profiles = active_options.profiles is not None and bool(active_options.profiles)
        if explicit_profiles and requested_mode == "auto":
            requested_mode = "subagents"
        replicas = _bounded_replicas(
            active_options.replicas or routing.default_replicas,
            routing.max_parallel_agents,
        )
        max_budget_tokens = active_options.max_budget_tokens or routing.max_budget_tokens
        estimated = TokenEstimator(tokenizer=self.config.context.tokenizer).count_text(task)

        if requested_mode == "single":
            return RoutePlan(
                mode="single",
                reason="requested_single",
                max_budget_tokens=max_budget_tokens,
                estimated_input_tokens=estimated,
            )
        if requested_mode == "subagents":
            return RoutePlan(
                mode="subagents",
                reason="requested_subagents",
                profiles=_default_subagent_profiles(profiles, self.config.agent.profiles),
                max_budget_tokens=max_budget_tokens,
                estimated_input_tokens=estimated,
            )
        if requested_mode == "replicas":
            return RoutePlan(
                mode="replicas",
                reason="requested_replicas",
                replicas=replicas,
                max_budget_tokens=max_budget_tokens,
                estimated_input_tokens=estimated,
            )

        if _is_simple_task(task, routing.simple_max_words, routing.simple_max_tool_markers):
            return RoutePlan(
                mode="single",
                reason="auto_simple_task",
                max_budget_tokens=max_budget_tokens,
                estimated_input_tokens=estimated,
            )
        # P3: auto fanout only fires when the user explicitly asked for it via
        # `routing.default_profiles` or `RunOptions.profiles`. Merely having
        # profiles defined in config is not a reason to multiply LLM calls.
        if profiles:
            return RoutePlan(
                mode="subagents",
                reason="auto_specialized_profiles",
                profiles=_default_subagent_profiles(profiles, self.config.agent.profiles),
                max_budget_tokens=max_budget_tokens,
                estimated_input_tokens=estimated,
            )
        return RoutePlan(
            mode="single",
            reason="auto_complex_single",
            max_budget_tokens=max_budget_tokens,
            estimated_input_tokens=estimated,
        )

    async def _run_single(
        self,
        task: str,
        *,
        options: RunOptions,
        plan: RoutePlan,
        model_overrides: dict[str, Any],
        meter: BudgetMeter | None,
    ) -> RuntimeResult:
        built = await self._build_root(options, meter=meter)
        if options.use_session and self.store is not None:
            session = await self._session(built, options)
            result = await session.run(task, **model_overrides)
            return RuntimeResult(
                content=result.content,
                plan=plan,
                session_id=session.session_id,
                trace_file=self._trace_file(),
                token_report=result.token_usage.to_dict(),
                cost=_finalize_cost(meter),
            )
        result = await built.run(task, **model_overrides)
        return RuntimeResult(
            content=result.content,
            plan=plan,
            trace_file=self._trace_file(),
            cost=_finalize_cost(meter),
        )

    async def _run_subagents(
        self,
        task: str,
        *,
        options: RunOptions,
        plan: RoutePlan,
        model_overrides: dict[str, Any],
        meter: BudgetMeter | None,
    ) -> RuntimeResult:
        root_options = replace(options, use_session=False)
        worker_results: list[WorkerResult] = []
        for profile in plan.profiles:
            built = await self._build_profile(profile, root_options, meter=meter)
            prompt = _profile_prompt(task, profile)
            result = await built.run(prompt, **model_overrides)
            worker_results.append(WorkerResult(name=profile, profile=profile, content=result.content))
        content = await self._synthesize(
            task, worker_results, options=root_options, model_overrides=model_overrides, meter=meter
        )
        session_id = None
        token_report = None
        if options.use_session and self.store is not None:
            session = await self._record_routed_session(task, content, plan, worker_results, options)
            session_id = session.session_id
            token_report = (await session.token_report()).to_dict()
        return RuntimeResult(
            content=content,
            plan=plan,
            session_id=session_id,
            trace_file=self._trace_file(),
            workers=worker_results,
            token_report=token_report,
            cost=_finalize_cost(meter),
        )

    async def _run_replicas(
        self,
        task: str,
        *,
        options: RunOptions,
        plan: RoutePlan,
        model_overrides: dict[str, Any],
        meter: BudgetMeter | None,
    ) -> RuntimeResult:
        root_options = replace(options, use_session=False)
        worker_results: list[WorkerResult | None] = [None] * plan.replicas

        async def run_replica(index: int) -> None:
            built = await self._build_root(
                root_options,
                agent_name=f"{self.config.agent.name}_replica_{index}",
                meter=meter,
            )
            result = await built.run(_replica_prompt(task, index), **model_overrides)
            worker_results[index - 1] = WorkerResult(
                name=f"replica_{index}",
                profile=None,
                content=result.content,
            )

        async with anyio.create_task_group() as task_group:
            for index in range(1, plan.replicas + 1):
                task_group.start_soon(run_replica, index)
        completed_workers = [worker for worker in worker_results if worker is not None]
        content = await self._synthesize(
            task, completed_workers, options=root_options, model_overrides=model_overrides, meter=meter
        )
        session_id = None
        token_report = None
        if options.use_session and self.store is not None:
            session = await self._record_routed_session(task, content, plan, completed_workers, options)
            session_id = session.session_id
            token_report = (await session.token_report()).to_dict()
        return RuntimeResult(
            content=content,
            plan=plan,
            session_id=session_id,
            trace_file=self._trace_file(),
            workers=completed_workers,
            token_report=token_report,
            cost=_finalize_cost(meter),
        )

    async def _synthesize(
        self,
        task: str,
        workers: list[WorkerResult],
        *,
        options: RunOptions,
        model_overrides: dict[str, Any],
        meter: BudgetMeter | None,
    ) -> str:
        if len(workers) == 1:
            return workers[0].content
        profile = self.config.agent.routing.synthesizer_profile
        built = (
            await self._build_profile(profile, options, meter=meter)
            if profile
            else await self._build_root(options, meter=meter)
        )
        result = await built.run(_synthesis_prompt(task, workers), **model_overrides)
        return result.content

    async def _build_root(
        self,
        options: RunOptions,
        *,
        agent_name: str | None = None,
        meter: BudgetMeter | None = None,
    ) -> Agent:
        model_settings = self.config.model(options.model_name)
        child_config = self.config
        if options.system_prompt or options.max_tool_rounds or agent_name:
            child_config = replace(
                self.config,
                agent=replace(
                    self.config.agent,
                    name=agent_name or self.config.agent.name,
                    system_prompt=options.system_prompt or self.config.agent.system_prompt,
                    max_tool_rounds=options.max_tool_rounds or self.config.agent.max_tool_rounds,
                ),
            )
        merged_skills = _merge_unique(child_config.agent.skills, options.extra_skills)
        if merged_skills != child_config.agent.skills:
            child_config = replace(
                child_config,
                agent=replace(child_config.agent, skills=merged_skills),
            )
        built = await build_agent(
            child_config,
            client=self._client(model_settings),
            tracer=self.tracer,
            skills_dir=self.skills_dir,
            client_factory=self.client_factory,
            mcp_servers=options.extra_mcp_servers,
            tool_names=options.tool_names_override,
        )
        return self._attach_runtime_hooks(built.agent, meter=meter)

    async def _build_profile(
        self,
        profile_name: str | None,
        options: RunOptions,
        *,
        meter: BudgetMeter | None = None,
    ) -> Agent:
        if profile_name is None:
            return await self._build_root(options, meter=meter)
        try:
            profile = self.config.agent.profiles[profile_name]
        except KeyError as exc:
            names = ", ".join(sorted(self.config.agent.profiles))
            raise KeyError(f"Unknown agent profile {profile_name!r}. Available profiles: {names}") from exc
        model_settings = self.config.model(profile.model_name or options.model_name)
        merged_skills = _merge_unique(profile.skills, options.extra_skills)
        merged_mcp = _merge_unique(profile.mcp_servers, options.extra_mcp_servers)
        merged_tool_names = options.tool_names_override if options.tool_names_override is not None else profile.tool_names
        profile_config = replace(
            self.config,
            agent=replace(
                self.config.agent,
                name=profile.name,
                default_model=model_settings.name,
                system_prompt=options.system_prompt or profile.system_prompt or self.config.agent.system_prompt,
                max_tool_rounds=profile.max_tool_rounds or options.max_tool_rounds or self.config.agent.max_tool_rounds,
                skills=merged_skills,
            ),
        )
        built = await build_agent(
            profile_config,
            client=self._client(model_settings),
            tracer=self.tracer,
            skills_dir=self.skills_dir,
            client_factory=self.client_factory,
            skills=merged_skills,
            mcp_servers=merged_mcp,
            tool_names=merged_tool_names,
            enable_team_tools=False,
            depth=self.config.agent.subagents.max_depth,
        )
        return self._attach_runtime_hooks(built.agent, meter=meter)

    def _attach_runtime_hooks(
        self,
        agent: Agent,
        *,
        meter: BudgetMeter | None,
    ) -> Agent:
        if meter is not None:
            agent.budget = meter
        if self.config.context.enabled:
            estimator = TokenEstimator(
                tokenizer=self.config.context.tokenizer,
                hash_components=self.config.context.cache.hash_components,
            )
            agent.message_transformer = ContextManager(
                settings=self.config.context,
                estimator=estimator,
            )
        return agent

    def _build_budget(self, options: RunOptions) -> BudgetMeter | None:
        pricing = dict(options.pricing or {})
        for model in self.config.models.values():
            if model.pricing is not None:
                pricing.setdefault(model.model, model.pricing)
                pricing.setdefault(model.name, model.pricing)
                continue
            # Fallback to bundled catalog when no inline pricing is present.
            if self.catalog is not None:
                cat = self.catalog.pricing_for(model.model, provider=model.provider)
                if cat is not None:
                    pricing.setdefault(model.model, cat)
                    pricing.setdefault(model.name, cat)
        if not any(
            cap is not None
            for cap in (
                options.max_input_tokens,
                options.max_output_tokens,
                options.max_total_tokens,
                options.max_cost_usd,
            )
        ) and not pricing:
            return None
        return BudgetMeter.from_options(
            max_input_tokens=options.max_input_tokens,
            max_output_tokens=options.max_output_tokens,
            max_total_tokens=options.max_total_tokens,
            max_cost_usd=options.max_cost_usd,
            on_exceeded=options.on_budget_exceeded,
            pricing=pricing,
        )

    async def _session(self, agent: Agent, options: RunOptions) -> AgentSession:
        if self.store is None:
            raise RuntimeError("AgentRuntime was created without a session store.")
        if options.session_id:
            return await AgentSession.resume(
                agent=agent,
                store=self.store,
                session_id=options.session_id,
                context_settings=self.config.context,
            )
        return await AgentSession.create(
            agent=agent,
            store=self.store,
            name=options.session_name or agent.name,
            model_name=options.model_name or self.config.model().name,
            context_settings=self.config.context,
            metadata=options.metadata,
        )

    async def _record_routed_session(
        self,
        task: str,
        content: str,
        plan: RoutePlan,
        workers: list[WorkerResult],
        options: RunOptions,
    ) -> AgentSession:
        session = await self._session(await self._build_root(options), options)
        if self.store is None:
            raise RuntimeError("AgentRuntime was created without a session store.")
        await self.store.append_message(
            MessageRecord.from_message(session.session_id, {"role": "user", "content": task}, source="user")
        )
        await self.store.append_message(
            MessageRecord.from_message(session.session_id, {"role": "assistant", "content": content}, source="agent")
        )
        await self.store.append(
            session.session_id,
            "runtime.route",
            {
                "plan": plan.to_dict(),
                "workers": [worker.to_dict() for worker in workers],
                "content": content,
            },
        )
        return session

    def _client(self, model_settings: ModelSettings) -> AnyLLMClient:
        if self.client_factory is not None:
            return self.client_factory(model_settings, self.tracer)
        return AnyLLMClient(model_settings, tracer=self.tracer)

    def _trace_file(self) -> Path | None:
        if not self.config.observability.enabled:
            return None
        return self.config.observability.resolve_directory(self.config.repo_path) / self.config.observability.file_name

    async def stream_task(
        self,
        task: str,
        *,
        options: RunOptions | None = None,
        **model_overrides: Any,
    ) -> AsyncIterator["RuntimeStreamEvent"]:
        """Stream a task end-to-end.

        Currently streams the model output for single-mode routes. Other routes
        fall through to `run_task` and emit one `RuntimeFinal` event at the end.
        Multi-worker streaming is intentionally deferred: it would require
        coordinated event multiplexing that has no clear default UX.
        """

        active_options = options or RunOptions()
        plan = self.plan(task, active_options)
        _check_budget(plan)
        yield RuntimeStreamEvent(kind="route", plan=plan)
        meter = self._build_budget(active_options)
        if plan.mode != "single":
            result = await self.run_task(task, options=options, **model_overrides)
            yield RuntimeStreamEvent(kind="final", content=result.content, cost=result.cost)
            return
        agent = await self._build_root(active_options, meter=meter)
        active_overrides = _with_stream_usage(model_overrides) if meter is not None else model_overrides
        chunks: list[str] = []
        stream = (
            (await self._session(agent, active_options)).stream(task, **active_overrides)
            if active_options.use_session and self.store is not None
            else agent.stream(task, **active_overrides)
        )
        async for event in stream:
            if not event.text:
                continue
            chunks.append(event.text)
            yield RuntimeStreamEvent(kind="token", text=event.text)
        yield RuntimeStreamEvent(
            kind="final",
            content="".join(chunks),
            cost=_finalize_cost(meter),
        )


async def ask(
    question: str,
    *,
    config: AppConfig | None = None,
    options: RunOptions | None = None,
    tracer: TraceManager | None = None,
    client_factory: ClientFactory | None = None,
    **model_overrides: Any,
) -> str:
    """One-shot helper that resolves the runtime automatically.

    When `config`, `tracer`, and `client_factory` are all omitted, the call
    reuses a process-wide `Hajimi.default()` runtime built from environment
    variables. Otherwise it constructs a one-off `AgentRuntime` from the
    provided pieces.
    """

    if config is None and tracer is None and client_factory is None:
        runtime = await Hajimi.default()
    else:
        active_config = config if config is not None else await load_config()
        runtime = await AgentRuntime.from_config(
            active_config,
            tracer=tracer,
            client_factory=client_factory,
        )
    return (await runtime.run_task(question, options=options, **model_overrides)).content


class Hajimi:
    """Process-wide one-call facade.

    Calling `Hajimi.default()` lazily builds an `AgentRuntime` from
    `load_config()` (env-only when no TOML is present). Subsequent calls return
    the cached runtime. Useful for scripts and notebooks that only set
    `OPENAI_API_KEY` (or another provider key) and want
    `await Hajimi.ask("...")` to just work.
    """

    _runtime: AgentRuntime | None = None
    _lock: anyio.Lock | None = None

    @classmethod
    async def default(
        cls,
        *,
        config_path: str | Path | None = None,
    ) -> AgentRuntime:
        if cls._runtime is not None:
            return cls._runtime
        if cls._lock is None:
            cls._lock = anyio.Lock()
        async with cls._lock:
            if cls._runtime is None:
                config = await load_config(config_path)
                cls._runtime = await AgentRuntime.from_config(config)
        return cls._runtime

    @classmethod
    async def ask(cls, question: str, **kwargs: Any) -> str:
        runtime = await cls.default()
        result = await runtime.run_task(question, **kwargs)
        return result.content

    @classmethod
    def reset(cls) -> None:
        cls._runtime = None
        cls._lock = None


def _merge_unique(base: list[str], extra: list[str] | None) -> list[str]:
    if not extra:
        return list(base)
    seen: set[str] = set()
    merged: list[str] = []
    for value in (*base, *extra):
        if value in seen:
            continue
        seen.add(value)
        merged.append(value)
    return merged


def _finalize_cost(meter: BudgetMeter | None) -> CostReport | None:
    if meter is None:
        return None
    return meter.report


def _with_stream_usage(model_overrides: dict[str, Any]) -> dict[str, Any]:
    options = dict(model_overrides.get("stream_options") or {})
    options["include_usage"] = True
    return {**model_overrides, "stream_options": options}


def _is_simple_task(task: str, max_words: int, max_tool_markers: int) -> bool:
    words = task.split()
    markers = sum(task.lower().count(marker) for marker in ("http://", "https://", "\n", "```"))
    return len(words) <= max_words and markers <= max_tool_markers


def _profiles(requested: list[str] | None, defaults: list[str]) -> list[str]:
    if requested is not None:
        return list(requested)
    return list(defaults)


def _default_subagent_profiles(requested: list[str], configured: dict[str, Any]) -> list[str]:
    if requested:
        return requested
    if configured:
        return list(configured)
    raise ValueError("Subagent mode requires at least one configured or requested profile.")


def _bounded_replicas(value: int, max_parallel: int) -> int:
    return max(1, min(value, max(1, max_parallel)))


def _check_budget(plan: RoutePlan) -> None:
    if plan.max_budget_tokens is not None and plan.estimated_input_tokens > plan.max_budget_tokens:
        raise RuntimeError(
            "Estimated input tokens "
            f"{plan.estimated_input_tokens} exceed max_budget_tokens={plan.max_budget_tokens}."
        )


def _profile_prompt(task: str, profile: str) -> str:
    return (
        f"Task for profile {profile}:\n"
        f"{task}\n\n"
        "Do not call tools or spawn other agents. "
        "Return the useful result for your specialty. Keep assumptions explicit."
    )


def _replica_prompt(task: str, index: int) -> str:
    return (
        f"Replica {index} independent attempt:\n"
        f"{task}\n\n"
        "Solve independently and return a concise answer with key reasoning."
    )


def _synthesis_prompt(task: str, workers: list[WorkerResult]) -> str:
    worker_text = "\n\n".join(
        f"## {worker.name}\n{worker.content}" for worker in workers
    )
    return (
        "Synthesize the worker outputs into one final answer.\n\n"
        f"Original task:\n{task}\n\n"
        f"Worker outputs:\n{worker_text}\n\n"
        "Resolve disagreements, keep the strongest evidence, and return only the final answer."
    )
