"""Sandbox environment protocol shared by workspace tools and adapters."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Protocol

type SandboxPathType = Literal["file", "directory", "other"]


@dataclass(frozen=True, slots=True)
class SandboxDirectoryEntry:
    path: str
    type: SandboxPathType

    def to_dict(self) -> dict[str, str]:
        return {"path": self.path, "type": self.type}


@dataclass(frozen=True, slots=True)
class SandboxPathStat:
    path: str
    type: SandboxPathType


@dataclass(frozen=True, slots=True)
class SandboxExecResult:
    exit_code: int | None
    stdout: str
    stderr: str
    timed_out: bool = False


class SandboxEnvironment(Protocol):
    """Minimal async environment API behind model-visible workspace tools."""

    async def stat(self, path: str) -> SandboxPathStat:
        """Return normalized path metadata inside the sandbox."""

    async def read_text(self, path: str) -> str:
        """Read a UTF-8 text file inside the sandbox."""

    async def read_bytes(self, path: str) -> bytes:
        """Read raw bytes from a file inside the sandbox."""

    async def write_text(self, path: str, content: str) -> None:
        """Write a UTF-8 text file inside the sandbox, creating parents when needed."""

    async def write_bytes(self, path: str, content: bytes) -> None:
        """Write raw bytes to a file inside the sandbox, creating parents when needed."""

    async def list_dir(self, path: str) -> list[SandboxDirectoryEntry]:
        """List direct directory entries inside the sandbox."""

    async def iter_files(self, path: str) -> list[str]:
        """Return sandbox-relative file paths under a file or directory."""

    async def exec(
        self,
        command: str,
        timeout_seconds: float,
        cwd: str | None = None,
    ) -> SandboxExecResult:
        """Run a command in the sandbox."""
