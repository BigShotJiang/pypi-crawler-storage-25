"""E2B-backed sandbox adapter."""

from __future__ import annotations

import posixpath
import shlex
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import PurePosixPath
from typing import Any

import anyio

from hajimi.sandbox.types import (
    SandboxDirectoryEntry,
    SandboxExecResult,
    SandboxPathStat,
    SandboxPathType,
)


@dataclass(frozen=True, slots=True)
class E2BSandboxEnvironment:
    """Lazy E2B adapter matching the Hajimi sandbox protocol."""

    root: str = "/home/user"
    sandbox_id: str | None = None
    template: str | None = None
    timeout: int | None = 300
    allow_internet_access: bool = True
    sandbox_factory: Callable[[], Any] | None = None
    _sandbox_instance: Any = field(default=None, init=False, repr=False, compare=False)

    async def stat(self, path: str) -> SandboxPathStat:
        target = self._resolve(path)
        info = await anyio.to_thread.run_sync(lambda: self._sandbox().files.get_info(target))
        return SandboxPathStat(path=self._relative(target), type=_e2b_path_type(info))

    async def read_text(self, path: str) -> str:
        target = self._resolve(path)
        return await anyio.to_thread.run_sync(lambda: self._sandbox().files.read(target))

    async def read_bytes(self, path: str) -> bytes:
        target = self._resolve(path)
        content = await anyio.to_thread.run_sync(lambda: self._sandbox().files.read(target))
        if isinstance(content, bytes):
            return content
        return str(content).encode("utf-8")

    async def write_text(self, path: str, content: str) -> None:
        target = self._resolve(path)
        await anyio.to_thread.run_sync(lambda: self._sandbox().files.write(target, content))

    async def write_bytes(self, path: str, content: bytes) -> None:
        target = self._resolve(path)
        await anyio.to_thread.run_sync(lambda: self._sandbox().files.write(target, content))

    async def list_dir(self, path: str) -> list[SandboxDirectoryEntry]:
        target = self._resolve(path)
        entries = await anyio.to_thread.run_sync(lambda: self._sandbox().files.list(target))
        return sorted(
            [
                SandboxDirectoryEntry(path=_entry_name(entry), type=_e2b_path_type(entry))
                for entry in entries
            ],
            key=lambda entry: entry.path,
        )

    async def iter_files(self, path: str) -> list[str]:
        target = self._resolve(path)
        info = await anyio.to_thread.run_sync(lambda: self._sandbox().files.get_info(target))
        if _e2b_path_type(info) == "file":
            return [self._relative(target)]
        files: list[str] = []
        await self._collect_files(target, files)
        return sorted(files)

    async def exec(
        self,
        command: str,
        timeout_seconds: float,
        cwd: str | None = None,
    ) -> SandboxExecResult:
        argv = shlex.split(command)
        if not argv:
            raise ValueError("command must not be empty.")
        working_dir = self._resolve(cwd) if cwd else self.root
        result = await anyio.to_thread.run_sync(
            lambda: self._sandbox().commands.run(
                command,
                cwd=working_dir,
                timeout=int(max(1.0, timeout_seconds)),
            )
        )
        return SandboxExecResult(
            exit_code=_read_int(result, "exit_code", "exitCode") or 0,
            stdout=str(_read_attr(result, "stdout") or ""),
            stderr=str(_read_attr(result, "stderr") or ""),
        )

    async def _collect_files(self, path: str, files: list[str]) -> None:
        entries = await anyio.to_thread.run_sync(lambda: self._sandbox().files.list(path))
        for entry in entries:
            entry_path = _entry_path(path, entry)
            kind = _e2b_path_type(entry)
            if kind == "file":
                files.append(self._relative(entry_path))
            elif kind == "directory":
                await self._collect_files(entry_path, files)

    def _sandbox(self) -> Any:
        if self._sandbox_instance is not None:
            return self._sandbox_instance
        if self.sandbox_factory is not None:
            sandbox = self.sandbox_factory()
            object.__setattr__(self, "_sandbox_instance", sandbox)
            return sandbox
        try:
            from e2b import Sandbox
        except ImportError as exc:
            raise RuntimeError(
                "E2B sandbox provider requires the optional 'e2b' package. "
                "Install it with `uv sync --extra sandbox-e2b` or set "
                "sandbox_provider = \"local\"."
            ) from exc
        if self.sandbox_id:
            sandbox = Sandbox.connect(self.sandbox_id, timeout=self.timeout)
            object.__setattr__(self, "_sandbox_instance", sandbox)
            return sandbox
        kwargs: dict[str, Any] = {
            "timeout": self.timeout,
            "allow_internet_access": self.allow_internet_access,
        }
        if self.template:
            kwargs["template"] = self.template
        sandbox = Sandbox.create(**{key: value for key, value in kwargs.items() if value is not None})
        object.__setattr__(self, "_sandbox_instance", sandbox)
        return sandbox

    def _resolve(self, path: str) -> str:
        root = PurePosixPath(self.root)
        target = PurePosixPath(path)
        if not target.is_absolute():
            target = root / target
        normalized = PurePosixPath(posixpath.normpath(target.as_posix()))
        try:
            normalized.relative_to(root)
        except ValueError as exc:
            raise ValueError(f"Path {path!r} escapes sandbox root.") from exc
        return normalized.as_posix()

    def _relative(self, path: str) -> str:
        return PurePosixPath(path).relative_to(PurePosixPath(self.root)).as_posix()


def create_e2b_sandbox(
    *,
    root: str = "/home/user",
    sandbox_id: str | None = None,
    template: str | None = None,
    timeout: int | None = 300,
    allow_internet_access: bool = True,
) -> E2BSandboxEnvironment:
    return E2BSandboxEnvironment(
        root=root,
        sandbox_id=sandbox_id,
        template=template,
        timeout=timeout,
        allow_internet_access=allow_internet_access,
    )


def _e2b_path_type(value: Any) -> SandboxPathType:
    kind = str(_read_attr(value, "type") or "").lower()
    if kind in {"file", "directory"}:
        return kind
    if bool(_read_attr(value, "is_dir", "isDirectory")):
        return "directory"
    if bool(_read_attr(value, "is_file", "isFile")):
        return "file"
    return "other"


def _entry_name(value: Any) -> str:
    name = _read_attr(value, "name")
    if name:
        return str(name)
    path = _read_attr(value, "path")
    return PurePosixPath(str(path)).name


def _entry_path(parent: str, value: Any) -> str:
    path = _read_attr(value, "path")
    if path:
        raw = str(path)
        if raw.startswith("/"):
            return raw
    return (PurePosixPath(parent) / _entry_name(value)).as_posix()


def _read_int(value: Any, *names: str) -> int | None:
    raw = _read_attr(value, *names)
    return int(raw) if raw is not None else None


def _read_attr(value: Any, *names: str) -> Any:
    for name in names:
        if isinstance(value, dict) and name in value:
            return value[name]
        if hasattr(value, name):
            return getattr(value, name)
    return None
