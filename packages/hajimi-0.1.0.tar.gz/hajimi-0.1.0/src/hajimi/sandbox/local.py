"""Repo-root scoped local sandbox implementation."""

from __future__ import annotations

import shlex
from dataclasses import dataclass
from pathlib import Path

import anyio

from hajimi.sandbox.types import (
    SandboxDirectoryEntry,
    SandboxExecResult,
    SandboxPathStat,
    SandboxPathType,
)


@dataclass(frozen=True, slots=True)
class LocalSandboxEnvironment:
    """Local filesystem/process adapter with paths contained under one root."""

    root: Path
    allowed_shell_commands: tuple[str, ...] = ()

    async def stat(self, path: str) -> SandboxPathStat:
        target = self._resolve(path)
        return SandboxPathStat(path=self._relative(target), type=_path_type(target))

    async def read_text(self, path: str) -> str:
        target = self._resolve(path)
        if target.is_dir():
            raise IsADirectoryError(path)
        return await anyio.Path(target).read_text(encoding="utf-8")

    async def read_bytes(self, path: str) -> bytes:
        target = self._resolve(path)
        if target.is_dir():
            raise IsADirectoryError(path)
        return await anyio.Path(target).read_bytes()

    async def write_text(self, path: str, content: str) -> None:
        target = self._resolve(path)
        await anyio.Path(target.parent).mkdir(parents=True, exist_ok=True)
        await anyio.Path(target).write_text(content, encoding="utf-8")

    async def write_bytes(self, path: str, content: bytes) -> None:
        target = self._resolve(path)
        await anyio.Path(target.parent).mkdir(parents=True, exist_ok=True)
        await anyio.Path(target).write_bytes(content)

    async def list_dir(self, path: str) -> list[SandboxDirectoryEntry]:
        target = self._resolve(path)
        entries: list[SandboxDirectoryEntry] = []
        async for item in anyio.Path(target).iterdir():
            entry_path = Path(item).resolve()
            if self._is_under_root(entry_path):
                entries.append(
                    SandboxDirectoryEntry(
                        path=entry_path.name,
                        type=_path_type(entry_path),
                    )
                )
        return sorted(entries, key=lambda entry: entry.path)

    async def iter_files(self, path: str) -> list[str]:
        target = self._resolve(path)
        if target.is_file():
            return [self._relative(target)]
        paths: list[str] = []
        async for item in anyio.Path(target).rglob("*"):
            file_path = Path(item).resolve()
            if self._is_under_root(file_path) and file_path.is_file():
                paths.append(self._relative(file_path))
        return sorted(paths)

    async def exec(
        self,
        command: str,
        timeout_seconds: float,
        cwd: str | None = None,
    ) -> SandboxExecResult:
        argv = shlex.split(command)
        if not argv:
            raise ValueError("command must not be empty.")
        allowed = set(self.allowed_shell_commands)
        if allowed and argv[0] not in allowed:
            raise PermissionError(f"Command {argv[0]!r} is not allow-listed.")
        working_dir = self._resolve(cwd or ".")
        if not working_dir.is_dir():
            raise NotADirectoryError(cwd or ".")
        with anyio.move_on_after(max(0.1, timeout_seconds)) as scope:
            result = await anyio.run_process(argv, cwd=working_dir, check=False)
        if scope.cancel_called:
            return SandboxExecResult(
                exit_code=None,
                stdout="",
                stderr=f"Command timed out after {timeout_seconds:.1f}s.",
                timed_out=True,
            )
        return SandboxExecResult(
            exit_code=result.returncode,
            stdout=result.stdout.decode("utf-8", errors="replace"),
            stderr=result.stderr.decode("utf-8", errors="replace"),
        )

    def _resolve(self, path: str) -> Path:
        target = (self.root / path).resolve()
        if not self._is_under_root(target):
            raise ValueError(f"Path {path!r} escapes sandbox root.")
        return target

    def _relative(self, path: Path) -> str:
        return path.resolve().relative_to(self.root).as_posix()

    def _is_under_root(self, path: Path) -> bool:
        return path == self.root or self.root in path.parents


def create_local_sandbox(
    repo_path: str | Path,
    *,
    root: Path | None = None,
    allowed_shell_commands: list[str] | tuple[str, ...] = (),
) -> LocalSandboxEnvironment:
    repo_root = Path(repo_path).expanduser().resolve()
    sandbox_root = repo_root if root is None else (repo_root / root).resolve()
    if sandbox_root != repo_root and repo_root not in sandbox_root.parents:
        raise ValueError("sandbox root must stay under repo_path.")
    return LocalSandboxEnvironment(
        root=sandbox_root,
        allowed_shell_commands=tuple(allowed_shell_commands),
    )


def _path_type(path: Path) -> SandboxPathType:
    if path.is_dir():
        return "directory"
    if path.is_file():
        return "file"
    return "other"
