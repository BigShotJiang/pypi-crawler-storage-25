"""Default names and descriptions for built-in LLM tools."""

SKILL_TOOL_NAME = "load_skill"
SKILL_TOOL_DESCRIPTION = (
    "Load a named skill when the task matches the skill catalog; returns instructions and tools."
)
SKILL_SCRIPT_TOOL_NAME = "run_skill_script"
SKILL_SCRIPT_TOOL_DESCRIPTION = (
    "Run a script bundled with an activated skill inside the configured sandbox."
)

TOOL_SEARCH_NAME = "find_tools"
TOOL_SEARCH_DESCRIPTION = (
    "Search hidden skill or MCP tools by task text; load matches for the next round."
)

SUBAGENT_TOOL_NAME = "delegate"
SUBAGENT_TOOL_DESCRIPTION = "Run a focused one-shot child agent for delegated work."

TEAM_SPAWN_TOOL_NAME = "team_spawn"
TEAM_SPAWN_TOOL_DESCRIPTION = "Create a persistent teammate and send its first prompt."
TEAM_SEND_TOOL_NAME = "team_send"
TEAM_SEND_TOOL_DESCRIPTION = "Send one active teammate a message and return its reply."
TEAM_BROADCAST_TOOL_NAME = "team_broadcast"
TEAM_BROADCAST_TOOL_DESCRIPTION = "Send the same message to all active teammates."
TEAM_LIST_TOOL_NAME = "team_list"
TEAM_LIST_TOOL_DESCRIPTION = "List active teammates, status, and message counts."
TEAM_CLOSE_TOOL_NAME = "team_close"
TEAM_CLOSE_TOOL_DESCRIPTION = "Close one active teammate."

WORKSPACE_READ_TOOL_NAME = "read"
WORKSPACE_READ_TOOL_DESCRIPTION = "Read a UTF-8 file or list a directory under the workspace."
WORKSPACE_WRITE_TOOL_NAME = "write"
WORKSPACE_WRITE_TOOL_DESCRIPTION = "Write a UTF-8 file under the workspace when enabled."
WORKSPACE_EDIT_TOOL_NAME = "edit"
WORKSPACE_EDIT_TOOL_DESCRIPTION = "Replace text in a workspace file when enabled."
WORKSPACE_GREP_TOOL_NAME = "grep"
WORKSPACE_GREP_TOOL_DESCRIPTION = "Search workspace files with a regex pattern."
WORKSPACE_GLOB_TOOL_NAME = "glob"
WORKSPACE_GLOB_TOOL_DESCRIPTION = "Find workspace files by glob pattern."
WORKSPACE_BASH_TOOL_NAME = "bash"
WORKSPACE_BASH_TOOL_DESCRIPTION = "Run an allow-listed shell command in the workspace when enabled."
