"""Core agent protocols and result types."""

from __future__ import annotations

import contextlib
from collections.abc import AsyncIterator, Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Protocol

type Message = dict[str, Any]


@dataclass(frozen=True, slots=True)
class ModelResult:
    text: str
    raw: Any


@dataclass(frozen=True, slots=True)
class ModelStreamChunk:
    text: str
    raw: Any


@dataclass(frozen=True, slots=True)
class AgentResult:
    content: str
    messages: list[Message]
    raw: Any


@dataclass(frozen=True, slots=True)
class AgentStreamEvent:
    text: str
    raw: Any


class ModelClient(Protocol):
    async def complete(
        self,
        messages: Sequence[Message],
        *,
        tools: list[dict[str, object]] | None = None,
        **overrides: Any,
    ) -> ModelResult: ...

    def stream_complete(
        self,
        messages: Sequence[Message],
        *,
        tools: list[dict[str, object]] | None = None,
        **overrides: Any,
    ) -> AsyncIterator[ModelStreamChunk]: ...


class TraceSpan(Protocol):
    def set_attribute(self, key: str, value: Any) -> None: ...

    def set_attributes(self, attributes: Mapping[str, Any]) -> None: ...

    def add_event(self, name: str, attributes: Mapping[str, Any] | None = None) -> None: ...


class Tracer(Protocol):
    include_content: bool

    def span(
        self,
        name: str,
        *,
        kind: str = "internal",
        attributes: Mapping[str, Any] | None = None,
    ) -> AsyncIterator[TraceSpan]: ...

    def content(self, value: Any) -> str: ...


class Budget(Protocol):
    report: Any

    def is_active(self) -> bool: ...

    async def record_raw(self, *, model: str, raw: Any) -> None: ...

    async def record_estimate(self, *, model: str, input_tokens: int, output_tokens: int) -> None: ...

    def enforce(self) -> bool: ...


class MessageTransformer(Protocol):
    async def compact_messages(self, messages: list[Message]) -> list[Message]: ...


class NoOpTraceSpan:
    def set_attribute(self, key: str, value: Any) -> None:
        return None

    def set_attributes(self, attributes: Mapping[str, Any]) -> None:
        return None

    def add_event(self, name: str, attributes: Mapping[str, Any] | None = None) -> None:
        return None


class NoOpTracer:
    include_content = False

    @contextlib.asynccontextmanager
    async def span(
        self,
        name: str,
        *,
        kind: str = "internal",
        attributes: Mapping[str, Any] | None = None,
    ) -> AsyncIterator[TraceSpan]:
        yield NoOpTraceSpan()

    def content(self, value: Any) -> str:
        return "" if value is None else str(value)
