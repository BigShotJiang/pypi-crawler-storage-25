"""Agent-as-tool support."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import asdict, dataclass, replace
from typing import Any

from hajimi.config import AgentProfileSettings, AppConfig, ModelSettings
from hajimi.llm import AnyLLMClient
from hajimi.observability import TraceManager
from hajimi.tool import Tool

type ClientFactory = Callable[[ModelSettings, TraceManager], AnyLLMClient]


@dataclass(frozen=True, slots=True)
class SubAgentRequest:
    name: str
    task: str
    profile: str | None = None
    model_name: str | None = None
    system_prompt: str | None = None
    max_tool_rounds: int | None = None
    skills: list[str] | None = None
    mcp_servers: list[str] | None = None
    tool_names: list[str] | None = None


@dataclass(frozen=True, slots=True)
class SubAgentResponse:
    name: str
    model_name: str
    depth: int
    content: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def create_subagent_tool(
    config: AppConfig,
    *,
    tracer: TraceManager,
    depth: int,
    skills_dir: str = "skills",
    client_factory: ClientFactory | None = None,
) -> Tool:
    settings = config.agent.subagents
    factory = client_factory or _default_client_factory

    async def handler(
        name: str,
        task: str,
        profile: str | None = None,
        model_name: str | None = None,
        system_prompt: str | None = None,
        max_tool_rounds: int | None = None,
        skills: list[str] | None = None,
        mcp_servers: list[str] | None = None,
        tool_names: list[str] | None = None,
    ) -> dict[str, Any]:
        request = SubAgentRequest(
            name=name,
            task=task,
            profile=profile,
            model_name=model_name,
            system_prompt=system_prompt,
            max_tool_rounds=max_tool_rounds,
            skills=skills,
            mcp_servers=mcp_servers,
            tool_names=tool_names,
        )
        return (
            await _run_subagent(
                config,
                request=request,
                tracer=tracer,
                depth=depth,
                skills_dir=skills_dir,
                client_factory=factory,
            )
        ).to_dict()

    return Tool(
        name=settings.tool_name,
        description=settings.tool_description,
        parameters={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Child agent name.",
                },
                "task": {
                    "type": "string",
                    "description": "Delegated work to complete.",
                },
                "profile": {
                    "type": "string",
                    "description": "Configured agent profile.",
                },
                "model_name": {
                    "type": "string",
                    "description": "Configured model key.",
                },
                "system_prompt": {
                    "type": "string",
                    "description": "System prompt override.",
                },
                "max_tool_rounds": {
                    "type": "integer",
                    "description": "Tool-call round limit.",
                },
                "skills": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Skill names available to the child.",
                },
                "mcp_servers": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "MCP servers available to the child.",
                },
                "tool_names": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Allowed tool names for the child.",
                },
            },
            "required": ["name", "task"],
        },
        handler=handler,
    )


async def _run_subagent(
    config: AppConfig,
    *,
    request: SubAgentRequest,
    tracer: TraceManager,
    depth: int,
    skills_dir: str,
    client_factory: ClientFactory,
) -> SubAgentResponse:
    settings = config.agent.subagents
    next_depth = depth + 1
    if next_depth > settings.max_depth:
        raise RuntimeError(
            f"Sub-agent depth {next_depth} exceeds max_depth={settings.max_depth}."
        )

    profile = _resolve_profile(config, request)
    model_settings = config.model(request.model_name or (profile.model_name if profile else None))
    child_skills = _select_list(request.skills, profile.skills if profile else None, config.agent.skills) or []
    child_mcp_servers = _select_list(request.mcp_servers, profile.mcp_servers if profile else None, None)
    child_tool_names = _select_list(request.tool_names, profile.tool_names if profile else None, None)
    child_max_tool_rounds = (
        request.max_tool_rounds
        or (profile.max_tool_rounds if profile else None)
        or settings.max_tool_rounds
        or config.agent.max_tool_rounds
    )
    child_system_prompt = (
        request.system_prompt
        or (profile.system_prompt if profile else None)
        or _default_subagent_prompt(request.name)
    )
    async with tracer.span(
        "agent.subagent",
        kind="agent",
        attributes={
            "agent.subagent.name": request.name,
            "agent.subagent.depth": next_depth,
            "agent.subagent.model_name": model_settings.name,
            "agent.subagent.parent": config.agent.name,
            "agent.subagent.profile": request.profile,
            "agent.subagent.task.length": len(request.task),
            "agent.subagent.skills": child_skills,
            "agent.subagent.mcp_servers": child_mcp_servers or [],
            "agent.subagent.tool_names": child_tool_names or [],
        },
    ) as span:
        span.add_event(
            "agent.subagent.create",
            {
                "name": request.name,
                "model_name": model_settings.name,
                "depth": next_depth,
            },
        )
        try:
            child_config = replace(
                config,
                agent=replace(
                    config.agent,
                    name=request.name,
                    default_model=model_settings.name,
                    system_prompt=child_system_prompt,
                    max_tool_rounds=child_max_tool_rounds,
                    skills=child_skills,
                ),
            )
            child_client = client_factory(model_settings, tracer)

            from hajimi.core.builder import build_agent

            built = await build_agent(
                child_config,
                client=child_client,
                tracer=tracer,
                skills_dir=skills_dir,
                depth=next_depth,
                client_factory=client_factory,
                skills=child_skills,
                mcp_servers=child_mcp_servers,
                tool_names=child_tool_names,
            )
            result = await built.agent.run(request.task)
            span.set_attribute("agent.subagent.output.length", len(result.content))
            if tracer.include_content:
                span.add_event("agent.subagent.output", {"content": tracer.content(result.content)})
            return SubAgentResponse(
                name=request.name,
                model_name=model_settings.name,
                depth=next_depth,
                content=result.content,
            )
        finally:
            span.add_event(
                "agent.subagent.destroy",
                {
                    "name": request.name,
                    "depth": next_depth,
                },
            )


def _default_client_factory(settings: ModelSettings, tracer: TraceManager) -> AnyLLMClient:
    return AnyLLMClient(settings, tracer=tracer)


def _default_subagent_prompt(name: str) -> str:
    return (
        f"You are child agent {name}. Solve the delegated task independently, "
        "return only the useful result, and keep the response concise."
    )


def _resolve_profile(config: AppConfig, request: SubAgentRequest) -> AgentProfileSettings | None:
    if request.profile is None:
        return None
    try:
        return config.agent.profiles[request.profile]
    except KeyError as exc:
        names = ", ".join(sorted(config.agent.profiles))
        raise KeyError(f"Unknown agent profile {request.profile!r}. Available profiles: {names}") from exc


def _select_list(
    request_value: list[str] | None,
    profile_value: list[str] | None,
    default_value: list[str] | None,
) -> list[str] | None:
    if request_value is not None:
        return list(request_value)
    if profile_value is not None:
        return list(profile_value)
    if default_value is not None:
        return list(default_value)
    return None
