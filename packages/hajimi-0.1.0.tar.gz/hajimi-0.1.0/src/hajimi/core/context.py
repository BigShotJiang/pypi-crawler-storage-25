"""Agent context object used by the core execution loop."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from hajimi.core.messages import Message, ToolCallPart, ensure_message, to_chat_messages
from hajimi.core.registry import ToolRegistry
from hajimi.core.tools import BoundToolCall, ToolCall
from hajimi.core.types import ModelClient


@dataclass(slots=True)
class Context:
    """Everything core needs to send the next model turn."""

    messages: list[Message]
    tools: ToolRegistry = field(default_factory=ToolRegistry)
    client: ModelClient | None = field(default=None, repr=False)
    output_type: type[Any] | None = None
    params: Any = None
    state: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_prompt(
        cls,
        prompt: str | Mapping[str, Any] | Message | Sequence[Mapping[str, Any] | Message],
        *,
        tools: ToolRegistry | None = None,
        system_prompt: str | None = None,
    ) -> "Context":
        messages: list[Message]
        if isinstance(prompt, str):
            messages = [ensure_message(prompt)]
        elif isinstance(prompt, Message) or isinstance(prompt, Mapping):
            messages = [ensure_message(prompt)]
        else:
            messages = [ensure_message(item) for item in prompt]
        if system_prompt and not (messages and messages[0].role == "system"):
            messages.insert(0, Message.text_message("system", system_prompt))
        return cls(messages=messages, tools=tools or ToolRegistry())

    def keep_running(self) -> bool:
        if self.state.get("stopped"):
            return False
        if not self.messages:
            return False
        last = self.messages[-1]
        return last.replay or last.role != "assistant" or bool(last.tool_calls)

    def stop(self) -> None:
        self.state["stopped"] = True

    def add(self, message: Message | Mapping[str, Any] | Sequence[Message | Mapping[str, Any]] | None) -> None:
        if message is None:
            return
        if isinstance(message, Message) or isinstance(message, Mapping):
            messages = [ensure_message(message)]
        else:
            messages = [ensure_message(item) for item in message]
        for item in messages:
            if not item.replay:
                self.messages.append(item)

    def model_messages(self) -> list[dict[str, Any]]:
        return to_chat_messages(self.messages)

    def resolve(self, tool_call: ToolCallPart) -> BoundToolCall:
        call = ToolCall(
            id=tool_call.tool_call_id,
            name=tool_call.tool_name,
            arguments_text=tool_call.tool_args,
        )
        return BoundToolCall(call=call, tool=self.tools.get(call.name))
