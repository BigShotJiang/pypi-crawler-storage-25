"""Tool abstractions for the reusable core."""

from __future__ import annotations

import json
import inspect
from collections import deque
from collections.abc import AsyncGenerator, AsyncIterator, Callable, Mapping
from dataclasses import dataclass
from typing import Any

import anyio
from anyio import WouldBlock

from hajimi.core import events
from hajimi.core.messages import Message, ToolResultPart, tool_message


@dataclass(frozen=True, slots=True)
class Tool:
    name: str
    description: str
    parameters: dict[str, object]
    handler: Callable[..., object]
    require_approval: bool = False

    @property
    def openai_schema(self) -> dict[str, object]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }

    async def invoke(self, arguments: Mapping[str, Any]) -> Any:
        if inspect.iscoroutinefunction(self.handler):
            return await self.handler(**arguments)
        return await anyio.to_thread.run_sync(lambda: self.handler(**arguments))


@dataclass(frozen=True, slots=True)
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any] | None = None
    arguments_text: str | None = None

    @property
    def kwargs(self) -> dict[str, Any]:
        if self.arguments is not None:
            return dict(self.arguments)
        if not self.arguments_text:
            return {}
        return json.loads(self.arguments_text)


@dataclass(frozen=True, slots=True)
class ToolResult:
    call_id: str
    name: str
    content: str
    raw: Any = None
    is_error: bool = False
    exception: BaseException | None = None

    def part(self) -> ToolResultPart:
        return ToolResultPart(
            tool_call_id=self.call_id,
            tool_name=self.name,
            result=self.content,
            is_error=self.is_error,
        )

    def message(self) -> Message:
        return tool_message(self.part())


class BoundToolCall:
    def __init__(self, *, call: ToolCall, tool: Tool) -> None:
        self.call = call
        self.tool = tool

    @property
    def id(self) -> str:
        return self.call.id

    @property
    def name(self) -> str:
        return self.call.name

    @property
    def kwargs(self) -> dict[str, Any]:
        return self.call.kwargs

    async def __call__(self) -> events.ToolCallResult:
        try:
            result = await self.tool.invoke(self.kwargs)
        except BaseException as exc:
            result_text = f"{type(exc).__name__}: {exc}"
            part = ToolResultPart(
                tool_call_id=self.id,
                tool_name=self.name,
                result=result_text,
                is_error=True,
            )
            return events.ToolCallResult(message=tool_message(part), results=[part], exception=exc)
        text = _stringify_result(result)
        part = ToolResultPart(tool_call_id=self.id, tool_name=self.name, result=text)
        part.set_model_input(text)
        return events.ToolCallResult(message=tool_message(part), results=[part])


class ToolRunner:
    """Concurrent tool runner that yields tool-result events."""

    def __init__(self) -> None:
        self._send, self._receive = anyio.create_memory_object_stream[None](100)
        self._active = 0
        self._task_group: anyio.abc.TaskGroup | None = None
        self._results: list[events.ToolCallResult] = []
        self._pending: deque[events.ToolCallResult] = deque()

    async def __aenter__(self) -> "ToolRunner":
        self._task_group = await anyio.create_task_group().__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> None:
        if self._task_group is not None:
            await self._task_group.__aexit__(*args)
        await self._notify()
        await self._send.aclose()

    def schedule(self, call: BoundToolCall) -> None:
        if self._task_group is None:
            raise RuntimeError("ToolRunner must be entered before scheduling tools.")
        self._active += 1
        self._wakeup()
        self._task_group.start_soon(self._run_one, call)

    async def _run_one(self, call: BoundToolCall) -> None:
        try:
            result = await call()
            self._results.append(result)
            self._pending.append(result)
            await self._notify()
        finally:
            self._active -= 1
            await self._notify()

    def events(self) -> "_ToolRunnerEvents":
        return _ToolRunnerEvents(self)

    async def _iterate(self) -> AsyncGenerator[events.ToolCallResult]:
        while self._pending or self._active:
            while self._pending:
                item = self._pending.popleft()
                yield item
            if not self._active:
                return
            await self._receive.receive()

    def get_tool_message(self) -> Message | None:
        parts = [part for result in self._results for part in result.results]
        return tool_message(*parts) if parts else None

    async def _notify(self) -> None:
        await self._send.send(None)

    def _wakeup(self) -> None:
        try:
            self._send.send_nowait(None)
        except WouldBlock:
            pass


class _ToolRunnerEvents:
    def __init__(self, runner: ToolRunner) -> None:
        self._runner = runner

    def __aiter__(self) -> AsyncIterator[events.ToolCallResult]:
        return self._runner._iterate()


def _stringify_result(value: Any) -> str:
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, default=str)
