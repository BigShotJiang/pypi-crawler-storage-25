"""Async utilities for composing core event sources."""

from __future__ import annotations

from collections.abc import AsyncIterable, AsyncIterator
from dataclasses import dataclass
from typing import Any

import anyio


_EMPTY: Any = object()


@dataclass(slots=True)
class _Item[T]:
    index: int
    value: T | object = _EMPTY
    error: BaseException | None = None


async def merge[T](*aiterables: AsyncIterable[T], restart: bool = True) -> AsyncIterator[T]:
    """Yield items from async iterables as soon as each item is available.

    Restartable iterables, such as ``ToolRunner.events()``, are re-opened
    after another source yields. This supports the custom-loop pattern where
    a model stream emits tool calls and schedules work into a tool runner.
    """

    states: list[dict[str, Any]] = []
    for source in aiterables:
        iterator = source.__aiter__()
        states.append(
            {
                "source": source,
                "iterator": iterator,
                "active": True,
                "restartable": source is not iterator,
            }
        )

    async def pull(index: int, iterator: AsyncIterator[T], send: anyio.abc.ObjectSendStream[_Item[T]]) -> None:
        try:
            item = await iterator.__anext__()
        except StopAsyncIteration:
            await send.send(_Item(index))
        except BaseException as exc:
            await send.send(_Item(index, error=exc))
        else:
            await send.send(_Item(index, value=item))

    send, receive = anyio.create_memory_object_stream[_Item[T]](len(states) or 1)
    async with send, receive, anyio.create_task_group() as task_group:
        active_count = len(states)
        for index, state in enumerate(states):
            task_group.start_soon(pull, index, state["iterator"], send.clone())

        try:
            async for payload in receive:
                current_state = states[payload.index]
                if payload.error is not None:
                    raise payload.error
                if payload.value is _EMPTY:
                    if states[payload.index]["active"]:
                        states[payload.index]["active"] = False
                        active_count -= 1
                    if active_count <= 0:
                        return
                    continue

                yield payload.value

                if restart:
                    for restart_index, restart_state in enumerate(states):
                        if (
                            restart_index == payload.index
                            or restart_state["active"]
                            or not restart_state["restartable"]
                        ):
                            continue
                        iterator = restart_state["source"].__aiter__()
                        restart_state["iterator"] = iterator
                        restart_state["active"] = True
                        active_count += 1
                        task_group.start_soon(pull, restart_index, iterator, send.clone())

                task_group.start_soon(pull, payload.index, current_state["iterator"], send.clone())
        finally:
            task_group.cancel_scope.cancel()
