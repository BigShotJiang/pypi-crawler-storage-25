"""Small callable-to-tool-schema mapper."""

from __future__ import annotations

import inspect
import types
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Literal, get_args, get_origin, get_type_hints, overload

from hajimi.core.tools import Tool


@overload
def tool(func: Callable[..., object], /) -> Tool: ...


@overload
def tool(
    func: None = None,
    /,
    *,
    name: str | None = None,
    description: str | None = None,
    parameters: dict[str, object] | None = None,
) -> Callable[[Callable[..., object]], Tool]: ...


def tool(
    func: Callable[..., object] | None = None,
    /,
    *,
    name: str | None = None,
    description: str | None = None,
    parameters: dict[str, object] | None = None,
) -> Tool | Callable[[Callable[..., object]], Tool]:
    """Create a Tool from a function, with optional schema overrides."""

    def decorator(target: Callable[..., object]) -> Tool:
        return schema_from_callable(
            target,
            name=name,
            description=description,
            parameters=parameters,
        )

    if func is None:
        return decorator
    return decorator(func)


def schema_from_callable(
    func: Callable[..., object],
    *,
    name: str | None = None,
    description: str | None = None,
    parameters: dict[str, object] | None = None,
) -> Tool:
    signature = inspect.signature(func)
    type_hints = get_type_hints(func)
    doc = _parse_docstring(inspect.getdoc(func) or "")
    properties: dict[str, dict[str, object]] = {}
    required: list[str] = []

    for parameter_name, parameter in signature.parameters.items():
        if parameter.kind not in {
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        }:
            continue
        annotation = type_hints.get(parameter_name, parameter.annotation)
        schema = _json_schema_for_annotation(annotation)
        if parameter_name in doc.params:
            schema["description"] = doc.params[parameter_name]
        if parameter.default is not inspect.Parameter.empty and parameter.default is not None:
            schema["default"] = parameter.default
        properties[parameter_name] = schema
        if parameter.default is inspect.Parameter.empty:
            required.append(parameter_name)

    resolved_description = description or doc.description or f"Call {func.__name__}."
    resolved_parameters = parameters
    if resolved_parameters is None:
        resolved_parameters = {
            "type": "object",
            "properties": properties,
        }
        if required:
            resolved_parameters["required"] = required

    return Tool(
        name=name or func.__name__,
        description=resolved_description,
        parameters=resolved_parameters,
        handler=func,
    )


def _json_schema_for_annotation(annotation: Any) -> dict[str, object]:
    if annotation is inspect.Parameter.empty or annotation is Any:
        return {"type": "string"}

    origin = get_origin(annotation)
    args = get_args(annotation)
    if origin is Literal:
        values = list(args)
        schema_type = _literal_json_type(values)
        schema: dict[str, object] = {"enum": values}
        if schema_type:
            schema["type"] = schema_type
        return schema
    if origin in {types.UnionType, getattr(types, "UnionType", object)} or str(origin) == "typing.Union":
        non_null = [arg for arg in args if arg is not type(None)]
        nullable = len(non_null) != len(args)
        if len(non_null) == 1:
            schema = _json_schema_for_annotation(non_null[0])
            if nullable:
                schema["nullable"] = True
            return schema
        return {"anyOf": [_json_schema_for_annotation(arg) for arg in non_null]}
    if origin in {list, tuple, set}:
        item_type = args[0] if args else Any
        return {"type": "array", "items": _json_schema_for_annotation(item_type)}
    if origin is dict:
        value_type = args[1] if len(args) == 2 else Any
        return {"type": "object", "additionalProperties": _json_schema_for_annotation(value_type)}

    target = origin or annotation
    mapping = {
        str: "string",
        int: "integer",
        float: "number",
        bool: "boolean",
        list: "array",
        dict: "object",
    }
    return {"type": mapping.get(target, "string")}


@dataclass(frozen=True, slots=True)
class ParsedDocstring:
    description: str | None
    params: dict[str, str]


def _parse_docstring(doc: str) -> ParsedDocstring:
    if not doc:
        return ParsedDocstring(description=None, params={})
    lines = doc.splitlines()
    description = _description_from_lines(lines)
    params = _google_args(lines) | _sphinx_params(lines)
    return ParsedDocstring(description=description, params=params)


def _description_from_lines(lines: list[str]) -> str | None:
    parts: list[str] = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            if parts:
                break
            continue
        if stripped in {"Args:", "Arguments:", "Parameters:", "Returns:", "Raises:"}:
            break
        if stripped.startswith(":param "):
            break
        parts.append(stripped)
    return " ".join(parts) or None


def _google_args(lines: list[str]) -> dict[str, str]:
    params: dict[str, str] = {}
    in_args = False
    current: str | None = None
    for line in lines:
        stripped = line.strip()
        if stripped in {"Args:", "Arguments:", "Parameters:"}:
            in_args = True
            current = None
            continue
        if not in_args:
            continue
        if stripped in {"Returns:", "Raises:", "Examples:"}:
            break
        if not stripped:
            continue
        name_part, separator, description = stripped.partition(":")
        if separator:
            current = name_part.split("(", 1)[0].strip()
            params[current] = description.strip()
        elif current:
            params[current] = f"{params[current]} {stripped}".strip()
    return params


def _sphinx_params(lines: list[str]) -> dict[str, str]:
    params: dict[str, str] = {}
    for line in lines:
        stripped = line.strip()
        if not stripped.startswith(":param "):
            continue
        raw_name, separator, description = stripped.removeprefix(":param ").partition(":")
        if separator:
            params[raw_name.strip()] = description.strip()
    return params


def _literal_json_type(values: list[Any]) -> str | None:
    types_seen = {type(value) for value in values}
    if types_seen == {str}:
        return "string"
    if types_seen == {int}:
        return "integer"
    if types_seen <= {int, float}:
        return "number"
    if types_seen == {bool}:
        return "boolean"
    return None
