"""Agent construction helpers."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from hajimi.config import AppConfig
from hajimi.llm import AnyLLMClient
from hajimi.mcp import MCPToolSource
from hajimi.observability import TraceManager
from hajimi.skill import (
    SkillCatalogEntry,
    create_activate_skill_tool,
    discover_skill_catalog,
    load_skill_catalog,
    load_skills,
    skill_catalog_prompt,
)
from hajimi.tool import (
    Tool,
    ToolCatalog,
    ToolRegistry,
    create_tool_search_tool,
    create_workspace_environment,
    create_workspace_tools,
)
from hajimi.core import Agent
from hajimi.core.subagent import ClientFactory, create_subagent_tool
from hajimi.core.team import TeamCoordinator, create_team_tools


@dataclass(frozen=True, slots=True)
class AgentBuildResult:
    agent: Agent
    tools: list[Tool]
    system_prompt: str | None


async def build_agent(
    config: AppConfig,
    *,
    client: AnyLLMClient,
    tracer: TraceManager,
    extra_tools: list[Tool] | None = None,
    skills_dir: str | Path = "skills",
    depth: int = 0,
    client_factory: ClientFactory | None = None,
    skills: list[str] | None = None,
    mcp_servers: list[str] | None = None,
    tool_names: list[str] | None = None,
    team_coordinator: TeamCoordinator | None = None,
    enable_team_tools: bool = True,
    team_tool_scope: str = "lead",
    team_tool_sender: str = "team_lead",
) -> AgentBuildResult:
    skill_names = config.agent.skills if skills is None else skills
    skills_base_dir = config.repo_path / skills_dir
    workspace_environment = (
        create_workspace_environment(config.repo_path, config.agent.workspace_tools)
        if config.agent.workspace_tools.enabled
        else None
    )
    progressive_skills = config.agent.skill_loading.progressive
    if progressive_skills:
        skill_catalog = await _skill_catalog(config, skill_names, skills_base_dir)
        skill_bundle = await load_skills([], base_dir=skills_base_dir)
    else:
        skill_catalog = []
        skill_bundle = await load_skills(skill_names, base_dir=skills_base_dir)
    mcp_tools = await MCPToolSource(config.mcp).load_tools(mcp_servers)
    subagent_tools = []
    if config.agent.subagents.enabled and depth < config.agent.subagents.max_depth:
        subagent_tools.append(
            create_subagent_tool(
                config,
                tracer=tracer,
                depth=depth,
                skills_dir=str(skills_dir),
                client_factory=client_factory,
            )
        )
    team_tools = []
    if config.agent.teammates.enabled and enable_team_tools:
        coordinator = team_coordinator or TeamCoordinator(
            config,
            tracer=tracer,
            skills_dir=str(skills_dir),
            client_factory=client_factory,
        )
        team_tools = create_team_tools(
            coordinator,
            config,
            include_lifecycle=team_tool_scope == "lead",
            default_sender=team_tool_sender,
        )
    searchable_tools = _filter_tools([*skill_bundle.tools, *mcp_tools], tool_names)
    workspace_tools = _filter_tools(
        create_workspace_tools(
            config.repo_path,
            config.agent.workspace_tools,
            environment=workspace_environment,
        ),
        tool_names,
    )
    always_visible_tools = [*workspace_tools, *subagent_tools, *team_tools, *(extra_tools or [])]
    registry_tools = always_visible_tools
    catalog = ToolCatalog(searchable_tools)
    if config.agent.tool_search.enabled and catalog:
        if not config.agent.tool_search.defer_tools:
            registry_tools = [*searchable_tools, *always_visible_tools]
        registry = ToolRegistry(registry_tools)
        registry.register(
            create_tool_search_tool(
                catalog,
                registry,
                name=config.agent.tool_search.tool_name,
                max_results=config.agent.tool_search.max_results,
            )
        )
    else:
        registry = ToolRegistry([*searchable_tools, *always_visible_tools])
    if progressive_skills and skill_catalog:
        registry.register(
            create_activate_skill_tool(
                skill_catalog,
                registry,
                base_dir=skills_base_dir,
                name=config.agent.skill_loading.activation_tool_name,
                script_tool_name=config.agent.skill_loading.script_tool_name,
                script_stage_path=config.agent.skill_loading.sandbox_stage_path,
                max_resources=config.agent.skill_loading.max_resources,
                tool_names=tool_names,
                sandbox=workspace_environment,
            )
        )
    system_prompt = _merge_prompts(
        config.agent.system_prompt,
        skill_bundle.instructions,
        skill_catalog_prompt(
            skill_catalog,
            tool_name=config.agent.skill_loading.activation_tool_name,
        ),
    )

    agent = Agent(
        client=client,
        tools=registry,
        name=config.agent.name,
        system_prompt=system_prompt,
        max_tool_rounds=config.agent.max_tool_rounds,
        tracer=tracer,
    )
    return AgentBuildResult(agent=agent, tools=[registry.get(name) for name in registry.names()], system_prompt=system_prompt)


def _merge_prompts(*parts: str | None) -> str | None:
    prompt = "\n\n".join(part.strip() for part in parts if part and part.strip())
    return prompt or None


async def _skill_catalog(
    config: AppConfig,
    skill_names: list[str],
    skills_base_dir: Path,
) -> list[SkillCatalogEntry]:
    explicit = await load_skill_catalog(skill_names, base_dir=skills_base_dir)
    if not config.agent.skill_loading.auto_discover:
        return explicit
    roots = [config.repo_path / path for path in config.agent.skill_loading.discovery_dirs]
    discovered = await discover_skill_catalog(roots)
    entries = {entry.name: entry for entry in discovered}
    entries.update({entry.name: entry for entry in explicit})
    return sorted(entries.values(), key=lambda entry: entry.name)


def _filter_tools(tools: list[Tool], tool_names: list[str] | None) -> list[Tool]:
    if tool_names is None:
        return tools
    allowed = set(tool_names)
    return [tool for tool in tools if tool.name in allowed]
