"""Core model and message adapters."""

