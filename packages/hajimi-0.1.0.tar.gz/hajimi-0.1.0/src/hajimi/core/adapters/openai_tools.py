"""OpenAI-style tool-call message adapters."""

from __future__ import annotations

import json
from typing import Any

from hajimi.core.tools import ToolCall, ToolResult
from hajimi.core.types import Message


def assistant_message(message: Any, content: str, tool_calls: list[ToolCall]) -> Message:
    payload = message_to_dict(message)
    payload["role"] = payload.get("role") or "assistant"
    if payload.get("content") is None:
        payload["content"] = content
    if tool_calls:
        payload["tool_calls"] = [raw_tool_call(tool_call) for tool_call in read_attr(message, "tool_calls")]
    return payload


def tool_message(result: ToolResult) -> Message:
    return {
        "role": "tool",
        "tool_call_id": result.call_id,
        "name": result.name,
        "content": result.content,
    }


def extract_tool_calls(message: Any) -> list[ToolCall]:
    raw_calls = read_attr(message, "tool_calls") or []
    return [parse_tool_call(raw_call) for raw_call in raw_calls]


def parse_tool_call(raw_call: Any) -> ToolCall:
    function = read_attr(raw_call, "function") or {}
    arguments = read_attr(function, "arguments") or "{}"
    if isinstance(arguments, str):
        try:
            parsed_arguments = json.loads(arguments or "{}")
        except json.JSONDecodeError as exc:
            parsed_arguments = {
                "__hajimi_parse_error__": f"{type(exc).__name__}: {exc}",
                "__raw_arguments__": arguments,
            }
    else:
        parsed_arguments = dict(arguments)
    return ToolCall(
        id=str(read_attr(raw_call, "id")),
        name=str(read_attr(function, "name")),
        arguments=parsed_arguments,
    )


def raw_tool_call(raw_call: Any) -> dict[str, Any]:
    if isinstance(raw_call, dict):
        return dict(raw_call)
    if hasattr(raw_call, "model_dump"):
        return {
            key: value
            for key, value in raw_call.model_dump(exclude_none=True).items()
            if value is not None
        }
    function = read_attr(raw_call, "function") or {}
    payload: dict[str, Any] = {
        "id": read_attr(raw_call, "id"),
        "type": read_attr(raw_call, "type") or "function",
        "function": {
            "name": read_attr(function, "name"),
            "arguments": read_attr(function, "arguments") or "{}",
        },
    }
    extra_content = read_attr(raw_call, "extra_content")
    if extra_content is not None:
        payload["extra_content"] = extra_content
    return payload


def read_attr(value: Any, name: str) -> Any:
    if isinstance(value, dict):
        return value.get(name)
    return getattr(value, name, None)


def message_to_dict(message: Any) -> Message:
    if isinstance(message, dict):
        return dict(message)
    if hasattr(message, "model_dump"):
        try:
            return {
                key: value
                for key, value in message.model_dump(exclude_none=True).items()
                if value is not None
            }
        except TypeError:
            pass
        return {
            key: value
            for key, value in message.model_dump().items()
            if value is not None
        }
    return {}
