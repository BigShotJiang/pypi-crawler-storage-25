"""Tool registry for the reusable core."""

from __future__ import annotations

from collections.abc import Callable, Iterable

from hajimi.core.schema import schema_from_callable
from hajimi.core.tools import Tool


class ToolRegistry:
    def __init__(self, tools: Iterable[Tool | Callable[..., object]] = ()) -> None:
        self._tools: dict[str, Tool] = {}
        for tool in tools:
            self.register(tool)

    def register(self, tool: Tool | Callable[..., object]) -> Tool:
        resolved = tool if isinstance(tool, Tool) else schema_from_callable(tool)
        if resolved.name in self._tools:
            raise ValueError(f"Tool {resolved.name!r} is already registered.")
        self._tools[resolved.name] = resolved
        return resolved

    def get(self, name: str) -> Tool:
        try:
            return self._tools[name]
        except KeyError as exc:
            raise KeyError(f"Unknown tool {name!r}.") from exc

    def has(self, name: str) -> bool:
        return name in self._tools

    def schemas(self) -> list[dict[str, object]]:
        return [tool.openai_schema for tool in self._tools.values()]

    def names(self) -> list[str]:
        return list(self._tools)

    def __bool__(self) -> bool:
        return bool(self._tools)
