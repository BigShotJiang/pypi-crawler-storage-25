"""Run-scoped event sink for nested producers."""

from __future__ import annotations

import contextvars
from collections.abc import AsyncIterable, AsyncIterator

import anyio

from hajimi.core.events import AgentEvent


class Runtime:
    def __init__(self) -> None:
        self._send, self._receive = anyio.create_memory_object_stream[AgentEvent](100)

    async def put_event(self, event: AgentEvent) -> None:
        await self._send.send(event)

    async def close(self) -> None:
        await self._send.aclose()

    def events(self) -> AsyncIterator[AgentEvent]:
        return self._receive.__aiter__()


_runtime: contextvars.ContextVar[Runtime] = contextvars.ContextVar("hajimi_core_runtime")


def get_runtime() -> Runtime:
    return _runtime.get()


async def run(source: AsyncIterable[AgentEvent]) -> AsyncIterator[AgentEvent]:
    runtime = Runtime()
    token = _runtime.set(runtime)

    async def drain() -> None:
        try:
            async for event in source:
                await runtime.put_event(event)
        finally:
            await runtime.close()

    try:
        async with anyio.create_task_group() as task_group:
            task_group.start_soon(drain)
            async for event in runtime.events():
                yield event
    finally:
        _runtime.reset(token)
