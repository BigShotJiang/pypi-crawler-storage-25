"""Typed message and content-part primitives for the core agent loop."""

from __future__ import annotations

import base64
import mimetypes
from collections.abc import Mapping, Sequence
from typing import Annotated, Any, Literal, Self, overload
from uuid import uuid4

import pydantic


def new_id(prefix: str | None = None) -> str:
    raw = uuid4().hex[:12]
    return f"{prefix}_{raw}" if prefix else raw


class TextPart(pydantic.BaseModel):
    id: str = pydantic.Field(default_factory=lambda: new_id("txt"))
    text: str
    provider_metadata: dict[str, Any] | None = None
    kind: Literal["text"] = "text"


class ReasoningPart(pydantic.BaseModel):
    id: str = pydantic.Field(default_factory=lambda: new_id("rsn"))
    text: str
    provider_metadata: dict[str, Any] | None = None
    kind: Literal["reasoning"] = "reasoning"


class ToolCallPart(pydantic.BaseModel):
    id: str = pydantic.Field(default_factory=lambda: new_id("tc"))
    tool_call_id: str
    tool_name: str
    tool_args: str = "{}"
    provider_metadata: dict[str, Any] | None = None
    cached_result: "ToolResultPart | None" = pydantic.Field(default=None, exclude=True, repr=False)
    kind: Literal["tool_call"] = "tool_call"


_MODEL_INPUT_UNSET: Any = object()


class ToolResultPart(pydantic.BaseModel):
    id: str = pydantic.Field(default_factory=lambda: new_id("tr"))
    tool_call_id: str
    tool_name: str = ""
    result: Any = None
    is_error: bool = False
    provider_metadata: dict[str, Any] | None = None
    kind: Literal["tool_result"] = "tool_result"
    model_config = pydantic.ConfigDict(frozen=True)

    _model_input: Any = pydantic.PrivateAttr(default_factory=lambda: _MODEL_INPUT_UNSET)

    def get_model_input(self) -> Any:
        if self._model_input is _MODEL_INPUT_UNSET:
            return self.result
        return self._model_input

    def set_model_input(self, value: Any) -> None:
        self._model_input = value

    @property
    def has_model_input(self) -> bool:
        return self._model_input is not _MODEL_INPUT_UNSET


class FilePart(pydantic.BaseModel):
    id: str = pydantic.Field(default_factory=lambda: new_id("file"))
    data: str | bytes
    media_type: str
    filename: str | None = None
    provider_metadata: dict[str, Any] | None = None
    kind: Literal["file"] = "file"

    @classmethod
    def from_url(cls, url: str, *, media_type: str | None = None) -> Self:
        resolved = media_type or _infer_media_type(url)
        if resolved is None:
            raise ValueError("Cannot infer media_type from URL. Provide media_type explicitly.")
        return cls(data=url, media_type=resolved)

    @classmethod
    def from_bytes(
        cls,
        data: bytes,
        *,
        media_type: str | None = None,
        filename: str | None = None,
    ) -> Self:
        resolved = media_type or _detect_media_type(data)
        if resolved is None:
            raise ValueError("Cannot detect media_type from bytes. Provide media_type explicitly.")
        return cls(data=data, media_type=resolved, filename=filename)

    def as_provider_data(self) -> str:
        if isinstance(self.data, bytes):
            return base64.b64encode(self.data).decode("ascii")
        return self.data


class SummaryPart(pydantic.BaseModel):
    id: str = pydantic.Field(default_factory=lambda: new_id("sum"))
    text: str
    source_message_ids: list[str] = pydantic.Field(default_factory=list)
    kind: Literal["summary"] = "summary"


Part = Annotated[
    TextPart | ReasoningPart | ToolCallPart | ToolResultPart | FilePart | SummaryPart,
    pydantic.Field(discriminator="kind"),
]

Role = Literal["system", "user", "assistant", "tool", "internal"]


class Message(pydantic.BaseModel):
    role: Role
    parts: list[Part] = pydantic.Field(default_factory=list)
    id: str = pydantic.Field(default_factory=lambda: new_id("msg"))
    turn_id: str | None = None
    usage: dict[str, Any] | None = None
    provider_metadata: dict[str, Any] | None = None
    replay: bool = pydantic.Field(default=False, exclude=True, repr=False)

    model_config = pydantic.ConfigDict(arbitrary_types_allowed=True)

    @classmethod
    def text_message(cls, role: Role, text: str) -> "Message":
        part: Part
        if role == "system":
            part = SummaryPart(text=text)
        else:
            part = TextPart(text=text)
        return cls(role=role, parts=[part])

    @classmethod
    def from_chat(cls, message: Mapping[str, Any]) -> "Message":
        role = str(message.get("role", "user"))
        raw = _jsonable(dict(message))
        parts: list[Part] = []
        content = message.get("content")

        if role == "tool":
            parts.append(
                ToolResultPart(
                    tool_call_id=str(message.get("tool_call_id") or ""),
                    tool_name=str(message.get("name") or ""),
                    result=_content_text(content),
                    provider_metadata={"raw": raw},
                )
            )
            return cls(role="tool", parts=parts, provider_metadata={"raw": raw})

        if role == "system":
            if content is not None:
                parts.append(SummaryPart(text=_content_text(content)))
        elif content is not None:
            parts.extend(_content_parts(content))

        for field_name in ("reasoning", "reasoning_content", "thinking", "think"):
            if field_name not in message or message.get(field_name) is None:
                continue
            parts.append(
                ReasoningPart(
                    text=_content_text(message.get(field_name)),
                    provider_metadata={"field": field_name, "raw": _jsonable(message.get(field_name))},
                )
            )

        for raw_call in message.get("tool_calls") or []:
            function = _read_attr(raw_call, "function") or {}
            parts.append(
                ToolCallPart(
                    tool_call_id=str(_read_attr(raw_call, "id") or ""),
                    tool_name=str(_read_attr(function, "name") or ""),
                    tool_args=str(_read_attr(function, "arguments") or "{}"),
                    provider_metadata={"raw": _jsonable(raw_call)},
                )
            )

        if role not in {"system", "user", "assistant", "internal"}:
            role = "user"
        return cls(role=role, parts=parts, provider_metadata={"raw": raw})  # type: ignore[arg-type]

    @property
    def text(self) -> str:
        return "".join(part.text for part in self.parts if isinstance(part, TextPart))

    @property
    def reasoning(self) -> str:
        return "".join(part.text for part in self.parts if isinstance(part, ReasoningPart))

    @property
    def summaries(self) -> list[SummaryPart]:
        return [part for part in self.parts if isinstance(part, SummaryPart)]

    @property
    def tool_calls(self) -> list[ToolCallPart]:
        return [part for part in self.parts if isinstance(part, ToolCallPart)]

    @property
    def tool_results(self) -> list[ToolResultPart]:
        return [part for part in self.parts if isinstance(part, ToolResultPart)]

    @property
    def files(self) -> list[FilePart]:
        return [part for part in self.parts if isinstance(part, FilePart)]

    @overload
    def get_output(self, output_type: None = None) -> str: ...

    @overload
    def get_output[T: pydantic.BaseModel](self, output_type: type[T]) -> T: ...

    def get_output(self, output_type: type[pydantic.BaseModel] | None = None) -> Any:
        if self.role != "assistant" or self.tool_calls:
            raise ValueError("get_output() requires a final assistant message with no tool calls.")
        if output_type is None:
            return self.text
        return output_type.model_validate_json(self.text)

    def to_chat(self) -> dict[str, Any]:
        if self.role == "tool":
            result = self.tool_results[0] if self.tool_results else None
            return {
                "role": "tool",
                "tool_call_id": result.tool_call_id if result else "",
                "name": result.tool_name if result else "",
                "content": _content_text(result.get_model_input() if result else ""),
            }

        raw = _raw_metadata(self)
        if raw and self.role == "assistant":
            payload = dict(raw)
            payload["role"] = "assistant"
            if self.text or payload.get("content") is None:
                payload["content"] = self.text
            if self.tool_calls:
                payload["tool_calls"] = [_raw_tool_call(part) for part in self.tool_calls]
            return {key: value for key, value in payload.items() if value is not None}

        content_parts: list[Any] = []
        text = self.text or "\n".join(part.text for part in self.summaries)
        if text:
            content_parts.append(text)
        for file_part in self.files:
            content_parts.append(
                {
                    "type": "file",
                    "data": file_part.as_provider_data(),
                    "media_type": file_part.media_type,
                    "filename": file_part.filename,
                }
            )
        content: Any
        if not content_parts:
            content = ""
        elif len(content_parts) == 1:
            content = content_parts[0]
        else:
            content = content_parts

        payload: dict[str, Any] = {"role": self.role, "content": content}
        if self.reasoning:
            payload["reasoning"] = self.reasoning
        if self.tool_calls:
            payload["tool_calls"] = [_raw_tool_call(part) for part in self.tool_calls]
        return payload


PartLike = str | Part


def system_message(*content: PartLike) -> Message:
    return Message(role="system", parts=_coerce_parts(content, system=True))


def user_message(*content: PartLike) -> Message:
    return Message(role="user", parts=_coerce_parts(content))


def assistant_message(*content: PartLike) -> Message:
    return Message(role="assistant", parts=_coerce_parts(content))


def tool_message(*parts: ToolResultPart) -> Message:
    return Message(role="tool", parts=list(parts))


def tool_result_part(
    tool_call_id: str,
    *,
    result: Any = None,
    tool_name: str = "",
    is_error: bool = False,
) -> ToolResultPart:
    return ToolResultPart(tool_call_id=tool_call_id, tool_name=tool_name, result=result, is_error=is_error)


def file_part(data: str | bytes, *, media_type: str | None = None, filename: str | None = None) -> FilePart:
    if isinstance(data, str):
        return FilePart.from_url(data, media_type=media_type)
    return FilePart.from_bytes(data, media_type=media_type, filename=filename)


def thinking(text: str, *, provider_metadata: dict[str, Any] | None = None) -> ReasoningPart:
    return ReasoningPart(text=text, provider_metadata=provider_metadata)


def ensure_message(value: str | Mapping[str, Any] | Message) -> Message:
    if isinstance(value, Message):
        return value
    if isinstance(value, str):
        return user_message(value)
    return Message.from_chat(value)


def ensure_messages(values: str | Mapping[str, Any] | Message | Sequence[Mapping[str, Any] | Message]) -> list[Message]:
    if isinstance(values, str) or isinstance(values, Message) or isinstance(values, Mapping):
        return [ensure_message(values)]
    return [ensure_message(value) for value in values]


def to_chat_messages(messages: Sequence[Message]) -> list[dict[str, Any]]:
    return [message.to_chat() for message in messages]


def _coerce_parts(content: tuple[PartLike, ...], *, system: bool = False) -> list[Part]:
    parts: list[Part] = []
    for item in content:
        if isinstance(item, str):
            parts.append(SummaryPart(text=item) if system else TextPart(text=item))
        elif isinstance(item, TextPart | ReasoningPart | ToolCallPart | ToolResultPart | FilePart | SummaryPart):
            parts.append(item)
        else:
            raise TypeError(f"Expected str or Part, got {type(item).__name__}.")
    return parts


def _content_parts(content: Any) -> list[Part]:
    if isinstance(content, list):
        parts: list[Part] = []
        for item in content:
            if isinstance(item, str):
                parts.append(TextPart(text=item))
            elif isinstance(item, Mapping):
                item_type = item.get("type")
                if item_type == "text":
                    parts.append(TextPart(text=_content_text(item.get("text"))))
                elif item_type in {"image_url", "file"}:
                    data = item.get("data") or item.get("url") or item.get("image_url", {}).get("url")
                    if data is not None:
                        parts.append(FilePart.from_url(str(data), media_type=item.get("media_type")))
        return parts
    text = _content_text(content)
    return [TextPart(text=text)] if text else []


def _content_text(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if hasattr(content, "model_dump"):
        return str(content.model_dump())
    return str(content)


def _read_attr(value: Any, name: str) -> Any:
    if isinstance(value, Mapping):
        return value.get(name)
    return getattr(value, name, None)


def _raw_metadata(message: Message) -> dict[str, Any] | None:
    raw = (message.provider_metadata or {}).get("raw")
    return dict(raw) if isinstance(raw, Mapping) else None


def _raw_tool_call(part: ToolCallPart) -> dict[str, Any]:
    raw = (part.provider_metadata or {}).get("raw")
    if isinstance(raw, Mapping):
        return dict(raw)
    return {
        "id": part.tool_call_id,
        "type": "function",
        "function": {"name": part.tool_name, "arguments": part.tool_args or "{}"},
    }


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, str | int | float | bool):
        return value
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, list | tuple):
        return [_jsonable(item) for item in value]
    if hasattr(value, "model_dump"):
        return _jsonable(value.model_dump(exclude_none=True))
    return str(value)


def _infer_media_type(value: str) -> str | None:
    if value.startswith("data:") and ";" in value:
        return value.removeprefix("data:").split(";", 1)[0] or None
    guessed, _ = mimetypes.guess_type(value)
    return guessed


def _detect_media_type(data: bytes) -> str | None:
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if data.startswith(b"GIF87a") or data.startswith(b"GIF89a"):
        return "image/gif"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WAVE":
        return "audio/wav"
    return None
