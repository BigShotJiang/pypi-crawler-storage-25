"""Concurrent async tool dispatch."""

from __future__ import annotations

import json
from typing import Any

import anyio

from hajimi.core.registry import ToolRegistry
from hajimi.core.tools import BoundToolCall, ToolCall, ToolResult
from hajimi.core.types import NoOpTracer, Tracer


class ToolDispatcher:
    def __init__(self, registry: ToolRegistry, tracer: Tracer | None = None) -> None:
        self._registry = registry
        self._tracer = tracer or NoOpTracer()

    async def dispatch(self, call: ToolCall) -> ToolResult:
        async with self._tracer.span(
            "tool.call",
            kind="tool",
            attributes={
                "tool.name": call.name,
                "tool.call_id": call.id,
            },
        ) as span:
            if self._tracer.include_content:
                span.add_event("tool.input", {"arguments": self._tracer.content(call.arguments)})
            arguments = call.arguments or {}
            parse_error = arguments.get("__hajimi_parse_error__")
            if parse_error is not None:
                content = _stringify_result(
                    {
                        "error": "tool_arguments_parse_error",
                        "message": parse_error,
                        "raw_arguments": arguments.get("__raw_arguments__", ""),
                    }
                )
                span.set_attribute("tool.output.length", len(content))
                span.set_attribute("tool.error.kind", "arguments_parse")
                if self._tracer.include_content:
                    span.add_event("tool.output", {"content": self._tracer.content(content)})
                return ToolResult(call_id=call.id, name=call.name, content=content)
            tool = self._registry.get(call.name)
            result = await tool.invoke(arguments)
            content = _stringify_result(result)
            span.set_attribute("tool.output.length", len(content))
            if self._tracer.include_content:
                span.add_event("tool.output", {"content": self._tracer.content(content)})
            return ToolResult(
                call_id=call.id,
                name=call.name,
                content=content,
            )

    async def dispatch_many(self, calls: list[ToolCall]) -> list[ToolResult]:
        results: list[ToolResult | None] = [None] * len(calls)

        async def run_one(index: int, call: ToolCall) -> None:
            results[index] = await self.dispatch(call)

        async with anyio.create_task_group() as task_group:
            for index, call in enumerate(calls):
                task_group.start_soon(run_one, index, call)

        return [result for result in results if result is not None]

    def bind(self, call: ToolCall) -> BoundToolCall:
        return BoundToolCall(call=call, tool=self._registry.get(call.name))


def _stringify_result(value: Any) -> str:
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, default=str)
