"""In-process teammate coordination."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import asdict, dataclass, replace
from typing import Any

from hajimi.config import AgentProfileSettings, AppConfig, ModelSettings
from hajimi.default_tools import (
    TEAM_BROADCAST_TOOL_DESCRIPTION,
    TEAM_CLOSE_TOOL_DESCRIPTION,
    TEAM_LIST_TOOL_DESCRIPTION,
    TEAM_SEND_TOOL_DESCRIPTION,
    TEAM_SPAWN_TOOL_DESCRIPTION,
)
from hajimi.llm import AnyLLMClient
from hajimi.observability import TraceManager
from hajimi.tool import Tool

type ClientFactory = Callable[[ModelSettings, TraceManager], AnyLLMClient]


@dataclass(slots=True)
class Teammate:
    name: str
    profile: str | None
    model_name: str
    agent: Any
    messages: list[dict[str, Any]]
    status: str = "active"


@dataclass(frozen=True, slots=True)
class TeammateMessageResponse:
    recipient: str
    content: str
    messages: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class TeamCoordinator:
    """Small in-process team runtime.

    Teammates differ from subagents: they persist across messages and keep their
    own conversation history until explicitly closed.
    """

    def __init__(
        self,
        config: AppConfig,
        *,
        tracer: TraceManager,
        skills_dir: str = "skills",
        client_factory: ClientFactory | None = None,
    ) -> None:
        self._config = config
        self._tracer = tracer
        self._skills_dir = skills_dir
        self._client_factory = client_factory or _default_client_factory
        self._members: dict[str, Teammate] = {}

    async def spawn(
        self,
        *,
        name: str,
        prompt: str,
        profile: str | None = None,
        model_name: str | None = None,
        system_prompt: str | None = None,
        skills: list[str] | None = None,
        mcp_servers: list[str] | None = None,
        tool_names: list[str] | None = None,
    ) -> dict[str, Any]:
        if name in self._members and self._members[name].status == "active":
            raise ValueError(f"Teammate {name!r} is already active.")
        if len([member for member in self._members.values() if member.status == "active"]) >= self._config.agent.teammates.max_members:
            raise RuntimeError(f"Team already has max_members={self._config.agent.teammates.max_members}.")

        profile_settings = _resolve_profile(self._config, profile)
        model_settings = self._config.model(model_name or (profile_settings.model_name if profile_settings else None))
        member_skills = _select_list(skills, profile_settings.skills if profile_settings else None, self._config.agent.skills) or []
        member_mcp_servers = _select_list(mcp_servers, profile_settings.mcp_servers if profile_settings else None, None)
        member_tool_names = _select_list(tool_names, profile_settings.tool_names if profile_settings else None, None)
        member_system_prompt = (
            system_prompt
            or (profile_settings.system_prompt if profile_settings else None)
            or _default_teammate_prompt(name)
        )
        member_max_tool_rounds = (
            self._config.agent.teammates.max_tool_rounds
            or (profile_settings.max_tool_rounds if profile_settings else None)
            or self._config.agent.max_tool_rounds
        )

        async with self._tracer.span(
            "agent.teammate.spawn",
            kind="agent",
            attributes={
                "agent.teammate.name": name,
                "agent.teammate.profile": profile,
                "agent.teammate.model_name": model_settings.name,
                "agent.teammate.skills": member_skills,
                "agent.teammate.mcp_servers": member_mcp_servers or [],
                "agent.teammate.tool_names": member_tool_names or [],
            },
        ):
            teammate_config = replace(
                self._config,
                agent=replace(
                    self._config.agent,
                    name=name,
                    default_model=model_settings.name,
                    system_prompt=member_system_prompt,
                    max_tool_rounds=member_max_tool_rounds,
                    skills=member_skills,
                ),
            )
            from hajimi.core.builder import build_agent

            built = await build_agent(
                teammate_config,
                client=self._client_factory(model_settings, self._tracer),
                tracer=self._tracer,
                skills_dir=self._skills_dir,
                depth=self._config.agent.subagents.max_depth,
                client_factory=self._client_factory,
                skills=member_skills,
                mcp_servers=member_mcp_servers,
                tool_names=member_tool_names,
                team_coordinator=self,
                enable_team_tools=True,
                team_tool_scope="member",
                team_tool_sender=name,
            )
            self._members[name] = Teammate(
                name=name,
                profile=profile,
                model_name=model_settings.name,
                agent=built.agent,
                messages=[],
            )
            first = await self.send(name=name, message=prompt, sender="team_lead")
            return {
                "name": name,
                "profile": profile,
                "model_name": model_settings.name,
                "status": "active",
                "initial_response": first.content,
            }

    async def send(self, *, name: str, message: str, sender: str = "team_lead") -> TeammateMessageResponse:
        member = self._active_member(name)
        member.messages.append({"role": "user", "name": sender, "content": message})
        async with self._tracer.span(
            "agent.teammate.message",
            kind="agent",
            attributes={
                "agent.teammate.name": name,
                "agent.teammate.sender": sender,
                "agent.teammate.messages": len(member.messages),
            },
        ) as span:
            result = await member.agent.run(member.messages)
            member.messages = result.messages
            span.set_attribute("agent.teammate.output.length", len(result.content))
            if self._tracer.include_content:
                span.add_event("agent.teammate.output", {"content": self._tracer.content(result.content)})
            return TeammateMessageResponse(
                recipient=name,
                content=result.content,
                messages=len(member.messages),
            )

    async def broadcast(self, *, message: str, sender: str = "team_lead") -> dict[str, Any]:
        responses = []
        for name in self._active_names():
            responses.append((await self.send(name=name, message=message, sender=sender)).to_dict())
        return {"responses": responses}

    def list(self) -> dict[str, Any]:
        return {
            "members": [
                {
                    "name": member.name,
                    "profile": member.profile,
                    "model_name": member.model_name,
                    "status": member.status,
                    "messages": len(member.messages),
                }
                for member in self._members.values()
            ]
        }

    async def close(self, *, name: str) -> dict[str, Any]:
        member = self._active_member(name)
        member.status = "closed"
        async with self._tracer.span(
            "agent.teammate.close",
            kind="agent",
            attributes={
                "agent.teammate.name": name,
                "agent.teammate.messages": len(member.messages),
            },
        ):
            return {"name": name, "status": member.status}

    def _active_member(self, name: str) -> Teammate:
        try:
            member = self._members[name]
        except KeyError as exc:
            raise KeyError(f"Unknown teammate {name!r}.") from exc
        if member.status != "active":
            raise RuntimeError(f"Teammate {name!r} is {member.status}.")
        return member

    def _active_names(self) -> list[str]:
        return [name for name, member in self._members.items() if member.status == "active"]


def create_team_tools(
    coordinator: TeamCoordinator,
    config: AppConfig,
    *,
    include_lifecycle: bool = True,
    default_sender: str = "team_lead",
) -> list[Tool]:
    settings = config.agent.teammates

    async def spawn_teammate(
        name: str,
        prompt: str,
        profile: str | None = None,
        model_name: str | None = None,
        system_prompt: str | None = None,
        skills: list[str] | None = None,
        mcp_servers: list[str] | None = None,
        tool_names: list[str] | None = None,
    ) -> dict[str, Any]:
        return await coordinator.spawn(
            name=name,
            prompt=prompt,
            profile=profile,
            model_name=model_name,
            system_prompt=system_prompt,
            skills=skills,
            mcp_servers=mcp_servers,
            tool_names=tool_names,
        )

    async def send_teammate_message(name: str, message: str, sender: str = default_sender) -> dict[str, Any]:
        return (await coordinator.send(name=name, message=message, sender=sender)).to_dict()

    async def broadcast_teammate_message(message: str, sender: str = default_sender) -> dict[str, Any]:
        return await coordinator.broadcast(message=message, sender=sender)

    async def list_teammates() -> dict[str, Any]:
        return coordinator.list()

    async def close_teammate(name: str) -> dict[str, Any]:
        return await coordinator.close(name=name)

    message_tools = [
        Tool(
            name=settings.send_tool_name,
            description=TEAM_SEND_TOOL_DESCRIPTION,
            parameters=_schema(
                {
                    "name": ("string", "Target teammate name."),
                    "message": ("string", "Message to send."),
                    "sender": ("string", "Sender name."),
                },
                ["name", "message"],
            ),
            handler=send_teammate_message,
        ),
        Tool(
            name=settings.broadcast_tool_name,
            description=TEAM_BROADCAST_TOOL_DESCRIPTION,
            parameters=_schema(
                {
                    "message": ("string", "Message to send."),
                    "sender": ("string", "Sender name."),
                },
                ["message"],
            ),
            handler=broadcast_teammate_message,
        ),
        Tool(
            name=settings.list_tool_name,
            description=TEAM_LIST_TOOL_DESCRIPTION,
            parameters=_schema({}, []),
            handler=list_teammates,
        ),
    ]
    if not include_lifecycle:
        return message_tools
    return [
        Tool(
            name=settings.spawn_tool_name,
            description=TEAM_SPAWN_TOOL_DESCRIPTION,
            parameters=_schema(
                {
                    "name": ("string", "Teammate name."),
                    "prompt": ("string", "First message for the teammate."),
                    "profile": ("string", "Configured agent profile."),
                    "model_name": ("string", "Configured model key."),
                    "system_prompt": ("string", "System prompt override."),
                    "skills": ("array", "Skill names available to the teammate."),
                    "mcp_servers": ("array", "MCP servers available to the teammate."),
                    "tool_names": ("array", "Allowed tool names for the teammate."),
                },
                ["name", "prompt"],
            ),
            handler=spawn_teammate,
        ),
        *message_tools,
        Tool(
            name=settings.close_tool_name,
            description=TEAM_CLOSE_TOOL_DESCRIPTION,
            parameters=_schema({"name": ("string", "Teammate name.")}, ["name"]),
            handler=close_teammate,
        ),
    ]


def _schema(properties: dict[str, tuple[str, str]], required: list[str]) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            name: _property_schema(kind, description)
            for name, (kind, description) in properties.items()
        },
        "required": required,
    }


def _property_schema(kind: str, description: str) -> dict[str, Any]:
    schema: dict[str, Any] = {"type": kind, "description": description}
    if kind == "array":
        schema["items"] = {"type": "string"}
    return schema


def _default_client_factory(settings: ModelSettings, tracer: TraceManager) -> AnyLLMClient:
    return AnyLLMClient(settings, tracer=tracer)


def _default_teammate_prompt(name: str) -> str:
    return (
        f"You are teammate {name}. You have your own context. "
        "Collaborate through teammate messaging tools and return concise results."
    )


def _resolve_profile(config: AppConfig, profile: str | None) -> AgentProfileSettings | None:
    if profile is None:
        return None
    try:
        return config.agent.profiles[profile]
    except KeyError as exc:
        names = ", ".join(sorted(config.agent.profiles))
        raise KeyError(f"Unknown agent profile {profile!r}. Available profiles: {names}") from exc


def _select_list(
    request_value: list[str] | None,
    profile_value: list[str] | None,
    default_value: list[str] | None,
) -> list[str] | None:
    if request_value is not None:
        return list(request_value)
    if profile_value is not None:
        return list(profile_value)
    if default_value is not None:
        return list(default_value)
    return None
