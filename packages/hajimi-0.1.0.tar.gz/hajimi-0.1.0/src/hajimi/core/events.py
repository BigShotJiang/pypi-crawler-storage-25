"""Typed runtime events emitted by core streams and agent loops."""

from __future__ import annotations

from typing import Annotated, Any, Literal

import pydantic

from hajimi.core.messages import Message, ToolCallPart, ToolResultPart


_DUMMY_MESSAGE = Message(role="assistant", parts=[])


class BaseEvent(pydantic.BaseModel):
    message: Message = _DUMMY_MESSAGE
    usage: dict[str, Any] | None = None
    provider_metadata: dict[str, Any] | None = None
    raw: Any = pydantic.Field(default=None, exclude=True, repr=False)
    replay: bool = pydantic.Field(default=False, exclude=True, repr=False)
    model_config = pydantic.ConfigDict(frozen=True, arbitrary_types_allowed=True)


class StreamStart(BaseEvent):
    kind: Literal["stream_start"] = "stream_start"


class StreamEnd(BaseEvent):
    kind: Literal["stream_end"] = "stream_end"


class TextStart(BaseEvent):
    block_id: str = ""
    kind: Literal["text_start"] = "text_start"


class TextDelta(BaseEvent):
    chunk: str
    block_id: str = ""
    kind: Literal["text_delta"] = "text_delta"


class TextEnd(BaseEvent):
    block_id: str = ""
    kind: Literal["text_end"] = "text_end"


class ReasoningStart(BaseEvent):
    block_id: str = ""
    kind: Literal["reasoning_start"] = "reasoning_start"


class ReasoningDelta(BaseEvent):
    chunk: str
    block_id: str = ""
    kind: Literal["reasoning_delta"] = "reasoning_delta"


class ReasoningEnd(BaseEvent):
    block_id: str = ""
    kind: Literal["reasoning_end"] = "reasoning_end"


class ToolStart(BaseEvent):
    tool_call_id: str = ""
    tool_name: str = ""
    kind: Literal["tool_start"] = "tool_start"


class ToolDelta(BaseEvent):
    chunk: str
    tool_call_id: str = ""
    kind: Literal["tool_delta"] = "tool_delta"


class ToolEnd(BaseEvent):
    tool_call: ToolCallPart
    tool_call_id: str = ""
    kind: Literal["tool_end"] = "tool_end"


class ToolCallResult(BaseEvent):
    results: list[ToolResultPart]
    exception: BaseException | None = pydantic.Field(default=None, exclude=True, repr=False)
    kind: Literal["tool_call_result"] = "tool_call_result"


class PartialToolCallResult(BaseEvent):
    tool_call_id: str | None = None
    tool_name: str | None = None
    label: object = None
    value: Any = None
    kind: Literal["partial_tool_call_result"] = "partial_tool_call_result"


Event = (
    StreamStart
    | StreamEnd
    | TextStart
    | TextDelta
    | TextEnd
    | ReasoningStart
    | ReasoningDelta
    | ReasoningEnd
    | ToolStart
    | ToolDelta
    | ToolEnd
)

AgentEvent = Event | ToolCallResult | PartialToolCallResult

DiscriminatedEvent = Annotated[AgentEvent, pydantic.Field(discriminator="kind")]
