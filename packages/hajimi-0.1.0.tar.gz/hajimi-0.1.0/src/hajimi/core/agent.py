"""Core async agent loop."""

from __future__ import annotations

import json
from collections.abc import AsyncIterator, Callable, Iterable, Sequence
from dataclasses import dataclass, field
from typing import Any, Generic, Self, cast

from loguru import logger

from hajimi.core.adapters.openai_tools import assistant_message, extract_tool_calls, tool_message
from hajimi.core.context import Context
from hajimi.core.dispatcher import ToolDispatcher
from hajimi.core.events import AgentEvent, StreamEnd, TextDelta, TextEnd, TextStart, ToolEnd
from hajimi.core.messages import Message as CoreMessage
from hajimi.core.messages import ensure_message, ensure_messages
from hajimi.core.registry import ToolRegistry
from hajimi.core.stream import Stream
from hajimi.core.stream import stream as open_stream
from hajimi.core.tools import Tool, ToolRunner
from hajimi.core.types import AgentResult, AgentStreamEvent, Budget, Message, MessageTransformer, ModelClient
from hajimi.core.types import NoOpTracer, Tracer
from hajimi.core.util import merge
from typing_extensions import TypeVar


AgentOutputT = TypeVar("AgentOutputT", default=str)


@dataclass(slots=True)
class Agent:
    """Minimal async agent with optional tool execution."""

    client: ModelClient
    name: str = "hajimi"
    system_prompt: str | None = None
    tools: ToolRegistry = field(default_factory=ToolRegistry)
    max_tool_rounds: int = 4
    tracer: Tracer | None = None
    budget: Budget | None = None
    message_transformer: MessageTransformer | None = None

    @classmethod
    def from_tools(
        cls,
        *,
        client: ModelClient,
        tools: Iterable[Tool | Callable[..., object]],
        name: str = "hajimi",
        system_prompt: str | None = None,
        max_tool_rounds: int = 4,
        tracer: Tracer | None = None,
    ) -> "Agent":
        return cls(
            client=client,
            name=name,
            system_prompt=system_prompt,
            tools=ToolRegistry(tools),
            max_tool_rounds=max_tool_rounds,
            tracer=tracer,
        )

    async def run(
        self,
        prompt: str | Sequence[Message],
        **model_overrides: Any,
    ) -> AgentResult:
        """Run a non-streaming completion loop and execute tool calls."""

        tracer = self._tracer()
        context = self._build_context(prompt)
        messages = context.model_messages()
        raw_response: Any = None

        async with tracer.span(
            "agent.run",
            kind="agent",
            attributes={
                "agent.name": self.name,
                "agent.stream": False,
                "agent.max_tool_rounds": self.max_tool_rounds,
                "agent.tools.count": len(self.tools.schemas()) if self.tools else 0,
            },
        ) as span:
            if tracer.include_content:
                span.add_event("agent.input", {"messages": tracer.content(messages)})

            for round_index in range(self.max_tool_rounds + 1):
                span.add_event("agent.round.start", {"round": round_index + 1})
                context.messages = ensure_messages(await self._compact_inflight(context.model_messages()))
                messages = context.model_messages()
                tools = self.tools.schemas() if self.tools else None
                result = await self.client.complete(messages, tools=tools, **model_overrides)
                raw_response = result.raw
                await self._record_usage(raw_response)
                choice_message = raw_response.choices[0].message
                tool_calls = extract_tool_calls(choice_message)
                context.add(assistant_message(choice_message, result.text, tool_calls))
                messages = context.model_messages()

                if self._budget_should_stop():
                    span.set_attribute("agent.rounds", round_index + 1)
                    span.set_attribute("agent.aborted", True)
                    if tracer.include_content:
                        span.add_event(
                            "agent.budget.aborted",
                            {"reason": self.budget.report.aborted_reason if self.budget else None},
                        )
                    logger.warning(
                        "Agent {name} stopping early after round {round} due to budget cap.",
                        name=self.name,
                        round=round_index + 1,
                    )
                    return AgentResult(content=result.text, messages=messages, raw=raw_response)

                if not tool_calls:
                    span.set_attribute("agent.rounds", round_index + 1)
                    span.set_attribute("agent.output.length", len(result.text))
                    if tracer.include_content:
                        span.add_event("agent.output", {"content": tracer.content(result.text)})
                    logger.debug("Agent {name} completed in {rounds} round(s).", name=self.name, rounds=round_index + 1)
                    return AgentResult(content=result.text, messages=messages, raw=raw_response)

                span.add_event(
                    "agent.tool_calls",
                    {"round": round_index + 1, "count": len(tool_calls), "names": [call.name for call in tool_calls]},
                )
                logger.debug("Agent {name} dispatching {count} tool call(s).", name=self.name, count=len(tool_calls))
                dispatcher = ToolDispatcher(self.tools, tracer=tracer)
                tool_results = await dispatcher.dispatch_many(tool_calls)
                context.add([tool_message(result) for result in tool_results])
                messages = context.model_messages()
                span.set_attribute("agent.tools.count", len(self.tools.schemas()) if self.tools else 0)

        raise RuntimeError(f"Agent {self.name!r} exceeded max_tool_rounds={self.max_tool_rounds}.")

    async def stream(
        self,
        prompt: str | Sequence[Message],
        **model_overrides: Any,
    ) -> AsyncIterator[AgentStreamEvent]:
        """Stream text deltas from the model."""

        tracer = self._tracer()
        messages = self._build_messages(prompt)
        async with tracer.span(
            "agent.stream",
            kind="agent",
            attributes={
                "agent.name": self.name,
                "agent.stream": True,
                "agent.tools.count": len(self.tools.schemas()) if self.tools else 0,
            },
        ) as span:
            if tracer.include_content:
                span.add_event("agent.input", {"messages": tracer.content(messages)})
            tools = self.tools.schemas() if self.tools else None
            output_parts: list[str] = []
            last_raw: Any = None
            output_tokens = 0
            async with self._model_stream(messages, tools=tools, **model_overrides) as stream:
                async for event in stream:
                    if not isinstance(event, TextDelta):
                        continue
                    raw = getattr(event, "raw", None)
                    if event.chunk:
                        output_tokens += _estimate_text_tokens(event.chunk)
                    output_parts.append(event.chunk)
                    last_raw = raw
                    yield AgentStreamEvent(text=event.chunk, raw=raw)
            if last_raw is not None:
                await self._record_usage(last_raw)
            if self.budget is not None and self.budget.is_active() and not _provider_usage(last_raw):
                await self.budget.record_estimate(
                    model=self._model_label(),
                    input_tokens=_estimate_message_tokens(messages),
                    output_tokens=output_tokens,
                )
            self._budget_should_stop()
            output = "".join(output_parts)
            span.set_attribute("agent.output.length", len(output))
            if tracer.include_content:
                span.add_event("agent.output", {"content": tracer.content(output)})

    async def stream_events(
        self,
        prompt: str | Sequence[Message],
        **model_overrides: Any,
    ) -> AsyncIterator[AgentEvent]:
        """Stream typed agent events and execute tools through the core loop."""

        async with self.run_stream(prompt, **model_overrides) as stream:
            async for event in stream:
                yield event

    def run_stream(
        self,
        prompt: str | Sequence[Message],
        *,
        output_type: type[AgentOutputT] | None = None,
        **model_overrides: Any,
    ) -> "AgentRun[AgentOutputT]":
        """Open a typed streaming agent run.

        `run()` remains the simple awaitable one-shot API. `run_stream()` is
        the coroutine-friendly context API for callers that want events,
        context, messages, and typed output from the same run.
        """

        context = self._build_context(prompt)
        context.output_type = output_type
        context.params = dict(model_overrides)
        return AgentRun(
            self,
            context,
        )

    async def loop(self, context: Context) -> AsyncIterator[AgentEvent]:
        """Default model/tool loop.

        Override this method to customize scheduling while using the same
        Context, Stream, ToolRunner, and typed event contracts.
        """

        while context.keep_running():
            context.messages = ensure_messages(await self._compact_inflight(context.model_messages()))
            async with (
                open_stream(context=context) as stream,
                ToolRunner() as runner,
            ):
                async for event in merge(stream, runner.events()):
                    yield event
                    if isinstance(event, ToolEnd):
                        runner.schedule(context.resolve(event.tool_call))

                context.add(stream.message)
                context.add(runner.get_tool_message())

    async def _stream_context(
        self,
        context: Context,
        **model_overrides: Any,
    ) -> AsyncIterator[AgentEvent]:
        if model_overrides:
            context.params = {**(context.params or {}), **model_overrides}
        tracer = self._tracer()
        async with tracer.span(
            "agent.stream_events",
            kind="agent",
            attributes={
                "agent.name": self.name,
                "agent.max_tool_rounds": self.max_tool_rounds,
                "agent.tools.count": len(self.tools.schemas()) if self.tools else 0,
            },
        ) as span:
            if tracer.include_content:
                span.add_event("agent.input", {"messages": tracer.content(context.model_messages())})

            rounds = 0
            output_parts: list[str] = []
            output_tokens = 0
            last_raw: Any = None
            tool_names: list[str] = []
            seen_tool_ids: set[str] = set()

            async for event in self.loop(context):
                if isinstance(event, TextDelta):
                    output_parts.append(event.chunk)
                    output_tokens += _estimate_text_tokens(event.chunk)
                elif isinstance(event, ToolEnd):
                    if rounds > self.max_tool_rounds:
                        context.stop()
                        raise RuntimeError(f"Agent {self.name!r} exceeded max_tool_rounds={self.max_tool_rounds}.")
                    tool_call_id = event.tool_call.tool_call_id
                    if tool_call_id not in seen_tool_ids:
                        seen_tool_ids.add(tool_call_id)
                        tool_names.append(event.tool_call.tool_name)
                elif isinstance(event, StreamEnd):
                    rounds += 1
                    span.add_event("agent.round.end", {"round": rounds})
                    last_raw = event.raw or last_raw
                    await self._record_usage(event.raw)
                    if tool_names:
                        span.add_event(
                            "agent.tool_calls",
                            {"round": rounds, "count": len(tool_names), "names": tool_names},
                        )
                        tool_names = []
                    if self._budget_should_stop():
                        span.set_attribute("agent.aborted", True)
                        context.stop()
                yield event

            if self.budget is not None and self.budget.is_active() and not _provider_usage(last_raw):
                await self.budget.record_estimate(
                    model=self._model_label(),
                    input_tokens=_estimate_message_tokens(context.model_messages()),
                    output_tokens=output_tokens,
                )
            span.set_attribute("agent.rounds", rounds)
            output = "".join(output_parts)
            span.set_attribute("agent.output.length", len(output))
            if tracer.include_content:
                span.add_event("agent.output", {"content": tracer.content(output)})

    def _build_context(self, prompt: str | Sequence[Message]) -> Context:
        if isinstance(prompt, str):
            messages = [ensure_message(prompt)]
        else:
            messages = [ensure_message(message) for message in prompt]

        if self.system_prompt and not _has_system_message(messages):
            messages = [CoreMessage.text_message("system", self.system_prompt), *messages]
        return Context(messages=messages, tools=self.tools, client=self.client)

    def _build_messages(self, prompt: str | Sequence[Message]) -> list[Message]:
        return self._build_context(prompt).model_messages()

    def _model_stream(
        self,
        messages: list[Message],
        *,
        tools: list[dict[str, object]] | None,
        **model_overrides: Any,
    ) -> Stream[str]:
        async def source() -> AsyncIterator[Any]:
            block_id = "text"
            yield TextStart(block_id=block_id)
            async for chunk in self.client.stream_complete(messages, tools=tools, **model_overrides):
                yield TextDelta(block_id=block_id, chunk=chunk.text, raw=chunk.raw)
            yield TextEnd(block_id=block_id)
            yield StreamEnd()

        return Stream(source())

    async def _compact_inflight(self, messages: list[Message]) -> list[Message]:
        if self.message_transformer is None:
            return messages
        return await self.message_transformer.compact_messages(messages)

    async def _record_usage(self, raw_response: Any) -> None:
        if self.budget is None or not self.budget.is_active():
            return
        await self.budget.record_raw(model=self._model_label(), raw=raw_response)

    def _budget_should_stop(self) -> bool:
        if self.budget is None or not self.budget.is_active():
            return False
        return self.budget.enforce()

    def _model_label(self) -> str:
        model_name = getattr(self.client, "model_name", None)
        if model_name:
            return str(model_name)
        settings = getattr(self.client, "settings", None)
        if settings is not None:
            model = getattr(settings, "model", None)
            if model:
                return str(model)
            name = getattr(settings, "name", None)
            if name:
                return str(name)
        return self.name

    def _tracer(self) -> Tracer:
        if self.tracer is None:
            self.tracer = NoOpTracer()
        return self.tracer


class AgentRun(Generic[AgentOutputT]):
    """Async context manager for a typed agent run."""

    def __init__(
        self,
        agent: Agent,
        context: Context,
    ) -> None:
        self._agent = agent
        self._context = context
        self._source: AsyncIterator[AgentEvent] | None = None

    async def __aenter__(self) -> Self:
        self._source = self._agent._stream_context(self._context)
        return self

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> bool:
        if self._source is not None:
            aclose = getattr(self._source, "aclose", None)
            if aclose is not None:
                await aclose()
        self._source = None
        return False

    def __aiter__(self) -> Self:
        return self

    async def __anext__(self) -> AgentEvent:
        if self._source is None:
            self._source = self._agent._stream_context(self._context)
        return await self._source.__anext__()

    @property
    def context(self) -> Context:
        return self._context

    @property
    def messages(self) -> list[CoreMessage]:
        return self._context.messages

    @property
    def text(self) -> str:
        return self._final_message().text

    @property
    def output(self) -> AgentOutputT:
        return cast("AgentOutputT", self._final_message().get_output(self._context.output_type))

    def _final_message(self) -> CoreMessage:
        for message in reversed(self._context.messages):
            if message.role == "assistant" and not message.tool_calls:
                return message
        raise ValueError("Agent run has no final assistant message yet.")


def _has_system_message(messages: Sequence[CoreMessage]) -> bool:
    return bool(messages and messages[0].role == "system")


def _estimate_text_tokens(text: str) -> int:
    if not text:
        return 0
    return max(1, len(str(text).split()))


def _estimate_message_tokens(messages: Sequence[Message]) -> int:
    total = 0
    for message in messages:
        total += _estimate_text_tokens(json.dumps(message, ensure_ascii=False, default=str))
    return total


def _provider_usage(raw: Any) -> dict[str, int]:
    usage = getattr(raw, "usage", None)
    if usage is None and isinstance(raw, dict):
        usage = raw.get("usage")
    if usage is None:
        return {}
    out: dict[str, int] = {}
    for key in (
        "prompt_tokens",
        "completion_tokens",
        "total_tokens",
        "reasoning_tokens",
        "cache_read_tokens",
        "cache_write_tokens",
    ):
        value = usage.get(key) if isinstance(usage, dict) else getattr(usage, key, None)
        if value is None:
            continue
        try:
            out[key] = int(value)
        except (TypeError, ValueError):
            continue
    return out
