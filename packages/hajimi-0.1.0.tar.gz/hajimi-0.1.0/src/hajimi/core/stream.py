"""Async stream wrapper that aggregates typed events into a Message."""

from __future__ import annotations

import contextlib
from collections.abc import AsyncGenerator, AsyncIterator, Sequence
from typing import Any, Self, cast

import pydantic

from hajimi.core import events
from hajimi.core.adapters.openai_tools import assistant_message, extract_tool_calls
from hajimi.core.context import Context
from hajimi.core.messages import Message, ReasoningPart, TextPart, ToolCallPart, ensure_message
from hajimi.core.types import Message as ChatMessage
from hajimi.core.types import ModelClient


class Stream[T = str]:
    def __init__(
        self,
        source: AsyncGenerator[events.Event],
        *,
        seed_message: Message | None = None,
        output_type: type[T] | None = None,
    ) -> None:
        self._source = source
        self._message = seed_message or Message(role="assistant", parts=[])
        self._parts: dict[str, Any] = {}
        self._output_type = cast("type[pydantic.BaseModel] | None", output_type)

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> bool:
        await self.aclose()
        return False

    def __aiter__(self) -> Self:
        return self

    async def __anext__(self) -> events.Event:
        event = await self._source.__anext__()
        return self._aggregate(event)

    async def aclose(self) -> None:
        await self._source.aclose()

    @property
    def message(self) -> Message:
        return self._message

    @property
    def text(self) -> str:
        return self._message.text

    @property
    def output(self) -> T:
        return cast("T", self._message.get_output(self._output_type))

    def _aggregate(self, event: events.Event) -> events.Event:
        if event.replay:
            return event.model_copy(update={"message": self._message})
        match event:
            case events.TextStart(block_id=block_id):
                part = TextPart(id=block_id or TextPart(text="").id, text="")
                self._message.parts.append(part)
                self._parts[part.id] = part
            case events.TextDelta(block_id=block_id, chunk=chunk):
                part = self._parts.get(block_id)
                if isinstance(part, TextPart):
                    part.text += chunk
                else:
                    part = TextPart(id=block_id or TextPart(text="").id, text=chunk)
                    self._message.parts.append(part)
                    self._parts[part.id] = part
            case events.ReasoningStart(block_id=block_id):
                part = ReasoningPart(id=block_id or ReasoningPart(text="").id, text="")
                self._message.parts.append(part)
                self._parts[part.id] = part
            case events.ReasoningDelta(block_id=block_id, chunk=chunk):
                part = self._parts.get(block_id)
                if isinstance(part, ReasoningPart):
                    part.text += chunk
            case events.ToolStart(tool_call_id=call_id, tool_name=name):
                part = ToolCallPart(tool_call_id=call_id, tool_name=name, tool_args="")
                self._message.parts.append(part)
                self._parts[call_id] = part
            case events.ToolDelta(tool_call_id=call_id, chunk=chunk):
                part = self._parts.get(call_id)
                if isinstance(part, ToolCallPart):
                    part.tool_args += chunk
            case events.ToolEnd(tool_call_id=call_id):
                part = self._parts.get(call_id)
                if isinstance(part, ToolCallPart):
                    return event.model_copy(update={"message": self._message, "tool_call": part})
            case events.StreamEnd():
                pass
        return event.model_copy(update={"message": self._message})


def stream[T = str](
    messages: Sequence[ChatMessage] | None = None,
    *,
    context: Context | None = None,
    client: ModelClient | None = None,
    tools: list[dict[str, object]] | None = None,
    output_type: type[T] | None = None,
    **model_overrides: Any,
) -> contextlib.AbstractAsyncContextManager[Stream[T]]:
    """Open a model event stream from a context or raw chat messages."""

    if context is not None:
        if messages is not None or client is not None or tools is not None:
            raise TypeError("stream() takes either context= or messages/client/tools, not both.")
        if context.client is None:
            raise ValueError("Context has no model client. Build it through Agent.run_stream() or set context.client.")
        client = context.client
        messages = context.model_messages()
        tools = context.tools.schemas() if context.tools else None
        if output_type is None:
            output_type = context.output_type
        params = context.params
        if isinstance(params, dict):
            model_overrides = {**params, **model_overrides}
    elif messages is None or client is None:
        raise TypeError("stream() requires either context= or both messages and client.")

    return _stream(
        client=client,
        messages=list(messages),
        tools=tools,
        output_type=cast("type[T] | None", output_type),
        model_overrides=model_overrides,
    )


@contextlib.asynccontextmanager
async def _stream[T](
    *,
    client: ModelClient,
    messages: list[ChatMessage],
    tools: list[dict[str, object]] | None,
    output_type: type[T] | None,
    model_overrides: dict[str, Any],
) -> AsyncIterator[Stream[T]]:
    stream = Stream(
        _source(client, messages, tools=tools, **model_overrides),
        output_type=output_type,
    )
    try:
        yield stream
    finally:
        await stream.aclose()


async def _source(
    client: ModelClient,
    messages: list[ChatMessage],
    *,
    tools: list[dict[str, object]] | None,
    **model_overrides: Any,
) -> AsyncGenerator[events.Event]:
    result = await client.complete(messages, tools=tools, **model_overrides)
    choice_message = result.raw.choices[0].message
    assistant = ensure_message(assistant_message(choice_message, result.text, extract_tool_calls(choice_message)))
    block_id = "text"
    if assistant.text:
        yield events.TextStart(block_id=block_id)
        yield events.TextDelta(block_id=block_id, chunk=result.text)
        yield events.TextEnd(block_id=block_id)
    for part in assistant.tool_calls:
        yield events.ToolStart(tool_call_id=part.tool_call_id, tool_name=part.tool_name)
        if part.tool_args:
            yield events.ToolDelta(tool_call_id=part.tool_call_id, chunk=part.tool_args)
        yield events.ToolEnd(tool_call_id=part.tool_call_id, tool_call=part)
    yield events.StreamEnd(raw=result.raw)
