"""Dynamic tool catalog and BM25 search."""

from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass
from typing import Any

from hajimi.default_tools import TOOL_SEARCH_DESCRIPTION, TOOL_SEARCH_NAME
from hajimi.tool.registry import ToolRegistry
from hajimi.tool.types import Tool

_TOKEN_RE = re.compile(r"[A-Za-z0-9_]+")


@dataclass(frozen=True, slots=True)
class ToolSearchResult:
    name: str
    description: str
    score: float

    def to_dict(self, *, loaded: bool = False) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "score": round(self.score, 4),
            "loaded": loaded,
        }


@dataclass(frozen=True, slots=True)
class ToolSearchEntry:
    tool: Tool
    text: str
    tokens: tuple[str, ...]
    frequencies: Counter[str]

    @classmethod
    def from_tool(cls, tool: Tool) -> "ToolSearchEntry":
        text = _tool_text(tool)
        tokens = tuple(_tokenize(text))
        return cls(
            tool=tool,
            text=text,
            tokens=tokens,
            frequencies=Counter(tokens),
        )


class ToolCatalog:
    """Searchable collection of tools hidden from the initial model context."""

    def __init__(self, tools: list[Tool]) -> None:
        self._entries = [ToolSearchEntry.from_tool(tool) for tool in tools]
        self._by_name = {entry.tool.name: entry.tool for entry in self._entries}
        self._avg_len = (
            sum(len(entry.tokens) for entry in self._entries) / len(self._entries)
            if self._entries
            else 0.0
        )
        self._doc_freq = Counter(
            token
            for entry in self._entries
            for token in set(entry.tokens)
        )

    def __bool__(self) -> bool:
        return bool(self._entries)

    def search(self, query: str, *, limit: int = 8) -> list[ToolSearchResult]:
        query_tokens = _tokenize(query)
        scored = [
            (self._score(entry, query_tokens), entry)
            for entry in self._entries
        ]
        ranked = sorted(
            ((score, entry) for score, entry in scored if score > 0),
            key=lambda item: (-item[0], item[1].tool.name),
        )
        return [
            ToolSearchResult(
                name=entry.tool.name,
                description=entry.tool.description,
                score=score,
            )
            for score, entry in ranked[:limit]
        ]

    def get(self, name: str) -> Tool:
        try:
            return self._by_name[name]
        except KeyError as exc:
            raise KeyError(f"Unknown catalog tool {name!r}.") from exc

    def _score(self, entry: ToolSearchEntry, query_tokens: list[str]) -> float:
        if not query_tokens or not entry.tokens:
            return 0.0

        k1 = 1.5
        b = 0.75
        score = 0.0
        doc_count = len(self._entries)
        doc_len = len(entry.tokens)

        for token in query_tokens:
            freq = entry.frequencies[token]
            if freq == 0:
                continue
            doc_freq = self._doc_freq[token]
            idf = math.log(1 + (doc_count - doc_freq + 0.5) / (doc_freq + 0.5))
            denominator = freq + k1 * (1 - b + b * doc_len / self._avg_len)
            score += idf * (freq * (k1 + 1) / denominator)
        return score


def create_tool_search_tool(
    catalog: ToolCatalog,
    registry: ToolRegistry,
    *,
    name: str = TOOL_SEARCH_NAME,
    max_results: int = 8,
) -> Tool:
    async def handler(query: str, limit: int | None = None) -> dict[str, Any]:
        active_limit = min(limit or max_results, max_results)
        results = catalog.search(query, limit=active_limit)
        loaded: list[str] = []
        already_loaded: list[str] = []
        for result in results:
            tool = catalog.get(result.name)
            if registry.has(tool.name):
                already_loaded.append(tool.name)
                continue
            try:
                registry.register(tool)
                loaded.append(tool.name)
            except ValueError:
                already_loaded.append(tool.name)
        return {
            "query": query,
            "loaded": loaded,
            "already_loaded": already_loaded,
            "results": [
                result.to_dict(loaded=result.name in loaded or result.name in already_loaded)
                for result in results
            ],
        }

    return Tool(
        name=name,
        description=TOOL_SEARCH_DESCRIPTION,
        parameters={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Task or capability that needs a tool.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum matches to load.",
                },
            },
            "required": ["query"],
        },
        handler=handler,
    )


def _tool_text(tool: Tool) -> str:
    function = tool.openai_schema["function"]
    parameters = function.get("parameters", {})
    properties = parameters.get("properties", {}) if isinstance(parameters, dict) else {}
    parameter_names = " ".join(properties) if isinstance(properties, dict) else ""
    return f"{tool.name} {tool.description} {parameter_names}"


def _tokenize(text: str) -> list[str]:
    tokens: list[str] = []
    for match in _TOKEN_RE.finditer(text.lower()):
        raw = match.group(0)
        tokens.append(raw)
        tokens.extend(part for part in raw.split("_") if part)
    return tokens
