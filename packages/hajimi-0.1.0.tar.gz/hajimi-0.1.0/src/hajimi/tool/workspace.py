"""Built-in workspace file, search, and shell tools."""

from __future__ import annotations

import fnmatch
import re
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from hajimi.config import AgentWorkspaceToolsSettings
from hajimi.sandbox import SandboxEnvironment, create_e2b_sandbox, create_local_sandbox
from hajimi.tool.types import Tool


@dataclass(frozen=True, slots=True)
class WorkspaceToolbox:
    """Factory for workspace-scoped model tools."""

    environment: SandboxEnvironment
    settings: AgentWorkspaceToolsSettings

    def tools(self) -> list[Tool]:
        tools = [
            Tool(
                name=self.settings.read_tool_name,
                description=self.settings.read_tool_description,
                parameters=_read_schema(),
                handler=self.read,
            ),
            Tool(
                name=self.settings.grep_tool_name,
                description=self.settings.grep_tool_description,
                parameters=_grep_schema(),
                handler=self.grep,
            ),
            Tool(
                name=self.settings.glob_tool_name,
                description=self.settings.glob_tool_description,
                parameters=_glob_schema(),
                handler=self.glob,
            ),
        ]
        if self.settings.allow_write:
            tools.extend(
                [
                    Tool(
                        name=self.settings.write_tool_name,
                        description=self.settings.write_tool_description,
                        parameters=_write_schema(),
                        handler=self.write,
                    ),
                    Tool(
                        name=self.settings.edit_tool_name,
                        description=self.settings.edit_tool_description,
                        parameters=_edit_schema(),
                        handler=self.edit,
                    ),
                ]
            )
        if self.settings.allow_shell:
            tools.append(
                Tool(
                    name=self.settings.bash_tool_name,
                    description=self.settings.bash_tool_description,
                    parameters=_bash_schema(),
                    handler=self.bash,
                )
            )
        return tools

    async def read(self, path: str, offset: int = 0, limit: int | None = None) -> dict[str, Any]:
        stat = await self.environment.stat(path)
        if stat.type == "directory":
            entries = [entry.to_dict() for entry in await self.environment.list_dir(path)]
            max_entries = _positive_or_default(limit, self.settings.max_search_results)
            return {
                "path": stat.path,
                "entries": entries[:max_entries],
                "truncated": len(entries) > max_entries,
            }
        text = await self.environment.read_text(path)
        start = max(0, offset)
        max_chars = _positive_or_default(limit, self.settings.max_read_chars)
        content = text[start : start + max_chars]
        return {
            "path": stat.path,
            "content": content,
            "offset": start,
            "bytes": len(text.encode("utf-8")),
            "truncated": start + len(content) < len(text),
        }

    async def write(self, path: str, content: str) -> dict[str, Any]:
        self._require_write()
        await self.environment.write_text(path, content)
        stat = await self.environment.stat(path)
        return {
            "path": stat.path,
            "bytes": len(content.encode("utf-8")),
        }

    async def edit(self, path: str, old: str, new: str, expected_replacements: int = 1) -> dict[str, Any]:
        self._require_write()
        if old == "":
            raise ValueError("old must not be empty.")
        stat = await self.environment.stat(path)
        text = await self.environment.read_text(path)
        replacements = text.count(old)
        if expected_replacements >= 0 and replacements != expected_replacements:
            raise ValueError(
                f"Expected {expected_replacements} replacement(s), found {replacements}."
            )
        updated = text.replace(old, new)
        await self.environment.write_text(path, updated)
        return {
            "path": stat.path,
            "replacements": replacements,
            "bytes": len(updated.encode("utf-8")),
        }

    async def grep(
        self,
        pattern: str,
        path: str = ".",
        glob: str | None = None,
        ignore_case: bool = False,
        max_results: int | None = None,
    ) -> dict[str, Any]:
        regex = re.compile(pattern, re.IGNORECASE if ignore_case else 0)
        limit = _positive_or_default(max_results, self.settings.max_search_results)
        matches: list[dict[str, Any]] = []
        for file_path in await self.environment.iter_files(path):
            if glob and not fnmatch.fnmatch(file_path, glob):
                continue
            try:
                text = await self.environment.read_text(file_path)
            except UnicodeDecodeError:
                continue
            for line_number, line in enumerate(text.splitlines(), start=1):
                if not regex.search(line):
                    continue
                matches.append({"path": file_path, "line": line_number, "text": line})
                if len(matches) >= limit:
                    return {"matches": matches, "truncated": True}
        return {"matches": matches, "truncated": False}

    async def glob(self, pattern: str, path: str = ".", max_results: int | None = None) -> dict[str, Any]:
        limit = _positive_or_default(max_results, self.settings.max_search_results)
        matches: list[str] = []
        for file_path in await self.environment.iter_files(path):
            if fnmatch.fnmatch(file_path, pattern):
                matches.append(file_path)
                if len(matches) >= limit:
                    return {"matches": matches, "truncated": True}
        return {"matches": matches, "truncated": False}

    async def bash(self, command: str, timeout_seconds: float = 30.0) -> dict[str, Any]:
        if not self.settings.allow_shell:
            raise PermissionError("Workspace shell tool is disabled.")
        argv = shlex.split(command)
        if not argv:
            raise ValueError("command must not be empty.")
        allowed = set(self.settings.allowed_shell_commands)
        if allowed and argv[0] not in allowed:
            raise PermissionError(f"Command {argv[0]!r} is not allow-listed.")
        result = await self.environment.exec(command, timeout_seconds)
        return {
            "command": command,
            "exit_code": result.exit_code,
            "stdout": _truncate_output(result.stdout, self.settings.max_output_chars),
            "stderr": _truncate_output(result.stderr, self.settings.max_output_chars),
            "timed_out": result.timed_out,
        }

    def _require_write(self) -> None:
        if not self.settings.allow_write:
            raise PermissionError("Workspace write tools are disabled.")


def create_workspace_tools(
    repo_path: str | Path,
    settings: AgentWorkspaceToolsSettings,
    environment: SandboxEnvironment | None = None,
) -> list[Tool]:
    if not settings.enabled:
        return []
    sandbox = environment or _create_workspace_environment(repo_path, settings)
    return WorkspaceToolbox(environment=sandbox, settings=settings).tools()


def create_workspace_environment(
    repo_path: str | Path,
    settings: AgentWorkspaceToolsSettings,
) -> SandboxEnvironment:
    provider = settings.sandbox_provider.lower()
    match provider:
        case "local":
            return create_local_sandbox(
                repo_path,
                root=settings.root,
                allowed_shell_commands=settings.allowed_shell_commands,
            )
        case "e2b":
            return create_e2b_sandbox(
                root=_e2b_root(settings.root),
                sandbox_id=settings.e2b_sandbox_id,
                template=settings.e2b_template,
                timeout=settings.e2b_timeout,
                allow_internet_access=settings.e2b_allow_internet_access,
            )
        case _:
            raise ValueError(f"Unknown workspace sandbox provider {settings.sandbox_provider!r}.")


def _e2b_root(root: Path | None) -> str:
    if root is None:
        return "/home/user"
    root_text = root.as_posix()
    return root_text if root.is_absolute() else f"/home/user/{root_text}"


def _positive_or_default(value: int | None, default: int) -> int:
    if value is None or value <= 0:
        return default
    return value


def _truncate_output(value: str, max_chars: int) -> str:
    if len(value) <= max_chars:
        return value
    return f"{value[:max_chars]}...<truncated>"


def _read_schema() -> dict[str, object]:
    return {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Workspace-relative file or directory path."},
            "offset": {"type": "integer", "description": "Character offset to start reading."},
            "limit": {"type": "integer", "description": "Maximum characters or directory entries to return."},
        },
        "required": ["path"],
    }


def _write_schema() -> dict[str, object]:
    return {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Workspace-relative file path."},
            "content": {"type": "string", "description": "UTF-8 content to write."},
        },
        "required": ["path", "content"],
    }


def _edit_schema() -> dict[str, object]:
    return {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Workspace-relative file path."},
            "old": {"type": "string", "description": "Exact text to replace."},
            "new": {"type": "string", "description": "Replacement text."},
            "expected_replacements": {
                "type": "integer",
                "description": "Expected match count; use -1 to replace all without checking.",
            },
        },
        "required": ["path", "old", "new"],
    }


def _grep_schema() -> dict[str, object]:
    return {
        "type": "object",
        "properties": {
            "pattern": {"type": "string", "description": "Python regex pattern."},
            "path": {"type": "string", "description": "File or directory to search."},
            "glob": {"type": "string", "description": "Optional file glob filter."},
            "ignore_case": {"type": "boolean", "description": "Case-insensitive search."},
            "max_results": {"type": "integer", "description": "Maximum matches to return."},
        },
        "required": ["pattern"],
    }


def _glob_schema() -> dict[str, object]:
    return {
        "type": "object",
        "properties": {
            "pattern": {"type": "string", "description": "Glob pattern matched against relative paths."},
            "path": {"type": "string", "description": "Directory to search."},
            "max_results": {"type": "integer", "description": "Maximum paths to return."},
        },
        "required": ["pattern"],
    }


def _bash_schema() -> dict[str, object]:
    return {
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "Shell-like command parsed with shlex."},
            "timeout_seconds": {"type": "number", "description": "Maximum runtime in seconds."},
        },
        "required": ["command"],
    }


_create_workspace_environment = create_workspace_environment


__all__ = ["WorkspaceToolbox", "create_workspace_environment", "create_workspace_tools"]
