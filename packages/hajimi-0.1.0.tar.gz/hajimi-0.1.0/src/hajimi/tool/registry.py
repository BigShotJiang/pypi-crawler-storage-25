"""Tool registry."""

from hajimi.corekit.registry import ToolRegistry

__all__ = ["ToolRegistry"]
