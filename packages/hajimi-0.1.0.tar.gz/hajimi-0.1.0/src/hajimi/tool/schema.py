"""Callable-to-tool-schema mapper."""

from hajimi.corekit.schema import schema_from_callable, tool

__all__ = ["schema_from_callable", "tool"]
