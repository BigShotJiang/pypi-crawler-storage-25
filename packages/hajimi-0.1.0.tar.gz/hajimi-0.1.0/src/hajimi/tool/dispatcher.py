"""Tool dispatcher."""

from hajimi.corekit.dispatcher import ToolDispatcher

__all__ = ["ToolDispatcher"]
