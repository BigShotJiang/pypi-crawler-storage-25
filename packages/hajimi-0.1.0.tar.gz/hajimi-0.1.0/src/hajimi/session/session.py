"""High-level AgentSession wrapper."""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from hajimi.config import ContextSettings
from hajimi.corekit import Agent, AgentStreamEvent
from hajimi.session.context import ContextManager, Summarizer
from hajimi.session.models import (
    Message,
    MessageRecord,
    SessionRunResult,
    TokenUsage,
    new_id,
)
from hajimi.session.store import SessionStore
from hajimi.session.tokens import TokenEstimator, provider_usage_from_raw


@dataclass(slots=True)
class AgentSession:
    """Durable session wrapper around `Agent`.

    `Agent` stays responsible for model and tool execution. This wrapper
    owns history persistence, replay, edit markers, fork, compaction, and token
    accounting.
    """

    agent: Agent
    store: SessionStore
    session_id: str
    context: ContextManager

    @classmethod
    async def create(
        cls,
        *,
        agent: Agent,
        store: SessionStore,
        name: str | None = None,
        model_name: str | None = None,
        context_settings: ContextSettings | None = None,
        summarizer: Summarizer | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> "AgentSession":
        settings = context_settings or ContextSettings()
        estimator = TokenEstimator(
            tokenizer=settings.tokenizer,
            hash_components=settings.cache.hash_components,
        )
        session = await store.create_session(
            name=name or agent.name,
            agent_name=agent.name,
            model_name=model_name,
            metadata=metadata,
        )
        return cls(
            agent=agent,
            store=store,
            session_id=session.id,
            context=ContextManager(settings, estimator, summarizer=summarizer),
        )

    @classmethod
    async def resume(
        cls,
        *,
        agent: Agent,
        store: SessionStore,
        session_id: str,
        context_settings: ContextSettings | None = None,
        summarizer: Summarizer | None = None,
    ) -> "AgentSession":
        await store.get_session(session_id)
        settings = context_settings or ContextSettings()
        estimator = TokenEstimator(
            tokenizer=settings.tokenizer,
            hash_components=settings.cache.hash_components,
        )
        return cls(
            agent=agent,
            store=store,
            session_id=session_id,
            context=ContextManager(settings, estimator, summarizer=summarizer),
        )

    async def run(self, prompt: str | Message | list[Message], **model_overrides: Any) -> SessionRunResult:
        snapshot = await self.store.snapshot(self.session_id)
        context_build = await self.context.build(snapshot.messages)
        prompt_messages = _prompt_messages(prompt)
        new_user_records = [
            MessageRecord.from_message(
                self.session_id,
                message,
                source="user",
            )
            for message in prompt_messages
        ]
        run_messages = _with_system_prompt(
            [*context_build.messages, *prompt_messages],
            self.agent.system_prompt,
        )
        result = await self.agent.run(run_messages, **model_overrides)
        new_records = _new_result_records(
            self.session_id,
            result.messages,
            base_count=len(run_messages),
        )

        if context_build.compacted:
            summary = context_build.summary_record
            kept = context_build.kept_messages
            if summary is None:
                summary, kept = await self.context.compact(snapshot.messages)
            await self.store.append(
                self.session_id,
                "context.compacted",
                self.context.compacted_event_payload(summary, kept),
            )

        for record in new_user_records:
            await self.store.append_message(record)
        for record in new_records:
            await self.store.append_message(record)

        provider_usage = provider_usage_from_raw(result.raw)
        if not self.context.settings.cache.record_provider_cache:
            provider_usage = {
                key: value
                for key, value in provider_usage.items()
                if not key.startswith("cache_")
            }
        usage = self.context.estimator.components(
            system_prompt=None,
            messages=run_messages,
            tools=self.agent.tools,
            summary=context_build.summary,
            provider=provider_usage,
        )
        await self.store.append(self.session_id, "token.usage", {"usage": usage.to_dict()})
        await self.store.append(
            self.session_id,
            "run.completed",
            {
                "content_length": len(result.content),
                "new_message_ids": [record.id for record in [*new_user_records, *new_records]],
                "compacted": context_build.compacted,
            },
        )
        return SessionRunResult(
            content=result.content,
            messages=result.messages,
            new_messages=[*new_user_records, *new_records],
            token_usage=usage,
            compacted=context_build.compacted,
            raw=result.raw,
        )

    async def stream(self, prompt: str | Message | list[Message], **model_overrides: Any) -> AsyncIterator[AgentStreamEvent]:
        snapshot = await self.store.snapshot(self.session_id)
        context_build = await self.context.build(snapshot.messages)
        prompt_messages = _prompt_messages(prompt)
        run_messages = _with_system_prompt(
            [*context_build.messages, *prompt_messages],
            self.agent.system_prompt,
        )
        output_parts: list[str] = []
        last_raw: Any = None

        async for event in self.agent.stream(run_messages, **model_overrides):
            output_parts.append(event.text)
            last_raw = event.raw
            yield event

        if context_build.compacted:
            summary = context_build.summary_record
            kept = context_build.kept_messages
            if summary is None:
                summary, kept = await self.context.compact(snapshot.messages)
            await self.store.append(
                self.session_id,
                "context.compacted",
                self.context.compacted_event_payload(summary, kept),
            )

        user_records = [
            MessageRecord.from_message(self.session_id, message, source="user")
            for message in prompt_messages
        ]
        assistant_record = MessageRecord.from_message(
            self.session_id,
            {"role": "assistant", "content": "".join(output_parts)},
            source="agent",
        )
        for record in [*user_records, assistant_record]:
            await self.store.append_message(record)
        usage = self.context.estimator.components(
            system_prompt=None,
            messages=run_messages,
            tools=self.agent.tools,
            summary=context_build.summary,
        )
        await self.store.append(self.session_id, "token.usage", {"usage": usage.to_dict()})
        await self.store.append(
            self.session_id,
            "stream.completed",
            {
                "content_length": len(assistant_record.content),
                "chunks": len(output_parts),
                "new_message_ids": [record.id for record in [*user_records, assistant_record]],
                "last_raw": str(last_raw),
                "compacted": context_build.compacted,
            },
        )

    async def visible_messages(self) -> list[MessageRecord]:
        return (await self.store.snapshot(self.session_id)).messages

    async def edit_message(self, message_id: str, content: str) -> MessageRecord:
        snapshot = await self.store.snapshot(self.session_id)
        original = _find_message(snapshot.messages, message_id)
        edited = MessageRecord.from_message(
            self.session_id,
            {
                "role": original.role,
                "content": content,
            },
            source=original.source,
            message_id=new_id("msg"),
            metadata={**original.metadata, "edited_from": original.id},
        )
        await self.store.append(
            self.session_id,
            "message.edited",
            {
                "message_id": message_id,
                "message": edited.to_dict(),
            },
        )
        return edited

    async def delete_message(self, message_id: str) -> None:
        _find_message((await self.store.snapshot(self.session_id)).messages, message_id)
        await self.store.append(self.session_id, "message.deleted", {"message_id": message_id})

    async def restore_message(self, message_id: str) -> None:
        await self.store.append(self.session_id, "session.restored", {"message_id": message_id})

    async def rollback(self, *, message_id: str) -> None:
        _find_message((await self.store.snapshot(self.session_id)).messages, message_id)
        await self.store.append(self.session_id, "session.rollback", {"message_id": message_id})

    async def fork(
        self,
        *,
        name: str | None = None,
        until_message_id: str | None = None,
    ) -> "AgentSession":
        forked = await self.store.fork(
            self.session_id,
            name=name,
            until_message_id=until_message_id,
        )
        return await self.resume(
            agent=self.agent,
            store=self.store,
            session_id=forked.id,
            context_settings=self.context.settings,
            summarizer=self.context.summarizer,
        )

    async def token_report(self) -> TokenUsage:
        messages = [
            message.to_message(tool_output_max_chars=self.context.settings.tool_output_max_chars)
            for message in await self.visible_messages()
        ]
        return self.context.estimator.components(
            system_prompt=self.agent.system_prompt,
            messages=messages,
            tools=self.agent.tools,
        )


def create_session_store(context_settings: ContextSettings, repo_path: Any) -> SessionStore:
    return SessionStore(
        sqlite_path=context_settings.resolve_sqlite_path(repo_path),
        events_dir=context_settings.resolve_events_dir(repo_path),
        database_url=context_settings.database_url,
    )


def _prompt_messages(prompt: str | Message | list[Message]) -> list[Message]:
    if isinstance(prompt, str):
        return [{"role": "user", "content": prompt}]
    if isinstance(prompt, dict):
        return [dict(prompt)]
    return [dict(message) for message in prompt]


def _with_system_prompt(messages: list[Message], system_prompt: str | None) -> list[Message]:
    if not system_prompt:
        return messages
    if messages and messages[0].get("role") == "system" and messages[0].get("content") == system_prompt:
        return messages
    return [{"role": "system", "content": system_prompt}, *messages]


def _new_result_records(session_id: str, messages: list[Message], *, base_count: int) -> list[MessageRecord]:
    return [
        MessageRecord.from_message(session_id, message, source="agent")
        for message in messages[base_count:]
    ]


def _find_message(messages: list[MessageRecord], message_id: str) -> MessageRecord:
    for message in messages:
        if message.id == message_id:
            return message
    raise KeyError(f"Unknown message {message_id!r}.")
