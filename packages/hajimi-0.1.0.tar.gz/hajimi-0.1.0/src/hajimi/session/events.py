"""Append-only session events."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from hajimi.session.models import MessageRecord, SessionMetadata, TokenUsage, from_iso, to_iso, utc_now

type SessionEventType = Literal[
    "session.created",
    "session.forked",
    "message.appended",
    "message.edited",
    "message.deleted",
    "session.rollback",
    "session.restored",
    "context.compacted",
    "token.usage",
    "run.completed",
    "stream.completed",
    "runtime.route",
]


@dataclass(frozen=True, slots=True)
class SessionEvent:
    id: int
    session_id: str
    type: SessionEventType
    created_at: Any
    payload: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "type": self.type,
            "created_at": to_iso(self.created_at),
            "payload": self.payload,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SessionEvent":
        return cls(
            id=int(data["id"]),
            session_id=str(data["session_id"]),
            type=data["type"],
            created_at=from_iso(str(data["created_at"])),
            payload=dict(data.get("payload", {})),
        )


def make_event(
    event_id: int,
    session_id: str,
    event_type: SessionEventType,
    payload: dict[str, Any] | None = None,
) -> SessionEvent:
    return SessionEvent(
        id=event_id,
        session_id=session_id,
        type=event_type,
        created_at=utc_now(),
        payload=dict(payload or {}),
    )


def session_created_payload(metadata: SessionMetadata) -> dict[str, Any]:
    return {"session": metadata.to_dict()}


def message_payload(message: MessageRecord) -> dict[str, Any]:
    return {"message": message.to_dict()}


def token_usage_payload(usage: TokenUsage) -> dict[str, Any]:
    return {"usage": usage.to_dict()}
