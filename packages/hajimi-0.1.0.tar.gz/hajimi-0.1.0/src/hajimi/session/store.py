"""Session event storage with JSONL source logs and ORM indexes."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import anyio
from sqlalchemy import Engine
from sqlalchemy.engine import make_url
from sqlalchemy.orm import Session, sessionmaker

from hajimi.session.events import SessionEvent, SessionEventType, make_event
from hajimi.session.models import MessageRecord, SessionMetadata, new_id, to_iso, utc_now
from hajimi.session.orm import EventRow, SessionRow, create_schema, create_session_engine, create_session_factory, next_event_id


@dataclass(slots=True)
class SessionSnapshot:
    metadata: SessionMetadata
    messages: list[MessageRecord]
    events: list[SessionEvent]


@dataclass(slots=True)
class SessionStore:
    sqlite_path: Path
    events_dir: Path
    database_url: str | None = None
    _lock: anyio.Lock | None = None
    _engine: Engine | None = None
    _session_factory: sessionmaker[Session] | None = None

    async def initialize(self) -> None:
        await anyio.Path(self.sqlite_path.parent).mkdir(parents=True, exist_ok=True)
        await anyio.Path(self.events_dir).mkdir(parents=True, exist_ok=True)
        if self._session_factory is None:
            engine = create_session_engine(_database_url(self.sqlite_path, self.database_url))
            self._engine = engine
            self._session_factory = create_session_factory(engine)
            await anyio.to_thread.run_sync(create_schema, engine)
        if self._lock is None:
            self._lock = anyio.Lock()

    async def create_session(
        self,
        *,
        name: str,
        agent_name: str,
        model_name: str | None = None,
        parent_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        session_id: str | None = None,
    ) -> SessionMetadata:
        await self.initialize()
        now = utc_now()
        session = SessionMetadata(
            id=session_id or new_id("sess"),
            name=name,
            agent_name=agent_name,
            model_name=model_name,
            parent_id=parent_id,
            created_at=now,
            updated_at=now,
            metadata=dict(metadata or {}),
        )
        await anyio.to_thread.run_sync(_upsert_session, self._factory(), session)
        await self.append(
            session.id,
            "session.created" if parent_id is None else "session.forked",
            {"session": session.to_dict()},
        )
        return session

    async def append(
        self,
        session_id: str,
        event_type: SessionEventType,
        payload: dict[str, Any] | None = None,
    ) -> SessionEvent:
        await self.initialize()
        lock = self._lock or anyio.Lock()
        async with lock:
            event_id = await anyio.to_thread.run_sync(_next_event_id, self._factory(), session_id)
            event = make_event(event_id, session_id, event_type, payload)
            line = json.dumps(event.to_dict(), ensure_ascii=False, default=str) + "\n"
            path = self._events_path(session_id)
            async with await anyio.open_file(path, "a", encoding="utf-8") as file:
                await file.write(line)
            await anyio.to_thread.run_sync(_insert_event_index, self._factory(), event)
            await anyio.to_thread.run_sync(_touch_session, self._factory(), session_id, event.created_at)
            return event

    async def append_message(self, message: MessageRecord) -> SessionEvent:
        return await self.append(message.session_id, "message.appended", {"message": message.to_dict()})

    async def get_session(self, session_id: str) -> SessionMetadata:
        await self.initialize()
        row = await anyio.to_thread.run_sync(_get_session, self._factory(), session_id)
        if row is None:
            raise KeyError(f"Unknown session {session_id!r}.")
        return SessionMetadata.from_dict(row)

    async def read_events(self, session_id: str) -> list[SessionEvent]:
        await self.initialize()
        path = self._events_path(session_id)
        if not await anyio.Path(path).exists():
            return []
        text = await anyio.Path(path).read_text(encoding="utf-8")
        return [
            SessionEvent.from_dict(json.loads(line))
            for line in text.splitlines()
            if line.strip()
        ]

    async def snapshot(self, session_id: str) -> SessionSnapshot:
        metadata = await self.get_session(session_id)
        events = await self.read_events(session_id)
        messages = replay_messages(events)
        return SessionSnapshot(metadata=metadata, messages=messages, events=events)

    async def fork(
        self,
        source_session_id: str,
        *,
        name: str | None = None,
        until_event_id: int | None = None,
        until_message_id: str | None = None,
    ) -> SessionMetadata:
        source = await self.snapshot(source_session_id)
        target = await self.create_session(
            name=name or f"{source.metadata.name} fork",
            agent_name=source.metadata.agent_name,
            model_name=source.metadata.model_name,
            parent_id=source.metadata.id,
            metadata={"forked_from": source.metadata.id},
        )
        messages = source.messages
        if until_event_id is not None:
            messages = replay_messages([event for event in source.events if event.id <= until_event_id])
        if until_message_id is not None:
            clipped: list[MessageRecord] = []
            for message in messages:
                clipped.append(message)
                if message.id == until_message_id:
                    break
            messages = clipped
        for message in messages:
            copied = MessageRecord(
                id=new_id("msg"),
                session_id=target.id,
                role=message.role,
                parts=message.parts,
                created_at=message.created_at,
                source=message.source,
                metadata={**message.metadata, "forked_from_message": message.id},
            )
            await self.append_message(copied)
        return target

    def _events_path(self, session_id: str) -> Path:
        return self.events_dir / f"{session_id}.jsonl"

    def _factory(self) -> sessionmaker[Session]:
        if self._session_factory is None:
            raise RuntimeError("SessionStore is not initialized.")
        return self._session_factory


def replay_messages(events: list[SessionEvent]) -> list[MessageRecord]:
    messages: list[MessageRecord] = []
    deleted: set[str] = set()
    restore_points: dict[str, MessageRecord] = {}

    for event in sorted(events, key=lambda item: item.id):
        if event.type == "message.appended":
            message = MessageRecord.from_dict(event.payload["message"])
            messages.append(message)
            restore_points[message.id] = message
        elif event.type == "message.edited":
            target = str(event.payload["message_id"])
            replacement = MessageRecord.from_dict(event.payload["message"])
            messages = [replacement if message.id == target else message for message in messages]
            restore_points[replacement.id] = replacement
        elif event.type == "message.deleted":
            deleted.add(str(event.payload["message_id"]))
        elif event.type == "session.rollback":
            messages = _rollback(messages, event.payload)
        elif event.type == "session.restored":
            message_id = str(event.payload["message_id"])
            restored = restore_points.get(message_id)
            if restored is not None:
                deleted.discard(message_id)
                if all(message.id != message_id for message in messages):
                    messages.append(restored)
        elif event.type == "context.compacted":
            summary = MessageRecord.from_dict(event.payload["summary"])
            kept_ids = set(event.payload.get("kept_message_ids", []))
            messages = [
                message
                for message in messages
                if message.id in kept_ids and not _is_summary_record(message)
            ]
            if all(message.id != summary.id for message in messages):
                messages.insert(0, summary)
            restore_points[summary.id] = summary

    return [message for message in messages if message.id not in deleted]


def _rollback(messages: list[MessageRecord], payload: dict[str, Any]) -> list[MessageRecord]:
    if "event_id" in payload:
        return list(messages)
    if "message_id" not in payload:
        return messages
    target = str(payload["message_id"])
    rolled: list[MessageRecord] = []
    for message in messages:
        rolled.append(message)
        if message.id == target:
            break
    return rolled


def _is_summary_record(message: MessageRecord) -> bool:
    return bool(message.metadata.get("summary")) or any(part.kind == "summary" for part in message.parts)


def _upsert_session(factory: sessionmaker[Session], session: SessionMetadata) -> None:
    with factory.begin() as db:
        row = db.get(SessionRow, session.id)
        values = {
            "id": session.id,
            "name": session.name,
            "agent_name": session.agent_name,
            "model_name": session.model_name,
            "parent_id": session.parent_id,
            "created_at": to_iso(session.created_at),
            "updated_at": to_iso(session.updated_at),
            "metadata_json": session.metadata,
        }
        if row is None:
            db.add(SessionRow(**values))
            return
        for key, value in values.items():
            setattr(row, key, value)


def _get_session(factory: sessionmaker[Session], session_id: str) -> dict[str, Any] | None:
    with factory() as db:
        row = db.get(SessionRow, session_id)
        if row is None:
            return None
        return {
            "id": row.id,
            "name": row.name,
            "agent_name": row.agent_name,
            "model_name": row.model_name,
            "parent_id": row.parent_id,
            "created_at": row.created_at,
            "updated_at": row.updated_at,
            "metadata": row.metadata_json,
        }


def _next_event_id(factory: sessionmaker[Session], session_id: str) -> int:
    with factory() as db:
        return next_event_id(db, session_id)


def _insert_event_index(factory: sessionmaker[Session], event: SessionEvent) -> None:
    with factory.begin() as db:
        db.add(
            EventRow(
                session_id=event.session_id,
                event_id=event.id,
                type=event.type,
                created_at=to_iso(event.created_at),
                payload=event.payload,
            )
        )


def _touch_session(factory: sessionmaker[Session], session_id: str, updated_at: Any) -> None:
    with factory.begin() as db:
        row = db.get(SessionRow, session_id)
        if row is not None:
            row.updated_at = to_iso(updated_at)


def _database_url(sqlite_path: Path, configured_url: str | None) -> str:
    if configured_url:
        return configured_url
    return make_url(f"sqlite:///{sqlite_path}").render_as_string(hide_password=False)
