"""Token estimation for local context accounting."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any

from hajimi.llm.extract import provider_usage as _provider_usage
from hajimi.session.models import Message, TokenUsage
from hajimi.tool import ToolRegistry

_WORD_RE = re.compile(r"\w+|[^\w\s]", re.UNICODE)


@dataclass(frozen=True, slots=True)
class TokenEstimator:
    """Small local estimator with optional component hashing.

    The default heuristic is deterministic, dependency-free, and intentionally
    conservative enough for compaction thresholds. Provider usage remains the
    authoritative value when model responses include it.
    """

    tokenizer: str = "heuristic"
    hash_components: bool = True

    def count_text(self, text: str) -> int:
        if not text:
            return 0
        pieces = _WORD_RE.findall(text)
        return max(1, len(pieces))

    def count_value(self, value: Any) -> int:
        if isinstance(value, str):
            return self.count_text(value)
        return self.count_text(json.dumps(value, ensure_ascii=False, default=str))

    def messages(self, messages: list[Message]) -> TokenUsage:
        by_component: dict[str, int] = {}
        total = 0
        for index, message in enumerate(messages):
            name = f"message.{index}.{message.get('role', 'unknown')}"
            tokens = self.count_value(message)
            by_component[name] = tokens
            total += tokens
        return TokenUsage(total=total, by_component=by_component)

    def components(
        self,
        *,
        system_prompt: str | None,
        messages: list[Message],
        tools: ToolRegistry | None = None,
        skills_prompt: str | None = None,
        summary: str | None = None,
        provider: dict[str, int] | None = None,
    ) -> TokenUsage:
        by_component: dict[str, int] = {}
        if system_prompt:
            by_component["system_prompt"] = self.count_text(system_prompt)
        if skills_prompt:
            by_component["skills_prompt"] = self.count_text(skills_prompt)
        if summary:
            by_component["summary"] = self.count_text(summary)
        if tools:
            by_component["tools_schema"] = self.count_value(tools.schemas())
        message_usage = self.messages(messages)
        by_component.update(message_usage.by_component)
        total = sum(by_component.values())
        component_hashes: dict[str, str] = {}
        if self.hash_components:
            component_hashes = {
                name: _stable_hash(name, value)
                for name, value in by_component.items()
            }
        return TokenUsage(
            total=total,
            by_component=by_component,
            provider=dict(provider or {}),
            component_hashes=component_hashes,
        )


def provider_usage_from_raw(raw: Any) -> dict[str, int]:
    """Backwards-compatible wrapper around `hajimi.llm.extract.provider_usage`."""

    return _provider_usage(raw)


def _stable_hash(name: str, value: int) -> str:
    digest = hashlib.sha256(f"{name}:{value}".encode("utf-8")).hexdigest()
    return digest[:16]
