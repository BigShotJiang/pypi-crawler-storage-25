"""SQLAlchemy ORM models for session indexes."""

from __future__ import annotations

from sqlalchemy import JSON, String, UniqueConstraint, create_engine, select
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker


class Base(DeclarativeBase):
    pass


class SessionRow(Base):
    __tablename__ = "sessions"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
    agent_name: Mapped[str] = mapped_column(String, nullable=False)
    model_name: Mapped[str | None] = mapped_column(String)
    parent_id: Mapped[str | None] = mapped_column(String, index=True)
    created_at: Mapped[str] = mapped_column(String, nullable=False)
    updated_at: Mapped[str] = mapped_column(String, nullable=False)
    metadata_json: Mapped[dict] = mapped_column("metadata", JSON, nullable=False, default=dict)


class EventRow(Base):
    __tablename__ = "events"
    __table_args__ = (
        UniqueConstraint("session_id", "event_id", name="events_session_event_id_uq"),
    )

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    session_id: Mapped[str] = mapped_column(String, index=True, nullable=False)
    event_id: Mapped[int] = mapped_column(nullable=False)
    type: Mapped[str] = mapped_column(String, index=True, nullable=False)
    created_at: Mapped[str] = mapped_column(String, nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)


def create_session_engine(url: str, *, echo: bool = False) -> Engine:
    return create_engine(url, echo=echo, future=True)


def create_session_factory(engine: Engine) -> sessionmaker[Session]:
    return sessionmaker(bind=engine, expire_on_commit=False, future=True)


def create_schema(engine: Engine) -> None:
    Base.metadata.create_all(engine)


def next_event_id(db: Session, session_id: str) -> int:
    current = db.scalars(
        select(EventRow.event_id)
        .where(EventRow.session_id == session_id)
        .order_by(EventRow.event_id.desc())
        .limit(1)
    ).first()
    return int(current or 0) + 1
