"""Durable session data models."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Literal
from uuid import uuid4

type Message = dict[str, Any]
type MessageRole = Literal["system", "user", "assistant", "tool"]
type PartKind = Literal[
    "text",
    "tool_call",
    "tool_result",
    "reasoning",
    "summary",
    "skill",
    "system",
]

_REASONING_FIELD_NAMES = (
    "reasoning",
    "reasoning_content",
    "thinking",
    "think",
    "chain_of_thought",
)


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid4().hex}"


def utc_now() -> datetime:
    return datetime.now(UTC)


def to_iso(value: datetime) -> str:
    return value.astimezone(UTC).isoformat()


def from_iso(value: str) -> datetime:
    return datetime.fromisoformat(value).astimezone(UTC)


@dataclass(frozen=True, slots=True)
class MessagePart:
    kind: PartKind
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "content": self.content,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MessagePart":
        return cls(
            kind=data["kind"],
            content=str(data.get("content", "")),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True, slots=True)
class MessageRecord:
    id: str
    session_id: str
    role: MessageRole
    parts: list[MessagePart]
    created_at: datetime = field(default_factory=utc_now)
    source: str = "agent"
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def content(self) -> str:
        return "\n".join(part.content for part in self.parts if part.content and part.kind != "reasoning")

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "role": self.role,
            "parts": [part.to_dict() for part in self.parts],
            "created_at": to_iso(self.created_at),
            "source": self.source,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MessageRecord":
        return cls(
            id=str(data["id"]),
            session_id=str(data["session_id"]),
            role=data["role"],
            parts=[MessagePart.from_dict(part) for part in data.get("parts", [])],
            created_at=from_iso(str(data["created_at"])),
            source=str(data.get("source", "agent")),
            metadata=dict(data.get("metadata", {})),
        )

    @classmethod
    def from_message(
        cls,
        session_id: str,
        message: Message,
        *,
        source: str = "agent",
        message_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> "MessageRecord":
        role = str(message.get("role", "user"))
        content = message.get("content")
        parts: list[MessagePart] = []
        if role == "system":
            parts.append(MessagePart(kind="system", content=_message_content(content)))
        elif role == "tool":
            parts.append(
                MessagePart(
                    kind="tool_result",
                    content=_message_content(content),
                    metadata={
                        key: value
                        for key, value in {
                            "tool_call_id": message.get("tool_call_id"),
                            "name": message.get("name"),
                        }.items()
                        if value is not None
                    },
                )
            )
        else:
            parts.append(MessagePart(kind="text", content=_message_content(content)))

        tool_calls = message.get("tool_calls") or []
        for tool_call in tool_calls:
            parts.append(
                MessagePart(
                    kind="tool_call",
                    content=_tool_call_content(tool_call),
                    metadata=_tool_call_metadata(tool_call),
                )
            )

        parts.extend(_reasoning_parts(message))

        return cls(
            id=message_id or new_id("msg"),
            session_id=session_id,
            role=role,  # type: ignore[arg-type]
            parts=parts,
            source=source,
            metadata=dict(metadata or {}),
        )

    def to_message(self, *, tool_output_max_chars: int | None = None) -> Message:
        if self.role == "tool":
            part = self.parts[0] if self.parts else MessagePart(kind="tool_result", content="")
            content = _truncate(part.content, tool_output_max_chars)
            payload: Message = {
                "role": "tool",
                "content": content,
            }
            if "tool_call_id" in part.metadata:
                payload["tool_call_id"] = part.metadata["tool_call_id"]
            if "name" in part.metadata:
                payload["name"] = part.metadata["name"]
            return payload

        payload = {
            "role": self.role,
            "content": _truncate(
                "\n".join(
                    part.content
                    for part in self.parts
                    if part.kind not in {"tool_call", "reasoning"}
                ),
                tool_output_max_chars if self.role == "tool" else None,
            ),
        }
        for part in self.parts:
            if part.kind == "reasoning":
                field_name = str(part.metadata.get("field") or "reasoning")
                payload[field_name] = _reasoning_payload(field_name, part)
        tool_calls = [
            part.metadata.get("raw", {})
            for part in self.parts
            if part.kind == "tool_call"
        ]
        if tool_calls:
            payload["tool_calls"] = tool_calls
        return payload


@dataclass(frozen=True, slots=True)
class SessionMetadata:
    id: str
    name: str
    agent_name: str
    model_name: str | None = None
    parent_id: str | None = None
    created_at: datetime = field(default_factory=utc_now)
    updated_at: datetime = field(default_factory=utc_now)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "agent_name": self.agent_name,
            "model_name": self.model_name,
            "parent_id": self.parent_id,
            "created_at": to_iso(self.created_at),
            "updated_at": to_iso(self.updated_at),
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SessionMetadata":
        return cls(
            id=str(data["id"]),
            name=str(data["name"]),
            agent_name=str(data["agent_name"]),
            model_name=data.get("model_name"),
            parent_id=data.get("parent_id"),
            created_at=from_iso(str(data["created_at"])),
            updated_at=from_iso(str(data["updated_at"])),
            metadata=dict(data.get("metadata", {})),
        )


@dataclass(frozen=True, slots=True)
class TokenUsage:
    total: int
    by_component: dict[str, int]
    provider: dict[str, int] = field(default_factory=dict)
    component_hashes: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "total": self.total,
            "by_component": self.by_component,
            "provider": self.provider,
            "component_hashes": self.component_hashes,
        }


@dataclass(frozen=True, slots=True)
class ContextBuild:
    messages: list[Message]
    token_usage: TokenUsage
    compacted: bool
    summary: str | None = None
    summary_record: MessageRecord | None = None
    kept_messages: list[MessageRecord] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class SessionRunResult:
    content: str
    messages: list[Message]
    new_messages: list[MessageRecord]
    token_usage: TokenUsage
    compacted: bool
    raw: Any


def _message_content(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    return str(content)


def _reasoning_parts(message: Message) -> list[MessagePart]:
    parts: list[MessagePart] = []
    for field_name in _REASONING_FIELD_NAMES:
        if field_name not in message:
            continue
        raw = message.get(field_name)
        if raw is None:
            continue
        content = _reasoning_content(raw)
        if not content and raw in ("", [], {}):
            continue
        parts.append(
            MessagePart(
                kind="reasoning",
                content=content,
                metadata={
                    "field": field_name,
                    "raw": _jsonable(raw),
                },
            )
        )
    return parts


def _reasoning_content(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if hasattr(value, "model_dump"):
        return _reasoning_content(value.model_dump(exclude_none=True))
    if isinstance(value, dict):
        for key in ("content", "text", "thinking", "reasoning"):
            if key in value:
                return _reasoning_content(value[key])
        return _message_content(_jsonable(value))
    if isinstance(value, list):
        return "\n".join(part for item in value if (part := _reasoning_content(item)))
    return str(value)


def _reasoning_payload(field_name: str, part: MessagePart) -> Any:
    raw = part.metadata.get("raw")
    if field_name == "reasoning":
        if isinstance(raw, dict):
            return raw
        return {"content": part.content}
    if raw is not None:
        return raw
    return part.content


def _tool_call_content(tool_call: Any) -> str:
    function = _read_attr(tool_call, "function") or {}
    name = _read_attr(function, "name") or ""
    arguments = _read_attr(function, "arguments") or "{}"
    return f"{name}({arguments})"


def _tool_call_metadata(tool_call: Any) -> dict[str, Any]:
    raw = dict(tool_call) if isinstance(tool_call, dict) else _raw_tool_call(tool_call)
    function = _read_attr(raw, "function") or {}
    return {
        "id": _read_attr(raw, "id"),
        "type": _read_attr(raw, "type") or "function",
        "name": _read_attr(function, "name"),
        "arguments": _read_attr(function, "arguments") or "{}",
        "raw": _jsonable(raw),
    }


def _raw_tool_call(raw_call: Any) -> dict[str, Any]:
    if hasattr(raw_call, "model_dump"):
        return {
            key: value
            for key, value in raw_call.model_dump(exclude_none=True).items()
            if value is not None
        }
    function = _read_attr(raw_call, "function") or {}
    payload: dict[str, Any] = {
        "id": _read_attr(raw_call, "id"),
        "type": _read_attr(raw_call, "type") or "function",
        "function": {
            "name": _read_attr(function, "name"),
            "arguments": _read_attr(function, "arguments") or "{}",
        },
    }
    extra_content = _read_attr(raw_call, "extra_content")
    if extra_content is not None:
        payload["extra_content"] = extra_content
    return payload


def _read_attr(value: Any, name: str) -> Any:
    if isinstance(value, dict):
        return value.get(name)
    return getattr(value, name, None)


def _truncate(value: str, max_chars: int | None) -> str:
    if max_chars is None or len(value) <= max_chars:
        return value
    return f"{value[:max_chars]}...<truncated>"


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, str | int | float | bool):
        return value
    if hasattr(value, "model_dump"):
        return _jsonable(value.model_dump(exclude_none=True))
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, list | tuple):
        return [_jsonable(item) for item in value]
    return str(value)
