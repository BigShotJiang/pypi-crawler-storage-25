"""Context-window construction and compaction."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from hajimi.config import ContextSettings
from hajimi.session.models import ContextBuild, Message, MessagePart, MessageRecord, TokenUsage, new_id
from hajimi.session.tokens import TokenEstimator

type Summarizer = Callable[[list[MessageRecord]], Awaitable[str]]


@dataclass(slots=True)
class ContextManager:
    settings: ContextSettings
    estimator: TokenEstimator
    summarizer: Summarizer | None = None

    async def compact_messages(self, messages: list[Message]) -> list[Message]:
        """Compact a raw chat-message list in flight without persistence.

        Designed to be plugged into `Agent.message_transformer` so multi-round
        tool loops outside of an `AgentSession` keep their context bounded.
        Uses a deterministic fallback summary; pass a custom `summarizer` if you
        want an LLM-based summary in flight.
        """

        usage = self.estimator.messages(messages)
        if not self._should_compact(usage):
            return messages

        head_count = min(len(messages), max(0, self.settings.protected_head_messages))
        tail_count = min(len(messages), max(0, self.settings.protected_tail_turns * 2))
        protected_indices = _protected_message_indices(
            messages,
            head_count=head_count,
            tail_count=tail_count,
            tool_call_ids=_message_tool_call_ids,
            tool_result_call_id=_message_tool_result_call_id,
        )
        middle = [
            message
            for index, message in enumerate(messages)
            if index not in protected_indices
        ]
        if not middle:
            return messages
        summary_text = _fallback_summary_dict(middle)
        summary_message: Message = {
            "role": "system",
            "content": summary_text,
        }
        compacted: list[Message] = []
        summary_inserted = False
        for index, message in enumerate(messages):
            if index in protected_indices:
                compacted.append(message)
            elif not summary_inserted:
                compacted.append(summary_message)
                summary_inserted = True
        return compacted

    async def build(self, messages: list[MessageRecord]) -> ContextBuild:
        visible = [message.to_message(tool_output_max_chars=self.settings.tool_output_max_chars) for message in messages]
        usage = self.estimator.messages(visible)
        if not self._should_compact(usage):
            return ContextBuild(messages=visible, token_usage=usage, compacted=False)

        summary_record, compacted_records = await self.compact(messages)
        compacted_messages = [
            message.to_message(tool_output_max_chars=self.settings.tool_output_max_chars)
            for message in [summary_record, *compacted_records]
        ]
        compacted_usage = self.estimator.messages(compacted_messages)
        return ContextBuild(
            messages=compacted_messages,
            token_usage=compacted_usage,
            compacted=True,
            summary=summary_record.content,
            summary_record=summary_record,
            kept_messages=compacted_records,
        )

    async def compact(self, messages: list[MessageRecord]) -> tuple[MessageRecord, list[MessageRecord]]:
        if not messages:
            summary = _fallback_summary([])
            return _summary_record("", summary, []), []

        head_count = min(len(messages), max(0, self.settings.protected_head_messages))
        tail_count = min(len(messages), max(0, self.settings.protected_tail_turns * 2))
        protected_indices = _protected_message_indices(
            messages,
            head_count=head_count,
            tail_count=tail_count,
            tool_call_ids=_record_tool_call_ids,
            tool_result_call_id=_record_tool_result_call_id,
        )
        protected = [
            message
            for index, message in enumerate(messages)
            if index in protected_indices and not _is_summary_record(message)
        ]
        protected_ids = {message.id for message in protected}
        middle = [message for message in messages if message.id not in protected_ids]
        summary = await self._summarize(middle)
        session_id = messages[0].session_id
        kept = _dedupe_messages(protected)
        return _summary_record(session_id, summary, middle), kept

    def compacted_event_payload(
        self,
        summary: MessageRecord,
        kept_messages: list[MessageRecord],
    ) -> dict[str, Any]:
        return {
            "summary": summary.to_dict(),
            "kept_message_ids": [message.id for message in kept_messages],
        }

    def _should_compact(self, usage: TokenUsage) -> bool:
        if not self.settings.auto_compact:
            return False
        threshold = max(0.0, min(self.settings.compact_threshold, 1.0))
        return usage.total >= int(self.settings.max_context_tokens * threshold)

    async def _summarize(self, messages: list[MessageRecord]) -> str:
        if self.summarizer is not None:
            return await self.summarizer(messages)
        return _fallback_summary(messages)


def _summary_record(session_id: str, content: str, source_messages: list[MessageRecord]) -> MessageRecord:
    return MessageRecord(
        id=new_id("sum"),
        session_id=session_id,
        role="system",
        parts=[
            MessagePart(
                kind="summary",
                content=content,
                metadata={"source_message_ids": [message.id for message in source_messages]},
            )
        ],
        source="context",
        metadata={"summary": True},
    )


def _fallback_summary(messages: list[MessageRecord]) -> str:
    if not messages:
        return "Conversation summary: no prior middle context."
    lines = ["Conversation summary of compacted middle context:"]
    for message in messages:
        content = message.content.replace("\n", " ").strip()
        if len(content) > 240:
            content = f"{content[:240]}...<truncated>"
        lines.append(f"- {message.role}: {content}")
    return "\n".join(lines)


def _fallback_summary_dict(messages: list[Message]) -> str:
    if not messages:
        return "Conversation summary: no prior middle context."
    lines = ["Conversation summary of compacted middle context:"]
    for message in messages:
        role = str(message.get("role", "unknown"))
        content = str(message.get("content") or "").replace("\n", " ").strip()
        if not content and message.get("tool_calls"):
            content = f"<tool_calls: {len(message['tool_calls'])}>"
        if len(content) > 240:
            content = f"{content[:240]}...<truncated>"
        lines.append(f"- {role}: {content}")
    return "\n".join(lines)


def _protected_message_indices(
    messages: list[Any],
    *,
    head_count: int,
    tail_count: int,
    tool_call_ids: Callable[[Any], set[str]],
    tool_result_call_id: Callable[[Any], str | None],
) -> set[int]:
    length = len(messages)
    tail_start = length - tail_count if tail_count else length
    protected = set(range(head_count))
    protected.update(range(max(0, tail_start), length))
    blocks = _tool_interaction_blocks(
        messages,
        tool_call_ids=tool_call_ids,
        tool_result_call_id=tool_result_call_id,
    )

    changed = True
    while changed:
        changed = False
        for block in blocks:
            if block & protected and not block <= protected:
                protected.update(block)
                changed = True
    return protected


def _tool_interaction_blocks(
    messages: list[Any],
    *,
    tool_call_ids: Callable[[Any], set[str]],
    tool_result_call_id: Callable[[Any], str | None],
) -> list[set[int]]:
    blocks: list[set[int]] = []
    for index, message in enumerate(messages):
        call_ids = tool_call_ids(message)
        if not call_ids:
            continue
        block = {index}
        for following_index in range(index + 1, len(messages)):
            result_call_id = tool_result_call_id(messages[following_index])
            if result_call_id is None:
                break
            if result_call_id not in call_ids:
                break
            block.add(following_index)
        if len(block) > 1:
            blocks.append(block)
    return blocks


def _message_tool_call_ids(message: Message) -> set[str]:
    return {
        str(tool_call["id"])
        for tool_call in message.get("tool_calls") or []
        if isinstance(tool_call, dict) and tool_call.get("id") is not None
    }


def _message_tool_result_call_id(message: Message) -> str | None:
    if message.get("role") != "tool":
        return None
    call_id = message.get("tool_call_id")
    return str(call_id) if call_id is not None else None


def _record_tool_call_ids(message: MessageRecord) -> set[str]:
    return {
        str(part.metadata["id"])
        for part in message.parts
        if part.kind == "tool_call" and part.metadata.get("id") is not None
    }


def _record_tool_result_call_id(message: MessageRecord) -> str | None:
    if message.role != "tool":
        return None
    for part in message.parts:
        if part.kind != "tool_result":
            continue
        call_id = part.metadata.get("tool_call_id")
        return str(call_id) if call_id is not None else None
    return None


def _dedupe_messages(messages: list[MessageRecord]) -> list[MessageRecord]:
    seen: set[str] = set()
    deduped: list[MessageRecord] = []
    for message in messages:
        if message.id in seen:
            continue
        seen.add(message.id)
        deduped.append(message)
    return deduped


def _is_summary_record(message: MessageRecord) -> bool:
    return bool(message.metadata.get("summary")) or any(part.kind == "summary" for part in message.parts)
