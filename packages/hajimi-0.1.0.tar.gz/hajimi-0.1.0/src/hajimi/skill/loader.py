"""Local skill loading.

A skill is a directory with an optional `SKILL.md` instruction file and an
optional `tools.py` module. Public functions from `tools.py` are registered as
agent tools.
"""

from __future__ import annotations

import importlib.util
import inspect
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from types import ModuleType
from typing import Any

import anyio

from hajimi.tool import Tool
from hajimi.tool.schema import schema_from_callable


@dataclass(frozen=True, slots=True)
class SkillMetadata:
    name: str
    description: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class SkillResource:
    path: str
    type: str
    bytes: int | None = None

    def to_dict(self) -> dict[str, object]:
        result: dict[str, object] = {"path": self.path, "type": self.type}
        if self.bytes is not None:
            result["bytes"] = self.bytes
        return result


@dataclass(frozen=True, slots=True)
class Skill:
    name: str
    path: Path
    instructions: str | None = None
    tools: list[Tool] = field(default_factory=list)
    metadata: SkillMetadata | None = None
    resources: list[SkillResource] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class SkillCatalogEntry:
    name: str
    path: Path
    summary: str | None = None
    metadata: SkillMetadata | None = None

    def prompt_line(self) -> str:
        if self.summary:
            return f"- {self.name}: {self.summary}"
        return f"- {self.name}"


@dataclass(frozen=True, slots=True)
class SkillBundle:
    skills: list[Skill]

    @property
    def instructions(self) -> str | None:
        parts = [
            f"# Skill: {skill.name}\n\n{skill.instructions.strip()}"
            for skill in self.skills
            if skill.instructions
        ]
        return "\n\n".join(parts) or None

    @property
    def tools(self) -> list[Tool]:
        return [tool for skill in self.skills for tool in skill.tools]


async def load_skills(paths: Iterable[str | Path], *, base_dir: str | Path | None = None) -> SkillBundle:
    skills = [await load_skill(path, base_dir=base_dir) for path in paths]
    return SkillBundle(skills=skills)


async def load_skill_catalog(
    paths: Iterable[str | Path],
    *,
    base_dir: str | Path | None = None,
) -> list[SkillCatalogEntry]:
    return [await load_skill_catalog_entry(path, base_dir=base_dir) for path in paths]


async def discover_skill_catalog(
    roots: Iterable[str | Path],
) -> list[SkillCatalogEntry]:
    entries: dict[str, SkillCatalogEntry] = {}
    for root in roots:
        root_path = Path(root).expanduser().resolve()
        if not await anyio.Path(root_path).exists():
            continue
        async for item in anyio.Path(root_path).iterdir():
            skill_path = Path(item).resolve()
            if not skill_path.is_dir() or not await anyio.Path(skill_path / "SKILL.md").exists():
                continue
            entry = await load_skill_catalog_entry(skill_path)
            entries.setdefault(entry.name, entry)
    return sorted(entries.values(), key=lambda entry: entry.name)


async def load_skill_catalog_entry(
    path: str | Path,
    *,
    base_dir: str | Path | None = None,
) -> SkillCatalogEntry:
    skill_path = _resolve_skill_path(path, base_dir)
    raw_instructions = await _read_optional_text(skill_path / "SKILL.md")
    metadata, _ = _parse_skill_markdown(raw_instructions or "", fallback_name=skill_path.name)
    summary = metadata.description or await _read_optional_text(skill_path / "SUMMARY.md")
    if summary is None:
        summary = _first_heading_or_line(raw_instructions or "")
    return SkillCatalogEntry(
        name=metadata.name,
        path=skill_path,
        summary=summary,
        metadata=metadata,
    )


async def load_skill(path: str | Path, *, base_dir: str | Path | None = None) -> Skill:
    skill_path = _resolve_skill_path(path, base_dir)
    raw_instructions = await _read_optional_text(skill_path / "SKILL.md")
    metadata, instructions = _parse_skill_markdown(raw_instructions or "", fallback_name=skill_path.name)
    tools = _load_tools_module(skill_path / "tools.py")
    resources = await list_skill_resources(skill_path)
    return Skill(
        name=metadata.name,
        path=skill_path,
        instructions=instructions or None,
        tools=tools,
        metadata=metadata,
        resources=resources,
    )


async def list_skill_resources(
    path: str | Path,
    *,
    max_resources: int | None = None,
) -> list[SkillResource]:
    skill_path = Path(path).expanduser().resolve()
    resources: list[SkillResource] = []
    async for item in anyio.Path(skill_path).rglob("*"):
        resource_path = Path(item).resolve()
        if not resource_path.is_file() or resource_path.name in {"SKILL.md", "SUMMARY.md", "tools.py"}:
            continue
        try:
            relative = resource_path.relative_to(skill_path).as_posix()
        except ValueError:
            continue
        resources.append(
            SkillResource(
                path=relative,
                type=_resource_type(relative),
                bytes=resource_path.stat().st_size,
            )
        )
        if max_resources is not None and len(resources) >= max_resources:
            break
    return sorted(resources, key=lambda resource: resource.path)


def _resolve_skill_path(path: str | Path, base_dir: str | Path | None) -> Path:
    candidate = Path(path)
    if not candidate.is_absolute() and base_dir is not None:
        candidate = Path(base_dir) / candidate
    return candidate.expanduser().resolve()


async def _read_optional_text(path: Path) -> str | None:
    if not await anyio.Path(path).exists():
        return None
    return await anyio.Path(path).read_text(encoding="utf-8")


def _first_heading_or_line(text: str) -> str | None:
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line == "---":
            continue
        return line.lstrip("#").strip()
    return None


def _parse_skill_markdown(text: str, *, fallback_name: str) -> tuple[SkillMetadata, str]:
    metadata: dict[str, Any] = {}
    body = text
    if text.startswith("---\n"):
        end = text.find("\n---", 4)
        if end != -1:
            metadata = _parse_frontmatter(text[4:end])
            body = text[end + 4 :].lstrip("\r\n")
    name = str(metadata.get("name") or fallback_name)
    description = metadata.get("description")
    return SkillMetadata(
        name=name,
        description=str(description).strip() if description else None,
        raw=metadata,
    ), body


def _parse_frontmatter(text: str) -> dict[str, Any]:
    values: dict[str, Any] = {}
    current_key: str | None = None
    current_lines: list[str] = []
    for raw_line in text.splitlines():
        if not raw_line.strip() or raw_line.lstrip().startswith("#"):
            continue
        if raw_line.startswith((" ", "\t")) and current_key is not None:
            current_lines.append(raw_line.strip())
            continue
        if current_key is not None and current_lines:
            values[current_key] = "\n".join(current_lines).strip()
            current_lines = []
        key, separator, value = raw_line.partition(":")
        if not separator:
            current_key = None
            continue
        current_key = key.strip()
        raw_value = value.strip()
        values[current_key] = _parse_frontmatter_value(raw_value)
    if current_key is not None and current_lines:
        values[current_key] = "\n".join(current_lines).strip()
    return values


def _parse_frontmatter_value(value: str) -> Any:
    if value in {"", "|", ">"}:
        return ""
    if value.startswith("[") and value.endswith("]"):
        return [
            _strip_quotes(item.strip())
            for item in value[1:-1].split(",")
            if item.strip()
        ]
    return _strip_quotes(value)


def _strip_quotes(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        return value[1:-1]
    return value


def _resource_type(path: str) -> str:
    first = path.split("/", 1)[0]
    if first in {"scripts", "references", "assets", "examples", "templates"}:
        return first[:-1] if first.endswith("s") else first
    return "file"


def _load_tools_module(path: Path) -> list[Tool]:
    if not path.exists():
        return []

    module = _import_module_from_path(path)
    tools: list[Tool] = []
    for name, value in vars(module).items():
        if name.startswith("_") or not callable(value):
            continue
        if inspect.isclass(value) or inspect.ismodule(value):
            continue
        tools.append(schema_from_callable(value))
    return tools


def _import_module_from_path(path: Path) -> ModuleType:
    module_name = f"hajimi_skill_{path.parent.name}_{path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot import skill tools from {path}.")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
