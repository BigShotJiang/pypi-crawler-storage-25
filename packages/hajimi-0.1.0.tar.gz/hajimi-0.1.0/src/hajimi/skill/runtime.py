"""Runtime support for progressive skill loading."""

from __future__ import annotations

from collections.abc import Iterable
import posixpath
import shlex
from pathlib import Path, PurePosixPath
from typing import Any

import anyio

from hajimi.default_tools import (
    SKILL_SCRIPT_TOOL_DESCRIPTION,
    SKILL_SCRIPT_TOOL_NAME,
    SKILL_TOOL_DESCRIPTION,
    SKILL_TOOL_NAME,
)
from hajimi.sandbox import SandboxEnvironment
from hajimi.skill.loader import Skill, SkillCatalogEntry, load_skill
from hajimi.tool import Tool, ToolRegistry


def skill_catalog_prompt(entries: list[SkillCatalogEntry], *, tool_name: str = SKILL_TOOL_NAME) -> str | None:
    if not entries:
        return None
    lines = "\n".join(entry.prompt_line() for entry in entries)
    return (
        "<available_skills>\n"
        f"Use {tool_name} when a task needs one of these skills. "
        "Only activate skills that are relevant to the current task.\n"
        f"{lines}\n"
        "</available_skills>"
    )


def create_activate_skill_tool(
    entries: list[SkillCatalogEntry],
    registry: ToolRegistry,
    *,
    base_dir: str | Path,
    name: str = SKILL_TOOL_NAME,
    script_tool_name: str = SKILL_SCRIPT_TOOL_NAME,
    script_stage_path: str = ".hajimi/skill-runs",
    max_resources: int = 200,
    tool_names: Iterable[str] | None = None,
    sandbox: SandboxEnvironment | None = None,
) -> Tool:
    by_name = {entry.name: entry for entry in entries}
    allowed_tools = set(tool_names) if tool_names is not None else None
    state = SkillRuntimeState(
        sandbox=sandbox,
        stage_root=script_stage_path,
        max_resources=max_resources,
    )

    async def handler(skill_name: str) -> dict[str, Any]:
        try:
            entry = by_name[skill_name]
        except KeyError as exc:
            names = ", ".join(sorted(by_name))
            raise KeyError(f"Unknown skill {skill_name!r}. Available skills: {names}") from exc

        skill = await load_skill(entry.path, base_dir=base_dir)
        stage_path = await state.activate(skill)
        loaded_tools: list[str] = []
        for tool in skill.tools:
            if allowed_tools is not None and tool.name not in allowed_tools:
                continue
            try:
                registry.register(tool)
            except ValueError:
                pass
            loaded_tools.append(tool.name)
        if sandbox is not None and (allowed_tools is None or script_tool_name in allowed_tools):
            try:
                registry.register(
                    create_skill_script_tool(
                        state,
                        name=script_tool_name,
                    )
                )
            except ValueError:
                pass
        return {
            "skill": skill.name,
            "instructions": skill.instructions or "",
            "loaded_tools": loaded_tools,
            "resources": [resource.to_dict() for resource in skill.resources[:max_resources]],
            "resource_count": len(skill.resources),
            "sandbox_path": stage_path,
            "script_tool": script_tool_name if sandbox is not None else None,
        }

    return Tool(
        name=name,
        description=SKILL_TOOL_DESCRIPTION,
        parameters={
            "type": "object",
            "properties": {
                "skill_name": {
                    "type": "string",
                    "description": "Skill name from <available_skills>.",
                }
            },
            "required": ["skill_name"],
        },
        handler=handler,
    )


class SkillRuntimeState:
    def __init__(
        self,
        *,
        sandbox: SandboxEnvironment | None,
        stage_root: str,
        max_resources: int,
    ) -> None:
        self._sandbox = sandbox
        self._stage_root = _normalize_relative(stage_root)
        self._max_resources = max_resources
        self._skills: dict[str, Skill] = {}
        self._staged: set[str] = set()

    def get(self, skill_name: str) -> Skill:
        try:
            return self._skills[skill_name]
        except KeyError as exc:
            names = ", ".join(sorted(self._skills))
            raise KeyError(f"Skill {skill_name!r} is not activated. Active skills: {names}") from exc

    def stage_path(self, skill_name: str) -> str:
        return f"{self._stage_root}/{_safe_path_component(skill_name)}"

    async def activate(self, skill: Skill) -> str:
        self._skills[skill.name] = skill
        return self.stage_path(skill.name)

    async def run_script(
        self,
        *,
        skill_name: str,
        script_path: str,
        args: list[str] | None = None,
        timeout_seconds: float = 30.0,
    ) -> dict[str, Any]:
        if self._sandbox is None:
            raise RuntimeError("Skill script sandbox is not configured.")
        skill = self.get(skill_name)
        script_relative = _normalize_relative(script_path)
        if not script_relative.startswith("scripts/"):
            raise ValueError("script_path must point to a file under scripts/.")
        local_script = (skill.path / script_relative).resolve()
        try:
            local_script.relative_to(skill.path)
        except ValueError as exc:
            raise ValueError("script_path escapes skill root.") from exc
        if not local_script.is_file():
            raise FileNotFoundError(script_path)
        stage_path = self.stage_path(skill.name)
        if skill.name not in self._staged:
            await self._stage_skill(skill)
            self._staged.add(skill.name)
        command_parts = [*_script_command_prefix(script_relative), *(args or [])]
        command = " ".join(shlex.quote(part) for part in command_parts)
        result = await self._sandbox.exec(
            command,
            timeout_seconds,
            cwd=stage_path,
        )
        return {
            "skill": skill.name,
            "script": script_relative,
            "cwd": stage_path,
            "command": command,
            "exit_code": result.exit_code,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "timed_out": result.timed_out,
        }

    async def _stage_skill(self, skill: Skill) -> None:
        if self._sandbox is None:
            return
        staged_count = 0
        for file_path in sorted(skill.path.rglob("*")):
            if not file_path.is_file():
                continue
            try:
                relative = file_path.relative_to(skill.path).as_posix()
            except ValueError:
                continue
            if (
                relative not in {"SKILL.md", "SUMMARY.md", "tools.py"}
                and self._max_resources >= 0
                and staged_count >= self._max_resources
            ):
                continue
            target_path = f"{self.stage_path(skill.name)}/{relative}"
            content = await anyio.Path(file_path).read_bytes()
            await self._sandbox.write_bytes(target_path, content)
            if relative not in {"SKILL.md", "SUMMARY.md", "tools.py"}:
                staged_count += 1


def create_skill_script_tool(
    state: SkillRuntimeState,
    *,
    name: str = SKILL_SCRIPT_TOOL_NAME,
) -> Tool:
    return Tool(
        name=name,
        description=SKILL_SCRIPT_TOOL_DESCRIPTION,
        parameters={
            "type": "object",
            "properties": {
                "skill_name": {
                    "type": "string",
                    "description": "Activated skill name.",
                },
                "script_path": {
                    "type": "string",
                    "description": "Path under scripts/ inside the activated skill.",
                },
                "args": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Command-line arguments passed to the script.",
                },
                "timeout_seconds": {
                    "type": "number",
                    "description": "Maximum runtime in seconds.",
                },
            },
            "required": ["skill_name", "script_path"],
        },
        handler=state.run_script,
    )


def _normalize_relative(path: str) -> str:
    normalized = PurePosixPath(posixpath.normpath(path)).as_posix()
    if normalized in {"", "."} or normalized.startswith("../") or normalized == ".." or normalized.startswith("/"):
        raise ValueError(f"Path {path!r} must stay relative.")
    return normalized


def _safe_path_component(value: str) -> str:
    return "".join(char if char.isalnum() or char in {"-", "_", "."} else "_" for char in value)


def _script_command_prefix(script_path: str) -> list[str]:
    if script_path.endswith(".py"):
        return ["python", script_path]
    if script_path.endswith(".sh"):
        return ["sh", script_path]
    return [f"./{script_path}"]
