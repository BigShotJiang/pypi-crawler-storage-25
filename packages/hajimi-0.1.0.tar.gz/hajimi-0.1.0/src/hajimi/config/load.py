"""Async TOML and .env configuration loading."""

from __future__ import annotations

import os
import re
import tomllib
from collections.abc import Mapping
from pathlib import Path
from typing import Any

import anyio

from hajimi.config.models import (
    AgentProfileSettings,
    AgentRoutingSettings,
    AgentSettings,
    AgentSkillLoadingSettings,
    AgentToolSearchSettings,
    AgentWorkspaceToolsSettings,
    AppConfig,
    ContextCacheSettings,
    ContextSettings,
    LogSettings,
    MCPServerSettings,
    MCPSettings,
    ModelPricing,
    ModelSettings,
    ObservabilitySettings,
    OpenTelemetrySettings,
    SubAgentSettings,
    TeammateSettings,
)
from hajimi.config.providers import detect_provider_models, select_default_model
from hajimi.default_tools import (
    SKILL_SCRIPT_TOOL_NAME,
    SKILL_TOOL_NAME,
    SUBAGENT_TOOL_DESCRIPTION,
    SUBAGENT_TOOL_NAME,
    TEAM_BROADCAST_TOOL_NAME,
    TEAM_CLOSE_TOOL_NAME,
    TEAM_LIST_TOOL_NAME,
    TEAM_SEND_TOOL_NAME,
    TEAM_SPAWN_TOOL_NAME,
    TOOL_SEARCH_NAME,
    WORKSPACE_BASH_TOOL_DESCRIPTION,
    WORKSPACE_BASH_TOOL_NAME,
    WORKSPACE_EDIT_TOOL_DESCRIPTION,
    WORKSPACE_EDIT_TOOL_NAME,
    WORKSPACE_GLOB_TOOL_DESCRIPTION,
    WORKSPACE_GLOB_TOOL_NAME,
    WORKSPACE_GREP_TOOL_DESCRIPTION,
    WORKSPACE_GREP_TOOL_NAME,
    WORKSPACE_READ_TOOL_DESCRIPTION,
    WORKSPACE_READ_TOOL_NAME,
    WORKSPACE_WRITE_TOOL_DESCRIPTION,
    WORKSPACE_WRITE_TOOL_NAME,
)

_ENV_NAME_RE = re.compile(r"[^A-Z0-9]+")
_MODEL_FIELDS = {
    "provider",
    "model",
    "api_key",
    "base_url",
    "api_key_env",
    "base_url_env",
    "temperature",
    "top_p",
    "max_tokens",
    "max_output_tokens",
    "client_args",
    "pricing",
}


async def load_config(
    config_path: str | Path | None = None,
    *,
    env_path: str | Path | None = None,
    repo_path: str | Path | None = None,
) -> AppConfig:
    """Load Hajimi configuration with progressive layering.

    Resolution order:

    1. Optional TOML file at `config_path` (skipped when `None`).
    2. Optional `.env` next to the TOML, or the explicit `env_path`.
    3. `os.environ`.
    4. Auto-detected providers (`<PROVIDER>_API_KEY`) merged for any model
       names that the TOML did not already define.

    When `config_path` is `None` and no env API key is detected, the resulting
    `AppConfig` will still load but `config.model()` will raise on first use.
    """

    if config_path is None:
        resolved_config_path = None
        resolved_repo_path = await _resolve_repo_path(None, repo_path)
    else:
        resolved_config_path = Path(config_path).expanduser().resolve()
        resolved_repo_path = await _resolve_repo_path(resolved_config_path, repo_path)
    resolved_env_path = await _resolve_env_path(resolved_config_path, env_path)

    toml_data: dict[str, Any] = (
        await _read_toml(resolved_config_path) if resolved_config_path is not None else {}
    )
    env_file_data = await _read_env_file(resolved_env_path)
    env_data = {**env_file_data, **os.environ}

    toml_models = _parse_models(toml_data.get("model", {}), env_data)
    auto_models = detect_provider_models(env_data)
    merged_models: dict[str, ModelSettings] = dict(auto_models)
    merged_models.update(toml_models)  # TOML wins on name conflicts.

    agent_settings = _parse_agent(toml_data.get("agent", {}))
    if agent_settings.default_model is None:
        auto_default = select_default_model(env_data, merged_models)
        if auto_default is not None:
            agent_settings = _replace_default_model(agent_settings, auto_default)

    return AppConfig(
        repo_path=resolved_repo_path,
        agent=agent_settings,
        log=_parse_log(toml_data.get("log", {})),
        observability=_parse_observability(toml_data.get("observability", {})),
        context=_parse_context(toml_data.get("context", {})),
        mcp=_parse_mcp(toml_data.get("mcp", {})),
        models=merged_models,
    )


def _replace_default_model(agent: AgentSettings, default_model: str) -> AgentSettings:
    from dataclasses import replace as _dc_replace

    return _dc_replace(agent, default_model=default_model)


async def _read_toml(path: Path) -> dict[str, Any]:
    async with await anyio.open_file(path, "rb") as file:
        data = await file.read()
    return tomllib.loads(data.decode("utf-8"))


async def _read_env_file(path: Path | None) -> dict[str, str]:
    if path is None or not await anyio.Path(path).exists():
        return {}

    async with await anyio.open_file(path, encoding="utf-8") as file:
        text = await file.read()

    values: dict[str, str] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = _clean_env_value(value.strip())
    return values


def _clean_env_value(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        return value[1:-1]
    return value


def _parse_agent(data: Mapping[str, Any]) -> AgentSettings:
    return AgentSettings(
        name=str(data.get("name", "hajimi")),
        default_model=_optional_str(data.get("default_model")),
        system_prompt=_optional_str(data.get("system_prompt")),
        max_tool_rounds=int(data.get("max_tool_rounds", 4)),
        skills=[str(skill) for skill in data.get("skills", [])],
        skill_loading=_parse_skill_loading(data.get("skill_loading", {})),
        subagents=_parse_subagents(data.get("subagents", {})),
        teammates=_parse_teammates(data.get("teammates", {})),
        profiles=_parse_agent_profiles(data.get("profile", {})),
        tool_search=_parse_tool_search(data.get("tool_search", {})),
        workspace_tools=_parse_workspace_tools(data.get("workspace_tools", {})),
        routing=_parse_routing(data.get("routing", {})),
    )


def _parse_skill_loading(data: Mapping[str, Any]) -> AgentSkillLoadingSettings:
    return AgentSkillLoadingSettings(
        progressive=bool(data.get("progressive", True)),
        activation_tool_name=str(data.get("activation_tool_name", SKILL_TOOL_NAME)),
        script_tool_name=str(data.get("script_tool_name", SKILL_SCRIPT_TOOL_NAME)),
        sandbox_stage_path=str(data.get("sandbox_stage_path", ".hajimi/skill-runs")),
        max_resources=int(data.get("max_resources", 200)),
        auto_discover=bool(data.get("auto_discover", True)),
        discovery_dirs=[str(path) for path in data.get(
            "discovery_dirs",
            ["skills", ".agents/skills", ".claude/skills"],
        )],
    )


def _parse_tool_search(data: Mapping[str, Any]) -> AgentToolSearchSettings:
    return AgentToolSearchSettings(
        enabled=bool(data.get("enabled", False)),
        tool_name=str(data.get("tool_name", TOOL_SEARCH_NAME)),
        max_results=int(data.get("max_results", 8)),
        defer_tools=bool(data.get("defer_tools", True)),
    )


def _parse_workspace_tools(data: Mapping[str, Any]) -> AgentWorkspaceToolsSettings:
    root = _optional_str(data.get("root"))
    return AgentWorkspaceToolsSettings(
        enabled=bool(data.get("enabled", True)),
        sandbox_provider=str(data.get("sandbox_provider", "e2b")),
        root=Path(root) if root else None,
        allow_write=bool(data.get("allow_write", False)),
        allow_shell=bool(data.get("allow_shell", False)),
        max_read_chars=int(data.get("max_read_chars", 20000)),
        max_output_chars=int(data.get("max_output_chars", 12000)),
        max_search_results=int(data.get("max_search_results", 100)),
        allowed_shell_commands=[str(command) for command in data.get("allowed_shell_commands", [])],
        e2b_sandbox_id=_optional_str(data.get("e2b_sandbox_id")),
        e2b_template=_optional_str(data.get("e2b_template")),
        e2b_timeout=(
            int(data["e2b_timeout"])
            if data.get("e2b_timeout") is not None
            else 300
        ),
        e2b_allow_internet_access=bool(data.get("e2b_allow_internet_access", True)),
        read_tool_name=str(data.get("read_tool_name", WORKSPACE_READ_TOOL_NAME)),
        read_tool_description=str(data.get("read_tool_description", WORKSPACE_READ_TOOL_DESCRIPTION)),
        write_tool_name=str(data.get("write_tool_name", WORKSPACE_WRITE_TOOL_NAME)),
        write_tool_description=str(data.get("write_tool_description", WORKSPACE_WRITE_TOOL_DESCRIPTION)),
        edit_tool_name=str(data.get("edit_tool_name", WORKSPACE_EDIT_TOOL_NAME)),
        edit_tool_description=str(data.get("edit_tool_description", WORKSPACE_EDIT_TOOL_DESCRIPTION)),
        grep_tool_name=str(data.get("grep_tool_name", WORKSPACE_GREP_TOOL_NAME)),
        grep_tool_description=str(data.get("grep_tool_description", WORKSPACE_GREP_TOOL_DESCRIPTION)),
        glob_tool_name=str(data.get("glob_tool_name", WORKSPACE_GLOB_TOOL_NAME)),
        glob_tool_description=str(data.get("glob_tool_description", WORKSPACE_GLOB_TOOL_DESCRIPTION)),
        bash_tool_name=str(data.get("bash_tool_name", WORKSPACE_BASH_TOOL_NAME)),
        bash_tool_description=str(data.get("bash_tool_description", WORKSPACE_BASH_TOOL_DESCRIPTION)),
    )


def _parse_agent_profiles(data: Mapping[str, Any]) -> dict[str, AgentProfileSettings]:
    return {
        name: AgentProfileSettings(
            name=name,
            model_name=_optional_str(raw_settings.get("model_name")),
            system_prompt=_optional_str(raw_settings.get("system_prompt")),
            max_tool_rounds=_optional_int(raw_settings.get("max_tool_rounds")),
            skills=[str(skill) for skill in raw_settings.get("skills", [])],
            mcp_servers=[str(server) for server in raw_settings.get("mcp_servers", [])],
            tool_names=(
                [str(tool_name) for tool_name in raw_settings["tool_names"]]
                if "tool_names" in raw_settings
                else None
            ),
        )
        for name, raw_settings in data.items()
    }


def _parse_routing(data: Mapping[str, Any]) -> AgentRoutingSettings:
    return AgentRoutingSettings(
        enabled=bool(data.get("enabled", True)),
        strategy=str(data.get("strategy", "auto")),
        simple_max_words=int(data.get("simple_max_words", 80)),
        simple_max_tool_markers=int(data.get("simple_max_tool_markers", 0)),
        default_mode=str(data.get("default_mode", "auto")),
        default_profiles=[str(profile) for profile in data.get("default_profiles", [])],
        default_replicas=int(data.get("default_replicas", 1)),
        planner_profile=_optional_str(data.get("planner_profile")),
        synthesizer_profile=_optional_str(data.get("synthesizer_profile")),
        max_parallel_agents=int(data.get("max_parallel_agents", 4)),
        max_budget_tokens=_optional_int(data.get("max_budget_tokens")),
    )


def _parse_subagents(data: Mapping[str, Any]) -> SubAgentSettings:
    return SubAgentSettings(
        enabled=bool(data.get("enabled", False)),
        max_depth=int(data.get("max_depth", 2)),
        tool_name=str(data.get("tool_name", SUBAGENT_TOOL_NAME)),
        tool_description=str(
            data.get(
                "tool_description",
                SUBAGENT_TOOL_DESCRIPTION,
            )
        ),
        max_tool_rounds=_optional_int(data.get("max_tool_rounds")),
    )


def _parse_teammates(data: Mapping[str, Any]) -> TeammateSettings:
    return TeammateSettings(
        enabled=bool(data.get("enabled", False)),
        max_members=int(data.get("max_members", 4)),
        spawn_tool_name=str(data.get("spawn_tool_name", TEAM_SPAWN_TOOL_NAME)),
        send_tool_name=str(data.get("send_tool_name", TEAM_SEND_TOOL_NAME)),
        broadcast_tool_name=str(data.get("broadcast_tool_name", TEAM_BROADCAST_TOOL_NAME)),
        list_tool_name=str(data.get("list_tool_name", TEAM_LIST_TOOL_NAME)),
        close_tool_name=str(data.get("close_tool_name", TEAM_CLOSE_TOOL_NAME)),
        max_tool_rounds=_optional_int(data.get("max_tool_rounds")),
    )


def _parse_log(data: Mapping[str, Any]) -> LogSettings:
    directory = _optional_str(data.get("directory"))
    return LogSettings(
        directory=Path(directory) if directory else None,
        file_name=str(data.get("file_name", "hajimi.jsonl")),
        console_level=str(data.get("console_level", "INFO")).upper(),
        file_level=str(data.get("file_level", "DEBUG")).upper(),
        rotation=str(data.get("rotation", "10 MB")),
        retention=_optional_str(data.get("retention", "14 days")),
        compression=_optional_str(data.get("compression")),
        colorize=bool(data.get("colorize", True)),
        enqueue=bool(data.get("enqueue", True)),
        backtrace=bool(data.get("backtrace", False)),
        diagnose=bool(data.get("diagnose", False)),
        enable_file=bool(data.get("enable_file", True)),
        enable_console=bool(data.get("enable_console", True)),
        serialize_file=bool(data.get("serialize_file", True)),
    )


def _parse_observability(data: Mapping[str, Any]) -> ObservabilitySettings:
    directory = _optional_str(data.get("directory"))
    return ObservabilitySettings(
        enabled=bool(data.get("enabled", True)),
        directory=Path(directory) if directory else None,
        file_name=str(data.get("file_name", "traces.jsonl")),
        sample_rate=float(data.get("sample_rate", 1.0)),
        include_content=bool(data.get("include_content", True)),
        max_content_chars=int(data.get("max_content_chars", 4000)),
        otel=_parse_otel(data.get("otel", {})),
    )


def _parse_context(data: Mapping[str, Any]) -> ContextSettings:
    store_dir = str(data.get("store_dir", "sessions"))
    events_dir = str(data.get("events_dir", "sessions/events"))
    return ContextSettings(
        enabled=bool(data.get("enabled", True)),
        store_dir=Path(store_dir),
        database_url=_optional_str(data.get("database_url")),
        sqlite_file=str(data.get("sqlite_file", "sessions.sqlite")),
        events_dir=Path(events_dir),
        auto_compact=bool(data.get("auto_compact", True)),
        compact_threshold=float(data.get("compact_threshold", 0.70)),
        max_context_tokens=int(data.get("max_context_tokens", 12000)),
        protected_head_messages=int(data.get("protected_head_messages", 2)),
        protected_tail_turns=int(data.get("protected_tail_turns", 6)),
        tool_output_max_chars=int(data.get("tool_output_max_chars", 2000)),
        summary_model=_optional_str(data.get("summary_model")),
        tokenizer=str(data.get("tokenizer", "heuristic")),
        cache=_parse_context_cache(data.get("cache", {})),
    )


def _parse_context_cache(data: Mapping[str, Any]) -> ContextCacheSettings:
    return ContextCacheSettings(
        enabled=bool(data.get("enabled", True)),
        hash_components=bool(data.get("hash_components", True)),
        record_provider_cache=bool(data.get("record_provider_cache", True)),
    )


def _parse_otel(data: Mapping[str, Any]) -> OpenTelemetrySettings:
    return OpenTelemetrySettings(
        enabled=bool(data.get("enabled", False)),
        service_name=str(data.get("service_name", "hajimi")),
        service_version=_optional_str(data.get("service_version")),
        endpoint=_optional_str(data.get("endpoint")),
        protocol=str(data.get("protocol", "http/protobuf")),
        headers={str(key): str(value) for key, value in data.get("headers", {}).items()},
        insecure=bool(data.get("insecure", False)),
        timeout=float(data.get("timeout", 10.0)),
    )


def _parse_mcp(data: Mapping[str, Any]) -> MCPSettings:
    servers_data = data.get("server", {})
    servers = {
        name: _parse_mcp_server(name, raw_settings)
        for name, raw_settings in servers_data.items()
    }
    return MCPSettings(
        enabled=bool(data.get("enabled", False)),
        servers=servers,
    )


def _parse_mcp_server(name: str, data: Mapping[str, Any]) -> MCPServerSettings:
    cwd = _optional_str(data.get("cwd"))
    return MCPServerSettings(
        name=name,
        transport=str(data.get("transport", "stdio")),
        command=_optional_str(data.get("command")),
        args=[str(arg) for arg in data.get("args", [])],
        env={str(key): str(value) for key, value in data.get("env", {}).items()},
        cwd=Path(cwd) if cwd else None,
        url=_optional_str(data.get("url")),
        enabled=bool(data.get("enabled", True)),
        tool_prefix=_optional_str(data.get("tool_prefix")),
    )


def _parse_models(
    data: Mapping[str, Mapping[str, Any]],
    env_data: Mapping[str, str],
) -> dict[str, ModelSettings]:
    models: dict[str, ModelSettings] = {}
    for name, raw_settings in data.items():
        provider = str(raw_settings["provider"])
        env_prefix = _provider_env_prefix(provider)
        api_key = _first_present(
            _optional_str(raw_settings.get("api_key")),
            env_data.get(str(raw_settings.get("api_key_env", ""))),
            env_data.get(f"{env_prefix}_API_KEY"),
        )
        base_url = _first_present(
            _optional_str(raw_settings.get("base_url")),
            env_data.get(str(raw_settings.get("base_url_env", ""))),
            env_data.get(f"{env_prefix}_BASE_URL"),
            env_data.get(f"{env_prefix}_API_BASE"),
        )
        extra = {
            key: value
            for key, value in raw_settings.items()
            if key not in _MODEL_FIELDS
        }
        models[name] = ModelSettings(
            name=name,
            provider=provider,
            model=str(raw_settings["model"]),
            api_key=api_key,
            base_url=base_url,
            temperature=_optional_float(raw_settings.get("temperature")),
            top_p=_optional_float(raw_settings.get("top_p")),
            max_tokens=_optional_int(raw_settings.get("max_tokens")),
            max_output_tokens=_optional_int(raw_settings.get("max_output_tokens")),
            client_args=dict(raw_settings.get("client_args", {})),
            extra=extra,
            pricing=_parse_pricing(raw_settings.get("pricing")),
        )
    return models


def _parse_pricing(data: Any) -> ModelPricing | None:
    """Parse a `[model.<name>.pricing]` table.

    Accepts the canonical per-million-token keys (`input_per_1m`,
    `output_per_1m`, `cached_input_per_1m`). The legacy per-1K keys are
    auto-converted for backward compatibility with old config files.
    """

    if not isinstance(data, Mapping) or not data:
        return None
    input_per_1m = _read_pricing_field(data, "input_per_1m", legacy="input_per_1k")
    output_per_1m = _read_pricing_field(data, "output_per_1m", legacy="output_per_1k")
    cached = _read_pricing_field(
        data, "cached_input_per_1m", legacy="cached_input_per_1k", allow_none=True
    )
    return ModelPricing(
        input_per_1m=input_per_1m or 0.0,
        output_per_1m=output_per_1m or 0.0,
        cached_input_per_1m=cached,
    )


def _read_pricing_field(
    data: Mapping[str, Any],
    key: str,
    *,
    legacy: str | None = None,
    allow_none: bool = False,
) -> float | None:
    if key in data and data[key] is not None:
        return float(data[key])
    if legacy and legacy in data and data[legacy] is not None:
        return float(data[legacy]) * 1000.0
    return None if allow_none else 0.0


async def _resolve_env_path(config_path: Path | None, env_path: str | Path | None) -> Path | None:
    if env_path is not None:
        return Path(env_path).expanduser().resolve()
    if config_path is not None:
        candidate = config_path.parent / ".env"
        if await anyio.Path(candidate).exists():
            return candidate
    cwd_candidate = Path.cwd() / ".env"
    if await anyio.Path(cwd_candidate).exists():
        return cwd_candidate
    return None


async def _resolve_repo_path(config_path: Path | None, repo_path: str | Path | None) -> Path:
    if repo_path is not None:
        return Path(repo_path).expanduser().resolve()
    if config_path is not None:
        for parent in (config_path.parent, *config_path.parents):
            if await anyio.Path(parent / "pyproject.toml").exists():
                return parent
    return Path.cwd().resolve()


def _provider_env_prefix(provider: str) -> str:
    return _ENV_NAME_RE.sub("_", provider.upper()).strip("_")


def _optional_str(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _optional_int(value: Any) -> int | None:
    if value is None or value == "":
        return None
    return int(value)


def _optional_float(value: Any) -> float | None:
    if value is None or value == "":
        return None
    return float(value)


def _first_present(*values: str | None) -> str | None:
    for value in values:
        if value:
            return value
    return None
