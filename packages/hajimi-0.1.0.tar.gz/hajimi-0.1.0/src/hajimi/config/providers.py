"""Provider auto-detection from environment variables.

When users only export `<PROVIDER>_API_KEY`, we synthesize a usable
`ModelSettings` per provider so that high-level helpers like `Hajimi.default()`
and `ask()` work without a TOML file.

Per-provider model id and pricing can still be overridden via env:

  - `HAJIMI_DEFAULT_MODEL=<provider_name>` selects which provider becomes the
    default when several keys are present.
  - `HAJIMI_DEFAULT_MODEL__<PREFIX>=<model_id>` overrides the auto-picked model
    id, e.g. `HAJIMI_DEFAULT_MODEL__OPENAI=gpt-5`.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from hajimi.config.models import ModelSettings


@dataclass(frozen=True, slots=True)
class ProviderDefault:
    """Defaults used when only an API key is present in the environment."""

    name: str
    env_prefix: str
    default_model: str


# Priority order: when several `<PREFIX>_API_KEY` env vars are present and the
# user has not set `HAJIMI_DEFAULT_MODEL`, providers earlier in this tuple win.
#
# Pricing is resolved from the bundled LiteLLM catalog at runtime. Default
# models below are provider-native ids because `ModelSettings.provider` is
# already set for direct any-llm calls. Override per-call via
# `RunOptions.pricing` or in `[model.<name>.pricing]` TOML tables.
PROVIDER_DEFAULTS: tuple[ProviderDefault, ...] = (
    ProviderDefault(name="openai", env_prefix="OPENAI", default_model="gpt-5.4-mini"),
    ProviderDefault(name="anthropic", env_prefix="ANTHROPIC", default_model="claude-sonnet-4-6"),
    ProviderDefault(name="deepseek", env_prefix="DEEPSEEK", default_model="deepseek-chat"),
    ProviderDefault(name="gemini", env_prefix="GEMINI", default_model="gemini-3-flash-preview"),
    ProviderDefault(name="mistral", env_prefix="MISTRAL", default_model="mistral-medium-latest"),
    ProviderDefault(name="groq", env_prefix="GROQ", default_model="llama-3.3-70b-versatile"),
    ProviderDefault(name="xai", env_prefix="XAI", default_model="grok-4-fast-reasoning"),
    ProviderDefault(name="dashscope", env_prefix="DASHSCOPE", default_model="qwen-flash"),
)


def detect_provider_models(env: Mapping[str, str]) -> dict[str, ModelSettings]:
    """Synthesize one `ModelSettings` per provider whose API key is in `env`."""

    models: dict[str, ModelSettings] = {}
    for default in PROVIDER_DEFAULTS:
        api_key = (env.get(f"{default.env_prefix}_API_KEY") or "").strip()
        if not api_key:
            continue
        model_override = (env.get(f"HAJIMI_DEFAULT_MODEL__{default.env_prefix}") or "").strip()
        model_id = model_override or default.default_model
        base_url = (
            env.get(f"{default.env_prefix}_BASE_URL")
            or env.get(f"{default.env_prefix}_API_BASE")
            or ""
        ).strip() or None
        models[default.name] = ModelSettings(
            name=default.name,
            provider=default.name,
            model=model_id,
            api_key=api_key,
            base_url=base_url,
            pricing=None,
        )
    return models


def select_default_model(
    env: Mapping[str, str],
    models: Mapping[str, ModelSettings],
) -> str | None:
    """Pick which model name should be used as the agent default."""

    explicit = (env.get("HAJIMI_DEFAULT_MODEL") or "").strip()
    if explicit and explicit in models:
        return explicit
    for default in PROVIDER_DEFAULTS:
        if default.name in models:
            return default.name
    return next(iter(models), None)


__all__ = [
    "PROVIDER_DEFAULTS",
    "ProviderDefault",
    "detect_provider_models",
    "select_default_model",
]
