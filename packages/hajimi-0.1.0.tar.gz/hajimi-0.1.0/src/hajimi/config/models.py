"""Configuration models for Hajimi."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from hajimi.default_tools import (
    SKILL_SCRIPT_TOOL_NAME,
    SKILL_TOOL_NAME,
    SUBAGENT_TOOL_DESCRIPTION,
    SUBAGENT_TOOL_NAME,
    TEAM_BROADCAST_TOOL_NAME,
    TEAM_CLOSE_TOOL_NAME,
    TEAM_LIST_TOOL_NAME,
    TEAM_SEND_TOOL_NAME,
    TEAM_SPAWN_TOOL_NAME,
    TOOL_SEARCH_NAME,
    WORKSPACE_BASH_TOOL_DESCRIPTION,
    WORKSPACE_BASH_TOOL_NAME,
    WORKSPACE_EDIT_TOOL_DESCRIPTION,
    WORKSPACE_EDIT_TOOL_NAME,
    WORKSPACE_GLOB_TOOL_DESCRIPTION,
    WORKSPACE_GLOB_TOOL_NAME,
    WORKSPACE_GREP_TOOL_DESCRIPTION,
    WORKSPACE_GREP_TOOL_NAME,
    WORKSPACE_READ_TOOL_DESCRIPTION,
    WORKSPACE_READ_TOOL_NAME,
    WORKSPACE_WRITE_TOOL_DESCRIPTION,
    WORKSPACE_WRITE_TOOL_NAME,
)


@dataclass(frozen=True, slots=True)
class LogSettings:
    """Runtime logging settings."""

    directory: Path | None = None
    file_name: str = "hajimi.jsonl"
    console_level: str = "INFO"
    file_level: str = "DEBUG"
    rotation: str = "10 MB"
    retention: str | None = "14 days"
    compression: str | None = None
    colorize: bool = True
    enqueue: bool = True
    backtrace: bool = False
    diagnose: bool = False
    enable_file: bool = True
    enable_console: bool = True
    serialize_file: bool = True

    def resolve_directory(self, repo_path: Path) -> Path:
        if self.directory is None:
            return repo_path / "logs"
        if self.directory.is_absolute():
            return self.directory
        return repo_path / self.directory


@dataclass(frozen=True, slots=True)
class OpenTelemetrySettings:
    """Optional OpenTelemetry export settings."""

    enabled: bool = False
    service_name: str = "hajimi"
    service_version: str | None = None
    endpoint: str | None = None
    protocol: str = "http/protobuf"
    headers: dict[str, str] = field(default_factory=dict)
    insecure: bool = False
    timeout: float = 10.0


@dataclass(frozen=True, slots=True)
class MCPServerSettings:
    """MCP server connection settings."""

    name: str
    transport: str = "stdio"
    command: str | None = None
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    cwd: Path | None = None
    url: str | None = None
    enabled: bool = True
    tool_prefix: str | None = None


@dataclass(frozen=True, slots=True)
class MCPSettings:
    """MCP tool-source settings."""

    enabled: bool = False
    servers: dict[str, MCPServerSettings] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ObservabilitySettings:
    """Structured tracing settings."""

    enabled: bool = True
    directory: Path | None = None
    file_name: str = "traces.jsonl"
    sample_rate: float = 1.0
    include_content: bool = True
    max_content_chars: int = 4000
    otel: OpenTelemetrySettings = field(default_factory=OpenTelemetrySettings)

    def resolve_directory(self, repo_path: Path) -> Path:
        if self.directory is None:
            return repo_path / "logs"
        if self.directory.is_absolute():
            return self.directory
        return repo_path / self.directory


@dataclass(frozen=True, slots=True)
class ContextCacheSettings:
    """Context cache and component-hash recording settings."""

    enabled: bool = True
    hash_components: bool = True
    record_provider_cache: bool = True


@dataclass(frozen=True, slots=True)
class ContextSettings:
    """Durable session history and context-window settings."""

    enabled: bool = True
    store_dir: Path = Path("sessions")
    database_url: str | None = None
    sqlite_file: str = "sessions.sqlite"
    events_dir: Path = Path("sessions/events")
    auto_compact: bool = True
    compact_threshold: float = 0.70
    max_context_tokens: int = 12000
    protected_head_messages: int = 2
    protected_tail_turns: int = 6
    tool_output_max_chars: int = 2000
    summary_model: str | None = None
    tokenizer: str = "heuristic"
    cache: ContextCacheSettings = field(default_factory=ContextCacheSettings)

    def resolve_store_dir(self, repo_path: Path) -> Path:
        if self.store_dir.is_absolute():
            return self.store_dir
        return repo_path / self.store_dir

    def resolve_sqlite_path(self, repo_path: Path) -> Path:
        sqlite_path = Path(self.sqlite_file)
        if sqlite_path.is_absolute():
            return sqlite_path
        return self.resolve_store_dir(repo_path) / sqlite_path

    def resolve_events_dir(self, repo_path: Path) -> Path:
        if self.events_dir.is_absolute():
            return self.events_dir
        return repo_path / self.events_dir


@dataclass(frozen=True, slots=True)
class ModelPricing:
    """Per-model price table (USD per 1M tokens).

    Industry-standard unit is per-million-tokens — match every public
    pricing page (OpenAI, Anthropic, DeepSeek, Gemini, Mistral, xAI,
    DashScope) so users can paste rates verbatim.
    """

    input_per_1m: float = 0.0
    output_per_1m: float = 0.0
    cached_input_per_1m: float | None = None


@dataclass(frozen=True, slots=True)
class ModelSettings:
    """Direct any-llm API model settings."""

    name: str
    provider: str
    model: str
    api_key: str | None = None
    base_url: str | None = None
    temperature: float | None = None
    top_p: float | None = None
    max_tokens: int | None = None
    max_output_tokens: int | None = None
    client_args: dict[str, Any] = field(default_factory=dict)
    extra: dict[str, Any] = field(default_factory=dict)
    pricing: ModelPricing | None = None

    def direct_api_kwargs(self, **overrides: Any) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "model": self.model,
            "provider": self.provider,
            "api_key": self.api_key,
            "api_base": self.base_url,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "max_tokens": self.max_tokens,
            "max_output_tokens": self.max_output_tokens,
            "client_args": self.client_args or None,
            **self.extra,
            **overrides,
        }
        return {key: value for key, value in kwargs.items() if value is not None}


@dataclass(frozen=True, slots=True)
class AgentSettings:
    """Default agent settings."""

    name: str = "hajimi"
    default_model: str | None = None
    system_prompt: str | None = None
    max_tool_rounds: int = 4
    skills: list[str] = field(default_factory=list)
    skill_loading: "AgentSkillLoadingSettings" = field(default_factory=lambda: AgentSkillLoadingSettings())
    subagents: "SubAgentSettings" = field(default_factory=lambda: SubAgentSettings())
    teammates: "TeammateSettings" = field(default_factory=lambda: TeammateSettings())
    profiles: dict[str, "AgentProfileSettings"] = field(default_factory=dict)
    tool_search: "AgentToolSearchSettings" = field(default_factory=lambda: AgentToolSearchSettings())
    workspace_tools: "AgentWorkspaceToolsSettings" = field(default_factory=lambda: AgentWorkspaceToolsSettings())
    routing: "AgentRoutingSettings" = field(default_factory=lambda: AgentRoutingSettings())


@dataclass(frozen=True, slots=True)
class AgentToolSearchSettings:
    """Dynamic tool search settings."""

    enabled: bool = False
    tool_name: str = TOOL_SEARCH_NAME
    max_results: int = 8
    defer_tools: bool = True


@dataclass(frozen=True, slots=True)
class AgentWorkspaceToolsSettings:
    """Built-in workspace file, search, and shell tools."""

    enabled: bool = True
    sandbox_provider: str = "e2b"
    root: Path | None = None
    allow_write: bool = False
    allow_shell: bool = False
    max_read_chars: int = 20000
    max_output_chars: int = 12000
    max_search_results: int = 100
    allowed_shell_commands: list[str] = field(default_factory=list)
    e2b_sandbox_id: str | None = None
    e2b_template: str | None = None
    e2b_timeout: int | None = 300
    e2b_allow_internet_access: bool = True
    read_tool_name: str = WORKSPACE_READ_TOOL_NAME
    read_tool_description: str = WORKSPACE_READ_TOOL_DESCRIPTION
    write_tool_name: str = WORKSPACE_WRITE_TOOL_NAME
    write_tool_description: str = WORKSPACE_WRITE_TOOL_DESCRIPTION
    edit_tool_name: str = WORKSPACE_EDIT_TOOL_NAME
    edit_tool_description: str = WORKSPACE_EDIT_TOOL_DESCRIPTION
    grep_tool_name: str = WORKSPACE_GREP_TOOL_NAME
    grep_tool_description: str = WORKSPACE_GREP_TOOL_DESCRIPTION
    glob_tool_name: str = WORKSPACE_GLOB_TOOL_NAME
    glob_tool_description: str = WORKSPACE_GLOB_TOOL_DESCRIPTION
    bash_tool_name: str = WORKSPACE_BASH_TOOL_NAME
    bash_tool_description: str = WORKSPACE_BASH_TOOL_DESCRIPTION


@dataclass(frozen=True, slots=True)
class AgentSkillLoadingSettings:
    """Progressive skill loading settings."""

    progressive: bool = True
    activation_tool_name: str = SKILL_TOOL_NAME
    script_tool_name: str = SKILL_SCRIPT_TOOL_NAME
    sandbox_stage_path: str = ".hajimi/skill-runs"
    max_resources: int = 200
    auto_discover: bool = True
    discovery_dirs: list[str] = field(
        default_factory=lambda: [
            "skills",
            ".agents/skills",
            ".claude/skills",
        ]
    )


@dataclass(frozen=True, slots=True)
class AgentProfileSettings:
    """Reusable settings for named agents."""

    name: str
    model_name: str | None = None
    system_prompt: str | None = None
    max_tool_rounds: int | None = None
    skills: list[str] = field(default_factory=list)
    mcp_servers: list[str] = field(default_factory=list)
    tool_names: list[str] | None = None


@dataclass(frozen=True, slots=True)
class AgentRoutingSettings:
    """High-level task routing defaults."""

    enabled: bool = True
    strategy: str = "auto"
    simple_max_words: int = 80
    simple_max_tool_markers: int = 0
    default_mode: str = "auto"
    default_profiles: list[str] = field(default_factory=list)
    default_replicas: int = 1
    planner_profile: str | None = None
    synthesizer_profile: str | None = None
    max_parallel_agents: int = 4
    max_budget_tokens: int | None = None


@dataclass(frozen=True, slots=True)
class SubAgentSettings:
    """Nested agent tool settings."""

    enabled: bool = False
    max_depth: int = 2
    tool_name: str = SUBAGENT_TOOL_NAME
    tool_description: str = SUBAGENT_TOOL_DESCRIPTION
    max_tool_rounds: int | None = None


@dataclass(frozen=True, slots=True)
class TeammateSettings:
    """Persistent in-process teammate settings."""

    enabled: bool = False
    max_members: int = 4
    spawn_tool_name: str = TEAM_SPAWN_TOOL_NAME
    send_tool_name: str = TEAM_SEND_TOOL_NAME
    broadcast_tool_name: str = TEAM_BROADCAST_TOOL_NAME
    list_tool_name: str = TEAM_LIST_TOOL_NAME
    close_tool_name: str = TEAM_CLOSE_TOOL_NAME
    max_tool_rounds: int | None = None


@dataclass(frozen=True, slots=True)
class AppConfig:
    """Loaded project configuration."""

    repo_path: Path
    agent: AgentSettings
    log: LogSettings
    observability: ObservabilitySettings
    mcp: MCPSettings
    models: dict[str, ModelSettings]
    context: ContextSettings = field(default_factory=ContextSettings)

    def model(self, name: str | None = None) -> ModelSettings:
        model_name = name or self.agent.default_model
        if model_name is None:
            try:
                return next(iter(self.models.values()))
            except StopIteration as exc:
                raise ValueError("No model is configured.") from exc
        try:
            return self.models[model_name]
        except KeyError as exc:
            names = ", ".join(sorted(self.models))
            raise KeyError(f"Unknown model {model_name!r}. Available models: {names}") from exc
