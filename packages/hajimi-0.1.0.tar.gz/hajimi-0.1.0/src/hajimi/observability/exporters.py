"""Span exporters for local and remote observability backends."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

import anyio

from hajimi.observability.types import SpanRecord


class SpanExporter(Protocol):
    async def export(self, span: SpanRecord) -> None:
        """Export a completed span."""


@dataclass(slots=True)
class NullSpanExporter:
    async def export(self, span: SpanRecord) -> None:
        return None


@dataclass(slots=True)
class CompositeSpanExporter:
    exporters: list[SpanExporter]

    async def export(self, span: SpanRecord) -> None:
        for exporter in self.exporters:
            await exporter.export(span)


@dataclass(slots=True)
class JsonlSpanExporter:
    path: Path
    _lock: anyio.Lock = field(default_factory=anyio.Lock, init=False, repr=False)

    async def export(self, span: SpanRecord) -> None:
        line = json.dumps(span.to_dict(), ensure_ascii=False, default=str) + "\n"
        async with self._lock:
            async with await anyio.open_file(self.path, "a", encoding="utf-8") as file:
                await file.write(line)
