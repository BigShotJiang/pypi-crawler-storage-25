"""Observability setup helpers."""

from pathlib import Path

import anyio

from hajimi.config import ObservabilitySettings
from hajimi.observability.exporters import JsonlSpanExporter, NullSpanExporter
from hajimi.observability.otel import build_otel_tracer
from hajimi.observability.tracer import NoOpTraceManager, TraceManager


async def setup_observability(settings: ObservabilitySettings, repo_path: Path) -> TraceManager:
    """Build the project's trace manager from config."""

    if not settings.enabled:
        return NoOpTraceManager()

    trace_dir = settings.resolve_directory(repo_path)
    await anyio.Path(trace_dir).mkdir(parents=True, exist_ok=True)
    exporter = JsonlSpanExporter(trace_dir / settings.file_name)

    return TraceManager(
        exporter=exporter if settings.enabled else NullSpanExporter(),
        sample_rate=settings.sample_rate,
        include_content=settings.include_content,
        max_content_chars=settings.max_content_chars,
        otel_tracer=build_otel_tracer(settings.otel),
    )
