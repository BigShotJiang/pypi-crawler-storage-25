"""Structured trace records."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


@dataclass(frozen=True, slots=True)
class SpanEvent:
    name: str
    timestamp_ns: int
    attributes: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "timestamp": _ns_to_iso(self.timestamp_ns),
            "timestamp_ns": self.timestamp_ns,
            "attributes": self.attributes,
        }


@dataclass(frozen=True, slots=True)
class SpanRecord:
    trace_id: str
    span_id: str
    parent_span_id: str | None
    name: str
    kind: str
    status: str
    error: str | None
    started_at_ns: int
    ended_at_ns: int
    duration_ms: float
    attributes: dict[str, Any] = field(default_factory=dict)
    events: list[SpanEvent] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "trace_id": self.trace_id,
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id,
            "name": self.name,
            "kind": self.kind,
            "status": self.status,
            "error": self.error,
            "started_at": _ns_to_iso(self.started_at_ns),
            "ended_at": _ns_to_iso(self.ended_at_ns),
            "started_at_ns": self.started_at_ns,
            "ended_at_ns": self.ended_at_ns,
            "duration_ms": self.duration_ms,
            "attributes": self.attributes,
            "events": [event.to_dict() for event in self.events],
        }


def _ns_to_iso(value: int) -> str:
    return datetime.fromtimestamp(value / 1_000_000_000, UTC).isoformat()
