"""Small async tracing API for agents, tools, and model calls."""

from __future__ import annotations

import contextlib
import contextvars
import random
import time
import uuid
from collections.abc import AsyncIterator, Mapping
from dataclasses import dataclass, field
from typing import Any

from hajimi.observability.exporters import NullSpanExporter, SpanExporter
from hajimi.observability.types import SpanEvent, SpanRecord

_CURRENT_SPAN: contextvars.ContextVar["TraceSpan | None"] = contextvars.ContextVar(
    "hajimi_current_span",
    default=None,
)


@dataclass(slots=True)
class TraceManager:
    exporter: SpanExporter = field(default_factory=NullSpanExporter)
    sample_rate: float = 1.0
    include_content: bool = True
    max_content_chars: int = 4000
    otel_tracer: Any | None = None

    @contextlib.asynccontextmanager
    async def span(
        self,
        name: str,
        *,
        kind: str = "internal",
        attributes: Mapping[str, Any] | None = None,
    ) -> AsyncIterator["TraceSpan"]:
        parent = _CURRENT_SPAN.get()
        if parent is None and not self._sampled():
            yield NoOpTraceSpan()
            return

        otel_context = None
        otel_span = None
        if self.otel_tracer is not None:
            otel_context = self.otel_tracer.start_as_current_span(
                name,
                attributes=_clean_attributes(attributes or {}),
            )
            otel_span = otel_context.__enter__()

        span = TraceSpan(
            manager=self,
            trace_id=parent.trace_id if parent else uuid.uuid4().hex,
            span_id=uuid.uuid4().hex[:16],
            parent_span_id=parent.span_id if parent else None,
            name=name,
            kind=kind,
            attributes=dict(attributes or {}),
            started_at_ns=time.time_ns(),
            otel_span=otel_span,
        )
        token = _CURRENT_SPAN.set(span)

        try:
            yield span
        except BaseException as exc:
            span.record_exception(exc)
            raise
        finally:
            _CURRENT_SPAN.reset(token)
            span.end()
            if otel_context is not None:
                otel_context.__exit__(None, None, None)
            await self.exporter.export(span.to_record())

    def content(self, value: Any) -> str:
        text = "" if value is None else str(value)
        if len(text) <= self.max_content_chars:
            return text
        return f"{text[: self.max_content_chars]}...<truncated>"

    def _sampled(self) -> bool:
        return self.sample_rate >= 1.0 or random.random() < self.sample_rate


class NoOpTraceManager(TraceManager):
    def __init__(self) -> None:
        super().__init__(exporter=NullSpanExporter(), sample_rate=0.0, include_content=False)

    @contextlib.asynccontextmanager
    async def span(
        self,
        name: str,
        *,
        kind: str = "internal",
        attributes: Mapping[str, Any] | None = None,
    ) -> AsyncIterator["TraceSpan"]:
        yield NoOpTraceSpan()


@dataclass(slots=True)
class TraceSpan:
    manager: TraceManager
    trace_id: str
    span_id: str
    parent_span_id: str | None
    name: str
    kind: str
    attributes: dict[str, Any] = field(default_factory=dict)
    events: list[SpanEvent] = field(default_factory=list)
    started_at_ns: int = field(default_factory=time.time_ns)
    ended_at_ns: int | None = None
    status: str = "ok"
    error: str | None = None
    otel_span: Any | None = None

    def set_attribute(self, key: str, value: Any) -> None:
        self.attributes[key] = value
        if self.otel_span is not None:
            self.otel_span.set_attribute(key, _clean_value(value))

    def set_attributes(self, attributes: Mapping[str, Any]) -> None:
        for key, value in attributes.items():
            self.set_attribute(key, value)

    def add_event(self, name: str, attributes: Mapping[str, Any] | None = None) -> None:
        event = SpanEvent(name=name, timestamp_ns=time.time_ns(), attributes=dict(attributes or {}))
        self.events.append(event)
        if self.otel_span is not None:
            self.otel_span.add_event(name, attributes=_clean_attributes(event.attributes))

    def record_exception(self, exc: BaseException) -> None:
        self.status = "error"
        self.error = f"{type(exc).__name__}: {exc}"
        self.add_event(
            "exception",
            {
                "exception.type": type(exc).__name__,
                "exception.message": str(exc),
            },
        )
        if self.otel_span is not None:
            from opentelemetry import trace

            self.otel_span.record_exception(exc)
            self.otel_span.set_status(trace.StatusCode.ERROR, str(exc))

    def end(self) -> None:
        if self.ended_at_ns is None:
            self.ended_at_ns = time.time_ns()

    def to_record(self) -> SpanRecord:
        ended_at_ns = self.ended_at_ns or time.time_ns()
        return SpanRecord(
            trace_id=self.trace_id,
            span_id=self.span_id,
            parent_span_id=self.parent_span_id,
            name=self.name,
            kind=self.kind,
            status=self.status,
            error=self.error,
            started_at_ns=self.started_at_ns,
            ended_at_ns=ended_at_ns,
            duration_ms=(ended_at_ns - self.started_at_ns) / 1_000_000,
            attributes=dict(self.attributes),
            events=list(self.events),
        )


class NoOpTraceSpan(TraceSpan):
    def __init__(self) -> None:
        super().__init__(
            manager=NoOpTraceManager.__new__(NoOpTraceManager),
            trace_id="",
            span_id="",
            parent_span_id=None,
            name="noop",
            kind="noop",
        )

    def set_attribute(self, key: str, value: Any) -> None:
        return None

    def set_attributes(self, attributes: Mapping[str, Any]) -> None:
        return None

    def add_event(self, name: str, attributes: Mapping[str, Any] | None = None) -> None:
        return None

    def record_exception(self, exc: BaseException) -> None:
        return None

    def end(self) -> None:
        return None


def _clean_attributes(attributes: Mapping[str, Any]) -> dict[str, Any]:
    return {key: _clean_value(value) for key, value in attributes.items()}


def _clean_value(value: Any) -> Any:
    if value is None or isinstance(value, str | int | float | bool):
        return value
    if isinstance(value, list | tuple):
        return [_clean_value(item) for item in value]
    return str(value)
