"""Optional OpenTelemetry bridge.

The imports are intentionally lazy so local JSONL tracing works without OTel
dependencies installed.
"""

from __future__ import annotations

from typing import Any

from hajimi.config import OpenTelemetrySettings


def build_otel_tracer(settings: OpenTelemetrySettings) -> Any | None:
    if not settings.enabled:
        return None

    try:
        from opentelemetry import trace
    except ImportError as exc:
        raise RuntimeError(
            "OpenTelemetry export is enabled, but opentelemetry packages are not installed. "
            "Install with `uv sync --extra observability`."
        ) from exc

    if settings.endpoint:
        _configure_otel_provider(settings)

    return trace.get_tracer("hajimi", settings.service_version)


def _configure_otel_provider(settings: OpenTelemetrySettings) -> None:
    from opentelemetry import trace
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    provider = TracerProvider(
        resource=Resource.create(
            {
                "service.name": settings.service_name,
                **({"service.version": settings.service_version} if settings.service_version else {}),
            }
        )
    )
    provider.add_span_processor(BatchSpanProcessor(_build_otlp_exporter(settings)))
    trace.set_tracer_provider(provider)


def _build_otlp_exporter(settings: OpenTelemetrySettings) -> Any:
    if settings.protocol == "grpc":
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

        return OTLPSpanExporter(
            endpoint=settings.endpoint,
            headers=settings.headers,
            insecure=settings.insecure,
            timeout=settings.timeout,
        )

    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

    return OTLPSpanExporter(
        endpoint=settings.endpoint,
        headers=settings.headers,
        timeout=settings.timeout,
    )
