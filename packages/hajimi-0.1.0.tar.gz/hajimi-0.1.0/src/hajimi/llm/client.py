"""Direct async any-llm client wrappers."""

from __future__ import annotations

from collections.abc import AsyncIterator, Callable, Sequence
from dataclasses import dataclass, field
from typing import Any

import any_llm

from hajimi.config import ModelSettings
from hajimi.llm.extract import completion_chunk_text, completion_text, response_event_text, response_text
from hajimi.corekit import ModelResult, ModelStreamChunk
from hajimi.observability import NoOpTraceManager, TraceManager

type CompletionAPI = Callable[..., Any]
type EmbeddingAPI = Callable[..., Any]
type ResponsesAPI = Callable[..., Any]
type Message = dict[str, Any]


@dataclass(slots=True)
class AnyLLMClient:
    """Small async adapter around any-llm direct APIs."""

    settings: ModelSettings
    completion_api: CompletionAPI = any_llm.acompletion
    embedding_api: EmbeddingAPI = any_llm.aembedding
    responses_api: ResponsesAPI = any_llm.aresponses
    tracer: TraceManager = field(default_factory=NoOpTraceManager)

    async def complete(
        self,
        messages: Sequence[Message],
        **overrides: Any,
    ) -> ModelResult:
        """Call `any_llm.acompletion` once and return extracted assistant text."""

        message_list = list(messages)
        async with self.tracer.span(
            "llm.completion",
            kind="llm",
            attributes=self._base_span_attributes(message_list, stream=False),
        ) as span:
            if self.tracer.include_content:
                span.add_event("llm.input", {"messages": self.tracer.content(message_list)})
            response = await self.completion_api(
                messages=message_list,
                **self._completion_kwargs(stream=False, **overrides),
            )
            text = completion_text(response)
            span.set_attributes(_usage_attributes(response))
            span.set_attribute("llm.response.length", len(text))
            if self.tracer.include_content:
                span.add_event("llm.output", {"content": self.tracer.content(text)})
            return ModelResult(text=text, raw=response)

    async def stream_complete(
        self,
        messages: Sequence[Message],
        **overrides: Any,
    ) -> AsyncIterator[ModelStreamChunk]:
        """Stream text deltas from `any_llm.acompletion`."""

        message_list = list(messages)
        async with self.tracer.span(
            "llm.completion.stream",
            kind="llm",
            attributes=self._base_span_attributes(message_list, stream=True),
        ) as span:
            if self.tracer.include_content:
                span.add_event("llm.input", {"messages": self.tracer.content(message_list)})
            output_parts: list[str] = []
            chunk_count = 0
            stream = await self.completion_api(
                messages=message_list,
                **self._completion_kwargs(stream=True, **overrides),
            )
            async for chunk in stream:
                text = completion_chunk_text(chunk)
                if text:
                    chunk_count += 1
                    output_parts.append(text)
                    yield ModelStreamChunk(text=text, raw=chunk)
                elif getattr(chunk, "usage", None) is not None:
                    # OpenAI-compatible streams emit usage on a final empty
                    # chunk when `stream_options={"include_usage": true}`.
                    # Forward it so downstream meters can record it.
                    yield ModelStreamChunk(text="", raw=chunk)
            output = "".join(output_parts)
            span.set_attribute("llm.stream.chunks", chunk_count)
            span.set_attribute("llm.response.length", len(output))
            if self.tracer.include_content:
                span.add_event("llm.output", {"content": self.tracer.content(output)})

    async def embed(
        self,
        inputs: str | list[str],
        *,
        settings: ModelSettings | None = None,
        **overrides: Any,
    ) -> Any:
        """Call `any_llm.aembedding` and return the raw embedding response."""

        active_settings = settings or self.settings
        async with self.tracer.span(
            "llm.embedding",
            kind="llm",
            attributes={
                "llm.provider": active_settings.provider,
                "llm.model": active_settings.model,
                "llm.input.count": len(inputs) if isinstance(inputs, list) else 1,
            },
        ) as span:
            if self.tracer.include_content:
                span.add_event("llm.embedding.input", {"inputs": self.tracer.content(inputs)})
            response = await self.embedding_api(
                inputs=inputs,
                **self._embedding_kwargs(active_settings, **overrides),
            )
            span.set_attribute("llm.embedding.count", len(getattr(response, "data", [])))
            return response

    async def embed_vectors(
        self,
        inputs: str | list[str],
        *,
        settings: ModelSettings | None = None,
        **overrides: Any,
    ) -> list[list[float]]:
        """Return only embedding vectors from `any_llm.aembedding`."""

        response = await self.embed(inputs, settings=settings, **overrides)
        return [list(item.embedding) for item in response.data]

    async def respond(
        self,
        input_data: str | list[Any],
        **overrides: Any,
    ) -> ModelResult:
        """Call `any_llm.aresponses` once and return extracted output text."""

        async with self.tracer.span(
            "llm.responses",
            kind="llm",
            attributes=self._responses_span_attributes(input_data, stream=False),
        ) as span:
            if self.tracer.include_content:
                span.add_event("llm.input", {"input": self.tracer.content(input_data)})
            response = await self.responses_api(
                input_data=input_data,
                **self._responses_kwargs(stream=False, **overrides),
            )
            text = response_text(response)
            span.set_attribute("llm.response.length", len(text))
            if self.tracer.include_content:
                span.add_event("llm.output", {"content": self.tracer.content(text)})
            return ModelResult(text=text, raw=response)

    async def stream_respond(
        self,
        input_data: str | list[Any],
        **overrides: Any,
    ) -> AsyncIterator[ModelStreamChunk]:
        """Stream text deltas from `any_llm.aresponses`."""

        async with self.tracer.span(
            "llm.responses.stream",
            kind="llm",
            attributes=self._responses_span_attributes(input_data, stream=True),
        ) as span:
            if self.tracer.include_content:
                span.add_event("llm.input", {"input": self.tracer.content(input_data)})
            output_parts: list[str] = []
            chunk_count = 0
            stream = await self.responses_api(
                input_data=input_data,
                **self._responses_kwargs(stream=True, **overrides),
            )
            async for event in stream:
                text = response_event_text(event)
                if text:
                    chunk_count += 1
                    output_parts.append(text)
                    yield ModelStreamChunk(text=text, raw=event)
            output = "".join(output_parts)
            span.set_attribute("llm.stream.chunks", chunk_count)
            span.set_attribute("llm.response.length", len(output))
            if self.tracer.include_content:
                span.add_event("llm.output", {"content": self.tracer.content(output)})

    def _base_span_attributes(self, messages: Sequence[Message], *, stream: bool) -> dict[str, Any]:
        return {
            "llm.provider": self.settings.provider,
            "llm.model": self.settings.model,
            "llm.api": "completion",
            "llm.stream": stream,
            "llm.input.messages": len(messages),
        }

    def _responses_span_attributes(self, input_data: str | list[Any], *, stream: bool) -> dict[str, Any]:
        return {
            "llm.provider": self.settings.provider,
            "llm.model": self.settings.model,
            "llm.api": "responses",
            "llm.stream": stream,
            "llm.input.count": len(input_data) if isinstance(input_data, list) else 1,
        }

    def _completion_kwargs(self, **overrides: Any) -> dict[str, Any]:
        return self._direct_kwargs(self.settings, drop={"max_output_tokens"}, **overrides)

    def _responses_kwargs(self, **overrides: Any) -> dict[str, Any]:
        kwargs = self._direct_kwargs(self.settings, drop={"max_tokens"}, **overrides)
        if "max_output_tokens" not in kwargs and self.settings.max_tokens is not None:
            kwargs["max_output_tokens"] = self.settings.max_tokens
        return kwargs

    def _embedding_kwargs(
        self,
        settings: ModelSettings,
        **overrides: Any,
    ) -> dict[str, Any]:
        return self._direct_kwargs(
            settings,
            drop={
                "temperature",
                "top_p",
                "max_tokens",
                "max_output_tokens",
            },
            **overrides,
        )

    @staticmethod
    def _direct_kwargs(
        settings: ModelSettings,
        *,
        drop: set[str],
        **overrides: Any,
    ) -> dict[str, Any]:
        kwargs = settings.direct_api_kwargs(**overrides)
        for key in drop:
            kwargs.pop(key, None)
        return kwargs


def _usage_attributes(response: Any) -> dict[str, Any]:
    usage = getattr(response, "usage", None)
    if usage is None:
        return {}
    return {
        key: value
        for key, value in {
            "llm.usage.prompt_tokens": getattr(usage, "prompt_tokens", None),
            "llm.usage.completion_tokens": getattr(usage, "completion_tokens", None),
            "llm.usage.total_tokens": getattr(usage, "total_tokens", None),
        }.items()
        if value is not None
    }
