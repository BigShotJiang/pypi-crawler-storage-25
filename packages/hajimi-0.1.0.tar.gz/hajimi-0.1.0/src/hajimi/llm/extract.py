"""Best-effort text extraction from any-llm compatible response objects."""

from __future__ import annotations

from typing import Any

_USAGE_KEYS = (
    "prompt_tokens",
    "completion_tokens",
    "total_tokens",
    "reasoning_tokens",
    "cache_read_tokens",
    "cache_write_tokens",
)


def provider_usage(raw: Any) -> dict[str, int]:
    """Extract token usage from a provider response, dict or attribute style."""

    usage = getattr(raw, "usage", None)
    if usage is None and isinstance(raw, dict):
        usage = raw.get("usage")
    if usage is None:
        return {}
    out: dict[str, int] = {}
    for key in _USAGE_KEYS:
        value = usage.get(key) if isinstance(usage, dict) else getattr(usage, key, None)
        if value is None:
            continue
        try:
            out[key] = int(value)
        except (TypeError, ValueError):
            continue
    return out


def completion_text(response: Any) -> str:
    choice = response.choices[0]
    message = choice.message
    content = _coerce_text(_read_attr(message, "content"))
    if content:
        return content
    return ""


def completion_chunk_text(chunk: Any) -> str:
    if not getattr(chunk, "choices", None):
        return ""
    delta = chunk.choices[0].delta
    return _coerce_text(_read_attr(delta, "content"))


def response_text(response: Any) -> str:
    text = _read_attr(response, "output_text")
    if text:
        return _coerce_text(text)

    output = _read_attr(response, "output")
    if isinstance(output, list):
        return "".join(_coerce_text(_read_attr(item, "content")) for item in output)
    return _coerce_text(output)


def response_event_text(event: Any) -> str:
    event_type = _read_attr(event, "type")
    if event_type and "delta" not in str(event_type) and not str(event_type).endswith(".done"):
        return ""
    return _coerce_text(_read_attr(event, "delta") or _read_attr(event, "output_text"))


def _read_attr(value: Any, name: str) -> Any:
    if isinstance(value, dict):
        return value.get(name)
    return getattr(value, name, None)


def _coerce_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "".join(_coerce_text(item) for item in value)
    if isinstance(value, dict):
        if "text" in value:
            return _coerce_text(value["text"])
        if "content" in value:
            return _coerce_text(value["content"])
        return ""
    for attr in ("text", "content"):
        if not hasattr(value, attr):
            continue
        attr_value = getattr(value, attr)
        if attr_value is not None and not callable(attr_value):
            return _coerce_text(attr_value)
    if hasattr(value, "model_dump"):
        return _coerce_text(value.model_dump(exclude_none=True))
    return str(value)
