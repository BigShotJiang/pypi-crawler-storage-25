"""LLM result types."""

from hajimi.corekit import ModelResult, ModelStreamChunk

__all__ = ["ModelResult", "ModelStreamChunk"]
