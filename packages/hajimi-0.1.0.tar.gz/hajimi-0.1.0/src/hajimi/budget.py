"""Cost and token budget enforcement.

The `BudgetMeter` is shared across an agent run (single agent, sub-agents, or
replicas) so that the runtime can both report aggregate cost and abort when a
hard cap is crossed. It records provider-reported usage when available and
falls back to local estimates otherwise.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any, Literal

import anyio

from hajimi.config import ModelPricing
from hajimi.llm.extract import provider_usage

type ExceededPolicy = Literal["raise", "stop"]


class BudgetExceeded(RuntimeError):
    """Raised when a `BudgetMeter` enforces a hard cap and the policy is `raise`."""

    def __init__(self, reason: str, report: "CostReport") -> None:
        super().__init__(f"Budget exceeded: {reason}")
        self.reason = reason
        self.report = report


@dataclass(slots=True)
class CostReport:
    """Aggregate cost and token report for one run."""

    input_tokens: int = 0
    output_tokens: int = 0
    cached_input_tokens: int = 0
    reasoning_tokens: int = 0
    total_tokens: int = 0
    cost_usd: float = 0.0
    rounds: int = 0
    by_model: dict[str, dict[str, float]] = field(default_factory=dict)
    aborted: bool = False
    aborted_reason: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cached_input_tokens": self.cached_input_tokens,
            "reasoning_tokens": self.reasoning_tokens,
            "total_tokens": self.total_tokens,
            "cost_usd": round(self.cost_usd, 6),
            "rounds": self.rounds,
            "by_model": {
                model: {key: (round(value, 6) if isinstance(value, float) else value) for key, value in entry.items()}
                for model, entry in self.by_model.items()
            },
            "aborted": self.aborted,
            "aborted_reason": self.aborted_reason,
        }


@dataclass(slots=True)
class BudgetMeter:
    """Shared meter that records token usage and enforces hard caps."""

    max_input_tokens: int | None = None
    max_output_tokens: int | None = None
    max_total_tokens: int | None = None
    max_cost_usd: float | None = None
    on_exceeded: ExceededPolicy = "raise"
    pricing: dict[str, ModelPricing] = field(default_factory=dict)
    report: CostReport = field(default_factory=CostReport)
    _lock: anyio.Lock = field(default_factory=anyio.Lock)

    @classmethod
    def from_options(
        cls,
        *,
        max_input_tokens: int | None = None,
        max_output_tokens: int | None = None,
        max_total_tokens: int | None = None,
        max_cost_usd: float | None = None,
        on_exceeded: ExceededPolicy = "raise",
        pricing: Mapping[str, ModelPricing] | None = None,
    ) -> "BudgetMeter":
        return cls(
            max_input_tokens=max_input_tokens,
            max_output_tokens=max_output_tokens,
            max_total_tokens=max_total_tokens,
            max_cost_usd=max_cost_usd,
            on_exceeded=on_exceeded,
            pricing=dict(pricing or {}),
        )

    def is_active(self) -> bool:
        if self.pricing:
            return True
        return any(
            cap is not None
            for cap in (
                self.max_input_tokens,
                self.max_output_tokens,
                self.max_total_tokens,
                self.max_cost_usd,
            )
        )

    async def record_raw(self, *, model: str, raw: Any) -> None:
        """Record provider-reported usage from a raw completion response."""

        await self.record(model=model, usage=provider_usage(raw))

    async def record_estimate(self, *, model: str, input_tokens: int, output_tokens: int) -> None:
        """Record local token estimates when a streamed provider omits usage."""

        await self.record(
            model=model,
            usage={
                "prompt_tokens": input_tokens,
                "completion_tokens": output_tokens,
                "total_tokens": input_tokens + output_tokens,
            },
        )

    async def record(self, *, model: str, usage: Mapping[str, int]) -> None:
        if not usage:
            return
        async with self._lock:
            self.report.rounds += 1
            input_tokens = int(usage.get("prompt_tokens", 0) or 0)
            output_tokens = int(usage.get("completion_tokens", 0) or 0)
            cached_input = int(usage.get("cache_read_tokens", 0) or 0)
            reasoning_tokens = int(usage.get("reasoning_tokens", 0) or 0)
            total = int(usage.get("total_tokens", 0) or (input_tokens + output_tokens))

            self.report.input_tokens += input_tokens
            self.report.output_tokens += output_tokens
            self.report.cached_input_tokens += cached_input
            self.report.reasoning_tokens += reasoning_tokens
            self.report.total_tokens += total

            cost_delta = self._cost_for(model, input_tokens, output_tokens, cached_input)
            self.report.cost_usd += cost_delta

            entry = self.report.by_model.setdefault(
                model,
                {"input_tokens": 0, "output_tokens": 0, "cost_usd": 0.0, "rounds": 0},
            )
            entry["input_tokens"] = int(entry["input_tokens"]) + input_tokens
            entry["output_tokens"] = int(entry["output_tokens"]) + output_tokens
            entry["cost_usd"] = float(entry["cost_usd"]) + cost_delta
            entry["rounds"] = int(entry["rounds"]) + 1

    def _cost_for(
        self,
        model: str,
        input_tokens: int,
        output_tokens: int,
        cached_input: int,
    ) -> float:
        pricing = self.pricing.get(model)
        if pricing is None:
            return 0.0
        billable_input = max(0, input_tokens - cached_input)
        cost = (billable_input / 1_000_000.0) * pricing.input_per_1m
        if cached_input and pricing.cached_input_per_1m is not None:
            cost += (cached_input / 1_000_000.0) * pricing.cached_input_per_1m
        cost += (output_tokens / 1_000_000.0) * pricing.output_per_1m
        return cost

    def should_abort(self) -> tuple[bool, str | None]:
        if self.max_input_tokens is not None and self.report.input_tokens > self.max_input_tokens:
            return True, f"input_tokens {self.report.input_tokens} > {self.max_input_tokens}"
        if self.max_output_tokens is not None and self.report.output_tokens > self.max_output_tokens:
            return True, f"output_tokens {self.report.output_tokens} > {self.max_output_tokens}"
        if self.max_total_tokens is not None and self.report.total_tokens > self.max_total_tokens:
            return True, f"total_tokens {self.report.total_tokens} > {self.max_total_tokens}"
        if self.max_cost_usd is not None and self.report.cost_usd > self.max_cost_usd:
            return True, f"cost_usd {self.report.cost_usd:.6f} > {self.max_cost_usd:.6f}"
        return False, None

    def enforce(self) -> bool:
        """Apply the configured policy. Returns True when the run should stop."""

        aborted, reason = self.should_abort()
        if not aborted:
            return False
        self.report.aborted = True
        self.report.aborted_reason = reason
        if self.on_exceeded == "raise":
            raise BudgetExceeded(reason or "budget", self.report)
        return True


__all__ = [
    "BudgetExceeded",
    "BudgetMeter",
    "CostReport",
    "ExceededPolicy",
]
