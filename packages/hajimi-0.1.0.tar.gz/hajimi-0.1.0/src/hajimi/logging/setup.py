"""Loguru setup helpers."""

from pathlib import Path
import sys

import anyio
from loguru import logger

from hajimi.config import LogSettings

_FORMAT = (
    "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
    "<level>{level: <8}</level> | "
    "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
    "<level>{message}</level>"
)


async def configure_logging(settings: LogSettings, repo_path: Path) -> Path | None:
    """Configure console and file sinks from project settings."""

    logger.remove()

    if settings.enable_console:
        logger.add(
            sys.stderr,
            level=settings.console_level,
            colorize=settings.colorize,
            format=_FORMAT,
            backtrace=settings.backtrace,
            diagnose=settings.diagnose,
        )

    if not settings.enable_file:
        return None

    log_dir = settings.resolve_directory(repo_path)
    await anyio.Path(log_dir).mkdir(parents=True, exist_ok=True)
    log_file = log_dir / settings.file_name
    logger.add(
        log_file,
        level=settings.file_level,
        rotation=settings.rotation,
        retention=settings.retention,
        compression=settings.compression,
        enqueue=settings.enqueue,
        format=_FORMAT,
        serialize=settings.serialize_file,
        backtrace=settings.backtrace,
        diagnose=settings.diagnose,
    )
    return log_file
