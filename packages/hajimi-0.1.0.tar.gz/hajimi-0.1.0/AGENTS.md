# Repository Guidelines

## Project Structure & Module Organization

This is an async-first Python agent framework packaged from `src/hajimi`.
Runtime code lives in focused subpackages: `core/` for agents and teams,
`corekit/` for the reusable agent loop, model/tool protocols, registry,
dispatcher, and schema helpers, `llm/` for provider wrappers, `tool/` for
framework tool integrations, `skill/`
for local skills, `mcp/` for clients, `session/` for durable context, and
`observability/` plus `logging/` for traces and logs. Tests live in
`tests/test_*.py`; examples in `examples/`; public docs in `docs/`; design
notes in `agents-docs/`; sample skills in `skills/`.

## Build, Test, and Development Commands

- `uv sync`: create or update the environment.
- `uv sync --extra mcp`: install optional MCP support.
- `uv sync --extra observability`: install OpenTelemetry exporters.
- `cp examples/configs/.env.example examples/configs/.env`: create local
  example credentials and settings.
- `uv run python examples/basic_agent.py`: run the basic local example.
- `uv run pytest -q`: run the full test suite.

## Coding Style & Naming Conventions

Use Python 3.14 syntax and keep modules responsibility-focused. Follow the
existing style: 4-space indentation, type hints for public interfaces, async
APIs for I/O or LLM calls, and clear model boundaries. Prefer coroutine-based
runtime code. Use `anyio` for async primitives, task groups, sleeps, locks, and
cancellation; keep new code free of direct `asyncio` usage.

New code should be simple, high-performance, extensible, elegant, and reusable.
Prefer existing utilities, types, builders, registries, and helper functions
before introducing new abstractions. Keep implementations concise, avoid
verbose control flow, and use Python 3.14 features when they improve clarity or
type safety.

Name modules with lowercase `snake_case.py`, functions and variables with
`snake_case`, classes with `PascalCase`, and constants with `UPPER_SNAKE_CASE`.
Preserve nearby style and keep imports readable.

## Architecture & Reference Docs

Read `agents-docs/` when implementing skills, subagents, team behavior, or
`any-llm-sdk` integration. Treat those notes as background, then verify against
`src/hajimi` and focused tests before changing runtime contracts.

Keep `src/hajimi/corekit` dependency-light. It may use the standard library,
`anyio`, `loguru`, and other `hajimi.corekit` modules. It must not import
`hajimi.config`, `hajimi.mcp`, `hajimi.skill`, `hajimi.session`,
`hajimi.runtime`, `hajimi.pricing`, or `hajimi.observability`.

## Testing Guidelines

Pytest is the test framework. Add or update focused tests in `tests/` for
behavior changes in `src/hajimi`. Name files `test_<area>.py` and functions
`test_<expected_behavior>`. Prefer deterministic unit tests with fake LLM or
MCP clients. Use `uv run pytest -q` as the minimum validation before merging.

## Commit & Pull Request Guidelines

This repository currently has no local commit history to derive conventions
from. Use concise imperative subjects, for example `Add session token report
tests` or `Fix MCP client cleanup`. Keep each commit scoped to one behavioral
change. Pull requests should describe the change, list validation commands,
link related issues or notes, and include screenshots only when visual review
helps.

## Security & Configuration Tips

Keep secrets in local `.env` files such as `examples/configs/.env` or
`devs/configs/.env`. Exclude provider API keys, local logs, SQLite session
files, and generated trace output from commits. When adding configuration,
update `docs/configuration.md` and provide a safe example in `examples/configs/`.
