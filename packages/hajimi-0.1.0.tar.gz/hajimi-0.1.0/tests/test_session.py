from collections.abc import AsyncIterator
from pathlib import Path
from types import SimpleNamespace
from typing import Any

from any_llm.types.completion import ChatCompletionMessage, ChatCompletionMessageFunctionToolCall, Function, Reasoning
import pytest

from hajimi.config import ContextCacheSettings, ContextSettings
from hajimi.core import Agent
from hajimi.llm import ModelStreamChunk, ModelResult
from hajimi.session import AgentSession, SessionStore


class FakeClient:
    def __init__(self, results: list[ModelResult]) -> None:
        self.results = results
        self.calls: list[list[dict[str, Any]]] = []

    async def complete(self, messages: list[dict[str, Any]], **kwargs: Any) -> ModelResult:
        self.calls.append(messages)
        return self.results.pop(0)


class FakeStreamingClient:
    def __init__(self) -> None:
        self.calls: list[list[dict[str, Any]]] = []

    async def stream_complete(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> AsyncIterator[ModelStreamChunk]:
        self.calls.append(messages)
        yield ModelStreamChunk(text="he", raw={"index": 0})
        yield ModelStreamChunk(text="llo", raw={"index": 1})


def _response(content: str, usage: Any | None = None) -> Any:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content=content, tool_calls=[]),
            ),
        ],
        usage=usage,
    )


def _message_response(message: Any, usage: Any | None = None) -> Any:
    return SimpleNamespace(choices=[SimpleNamespace(message=message)], usage=usage)


@pytest.mark.anyio
async def test_agent_session_persists_run_and_token_usage(tmp_path: Path) -> None:
    usage = SimpleNamespace(prompt_tokens=3, completion_tokens=2, total_tokens=5)
    client = FakeClient([ModelResult(text="answer", raw=_response("answer", usage))])
    agent = Agent(client=client, name="tester", system_prompt="Be brief.")
    store = _store(tmp_path)
    session = await AgentSession.create(agent=agent, store=store, name="unit", model_name="fake")

    result = await session.run("hello")

    messages = await session.visible_messages()
    events = await store.read_events(session.session_id)
    assert result.content == "answer"
    assert [message.role for message in messages] == ["user", "assistant"]
    assert client.calls[0][0] == {"role": "system", "content": "Be brief."}
    assert client.calls[0][1] == {"role": "user", "content": "hello"}
    assert result.token_usage.provider["total_tokens"] == 5
    assert [event.type for event in events] == [
        "session.created",
        "message.appended",
        "message.appended",
        "token.usage",
        "run.completed",
    ]


@pytest.mark.anyio
async def test_agent_session_can_omit_provider_cache_usage(tmp_path: Path) -> None:
    usage = SimpleNamespace(
        prompt_tokens=5,
        completion_tokens=3,
        total_tokens=8,
        cache_read_tokens=2,
        cache_write_tokens=1,
    )
    client = FakeClient([ModelResult(text="answer", raw=_response("answer", usage))])
    agent = Agent(client=client, name="tester")
    store = _store(tmp_path)
    settings = ContextSettings(cache=ContextCacheSettings(record_provider_cache=False))
    session = await AgentSession.create(agent=agent, store=store, context_settings=settings)

    result = await session.run("hello")

    assert result.token_usage.provider == {
        "prompt_tokens": 5,
        "completion_tokens": 3,
        "total_tokens": 8,
    }


@pytest.mark.anyio
async def test_agent_session_replays_reasoning_and_tool_extra_content(tmp_path: Path) -> None:
    def add(a: int, b: int) -> int:
        """Add two integers."""
        return a + b

    tool_call = ChatCompletionMessageFunctionToolCall(
        id="call-1",
        type="function",
        function=Function(name="add", arguments='{"a": 2, "b": 3}'),
        extra_content={"google": {"thought_signature": "sig"}},
    )
    assistant_message = ChatCompletionMessage.model_validate(
        {
            "role": "assistant",
            "content": None,
            "reasoning": Reasoning(content="normalized reasoning"),
            "reasoning_content": "provider reasoning",
            "tool_calls": [tool_call],
        }
    )
    client = FakeClient(
        [
            ModelResult(text="", raw=_message_response(assistant_message)),
            ModelResult(text="5", raw=_response("5")),
            ModelResult(text="again", raw=_response("again")),
        ],
    )
    agent = Agent.from_tools(client=client, tools=[add], name="session-tools")
    store = _store(tmp_path)
    session = await AgentSession.create(agent=agent, store=store)

    await session.run("2+3?")
    await session.run("again")

    replayed = next(message for message in client.calls[2] if message.get("tool_calls"))
    assert replayed["reasoning"] == {"content": "normalized reasoning"}
    assert replayed["reasoning_content"] == "provider reasoning"
    assert replayed["tool_calls"][0]["extra_content"] == {"google": {"thought_signature": "sig"}}


@pytest.mark.anyio
async def test_agent_session_stream_records_once_after_completion(tmp_path: Path) -> None:
    client = FakeStreamingClient()
    agent = Agent(client=client, name="streamer")
    store = _store(tmp_path)
    session = await AgentSession.create(agent=agent, store=store)

    text = "".join([event.text async for event in session.stream("hello")])

    messages = await session.visible_messages()
    events = await store.read_events(session.session_id)
    assert text == "hello"
    assert [message.content for message in messages] == ["hello", "hello"]
    assert [event.type for event in events].count("stream.completed") == 1
    stream_event = next(event for event in events if event.type == "stream.completed")
    assert stream_event.payload["chunks"] == 2
    assert stream_event.payload["content_length"] == 5


@pytest.mark.anyio
async def test_edit_delete_restore_and_rollback_are_replayed_from_markers(tmp_path: Path) -> None:
    client = FakeClient(
        [
            ModelResult(text="one", raw=_response("one")),
            ModelResult(text="two", raw=_response("two")),
        ]
    )
    agent = Agent(client=client, name="editor")
    store = _store(tmp_path)
    session = await AgentSession.create(agent=agent, store=store)
    await session.run("first")
    await session.run("second")
    original = await session.visible_messages()

    edited = await session.edit_message(original[0].id, "first edited")
    await session.delete_message(original[1].id)
    after_delete = await session.visible_messages()
    await session.restore_message(original[1].id)
    after_restore = await session.visible_messages()
    await session.rollback(message_id=edited.id)
    after_rollback = await session.visible_messages()

    assert after_delete[0].content == "first edited"
    assert all(message.id != original[1].id for message in after_delete)
    assert any(message.id == original[1].id for message in after_restore)
    assert [message.id for message in after_rollback] == [edited.id]


@pytest.mark.anyio
async def test_fork_copies_visible_history_until_message(tmp_path: Path) -> None:
    client = FakeClient(
        [
            ModelResult(text="one", raw=_response("one")),
            ModelResult(text="two", raw=_response("two")),
        ]
    )
    agent = Agent(client=client, name="forker")
    store = _store(tmp_path)
    session = await AgentSession.create(agent=agent, store=store)
    await session.run("first")
    await session.run("second")
    messages = await session.visible_messages()

    forked = await session.fork(name="branch", until_message_id=messages[1].id)

    forked_messages = await forked.visible_messages()
    forked_meta = await store.get_session(forked.session_id)
    assert forked_meta.parent_id == session.session_id
    assert [message.content for message in forked_messages] == ["first", "one"]
    assert forked_messages[0].metadata["forked_from_message"] == messages[0].id


@pytest.mark.anyio
async def test_auto_compaction_writes_summary_and_keeps_tail(tmp_path: Path) -> None:
    client = FakeClient(
        [
            ModelResult(text="first answer", raw=_response("first answer")),
            ModelResult(text="second answer", raw=_response("second answer")),
        ]
    )
    agent = Agent(client=client, name="compact")
    store = _store(tmp_path)
    settings = ContextSettings(
        max_context_tokens=8,
        compact_threshold=0.5,
        protected_head_messages=1,
        protected_tail_turns=1,
    )
    session = await AgentSession.create(agent=agent, store=store, context_settings=settings)
    await session.run("first message with many words")

    result = await session.run("second message")

    messages = await session.visible_messages()
    events = await store.read_events(session.session_id)
    assert result.compacted is True
    assert any(message.metadata.get("summary") for message in messages)
    assert any(event.type == "context.compacted" for event in events)
    assert any("Conversation summary" in str(message) for message in client.calls[1])


@pytest.mark.anyio
async def test_repeated_auto_compaction_replaces_previous_summary(tmp_path: Path) -> None:
    client = FakeClient(
        [
            ModelResult(text="first answer", raw=_response("first answer")),
            ModelResult(text="second answer", raw=_response("second answer")),
            ModelResult(text="third answer", raw=_response("third answer")),
        ]
    )
    agent = Agent(client=client, name="compact")
    store = _store(tmp_path)
    settings = ContextSettings(
        max_context_tokens=8,
        compact_threshold=0.5,
        protected_head_messages=1,
        protected_tail_turns=1,
    )
    session = await AgentSession.create(agent=agent, store=store, context_settings=settings)
    await session.run("first message with many words")
    await session.run("second message")

    result = await session.run("third message")

    messages = await session.visible_messages()
    events = await store.read_events(session.session_id)
    summary_events = [event for event in events if event.type == "context.compacted"]
    summary_ids = [str(event.payload["summary"]["id"]) for event in summary_events]
    visible_summary_ids = [message.id for message in messages if message.metadata.get("summary")]
    assert result.compacted is True
    assert len(summary_events) == 2
    assert visible_summary_ids == [summary_ids[-1]]
    assert summary_ids[0] not in summary_events[-1].payload["kept_message_ids"]


@pytest.mark.anyio
async def test_token_report_counts_tools_and_messages(tmp_path: Path) -> None:
    def add(a: int, b: int) -> int:
        """Add two integers."""
        return a + b

    client = FakeClient([ModelResult(text="ok", raw=_response("ok"))])
    agent = Agent.from_tools(client=client, tools=[add], name="tokens")
    store = _store(tmp_path)
    session = await AgentSession.create(agent=agent, store=store)
    await session.run("hello")

    report = await session.token_report()

    assert report.total > 0
    assert report.by_component["tools_schema"] > 0
    assert "tools_schema" in report.component_hashes
    assert any(key.startswith("message.") for key in report.by_component)
    assert not any(key.endswith(".hash") for key in report.by_component)


def _store(tmp_path: Path) -> SessionStore:
    return SessionStore(
        sqlite_path=tmp_path / "sessions.sqlite",
        events_dir=tmp_path / "events",
    )
