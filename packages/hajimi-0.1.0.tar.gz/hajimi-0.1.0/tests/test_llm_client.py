from collections.abc import AsyncIterator
from types import SimpleNamespace
from typing import Any

import pytest
from openai.types.responses import ResponseOutputMessage, ResponseOutputText

from hajimi.config import ModelSettings
from hajimi.llm import AnyLLMClient


@pytest.mark.anyio
async def test_complete_uses_async_direct_api() -> None:
    calls: list[dict[str, Any]] = []

    async def fake_completion(**kwargs: Any) -> Any:
        calls.append(kwargs)
        return SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(content="done"),
                ),
            ],
        )

    client = AnyLLMClient(
        ModelSettings(name="chat", provider="test", model="chat-model", api_key="key"),
        completion_api=fake_completion,
    )

    result = await client.complete([{"role": "user", "content": "hi"}])

    assert result.text == "done"
    assert calls[0]["model"] == "chat-model"
    assert calls[0]["provider"] == "test"
    assert calls[0]["api_key"] == "key"
    assert calls[0]["stream"] is False


@pytest.mark.anyio
async def test_complete_keeps_reasoning_out_of_visible_text() -> None:
    async def fake_completion(**kwargs: Any) -> Any:
        return SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(
                        content="",
                        reasoning_content="reasoning answer",
                        reasoning={"content": "normalized reasoning"},
                    ),
                ),
            ],
        )

    client = AnyLLMClient(
        ModelSettings(name="chat", provider="test", model="chat-model"),
        completion_api=fake_completion,
    )

    result = await client.complete([{"role": "user", "content": "hi"}])

    assert result.text == ""


@pytest.mark.anyio
async def test_stream_complete_yields_text_deltas() -> None:
    async def stream() -> AsyncIterator[Any]:
        yield SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content="he"))])
        yield SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content="llo"))])

    async def fake_completion(**kwargs: Any) -> Any:
        assert kwargs["stream"] is True
        return stream()

    client = AnyLLMClient(
        ModelSettings(name="chat", provider="test", model="chat-model"),
        completion_api=fake_completion,
    )

    chunks = [chunk.text async for chunk in client.stream_complete([{"role": "user", "content": "hi"}])]

    assert chunks == ["he", "llo"]


@pytest.mark.anyio
async def test_embedding_and_responses_wrappers() -> None:
    async def fake_embedding(**kwargs: Any) -> Any:
        assert kwargs["inputs"] == ["a", "b"]
        return SimpleNamespace(data=[SimpleNamespace(embedding=[1.0]), SimpleNamespace(embedding=[2.0])])

    async def fake_responses(**kwargs: Any) -> Any:
        assert kwargs["input_data"] == "ping"
        assert kwargs["stream"] is False
        return SimpleNamespace(output_text="pong")

    client = AnyLLMClient(
        ModelSettings(name="chat", provider="test", model="chat-model"),
        embedding_api=fake_embedding,
        responses_api=fake_responses,
    )

    assert await client.embed_vectors(["a", "b"]) == [[1.0], [2.0]]
    assert (await client.respond("ping")).text == "pong"


@pytest.mark.anyio
async def test_respond_extracts_real_response_content_parts() -> None:
    async def fake_responses(**kwargs: Any) -> Any:
        assert kwargs["stream"] is False
        return SimpleNamespace(
            output=[
                ResponseOutputMessage(
                    id="msg_1",
                    content=[
                        ResponseOutputText(
                            annotations=[],
                            text="hello",
                            type="output_text",
                        )
                    ],
                    role="assistant",
                    status="completed",
                    type="message",
                )
            ]
        )

    client = AnyLLMClient(
        ModelSettings(name="chat", provider="test", model="chat-model"),
        responses_api=fake_responses,
    )

    result = await client.respond("ping")

    assert result.text == "hello"
