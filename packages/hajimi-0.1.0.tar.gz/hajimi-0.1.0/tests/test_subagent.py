import sys
import types
from contextlib import asynccontextmanager
from types import SimpleNamespace
import json
from typing import Any

import anyio
import pytest

from hajimi.config import (
    AgentProfileSettings,
    AgentSettings,
    AgentToolSearchSettings,
    AppConfig,
    LogSettings,
    MCPServerSettings,
    MCPSettings,
    ModelSettings,
    ObservabilitySettings,
    SubAgentSettings,
)
from hajimi.core import build_agent, create_subagent_tool
from hajimi.default_tools import SKILL_TOOL_NAME, SUBAGENT_TOOL_NAME
from hajimi.llm import AnyLLMClient, ModelResult
from hajimi.observability import JsonlSpanExporter, TraceManager
from hajimi.tool import Tool


class FakeClient:
    def __init__(self, name: str, outputs: dict[str, list[str]]) -> None:
        self.name = name
        self.outputs = outputs
        self.calls: list[list[dict[str, Any]]] = []

    async def complete(self, messages: list[dict[str, Any]], **kwargs: Any) -> ModelResult:
        self.calls.append(messages)
        text = self.outputs[self.name].pop(0)
        return ModelResult(text=text, raw=_response(text))


class ScriptedClient:
    def __init__(self, name: str, scripts: dict[str, list[Any]]) -> None:
        self.name = name
        self.scripts = scripts
        self.calls: list[list[dict[str, Any]]] = []

    async def complete(self, messages: list[dict[str, Any]], **kwargs: Any) -> ModelResult:
        self.calls.append(messages)
        script = self.scripts[self.name].pop(0)
        if isinstance(script, str):
            return ModelResult(text=script, raw=_response(script))
        return ModelResult(text="", raw=_response("", script))


def _response(content: str, tool_calls: list[Any] | None = None) -> Any:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content=content, tool_calls=tool_calls or []),
            ),
        ],
    )


def _tool_call(call_id: str, name: str, arguments: dict[str, Any]) -> Any:
    return SimpleNamespace(
        id=call_id,
        type="function",
        function=SimpleNamespace(name=name, arguments=json.dumps(arguments)),
    )


@pytest.mark.anyio
async def test_subagent_tool_runs_child_with_name_model_and_protocol(tmp_path) -> None:
    outputs = {"child": ["child result"]}
    created_clients: list[tuple[str, str]] = []

    def client_factory(model: ModelSettings, tracer: TraceManager) -> AnyLLMClient:
        created_clients.append((model.name, model.model))
        return FakeClient("child", outputs)  # type: ignore[return-value]

    config = _config(tmp_path)
    tracer = TraceManager(exporter=JsonlSpanExporter(tmp_path / "traces.jsonl"))
    tool = create_subagent_tool(config, tracer=tracer, depth=0, client_factory=client_factory)

    assert tool.name == SUBAGENT_TOOL_NAME
    assert tool.description == "Run a focused one-shot child agent for delegated work."
    assert tool.parameters["properties"]["task"]["description"] == "Delegated work to complete."

    result = await tool.invoke(
        {
            "name": "researcher",
            "task": "Summarize the task.",
            "model_name": "child",
            "system_prompt": "Be precise.",
        }
    )

    assert result == {
        "name": "researcher",
        "model_name": "child",
        "depth": 1,
        "content": "child result",
    }
    assert created_clients == [("child", "child-model")]

    records = await _read_records(tmp_path / "traces.jsonl")
    subagent_record = next(record for record in records if record["name"] == "agent.subagent")
    child_run = next(
        record
        for record in records
        if record["name"] == "agent.run" and record["attributes"]["agent.name"] == "researcher"
    )
    assert subagent_record["attributes"]["agent.subagent.name"] == "researcher"
    assert subagent_record["attributes"]["agent.subagent.model_name"] == "child"
    assert [event["name"] for event in subagent_record["events"]] == [
        "agent.subagent.create",
        "agent.subagent.output",
        "agent.subagent.destroy",
    ]
    assert child_run["trace_id"] == subagent_record["trace_id"]
    assert child_run["parent_span_id"] == subagent_record["span_id"]


@pytest.mark.anyio
async def test_subagent_depth_limit_blocks_creation(tmp_path) -> None:
    config = _config(tmp_path, max_depth=1)
    tracer = TraceManager(exporter=JsonlSpanExporter(tmp_path / "traces.jsonl"))
    tool = create_subagent_tool(config, tracer=tracer, depth=1)

    with pytest.raises(RuntimeError, match="exceeds max_depth"):
        await tool.invoke({"name": "too_deep", "task": "do work"})


@pytest.mark.anyio
async def test_build_agent_adds_subagent_tool_until_max_depth(tmp_path) -> None:
    config = _config(tmp_path, max_depth=1)
    tracer = TraceManager(exporter=JsonlSpanExporter(tmp_path / "traces.jsonl"))
    root = await build_agent(
        config,
        client=FakeClient("root", {"root": ["ok"]}),  # type: ignore[arg-type]
        tracer=tracer,
    )
    child = await build_agent(
        config,
        client=FakeClient("child", {"child": ["ok"]}),  # type: ignore[arg-type]
        tracer=tracer,
        depth=1,
    )

    assert SUBAGENT_TOOL_NAME in [tool.name for tool in root.tools]
    assert SUBAGENT_TOOL_NAME not in [tool.name for tool in child.tools]


@pytest.mark.anyio
async def test_multiple_subagents_exchange_context_with_isolated_capabilities(
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _install_fake_mcp(monkeypatch)
    await _write_skill(
        tmp_path,
        "planner_skill",
        "Planner can only produce plans.",
        """
def planning_marker(topic: str) -> str:
    \"\"\"Return a planner marker.\"\"\"
    return f"plan:{topic}"
""",
    )
    await _write_skill(
        tmp_path,
        "math_skill",
        "Math agent must use multiply_numbers.",
        """
def multiply_numbers(a: int, b: int) -> int:
    \"\"\"Multiply two integers.\"\"\"
    return a * b
""",
    )

    scripts = {
        "root": [
            [
                _tool_call(
                    "plan-call",
                    SUBAGENT_TOOL_NAME,
                    {
                        "name": "planner",
                        "profile": "planner",
                        "task": "Create plan for multiplying 6 and 7.",
                    },
                )
            ],
            [
                _tool_call(
                    "math-call",
                    SUBAGENT_TOOL_NAME,
                    {
                        "name": "math_worker",
                        "profile": "math",
                        "task": "Use planner output plan:multiply 6x7 and compute 6*7.",
                    },
                )
            ],
            [
                _tool_call(
                    "review-call",
                    SUBAGENT_TOOL_NAME,
                    {
                        "name": "reviewer",
                        "profile": "reviewer",
                        "task": "Review math output math:42 from math_worker.",
                    },
                )
            ],
            "team-ok planner->math_worker->reviewer final=review:approved:42",
        ],
        "planner": ["plan:multiply 6x7"],
        "math": [
            [_tool_call("activate-math", SKILL_TOOL_NAME, {"skill_name": "math_skill"})],
            [_tool_call("multiply-call", "multiply_numbers", {"a": 6, "b": 7})],
            "math:42",
        ],
        "reviewer": [[_tool_call("review-call", "review_approval", {"answer": "math:42"})], "review:approved:42"],
    }
    clients: dict[str, ScriptedClient] = {}

    def client_factory(model: ModelSettings, tracer: TraceManager) -> AnyLLMClient:
        name_by_model = {
            "root": "root",
            "planner_model": "planner",
            "math_model": "math",
            "reviewer_model": "reviewer",
        }
        name = name_by_model[model.name]
        client = ScriptedClient(name, scripts)
        clients[name] = client
        return client  # type: ignore[return-value]

    config = _team_config(tmp_path)
    tracer = TraceManager(exporter=JsonlSpanExporter(tmp_path / "traces.jsonl"))
    root = await build_agent(
        config,
        client=client_factory(config.model("root"), tracer),  # type: ignore[arg-type]
        tracer=tracer,
        client_factory=client_factory,
    )

    result = await root.agent.run("Coordinate planner, math_worker, and reviewer.")

    assert result.content == "team-ok planner->math_worker->reviewer final=review:approved:42"
    assert "Use planner output plan:multiply 6x7" in str(clients["math"].calls[0])
    assert "Review math output math:42" in str(clients["reviewer"].calls[0])

    planner_tools = await _profile_tools(config, "planner", tracer)
    math_tools = await _profile_tools(config, "math", tracer)
    reviewer_tools = await _profile_tools(config, "reviewer", tracer)
    assert SKILL_TOOL_NAME in [tool.name for tool in planner_tools]
    assert SKILL_TOOL_NAME in [tool.name for tool in math_tools]
    assert "review_approval" in [tool.name for tool in reviewer_tools]
    assert "review_approval" not in [tool.name for tool in math_tools]
    assert "multiply_numbers" not in [tool.name for tool in reviewer_tools]

    records = await _read_records(tmp_path / "traces.jsonl")
    subagents = [record for record in records if record["name"] == "agent.subagent"]
    assert [record["attributes"]["agent.subagent.name"] for record in subagents] == [
        "planner",
        "math_worker",
        "reviewer",
    ]
    assert [record["attributes"]["agent.subagent.profile"] for record in subagents] == [
        "planner",
        "math",
        "reviewer",
    ]
    assert [record["attributes"]["agent.subagent.skills"] for record in subagents] == [
        ["planner_skill"],
        ["math_skill"],
        [],
    ]
    assert [record["attributes"]["agent.subagent.mcp_servers"] for record in subagents] == [
        [],
        [],
        ["review_server"],
    ]
    assert {
        record["attributes"]["tool.name"]
        for record in records
        if record["name"] == "tool.call"
    } == {SUBAGENT_TOOL_NAME, SKILL_TOOL_NAME, "multiply_numbers", "review_approval"}
    root_run = next(
        record
        for record in records
        if record["name"] == "agent.run" and record["attributes"]["agent.name"] == "root"
    )
    assert all(record["trace_id"] == root_run["trace_id"] for record in subagents)


@pytest.mark.anyio
async def test_dynamic_subagent_searches_and_loads_own_tools(tmp_path) -> None:
    await _write_skill(
        tmp_path,
        "math_skill",
        "Math skill provides hidden arithmetic tools.",
        """
def multiply_numbers(a: int, b: int) -> int:
    \"\"\"Multiply two integers exactly.\"\"\"
    return a * b
""",
    )
    scripts = {
        "child": [
            [_tool_call("activate-1", SKILL_TOOL_NAME, {"skill_name": "math_skill"})],
            [_tool_call("multiply-1", "multiply_numbers", {"a": 8, "b": 9})],
            "child-dynamic-ok:72",
        ]
    }
    clients: dict[str, ScriptedClient] = {}

    def client_factory(model: ModelSettings, tracer: TraceManager) -> AnyLLMClient:
        client = ScriptedClient("child", scripts)
        clients["child"] = client
        return client  # type: ignore[return-value]

    config = AppConfig(
        repo_path=tmp_path,
        agent=AgentSettings(
            name="root",
            default_model="child",
            subagents=SubAgentSettings(enabled=True, max_depth=2),
            tool_search=AgentToolSearchSettings(enabled=True, defer_tools=True, max_results=1),
        ),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=True, directory=tmp_path),
        mcp=MCPSettings(enabled=False),
        models={"child": ModelSettings(name="child", provider="test", model="child-model")},
    )
    tracer = TraceManager(exporter=JsonlSpanExporter(tmp_path / "traces.jsonl"))
    tool = create_subagent_tool(config, tracer=tracer, depth=0, client_factory=client_factory)

    result = await tool.invoke(
        {
            "name": "dynamic_math",
            "task": "Find a tool for multiplying 8 and 9, then return the result.",
            "skills": ["math_skill"],
        }
    )

    assert result["content"] == "child-dynamic-ok:72"
    assert SKILL_TOOL_NAME in str(clients["child"].calls[0])
    assert "multiply_numbers" in str(clients["child"].calls[1])
    records = await _read_records(tmp_path / "traces.jsonl")
    assert {
        record["attributes"]["tool.name"]
        for record in records
        if record["name"] == "tool.call"
    } == {SKILL_TOOL_NAME, "multiply_numbers"}


def _config(tmp_path, *, max_depth: int = 2) -> AppConfig:
    return AppConfig(
        repo_path=tmp_path,
        agent=AgentSettings(
            name="root",
            default_model="root",
            system_prompt="Root.",
            subagents=SubAgentSettings(enabled=True, max_depth=max_depth),
        ),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=True, directory=tmp_path),
        mcp=MCPSettings(enabled=False),
        models={
            "root": ModelSettings(name="root", provider="test", model="root-model"),
            "child": ModelSettings(name="child", provider="test", model="child-model"),
        },
    )


def _team_config(tmp_path) -> AppConfig:
    return AppConfig(
        repo_path=tmp_path,
        agent=AgentSettings(
            name="root",
            default_model="root",
            max_tool_rounds=5,
            subagents=SubAgentSettings(enabled=True, max_depth=2),
            profiles={
                "planner": AgentProfileSettings(
                    name="planner",
                    model_name="planner_model",
                    system_prompt="Planner only returns compact plan markers.",
                    skills=["planner_skill"],
                    tool_names=["planning_marker"],
                ),
                "math": AgentProfileSettings(
                    name="math",
                    model_name="math_model",
                    system_prompt="Math worker must use math tools.",
                    skills=["math_skill"],
                    tool_names=["multiply_numbers"],
                ),
                "reviewer": AgentProfileSettings(
                    name="reviewer",
                    model_name="reviewer_model",
                    system_prompt="Reviewer validates math answers.",
                    mcp_servers=["review_server"],
                    tool_names=["review_approval"],
                ),
            },
        ),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=True, directory=tmp_path),
        mcp=MCPSettings(
            enabled=True,
            servers={
                "review_server": MCPServerSettings(
                    name="review_server",
                    command="fake",
                    tool_prefix="",
                )
            },
        ),
        models={
            "root": ModelSettings(name="root", provider="test", model="root-model"),
            "planner_model": ModelSettings(name="planner_model", provider="test", model="planner-model"),
            "math_model": ModelSettings(name="math_model", provider="test", model="math-model"),
            "reviewer_model": ModelSettings(name="reviewer_model", provider="test", model="reviewer-model"),
        },
    )


async def _profile_tools(config: AppConfig, profile_name: str, tracer: TraceManager) -> list[Tool]:
    profile = config.agent.profiles[profile_name]
    client = FakeClient(profile_name, {profile_name: ["ok"]})
    built = await build_agent(
        config,
        client=client,  # type: ignore[arg-type]
        tracer=tracer,
        skills=profile.skills,
        mcp_servers=profile.mcp_servers,
        tool_names=profile.tool_names,
        depth=1,
    )
    return built.tools


async def _write_skill(tmp_path, name: str, instructions: str, tools_code: str) -> None:
    skill_dir = tmp_path / "skills" / name
    await anyio.Path(skill_dir).mkdir(parents=True)
    await anyio.Path(skill_dir / "SKILL.md").write_text(instructions, encoding="utf-8")
    await anyio.Path(skill_dir / "tools.py").write_text(tools_code, encoding="utf-8")


def _install_fake_mcp(monkeypatch: pytest.MonkeyPatch) -> None:
    mcp_module = types.ModuleType("mcp")
    client_module = types.ModuleType("mcp.client")
    stdio_module = types.ModuleType("mcp.client.stdio")
    http_module = types.ModuleType("mcp.client.streamable_http")

    class StdioServerParameters:
        def __init__(self, **kwargs: Any) -> None:
            self.kwargs = kwargs

    class ClientSession:
        def __init__(self, read_stream: Any, write_stream: Any) -> None:
            self.read_stream = read_stream
            self.write_stream = write_stream

        async def __aenter__(self) -> "ClientSession":
            return self

        async def __aexit__(self, *args: Any) -> None:
            return None

        async def initialize(self) -> None:
            return None

        async def list_tools(self) -> Any:
            return SimpleNamespace(
                tools=[
                    SimpleNamespace(
                        name="review_approval",
                        description="Approve a math answer.",
                        inputSchema={
                            "type": "object",
                            "properties": {"answer": {"type": "string"}},
                            "required": ["answer"],
                        },
                    )
                ]
            )

        async def call_tool(self, name: str, arguments: dict[str, Any]) -> Any:
            return SimpleNamespace(
                structuredContent={"approval": f"approved:{arguments['answer'].split(':')[-1]}"},
                content=[],
            )

    @asynccontextmanager
    async def stdio_client(params: Any) -> Any:
        yield object(), object()

    @asynccontextmanager
    async def streamable_http_client(url: str) -> Any:
        yield object(), object(), None

    mcp_module.ClientSession = ClientSession
    mcp_module.StdioServerParameters = StdioServerParameters
    stdio_module.stdio_client = stdio_client
    http_module.streamable_http_client = streamable_http_client

    monkeypatch.setitem(sys.modules, "mcp", mcp_module)
    monkeypatch.setitem(sys.modules, "mcp.client", client_module)
    monkeypatch.setitem(sys.modules, "mcp.client.stdio", stdio_module)
    monkeypatch.setitem(sys.modules, "mcp.client.streamable_http", http_module)


async def _read_records(path) -> list[dict[str, Any]]:
    text = await anyio.Path(path).read_text(encoding="utf-8")
    return [json.loads(line) for line in text.splitlines()]
