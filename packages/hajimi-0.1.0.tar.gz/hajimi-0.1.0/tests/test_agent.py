from types import SimpleNamespace
from collections.abc import AsyncIterator
from typing import Any

from any_llm.types.completion import ChatCompletionMessage, ChatCompletionMessageFunctionToolCall, Function, Reasoning
import pytest

from hajimi.core import AgentStreamEvent, Agent
from hajimi.llm import ModelStreamChunk, ModelResult


class FakeClient:
    def __init__(self, results: list[ModelResult]) -> None:
        self.results = results
        self.calls: list[dict[str, Any]] = []

    async def complete(self, messages: list[dict[str, Any]], **kwargs: Any) -> ModelResult:
        self.calls.append({"messages": messages, "kwargs": kwargs})
        return self.results.pop(0)


class FakeStreamingClient:
    async def stream_complete(
        self,
        messages: list[dict[str, Any]],
        **kwargs: Any,
    ) -> AsyncIterator[ModelStreamChunk]:
        yield ModelStreamChunk(text="he", raw={"index": 0})
        yield ModelStreamChunk(text="llo", raw={"index": 1})


def _response(content: str, tool_calls: list[Any] | None = None) -> Any:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content=content, tool_calls=tool_calls or []),
            ),
        ],
    )


def _message_response(message: Any) -> Any:
    return SimpleNamespace(choices=[SimpleNamespace(message=message)])


@pytest.mark.anyio
async def test_agent_runs_once_with_system_prompt() -> None:
    client = FakeClient([ModelResult(text="answer", raw=_response("answer"))])
    agent = Agent(client=client, system_prompt="Be brief.")

    result = await agent.run("hello")

    assert result.content == "answer"
    assert client.calls[0]["messages"][0] == {"role": "system", "content": "Be brief."}
    assert client.calls[0]["messages"][1] == {"role": "user", "content": "hello"}


@pytest.mark.anyio
async def test_agent_dispatches_tool_call() -> None:
    def add(a: int, b: int) -> int:
        """Add two numbers."""
        return a + b

    tool_call = SimpleNamespace(
        id="call-1",
        type="function",
        function=SimpleNamespace(name="add", arguments='{"a": 2, "b": 3}'),
    )
    client = FakeClient(
        [
            ModelResult(text="", raw=_response("", [tool_call])),
            ModelResult(text="5", raw=_response("5")),
        ],
    )
    agent = Agent.from_tools(client=client, tools=[add])

    result = await agent.run("2+3?")

    assert result.content == "5"
    assert client.calls[0]["kwargs"]["tools"][0]["function"]["name"] == "add"
    assert client.calls[1]["messages"][-1]["content"] == "5"


@pytest.mark.anyio
async def test_agent_converts_malformed_tool_arguments_to_tool_error() -> None:
    def add(a: int, b: int) -> int:
        """Add two numbers."""
        return a + b

    tool_call = SimpleNamespace(
        id="call-bad",
        type="function",
        function=SimpleNamespace(name="add", arguments='{"a": "unterminated}'),
    )
    client = FakeClient(
        [
            ModelResult(text="", raw=_response("", [tool_call])),
            ModelResult(text="recovered", raw=_response("recovered")),
        ],
    )
    agent = Agent.from_tools(client=client, tools=[add])

    result = await agent.run("2+3?")

    assert result.content == "recovered"
    tool_message = next(message for message in client.calls[1]["messages"] if message["role"] == "tool")
    assert tool_message["name"] == "add"
    assert "tool_arguments_parse_error" in tool_message["content"]


@pytest.mark.anyio
async def test_agent_preserves_reasoning_and_tool_extra_content_between_rounds() -> None:
    def add(a: int, b: int) -> int:
        """Add two numbers."""
        return a + b

    tool_call = ChatCompletionMessageFunctionToolCall(
        id="call-1",
        type="function",
        function=Function(name="add", arguments='{"a": 2, "b": 3}'),
        extra_content={"google": {"thought_signature": "sig"}},
    )
    assistant_message = ChatCompletionMessage.model_validate(
        {
            "role": "assistant",
            "content": None,
            "reasoning": Reasoning(content="normalized reasoning"),
            "reasoning_content": "provider reasoning",
            "tool_calls": [tool_call],
        }
    )
    client = FakeClient(
        [
            ModelResult(text="", raw=_message_response(assistant_message)),
            ModelResult(text="5", raw=_response("5")),
        ],
    )
    agent = Agent.from_tools(client=client, tools=[add])

    result = await agent.run("2+3?")

    preserved = next(message for message in client.calls[1]["messages"] if message.get("tool_calls"))
    assert result.content == "5"
    assert preserved["reasoning"] == {"content": "normalized reasoning"}
    assert preserved["reasoning_content"] == "provider reasoning"
    assert preserved["tool_calls"][0]["extra_content"] == {"google": {"thought_signature": "sig"}}


@pytest.mark.anyio
async def test_agent_streams_async_events() -> None:
    agent = Agent(client=FakeStreamingClient())

    events = [event async for event in agent.stream("hello")]

    assert events == [
        AgentStreamEvent(text="he", raw={"index": 0}),
        AgentStreamEvent(text="llo", raw={"index": 1}),
    ]
