from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

import pytest

from hajimi.corekit import (
    Agent,
    BoundToolCall,
    Context,
    ModelResult,
    Stream,
    TextDelta,
    TextEnd,
    TextStart,
    ToolCall,
    ToolRegistry,
    ToolRunner,
    merge,
    stream,
    user_message,
)
from types import SimpleNamespace
from hajimi.corekit.events import StreamEnd, ToolEnd
from hajimi.corekit.messages import Message, ToolCallPart, file_part, system_message, thinking
from hajimi.tool import tool


def test_typed_message_builders_preserve_parts_and_chat_adapter() -> None:
    image = file_part("https://example.com/cat.png")
    msg = user_message("describe", image)
    system = system_message("Be precise.")
    assistant = Message(role="assistant", parts=[thinking("checking"), *user_message("done").parts])

    assert msg.text == "describe"
    assert msg.files[0].media_type == "image/png"
    assert system.to_chat() == {"role": "system", "content": "Be precise."}
    assert assistant.reasoning == "checking"
    assert assistant.to_chat()["content"] == "done"


@pytest.mark.anyio
async def test_stream_aggregates_events_into_message() -> None:
    async def source() -> AsyncIterator[Any]:
        yield TextStart(block_id="b1")
        yield TextDelta(block_id="b1", chunk="he")
        yield TextDelta(block_id="b1", chunk="llo")
        yield TextEnd(block_id="b1")
        yield StreamEnd()

    async with Stream(source()) as stream:
        chunks = [event.chunk async for event in stream if isinstance(event, TextDelta)]

    assert chunks == ["he", "llo"]
    assert stream.text == "hello"
    assert stream.output == "hello"


def test_context_resolves_tool_call_parts() -> None:
    @tool
    def add(a: int) -> int:
        """Add one."""
        return a + 1

    context = Context(
        messages=[
            user_message("run tool"),
            Message(
                role="assistant",
                parts=[ToolCallPart(tool_call_id="tc-1", tool_name="add", tool_args='{"a": 2}')],
            ),
        ],
        tools=ToolRegistry([add]),
    )

    call = context.resolve(context.messages[-1].tool_calls[0])

    assert context.keep_running() is True
    assert call.call == ToolCall(id="tc-1", name="add", arguments_text='{"a": 2}')
    assert call.kwargs == {"a": 2}


@pytest.mark.anyio
async def test_tool_runner_emits_typed_tool_result_message() -> None:
    @tool
    def add(a: int, b: int) -> int:
        """Add numbers."""
        return a + b

    registry = ToolRegistry([add])
    bound = BoundToolCall(
        call=ToolCall(id="tc-1", name="add", arguments_text='{"a": 2, "b": 3}'),
        tool=registry.get("add"),
    )

    async with ToolRunner() as runner:
        runner.schedule(bound)
        events = [event async for event in runner.events()]
        tool_message = runner.get_tool_message()

    assert len(events) == 1
    assert events[0].results[0].result == "5"
    assert tool_message is not None
    assert tool_message.role == "tool"
    assert tool_message.to_chat()["content"] == "5"


class _ScriptedClient:
    def __init__(self, results: list[ModelResult]) -> None:
        self.results = results
        self.calls: list[list[dict[str, Any]]] = []

    async def complete(self, messages: list[dict[str, Any]], **kwargs: Any) -> ModelResult:
        self.calls.append(messages)
        return self.results.pop(0)


def _response(content: str, tool_calls: list[Any] | None = None) -> Any:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content=content, tool_calls=tool_calls or []),
            )
        ]
    )


@pytest.mark.anyio
async def test_agent_stream_events_runs_tools_and_continues_loop() -> None:
    @tool
    def add(a: int, b: int) -> int:
        """Add numbers."""
        return a + b

    tool_call = SimpleNamespace(
        id="tc-1",
        type="function",
        function=SimpleNamespace(name="add", arguments='{"a": 2, "b": 3}'),
    )
    client = _ScriptedClient(
        [
            ModelResult(text="", raw=_response("", [tool_call])),
            ModelResult(text="5", raw=_response("5")),
        ]
    )
    agent = Agent.from_tools(client=client, tools=[add])

    async with agent.run_stream([user_message("2+3?")]) as run:
        events = [event async for event in run]

    assert any(event.kind == "tool_call_result" for event in events)
    assert [event.chunk for event in events if isinstance(event, TextDelta)] == ["5"]
    assert run.output == "5"
    assert run.messages[-1].text == "5"
    assert client.calls[1][-1]["role"] == "tool"
    assert client.calls[1][-1]["content"] == "5"


@pytest.mark.anyio
async def test_custom_agent_loop_can_manage_context_stream_and_tool_runner() -> None:
    @tool
    def add(a: int, b: int) -> int:
        """Add numbers."""
        return a + b

    class CustomAgent(Agent):
        async def loop(self, context: Context) -> AsyncIterator[Any]:
            while context.keep_running():
                async with (
                    stream(context=context) as model_stream,
                    ToolRunner() as runner,
                ):
                    async for event in merge(model_stream, runner.events()):
                        yield event
                        if isinstance(event, ToolEnd):
                            runner.schedule(context.resolve(event.tool_call))

                    context.add(model_stream.message)
                    context.add(runner.get_tool_message())

    tool_call = SimpleNamespace(
        id="tc-1",
        type="function",
        function=SimpleNamespace(name="add", arguments='{"a": 8, "b": 13}'),
    )
    client = _ScriptedClient(
        [
            ModelResult(text="", raw=_response("", [tool_call])),
            ModelResult(text="21", raw=_response("21")),
        ]
    )
    agent = CustomAgent.from_tools(client=client, tools=[add])

    async with agent.run_stream([user_message("8+13?")]) as run:
        events = [event async for event in run]

    assert any(isinstance(event, ToolEnd) for event in events)
    assert any(event.kind == "tool_call_result" for event in events)
    assert run.output == "21"
    assert client.calls[1][-1]["role"] == "tool"
    assert client.calls[1][-1]["content"] == "21"
