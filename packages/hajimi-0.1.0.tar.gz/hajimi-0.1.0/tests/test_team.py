from types import SimpleNamespace
from typing import Any

import pytest

from hajimi.config import (
    AgentProfileSettings,
    AgentSettings,
    AppConfig,
    LogSettings,
    MCPSettings,
    ModelSettings,
    ObservabilitySettings,
    TeammateSettings,
)
from hajimi.core import build_agent
from hajimi.default_tools import TEAM_CLOSE_TOOL_NAME, TEAM_SEND_TOOL_NAME, TEAM_SPAWN_TOOL_NAME
from hajimi.llm import AnyLLMClient, ModelResult
from hajimi.observability import JsonlSpanExporter, TraceManager


class ScriptedClient:
    def __init__(self, name: str, scripts: dict[str, list[Any]]) -> None:
        self.name = name
        self.scripts = scripts
        self.calls: list[list[dict[str, Any]]] = []

    async def complete(self, messages: list[dict[str, Any]], **kwargs: Any) -> ModelResult:
        self.calls.append(messages)
        script = self.scripts[self.name].pop(0)
        if isinstance(script, str):
            return ModelResult(text=script, raw=_response(script))
        return ModelResult(text="", raw=_response("", script))


@pytest.mark.anyio
async def test_teammates_are_persistent_and_can_message_each_other(tmp_path) -> None:
    scripts = {
        "lead": [
            [_tool_call("spawn-a", TEAM_SPAWN_TOOL_NAME, {"name": "architect", "profile": "architect", "prompt": "Start architecture review."})],
            [_tool_call("spawn-r", TEAM_SPAWN_TOOL_NAME, {"name": "reviewer", "profile": "reviewer", "prompt": "Wait for architect."})],
            [_tool_call("send-a", TEAM_SEND_TOOL_NAME, {"name": "architect", "message": "Ask reviewer for a risk check."})],
            [_tool_call("close-a", TEAM_CLOSE_TOOL_NAME, {"name": "architect"})],
            "team-complete",
        ],
        "architect": [
            "architect-ready",
            [_tool_call("ask-reviewer", TEAM_SEND_TOOL_NAME, {"name": "reviewer", "message": "Please check API risk."})],
            "architect-used-reviewer",
        ],
        "reviewer": [
            "reviewer-ready",
            "reviewer-risk-low",
        ],
    }
    clients: dict[str, ScriptedClient] = {}

    def client_factory(model: ModelSettings, tracer: TraceManager) -> AnyLLMClient:
        name_by_model = {
            "lead": "lead",
            "architect_model": "architect",
            "reviewer_model": "reviewer",
        }
        name = name_by_model[model.name]
        client = ScriptedClient(name, scripts)
        clients[name] = client
        return client  # type: ignore[return-value]

    config = AppConfig(
        repo_path=tmp_path,
        agent=AgentSettings(
            name="lead",
            default_model="lead",
            max_tool_rounds=6,
            teammates=TeammateSettings(enabled=True, max_members=3),
            profiles={
                "architect": AgentProfileSettings(name="architect", model_name="architect_model"),
                "reviewer": AgentProfileSettings(name="reviewer", model_name="reviewer_model"),
            },
        ),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=True, directory=tmp_path),
        mcp=MCPSettings(enabled=False),
        models={
            "lead": ModelSettings(name="lead", provider="test", model="lead-model"),
            "architect_model": ModelSettings(name="architect_model", provider="test", model="architect-model"),
            "reviewer_model": ModelSettings(name="reviewer_model", provider="test", model="reviewer-model"),
        },
    )
    tracer = TraceManager(exporter=JsonlSpanExporter(tmp_path / "traces.jsonl"))
    built = await build_agent(
        config,
        client=client_factory(config.model("lead"), tracer),  # type: ignore[arg-type]
        tracer=tracer,
        client_factory=client_factory,
    )

    result = await built.agent.run("Create a teammate team and coordinate them.")

    assert result.content == "team-complete"
    assert "Ask reviewer for a risk check." in str(clients["architect"].calls[-1])
    assert "Please check API risk." in str(clients["reviewer"].calls[-1])
    assert "Start architecture review." in str(clients["architect"].calls[0])
    assert "Wait for architect." in str(clients["reviewer"].calls[0])


def _response(content: str, tool_calls: list[Any] | None = None) -> Any:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content=content, tool_calls=tool_calls or []),
            )
        ]
    )


def _tool_call(call_id: str, name: str, arguments: dict[str, Any]) -> Any:
    import json

    return SimpleNamespace(
        id=call_id,
        type="function",
        function=SimpleNamespace(name=name, arguments=json.dumps(arguments)),
    )
