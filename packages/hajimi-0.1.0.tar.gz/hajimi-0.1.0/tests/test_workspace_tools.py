from pathlib import Path

import anyio
import pytest

from hajimi.config import (
    AgentSettings,
    AgentWorkspaceToolsSettings,
    AppConfig,
    LogSettings,
    MCPSettings,
    ModelSettings,
    ObservabilitySettings,
)
from hajimi.core import build_agent
from hajimi.llm import ModelResult
from hajimi.observability import NoOpTraceManager
from hajimi.sandbox import (
    SandboxDirectoryEntry,
    SandboxExecResult,
    SandboxPathStat,
)
from hajimi.tool.workspace import create_workspace_tools


@pytest.mark.anyio
async def test_workspace_tools_read_grep_and_glob_under_root(tmp_path: Path) -> None:
    await anyio.Path(tmp_path / "notes").mkdir()
    await anyio.Path(tmp_path / "notes" / "todo.txt").write_text("alpha\nbeta\n", encoding="utf-8")
    tools = {
        tool.name: tool
        for tool in create_workspace_tools(
            tmp_path,
            AgentWorkspaceToolsSettings(sandbox_provider="local"),
        )
    }

    read = await tools["read"].invoke({"path": "notes/todo.txt", "limit": 5})
    listing = await tools["read"].invoke({"path": "notes"})
    grep = await tools["grep"].invoke({"pattern": "bet", "path": "notes"})
    glob = await tools["glob"].invoke({"pattern": "notes/*.txt"})

    assert read["content"] == "alpha"
    assert read["truncated"] is True
    assert listing == {
        "path": "notes",
        "entries": [{"path": "todo.txt", "type": "file"}],
        "truncated": False,
    }
    assert grep["matches"] == [{"path": "notes/todo.txt", "line": 2, "text": "beta"}]
    assert glob["matches"] == ["notes/todo.txt"]


@pytest.mark.anyio
async def test_workspace_tools_reject_path_escape_and_skip_external_symlinks(tmp_path: Path) -> None:
    outside = tmp_path.parent / "outside.txt"
    await anyio.Path(outside).write_text("secret-token\n", encoding="utf-8")
    await anyio.Path(tmp_path / "link.txt").symlink_to(outside)
    tools = {
        tool.name: tool
        for tool in create_workspace_tools(
            tmp_path,
            AgentWorkspaceToolsSettings(sandbox_provider="local"),
        )
    }

    with pytest.raises(ValueError, match="escapes sandbox root"):
        await tools["read"].invoke({"path": "../outside.txt"})

    grep = await tools["grep"].invoke({"pattern": "secret-token"})
    glob = await tools["glob"].invoke({"pattern": "*.txt"})

    assert grep["matches"] == []
    assert glob["matches"] == []


@pytest.mark.anyio
async def test_workspace_write_edit_and_bash_require_explicit_enablement(tmp_path: Path) -> None:
    read_only = {
        tool.name
        for tool in create_workspace_tools(
            tmp_path,
            AgentWorkspaceToolsSettings(sandbox_provider="local"),
        )
    }
    assert read_only == {"read", "grep", "glob"}

    settings = AgentWorkspaceToolsSettings(
        sandbox_provider="local",
        allow_write=True,
        allow_shell=True,
        allowed_shell_commands=["python"],
    )
    tools = {tool.name: tool for tool in create_workspace_tools(tmp_path, settings)}
    await tools["write"].invoke({"path": "data.txt", "content": "hello"})
    edit = await tools["edit"].invoke({"path": "data.txt", "old": "hello", "new": "world"})
    bash = await tools["bash"].invoke({"command": "python --version", "timeout_seconds": 5})
    timeout = await tools["bash"].invoke({
        "command": "python -c 'import time; time.sleep(2)'",
        "timeout_seconds": 0.1,
    })

    assert edit["replacements"] == 1
    assert (tmp_path / "data.txt").read_text(encoding="utf-8") == "world"
    assert bash["exit_code"] == 0
    assert "Python" in bash["stdout"] or "Python" in bash["stderr"]
    assert timeout["timed_out"] is True
    assert timeout["exit_code"] is None

    with pytest.raises(PermissionError, match="not allow-listed"):
        await tools["bash"].invoke({"command": "git status"})


@pytest.mark.anyio
async def test_build_agent_exposes_workspace_tools_and_respects_allow_list(tmp_path: Path) -> None:
    config = AppConfig(
        repo_path=tmp_path,
        agent=AgentSettings(
            default_model="chat",
            workspace_tools=AgentWorkspaceToolsSettings(
                sandbox_provider="local",
                allow_write=True,
                allow_shell=True,
            ),
        ),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=False),
        mcp=MCPSettings(enabled=False),
        models={"chat": ModelSettings(name="chat", provider="test", model="chat-model")},
    )
    built = await build_agent(
        config,
        client=FakeClient(),  # type: ignore[arg-type]
        tracer=NoOpTraceManager(),
        tool_names=["read", "write"],
    )

    tool_names = [tool["function"]["name"] for tool in built.agent.tools.schemas()]
    assert tool_names == ["read", "write"]


@pytest.mark.anyio
async def test_workspace_tools_can_use_custom_sandbox_environment(tmp_path: Path) -> None:
    tools = {
        tool.name: tool
        for tool in create_workspace_tools(
            tmp_path,
            AgentWorkspaceToolsSettings(
                sandbox_provider="local",
                allow_write=True,
                allow_shell=True,
                allowed_shell_commands=["python"],
            ),
            environment=FakeSandboxEnvironment(),
        )
    }

    read = await tools["read"].invoke({"path": "notes/todo.txt"})
    listing = await tools["read"].invoke({"path": "notes"})
    grep = await tools["grep"].invoke({"pattern": "bet"})
    glob = await tools["glob"].invoke({"pattern": "notes/*.txt"})
    bash = await tools["bash"].invoke({"command": "python --version"})

    assert read["content"] == "alpha\nbeta\n"
    assert listing["entries"] == [{"path": "todo.txt", "type": "file"}]
    assert grep["matches"] == [{"path": "notes/todo.txt", "line": 2, "text": "beta"}]
    assert glob["matches"] == ["notes/todo.txt"]
    assert bash["stdout"] == "Python 3.14\n"

    with pytest.raises(PermissionError, match="not allow-listed"):
        await tools["bash"].invoke({"command": "git status"})


def test_workspace_tools_fail_fast_for_unknown_sandbox_provider(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="Unknown workspace sandbox provider"):
        create_workspace_tools(
            tmp_path,
            AgentWorkspaceToolsSettings(sandbox_provider="missing"),
        )


def test_workspace_tools_default_to_e2b_provider(tmp_path: Path) -> None:
    tools = create_workspace_tools(tmp_path, AgentWorkspaceToolsSettings())

    assert [tool.name for tool in tools] == ["read", "grep", "glob"]


class FakeClient:
    async def complete(self, messages: list[dict[str, object]], **kwargs: object) -> ModelResult:
        del messages, kwargs
        raise AssertionError("not used")


class FakeSandboxEnvironment:
    async def stat(self, path: str) -> SandboxPathStat:
        if path == "notes":
            return SandboxPathStat(path="notes", type="directory")
        return SandboxPathStat(path=path, type="file")

    async def read_text(self, path: str) -> str:
        assert path == "notes/todo.txt"
        return "alpha\nbeta\n"

    async def write_text(self, path: str, content: str) -> None:
        del path, content

    async def read_bytes(self, path: str) -> bytes:
        del path
        return b""

    async def write_bytes(self, path: str, content: bytes) -> None:
        del path, content

    async def list_dir(self, path: str) -> list[SandboxDirectoryEntry]:
        assert path == "notes"
        return [SandboxDirectoryEntry(path="todo.txt", type="file")]

    async def iter_files(self, path: str) -> list[str]:
        assert path == "."
        return ["notes/todo.txt"]

    async def exec(
        self,
        command: str,
        timeout_seconds: float,
        cwd: str | None = None,
    ) -> SandboxExecResult:
        del command, timeout_seconds, cwd
        return SandboxExecResult(exit_code=0, stdout="Python 3.14\n", stderr="")
