"""Tests for the runtime optimization pass (P0-P4)."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

from hajimi import Hajimi
from hajimi.budget import BudgetExceeded
from hajimi.config import (
    AgentProfileSettings,
    AgentRoutingSettings,
    AgentSettings,
    AppConfig,
    ContextCacheSettings,
    ContextSettings,
    LogSettings,
    MCPSettings,
    ModelPricing,
    ModelSettings,
    ObservabilitySettings,
    SubAgentSettings,
    TeammateSettings,
    load_config,
)
from hajimi.config.providers import detect_provider_models, select_default_model
from hajimi.pricing import PricingCatalog
from hajimi.llm import ModelResult
from hajimi.observability import NoOpTraceManager, TraceManager
from hajimi.runtime import AgentRuntime, RunOptions, RuntimeStreamEvent
from hajimi.session import ContextManager, SessionStore
from hajimi.session.tokens import TokenEstimator


# ---------- helpers ----------


class ScriptedClient:
    """Minimal scripted client matching Agent's expected interface."""

    def __init__(self, name: str, scripts: dict[str, list[Any]]) -> None:
        self.name = name
        self.scripts = scripts
        self.settings = SimpleNamespace(model=name, name=name, provider="test")
        self.calls: list[list[dict[str, Any]]] = []
        self.kwargs: list[dict[str, Any]] = []

    async def complete(self, messages: list[dict[str, Any]], **kwargs: Any) -> ModelResult:
        self.calls.append([dict(message) for message in messages])
        self.kwargs.append(kwargs)
        script_entry = self.scripts[self.name].pop(0)
        if isinstance(script_entry, tuple):
            text, usage = script_entry
        else:
            text, usage = script_entry, SimpleNamespace(
                prompt_tokens=3, completion_tokens=2, total_tokens=5
            )
        return ModelResult(text=text, raw=_response(text, usage))

    async def stream_complete(self, messages: list[dict[str, Any]], **kwargs: Any):
        self.calls.append([dict(message) for message in messages])
        self.kwargs.append(kwargs)
        text = self.scripts[self.name].pop(0)
        for piece in text.split("|"):
            yield SimpleNamespace(text=piece, raw={"piece": piece})


def _response(content: str, usage: Any) -> Any:
    return SimpleNamespace(
        choices=[SimpleNamespace(message=SimpleNamespace(content=content, tool_calls=[]))],
        usage=usage,
    )


def _config(
    tmp_path: Path,
    *,
    routing: AgentRoutingSettings | None = None,
    profiles: dict[str, AgentProfileSettings] | None = None,
    models: dict[str, ModelSettings] | None = None,
    context: ContextSettings | None = None,
) -> AppConfig:
    return AppConfig(
        repo_path=tmp_path,
        agent=AgentSettings(
            name="root",
            default_model="root",
            routing=routing or AgentRoutingSettings(default_profiles=[]),
            subagents=SubAgentSettings(),
            teammates=TeammateSettings(),
            profiles=profiles or {},
        ),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=False),
        context=context
        or ContextSettings(
            enabled=False,
            store_dir=tmp_path / "sessions",
            events_dir=tmp_path / "events",
        ),
        mcp=MCPSettings(enabled=False),
        models=models
        or {"root": ModelSettings(name="root", provider="test", model="root")},
    )


def _factory(scripts: dict[str, list[Any]]):
    def create(model: ModelSettings, tracer: TraceManager):
        return ScriptedClient(model.name, scripts)  # type: ignore[return-value]

    return create


def _store(tmp_path: Path) -> SessionStore:
    return SessionStore(
        sqlite_path=tmp_path / "sessions.sqlite",
        events_dir=tmp_path / "events",
    )


# ---------- P0: env-driven defaults ----------


def test_detect_provider_models_synthesizes_models_for_present_keys() -> None:
    env = {"OPENAI_API_KEY": "sk-openai", "DEEPSEEK_API_KEY": "sk-deepseek"}
    models = detect_provider_models(env)
    assert set(models) == {"openai", "deepseek"}
    assert models["openai"].api_key == "sk-openai"
    assert models["deepseek"].api_key == "sk-deepseek"
    # Inline pricing is removed; catalog is used at runtime.
    assert models["openai"].pricing is None


def test_pricing_catalog_finds_known_models() -> None:
    catalog = PricingCatalog.from_bundled()
    pricing = catalog.pricing_for("gpt-5.4-mini")
    assert pricing is not None
    assert pricing.input_per_1m > 0.0
    # Tail lookup: no provider prefix needed.
    assert catalog.pricing_for("deepseek-chat") is not None
    assert catalog.pricing_for("nonexistent-model-xyz") is None


def test_detect_provider_models_respects_model_override() -> None:
    env = {
        "OPENAI_API_KEY": "sk-openai",
        "HAJIMI_DEFAULT_MODEL__OPENAI": "gpt-5-pro",
    }
    models = detect_provider_models(env)
    assert models["openai"].model == "gpt-5-pro"


def test_select_default_model_prefers_explicit_then_priority_order() -> None:
    env = {"OPENAI_API_KEY": "x", "DEEPSEEK_API_KEY": "x"}
    models = detect_provider_models(env)
    # Without HAJIMI_DEFAULT_MODEL, openai (priority) wins.
    assert select_default_model(env, models) == "openai"
    # Explicit override.
    env_with_default = {**env, "HAJIMI_DEFAULT_MODEL": "deepseek"}
    assert select_default_model(env_with_default, models) == "deepseek"


def test_provider_defaults_use_provider_native_model_ids() -> None:
    env = {
        "MISTRAL_API_KEY": "x",
        "GROQ_API_KEY": "x",
        "XAI_API_KEY": "x",
        "DASHSCOPE_API_KEY": "x",
    }
    models = detect_provider_models(env)
    assert models["mistral"].model == "mistral-medium-latest"
    assert models["groq"].model == "llama-3.3-70b-versatile"
    assert models["xai"].model == "grok-4-fast-reasoning"
    assert models["dashscope"].model == "qwen-flash"
    assert all("/" not in model.model for model in models.values())


@pytest.mark.anyio
async def test_load_config_without_toml_synthesizes_from_env(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    for key in (
        "OPENAI_API_KEY",
        "DEEPSEEK_API_KEY",
        "ANTHROPIC_API_KEY",
        "GEMINI_API_KEY",
        "MISTRAL_API_KEY",
        "GROQ_API_KEY",
        "XAI_API_KEY",
        "DASHSCOPE_API_KEY",
        "HAJIMI_DEFAULT_MODEL",
    ):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    monkeypatch.chdir(tmp_path)

    config = await load_config(None, repo_path=tmp_path)

    assert "openai" in config.models
    assert config.models["openai"].api_key == "sk-test"
    assert config.agent.default_model == "openai"


# ---------- P3: auto routing fix ----------


@pytest.mark.anyio
async def test_auto_route_with_profiles_defined_but_unused_still_uses_single(
    tmp_path: Path,
) -> None:
    # Profiles are defined but neither RunOptions.profiles nor
    # routing.default_profiles request fanout. Expect single mode.
    profiles = {
        "planner": AgentProfileSettings(name="planner", model_name="root"),
    }
    config = _config(
        tmp_path,
        routing=AgentRoutingSettings(default_profiles=[], simple_max_words=1),
        profiles=profiles,
    )
    runtime = AgentRuntime(
        config=config,
        tracer=NoOpTraceManager(),
        store=None,
        client_factory=_factory({"root": ["only-answer"]}),
    )

    result = await runtime.run_task("a complex task that is not simple", options=RunOptions(use_session=False))

    assert result.plan.mode == "single"
    assert result.plan.reason == "auto_complex_single"
    assert result.content == "only-answer"


# ---------- P1: BudgetMeter ----------


@pytest.mark.anyio
async def test_budget_meter_raises_when_total_tokens_exceed_cap(tmp_path: Path) -> None:
    config = _config(tmp_path)
    runtime = AgentRuntime(
        config=config,
        tracer=NoOpTraceManager(),
        store=None,
        client_factory=_factory({"root": [("answer", SimpleNamespace(prompt_tokens=100, completion_tokens=100, total_tokens=200))]}),
    )

    with pytest.raises(BudgetExceeded):
        await runtime.run_task(
            "hello",
            options=RunOptions(
                mode="single",
                use_session=False,
                max_total_tokens=10,
                on_budget_exceeded="raise",
            ),
        )


@pytest.mark.anyio
async def test_budget_meter_stop_policy_returns_partial_result(tmp_path: Path) -> None:
    config = _config(tmp_path)
    runtime = AgentRuntime(
        config=config,
        tracer=NoOpTraceManager(),
        store=None,
        client_factory=_factory({"root": [("partial", SimpleNamespace(prompt_tokens=50, completion_tokens=50, total_tokens=100))]}),
    )

    result = await runtime.run_task(
        "hello",
        options=RunOptions(
            mode="single",
            use_session=False,
            max_total_tokens=5,
            on_budget_exceeded="stop",
        ),
    )

    assert result.content == "partial"
    assert result.cost is not None
    assert result.cost.aborted is True
    assert "total_tokens" in (result.cost.aborted_reason or "")


@pytest.mark.anyio
async def test_runtime_result_reports_cost_when_pricing_known(tmp_path: Path) -> None:
    # Per-M units: $1/M input, $2/M output.
    pricing = ModelPricing(input_per_1m=1.0, output_per_1m=2.0)
    config = _config(
        tmp_path,
        models={
            "root": ModelSettings(
                name="root", provider="test", model="root", pricing=pricing
            )
        },
    )
    runtime = AgentRuntime(
        config=config,
        tracer=NoOpTraceManager(),
        store=None,
        client_factory=_factory(
            {"root": [("answer", SimpleNamespace(prompt_tokens=1_000_000, completion_tokens=500_000, total_tokens=1_500_000))]}
        ),
    )

    result = await runtime.run_task("hello", options=RunOptions(use_session=False))

    assert result.cost is not None
    # 1M/1M * 1.0 + 500K/1M * 2.0 = 1.0 + 1.0 = 2.0
    assert result.cost.cost_usd == pytest.approx(2.0)
    assert result.cost.input_tokens == 1_000_000
    assert result.cost.output_tokens == 500_000


# ---------- P2: inflight context compaction ----------


@pytest.mark.anyio
async def test_context_manager_compact_messages_is_noop_below_threshold() -> None:
    settings = ContextSettings(
        enabled=True,
        store_dir=Path("/tmp/sessions"),
        events_dir=Path("/tmp/events"),
        max_context_tokens=10_000,
        compact_threshold=0.9,
        protected_head_messages=1,
        protected_tail_turns=1,
        cache=ContextCacheSettings(),
    )
    manager = ContextManager(settings=settings, estimator=TokenEstimator())

    messages = [
        {"role": "system", "content": "be brief"},
        {"role": "user", "content": "hello"},
        {"role": "assistant", "content": "hi"},
    ]
    compacted = await manager.compact_messages(messages)
    assert compacted == messages


@pytest.mark.anyio
async def test_context_manager_compact_messages_collapses_middle_above_threshold() -> None:
    settings = ContextSettings(
        enabled=True,
        store_dir=Path("/tmp/sessions"),
        events_dir=Path("/tmp/events"),
        max_context_tokens=10,
        compact_threshold=0.1,
        protected_head_messages=1,
        protected_tail_turns=1,
        cache=ContextCacheSettings(),
    )
    manager = ContextManager(settings=settings, estimator=TokenEstimator())

    head = {"role": "system", "content": "head"}
    middle_a = {"role": "user", "content": "middle a"}
    middle_b = {"role": "assistant", "content": "middle b"}
    tail_user = {"role": "user", "content": "tail"}
    tail_assistant = {"role": "assistant", "content": "tail reply"}
    messages = [head, middle_a, middle_b, tail_user, tail_assistant]

    compacted = await manager.compact_messages(messages)
    assert compacted[0] == head
    assert compacted[1]["role"] == "system"
    assert "summary" in compacted[1]["content"].lower()
    assert compacted[-2:] == [tail_user, tail_assistant]


@pytest.mark.anyio
async def test_context_manager_compact_messages_preserves_tool_call_pairs() -> None:
    settings = ContextSettings(
        enabled=True,
        store_dir=Path("/tmp/sessions"),
        events_dir=Path("/tmp/events"),
        max_context_tokens=10,
        compact_threshold=0.1,
        protected_head_messages=1,
        protected_tail_turns=1,
        cache=ContextCacheSettings(),
    )
    manager = ContextManager(settings=settings, estimator=TokenEstimator())
    tool_call = {
        "id": "call-1",
        "type": "function",
        "function": {"name": "lookup", "arguments": "{}"},
    }
    assistant = {"role": "assistant", "content": "", "tool_calls": [tool_call]}
    tool_result = {"role": "tool", "tool_call_id": "call-1", "name": "lookup", "content": "result"}
    messages = [
        {"role": "system", "content": "head"},
        {"role": "user", "content": "old middle message"},
        {"role": "assistant", "content": "old middle answer"},
        assistant,
        tool_result,
        {"role": "assistant", "content": "final"},
    ]

    compacted = await manager.compact_messages(messages)

    assert assistant in compacted
    assert tool_result in compacted
    assert compacted.index(assistant) + 1 == compacted.index(tool_result)
    assert any(message.get("role") == "system" and "summary" in message.get("content", "").lower() for message in compacted)


# ---------- P4: stream_task ----------


@pytest.mark.anyio
async def test_runtime_stream_task_emits_route_token_and_final(tmp_path: Path) -> None:
    config = _config(tmp_path)
    runtime = AgentRuntime(
        config=config,
        tracer=NoOpTraceManager(),
        store=None,
        client_factory=_factory({"root": ["he|llo"]}),
    )

    events: list[RuntimeStreamEvent] = []
    async for event in runtime.stream_task("hi", options=RunOptions(use_session=False)):
        events.append(event)

    assert events[0].kind == "route"
    assert events[0].plan is not None and events[0].plan.mode == "single"
    token_events = [event for event in events if event.kind == "token"]
    assert [event.text for event in token_events] == ["he", "llo"]
    assert events[-1].kind == "final"
    assert events[-1].content == "hello"


@pytest.mark.anyio
async def test_runtime_stream_task_persists_session_by_default(tmp_path: Path) -> None:
    config = _config(
        tmp_path,
        context=ContextSettings(
            enabled=True,
            store_dir=tmp_path / "sessions",
            events_dir=tmp_path / "events",
        ),
    )
    runtime = AgentRuntime(
        config=config,
        tracer=NoOpTraceManager(),
        store=_store(tmp_path),
        client_factory=_factory({"root": ["he|llo"]}),
    )

    events = [event async for event in runtime.stream_task("hi", options=RunOptions(session_name="streamed"))]

    assert events[-1].kind == "final"
    event_files = list((tmp_path / "events").glob("*.jsonl"))
    assert len(event_files) == 1
    session_id = event_files[0].stem
    session = await runtime.store.get_session(session_id)  # type: ignore[union-attr]
    assert session.name == "streamed"
    stored_events = await runtime.store.read_events(session_id)  # type: ignore[union-attr]
    assert [event.type for event in stored_events] == [
        "session.created",
        "message.appended",
        "message.appended",
        "token.usage",
        "stream.completed",
    ]


@pytest.mark.anyio
async def test_runtime_stream_task_requests_usage_and_estimates_budget_when_omitted(tmp_path: Path) -> None:
    pricing = ModelPricing(input_per_1m=1.0, output_per_1m=2.0)
    config = _config(
        tmp_path,
        models={"root": ModelSettings(name="root", provider="test", model="root", pricing=pricing)},
    )
    clients: dict[str, ScriptedClient] = {}

    def create(model: ModelSettings, tracer: TraceManager):
        client = ScriptedClient(model.name, {"root": ["he|llo"]})
        clients[model.name] = client
        return client  # type: ignore[return-value]

    runtime = AgentRuntime(
        config=config,
        tracer=NoOpTraceManager(),
        store=None,
        client_factory=create,
    )

    events = [
        event
        async for event in runtime.stream_task(
            "hi",
            options=RunOptions(use_session=False, max_total_tokens=100),
        )
    ]

    assert clients["root"].kwargs[0]["stream_options"] == {"include_usage": True}
    assert events[-1].cost is not None
    assert events[-1].cost.total_tokens > 0
    assert events[-1].cost.cost_usd > 0


# ---------- Hajimi singleton ----------


@pytest.mark.anyio
async def test_hajimi_default_lazily_builds_runtime_from_env(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    for key in (
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "DEEPSEEK_API_KEY",
        "GEMINI_API_KEY",
        "MISTRAL_API_KEY",
        "GROQ_API_KEY",
        "XAI_API_KEY",
        "DASHSCOPE_API_KEY",
        "HAJIMI_DEFAULT_MODEL",
    ):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    monkeypatch.chdir(tmp_path)
    Hajimi.reset()
    try:
        runtime = await Hajimi.default()
        # Same instance returned on the second call.
        assert await Hajimi.default() is runtime
        assert runtime.config.agent.default_model == "openai"
    finally:
        Hajimi.reset()
