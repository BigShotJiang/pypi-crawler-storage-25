import sys
import types
from contextlib import asynccontextmanager
from types import SimpleNamespace
from typing import Any

import pytest

from hajimi.config import (
    AgentSettings,
    AgentToolSearchSettings,
    AppConfig,
    LogSettings,
    MCPServerSettings,
    MCPSettings,
    ModelSettings,
    ObservabilitySettings,
)
from hajimi.core import build_agent
from hajimi.default_tools import TOOL_SEARCH_NAME
from hajimi.llm import ModelResult
from hajimi.observability import NoOpTraceManager
from hajimi.tool import ToolCatalog, ToolRegistry, create_tool_search_tool


@pytest.mark.anyio
async def test_tool_search_ranks_and_loads_matching_tools() -> None:
    def multiply_numbers(a: int, b: int) -> int:
        """Multiply two integers."""
        return a * b

    def send_email(to: str, body: str) -> str:
        """Send an email message."""
        return f"sent:{to}:{body}"

    tools = ToolRegistry([multiply_numbers, send_email])
    catalog = ToolCatalog([tools.get("multiply_numbers"), tools.get("send_email")])
    registry = ToolRegistry()
    search_tool = create_tool_search_tool(catalog, registry, max_results=1)

    result = await search_tool.invoke({"query": "calculate product multiply integers"})

    assert search_tool.name == TOOL_SEARCH_NAME
    assert search_tool.description == "Search hidden skill or MCP tools by task text; load matches for the next round."
    assert search_tool.parameters["properties"]["query"]["description"] == "Task or capability that needs a tool."
    assert result["loaded"] == ["multiply_numbers"]
    assert result["already_loaded"] == []
    assert result["results"][0]["loaded"] is True
    assert [schema["function"]["name"] for schema in registry.schemas()] == ["multiply_numbers"]

    repeated = await search_tool.invoke({"query": "calculate product multiply integers"})

    assert repeated["loaded"] == []
    assert repeated["already_loaded"] == ["multiply_numbers"]
    assert [schema["function"]["name"] for schema in registry.schemas()] == ["multiply_numbers"]


@pytest.mark.anyio
async def test_agent_searches_then_calls_hidden_mcp_tool(
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeClient:
        def __init__(self) -> None:
            self.calls: list[list[dict[str, Any]]] = []

        async def complete(self, messages: list[dict[str, Any]], **kwargs: Any) -> ModelResult:
            self.calls.append(messages)
            tools = [tool["function"]["name"] for tool in kwargs["tools"]]
            if len(self.calls) == 1:
                assert tools == ["read", "grep", "glob", TOOL_SEARCH_NAME]
                return ModelResult(
                    text="",
                    raw=_response(
                        "",
                        [
                            _tool_call(
                                "search-1",
                                TOOL_SEARCH_NAME,
                                {"query": "review approve math answer", "limit": 1},
                            )
                        ],
                    ),
                )
            if len(self.calls) == 2:
                assert tools == ["read", "grep", "glob", TOOL_SEARCH_NAME, "review_approval"]
                return ModelResult(
                    text="",
                    raw=_response(
                        "",
                        [_tool_call("review-1", "review_approval", {"answer": "42"})],
                    ),
                )
            return ModelResult(text="42", raw=_response("42"))

    _install_fake_mcp(monkeypatch)

    config = AppConfig(
        repo_path=tmp_path,
        agent=AgentSettings(
            default_model="chat",
            max_tool_rounds=3,
            tool_search=AgentToolSearchSettings(enabled=True, defer_tools=True, max_results=1),
        ),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=False),
        mcp=MCPSettings(
            enabled=True,
            servers={
                "review_server": MCPServerSettings(
                    name="review_server",
                    command="fake",
                    tool_prefix="",
                )
            },
        ),
        models={"chat": ModelSettings(name="chat", provider="test", model="chat-model")},
    )

    built = await build_agent(
        config,
        client=FakeClient(),  # type: ignore[arg-type]
        tracer=NoOpTraceManager(),
    )

    result = await built.agent.run("What is 6*7?")

    assert result.content == "42"


def _response(content: str, tool_calls: list[Any] | None = None) -> Any:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content=content, tool_calls=tool_calls or []),
            )
        ]
    )


def _tool_call(call_id: str, name: str, arguments: dict[str, Any]) -> Any:
    import json

    return SimpleNamespace(
        id=call_id,
        type="function",
        function=SimpleNamespace(name=name, arguments=json.dumps(arguments)),
    )


def _install_fake_mcp(monkeypatch: pytest.MonkeyPatch) -> None:
    mcp_module = types.ModuleType("mcp")
    client_module = types.ModuleType("mcp.client")
    stdio_module = types.ModuleType("mcp.client.stdio")
    http_module = types.ModuleType("mcp.client.streamable_http")

    class StdioServerParameters:
        def __init__(self, **kwargs: Any) -> None:
            self.kwargs = kwargs

    class ClientSession:
        def __init__(self, read_stream: Any, write_stream: Any) -> None:
            self.read_stream = read_stream
            self.write_stream = write_stream

        async def __aenter__(self) -> "ClientSession":
            return self

        async def __aexit__(self, *args: Any) -> None:
            return None

        async def initialize(self) -> None:
            return None

        async def list_tools(self) -> Any:
            return SimpleNamespace(
                tools=[
                    SimpleNamespace(
                        name="review_approval",
                        description="Review and approve a math answer.",
                        inputSchema={
                            "type": "object",
                            "properties": {"answer": {"type": "string"}},
                            "required": ["answer"],
                        },
                    )
                ]
            )

        async def call_tool(self, name: str, arguments: dict[str, Any]) -> Any:
            return SimpleNamespace(
                structuredContent={"approval": f"approved:{arguments['answer']}"},
                content=[],
            )

    @asynccontextmanager
    async def stdio_client(params: Any) -> Any:
        yield object(), object()

    @asynccontextmanager
    async def streamable_http_client(url: str) -> Any:
        yield object(), object(), None

    mcp_module.ClientSession = ClientSession
    mcp_module.StdioServerParameters = StdioServerParameters
    stdio_module.stdio_client = stdio_client
    http_module.streamable_http_client = streamable_http_client

    monkeypatch.setitem(sys.modules, "mcp", mcp_module)
    monkeypatch.setitem(sys.modules, "mcp.client", client_module)
    monkeypatch.setitem(sys.modules, "mcp.client.stdio", stdio_module)
    monkeypatch.setitem(sys.modules, "mcp.client.streamable_http", http_module)
