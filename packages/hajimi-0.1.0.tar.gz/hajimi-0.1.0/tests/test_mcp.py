from __future__ import annotations

import sys
import types
from contextlib import asynccontextmanager
from importlib.util import find_spec
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

from hajimi.config import MCPServerSettings, MCPSettings
from hajimi.config import AgentSettings, AppConfig, LogSettings, ModelSettings, ObservabilitySettings
from hajimi.core import build_agent
from hajimi.llm import ModelResult
from hajimi.mcp import MCPClient, MCPToolSource
from hajimi.observability import NoOpTraceManager


@pytest.mark.anyio
async def test_mcp_client_lists_and_calls_stdio_tools(monkeypatch: pytest.MonkeyPatch) -> None:
    _install_fake_mcp(monkeypatch)
    settings = MCPServerSettings(
        name="local",
        transport="stdio",
        command="fake",
        tool_prefix="mcp",
    )

    tools = await MCPClient(settings).list_tools()

    assert [tool.name for tool in tools] == ["mcp_add"]
    assert tools[0].parameters == {
        "type": "object",
        "properties": {"a": {"type": "integer"}, "b": {"type": "integer"}},
    }
    assert await tools[0].invoke({"a": 2, "b": 3}) == {"sum": 5}


@pytest.mark.anyio
async def test_mcp_tool_source_respects_enabled_flag(monkeypatch: pytest.MonkeyPatch) -> None:
    _install_fake_mcp(monkeypatch)
    settings = MCPSettings(
        enabled=True,
        servers={
            "disabled": MCPServerSettings(name="disabled", enabled=False, command="fake"),
            "enabled": MCPServerSettings(name="enabled", command="fake", tool_prefix=""),
        },
    )

    tools = await MCPToolSource(settings).load_tools()

    assert [tool.name for tool in tools] == ["add"]


@pytest.mark.anyio
async def test_agent_calls_fake_mcp_weather_and_calculator(tmp_path: Path) -> None:
    if find_spec("mcp") is None:
        pytest.skip("mcp extra is not installed")

    class FakeClient:
        def __init__(self) -> None:
            self.calls = 0

        async def complete(self, messages: list[dict[str, Any]], **kwargs: Any) -> ModelResult:
            self.calls += 1
            if self.calls == 1:
                names = [tool["function"]["name"] for tool in kwargs["tools"]]
                assert "fake_get_weather" in names
                assert "fake_add_numbers" in names
                return ModelResult(
                    text="",
                    raw=_response(
                        "",
                        [
                            _tool_call("weather-1", "fake_get_weather", {"city": "Shanghai"}),
                            _tool_call("add-1", "fake_add_numbers", {"a": 20, "b": 22}),
                        ],
                    ),
                )
            assert "Shanghai: sunny, 24C" in str(messages)
            assert "42" in str(messages)
            return ModelResult(text="mcp-ok", raw=_response("mcp-ok"))

    config = AppConfig(
        repo_path=Path.cwd(),
        agent=AgentSettings(default_model="fake", max_tool_rounds=2),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=False),
        mcp=MCPSettings(
            enabled=True,
            servers={
                "fake": MCPServerSettings(
                    name="fake",
                    command="uv",
                    args=["run", "python", "examples/fake_mcp_server.py"],
                    tool_prefix="fake",
                )
            },
        ),
        models={"fake": ModelSettings(name="fake", provider="test", model="fake")},
    )

    built = await build_agent(config, client=FakeClient(), tracer=NoOpTraceManager())  # type: ignore[arg-type]
    result = await built.agent.run("Check Shanghai weather and compute 20+22.")

    assert result.content == "mcp-ok"


def _install_fake_mcp(monkeypatch: pytest.MonkeyPatch) -> None:
    mcp_module = types.ModuleType("mcp")
    client_module = types.ModuleType("mcp.client")
    stdio_module = types.ModuleType("mcp.client.stdio")
    http_module = types.ModuleType("mcp.client.streamable_http")

    class StdioServerParameters:
        def __init__(self, **kwargs: Any) -> None:
            self.kwargs = kwargs

    class ClientSession:
        def __init__(self, read_stream: Any, write_stream: Any) -> None:
            self.read_stream = read_stream
            self.write_stream = write_stream

        async def __aenter__(self) -> "ClientSession":
            return self

        async def __aexit__(self, *args: Any) -> None:
            return None

        async def initialize(self) -> None:
            return None

        async def list_tools(self) -> Any:
            return SimpleNamespace(
                tools=[
                    SimpleNamespace(
                        name="add",
                        description="Add numbers.",
                        inputSchema={
                            "type": "object",
                            "properties": {"a": {"type": "integer"}, "b": {"type": "integer"}},
                        },
                    )
                ]
            )

        async def call_tool(self, name: str, arguments: dict[str, Any]) -> Any:
            return SimpleNamespace(
                structuredContent={"sum": arguments["a"] + arguments["b"]},
                content=[],
            )

    @asynccontextmanager
    async def stdio_client(params: Any) -> Any:
        yield object(), object()

    @asynccontextmanager
    async def streamable_http_client(url: str) -> Any:
        yield object(), object(), None

    mcp_module.ClientSession = ClientSession
    mcp_module.StdioServerParameters = StdioServerParameters
    stdio_module.stdio_client = stdio_client
    http_module.streamable_http_client = streamable_http_client

    monkeypatch.setitem(sys.modules, "mcp", mcp_module)
    monkeypatch.setitem(sys.modules, "mcp.client", client_module)
    monkeypatch.setitem(sys.modules, "mcp.client.stdio", stdio_module)
    monkeypatch.setitem(sys.modules, "mcp.client.streamable_http", http_module)


def _response(content: str, tool_calls: list[Any] | None = None) -> Any:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content=content, tool_calls=tool_calls or []),
            )
        ]
    )


def _tool_call(call_id: str, name: str, arguments: dict[str, Any]) -> Any:
    import json

    return SimpleNamespace(
        id=call_id,
        type="function",
        function=SimpleNamespace(name=name, arguments=json.dumps(arguments)),
    )
