from pathlib import Path

import anyio
import pytest

from hajimi.sandbox import create_local_sandbox
from hajimi.sandbox.e2b import E2BSandboxEnvironment


@pytest.mark.anyio
async def test_local_sandbox_file_directory_and_exec_api(tmp_path: Path) -> None:
    sandbox = create_local_sandbox(
        tmp_path,
        allowed_shell_commands=["python"],
    )

    await sandbox.write_text("notes/todo.txt", "alpha\nbeta\n")
    stat = await sandbox.stat("notes/todo.txt")
    listing = await sandbox.list_dir("notes")
    files = await sandbox.iter_files(".")
    result = await sandbox.exec("python --version", timeout_seconds=5)

    assert stat.path == "notes/todo.txt"
    assert stat.type == "file"
    assert [entry.to_dict() for entry in listing] == [{"path": "todo.txt", "type": "file"}]
    assert files == ["notes/todo.txt"]
    assert result.exit_code == 0
    assert "Python" in result.stdout or "Python" in result.stderr


@pytest.mark.anyio
async def test_local_sandbox_rejects_escape_and_external_symlink(tmp_path: Path) -> None:
    outside = tmp_path.parent / "outside.txt"
    await anyio.Path(outside).write_text("secret-token\n", encoding="utf-8")
    await anyio.Path(tmp_path / "link.txt").symlink_to(outside)

    sandbox = create_local_sandbox(tmp_path)

    with pytest.raises(ValueError, match="escapes sandbox root"):
        await sandbox.read_text("../outside.txt")

    assert await sandbox.iter_files(".") == []


@pytest.mark.anyio
async def test_local_sandbox_allow_lists_shell_commands(tmp_path: Path) -> None:
    sandbox = create_local_sandbox(tmp_path, allowed_shell_commands=["python"])

    with pytest.raises(PermissionError, match="not allow-listed"):
        await sandbox.exec("git status", timeout_seconds=5)


def test_local_sandbox_root_must_stay_under_repo_path(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="sandbox root must stay under repo_path"):
        create_local_sandbox(tmp_path, root=Path(".."))


@pytest.mark.anyio
async def test_e2b_sandbox_adapter_uses_files_and_commands_api() -> None:
    created = 0

    def create_sandbox() -> FakeE2BSandbox:
        nonlocal created
        created += 1
        return FakeE2BSandbox()

    sandbox = E2BSandboxEnvironment(
        root="/workspace",
        sandbox_factory=create_sandbox,
    )

    await sandbox.write_text("notes/todo.txt", "alpha\nbeta\n")
    stat = await sandbox.stat("notes/todo.txt")
    listing = await sandbox.list_dir("notes")
    files = await sandbox.iter_files(".")
    text = await sandbox.read_text("notes/todo.txt")
    await sandbox.write_bytes("notes/raw.bin", b"raw")
    raw = await sandbox.read_bytes("notes/raw.bin")
    result = await sandbox.exec("python --version", timeout_seconds=5)

    assert stat.path == "notes/todo.txt"
    assert stat.type == "file"
    assert [entry.to_dict() for entry in listing] == [{"path": "todo.txt", "type": "file"}]
    assert files == ["notes/todo.txt"]
    assert text == "alpha\nbeta\n"
    assert raw == b"raw"
    assert result.exit_code == 0
    assert result.stdout == "Python 3.14\n"
    assert created == 1


@pytest.mark.anyio
async def test_e2b_sandbox_rejects_path_escape() -> None:
    sandbox = E2BSandboxEnvironment(
        root="/workspace",
        sandbox_factory=lambda: FakeE2BSandbox(),
    )

    with pytest.raises(ValueError, match="escapes sandbox root"):
        await sandbox.read_text("../secret.txt")


class FakeE2BSandbox:
    def __init__(self) -> None:
        self.files = FakeE2BFiles()
        self.commands = FakeE2BCommands()


class FakeE2BFiles:
    def __init__(self) -> None:
        self.contents: dict[str, str | bytes] = {"/workspace/notes/todo.txt": "alpha\nbeta\n"}

    def get_info(self, path: str) -> dict[str, str]:
        if path in self.contents:
            return {"path": path, "name": Path(path).name, "type": "file"}
        return {"path": path, "name": Path(path).name, "type": "directory"}

    def read(self, path: str) -> str | bytes:
        return self.contents[path]

    def write(self, path: str, content: str | bytes) -> None:
        self.contents[path] = content

    def list(self, path: str) -> list[dict[str, str]]:
        if path == "/workspace":
            return [{"path": "/workspace/notes", "name": "notes", "type": "directory"}]
        if path == "/workspace/notes":
            return [{"path": "/workspace/notes/todo.txt", "name": "todo.txt", "type": "file"}]
        return []


class FakeE2BCommands:
    def run(self, command: str, *, cwd: str, timeout: int) -> dict[str, object]:
        assert command == "python --version"
        assert cwd == "/workspace"
        assert timeout == 5
        return {"exit_code": 0, "stdout": "Python 3.14\n", "stderr": ""}
