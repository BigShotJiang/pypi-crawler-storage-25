from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

from hajimi.config import (
    AgentProfileSettings,
    AgentRoutingSettings,
    AgentSettings,
    AppConfig,
    ContextSettings,
    LogSettings,
    MCPSettings,
    ModelSettings,
    ObservabilitySettings,
    SubAgentSettings,
    TeammateSettings,
)
from hajimi.default_tools import SUBAGENT_TOOL_NAME, TEAM_SPAWN_TOOL_NAME
from hajimi.llm import AnyLLMClient, ModelResult
from hajimi.observability import JsonlSpanExporter, TraceManager
from hajimi.runtime import AgentRuntime, RunOptions, ask
from hajimi.session import SessionStore


class ScriptedClient:
    def __init__(self, name: str, scripts: dict[str, list[str]]) -> None:
        self.name = name
        self.scripts = scripts
        self.calls: list[list[dict[str, Any]]] = []
        self.kwargs: list[dict[str, Any]] = []

    async def complete(self, messages: list[dict[str, Any]], **kwargs: Any) -> ModelResult:
        self.calls.append(messages)
        self.kwargs.append(kwargs)
        text = self.scripts[self.name].pop(0)
        return ModelResult(text=text, raw=_response(text))


def _response(content: str) -> Any:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content=content, tool_calls=[]),
            ),
        ],
        usage=SimpleNamespace(prompt_tokens=3, completion_tokens=2, total_tokens=5),
    )


@pytest.mark.anyio
async def test_runtime_ask_uses_single_agent_and_persists_session(tmp_path: Path) -> None:
    config = _config(tmp_path, routing=AgentRoutingSettings(default_profiles=[]))
    tracer = TraceManager(exporter=JsonlSpanExporter(tmp_path / "traces.jsonl"))
    scripts = {"root": ["single-answer"]}
    runtime = AgentRuntime(
        config=config,
        tracer=tracer,
        store=_store(tmp_path),
        client_factory=_factory(scripts),
    )

    result = await runtime.run_task("hello", options=RunOptions(mode="auto"))

    assert result.content == "single-answer"
    assert result.plan.mode == "single"
    assert result.plan.reason == "auto_simple_task"
    assert result.session_id is not None
    assert result.token_report is not None
    events = await runtime.store.read_events(result.session_id)  # type: ignore[union-attr]
    assert [event.type for event in events] == [
        "session.created",
        "message.appended",
        "message.appended",
        "token.usage",
        "run.completed",
    ]


@pytest.mark.anyio
async def test_runtime_auto_routes_complex_task_to_profiles_and_records_route(tmp_path: Path) -> None:
    config = _config(
        tmp_path,
        routing=AgentRoutingSettings(
            simple_max_words=2,
            default_profiles=["planner", "reviewer"],
            synthesizer_profile="reviewer",
        ),
    )
    tracer = TraceManager(exporter=JsonlSpanExporter(tmp_path / "traces.jsonl"))
    scripts = {
        "planner_model": ["plan-output"],
        "reviewer_model": ["review-output", "final-synthesis"],
    }
    runtime = AgentRuntime(
        config=config,
        tracer=tracer,
        store=_store(tmp_path),
        client_factory=_factory(scripts),
    )

    result = await runtime.run_task("complex task with several parts")

    assert result.content == "final-synthesis"
    assert result.plan.mode == "subagents"
    assert result.plan.profiles == ["planner", "reviewer"]
    assert [worker.content for worker in result.workers] == ["plan-output", "review-output"]
    assert result.session_id is not None
    events = await runtime.store.read_events(result.session_id)  # type: ignore[union-attr]
    assert [event.type for event in events] == [
        "session.created",
        "message.appended",
        "message.appended",
        "runtime.route",
    ]
    route_event = events[-1]
    assert route_event.payload["plan"]["mode"] == "subagents"
    assert route_event.payload["workers"][0]["profile"] == "planner"


@pytest.mark.anyio
async def test_runtime_profile_workers_do_not_receive_orchestration_tools(tmp_path: Path) -> None:
    config = _config(
        tmp_path,
        routing=AgentRoutingSettings(
            simple_max_words=1,
            default_profiles=["planner"],
        ),
        subagents=SubAgentSettings(enabled=True, max_depth=2),
        teammates=TeammateSettings(enabled=True),
    )
    scripts = {"planner_model": ["worker-output"]}
    clients: dict[str, ScriptedClient] = {}

    def create(model: ModelSettings, tracer: TraceManager) -> AnyLLMClient:
        client = ScriptedClient(model.name, scripts)
        clients[model.name] = client
        return client  # type: ignore[return-value]

    runtime = AgentRuntime(
        config=config,
        tracer=TraceManager(exporter=JsonlSpanExporter(tmp_path / "traces.jsonl")),
        store=None,
        client_factory=create,
    )

    result = await runtime.run_task("complex task", options=RunOptions(use_session=False))

    assert result.content == "worker-output"
    tools = clients["planner_model"].kwargs[0]["tools"]
    tool_names = [tool["function"]["name"] for tool in tools or []]
    assert SUBAGENT_TOOL_NAME not in tool_names
    assert TEAM_SPAWN_TOOL_NAME not in tool_names


@pytest.mark.anyio
async def test_runtime_replicas_run_independently_and_synthesize(tmp_path: Path) -> None:
    config = _config(tmp_path, routing=AgentRoutingSettings(default_profiles=[], default_replicas=2))
    tracer = TraceManager(exporter=JsonlSpanExporter(tmp_path / "traces.jsonl"))
    scripts = {
        "root": ["replica-one", "replica-two", "final"],
    }
    runtime = AgentRuntime(
        config=config,
        tracer=tracer,
        store=_store(tmp_path),
        client_factory=_factory(scripts),
    )

    result = await runtime.run_task(
        "try two approaches",
        options=RunOptions(mode="replicas", replicas=2),
    )

    assert result.content == "final"
    assert result.plan.mode == "replicas"
    assert result.plan.replicas == 2
    assert [worker.name for worker in result.workers] == ["replica_1", "replica_2"]
    assert sorted(worker.content for worker in result.workers) == ["replica-one", "replica-two"]
    assert result.session_id is not None
    events = await runtime.store.read_events(result.session_id)  # type: ignore[union-attr]
    assert events[-1].type == "runtime.route"
    assert events[-1].payload["workers"][1]["name"] == "replica_2"


@pytest.mark.anyio
async def test_runtime_budget_blocks_oversized_task(tmp_path: Path) -> None:
    config = _config(tmp_path)
    runtime = AgentRuntime(
        config=config,
        tracer=TraceManager(exporter=JsonlSpanExporter(tmp_path / "traces.jsonl")),
        store=None,
        client_factory=_factory({"root": ["unused"]}),
    )

    with pytest.raises(RuntimeError, match="exceed max_budget_tokens"):
        await runtime.run_task(
            "one two three",
            options=RunOptions(mode="single", max_budget_tokens=2, use_session=False),
        )


@pytest.mark.anyio
async def test_runtime_subagents_require_profiles(tmp_path: Path) -> None:
    config = _config(tmp_path, routing=AgentRoutingSettings(default_profiles=[]), profiles={})
    runtime = AgentRuntime(
        config=config,
        tracer=TraceManager(exporter=JsonlSpanExporter(tmp_path / "traces.jsonl")),
        store=None,
        client_factory=_factory({"root": ["unused"]}),
    )

    with pytest.raises(ValueError, match="requires at least one"):
        await runtime.run_task("complex task", options=RunOptions(mode="subagents", use_session=False))


@pytest.mark.anyio
async def test_top_level_ask_returns_content_string(tmp_path: Path) -> None:
    config = _config(tmp_path, routing=AgentRoutingSettings(default_profiles=[]))

    result = await ask(
        "hello",
        config=config,
        tracer=TraceManager(exporter=JsonlSpanExporter(tmp_path / "traces.jsonl")),
        client_factory=_factory({"root": ["top-level-answer"]}),
    )

    assert result == "top-level-answer"


def _config(
    tmp_path: Path,
    *,
    routing: AgentRoutingSettings | None = None,
    profiles: dict[str, AgentProfileSettings] | None = None,
    subagents: SubAgentSettings | None = None,
    teammates: TeammateSettings | None = None,
) -> AppConfig:
    return AppConfig(
        repo_path=tmp_path,
        agent=AgentSettings(
            name="root",
            default_model="root",
            routing=routing or AgentRoutingSettings(default_profiles=["planner", "reviewer"]),
            subagents=subagents or SubAgentSettings(),
            teammates=teammates or TeammateSettings(),
            profiles=profiles
            if profiles is not None
            else {
                "planner": AgentProfileSettings(name="planner", model_name="planner_model"),
                "reviewer": AgentProfileSettings(name="reviewer", model_name="reviewer_model"),
            },
        ),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=True, directory=tmp_path),
        context=ContextSettings(store_dir=tmp_path / "sessions", events_dir=tmp_path / "events"),
        mcp=MCPSettings(enabled=False),
        models={
            "root": ModelSettings(name="root", provider="test", model="root-model"),
            "planner_model": ModelSettings(name="planner_model", provider="test", model="planner-model"),
            "reviewer_model": ModelSettings(name="reviewer_model", provider="test", model="reviewer-model"),
        },
    )


def _factory(scripts: dict[str, list[str]]) -> Any:
    def create(model: ModelSettings, tracer: TraceManager) -> AnyLLMClient:
        return ScriptedClient(model.name, scripts)  # type: ignore[return-value]

    return create


def _store(tmp_path: Path) -> SessionStore:
    return SessionStore(
        sqlite_path=tmp_path / "sessions.sqlite",
        events_dir=tmp_path / "events",
    )
