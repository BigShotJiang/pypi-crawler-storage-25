import pytest
from typing import Literal

from hajimi.tool import Tool, tool


@pytest.mark.anyio
async def test_tool_decorator_creates_tool_from_function() -> None:
    @tool
    def multiply_numbers(a: int, b: int) -> int:
        """Multiply two integers."""
        return a * b

    assert isinstance(multiply_numbers, Tool)
    assert multiply_numbers.name == "multiply_numbers"
    assert multiply_numbers.description == "Multiply two integers."
    assert multiply_numbers.parameters == {
        "type": "object",
        "properties": {
            "a": {"type": "integer"},
            "b": {"type": "integer"},
        },
        "required": ["a", "b"],
    }
    assert await multiply_numbers.invoke({"a": 6, "b": 7}) == 42


@pytest.mark.anyio
async def test_tool_decorator_accepts_overrides() -> None:
    @tool(name="sum_values", description="Add values.")
    async def add(a: int, b: int = 0) -> int:
        return a + b

    assert add.name == "sum_values"
    assert add.description == "Add values."
    assert add.parameters == {
        "type": "object",
        "properties": {
            "a": {"type": "integer"},
            "b": {"type": "integer", "default": 0},
        },
        "required": ["a"],
    }
    assert await add.invoke({"a": 2, "b": 3}) == 5


def test_tool_decorator_accepts_parameter_schema_override() -> None:
    parameters = {
        "type": "object",
        "properties": {"value": {"type": "string", "enum": ["ok"]}},
        "required": ["value"],
    }

    @tool(parameters=parameters)
    def echo(value: str) -> str:
        return value

    assert echo.parameters == parameters


def test_tool_decorator_infers_parameter_descriptions_and_richer_types() -> None:
    @tool
    def search_notes(
        query: str,
        tags: list[str] | None = None,
        mode: Literal["fast", "deep"] = "fast",
        metadata: dict[str, int] | None = None,
    ) -> list[str]:
        """Search notes.

        Args:
            query: Text to search for.
            tags: Optional tag filters.
            mode: Search depth.
            metadata: Numeric metadata filters.
        """
        del query, tags, mode, metadata
        return []

    assert search_notes.description == "Search notes."
    assert search_notes.parameters == {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Text to search for."},
            "tags": {
                "type": "array",
                "items": {"type": "string"},
                "nullable": True,
                "description": "Optional tag filters.",
            },
            "mode": {
                "enum": ["fast", "deep"],
                "type": "string",
                "description": "Search depth.",
                "default": "fast",
            },
            "metadata": {
                "type": "object",
                "additionalProperties": {"type": "integer"},
                "nullable": True,
                "description": "Numeric metadata filters.",
            },
        },
        "required": ["query"],
    }
