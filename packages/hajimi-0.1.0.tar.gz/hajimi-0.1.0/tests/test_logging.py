from pathlib import Path
import json

import anyio
import pytest
from loguru import logger

from hajimi.config import LogSettings
from hajimi.logging import configure_logging


@pytest.mark.anyio
async def test_configure_logging_creates_default_log_file(tmp_path: Path) -> None:
    log_file = await configure_logging(
        LogSettings(enable_console=False, enqueue=False),
        tmp_path,
    )

    assert log_file == tmp_path / "logs" / "hajimi.jsonl"
    logger.debug("debug to file")
    await logger.complete()
    assert await anyio.Path(log_file).exists()

    text = await anyio.Path(log_file).read_text(encoding="utf-8")
    record = json.loads(text.splitlines()[0])
    assert record["record"]["message"] == "debug to file"
    assert record["record"]["level"]["name"] == "DEBUG"
