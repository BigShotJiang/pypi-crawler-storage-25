from collections.abc import AsyncIterator
from pathlib import Path
import json
from types import SimpleNamespace
from typing import Any

import anyio
import pytest

from hajimi.config import ModelSettings, ObservabilitySettings
from hajimi.core import Agent
from hajimi.llm import AnyLLMClient
from hajimi.observability import setup_observability


@pytest.mark.anyio
async def test_agent_and_llm_write_related_spans(tmp_path: Path) -> None:
    async def fake_completion(**kwargs: Any) -> Any:
        return SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(content="ok", tool_calls=[]),
                ),
            ],
            usage=SimpleNamespace(prompt_tokens=1, completion_tokens=1, total_tokens=2),
        )

    tracer = await setup_observability(
        ObservabilitySettings(directory=tmp_path, include_content=True),
        tmp_path,
    )
    client = AnyLLMClient(
        ModelSettings(name="chat", provider="test", model="chat-model"),
        completion_api=fake_completion,
        tracer=tracer,
    )
    agent = Agent(client=client, tracer=tracer)

    result = await agent.run("hello")

    records = await _read_trace_records(tmp_path / "traces.jsonl")
    assert result.content == "ok"
    assert [record["name"] for record in records] == ["llm.completion", "agent.run"]
    assert records[0]["trace_id"] == records[1]["trace_id"]
    assert records[0]["parent_span_id"] == records[1]["span_id"]
    assert records[0]["attributes"]["llm.usage.total_tokens"] == 2
    assert records[1]["events"][0]["name"] == "agent.input"


@pytest.mark.anyio
async def test_stream_records_one_output_event_after_completion(tmp_path: Path) -> None:
    async def stream() -> AsyncIterator[Any]:
        yield SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content="he"))])
        yield SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content="llo"))])

    async def fake_completion(**kwargs: Any) -> Any:
        return stream()

    tracer = await setup_observability(
        ObservabilitySettings(directory=tmp_path),
        tmp_path,
    )
    client = AnyLLMClient(
        ModelSettings(name="chat", provider="test", model="chat-model"),
        completion_api=fake_completion,
        tracer=tracer,
    )
    agent = Agent(client=client, tracer=tracer)

    assert "".join([event.text async for event in agent.stream("hello")]) == "hello"

    records = await _read_trace_records(tmp_path / "traces.jsonl")
    llm_record = next(record for record in records if record["name"] == "llm.completion.stream")
    assert llm_record["attributes"]["llm.stream.chunks"] == 2
    assert [event["name"] for event in llm_record["events"]] == ["llm.input", "llm.output"]
    assert llm_record["events"][1]["attributes"]["content"] == "hello"


@pytest.mark.anyio
async def test_content_can_be_disabled(tmp_path: Path) -> None:
    async def fake_completion(**kwargs: Any) -> Any:
        return SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(content="secret-output", tool_calls=[]),
                ),
            ],
        )

    tracer = await setup_observability(
        ObservabilitySettings(directory=tmp_path, include_content=False),
        tmp_path,
    )
    client = AnyLLMClient(
        ModelSettings(name="chat", provider="test", model="chat-model"),
        completion_api=fake_completion,
        tracer=tracer,
    )
    agent = Agent(client=client, tracer=tracer)

    await agent.run("secret-input")

    text = await anyio.Path(tmp_path / "traces.jsonl").read_text(encoding="utf-8")
    assert "secret-input" not in text
    assert "secret-output" not in text


@pytest.mark.anyio
async def test_tool_calls_are_recorded_as_events_and_spans(tmp_path: Path) -> None:
    def add(a: int, b: int) -> int:
        """Add two numbers."""
        return a + b

    tool_call = SimpleNamespace(
        id="call-1",
        type="function",
        function=SimpleNamespace(name="add", arguments='{"a": 2, "b": 3}'),
    )
    responses = [
        SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(content="", tool_calls=[tool_call]),
                ),
            ],
        ),
        SimpleNamespace(
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(content="5", tool_calls=[]),
                ),
            ],
        ),
    ]

    async def fake_completion(**kwargs: Any) -> Any:
        return responses.pop(0)

    tracer = await setup_observability(
        ObservabilitySettings(directory=tmp_path, include_content=True),
        tmp_path,
    )
    client = AnyLLMClient(
        ModelSettings(name="chat", provider="test", model="chat-model"),
        completion_api=fake_completion,
        tracer=tracer,
    )
    agent = Agent.from_tools(client=client, tools=[add], tracer=tracer)

    result = await agent.run("2+3?")

    records = await _read_trace_records(tmp_path / "traces.jsonl")
    agent_record = next(record for record in records if record["name"] == "agent.run")
    tool_record = next(record for record in records if record["name"] == "tool.call")
    tool_call_event = next(event for event in agent_record["events"] if event["name"] == "agent.tool_calls")

    assert result.content == "5"
    assert tool_call_event["attributes"]["names"] == ["add"]
    assert tool_record["trace_id"] == agent_record["trace_id"]
    assert tool_record["parent_span_id"] == agent_record["span_id"]
    assert tool_record["attributes"]["tool.name"] == "add"
    assert tool_record["attributes"]["tool.call_id"] == "call-1"
    assert [event["name"] for event in tool_record["events"]] == ["tool.input", "tool.output"]
    assert tool_record["events"][0]["attributes"]["arguments"] == "{'a': 2, 'b': 3}"
    assert tool_record["events"][1]["attributes"]["content"] == "5"


async def _read_trace_records(path: Path) -> list[dict[str, Any]]:
    text = await anyio.Path(path).read_text(encoding="utf-8")
    return [json.loads(line) for line in text.splitlines()]
