from pathlib import Path

import anyio
import pytest

from hajimi.config import (
    AgentSettings,
    AgentSkillLoadingSettings,
    AgentWorkspaceToolsSettings,
    AppConfig,
    LogSettings,
    MCPSettings,
    ModelSettings,
    ObservabilitySettings,
)
from hajimi.core import build_agent
from hajimi.default_tools import SKILL_SCRIPT_TOOL_NAME, SKILL_TOOL_NAME
from hajimi.llm import AnyLLMClient
from hajimi.observability import NoOpTraceManager
from hajimi.skill import load_skill, load_skills


@pytest.mark.anyio
async def test_load_skill_reads_instructions_and_tools(tmp_path: Path) -> None:
    skill_dir = tmp_path / "skills" / "math"
    await anyio.Path(skill_dir).mkdir(parents=True)
    await anyio.Path(skill_dir / "SKILL.md").write_text("Use math tools.", encoding="utf-8")
    await anyio.Path(skill_dir / "tools.py").write_text(
        """
def double(value: int) -> int:
    \"\"\"Double a number.\"\"\"
    return value * 2
""",
        encoding="utf-8",
    )

    skill = await load_skill("math", base_dir=tmp_path / "skills")

    assert skill.instructions == "Use math tools."
    assert [tool.name for tool in skill.tools] == ["double"]
    assert await skill.tools[0].invoke({"value": 4}) == 8


@pytest.mark.anyio
async def test_build_agent_merges_skill_prompt_and_tools(tmp_path: Path) -> None:
    skill_dir = tmp_path / "skills" / "math"
    await anyio.Path(skill_dir).mkdir(parents=True)
    await anyio.Path(skill_dir / "SKILL.md").write_text("Use math tools.", encoding="utf-8")
    await anyio.Path(skill_dir / "tools.py").write_text(
        """
def triple(value: int) -> int:
    \"\"\"Triple a number.\"\"\"
    return value * 3
""",
        encoding="utf-8",
    )

    config = AppConfig(
        repo_path=tmp_path,
        agent=AgentSettings(system_prompt="Base prompt.", skills=["math"]),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=False),
        mcp=MCPSettings(enabled=False),
        models={"chat": ModelSettings(name="chat", provider="test", model="chat")},
    )
    client = AnyLLMClient(config.model("chat"))

    built = await build_agent(config, client=client, tracer=NoOpTraceManager())

    assert "Base prompt." in (built.system_prompt or "")
    assert "Use math tools." in (built.system_prompt or "")
    assert f"Use {SKILL_TOOL_NAME}" in (built.system_prompt or "")
    assert [tool.name for tool in built.tools] == ["read", "grep", "glob", SKILL_TOOL_NAME]

    result = await built.agent.tools.get(SKILL_TOOL_NAME).invoke({"skill_name": "math"})

    assert result["loaded_tools"] == ["triple"]
    assert result["sandbox_path"] == ".hajimi/skill-runs/math"
    assert result["script_tool"] == SKILL_SCRIPT_TOOL_NAME
    assert built.agent.tools.names() == [
        "read",
        "grep",
        "glob",
        SKILL_TOOL_NAME,
        "triple",
        SKILL_SCRIPT_TOOL_NAME,
    ]


@pytest.mark.anyio
async def test_progressive_skill_activation_respects_tool_names(tmp_path: Path) -> None:
    skill_dir = tmp_path / "skills" / "math"
    await anyio.Path(skill_dir).mkdir(parents=True)
    await anyio.Path(skill_dir / "SKILL.md").write_text("Use math tools.", encoding="utf-8")
    await anyio.Path(skill_dir / "tools.py").write_text(
        """
def multiply_numbers(a: int, b: int) -> int:
    \"\"\"Multiply two integers.\"\"\"
    return a * b


def divide_numbers(a: int, b: int) -> float:
    \"\"\"Divide two integers.\"\"\"
    return a / b
""",
        encoding="utf-8",
    )

    config = AppConfig(
        repo_path=tmp_path,
        agent=AgentSettings(system_prompt="Base prompt.", skills=["math"]),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=False),
        mcp=MCPSettings(enabled=False),
        models={"chat": ModelSettings(name="chat", provider="test", model="chat")},
    )
    client = AnyLLMClient(config.model("chat"))

    built = await build_agent(
        config,
        client=client,
        tracer=NoOpTraceManager(),
        tool_names=["multiply_numbers"],
    )
    result = await built.agent.tools.get(SKILL_TOOL_NAME).invoke({"skill_name": "math"})

    assert result["loaded_tools"] == ["multiply_numbers"]
    assert built.agent.tools.names() == [SKILL_TOOL_NAME, "multiply_numbers"]


@pytest.mark.anyio
async def test_skill_catalog_prompt_uses_custom_activation_tool_name(tmp_path: Path) -> None:
    skill_dir = tmp_path / "skills" / "math"
    await anyio.Path(skill_dir).mkdir(parents=True)
    await anyio.Path(skill_dir / "SKILL.md").write_text("Use math tools.", encoding="utf-8")

    config = AppConfig(
        repo_path=tmp_path,
        agent=AgentSettings(
            system_prompt="Base prompt.",
            skills=["math"],
            skill_loading=AgentSkillLoadingSettings(activation_tool_name="activate_skill"),
        ),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=False),
        mcp=MCPSettings(enabled=False),
        models={"chat": ModelSettings(name="chat", provider="test", model="chat")},
    )
    client = AnyLLMClient(config.model("chat"))

    built = await build_agent(config, client=client, tracer=NoOpTraceManager())

    assert "Use activate_skill" in (built.system_prompt or "")
    assert [tool.name for tool in built.tools] == ["read", "grep", "glob", "activate_skill"]


@pytest.mark.anyio
async def test_build_agent_auto_discovers_agent_skill_catalog(tmp_path: Path) -> None:
    skill_dir = tmp_path / ".agents" / "skills" / "writer"
    await anyio.Path(skill_dir).mkdir(parents=True)
    await anyio.Path(skill_dir / "SKILL.md").write_text(
        """---
name: writer
description: Write project prose.
---
Use concise prose.
""",
        encoding="utf-8",
    )

    config = AppConfig(
        repo_path=tmp_path,
        agent=AgentSettings(system_prompt="Base prompt."),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=False),
        mcp=MCPSettings(enabled=False),
        models={"chat": ModelSettings(name="chat", provider="test", model="chat")},
    )
    client = AnyLLMClient(config.model("chat"))

    built = await build_agent(config, client=client, tracer=NoOpTraceManager())

    assert "- writer: Write project prose." in (built.system_prompt or "")
    assert SKILL_TOOL_NAME in built.agent.tools.names()


@pytest.mark.anyio
async def test_load_skills_combines_multiple_skills(tmp_path: Path) -> None:
    for name in ["alpha", "beta"]:
        skill_dir = tmp_path / name
        await anyio.Path(skill_dir).mkdir()
        await anyio.Path(skill_dir / "SKILL.md").write_text(f"{name} instructions", encoding="utf-8")

    bundle = await load_skills(["alpha", "beta"], base_dir=tmp_path)

    assert "alpha instructions" in (bundle.instructions or "")
    assert "beta instructions" in (bundle.instructions or "")


@pytest.mark.anyio
async def test_skill_frontmatter_metadata_and_resources_are_progressive(tmp_path: Path) -> None:
    skill_dir = tmp_path / "skills" / "writer"
    await anyio.Path(skill_dir / "references").mkdir(parents=True)
    await anyio.Path(skill_dir / "SKILL.md").write_text(
        """---
name: prose-writer
description: Draft and revise prose.
---
# Writer

Use the bundled references only when needed.
""",
        encoding="utf-8",
    )
    await anyio.Path(skill_dir / "references" / "tone.md").write_text("Keep it direct.", encoding="utf-8")

    skill = await load_skill("writer", base_dir=tmp_path / "skills")

    assert skill.name == "prose-writer"
    assert skill.metadata is not None
    assert skill.metadata.description == "Draft and revise prose."
    assert skill.instructions == "# Writer\n\nUse the bundled references only when needed.\n"
    assert [resource.to_dict() for resource in skill.resources] == [
        {"path": "references/tone.md", "type": "reference", "bytes": 15}
    ]


@pytest.mark.anyio
async def test_skill_script_runs_in_shared_sandbox(tmp_path: Path) -> None:
    skill_dir = tmp_path / "skills" / "writer"
    await anyio.Path(skill_dir / "scripts").mkdir(parents=True)
    await anyio.Path(skill_dir / "SKILL.md").write_text(
        """---
name: writer
description: Write files from scripts.
---
Use scripts/render.py for rendering.
""",
        encoding="utf-8",
    )
    await anyio.Path(skill_dir / "scripts" / "render.py").write_text(
        """
from pathlib import Path
import sys

Path(sys.argv[1]).write_text("rendered", encoding="utf-8")
print(Path.cwd())
""".strip(),
        encoding="utf-8",
    )

    config = AppConfig(
        repo_path=tmp_path,
        agent=AgentSettings(
            system_prompt="Base prompt.",
            skills=["writer"],
            workspace_tools=AgentWorkspaceToolsSettings(
                sandbox_provider="local",
                allow_shell=True,
                allowed_shell_commands=["python"],
            ),
        ),
        log=LogSettings(),
        observability=ObservabilitySettings(enabled=False),
        mcp=MCPSettings(enabled=False),
        models={"chat": ModelSettings(name="chat", provider="test", model="chat")},
    )
    client = AnyLLMClient(config.model("chat"))
    built = await build_agent(config, client=client, tracer=NoOpTraceManager())

    loaded = await built.agent.tools.get(SKILL_TOOL_NAME).invoke({"skill_name": "writer"})
    result = await built.agent.tools.get(SKILL_SCRIPT_TOOL_NAME).invoke(
        {
            "skill_name": "writer",
            "script_path": "scripts/render.py",
            "args": ["output.txt"],
            "timeout_seconds": 5,
        }
    )
    output = await built.agent.tools.get("read").invoke({"path": ".hajimi/skill-runs/writer/output.txt"})

    assert loaded["resources"] == [{"path": "scripts/render.py", "type": "script", "bytes": 113}]
    assert result["exit_code"] == 0
    assert result["cwd"] == ".hajimi/skill-runs/writer"
    assert output["content"] == "rendered"
