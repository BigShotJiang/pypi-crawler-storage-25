from pathlib import Path

import anyio
import pytest

from hajimi.config import load_config
from hajimi.default_tools import (
    SKILL_TOOL_NAME,
    SUBAGENT_TOOL_DESCRIPTION,
    SUBAGENT_TOOL_NAME,
    TEAM_BROADCAST_TOOL_NAME,
    TEAM_CLOSE_TOOL_NAME,
    TEAM_LIST_TOOL_NAME,
    TEAM_SEND_TOOL_NAME,
    TEAM_SPAWN_TOOL_NAME,
    TOOL_SEARCH_NAME,
    WORKSPACE_BASH_TOOL_NAME,
    WORKSPACE_EDIT_TOOL_NAME,
    WORKSPACE_GLOB_TOOL_NAME,
    WORKSPACE_GREP_TOOL_NAME,
    WORKSPACE_READ_TOOL_NAME,
    WORKSPACE_WRITE_TOOL_NAME,
)


@pytest.mark.anyio
async def test_load_config_merges_toml_and_env(tmp_path: Path) -> None:
    config_path = tmp_path / "configs.toml"
    env_path = tmp_path / ".env"
    await anyio.Path(config_path).write_text(
        """
[agent]
default_model = "deepseek_flash"

[log]

[context]
database_url = "sqlite:////tmp/hajimi-test.sqlite"

[model.deepseek_flash]
provider = "deepseek"
model = "deepseek_v4_flash"
api_key = ""
base_url = ""
temperature = 0.2
max_tokens = 128
""",
        encoding="utf-8",
    )
    await anyio.Path(env_path).write_text(
        'DEEPSEEK_API_KEY="test-key"\nDEEPSEEK_BASE_URL=https://example.test\n',
        encoding="utf-8",
    )

    config = await load_config(config_path, env_path=env_path, repo_path=tmp_path)
    model = config.model()

    assert config.repo_path == tmp_path
    assert model.api_key == "test-key"
    assert model.base_url == "https://example.test"
    assert model.direct_api_kwargs()["api_base"] == "https://example.test"
    assert config.observability.file_name == "traces.jsonl"
    assert config.context.database_url == "sqlite:////tmp/hajimi-test.sqlite"


@pytest.mark.anyio
async def test_load_config_reads_agent_profiles(tmp_path: Path) -> None:
    config_path = tmp_path / "configs.toml"
    await anyio.Path(config_path).write_text(
        """
[agent]
default_model = "deepseek_flash"

[agent.profile.math]
model_name = "deepseek_math"
system_prompt = "Use math tools."
max_tool_rounds = 2
skills = ["calculator"]
mcp_servers = ["math_server"]
tool_names = ["multiply_numbers"]

[model.deepseek_flash]
provider = "deepseek"
model = "deepseek_v4_flash"

[model.deepseek_math]
provider = "deepseek"
model = "deepseek_v4_flash"
""",
        encoding="utf-8",
    )

    config = await load_config(config_path, repo_path=tmp_path)
    profile = config.agent.profiles["math"]

    assert profile.model_name == "deepseek_math"
    assert profile.system_prompt == "Use math tools."
    assert profile.max_tool_rounds == 2
    assert profile.skills == ["calculator"]
    assert profile.mcp_servers == ["math_server"]
    assert profile.tool_names == ["multiply_numbers"]


@pytest.mark.anyio
async def test_agent_profile_tool_names_are_optional(tmp_path: Path) -> None:
    config_path = tmp_path / "configs.toml"
    await anyio.Path(config_path).write_text(
        """
[agent.profile.open_tools]
skills = ["calculator"]

[model.deepseek_flash]
provider = "deepseek"
model = "deepseek_v4_flash"
""",
        encoding="utf-8",
    )

    config = await load_config(config_path, repo_path=tmp_path)

    assert config.agent.profiles["open_tools"].tool_names is None


@pytest.mark.anyio
async def test_load_config_uses_short_builtin_tool_defaults(tmp_path: Path) -> None:
    config_path = tmp_path / "configs.toml"
    await anyio.Path(config_path).write_text(
        """
[model.deepseek_flash]
provider = "deepseek"
model = "deepseek_v4_flash"
""",
        encoding="utf-8",
    )

    config = await load_config(config_path, repo_path=tmp_path)

    assert config.agent.skill_loading.activation_tool_name == SKILL_TOOL_NAME
    assert config.agent.tool_search.tool_name == TOOL_SEARCH_NAME
    assert config.agent.subagents.tool_name == SUBAGENT_TOOL_NAME
    assert config.agent.subagents.tool_description == SUBAGENT_TOOL_DESCRIPTION
    assert config.agent.teammates.spawn_tool_name == TEAM_SPAWN_TOOL_NAME
    assert config.agent.teammates.send_tool_name == TEAM_SEND_TOOL_NAME
    assert config.agent.teammates.broadcast_tool_name == TEAM_BROADCAST_TOOL_NAME
    assert config.agent.teammates.list_tool_name == TEAM_LIST_TOOL_NAME
    assert config.agent.teammates.close_tool_name == TEAM_CLOSE_TOOL_NAME
    assert config.agent.workspace_tools.read_tool_name == WORKSPACE_READ_TOOL_NAME
    assert config.agent.workspace_tools.write_tool_name == WORKSPACE_WRITE_TOOL_NAME
    assert config.agent.workspace_tools.edit_tool_name == WORKSPACE_EDIT_TOOL_NAME
    assert config.agent.workspace_tools.grep_tool_name == WORKSPACE_GREP_TOOL_NAME
    assert config.agent.workspace_tools.glob_tool_name == WORKSPACE_GLOB_TOOL_NAME
    assert config.agent.workspace_tools.bash_tool_name == WORKSPACE_BASH_TOOL_NAME


@pytest.mark.anyio
async def test_load_config_reads_workspace_tool_settings(tmp_path: Path) -> None:
    config_path = tmp_path / "configs.toml"
    await anyio.Path(config_path).write_text(
        """
[agent.workspace_tools]
enabled = true
sandbox_provider = "local"
root = "sandbox"
allow_write = true
allow_shell = true
max_read_chars = 1000
max_output_chars = 2000
max_search_results = 20
allowed_shell_commands = ["python", "git"]

[model.deepseek_flash]
provider = "deepseek"
model = "deepseek_v4_flash"
""",
        encoding="utf-8",
    )

    config = await load_config(config_path, repo_path=tmp_path)

    assert config.agent.workspace_tools.root == Path("sandbox")
    assert config.agent.workspace_tools.sandbox_provider == "local"
    assert config.agent.workspace_tools.allow_write is True
    assert config.agent.workspace_tools.allow_shell is True
    assert config.agent.workspace_tools.max_read_chars == 1000
    assert config.agent.workspace_tools.max_output_chars == 2000
    assert config.agent.workspace_tools.max_search_results == 20
    assert config.agent.workspace_tools.allowed_shell_commands == ["python", "git"]


@pytest.mark.anyio
async def test_load_config_reads_teammate_settings(tmp_path: Path) -> None:
    config_path = tmp_path / "configs.toml"
    await anyio.Path(config_path).write_text(
        """
[agent.teammates]
enabled = true
max_members = 6
spawn_tool_name = "spawn_teammate"
send_tool_name = "send_teammate_message"
broadcast_tool_name = "broadcast_teammate_message"
list_tool_name = "list_teammates"
close_tool_name = "close_teammate"
max_tool_rounds = 3

[model.deepseek_flash]
provider = "deepseek"
model = "deepseek_v4_flash"
""",
        encoding="utf-8",
    )

    config = await load_config(config_path, repo_path=tmp_path)

    assert config.agent.teammates.enabled is True
    assert config.agent.teammates.max_members == 6
    assert config.agent.teammates.max_tool_rounds == 3


@pytest.mark.anyio
async def test_load_config_reads_routing_settings(tmp_path: Path) -> None:
    config_path = tmp_path / "configs.toml"
    await anyio.Path(config_path).write_text(
        """
[agent.routing]
enabled = true
strategy = "auto"
simple_max_words = 12
simple_max_tool_markers = 1
default_mode = "subagents"
default_profiles = ["planner", "reviewer"]
default_replicas = 2
planner_profile = "planner"
synthesizer_profile = "reviewer"
max_parallel_agents = 3
max_budget_tokens = 1000

[model.deepseek_flash]
provider = "deepseek"
model = "deepseek_v4_flash"
""",
        encoding="utf-8",
    )

    config = await load_config(config_path, repo_path=tmp_path)

    assert config.agent.routing.simple_max_words == 12
    assert config.agent.routing.simple_max_tool_markers == 1
    assert config.agent.routing.default_mode == "subagents"
    assert config.agent.routing.default_profiles == ["planner", "reviewer"]
    assert config.agent.routing.default_replicas == 2
    assert config.agent.routing.planner_profile == "planner"
    assert config.agent.routing.synthesizer_profile == "reviewer"
    assert config.agent.routing.max_parallel_agents == 3
    assert config.agent.routing.max_budget_tokens == 1000


@pytest.mark.anyio
async def test_toml_secret_takes_priority_over_env(tmp_path: Path) -> None:
    config_path = tmp_path / "configs.toml"
    env_path = tmp_path / ".env"
    await anyio.Path(config_path).write_text(
        """
[model.deepseek_flash]
provider = "deepseek"
model = "deepseek_v4_flash"
api_key = "toml-key"
base_url = "https://toml.example"
""",
        encoding="utf-8",
    )
    await anyio.Path(env_path).write_text(
        "DEEPSEEK_API_KEY=env-key\nDEEPSEEK_BASE_URL=https://env.example\n",
        encoding="utf-8",
    )

    config = await load_config(config_path, env_path=env_path, repo_path=tmp_path)
    model = config.model("deepseek_flash")

    assert model.api_key == "toml-key"
    assert model.base_url == "https://toml.example"
