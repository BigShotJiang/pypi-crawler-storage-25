# Multi-agent

Hajimi implements the supervisor pattern first: a parent agent can call a child
agent as a tool, while the parent keeps control of the main turn.

## Research Summary

- OpenAI Agents SDK exposes `agent.as_tool()` for nested specialist agents.
- LangChain documents supervisor agents that invoke named sub-agents through
  tools.
- A2A-style protocols are useful when agents run across process or service
  boundaries. Hajimi keeps the current implementation in-process and maps cleanly
  to A2A concepts later: task input, agent name, model, result artifact, trace id.
- Swarm/team runtimes are useful for peer coordination. Hajimi's current team
  layer keeps that local and explicit through persistent in-process teammates,
  while subagents keep one-shot supervisor delegation depth-limited.

Detailed evaluation, protocol notes, lifecycle, and test matrix:

- [Sub-agent evaluation](multi-agent/2026-05-15_subagent_evaluation.md)
- [Routed runtime plan](multi-agent/2026-05-15_13-19_routed_runtime_plan.md)
- [Completion audit](multi-agent/2026-05-15_completion_audit.md)
- [Mermaid flow](multi-agent/flow.mmd)
- [Routed runtime flow](multi-agent/routed-runtime-flow.mmd)

## Config

```toml
[agent.subagents]
enabled = true
max_depth = 2
tool_name = "delegate"
max_tool_rounds = 3

[agent.routing]
enabled = true
strategy = "auto"
simple_max_words = 80
simple_max_tool_markers = 0
default_mode = "auto"
default_profiles = ["planner", "math", "reviewer"]
default_replicas = 2
planner_profile = "planner"
synthesizer_profile = "reviewer"
max_parallel_agents = 4
max_budget_tokens = 12000

[agent.teammates]
enabled = true
max_members = 4
spawn_tool_name = "team_spawn"
send_tool_name = "team_send"
broadcast_tool_name = "team_broadcast"
list_tool_name = "team_list"
close_tool_name = "team_close"
max_tool_rounds = 3

[agent.profile.math]
model_name = "deepseek_flash_child"
system_prompt = "Use calculator tools for exact arithmetic."
max_tool_rounds = 3
skills = ["calculator"]
mcp_servers = []
tool_names = ["multiply_numbers"]
```

## Protocol

Hajimi supports two multi-agent modes:

| Mode | Lifecycle | Communication | Best for |
| --- | --- | --- | --- |
| Subagent | One tool call creates, runs, returns, and destroys a child agent | Child returns only to caller | Focused delegation where only the result matters |
| Teammate | Persistent in-process agent kept in a team registry | Lead and teammates can send messages to teammates | Collaboration where agents need follow-up context or direct discussion |

## Routed Runtime

`AgentRuntime` adds a high-level routing layer above the low-level primitives.
Normal applications can call `runtime.ask(question)` and let Hajimi choose a
route. Advanced applications can call `runtime.run_task(...,
options=RunOptions(...))` to force `single`, `subagents`, or `replicas`, choose
profiles, cap budget, and capture session plus trace metadata.

```python
from hajimi import AgentRuntime, RunOptions, load_config

config = await load_config("examples/configs/configs.toml")
runtime = await AgentRuntime.from_config(config)

answer = await runtime.ask("用一句话解释 Hajimi。")

result = await runtime.run_task(
    "比较两种架构方案并给出推荐。",
    options=RunOptions(
        mode="subagents",
        profiles=["planner", "reviewer"],
        max_budget_tokens=4000,
        session_name="architecture-review",
    ),
)
print(result.content)
print(result.plan.to_dict())
print(result.session_id)
```

Route modes:

| Mode | Behavior |
| --- | --- |
| `single` | Run the root agent once, with `AgentSession` when enabled |
| `subagents` | Run one worker per configured profile, then synthesize outputs |
| `replicas` | Run independent root-agent replicas in parallel, then synthesize outputs |
| `auto` | Use a deterministic heuristic: small prompts use `single`; complex prompts use configured profiles or replicas |

When sessions are enabled, routed multi-agent runs append a `runtime.route`
event with the route plan, worker outputs, and final content. The JSONL trace
continues to record model, tool, and runtime spans.

## Subagent Protocol

The built-in subagent tool accepts:

```json
{
  "name": "researcher",
  "profile": "math",
  "task": "Summarize this input.",
  "model_name": "deepseek_flash_child",
  "system_prompt": "Optional child instructions.",
  "max_tool_rounds": 3,
  "skills": ["calculator"],
  "mcp_servers": [],
  "tool_names": ["multiply_numbers"]
}
```

It returns:

```json
{
  "name": "researcher",
  "model_name": "deepseek_flash_child",
  "depth": 1,
  "content": "child result"
}
```

`max_depth` prevents recursive agent creation loops. A root agent starts at
depth `0`; the first child runs at depth `1`. When the next depth would exceed
`max_depth`, the tool raises an error and the trace records the failed span.

`profile` is the stable way to create specialized agents. A profile can set the
default child model, prompt, skills, MCP servers, and tool allow-list. Request
fields override profile fields for one call. This keeps planner, math, reviewer,
or MCP-backed agents from accidentally sharing tools.

Unknown agents can be created dynamically without a predefined profile:

```json
{
  "name": "dynamic_math",
  "task": "Find a tool for multiplying 8 and 9, then return the result.",
  "skills": ["math_skill"],
  "mcp_servers": [],
  "tool_names": null
}
```

With `[agent.tool_search] enabled`, that child initially sees `find_tools`.
After searching for "multiply two integers", the matching hidden tool is loaded
into the child agent and can be called in the next round.

## Teammate Protocol

Teammates are created with `team_spawn` and stay active until `team_close`.

```json
{
  "name": "architect",
  "profile": "planner",
  "prompt": "Review the API design and ask reviewer for risk checks."
}
```

Send a direct message:

```json
{
  "name": "reviewer",
  "message": "Please check the auth risk.",
  "sender": "architect"
}
```

Available team tools:

- `team_spawn`: lead-only lifecycle tool.
- `team_send`: lead and teammates can send to one teammate.
- `team_broadcast`: lead and teammates can send to all active teammates.
- `team_list`: inspect names, status, and message counts.
- `team_close`: lead-only lifecycle tool.

Current teammate implementation is in-process and intentionally small. It
supports independent message histories, direct teammate messaging, lifecycle
traces, profile/model/tool scoping, progressive skills, and MCP tools. Persistent
team storage, lock-backed shared task lists, wait semantics, and split-pane UI
are extension points.

Teammate tool scope is split by role. The lead agent receives lifecycle tools
(`team_spawn` and `team_close`) plus message tools. Teammates receive
message/list tools so they can collaborate with active teammates without
spawning or closing team members.

## Dynamic Tool Search

Hajimi follows the same high-level pattern as Codex-style deferred tools:

1. Build a catalog from selected skill tools and MCP tools.
2. Index tool name, description, and parameter names.
3. Expose only `find_tools` and always-visible control tools first.
4. Rank catalog matches with BM25.
5. Register matched tools into the current agent registry.
6. Let the model call the loaded tool in the next round.

This keeps prompt size bounded when hundreds of tools exist, while still making
tools discoverable by task text. Repeated searches can return the same matches;
`find_tools` reports newly registered tools separately from already-present
tools.

Progressive skills use a second deferred-loading path. The system prompt lists
available skills, `load_skill` loads full skill instructions and tools, and
then regular tool dispatch handles the loaded skill tools.

## Team Scenario

The tested coordination pattern is:

1. Parent creates `planner` with a planner profile.
2. Parent passes the planner output into `math_worker`.
3. `math_worker` uses only its math skill tool.
4. Parent passes math output into `reviewer`.
5. `reviewer` uses only its MCP review tool.
6. Parent returns the final coordinated result.

The regression test is:

```bash
uv run pytest tests/test_subagent.py::test_multiple_subagents_exchange_context_with_isolated_capabilities -q
uv run pytest tests/test_subagent.py::test_dynamic_subagent_searches_and_loads_own_tools -q
uv run pytest tests/test_tool_search.py -q
uv run pytest tests/test_team.py -q
```

## Trace

Sub-agent runs are traced with create/output/destroy events:

```bash
jq -r 'select(.name == "agent.subagent") | [.attributes["agent.subagent.name"], .attributes["agent.subagent.depth"], .status] | @tsv' logs/traces.jsonl
jq -r 'select(.name == "agent.subagent") | .events[].name' logs/traces.jsonl
jq -r 'select(.name == "agent.subagent") | [.attributes["agent.subagent.name"], .attributes["agent.subagent.profile"], ((.attributes["agent.subagent.skills"] // []) | join(",")), ((.attributes["agent.subagent.mcp_servers"] // []) | join(",")), ((.attributes["agent.subagent.tool_names"] // []) | join(","))] | @tsv' logs/traces.jsonl
```

The parent `agent.run`, `agent.subagent`, child `agent.run`, and child LLM spans
share one `trace_id`, so the whole parent-child exchange can be reconstructed
from `logs/traces.jsonl`.

## Example

```bash
uv run python examples/routed_runtime.py
```
