# Configuration

Hajimi reads runtime settings from a TOML file and provider secrets from `.env`.
The default example lives at `examples/configs/configs.toml`.

## Environment

Copy the example environment file:

```bash
cp examples/configs/.env.example examples/configs/.env
```

Set provider credentials in `.env`:

```dotenv
DEEPSEEK_API_KEY=your_deepseek_apikey
DEEPSEEK_BASE_URL=https://api.deepseek.com
```

Empty `api_key` and `base_url` values in TOML are read from `.env` using
`{PROVIDER}_API_KEY`, `{PROVIDER}_BASE_URL`, or `{PROVIDER}_API_BASE`.

## Model

```toml
[model.deepseek_flash]
provider = "deepseek"
model = "deepseek-v4-flash"
api_key = ""
base_url = ""
temperature = 0.2
max_tokens = 1024
```

## Agent

```toml
[agent]
name = "hajimi"
default_model = "deepseek_flash"
system_prompt = "You are Hajimi, a concise and helpful async agent."
max_tool_rounds = 4
skills = ["calculator"]

[agent.skill_loading]
progressive = true
activation_tool_name = "load_skill"
script_tool_name = "run_skill_script"
sandbox_stage_path = ".hajimi/skill-runs"
max_resources = 200
auto_discover = true
discovery_dirs = ["skills", ".agents/skills", ".claude/skills"]
```

With progressive skill loading enabled, `build_agent()` reads configured and
discovered skill metadata and adds it to the system prompt as an
`<available_skills>` catalog. Full `SKILL.md` instructions, resource listings,
and skill tools are loaded only after the model calls `load_skill`.
`run_skill_script` executes activated skill scripts inside the same sandbox used
by workspace tools. Set `progressive = false` to load configured skill
instructions and Python tools during agent construction.

Named profiles define stable specialized child agents:

```toml
[agent.profile.math]
model_name = "deepseek_flash_child"
system_prompt = "Use calculator tools for exact arithmetic."
skills = ["calculator"]
mcp_servers = []
tool_names = ["multiply_numbers"]
```

`delegate` can reference a profile by name. The profile controls the
child model, prompt, skills, MCP servers, and allowed tools. Request fields can
override profile fields for a single call.

Persistent teammates use the same profiles and tool scoping:

```toml
[agent.teammates]
enabled = true
max_members = 4
spawn_tool_name = "team_spawn"
send_tool_name = "team_send"
broadcast_tool_name = "team_broadcast"
list_tool_name = "team_list"
close_tool_name = "team_close"
max_tool_rounds = 3
```

Dynamic tool search keeps large tool catalogs out of the initial model context:

```toml
[agent.tool_search]
enabled = true
tool_name = "find_tools"
max_results = 8
defer_tools = true
```

When `defer_tools = true`, skill and MCP tools are hidden at first. The agent
sees `find_tools`; matching tools are loaded into the current agent after a
search result, then can be called in the next round. Repeated searches are
allowed; the result separates tools newly added in `loaded` from tools already
present in `already_loaded`.

Subagent, teammate, and extra tools remain visible even when searchable skill
and MCP tools are deferred.

Built-in workspace tools provide the core file and command workflow used by
coding agents:

```toml
[agent.workspace_tools]
enabled = true
sandbox_provider = "e2b" # e2b or local
root = "/home/user" # E2B absolute root; local must stay under repo_path
allow_write = false
allow_shell = false
max_read_chars = 20000
max_output_chars = 12000
max_search_results = 100
allowed_shell_commands = ["python", "git"]
e2b_sandbox_id = "" # optional existing sandbox
e2b_template = "" # optional E2B template
e2b_timeout = 300
e2b_allow_internet_access = true
```

`read`, `grep`, and `glob` are visible by default and resolve paths under the
workspace root. `write`, `edit`, and `bash` appear only when `allow_write` or
`allow_shell` is enabled. Shell commands are parsed with `shlex`, run with
`cwd` set to the workspace root, and can be restricted with
`allowed_shell_commands`.

These tools run through the `SandboxEnvironment` interface. The default E2B
sandbox requires the optional `sandbox-e2b` dependency and an E2B API key in the
environment. Set `sandbox_provider = "local"` for offline development; local
mode keeps paths under `repo_path` and uses the configured workspace root.
Custom adapters can provide the same `stat`, `read_text`, `read_bytes`,
`write_text`, `write_bytes`, `list_dir`, `iter_files`, and `exec` methods for
another remote or container sandbox.

Install E2B support with:

```bash
uv sync --extra sandbox-e2b
```

High-level routing defaults control `AgentRuntime.ask()` and
`AgentRuntime.run_task()`:

```toml
[agent.routing]
enabled = true
strategy = "auto"
simple_max_words = 80
simple_max_tool_markers = 0
default_mode = "auto"
default_profiles = ["planner", "math", "reviewer"]
default_replicas = 2
planner_profile = "planner"
synthesizer_profile = "reviewer"
max_parallel_agents = 4
max_budget_tokens = 12000
```

`default_mode = "auto"` chooses `single` for small prompts, `subagents` when
profiles are configured, and `replicas` as the generic complex fallback.
Advanced callers can override these values per call with `RunOptions`.

## Logging

```toml
[log]
directory = "logs"
file_name = "hajimi.jsonl"
console_level = "INFO"
file_level = "DEBUG"
rotation = "10 MB"
retention = "14 days"
enable_file = true
enable_console = true
serialize_file = true
```

Relative log directories resolve from the repository root. File logs are JSON
Lines by default:

```bash
jq -r '.record.time.repr + " " + .record.level.name + " " + .record.message' logs/hajimi.jsonl
```

## Context And Sessions

```toml
[context]
enabled = true
store_dir = "sessions"
database_url = "" # optional SQLAlchemy URL; empty uses local SQLite
sqlite_file = "sessions.sqlite"
events_dir = "sessions/events"
auto_compact = true
compact_threshold = 0.70
max_context_tokens = 12000
protected_head_messages = 2
protected_tail_turns = 6
tool_output_max_chars = 2000
summary_model = "deepseek_flash_child"
tokenizer = "heuristic"

[context.cache]
enabled = true
hash_components = true
record_provider_cache = true
```

`AgentSession` stores replayable JSONL events under `sessions/events/` and
metadata/event indexes through SQLAlchemy ORM. Empty `database_url` uses local
SQLite at `sessions/sessions.sqlite`. See [Context](context/index.md) for edit,
delete, restore, fork, compaction, and token accounting usage.
`database_url` affects only the ORM database; event logs still follow
`events_dir`.
`record_provider_cache = false` filters `cache_read_tokens` and
`cache_write_tokens` out of stored provider usage reports.

## Basic Agent

```python
import anyio

from hajimi import AnyLLMClient, TextDelta, build_agent, load_config, setup_observability, user_message
from hajimi.logging import configure_logging


async def main() -> None:
    config = await load_config("examples/configs/configs.toml")
    await configure_logging(config.log, config.repo_path)
    tracer = await setup_observability(config.observability, config.repo_path)

    client = AnyLLMClient(config.model(), tracer=tracer)
    built = await build_agent(config, client=client, tracer=tracer)
    result = await built.agent.run([user_message("用一句话介绍 Hajimi。")])
    print(result.content)

    async with built.agent.run_stream([user_message("继续，用一句话说明 corekit。")]) as stream:
        async for event in stream:
            if isinstance(event, TextDelta):
                print(event.chunk, end="")


anyio.run(main)
```

## Routed Runtime

```python
import anyio

from hajimi import AgentRuntime, RunOptions, load_config


async def main() -> None:
    config = await load_config("examples/configs/configs.toml")
    runtime = await AgentRuntime.from_config(config)

    answer = await runtime.ask("用一句话介绍 Hajimi。")
    print(answer)

    result = await runtime.run_task(
        "让 planner 和 reviewer 比较两个方案。",
        options=RunOptions(mode="subagents", profiles=["planner", "reviewer"]),
    )
    print(result.plan.to_dict())
    print(result.content)


anyio.run(main)
```

## Related Docs

- [Observability](observability.md)
- [Context](context/index.md)
- [Skills](skills.md)
- [MCP](mcp.md)
- [Multi-agent](multi-agent.md)
