# Research Notes

## Multi-agent Patterns

Hajimi currently implements agent-as-tool first.

Why this pattern:

- OpenAI Agents SDK exposes `agent.as_tool()` for specialist agents. The parent
  agent keeps control and receives a normal tool result.
- LangChain documents the same supervisor pattern: a named supervisor delegates
  bounded work to named sub-agents through tools.
- A2A-style protocols are better for cross-process or cross-service agent
  collaboration. Hajimi's in-process protocol keeps the same core fields: task,
  agent name, model, result artifact, trace id.
- Swarm/team runtimes add peer routing, shared state, and scheduling. They are
  useful later, after the single-process protocol is stable.

Current implementation:

- `delegate` is a normal tool.
- The request is JSON-compatible: `name`, `task`, optional `model_name`,
  optional `profile`, optional `system_prompt`, optional `max_tool_rounds`,
  optional `skills`, optional `mcp_servers`, and optional `tool_names`.
- The response is JSON-compatible: `name`, `model_name`, `depth`, `content`.
- `max_depth` blocks recursive runaway creation.
- Parent and child spans share one `trace_id`.
- Profiles provide stable child defaults for model, prompt, skills, MCP
  servers, tool allow-lists, and tool-round limits. Request fields override the
  profile for one call.
- Teammates extend the same in-process runtime with persistent per-member
  message history and lead/member messaging tools.
- Tool search keeps large skill and MCP tool catalogs hidden until a model
  calls `find_tools`, while progressive skills use `load_skill` to load
  full skill instructions and tools on demand.

## Workspace Tooling

`withastro/flue` exposes a compact coding-agent tool set around `read`, `write`,
`edit`, `grep`, `glob`, `bash`, and `task`, backed by sandbox abstractions for
virtual, local, or container execution. Hajimi already covers `task`-style
delegation through `delegate` and persistent teammates, plus MCP for external
tool sources.

The missing local capability was first-party workspace interaction. Hajimi adds
repo-root-scoped `read`, `grep`, and `glob` tools by default, with `write`,
`edit`, and `bash` exposed only through explicit `[agent.workspace_tools]`
settings.

Sandbox research points to a narrow adapter shape. Flue's `SessionEnv` centers
on file metadata, file reads/writes, directory listing, path iteration, and
command execution. Python options map cleanly onto that boundary. E2B exposes
`Sandbox.files` and `Sandbox.commands` surfaces that directly match this shape.
Modal and Daytona provide container command plus filesystem APIs that fit the
same contract but carry more platform-specific lifecycle and image/resource
configuration. SandboxAI exposes `run_ipython_cell` and `run_shell_command`;
CodeJail/RestrictedPython are Python-execution sandboxes with narrower fit for
general coding agents.

Hajimi follows the Flue shape with `SandboxEnvironment`: `stat`, `read_text`,
`write_text`, `list_dir`, `iter_files`, and `exec`. The default provider is E2B
because its Python SDK maps most directly to the interface and is designed for
agent/code-interpreter workloads. `LocalSandboxEnvironment` remains available
for offline development and deterministic tests. Remote or container adapters
can plug into the same workspace tools without changing model-visible schemas.

Minimal Modal adapter sketch:

```python
class ModalSandboxEnvironment:
    def __init__(self, sandbox):
        self.sandbox = sandbox

    async def read_text(self, path: str) -> str:
        return await anyio.to_thread.run_sync(lambda: self.sandbox.filesystem.read_text(path))

    async def write_text(self, path: str, content: str) -> None:
        await anyio.to_thread.run_sync(lambda: self.sandbox.filesystem.write_text(path, content))

    async def exec(self, command: str, timeout_seconds: float) -> SandboxExecResult:
        process = await anyio.to_thread.run_sync(lambda: self.sandbox.exec("bash", "-lc", command, timeout=timeout_seconds))
        await anyio.to_thread.run_sync(process.wait)
        stdout = await anyio.to_thread.run_sync(process.stdout.read)
        stderr = await anyio.to_thread.run_sync(process.stderr.read)
        return SandboxExecResult(process.returncode, stdout, stderr)
```

Minimal Daytona adapter sketch:

```python
class DaytonaSandboxEnvironment:
    def __init__(self, sandbox):
        self.sandbox = sandbox

    async def read_text(self, path: str) -> str:
        return await anyio.to_thread.run_sync(lambda: self.sandbox.fs.download_file(path).decode("utf-8"))

    async def write_text(self, path: str, content: str) -> None:
        await anyio.to_thread.run_sync(lambda: self.sandbox.fs.upload_file(content.encode("utf-8"), path))

    async def exec(self, command: str, timeout_seconds: float) -> SandboxExecResult:
        result = await anyio.to_thread.run_sync(lambda: self.sandbox.process.exec(command, timeout=timeout_seconds))
        stdout = result.artifacts.stdout if result.artifacts else result.result
        return SandboxExecResult(result.exit_code, stdout, "")
```

## MCP

The official MCP Python SDK provides anyio-compatible transport context
managers. The minimal flow is:

1. Open a transport such as `stdio_client()` or `streamable_http_client()`.
2. Create `ClientSession(read_stream, write_stream)`.
3. Call `initialize()`.
4. Call `list_tools()` and `call_tool()`.

Hajimi wraps MCP tools into the same `Tool` abstraction used by skills.

## Observability

Hajimi stores local JSONL spans first. OpenTelemetry export remains optional.
Langfuse can be connected through OTel or a future custom exporter without
changing the agent/tool APIs.
