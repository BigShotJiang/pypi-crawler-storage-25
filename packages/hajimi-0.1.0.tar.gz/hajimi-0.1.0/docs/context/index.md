# Context And Sessions

Hajimi keeps the core `Agent` small. Durable history, context building,
edit markers, forks, compaction, and token reports live in `AgentSession`.

## Configuration

```toml
[context]
enabled = true
store_dir = "sessions"
database_url = "" # optional SQLAlchemy URL; empty uses local SQLite
sqlite_file = "sessions.sqlite"
events_dir = "sessions/events"
auto_compact = true
compact_threshold = 0.70
max_context_tokens = 12000
protected_head_messages = 2
protected_tail_turns = 6
tool_output_max_chars = 2000
summary_model = "deepseek_flash_child"
tokenizer = "heuristic"

[context.cache]
enabled = true
hash_components = true
record_provider_cache = true
```

Relative paths resolve from the repository root. The default layout is:

- `sessions/sessions.sqlite`: default local SQLAlchemy ORM database.
- `sessions/events/<session_id>.jsonl`: append-only replay log.

The database layer uses SQLAlchemy ORM models behind the async `SessionStore`
API. Local SQLite is the default. `database_url` can point at another SQLAlchemy
database URL later, while JSONL events remain the replayable source of truth.
SQLite-specific retrieval features such as FTS5 and `sqlite-vec` should live as
optional indexes behind this same store boundary.
`database_url` changes the ORM database only; JSONL event files still use
`events_dir`.
`record_provider_cache = false` keeps provider totals while omitting
`cache_read_tokens` and `cache_write_tokens` from stored token usage events.

## Usage

```python
import anyio

from hajimi import (
    AgentSession,
    AnyLLMClient,
    build_agent,
    create_session_store,
    load_config,
    setup_observability,
)


async def main() -> None:
    config = await load_config("examples/configs/configs.toml")
    tracer = await setup_observability(config.observability, config.repo_path)
    client = AnyLLMClient(config.model(), tracer=tracer)
    built = await build_agent(config, client=client, tracer=tracer)

    store = create_session_store(config.context, config.repo_path)
    session = await AgentSession.create(
        agent=built.agent,
        store=store,
        name="research-session",
        model_name=config.model().name,
        context_settings=config.context,
    )

    result = await session.run("分析一下当前任务。")
    print(result.content)

    async for event in session.stream("继续，用简短 bullet 输出。"):
        print(event.text, end="")


anyio.run(main)
```

## Replay Semantics

History changes are event markers:

- `message.appended`: add a visible message.
- `message.edited`: replace a visible message with a new record.
- `message.deleted`: hide a message.
- `session.restored`: unhide a known message.
- `session.rollback`: keep messages up to a chosen message.
- `session.forked`: create a child session and copy visible history.
- `context.compacted`: add a summary and keep protected head and tail messages.

This keeps the original event stream auditable and makes rollback/fork cheap to
reason about.

## Token Accounting

`token_report()` estimates component tokens for:

- system prompt
- visible messages
- tool schemas
- compacted summary
- provider usage when the raw response includes usage fields

The default tokenizer is dependency-free `heuristic`. It is deterministic and
intended for thresholds and reports. Provider usage remains authoritative when
available.

## Compaction

When estimated tokens exceed `max_context_tokens * compact_threshold`,
`ContextManager` builds a compacted context:

- preserve the first `protected_head_messages`
- preserve the last `protected_tail_turns * 2` messages
- summarize the middle
- truncate oversized tool outputs to `tool_output_max_chars`

The default summary is local and deterministic. A future production path can
inject an async summarizer backed by `AnyLLMClient` and `summary_model`.
