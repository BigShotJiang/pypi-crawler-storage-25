# Session Context Implementation Plan

## Goal

Add durable, replayable context management outside `Agent` while keeping the
agent loop small and easy to extend.

## Scope

- Add `AgentSession` as the API boundary for durable conversations.
- Store session metadata and event indexes through SQLAlchemy ORM, with local
  SQLite as the default database.
- Store complete append-only events in JSONL.
- Support edit, delete, restore, rollback, fork, compaction, and token reports.
- Keep all public operations async and use `anyio` for file and thread work.

## Assumptions

- `Agent` remains the execution primitive for model and tool calls.
- JSONL is the auditable source of truth; SQLAlchemy ORM stores the database
  index and metadata, with SQLite as the default local database.
- The default tokenizer is local and heuristic until a tokenizer dependency is
  explicitly added.
- Default compaction uses deterministic local summaries; production summarizers
  can be injected through the `ContextManager` interface.

## Risks

- Heuristic token counts differ from provider tokenization.
- The current stream path follows existing `Agent.stream` behavior and
  does not add a streaming tool loop.
- Logical deletion preserves event data on disk by design.

## Steps

1. Add `[context]` and `[context.cache]` config models and TOML parsing.
2. Add `hajimi.session` models for message parts, records, metadata, and token
   usage.
3. Add `SessionStore` with JSONL event logs and SQLAlchemy ORM indexes.
4. Add `ContextManager` with summary plus protected head/tail compaction.
5. Add `AgentSession` wrapper around `Agent`.
6. Add async pytest coverage for run, stream, edit/delete/restore, rollback,
   fork, compaction, and token accounting.
7. Document configuration, event semantics, and usage.

## Validation

- `uv run pytest tests/test_config.py tests/test_session.py -q`
- `uv run pytest -q`
- `rg -n "\basyncio\b" src tests examples docs README.md pyproject.toml`

## Rollback

Remove the `hajimi.session` package, `[context]` config additions, docs under
`docs/context/`, and session exports from `hajimi.__init__` / `hajimi.core`.
