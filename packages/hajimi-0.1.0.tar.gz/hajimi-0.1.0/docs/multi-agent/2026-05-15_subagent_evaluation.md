# Sub-agent Evaluation

Date: 2026-05-15

## Goal

Evaluate and implement the first multi-agent layer for Hajimi:

- Parent agents can create focused child agents through a normal tool call.
- Child agents have names, optional model overrides, optional prompt overrides,
  optional profile overrides, scoped skills, scoped MCP servers, scoped tools,
  and bounded tool rounds.
- Persistent teammates can be spawned in-process and keep their own message
  history across follow-up messages.
- Recursive creation is depth-limited.
- Parent, tool, child-agent, and child-LLM spans share one trace id.
- Creation, output, and destruction are recorded as structured trace events.
- The implementation stays async-first, uses anyio for concurrency, and avoids
  direct asyncio calls in project code.

## Research Inputs

- any-llm: Context7 for `/mozilla-ai/any-llm` confirms async direct APIs:
  `acompletion`, `aembedding`, and `aresponses`. Streaming completion returns an
  async iterator when `stream=True`.
- LangChain multi-agent docs: supervisor agents can wrap sub-agents as tools;
  the supervisor sends a bounded request and receives either text or structured
  JSON data.
- OpenAI Agents SDK pattern: agents can be exposed as callable tools for
  specialist delegation; this keeps the parent in control of routing.
- Google A2A protocol: useful for cross-process agents through agent metadata,
  task/message/artifact concepts, and asynchronous task state. Hajimi maps to
  those fields but keeps the first version in-process.
- Codex-style delegation: mature agent systems separate lifecycle control,
  tool invocation, status tracking, and event emission. Hajimi keeps these as
  small local modules: builder, subagent tool, dispatcher, tracer.
- MCP Python SDK: tools are loaded through transport/session boundaries and then
  normalized into the same local `Tool` abstraction.

Reference links:

- OpenAI Agents SDK tools: https://openai.github.io/openai-agents-python/tools/
- LangChain subagents: https://docs.langchain.com/oss/python/langchain/multi-agent/subagents
- A2A specification: https://google-a2a.github.io/A2A/specification/
- A2A core concepts: https://agent2agent.info/docs/concepts/
- MCP SDKs: https://modelcontextprotocol.io/docs/sdk
- MCP Python stdio client example: https://github.com/modelcontextprotocol/python-sdk/blob/main/examples/snippets/clients/stdio_client.py

## Options Evaluated

| Option | Strength | Cost | Decision |
| --- | --- | --- | --- |
| Agent-as-tool supervisor | Simple control flow, easy tracing, works with current tool loop | Child agents are not peers | Implemented first |
| Handoff/routing graph | Good for user-facing specialist transfer | More state and routing policy | Later |
| In-process teammate runtime | Useful for explicit peer collaboration with follow-up context | More lifecycle and message tools | Implemented in small form |
| Distributed swarm runtime | Useful for peer collaboration and voting across workers | Scheduler, shared memory, conflict handling | Later |
| A2A service protocol | Best for remote/cross-process agents | Network protocol, auth, task persistence | Future adapter |
| MCP-only agents | Reuses remote tool protocol | MCP is tool-centric, not enough lifecycle semantics | Keep MCP as tool source |

The current implementation uses supervisor control because it covers the first
real need with the smallest reliable surface. The request and response are
structured enough to become an A2A or remote-run payload later.

## Implemented Protocol

Tool name defaults to `delegate`.

Request:

```json
{
  "name": "math_child",
  "profile": "math",
  "task": "Return exactly: child-ok: 17+25=42",
  "model_name": "deepseek_flash_child",
  "system_prompt": "Optional child instructions.",
  "max_tool_rounds": 3,
  "skills": ["calculator"],
  "mcp_servers": [],
  "tool_names": ["multiply_numbers"]
}
```

Response:

```json
{
  "name": "math_child",
  "model_name": "deepseek_flash_child",
  "depth": 1,
  "content": "child-ok: 17+25=42"
}
```

Data transfer is intentionally narrow:

- Parent sends the delegated `task`, child `name`, optional `profile`, optional
  `model_name`, optional `system_prompt`, optional `max_tool_rounds`, optional
  `skills`, optional `mcp_servers`, and optional `tool_names`.
- Child receives a fresh agent context plus configured skills, MCP tools, tool
  allow-list, progressive skill activation, dynamic tool search, and depth
  controls for that run.
- Parent receives structured JSON-compatible output from the tool dispatcher.
- Trace context is inherited through `contextvars`, so spans share `trace_id`.

## Lifecycle

1. Parent model calls `delegate`.
2. `ToolDispatcher` records `tool.call`.
3. `delegate` validates depth and resolves the child profile, model, and
   tool scope.
4. `agent.subagent` span starts.
5. `agent.subagent.create` event records name, model, and depth.
6. Child config is derived from parent config with name/model/prompt/tool-scope
   overrides.
7. Child agent is built through `build_agent(..., depth=next_depth)`.
8. Child agent runs the task and records normal `agent.run` and LLM spans.
9. `agent.subagent.output` records the final aggregated child output.
10. `agent.subagent.destroy` is recorded in `finally`.

## Trace Shape

```mermaid
flowchart TD
    U[User prompt] --> P[Parent agent.run]
    P --> L1[Parent llm.completion]
    P --> T[tool.call: delegate]
    T --> S[agent.subagent]
    S --> C[agent.subagent.create]
    S --> R[Child agent.run]
    R --> L2[Child llm.completion]
    S --> O[agent.subagent.output]
    S --> D[agent.subagent.destroy]
    S --> T
    T --> P
```

All nodes in one parent-child run share the same `trace_id`. Parent-child edges
are represented by `parent_span_id`.

## Test Matrix

| Requirement | Evidence |
| --- | --- |
| Async direct completion | `tests/test_llm_client.py::test_complete_uses_async_direct_api` |
| Streaming completion | `tests/test_llm_client.py::test_stream_complete_yields_text_deltas` |
| Embedding and responses APIs | `tests/test_llm_client.py::test_embedding_and_responses_wrappers` |
| Agent tool loop | `tests/test_agent.py::test_agent_dispatches_tool_call` |
| Stream trace aggregated after completion | `tests/test_observability.py::test_stream_records_one_output_event_after_completion` |
| Tool calls traced | `tests/test_observability.py::test_tool_calls_are_recorded_as_events_and_spans` |
| Content redaction switch | `tests/test_observability.py::test_content_can_be_disabled` |
| Sub-agent protocol and model override | `tests/test_subagent.py::test_subagent_tool_runs_child_with_name_model_and_protocol` |
| Sub-agent create/output/destroy events | `tests/test_subagent.py::test_subagent_tool_runs_child_with_name_model_and_protocol` |
| Sub-agent trace parent linkage | `tests/test_subagent.py::test_subagent_tool_runs_child_with_name_model_and_protocol` |
| Recursive depth limit | `tests/test_subagent.py::test_subagent_depth_limit_blocks_creation` |
| Builder hides tool at max depth | `tests/test_subagent.py::test_build_agent_adds_subagent_tool_until_max_depth` |
| Profile-scoped multi-agent flow | `tests/test_subagent.py::test_multiple_subagents_exchange_context_with_isolated_capabilities` |
| Dynamic tool search in child agents | `tests/test_subagent.py::test_dynamic_subagent_searches_and_loads_own_tools` |
| Persistent teammate messaging | `tests/test_team.py::test_teammates_are_persistent_and_can_message_each_other` |
| Real DeepSeek flow | `examples/routed_runtime.py` |

## Real API Smoke

Run with local credentials in `devs/configs/.env`:

```bash
uv run python examples/routed_runtime.py
```

Expected behavior:

- Parent uses `delegate` exactly once.
- Child name is `math_child`.
- Child model key is `deepseek_flash_child`.
- Final visible output contains the child calculation result.
- `logs/traces.jsonl` includes `agent.subagent.create`,
  `agent.subagent.output`, and `agent.subagent.destroy`.

Useful trace checks:

```bash
jq -r 'select(.name == "agent.subagent") | [.trace_id, .attributes["agent.subagent.name"], .attributes["agent.subagent.depth"], .attributes["agent.subagent.model_name"], .status] | @tsv' logs/traces.jsonl
jq -r 'select(.name == "agent.subagent") | .events[].name' logs/traces.jsonl
jq -r 'select(.name == "tool.call") | [.attributes["tool.name"], .status] | @tsv' logs/traces.jsonl
```

## Teammate Layer

Persistent teammates are implemented in `TeamCoordinator`. The lead receives
spawn/send/broadcast/list/close tools. Teammates receive send/broadcast/list
tools, keep independent message history, and use the same profile/model/skill/
MCP/tool scoping as subagents.

## Remaining Extension Points

- Add remote A2A adapter when agents run across processes or machines.
- Add distributed team/swarm scheduler if collaboration needs workers outside
  the current process.
- Add Langfuse native exporter if OTel is insufficient for prompt/version
  dashboards.
