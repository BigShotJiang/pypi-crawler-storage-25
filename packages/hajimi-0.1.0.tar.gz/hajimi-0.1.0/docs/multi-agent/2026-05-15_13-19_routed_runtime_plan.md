# Routed Runtime Plan

## Goal

Expose Hajimi as a general agent framework with two clear layers:

- Normal users call one high-level API with a question and receive an answer.
- Advanced users control routing mode, profiles, replicas, budget limits,
  sessions, tracing, and replay metadata.

The runtime should reuse the existing async `Agent`, `AgentSession`,
subagent, teammate, skill, MCP, and tracing layers instead of replacing them.

## Scope

- Add `AgentRuntime` as a facade for routed task execution.
- Add `RunOptions`, `RoutePlan`, `RuntimeResult`, and `WorkerResult`.
- Add `[agent.routing]` defaults to configuration.
- Support deterministic route choices: `single`, `subagents`, `replicas`,
  and `auto`.
- Persist high-level route metadata for replay when sessions are enabled.
- Document normal and advanced usage.

This slice does not add a distributed A2A adapter, a graph compiler, vector
memory, or a visual UI.

## Reference Patterns

| Framework | Transferable pattern | Hajimi mapping |
| --- | --- | --- |
| AutoGen | High-level teams plus lower-level routed agents and serialized components | `AgentRuntime` facade over low-level `Agent` and config profiles |
| LangGraph | State routing, parallel sends, checkpoints, replay, and subgraphs | Deterministic `RoutePlan`, parallel replicas, `AgentSession` JSONL replay |
| CrewAI | Simple crew kickoff with sequential or hierarchical process controls | `ask()` for normal users, `RunOptions(mode=...)` for advanced users |
| Hermes Agent | Prompt builder, memory/context injection, iteration budgets, callbacks | Session compaction, token reports, trace spans, budget guard |
| OpenClaw | Session route binding, depth-aware tools, agent-to-agent messages | Profiles, explicit route modes, subagent/team depth and tool scoping |
| ClawTeam | CLI-readable task board, inboxes, isolated workers | Future UI can read `runtime.route` events and worker outputs |
| TradingAgents | Role factories, state handoff, checkpoint resume | Profile-specific workers plus synthesis step |
| Nanobot | Message bus, context builder, hooks, background subagents | Future event bus/hooks can attach around `runtime.run` spans |

Reference links:

- https://github.com/NousResearch/hermes-agent
- https://github.com/openclaw/openclaw
- https://github.com/HKUDS/ClawTeam
- https://github.com/TauricResearch/TradingAgents
- https://github.com/open-multi-agent/open-multi-agent
- https://github.com/HKUDS/nanobot
- https://github.com/microsoft/autogen
- https://github.com/langchain-ai/langgraph
- https://github.com/crewAIInc/crewAI

## Target Flow

See the standalone Mermaid source:
[`routed-runtime-flow.mmd`](routed-runtime-flow.mmd).

```mermaid
flowchart TD
    U[User question] --> R[AgentRuntime.run_task]
    R --> P[RoutePlan]
    P -->|single| A[Root Agent]
    P -->|subagents| W[Profile workers]
    P -->|replicas| N[Replica workers]
    W --> S[Synthesizer agent]
    N --> S
    A --> O[RuntimeResult]
    S --> O
    O --> E[Session JSONL route event]
    O --> T[Trace spans]
```

## API Design

Normal usage:

```python
runtime = await AgentRuntime.from_config(config)
answer = await runtime.ask("Explain this problem.")
```

Advanced usage:

```python
result = await runtime.run_task(
    "Compare two implementation strategies.",
    options=RunOptions(
        mode="subagents",
        profiles=["planner", "reviewer"],
        max_budget_tokens=4000,
        session_name="architecture-review",
    ),
)
```

`RuntimeResult` includes:

- `content`: final answer
- `plan`: resolved `RoutePlan`
- `workers`: profile or replica outputs
- `session_id`: replay handle when session storage is enabled
- `trace_file`: JSONL trace file path
- `token_report`: session token report when available

## UX And Operations

Normal-user UX stays one-call:

- input: a plain question or task string
- output: answer text from `runtime.ask()`
- hidden behavior: route planning, session creation, trace writing, and
  worker synthesis

Advanced-user UX uses `RuntimeResult` as the control and replay surface:

- route inspection: `result.plan.to_dict()`
- cost guard: `RunOptions(max_budget_tokens=...)`
- cost report: `result.token_report`
- replay handle: `result.session_id` and `sessions/events/<session_id>.jsonl`
- worker comparison: `result.workers`
- trace inspection: `result.trace_file`

Prompt and context construction stay separated from routing. `build_agent()`
continues to own system prompts, progressive skills, MCP tools, and dynamic
tool search. `AgentSession` continues to own durable messages, compaction,
forks, rollback, edit/delete/restore markers, and token reports. `AgentRuntime`
only chooses which execution shape to run and records the route.

Agent communication is explicit by route type:

- `single`: no inter-agent communication
- `subagents`: parent-style fan-out to profile workers followed by synthesis
- `replicas`: independent attempts followed by synthesis
- `teammates`: persistent direct/broadcast messaging remains available through
  the lower-level team tools for workflows that need multi-turn collaboration

## Routing Semantics

- `single`: run the root agent once, optionally through `AgentSession`.
- `subagents`: run one worker per profile, then synthesize multiple outputs.
- `replicas`: run N independent root-agent attempts in parallel, then
  synthesize multiple outputs.
- `auto`: choose `single` for small prompts, `subagents` when configured
  profiles exist, and `replicas` as the generic complex fallback.

The first implementation intentionally uses deterministic local heuristics. A
future LLM router can be added behind the same `plan()` boundary.

## Risks

- Heuristic routing can choose too simple a route for short but difficult tasks.
- Replica mode consumes more tokens than single-agent mode.
- Subagent profile quality depends on configured prompts and tool scopes.
- `runtime.route` event stores high-level route metadata but does not yet store
  every worker's full internal trace in the session event stream.

## Validation

- `uv run pytest tests/test_config.py tests/test_runtime.py -q`
- `uv run pytest -q`

## Rollback

Remove `src/hajimi/runtime.py`, `[agent.routing]` parsing/models, runtime
exports, `tests/test_runtime.py`, and this documentation.
