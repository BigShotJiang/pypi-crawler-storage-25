# Completion Audit

Date: 2026-05-15

Objective:

> 充分调研，充分评估试下方法，提示词，充分测试，包括创建销毁，
> 追踪行为，（子）agent之间交流的协议，传输数据等，可以使用真实的
> deepseek api 进行测试。

## Success Criteria

| Criterion | Evidence | Status |
| --- | --- | --- |
| Research mature agent designs | `docs/multi-agent/2026-05-15_subagent_evaluation.md` records any-llm, OpenAI Agents SDK, LangChain supervisor, A2A, Codex-style delegation, and MCP inputs. | Complete |
| Evaluate implementation options | The same evaluation doc compares supervisor agent-as-tool, handoff graph, swarm/team runtime, A2A service protocol, and MCP-only agents. | Complete |
| Define prompts and protocol | `SubAgentRequest` and `SubAgentResponse` define request/response fields; `examples/routed_runtime.py` shows the public routed workflow. | Complete |
| Implement child creation | `create_subagent_tool()` exposes `delegate`; `_run_subagent()` derives child config and runs the child. | Complete |
| Support profile and tool scoping | Profiles carry model, prompt, max rounds, skills, MCP servers, and tool allow-lists; request fields override one call. | Complete |
| Support persistent teammates | `TeamCoordinator` exposes spawn/send/broadcast/list/close tools with per-member message history. | Complete |
| Implement lifecycle destruction trace | `_run_subagent()` emits `agent.subagent.destroy` in `finally`. | Complete |
| Enforce max depth | `_run_subagent()` checks `next_depth > max_depth`; builder stops adding the tool at max depth. | Complete |
| Support child name | `SubAgentRequest.name` becomes child `AgentSettings.name` and trace attribute. | Complete |
| Support different child model | `model_name` resolves through `config.model()` and child `default_model`. | Complete |
| Record tool calls | `ToolDispatcher` records `tool.call`, `tool.input`, and `tool.output`. | Complete |
| Record sub-agent trace events | `agent.subagent.create`, `agent.subagent.output`, and `agent.subagent.destroy` are tested and observed in real traces. | Complete |
| Preserve parent-child trace linkage | `TraceManager` uses contextvars; tests verify child span parent and same trace id. | Complete |
| Avoid per-token stream logging | `stream_complete()` accumulates chunks and emits one `llm.output` after completion. | Complete |
| Use anyio, avoid direct asyncio | `rg -n "\basyncio\b" src tests examples pyproject.toml README.md docs` shows no project-code `asyncio` references; tool dispatch uses `anyio.create_task_group()`. | Complete |
| Test asynchronously | All test functions use `pytest.mark.anyio` for async behavior. | Complete |
| Run unit tests | `uv run pytest -q` returned `37 passed in 1.94s`. | Complete |
| Run real DeepSeek subagent flow | The earlier smoke run returned `child-ok: 17+25=42`; use `uv run python examples/routed_runtime.py` for the maintained public flow. | Complete |
| Verify real trace output | `jq` found `agent.subagent` with child `math_child`, depth `1`, model `deepseek_flash_child`, status `ok`; events included create/output/destroy. | Complete |
| Verify dependency lock | `uv lock --check` exited 0 and resolved 74 packages. | Complete |

## Commands Run

```bash
uv run pytest -q
# 37 passed in 1.94s
```

```bash
uv run python examples/routed_runtime.py
# Runs the maintained routed runtime example with configured profiles.
# trace_file=/Users/wuyong/codes/git/hajimi/logs/traces.jsonl
```

```bash
jq -r 'select(.name == "agent.subagent") | [.trace_id, .span_id, .parent_span_id, .attributes["agent.subagent.name"], .attributes["agent.subagent.depth"], .attributes["agent.subagent.model_name"], .status] | @tsv' logs/traces.jsonl | tail -5
# 5054f33641b848cc83c81dc7822ce824 ... math_child 1 deepseek_flash_child ok
```

```bash
jq -r 'select(.name == "agent.subagent") | .events[].name' logs/traces.jsonl | tail -6
# agent.subagent.create
# agent.subagent.output
# agent.subagent.destroy
```

```bash
rg -n "\basyncio\b" src tests examples pyproject.toml README.md docs
# Only documentation references were found.
```

```bash
uv lock --check
# Resolved 74 packages in 0.58ms
```

## Residual Risks

- A2A and distributed swarm execution remain extension points. The implemented
  runtime covers supervisor-controlled in-process subagents plus persistent
  in-process teammates.
- Real API smoke depends on local `devs/configs/.env` credentials and network
  availability.
