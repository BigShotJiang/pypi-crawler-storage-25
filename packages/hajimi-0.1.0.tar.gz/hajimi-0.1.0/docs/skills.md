# Skills

Skills are local directories with a `SKILL.md`. Hajimi scans configured skills
and, by default, project skill directories such as `skills/` and
`.agents/skills/`. A skill can provide instructions, Python tools, bundled
resources, or sandbox scripts.

```text
skills/calculator/
  SKILL.md
  scripts/
  references/
  tools.py
```

`SKILL.md` may include Agent Skills style frontmatter:

```markdown
---
name: calculator
description: Exact arithmetic helper.
---

Use the calculator tools for exact arithmetic.
```

The `name` and `description` fields form the startup catalog. The Markdown body
becomes the instruction source after activation. Public functions in `tools.py`
are converted into function tools from their signatures and docstrings.

```python
from hajimi.tool import tool


@tool
def multiply_numbers(a: int, b: int) -> int:
    """Multiply two integers and return the exact product."""
    return a * b
```

Use `@tool(name="...", description="...")` when the model-facing name or
description should differ from the Python function name or docstring.

Enable skills from TOML:

```toml
[agent]
skills = ["calculator"]

[agent.skill_loading]
progressive = true
activation_tool_name = "load_skill"
script_tool_name = "run_skill_script"
sandbox_stage_path = ".hajimi/skill-runs"
auto_discover = true
discovery_dirs = ["skills", ".agents/skills", ".claude/skills"]
```

With the default progressive loading mode, `build_agent()` reads each
configured or discovered skill catalog entry and exposes `load_skill`. The
agent sees the catalog in its system prompt, then calls `load_skill` when a task
needs the full `SKILL.md` instructions, tool definitions, or resource listing.
Loaded skill tools are registered in the current agent registry and can be
called in the next tool round.

Set `progressive = false` to load all configured skill instructions into the
initial system prompt and register all skill tools during agent construction.

Skill catalog summaries come from frontmatter `description`, then `SUMMARY.md`,
then the first heading or non-empty line in `SKILL.md`.

Bundled resource files are listed but not eagerly read. `scripts/`,
`references/`, `assets/`, `examples/`, and `templates/` are exposed as resource
paths in the `load_skill` result so the agent can decide what to inspect.

When workspace tools are backed by a sandbox, `load_skill` also registers
`run_skill_script`. The first script call stages the activated skill directory
under `.hajimi/skill-runs/<skill_name>/` inside the same sandbox used by
`read`, `write`, `grep`, `glob`, and `bash`, then runs the script with that
staged skill directory as `cwd`.

```python
await agent.tools.get("run_skill_script").invoke({
    "skill_name": "calculator",
    "script_path": "scripts/solve.py",
    "args": ["input.json"],
    "timeout_seconds": 30,
})
```
