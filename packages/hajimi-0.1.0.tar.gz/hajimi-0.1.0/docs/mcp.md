# MCP

MCP is optional and uses the official Python SDK through anyio-compatible
transport context managers. Hajimi code does not call `asyncio` directly.

Install it only when needed:

```bash
uv sync --extra mcp
```

Enable MCP servers in TOML:

```toml
[mcp]
enabled = true

[mcp.server.local]
transport = "stdio"
command = "python"
args = ["examples/fake_mcp_server.py"]
tool_prefix = "local"
```

Streamable HTTP servers use a URL:

```toml
[mcp.server.remote]
transport = "streamable_http"
url = "http://localhost:8000/mcp"
tool_prefix = "remote"
```

MCP tools are converted into the same `Tool` abstraction as local skills.
`build_agent()` loads enabled MCP servers and registers their tools. Local tool
names are prefixed by the server name by default, for example `local_search`.
Set `tool_prefix = ""` to preserve remote names.

When `[agent.tool_search]` is enabled, MCP tools are part of the searchable
catalog. With `defer_tools = true`, the agent sees `find_tools` first and
matching MCP tools are loaded into the current registry after a search.

## Local Stdio Example

Hajimi includes a small stdio MCP server for local testing:

```bash
uv sync --extra mcp
uv run python examples/mcp_stdio.py
```

The fake server exposes:

- `get_weather(city: str)`: returns deterministic fake weather.
- `add_numbers(a: int, b: int)`: returns an exact integer sum.

The pytest suite includes mocked MCP coverage by default. The real fake-server
test runs only when the optional `mcp` extra is installed.
