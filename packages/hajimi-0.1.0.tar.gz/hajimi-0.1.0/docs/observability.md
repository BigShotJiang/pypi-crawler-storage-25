# Observability

Hajimi records structured spans in JSON Lines by default.

```toml
[observability]
enabled = true
directory = "logs"
file_name = "traces.jsonl"
sample_rate = 1.0
include_content = true
max_content_chars = 4000

[observability.otel]
enabled = false
service_name = "hajimi"
service_version = "0.1.0"
endpoint = ""
protocol = "http/protobuf"
insecure = false
timeout = 10.0
headers = {}
```

Each completed span is one JSON object. Agent, LLM, tool, and sub-agent spans
share a `trace_id`.

```bash
jq -r '[.trace_id, .parent_span_id, .span_id, .kind, .name, .duration_ms] | @tsv' logs/traces.jsonl
```

LLM outputs:

```bash
jq -r 'select(.kind == "llm") | .events[] | select(.name == "llm.output") | .attributes.content' logs/traces.jsonl
```

Tool calls:

```bash
jq -r 'select(.name == "agent.run") | .events[] | select(.name == "agent.tool_calls") | .attributes' logs/traces.jsonl
jq -r 'select(.kind == "tool") | [.attributes["tool.name"], .status, .duration_ms] | @tsv' logs/traces.jsonl
jq -r 'select(.kind == "tool") | .events[] | select(.name == "tool.output") | .attributes.content' logs/traces.jsonl
```

Streaming spans record one aggregated `llm.output` event after completion.
Individual token chunks are yielded to the caller and skipped in the trace file.

`include_content = false` keeps prompts and outputs out of traces while still
recording metadata such as provider, model, duration, token usage, and status.

OpenTelemetry export is optional:

```bash
uv sync --extra observability
```

```toml
[observability.otel]
enabled = true
endpoint = "https://otel.example.com/v1/traces"
protocol = "http/protobuf"
headers = { Authorization = "Bearer ..." }
```

Langfuse supports OpenTelemetry-based ingestion through its Python SDK and
tracing stack. Hajimi keeps the core on a local tracer interface, so OTel or a
future custom Langfuse exporter can be attached without changing agent code.

`TraceManager` samples only root spans. When a root span is sampled, child agent,
LLM, and tool spans inherit the active trace through `contextvars`; when a root
span is skipped, that run uses no-op spans.
