"""Durable session with JSONL replay and token accounting."""

import anyio

from hajimi import AgentSession, AnyLLMClient, build_agent, create_session_store, load_config, setup_observability
from hajimi.logging import configure_logging


async def main() -> None:
    config = await load_config("examples/configs/configs.toml")
    await configure_logging(config.log, config.repo_path)
    tracer = await setup_observability(config.observability, config.repo_path)

    client = AnyLLMClient(config.model(), tracer=tracer)
    built = await build_agent(config, client=client, tracer=tracer)
    store = create_session_store(config.context, config.repo_path)

    session = await AgentSession.create(
        agent=built.agent,
        store=store,
        name="examples-session",
        model_name=config.model().name,
        context_settings=config.context,
    )

    first = await session.run("记住项目名是 Hajimi。")
    second = await session.run("刚才的项目名是什么？用一句话回答。")
    report = await session.token_report()

    print(first.content)
    print(second.content)
    print(f"session_id={session.session_id}")
    print(f"tokens={report.total_tokens}")


if __name__ == "__main__":
    anyio.run(main)
