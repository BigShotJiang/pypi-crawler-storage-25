"""Small fake MCP server with weather and calculator tools."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("hajimi-fake-tools")


@mcp.tool()
def get_weather(city: str) -> str:
    """Return fake weather for a city."""

    return f"{city}: sunny, 24C"


@mcp.tool()
def add_numbers(a: int, b: int) -> int:
    """Add two integers exactly."""

    return a + b


if __name__ == "__main__":
    mcp.run()
