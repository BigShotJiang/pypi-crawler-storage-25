"""Small public examples for core Hajimi workflows."""
