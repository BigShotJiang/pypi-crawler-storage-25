"""Agent using local stdio MCP tools."""

import json
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import anyio

from hajimi.config import AgentSettings, AppConfig, LogSettings, MCPServerSettings, MCPSettings, ModelSettings, ObservabilitySettings
from hajimi.core import build_agent
from hajimi.llm import ModelResult
from hajimi.observability import setup_observability


class FakeClient:
    def __init__(self) -> None:
        self.calls = 0

    async def complete(self, messages: list[dict[str, Any]], **kwargs: Any) -> ModelResult:
        self.calls += 1
        if self.calls == 1:
            return ModelResult(
                text="",
                raw=_response(
                    "",
                    [
                        _tool_call("weather-1", "fake_get_weather", {"city": "Shanghai"}),
                        _tool_call("add-1", "fake_add_numbers", {"a": 20, "b": 22}),
                    ],
                ),
            )
        return ModelResult(text="Shanghai sunny; sum=42", raw=_response("Shanghai sunny; sum=42"))


async def main() -> None:
    repo_path = Path.cwd()
    config = AppConfig(
        repo_path=repo_path,
        agent=AgentSettings(name="mcp-example", default_model="fake", max_tool_rounds=2),
        log=LogSettings(enable_console=False, enable_file=False),
        observability=ObservabilitySettings(enabled=True, directory=repo_path / "logs"),
        mcp=MCPSettings(
            enabled=True,
            servers={
                "fake": MCPServerSettings(
                    name="fake",
                    transport="stdio",
                    command="uv",
                    args=["run", "python", "examples/fake_mcp_server.py"],
                    tool_prefix="fake",
                )
            },
        ),
        models={"fake": ModelSettings(name="fake", provider="test", model="fake")},
    )
    tracer = await setup_observability(config.observability, config.repo_path)
    built = await build_agent(config, client=FakeClient(), tracer=tracer)  # type: ignore[arg-type]
    result = await built.agent.run("Use fake MCP weather and calculator tools.")
    print(result.content)


def _response(content: str, tool_calls: list[Any] | None = None) -> Any:
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(content=content, tool_calls=tool_calls or []),
            )
        ]
    )


def _tool_call(call_id: str, name: str, arguments: dict[str, Any]) -> Any:
    return SimpleNamespace(
        id=call_id,
        type="function",
        function=SimpleNamespace(name=name, arguments=json.dumps(arguments)),
    )


if __name__ == "__main__":
    anyio.run(main)
