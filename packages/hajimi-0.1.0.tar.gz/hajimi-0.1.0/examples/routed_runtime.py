"""High-level routed runtime with profiles, sessions, and traces."""

import anyio

from hajimi import AgentRuntime, RunOptions, load_config
from hajimi.logging import configure_logging


async def main() -> None:
    config = await load_config("examples/configs/configs.toml")
    await configure_logging(config.log, config.repo_path)
    runtime = await AgentRuntime.from_config(config)

    answer = await runtime.ask("用一句话介绍 Hajimi。")
    print(answer)

    result = await runtime.run_task(
        "让 planner 和 reviewer 分别评估一个 Python agent framework 的 context API 设计。",
        options=RunOptions(
            mode="subagents",
            profiles=["planner", "reviewer"],
            session_name="examples-routed-runtime",
            max_budget_tokens=4000,
        ),
    )

    print(result.plan.to_dict())
    print(result.content)
    print(f"session_id={result.session_id}")
    print(f"trace_file={result.trace_file}")


if __name__ == "__main__":
    anyio.run(main)
