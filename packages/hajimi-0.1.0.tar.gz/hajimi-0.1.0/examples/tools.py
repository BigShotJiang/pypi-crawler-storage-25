"""Agent with local function tools inferred from type hints and docstrings."""

import anyio

from hajimi import Agent, AnyLLMClient, TextDelta, load_config, setup_observability, tool, user_message
from hajimi.logging import configure_logging


@tool
def add_numbers(a: int, b: int) -> int:
    """Add two integers."""

    return a + b


@tool
def lookup_order_status(order_id: str) -> dict[str, str]:
    """Look up a fake order status."""

    statuses = {
        "A100": "paid",
        "B200": "shipped",
        "C300": "delivered",
    }
    return {"order_id": order_id, "status": statuses.get(order_id, "unknown")}


async def main() -> None:
    config = await load_config("examples/configs/configs.toml")
    await configure_logging(config.log, config.repo_path)
    tracer = await setup_observability(config.observability, config.repo_path)

    client = AnyLLMClient(config.model(), tracer=tracer)
    agent = Agent.from_tools(
        client=client,
        tools=[add_numbers, lookup_order_status],
        system_prompt="Use tools for arithmetic and order lookups. Keep answers short.",
        tracer=tracer,
    )

    async with agent.run_stream(
        [
            user_message(
                "Use tools to add 19 and 23, then look up order B200. "
                "Return exactly: sum=<number>; status=<status>."
            )
        ]
    ) as run:
        async for event in run:
            if isinstance(event, TextDelta):
                print(event.chunk, end="", flush=True)
    print()


if __name__ == "__main__":
    anyio.run(main)
