"""Custom agent loop with explicit context, stream, and tool scheduling."""

from collections.abc import AsyncIterator

import anyio

import hajimi as ai
from hajimi.logging import configure_logging


@ai.tool
async def get_weather(city: str) -> str:
    """Get current weather for a city."""

    await anyio.sleep(0.1)
    forecasts = {
        "tokyo": "Sunny, 22C",
        "new york": "Cloudy, 13C",
    }
    return forecasts.get(city.lower(), f"Mild weather in {city}")


@ai.tool
async def get_population(city: str) -> int:
    """Get population for a city."""

    await anyio.sleep(0.1)
    populations = {
        "tokyo": 13_960_000,
        "new york": 8_336_817,
    }
    return populations.get(city.lower(), 1_000_000)


class CustomAgent(ai.Agent):
    async def loop(self, context: ai.Context) -> AsyncIterator[ai.AgentEvent]:
        while context.keep_running():
            async with (
                ai.stream(context=context) as model_stream,
                ai.ToolRunner() as tools,
            ):
                async for event in ai.merge(model_stream, tools.events()):
                    yield event
                    if isinstance(event, ai.ToolEnd):
                        call = event.tool_call
                        print(f"\n[tool] {call.tool_name}({call.tool_args})")
                        tools.schedule(context.resolve(call))

                context.add(model_stream.message)
                context.add(tools.get_tool_message())


async def main() -> None:
    config = await ai.load_config("examples/configs/configs.toml")
    await configure_logging(config.log, config.repo_path)
    tracer = await ai.setup_observability(config.observability, config.repo_path)

    client = ai.AnyLLMClient(config.model(), tracer=tracer)
    agent = CustomAgent.from_tools(
        client=client,
        tools=[get_weather, get_population],
        system_prompt="Use tools when comparing weather or population. Be concise.",
        tracer=tracer,
    )

    async with agent.run_stream([ai.user_message("Compare Tokyo and New York weather and population.")]) as run:
        async for event in run:
            if isinstance(event, ai.TextDelta):
                print(event.chunk, end="", flush=True)
    print()


if __name__ == "__main__":
    anyio.run(main)
