"""Simplest agent run with typed messages."""

import anyio

from hajimi import AnyLLMClient, TextDelta, build_agent, load_config, setup_observability, user_message
from hajimi.logging import configure_logging


async def main() -> None:
    config = await load_config("examples/configs/configs.toml")
    await configure_logging(config.log, config.repo_path)
    tracer = await setup_observability(config.observability, config.repo_path)

    client = AnyLLMClient(config.model(), tracer=tracer)
    built = await build_agent(config, client=client, tracer=tracer)

    result = await built.agent.run([user_message("用一句话介绍 Hajimi。")])
    print(result.content)

    async with built.agent.run_stream([user_message("列出 3 个 agent 框架设计原则。")]) as run:
        async for event in run:
            if isinstance(event, TextDelta):
                print(event.chunk, end="", flush=True)
    print()


if __name__ == "__main__":
    anyio.run(main)
