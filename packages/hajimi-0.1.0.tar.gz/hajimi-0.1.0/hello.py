def main():
    print("Hello from hajimi!")


if __name__ == "__main__":
    main()
