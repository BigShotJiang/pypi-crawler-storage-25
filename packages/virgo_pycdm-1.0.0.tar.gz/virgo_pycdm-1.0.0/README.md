# CDM Python frontend

Python frontend to communicate with the CDM. This library implements the 0mq API

## Build & install

To build the project run: `python3 setup.py build` which will also build the cdm_bindings module.

To install it: `python3 setup.py install --user`

### Manual build

To compile the tiny cdm_bindings module manually run: `bash -c "cd common-cdm && g++ -O3 -shared -std=c++17 -fPIC $(python3 -m pybind11 --includes) cdm_bindings.cpp -o ../cdm_bindings$(python3-config --extension-suffix)"`
Note that the module depends on pybind11.

In mac:
```
bash -c "cd common-cdm && g++ -O3 -shared -std=c++17 -fPIC -Wl,-undefined,dynamic_lookup $(python3 -m pybind11 --includes) $(python3-config --ldflags) cdm_bindings.cpp -o ../cdm_bindings$(python3-config --extension-suffix)"
```

## GUI

Once the project is installed the GUI can be executed running "cdm_gui" command. 

To run the gui without installing the project `python3 -m cdm_gui.widget` can be used. 

## Heap Monitor

A live heap monitor for both EBIs is available through `cdm_heap_monitor`.
The module can also be run directly with `python3 -m tools.heap_monitor_graph`.

Examples:
- `cdm_heap_monitor`
- `cdm_heap_monitor --cdm-address 127.0.0.1 --interval 2`

The monitor opens a tabbed window. The main tab graphs total free heap, largest free block, and lifetime minimum free heap for both EBIs and shows a green or red data-status indicator depending on whether any `DATA.FRAME` messages arrived during the last refresh interval. A second tab shows the `DATA.FRAME` rate history in frames per second. It keeps all collected samples for the lifetime of the process.

## Pushing new version to PyPi

Build dist: `python3 setup.py build bdist sdist`
Push example: `twine upload --repository pypi --verbose dist/virgo_pycdm-X.Y.Z.tar.gz`

TODO: Would be nice to have this done at CI/CD at merge time in Gitlab

## Integration tests

Before running intergration tests we must run `export PYTHONPATH="$PWD"` in order to detect the test coverage. Then we can proceed by executing `pytest -x -rx -rP -vvv --cov=$PWD/pycdm --cov-report html integration_tests`
