import unittest

from tools.heap_monitor_graph import FrameRateTracker, extract_heap_sample


class ExtractHeapSampleTests(unittest.TestCase):
    def test_extracts_heap_metrics_in_kib(self) -> None:
        sample = extract_heap_sample(
            {
                "left": {
                    "ebi": {
                        "uptime": 180_000_000,
                        "heap": {
                            "total_free_bytes": 30 * 1024,
                            "largest_free_block": 18 * 1024,
                            "minimum_free_bytes": 12 * 1024,
                        },
                    }
                }
            },
            "left",
            timestamp=42.0,
        )

        self.assertIsNotNone(sample)
        assert sample is not None
        self.assertEqual(sample.timestamp, 42.0)
        self.assertEqual(sample.uptime_minutes, 3.0)
        self.assertEqual(sample.total_free_kib, 30.0)
        self.assertEqual(sample.largest_free_block_kib, 18.0)
        self.assertEqual(sample.minimum_free_kib, 12.0)

    def test_returns_none_when_ebi_payload_is_missing(self) -> None:
        self.assertIsNone(extract_heap_sample({}, "right"))
        self.assertIsNone(extract_heap_sample({"right": {}}, "right"))
        self.assertIsNone(extract_heap_sample({"right": {"ebi": {}}}, "right"))


class FrameRateTrackerTests(unittest.TestCase):
    def test_updates_frames_per_second_from_interval(self) -> None:
        tracker = FrameRateTracker()

        self.assertIsNone(tracker.update(5, 10.0))
        self.assertEqual(tracker.total_frames, 5)
        self.assertTrue(tracker.had_data_last_interval)
        self.assertEqual(tracker.update(12, 12.0), 6.0)
        self.assertEqual(tracker.total_frames, 17)
        self.assertTrue(tracker.had_data_last_interval)

    def test_handles_non_positive_elapsed_time(self) -> None:
        tracker = FrameRateTracker(last_timestamp=8.0, frames_per_second=3.0, total_frames=4)

        self.assertEqual(tracker.update(7, 8.0), 0.0)
        self.assertEqual(tracker.total_frames, 11)
        self.assertTrue(tracker.had_data_last_interval)

    def test_marks_interval_as_down_when_no_frames_arrive(self) -> None:
        tracker = FrameRateTracker(last_timestamp=3.0, frames_per_second=5.0, total_frames=9)

        self.assertEqual(tracker.update(0, 5.0), 0.0)
        self.assertFalse(tracker.had_data_last_interval)


if __name__ == "__main__":
    unittest.main()
