from __future__ import annotations

import argparse
import os
import pathlib
import time
from dataclasses import dataclass
from queue import Empty
from typing import Any


BYTES_PER_KIB = 1024.0
MICROSECONDS_PER_MINUTE = 60_000_000.0
EBI_NAMES = ("left", "right")


@dataclass(frozen=True)
class HeapSample:
    timestamp: float
    uptime_minutes: float
    total_free_kib: float
    largest_free_block_kib: float
    minimum_free_kib: float


@dataclass
class FrameRateTracker:
    last_timestamp: float | None = None
    frames_per_second: float = 0.0
    total_frames: int = 0
    had_data_last_interval: bool = False

    def update(self, received_frames: int, now: float) -> float | None:
        self.total_frames += received_frames
        self.had_data_last_interval = received_frames > 0
        if self.last_timestamp is None:
            self.last_timestamp = now
            self.frames_per_second = 0.0
            return None

        elapsed = now - self.last_timestamp
        self.last_timestamp = now
        if elapsed <= 0:
            self.frames_per_second = 0.0
        else:
            self.frames_per_second = received_frames / elapsed

        return self.frames_per_second


def extract_heap_sample(info: dict[str, Any], ebi_name: str, timestamp: float | None = None) -> HeapSample | None:
    board = info.get(ebi_name)
    if not isinstance(board, dict):
        return None

    ebi = board.get("ebi")
    if not isinstance(ebi, dict):
        return None

    heap = ebi.get("heap")
    if not isinstance(heap, dict):
        return None

    now = time.monotonic() if timestamp is None else timestamp
    total_free = float(heap["total_free_bytes"])
    largest_free_block = float(heap["largest_free_block"])
    minimum_free = float(heap["minimum_free_bytes"])

    return HeapSample(
        timestamp=now,
        uptime_minutes=float(ebi["uptime"]) / MICROSECONDS_PER_MINUTE,
        total_free_kib=total_free / BYTES_PER_KIB,
        largest_free_block_kib=largest_free_block / BYTES_PER_KIB,
        minimum_free_kib=minimum_free / BYTES_PER_KIB,
    )


def _connect_ebis_if_needed(cdm: Any, cdm_bindings: Any) -> None:
    if cdm.cdm.get_sm_state() == cdm_bindings.SM_STATE.INITIALIZED:
        cdm.ebi.connect()


def _prepare_matplotlib_config_dir() -> None:
    if os.environ.get("MPLCONFIGDIR"):
        return

    config_dir = pathlib.Path("/tmp") / "matplotlib-{}".format(os.getuid())
    config_dir.mkdir(parents=True, exist_ok=True)
    os.environ["MPLCONFIGDIR"] = str(config_dir)


def _ensure_runtime_dependencies() -> None:
    _prepare_matplotlib_config_dir()

    try:
        import tkinter  # noqa: F401
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "Missing tkinter for the active interpreter. On Gentoo this is provided by "
            "dev-lang/python built with USE=tk. In this environment, python3.14 has tkinter "
            "but the active python3.13 does not."
        ) from exc

    try:
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg  # noqa: F401
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "Missing matplotlib Tk backend for the active interpreter. On Gentoo install or rebuild "
            "dev-python/matplotlib for the same Python target you use to run this tool, with USE=tk."
        ) from exc


class HeapMonitorPlot:
    def __init__(self, cdm: Any, interval_s: float) -> None:
        import tkinter as tk
        from tkinter import ttk

        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
        from matplotlib.figure import Figure

        self._cdm = cdm
        self._frame_queue = cdm.reg_msg("DATA.FRAME")
        self._frame_rate = FrameRateTracker()
        self._interval_s = interval_s
        self._history = {ebi_name: [] for ebi_name in EBI_NAMES}
        self._frame_rate_history: list[tuple[float, float]] = []
        self._start_time = time.monotonic()
        self._root = tk.Tk()
        self._root.title("CDM Heap Monitor")
        self._root.geometry("1280x820")
        self._root.protocol("WM_DELETE_WINDOW", self._handle_close)

        notebook = ttk.Notebook(self._root)
        notebook.pack(fill="both", expand=True)

        heap_tab = ttk.Frame(notebook)
        fps_tab = ttk.Frame(notebook)
        notebook.add(heap_tab, text="Heap")
        notebook.add(fps_tab, text="Frames/s")

        self._heap_figure = Figure(figsize=(12, 7))
        self._heap_figure.set_tight_layout(True)
        self._heap_axis = self._heap_figure.add_subplot(111)
        self._heap_canvas = FigureCanvasTkAgg(self._heap_figure, master=heap_tab)
        self._heap_canvas.get_tk_widget().pack(fill="both", expand=True)

        self._fps_figure = Figure(figsize=(12, 7))
        self._fps_figure.set_tight_layout(True)
        self._fps_axis = self._fps_figure.add_subplot(111)
        self._fps_canvas = FigureCanvasTkAgg(self._fps_figure, master=fps_tab)
        self._fps_canvas.get_tk_widget().pack(fill="both", expand=True)

        self._closed = False

    def _handle_close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._cdm.close()
        self._root.quit()
        self._root.destroy()

    def _poll(self) -> None:
        info = self._cdm.bcg.get_info()
        now = time.monotonic()
        for ebi_name in EBI_NAMES:
            sample = extract_heap_sample(info, ebi_name, now)
            if sample is not None:
                self._history[ebi_name].append(sample)
        frame_rate = self._frame_rate.update(self._drain_frame_queue(), now)
        if frame_rate is not None:
            self._frame_rate_history.append(((now - self._start_time) / 60.0, frame_rate))

    def _drain_frame_queue(self) -> int:
        count = 0
        while True:
            try:
                self._frame_queue.get_nowait()
            except Empty:
                break
            count += 1
        return count

    def _draw_heap_axis(self) -> None:
        axis = self._heap_axis
        axis.clear()
        axis.set_title("EBI heap monitor")
        axis.set_xlabel("Elapsed time [min]")
        axis.set_ylabel("KiB")
        axis.grid(True, alpha=0.3)

        color_map = {
            "left": "#D62728",
            "right": "#1F77B4",
        }
        linestyle_map = {
            "total_free_kib": "-",
            "largest_free_block_kib": "--",
            "minimum_free_kib": ":",
        }
        metric_labels = {
            "total_free_kib": "total free",
            "largest_free_block_kib": "largest free block",
            "minimum_free_kib": "lifetime minimum free",
        }

        latest_summaries = []
        plotted_anything = False
        for ebi_name in EBI_NAMES:
            samples = list(self._history[ebi_name])
            if not samples:
                continue

            plotted_anything = True
            x_data = [(sample.timestamp - self._start_time) / 60.0 for sample in samples]
            for metric_name, metric_label in metric_labels.items():
                axis.plot(
                    x_data,
                    [getattr(sample, metric_name) for sample in samples],
                    label="{} {}".format(ebi_name.title(), metric_label),
                    color=color_map[ebi_name],
                    linestyle=linestyle_map[metric_name],
                    linewidth=2,
                )

            latest = samples[-1]
            latest_summaries.append("{} UP {:.1f} min".format(ebi_name.title(), latest.uptime_minutes))

        if plotted_anything:
            axis.text(
                0.02,
                0.98,
                " | ".join(latest_summaries),
                ha="left",
                va="top",
                transform=axis.transAxes,
                bbox={"boxstyle": "round", "facecolor": "white", "alpha": 0.75, "edgecolor": "#CCCCCC"},
            )
            axis.legend(loc="upper right", ncol=2)
        else:
            axis.text(
                0.5,
                0.5,
                "No heap data yet",
                ha="center",
                va="center",
                transform=axis.transAxes,
            )

        status_color = "#2CA02C" if self._frame_rate.had_data_last_interval else "#D62728"
        status_text = "DATA OK" if self._frame_rate.had_data_last_interval else "DATA DOWN"
        axis.scatter([0.03], [0.04], s=180, color=status_color, transform=axis.transAxes, clip_on=False)
        axis.text(
            0.06,
            0.04,
            status_text,
            ha="left",
            va="center",
            transform=axis.transAxes,
            bbox={"boxstyle": "round", "facecolor": "white", "alpha": 0.75, "edgecolor": "#CCCCCC"},
        )

    def _draw_fps_axis(self) -> None:
        axis = self._fps_axis
        axis.clear()
        axis.set_title("DATA.FRAME per second")
        axis.set_xlabel("Elapsed time [min]")
        axis.set_ylabel("Frames/s")
        axis.grid(True, alpha=0.3)

        if not self._frame_rate_history:
            axis.text(
                0.5,
                0.5,
                "No frame-rate data yet",
                ha="center",
                va="center",
                transform=axis.transAxes,
            )
            return

        x_data = [sample[0] for sample in self._frame_rate_history]
        y_data = [sample[1] for sample in self._frame_rate_history]
        axis.plot(x_data, y_data, color="#2F4F4F", linewidth=2.2, label="Frames/s")
        axis.fill_between(x_data, y_data, color="#2F4F4F", alpha=0.12)
        axis.text(
            0.02,
            0.98,
            "Current {:.1f}/s | Total {}".format(
                self._frame_rate.frames_per_second,
                self._frame_rate.total_frames,
            ),
            ha="left",
            va="top",
            transform=axis.transAxes,
            bbox={"boxstyle": "round", "facecolor": "white", "alpha": 0.75, "edgecolor": "#CCCCCC"},
        )
        axis.legend(loc="upper right")

    def _update(self) -> None:
        self._poll()
        self._draw_heap_axis()
        self._draw_fps_axis()
        self._heap_canvas.draw_idle()
        self._fps_canvas.draw_idle()

    def _schedule_update(self) -> None:
        if self._closed:
            return

        try:
            self._update()
        finally:
            if not self._closed:
                self._root.after(max(int(self._interval_s * 1000), 250), self._schedule_update)

    def show(self) -> None:
        self._schedule_update()
        self._root.mainloop()


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Live heap monitor for left and right EBIs")
    parser.add_argument("--cdm-address", default="127.0.0.1", help="CDM address to connect to")
    parser.add_argument("--interval", type=float, default=5.0, help="Polling interval in seconds")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_argument_parser().parse_args(argv)

    if args.interval <= 0:
        raise ValueError("--interval must be greater than zero")

    _ensure_runtime_dependencies()

    import cdm_bindings
    from pycdm import PyCDM

    cdm = PyCDM(args.cdm_address)

    try:
        _connect_ebis_if_needed(cdm, cdm_bindings)
        HeapMonitorPlot(cdm, args.interval).show()
    finally:
        cdm.close()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
