"""Utility modules and scripts for the CDM Python frontend."""
