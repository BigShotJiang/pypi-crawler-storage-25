"""Tasks for computing dataset-wide quality metrics."""

from typing import Iterable

from dkist_processing_common.tasks import QualityL0Metrics

from dkist_processing_dlnirsp.models.constants import DlnirspConstants
from dkist_processing_dlnirsp.models.tags import DlnirspTag

__all__ = ["DlnirspL0QualityMetrics"]


class DlnirspL0QualityMetrics(QualityL0Metrics):
    """
    Task class for collection of DLNIRSP L0 specific quality metrics.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs

    """

    @property
    def constants_model_class(self):
        """Class for DLNIRSP constants."""
        return DlnirspConstants

    @property
    def raw_frame_tag(self) -> str:
        """
        Define tag corresponding to L0 data.

        For DL it's LINEARIZED.
        """
        return DlnirspTag.linearized()

    @property
    def modstate_list(self) -> Iterable[int] | None:
        """
        Define the list of modstates over which to compute L0 quality metrics.

        If the dataset is non-polarimetric then we just compute all metrics over all modstates at once.
        """
        if self.constants.correct_for_polarization:
            return list(range(1, self.constants.num_modstates + 1))

        return None
