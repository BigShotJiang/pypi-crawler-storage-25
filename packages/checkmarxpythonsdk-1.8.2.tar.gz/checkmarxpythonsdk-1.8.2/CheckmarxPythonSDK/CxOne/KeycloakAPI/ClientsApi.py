import logging

from CheckmarxPythonSDK.api_client import ApiClient
from CheckmarxPythonSDK.CxOne.config import construct_configuration
from typing import Dict, List, Any, Optional, Union
from .dto.AccessToken import AccessToken
from .dto.ClientRepresentation import ClientRepresentation
from .dto.ClientScopeRepresentation import ClientScopeRepresentation
from .dto.CredentialRepresentation import CredentialRepresentation
from .dto.GlobalRequestResult import GlobalRequestResult
from .dto.IDToken import IDToken
from .dto.ManagementPermissionReference import ManagementPermissionReference
from .dto.ProtocolMapperEvaluationRepresentation import (
    ProtocolMapperEvaluationRepresentation,
)
from .dto.RoleRepresentation import RoleRepresentation
from .dto.UserRepresentation import UserRepresentation
from .dto.UserSessionRepresentation import UserSessionRepresentation
from .api_url import api_url

logger = logging.getLogger(__name__)


class ClientsApi:
    def __init__(self, api_client: Optional[ApiClient] = None):
        if api_client is None:
            configuration = construct_configuration()
            api_client = ApiClient(configuration=configuration)
        self.api_client = api_client
        self.base_url = f"{api_client.configuration.iam_base_url.rstrip('/')}{api_url}"

    def get_clients(
        self,
        realm: str,
        client_id: str = None,
        first: int = 0,
        max: int = 100,
        q: str = None,
        search: bool = None,
        viewable_only: str = None,
    ) -> List[ClientRepresentation]:
        """
        Get clients belonging to the realm.

        Args:
            realm (str):  [required]
            client_id (str): filter by clientId
            first (int): the first result
            max (int): the max results to return
            q (str):
            search (bool): whether this is a search query or a getClientById query
            viewable_only (str): filter clients that cannot be viewed in full by admin

        Returns:
            List[ClientRepresentation]

        URL:
            Relative path: /{realm}/clients
        """
        params = {
            "clientId": client_id,
            "first": first,
            "max": max,
            "q": q,
            "search": search,
            "viewableOnly": viewable_only,
        }
        url = f"{self.base_url}/{realm}/clients"
        response = self.api_client.call_api("GET", url, params=params)
        return [ClientRepresentation.from_dict(item) for item in response.json()]

    def post_clients(
        self, realm: str, client_representation: ClientRepresentation
    ) -> bool:
        """
        Create a new client Client’s client_id must be unique!

        Args:
            realm (str):  [required]
            client_representation (ClientRepresentation): Request body data [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/clients
        """
        url = f"{self.base_url}/{realm}/clients"
        print(f"Post request to {url}")
        print(f"Request body: {client_representation.to_dict()}")
        response = self.api_client.call_api("POST", url, json=client_representation.to_dict())
        return response.status_code == 201

    def get_client_by_realm_by_id(self, realm: str, id: str) -> ClientRepresentation:
        """
        Get representation of the client

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            ClientRepresentation

        URL:
            Relative path: /{realm}/clients/{id}
        """
        url = f"{self.base_url}/{realm}/clients/{id}"
        response = self.api_client.call_api("GET", url)
        return ClientRepresentation.from_dict(response.json())

    def put_client(
        self, realm: str, id: str, client_representation: ClientRepresentation
    ) -> bool:
        """
        Update the client

        Args:
            realm (str):  [required]
            id (str):  [required]
            client_representation (ClientRepresentation): Request body data [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/clients/{id}
        """
        url = f"{self.base_url}/{realm}/clients/{id}"
        response = self.api_client.call_api("PUT", url, json=client_representation.to_dict())
        return response.status_code == 204

    def delete_client_by_realm_by_id(self, realm: str, id: str) -> bool:
        """
        Delete the client

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/clients/{id}
        """
        if id in ["ast-app", "cb-app", "realm-management", "superset-kpi"]:
            logger.error(
                "Forbid to delete builtin-in clients ast-app, cb-app, "
                "realm-management, superset-kpi which are system clients"
            )
            return False
        if id.startswith(tuple(["saml-helper-"])):
            logger.error(
                "Forbid to delete clients with saml-helper- prefix, "
                "which are intended for internal use"
            )
            return False
        url = f"{self.base_url}/{realm}/clients/{id}"
        response = self.api_client.call_api("DELETE", url)
        logger.info(f"Delete client {id} successful in realm {realm}")
        return response.status_code == 204

    def get_client_secret(self, realm: str, id: str) -> CredentialRepresentation:
        """
        Get the client secret

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            CredentialRepresentation

        URL:
            Relative path: /{realm}/clients/{id}/client-secret
        """
        url = f"{self.base_url}/{realm}/clients/{id}/client-secret"
        response = self.api_client.call_api("GET", url)
        return CredentialRepresentation.from_dict(response.json())

    def post_client_secret(self, realm: str, id: str) -> CredentialRepresentation:
        """
        Generate a new secret for the client

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            CredentialRepresentation

        URL:
            Relative path: /{realm}/clients/{id}/client-secret
        """
        url = f"{self.base_url}/{realm}/clients/{id}/client-secret"
        response = self.api_client.call_api("POST", url)
        return CredentialRepresentation.from_dict(response.json())

    def get_rotated(self, realm: str, id: str) -> CredentialRepresentation:
        """
        Get the rotated client secret

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            CredentialRepresentation

        URL:
            Relative path: /{realm}/clients/{id}/client-secret/rotated
        """
        url = f"{self.base_url}/{realm}/clients/{id}/client-secret/rotated"
        response = self.api_client.call_api("GET", url)
        return CredentialRepresentation.from_dict(response.json())

    def delete_rotated(self, realm: str, id: str) -> bool:
        """
        Invalidate the rotated secret for the client

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/clients/{id}/client-secret/rotated
        """
        url = f"{self.base_url}/{realm}/clients/{id}/client-secret/rotated"
        response = self.api_client.call_api("DELETE", url)
        return response.status_code == 200

    def get_default_client_scopes(
        self, realm: str, id: str
    ) -> List[ClientScopeRepresentation]:
        """
        Get default client scopes.  Only name and ids are returned.

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            List[ClientScopeRepresentation]

        URL:
            Relative path: /{realm}/clients/{id}/default-client-scopes
        """
        url = f"{self.base_url}/{realm}/clients/{id}/default-client-scopes"
        response = self.api_client.call_api("GET", url)
        return [ClientScopeRepresentation.from_dict(item) for item in response.json()]

    def put_default_client_scope(
        self, realm: str, id: str, client_scope_id: str
    ) -> bool:
        """

        Args:
            realm (str):  [required]
            id (str):  [required]
            client_scope_id (str):  [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/clients/{id}/default-client-scopes/{clientScopeId}
        """
        url = f"{self.base_url}/{realm}/clients/{id}/default-client-scopes/{client_scope_id}"
        response = self.api_client.call_api("PUT", url)
        return response.status_code == 204

    def delete_default_client_scope(
        self, realm: str, id: str, client_scope_id: str
    ) -> bool:
        """

        Args:
            realm (str):  [required]
            id (str):  [required]
            client_scope_id (str):  [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/clients/{id}/default-client-scopes/{clientScopeId}
        """
        url = f"{self.base_url}/{realm}/clients/{id}/default-client-scopes/{client_scope_id}"
        response = self.api_client.call_api("DELETE", url)
        return response.status_code == 204

    def get_generate_example_access_token(
        self, realm: str, id: str, scope: str = None, user_id: str = None
    ) -> AccessToken:
        """
        Create JSON with payload of example access token

        Args:
            realm (str):  [required]
            id (str):  [required]
            scope (str):
            user_id (str):

        Returns:
            AccessToken

        URL:
            Relative path: /{realm}/clients/{id}/evaluate-scopes/generate-example-access-token
        """
        params = {"scope": scope, "userId": user_id}
        url = f"{self.base_url}/{realm}/clients/{id}/evaluate-scopes/generate-example-access-token"
        response = self.api_client.call_api("GET", url, params=params)
        return AccessToken.from_dict(response.json())

    def get_generate_example_id_token(
        self, realm: str, id: str, scope: str = None, user_id: str = None
    ) -> IDToken:
        """
        Create JSON with payload of example id token

        Args:
            realm (str):  [required]
            id (str):  [required]
            scope (str):
            user_id (str):

        Returns:
            IDToken

        URL:
            Relative path: /{realm}/clients/{id}/evaluate-scopes/generate-example-id-token
        """
        params = {"scope": scope, "userId": user_id}
        url = f"{self.base_url}/{realm}/clients/{id}/evaluate-scopes/generate-example-id-token"
        response = self.api_client.call_api("GET", url, params=params)
        return IDToken.from_dict(response.json())

    def get_generate_example_userinfo(
        self, realm: str, id: str, scope: str = None, user_id: str = None
    ) -> Dict[str, Any]:
        """
        Create JSON with payload of example user info

        Args:
            realm (str):  [required]
            id (str):  [required]
            scope (str):
            user_id (str):

        Returns:
            Dict[str, Any]

        URL:
            Relative path: /{realm}/clients/{id}/evaluate-scopes/generate-example-userinfo
        """
        params = {"scope": scope, "userId": user_id}
        url = f"{self.base_url}/{realm}/clients/{id}/evaluate-scopes/generate-example-userinfo"
        response = self.api_client.call_api("GET", url, params=params)
        return response.json()

    def get_protocol_mappers(
        self, realm: str, id: str, scope: str = None
    ) -> List[ProtocolMapperEvaluationRepresentation]:
        """
        Return list of all protocol mappers, which will be used when
        generating tokens issued for particular client.

        Args:
            realm (str):  [required]
            id (str):  [required]
            scope (str):

        Returns:
            List[ProtocolMapperEvaluationRepresentation]

        URL:
            Relative path: /{realm}/clients/{id}/evaluate-scopes/protocol-mappers
        """
        params = {"scope": scope}
        url = f"{self.base_url}/{realm}/clients/{id}/evaluate-scopes/protocol-mappers"
        response = self.api_client.call_api("GET", url, params=params)
        return [
            ProtocolMapperEvaluationRepresentation.from_dict(item)
            for item in response.json()
        ]

    def get_granted(
        self, realm: str, id: str, role_container_id: str, scope: str = None
    ) -> List[RoleRepresentation]:
        """
        Get effective scope mapping of all roles of particular role container,
        which this client is defacto allowed to have in the accessToken issued for him.

        Args:
            realm (str):  [required]
            id (str):  [required]
            role_container_id (str):  [required]
            scope (str):

        Returns:
            List[RoleRepresentation]

        URL:
            Relative path: /{realm}/clients/{id}/evaluate-scopes/scope-mappings/{roleContainerId}/granted
        """
        params = {"scope": scope}
        url = f"{self.base_url}/{realm}/clients/{id}/evaluate-scopes/scope-mappings/{role_container_id}/granted"
        response = self.api_client.call_api("GET", url, params=params)
        return [RoleRepresentation.from_dict(item) for item in response.json()]

    def get_not_granted(
        self, realm: str, id: str, role_container_id: str, scope: str = None
    ) -> List[RoleRepresentation]:
        """
        Get roles, which this client doesn’t have scope for and
        can’t have them in the accessToken issued for him.

        Args:
            realm (str):  [required]
            id (str):  [required]
            role_container_id (str):  [required]
            scope (str):

        Returns:
            List[RoleRepresentation]

        URL:
            Relative path: /{realm}/clients/{id}/evaluate-scopes/scope-mappings/{roleContainerId}/not-granted
        """
        params = {"scope": scope}
        url = f"{self.base_url}/{realm}/clients/{id}/evaluate-scopes/scope-mappings/{role_container_id}/not-granted"
        response = self.api_client.call_api("GET", url, params=params)
        return [RoleRepresentation.from_dict(item) for item in response.json()]

    def get_installation_provider(self, realm: str, id: str, provider_id: str) -> bool:
        """

        Args:
            realm (str):  [required]
            id (str):  [required]
            provider_id (str):  [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/clients/{id}/installation/providers/{providerId}
        """
        url = f"{self.base_url}/{realm}/clients/{id}/installation/providers/{provider_id}"
        response = self.api_client.call_api("GET", url)
        return response.status_code == 200

    def get_client_management_permissions(
        self, realm: str, id: str
    ) -> ManagementPermissionReference:
        """
        Return object stating whether client Authorization permissions
        have been initialized or not and a reference

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            ManagementPermissionReference

        URL:
            Relative path: /{realm}/clients/{id}/management/permissions
        """
        url = f"{self.base_url}/{realm}/clients/{id}/management/permissions"
        response = self.api_client.call_api("GET", url)
        return ManagementPermissionReference.from_dict(response.json())

    def put_client_management_permissions(
        self,
        realm: str,
        id: str,
        management_permission_reference: ManagementPermissionReference,
    ) -> ManagementPermissionReference:
        """
        Return object stating whether client Authorization permissions
        have been initialized or not and a reference

        Args:
            realm (str):  [required]
            id (str):  [required]
            management_permission_reference (ManagementPermissionReference): Request body data [required]

        Returns:
            ManagementPermissionReference

        URL:
            Relative path: /{realm}/clients/{id}/management/permissions
        """
        url = f"{self.base_url}/{realm}/clients/{id}/management/permissions"
        response = self.api_client.call_api("PUT", url,
            json=management_permission_reference.to_dict(),
            )
        return ManagementPermissionReference.from_dict(response.json())

    def post_nodes(self, realm: str, id: str) -> bool:
        """
        Register a cluster node with the client Manually register cluster node to this client -
        usually it’s not needed to call this directly as adapter should handle by sending
        registration request to Keycloak

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/clients/{id}/nodes
        """
        url = f"{self.base_url}/{realm}/clients/{id}/nodes"
        response = self.api_client.call_api("POST", url)
        return response.status_code == 201

    def delete_node(self, realm: str, id: str, node: str) -> bool:
        """
        Unregister a cluster node from the client

        Args:
            realm (str):  [required]
            id (str):  [required]
            node (str):  [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/clients/{id}/nodes/{node}
        """
        url = f"{self.base_url}/{realm}/clients/{id}/nodes/{node}"
        response = self.api_client.call_api("DELETE", url)
        return response.status_code == 204

    def get_offline_session_count(self, realm: str, id: str) -> Dict[str, Any]:
        """
        Get application offline session count Returns a number of offline user
        sessions associated with this client { \"count\": number }

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            Dict[str, Any]

        URL:
            Relative path: /{realm}/clients/{id}/offline-session-count
        """
        url = f"{self.base_url}/{realm}/clients/{id}/offline-session-count"
        response = self.api_client.call_api("GET", url)
        return response.json()

    def get_offline_sessions(
        self, realm: str, id: str, first: int = 0, max: int = 100
    ) -> List[UserSessionRepresentation]:
        """
        Get offline sessions for client Returns a list of offline user sessions
        associated with this client

        Args:
            realm (str):  [required]
            id (str):  [required]
            first (int): Paging offset
            max (int): Maximum results size (defaults to 100)

        Returns:
            List[UserSessionRepresentation]

        URL:
            Relative path: /{realm}/clients/{id}/offline-sessions
        """
        params = {"first": first, "max": max}
        url = f"{self.base_url}/{realm}/clients/{id}/offline-sessions"
        response = self.api_client.call_api("GET", url, params=params)
        return [UserSessionRepresentation.from_dict(item) for item in response.json()]

    def get_optional_client_scopes(
        self, realm: str, id: str
    ) -> List[ClientScopeRepresentation]:
        """
        Get optional client scopes.  Only name and ids are returned.

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            List[ClientScopeRepresentation]

        URL:
            Relative path: /{realm}/clients/{id}/optional-client-scopes
        """
        url = f"{self.base_url}/{realm}/clients/{id}/optional-client-scopes"
        response = self.api_client.call_api("GET", url)
        return [ClientScopeRepresentation.from_dict(item) for item in response.json()]

    def put_optional_client_scope(
        self, realm: str, id: str, client_scope_id: str
    ) -> bool:
        """

        Args:
            realm (str):  [required]
            id (str):  [required]
            client_scope_id (str):  [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/clients/{id}/optional-client-scopes/{clientScopeId}
        """
        url = f"{self.base_url}/{realm}/clients/{id}/optional-client-scopes/{client_scope_id}"
        response = self.api_client.call_api("PUT", url)
        return response.status_code == 204

    def delete_optional_client_scope(
        self, realm: str, id: str, client_scope_id: str
    ) -> bool:
        """

        Args:
            realm (str):  [required]
            id (str):  [required]
            client_scope_id (str):  [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/clients/{id}/optional-client-scopes/{clientScopeId}
        """
        url = f"{self.base_url}/{realm}/clients/{id}/optional-client-scopes/{client_scope_id}"
        response = self.api_client.call_api("DELETE", url)
        return response.status_code == 204

    def post_client_push_revocation(self, realm: str, id: str) -> GlobalRequestResult:
        """
        Push the client’s revocation policy to its admin URL If the
        client has an admin URL, push revocation policy to it.

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            GlobalRequestResult

        URL:
            Relative path: /{realm}/clients/{id}/push-revocation
        """
        url = f"{self.base_url}/{realm}/clients/{id}/push-revocation"
        response = self.api_client.call_api("POST", url)
        return GlobalRequestResult.from_dict(response.json())

    def post_registration_access_token(
        self, realm: str, id: str
    ) -> ClientRepresentation:
        """
        Generate a new registration access token for the client

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            ClientRepresentation

        URL:
            Relative path: /{realm}/clients/{id}/registration-access-token
        """
        url = f"{self.base_url}/{realm}/clients/{id}/registration-access-token"
        response = self.api_client.call_api("POST", url)
        return ClientRepresentation.from_dict(response.json())

    def get_service_account_user(self, realm: str, id: str) -> UserRepresentation:
        """
        Get a user dedicated to the service account

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            UserRepresentation

        URL:
            Relative path: /{realm}/clients/{id}/service-account-user
        """
        url = f"{self.base_url}/{realm}/clients/{id}/service-account-user"
        response = self.api_client.call_api("GET", url)
        return UserRepresentation.from_dict(response.json())

    def get_session_count(self, realm: str, id: str) -> Dict[str, Any]:
        """
        Get application session count Returns a number of user sessions
        associated with this client { \"count\": number }

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            Dict[str, Any]

        URL:
            Relative path: /{realm}/clients/{id}/session-count
        """
        url = f"{self.base_url}/{realm}/clients/{id}/session-count"
        response = self.api_client.call_api("GET", url)
        return response.json()

    def get_test_nodes_available(self, realm: str, id: str) -> GlobalRequestResult:
        """
        Test if registered cluster nodes are available Tests availability
        by sending 'ping' request to all cluster nodes.

        Args:
            realm (str):  [required]
            id (str):  [required]

        Returns:
            GlobalRequestResult

        URL:
            Relative path: /{realm}/clients/{id}/test-nodes-available
        """
        url = f"{self.base_url}/{realm}/clients/{id}/test-nodes-available"
        response = self.api_client.call_api("GET", url)
        return GlobalRequestResult.from_dict(response.json())

    def get_client_user_sessions(
        self, realm: str, id: str, first: int = 0, max: int = 100
    ) -> List[UserSessionRepresentation]:
        """
        Get user sessions for client Returns a list of user sessions
        associated with this client

        Args:
            realm (str):  [required]
            id (str):  [required]
            first (int): Paging offset
            max (int): Maximum results size (defaults to 100)

        Returns:
            List[UserSessionRepresentation]

        URL:
            Relative path: /{realm}/clients/{id}/user-sessions
        """
        params = {"first": first, "max": max}
        url = f"{self.base_url}/{realm}/clients/{id}/user-sessions"
        response = self.api_client.call_api("GET", url, params=params)
        return [UserSessionRepresentation.from_dict(item) for item in response.json()]
