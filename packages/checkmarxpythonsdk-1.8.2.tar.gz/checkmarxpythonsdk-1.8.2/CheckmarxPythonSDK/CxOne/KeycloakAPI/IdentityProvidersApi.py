from CheckmarxPythonSDK.api_client import ApiClient
from CheckmarxPythonSDK.CxOne.config import construct_configuration
from typing import Dict, List, Any, Optional
from .dto.IdentityProviderMapperRepresentation import (
    IdentityProviderMapperRepresentation,
)
from .dto.IdentityProviderRepresentation import IdentityProviderRepresentation
from .dto.ManagementPermissionReference import ManagementPermissionReference
from .api_url import api_url


class IdentityProvidersApi:
    def __init__(self, api_client: ApiClient = None):
        if api_client is None:
            configuration = construct_configuration()
            api_client = ApiClient(configuration=configuration)
        self.api_client = api_client
        self.base_url = f"{api_client.configuration.iam_base_url.rstrip('/')}{api_url}"

    def post_import_config(self, realm: str) -> Dict[str, Any]:
        """
        Import identity provider from JSON body

        Args:
            realm (str):  [required]

        Returns:
            Dict[str, Any]

        URL:
            Relative path: /{realm}/identity-provider/import-config
        """
        url = f"{self.base_url}/{realm}/identity-provider/import-config"
        response = self.api_client.call_api("POST", url)
        return response.json()

    def get_instances(
        self,
        realm: str,
        brief_representation: bool = None,
        first: str = None,
        max: str = None,
        search: bool = None,
    ) -> List[IdentityProviderRepresentation]:
        """
        List identity providers

        Args:
            realm (str):  [required]
            brief_representation (bool): Boolean which defines whether brief
                representations are returned (default: false)
            first (str): Pagination offset
            max (str): Maximum results size (defaults to 100)
            search (bool): Filter specific providers by name. Search can be
                prefix (name*), contains (name) or exact ("name"). Default prefixed.

        Returns:
            List[IdentityProviderRepresentation]

        URL:
            Relative path: /{realm}/identity-provider/instances
        """
        params = {
            "briefRepresentation": brief_representation,
            "first": first,
            "max": max,
            "search": search,
        }
        url = f"{self.base_url}/{realm}/identity-provider/instances"
        response = self.api_client.call_api("GET", url, params=params)
        return [
            IdentityProviderRepresentation.from_dict(item) for item in response.json()
        ]

    def post_instances(
        self,
        realm: str,
        identity_provider_representation: IdentityProviderRepresentation,
    ) -> bool:
        """
        Create a new identity provider

        Args:
            realm (str):  [required]
            identity_provider_representation
               (IdentityProviderRepresentation): Request body data [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/identity-provider/instances
        """
        url = f"{self.base_url}/{realm}/identity-provider/instances"
        response = self.api_client.call_api("POST", url,
            json=identity_provider_representation.to_dict(),
            )
        return response.status_code == 200

    def get_instance(self, realm: str, alias: str) -> IdentityProviderRepresentation:
        """
        Get the identity provider

        Args:
            realm (str):  [required]
            alias (str):  [required]

        Returns:
            IdentityProviderRepresentation

        URL:
            Relative path: /{realm}/identity-provider/instances/{alias}
        """
        url = f"{self.base_url}/{realm}/identity-provider/instances/{alias}"
        response = self.api_client.call_api("GET", url)
        return IdentityProviderRepresentation.from_dict(response.json())

    def put_instance(
        self,
        realm: str,
        alias: str,
        identity_provider_representation: IdentityProviderRepresentation,
    ) -> bool:
        """
        Update the identity provider

        Args:
            realm (str):  [required]
            alias (str):  [required]
            identity_provider_representation
               (IdentityProviderRepresentation): Request body data [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/identity-provider/instances/{alias}
        """
        url = f"{self.base_url}/{realm}/identity-provider/instances/{alias}"
        response = self.api_client.call_api("PUT", url,
            json=identity_provider_representation.to_dict(),
            )
        return response.status_code == 200

    def delete_instance(self, realm: str, alias: str) -> bool:
        """
        Delete the identity provider

        Args:
            realm (str):  [required]
            alias (str):  [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/identity-provider/instances/{alias}
        """
        url = f"{self.base_url}/{realm}/identity-provider/instances/{alias}"
        response = self.api_client.call_api("DELETE", url)
        return response.status_code == 200

    def get_export(self, realm: str, alias: str, format: str = None) -> bool:
        """
        Export public broker configuration for identity provider

        Args:
            realm (str):  [required]
            alias (str):  [required]
            format (str): Format to use

        Returns:
            bool

        URL:
            Relative path: /{realm}/identity-provider/instances/{alias}/export
        """
        params = {"format": format}
        url = f"{self.base_url}/{realm}/identity-provider/instances/{alias}/export"
        response = self.api_client.call_api("GET", url, params=params)
        return response.status_code == 200

    def get_instance_management_permissions(
        self, realm: str, alias: str
    ) -> ManagementPermissionReference:
        """
        Return object stating whether client Authorization
        permissions have been initialized or not and a reference

        Args:
            realm (str):  [required]
            alias (str):  [required]

        Returns:
            ManagementPermissionReference

        URL:
            Relative path: /{realm}/identity-provider/instances/{alias}/management/permissions
        """
        url = f"{self.base_url}/{realm}/identity-provider/instances/{alias}/management/permissions"
        response = self.api_client.call_api("GET", url)
        return ManagementPermissionReference.from_dict(response.json())

    def put_instance_management_permissions(
        self,
        realm: str,
        alias: str,
        management_permission_reference: ManagementPermissionReference,
    ) -> ManagementPermissionReference:
        """
        Return object stating whether client Authorization permissions have been initialized or not and a reference

        Args:
            realm (str):  [required]
            alias (str):  [required]
            management_permission_reference (ManagementPermissionReference): Request body data [required]

        Returns:
            ManagementPermissionReference

        URL:
            Relative path: /{realm}/identity-provider/instances/{alias}/management/permissions
        """
        url = f"{self.base_url}/{realm}/identity-provider/instances/{alias}/management/permissions"
        response = self.api_client.call_api("PUT", url,
            json=management_permission_reference.to_dict(),
            )
        return ManagementPermissionReference.from_dict(response.json())

    def get_mapper_types(self, realm: str, alias: str) -> bool:
        """
        Get mapper types for identity provider

        Args:
            realm (str):  [required]
            alias (str):  [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/identity-provider/instances/{alias}/mapper-types
        """
        url = f"{self.base_url}/{realm}/identity-provider/instances/{alias}/mapper-types"
        response = self.api_client.call_api("GET", url)
        return response.status_code == 200

    def get_mappers(
        self, realm: str, alias: str
    ) -> List[IdentityProviderMapperRepresentation]:
        """
        Get mappers for identity provider

        Args:
            realm (str):  [required]
            alias (str):  [required]

        Returns:
            List[IdentityProviderMapperRepresentation]

        URL:
            Relative path: /{realm}/identity-provider/instances/{alias}/mappers
        """
        url = f"{self.base_url}/{realm}/identity-provider/instances/{alias}/mappers"
        response = self.api_client.call_api("GET", url)
        return [
            IdentityProviderMapperRepresentation.from_dict(item)
            for item in response.json()
        ]

    def post_mappers(
        self,
        realm: str,
        alias: str,
        identity_provider_mapper_representation: IdentityProviderMapperRepresentation,
    ) -> bool:
        """
        Add a mapper to identity provider

        Args:
            realm (str):  [required]
            alias (str):  [required]
            identity_provider_mapper_representation (IdentityProviderMapperRepresentation): Request body data [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/identity-provider/instances/{alias}/mappers
        """
        url = f"{self.base_url}/{realm}/identity-provider/instances/{alias}/mappers"
        response = self.api_client.call_api("POST", url,
            json=identity_provider_mapper_representation.to_dict(),
            )
        return response.status_code == 200

    def get_mapper(
        self, realm: str, alias: str, id: str
    ) -> IdentityProviderMapperRepresentation:
        """
        Get mapper by id for the identity provider

        Args:
            realm (str):  [required]
            alias (str):  [required]
            id (str):  [required]

        Returns:
            IdentityProviderMapperRepresentation

        URL:
            Relative path: /{realm}/identity-provider/instances/{alias}/mappers/{id}
        """
        url = f"{self.base_url}/{realm}/identity-provider/instances/{alias}/mappers/{id}"
        response = self.api_client.call_api("GET", url)
        return IdentityProviderMapperRepresentation.from_dict(response.json())

    def put_mapper(
        self,
        realm: str,
        alias: str,
        id: str,
        identity_provider_mapper_representation: IdentityProviderMapperRepresentation,
    ) -> bool:
        """
        Update a mapper for the identity provider

        Args:
            realm (str):  [required]
            alias (str):  [required]
            id (str):  [required]
            identity_provider_mapper_representation (IdentityProviderMapperRepresentation): Request body data [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/identity-provider/instances/{alias}/mappers/{id}
        """
        url = f"{self.base_url}/{realm}/identity-provider/instances/{alias}/mappers/{id}"
        response = self.api_client.call_api("PUT", url,
            json=identity_provider_mapper_representation.to_dict(),
            )
        return response.status_code == 204

    def delete_mapper(self, realm: str, alias: str, id: str) -> bool:
        """
        Delete a mapper for the identity provider

        Args:
            realm (str):  [required]
            alias (str):  [required]
            id (str):  [required]

        Returns:
            bool

        URL:
            Relative path: /{realm}/identity-provider/instances/{alias}/mappers/{id}
        """
        url = f"{self.base_url}/{realm}/identity-provider/instances/{alias}/mappers/{id}"
        response = self.api_client.call_api("DELETE", url)
        return response.status_code == 204

    def get_identity_provider_provider(
        self, realm: str, provider_id: str
    ) -> Dict[str, Any]:
        """
        Get the identity provider factory for that provider id

        Args:
            realm (str):  [required]
            provider_id (str):  [required]

        Returns:
            Dict[str, Any]

        URL:
            Relative path: /{realm}/identity-provider/providers/{provider_id}
        """
        url = f"{self.base_url}/{realm}/identity-provider/providers/{provider_id}"
        response = self.api_client.call_api("GET", url)
        return response.json()
