import{b as r}from"./graph-BQBI-Io5.js";var e=4;function a(o){return r(o,e)}export{a as c};
