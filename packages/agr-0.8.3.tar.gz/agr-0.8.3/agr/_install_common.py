"""Shared infrastructure for skill and ralph installation.

Data classes, rollback helpers, and utility functions used by both
skill_installer and ralph_installer.
"""

import logging
import shutil
from collections.abc import Callable, Generator
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import NamedTuple

from agr.exceptions import AgrError, RepoNotFoundError
from agr.git import (
    checkout_full,
    checkout_sparse_paths,
    downloaded_repo,
    get_head_commit_full,
    git_list_files,
)
from agr.handle import ParsedHandle, iter_repo_candidates
from agr.metadata import (
    METADATA_KEY_ID,
    METADATA_KEY_TYPE,
    METADATA_TYPE_LOCAL,
    build_handle_id,
    build_handle_ids,
    read_resource_metadata,
    stamp_resource_metadata,
)
from agr.source import SourceConfig, SourceResolver
from agr.tool import ToolConfig

# Ralph installation directory constants
RALPHS_CONFIG_DIR = ".agents"
RALPHS_SUBDIR = "ralphs"

logger = logging.getLogger(__name__)


@dataclass
class InstallResult:
    """Lockfile-relevant metadata captured during skill installation."""

    commit: str | None = None
    content_hash: str | None = None
    source_name: str | None = None


class RemoteDepLocation(NamedTuple):
    """Result of locating a remote dependency across sources."""

    repo_dir: Path
    source_path: Path
    source_config: SourceConfig
    is_legacy: bool
    commit: str | None = None


def copy_resource_to_destination(
    source: Path,
    dest: Path,
    handle: ParsedHandle,
    overwrite: bool,
    repo_root: Path | None,
    kind: str,
    *,
    tool_name: str | None = None,
    install_source: str | None = None,
    post_copy: Callable[[Path], None] | None = None,
) -> Path:
    """Copy a resource (skill or ralph) to its destination with overwrite handling.

    Args:
        source: Source resource directory.
        dest: Destination path.
        handle: Parsed handle for naming.
        overwrite: Whether to overwrite existing.
        repo_root: Repository root for metadata resolution.
        kind: Human-readable resource type for error messages (e.g. "Skill").
        tool_name: Tool name to record in metadata (skills only).
        install_source: Source name to record in metadata.
        post_copy: Optional callback invoked after copying, before metadata stamp.

    Returns:
        Path to installed resource.

    Raises:
        FileExistsError: If resource exists and not overwriting.
    """
    if dest.exists() and not overwrite:
        raise FileExistsError(
            f"{kind} already exists at {dest}. Use --overwrite to replace."
        )

    if dest.exists():
        shutil.rmtree(dest)

    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, dest)

    if post_copy:
        post_copy(dest)

    stamp_resource_metadata(
        dest, handle, repo_root, dest.name, tool_name=tool_name, source=install_source
    )

    return dest


def _dir_matches_handle(dep_dir: Path, handle_ids: list[str]) -> bool:
    """Check whether an installed dependency directory matches a handle via metadata."""
    meta = read_resource_metadata(dep_dir)
    if not meta:
        return False
    return meta.get(METADATA_KEY_ID) in handle_ids


def find_existing_flat_dir(
    handle: ParsedHandle,
    parent_dir: Path,
    repo_root: Path | None,
    source: str | None,
    is_valid_dir: Callable[[Path], bool],
) -> Path | None:
    """Find an existing installed dependency directory (flat layout).

    Checks two candidate paths in priority order:
    1. Plain name (e.g. ``dep/``) — preferred, requires metadata ID match
    2. Full name (e.g. ``user--repo--dep/``) — accepted without metadata
       (covers both current installs and legacy installs without metadata)

    Args:
        handle: Parsed handle identifying the dependency.
        parent_dir: Directory containing installed dependencies.
        repo_root: Repository root for metadata resolution.
        source: Source name for metadata matching.
        is_valid_dir: Callable to check if a directory is a valid dependency.

    Returns:
        Path to existing directory, or None if not found.
    """
    handle_ids = build_handle_ids(handle, repo_root, source)
    name_path = parent_dir / handle.name
    full_path = parent_dir / handle.to_installed_name()

    if is_valid_dir(name_path) and _dir_matches_handle(name_path, handle_ids):
        return name_path

    if is_valid_dir(full_path):
        return full_path

    return None


def find_local_name_conflicts(
    candidates: list[Path],
    handle: ParsedHandle,
    repo_root: Path | None,
    is_valid_dir: Callable[[Path], bool],
) -> tuple[list[Path], bool]:
    """Find conflicting local installs among candidate paths.

    Scans *candidates* for directories that are valid dependencies with
    the same name but a different local identity than *handle*.

    Args:
        candidates: Paths to check for conflicts.
        handle: Parsed handle for the dependency being installed.
        repo_root: Repository root for metadata resolution.
        is_valid_dir: Callable to check if a directory is a valid dependency.

    Returns:
        Tuple of (conflict_paths, has_unknown_metadata).
    """
    handle_id = build_handle_id(handle, repo_root)
    conflicts: list[Path] = []
    has_unknown = False

    for path in candidates:
        if not is_valid_dir(path):
            continue
        meta = read_resource_metadata(path)
        if meta:
            # Remote deps at this path are not local conflicts.
            if meta.get(METADATA_KEY_TYPE) != METADATA_TYPE_LOCAL:
                continue
            # Same local handle — this is us, not a conflict.
            if meta.get(METADATA_KEY_ID) == handle_id:
                continue
            conflicts.append(path)
            continue
        # No metadata means we can't determine ownership — flag it.
        has_unknown = True
        conflicts.append(path)

    return conflicts, has_unknown


def raise_on_local_name_conflict(
    conflicts: list[Path],
    has_unknown: bool,
    handle: ParsedHandle,
    kind: str,
) -> None:
    """Raise AgrError if there are conflicting local installs with the same name.

    Args:
        conflicts: Paths where conflicting installs were found.
        has_unknown: Whether any conflict lacked metadata (ownership unknown).
        handle: Parsed handle for the dependency being installed.
        kind: Human-readable resource type (e.g. "skill", "ralph").
    """
    if not conflicts:
        return
    locations = ", ".join(str(path) for path in conflicts)
    hint = ""
    if has_unknown:
        hint = (
            f" If this is a remote {kind}, run "
            "`agr sync` or reinstall it to "
            "add metadata."
        )
    raise AgrError(
        f"Local {kind} name '{handle.name}' is already installed at {locations}. "
        f"agr allows only one local {kind} with a given name. "
        f"Rename the {kind} or remove the existing one."
        f"{hint}"
    )


def resolve_flat_destination(
    handle: ParsedHandle,
    parent_dir: Path,
    repo_root: Path | None,
    source: str | None,
    is_valid_dir: Callable[[Path], bool],
) -> Path:
    """Resolve the destination path for installing a dependency (flat layout).

    Resolution order:
    1. If the dependency is already installed (any name form), reuse that path.
    2. If the plain name (e.g. ``dep/``) is free, use it.
    3. If the plain name is taken by a *different* dependency, fall back to the
       fully qualified name (e.g. ``user--repo--dep/``).

    Args:
        handle: Parsed handle identifying the dependency.
        parent_dir: Directory containing installed dependencies.
        repo_root: Repository root for metadata resolution.
        source: Source name for metadata matching.
        is_valid_dir: Callable to check if a directory is a valid dependency.

    Returns:
        Resolved destination path.
    """
    existing = find_existing_flat_dir(
        handle, parent_dir, repo_root, source, is_valid_dir
    )
    if existing:
        return existing

    name_path = parent_dir / handle.name
    if is_valid_dir(name_path):
        return parent_dir / handle.to_installed_name()

    return name_path


def dep_not_found_message(kind: str, name: str, marker: str, subdir: str) -> str:
    """Build a user-friendly message for a missing dependency in a repository."""
    return (
        f"{kind} '{name}' not found in repository.\n"
        f"No directory named '{name}' containing {marker} was found.\n"
        f"Hint: Create a {kind.lower()} at '{subdir}/{name}/{marker}' or '{name}/{marker}'"
    )


def prepare_local_handle(
    source_path: Path,
    handle: ParsedHandle | None,
    repo_root: Path | None,
) -> tuple[ParsedHandle, Path]:
    """Ensure handle and repo_root are set for local installations.

    Creates a local ParsedHandle from the source path name if not
    provided, and defaults repo_root to the current working directory.

    Args:
        source_path: Path to the local resource directory.
        handle: Optional pre-parsed handle; built from source_path if None.
        repo_root: Repository root; defaults to cwd if None.

    Returns:
        Tuple of (resolved handle, resolved repo_root).
    """
    handle = handle or ParsedHandle(
        is_local=True, name=source_path.name, local_path=source_path
    )
    repo_root = repo_root if repo_root is not None else Path.cwd()
    return handle, repo_root


def check_self_install(
    source_path: Path,
    default_dest: Path,
    handle: ParsedHandle,
    repo_root: Path,
    is_valid_dir: Callable[[Path], bool],
    tool_name: str | None = None,
) -> Path | None:
    """Detect self-install and stamp metadata if needed.

    A "self-install" occurs when the source path IS the default
    destination (e.g. ``agr add ./skills/my-skill`` when ``skills/``
    is the tool's skills directory).  In this case copying is skipped;
    only metadata is stamped if missing.

    Args:
        source_path: Path to the local resource directory.
        default_dest: The computed default install destination.
        handle: Parsed handle for metadata.
        repo_root: Repository root for metadata resolution.
        is_valid_dir: Callable to verify the directory is a valid resource.
        tool_name: Tool name to record in metadata (skills only).

    Returns:
        The destination path if this is a self-install, None otherwise.
    """
    if source_path.resolve() != default_dest.resolve():
        return None
    if not is_valid_dir(default_dest):
        return None
    if read_resource_metadata(default_dest) is None:
        stamp_resource_metadata(
            default_dest, handle, repo_root, default_dest.name, tool_name=tool_name
        )
    return default_dest


def resolve_skills_dir(
    skills_dir: Path | None, repo_root: Path | None, tool: ToolConfig
) -> Path:
    """Resolve skills directory from explicit path or repo_root + tool config.

    Args:
        skills_dir: Explicit skills directory, if provided.
        repo_root: Repository root path (project installs) or None (global installs).
        tool: Tool configuration for deriving the skills directory.

    Returns:
        Resolved skills directory path.

    Raises:
        AgrError: If both skills_dir and repo_root are None.
    """
    if skills_dir is not None:
        return skills_dir
    if repo_root is None:
        raise AgrError("repo_root is required when skills_dir is not provided")
    return tool.get_skills_dir(repo_root)


def _rollback_installed(installed: dict[str, Path]) -> None:
    """Remove installed skill dirs to roll back partial installs."""
    for tool_name, rollback_path in installed.items():
        try:
            shutil.rmtree(rollback_path)
        except OSError as e:
            logger.warning(f"Failed to rollback {tool_name} at {rollback_path}: {e}")


@contextmanager
def rollback_on_failure() -> Generator[dict[str, Path], None, None]:
    """Track installed paths and roll back all on failure.

    Yields a dict that callers populate with {tool_name: path} entries.
    If an exception propagates out, all recorded installs are removed.
    """
    installed: dict[str, Path] = {}
    try:
        yield installed
    except Exception:
        _rollback_installed(installed)
        raise


@contextmanager
def locate_remote_dep(
    handle: ParsedHandle,
    prepare_fn: Callable[[Path, str], Path | None],
    not_found_error_cls: type[Exception],
    dep_kind: str,
    resolver: SourceResolver | None = None,
    source: str | None = None,
    default_repo: str | None = None,
) -> Generator[RemoteDepLocation, None, None]:
    """Search for a remote dependency across sources and repo candidates.

    Downloads the repository and prepares the dependency, keeping the temp
    directory alive while the caller processes the result.

    Args:
        handle: Parsed handle identifying the dependency.
        prepare_fn: Callable(repo_dir, name) -> Path | None to locate the
            dependency inside a checked-out repo.
        not_found_error_cls: Exception class to raise when not found.
        dep_kind: Human-readable label for error messages (e.g. "Skill").
        resolver: Source resolver for finding the repo.
        source: Explicit source name.
        default_repo: Default repo name fallback.

    Yields:
        RemoteDepLocation with repo_dir, source_path, source_config, is_legacy.
    """
    resolver = resolver or SourceResolver.default()
    owner = handle.username or ""

    for repo_name, is_legacy in iter_repo_candidates(handle.repo, default_repo):
        for source_config in resolver.ordered(source):
            try:
                with downloaded_repo(source_config, owner, repo_name) as repo_dir:
                    dep_source = prepare_fn(repo_dir, handle.name)
                    if dep_source is None:
                        continue
                    try:
                        commit = get_head_commit_full(repo_dir)
                    except AgrError:
                        commit = None
                    yield RemoteDepLocation(
                        repo_dir=repo_dir,
                        source_path=dep_source,
                        source_config=source_config,
                        is_legacy=is_legacy,
                        commit=commit,
                    )
                    return
            except RepoNotFoundError:
                if source is not None:
                    raise
                continue

    raise not_found_error_cls(
        f"{dep_kind} '{handle.name}' not found in sources: "
        f"{', '.join(s.name for s in resolver.ordered(source))}"
    )


def prepare_repo_for_deps(
    repo_dir: Path,
    dep_names: list[str],
    find_in_listing: Callable[[list[str], list[str]], dict[str, PurePosixPath]],
    find_in_repo: Callable[[Path, str], Path | None],
    dep_kind: str,
) -> dict[str, Path]:
    """Prepare a repo so multiple dependency paths are checked out.

    Generic implementation shared by skill and ralph installers.

    Args:
        repo_dir: Path to the downloaded repository.
        dep_names: Names of dependencies to locate.
        find_in_listing: Callable(file_paths, names) -> {name: rel_dir}.
        find_in_repo: Callable(repo_dir, name) -> Path | None (filesystem fallback).
        dep_kind: Human-readable label for error messages (e.g. "skill").

    Returns:
        Mapping of dependency name to resolved path for those found.
    """
    unique_names = list(dict.fromkeys(dep_names))
    if not unique_names:
        return {}

    try:
        paths = git_list_files(repo_dir)
        rel_paths = {
            name: Path(d) for name, d in find_in_listing(paths, unique_names).items()
        }

        if rel_paths:
            checkout_sparse_paths(repo_dir, list(rel_paths.values()))
            resolved = {
                name: repo_dir / rel_path for name, rel_path in rel_paths.items()
            }
            for path in resolved.values():
                if not path.exists():
                    raise AgrError(f"Failed to checkout {dep_kind} path.")
            return resolved

        return {}
    except AgrError:
        checkout_full(repo_dir)
        resolved_dict: dict[str, Path] = {}
        for name in unique_names:
            dep_path = find_in_repo(repo_dir, name)
            if dep_path is not None:
                resolved_dict[name] = dep_path
        return resolved_dict


def list_remote_repo_deps(
    owner: str,
    repo_name: str,
    discover_in_listing: Callable[[list[str]], list[str]],
    resolver: SourceResolver | None = None,
    source: str | None = None,
) -> list[str]:
    """List all dependency names of a given kind in a remote repository.

    Generic implementation shared by skill and ralph installers.

    Args:
        owner: Repository owner/username.
        repo_name: Repository name.
        discover_in_listing: Callable(file_paths) -> sorted list of names.
        resolver: Source resolver for finding the repo.
        source: Explicit source name.

    Returns:
        Sorted list of names found, or empty list on any error.
    """
    resolver = resolver or SourceResolver.default()
    for source_config in resolver.ordered(source):
        try:
            with downloaded_repo(source_config, owner, repo_name) as repo_dir:
                paths = git_list_files(repo_dir)
                return discover_in_listing(paths)
        except AgrError:
            continue
    return []


def cleanup_empty_parents(path: Path, stop_at: Path) -> None:
    """Remove empty parent directories up to stop_at.

    Args:
        path: Starting path to clean
        stop_at: Directory to stop at (not removed)
    """
    # Resolve symlinks to ensure proper path comparison
    path = path.resolve()
    stop_at = stop_at.resolve()
    current = path

    while current != stop_at and current.exists():
        # Safety: ensure we're still within stop_at
        if not current.is_relative_to(stop_at):
            break

        if current.is_dir() and not any(current.iterdir()):
            try:
                current.rmdir()
            except OSError:
                break  # Permission error or other issue
            current = current.parent
        else:
            break
