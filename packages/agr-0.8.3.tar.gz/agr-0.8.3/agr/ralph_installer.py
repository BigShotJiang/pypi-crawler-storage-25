"""Ralph installation, uninstallation, and query operations.

Handles local and remote ralph installation, repo preparation,
destination resolution, and ralph lifecycle management.
"""

import shutil
from contextlib import contextmanager
from pathlib import Path
from collections.abc import Generator

from agr._install_common import (
    InstallResult,
    RALPHS_CONFIG_DIR,
    RALPHS_SUBDIR,
    RemoteDepLocation,
    check_self_install,
    copy_resource_to_destination,
    dep_not_found_message,
    find_existing_flat_dir,
    find_local_name_conflicts,
    locate_remote_dep,
    prepare_local_handle,
    prepare_repo_for_deps,
    raise_on_local_name_conflict,
    resolve_flat_destination,
    rollback_on_failure,
)
from agr.exceptions import (
    AgrError,
    InvalidLocalPathError,
    RalphNotFoundError,
)
from agr.handle import (
    INSTALLED_NAME_SEPARATOR,
    ParsedHandle,
    warn_legacy_repo,
)
from agr.metadata import compute_content_hash
from agr.ralph import (
    RALPH_MARKER,
    find_ralph_in_repo,
    find_ralphs_in_repo_listing,
    is_valid_ralph_dir,
)
from agr.source import SourceResolver


# ---------------------------------------------------------------------------
# Directory helper
# ---------------------------------------------------------------------------


def get_ralphs_dir(repo_root: Path) -> Path:
    """Return the project-level ralphs directory."""
    return repo_root / RALPHS_CONFIG_DIR / RALPHS_SUBDIR


# ---------------------------------------------------------------------------
# Resolution helpers
# ---------------------------------------------------------------------------


def _find_existing_ralph_dir(
    handle: ParsedHandle,
    ralphs_dir: Path,
    repo_root: Path | None,
    source: str | None = None,
) -> Path | None:
    """Find an existing installed ralph directory for this handle."""
    return find_existing_flat_dir(
        handle, ralphs_dir, repo_root, source, is_valid_ralph_dir
    )


def _resolve_ralph_destination(
    handle: ParsedHandle,
    ralphs_dir: Path,
    repo_root: Path | None,
    source: str | None = None,
) -> Path:
    """Resolve the destination path for installing a ralph."""
    return resolve_flat_destination(
        handle, ralphs_dir, repo_root, source, is_valid_ralph_dir
    )


# ---------------------------------------------------------------------------
# Copy & error messages
# ---------------------------------------------------------------------------


def _copy_ralph_to_destination(
    source: Path,
    dest: Path,
    handle: ParsedHandle,
    overwrite: bool,
    repo_root: Path | None,
    install_source: str | None = None,
) -> Path:
    """Copy ralph source to destination with overwrite handling."""
    return copy_resource_to_destination(
        source,
        dest,
        handle,
        overwrite,
        repo_root,
        kind="Ralph",
        install_source=install_source,
    )


def ralph_not_found_message(name: str) -> str:
    """Build a user-friendly message for a missing ralph in a repository."""
    return dep_not_found_message("Ralph", name, RALPH_MARKER, "ralphs")


# ---------------------------------------------------------------------------
# Repo preparation
# ---------------------------------------------------------------------------


def prepare_repo_for_ralph(repo_dir: Path, ralph_name: str) -> Path | None:
    """Prepare a repo so that only the ralph path is checked out."""
    result = prepare_repo_for_ralphs(repo_dir, [ralph_name])
    return result.get(ralph_name)


def prepare_repo_for_ralphs(repo_dir: Path, ralph_names: list[str]) -> dict[str, Path]:
    """Prepare a repo so multiple ralph paths are checked out."""
    return prepare_repo_for_deps(
        repo_dir, ralph_names, find_ralphs_in_repo_listing, find_ralph_in_repo, "ralph"
    )


# ---------------------------------------------------------------------------
# Install orchestration
# ---------------------------------------------------------------------------


def install_ralph_from_repo(
    repo_dir: Path,
    ralph_name: str,
    handle: ParsedHandle,
    ralphs_dir: Path,
    repo_root: Path | None,
    overwrite: bool = False,
    install_source: str | None = None,
    ralph_source: Path | None = None,
) -> Path:
    """Install a ralph from a downloaded repository."""
    if ralph_source is None:
        ralph_source = find_ralph_in_repo(repo_dir, ralph_name)
    if ralph_source is None:
        raise RalphNotFoundError(ralph_not_found_message(ralph_name))

    ralph_dest = _resolve_ralph_destination(
        handle, ralphs_dir, repo_root, install_source
    )

    return _copy_ralph_to_destination(
        ralph_source, ralph_dest, handle, overwrite, repo_root, install_source
    )


def _find_local_ralph_name_conflicts(
    handle: ParsedHandle,
    ralphs_dir: Path,
    repo_root: Path | None,
) -> tuple[list[Path], bool]:
    """Find conflicting local installs with the same ralph name.

    Returns a tuple of (conflict_paths, has_unknown_metadata).
    """
    candidates = [ralphs_dir / handle.name, ralphs_dir / handle.to_installed_name()]

    return find_local_name_conflicts(candidates, handle, repo_root, is_valid_ralph_dir)


def install_local_ralph(
    source_path: Path,
    ralphs_dir: Path,
    overwrite: bool = False,
    repo_root: Path | None = None,
    handle: ParsedHandle | None = None,
) -> Path:
    """Install a local ralph."""
    if not is_valid_ralph_dir(source_path):
        raise RalphNotFoundError(
            f"'{source_path}' is not a valid ralph (missing {RALPH_MARKER})"
        )

    if INSTALLED_NAME_SEPARATOR in source_path.name:
        raise AgrError(
            f"Ralph name '{source_path.name}' contains "
            f"reserved sequence '{INSTALLED_NAME_SEPARATOR}'"
        )

    handle, repo_root = prepare_local_handle(source_path, handle, repo_root)

    # Self-install case: source path IS the install destination.
    default_dest = ralphs_dir / handle.name
    self_installed = check_self_install(
        source_path,
        default_dest,
        handle,
        repo_root,
        is_valid_ralph_dir,
    )
    if self_installed is not None:
        return self_installed

    conflicts, has_unknown = _find_local_ralph_name_conflicts(
        handle, ralphs_dir, repo_root
    )
    raise_on_local_name_conflict(conflicts, has_unknown, handle, "ralph")

    ralph_dest = _resolve_ralph_destination(handle, ralphs_dir, repo_root)

    return _copy_ralph_to_destination(
        source_path, ralph_dest, handle, overwrite, repo_root
    )


@contextmanager
def _locate_remote_ralph(
    handle: ParsedHandle,
    resolver: SourceResolver | None = None,
    source: str | None = None,
    default_repo: str | None = None,
) -> Generator[RemoteDepLocation, None, None]:
    """Search for a remote ralph across sources and repo candidates."""
    with locate_remote_dep(
        handle,
        prepare_repo_for_ralph,
        RalphNotFoundError,
        "Ralph",
        resolver,
        source,
        default_repo,
    ) as loc:
        yield loc


def fetch_and_install_ralph(
    handle: ParsedHandle,
    repo_root: Path | None,
    overwrite: bool = False,
    resolver: SourceResolver | None = None,
    source: str | None = None,
    default_repo: str | None = None,
) -> tuple[Path, InstallResult]:
    """Fetch and install a ralph to the project-level ralphs directory.

    Returns:
        Tuple of (installed path, InstallResult with lockfile metadata).
    """
    if repo_root is None:
        raise AgrError("repo_root is required for ralph installation")

    ralphs_dir = get_ralphs_dir(repo_root)

    if handle.is_local:
        if handle.local_path is None:
            raise InvalidLocalPathError("Local handle missing path")
        source_path = handle.resolve_local_path(repo_root)
        resolved_handle = ParsedHandle(
            is_local=True, name=handle.name, local_path=source_path
        )
        path = install_local_ralph(
            source_path, ralphs_dir, overwrite, repo_root, resolved_handle
        )
        return path, InstallResult()

    install_result = InstallResult()
    with (
        rollback_on_failure() as installed,
        _locate_remote_ralph(handle, resolver, source, default_repo) as loc,
    ):
        if loc.is_legacy:
            warn_legacy_repo()
        path = install_ralph_from_repo(
            loc.repo_dir,
            handle.name,
            handle,
            ralphs_dir,
            repo_root,
            overwrite,
            install_source=loc.source_config.name,
            ralph_source=loc.source_path,
        )
        installed["ralph"] = path
        content_hash = compute_content_hash(path)
        install_result = InstallResult(
            commit=loc.commit,
            content_hash=content_hash,
            source_name=loc.source_config.name,
        )
    return path, install_result


# ---------------------------------------------------------------------------
# Uninstall & query
# ---------------------------------------------------------------------------


def uninstall_ralph(
    handle: ParsedHandle,
    repo_root: Path | None,
    source: str | None = None,
) -> bool:
    """Uninstall a ralph from the project-level ralphs directory."""
    if repo_root is None:
        return False
    ralphs_dir = get_ralphs_dir(repo_root)
    ralph_path = _find_existing_ralph_dir(handle, ralphs_dir, repo_root, source)
    if not ralph_path:
        return False
    shutil.rmtree(ralph_path)
    return True


def is_ralph_installed(
    handle: ParsedHandle,
    repo_root: Path | None,
    source: str | None = None,
) -> bool:
    """Check if a ralph is installed."""
    if repo_root is None:
        return False
    ralphs_dir = get_ralphs_dir(repo_root)
    return _find_existing_ralph_dir(handle, ralphs_dir, repo_root, source) is not None
