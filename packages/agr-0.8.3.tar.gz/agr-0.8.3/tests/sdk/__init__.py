"""SDK tests package."""
