---
title: "Resource Directory — Browse and Install AI Agent Resources for Claude Code, Cursor, Codex, and More"
description: Browse official and community AI agent resources available for agr — PDF, frontend design, API integration, Go, Drupal, and more. Install into Claude Code, Cursor, Codex, OpenCode, Copilot, or Antigravity with one command.
keywords:
  - agr resource directory
  - AI agent resources list
  - browse AI agent resources
  - Claude Code skills directory
  - Cursor skills directory
  - Codex skills directory
  - OpenCode skills
  - GitHub Copilot skills
  - Antigravity skills
  - install AI agent resources
  - PDF skill agr
  - frontend design skill
  - community AI resources
  - SKILL.md
---

# Skill Directory

!!! tldr
    **Official skills** from Anthropic cover documents (PDF, DOCX, XLSX, PPTX),
    design, frontend, API integration, and productivity. **Community skills** add
    Go, Drupal, workflow automation, and more. Try any skill instantly with
    `agrx user/skill` or install with `agr add user/skill`.

Browse available skills and find ones that fit your workflow. Every skill below
works with all [supported tools](tools.md) — Claude Code, Cursor, Codex,
OpenCode, GitHub Copilot, and Antigravity — and can be tried instantly without
installing using [`agrx`](agrx.md):

**Key terms:** A **skill** is a directory containing a `SKILL.md` file with
YAML frontmatter (`name`, `description`) and markdown instructions for an AI
coding agent. A **[handle](concepts.md#handles)** like `anthropics/skills/pdf`
identifies a skill on GitHub. Install permanently with
[`agr add`](reference.md#agr-add) or run once with [`agrx`](agrx.md).

```bash
agrx anthropics/skills/pdf -p "Extract tables from report.pdf"
```

---

## Official Skills

Maintained by Anthropic in the [anthropics/skills](https://github.com/anthropics/skills) repository.

### Documents & Data

| Skill | Description | Install |
|-------|-------------|---------|
| PDF | Read, extract, create, and modify PDF files | `agr add anthropics/skills/pdf` |
| DOCX | Create, read, edit, and manipulate Word documents | `agr add anthropics/skills/docx` |
| PPTX | Create and work with PowerPoint slide decks | `agr add anthropics/skills/pptx` |
| XLSX | Create and manipulate spreadsheet files | `agr add anthropics/skills/xlsx` |
| Doc Co-authoring | Structured workflow for co-authoring documentation | `agr add anthropics/skills/doc-coauthoring` |

### Design & Frontend

| Skill | Description | Install |
|-------|-------------|---------|
| Frontend Design | Build distinctive, production-grade frontend interfaces | `agr add anthropics/skills/frontend-design` |
| Canvas Design | Create visual art in PNG and PDF using design principles | `agr add anthropics/skills/canvas-design` |
| Algorithmic Art | Create algorithmic art with p5.js and seeded randomness | `agr add anthropics/skills/algorithmic-art` |
| Theme Factory | Style artifacts (slides, docs, landing pages) with themes | `agr add anthropics/skills/theme-factory` |
| Brand Guidelines | Apply Anthropic's official brand colors and typography | `agr add anthropics/skills/brand-guidelines` |

### Development

| Skill | Description | Install |
|-------|-------------|---------|
| Claude API | Build apps with the Claude API and Anthropic SDKs | `agr add anthropics/skills/claude-api` |
| MCP Builder | Create MCP servers for LLM-to-service interaction | `agr add anthropics/skills/mcp-builder` |
| Web Artifacts Builder | Create multi-component HTML artifacts with modern frontend tech | `agr add anthropics/skills/web-artifacts-builder` |
| Webapp Testing | Test local web applications using Playwright | `agr add anthropics/skills/webapp-testing` |

### Productivity

| Skill | Description | Install |
|-------|-------------|---------|
| Skill Creator | Create, modify, and improve skills | `agr add anthropics/skills/skill-creator` |
| Internal Comms | Write internal communications in your company's formats | `agr add anthropics/skills/internal-comms` |
| Slack GIF Creator | Create animated GIFs optimized for Slack | `agr add anthropics/skills/slack-gif-creator` |

Browse the full list at [github.com/anthropics/skills](https://github.com/anthropics/skills).

---

## Community Skills

Skills built and shared by the community.

### Go

| Skill | Description | Author | Install |
|-------|-------------|--------|---------|
| Go Pro | Expert Go 1.21+ development for concurrent, scalable systems | [@dsjacobsen](https://github.com/dsjacobsen) | `agr add dsjacobsen/agent-resources/golang-pro` |

### Drupal

| Skill | Description | Author | Install |
|-------|-------------|--------|---------|
| Drupal Expert | Drupal 10/11 modules, themes, hooks, services, and config | [@madsnorgaard](https://github.com/madsnorgaard) | `agr add madsnorgaard/drupal-agent-resources/drupal-expert` |
| Drupal Security | Prevent XSS, SQL injection, and access bypass in Drupal | [@madsnorgaard](https://github.com/madsnorgaard) | `agr add madsnorgaard/drupal-agent-resources/drupal-security` |
| Drupal Migration | D7-to-D10 migrations, CSV imports, and migration plugins | [@madsnorgaard](https://github.com/madsnorgaard) | `agr add madsnorgaard/drupal-agent-resources/drupal-migration` |
| DDEV Expert | DDEV local development, containers, and configuration | [@madsnorgaard](https://github.com/madsnorgaard) | `agr add madsnorgaard/drupal-agent-resources/ddev-expert` |
| Docker Local | Docker Compose local development patterns | [@madsnorgaard](https://github.com/madsnorgaard) | `agr add madsnorgaard/drupal-agent-resources/docker-local` |

### Workflow

| Skill | Description | Author | Install |
|-------|-------------|--------|---------|
| Collaboration | Contributing to GitHub projects, PRs, and code reviews | [@maragudk](https://github.com/maragudk) | `agr add maragudk/skills/collaboration` |
| Code Review | Guide for making code reviews | [@maragudk](https://github.com/maragudk) | `agr add maragudk/skills/code-review` |

---

## Discovering More Skills

### Search GitHub

Any GitHub repository with a [`SKILL.md`](creating.md#skillmd-format) file can be installed as a [handle](concepts.md#handles):

- [Search for SKILL.md files on GitHub](https://github.com/search?q=filename%3ASKILL.md&type=code)

### List skills in a repository

Use the [Python SDK](sdk.md) to list all skills in any repo:

```python
from agr import list_skills, skill_info

for info in list_skills("anthropics/skills"):
    details = skill_info(info.handle)
    print(f"{details.handle}: {details.description}")
```

!!! note
    `list_skills()` discovers skills without downloading each `SKILL.md`, so
    `description` is `None`. Use `skill_info()` to fetch the description for
    a specific skill.

Or check a repo manually — agr looks for any directory containing a `SKILL.md`
file.

### Try before you install

Use [`agrx`](agrx.md) to run any skill without adding it to your project:

```bash
agrx anthropics/skills/webapp-testing
agrx anthropics/skills/pdf -i   # Interactive: continue chatting after the skill runs
```

---

## Share Your Own Skills

### 1. Create a skill

```bash
agr init my-skill
```

Edit the generated `my-skill/SKILL.md` with your instructions. See [`agr init`](reference.md#agr-init) for all options.

### 2. Push to GitHub

Push your skill to a GitHub repository. The recommended structure is a repo named `skills` with one directory per skill:

```text
your-username/skills/
├── my-skill/
│   └── SKILL.md
└── another-skill/
    └── SKILL.md
```

Others can then install with:

```bash
agr add your-username/my-skill
```

### 3. List it here

Open an issue at [github.com/computerlovetech/agr](https://github.com/computerlovetech/agr/issues) to get your skill added to this directory. For [team-wide sharing](teams.md), you can also use a private repository with [`agr.toml`](configuration.md).

See [Creating Skills](creating.md) for a full guide on writing effective skills.

---

## Next Steps

- [Tutorial](tutorial.md) — Get started with agr from scratch
- [Creating Skills](creating.md) — Write and publish your own skills
- [Try Skills with agrx](agrx.md) — Run any skill instantly without installing
- [Python SDK](sdk.md) — Discover and manage skills programmatically
- [Troubleshooting](troubleshooting.md) — Fix install errors and common issues
- [What's New](changelog.md) — Latest skill support and feature updates
