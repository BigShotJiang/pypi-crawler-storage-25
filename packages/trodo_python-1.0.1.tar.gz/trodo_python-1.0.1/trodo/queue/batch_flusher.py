"""Background timer-based batch flusher."""

from __future__ import annotations

import threading
from typing import Optional

from .event_queue import EventQueue


class BatchFlusher:
    def __init__(
        self,
        queue: EventQueue,
        http_client: object,
        flush_interval: float,
    ) -> None:
        self._queue = queue
        self._http = http_client
        self._flush_interval = flush_interval
        self._timer: Optional[threading.Timer] = None
        self._lock = threading.Lock()

    def start(self) -> None:
        self._reschedule()

    def stop(self) -> None:
        with self._lock:
            if self._timer:
                self._timer.cancel()
                self._timer = None

    def flush(self) -> None:
        events = self._queue.drain()
        if not events:
            return
        self._http.post_bulk_events(events)  # type: ignore[attr-defined]

    def _reschedule(self) -> None:
        with self._lock:
            if self._timer:
                self._timer.cancel()
            t = threading.Timer(self._flush_interval, self._tick)
            t.daemon = True
            t.start()
            self._timer = t

    def _tick(self) -> None:
        try:
            self.flush()
        finally:
            self._reschedule()
