"""Server session creation utilities."""

from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from ..types import ServerSession


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def create_server_session(
    site_id: str,
    distinct_id: str,
    session_id: Optional[str] = None,
) -> ServerSession:
    return ServerSession(
        session_id=session_id or str(uuid.uuid4()),
        site_id=site_id,
        distinct_id=distinct_id,
        start_time=now_iso(),
        last_activity=time.time(),
        confirmed=False,
    )


def build_session_payload(session: ServerSession) -> Dict[str, Any]:
    return {
        "session_id": session.session_id,
        "site_id": session.site_id,
        "user_id": session.distinct_id,
        "distinct_id": session.distinct_id,
        "team_id": None,
        "start_time": session.start_time,
        "end_time": None,
        "last_activity": int(session.last_activity * 1000),
        "duration": 0,
        "pages_viewed": 0,
        "is_bounce": False,
        "previous_session_id": None,
        "time_since_last_session": None,
        "entry_page": None,
        "exit_page": None,
        "referrer": "server",
        "ip_address": None,
        "city": None,
        "region": None,
        "country": None,
        "browser_name": None,
        "browser_version": None,
        "device_type": "server",
        "os": None,
        "resolution": None,
        "user_agent": None,
        "language": None,
        "wallet_address": None,
        "wallet_type": None,
        "chain_name": None,
        "is_web3_user": False,
        "wallet_connected": False,
        "utm_source": None,
        "utm_medium": None,
        "utm_campaign": None,
        "utm_term": None,
        "utm_content": None,
        "utm_id": None,
        "visited_pages": [],
        "active_time_ms": 0,
    }
