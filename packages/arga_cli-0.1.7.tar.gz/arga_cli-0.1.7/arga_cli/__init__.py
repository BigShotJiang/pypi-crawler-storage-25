"""Arga CLI package."""
