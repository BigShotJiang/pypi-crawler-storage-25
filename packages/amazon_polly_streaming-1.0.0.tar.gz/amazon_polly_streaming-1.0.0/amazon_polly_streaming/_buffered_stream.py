"""Writable, non-blocking byte stream used as HTTP/2 request body channel.

`awscrt`'s HTTP/2 client reads the request body from a file-like object on its
own I/O thread, calling `read(size)` repeatedly until the stream signals EOF.
For bidirectional streaming we want to write events to the body channel
incrementally from the application's asyncio thread, after the request has
already been opened.

`BufferableByteStream` exposes that pattern by behaving as a non-blocking
file-like object: `read` raises `BlockingIOError` when no data is currently
available, signalling `awscrt` to retry later; once `end_stream` is called and
all buffered chunks have been read, `read` returns `b""` (EOF) and the HTTP/2
stream is closed cleanly.

Pattern adapted from the `amazon-transcribe-streaming-sdk` Python package
(Apache 2.0), which uses the same approach with `awscrt`.
"""

from __future__ import annotations

from io import BufferedIOBase


class BufferableByteStream(BufferedIOBase):
    """Non-blocking, append-only byte buffer for HTTP/2 request body channels."""

    def __init__(self) -> None:
        """Initialize an empty, open stream."""
        self._chunks: list[bytes] = []
        self._done: bool = False
        self._closed: bool = False

    def read(self, size: int | None = -1) -> bytes:
        """Return up to `size` bytes; raise `BlockingIOError` if no data is buffered.

        Args:
            size: Maximum number of bytes to return. ``-1`` or ``None`` means
                "the next chunk in full".

        Returns:
            Bytes consumed from the head of the buffer. ``b""`` once the
            stream has been ended (`end_stream`) and fully drained.

        Raises:
            BlockingIOError: when the stream is still open but no data has
                been written yet. The caller (`awscrt` in production) is
                expected to retry later.
        """
        if not self._chunks:
            if self._done or self._closed:
                return b""
            msg = "no data buffered yet"
            raise BlockingIOError(msg)

        chunk = self._chunks.pop(0)
        if size is None or size < 0 or size >= len(chunk):
            return chunk
        leftover = chunk[size:]
        self._chunks.insert(0, leftover)
        return chunk[:size]

    def read1(self, size: int = -1) -> bytes:
        """Read at most `size` bytes; same semantics as `read`."""
        return self.read(size)

    def write(self, b: bytes) -> int:  # pyright: ignore[reportIncompatibleMethodOverride]
        """Append `b` to the buffer; return the number of bytes accepted.

        Args:
            b: Bytes to append. Non-bytes input raises `TypeError`.

        Returns:
            ``len(b)``.

        Raises:
            TypeError: if `b` is not exactly `bytes`.
            OSError: if the stream has already been ended or closed.
        """
        if not isinstance(b, bytes):  # pyright: ignore[reportUnnecessaryIsInstance]
            msg = f"BufferableByteStream.write requires bytes, got {type(b).__name__}"
            raise TypeError(msg)
        if self._done or self._closed:
            msg = "stream is closed"
            raise OSError(msg)
        if b:
            self._chunks.append(b)
        return len(b)

    def end_stream(self) -> None:
        """Mark the stream as ended; future writes raise, future reads drain then return `b""`."""
        self._done = True

    def close(self) -> None:
        """Close the stream and discard any buffered data."""
        self._chunks = []
        self._done = True
        self._closed = True

    @property
    def closed(self) -> bool:
        """True if `close` has been called."""
        return self._closed
