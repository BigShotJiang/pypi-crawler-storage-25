"""Amazon Polly bidirectional streaming over HTTP/2 with SigV4."""

from amazon_polly_streaming.client import PollyStreamingClient
from amazon_polly_streaming.exceptions import (
    ServiceException,
    ServiceFailureException,
    ServiceQuotaExceededException,
    ThrottlingException,
    ValidationException,
)

__all__ = [
    "PollyStreamingClient",
    "ServiceException",
    "ServiceFailureException",
    "ServiceQuotaExceededException",
    "ThrottlingException",
    "ValidationException",
]
__version__ = "1.0.0"
