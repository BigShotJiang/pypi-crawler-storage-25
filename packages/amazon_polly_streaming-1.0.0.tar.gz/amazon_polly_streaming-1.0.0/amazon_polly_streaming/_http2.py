"""HTTP/2 streaming client wrapping the AWS Common Runtime (`awscrt`).

Opens an HTTP/2 connection (ALPN-negotiated), SigV4-signs the initial request
with an empty body (since chunks are signed independently), and returns a
`StreamHandle` exposing:

* the SigV4 signature of the initial request (32 raw bytes), used as the seed
  of the rolling chunk-signature chain by the caller;
* a writable `BufferableByteStream` body channel, where the caller appends
  signed event-stream messages as they become available;
* an async iterator over response body chunks (Polly's outbound event stream).

Pattern inspired by amazon-transcribe (Apache 2.0): in particular the
callback-to-async-generator wrapper around the awscrt HTTP stream, the
bootstrap/TLS/connect dance, and the writable body channel for incremental
events.
"""

# pyright: reportUnknownMemberType=false, reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false, reportUnknownParameterType=false
# pyright: reportMissingParameterType=false, reportUnknownLambdaType=false
# pyright: reportAttributeAccessIssue=false, reportArgumentType=false
# pyright: reportUnnecessaryComparison=false
# Rationale: awscrt ships no type stubs and its inline annotations are
# incomplete (e.g. `new_connection_options()` is annotated as returning the
# wrong type, `HttpClientStream` attributes are not exposed). Suppressing the
# resulting noise is scoped to this module only; the public surface
# (`stream_request`) remains fully typed.
from __future__ import annotations

import asyncio
from concurrent.futures import Future
from dataclasses import dataclass
from threading import Lock
from typing import TYPE_CHECKING
from urllib.parse import urlparse

from awscrt import io
from awscrt.auth import (
    AwsCredentialsProvider,
    AwsSignatureType,
    AwsSignedBodyHeaderType,
    AwsSignedBodyValue,
    AwsSigningAlgorithm,
    AwsSigningConfig,
    aws_sign_request,
)
from awscrt.http import HttpClientConnection, HttpHeaders, HttpRequest

from amazon_polly_streaming._buffered_stream import BufferableByteStream
from amazon_polly_streaming._connection_pool import _connect  # pyright: ignore[reportPrivateUsage]

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Mapping

_HTTPS_PORT = 443
_HTTP_OK_MIN = 200
_HTTP_OK_MAX = 300
_ERROR_BODY_CAP = 4096


class _ResponseCollector:
    """Bridge awscrt's callback-driven stream into an async generator.

    Headers/body callbacks fire from the awscrt I/O thread; we hand chunks to
    the asyncio loop via `concurrent.futures.Future` + `asyncio.wrap_future`.
    """

    def __init__(self) -> None:
        self._status_future: Future[int] = Future()
        self._chunk_futures: list[Future[bytes]] = []
        self._received_chunks: list[bytes] = []
        self._lock = Lock()
        self._stream: object = None

    def attach(self, stream: object) -> None:
        """Bind the stream and arrange the completion callback."""
        self._stream = stream
        stream.completion_future.add_done_callback(self._on_complete)
        stream.activate()

    def on_headers(self, status_code: int, headers, **_kwargs: object) -> None:  # noqa: ANN001
        """`awscrt` headers callback. `headers` is unused; kept for signature."""
        del headers
        if not self._status_future.done():
            self._status_future.set_result(status_code)

    def on_body(self, chunk: bytes, **_kwargs: object) -> None:
        """`awscrt` body callback. Hand the chunk to a waiter or buffer it."""
        with self._lock:
            if self._chunk_futures:
                self._chunk_futures.pop(0).set_result(chunk)
            else:
                self._received_chunks.append(chunk)

    def _on_complete(self, _completion_future: object) -> None:
        """Resolve any waiter with empty bytes to signal end-of-stream."""
        with self._lock:
            for fut in self._chunk_futures:
                if not fut.done():
                    fut.set_result(b"")
            self._chunk_futures.clear()

    async def status_code(self) -> int:
        """Await the HTTP response status code."""
        return await asyncio.wrap_future(self._status_future)

    async def next_chunk(self) -> bytes:
        """Await the next body chunk; returns empty bytes once the stream ends."""
        with self._lock:
            if self._received_chunks:
                return self._received_chunks.pop(0)
            stream = self._stream
            if stream is not None and stream.completion_future.done():
                return b""
            future: Future[bytes] = Future()
            self._chunk_futures.append(future)
        return await asyncio.wrap_future(future)


def _path_from_url(url: str) -> tuple[str, str, int]:
    """Extract `(host, path_with_query, port)` from `url`. Raises on malformed."""
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname:
        msg = f"Only HTTPS URLs with a hostname are supported: {url!r}"
        raise RuntimeError(msg)
    path = parsed.path or "/"
    if parsed.query:
        path = f"{path}?{parsed.query}"
    port = parsed.port or _HTTPS_PORT
    return parsed.hostname, path, port


async def _open_connection(host: str, port: int) -> HttpClientConnection:  # pyright: ignore[reportUnusedFunction]
    """Open a fresh HTTP/2 connection to `host:port` with throwaway resources.

    Used by the no-pool path of `PollyStreamingClient.start_speech_synthesis_stream`. Each
    call allocates a new event loop group, host resolver, client bootstrap and TLS context;
    the pooled path (`_ConnectionPool.acquire_connection`) shares those instead.
    """
    elg = io.EventLoopGroup(1)
    resolver = io.DefaultHostResolver(elg)
    bootstrap = io.ClientBootstrap(elg, resolver)
    tls_ctx = io.ClientTlsContext(io.TlsContextOptions())
    return await _connect(host, port, bootstrap=bootstrap, tls_ctx=tls_ctx)


async def _sign(request: HttpRequest, region: str, service: str) -> HttpRequest:
    """SigV4-sign `request`. Returns the signed request (signing is in-place)."""
    credentials_provider = AwsCredentialsProvider.new_default_chain()
    config = AwsSigningConfig(
        algorithm=AwsSigningAlgorithm.V4,
        signature_type=AwsSignatureType.HTTP_REQUEST_HEADERS,
        credentials_provider=credentials_provider,
        region=region,
        service=service,
        signed_body_value=AwsSignedBodyValue.EMPTY_SHA256,
        signed_body_header_type=AwsSignedBodyHeaderType.NONE,
    )
    return await asyncio.wrap_future(aws_sign_request(request, config))


@dataclass
class StreamHandle:
    """Handles to drive a Polly bidirectional HTTP/2 streaming request.

    Attributes:
        initial_signature: 32 raw bytes extracted from the SigV4 ``Authorization``
            header of the initial request. The caller passes this as the seed
            ``prior_signature`` to the rolling event-stream chunk signer.
        body: Writable, non-blocking byte channel. The caller appends signed
            event-stream messages and finally calls ``body.end_stream()``.
        response_chunks: Async iterator over Polly's response body bytes (the
            outbound event stream of ``AudioEvent`` / status / exception
            messages, still framed in the AWS event-stream wire format).
    """

    initial_signature: bytes
    body: BufferableByteStream
    response_chunks: AsyncIterator[bytes]


def _extract_initial_signature(signed_headers: HttpHeaders) -> bytes:
    """Pull the 32 raw bytes of the SigV4 signature out of the ``Authorization`` header.

    The AWS SigV4 ``Authorization`` header has the form
    ``"AWS4-HMAC-SHA256 Credential=..., SignedHeaders=..., Signature=<hex>"``.
    """
    auth = signed_headers.get("authorization") or signed_headers.get("Authorization") or ""
    if "Signature=" not in auth:
        msg = f"signed Authorization header is missing Signature=: {auth!r}"
        raise RuntimeError(msg)
    sig_hex = auth.rsplit("Signature=", 1)[-1].strip()
    return bytes.fromhex(sig_hex)


async def _drain_response(collector: _ResponseCollector) -> AsyncIterator[bytes]:
    while True:
        chunk = await collector.next_chunk()
        if not chunk:
            return
        yield chunk


async def open_stream(  # noqa: PLR0913
    *,
    url: str,
    method: str,
    headers: Mapping[str, str],
    region: str,
    service: str,
    connection: HttpClientConnection,
) -> StreamHandle:
    """Open an HTTP/2 stream on `connection`, SigV4-sign with empty body, return a `StreamHandle`.

    The caller owns the connection lifecycle: pass either a pooled connection
    leased from ``_ConnectionPool.acquire_connection`` (recommended for
    repeated calls to the same endpoint, to amortize TLS/H2 setup) or a
    one-shot connection from ``_open_connection``.

    Args:
        url: Full HTTPS URL of the streaming endpoint.
        method: HTTP method, normally ``"POST"``.
        headers: Initial headers; SigV4 headers are added by this function.
        region: AWS region for SigV4.
        service: AWS service name for SigV4 (e.g. ``"polly"``).
        connection: Open HTTP/2 connection on which to issue the request.
            The caller retains ownership and is responsible for closing or
            returning it to the pool.

    Returns:
        A `StreamHandle` exposing the initial signature seed, the writable
        body channel, and an async iterator over response body chunks.

    Raises:
        RuntimeError: if the response status is not in the 2xx range.
    """
    host, path, _port = _path_from_url(url)

    body = BufferableByteStream()
    initial_headers = [(":authority", host), *headers.items()]
    request = HttpRequest(
        method=method,
        path=path,
        headers=HttpHeaders(initial_headers),
        body_stream=body,
    )
    signed_request = await _sign(request, region=region, service=service)
    initial_signature = _extract_initial_signature(signed_request.headers)

    collector = _ResponseCollector()
    stream = connection.request(signed_request, collector.on_headers, collector.on_body)
    collector.attach(stream)

    status = await collector.status_code()
    if not (_HTTP_OK_MIN <= status < _HTTP_OK_MAX):
        # Drain the response body so the AWS error payload (typically a JSON
        # with `__type` and `message`) is included in the exception.
        body_chunks: list[bytes] = []
        body_size = 0
        while body_size < _ERROR_BODY_CAP:
            chunk = await collector.next_chunk()
            if not chunk:
                break
            body_chunks.append(chunk)
            body_size += len(chunk)
        body_repr = b"".join(body_chunks)[:_ERROR_BODY_CAP].decode("utf-8", errors="replace")
        msg = f"Streaming request failed with status {status}: {body_repr}"
        raise RuntimeError(msg)

    return StreamHandle(
        initial_signature=initial_signature,
        body=body,
        response_chunks=_drain_response(collector),
    )
