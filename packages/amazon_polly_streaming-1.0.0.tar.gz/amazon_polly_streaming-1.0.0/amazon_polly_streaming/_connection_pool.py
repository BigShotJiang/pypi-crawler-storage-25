"""HTTP/2 connection pool for `amazon-polly-streaming` with multi-connection lease semantics.

Eliminates the TLS handshake, ALPN h2 negotiation, and HTTP/2 SETTINGS exchange
between subsequent calls to the same Polly endpoint, while supporting fan-out:
multiple concurrent leases on the same ``(host, port)`` get distinct underlying
``HttpClientConnection`` instances, up to ``max_size_per_key``.

The Polly bidirectional streaming endpoint advertises one active stream per
HTTP/2 connection, so a single shared connection cannot serve more than one
synthesis call at a time. The pool therefore keeps a per-key list of
connections: idle entries are reused by subsequent acquires (preserving the
TLS/H2 cache benefit), and concurrent leases each get their own connection.
When the per-key cap is reached, a further acquire waits on a Condition until
a release frees a slot.

The underlying AWS Common Runtime resources (event loop group, host resolver,
client bootstrap, TLS context) are shared across all entries and allocated
lazily on the first connect.

Pattern inspired by the AWS-maintained ``amazon-transcribe-streaming-sdk``
(``AwsCrtHttpSessionManager._connections`` in
``amazon_transcribe/httpsession.py``).
"""

# pyright: reportUnknownMemberType=false, reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false, reportUnknownParameterType=false
# pyright: reportAttributeAccessIssue=false, reportArgumentType=false
# pyright: reportUnnecessaryComparison=false
# Rationale: awscrt ships no type stubs and its inline annotations are
# incomplete; suppressions are scoped to this module.
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from awscrt import http, io
from awscrt.http import HttpClientConnection

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

_DEFAULT_MAX_SIZE_PER_KEY = 8


async def _connect(
    host: str,
    port: int,
    *,
    bootstrap: io.ClientBootstrap,
    tls_ctx: io.ClientTlsContext,
) -> HttpClientConnection:
    """Open an HTTP/2 connection to ``host:port`` using the provided awscrt resources.

    The bootstrap (event loop group + DNS resolver) and TLS context are
    intended to be shared across multiple connections. Only the
    per-connection TLS connection options carrying SNI server name and ALPN
    list are built here.

    Args:
        host: Hostname to connect to.
        port: TCP port (typically ``443``).
        bootstrap: Pre-built ``ClientBootstrap`` used as I/O backbone.
        tls_ctx: Pre-built ``ClientTlsContext`` from which per-connection
            options are spawned.

    Returns:
        An open ``HttpClientConnection`` with HTTP/2 negotiated.

    Raises:
        RuntimeError: if the connection cannot be opened or HTTP/2 cannot be
            negotiated.
    """
    tls_conn_options = tls_ctx.new_connection_options()
    tls_conn_options.set_server_name(host)
    tls_conn_options.set_alpn_list(["h2"])
    connect_future = HttpClientConnection.new(
        host_name=host,
        port=port,
        bootstrap=bootstrap,
        socket_options=io.SocketOptions(),
        tls_connection_options=tls_conn_options,
    )
    connection = await asyncio.wrap_future(connect_future)
    if not connection.is_open():
        msg = f"Could not open connection to {host}:{port}"
        raise RuntimeError(msg)
    if connection.version is not http.HttpVersion.Http2:
        connection.close()
        msg = f"HTTP/2 could not be negotiated: got {connection.version!r}"
        raise RuntimeError(msg)
    return connection


class _ConnectionPool:
    """Bounded pool of HTTP/2 connections keyed on ``(host, port)``, with leases.

    The pool keeps up to ``max_size_per_key`` connections per key. Each acquire
    grants exclusive use of one connection (a "lease") for the duration of an
    ``async with acquire_connection(...)`` block. Idle connections are reused
    by subsequent acquires; concurrent acquires on the same key each get their
    own connection (opening fresh ones up to the cap).

    A single ``asyncio.Condition`` serializes pool state mutations and signals
    waiters when a slot frees up. The lock is held only over in-memory state
    updates; ``_connect`` runs outside the lock so different keys (and even
    different acquires on the same key) connect in parallel.

    The underlying awscrt resources (event loop group, host resolver,
    client bootstrap, TLS context) are shared across every cached
    connection and allocated lazily on the first connect.
    """

    def __init__(self, *, max_size_per_key: int = _DEFAULT_MAX_SIZE_PER_KEY) -> None:
        self._max_size_per_key = max_size_per_key
        self._idle: dict[tuple[str, int], list[HttpClientConnection]] = {}
        self._in_use: dict[tuple[str, int], int] = {}
        self._cond = asyncio.Condition()
        self._closed = False
        self._bootstrap: io.ClientBootstrap | None = None
        self._tls_ctx: io.ClientTlsContext | None = None
        # Hold refs to event loop group and resolver so they are not GC'd
        # while the bootstrap is alive.
        self._elg: io.EventLoopGroup | None = None
        self._resolver: io.DefaultHostResolver | None = None

    def _ensure_resources(self) -> tuple[io.ClientBootstrap, io.ClientTlsContext]:
        """Lazily build the shared awscrt resources on first use."""
        if self._bootstrap is None or self._tls_ctx is None:
            elg = io.EventLoopGroup(1)
            resolver = io.DefaultHostResolver(elg)
            self._elg = elg
            self._resolver = resolver
            self._bootstrap = io.ClientBootstrap(elg, resolver)
            self._tls_ctx = io.ClientTlsContext(io.TlsContextOptions())
        return self._bootstrap, self._tls_ctx

    @asynccontextmanager
    async def acquire_connection(
        self, *, host: str, port: int
    ) -> AsyncGenerator[HttpClientConnection]:
        """Acquire an exclusive lease on an HTTP/2 connection for ``(host, port)``.

        On entry, returns either a cached idle connection or a freshly opened
        one (up to ``max_size_per_key`` total per key). If the cap is reached,
        the call waits until a concurrent lease releases its connection. On
        exit, the connection returns to the idle list (or is closed if it has
        gone stale or the pool was closed in the meantime).

        Args:
            host: Hostname.
            port: TCP port.

        Yields:
            An open ``HttpClientConnection`` ready to accept a new HTTP/2
            stream via ``connection.request(...)``.

        Raises:
            RuntimeError: if no connection slot is available and a fresh
                connect cannot be opened.
        """
        key = (host, port)
        connection = await self._acquire(key)
        try:
            yield connection
        finally:
            await self._release(key, connection)

    async def _acquire(self, key: tuple[str, int]) -> HttpClientConnection:
        """Reserve a slot for ``key`` and return an open connection."""
        async with self._cond:
            while True:
                idle_list = self._idle.get(key, [])
                while idle_list:
                    candidate = idle_list.pop()
                    if candidate.is_open():
                        self._in_use[key] = self._in_use.get(key, 0) + 1
                        return candidate
                    candidate.close()
                count = self._in_use.get(key, 0)
                if count < self._max_size_per_key:
                    self._in_use[key] = count + 1
                    break
                await self._cond.wait()
        try:
            bootstrap, tls_ctx = self._ensure_resources()
            return await _connect(key[0], key[1], bootstrap=bootstrap, tls_ctx=tls_ctx)
        except BaseException:
            async with self._cond:
                self._in_use[key] = max(0, self._in_use.get(key, 0) - 1)
                self._cond.notify_all()
            raise

    async def _release(self, key: tuple[str, int], connection: HttpClientConnection) -> None:
        """Return a leased connection to idle, or close it on stale/closed-pool."""
        async with self._cond:
            self._in_use[key] = max(0, self._in_use.get(key, 0) - 1)
            if self._closed or not connection.is_open():
                connection.close()
            else:
                self._idle.setdefault(key, []).append(connection)
            self._cond.notify_all()

    async def close_all(self) -> None:
        """Close every idle connection and mark the pool as closed.

        Connections currently leased survive until their lease releases; on
        release they are closed (not returned to idle) because the pool is
        flagged closed.
        """
        async with self._cond:
            self._closed = True
            idle_snapshot = list(self._idle.items())
            self._idle.clear()
            self._cond.notify_all()
        for _key, conns in idle_snapshot:
            for connection in conns:
                connection.close()


_default_pool: _ConnectionPool | None = None


def get_default_pool() -> _ConnectionPool:
    """Return the module-level default ``_ConnectionPool``, creating it on first call."""
    global _default_pool  # noqa: PLW0603
    if _default_pool is None:
        _default_pool = _ConnectionPool()
    return _default_pool
