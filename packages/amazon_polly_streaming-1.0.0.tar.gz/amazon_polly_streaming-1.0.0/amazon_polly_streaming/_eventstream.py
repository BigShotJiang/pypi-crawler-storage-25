"""AWS event-stream binary format parser and encoder.

This module provides three interfaces:

- `EventStreamParser`: stateful, sync-friendly. Accumulates bytes via `feed(...)`
  and returns the list of complete messages decoded so far.
- `parse_stream(...)`: async iterator wrapper. Consumes an async iterator of
  byte chunks and yields each complete message.
- `encode_message(...)` / `encode_messages(...)`: build the binary on-the-wire
  representation of one or more event-stream messages.

Parsing reuses `botocore.eventstream.EventStreamBuffer`. Encoding is
implemented directly with `struct` and `binascii.crc32` because `awscrt`
exposes the encoder only via its connection-oriented RPC client, which is
heavier than what we need here.
"""

from __future__ import annotations

import binascii
import datetime
import struct
from typing import TYPE_CHECKING

from botocore.eventstream import EventStreamBuffer

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Mapping, Sequence

    from botocore.eventstream import EventStreamMessage

# Header value type codes per the AWS event-stream binary spec.
_HEADER_TYPE_BYTE_ARRAY = 6
_HEADER_TYPE_STRING = 7
_HEADER_TYPE_TIMESTAMP = 8
# Each prelude is 12 bytes: total_length (u32) + headers_length (u32) + crc (u32).
_PRELUDE_LENGTH = 12
# The trailing message CRC is 4 bytes.
_MESSAGE_CRC_LENGTH = 4

HeaderValue = str | bytes | datetime.datetime


class EventStreamParser:
    """Sync stateful parser for AWS event-stream framing."""

    def __init__(self) -> None:
        """Initialize with an empty buffer."""
        self._buffer = EventStreamBuffer()

    def feed(self, data: bytes) -> list[EventStreamMessage]:
        """Add bytes to the buffer; return any complete messages now decoded.

        Args:
            data: Raw bytes from the network. May be a partial message, a full
                message, or multiple messages concatenated.

        Returns:
            List of complete `EventStreamMessage` objects decoded after this
            chunk. Empty if the buffer does not yet contain a full message.
        """
        self._buffer.add_data(data)
        return list(self._buffer)

    def reset(self) -> None:
        """Reset the internal buffer to an empty state."""
        self._buffer = EventStreamBuffer()


async def parse_stream(
    chunks: AsyncIterator[bytes],
) -> AsyncIterator[EventStreamMessage]:
    """Consume an async iterator of bytes and yield each complete message.

    Args:
        chunks: Async iterator producing byte chunks from a streaming HTTP body.

    Yields:
        Each complete `EventStreamMessage` as soon as enough bytes have arrived
        to decode it.
    """
    parser = EventStreamParser()
    async for chunk in chunks:
        for msg in parser.feed(chunk):
            yield msg


def _encode_header(name: str, value: HeaderValue) -> bytes:
    """Encode a single header in event-stream wire format.

    Dispatches on the value Python type:
        - `str`   -> type 7 (UTF-8 string), u16 length prefix.
        - `bytes` -> type 6 (byte array), u16 length prefix.
        - `datetime.datetime` -> type 8 (timestamp), i64 ms since UTC epoch.

    Layout: name_len (u8) | name | value_type (u8) | value-encoded-bytes.
    """
    name_bytes = name.encode("utf-8")
    name_prefix = bytes([len(name_bytes)]) + name_bytes
    if isinstance(value, str):
        value_bytes = value.encode("utf-8")
        return (
            name_prefix
            + bytes([_HEADER_TYPE_STRING])
            + struct.pack(">H", len(value_bytes))
            + value_bytes
        )
    if isinstance(value, datetime.datetime):
        if value.tzinfo is None:
            msg = f"Header {name!r} datetime value must be timezone-aware"
            raise ValueError(msg)
        epoch_ms = int(value.timestamp() * 1000)
        return name_prefix + bytes([_HEADER_TYPE_TIMESTAMP]) + struct.pack(">q", epoch_ms)
    return name_prefix + bytes([_HEADER_TYPE_BYTE_ARRAY]) + struct.pack(">H", len(value)) + value


def encode_message(headers: Mapping[str, HeaderValue], payload: bytes) -> bytes:
    """Encode one event-stream message.

    Headers are emitted with a wire type matching their Python type (see
    `_encode_header`): string (type 7), byte_array (type 6), timestamp
    (type 8). The Polly inbound protocol uses string headers for inner events
    (`:message-type`, `:event-type`, `:content-type`) and bytes/timestamp for
    the rolling-signature wrapper (`:date`, `:chunk-signature`).

    Args:
        headers: Mapping of header name to typed value.
        payload: Raw payload bytes (already JSON-encoded for ``TextEvent`` or
            empty for ``CloseStreamEvent``).

    Returns:
        Binary message: prelude (with prelude CRC) + headers + payload +
        trailing message CRC.
    """
    headers_bytes = b"".join(_encode_header(name, value) for name, value in headers.items())
    headers_length = len(headers_bytes)
    total_length = _PRELUDE_LENGTH + headers_length + len(payload) + _MESSAGE_CRC_LENGTH

    prelude = struct.pack(">II", total_length, headers_length)
    prelude_with_crc = prelude + struct.pack(">I", binascii.crc32(prelude))

    body = prelude_with_crc + headers_bytes + payload
    return body + struct.pack(">I", binascii.crc32(body))


def encode_messages(messages: Sequence[tuple[Mapping[str, HeaderValue], bytes]]) -> bytes:
    """Encode a sequence of (headers, payload) tuples into one byte string.

    Args:
        messages: Ordered list of messages to encode.

    Returns:
        Concatenated binary representation of all messages.
    """
    return b"".join(encode_message(headers, payload) for headers, payload in messages)
