"""Rolling AWS event-stream chunk signer for HTTP/2 bidirectional streaming.

Each event sent on the request body channel must be wrapped in a signed
envelope. The wrapper carries two headers, `:date` and `:chunk-signature`,
where `:chunk-signature` is computed as an HMAC-SHA256 of an event-stream-
specific string-to-sign. The signature of the previous wrapped event (or, for
the first event, the SigV4 signature of the initial HTTP request) participates
in the string-to-sign, producing a rolling chain.

The signing string follows the format documented at
https://docs.aws.amazon.com/transcribe/latest/dg/streaming-setting-up.html
under "AWS4-HMAC-SHA256-PAYLOAD". The same algorithm is used by Amazon Polly
bidirectional streaming and by the open-source `amazon-transcribe-streaming-
sdk` Python package, both based on the AWS Common Runtime event-stream signing
contract.
"""

from __future__ import annotations

import hashlib
import hmac
import struct
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import datetime

    from amazon_polly_streaming._eventstream import HeaderValue

_TIMESTAMP_FMT = "%Y%m%dT%H%M%SZ"
_HEADER_TYPE_TIMESTAMP = 8


@dataclass(frozen=True)
class EventSignerCredentials:
    """Subset of AWS credentials needed to derive the signing key."""

    access_key_id: str
    secret_access_key: str
    session_token: str | None


class EventSigner:
    """Compute rolling `:chunk-signature` headers for event-stream wrappers."""

    def __init__(self, *, signing_name: str, region: str) -> None:
        """Bind the signer to a service signing name and a region."""
        self._signing_name = signing_name
        self._region = region

    def sign(
        self,
        *,
        payload: bytes,
        prior_signature: bytes,
        credentials: EventSignerCredentials,
        now: datetime.datetime,
    ) -> dict[str, HeaderValue]:
        """Return wrapper headers (`:date`, `:chunk-signature`) for `payload`.

        Args:
            payload: Inner event-stream message bytes (already encoded with its
                own headers and payload).
            prior_signature: 32-byte raw signature of the previous wrapped
                event, or the SigV4 signature of the initial HTTP request for
                the first event.
            credentials: AWS credentials used to derive the signing key.
            now: Timezone-aware UTC datetime used both as the `:date` header
                value and as the timestamp embedded in the string-to-sign.

        Returns:
            A dict with two entries: `:date` (the input `now`) and
            `:chunk-signature` (32 raw HMAC-SHA256 bytes).

        Raises:
            ValueError: if `now` is naive (no `tzinfo`).
        """
        if now.tzinfo is None:
            msg = "EventSigner.sign requires a timezone-aware `now`"
            raise ValueError(msg)

        timestamp = now.strftime(_TIMESTAMP_FMT)
        date_header_bytes = _encode_date_header_value(now)
        string_to_sign = "\n".join(
            [
                "AWS4-HMAC-SHA256-PAYLOAD",
                timestamp,
                self._scope(timestamp),
                prior_signature.hex(),
                hashlib.sha256(date_header_bytes).hexdigest(),
                hashlib.sha256(payload).hexdigest(),
            ]
        )
        signing_key = self._derive_signing_key(
            secret_access_key=credentials.secret_access_key,
            timestamp=timestamp,
        )
        chunk_signature = hmac.new(
            signing_key, string_to_sign.encode("utf-8"), hashlib.sha256
        ).digest()
        return {":date": now, ":chunk-signature": chunk_signature}

    def _scope(self, timestamp: str) -> str:
        return f"{timestamp[:8]}/{self._region}/{self._signing_name}/aws4_request"

    def _derive_signing_key(self, *, secret_access_key: str, timestamp: str) -> bytes:
        date = timestamp[:8].encode("utf-8")
        k_date = _hmac(b"AWS4" + secret_access_key.encode("utf-8"), date)
        k_region = _hmac(k_date, self._region.encode("utf-8"))
        k_service = _hmac(k_region, self._signing_name.encode("utf-8"))
        return _hmac(k_service, b"aws4_request")


def _hmac(key: bytes, msg: bytes) -> bytes:
    return hmac.new(key, msg, hashlib.sha256).digest()


def _encode_date_header_value(when: datetime.datetime) -> bytes:
    """Encode `:date` as it appears in the wrapper headers section, for hashing.

    The string-to-sign uses the SHA256 of the encoded `:date` header bytes
    (name-prefixed, type-tagged, big-endian int64 milliseconds since UTC
    epoch). This mirrors the wire format produced by the event-stream encoder
    when serializing the wrapper message.
    """
    name = b":date"
    epoch_ms = int(when.timestamp() * 1000)
    return bytes([len(name)]) + name + bytes([_HEADER_TYPE_TIMESTAMP]) + struct.pack(">q", epoch_ms)
