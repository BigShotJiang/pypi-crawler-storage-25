"""Public Amazon Polly bidirectional streaming client.

Composes the lower-level pieces (event-stream encoder/decoder, rolling
chunk-signature signer, and the HTTP/2 + SigV4 transport) into a high-level
``PollyStreamingClient`` whose ``start_speech_synthesis_stream`` method takes
text and a voice id and yields audio chunks as they arrive from Polly.

Wire format (consistent with the AWS Java SDK service model and the
``amazon-transcribe-streaming-sdk`` reference implementation):

* Synthesis parameters (engine, voice, output format, ...) travel in
  ``x-amzn-*`` request headers.
* The request body is an event-stream where each event is itself wrapped in
  another event-stream message carrying ``:date`` and ``:chunk-signature``
  headers (rolling HMAC-SHA256). The seed of the rolling chain is the SigV4
  signature of the initial HTTP request.
* Inner events are: one ``TextEvent`` (JSON ``{"Text": ...}``) followed by
  one ``CloseStreamEvent`` (empty JSON object). After both are written, an
  empty-payload wrapper is written as the wire-level end-of-stream marker
  before closing the body channel.
* The response body is an event-stream of ``AudioEvent`` messages whose
  payloads carry the synthesized audio bytes, plus ``StreamClosedEvent`` and
  framed exception messages (``ServiceFailureException``, ``ValidationException``,
  ``ServiceQuotaExceededException``, ``ThrottlingException``).
"""

from __future__ import annotations

import datetime
import json
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

import botocore.session

from amazon_polly_streaming._connection_pool import get_default_pool
from amazon_polly_streaming._event_signer import EventSigner, EventSignerCredentials
from amazon_polly_streaming._eventstream import encode_message, parse_stream
from amazon_polly_streaming._http2 import (
    _open_connection,  # pyright: ignore[reportPrivateUsage]
    open_stream,
)
from amazon_polly_streaming.exceptions import ServiceException, exception_for_type

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator, AsyncIterator

    from awscrt.http import HttpClientConnection

    from amazon_polly_streaming._buffered_stream import BufferableByteStream

_HTTPS_PORT = 443

_TEXT_EVENT_HEADERS = {
    ":message-type": "event",
    ":event-type": "TextEvent",
    ":content-type": "application/json",
}
_CLOSE_EVENT_HEADERS = {
    ":message-type": "event",
    ":event-type": "CloseStreamEvent",
    ":content-type": "application/json",
}


def _now_utc() -> datetime.datetime:
    return datetime.datetime.now(tz=datetime.UTC)


def _resolve_event_credentials() -> EventSignerCredentials:
    """Resolve AWS credentials from the default chain for event signing.

    `botocore-stubs` types `Session.get_credentials()` as non-Optional and
    `ReadOnlyCredentials.access_key` / `.secret_key` as `str`, but at runtime
    both can be `None` when no credentials are configured. The defensive
    checks below cover that gap.
    """
    session = botocore.session.Session()
    creds = session.get_credentials()
    if creds is None:  # pyright: ignore[reportUnnecessaryComparison]
        msg = "Could not resolve AWS credentials for event signing"
        raise RuntimeError(msg)
    frozen = creds.get_frozen_credentials()
    if frozen.access_key is None or frozen.secret_key is None:  # pyright: ignore[reportUnnecessaryComparison]
        msg = "AWS credentials chain returned an incomplete identity (missing access or secret key)"
        raise RuntimeError(msg)
    return EventSignerCredentials(
        access_key_id=frozen.access_key,
        secret_access_key=frozen.secret_key,
        session_token=frozen.token,
    )


def _header_value(headers: object, name: str) -> str | None:
    """Return the string value of `name` in `headers`, or None if absent.

    `botocore` exposes message headers as a plain `dict` at runtime but ships
    no type stubs for `EventStreamMessage`; this helper normalises access.
    """
    if not isinstance(headers, dict):
        return None
    value = headers.get(name)  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
    if isinstance(value, str):
        return value
    return None


class _EventWriter:
    """Buffers signed event-stream messages onto the HTTP/2 body channel."""

    def __init__(
        self,
        *,
        body: BufferableByteStream,
        signer: EventSigner,
        credentials: EventSignerCredentials,
        initial_signature: bytes,
    ) -> None:
        self._body = body
        self._signer = signer
        self._credentials = credentials
        self._prior_signature = initial_signature

    def send_event(self, headers: dict[str, str], payload: bytes) -> None:
        """Encode `(headers, payload)` and append a signed wrapper to the body."""
        inner_bytes = encode_message(headers, payload)
        self._write_signed(inner_bytes)

    def end_stream(self) -> None:
        """Send the wire-level end-of-stream marker and close the body channel."""
        self._write_signed(b"")
        self._body.end_stream()

    def _write_signed(self, payload: bytes) -> None:
        wrapper_headers = self._signer.sign(
            payload=payload,
            prior_signature=self._prior_signature,
            credentials=self._credentials,
            now=_now_utc(),
        )
        wrapped = encode_message(wrapper_headers, payload)
        self._body.write(wrapped)
        chunk_signature = wrapper_headers[":chunk-signature"]
        if not isinstance(chunk_signature, bytes):
            msg = "EventSigner.sign must return bytes for :chunk-signature"
            raise TypeError(msg)
        self._prior_signature = chunk_signature


@asynccontextmanager
async def _acquire_polly_connection(
    host: str, port: int, *, use_pool: bool
) -> AsyncGenerator[HttpClientConnection]:
    """Yield a Polly HTTP/2 connection: a pooled lease if `use_pool`, else one-shot.

    Pooled path: lease via ``_ConnectionPool.acquire_connection``, returned to
    idle on exit. One-shot path: open a fresh single-use connection; not
    explicitly closed on exit (matches the no-pool behaviour of 0.2.0; the
    awscrt connection is released by GC once it goes out of scope).
    """
    if use_pool:
        async with get_default_pool().acquire_connection(host=host, port=port) as connection:
            yield connection
    else:
        connection = await _open_connection(host, port)
        yield connection


class PollyStreamingClient:
    """High-level client for Amazon Polly bidirectional streaming.

    Mirrors the ``TranscribeStreamingClient`` shape from
    ``amazon-transcribe-streaming-sdk-python``: instantiate once for a given
    region, then call ``start_speech_synthesis_stream`` for each utterance.
    """

    def __init__(self, region: str = "eu-central-1") -> None:
        """Bind the client to ``region`` for all subsequent stream requests.

        Args:
            region: AWS region for the Polly endpoint. Bidirectional streaming
                is available in a subset of regions; default ``eu-central-1``
                (Frankfurt, the closest European region with bidirectional
                streaming support at the time of writing).
        """
        self._region = region

    @property
    def region(self) -> str:
        """The AWS region bound to this client."""
        return self._region

    async def start_speech_synthesis_stream(  # noqa: PLR0913
        self,
        *,
        text: str,
        voice_id: str,
        engine: str = "generative",
        language_code: str = "en-US",
        output_format: str = "mp3",
        sample_rate: str = "24000",
        use_pool: bool = True,
    ) -> AsyncIterator[bytes]:
        """Synthesize ``text`` via Polly bidirectional streaming and yield audio chunks.

        Opens an HTTP/2 connection to ``polly.<region>.amazonaws.com``, signs
        the initial request with SigV4, then writes one ``TextEvent`` and one
        ``CloseStreamEvent`` (each wrapped with a rolling chunk-signature) on
        the body channel. As Polly responds, decodes the inbound event stream
        and yields the bytes of every ``AudioEvent``.

        Args:
            text: The text to synthesize.
            voice_id: Polly voice id (must be a generative voice supporting
                bidirectional streaming, e.g. ``"Matthew"``).
            engine: Polly engine name. Currently only ``"generative"`` is
                supported by the bidirectional streaming API.
            language_code: BCP-47 language code (only used for bilingual voices).
            output_format: Audio format (``"mp3"``, ``"pcm"``, ``"ogg_vorbis"``,
                ...). Default ``"mp3"``.
            sample_rate: Sample rate in Hz, as a string. Default ``"24000"``.
            use_pool: If ``True`` (default), reuse a cached HTTP/2 connection
                from the module-level connection pool, avoiding TLS handshake
                and HTTP/2 settings exchange between calls to the same Polly
                endpoint. Disable for one-shot scripts where the cache adds
                complexity without benefit.

        Yields:
            Bytes of audio for each ``AudioEvent`` received from Polly, in order.

        Raises:
            ServiceException: base class for any service-side error. Subclasses
                (``ServiceFailureException``, ``ValidationException``,
                ``ServiceQuotaExceededException``, ``ThrottlingException``)
                are raised when Polly returns a framed exception with a
                recognised ``:exception-type`` header.
            RuntimeError: on transport failures (HTTP non-2xx, TLS / HTTP/2
                negotiation, missing credentials).
        """
        host = f"polly.{self._region}.amazonaws.com"
        url = f"https://{host}/v1/synthesisStream"
        headers = {
            "host": host,
            "content-type": "application/vnd.amazon.eventstream",
            "x-amzn-Engine": engine,
            "x-amzn-LanguageCode": language_code,
            "x-amzn-OutputFormat": output_format,
            "x-amzn-SampleRate": sample_rate,
            "x-amzn-VoiceId": voice_id,
        }

        async with _acquire_polly_connection(host, _HTTPS_PORT, use_pool=use_pool) as connection:
            handle = await open_stream(
                url=url,
                method="POST",
                headers=headers,
                region=self._region,
                service="polly",
                connection=connection,
            )

            signer = EventSigner(signing_name="polly", region=self._region)
            credentials = _resolve_event_credentials()
            writer = _EventWriter(
                body=handle.body,
                signer=signer,
                credentials=credentials,
                initial_signature=handle.initial_signature,
            )
            writer.send_event(_TEXT_EVENT_HEADERS, json.dumps({"Text": text}).encode("utf-8"))
            writer.send_event(_CLOSE_EVENT_HEADERS, b"{}")
            writer.end_stream()

            async for message in parse_stream(handle.response_chunks):
                message_type = _header_value(message.headers, ":message-type")

                if message_type == "event":
                    event_type = _header_value(message.headers, ":event-type")
                    if event_type == "AudioEvent":
                        yield bytes(message.payload)
                    # skip non-audio events (e.g. StreamClosedEvent)
                    continue

                if message_type == "exception":
                    exception_type = _header_value(message.headers, ":exception-type")
                    exception_class = exception_for_type(exception_type)
                    payload_text = bytes(message.payload).decode("utf-8", errors="replace")
                    raise exception_class(payload_text)

                error_message = (
                    f"Polly returned an unexpected message: :message-type={message_type!r}, "
                    f"headers={message.headers!r}, "
                    f"payload={message.payload!r}"
                )
                raise ServiceException(error_message)
