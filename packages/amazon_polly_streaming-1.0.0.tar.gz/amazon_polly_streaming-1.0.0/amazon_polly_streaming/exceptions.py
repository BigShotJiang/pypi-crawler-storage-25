"""Service exceptions for Amazon Polly bidirectional streaming.

When the Polly bidirectional streaming endpoint encounters an error, it sends
a framed event-stream message with ``:message-type=exception`` and an
``:exception-type`` header naming the exception class. This module defines the
Python exception classes mirroring the Polly API exception types documented
for ``StartSpeechSynthesisStream``, plus a base class for unknown or
unexpected error conditions.
"""

from __future__ import annotations


class ServiceException(Exception):
    """Base exception for all Polly bidirectional streaming service errors."""


class ServiceFailureException(ServiceException):
    """An unknown condition has caused a Polly service failure."""


class ValidationException(ServiceException):
    """The input provided to Polly is invalid."""


class ServiceQuotaExceededException(ServiceException):
    """The Polly service quota has been exceeded for this account or operation."""


class ThrottlingException(ServiceException):
    """The request to Polly was throttled by the service."""


_EXCEPTION_TYPE_MAP: dict[str, type[ServiceException]] = {
    "ServiceFailureException": ServiceFailureException,
    "ValidationException": ValidationException,
    "ServiceQuotaExceededException": ServiceQuotaExceededException,
    "ThrottlingException": ThrottlingException,
}


def exception_for_type(exception_type: str | None) -> type[ServiceException]:
    """Return the exception class matching ``exception_type`` or ``ServiceException``.

    Args:
        exception_type: The value of the ``:exception-type`` header from a
            framed Polly exception message, or ``None`` if the header is absent.

    Returns:
        The corresponding subclass of ``ServiceException`` when ``exception_type``
        is one of the known Polly exception type names. Otherwise returns the
        base ``ServiceException`` class as a fallback (so callers always get a
        valid exception class to raise).
    """
    if exception_type is None:
        return ServiceException
    return _EXCEPTION_TYPE_MAP.get(exception_type, ServiceException)
