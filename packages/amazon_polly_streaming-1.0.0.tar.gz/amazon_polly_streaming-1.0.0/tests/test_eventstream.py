"""Test the event-stream parser wrapper."""

import binascii
import datetime
import struct

import pytest
from botocore.eventstream import EventStreamMessage

from amazon_polly_streaming._eventstream import (
    EventStreamParser,
    encode_message,
    encode_messages,
    parse_stream,
)


def _build_message(event_type: str, payload: bytes) -> bytes:
    """Encode a synthetic event-stream message for tests.

    Uses the same binary format botocore parses: prelude (total_length + headers_length
    + prelude_crc) + headers + payload + message_crc.
    """
    # Build the headers section: one header ":event-type" with the given type.
    name = b":event-type"
    name_len = len(name)
    value = event_type.encode("utf-8")
    value_len = len(value)
    # Header value type 7 = string
    headers = bytes([name_len]) + name + bytes([7]) + struct.pack(">H", value_len) + value

    headers_length = len(headers)
    total_length = 4 + 4 + 4 + headers_length + len(payload) + 4

    prelude = struct.pack(">II", total_length, headers_length)
    prelude_crc = binascii.crc32(prelude)
    prelude += struct.pack(">I", prelude_crc)

    body = prelude + headers + payload
    message_crc = binascii.crc32(body)

    return body + struct.pack(">I", message_crc)


def test_feed_yields_complete_message_when_one_arrives_in_one_chunk() -> None:
    """`feed` returns one EventStreamMessage when a full message is fed at once."""
    msg_bytes = _build_message("AudioEvent", b"\x00\x11\x22\x33")

    parser = EventStreamParser()
    messages = parser.feed(msg_bytes)

    assert len(messages) == 1
    msg = messages[0]
    assert isinstance(msg, EventStreamMessage)
    assert msg.payload == b"\x00\x11\x22\x33"


def test_feed_yields_nothing_for_partial_chunk() -> None:
    """`feed` returns an empty list when the chunk does not contain a complete message."""
    msg_bytes = _build_message("AudioEvent", b"\x00\x11\x22\x33")

    parser = EventStreamParser()
    head = parser.feed(msg_bytes[:5])
    assert head == []


def test_feed_reassembles_message_across_chunks() -> None:
    """`feed` accumulates bytes and yields a message once it is complete across chunks."""
    msg_bytes = _build_message("AudioEvent", b"\x00\x11\x22\x33")

    parser = EventStreamParser()
    first = parser.feed(msg_bytes[:8])
    second = parser.feed(msg_bytes[8:])

    assert first == []
    assert len(second) == 1
    assert second[0].payload == b"\x00\x11\x22\x33"


@pytest.mark.asyncio
async def test_parse_stream_yields_messages_from_async_chunks() -> None:
    """`parse_stream` yields a message per complete frame consumed from the async source."""
    msg_a = _build_message("AudioEvent", b"chunk_a")
    msg_b = _build_message("AudioEvent", b"chunk_b")

    async def chunks():
        yield msg_a[:5]
        yield msg_a[5:] + msg_b[:10]
        yield msg_b[10:]

    payloads = [msg.payload async for msg in parse_stream(chunks())]

    assert payloads == [b"chunk_a", b"chunk_b"]


def test_encode_message_round_trips_through_parser() -> None:
    """`encode_message` produces bytes that EventStreamParser decodes back."""
    headers = {
        ":message-type": "event",
        ":event-type": "TextEvent",
        ":content-type": "application/json",
    }
    payload = b'{"text": "hello"}'

    encoded = encode_message(headers, payload)

    parser = EventStreamParser()
    messages = parser.feed(encoded)

    assert len(messages) == 1
    decoded = messages[0]
    assert decoded.payload == payload
    decoded_headers = dict(decoded.headers.items())
    assert decoded_headers[":message-type"] == "event"
    assert decoded_headers[":event-type"] == "TextEvent"
    assert decoded_headers[":content-type"] == "application/json"


def test_encode_messages_concatenates_in_order() -> None:
    """`encode_messages` produces a stream of two messages decoded in order."""
    text_headers = {
        ":message-type": "event",
        ":event-type": "TextEvent",
        ":content-type": "application/json",
    }
    close_headers = {
        ":message-type": "event",
        ":event-type": "CloseStreamEvent",
        ":content-type": "application/json",
    }

    encoded = encode_messages(
        [
            (text_headers, b'{"text": "ciao"}'),
            (close_headers, b""),
        ]
    )

    parser = EventStreamParser()
    messages = parser.feed(encoded)

    expected_message_count = 2
    assert len(messages) == expected_message_count
    first_headers = dict(messages[0].headers.items())
    second_headers = dict(messages[1].headers.items())
    assert first_headers[":event-type"] == "TextEvent"
    assert messages[0].payload == b'{"text": "ciao"}'
    assert second_headers[":event-type"] == "CloseStreamEvent"
    assert messages[1].payload == b""


def test_encode_message_matches_synthetic_builder() -> None:
    """`encode_message` byte-for-byte matches the test builder for a one-header message."""
    headers = {":event-type": "AudioEvent"}
    payload = b"\x00\x11\x22\x33"

    expected = _build_message("AudioEvent", payload)
    actual = encode_message(headers, payload)

    assert actual == expected


def test_encode_message_round_trips_bytes_header() -> None:
    """`encode_message` accepts a bytes-typed header (type 6) and the parser decodes it back."""
    chunk_signature = bytes(range(32))
    headers: dict[str, str | bytes | datetime.datetime] = {
        ":chunk-signature": chunk_signature,
    }
    payload = b"inner-event-bytes"

    encoded = encode_message(headers, payload)

    parser = EventStreamParser()
    messages = parser.feed(encoded)

    assert len(messages) == 1
    decoded_headers = dict(messages[0].headers.items())
    assert decoded_headers[":chunk-signature"] == chunk_signature
    assert messages[0].payload == payload


def test_encode_message_round_trips_datetime_header() -> None:
    """`encode_message` accepts a tz-aware datetime header (type 8) and the parser decodes it."""
    when = datetime.datetime(2026, 5, 1, 12, 30, 45, tzinfo=datetime.UTC)
    headers: dict[str, str | bytes | datetime.datetime] = {":date": when}
    payload = b""

    encoded = encode_message(headers, payload)

    parser = EventStreamParser()
    messages = parser.feed(encoded)

    assert len(messages) == 1
    decoded_headers = dict(messages[0].headers.items())
    # botocore decodes timestamp headers as int (milliseconds since UTC epoch).
    expected_epoch_ms = int(when.timestamp() * 1000)
    assert decoded_headers[":date"] == expected_epoch_ms


def test_encode_message_rejects_naive_datetime_header() -> None:
    """A datetime header without tzinfo raises, since timestamp semantics would be ambiguous."""
    naive = datetime.datetime(2026, 5, 1, 12, 30, 45)  # noqa: DTZ001
    headers: dict[str, str | bytes | datetime.datetime] = {":date": naive}

    with pytest.raises(ValueError, match="timezone-aware"):
        encode_message(headers, b"")


def test_encode_message_mixes_string_bytes_and_datetime_headers() -> None:
    """A wrapper-style message with `:date` and `:chunk-signature` round-trips correctly."""
    when = datetime.datetime(2026, 5, 1, 12, 30, 45, tzinfo=datetime.UTC)
    chunk_signature = b"\xaa" * 32
    inner_bytes = b"opaque-inner-event-stream-message"
    headers: dict[str, str | bytes | datetime.datetime] = {
        ":date": when,
        ":chunk-signature": chunk_signature,
    }

    encoded = encode_message(headers, inner_bytes)

    parser = EventStreamParser()
    messages = parser.feed(encoded)

    assert len(messages) == 1
    decoded_headers = dict(messages[0].headers.items())
    assert decoded_headers[":chunk-signature"] == chunk_signature
    expected_epoch_ms = int(when.timestamp() * 1000)
    assert decoded_headers[":date"] == expected_epoch_ms
    assert messages[0].payload == inner_bytes
