"""Tests for BufferableByteStream, the writable body channel for HTTP/2."""

from __future__ import annotations

import pytest

from amazon_polly_streaming._buffered_stream import BufferableByteStream


def test_read_raises_blocking_io_error_when_empty_and_open() -> None:
    """`read` raises `BlockingIOError` when no data is available and the stream is open."""
    stream = BufferableByteStream()

    with pytest.raises(BlockingIOError):
        stream.read()


def test_read_returns_empty_bytes_when_done_and_empty() -> None:
    """`read` returns empty bytes once the stream has been ended and drained."""
    stream = BufferableByteStream()
    stream.end_stream()

    assert stream.read() == b""


def test_read_returns_written_chunk_in_full_when_size_negative() -> None:
    """A `read(-1)` after a `write(...)` returns the full chunk."""
    stream = BufferableByteStream()
    stream.write(b"hello")

    assert stream.read() == b"hello"


def test_read_returns_chunks_in_fifo_order() -> None:
    """Multiple writes are returned in the order they were written."""
    stream = BufferableByteStream()
    stream.write(b"first")
    stream.write(b"second")

    assert stream.read() == b"first"
    assert stream.read() == b"second"


def test_read_with_size_smaller_than_chunk_returns_prefix_and_keeps_remainder() -> None:
    """`read(size)` returns at most `size` bytes; the remainder of the chunk stays buffered."""
    stream = BufferableByteStream()
    stream.write(b"abcdef")

    assert stream.read(3) == b"abc"
    assert stream.read(3) == b"def"


def test_write_returns_number_of_bytes_written() -> None:
    """`write` returns the count of bytes accepted into the buffer."""
    stream = BufferableByteStream()

    n = stream.write(b"hello")

    assert n == len(b"hello")


def test_write_after_end_stream_raises() -> None:
    """After `end_stream`, further writes are rejected with `OSError`."""
    stream = BufferableByteStream()
    stream.end_stream()

    with pytest.raises(OSError, match="closed"):
        stream.write(b"too late")


def test_end_stream_with_buffered_data_drains_then_returns_empty() -> None:
    """After `end_stream`, buffered chunks remain readable; only when drained `read` returns b''."""
    stream = BufferableByteStream()
    stream.write(b"alpha")
    stream.end_stream()

    assert stream.read() == b"alpha"
    assert stream.read() == b""


def test_close_sets_closed_property() -> None:
    """`close` flips the `closed` property to True."""
    stream = BufferableByteStream()
    assert stream.closed is False

    stream.close()

    assert stream.closed is True


def test_write_rejects_non_bytes() -> None:
    """`write` rejects non-bytes input to keep wire-format invariants explicit."""
    stream = BufferableByteStream()

    with pytest.raises(TypeError):
        stream.write("not bytes")  # pyright: ignore[reportArgumentType]
