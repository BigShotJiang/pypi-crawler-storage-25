"""Tests for the rolling event-stream chunk signer."""

from __future__ import annotations

import datetime

import pytest

from amazon_polly_streaming._event_signer import EventSigner, EventSignerCredentials

_FIXED_NOW = datetime.datetime(2026, 5, 1, 12, 30, 45, tzinfo=datetime.UTC)
_TEST_CREDS = EventSignerCredentials(
    access_key_id="AKIAIOSFODNN7EXAMPLE",
    secret_access_key="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",  # noqa: S106
    session_token=None,
)
_INITIAL_SIGNATURE = bytes.fromhex(
    "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
)


def test_sign_returns_date_and_chunk_signature_headers() -> None:
    """`sign` returns exactly the two headers expected for the wrapper message."""
    signer = EventSigner(signing_name="polly", region="us-west-2")
    headers = signer.sign(
        payload=b"opaque-event-bytes",
        prior_signature=_INITIAL_SIGNATURE,
        credentials=_TEST_CREDS,
        now=_FIXED_NOW,
    )

    assert set(headers.keys()) == {":date", ":chunk-signature"}


def test_sign_chunk_signature_is_32_raw_bytes() -> None:
    """`:chunk-signature` is a 32-byte HMAC-SHA256 output, returned as raw bytes."""
    signer = EventSigner(signing_name="polly", region="us-west-2")
    headers = signer.sign(
        payload=b"opaque-event-bytes",
        prior_signature=_INITIAL_SIGNATURE,
        credentials=_TEST_CREDS,
        now=_FIXED_NOW,
    )

    sig = headers[":chunk-signature"]
    expected_signature_length = 32
    assert isinstance(sig, bytes)
    assert len(sig) == expected_signature_length


def test_sign_date_matches_now_argument() -> None:
    """`:date` echoes the timezone-aware datetime passed in as `now`."""
    signer = EventSigner(signing_name="polly", region="us-west-2")
    headers = signer.sign(
        payload=b"x",
        prior_signature=_INITIAL_SIGNATURE,
        credentials=_TEST_CREDS,
        now=_FIXED_NOW,
    )

    assert headers[":date"] == _FIXED_NOW


def test_sign_is_deterministic_for_fixed_inputs() -> None:
    """Same inputs (creds, region, payload, prior, now) produce the same signature."""
    signer_a = EventSigner(signing_name="polly", region="us-west-2")
    signer_b = EventSigner(signing_name="polly", region="us-west-2")

    headers_a = signer_a.sign(
        payload=b"event-bytes",
        prior_signature=_INITIAL_SIGNATURE,
        credentials=_TEST_CREDS,
        now=_FIXED_NOW,
    )
    headers_b = signer_b.sign(
        payload=b"event-bytes",
        prior_signature=_INITIAL_SIGNATURE,
        credentials=_TEST_CREDS,
        now=_FIXED_NOW,
    )

    assert headers_a[":chunk-signature"] == headers_b[":chunk-signature"]


def test_sign_changes_with_different_prior_signature() -> None:
    """Different `prior_signature` produces a different `:chunk-signature`."""
    signer = EventSigner(signing_name="polly", region="us-west-2")
    other_prior = bytes.fromhex("fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210")

    a = signer.sign(
        payload=b"event-bytes",
        prior_signature=_INITIAL_SIGNATURE,
        credentials=_TEST_CREDS,
        now=_FIXED_NOW,
    )
    b = signer.sign(
        payload=b"event-bytes",
        prior_signature=other_prior,
        credentials=_TEST_CREDS,
        now=_FIXED_NOW,
    )

    assert a[":chunk-signature"] != b[":chunk-signature"]


def test_sign_changes_with_different_payload() -> None:
    """Different `payload` produces a different `:chunk-signature`."""
    signer = EventSigner(signing_name="polly", region="us-west-2")

    a = signer.sign(
        payload=b"event-bytes-a",
        prior_signature=_INITIAL_SIGNATURE,
        credentials=_TEST_CREDS,
        now=_FIXED_NOW,
    )
    b = signer.sign(
        payload=b"event-bytes-b",
        prior_signature=_INITIAL_SIGNATURE,
        credentials=_TEST_CREDS,
        now=_FIXED_NOW,
    )

    assert a[":chunk-signature"] != b[":chunk-signature"]


def test_sign_changes_with_different_timestamp() -> None:
    """Different `now` produces a different `:chunk-signature`."""
    signer = EventSigner(signing_name="polly", region="us-west-2")
    later = _FIXED_NOW + datetime.timedelta(seconds=1)

    a = signer.sign(
        payload=b"event-bytes",
        prior_signature=_INITIAL_SIGNATURE,
        credentials=_TEST_CREDS,
        now=_FIXED_NOW,
    )
    b = signer.sign(
        payload=b"event-bytes",
        prior_signature=_INITIAL_SIGNATURE,
        credentials=_TEST_CREDS,
        now=later,
    )

    assert a[":chunk-signature"] != b[":chunk-signature"]


def test_sign_handles_empty_payload_for_end_stream() -> None:
    """Signing an empty payload (used for the end-of-stream marker) produces a 32-byte signature."""
    signer = EventSigner(signing_name="polly", region="us-west-2")

    headers = signer.sign(
        payload=b"",
        prior_signature=_INITIAL_SIGNATURE,
        credentials=_TEST_CREDS,
        now=_FIXED_NOW,
    )

    expected_signature_length = 32
    sig = headers[":chunk-signature"]
    assert isinstance(sig, bytes)
    assert len(sig) == expected_signature_length


def test_sign_rejects_naive_now() -> None:
    """A naive `now` raises, since signing requires a deterministic UTC timestamp."""
    signer = EventSigner(signing_name="polly", region="us-west-2")
    naive = datetime.datetime(2026, 5, 1, 12, 30, 45)  # noqa: DTZ001

    with pytest.raises(ValueError, match="timezone-aware"):
        signer.sign(
            payload=b"x",
            prior_signature=_INITIAL_SIGNATURE,
            credentials=_TEST_CREDS,
            now=naive,
        )
