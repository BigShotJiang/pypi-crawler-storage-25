"""Test the typed exception module and `exception_for_type` lookup."""

from __future__ import annotations

import pytest

from amazon_polly_streaming.exceptions import (
    ServiceException,
    ServiceFailureException,
    ServiceQuotaExceededException,
    ThrottlingException,
    ValidationException,
    exception_for_type,
)


@pytest.mark.parametrize(
    ("name", "expected"),
    [
        ("ServiceFailureException", ServiceFailureException),
        ("ValidationException", ValidationException),
        ("ServiceQuotaExceededException", ServiceQuotaExceededException),
        ("ThrottlingException", ThrottlingException),
    ],
)
def test_exception_for_type_maps_known_names_to_typed_classes(
    name: str, expected: type[ServiceException]
) -> None:
    """`exception_for_type` returns the matching subclass for each Polly exception name."""
    assert exception_for_type(name) is expected


def test_exception_for_type_falls_back_to_service_exception_for_unknown_name() -> None:
    """Unknown exception type names fall back to the base `ServiceException`."""
    assert exception_for_type("NotARealPollyException") is ServiceException


def test_exception_for_type_falls_back_to_service_exception_for_none() -> None:
    """A ``None`` exception type falls back to the base `ServiceException`."""
    assert exception_for_type(None) is ServiceException


def test_all_typed_exceptions_inherit_from_service_exception() -> None:
    """Every typed exception class is a subclass of `ServiceException`."""
    for cls in [
        ServiceFailureException,
        ValidationException,
        ServiceQuotaExceededException,
        ThrottlingException,
    ]:
        assert issubclass(cls, ServiceException)
