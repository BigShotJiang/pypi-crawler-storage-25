"""Test the HTTP/2 connection pool with multi-connection lease semantics."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any
from unittest.mock import MagicMock, patch

import pytest

from amazon_polly_streaming import _connection_pool
from amazon_polly_streaming._connection_pool import _ConnectionPool

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator

_TEST_TIMEOUT_SECONDS = 5.0
_CONCURRENT_LEASES = 2


def _open_connection_mock() -> MagicMock:
    """Return a mock connection whose `is_open()` returns True."""
    connection = MagicMock()
    connection.is_open.return_value = True
    return connection


def _connect_factory(connections: list[MagicMock]) -> Callable[..., Any]:
    """Return a fake `_connect` coroutine that pops `connections` in order."""

    async def fake_connect(*_args: Any, **_kwargs: Any) -> MagicMock:
        return connections.pop(0)

    return fake_connect


@pytest.fixture
def pool() -> Iterator[_ConnectionPool]:
    """Build a `_ConnectionPool` with default cap and stubbed awscrt resources."""
    instance = _ConnectionPool()
    with patch.object(instance, "_ensure_resources", return_value=(MagicMock(), MagicMock())):
        yield instance


@pytest.mark.asyncio
async def test_acquire_connection_yields_open_connection(pool: _ConnectionPool) -> None:
    """`acquire_connection` is an async context manager yielding an open connection."""
    connection = _open_connection_mock()
    with patch.object(_connection_pool, "_connect", side_effect=_connect_factory([connection])):
        async with pool.acquire_connection(host="x.com", port=443) as leased:
            assert leased is connection
            assert leased.is_open()


@pytest.mark.asyncio
async def test_acquire_connection_reuses_idle_connection_after_release(
    pool: _ConnectionPool,
) -> None:
    """Sequential acquire/release reuses the same idle connection (single connect call)."""
    connection = _open_connection_mock()
    connect_calls = 0

    async def fake_connect(*_args: Any, **_kwargs: Any) -> MagicMock:
        nonlocal connect_calls
        connect_calls += 1
        return connection

    with patch.object(_connection_pool, "_connect", side_effect=fake_connect):
        async with pool.acquire_connection(host="x.com", port=443) as first:
            assert first is connection
        async with pool.acquire_connection(host="x.com", port=443) as second:
            assert second is connection

    assert connect_calls == 1


@pytest.mark.asyncio
async def test_concurrent_acquire_same_key_opens_distinct_connections(
    pool: _ConnectionPool,
) -> None:
    """Two leases held simultaneously on the same key get separate connections."""
    connections = [_open_connection_mock(), _open_connection_mock()]
    both_acquired = asyncio.Event()
    seen: list[MagicMock] = []

    async def hold_lease() -> MagicMock:
        async with pool.acquire_connection(host="x.com", port=443) as conn:
            seen.append(conn)
            if len(seen) == _CONCURRENT_LEASES:
                both_acquired.set()
            else:
                await asyncio.wait_for(both_acquired.wait(), timeout=_TEST_TIMEOUT_SECONDS)
            return conn

    with patch.object(
        _connection_pool, "_connect", side_effect=_connect_factory(list(connections))
    ):
        results = await asyncio.gather(hold_lease(), hold_lease())

    assert results[0] is not results[1]
    assert {id(r) for r in results} == {id(c) for c in connections}


@pytest.mark.asyncio
async def test_acquire_blocks_when_max_size_per_key_reached() -> None:
    """When `max_size_per_key` connections are leased, the next acquire waits for a release."""
    instance = _ConnectionPool(max_size_per_key=2)
    connections = [_open_connection_mock() for _ in range(2)]
    release_first_two = asyncio.Event()
    third_acquired = asyncio.Event()

    async def hold_until_release() -> None:
        async with instance.acquire_connection(host="x.com", port=443):
            await asyncio.wait_for(release_first_two.wait(), timeout=_TEST_TIMEOUT_SECONDS)

    async def acquire_third() -> None:
        async with instance.acquire_connection(host="x.com", port=443):
            third_acquired.set()

    with (
        patch.object(instance, "_ensure_resources", return_value=(MagicMock(), MagicMock())),
        patch.object(_connection_pool, "_connect", side_effect=_connect_factory(list(connections))),
    ):
        first = asyncio.create_task(hold_until_release())
        second = asyncio.create_task(hold_until_release())
        # Yield enough times to let both first/second enter the lease and increment in_use.
        for _ in range(3):
            await asyncio.sleep(0)
        third = asyncio.create_task(acquire_third())
        # Yield enough times for the third task to attempt acquisition; it must block.
        for _ in range(3):
            await asyncio.sleep(0)
        assert not third_acquired.is_set()

        release_first_two.set()
        await asyncio.wait_for(third_acquired.wait(), timeout=_TEST_TIMEOUT_SECONDS)
        await asyncio.gather(first, second, third)


@pytest.mark.asyncio
async def test_acquire_recovers_from_stale_idle_connection(pool: _ConnectionPool) -> None:
    """An idle connection that is no longer open is dropped and replaced on the next acquire."""
    stale = _open_connection_mock()
    fresh = _open_connection_mock()

    with patch.object(_connection_pool, "_connect", side_effect=_connect_factory([stale, fresh])):
        async with pool.acquire_connection(host="x.com", port=443) as first:
            assert first is stale
        # Mark the cached connection as no longer open before the second acquire.
        stale.is_open.return_value = False
        async with pool.acquire_connection(host="x.com", port=443) as second:
            assert second is fresh

    stale.close.assert_called_once()


@pytest.mark.asyncio
async def test_close_all_closes_idle_but_not_busy_connections(pool: _ConnectionPool) -> None:
    """`close_all` closes idle connections immediately; busy ones survive until release."""
    conn_a = _open_connection_mock()
    conn_b = _open_connection_mock()

    with patch.object(_connection_pool, "_connect", side_effect=_connect_factory([conn_a, conn_b])):
        ctx_a = pool.acquire_connection(host="x.com", port=443)
        ctx_b = pool.acquire_connection(host="x.com", port=443)
        leased_a = await ctx_a.__aenter__()
        leased_b = await ctx_b.__aenter__()

        # Release the first lease so leased_a moves to idle.
        await ctx_a.__aexit__(None, None, None)

        await pool.close_all()
        leased_a.close.assert_called_once()
        leased_b.close.assert_not_called()

        # Releasing a busy lease after close_all closes the connection too.
        await ctx_b.__aexit__(None, None, None)
        leased_b.close.assert_called_once()


@pytest.mark.asyncio
async def test_concurrent_acquire_different_keys_runs_in_parallel(
    pool: _ConnectionPool,
) -> None:
    """Acquires for different keys do not block each other."""
    conn_a = _open_connection_mock()
    conn_b = _open_connection_mock()
    a_can_finish = asyncio.Event()

    async def fake_connect(host: str, _port: int, **_kwargs: Any) -> MagicMock:
        if host == "a.com":
            await asyncio.wait_for(a_can_finish.wait(), timeout=_TEST_TIMEOUT_SECONDS)
            return conn_a
        a_can_finish.set()
        return conn_b

    async def acquire(host: str) -> MagicMock:
        async with pool.acquire_connection(host=host, port=443) as conn:
            return conn

    with patch.object(_connection_pool, "_connect", side_effect=fake_connect):
        results = await asyncio.wait_for(
            asyncio.gather(acquire("a.com"), acquire("b.com")),
            timeout=_TEST_TIMEOUT_SECONDS,
        )

    assert results == [conn_a, conn_b]


def test_get_default_pool_returns_singleton(monkeypatch: pytest.MonkeyPatch) -> None:
    """`get_default_pool()` returns the same instance across repeated calls."""
    monkeypatch.setattr(_connection_pool, "_default_pool", None)
    first = _connection_pool.get_default_pool()
    second = _connection_pool.get_default_pool()
    assert first is second
