"""Test the awscrt-based HTTP/2 streaming client wrapper."""

from __future__ import annotations

from concurrent.futures import Future
from typing import TYPE_CHECKING, Any
from unittest.mock import MagicMock, patch

import pytest

from amazon_polly_streaming import _http2
from amazon_polly_streaming._buffered_stream import BufferableByteStream

if TYPE_CHECKING:
    from collections.abc import Callable

_INITIAL_SIGNATURE_HEX = "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"


class _FakeHeaders:
    """Minimal stand-in for `awscrt.http.HttpHeaders` exposing `.get`."""

    def __init__(self, items: list[tuple[str, str]]) -> None:
        self._items = items

    def get(self, name: str) -> str | None:
        for key, value in self._items:
            if key.lower() == name.lower():
                return value
        return None


class _FakeStream:
    """Fake `HttpClientStream` driven by the test to deliver headers and body."""

    def __init__(
        self,
        on_headers: Callable[..., None],
        on_body: Callable[..., None],
        status_code: int,
        chunks: list[bytes],
    ) -> None:
        self._on_headers = on_headers
        self._on_body = on_body
        self._status_code = status_code
        self._chunks = chunks
        self.completion_future: Future[int] = Future()

    def activate(self) -> None:
        """Invoke headers/body callbacks then resolve completion future."""
        self._on_headers(
            status_code=self._status_code,
            headers=[(":status", str(self._status_code))],
        )
        for chunk in self._chunks:
            self._on_body(chunk=chunk)
        self.completion_future.set_result(self._status_code)


class _FakeConnection:
    """Fake `HttpClientConnection` returning preconfigured streams."""

    def __init__(self, status_code: int, chunks: list[bytes]) -> None:
        self._status_code = status_code
        self._chunks = chunks

    def request(
        self,
        request: object,  # noqa: ARG002
        on_headers: Callable[..., None],
        on_body: Callable[..., None],
    ) -> _FakeStream:
        return _FakeStream(on_headers, on_body, self._status_code, self._chunks)


def _make_signed_future(*, signature_hex: str = _INITIAL_SIGNATURE_HEX) -> Future[Any]:
    fut: Future[Any] = Future()
    signed_request = MagicMock()
    auth_value = (
        "AWS4-HMAC-SHA256 "
        "Credential=AKIA.../20260501/us-west-2/polly/aws4_request, "
        "SignedHeaders=host;x-amz-date, "
        f"Signature={signature_hex}"
    )
    signed_request.headers = _FakeHeaders([("authorization", auth_value)])
    fut.set_result(signed_request)
    return fut


@pytest.mark.asyncio
async def test_open_stream_returns_handle_with_response_chunks() -> None:
    """`open_stream` returns a handle whose `response_chunks` yields each delivered chunk."""
    chunks = [b"first-chunk", b"second-chunk"]
    connection = _FakeConnection(status_code=200, chunks=chunks)

    with (
        patch.object(_http2, "aws_sign_request", return_value=_make_signed_future()),
        patch.object(_http2, "AwsCredentialsProvider"),
        patch.object(_http2, "AwsSigningConfig"),
    ):
        handle = await _http2.open_stream(
            url="https://polly.us-west-2.amazonaws.com/v1/synthesisStream",
            method="POST",
            headers={"x-amzn-Engine": "generative"},
            region="us-west-2",
            service="polly",
            connection=connection,
        )
        received = [chunk async for chunk in handle.response_chunks]

    assert received == chunks


@pytest.mark.asyncio
async def test_open_stream_exposes_writable_body_channel() -> None:
    """`open_stream` returns a `BufferableByteStream` body the caller can append to."""
    connection = _FakeConnection(status_code=200, chunks=[])

    with (
        patch.object(_http2, "aws_sign_request", return_value=_make_signed_future()),
        patch.object(_http2, "AwsCredentialsProvider"),
        patch.object(_http2, "AwsSigningConfig"),
    ):
        handle = await _http2.open_stream(
            url="https://polly.us-west-2.amazonaws.com/v1/synthesisStream",
            method="POST",
            headers={"x-amzn-Engine": "generative"},
            region="us-west-2",
            service="polly",
            connection=connection,
        )

    assert isinstance(handle.body, BufferableByteStream)
    written = handle.body.write(b"signed-event-bytes")
    assert written == len(b"signed-event-bytes")


@pytest.mark.asyncio
async def test_open_stream_extracts_initial_signature_from_authorization() -> None:
    """`initial_signature` is the 32 raw bytes parsed from the `Signature=...` field."""
    connection = _FakeConnection(status_code=200, chunks=[])

    with (
        patch.object(_http2, "aws_sign_request", return_value=_make_signed_future()),
        patch.object(_http2, "AwsCredentialsProvider"),
        patch.object(_http2, "AwsSigningConfig"),
    ):
        handle = await _http2.open_stream(
            url="https://polly.us-west-2.amazonaws.com/v1/synthesisStream",
            method="POST",
            headers={"x-amzn-Engine": "generative"},
            region="us-west-2",
            service="polly",
            connection=connection,
        )

    assert handle.initial_signature == bytes.fromhex(_INITIAL_SIGNATURE_HEX)


@pytest.mark.asyncio
async def test_open_stream_raises_on_non_2xx() -> None:
    """`open_stream` raises RuntimeError when the response status is not 2xx."""
    connection = _FakeConnection(status_code=400, chunks=[b"error-body"])

    with (
        patch.object(_http2, "aws_sign_request", return_value=_make_signed_future()),
        patch.object(_http2, "AwsCredentialsProvider"),
        patch.object(_http2, "AwsSigningConfig"),
        pytest.raises(RuntimeError, match="400"),
    ):
        await _http2.open_stream(
            url="https://polly.us-west-2.amazonaws.com/v1/synthesisStream",
            method="POST",
            headers={"x-amzn-Engine": "generative"},
            region="us-west-2",
            service="polly",
            connection=connection,
        )


@pytest.mark.asyncio
async def test_open_stream_raises_when_authorization_lacks_signature_field() -> None:
    """If SigV4 signing produces a malformed Authorization header, `open_stream` raises."""
    connection = _FakeConnection(status_code=200, chunks=[])

    bad_signed: Future[Any] = Future()
    bad_signed_request = MagicMock()
    bad_signed_request.headers = _FakeHeaders(
        [("authorization", "AWS4-HMAC-SHA256 ...no-signature...")]
    )
    bad_signed.set_result(bad_signed_request)

    with (
        patch.object(_http2, "aws_sign_request", return_value=bad_signed),
        patch.object(_http2, "AwsCredentialsProvider"),
        patch.object(_http2, "AwsSigningConfig"),
        pytest.raises(RuntimeError, match="Signature="),
    ):
        await _http2.open_stream(
            url="https://polly.us-west-2.amazonaws.com/v1/synthesisStream",
            method="POST",
            headers={"x-amzn-Engine": "generative"},
            region="us-west-2",
            service="polly",
            connection=connection,
        )
