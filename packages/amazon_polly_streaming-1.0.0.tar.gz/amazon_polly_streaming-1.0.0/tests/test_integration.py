"""Integration test that hits real AWS Polly. Marked `integration`, deselected by default.

To run this integration test against real Polly:

    AWS_PROFILE=your-profile uv run pytest -m integration

This requires valid AWS credentials in the default chain (env vars, profile,
or IAM role) with the bidirectional streaming permission for Polly.
"""

from __future__ import annotations

import pytest

from amazon_polly_streaming import PollyStreamingClient

_MIN_EXPECTED_AUDIO_BYTES = 1000


@pytest.mark.integration
@pytest.mark.asyncio
async def test_start_speech_synthesis_stream_returns_audio_from_real_polly() -> None:
    """End-to-end smoke test: synthesize a short phrase and assert audio is returned."""
    client = PollyStreamingClient(region="eu-central-1")
    audio = b""
    async for chunk in client.start_speech_synthesis_stream(
        text="hello world, how are you today",
        voice_id="Matthew",
        engine="generative",
        language_code="en-US",
        output_format="mp3",
        sample_rate="24000",
    ):
        audio += chunk

    assert len(audio) >= _MIN_EXPECTED_AUDIO_BYTES, (
        f"Expected at least {_MIN_EXPECTED_AUDIO_BYTES} bytes of audio, got {len(audio)}"
    )
