"""Test the public `PollyStreamingClient` API."""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from amazon_polly_streaming import (
    PollyStreamingClient,
    ServiceException,
    ServiceFailureException,
    ServiceQuotaExceededException,
    ThrottlingException,
    ValidationException,
)
from amazon_polly_streaming._buffered_stream import BufferableByteStream
from amazon_polly_streaming._event_signer import EventSignerCredentials
from amazon_polly_streaming._eventstream import encode_message, encode_messages
from amazon_polly_streaming._http2 import StreamHandle

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

_AUDIO_EVENT_HEADERS = {
    ":message-type": "event",
    ":event-type": "AudioEvent",
    ":content-type": "application/octet-stream",
}
_TEXT_EVENT_HEADERS = {
    ":message-type": "event",
    ":event-type": "TextEvent",
    ":content-type": "application/json",
}

_FAKE_INITIAL_SIGNATURE = bytes.fromhex(
    "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
)
_FAKE_CREDENTIALS = EventSignerCredentials(
    access_key_id="AKIATEST",
    secret_access_key="testsecretkey",  # noqa: S106
    session_token=None,
)


def _make_chunks(body: bytes) -> AsyncIterator[bytes]:
    """Wrap `body` into a single-chunk async iterator."""

    async def gen() -> AsyncIterator[bytes]:
        yield body

    return gen()


def _make_handle(response_body: bytes) -> StreamHandle:
    return StreamHandle(
        initial_signature=_FAKE_INITIAL_SIGNATURE,
        body=BufferableByteStream(),
        response_chunks=_make_chunks(response_body),
    )


@asynccontextmanager
async def _fake_lease() -> AsyncIterator[MagicMock]:
    """Yield a dummy connection mock without any awscrt I/O."""
    yield MagicMock()


def _fake_acquire(*_args: object, **_kwargs: object) -> object:
    """Return a fresh dummy lease each time `_acquire_polly_connection` is called."""
    return _fake_lease()


@pytest.fixture
def patch_credentials() -> object:
    """Bypass the real botocore credential chain in unit tests."""
    with patch(
        "amazon_polly_streaming.client._resolve_event_credentials",
        return_value=_FAKE_CREDENTIALS,
    ) as fixture:
        yield fixture


@pytest.fixture
def patch_acquire(monkeypatch: pytest.MonkeyPatch) -> MagicMock:
    """Patch `_acquire_polly_connection` to skip awscrt I/O and yield a dummy connection."""
    mock = MagicMock(side_effect=_fake_acquire)
    monkeypatch.setattr("amazon_polly_streaming.client._acquire_polly_connection", mock)
    return mock


@pytest.mark.asyncio
async def test_start_speech_synthesis_stream_yields_audio_chunks_from_audio_events(
    patch_credentials: object,  # noqa: ARG001
    patch_acquire: MagicMock,  # noqa: ARG001
) -> None:
    """`start_speech_synthesis_stream` yields the payload of each AudioEvent in order."""
    body = encode_messages(
        [
            (_AUDIO_EVENT_HEADERS, b"chunk_a"),
            (_AUDIO_EVENT_HEADERS, b"chunk_b"),
        ]
    )
    handle = _make_handle(body)

    async def fake_open_stream(**_: object) -> StreamHandle:
        return handle

    with patch("amazon_polly_streaming.client.open_stream", side_effect=fake_open_stream):
        client = PollyStreamingClient()
        received = [
            chunk
            async for chunk in client.start_speech_synthesis_stream(
                text="hello", voice_id="Matthew"
            )
        ]

    assert received == [b"chunk_a", b"chunk_b"]


@pytest.mark.asyncio
async def test_start_speech_synthesis_stream_skips_non_audio_event_messages(
    patch_credentials: object,  # noqa: ARG001
    patch_acquire: MagicMock,  # noqa: ARG001
) -> None:
    """`start_speech_synthesis_stream` does not yield non-AudioEvent event messages."""
    body = encode_messages(
        [
            (_TEXT_EVENT_HEADERS, b'{"text": "ignored"}'),
            (_AUDIO_EVENT_HEADERS, b"only_audio"),
        ]
    )
    handle = _make_handle(body)

    async def fake_open_stream(**_: object) -> StreamHandle:
        return handle

    with patch("amazon_polly_streaming.client.open_stream", side_effect=fake_open_stream):
        client = PollyStreamingClient()
        received = [
            chunk
            async for chunk in client.start_speech_synthesis_stream(
                text="hello", voice_id="Matthew"
            )
        ]

    assert received == [b"only_audio"]


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("exception_type_header", "expected_class"),
    [
        ("ServiceFailureException", ServiceFailureException),
        ("ValidationException", ValidationException),
        ("ServiceQuotaExceededException", ServiceQuotaExceededException),
        ("ThrottlingException", ThrottlingException),
        ("UnknownException", ServiceException),
    ],
)
async def test_start_speech_synthesis_stream_maps_exception_type_header_to_typed_exception(
    patch_credentials: object,  # noqa: ARG001
    patch_acquire: MagicMock,  # noqa: ARG001
    exception_type_header: str,
    expected_class: type[ServiceException],
) -> None:
    """Maps `:exception-type` header to the typed exception class (fallback to base)."""
    headers = {
        ":message-type": "exception",
        ":exception-type": exception_type_header,
        ":content-type": "application/json",
    }
    body = encode_message(headers, b'{"message": "boom"}')
    handle = _make_handle(body)

    async def fake_open_stream(**_: object) -> StreamHandle:
        return handle

    with patch("amazon_polly_streaming.client.open_stream", side_effect=fake_open_stream):
        client = PollyStreamingClient()
        with pytest.raises(expected_class):
            async for _ in client.start_speech_synthesis_stream(text="hello", voice_id="Matthew"):
                pass


@pytest.mark.asyncio
async def test_start_speech_synthesis_stream_raises_service_exception_on_unknown_message_type(
    patch_credentials: object,  # noqa: ARG001
    patch_acquire: MagicMock,  # noqa: ARG001
) -> None:
    """Unknown `:message-type` raises base `ServiceException`."""
    headers = {":message-type": "weird", ":content-type": "application/json"}
    body = encode_message(headers, b"{}")
    handle = _make_handle(body)

    async def fake_open_stream(**_: object) -> StreamHandle:
        return handle

    with patch("amazon_polly_streaming.client.open_stream", side_effect=fake_open_stream):
        client = PollyStreamingClient()
        with pytest.raises(ServiceException, match="unexpected message"):
            async for _ in client.start_speech_synthesis_stream(text="hello", voice_id="Matthew"):
                pass


@pytest.mark.asyncio
async def test_start_speech_synthesis_stream_passes_voice_config_in_headers(
    patch_credentials: object,  # noqa: ARG001
    patch_acquire: MagicMock,  # noqa: ARG001
) -> None:
    """`start_speech_synthesis_stream` forwards voice/engine/format/rate as `x-amzn-*` headers."""
    body = encode_message(_AUDIO_EVENT_HEADERS, b"audio")
    captured: dict[str, object] = {}

    async def fake_open_stream(**kwargs: object) -> StreamHandle:
        captured.update(kwargs)
        return _make_handle(body)

    with patch("amazon_polly_streaming.client.open_stream", side_effect=fake_open_stream):
        client = PollyStreamingClient(region="us-west-2")
        async for _ in client.start_speech_synthesis_stream(
            text="ciao",
            voice_id="Matthew",
            engine="generative",
            language_code="en-US",
            output_format="mp3",
            sample_rate="24000",
        ):
            pass

    assert captured["url"] == "https://polly.us-west-2.amazonaws.com/v1/synthesisStream"
    assert captured["method"] == "POST"
    assert captured["region"] == "us-west-2"
    assert captured["service"] == "polly"

    headers = captured["headers"]
    assert isinstance(headers, dict)
    assert headers["x-amzn-Engine"] == "generative"
    assert headers["x-amzn-LanguageCode"] == "en-US"
    assert headers["x-amzn-OutputFormat"] == "mp3"
    assert headers["x-amzn-SampleRate"] == "24000"
    assert headers["x-amzn-VoiceId"] == "Matthew"
    assert headers["content-type"] == "application/vnd.amazon.eventstream"


@pytest.mark.asyncio
async def test_start_speech_synthesis_stream_writes_signed_events_to_body_channel(
    patch_credentials: object,  # noqa: ARG001
    patch_acquire: MagicMock,  # noqa: ARG001
) -> None:
    """`start_speech_synthesis_stream` writes wrapper-framed events to the request body channel."""
    body = encode_message(_AUDIO_EVENT_HEADERS, b"audio")
    handle = _make_handle(body)

    async def fake_open_stream(**_: object) -> StreamHandle:
        return handle

    with patch("amazon_polly_streaming.client.open_stream", side_effect=fake_open_stream):
        client = PollyStreamingClient()
        async for _ in client.start_speech_synthesis_stream(text="hello world", voice_id="Matthew"):
            pass

    # After synthesis, the body channel should be ended and contain the
    # wrapper-encoded TextEvent + CloseStreamEvent + end-of-stream marker.
    handle.body.end_stream()  # idempotent for ended streams
    drained = b""
    while True:
        try:
            chunk = handle.body.read()
        except BlockingIOError:  # pragma: no cover - defensive
            break
        if not chunk:
            break
        drained += chunk
    expected_min_messages = 3
    assert drained.count(b"\x00\x00\x00") >= expected_min_messages  # at least three frames


@pytest.mark.asyncio
async def test_start_speech_synthesis_stream_default_use_pool_is_true(
    patch_credentials: object,  # noqa: ARG001
    patch_acquire: MagicMock,
) -> None:
    """`start_speech_synthesis_stream` defaults to `use_pool=True` when omitted."""
    body = encode_message(_AUDIO_EVENT_HEADERS, b"audio")

    async def fake_open_stream(**_kwargs: object) -> StreamHandle:
        return _make_handle(body)

    with patch("amazon_polly_streaming.client.open_stream", side_effect=fake_open_stream):
        client = PollyStreamingClient()
        async for _ in client.start_speech_synthesis_stream(text="hi", voice_id="Matthew"):
            pass

    patch_acquire.assert_called_once()
    _args, kwargs = patch_acquire.call_args
    assert kwargs["use_pool"] is True


@pytest.mark.asyncio
async def test_start_speech_synthesis_stream_propagates_use_pool_false(
    patch_credentials: object,  # noqa: ARG001
    patch_acquire: MagicMock,
) -> None:
    """`use_pool=False` is forwarded to `_acquire_polly_connection`."""
    body = encode_message(_AUDIO_EVENT_HEADERS, b"audio")

    async def fake_open_stream(**_kwargs: object) -> StreamHandle:
        return _make_handle(body)

    with patch("amazon_polly_streaming.client.open_stream", side_effect=fake_open_stream):
        client = PollyStreamingClient()
        async for _ in client.start_speech_synthesis_stream(
            text="hi", voice_id="Matthew", use_pool=False
        ):
            pass

    patch_acquire.assert_called_once()
    _args, kwargs = patch_acquire.call_args
    assert kwargs["use_pool"] is False
