"""selvo REST API package."""
