"""Synchronous HTTP client for the Mipiti verification API."""

from __future__ import annotations

import os
from typing import Any

import httpx

DEFAULT_BASE_URL = "https://api.mipiti.io"


class MipitiClient:
    """Sync httpx client for pulling pending assertions and submitting results."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self.api_key = api_key or os.environ.get("MIPITI_API_KEY", "")
        self.base_url = (
            base_url or os.environ.get("MIPITI_BASE_URL", DEFAULT_BASE_URL)
        ).rstrip("/")
        if not self.api_key:
            raise ValueError(
                "MIPITI_API_KEY is required. Set it as an environment variable "
                "or pass api_key= to MipitiClient."
            )
        self.key_scope = "verifier" if self.api_key.startswith("mv_") else "developer"
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={"X-API-Key": self.api_key},
            timeout=httpx.Timeout(connect=10.0, read=120.0, write=10.0, pool=10.0),
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> MipitiClient:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Pending assertions (CI pull)
    # ------------------------------------------------------------------

    def get_pending(
        self, model_id: str, tier: int = 1, stale_after: int = 24, repo: str = "",
    ) -> dict[str, Any]:
        """GET /api/models/{id}/verification/pending?tier={t}&repo={r}

        Returns ``{"model_id": ..., "tier": ..., "controls": {ctrl_id: [assertions]}, "assumptions": {as_id: [assertions]}}``
        """
        params: dict[str, Any] = {"tier": tier, "stale_after": stale_after}
        if repo:
            params["repo"] = repo
        resp = self._client.get(
            f"/api/models/{model_id}/verification/pending",
            params=params,
        )
        resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------
    # All assertions (for --reverify mode)
    # ------------------------------------------------------------------

    def get_all_assertions(self, model_id: str, repo: str = "") -> dict[str, Any]:
        """GET /api/models/{id}/verification/assertions?repo={r}

        Returns ``{"model_id": ..., "controls": {ctrl_id: [assertions]}, "assumptions": {as_id: [assertions]}}``
        """
        params: dict[str, Any] = {}
        if repo:
            params["repo"] = repo
        resp = self._client.get(
            f"/api/models/{model_id}/verification/assertions",
            params=params,
        )
        resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------
    # Submit results
    # ------------------------------------------------------------------

    def submit_results(
        self,
        model_id: str,
        pipeline: dict[str, Any],
        results: list[dict[str, Any]],
        bundle: str = "",
        signature: str = "",
        signed_hash: str = "",
        content_hash: str = "",
    ) -> dict[str, Any]:
        """POST /api/models/{id}/verification/results

        CI-side attestation is carried by `bundle` — a Sigstore bundle (JSON-
        serialised, bundle_v0.3) minted locally from the runner's OIDC token.
        The raw token never leaves the runner; the backend verifies the bundle
        against the Sigstore transparency log.

        Self-hosted deployments without OIDC supply `signature` + `signed_hash`
        produced with a workspace ECDSA key instead.
        """
        body: dict[str, Any] = {
            "pipeline": pipeline,
            "results": results,
            "content_hash": content_hash,
        }
        if bundle:
            body["bundle"] = bundle
        if signature:
            body["signature"] = signature
        if signed_hash:
            body["signed_hash"] = signed_hash

        resp = self._client.post(
            f"/api/models/{model_id}/verification/results",
            json=body,
        )
        resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------
    # Model listing (for --all mode)
    # ------------------------------------------------------------------

    def list_models(self) -> list[dict[str, Any]]:
        """GET /api/models — list models accessible by this API key's workspace."""
        resp = self._client.get("/api/models")
        resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------
    # Model / controls info (for context)
    # ------------------------------------------------------------------

    def get_model(self, model_id: str) -> dict[str, Any]:
        """GET /api/models/{id} — full model with controls."""
        resp = self._client.get(f"/api/models/{model_id}")
        resp.raise_for_status()
        return resp.json()

    def get_controls(self, model_id: str, component_id: str = "") -> dict[str, Any]:
        """GET /api/models/{id}/controls — returns controls response dict."""
        params: dict[str, str] = {}
        if component_id:
            params["component_id"] = component_id
        resp = self._client.get(f"/api/models/{model_id}/controls", params=params)
        resp.raise_for_status()
        return resp.json()

    def get_verification_report(self, model_id: str) -> dict[str, Any]:
        """GET /api/models/{id}/verification/report"""
        resp = self._client.get(f"/api/models/{model_id}/verification/report")
        resp.raise_for_status()
        return resp.json()


