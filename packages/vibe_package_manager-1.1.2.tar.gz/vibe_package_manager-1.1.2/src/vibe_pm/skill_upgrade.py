"""SKILL upgrade logic — push local changes back to upstream repo for code review."""

import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional


GIT_TIMEOUT_CLONE = 60
GIT_TIMEOUT_CHECKOUT = 30
GIT_TIMEOUT_PUSH = 60


def _debug_log(message: str, debug: bool) -> None:
    """Print debug message if debug mode is enabled."""
    if debug:
        print(f"[DEBUG] [SkillUpgrade] {message}")


def _is_branch(git_tag: str, repo_dir: Path) -> bool:
    """Check if git_tag corresponds to a remote branch (not a tag or commit SHA)."""
    # 40-char hex is a commit SHA
    if re.fullmatch(r"[0-9a-fA-F]{40}", git_tag):
        return False
    # Check against remote branches
    result = subprocess.run(
        ["git", "branch", "-r", "--list", f"origin/{git_tag}"],
        cwd=repo_dir,
        capture_output=True,
        text=True,
        timeout=10,
    )
    return bool(result.stdout.strip())


def _resolve_push_refspec(git_tag: str, repo_dir: Path, debug: bool = False) -> str:
    """Return the Gerrit refspec: refs/for/<branch> or refs/for/master."""
    if _is_branch(git_tag, repo_dir):
        refspec = f"refs/for/{git_tag}"
        _debug_log(f"git_tag '{git_tag}' is a branch, push to {refspec}", debug)
    else:
        refspec = "refs/for/master"
        _debug_log(f"git_tag '{git_tag}' is a tag/SHA, push to {refspec}", debug)
    return refspec


def upgrade_skill(
    skill_name: str,
    skill_config: Dict[str, Any],
    agent: str,
    base_dir: Path,
    commit_message: Optional[str] = None,
    debug: bool = False,
) -> None:
    """Push local skill changes back to the upstream repo for code review.

    Args:
        skill_name: Name of the skill to upgrade
        skill_config: Skill configuration dict from vibe_package.json (git, git_tag, path)
        agent: Agent name (claude, qoder, codex)
        base_dir: Base directory (where vibe_package.json lives)
        commit_message: Custom commit message
        debug: Enable debug logging
    """
    git_url = skill_config["git"]
    git_tag = skill_config["git_tag"]
    skill_path = skill_config.get("path")

    # 1. Validate local skill directory
    local_skill_dir = base_dir / f".{agent}" / "skills" / skill_name
    if not local_skill_dir.exists():
        raise FileNotFoundError(
            f"Local skill directory not found: {local_skill_dir}\n"
            f"Please run 'vpm install' first to install the skill."
        )
    _debug_log(f"Local skill directory: {local_skill_dir}", debug)

    # 2. Create temp directory for clone
    tmp_dir = tempfile.mkdtemp(prefix=f"vpm_upgrade_{skill_name}_")
    clone_dir = Path(tmp_dir) / "repo"
    _debug_log(f"Temp directory: {tmp_dir}", debug)

    try:
        # 3. Clone upstream repo
        print(f"Cloning {git_url} ...")
        try:
            subprocess.run(
                ["git", "clone", git_url, str(clone_dir)],
                check=True,
                capture_output=True,
                text=True,
                timeout=GIT_TIMEOUT_CLONE,
            )
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Failed to clone '{git_url}': {e.stderr.strip()}") from e

        # Checkout git_tag
        _debug_log(f"Checking out '{git_tag}' ...", debug)
        try:
            subprocess.run(
                ["git", "checkout", git_tag],
                cwd=clone_dir,
                check=True,
                capture_output=True,
                text=True,
                timeout=GIT_TIMEOUT_CHECKOUT,
            )
        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                f"Failed to checkout '{git_tag}': {e.stderr.strip()}"
            ) from e

        # 4. Determine copy target in clone
        if skill_path:
            target_dir = clone_dir / skill_path
            if not target_dir.exists():
                raise FileNotFoundError(
                    f"Path '{skill_path}' not found in repository '{git_url}'"
                )
        else:
            target_dir = clone_dir
        _debug_log(f"Copy target in clone: {target_dir}", debug)

        # 5. Clear target contents (preserve .git at repo root)
        _debug_log("Clearing target directory contents ...", debug)
        for item in target_dir.iterdir():
            if item.name == ".git":
                continue
            if item.is_dir():
                shutil.rmtree(item)
            else:
                item.unlink()

        # Copy local skill files into target
        _debug_log(f"Copying from {local_skill_dir} to {target_dir} ...", debug)
        shutil.copytree(
            local_skill_dir,
            target_dir,
            dirs_exist_ok=True,
            ignore=shutil.ignore_patterns(".git"),
        )

        # 6. Stage and check for changes
        subprocess.run(
            ["git", "add", "-A"],
            cwd=clone_dir,
            check=True,
            capture_output=True,
            text=True,
        )

        diff_result = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            cwd=clone_dir,
            capture_output=True,
        )
        if diff_result.returncode == 0:
            print(f"No changes detected for SKILL '{skill_name}'. Nothing to push.")
            return

        # Commit
        msg = commit_message or f"Upgrade SKILL '{skill_name}' from local changes"
        _debug_log(f"Committing with message: {msg}", debug)
        subprocess.run(
            ["git", "commit", "-m", msg],
            cwd=clone_dir,
            check=True,
            capture_output=True,
            text=True,
        )

        # 7. Resolve push refspec
        refspec = _resolve_push_refspec(git_tag, clone_dir, debug)

        # 8. Push
        print(f"Pushing to {refspec} ...")
        try:
            result = subprocess.run(
                ["git", "push", "origin", f"HEAD:{refspec}"],
                cwd=clone_dir,
                check=True,
                capture_output=True,
                text=True,
                timeout=GIT_TIMEOUT_PUSH,
            )
            if result.stderr:
                print(result.stderr.strip())
        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                f"Failed to push to '{refspec}': {e.stderr.strip()}"
            ) from e

        print(f"[OK] SKILL '{skill_name}' upgrade pushed to {refspec}")

    finally:
        # 9. Cleanup
        _debug_log("Cleaning up temp directory ...", debug)
        shutil.rmtree(tmp_dir, ignore_errors=True)
