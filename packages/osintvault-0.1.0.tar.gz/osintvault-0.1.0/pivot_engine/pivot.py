import json
from pathlib import Path

class PivotEngine:
    def __init__(self):
        patterns_path = Path(__file__).parent / "patterns.json"
        with open(patterns_path, "r", encoding="utf-8") as f:
            self.patterns = json.load(f)

    def pivot(self, entity_type, value):
        if entity_type not in self.patterns:
            raise ValueError(f"Unsupported entity type: {entity_type}")

        return {
            "entity": value,
            "type": entity_type,
            "pivots": self.patterns[entity_type]
        }

if __name__ == "__main__":
    engine = PivotEngine()
    result = engine.pivot("email", "test@example.com")
    print(result)
