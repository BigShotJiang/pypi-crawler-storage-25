from setuptools import setup, find_packages

setup(
    name="osintvault",
    version="0.1.0",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "osintvault=cli.main:main",
        ]
    },
)
