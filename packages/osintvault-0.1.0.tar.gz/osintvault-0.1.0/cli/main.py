import argparse
from pivot_engine.core import pivot_entity


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="osintvault",
        description="OSINT pivot CLI for entities like emails, domains, IPs, and usernames.",
    )
    parser.add_argument(
        "entity",
        help="The entity to pivot on (email, domain, IP, username, etc.).",
    )
    parser.add_argument(
        "--type",
        "-t",
        dest="etype",
        help="Optional explicit entity type (email, domain, ip, username).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    result = pivot_entity(args.entity, args.etype)
    print(result)


if __name__ == "__main__":
    main()
