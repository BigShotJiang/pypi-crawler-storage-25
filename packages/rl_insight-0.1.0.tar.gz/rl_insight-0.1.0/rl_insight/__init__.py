# Copyright (c) 2025 verl-project authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Cluster scheduling analysis and visualization for RL workloads.

This package exposes built-in parser classes and a CLI entry helper.
"""

from .parser import MstxClusterParser, TorchClusterParser


def main():
    # Lazy import avoids preloading rl_insight.main during package import.
    from .main import main as _main

    return _main()


__all__ = ["MstxClusterParser", "TorchClusterParser", "main"]
