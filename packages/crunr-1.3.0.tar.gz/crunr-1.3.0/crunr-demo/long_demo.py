"""
crunr demo — CPU endurance test (long-running job)

Three back-to-back compute phases: Monte Carlo Pi, SHA-256 hashing, prime
sieve. Each phase runs for PHASE_MINUTES minutes regardless of how fast the
machine is, so the total wall time is always ~2.5 hours.

Purpose: verify crunr handles multi-hour jobs without timeouts or disconnects.

Zero dependencies — pure Python stdlib, starts instantly.

CPU (t3.micro, 2 vCPU 1 GB):  ~2.5 hours, < $0.02
No GPU needed.

Run:
    crunr run long_demo.py --instance t3.micro --s3-bucket <bucket>
"""

import hashlib
import json
import math
import os
import random
import time
from pathlib import Path

Path("outputs").mkdir(exist_ok=True)

PHASE_MINUTES = 50      # × 3 phases = 2.5 hours
REPORT_EVERY  = 300     # print a progress line every 5 minutes

print("=" * 58)
print("  crunr Demo — CPU Endurance Test  (3 phases, ~2.5 hr)")
print("=" * 58)
print(f"  Instance  : t3.micro (2 vCPU, 1 GB RAM)")
print(f"  Each phase: {PHASE_MINUTES} min")
print(f"  Total     : ~{3 * PHASE_MINUTES} min  (~{3 * PHASE_MINUTES / 60:.1f} hr)")
print()

job_start = time.time()
results   = {}


# ---------------------------------------------------------------------------
# Phase 1 — Monte Carlo Pi
#   Drop random points in the unit square; fraction inside the unit circle
#   converges to π/4.  Pure arithmetic — no memory growth.
# ---------------------------------------------------------------------------

print("Phase 1 / 3 — Monte Carlo Pi estimation")
print()

phase_start = time.time()
phase_end   = phase_start + PHASE_MINUTES * 60
last_report = phase_start

inside = 0
total  = 0
rng    = random.Random(42)

while time.time() < phase_end:
    for _ in range(200_000):
        x = rng.random()
        y = rng.random()
        if x * x + y * y <= 1.0:
            inside += 1
    total += 200_000

    now = time.time()
    if now - last_report >= REPORT_EVERY:
        pi_est    = 4 * inside / total
        elapsed   = (now - phase_start) / 60
        remaining = (phase_end - now) / 60
        print(f"  [{elapsed:5.1f} min elapsed | {remaining:5.1f} min left]"
              f"  samples={total:>14,}  π≈{pi_est:.8f}"
              f"  err={abs(pi_est - math.pi):.2e}", flush=True)
        last_report = now

phase1_time = time.time() - phase_start
pi_est      = 4 * inside / total

print(f"\nPhase 1 complete — {phase1_time / 60:.1f} min")
print(f"  Samples   : {total:,}")
print(f"  Pi est.   : {pi_est:.10f}")
print(f"  True pi   : {math.pi:.10f}")
print(f"  Error     : {abs(pi_est - math.pi):.2e}\n")

results["phase1_monte_carlo_pi"] = {
    "duration_min": round(phase1_time / 60, 2),
    "samples":      total,
    "pi_estimate":  pi_est,
    "error":        abs(pi_est - math.pi),
}


# ---------------------------------------------------------------------------
# Phase 2 — SHA-256 hashing
#   Hash the same 1 MB random chunk repeatedly.  Tests integer + bitwise
#   throughput; the fixed chunk keeps memory flat at ~1 MB.
# ---------------------------------------------------------------------------

print("Phase 2 / 3 — SHA-256 hash throughput")
print()

phase_start   = time.time()
phase_end     = phase_start + PHASE_MINUTES * 60
last_report   = phase_start
chunks_hashed = 0
bytes_hashed  = 0
CHUNK         = os.urandom(1024 * 1024)   # 1 MB — allocated once

while time.time() < phase_end:
    for _ in range(50):
        hashlib.sha256(CHUNK).digest()
        chunks_hashed += 1
        bytes_hashed  += len(CHUNK)

    now = time.time()
    if now - last_report >= REPORT_EVERY:
        elapsed    = (now - phase_start) / 60
        remaining  = (phase_end - now) / 60
        throughput = bytes_hashed / (now - phase_start) / 1e6
        print(f"  [{elapsed:5.1f} min elapsed | {remaining:5.1f} min left]"
              f"  {chunks_hashed:>10,} chunks  {bytes_hashed/1e9:6.2f} GB"
              f"  {throughput:5.1f} MB/s", flush=True)
        last_report = now

phase2_time = time.time() - phase_start
throughput  = bytes_hashed / phase2_time / 1e6

print(f"\nPhase 2 complete — {phase2_time / 60:.1f} min")
print(f"  Chunks    : {chunks_hashed:,}")
print(f"  Data      : {bytes_hashed / 1e9:.2f} GB")
print(f"  Throughput: {throughput:.1f} MB/s\n")

results["phase2_sha256_hashing"] = {
    "duration_min":   round(phase2_time / 60, 2),
    "chunks_hashed":  chunks_hashed,
    "gb_hashed":      round(bytes_hashed / 1e9, 2),
    "throughput_mb_s": round(throughput, 1),
}


# ---------------------------------------------------------------------------
# Phase 3 — Sieve of Eratosthenes (repeated)
#   Classic prime sieve to N=500,000 run as many times as possible.
#   Uses a bytearray (500 KB) — safe for t3.micro's 1 GB RAM.
# ---------------------------------------------------------------------------

print("Phase 3 / 3 — Sieve of Eratosthenes  (N = 500,000, repeated)")
print()

N           = 500_000
phase_start = time.time()
phase_end   = phase_start + PHASE_MINUTES * 60
last_report = phase_start
runs        = 0
last_count  = 0

while time.time() < phase_end:
    sieve = bytearray([1]) * (N + 1)
    sieve[0] = sieve[1] = 0
    for i in range(2, int(N ** 0.5) + 1):
        if sieve[i]:
            for j in range(i * i, N + 1, i):
                sieve[j] = 0
    last_count = sum(sieve)
    runs += 1

    now = time.time()
    if now - last_report >= REPORT_EVERY:
        elapsed   = (now - phase_start) / 60
        remaining = (phase_end - now) / 60
        rate      = runs / (now - phase_start)
        print(f"  [{elapsed:5.1f} min elapsed | {remaining:5.1f} min left]"
              f"  {runs:>8,} runs  {rate:.3f} sieves/s"
              f"  primes={last_count:,}", flush=True)
        last_report = now

phase3_time = time.time() - phase_start
rate        = runs / phase3_time

print(f"\nPhase 3 complete — {phase3_time / 60:.1f} min")
print(f"  Runs      : {runs:,}")
print(f"  Rate      : {rate:.3f} sieves/s")
print(f"  Primes ≤ {N:,}: {last_count:,}\n")

results["phase3_prime_sieve"] = {
    "duration_min": round(phase3_time / 60, 2),
    "n":            N,
    "sieve_runs":   runs,
    "rate_per_s":   round(rate, 3),
    "primes_count": last_count,
}


# ---------------------------------------------------------------------------
# Save outputs
# ---------------------------------------------------------------------------

total_time = time.time() - job_start

summary = f"""crunr Demo — CPU Endurance Test Summary
========================================
Total time    : {total_time / 60:.1f} min  ({total_time:.0f}s)

Phase 1 — Monte Carlo Pi
  Duration    : {results['phase1_monte_carlo_pi']['duration_min']:.1f} min
  Samples     : {results['phase1_monte_carlo_pi']['samples']:,}
  Pi estimate : {results['phase1_monte_carlo_pi']['pi_estimate']:.10f}
  Error       : {results['phase1_monte_carlo_pi']['error']:.2e}

Phase 2 — SHA-256 Hashing
  Duration    : {results['phase2_sha256_hashing']['duration_min']:.1f} min
  Data hashed : {results['phase2_sha256_hashing']['gb_hashed']:.2f} GB
  Throughput  : {results['phase2_sha256_hashing']['throughput_mb_s']:.1f} MB/s

Phase 3 — Prime Sieve  (N = {N:,})
  Duration    : {results['phase3_prime_sieve']['duration_min']:.1f} min
  Sieve runs  : {results['phase3_prime_sieve']['sieve_runs']:,}
  Rate        : {results['phase3_prime_sieve']['rate_per_s']:.3f} sieves/s
  Primes      : {results['phase3_prime_sieve']['primes_count']:,}

Outputs
-------
  outputs/results.json   per-phase benchmark numbers
  outputs/summary.txt    this report
"""

Path("outputs/summary.txt").write_text(summary)
Path("outputs/results.json").write_text(json.dumps(results, indent=2))

print(summary)
print("Done. All outputs saved to outputs/")
