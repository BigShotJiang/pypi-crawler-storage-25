"""
crunr quick flow test — ~2 minutes on any CPU instance.

Verifies the full pipeline end-to-end:
  provision → sync → run → S3 upload → Phase 5 collect → self-terminate

Pure Python stdlib — zero pip installs, starts in seconds.

Run:
    crunr run quick_demo.py --instance t3.micro --s3-bucket <bucket>
"""

import hashlib
import json
import math
import random
import time
from pathlib import Path

Path("outputs").mkdir(exist_ok=True)

RUN_SECONDS = 90   # wall-clock target

print("=" * 50)
print("  crunr Quick Flow Test")
print("=" * 50)
print(f"  Runtime : ~{RUN_SECONDS}s")
print()

job_start = time.time()

# ── Phase 1: Monte Carlo Pi (45 s) ─────────────────────────────────────────
print("Step 1/2 — Monte Carlo Pi estimation")
t0       = time.time()
deadline = t0 + RUN_SECONDS // 2
inside = total = 0
rng = random.Random(42)

while time.time() < deadline:
    for _ in range(100_000):
        x, y = rng.random(), rng.random()
        if x * x + y * y <= 1.0:
            inside += 1
    total += 100_000

pi_est = 4 * inside / total
step1_s = time.time() - t0
print(f"  Samples : {total:,}")
print(f"  π ≈     : {pi_est:.8f}  (error {abs(pi_est - math.pi):.2e})")
print(f"  Time    : {step1_s:.1f}s")
print()

# ── Phase 2: SHA-256 throughput (45 s) ─────────────────────────────────────
print("Step 2/2 — SHA-256 hash throughput")
t0       = time.time()
deadline = t0 + RUN_SECONDS // 2
chunk    = b"crunr-flow-test-data" * 4096   # ~80 KB fixed chunk
hashes   = bytes_hashed = 0

while time.time() < deadline:
    for _ in range(20):
        hashlib.sha256(chunk).digest()
        hashes += 1
        bytes_hashed += len(chunk)

step2_s    = time.time() - t0
throughput = bytes_hashed / step2_s / 1e6
print(f"  Hashes  : {hashes:,}")
print(f"  Data    : {bytes_hashed / 1e6:.1f} MB")
print(f"  Speed   : {throughput:.1f} MB/s")
print(f"  Time    : {step2_s:.1f}s")
print()

# ── Save outputs ────────────────────────────────────────────────────────────
total_s = time.time() - job_start

results = {
    "total_seconds": round(total_s, 2),
    "monte_carlo_pi": {
        "samples": total,
        "estimate": pi_est,
        "error": abs(pi_est - math.pi),
        "seconds": round(step1_s, 2),
    },
    "sha256": {
        "hashes": hashes,
        "mb_hashed": round(bytes_hashed / 1e6, 1),
        "throughput_mb_s": round(throughput, 1),
        "seconds": round(step2_s, 2),
    },
}

summary = f"""crunr Quick Flow Test — Summary
================================
Total time  : {total_s:.1f}s

Step 1 — Monte Carlo Pi
  Samples   : {total:,}
  π estimate: {pi_est:.8f}
  Error     : {abs(pi_est - math.pi):.2e}

Step 2 — SHA-256
  Data      : {bytes_hashed / 1e6:.1f} MB hashed
  Speed     : {throughput:.1f} MB/s

Outputs
-------
  outputs/results.json
  outputs/summary.txt
"""

Path("outputs/results.json").write_text(json.dumps(results, indent=2))
Path("outputs/summary.txt").write_text(summary)

print(summary)
print("Done.")
