"""
crunr demo — Variational Autoencoder (VAE) on synthetic images

Trains a convolutional VAE to reconstruct synthetic colour-patch images.
After training it generates new images by sampling the latent space —
showing the generative side of GPU ML, unlike the classifier in demo.py.

GPU (g4dn.xlarge, T4 16 GB):  ~5-7 min
CPU: not recommended

Run:
    crunr run gpt_demo.py --gpu --instance g4dn.xlarge --s3-bucket <bucket>
"""

# ---------------------------------------------------------------------------
# Step 0: Re-exec with DL AMI Python (torch pre-installed)
# ---------------------------------------------------------------------------

import os
import subprocess
import sys
from pathlib import Path


def _reexec_dl() -> None:
    if os.environ.get("_CRUNR_REEXEC"):
        return
    for py in [
        "/opt/conda/envs/pytorch/bin/python3",
        "/opt/conda/envs/pytorch_p310/bin/python3",
        "/opt/conda/envs/pytorch_p39/bin/python3",
        "/opt/conda/bin/python3",
        "/home/ec2-user/anaconda3/envs/pytorch/bin/python3",
        "/home/ec2-user/miniconda3/envs/pytorch/bin/python3",
    ]:
        if not Path(py).exists() or py == sys.executable:
            continue
        try:
            r = subprocess.run([py, "-c", "import torch"],
                               capture_output=True, timeout=20)
            if r.returncode == 0:
                print(f"DL AMI detected — re-exec with {py}", flush=True)
                os.execve(py, [py] + sys.argv, {**os.environ, "_CRUNR_REEXEC": "1"})
        except Exception:
            continue


_reexec_dl()


# ---------------------------------------------------------------------------
# Step 1: Self-install torch if needed
# ---------------------------------------------------------------------------

def _bootstrap_pip() -> None:
    if subprocess.run([sys.executable, "-m", "pip", "--version"],
                      capture_output=True).returncode == 0:
        return
    subprocess.run([sys.executable, "-m", "ensurepip", "--upgrade"], capture_output=True)


_bootstrap_pip()

try:
    import torch
except ImportError:
    if os.environ.get("_CRUNR_PIP_DONE"):
        print("[ERROR] torch still not importable after install")
        sys.exit(1)
    import shutil
    if shutil.which("nvidia-smi"):
        print("Installing PyTorch (CUDA build)…", flush=True)
        subprocess.run([sys.executable, "-m", "pip", "install", "torch",
                        "--quiet", "--disable-pip-version-check"], check=True)
    else:
        print("Installing PyTorch (CPU build)…", flush=True)
        subprocess.run([sys.executable, "-m", "pip", "install", "torch",
                        "--index-url", "https://download.pytorch.org/whl/cpu",
                        "--quiet", "--disable-pip-version-check"], check=True)
    sys.stdout.flush()
    os.execve(sys.executable, [sys.executable, "-u"] + sys.argv,
              {**os.environ, "_CRUNR_PIP_DONE": "1", "PYTHONUNBUFFERED": "1"})

# ---------------------------------------------------------------------------
# Imports (torch guaranteed available)
# ---------------------------------------------------------------------------

import json
import time

import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset

Path("outputs").mkdir(exist_ok=True)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

IMG_SIZE   = 32
CHANNELS   = 3
LATENT_DIM = 128
BATCH      = 256
EPOCHS     = 20 if device.type == "cuda" else 2
NUM_TRAIN  = 60_000
NUM_GEN    = 64       # images to generate after training
LR         = 1e-3
BETA       = 1.0      # KL weight (β-VAE)

print("=" * 54)
print("  crunr Demo — Variational Autoencoder (VAE)")
print("=" * 54)
print(f"  Device     : {device}")
if device.type == "cuda":
    props = torch.cuda.get_device_properties(0)
    print(f"  GPU        : {props.name}")
    print(f"  VRAM       : {props.total_memory / 1e9:.1f} GB")
print(f"  Images     : {NUM_TRAIN:,} × {IMG_SIZE}×{IMG_SIZE} RGB")
print(f"  Latent dim : {LATENT_DIM}")
print(f"  Epochs     : {EPOCHS}  |  Batch: {BATCH}")
print()

# ---------------------------------------------------------------------------
# Synthetic dataset: random colour-patch images
#   Each image is split into quadrants filled with different random colours.
#   Simple enough to generate fast; varied enough for the VAE to learn something.
# ---------------------------------------------------------------------------

print(f"Generating {NUM_TRAIN:,} synthetic images …")
t0 = time.time()
torch.manual_seed(42)

imgs = torch.zeros(NUM_TRAIN, CHANNELS, IMG_SIZE, IMG_SIZE)
H, W = IMG_SIZE // 2, IMG_SIZE // 2
for q, (r0, c0) in enumerate([(0, 0), (0, W), (H, 0), (H, W)]):
    colour = torch.rand(NUM_TRAIN, CHANNELS, 1, 1)
    imgs[:, :, r0:r0 + H, c0:c0 + W] = colour + 0.05 * torch.randn(NUM_TRAIN, CHANNELS, H, W)

imgs = imgs.clamp(0, 1)
print(f"  Done in {time.time() - t0:.1f}s")

pin = device.type == "cuda"
loader = DataLoader(TensorDataset(imgs), batch_size=BATCH, shuffle=True,
                    pin_memory=pin, num_workers=0)
n_batches = len(imgs) // BATCH
print(f"  {n_batches} batches/epoch\n")

# ---------------------------------------------------------------------------
# Model: convolutional VAE
#   Encoder: Conv2d blocks → (mu, log_var)
#   Decoder: ConvTranspose2d blocks → reconstructed image
#   Same Conv2d path as demo.py — proven fast on any CUDA GPU.
# ---------------------------------------------------------------------------


class Encoder(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(CHANNELS, 32,  4, stride=2, padding=1),  # 32→16
            nn.LeakyReLU(0.2),
            nn.Conv2d(32,       64,  4, stride=2, padding=1),  # 16→8
            nn.BatchNorm2d(64),
            nn.LeakyReLU(0.2),
            nn.Conv2d(64,       128, 4, stride=2, padding=1),  # 8→4
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2),
            nn.Flatten(),                                       # 128×4×4 = 2048
        )
        self.mu      = nn.Linear(2048, LATENT_DIM)
        self.log_var = nn.Linear(2048, LATENT_DIM)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        h = self.net(x)
        return self.mu(h), self.log_var(h)


class Decoder(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.fc  = nn.Linear(LATENT_DIM, 2048)
        self.net = nn.Sequential(
            nn.ConvTranspose2d(128, 64,  4, stride=2, padding=1),  # 4→8
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.ConvTranspose2d(64,  32,  4, stride=2, padding=1),  # 8→16
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.ConvTranspose2d(32,  CHANNELS, 4, stride=2, padding=1),  # 16→32
            nn.Sigmoid(),
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        h = self.fc(z).view(-1, 128, 4, 4)
        return self.net(h)


class VAE(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.encoder = Encoder()
        self.decoder = Decoder()

    def reparameterise(self, mu: torch.Tensor, log_var: torch.Tensor) -> torch.Tensor:
        if self.training:
            std = (0.5 * log_var).exp()
            return mu + std * torch.randn_like(std)
        return mu

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        mu, log_var = self.encoder(x)
        z           = self.reparameterise(mu, log_var)
        recon       = self.decoder(z)
        return recon, mu, log_var


def vae_loss(recon: torch.Tensor, x: torch.Tensor,
             mu: torch.Tensor, log_var: torch.Tensor) -> tuple[torch.Tensor, float, float]:
    recon_loss = F.mse_loss(recon, x, reduction="sum") / x.size(0)
    kl_loss    = -0.5 * (1 + log_var - mu.pow(2) - log_var.exp()).sum(1).mean()
    return recon_loss + BETA * kl_loss, recon_loss.item(), kl_loss.item()


model     = VAE().to(device)
n_params  = sum(p.numel() for p in model.parameters())
optimizer = torch.optim.Adam(model.parameters(), lr=LR)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)

print(f"Model params : {n_params:,}  (encoder + decoder)\n")

# ---------------------------------------------------------------------------
# Training loop
# ---------------------------------------------------------------------------

history   : list[dict] = []
job_start = time.time()

hdr = f"{'Ep':>3}  {'Loss':>9}  {'Recon':>9}  {'KL':>7}  {'VRAM':>7}  {'t':>6}"
print(hdr)
print("─" * len(hdr))

for epoch in range(1, EPOCHS + 1):
    t0 = time.time()
    model.train()
    tot_loss = tot_recon = tot_kl = 0.0
    n_seen   = 0

    for (xb,) in loader:
        xb              = xb.to(device)
        recon, mu, lv   = model(xb)
        loss, rl, kl    = vae_loss(recon, xb, mu, lv)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        b = xb.size(0)
        tot_loss  += loss.item()  * b
        tot_recon += rl           * b
        tot_kl    += kl           * b
        n_seen    += b

    scheduler.step()
    elapsed  = time.time() - t0
    avg_loss  = tot_loss  / n_seen
    avg_recon = tot_recon / n_seen
    avg_kl    = tot_kl    / n_seen
    vram_gb   = torch.cuda.memory_reserved(0) / 1e9 if device.type == "cuda" else 0.0

    history.append({
        "epoch": epoch, "loss": round(avg_loss, 4),
        "recon": round(avg_recon, 4), "kl": round(avg_kl, 4),
        "vram_gb": round(vram_gb, 2), "elapsed_s": round(elapsed, 2),
    })
    vstr = f"{vram_gb:.2f} GB" if device.type == "cuda" else "   n/a"
    print(f"{epoch:>3}  {avg_loss:>9.4f}  {avg_recon:>9.4f}  {avg_kl:>7.4f}"
          f"  {vstr:>7}  {elapsed:>5.1f}s", flush=True)

total_time = time.time() - job_start

# ---------------------------------------------------------------------------
# Generate samples from random latent vectors
# ---------------------------------------------------------------------------

model.eval()
with torch.no_grad():
    z        = torch.randn(NUM_GEN, LATENT_DIM, device=device)
    gen_imgs = model.decoder(z).cpu()

torch.save(gen_imgs, "outputs/generated.pt")
print(f"\nGenerated {NUM_GEN} images saved → outputs/generated.pt")
print(f"  Shape: {list(gen_imgs.shape)}  (N × C × H × W,  values 0–1)")

# ---------------------------------------------------------------------------
# Save outputs
# ---------------------------------------------------------------------------

torch.save(model.state_dict(), "outputs/model.pt")
Path("outputs/history.json").write_text(json.dumps(history, indent=2))

best = min(history, key=lambda r: r["loss"])
gpu_info = (
    f"{torch.cuda.get_device_name(0)} "
    f"({torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB)"
    if device.type == "cuda" else "CPU (no GPU)"
)
peak_vram = max(h["vram_gb"] for h in history)

summary = f"""crunr Demo — VAE Training Summary
==================================
Device       : {gpu_info}
PyTorch      : {torch.__version__}
Model params : {n_params:,}  (encoder + decoder)
Latent dim   : {LATENT_DIM}
Dataset      : {NUM_TRAIN:,} synthetic 32×32 RGB images
Epochs       : {EPOCHS}
Total time   : {total_time / 60:.1f} min  ({total_time:.0f}s)

Final loss   : {history[-1]['loss']:.4f}  (recon={history[-1]['recon']:.4f}  kl={history[-1]['kl']:.4f})
Best  loss   : {best['loss']:.4f}  (epoch {best['epoch']})
Peak VRAM    : {peak_vram:.2f} GB

Outputs
-------
  outputs/model.pt       VAE weights  ({n_params:,} params)
  outputs/generated.pt   {NUM_GEN} generated images  shape {list(gen_imgs.shape)}
  outputs/history.json   per-epoch  loss / recon / kl / vram
  outputs/summary.txt    this report
"""

Path("outputs/summary.txt").write_text(summary)
print()
print(summary)
print("Done. All outputs saved to outputs/")
