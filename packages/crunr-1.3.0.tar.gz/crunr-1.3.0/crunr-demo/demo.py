"""
crunr demo — ResNet-style CNN training on CPU or GPU.

Self-installs its own dependencies so no requirements.txt is needed.
CPU (t3.xlarge, 2 epochs): ~8 min, < $0.02
GPU (g4dn.xlarge, 12 epochs): ~5 min, < $0.02

Run:
    crunr run demo.py --instance t3.xlarge --s3-bucket crunr-gpu-outputs   # CPU
    crunr run demo.py --gpu --instance g4dn.xlarge --s3-bucket crunr-gpu-outputs  # GPU
"""

# ---------------------------------------------------------------------------
# Step 0: Re-exec with DL AMI Python if available (has torch pre-installed)
# Must run before any pip logic so sys.executable is correct from the start.
# ---------------------------------------------------------------------------

import os
import subprocess
import sys
from pathlib import Path


def _reexec_with_dl_python() -> None:
    """On a DL AMI, replace this process with the conda Python that has torch.

    AWS Deep Learning AMIs ship PyTorch pre-installed in a conda environment.
    The system Python (/usr/bin/python3) does NOT have torch, and downloading
    the CUDA wheel from PyPI (~5 GB) into the near-full DL AMI disk fails.
    os.execve replaces the current process so sys.executable is correct throughout.
    """
    if os.environ.get("_CRUNR_REEXEC"):
        return  # guard against infinite re-exec

    for py_path in [
        "/opt/conda/envs/pytorch/bin/python3",
        "/opt/conda/envs/pytorch_p310/bin/python3",
        "/opt/conda/envs/pytorch_p39/bin/python3",
        "/opt/conda/bin/python3",
        "/home/ec2-user/anaconda3/envs/pytorch/bin/python3",
        "/home/ec2-user/miniconda3/envs/pytorch/bin/python3",
        "/opt/amazon/openmpi/bin/python3",
    ]:
        if not Path(py_path).exists() or py_path == sys.executable:
            continue
        try:
            r = subprocess.run([py_path, "-c", "import torch"],
                               capture_output=True, timeout=15)
            if r.returncode == 0:
                print(f"DL AMI detected — re-exec with {py_path} (torch pre-installed)")
                sys.stdout.flush()
                os.execve(py_path, [py_path] + sys.argv,
                          {**os.environ, "_CRUNR_REEXEC": "1"})
        except Exception:
            continue


_reexec_with_dl_python()


# ---------------------------------------------------------------------------
# Self-install dependencies (fallback for non-DL-AMI instances)
# ---------------------------------------------------------------------------


def _bootstrap_pip() -> None:
    """Ensure pip exists — Amazon Linux 2023 ships without it."""
    if subprocess.run([sys.executable, "-m", "pip", "--version"],
                      capture_output=True).returncode == 0:
        return  # already available

    print("pip not found — bootstrapping...")

    # Try ensurepip (Python stdlib, works on most distros)
    if subprocess.run([sys.executable, "-m", "ensurepip", "--upgrade"],
                      capture_output=True).returncode == 0:
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade",
                        "pip", "--quiet"], capture_output=True)
        print("pip bootstrapped via ensurepip.")
        return

    # Fallback: download get-pip.py
    print("Downloading get-pip.py ...")
    import urllib.request
    urllib.request.urlretrieve(
        "https://bootstrap.pypa.io/get-pip.py", "/tmp/get-pip.py"
    )
    subprocess.run([sys.executable, "/tmp/get-pip.py", "--quiet"], check=True)
    print("pip bootstrapped via get-pip.py.")


def _install(package, index_url=None) -> None:
    cmd = [sys.executable, "-m", "pip", "install", package, "--quiet",
           "--disable-pip-version-check"]
    if index_url:
        cmd += ["--index-url", index_url]
    subprocess.run(cmd, check=True)


def _has_nvidia() -> bool:
    """Detect GPU before torch is imported — check for nvidia-smi."""
    import shutil
    return shutil.which("nvidia-smi") is not None


_bootstrap_pip()

try:
    import torch
except ImportError:
    if os.environ.get("_CRUNR_PIP_DONE"):
        # Already installed and re-exec'd — still not importable; bail with diagnostics.
        import site
        print(f"[ERROR] torch installed but not importable from {sys.executable}")
        print(f"  user site : {site.getusersitepackages()}")
        print(f"  sys.path  : {sys.path}")
        sys.exit(1)

    if _has_nvidia():
        print("Installing PyTorch (CUDA build) ...")
        _install("torch")  # PyPI default includes CUDA
    else:
        print("Installing PyTorch (CPU build, ~200 MB) ...")
        # CPU-only wheel is ~3x smaller — installs much faster on CPU instances
        _install("torch", index_url="https://download.pytorch.org/whl/cpu")
    print("PyTorch installed.")

    # Re-exec with a fresh interpreter so the newly installed site-packages
    # are picked up — pip installs to user site-packages after Python has
    # already cached its import paths, so a new process is required.
    # -u forces unbuffered stdout/stderr so training progress streams live.
    sys.stdout.flush()
    os.execve(sys.executable, [sys.executable, "-u"] + sys.argv,
              {**os.environ, "_CRUNR_PIP_DONE": "1", "PYTHONUNBUFFERED": "1"})

# ---------------------------------------------------------------------------
# Imports (after torch is guaranteed available)
# ---------------------------------------------------------------------------

import json
import time
from pathlib import Path

import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

Path("outputs").mkdir(exist_ok=True)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Fewer epochs on CPU to keep runtime ~8 min; bump to 12 for GPU
EPOCHS     = 2   if device.type == "cpu"  else 12
NUM_TRAIN  = 50_000
NUM_TEST   =  5_000
IMG_SIZE   = 32
CLASSES    = 10
BATCH      = 128 if device.type == "cpu"  else 256

print("=" * 52)
print("  crunr Demo — ResNet-style CNN Training")
print("=" * 52)
print(f"  Device  : {device}")
if device.type == "cuda":
    props = torch.cuda.get_device_properties(0)
    print(f"  GPU     : {props.name}")
    print(f"  VRAM    : {props.total_memory / 1e9:.1f} GB")
print(f"  PyTorch : {torch.__version__}")
print(f"  Epochs  : {EPOCHS}")
print(f"  Batch   : {BATCH}")
print()

# ---------------------------------------------------------------------------
# Synthetic dataset (32×32 RGB, 10 classes)
# ---------------------------------------------------------------------------

print(f"Generating dataset ({NUM_TRAIN:,} train / {NUM_TEST:,} test) ...")
torch.manual_seed(42)

X_train = torch.randn(NUM_TRAIN, 3, IMG_SIZE, IMG_SIZE)
y_train = torch.randint(0, CLASSES, (NUM_TRAIN,))
X_test  = torch.randn(NUM_TEST,  3, IMG_SIZE, IMG_SIZE)
y_test  = torch.randint(0, CLASSES, (NUM_TEST,))

pin = device.type == "cuda"
train_loader = DataLoader(TensorDataset(X_train, y_train), batch_size=BATCH, shuffle=True,  pin_memory=pin)
test_loader  = DataLoader(TensorDataset(X_test,  y_test),  batch_size=BATCH, shuffle=False, pin_memory=pin)
print(f"Batches : {len(train_loader)} train / {len(test_loader)} test\n")

# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------

class ResBlock(nn.Module):
    def __init__(self, ch: int) -> None:
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv2d(ch, ch, 3, padding=1, bias=False), nn.BatchNorm2d(ch), nn.ReLU(inplace=True),
            nn.Conv2d(ch, ch, 3, padding=1, bias=False), nn.BatchNorm2d(ch),
        )
        self.act = nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.act(self.body(x) + x)


model = nn.Sequential(
    nn.Conv2d(3,  64,  3, padding=1, bias=False), nn.BatchNorm2d(64),  nn.ReLU(inplace=True),
    ResBlock(64),
    nn.Conv2d(64,  128, 3, stride=2, padding=1, bias=False), nn.BatchNorm2d(128), nn.ReLU(inplace=True),
    ResBlock(128),
    nn.Conv2d(128, 256, 3, stride=2, padding=1, bias=False), nn.BatchNorm2d(256), nn.ReLU(inplace=True),
    ResBlock(256),
    nn.AdaptiveAvgPool2d(1), nn.Flatten(),
    nn.Linear(256, CLASSES),
).to(device)

total_params = sum(p.numel() for p in model.parameters())
print(f"Model params : {total_params:,}")

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=1e-3)
scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)

# ---------------------------------------------------------------------------
# Training loop
# ---------------------------------------------------------------------------

history = []
job_start = time.time()

header = f"{'Epoch':>5}  {'Loss':>8}  {'Train':>7}  {'Val':>7}  {'Time':>6}"
print(header)
print("─" * len(header))

for epoch in range(1, EPOCHS + 1):
    t0 = time.time()

    model.train()
    total_loss = correct = seen = 0
    for xb, yb in train_loader:
        xb, yb = xb.to(device), yb.to(device)
        optimizer.zero_grad(set_to_none=True)
        logits = model(xb)
        loss = criterion(logits, yb)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * len(xb)
        correct    += (logits.argmax(1) == yb).sum().item()
        seen       += len(xb)

    train_loss = total_loss / seen
    train_acc  = correct / seen

    model.eval()
    correct = seen = 0
    with torch.no_grad():
        for xb, yb in test_loader:
            xb, yb = xb.to(device), yb.to(device)
            correct += (model(xb).argmax(1) == yb).sum().item()
            seen    += len(xb)
    val_acc = correct / seen

    scheduler.step()
    epoch_time = time.time() - t0

    print(f"{epoch:>5}  {train_loss:>8.4f}  {train_acc:>6.1%}  {val_acc:>6.1%}  {epoch_time:>5.1f}s")
    history.append({
        "epoch": epoch, "train_loss": round(train_loss, 6),
        "train_acc": round(train_acc, 6), "val_acc": round(val_acc, 6),
        "elapsed_s": round(epoch_time, 2),
    })

total_time = time.time() - job_start

# ---------------------------------------------------------------------------
# Save outputs
# ---------------------------------------------------------------------------

torch.save(model.state_dict(), "outputs/model.pt")
Path("outputs/history.json").write_text(json.dumps(history, indent=2))

best = max(history, key=lambda r: r["val_acc"])
gpu_info = (
    f"{torch.cuda.get_device_name(0)} ({torch.cuda.get_device_properties(0).total_memory/1e9:.1f} GB)"
    if device.type == "cuda" else "CPU (no GPU)"
)
summary = f"""crunr Demo — Training Summary
==============================
Device       : {gpu_info}
PyTorch      : {torch.__version__}
Params       : {total_params:,}
Dataset      : {NUM_TRAIN:,} train / {NUM_TEST:,} test (synthetic 32x32 RGB)
Epochs       : {EPOCHS}
Total time   : {total_time/60:.1f} min ({total_time:.0f}s)

Best val acc : {best['val_acc']:.2%}  (epoch {best['epoch']})
Final val acc: {history[-1]['val_acc']:.2%}
Final loss   : {history[-1]['train_loss']:.4f}

Outputs
-------
  outputs/model.pt       model weights
  outputs/history.json   per-epoch metrics
  outputs/summary.txt    this report
"""

Path("outputs/summary.txt").write_text(summary)

print()
print(summary)
print("Done. All outputs saved to outputs/")
