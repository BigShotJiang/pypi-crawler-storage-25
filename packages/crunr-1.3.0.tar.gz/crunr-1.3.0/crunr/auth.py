"""AWS credential management: interactive wizard, list, verify, set-default."""

from __future__ import annotations

import configparser
import stat
import sys
from pathlib import Path
from typing import Optional

import boto3
import botocore.exceptions

from . import console
from .config import REGIONS

# ---------------------------------------------------------------------------
# File paths
# ---------------------------------------------------------------------------

AWS_DIR = Path.home() / ".aws"
CREDS_FILE = AWS_DIR / "credentials"
CONFIG_FILE = AWS_DIR / "config"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def cmd_auth(profile_name: str = "default") -> None:
    """Interactive wizard to add/update an AWS profile."""
    console.header(
        "crunr auth",
        f"Configure AWS credentials → profile: [bold]{profile_name}[/bold]",
    )

    console.step("Enter your AWS credentials")
    console.info("  Find these at: AWS Console → IAM → Users → Security credentials")

    key_id = console.prompt("AWS Access Key ID")
    if not key_id:
        console.error("Access Key ID cannot be empty.")
        sys.exit(1)

    secret = console.prompt_secret("AWS Secret Access Key")
    if not secret:
        console.error("Secret Access Key cannot be empty.")
        sys.exit(1)

    region = console.choose("Select a region", REGIONS)

    _ensure_aws_dir()
    _write_credentials(profile_name, key_id, secret)
    _write_config(profile_name, region)

    console.ok(f"Credentials written to {CREDS_FILE}")

    with console.spinner("Verifying credentials with AWS STS…"):
        ok, identity, err = _verify(profile_name)

    if ok:
        console.ok(f"Authenticated as: [bold]{identity}[/bold]")
        if profile_name != "default":
            console.info(f"  Use with: crunr run script.py --profile {profile_name}")
    else:
        console.error(f"Credential verification failed: {err}")
        console.warn("Credentials were saved but may be invalid. Double-check them with:")
        console.info(f"  crunr auth --verify {profile_name}")
        sys.exit(1)


def cmd_list_profiles() -> None:
    """Print a table of all configured profiles."""
    profiles = _read_all_profiles()
    default = _read_default_profile_name()
    for p in profiles:
        p["is_default"] = (p["name"] == default)
    console.profiles_table(profiles)


def cmd_verify(profile_name: str) -> None:
    """Test that a profile's credentials still work."""
    with console.spinner(f"Verifying profile [bold]{profile_name}[/bold]…"):
        ok, identity, err = _verify(profile_name)
    if ok:
        console.ok(f"Profile [bold]{profile_name}[/bold] is valid — authenticated as [bold]{identity}[/bold]")
    else:
        console.error(f"Profile [bold]{profile_name}[/bold] failed: {err}")
        sys.exit(1)


def cmd_set_default(profile_name: str) -> None:
    """Copy an existing profile's settings into the [default] slot."""
    profiles = {p["name"]: p for p in _read_all_profiles()}
    if profile_name not in profiles:
        console.error(f"Profile '{profile_name}' not found. Run 'crunr auth --list' to see available profiles.")
        sys.exit(1)

    p = profiles[profile_name]
    _ensure_aws_dir()

    # Read key and secret from the existing profile entry
    creds = _read_configparser(CREDS_FILE)
    section = profile_name if profile_name != "default" else "default"
    if not creds.has_section(section):
        console.error(f"No credentials found for profile '{profile_name}'.")
        sys.exit(1)

    key_id = creds.get(section, "aws_access_key_id", fallback="")
    secret = creds.get(section, "aws_secret_access_key", fallback="")
    _write_credentials("default", key_id, secret)
    _write_config("default", p["region"])

    console.ok(f"Default profile now points to [bold]{profile_name}[/bold] ({p['region']})")


def get_boto3_session(profile: Optional[str] = None, region: Optional[str] = None) -> boto3.Session:
    """Return a boto3 Session using the given profile (or default).

    All credential/config errors are converted to clean console messages here
    so no raw tracebacks ever reach the user for auth-related failures.
    """
    try:
        session = boto3.Session(profile_name=profile, region_name=region)
        creds = session.get_credentials()
        if creds is None:
            console.error(
                "No AWS credentials found.\n"
                "  Run [bold]crunr auth[/bold] to configure your AWS access keys."
            )
            sys.exit(1)
        return session
    except botocore.exceptions.ProfileNotFound:
        if profile:
            console.error(
                f"AWS profile [bold]{profile}[/bold] not found.\n"
                "  Available profiles: crunr auth --list\n"
                "  Add a new profile:  crunr auth " + profile
            )
        else:
            console.error(
                "No AWS credentials found.\n"
                "  Run [bold]crunr auth[/bold] to set up your AWS access keys.\n"
                "  You'll need: AWS Access Key ID + Secret Access Key\n"
                "  Get them at: AWS Console → IAM → Users → Security credentials"
            )
        sys.exit(1)
    except botocore.exceptions.NoCredentialsError:
        console.error(
            "No AWS credentials found.\n"
            "  Run [bold]crunr auth[/bold] to set up your AWS access keys.\n"
            "  You'll need: AWS Access Key ID + Secret Access Key\n"
            "  Get them at: AWS Console → IAM → Users → Security credentials"
        )
        sys.exit(1)
    except botocore.exceptions.NoRegionError:
        console.error(
            "No AWS region configured.\n"
            "  Run [bold]crunr auth[/bold] to set your region, or pass [bold]--region REGION[/bold]."
        )
        sys.exit(1)
    except Exception as exc:  # noqa: BLE001
        console.error(f"Failed to load AWS credentials: {exc}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _ensure_aws_dir() -> None:
    AWS_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)


def _read_configparser(path: Path) -> configparser.ConfigParser:
    cp = configparser.ConfigParser()
    if path.exists():
        cp.read(path)
    return cp


def _write_credentials(profile_name: str, key_id: str, secret: str) -> None:
    cp = _read_configparser(CREDS_FILE)
    section = profile_name  # credentials file uses bare profile names
    if not cp.has_section(section):
        cp.add_section(section)
    cp.set(section, "aws_access_key_id", key_id)
    cp.set(section, "aws_secret_access_key", secret)

    with CREDS_FILE.open("w") as f:
        cp.write(f)

    _set_private(CREDS_FILE)


def _write_config(profile_name: str, region: str) -> None:
    cp = _read_configparser(CONFIG_FILE)
    # config file uses "profile <name>" for non-default profiles
    section = "default" if profile_name == "default" else f"profile {profile_name}"
    if not cp.has_section(section):
        cp.add_section(section)
    cp.set(section, "region", region)
    cp.set(section, "output", "json")

    with CONFIG_FILE.open("w") as f:
        cp.write(f)

    _set_private(CONFIG_FILE)


def _set_private(path: Path) -> None:
    try:
        path.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    except OSError:
        pass  # Windows — best effort


def _verify(profile_name: str) -> tuple[bool, str, str]:
    try:
        session = boto3.Session(profile_name=profile_name)
        sts = session.client("sts")
        identity = sts.get_caller_identity()
        arn = identity.get("Arn", "unknown")
        return True, arn, ""
    except botocore.exceptions.ProfileNotFound as e:
        return False, "", str(e)
    except botocore.exceptions.ClientError as e:
        return False, "", str(e)
    except botocore.exceptions.NoCredentialsError as e:
        return False, "", str(e)
    except Exception as e:  # noqa: BLE001
        return False, "", str(e)


def _read_all_profiles() -> list[dict]:  # type: ignore[type-arg]
    cp_creds = _read_configparser(CREDS_FILE)
    cp_conf = _read_configparser(CONFIG_FILE)

    profiles = []
    for section in cp_creds.sections():
        key_id = cp_creds.get(section, "aws_access_key_id", fallback="")
        # Mask key for display
        masked = key_id[:4] + "****" + key_id[-4:] if len(key_id) >= 8 else "****"

        # Find region from config file
        conf_section = "default" if section == "default" else f"profile {section}"
        region = cp_conf.get(conf_section, "region", fallback="us-east-1")

        profiles.append({"name": section, "region": region, "key_id": masked})

    return profiles


def _read_default_profile_name() -> str:
    """Returns the name of the current default profile (always 'default')."""
    return "default"
