"""S3 operations: bucket setup, EC2-side upload script, download, list, delete."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Optional

import botocore.exceptions

from . import console

# Multipart upload threshold: files larger than this use concurrent parts.
_MULTIPART_THRESHOLD = 64 * 1024 * 1024  # 64 MB
_MULTIPART_CHUNK = 64 * 1024 * 1024

# S3 SSE algorithm applied to every object crunr writes
_SSE = "AES256"


# ---------------------------------------------------------------------------
# Bucket lifecycle
# ---------------------------------------------------------------------------

def ensure_bucket(s3: Any, bucket: str, region: str) -> None:
    """Create bucket if absent, apply security hardening. Idempotent."""
    if _bucket_exists(s3, bucket):
        console.info(f"  Using existing bucket s3://{bucket}")
        _assert_bucket_in_region(s3, bucket, region)
        return

    _create_bucket(s3, bucket, region)
    _harden_bucket(s3, bucket)
    console.ok(f"Created bucket s3://{bucket} ({region})")


def _bucket_exists(s3: Any, bucket: str) -> bool:
    try:
        s3.head_bucket(Bucket=bucket)
        return True
    except botocore.exceptions.ClientError as e:
        code = e.response["Error"]["Code"]  # type: ignore[index]
        if code in ("404", "NoSuchBucket"):
            return False
        if code == "403":
            # Bucket exists but owned by someone else
            raise PermissionError(
                f"Bucket s3://{bucket} exists but access is denied. "
                "Choose a different name or use a bucket you own."
            ) from e
        raise


def _assert_bucket_in_region(s3: Any, bucket: str, region: str) -> None:
    try:
        resp = s3.get_bucket_location(Bucket=bucket)
        loc = resp.get("LocationConstraint") or "us-east-1"
        if loc != region:
            console.warn(
                f"Bucket s3://{bucket} is in {loc}, not {region}. "
                "Data transfer costs may apply. Use --region {loc} to match."
            )
    except botocore.exceptions.ClientError:
        pass


def _create_bucket(s3: Any, bucket: str, region: str) -> None:
    kwargs: dict[str, Any] = {"Bucket": bucket}
    # us-east-1 is the default; passing CreateBucketConfiguration for it raises an error
    if region != "us-east-1":
        kwargs["CreateBucketConfiguration"] = {"LocationConstraint": region}
    try:
        s3.create_bucket(**kwargs)
    except botocore.exceptions.ClientError as e:
        code = e.response["Error"]["Code"]  # type: ignore[index]
        if code == "BucketAlreadyOwnedByYou":
            return  # race condition — someone else in the account just created it
        raise


def _harden_bucket(s3: Any, bucket: str) -> None:
    """Apply security best practices to a freshly-created bucket."""
    # 1. Block all public access
    s3.put_public_access_block(
        Bucket=bucket,
        PublicAccessBlockConfiguration={
            "BlockPublicAcls": True,
            "IgnorePublicAcls": True,
            "BlockPublicPolicy": True,
            "RestrictPublicBuckets": True,
        },
    )

    # 2. Enforce TLS-only access via bucket policy
    tls_policy = json.dumps({
        "Version": "2012-10-17",
        "Statement": [{
            "Sid": "DenyNonTLS",
            "Effect": "Deny",
            "Principal": "*",
            "Action": "s3:*",
            "Resource": [f"arn:aws:s3:::{bucket}", f"arn:aws:s3:::{bucket}/*"],
            "Condition": {"Bool": {"aws:SecureTransport": "false"}},
        }],
    })
    s3.put_bucket_policy(Bucket=bucket, Policy=tls_policy)

    # 3. Default SSE-S3 encryption for all objects
    s3.put_bucket_encryption(
        Bucket=bucket,
        ServerSideEncryptionConfiguration={
            "Rules": [{
                "ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"},
                "BucketKeyEnabled": True,
            }]
        },
    )

    # 4. Ownership: bucket owner enforced (disables ACLs)
    try:
        s3.put_bucket_ownership_controls(
            Bucket=bucket,
            OwnershipControls={"Rules": [{"ObjectOwnership": "BucketOwnerEnforced"}]},
        )
    except botocore.exceptions.ClientError:
        pass  # not available in all regions/older SDK versions

    # 5. Intelligent-Tiering lifecycle: move objects to IA after 90 days
    s3.put_bucket_lifecycle_configuration(
        Bucket=bucket,
        LifecycleConfiguration={
            "Rules": [{
                "ID": "crunr-ia-transition",
                "Status": "Enabled",
                "Filter": {"Prefix": "crunr-jobs/"},
                "Transitions": [{
                    "Days": 90,
                    "StorageClass": "STANDARD_IA",
                }],
            }]
        },
    )


def set_ttl(s3: Any, bucket: str, prefix: str, ttl_days: int) -> None:
    """Add (or update) an expiration rule for objects under prefix/."""
    # Fetch current lifecycle config to preserve the IA-transition rule
    try:
        resp = s3.get_bucket_lifecycle_configuration(Bucket=bucket)
        rules: list[dict[str, Any]] = resp.get("Rules", [])
    except botocore.exceptions.ClientError as e:
        if e.response["Error"]["Code"] == "NoSuchLifecycleConfiguration":  # type: ignore[index]
            rules = []
        else:
            raise

    rule_id = f"crunr-ttl-{prefix.replace('/', '-')}"
    rules = [r for r in rules if r.get("ID") != rule_id]
    rules.append({
        "ID": rule_id,
        "Status": "Enabled",
        "Filter": {"Prefix": f"{prefix}/"},
        "Expiration": {"Days": ttl_days},
    })
    s3.put_bucket_lifecycle_configuration(
        Bucket=bucket,
        LifecycleConfiguration={"Rules": rules},
    )


# ---------------------------------------------------------------------------
# EC2-side upload script (runs on the instance via SSH)
# ---------------------------------------------------------------------------

def build_ec2_upload_script(
    remote_dir: str,
    job_id: str,
    log_file: str,
    bucket: str,
    prefix: str,
    region: str,
) -> str:
    """Return a bash script that uploads outputs/ + stdout.log to S3 from the EC2 instance."""
    s3_job_root = f"s3://{bucket}/{prefix}/{job_id}"
    s3_outputs = f"{s3_job_root}/outputs"
    s3_log = f"{s3_job_root}/stdout.log"

    # ~ inside double-quoted bash strings does not expand; use $HOME instead
    bash_remote_dir = remote_dir.replace("~", "$HOME")

    return f"""#!/bin/bash
set -euo pipefail

# Verify aws CLI is available (it ships with Amazon Linux 2023 and DL AMIs)
if ! command -v aws &>/dev/null; then
    echo "ERROR: aws CLI not found on this instance. S3 backup skipped." >&2
    exit 1
fi

# Retry wrapper: exponential back-off, up to 3 attempts
_crunr_retry() {{
    local n=1 max=3 delay=2
    while true; do
        "$@" && return 0
        [ $n -lt $max ] || {{ echo "S3 upload failed after $max attempts." >&2; return 1; }}
        echo "Attempt $n failed. Retrying in ${{delay}}s..." >&2
        sleep "$delay"; n=$((n+1)); delay=$((delay*2))
    done
}}

S3_JOB_ROOT="{s3_job_root}"
echo "→ S3 backup: ${{S3_JOB_ROOT}}/"

# Upload outputs/ directory (skip if empty or missing)
if [ -d "{bash_remote_dir}/outputs" ] && [ "$(ls -A "{bash_remote_dir}/outputs" 2>/dev/null)" ]; then
    echo "  uploading outputs/ ..."
    _crunr_retry aws s3 sync \
        "{bash_remote_dir}/outputs/" \
        "{s3_outputs}/" \
        --region "{region}" \
        --sse "{_SSE}" \
        --no-progress \
        --quiet
    echo "  ✓ outputs/ backed up"
else
    echo "  outputs/ is empty or missing — nothing to upload"
fi

# Upload stdout log
if [ -f "{log_file}" ]; then
    echo "  uploading stdout.log ..."
    _crunr_retry aws s3 cp \
        "{log_file}" \
        "{s3_log}" \
        --region "{region}" \
        --sse "{_SSE}" \
        --no-progress
    echo "  ✓ stdout.log backed up"
fi

echo "✓ S3 backup complete: ${{S3_JOB_ROOT}}/"
"""


# ---------------------------------------------------------------------------
# Client-side metadata upload
# ---------------------------------------------------------------------------

def upload_metadata(
    s3: Any,
    bucket: str,
    prefix: str,
    job_id: str,
    metadata: dict[str, Any],
) -> None:
    """Upload metadata.json to S3 from the client after the job completes."""
    key = f"{prefix}/{job_id}/metadata.json"
    body = json.dumps(metadata, indent=2, default=str).encode("utf-8")
    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=body,
        ContentType="application/json",
        ServerSideEncryption=_SSE,
    )


# ---------------------------------------------------------------------------
# List jobs
# ---------------------------------------------------------------------------

def list_jobs(s3: Any, bucket: str, prefix: str) -> list[dict[str, Any]]:
    """Return list of job dicts, sorted newest-first. Fetches metadata for each job."""
    job_ids = _list_job_ids(s3, bucket, prefix)
    jobs = []
    for job_id in job_ids:
        meta = _fetch_metadata(s3, bucket, prefix, job_id)
        size = _job_size_bytes(s3, bucket, prefix, job_id)
        jobs.append({
            "job_id": job_id,
            "metadata": meta,
            "size_bytes": size,
        })
    # Sort by started_at descending if available, else by key alphabetically
    jobs.sort(
        key=lambda j: j["metadata"].get("started_at", j["job_id"]),
        reverse=True,
    )
    return jobs


def _list_job_ids(s3: Any, bucket: str, prefix: str) -> list[str]:
    """Return job IDs (folder names under prefix/)."""
    paginator = s3.get_paginator("list_objects_v2")
    ids = []
    try:
        for page in paginator.paginate(Bucket=bucket, Prefix=f"{prefix}/", Delimiter="/"):
            for cp in page.get("CommonPrefixes", []):
                folder = cp["Prefix"]  # e.g. "crunr-jobs/abc123/"
                job_id = folder.rstrip("/").split("/")[-1]
                if job_id:
                    ids.append(job_id)
    except botocore.exceptions.ClientError as e:
        if e.response["Error"]["Code"] == "NoSuchBucket":  # type: ignore[index]
            return []
        raise
    return ids


def _fetch_metadata(s3: Any, bucket: str, prefix: str, job_id: str) -> dict[str, Any]:
    """Fetch and parse metadata.json. Returns empty dict if missing."""
    try:
        resp = s3.get_object(Bucket=bucket, Key=f"{prefix}/{job_id}/metadata.json")
        return json.loads(resp["Body"].read())
    except (botocore.exceptions.ClientError, json.JSONDecodeError, KeyError):
        return {}


def _job_size_bytes(s3: Any, bucket: str, prefix: str, job_id: str) -> int:
    """Return total bytes stored for a job under prefix/job_id/."""
    paginator = s3.get_paginator("list_objects_v2")
    total = 0
    try:
        for page in paginator.paginate(Bucket=bucket, Prefix=f"{prefix}/{job_id}/"):
            for obj in page.get("Contents", []):
                total += obj.get("Size", 0)
    except botocore.exceptions.ClientError:
        pass
    return total


# ---------------------------------------------------------------------------
# Download job artifacts
# ---------------------------------------------------------------------------

def download_job(
    s3: Any,
    bucket: str,
    prefix: str,
    job_id: str,
    dest_dir: Path,
    outputs_only: bool = False,
    include_log: bool = True,
) -> int:
    """Download all artifacts for a job to dest_dir. Returns number of files downloaded."""
    from boto3.s3.transfer import TransferConfig  # type: ignore[import-untyped]

    cfg = TransferConfig(
        multipart_threshold=_MULTIPART_THRESHOLD,
        multipart_chunksize=_MULTIPART_CHUNK,
        max_concurrency=8,
        use_threads=True,
    )

    # Determine which prefixes to fetch
    sub_prefixes = [f"{prefix}/{job_id}/outputs/"]
    if not outputs_only:
        if include_log:
            sub_prefixes.append(f"{prefix}/{job_id}/stdout.log")
        sub_prefixes.append(f"{prefix}/{job_id}/metadata.json")

    paginator = s3.get_paginator("list_objects_v2")
    keys: list[str] = []

    for sub in sub_prefixes:
        # If sub ends with '/' it's a prefix; otherwise treat as exact key
        if sub.endswith("/"):
            try:
                for page in paginator.paginate(Bucket=bucket, Prefix=sub):
                    for obj in page.get("Contents", []):
                        keys.append(obj["Key"])
            except botocore.exceptions.ClientError:
                pass
        else:
            keys.append(sub)

    if not keys:
        console.warn(f"No objects found in S3 for job {job_id}.")
        return 0

    dest_dir.mkdir(parents=True, exist_ok=True)
    downloaded = 0

    for key in keys:
        # Strip the "prefix/job_id/" portion to get the local relative path
        rel = key[len(f"{prefix}/{job_id}/"):]
        if not rel:
            continue
        local_path = dest_dir / rel
        local_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            with console.spinner(f"Downloading {rel} …"):
                s3.download_file(
                    Bucket=bucket,
                    Key=key,
                    Filename=str(local_path),
                    Config=cfg,
                )
            downloaded += 1
        except botocore.exceptions.ClientError as e:
            code = e.response["Error"]["Code"]  # type: ignore[index]
            if code in ("404", "NoSuchKey"):
                console.info(f"  {rel} not found in S3 — skipping.")
            else:
                console.warn(f"  Failed to download {rel}: {e}")

    return downloaded


# ---------------------------------------------------------------------------
# Delete job artifacts
# ---------------------------------------------------------------------------

def delete_job(s3: Any, bucket: str, prefix: str, job_id: str) -> int:
    """Delete all S3 objects for a job. Returns number of objects deleted."""
    paginator = s3.get_paginator("list_objects_v2")
    keys: list[str] = []

    try:
        for page in paginator.paginate(Bucket=bucket, Prefix=f"{prefix}/{job_id}/"):
            for obj in page.get("Contents", []):
                keys.append(obj["Key"])
    except botocore.exceptions.ClientError as e:
        if e.response["Error"]["Code"] == "NoSuchBucket":  # type: ignore[index]
            return 0
        raise

    if not keys:
        return 0

    # delete_objects accepts up to 1000 keys per call
    for i in range(0, len(keys), 1000):
        batch = keys[i : i + 1000]
        s3.delete_objects(
            Bucket=bucket,
            Delete={"Objects": [{"Key": k} for k in batch], "Quiet": True},
        )

    return len(keys)


# ---------------------------------------------------------------------------
# Presigned share links
# ---------------------------------------------------------------------------

def generate_share_links(
    s3: Any,
    bucket: str,
    prefix: str,
    job_id: str,
    ttl_seconds: int = 86400,
    outputs_only: bool = True,
) -> list[dict[str, Any]]:
    """Return presigned GET URLs for a job's files.

    Each entry: {filename, url, size_bytes}.
    filename is relative to prefix/job_id/ (e.g. "outputs/results.json").
    """
    scan_prefix = (
        f"{prefix}/{job_id}/outputs/" if outputs_only else f"{prefix}/{job_id}/"
    )
    strip_len = len(f"{prefix}/{job_id}/")

    paginator = s3.get_paginator("list_objects_v2")
    links: list[dict[str, Any]] = []

    try:
        for page in paginator.paginate(Bucket=bucket, Prefix=scan_prefix):
            for obj in page.get("Contents", []):
                key = obj["Key"]
                filename = key[strip_len:]
                if not filename:
                    continue
                url = s3.generate_presigned_url(
                    "get_object",
                    Params={"Bucket": bucket, "Key": key},
                    ExpiresIn=ttl_seconds,
                )
                links.append({
                    "filename": filename,
                    "url": url,
                    "size_bytes": obj.get("Size", 0),
                })
    except botocore.exceptions.ClientError as e:
        if e.response["Error"]["Code"] == "NoSuchBucket":  # type: ignore[index]
            raise FileNotFoundError(f"Bucket {bucket} not found.") from e
        raise

    return links


# ---------------------------------------------------------------------------
# Bucket stats
# ---------------------------------------------------------------------------

def get_bucket_stats(s3: Any, bucket: str, prefix: str) -> dict[str, Any]:
    """Return total object count and bytes under prefix/ in the bucket."""
    paginator = s3.get_paginator("list_objects_v2")
    count = 0
    total_bytes = 0

    try:
        for page in paginator.paginate(Bucket=bucket, Prefix=f"{prefix}/"):
            for obj in page.get("Contents", []):
                count += 1
                total_bytes += obj.get("Size", 0)
    except botocore.exceptions.ClientError as e:
        if e.response["Error"]["Code"] == "NoSuchBucket":  # type: ignore[index]
            return {"count": 0, "bytes": 0}
        raise

    # Approximate job count = number of unique job-id folders
    job_ids = _list_job_ids(s3, bucket, prefix)
    return {"count": len(job_ids), "bytes": total_bytes}
