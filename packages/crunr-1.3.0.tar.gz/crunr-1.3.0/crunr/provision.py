"""EC2 lifecycle: pricing, AMI, security group, key pair, launch, poll, terminate."""

from __future__ import annotations

import os
import stat
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Optional

import boto3
import botocore.exceptions

from . import console
from .config import (
    AL2023_AMI_FILTER,
    AMAZON_OWNER_ID,
    DL_AMI_OWNER_ID,
    CPU_CANDIDATES,
    DL_AMI_FILTERS,
    EBS_VOLUME_TYPE,
    GPU_CANDIDATES,
    INSTANCE_MAX_WAIT,
    INSTANCE_POLL_INTERVAL,
    KEY_FILE,
    KEY_NAME,
    MIN_DISK_GB_CPU,
    MIN_DISK_GB_GPU,
    SG_DESCRIPTION,
    SG_NAME,
    InstanceProfile,
)

_KEY_PATH = Path(KEY_FILE).expanduser()


# ---------------------------------------------------------------------------
# Spot price query & instance selection
# ---------------------------------------------------------------------------

def get_spot_price(ec2: Any, instance_type: str) -> float:
    """Return the most recent spot price for the given instance type ($/hr).
    Returns 0.0 if unavailable (caller should fall back to on-demand)."""
    try:
        resp = ec2.describe_spot_price_history(
            InstanceTypes=[instance_type],
            ProductDescriptions=["Linux/UNIX"],
            MaxResults=1,
        )
        history = resp.get("SpotPriceHistory", [])
        if history:
            return float(history[0]["SpotPrice"])
    except botocore.exceptions.ClientError:
        pass
    return 0.0


def get_ondemand_price(instance_type: str, region: str) -> float:
    """Return approximate on-demand price. Uses a small static table for common
    types; returns 0.0 if unknown so cost estimate shows as unknown."""
    _TABLE = {
        "t3.nano": 0.0052, "t3.micro": 0.0104, "t3.small": 0.0208,
        "t3.medium": 0.0416, "t3.large": 0.0832, "t3.xlarge": 0.1664,
        "t3.2xlarge": 0.3328, "c5.xlarge": 0.17, "c5.2xlarge": 0.34,
        "c5.4xlarge": 0.68, "c5.9xlarge": 1.53, "m5.xlarge": 0.192,
        "m5.2xlarge": 0.384, "m5.4xlarge": 0.768, "r5.xlarge": 0.252,
        "r5.2xlarge": 0.504, "r5.4xlarge": 1.008, "g4dn.xlarge": 0.526,
        "g4dn.2xlarge": 0.752, "g4dn.4xlarge": 1.204, "g4dn.8xlarge": 2.264,
        "g4dn.12xlarge": 3.912, "g5.xlarge": 1.006, "g5.2xlarge": 1.212,
        "g5.4xlarge": 1.624, "g5.12xlarge": 5.672, "g5.48xlarge": 16.288,
        "p3.2xlarge": 3.06, "p3.8xlarge": 12.24, "p3.16xlarge": 24.48,
        "p4d.24xlarge": 32.77, "p4de.24xlarge": 40.97,
    }
    return _TABLE.get(instance_type, 0.0)


def select_instance(
    ec2: Any,
    gpu: bool,
    min_memory_gb: Optional[float] = None,
    instance_type: Optional[str] = None,
    use_spot: bool = True,
) -> tuple[InstanceProfile, float, bool]:
    """Choose the cheapest matching instance.

    Returns (profile, price_per_hour, is_spot).
    Raises SystemExit if no suitable instance is available.
    """
    region = ec2.meta.region_name

    # Explicit instance type requested
    if instance_type:
        from .config import ALL_PROFILES
        profile = ALL_PROFILES.get(instance_type)
        if profile is None:
            # Unknown type — create a minimal profile so we can still proceed
            profile = InstanceProfile(
                instance_type=instance_type,
                vcpus=0, ram_gb=0.0, gpu=gpu,
                gpu_count=0, gpu_memory_gb=0.0,
            )
        price, is_spot = _resolve_price(ec2, profile.instance_type, region, use_spot)
        return profile, price, is_spot

    candidates = GPU_CANDIDATES if gpu else CPU_CANDIDATES

    if min_memory_gb:
        candidates = [
            c for c in candidates
            if (c.gpu_memory_gb * c.gpu_count >= min_memory_gb if gpu else c.ram_gb >= min_memory_gb)
        ]

    if not candidates:
        what = "GPU" if gpu else "CPU"
        console.error(
            f"No {what} instance satisfies --memory {min_memory_gb} GB. "
            "Try a lower value or specify --instance directly."
        )
        sys.exit(1)

    if not use_spot:
        # On-demand: just pick the smallest candidate
        profile = candidates[0]
        price = get_ondemand_price(profile.instance_type, region)
        return profile, price, False

    # Spot: fetch prices in parallel-ish (one call per type — cheapest overall)
    with console.spinner(f"Querying spot prices for {len(candidates)} instance types…"):
        priced: list[tuple[float, InstanceProfile]] = []
        for c in candidates:
            p = get_spot_price(ec2, c.instance_type)
            if p > 0:
                priced.append((p, c))

    if priced:
        priced.sort(key=lambda x: x[0])
        price, profile = priced[0]
        return profile, price, True

    # No spot capacity found — fall back to on-demand with smallest candidate
    console.warn("No spot capacity found. Falling back to on-demand pricing.")
    profile = candidates[0]
    price = get_ondemand_price(profile.instance_type, region)
    return profile, price, False


def _resolve_price(
    ec2: Any, instance_type: str, region: str, use_spot: bool
) -> tuple[float, bool]:
    if use_spot:
        p = get_spot_price(ec2, instance_type)
        if p > 0:
            return p, True
        console.warn(f"No spot price for {instance_type}. Falling back to on-demand.")
    return get_ondemand_price(instance_type, region), False


# ---------------------------------------------------------------------------
# AMI lookup
# ---------------------------------------------------------------------------

def get_ami(ec2: Any, gpu: bool) -> tuple[str, str]:
    """Return (ami_id, root_device_name). GPU → Deep Learning AMI; CPU → AL2023."""
    if gpu:
        # DL AMIs are published under a different AWS account than standard AL2 AMIs
        dl_owners = [DL_AMI_OWNER_ID, AMAZON_OWNER_ID]
        for filters in DL_AMI_FILTERS:
            result = _find_ami(ec2, [filters], owners=dl_owners)
            if result:
                return result
        console.warn("Deep Learning AMI not found; falling back to Amazon Linux 2023.")

    result = _find_ami(ec2, [AL2023_AMI_FILTER])
    if result:
        return result

    console.error(
        "Could not find a suitable AMI in this region. "
        "Check your region setting with 'crunr auth --list'."
    )
    sys.exit(1)


def _find_ami(
    ec2: Any,
    filters: list[dict[str, Any]],
    owners: Optional[list[str]] = None,
) -> Optional[tuple[str, str]]:
    """Return (ami_id, root_device_name) for the newest matching AMI, or None."""
    if owners is None:
        owners = [AMAZON_OWNER_ID]
    try:
        resp = ec2.describe_images(
            Owners=owners,
            Filters=filters,
        )
        images = resp.get("Images", [])
        if not images:
            return None
        images.sort(key=lambda x: x.get("CreationDate", ""), reverse=True)
        image = images[0]
        return image["ImageId"], image.get("RootDeviceName", "/dev/xvda")
    except botocore.exceptions.ClientError:
        return None


# ---------------------------------------------------------------------------
# Security group
# ---------------------------------------------------------------------------

def ensure_security_group(ec2: Any) -> str:
    """Create crunr-sg if it doesn't exist. Returns the SG ID."""
    try:
        resp = ec2.describe_security_groups(
            Filters=[{"Name": "group-name", "Values": [SG_NAME]}]
        )
        groups = resp.get("SecurityGroups", [])
        if groups:
            sg_id = groups[0]["GroupId"]
            console.info(f"  Using existing security group {SG_NAME} ({sg_id})")
            return sg_id
    except botocore.exceptions.ClientError as e:
        _reraise_fatal(e)

    # Create new SG
    try:
        resp = ec2.create_security_group(
            GroupName=SG_NAME,
            Description=SG_DESCRIPTION,
        )
        sg_id = resp["GroupId"]
        console.ok(f"Created security group {SG_NAME} ({sg_id})")
    except botocore.exceptions.ClientError as e:
        _fatal_api_error("create_security_group", e)

    # Authorize SSH inbound
    try:
        ec2.authorize_security_group_ingress(
            GroupId=sg_id,
            IpPermissions=[
                {
                    "IpProtocol": "tcp",
                    "FromPort": 22,
                    "ToPort": 22,
                    "IpRanges": [{"CidrIp": "0.0.0.0/0", "Description": "crunr SSH"}],
                }
            ],
        )
    except botocore.exceptions.ClientError as e:
        if "InvalidPermission.Duplicate" not in str(e):
            _fatal_api_error("authorize_security_group_ingress", e)

    return sg_id


# ---------------------------------------------------------------------------
# Key pair
# ---------------------------------------------------------------------------

def ensure_key_pair(ec2: Any) -> str:
    """Create crunr-key if it doesn't exist locally or if it's stale. Returns the key name."""
    pem_exists = _KEY_PATH.exists()
    fingerprint = _get_aws_fingerprint(ec2)
    aws_exists = fingerprint is not None

    if pem_exists and aws_exists:
        if _fingerprint_matches(_KEY_PATH, fingerprint):  # type: ignore[arg-type]
            console.info(f"  Using existing key pair {KEY_NAME}")
            _set_key_permissions(_KEY_PATH)
            return KEY_NAME
        # Local .pem doesn't match — AWS key was recreated without updating local file
        console.warn(
            f"Local key file doesn't match AWS key pair '{KEY_NAME}' — "
            "recreating a fresh matching pair."
        )
        try:
            _KEY_PATH.unlink()
        except OSError:
            pass
        try:
            ec2.delete_key_pair(KeyName=KEY_NAME)
        except botocore.exceptions.ClientError:
            pass

    elif aws_exists and not pem_exists:
        # AWS has the key but we lost the .pem — must recreate
        console.warn(
            f"Key pair '{KEY_NAME}' exists in AWS but local .pem is missing. "
            "Deleting old key pair and creating a fresh one."
        )
        try:
            ec2.delete_key_pair(KeyName=KEY_NAME)
        except botocore.exceptions.ClientError:
            pass

    # Create new key pair
    resp = ec2.create_key_pair(KeyName=KEY_NAME, KeyType="rsa", KeyFormat="pem")
    pem_material: str = resp["KeyMaterial"]

    _KEY_PATH.parent.mkdir(parents=True, exist_ok=True)
    _KEY_PATH.write_text(pem_material, encoding="utf-8")
    _set_key_permissions(_KEY_PATH)
    console.ok(f"Created key pair {KEY_NAME} → {_KEY_PATH}")
    return KEY_NAME


def _get_aws_fingerprint(ec2: Any) -> Optional[str]:
    """Return the fingerprint of the crunr-key pair from AWS, or None if it doesn't exist."""
    try:
        resp = ec2.describe_key_pairs(KeyNames=[KEY_NAME])
        pairs = resp.get("KeyPairs", [])
        return pairs[0].get("KeyFingerprint") if pairs else None
    except botocore.exceptions.ClientError:
        return None


def _fingerprint_matches(pem_path: Path, aws_fingerprint: str) -> bool:
    """Check if the local .pem key produces the same fingerprint AWS has stored.

    AWS stores MD5 fingerprints for RSA keys imported/created via the API.
    We reproduce the same fingerprint from the local private key using OpenSSL
    (which ships with the Windows OpenSSH client). Falls back to True on any
    error so a missing OpenSSL never blocks the user.
    """
    try:
        result = subprocess.run(
            ["ssh-keygen", "-l", "-E", "md5", "-f", str(pem_path)],
            capture_output=True,
            timeout=10,
        )
        if result.returncode != 0:
            return True  # can't verify — assume ok
        # Output: "2048 MD5:aa:bb:cc:... comment (RSA)"
        out = result.stdout.decode("utf-8", errors="replace")
        local_fp = ""
        for part in out.split():
            if part.startswith("MD5:"):
                local_fp = part[4:]   # strip "MD5:" prefix
                break
        if not local_fp:
            return True
        # AWS fingerprint format: "aa:bb:cc:..." (already without "MD5:")
        return local_fp == aws_fingerprint
    except Exception:  # noqa: BLE001
        return True  # ssh-keygen not available or timed out — don't block


def _set_key_permissions(path: Path) -> None:
    if sys.platform == "win32":
        # On Windows, ACL controls SSH key security — the read-only file attribute
        # is a separate concept and must NOT be set (it blocks the user from deleting
        # their own key file even with Full Control ACL).
        username = os.environ.get("USERNAME", "")
        if username:
            subprocess.run(
                [
                    "icacls", str(path),
                    "/inheritance:r",
                    "/grant:r", f"{username}:(F)",
                ],
                capture_output=True,
                check=False,
            )
    else:
        try:
            path.chmod(stat.S_IRUSR)  # 0o400 — owner read-only on Unix/macOS
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Launch
# ---------------------------------------------------------------------------

def launch_instance(
    ec2: Any,
    instance_type: str,
    ami_id: str,
    root_device: str,
    sg_id: str,
    key_name: str,
    spot: bool,
    env_vars: dict[str, str],
    disk_gb: int = 0,
    instance_profile_arn: Optional[str] = None,
) -> str:
    """Launch a spot or on-demand instance. Returns instance_id.

    disk_gb=0 means use the AMI default (no BlockDeviceMappings override).
    instance_profile_arn, when provided, gives the EC2 instance S3 write access
    via IAM role without passing any credentials into the instance.
    """
    user_data = _build_user_data(env_vars)

    common_params: dict[str, Any] = {
        "ImageId": ami_id,
        "InstanceType": instance_type,
        "MinCount": 1,
        "MaxCount": 1,
        "KeyName": key_name,
        "SecurityGroupIds": [sg_id],
        "UserData": user_data,
        # Terminate (not stop) when the OS or the instance itself calls shutdown.
        # This ensures self-termination via `aws ec2 terminate-instances` on the
        # instance side actually removes the instance and stops billing.
        "InstanceInitiatedShutdownBehavior": "terminate",
        "TagSpecifications": [
            {
                "ResourceType": "instance",
                "Tags": [
                    {"Key": "Name", "Value": "crunr-job"},
                    {"Key": "ManagedBy", "Value": "crunr"},
                ],
            }
        ],
    }

    if instance_profile_arn:
        common_params["IamInstanceProfile"] = {"Arn": instance_profile_arn}

    if disk_gb:
        common_params["BlockDeviceMappings"] = [
            {
                "DeviceName": root_device,
                "Ebs": {
                    "VolumeSize": disk_gb,
                    "VolumeType": EBS_VOLUME_TYPE,
                    "DeleteOnTermination": True,
                },
            }
        ]

    if spot:
        common_params["InstanceMarketOptions"] = {
            "MarketType": "spot",
            "SpotOptions": {"SpotInstanceType": "one-time"},
        }

    try:
        resp = ec2.run_instances(**common_params)
        instance_id = resp["Instances"][0]["InstanceId"]
        return instance_id
    except botocore.exceptions.ClientError as e:
        err_code = e.response["Error"]["Code"]  # type: ignore[index]
        err_msg = str(e)

        if spot and err_code in (
            "InsufficientInstanceCapacity",
            "SpotMaxPriceTooLow",
            "AuthFailure.ServiceLinkedRoleCreationNotPermitted",
        ):
            raise _SpotUnavailableError(err_msg) from e

        # GPU vCPU quota not approved
        if err_code == "VcpuLimitExceeded" or (
            err_code == "InstanceLimitExceeded" and "vCPU" in err_msg
        ):
            console.error(
                "GPU vCPU quota exceeded — your AWS account needs a limit increase.\n\n"
                "  How to fix (takes 5–30 minutes):\n"
                "  1. Go to: AWS Console → Service Quotas → AWS Services → Amazon EC2\n"
                "  2. Search: 'Running On-Demand G and VT instances'  → request 32 vCPUs\n"
                "  3. Search: 'Running Spot G and VT instances'        → request 32 vCPUs\n"
                "  4. For P-series (p3/p4): search 'Running On-Demand P instances' instead\n\n"
                "  After approval, re-run the same crunr command."
            )
            sys.exit(1)

        # Disk size smaller than AMI snapshot
        if err_code == "InvalidParameterValue" and "smaller than the snapshot" in err_msg:
            console.error(
                f"Disk size {disk_gb} GB is smaller than the AMI's minimum snapshot size.\n"
                "  The Deep Learning AMI requires at least 150 GB. Use: --disk 150"
            )
            sys.exit(1)

        _fatal_api_error("run_instances", e)


class _SpotUnavailableError(Exception):
    pass


def launch_with_fallback(
    ec2: Any,
    instance_type: str,
    ami_id: str,
    root_device: str,
    sg_id: str,
    key_name: str,
    spot: bool,
    env_vars: dict[str, str],
    disk_gb: int = 0,
    instance_profile_arn: Optional[str] = None,
) -> tuple[str, bool]:
    """Launch spot; if unavailable, fall back to on-demand. Returns (instance_id, is_spot)."""
    if spot:
        try:
            iid = launch_instance(
                ec2, instance_type, ami_id, root_device, sg_id, key_name,
                True, env_vars, disk_gb, instance_profile_arn,
            )
            return iid, True
        except _SpotUnavailableError as e:
            if "ServiceLinkedRole" in str(e):
                console.warn(
                    "Spot requires a one-time AWS service-linked role that your IAM user "
                    "can't create yet.\n"
                    "  Fix: add this permission to your IAM policy:\n"
                    '    { "Effect": "Allow", "Action": "iam:CreateServiceLinkedRole",\n'
                    '      "Resource": "arn:aws:iam::*:role/aws-service-role/spot.amazonaws.com/*" }\n'
                    "  Falling back to on-demand for this run."
                )
            else:
                console.warn("Spot capacity unavailable — launching on-demand instead.")

    iid = launch_instance(
        ec2, instance_type, ami_id, root_device, sg_id, key_name,
        False, env_vars, disk_gb, instance_profile_arn,
    )
    return iid, False


def _build_user_data(env_vars: dict[str, str]) -> str:
    """Cloud-init script to export env vars into every login shell."""
    if not env_vars:
        return ""
    lines = ["#!/bin/bash"]
    env_file = "/etc/profile.d/crunr-env.sh"
    lines.append(f"cat > {env_file} << 'CRUNR_EOF'")
    for k, v in env_vars.items():
        safe_v = v.replace("'", "'\\''")
        lines.append(f"export {k}='{safe_v}'")
    lines.append("CRUNR_EOF")
    lines.append(f"chmod 644 {env_file}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Poll until running
# ---------------------------------------------------------------------------

def wait_for_running(ec2: Any, instance_id: str) -> str:
    """Poll until the instance is in 'running' state. Returns public IP."""
    deadline = time.monotonic() + INSTANCE_MAX_WAIT
    with console.spinner(f"Waiting for instance {instance_id} to start…"):
        while True:
            try:
                resp = ec2.describe_instances(InstanceIds=[instance_id])
                reservations = resp.get("Reservations", [])
                if reservations:
                    inst = reservations[0]["Instances"][0]
                    state = inst["State"]["Name"]
                    if state == "running":
                        ip = inst.get("PublicIpAddress", "")
                        if ip:
                            return ip
                    elif state in ("shutting-down", "terminated", "stopping", "stopped"):
                        console.error(f"Instance entered unexpected state: {state}")
                        sys.exit(1)
            except botocore.exceptions.ClientError as e:
                # AWS eventual consistency: instance ID may not be visible
                # in DescribeInstances for a few seconds after run_instances.
                if e.response["Error"]["Code"] == "InvalidInstanceID.NotFound":  # type: ignore[index]
                    time.sleep(INSTANCE_POLL_INTERVAL)
                    continue
                _reraise_fatal(e)

            if time.monotonic() > deadline:
                console.error(
                    f"Instance {instance_id} did not start within {INSTANCE_MAX_WAIT}s. "
                    "Check the AWS console for capacity issues."
                )
                sys.exit(1)

            time.sleep(INSTANCE_POLL_INTERVAL)


# ---------------------------------------------------------------------------
# Terminate
# ---------------------------------------------------------------------------

def terminate_instance(ec2: Any, instance_id: str) -> None:
    """Terminate the instance. Safe to call even if already terminated."""
    try:
        ec2.terminate_instances(InstanceIds=[instance_id])
        console.ok(f"Instance {instance_id} terminated.")
    except botocore.exceptions.ClientError as e:
        err_code = e.response["Error"]["Code"]  # type: ignore[index]
        if err_code == "InvalidInstanceID.NotFound":
            return  # already gone
        console.warn(f"Warning: could not terminate {instance_id}: {e}")


# ---------------------------------------------------------------------------
# Error helpers
# ---------------------------------------------------------------------------

def _fatal_api_error(operation: str, exc: botocore.exceptions.ClientError) -> None:
    console.error(f"AWS API error during {operation}: {exc}")
    sys.exit(1)


def _reraise_fatal(exc: botocore.exceptions.ClientError) -> None:
    code = exc.response["Error"]["Code"]  # type: ignore[index]
    if code in ("AuthFailure", "UnauthorizedOperation", "InvalidClientTokenId"):
        console.error(
            f"AWS authentication error: {exc}\n"
            "  Check credentials with: crunr auth --verify"
        )
        sys.exit(1)
    raise exc
