"""SSH and rsync operations: wait for port, detect user, sync, run, collect."""

from __future__ import annotations

import base64
import fnmatch
import os
import shutil
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
from pathlib import Path
from typing import Optional

from . import console
from .config import (
    CANDIDATE_SSH_USERS,
    CLOUD_INIT_TIMEOUT,
    KEY_FILE,
    REMOTE_WORKSPACE,
    RSYNC_EXCLUDES,
    SSH_MAX_WAIT,
    SSH_POLL_INTERVAL,
    SSH_TIMEOUT,
)

_KEY_PATH = str(Path(KEY_FILE).expanduser())


# ---------------------------------------------------------------------------
# Tool availability check
# ---------------------------------------------------------------------------

def _has_rsync() -> bool:
    return shutil.which("rsync") is not None


def check_tools() -> None:
    if shutil.which("ssh") is None:
        console.error(
            "ssh not found on PATH.\n"
            "  On Windows: it ships with Windows 10/11 — search 'Optional Features' → 'OpenSSH Client'.\n"
            "  Or install Git for Windows: https://git-scm.com/download/win"
        )
        sys.exit(1)

    if not _has_rsync():
        console.warn(
            "rsync not found — using scp+tar fallback (slightly slower, no progress bar).\n"
            "  To get rsync on Windows:  choco install rsync\n"
            "  Or install Git for Windows with rsync component."
        )


# ---------------------------------------------------------------------------
# Interactive SSH shell
# ---------------------------------------------------------------------------

def open_ssh_shell(host: str, user: str) -> int:
    """Hand the current terminal to an interactive SSH session.

    stdin/stdout/stderr are inherited directly so the remote shell gets a
    proper PTY — colours, readline, vim, htop all work. Returns the SSH
    process exit code (0 = clean logout, 130 = Ctrl+C).
    """
    cmd = [
        "ssh",
        "-i", _KEY_PATH,
        "-o", "StrictHostKeyChecking=no",
        "-o", f"UserKnownHostsFile={os.devnull}",
        "-o", "LogLevel=ERROR",
        "-o", f"ConnectTimeout={SSH_TIMEOUT}",
        "-o", "ServerAliveInterval=30",
        "-o", "ServerAliveCountMax=3",
        f"{user}@{host}",
    ]
    try:
        return subprocess.run(cmd).returncode
    except KeyboardInterrupt:
        return 130


# ---------------------------------------------------------------------------
# SSH wait
# ---------------------------------------------------------------------------

def wait_for_ssh(host: str, timeout: int = SSH_MAX_WAIT) -> None:
    """Block until TCP port 22 accepts connections."""
    deadline = time.monotonic() + timeout
    with console.spinner(f"Waiting for SSH on {host}:22…"):
        while True:
            try:
                with socket.create_connection((host, 22), timeout=SSH_TIMEOUT):
                    return
            except (OSError, socket.timeout):
                pass

            if time.monotonic() > deadline:
                console.error(f"SSH port on {host} did not open within {timeout}s.")
                sys.exit(1)

            time.sleep(SSH_POLL_INTERVAL)


# ---------------------------------------------------------------------------
# SSH user detection
# ---------------------------------------------------------------------------

_USER_DETECT_TIMEOUT = 90   # seconds total to keep trying
_USER_DETECT_CONN    = 5    # seconds per individual SSH attempt
_USER_DETECT_PAUSE   = 5    # seconds between full-candidate sweeps


def detect_ssh_user(host: str) -> str:
    """Retry all candidate usernames until one connects or the deadline passes.

    The SSH port opens before cloud-init finishes writing authorized_keys, so
    the first few attempts will get "Permission denied" — that's normal and
    expected. We keep retrying until the key is accepted.
    """
    deadline = time.monotonic() + _USER_DETECT_TIMEOUT
    last_stderr = ""

    with console.spinner("Waiting for SSH authentication to become ready…"):
        while time.monotonic() < deadline:
            for user in CANDIDATE_SSH_USERS:
                rc, stderr = _try_ssh_user(host, user)
                if rc == 0:
                    console.info(f"  SSH user: {user}")
                    return user
                last_stderr = stderr or last_stderr

            time.sleep(_USER_DETECT_PAUSE)

    # Timed out — show the actual SSH error so the user knows what went wrong
    console.error(
        f"Could not authenticate after {_USER_DETECT_TIMEOUT}s "
        f"as any of: {', '.join(CANDIDATE_SSH_USERS)}"
    )
    if last_stderr:
        console.info(f"  Last SSH error: {last_stderr.strip()}")
    console.info(
        "  Common causes on Windows:\n"
        "  1. Key file permissions — fix with:  icacls %USERPROFILE%\\.crunr\\crunr-key.pem /inheritance:r /grant:r \"%USERNAME%:(R)\"\n"
        "  2. Instance still initializing — wait a minute and retry."
    )
    sys.exit(1)


def _try_ssh_user(host: str, user: str) -> tuple[int, str]:
    """Return (exit_code, stderr_text). Uses a short timeout suitable for polling."""
    cmd = [
        "ssh",
        "-i", _KEY_PATH,
        "-o", "StrictHostKeyChecking=no",
        "-o", f"UserKnownHostsFile={os.devnull}",
        "-o", "LogLevel=ERROR",
        "-o", f"ConnectTimeout={_USER_DETECT_CONN}",
        "-o", "BatchMode=yes",
        "-o", "PasswordAuthentication=no",
        f"{user}@{host}",
        "true",
    ]
    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            timeout=_USER_DETECT_CONN + 3,
        )
        stderr = result.stderr.decode("utf-8", errors="replace")
        return result.returncode, stderr
    except (subprocess.TimeoutExpired, OSError):
        return 1, ""


# ---------------------------------------------------------------------------
# Cloud-init
# ---------------------------------------------------------------------------

def wait_cloud_init(host: str, user: str) -> None:
    """Wait until cloud-init reports 'done' or timeout."""
    deadline = time.monotonic() + CLOUD_INIT_TIMEOUT
    with console.spinner("Waiting for cloud-init to complete…"):
        while True:
            out = _capture_ssh(host, user, "cloud-init status 2>/dev/null || echo done")
            if "done" in out or "status: done" in out:
                return
            if "error" in out:
                console.warn("cloud-init reported an error; proceeding anyway.")
                return

            if time.monotonic() > deadline:
                console.warn(f"cloud-init did not finish within {CLOUD_INIT_TIMEOUT}s; continuing.")
                return

            time.sleep(5)


# ---------------------------------------------------------------------------
# Upload: rsync (preferred) or scp+tar fallback
# ---------------------------------------------------------------------------

def rsync_up(
    host: str,
    user: str,
    local_dir: Path,
    remote_dir: str,
) -> None:
    """Upload local_dir to remote_dir. Uses rsync when available, scp+tar otherwise."""
    _exec_ssh(host, user, f"mkdir -p {remote_dir}")

    if _has_rsync():
        _rsync_up(host, user, local_dir, remote_dir)
    else:
        _scp_tar_up(host, user, local_dir, remote_dir)

    console.ok(f"Code synced → {remote_dir}/")


def _rsync_up(host: str, user: str, local_dir: Path, remote_dir: str) -> None:
    exclude_args: list[str] = []
    for exc in RSYNC_EXCLUDES:
        exclude_args += ["--exclude", exc]

    ssh_spec = f"ssh {_ssh_opts_str()}"
    cmd = [
        "rsync", "-az", "--info=progress2", "--no-inc-recursive",
        *exclude_args,
        "-e", ssh_spec,
        f"{local_dir}/",
        f"{user}@{host}:{remote_dir}/",
    ]
    with console.spinner(f"Uploading {local_dir.name}/ (rsync)…"):
        _run(cmd)


def _scp_tar_up(host: str, user: str, local_dir: Path, remote_dir: str) -> None:
    """Pack local_dir into a tar.gz with Python, scp it, extract on remote."""
    exclude_set = set(RSYNC_EXCLUDES)

    def _excluded(path: Path) -> bool:
        for pattern in exclude_set:
            if fnmatch.fnmatch(path.name, pattern):
                return True
        return False

    with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as tmp:
        tarball = tmp.name

    try:
        with console.spinner(f"Packing {local_dir.name}/…"):
            with tarfile.open(tarball, "w:gz") as tar:
                for item in local_dir.rglob("*"):
                    if _excluded(item):
                        continue
                    # Skip excluded parent directories
                    if any(_excluded(p) for p in item.parents if p != local_dir):
                        continue
                    arcname = item.relative_to(local_dir)
                    tar.add(item, arcname=str(arcname))

        tarball_mb = os.path.getsize(tarball) / 1_048_576
        if tarball_mb > 50:
            console.warn(
                f"Upload is {tarball_mb:.0f} MB — consider adding large files to .gitignore "
                "or moving datasets outside the project directory."
            )

        remote_tarball = f"/tmp/crunr-upload-{os.getpid()}.tar.gz"
        scp_cmd = [
            "scp",
            "-i", _KEY_PATH,
            "-o", "StrictHostKeyChecking=no",
            "-o", "UserKnownHostsFile=/dev/null",
            "-o", "LogLevel=ERROR",
            "-o", f"ConnectTimeout={SSH_TIMEOUT}",
            tarball,
            f"{user}@{host}:{remote_tarball}",
        ]

        with console.spinner(f"Uploading {local_dir.name}/ (scp+tar)…"):
            _run(scp_cmd)

        _exec_ssh(host, user, f"tar xzf {remote_tarball} -C {remote_dir} && rm -f {remote_tarball}")

    finally:
        try:
            os.unlink(tarball)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Install dependencies
# ---------------------------------------------------------------------------

def install_deps(host: str, user: str, remote_dir: str) -> None:
    """pip install -r requirements.txt if the file exists on the remote."""
    has_req = _capture_ssh(
        host, user, f"test -f {remote_dir}/requirements.txt && echo yes || echo no"
    ).strip()

    if has_req != "yes":
        console.info("  No requirements.txt found — skipping pip install.")
        return

    console.step("Installing dependencies from requirements.txt…")
    # Bootstrap pip if missing (Amazon Linux 2023 ships without it),
    # then install requirements. ensurepip is stdlib since Python 3.4.
    cmd = (
        "python3 -m ensurepip --upgrade 2>/dev/null || "
        "curl -sSL https://bootstrap.pypa.io/get-pip.py | python3 - --quiet 2>/dev/null || true; "
        f"cd {remote_dir} && "
        "python3 -m pip install --quiet --disable-pip-version-check -r requirements.txt 2>&1"
    )
    rc = _stream_ssh(host, user, cmd)
    if rc != 0:
        console.warn(
            f"pip install exited with code {rc}. "
            "Your job may fail if dependencies are missing."
        )
    else:
        console.ok("Dependencies installed.")


# ---------------------------------------------------------------------------
# Run job
# ---------------------------------------------------------------------------

def run_job(
    host: str,
    user: str,
    remote_dir: str,
    command: str,
    job_id: str,
    env_vars: dict[str, str],
    gpu: bool = False,
) -> int:
    """Execute command over SSH, stream output, return exit code."""
    exit_file = f"/tmp/crunr-{job_id}.exit"
    log_file = f"/tmp/crunr-{job_id}.log"

    # Always force unbuffered Python output so each print() line streams
    # to the terminal immediately instead of appearing all at once at the end.
    base_env = {"PYTHONUNBUFFERED": "1"}
    merged_env = {**base_env, **env_vars}
    env_prefix = " ".join(f"{k}={_shell_quote(v)}" for k, v in merged_env.items()) + " "

    # On DL AMIs the pytorch conda env has torch/CUDA pre-installed.
    # Prepend conda bin paths directly — avoids needing `conda activate` to
    # work in a non-interactive SSH session (where the shell function may not
    # be defined), so `python3` resolves to the conda Python without pip-installing
    # a 5+ GB wheel into a near-full disk.
    conda_init = ""
    if gpu:
        conda_init = (
            "export PATH="
            "/opt/conda/envs/pytorch/bin"
            ":/opt/conda/envs/pytorch_p310/bin"
            ":/opt/conda/envs/pytorch_p39/bin"
            ":/opt/conda/bin"
            ":$PATH 2>/dev/null; "
            "hash -r 2>/dev/null || true; "
        )

    # We wrap the command so:
    # 1. output is tee'd to a log file (for exit-code recovery after Ctrl+C)
    # 2. exit code is written to a sentinel file
    remote_cmd = (
        f"set -o pipefail; "
        f"{conda_init}"
        f"cd {remote_dir}; "
        f"{{ {env_prefix}{command}; }} 2>&1 | tee {log_file}; "
        f"echo ${{PIPESTATUS[0]}} > {exit_file}"
    )

    console.step(f"Running: {command}")
    console.info(f"  Workspace: {remote_dir}/")

    _stream_ssh(host, user, remote_cmd)

    # Read exit code from sentinel file
    return _read_exit_code(host, user, exit_file, log_file, job_id)


def _read_exit_code(
    host: str, user: str, exit_file: str, log_file: str, job_id: str
) -> int:
    raw = _capture_ssh(host, user, f"cat {exit_file} 2>/dev/null || echo -1").strip()
    try:
        return int(raw)
    except ValueError:
        return -1


# ---------------------------------------------------------------------------
# Autonomous wrapper: build, deploy, monitor
# ---------------------------------------------------------------------------

def build_wrapper_script(
    remote_dir: str,
    job_id: str,
    command: str,
    env_vars: dict[str, str],
    region: str,
    gpu: bool = False,
    s3_bucket: Optional[str] = None,
    s3_prefix: Optional[str] = None,
) -> str:
    """Return a self-contained bash script that runs the job, uploads to S3,
    and self-terminates the instance — all without any client connection.

    The script is injected into the instance via base64 (no quoting issues)
    and launched with nohup so it survives SSH disconnects.
    """
    log_file = f"/tmp/crunr-{job_id}.log"
    exit_file = f"/tmp/crunr-{job_id}.exit"
    done_file = f"/tmp/crunr-{job_id}.done"
    # ~ doesn't expand inside double-quoted strings in bash; use $HOME instead
    remote_dir_bash = remote_dir.replace("~", "$HOME")

    # Environment setup
    env_lines = ["export PYTHONUNBUFFERED=1"]
    for k, v in env_vars.items():
        safe_v = v.replace("'", "'\\''")
        env_lines.append(f"export {k}='{safe_v}'")
    env_block = "\n".join(env_lines)

    # Conda PATH for GPU (DL AMI variants)
    conda_block = ""
    if gpu:
        conda_block = (
            "export PATH=/opt/conda/envs/pytorch/bin"
            ":/opt/conda/envs/pytorch_p310/bin"
            ":/opt/conda/envs/pytorch_p39/bin"
            ":/opt/conda/bin:$PATH 2>/dev/null\n"
            "hash -r 2>/dev/null || true"
        )

    # S3 upload block — only emitted when S3 is configured
    s3_block = ""
    terminate_block = ""
    if s3_bucket and s3_prefix:
        s3_block = (
            "# ── S3 upload (3 retries) ────────────────────────────────────────\n"
            "S3_OK=0\n"
            f'if [ -d "{remote_dir_bash}/outputs" ]; then\n'
            "    for attempt in 1 2 3; do\n"
            f'        aws s3 sync "{remote_dir_bash}/outputs/" \\\n'
            f'            "s3://{s3_bucket}/{s3_prefix}/{job_id}/outputs/" \\\n'
            f'            --region "{region}" >> "{log_file}" 2>&1 \\\n'
            "        && S3_OK=1 && break\n"
            f'        echo "[crunr] S3 sync attempt $attempt failed, retrying..." >> "{log_file}"\n'
            "        sleep 5\n"
            "    done\n"
            "else\n"
            f'    echo "[crunr] No outputs/ directory — skipping S3 sync." >> "{log_file}"\n'
            "fi\n"
            f'aws s3 cp "{log_file}" \\\n'
            f'    "s3://{s3_bucket}/{s3_prefix}/{job_id}/stdout.log" \\\n'
            f'    --region "{region}" >> "{log_file}" 2>&1 || true\n'
            f'aws s3 cp "{exit_file}" \\\n'
            f'    "s3://{s3_bucket}/{s3_prefix}/{job_id}/exit_code.txt" \\\n'
            f'    --region "{region}" >> "{log_file}" 2>&1 || true\n'
            f'echo "[crunr] S3 upload done (ok=$S3_OK)." >> "{log_file}"'
        )
        # 60-second grace period lets the client finish rsync_down before the
        # instance disappears. In normal operation the client terminates via
        # boto3 first; the sleep only matters when the client is disconnected.
        terminate_block = (
            f'echo "[crunr] Waiting 60s grace period, then self-terminating..." >> "{log_file}"\n'
            "sleep 60\n"
            "TOKEN=$(curl -sXPUT 'http://169.254.169.254/latest/api/token' \\\n"
            "    -H 'X-aws-ec2-metadata-token-ttl-seconds: 21600' 2>/dev/null)\n"
            'INSTANCE_ID=$(curl -s \'http://169.254.169.254/latest/meta-data/instance-id\' \\\n'
            '    -H "X-aws-ec2-metadata-token: $TOKEN" 2>/dev/null)\n'
            f'aws ec2 terminate-instances \\\n'
            f'    --instance-ids "$INSTANCE_ID" \\\n'
            f'    --region "{region}" >> "{log_file}" 2>&1\n'
            f'echo "[crunr] Terminate command sent." >> "{log_file}"'
        )

    return (
        f"#!/bin/bash\n"
        f"# crunr autonomous job wrapper — {job_id}\n"
        f"# Runs job → S3 upload → self-terminate with no client connection needed.\n"
        f"set -o pipefail\n\n"
        f"# ── Environment ──────────────────────────────────────────────────────\n"
        f"{env_block}\n"
        f"{conda_block}\n\n"
        f"# ── Run job ──────────────────────────────────────────────────────────\n"
        f'echo "[crunr] Started: $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "{log_file}"\n'
        f'cd {remote_dir_bash}\n'
        f'{{ {command}; }} 2>&1 | tee -a "{log_file}"\n'
        f"JOB_EXIT=${{PIPESTATUS[0]}}\n"
        f'echo "$JOB_EXIT" > "{exit_file}"\n'
        f'echo "[crunr] Finished exit=$JOB_EXIT: $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "{log_file}"\n\n'
        f"{s3_block}\n\n"
        f"# ── Signal done (client polls this file to detect completion) ────────\n"
        f'echo "done" > "{done_file}"\n\n'
        f"{terminate_block}\n"
    )


def write_and_launch_wrapper(host: str, user: str, script: str, job_id: str) -> str:
    """Deliver the wrapper script to the instance and launch it fully detached.

    Two separate SSH calls are used intentionally:
    - Call 1 (write): blocking — we must know the script is on disk before launch.
    - Call 2 (launch): uses setsid to create a new process session, plus
      </dev/null >/dev/null 2>&1 to close all stdio FDs inherited from SSH.
      This lets SSH exit immediately — the wrapper keeps running in its own
      session with no connection to the SSH channel.

    If the launch command shared a && chain with the write (single SSH call),
    the backgrounded subshell would keep the SSH stdout pipe open until the
    wrapper finished, hanging _exec_ssh for the entire job duration.
    """
    wrapper_path = f"/tmp/crunr-{job_id}-wrapper.sh"
    pid_file = f"/tmp/crunr-{job_id}.pid"

    b64 = base64.b64encode(script.encode()).decode()

    # Step 1 — write the wrapper script (blocks until file is on disk)
    _exec_ssh(host, user,
        f"echo '{b64}' | base64 -d > {wrapper_path} && chmod +x {wrapper_path}"
    )

    # Step 2 — launch in a new session, all stdio closed.
    # setsid: new session → no controlling terminal → immune to SSH SIGHUP
    # </dev/null >/dev/null 2>&1: close stdin/stdout/stderr → SSH exits NOW
    # The & backgrounds only the setsid command; echo $! runs in foreground.
    _exec_ssh(host, user,
        f"setsid {wrapper_path} </dev/null >/dev/null 2>&1 & echo $! > {pid_file}"
    )

    pid = _capture_ssh(host, user, f"cat {pid_file} 2>/dev/null").strip()
    return pid or "?"


def tail_until_done(host: str, user: str, log_file: str, done_file: str) -> int:
    """Stream the job log until the done sentinel file appears on the instance.

    Uses a non-TTY SSH session so the wrapper process is NOT killed when the
    client disconnects (contrast with run_job's -t flag which sends SIGHUP).
    Returns the job exit code read from the exit sentinel file.
    """
    exit_file = log_file.replace(".log", ".exit")

    # Wait up to 30s for the log file to appear (wrapper may not have written
    # it yet if it's still setting up the environment).  Then tail from the
    # beginning so we don't miss lines written before we connected.
    # The while loop polls for the done file every 2 seconds; when it appears
    # (or the tail process dies because the instance terminated) we stop.
    remote_cmd = (
        f"for i in $(seq 1 30); do [ -f {log_file} ] && break; sleep 1; done; "
        f"tail -n +1 -f {log_file} & "
        f"TAIL_PID=$!; "
        f"while [ ! -f {done_file} ] && kill -0 $TAIL_PID 2>/dev/null; do sleep 2; done; "
        f"sleep 1; "
        f"kill $TAIL_PID 2>/dev/null; wait $TAIL_PID 2>/dev/null; true"
    )
    _stream_ssh_no_tty(host, user, remote_cmd)

    raw = _capture_ssh(host, user, f"cat {exit_file} 2>/dev/null || echo -1").strip()
    try:
        return int(raw)
    except ValueError:
        return -1


def _stream_ssh_no_tty(host: str, user: str, command: str) -> int:
    """Stream a remote command without allocating a pseudo-TTY (-t).

    Without -t, the remote process is NOT sent SIGHUP when the SSH connection
    drops — used for log tailing where we want the monitored process (the nohup
    wrapper) to keep running after the client disconnects.
    """
    cmd = _ssh_cmd(host, user) + [command]   # no -t
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=0,
        )
        assert proc.stdout is not None
        for raw_line in iter(proc.stdout.readline, b""):
            console.job_line(raw_line.decode("utf-8", errors="replace"))
        proc.wait()
        return proc.returncode
    except KeyboardInterrupt:
        try:
            proc.terminate()
        except Exception:  # noqa: BLE001
            pass
        raise


# ---------------------------------------------------------------------------
# Download outputs: rsync (preferred) or scp+tar fallback
# ---------------------------------------------------------------------------

def rsync_down(
    host: str,
    user: str,
    remote_dir: str,
    local_dir: Path,
) -> Optional[Path]:
    """Download outputs/ from remote → local. Returns local path or None."""
    has_out = _capture_ssh(
        host, user, f"test -d {remote_dir}/outputs && echo yes || echo no"
    ).strip()

    if has_out != "yes":
        console.info("  No outputs/ directory found — nothing to download.")
        return None

    dest = local_dir / "outputs"
    dest.mkdir(parents=True, exist_ok=True)

    if _has_rsync():
        _rsync_down(host, user, remote_dir, dest)
    else:
        _scp_tar_down(host, user, remote_dir, dest)

    console.ok(f"Outputs saved → {dest}/")
    return dest


def _rsync_down(host: str, user: str, remote_dir: str, dest: Path) -> None:
    ssh_spec = f"ssh {_ssh_opts_str()}"
    cmd = [
        "rsync", "-az", "--info=progress2",
        "-e", ssh_spec,
        f"{user}@{host}:{remote_dir}/outputs/",
        f"{dest}/",
    ]
    with console.spinner("Downloading outputs/ (rsync)…"):
        _run(cmd)


def _scp_tar_down(host: str, user: str, remote_dir: str, dest: Path) -> None:
    """Tar outputs/ on remote, scp it down, extract locally."""
    remote_tarball = f"/tmp/crunr-outputs-{os.getpid()}.tar.gz"
    _exec_ssh(host, user, f"tar czf {remote_tarball} -C {remote_dir}/outputs .")

    with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as tmp:
        local_tarball = tmp.name

    try:
        scp_cmd = [
            "scp",
            "-i", _KEY_PATH,
            "-o", "StrictHostKeyChecking=no",
            "-o", "UserKnownHostsFile=/dev/null",
            "-o", "LogLevel=ERROR",
            "-o", f"ConnectTimeout={SSH_TIMEOUT}",
            f"{user}@{host}:{remote_tarball}",
            local_tarball,
        ]
        with console.spinner("Downloading outputs/ (scp+tar)…"):
            _run(scp_cmd)

        with tarfile.open(local_tarball, "r:gz") as tar:
            tar.extractall(dest)

        _exec_ssh(host, user, f"rm -f {remote_tarball}")
    finally:
        try:
            os.unlink(local_tarball)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# S3 output upload (runs on the EC2 instance via SSH)
# ---------------------------------------------------------------------------

def upload_outputs_to_s3(
    host: str,
    user: str,
    remote_dir: str,
    job_id: str,
    bucket: str,
    prefix: str,
    region: str,
) -> bool:
    """Sync outputs/ and the stdout log from the EC2 instance to S3.

    Runs entirely on the EC2 side using the attached IAM instance profile —
    no user credentials are passed to the instance. Returns True on success.
    """
    from .s3 import build_ec2_upload_script  # local import to avoid circular

    log_file = f"/tmp/crunr-{job_id}.log"
    script = build_ec2_upload_script(
        remote_dir=remote_dir,
        job_id=job_id,
        log_file=log_file,
        bucket=bucket,
        prefix=prefix,
        region=region,
    )

    with console.spinner("Backing up outputs to S3…"):
        rc = _exec_ssh_rc(host, user, script)

    if rc == 0:
        s3_url = f"s3://{bucket}/{prefix}/{job_id}/"
        console.ok(f"S3 backup complete → {s3_url}")
        return True
    else:
        console.warn(
            "S3 backup failed (the EC2 instance could not write to S3). "
            "Your outputs may still download locally."
        )
        return False


def schedule_self_terminate(host: str, user: str, region: str, delay_s: int = 900) -> None:
    """Schedule the instance to terminate itself after *delay_s* seconds.

    Called after a successful S3 upload.  If the crunr client disconnects before
    it can call terminate_instance(), this background process fires as a fallback
    so the instance doesn't run (and bill) indefinitely.

    Uses IMDSv2 to retrieve the instance ID at execution time.  The script is
    delivered via base64 to avoid all shell-quoting issues in the SSH command.
    """
    script = "\n".join([
        "#!/bin/bash",
        f"sleep {delay_s}",
        "TOKEN=$(curl -sXPUT 'http://169.254.169.254/latest/api/token'"
        " -H 'X-aws-ec2-metadata-token-ttl-seconds: 21600' 2>/dev/null)",
        "INSTANCE_ID=$(curl -s 'http://169.254.169.254/latest/meta-data/instance-id'"
        " -H \"X-aws-ec2-metadata-token: $TOKEN\" 2>/dev/null)",
        f"aws ec2 terminate-instances --instance-ids \"$INSTANCE_ID\" --region {region}"
        " >> /tmp/crunr-selfterminate.log 2>&1",
    ]) + "\n"

    b64 = base64.b64encode(script.encode()).decode()
    cmd = (
        f"echo {b64} | base64 -d > /tmp/crunr-st.sh && "
        "chmod +x /tmp/crunr-st.sh && "
        "nohup /tmp/crunr-st.sh > /dev/null 2>&1 &"
    )
    try:
        _exec_ssh(host, user, cmd)
    except Exception:  # noqa: BLE001
        pass  # best-effort — the client's finally block still terminates normally


def _exec_ssh_rc(host: str, user: str, command: str) -> int:
    """Run a remote command and return its exit code (never raises)."""
    cmd = _ssh_cmd(host, user) + [command]
    try:
        result = subprocess.run(cmd, capture_output=True, timeout=600)
        if result.returncode != 0:
            err = result.stderr.decode("utf-8", errors="replace").strip()
            if err:
                console.info(f"  [dim]S3 upload stderr: {err[:400]}[/dim]")
        return result.returncode
    except (subprocess.TimeoutExpired, OSError) as exc:
        console.warn(f"S3 upload SSH call timed out or failed: {exc}")
        return 1


# ---------------------------------------------------------------------------
# SSH command builders
# ---------------------------------------------------------------------------

def _ssh_cmd(host: str, user: str) -> list[str]:
    return [
        "ssh",
        *_ssh_opts(),
        f"{user}@{host}",
    ]


def _ssh_opts() -> list[str]:
    return [
        "-i", _KEY_PATH,
        "-o", "StrictHostKeyChecking=no",
        "-o", f"UserKnownHostsFile={os.devnull}",   # "nul" on Windows, "/dev/null" on Unix
        "-o", "LogLevel=ERROR",
        "-o", f"ConnectTimeout={SSH_TIMEOUT}",
        "-o", "ServerAliveInterval=30",
        "-o", "ServerAliveCountMax=3",
        "-o", "BatchMode=yes",                       # never hang waiting for a password/passphrase
        "-o", "PasswordAuthentication=no",
    ]


def _ssh_opts_str() -> str:
    opts = _ssh_opts()
    # Join pairs for use in rsync -e "ssh ..."
    return " ".join(opts)


def _exec_ssh(host: str, user: str, command: str) -> None:
    """Run a remote command; raise on non-zero exit."""
    cmd = _ssh_cmd(host, user) + [command]
    result = subprocess.run(cmd, capture_output=True)
    if result.returncode != 0:
        err = result.stderr.decode("utf-8", errors="replace").strip()
        console.warn(f"SSH command failed (rc={result.returncode}): {err}")


def _capture_ssh(host: str, user: str, command: str) -> str:
    """Run a remote command and return stdout as a string."""
    cmd = _ssh_cmd(host, user) + [command]
    try:
        result = subprocess.run(cmd, capture_output=True, timeout=30)
        return result.stdout.decode("utf-8", errors="replace")
    except (subprocess.TimeoutExpired, OSError):
        return ""


def _stream_ssh(host: str, user: str, command: str) -> int:
    """Run a remote command, streaming stdout+stderr to the terminal. Returns exit code."""
    cmd = _ssh_cmd(host, user) + ["-t", command]
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=0,
        )
        assert proc.stdout is not None
        for raw_line in iter(proc.stdout.readline, b""):
            console.job_line(raw_line.decode("utf-8", errors="replace"))
        proc.wait()
        return proc.returncode
    except KeyboardInterrupt:
        # Ctrl+C — let the caller's finally block handle cleanup
        try:
            proc.terminate()
        except Exception:  # noqa: BLE001
            pass
        raise


def _run(cmd: list[str]) -> None:
    """Run a local subprocess; abort on error."""
    try:
        result = subprocess.run(cmd, capture_output=True)
        if result.returncode != 0:
            err = result.stderr.decode("utf-8", errors="replace").strip()
            console.error(f"Command failed (rc={result.returncode}): {err}")
            sys.exit(result.returncode)
    except FileNotFoundError as e:
        console.error(f"Command not found: {e}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Shell quoting (portable, minimal)
# ---------------------------------------------------------------------------

def _shell_quote(value: str) -> str:
    escaped = value.replace("'", "'\\''")
    return f"'{escaped}'"
