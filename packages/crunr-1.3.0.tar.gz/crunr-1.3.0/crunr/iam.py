"""IAM role + instance profile management so EC2 can write to S3 without user credentials."""

from __future__ import annotations

import json
import time
from typing import Any

import botocore.exceptions

from . import console

ROLE_NAME = "crunr-s3-writer"
INSTANCE_PROFILE_NAME = "crunr-instance-profile"

_TRUST_POLICY = json.dumps({
    "Version": "2012-10-17",
    "Statement": [{
        "Effect": "Allow",
        "Principal": {"Service": "ec2.amazonaws.com"},
        "Action": "sts:AssumeRole",
    }],
})

# How long to wait after creating a *new* instance profile before using it.
# IAM is eventually consistent; EC2 rejects the profile during this window.
_IAM_PROPAGATION_WAIT = 15  # seconds


def ensure_instance_profile(iam: Any, bucket: str, prefix: str) -> str:
    """Ensure the crunr IAM role + instance profile exist. Returns profile ARN."""
    _ensure_role(iam, bucket, prefix)
    return _ensure_profile(iam)


def _ensure_role(iam: Any, bucket: str, prefix: str) -> None:
    """Create or update the crunr-s3-writer IAM role with a least-privilege inline policy."""
    # Scope permissions tightly: write only within the crunr-jobs prefix of this bucket.
    # Also allow the instance to terminate itself (scoped to crunr-tagged instances)
    # so orphaned billing stops even if the client disconnects after S3 upload.
    inline_policy = json.dumps({
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "CrunrS3PutObject",
                "Effect": "Allow",
                "Action": ["s3:PutObject", "s3:GetObject", "s3:HeadObject"],
                "Resource": f"arn:aws:s3:::{bucket}/{prefix}/*",
            },
            {
                "Sid": "CrunrS3List",
                "Effect": "Allow",
                "Action": "s3:ListBucket",
                "Resource": f"arn:aws:s3:::{bucket}",
                "Condition": {
                    "StringLike": {"s3:prefix": [f"{prefix}/*"]},
                },
            },
            {
                "Sid": "CrunrSelfTerminate",
                "Effect": "Allow",
                "Action": "ec2:TerminateInstances",
                "Resource": "*",
                "Condition": {
                    "StringEquals": {"ec2:ResourceTag/ManagedBy": "crunr"},
                },
            },
        ],
    })

    # Create role if not exists
    try:
        iam.create_role(
            RoleName=ROLE_NAME,
            AssumeRolePolicyDocument=_TRUST_POLICY,
            Description="crunr: allows EC2 instances to write job outputs to S3",
            Tags=[{"Key": "ManagedBy", "Value": "crunr"}],
        )
        console.ok(f"Created IAM role {ROLE_NAME}")
    except (
        iam.exceptions.EntityAlreadyExistsException,
        botocore.exceptions.ClientError,
    ) as exc:
        if isinstance(exc, botocore.exceptions.ClientError):
            code = exc.response["Error"]["Code"]  # type: ignore[index]
            if code != "EntityAlreadyExists":
                raise
        console.info(f"  Using existing IAM role {ROLE_NAME}")

    # Always (re-)apply the inline policy — idempotent, keeps it current
    iam.put_role_policy(
        RoleName=ROLE_NAME,
        PolicyName="crunr-s3-access",
        PolicyDocument=inline_policy,
    )


def _ensure_profile(iam: Any) -> str:
    """Create instance profile and attach the role. Returns profile ARN."""
    just_created = False

    try:
        resp = iam.create_instance_profile(
            InstanceProfileName=INSTANCE_PROFILE_NAME,
            Tags=[{"Key": "ManagedBy", "Value": "crunr"}],
        )
        profile_arn: str = resp["InstanceProfile"]["Arn"]
        console.ok(f"Created IAM instance profile {INSTANCE_PROFILE_NAME}")
        just_created = True
    except (
        iam.exceptions.EntityAlreadyExistsException,
        botocore.exceptions.ClientError,
    ) as exc:
        if isinstance(exc, botocore.exceptions.ClientError):
            code = exc.response["Error"]["Code"]  # type: ignore[index]
            if code != "EntityAlreadyExists":
                raise
        resp = iam.get_instance_profile(InstanceProfileName=INSTANCE_PROFILE_NAME)
        profile_arn = resp["InstanceProfile"]["Arn"]
        console.info(f"  Using existing instance profile {INSTANCE_PROFILE_NAME}")

    # Attach role to profile (idempotent — catch LimitExceeded if role already attached)
    existing_roles = [
        r["RoleName"]
        for r in iam.get_instance_profile(
            InstanceProfileName=INSTANCE_PROFILE_NAME
        )["InstanceProfile"]["Roles"]
    ]
    if ROLE_NAME not in existing_roles:
        iam.add_role_to_instance_profile(
            InstanceProfileName=INSTANCE_PROFILE_NAME,
            RoleName=ROLE_NAME,
        )
        just_created = True

    if just_created:
        # IAM is eventually consistent. EC2 RunInstances will reject an
        # instance profile that it can't find yet. A brief wait is the
        # standard workaround; AWS docs suggest up to 60s but 15s is
        # almost always enough for newly-created resources.
        with console.spinner(f"Waiting {_IAM_PROPAGATION_WAIT}s for IAM to propagate…"):
            time.sleep(_IAM_PROPAGATION_WAIT)

    return profile_arn


def teardown(iam: Any) -> None:
    """Remove role from profile and delete both. Used for clean uninstall."""
    for fn, kwargs in [
        (iam.remove_role_from_instance_profile, {
            "InstanceProfileName": INSTANCE_PROFILE_NAME,
            "RoleName": ROLE_NAME,
        }),
        (iam.delete_instance_profile, {"InstanceProfileName": INSTANCE_PROFILE_NAME}),
        (iam.delete_role_policy, {"RoleName": ROLE_NAME, "PolicyName": "crunr-s3-access"}),
        (iam.delete_role, {"RoleName": ROLE_NAME}),
    ]:
        try:
            fn(**kwargs)  # type: ignore[operator]
        except Exception:  # noqa: BLE001
            pass
