"""Terminal output helpers built on Rich."""

from __future__ import annotations

import threading
import time
from contextlib import contextmanager
from typing import Generator

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.table import Table
from rich.text import Text
from rich import box

# Shared console — stderr for status, stdout for job output
_err = Console(stderr=True, highlight=False)
_out = Console(stderr=False, highlight=False)


# ---------------------------------------------------------------------------
# Brand logo
# ---------------------------------------------------------------------------

_LOGO_GREEN = "#B5F542"   # neon lime green from the crunr brand
_LOGO_BLACK = "#000000"   # inner square (blends with dark terminals = hole effect)

# 12-pixel wide × 11-pixel tall grid.  G = green pixel, B = black pixel,
# space = transparent (terminal background shows through).
# Each pixel renders as 2 space chars with the appropriate background colour,
# giving a 24-char visual width that is roughly square at standard terminal
# font metrics (characters are ~2× taller than wide).
_LOGO_GRID: list[str] = [
    "  GGGGGGGG  ",   # outer rounded top corners
    " GGGGGGGGGG ",
    "GGGGGGGGGGGG",
    "GGGGBBBBGGGG",   # inner rounded top corners
    "GGGBBBBBBGGG",
    "GGGBBBBBBGGG",
    "GGGBBBBBBGGG",
    "GGGGBBBBGGGG",   # inner rounded bottom corners
    "GGGGGGGGGGGG",
    " GGGGGGGGGG ",
    "  GGGGGGGG  ",   # outer rounded bottom corners
]


def logo_rows() -> list[str]:
    """Return each logo row as a Rich markup string (coloured 2-char pixels)."""
    rows = []
    for row in _LOGO_GRID:
        line = ""
        for ch in row:
            if ch == "G":
                line += f"[on {_LOGO_GREEN}]  [/on {_LOGO_GREEN}]"
            elif ch == "B":
                line += f"[on {_LOGO_BLACK}]  [/on {_LOGO_BLACK}]"
            else:
                line += "  "
        rows.append(line)
    return rows


# ---------------------------------------------------------------------------
# Styled printers
# ---------------------------------------------------------------------------

def step(msg: str) -> None:
    _err.print(f"[bold cyan]▸[/bold cyan] {msg}")


def ok(msg: str) -> None:
    _err.print(f"[bold green]✓[/bold green] {msg}")


def warn(msg: str) -> None:
    _err.print(f"[bold yellow]⚠[/bold yellow]  {msg}")


def error(msg: str) -> None:
    _err.print(f"[bold red]✗[/bold red] {msg}")


def info(msg: str) -> None:
    _err.print(f"[dim]{msg}[/dim]")


def header(title: str, subtitle: str = "") -> None:
    rows = logo_rows()
    mid = len(rows) // 2          # centre row = 5 for an 11-row logo

    right: list[str] = [""] * len(rows)
    right[mid - 1] = f"   [bold {_LOGO_GREEN}]{title}[/bold {_LOGO_GREEN}]"
    if subtitle:
        right[mid] = f"   [dim]{subtitle}[/dim]"

    _err.print()
    for logo_row, text_row in zip(rows, right):
        _err.print(logo_row + text_row)
    _err.print()


def job_line(text: str) -> None:
    """Print a line of live job output verbatim to stdout."""
    _out.print(text, end="")


# ---------------------------------------------------------------------------
# Real-time cost meter
# ---------------------------------------------------------------------------

class CostMeter:
    """Real-time cost ticker that updates the current terminal line in place.

    Uses carriage-return (no newline) so the meter overwrites itself every
    second — like a live counter — instead of printing a new log line.
    """

    def __init__(self, price_per_hour: float, start_time: float | None = None) -> None:
        self._price  = price_per_hour
        self._start  = start_time if start_time is not None else time.time()
        self._stop   = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def start(self) -> "CostMeter":
        self._thread.start()
        return self

    def stop(self) -> None:
        self._stop.set()
        self._thread.join(timeout=5)
        self._tick(final=True)   # commit last reading with a newline

    def _run(self) -> None:
        self._tick()
        while not self._stop.wait(1):
            self._tick()

    def _tick(self, final: bool = False) -> None:
        elapsed = time.time() - self._start
        cost    = self._price * elapsed / 3600
        mins    = int(elapsed // 60)
        secs    = int(elapsed % 60)
        _err.print(
            f"[bold green]  ⏱  {mins}m {secs:02d}s elapsed"
            f"  │  ~${cost:.6f} spent"
            f"  │  ${self._price:.4f}/hr[/bold green]",
            end="\n" if final else "\r",
        )


# ---------------------------------------------------------------------------
# Spinner context manager
# ---------------------------------------------------------------------------

@contextmanager
def spinner(msg: str) -> Generator[None, None, None]:
    with Progress(
        SpinnerColumn(style="cyan"),
        TextColumn("[progress.description]{task.description}"),
        TimeElapsedColumn(),
        console=_err,
        transient=True,
    ) as progress:
        progress.add_task(msg, total=None)
        yield


# ---------------------------------------------------------------------------
# Summary panel
# ---------------------------------------------------------------------------

def summary_panel(
    job_id: str,
    instance_type: str,
    duration_s: float,
    cost_usd: float,
    exit_code: int,
    outputs_path: str | None,
) -> None:
    status_color = "green" if exit_code == 0 else "red"
    status_label = "success" if exit_code == 0 else f"failed (exit {exit_code})"

    mins, secs = divmod(int(duration_s), 60)
    hrs, mins = divmod(mins, 60)
    if hrs:
        duration_str = f"{hrs}h {mins}m {secs}s"
    elif mins:
        duration_str = f"{mins}m {secs}s"
    else:
        duration_str = f"{secs}s"

    text = Text()
    text.append("  job id       ", style="dim")
    text.append(f"{job_id}\n", style="bold")

    text.append("  instance     ", style="dim")
    text.append(f"{instance_type}\n")

    text.append("  duration     ", style="dim")
    text.append(f"{duration_str}\n")

    text.append("  cost         ", style="dim")
    text.append(f"${cost_usd:.4f}\n")

    text.append("  status       ", style="dim")
    text.append(f"{status_label}\n", style=f"bold {status_color}")

    if outputs_path:
        text.append("  outputs      ", style="dim")
        text.append(f"{outputs_path}\n", style="cyan")

    text.append("\n  $0.00 idle cost after this point", style="dim italic")

    border = "green" if exit_code == 0 else "red"
    _err.print(Panel(text, title="[bold]run complete[/bold]", border_style=border, padding=(0, 1)))


# ---------------------------------------------------------------------------
# Jobs table
# ---------------------------------------------------------------------------

def jobs_table(records: list[dict]) -> None:  # type: ignore[type-arg]
    if not records:
        _err.print("[dim]No jobs recorded yet. Run [bold]crunr run <script>[/bold] to start.[/dim]")
        return

    table = Table(
        box=box.SIMPLE_HEAD,
        show_header=True,
        header_style="bold bright_blue",
        border_style="dim",
        padding=(0, 1),
    )
    table.add_column("Job ID", style="dim", no_wrap=True)
    table.add_column("Date", no_wrap=True)
    table.add_column("Instance", no_wrap=True)
    table.add_column("Duration", justify="right")
    table.add_column("Cost", justify="right", style="yellow")
    table.add_column("Status", justify="center")

    for r in reversed(records):
        exit_code = r.get("exit_code", -1)
        status_text = "✓ ok" if exit_code == 0 else f"✗ {exit_code}"
        status_style = "green" if exit_code == 0 else "red"

        duration_s = r.get("duration_s", 0)
        mins, secs = divmod(int(duration_s), 60)
        hrs, mins = divmod(mins, 60)
        if hrs:
            dur_str = f"{hrs}h{mins}m"
        elif mins:
            dur_str = f"{mins}m{secs}s"
        else:
            dur_str = f"{secs}s"

        cost = r.get("cost_usd", 0)
        table.add_row(
            r.get("job_id", "?")[:12],
            r.get("started_at", "?")[:16].replace("T", " "),
            r.get("instance_type", "?"),
            dur_str,
            f"${cost:.4f}",
            Text(status_text, style=status_style),
        )

    _out.print(table)


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------

def profiles_table(profiles: list[dict]) -> None:  # type: ignore[type-arg]
    if not profiles:
        _err.print("[dim]No profiles configured. Run [bold]crunr auth[/bold] to add one.[/dim]")
        return

    table = Table(
        box=box.SIMPLE_HEAD,
        header_style="bold bright_blue",
        border_style="dim",
        padding=(0, 1),
    )
    table.add_column("Profile")
    table.add_column("Region")
    table.add_column("Key ID")
    table.add_column("Default", justify="center")

    for p in profiles:
        table.add_row(
            p.get("name", "?"),
            p.get("region", "?"),
            p.get("key_id", "?"),
            "★" if p.get("is_default") else "",
        )

    _out.print(table)


def prompt(msg: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    _err.print(f"[cyan]{msg}{suffix}:[/cyan] ", end="")
    value = input()
    return value.strip() or default


def prompt_secret(msg: str) -> str:
    import getpass
    _err.print(f"[cyan]{msg}:[/cyan] ", end="")
    return getpass.getpass("")


def s3_jobs_table(jobs: list[dict]) -> None:  # type: ignore[type-arg]
    """Display S3 job list returned by crunr.s3.list_jobs()."""
    if not jobs:
        _err.print(
            "[dim]No jobs found in S3. Run [bold]crunr run --s3-bucket BUCKET script.py[/bold] to start.[/dim]"
        )
        return

    table = Table(
        box=box.SIMPLE_HEAD,
        show_header=True,
        header_style="bold bright_blue",
        border_style="dim",
        padding=(0, 1),
    )
    table.add_column("Job ID", style="dim", no_wrap=True)
    table.add_column("Date", no_wrap=True)
    table.add_column("Instance", no_wrap=True)
    table.add_column("Duration", justify="right")
    table.add_column("Cost", justify="right", style="yellow")
    table.add_column("Status", justify="center")
    table.add_column("S3 Size", justify="right", style="dim")

    for j in jobs:
        meta = j.get("metadata", {})
        job_id = j.get("job_id", "?")

        exit_code = meta.get("exit_code", -1)
        status_text = "✓ ok" if exit_code == 0 else f"✗ {exit_code}"
        status_style = "green" if exit_code == 0 else "red"

        duration_s = meta.get("duration_s", 0)
        mins, secs = divmod(int(duration_s), 60)
        hrs, mins = divmod(mins, 60)
        if hrs:
            dur_str = f"{hrs}h{mins}m"
        elif mins:
            dur_str = f"{mins}m{secs}s"
        else:
            dur_str = f"{secs}s"

        size_bytes = j.get("size_bytes", 0)
        if size_bytes >= 1_073_741_824:
            size_str = f"{size_bytes / 1_073_741_824:.1f} GB"
        elif size_bytes >= 1_048_576:
            size_str = f"{size_bytes / 1_048_576:.1f} MB"
        elif size_bytes >= 1024:
            size_str = f"{size_bytes / 1024:.1f} KB"
        elif size_bytes:
            size_str = f"{size_bytes} B"
        else:
            size_str = "—"

        cost = meta.get("cost_usd", 0)
        started = meta.get("started_at", "?")
        date_str = (started[:16] if started and started != "?" else "?").replace("T", " ")

        table.add_row(
            job_id[:12],
            date_str,
            meta.get("instance_type", "?"),
            dur_str,
            f"${cost:.4f}" if cost else "?",
            Text(status_text, style=status_style),
            size_str,
        )

    _out.print(table)


def share_links(links: list[dict], ttl_hours: int, expires_label: str) -> None:  # type: ignore[type-arg]
    """Print share links: filenames/sizes to stderr, bare URLs to stdout for easy copy."""
    _err.print(
        f"\n[bold]  {len(links)} file(s)[/bold]  [dim]•[/dim]  "
        f"expires in [bold]{ttl_hours}h[/bold]  [dim]({expires_label})[/dim]"
    )
    _err.print(
        "[yellow]  ⚠  Anyone with a link can download until it expires. "
        "Pass [bold]--ttl 1[/bold] to limit exposure.[/yellow]\n"
    )
    for link in links:
        size = link["size_bytes"]
        if size >= 1_073_741_824:
            size_str = f"{size / 1_073_741_824:.1f} GB"
        elif size >= 1_048_576:
            size_str = f"{size / 1_048_576:.1f} MB"
        elif size >= 1024:
            size_str = f"{size / 1024:.1f} KB"
        else:
            size_str = f"{size} B"
        _err.print(f"  [bold cyan]{link['filename']}[/bold cyan]  [dim]{size_str}[/dim]")
        _out.print(link["url"])
        _err.print()


def choose(msg: str, options: list[tuple[str, str]]) -> str:
    """Numbered menu. Returns the value (first element) of the chosen option."""
    _err.print(f"\n[bold]{msg}[/bold]")
    for i, (value, label) in enumerate(options, 1):
        _err.print(f"  [cyan]{i:2}.[/cyan] {label}  [dim]({value})[/dim]")
    while True:
        raw = prompt(f"Enter number [1-{len(options)}]")
        if raw.isdigit() and 1 <= int(raw) <= len(options):
            return options[int(raw) - 1][0]
        warn("Invalid choice — enter a number from the list.")
