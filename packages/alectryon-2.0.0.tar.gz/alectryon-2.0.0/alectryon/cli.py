# Copyright © 2019 Clément Pit-Claudel
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from __future__ import annotations

from typing import Any, ClassVar, Dict, Optional, Tuple, List, Union, NamedTuple, TYPE_CHECKING

if TYPE_CHECKING:
    from bs4 import BeautifulSoup, ResultSet

import argparse
import inspect
import os
import os.path
import re
import shutil
import sys

from . import __version__, core

# Pipelines
# =========

def read_plain(_, fpath, input_is_stdin):
    if input_is_stdin:
        return sys.stdin.read()
    with open(fpath, encoding="utf-8") as f:
        return f.read()

def read_json(_, fpath, input_is_stdin):
    from .json import loads
    return loads(read_plain(None, fpath, input_is_stdin))

def parse_plain(contents, fpath):
    return [core.PosStr(contents, core.Position.default(fpath), 0)]

class CodeSnippet(NamedTuple):
    contents: Any
    lang: str
    annots: str

    @property
    def io_annots(self):
        from .transforms import read_all_io_flags
        return self.annots and read_all_io_flags(self.annots)

    @staticmethod
    def _by_lang(snippets: list["CodeSnippet"]) -> "SnippetCollection":
        bylang: "SnippetCollection" = {}
        for snippet in snippets:
            bylang.setdefault(snippet.lang, []).append(snippet)
        return bylang

    @staticmethod
    def _update(snippets: list["CodeSnippet"], items):
        for snippet, contents in zip(snippets, items):
            yield snippet._replace(contents=contents)

    @staticmethod
    def _update_by_lang(snippets, by_lang):
        iters = { k: iter(vs) for k, vs in by_lang.items() }
        for snippet in snippets:
            if isinstance(snippet, CodeSnippet):
                snippet = next(iters[snippet.lang], None)
                assert snippet
            yield snippet

SnippetCollection = dict[str, list[CodeSnippet]]

def _catch_parsing_errors(fpath, k, *args):
    from .literate import ParsingError
    try:
        return k(*args)
    except ParsingError as e:
        raise ValueError("{}: {}".format(fpath, e)) from e

def code_to_markup(code, fpath, point, marker, input_language, backend):
    from .literate import get_markup, code2markup_marked
    markup = get_markup(backend, input_language)
    return _catch_parsing_errors(fpath, code2markup_marked, markup, code, point, marker)

def markup_to_code(rst, fpath, point, marker, frontend, backend):
    from .literate import get_markup, markup2code_marked
    markup = get_markup(frontend, backend.split("+")[0])
    return _catch_parsing_errors(fpath, markup2code_marked, markup, rst, point, marker)

def _annotate_chunks(chunks, fpath, driver_config, cache, exit_code):
    from .core import StderrObserver
    driver = driver_config.init_driver(fpath)
    annotated = cache.update(chunks, driver)
    assert isinstance(driver.observer, StderrObserver)
    exit_code.val = int(exit_code.val or driver.observer.exit_code >= 3)
    return annotated

def annotate_chunks(chunks, fpath, cache_directory, cache_compression,
                    driver_configs, input_language, exit_code):
    from .json import CacheSet
    with CacheSet(cache_directory, fpath, cache_compression) as caches:
        return _annotate_chunks(chunks, fpath, driver_configs[input_language],
                                caches[input_language], exit_code)

def _annotate_snippets(snippets, fpath, driver_config, cache, exit_code):
    contents = [s.contents for s in snippets]
    annotated = _annotate_chunks(contents, fpath, driver_config, cache, exit_code)
    return list(CodeSnippet._update(snippets, annotated))

def annotate_polyglot(snippets: list[CodeSnippet], fpath, cache_directory, cache_compression,
                      driver_configs, exit_code):
    from .json import CacheSet
    with CacheSet(cache_directory, fpath, cache_compression) as caches:
        return {
            lang: _annotate_snippets(snippets, fpath,
                                     driver_configs[lang], caches[lang],
                                     exit_code)
            for lang, snippets in CodeSnippet._by_lang(snippets).items()
        }

# Passing these settings avoids `FutureWarning`s
DOCUTILS_FUTURE_WARNINGS_SETTINGS_OVERRIDES = {
    'use_latex_citations': True,
    'legacy_column_widths': False,
}

def register_docutils(v, ctx):
    from . import docutils

    docutils.AlectryonTransform.DRIVER_ARGS = ctx["driver_args_by_name"]
    docutils.AlectryonTransform.LANGUAGE_DRIVERS = ctx["language_drivers"]
    docutils.CACHE_DIRECTORY = ctx["cache_directory"]
    docutils.CACHE_COMPRESSION = ctx["cache_compression"]
    docutils.HTML_MINIFICATION = ctx["html_minification"]
    docutils.LONG_LINE_THRESHOLD = ctx["long_line_threshold"]
    docutils.setup(ctx["input_language"] or "coq")

    # The encoding/decoding dance below happens because setting output_encoding
    # to "unicode" causes reST to generate a bad <meta> tag, and setting
    # input_encoding to "unicode" breaks the ‘.. include’ directive.

    # Setting ``traceback`` unconditionally allows us to catch and report errors
    # from our own docutils components and avoid asking users to make a report
    # to the docutils mailing list.

    ctx["docutils_settings_overrides"] = {
        'traceback': True,
        'stylesheet_path': None,
        'input_encoding': 'utf-8',
        'output_encoding': 'utf-8',
        'exit_status_level': 3,
        'pygments_style': ctx["pygments_style"],
        'alectryon_banner': ctx["include_banner"],
        'alectryon_vernums': ctx["include_vernums"],
        'alectryon_webpage_style': ctx["webpage_style"],
        **DOCUTILS_FUTURE_WARNINGS_SETTINGS_OVERRIDES
    }

    return v

def _gen_docutils(source, fpath,
                  Parser, Reader, Writer,
                  settings_overrides):
    from docutils.core import publish_programmatically
    from docutils.io import StringInput, StringOutput

    parser = Parser()

    # LATER: ``destination_path=None`` propagates to ``settings._destination``,
    # which means that ``stylesheet_path`` isn't actually resolved relative to
    # ``_destination``.  This isn't trivial to fix because the name of the
    # output is determined by the argument to ``write_file``.  Maybe we should
    # call a function ``set_output_filename`` early in each pipeline instead?
    text, pub = publish_programmatically(
        source_class=StringInput, destination_class=StringOutput,
        source=source.encode("utf-8"), destination=None,
        source_path=fpath, destination_path=None,

        reader=Reader(parser), reader_name=None,
        parser=parser, parser_name=None,
        writer=Writer(), writer_name=None,

        settings=None, settings_spec=None,
        settings_overrides=settings_overrides, config_section=None,
        enable_exit_status=False)

    max_level = pub.document.reporter.max_level
    exit_code = max_level + 10 if max_level >= pub.settings.exit_status_level else 0
    return text.decode("utf-8"), pub, exit_code

def _record_assets(assets, path, names):
    for name in names:
        assets.append((path, name))

class DocutilsException(Exception):
    pass

def gen_docutils(src, frontend, backend, fpath, dialect,
                 docutils_settings_overrides, assets, exit_code):
    from .docutils import get_pipeline, alectryon_state
    from docutils.utils import SystemMessage

    pipeline = get_pipeline(frontend, backend, dialect)
    try:
        text, pub, exit_code.val = \
            _gen_docutils(src, fpath,
                          pipeline.parser, pipeline.reader, pipeline.writer,
                          docutils_settings_overrides)
    except SystemMessage as e:
        MSG = ("Exiting early due to a level-{} Docutils message.\n"
               "Use docutils setting `halt_level` to change this behavior.")
        raise DocutilsException(MSG.format(e.level)) from e

    embedded_assets = alectryon_state(pub.document).embedded_assets
    _record_assets(assets,
                   pipeline.translator.ASSETS_PATH,
                   [a for a in pipeline.translator.ASSETS if a not in embedded_assets])

    return text

def _docutils_cmdline(description, frontend, backend, dialect):
    import locale
    locale.setlocale(locale.LC_ALL, '')

    from docutils.core import publish_cmdline, default_description
    from .docutils import setup, get_pipeline

    setup()

    pipeline = get_pipeline(frontend, backend, dialect)
    return publish_cmdline(
        reader=pipeline.reader(), parser=pipeline.parser(), writer=pipeline.writer(),
        settings_overrides={'stylesheet_path': None,
                            **DOCUTILS_FUTURE_WARNINGS_SETTINGS_OVERRIDES},
        description="{} {}".format(description, default_description))

def inherit_io_annots(snippets: list[CodeSnippet]):
    from .transforms import inherit_io_annots as inherit_annots
    for snippet in snippets:
        if annots := snippet.io_annots:
            fragments = list(inherit_annots(snippet.contents, annots))
            snippet = snippet._replace(contents=fragments)
        yield snippet

def remove_hidden_snippets(snippets: list[CodeSnippet]):
    from .transforms import all_hidden
    for snippet in snippets:
        if snippet.annots and all_hidden(snippet.contents, snippet.io_annots):
            snippet = snippet._replace(contents=None)
        yield snippet

def apply_transforms(annotated, input_language):
    from .transforms import default_transform
    for fragments in annotated:
        yield default_transform(fragments, input_language)

def _scrub_fname(fname):
    return re.sub("[^-a-zA-Z0-9]", "-", fname)

def gen_html_snippets(annotated, fname, input_language,
                      html_minification, pygments_style):
    from .html import HtmlGenerator
    from .pygments import make_highlighter
    fname = _scrub_fname(fname)
    highlighter = make_highlighter("html", input_language, pygments_style)
    return HtmlGenerator(highlighter, fname, html_minification).gen(annotated)

def gen_latex_snippets(annotated, input_language, pygments_style):
    from .latex import LatexGenerator
    from .pygments import make_highlighter
    highlighter = make_highlighter("latex", input_language, pygments_style)
    return LatexGenerator(highlighter).gen(annotated)

COQDOC_OPTIONS = ['doc', '--body-only', '--no-glob', '--no-index', '--no-externals',
                  '-s', '--html', '--stdout', '--utf8']

def _run_coqdoc(coq_snippets, coqdoc_bin=None):
    """Get the output of coqdoc on coq_code."""
    from tempfile import TemporaryDirectory, NamedTemporaryFile
    from subprocess import check_output
    coqdoc_bin = coqdoc_bin or os.path.join(os.getenv("COQBIN", ""), "rocq")
    with TemporaryDirectory(prefix="alectryon_coqdoc_") as dpath:
        with NamedTemporaryFile(mode="w", encoding="utf-8", suffix=".v",
                                dir=dpath, delete=False) as f:
            for snippet in coq_snippets:
                f.write(snippet)
                f.write("\n(* --- *)\n") # Separator to prevent fusing
        coqdoc = [coqdoc_bin, *COQDOC_OPTIONS, "-d", dpath, f.name]
        return check_output(coqdoc, cwd=dpath, timeout=10).decode("utf-8")

def _gen_coqdoc_html_assert(docs, coqdoc_comments):
    if len(docs) != len(coqdoc_comments):
        from pprint import pprint
        print("Coqdoc mismatch:", file=sys.stderr)
        pprint(list(zip(coqdoc_comments, docs)), stream=sys.stderr)
        raise AssertionError()

def _parse_html(html):
    from bs4 import BeautifulSoup
    return BeautifulSoup(html, "html.parser")

def _gen_coqdoc_html(coqdoc_fragments):
    coqdoc_output = _run_coqdoc(fr.contents for fr in coqdoc_fragments)
    soup = _parse_html(coqdoc_output)
    docs = soup.find_all(class_='doc')
    coqdoc_comments = [c for c in coqdoc_fragments if not c.special]
    _gen_coqdoc_html_assert(docs, coqdoc_comments)
    return docs

def _gen_html_snippets_with_coqdoc(annotated, fname, html_minification,
                                   input_language, pygments_style):
    from dominate.util import raw
    from .html import HtmlGenerator
    from .pygments import make_highlighter
    from .transforms import isolate_coqdoc, default_transform, CoqdocFragment

    fname = _scrub_fname(fname)
    highlighter = make_highlighter("html", input_language, pygments_style)
    writer = HtmlGenerator(highlighter, fname, html_minification)

    parts = [part for fragments in annotated
             for part in isolate_coqdoc(fragments)]
    coqdoc = [part for part in parts
              if isinstance(part, CoqdocFragment)]
    coqdoc_html = iter(_gen_coqdoc_html(coqdoc))

    for part in parts:
        if isinstance(part, CoqdocFragment):
            if not part.special:
                yield [raw(str(next(coqdoc_html, None)))]
        else:
            fragments = default_transform(part.fragments, input_language)
            yield writer.gen_fragments(fragments)

def gen_html_snippets_with_coqdoc(annotated, html_classes, fname,
                                  html_minification, input_language, pygments_style):
    html_classes.append("coqdoc")
    # ‘return’ instead of ‘yield from’ to update html_classes eagerly
    return _gen_html_snippets_with_coqdoc(
        annotated, fname, html_minification, input_language, pygments_style)

def copy_assets(state, assets: List[Tuple[str, Union[str, core.Asset]]],
                copy_fn, output_directory, ctx=None):
    if copy_fn is None:
        return state

    for (path, asset) in assets:
        src = os.path.join(path, asset)
        dst = os.path.join(output_directory, asset)

        if isinstance(asset, core.Asset):
            with open(dst, mode="w", encoding="utf-8") as f:
                f.write(asset.gen(ctx or {}))
            continue

        if copy_fn is not shutil.copyfile:
            try:
                os.unlink(dst)
            except FileNotFoundError:
                pass
        try:
            copy_fn(src, dst)
        except (shutil.SameFileError, FileExistsError):
            pass

    return state

def _gen_html_header(html_minification, assets):
    from dominate.util import raw, container
    from dominate import tags
    from . import GENERATOR
    from .html import ASSETS, ADDITIONAL_HEADS, JS_UNMINIFY

    head = container()
    head.add(tags.meta(name="generator", content=GENERATOR))

    for hd in ADDITIONAL_HEADS:
        head.add(raw(hd))
    if html_minification:
        head.add(raw(JS_UNMINIFY))
    for css in ASSETS.ALECTRYON_CSS + ASSETS.PYGMENTS_CSS:
        head.add(tags.link(rel="stylesheet", href=str(css)))
    for link in (ASSETS.IBM_PLEX_CDN, ASSETS.FIRA_CODE_CDN):
        head.add(raw("\n    " + link))
    for js in ASSETS.ALECTRYON_JS:
        head.add(tags.script(src=js))

    _record_assets(assets, ASSETS.PATH, ASSETS.ALECTRYON_CSS)
    _record_assets(assets, ASSETS.PATH, ASSETS.ALECTRYON_JS)
    _record_assets(assets, ASSETS.PATH, ASSETS.PYGMENTS_CSS)

    return head

def _add_html_minification_class(html_classes, html_minification):
    if html_minification:
        html_classes.append("minified")

def _get_banner(fpath, driver_configs, include_vernums):
    from .html import gen_banner
    vi = [dc.init_driver(fpath).version_info()
          for dc in driver_configs.values() if dc.used]
    return gen_banner(vi, include_vernums)

def dump_html_standalone(snippets, fname, webpage_style,
                         html_minification, include_banner,
                         assets, html_classes, ctx) -> str:
    from dominate import tags, document
    from dominate.util import raw
    from .html import wrap_classes, HTML4_VIEWPORT

    doc = document(title=fname)
    doc.set_attribute("class", "alectryon-standalone")

    doc.head.add(tags.meta(charset="utf-8"))
    doc.head.add(raw(s) for s in HTML4_VIEWPORT)
    doc.head.add(_gen_html_header(html_minification, assets))

    _add_html_minification_class(html_classes, html_minification)
    cls = wrap_classes(webpage_style, *html_classes)

    root = doc.body.add(tags.article(cls=cls))
    if include_banner:
        root.add(raw(ctx_invoke(_get_banner, ctx)))
    for snippet in snippets:
        root.add(snippet)

    return doc.render(pretty=False)

class ParsedHTMLDocument:
    """A parsed HTML document."""
    HTML_CODE_BLOCK_SELECTOR: ClassVar[str] = "pre.alectryon"

    def __init__(self, html: str, input_language: str):
        self.soup: BeautifulSoup = _parse_html(html)
        self.tags: ResultSet = self.soup.select(self.HTML_CODE_BLOCK_SELECTOR)
        self.snippets: list[CodeSnippet] = [
            CodeSnippet(tag.text, tag.get("data-lang", input_language), tag.get("data-io"))
            for tag in self.tags
        ]

    def update(self, by_lang):
        from bs4.element import PreformattedString
        snippets = CodeSnippet._update_by_lang(self.snippets, by_lang)
        for tag, snippet in zip(self.tags, snippets):
            if snippet.contents is None:
                tag.decompose()
            else:
                tag.replace_with(PreformattedString(str(snippet.contents)))

def parse_html(state, input_language, ctx) -> list[CodeSnippet]:
    """Separate code snippets from HTML document `state`."""
    ctx["document"] = document = ParsedHTMLDocument(state, input_language)
    return document.snippets

def unparse_html(chunks, document, html_minification, include_banner,
                 assets, html_classes, webpage_style, ctx) -> str:
    """Replace code blocks in `document` with annotated `chunks`."""
    from bs4.element import PreformattedString
    from .html import wrap_classes
    document.update(chunks)

    head, body = document.soup.find("head"), document.soup.find("body")
    head.append(PreformattedString(_gen_html_header(html_minification, assets).render()))

    _add_html_minification_class(html_classes, html_minification)
    body["class"] = body.get("class", []) + [wrap_classes(webpage_style, *html_classes)]

    if include_banner:
        body.insert(0, PreformattedString(ctx_invoke(_get_banner, ctx)))

    return str(document.soup)

class ParsedLaTeXDocument:
    """A LaTeX document, split into a sequence of code and text blocks."""

    LATEX_IO_RE = re.compile(r"""
    ^(?P<indent>[ ]*)\\begin[{]alectryon[}][{](?P<lang>.*?)[}][{](?P<annots>.*)[}][ ]*\n
        (?P<body>(?:.|\n)*?)
    ^[ ]*\\end[{]alectryon[}]
    """, re.VERBOSE | re.MULTILINE)

    def __init__(self, latex: str):
        self.blocks: list[str | CodeSnippet] = []
        end = 0
        for m in self.LATEX_IO_RE.finditer(latex):
            if end < m.start():
                self.blocks.append(latex[end:m.start()])
            indent, lang, body, annots = m.group("indent", "lang", "body", "annots")
            _, body = core.dedent(body.splitlines(), len(indent))
            self.blocks.append(CodeSnippet(body, lang, annots))
            end = m.end()
        if end < len(latex):
            self.blocks.append(latex[end:])

    @property
    def snippets(self):
        return [s for s in self.blocks if isinstance(s, CodeSnippet)]

    def unparse(self, by_lang):
        return [block.contents if isinstance(block, CodeSnippet) else block
                for block in CodeSnippet._update_by_lang(self.blocks, by_lang)]

def parse_latex(state, ctx) -> List[CodeSnippet]:
    """Extract code snippets from TeX input `state`."""
    ctx["document"] = document = ParsedLaTeXDocument(state)
    return document.snippets

def unparse_latex(snippets, document, assets) -> str:
    """Replaces snippets in a LaTeX document with their snippets equivalents."""
    from .docutils import LatexTranslator
    _record_assets(assets, LatexTranslator.ASSETS_PATH, LatexTranslator.ASSETS)
    return "".join(str(s) for s in document.unparse(snippets) if s)

def encode_json(obj):
    from .json import PlainSerializer
    return PlainSerializer.encode(obj)

def decode_json(obj):
    from .json import PlainSerializer
    return PlainSerializer.decode(obj)

def dump_json(js):
    from json import dumps
    return dumps(js, indent=4)

def dump_snippets(snippets, separator):
    return "".join(s.render(pretty=True) + separator for s in snippets)

def dump_html_snippets(snippets):
    return dump_snippets(snippets, "<!-- alectryon-block-end -->\n")

def dump_latex_snippets(snippets):
    return dump_snippets(snippets, "\n%% alectryon-block-end\n")

def write_output(ext, contents, fname, output, output_directory, strip_re):
    if output == "-":
        sys.stdout.write(contents)
    else:
        if not output:
            fname = strip_re.sub("", fname)
            output = os.path.join(output_directory, fname + ext)
        os.makedirs(os.path.dirname(os.path.abspath(output)), exist_ok=True)
        with open(output, mode="w", encoding="utf-8") as f:
            f.write(contents)

def write_file(ext, strip):
    strip_re = re.compile("(" + "|".join(re.escape(ext) for ext in strip) + ")*\\Z")
    return lambda contents, fname, output, output_directory: \
        write_output(ext, contents, fname, output,
                     output_directory, strip_re=strip_re)

def on_snippets(*pipeline):
    def _dispatch(snippets: list[CodeSnippet], ctx):
        snippets = list(snippets)
        items = (snippet.contents for snippet in snippets)
        return CodeSnippet._update(snippets, run_pipeline(pipeline, items, ctx))
    return _dispatch

def by_language(*pipeline):
    def _dispatch(snippets_by_lang: SnippetCollection, ctx):
        """Run `pipeline` on each group in `snippets_by_lang`."""
        return {
            lang: run_pipeline(pipeline, snippets, { **ctx, "input_language": lang })
            for lang, snippets in snippets_by_lang.items()
        }
    return _dispatch

CODE_EXTENSIONS = {
    ext for exts in core.EXTENSIONS_BY_LANGUAGE.values() for ext in exts
}

# No ‘apply_transforms’ in JSON pipelines: we save the prover output without
# modifications.
def _add_code_pipelines(pipelines, lang, *exts):
    pipelines[lang + '.json'] = {
        'null':
        (read_json, annotate_chunks),
        'json':
        (read_json, annotate_chunks, encode_json, dump_json,
         write_file(".io.json", strip=(".json",))),
        'snippets-html':
        (read_json, annotate_chunks, apply_transforms, gen_html_snippets,
         dump_html_snippets, write_file(".snippets.html", strip=(*exts, ".json",))),
        'snippets-latex':
        (read_json, annotate_chunks, apply_transforms, gen_latex_snippets,
         dump_latex_snippets, write_file(".snippets.tex", strip=(*exts, ".json",)))
    }
    pipelines[lang + '.io.json'] = {
        'null':
        (read_json, decode_json),
        'snippets-html':
        (read_json, decode_json, apply_transforms,
         gen_html_snippets, dump_html_snippets,
         write_file(".snippets.html", strip=(*exts, ".io", ".json"))),
        'snippets-latex':
        (read_json, decode_json, apply_transforms,
         gen_latex_snippets, dump_latex_snippets,
         write_file(".snippets.tex", strip=(*exts, ".io", ".json"))),
        'webpage':
        (read_json, decode_json, apply_transforms, gen_html_snippets,
         dump_html_standalone, copy_assets,
         write_file(".html", strip=(".io", ".json",))),
    }
    pipelines[lang] = {
        'null':
        (read_plain, parse_plain, annotate_chunks),
        'webpage':
        (read_plain, parse_plain, annotate_chunks, apply_transforms,
         gen_html_snippets, dump_html_standalone, copy_assets,
         write_file(".html", strip=())),
        'snippets-html':
        (read_plain, parse_plain, annotate_chunks, apply_transforms,
         gen_html_snippets, dump_html_snippets,
         write_file(".snippets.html", strip=exts)),
        'snippets-latex':
        (read_plain, parse_plain, annotate_chunks, apply_transforms,
         gen_latex_snippets, dump_latex_snippets,
         write_file(".snippets.tex", strip=exts)),
        'lint':
        (read_plain, register_docutils, gen_docutils,
         write_file(".lint.json", strip=exts)),
        'json':
        (read_plain, parse_plain, annotate_chunks, encode_json, dump_json,
         write_file(".io.json", strip=()))
    }
    for markup, mexts in core.EXTENSIONS_BY_MARKUP.items():
        strip = (*exts, *mexts)
        pipelines["{}+{}".format(lang, markup)] = {
            'webpage':
            (read_plain, register_docutils, gen_docutils, copy_assets,
             write_file(".html", strip=strip)),
            'latex':
            (read_plain, register_docutils, gen_docutils, copy_assets,
             write_file(".tex", strip=strip)),
            'lint':
            (read_plain, register_docutils, gen_docutils,
             write_file(".lint.json", strip=strip)),
        }

def _add_special_pipelines(pipelines):
    pipelines['coqdoc'] = {
        'webpage':
        (read_plain, parse_plain, annotate_chunks, # transforms applied later
         gen_html_snippets_with_coqdoc, dump_html_standalone, copy_assets,
         write_file(".html", strip=(".v",))),
    }
    pipelines['latex'] = {
        'latex':
        (read_plain, parse_latex, annotate_polyglot,
         by_language(inherit_io_annots,
                     on_snippets(apply_transforms),
                     remove_hidden_snippets,
                     on_snippets(gen_latex_snippets)),
         unparse_latex, copy_assets, write_file(".annotated.tex", strip=(".tex",))),
    }
    pipelines['html'] = {
        'webpage':
        (read_plain, parse_html, annotate_polyglot,
         by_language(inherit_io_annots,
                     on_snippets(apply_transforms),
                     remove_hidden_snippets,
                     on_snippets(gen_html_snippets)),
         unparse_html, copy_assets, write_file(".annotated.html", strip=(".html",)))
    }

def _add_docutils_pipelines(pipelines, lang, *exts):
    exts = (*CODE_EXTENSIONS, *exts)
    pipelines[lang] = {
        'webpage':
        (read_plain, register_docutils, gen_docutils, copy_assets,
         write_file(".html", strip=exts)),
        'latex':
        (read_plain, register_docutils, gen_docutils, copy_assets,
         write_file(".tex", strip=exts)),
        'lint':
        (read_plain, register_docutils, gen_docutils,
         write_file(".lint.json", strip=exts))
    }

def _add_transliteration_pipelines(pipelines):
    for markup, mexts in core.EXTENSIONS_BY_MARKUP.items():
        exts = (*CODE_EXTENSIONS, *mexts)
        for lang, (ext, *_) in core.EXTENSIONS_BY_LANGUAGE.items():
            lang_plus = "{}+{}".format(lang, markup)
            pipelines[markup][lang] = pipelines[markup][lang_plus] = \
                (read_plain, markup_to_code, write_file(ext, strip=exts))
            pipelines[lang][markup] = \
                (read_plain, code_to_markup, write_file(mexts[0], strip=()))
            pipelines[lang_plus][markup] = \
                (read_plain, code_to_markup, write_file(ext + mexts[0], strip=exts))

def warn_renamed_json_pipeline(v, ctx):
    print("WARNING: Frontend `json` is ambiguous; use `coq.json` instead.",
          file=sys.stderr)
    ctx["frontend"] = 'coq.json'
    return v

def _add_compatibility_pipelines(pipelines):
    pipelines['json'] = {
        backend: (warn_renamed_json_pipeline, *steps)
        for (backend, steps) in pipelines['coq.json'].items()
    }

def _add_pipelines(pipelines):
    for lang, exts in core.EXTENSIONS_BY_LANGUAGE.items():
        _add_code_pipelines(pipelines, lang, *exts)
    _add_special_pipelines(pipelines)
    for markup, exts in core.EXTENSIONS_BY_MARKUP.items():
        _add_docutils_pipelines(pipelines, markup, *exts)
    _add_transliteration_pipelines(pipelines)
    _add_compatibility_pipelines(pipelines)
    return pipelines

# LATER: Reorganize to separate concepts of language and frontend instead of
# generating (languages * frontend) entries in PIPELINES.
PIPELINES = _add_pipelines({})

# CLI
# ===

def _language_frontends_by_extension(ext, lang):
    return [
        (ext, lang + '+rst'),
        (ext + '.json', lang + '.json'),
        (ext + '.io.json', lang + '.io.json'),
    ]

FRONTENDS_BY_EXTENSION = {
    **{ext: frontend
       for lang, exts in core.EXTENSIONS_BY_LANGUAGE.items() for ext in exts
       for ext, frontend in _language_frontends_by_extension(ext, lang)},
    **{ext: markup
       for markup, exts in core.EXTENSIONS_BY_MARKUP.items() for ext in exts},
    '.html': 'html',
    '.tex': 'latex',
    '.json': 'json', # LATER: Remove
}

BACKENDS_BY_EXTENSION = {
    **{ext: lang
       for lang, exts in core.EXTENSIONS_BY_LANGUAGE.items() for ext in exts},
    **{ext: markup
       for markup, exts in core.EXTENSIONS_BY_MARKUP.items() for ext in exts},
    '.lint.json': 'lint', '.json': 'json',
    '.snippets.html': 'snippets-html', '.snippets.tex': 'snippets-latex',
    '.html': 'webpage', '.tex': 'latex'
}

def _default_language_backends(lang):
    return {
        lang: 'webpage',
        lang + '.json': 'json',
        lang + '.io.json': 'webpage',
        **{f"{lang}+{markup}": 'webpage' for markup in core.EXTENSIONS_BY_MARKUP}
    }

DEFAULT_BACKENDS = {
    **{fr: bk
       for lang in core.ALL_LANGUAGES
       for (fr, bk) in _default_language_backends(lang).items()},
    **{markup: 'webpage'
       for markup in core.EXTENSIONS_BY_MARKUP},

    'coqdoc': 'webpage',
    'latex': 'latex',
    'html': 'webpage',

    'json': 'json', # LATER: Remove
}

def _input_frontends(lang):
    return [lang, lang + '.json', lang + '.io.json',
            *[f"{lang}+{markup}" for markup in core.EXTENSIONS_BY_MARKUP]]

INPUT_LANGUAGE_BY_FRONTEND = {
    **{fr: lang
       for lang in core.ALL_LANGUAGES
       for fr in _input_frontends(lang)},

    "coqdoc": "coq",

    "json": "coq", # LATER: Remove
    "html": "coq",
    "latex": "coq"
}

def infer_mode(fpath, kind, arg, table):
    for (ext, mode) in table.items():
        if fpath.endswith(ext):
            return mode
    MSG = """{}: Not sure what to do with {!r}.
Try passing {}?"""
    raise argparse.ArgumentTypeError(MSG.format(kind, fpath, arg))

def infer_frontend(fpath):
    return infer_mode(fpath, "input", "--frontend", FRONTENDS_BY_EXTENSION)

def infer_backend(frontend, out_fpath):
    if out_fpath and out_fpath not in ("-", "/dev/null"):
        return infer_mode(out_fpath, "output", "--backend", BACKENDS_BY_EXTENSION)
    return DEFAULT_BACKENDS[frontend]

def resolve_pipeline(fpath, args):
    frontend = args.frontend or infer_frontend(fpath)

    assert frontend in PIPELINES
    supported_backends = PIPELINES[frontend]

    backend = args.backend or infer_backend(frontend, args.output)
    if backend not in supported_backends:
        MSG = """argument --backend: Frontend {!r} does not support backend {!r}: \
expecting one of {}"""
        raise argparse.ArgumentTypeError(MSG.format(
            frontend, backend, ", ".join(map(repr, supported_backends))))

    return frontend, backend, supported_backends[backend]

COPY_FUNCTIONS = {
    "copy": shutil.copyfile,
    "symlink": os.symlink,
    "hardlink": os.link,
    "none": None
}

DRIVER_ARGS_BY_NAME: Dict[str, Optional[str]] = {
    "coqc_time": "coqc_args",
    "coqlsp": None,
    "dafny_lsp": None,
    "lean3_repl": None,
    "leanInk": "leanInk_args",
    "noop": None,
    "sertop": "sertop_args",
    "sertop_noexec": "sertop_args",
    "vsrocq": "coqc_args",
}
"""Map from driver name to field in argparse namespace.
Used to populate ``args.driver_args_by_name`` in ``post_process_arguments``."""

assert set(core.ALL_DRIVERS) == DRIVER_ARGS_BY_NAME.keys()

def post_process_arguments(parser, args):
    if len(args.input) > 1 and args.output:
        parser.error("argument --output: Not valid with multiple inputs")

    if args.stdin_filename and "-" not in args.input:
        parser.error("argument --stdin-filename: input must be '-'")

    args.backend_dialects = {
        "webpage": args.html_dialect,
        "latex": args.latex_dialect
    }

    args.language_drivers = core.DEFAULT_DRIVERS.copy()
    for lang in core.ALL_LANGUAGES:
        if driver := getattr(args, "{}_driver".format(lang)):
            args.language_drivers[lang] = driver

    coq_args = []
    for (dirpath,) in args.coq_args_I:
        coq_args.append(("-I", dirpath))
    for pair in args.coq_args_R:
        coq_args.append(("-R", *pair))
    for pair in args.coq_args_Q:
        coq_args.append(("-Q", *pair))

    args.sertop_args.extend(arg for opt, *args in coq_args for arg in (opt, ",".join(args)))
    args.coqc_args.extend(arg for args in coq_args for arg in args)

    args.leanInk_args = []
    if args.leanInk_args_lake is not None:
        args.leanInk_args.extend(("--lake", args.leanInk_args_lake))
    if args.debug:
        args.leanInk_args.extend(("--verbose",))

    args.driver_args_by_name = {
        driver: (getattr(args, field) if field else ())
        for driver, field in DRIVER_ARGS_BY_NAME.items()
    }

    # argparse applies ‘type’ before ‘choices’, so we do the conversion here
    args.copy_fn = COPY_FUNCTIONS[args.copy_fn]

    if args.long_line_threshold <= 0:
        args.long_line_threshold = None

    args.point, args.marker = args.mark_point
    if args.point is not None:
        try:
            args.point = int(args.point)
        except ValueError:
            MSG = "argument --mark-point: Expecting a number, not {!r}"
            parser.error(MSG.format(args.point))

        # LATER: if args.marker.isspace():
        #     MSG = "argument --mark-point: Marker must not be whitespace ({!r})"
        #     parser.error(MSG.format(args.marker))

    args.pipelines = [(fpath, *resolve_pipeline(fpath, args))
                      for fpath in args.input]

    return args

def build_parser():
    parser = argparse.ArgumentParser(
        description="""\
Annotate segments of Coq code with responses and goals.
Take input in Coq, reStructuredText, Markdown, or JSON \
and produce reStructuredText, HTML, LaTeX, or JSON output.""",
        fromfile_prefix_chars='@')

    VERSION_HELP = "Print version and exit."
    parser.add_argument("--version", action="version",
                        version="Alectryon v{}".format(__version__),
                        help=VERSION_HELP)

    in_ = parser.add_argument_group("Input configuration")

    INPUT_FILES_HELP = "Input files"
    in_.add_argument("input", nargs="+", help=INPUT_FILES_HELP)

    INPUT_STDIN_NAME_HELP = "Name of file passed on stdin, if any"
    in_.add_argument("--stdin-filename", default=None,
                     help=INPUT_STDIN_NAME_HELP)

    FRONTEND_HELP = "Choose a frontend. Defaults: "
    FRONTEND_HELP += "; ".join("{!r} → {}".format(ext, frontend)
                               for ext, frontend in FRONTENDS_BY_EXTENSION.items())
    FRONTEND_CHOICES = sorted(PIPELINES.keys())
    in_.add_argument("--frontend", default=None, choices=FRONTEND_CHOICES,
                     help=FRONTEND_HELP)

    for language, drivers in core.DRIVERS_BY_LANGUAGE.items():
        DRIVER_HELP = "Choose which driver to use to execute {} proofs.".format(language)
        DRIVER_CHOICES = sorted(drivers)
        in_.add_argument("--{}-driver".format(language),
                         default=None, choices=DRIVER_CHOICES, help=DRIVER_HELP)

    out = parser.add_argument_group("Output configuration")

    BACKEND_HELP = "Choose a backend. Supported: "
    BACKEND_HELP += "; ".join(
        "{} → {{{}}}".format(frontend, ", ".join(sorted(backends)))
        for frontend, backends in PIPELINES.items())
    BACKEND_CHOICES = sorted(set(b for _, bs in PIPELINES.items() for b in bs))
    out.add_argument("--backend", default=None, choices=BACKEND_CHOICES,
                     help=BACKEND_HELP)

    OUT_FILE_HELP = "Set the output file (default: computed based on INPUT)."
    out.add_argument("-o", "--output", default=None,
                     help=OUT_FILE_HELP)

    OUT_DIR_HELP = "Set the output directory (default: same as each INPUT)."
    out.add_argument("--output-directory", default=None,
                     help=OUT_DIR_HELP)

    COPY_ASSETS_HELP = ("Chose the method to use to copy assets along the " +
                        "generated file(s) when creating webpages and TeX docs.")
    out.add_argument("--copy-assets", choices=list(COPY_FUNCTIONS.keys()),
                     default="copy", dest="copy_fn",
                     help=COPY_ASSETS_HELP)

    PYGMENTS_STYLE_HELP = "Choose a pygments style by name."
    out.add_argument("--pygments-style", default=None,
                     help=PYGMENTS_STYLE_HELP)

    MARK_POINT_HELP = "Mark a point in the output with a given marker."
    out.add_argument("--mark-point", nargs=2, default=(None, None),
                     metavar=("POINT", "MARKER"),
                     help=MARK_POINT_HELP)

    NO_HEADER_HELP = "Do not insert a header with usage instructions in webpages."
    out.add_argument("--no-header", action='store_false',
                     dest="include_banner", default=True,
                     help=NO_HEADER_HELP)

    NO_VERSION_NUMBERS = "Omit version numbers in meta tags and headers."
    out.add_argument("--no-version-numbers", action='store_false',
                     dest="include_vernums", default=True,
                     help=NO_VERSION_NUMBERS)

    cache_out = parser.add_argument_group("Cache configuration")

    CACHE_DIRECTORY_HELP = "Cache prover output in DIRECTORY."
    cache_out.add_argument("--cache-directory", default=None, metavar="DIRECTORY",
                           help=CACHE_DIRECTORY_HELP)

    CACHE_COMPRESSION_HELP = "Compress caches."
    CACHE_COMPRESSION_CHOICES = ("none", "gzip", "xz")
    cache_out.add_argument("--cache-compression", nargs='?',
                           default=None, const="xz",
                           choices=CACHE_COMPRESSION_CHOICES,
                           help=CACHE_COMPRESSION_HELP)

    html_out = parser.add_argument_group("HTML output configuration")

    WEBPAGE_STYLE_HELP = "Choose a style for standalone webpages."
    WEBPAGE_STYLE_CHOICES = ("centered", "floating", "windowed")
    html_out.add_argument("--webpage-style", default="centered",
                          choices=WEBPAGE_STYLE_CHOICES,
                          help=WEBPAGE_STYLE_HELP)

    HTML_MINIFICATION_HELP = (
        "Minify HTML files using backreferences for repeated content. "
        "(Backreferences are automatically expanded on page load,"
        " using a very small amount of JavaScript code.)"
    )
    html_out.add_argument("--html-minification", action='store_true',
                          default=False,
                          help=HTML_MINIFICATION_HELP)

    HTML_DIALECT_HELP = "Choose which HTML dialect to use."
    HTML_DIALECT_CHOICES = ("html4", "html5")
    html_out.add_argument("--html-dialect", default="html4",
                          choices=HTML_DIALECT_CHOICES,
                          help=HTML_DIALECT_HELP)

    latex_out = parser.add_argument_group("LaTeX output configuration")

    LATEX_DIALECT_HELP = "Choose which LaTeX dialect to use."
    LATEX_DIALECT_CHOICES = ("pdflatex", "xelatex", "lualatex")
    latex_out.add_argument("--latex-dialect", default="pdflatex",
                           choices=LATEX_DIALECT_CHOICES,
                           help=LATEX_DIALECT_HELP)

    subp = parser.add_argument_group("SerAPI process configuration")

    SERTOP_ARGS_HELP = ("Pass a single argument to SerAPI "
                        "(e.g. --sertop-arg=-Q --sertop-arg=dir,lib).")
    subp.add_argument("--sertop-arg", dest="sertop_args",
                      action="append", default=[],
                      metavar="SERTOP_ARG",
                      help=SERTOP_ARGS_HELP)

    COQC_ARGS_HELP = ("Pass a single argument to Rocq, "
                      "for use with the coqc_time and vsrocq drivers. "
                      "(e.g. --rocq-arg=-noinit).")
    subp.add_argument("--rocq-arg", "--coqc-arg", dest="coqc_args",
                      action="append", default=[],
                      metavar="COQC_ARG",
                      help=COQC_ARGS_HELP)

    I_HELP = "Pass -I DIR to Rocq subprocess."
    subp.add_argument("-I", "--ml-include-path", dest="coq_args_I",
                      metavar="DIR", nargs=1, action="append",
                      default=[], help=I_HELP)

    Q_HELP = "Pass -Q DIR COQDIR to Rocq subprocess."
    subp.add_argument("-Q", "--load-path", dest="coq_args_Q",
                      metavar=("DIR", "COQDIR"), nargs=2, action="append",
                      default=[], help=Q_HELP)

    R_HELP = "Pass -R DIR COQDIR to Rocq subprocess."
    subp.add_argument("-R", "--rec-load-path", dest="coq_args_R",
                      metavar=("DIR", "COQDIR"), nargs=2, action="append",
                      default=[], help=R_HELP)

    leanInkp = parser.add_argument_group("LeanInk configuration")

    LAKE_PATH_HELP = "Path to 'lakefile.lean' if necessary."
    leanInkp.add_argument("--lake", dest="leanInk_args_lake", metavar="LAKE_FILE",
                         default=None, help=LAKE_PATH_HELP)

    warn_out = parser.add_argument_group("Warnings configuration")

    LL_THRESHOLD_HELP = ("Warn on lines longer than this threshold "
                         "(docutils, 0 to turn off).")
    warn_out.add_argument("--long-line-threshold", type=int,
                          default=72, help=LL_THRESHOLD_HELP)

    debug = parser.add_argument_group("Debugging options")

    EXPECT_UNEXPECTED_HELP = "Ignore unexpected output from SerAPI."
    debug.add_argument("--expect-unexpected", action="store_true",
                       default=False, help=EXPECT_UNEXPECTED_HELP)

    DEBUG_HELP = "Print communications with prover process."
    debug.add_argument("--debug", action="store_true",
                       default=False, help=DEBUG_HELP)

    TRACEBACK_HELP = "Print error traces."
    debug.add_argument("--traceback", action="store_true",
                       default=False, help=TRACEBACK_HELP)

    return parser

def parse_arguments():
    parser = build_parser()
    return post_process_arguments(parser, parser.parse_args())


# Entry point
# ===========

class ExitCode:
    def __init__(self, n):
        self.val = n

def ctx_invoke(fn, ctx, *args):
    params = list(inspect.signature(fn).parameters.keys())[len(args):]
    return fn(*args, **{p: ctx[p] for p in params})

def call_pipeline_step(step, state, ctx):
    return ctx_invoke(step, ctx, state)

def build_context(fpath, args, frontend, backend):
    input_is_stdin = fpath == "-"

    if input_is_stdin:
        fpath = args.stdin_filename or fpath
    fname = os.path.basename(fpath)

    dialect = args.backend_dialects.get(backend)

    driver_configs = {
        lang: core.DriverConfig(lang, args.language_drivers, args.driver_args_by_name)
        for lang in core.ALL_LANGUAGES
    }

    input_language = INPUT_LANGUAGE_BY_FRONTEND.get(frontend)

    ctx = {**vars(args),
           "fpath": fpath, "fname": fname, "input_is_stdin": input_is_stdin,
           "frontend": frontend, "backend": backend, "dialect": dialect,
           "input_language": input_language, "driver_configs": driver_configs,
           "assets": [], "html_classes": [], "exit_code": ExitCode(0)}
    ctx["ctx"] = ctx

    if args.output_directory is None:
        if input_is_stdin:
            ctx["output_directory"] = "."
        else:
            refpath = fpath if args.output in (None, "-") else args.output
            ctx["output_directory"] = os.path.dirname(os.path.abspath(refpath))

    os.makedirs(os.path.abspath(ctx["output_directory"]), exist_ok=True)

    if args.output is None and input_is_stdin:
        ctx["output"] = "-"

    return ctx

def except_hook(etype, value, tb):
    from traceback import TracebackException
    for line in TracebackException(etype, value, tb, capture_locals=True).format():
        print(line, file=sys.stderr)

def run_pipeline(pipeline, state, ctx):
    for step in pipeline:
        state = call_pipeline_step(step, state, ctx)
    return state

def process_pipelines(args):
    if args.debug:
        core.DEBUG = True

    if args.traceback:
        core.TRACEBACK = True
        sys.excepthook = except_hook

    if args.expect_unexpected:
        from . import serapi
        serapi.SerAPI.EXPECT_UNEXPECTED = True

    for fpath, frontend, backend, pipeline in args.pipelines:
        ctx = build_context(fpath, args, frontend, backend)
        run_pipeline(pipeline, None, ctx)
        yield ctx["exit_code"].val

def main():
    try:
        args = parse_arguments()
        sys.exit(max(process_pipelines(args), default=0))
    except DocutilsException as e:
        print(e, file=sys.stderr)
        sys.exit(1)
    except (ValueError, FileNotFoundError, ImportError, argparse.ArgumentTypeError) as e:
        if core.TRACEBACK:
            raise
        MSG = "Exiting early due to an error; use --traceback to diagnose:"
        print(MSG, file=sys.stderr)
        print(core.indent(str(e), "  "), file=sys.stderr)
        sys.exit(1)

# Alternative CLIs
# ================

def rstcoq2html():
    """Docutils entry point for Coq → HTML conversion."""
    DESCRIPTION = 'Build an HTML document from an Alectryon Coq file.'
    return _docutils_cmdline(DESCRIPTION, "coq+rst", "webpage", "html4")

def coqrst2html():
    """Docutils entry point for reST → HTML conversion."""
    DESCRIPTION = 'Build an HTML document from an Alectryon reStructuredText file.'
    return _docutils_cmdline(DESCRIPTION, "rst", "webpage", "html4")

def rstcoq2latex():
    """Docutils entry point for Coq → LaTeX conversion."""
    DESCRIPTION = 'Build a LaTeX document from an Alectryon Coq file.'
    return _docutils_cmdline(DESCRIPTION, "coq+rst", "latex", "pdflatex")

def coqrst2latex():
    """Docutils entry point for reST → LaTeX conversion."""
    DESCRIPTION = 'Build a LaTeX document from an Alectryon reStructuredText file.'
    return _docutils_cmdline(DESCRIPTION, "rst", "latex", "pdflatex")
