# Copyright © 2021 Niklas Bülow
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from typing import Any, List

import tempfile
import os
from pathlib import Path

from . import json
from .json import PlainSerializer
from .core import CLIDriver, UTF8Document, Text, Fragment


class Lean4(CLIDriver):
    BIN = "leanInk"
    NAME = "Lean4"

    VERSION_ARGS = ("lV",)

    ID = "leanInk"
    LANGUAGE = "lean4"
    AUTOSELECT = True

    CLI_ARGS = ("analyze",)

    TMP_PREFIX = "leanInk_"
    LEAN_FILE_EXT = ".lean"
    LEAN_INK_FILE_EXT = ".leanInk"
    LAKE_ENV_KEY = "--lake"
    LAKE_TMP_FILE_PATH = "lakefile.lean"

    def __init__(self, args=(), fpath="-", binpath=None):
        super().__init__(args=args, fpath=fpath, binpath=binpath)

    def run_leanInk_document(self, document: UTF8Document) -> List[Any]:
        """Run LeanInk with `document`."""
        with tempfile.TemporaryDirectory(prefix=self.TMP_PREFIX) as temp_directory:
            input_file_name = self.fpath.with_suffix(self.LEAN_FILE_EXT)
            input_file = Path(temp_directory) / os.path.basename(input_file_name)
            input_file.write_bytes(document.bytes)
            working_directory = temp_directory

            try:
                lakefile_idx = self.user_args.index("--lake") + 1
            except ValueError:
                self.user_args += ("--lake", self.LAKE_TMP_FILE_PATH)
                lakefile_idx = -1
            working_directory = os.path.dirname(
                os.path.realpath(self.user_args[lakefile_idx])
            )

            input_file_path = str(os.path.abspath(input_file))
            self.run_cli(
                cwd=working_directory,
                capture_output=False,
                more_args=[input_file_path],
            )

            output_file = input_file.with_suffix(
                self.LEAN_FILE_EXT + self.LEAN_INK_FILE_EXT
            )
            content = output_file.read_text(encoding="utf-8")
            json_result = json.loads(content)
            tuple_result = PlainSerializer.decode(json_result)
            assert isinstance(tuple_result, list)
            return tuple_result

    def annotate(self, chunks: list[str]):
        """Annotate a Lean 4 file."""
        document = UTF8Document(chunks, "\n")
        result: List[Fragment] = self.run_leanInk_document(document)

        if not result:
            return list([])

        # Sometimes we require an additional \n and sometimes not. I wasn't really able to
        # find out exactly when, but this workaround seems to work for almost all cases.
        if not result[-1].contents.endswith("\n"):
            result = result + [Text(contents="\n")]
        return list(document.recover_chunks(result))
