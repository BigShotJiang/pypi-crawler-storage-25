from .page import Base, Page

__all__ = ["Base", "Page"]
