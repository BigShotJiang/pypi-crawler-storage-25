from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, field_validator

MAX_EXPIRES_IN_MINUTES = 60 * 24 * 7  # 7 days


class PageCreate(BaseModel):
    html: str = Field(..., min_length=0, max_length=10 * 1024 * 1024)
    title: str | None = Field(default=None, max_length=200)
    password: str | None = Field(default=None, max_length=128)
    expires_in: int | None = Field(default=None)
    parent_slug: str | None = Field(default=None, min_length=4, max_length=12)
    sandbox_mode: Literal["strict", "relaxed"] = "strict"

    @field_validator("expires_in")
    @classmethod
    def _check_expires_in(cls, v: int | None) -> int | None:
        if v is None:
            return v
        if v < 1:
            raise ValueError("expires_in must be at least 1 minute")
        if v > MAX_EXPIRES_IN_MINUTES:
            raise ValueError("max expiration is 7 days (10080 minutes)")
        return v


class PageUpdate(BaseModel):
    html: str = Field(..., min_length=0, max_length=10 * 1024 * 1024)
    title: str | None = Field(default=None, max_length=200)


class PageCreateResponse(BaseModel):
    slug: str
    url: str
    owner_key: str
    expires_at: datetime | None
    created_at: datetime


class PageMetadata(BaseModel):
    slug: str
    title: str | None
    url: str
    expires_at: datetime | None
    created_at: datetime
    updated_at: datetime
    view_count: int
    size_bytes: int
    has_password: bool
    parent_slug: str | None


class PageUpdateResponse(BaseModel):
    slug: str
    url: str
    expires_at: datetime | None
    updated_at: datetime
