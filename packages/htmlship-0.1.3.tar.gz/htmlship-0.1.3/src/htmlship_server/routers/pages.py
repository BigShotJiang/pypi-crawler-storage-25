from __future__ import annotations

from datetime import UTC, datetime, timedelta

from fastapi import APIRouter, Depends, Header, HTTPException, Request, Response, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import Settings, get_settings
from ..database import get_session
from ..db_models.page import Page
from ..schemas.pages import (
    PageCreate,
    PageCreateResponse,
    PageMetadata,
    PageUpdate,
    PageUpdateResponse,
)
from ..security import (
    generate_owner_key,
    hash_owner_key,
    hash_password,
    verify_owner_key,
)
from ..slugs import generate_unique_slug
from ..storage import get_blob_store, make_blob_key

router = APIRouter(prefix="/api/v1")


def _view_url(settings: Settings, slug: str) -> str:
    return f"{settings.view_base_url.rstrip('/')}/{slug}"


async def _slug_exists(session: AsyncSession, slug: str) -> bool:
    res = await session.execute(select(Page.id).where(Page.slug == slug))
    return res.first() is not None


async def _load_active(session: AsyncSession, slug: str) -> Page:
    res = await session.execute(select(Page).where(Page.slug == slug))
    page = res.scalar_one_or_none()
    if page is None or page.deleted_at is not None:
        raise HTTPException(status_code=404, detail="page not found")
    if page.expires_at is not None and page.expires_at <= datetime.now(UTC):
        raise HTTPException(status_code=404, detail="page expired")
    return page


def _require_owner_key(x_owner_key: str | None) -> str:
    if not x_owner_key:
        raise HTTPException(status_code=401, detail="missing X-Owner-Key header")
    return x_owner_key


@router.post(
    "/pages",
    status_code=status.HTTP_201_CREATED,
    response_model=PageCreateResponse,
)
async def create_page(
    payload: PageCreate,
    request: Request,
    settings: Settings = Depends(get_settings),
    session: AsyncSession = Depends(get_session),
) -> PageCreateResponse:
    return await _create_page_impl(
        payload=payload,
        parent_override=payload.parent_slug,
        settings=settings,
        session=session,
    )


@router.post(
    "/pages/{slug}/version",
    status_code=status.HTTP_201_CREATED,
    response_model=PageCreateResponse,
)
async def create_version(
    slug: str,
    payload: PageCreate,
    settings: Settings = Depends(get_settings),
    session: AsyncSession = Depends(get_session),
) -> PageCreateResponse:
    parent = await _load_active(session, slug)
    return await _create_page_impl(
        payload=payload,
        parent_override=parent.slug,
        settings=settings,
        session=session,
    )


async def _create_page_impl(
    *,
    payload: PageCreate,
    parent_override: str | None,
    settings: Settings,
    session: AsyncSession,
) -> PageCreateResponse:
    html_bytes = payload.html.encode("utf-8")
    if len(html_bytes) > settings.max_payload_bytes:
        raise HTTPException(status_code=413, detail="html exceeds size limit")

    if parent_override and parent_override != payload.parent_slug:
        # Path version takes precedence; verify it exists
        await _load_active(session, parent_override)

    async def exists(s: str) -> bool:
        return await _slug_exists(session, s)

    slug = await generate_unique_slug(exists)

    owner_key = generate_owner_key()
    owner_hash = hash_owner_key(owner_key)
    pwd_hash = hash_password(payload.password) if payload.password else None

    expires_at: datetime | None = None
    if payload.expires_in is not None:
        expires_at = datetime.now(UTC) + timedelta(minutes=payload.expires_in)
    elif settings.default_expires_in_minutes:
        expires_at = datetime.now(UTC) + timedelta(minutes=settings.default_expires_in_minutes)

    page = Page(
        slug=slug,
        blob_key="",  # set after we know the id
        title=payload.title,
        owner_key_hash=owner_hash,
        password_hash=pwd_hash,
        sandbox_mode=payload.sandbox_mode,
        expires_at=expires_at,
        size_bytes=len(html_bytes),
        parent_slug=parent_override,
    )
    session.add(page)
    await session.flush()

    blob_key = make_blob_key(page.id)
    page.blob_key = blob_key

    store = get_blob_store()
    await store.put(blob_key, html_bytes)

    await session.commit()
    await session.refresh(page)

    return PageCreateResponse(
        slug=page.slug,
        url=_view_url(settings, page.slug),
        owner_key=owner_key,
        expires_at=page.expires_at,
        created_at=page.created_at,
    )


@router.get("/pages/{slug}", response_model=PageMetadata)
async def get_page_metadata(
    slug: str,
    settings: Settings = Depends(get_settings),
    session: AsyncSession = Depends(get_session),
) -> PageMetadata:
    page = await _load_active(session, slug)
    return PageMetadata(
        slug=page.slug,
        title=page.title,
        url=_view_url(settings, page.slug),
        expires_at=page.expires_at,
        created_at=page.created_at,
        updated_at=page.updated_at,
        view_count=page.view_count,
        size_bytes=page.size_bytes,
        has_password=page.password_hash is not None,
        parent_slug=page.parent_slug,
    )


@router.patch("/pages/{slug}", response_model=PageUpdateResponse)
async def update_page(
    slug: str,
    payload: PageUpdate,
    x_owner_key: str | None = Header(default=None, alias="X-Owner-Key"),
    settings: Settings = Depends(get_settings),
    session: AsyncSession = Depends(get_session),
) -> PageUpdateResponse:
    owner_key = _require_owner_key(x_owner_key)
    page = await _load_active(session, slug)
    if not verify_owner_key(owner_key, page.owner_key_hash):
        raise HTTPException(status_code=403, detail="invalid owner key")

    html_bytes = payload.html.encode("utf-8")
    if len(html_bytes) > settings.max_payload_bytes:
        raise HTTPException(status_code=413, detail="html exceeds size limit")

    page.size_bytes = len(html_bytes)
    if payload.title is not None:
        page.title = payload.title

    store = get_blob_store()
    await store.put(page.blob_key, html_bytes)

    await session.commit()
    await session.refresh(page)

    return PageUpdateResponse(
        slug=page.slug,
        url=_view_url(settings, page.slug),
        expires_at=page.expires_at,
        updated_at=page.updated_at,
    )


@router.delete(
    "/pages/{slug}",
    status_code=status.HTTP_204_NO_CONTENT,
    response_class=Response,
)
async def delete_page(
    slug: str,
    x_owner_key: str | None = Header(default=None, alias="X-Owner-Key"),
    session: AsyncSession = Depends(get_session),
) -> Response:
    owner_key = _require_owner_key(x_owner_key)
    page = await _load_active(session, slug)
    if not verify_owner_key(owner_key, page.owner_key_hash):
        raise HTTPException(status_code=403, detail="invalid owner key")
    page.deleted_at = datetime.now(UTC)
    store = get_blob_store()
    try:
        await store.delete(page.blob_key)
    except Exception:
        pass
    await session.commit()
    return Response(status_code=204)
