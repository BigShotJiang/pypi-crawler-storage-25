from __future__ import annotations


class StorageError(Exception):
    """Raised when the blob store fails."""


class PageNotFoundError(Exception):
    pass
