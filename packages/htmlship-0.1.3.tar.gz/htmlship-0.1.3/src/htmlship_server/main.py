from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse, HTMLResponse, Response
from starlette.staticfiles import StaticFiles

from . import __version__
from .config import get_settings
from .middleware import HostRoutingMiddleware
from .routers import meta, pages, view


@asynccontextmanager
async def lifespan(app: FastAPI):
    yield


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title="HTMLShip",
        version=__version__,
        description="Host and share HTML pages in one line.",
        lifespan=lifespan,
        docs_url="/api/docs" if settings.environment != "production" else None,
        redoc_url=None,
        openapi_url="/api/openapi.json" if settings.environment != "production" else None,
    )

    app.include_router(meta.router)
    app.include_router(pages.router)

    # Landing-page static assets, served from /static/* on landing/api hosts.
    web_dir = Path(__file__).resolve().parents[2] / "web"
    if web_dir.is_dir():
        app.mount("/static", StaticFiles(directory=str(web_dir)), name="static")

        @app.get("/", include_in_schema=False)
        async def landing_root() -> Response:
            index = web_dir / "index.html"
            if not index.is_file():
                return HTMLResponse("HTMLShip", status_code=200)
            return FileResponse(index, media_type="text/html")

        @app.get("/styles.css", include_in_schema=False)
        async def landing_css() -> Response:
            return FileResponse(web_dir / "styles.css", media_type="text/css")

        @app.get("/demo.js", include_in_schema=False)
        async def landing_js() -> Response:
            return FileResponse(web_dir / "demo.js", media_type="application/javascript")

    # The view router last so that /{slug} doesn't shadow the landing routes above.
    app.include_router(view.router)

    app.add_middleware(
        HostRoutingMiddleware,
        view_host=settings.view_host,
        api_host=settings.api_host,
        landing_host=settings.public_base_domain,
    )

    return app


app = create_app()
