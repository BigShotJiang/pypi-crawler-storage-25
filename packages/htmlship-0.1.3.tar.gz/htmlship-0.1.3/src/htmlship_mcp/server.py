"""HTMLShip MCP server.

Exposes three tools — publish_html, fetch_html, update_html — that wrap the
public Python library. All HTTP traffic goes through the library and the
real API; this server adds no business logic of its own.

Configure the API endpoint via the HTMLSHIP_API_URL environment variable.
"""
from __future__ import annotations

import os
from typing import Any

from mcp.server.fastmcp import FastMCP

import htmlship
from htmlship.exceptions import AuthError, HTMLShipError, NotFoundError

mcp = FastMCP("htmlship")


def _client() -> htmlship.HTMLShipClient:
    base_url = os.getenv("HTMLSHIP_API_URL")
    return htmlship.HTMLShipClient(base_url=base_url)


@mcp.tool()
def publish_html(
    html: str,
    title: str | None = None,
    expires_in: int | None = None,
) -> dict[str, Any]:
    """Publish an HTML document and get a public URL.

    Args:
        html: The HTML body to publish. May include inline CSS but scripts will
            be blocked by Content Security Policy at view time.
        title: Optional human-readable title.
        expires_in: Optional TTL in minutes (1–10080, i.e. up to 7 days). If
            omitted, the page is permanent (subject to the server's default
            policy).

    Returns:
        A dict with keys: url, slug, owner_key, expires_at.
        IMPORTANT: owner_key is the only credential to update or delete the
        page later. Save it.
    """
    with _client() as c:
        try:
            page = c.publish(html, title=title, expires_in=expires_in)
        except HTMLShipError as exc:
            raise RuntimeError(f"htmlship publish failed: {exc}") from exc
    return {
        "url": page.url,
        "slug": page.slug,
        "owner_key": page.owner_key,
        "expires_at": page.expires_at.isoformat() if page.expires_at else None,
    }


@mcp.tool()
def fetch_html(slug: str) -> dict[str, Any]:
    """Fetch a page's metadata.

    NOTE: this returns metadata only. To view the rendered HTML, open the
    `url` in a browser — the content is served from a sandboxed subdomain.

    Args:
        slug: The page's short identifier.
    """
    with _client() as c:
        try:
            page = c.get(slug)
        except NotFoundError as exc:
            raise RuntimeError(f"page '{slug}' not found") from exc
        except HTMLShipError as exc:
            raise RuntimeError(f"htmlship fetch failed: {exc}") from exc
    return {
        "slug": page.slug,
        "url": page.url,
        "title": page.title,
        "view_count": page.view_count,
        "size_bytes": page.size_bytes,
        "has_password": page.has_password,
        "parent_slug": page.parent_slug,
        "expires_at": page.expires_at.isoformat() if page.expires_at else None,
        "created_at": page.created_at.isoformat() if page.created_at else None,
        "updated_at": page.updated_at.isoformat() if page.updated_at else None,
    }


@mcp.tool()
def update_html(slug: str, html: str, owner_key: str, title: str | None = None) -> dict[str, Any]:
    """Replace the HTML for an existing page. Requires the original owner_key.

    Args:
        slug: The page's short identifier.
        html: The new HTML body.
        owner_key: The owner key returned at publish time.
        title: Optional new title.
    """
    with _client() as c:
        try:
            page = c.update(slug, html, owner_key=owner_key, title=title)
        except AuthError as exc:
            raise RuntimeError(f"invalid owner_key for '{slug}'") from exc
        except NotFoundError as exc:
            raise RuntimeError(f"page '{slug}' not found") from exc
        except HTMLShipError as exc:
            raise RuntimeError(f"htmlship update failed: {exc}") from exc
    return {
        "url": page.url,
        "slug": page.slug,
        "updated_at": page.updated_at.isoformat() if page.updated_at else None,
    }


def main() -> None:
    """Entry point for the `htmlship-mcp` console script (stdio transport)."""
    mcp.run()


if __name__ == "__main__":
    main()
