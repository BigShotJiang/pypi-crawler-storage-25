from __future__ import annotations


class HTMLShipError(Exception):
    """Base class for all HTMLShip client errors."""


class NotFoundError(HTMLShipError):
    """Returned when a page does not exist or has expired."""


class AuthError(HTMLShipError):
    """Owner key missing or invalid."""


class RateLimitError(HTMLShipError):
    """Server returned 429."""

    def __init__(self, message: str, retry_after: float | None = None):
        super().__init__(message)
        self.retry_after = retry_after


class APIError(HTMLShipError):
    """Server returned a non-2xx response that doesn't fit a more specific class."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code
