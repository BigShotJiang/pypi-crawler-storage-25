"""HTMLShip — host and share HTML in one line.

Quick start:

    import htmlship
    page = htmlship.publish("<h1>Hello</h1>", expires_in=60)  # minutes
    print(page.url)
    print(page.owner_key)

    page.update("<h1>Hello, again</h1>")
    page.delete()

Configuration via environment:
    HTMLSHIP_API_URL   (default: https://api.htmlship.com)
    HTMLSHIP_API_KEY   (optional; reserved for future use)
"""
from __future__ import annotations

from ._version import __version__
from .client import HTMLShipClient
from .exceptions import (
    APIError,
    AuthError,
    HTMLShipError,
    NotFoundError,
    RateLimitError,
)
from .models import Page

_default_client: HTMLShipClient | None = None


def _get_default_client() -> HTMLShipClient:
    global _default_client
    if _default_client is None:
        _default_client = HTMLShipClient()
    return _default_client


def configure(
    *,
    base_url: str | None = None,
    api_key: str | None = None,
) -> HTMLShipClient:
    """Replace the module-level default client.

    Useful when you want to point at a different API URL without setting env vars.
    """
    global _default_client
    if _default_client is not None:
        _default_client.close()
    _default_client = HTMLShipClient(base_url=base_url, api_key=api_key)
    return _default_client


def publish(
    html: str,
    *,
    title: str | None = None,
    password: str | None = None,
    expires_in: int | None = None,
    parent_slug: str | None = None,
    sandbox_mode: str = "strict",
) -> Page:
    """Publish HTML. ``expires_in`` is in minutes (max 10080 = 7 days)."""
    return _get_default_client().publish(
        html,
        title=title,
        password=password,
        expires_in=expires_in,
        parent_slug=parent_slug,
        sandbox_mode=sandbox_mode,
    )


def get(slug: str) -> Page:
    return _get_default_client().get(slug)


def update(slug: str, html: str, *, owner_key: str, title: str | None = None) -> Page:
    return _get_default_client().update(slug, html, owner_key=owner_key, title=title)


def delete(slug: str, *, owner_key: str) -> None:
    return _get_default_client().delete(slug, owner_key=owner_key)


__all__ = [
    "__version__",
    "HTMLShipClient",
    "Page",
    "HTMLShipError",
    "NotFoundError",
    "AuthError",
    "RateLimitError",
    "APIError",
    "configure",
    "publish",
    "get",
    "update",
    "delete",
]
