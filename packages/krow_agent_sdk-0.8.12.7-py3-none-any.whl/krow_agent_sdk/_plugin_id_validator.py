"""Plugin ID 双段命名校验（design doc §5.0.5 / 顶级 review A8 + D4）。

约束：``plugin_id = "<org>.<plugin_name>"``

- ``<org>``：全小写 ``[a-z0-9_-]``，3-20 字符
- ``.`` 必须用点分隔
- ``<plugin_name>``：全小写 snake_case ``[a-z0-9_]``，3-30 字符
"""
from __future__ import annotations

import re
from typing import Final

from .errors import InvalidPluginIDError

PLUGIN_ID_PATTERN: Final[re.Pattern[str]] = re.compile(
    r"^[a-z0-9_\-]{3,20}\.[a-z0-9_]{3,30}$"
)


def validate_plugin_id(plugin_id: str) -> None:
    """启动期 plugin_id 校验，违反 fail-loud。

    Args:
        plugin_id: plugin 自报的全局 ID

    Raises:
        InvalidPluginIDError: 格式不符合 ``<org>.<plugin_name>`` 双段规范
    """
    if not isinstance(plugin_id, str):
        raise InvalidPluginIDError(plugin_id=repr(plugin_id))
    if not PLUGIN_ID_PATTERN.match(plugin_id):
        raise InvalidPluginIDError(plugin_id=plugin_id)


def split_plugin_id(plugin_id: str) -> tuple[str, str]:
    """拆出 ``(org, plugin_name)``，先校验。"""
    validate_plugin_id(plugin_id)
    org, name = plugin_id.split(".", 1)
    return org, name
