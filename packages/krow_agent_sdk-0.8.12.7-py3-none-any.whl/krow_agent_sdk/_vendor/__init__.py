"""SDK vendor stub modules（M6 / 1B 决策落地）.

这个子包**只**为了支持 ``from krow_agent_sdk import AgentBuilder`` 在
没装 ``krow-agent-sdk-runtime`` 的干净 venv 里也能成功 import.

包含的 stub 都是 thin dataclass / ABC / 常量定义，**无业务算法**，
公开它们不会泄露核心 IP（详 ``docs/sdk/source-protection-design.md`` §1.2）.

Stub 与真实 ``modules.ai.providers`` / ``modules.agent.visual.protocol`` 的
关系：

- runtime 装上后：``from modules.ai.providers import ChatMessage`` 直接
  命中真实（runtime 安装的 .so/.py 优先于 wheel 内 stub）
- runtime 没装时：sdk 的 ``llm.py`` / ``visual.py`` try-except fallback
  到 vendor stub，至少保证 import + plugin 单元测试可跑

设计依据：``docs/sdk/source-protection-design.md`` §3 (D1 = 1B).
"""
