"""Visual Grounding Protocol stub —— 数据模型 + ``VisualAdapter`` 抽象接口.

完整文档：``modules/agent/sdk/_vendor/__init__.py``.

来源：``modules/agent/visual/protocol.py``（仅 thin dataclass + ABC + 常量，
不含业务算法）.

**M6 1B 决策**：复制到 wheel 让公开 wheel 自包含.外部团队基于此 stub
即可写自己的 ``VisualAdapter`` 子类 + plugin（详 ``docs/sdk/quickstart.md`` §7.1）.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from contextlib import contextmanager
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Dict, FrozenSet, List, Optional, Tuple


CONFIDENCE_THRESHOLD = 0.4

FILLABLE_ROLES = frozenset({"title", "subtitle", "body", "bullet_list"})
PRESERVE_ROLES = frozenset({"decoration", "nav", "logo", "page_number"})
ALL_ROLES = frozenset({
    "title", "subtitle", "body", "bullet_list",
    "image_area", "chart_area", "nav",
    "decoration", "page_number", "logo",
})


@dataclass(frozen=True)
class SceneConfig:
    """场景特定的 VG 配置 — 由 ``VisualAdapter`` 子类通过 ``scene_config`` 属性提供.

    ``frozen=True`` 保证线程安全：多个 VLM 工作线程可安全共享同一实例.
    """
    grounding_prompt_template: str
    verify_prompt_template: str
    valid_roles: FrozenSet[str]
    fillable_roles: FrozenSet[str]
    preserve_roles: FrozenSet[str]
    issue_patterns: Dict[str, str]
    grounding_max_tokens: int = 2000
    verify_max_tokens: int = 800

    def __post_init__(self):
        if isinstance(self.issue_patterns, dict) and \
           not isinstance(self.issue_patterns, MappingProxyType):
            object.__setattr__(
                self, "issue_patterns", MappingProxyType(self.issue_patterns),
            )

    def validate(self) -> List[str]:
        errors = []
        if "{inventory_table}" not in self.grounding_prompt_template:
            errors.append("grounding_prompt_template 缺少 {inventory_table}")
        if "{expectation}" not in self.verify_prompt_template:
            errors.append("verify_prompt_template 缺少 {expectation}")
        if not self.fillable_roles.issubset(self.valid_roles):
            errors.append(f"fillable_roles 溢出: {self.fillable_roles - self.valid_roles}")
        if not self.preserve_roles.issubset(self.valid_roles):
            errors.append(f"preserve_roles 溢出: {self.preserve_roles - self.valid_roles}")
        if self.fillable_roles & self.preserve_roles:
            errors.append(f"fillable/preserve 重叠: {self.fillable_roles & self.preserve_roles}")
        return errors


@dataclass
class ElementEntry:
    """结构化元素条目 — inventory 输出单元."""
    element_id: str
    element_type: str
    bbox: Tuple[float, float, float, float]
    content_preview: str
    ph_type: Optional[str]
    ph_idx: Optional[int]
    z_order: int
    area_pt2: float
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class SemanticRole:
    """语义角色 — ground 输出的单个映射."""
    role: str
    element_ids: List[str]
    confidence: float
    description: str

    def to_dict(self) -> dict:
        return {
            "role": self.role,
            "element_ids": self.element_ids,
            "confidence": self.confidence,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "SemanticRole":
        return cls(
            role=d.get("role", "unknown"),
            element_ids=d.get("element_ids", []),
            confidence=float(d.get("confidence", 0)),
            description=d.get("description", ""),
        )


@dataclass
class SemanticMap:
    """语义映射 — 单页的完整语义理解."""
    page_index: int
    roles: List[SemanticRole]
    layout_description: str
    raw_vlm_response: str = ""

    def get_ids_by_role(self, role: str) -> List[str]:
        for r in self.roles:
            if r.role == role:
                return list(r.element_ids)
        return []

    def get_fillable_ids(self) -> List[str]:
        ids: List[str] = []
        for r in self.roles:
            if r.role in FILLABLE_ROLES:
                ids.extend(r.element_ids)
        return ids

    def get_preserve_ids(self) -> List[str]:
        ids: List[str] = []
        for r in self.roles:
            if r.role in PRESERVE_ROLES:
                ids.extend(r.element_ids)
        return ids

    def to_dict(self) -> dict:
        return {
            "page_index": self.page_index,
            "roles": [r.to_dict() for r in self.roles],
            "layout_description": self.layout_description,
            "raw_vlm_response": self.raw_vlm_response,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "SemanticMap":
        roles = [SemanticRole.from_dict(r) for r in d.get("roles", [])]
        return cls(
            page_index=d.get("page_index", 0),
            roles=roles,
            layout_description=d.get("layout_description", ""),
            raw_vlm_response=d.get("raw_vlm_response", ""),
        )

    @classmethod
    def empty(cls, page_index: int, reason: str = "") -> "SemanticMap":
        return cls(
            page_index=page_index,
            roles=[],
            layout_description=reason or "空",
            raw_vlm_response="",
        )


@dataclass
class VisualGroundingResult:
    """完整的 Visual Grounding 结果（可缓存）."""
    source_path: str
    source_mtime: float
    pages: List[SemanticMap]
    generated_at: str
    vlm_model: str
    version: str = "1.0"

    def to_dict(self) -> dict:
        return {
            "version": self.version,
            "source_path": self.source_path,
            "source_mtime": self.source_mtime,
            "generated_at": self.generated_at,
            "vlm_model": self.vlm_model,
            "pages": [p.to_dict() for p in self.pages],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "VisualGroundingResult":
        pages = [SemanticMap.from_dict(p) for p in d.get("pages", [])]
        return cls(
            source_path=d.get("source_path", ""),
            source_mtime=d.get("source_mtime", 0.0),
            generated_at=d.get("generated_at", ""),
            vlm_model=d.get("vlm_model", ""),
            pages=pages,
            version=d.get("version", "1.0"),
        )


class VisualAdapter(ABC):
    """视觉适配器接口 — 每个场景实现一个.

    调用者通过 ``open`` / ``close`` 管理资源生命周期.推荐用 ``open_adapter``
    上下文管理器.

    v0.9.x (2026-05-15) · OCP class attr 扩展点（与 ``modules/agent/visual/
    protocol.py`` 上游 SSOT 对齐 / SDK vendor 同步）：

    - ``RENDER_SOURCE``：渲染来源标识（``"qgraphics-desktop"`` /
      ``"cairosvg-pisma-svg"`` 等），供 prompt 透明性 + 测试断言使用
    - ``RENDER_FIDELITY_CLASS``：保真度分级（``"pixel_match"`` /
      ``"geometry_match"`` / ``"layout_only"``）

    子类可选 override；不 override 时使用基类默认值.
    """

    RENDER_SOURCE: str = "unknown"
    RENDER_FIDELITY_CLASS: str = "geometry_match"

    @abstractmethod
    def open(self, source: Any, **kwargs: Any) -> None:
        ...

    @abstractmethod
    def close(self) -> None:
        ...

    @abstractmethod
    def render(self, page_index: int,
               width: int = 960, height: int = 540) -> bytes:
        ...

    @abstractmethod
    def inventory(self, page_index: int) -> List[ElementEntry]:
        ...

    @abstractmethod
    def page_count(self) -> int:
        ...

    @property
    def scene_config(self) -> Optional[SceneConfig]:
        return None


@contextmanager
def open_adapter(adapter_cls, source):
    """上下文管理器 — 确保 ``open`` / ``close`` 配对.

    Usage::

        with open_adapter(PPTXVisualAdapter, "path.pptx") as adapter:
            img = adapter.render(0)
    """
    adapter = adapter_cls()
    adapter.open(source)
    try:
        yield adapter
    finally:
        adapter.close()


__all__ = [
    "CONFIDENCE_THRESHOLD",
    "FILLABLE_ROLES",
    "PRESERVE_ROLES",
    "ALL_ROLES",
    "SceneConfig",
    "ElementEntry",
    "SemanticRole",
    "SemanticMap",
    "VisualGroundingResult",
    "VisualAdapter",
    "open_adapter",
]
