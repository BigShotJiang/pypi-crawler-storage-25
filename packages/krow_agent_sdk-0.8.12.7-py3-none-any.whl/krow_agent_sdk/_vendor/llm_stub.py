"""LLM stub —— ``ChatMessage`` / ``LLMSourceModule`` / ``llm_source_context``.

完整文档：``modules/agent/sdk/_vendor/__init__.py``.

来源：``modules/ai/providers.py``（仅 thin dataclass + 常量类 +
contextmanager wrapper，不含业务算法）.

**M6 1B 决策**：复制到 wheel 让公开 wheel 自包含.
"""
from __future__ import annotations

import contextvars
from dataclasses import dataclass


@dataclass
class ChatMessage:
    """LLM chat message.

    ``role``：``"user"`` / ``"system"`` / ``"assistant"`` / ``"tool"``。
    ``content``：消息文本（multi-modal 用 list[dict]，但 SDK 公开层不要求）.
    """
    role: str
    content: str


class LLMSourceModule:
    """LLM 调用的源模块常量集（vendor stub）.

    与 ``modules.ai.providers.LLMSourceModule`` 的常量值**完全一致**，
    runtime 装上后直接命中真实类（值兼容，可互换）.
    """

    ORCHESTRATOR = "编排器"
    INPUT_REFINER = "输入优化器"
    PLANNER = "规划器"
    EXECUTOR = "执行器"
    EVALUATOR = "评估器"
    REACT_THINKER = "推理器"

    AI_MANAGER = "AI管理器"
    TASK_MANAGER = "任务管理器"
    TOOL_MANAGER = "工具管理器"

    MEMORY = "记忆器"
    EXPERIENCE_MEMORY = "经验记忆"
    KNOWLEDGE_GRAPH = "知识库"
    ANALYZER = "分析器"

    SUMMARY_REPORT = "总结报告"

    SEMANTIC_DECISION = "语义决策"
    SEMANTIC_EVALUATOR = "语义评估"
    EXPLORATORY_ANALYZER = "探索分析"
    SOLUTION_VERIFIER = "方案验证"

    CHAT = "对话"
    UNKNOWN = "未知"


_llm_source_module: contextvars.ContextVar[str] = contextvars.ContextVar(
    "llm_source_module",
    default=LLMSourceModule.UNKNOWN,
)


def set_llm_source_module(module: str) -> contextvars.Token:
    return _llm_source_module.set(module)


def reset_llm_source_module(token: contextvars.Token) -> None:
    _llm_source_module.reset(token)


def get_llm_source_module() -> str:
    return _llm_source_module.get()


class llm_source_context:
    """LLM 源模块上下文管理器（vendor stub）.

    Usage::

        with llm_source_context(LLMSourceModule.PLANNER):
            response = ai_manager.generate(...)
    """

    def __init__(self, module: str):
        self.module = module
        self.token: contextvars.Token | None = None

    def __enter__(self):
        self.token = set_llm_source_module(self.module)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.token is not None:
            reset_llm_source_module(self.token)
        return False


__all__ = [
    "ChatMessage",
    "LLMSourceModule",
    "llm_source_context",
    "set_llm_source_module",
    "reset_llm_source_module",
    "get_llm_source_module",
]
