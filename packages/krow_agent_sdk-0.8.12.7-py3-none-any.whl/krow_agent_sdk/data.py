"""krow_agent_sdk.data —— 只读数据层 facade（PR A2 / S1.14）

为外部 SDK 开发者提供 **只读** 访问 agent 内部数据层的入口：
- StateManager 状态机快照（todos / sub_states / current_session_id）
- GlobalOntologyStore（concepts / entities / events / relations / chunks / actions count + version）
- ExperienceMemory（query_memories / memory_stats）

设计原则：
1. **read-only**：facade 只读，不暴露任何写接口；底层 SSOT 仍归 main 仓 modules/{knowledge,agent}
2. **不抛异常**：失败时返回 ``{"error": "..."}`` dict（与 ``krow_agent_sdk.diagnostics`` 风格一致）
3. **不暴露内部对象**：序列化 OntologyObject / MemoryNode 为 plain dict（Pickle 安全；plugin 可
   pickle / json.dumps）
4. **零 LLM 调用**：所有读操作走 SQLite / 内存查询，不触发 reasoning
5. **零副作用**：不产生 EventBus 事件、不修改 _SDK_STATE、不持有底层对象引用

设计文档锚点：§5.10 / §6.6 / §9.1 S1.14。

## 公开 API

| 函数 | 用途 | 不抛异常 |
|---|---|---|
| ``get_state_snapshot(agent=None)`` | StateManager 全局/agent 状态摘要 | ✅ |
| ``get_global_ontology_snapshot(project_root=None)`` | GlobalOntology 6 类对象 count + version | ✅ |
| ``query_global_ontology(query, project_root=None, limit=10)`` | alias/label/definition 命中查询 | ✅ |
| ``get_memory_stats()`` | MemoryGraphService.get_stats 摘要 | ✅ |
| ``query_memories(query_text, limit=10, ...)`` | wakeup_sync 降级 + 序列化为 dict | ✅ |

## 反模式

- ❌ ``from krow_agent_sdk.data import GlobalOntologyStore`` 拿底层 store 直接调 ``add()`` —
  data facade 只暴露 read 函数，不暴露 store 实例
- ❌ 在 plugin 内 cache facade 返回的 dict 跨进程使用 — 非 stable schema，仅快照用途
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional, Union

if TYPE_CHECKING:
    from .builder import Agent

logger = logging.getLogger(__name__)


# ────────────────────────────────────────────────────────────────────────
# StateManager 快照
# ────────────────────────────────────────────────────────────────────────


def get_state_snapshot(agent: Optional["Agent"] = None) -> dict[str, Any]:
    """StateManager 状态机快照。
    
    返回 dict 结构：
        {
          "current_session_id": str | None,
          "current_task": dict | None,
          "todos_count": int,
          "todos": [{"id", "content", "status"}],  # 至多 50 条
          "sub_states_count": int,
          "is_initialized": bool,
        }
    
    Args:
        agent: 当前未使用（保留位置便于未来按 agent 实例隔离 StateManager）。
    
    不抛异常；失败返 ``{"error": "..."}``。
    """
    try:
        from modules.agent.state_manager import StateManager
    except ImportError as exc:
        return {"error": f"StateManager import failed: {exc}", "is_initialized": False}
    
    try:
        instance = StateManager.get_instance()
    except Exception as exc:  # noqa: BLE001
        return {"error": f"StateManager.get_instance failed: {exc}"}
    
    if instance is None:
        return {
            "is_initialized": False,
            "current_session_id": None,
            "todos_count": 0,
            "todos": [],
            "sub_states_count": 0,
        }
    
    try:
        todos = list(getattr(instance, "_todos", []) or [])
        sub_states = list(getattr(instance, "_sub_states", []) or [])
        session_id = getattr(instance, "_current_session_id", None)
        current_task = getattr(instance, "_current_task", None)
        
        todo_dicts: list[dict[str, Any]] = []
        for t in todos[:50]:
            todo_dicts.append({
                "id": str(getattr(t, "id", "")),
                "content": str(getattr(t, "content", ""))[:200],
                "status": str(getattr(t, "status", "")),
            })
        
        task_dict: Optional[dict[str, Any]] = None
        if current_task is not None:
            task_dict = {
                "id": str(getattr(current_task, "id", "")),
                "user_input": str(getattr(current_task, "user_input", ""))[:200],
            }
        
        return {
            "is_initialized": True,
            "current_session_id": session_id,
            "current_task": task_dict,
            "todos_count": len(todos),
            "todos": todo_dicts,
            "sub_states_count": len(sub_states),
        }
    except Exception as exc:  # noqa: BLE001
        return {"error": f"get_state_snapshot failed: {exc}"}


# ────────────────────────────────────────────────────────────────────────
# GlobalOntology 快照 + 查询
# ────────────────────────────────────────────────────────────────────────


def get_global_ontology_snapshot(
    project_root: Optional[Union[str, Path]] = None,
) -> dict[str, Any]:
    """GlobalOntology 6 类对象 count + version。
    
    返回 dict：
        {
          "is_initialized": bool,
          "project_root": str,
          "version": int,
          "counts": {
            "concept": int, "entity": int, "event": int,
            "relation": int, "document_chunk": int, "action": int,
          },
          "total": int,
        }
    
    Args:
        project_root: 项目根；为 None 时尝试从 ``project_context`` 读取
    
    不抛异常；失败返 ``{"error": "..."}``。
    """
    if project_root is None:
        try:
            from modules.utils.project_context import get_project_root
            project_root = get_project_root()
        except Exception:  # noqa: BLE001
            project_root = None
    
    if project_root is None:
        return {
            "is_initialized": False,
            "project_root": "",
            "version": 0,
            "counts": {},
            "total": 0,
        }
    
    try:
        from modules.knowledge.global_ontology_store import (
            _TABLE_BY_TYPE,
            get_global_ontology_store,
        )
    except ImportError as exc:
        return {"error": f"GlobalOntologyStore import failed: {exc}"}
    
    try:
        store = get_global_ontology_store(project_root)
        if store is None:
            return {
                "is_initialized": False,
                "project_root": str(project_root),
                "version": 0,
                "counts": {},
                "total": 0,
            }
        
        counts: dict[str, int] = {}
        total = 0
        for object_type in _TABLE_BY_TYPE.keys():
            try:
                c = store.count(object_type)  # type: ignore[arg-type]
                counts[object_type] = int(c)
                total += int(c)
            except Exception:  # noqa: BLE001
                counts[object_type] = 0
        
        return {
            "is_initialized": True,
            "project_root": str(project_root),
            "version": int(store.version),
            "counts": counts,
            "total": total,
        }
    except Exception as exc:  # noqa: BLE001
        return {"error": f"get_global_ontology_snapshot failed: {exc}"}


def query_global_ontology(
    query: str,
    *,
    project_root: Optional[Union[str, Path]] = None,
    limit: int = 10,
) -> dict[str, Any]:
    """按 query string 模糊查询 GlobalOntology（alias / label / definition 命中）。
    
    返回 dict：
        {
          "query": str,
          "matches": [{"object_type", "id", "label", "score"}],  # 至多 limit 条
          "match_count": int,
        }
    
    Args:
        query: 查询字符串
        project_root: 项目根；None 时从 project_context 读
        limit: 返回上限（默认 10，最大 100）
    
    不抛异常；失败返 ``{"error": "..."}``。
    """
    limit = max(1, min(int(limit), 100))
    query = (query or "").strip()
    if not query:
        return {"query": "", "matches": [], "match_count": 0}
    
    if project_root is None:
        try:
            from modules.utils.project_context import get_project_root
            project_root = get_project_root()
        except Exception:  # noqa: BLE001
            project_root = None
    
    if project_root is None:
        return {"query": query, "matches": [], "match_count": 0}
    
    try:
        from modules.knowledge.global_ontology_store import (
            get_global_ontology_store,
        )
    except ImportError as exc:
        return {"error": f"GlobalOntologyStore import failed: {exc}"}
    
    try:
        store = get_global_ontology_store(project_root)
        if store is None:
            return {"query": query, "matches": [], "match_count": 0}
        
        # 走 search_by_alias（最稳定的 read API）
        try:
            hits = store.search_by_alias(query) or []
        except Exception:  # noqa: BLE001
            hits = []
        
        matches: list[dict[str, Any]] = []
        for object_type, object_id in hits[:limit]:
            try:
                obj = store.get(object_type, object_id)
                label = ""
                if obj is not None:
                    label = str(getattr(obj, "label", "") or getattr(obj, "name", ""))[:120]
                matches.append({
                    "object_type": object_type,
                    "id": str(object_id),
                    "label": label,
                })
            except Exception:  # noqa: BLE001
                matches.append({
                    "object_type": object_type,
                    "id": str(object_id),
                    "label": "",
                })
        
        return {
            "query": query,
            "matches": matches,
            "match_count": len(matches),
        }
    except Exception as exc:  # noqa: BLE001
        return {"error": f"query_global_ontology failed: {exc}"}


# ────────────────────────────────────────────────────────────────────────
# ExperienceMemory 快照 + 查询
# ────────────────────────────────────────────────────────────────────────


def get_memory_stats() -> dict[str, Any]:
    """ExperienceMemory 统计摘要。
    
    返回 dict：
        {
          "is_initialized": bool,
          "stats": {...},  # MemoryGraphService.get_stats() 原样转发（dict）
        }
    
    不抛异常；失败返 ``{"error": "..."}``。
    """
    try:
        from modules.agent.experience_memory.integration import get_memory_system
    except ImportError as exc:
        return {"error": f"ExperienceMemory import failed: {exc}", "is_initialized": False}
    
    try:
        svc = get_memory_system()
        if svc is None:
            return {"is_initialized": False, "stats": {}}
        
        try:
            stats = svc.get_stats()
            if not isinstance(stats, dict):
                stats = {"raw": str(stats)}
        except Exception as exc:  # noqa: BLE001
            return {
                "is_initialized": True,
                "stats": {},
                "error_inner": f"get_stats failed: {exc}",
            }
        
        return {"is_initialized": True, "stats": stats}
    except Exception as exc:  # noqa: BLE001
        return {"error": f"get_memory_stats failed: {exc}"}


def query_memories(
    query_text: str,
    *,
    limit: int = 10,
    session_id: Optional[str] = None,
    project_id: Optional[str] = None,
) -> dict[str, Any]:
    """ExperienceMemory wakeup_sync 降级查询。
    
    返回 dict：
        {
          "query": str,
          "results": [
            {"id", "node_type", "title", "content_preview", "strength", "tags"},
          ],  # 至多 limit 条
          "count": int,
        }
    
    设计取舍：
    - 用 ``query_by_metadata`` 而非 ``query_sync`` —— ``query_sync`` 走 wakeup engine
      可能触发 embedding / LLM 调用（违反 §5.10 zero-LLM 原则）
    - ``query_by_metadata`` 是纯内存 + tag 过滤，纯 read-only
    
    不抛异常；失败返 ``{"error": "..."}``。
    """
    limit = max(1, min(int(limit), 100))
    query_text = (query_text or "").strip()
    
    try:
        from modules.agent.experience_memory.integration import get_memory_system
    except ImportError as exc:
        return {"error": f"ExperienceMemory import failed: {exc}"}
    
    try:
        svc = get_memory_system()
        if svc is None:
            return {"query": query_text, "results": [], "count": 0}
        
        # 优先走 query_by_metadata（纯内存 + 标签过滤；不调 LLM/embedding）
        try:
            tags = [query_text] if query_text else None
            nodes = svc.query_by_metadata(
                tags=tags,
                project_id=project_id,
                session_id=session_id,
                top_k=limit,
            ) or []
        except Exception as exc:  # noqa: BLE001
            return {
                "query": query_text,
                "results": [],
                "count": 0,
                "error_inner": f"query_by_metadata failed: {exc}",
            }
        
        results: list[dict[str, Any]] = []
        for node in nodes[:limit]:
            try:
                node_type = getattr(node, "node_type", None)
                node_type_str = str(node_type.value) if hasattr(node_type, "value") else str(node_type)
                results.append({
                    "id": str(getattr(node, "id", "")),
                    "node_type": node_type_str,
                    "title": str(getattr(node, "title", ""))[:120],
                    "content_preview": str(getattr(node, "content", ""))[:200],
                    "strength": float(getattr(node, "strength", 0.0) or 0.0),
                    "tags": list(getattr(node, "tags", []) or []),
                })
            except Exception:  # noqa: BLE001
                continue
        
        return {
            "query": query_text,
            "results": results,
            "count": len(results),
        }
    except Exception as exc:  # noqa: BLE001
        return {"error": f"query_memories failed: {exc}"}


__all__ = [
    "get_global_ontology_snapshot",
    "get_memory_stats",
    "get_state_snapshot",
    "query_global_ontology",
    "query_memories",
]
