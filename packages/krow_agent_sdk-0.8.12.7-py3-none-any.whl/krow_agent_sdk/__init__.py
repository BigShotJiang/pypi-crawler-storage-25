"""Krow Agent SDK（Wave 1）—— 顶层入口。

> 完整设计 SSOT：``docs/sdk/plugin-architecture-design.md`` (v0.8)
> 路线图：``§9 渐进路线图``；本 Wave 1 PR 兑现 mvp_critical（P1/P2/P4）真实加载

import 路径双轨（design doc §6.0 + 顶级 review D1）：

- Step 1：``from modules.agent.sdk import AgentBuilder`` 或 ``from krow_agent_sdk import AgentBuilder``（alias）
- Step 2 PyPI 发布后：仅推荐 ``from krow_agent_sdk import AgentBuilder``

Wave 1 暴露的 API：

- ``AgentBuilder``、``Agent``、``BuilderConfig``、``BudgetSpec``
- ``protocols``: ``ACTPlugin / ToolPlugin / GatePlugin / HintPlugin / EventListenerPlugin / ObservabilityPlugin``
- ``experimental.protocols``: ``MCPServerPlugin / SecurityPlugin / DomainPackPlugin``（experimental）
- errors / lifecycle / events / llm helper / auth helper

Wave 1 **不**暴露：

- 完整 ``with_*_from_entry_points()`` 自动发现（Wave 2）
- ``data`` / ``diagnostics`` / ``visual`` facade（Wave 2-3）
- 反向 telemetry（Wave 2 PR S2.17）
"""
from __future__ import annotations

import sys

# v0.8 顶级 review D1 / Step 1 PR S1.18：让外部团队 Day 1 用稳定 import 路径。
# `from krow_agent_sdk import AgentBuilder` 与 `from modules.agent.sdk import AgentBuilder` 等价。
sys.modules.setdefault("krow_agent_sdk", sys.modules[__name__])

from . import (
    auth,
    data,
    deprecation,
    diagnostics,
    entry_points,
    errors,
    events,
    extended_md_supplement_registry,
    hints,
    lifecycle,
    llm,
    replay,
    telemetry,
    visual,
)
from .builder import (
    Agent,
    AgentBuilder,
    BudgetSpec,
    BuilderConfig,
    HttpGatewaySpec,
)
from .data import (
    get_global_ontology_snapshot,
    get_memory_stats,
    get_state_snapshot,
    query_global_ontology,
    query_memories,
)
from .diagnostics import dump_state, get_plugin_snapshot, get_tool_snapshot
from .events import EventBusReader, StreamItem, StreamItemKind
from .hints import HintRegistry, get_hint_registry
from .lifecycle import BasePluginLifecycle, SDKContext
from . import protocols as _protocols
from .protocols import (
    ACTPlugin,
    EventListenerPlugin,
    GatePlugin,
    HintPlugin,
    ObservabilityPlugin,
    ToolPlugin,
)

# experimental 单独 namespace（design doc §5.0.1 + 顶级 review A2）
from . import experimental  # noqa: E402  (alias setup must come first)

# 子模块也要加 alias，否则 `from krow_agent_sdk.errors import X` 会得到独立 module 实例（破坏 isinstance 检查）
for _suffix, _mod in (
    ("errors", errors),
    ("events", events),
    ("hints", hints),
    ("lifecycle", lifecycle),
    ("llm", llm),
    ("auth", auth),
    ("data", data),
    ("diagnostics", diagnostics),
    ("entry_points", entry_points),
    ("extended_md_supplement_registry", extended_md_supplement_registry),
    ("deprecation", deprecation),
    ("telemetry", telemetry),
    ("replay", replay),
    ("visual", visual),
    ("protocols", _protocols),
    ("experimental", experimental),
    ("experimental.protocols", experimental.protocols),
):
    sys.modules.setdefault(f"krow_agent_sdk.{_suffix}", _mod)
del _suffix, _mod, _protocols

# Wave 4：krow_test_sdk 平级 namespace（design doc §6.7 PR S1.13）
# 让外部开发者写 `from krow_test_sdk import HeadlessAgentHarness, LLMReplayStore`
#
# P0b（2026-05-13）：tolerate ``tests/support`` 不可用的场景。
# Step 1 阶段 SDK 与主仓 monorepo 共享 wheel；setuptools 默认 exclude ``tests/``，
# 装 wheel 后 ``tests.support.llm_replay`` 不存在 → ``test_sdk`` import 抛
# ``ModuleNotFoundError``。这个 module 只用于"开发者写自己 plugin 的测试"
# （详 ``test_sdk.py`` docstring），不影响 ``AgentBuilder`` / Plugin Protocol 主路径。
# 所以静默跳过：开发模式（``pip install -e .``）有 ``tests/`` 时正常注册；
# wheel 模式下不注册 ``krow_test_sdk`` alias，但所有 SDK 主功能完好。
try:
    from . import test_sdk as _test_sdk  # noqa: E402
    sys.modules.setdefault("krow_test_sdk", _test_sdk)
    del _test_sdk
except ModuleNotFoundError as _exc:  # 缺 tests/support 场景（wheel 安装）
    import logging as _logging
    _logging.getLogger(__name__).debug(
        "krow_test_sdk 不可用（缺 tests/support，wheel 安装常态）：%s", _exc,
    )
    del _exc

# SSOT: ``config/version.py:get_version`` —— SDK 版本与主仓 release tag 始终一致.
# 早期 0.1.0 hardcoded 已弃用（与 README 声明 "SDK 版本号 = Krow 主仓 config/version.py
# 版本号" 矛盾）. 兜底 fallback 仅在 ``config.version`` 不可用时使用.
try:
    from config.version import get_version as _get_version  # type: ignore
    __version__: str = _get_version()
    del _get_version
except Exception:  # noqa: BLE001
    __version__ = "0.0.0+unknown"

__all__ = [
    "__version__",
    # Builder + Agent
    "AgentBuilder",
    "Agent",
    "BudgetSpec",
    "BuilderConfig",
    "HttpGatewaySpec",
    # mvp_critical Protocols
    "ACTPlugin",
    "ToolPlugin",
    "GatePlugin",
    # stable Protocols
    "HintPlugin",
    "EventListenerPlugin",
    "ObservabilityPlugin",
    # Lifecycle / Events
    "BasePluginLifecycle",
    "SDKContext",
    "EventBusReader",
    "StreamItem",
    "StreamItemKind",
    # Hint registry（Wave 2 P3 真实加载）
    "HintRegistry",
    "get_hint_registry",
    # Wave 4 diagnostics facade
    "dump_state",
    "get_plugin_snapshot",
    "get_tool_snapshot",
    "diagnostics",
    # PR A2 / S1.14 data facade（only-read）
    "data",
    "get_state_snapshot",
    "get_global_ontology_snapshot",
    "query_global_ontology",
    "get_memory_stats",
    "query_memories",
    # PR B1 entry_points 自动发现
    "entry_points",
    # PR B3 / S2.9+S2.14 feature flag + supplement merge + deprecation
    "extended_md_supplement_registry",
    "deprecation",
    # PR C1 / S2.17 反向 telemetry opt-in
    "telemetry",
    # P1b 2026-05-13：record/replay 框架公开 API
    "replay",
    # Step 2 P2 (2026-05-13)：visual_inspect plugin 完整公开
    "visual",
    # subpackages
    "experimental",
    "errors",
    "lifecycle",
    "events",
    "hints",
    "auth",
    "llm",
]
