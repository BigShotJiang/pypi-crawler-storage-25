"""HintRegistry —— P3 HintPlugin 真实加载基础设施（Wave 2）。

设计文档锚点：§5.0.4 + §3.5 P3 协议；本文件落地 PR S1.7 部分能力。

## 架构定位（System 1 / System 2 边界）

- **System 1**（本文件）：注册 / 反注册 / fan-out 渲染 = 确定性查表 + 字符串拼接
- **System 2**：plugin.hint_for(context) → str 由 LLM 视角的语义判断（plugin 实现侧）

## 接入点（OCP，不破坏既有调用方）

- macro 侧：`agent_v3` 里 `build_macro_system_prompt(...)` 完成后，
  `build_reasoning_preamble` 拼接同位置追加 `render_macro_hints(context)` 的结果
- micro 侧：`progressive/executor.py` 拼装 ReACT `question` 之前，
  在尾段追加 `render_micro_hints(context)` 的结果

未挂载（单元测试 / 无 plugin 注入时）→ 渲染返回空字符串，零行为变化。

## SSOT 约束

- 注册表是**进程级 singleton**（与 ToolManager / ACTLoader 一致）
- plugin_id 维度去重（同 plugin_id 后注册覆盖前一次，不抛错——支持 hot reload 场景）
- 渲染按注册顺序拼接（FIFO）
- handler 抛异常 → swallow + logger.error（与 §6.0.4 plugin error mode 一致）
"""
from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING, Any, Callable, Optional

if TYPE_CHECKING:
    from .protocols.hint import HintPlugin

logger = logging.getLogger(__name__)


# 注册条目：(plugin_id, hint_callable, applicable_acts)
# hint_callable: Callable[[dict], Optional[str]]
HintCallable = Callable[[dict], Optional[str]]


class HintRegistry:
    """Hint 注册中心。Plugin 通过 `register_hint` 注入，
    主仓在 prompt 拼装钩子调 `render_macro_hints` / `render_micro_hints` fan-out。

    线程安全：register / unregister / render 全部 `_lock` 保护；
    handler 调用本身**不**持锁（避免 plugin handler 内部死锁）。
    """

    def __init__(self) -> None:
        self._entries: list[tuple[str, HintCallable, frozenset[str]]] = []
        self._lock = threading.RLock()

    def register_hint(
        self,
        plugin_id: str,
        hint_callable: HintCallable,
        *,
        applicable_acts: Optional[list[str]] = None,
    ) -> None:
        """注册 plugin 的 hint 渲染回调。

        Args:
            plugin_id: 唯一 ID（同 plugin_id 后注册覆盖前一次）
            hint_callable: ``(context_dict) -> Optional[str]`` 渲染函数
                返回 None 或 ``""`` → fan-out 时跳过
            applicable_acts: 限定生效的 ACT 名单（None / 空 = 全局生效）
                上下文中 ``context["act_name"]`` 在 applicable_acts 列表内才调
        """
        applicable_set: frozenset[str] = frozenset(applicable_acts or [])
        with self._lock:
            self._entries = [(pid, fn, acts) for pid, fn, acts in self._entries if pid != plugin_id]
            self._entries.append((plugin_id, hint_callable, applicable_set))

    def unregister_hint(self, plugin_id: str) -> None:
        """反注册（plugin shutdown / Agent.shutdown 时调用）。"""
        with self._lock:
            self._entries = [(pid, fn, acts) for pid, fn, acts in self._entries if pid != plugin_id]

    def list_plugin_ids(self) -> list[str]:
        """已注册 plugin_id 列表（debug / introspection）。"""
        with self._lock:
            return [pid for pid, _, _ in self._entries]

    def render_hints(self, context: dict, *, scope: str = "macro") -> str:
        """fan-out 调所有匹配 plugin 的 hint，按注册顺序拼接为单段字符串。

        Args:
            context: 上下文 dict；至少含 ``act_name`` 字段（applicable_acts 过滤）
            scope: ``"macro"`` / ``"micro"``（仅作 logger 记录，不影响行为；
                后续 P3 hint plugin 可在 context 里读 ``scope`` 自分流）

        Returns:
            拼接后的 hint 文本（用 ``\\n\\n`` 分隔多个 plugin 的输出）；
            无匹配 / 全部空 → 返回 ``""``。
        """
        ctx = dict(context) if context else {}
        ctx.setdefault("scope", scope)
        act_name = ctx.get("act_name", "")

        with self._lock:
            entries_snapshot = list(self._entries)

        parts: list[str] = []
        for plugin_id, fn, acts in entries_snapshot:
            if acts and act_name and act_name not in acts:
                continue
            try:
                output = fn(ctx)
            except Exception as exc:  # noqa: BLE001
                logger.error(
                    "HintPlugin render error (plugin_id=%s, scope=%s): %s",
                    plugin_id, scope, exc, exc_info=True,
                )
                continue
            if output is None:
                continue
            text = str(output).strip()
            if not text:
                continue
            parts.append(text)
        return "\n\n".join(parts)

    # 别名：macro / micro 各暴露一个语义化 API（与设计文档对齐）
    def render_macro_hints(self, context: dict) -> str:
        return self.render_hints(context, scope="macro")

    def render_micro_hints(self, context: dict) -> str:
        return self.render_hints(context, scope="micro")

    def clear(self) -> None:
        """全部清空（仅测试 / Agent.shutdown 内部调用）。"""
        with self._lock:
            self._entries.clear()


# ────────────────────────────────────────────────────────────────────────
# 进程级 singleton
# ────────────────────────────────────────────────────────────────────────


_HINT_REGISTRY: Optional[HintRegistry] = None
_HINT_REGISTRY_LOCK = threading.RLock()


def get_hint_registry() -> HintRegistry:
    """进程级 singleton 入口。第一次调用时懒构造。"""
    global _HINT_REGISTRY
    with _HINT_REGISTRY_LOCK:
        if _HINT_REGISTRY is None:
            _HINT_REGISTRY = HintRegistry()
        return _HINT_REGISTRY


def reset_hint_registry() -> None:
    """测试用 reset（不要在生产代码中调用）。"""
    global _HINT_REGISTRY
    with _HINT_REGISTRY_LOCK:
        if _HINT_REGISTRY is not None:
            _HINT_REGISTRY.clear()


def _hint_callable_from_plugin(plugin: "HintPlugin") -> HintCallable:
    """从 HintPlugin 实例提取 ``hint_for`` 方法包装为 callable。

    分离封装让 builder 可以传 callable 而非 plugin 实例（解耦 + 便于测试）。
    """
    def _call(context: dict) -> Optional[str]:
        return plugin.hint_for(context)
    return _call


__all__ = [
    "HintCallable",
    "HintRegistry",
    "get_hint_registry",
    "reset_hint_registry",
    "_hint_callable_from_plugin",
]
