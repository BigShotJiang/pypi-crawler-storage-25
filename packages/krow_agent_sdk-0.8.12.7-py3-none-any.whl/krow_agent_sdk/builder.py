"""AgentBuilder + Agent + BuilderConfig（design doc §6.1 + 顶级 review A5/A6/D8）。

SDK 唯一入口：``from krow_agent_sdk import AgentBuilder``（详 §6.0 import 双轨）。

> **Wave 1 范围**：
>
> - 真实加载 mvp_critical（P1 ACT / P2 Tool / P4 Gate）到主仓 ACTLoader / ToolManager / GateChain
> - 校验 api_key 格式 + project_root 写权限 + plugin signature
> - 暴露 ``Agent.run`` / ``Agent.event_bus`` (EventBusReader) / ``Agent.shutdown``
> - 支持注入 ``ai_manager`` 用于测试（生产从 AIProviderManager 默认初始化）
>
> **不在 Wave 1 范围**（Wave 2 起）：
>
> - 完整链式 ``with_*_from_entry_points()`` 自动发现（Wave 2 PR S1.2-S1.4）
> - P3/P5/P6 真实加载（Wave 2）
> - experimental P7/P8/P9 加载（Wave 3）
> - 修 ``KrowAuthAdapter.set_api_key/get_user_info`` dead code（Wave 2 PR S1.17 末段）
"""
from __future__ import annotations

import logging
import os
import queue
import threading
import time
from collections.abc import Callable, Iterator, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
)

from ._plugin_id_validator import validate_plugin_id
from ._protocol_validator import validate_protocol_implementation
from .auth import (
    read_api_key_from_env,
    read_project_root_from_env,
    validate_api_key_format,
)
from .errors import (
    DuplicatePluginIDError,
    MissingKrowAPIKeyError,
    MissingProjectRootError,
    PluginLoadError,
    ProjectRootNotWritableError,
)
from .events import EventBusReader, StreamItem
from .experimental.protocols import (
    DomainPackPlugin,
    MCPServerPlugin,
    SecurityPlugin,
    VisualAdapterPlugin,
)
from .hints import _hint_callable_from_plugin, get_hint_registry
from .lifecycle import SDKContext, call_on_load_if_implemented, call_on_unload_if_implemented
from .protocols import (
    ACTPlugin,
    EventListenerPlugin,
    GatePlugin,
    HintPlugin,
    ObservabilityPlugin,
    ToolPlugin,
)

if TYPE_CHECKING:
    from modules.agent.agent_v3 import AgentV3, AgentV3Result
    from modules.ai.providers import AIProviderManager
    from modules.events.bus import EventBus

logger = logging.getLogger(__name__)


# ────────────────────────────────────────────────────────────────────────
# Plugin error mode（design doc §6.0.4 + D6）
# ────────────────────────────────────────────────────────────────────────

ENV_PLUGIN_ERROR_MODE = "KROW_SDK_PLUGIN_ERROR_MODE"
ENV_BUILD_VALIDATE = "KROW_SDK_BUILD_VALIDATE_CONNECTION"
ENV_HTTP_GATEWAY = "KROW_SDK_HTTP_GATEWAY"  # PR A3 / S1.15 feature flag
ENV_MCP_SERVER_PLUGIN = "KROW_ENABLE_MCP_SERVER_PLUGIN"  # P1a 2026-05-13


def _plugin_error_mode() -> str:
    return os.environ.get(ENV_PLUGIN_ERROR_MODE, "swallow").strip().lower()


def _is_mcp_server_plugin_enabled() -> bool:
    """P1a：MCPServerPlugin 形态 B（in-process server 注册到 ToolManager）opt-in。
    
    默认 OFF — 避免外部 plugin 直接污染 ToolManager 主路径；明确 opt-in 后才生效。
    """
    return os.environ.get(ENV_MCP_SERVER_PLUGIN, "0").strip().lower() in (
        "1", "true", "yes", "on",
    )


def _handle_plugin_error(plugin_id: str, location: str, exc: BaseException) -> None:
    mode = _plugin_error_mode()
    if mode == "raise":
        raise exc
    # swallow / quiet 都不抛
    if mode != "quiet":
        logger.error(
            "Plugin error (mode=%s) plugin_id=%s at %s: %s",
            mode, plugin_id, location, exc, exc_info=True,
        )


# ────────────────────────────────────────────────────────────────────────
# BudgetSpec（design doc §5.12 + §6.1，Wave 1 字段精简版）
# ────────────────────────────────────────────────────────────────────────


@dataclass
class BudgetSpec:
    """完整预算配置 dataclass（Wave 1 仅暴露最常用字段）。"""

    target_walltime_s: int = 600
    max_walltime_s: int = 1800
    max_total_llm_calls: int = 120
    max_adapt_extensions: int = 3
    max_replans: int = 3
    micro_max_iterations: int = 8
    micro_max_time_ms: int = 180_000


# ────────────────────────────────────────────────────────────────────────
# BuilderConfig（design doc §6.1 + 顶级 review A5）
# ────────────────────────────────────────────────────────────────────────


@dataclass
class HttpGatewaySpec:
    """SDK HTTP Gateway 配置（PR A3 / S1.15）。
    
    enabled=True 时 ``AgentBuilder.build()`` 末尾启动主仓 ``APIServer``
    （uvicorn + FastAPI），供外部 UI 通过 HTTP / WS / SSE 接 SDK Agent。
    
    feature flag：``KROW_SDK_HTTP_GATEWAY=1`` 也可在不调 ``with_http_gateway()``
    时启用（host/port 走 default）。
    """
    
    enabled: bool = False
    host: str = "127.0.0.1"
    port: int = 8090
    auth_token: str | None = None  # 预留：Wave B 真实接入 bearer auth middleware
    dry_run: bool = False  # 测试用：不真启 uvicorn，只占位 + 验证配置


@dataclass
class BuilderConfig:
    """SDK 一次性配置 dataclass。``AgentBuilder.from_config(config)`` 是 production 推荐路径。"""

    api_key: str
    project_root: Path
    budget: BudgetSpec | None = None
    act_plugins: list[ACTPlugin] = field(default_factory=list)
    tool_plugins: list[ToolPlugin] = field(default_factory=list)
    gate_plugins: list[GatePlugin] = field(default_factory=list)
    hint_plugins: list[HintPlugin] = field(default_factory=list)
    event_listener_plugins: list[EventListenerPlugin] = field(default_factory=list)
    observability_plugins: list[ObservabilityPlugin] = field(default_factory=list)
    # Wave 3 experimental
    mcp_server_plugins: list[MCPServerPlugin] = field(default_factory=list)
    security_plugins: list[SecurityPlugin] = field(default_factory=list)
    domain_pack_plugins: list[DomainPackPlugin] = field(default_factory=list)
    # Step 2 P2 (2026-05-13)：visual_inspect plugin 完整公开
    visual_adapter_plugins: list[VisualAdapterPlugin] = field(default_factory=list)
    inline_visual_adapters: list[tuple[str, Any]] = field(default_factory=list)
    validate_connection_on_build: bool = True
    ai_manager: AIProviderManager | None = None  # 测试可注入
    # PR A3 / S1.15 HTTP gateway
    http_gateway: HttpGatewaySpec = field(default_factory=HttpGatewaySpec)


# ────────────────────────────────────────────────────────────────────────
# HTTP Gateway handle（PR A3 / S1.15）
# ────────────────────────────────────────────────────────────────────────


class _HttpGatewayHandle:
    """``with_http_gateway`` 启动后返回的 handle。
    
    包装主仓 ``modules.remote.api_gateway.APIServer`` 实例，
    暴露稳定的 ``host``/``port``/``url``/``is_running``/``stop`` 接口。
    
    设计取舍：
    - 不直接暴露 ``APIServer`` 内部，避免外部 SDK 依赖主仓 API 形状变化
    - dry_run=True 时不真启 uvicorn（unit test / CI 友好），但保留所有 metadata
      让调用方能验证配置已记录
    """
    
    def __init__(
        self,
        *,
        host: str,
        port: int,
        auth_token: str | None = None,
        dry_run: bool = False,
    ) -> None:
        self._host = host
        self._port = port
        self._auth_token = auth_token
        self._dry_run = dry_run
        self._api_server: Any = None  # APIServer 或 None（dry_run）
        self._started = False
    
    @property
    def host(self) -> str:
        return self._host
    
    @property
    def port(self) -> int:
        return self._port
    
    @property
    def url(self) -> str:
        return f"http://{self._host}:{self._port}"
    
    @property
    def is_running(self) -> bool:
        if self._dry_run:
            return self._started
        if self._api_server is None:
            return False
        try:
            return bool(self._api_server.is_running)
        except Exception:  # noqa: BLE001
            return False
    
    @property
    def dry_run(self) -> bool:
        return self._dry_run
    
    def _start(self) -> None:
        """build() 内部调；启动主仓 APIServer。"""
        if self._started:
            return
        if self._dry_run:
            self._started = True
            logger.info(
                "HTTP Gateway: dry_run mode — host=%s port=%d (uvicorn not started)",
                self._host, self._port,
            )
            return
        
        try:
            from modules.remote.api_gateway import APIServer
        except ImportError as exc:
            raise RuntimeError(
                "HTTP Gateway requires FastAPI/uvicorn — install with `pip install krow-agent-sdk[http]`",
            ) from exc
        
        # 创建独立 APIServer 实例（不调 get_api_server() 单例，避免污染主仓 KrowService）
        self._api_server = APIServer(host=self._host, port=self._port)
        ok = self._api_server.start()
        if not ok:
            raise RuntimeError(
                f"HTTP Gateway: APIServer.start() failed (host={self._host}, port={self._port}); "
                f"FastAPI may be missing or port may be occupied",
            )
        self._started = True
        logger.info("HTTP Gateway started: %s", self.url)
    
    def stop(self) -> None:
        """停止 gateway。Agent.shutdown 内自动调；外部也可显式调。"""
        if not self._started:
            return
        if self._dry_run:
            self._started = False
            return
        if self._api_server is not None:
            try:
                self._api_server.stop()
            except Exception as exc:  # noqa: BLE001
                logger.warning("HTTP Gateway: APIServer.stop() error: %s", exc)
        self._api_server = None
        self._started = False
        logger.info("HTTP Gateway stopped")


# ────────────────────────────────────────────────────────────────────────
# Agent（build() 返回的 SDK 对象）
# ────────────────────────────────────────────────────────────────────────


class Agent:
    """SDK Agent facade —— 包装主仓 AgentV3，暴露稳定 API。

    用户通过 ``AgentBuilder.build()`` 拿到该对象。
    """

    def __init__(
        self,
        agent_v3: AgentV3,
        event_bus: EventBus,
        plugin_ids: list[str],
        cleanup_callbacks: list[Callable[[], None]],
        sdk_state: dict[str, Any] | None = None,
        http_gateway: _HttpGatewayHandle | None = None,
    ) -> None:
        self._agent_v3 = agent_v3
        self._event_bus_reader = EventBusReader(event_bus)
        self._plugin_ids = list(plugin_ids)
        self._cleanup_callbacks = list(cleanup_callbacks)
        self._sdk_state: dict[str, Any] = dict(sdk_state or {})
        self._http_gateway = http_gateway
        self._closed = False
        self._lock = threading.RLock()

    @property
    def event_bus(self) -> EventBusReader:
        """暴露**只读** EventBus reader（design doc §6.1 顶级 review A10）。"""
        return self._event_bus_reader

    @property
    def loaded_plugin_ids(self) -> tuple[str, ...]:
        """已加载 plugin 的 ID 列表（用于 debug / introspection）。"""
        return tuple(self._plugin_ids)

    @property
    def mcp_servers(self) -> tuple[dict, ...]:
        """experimental P7：所有 MCPServerPlugin + DomainPackPlugin 注入的 MCP server 配置。"""
        return tuple(self._sdk_state.get("mcp_servers", []))

    @property
    def security_policies(self) -> tuple[dict, ...]:
        """experimental P8：所有 SecurityPlugin + DomainPackPlugin 注入的 policy 列表。"""
        return tuple(self._sdk_state.get("security_policies", []))

    @property
    def visual_adapters(self) -> tuple[tuple, ...]:
        """experimental P9：所有 DomainPackPlugin 注入的 (file_ext, adapter) 列表。"""
        return tuple(self._sdk_state.get("visual_adapters", []))

    @property
    def recommended_budget(self) -> dict | None:
        """experimental P9：DomainPackPlugin 推荐的 budget dict（最后一个 plugin 覆盖）。"""
        bd = self._sdk_state.get("recommended_budget")
        return dict(bd) if bd else None

    @property
    def supplementary_md_providers(self) -> tuple[Any, ...]:
        """experimental P9：所有实现了 ``get_extended_md_supplement`` 的 plugin（Wave 3 仅记录）。"""
        return tuple(self._sdk_state.get("supplementary_md_providers", []))
    
    @property
    def http_gateway(self) -> _HttpGatewayHandle | None:
        """PR A3 / S1.15 HTTP Gateway handle（None = 未启用）。
        
        启用时返回 ``_HttpGatewayHandle`` 实例，含 ``host``/``port``/``url``/
        ``is_running`` 属性 + ``stop()`` 方法。SDK 开发者可拿 ``url`` 给外部 UI
        / 测试用例 / 监控端访问。
        
        feature flag：``with_http_gateway(enable=True)`` 或 env ``KROW_SDK_HTTP_GATEWAY=1``。
        """
        return self._http_gateway

    def run(
        self,
        user_input: str,
        *,
        context: dict | None = None,
        session_id: str | None = None,
        project_id: str | None = None,
        stop_event: Any | None = None,
        inbound_messages: list[dict[str, str]] | None = None,
        task_context: dict[str, Any] | None = None,
    ) -> AgentV3Result:
        """执行任务（透传 ``AgentV3.run`` 真实签名）。

        Returns:
            ``AgentV3Result`` dataclass（含 ``success`` / ``solution`` / ``execution_result`` / ``final_output`` 等）

        Wave 2 加：进入前 emit ``agent.run.start`` audit + ``agent.run.calls`` metric；
        退出后 emit ``agent.run.complete`` audit + 主仓 EventBus 仍发自己的事件（双轨）。
        """
        if self._closed:
            raise RuntimeError("Agent has been shutdown; cannot run.")
        from modules.observability.sink_registry import emit_sdk_audit, emit_sdk_metric

        emit_sdk_metric(
            name="agent.run.calls",
            value=1.0,
            session_id=str(session_id or ""),
            project_id=str(project_id or ""),
        )
        emit_sdk_audit(
            "agent.run.start",
            user_input_preview=user_input[:80],
            session_id=str(session_id or ""),
        )
        try:
            result = self._agent_v3.run(
                user_input=user_input,
                context=context,
                session_id=session_id,
                project_id=project_id,
                stop_event=stop_event,
                inbound_messages=inbound_messages,
                task_context=task_context,
            )
        except Exception as exc:
            emit_sdk_audit(
                "agent.run.error",
                error_type=type(exc).__name__,
                error_msg=str(exc)[:200],
            )
            raise
        emit_sdk_audit(
            "agent.run.complete",
            success=bool(getattr(result, "success", False)),
            output_preview=str(getattr(result, "final_output", ""))[:80],
        )
        return result

    def run_stream(
        self,
        user_input: str,
        *,
        topics: Sequence[str] = (
            # macro_react / progressive 推进
            "macro_react.plan_created",
            "macro_react.todo_updated",
            "progressive.step_start",
            "progressive.step_completed",
            "progressive.replan_start",
            "progressive.early_conclude",
            # planner / phase
            "planner.phase2_start",
            "planner.phase2_end",
            # micro ReACT
            "react.step",
            "react.complete",
            "react.thinking_stream",
            # LLM
            "llm.request",
            "llm.response",
            "llm.error",
            # 终止信号（必须订阅，run_stream 据此知道何时结束）
            "agent.task_start",
            "agent.task_complete",
            "agent.task_failed",
            "agent.task_cancelled",
        ),
        context: dict | None = None,
        session_id: str | None = None,
        project_id: str | None = None,
        stop_event: Any | None = None,
        inbound_messages: list[dict[str, str]] | None = None,
        task_context: dict[str, Any] | None = None,
        queue_max_size: int = 1000,
        idle_timeout: float | None = 600.0,
    ) -> Iterator[StreamItem]:
        """流式执行任务（chore/sdk-run-stream-api-2026-05-15）。

        启动后台线程跑 ``AgentV3.run``，主调用方逐个 yield ``StreamItem``
        envelope（``event`` / ``result`` / ``error`` 三种 kind），直到任务
        完成 / 异常 / idle_timeout / 用户 break。

        与 ``Agent.run()`` 的关系：
        - ``run()``：阻塞式同步，返回 ``AgentV3Result`` 一次性。
        - ``run_stream()``：流式 yield，事件实时推、最终结果作为最后一个
          ``StreamItem(kind="result")`` yield。底层完全复用 ``run()`` 路径
          + ``EventBusReader.subscribe``，不引入新的执行分支（OCP）。

        参数:
            user_input: 用户任务输入（透传 ``AgentV3.run``）
            topics: 需要订阅的 EventBus topic 列表。默认覆盖：
                ``macro_react.* / progressive.* / planner.* / react.* / llm.* /
                agent.task_*``。**``agent.task_complete/failed/cancelled``
                必须在列表内**——run_stream 据此知道何时结束（若用户传入
                自定义 topics 漏掉，本方法会 fail-loud 报错）。
            context / session_id / project_id / stop_event / inbound_messages /
            task_context: 透传给 ``AgentV3.run``（语义同 ``Agent.run``）。
            queue_max_size: 内部事件 queue 上限（默认 1000）。**满时 fail-loud
              丢弃最旧的事件**（保流不卡死，但记 warning）；正常 LLM 任务
              5-100 个事件远小于 1000，不会触发。
            idle_timeout: ``queue.get`` 单次最长等待秒数（默认 600）；超过 →
              yield ``StreamItem(kind="error", error=TimeoutError)`` 后结束。
              传 ``None`` 表示无限等待（不推荐生产用，agent 卡死会无限阻塞）。

        Yields:
            ``StreamItem`` envelope，按时间顺序：

            1. 多个 ``StreamItem(kind="event")`` —— EventBus 推送的事件
            2. **最后一个**为 ``StreamItem(kind="result")`` 或
               ``StreamItem(kind="error")``，标识任务结束

        生命周期:
            - 用户提前 ``break`` for loop → generator ``close()`` → 触发
              ``finally`` → unsubscribe + 等后台线程退出 + 清队列。
            - **``stop_event``**：用户传入的 ``threading.Event`` 在 break
              时自动 set，让 ``AgentV3`` 内部协作 stop（详
              ``modules/agent/agent_v3.py`` 的 stop_event 协议）。
            - **后台线程异常**：捕获后转 ``StreamItem(kind="error")``
              yield，再 raise StopIteration。

        反模式（设计文档 §0.1 TURBO 哲学）:
            - ❌ 在 ``handler`` 里调 LLM / 重 IO（handler 在 EventBus 线程跑，
              会阻塞其他订阅）
            - ❌ 多次调 ``run_stream()`` 复用同一个 Agent 实例的同 ``session_id``
              （AgentV3 是 stateful，并发会乱）

        例子:

        .. code-block:: python

            with agent_builder.build() as agent:  # 假设 P0 之后加了 ctx mgr
                for item in agent.run_stream("写报告"):
                    if item.kind == "event":
                        print(f"[{item.event.type}]")
                    elif item.kind == "result":
                        final = item.result
                    elif item.kind == "error":
                        raise item.error
        """
        if self._closed:
            raise RuntimeError("Agent has been shutdown; cannot run_stream.")

        terminal_topics = {
            "agent.task_complete",
            "agent.task_failed",
            "agent.task_cancelled",
        }
        topics_set = set(topics)
        if not (terminal_topics & topics_set):
            raise ValueError(
                "run_stream(topics=...) 必须包含至少 1 个终止 topic "
                f"({sorted(terminal_topics)})；否则 stream 永不结束。"
                "默认 topics 已包含全部 3 个，自定义 topics 时勿漏。"
            )

        from modules.observability.sink_registry import emit_sdk_audit, emit_sdk_metric

        emit_sdk_metric(
            name="agent.run_stream.calls",
            value=1.0,
            session_id=str(session_id or ""),
            project_id=str(project_id or ""),
        )
        emit_sdk_audit(
            "agent.run_stream.start",
            user_input_preview=user_input[:80],
            session_id=str(session_id or ""),
            topics_count=len(topics_set),
        )

        # 1. 内部事件 queue + 后台线程协调状态
        ev_queue: queue.Queue[Any] = queue.Queue(maxsize=queue_max_size)
        # 用户没传 stop_event 时，本方法注入一个内部的，让 break 能传播 stop
        owned_stop_event = stop_event is None
        effective_stop = stop_event if stop_event is not None else threading.Event()
        # 后台线程协调
        run_done = threading.Event()
        # 终止 flag：terminal topic 命中 / runner 退出 / 异常 → set。
        # 用 Event 而非 queue sentinel：queue 满时 sentinel 会被 drop 导致主
        # 循环卡死（设计教训：早期实现用 sentinel + put_nowait 在 queue=1 时
        # 100% 死锁）；Event 是带外信号，不受 queue 容量影响。
        terminated_event = threading.Event()
        run_result: dict[str, Any] = {"value": None, "error": None}
        dropped_count = {"n": 0}
        # 主循环短轮询步长（防 queue.get 与 terminated 信号的 priority inversion）
        _POLL_STEP = 0.1

        # 2. EventBus subscribe → 把 Event 推入 queue
        tokens: list[str] = []

        def _make_handler(topic: str) -> Callable[[Any], None]:
            is_terminal = topic in terminal_topics

            def _handler(event: Any) -> None:
                # handler 在 EventBus 线程跑，必须超快超无副作用。
                # queue.put_nowait 满 → 记 dropped + warn，但不阻塞 EventBus。
                try:
                    ev_queue.put_nowait(event)
                except queue.Full:
                    dropped_count["n"] += 1
                    if dropped_count["n"] == 1:
                        logger.warning(
                            "Agent.run_stream: ev_queue 已满 (%d)，丢弃事件 type=%s "
                            "(后续丢弃将静默；考虑增大 queue_max_size)",
                            queue_max_size, getattr(event, "type", "?"),
                        )
                # 终止 topic 命中 → 带外 set Event（不依赖 queue，避免 queue 满
                # 时的 deadlock）。AgentV3.run 自己 return 后 runner 线程也会
                # set 一次（幂等）。
                if is_terminal:
                    terminated_event.set()
            return _handler

        for topic in topics_set:
            try:
                token = self._event_bus_reader.subscribe(topic, _make_handler(topic))
                tokens.append(token)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "Agent.run_stream: subscribe(%s) 失败 (non-fatal): %s", topic, exc,
                )

        # 3. 后台线程跑 agent.run
        def _runner() -> None:
            try:
                run_result["value"] = self._agent_v3.run(
                    user_input=user_input,
                    context=context,
                    session_id=session_id,
                    project_id=project_id,
                    stop_event=effective_stop,
                    inbound_messages=inbound_messages,
                    task_context=task_context,
                )
            except BaseException as exc:  # noqa: BLE001 (透传所有异常给主线程)
                run_result["error"] = exc
            finally:
                run_done.set()
                terminated_event.set()  # 兜底：runner 退出必然终止

        run_thread = threading.Thread(
            target=_runner, name=f"sdk-run-stream-{session_id or 'anon'}", daemon=True,
        )
        run_thread.start()

        # 4. 主循环：短轮询 queue + 检查 terminated_event + 累计 idle 计时
        items_yielded = 0
        idle_start = time.monotonic()
        try:
            while True:
                # 先尝试拿队列事件（短超时；不一直 block）
                try:
                    item = ev_queue.get(timeout=_POLL_STEP)
                    yield StreamItem(kind="event", event=item)
                    items_yielded += 1
                    idle_start = time.monotonic()  # 收到事件 → 重置 idle 计时
                    continue
                except queue.Empty:
                    pass

                # queue 空 → 检查终止 / idle timeout
                if terminated_event.is_set():
                    # 让 runner 退出，拿真实 result/error。再读完队列残留事件
                    run_thread.join(timeout=30.0)
                    # 排空队列残留事件（runner 退出前可能已发但还没被消费）
                    while True:
                        try:
                            ev = ev_queue.get_nowait()
                            yield StreamItem(kind="event", event=ev)
                            items_yielded += 1
                        except queue.Empty:
                            break
                    if run_result["error"] is not None:
                        yield StreamItem(kind="error", error=run_result["error"])
                    elif run_result["value"] is not None:
                        yield StreamItem(kind="result", result=run_result["value"])
                    else:
                        # 极端时序：terminal topic 命中但 runner 还没 set value
                        # （join(timeout=30) 已等过；通常足够）
                        yield StreamItem(
                            kind="error",
                            error=RuntimeError(
                                "run_stream: 终止信号已到，但 AgentV3.run 未返回 "
                                "（join 30s 超时）",
                            ),
                        )
                    return

                if idle_timeout is not None and (time.monotonic() - idle_start) > idle_timeout:
                    yield StreamItem(
                        kind="error",
                        error=TimeoutError(
                            f"run_stream idle_timeout={idle_timeout}s 超时 "
                            f"(无新事件；agent 可能卡死)；已 yield {items_yielded} 个事件"
                        ),
                    )
                    return
        finally:
            # 5. 清理：用户 break / 异常 / 正常结束都走这里
            # 5.1 让后台 agent 知道 stop（仅本方法 owned 的 stop_event）
            if owned_stop_event:
                effective_stop.set()
            # 5.2 unsubscribe（避免后续残留事件累积）
            for token in tokens:
                try:
                    self._event_bus_reader.unsubscribe(token)
                except Exception as exc:  # noqa: BLE001
                    logger.debug("run_stream unsubscribe(%s) error: %s", token, exc)
            # 5.3 等 runner 退出（已退出则立即返回）
            if run_thread.is_alive():
                run_thread.join(timeout=10.0)
                if run_thread.is_alive():
                    logger.warning(
                        "Agent.run_stream: runner 线程在 stop_event.set() 后 10s "
                        "仍未退出（agent 可能不响应 stop_event；后台仍跑直到结束）",
                    )
            # 5.4 清队列（防 ringbuffer 累积）
            try:
                while not ev_queue.empty():
                    ev_queue.get_nowait()
            except queue.Empty:
                pass

            emit_sdk_audit(
                "agent.run_stream.complete",
                items_yielded=items_yielded,
                terminated_normally=terminated_event.is_set() and not run_thread.is_alive(),
                runner_alive=run_thread.is_alive(),
                events_dropped=dropped_count["n"],
            )

    def shutdown(self) -> None:
        """清理 plugin（unsubscribe / unregister / call plugin.on_unload）+ 重置内部状态。
        
        PR A3 / S1.15: 也停 HTTP gateway（如启用）。
        """
        with self._lock:
            if self._closed:
                return
            # 先停 HTTP gateway（避免外部还在访问时清理 plugin 状态）
            if self._http_gateway is not None:
                try:
                    self._http_gateway.stop()
                except Exception as exc:  # noqa: BLE001
                    logger.error(
                        "Agent.shutdown: http_gateway.stop() error: %s", exc, exc_info=True,
                    )
                self._http_gateway = None
            for cb in reversed(self._cleanup_callbacks):
                try:
                    cb()
                except Exception as exc:  # noqa: BLE001
                    logger.error("Agent.shutdown cleanup error: %s", exc, exc_info=True)
            self._cleanup_callbacks = []
            self._closed = True


# ────────────────────────────────────────────────────────────────────────
# AgentBuilder（链式 + from_config + from_env）
# ────────────────────────────────────────────────────────────────────────


class AgentBuilder:
    """链式构造 Agent 的入口（design doc §6.1）。

    内部包装现有 ``modules/agent/v3_bootstrap.py:get_v3_agent``，
    对外提供稳定 API；内部实现可自由 refactor。
    """

    SDK_VERSION = "0.1.0"

    def __init__(self) -> None:
        self._api_key: str | None = None
        self._project_root: Path | None = None
        self._budget: BudgetSpec | None = None
        self._act_plugins: list[ACTPlugin] = []
        self._tool_plugins: list[ToolPlugin] = []
        self._gate_plugins: list[GatePlugin] = []
        self._hint_plugins: list[HintPlugin] = []
        self._event_listener_plugins: list[EventListenerPlugin] = []
        self._observability_plugins: list[ObservabilityPlugin] = []
        # Wave 3 experimental（feature flag default off）
        self._mcp_server_plugins: list[MCPServerPlugin] = []
        self._security_plugins: list[SecurityPlugin] = []
        self._domain_pack_plugins: list[DomainPackPlugin] = []
        # Step 2 P2（2026-05-13）：visual_inspect plugin 完整公开。
        # 两条注册路径汇合到 _sdk_state["visual_adapters"]：
        # - _visual_adapter_plugins：通过 with_visual_adapter_plugin(plugin) 注册的实例
        # - _inline_visual_adapters：通过 with_visual_adapter(ext, cls) 直接注册的 (ext, cls) pair
        self._visual_adapter_plugins: list[VisualAdapterPlugin] = []
        self._inline_visual_adapters: list[tuple[str, Any]] = []
        self._ai_manager: AIProviderManager | None = None
        self._loaded_plugin_ids: set[str] = set()
        # Wave 3 sdk_state — domain_pack 展开 + experimental plugin 内部 list（暴露给 Agent）
        self._sdk_state: dict[str, Any] = {}
        # PR A3 / S1.15 HTTP gateway 配置（默认 disabled）
        self._http_gateway_spec: HttpGatewaySpec = HttpGatewaySpec()
        # SDK model selection API（chore/sdk-model-selection-api · 2026-05-15）：
        # 用户显式指定每类模型；优先级 > cloud-model fallback > module_config.json.
        # 6 类对齐 modules.ai.providers.ModelCategory enum.
        # None 表示不指定（走 cloud-model fallback；详 _validate_and_fallback_cloud_models）.
        self._explicit_chat_model: str | None = None
        self._explicit_reasoning_model: str | None = None
        self._explicit_vision_model: str | None = None
        self._explicit_image_gen_model: str | None = None
        self._explicit_image_edit_model: str | None = None
        self._explicit_text_encoder_model: str | None = None
        # Step 2 P2（2026-05-13）：record/replay store 主路径接入。
        # 设置后 build() 自动 install swap；agent.shutdown() 自动 uninstall。
        self._replay_store: Any | None = None

    # ────────── 必须项 ──────────

    def with_krow_api_key(self, api_key: str) -> AgentBuilder:
        """强绑 krow cloud API key 认证（必须项）。

        参数立即校验格式：非 ``sk-`` 前缀 → ``InvalidKrowAPIKeyError``。
        """
        self._api_key = validate_api_key_format(api_key)
        return self

    def with_project_root(self, path: str | Path) -> AgentBuilder:
        """强制声明 project root；不传 build() 时 raise ``MissingProjectRootError``。"""
        self._project_root = Path(path).expanduser().resolve()
        return self

    # ────────── 模型选择 API（chore/sdk-model-selection-api · 2026-05-15）──────────
    # 
    # 6 个 with_<category>_model() method 与 modules.ai.providers.ModelCategory 对齐.
    # 用户在 builder time 指定 model_id（cloud /v1/models 清单内的 string id），
    # build() 时由 _validate_and_fallback_cloud_models 校验 + 透传给 ai_manager.
    # 
    # 设计协议（专家辩论 chore/sdk-model-selection-api，方案 B）：
    # - **System 1 边界**：模型选择是确定性查表，禁止 per-call override（防 LLM 决定 LLM）
    # - **OCP**：cloud 加新 category → SDK 加 1 个 method + 1 个 _explicit_*_model 字段
    # - **错误处理**：用户传 unknown model_id → log warning + fallback（与现有
    #   _validate_and_fallback_cloud_models 行为一致）
    # - **未指定 → 走默认 fallback**（与今天行为完全相同；零 breaking 风险）
    # 
    # 反模式（共通）：
    # - ❌ 在 1 个 builder 实例上对同一 category 调多次 → 最后一次胜出（builder 是 mutable）
    # - ❌ build() 之后改 _explicit_*_model 字段 → 无效（agent 已构造完成）
    # - ❌ 想全局改默认模型 → 用 ``module_config.json`` / ``settings.module_interfaces.krow``,
    #   with_<cat>_model 是单 Agent 实例局部覆盖

    def _validate_model_id(self, category_label: str, model_id: str) -> str:
        """6 个 with_<cat>_model 共用的入参校验（DRY）."""
        if not isinstance(model_id, str) or not model_id.strip():
            raise ValueError(
                f"with_{category_label}_model: model_id 必须非空字符串，got: {model_id!r}"
            )
        return model_id.strip()

    def with_chat_model(self, model_id: str) -> AgentBuilder:
        """显式指定 chat 类别（对话 / 通用 / 代码生成）模型 id.
        
        范例：``with_chat_model("qwen3.6-plus")`` / ``with_chat_model("deepseek-chat")``.
        cloud 当前可选清单 → ``GET /v1/models`` filter ``is_chat=True``.
        
        未指定 → cloud-model fallback 自动选 chat 类别第一个可用模型.
        """
        self._explicit_chat_model = self._validate_model_id("chat", model_id)
        return self

    def with_reasoning_model(self, model_id: str) -> AgentBuilder:
        """显式指定 reasoning 类别（深度推理 / 思维链）模型 id.
        
        范例：``with_reasoning_model("deepseek-reasoner")``.
        cloud 当前可选清单 → ``GET /v1/models`` filter ``is_reasoning=True``.
        """
        self._explicit_reasoning_model = self._validate_model_id("reasoning", model_id)
        return self

    def with_vision_model(self, model_id: str) -> AgentBuilder:
        """显式指定 vision 类别（视觉理解 / VLM）模型 id.
        
        范例：``with_vision_model("qwen2.5-vl-72b-instruct")``.
        cloud 当前可选清单 → ``GET /v1/models`` filter ``is_vision=True``.
        
        Agent 内 ``modules.agent.context_enhancer`` + ``visual_inspect`` /
        ``HeadlessPPTXVisualAdapter`` 等 vision 调用走该模型.
        """
        self._explicit_vision_model = self._validate_model_id("vision", model_id)
        return self

    def with_image_gen_model(self, model_id: str) -> AgentBuilder:
        """显式指定 image_gen 类别（图像生成）模型 id.
        
        范例：``with_image_gen_model("qwen-image")``.
        Agent 内 image generation 工具（如未来的 ``krow_image_create``）走该模型.
        """
        self._explicit_image_gen_model = self._validate_model_id("image_gen", model_id)
        return self

    def with_image_edit_model(self, model_id: str) -> AgentBuilder:
        """显式指定 image_edit 类别（图像编辑）模型 id.
        
        范例：``with_image_edit_model("qwen-image-edit")``.
        """
        self._explicit_image_edit_model = self._validate_model_id("image_edit", model_id)
        return self

    def with_text_encoder_model(self, model_id: str) -> AgentBuilder:
        """显式指定 text_encoder 类别（文本嵌入 / embedding）模型 id.
        
        范例：``with_text_encoder_model("text-embedding-v2")``.
        Agent 内 knowledge / experience memory / vector search 调用走该模型.
        """
        self._explicit_text_encoder_model = self._validate_model_id(
            "text_encoder", model_id,
        )
        return self

    def with_replay_store(self, store: Any) -> AgentBuilder:
        """显式接入 LLM record/replay 框架（Step 2 P2，2026-05-13）。

        让 SDK 用户**不必手动**写 ``wrap_provider_manager_with_replay(store)`` +
        ``finally swap.uninstall()`` —— ``build()`` 时自动 install，
        ``agent.shutdown()`` 时自动 uninstall。

        Args:
            store: 已构造好的 ``LLMReplayStore`` 实例（``from krow_agent_sdk.replay
                import LLMReplayStore``）

        典型用法：

        .. code-block:: python

            from krow_agent_sdk import AgentBuilder
            from krow_agent_sdk.replay import LLMReplayStore

            store = LLMReplayStore.from_env("fixtures/my_test.json")
            agent = (
                AgentBuilder()
                .with_krow_api_key(api_key)
                .with_project_root(p)
                .with_replay_store(store)
                .build()
            )
            try:
                result = agent.run("...")
            finally:
                agent.shutdown()  # 自动 uninstall replay swap

        校验：
        - ``store`` 必须有 ``mode``、``get`` / ``put`` 方法（duck typing 兼容
          ``LLMReplayStore``，不强制 isinstance —— SDK Step 2+ 用户可能 wrap）
        - 不可重复调用：第二次 ``with_replay_store(other)`` 覆盖第一个
        """
        if not hasattr(store, "mode") or not callable(getattr(store, "get", None)):
            raise ValueError(
                f"with_replay_store: store 必须是 LLMReplayStore-like 对象（mode + "
                f"get/put 方法），got: {type(store).__name__}"
            )
        self._replay_store = store
        return self

    @classmethod
    def from_env(cls) -> AgentBuilder:
        """快捷启动：从 ``KROW_API_KEY`` env var 读 api_key + ``KROW_PROJECT_ROOT`` 读项目根。

        api_key 缺失 raise ``MissingKrowAPIKeyError``；project_root 缺失 raise ``MissingProjectRootError``。
        """
        builder = cls()
        builder._api_key = read_api_key_from_env()  # noqa: SLF001
        project_root_str = read_project_root_from_env()
        if project_root_str:
            builder._project_root = Path(project_root_str).expanduser().resolve()  # noqa: SLF001
        return builder

    @classmethod
    def from_config(cls, config: BuilderConfig) -> AgentBuilder:
        """从 ``BuilderConfig`` dataclass 一次性构造（A5 god class 缓解）。"""
        builder = cls()
        builder._api_key = validate_api_key_format(config.api_key)  # noqa: SLF001
        builder._project_root = Path(config.project_root).expanduser().resolve()  # noqa: SLF001
        builder._budget = config.budget  # noqa: SLF001
        builder._act_plugins = list(config.act_plugins)  # noqa: SLF001
        builder._tool_plugins = list(config.tool_plugins)  # noqa: SLF001
        builder._gate_plugins = list(config.gate_plugins)  # noqa: SLF001
        builder._hint_plugins = list(config.hint_plugins)  # noqa: SLF001
        builder._event_listener_plugins = list(config.event_listener_plugins)  # noqa: SLF001
        builder._observability_plugins = list(config.observability_plugins)  # noqa: SLF001
        builder._mcp_server_plugins = list(config.mcp_server_plugins)  # noqa: SLF001
        builder._security_plugins = list(config.security_plugins)  # noqa: SLF001
        builder._domain_pack_plugins = list(config.domain_pack_plugins)  # noqa: SLF001
        builder._visual_adapter_plugins = list(config.visual_adapter_plugins)  # noqa: SLF001
        builder._inline_visual_adapters = list(config.inline_visual_adapters)  # noqa: SLF001
        builder._ai_manager = config.ai_manager  # noqa: SLF001
        return builder

    # ────────── Plugin 注入（直接） ──────────

    def with_act_plugin(self, plugin: ACTPlugin) -> AgentBuilder:
        """直接注册 ACTPlugin 实例（不走 entry_points；Wave 1 主路径）。"""
        self._act_plugins.append(plugin)
        return self

    def with_tool_plugin(self, plugin: ToolPlugin) -> AgentBuilder:
        """直接注册 ToolPlugin 实例。"""
        self._tool_plugins.append(plugin)
        return self

    def with_gate_plugin(self, plugin: GatePlugin) -> AgentBuilder:
        """直接注册 GatePlugin 实例。"""
        self._gate_plugins.append(plugin)
        return self
    
    # ────────── PR B1 / S2.1-3 entry_points 自动发现 ──────────
    
    def with_act_plugins_from_entry_points(self, *, force: bool = False) -> AgentBuilder:
        """自动扫描 ``krow.act`` group 下所有 ACTPlugin entry_points + 注册（PR B1 / S2.1）。
        
        外部 plugin 包通过 pyproject.toml 暴露：
        ```toml
        [project.entry-points."krow.act"]
        my_research_act = "my_pkg.plugins:MyResearchACTPlugin"
        ```
        
        SDK 自动 ``ep.load()()`` 实例化后走 ``with_act_plugin()`` 标准加载链。
        单条 plugin 加载失败仅 log warning，不阻塞其他。

        Feature flag (PR B3 / S2.9)：默认仅当 ``KROW_ENABLE_PLUGIN_ENTRY_POINTS=1``
        时真扫描；``force=True`` 可强制 override env。
        """
        from .entry_points import (
            GROUP_ACT,
            discover_plugins_for_protocol,
            is_plugin_entry_points_enabled,
        )

        if not force and not is_plugin_entry_points_enabled():
            logger.debug(
                "with_act_plugins_from_entry_points: KROW_ENABLE_PLUGIN_ENTRY_POINTS 未启用，已跳过扫描"
            )
            return self
        from .protocols.act import ACTPlugin as ACTPluginCls
        
        plugins = discover_plugins_for_protocol(
            GROUP_ACT, ACTPluginCls,
        )
        self._act_plugins.extend(plugins)
        if plugins:
            logger.info("entry_points: 加载 %d 个 ACTPlugin (group=%s)", len(plugins), GROUP_ACT)
        return self
    
    def with_tool_plugins_from_entry_points(self, *, force: bool = False) -> AgentBuilder:
        """自动扫描 ``krow.tool`` group 下所有 ToolPlugin entry_points + 注册（PR B1 / S2.2）。

        Feature flag (PR B3 / S2.9)：默认仅当 ``KROW_ENABLE_PLUGIN_ENTRY_POINTS=1`` 时扫描。
        """
        from .entry_points import (
            GROUP_TOOL,
            discover_plugins_for_protocol,
            is_plugin_entry_points_enabled,
        )

        if not force and not is_plugin_entry_points_enabled():
            return self
        from .protocols.tool import ToolPlugin as ToolPluginCls

        plugins = discover_plugins_for_protocol(GROUP_TOOL, ToolPluginCls)
        self._tool_plugins.extend(plugins)
        if plugins:
            logger.info("entry_points: 加载 %d 个 ToolPlugin (group=%s)", len(plugins), GROUP_TOOL)
        return self

    def with_gate_plugins_from_entry_points(self, *, force: bool = False) -> AgentBuilder:
        """自动扫描 ``krow.gate`` group 下所有 GatePlugin entry_points + 注册（PR B1 / S2.3）。

        Feature flag (PR B3 / S2.9)：默认仅当 ``KROW_ENABLE_PLUGIN_ENTRY_POINTS=1`` 时扫描。
        """
        from .entry_points import (
            GROUP_GATE,
            discover_plugins_for_protocol,
            is_plugin_entry_points_enabled,
        )

        if not force and not is_plugin_entry_points_enabled():
            return self
        from .protocols.gate import GatePlugin as GatePluginCls

        plugins = discover_plugins_for_protocol(GROUP_GATE, GatePluginCls)
        self._gate_plugins.extend(plugins)
        if plugins:
            logger.info("entry_points: 加载 %d 个 GatePlugin (group=%s)", len(plugins), GROUP_GATE)
        return self

    def with_hint_plugin(self, plugin: HintPlugin) -> AgentBuilder:
        """直接注册 ``HintPlugin`` 实例（Wave 2 P3 真实加载）。

        SDK build() 时把 ``plugin.hint_for(context)`` 注册到进程级 ``HintRegistry``；
        主仓 prompt 拼装钩子调 ``render_hints(context)`` fan-out。
        """
        self._hint_plugins.append(plugin)
        return self

    def with_event_listener_plugin(self, plugin: EventListenerPlugin) -> AgentBuilder:
        """直接注册 ``EventListenerPlugin`` 实例（Wave 2 P5 真实加载）。

        SDK build() 时遍历 ``plugin.get_subscriptions()`` 逐个调 ``EventBus.subscribe``。
        ``Agent.shutdown()`` 时反向 ``unsubscribe``。
        """
        self._event_listener_plugins.append(plugin)
        return self

    def with_observability_plugin(self, plugin: ObservabilityPlugin) -> AgentBuilder:
        """直接注册 ``ObservabilityPlugin`` 实例（Wave 2 P6 真实加载）。

        SDK build() 时调 ``plugin.register(facade)``，plugin 在内部用
        ``facade.add_metric_sink(callback)`` / ``add_trace_sink`` / ``add_audit_sink``
        把回调挂到进程级 ``SinkRegistry``。
        """
        self._observability_plugins.append(plugin)
        return self

    # ────────── Plugin 注入（experimental，Wave 3 PR S1.11 + 骨架激活）──────────

    def with_mcp_server_plugin(self, plugin: MCPServerPlugin) -> AgentBuilder:
        """注册 ``MCPServerPlugin`` 实例（Wave 3 骨架激活，feature flag default off）。

        当前实现：plugin_id 注册到 ``loaded_plugin_ids`` + ``plugin.get_servers()``
        合并到 SDK 内部 list（``Agent.mcp_servers`` 暴露）。**不接** 主仓
        ``McpServiceRegistry``——主仓内部 MCP 与外部 plugin MCP 是不同形态（详
        design doc §5.7 + §9.3 Step 3）。
        """
        self._mcp_server_plugins.append(plugin)
        return self

    def with_security_plugin(self, plugin: SecurityPlugin) -> AgentBuilder:
        """注册 ``SecurityPlugin`` 实例（Wave 3 骨架激活，feature flag default off）。

        当前实现：plugin_id 注册到 ``loaded_plugin_ids`` + ``plugin.get_policies()``
        合并到 SDK 内部 list（``Agent.security_policies`` 暴露）。**不做**强沙箱拦截
        （强沙箱推 Step 3 subprocess / VM 隔离）。
        """
        self._security_plugins.append(plugin)
        return self

    def with_domain_pack_plugin(self, plugin: DomainPackPlugin) -> AgentBuilder:
        """注册 ``DomainPackPlugin`` 实例（Wave 3 P9 真实展开）。

        SDK build() 时把 plugin 8 个 OPTIONAL 元素一次性展开为多个底层 registry 注册：
        hint → HintRegistry / tool → ToolManager / gate → GateRegistry /
        event_listener → EventBus / mcp_server / security / supplementary_md /
        recommended_budget → SDK 内部 list。详 ``domain_pack_expander.py``。
        """
        self._domain_pack_plugins.append(plugin)
        return self

    # ────────── Step 2 P2（2026-05-13）visual_inspect plugin 完整公开 ──────────

    def with_visual_adapter(
        self, extension: str, adapter_class: Any,
    ) -> AgentBuilder:
        """注册单个 (file_extension, VisualAdapter class) — 不必组装 plugin（Step 2 P2）.

        最小可行用法：

        ```python
        from krow_agent_sdk.visual import VisualAdapter

        class CADVisualAdapter(VisualAdapter):
            def open(self, source, **kwargs): ...
            def close(self): ...
            def render(self, page_index, width=960, height=540): ...
            def inventory(self, page_index): ...
            def page_count(self): ...

        agent = (
            AgentBuilder()
            .with_krow_api_key("sk-user-...")
            .with_visual_adapter(".dwg", CADVisualAdapter)
            .with_visual_adapter(".step", CADVisualAdapter)
            .build()
        )
        ```

        参数：
            extension: 文件扩展名（必须以 ``.`` 开头）；不区分大小写，内部归一为小写
            adapter_class: ``VisualAdapter`` 子类（推荐传 class，延迟实例化）
                           或者已实例化的 adapter（不推荐，多文件共享时 open/close 状态可能撞）

        返回 ``self`` 支持链式调用.

        与 ``with_visual_adapter_plugin(plugin)`` 关系：两条路径汇合到
        ``_sdk_state["visual_adapters"]``，``Agent.visual_adapters`` property 暴露汇总.
        """
        if not isinstance(extension, str) or not extension.startswith("."):
            raise ValueError(
                f"visual adapter extension 必须是以 '.' 开头的字符串，"
                f"如 '.dwg' / '.pdf'，你传了 {extension!r}。"
            )
        ext_normalized = extension.lower()
        self._inline_visual_adapters.append((ext_normalized, adapter_class))
        return self

    def with_default_pptx_adapter(self) -> AgentBuilder:
        """一行接入 ``HeadlessPPTXVisualAdapter`` 视觉质检管线（PR-7, 2026-05-16）.

        路线图：``docs/governance/pptx-geometry-quality-roadmap.md`` Batch 3 PR-7.

        与函数式 :func:`krow_agent_sdk.visual.register_default_pptx_adapter`
        的区别：本方法仅在 ``build()`` 后该 Agent 生命周期内生效；``shutdown()``
        会自动 unregister，避免多 Agent 场景下的全局 registry 污染.

        典型用法：

        ```python
        agent = (
            AgentBuilder()
            .with_krow_api_key("sk-user-...")
            .with_default_pptx_adapter()
            .build()
        )
        # 现在 agent.run("生成 PPT 并验证") 中的 visual_inspect 工具能正确处理 .pptx
        ```

        依赖准备
        --------

        要求 ``krow-agent-sdk[visual]`` extra（cairosvg + cairocffi + lxml +
        Pillow）+ 系统库 ``libcairo2 + libpango + fonts-noto-cjk``（Linux）.

        失败兜底
        --------

        当 ``HeadlessPPTXVisualAdapter`` 不可导入时，本方法**不抛异常**——记录
        warning 后返回 ``self``（不影响 builder 链式调用）；real render 时
        ``visual_inspect`` 会返回结构化 ``render_available=false`` 而非崩溃.

        Returns:
            ``self`` 支持链式调用.
        """
        try:
            from modules.agent.visual.adapters.headless_pptx_adapter import (
                HeadlessPPTXVisualAdapter,
            )
            self._inline_visual_adapters.append(
                (".pptx", HeadlessPPTXVisualAdapter),
            )
            logger.info(
                "AgentBuilder.with_default_pptx_adapter: "
                "queued HeadlessPPTXVisualAdapter for .pptx",
            )
        except ImportError as exc:
            logger.warning(
                "AgentBuilder.with_default_pptx_adapter: "
                "HeadlessPPTXVisualAdapter 不可导入，跳过 .pptx 注册 "
                "(%s)。是否漏装 krow-agent-sdk[visual] extra？",
                exc,
            )
        return self

    def with_visual_adapter_plugin(
        self, plugin: VisualAdapterPlugin,
    ) -> AgentBuilder:
        """注册 ``VisualAdapterPlugin`` 实例（Step 2 P2，experimental P10）.

        plugin 通过 ``get_visual_adapters() -> list[(ext, cls)]`` 一次性返回多对.
        与 ``with_visual_adapter(ext, cls)`` 区别：plugin 形态可走 entry_points
        自动发现，且支持 ``on_load`` / ``on_unload`` lifecycle hook.

        ```python
        class CADPlugin:
            plugin_id = "cad-vis-2026"
            def get_visual_adapters(self):
                return [(".dwg", CADVisualAdapter), (".step", CADVisualAdapter)]

        agent = (
            AgentBuilder()
            .with_krow_api_key("sk-user-...")
            .with_visual_adapter_plugin(CADPlugin())
            .build()
        )
        ```
        """
        self._visual_adapter_plugins.append(plugin)
        return self

    # ────────── PR B2 / S2.4-6 + S2.15 P3/P5/P6/P9 entry_points 自动发现 ──────────

    def with_hint_plugins_from_entry_points(self, *, force: bool = False) -> AgentBuilder:
        """自动扫描 ``krow.hint`` group 下所有 HintPlugin entry_points + 注册（PR B2 / S2.4）。

        Feature flag (PR B3 / S2.9)：默认仅当 ``KROW_ENABLE_PLUGIN_ENTRY_POINTS=1`` 时扫描。
        """
        from .entry_points import (
            GROUP_HINT,
            discover_plugins_for_protocol,
            is_plugin_entry_points_enabled,
        )

        if not force and not is_plugin_entry_points_enabled():
            return self
        from .protocols.hint import HintPlugin as HintPluginCls

        plugins = discover_plugins_for_protocol(GROUP_HINT, HintPluginCls)
        self._hint_plugins.extend(plugins)
        if plugins:
            logger.info("entry_points: 加载 %d 个 HintPlugin (group=%s)", len(plugins), GROUP_HINT)
        return self

    def with_event_listener_plugins_from_entry_points(self, *, force: bool = False) -> AgentBuilder:
        """自动扫描 ``krow.event_listener`` group 下所有 EventListenerPlugin entry_points + 注册（PR B2 / S2.5）。

        Feature flag (PR B3 / S2.9)：默认仅当 ``KROW_ENABLE_PLUGIN_ENTRY_POINTS=1`` 时扫描。
        """
        from .entry_points import (
            GROUP_EVENT_LISTENER,
            discover_plugins_for_protocol,
            is_plugin_entry_points_enabled,
        )

        if not force and not is_plugin_entry_points_enabled():
            return self
        from .protocols.event_listener import EventListenerPlugin as EventListenerPluginCls

        plugins = discover_plugins_for_protocol(GROUP_EVENT_LISTENER, EventListenerPluginCls)
        self._event_listener_plugins.extend(plugins)
        if plugins:
            logger.info(
                "entry_points: 加载 %d 个 EventListenerPlugin (group=%s)",
                len(plugins), GROUP_EVENT_LISTENER,
            )
        return self

    def with_observability_plugins_from_entry_points(self, *, force: bool = False) -> AgentBuilder:
        """自动扫描 ``krow.observability`` group 下所有 ObservabilityPlugin entry_points + 注册（PR B2 / S2.6）。

        Feature flag (PR B3 / S2.9)：默认仅当 ``KROW_ENABLE_PLUGIN_ENTRY_POINTS=1`` 时扫描。
        """
        from .entry_points import (
            GROUP_OBSERVABILITY,
            discover_plugins_for_protocol,
            is_plugin_entry_points_enabled,
        )

        if not force and not is_plugin_entry_points_enabled():
            return self
        from .protocols.observability import ObservabilityPlugin as ObservabilityPluginCls

        plugins = discover_plugins_for_protocol(GROUP_OBSERVABILITY, ObservabilityPluginCls)
        self._observability_plugins.extend(plugins)
        if plugins:
            logger.info(
                "entry_points: 加载 %d 个 ObservabilityPlugin (group=%s)",
                len(plugins), GROUP_OBSERVABILITY,
            )
        return self

    def with_domain_pack_plugins_from_entry_points(self, *, force: bool = False) -> AgentBuilder:
        """自动扫描 ``krow.domain_pack`` group 下所有 DomainPackPlugin entry_points + 注册（PR B2 / S2.15）。

        DomainPackPlugin 是"语法糖" plugin，build() 时 ``domain_pack_expander.py``
        会把它一次性展开为多个底层 registry 注册（hint / tool / gate / 等）。

        Feature flag (PR B3 / S2.9)：默认仅当 ``KROW_ENABLE_PLUGIN_ENTRY_POINTS=1`` 时扫描。
        """
        from .entry_points import (
            GROUP_DOMAIN_PACK,
            discover_plugins_for_protocol,
            is_plugin_entry_points_enabled,
        )

        if not force and not is_plugin_entry_points_enabled():
            return self
        from .experimental.protocols.domain_pack import DomainPackPlugin as DomainPackPluginCls

        plugins = discover_plugins_for_protocol(GROUP_DOMAIN_PACK, DomainPackPluginCls)
        self._domain_pack_plugins.extend(plugins)
        if plugins:
            logger.info(
                "entry_points: 加载 %d 个 DomainPackPlugin (group=%s)",
                len(plugins), GROUP_DOMAIN_PACK,
            )
        return self

    def with_visual_adapter_plugins_from_entry_points(
        self, *, force: bool = False,
    ) -> AgentBuilder:
        """自动扫描 ``krow.visual_adapter`` group 下所有 VisualAdapterPlugin entry_points + 注册（Step 2 P2）.

        Feature flag (PR B3 / S2.9)：默认仅当 ``KROW_ENABLE_PLUGIN_ENTRY_POINTS=1`` 时扫描.
        """
        from .entry_points import (
            GROUP_VISUAL_ADAPTER,
            discover_plugins_for_protocol,
            is_plugin_entry_points_enabled,
        )

        if not force and not is_plugin_entry_points_enabled():
            return self
        from .experimental.protocols.visual_adapter import (
            VisualAdapterPlugin as VisualAdapterPluginCls,
        )

        plugins = discover_plugins_for_protocol(
            GROUP_VISUAL_ADAPTER, VisualAdapterPluginCls,
        )
        self._visual_adapter_plugins.extend(plugins)
        if plugins:
            logger.info(
                "entry_points: 加载 %d 个 VisualAdapterPlugin (group=%s)",
                len(plugins), GROUP_VISUAL_ADAPTER,
            )
        return self

    def with_all_plugins_from_entry_points(self, *, force: bool = False) -> AgentBuilder:
        """一次性扫描全部 7 个 protocol 的 entry_points（PR B2 便捷 API）。

        等价于按顺序调 7 个独立 ``with_*_plugins_from_entry_points()`` 方法
        （ACT/Tool/Gate/Hint/EventListener/Observability/DomainPack）；
        MCPServer / Security 仍属 Wave 3 experimental，不在自动扫描范围。

        Feature flag (PR B3 / S2.9)：默认仅当 ``KROW_ENABLE_PLUGIN_ENTRY_POINTS=1`` 时扫描；
        ``force=True`` 透传到所有底层方法。
        """
        return (
            self.with_act_plugins_from_entry_points(force=force)
            .with_tool_plugins_from_entry_points(force=force)
            .with_gate_plugins_from_entry_points(force=force)
            .with_hint_plugins_from_entry_points(force=force)
            .with_event_listener_plugins_from_entry_points(force=force)
            .with_observability_plugins_from_entry_points(force=force)
            .with_domain_pack_plugins_from_entry_points(force=force)
            .with_visual_adapter_plugins_from_entry_points(force=force)
        )

    # ────────── 测试注入 ──────────

    def with_ai_manager(self, ai_manager: AIProviderManager) -> AgentBuilder:
        """注入 ``AIProviderManager`` 实例（用于 LLMReplayStore 测试）。"""
        self._ai_manager = ai_manager
        return self

    def with_budget(self, budget: BudgetSpec) -> AgentBuilder:
        self._budget = budget
        return self
    
    # ────────── PR A3 / S1.15 HTTP Gateway ──────────
    
    def with_http_gateway(
        self,
        *,
        enable: bool = True,
        host: str = "127.0.0.1",
        port: int = 8090,
        auth_token: str | None = None,
        dry_run: bool = False,
    ) -> AgentBuilder:
        """启用 HTTP / WS / SSE 网关，让外部 UI 通过 HTTP 接 SDK Agent（PR A3 / S1.15）。
        
        实现：包装主仓 ``modules.remote.api_gateway.APIServer``，独立实例（不污染主仓
        KrowService 单例）。``build()`` 末尾启动；``Agent.shutdown()`` 自动停止。
        
        feature flag 双轨：
        - 显式：``builder.with_http_gateway(enable=True, host=..., port=...)``
        - env：``KROW_SDK_HTTP_GATEWAY=1`` 时 default host/port 自动启用
        
        Args:
            enable: 是否启用（默认 True）
            host: 绑定 host（默认 ``127.0.0.1`` 仅本地）；生产可设 ``0.0.0.0``
            port: 端口（默认 8090，避开主仓 KrowService 9527）
            auth_token: 预留（Wave B 接 bearer middleware）
            dry_run: 测试用；不真启 uvicorn 仅占位
        
        Returns: self（fluent）
        """
        self._http_gateway_spec = HttpGatewaySpec(
            enabled=bool(enable),
            host=str(host),
            port=int(port),
            auth_token=auth_token,
            dry_run=bool(dry_run),
        )
        return self

    # ────────── 构造 ──────────

    def build(
        self,
        *,
        validate_connection: bool | None = None,
        on_progress: Callable[[str, dict], None] | None = None,
        on_thinking: Callable[[str], None] | None = None,
        on_report: Callable[[Any], None] | None = None,
        on_todo_created: Callable[[list], None] | None = None,
        on_todo_update: Callable[[str, Any], None] | None = None,
    ) -> Agent:
        """构造 Agent；缺失必须项 → fail-loud。

        Args:
            validate_connection: 是否做启动期连接验证（GET /v1/models + project_root 写权限测试 +
                plugin signature 校验）。``None`` 时读 ``KROW_SDK_BUILD_VALIDATE_CONNECTION``
                env var（default 1）。
            on_progress / on_thinking / on_report / on_todo_*: AgentV3 的 5 个 callback 透传。

        Raises:
            MissingKrowAPIKeyError: api_key 缺失
            MissingProjectRootError: project_root 缺失
            ProjectRootNotWritableError: validate_connection 时 project_root 不可写
            PluginSignatureMismatchError: plugin 签名不匹配契约
            DuplicatePluginIDError: plugin_id 撞名
        """
        # 1. 必须项校验
        if not self._api_key:
            raise MissingKrowAPIKeyError()
        if self._project_root is None:
            raise MissingProjectRootError()

        # 2. validate_connection 决策
        if validate_connection is None:
            validate_connection = os.environ.get(ENV_BUILD_VALIDATE, "1").strip() != "0"

        # 3. project_root 写权限测试（A6）
        if validate_connection:
            self._validate_project_root_writable(self._project_root)

        # 4. 设 project_context（让主仓 native 工具可用）
        from modules.utils.project_context import set_project_root
        set_project_root(self._project_root)

        # 4b. PR A1 完善（2026-05-12）：把 api_key 注入全局 KrowAuthAdapter 单例。
        # 之前仅 store 到 builder + _validate_api_key_connection 用临时 adapter
        # 实例（_validate_api_key_connection），导致主路径走 KrowLLMProvider 时单例
        # 没认证 → AuthExpiredError 401（Tier-2 真实 LLM E2E 实测）。现在 build()
        # 内自动注入，外部 SDK 用户直接拿到可调真实 LLM 的 agent。
        try:
            from modules.auth.krow_auth import get_krow_auth_adapter
            get_krow_auth_adapter().set_api_key(self._api_key)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "build(): failed to inject api_key to global KrowAuthAdapter "
                "(LLM calls may fail): %s", exc,
            )

        # 5. plugin signature 校验（A1 / R26）
        self._validate_all_plugins()

        # 6. ai_manager 准备（按优先级：注入 → 全局已初始化 → app.container 标准路径 → 空 manager）
        ai_manager = self._ai_manager
        if ai_manager is None:
            ai_manager = _ensure_ai_manager()

        # 7. (validate_connection) 不在 Wave 1 真接 GET /v1/models 验证 api_key
        #    Wave 2 PR S1.17 配 KrowAuthAdapter.set_api_key 修复后接入
        if validate_connection and ai_manager is not None and self._ai_manager is None:
            # 仅在 ai_manager 是默认初始化时尝试 ping；测试注入的 mock 不验
            self._validate_api_key_connection(self._api_key)

        # 7b. (TODO-2 完善 2026-05-12): 检测默认模型与 cloud 真实清单脱节 → fallback。
        #     必须在 step 6 (_ensure_ai_manager) 之**后**做：那时 lpm._llm_providers 才
        #     有 'Krow (远程)' provider 可改。改 ModelConfig.model_name 后，下次
        #     ReACTEngine 调 ``llm_manager.get_chat_model`` 走 ``_get_model_provider``
        #     重新创建 KrowLLMProviderAdapter（用 fallback model）。
        #     根因：``config/module_config.json`` 默认 ``claude-opus-4.6``，但开发者
        #     的 cloud 账号在某些时段 ``/v1/models`` 不返 claude（区域受限 / 服务降级）
        #     → 用旧 model 调 chat_stream 报 401 "登录已过期"（误诊；实际是模型名不存在）。
        if validate_connection and self._ai_manager is None:
            try:
                self._validate_and_fallback_cloud_models()
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "build(): cloud-model fallback check failed (non-fatal): %s", exc,
                )

        # SDK model selection API（chore/sdk-model-selection-api · 2026-05-15）：
        # vision / image_gen / image_edit / text_encoder 4 个 category 的 user override
        # 通过本步注入下层 ai_manager 的 ProviderConfig.model_name.
        # 与 chat/reasoning 在 _validate_and_fallback_cloud_models 内的逻辑
        # 同源（同样改 model_name 字段）；分开是因为 chat/reasoning 走 LLMProviderManager
        # 上层抽象，aux 4 类走下层 AIProviderManager 单 provider 实例.
        try:
            self._apply_explicit_aux_model_overrides()
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "build(): apply_explicit_aux_model_overrides failed (non-fatal): %s",
                exc,
            )

        # 8. 加载 plugin（lifecycle on_load + 真实注册到主仓 manager）
        from modules.events.bus import EventBus
        event_bus = EventBus.get_instance()
        cleanup_callbacks: list[Callable[[], None]] = []
        
        # 8a. Step 2 P2（2026-05-13）：record/replay store 主路径接入。
        # 必须在 ai_manager + lpm 已就绪（step 6/7b）之后；
        # plugin 加载之前（让 plugin lifecycle on_load 期 LLM 调用也走 swap）。
        if self._replay_store is not None:
            try:
                from .replay import wrap_provider_manager_with_replay
                _replay_swap = wrap_provider_manager_with_replay(self._replay_store)
                
                def _uninstall_replay() -> None:
                    try:
                        _replay_swap.uninstall()
                    except Exception as exc:  # noqa: BLE001
                        logger.debug(
                            "with_replay_store: uninstall failed (non-fatal): %s", exc,
                        )
                
                cleanup_callbacks.append(_uninstall_replay)
                logger.info(
                    "Step 2 P2: replay store 已接入主路径（mode=%s, fixture=%s）",
                    self._replay_store.mode, self._replay_store.path,
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "with_replay_store: install 失败（continue without replay）：%s", exc,
                )

        sdk_context_factory = lambda plugin_id: SDKContext(  # noqa: E731
            plugin_id=plugin_id,
            project_root=self._project_root,  # type: ignore[arg-type]
            logger=logging.getLogger(f"krow_agent_sdk.plugin.{plugin_id}"),
            event_bus=EventBusReader(event_bus),
            sdk_version=self.SDK_VERSION,
        )

        for plugin in self._act_plugins:
            self._load_act_plugin(plugin, sdk_context_factory, cleanup_callbacks)
        for plugin in self._tool_plugins:
            self._load_tool_plugin(plugin, sdk_context_factory, cleanup_callbacks)
        for plugin in self._gate_plugins:
            self._load_gate_plugin(plugin, sdk_context_factory, cleanup_callbacks)
        for plugin in self._hint_plugins:
            self._load_hint_plugin(plugin, sdk_context_factory, cleanup_callbacks)
        for plugin in self._event_listener_plugins:
            self._load_event_listener_plugin(plugin, sdk_context_factory, cleanup_callbacks, event_bus)
        for plugin in self._observability_plugins:
            self._load_observability_plugin(plugin, sdk_context_factory, cleanup_callbacks)
        # Wave 3 experimental
        for plugin in self._mcp_server_plugins:
            self._load_mcp_server_plugin(plugin, sdk_context_factory, cleanup_callbacks)
        for plugin in self._security_plugins:
            self._load_security_plugin(plugin, sdk_context_factory, cleanup_callbacks)
        for plugin in self._domain_pack_plugins:
            self._load_domain_pack_plugin(plugin, sdk_context_factory, cleanup_callbacks, event_bus)
        # Step 2 P2：visual adapter — plugin 路径 + inline 直接注册路径汇合
        # v0.9.x · PR 5.5：两条路径都同步注册到 visual_grounding_tools registry，
        # cleanup 对称 unregister（避免多 Agent / 测试污染全局 registry）
        for plugin in self._visual_adapter_plugins:
            self._load_visual_adapter_plugin(plugin, sdk_context_factory, cleanup_callbacks)
        if self._inline_visual_adapters:
            self._load_inline_visual_adapters(cleanup_callbacks)

        # 9. 调 bootstrap_v3 + get_v3_agent（真实拿 AgentV3）
        from modules.agent.v3_bootstrap import bootstrap_v3, get_v3_agent
        bootstrap_v3(ai_manager=ai_manager)
        agent_v3 = get_v3_agent(
            ai_manager=ai_manager,
            on_progress=on_progress,
            on_thinking=on_thinking,
            on_report=on_report,
            on_todo_created=on_todo_created,
            on_todo_update=on_todo_update,
        )
        if agent_v3 is None:
            raise RuntimeError("get_v3_agent returned None; V3 not available")
        
        # 9.5 PR A3 / S1.15: HTTP Gateway 启动（feature flag 双轨）
        http_gateway_handle = self._maybe_start_http_gateway()

        # 10. 包装成 SDK Agent
        return Agent(
            agent_v3=agent_v3,
            event_bus=event_bus,
            plugin_ids=sorted(self._loaded_plugin_ids),
            cleanup_callbacks=cleanup_callbacks,
            sdk_state=dict(self._sdk_state),
            http_gateway=http_gateway_handle,
        )
    
    def _maybe_start_http_gateway(self) -> _HttpGatewayHandle | None:
        """根据 spec + env feature flag 决定是否启 HTTP gateway。
        
        优先级：
        1. 显式 ``with_http_gateway(enable=True)`` → 启
        2. env ``KROW_SDK_HTTP_GATEWAY=1`` → 启（host/port 走 spec default）
        3. 否则 → 不启，返 None
        """
        spec = self._http_gateway_spec
        env_flag = os.environ.get(ENV_HTTP_GATEWAY, "0").strip() != "0"
        should_start = bool(spec.enabled) or env_flag
        
        if not should_start:
            return None
        
        handle = _HttpGatewayHandle(
            host=spec.host,
            port=spec.port,
            auth_token=spec.auth_token,
            dry_run=spec.dry_run,
        )
        try:
            handle._start()  # noqa: SLF001
        except Exception as exc:  # noqa: BLE001
            # 启动失败不阻塞 build（log warning）— 设计文档 §6.1: gateway 是 nice-to-have
            logger.warning(
                "HTTP Gateway start failed (build continues): %s", exc, exc_info=True,
            )
            return None
        return handle

    # ────────── Plugin 加载子流程 ──────────

    def _validate_all_plugins(self) -> None:
        """启动期校验所有 plugin。

        ``plugin_id`` 在 SDK 内**按 protocol 维度独立判重**——
        同一 plugin pack 完全可同时实现 P1 + P2 + P4 共享同一 plugin_id（这是常态）；
        但同一 protocol 下两个 instance 共享 plugin_id 视为撞名 fail-loud。
        """
        from .experimental.protocols.domain_pack import DomainPackPlugin as DomainPackCls
        from .experimental.protocols.mcp_server import MCPServerPlugin as MCPServerCls
        from .experimental.protocols.security import SecurityPlugin as SecurityCls
        from .protocols.act import ACTPlugin as ACTPluginCls
        from .protocols.event_listener import EventListenerPlugin as EventListenerCls
        from .protocols.gate import GatePlugin as GatePluginCls
        from .protocols.hint import HintPlugin as HintPluginCls
        from .protocols.observability import ObservabilityPlugin as ObservabilityCls
        from .protocols.tool import ToolPlugin as ToolPluginCls

        seen_per_protocol: dict[str, set[str]] = {}
        all_plugins: list[tuple[Any, type, str]] = (
            [(p, ACTPluginCls, "ACTPlugin") for p in self._act_plugins]
            + [(p, ToolPluginCls, "ToolPlugin") for p in self._tool_plugins]
            + [(p, GatePluginCls, "GatePlugin") for p in self._gate_plugins]
            + [(p, HintPluginCls, "HintPlugin") for p in self._hint_plugins]
            + [(p, EventListenerCls, "EventListenerPlugin") for p in self._event_listener_plugins]
            + [(p, ObservabilityCls, "ObservabilityPlugin") for p in self._observability_plugins]
            + [(p, MCPServerCls, "MCPServerPlugin") for p in self._mcp_server_plugins]
            + [(p, SecurityCls, "SecurityPlugin") for p in self._security_plugins]
            + [(p, DomainPackCls, "DomainPackPlugin") for p in self._domain_pack_plugins]
        )
        for plugin, protocol, label in all_plugins:
            plugin_id = getattr(plugin, "plugin_id", "<unknown>")
            validate_plugin_id(plugin_id)
            seen_in_protocol = seen_per_protocol.setdefault(label, set())
            if plugin_id in seen_in_protocol:
                raise DuplicatePluginIDError(
                    plugin_id=plugin_id,
                    conflict_entry=f"{label}({type(plugin).__name__})",
                    existing_entry=f"previous {label}",
                )
            seen_in_protocol.add(plugin_id)
            validate_protocol_implementation(plugin, protocol, plugin_id=plugin_id)

    def _load_act_plugin(
        self,
        plugin: ACTPlugin,
        sdk_context_factory: Callable[[str], SDKContext],
        cleanup_callbacks: list[Callable[[], None]],
    ) -> None:
        plugin_id = plugin.plugin_id
        ctx = sdk_context_factory(plugin_id)
        try:
            call_on_load_if_implemented(plugin, ctx)
            from modules.agent.act.act_loader import get_act_loader
            loader = get_act_loader()
            extension_name = plugin.act_name
            act_file = plugin.get_act_file_path()
            tool_names = list(plugin.get_tool_names())
            loader.register_extension_act(
                extension_name=extension_name,
                act_file_path=Path(act_file),
                tool_names=tool_names,
            )

            def _cleanup_act() -> None:
                try:
                    loader.unregister_extension_act(extension_name)
                except Exception as exc:  # noqa: BLE001
                    logger.debug("ACT unregister failed: %s", exc)
                call_on_unload_if_implemented(plugin)

            cleanup_callbacks.append(_cleanup_act)
            self._loaded_plugin_ids.add(plugin_id)
        except Exception as exc:  # noqa: BLE001
            _handle_plugin_error(
                plugin_id=plugin_id,
                location=f"AgentBuilder._load_act_plugin({plugin_id})",
                exc=PluginLoadError(
                    plugin_id=plugin_id,
                    reason=str(exc),
                    location="ACT load",
                ) if not isinstance(exc, PluginLoadError) else exc,
            )

    def _load_tool_plugin(
        self,
        plugin: ToolPlugin,
        sdk_context_factory: Callable[[str], SDKContext],
        cleanup_callbacks: list[Callable[[], None]],
    ) -> None:
        plugin_id = plugin.plugin_id
        ctx = sdk_context_factory(plugin_id)
        try:
            call_on_load_if_implemented(plugin, ctx)
            from modules.tools.manager import ToolManager
            manager = ToolManager.get_instance()
            registered_names: list[str] = []
            for spec in plugin.get_tools():
                name = spec.get("name")
                if not name:
                    continue
                ok = manager.register_tool(
                    name=name,
                    description=spec.get("description", ""),
                    input_schema=spec.get("input_schema", {}),
                    handler=spec["handler"],  # type: ignore[index]
                    server_name=f"extension_{plugin_id}",
                    category=spec.get("category", "custom"),
                    direct_output=spec.get("direct_output", False),
                    user_visible=spec.get("user_visible", True),
                    output_schema=spec.get("output_schema"),
                    complexity=spec.get("complexity", "normal"),
                    dependencies=spec.get("dependencies"),
                )
                if ok:
                    registered_names.append(name)

            def _cleanup_tool() -> None:
                # ToolManager.unregister_tool 是公开 API（手动接到的 SSOT）
                # —— 但保险起见先 pop 再调 unregister_tool（兼容 hot reload）
                tools = getattr(manager, "tools", {})
                handlers = getattr(manager, "_dynamic_handlers", {})
                for n in registered_names:
                    tools.pop(n, None)
                    handlers.pop(n, None)
                call_on_unload_if_implemented(plugin)

            cleanup_callbacks.append(_cleanup_tool)
            self._loaded_plugin_ids.add(plugin_id)
        except Exception as exc:  # noqa: BLE001
            _handle_plugin_error(
                plugin_id=plugin_id,
                location=f"AgentBuilder._load_tool_plugin({plugin_id})",
                exc=PluginLoadError(
                    plugin_id=plugin_id,
                    reason=str(exc),
                    location="Tool load",
                ),
            )

    def _load_gate_plugin(
        self,
        plugin: GatePlugin,
        sdk_context_factory: Callable[[str], SDKContext],
        cleanup_callbacks: list[Callable[[], None]],
    ) -> None:
        plugin_id = plugin.plugin_id
        ctx = sdk_context_factory(plugin_id)
        try:
            call_on_load_if_implemented(plugin, ctx)
            gate = plugin.get_gate()
            phase = plugin.phase
            # Wave 1：仅在 SDK 内部维护 macro/micro chain 的引用副本，等真实接入后转
            # 给主仓 ConcludeGuardGates / GuardPipeline。Wave 2 PR 接入主仓。
            registry = _global_gate_registry()
            registry.register(plugin_id, gate, phase=phase)

            def _cleanup_gate() -> None:
                registry.unregister(plugin_id)
                call_on_unload_if_implemented(plugin)

            cleanup_callbacks.append(_cleanup_gate)
            self._loaded_plugin_ids.add(plugin_id)
        except Exception as exc:  # noqa: BLE001
            _handle_plugin_error(
                plugin_id=plugin_id,
                location=f"AgentBuilder._load_gate_plugin({plugin_id})",
                exc=PluginLoadError(
                    plugin_id=plugin_id,
                    reason=str(exc),
                    location="Gate load",
                ),
            )

    def _load_hint_plugin(
        self,
        plugin: HintPlugin,
        sdk_context_factory: Callable[[str], SDKContext],
        cleanup_callbacks: list[Callable[[], None]],
    ) -> None:
        """注册 HintPlugin 到进程级 ``HintRegistry``（Wave 2 P3 真实加载）。"""
        plugin_id = plugin.plugin_id
        ctx = sdk_context_factory(plugin_id)
        try:
            call_on_load_if_implemented(plugin, ctx)
            registry = get_hint_registry()
            applicable = list(getattr(plugin, "applicable_acts", []) or [])
            registry.register_hint(
                plugin_id=plugin_id,
                hint_callable=_hint_callable_from_plugin(plugin),
                applicable_acts=applicable,
            )

            def _cleanup_hint() -> None:
                try:
                    registry.unregister_hint(plugin_id)
                except Exception as exc:  # noqa: BLE001
                    logger.debug("HintRegistry unregister failed: %s", exc)
                call_on_unload_if_implemented(plugin)

            cleanup_callbacks.append(_cleanup_hint)
            self._loaded_plugin_ids.add(plugin_id)
        except Exception as exc:  # noqa: BLE001
            _handle_plugin_error(
                plugin_id=plugin_id,
                location=f"AgentBuilder._load_hint_plugin({plugin_id})",
                exc=PluginLoadError(
                    plugin_id=plugin_id,
                    reason=str(exc),
                    location="Hint load",
                ),
            )

    def _load_event_listener_plugin(
        self,
        plugin: EventListenerPlugin,
        sdk_context_factory: Callable[[str], SDKContext],
        cleanup_callbacks: list[Callable[[], None]],
        event_bus: EventBus,
    ) -> None:
        """订阅 ``EventBus`` 各 topic（Wave 2 P5 真实加载）。

        ``Agent.shutdown()`` 时反向 unsubscribe（保证 listener handler 不再被回调）。
        """
        plugin_id = plugin.plugin_id
        ctx = sdk_context_factory(plugin_id)
        try:
            call_on_load_if_implemented(plugin, ctx)
            tokens: list[str] = []
            subs = list(plugin.get_subscriptions() or [])
            for topic, handler in subs:
                token = event_bus.subscribe(topic, handler)
                tokens.append(token)

            def _cleanup_listener() -> None:
                for tok in tokens:
                    try:
                        event_bus.unsubscribe(tok)
                    except Exception as exc:  # noqa: BLE001
                        logger.debug("EventBus.unsubscribe failed (%s): %s", tok, exc)
                call_on_unload_if_implemented(plugin)

            cleanup_callbacks.append(_cleanup_listener)
            self._loaded_plugin_ids.add(plugin_id)
        except Exception as exc:  # noqa: BLE001
            _handle_plugin_error(
                plugin_id=plugin_id,
                location=f"AgentBuilder._load_event_listener_plugin({plugin_id})",
                exc=PluginLoadError(
                    plugin_id=plugin_id,
                    reason=str(exc),
                    location="EventListener load",
                ),
            )

    def _load_observability_plugin(
        self,
        plugin: ObservabilityPlugin,
        sdk_context_factory: Callable[[str], SDKContext],
        cleanup_callbacks: list[Callable[[], None]],
    ) -> None:
        """注入 ObservabilityFacade 让 plugin 挂自己的 callback 到 SinkRegistry（Wave 2 P6 真实加载）。"""
        plugin_id = plugin.plugin_id
        ctx = sdk_context_factory(plugin_id)
        try:
            call_on_load_if_implemented(plugin, ctx)
            from modules.observability.sink_registry import (
                ObservabilityFacade,
                get_sink_registry,
            )
            registry = get_sink_registry()
            facade = ObservabilityFacade(plugin_id=plugin_id, registry=registry)
            plugin.register(facade)

            def _cleanup_observability() -> None:
                try:
                    registry.remove_plugin(plugin_id)
                except Exception as exc:  # noqa: BLE001
                    logger.debug("SinkRegistry.remove_plugin failed: %s", exc)
                call_on_unload_if_implemented(plugin)

            cleanup_callbacks.append(_cleanup_observability)
            self._loaded_plugin_ids.add(plugin_id)
        except Exception as exc:  # noqa: BLE001
            _handle_plugin_error(
                plugin_id=plugin_id,
                location=f"AgentBuilder._load_observability_plugin({plugin_id})",
                exc=PluginLoadError(
                    plugin_id=plugin_id,
                    reason=str(exc),
                    location="Observability load",
                ),
            )

    def _load_mcp_server_plugin(
        self,
        plugin: MCPServerPlugin,
        sdk_context_factory: Callable[[str], SDKContext],
        cleanup_callbacks: list[Callable[[], None]],
    ) -> None:
        """Wave 3 P7 → P1a → Step 2 P1 (2026-05-13)：三形态加载。

        - 形态 A（``get_servers()``）：远程 MCP 配置 collect 到 ``Agent.mcp_servers``
        - 形态 B（``get_in_process_servers()`` 返本进程 server）：自动注册到
          ``ToolManager``（feature flag ``KROW_ENABLE_MCP_SERVER_PLUGIN=1`` opt-in）
        - 形态 C（``get_in_process_servers()`` 返已连接的**远程 client**）：与形态 B
          代码路径一样，SDK 不区分；额外在 cleanup 阶段尝试调 ``server.close()``
          / ``aclose()`` 优雅释放远程连接（OCP：不实现也不 raise）

        详 design doc §5.7 + ``modules/agent/sdk/experimental/protocols/mcp_server.py``。
        """
        plugin_id = plugin.plugin_id
        ctx = sdk_context_factory(plugin_id)
        try:
            call_on_load_if_implemented(plugin, ctx)
            servers = list(plugin.get_servers() or [])
            self._sdk_state.setdefault("mcp_servers", []).extend(servers)

            # P1a 形态 B：in-process server 真注册到 ToolManager
            registered_server_names: list[tuple[str, Any]] = []
            if (
                _is_mcp_server_plugin_enabled()
                and hasattr(plugin, "get_in_process_servers")
            ):
                try:
                    in_proc = list(plugin.get_in_process_servers() or [])  # type: ignore[attr-defined]
                except Exception as inproc_exc:  # noqa: BLE001
                    logger.warning(
                        "MCPServerPlugin %s.get_in_process_servers() raised: %s",
                        plugin_id, inproc_exc,
                    )
                    in_proc = []
                
                if in_proc:
                    from modules.tools.manager import ToolManager
                    tm = ToolManager.get_instance()
                    for srv_name, srv_instance in in_proc:
                        if not callable(getattr(srv_instance, "list_tools", None)):
                            logger.warning(
                                "MCPServerPlugin %s: server %r 缺 list_tools()，跳过注册",
                                plugin_id, srv_name,
                            )
                            continue
                        tm.register_internal_server(srv_name, srv_instance)
                        registered_server_names.append((srv_name, srv_instance))
                        logger.info(
                            "P1a/Step2-P1: MCPServerPlugin %s 注册 server %r (类型 %s)",
                            plugin_id, srv_name, type(srv_instance).__name__,
                        )

            def _cleanup_mcp() -> None:
                # 形态 B/C cleanup：unload 注册过的 server 工具 + close 远程 client
                if registered_server_names:
                    from modules.tools.manager import ToolManager
                    tm = ToolManager.get_instance()
                    for srv_name, srv_instance in registered_server_names:
                        # Step 2 P1 (2026-05-13)：形态 C 远程 client 优雅断开。
                        # 优先 close()（同步）；其次 aclose()（asyncio.run() 兜底）；
                        # 不实现也不 raise（OCP 兼容形态 B in-process server，通常不需 close）
                        close_fn = getattr(srv_instance, "close", None)
                        if callable(close_fn):
                            try:
                                close_fn()
                                logger.debug(
                                    "Step 2 P1: MCP server %r close() 已调用 (form-C remote)",
                                    srv_name,
                                )
                            except Exception as exc:  # noqa: BLE001
                                logger.warning(
                                    "MCP server %r close() raised (non-fatal): %s",
                                    srv_name, exc,
                                )
                        else:
                            aclose_fn = getattr(srv_instance, "aclose", None)
                            if callable(aclose_fn):
                                try:
                                    import asyncio
                                    coro = aclose_fn()
                                    if asyncio.iscoroutine(coro):
                                        try:
                                            loop = asyncio.get_running_loop()
                                            # 已在事件循环内 → schedule，不阻塞
                                            asyncio.ensure_future(coro)
                                        except RuntimeError:
                                            # 没运行的 loop → 起一个跑完 close
                                            asyncio.run(coro)
                                    logger.debug(
                                        "Step 2 P1: MCP server %r aclose() 已调用",
                                        srv_name,
                                    )
                                except Exception as exc:  # noqa: BLE001
                                    logger.warning(
                                        "MCP server %r aclose() raised (non-fatal): %s",
                                        srv_name, exc,
                                    )
                        
                        try:
                            tm._unload_tools(srv_name)  # noqa: SLF001
                            tm.internal_servers.pop(srv_name, None)
                        except Exception as exc:  # noqa: BLE001
                            logger.debug(
                                "MCP server %r unload 失败（non-fatal）：%s",
                                srv_name, exc,
                            )
                call_on_unload_if_implemented(plugin)

            cleanup_callbacks.append(_cleanup_mcp)
            self._loaded_plugin_ids.add(plugin_id)
        except Exception as exc:  # noqa: BLE001
            _handle_plugin_error(
                plugin_id=plugin_id,
                location=f"AgentBuilder._load_mcp_server_plugin({plugin_id})",
                exc=PluginLoadError(
                    plugin_id=plugin_id,
                    reason=str(exc),
                    location="MCPServer load",
                ),
            )

    def _load_security_plugin(
        self,
        plugin: SecurityPlugin,
        sdk_context_factory: Callable[[str], SDKContext],
        cleanup_callbacks: list[Callable[[], None]],
    ) -> None:
        """Wave 3 P8 骨架：仅注册 plugin_id + ``get_policies()`` 收集到 sdk_state。

        **不做**强沙箱拦截（强沙箱推 Step 3 subprocess / VM 隔离）。
        """
        plugin_id = plugin.plugin_id
        ctx = sdk_context_factory(plugin_id)
        try:
            call_on_load_if_implemented(plugin, ctx)
            policies = list(plugin.get_policies() or [])
            self._sdk_state.setdefault("security_policies", []).extend(policies)

            def _cleanup_security() -> None:
                call_on_unload_if_implemented(plugin)

            cleanup_callbacks.append(_cleanup_security)
            self._loaded_plugin_ids.add(plugin_id)
        except Exception as exc:  # noqa: BLE001
            _handle_plugin_error(
                plugin_id=plugin_id,
                location=f"AgentBuilder._load_security_plugin({plugin_id})",
                exc=PluginLoadError(
                    plugin_id=plugin_id,
                    reason=str(exc),
                    location="Security load",
                ),
            )

    def _load_domain_pack_plugin(
        self,
        plugin: DomainPackPlugin,
        sdk_context_factory: Callable[[str], SDKContext],
        cleanup_callbacks: list[Callable[[], None]],
        event_bus: EventBus,
    ) -> None:
        """Wave 3 P9 真实展开：把 8 元素分发到对应 registry。"""
        plugin_id = plugin.plugin_id
        ctx = sdk_context_factory(plugin_id)
        try:
            call_on_load_if_implemented(plugin, ctx)
            from modules.tools.manager import ToolManager

            from .domain_pack_expander import expand_domain_pack
            tool_manager = ToolManager.get_instance()
            sub_cleanups = expand_domain_pack(
                plugin,
                hint_registry=get_hint_registry(),
                tool_manager=tool_manager,
                event_bus=event_bus,
                gate_registry=_global_gate_registry(),
                sdk_context=ctx,
                sdk_state=self._sdk_state,
            )

            def _cleanup_pack() -> None:
                for sub in reversed(sub_cleanups):
                    try:
                        sub()
                    except Exception as exc:  # noqa: BLE001
                        logger.debug("DomainPack sub-cleanup error: %s", exc)
                call_on_unload_if_implemented(plugin)

            cleanup_callbacks.append(_cleanup_pack)
            self._loaded_plugin_ids.add(plugin_id)
        except Exception as exc:  # noqa: BLE001
            _handle_plugin_error(
                plugin_id=plugin_id,
                location=f"AgentBuilder._load_domain_pack_plugin({plugin_id})",
                exc=PluginLoadError(
                    plugin_id=plugin_id,
                    reason=str(exc),
                    location="DomainPack load",
                ),
            )

    def _load_visual_adapter_plugin(
        self,
        plugin: VisualAdapterPlugin,
        sdk_context_factory: Callable[[str], SDKContext],
        cleanup_callbacks: list[Callable[[], None]],
    ) -> None:
        """Step 2 P2 (2026-05-13)：加载 VisualAdapterPlugin.

        plugin 的 ``get_visual_adapters() -> [(ext, cls)]`` 返回值：

        - 合并到 ``_sdk_state["visual_adapters"]`` —— 与 ``DomainPackPlugin
          .get_visual_adapters()`` + ``with_visual_adapter()`` 三条路径共用
          同一汇总点（用于 ``Agent.visual_adapters`` property / diagnostics）.
        - **同时**注册到 ``visual_grounding_tools._ADAPTER_REGISTRY`` ——
          ``visual_inspect`` 工具的真正 lookup 路径（v0.9.x · PR 5.5 桥接 fix）.

        plugin lifecycle：``on_load`` 注册前调，``on_unload`` 在 cleanup 调（OCP）.

        v0.9.x (2026-05-15) · PR 5.5：以前只写 ``_sdk_state``，``visual_inspect``
        实际命中不到 plugin 的 adapter（dead state）。现在双写 + cleanup 时
        unregister，保证 SDK plugin 注册的 ``.dwg`` / ``.step`` / ``.cad`` 等
        adapter 在 ``visual_inspect(file_path)`` 按扩展名 lookup 时真的被实例化.
        """
        plugin_id = plugin.plugin_id
        ctx = sdk_context_factory(plugin_id)
        try:
            call_on_load_if_implemented(plugin, ctx)
            adapters = list(plugin.get_visual_adapters() or [])
            normalized: list[tuple[str, Any]] = []
            for item in adapters:
                if not (isinstance(item, tuple) and len(item) == 2):
                    raise PluginLoadError(
                        plugin_id=plugin_id,
                        reason=(
                            "get_visual_adapters() 必须返回 list[(ext, cls)]，"
                            f"但收到 {type(item).__name__} = {item!r}"
                        ),
                        location="VisualAdapterPlugin.get_visual_adapters",
                    )
                ext, adapter_cls = item
                if not isinstance(ext, str) or not ext.startswith("."):
                    raise PluginLoadError(
                        plugin_id=plugin_id,
                        reason=(
                            f"file_ext 必须是以 '.' 开头的字符串，收到 {ext!r}"
                        ),
                        location="VisualAdapterPlugin.get_visual_adapters",
                    )
                normalized.append((ext.lower(), adapter_cls))
            registered_exts = self._register_visual_adapters_to_vg_registry(
                normalized, source=f"VisualAdapterPlugin[{plugin_id}]",
            )
            if normalized:
                self._sdk_state.setdefault("visual_adapters", []).extend(normalized)
                logger.info(
                    "VisualAdapterPlugin %s 注册了 %d 个 adapter (ext=%s)",
                    plugin_id,
                    len(normalized),
                    [n[0] for n in normalized],
                )

            def _cleanup_visual() -> None:
                self._unregister_visual_adapters_from_vg_registry(registered_exts)
                call_on_unload_if_implemented(plugin)

            cleanup_callbacks.append(_cleanup_visual)
            self._loaded_plugin_ids.add(plugin_id)
        except Exception as exc:  # noqa: BLE001
            _handle_plugin_error(
                plugin_id=plugin_id,
                location=f"AgentBuilder._load_visual_adapter_plugin({plugin_id})",
                exc=PluginLoadError(
                    plugin_id=plugin_id,
                    reason=str(exc),
                    location="VisualAdapter load",
                ),
            )

    def _load_inline_visual_adapters(
        self,
        cleanup_callbacks: list[Callable[[], None]] | None = None,
    ) -> None:
        """Step 2 P2 (2026-05-13)：把 ``with_visual_adapter(ext, cls)`` 直接注册的
        (ext, cls) pair 合并到 ``_sdk_state["visual_adapters"]``.

        无 lifecycle hook（inline 注册没有 plugin_id），与 plugin 路径共享同一汇总点.

        v0.9.x (2026-05-15) · PR 5.5：同步桥接到 ``visual_grounding_tools``
        registry（与 plugin 路径一致），cleanup 时 unregister.
        """
        if not self._inline_visual_adapters:
            return
        registered_exts = self._register_visual_adapters_to_vg_registry(
            self._inline_visual_adapters, source="with_visual_adapter (inline)",
        )
        self._sdk_state.setdefault("visual_adapters", []).extend(
            self._inline_visual_adapters,
        )
        logger.info(
            "inline visual adapters: 注册 %d 个 (ext=%s)",
            len(self._inline_visual_adapters),
            [a[0] for a in self._inline_visual_adapters],
        )
        if cleanup_callbacks is not None and registered_exts:
            def _cleanup_inline_visual() -> None:
                self._unregister_visual_adapters_from_vg_registry(registered_exts)
            cleanup_callbacks.append(_cleanup_inline_visual)

    def _register_visual_adapters_to_vg_registry(
        self, pairs: list[tuple[str, Any]], *, source: str,
    ) -> list[str]:
        """桥接：把 (ext, cls) 列表注册进 ``visual_grounding_tools`` registry.

        v0.9.x (2026-05-15) · PR 5.5：这是 SDK Builder 与 ``visual_inspect``
        工具之间的真正桥接点。registry 是模块级全局 dict，多 Agent 共享 → 注册
        要 cleanup 对称（``unregister``），否则测试 / 多 Agent 场景污染.

        Args:
            pairs: ``(ext_lowercase, adapter_class_or_fqcn)`` 列表.
            source: 注册来源标识（plugin_id / "inline"），仅日志用.

        Returns:
            实际 register 进去的 ext 列表（已 lowercase）.
        """
        if not pairs:
            return []
        try:
            from modules.agent.visual.visual_grounding_tools import (
                register_visual_adapter,
            )
        except Exception as exc:  # noqa: BLE001 — visual subsystem 不可用降级
            logger.warning(
                "AgentBuilder: visual_grounding_tools 不可导入，"
                "SDK 注册的 adapter 不会被 visual_inspect 工具看到 "
                "(source=%s, exts=%s, error=%s)",
                source,
                [e for e, _ in pairs],
                exc,
            )
            return []
        registered: list[str] = []
        for ext, adapter_cls in pairs:
            try:
                register_visual_adapter(ext, adapter_cls)
                registered.append(ext)
            except Exception as exc:  # noqa: BLE001
                logger.error(
                    "register_visual_adapter failed: ext=%s cls=%r "
                    "source=%s error=%s",
                    ext, adapter_cls, source, exc,
                )
        if registered:
            logger.info(
                "AgentBuilder: 已桥接 %d 个 adapter 到 visual_grounding "
                "registry (ext=%s, source=%s)",
                len(registered), registered, source,
            )
        return registered

    def _unregister_visual_adapters_from_vg_registry(
        self, exts: list[str],
    ) -> None:
        """cleanup 对称：从 ``visual_grounding_tools`` registry 移除 ext.

        v0.9.x (2026-05-15) · PR 5.5：``Agent.shutdown()`` cleanup 阶段调.
        若 import 失败（visual subsystem 已 unload），静默跳过.
        """
        if not exts:
            return
        try:
            from modules.agent.visual.visual_grounding_tools import (
                unregister_visual_adapter,
            )
        except Exception:  # noqa: BLE001 — cleanup 阶段不阻塞
            return
        for ext in exts:
            try:
                unregister_visual_adapter(ext)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "unregister_visual_adapter(%r) failed during cleanup: %s",
                    ext, exc,
                )

    # ────────── 启动期校验 ──────────

    def _validate_project_root_writable(self, root: Path) -> None:
        try:
            root.mkdir(parents=True, exist_ok=True)
            test_file = root / ".krow_sdk_writetest"
            test_file.write_text("ok", encoding="utf-8")
            test_file.unlink()
        except OSError as exc:
            raise ProjectRootNotWritableError(project_root=str(root)) from exc

    def _validate_and_fallback_cloud_models(self) -> None:
        """检测 ``LLMProviderManager`` 内 ``Krow (远程)`` 的默认模型是否还在 cloud
        当前可用清单 ``/v1/models`` 内；不在 → 自动 fallback 到第一个兼容模型。

        触发场景：开发者本地 ``config/module_config.json`` 历史写入 ``claude-opus-4.6``
        （桌面 app 旧版本），但当前 cloud ``/v1/models`` 不返 claude 系列（区域受限 /
        服务降级 / 账号限权）→ 不 fallback 时 KrowLLMProvider 报 ``AuthExpiredError``
        401，误诊"登录已过期"（实际是模型名不存在 / 账号无权访问）。
        
        Fallback 策略：
        - chat_model：选 cloud 清单内第一个非 vision、非 reasoning 的模型
        - reasoning_model：选 cloud 清单内第一个 ``is_reasoning=True`` 的模型；
          若无 reasoning 模型则用 chat fallback 同款（cloud 通常 deepseek-reasoner / 
          qwen3.6-plus 都支持 reasoning）
        - cloud 完全空清单（极端故障 / 网络不通）→ log warning 不阻塞 build
        - cloud 清单返但默认模型恰在内 → no-op（保留用户配置）
        """
        try:
            from modules.ai.krow.provider import get_krow_llm_provider
            from modules.ai.providers import get_llm_provider_manager
        except ImportError:
            return  # 极端依赖缺失，跳过

        lpm = get_llm_provider_manager()
        if lpm is None:
            return

        # 直接 GET /v1/models 读 raw 清单，绕过 ``_ensure_overseas_models`` 硬编码兜底
        # （后者会把 claude 等海外模型回填进 cache，让 cloud-side 实际不可用的模型在
        # ``get_models()`` 里仍然存在 → 失去 fallback 检测意义）。
        try:
            cloud_provider = get_krow_llm_provider()
            headers = cloud_provider._auth.get_headers()  # noqa: SLF001
            resp = cloud_provider._http_client.get(  # noqa: SLF001
                f"{cloud_provider._api_base}{cloud_provider.MODELS_ENDPOINT}",  # noqa: SLF001
                headers=headers,
                timeout=10.0,
            )
            resp.raise_for_status()
            raw_data = resp.json()
            available_ids = {
                item.get("id", "")
                for item in raw_data.get("data", [])
                if item.get("id")
            }
            # 同时拿 KrowModelInfo 拷贝（用 get_models 单条查 traits）—— get_models
            # 含兜底但 traits 一致；用于 chat / reasoning 选 fallback 候选
            full = cloud_provider.get_models()
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "_validate_and_fallback_cloud_models: cloud /v1/models failed "
                "(network / auth?): %s", exc,
            )
            return

        if not available_ids:
            return  # 清单完全为空 → 不动

        # 只取 cloud 真实可用 + 在 full(KrowModelInfo) 也有的子集
        available = {mid: info for mid, info in full.items() if mid in available_ids}
        if not available:
            return

        # Step 2 P1（2026-05-13）：``with_default_model()`` 用户显式指定优先于 fallback。
        # 校验用户指定的模型在 cloud 清单内；不在则 log warning 并 fallback（保护打错字
        # / 模型已下线场景，但对正确指定的 chat_model 不动）。
        chat_fallback: str | None = None
        if self._explicit_chat_model:
            if self._explicit_chat_model in available_ids:
                chat_fallback = self._explicit_chat_model
                logger.info(
                    "SDK with_default_model: chat_model=%s 在 cloud 清单 (用户显式指定)",
                    chat_fallback,
                )
            else:
                logger.warning(
                    "SDK with_default_model: chat_model=%r 不在 cloud /v1/models 清单 "
                    "(可用清单 head: %s) → 走 fallback",
                    self._explicit_chat_model,
                    list(available_ids)[:8],
                )

        if chat_fallback is None:
            # 找 chat fallback 候选（非 vision、非 reasoning）
            for mid, info in available.items():
                if not info.is_vision and not info.is_reasoning:
                    chat_fallback = mid
                    break
            if chat_fallback is None:
                # 极端：cloud 全是 vision / reasoning → 用任一
                chat_fallback = next(iter(available_ids))

        reasoning_fallback: str | None = None
        if self._explicit_reasoning_model:
            if self._explicit_reasoning_model in available_ids:
                reasoning_fallback = self._explicit_reasoning_model
                logger.info(
                    "SDK with_default_model: reasoning_model=%s 在 cloud 清单 (用户显式指定)",
                    reasoning_fallback,
                )
            else:
                logger.warning(
                    "SDK with_default_model: reasoning_model=%r 不在 cloud 清单 → 走 fallback",
                    self._explicit_reasoning_model,
                )

        if reasoning_fallback is None:
            for mid, info in available.items():
                if info.is_reasoning and not info.is_vision:
                    reasoning_fallback = mid
                    break
            if reasoning_fallback is None:
                reasoning_fallback = chat_fallback

        # 替换 LLMProviderManager 内 'Krow (远程)' 不可用的默认模型
        # Step 2 P1：用户 with_default_model() 时强制覆盖（即使现 model 在清单内）；
        # 不指定时仅 cloud 不返才覆盖（保留 module_config.json 用户配置）
        force_chat_override = self._explicit_chat_model is not None
        force_reasoning_override = self._explicit_reasoning_model is not None
        for prov_name, prov in list(lpm._llm_providers.items()):  # noqa: SLF001
            if "Krow" not in prov_name:
                continue
            if prov.chat_model and (
                force_chat_override
                or prov.chat_model.model_name not in available_ids
            ):
                old = prov.chat_model.model_name
                prov.chat_model.model_name = chat_fallback
                if force_chat_override:
                    logger.info(
                        "SDK with_default_model: %s.chat_model %s → %s (用户显式指定)",
                        prov_name, old, chat_fallback,
                    )
                else:
                    logger.warning(
                        "SDK cloud-model fallback: %s.chat_model %s → %s "
                        "(cloud 不返该模型)",
                        prov_name, old, chat_fallback,
                    )
            if prov.reasoning_model and (
                force_reasoning_override
                or prov.reasoning_model.model_name not in available_ids
            ):
                old = prov.reasoning_model.model_name
                prov.reasoning_model.model_name = reasoning_fallback
                if force_reasoning_override:
                    logger.info(
                        "SDK with_default_model: %s.reasoning_model %s → %s (用户显式指定)",
                        prov_name, old, reasoning_fallback,
                    )
                else:
                    logger.warning(
                        "SDK cloud-model fallback: %s.reasoning_model %s → %s "
                        "(cloud 不返该模型)",
                        prov_name, old, reasoning_fallback,
                    )

        # 同步覆盖 settings.module_interfaces.krow，让 bootstrap._register_llm_providers
        # 再注册 / sync 时也走 fallback 模型（避免后续 ai_manager 重建撞回旧值）
        try:
            from config.settings import settings as _sdk_settings
            _krow_cfg = _sdk_settings.module_interfaces.krow
            if force_chat_override or _krow_cfg.default_chat_model not in available_ids:
                _krow_cfg.default_chat_model = chat_fallback
            if (
                force_reasoning_override
                or _krow_cfg.default_reasoning_model not in available_ids
            ):
                _krow_cfg.default_reasoning_model = reasoning_fallback
        except Exception as _exc:  # noqa: BLE001
            logger.debug(
                "build(): could not sync settings.krow.default_*_model "
                "(non-fatal): %s", _exc,
            )

    def _apply_explicit_aux_model_overrides(self) -> None:
        """把用户 ``with_<vision|image_gen|image_edit|text_encoder>_model()`` 指定的
        model_id 注入下层 ``AIProviderManager`` 内对应 category provider 的
        ``ProviderConfig.model`` 字段（chore/sdk-model-selection-api · 2026-05-15）.

        与 ``_validate_and_fallback_cloud_models`` 同源思路（改 model 字段），
        但作用面不同：

        - ``_validate_and_fallback_cloud_models``: 改 ``LLMProviderManager`` 上层
          ``LLMProvider.{chat,reasoning}_model.model_name``（chat / reasoning 共享一个
          provider 实例的不同 model field；这里是 ``ModelConfig.model_name``，与
          ``ProviderConfig.model`` 不同对象）.
        - 本方法：改下层 ``AIProviderManager._providers[<provider_name>].config.model``
          （vision / image_gen / image_edit / text_encoder 各自是独立 provider 实例，
          每个 provider 实例 1 个 ``ProviderConfig.model``）.

        未指定的 category 不动；指定但 ai_manager 没注册该 category provider 时
        log warning（不 raise，与现有 chat/reasoning fallback 行为一致）.

        历史 bug（chore/btq-model-overrides-2026-05-15 hotfix）：
        本方法此前写入 ``cfg.model_name``——但 ``ProviderConfig`` 实际字段名是
        ``model``（``modules/ai/providers.py:417-434``），下游 ~15 处都读 ``cfg.model``，
        而 Python dataclass 默认 ``frozen=False`` → ``cfg.model_name = X`` 被静默
        写成动态属性，下游零感知 → aux 4 类 override **完全无效**。
        本次 PR 把 3 处写入点（本方法 / api_gateway.py desktop path /
        background_task_queue.py BtQ helper）统一对齐 dataclass 真实字段名 ``model``。
        """
        from modules.ai.providers import ModelCategory
        
        overrides: dict[ModelCategory, str | None] = {
            ModelCategory.VISION: self._explicit_vision_model,
            ModelCategory.IMAGE_GEN: self._explicit_image_gen_model,
            ModelCategory.IMAGE_EDIT: self._explicit_image_edit_model,
            ModelCategory.TEXT_ENCODER: self._explicit_text_encoder_model,
        }
        any_override = any(v is not None for v in overrides.values())
        if not any_override:
            return  # 用户未指定任何 aux category → 走默认 fallback
        
        ai_manager = self._ai_manager
        if ai_manager is None:
            logger.warning(
                "with_<aux>_model: AIProviderManager 未初始化，aux model overrides 暂不生效"
            )
            return
        
        for category, model_id in overrides.items():
            if model_id is None:
                continue
            
            matched_count = 0
            for prov_name, provider in list(ai_manager._providers.items()):  # noqa: SLF001
                cfg = getattr(provider, "config", None)
                if cfg is None or cfg.category != category:
                    continue
                old_model = cfg.model
                cfg.model = model_id
                matched_count += 1
                logger.info(
                    "SDK with_%s_model: %s.config.model %s → %s (用户显式指定)",
                    category.value, prov_name, old_model, model_id,
                )
            
            if matched_count == 0:
                logger.warning(
                    "SDK with_%s_model: 当前 AIProviderManager 内无 %s category provider "
                    "（用户指定 model_id=%r，本期 build 不生效；后续 ai_manager 重建后再试）",
                    category.value, category.value, model_id,
                )

    def _validate_api_key_connection(self, api_key: str) -> None:
        """PR A1 / S1.17：真实 GET /v1/models 验证 api_key 启动期 fail-loud。
        
        通过 ``KrowAuthAdapter.set_api_key`` + ``get_user_info`` 串通：
        - api_key 无效 → ``get_user_info`` 返 None → 抛 ``KrowAPIKeyInvalidError``
        - 网络故障 → 不阻塞 build（与设计文档 §3.6 "网络验证不可用时不应硬挡用户启动" 一致）
        
        Args:
            api_key: Krow API Key
        
        Raises:
            KrowAPIKeyInvalidError: api_key 经云端 /v1/models 验证 401（无效）
        """
        try:
            from modules.auth.krow_auth import KrowAuthAdapter

            from .errors import KrowAPIKeyInvalidError
        except ImportError:
            # 异常环境（如最小依赖测试）跳过验证
            return
        
        # 用独立 adapter 实例做"无副作用"验证（不污染全局 adapter / 不持久化）
        adapter = KrowAuthAdapter()
        try:
            adapter.set_api_key(api_key)
            try:
                _ = adapter.get_user_info()
                # 200 / 404 降级 200 都视为有效；不强求拿到 user_info
            except KrowAPIKeyInvalidError:
                # 云端明确 401 — fail-loud
                raise
            except Exception as exc:  # noqa: BLE001
                # 网络故障 / 云端临时不可达 → log warning 不阻塞 build
                # 开发者可设 KROW_SDK_BUILD_VALIDATE_CONNECTION=0 完全跳过
                logger.warning(
                    "validate_connection: api_key 网络验证失败（非 401），不阻塞 build：%s",
                    exc,
                )
        finally:
            try:
                adapter._stop_keepalive()  # noqa: SLF001
            except Exception:  # noqa: BLE001
                pass


# ────────────────────────────────────────────────────────────────────────
# Wave 1 全局 Gate 注册表（Wave 2 接入主仓 ConcludeGuardGates / GuardPipeline）
# ────────────────────────────────────────────────────────────────────────


class _GateRegistry:
    """Wave 1 内部 Gate 注册表，用于让 SDK 知道有哪些 plugin gate 注册了；
    Wave 2 PR 真实接入主仓 ConcludeGuard chain 时改成 forwarding。"""

    def __init__(self) -> None:
        self._gates: dict[str, tuple[Any, str]] = {}
        self._lock = threading.RLock()

    def register(self, plugin_id: str, gate: Any, *, phase: str) -> None:
        with self._lock:
            self._gates[plugin_id] = (gate, phase)

    def unregister(self, plugin_id: str) -> None:
        with self._lock:
            self._gates.pop(plugin_id, None)

    def list_gates(self) -> list[tuple[str, Any, str]]:
        with self._lock:
            return [(pid, g, ph) for pid, (g, ph) in self._gates.items()]


_GATE_REGISTRY: _GateRegistry | None = None
_GATE_REGISTRY_LOCK = threading.RLock()


def _global_gate_registry() -> _GateRegistry:
    global _GATE_REGISTRY
    with _GATE_REGISTRY_LOCK:
        if _GATE_REGISTRY is None:
            _GATE_REGISTRY = _GateRegistry()
        return _GATE_REGISTRY


def _ensure_ai_manager() -> AIProviderManager:
    """按优先级初始化 ``AIProviderManager``。

    1. 全局 ``get_ai_provider_manager()`` 已初始化 → 直接返回
    2. 走 ``app.container._build_ai_manager()`` 标准初始化路径（与 headless / 桌面共享）
    3. 都失败 → 构造空 ``AIProviderManager(provider_configs=[], default_provider=DEEPSEEK)``
       —— 仅用于 SDK 单元测试 + replay 场景，真实 LLM 不可用
    """
    from modules.ai.providers import (
        AIProviderManager,
        get_ai_provider_manager,
    )

    mgr = get_ai_provider_manager()
    if mgr is not None:
        return mgr

    try:
        from app.container import _build_ai_manager
        return _build_ai_manager()
    except Exception as exc:  # noqa: BLE001
        logger.debug("_build_ai_manager failed (%s); falling back to empty AIProviderManager", exc)

    try:
        from modules.ai.providers import ProviderName
        return AIProviderManager(provider_configs=[], default_provider=ProviderName.DEEPSEEK)
    except Exception as exc:  # noqa: BLE001
        logger.error("Failed to construct empty AIProviderManager: %s", exc)
        raise


__all__ = [
    "Agent",
    "AgentBuilder",
    "BudgetSpec",
    "BuilderConfig",
]
