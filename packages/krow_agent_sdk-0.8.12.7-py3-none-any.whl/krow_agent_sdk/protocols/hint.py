"""P3 HintPlugin：外部 plugin 加 progressive hint（design doc §5.3）。

System 2 标签——hint 是给 LLM 的语义提示文本。
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class HintPlugin(Protocol):
    """外部 plugin 加领域特定的软提示（hint）。

    与现有 ``modules/agent/progressive/`` 各种 hint 函数（``tool_priority_hint`` /
    ``contrast_hint`` 等）共享接口契约：返回拼接到 LLM prompt 的 markdown 文本。

    SDK 在 prompt 拼接阶段调 ``hint_for(context) -> Optional[str]``，
    None / 空串 / 异常都视为"本 hint 不适用"，跳过即可（不阻塞主流程）。
    """

    @property
    def plugin_id(self) -> str:
        """全局唯一 ID。"""
        ...

    @property
    def applicable_acts(self) -> list[str]:
        """该 hint 适用的 ACT 名单（空 list 视为"全局 hint，所有 ACT 触发"）。"""
        ...

    def hint_for(self, context: dict) -> str | None:
        """根据 context 生成 hint 文本（markdown）；不适用时返回 None。

        Args:
            context: 包含 ``act_name`` / ``user_input`` / ``tool_name`` / ``step_index`` 等
                的运行时上下文（SDK 注入），plugin 不应修改。

        Returns:
            hint 文本（拼到 prompt）或 None
        """
        ...
