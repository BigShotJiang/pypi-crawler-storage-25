"""P5 EventListenerPlugin：外部 plugin 订阅 EventBus 事件（design doc §5.5）。

System 1 标签——listener 是确定性事件转发。
**严格只读**：listener 不可修改 agent 状态 / 不可调 BudgetController write API。
"""
from __future__ import annotations

from typing import Any, Callable, Protocol, runtime_checkable


@runtime_checkable
class EventListenerPlugin(Protocol):
    """外部 plugin 订阅 EventBus 事件。

    SDK build() 时遍历 ``get_subscriptions() -> list[(topic, handler)]``，
    逐个调 ``EventBus.subscribe(topic, handler)``。

    支持的 stable topic 子集（详 design doc §5.5 表）：
        agent.task_complete / executor.* / progressive.* / budget.* / react.*
    其他 topic 仍可订阅，但**不在 SemVer 稳定保证内**——主仓 refactor 可能 break。
    """

    @property
    def plugin_id(self) -> str:
        """全局唯一 ID。"""
        ...

    def get_subscriptions(self) -> list[tuple[str, Callable[[Any], None]]]:
        """返回订阅列表，每项 ``(topic, handler)``。

        handler 接收 ``Event`` dataclass（``modules.events.bus_core.Event``）。

        **铁律**：handler 内部不可调用任何 BudgetController write API / 不可调 ToolManager.register_tool / 不可改 agent 状态。
        """
        ...
