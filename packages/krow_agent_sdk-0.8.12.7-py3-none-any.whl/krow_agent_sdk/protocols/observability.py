"""P6 ObservabilityPlugin：外部 plugin 推 metrics / traces 到外部 sink（design doc §5.6）。

System 1 标签——sink 是确定性数据转发。
"""
from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class ObservabilityPlugin(Protocol):
    """外部 plugin 把 krow agent 内部 metrics / traces / audit log 推到外部系统。

    现有 SSOT：``modules/observability/{tracing,metrics,audit_reporter}.py``。

    SDK build() 时调 ``register(observability_facade)``——facade 提供
    ``on_metric(name, value, labels)`` / ``on_span(span)`` / ``on_audit(event)`` 三组回调注册接口。
    plugin 据此把数据 forward 到 Datadog / Splunk / Grafana / 自建系统等。
    """

    @property
    def plugin_id(self) -> str:
        """全局唯一 ID。"""
        ...

    def register(self, observability_facade: Any) -> None:
        """SDK 注入 ObservabilityFacade（薄封装 ``modules/observability/`` 模块）。

        plugin 在此调用 ``facade.add_metric_sink(callback)`` / ``add_trace_sink(...)`` 等。
        """
        ...
