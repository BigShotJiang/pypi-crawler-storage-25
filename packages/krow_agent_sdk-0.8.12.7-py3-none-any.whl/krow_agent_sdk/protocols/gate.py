"""P4 GatePlugin：外部 plugin 加新 ConcludeGuard Gate（design doc §5.4）。

System 1 标签——Gate 是确定性判停规则。
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Literal, Protocol, runtime_checkable

if TYPE_CHECKING:
    from modules.knowledge.conclude_guard_gates import Gate

GatePhase = Literal["macro", "micro"]
"""Gate 工作位面：``macro``（macro ReACT conclude 时检查）/ ``micro``（micro ReACT step 内检查）。"""


@runtime_checkable
class GatePlugin(Protocol):
    """外部 plugin 加新 ConcludeGuard Gate。

    现有 SSOT：``modules/knowledge/conclude_guard_gates.py``
        - ``class Gate(Protocol)``：方法 ``evaluate(parsed: Dict, context: Dict) -> GateDecision``
        - ``class GateChain``：``register(gate: Gate) -> GateChain``
        - ``make_simple_gate(name, priority, evaluator) -> Gate``

    SDK build() 时调用 ``GateChain.register(gate)``——按 ``phase`` 注册到 macro 或 micro 链。
    """

    @property
    def plugin_id(self) -> str:
        """全局唯一 ID，格式 ``<org>.<plugin_name>``。"""
        ...

    def get_gate(self) -> "Gate":
        """返回 ``Gate`` 实例（必须满足 ``modules.knowledge.conclude_guard_gates.Gate`` Protocol）。

        实现可用 ``make_simple_gate(name, priority, evaluator)`` 工厂函数构造。
        """
        ...

    @property
    def phase(self) -> GatePhase:
        """gate 工作位面：``macro`` 或 ``micro``。"""
        ...
