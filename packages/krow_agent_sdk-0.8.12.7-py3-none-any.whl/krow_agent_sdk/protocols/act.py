"""P1 ACTPlugin：外部 plugin 加新 ACT（macro 层扩展，design doc §5.1）。

System 1 标签——ACT 是声明式 yaml + markdown 容器，加载是确定性查表。
"""
from __future__ import annotations

from pathlib import Path
from typing import Protocol, runtime_checkable


@runtime_checkable
class ACTPlugin(Protocol):
    """外部 plugin 加新 ACT（macro 层扩展）。

    现有 SSOT：``modules/agent/act/act_loader.py:ACTLoader.register_extension_act``
    + ``modules/agent/act/act_manager.py:ACTManager.register_act``

    SDK build() 时调用 ``register_extension_act(extension_name=plugin_id, act_file_path=get_act_root() / 'ext_<plugin>.md', tool_names=[...])``。

    plugin_id 必须双段命名 ``<org>.<plugin_name>``（详 §5.0.5）；ACT name = 该 plugin 的 ``<plugin_name>`` 段。
    """

    @property
    def plugin_id(self) -> str:
        """全局唯一 ID，格式 ``<org>.<plugin_name>``。"""
        ...

    @property
    def act_name(self) -> str:
        """ACT 名称（不含 ``ext_`` 前缀；SDK 会自动加）；通常等于 ``<plugin_name>`` 段。"""
        ...

    def get_act_root(self) -> Path:
        """ACT 资源目录（含 ``__act__.yaml`` / ``extended.md`` 等）。

        SDK 期望该目录布局兼容 ``modules/agent/act/acts/<name>/`` 结构。
        """
        ...

    def get_act_file_path(self) -> Path:
        """主 ACT markdown 文件路径（用于 ACTLoader.register_extension_act 第二参数）。

        典型实现：``return self.get_act_root() / "ext_<name>.md"``
        """
        ...

    def get_tool_names(self) -> list[str]:
        """该 ACT 内启用的工具名列表（与 ToolPlugin 注册的 tool name 对齐）。

        命名规范：必须以 ``<plugin_name>.`` 段为前缀（防撞 native）。
        """
        ...
