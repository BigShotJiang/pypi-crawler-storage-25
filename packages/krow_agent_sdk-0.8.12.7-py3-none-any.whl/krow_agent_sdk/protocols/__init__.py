"""Krow Agent SDK Plugin Protocols（mvp_critical + stable 层）。

design doc §5.0.1 优先级分层：

- **mvp_critical**：P1 ACTPlugin / P2 ToolPlugin / P4 GatePlugin（5 年 SemVer 强约束）
- **stable**：P3 HintPlugin / P5 EventListenerPlugin / P6 ObservabilityPlugin（3 年 SemVer 强约束）

experimental（P7/P8/P9）单独在 ``krow_agent_sdk.experimental.protocols`` namespace。
"""
from __future__ import annotations

from .act import ACTPlugin
from .event_listener import EventListenerPlugin
from .gate import GatePlugin
from .hint import HintPlugin
from .observability import ObservabilityPlugin
from .tool import ToolPlugin

__all__ = [
    # mvp_critical
    "ACTPlugin",
    "ToolPlugin",
    "GatePlugin",
    # stable
    "HintPlugin",
    "EventListenerPlugin",
    "ObservabilityPlugin",
]
