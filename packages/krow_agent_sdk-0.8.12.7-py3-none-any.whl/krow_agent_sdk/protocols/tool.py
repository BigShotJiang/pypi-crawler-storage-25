"""P2 ToolPlugin：外部 plugin 加新工具（design doc §5.2）。

System 1 标签——工具注册是声明式 dict + Python handler，确定性。
"""
from __future__ import annotations

from typing import Any, Callable, Protocol, TypedDict, runtime_checkable


class ToolSpec(TypedDict, total=False):
    """SDK ToolPlugin 暴露给 ToolManager.register_tool 的 dict 形态。

    与 ``modules/tools/manager.py:ToolManager.register_tool`` 真实参数对齐：
        register_tool(name, description, input_schema, handler,
                       server_name="dynamic", category="custom",
                       direct_output=False, user_visible=True,
                       output_schema=None, complexity="normal",
                       dependencies=None) -> bool
    """

    name: str
    description: str
    input_schema: dict[str, Any]
    handler: Callable[..., Any]
    category: str
    direct_output: bool
    user_visible: bool
    output_schema: dict[str, Any] | None
    complexity: str
    dependencies: dict[str, Any] | None


@runtime_checkable
class ToolPlugin(Protocol):
    """外部 plugin 加新工具。

    SDK build() 时遍历 ``get_tools() -> list[ToolSpec]``，逐个调
    ``ToolManager.register_tool(**spec, server_name=f"extension_{plugin_id}")``。
    server_name 强制 ``extension_*`` 前缀（详 manager.py:V100.2 安全检查）。

    工具命名规范：必须以 plugin 的 ``<plugin_name>`` 段为前缀（如 ``industrial_design.cad_extract_geometry``）。
    """

    @property
    def plugin_id(self) -> str:
        """全局唯一 ID，格式 ``<org>.<plugin_name>``。"""
        ...

    def get_tools(self) -> list[ToolSpec]:
        """返回工具规格列表（每个 spec 描述一个工具）。

        最小 spec：``{"name", "description", "input_schema", "handler"}``。
        """
        ...
