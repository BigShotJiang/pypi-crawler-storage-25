"""SDK 反向 telemetry opt-in（PR C1 / S2.17）。

设计 SSOT：``docs/sdk/plugin-architecture-design.md`` §5.13。

## 设计要点

- **opt-in only**：默认 OFF；仅当 ``KROW_SDK_TELEMETRY=1`` 时启用（GDPR 对齐）
- **anonymous only**：plugin_id 上报为 SHA-256 hash，不含明文
- **silent drop on failure**：网络 / 后端故障不影响 SDK 主流程
- **聚合上报**：每小时一次（不 per-call）
- **绝不上报**：API key / user_input / 文件路径 / 任何 PII

## 上报内容（最小匿名）

| 字段 | 说明 |
|---|---|
| ``sdk_version`` | 当前 SDK 版本号（如 ``0.1.0``） |
| ``plugin_id_hash`` | 各 plugin_id 的 SHA-256 hex（不含明文） |
| ``protocols_used`` | 各 plugin 实际实现的 Protocol 列表 |
| ``protocol_call_counts`` | 各 Protocol 调用次数聚合 |
| ``error_counts`` | 各 error class 的触发次数聚合 |
| ``feature_flags_state`` | 各 ``KROW_*`` feature flag 的开关状态（不含 secrets） |

## 通道

- HTTPS POST 到 ``https://api.krow.cn/sdk/telemetry/v1/anonymous``
- 与计费 / LLM 通道独立（不混用 KROW_API_KEY）
- 30 秒 timeout，失败 silent drop（log debug）

## 用法

```python
from modules.agent.sdk.telemetry import (
    is_telemetry_enabled,
    get_telemetry_client,
)

# 用户 opt-in:
# export KROW_SDK_TELEMETRY=1

# SDK 内部记录（plugin 注册时）:
client = get_telemetry_client()
client.track_plugin_register(plugin_id="acme.research_pack", protocols=["P1", "P2"])

# SDK 内部记录（protocol 调用时）:
client.track_protocol_call(protocol="ACTPlugin")

# SDK 内部记录（plugin 抛错时）:
client.track_error(error_class="PluginLoadError")

# 进程退出 / 每小时自动 flush（后台线程）
```

## SSOT 锚点

- 设计文档 §5.13 + §10.2 KROW_SDK_TELEMETRY
- endpoint: §15.5 ``https://api.krow.cn/sdk/telemetry/v1/anonymous``
- 反模式：§5.13 表格"telemetry 默认开启" / "上报具体 input/output" / "telemetry 失败拖死 SDK"
"""
from __future__ import annotations

import hashlib
import logging
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ────────────────────────────────────────────────────────────────────
# Feature flag
# ────────────────────────────────────────────────────────────────────

ENV_VAR_TELEMETRY = "KROW_SDK_TELEMETRY"
"""控制是否开启 SDK 反向 telemetry opt-in 的 env var；默认 OFF。"""

_TRUTHY_ENV_VALUES = {"1", "true", "yes", "on"}


def is_telemetry_enabled() -> bool:
    """检查环境变量是否启用 telemetry opt-in。

    Returns:
        ``True`` 当且仅当 ``KROW_SDK_TELEMETRY`` 设为 ``1`` / ``true`` / ``yes`` / ``on``
        （不区分大小写）。其他值（包括未设置）一律返回 ``False``。
    """
    raw = os.environ.get(ENV_VAR_TELEMETRY, "")
    return raw.strip().lower() in _TRUTHY_ENV_VALUES


# ────────────────────────────────────────────────────────────────────
# Endpoint + 安全黑名单
# ────────────────────────────────────────────────────────────────────

DEFAULT_TELEMETRY_ENDPOINT = "https://api.krow.cn/sdk/telemetry/v1/anonymous"
"""默认 telemetry 上报端点（与计费 / LLM 通道独立）。"""

ENV_VAR_TELEMETRY_ENDPOINT = "KROW_SDK_TELEMETRY_ENDPOINT"
"""仅测试 / 内部部署使用：override 上报 endpoint。生产用户**不应**改。"""

DEFAULT_FLUSH_INTERVAL_SECONDS = 3600
"""默认聚合上报间隔：1 小时。"""

DEFAULT_HTTP_TIMEOUT_SECONDS = 30
"""HTTPS POST 超时：30 秒（足够应对网络慢，不至于阻塞主流程）。"""

# 字段名 / 值含 SECRETS_PATTERNS 任一关键字 → 一律不上报
# （防御性：即使上层错误调用 track_*，也不会泄露 secrets）
SECRETS_PATTERNS = (
    "api_key",
    "apikey",
    "token",
    "secret",
    "password",
    "passwd",
    "auth",
    "credential",
    "bearer",
    "oauth",
    "private",
)


def _contains_secret_pattern(text: str) -> bool:
    """检查字符串是否含 secret 模式（防御性过滤）。"""
    if not text:
        return False
    lower = text.lower()
    return any(p in lower for p in SECRETS_PATTERNS)


# ────────────────────────────────────────────────────────────────────
# 数据结构
# ────────────────────────────────────────────────────────────────────


def _hash_plugin_id(plugin_id: str) -> str:
    """对 plugin_id 做 SHA-256 hash（不含明文，避免泄露 plugin 拓扑）。"""
    return hashlib.sha256(plugin_id.encode("utf-8")).hexdigest()


@dataclass
class TelemetryPayload:
    """单次聚合上报 payload。

    所有字段均"匿名 + 聚合"；绝不含 user_input / 文件路径 / API key。
    """

    sdk_version: str = ""
    plugin_id_hashes: List[str] = field(default_factory=list)
    protocols_used: Dict[str, List[str]] = field(default_factory=dict)
    """plugin_id_hash → protocols 列表（如 ``{"abc...": ["P1", "P2"]}``）"""
    protocol_call_counts: Dict[str, int] = field(default_factory=dict)
    """protocol 名 → 调用次数（如 ``{"ACTPlugin": 17}``）"""
    error_counts: Dict[str, int] = field(default_factory=dict)
    """error class 名 → 触发次数（如 ``{"PluginLoadError": 3}``）"""
    feature_flags_state: Dict[str, str] = field(default_factory=dict)
    """``KROW_*`` env var 名 → 值（仅 enabled/disabled，不含 secret 字段）"""
    aggregation_started_at: float = 0.0
    aggregation_ended_at: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "sdk_version": self.sdk_version,
            "plugin_id_hashes": list(self.plugin_id_hashes),
            "protocols_used": dict(self.protocols_used),
            "protocol_call_counts": dict(self.protocol_call_counts),
            "error_counts": dict(self.error_counts),
            "feature_flags_state": dict(self.feature_flags_state),
            "aggregation_started_at": self.aggregation_started_at,
            "aggregation_ended_at": self.aggregation_ended_at,
        }

    def is_empty(self) -> bool:
        """是否完全无数据（无 plugin / 无 protocol call / 无 error）→ 跳过 flush。"""
        return (
            not self.plugin_id_hashes
            and not self.protocol_call_counts
            and not self.error_counts
        )


# ────────────────────────────────────────────────────────────────────
# 上报客户端（线程安全单例）
# ────────────────────────────────────────────────────────────────────


class TelemetryClient:
    """SDK 反向 telemetry 客户端（opt-in only）。

    特性：

    - **线程安全**：所有 ``track_*`` 用 ``RLock`` 保护
    - **silent drop**：上报失败 → log debug，不抛异常
    - **后台 flush**：后台线程每 ``flush_interval`` 秒 flush 一次
    - **OFF 时零开销**：``is_telemetry_enabled()`` 返 False 时所有 ``track_*`` 是 no-op

    设计原则：

    - opt-in only：构造时不强制启动后台线程；用户调 ``start()`` 才启动
    - silent drop：``flush()`` 内任何异常都被吞掉（防御 telemetry 故障扩散）
    """

    def __init__(
        self,
        *,
        sdk_version: str = "0.1.0",
        endpoint: Optional[str] = None,
        flush_interval: int = DEFAULT_FLUSH_INTERVAL_SECONDS,
    ) -> None:
        self._sdk_version = sdk_version
        self._endpoint = endpoint or os.environ.get(
            ENV_VAR_TELEMETRY_ENDPOINT, DEFAULT_TELEMETRY_ENDPOINT
        )
        self._flush_interval = max(flush_interval, 60)  # 最低 60s 防 DDoS

        self._lock = threading.RLock()
        self._payload = TelemetryPayload(sdk_version=sdk_version)
        self._payload.aggregation_started_at = time.time()

        self._stop_event = threading.Event()
        self._flush_thread: Optional[threading.Thread] = None
        self._started = False

    # ──────── opt-in 闸门 ────────

    def is_active(self) -> bool:
        """是否处于 active 状态（env opt-in + start() 已调）。"""
        return is_telemetry_enabled() and self._started

    # ──────── track_* API（OFF 时 no-op） ────────

    def track_plugin_register(
        self,
        *,
        plugin_id: str,
        protocols: List[str],
    ) -> None:
        """记录 plugin 注册事件（hash plugin_id）。"""
        if not is_telemetry_enabled():
            return
        if _contains_secret_pattern(plugin_id):
            logger.debug("telemetry: plugin_id 含 secret pattern，已跳过")
            return
        plugin_hash = _hash_plugin_id(plugin_id)
        with self._lock:
            if plugin_hash not in self._payload.plugin_id_hashes:
                self._payload.plugin_id_hashes.append(plugin_hash)
            self._payload.protocols_used[plugin_hash] = list(protocols)

    def track_protocol_call(self, protocol: str) -> None:
        """记录 protocol 被调用一次。"""
        if not is_telemetry_enabled():
            return
        if _contains_secret_pattern(protocol):
            return
        with self._lock:
            self._payload.protocol_call_counts[protocol] = (
                self._payload.protocol_call_counts.get(protocol, 0) + 1
            )

    def track_error(self, error_class: str) -> None:
        """记录 error class 触发一次。"""
        if not is_telemetry_enabled():
            return
        if _contains_secret_pattern(error_class):
            return
        with self._lock:
            self._payload.error_counts[error_class] = (
                self._payload.error_counts.get(error_class, 0) + 1
            )

    def track_feature_flag(self, flag_name: str, enabled: bool) -> None:
        """记录 feature flag 状态（仅 ``KROW_*`` 开头 + 非 secret 字段）。"""
        if not is_telemetry_enabled():
            return
        if not flag_name.startswith("KROW_"):
            return
        if _contains_secret_pattern(flag_name):
            return
        with self._lock:
            self._payload.feature_flags_state[flag_name] = (
                "enabled" if enabled else "disabled"
            )

    # ──────── 后台 flush 控制 ────────

    def start(self) -> None:
        """启动后台 flush 线程（仅 env opt-in 时真启动）。"""
        if not is_telemetry_enabled():
            return
        with self._lock:
            if self._started:
                return
            self._started = True
            self._stop_event.clear()
        self._flush_thread = threading.Thread(
            target=self._flush_loop, name="krow-sdk-telemetry-flush", daemon=True
        )
        self._flush_thread.start()
        logger.info(
            "krow-sdk-telemetry: opt-in 已启用，每 %ds 聚合上报一次到 %s（详 §5.13）",
            self._flush_interval, self._endpoint,
        )

    def stop(self, *, flush_remaining: bool = True) -> None:
        """停止后台线程（进程退出前调；可选 flush 剩余 payload）。"""
        with self._lock:
            if not self._started:
                return
            self._started = False
        self._stop_event.set()
        if self._flush_thread:
            self._flush_thread.join(timeout=5.0)
            self._flush_thread = None
        if flush_remaining:
            try:
                self.flush_now()
            except Exception:  # noqa: BLE001
                pass  # silent drop

    def _flush_loop(self) -> None:
        """后台线程主循环：每 ``flush_interval`` 秒 flush 一次。"""
        while not self._stop_event.wait(self._flush_interval):
            try:
                self.flush_now()
            except Exception as exc:  # noqa: BLE001
                logger.debug("telemetry flush 失败（已 silent drop）：%s", exc)

    # ──────── flush（HTTPS POST） ────────

    def flush_now(self) -> bool:
        """立即聚合 + 上报当前 payload；返回是否成功。

        失败 silent drop（不抛）。空 payload 跳过。
        """
        if not is_telemetry_enabled():
            return False

        with self._lock:
            if self._payload.is_empty():
                return False
            self._payload.aggregation_ended_at = time.time()
            payload_dict = self._payload.to_dict()
            # reset payload（下个聚合周期重新开始）
            self._payload = TelemetryPayload(sdk_version=self._sdk_version)
            self._payload.aggregation_started_at = time.time()

        return self._post_telemetry(payload_dict)

    def _post_telemetry(self, payload_dict: Dict[str, Any]) -> bool:
        """HTTPS POST 上报 payload；任何异常 silent drop。"""
        try:
            import httpx
        except ImportError:
            logger.debug("telemetry: httpx 不可用，silent drop")
            return False

        try:
            with httpx.Client(timeout=DEFAULT_HTTP_TIMEOUT_SECONDS) as client:
                response = client.post(
                    self._endpoint,
                    json=payload_dict,
                    headers={"User-Agent": f"krow-sdk-telemetry/{self._sdk_version}"},
                )
                if 200 <= response.status_code < 300:
                    return True
                logger.debug(
                    "telemetry: 上报返回 %d（silent drop）", response.status_code,
                )
                return False
        except Exception as exc:  # noqa: BLE001 - silent drop is design intent
            logger.debug("telemetry: 上报异常（silent drop）：%s", exc)
            return False

    # ──────── 测试 helper ────────

    def _snapshot_payload_for_test(self) -> TelemetryPayload:
        """仅测试用：返回当前 payload 的副本。"""
        with self._lock:
            snap = TelemetryPayload(
                sdk_version=self._payload.sdk_version,
                plugin_id_hashes=list(self._payload.plugin_id_hashes),
                protocols_used={k: list(v) for k, v in self._payload.protocols_used.items()},
                protocol_call_counts=dict(self._payload.protocol_call_counts),
                error_counts=dict(self._payload.error_counts),
                feature_flags_state=dict(self._payload.feature_flags_state),
                aggregation_started_at=self._payload.aggregation_started_at,
                aggregation_ended_at=self._payload.aggregation_ended_at,
            )
        return snap

    def _reset_for_test(self) -> None:
        """仅测试用：重置内部状态。"""
        with self._lock:
            self._payload = TelemetryPayload(sdk_version=self._sdk_version)
            self._payload.aggregation_started_at = time.time()


# ────────────────────────────────────────────────────────────────────
# 全局单例
# ────────────────────────────────────────────────────────────────────


_global_client: Optional[TelemetryClient] = None
_global_client_lock = threading.RLock()


def get_telemetry_client() -> TelemetryClient:
    """获取全局 TelemetryClient 单例（懒初始化）。"""
    global _global_client
    if _global_client is None:
        with _global_client_lock:
            if _global_client is None:
                _global_client = TelemetryClient()
    return _global_client


def _reset_global_client_for_test() -> None:
    """仅测试用：重置全局单例。"""
    global _global_client
    with _global_client_lock:
        if _global_client is not None:
            try:
                _global_client.stop(flush_remaining=False)
            except Exception:  # noqa: BLE001
                pass
        _global_client = None


__all__ = [
    "DEFAULT_FLUSH_INTERVAL_SECONDS",
    "DEFAULT_TELEMETRY_ENDPOINT",
    "ENV_VAR_TELEMETRY",
    "ENV_VAR_TELEMETRY_ENDPOINT",
    "SECRETS_PATTERNS",
    "TelemetryClient",
    "TelemetryPayload",
    "get_telemetry_client",
    "is_telemetry_enabled",
]
