"""SDK Visual API namespace（Step 2 P2 — visual_inspect plugin 完整公开）.

外部团队 import 路径：

```python
from krow_agent_sdk.visual import (
    VisualAdapter,         # ABC：实现 5 抽象方法即得视觉适配器
    open_adapter,          # context manager：保证 open/close 配对
    ElementEntry,          # inventory 输出单元
    SceneConfig,           # 场景配置（grounding/verify prompt + 角色集）
    SemanticRole,          # ground 输出的单个角色映射
    SemanticMap,           # 单页语义理解
    VisualGroundingResult, # 完整 VG 结果（可缓存）
    visual_inspect,        # 函数式 API：直接调 VLM 质检（v0.9.x · PR 5.5）
    # 角色集常量
    FILLABLE_ROLES,
    PRESERVE_ROLES,
    ALL_ROLES,
    CONFIDENCE_THRESHOLD,
)
```

## 设计

这个模块**只 re-export**，不引入任何新逻辑——把已存在 ``modules/agent/visual/protocol.py``
的公共数据模型 + ABC 公开到 SDK 顶层 namespace.外部团队通过 wheel 安装 SDK
时，``modules.agent.visual`` 路径**不**在 wheel 内（only ``modules.agent.sdk``
被 force-include），所以必须经由 SDK namespace re-export.

## 与 ``VisualAdapterPlugin`` 配合

最小可行 plugin：

```python
from krow_agent_sdk.visual import VisualAdapter
from krow_agent_sdk.experimental.protocols import VisualAdapterPlugin

class MyAdapter(VisualAdapter):
    def open(self, source, **kwargs): ...
    def close(self): ...
    def render(self, page_index, width=960, height=540): ...
    def inventory(self, page_index): ...
    def page_count(self): ...

class MyPlugin:
    plugin_id = "my-vis-2026"
    def get_visual_adapters(self):
        return [(".dwg", MyAdapter)]
```

design doc §5.10 + AGENTS.md §13.9 Step 2 P2.

## M6 1B 双轨 import

- runtime 装上后：``from modules.agent.visual.protocol import ...`` 直接命中真实
- runtime 没装时：fallback 到 ``modules.agent.sdk._vendor.visual_protocol_stub``
  （thin dataclass + ABC + 常量，公开它们不会泄露算法）

详 ``docs/sdk/source-protection-design.md`` §3 D1 决策.
"""
from __future__ import annotations

try:
    from modules.agent.visual.protocol import (
        ALL_ROLES,
        CONFIDENCE_THRESHOLD,
        FILLABLE_ROLES,
        PRESERVE_ROLES,
        ElementEntry,
        SceneConfig,
        SemanticMap,
        SemanticRole,
        VisualAdapter,
        VisualGroundingResult,
        open_adapter,
    )
except ModuleNotFoundError:
    from ._vendor.visual_protocol_stub import (
        ALL_ROLES,
        CONFIDENCE_THRESHOLD,
        FILLABLE_ROLES,
        PRESERVE_ROLES,
        ElementEntry,
        SceneConfig,
        SemanticMap,
        SemanticRole,
        VisualAdapter,
        VisualGroundingResult,
        open_adapter,
    )

def visual_inspect(
    file_path: str,
    *,
    mode: str = "verify",
    page_index: int = -1,
    expectation: str = "",
    delta_context: str | None = None,
) -> dict:
    """SDK 视觉质检函数式 API（v0.9.x · PR 5.5）.

    薄封装：调用主仓 ``modules.agent.visual.visual_grounding_tools
    .handle_visual_inspect`` 工具入口，把 JSON 字符串返回值 parse 成 ``dict``
    交给 plugin 直接消费.

    内部行为：
        - 按 ``file_path`` 扩展名从 ``_ADAPTER_REGISTRY`` 找对应 ``VisualAdapter``
          (含 ``AgentBuilder.with_visual_adapter*`` 注册的 plugin adapter，
          桥接见 ``modules.agent.sdk.builder._register_visual_adapters_to_vg_registry``)
        - 按 ``mode`` 走 ``verify`` (有 expectation 时) / ``analyze`` (无 expectation)
        - VLM 调用走 ``KrowLLMProvider.chat_vision`` (强绑 krow cloud auth/billing)
        - token 成本由 ``BudgetController`` 计入

    Args:
        file_path: 目标文件路径（必须能被某个已注册 adapter 处理；扩展名 lookup）.
        mode: ``"verify"`` (默认，有 expectation 时校验) | ``"analyze"`` (无 expectation
              时纯描述/分析).
        page_index: 指定页索引（``-1`` = 全部页，默认）；单页文件忽略.
        expectation: 预期内容描述（``verify`` 模式生效）；空串等同 ``analyze``.
        delta_context: 上轮编辑摘要（可选），注入 VLM prompt 引导聚焦验证.

    Returns:
        Parse 后的 dict，主要字段：
            - ``success`` (bool): 整体是否通过.
            - ``issues`` (list[dict]): VLM 标记的问题列表（含 ``severity`` /
              ``page`` / ``title`` / ``description`` 等）.
            - ``render_source`` (str): 实际渲染来源（如 ``cairosvg-pisma-svg``
              / ``qgraphics-desktop`` / ``pil-image``）.
            - ``render_fidelity_class`` (str): 渲染保真度等级（``pixel_match``
              / ``geometry_match`` / ``layout_only``）.
        极端情况下（adapter 缺失 / VLM 不可用）返回 ``{"error": "..."}`` 字段.

    Raises:
        RuntimeError: 主仓 ``visual_grounding_tools`` 模块不可导入（SDK wheel
                      未含 visual 子系统；正常装包场景不会发生）.

    Example:
        >>> from krow_agent_sdk.visual import visual_inspect
        >>> result = visual_inspect(
        ...     "/tmp/output.pptx", mode="verify", page_index=-1,
        ...     expectation="标题包含 2026 OKR + 至少 8 页",
        ... )
        >>> if not result.get("success"):
        ...     for issue in result.get("issues", []):
        ...         print(f"[{issue['severity']}] {issue['title']}")
    """
    import json
    try:
        from modules.agent.visual.visual_grounding_tools import (
            handle_visual_inspect,
        )
    except ImportError as exc:
        raise RuntimeError(
            "visual_inspect 不可用：主仓 visual_grounding_tools 模块未装。"
            "可能是 SDK 在不含 visual subsystem 的 minimal wheel 下运行；"
            "查 docs/sdk/source-protection-design.md §3 wheel 边界。"
        ) from exc
    kwargs: dict = {
        "file_path": file_path,
        "mode": mode,
        "page_index": page_index,
        "expectation": expectation,
    }
    if delta_context is not None:
        kwargs["delta_context"] = delta_context
    raw = handle_visual_inspect(**kwargs)
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return {"raw": raw, "parse_error": "non-JSON response"}
    return {"raw": str(raw), "parse_error": f"unexpected type: {type(raw).__name__}"}


def register_default_pptx_adapter() -> str:
    """注册默认的 ``HeadlessPPTXVisualAdapter`` 到 ``visual_inspect`` registry.

    PR-7 (geometry-quality-roadmap Batch 3, 2026-05-16)：让外部 SDK 用户**一行**
    打开 PPTX 视觉质检能力，不需要自己写 ``with_visual_adapter(".pptx", ...)``.

    使用场景
    --------

    plugin 想做"生成 PPTX → 视觉质检"闭环但不想 :pycode:`from modules...` 直接
    引用主仓内部路径（导致 wheel 边界违规 / 版本耦合）.

    .. code-block:: python

        from krow_agent_sdk.visual import register_default_pptx_adapter, visual_inspect

        register_default_pptx_adapter()   # 进程内一次即可
        result = visual_inspect("/tmp/output.pptx", expectation="标题包含 2026 OKR")
        if not result.get("success"):
            for issue in result.get("issues", []):
                print(f"[{issue['severity']}] {issue['title']}")

    与 ``AgentBuilder.with_default_pptx_adapter()`` 区别
    ------------------------------------------------------

    - **本函数（register_default_pptx_adapter）**：进程级 registry 修改，立即生效，
      ``visual_inspect`` 函数式 API 直接可用；不与某个 Agent 实例绑定.
    - **AgentBuilder.with_default_pptx_adapter()**：仅在 ``build()`` 后该 Agent
      生命周期内注册；``shutdown()`` 自动 unregister.

    依赖准备
    --------

    本函数运行需要安装 ``krow-agent-sdk[visual]`` extra 提供的 ``cairosvg /
    cairocffi / lxml / Pillow``，并装系统库 ``libcairo2 + libpango``（Linux：
    ``apt-get install libcairo2 libpango-1.0-0 fonts-noto-cjk``；macOS：
    ``brew install cairo pango``）.

    缺依赖时本函数仍能注册 adapter 类（注册成功），但 ``visual_inspect`` 实际
    渲染时会抛 ``HeadlessRenderUnavailable``——交由调用方决定处理（fallback
    到 PIL / 跳过 / 报错）.

    Returns:
        实际注册的扩展名（``.pptx``）.

    Raises:
        RuntimeError: 主仓 ``HeadlessPPTXVisualAdapter`` 模块不可导入
                      （非 ``[visual]`` extra 缺失的问题；通常是 wheel 边界
                      被破坏或 visual subsystem 没在当前 Python 路径下）.
    """
    try:
        from modules.agent.visual.adapters.headless_pptx_adapter import (
            HeadlessPPTXVisualAdapter,
        )
        from modules.agent.visual.visual_grounding_tools import (
            register_visual_adapter,
        )
    except ImportError as exc:
        raise RuntimeError(
            "register_default_pptx_adapter 失败：HeadlessPPTXVisualAdapter "
            "或 visual_grounding_tools 不可导入。\n"
            "可能原因：\n"
            "  1) 当前 SDK wheel 不含 visual subsystem（请用 monorepo "
            "     ``pip install -e .[sdk]`` 或 future ``krow-agent-sdk[visual]``）\n"
            "  2) 主仓 visual 模块路径异常（联系 krow 维护方）\n"
            f"原始错误：{type(exc).__name__}: {exc}"
        ) from exc

    register_visual_adapter(".pptx", HeadlessPPTXVisualAdapter)
    return ".pptx"


__all__ = [
    "VisualAdapter",
    "open_adapter",
    "ElementEntry",
    "SceneConfig",
    "SemanticRole",
    "SemanticMap",
    "VisualGroundingResult",
    "visual_inspect",
    "register_default_pptx_adapter",
    "FILLABLE_ROLES",
    "PRESERVE_ROLES",
    "ALL_ROLES",
    "CONFIDENCE_THRESHOLD",
]
