"""Krow Agent SDK 错误层（v0.8 design doc §3.5 完整黄金模板 message 文本）

每个 error class 严格按 ``AGENTS.md §五黄金模板``：一句话 + 原因 + 位置 + 1-3 个修法 + 相关链接。

涉及 design doc 修订条目：D3 / R30 / R26 / A6 / A7。
"""
from __future__ import annotations

from typing import Optional


class KrowSDKError(RuntimeError):
    """Krow Agent SDK 错误根基类。

    所有 SDK fail-loud 错误继承本类，便于业务侧统一捕获边界。
    """

    DEFAULT_MESSAGE: str = ""

    def __init__(self, message: Optional[str] = None, **fields: object) -> None:
        text = message if message is not None else self.DEFAULT_MESSAGE
        if fields:
            try:
                text = text.format(**fields)
            except (KeyError, IndexError):
                pass
        super().__init__(text)
        self.fields = dict(fields)


# ────────────────────────────────────────────────────────────────────────
# Auth / API Key 类（design doc §3.5 + R30 / A6）
# ────────────────────────────────────────────────────────────────────────


class MissingKrowAPIKeyError(KrowSDKError):
    """`AgentBuilder.build()` 时未调 `with_krow_api_key()` 且 `KROW_API_KEY` env var 未设。"""

    DEFAULT_MESSAGE = (
        "❌ AgentBuilder.build() 缺少 krow cloud API key。\n"
        "原因：strong-bound LLM 链路（详 design doc §3）必须有有效 API key 才能调 https://api.krow.cn/v1。\n"
        "位置：AgentBuilder（任一 with_* 链尾的 .build() 调用点）。\n"
        "你可以：\n"
        "  1) 在 https://krow.cn API 密钥页面创建 key（前缀 sk-user-），然后调 .with_krow_api_key('sk-user-xxxxx').build()\n"
        "  2) 设环境变量 KROW_API_KEY=sk-user-xxxxx，然后用 AgentBuilder.from_env().build()\n"
        "  3) 见 docs/sdk/plugin-architecture-design.md §3.2"
    )


class InvalidKrowAPIKeyError(KrowSDKError):
    """`with_krow_api_key(key)` 时格式校验失败（非 `sk-` 前缀 / 长度不足 / 含非法字符）。"""

    DEFAULT_MESSAGE = (
        "❌ 传入的 API key 格式不合法：'{masked_key}'\n"
        "原因：krow cloud API key 必须以 'sk-' 开头（OpenAI 兼容格式），通常是 'sk-user-' 前缀（个人 key）。\n"
        "位置：AgentBuilder.with_krow_api_key(api_key=...)\n"
        "你可以：\n"
        "  1) 检查 key 是否完整复制（尾部空格 / 引号已剥）\n"
        "  2) 到 https://krow.cn 重新创建一个 key\n"
        "  3) 用 AgentBuilder.from_env() 从环境变量读避免手敲漏字符"
    )


class KrowAPIKeyInvalidError(KrowSDKError):
    """首次 `provider.generate()` 调用 api.krow.cn 返回 HTTP 401。"""

    DEFAULT_MESSAGE = (
        "❌ krow cloud 拒绝当前 API key（HTTP 401 from https://api.krow.cn）。\n"
        "原因：API key 已撤销 / 已过期 / 不属于当前账户。\n"
        "位置：第一次 LLM 调用（KrowLLMProvider.chat 内 httpx.post 401 响应）。\n"
        "你可以：\n"
        "  1) 到 https://krow.cn API 密钥页面确认 key 状态\n"
        "  2) 创建新 key 替换\n"
        "  3) 若 build() 时已知风险可加 .build(validate_connection=True)（见 §7.1）让 SDK 在 build 阶段而非 first run 时报错"
    )


class KrowQuotaExceededError(KrowSDKError):
    """`provider.generate()` 调用返回 HTTP 402 / 服务端 quota_exceeded 响应。"""

    DEFAULT_MESSAGE = (
        "❌ API key 余额不足或超出配额（HTTP 402 from https://api.krow.cn）。\n"
        "原因：当前 sk-user-xxx 余额耗尽 / 触发服务端限速 / 月度配额耗尽。\n"
        "位置：LLM 调用过程中（具体哪一步见 stack trace 中 source_module 字段）。\n"
        "你可以：\n"
        "  1) 到 https://krow.cn 充值或开通更高套餐\n"
        "  2) 用 BudgetSpec 降低 max_total_llm_calls（见 §6.1）\n"
        "  3) 主测试链改走 LLMReplayStore 零成本回放（见 §11.4）"
    )


class LLMProviderError(KrowSDKError):
    """LLM 调用失败（网络 / 5xx / 模型错误 / fallback 链耗尽）。"""

    DEFAULT_MESSAGE = (
        "❌ LLM provider 调用失败（{reason}）。\n"
        "原因：网络瞬断 / 服务端 5xx / 模型路由错误。\n"
        "位置：KrowLLMProvider 内部 retry 链耗尽（默认 3 次）。\n"
        "你可以：\n"
        "  1) 检查 https://krow.cn 服务状态页\n"
        "  2) 重试任务（agent.run 是幂等的）\n"
        "  3) 若长期失败提交 bug report：krow_agent_sdk.diagnostics.dump_state(agent) 输出含 trace（见 §6.7）"
    )


# ────────────────────────────────────────────────────────────────────────
# Project root（design doc §7 / D7）
# ────────────────────────────────────────────────────────────────────────


class MissingProjectRootError(KrowSDKError):
    """`build()` 时未调 `with_project_root()` 且 `KROW_PROJECT_ROOT` env var 未设（force_explicit 策略）。"""

    DEFAULT_MESSAGE = (
        "❌ AgentBuilder.build() 缺少项目根目录（force_explicit 策略）。\n"
        "原因：项目根是 native 工具（document_reader / pptx_editor / native_fileops 等）的 SSOT，"
        "不能默认成 cwd（多租户 / 多 agent 实例时易污染）。\n"
        "位置：AgentBuilder.build() 调用点。\n"
        "你可以：\n"
        "  1) 显式 .with_project_root('/data/myproject')\n"
        "  2) 设环境变量 KROW_PROJECT_ROOT 然后用 AgentBuilder.from_env()\n"
        "  3) 见 design doc §7"
    )


class ProjectRootNotWritableError(MissingProjectRootError):
    """`build(validate_connection=True)` 时检测 project root 不可写（A6）。"""

    DEFAULT_MESSAGE = (
        "❌ 项目根目录不可写：'{project_root}'\n"
        "原因：build(validate_connection=True) 启动期写权限测试失败。\n"
        "位置：AgentBuilder.build() 内部 _validate_project_root_writable。\n"
        "你可以：\n"
        "  1) chmod / icacls 给目录加写权限\n"
        "  2) 换一个可写路径\n"
        "  3) build(validate_connection=False) 跳过校验（不推荐生产）"
    )


# ────────────────────────────────────────────────────────────────────────
# Plugin 类（design doc R26 / D6 / A1 / A8）
# ────────────────────────────────────────────────────────────────────────


class PluginSignatureMismatchError(KrowSDKError):
    """v0.8 R26：启动期 plugin signature validator 检测到 plugin 实现的方法签名与 Protocol 不匹配。"""

    DEFAULT_MESSAGE = (
        "❌ Plugin {plugin_id} 实现的 {protocol_name}.{method} 签名不匹配契约。\n"
        "原因：runtime_checkable Protocol 只查方法名存在性，不查签名/类型/返回值；"
        "signature validator 启动期对比发现 plugin 方法签名与 Protocol 定义不一致。\n"
        "位置：plugin entry_points 加载期（_protocol_validator.validate_protocol_implementation）。\n"
        "Protocol 定义签名：{expected_sig}\n"
        "Plugin 实际签名：{actual_sig}\n"
        "你可以：\n"
        "  1) 修正 plugin 方法签名（推荐 mypy --strict 在 plugin CI 跑契约测试）\n"
        "  2) 临时设 KROW_SDK_SIGNATURE_VALIDATION=0 跳过校验（不推荐，仅 dev/debug）\n"
        "  3) 见 design doc §0.3 R26 + §5 Protocol 契约测试模板"
    )


class InvalidPluginIDError(KrowSDKError):
    """v0.8 A8：plugin_id 双段命名规范校验失败。"""

    DEFAULT_MESSAGE = (
        "❌ plugin_id 格式不合法：'{plugin_id}'\n"
        "原因：必须是 '<org>.<plugin_name>' 双段命名\n"
        "  <org>: 全小写 [a-z0-9_-] 3-20 字符\n"
        "  <plugin_name>: 全小写 [a-z0-9_] 3-30 字符\n"
        "位置：plugin entry_points 加载期。\n"
        "你可以：\n"
        "  1) 在你的 pyproject.toml entry_points 改成 'org.plugin_name = your_module:plugin'\n"
        "  2) 见 docs/sdk/plugin-architecture-design.md §5.0.5"
    )


class DuplicatePluginIDError(KrowSDKError):
    """v0.8 A8：同 SDK 进程内 plugin_id 撞名。"""

    DEFAULT_MESSAGE = (
        "❌ Plugin ID 撞名：'{plugin_id}' 已被另一个 plugin 注册。\n"
        "原因：同 SDK 进程内 plugin_id 必须全局唯一。\n"
        "位置：plugin 加载期；冲突在 entry_point '{conflict_entry}' 与 '{existing_entry}' 之间。\n"
        "你可以：\n"
        "  1) 检查 pyproject.toml entry_points 是否两个 plugin 用了同一 plugin_id\n"
        "  2) 改 plugin_id 加更具体的 <plugin_name> 段\n"
        "  3) 见 docs/sdk/plugin-architecture-design.md §5.0.5"
    )


class PluginLoadError(KrowSDKError):
    """plugin entry_points 加载失败（import error / on_load 抛异常等）。"""

    DEFAULT_MESSAGE = (
        "❌ Plugin '{plugin_id}' 加载失败：{reason}\n"
        "位置：{location}\n"
        "你可以：\n"
        "  1) 检查 plugin 包安装是否完整（pip install -e .）\n"
        "  2) 检查 plugin on_load() 实现是否抛异常\n"
        "  3) 临时设 KROW_SDK_PLUGIN_ERROR_MODE=raise 看完整 stack trace"
    )
