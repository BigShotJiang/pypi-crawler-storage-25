"""Plugin signature validator（design doc §0.3 R26 + 顶级 review A1 + Step 1 PR S1.19）。

``@runtime_checkable Protocol`` 只查方法名是否存在，**不查签名 / 类型 / 返回值**。
本模块在启动期用 ``inspect.signature`` 真实校验 plugin 方法签名 vs Protocol 定义，
不一致 fail-loud（``PluginSignatureMismatchError``）。

环境变量：

- ``KROW_SDK_SIGNATURE_VALIDATION=0`` → 跳过校验（仅 dev/debug，不推荐生产）
"""
from __future__ import annotations

import inspect
import os
from typing import Any

from .errors import PluginSignatureMismatchError

ENV_FLAG = "KROW_SDK_SIGNATURE_VALIDATION"


def _signature_validation_enabled() -> bool:
    raw = os.environ.get(ENV_FLAG, "1").strip()
    return raw not in {"0", "false", "False", "FALSE", ""}


def _format_signature(sig: inspect.Signature) -> str:
    return str(sig)


def _is_compatible_signature(
    expected: inspect.Signature,
    actual: inspect.Signature,
) -> bool:
    """是否签名兼容。

    简化策略（v0.8 Wave 1 起步）：仅比对**位置参数 + 默认参数 + 必填参数数量**；
    不强制 annotation 完全一致——实战中 plugin 写不完整 annotation 仍属常见，
    Wave 2 可考虑收紧（mypy plugin）。

    严格条件：
    - 必填位置参数数量必须一致（self 除外）
    - 可变长度参数（``*args`` / ``**kwargs``）位置必须一致
    - 关键参数缺失即不兼容（plugin 多加可选参数允许，少必填不允许）
    """
    expected_params = [p for p in expected.parameters.values() if p.name != "self"]
    actual_params = [p for p in actual.parameters.values() if p.name != "self"]

    expected_required = [p for p in expected_params if p.default is inspect.Parameter.empty
                         and p.kind not in {inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD}]
    actual_required = [p for p in actual_params if p.default is inspect.Parameter.empty
                       and p.kind not in {inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD}]

    if len(expected_required) != len(actual_required):
        return False

    expected_names = {p.name for p in expected_required}
    actual_names = {p.name for p in actual_required}
    if expected_names != actual_names:
        return False

    return True


def validate_protocol_implementation(
    plugin: Any,
    protocol: type,
    *,
    plugin_id: str = "<unknown>",
) -> None:
    """启动期对比 plugin 实现的方法签名 vs Protocol 定义；不一致 fail-loud。

    Args:
        plugin: plugin instance
        protocol: ``Protocol`` 定义类（带 ``@runtime_checkable``）
        plugin_id: plugin 自报 ID，用于 error message 定位

    Raises:
        PluginSignatureMismatchError: 任一方法签名不匹配
    """
    if not _signature_validation_enabled():
        return

    protocol_name = protocol.__name__

    expected_methods = {
        name: getattr(protocol, name)
        for name in getattr(protocol, "__abstractmethods__", set())
        if callable(getattr(protocol, name, None))
    }

    if not expected_methods:
        for name in dir(protocol):
            if name.startswith("_"):
                continue
            value = getattr(protocol, name, None)
            if callable(value) and not inspect.isclass(value):
                expected_methods[name] = value

    for method_name, expected_callable in expected_methods.items():
        actual_callable = getattr(plugin, method_name, None)
        if actual_callable is None:
            raise PluginSignatureMismatchError(
                plugin_id=plugin_id,
                protocol_name=protocol_name,
                method=method_name,
                expected_sig=_format_signature(inspect.signature(expected_callable)),
                actual_sig="<not implemented>",
            )

        if not callable(actual_callable):
            raise PluginSignatureMismatchError(
                plugin_id=plugin_id,
                protocol_name=protocol_name,
                method=method_name,
                expected_sig=_format_signature(inspect.signature(expected_callable)),
                actual_sig="<not callable>",
            )

        try:
            expected_sig = inspect.signature(expected_callable)
            actual_sig = inspect.signature(actual_callable)
        except (ValueError, TypeError):
            continue

        if not _is_compatible_signature(expected_sig, actual_sig):
            raise PluginSignatureMismatchError(
                plugin_id=plugin_id,
                protocol_name=protocol_name,
                method=method_name,
                expected_sig=_format_signature(expected_sig),
                actual_sig=_format_signature(actual_sig),
            )
