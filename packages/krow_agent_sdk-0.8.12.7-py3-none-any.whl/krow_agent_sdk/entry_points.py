"""Krow Agent SDK entry_points 自动发现框架（PR B1 / S2.1-3）。

外部 plugin 包通过 ``pyproject.toml`` 暴露 entry_points，SDK 启动时自动扫描 +
实例化 + 走 ``with_*_plugin()`` 加载链。

## 标准 entry_points group 命名

| Protocol | group |
|---|---|
| ``ACTPlugin`` | ``krow.act`` |
| ``ToolPlugin`` | ``krow.tool`` |
| ``GatePlugin`` | ``krow.gate`` |
| ``HintPlugin`` | ``krow.hint`` |
| ``EventListenerPlugin`` | ``krow.event_listener`` |
| ``ObservabilityPlugin`` | ``krow.observability`` |
| ``MCPServerPlugin`` | ``krow.mcp_server`` |
| ``SecurityPlugin`` | ``krow.security`` |
| ``DomainPackPlugin`` | ``krow.domain_pack`` |

## 外部 plugin 包示例（pyproject.toml）

```toml
[project.entry-points."krow.tool"]
my_search_tool = "my_pkg.plugins:MySearchToolPlugin"

[project.entry-points."krow.act"]
my_research_act = "my_pkg.plugins:MyResearchACTPlugin"
```

## SDK 调用方式

```python
builder = (
    AgentBuilder()
    .with_krow_api_key(api_key)
    .with_project_root(root)
    .with_act_plugins_from_entry_points()      # 自动扫 krow.act group
    .with_tool_plugins_from_entry_points()     # 自动扫 krow.tool group
    .with_gate_plugins_from_entry_points()     # 自动扫 krow.gate group
)
agent = builder.build()
```

## Feature flag

``KROW_ENABLE_PLUGIN_ENTRY_POINTS`` env var 控制是否自动扫描 entry_points：

- ``KROW_ENABLE_PLUGIN_ENTRY_POINTS=0`` (默认)：扫描函数仍可手动调，但
  ``AgentBuilder.with_*_plugins_from_entry_points()`` 会跳过扫描（返回空列表）
- ``KROW_ENABLE_PLUGIN_ENTRY_POINTS=1``：完整 opt-in 自动发现
- ``AgentBuilder.with_*_plugins_from_entry_points(force=True)``：忽略 env，强制扫描

设计原因（PR B3 / S2.9）：默认 OFF 保护现有部署不引入未知第三方 plugin；
plugin 作者发布安装包后，用户需要主动 ``export KROW_ENABLE_PLUGIN_ENTRY_POINTS=1``
才会被 SDK 自动扫到——这是 supply-chain 安全的标准做法。

## 容错策略（与 ``_handle_plugin_error`` 一致）

- entry_point 加载失败 / class 实例化失败 → 单条 plugin 跳过 + log warning
- 不让一个坏 plugin 阻塞整个 builder
- 由 ``KROW_SDK_PLUGIN_ERROR_MODE=raise`` 切到严格 fail-loud

设计文档锚点：§5.0.1 / §6.1 / §9.2 S2.1-3。
"""
from __future__ import annotations

import logging
import os
from importlib.metadata import EntryPoint, entry_points
from typing import Any, Callable, List, Type, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")


# ────────────────────────────────────────────────────────────────────
# Feature flag（PR B3 / S2.9）
# ────────────────────────────────────────────────────────────────────

ENV_VAR_ENABLE_PLUGIN_ENTRY_POINTS = "KROW_ENABLE_PLUGIN_ENTRY_POINTS"
"""控制 ``AgentBuilder.with_*_plugins_from_entry_points()`` 是否真扫描 entry_points 的 env var。"""

_TRUTHY_ENV_VALUES = {"1", "true", "yes", "on"}


def is_plugin_entry_points_enabled() -> bool:
    """检查环境变量是否启用 plugin entry_points 自动扫描。

    返回 ``True`` 当且仅当 ``KROW_ENABLE_PLUGIN_ENTRY_POINTS`` 设为
    ``1`` / ``true`` / ``yes`` / ``on``（不区分大小写）。其他值（包括
    未设置）一律返回 ``False``——即默认 opt-in 而非 opt-out。
    """
    raw = os.environ.get(ENV_VAR_ENABLE_PLUGIN_ENTRY_POINTS, "")
    return raw.strip().lower() in _TRUTHY_ENV_VALUES


# ────────────────────────────────────────────────────────────────────
# entry_points group 命名 SSOT
# ────────────────────────────────────────────────────────────────────

GROUP_ACT = "krow.act"
GROUP_TOOL = "krow.tool"
GROUP_GATE = "krow.gate"
GROUP_HINT = "krow.hint"
GROUP_EVENT_LISTENER = "krow.event_listener"
GROUP_OBSERVABILITY = "krow.observability"
GROUP_MCP_SERVER = "krow.mcp_server"
GROUP_SECURITY = "krow.security"
GROUP_DOMAIN_PACK = "krow.domain_pack"
GROUP_VISUAL_ADAPTER = "krow.visual_adapter"

ALL_GROUPS = (
    GROUP_ACT,
    GROUP_TOOL,
    GROUP_GATE,
    GROUP_HINT,
    GROUP_EVENT_LISTENER,
    GROUP_OBSERVABILITY,
    GROUP_MCP_SERVER,
    GROUP_SECURITY,
    GROUP_DOMAIN_PACK,
    GROUP_VISUAL_ADAPTER,
)


# ────────────────────────────────────────────────────────────────────
# 通用发现函数
# ────────────────────────────────────────────────────────────────────


def discover_entry_points(group: str) -> List[EntryPoint]:
    """返回指定 group 下的所有 entry_points。
    
    标准 importlib.metadata API；Python 3.10+ 支持 ``select(group=...)``。
    
    Args:
        group: entry_points group 名（如 ``"krow.tool"``）
    
    Returns:
        list[EntryPoint]；group 不存在时返回空列表（不抛）
    """
    try:
        eps = entry_points()
        # Python 3.10+ 风格
        if hasattr(eps, "select"):
            return list(eps.select(group=group))
        # 兼容更旧 API（dict-like）
        return list(eps.get(group, []))  # type: ignore[union-attr]
    except Exception as exc:  # noqa: BLE001
        logger.warning("discover_entry_points: group=%r 扫描失败：%s", group, exc)
        return []


def load_plugin_from_entry_point(
    ep: EntryPoint,
    *,
    expected_protocol: Type[T],
) -> Any:
    """从 EntryPoint 加载 + 实例化一个 plugin。
    
    流程：
    1. ``ep.load()`` 拿到 class（或工厂函数）
    2. 调用 ``cls()`` 实例化
    3. 校验实例符合 ``expected_protocol``
    
    Args:
        ep: EntryPoint 对象
        expected_protocol: 期望的 Protocol 类（如 ``ToolPlugin``）
    
    Returns:
        plugin 实例（class instance）
    
    Raises:
        TypeError: 加载结果非 callable / 实例不符合 protocol
        Exception: load() / __init__ 抛出的任意异常
    """
    loaded = ep.load()
    if not callable(loaded):
        raise TypeError(
            f"EntryPoint {ep.name!r} (group={ep.group!r}) load 返回非 callable 对象 {type(loaded)}"
        )
    
    instance = loaded()
    
    # Runtime 校验是否符合 Protocol（duck typing 兼容）
    if not isinstance(instance, expected_protocol):
        raise TypeError(
            f"EntryPoint {ep.name!r} (group={ep.group!r}) 实例类型 {type(instance).__name__} "
            f"不符合 protocol {expected_protocol.__name__}",
        )
    
    return instance


def discover_plugins_for_protocol(
    group: str,
    protocol_class: Type[T],
    *,
    error_handler: Callable[[str, Exception], None] | None = None,
) -> List[T]:
    """高层 API：扫描 group + 加载所有 plugin + 容错处理。
    
    用于 ``AgentBuilder.with_*_plugins_from_entry_points()`` 内部。
    
    Args:
        group: entry_points group（如 ``"krow.tool"``）
        protocol_class: 期望的 Protocol 类
        error_handler: 单条 plugin 加载失败时的回调；None 时仅 log warning
    
    Returns:
        加载成功的 plugin 实例列表（顺序按 entry_point 名称字典序）
    """
    eps = sorted(discover_entry_points(group), key=lambda e: e.name)
    plugins: List[T] = []
    
    for ep in eps:
        try:
            instance = load_plugin_from_entry_point(ep, expected_protocol=protocol_class)
            plugins.append(instance)
            logger.debug(
                "entry_points: 加载成功 group=%s name=%s class=%s",
                group, ep.name, type(instance).__name__,
            )
        except Exception as exc:  # noqa: BLE001
            if error_handler is not None:
                error_handler(ep.name, exc)
            else:
                logger.warning(
                    "entry_points: 加载失败（已跳过）group=%s name=%s 错误=%s",
                    group, ep.name, exc,
                )
    
    return plugins


__all__ = [
    "ALL_GROUPS",
    "ENV_VAR_ENABLE_PLUGIN_ENTRY_POINTS",
    "GROUP_ACT",
    "GROUP_DOMAIN_PACK",
    "GROUP_EVENT_LISTENER",
    "GROUP_GATE",
    "GROUP_HINT",
    "GROUP_MCP_SERVER",
    "GROUP_OBSERVABILITY",
    "GROUP_SECURITY",
    "GROUP_TOOL",
    "GROUP_VISUAL_ADAPTER",
    "discover_entry_points",
    "discover_plugins_for_protocol",
    "is_plugin_entry_points_enabled",
    "load_plugin_from_entry_point",
]
