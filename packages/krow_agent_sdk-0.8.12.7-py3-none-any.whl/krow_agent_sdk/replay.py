"""LLM Record-Replay 框架 —— SDK 公开 API（P1b · 2026-05-13）。

> 本模块原位于 ``tests/support/llm_replay.py``（M6-4 落地）；P1b 物理迁出到 SDK，
> 让外部 SDK 用户在 ``pip install krow[sdk]`` 后也能用 record/replay 写自己的
> plugin / agent E2E 测试，而不必复制 fixture 框架代码。
> ``tests/support/llm_replay.py`` 保留为 backward-compat shim 转发到本模块。

支持两种模式：

- **record**：透传到真实 LLM provider，把每次调用的请求/响应写进 JSON fixture
- **replay**：不调用真实 LLM，按请求哈希直接从 fixture 读返回值

设计原则：

1. **零侵入**：用 wrap 的方式套在任意 LLMInterface 实现外面，不改产品代码
2. **幂等 key**：对 messages 做 **canonical** 序列化（role + content 规范化、
   去除时间戳类动态字段），SHA-256 生成 key；同样 prompt 必然命中同一条录制
3. **CI 友好**：replay 模式不需要网络，不需要 API key，pytest 可稳定跑
4. **故障暴露**：miss 默认抛 ``LLMReplayMiss``（而非静默 fallthrough 到真实请求
   产生费用），可 opt-in ``on_miss="passthrough"``

用法（外部 SDK 用户视角）：

.. code-block:: python

    from krow_agent_sdk.replay import LLMReplayStore, RecordReplayWrapper

    store = LLMReplayStore.from_env("tests/fixtures/my_plugin_replay.json")
    real_provider = build_real_provider()
    wrapped = RecordReplayWrapper(real_provider, store)
    # 把 wrapped 注入到 AgentV3 使用的地方
"""
from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Literal, Optional

Mode = Literal["record", "replay", "auto"]
# "raise"：miss 时抛错（CI 严格回放）
# "passthrough"：miss 时调真实 LLM，**但不回写**（保持 fixture 最小化）
# "record_on_miss"：miss 时调真实 LLM，**并把结果写回** fixture（auto 模式默认）
MissPolicy = Literal["raise", "passthrough", "record_on_miss"]


class LLMReplayError(RuntimeError):
    """录制/回放框架基础异常。"""


class LLMReplayMiss(LLMReplayError):
    """replay 模式下找不到对应的录制记录。"""

    def __init__(self, request_hash: str, prompt_preview: str):
        super().__init__(
            f"LLM replay cache miss hash={request_hash[:12]} "
            f"prompt='{prompt_preview[:80]}...'. "
            "请在 record 模式下重新录制 fixture。"
        )
        self.request_hash = request_hash


def _messages_to_canonical(messages: Any) -> List[Dict[str, str]]:
    """把 ChatMessage / dict / 其他结构都归一成 ``[{role, content}]``。

    不引入对 modules.ai.providers 的硬依赖（避免循环 import 问题），用 duck typing。
    """
    out: List[Dict[str, str]] = []
    if not messages:
        return out
    for msg in messages:
        if isinstance(msg, dict):
            role = str(msg.get("role", ""))
            content = str(msg.get("content", ""))
        else:
            role = str(getattr(msg, "role", ""))
            content = str(getattr(msg, "content", ""))
        content = content.replace("\r\n", "\n").strip()
        out.append({"role": role, "content": content})
    return out


def compute_request_hash(messages: Any, extra: Optional[Dict[str, Any]] = None) -> str:
    """对 messages + extra 元数据计算稳定哈希（SHA-256 前 32 hex）。"""
    canonical = _messages_to_canonical(messages)
    payload: Dict[str, Any] = {"messages": canonical}
    if extra:
        payload["extra"] = {k: extra[k] for k in sorted(extra)}
    data = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(data).hexdigest()[:32]


@dataclass
class ReplayRecord:
    request_hash: str
    messages: List[Dict[str, str]]
    response: str
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> Dict[str, Any]:
        return {
            "request_hash": self.request_hash,
            "messages": self.messages,
            "response": self.response,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }

    @classmethod
    def from_json(cls, obj: Dict[str, Any]) -> "ReplayRecord":
        return cls(
            request_hash=obj["request_hash"],
            messages=obj.get("messages", []),
            response=obj.get("response", ""),
            timestamp=obj.get("timestamp", 0.0),
            metadata=obj.get("metadata", {}),
        )


class LLMReplayStore:
    """文件型 KV 存储，key=request_hash，value=ReplayRecord。

    写入是 append-style（每次 record 追加或覆盖同 hash），读取纯内存字典。线程安全。
    """

    def __init__(self, path: Path, mode: Mode, on_miss: MissPolicy = "raise") -> None:
        self._path = Path(path)
        self._mode: Mode = mode
        self._on_miss: MissPolicy = on_miss
        self._lock = threading.RLock()
        self._records: Dict[str, ReplayRecord] = {}
        self._load()

    @classmethod
    def from_env(
        cls,
        path: str,
        mode_env: str = "KROW_LLM_REPLAY_MODE",
        default: Mode = "replay",
    ) -> "LLMReplayStore":
        """根据环境变量选择模式。默认 ``replay``（CI 友好）。

        - 设置 ``KROW_LLM_REPLAY_MODE=record`` 本地录制
        - ``KROW_LLM_REPLAY_MODE=auto``：fixture 存在则 replay，不存在则 record
        """
        raw = os.environ.get(mode_env, default).lower()
        if raw not in ("record", "replay", "auto"):
            raw = default
        p = Path(path)
        effective: Mode
        if raw == "auto":
            effective = "replay" if p.exists() else "record"
        else:
            effective = raw  # type: ignore[assignment]
        return cls(p, mode=effective)

    def _load(self) -> None:
        if not self._path.exists():
            return
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
            for item in data.get("records", []):
                rec = ReplayRecord.from_json(item)
                self._records[rec.request_hash] = rec
        except (json.JSONDecodeError, OSError) as e:
            raise LLMReplayError(f"无法加载 fixture {self._path}: {e}")

    def _persist(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        body = {
            "version": 1,
            "records": [r.to_json() for r in self._records.values()],
        }
        tmp = self._path.with_suffix(self._path.suffix + ".tmp")
        tmp.write_text(
            json.dumps(body, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        tmp.replace(self._path)

    @property
    def mode(self) -> Mode:
        return self._mode

    @property
    def path(self) -> Path:
        return self._path

    @property
    def on_miss(self) -> MissPolicy:
        return self._on_miss

    def size(self) -> int:
        with self._lock:
            return len(self._records)

    def put(self, record: ReplayRecord) -> None:
        with self._lock:
            self._records[record.request_hash] = record
            self._persist()

    def get(self, request_hash: str) -> Optional[ReplayRecord]:
        with self._lock:
            return self._records.get(request_hash)

    def has(self, request_hash: str) -> bool:
        with self._lock:
            return request_hash in self._records


class RecordReplayWrapper:
    """把任意 LLMInterface 包装成 record/replay 适配器。

    代理 ``generate(messages)`` 与 ``stream(messages, stop_event)``；其他方法原样
    透传（via __getattr__）。
    """

    def __init__(
        self,
        base: Any,
        store: LLMReplayStore,
        extra_key: Optional[Dict[str, Any]] = None,
    ):
        self._base = base
        self._store = store
        self._extra_key = extra_key or {}

    def __getattr__(self, name: str) -> Any:
        return getattr(self._base, name)

    def generate(self, messages: List[Any], *args, **kwargs) -> str:
        extra = dict(self._extra_key)
        if kwargs:
            for k in sorted(kwargs):
                extra[f"kw.{k}"] = _sanitize_extra_value(kwargs[k])
        h = compute_request_hash(messages, extra)
        if self._store.mode == "replay":
            rec = self._store.get(h)
            if rec is None:
                if self._store.on_miss == "passthrough":
                    return self._base.generate(messages, *args, **kwargs)
                if self._store.on_miss == "record_on_miss":
                    text = self._base.generate(messages, *args, **kwargs)
                    self._store.put(ReplayRecord(
                        request_hash=h,
                        messages=_messages_to_canonical(messages),
                        response=text,
                        metadata=dict(extra),
                    ))
                    return text
                preview = ""
                if messages:
                    last = messages[-1]
                    preview = getattr(last, "content", "") or (
                        last.get("content", "") if isinstance(last, dict) else ""
                    )
                raise LLMReplayMiss(h, preview)
            return rec.response

        text = self._base.generate(messages, *args, **kwargs)
        self._store.put(ReplayRecord(
            request_hash=h,
            messages=_messages_to_canonical(messages),
            response=text,
            metadata=dict(extra),
        ))
        return text

    def stream(
        self, messages: List[Any], stop_event: Any = None, *args, **kwargs,
    ) -> Iterable[str]:
        """流式调用。replay 模式把文本切片吐出以模拟流式；record 模式
        透传真实 stream 并累积成完整文本落盘。"""
        extra = dict(self._extra_key)
        if kwargs:
            for k in sorted(kwargs):
                extra[f"kw.{k}"] = _sanitize_extra_value(kwargs[k])
        h = compute_request_hash(messages, extra)

        if self._store.mode == "replay":
            rec = self._store.get(h)
            if rec is None:
                if self._store.on_miss == "passthrough":
                    yield from self._base.stream(messages, stop_event, *args, **kwargs)
                    return
                if self._store.on_miss == "record_on_miss":
                    collected: List[str] = []
                    for piece in self._base.stream(messages, stop_event, *args, **kwargs):
                        collected.append(piece)
                        yield piece
                    full = "".join(collected)
                    self._store.put(ReplayRecord(
                        request_hash=h,
                        messages=_messages_to_canonical(messages),
                        response=full,
                        metadata={**extra, "streamed": True},
                    ))
                    return
                preview = ""
                if messages:
                    last = messages[-1]
                    preview = getattr(last, "content", "") or (
                        last.get("content", "") if isinstance(last, dict) else ""
                    )
                raise LLMReplayMiss(h, preview)
            text = rec.response
            chunk_size = 100
            for i in range(0, len(text), chunk_size):
                yield text[i:i + chunk_size]
            return

        collected: List[str] = []
        for piece in self._base.stream(messages, stop_event, *args, **kwargs):
            collected.append(piece)
            yield piece
        full = "".join(collected)
        self._store.put(ReplayRecord(
            request_hash=h,
            messages=_messages_to_canonical(messages),
            response=full,
            metadata={**extra, "streamed": True},
        ))


def _sanitize_extra_value(v: Any) -> Any:
    """把 kwargs 值转成 JSON 可序列化形态；不认识的直接 repr。"""
    if isinstance(v, (str, int, float, bool)) or v is None:
        return v
    if isinstance(v, (list, tuple)):
        return [_sanitize_extra_value(x) for x in v]
    if isinstance(v, dict):
        return {str(k): _sanitize_extra_value(val) for k, val in v.items()}
    return repr(v)


# pytest plugin hooks（保留与原 ``tests/support/llm_replay.py`` 完全兼容）
def pytest_addoption(parser):  # pragma: no cover - plugin hook
    parser.addoption(
        "--llm-replay-mode",
        default=None,
        help="Override KROW_LLM_REPLAY_MODE (record|replay|auto)",
    )


def pytest_configure(config):  # pragma: no cover
    mode = config.getoption("--llm-replay-mode")
    if mode:
        os.environ["KROW_LLM_REPLAY_MODE"] = mode


class _ProviderMethodSwap:
    """在 fixture / Agent 生命周期内替换 provider.generate/stream，退出时还原。

    同时 hook ``LLMProviderManager.get_chat_model`` / ``get_reasoning_model`` 的
    返回值：``AgentV3`` 走的路径是 ``LLMProviderManager.get_chat_model()``（会
    动态 new 出 ``KrowLLMProviderAdapter`` 等），直接 wrap 底层
    ``AIProviderManager._providers`` 无法覆盖这条路径。

    P1b（2026-05-13）：从 ``tests/support/real_llm_fixture.py`` 物理迁出到 SDK，
    让 SDK 用户也能用同款 wrap 机制。
    """

    def __init__(self, mgr: Any, store: "LLMReplayStore"):
        self._mgr = mgr
        self._store = store
        self._originals: List = []  # [(obj, attr_name, orig_fn), ...]
        self._llm_mgr_originals: List = []

    def install(self) -> None:
        if self._mgr is not None:
            providers = getattr(self._mgr, "_providers", {}) or {}
            for name, prov in providers.items():
                if prov is None:
                    continue
                wrapper = RecordReplayWrapper(
                    prov, self._store, extra_key={"provider": str(name)},
                )
                for method_name in ("generate", "stream"):
                    if hasattr(prov, method_name):
                        orig = getattr(prov, method_name)
                        self._originals.append((prov, method_name, orig))
                        setattr(prov, method_name, getattr(wrapper, method_name))

        try:
            from modules.ai.providers import get_llm_provider_manager
            llm_mgr = get_llm_provider_manager()
        except Exception:
            llm_mgr = None
        if llm_mgr is not None:
            store = self._store

            def _wrap_method(orig_fn, method_name):
                def _wrapped(provider_name=None):
                    adapter = orig_fn(provider_name)
                    if adapter is None:
                        return None
                    return RecordReplayWrapper(
                        adapter, store,
                        extra_key={
                            "llm_mgr_method": method_name,
                            "provider": str(provider_name or "<default>"),
                        },
                    )
                return _wrapped

            for mname in ("get_chat_model", "get_reasoning_model"):
                orig = getattr(llm_mgr, mname, None)
                if orig is None:
                    continue
                self._llm_mgr_originals.append((llm_mgr, mname, orig))
                setattr(llm_mgr, mname, _wrap_method(orig, mname))

    def uninstall(self) -> None:
        for obj, name, orig in self._originals:
            try:
                setattr(obj, name, orig)
            except Exception:
                pass
        self._originals.clear()
        for obj, name, orig in self._llm_mgr_originals:
            try:
                setattr(obj, name, orig)
            except Exception:
                pass
        self._llm_mgr_originals.clear()


def wrap_provider_manager_with_replay(store: "LLMReplayStore") -> _ProviderMethodSwap:
    """装配 LLM provider 的 record/replay swap，让 ``AgentV3`` 经它经过 store。

    用例（手动管理 lifecycle）：

    .. code-block:: python

        from krow_agent_sdk.replay import LLMReplayStore, wrap_provider_manager_with_replay

        store = LLMReplayStore.from_env("fixtures/my_test.json")
        swap = wrap_provider_manager_with_replay(store)
        try:
            # ... 跑你的测试 ...
            agent.run("...")
        finally:
            swap.uninstall()

    或更推荐：直接 ``AgentBuilder().with_replay_store(store).build()``，
    SDK 会自动在 ``Agent.shutdown()`` 时 uninstall（详 design doc Step 2 P2）。
    """
    try:
        from modules.ai.providers import (
            get_ai_provider_manager,
            get_llm_provider_manager,
            init_llm_provider_manager,
        )
    except ImportError as exc:
        raise LLMReplayError(
            f"wrap_provider_manager_with_replay: 主仓 modules.ai.providers 不可用：{exc}"
        ) from exc
    
    mgr = get_ai_provider_manager()
    if mgr is None:
        try:
            from app.container import _build_ai_manager
            _build_ai_manager()
            mgr = get_ai_provider_manager()
        except Exception:
            pass
    
    if get_llm_provider_manager() is None and mgr is not None:
        try:
            init_llm_provider_manager(mgr)
        except Exception:
            pass
    
    swap = _ProviderMethodSwap(mgr, store)
    swap.install()
    return swap


__all__ = [
    "LLMReplayStore",
    "RecordReplayWrapper",
    "ReplayRecord",
    "LLMReplayError",
    "LLMReplayMiss",
    "compute_request_hash",
    "Mode",
    "MissPolicy",
    # Step 2 P2 (2026-05-13)：替换 provider 方法以接入 record/replay
    "wrap_provider_manager_with_replay",
]
