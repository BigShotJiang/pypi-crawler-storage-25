"""Plugin lifecycle hook + SDKContext（design doc §6.0.4 + D5）。

所有 9 个 Protocol（P1-P9）共享一个**可选** mixin（不是新 Protocol），
plugin 实现 ``on_load`` / ``on_unload`` 控制资源 lifecycle。
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:
    from .events import EventBusReader


@dataclass
class SDKContext:
    """SDK 注入给 plugin 的上下文（lifecycle hook 用）。

    Fields:
        plugin_id: 当前 plugin 的全局 ID
        project_root: 项目根目录（force_explicit 后必有值）
        logger: 已绑定 plugin_id 的 logger
        event_bus: 只读 EventBus facade（plugin 可订阅）
        sdk_version: 当前 SDK 版本号字符串
        config: 任意配置 dict（plugin 自己解析）
    """

    plugin_id: str
    project_root: Path
    logger: logging.Logger
    event_bus: "EventBusReader"
    sdk_version: str = "0.1.0"
    config: dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class BasePluginLifecycle(Protocol):
    """Plugin 可选 lifecycle mixin（**不是必须实现**）。

    SDK 加载链：
    1. ``validate_protocol_implementation(plugin, protocol)``
    2. 若 plugin 实现 on_load → 调用 ``plugin.on_load(sdk_context)``
    3. 真实注册到 ToolManager / ACTLoader / GateChain / EventBus
    4. shutdown 时若 plugin 实现 on_unload → 反向调用

    plugin 不实现也不破契约（hasattr check）。
    """

    def on_load(self, sdk_context: SDKContext) -> None:
        """SDK build() 时调用一次；plugin 在此初始化资源（不能塞 __init__）。"""
        ...

    def on_unload(self) -> None:
        """SDK shutdown() 时调用一次；plugin 在此释放资源（关连接 / 释放句柄）。"""
        ...


def call_on_load_if_implemented(plugin: Any, sdk_context: SDKContext) -> None:
    """如果 plugin 实现了 on_load，调它；否则 silent skip。"""
    on_load = getattr(plugin, "on_load", None)
    if callable(on_load):
        on_load(sdk_context)


def call_on_unload_if_implemented(plugin: Any) -> None:
    """如果 plugin 实现了 on_unload，调它；否则 silent skip。"""
    on_unload = getattr(plugin, "on_unload", None)
    if callable(on_unload):
        on_unload()
