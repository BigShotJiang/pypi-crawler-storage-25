"""EventBusReader 只读 facade（design doc §6.1 + 顶级 review A10 + Step 1 PR S1.21）。

防 Hyrum's Law（"任何可观察行为都会被某 user 依赖"）：
- 老接口 ``agent.event_bus.publish(...)`` 会让 plugin 主动发事件污染主流程
- 老接口 ``agent.event_bus._subscribers`` 会让 plugin 依赖内部状态，主仓 refactor 即破

EventBusReader 仅暴露：
- ``subscribe(topic, handler) -> token``
- ``unsubscribe(token)``
- ``iter_recent(topic_pattern, n=100) -> Iterator[Event]``（最近 N 条只读）

不暴露：``publish`` / 内部状态 / 任何可写方法。

**StreamItem**（chore/sdk-run-stream-api-2026-05-15）：
``Agent.run_stream()`` yield 的统一 envelope dataclass。区分
``event`` / ``result`` / ``error`` 三种 yield 类型，让用户在同一 for loop 内
分辨流式事件、最终结果、后台异常，无需多个 callback / 多个 channel。
"""
from __future__ import annotations

import logging
import threading
from collections import deque
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable, Deque, Iterator, Literal, Optional

if TYPE_CHECKING:
    from modules.events.bus import EventBus
    from modules.events.bus_core import Event

logger = logging.getLogger(__name__)


_DEFAULT_RECENT_BUFFER_PER_TOPIC = 100


# ────────────────────────────────────────────────────────────────────────
# StreamItem: Agent.run_stream() yield envelope
# ────────────────────────────────────────────────────────────────────────


StreamItemKind = Literal["event", "result", "error"]


@dataclass(frozen=True)
class StreamItem:
    """``Agent.run_stream()`` yield 的统一 envelope（chore/sdk-run-stream-api-2026-05-15）.

    用户在同一个 for loop 内分辨三种类型：

    - ``kind="event"``：流式事件，``event`` 字段为 ``modules.events.bus_core.Event``
      dataclass（``type`` / ``payload`` / ``trace_id`` / ``timestamp``）
    - ``kind="result"``：最终任务结果，``result`` 字段为 ``AgentV3Result`` dataclass
      （含 ``success`` / ``solution`` / ``execution_result`` / ``final_output``）；
      在 ``agent.task_complete`` 后、stream 结束前 yield 1 次（不会 yield 多次）
    - ``kind="error"``：后台线程抛异常，``error`` 字段为 ``BaseException``；
      yield 后 stream 结束（用户可 ``raise item.error`` 或 log 处理）

    设计原则（design doc §6.1 + scope 评审）：

    1. **不污染 EventBus 类型**：``event`` 字段直接拿 EventBus 的 ``Event``
       dataclass，不重新定义；用户可继续用 ``agent.event_bus.subscribe`` 兜底
    2. **不丢失 ``Agent.run`` 返回值**：``result`` 字段封装 ``AgentV3Result``
       完整 dataclass，与同步路径 ``agent.run() -> AgentV3Result`` 对齐
    3. **error 透传**：后台线程异常不会"吞"，调用方能拿到完整 exception 链
    4. **for loop 自然结束**：stream 结束 = generator return（无 sentinel
       侵入用户代码）

    使用示例：

    .. code-block:: python

        for item in agent.run_stream("写一份报告"):
            if item.kind == "event":
                print(f"[{item.event.type}] {item.event.payload.get('summary', '')}")
            elif item.kind == "result":
                final = item.result
                print(f"Done: {final.final_output[:200]}")
            elif item.kind == "error":
                raise item.error
    """

    kind: StreamItemKind
    event: Any | None = None    # kind="event" 时 = bus_core.Event 实例
    result: Any | None = None   # kind="result" 时 = AgentV3Result 实例
    error: BaseException | None = None  # kind="error" 时 = 后台线程异常

    def __post_init__(self) -> None:
        # 轻量 fail-loud：kind 与字段配对必须一致（防止 SDK 内部组装 bug）
        if self.kind == "event" and self.event is None:
            raise ValueError("StreamItem(kind='event') 必须带 event 字段")
        if self.kind == "result" and self.result is None:
            raise ValueError("StreamItem(kind='result') 必须带 result 字段")
        if self.kind == "error" and self.error is None:
            raise ValueError("StreamItem(kind='error') 必须带 error 字段")


class EventBusReader:
    """SDK 暴露给 plugin / UI 的 EventBus 只读视图。

    设计目的：
    - 隔离 ``modules/events/bus.py:EventBus`` 内部实现（防 Hyrum's Law）
    - 主仓未来 refactor EventBus 内部不影响外部
    - plugin 只能"读 + 订阅"，不能"写 + 发事件"（保 EventBus 是内核单向 pub-sub）

    plugin 想发布事件 → 走 P5 EventListenerPlugin 的 listener 内部副作用，
    或走 P6 ObservabilityPlugin 自己的 sink，**不**通过 SDK 反向 publish。
    """

    def __init__(self, bus: "EventBus") -> None:
        self._bus = bus
        # 简易最近事件 ring buffer，按 topic 维度存储，便于 ``iter_recent``。
        # 仅记录 SDK 自己 subscribe 的事件，不动 bus 内部状态。
        self._recent_lock = threading.RLock()
        self._recent_by_topic: dict[str, Deque[Any]] = {}
        self._tracked_topics: set[str] = set()

    # ──────────────────────────────────────────────────────────────────
    # 订阅 / 取消订阅
    # ──────────────────────────────────────────────────────────────────

    def subscribe(
        self,
        topic: str,
        handler: Callable[[Any], None],
        *,
        track_recent: bool = False,
    ) -> str:
        """订阅一个稳定 topic（详 design doc §5.5 表）。

        Args:
            topic: EventBus topic 名（如 ``agent.task_complete``）
            handler: 接收 ``Event`` dataclass（单参数）
            track_recent: 是否把命中的事件存入本 reader 的 recent ring buffer，
                供 ``iter_recent`` 读取（默认 False，避免无关订阅占内存）

        Returns:
            EventBus 内部 token 字符串，用于 ``unsubscribe``
        """
        wrapped = handler
        if track_recent:
            self._tracked_topics.add(topic)

            def _wrapped(event: Any) -> None:
                self._record_recent(topic, event)
                handler(event)

            wrapped = _wrapped

        return self._bus.subscribe(topic, wrapped)

    def unsubscribe(self, token: str) -> None:
        """注销订阅。"""
        if hasattr(self._bus, "unsubscribe"):
            self._bus.unsubscribe(token)
        else:
            logger.debug("EventBus has no unsubscribe(token=%s)", token)

    # ──────────────────────────────────────────────────────────────────
    # 只读快照
    # ──────────────────────────────────────────────────────────────────

    def iter_recent(self, topic_pattern: str, n: int = 100) -> Iterator[Any]:
        """读最近 N 条事件（用于 UI debug / 慢启动 backfill）。

        只读快照——不影响 EventBus 状态。

        Args:
            topic_pattern: 精确 topic 名；通配符暂不支持（v0.8 起步）
            n: 最多返回 N 条

        Yields:
            ``Event`` dataclass 实例
        """
        with self._recent_lock:
            buf = self._recent_by_topic.get(topic_pattern)
            if not buf:
                return iter([])
            snapshot = list(buf)[-n:]
        return iter(snapshot)

    # ──────────────────────────────────────────────────────────────────
    # 内部
    # ──────────────────────────────────────────────────────────────────

    def _record_recent(self, topic: str, event: Any) -> None:
        with self._recent_lock:
            buf = self._recent_by_topic.get(topic)
            if buf is None:
                buf = deque(maxlen=_DEFAULT_RECENT_BUFFER_PER_TOPIC)
                self._recent_by_topic[topic] = buf
            buf.append(event)


__all__ = ["EventBusReader", "StreamItem", "StreamItemKind"]
