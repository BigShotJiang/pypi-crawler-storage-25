"""``krow_test_sdk`` —— SDK 测试基础设施 public export（Wave 4 / S1.13）。

> 设计文档锚点：``docs/sdk/plugin-architecture-design.md`` §6.7 +
> §9.1 PR S1.13 "Wave 4 — krow_test_sdk public export"。

## 职责

让外部 SDK 开发者拿到与 krow 主仓一致的测试基础设施，**避免重新造轮子**：

- ``LLMReplayStore`` / ``LLMReplayMiss`` —— LLM 录制/回放
- ``HeadlessAgentHarness`` —— 一键起 headless agent 跑测试，无 UI 依赖
- ``AgentRunResult`` —— Agent 运行结果 dataclass
- ``detect_live_llm_available`` —— 检测真实 LLM 凭证是否可用
- ``ensure_ai_manager_initialized`` —— 确保 AIProviderManager 初始化
- ``wrap_ai_provider_manager_with_replay`` —— 把 LLMReplayStore wrap 到全局 manager

## 设计约束

- **subset of tests/support/**：只暴露与"用户测自己 plugin"相关的 API；
  e2e_framework 内的 WorkbenchHarness / AgentProbe 由于依赖 PySide6，**不**暴露在 SDK
- **零侵入**：所有 API 都是 wrap 现有 ``tests/support/*`` 模块
- **only OK for testing**：`krow_test_sdk` 仅用于开发者写自己 plugin 的测试

## 示例

```python
import pytest
from krow_test_sdk import (
    LLMReplayStore,
    HeadlessAgentHarness,
    detect_live_llm_available,
)

@pytest.fixture()
def my_plugin_harness(tmp_path):
    h = HeadlessAgentHarness(api_key="sk-user-...", project_root=tmp_path)
    h.with_my_plugin(...)
    h.build()
    return h

def test_my_plugin(my_plugin_harness):
    if not detect_live_llm_available():
        pytest.skip("需真实 LLM 凭证")
    result = my_plugin_harness.run("你的指令...")
    assert result.success
```
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Optional

# SSOT：直接走 SDK 内部 path，不走 ``tests.support.llm_replay`` shim。
# R2 根因（2026-05-13）：shim → ``modules.agent.sdk.replay`` →
# ``modules.agent.sdk.__init__`` (which imports test_sdk) → ``test_sdk`` →
# 走回 shim 此时 partial init → ``ImportError: cannot import LLMReplayMiss``。
# 修法：``test_sdk.py`` 是 SDK 内部模块，应直接用 SDK 内部 path。
from modules.agent.sdk.replay import LLMReplayMiss, LLMReplayStore
from tests.support.real_llm_fixture import (
    detect_live_llm_available,
    ensure_ai_manager_initialized,
    wrap_ai_provider_manager_with_replay,
)

if TYPE_CHECKING:
    from .builder import Agent, AgentBuilder

logger = logging.getLogger(__name__)


# ────────────────────────────────────────────────────────────────────────
# AgentRunResult dataclass
# ────────────────────────────────────────────────────────────────────────


@dataclass
class AgentRunResult:
    """开发者面向的 Agent run 结果（与主仓 ``AgentV3Result`` 等价的开放视图）。"""

    success: bool
    final_output: str
    error: Optional[str] = None
    raw_step_outputs: Optional[list[Any]] = None
    duration_s: Optional[float] = None
    llm_call_count: Optional[int] = None


def _result_to_dataclass(raw: Any) -> AgentRunResult:
    if raw is None:
        return AgentRunResult(success=False, final_output="", error="agent.run returned None")
    return AgentRunResult(
        success=bool(getattr(raw, "success", False)),
        final_output=str(getattr(raw, "final_output", "") or ""),
        error=getattr(raw, "error", None),
        raw_step_outputs=list(getattr(raw, "raw_step_outputs", []) or []),
        duration_s=getattr(raw, "duration_s", None),
        llm_call_count=getattr(raw, "llm_call_count", None),
    )


# ────────────────────────────────────────────────────────────────────────
# HeadlessAgentHarness
# ────────────────────────────────────────────────────────────────────────


class HeadlessAgentHarness:
    """一键起 headless agent 跑 plugin 测试的 harness（**不依赖 PySide6 / GUI**）。

    内部包装 ``AgentBuilder``，提供链式 ``with_*`` + ``build`` + ``run`` + ``shutdown``。
    Plugin 测试场景下推荐用法（与 production AgentBuilder 等价但收敛接口）。
    """

    def __init__(
        self,
        *,
        api_key: str,
        project_root: Path,
        ai_manager: Optional[Any] = None,
    ) -> None:
        from .builder import AgentBuilder
        self._builder: AgentBuilder = (
            AgentBuilder()
            .with_krow_api_key(api_key)
            .with_project_root(project_root)
        )
        if ai_manager is not None:
            self._builder.with_ai_manager(ai_manager)
        self._agent: Optional["Agent"] = None
        self._project_root = project_root

    def with_act_plugin(self, plugin: Any) -> "HeadlessAgentHarness":
        self._builder.with_act_plugin(plugin)
        return self

    def with_tool_plugin(self, plugin: Any) -> "HeadlessAgentHarness":
        self._builder.with_tool_plugin(plugin)
        return self

    def with_gate_plugin(self, plugin: Any) -> "HeadlessAgentHarness":
        self._builder.with_gate_plugin(plugin)
        return self

    def with_hint_plugin(self, plugin: Any) -> "HeadlessAgentHarness":
        self._builder.with_hint_plugin(plugin)
        return self

    def with_event_listener_plugin(self, plugin: Any) -> "HeadlessAgentHarness":
        self._builder.with_event_listener_plugin(plugin)
        return self

    def with_observability_plugin(self, plugin: Any) -> "HeadlessAgentHarness":
        self._builder.with_observability_plugin(plugin)
        return self

    def with_domain_pack_plugin(self, plugin: Any) -> "HeadlessAgentHarness":
        self._builder.with_domain_pack_plugin(plugin)
        return self

    def with_mcp_server_plugin(self, plugin: Any) -> "HeadlessAgentHarness":
        self._builder.with_mcp_server_plugin(plugin)
        return self

    def with_security_plugin(self, plugin: Any) -> "HeadlessAgentHarness":
        self._builder.with_security_plugin(plugin)
        return self

    def build(self, *, validate_connection: bool = False) -> "HeadlessAgentHarness":
        self._agent = self._builder.build(validate_connection=validate_connection)
        return self

    @property
    def agent(self) -> "Agent":
        if self._agent is None:
            raise RuntimeError("Call build() first")
        return self._agent

    def run(
        self,
        user_input: str,
        *,
        session_id: str = "test-session",
        project_id: Optional[str] = None,
        on_progress: Optional[Callable[[str, dict], None]] = None,
    ) -> AgentRunResult:
        if self._agent is None:
            raise RuntimeError("Call build() first")
        raw = self._agent.run(
            user_input=user_input,
            session_id=session_id,
            project_id=project_id,
        )
        return _result_to_dataclass(raw)

    def shutdown(self) -> None:
        if self._agent is not None:
            self._agent.shutdown()
            self._agent = None

    def __enter__(self) -> "HeadlessAgentHarness":
        if self._agent is None:
            self.build()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.shutdown()


__all__ = [
    "AgentRunResult",
    "HeadlessAgentHarness",
    "LLMReplayStore",
    "LLMReplayMiss",
    "detect_live_llm_available",
    "ensure_ai_manager_initialized",
    "wrap_ai_provider_manager_with_replay",
]
