"""experimental SDK namespace（design doc §5.0.1）。

experimental Protocol 维护承诺：**2 年 SemVer 弱约束**——minor 内可 breaking +
deprecation 1 个 minor 周期；feature flag default off。

> **谨慎使用**：experimental Protocol 未来可能调整接口，不在 `krow_agent_sdk.protocols` 主 namespace 暴露。
"""
from __future__ import annotations

from . import protocols

__all__ = ["protocols"]
