"""P9 DomainPackPlugin（experimental，design doc §5.9 + 第 8 轮辩论扩展为 8 元素）。

System 1 + System 2 混合——pack 内含 hint（System 2）+ tool/gate（System 1）等聚合。
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable, Protocol, runtime_checkable

if TYPE_CHECKING:
    from modules.knowledge.conclude_guard_gates import Gate

    from ..protocols.tool import ToolSpec


@runtime_checkable
class DomainPackPlugin(Protocol):
    """领域包"语法糖" Protocol——一次性聚合多种 plugin 元素（design doc §5.9）。

    SDK 内部把 DomainPack 展开为 P3 HintPlugin + P2 ToolPlugin + P4 GatePlugin +
    supplementary extended.md + visual_adapters + mcp_servers + event_listeners +
    recommended_budget 等 8 元素并真实加载。

    所有方法都是 OPTIONAL（plugin 不实现某项时跳过该元素加载）。
    """

    @property
    def plugin_id(self) -> str:
        """全局唯一 ID。"""
        ...

    @property
    def domain_name(self) -> str:
        """领域名（如 ``industrial_design`` / ``research``），用于显示和路由提示。"""
        ...

    def get_hints(self) -> list[Callable[[dict], str | None]]:
        """OPTIONAL：返回 hint 函数列表（each: ``(context: dict) -> str | None``）。"""
        ...

    def get_tools(self) -> list["ToolSpec"]:
        """OPTIONAL：返回工具 spec 列表（与 P2 ToolPlugin.get_tools 同形）。"""
        ...

    def get_gates(self) -> list[tuple[str, "Gate"]]:
        """OPTIONAL：返回 gate 列表，每项 ``(phase, gate)``（phase 是 macro/micro）。"""
        ...

    def get_extended_md_supplement(self, target_act: str) -> str | None:
        """OPTIONAL：给指定 native ACT 追加 supplementary extended.md 文本（v0.8 A9：上限 4KB / target / 16KB total）。"""
        ...

    def get_visual_adapters(self) -> list[tuple[str, Any]]:
        """OPTIONAL：返回视觉适配器列表，每项 ``(file_ext, adapter)``。"""
        ...

    def get_mcp_servers(self) -> list[dict]:
        """OPTIONAL：返回 MCP server 配置列表（同 P7 MCPServerPlugin.get_servers）。"""
        ...

    def get_event_listeners(self) -> list[tuple[str, Callable[[Any], None]]]:
        """OPTIONAL：返回事件订阅列表（同 P5 EventListenerPlugin.get_subscriptions；listener 严格只读）。"""
        ...

    def get_recommended_budget(self) -> dict | None:
        """OPTIONAL：返回推荐 BudgetSpec dict（SDK 在没有显式 ``with_budget`` 时使用）。"""
        ...
