"""P10 VisualAdapterPlugin（experimental, design doc §5.10 + Step 2 P2 落地）.

让外部团队（CAD / 工业图纸 / 科研报告 等场景）注册自己的 ``VisualAdapter``
直接接入 Agent 的 ``visual_inspect`` 工具链，**不必**通过 ``DomainPackPlugin``
间接注册.

## 现状（M4 完成时）

- ``VisualAdapter`` ABC 定义在 ``modules/agent/visual/protocol.py:200``，6 个
  抽象方法（``open`` / ``close`` / ``render`` / ``inventory`` / ``page_count``
  + ``scene_config`` property）.
- 内置场景 adapter：``.pptx`` （桌面 ``PPTXVisualAdapter`` /
  headless ``HeadlessPPTXVisualAdapter``，按 ``KROW_HEADLESS`` 动态选）+
  ``.png/.jpg`` 等图片格式（``ImageVisualAdapter``）已注册.
  详 ``modules/agent/visual/__init__.py:_register_builtin_adapters``.
- ``DomainPackPlugin.get_visual_adapters()`` 已能间接注册 ``(file_ext, adapter)``
  pair，``Agent.visual_adapters`` property 暴露汇总列表.

## 本协议（Step 2 P2）新增

让外部团队**单独**注册 visual adapter（不必组装 DomainPack）：

```python
from krow_agent_sdk.experimental.protocols import VisualAdapterPlugin
from krow_agent_sdk.visual import VisualAdapter, ElementEntry, SceneConfig

class CADVisualAdapter(VisualAdapter):
    def open(self, source, **kwargs): ...
    def close(self): ...
    def render(self, page_index, width=960, height=540): ...
    def inventory(self, page_index): ...
    def page_count(self): ...

class CADPlugin:
    plugin_id = "cad-vis-2026"
    def get_visual_adapters(self):
        return [(".dwg", CADVisualAdapter), (".step", CADVisualAdapter)]

agent = (
    AgentBuilder()
    .with_krow_api_key("sk-user-...")
    .with_visual_adapter_plugin(CADPlugin())
    .build()
)
# 此后 visual_inspect 工具可处理 .dwg / .step 文件
```

## 与 DomainPackPlugin 的关系

- ``DomainPackPlugin.get_visual_adapters()`` 仍可用（不破坏向后兼容）.
- ``VisualAdapterPlugin`` 是**专用**协议——只暴露 visual adapter 一项能力.
  适合外部团队只想加视觉适配，不需要 hint/tool/gate 时.
- 两者注入路径汇合到 ``Agent.visual_adapters`` property（同一来源）.

## Feature flag

experimental Wave 3 协议默认 off：``KROW_PLUGIN_P10_VISUAL_ADAPTER=1`` 才启用
``with_visual_adapter_plugins_from_entry_points()``.直接 ``with_visual_adapter_plugin(plugin)`` 不受 feature flag 限制.

design doc §5.10 + AGENTS.md §13.9 Step 2 P2.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:
    pass


@runtime_checkable
class VisualAdapterPlugin(Protocol):
    """P10：注册 VisualAdapter 的专用 plugin 协议.

    最小可行 plugin 只需实现 ``plugin_id`` + ``get_visual_adapters()``.
    """

    @property
    def plugin_id(self) -> str:
        """全局唯一 plugin ID（用于 deduplicate / 审计 / observability）."""
        ...

    def get_visual_adapters(self) -> list[tuple[str, Any]]:
        """返回视觉适配器列表，每项 ``(file_ext, adapter_class_or_instance)``.

        - ``file_ext``: 文件扩展名，如 ``".dwg"`` / ``".step"`` / ``".pptx"``,
          以 ``.`` 开头，小写
        - ``adapter_class_or_instance``: ``VisualAdapter`` 子类（推荐传 class，
          延迟实例化）或者已实例化的 adapter（不推荐——会被多个文件共享，
          ``open()/close()`` 状态可能撞）

        Krow 会在 ``visual_inspect`` 工具被调用时按文件扩展名 lookup 对应 adapter.
        若多个 plugin 注册了同 ext，**后注册者覆盖**前者（给外部 plugin
        替换内置 adapter 的能力）.

        返回空 list = 该 plugin 暂时不提供 adapter（合法）.
        """
        ...
