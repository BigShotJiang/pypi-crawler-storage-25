"""P8 SecurityPlugin（experimental MVP 降级版，design doc §5.8）。

System 1 标签——security policy 是声明式 deny/allow rule。
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class SecurityPlugin(Protocol):
    """外部 plugin 加声明式安全策略（MVP 降级版）。

    Wave 1 仅声明骨架——真实加载推 Step 2；强沙箱（subprocess / VM）推 Step 3。
    """

    @property
    def plugin_id(self) -> str:
        """全局唯一 ID。"""
        ...

    def get_policies(self) -> list[dict]:
        """返回安全策略列表。

        每项最小字段：
        ``{"target_tool": "<tool_name>", "rules": ["deny:write_outside_project_root", ...]}``
        """
        ...
