"""experimental Protocol（P7/P8/P9/P10，design doc §5.7-5.10）.

**警告**：experimental 维护承诺为 2 年 SemVer 弱约束（minor 内可 breaking）；
默认 feature flag off：

- ``KROW_PLUGIN_P7_MCP_SERVER=0``
- ``KROW_PLUGIN_P8_SECURITY=0``
- ``KROW_PLUGIN_P9_DOMAIN_PACK=0``
- ``KROW_PLUGIN_P10_VISUAL_ADAPTER=0``

import 路径：

- ``from krow_agent_sdk.experimental.protocols import P9DomainPackPlugin``
- ``from krow_agent_sdk.experimental.protocols import VisualAdapterPlugin``
"""
from __future__ import annotations

from .domain_pack import DomainPackPlugin
from .mcp_server import MCPServerPlugin
from .security import SecurityPlugin
from .visual_adapter import VisualAdapterPlugin

__all__ = [
    "MCPServerPlugin",
    "SecurityPlugin",
    "DomainPackPlugin",
    "VisualAdapterPlugin",
]
