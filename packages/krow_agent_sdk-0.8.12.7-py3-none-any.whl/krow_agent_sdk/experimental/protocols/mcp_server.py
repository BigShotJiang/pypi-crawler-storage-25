"""P7 MCPServerPlugin（experimental，design doc §5.7）.

System 1 标签——MCP server 注册是确定性配置。

## 协议形态（3 选 1+，可同时实现）

### 形态 A：远程 MCP endpoint 配置（仅 metadata，不连接）

通过 ``get_servers() -> list[dict]`` 返回 ``[{"name", "url", "auth", "transport"}]``。
SDK 仅 collect 到 ``Agent.mcp_servers`` facade 暴露，plugin 自负责真实连接。
**不会**自动注册工具到 ``ToolManager``。

适用场景：plugin 仅声明"我用了哪些远程 MCP"，但工具调用走 plugin 自己的层。

### 形态 B：in-process MCP server 实例（P1a 加，2026-05-13）

通过 ``get_in_process_servers() -> list[tuple[str, Any]]`` 返回
``[(server_name, server_instance), ...]``。SDK ``build()`` 在
``KROW_ENABLE_MCP_SERVER_PLUGIN=1`` 时自动注册到主仓 ``ToolManager``，
plugin 提供的工具直接被 Agent 可用（无需写 ToolPlugin 单工具适配）。

要求 ``server_instance`` 有 ``list_tools() -> list[dict]`` 与 ``call_tool(name, args)``
方法（与 ``ToolManager.register_internal_server`` 内部 MCP server 协议一致；详
``modules/agent/mcp_registry.py`` SSOT）。

适用场景：plugin 内嵌一个 MCP server 实例，跑在 Agent 进程内。

### 形态 C：远程 MCP client（自动注册到 ToolManager，Step 2 P1 加，2026-05-13）

形态 C 是形态 B 的**远程语义变体**。Plugin 在 ``get_in_process_servers()`` 返回的
"server instance" 可以是已连接好的**远程 MCP client**（实际 RPC 走 HTTP / SSE /
stdio / WebSocket / gRPC 等），只要满足以下鸭型接口：

- ``list_tools() -> list[dict]``：（必须）返回工具元数据列表
- ``call_tool(name: str, args: dict) -> Any``：（必须）远程调用工具
- ``close() -> None`` 或 ``aclose()``：（可选）SDK ``Agent.shutdown()`` 时自动
  调用，让远程 client 优雅断开 socket / 释放连接池

SDK 不区分 B/C —— 你交什么实例 SDK 就调什么。这是 OCP 设计：你可以用 ``mcp``
官方 SDK / 自家 protocol / 任意 transport。SDK 不锁死任一实现。

适用场景：plugin 接入第三方 MCP server（如外部公司的工具 API、SaaS MCP 服务）。

例：

.. code-block:: python

    class MyMCPRemotePlugin:
        plugin_id = "myorg.remote_mcp"
        
        def __init__(self, mcp_url, api_key):
            from mcp.client import Client  # 例：MCP 官方 python SDK
            self._client = Client(mcp_url, auth=api_key)
            self._client.connect()
        
        def get_servers(self):
            return [{"name": "remote_x", "url": self._mcp_url, "auth": "..."}]
        
        def get_in_process_servers(self):
            # 形态 C：远程 client 当 in-process server 注入
            return [("remote_x", self._client)]

## 默认行为

三个方法都是可选的（``hasattr`` 检查）；旧 plugin 只实现 ``get_servers()`` 不影响
向后兼容（OCP）。

## 反模式

- ❌ 用 ``ToolPlugin`` 一个个 register 工具，但其实 plugin 内部已有 MCP server
  → 直接用 ``MCPServerPlugin`` 形态 B/C 一次性注入更简洁
- ❌ ``server_instance`` 没实现 ``list_tools()`` → register 时 fail-loud（形态 B/C）
- ❌ 远程 client 在 plugin ``__init__`` 没真连，``list_tools()`` 时才 lazy 连 →
  SDK ``build()`` 期 fail；推荐 ``__init__`` 同步连，或在 ``on_load(ctx)`` lifecycle 连
- ❌ 远程 client 没实现 ``close()`` → SDK 不 raise，但 plugin 应自己在
  ``on_unload(ctx)`` 里 cleanup；不然进程退出时 socket 泄漏
"""
from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class MCPServerPlugin(Protocol):
    """外部 plugin 注册 MCP server endpoint。

    SDK build() 时遍历 ``get_servers()`` 并暴露到 ``Agent.mcp_servers``；
    若 plugin 还实现 ``get_in_process_servers()`` 且 feature flag 打开，
    则真注册到 ``ToolManager`` —— 该方法返的实例可以是 in-process（形态 B）
    或远程 client（形态 C），SDK 不区分。
    """

    @property
    def plugin_id(self) -> str:
        """全局唯一 ID。"""
        ...

    def get_servers(self) -> list[dict]:
        """返回远程 MCP server 配置列表（形态 A）。

        每项最小字段：``{"name", "url", "auth", "transport"}``。
        """
        ...

    # 形态 B/C（可选）：plugin 直接提供 in-process server 实例 / 远程 client。
    # 用 ``hasattr(plugin, "get_in_process_servers")`` 做 duck-typing 检查；
    # 不强制实现 — Protocol runtime_checkable 不要求所有方法都存在。
    # def get_in_process_servers(self) -> list[tuple[str, Any]]:
    #     """返回 [(server_name, server_instance)] 列表。
    #
    #     server_instance 必须有 ``list_tools()`` 方法（详
    #     ``modules.tools.manager.ToolManager.register_internal_server``）。
    #     可选 ``close()`` / ``aclose()``：SDK shutdown 时自动调用。
    #     """
    #     ...
