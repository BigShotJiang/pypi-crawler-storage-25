"""``krow_agent_sdk.diagnostics`` —— 只读 introspection facade（Wave 4 / S1.12）。

> 设计文档锚点：``docs/sdk/plugin-architecture-design.md`` §5.7 + §6.6 +
> §9.1 PR S1.12 "Wave 4 — diagnostics facade 暴露给 SDK 开发者"。

## 职责

让 SDK 开发者 **只读** 地审视 Agent 内部状态，便于：

- **debug**：plugin 没生效？工具有没有真实注册？hint 进了 prompt 吗？
- **observability**：自己挂监控时拿到 metric/audit 流
- **状态快照**：把 agent 当前状态序列化便于 reproduce / share

## 设计约束

- **read-only**：所有 API 返回 dict / tuple / dataclass；**禁止**让外部修改 SDK 内部状态
- **不暴露主仓内部对象**：返回的全是 plain Python（dict / list / 基础类型）
- **不抛异常**：发生异常 → 返回 ``{"error": "..."}``，符合 SDK"友好错误信号"原则
- **零 LLM 调用**：所有方法是 deterministic 系统侧查询（System 1）

## 暴露的 API

- ``dump_state(agent)`` — 输出 agent 状态全景 dict（System 1 / System 2 / plugin / budget / tool / hint / event / observability）
- ``get_plugin_snapshot(agent)`` — 输出已加载 plugin 的清单 + per-protocol 分类
- ``get_tool_snapshot()`` — 输出 ToolManager 当前注册的所有工具（仅 metadata，不返 handler）
- ``get_hint_snapshot()`` — 输出 HintRegistry 已注册 hint plugin 列表
- ``get_observability_snapshot()`` — 输出 SinkRegistry 已注册 sink 列表
- ``get_event_subscription_snapshot()`` — 输出 EventBus 当前 topic→subscriber 映射的概要

## 示例

```python
from krow_agent_sdk import AgentBuilder
from krow_agent_sdk.diagnostics import dump_state

agent = AgentBuilder().with_krow_api_key(...).with_project_root(...).build()
state = dump_state(agent)
print(json.dumps(state, indent=2, ensure_ascii=False))
```
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from .builder import Agent

logger = logging.getLogger(__name__)


def dump_state(agent: Optional["Agent"] = None) -> dict[str, Any]:
    """输出 agent 状态全景 dict。

    Args:
        agent: 已 ``build()`` 的 SDK Agent；None 则只返回全局 SDK registry 快照

    Returns:
        全景 dict，含：
        - ``sdk_version``: SDK 版本
        - ``plugin``: ``get_plugin_snapshot(agent)``
        - ``tool``: ``get_tool_snapshot()``
        - ``hint``: ``get_hint_snapshot()``
        - ``event``: ``get_event_subscription_snapshot()``
        - ``observability``: ``get_observability_snapshot()``
        - ``mcp_servers`` / ``security_policies`` / ``visual_adapters`` / ``recommended_budget``
          （Wave 3 experimental，agent 非 None 时）
    """
    state: dict[str, Any] = {}
    try:
        from . import __version__
        state["sdk_version"] = __version__
    except Exception as exc:  # noqa: BLE001
        state["sdk_version"] = f"<unknown: {exc}>"

    state["plugin"] = get_plugin_snapshot(agent)
    state["tool"] = get_tool_snapshot()
    state["hint"] = get_hint_snapshot()
    state["event"] = get_event_subscription_snapshot()
    state["observability"] = get_observability_snapshot()

    if agent is not None:
        try:
            state["mcp_servers"] = list(agent.mcp_servers)
            state["security_policies"] = list(agent.security_policies)
            state["visual_adapters"] = [
                {"file_ext": fx, "adapter_type": type(ad).__name__}
                for fx, ad in agent.visual_adapters
            ]
            state["recommended_budget"] = agent.recommended_budget
        except Exception as exc:  # noqa: BLE001
            state["experimental_error"] = str(exc)

    return state


def get_plugin_snapshot(agent: Optional["Agent"] = None) -> dict[str, Any]:
    """输出已加载 plugin 的快照。

    Args:
        agent: 可选的 Agent；None 则从全局 _GateRegistry / HintRegistry 等扫描

    Returns:
        ``{"loaded_plugin_ids": [...], "by_protocol": {protocol: [plugin_id, ...]}}``
    """
    snapshot: dict[str, Any] = {
        "loaded_plugin_ids": [],
        "by_protocol": {},
    }
    if agent is not None:
        try:
            snapshot["loaded_plugin_ids"] = list(agent.loaded_plugin_ids)
        except Exception as exc:  # noqa: BLE001
            snapshot["error"] = f"agent.loaded_plugin_ids: {exc}"

    # Hint 维度
    try:
        from .hints import get_hint_registry
        snapshot["by_protocol"]["hint"] = list(get_hint_registry().list_plugin_ids())
    except Exception as exc:  # noqa: BLE001
        snapshot["by_protocol"]["hint_error"] = str(exc)

    # Gate 维度
    try:
        from .builder import _global_gate_registry
        gates = _global_gate_registry().list_gates()
        snapshot["by_protocol"]["gate"] = [
            {"plugin_id": pid, "gate_name": getattr(g, "name", "<unknown>"), "phase": ph}
            for pid, g, ph in gates
        ]
    except Exception as exc:  # noqa: BLE001
        snapshot["by_protocol"]["gate_error"] = str(exc)

    # Observability sink 维度
    try:
        from modules.observability.sink_registry import get_sink_registry
        snapshot["by_protocol"]["observability"] = list(
            get_sink_registry().list_plugin_ids()
        )
    except Exception as exc:  # noqa: BLE001
        snapshot["by_protocol"]["observability_error"] = str(exc)

    return snapshot


def get_tool_snapshot() -> dict[str, Any]:
    """输出 ``ToolManager`` 当前注册的所有工具的 metadata 快照（不含 handler）。

    Returns:
        ``{"count": int, "tools": [{"name": ..., "category": ..., "server_name": ...,
           "complexity": ..., "user_visible": bool, "is_internal": bool}]}``
    """
    try:
        from modules.tools.manager import ToolManager
        manager = ToolManager.get_instance()
        tools = getattr(manager, "tools", {})
        items: list[dict[str, Any]] = []
        for name, td in tools.items():
            items.append(
                {
                    "name": name,
                    "category": getattr(td, "category", None),
                    "server_name": getattr(td, "server_name", None),
                    "complexity": getattr(td, "complexity", None),
                    "user_visible": not bool(getattr(td, "is_internal", False)),
                    "is_internal": bool(getattr(td, "is_internal", False)),
                    "direct_output": bool(getattr(td, "direct_output", False)),
                }
            )
        return {"count": len(items), "tools": items}
    except Exception as exc:  # noqa: BLE001
        return {"error": f"get_tool_snapshot: {exc}"}


def get_hint_snapshot() -> dict[str, Any]:
    """输出 ``HintRegistry`` 已注册 hint plugin 列表。

    Returns:
        ``{"count": int, "plugin_ids": [...]}``
    """
    try:
        from .hints import get_hint_registry
        ids = list(get_hint_registry().list_plugin_ids())
        return {"count": len(ids), "plugin_ids": ids}
    except Exception as exc:  # noqa: BLE001
        return {"error": f"get_hint_snapshot: {exc}"}


def get_observability_snapshot() -> dict[str, Any]:
    """输出 ``SinkRegistry`` 已注册 sink 列表。

    Returns:
        ``{"count": int, "plugin_ids": [...], "sink_kinds": {plugin_id: [...]}}``
    """
    try:
        from modules.observability.sink_registry import get_sink_registry
        registry = get_sink_registry()
        ids = list(registry.list_plugin_ids())
        # SinkRegistry 内部分别管理 metric/trace/audit；这里只暴露汇总
        return {
            "count": len(ids),
            "plugin_ids": ids,
        }
    except Exception as exc:  # noqa: BLE001
        return {"error": f"get_observability_snapshot: {exc}"}


def get_event_subscription_snapshot() -> dict[str, Any]:
    """输出 ``EventBus`` 当前 topic→subscriber 计数概要。

    Returns:
        ``{"topics": {topic: subscriber_count}, "total_subscribers": int}``
    """
    try:
        from modules.events.bus import EventBus
        bus = EventBus.get_instance()
        # EventBus.get_subscribers 是 SSOT 但可能因实现而异；先尝试多种常见 API
        topics_summary: dict[str, int] = {}
        # 优先尝试 _subscriptions / subscriptions / topics 等内部 attr
        subs_attr = (
            getattr(bus, "_subscriptions", None)
            or getattr(bus, "subscriptions", None)
            or getattr(bus, "_subscribers", None)
        )
        if isinstance(subs_attr, dict):
            for topic, value in subs_attr.items():
                if isinstance(value, (list, tuple, set)):
                    topics_summary[str(topic)] = len(value)
                elif isinstance(value, dict):
                    topics_summary[str(topic)] = len(value)
                else:
                    topics_summary[str(topic)] = 1
        return {
            "topics": topics_summary,
            "total_subscribers": sum(topics_summary.values()),
        }
    except Exception as exc:  # noqa: BLE001
        return {"error": f"get_event_subscription_snapshot: {exc}"}


__all__ = [
    "dump_state",
    "get_plugin_snapshot",
    "get_tool_snapshot",
    "get_hint_snapshot",
    "get_observability_snapshot",
    "get_event_subscription_snapshot",
]
