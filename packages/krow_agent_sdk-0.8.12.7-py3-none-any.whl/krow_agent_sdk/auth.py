"""SDK auth facade（design doc §3 + Step 1 PR S1.17）。

KROW_API_KEY 环境变量读取 + API key 格式校验。

> **铁证**（v0.8 设计文档调研发现）：
>
> - ``modules.auth.krow_auth.KrowAuthAdapter`` 当前**没有** ``set_api_key`` / ``get_user_info`` 方法
> - ``KROW_API_KEY`` env var 在主仓 *.py 中**没有被读取**
> - ``modules.auth.service.AuthService._login_with_api_key`` 是 dead code（依赖上述两条）
>
> Wave 1 暂不接入 ``KrowAuthAdapter.set_api_key``——主仓 KrowLLMProvider 当前
> 通过 ``Authorization: Bearer <access_token>`` (Headless env auth) 工作；Wave 1 SDK 仅在
> ``AgentBuilder.build()`` 时验证 ``KROW_API_KEY`` 存在 + 格式正确，并把
> 校验后的 api_key 透传给 ``KrowLLMProvider``（Wave 2 修 dead code 端到端打通）。
"""
from __future__ import annotations

import os
import re
from typing import Final

from .errors import InvalidKrowAPIKeyError, MissingKrowAPIKeyError

ENV_KROW_API_KEY: Final[str] = "KROW_API_KEY"
ENV_KROW_PROJECT_ROOT: Final[str] = "KROW_PROJECT_ROOT"

# OpenAI-compatible 格式：``sk-`` 前缀，长度 ≥ 20，仅字母数字 + 下划线 + 连字符
API_KEY_PATTERN: Final[re.Pattern[str]] = re.compile(r"^sk-[A-Za-z0-9_\-]{17,}$")


def validate_api_key_format(api_key: str) -> str:
    """校验 API key 格式；不合法 raise ``InvalidKrowAPIKeyError``。

    Returns:
        校验通过的 api_key（原样返回，便于链式 ``return validate_api_key_format(...)``）

    Raises:
        InvalidKrowAPIKeyError: 格式错（非 sk- 前缀 / 长度不足 / 含非法字符）
    """
    if not isinstance(api_key, str) or not api_key:
        raise InvalidKrowAPIKeyError(masked_key="<empty>")
    stripped = api_key.strip()
    if not API_KEY_PATTERN.match(stripped):
        masked = _mask_api_key(stripped)
        raise InvalidKrowAPIKeyError(masked_key=masked)
    return stripped


def read_api_key_from_env() -> str:
    """从 ``KROW_API_KEY`` 环境变量读 api_key；缺失 raise ``MissingKrowAPIKeyError``。

    格式校验也会跑。
    """
    raw = os.environ.get(ENV_KROW_API_KEY, "").strip()
    if not raw:
        raise MissingKrowAPIKeyError()
    return validate_api_key_format(raw)


def read_project_root_from_env() -> str | None:
    """从 ``KROW_PROJECT_ROOT`` 环境变量读项目根路径；不存在返回 None。"""
    raw = os.environ.get(ENV_KROW_PROJECT_ROOT, "").strip()
    return raw or None


def _mask_api_key(api_key: str) -> str:
    """脱敏 api_key 用于日志 / error message。

    保留前 6 位 + 后 4 位，中间用 ``***`` 替换。
    """
    if len(api_key) <= 10:
        return "***"
    return f"{api_key[:6]}***{api_key[-4:]}"


__all__ = [
    "ENV_KROW_API_KEY",
    "ENV_KROW_PROJECT_ROOT",
    "validate_api_key_format",
    "read_api_key_from_env",
    "read_project_root_from_env",
]
