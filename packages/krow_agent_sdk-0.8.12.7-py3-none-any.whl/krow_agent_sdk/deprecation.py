"""SDK API 弃用装饰器（PR B3 / S2.9）。

为 SDK 公共 API 标记 ``@deprecated(reason, removed_in)`` 以告知 plugin 作者。

## 用法

```python
from modules.agent.sdk.deprecation import deprecated

@deprecated(reason="改用 with_act_plugins_from_entry_points()", removed_in="0.9")
def with_act_plugin_legacy(self, plugin):
    ...
```

调用方第一次触发时会 log 一条 warning（同进程内同函数不重复 log）。

## 与 Python 内置 ``warnings.warn(DeprecationWarning)`` 的关系

本装饰器同时调用 ``warnings.warn(..., DeprecationWarning)``——上层 SDK 用户
可通过 ``-W error::DeprecationWarning`` 把 warning 升级为 error 做严格审查。

## SSOT 锚点

- 设计文档：§5.0.1 / §6.1 / §9.2 S2.9
- 与 Python ``deprecated`` PEP 702（3.13+）等价语义；本实现兼容 3.10+
"""
from __future__ import annotations

import functools
import logging
import warnings
from typing import Any, Callable, TypeVar

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


# 进程内已 log 过 deprecation warning 的函数 id（避免刷屏）
_logged_warnings: set[str] = set()


def deprecated(
    *,
    reason: str,
    removed_in: str | None = None,
    use_instead: str | None = None,
) -> Callable[[F], F]:
    """装饰器：把函数 / 方法标记为 deprecated。

    Args:
        reason: 弃用原因（必填）
        removed_in: 计划移除版本（如 ``"0.9"``）；None 表示"未定计划"
        use_instead: 推荐的替代 API；None 表示"无替代"

    Returns:
        装饰器（保留原函数签名）
    """
    def _decorator(func: F) -> F:
        msg_parts = [f"{func.__module__}.{func.__qualname__} is deprecated: {reason}"]
        if removed_in:
            msg_parts.append(f"will be removed in v{removed_in}")
        if use_instead:
            msg_parts.append(f"use {use_instead} instead")
        warning_msg = "; ".join(msg_parts)
        log_key = f"{func.__module__}.{func.__qualname__}"

        @functools.wraps(func)
        def _wrapper(*args: Any, **kwargs: Any) -> Any:
            # warnings.warn 会被 -W error::DeprecationWarning 升级为 error
            warnings.warn(warning_msg, DeprecationWarning, stacklevel=2)
            # log warning 仅首次（避免刷屏）
            if log_key not in _logged_warnings:
                _logged_warnings.add(log_key)
                logger.warning(warning_msg)
            return func(*args, **kwargs)

        # 暴露元数据给 introspection
        _wrapper.__deprecated__ = True  # type: ignore[attr-defined]
        _wrapper.__deprecated_reason__ = reason  # type: ignore[attr-defined]
        _wrapper.__deprecated_removed_in__ = removed_in  # type: ignore[attr-defined]
        _wrapper.__deprecated_use_instead__ = use_instead  # type: ignore[attr-defined]

        # 在 docstring 里加 deprecation 标记（让 IDE / pydoc 也能看到）
        original_doc = func.__doc__ or ""
        deprecation_note = f"\n\n.. deprecated:: {removed_in or '未定'}\n    {reason}"
        if use_instead:
            deprecation_note += f"\n    Use ``{use_instead}`` instead."
        _wrapper.__doc__ = original_doc + deprecation_note

        return _wrapper  # type: ignore[return-value]

    return _decorator


def is_deprecated(func: Any) -> bool:
    """检查一个函数是否已被 ``@deprecated`` 标记。"""
    return getattr(func, "__deprecated__", False)


def get_deprecation_metadata(func: Any) -> dict[str, Any] | None:
    """获取函数的 deprecation 元数据；非 deprecated 返 None。"""
    if not is_deprecated(func):
        return None
    return {
        "reason": getattr(func, "__deprecated_reason__", ""),
        "removed_in": getattr(func, "__deprecated_removed_in__", None),
        "use_instead": getattr(func, "__deprecated_use_instead__", None),
    }


def _clear_logged_warnings_for_test() -> None:
    """仅测试用：清空 logged warnings 集合。"""
    _logged_warnings.clear()


__all__ = [
    "deprecated",
    "get_deprecation_metadata",
    "is_deprecated",
]
