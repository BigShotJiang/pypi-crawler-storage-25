"""DomainPackExpander —— P9 DomainPackPlugin 真实展开（Wave 3）。

设计文档锚点：§5.0.4 P9 + §9.1 PR S1.11；本文件落地 P9 真实加载。

## 工作原理

DomainPackPlugin 是"语法糖" Protocol，一次声明 8 个 OPTIONAL 元素：

1. `get_hints()` → **真展开**为多个 hint callable 注册到 ``HintRegistry``
2. `get_tools()` → **真展开**为 P2 ToolPlugin spec 注册到 ``ToolManager``
3. `get_gates()` → **真展开**为 SDK GateRegistry entry（带 phase）
4. `get_extended_md_supplement(target_act)` → SDK 内部 ``supplement_registry`` list
   （Wave 3 仅记录；Wave Step 2 PR S2.1 改造 ACTLoader 后真合并到 native ACT extended.md）
5. `get_visual_adapters()` → SDK 内部 list（feature flag off）
6. `get_mcp_servers()` → SDK 内部 list（feature flag off）
7. `get_event_listeners()` → **真展开**注册到 EventBus
8. `get_recommended_budget()` → 写到 builder.config.budget（如果 with_budget 未显式调）

## SSOT 约束

- 展开**只**使用 SDK 已有 SSOT（HintRegistry / ToolManager / GateRegistry / EventBus）
- 不破坏既有 with_*_plugin 调用链
- per-DomainPack 维护 cleanup callback list（Agent.shutdown 反向清理）
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Callable, Optional

if TYPE_CHECKING:
    from modules.events.bus import EventBus
    from modules.tools.manager import ToolManager

    from .experimental.protocols.domain_pack import DomainPackPlugin
    from .hints import HintRegistry
    from .lifecycle import SDKContext

logger = logging.getLogger(__name__)


def _safe_call(fn_name: str, plugin: Any, default: Any = None) -> Any:
    """安全调用 plugin OPTIONAL method；不实现 / 返回 None / 抛异常 → 返回 default。"""
    fn = getattr(plugin, fn_name, None)
    if fn is None or not callable(fn):
        return default
    try:
        return fn()
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "DomainPackPlugin.%s error (plugin_id=%s): %s",
            fn_name, getattr(plugin, "plugin_id", "?"), exc, exc_info=True,
        )
        return default


def expand_domain_pack(
    plugin: "DomainPackPlugin",
    *,
    hint_registry: "HintRegistry",
    tool_manager: "ToolManager",
    event_bus: "EventBus",
    gate_registry: Any,  # `_GateRegistry` from builder.py
    sdk_context: "SDKContext",
    sdk_state: dict[str, Any],
) -> list[Callable[[], None]]:
    """把 DomainPackPlugin 展开为 8 元素并真实加载到对应 registry。

    Args:
        plugin: DomainPackPlugin 实例（OPTIONAL 方法允许不实现）
        hint_registry: SDK HintRegistry singleton
        tool_manager: 主仓 ToolManager singleton
        event_bus: 主仓 EventBus singleton
        gate_registry: SDK 内部 _GateRegistry
        sdk_context: 注入到 plugin 的 context
        sdk_state: SDK builder state 字典，用于把 mcp_servers / security_policies /
            supplementary_mds / visual_adapters / recommended_budget 写到 builder

    Returns:
        cleanup callback list（反向清理用）
    """
    plugin_id = plugin.plugin_id
    domain_name = getattr(plugin, "domain_name", "<unknown>") or "<unknown>"
    cleanup: list[Callable[[], None]] = []

    # ── 1. hints → HintRegistry ──
    hints = _safe_call("get_hints", plugin, default=[]) or []
    hint_keys: list[str] = []
    for idx, hint_fn in enumerate(hints):
        if not callable(hint_fn):
            continue
        hint_key = f"domain_pack:{plugin_id}:{idx}"
        hint_registry.register_hint(plugin_id=hint_key, hint_callable=hint_fn)
        hint_keys.append(hint_key)
    if hint_keys:
        def _cleanup_hints():
            for k in hint_keys:
                try:
                    hint_registry.unregister_hint(k)
                except Exception:  # noqa: BLE001
                    pass
        cleanup.append(_cleanup_hints)

    # ── 2. tools → ToolManager ──
    tool_specs = _safe_call("get_tools", plugin, default=[]) or []
    registered_tool_names: list[str] = []
    for spec in tool_specs:
        if not isinstance(spec, dict):
            continue
        name = spec.get("name")
        if not name:
            continue
        try:
            ok = tool_manager.register_tool(
                name=name,
                description=spec.get("description", ""),
                input_schema=spec.get("input_schema", {}),
                handler=spec["handler"],
                server_name=f"domain_pack_{plugin_id}",
                category=spec.get("category", "domain_pack"),
                direct_output=spec.get("direct_output", False),
                user_visible=spec.get("user_visible", True),
                output_schema=spec.get("output_schema"),
                complexity=spec.get("complexity", "normal"),
                dependencies=spec.get("dependencies"),
            )
            if ok:
                registered_tool_names.append(name)
        except Exception as exc:  # noqa: BLE001
            logger.error(
                "DomainPack tool register failed (plugin_id=%s, tool=%s): %s",
                plugin_id, name, exc, exc_info=True,
            )
    if registered_tool_names:
        def _cleanup_tools():
            tools = getattr(tool_manager, "tools", {})
            handlers = getattr(tool_manager, "_dynamic_handlers", {})
            for n in registered_tool_names:
                tools.pop(n, None)
                handlers.pop(n, None)
        cleanup.append(_cleanup_tools)

    # ── 3. gates → SDK GateRegistry ──
    gates_raw = _safe_call("get_gates", plugin, default=[]) or []
    gate_keys: list[str] = []
    for idx, item in enumerate(gates_raw):
        if not isinstance(item, tuple) or len(item) != 2:
            continue
        phase, gate = item
        gate_key = f"domain_pack:{plugin_id}:gate:{idx}"
        try:
            gate_registry.register(gate_key, gate, phase=str(phase or "macro"))
            gate_keys.append(gate_key)
        except Exception as exc:  # noqa: BLE001
            logger.error(
                "DomainPack gate register failed (plugin_id=%s, idx=%d): %s",
                plugin_id, idx, exc, exc_info=True,
            )
    if gate_keys:
        def _cleanup_gates():
            for k in gate_keys:
                try:
                    gate_registry.unregister(k)
                except Exception:  # noqa: BLE001
                    pass
        cleanup.append(_cleanup_gates)

    # ── 4. extended_md_supplement → 进程级 supplement registry（PR B3 / S2.14 真实合并）──
    fn_supp = getattr(plugin, "get_extended_md_supplement", None)
    if callable(fn_supp):
        from .extended_md_supplement_registry import (
            register_extended_md_supplement,
            unregister_extended_md_supplement,
        )

        register_extended_md_supplement(plugin_id, fn_supp)
        sdk_state.setdefault("supplementary_md_providers", []).append(plugin)

        def _cleanup_supp() -> None:
            try:
                unregister_extended_md_supplement(plugin_id)
            except Exception:  # noqa: BLE001
                pass
        cleanup.append(_cleanup_supp)

    # ── 5. visual_adapters → sdk_state ──
    visual_adapters = _safe_call("get_visual_adapters", plugin, default=[]) or []
    if visual_adapters:
        sdk_state.setdefault("visual_adapters", []).extend(visual_adapters)

    # ── 6. mcp_servers → sdk_state ──
    mcp_servers = _safe_call("get_mcp_servers", plugin, default=[]) or []
    if mcp_servers:
        sdk_state.setdefault("mcp_servers", []).extend(mcp_servers)

    # ── 7. event_listeners → EventBus.subscribe ──
    listeners = _safe_call("get_event_listeners", plugin, default=[]) or []
    listener_tokens: list[str] = []
    for item in listeners:
        if not isinstance(item, tuple) or len(item) != 2:
            continue
        topic, handler = item
        if not topic or not callable(handler):
            continue
        try:
            tok = event_bus.subscribe(str(topic), handler)
            listener_tokens.append(tok)
        except Exception as exc:  # noqa: BLE001
            logger.error(
                "DomainPack event listener subscribe failed "
                "(plugin_id=%s, topic=%s): %s",
                plugin_id, topic, exc, exc_info=True,
            )
    if listener_tokens:
        def _cleanup_listeners():
            for tok in listener_tokens:
                try:
                    event_bus.unsubscribe(tok)
                except Exception:  # noqa: BLE001
                    pass
        cleanup.append(_cleanup_listeners)

    # ── 8. recommended_budget → sdk_state（仅当 builder 没显式 with_budget 时使用）──
    budget_dict = _safe_call("get_recommended_budget", plugin, default=None)
    if isinstance(budget_dict, dict):
        sdk_state["recommended_budget"] = budget_dict

    logger.info(
        "DomainPack expanded: plugin_id=%s domain=%s hints=%d tools=%d gates=%d "
        "listeners=%d mcp=%d visual=%d supplement=%s budget=%s",
        plugin_id, domain_name,
        len(hint_keys), len(registered_tool_names), len(gate_keys),
        len(listener_tokens), len(mcp_servers), len(visual_adapters),
        bool(callable(fn_supp)), budget_dict is not None,
    )

    return cleanup


__all__ = ["expand_domain_pack"]
