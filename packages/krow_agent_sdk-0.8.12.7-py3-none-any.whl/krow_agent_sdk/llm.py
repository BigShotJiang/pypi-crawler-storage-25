"""LLM helper for plugins（design doc §3.3 + 顶级 review A7 + Step 1 PR S1.23）。

主仓 ``LLMSourceModule`` 真实是普通类含中文常量字符串（不是 enum），
天然兼容 plugin 用 ``str`` 命名空间——plugin 不需要往 ``LLMSourceModule`` 上加属性，
只需用 ``f"plugin:{plugin_id}"`` 字符串调 ``llm_source_context()`` 即可。

Re-export（M6 1B 双轨）:

- runtime 装上后：``from modules.ai.providers import ChatMessage`` 直接命中真实
- runtime 没装时：fallback 到 ``modules.agent.sdk._vendor.llm_stub``（thin dataclass
  + 常量类 + contextmanager wrapper，与真实**值**完全兼容）

详 ``docs/sdk/source-protection-design.md`` §3 D1 决策.
"""
from __future__ import annotations

try:
    from modules.ai.providers import ChatMessage, LLMSourceModule, llm_source_context
except ModuleNotFoundError:
    from ._vendor.llm_stub import ChatMessage, LLMSourceModule, llm_source_context

from ._plugin_id_validator import validate_plugin_id


def make_plugin_source_module(plugin_id: str) -> str:
    """生成 plugin 的 source_module 字符串（v0.8 design doc §3.3.1）。

    格式：``f"plugin:{plugin_id}"``，与内置 ``LLMSourceModule.PLANNER`` 等中文常量
    天然不冲突（前缀 ``plugin:`` 是英文命名空间）。

    SDK 启动期校验：plugin 必须用 ``f"plugin:..."`` 前缀，冒充内置 fail-loud。

    Args:
        plugin_id: 双段命名 ``<org>.<plugin_name>``（详 §5.0.5）

    Returns:
        ``"plugin:<org>.<plugin_name>"`` 字符串
    """
    validate_plugin_id(plugin_id)
    return f"plugin:{plugin_id}"


__all__ = [
    "ChatMessage",
    "LLMSourceModule",
    "llm_source_context",
    "make_plugin_source_module",
]
