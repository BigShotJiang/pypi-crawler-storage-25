"""ACT extended.md supplement 进程级注册表（PR B3 / S2.14）。

DomainPackPlugin.get_extended_md_supplement(target_act) -> str | None
被 SDK 真实合并到 ``ACTHierarchyLoader.load_extended(target_act)`` 返回的
``ACTExtended.content`` 末尾。

## 配额（v0.8 A9）

每个 ACT 的总 supplement 文本上限 16KB（约 16384 字符），单个 plugin
对单个 ACT 的 supplement 上限 4KB。超限时记 warning + 截断（fail-loud）。

## 调用链

```
ACTHierarchyLoader.load_extended(act_name)
    ├─ 加载 base extended.md → ACTExtended.content
    └─ 调 apply_supplements(act_name, ACTExtended) ← 本模块
        ├─ get_supplements_for(act_name) → list[(plugin_id, text)]
        └─ 拼到 ACTExtended.content 末尾（每个 plugin 一个 ## 章节）
```

## SSOT 锚点

- 设计文档 §5.9 + §6.1 / §9.2 S2.14
- 容错：单个 plugin supplement 抛异常 → log warning + skip，不阻塞主流程
"""
from __future__ import annotations

import logging
import threading
from typing import Callable, List, Tuple

logger = logging.getLogger(__name__)


# ────────────────────────────────────────────────────────────────────
# 配额常量（v0.8 A9）
# ────────────────────────────────────────────────────────────────────

MAX_SUPPLEMENT_CHARS_PER_PLUGIN = 4 * 1024
"""单 plugin 单 ACT supplement 文本上限：4KB。"""

MAX_SUPPLEMENT_CHARS_PER_ACT_TOTAL = 16 * 1024
"""单 ACT 总 supplement 文本上限：16KB。"""


# ────────────────────────────────────────────────────────────────────
# 进程级注册表（线程安全）
# ────────────────────────────────────────────────────────────────────


class _SupplementRegistry:
    """进程级单例：plugin_id → callable(act_name) -> str | None。"""

    def __init__(self) -> None:
        self._providers: dict[str, Callable[[str], str | None]] = {}
        self._lock = threading.RLock()

    def register(
        self,
        plugin_id: str,
        provider: Callable[[str], str | None],
    ) -> None:
        with self._lock:
            if plugin_id in self._providers:
                logger.warning(
                    "extended_md_supplement: plugin_id=%s 已注册（旧 provider 将被覆盖）",
                    plugin_id,
                )
            self._providers[plugin_id] = provider

    def unregister(self, plugin_id: str) -> bool:
        with self._lock:
            return self._providers.pop(plugin_id, None) is not None

    def get_supplements_for(self, act_name: str) -> List[Tuple[str, str]]:
        """查询所有 plugin 对该 ACT 的 supplement，返回 (plugin_id, text) 列表。

        - 单 plugin 抛异常 → log warning + 跳过
        - 单 plugin 返超长（>4KB） → log warning + 截断
        - 总长 > 16KB → log warning + 截止后续 plugin
        """
        with self._lock:
            providers = list(self._providers.items())

        results: List[Tuple[str, str]] = []
        total_chars = 0

        for plugin_id, provider in providers:
            try:
                text = provider(act_name)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "extended_md_supplement: plugin_id=%s act=%s 抛异常（已跳过）：%s",
                    plugin_id, act_name, exc,
                )
                continue
            if not text or not isinstance(text, str):
                continue

            # 单 plugin 配额
            if len(text) > MAX_SUPPLEMENT_CHARS_PER_PLUGIN:
                logger.warning(
                    "extended_md_supplement: plugin_id=%s act=%s 文本超 %d 字符上限（实际 %d），已截断",
                    plugin_id, act_name, MAX_SUPPLEMENT_CHARS_PER_PLUGIN, len(text),
                )
                text = text[:MAX_SUPPLEMENT_CHARS_PER_PLUGIN] + "\n\n... [truncated]"

            # 总配额
            if total_chars + len(text) > MAX_SUPPLEMENT_CHARS_PER_ACT_TOTAL:
                logger.warning(
                    "extended_md_supplement: act=%s 总 supplement 已达 %d 字符上限，跳过 plugin_id=%s 及后续",
                    act_name, MAX_SUPPLEMENT_CHARS_PER_ACT_TOTAL, plugin_id,
                )
                break

            results.append((plugin_id, text))
            total_chars += len(text)

        return results

    def clear(self) -> None:
        """清空注册表（仅测试用）。"""
        with self._lock:
            self._providers.clear()

    def is_empty(self) -> bool:
        with self._lock:
            return not self._providers


_global_registry = _SupplementRegistry()


# ────────────────────────────────────────────────────────────────────
# 公开 API
# ────────────────────────────────────────────────────────────────────


def register_extended_md_supplement(
    plugin_id: str,
    provider: Callable[[str], str | None],
) -> None:
    """注册一个 supplement provider。

    Args:
        plugin_id: 全局唯一 plugin ID（``<org>.<plugin_name>``）
        provider: ``(act_name: str) -> str | None`` 的 callable；
            返回 None / 空串视为"该 ACT 不适用"。
    """
    _global_registry.register(plugin_id, provider)


def unregister_extended_md_supplement(plugin_id: str) -> bool:
    """注销 supplement provider。

    Returns:
        True 如果注销成功；False 如果 plugin_id 不存在。
    """
    return _global_registry.unregister(plugin_id)


def get_supplements_for(act_name: str) -> List[Tuple[str, str]]:
    """查询所有 plugin 对该 ACT 的 supplement。

    Returns:
        list of (plugin_id, supplement_text)；按注册顺序，已应用 4KB / 16KB 配额。
    """
    return _global_registry.get_supplements_for(act_name)


def merge_supplements_into_extended_md(
    act_name: str,
    base_extended_md: str,
) -> str:
    """把 supplement 合并到 base extended.md 末尾。

    每个 plugin 的 supplement 单独成 ``## Plugin: <plugin_id>`` 章节。
    """
    supplements = get_supplements_for(act_name)
    if not supplements:
        return base_extended_md

    parts = [base_extended_md.rstrip()]
    parts.append("\n\n---\n\n# Plugin Supplements\n")
    for plugin_id, text in supplements:
        parts.append(f"\n## {plugin_id}\n\n{text.strip()}\n")
    return "".join(parts)


def _clear_for_test() -> None:
    """仅测试用：清空全局注册表。"""
    _global_registry.clear()


__all__ = [
    "MAX_SUPPLEMENT_CHARS_PER_ACT_TOTAL",
    "MAX_SUPPLEMENT_CHARS_PER_PLUGIN",
    "get_supplements_for",
    "merge_supplements_into_extended_md",
    "register_extended_md_supplement",
    "unregister_extended_md_supplement",
]
