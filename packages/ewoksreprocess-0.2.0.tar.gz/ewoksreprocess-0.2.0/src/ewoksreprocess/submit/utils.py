import os


def isRemoteConfigured() -> bool:
    """
    Return True if remote Ewoks execution is configured via environment.
    """
    return bool(os.environ.get("BEACON_HOST") or os.environ.get("EWOKS_CONFIG_URI"))
