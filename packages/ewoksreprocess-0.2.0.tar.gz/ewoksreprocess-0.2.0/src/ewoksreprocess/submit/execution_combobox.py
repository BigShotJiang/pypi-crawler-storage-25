from silx.gui import qt

from .utils import isRemoteConfigured


class ExecutionComboBox(qt.QComboBox):
    """A combobox to choose the execution location: local or on a worker"""

    _LOCAL_HOST = "Local"
    _REMOTE_HOST = "Ewoks worker"

    def __init__(self, parent: qt.QWidget | None = None):
        super().__init__(parent)

        self._executionModeComboBox = qt.QComboBox()
        self.addItems((self._LOCAL_HOST, self._REMOTE_HOST))
        self.setCurrentText(self._LOCAL_HOST)

        self.setToolTip(
            "Select where the process will be executed: locally or on an Ewoks worker."
        )
        if not isRemoteConfigured():
            remoteIndex = self.findText(self._REMOTE_HOST)
            item = self.model().item(remoteIndex)
            item.setEnabled(False)
            item.setToolTip("Requires BEACON_HOST or EWOKS_CONFIG_URI to be set.")

    def isRemoteOptionEnabled(self) -> bool:
        """
        Return True if the "Ewoks worker" execution option is available.
        """
        remoteIndex = self.findText(self._REMOTE_HOST)
        if remoteIndex < 0:
            return False
        return self.model().item(remoteIndex).isEnabled()

    def setLocalExecution(self, local: bool) -> None:
        """
        Select local or remote execution.

        If remote execution is requested but not available, fallback to local execution.
        """
        if not local and not self.isRemoteOptionEnabled():
            return

        if local:
            self.setCurrentText(self._LOCAL_HOST)
        else:
            self.setCurrentText(self._REMOTE_HOST)

    def isLocalExecution(self) -> bool:
        """
        Return True if local execution is currently selected.
        """
        return self.currentText() == self._LOCAL_HOST
