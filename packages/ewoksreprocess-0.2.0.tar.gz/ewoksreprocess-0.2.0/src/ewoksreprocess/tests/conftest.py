SUM_TASK_WORKFLOW = {
    "graph": {"id": "test"},
    "nodes": [
        {
            "id": "task",
            "task_type": "class",
            "task_identifier": "ewokscore.tests.examples.tasks.sumtask.SumTask",
        },
    ],
}
