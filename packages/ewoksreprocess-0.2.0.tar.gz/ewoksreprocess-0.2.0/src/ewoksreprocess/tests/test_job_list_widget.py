from ewoksutils.task_utils import task_inputs
from silx.gui import qt

from ewoksreprocess.submit.jobs_list_widget import JobItem
from ewoksreprocess.submit.jobs_list_widget import JobsListWidget

from ..submit.workflow_executor import WorkflowExecutor
from .conftest import SUM_TASK_WORKFLOW


def test_list_item_is_added_and_removed(qtbot):
    executor = WorkflowExecutor()
    jobs_list_widget = JobsListWidget(executor)

    inputs = task_inputs(inputs={"a": 1, "b": 2, "delay": 2})

    with qtbot.waitSignal(executor.jobSubmitted, timeout=1000) as blocker:
        job = executor.submit(True, graph=SUM_TASK_WORKFLOW, inputs=inputs)
    assert job is blocker.args[0]

    assert jobs_list_widget._listWidget.count() == 1
    listItem = jobs_list_widget._listWidget.item(0)
    assert isinstance(listItem, qt.QListWidgetItem)
    assert isinstance(listItem.data(qt.Qt.ItemDataRole.UserRole), JobItem)

    with qtbot.waitSignal(executor.finished, timeout=20000):
        executor.shutdown(wait=True, cancelFutures=False)

    assert listItem.data(qt.Qt.ItemDataRole.UserRole) is None

    # Test removal
    assert jobs_list_widget._listWidget.count() == 1
    jobs_list_widget.removeFinishedItems()
    assert jobs_list_widget._listWidget.count() == 0
