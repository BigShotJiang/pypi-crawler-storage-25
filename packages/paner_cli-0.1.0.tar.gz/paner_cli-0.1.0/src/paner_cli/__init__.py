"""
Compatibility shim for the `paner-cli` distribution.

The actual package name is `paner`; this module re-exports its public API so
build tools expecting `paner_cli` can resolve the project correctly.
"""

from paner import *  # noqa: F401,F403
