"""Public interfaces for the email package."""

from appcore.email_.auth import EmailAuth, NoAuth, OAuth2Auth, PlainAuth
from appcore.email_.email_client import EmailClient

__all__ = ["EmailAuth", "EmailClient", "NoAuth", "OAuth2Auth", "PlainAuth"]
