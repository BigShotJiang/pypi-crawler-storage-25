"""Email message construction and delivery."""

from __future__ import annotations

import mimetypes
import smtplib
from email.mime.application import MIMEApplication
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import Literal

from appcore.common import exceptions as common_exceptions
from appcore.config import settings_models
from appcore.crypto import crypto
from appcore.email_ import auth


class EmailClient:
    """Build and send SMTP email messages."""

    def __init__(
        self,
        smtp_host: str,
        smtp_port: int,
        use_ssl: bool,
        email_auth: auth.EmailAuth,
        sender_name: str,
        sender_email: str,
        timeout: int = 30,
    ) -> None:
        """Store SMTP connection settings."""
        self._smtp_host = smtp_host
        self._smtp_port = smtp_port
        self._use_ssl = use_ssl
        self._auth = email_auth
        self._sender_name = sender_name
        self._sender_email = sender_email
        self._timeout = timeout

    def send(
        self,
        subject: str,
        body: str,
        to: list[str],
        *,
        cc: list[str] | None = None,
        bcc: list[str] | None = None,
        body_type: Literal["plain", "html"] = "plain",
        attachments: list[Path | tuple[str, bytes]] | None = None,
        reply_to: str | None = None,
    ) -> None:
        """Build, authenticate, and send an email message."""
        cc_recipients = cc or []
        bcc_recipients = bcc or []
        attachment_items = attachments or []

        message = MIMEMultipart()
        message["From"] = f"{self._sender_name} <{self._sender_email}>"
        message["To"] = ", ".join(to)
        if cc_recipients:
            message["Cc"] = ", ".join(cc_recipients)
        message["Subject"] = subject
        if reply_to is not None:
            message["Reply-To"] = reply_to
        message.attach(MIMEText(body, body_type, "utf-8"))

        for attachment in attachment_items:
            message.attach(self._build_attachment_part(attachment))

        recipients = [*to, *cc_recipients, *bcc_recipients]
        try:
            with smtplib.SMTP(self._smtp_host, self._smtp_port, timeout=self._timeout) as smtp:
                if self._use_ssl:
                    smtp.starttls()
                self._auth.apply(smtp)
                smtp.sendmail(self._sender_email, recipients, message.as_string())
        except Exception as exc:
            raise common_exceptions.EmailError(f"Failed to send email: {exc}") from exc

    @classmethod
    def from_config(
        cls,
        settings: settings_models.EmailSettings,
        crypto_service: crypto.CryptoService,
    ) -> EmailClient:
        """Build an EmailClient from validated settings."""
        decrypted_secret = crypto_service.decrypt_if_encrypted(settings.password)
        email_auth: auth.EmailAuth
        if settings.auth_type == "plain":
            email_auth = auth.PlainAuth(settings.username, decrypted_secret)
        elif settings.auth_type == "oauth2":
            email_auth = auth.OAuth2Auth(settings.username, decrypted_secret)
        else:
            email_auth = auth.NoAuth()

        return cls(
            smtp_host=settings.smtp_host,
            smtp_port=settings.smtp_port,
            use_ssl=settings.use_ssl,
            email_auth=email_auth,
            sender_name=settings.sender_name,
            sender_email=settings.sender_email,
            timeout=settings.timeout,
        )

    @staticmethod
    def _build_attachment_part(attachment: Path | tuple[str, bytes]) -> MIMEBase:
        """Build one MIME attachment part."""
        if isinstance(attachment, Path):
            filename = attachment.name
            payload = attachment.read_bytes()
            mime_type, _ = mimetypes.guess_type(str(attachment))
        else:
            filename, payload = attachment
            mime_type = None

        part = MIMEApplication(payload, _subtype="octet-stream")
        if mime_type is not None:
            major, minor = mime_type.split("/", maxsplit=1)
            part.set_type(f"{major}/{minor}")
        part.add_header("Content-Disposition", "attachment", filename=filename)
        return part
