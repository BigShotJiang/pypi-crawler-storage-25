"""SMTP authentication strategies."""

from __future__ import annotations

import base64
import smtplib
from typing import Protocol, runtime_checkable


@runtime_checkable
class EmailAuth(Protocol):
    """Protocol for authenticating an open SMTP connection."""

    def apply(self, smtp: smtplib.SMTP) -> None:
        """Apply authentication to the SMTP connection."""
        ...


class PlainAuth:
    """Authenticate with a username and password."""

    def __init__(self, username: str, password: str) -> None:
        """Store plain-credential authentication details."""
        self.username = username
        self.password = password

    def apply(self, smtp: smtplib.SMTP) -> None:
        """Authenticate using SMTP LOGIN/PLAIN."""
        smtp.login(self.username, self.password)


class OAuth2Auth:
    """Authenticate using the XOAUTH2 SASL mechanism."""

    def __init__(self, username: str, access_token: str) -> None:
        """Store OAuth2 authentication details."""
        self.username = username
        self.access_token = access_token

    def apply(self, smtp: smtplib.SMTP) -> None:
        """Authenticate using XOAUTH2."""
        auth_string = (
            f"user={self.username}\x01auth=Bearer {self.access_token}\x01\x01"
        )
        encoded = base64.b64encode(auth_string.encode("utf-8")).decode("ascii")
        smtp.docmd("AUTH", f"XOAUTH2 {encoded}")


class NoAuth:
    """No-op SMTP authentication."""

    def apply(self, smtp: smtplib.SMTP) -> None:
        """Do nothing for unauthenticated SMTP servers."""
        return
