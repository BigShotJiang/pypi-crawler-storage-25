"""Auto-generate documentation pages from project structure."""

import ast
import fnmatch
import os
import re
import stat
import tempfile

from selfdoc.build import _parse_frontmatter
from selfdoc.extractors import EXTRACTORS


# Matches the default per-module description template so we can detect when a
# page still has its auto-generated description (and recompute it) versus when
# a user has hand-edited the description (and we should preserve it).
_DEFAULT_DESCRIPTION_RE = re.compile(
    r"^API reference for (the )?[\w.]+( module)? — "
    r"auto-generated documentation covering public functions, "
    r"classes, and type signatures\.?$"
)


# Default exclusion patterns (always applied in addition to user-configured ones).
# These are matched against both the full relative path and the basename,
# so ``test_*`` will match ``test_core.py`` at any depth.
_DEFAULT_EXCLUDES = [
    "test_*",
    "*_test.*",
    "__pycache__",
    "tests",
]


def _extract_module_docstring(filepath):
    """Extract the first line of a Python module's docstring.

    Uses ``ast.parse`` and ``ast.get_docstring`` to read the module-level
    docstring.  Returns the first sentence (up to the first period followed
    by whitespace/end, or the first newline), truncated to 155 characters.
    Returns ``None`` if the file is not Python, cannot be parsed, or has
    no module docstring.
    """
    if not filepath.endswith(".py"):
        return None
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            source = f.read()
    except OSError:
        return None
    try:
        tree = ast.parse(source, filename=filepath)
    except SyntaxError:
        return None
    docstring = ast.get_docstring(tree)
    if not docstring:
        return None
    # Take the first line
    first_line = docstring.split("\n", 1)[0].strip()
    if not first_line:
        return None
    # Take up to the first sentence-ending period (period followed by
    # whitespace or end-of-string)
    match = re.search(r"\.\s", first_line)
    if match:
        first_line = first_line[: match.start() + 1]
    elif first_line.endswith("."):
        pass  # already ends with period
    # Truncate to 155 chars
    if len(first_line) > 155:
        first_line = first_line[:152] + "..."
    return first_line


def _has_generated_marker(filepath):
    """Check whether a Markdown file has ``generated: true`` in its frontmatter.

    Returns True if the file starts with ``---`` frontmatter containing
    ``generated: true``, False otherwise (including when the file does
    not exist or cannot be read).
    """
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
    except OSError:
        return False

    if not content.startswith("---"):
        return False

    lines = content.split("\n")
    for idx in range(1, len(lines)):
        line = lines[idx].strip()
        if line == "---":
            break
        if line == "generated: true":
            return True
    return False


def _file_to_module_path(file_path, base_dir, language):
    """Convert a source file path to a module/package path string.

    The path is computed relative to ``base_dir`` (the project root) so
    that the resulting module path matches what ``:-: ref path="..."``
    expects.

    For Python: ``mylib/config.py`` -> ``mylib.config``
    For Go: ``pkg/handler.go`` -> ``pkg/handler``
    For TypeScript/JavaScript: ``src/utils.ts`` -> ``src/utils``
    """
    # Make path relative to the project root
    rel = os.path.relpath(file_path, base_dir)

    # Strip extension
    root, _ext = os.path.splitext(rel)

    if language == "python":
        # Remove trailing /__init__ for package init files
        if root.endswith("/__init__") or root == "__init__":
            root = root.rsplit("/__init__", 1)[0] if "/" in root else ""
        if not root:
            return None
        # Convert path separators to dots
        return root.replace(os.sep, ".").replace("/", ".")

    # Go, TypeScript, JavaScript: keep path separators as slashes
    return root.replace(os.sep, "/")


def _module_to_filename(module_path, language):
    """Convert a module path to a Markdown filename for docs/.

    Replaces dots (Python) or slashes (Go/TS/JS) with dashes.
    E.g. ``selfdoc.config`` -> ``selfdoc-config.md``
    E.g. ``pkg/handler`` -> ``pkg-handler.md``
    """
    if language == "python":
        return module_path.replace(".", "-") + ".md"
    return module_path.replace("/", "-") + ".md"


def _is_excluded(rel_path, exclude_patterns):
    """Check whether a relative path matches any exclusion glob pattern.

    Supports ``**/`` prefix as "match at any depth" by stripping the
    prefix and testing against every path component and the basename.
    Plain patterns are matched against the full path, the basename, and
    each directory component.
    """
    # Normalise to forward slashes for consistent matching
    normalized = rel_path.replace(os.sep, "/")
    parts = normalized.split("/")
    basename = parts[-1]
    dir_parts = parts[:-1]
    for pattern in exclude_patterns:
        # Strip leading **/ for "any depth" semantics
        stripped = pattern
        while stripped.startswith("**/"):
            stripped = stripped[3:]

        if fnmatch.fnmatch(normalized, stripped):
            return True
        if fnmatch.fnmatch(basename, stripped):
            return True
        # Check each directory component
        for part in dir_parts:
            if fnmatch.fnmatch(part, stripped):
                return True
        # Also try the original pattern against the full path
        if pattern != stripped and fnmatch.fnmatch(normalized, pattern):
            return True
    return False


def _read_existing_description(filepath):
    """Return the user-customized ``description`` from a page's frontmatter.

    Returns ``None`` if the file does not exist, has no ``description`` key,
    or still has the default auto-generated description (in which case the
    caller should recompute it from the current module name).
    """
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
    except OSError:
        return None

    metadata, _ = _parse_frontmatter(content)
    raw = metadata.get("description")
    if raw is None or not isinstance(raw, str):
        return None

    # Strip wrapping quotes (single or double) that may survive the simple
    # parser in build.py.
    value = raw.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
        value = value[1:-1].strip()

    if not value:
        return None

    if _DEFAULT_DESCRIPTION_RE.match(value):
        return None

    return value


def _generate_page_content(module_name, module_path, nav_order,
                           existing_description=None,
                           docstring_description=None):
    """Build the Markdown content for a generated documentation page.

    If ``existing_description`` is provided, it is used verbatim as the page's
    ``description`` frontmatter value.  Otherwise, if ``docstring_description``
    is provided (extracted from the module's docstring), it is used.  Finally,
    if neither is available, the default auto-generated template is used.
    """
    if existing_description is not None:
        desc = existing_description
    elif docstring_description is not None:
        desc = docstring_description
    else:
        desc = (
            f"API reference for the {module_name} module — "
            f"auto-generated documentation covering public functions, "
            f"classes, and type signatures."
        )
    return (
        f"---\n"
        f"title: {module_name}\n"
        f"description: \"{desc}\"\n"
        f"generated: true\n"
        f'nav_group: "API Reference"\n'
        f"nav_order: {nav_order}\n"
        f"---\n"
        f"<!-- generated by selfdoc gen, do not edit -->\n"
        f"\n"
        f"# {module_name}\n"
        f"\n"
        f':-: ref path="{module_path}"\n'
    )


def _generate_index_content(generated_pages):
    """Build the gen-index.md page listing all generated pages with links.

    ``generated_pages`` is a list of (module_name, md_filename) tuples,
    already sorted by module name.
    """
    lines = [
        "---",
        "title: API Reference",
        'description: "Complete auto-generated API reference index — browse all modules, classes, and functions with their signatures and docstrings."',
        "generated: true",
        'nav_group: "API Reference"',
        "nav_order: 0",
        "order: 90",
        "---",
        "<!-- generated by selfdoc gen, do not edit -->",
        "",
        "# API Reference",
        "",
    ]
    for module_name, md_filename in generated_pages:
        # Link to the sibling page (same docs/ directory)
        html_name = md_filename.replace(".md", ".html")
        lines.append(f"- [{module_name}]({html_name})")
    lines.append("")
    return "\n".join(lines)


def _atomic_write(filepath, content, permissions=None):
    """Write *content* to *filepath* atomically.

    Writes to a temporary file in the same directory, then replaces the
    target.  Optionally sets file permissions after writing.
    """
    dir_name = os.path.dirname(filepath)
    fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
        if permissions is not None:
            os.chmod(tmp_path, permissions)
        os.replace(tmp_path, filepath)
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def _remove_stale_generated(docs_dir, new_filenames):
    """Delete previously generated files that are no longer in the new set.

    Only removes files whose frontmatter contains ``generated: true``.
    """
    new_set = set(new_filenames)
    for entry in os.listdir(docs_dir):
        if not entry.endswith(".md"):
            continue
        if entry in new_set:
            continue
        full = os.path.join(docs_dir, entry)
        if os.path.isfile(full) and _has_generated_marker(full):
            # Make writable before removing (we set 0o444)
            try:
                os.chmod(full, stat.S_IRUSR | stat.S_IWUSR)
            except OSError:
                pass
            os.unlink(full)


def generate_docs(config, base_dir="."):
    """Auto-discover project source files and generate documentation pages.

    Returns a list of generated file paths relative to the docs directory.
    """
    language = config["language"]
    extractor = EXTRACTORS.get(language)
    if extractor is None:
        raise RuntimeError(f"no extractor for language {language!r}")

    source_paths = config["source"]
    docs_rel = config.get("docs", "docs/")
    docs_dir = os.path.join(base_dir, docs_rel.rstrip("/"))
    os.makedirs(docs_dir, exist_ok=True)

    extensions = set(extractor.file_extensions())

    # Build exclusion patterns: defaults + user-configured
    gen_config = config.get("gen") or {}
    user_excludes = gen_config.get("exclude", [])
    exclude_patterns = list(_DEFAULT_EXCLUDES) + list(user_excludes)

    # Collect (module_path, module_name, md_filename) tuples
    modules = []

    for sp in source_paths:
        source_root = os.path.join(base_dir, sp.rstrip("/"))
        if not os.path.isdir(source_root):
            continue

        for dirpath, _dirnames, filenames in os.walk(source_root):
            for fname in filenames:
                _root, ext = os.path.splitext(fname)
                if ext not in extensions:
                    continue

                full_path = os.path.join(dirpath, fname)
                rel_to_source = os.path.relpath(full_path, source_root)

                if _is_excluded(rel_to_source, exclude_patterns):
                    continue

                module_path = _file_to_module_path(
                    full_path, base_dir, language,
                )
                if module_path is None:
                    continue

                # Also check exclude patterns against the computed module path
                # (supports dotted module names like "selfdoc.staleness")
                if _is_excluded(module_path, exclude_patterns):
                    continue

                md_filename = _module_to_filename(module_path, language)

                # Skip if a hand-written page already exists
                existing_md = os.path.join(docs_dir, md_filename)
                if os.path.isfile(existing_md) and not _has_generated_marker(
                    existing_md
                ):
                    continue

                modules.append((module_path, module_path, md_filename, full_path))

    # Sort for deterministic output
    modules.sort(key=lambda t: t[0])

    # Deduplicate by md_filename (in case multiple source paths yield the same module)
    seen = set()
    unique_modules = []
    for mod_path, mod_name, md_fname, src_path in modules:
        if md_fname not in seen:
            seen.add(md_fname)
            unique_modules.append((mod_path, mod_name, md_fname, src_path))
    modules = unique_modules

    # Collect all filenames we will write (pages + index) for stale cleanup
    all_filenames = [md_fname for _, _, md_fname, _ in modules]
    all_filenames.append("gen-index.md")

    # Resolve the strictcli structure up front so the CLI page names can
    # join all_filenames before the stale-cleanup pass — otherwise the
    # cleanup deletes every cli-*.md file (they have ``generated: true``)
    # and the per-page description preservation has no existing file to
    # read from when generate_cli_pages re-renders them.
    from selfdoc.strictcli_support import (
        uses_strictcli,
        extract_cli_structure,
        generate_cli_pages,
        expected_cli_page_filenames,
    )
    cli_structure = None
    if uses_strictcli(source_paths, base_dir):
        cli_structure = extract_cli_structure(source_paths, base_dir)
    all_filenames.extend(expected_cli_page_filenames(cli_structure))

    # Remove stale generated files before writing new ones
    _remove_stale_generated(docs_dir, all_filenames)

    generated = []

    for nav_order, (mod_path, mod_name, md_fname, src_path) in enumerate(modules, start=1):
        out_path = os.path.join(docs_dir, md_fname)
        existing_description = _read_existing_description(out_path)
        # Try module docstring when no custom description exists
        docstring_description = None
        if existing_description is None:
            docstring_description = _extract_module_docstring(src_path)
        content = _generate_page_content(
            mod_name, mod_path, nav_order,
            existing_description=existing_description,
            docstring_description=docstring_description,
        )
        # Make writable if it already exists with 0o444
        if os.path.isfile(out_path):
            try:
                os.chmod(out_path, stat.S_IRUSR | stat.S_IWUSR)
            except OSError:
                pass
        _atomic_write(out_path, content, permissions=0o444)
        generated.append(md_fname)

    # Generate index page
    index_pages = [(mod_name, md_fname) for _, mod_name, md_fname, _ in modules]
    index_content = _generate_index_content(index_pages)
    index_path = os.path.join(docs_dir, "gen-index.md")
    if os.path.isfile(index_path):
        try:
            os.chmod(index_path, stat.S_IRUSR | stat.S_IWUSR)
        except OSError:
            pass
    _atomic_write(index_path, index_content, permissions=0o444)
    generated.append("gen-index.md")

    # strictcli support: auto-generate CLI documentation pages
    # (cli_structure was resolved earlier so its page names could be
    # excluded from the stale-cleanup pass)
    if cli_structure is not None:
        cli_pages = generate_cli_pages(cli_structure, docs_dir)
        generated.extend(cli_pages)

    return generated
