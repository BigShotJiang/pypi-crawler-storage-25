"""
LangChain → LiveKit Agents bridge.

This module provides a concrete implementation of :class:`~.translators.base.Translator`
for LangChain, bridging a LangChain ``ChatModel`` (or any LangChain Runnable)
to the LiveKit Agent runtime.

ChatModel usage::

    from langchain_openai import ChatOpenAI
    from livekit_agents_adapter_langchain import LangChainTranslator

    llm = ChatOpenAI(model="gpt-4o", streaming=True)
    translator = LangChainTranslator(llm)

Agent usage (AgentExecutor, LangGraph)::

    from langgraph.prebuilt import create_react_agent
    from livekit_agents_adapter_langchain import LangChainTranslator

    graph = create_react_agent(llm, tools=[my_tool])
    translator = LangChainTranslator(graph)
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from livekit.agents import llm

from livekit_agents_adapter import (
    Done,
    ExternalLLMResponse,
    TextChunk,
    ToolCall,
)
from livekit_agents_adapter.translators.base import Translator
from livekit_agents_adapter.translators.chat_context import build_tools_dict

logger = logging.getLogger("livekit_agents_adapter.langchain")


def _handle_chunk(chunk: Any) -> list[ExternalLLMResponse]:
    """Parse a LangChain AIMessage chunk into ExternalLLMResponse items."""
    results: list[ExternalLLMResponse] = []
    content = ""
    tool_calls: list[dict[str, Any]] = []

    if hasattr(chunk, "content"):
        if isinstance(chunk.content, str):
            content = chunk.content
        elif isinstance(chunk.content, list):
            for part in chunk.content:
                if isinstance(part, str):
                    content += part
                elif isinstance(part, dict):
                    if part.get("type") == "text":
                        content += part.get("text", "")
                    elif part.get("type") == "tool_use":
                        tc = part.get("tool_use", {})
                        tool_calls.append(tc)

    if content:
        results.append(TextChunk(content=content, is_final=False))

    for tc in tool_calls:
        name = tc.get("name", "")
        args = tc.get("args", tc.get("input", {}))
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except Exception:
                pass
        results.append(
            ToolCall(
                name=name,
                arguments=args,
                call_id=tc.get("id", ""),
            )
        )

    return results


def _extract_agent_text(event: Any) -> str:
    """Extract text content from an agent streaming event.

    Handles common LangChain agent output formats:
    - LangGraph: ``{"messages": [HumanMessage, AIMessage("text"), ...]}``
    - AgentExecutor: ``{"output": "text"}``
    - Plain strings or message objects.
    """
    if isinstance(event, str):
        return event

    if hasattr(event, "content"):
        content = event.content
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            return " ".join(p if isinstance(p, str) else p.get("text", "") for p in content)
        return str(content)

    if isinstance(event, dict):
        # LangGraph state with messages list
        if "messages" in event:
            msgs = event["messages"]
            if msgs:
                last = msgs[-1]
                return _extract_agent_text(last)
        # AgentExecutor output key
        if "output" in event:
            return str(event["output"])

    return ""


class LangChainTranslator(Translator):
    """
    A :class:`~.translators.base.Translator` implementation for LangChain.

    Supports two modes, auto-detected based on the input type:

    **ChatModel mode** (e.g., ``ChatOpenAI``, ``ChatAnthropic``):
    - Streams responses via ``astream`` / ``stream``
    - Attaches tools via ``bind_tools``
    - Forwards tool call *requests* to LiveKit (tool execution is external)

    **Agent mode** (e.g., ``AgentExecutor``, LangGraph compiled graph):
    - Streams the agent's execution via ``astream``
    - Tools are managed internally by the agent
    - Forwards only the final text output to LiveKit

    The translator maintains its own message history internally, syncing back
    to LiveKit's ChatContext after each turn.
    """

    def __init__(
        self,
        llm: Any,
        *,
        system_prompt: str = "You are a helpful assistant.",
        model_kwargs: dict[str, Any] | None = None,
    ) -> None:
        """
        Args:
            llm: A LangChain ``ChatModel``, ``Runnable``, ``AgentExecutor``,
                or LangGraph compiled graph. Must support ``astream`` or ``invoke``.
            system_prompt: System prompt prepended to every conversation.
            model_kwargs: Additional keyword arguments passed to the LLM/agent
                on each call (e.g., ``{"temperature": 0.7}``).
        """
        super().__init__()
        self._llm = llm
        self._system_prompt = system_prompt
        self._model_kwargs = model_kwargs or {}
        self._messages: list[Any] = []
        self._current_ai_message: Any | None = None
        self._last_synced_count: int = 0
        self._is_agent: bool = not hasattr(llm, "bind_tools")

    def reset(self) -> None:
        """Reset LangChainTranslator state for a new session.

        Clears message history and sync offset so that a single translator
        instance can safely serve multiple :class:`AgentAdapter` sessions
        without cross-pollinating conversation history.
        """
        self._messages = []
        self._current_ai_message = None
        self._last_synced_count = 0

    async def to_external_chat_ctx(self, chat_ctx: llm.ChatContext) -> Any:
        """
        Convert a LiveKit ChatContext to LangChain's message format.

        Returns a list of LangChain ``BaseMessage`` objects.
        """
        try:
            from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
        except ImportError:
            logger.warning("langchain-core not installed; chat context conversion may not work")
            return []

        messages: list[Any] = []

        if self._system_prompt:
            messages.append(SystemMessage(content=self._system_prompt))

        for item in chat_ctx.items:
            if isinstance(item, llm.ChatMessage):
                role = item.role
                text = item.text_content or ""
                if not text:
                    continue

                if role in ("user", "human"):
                    messages.append(HumanMessage(content=text))
                elif role in ("assistant", "ai", "agent"):
                    messages.append(AIMessage(content=text))
                elif role == "system":
                    messages.append(SystemMessage(content=text))

            elif hasattr(item, "arguments"):
                args_str = getattr(item, "arguments", "{}")
                try:
                    args = json.loads(args_str)
                except Exception:
                    args = args_str
                name = getattr(item, "name", "")
                messages.append(AIMessage(content=f"[tool call: {name}({args})]"))

            elif hasattr(item, "output"):
                msg_output = getattr(item, "output", "")
                msg_call_id = getattr(item, "call_id", "unknown")
                messages.append(ToolMessage(content=str(msg_output), tool_call_id=msg_call_id))

        self._messages = messages
        return messages

    async def to_external_tools(self, tools: list[llm.Tool]) -> Any:
        """Convert LiveKit tools to LangChain tool dict format."""
        return build_tools_dict(tools)

    async def invoke(self, chat_ctx: Any, tools: Any) -> Any:
        """
        Invoke the LangChain LLM or agent with streaming.

        In **ChatModel** mode, streams via ``astream`` / ``stream`` and yields
        ``TextChunk`` for text tokens and ``ToolCall`` for tool requests.

        In **Agent** mode, streams via ``astream`` and extracts text from the
        agent's output. Tool execution is handled internally by the agent.

        Yields:
            :class:`~.types.TextChunk` for text content,
            :class:`~.types.ToolCall` for tool call requests (ChatModel mode only),
            and a final :class:`~.types.Done`.
        """
        if self._is_agent:
            async for item in self._invoke_agent(chat_ctx, tools):
                yield item
        else:
            async for item in self._invoke_chat_model(chat_ctx, tools):
                yield item

    async def _invoke_chat_model(self, chat_ctx: Any, tools: Any) -> Any:
        """ChatModel streaming path."""
        llm_model = self._llm
        kwargs = {**self._model_kwargs}

        if tools:
            if hasattr(llm_model, "bind_tools"):
                llm_model = llm_model.bind_tools(tools)
            elif hasattr(llm_model, "with_config"):
                llm_model = llm_model.with_config(configurable={"tools": tools})

        runnable = llm_model
        accumulated_chunks: list[Any] = []

        try:
            if hasattr(runnable, "astream"):
                async for chunk in runnable.astream(chat_ctx, **kwargs):
                    accumulated_chunks.append(chunk)
                    for item in _handle_chunk(chunk):
                        yield item
            elif hasattr(runnable, "stream"):
                # Collect the sync stream in a thread to avoid blocking the event loop.
                # This sacrifices per-chunk streaming in favour of safety; implement
                # astream on the runnable for true token-level streaming.
                def _collect_stream() -> list[Any]:
                    return list(runnable.stream(chat_ctx, **kwargs))

                chunks = await asyncio.to_thread(_collect_stream)
                for chunk in chunks:
                    accumulated_chunks.append(chunk)
                    for item in _handle_chunk(chunk):
                        yield item
            else:
                result = await asyncio.to_thread(runnable.invoke, chat_ctx, **kwargs)
                accumulated_chunks.append(result)
                for item in _handle_chunk(result):
                    yield item
        except Exception as e:
            logger.error("LangChain invoke failed: %s", e, exc_info=True)
            yield TextChunk(content=f"[Error: {e}]", is_final=True)
            yield Done(metadata={"error": str(e)})
            return

        combined = None
        for chunk in accumulated_chunks:
            if combined is None:
                combined = chunk
            elif hasattr(combined, "__add__"):
                try:
                    combined = combined + chunk
                except Exception:
                    pass

        self._current_ai_message = combined
        yield Done(metadata={})

    async def _invoke_agent(self, chat_ctx: Any, tools: Any) -> Any:
        """Agent streaming path (AgentExecutor, LangGraph, etc.)."""
        agent = self._llm
        kwargs = {**self._model_kwargs}

        # Wrap messages for LangGraph-style agents that expect {"messages": [...]}
        agent_input = chat_ctx
        if isinstance(chat_ctx, list) and hasattr(agent, "get_graph"):
            agent_input = {"messages": chat_ctx}

        collected_text: str = ""

        try:
            if hasattr(agent, "astream"):
                async for event in agent.astream(agent_input, **kwargs):
                    text = _extract_agent_text(event)
                    if text:
                        collected_text += text
                        yield TextChunk(content=text, is_final=False)
            elif hasattr(agent, "invoke"):
                result = await asyncio.to_thread(agent.invoke, agent_input, **kwargs)
                text = _extract_agent_text(result)
                if text:
                    collected_text += text
                    yield TextChunk(content=text, is_final=False)
        except Exception as e:
            logger.error("LangChain agent invoke failed: %s", e, exc_info=True)
            yield TextChunk(content=f"[Error: {e}]", is_final=True)
            yield Done(metadata={"error": str(e)})
            return

        self._current_ai_message = collected_text
        if collected_text:
            try:
                from langchain_core.messages import AIMessage

                self._messages.append(AIMessage(content=collected_text))
            except ImportError:
                pass
        yield Done(metadata={})

    async def sync_back_messages(self, chat_ctx: llm.ChatContext) -> list[Any]:
        """
        Sync LangChain's message history back to LiveKit ChatContext.

        Only messages from the last-synced turn boundary onward are collected,
        preventing duplicate entries across turns.

        Returns a list of LiveKit ``ChatItem`` objects for the adapter to insert.
        """
        try:
            from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
        except ImportError:
            return []

        from livekit.agents.llm.chat_context import FunctionCall, FunctionCallOutput

        new_items: list[Any] = []

        for msg in self._messages[self._last_synced_count :]:
            if isinstance(msg, HumanMessage):
                text = self._get_message_text(msg)
                if text:
                    new_items.append(llm.ChatMessage(role="user", content=[text]))
            elif isinstance(msg, AIMessage):
                text = self._get_message_text(msg)
                if text:
                    new_items.append(llm.ChatMessage(role="assistant", content=[text]))
                if hasattr(msg, "tool_calls") and msg.tool_calls:
                    for tc in msg.tool_calls:
                        args = getattr(tc, "args", getattr(tc, "input", {}))
                        if isinstance(args, str):
                            try:
                                args = json.loads(args)
                            except Exception:
                                pass
                        new_items.append(
                            FunctionCall(
                                call_id=getattr(tc, "id", ""),
                                name=getattr(tc, "name", ""),
                                arguments=json.dumps(args) if isinstance(args, dict) else str(args),
                            )
                        )
            elif isinstance(msg, ToolMessage):
                new_items.append(
                    FunctionCallOutput(
                        call_id=msg.tool_call_id or "",
                        output=str(msg.content),
                        is_error=False,
                    )
                )
                # Note: LangChain's ToolMessage does not carry an is_error field,
                # so error status from failed tool calls cannot be propagated here.
                # If your LangChain agent tracks tool errors in a custom attribute
                # (e.g. msg.extra), map it in a subclass override of sync_back_messages.

        self._last_synced_count = len(self._messages)
        return new_items

    def _get_message_text(self, msg: Any) -> str:
        content = getattr(msg, "content", "")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            return " ".join(
                part if isinstance(part, str) else part.get("text", "") for part in content
            )
        return str(content)
