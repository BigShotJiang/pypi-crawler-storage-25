# LiveKit Agents Adapter — LangChain Translator

A LangChain translator plugin for [livekit-agents-adapter](https://github.com/guttume/livekit_agents_adapter).

Provides `LangChainTranslator` for bridging LangChain ChatModels and agents
(AgentExecutor, LangGraph) to the LiveKit Agent runtime.
