"""Publishing utilities for test_publish package."""

import logging
from typing import Optional

logger = logging.getLogger(__name__)


def publish_artifact(name: str, version: str, registry: Optional[str] = None) -> dict:
    """Publish an artifact to the specified registry.

    Args:
        name: Artifact name.
        version: Semantic version string.
        registry: Target registry URL. Defaults to PyPI.

    Returns:
        dict with publish status and metadata.
    """
    if not name:
        raise ValueError("Artifact name is required")

    if not version:
        raise ValueError("Version is required")

    registry = registry or "https://pypi.org"

    logger.info("Publishing %s@%s to %s", name, version, registry)

    return {
        "name": name,
        "version": version,
        "registry": registry,
        "status": "published",
    }


def validate_version(version: str) -> bool:
    """Check if a version string follows semver format (X.Y.Z)."""
    parts = version.split(".")
    if len(parts) != 3:
        return False
    return all(p.isdigit() for p in parts)


def bump_version(version: str, part: str = "patch") -> str:
    """Bump a semver version string.

    Args:
        version: Current version in X.Y.Z format.
        part: Which part to bump — 'major', 'minor', or 'patch'.

    Returns:
        New version string with the specified part incremented.
    """
    if not validate_version(version):
        raise ValueError(f"Invalid version format: {version}")

    major, minor, patch = (int(p) for p in version.split("."))

    if part == "major":
        return f"{major + 1}.0.0"
    elif part == "minor":
        return f"{major}.{minor + 1}.0"
    else:
        return f"{major}.{minor}.{patch + 1}"
