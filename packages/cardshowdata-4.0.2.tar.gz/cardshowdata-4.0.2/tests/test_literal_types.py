"""Tests for SDK 4.0.1 literal-union narrowing.

Verifies the five enum-typed fields documented in pricing-v4-plan.md §6.1 are
emitted as `typing.Literal[...]` instead of plain `str`. We assert via
`get_type_hints` (runtime introspection) so the suite passes without an extra
mypy install.

Backward-compat contract: any 4.0.0 caller that already used valid enum values
must continue to work unchanged. The narrowing is additive — invalid strings
that previously type-checked will now be rejected by mypy/Pyright at the call
site, which is the autocomplete win for 4.0.1.
"""

from __future__ import annotations

from typing import Literal, Union, get_args, get_type_hints, get_origin
from types import UnionType

from cardshowdata.models.cards import (
    EbaySale,
    GradedListing,
    GradedRecentSale,
    RawPriceRow,
    RecentSale,
    RecommendedSellPerVertical,
)
from cardshowdata.models.pricing import (
    PriceChange,
    PricingHistoryEntry,
    VariantPricingHistory,
)


def _literal_args(annotation) -> tuple[str, ...]:
    """Extract the concrete string values from a Literal[...] annotation,
    handling `Literal[...] | None` unions transparently."""
    origin = get_origin(annotation)
    if origin is UnionType or origin is Union:
        for arg in get_args(annotation):
            if get_origin(arg) is Literal:
                return get_args(arg)
        raise AssertionError(f"No Literal in union {annotation}")
    if origin is Literal:
        return get_args(annotation)
    raise AssertionError(f"Annotation {annotation!r} is not a Literal")


# ── condition: "NM" | "LP" | "MP" | "HP" | "DMG" ────────────────────────────

def test_raw_price_row_condition_is_literal() -> None:
    hints = get_type_hints(RawPriceRow)
    assert _literal_args(hints["condition"]) == ("NM", "LP", "MP", "HP", "DMG")


def test_pricing_history_entry_condition_is_literal() -> None:
    hints = get_type_hints(PricingHistoryEntry)
    assert _literal_args(hints["condition"]) == ("NM", "LP", "MP", "HP", "DMG")


def test_variant_pricing_history_condition_is_literal() -> None:
    hints = get_type_hints(VariantPricingHistory)
    assert _literal_args(hints["condition"]) == ("NM", "LP", "MP", "HP", "DMG")


def test_price_change_condition_is_nullable_literal() -> None:
    hints = get_type_hints(PriceChange)
    ann = hints["condition"]
    # Literal[...] | None
    assert get_origin(ann) in (UnionType, Union)
    assert type(None) in get_args(ann)
    assert _literal_args(ann) == ("NM", "LP", "MP", "HP", "DMG")


# ── currency: "USD" | "EUR" ─────────────────────────────────────────────────

def test_raw_price_row_currency_is_literal() -> None:
    assert _literal_args(get_type_hints(RawPriceRow)["currency"]) == ("USD", "EUR")


def test_recent_sale_currency_is_literal() -> None:
    assert _literal_args(get_type_hints(RecentSale)["currency"]) == ("USD", "EUR")


def test_graded_listing_currency_is_literal() -> None:
    assert _literal_args(get_type_hints(GradedListing)["currency"]) == ("USD", "EUR")


def test_graded_recent_sale_currency_is_literal() -> None:
    assert _literal_args(get_type_hints(GradedRecentSale)["currency"]) == ("USD", "EUR")


def test_ebay_sale_currency_is_nullable_literal() -> None:
    ann = get_type_hints(EbaySale)["currency"]
    assert type(None) in get_args(ann)
    assert _literal_args(ann) == ("USD", "EUR")


# ── vertical: "online" | "show" | "lcs" (nullable) ──────────────────────────

def test_price_change_vertical_is_nullable_literal() -> None:
    ann = get_type_hints(PriceChange)["vertical"]
    assert type(None) in get_args(ann)
    assert _literal_args(ann) == ("online", "show", "lcs")


# ── approach: 6-value enum (nullable) ───────────────────────────────────────

def test_recommended_sell_approach_is_nullable_literal() -> None:
    ann = get_type_hints(RecommendedSellPerVertical)["approach"]
    assert type(None) in get_args(ann)
    assert _literal_args(ann) == (
        "show_sales",
        "lcs_sales",
        "card_show_sales",
        "retail_blend",
        "fair_value_spread",
        "fair_value_only",
    )


# ── lifecycle_state: 4-value enum (nullable) ────────────────────────────────

def test_recommended_sell_lifecycle_state_is_nullable_literal() -> None:
    ann = get_type_hints(RecommendedSellPerVertical)["lifecycle_state"]
    assert type(None) in get_args(ann)
    assert _literal_args(ann) == ("rising", "stable", "declining", "peak_risk")


def test_pricing_history_lifecycle_state_is_nullable_literal() -> None:
    ann = get_type_hints(PricingHistoryEntry)["lifecycle_state"]
    assert type(None) in get_args(ann)
    assert _literal_args(ann) == ("rising", "stable", "declining", "peak_risk")


# ── Backward-compat smoke: parsing valid 4.0.0 payloads still works ─────────

def test_raw_price_row_from_dict_with_valid_enum_values() -> None:
    """Any 4.0.0 caller that already uses valid enum values must keep working."""
    row = RawPriceRow.from_dict({
        "condition": "NM",
        "currency": "USD",
        "snapshot_date": "2026-04-12",
        "reference_prices": None,
        "recommended_sell": None,
        "recent_sales": None,
    })
    assert row.condition == "NM"
    assert row.currency == "USD"


def test_raw_price_row_from_dict_uses_safe_default_when_currency_missing() -> None:
    """Default `"USD"` must satisfy the Literal["USD","EUR"] type."""
    row = RawPriceRow.from_dict({
        "condition": "LP",
        "snapshot_date": "2026-04-12",
        "reference_prices": None,
        "recommended_sell": None,
        "recent_sales": None,
    })
    assert row.condition == "LP"
    assert row.currency == "USD"  # fallback default
