"""Tests for the Catalog resource."""

import httpx
import pytest

from cardshowdata import AsyncCardShowData


TCGS = [
    {"tcg_slug": "pk", "tcg_name": "Pokemon", "product_count": 50000, "set_count": 150},
    {"tcg_slug": "mtg", "tcg_name": "Magic: The Gathering", "product_count": 80000, "set_count": 300},
]

SETS = [
    {"tcg_slug": "pk", "set_code": "bs", "set_name": "Base Set", "release_date": "1999-01-09", "product_count": 102},
]

TAXONOMY = {
    "tcg_slug": "pk",
    "supertypes": [{"name": "Pokemon", "count": 40000}],
    "subtypes": [{"name": "Stage 2", "count": 5000}],
    "types": [{"name": "Fire", "count": 3000}],
}

PRODUCT = {
    "csd_product_id": "aaaa-bbbb",
    "tcg_slug": "pk",
    "tcg_name": "Pokemon",
    "set_code": "bs",
    "set_name": "Base Set",
    "release_date": "1999-01-09",
    "product_type": "raw_card",
    "product_name": "Charizard",
    "clean_name": "charizard",
    "card_number": "4/102",
    "variant": "holofoil",
    "rarity": "Rare Holo",
    "language": "English",
    "pretty_id": "pk_bs_004",
    "image_url": "https://images.cardshowdata.com/aaaa-bbbb.jpg",
    "is_active": True,
    "updated_at": "2026-04-12T10:30:00Z",
}


class TestCatalog:
    def test_list_tcgs(self, mock_api, client):
        mock_api.get("/v1/catalog/tcgs").mock(
            return_value=httpx.Response(200, json=TCGS)
        )
        tcgs = client.catalog.list_tcgs()
        assert len(tcgs) == 2
        assert tcgs[0].tcg_slug == "pk"
        assert tcgs[0].product_count == 50000

    def test_list_sets(self, mock_api, client):
        mock_api.get("/v1/catalog/pk/sets").mock(
            return_value=httpx.Response(200, json=SETS)
        )
        sets = client.catalog.list_sets("pk")
        assert len(sets) == 1
        assert sets[0].set_code == "bs"
        assert sets[0].release_date == "1999-01-09"

    def test_get_taxonomy(self, mock_api, client):
        mock_api.get("/v1/catalog/pk/taxonomy").mock(
            return_value=httpx.Response(200, json=TAXONOMY)
        )
        tax = client.catalog.get_taxonomy("pk")
        assert tax.tcg_slug == "pk"
        assert tax.supertypes[0].name == "Pokemon"
        assert tax.types[0].count == 3000

    def test_list_products(self, mock_api, client):
        mock_api.get("/v1/catalog/pk/products").mock(
            return_value=httpx.Response(200, json={
                "items": [PRODUCT],
                "next_cursor": None,
                "count": 1,
            })
        )
        page = client.catalog.list_products("pk")
        assert len(page.items) == 1
        assert page.items[0].product_name == "Charizard"
        assert page.items[0].pretty_id == "pk_bs_004"

    def test_list_products_with_filters(self, mock_api, client):
        route = mock_api.get("/v1/catalog/pk/products").mock(
            return_value=httpx.Response(200, json={"items": [], "next_cursor": None, "count": 0})
        )
        client.catalog.list_products("pk", updated_since="2026-04-01", set_code="bs")
        url = str(route.calls[0].request.url)
        assert "updated_since" in url
        assert "set_code=bs" in url

    def test_export_csv(self, mock_api, client):
        csv_content = b"csd_product_id,pretty_id,product_name\naaaa,pk_bs_004,Charizard\n"
        mock_api.get("/v1/catalog/pk/products.csv").mock(
            return_value=httpx.Response(200, content=csv_content)
        )
        result = client.catalog.export_csv("pk")
        assert result == csv_content

    def test_resolve(self, mock_api, client):
        route = mock_api.post("/v1/catalog/resolve").mock(
            return_value=httpx.Response(200, json=[
                {"pretty_id": "pk_bs_004", "csd_product_id": "aaaa-bbbb", "tcg_slug": "pk", "set_code": "bs", "card_number": "4/102", "variant": "holofoil", "product_name": "Charizard"},
            ])
        )
        results = client.catalog.resolve(["pk_bs_004"])
        assert len(results) == 1
        assert results[0].csd_product_id == "aaaa-bbbb"
        body = route.calls[0].request.read()
        assert b'"keys"' in body

    def test_search(self, mock_api, client):
        route = mock_api.get("/v1/catalog/search").mock(
            return_value=httpx.Response(200, json={"items": [PRODUCT]})
        )
        results = client.catalog.search(q="charizard", tcg_slug="pk")
        assert len(results) == 1
        assert results[0].product_name == "Charizard"
        url = str(route.calls[0].request.url)
        assert "q=charizard" in url

    def test_list_products_filter_product_type(self, mock_api, client):
        route = mock_api.get("/v1/catalog/pk/products").mock(
            return_value=httpx.Response(200, json={"items": [], "next_cursor": None, "count": 0})
        )
        client.catalog.list_products("pk", product_type="booster_box")
        url = str(route.calls[0].request.url)
        assert "product_type=booster_box" in url

    def test_search_filter_product_type(self, mock_api, client):
        route = mock_api.get("/v1/catalog/search").mock(
            return_value=httpx.Response(200, json={"items": []})
        )
        client.catalog.search(q="booster", product_type="booster_box")
        url = str(route.calls[0].request.url)
        assert "product_type=booster_box" in url

    def test_export_csv_filter_product_type(self, mock_api, client):
        route = mock_api.get("/v1/catalog/pk/products.csv").mock(
            return_value=httpx.Response(200, content=b"")
        )
        client.catalog.export_csv("pk", product_type="elite_trainer_box")
        url = str(route.calls[0].request.url)
        assert "product_type=elite_trainer_box" in url

    @pytest.mark.asyncio
    async def test_async_list_tcgs(self, mock_api):
        mock_api.get("/v1/catalog/tcgs").mock(
            return_value=httpx.Response(200, json=TCGS)
        )
        async with AsyncCardShowData(api_key="test_key_123") as c:
            tcgs = await c.catalog.list_tcgs()
            assert len(tcgs) == 2
