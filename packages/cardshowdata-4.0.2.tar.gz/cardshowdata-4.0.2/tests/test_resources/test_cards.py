"""Tests for the Cards resource — v4 response shape."""

import httpx
import pytest

from cardshowdata import AsyncCardShowData


# v4 shape: variants[].raw[] keyed by (condition, currency); per-vertical
# recommended_sell + recent_sales; per-grader graded blocks.
CARD_RESPONSE = {
    "id": "pk_bs_004_holofoil",
    "csd_product_id": "aaaa-bbbb-cccc",
    "tcg": "pk",
    "name": "Charizard",
    "number": "4/102",
    "printed_number": "4",
    "rarity": "Rare Holo",
    "rarity_code": "RH",
    "artist": "Mitsuhiro Arita",
    "language": "English",
    "language_code": "en",
    "image": "https://images.cardshowdata.com/aaaa-bbbb-cccc.jpg",
    "tcgplayer_url": "https://tcgplayer.com/...",
    "cardmarket_url": None,
    "expansion": {
        "id": "pk_bs",
        "name": "Base Set",
        "series": "Base",
        "code": "bs",
        "release_date": "1999-01-09",
    },
    "variants": [
        {
            "name": "holofoil",
            "image": None,
            "raw": [
                {
                    "condition": "NM",
                    "currency": "USD",
                    "snapshot_date": "2026-05-02",
                    "reference_prices": {
                        "market_cents": 50000,
                        "low_cents": 40000,
                        "mid_cents": 48000,
                        "high_cents": 60000,
                    },
                    "recommended_sell": {
                        "online": {
                            "price_cents": 45000,
                            "approach": "retail_blend",
                            "confidence": 0.85,
                            "sales_count": 3,
                            "lifecycle_state": "declining",
                            "adjustment_pct": -5.0,
                        },
                        "show": {
                            "price_cents": 47000,
                            "approach": "fair_value_spread",
                            "confidence": 0.7,
                            "sales_count": 0,
                            "lifecycle_state": "declining",
                            "adjustment_pct": 0.0,
                        },
                        "lcs": {
                            "price_cents": 46000,
                            "approach": "fair_value_spread",
                            "confidence": 0.7,
                            "sales_count": 0,
                            "lifecycle_state": "declining",
                            "adjustment_pct": 0.0,
                        },
                    },
                    "recent_sales": {
                        "online": [
                            {
                                "currency": "USD",
                                "price_cents": 48500,
                                "sold_at": "2026-04-22",
                                "source": "ebay",
                                "listing_url": "https://ebay.com/itm/123",
                            }
                        ],
                        "show": [
                            {
                                "currency": "USD",
                                "price_cents": 47000,
                                "sold_at": "2026-05-02",
                                "event": {
                                    "show_name": "Dallas Card Show",
                                    "start_date": "2026-04-24",
                                    "end_date": "2026-04-26",
                                    "region": "southwest",
                                    "zipcode": "75013",
                                },
                            }
                        ],
                        "lcs": [],
                    },
                }
            ],
            "graded": {
                "psa": {
                    "population": {
                        "grades": {"10": 1524, "9": 892},
                        "total": 2416,
                        "as_of": "2026-04-16T09:30:00Z",
                    },
                    "current_listings": [
                        {
                            "grade": "10",
                            "currency": "USD",
                            "market_cents": 800000,
                            "snapshot_date": "2026-05-02",
                            "listing_url": "https://example.com/listing/1",
                        }
                    ],
                    "recent_sales": [
                        {
                            "grade": "10",
                            "currency": "USD",
                            "price_cents": 750000,
                            "sold_at": "2026-04-22",
                            "source": "ebay",
                            "listing_url": "https://ebay.com/itm/777",
                        }
                    ],
                }
            },
        }
    ],
}

EBAY_RESPONSE = {
    "sales": [
        {
            "price_cents": 120000,
            "shipping_price_cents": 500,
            "currency": "USD",
            "format": "auction",
            "sold_at": "2026-04-10T12:00:00Z",
            "ebay_url": "https://ebay.com/...",
            "title": "PSA 10 Charizard Base Set",
        }
    ],
    "source": "db",
    "cached": True,
}


class TestCards:
    def test_get_by_pretty_id(self, mock_api, client):
        route = mock_api.get("/v1/cards/pk_bs_004_holofoil").mock(
            return_value=httpx.Response(200, json=CARD_RESPONSE)
        )
        card = client.cards.get("pk_bs_004_holofoil")
        assert card.name == "Charizard"
        assert card.csd_product_id == "aaaa-bbbb-cccc"
        assert card.image == "https://images.cardshowdata.com/aaaa-bbbb-cccc.jpg"
        assert card.expansion.name == "Base Set"
        assert card.expansion.release_date == "1999-01-09"
        assert len(card.variants) == 1
        variant = card.variants[0]
        assert variant.name == "holofoil"
        assert variant.image is None

        # v4: raw[] keyed by (condition, currency)
        assert len(variant.raw) == 1
        row = variant.raw[0]
        assert row.condition == "NM"
        assert row.currency == "USD"
        assert row.snapshot_date == "2026-05-02"

        # reference_prices block
        assert row.reference_prices.market_cents == 50000
        assert row.reference_prices.high_cents == 60000

        # per-vertical recommended_sell
        assert row.recommended_sell.online.price_cents == 45000
        assert row.recommended_sell.online.approach == "retail_blend"
        assert row.recommended_sell.online.sales_count == 3
        assert row.recommended_sell.show.approach == "fair_value_spread"
        assert row.recommended_sell.lcs.approach == "fair_value_spread"

        # per-vertical recent_sales
        assert len(row.recent_sales.online) == 1
        assert row.recent_sales.online[0].source == "ebay"
        assert len(row.recent_sales.show) == 1
        assert row.recent_sales.show[0].event.show_name == "Dallas Card Show"
        assert row.recent_sales.show[0].event.region == "southwest"
        assert row.recent_sales.lcs == []

        # graded keyed by grader
        assert "psa" in variant.graded
        psa = variant.graded["psa"]
        assert psa.population.grades["10"] == 1524
        assert psa.population.total == 2416
        assert psa.population.as_of == "2026-04-16T09:30:00Z"
        assert len(psa.current_listings) == 1
        assert psa.current_listings[0].grade == "10"
        assert psa.current_listings[0].market_cents == 800000
        assert len(psa.recent_sales) == 1
        assert psa.recent_sales[0].price_cents == 750000

    def test_get_with_include(self, mock_api, client):
        route = mock_api.get("/v1/cards/pk_bs_004_holofoil").mock(
            return_value=httpx.Response(200, json={**CARD_RESPONSE, "details": {"supertype": "Pokemon"}})
        )
        card = client.cards.get("pk_bs_004_holofoil", include=["details", "trends"])
        assert "include" in str(route.calls[0].request.url)
        assert card.details["supertype"] == "Pokemon"

    def test_get_with_recent_sales_limit(self, mock_api, client):
        route = mock_api.get("/v1/cards/pk_bs_004_holofoil").mock(
            return_value=httpx.Response(200, json=CARD_RESPONSE)
        )
        card = client.cards.get("pk_bs_004_holofoil", recent_sales_limit=20)
        url = str(route.calls[0].request.url)
        assert "recent_sales_limit=20" in url

    def test_search(self, mock_api, client):
        route = mock_api.get("/v1/cards").mock(
            return_value=httpx.Response(200, json={
                "data": [CARD_RESPONSE],
                "pagination": {"page": 1, "page_size": 50, "total_count": 1, "total_pages": 1, "next_href": None, "prev_href": None},
            })
        )
        page = client.cards.search(tcg="pk", q="name:charizard")
        assert len(page.data) == 1
        assert page.data[0].name == "Charizard"
        url = str(route.calls[0].request.url)
        assert "tcg=pk" in url
        assert "name%3Acharizard" in url or "name:charizard" in url

    def test_list_by_expansion(self, mock_api, client):
        route = mock_api.get("/v1/expansions/pk_bs/cards").mock(
            return_value=httpx.Response(200, json={
                "data": [CARD_RESPONSE],
                "pagination": {"page": 1, "page_size": 50, "total_count": 1, "total_pages": 1, "next_href": None, "prev_href": None},
            })
        )
        page = client.cards.list_by_expansion("pk_bs")
        assert len(page.data) == 1

    def test_get_ebay_sales(self, mock_api, client):
        route = mock_api.get("/v1/cards/pk_bs_004_holofoil/ebay-sales").mock(
            return_value=httpx.Response(200, json=EBAY_RESPONSE)
        )
        result = client.cards.get_ebay_sales("pk_bs_004_holofoil", company="PSA", grade="10")
        assert len(result.sales) == 1
        assert result.sales[0].price_cents == 120000
        assert result.source == "db"
        assert result.cached is True
        url = str(route.calls[0].request.url)
        assert "company=PSA" in url
        assert "grade=10" in url

    @pytest.mark.asyncio
    async def test_async_get(self, mock_api):
        mock_api.get("/v1/cards/pk_bs_004_holofoil").mock(
            return_value=httpx.Response(200, json=CARD_RESPONSE)
        )
        async with AsyncCardShowData(api_key="test_key_123") as c:
            card = await c.cards.get("pk_bs_004_holofoil")
            assert card.name == "Charizard"
