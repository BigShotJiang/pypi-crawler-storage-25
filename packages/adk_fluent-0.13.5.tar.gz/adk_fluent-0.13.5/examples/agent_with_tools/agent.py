"""
Travel Planner with Weather and Flight Lookup -- Agent with Tools

Demonstrates attaching function tools to an agent.  The scenario:
a travel planning assistant that can look up weather forecasts and
search for flights to help users plan trips.

Converted from cookbook example: 02_agent_with_tools.py

Usage:
    cd examples
    adk web agent_with_tools
"""


# --- Tools & Callbacks ---


def check_weather(city: str, date: str) -> str:
    """Check the weather forecast for a city on a given date."""
    return f"Forecast for {city} on {date}: 24C, partly cloudy"


def search_flights(origin: str, destination: str, date: str) -> str:
    """Search available flights between two cities on a date."""
    return f"Found 3 flights from {origin} to {destination} on {date}, starting at $299"


from adk_fluent import Agent
from dotenv import load_dotenv

load_dotenv()  # loads .env from examples/ (copy .env.example -> .env)

agent_fluent = (
    Agent("travel_planner")
    .model("gemini-2.5-flash")
    .instruct(
        "You are a travel planning assistant. Help users plan trips by "
        "checking weather forecasts and searching for flights. Always "
        "check the weather at the destination before recommending flights."
    )
    .tool(check_weather)
    .tool(search_flights)
    .build()
)

root_agent = agent_fluent
