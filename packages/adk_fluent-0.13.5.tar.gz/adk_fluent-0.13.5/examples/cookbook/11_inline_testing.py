"""Smoke-Testing a Customer Support Bot -- Inline Testing with .test()

Demonstrates the .test() method for validating agent behavior during
development.  The scenario: a customer support bot that is
smoke-tested inline before deployment to ensure it handles common
queries correctly.  No LLM calls are made here -- we verify that
the builder exposes the test API with the right signature.
"""

# --- NATIVE ---
# Native ADK has no inline testing. You must write separate test files
# with full Runner/Session setup for each agent test case.

# --- FLUENT ---
from adk_fluent import Agent

# In production, you chain tests directly into the agent definition:
# agent = (
#     Agent("support_bot")
#     .model("gemini-2.5-flash")
#     .instruct("You are a customer support agent for an e-commerce platform.")
#     .test("How do I return an item?", contains="return")
#     .test("What is your refund policy?", contains="refund")
#     .test("Track my order #12345", contains="order")
#     .build()
# )

builder = (
    Agent("support_bot")
    .model("gemini-2.5-flash")
    .instruct(
        "You are a customer support agent for an e-commerce platform. "
        "Handle returns, refunds, order tracking, and general inquiries. "
        "Always be polite and offer to escalate to a human if needed."
    )
)

# --- ASSERT ---
assert hasattr(builder, "test")
assert callable(builder.test)
import inspect

sig = inspect.signature(builder.test)
assert "prompt" in sig.parameters
assert "contains" in sig.parameters
assert "matches" in sig.parameters
assert "equals" in sig.parameters

# E module eval integration
assert hasattr(builder, "eval")
assert hasattr(builder, "eval_suite")

from adk_fluent._eval import EvalSuite

suite = builder.eval("What is your return policy?", expect="return")
assert isinstance(suite, EvalSuite)
assert len(suite._cases) == 1

suite2 = builder.eval_suite()
assert isinstance(suite2, EvalSuite)
