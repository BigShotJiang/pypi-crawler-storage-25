from pathlib import Path
import runpy
import sys


def main():
    package_dir = Path(__file__).resolve().parent / "MODULE_TWO"
    app_path = package_dir / "module4-8-26.py"

    if not app_path.exists():
        raise FileNotFoundError(f"Could not find app launcher: {app_path}")

    if str(package_dir) not in sys.path:
        sys.path.insert(0, str(package_dir))

    runpy.run_path(str(app_path), run_name="__main__")


if __name__ == "__main__":
    main()
