import json
import os
import time


def get_barograph_history_path(path=None):
    return path or os.path.expanduser("~/barograph_history.json")


def load_barograph_history(datetime_cls, path=None):
    history_path = get_barograph_history_path(path)
    xs = []
    ys = []

    try:
        if os.path.exists(history_path):
            with open(history_path, "r") as history_file:
                loaded_data = json.load(history_file)

            loaded_xs = loaded_data.get("xs", [])
            loaded_ys = loaded_data.get("ys", [])

            if isinstance(loaded_xs, list) and isinstance(loaded_ys, list):
                for x_value, y_value in zip(loaded_xs, loaded_ys):
                    try:
                        xs.append(datetime_cls.fromisoformat(x_value))
                        ys.append(y_value)
                    except Exception:
                        continue

                if xs:
                    print(f"Loaded {len(xs)} persisted barograph points.")
    except Exception as e:
        print(f"Error loading barograph history: {e}")

    return xs, ys


def save_barograph_history(xs, ys, path=None):
    history_path = get_barograph_history_path(path)
    data_to_save = {
        "xs": [x.isoformat() if hasattr(x, "isoformat") else str(x) for x in xs],
        "ys": ys,
    }

    try:
        with open(history_path, "w") as history_file:
            json.dump(data_to_save, history_file)
    except Exception as e:
        print(f"Error saving barograph history: {e}")


def read_barograph_sample(i, bus, baro_input, inhg_correction_factor):
    bus.write_byte(0x77, 0x44 | 0x00)
    time.sleep(0.5)

    data = bus.read_i2c_block_data(0x77, 0x10, 6)

    c_temp = (((data[0] & 0x0F) * 65536) + (data[1] * 256) + data[2]) / 100.00
    f_temp = (c_temp * 1.8) + 32
    pressure = (((data[3] & 0x0F) * 65536) + (data[4] * 256) + data[5]) / 100.00
    corrected_pressure = pressure * 1.0058
    in_hg = corrected_pressure * 0.029529

    if i == 0:
        inhg_correction_factor = baro_input / in_hg

    in_hg = round(in_hg * inhg_correction_factor, 3)
    return {
        "in_hg": in_hg,
        "f_temp": f_temp,
        "inhg_correction_factor": inhg_correction_factor,
    }


def build_barograph_time_context(
    now,
    pandas_module,
    datetime_cls,
    timedelta_cls,
    mdates_module,
):
    date_time = pandas_module.to_datetime(now.strftime("%m/%d/%Y, %H:%M:%S"))
    threshold_left_x_value = mdates_module.date2num(datetime_cls.now() - timedelta_cls(days=2.4))
    threshold_right_x_value = mdates_module.date2num(datetime_cls.now() - timedelta_cls(days=0.125))

    yesterday_name = (now - timedelta_cls(days=1)).strftime("%A")
    before_yesterday_name = (now - timedelta_cls(days=2)).strftime("%A")

    midnight = datetime_cls.combine(date_time.date(), datetime_cls.min.time())
    x_value_12pm = mdates_module.date2num(midnight.replace(hour=12))
    x_value_yesterday = x_value_12pm - 1
    x_value_day_before = x_value_12pm - 2

    return {
        "now": now,
        "date_time": date_time,
        "threshold_left_x_value": threshold_left_x_value,
        "threshold_right_x_value": threshold_right_x_value,
        "yesterday_name": yesterday_name,
        "before_yesterday_name": before_yesterday_name,
        "x_value_12pm": x_value_12pm,
        "x_value_yesterday": x_value_yesterday,
        "x_value_day_before": x_value_day_before,
        "y_value_day_label": 30.90,
    }


def append_barograph_point(xs, ys, date_time, in_hg, max_points=1200):
    xs.append(date_time)
    ys.append(in_hg)
    return xs[-max_points:], ys[-max_points:]


def reset_midnight_annotation_flags(time_context, state, ax=None):
    reset_date = state.get("last_midnight_reset_date")
    current_date = time_context["now"].date()

    if (
        0 <= time_context["now"].hour < 1
        and 0 <= time_context["now"].minute <= 15
        and reset_date != current_date
    ):
        for key in ("yesterday_annotation", "before_yesterday_annotation"):
            annotation = state.get(key)
            if annotation is not None:
                try:
                    annotation.remove()
                except Exception:
                    pass
                state[key] = None

        if ax is not None:
            for attr_name in (
                "_day_label_annotation",
                "_day_2900_annotation",
                "_day_3050_annotation",
                "_day_3000_annotation",
                "_day_2950_annotation",
                "_yesterday_2900_annotation",
                "_yesterday_3050_annotation",
                "_yesterday_3000_annotation",
                "_yesterday_2950_annotation",
                "_bday_2900_annotation",
                "_bday_3050_annotation",
                "_bday_3000_annotation",
                "_bday_2950_annotation",
            ):
                annotation = getattr(ax, attr_name, None)
                if annotation is not None:
                    try:
                        annotation.remove()
                    except Exception:
                        pass
                    setattr(ax, attr_name, None)

        state["today_annotation_flag"] = False
        state["today_inhg_annotation_flag"] = False
        state["annotations_created"]["before_yesterday"] = False
        state["annotations_created"]["bday_3050"] = False
        state["annotations_created"]["bday_3000"] = False
        state["annotations_created"]["bday_2950"] = False
        state["last_midnight_reset_date"] = current_date
        time_context["yesterday_name"] = (time_context["date_time"] - state["timedelta_cls"](days=1)).strftime("%A")
        time_context["before_yesterday_name"] = (time_context["date_time"] - state["timedelta_cls"](days=2)).strftime("%A")


def replace_axis_annotation(ax, attr_name, *annotate_args, **annotate_kwargs):
    existing_annotation = getattr(ax, attr_name, None)
    if existing_annotation is not None:
        try:
            existing_annotation.remove()
        except Exception:
            pass

    new_annotation = ax.annotate(*annotate_args, **annotate_kwargs)
    setattr(ax, attr_name, new_annotation)
    return new_annotation


def update_barograph_annotations(ax, day_label, time_context, state):
    yesterday_annotation = state["yesterday_annotation"]
    before_yesterday_annotation = state["before_yesterday_annotation"]
    annotations_created = state["annotations_created"]
    today_annotation_flag = state["today_annotation_flag"]
    today_inhg_annotation_flag = state["today_inhg_annotation_flag"]

    day_label.set_text(time_context["date_time"].strftime("%A"))

    if time_context["x_value_12pm"] < time_context["threshold_right_x_value"] and not today_annotation_flag:
        replace_axis_annotation(
            ax,
            "_day_label_annotation",
            time_context["date_time"].strftime("%A"),
            (time_context["x_value_12pm"], time_context["y_value_day_label"]),
            ha="center",
            fontsize=10,
            fontstyle="italic",
            fontfamily="DejaVu Serif",
            fontweight="bold",
        )
        today_annotation_flag = True

    if time_context["x_value_12pm"] < time_context["threshold_right_x_value"] + 0.08 and not today_inhg_annotation_flag:
        replace_axis_annotation(ax, "_day_2900_annotation", "29.00", (time_context["x_value_12pm"] - 0.001, 28.975), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        replace_axis_annotation(ax, "_day_3050_annotation", "30.50", (time_context["x_value_12pm"] - 0.001, 30.475), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        replace_axis_annotation(ax, "_day_3000_annotation", "30.00", (time_context["x_value_12pm"] - 0.001, 29.975), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        replace_axis_annotation(ax, "_day_2950_annotation", "29.50", (time_context["x_value_12pm"] - 0.001, 29.475), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        today_inhg_annotation_flag = True

    if yesterday_annotation is None and time_context["x_value_yesterday"] < time_context["threshold_right_x_value"] + 0.2:
        yesterday_annotation = ax.annotate(
            time_context["yesterday_name"],
            xy=(time_context["x_value_yesterday"], time_context["y_value_day_label"]),
            xytext=(0, 0),
            textcoords="offset points",
            ha="center",
            fontsize=10,
            fontstyle="italic",
            fontfamily="DejaVu Serif",
            fontweight="bold",
            color="black",
        )
        replace_axis_annotation(ax, "_yesterday_2900_annotation", "29.00", (time_context["x_value_yesterday"] - 0.001, 28.975), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        replace_axis_annotation(ax, "_yesterday_3050_annotation", "30.50", (time_context["x_value_yesterday"] - 0.001, 30.475), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        replace_axis_annotation(ax, "_yesterday_3000_annotation", "30.00", (time_context["x_value_yesterday"] - 0.001, 29.975), ha="center", fontsize=10, fontfamily="DejaVu Serif")
        replace_axis_annotation(ax, "_yesterday_2950_annotation", "29.50", (time_context["x_value_yesterday"] - 0.001, 29.475), ha="center", fontsize=10, fontfamily="DejaVu Serif")

    if before_yesterday_annotation and time_context["x_value_day_before"] < time_context["threshold_left_x_value"]:
        before_yesterday_annotation.remove()
        before_yesterday_annotation = None
        annotations_created["before_yesterday"] = False

    if not annotations_created["before_yesterday"] and time_context["x_value_day_before"] > time_context["threshold_left_x_value"] + 0.044:
        if before_yesterday_annotation is None:
            before_yesterday_annotation = ax.annotate(
                time_context["before_yesterday_name"],
                xy=(time_context["x_value_day_before"], time_context["y_value_day_label"]),
                xytext=(0, 0),
                textcoords="offset points",
                ha="center",
                fontsize=10,
                fontstyle="italic",
                fontfamily="DejaVu Serif",
                fontweight="bold",
                color="black",
            )
            annotations_created["before_yesterday"] = True

    if time_context["x_value_day_before"] > time_context["threshold_left_x_value"] - 0.044:
        if not annotations_created["bday_2900"]:
            replace_axis_annotation(ax, "_bday_2900_annotation", "29.00", (time_context["x_value_day_before"] - 0.001, 28.975), ha="center", fontsize=10, fontfamily="DejaVu Serif")
            annotations_created["bday_2900"] = True
        if not annotations_created["bday_3050"]:
            replace_axis_annotation(ax, "_bday_3050_annotation", "30.50", (time_context["x_value_day_before"] - 0.001, 30.475), ha="center", fontsize=10, fontfamily="DejaVu Serif")
            annotations_created["bday_3050"] = True
        if not annotations_created["bday_3000"]:
            replace_axis_annotation(ax, "_bday_3000_annotation", "30.00", (time_context["x_value_day_before"] - 0.001, 29.975), ha="center", fontsize=10, fontfamily="DejaVu Serif")
            annotations_created["bday_3000"] = True
        if not annotations_created["bday_2950"]:
            replace_axis_annotation(ax, "_bday_2950_annotation", "29.50", (time_context["x_value_day_before"] - 0.001, 29.475), ha="center", fontsize=10, fontfamily="DejaVu Serif")
            annotations_created["bday_2950"] = True

    state["yesterday_annotation"] = yesterday_annotation
    state["before_yesterday_annotation"] = before_yesterday_annotation
    state["today_annotation_flag"] = today_annotation_flag
    state["today_inhg_annotation_flag"] = today_inhg_annotation_flag
    return state


def finalize_barograph_frame(
    fig,
    ax,
    line,
    xs,
    ys,
    time_context,
    i,
    aobs_site,
    datetime_cls,
    timedelta_cls,
    output_path="/home/santod/baro_trace.png",
):
    line.set_data(xs, ys)
    ax.set_xlim(datetime_cls.now() - timedelta_cls(minutes=3600), datetime_cls.now())

    title_text = f"Barometric Pressure - {aobs_site}"
    existing_title = getattr(fig, "_barograph_title_text", None)
    if existing_title is None:
        existing_title = fig.text(
            0.5,
            0.03,
            title_text,
            fontsize=12,
            ha="center",
            va="top",
            fontweight="bold",
            zorder=10,
        )
        fig._barograph_title_text = existing_title
    else:
        existing_title.set_text(title_text)

    fig.savefig(output_path, bbox_inches="tight", pad_inches=0.35)
    print(i, ",", time_context["now"])
