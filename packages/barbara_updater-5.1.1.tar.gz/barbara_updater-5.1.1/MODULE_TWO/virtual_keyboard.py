def set_state_uppercase(globals_dict, update_keyboard_shift_state_fn):
    globals_dict["shift_active"] = True
    update_keyboard_shift_state_fn()


def auto_capitalize(globals_dict, tk_module, update_keyboard_shift_state_fn):
    current_target_entry = globals_dict["current_target_entry"]
    state_entry_widgets = globals_dict["state_entry_widgets"]

    if current_target_entry in state_entry_widgets.values():
        globals_dict["shift_active"] = True
        update_keyboard_shift_state_fn()
        return

    if globals_dict["is_buoy_code"]:
        return

    if current_target_entry is not None:
        if isinstance(current_target_entry, tk_module.Text):
            content = current_target_entry.get("1.0", "end-1c")
        else:
            content = current_target_entry.get()

        if not content or content.endswith((".", ". ", ".\n", "!", "! ", "!\n", "?", "? ", "?\n")):
            if not globals_dict["shift_active"]:
                globals_dict["shift_active"] = True
                update_keyboard_shift_state_fn()


def set_keyboard_target(widget, globals_dict, tk_module, auto_capitalize_fn, update_keyboard_shift_state_fn):
    try:
        widget.winfo_exists()
    except tk_module.TclError:
        print(f"set_keyboard_target: Widget {widget} no longer exists.")
        return

    print(f"Setting keyboard target to: {widget}")
    globals_dict["current_target_entry"] = widget
    auto_capitalize_fn()
    update_keyboard_shift_state_fn()


def set_current_target(entry_widget, globals_dict):
    globals_dict["current_target_entry"] = entry_widget


def key_pressed(key_value, globals_dict, tk_module, auto_capitalize_fn, update_keyboard_shift_state_fn):
    current_target_entry = globals_dict["current_target_entry"]
    state_entry_widgets = globals_dict["state_entry_widgets"]
    shifted_keys = globals_dict["shifted_keys"]

    if not current_target_entry:
        return

    if key_value == "Backspace":
        if isinstance(current_target_entry, tk_module.Text):
            current_target_entry.delete("insert -1 chars", "insert")
        elif isinstance(current_target_entry, tk_module.Entry):
            current_pos = current_target_entry.index(tk_module.INSERT)
            if current_pos > 0:
                current_target_entry.delete(current_pos - 1, current_pos)
        auto_capitalize_fn()
        update_keyboard_shift_state_fn()
        return

    if key_value == "Space":
        current_target_entry.insert("insert", " ")
        auto_capitalize_fn()
        update_keyboard_shift_state_fn()
        return

    if key_value == "Tab":
        current_target_entry.tk_focusNext().focus_set()
        return

    if key_value == "Shift":
        globals_dict["shift_active"] = not globals_dict["shift_active"]
        if current_target_entry in state_entry_widgets.values():
            globals_dict["shift_active"] = True
        update_keyboard_shift_state_fn()
        return

    if key_value == "@gmail.com":
        current_target_entry.insert("insert", "@gmail.com")
        auto_capitalize_fn()
        update_keyboard_shift_state_fn()
        return

    actual_value = None
    if key_value in shifted_keys:
        actual_value = shifted_keys[key_value] if globals_dict["shift_active"] else key_value
    elif key_value.isalpha():
        if current_target_entry in state_entry_widgets.values():
            actual_value = key_value.upper()
        else:
            actual_value = key_value.upper() if globals_dict["shift_active"] else key_value.lower()
    else:
        actual_value = key_value

    if actual_value:
        current_target_entry.insert("insert", actual_value)

    if current_target_entry not in state_entry_widgets.values():
        auto_capitalize_fn()
        update_keyboard_shift_state_fn()


def update_keyboard_shift_state(globals_dict, tk_module):
    shift_active = globals_dict["shift_active"]
    keyboard_buttons = globals_dict["keyboard_buttons"]
    shifted_keys = globals_dict["shifted_keys"]
    current_target_entry = globals_dict["current_target_entry"]
    state_entry_widgets = globals_dict["state_entry_widgets"]

    is_state_entry = current_target_entry and current_target_entry in state_entry_widgets.values()

    for key, button in keyboard_buttons.items():
        if key.isnumeric():
            button.config(text=shifted_keys[key] if shift_active else key)
        elif key.isalpha():
            if is_state_entry:
                button.config(text=key.upper())
            else:
                button.config(text=key.upper() if shift_active else key.lower())
        elif key == "Shift":
            button.config(relief=tk_module.SUNKEN if shift_active else tk_module.RAISED)
