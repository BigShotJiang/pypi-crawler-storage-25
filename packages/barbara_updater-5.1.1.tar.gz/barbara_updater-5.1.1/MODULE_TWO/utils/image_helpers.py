from PIL import Image

def is_black_image(image_path):
    try:
        image = Image.open(image_path)
        return not image.getbbox()
    except Exception:
        return True
        
