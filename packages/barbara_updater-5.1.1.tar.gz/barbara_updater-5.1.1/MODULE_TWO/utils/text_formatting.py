import re

_COMMON_ABBREVIATIONS = {
    "International": "Intl",
    "Municipal": "Muni",
    "Regional": "Reg",
    "Airport": "Arpt",
    "Field": "Fld",
    "National": "Natl",
    "County": "Co",
    "Downtown": "Dwntn",
    "DOWNTOWN": "DWNTN",
    "Boardman": "Brdmn",
    "Street": "St",
    "Southern": "Sthrn",
    "Northeast": "NE",
    "Northwest": "NW",
    "Southwest": "SW",
    "Southeast": "SE",
    " North ": "N",
    " South ": "S",
    " East ": "E",
    " West ": "W",
    " And ": "&",
}


def _apply_common_abbreviations(name):
    first_six = name[:6]
    if len(name) > 6 and any(char.isdigit() for char in first_six) and any(char.isalpha() for char in first_six):
        code = first_six
        rest_of_name = name[6:].strip()
        if rest_of_name and not rest_of_name.startswith(tuple(_COMMON_ABBREVIATIONS.keys())):
            name = code + ' ' + rest_of_name
        else:
            name = code + rest_of_name

    for word, abbr in _COMMON_ABBREVIATIONS.items():
        name = re.sub(rf"\b{re.escape(word.strip())}\b", abbr, name)
    return " ".join(name.split())


def _ellipsis_trim(text, max_length):
    if len(text) <= max_length:
        return text
    return f"{text[:max_length-3].rstrip()}..."

def obs_buttons_choice_abbreviations(name, state_id, max_length=21):
    name = _apply_common_abbreviations(name)

    if len(name) > max_length:
        result = f"{name[:max_length-3]}..., {state_id}"
        return result
    else:
        result = f"{name}, {state_id}"
        return result
        
def abbreviate_location(name, state_id, max_length=21):
    name = _apply_common_abbreviations(name)

    if len(name) > max_length:
        return f"{name[:max_length-3]}..., {state_id}"
    else:
        return f"{name}, {state_id}"


def format_map_flag_label(name, state_id="", max_length=14):
    clean_name = (name or "").split(",")[0].strip()
    clean_name = _apply_common_abbreviations(clean_name).title()
    if state_id:
        clean_name = f"{clean_name}, {state_id}"
    return _ellipsis_trim(clean_name, max_length)
        
