import functools
import http.server
import os
import socketserver
import threading


class ReusableTCPServer(socketserver.TCPServer):
    allow_reuse_address = True


class QuietMapRequestHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
            return
        super().do_GET()

    def log_message(self, format, *args):
        return


def capture_folium_map_screenshot(
    html_path,
    png_path,
    chrome_driver_path,
    options_cls,
    service_cls,
    webdriver_module,
    time_module,
    adjust_window_size_func,
    target_width=450,
    target_height=300,
    initial_width=600,
    initial_height=500,
    extra_chrome_args=None,
):
    if not chrome_driver_path:
        return False

    map_directory = os.path.dirname(os.path.abspath(html_path)) or os.getcwd()
    map_filename = os.path.basename(html_path)

    handler = functools.partial(QuietMapRequestHandler, directory=map_directory)
    server = ReusableTCPServer(("127.0.0.1", 0), handler)
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    driver = None
    try:
        options = options_cls()
        options.add_argument("--headless")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        if extra_chrome_args:
            for chrome_arg in extra_chrome_args:
                options.add_argument(chrome_arg)

        service = service_cls(chrome_driver_path)
        driver = webdriver_module.Chrome(service=service, options=options)
        driver.set_window_size(initial_width, initial_height)
        driver.get(f"http://127.0.0.1:{server.server_address[1]}/{map_filename}")
        time_module.sleep(2)
        adjust_window_size_func(driver, target_width, target_height)
        time_module.sleep(0.5)
        driver.save_screenshot(os.path.abspath(png_path))
        return True
    finally:
        if driver:
            try:
                driver.quit()
            except Exception:
                pass
        try:
            server.shutdown()
        except Exception:
            pass
        try:
            server.server_close()
        except Exception:
            pass
