# Hi David - 2026-04-08 09:27:20 AM EDT
# 3/25/26 reconfigure
# 3/27/26 completed image sources
# 3/31/26 started observations sources
# 4/5/26 some of obs done. moving to codex

import subprocess
import sys
import importlib.metadata
import os
import requests
import re
import shutil
import platform
import time
from time import strftime
import datetime as dt
from datetime import datetime, timedelta, timezone
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
matplotlib.rcParams['toolbar'] = 'None'
import matplotlib.animation as animation
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator)
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
import json
from matplotlib import rcParams
import io
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont, ImageTk, ImageChops, UnidentifiedImageError, ImageFilter
import matplotlib.image as mpimg
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import traceback
import imageio
from matplotlib.animation import FuncAnimation
from math import radians, sin, cos, sqrt, atan2
import geopy.distance
from geopy.geocoders import Nominatim
from geopy.distance import geodesic
from geopy.exc import GeocoderTimedOut, GeocoderUnavailable
import urllib.parse
from selenium import webdriver
from selenium.common.exceptions import WebDriverException, NoSuchElementException, TimeoutException, SessionNotCreatedException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
import threading
import tkinter as tk
from tkinter import ttk, IntVar, messagebox, PhotoImage, simpledialog, font, Checkbutton
import tkinter.font as tkFont
from collections import deque
from matplotlib.widgets import Button
import matplotlib.ticker as ticker
import warnings
import itertools
from itertools import cycle, islice
import psutil
import gc
from queue import Queue, Empty
data_update_queue = Queue()
from threading import Thread
from functools import partial
import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
import base64
import random
import pytz
import concurrent.futures
import folium
import ssl
import certifi
from dateutil import parser
import urllib3
import asyncio
import aiohttp
from folium.plugins import MarkerCluster
from folium import Element
from tkhtmlview import HTMLLabel
import math
import calendar
import signal
from concurrent.futures import ThreadPoolExecutor
import uuid
import configparser
import copy
import xml.etree.ElementTree as ElementTree
import smbus2 as smbus
import tracemalloc
from bs4 import BeautifulSoup
from bs4.element import Tag
import time, queue
from PIL import ImageTk 
import zlib # added these three lines on 8/10/25
from functools import lru_cache # added 9/30/25 to manage the use of cached land & buoy meta data
#start new modules 3/25/26
from utils.conversions import pascals_to_inches_hg, is_black_image
from utils.text_formatting import obs_buttons_choice_abbreviations, abbreviate_location
from image_sources.radar_national import fetch_and_process_national_radar
from image_sources.national_surface import fetch_and_process_national_sfc
from image_sources.storm_reports import fetch_and_process_storm_reports
from image_sources.vorticity import fetch_and_process_vorticity
from image_sources.barograph_image import fetch_and_process_baro_pic
from image_sources.still_satellite import fetch_and_process_still_sat
from image_sources.lightning import fetch_and_process_lightning
from image_sources.radiosonde import fetch_and_process_radiosonde
from image_sources.sfc_plots import fetch_and_process_sfc_plots
from image_sources.local_radar import get_lcl_radar_loop
from image_sources.regional_satellite import fetch_and_process_reg_sat_loop as module_fetch_and_process_reg_sat_loop
# observation sources
from observation_sources.metadata import (
    populate_random_station_selection_globals,
    get_random_station_config,
    find_valid_random_stations,
    check_random_station_functionality,
    preload_random_station_observations,
    populate_random_station_observation_globals,
    apply_manual_land_confirmation_globals,
    apply_buoy_selection_globals,
    populate_single_buoy_observation_globals,
    clear_obs_only_click_flag,
    apply_buoy_display_name,
    build_state_station_candidates,
    find_first_valid_temperature_row,
    build_scraped_land_station_result,
    calculate_station_map_center,
    calculate_station_map_zoom_level,
    build_station_map_bounds,
    build_land_station_choice_text,
    normalize_land_input_values,
    is_valid_land_input,
    apply_land_input_display_globals,
    get_obs_ordinal,
    build_buoy_choice_text_from_description,
    apply_buoy_help_selection_globals,
    build_buoy_help_final_list,
    get_land_confirmation_slot_config,
    find_buoy_help_nearest_buoys,
    check_buoy_help_functionality,
    calculate_buoy_help_center as metadata_calculate_buoy_help_center,
    calculate_buoy_help_zoom_level as metadata_calculate_buoy_help_zoom_level,
    normalize_station_id,
    normalize_buoy_help_town_state_input,
    parse_buoy_help_coordinates,
    get_recent_buoy_rss_observation,
)
from observation_sources.workflows import (
    create_station_map_screenshot,
    find_and_scrape_land_stations_sequentially,
    fetch_functional_buoy_help_candidates,
    build_buoy_help_choice_entries,
    gather_buoy_help_choices,
    resolve_buoy_help_selection,
    validate_buoy_observation_workflow,
    gather_land_station_choices,
    display_station_map_image,
    prepare_land_confirmation_display,
    create_buoy_help_map_screenshot,
    submit_buoy_help_town_workflow,
    submit_buoy_help_coord_workflow,
    submit_buoy_help_near_me_workflow,
)

VERSION = "4.3.15"
        
# --- STARTUP FUNCTIONS ---

def ensure_network_manager_enabled_and_started():
    try:
        status = subprocess.check_output(
            ["systemctl", "is-active", "NetworkManager"],
            stderr=subprocess.STDOUT
        ).decode("utf-8").strip()
        if status == "active":
            return
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass
    try:
        subprocess.check_call(["sudo", "systemctl", "enable", "NetworkManager"])
        subprocess.check_call(["sudo", "systemctl", "start", "NetworkManager"])
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"Failed to enable/start Network Manager: {e}")

def get_os_codename():
    try:
        with open("/etc/os-release") as f:
            for line in f:
                if line.startswith("VERSION_CODENAME="):
                    return line.strip().split("=")[1]
    except FileNotFoundError:
        pass
    return None

def detect_chromium_and_driver():
    """Detect preinstalled Chromium and ChromeDriver placed by apt."""
    # Bookworm: /usr/bin/chromium ; Bullseye: /usr/bin/chromium-browser
    chromium_bins = ("/usr/bin/chromium", "/usr/bin/chromium-browser")
    chromium_bin = next((p for p in chromium_bins if os.path.exists(p)), None)

    driver_path = "/usr/bin/chromedriver" if os.path.exists("/usr/bin/chromedriver") else shutil.which("chromedriver")

    if not chromium_bin or not driver_path:
        print(f"[DRIVER][FATAL] Missing binaries. chromium={chromium_bin}, chromedriver={driver_path}")
        return None, None

    # Log versions; warn if majors differ
    try:
        b_out = subprocess.check_output([chromium_bin, "--version"], text=True).strip()
        d_out = subprocess.check_output([driver_path, "--version"], text=True).strip()
        b_maj = re.search(r"(?:Chromium|Chrome)\s+(\d+)\.", b_out).group(1)
        d_maj = re.search(r"ChromeDriver\s+(\d+)\.", d_out).group(1)
        print(f"[DRIVER] Chromium:     {b_out}")
        print(f"[DRIVER] ChromeDriver: {d_out}")
        if b_maj != d_maj:
            print(f"[DRIVER][WARN] Version mismatch: Chromium {b_maj} vs Driver {d_maj}.")
    except Exception as e:
        print(f"[DRIVER][WARN] Could not read versions: {e}")

    return chromium_bin, driver_path

# --- SCRIPT STARTUP SEQUENCE ---
ensure_network_manager_enabled_and_started()
CHROMIUM_BIN, CHROME_DRIVER_PATH = detect_chromium_and_driver()

# --- HOW TO USE THE DRIVER PATH IN YOUR CODE ---
# In every function where you start Selenium, use the global CHROME_DRIVER_PATH variable.
# The rest of your code does not need to know which path was chosen.
# Example:
#
# def some_function_that_uses_selenium():
#     if not CHROME_DRIVER_PATH:
#         print("ERROR: ChromeDriver path not set. Cannot start browser.")
#         return
#
#     options = Options()
#     options.add_argument(...)
#
#     service = Service(CHROME_DRIVER_PATH)
#     driver = webdriver.Chrome(service=service, options=options)
#     # ...

# This flag signals if a high-demand task is currently running.
# The scheduler will not start a new task until this is False.

TASK_IN_PROGRESS = False

task_queue = [
    'lightning',
    'lcl_radar',
    'reg_sat',
    'sfc_plots',
    'observations',
]

#sys.stdout = sys.stderr = open('/dev/null', 'w') # comment out this line to see output to the console for troubleshooting

IS_X11 = os.environ.get('XDG_SESSION_TYPE', '').lower() == 'x11'
print(f"Detected Session Type: {'X11' if IS_X11 else os.environ.get('XDG_SESSION_TYPE', 'Unknown')}")

def get_location(timeout=5):
    try:
        resp = requests.get('http://ip-api.com/json', timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
    except requests.exceptions.RequestException as e:
        print(f"Location lookup failed: {e}")
        return None

    if data.get('status') != 'success':
        # e.g. “fail” or rate-limited
        print(f"Geolocate API error: {data.get('message', '<no message>')}")
        return None

    return data['lat'], data['lon']

def get_aobs_site(latitude, longitude):
    global baro_input  # Global variable for barometric pressure
    global aobs_site   # Global variable for the name of the town and state
    
    baro_input = None  # Initialize to None or any default value
    
    try:
        # Make the initial API request to get location and station information
        response = requests.get(f'https://api.weather.gov/points/{latitude},{longitude}')
        if response.status_code != 200:
            print("Failed to fetch data from the National Weather Service.")
            return False
        data = response.json()

        try:
            # Extract location information
            location = data['properties']['relativeLocation']['properties']
            town = location['city']
            state = location['state']
            aobs_site = f"{town}, {state}"  # Update global variable with location name
        except Exception as e:
            aobs_site = "Try again later"
            print("not able to assign aobs_site at this time. {e} aobs_site: ", aobs_site)

        # Extract the URL to the nearest observation stations
        stations_url = data['properties']['observationStations']

        # Get the list of nearby weather stations
        response = requests.get(stations_url)
        if response.status_code != 200:
            print("Failed to fetch station list from the National Weather Service.")
            return False
        stations_data = response.json()

        # Loop through the stations to find one with a barometric pressure reading
        for station_url in stations_data['observationStations']:
            try:
                station_observation_response = requests.get(f"{station_url}/observations/latest")
                if station_observation_response.status_code != 200:
                    continue  # Skip if the station's observation data can't be accessed

                observation_data = station_observation_response.json()

                # Attempt to get the barometric pressure
                if 'barometricPressure' in observation_data['properties'] and 'value' in observation_data['properties']['barometricPressure']:
                    barometric_pressure_pascals = observation_data['properties']['barometricPressure']['value']
                    if barometric_pressure_pascals is not None:
                        # Convert to inches of mercury and update the global variable
                        baro_input = pascals_to_inches_hg(barometric_pressure_pascals)
                        return aobs_site
            except Exception as e:
                print(f"Error accessing data for station {station_url}: {e}")
                continue

        # If the loop completes without finding a valid pressure reading
        print(f"Location: {aobs_site}")
        print("No stations with a current barometric pressure reading were found.")
        return False

    except Exception as e:
        print(f"An error occurred: {e}")
        
        try:
            next_button = tk.Button(frame, text="Next", font=error_button_font, command=land_or_buoy)
            next_button.grid(row=4, column=0, padx=(50, 0), pady=10, sticky="w")
        except NameError:
            tk.Button(frame, text="Back", font=error_button_font, command=back_command).grid(row=4, column=0, padx=(50,0), pady=10, sticky="w")

        #return False
        
location = get_location()
if location is None:
    print("Could not resolve latitude/longitude")
else:
    latitude, longitude = location
    aobs_site = get_aobs_site(latitude, longitude)

# Establish keys for secrets
ACCESS_TOKEN = ""
API_SECRET_TOKEN = ""
EMAIL_PASSWORD_CODE = ""
FULLSCREEN_BREAK_PASSWORD = ""
IG_USER_ID = ""
#MESOWEST_API_TOKEN = ""
PAGE_ACCESS_TOKEN = ""
PAGE_ID = ""

# Define the URL for getting secrets
SERVER_URL_SECRETS = "https://weatherobserver.duckdns.org/api/get_secrets"

# --- Section to fetch secrets using the API Key ---

api_key = None # Initialize api_key

# 1. Read API Key from the correct Configuration File
logging.info("Attempting to read API key from secrets.ini")
print("line 297 attempting to read API key from secrets.ini")
try:
    config = configparser.ConfigParser()
    config_path = '/home/santod/.config/weather_observer/secrets.ini'
    if not os.path.exists(config_path):
        logging.error(f"Configuration file not found at {config_path}")

    config.read(config_path)
    api_key = config.get('SECRETS', 'API_KEY')
    logging.info("API key read successfully.")
    print(f"Using API Key: {api_key}") # Optional: print key for confirmation

except configparser.NoSectionError:
    logging.error(f"Error: 'SECRETS' section not found in {config_path}")
except configparser.NoOptionError:
    logging.error(f"Error: 'API_KEY' not found in 'SECRETS' section in {config_path}")
except Exception as e:
    logging.error(f"Error reading configuration file {config_path}: {e}")

# Ensure api_key was read before proceeding
if not api_key:
    logging.error("API Key could not be read. Exiting.")

# 2. Construct Request for Secrets
logging.info("Constructing request to fetch secrets.")
request_data = {"api_key": api_key}
request_json = json.dumps(request_data)
logging.info(f"Request data: {request_json}")
#print("line 322 request for secrets contructed, step #2")

# 3. Send Request to Server to Get Secrets
logging.info(f"Sending request to {SERVER_URL_SECRETS}")
try:
    response = requests.post(
        SERVER_URL_SECRETS,
        headers={'Content-Type': 'application/json'},
        data=request_json
    )
    logging.info(f"Received response status code: {response.status_code}")
    response.raise_for_status() # Raises HTTPError for bad responses (4xx or 5xx)

    # 4. Process Server Response (Secrets)
    response_data = response.json() # Use response.json() to decode directly
    logging.info("Successfully received secrets from server.")
    #print(f"line 382. Received secrets: {response_data}") # Optional: print secrets for debugging

    # Extract secrets into variables (ensure these variable names match your needs)
    ACCESS_TOKEN = response_data.get('ACCESS_TOKEN')
    API_SECRET_TOKEN = response_data.get('API_SECRET_TOKEN')
    EMAIL_PASSWORD_CODE = response_data.get('EMAIL_PASSWORD_CODE')
    FULLSCREEN_BREAK_PASSWORD = response_data.get('FULLSCREEN_BREAK_PASSWORD')
    IG_USER_ID = response_data.get('IG_USER_ID')
    #MESOWEST_API_TOKEN = response_data.get('MESOWEST_API_TOKEN')
    PAGE_ACCESS_TOKEN = response_data.get('PAGE_ACCESS_TOKEN')
    PAGE_ID = response_data.get('PAGE_ID')

    # Check if any essential secrets are missing (optional but recommended)
    if None in [ACCESS_TOKEN, API_SECRET_TOKEN, EMAIL_PASSWORD_CODE, FULLSCREEN_BREAK_PASSWORD, IG_USER_ID, PAGE_ACCESS_TOKEN, PAGE_ID]:
        logging.warning("One or more secrets were not found in the server response.")
        # Decide how to handle missing secrets (e.g., exit, log, continue with defaults)

    logging.info("Secrets extracted successfully.")
    # Now you can use these variables (ACCESS_TOKEN, etc.) in the rest of your script

except requests.exceptions.RequestException as e:
    logging.error(f"Error connecting to server at {SERVER_URL_SECRETS}: {e}")
    # Handle connection error (e.g., retry logic, exit)
    #exit(1)
except requests.exceptions.HTTPError as e:
    logging.error(f"HTTP Error received from server: {e.response.status_code} {e.response.reason}")
    logging.error(f"Server response content: {e.response.text}")
    # Handle HTTP errors (e.g. 401 Unauthorized, 400 Bad Request, 500 Internal Server Error)
    if e.response.status_code == 401:
        logging.error("Authentication failed (401 Unauthorized). Check if the API Key is correct and valid on the server.")
    
except json.JSONDecodeError as e:
    logging.error(f"Error decoding JSON response from server: {e}")
    logging.error(f"Server response content: {response.text}") # Log the raw response

except Exception as e:
    logging.error(f"An unexpected error occurred during secret retrieval: {e}")

#--- End of section to fetch secrets ---

# --- Fetch Land Station Metadata from Server ---
# --- Land Station Metadata ---
ALL_STATIONS_CACHE = None
RANDOM_CANDIDATE_STATIONS_CACHE = None # to hold list of stations near home location to draw random sites from
ALL_STATIONS_CACHE_DICTS = None
ALL_BUOY_CACHE = None
logging.info("Attempting to fetch land station metadata from server...")
try:
    pp_land_stations_url = "https://weatherobserver.duckdns.org/data/stations_metadata.json"
    pp_local_land_path = "/home/santod/stations_metadata.json"
    pp_headers = {'X-API-Key': api_key}

    response = requests.get(pp_land_stations_url, headers=pp_headers, timeout=60)
    response.raise_for_status()

    data = response.json()

    # --- ADD THIS DIAGNOSTIC BLOCK ---
    print("\n---- DIAGNOSTIC START ----")
    print(f"The 'data' variable received from the server is a: {type(data)}")
    if isinstance(data, list):
        print(f"The list contains {len(data)} items.")
        if len(data) > 0:
            print("Checking the keys of the FIRST item in the list:")
            first_item_keys = data[0].keys()
            print(f"  Keys found: {list(first_item_keys)}")
            
            required_keys = {"id", "name", "latitude", "longitude", "state"}
            missing_keys = required_keys - set(first_item_keys)
            if missing_keys:
                print(f"  [PROBLEM] The first item is MISSING required keys: {missing_keys}")
            else:
                print("  [OK] The first item seems to have all required keys.")
    else:
        print("The data received is NOT a list. Here is what was received:")
        print(data)
    print("---- DIAGNOSTIC END ----\n")
    # --- END OF DIAGNOSTIC BLOCK ---

    # Save the received data to a local file
    with open(pp_local_land_path, 'w') as f:
        json.dump(data, f)

    # Prime cache with dicts
    ALL_STATIONS_CACHE = [
        s for s in data
        if all(k in s for k in ("id", "name", "latitude", "longitude", "state"))
    ]

    # ADD THIS DIAGNOSTIC LINE HERE:
    print(f"DIAGNOSTIC CHECK: Immediately after creation, ALL_STATIONS_CACHE has {len(ALL_STATIONS_CACHE)} stations.")

    logging.info(f"Successfully downloaded and saved land station metadata to {pp_local_land_path}")
    print("line 451. successfully downloaded and saved land station metadata.")
    
except requests.exceptions.RequestException as e:
    logging.error(f"Error fetching land station metadata: {e}")
    ALL_STATIONS_CACHE = []

# --- Buoy Metadata ---
logging.info("Attempting to fetch buoy metadata from server...")
try:
    pp_buoy_stations_url = "https://weatherobserver.duckdns.org/data/buoy_metadata.json"
    pp_local_buoy_path = "/home/santod/buoy_metadata.json"
    pp_headers = {'X-API-Key': api_key}

    response = requests.get(pp_buoy_stations_url, headers=pp_headers, timeout=15)
    response.raise_for_status()

    data = response.json()

    # Save the received data to a local file
    with open(pp_local_buoy_path, 'w') as f:
        json.dump(data, f)

    # Prime cache with dicts
    ALL_BUOYS_CACHE = [
        s for s in data
        if all(k in s for k in ("id", "name", "latitude", "longitude"))
    ]

    logging.info(f"Successfully downloaded and saved buoy metadata to {pp_local_buoy_path}")
    print("line 471. successfully downloaded buoy metadata.")
except requests.exceptions.RequestException as e:
    logging.error(f"Error fetching buoy metadata: {e}")
    ALL_BUOYS_CACHE = []


#... (Rest of your TWO program logic continues here, using the fetched secrets) ...

def check_lcl_radar_map_available():
    print("line 478. inside check lcl radar map available.")
    lcl_radar_map_path = "/home/santod/lcl_radar_map.png"
    lcl_radar_metadata_path = "/home/santod/lcl_radar_metadata.json"
    return os.path.exists(lcl_radar_map_path) and os.path.exists(lcl_radar_metadata_path)

def display_lcl_radar_error_gui(error_message):
    """
    Display a GUI error message if the radar map is not available.
    """
    root = tk.Tk()
    root.title("Error")
    label = tk.Label(root, text=f"Error: {error_message}\nLocal radar map will not be available.",
                        font=("Arial", 16), wraplength=400, justify="center")
    label.pack(padx=20, pady=20)
    button = tk.Button(root, text="OK", command=root.destroy, font=("Helvetica", 14))
    button.pack(pady=10)
    root.mainloop()

def graceful_exit(signum, frame):
    print("[INFO] Program interrupted. Cleaning up...")

    # Perform any cleanup tasks here
    kill_orphaned_chrome()  # Kill any lingering Chrome processes
    gc.collect()  # Force garbage collection

    print("[INFO] Cleanup complete. Exiting...")
    
    root.quit()  # Exit the Tkinter main loop
    sys.exit(0)

# Register the signal handler for SIGINT (Ctrl+C)
signal.signal(signal.SIGINT, graceful_exit)

tracemalloc.start()

# Global variable to store the background event loop
background_loop = None

def start_event_loop():
    global background_loop
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    background_loop = loop  # Save the loop reference
    loop.run_forever()

# Launch the event loop thread
threading.Thread(target=start_event_loop, daemon=True).start()

# --- CPU Lull Detection System ---

# 1. Add this new global variable at the top of your script with your others.
CPU_IS_IDLE = False

def cpu_lull_monitor():
    """
    This function runs in a dedicated background thread. It continuously
    monitors CPU usage and sets a global flag when it detects a stable
    period of low activity.
    """
    global CPU_IS_IDLE
    
    # --- Configuration ---
    # The CPU usage must be below this percentage to be considered "low".
    LOW_CPU_THRESHOLD = 20.0
    # The CPU must stay below the threshold for this many seconds to be
    # considered a stable "lull".
    REQUIRED_LULL_DURATION = 5
    
    # --- Internal State ---
    consecutive_low_cpu_seconds = 0

    #print("[CPU_MONITOR] Monitor thread has started.")

    while True:
        # Get the system-wide CPU utilization over a 1-second interval.
        # The interval=1 part is important, as it makes this loop
        # automatically pause for 1 second and is very efficient.
        cpu_usage = psutil.cpu_percent(interval=1)

        if cpu_usage < LOW_CPU_THRESHOLD:
            # CPU is low, increment our counter.
            consecutive_low_cpu_seconds += 1
        else:
            # CPU is high, so the lull is broken. Reset the counter.
            consecutive_low_cpu_seconds = 0
            # If the flag was previously set to True, print a message
            # and set it back to False.
            if CPU_IS_IDLE:
                #print(f"[CPU_MONITOR] CPU usage high ({cpu_usage}%). Lull has ended.")
                CPU_IS_IDLE = False

        # Check if we have met the conditions for a stable lull.
        # We also check 'not CPU_IS_IDLE' to ensure we only print the
        # "lull detected" message once per lull.
        if consecutive_low_cpu_seconds >= REQUIRED_LULL_DURATION and not CPU_IS_IDLE:
            #print(f"[CPU_MONITOR] CPU lull detected (usage at {cpu_usage}% for {REQUIRED_LULL_DURATION}s). It is now safe to start a new task.")
            CPU_IS_IDLE = True
            # Note: We don't reset the counter here. This means the CPU_IS_IDLE
            # flag will remain True as long as the CPU stays low.

def start_cpu_monitor():    
    """
    Creates and starts the background thread for the CPU monitor.
    This should be called only once when the application starts.
    """
    # Creating a "daemon" thread means it will automatically exit
    # when the main application closes.
    monitor_thread = threading.Thread(target=cpu_lull_monitor, daemon=True)
    monitor_thread.start()
    #print("[INFO] CPU monitor thread has been started.")

start_cpu_monitor()

# Initialize variables for swipe functionality
start_x = None
start_y = None
debounce_timer = None

# Optional improvement for on_touch_start: Cancel any existing debounce
# This handles cases where a new touch happens before the old debounce finished
def on_touch_start(event):
    global start_x, start_y, debounce_timer
    print("Touch start detected at:", event.x, event.y)

    # Cancel any existing debounce timer when a new touch starts
    if debounce_timer is not None:
        root.after_cancel(debounce_timer)
        debounce_timer = None
        print("Existing debounce canceled by new touch.") # Optional: for debugging

    start_x = event.x
    start_y = event.y

def handle_swipe(event):
    global start_x, start_y, debounce_timer, auto_advance_timer, current_frame_index

    # --- Check debounce timer at the start ---
    if debounce_timer is not None:
        # If we are currently debouncing, ignore this motion event entirely.
        # print("Debouncing...") # Optional: for debugging
        return  # Ignore events during debounce

    # --- Check if start_x is valid (touch has started) ---
    if start_x is None:
        # This can happen if motion event fires before press, though unlikely with Tkinter bind order.
        return

    delta_x = event.x - start_x
    delta_y = event.y - start_y
    
    current_time_ms = int(time.time() * 1000)
    print(f"[{current_time_ms}] Motion: x={event.x}, y={event.y}, delta_x={delta_x:.2f}, delta_y={delta_y:.2f}")

    # --- Detect Horizontal Swipe ---
    # Check for significant horizontal movement that's greater than vertical movement
    if abs(delta_x) > 30 and abs(delta_x) > abs(delta_y): # Increased threshold slightly might help
        # --- Swipe Detected! ---

        # Determine direction and call the appropriate function
        if delta_x > 0:
            print("Swipe Right Detected -> Calling on_right_swipe")
            on_right_swipe(event)
        else:
            print("Swipe Left Detected -> Calling on_left_swipe")
            on_left_swipe(event)

        # --- *** CONDITIONAL Reset and Debounce *** ---
        if IS_X11:
            # For X11: Force a new touch start and use longer debounce
            start_x = None
            start_y = None
            debounce_delay_ms = 600 # Longer debounce for X11 (tune this!)
            print(f"[{current_time_ms}] X11: Resetting start=None, Starting debounce for {debounce_delay_ms}ms")
        else:
            # For Wayland (and others): Original reset, shorter debounce
            start_x = event.x
            start_y = event.y
            debounce_delay_ms = 300 # Keep original for Wayland
            print(f"[{current_time_ms}] Wayland: Resetting start={start_x}, Starting debounce for {debounce_delay_ms}ms")

        debounce_timer = root.after(debounce_delay_ms, reset_debounce)

        # 3. Manage auto-advance timers ONLY after a successful swipe
        manage_timers_after_swipe()

        # 4. IMPORTANT: Return here to stop further processing of this specific motion event
        #    after a swipe has been handled.
        return

def manage_timers_after_swipe():
    global auto_advance_timer, current_frame_index, image_keys
    if auto_advance_timer:
        root.after_cancel(auto_advance_timer)
        auto_advance_timer = None

    # Check if the current frame is a loop that should pause auto-advance
    if image_keys[current_frame_index] in ["lcl_radar_loop_img", "reg_sat_loop_img"]:
        # Extend or deactivate timer
        auto_advance_timer = root.after(30000, auto_advance_frames)  # 30 seconds delay
    else:
        # Restart with normal delay if not a loop
        auto_advance_timer = root.after(10000, auto_advance_frames)

# Ensure reset_debounce clears the global timer variable
def reset_debounce():
    global debounce_timer
    print("Debounce timer finished.") # Optional: for debugging
    debounce_timer = None

last_monitor_check = None # Global variable to track last monitoring time

def log_memory_snapshot():
    snapshot = tracemalloc.take_snapshot()
    top_stats = snapshot.statistics('lineno')
    #print("[Top 10 Memory Consumers]")
    #for stat in top_stats[:10]:
        #print(stat)

# Helper function to kill orphaned Chrome/WebDriver processes
def kill_orphaned_chrome():
    try:
        os.system("pkill -f chrome")
    except Exception as e:
        print("Error cleaning up Chrome processes:", e)

def force_gc_and_log():
    freed_objects = gc.collect()
    print(f"Garbage collection completed. Objects collected: {freed_objects}")
    
def log_memory_usage():
    process = psutil.Process()
    mem_info = process.memory_info()
    print(f"Memory Usage: {mem_info.rss / 1024 / 1024:.2f} MB (RSS), {mem_info.vms / 1024 / 1024:.2f} MB (VMS)")

# Code begins to find and prepare lcl radar choice map to get user's choice
def load_lcl_radar_map(): # Modified to return True/False
    #print("line 721. inside load lcl radar map.")
    lcl_radar_map_path = "/home/santod/lcl_radar_map.png"
    lcl_radar_metadata_path = "/home/santod/lcl_radar_metadata.json"
    SERVER_DUCKDNS = "weatherobserver.duckdns.org"
    lcl_radar_map_url = f"https://{SERVER_DUCKDNS}/~santod/radar_map_data/lcl_radar_map.png"
    lcl_radar_metadata_url = f"https://{SERVER_DUCKDNS}/~santod/radar_map_data/lcl_radar_metadata.json"

    if os.path.exists(lcl_radar_map_path) and os.path.exists(lcl_radar_metadata_path):
        print("Local radar map data found by load_lcl_radar_map.")
        # Optional: Could add validation here too, return False if invalid
        return True # Files exist
    else:
        print("Local radar map data not found by load_lcl_radar_map. Downloading...")
        try:
            # Download map image
            map_response = requests.get(lcl_radar_map_url, stream=True, timeout=15)
            map_response.raise_for_status()
            with open(lcl_radar_map_path, 'wb') as map_file:
                for chunk in map_response.iter_content(chunk_size=8192): map_file.write(chunk)
            print("Radar map image downloaded successfully.")

            # Download metadata
            metadata_response = requests.get(lcl_radar_metadata_url, timeout=15)
            metadata_response.raise_for_status()
            # Save metadata directly (no need to load into variable here)
            with open(lcl_radar_metadata_path, "w") as metadata_file:
                 metadata_file.write(metadata_response.text) # Write raw text
            print("Radar metadata downloaded successfully.")
            return True # Download succeeded

        except requests.exceptions.RequestException as e:
            print(f"Error downloading radar map data: {e}")
            return False
        except Exception as e:
            print(f"An unexpected error occurred during download: {e}")
            # Clean up potentially partial files on error?
            if os.path.exists(lcl_radar_map_path): os.remove(lcl_radar_map_path)
            if os.path.exists(lcl_radar_metadata_path): os.remove(lcl_radar_metadata_path)
            return False

def initialize_lcl_radar_map():
    lcl_radar_map_path = "/home/santod/lcl_radar_map.png"
    lcl_radar_metadata_path = "/home/santod/lcl_radar_metadata.json"

    if os.path.exists(lcl_radar_map_path) and os.path.exists(lcl_radar_metadata_path):
        print("Local radar map data found during initialization.")
        return True  # Indicate success (local files exist)
    else:
        print("Local radar map data not found during initialization. Attempting download.")
        success = load_lcl_radar_map() # Assuming load_lcl_radar_map now returns True/False
        if success:
            print("Radar map data downloaded successfully during initialization.")
            return True
        else:
            print("Failed to load or download radar map data during initialization.")
            return False

initialize_lcl_radar_map()

lcl_radar_map_unavailable = not check_lcl_radar_map_available()
if lcl_radar_map_unavailable:
    display_lcl_radar_error_gui("Local radar map data not found.")
else:
    pass
    print("Local radar map data found during initialization.")

# Create empty xs and ys arrays make them this early to use as a test if len is 0, then program just starting
xs = []
ys = []

# Proceed with the rest of your program
print("Starting main program...")

#ALL_STATIONS_CACHE = None        # list of (id,name,lat,lon,state)
BUOY_METADATA_CACHE = None       # raw list of buoy dicts
BUOY_ID_SET_CACHE = None         # set of buoy ids

# Define a fixed path for the screenshot
SCREENSHOT_PATH = '/home/santod/screenshot.png'
screenshot_filename = 'screenshot.png'   

RANDOM_NWS_API_ENDPOINT = "https://api.weather.gov"
RANDOM_NWS_API_STATIONS_ENDPOINT = f"{RANDOM_NWS_API_ENDPOINT}/stations"
RANDOM_NWS_API_LATEST_OBSERVATION_ENDPOINT = f"{RANDOM_NWS_API_ENDPOINT}/stations/{{station_id}}/observations/latest"

random_map_label = None # to manage the cleaning up of random site map 10/1/25

neighboring_states = {
    "ME": ["NH"],
    "NH": ["ME", "VT", "MA"],
    "VT": ["NH", "MA", "NY"],
    "MA": ["NH", "VT", "NY", "CT", "RI"],
    "RI": ["MA", "CT"],
    "CT": ["MA", "RI", "NY"],
    "NY": ["VT", "MA", "CT", "NJ", "PA"],
    "NJ": ["NY", "PA", "DE"],
    "PA": ["NY", "NJ", "DE", "MD", "WV", "OH"],
    "DE": ["PA", "NJ", "MD"],
    "MD": ["PA", "DE", "WV", "VA", "DC"],
    "DC": ["MD", "VA"],
    "VA": ["MD", "WV", "KY", "TN", "NC", "DC"],
    "WV": ["PA", "MD", "VA", "KY", "OH"],
    "NC": ["VA", "TN", "GA", "SC"],
    "SC": ["NC", "GA"],
    "GA": ["NC", "SC", "FL", "AL", "TN"],
    "FL": ["GA", "AL"],
    "AL": ["TN", "GA", "FL", "MS"],
    "TN": ["KY", "VA", "NC", "GA", "AL", "MS", "AR", "MO"],
    "KY": ["WV", "VA", "TN", "MO", "IL", "IN", "OH"],
    "OH": ["PA", "WV", "KY", "IN", "MI"],
    "MI": ["OH", "IN", "WI"],
    "IN": ["MI", "OH", "KY", "IL"],
    "IL": ["WI", "IN", "KY", "MO", "IA"],
    "WI": ["MI", "IL", "IA", "MN"],
    "MN": ["WI", "IA", "SD", "ND"],
    "IA": ["MN", "WI", "IL", "MO", "NE", "SD"],
    "MO": ["IA", "IL", "KY", "TN", "AR", "OK", "KS", "NE"],
    "AR": ["MO", "TN", "MS", "LA", "TX", "OK"],
    "LA": ["AR", "MS", "TX"],
    "MS": ["TN", "AL", "LA", "AR"],
    "TX": ["OK", "AR", "LA", "NM"],
    "OK": ["KS", "MO", "AR", "TX", "NM", "CO"],
    "KS": ["NE", "MO", "OK", "CO"],
    "NE": ["SD", "IA", "MO", "KS", "CO", "WY"],
    "SD": ["ND", "MN", "IA", "NE", "WY", "MT"],
    "ND": ["MN", "SD", "MT"],
    "MT": ["ND", "SD", "WY", "ID"],
    "WY": ["MT", "SD", "NE", "CO", "UT", "ID"],
    "CO": ["WY", "NE", "KS", "OK", "NM", "UT"],
    "NM": ["CO", "OK", "TX", "AZ", "UT"],
    "AZ": ["CA", "NV", "UT", "NM"],
    "UT": ["ID", "WY", "CO", "NM", "AZ", "NV"],
    "NV": ["ID", "UT", "AZ", "CA", "OR"],
    "ID": ["MT", "WY", "UT", "NV", "OR", "WA"],
    "OR": ["WA", "ID", "NV", "CA"],
    "WA": ["ID", "OR"],
    "CA": ["OR", "NV", "AZ"],
    "AK": [],
    "HI": [],
}


def load_all_stations_cached_dicts(path="/home/santod/stations_metadata.json"):
    global ALL_STATIONS_CACHE_DICTS
    if ALL_STATIONS_CACHE_DICTS is not None:
        return ALL_STATIONS_CACHE_DICTS
    with open(path) as f:
        data = json.load(f)
    ALL_STATIONS_CACHE_DICTS = [
        s for s in data
        if all(k in s for k in ("id","name","latitude","longitude","state"))
    ]
    return ALL_STATIONS_CACHE_DICTS

def load_buoy_metadata_cached(path="/home/santod/buoy_metadata.json"):
    global ALL_BUOY_CACHE
    
    # 1. Create a helper function/block to process the raw data
    def process_buoy_data(data_list):
        """Processes the list of buoy dictionaries into the required formats."""
        # The list of buoy dictionaries (used by find_buoy_help_nearest)
        all_buoys = data_list
        
        # The set of buoy IDs (used for fast lookup)
        buoy_id_set = {b["id"] for b in all_buoys if "id" in b}
        
        # *** NEW: The coordinate map dictionary (used by find_buoy_choice for the final output)
        buoy_coord_map = {
            b["id"]: (b["latitude"], b["longitude"])
            for b in all_buoys
            if "id" in b and "latitude" in b and "longitude" in b
        }
        
        # We now return three items
        return all_buoys, buoy_id_set, buoy_coord_map

    # 2. Check the Cache
    if ALL_BUOY_CACHE is not None:
        # If the cache is primed (it's a list of dictionaries), return the processed formats
        print("Using cached buoy metadata.")
        return process_buoy_data(ALL_BUOY_CACHE)
        
    # 3. Load from File
    print(f"Loading buoy metadata from file: {path}")
    with open(path) as f:
        data = json.load(f)
        
    # 4. Prime the Cache and Return
    ALL_BUOY_CACHE = data
    return process_buoy_data(ALL_BUOY_CACHE)

# Initialize the global image dictionary
available_image_dictionary = {}

last_displayed_index = -1

# Global list of image keys
image_keys = [
    "baro_img", "national_radar_img", "lcl_radar_loop_img", 
    "lightning_img", "still_sat_img", "reg_sat_loop_img", 
    "national_sfc_img", "sfc_plots_img", "radiosonde_img", 
    "vorticity_img", "storm_reports_img",  # Add more keys as needed
]

num_frames = len(image_keys)

state_entry_widgets = {} # to manage two consecutive uppercase letter entries when asked for state IDs
is_buoy_code = False # set to manage upper and lower cases on keyboard

aobs_station_identifier = ""
bobs_station_identifier = ""
cobs_station_identifier = ""
a_town_state = ""
b_town_state = ""
c_town_state = ""

# added to manage as a flag the frequency of scraping updates
atemp = ""
awtemp = ""
awind = ""
btemp = ""
bwtemp = ""
bwind = ""
ctemp = ""
cwtemp = ""
cwind = ""

# Global storage for reg_sat frames in memory to implement swiping 1/13/25
reg_sat_frames = []
sat_reg = 'unknown' # for placing different sized reg_sat loops
reg_sat_animation_id = None #added to manage reg sat loop 1/22/25
REG_SAT_ANIM_GEN = 0 # to manage playback of loop after change with PIL and PhotoImage 8/11/25

# Create buttons with custom font size (adjust font size as needed)
button_font = ("Helvetica", 16, "bold")

global inHg_correction_factor
inHg_correction_factor = 1

global create_virtual_keyboard

current_target_entry = None  # This will hold the currently focused entry widget

# Global declaration of page_choose_choice_vars according to rewriting 3/27/24
page_choose_choice_vars = []

# Initialize hold_box_variables with 0 for the first ten indices
hold_box_variables = [0] * 12  # Creates a list with ten zeros

# Global variable declaration for email functions
global email_entry
email_entry = None

last_land_scrape_time = None # use this to manage update frequency of land obs sites

cobs_only_click_flag = False #set up for buttons to change 1 posted obs at a time
bobs_only_click_flag = False
aobs_only_click_flag = False

refresh_flag = False
# to determine if user has chosen reg sat view
has_submitted_choice = False

# to signal if user has chosen random sites
random_sites_flag = False

lightning_near_me_flag = False # to manage user choice of lightning map

submit_station_plot_center_near_me_flag = False # to manage user choice of sfc plots

show_frame_call_count = 0 # for debugging frame displays while developing swiping
auto_advance_timer = None # for controlling display of images while user is at another frame
update_images_timer = None # Global variable to track the update_images timer

lcl_radar_updated_flag = False # to manage when lcl radar is updated
lcl_radar_animation_id = None # Variable to track the lcl radar animation loop
lcl_radar_url = None # Initialize lcl_radar_url globally
lcl_radar_frames = [] # to hold scraped lcl radar images

reg_sat_updated_flag = False # to manage display of reg sat loop
#calc_padding = "" # to manage cropping frames of regsat loop

executor = ThreadPoolExecutor(max_workers=1) # manage asyncio for if there's a more recent lcl radar

# flag established to track whether img_label_national_radar is forgotten to smooth displays
national_radar_hidden = False

extremes_flag = False
reboot_shutdown_flag = False

radiosonde_updated_flag = False
# variables used in extremes functions
# Counters for tracking observations
initial_successful_fetches = 0
successful_metar_parse = 0
successful_retries = 0

aobs_buoy_code = bobs_buoy_code = cobs_buoy_code = ""
aobs_buoy_signal = bobs_buoy_signal = cobs_buoy_signal = False
buoy_help_flag = None # to manage progression through obs choices after user has asked for help with buoy codes

# Global variables for images
#img_tk_national_radar = None
img_label_national_radar = None
img_label_lg_still_satellite = None
img_label_satellite = None
baro_img_label = None

img_label = None # added 7/11/24 while working on saving dead end runs. Lightning & Station plots

label_lcl_radar = None # to manage transition from ntl radar to lightning this had to be defined too

# variables used to manage updates with swiping 1/3/25
# Initialize last update times
last_baro_update = None
last_radar_update = None
last_lcl_radar_update = None
last_lightning_update = None
last_national_sfc_update = None
last_vorticity_update = None
last_satellite_update = None
last_still_sat_update = None
last_reg_sat_update = None
last_sfc_plots_update = None
last_radiosonde_update = None
last_radiosonde_update_check = None # this variable holds when the code last checked for an update, to monitor 00Z and 12Z
last_vorticity_update
last_storm_reports_update = None

satellite_idx = 0  # Initialize satellite index globally

# set GUI buttons to None
scraped_to_frame1 = None
maps_only_button = None
pic_email_button = None
reboot_button = None
extremes_button = None

message_label = None #this is to message user when chosen lcl radar isn't functioning

# for lightning display when scraped with selenium
lightning_max_retries = 2

global lightning_scraping_in_progress # added 8/31/25 to prevent backed up requests to scrape
lightning_scraping_in_progress = False

last_forget_clock = datetime.now()

i = 0

alternative_town_1 = ""
alternative_state_1 = ""

alternative_town_2 = ""
alternative_state_2 = ""

alternative_town_3 = ""
alternative_state_3 = ""

def monitor_system_health():
    global last_monitor_check, LAST_DISPLAY_FRAME_RESET_TIME
    current_time = datetime.now()

    # Run check every 5 minutes
    if last_monitor_check is None or (current_time - last_monitor_check) >= timedelta(minutes=5):
        last_monitor_check = current_time  # Update last check time

        #print("[MONITOR] Running system health check...")

        # --- NEW: Step 1: Force Garbage Collection ---
        # This is a good practice for long-running applications to manually
        # clean up any memory that might not have been released automatically.
        try:
            #print("[MONITOR] Forcing garbage collection...")
            collected_count = gc.collect()
            #print(f"[MONITOR] Garbage collector freed {collected_count} objects.")
        except Exception as e:
            print(f"[MONITOR] An error occurred during garbage collection: {e}")
        # --- END OF NEW LOGIC ---

        # Step 2: Check if WiFi is up
        try:
            subprocess.run(["ping", "-c", "1", "google.com"], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            network_up = True
        except subprocess.CalledProcessError:
            network_up = False

        if not network_up:
            print("[MONITOR] WiFi is down. Restarting network and clearing headless Chrome instances...")

            # Kill only headless Chromium processes
            try:
                ps_output = subprocess.check_output(["ps", "aux"], text=True)
                for line in ps_output.strip().split("\n"):
                    if "chromium" in line and "--headless" in line:
                        parts = line.split()
                        if len(parts) >= 2 and parts[1].isdigit():
                            pid = parts[1]
                            print(f"[MONITOR] Killing headless Chrome PID {pid} due to WiFi failure.")
                            subprocess.run(["sudo", "kill", "-9", pid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except subprocess.CalledProcessError:
                pass
                #print("[MONITOR] No headless Chromium processes found.")

            # Restart NetworkManager
            subprocess.run(["sudo", "systemctl", "restart", "NetworkManager"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return

        # Step 3: Find only headless Chromium processes
        chrome_pids = []
        try:
            ps_output = subprocess.check_output(["ps", "aux"], text=True)
            for line in ps_output.strip().split("\n"):
                if "chromium" in line and "--headless" in line:
                    parts = line.split()
                    if len(parts) >= 2 and parts[1].isdigit():
                        chrome_pids.append(parts[1])
        except subprocess.CalledProcessError:
            pass

        # Step 4: Check runtime for each Chrome instance
        def get_process_runtime(pid):
            try:
                secs = int(subprocess.check_output(["ps", "-o", "etimes=", "-p", pid], text=True).strip())
                return secs // 60
            except subprocess.CalledProcessError:
                return None

        stuck_pids = []
        for pid in chrome_pids:
            runtime = get_process_runtime(pid)
            if runtime and runtime >= 5:
                #print(f"[MONITOR] Chrome PID {pid} running for {runtime} minutes. Marked for termination.")
                stuck_pids.append(pid)
        
        # NOTE: The file descriptor check was removed for simplicity as the runtime
        # check is the most critical part for preventing CPU exhaustion.

        # Step 5: Kill stuck processes
        if stuck_pids:
            #print(f"[MONITOR] Killing {len(stuck_pids)} Chrome instances: {', '.join(stuck_pids)}")
            for pid in stuck_pids:
                subprocess.run(["sudo", "kill", "-9", pid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                
        # Step 6: Kill orphaned chromedriver processes (more than 5 minutes old)
        try:
            driver_pids = subprocess.check_output(["pgrep", "-f", "chromedriver.*--port"], text=True).strip().split("\n")
            driver_pids = [pid for pid in driver_pids if pid.isdigit()]
            
            for pid in driver_pids:
                runtime = get_process_runtime(pid)
                if runtime and runtime >= 5:
                    #print(f"[MONITOR] ChromeDriver PID {pid} running for {runtime} minutes. Killing it.")
                    subprocess.run(["sudo", "kill", "-9", pid], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        except subprocess.CalledProcessError:
            pass  # No chromedriver processes found
            
        #7 Step 7: destroy/recreate display frame
        if datetime.now() - LAST_DISPLAY_FRAME_RESET_TIME > timedelta(minutes=62):
            recreate_display_image_frame()
            LAST_DISPLAY_FRAME_RESET_TIME = datetime.now()

    else:
        pass

def reboot_system():
    root.quit()
    os.system('sudo reboot')
    
def shutdown_system():
    root.quit()
    os.system('sudo shutdown now')
    
def toggle_fullscreen(event=None):
    """Toggles the Tkinter window's fullscreen state."""
    global fullscreen_state
    # Invert the current state (True becomes False, False becomes True)
    fullscreen_state = not fullscreen_state
    root.attributes("-fullscreen", fullscreen_state)

def check_password(event):
    """Checks the typed key sequence against the password."""
    global key_sequence
    # Ignore modifier keys and only append character keys
    if event.char:
        key_sequence += event.char

    # Define your password. This can be a hardcoded default or a variable
    # fetched from your server, like FULLSCREEN_BREAK_PASSWORD.
    password = '2barbaraterminal'

    # Check if the correct sequence was entered
    if key_sequence.endswith(password):
        toggle_fullscreen()  # Call the new toggle function
        key_sequence = ''    # Reset sequence after a successful entry
    elif len(key_sequence) > len(password):
        # Keep the sequence from getting too long to save memory
        key_sequence = key_sequence[-len(password):]

def start_fullscreen():
    """Initializes the window to a fullscreen state."""
    global fullscreen_state
    root.geometry("1024x600")
    root.title("The Weather Observer")
    root.attributes('-fullscreen', True)
    fullscreen_state = True # Set the initial state to True

# --- Main Setup ---

# Create a tkinter window
root = tk.Tk()
root.title("The Weather Observer")
root.geometry("1024x576+0+-1")

# Initialize state and sequence variables
key_sequence = ''
fullscreen_state = False # Default state before fullscreen starts

# Bind all keypresses to the check_password function
root.bind('<Key>', check_password)

# Set up fullscreen after a 4-second delay
root.after(4000, start_fullscreen)

lcl_radar_zoom_clicks = tk.IntVar(value=0) # establish variable for zoom on lcl radar

# Define StringVar for labels
left_site_text = tk.StringVar()
left_temp_text = tk.StringVar()
left_water_temp_text = tk.StringVar()
left_wind_text = tk.StringVar()
left_combined_text = tk.StringVar()

middle_site_text = tk.StringVar()
middle_temp_text = tk.StringVar()
middle_water_temp_text = tk.StringVar()
middle_wind_text = tk.StringVar()
middle_combined_text = tk.StringVar()

right_site_text = tk.StringVar()
right_temp_text = tk.StringVar()
right_water_temp_text = tk.StringVar()
right_wind_text = tk.StringVar()
right_combined_text = tk.StringVar()

timestamp_text = tk.StringVar()

persistent_widgets = {} # used to manage reusable widgets in transparent frame

# Use a smaller font for the buoys
buoy_font = font.Font(family="Helvetica", size=11, weight="bold")

# Use the default font size (14) for the regular condition when posting observations
obs_font = font.Font(family="Helvetica", size=14, weight="bold")

# Set the background color in Tkinter to light blue
tk_background_color = "lightblue"
root.configure(bg=tk_background_color)

# Create a frame to serve as the transparent overlay
transparent_frame = tk.Frame(root, bg=tk_background_color, bd=0, highlightthickness=0)
transparent_frame.grid(row=0, column=0, sticky="nw")
# Make the frame transparent by setting its background color and border
transparent_frame.config(bg=tk_background_color, bd=0, highlightthickness=0)

# Create a Matplotlib figure and axis
fig = Figure(figsize=(12.5, 6))
ax = fig.add_subplot(1, 1, 1)

# Set the background color of matplotlib to match Tkinter
fig.patch.set_facecolor(tk_background_color)

# Create a frame for the barograph
baro_frame = tk.Frame(root, width=12.5, height=6)

# Embed the Matplotlib figure in a tkinter frame
canvas = FigureCanvasTkAgg(fig, master=baro_frame)
canvas_widget = canvas.get_tk_widget()
# Use next line to position matplotlib in window. pady pushes inmage down from top
canvas_widget.grid(row=1, column=0, padx=(20,0), pady=15, sticky="s")

# Set the background color of the frame to light blue
baro_frame.configure(bg=tk_background_color)

# Create main user GUI frame
frame1 = tk.Frame(root, bg=tk_background_color)
frame1.grid(row=0, column=0)
root.grid_rowconfigure(0, weight=1)
root.grid_columnconfigure(0, weight=1)

def reboot_shutdown_option_display():
    global reboot_shutdown_flag, timestamp_text, refresh_flag
    
    reboot_shutdown_flag = refresh_flag = True
    
    #transparent_frame.grid_forget()
    function_button_frame.grid_forget()
    baro_frame.grid_forget()
    transparent_frame.grid_forget()
      
    # _forget all frames displaying maps and images
    forget_all_frames()
      
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")
    root.grid_rowconfigure(0, weight=0)
    root.grid_columnconfigure(0, weight=0)
    root.geometry('1024x600')
    
    # --- Create Static Labels (Logo and Timestamp) ---
    logo_font = font.Font(family="Helvetica", size=16, weight="bold")
    logo_label = tk.Label(frame1, text="The\nWeather\nObserver", fg="black", bg=tk_background_color, font=logo_font, anchor="w", justify="left")
    logo_label.grid(row=0, column=0, padx=10, pady=5, sticky='w')

    time_stamp_font = font.Font(family="Helvetica", size=8, weight="normal", slant="italic")
    timestamp_label = tk.Label(frame1, textvariable=timestamp_text, fg="black", bg=tk_background_color, font=time_stamp_font, anchor="w", justify="left")
    timestamp_label.grid(row=0, column=0, padx=120, pady=(17, 5), sticky='w')
    
    instructions_label = tk.Label(frame1, text=f"Please choose to REBOOT, SHUTDOWN, or RETURN to images", font=("Helvetica", 14), bg=tk_background_color, justify="left")
    instructions_label.grid(row=1, column=0, columnspan=2, padx=50, pady=50, sticky='nw')
    
    # Create the 'Back' button
    reboot_button = tk.Button(frame1, text=" Reboot ", font=button_font, command=reboot_system)
    reboot_button.grid(row=1, column=0, columnspan=20, padx=(50, 0), pady=100, sticky="w")

    shutdown_button = tk.Button(frame1, text="Shutdown", command=shutdown_system, font=button_font)
    shutdown_button.grid(row=1, column=0, columnspan=20, padx=200, pady=100, sticky='nw')
    
    return_button = tk.Button(frame1, text="Return", command=return_to_image_cycle, font=button_font)
    return_button.grid(row=1, column=0, columnspan=20, padx=360, pady=100, sticky='nw')

def process_obs_data_queue():
    """
    Drain all pending results each tick. Apply only to the *current* A/B/C
    selections. Discard stale keys so the queue cannot backlog.
    """
    try:
        updated_any = False
        while True:
            try:
                result_dict = data_update_queue.get_nowait()
            except Empty:
                break  # queue fully drained

            # A
            if not aobs_buoy_signal and aobs_station_identifier and aobs_station_identifier in result_dict:
                atemp, awind = result_dict[aobs_station_identifier]
                globals()['atemp'], globals()['awind'] = atemp, awind
                updated_any = True
            elif aobs_buoy_signal and aobs_buoy_code and aobs_buoy_code in result_dict:
                atemp, awtemp, awind = result_dict[aobs_buoy_code]
                globals()['atemp'], globals()['awtemp'], globals()['awind'] = atemp, awtemp, awind
                updated_any = True

            # B
            if not bobs_buoy_signal and bobs_station_identifier and bobs_station_identifier in result_dict:
                btemp, bwind = result_dict[bobs_station_identifier]
                globals()['btemp'], globals()['bwind'] = btemp, bwind
                updated_any = True
            elif bobs_buoy_signal and bobs_buoy_code and bobs_buoy_code in result_dict:
                btemp, bwtemp, bwind = result_dict[bobs_buoy_code]
                globals()['btemp'], globals()['bwtemp'], globals()['bwind'] = btemp, bwtemp, bwind
                updated_any = True

            # C
            if not cobs_buoy_signal and cobs_station_identifier and cobs_station_identifier in result_dict:
                ctemp, cwind = result_dict[cobs_station_identifier]
                globals()['ctemp'], globals()['cwind'] = ctemp, cwind
                updated_any = True
            elif cobs_buoy_signal and cobs_buoy_code and cobs_buoy_code in result_dict:
                ctemp, cwtemp, cwind = result_dict[cobs_buoy_code]
                globals()['ctemp'], globals()['cwtemp'], globals()['cwind'] = ctemp, cwtemp, cwind
                updated_any = True

        # Optional: refresh UI only if something changed
        if updated_any:
            try:
                update_transparent_frame_data()
            except Exception:
                pass

    except Exception as e:
        print(f"Error processing data update queue: {e}")
    finally:
        frame1.after(100, process_obs_data_queue)

# This ensures the queue processor is started only once.
if 'queue_processor_started' not in globals() or not queue_processor_started:
    #print("[INFO] Starting the background data queue processor...")
    process_obs_data_queue()
    queue_processor_started = True

# Create frame for function buttons and a function to display it
function_button_frame = tk.Frame(root, bg=tk_background_color, bd=0, highlightthickness=0)

display_label = None

# Create the display_image_frame
display_image_frame = tk.Frame(root, width=950, height=515, bg=tk_background_color, bd=0)  # , highlightthickness=0)
display_image_frame.grid(row=0, column=0, padx=0, pady=0, sticky="se")  # ← ✅ INSERTED HERE

# Configure resizing behavior for the root window and frame
root.grid_rowconfigure(0, weight=0)
root.grid_columnconfigure(0, weight=0)

# Create the display_label inside the frame
display_label = tk.Label(display_image_frame, bg=tk_background_color, bd=0, highlightthickness=0)
display_label.grid(row=0, column=0, padx=0, pady=0, sticky="se")

DISPLAY_FRAME_RESET_IN_PROGRESS = False
LAST_DISPLAY_FRAME_RESET_TIME = datetime.now() - timedelta(days=1)

def setup_function_button_frame():
    global scraped_to_frame1, maps_only_button, extremes_button, pic_email_button, reboot_button

    root.grid_rowconfigure(0, weight=0)
    root.grid_columnconfigure(0, weight=0)
    
    scraped_to_frame1 = ttk.Button(function_button_frame, text="   Change\nObservation\n    Sites &\n     Maps", command=refresh_choices)
    maps_only_button = ttk.Button(function_button_frame, text=" \n    Change\n  Maps Only \n", command=change_maps_only)
    extremes_button = ttk.Button(function_button_frame, text=' \n    Display  \n  Extremes  \n', command=find_and_display_extremes)
    #pic_email_button = ttk.Button(function_button_frame, text=" \n    Share a \n Screenshot \n", command=pic_email)
    pic_email_button = ttk.Button(function_button_frame, text=" \n    Share a \n Screenshot \n", command=show_fb_login_screen)
    reboot_button = ttk.Button(function_button_frame, text="   Reboot/ \n  Shutdown \n", command=reboot_shutdown_option_display)

# Reuse the buttons when showing the frame
def show_function_button_frame():
    function_button_frame.grid(row=0, column=0, sticky='nw')

    root.grid_rowconfigure(0, weight=0)
    root.grid_columnconfigure(0, weight=0)

    scraped_to_frame1.grid(row=0, column=0, padx=15, pady=(125, 0), sticky='nw')
    maps_only_button.grid(row=0, column=0, padx=15, pady=(215, 0), sticky='nw')
    extremes_button.grid(row=0, column=0, padx=15, pady=(305, 0), sticky='nw')
    pic_email_button.grid(row=0, column=0, padx=15, pady=(395, 0), sticky='nw')
    reboot_button.grid(row=0, column=0, padx=15, pady=(520, 0), sticky='nw')

def recreate_display_image_frame():
    global display_image_frame, display_label, DISPLAY_FRAME_RESET_IN_PROGRESS

    DISPLAY_FRAME_RESET_IN_PROGRESS = True
    #print("[RESET] Rebuilding display_image_frame...")

    try:
        for widget in display_image_frame.winfo_children():
            widget.destroy()
        display_image_frame.destroy()

        # Recreate the frame and grid it exactly like original
        display_image_frame = tk.Frame(root, width=950, height=515, bg=tk_background_color, bd=0)
        display_image_frame.grid(row=0, column=0, padx=(140,0), pady=(75,0), sticky="sw")  # ← Make sure this is identical

        # Ensure grid config remains correct
        root.grid_rowconfigure(0, weight=0)
        root.grid_columnconfigure(0, weight=0)

        # Recreate and place the label inside
        display_label = tk.Label(display_image_frame, bg=tk_background_color, bd=0, highlightthickness=0)
        display_label.grid(row=0, column=0, padx=70, pady=(0,0), sticky="sw")  # ← Initial placement

        display_image_frame.lift()  # ← (optional) Ensures it's on top

        #print("[RESET] display_image_frame successfully rebuilt.")

        # Cancel and restart auto-advance timer
        try:
            global auto_advance_timer
            if auto_advance_timer is not None:
                root.after_cancel(auto_advance_timer)
                auto_advance_timer = None
            auto_advance_timer = root.after(22000, auto_advance_frames)
            #print("[RESET] Auto-advance timer restarted.")
        except Exception as e:
            print(f"[ERROR] Failed to reset auto-advance timer: {e}")

    except Exception as e:
        print(f"[ERROR] Failed to reset display_image_frame: {e}")
        import traceback; traceback.print_exc()

    display_image_frame.tkraise()

    DISPLAY_FRAME_RESET_IN_PROGRESS = False

def set_state_uppercase():
    global shift_active
    shift_active = True
    update_keyboard_shift_state()
    
shift_active = True # Start with shift active
keyboard_buttons = {} # to handle upper and lower case
shifted_keys = { # Now globally defined
  '1': '!', '2': '@', '3': '#', '4': '$', '5': '%',
  '6': '^', '7': '&', '8': '*', '9': '(', '0': ')',
  ';': ':', "'": '"', ',': '<', '.': '>'
}

def auto_capitalize():
    global current_target_entry, shift_active, state_entry_widgets, is_buoy_code

    # Don't change shift state automatically if it's a state entry field
    if current_target_entry in state_entry_widgets.values():
        shift_active = True # Keep it uppercase for state entries
        update_keyboard_shift_state()
        return # Exit early for state entries

    # Special handling for buoy codes (assuming they might need uppercase/numbers only?)
    # Adjust this logic based on exact buoy code requirements if needed.
    # For now, let's assume standard auto-cap rules don't apply strictly.
    if is_buoy_code:
        # Maybe force uppercase or handle differently? For now, let shift toggle normally.
        # shift_active = True # Example: force uppercase if needed for buoy codes
        # update_keyboard_shift_state()
        return # Or apply specific rules

    # Standard auto-capitalize for other fields
    if current_target_entry is not None:
        content = current_target_entry.get("1.0", "end-1c") if isinstance(current_target_entry, tk.Text) else current_target_entry.get()
        # Check if the content is empty or ends with sentence-ending punctuation followed by optional space/newline
        if not content or content.endswith(('.', '. ', '.\n', '!', '! ', '!\n', '?', '? ', '?\n')):
            if not shift_active: # Only update if it's currently false
               shift_active = True
               update_keyboard_shift_state()
        else:
            # Only turn off shift if it was on due to auto-cap, allow manual shift to persist
            # This is tricky. Let's simplify: if not ending with punctuation, default to lowercase *unless* manually shifted.
            # The manual shift state is handled by the Shift key press itself.
            # So, auto_capitalize primarily turns *on* capitalization.
            # The logic to turn it *off* after one letter should be removed from key_pressed.
            pass # Let manual shift state persist or be toggled by Shift key

def capitalize_next_letter(event):
    char = event.char
    if char.isalpha():
        current_target_entry.insert("insert", char.upper())
        return "break" # Stop the event from inserting the character again

def set_keyboard_target(widget):
    """
    Sets the target entry for keyboard input and updates the 
    virtual keyboard's state based on the focused widget.
    """
    global current_target_entry, state_entry_widgets, is_buoy_code, shift_active # Added shift_active as it's modified here

    # Defensive check: Ensure the widget passed actually exists before using it
    try:
        widget.winfo_exists() 
    except tk.TclError:
        print(f"set_keyboard_target: Widget {widget} no longer exists.")
        # Optional: Decide if current_target_entry should be cleared if the widget is invalid
        # current_target_entry = None 
        return # Stop processing if widget is invalid

    print(f"Setting keyboard target to: {widget}") # Debugging print
    current_target_entry = widget 
         
    auto_capitalize() # Apply auto-cap rules or specific field rules
    update_keyboard_shift_state() # Update keyboard appearance based on the determined state

def key_pressed(key_value):
    global current_target_entry, shift_active, keyboard_buttons, shifted_keys, is_buoy_code, state_entry_widgets

    if current_target_entry:
        if key_value == 'Backspace':
            if isinstance(current_target_entry, tk.Text):
                # Check if the character being deleted is the one that triggered auto-cap off
                # This requires more complex state tracking, maybe skip for simplicity first.
                current_target_entry.delete("insert -1 chars", "insert")
            elif isinstance(current_target_entry, tk.Entry):
                current_pos = current_target_entry.index(tk.INSERT)
                if current_pos > 0:
                    current_target_entry.delete(current_pos - 1, current_pos)
            # After backspace, re-evaluate capitalization for the *next* char
            auto_capitalize()
            update_keyboard_shift_state()

        elif key_value == 'Space':
            current_target_entry.insert("insert", ' ')
            # Check if auto-capitalization is needed after the space
            auto_capitalize()
            update_keyboard_shift_state()

        elif key_value == 'Tab':
            # Focus change should be handled by set_current_target via focus bindings
            current_target_entry.tk_focusNext().focus_set()

        elif key_value == 'Shift':
            shift_active = not shift_active
            # Handle state entry specific behavior: If it's a state field, shift *always* means uppercase keys visually
            if current_target_entry in state_entry_widgets.values():
                shift_active = True # Keep shift logically true for state entries? Or just visually? Let's stick to visual for now.
            update_keyboard_shift_state() # Update appearance immediately

        # Handle @gmail.com button specifically if needed
        elif key_value == '@gmail.com':
             current_target_entry.insert("insert", "@gmail.com")
             auto_capitalize() # Check state after inserting
             update_keyboard_shift_state()

        else: # Handle letters, numbers, and symbols
            actual_value = None
            # *** FIX 1: Use shifted_keys for insertion ***
            if key_value in shifted_keys:
                # Use shifted symbol if shift is active, otherwise the base key (number)
                actual_value = shifted_keys[key_value] if shift_active else key_value
            elif key_value.isalpha():
                # Handle letter casing based on shift state
                # Special case: State entries always insert uppercase
                if current_target_entry in state_entry_widgets.values():
                     actual_value = key_value.upper()
                     # Optional: Limit state entry to 2 chars
                     # if len(current_target_entry.get()) >= 2: return # Prevent typing more than 2
                else:
                    actual_value = key_value.upper() if shift_active else key_value.lower()
            else:
                # Handle other keys like '.', '?' - insert them directly
                # Consider if Shift should affect them (e.g., shift+? might be different)
                # For now, assume they aren't affected by shift unless in shifted_keys
                actual_value = key_value

            if actual_value:
                current_target_entry.insert("insert", actual_value)

            # Apply town entry lowercase conversion (if still needed and not a state entry)
            if isinstance(current_target_entry, tk.Entry) and \
               not is_buoy_code and \
               current_target_entry not in state_entry_widgets.values() and \
               len(current_target_entry.get()) > 1 and \
               key_value.isalpha(): # Only apply if a letter was just added
                  # This logic might need refinement depending on exact requirements
                  # For simplicity, let's assume it only runs if the second char is typed lowercase
                  pass # Or re-implement the specific lowercase logic if required. Be careful it doesn't conflict.

            # Re-evaluate auto-capitalization for the *next* character
            # Exception: Don't auto-lower if it's a state field
            if current_target_entry not in state_entry_widgets.values():
                auto_capitalize() # Update shift state based on the newly inserted character
                update_keyboard_shift_state() # Update keyboard appearance

def update_keyboard_shift_state():
    global shift_active, keyboard_buttons, shifted_keys, current_target_entry, state_entry_widgets

    is_state_entry = current_target_entry and current_target_entry in state_entry_widgets.values()

    for key, button in keyboard_buttons.items():
        if key.isnumeric(): # Handle numbers/symbols first
             button.config(text=shifted_keys[key] if shift_active else key)
        elif key.isalpha():
             # State entries always show uppercase letters on keys
             if is_state_entry:
                 button.config(text=key.upper())
             else:
                 button.config(text=key.upper() if shift_active else key.lower())
        # else: handle other non-alpha, non-numeric keys like '.', '?' if needed
        # Ensure Shift key itself doesn't change text, or indicates state
        elif key == 'Shift':
             # Optional: change Shift key appearance based on shift_active
             button.config(relief=tk.SUNKEN if shift_active else tk.RAISED)
             pass # Keep text as "Shift"

def create_virtual_keyboard(parent, start_row):
    # Prepare frame1 for grid layout for the keyboard and other elements
    for i in range(20):  # Match this with total_columns in create_virtual_keyboard
        frame1.grid_columnconfigure(i, weight=0)  # change to zero to adjust placement of extremes map

    global shift_active, keyboard_buttons
    keyboard_layout = [
        ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'Backspace'],
        ['Tab', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '@gmail.com'],
        ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ';', "'", ],
        ['Shift', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '?', 'Shift']
    ]

    key_widths = {
        'Backspace': 7,
        '@gmail.com': 8,
        'Tab': 5,
        'Shift': 5,
        'Space': 45  # Adjusted length for the space bar
    }

    default_width = 5  # Uniform key width
    default_height = 2  # Assuming a uniform height for all keys

    global_padx = 50  # Set the padx to align with the text elements

    keyboard_buttons = {}  # Initialize keyboard_buttons as a dictionary

    for i, row in enumerate(keyboard_layout):
        padx_value = 5  # Default padx for each row

        if row[0] == 'A' or row[0] == 'Z':
            padx_value = 73  # Adjusted padx for 'A' and 'Z' rows for alignment

        # Add pady only to the first row to push it down
        pady_value = 1 if i == 0 else 0  # Add padding only to the top row

        for j, key in enumerate(row):
            width = key_widths.get(key, default_width)
            incremental_padx = padx_value + (j * 68)  # The refined 68-unit offset

            # Determine the text for the button based on whether it's a letter
            button_text = key.upper() if key.isalpha() else key
            btn = tk.Button(parent, text=button_text, command=lambda k=key: key_pressed(k), width=width, height=default_height)
            btn.grid(row=start_row + i, column=0, padx=(global_padx + incremental_padx), pady=(pady_value, 0), sticky="w")
            keyboard_buttons[key] = btn  # Store the button reference

    # Space bar placed independently
    space_bar = tk.Button(parent, text="Space", command=lambda: key_pressed(" "), width=key_widths['Space'], height=default_height)
    space_bar.grid(row=start_row + len(keyboard_layout), column=0, padx=(global_padx + 150), pady=(0, 5), sticky="w")
    keyboard_buttons['Space'] = space_bar  # Store the space bar reference

  
def clear_frame(frame1):
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()

def close_GUI():
    root.destroy()

def refresh_choices():
    global alternative_town_1, alternative_state_1, alternative_town_2, alternative_state_2, alternative_town_3, alternative_state_3   
    global refresh_flag, box_variables, lcl_radar_frames, reg_sat_frames, available_image_dictionary, lcl_radar_updated_flag, last_lcl_radar_update, reg_sat_updated_flag
    global img_label_lg_still_satellite, label_lcl_radar,  img_label_national_radar, baro_img_label, img_label_sfc_map, lcl_radar_animation_id, reg_sat_animation_id
    
    refresh_flag = True
    lcl_radar_updated_flag = False
    last_lcl_radar_update = datetime.now() - timedelta(seconds=181)  # Force the timer to be expired
    reg_sat_updated_flag = False

    # Clear existing radar and satellite loops
    lcl_radar_frames.clear()
    reg_sat_frames.clear()
    
    try:
        root.after_cancel(lcl_radar_animation_id)
        lcl_radar_animation_id = None
        
        if display_label:
            display_label.configure(image='')
            display_label.image = None

        #print("[INFO] Canceled existing LCL radar animation.")
    except Exception as e:
        pass
        #print(f"[INFO] No active radar animation to cancel: {e}")
    
    # Clear the current LCL radar loop from the image dictionary, if it exists
    if 'lcl_radar_loop_img' in available_image_dictionary:
        available_image_dictionary['lcl_radar_loop_img'].clear()

    try:
        root.after_cancel(reg_sat_animation_id)
        reg_sat_animation_id = None
        #print("[INFO] Canceled existing REG SAT animation.")
    except Exception as e:
        pass
        #print(f"[INFO] No active reg_sat animation to cancel: {e}")
        
    if 'reg_sat_loop_img' in available_image_dictionary:
        available_image_dictionary['reg_sat_loop_img'].clear()

    transparent_frame.grid_forget()
    forget_all_frames()
    # Don't destroy display frames during loop displays will crash        
    function_button_frame.grid_forget()

    #avoid getting stuck trying to display radiosonde while user updates display choices
    box_variables[8] = 0
        
    frame1.grid(row=0, column=0, sticky="nsew") 
    
    alternative_town_1 = " "
    alternative_state_1 = " "

    alternative_town_2 = " "
    alternative_state_2 = " "

    alternative_town_3 = " "
    alternative_state_3 = " "

    land_or_buoy()

def change_maps_only():
    global refresh_flag, baro_img_label, img_label_national_radar
    global label_lcl_radar, img_label_lg_still_satellite, img_label_sfc_map, lcl_radar_updated_flag, last_lcl_radar_update, reg_sat_updated_flag
    global box_variables, lcl_radar_frames, reg_sat_frames, available_image_dictionary, lcl_radar_animation_id, reg_sat_animation_id

    refresh_flag = True
    lcl_radar_updated_flag = False
    last_lcl_radar_update = datetime.now() - timedelta(seconds=181)  # Force the timer to be expired
    reg_sat_updated_flag = False

    # Clear existing frames to avoid displaying stale data
    lcl_radar_frames.clear()
    reg_sat_frames.clear()
    
    try:
        root.after_cancel(lcl_radar_animation_id)
        lcl_radar_animation_id = None
        
        if display_label:
            display_label.configure(image='')
            display_label.image = None
        
        #print("[INFO] Canceled existing LCL radar animation.")
    except Exception as e:
        pass
        #print(f"[INFO] No active radar animation to cancel: {e}")

    if 'lcl_radar_loop_img' in available_image_dictionary:
        available_image_dictionary['lcl_radar_loop_img'].clear()

    try:
        root.after_cancel(reg_sat_animation_id)
        reg_sat_animation_id = None

        #print("[INFO] Canceled existing REG SAT animation.")
    except Exception as e:
        pass
        #print(f"[INFO] No active reg_sat animation to cancel: {e}")
        
    if 'reg_sat_loop_img' in available_image_dictionary:
        available_image_dictionary['reg_sat_loop_img'].clear()

    transparent_frame.grid_forget()
    forget_all_frames()

    # Don't destroy scraped frame during loop displays will crash       
    baro_frame.grid_forget()
    function_button_frame.grid_forget()
    
    # Avoid getting stuck trying to display radiosonde while user updates display choices
    box_variables[8] = 0

    frame1.grid(row=0, column=0, sticky="nsew")
    
    page_choose()
    
    # Function to display the map image in a Tkinter window
def display_extremes_map_image():
    global extremes_flag
    
    #transparent_frame.grid_forget()
    function_button_frame.grid_forget()
    baro_frame.grid_forget()
      
    # _forget all frames displaying maps and images
    forget_all_frames()
      
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")
    root.grid_rowconfigure(0, weight=0)
    root.grid_columnconfigure(0, weight=0)
    root.geometry('1024x600')

    # show obs from transparent frame while displaying extremes map
    transparent_frame.grid(row=0, column=0, sticky="nw")
    root.grid_rowconfigure(0, weight=0)
    root.grid_columnconfigure(0, weight=0)
    update_transparent_frame_data()

    # Define the URL (you already have this)
    extremes_map_image_url = "https://weatherobserver.duckdns.org/extremes_station_map_resized.png"

    # Define the local save path (you already have this)
    local_extremes_map_filename = "/home/santod/downloaded_extremes_map.png"
    
    try:
        extremes_map_response = requests.get(extremes_map_image_url, stream=True, timeout=15)
        if extremes_map_response.status_code == 200:
            with open(local_extremes_map_filename, 'wb') as extremes_map_file:
                for extremes_map_chunk in extremes_map_response.iter_content(chunk_size=8192):
                    extremes_map_file.write(extremes_map_chunk)
            print(f"Extremes map image successfully downloaded and saved as: {local_extremes_map_filename}")

            # Open the downloaded image
            img = Image.open(local_extremes_map_filename)

            # Create a PhotoImage object from the image
            tk_img = ImageTk.PhotoImage(img)

            # Create a label to display the image
            label = tk.Label(frame1, image=tk_img, bg=tk_background_color)
            label.image = tk_img  # Keep a reference!

            # Place the label in the frame, centered at the bottom with no padding
            label.grid(row=0, column=0, padx=0, pady=75, sticky="w")

        else:
            print(f"Error: Failed to download... Status code: {extremes_map_response.status_code}")
            print(f"Response text: {extremes_map_response.text}")
    except requests.exceptions.RequestException as e:
        print(f"Error: A network request exception occurred...: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        
    extreme_text = f"Click\nReturn to\nget back\nto images."
    extreme_label = tk.Label(frame1, text=extreme_text, font=("DejaVu Sans", 14), bg=tk_background_color, justify="left")
    extreme_label.grid(row=0, column=0, padx=50, pady=(270,0), sticky="nw")
    
    # get rid of red extremes pause button
    extremes_button_on.grid_forget()
    
    # Buttons for screenshot and email
    pic_email_button = tk.Button(frame1, text=" \n Share a \nScreenshot\n", command=show_fb_login_screen)
    pic_email_button.grid(row=0, column=0, padx=(50, 0), pady=(380,0), sticky='nw') 
    
    # Create a return button to return to scraped frame
    return_button = tk.Button(frame1, text="Return", command=return_to_image_cycle, font=("Helvetica", 16, "bold"))
    return_button.grid(row=0, column=0, padx=(50, 0), pady=(500, 0), sticky="nw")

    # optional: freeze current band size so it can't balloon when busy
    root.update_idletasks()
    transparent_frame.grid_propagate(False)
    transparent_frame.configure(width=transparent_frame.winfo_width(),
                                height=transparent_frame.winfo_height())

    # schedule z-order after a tick
    root.after(50, transparent_frame.tkraise)   # use frame1.tkraise if you want the map on top

def find_and_display_extremes():
    global extremes_flag, extremes_button_on
    extremes_flag = True

    # Create a standard tk.Button with centered text, explicitly using tk.Button
    # to avoid collision with matplotlib.widgets.Button.
    extremes_button_on = tk.Button(function_button_frame, text='Please\nPause.\nMap is\nGenerating',  
                                   bg="#FF9999", fg="white", justify='center', anchor='center',
                                   padx=0, width=11,
                                   command=find_and_display_extremes)

    extremes_button_on.grid(row=0, column=0, padx=15, pady=(305,0), sticky='nw')
    function_button_frame.update_idletasks()
    
    display_extremes_map_image()

def submit_pic_email():
    global email_entry  # Declare the use of the global variable
    
    to_email = email_entry.get()  # Get the email address from the entry widget
    if not to_email:
        print("No email address provided.")
        return

    # Email details
    from_email = 'picturesfromtheweatherobserver@gmail.com'
    subject = 'Weather Observer Screenshot - Do Not Reply'
    body = 'Attached is the screenshot from the Weather Observer.'

    # Set up the email message
    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    # Attach the screenshot
    with open(screenshot_filename, 'rb') as attachment:
        img = MIMEImage(attachment.read(), name=screenshot_filename)
        msg.attach(img)

    # For example:
    try:
        # Connect to Gmail's SMTP server and send the email
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        server.login(from_email, 'apedhdhxnyhkfepv')  # Use your app password
        #server.login(from_email, os.getenv('EMAIL_APP_PASSWORD'))  # Use the environment variable 
        server.send_message(msg)
        server.quit()
        # Clear the current display
        for widget in frame1.winfo_children():
            widget.destroy()
                
        # I think these need to stay. 
        transparent_frame.grid_forget()
        forget_all_frames()
        baro_frame.grid_forget()
        
        frame1.grid(row=0, column=0, sticky="nsew")
        root.grid_rowconfigure(0, weight=1)
        root.grid_columnconfigure(0, weight=1)
        root.geometry('1024x600')

        label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
        label1.grid(row=0, column=0, columnspan=20, padx=50, pady=(50,0), sticky="nw")

        finish_text = "Your email was sent successfully"
        finish_label = tk.Label(frame1, text=finish_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
        finish_label.grid(row=1, column=0, columnspan=20, padx=50, pady=25, sticky='nw')

        return_text = "Click the button to return to the maps"
        return_label = tk.Label(frame1, text=return_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
        return_label.grid(row=2, column=0, columnspan=20, padx=50, pady=25, sticky='nw') 

        return_button = tk.Button(frame1, text="Return", command=return_to_image_cycle, font=("Helvetica", 16, "bold"))
        return_button.grid(row=3, column=0, columnspan=20, padx=50, pady=(15,0), sticky='nw')
        
    except Exception as e:
        print("line 611. failed to send email: ", e)
        # Clear the current display
        for widget in frame1.winfo_children():
            widget.destroy()
        
        transparent_frame.grid_forget()
        forget_all_frames()
        baro_frame.grid_forget()
        
        frame1.grid(row=0, column=0, sticky="nsew")
        root.grid_rowconfigure(0, weight=1)
        root.grid_columnconfigure(0, weight=1)
        root.geometry('1024x600')

        label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
        label1.grid(row=0, column=0, columnspan=20, padx=50, pady=(50,0), sticky="nw")

        not_sent_text = "Your email was not able to be sent"
        not_sent_label = tk.Label(frame1, text=not_sent_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
        not_sent_label.grid(row=1, column=0, columnspan=20, padx=50, pady=25, sticky='nw')
        
        not_sent_text = "Try another email address or return to the Maps"
        not_sent_label = tk.Label(frame1, text=not_sent_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
        not_sent_label.grid(row=2, column=0, columnspan=20, padx=50, pady=25, sticky='nw')
        
        email_button = tk.Button(frame1, text="Email", command=pic_email, font=("Helvetica", 16, "bold"))
        email_button.grid(row=3, column=0, columnspan=20, padx=50, pady=(15,0), sticky='nw')
        
        maps_button = tk.Button(frame1, text="Return", command=return_to_image_cycle, font=("Helvetica", 16, "bold"))
        maps_button.grid(row=3, column=1, columnspan=20, padx=50, pady=(15,0), sticky='nw')

# Function to take screenshot using grim
def take_screenshot_with_grim(screenshot_filename):
    print("line 668. Trying to use grim for taking a screenshot.")
    try:
        result = subprocess.run(['grim', screenshot_filename], capture_output=True, text=True)
        if result.returncode == 0:
            print("line 672. Grim successfully took the screenshot.")
            return True
        else:
            print("line 675. Grim failed with error")
    except Exception as e:
        print("line 677. Error while using grim")
    return False

# Function to take screenshot using scrot
def take_screenshot_with_scrot(screenshot_filename):
    print("line 682. Trying to use scrot for taking a screenshot.")
    try:
        result = subprocess.run(['scrot', screenshot_filename, '--overwrite'], capture_output=True, text=True)
        if result.returncode == 0:
            print("line 686. Scrot successfully took the screenshot.")
            return True
        else:
            print("line 689. Scrot failed with error")
    except Exception as e:
        print("line 691. Error while using scrot")
    return False

# Main function to take screenshot and handle errors
def pic_email():
    global email_entry, refresh_flag  # Use the global variable
    refresh_flag = True

    # Determine which screenshot command to use
    screenshot_filename = SCREENSHOT_PATH
    grim_path = shutil.which('grim')
    scrot_path = shutil.which('scrot')

    #screenshot_taken = False

    # Verify the screenshot
    if not os.path.exists(screenshot_filename):
        print("line 731. Screenshot file does not exist.")
        raise RuntimeError("Screenshot file does not exist.")

    if is_black_image(screenshot_filename):
        print("Line 735. Screenshot file is black.")
        raise RuntimeError("Screenshot file is black.")

    try:
        image = Image.open(screenshot_filename)
        image.verify()  # Verify the integrity of the image
        print("line 741. Screenshot file is valid.")
    except Exception as e:
        print("line 743. Screenshot file is invalid")
        raise RuntimeError("Screenshot file is invalid.")

    # Clear the current display
    for widget in frame1.winfo_children():
        if isinstance(widget, (tk.Checkbutton, tk.Label, tk.Button, ttk.Button, tk.Entry, tk.Radiobutton)):
            widget.destroy()

    # Continue with the rest of the GUI update logic
    transparent_frame.grid_forget()
    forget_all_frames()
    baro_frame.grid_forget()

    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")
    frame1.config(width=1024, height=600)

    frame1.grid_propagate(False)

    root.grid_rowconfigure(0, weight=0)
    root.grid_columnconfigure(0, weight=0)
    root.geometry('1024x600')

    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, columnspan=20, padx=50, pady=(50,0), sticky="nw")

    instruction_text = "Please enter the email address to send the screenshot:"
    instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
    instructions_label.grid(row=1, column=0, columnspan=20, padx=50, pady=25, sticky='nw')

    email_entry = tk.Entry(frame1, font=("Helvetica", 14), width=50)
    email_entry.grid(row=2, column=0, columnspan=20, padx=50, pady=5, sticky='nw')

    email_entry.focus_set()

    submit_button = tk.Button(frame1, text="Submit", command=submit_pic_email, font=("Helvetica", 16, "bold"))
    submit_button.grid(row=6, column=0, columnspan=20, padx=50, pady=(15,0), sticky='nw')

    cancel_button = tk.Button(frame1, text="Cancel", command=return_to_image_cycle, font=("Helvetica", 16, "bold"))
    cancel_button.grid(row=6, column=0, columnspan=20, padx=225, pady=(15,0), sticky='nw')

    email_entry.bind("<FocusIn>", lambda e: set_keyboard_target(email_entry))

    spacer = tk.Label(frame1, text="", bg=tk_background_color)
    spacer.grid(row=7, column=0, sticky="nsew", pady=(0, 20))

    create_virtual_keyboard(frame1, 8)

    # Load and display the screenshot image
    image_path = SCREENSHOT_PATH  # Use the fixed path
    print(f"Image path: {SCREENSHOT_PATH}, Exists: {os.path.exists(SCREENSHOT_PATH)}")
    image = Image.open(image_path)
    image = image.resize((200, 118))  # Adjusted size as per your requirement
    photo = ImageTk.PhotoImage(image)
    image_label = tk.Label(frame1, image=photo)
    image_label.image = photo  # Keep a reference!
    # Place the image at the top of the column
    #image_label.grid(row=0, column=20, sticky="ne", padx=10)
    image_label.grid(row=0, sticky="n", padx=0)
    # Add a label for "Preview" text directly below the image
    preview_label = tk.Label(frame1, text="Preview", font=("Helvetica", 12), bg=tk_background_color)
    # Position it just below the image without using excessive padding or altering other widgets
    #preview_label.grid(row=0, column=20, sticky="n", padx=10)
    preview_label.grid(row=0, sticky="n", padx=0, pady=(120,0))

def show_fb_login_screen():
    global refresh_flag # use refresh flag to prevent getting kicked off pic post
    SCREENSHOT_PATH = "/home/santod/screenshot.png"
    screenshot_filename = SCREENSHOT_PATH
    grim_path = shutil.which('grim')
    scrot_path = shutil.which('scrot')

    refresh_flag = True
    screenshot_taken = False

    if grim_path and not screenshot_taken:
        screenshot_taken = take_screenshot_with_grim(screenshot_filename)

    if scrot_path and not screenshot_taken:
        screenshot_taken = take_screenshot_with_scrot(screenshot_filename)

    if not screenshot_taken:
        print("❌ Failed to take screenshot with both grim and scrot.")
        raise RuntimeError("Failed to take screenshot.")

    if not os.path.exists(screenshot_filename):
        print("❌ Screenshot file does not exist.")
        raise RuntimeError("Screenshot file does not exist.")

    if is_black_image(screenshot_filename):
        print("❌ Screenshot is black.")
        raise RuntimeError("Screenshot file is black.")

    try:
        image = Image.open(screenshot_filename)
        image.verify()
        print("✅ Screenshot file is valid.")
    except Exception as e:
        print("❌ Screenshot file is invalid.")
        raise RuntimeError("Screenshot file is invalid.")

    # Now hide frames AFTER screenshot
    transparent_frame.grid_forget()
    forget_all_frames()
    for widget in frame1.winfo_children():
        if isinstance(widget, (tk.Checkbutton, tk.Label, tk.Button, ttk.Button, tk.Entry, tk.Radiobutton, tk.Text)):
            widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")
    frame1.config(width=1024, height=600, bg='light blue')
    frame1.grid_propagate(False)
    root.grid_rowconfigure(0, weight=1)
    root.grid_columnconfigure(0, weight=1)

    fb_label = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg='light blue', justify="left")
    fb_label.grid(row=0, column=0, columnspan=20, padx=50, pady=(50, 0), sticky="nw")

    messages = [
        "Connecting to Facebook...",
        "Initializing authentication request...",
        "Connected to Facebook Page and Instagram Business Account: The Weather Observer"
    ]
    delay = 1000  # 1 seconds between messages

    # Create primary message label
    msg_label = tk.Label(frame1, text="", font=("Helvetica", 16), bg='light blue', justify="left")
    msg_label.grid(row=0, column=0, padx=50, pady=(120, 0), sticky="nw")

    # Prepare second label but don’t display yet
    final_label = tk.Label(frame1, text="", font=("Helvetica", 16), bg='light blue', justify="left")

    def show_next_message(index=0):
        if index < len(messages):
            msg_label.config(text=messages[index])
            frame1.after(delay, lambda: show_next_message(index + 1))
        elif index == len(messages):
            # Show the 3rd message (which stays) and queue the final message
            msg_label.config(text=messages[-1])
            frame1.after(delay, lambda: show_next_message(index + 1))
        elif index == len(messages) + 1:
            # Now show the final message below it
            final_label.config(text="Facebook Login complete")
            final_label.grid(row=0, column=0, padx=50, pady=(160, 0), sticky="nw")

            # Then show the Proceed button
            proceed_button = tk.Button(frame1, text="Proceed", font=("Helvetica", 16, "bold"), command=pic_post)
            proceed_button.grid(row=0, column=0, padx=50, pady=(220, 0), sticky="nw")

    show_next_message()


def pic_post():
    global email_entry, refresh_flag, keyboard_buttons, current_target_entry 

    SCREENSHOT_PATH = "/home/santod/screenshot.png"

    # Determine which screenshot command to use
    screenshot_filename = SCREENSHOT_PATH
    grim_path = shutil.which('grim')
    scrot_path = shutil.which('scrot')

    for widget in frame1.winfo_children():
        # Consider a more robust way if frame1 contains persistent elements you don't want destroyed
        # Or destroy only specific types as you are doing
        if isinstance(widget, (tk.Checkbutton, tk.Label, tk.Button, ttk.Button, tk.Entry, tk.Radiobutton, tk.Text)): # Added tk.Text
             widget.destroy()

    keyboard_buttons.clear() # Clear the dictionary holding refs to destroyed buttons
    current_target_entry = None # Reset the target entry as it was likely destroyed

    IMAGE_PATH = "/home/santod/screenshot.png"
    MESSAGE = "Posted from The Weather Observer!"

    def post_to_facebook(caption):
        url = f"https://graph.facebook.com/v18.0/{PAGE_ID}/photos"

        if not os.path.exists(IMAGE_PATH):
            messagebox.showerror("Error", f"Image not found at {IMAGE_PATH}")
            return

        with open(IMAGE_PATH, "rb") as image_file:
            response = requests.post(
                url,
                data={
                    "caption": caption,
                    "access_token": PAGE_ACCESS_TOKEN
                },
                files={
                    "source": image_file
                }
            )

        if response.status_code == 200:
            messagebox.showinfo("Success", "Image posted to Facebook!")
        else:
            messagebox.showerror("Failed", f"FB post failed. Code: {response.status_code}\n{response.text}")

    def post_to_instagram(caption):
        import requests
        import time
        from tkinter import messagebox
        from PIL import Image

        SRC_PATH  = "/home/santod/screenshot.png"     # source from your capture
        IMAGE_PATH = "/home/santod/screenshot.jpg"    # JPEG we will upload
        SERVER_UPLOAD_URL = "https://weatherobserver.duckdns.org/upload.php"

        # Re-encode to JPEG (no alpha/profile quirks)
        img = Image.open(SRC_PATH).convert("RGB")
        img.save(IMAGE_PATH, format="JPEG", quality=90, optimize=True)

        print("🧪 First 16 bytes:", open(IMAGE_PATH, "rb").read(16))

        # Upload to Your Server (Step 5 Version)
        print(f"📤 Uploading screenshot to {SERVER_UPLOAD_URL}...")
        try:
            with open(IMAGE_PATH, "rb") as img_file:
                files_payload = {
                    'uploaded_file': ('screenshot.jpg', img_file, 'image/jpeg')
                }
                data_payload = {'api_secret': API_SECRET_TOKEN}

                response = requests.post(SERVER_UPLOAD_URL, files=files_payload, data=data_payload)


            # Check the response from your server
            if response.status_code == 200:
                # --- Step 5: Get the URL from the server's plain text response ---
                IMAGE_URL = response.text.strip() # Get the raw text response and remove leading/trailing whitespace
                print(f"✅ Upload successful. Server returned URL: {IMAGE_URL}")

                # Basic validation of the returned URL format
                if not IMAGE_URL.startswith(('http://', 'https://')) or not IMAGE_URL.lower().endswith(('.png', '.jpg', '.jpeg', '.gif')):
                     print(f"❌ ERROR: Server returned an invalid or non-image URL: {IMAGE_URL}")
                     # Show the beginning of the invalid response in the error box
                     messagebox.showerror("Upload Failed", f"Server returned an invalid URL: {IMAGE_URL[:100]}...") 
                     return # Exit if URL is bad

                # --- URL received successfully, now proceed with Instagram post ---
                print("Image hosted successfully on own server. Proceeding with Instagram post...")

                # ------------------------------------------------------------
                # IG FETCH-GATE + RETRY (minimal, self-contained)
                # Place immediately after:
                #   print("Image hosted successfully on own server. Proceeding with Instagram post...")
                # and before create_url/create_payload are defined.
                # ------------------------------------------------------------
                
                # ---- IG FETCH-GATE + CACHE-BUSTED CONTAINER RETRIES (minimal) ----
                # Assumes IMAGE_URL holds the URL returned by your server.
                import time as _t, requests as _req, random as _rand

                def _ig_is_fetch_ready(url, timeout=6):
                    try:
                        h = _req.head(url, timeout=timeout, allow_redirects=True)
                        if h.status_code != 200:
                            return False, f"HEAD {h.status_code}"
                        ct = h.headers.get("Content-Type", "").lower()
                        cl = int(h.headers.get("Content-Length", "0") or "0")
                        if "image/" not in ct or cl < 2048:
                            return False, f"ct={ct} cl={cl}"
                        r = _req.get(url, headers={"Range": "bytes=0-31"}, timeout=timeout)
                        b = r.content or b""
                        if b.startswith(b"\xff\xd8\xff") or b.startswith(b"\x89PNG\r\n\x1a\n"):
                            return True, f"ct={ct} cl={cl}"
                        return False, "magic-bytes-missing"
                    except Exception as e:
                        return False, f"exc:{e}"

                def _ig_try_container(url, caption, tries=3):
                    base_create_url = f"https://graph.facebook.com/v18.0/{IG_USER_ID}/media"
                    for attempt in range(1, tries + 1):
                        # cache-bust per attempt to avoid any upstream stale cache
                        bust = int(_t.time()*1000) + _rand.randint(0, 999)
                        attempt_url = f"{url}{'&' if '?' in url else '?'}cb={bust}"

                        ok, why = _ig_is_fetch_ready(attempt_url)
                        print(f"[IG-GATE] attempt {attempt}: {why} url={attempt_url}")
                        if not ok:
                            _t.sleep(0.8 * attempt)
                            continue

                        payload = {
                            "image_url": attempt_url,
                            "caption": caption,
                            "access_token": ACCESS_TOKEN
                        }
                        try:
                            resp = _req.post(base_create_url, data=payload, timeout=20)
                            data = resp.json()
                        except Exception as e:
                            print(f"[IG-CONTAINER] exception on attempt {attempt}: {e}")
                            _t.sleep(1.2 * attempt)
                            continue

                        print(f"[IG-CONTAINER] response (attempt {attempt}):", data)

                        if isinstance(data, dict) and "id" in data:
                            return True, data["id"]

                        err = (data or {}).get("error", {})
                        # 9004 = IG couldn’t fetch the URL — back off and try again
                        if err.get("code") == 9004:
                            _t.sleep(1.2 * attempt)
                            continue

                        # Any other error: stop immediately
                        return False, data

                    return False, {"error": {"message": "exhausted container retries"}}

                # Run the minimal, cache-busted container attempts
                ok, result = _ig_try_container(IMAGE_URL, caption, tries=3)
                if not ok:
                    print("❌ IG container creation failed after retries:", result)
                    try:
                        from tkinter import messagebox as _mb
                        _mb.showerror("Upload Busy",
                                      "Unable to prepare image for sharing.") #\n(If this repeats, disable AAAA/IPv6 for your DuckDNS host.)
                    except Exception:
                        pass
                    return

                # If we get here, we have a creation_id — proceed to publish
                creation_id = result
                publish_url = f"https://graph.facebook.com/v18.0/{IG_USER_ID}/media_publish"
                publish_payload = {"creation_id": creation_id, "access_token": ACCESS_TOKEN}
                print("🚀 Publishing to Instagram feed...")
                _t.sleep(2.0)
                publish_response = _req.post(publish_url, data=publish_payload, timeout=20)
                print("Step 2 response:", publish_response.json())
                try:
                    from tkinter import messagebox as _mb
                    _mb.showinfo("Success", "Image posted to Instagram!")
                except Exception:
                    pass
                return

            else:
                # The server returned an error (e.g., 403 Forbidden if token is wrong, 500, 400, 415 etc.)
                print(f"❌ Server upload failed. Status Code: {response.status_code}")
                # Display the error message returned by the PHP script (e.g., "ERROR: Authentication failed.")
                print(f"Server error response: {response.text}") 
                messagebox.showerror("Upload Failed", f"Server returned status {response.status_code}.\nCheck Pi's console/logs.\nError: {response.text}")
                return # Exit the function if upload failed

        # Keep the existing exception handling blocks here (RequestException, FileNotFoundError, etc.)
        except requests.exceptions.RequestException as e:
            print(f"❌ Error connecting to server: {e}")
            messagebox.showerror("Upload Failed", f"Could not connect to server at {SERVER_UPLOAD_URL}.")
            return 
        except FileNotFoundError:
            print(f"❌ Error: Screenshot file not found at {IMAGE_PATH}")
            messagebox.showerror("Upload Failed", f"Screenshot file not found: {IMAGE_PATH}")
            return 
        except Exception as e:
            print(f"❌ An unexpected error occurred during server upload: {e}")
            messagebox.showerror("Upload Failed", "An unexpected error occurred during upload.")
            return

    def submit_pic_post_choice(fb_var, insta_var, frame1):
        user_caption = text_input.get("1.0", "end-1c").strip()
        if fb_var.get():
            post_to_facebook(user_caption)
        if insta_var.get():
            post_to_instagram(user_caption)
        if email_var.get():
            pic_email()

    transparent_frame.grid_forget()
    forget_all_frames()
    baro_frame.grid_forget()

    frame1.grid(row=0, column=0, sticky="nsew")
    frame1.config(width=1024, height=600)
    frame1.grid_propagate(False)

    frame1.grid(row=0, column=0, sticky="nsew")
    frame1.grid_propagate(False)

    root.grid_rowconfigure(0, weight=1)
    root.grid_columnconfigure(0, weight=1)

    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg='light blue', justify="left")
    label1.grid(row=0, column=0, columnspan=20, padx=50, pady=(50, 0), sticky="nw")

    fb_var = tk.BooleanVar()
    insta_var = tk.BooleanVar()
    email_var = tk.BooleanVar()

    tk.Checkbutton(frame1, text="Post to Facebook", variable=fb_var, font=("Helvetica", 14), bg='light blue', highlightthickness=0).grid(row=0, column=0, padx=50, pady=(110, 0), sticky="nw")
    tk.Checkbutton(frame1, text="Post to Instagram", variable=insta_var, font=("Helvetica", 14), bg='light blue', highlightthickness=0).grid(row=0, column=0, padx=50, pady=(140, 0), sticky="nw")

    label2 = tk.Label(frame1, text="OR", font=("Arial", 24, "bold"), bg='light blue', justify="left")
    label2.grid(row=0, column=0, padx=(275, 0), pady=(110, 0), sticky="nw")

    tk.Checkbutton(frame1, text="Email the image", variable=email_var, font=("Helvetica", 14), bg='light blue', highlightthickness=0).grid(row=0, column=0, padx=370, pady=(110, 0), sticky="nw")

    label3 = tk.Label(frame1, text="If posting, edit/complete what you want the post to say below:", font=("Arial", 12), bg='light blue', justify="left")
    label3.grid(row=0, column=0, padx=(50, 0), pady=(180, 0), sticky="nw")

    text_input = tk.Text(frame1, height=3, font=('Arial', 12))
    text_input.grid(row=1, column=0, columnspan=20, padx=(50, 0), pady=(20,10), sticky='w') # Adjusted pady slightly
    text_input.insert('1.0', "Posted from The Weather Observer. ")
    # text_input.focus_set() # Set focus after keyboard is created potentially
    text_input.config(cursor="xterm")
    text_input.bind("<FocusIn>", lambda event, widget=text_input: set_keyboard_target(widget)) # Good binding

    # --- FIX 2: Create the keyboard *before* calling auto_capitalize ---
    create_virtual_keyboard(frame1, start_row=3)

    post_button = tk.Button(frame1, text="Share", command=lambda: submit_pic_post_choice(fb_var, insta_var, frame1), font=("Helvetica", 16, "bold"))
    # Adjusted post button pady to avoid overlap if keyboard is taller
    post_button.grid(row=2, column=0, columnspan=20, padx=(50,0), pady=(10, 15), sticky='nw')

    cancel_button = tk.Button(frame1, text="Return", command=return_to_image_cycle, font=("Helvetica", 16, "bold"))
    cancel_button.grid(row=2, column=0, columnspan=20, padx=(200,0), pady=(10, 15), sticky='nw')

    # --- Image preview logic ---
    image_path = SCREENSHOT_PATH
    try: # Add try-except for image loading
        print(f"Image path: {SCREENSHOT_PATH}, Exists: {os.path.exists(SCREENSHOT_PATH)}")
        if os.path.exists(image_path):
             image = Image.open(image_path)
             image = image.resize((200, 118))
             photo = ImageTk.PhotoImage(image)
             image_label = tk.Label(frame1, image=photo)
             image_label.image = photo # Keep reference
             # Adjusted image preview placement - check column/padx carefully relative to keyboard
             image_label.grid(row=0, padx=(10, 0), pady=(0, 0), sticky="n") # Example placement
            
             preview_label = tk.Label(frame1, text="Preview", font=("Helvetica", 12), bg='light blue') # Use frame background color
             # Adjusted preview label placement
             preview_label.grid(row=0, padx=(10, 0), pady=(120, 0), sticky="n") # Example placement below image
        else:
             print(f"Preview image not found at {image_path}")
    except Exception as e:
        print(f"Error loading preview image: {e}")

    print("Setting focus to text_input...") # Debugging print
    text_input.focus_set() 

#code begins for generation of random sites
def clear_random_map_ui():
    global random_map_label
    print("line 2516. clearing map showing random sites.")
    if random_map_label and random_map_label.winfo_exists():
        try:
            random_map_label.configure(image="")
            random_map_label.image = None
            random_map_label.destroy()
            random_map_label = None
            print("line 2523. random sites map cleared.")
        except Exception as e:
            print(f"[RMAP] cleanup error: {e}")
    else:
        print("[RMAP] no map widget to clear.")

def confirm_random_sites():
    """
    (Corrected) Gathers the data for the three randomly selected sites
    and calls the UI update function. This version uses the correct
    'alternative_town' variables.
    """
    global alternative_town_1, alternative_town_2, alternative_town_3
    global aobs_random_obs_lat, aobs_random_obs_lon, bobs_random_obs_lat, bobs_random_obs_lon, cobs_random_obs_lat, cobs_random_obs_lon

    # Construct the station dictionaries using the correct 'alternative_town' variables
    station_a = {'name': alternative_town_1, 'latitude': aobs_random_obs_lat, 'longitude': aobs_random_obs_lon}
    station_b = {'name': alternative_town_2, 'latitude': bobs_random_obs_lat, 'longitude': bobs_random_obs_lon}
    station_c = {'name': alternative_town_3, 'latitude': cobs_random_obs_lat, 'longitude': cobs_random_obs_lon}
    
    random_stations = [station_a, station_b, station_c]

    # Generate the map and then schedule the GUI update
    #clear_random_map_ui()
    create_random_map_image(random_stations)
    frame1.after(100, lambda: update_gui(random_stations))

    #clear_random_map_ui()
    gc.collect()
    #snap_after = tracemalloc.take_snapshot()
    #top = snap_after.compare_to(snap_before, 'lineno')[:10]
    #print("[OBS] top allocators after site change:")
    #for stat in top:
        #print(stat)

def update_gui(random_stations):
    """
    (Corrected) Draws the confirmation screen, including the list of
    station names and the map. This version uses the correct 'alternative_town'
    variables to display the text.
    """
    global aobs_only_click_flag, alternative_town_1, alternative_town_2, alternative_town_3

    for widget in frame1.winfo_children():
        widget.destroy()

    # Configure grid layout for frame1
    frame1.grid_columnconfigure(0, weight=1)
    frame1.grid_columnconfigure(9, weight=1)

    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, columnspan=9, padx=50, pady=(20,10), sticky="nw")

    announce_text = "The following 3 locations have been chosen as observation sites:"
    announce_label = tk.Label(frame1, text=announce_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
    announce_label.grid(row=1, column=0, columnspan=9, padx=50, pady=(0,15), sticky='nw')
    
    # Use the correct 'alternative_town' variables to build the text
    random_sites_text = f"{alternative_town_1}\n\n{alternative_town_2}\n\n{alternative_town_3}"
    label2 = tk.Label(frame1, text=random_sites_text, font=("Arial", 16), bg=tk_background_color, anchor='w', justify='left')
    label2.grid(row=2, column=0, columnspan=9, padx=(50,0), pady=(0, 7), sticky='w')

    # Validate that all stations have lat/lon before proceeding
    for station in random_stations:
        if 'latitude' not in station or 'longitude' not in station:
            label_error = tk.Label(frame1, text=f"Error: Missing location data for {station['name']}.", font=("Arial", 14), fg="red", bg=tk_background_color)
            label_error.grid(row=4, column=0, columnspan=20, padx=50, pady=(10,10), sticky='w')
            return
    
    # Display the map with the 3 random sites
    display_random_map_image("/home/santod/station_locations.png")

    if aobs_only_click_flag == True:
        aobs_only_click_flag = False
        next_function = return_to_image_cycle
    else:
        next_function = page_choose
    
    # Create the 'Back' button
    back_button = tk.Button(frame1, text=" Back ", font=("Helvetica", 16, "bold"), command=land_or_buoy)
    back_button.grid(row=3, column=0, columnspan=20, padx=(50, 0), pady=(20,0), sticky="nw")
    
    next_button = tk.Button(frame1, text="Next", command=next_function, font=("Helvetica", 16, "bold"))
    next_button.grid(row=3, column=0, columnspan=20, padx=200, pady=(20,0), sticky='nw')
    
def calculate_random_center(random_stations):
    random_latitudes = [float(station['latitude']) for station in random_stations]
    random_longitudes = [float(station['longitude']) for station in random_stations]
    return sum(random_latitudes) / len(random_latitudes), sum(random_longitudes) / len(random_longitudes)

def calculate_random_zoom_level(random_stations):
    max_random_distance = 0
    for i in range(len(random_stations)):
        for j in range(i + 1, len(random_stations)):
            point1 = (float(random_stations[i]['latitude']), float(random_stations[i]['longitude']))
            point2 = (float(random_stations[j]['latitude']), float(random_stations[j]['longitude']))
            distance = geodesic(point1, point2).kilometers
            if distance > max_random_distance:
                max_random_distance = distance
        
    if max_random_distance < 50:
        return 10
    elif max_random_distance < 100:
        return 9
    elif max_random_distance < 200:
        return 8
    elif max_random_distance < 400:
        return 7
    elif max_random_distance < 800:
        return 6
    elif max_random_distance < 1600:
        return 5
    else:
        return 4

# Function to adjust the window size based on the visible content area
def adjust_random_window_size(driver, target_width, target_height):
    # Run JavaScript to get the size of the visible content area
    width = driver.execute_script("return window.innerWidth;")
    height = driver.execute_script("return window.innerHeight;")
    
    # Calculate the difference between the actual and desired dimensions
    width_diff = target_width - width
    height_diff = target_height - height

    # Adjust the window size based on the difference
    current_window_size = driver.get_window_size()
    new_width = current_window_size['width'] + width_diff
    new_height = current_window_size['height'] + height_diff
    driver.set_window_size(new_width, new_height)

def create_random_map_image(random_stations):
    # center and zoom exactly as before
    random_center = calculate_random_center(random_stations)
    random_zoom_level = calculate_random_zoom_level(random_stations)

    # fixed-size folium map (no style changes)
    m = folium.Map(
        location=random_center,
        zoom_start=random_zoom_level,
        width=450,
        height=300,
        control_scale=False,
        zoom_control=False
    )

    # markers and labels exactly as before
    for station in random_stations:
        random_station_name = station['name'].split(",")[0][:9]
        folium.Marker(
            location=(station['latitude'], station['longitude']),
            icon=folium.Icon(color='blue', icon='info-sign')
        ).add_to(m)
        folium.Marker(
            location=(station['latitude'], station['longitude']),
            icon=folium.DivIcon(html=f'''
                <div style="
                    background-color: white;
                    padding: 2px 5px;
                    border-radius: 3px;
                    box-shadow: 0px 0px 2px rgba(0, 0, 0, 0.5);
                    font-size: 12px;
                    font-weight: bold;
                    text-align: center;
                    width: 70px;
                    word-wrap: break-word;
                    transform: translate(-40%, -130%);
                ">{random_station_name}</div>
            ''')
        ).add_to(m)

    # fit bounds with the original buffers
    latitudes  = [station['latitude']  for station in random_stations]
    longitudes = [station['longitude'] for station in random_stations]
    min_lat, max_lat = min(latitudes),  max(latitudes)
    min_lon, max_lon = min(longitudes), max(longitudes)
    ns_buffer, ew_buffer = 0.15, 0.1
    bounds = [[min_lat - ns_buffer, min_lon - ew_buffer],
              [max_lat + ns_buffer, max_lon + ew_buffer]]
    m.fit_bounds(bounds)

    # file paths
    html_path = "/home/santod/random_station_locations.html"
    png_path  = "/home/santod/station_locations.png"

    # write HTML (legacy behavior) with cleanup on failure
    try:
        m.save(html_path)
    except Exception as e:
        print(f"[RMAP] Failed to save map HTML: {e}")
        try:
            if os.path.exists(html_path):
                os.remove(html_path)
        except Exception:
            pass
        return

    # headless Chrome exactly as before, just ensure cleanup in finally
    if not CHROME_DRIVER_PATH:
        print("ERROR: ChromeDriver path is not set. Cannot start browser.")
        try:
            if os.path.exists(html_path):
                os.remove(html_path)
        except Exception:
            pass
        return

    driver = None
    try:
        options = Options()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')

        service = Service(CHROME_DRIVER_PATH)
        driver = webdriver.Chrome(service=service, options=options)

        # initial window then exact inner size match (legacy)
        driver.set_window_size(600, 500)

        file_url = f'file://{os.path.abspath(html_path)}'
        driver.get(file_url)

        # legacy fixed wait only
        time.sleep(2)

        # preserves 450x300 aspect exactly
        adjust_random_window_size(driver, 450, 300)

        driver.save_screenshot(png_path)

    except Exception as e:
        print(f"[RMAP] Screenshot error: {e}")
    finally:
        try:
            if driver is not None:
                driver.quit()
        except Exception:
            pass
        try:
            if os.path.exists(html_path):
                os.remove(html_path)
        except Exception as e:
            print(f"[RMAP] Cleanup warning (HTML): {e}")


def display_random_map_image(img_path):
    # legacy display path: fixed resize to 450x300 then load into a fresh Label
    img = Image.open(img_path)
    try:
        img = img.resize((450, 300), Image.LANCZOS)
        tk_img = ImageTk.PhotoImage(img)

        label = tk.Label(frame1, image=tk_img)
        label.image = tk_img
        label.grid(row=8, column=8, rowspan=6, sticky="se", padx=(570, 10), pady=0)
    finally:
        try:
            img.close()
        except Exception:
            pass
        try:
            if os.path.exists(img_path):
                os.remove(img_path)
        except FileNotFoundError:
            pass

def generate_random_sites():
    """
    Finds 3 random, functioning stations near the user's location using
    a pre-filtered cache and an expanding search radius. (Corrected for deadlock)
    """
    # --- Preserved tracemalloc logic ---
    global snap_before
    snap_before = tracemalloc.take_snapshot()

    # --- Global variable declarations ---
    global RANDOM_CANDIDATE_STATIONS_CACHE, BUOY_ID_SET, aobs_site
    global aobs_station_identifier, bobs_station_identifier, cobs_station_identifier
    global aobs_buoy_code, bobs_buoy_code, cobs_buoy_code
    global aobs_buoy_signal, bobs_buoy_signal, cobs_buoy_signal
    global alternative_town_1, alternative_town_2, alternative_town_3
    global aobs_random_obs_lat, aobs_random_obs_lon, bobs_random_obs_lat, bobs_random_obs_lon, cobs_random_obs_lat, cobs_random_obs_lon
    global atemp, awtemp, awind, btemp, bwtemp, bwind, ctemp, cwtemp, cwind
    global last_land_scrape_time
    global random_sites_flag
    
    #random_sites_flag = True

    random_station_config = get_random_station_config()

    # --- Initial UI setup ---
    instruction_text = random_station_config["initial_message"]
    random_progress_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 12), bg=tk_background_color, anchor='w', justify='left')
    random_progress_label.grid(row=3, column=0, padx=50, pady=5, sticky='w')
    frame1.update_idletasks()

    # --- Main execution block ---
    try:
        if 'aobs_site' not in globals() or not aobs_site:
            raise ValueError("Primary location (aobs_site) is not set.")
        
        if not RANDOM_CANDIDATE_STATIONS_CACHE:
            raise ValueError(random_station_config["empty_cache_message"])

        geolocator = Nominatim(user_agent="two_random_locator_final_v1_contact_observeweather@gmail.com")
        center_location = geolocator.geocode(aobs_site, exactly_one=True, timeout=10)
        if center_location is None:
            raise ValueError(f"Could not geocode the location: {aobs_site}")
        center_lat, center_lon = center_location.latitude, center_location.longitude
        
        search_radii = random_station_config["search_radii"]
        _, buoy_id_set, _ = load_buoy_metadata_cached()
        
        valid_stations = find_valid_random_stations(
            RANDOM_CANDIDATE_STATIONS_CACHE,
            center_lat,
            center_lon,
            search_radii,
            random_station_config["selection_count"],
            random_progress_label,
            frame1,
            check_random_station_functionality,
            buoy_id_set,
        )
        # --- END OF MODIFIED LOGIC ---

        if len(valid_stations) < random_station_config["selection_count"]:
            raise ValueError(random_station_config["failure_message"])
        
        selected_stations = valid_stations[:random_station_config["selection_count"]]

        random_progress_label.config(text=random_station_config["map_build_message"])
        frame1.update_idletasks()
        
        populate_random_station_selection_globals(
            selected_stations,
            buoy_id_set,
            obs_buttons_choice_abbreviations,
            globals(),
        )

        random_progress_label.config(text=random_station_config["preload_message"])
        frame1.update_idletasks()

        land_data, buoy_data = preload_random_station_observations(
            aobs_buoy_signal,
            aobs_station_identifier,
            aobs_buoy_code,
            bobs_buoy_signal,
            bobs_station_identifier,
            bobs_buoy_code,
            cobs_buoy_signal,
            cobs_station_identifier,
            cobs_buoy_code,
            scrape_land_station_data,
            get_buoy_data,
        )

        populate_random_station_observation_globals(
            land_data,
            buoy_data,
            globals(),
        )

        last_land_scrape_time = datetime.now()

        random_progress_label.destroy()
        
        import gc; gc.collect()

        confirm_random_sites()

    except Exception as e:
        print(f"An error occurred in generate_random_sites: {e}")
        for widget in frame1.winfo_children():
            widget.destroy()
        error_label = tk.Label(frame1, text=f"Could not find random sites.\nError: {e}", font=("Helvetica", 14), bg=tk_background_color, fg="red", justify="center")
        error_label.pack(pady=50, padx=20)
        back_button = tk.Button(frame1, text="Back", font=("Helvetica", 16, "bold"), command=land_or_buoy)
        back_button.pack(pady=20)


def setup_aobs_input_land():
    """Sets up and calls xobs_input_land for the AOBS site."""
    print("Running setup_aobs_input_land...")
    xobs_input_land(
        obs_type='aobs',
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=land_or_buoy,
        submit_command_handler=handle_aobs_submission,
    )

def setup_bobs_input_land():
    """Sets up and calls xobs_input_land for the BOBS site."""
    print("Running setup_bobs_input_land...")
    xobs_input_land(
        obs_type='bobs',
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=land_or_buoy,
        submit_command_handler=handle_bobs_submission,
    )

def setup_cobs_input_land():
    """Sets up and calls xobs_input_land for the COBS site."""
    print("Running setup_cobs_input_land...")
    xobs_input_land(
        obs_type='cobs',
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=land_or_buoy,
        submit_command_handler=handle_cobs_submission,
    )

def recheck_cobs_stations():
    """
    Called by 'Back' button from page_choose.
    Re-runs xobs_check_land for COBS using stored town/state.
    """
    print("Back button pressed from page_choose. Re-running check for COBS...")
    try:
        # Access the stored COBS location from globals
        cobs_town = alternative_town_3
        cobs_state = alternative_state_3

        if not cobs_town or not cobs_state:
             print("Error: COBS town/state not found in globals for recheck.")
             # Optionally show an error message to the user
             # Maybe just go back to the input step?
             setup_cobs_input_land()
             return

        # Call xobs_check_land to rebuild the COBS station selection screen
        xobs_check_land(
            obs_type='cobs',
            input_town=cobs_town,
            input_state=cobs_state,
            frame=frame1, # Or your actual frame variable
            tk_background_color=tk_background_color, # Your actual color
            button_font=button_font, # Your actual font
            back_command=setup_cobs_input_land, # Back from check screen goes to input setup
            confirm_command_handler=handle_cobs_confirmation # Confirm selection goes to confirmation handler
        )
    except NameError as e:
        print(f"Error accessing needed variables/functions in recheck_cobs_stations: {e}")
        # Handle error appropriately, maybe go back to a known safe state
        # For example, go back to the COBS input screen:
        # setup_cobs_input_land()
    except Exception as e:
        print(f"Unexpected error in recheck_cobs_stations: {e}")
        # setup_cobs_input_land()

# --- Updated Confirmation Handlers ---

def handle_aobs_confirmation(selected_station_data=None):
    """
    (Corrected) Handles the final confirmation for the AOBS station.
    - If called from the manual selection screen, it uses the provided data
      to update the global variables, avoiding a re-scrape.
    - If called from the random selection screen (with no data), it does nothing,
      as the globals have already been set.
    """
    global aobs_station_identifier, aobs_buoy_signal, alternative_town_1
    global atemp, awind, awtemp
    global aobs_only_click_flag, last_land_scrape_time

    # This is the key: only process data if it was passed in from the manual selection screen.
    selected_station_display = prepare_land_confirmation_display(
        selected_station_data,
        get_land_confirmation_slot_config("aobs"),
        obs_buttons_choice_abbreviations,
        globals(),
        apply_manual_land_confirmation_globals,
    )

    # The rest of the function determines which screen to show next.
    ordinal = "first"
    back_command = setup_aobs_input_land

    next_command = return_to_image_cycle if aobs_only_click_flag else bobs_land_or_buoy
    if aobs_only_click_flag:
        aobs_only_click_flag = False

    xobs_confirm_land(
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        selected_station_data=selected_station_display,
        ordinal_text=ordinal,
        back_command_for_confirm=back_command,
        next_command_for_confirm=next_command
    )

def handle_bobs_confirmation(selected_station_data=None):
    """(Corrected) Handles the final confirmation for the BOBS station."""
    global bobs_station_identifier, bobs_buoy_signal, alternative_town_2
    global btemp, bwind, bwtemp
    global bobs_only_click_flag, last_land_scrape_time

    selected_station_display = prepare_land_confirmation_display(
        selected_station_data,
        get_land_confirmation_slot_config("bobs"),
        obs_buttons_choice_abbreviations,
        globals(),
        apply_manual_land_confirmation_globals,
    )

    ordinal = "second"
    back_command = setup_bobs_input_land

    next_command = return_to_image_cycle if bobs_only_click_flag else cobs_land_or_buoy
    if bobs_only_click_flag:
        bobs_only_click_flag = False

    xobs_confirm_land(
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        selected_station_data=selected_station_display,
        ordinal_text=ordinal,
        back_command_for_confirm=back_command,
        next_command_for_confirm=next_command
    )

def handle_cobs_confirmation(selected_station_data=None):
    """(Corrected) Handles the final confirmation for the COBS station."""
    global cobs_station_identifier, cobs_buoy_signal, alternative_town_3
    global ctemp, cwind, cwtemp
    global cobs_only_click_flag, last_land_scrape_time

    selected_station_display = prepare_land_confirmation_display(
        selected_station_data,
        get_land_confirmation_slot_config("cobs"),
        obs_buttons_choice_abbreviations,
        globals(),
        apply_manual_land_confirmation_globals,
    )

    # This is your specific logic for resetting the timer.
    # It will run correctly for both manual and random paths.
    if not cobs_only_click_flag:
        print("[TIMER_RESET] Initial manual setup complete. Resetting observation timer.")
        last_land_scrape_time = datetime.now()
    
    ordinal = "third"
    back_command = setup_cobs_input_land

    next_command = return_to_image_cycle if cobs_only_click_flag else page_choose
    if cobs_only_click_flag:
        cobs_only_click_flag = False

    xobs_confirm_land(
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        selected_station_data=selected_station_display,
        ordinal_text=ordinal,
        back_command_for_confirm=back_command,
        next_command_for_confirm=next_command
    )

def xobs_check_land(obs_type, input_town, input_state, frame, tk_background_color, button_font, back_command, confirm_command_handler):
    """
    (Refactored v18 - Sequential Scraper) Finds the 5 closest functional stations
    by iterating through a distance-sorted list and using a single, persistent
    browser instance with crash recovery to minimize CPU load.
    """
    global ALL_STATIONS_CACHE
    global ALL_STATIONS_CACHE_DICTS, ALL_STATIONS_CACHE, BUOY_ID_SET
        
    #snap_before = tracemalloc.take_snapshot()
    
    print("[META] ALL_STATIONS_CACHE_DICTS id/len:",
      id(ALL_STATIONS_CACHE_DICTS) if ALL_STATIONS_CACHE_DICTS is not None else None,
      len(ALL_STATIONS_CACHE_DICTS) if ALL_STATIONS_CACHE_DICTS else 0)

    print("[META] ALL_STATIONS_CACHE id/len:",
          id(ALL_STATIONS_CACHE) if ALL_STATIONS_CACHE is not None else None,
          len(ALL_STATIONS_CACHE) if ALL_STATIONS_CACHE else 0)

    print("[META] BUOY_ID_SET size:",
          len(BUOY_ID_SET) if 'BUOY_ID_SET' in globals() and BUOY_ID_SET else 0)

    
    print(f"\n--- Running xobs_check_land (Sequential Scraper Version) ---")
    print(f"  Searching for stations near: {input_town}, {input_state}")
    print(f"--------------------------------------------------")

    # --- Local State & Constants ---
    selected_site_index = tk.IntVar(value=-1)
    valid_stations_data = []
    STATIONS_METADATA_PATH = "/home/santod/stations_metadata.json"
    NUM_STATIONS_TO_FIND = 5

    # --- UI and Map Helpers (Unchanged from your original code) ---
    def calculate_center(stations):
        return calculate_station_map_center(stations)

    def calculate_zoom_level(stations):
        return calculate_station_map_zoom_level(stations, geodesic)

    def create_map_image(stations, progress_label=None, frame=None):
        try:
            return create_station_map_screenshot(
                stations,
                progress_label,
                frame,
                CHROME_DRIVER_PATH,
                calculate_center,
                calculate_zoom_level,
                build_station_map_bounds,
                folium,
                Options,
                Service,
                webdriver,
                os,
                time,
            )
        except Exception as e:
            print(f"Error creating map image: {e}")
            return False

    def on_radio_select():
        if selected_site_index.get() != -1 and submit_button['state'] == 'disabled':
            submit_button.config(state="normal")

    def on_submit_click():
        """
        (Corrected) This now passes the ENTIRE data dictionary for the
        selected station to the confirmation handler, not just the ID.
        """
        print("Submit button clicked.")
        selected_index = selected_site_index.get()
        if 0 <= selected_index < len(valid_stations_data):
            selected_station_data = valid_stations_data[selected_index]
            print(f"Confirming selection: {selected_station_data.get('identifier')}")
            confirm_command_handler(selected_station_data)
        else:
            print("Submit clicked but no valid station selected.")
            messagebox.showwarning("No Selection", "Please select a station before submitting.")

        try:
            del station_candidates, successful_scrapes
        except Exception:
            pass

    # --- Main Execution Logic ---
    try:
        progress_label = tk.Label(frame, text="Searching nearby stations...", font=("Helvetica", 12), bg=tk_background_color, justify="left", wraplength=800)
        progress_label.grid(row=5, column=0, columnspan=2, padx=50, pady=10, sticky='nw')

        valid_stations_data = gather_land_station_choices(
            input_town,
            input_state,
            lambda query: Nominatim(user_agent="town-state-locator-v2").geocode(
                query,
                exactly_one=True,
                timeout=10,
            ),
            load_all_stations_cached_dicts,
            lambda stations, search_state, search_lat, search_lon: build_state_station_candidates(
                stations,
                search_state,
                search_lat,
                search_lon,
                geopy.distance.distance,
            ),
            lambda candidates: find_and_scrape_land_stations_sequentially(
                candidates,
                progress_label,
                frame,
                NUM_STATIONS_TO_FIND,
                CHROME_DRIVER_PATH,
                Options,
                Service,
                webdriver,
                By,
                os,
                signal,
                input_state,
                find_first_valid_temperature_row,
                build_scraped_land_station_result,
            ),
        )

        # --- Build UI ---
        for widget in frame.winfo_children():
            widget.destroy()
        frame.configure(bg=tk_background_color)

        header_font = tkFont.Font(family="Arial", size=18, weight="bold")
        obs_font = tkFont.Font(family="Helvetica", size=12)
        frame.grid_columnconfigure(1, weight=1)

        label1 = tk.Label(frame, text="The Weather Observer", font=header_font, bg=tk_background_color, justify="left")
        label1.grid(row=0, column=0, columnspan=2, padx=50, pady=(20, 0), sticky="nw")

        instructions_label = tk.Label(frame, text=f"Please choose a site to represent {input_town}, {input_state}", font=("Helvetica", 14), bg=tk_background_color, justify="left")
        instructions_label.grid(row=1, column=0, columnspan=2, padx=50, pady=5, sticky='nw')

        # 🧭 Reuse same variable name for progress label
        progress_label = tk.Label(frame, text="Preparing map...", font=("Helvetica", 12), bg=tk_background_color, justify="left", wraplength=800)
        progress_label.grid(row=5, column=0, columnspan=2, padx=50, pady=10, sticky='nw')

        # 🌍 Display the map
        create_map_image(valid_stations_data, progress_label, frame)
        display_station_map_image(
            frame,
            "/home/santod/station_locations.png",
            tk,
            Image,
            ImageTk,
            os,
        )

        # 🧹 Clear the progress text
        progress_label.config(text="")

        submit_button = tk.Button(frame, text="Submit", font=button_font, state="disabled", width=6, command=on_submit_click)

        for a, station in enumerate(valid_stations_data):
            button_text = build_land_station_choice_text(
                station,
                input_state,
                obs_buttons_choice_abbreviations,
            )

            radio_button = tk.Radiobutton(
                frame, text=button_text, variable=selected_site_index, value=a, font=obs_font,
                justify="left", anchor="w", padx=10, pady=13, bg=tk_background_color, relief="raised",
                borderwidth=1, width=38, height=3, command=on_radio_select
            )
            radio_button.grid(row=3 + a, column=0, padx=50, pady=2, sticky="nw")

        bottom_row = 3 + len(valid_stations_data)
        back_button = tk.Button(frame, text="Back", font=button_font, width=6, command=back_command)
        back_button.grid(row=bottom_row, column=0, columnspan=2, padx=50, pady=(12, 10), sticky="sw")
        submit_button.grid(row=bottom_row, column=0, columnspan=2, padx=350, pady=(12, 10), sticky="sw")

    # --- Exception Handling ---
    except Exception as e:
        print(f"Error encountered in xobs_check_land: {type(e).__name__}: {e}")
        for widget in frame.winfo_children():
            if widget.winfo_class() != 'Frame': widget.destroy()
        frame.configure(bg=tk_background_color)
        error_button_font = tkFont.Font(family="Helvetica", size=16, weight="bold")
        label1 = tk.Label(frame, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
        label1.grid(row=0, column=0, padx=50, pady=10, sticky="w")
        instructions_label = tk.Label(frame, text=f"An error occurred: {e} Or you misspelled name or state", font=("Helvetica", 16), bg=tk_background_color, wraplength=800, justify="left")
        instructions_label.grid(row=1, column=0, padx=50, pady=(20, 10), sticky='w')
        instruction_text_2 = "Please check your connection or try again in a few minutes."
        #instructions_label_2 = tk.Label(frame, text=instruction_text_2, font=("Helvetica", 16), bg=tk_background_color)
        #instructions_label_2.grid(row=2, column=0, padx=50, pady=(20, 10), sticky='w')
        try:
            next_button = tk.Button(frame, text="Next", font=error_button_font, command=land_or_buoy)
            next_button.grid(row=2, column=0, padx=(50, 0), pady=10, sticky="w")
            tk.Button(frame, text="Back", font=error_button_font, command=back_command).grid(row=2, column=0, padx=(150,0), pady=10, sticky="w")
        except NameError:
            pass
            
    gc.collect()
    #snap_after = tracemalloc.take_snapshot()
    #top = snap_after.compare_to(snap_before, 'lineno')[:10]
    #print("[OBS] top allocators after site change:")
    #for stat in top:
        #print(stat)
            
def xobs_input_land(obs_type, frame, tk_background_color, button_font, back_command, submit_command_handler):
    """
    Displays UI for entering Town and State for a given observation type (aobs, bobs, cobs).

    Args:
        obs_type (str): 'aobs', 'bobs', or 'cobs'.
        frame (tk.Frame): The parent frame to build the UI in.
        tk_background_color (str): Background color for widgets.
        button_font (tk.font.Font): Font object for buttons.
        back_command (callable): Function to call when Back button is pressed.
        submit_command_handler (callable): Function to call with (town, state)
                                           when Submit button is pressed.
    """
    ordinal = get_obs_ordinal(obs_type)

    # Clear the current display in the target frame
    for widget in frame.winfo_children():
        widget.destroy()

    frame.grid(row=0, column=0, sticky="nsew")
    frame.configure(bg=tk_background_color) # Ensure frame background is set

    # --- UI Elements ---
    label1 = tk.Label(frame, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    # Adjusted columnspan and padding slightly if needed for 1024 width
    label1.grid(row=0, column=0, columnspan=2, padx=50, pady=(50, 0), sticky="nw")

    instruction_text = f"Please enter the name of the town for the {ordinal} observation site:"
    instructions_label = tk.Label(frame, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
    instructions_label.grid(row=1, column=0, columnspan=2, padx=50, pady=5, sticky='nw')

    # Use local variables for entry widgets
    town_entry = tk.Entry(frame, font=("Helvetica", 14), width=40) # Adjusted width example
    town_entry.grid(row=2, column=0, columnspan=2, padx=50, pady=5, sticky='nw')

    state_instruction_text = f"Please enter the 2-letter state ID for the {ordinal} observation site:"
    state_instructions_label = tk.Label(frame, text=state_instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
    state_instructions_label.grid(row=3, column=0, columnspan=2, padx=50, pady=5, sticky='nw')

    state_entry = tk.Entry(frame, font=("Helvetica", 14), width=5) # Adjusted width example
    state_entry.grid(row=4, column=0, columnspan=2, padx=50, pady=5, sticky='nw')

    instruction_text_2 = "After clicking SUBMIT, the system may pause while gathering observation stations."
    instructions_label_2 = tk.Label(frame, text=instruction_text_2, font=("Helvetica", 12), bg=tk_background_color, justify="left")
    instructions_label_2.grid(row=5, column=0, columnspan=2, padx=50, pady=10, sticky='nw')

    # --- Internal Submit Logic ---
    def _on_submit():
        global alternative_town_1, alternative_town_2, alternative_town_3, alternative_state_1, alternative_state_2, alternative_state_3
        
        # Get the raw input from the entry fields
        raw_town = town_entry.get()
        raw_state = state_entry.get()

        normalized_input = normalize_land_input_values(raw_town, raw_state)
        entered_town = normalized_input["entered_town"]
        entered_state = normalized_input["entered_state"]

        print(f"Submit clicked for {obs_type.upper()}. Town: '{entered_town}', State: '{entered_state}'")
        if not is_valid_land_input(entered_town, entered_state):
            if not entered_town:
                print("Error: Town cannot be empty.")
            else:
                print("Error: State must be 2 letters.")
            return

        submit_command_handler(entered_town, entered_state.upper()) # Pass state as uppercase
        
        apply_land_input_display_globals(
            ordinal,
            entered_town,
            entered_state,
            globals(),
        )
            
    # --- Buttons ---
    back_button = tk.Button(frame, text=" Back ", font=button_font, command=back_command)
    # Placed in column 0
    back_button.grid(row=6, column=0, padx=(50, 0), pady=15, sticky="w") # Adjusted pady

    submit_button = tk.Button(frame, text="Submit", command=_on_submit, font=button_font)
     # Placed in column 0 but offset using padx
    submit_button.grid(row=6, column=0, padx=(200, 0), pady=15, sticky="w") # Kept original padx offset logic relative to column 0 start

    # --- Bindings ---
    town_entry.bind("<FocusIn>", lambda e: set_current_target(town_entry))
    state_entry.bind("<FocusIn>", lambda e: [set_current_target(state_entry), set_state_uppercase()]) # Call both handlers

    # --- Focus ---
    town_entry.focus_set()
    
    # Check if current_target_entry exists before calling auto_capitalize
    if current_target_entry and current_target_entry.winfo_exists():
        auto_capitalize()  # call auto capitalize after focus bind.

    is_buoy_code = False #prepare for land input

    # Spacer to push the keyboard to the bottom
    spacer = tk.Label(frame1, text="", bg=tk_background_color)
    spacer.grid(row=7, column=0, sticky="nsew", pady=(0, 0))  # Adjust row and pady as necessary

    # Display the virtual keyboard
    create_virtual_keyboard(frame1, 8)  # Adjust as necessary based on layout

    try: root.grab_release()
    except: pass
    frame.update_idletasks()
    root.after_idle(lambda: town_entry.focus_force())
    root.after_idle(lambda: set_current_target(town_entry))

# --- Bridge Handler Functions for town/sate inputs for obs sites---

def handle_aobs_submission(entered_town, entered_state):
    """
    Bridge function called after AOBS input.
    Calls the (future) xobs_check_land function with necessary parameters.
    """
    print(f"\nSUBMIT HANDLER: Received AOBS input: Town='{entered_town}', State='{entered_state}'")
    print("Calling xobs_check_land for AOBS...")

    xobs_check_land(
        obs_type='aobs',
        input_town=entered_town,
        input_state=entered_state,
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=setup_aobs_input_land,
        confirm_command_handler=handle_aobs_confirmation,
    )

def handle_bobs_submission(entered_town, entered_state):
    """
    Bridge function called after BOBS input.
    Calls the (future) xobs_check_land function with necessary parameters.
    """
    print(f"\nSUBMIT HANDLER: Received BOBS input: Town='{entered_town}', State='{entered_state}'")
    print("Calling xobs_check_land for BOBS...")

    xobs_check_land(
        obs_type='bobs',
        input_town=entered_town,
        input_state=entered_state,
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=setup_bobs_input_land,
        confirm_command_handler=handle_bobs_confirmation,
    )

def handle_cobs_submission(entered_town, entered_state):
    """
    Bridge function called after COBS input.
    Calls the (future) xobs_check_land function with necessary parameters.
    """
    print(f"\nSUBMIT HANDLER: Received COBS input: Town='{entered_town}', State='{entered_state}'")
    print("Calling xobs_check_land for COBS...")

    xobs_check_land(
        obs_type='cobs',
        input_town=entered_town,
        input_state=entered_state,
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=setup_cobs_input_land,
        confirm_command_handler=handle_cobs_confirmation,
    )

def create_buoy_help_map_image(functional_buoys):
    create_buoy_help_map_screenshot(
        functional_buoys,
        CHROME_DRIVER_PATH,
        metadata_calculate_buoy_help_center,
        calculate_buoy_help_zoom_level,
        folium,
        Options,
        Service,
        webdriver,
        os,
        time,
        adjust_buoy_help_window_size,
    )
    
def receive_buoy_help_choice():
    global selected_buoy, buoy_help_flag, alternative_town_1, alternative_town_2, alternative_town_3
    # Retrieve the selected buoy's ID from the selected_buoy variable
    selected_buoy_code = normalize_station_id(selected_buoy.get())
    print("line 3856. inside receive buoy help choice.")        
    selected_handler = resolve_buoy_help_selection(
        buoy_help_flag,
        selected_buoy_code,
        apply_buoy_help_selection_globals,
        globals(),
        {
            "aobs": handle_aobs_buoy_submission,
            "bobs": handle_bobs_buoy_submission,
            "cobs": handle_cobs_buoy_submission,
        },
    )
    if buoy_help_flag == 'aobs':
        print("line 3858. inside receive buoy help choice, inside buoy help flag a.")

    if selected_handler:
        buoy_help_flag = None
        selected_handler(selected_buoy_code)

def show_buoy_help_choice(functional_buoys, buoy_cache):
    """
    (Refactored) Displays 3 functional buoys as radio buttons for user selection.

    This version scrapes the data for each button directly from the NDBC RSS feed,
    removing the dependency on the old buoy_cache.
    """
    global selected_buoy

    choice_entries = build_buoy_help_choice_entries(
        functional_buoys,
        lambda buoy_id: get_recent_buoy_rss_observation(
            buoy_id,
            timedelta(days=3650),
            requests,
            ElementTree,
            parser,
            datetime,
            timezone,
            timeout=10,
        ),
        build_buoy_choice_text_from_description,
    )
            
    # --- UI Setup (UNCHANGED) ---
    for widget in frame1.winfo_children():
        widget.destroy()
    frame1.grid_columnconfigure(9, weight=1)
    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, columnspan=9, padx=50, pady=(20, 0), sticky="nw")
    instruction_text = f"Please choose a buoy for the {alternative_town_3.title()} site."
    instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 14), bg=tk_background_color, justify="left")
    instructions_label.grid(row=1, column=0, columnspan=9, padx=50, pady=5, sticky='nw')
    instruction_text_2 = "Due to communication issues, not every available buoy will list every time this list is assembled."
    instructions_label_2 = tk.Label(frame1, text=instruction_text_2, font=("Helvetica", 12), bg=tk_background_color, justify="left", wraplength=800)
    instructions_label_2.grid(row=2, column=0, columnspan=9, padx=50, pady=5, sticky='nw')

    selected_buoy = tk.StringVar()
    def enable_submit(*args):
        submit_button.config(state="normal")
    selected_buoy.trace_add('write', enable_submit)

    # --- Create Radio Buttons (NEW LOGIC) ---
    for idx, choice_entry in enumerate(choice_entries):
        buoy_id = choice_entry["buoy_id"]
        buoy_info = choice_entry["button_text"]

        # Set button position (UNCHANGED)
        if idx == 0: button_pady = (2, 2)
        elif idx == 1: button_pady = (120, 2)
        else: button_pady = (240, 20)
        fixed_width = 33

        # Add radio button for each buoy
        tk.Radiobutton(frame1, text=buoy_info, variable=selected_buoy, value=buoy_id, bg=tk_background_color,
                        font=("Helvetica", 12), justify="left", anchor="w", padx=10, pady=10,
                        relief="raised", borderwidth=1, width=fixed_width).grid(row=3, column=0, columnspan=9, padx=50, pady=button_pady, sticky="nw")

    # --- Map and Submit Button Creation (UNCHANGED) ---
    create_buoy_help_map_image(functional_buoys)
    
    img_path = "/home/santod/buoy_locations.png"
    img = Image.open(img_path)
    img = img.resize((450, 300), Image.LANCZOS)
    tk_img = ImageTk.PhotoImage(img)
    
    label = tk.Label(frame1, image=tk_img)
    label.image = tk_img
    label.grid(row=3, column=8, sticky="se", padx=(370, 10), pady=(170, 5))
    
    img.close()
    try: os.remove(img_path)
    except FileNotFoundError: pass
    
    submit_button = tk.Button(frame1, text="Submit", font=("Helvetica", 16, "bold"), relief="raised", borderwidth=1, state="disabled", command=receive_buoy_help_choice)
    submit_button.grid(row=3, column=0, rowspan=4, padx=50, pady=(400,10), sticky="nw")


def adjust_buoy_help_window_size(driver, target_width, target_height):
    # Run JavaScript to get the size of the visible content area
    width = driver.execute_script("return window.innerWidth;")
    height = driver.execute_script("return window.innerHeight;")
    
    # Calculate the difference between the actual and desired dimensions
    width_diff = target_width - width
    height_diff = target_height - height

    # Adjust the window size based on the difference
    current_window_size = driver.get_window_size()
    new_width = current_window_size['width'] + width_diff
    new_height = current_window_size['height'] + height_diff
    driver.set_window_size(new_width, new_height)
    
def calculate_buoy_help_distance(point1, point2):

    return geodesic(point1, point2).kilometers

def calculate_buoy_help_zoom_level(functional_buoys):
    return metadata_calculate_buoy_help_zoom_level(functional_buoys, geodesic)

def find_buoy_choice(buoy_search_lat, buoy_search_lon):
    """
    (Refactored) Finds 3 functional buoys near a given location.

    This version uses a local JSON file for buoy locations and scrapes the
    NDBC RSS feed to check for recent activity, completely removing the
    dependency on MesoWest. It preserves the parallel execution for performance.
    """
    print("\n--- Running find_buoy_choice (Refactored) ---")
    
    # --- Configuration ---
    # This is now the single place to adjust how old a report can be.
    MAX_OBS_AGE = timedelta(hours=5)

    # --- Helper Functions ---

    # def load_buoy_help_locations():
        # """
        # Loads the master list of buoy locations from the local JSON file.
        # This is much faster and more reliable than a live download.
        # """
        # try:
            # with open("/home/santod/buoy_metadata.json") as f:
                # return json.load(f)
        # except Exception as e:
            # print(f"Error: Could not load buoy metadata file: {e}")
            # return []

    current_location = (buoy_search_lat, buoy_search_lon)

    final_buoy_list = gather_buoy_help_choices(
        current_location,
        "/home/santod/buoy_metadata.json",
        load_buoy_metadata_cached,
        lambda search_location, all_buoys: find_buoy_help_nearest_buoys(
            search_location,
            all_buoys,
            geodesic,
        ),
        lambda nearest_buoys: fetch_functional_buoy_help_candidates(
            nearest_buoys,
            10,
            lambda buoy_id: check_buoy_help_functionality(
                buoy_id,
                MAX_OBS_AGE,
                requests,
                ElementTree,
                parser,
                datetime,
                timezone,
            ),
            concurrent.futures,
        ),
        build_buoy_help_final_list,
    )

    if len(final_buoy_list) >= 3:
        print("\n--- Final Functional Buoys ---")
        for buoy_info in final_buoy_list:
            print(f"ID: {buoy_info[0]}, Lat: {buoy_info[1]}, Lon: {buoy_info[2]}")
        print("------------------------------")
        
        # Call the existing map display function with the results
        show_buoy_help_choice(final_buoy_list, {})

    else:
        print("Could not find at least 3 functional buoys within range.")

def submit_buoy_help_town():
    # Get the user's input from the entry boxes
    normalized_input = normalize_buoy_help_town_state_input(
        buoy_help_town_entry.get(),
        buoy_help_state_entry.get(),
    )
    town = normalized_input["town"]
    state = normalized_input["state"]

    # Initialize the geolocator
    geolocator = Nominatim(user_agent="buoy_locator")

    try:
        submit_buoy_help_town_workflow(
            town,
            state,
            geolocator,
            find_buoy_choice,
        )
    except GeocoderTimedOut:
        print("The geocoding service timed out. Please try again.")


def submit_buoy_help_coord():
    global buoy_search_lat, buoy_search_lon
    # Retrieve the values from the entry boxes
    lat_value = buoy_search_lat.get()
    lon_value = buoy_search_lon.get()
    
    try:
        buoy_search_lat, buoy_search_lon = submit_buoy_help_coord_workflow(
            lat_value,
            lon_value,
            parse_buoy_help_coordinates,
            find_buoy_choice,
        )
    except ValueError:
        # Handle invalid input (non-numeric values, etc.)
        print("Invalid latitude or longitude entered. Please try again.")


def buoy_near_me():
    global buoy_search_lat, buoy_search_lon
    
    buoy_search_lat, buoy_search_lon = submit_buoy_help_near_me_workflow(
        latitude,
        longitude,
        find_buoy_choice,
    )
    
def buoy_help_by_town():
    global buoy_help_town_entry, buoy_help_state_entry
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")

    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, columnspan=20, padx=50, pady=(50,0), sticky="nw")
    
    instruction_text = "Please enter the name of the town from which to search for buoys:"
    instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
    instructions_label.grid(row=1, column=0, columnspan=20, padx=50, pady=5, sticky='nw')

    buoy_help_town_entry = tk.Entry(frame1, font=("Helvetica", 14))
    buoy_help_town_entry.grid(row=2, column=0, columnspan=20, padx=50, pady=5, sticky='nw')

    # Automatically set focus to the town_entry widget
    buoy_help_town_entry.focus_set()

    state_instruction_text = "Please enter the 2-letter state ID:"
    state_instructions_label = tk.Label(frame1, text=state_instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
    state_instructions_label.grid(row=3, column=0, columnspan=20, padx=50, pady=5, sticky='nw')

    buoy_help_state_entry = tk.Entry(frame1, font=("Helvetica", 14))
    buoy_help_state_entry.grid(row=4, column=0, columnspan=20, padx=50, pady=5, sticky='nw')

    instruction_text_2 = "After clicking SUBMIT, the system will pause while gathering a list of functioning buoys."
    instructions_label_2 = tk.Label(frame1, text=instruction_text_2, font=("Helvetica", 12), bg=tk_background_color, justify="left")
    instructions_label_2.grid(row=5, column=0, columnspan=20, padx=50, pady=10, sticky='nw')

    # Create the 'Back' button
    back_button = tk.Button(frame1, text=" Back ", font=button_font, command=buoy_help)
    back_button.grid(row=6, column=0, columnspan=20, padx=(50, 0), pady=5, sticky="w")

    submit_button = tk.Button(frame1, text="Submit", command=submit_buoy_help_town, font=button_font)
    submit_button.grid(row=6, column=0, columnspan=20, padx=200, pady=5, sticky='nw')

    buoy_help_town_entry.bind("<FocusIn>", lambda e: set_current_target(buoy_help_town_entry))
    buoy_help_state_entry.bind("<FocusIn>", lambda e: set_current_target(buoy_help_state_entry))

    # Spacer to push the keyboard to the bottom
    spacer = tk.Label(frame1, text="", bg=tk_background_color)
    spacer.grid(row=7, column=0, sticky="nsew", pady=(0, 10))  # Adjust row and pady as necessary
    
    # Display the virtual keyboard
    create_virtual_keyboard(frame1, 8)  # Adjust as necessary based on layout

def buoy_help_by_coord():
    global buoy_search_lat, buoy_search_lon
    
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")

    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, columnspan=6, padx=50, pady=(50,0), sticky="nw")

    instruction_text = "Please enter the latitude and longitude from which to start searching for buoys:"
    instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
    instructions_label.grid(row=1, column=0, columnspan=6, padx=50, pady=5, sticky='nw')

    # Latitude Entry with degree symbol and 'N' all in one row using grid
    lat_label = tk.Label(frame1, text="Latitude:", font=("Helvetica", 14), bg=tk_background_color)
    lat_label.grid(row=2, column=0, padx=(50, 5), pady=5, sticky='w')
    buoy_search_lat = tk.Entry(frame1, font=("Helvetica", 14), width=6)  # Adjust width for 'XXX.X'
    buoy_search_lat.grid(row=2, column=0, padx=150, pady=5, sticky='w')
    lat_symbol = tk.Label(frame1, text="°N", font=("Helvetica", 14), bg=tk_background_color)
    lat_symbol.grid(row=2, column=0, padx=(220, 0), pady=5, sticky='w')

    # Automatically set focus to the latitude entry widget
    buoy_search_lat.focus_set()

    # Longitude Entry with degree symbol and 'W' all in one row using grid
    lon_label = tk.Label(frame1, text="Longitude:", font=("Helvetica", 14), bg=tk_background_color)
    lon_label.grid(row=3, column=0, padx=(50, 5), pady=5, sticky='w')
    buoy_search_lon = tk.Entry(frame1, font=("Helvetica", 14), width=6)  # Adjust width for 'XXX.X'
    buoy_search_lon.grid(row=3, column=0, padx=150, pady=5, sticky='w')
    lon_symbol = tk.Label(frame1, text="°W", font=("Helvetica", 14), bg=tk_background_color)
    lon_symbol.grid(row=3, column=0, padx=(220, 0), pady=5, sticky='w')

    instruction_text_2 = "After clicking SUBMIT, the system will pause while gathering a list of functioning buoys."
    instructions_label_2 = tk.Label(frame1, text=instruction_text_2, font=("Helvetica", 12), bg=tk_background_color, justify="left")
    instructions_label_2.grid(row=4, column=0, columnspan=6, padx=50, pady=10, sticky='nw')

    # Create the 'Back' button
    back_button = tk.Button(frame1, text=" Back ", font=button_font, command=buoy_help)
    back_button.grid(row=5, column=0, padx=(50, 0), pady=5, sticky="w")

    submit_button = tk.Button(frame1, text="Submit", command=submit_buoy_help_coord, font=button_font)
    submit_button.grid(row=5, column=0, padx=150, pady=5, sticky='w')

    buoy_search_lat.bind("<FocusIn>", lambda e: set_current_target(buoy_search_lat))
    buoy_search_lon.bind("<FocusIn>", lambda e: set_current_target(buoy_search_lon))

    spacer = tk.Label(frame1, text="", bg=tk_background_color)
    spacer.grid(row=6, column=0, columnspan=6, sticky="nsew", pady=(0, 10))

    # Display the virtual keyboard at a lower position (start_row shifted down)
    create_virtual_keyboard(frame1, 10)  # Adjust this value to move the keyboard lower

def buoy_help():
    
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")

    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, columnspan=20, padx=50, pady=(50,50), sticky="nw")
    
    instruction_text = "Choose how you would like to search for buoy codes."
    instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
    instructions_label.grid(row=1, column=0, columnspan=20, padx=50, pady=15, sticky='nw')
    
    buoy_nearby_button = tk.Button(frame1, text="Buoys Near Me", command=buoy_near_me, font=("Helvetica", 13, "bold"))
    buoy_nearby_button.grid(row=3, column=0, columnspan=20, padx=50, pady=5, sticky='nw')
    
    buoy_town_button = tk.Button(frame1, text="Town/State", command=buoy_help_by_town, font=("Helvetica", 13, "bold"))
    buoy_town_button.grid(row=3, column=0, columnspan=20, padx=240, pady=5, sticky='nw')
    
    buoy_coordinates_button = tk.Button(frame1, text="Latitude/Longitude", command=buoy_help_by_coord, font=("Helvetica", 13, "bold"))
    buoy_coordinates_button.grid(row=3, column=0, columnspan=20, padx=395, pady=5, sticky='nw')
  
def setup_aobs_input_buoy():
    """Sets up and calls buoy_obs_input for the AOBS (first) site."""
    print("Running setup_aobs_input_buoy...")

    buoy_obs_input(
        obs_type='aobs',
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=land_or_buoy,
        help_command=buoy_help,
        submit_command_handler=handle_aobs_buoy_submission,
    )

def setup_bobs_input_buoy():
    """Sets up and calls buoy_obs_input for the BOBS (second) site."""
    print("Running setup_bobs_input_buoy...")

    buoy_obs_input(
        obs_type='bobs',
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=bobs_land_or_buoy,
        help_command=buoy_help,
        submit_command_handler=handle_bobs_buoy_submission,
    )

def setup_cobs_input_buoy():
    """Sets up and calls buoy_obs_input for the COBS (third) site."""
    print("Running setup_cobs_input_buoy...")

    buoy_obs_input(
        obs_type='cobs',
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        back_command=cobs_land_or_buoy,
        help_command=buoy_help,
        submit_command_handler=handle_cobs_buoy_submission,
    )


def buoy_obs_check(obs_type, buoy_code, frame, tk_background_color, button_font, success_next_command, failure_back_command):
    """
    (Refactored v2) Checks buoy validity, then performs a synchronous data
    fetch to ensure the UI is updated immediately.
    """
    # --- Initial Setup (UNCHANGED) ---
    for widget in frame.winfo_children():
        widget.destroy()
    frame.grid(row=0, column=0, sticky="nsew")
    frame.configure(bg=tk_background_color)

    # Determine ordinal (UNCHANGED)
    buoy_selection_details = apply_buoy_selection_globals(
        obs_type,
        buoy_code,
        globals(),
    )
    ordinal = buoy_selection_details["ordinal"]
    current_only_click_flag = buoy_selection_details["current_only_click_flag"]

    label1 = tk.Label(frame, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, padx=50, pady=(50,0), sticky="w")

    # --- Buoy Check via NDBC RSS Feed (UNCHANGED) ---
    print(f"Checking NDBC RSS feed for buoy: {buoy_code}")
    next_function = None
    message_label = None

    validation_result = validate_buoy_observation_workflow(
        obs_type,
        buoy_code,
        current_only_click_flag,
        globals(),
        lambda requested_buoy_code: get_recent_buoy_rss_observation(
            requested_buoy_code,
            timedelta(hours=5),
            requests,
            ElementTree,
            parser,
            datetime,
            timezone,
            timeout=15,
        ),
        get_buoy_data,
        populate_single_buoy_observation_globals,
        clear_obs_only_click_flag,
        success_next_command,
        failure_back_command,
        return_to_image_cycle,
    )

    if validation_result["success"]:
        accept_text = f"Buoy {buoy_code} will be used for the {ordinal} observation site."
        message_label = tk.Label(frame, text=accept_text, font=("Helvetica", 16,), bg=tk_background_color)
        next_function = validation_result["next_function"]
    else:
        message_label = tk.Label(
            frame,
            text=validation_result["message_text"],
            font=("Helvetica", 16,),
            bg=tk_background_color,
            justify="left",
        )
        next_function = validation_result["next_function"]

    # --- Display Message and Next Button (UNCHANGED) ---
    if message_label:
        message_label.grid(row=1, column=0, padx=50, pady=(20,10), sticky="w")

    if next_function:
        next_button_text = " Next " if next_function == success_next_command or next_function == return_to_image_cycle else " Back "
        # Assuming create_button is a valid helper function you have elsewhere
        next_button = tk.Button(frame, text=next_button_text, font=button_font, command=next_function)
        next_button.grid(row=3, column=0, padx=(200, 0), pady=10, sticky="w")
    else:
        print("Error: Next function was not determined.")
        fallback_label = tk.Label(frame, text="An unexpected error occurred.", font=("Helvetica", 16,), bg=tk_background_color)
        fallback_label.grid(row=1, column=0, padx=50, pady=(20,10), sticky="w")

def handle_aobs_buoy_submission(buoy_code):
    """
    Handles submission for AOBS buoy input.
    Assigns the code to alternative_town_1 and calls the check function.
    """
    print(f"HANDLER AOBS: Received code '{buoy_code}'. Assigning to alternative_town_1.")
    print("HANDLER AOBS: Calling buoy_obs_check")
    apply_buoy_display_name('aobs', buoy_code, globals())
    buoy_obs_check(
        obs_type='aobs',
        buoy_code=buoy_code,
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        success_next_command=bobs_land_or_buoy,
        failure_back_command=land_or_buoy,
    )

def handle_bobs_buoy_submission(buoy_code):
    """
    Handles submission for BOBS buoy input.
    Assigns the code to alternative_town_2 and calls the check function.
    """
    print(f"HANDLER BOBS: Received code '{buoy_code}'. Assigning to alternative_town_2.")
    print("HANDLER BOBS: Calling buoy_obs_check")
    apply_buoy_display_name('bobs', buoy_code, globals())
    buoy_obs_check(
        obs_type='bobs',
        buoy_code=buoy_code,
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        success_next_command=cobs_land_or_buoy,
        failure_back_command=bobs_land_or_buoy,
    )

def handle_cobs_buoy_submission(buoy_code):
    """
    Handles submission for COBS buoy input.
    Assigns the code to alternative_town_3 and calls the check function.
    """
    print(f"HANDLER COBS: Received code '{buoy_code}'. Assigning to alternative_town_3.")
    print("HANDLER COBS: Calling buoy_obs_check")
    apply_buoy_display_name('cobs', buoy_code, globals())
    buoy_obs_check(
        obs_type='cobs',
        buoy_code=buoy_code,
        frame=frame1,
        tk_background_color=tk_background_color,
        button_font=button_font,
        success_next_command=page_choose,
        failure_back_command=cobs_land_or_buoy,
    )


def buoy_obs_input(obs_type, frame, tk_background_color, button_font, back_command, help_command, submit_command_handler):
    """
    Displays UI for entering the 5-character buoy code for a given observation type.

    Args:
        obs_type (str): 'aobs', 'bobs', or 'cobs'.
        frame (tk.Frame): The parent frame to build the UI in.
        tk_background_color (str): Background color for widgets.
        button_font (tuple): Font tuple for buttons (e.g., ("Helvetica", 14, "bold")).
        back_command (callable): Function to call when Back button is pressed.
        help_command (callable): buoy_help.
        submit_command_handler (callable): Function to call with the entered buoy code
                                           when Submit button is pressed.
    """
    global is_buoy_code, current_target_entry, buoy_help_flag

    # Reset current_target_entry for this input screen
    current_target_entry = None

    ordinal = get_obs_ordinal(obs_type)
    buoy_help_flag = obs_type if obs_type in {"aobs", "bobs", "cobs"} else None

    # Clear the current display in the target frame
    for widget in frame.winfo_children():
        widget.destroy()

    frame.grid(row=0, column=0, sticky="nsew")
    frame.configure(bg=tk_background_color) # Ensure frame background is set

    # --- UI Elements ---
    label1 = tk.Label(frame, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, columnspan=20, padx=50, pady=(50, 0), sticky="nw") # Match original layout

    instruction_text = f"Please enter the 5-character code for the buoy for the {ordinal} site:"
    instructions_label = tk.Label(frame, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
    instructions_label.grid(row=1, column=0, columnspan=20, padx=50, pady=5, sticky='nw')

    # Use a local variable for the entry widget
    buoy_code_entry = tk.Entry(frame, font=("Helvetica", 14))
    buoy_code_entry.grid(row=2, column=0, columnspan=20, padx=50, pady=5, sticky='nw')

    # --- Internal Submit Logic ---
    def _on_submit():
        # Get the user's input
        entered_code = normalize_station_id(buoy_code_entry.get())

        if len(entered_code) != 5:
            print(f"Error: Buoy code '{entered_code}' is not 5 characters long.")
            # Optional: Display error message to user (e.g., using tk.messagebox or a label)
            # Re-create keyboard if needed, or simply return to allow re-entry
            # create_virtual_keyboard(frame, 7) # Recreate if needed
            # buoy_code_entry.focus_set()       # Set focus back
            tk.messagebox.showerror("Input Error", "Buoy code must be exactly 5 characters long.", parent=frame)
            return # Stop processing if invalid

        # Add more validation if needed (e.g., check if alphanumeric)

        print(f"Submit clicked for {obs_type.upper()}. Buoy Code: '{entered_code}'")

        # Call the specific handler function passed in, providing the validated code
        submit_command_handler(entered_code)

    # --- Buttons ---
    submit_button = tk.Button(frame, text="Submit", command=_on_submit, font=("Helvetica", 16, "bold")) # Match original font
    submit_button.grid(row=3, column=0, columnspan=20, padx=50, pady=5, sticky='nw') # Match original layout

    help_option_text = "Or, if you want to choose a buoy and need help getting the code, click Buoy Help."
    help_option_label = tk.Label(frame, text=help_option_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
    help_option_label.grid(row=4, column=0, columnspan=20, padx=50, pady=5, sticky='nw') # Match original layout

    # Use the help_command passed in
    help_button = tk.Button(frame, text="Buoy Help", command=help_command, font=("Helvetica", 14, "bold")) # Match original font
    help_button.grid(row=5, column=0, columnspan=20, padx=50, pady=5, sticky='nw') # Match original layout

    # Optional: Add a Back button if needed, using back_command
    # back_button = tk.Button(frame, text=" Back ", font=button_font, command=back_command)
    # back_button.grid(row=X, column=Y, ...) # Position as needed

    # Spacer to push the keyboard to the bottom
    spacer = tk.Label(frame, text="", bg=tk_background_color)
    spacer.grid(row=6, column=0, sticky="nsew", pady=(0, 40)) # Match original layout

    # --- Bindings and Focus ---
    buoy_code_entry.bind("<FocusIn>", lambda e: set_current_target(buoy_code_entry))

    # Automatically set focus to the entry widget
    buoy_code_entry.focus_set()

    # Set flag for keyboard type
    is_buoy_code = True

    # Display the alphanumeric keyboard (adjust row as needed based on final layout)
    create_virtual_keyboard(frame, 7) # Match original row target
    

def xobs_confirm_land(frame, tk_background_color, button_font,
                      selected_station_data, ordinal_text,
                      back_command_for_confirm, next_command_for_confirm):
    """
    Displays the confirmation screen after a station is chosen.

    Args:
        frame: The target Tkinter frame.
        tk_background_color: Background color string.
        button_font: Tkinter font object for buttons.
        selected_station_data (dict): Dictionary containing info about the chosen station (needs at least 'name').
        ordinal_text (str): "first", "second", or "third".
        back_command_for_confirm (callable): Function for the Back button.
        next_command_for_confirm (callable): Function for the Next button.
    """
    
    global alternative_town_1, alternative_town_2, alternative_town_3
    
    print(f"--- Running xobs_confirm_land ---")
    print(f"  Confirming: {selected_station_data.get('name', 'N/A')} as {ordinal_text} site.")
    print(f"  Back command: {back_command_for_confirm.__name__ if callable(back_command_for_confirm) else 'None'}")
    print(f"  Next command: {next_command_for_confirm.__name__ if callable(next_command_for_confirm) else 'None'}")
    
    # 1. Clear the current frame
    for widget in frame.winfo_children():
        widget.destroy()
    frame.configure(bg=tk_background_color)
    # Ensure frame is gridded if it lost its parent config (usually not needed if frame itself wasn't destroyed)
    # frame.grid(row=0, column=0, sticky="nsew") # Re-grid if necessary

    # 2. Display the confirmation labels
    label1 = tk.Label(frame, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, padx=50, pady=(50,0), sticky="w") # Match original padding

    # Use station name from the passed data
    station_name = selected_station_data.get('name', 'Selected Station') # Fallback name
    instruction_text1 = f"{station_name}"
    instructions_label1 = tk.Label(frame, text=instruction_text1, font=("Helvetica", 16,), bg=tk_background_color)
    instructions_label1.grid(row=1, column=0, padx=50, pady=(20, 5), sticky='w') # Match original padding

    instruction_text2 = f"will be used for the {ordinal_text} observation site."
    instructions_label2 = tk.Label(frame, text=instruction_text2, font=("Helvetica", 16,), bg=tk_background_color)
    instructions_label2.grid(row=2, column=0, padx=50, pady=(5, 10), sticky='w') # Match original padding

    # 3. Create Back and Next buttons using passed commands
    # Assuming create_button is available:
    try:
        back_button = create_button(frame, " Back ", button_font, back_command_for_confirm)
        back_button.grid(row=4, column=0, padx=(50, 0), pady=10, sticky="w")

        next_button = create_button(frame, " Next ", button_font, next_command_for_confirm)
        next_button.grid(row=4, column=0, padx=(200, 0), pady=10, sticky="w")
    except NameError:
        # Fallback if create_button doesn't exist
        print("Warning: create_button function not found. Using standard tk.Button.")
        back_button = tk.Button(frame, text=" Back ", font=button_font, command=back_command_for_confirm)
        back_button.grid(row=4, column=0, padx=(50, 0), pady=10, sticky="w")

        next_button = tk.Button(frame, text=" Next ", font=button_font, command=next_command_for_confirm)
        next_button.grid(row=4, column=0, padx=(200, 0), pady=10, sticky="w")

    print(f"--- xobs_confirm_land UI build complete ---")   
                
            
def create_button(frame1, text, font, command_func):
    button = tk.Button(frame1, text=text, font=font, command=command_func)
    return button

def remove_checkbox():
    choice_check_button.destory()

def choose_lcl_radar():
    """
    Displays the local radar site selection map.
    Loads map and metadata directly from files each time.
    """
    global box_variables, submit_button # Add any other globals this function MODIFIES (like closest_site, etc. if needed globally)
                         # Globals only ACCESSED don't strictly need declaration here but doesn't hurt

    # Inside choose_lcl_radar, before defining lcl_radar_on_click
    
    submit_button = None # Initialize the global variable

    # --- 1. Check if map data was unavailable during initialization ---
    if lcl_radar_map_unavailable:
        # Clear the current display
        for widget in frame1.winfo_children():
            widget.destroy()
        frame1.grid(row=0, column=0, sticky="nsew") # Ensure frame is clean

        # Display the error message and the Next button
        unavailable_message = "The map showing local radar stations failed to load during startup and is unavailable."
        message_label = tk.Label(frame1, text=unavailable_message, font=("Arial", 16), justify='left', bg=tk_background_color, wraplength=500)
        message_label.grid(row=0, column=0, padx=50, pady=100, sticky='nw')
        box_variables[2] = 0 # Assuming this state change is appropriate on failure
        next_button = tk.Button(frame1, text="Next", command=lightning_center_input, font=("Helvetica", 16, "bold"))
        next_button.grid(row=1, column=0, padx=50, pady=20, sticky="nw")
        return # Stop execution of this function

    # --- 2. Load map and metadata directly from files ---
    lcl_radar_map_path = "/home/santod/lcl_radar_map.png"
    lcl_radar_metadata_path = "/home/santod/lcl_radar_metadata.json"
    map_screenshot_image = None
    radar_sites = None

    try:
        map_screenshot_image = Image.open(lcl_radar_map_path)

        with open(lcl_radar_metadata_path, "r") as metadata_file:
            radar_sites = json.load(metadata_file)

        # Basic validation
        if not isinstance(radar_sites, list):
             print("[ERROR] Radar metadata does not contain a list.")
             raise ValueError("Invalid metadata format: expected a list.")

    except FileNotFoundError:
        error_message = f"Error: Required map or metadata file not found.\nExpected at:\n{lcl_radar_map_path}\n{lcl_radar_metadata_path}"
        print(f"[ERROR] choose_lcl_radar: {error_message}")
        # Display error in GUI
        for widget in frame1.winfo_children(): widget.destroy()
        frame1.grid(row=0, column=0, sticky="nsew")
        tk.Label(frame1, text=error_message, font=("Arial", 14), justify='left', bg=tk_background_color, wraplength=500).grid(row=0, column=0, padx=50, pady=100, sticky='nw')
        box_variables[2] = 0
        tk.Button(frame1, text="Next", command=lightning_center_input, font=("Helvetica", 16, "bold")).grid(row=1, column=0, padx=50, pady=20, sticky="nw")
        return
    except json.JSONDecodeError as e:
        error_message = f"Error decoding radar metadata file:\n{lcl_radar_metadata_path}\nDetails: {e}"
        print(f"[ERROR] choose_lcl_radar: {error_message}")
        # Display error in GUI (similar to FileNotFoundError)
        for widget in frame1.winfo_children(): widget.destroy()
        frame1.grid(row=0, column=0, sticky="nsew")
        tk.Label(frame1, text=error_message, font=("Arial", 14), justify='left', bg=tk_background_color, wraplength=500).grid(row=0, column=0, padx=50, pady=100, sticky='nw')
        box_variables[2] = 0
        tk.Button(frame1, text="Next", command=lightning_center_input, font=("Helvetica", 16, "bold")).grid(row=1, column=0, padx=50, pady=20, sticky="nw")
        return
    except Exception as e:
        error_message = f"An unexpected error occurred loading map/metadata:\n{e}"
        print(f"[ERROR] choose_lcl_radar: {error_message}")
        # Display error in GUI (similar to FileNotFoundError)
        for widget in frame1.winfo_children(): widget.destroy()
        frame1.grid(row=0, column=0, sticky="nsew")
        tk.Label(frame1, text=error_message, font=("Arial", 14), justify='left', bg=tk_background_color, wraplength=500).grid(row=0, column=0, padx=50, pady=100, sticky='nw')
        box_variables[2] = 0
        tk.Button(frame1, text="Next", command=lightning_center_input, font=("Helvetica", 16, "bold")).grid(row=1, column=0, padx=50, pady=20, sticky="nw")
        return

    # --- 3. Prepare frame and data (if loading succeeded) ---
    if box_variables[2] == 0: # Check from original logic
        lightning_center_input()

    # Clear the current display now that we know loading worked
    for widget in frame1.winfo_children():
        widget.destroy()
    frame1.grid(row=0, column=0, sticky="nsew") # Reset frame


    # --- 4. Resize image and scale coordinates ---
    target_width, target_height = 800, 444
    scaled_radar_sites = [] # Use a new list for scaled data

    try:
        # Calculate scale factor based on the image just loaded
        scale_factor = target_width / map_screenshot_image.width

        # Resize the map image (creates a new image object)
        resized_map_image = map_screenshot_image.resize((target_width, target_height), Image.LANCZOS)

        # Scale coordinates safely into the new list
        scaled_radar_sites = copy.deepcopy(radar_sites) # Start with a deep copy
        for site in scaled_radar_sites:
            if 'coordinates' in site and isinstance(site['coordinates'], (list, tuple)) and len(site['coordinates']) >= 2:
                original_coords = site['coordinates']
                # Assuming coordinates are (x, y, radius...) - scale x, y
                scaled_coords = tuple(int(original_coords[i] * scale_factor) for i in range(2))
                site['coordinates'] = scaled_coords + tuple(original_coords[2:]) # Combine scaled x,y with rest
            else:
                print(f"[WARN] Invalid or missing coordinates for site: {site.get('site_code', 'N/A')}")
                # Decide how to handle invalid sites - skip, use defaults? Here we just leave coords as they are.

    except Exception as e:
        error_message = f"Error resizing map/site data:\n{e}"
        print(f"[ERROR] choose_lcl_radar: {error_message}")
        # Display error in GUI
        tk.Label(frame1, text=error_message, font=("Arial", 14), justify='left', bg=tk_background_color, wraplength=500).grid(row=0, column=0, padx=50, pady=100, sticky='nw')
        box_variables[2] = 0
        tk.Button(frame1, text="Next", command=lightning_center_input, font=("Helvetica", 16, "bold")).grid(row=1, column=0, padx=50, pady=20, sticky="nw")
        return

    # --- 5. Define Nested Functions (Helpers) ---
    # These functions will use 'scaled_radar_sites' from the outer scope

    def lcl_radar_find_closest_site(x, y):
        """Finds the closest site in scaled_radar_sites to click coordinates."""
        min_distance = float('inf')
        closest_site_found = None
        if not scaled_radar_sites:
            return None
        for site in scaled_radar_sites:
            # Ensure coordinates are valid before calculating distance
            if 'coordinates' in site and isinstance(site['coordinates'], (list, tuple)) and len(site['coordinates']) >= 3:
                 site_x, site_y, site_radius = site['coordinates'][:3] # Take first 3 elements
                 # Basic distance calculation (ignoring radius for simplicity here, adjust if needed)
                 # distance = ((x - site_x) ** 2 + (y - site_y) ** 2) ** 0.5
                 # Original logic accounting for radius:
                 distance = ((x - site_x) ** 2 + (y - site_y) ** 2) ** 0.5 - site_radius

                 if distance < min_distance:
                     min_distance = distance
                     closest_site_found = site
            else:
                 print(f"[WARN] Skipping site {site.get('site_code', 'N/A')} in closest site calculation due to invalid coords.")
        return closest_site_found

    def lcl_radar_draw_links():
        """Draws indicators on the map (if needed). Uses scaled_radar_sites."""
        # Currently commented out in original - implement if needed
        # print("[DEBUG] Drawing radar links (if implemented)")
        # if not scaled_radar_sites: return
        # for site in scaled_radar_sites:
        #     if 'coordinates' in site ... :
        #         site_x, site_y, site_radius = site['coordinates'][:3]
        #         label.create_oval(site_x - site_radius, site_y - site_radius, site_x + site_radius, site_y + site_radius, outline="red")
        pass # Placeholder if not drawing anything

    # Define variables needed within lcl_radar_on_click scope
    confirm_label = None
    lcl_radar_zoom_label = None
    lcl_radar_dropdown = None
    # Note: We do NOT need to initialize message_label = None here anymore, 
    # because we will use the global one.
    
    closest_site = None 
    global radar_identifier  
    radar_identifier = None  

    def lcl_radar_on_click(event):
        """Handles clicks on the radar map."""
        # 1. Keep these as nonlocal (they belong to choose_lcl_radar)
        nonlocal confirm_label, lcl_radar_zoom_label, lcl_radar_dropdown
        nonlocal closest_site
        
        # 2. CRITICAL CHANGE: Add 'message_label' to the GLOBAL list.
        # This allows this function to "see" and destroy the error message 
        # created by the separate confirm_radar_site function.
        global lcl_radar_zoom_clicks, submit_button, radar_identifier, message_label

        # Destroy previous dynamic widgets if they exist
        if confirm_label and confirm_label.winfo_exists(): confirm_label.destroy()
        if lcl_radar_zoom_label and lcl_radar_zoom_label.winfo_exists(): lcl_radar_zoom_label.destroy()
        if lcl_radar_dropdown and lcl_radar_dropdown.winfo_exists(): lcl_radar_dropdown.destroy()
        
        # 3. Clear the "Unavailable" error (or any other message) immediately
        if message_label and message_label.winfo_exists(): 
             message_label.destroy()
             message_label = None

        # Try reading the global submit_button
        if submit_button and submit_button.winfo_exists():
            submit_button.destroy()

        # Reset zoom level
        lcl_radar_zoom_clicks.set(0)

        x, y = event.x, event.y
        closest_site = lcl_radar_find_closest_site(x, y) # Use helper

        if closest_site and 'site_code' in closest_site:
            radar_identifier = closest_site['site_code']

            # Update the confirm_label
            confirm_text = f"You chose\nradar site:\n{radar_identifier}"
            confirm_label = tk.Label(frame1, text=confirm_text, font=("Arial", 16), justify='left', bg=tk_background_color)
            confirm_label.grid(row=0, column=0, padx=50, pady=160, sticky='nw')

            # Display zoom options label
            lcl_radar_zoom_text = f"Select the\nzoom"
            lcl_radar_zoom_label = tk.Label(frame1, text=lcl_radar_zoom_text, font=("Arial", 16), justify='left', bg=tk_background_color)
            lcl_radar_zoom_label.grid(row=0, column=0, padx=(50, 0), pady=(250, 0), sticky='nw')

            # Create and place the OptionMenu widget for zoom
            lcl_radar_choices = [0, 1, 2, 3, 4]
            lcl_radar_dropdown = tk.OptionMenu(frame1, lcl_radar_zoom_clicks, *lcl_radar_choices)
            lcl_radar_dropdown.config(font=("Helvetica", 14)) 
            lcl_radar_dropdown.grid(row=0, column=0, padx=(50, 0), pady=(300, 0), sticky="nw")

            # Create a submit button
            submit_button = tk.Button(frame1, text="Submit", command=confirm_radar_site, font=("Helvetica", 16, "bold"))
            submit_button.grid(row=0, column=0, padx=50, pady=(500, 0), sticky="nw")
        else:
            print("[WARN] Click did not correspond to a known radar site.")
            # Display a message to the user (Using the GLOBAL variable now)
            message_label = tk.Label(frame1, text="Click closer to a radar site marker.", font=("Arial", 14), fg="red", bg=tk_background_color)
            message_label.grid(row=0, column=0, padx=50, pady=210, sticky='nw')

    # Create label for the map image
    map_label = tk.Label(frame1, width=target_width, height=target_height)

    # Display the RESIZED map image
    try:
        photo = ImageTk.PhotoImage(resized_map_image)
        map_label.configure(image=photo)
        map_label.image = photo # Keep reference! Important!
    except Exception as e:
        print(f"[ERROR] Error creating Tkinter image: {e}")
        tk.Label(frame1, text="Error displaying map image.", font=("Arial", 14)).grid(row=0, column=0, padx=50, pady=100, sticky='nw')
        return # Can't proceed without the map visual

    # Place the map label on the grid
    map_label.grid(row=0, column=0, sticky="nsew", padx=200, pady=70) # Adjust padding as needed

    # Draw links/markers (if implemented in the helper)
    lcl_radar_draw_links()

    # Bind the click handler to the map label
    map_label.bind("<Button-1>", lcl_radar_on_click)

    # --- Add Static Labels and Buttons ---
     
    # 1. Title Label
    title_label = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color)
    title_label.grid(row=0, column=0, padx=50, pady=10, sticky='nw')

    # 2. Instructions Label
    instructions_text = "Please\nchoose a\nradar site"
    instructions_label = tk.Label(frame1, text=instructions_text, font=("Arial", 16), justify='left', bg=tk_background_color)
    instructions_label.grid(row=0, column=0, padx=50, pady=70, sticky='nw')

    # 3. Scraped Image (National Radar Map)
    # Target URL for the CONUS radar map
    radar_url = 'https://radar.weather.gov/ridge/standard/CONUS_0.gif'
     
    # Use variable prefix 'ntnl_radar_thumbnail' for unique names
    try:
        # Fetch the radar image data
        ntnl_radar_thumbnail_response = requests.get(radar_url, timeout=10)
        
        if ntnl_radar_thumbnail_response.status_code == 200:
            # Load image data into Pillow
            ntnl_radar_thumbnail_image_data = ntnl_radar_thumbnail_response.content
            ntnl_radar_thumbnail_pil_image = Image.open(io.BytesIO(ntnl_radar_thumbnail_image_data))
            
            # --- FIX FOR PIXELIZATION (Anti-Aliasing) ---
            # Convert the indexed-color GIF to full RGB mode before resizing.
            # This allows the LANCZOS filter to create smooth, intermediate colors.
            ntnl_radar_thumbnail_pil_image = ntnl_radar_thumbnail_pil_image.convert('RGB')
            
            # --- Resize Logic ---
            target_width = 180
            # Calculate aspect ratio
            ntnl_radar_thumbnail_w_percent = (target_width / float(ntnl_radar_thumbnail_pil_image.size[0]))
            ntnl_radar_thumbnail_h_size = int((float(ntnl_radar_thumbnail_pil_image.size[1]) * float(ntnl_radar_thumbnail_w_percent)))
            
            # Resize the image using the high-quality LANCZOS filter
            ntnl_radar_thumbnail_pil_image = ntnl_radar_thumbnail_pil_image.resize(
                (target_width, ntnl_radar_thumbnail_h_size), 
                Image.Resampling.LANCZOS
            )
            
            # Convert to Tkinter PhotoImage
            ntnl_radar_thumbnail_tk_image = ImageTk.PhotoImage(ntnl_radar_thumbnail_pil_image)
            
            # Create the label to hold the image
            ntnl_radar_thumbnail_map_label = tk.Label(frame1, image=ntnl_radar_thumbnail_tk_image, bg=tk_background_color)
            
            # CRITICAL: Keep a reference to the image on the widget to prevent Tkinter garbage collection!
            ntnl_radar_thumbnail_map_label.image = ntnl_radar_thumbnail_tk_image 
            
            # Place the map at the requested coordinates (Updated to your final values)
            # padx=(10, 0), pady=(250,0)
            ntnl_radar_thumbnail_map_label.grid(row=0, column=0, padx=(10, 0), pady=(370,0), sticky='nw')

            # --- Resource Cleanup for Long-Running Process ---
            # Set intermediate variables to None/delete to explicitly free up memory.
            # This prevents resource/memory leaks in the long-running application.
            del ntnl_radar_thumbnail_response
            del ntnl_radar_thumbnail_image_data
            ntnl_radar_thumbnail_pil_image.close() # Close PIL object explicitly
            del ntnl_radar_thumbnail_pil_image
            del ntnl_radar_thumbnail_w_percent
            del ntnl_radar_thumbnail_h_size
            
        else:
            print(f"[ERROR] Failed to fetch radar image. Status code: {ntnl_radar_thumbnail_response.status_code}")
            error_text = f"[Radar Failed: {ntnl_radar_thumbnail_response.status_code}]"
            error_label = tk.Label(frame1, text=error_text, bg=tk_background_color, fg="red")
            error_label.grid(row=0, column=0, padx=(50, 0), pady=300, sticky='nw')
            del ntnl_radar_thumbnail_response # Clean up failed response

    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Network/Timeout error fetching radar image: {e}")
        error_label = tk.Label(frame1, text="[Radar Failed: Network Error]", bg=tk_background_color, fg="red")
        error_label.grid(row=0, column=0, padx=(50, 0), pady=300, sticky='nw')

    # 4. Back Button (ensure page_choose function is accessible)
    back_button = tk.Button(frame1, text=" Back ", font=("Helvetica", 16, "bold"), command=page_choose)
    back_button.grid(row=0, column=0, padx=(50, 0), pady=(550,0), sticky="nw")

# --- End of choose_lcl_radar function ---

# begin block for radiosonde choice
def get_most_recent_gmt():
    global sonde_report_from_time, most_recent_sonde_time, sonde_letter_identifier, box_variables

    def check_url_exists(url):
        try:
            response = requests.head(url)
            return response.status_code == 200
        except requests.RequestException:
            return False

    def format_time(gmtime_struct, hour):
        return time.strftime(f"%y%m%d{hour:02d}_OBS", gmtime_struct)

    current_time = time.gmtime()
    hour = current_time.tm_hour

    # Determine if we should start with 12Z or 00Z
    if hour >= 12:
        most_recent_hour = 12
    else:
        most_recent_hour = 0

    # Initialize the starting time
    adjusted_time = time.mktime((
        current_time.tm_year, current_time.tm_mon, current_time.tm_mday,
        most_recent_hour, 0, 0, current_time.tm_wday,
        current_time.tm_yday, current_time.tm_isdst
    ))

    while True:
        gmt_struct = time.gmtime(adjusted_time)
        most_recent_sonde_time = format_time(gmt_struct, most_recent_hour)
        url = f"https://www.spc.noaa.gov/exper/soundings/{most_recent_sonde_time}/"
        #print(f"Testing URL: {url}")  # Debug print
        if check_url_exists(url):
            break
        
        # Adjust time to the previous 12-hour period
        adjusted_time -= 12 * 3600
        if most_recent_hour == 12:
            most_recent_hour = 0
        else:
            most_recent_hour = 12

    match = re.search(r'(\d{2})_OBS$', most_recent_sonde_time)
    if match:
        sonde_report_from_time = match.group(1)
    else:
        print("Could not pull 2 digits out of most_recent_sonde_time.")
        
    return most_recent_sonde_time

def draw_radiosonde_links(active_links, scale_factor):
    global sonde_letter_identifier, box_variables
    for link in active_links:
        coords = link['coords'].split(',')
        if len(coords) == 3:
            x, y, radius = map(int, coords)
            x_scaled, y_scaled = int(x * scale_factor), int(y * scale_factor)
            radius = int(radius * 2)
            #label.create_oval(x_scaled - radius, y_scaled - radius, x_scaled + radius, y_scaled + radius, outline="red")

def handle_click(event, active_links, scale_factor, confirm_label, submit_button):
    global sonde_letter_identifier, match, confirm_text
    for link in active_links:
        coords = link['coords'].split(',')
        if len(coords) == 3:
            x, y, radius = map(int, coords)
            x_scaled, y_scaled = int(x * scale_factor), int(y * scale_factor)
            radius = int(radius * 2)
            distance = ((event.x - x_scaled) ** 2 + (event.y - y_scaled) ** 2) ** 0.5
            if distance <= radius:
                match = re.search(r'"([A-Z]{3})"', link['href'])
                if match:
                    sonde_letter_identifier = match.group(1)
                    confirm_text = f"You chose radiosonde site:\n{sonde_letter_identifier}"
                    confirm_label.config(text=confirm_text)
                    submit_button.config(state=tk.NORMAL)  # Enable submit button
                else:
                    print("No match found")

def choose_radiosonde_site():
        
    global box_variables, sonde_letter_identifier, most_recent_sonde_time, refresh_flag, has_submitted_choice
    
    sonde_letter_identifier = ""
    
    if box_variables[8] == 1:        
        
        for widget in frame1.winfo_children():
            widget.destroy()
        
        # Reset clean position for frame1
        frame1.grid(row=0, column=0, sticky="nsew")
        #inserted 3/28/24
        # Before displaying the map, temporarily adjust the configuration
        frame1.master.grid_rowconfigure(0, weight=0)  # Reset to default which doesn't expand the row
        frame1.master.grid_columnconfigure(0, weight=0)  # Reset to default which doesn't expand the column 
        
        frame1.grid_propagate(True)
        
        if not CHROME_DRIVER_PATH:
            print("ERROR: ChromeDriver path is not set. Cannot start browser.")
            # Handle the error appropriately, maybe return or raise an exception
            return 

        # Define your options for this specific function
        options = Options()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        # Add any other specific options you need for this function...

        # Point to the driver path determined at startup
        service = Service(CHROME_DRIVER_PATH)

        # Initialize the driver with both objects
        driver = webdriver.Chrome(service=service, options=options)
        
        # trying to change this line as an experiment 4/3/24 - problem 00z-1z
        url = "https://www.spc.noaa.gov/exper/soundings/{}/".format(get_most_recent_gmt())        
        #url = "https://www.spc.noaa.gov/exper/soundings/{}/".format(most_recent_sonde_time()) 
        
        driver.get(url)

        try:
            # Wait up to 5 seconds for the image to be present
            map_element = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.XPATH, "/html/body/table/tbody/tr/td[1]/center/img"))
            )
            valid_page_found = True
        except Exception as e:
            print(f"Line 5031. Error: {e}")
            print("Image not found — possibly still loading or missing. Aborting radiosonde display.")
            driver.quit()
            # Gracefully skip this step, disable radiosonde, and call the fallback directly
            box_variables[8] = 0
            station_center_input()
            return
            

        map_image_url = map_element.get_attribute("src")
        map_response = requests.get(map_image_url, stream=True)
        
        # this try except block is for when the radiosonde map is unavailable        
        try:
            original_map_image = Image.open(BytesIO(map_response.content))
        except UnidentifiedImageError:
            # clean out the old widgets
            for widget in frame1.winfo_children():
                widget.destroy()
            # disable the radiosonde step and move on
            box_variables[8] = 0

            text_label = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), fg="black", bg=tk_background_color, anchor="w", justify="left")
            text_label.grid(row=0, column=0, padx=50, pady=10, sticky='w')

            # show the “not available” message
            error_label = tk.Label(
                frame1,
                text="The map that displays the choices of radiosonde sites is not available.\nPlease try back later.",
                font=("Helvetica", 16),
                bg=tk_background_color,
                justify="left"
            )
            error_label.grid(row=1, column=0, padx=50, pady=50, sticky="nw")

            # add a Next button to continue
            next_button = tk.Button(
                frame1,
                text="Next",
                font=("Helvetica", 16, "bold"),
                command=station_center_input
            )
            next_button.grid(row=2, column=0, padx=50, pady=20, sticky="nw")

            return

        soup = BeautifulSoup(driver.page_source, 'html.parser')
        active_links = soup.find('map', {'name': 'stations'}).find_all('area')

        target_width, target_height = 600, 450
        scale_factor = target_width / original_map_image.width
        enlarged_map_image = original_map_image.resize((target_width, target_height), Image.LANCZOS)

        label = tk.Label(frame1)
        label.grid(row=0, column=1, padx=0, pady=85)

        enlarged_map_photo = ImageTk.PhotoImage(enlarged_map_image)
        label.configure(image=enlarged_map_photo)
        label.image = enlarged_map_photo

        draw_radiosonde_links(active_links, scale_factor)

        overlay_label = tk.Label(frame1, text="Sounding Stations", font=("Arial", 18, "bold"), bg="white", fg="black")
        overlay_label.grid(row=0, column=1, pady=(400,0))

        match = re.search(r'<span class="style5">Observed Radiosonde Data<br>\s*([^<]+)\s*</span>', driver.page_source)
        if match:
            date_str = match.group(1)
            overlay_label["text"] += f" {date_str}"
        
        #frame1.grid(row=0, column=0, sticky="nw") 
        
        label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), justify="left", bg=tk_background_color)
        label1.grid(row=0, column=0, padx=50, pady=10, sticky="nw") 

        instruction_text = f"These are the\nradiosonde sites that are\navailable as of {sonde_report_from_time} GMT."
        instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16,), justify='left', bg=tk_background_color)
        instructions_label.grid(row=0, column=0, padx=50, pady=(60, 10), sticky='nw')

        instruction_text = "Click on the location\nof a station,\nthen click submit."
        instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16,), justify='left', bg=tk_background_color)
        instructions_label.grid(row=0, column=0, padx=50, pady=(150, 10), sticky='nw')

        confirm_text = f"You chose radiosonde site:\n{sonde_letter_identifier}"
        confirm_label = tk.Label(frame1, text=confirm_text, font=("Arial", 16), justify='left', bg=tk_background_color)
        confirm_label.grid(row=0, column=0, padx=50, pady=250, sticky='nw')

        if box_variables[5] == 1:
            #refresh_flag = True # this allows back button on choose_radiosonde_site to go back to choose_reg_sat, but prevents program from displaying
            # need to toggle refresh_flag back to False at some point
            has_submitted_choice = False
            back_function = choose_reg_sat
            
        elif box_variables[3] == 1:
            back_function = lightning_center_input
            
        elif box_variables[2] == 1:
            back_function = choose_lcl_radar
            
        else:
            back_function = page_choose

        # Create the 'Back' button
        back_button = tk.Button(frame1, text=" Back ", font=("Helvetica", 16, "bold"), command=back_function)
        back_button.grid(row=0, column=0, padx=(50, 0), pady=(400,0), sticky="nw")

        submit_button = tk.Button(frame1, text="Submit", command=station_center_input, font=("Helvetica", 16, "bold"), state=tk.DISABLED)
        submit_button.grid(row=0, column=0, padx=50, pady=(350,0), sticky="nw")            

        label.bind("<Button-1>", lambda event: handle_click(event, active_links, scale_factor, confirm_label, submit_button))
        
    else:
        station_center_input()
    
def choose_reg_sat():
    global reg_sat_choice_variables, box_variables, reg_sat, has_submitted_choice, refresh_flag
    
    reg_sat_choice_variable = tk.IntVar(value=-1)  # Single IntVar for all radio buttons
    reg_sat_choice_variables = [0] * 16  # Update to 16 instead of 12
    
    if refresh_flag == True:
        has_submitted_choice = False
        
    if box_variables[5] != 1:
        choose_radiosonde_site()

    elif not has_submitted_choice:
        frame1.grid(row=0, column=0, sticky="nsew")

        for widget in frame1.winfo_children():
            widget.destroy()

        # Set the layout back to the original background colors
        frame1.config(width=1024, height=600, bg="lightblue")  # Reverted background color

        reg_sat_label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")  
        reg_sat_label1.grid(row=0, column=0, columnspan=4, padx=(50, 0), pady=(50, 10), sticky="w")

        instruction_text = "Please select your regional satellite view:"
        instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 14, "bold"), bg=tk_background_color)
        instructions_label.grid(row=1, column=0, columnspan=4, padx=(50, 0), pady=(0, 25), sticky='w')

        # Combine the original and new choices
        choices = ['Pacific NW', 'Pacific SW', 'Northern Rockies', 'Southern Rockies', 'Upper Miss. Valley',
                   'Southern Miss. Valley', 'Great Lakes', 'Southern Plains', 'Northeast', 'Southeast',
                   'US Pacific Coast', 'US Atlantic Coast', 'Gulf of Mexico', 'Caribbean', 'Tropical Atlantic', 'Canada/Northern U.S.']

        # Create frames for the 4 columns, with original color scheme
        column1_frame = tk.Frame(frame1, bg=tk_background_color)  
        column2_frame = tk.Frame(frame1, bg=tk_background_color)
        column3_frame = tk.Frame(frame1, bg=tk_background_color)
        column4_frame = tk.Frame(frame1, bg=tk_background_color)

        # Position the frames
        column1_frame.grid(row=2, column=0, padx=(30, 12), sticky='w')
        column2_frame.grid(row=2, column=1, padx=(12, 12), sticky='w')
        column3_frame.grid(row=2, column=2, padx=(12, 12), sticky='w')
        column4_frame.grid(row=2, column=3, padx=(12, 50), pady=(20, 20), sticky='w')

        # Force Tkinter to update the layout
        frame1.update_idletasks()

        def update_sat_radio_buttons():
            submit_button['state'] = tk.NORMAL if reg_sat_choice_variable.get() != -1 else tk.DISABLED

        # Add radio buttons for all choices
        for index, choice in enumerate(choices):
            frame = [column1_frame, column2_frame, column3_frame, column4_frame][index // 4]
            choice_radio_button = tk.Radiobutton(
                frame,
                text=choice, variable=reg_sat_choice_variable, value=index,
                font=("Arial", 14, "bold"),
                bg="lightblue",  # Keep the original background
                command=update_sat_radio_buttons,
                highlightthickness=0,
                borderwidth=0
            )
            choice_radio_button.grid(row=index % 4, column=0, padx=10, pady=(5, 55), sticky='w')


        def submit_sat_choice():
            global reg_sat_choice_variables, has_submitted_choice
            selected_index = reg_sat_choice_variable.get()
            if selected_index != -1:
                reg_sat_choice_variables = [1 if i == selected_index else 0 for i in range(16)]
                has_submitted_choice = True
                # Clear the current display
                for widget in frame1.winfo_children():
                    widget.destroy()
                frame1.grid(row=0, column=0, sticky="nsew")
                frame1.config(width=1024, height=600)
                column1_frame.destroy()
                column2_frame.destroy()
                column3_frame.destroy()
                if box_variables[8] == 1:                
                    choose_radiosonde_site()                        
                else:
                    station_center_input()

        if box_variables[3] == 1:
            back_function = lightning_center_input
            
        elif box_variables[2] == 1:
            back_function = choose_lcl_radar
            
        else:
            back_function = page_choose

        submit_button = tk.Button(frame1, text="Submit", command=submit_sat_choice, font=("Arial", 16, "bold"), state=tk.DISABLED)
        submit_button.grid(row=3, column=3, padx=0, pady=0, sticky='s')

def submit_choices():
    global box_variables, hold_box_variables
    box_variables = [var.get() for var in page_choose_choice_vars]
    hold_box_variables = []

    # Set each hold_box_variable individually
    for value in box_variables:
        hold_box_variables.append(value)

    # Apply conditional changes to box_variables
    for index, value in enumerate(box_variables):
        if value == 1:
            box_variables[index] = 2 if index in {11} else 1

#     # Loop through each value in hold_box_variables and print it inside submit_choices
#     for index, value in enumerate(hold_box_variables):
#         print(f"submit_choices: hold_box_variables[{index}] = {value}")

    # Clear the current display and choose the next action based on choices
    for widget in frame1.winfo_children():
        widget.destroy()

    if box_variables[2] == 1:
        choose_lcl_radar()  
    else:
        lightning_center_input()  

def page_choose():
    global page_choose_choice_vars, hold_box_variables, xs  # Declare these global to modify
    global random_sites_flag, lcl_radar_map_unavailable
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()
    
    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 22, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, columnspan=3, padx=50, pady=(50,10), sticky="w")
    
    instructions_label = tk.Label(frame1, text="Please select your display choices:", font=("Helvetica", 20), bg=tk_background_color)
    instructions_label.grid(row=1, column=0, columnspan=3, padx=50, pady=(0, 15), sticky='w')
    
    # Initialize the global variable for this page's choice variables
    page_choose_choice_vars = []

    choices = ['Barograph', 'National Radar', 'Local Radar', 'Lightning', 'Large Single Image Satellite',
               'Regional Satellite Loop', 'National Surface Analysis', 'Local Station Plots', 'Radiosonde', '500mb Vorticity',
               'Storm Reports', 'Next Idea']

    # Create a custom style for the check buttons with the learned attributes
    custom_style = ttk.Style()
    custom_style.configure("Custom.TCheckbutton", font=("Arial", 14, "bold"))  # Set the font properties
    custom_style.map("Custom.TCheckbutton",
                     background=[("disabled", "lightblue"), ("!disabled", "lightblue")],
                     foreground=[("disabled", "gray"), ("!disabled", "black")])
    
    column_frames = [tk.Frame(frame1, bg=tk_background_color) for _ in range(3)]
    for i, col_frame in enumerate(column_frames):
        col_frame.grid(row=2, column=i, padx=(50, 20), pady=10, sticky='nw')
        frame1.grid_columnconfigure(i, weight=1)
        
    for index, choice in enumerate(choices):
        var = tk.IntVar()
        page_choose_choice_vars.append(var)
        col_index = index // 4
        check_button = ttk.Checkbutton(column_frames[col_index], text=choice, variable=var, style="Custom.TCheckbutton")
        check_button.grid(row=index % 4, column=0, padx=10, pady=30, sticky='w')

        # Set the checkbox based on hold_box_variables if available, handle special cases
        if index == 0:
            var.set(1)
            check_button.state(["disabled"])

        elif index > 10: # changed on 10/28/24 to include map of storm reports
            var.set(0)
            check_button.state(["disabled"])
        else:
            if hold_box_variables and index < len(hold_box_variables):
                var.set(hold_box_variables[index])

    if random_sites_flag:
        next_function = confirm_random_sites
    else:
        next_function = recheck_cobs_stations
    
    if len(xs) == 0: # only show this back button for set up, not during operation       
        back_button = tk.Button(frame1, text=" Back ", font=("Arial", 16, "bold"), command=next_function)
        back_button.grid(row=4, column=2, padx=(30,0), pady=(15, 10), sticky="s")

    submit_button = tk.Button(frame1, text="Submit", command=submit_choices, font=("Arial", 16, "bold"), bg="light gray", foreground="black")
    submit_button.grid(row=4, column=3, padx=0, pady=(15, 10), sticky='s')

def submit_lg_sat_choice():
    global lg_still_sat, lg_still_view
    
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()
    
    # Check which radio button is selected and assign the appropriate values
    choice = lg_still_sat_choice_vars.get()
    if choice == 0:
        lg_still_sat = "19"
        lg_still_view = "CONUS"
    elif choice == 1:
        lg_still_sat = "18"
        lg_still_view = "CONUS"
    elif choice == 2:
        lg_still_sat = "19"
        lg_still_view = "FD"
    elif choice == 3:
        lg_still_sat = "18"
        lg_still_view = "FD"

    choose_reg_sat()

def check_lg_still_sat_status(*args):
    # Enable submit button if a radio button is selected
    if lg_still_sat_choice_vars.get() != -1:  # -1 means no selection
        submit_button.config(state="normal")
    else:
        submit_button.config(state="disabled")

def choose_lg_still_sat():
    global lg_still_sat_choice_vars, submit_button
    
    if box_variables[4] == 1:
        # Clear the current display
        for widget in frame1.winfo_children():
            widget.destroy()

        frame1.grid(row=0, column=0, sticky="nsew")
        
        # Create and display the updated labels
        label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
        label1.grid(row=0, column=0, columnspan=20, padx=50, pady=(50,0), sticky="nw")

        instruction_text = "Please choose the view for the large still satellite image:"
        instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
        instructions_label.grid(row=1, column=0, columnspan=20, padx=50, pady=5, sticky='nw')

        # Initialize the IntVar for the radio buttons
        lg_still_sat_choice_vars = tk.IntVar(value=-1)  # -1 means no selection

        # Define a custom style for radio buttons
        style = ttk.Style()
        style.configure("Custom.TRadiobutton", font=("Helvetica", 16, "bold"), background=tk_background_color)

        # Define radio button labels
        radio_labels = ['Eastern US', 'Western US', 'Globe East', 'Globe West']
        
        # Create and arrange radio buttons, all linked to the same IntVar
        for i, label in enumerate(radio_labels):
            radio_button = ttk.Radiobutton(
                frame1, text=label, variable=lg_still_sat_choice_vars, 
                value=i, style="Custom.TRadiobutton"
            )
            radio_button.grid(row=2 + (i // 2), column=i % 2, padx=50, pady=10, sticky='w')

        # Add a trace to monitor the state of the radio buttons
        lg_still_sat_choice_vars.trace_add('write', check_lg_still_sat_status)

        # Create submit button, initially disabled
        submit_button = tk.Button(
            frame1, text="Submit", command=submit_lg_sat_choice, font=("Arial", 16, "bold"), 
            bg="light gray", foreground="black", state="disabled"
        )
        submit_button.grid(row=5, column=0, columnspan=20, padx=200, pady=50, sticky='nw')
        
        if box_variables[3] == 1:
            back_function = lightning_center_input
        elif box_variables[2] == 1:
            back_function = choose_lcl_radar
        else:
            back_function = page_choose

        # Create the 'Back' button
        back_button = tk.Button(frame1, text=" Back ", font=("Helvetica", 16, "bold"), command=back_function)
        back_button.grid(row=5, column=0, columnspan=20, padx=(50, 0), pady=50, sticky="nw")
    
    else:
        choose_reg_sat()

def submit_lightning_near_me():
    global aobs_site, lightning_near_me_flag
    
    lightning_near_me_flag = True
    
    submit_lightning_center()

def submit_lightning_center():
    global submit_lightning_town, submit_lightning_state, lightning_town, lightning_state, lightning_lat, lightning_lon, aobs_site 
    global lightning_near_me_flag
    # Get the user's input
    submit_lightning_town = lightning_town.get()
    submit_lightning_state = lightning_state.get()

    for widget in frame1.winfo_children():
        widget.destroy()

    lightning_geolocator = Nominatim(user_agent="lightning_map")
    
    if lightning_near_me_flag == False:        
        # Combine town and state into a search query
        lightning_query = f"{submit_lightning_town}, {submit_lightning_state}"
    
    if lightning_near_me_flag == True:
        lightning_query = aobs_site
        lightning_near_me_flag = False
        
    try:
        # Use geocoder to get coordinates of lightning map center
        lightning_location = lightning_geolocator.geocode(lightning_query)

        if lightning_location:
            lightning_lat = lightning_location.latitude
            lightning_lon = lightning_location.longitude
            choose_lg_still_sat()
        else:
            raise ValueError("Location not found")
    
    except (GeocoderUnavailable, ValueError) as e:

        for widget in frame1.winfo_children():
            widget.destroy()

        instruction_text = "Location not found or service unavailable. \n\Please enter a different town and state or choose not to display the lightning image."
        instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16,), bg=tk_background_color)
        instructions_label.grid(row=1, column=0, padx=50, pady=(20, 10))

        # Create the 'Next' button to retry or skip
        next_button = create_button(frame1, "Try Again", button_font, page_choose)
        next_button.grid(row=3, column=0, padx=(50, 0), pady=10, sticky="w")
        
        skip_button = create_button(frame1, "Skip Lightning", button_font, choose_lg_still_sat)  # or another appropriate function
        skip_button.grid(row=3, column=0, padx=(190, 0), pady=10, sticky="w")
  
def lightning_center_input():
    global box_variables, lightning_town, lightning_state, shift_active, current_target_entry

    if box_variables[3] == 1:
        # Reset current_target_entry
        current_target_entry = None

        # Clear the current display
        for widget in frame1.winfo_children():
            widget.destroy()

        frame1.grid(row=0, column=0, sticky="nsew")

        # Create and display the updated labels
        label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
        label1.grid(row=0, column=0, columnspan=20, padx=50, pady=(50, 0), sticky="nw")

        instruction_text = "Please enter the name of the town for the center of the lightning map,\nor just click Near Me to generate a map near your location:"
        instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
        instructions_label.grid(row=1, column=0, columnspan=20, padx=50, pady=5, sticky="nw")

        lightning_town = tk.Entry(frame1, font=("Helvetica", 14))
        lightning_town.grid(row=2, column=0, columnspan=20, padx=50, pady=5, sticky="nw")
        lightning_town.focus_set()  # Set focus to the first entry widget

        state_instruction_text = "Please enter the 2-letter state ID for the center of the lightning map:"
        state_instructions_label = tk.Label(frame1, text=state_instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
        state_instructions_label.grid(row=3, column=0, columnspan=20, padx=50, pady=5, sticky="nw")

        # Create the lightning_state Entry first!
        lightning_state = tk.Entry(frame1, font=("Helvetica", 14))
        lightning_state.grid(row=4, column=0, columnspan=20, padx=50, pady=5, sticky="nw")

        # Add state entry to dictionary AFTER creating lightning_state
        state_entry_widgets["lightning_state"] = lightning_state

        lightning_town.bind("<FocusIn>", lambda e: set_current_target(lightning_town))
        lightning_state.bind("<FocusIn>", lambda e: set_current_target(lightning_state))

        #force uppercase for state input.
        lightning_state.bind("<FocusIn>", lambda e: [set_current_target(lightning_state), set_state_uppercase()])

        auto_capitalize()  # call auto capitalize after focus bind.

        if box_variables[2] == 1:
            back_function = choose_lcl_radar
        else:
            back_function = page_choose

        # Create the 'Back' button
        back_button = tk.Button(frame1, text=" Back ", font=("Helvetica", 16, "bold"), command=back_function)
        back_button.grid(row=5, column=0, columnspan=20, padx=(50, 0), pady=5, sticky="nw")

        submit_button = tk.Button(frame1, text="Submit", command=submit_lightning_center, font=("Helvetica", 16, "bold"))
        submit_button.grid(row=5, column=0, columnspan=20, padx=200, pady=5, sticky="nw")

        near_me_button = tk.Button(frame1, text="Near Me", font=("Helvetica", 16, "bold"), command=submit_lightning_near_me)
        near_me_button.grid(row=5, column=0, columnspan=20, padx=350, pady=5, sticky="nw")

        # Spacer to ensure layout consistency
        spacer = tk.Label(frame1, text="", bg=tk_background_color)
        spacer.grid(row=6, column=0, columnspan=20, sticky="nsew", pady=(0, 40))  # Adjust this to fit the layout

        # Display the virtual keyboard, assuming row 7 is correctly positioned below the submit button and spacer
        shift_active = True  # force uppercase
        create_virtual_keyboard(frame1, 7)
        update_keyboard_shift_state()  # update the keyboard.
        
        # release any stale grabs and assert focus after layout
        try: root.grab_release()
        except: pass
        frame1.update_idletasks()
        root.after_idle(lambda: lightning_town.focus_force())
        root.after_idle(lambda: set_current_target(lightning_town))

    else:
        choose_lg_still_sat()

def station_center_input():
    global box_variables, refresh_flag, station_plot_town, station_plot_state, zoom_plot, random_sites_flag, submit_station_plot_center_near_me_flag, aobs_site, current_target_entry, shift_active

    random_sites_flag = False
    zoom_plot = None

    if box_variables[7] == 1:

        # Reset current_target_entry
        current_target_entry = None

        # Clear the current display
        for widget in frame1.winfo_children():
            widget.destroy()
        
        # special page setup to handle case when previous GUI doesn't have radiosonde map available
        frame1.master.grid_rowconfigure(0, weight=1)
        frame1.master.grid_columnconfigure(0, weight=1)
        frame1.grid(row=0, column=0, sticky="nsew")

        zoom_plot = tk.StringVar(value="9")

        def submit_station_plot_center_near_me():
            global submit_station_plot_center_near_me_flag
            submit_station_plot_center_near_me_flag = True
            submit_station_plot_center()

        def submit_station_plot_center():
            global submit_station_plot_town, submit_station_plot_state, station_plot_lat, station_plot_lon, zoom_plot
            global refresh_flag, current_frame_index, submit_station_plot_center_near_me_flag, aobs_site

            try:
                station_plot_geolocator = Nominatim(user_agent="station_plot_map")
                zoom_plot = zoom_plot.get()

                if submit_station_plot_center_near_me_flag == False:
                    submit_station_plot_town = station_plot_town.get()
                    submit_station_plot_state = station_plot_state.get()
                    station_plot_query = f"{submit_station_plot_town}, {submit_station_plot_state}"

                elif submit_station_plot_center_near_me_flag == True:
                    station_plot_query = aobs_site
                    submit_station_plot_center_near_me_flag = False

                station_plot_location = station_plot_geolocator.geocode(station_plot_query)

                if station_plot_location:
                    station_plot_lat = station_plot_location.latitude
                    station_plot_lon = station_plot_location.longitude

                    if len(xs) == 0:
                        frame1.grid_forget()
                        root.bind("<ButtonPress-1>", on_touch_start)
                        root.bind("<B1-Motion>", handle_swipe)
                        root.bind("<Left>", lambda event: on_left_swipe(event))
                        root.bind("<Right>", lambda event: on_right_swipe(event))
                        current_frame_index = 0
                        timer_override = False
                        start_animation()
                    else:
                        refresh_flag = False
                        #print("line 5920. A call back to image cycle.")
                        return_to_image_cycle()

                else:
                            
                    for widget in frame1.winfo_children():
                            widget.destroy()

                    instruction_text = "Not able to use that location as center."
                    instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color)
                    instructions_label.grid(row=1, column=0, padx=50, pady=(20, 10))

                    next_button = create_button(frame1, "Next", button_font, station_center_input)
                    next_button.grid(row=3, column=0, padx=(90, 0), pady=10, sticky="w")

                    station_center_input()

            except Exception as e:

                for widget in frame1.winfo_children():
                    widget.destroy()

                label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
                label1.grid(row=0, column=0, padx=50, pady=5, sticky="w")

                instruction_text = "Not able to use that location as center."
                instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color)
                instructions_label.grid(row=1, column=0, padx=50, pady=(20, 10))

                next_button = create_button(frame1, "Next", button_font, station_center_input)
                next_button.grid(row=3, column=0, padx=(90, 0), pady=10, sticky="w")

        label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
        label1.grid(row=0, column=0, columnspan=20, padx=50, pady=(50, 0), sticky="nw")

        instructions_label = tk.Label(
            frame1,
            text="Please enter the name of the town for the center of the station plot map,\nor just click Near Me to generate a map near your location:",
            font=("Helvetica", 16),
            bg=tk_background_color,
            justify="left"
        )
        instructions_label.grid(row=1, column=0, columnspan=20, padx=50, pady=(5, 0), sticky='nw')

        station_plot_town = tk.Entry(frame1, font=("Helvetica", 14))
        station_plot_town.grid(row=2, column=0, columnspan=20, padx=50, pady=5, sticky='nw')
        station_plot_town.focus_set()

        state_instructions_label = tk.Label(frame1, text="Please enter the 2-letter state ID for the center of the station plot map:", font=("Helvetica", 16), bg=tk_background_color)
        state_instructions_label.grid(row=3, column=0, columnspan=20, padx=50, pady=(5, 5), sticky='nw')

        # Create the station_plot_state Entry first!
        station_plot_state = tk.Entry(frame1, font=("Helvetica", 14))
        station_plot_state.grid(row=4, column=0, columnspan=20, padx=50, pady=(5, 10), sticky='nw')

        # Add state entry to dictionary AFTER creating station_plot_state
        state_entry_widgets["station_plot_state"] = station_plot_state

        station_plot_town.bind("<FocusIn>", lambda e: set_current_target(station_plot_town))
        station_plot_state.bind("<FocusIn>", lambda e: set_current_target(station_plot_state))

        #force uppercase for state input.
        station_plot_state.bind("<FocusIn>", lambda e: [set_current_target(station_plot_state), set_state_uppercase()])

        # Reset current_target_entry AFTER widget creation.
        current_target_entry = None

        auto_capitalize()  # call auto capitalize after focus bind.

        radio_buttons_info = [
            ("Few small\ncounties", "10"),
            ("Several\ncounties", "9"),
            ("States", "6"),
            ("Continents", "4"),
            ("Almost a\nhemisphere", "3")
        ]

        radio_button1 = tk.Radiobutton(frame1, text=radio_buttons_info[0][0], variable=zoom_plot, value=radio_buttons_info[0][1],
            font=("Helvetica", 11), bg=tk_background_color, bd=0, highlightthickness=0, justify="left")
        radio_button1.grid(row=6, column=0, columnspan=1, sticky="w", padx=(50, 0))

        radio_button2 = tk.Radiobutton(frame1, text=radio_buttons_info[1][0], variable=zoom_plot, value=radio_buttons_info[1][1],
                                        font=("Helvetica", 11), bg=tk_background_color, bd=0, highlightthickness=0, justify="left")
        radio_button2.grid(row=6, column=0, columnspan=1, sticky="w", padx=(200, 0))

        radio_button3 = tk.Radiobutton(frame1, text=radio_buttons_info[2][0], variable=zoom_plot, value=radio_buttons_info[2][1],
                                        font=("Helvetica", 11), bg=tk_background_color, bd=0, highlightthickness=0, justify="left")
        radio_button3.grid(row=6, column=0, columnspan=1, sticky="w", padx=(350, 0))

        radio_button4 = tk.Radiobutton(frame1, text=radio_buttons_info[3][0], variable=zoom_plot, value=radio_buttons_info[3][1],
                                        font=("Helvetica", 11), bg=tk_background_color, bd=0, highlightthickness=0, justify="left")
        radio_button4.grid(row=6, column=0, columnspan=1, sticky="w", padx=(470, 0))

        radio_button5 = tk.Radiobutton(frame1, text=radio_buttons_info[4][0], variable=zoom_plot, value=radio_buttons_info[4][1],
                                        font=("Helvetica", 11), bg=tk_background_color, bd=0, highlightthickness=0, justify="left")
        radio_button5.grid(row=6, column=0, columnspan=1, sticky="w", padx=(600, 0))

        if box_variables[8] == 1:
            back_function = choose_radiosonde_site

        elif box_variables[5] == 1:
            back_function = choose_reg_sat

        elif box_variables[3] == 1:
            back_function = lightning_center_input

        elif box_variables[2] == 1:
            back_function = choose_lcl_radar

        else:
            back_function = page_choose

        back_button = tk.Button(frame1, text=" Back ", font=("Helvetica", 16, "bold"), command=back_function)
        back_button.grid(row=7, column=0, columnspan=20, padx=(50, 0), pady=15, sticky="nw")

        submit_button = tk.Button(frame1, text="Submit", command=submit_station_plot_center, font=("Helvetica", 16, "bold"))
        submit_button.grid(row=7, column=0, columnspan=20, padx=200, pady=15, sticky='nw')

        near_me_button = tk.Button(frame1, text="Near Me", font=("Helvetica", 16, "bold"), command=submit_station_plot_center_near_me)
        near_me_button.grid(row=7, column=0, columnspan=20, padx=350, pady=15, sticky='nw')

        create_virtual_keyboard(frame1, 8)
        
        try: root.grab_release()
        except: pass
        frame1.update_idletasks()
        root.after_idle(lambda: station_plot_town.focus_force())
        root.after_idle(lambda: set_current_target(station_plot_town))

    else:
        if len(xs) == 0:
            frame1.grid_forget()

            root.bind("<ButtonPress-1>", on_touch_start)
            root.bind("<B1-Motion>", handle_swipe)
            root.bind("<Left>", lambda event: on_left_swipe(event))
            root.bind("<Right>", lambda event: on_right_swipe(event))

            current_frame_index = 0
            timer_override = False
            start_animation()

        else:
            refresh_flag = False
            timer_override = False
            return_to_image_cycle()
            
def cobs_land_or_buoy():
    global cobs_only_click_flag

    for widget in frame1.winfo_children():
        widget.destroy()
    
    frame1.grid(row=0, column=0, sticky="nsew")
    
    # Create and display the updated labels
    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, padx=50, pady=(50,0), sticky="w")
    
    instruction_text = "Do you want the third observation site to be on land or a buoy?"
    instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16,), bg=tk_background_color)
    instructions_label.grid(row=1, column=0, padx=50, pady=10, sticky="w")
    
    if cobs_only_click_flag == False:
        # Create the 'Back' button
        back_button = create_button(frame1, " Back ", button_font, setup_bobs_input_buoy)
        back_button.grid(row=2, column=0, padx=(50, 0), pady=30, sticky="w")
    
    # Create "Land" button
    land_button = create_button(frame1, " Land ", button_font, setup_cobs_input_land)
    land_button.grid(row=2, column=0, padx=200, pady=30, sticky="w")

    # Create "Buoy" button
    buoy_button = create_button(frame1, " Buoy ", button_font, setup_cobs_input_buoy)
    buoy_button.grid(row=2, column=0, padx=350, pady=30, sticky="w")
    
def bobs_land_or_buoy():
    global bobs_only_click_flag
            
    for widget in frame1.winfo_children():
        widget.destroy()
    
    frame1.grid(row=0, column=0, sticky="nsew")
    
    # Create and display the updated labels
    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, padx=50, pady=(50,0), sticky="w")
    
    instruction_text = "Do you want the second observation site to be on land or a buoy?"
    instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16,), bg=tk_background_color)
    instructions_label.grid(row=1, column=0, padx=50, pady=10, sticky="w")
    
    if bobs_only_click_flag == False:
        # Create the 'Back' button
        back_button = create_button(frame1, " Back ", button_font, land_or_buoy)
        back_button.grid(row=2, column=0, padx=(50, 0), pady=30, sticky="w")
    
    # Create "Land" button
    land_button = create_button(frame1, " Land ", button_font, setup_bobs_input_land)
    land_button.grid(row=2, column=0, padx=200, pady=30, sticky="w")

    # Create "Buoy" button
    buoy_button = create_button(frame1, " Buoy ", button_font, setup_bobs_input_buoy)
    buoy_button.grid(row=2, column=0, padx=350, pady=30, sticky="w")
        
def land_or_buoy():
    global aobs_only_click_flag, RANDOM_CANDIDATE_STATIONS_CACHE

    RANDOM_CANDIDATE_STATIONS_CACHE = initialize_random_candidate_cache(ALL_STATIONS_CACHE, aobs_site)
    print("line 6541. assembled list of random site candidates for future random requests.")
            
    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")

    # Create and display the updated labels
    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, padx=50, pady=(50,0), sticky="w")
    
    instruction_text = f"Do you want the first observation site to be on land or a buoy?\n\nOr\n\nYou can have 3 random sites chosen for you."
    instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16,), bg=tk_background_color, anchor='w', justify='left')
    instructions_label.grid(row=1, column=0, padx=50, pady=10, sticky='w')
    
    if aobs_only_click_flag == False:        
        # Create the 'Back' button
        back_button = create_button(frame1, " Back ", button_font, confirm_calibration_site)
        back_button.grid(row=2, column=0, padx=(50, 0), pady=30, sticky="w")
    
    # Create "Land" button
    land_button = create_button(frame1, " Land ", button_font, setup_aobs_input_land)
    land_button.grid(row=2, column=0, padx=(200,0), pady=30, sticky="w")

    # Create "Buoy" button
    buoy_button = create_button(frame1, " Buoy ", button_font, setup_aobs_input_buoy)
    buoy_button.grid(row=2, column=0, padx=(350,0), pady=30, sticky="w")
    
    # Create "Random" button
    random_button = create_button(frame1, "Random", button_font, generate_random_sites)
    random_button.grid(row=2, column=0, padx=(500,0), pady=30, sticky="w")

# --- CORRECTED Helper function to parse time string (Uses direct timedelta) ---
def parse_last_update(time_str):
    """
    Parses time strings like 'X Hours, Y Minutes, Z Seconds' or variations
    into a timedelta object using the directly imported timedelta class.
    Returns None if parsing fails. (Corrected for direct timedelta import)
    """
    hours, minutes, seconds = 0, 0, 0
    match = re.search(
        r"(?:(\d+)\s+Hours?,\s*)?"
        r"(?:(\d+)\s+Minutes?,\s*)?"
        r"(\d+)\s+Seconds?",
        time_str,
        re.IGNORECASE
    )
    if match:
        h_str, m_str, s_str = match.groups()
        hours = int(h_str) if h_str else 0
        minutes = int(m_str) if m_str else 0
        seconds = int(s_str) if s_str else 0
        # *** Use direct timedelta() call ***
        return timedelta(hours=hours, minutes=minutes, seconds=seconds)
    else:
        match = re.search(
             r"(?:(\d+)\s+Minutes?,\s*)?"
             r"(\d+)\s+Seconds?",
             time_str,
             re.IGNORECASE)
        if match:
             m_str, s_str = match.groups()
             minutes = int(m_str) if m_str else 0
             seconds = int(s_str) if s_str else 0
             # *** Use direct timedelta() call ***
             return timedelta(minutes=minutes, seconds=seconds)
        else:
             match = re.search(
                  r"(\d+)\s+Seconds?",
                  time_str,
                  re.IGNORECASE)
             if match:
                  s_str = match.group(1)
                  seconds = int(s_str) if s_str else 0
                  # *** Use direct timedelta() call ***
                  return timedelta(seconds=seconds)

    return None

# --- CORRECTED function to check radar status (Uses direct timedelta) ---
def check_radar_status(radar_identifier):
    """
    Checks radar status by cleaning the page to raw text and using Regex.
    Returns True if operational (<=30 min latency), False otherwise.
    """
    global lcl_radar_updated_flag

    radar_id_upper = radar_identifier.strip().upper()
    
    # 1. Validate ID
    if len(radar_id_upper) != 4 or not radar_id_upper.isalnum():
         print(f"Error: Invalid Radar ID format: '{radar_identifier}'.")
         return False

    url = "https://radar3pub.ncep.noaa.gov/"
    headers = {
        'User-Agent': 'Python Radar Status Checker Script v9 (Text Clean)'
    }
    
    print(f"Checking status for {radar_id_upper}...")

    try:
        response = requests.get(url, headers=headers, timeout=15)
        if response.status_code != 200:
            print(f"HTTP error fetching status list: {response.status_code}")
            return False
        
        # 2. Parse and Flatten to Text
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # This converts the entire HTML page into a simple string with spaces.
        # It fixes the issue where tags were merging words together.
        clean_text = soup.get_text(separator=' ')
        
        # 3. Find the Pattern in the clean text
        # Pattern looks for: ID + space + HH:MM:SS + space + MM/DD/YY
        # We use \s+ to handle any amount of spaces/tabs/newlines
        pattern = re.compile(rf"{radar_id_upper}\s+(\d{{2}}:\d{{2}}:\d{{2}})\s+(\d{{2}}/\d{{2}}/\d{{2}})")
        
        match = pattern.search(clean_text)
        
        if not match:
            # Fallback: Try to print what we 'almost' found for debugging
            print(f"Debug: Could not find '{radar_id_upper}' in clean text.")
            return False

        time_str = match.group(1) # 12:53:33
        date_str = match.group(2) # 11/21/25

        # 4. Calculate Latency
        full_dt_str = f"{date_str} {time_str}"
        
        try:
            radar_time = datetime.strptime(full_dt_str, "%m/%d/%y %H:%M:%S")
            radar_time = radar_time.replace(tzinfo=timezone.utc)
        except ValueError:
            print(f"Debug: Date format error. Parsed: '{full_dt_str}'")
            return False

        current_time = datetime.now(timezone.utc)
        latency = current_time - radar_time
        threshold = timedelta(minutes=30)

        if latency <= threshold:
            lcl_radar_updated_flag = False
            return True
        else:
            print(f"Radar {radar_id_upper} is stale. Last update: {full_dt_str} (Latency: {latency})")
            return False

    except requests.exceptions.RequestException as e:
        print(f"Network error checking radar '{radar_id_upper}': {e}")
        return False
    except Exception as e:
        print(f"Error during parsing for radar '{radar_id_upper}': {e}")
        return False

# --- confirm_radar_site function remains unchanged ---
def confirm_radar_site():
    global radar_identifier, lcl_radar_zoom_clicks, lcl_radar_zoom_clicks_value, confirm_label, submit_button
    global lcl_radar_zoom_label, lcl_radar_dropdown, message_label

    # Get the zoom level from the dropdown
    lcl_radar_zoom_clicks_value = lcl_radar_zoom_clicks.get()

    # Display the "Checking radar site..." message
    checking_message = "Checking radar site..."
    # Assume frame1, tk, tk_background_color are defined elsewhere in your GUI code
    message_label = tk.Label(frame1, text=checking_message, font=("Arial", 16), justify='left',
                             bg=tk_background_color)
    message_label.grid(row=0, column=0, padx=250, pady=(530, 0), sticky='nw')

    # Disable the submit button to prevent multiple clicks
    submit_button.config(state='disabled')

    # Start the radar site check in a separate thread
    def check_site():
        is_functioning = check_radar_status(radar_identifier) # CALLS THE UPDATED FUNCTION

        # Update the GUI after checking the radar site
        def update_gui():
            global message_label  # Ensure we're modifying the message_label from confirm_radar_site

            if is_functioning:
                # Remove the "Checking radar site..." message
                if message_label is not None and message_label.winfo_exists():
                    message_label.destroy()
                    message_label = None

                # Radar is functioning, proceed to the next step
                # Set the zoom clicks to the selected value
                lcl_radar_zoom_clicks.set(lcl_radar_zoom_clicks_value)

                # Clear the current display
                for widget in frame1.winfo_children():
                    widget.destroy()

                # Proceed to the next step (Assume lightning_center_input is defined elsewhere)
                lightning_center_input()
            else:
                # Radar is unavailable
                # Remove existing message_label if any
                if message_label is not None and message_label.winfo_exists():
                    message_label.destroy()
                    message_label = None

                # Display error message
                unavailable_message = "The selected radar site is currently unavailable.\nPlease choose another site."
                message_label = tk.Label(frame1, text=unavailable_message, font=("Arial", 16), justify='left',
                                         bg=tk_background_color, fg="red")
                message_label.grid(row=0, column=0, padx=250, pady=(530, 0), sticky='nw')

                # Re-enable the submit button
                submit_button.config(state='normal')

        # Schedule the GUI update in the main thread
        # Assumes frame1 is your tkinter container widget
        frame1.after(0, update_gui)

    # Start the thread
    # Assumes threading is imported
    threading.Thread(target=check_site, daemon=True).start()

def confirm_calibration_site():
    global submit_calibration_town, show_baro_input, baro_input, aobs_site
    
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nesw")
    
    # Create and display the updated labels
    label1 = tk.Label(frame1, text="The Weather Observer\n", font=("Arial", 18, "bold"), bg=tk_background_color)
    label1.grid(row=0, column=0, padx=50, pady=(50, 0), sticky="w")
    
    updated_text = f"{aobs_site}"
    label2 = tk.Label(frame1, text=updated_text, font=("Arial", 16), bg=tk_background_color)
    label2.grid(row=1, column=0, padx=(50,0), pady=(0, 10), sticky='w')
    
    updated_text = f"will be used as the calibration site."
    label2 = tk.Label(frame1, text=updated_text, font=("Arial", 16), bg=tk_background_color)
    label2.grid(row=2, column=0, padx=(50,0), pady=(20, 30), sticky='w') 
    
    # Create the 'Next' button
    next_button = create_button(frame1, "Next", button_font, land_or_buoy)
    next_button.grid(row=3, column=0, padx=(200, 0), pady=5, sticky="w")
    
    # Create the 'Back' button
    back_button = create_button(frame1, "Back", button_font, welcome_screen)
    back_button.grid(row=3, column=0, padx=(50, 0), pady=5, sticky="w")

def submit_calibration_input():
    global submit_calibration_town, submit_calibration_state, calibration_town, calibration_state, calibration_lat, calibration_lon, aobs_site
    global show_baro_input, baro_input, latitude, longitude
    global RANDOM_CANDIDATE_STATIONS_CACHE
    
    submit_calibration_town = calibration_town.get()
    submit_calibration_state = calibration_state.get()

    submit_calibration_town = submit_calibration_town.title()
    submit_calibration_state = submit_calibration_state.upper()

    aobs_site = submit_calibration_town + ", " + submit_calibration_state

    RANDOM_CANDIDATE_STATIONS_CACHE = initialize_random_candidate_cache(ALL_STATIONS_CACHE, aobs_site)
    #print("line 6599. assembled list of random site candidates for future random requests.")

    for widget in frame1.winfo_children():
        widget.destroy()

    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, padx=50, pady=(50,10), sticky="w")

    geolocator = Nominatim(user_agent="geocoder_app")

    try:
        # Attempt to geocode the location
        location = geolocator.geocode(f"{submit_calibration_town}, {submit_calibration_state}", country_codes="us")
        
        if location is not None:
            calibration_lat = location.latitude
            calibration_lon = location.longitude
            
            latitude = location.latitude
            longitude = location.longitude

            response = requests.get(f'https://api.weather.gov/points/{calibration_lat},{calibration_lon}')
            if response.status_code == 200:
                data = response.json()
                stations_url = data['properties']['observationStations']
                stations_response = requests.get(stations_url)
                if stations_response.status_code == 200:
                    stations_data = stations_response.json()

                    for station_url in stations_data['observationStations']:
                        obs_response = requests.get(f"{station_url}/observations/latest")
                        if obs_response.status_code == 200:
                            obs_data = obs_response.json()
                            if 'barometricPressure' in obs_data['properties'] and obs_data['properties']['barometricPressure']['value'] is not None:
                                baro_input = pascals_to_inches_hg(obs_data['properties']['barometricPressure']['value'])
                                show_baro_input = f'{baro_input:.2f}'
                                instruction_text = f"The barometric pressure at {aobs_site} is {show_baro_input} inches.\nDo you want to keep this as the calibration site,\nchange the site again or,\nenter your own barometric pressure?"
                                display_calibration_results(instruction_text)
                                return

            display_calibration_error("No usable barometric pressure reading was found.")
        else:
            display_calibration_error("Could not match that location with a barometric pressure reading.")
    
    except (requests.exceptions.ConnectionError, requests.exceptions.Timeout, geopy.exc.GeocoderUnavailable):
        display_calibration_error("Geo services are temporarily out of service. Please try again later.")
        
def display_calibration_results(instruction_text):
    """Displays the calibration results on the GUI."""
    instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
    instructions_label.grid(row=1, column=0, padx=(50,0), pady=(10, 20), sticky="w")

    # Create the 'Back' button
    back_button = tk.Button(frame1, text=" Back ", font=button_font, command=change_calibration_site)
    back_button.grid(row=2, column=0, padx=(50, 0), pady=20, sticky="w")
    
    keep_button = tk.Button(frame1, text=" Keep ", font=button_font, command=confirm_calibration_site)
    keep_button.grid(row=2, column=0, padx=(200,0), pady=20, sticky="w")
    change_button = tk.Button(frame1, text="Change", font=button_font, command=change_calibration_site)
    change_button.grid(row=2, column=0, padx=(350,0), pady=20, sticky="w")
    enter_own_button = tk.Button(frame1, text=" Own ", font=button_font, command=own_calibration_site)
    enter_own_button.grid(row=2, column=0, padx=(500,0), pady=20, sticky="w")

def display_calibration_error(message):
    """Displays an error message on the GUI."""
    instructions_label = tk.Label(frame1, text=message, font=("Helvetica", 16), bg=tk_background_color)
    instructions_label.grid(row=1, column=0, padx=(50,0), pady=(20, 10))
    change_button = tk.Button(frame1, text="Change", font=button_font, command=change_calibration_site)
    change_button.grid(row=2, column=0, padx=(50,0), pady=5, sticky="w")
        
        
def change_calibration_site():
    global calibration_town, calibration_state, current_target_entry, state_entry_widgets, is_buoy_code

    # Reset current_target_entry
    current_target_entry = None

    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")

    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, columnspan=20, padx=50, pady=(50, 5), sticky="nw")

    instructions_label = tk.Label(frame1, text="Please enter the name of the town to be used for calibration:", font=("Helvetica", 16), bg=tk_background_color, justify="left")
    instructions_label.grid(row=1, column=0, columnspan=20, padx=(50, 0), pady=5, sticky='nw')

    calibration_town = tk.Entry(frame1, font=("Helvetica", 14), justify="left")
    calibration_town.grid(row=2, column=0, columnspan=20, padx=(50, 0), pady=5, sticky='nw')
    calibration_town.bind("<FocusIn>", lambda e: set_current_target(calibration_town))
    calibration_town.focus_set()

    state_instructions_label = tk.Label(frame1, text="Please enter the 2-letter state ID for the calibration site:", font=("Helvetica", 16), bg=tk_background_color, justify="left")
    state_instructions_label.grid(row=3, column=0, columnspan=20, padx=(50, 0), pady=5, sticky='nw')

    calibration_state = tk.Entry(frame1, font=("Helvetica", 14))
    calibration_state.grid(row=4, column=0, columnspan=20, padx=(50, 0), pady=5, sticky='nw')
    calibration_state.bind("<FocusIn>", lambda e: [set_current_target(calibration_state), set_state_uppercase()]) # added

    # Add the calibration state to the state_entry_widgets dict.
    state_entry_widgets["calibration_state"] = calibration_state

    # Create the 'Back' button
    back_button = tk.Button(frame1, text=" Back ", font=("Helvetica", 16, "bold"), command=welcome_screen)
    back_button.grid(row=5, column=0, columnspan=20, padx=(50, 0), pady=5, sticky="nw")

    submit_button = tk.Button(frame1, text="Submit", command=submit_calibration_input, font=("Helvetica", 16, "bold"))
    submit_button.grid(row=5, column=0, columnspan=20, padx=(200, 0), pady=5, sticky='nw')

    # Spacer to push the keyboard to the bottom
    spacer = tk.Label(frame1, text="", bg=tk_background_color)
    spacer.grid(row=6, column=0, sticky="nsew", pady=(0, 35))  # Adjust row and pady as necessary

    # Set is_buoy_code to False before calling create_virtual_keyboard
    is_buoy_code = False
    create_virtual_keyboard(frame1, 7)

def set_current_target(entry_widget):
    global current_target_entry
    current_target_entry = entry_widget
    
def own_calibration_site():
    global baro_input_box, current_target_entry, calibration_town, calibration_state

    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")

    label1 = tk.Label(frame1, text="The Weather Observer", font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, columnspan=20, padx=50, pady=(30,0), sticky="nw")

    instruction_text = "Please enter the current barometric pressure reading in inches from your own source.\nEnter in the form XX.XX"
    instructions_label = tk.Label(frame1, text=instruction_text, font=("Helvetica", 16), bg=tk_background_color, justify="left")
    instructions_label.grid(row=1, column=0, columnspan=20, padx=50, pady=0, sticky="nw")

    # Create an Entry widget for the user to input the barometric pressure
    baro_input_box = tk.Entry(frame1, font=("Helvetica", 14), width=10)  # Adjust width as necessary
    baro_input_box.grid(row=2, column=0, columnspan=20, padx=50, pady=5, sticky="nw")
    baro_input_box.bind("<FocusIn>", lambda e: set_current_target(baro_input_box))
    baro_input_box.focus_set()
    
    label_text = "inches of mercury"
    label = tk.Label(frame1, text=label_text, font=("Helvetica", 14), bg=tk_background_color)
    label.grid(row=2, column=0, columnspan=20, padx=(170, 0), pady=(8,4), sticky="nw")  # Minor adjustment for positioning next to the entry
    
    home_town_label = tk.Label(frame1, text="Please enter the name of the town where the barometer is being measured:", font=("Helvetica", 16), bg=tk_background_color, justify="left")
    home_town_label.grid(row=3, column=0, columnspan=20, padx=(50,0), pady=(5,0), sticky='nw')
    
    calibration_town = tk.Entry(frame1, font=("Helvetica", 14), justify="left")
    calibration_town.grid(row=4, column=0, columnspan=20, padx=(50,0), pady=(0,10), sticky='nw')
    calibration_town.bind("<FocusIn>", lambda e: set_current_target(calibration_town))
        
    home_state_label = tk.Label(frame1, text="Please enter the 2-letter state ID where the barometer is being measured:", font=("Helvetica", 16), bg=tk_background_color, justify="left")
    home_state_label.grid(row=5, column=0, columnspan=20, padx=(50,0), pady=0, sticky='nw')
    
    calibration_state = tk.Entry(frame1, font=("Helvetica", 14))
    calibration_state.grid(row=6, column=0, columnspan=20, padx=(50,0), pady=(0,10), sticky='nw')
    calibration_state.bind("<FocusIn>", lambda e: set_current_target(calibration_state))
    
    # Create the 'Back' button
    back_button = tk.Button(frame1, text=" Back ", font=("Helvetica", 16, "bold"), command=welcome_screen)
    back_button.grid(row=7, column=0, columnspan=20, padx=(50, 0), pady=5, sticky="nw")

    # Create a submit button to process the user's input
    submit_button = tk.Button(frame1, text="Submit", command=submit_calibration_input, font=("Helvetica", 16, "bold"))
    submit_button.grid(row=7, column=0, columnspan=20, padx=200, pady=5, sticky="nw")

    # Spacer to push the keyboard to the bottom
    spacer = tk.Label(frame1, text="", bg=tk_background_color)
    spacer.grid(row=8, column=0, sticky="nsew", pady=(10, 0))  # Adjust row and pady as necessary

    # Display the virtual keyboard
    create_virtual_keyboard(frame1, 9)  # Adjust as necessary based on layout
    
def submit_own_calibration():
    global baro_input 

    # Get the user's input
    baro_input = float(baro_input_box.get())
 
    # Continue with other actions or functions as needed
    land_or_buoy()

def welcome_screen():
    
    # here's a block for some business after many functions defined, but passing here only once
    setup_function_button_frame()
    
    # Clear the current display
    for widget in frame1.winfo_children():
        widget.destroy()

    frame1.grid(row=0, column=0, sticky="nsew")

    # First line (bold)
    label1 = tk.Label(frame1, text=f'Welcome to The Weather Observer v{VERSION}', font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, padx=50, pady=(50, 10), sticky="w")
    
    if baro_input is None:
        own_calibration_site()

    # Main block of text including the question
    info_text = f'''
    In order to begin, your new instrument needs to be calibrated,
    and you need to make choices about which weather to observe.

    Please confirm your current location:
    {aobs_site}

    If this isn't your location, click change below.
    
    The site will be used to calibrate the first barometric pressure reading.
    The current barometric pressure reading at {aobs_site} is: {baro_input:.2f} inches.

    Do you want to keep this location as the calibration site,
    change to another site, or
    enter your own barometric pressure?
    '''

    label2 = tk.Label(frame1, text=info_text, font=("Arial", 16), bg=tk_background_color, justify="left")
    label2.grid(row=1, column=0, padx=50, pady=(0, 10), sticky='w')

    # Define frame_question
    frame_question = tk.Frame(frame1, bg=tk_background_color)
    frame_question.grid(row=2, column=0, pady=(0, 5), sticky="w")

    # Create the 'Keep' button
    keep_button = create_button(frame_question, "Keep", button_font, confirm_calibration_site)
    keep_button.grid(row=0, column=0, padx=50, pady=0, sticky="w")

    # Create the 'Change' button
    change_button = create_button(frame_question, "Change", button_font, change_calibration_site)
    change_button.grid(row=0, column=0, padx=190, pady=0, sticky="w")

    # Create the 'Enter Your Own' button
    enter_own_button = create_button(frame_question, "Own", button_font, own_calibration_site)
    enter_own_button.grid(row=0, column=0, padx=350, pady=0, sticky="w")

if location == None:
        # First line (bold)
    label1 = tk.Label(frame1, text=f'Welcome to The Weather Observer v{VERSION}', font=("Arial", 18, "bold"), bg=tk_background_color, justify="left")
    label1.grid(row=0, column=0, padx=50, pady=(50, 10), sticky="w")
    
    info_text = f'''
    In order to begin, your new instrument needs to be calibrated,
    and you need to make choices about which weather to observe.

    The Weather Observer couldn't determine your current location, so
    please click Next to enter your location:

    Or click Own to enter your own known, current, accurate barometric 
    pressure reading to be used for calibration.
    
    '''    
    label2 = tk.Label(frame1, text=info_text, font=("Arial", 16), bg=tk_background_color, justify="left")
    
    label2.grid(row=1, column=0, padx=50, pady=(0, 10), sticky='w')

    # Define frame_question
    frame_question = tk.Frame(frame1, bg=tk_background_color)
    frame_question.grid(row=2, column=0, pady=(0, 5), sticky="w")

    # Create the 'Change' button
    change_button = create_button(frame_question, "Next", button_font, change_calibration_site)
    change_button.grid(row=0, column=0, padx=50, pady=0, sticky="w")

    # Create the 'Enter Your Own' button
    enter_own_button = create_button(frame_question, "Own", button_font, own_calibration_site)
    enter_own_button.grid(row=0, column=0, padx=140, pady=0, sticky="w")

else:
    welcome_screen()
    
def initialize_random_candidate_cache(master_station_list, user_location_str):
    """
    Geocodes a user location and filters a master station list to find all
    stations within a maximum search radius.

    This function is intended to be run once at startup to create a smaller,
    pre-filtered list of candidate stations for subsequent random selections.
    It also saves the filtered list to a JSON file for diagnostics.

    Args:
        master_station_list (list): The complete list of station dictionaries.
        user_location_str (str): The location to search near (e.g., "Watertown, MA").

    Returns:
        list: A list of candidate station dictionaries within the max radius,
              or an empty list if an error occurs.
    """
    MAX_RADIUS_MILES = 100
    DIAGNOSTIC_FILE_PATH = "/home/santod/random_candidate_stations.json"

    if not master_station_list:
        print("[ERROR] Master station list is empty. Cannot initialize random candidate cache.")
        return []

    print(f"Initializing random candidate cache for location: '{user_location_str}'...")

    try:
        # 1. Geocode the user's location to get lat/lon
        geolocator = Nominatim(user_agent="station_cache_initializer")
        center_location = geolocator.geocode(user_location_str, exactly_one=True, timeout=10)
        if center_location is None:
            print(f"[ERROR] Could not geocode the location: {user_location_str}")
            return []
        
        center_lat, center_lon = center_location.latitude, center_location.longitude
        print(f"Successfully geocoded location to: Lat {center_lat:.4f}, Lon {center_lon:.4f}")

        # 2. Create a bounding box for the maximum search area
        lat_deg_per_mile = 1.0 / 69.0
        lon_deg_per_mile = 1.0 / (math.cos(math.radians(center_lat)) * 69.0)
        
        lat_delta = MAX_RADIUS_MILES * lat_deg_per_mile
        lon_delta = MAX_RADIUS_MILES * lon_deg_per_mile
        
        min_lat, max_lat = center_lat - lat_delta, center_lat + lat_delta
        min_lon, max_lon = center_lon - lon_delta, center_lon + lon_delta

        # 3. Filter the master list to find all stations within the bounding box
        candidate_stations = [
            s for s in master_station_list
            if "latitude" in s and "longitude" in s and
               min_lat <= s["latitude"] <= max_lat and
               min_lon <= s["longitude"] <= max_lon
        ]
        
        print(f"Found {len(candidate_stations)} candidate stations within {MAX_RADIUS_MILES} miles.")

        # 4. Save the resulting list to a file for your inspection
        try:
            with open(DIAGNOSTIC_FILE_PATH, 'w') as f:
                json.dump(candidate_stations, f, indent=4)
            print(f"Successfully saved candidate list to {DIAGNOSTIC_FILE_PATH}")
        except IOError as e:
            print(f"[ERROR] Could not write diagnostic file: {e}")

        return candidate_stations

    except Exception as e:
        print(f"[ERROR] An unexpected error occurred during cache initialization: {e}")
        return []

# --- Example of how to call this function in your main script ---

# This would go in your startup code, after ALL_STATIONS_CACHE and aobs_site are defined.
# Note: You will need to define the new global variable at the top of your script.
# RANDOM_CANDIDATE_STATIONS_CACHE = None

# print("\n--- Initializing random station candidate cache ---")
# RANDOM_CANDIDATE_STATIONS_CACHE = initialize_random_candidate_cache(
#     master_station_list=ALL_STATIONS_CACHE,
#     user_location_str=aobs_site
# )
# print(f"Initialization complete. Cache contains {len(RANDOM_CANDIDATE_STATIONS_CACHE)} stations.")

#RANDOM_CANDIDATE_STATIONS_CACHE = initialize_random_candidate_cache(ALL_STATIONS_CACHE, aobs_site)

# Call this function to stop the image cycle and forget all frames
def forget_all_frames():
    global auto_advance_timer, update_images_timer

    # Cancel the auto-advance timer if it's running
    if auto_advance_timer:
        root.after_cancel(auto_advance_timer)
        auto_advance_timer = None
        print("line 6599. Auto-advance timer canceled.")

    # Cancel the update_images timer if it's running
    if update_images_timer:
        root.after_cancel(update_images_timer)
        update_images_timer = None
        print("line 6605. Update images timer canceled.")

    display_image_frame.grid_forget()
        
    function_button_frame.grid_forget()

def return_to_image_cycle():
    global auto_advance_timer, update_images_timer, current_frame_index, image_keys, extremes_flag, refresh_flag, reboot_shutdown_flag
    global last_lcl_radar_update, last_still_sat_update, last_reg_sat_update, last_sfc_plots_update, last_radiosonde_update
    global atemp, awtemp, awind, btemp, bwtemp, bwind, ctemp, cwtemp, cwind
    global aobs_buoy_signal, bobs_buoy_signal, cobs_buoy_signal
    global aobs_buoy_code, bobs_buoy_code, cobs_buoy_code
    global aobs_station_identifier, bobs_station_identifier, cobs_station_identifier
    global last_land_scrape_time, xs

    last_lcl_radar_update = last_still_sat_update = last_reg_sat_update = last_sfc_plots_update = last_radiosonde_update = None
    refresh_flag = extremes_flag = reboot_shutdown_flag = False
    
    clear_random_map_ui()
    
    for widget in frame1.winfo_children():
        widget.destroy()
    
    if auto_advance_timer:
        root.after_cancel(auto_advance_timer)
        auto_advance_timer = None
    if update_images_timer:
        root.after_cancel(update_images_timer)
        update_images_timer = None

    current_frame_index = 0
    
    if len(xs) != 1:
        update_transparent_frame_data()
            
    show_function_button_frame()
    frame1.grid_forget()

    #     # Add placeholder labels
    #     baro_placeholder_label = tk.Label(display_image_frame, text="Barograph is being prepared", fg="white", bg="black", bd=0, highlightthickness=0)
    #     baro_placeholder_label.grid(row=0, column=0)
    # 
    #     national_radar_placeholder_label = tk.Label(display_image_frame, text="The National Radar Image is being prepared", fg="white", bg="black")
    #     national_radar_placeholder_label.grid(row=0, column=0)

    display_image_frame.grid(row=0, column=0, padx=(150,0), pady=(70,0), sticky="sw")
    root.grid_rowconfigure(0, weight=0)
    root.grid_columnconfigure(0, weight=0)

    show_image_in_display_frame(image_keys[current_frame_index])
    update_images()
    auto_advance_frames()

def run_lcl_radar_loop_animation():
    global available_image_dictionary, display_label, root, lcl_radar_animation_id, LCL_RADAR_ANIM_GEN

    if lcl_radar_animation_id:
        try: root.after_cancel(lcl_radar_animation_id)
        except Exception: pass
        lcl_radar_animation_id = None

    if 'lcl_radar_loop_img' not in available_image_dictionary: return
    lcl = available_image_dictionary['lcl_radar_loop_img']
    if not lcl: return

    first_frame, padx0, pady0 = lcl[0]
    w, h = first_frame.size

    # Create a single reusable PhotoImage once per run
    photo = ImageTk.PhotoImage(first_frame)  # initializes correct size
    display_label.configure(image=photo)
    display_label.image = photo
    display_label.grid(row=0, column=0, padx=padx0, pady=pady0, sticky="se")
    display_label.lift()

    # generation guard
    if 'LCL_RADAR_ANIM_GEN' not in globals():
        LCL_RADAR_ANIM_GEN = 0
    LCL_RADAR_ANIM_GEN += 1
    my_gen = LCL_RADAR_ANIM_GEN

    cycle_count = 0
    max_cycles = 3

    def play_loop(index=0):
        nonlocal cycle_count
        if my_gen != LCL_RADAR_ANIM_GEN:
            return

        frame, _, _ = lcl[index % len(lcl)]

        try:
            # Paste into the existing Tk image to avoid reallocations
            #print("[DEBUG] pasting new LCL frame into reusable PhotoImage")
            photo.paste(frame)   # reuse same PhotoImage
            # no new PhotoImage objects, no reassign of display_label.image
            display_label.lift()
        except Exception as e:
            print(f"[ERROR] displaying frame: {e}")
            return

        next_index = (index + 1) % len(lcl)
        delay = 200 if next_index != 0 else 2000
        if next_index == 0:
            cycle_count += 1
            if cycle_count >= max_cycles:
                return

        globals()['lcl_radar_animation_id'] = root.after(delay, play_loop, next_index)

    play_loop(0)

# Function to display the regional satellite loop
def run_reg_sat_loop_animation():
    global available_image_dictionary, display_label, root, reg_sat_animation_id, REG_SAT_ANIM_GEN

    # cancel any existing scheduled animation
    if reg_sat_animation_id:
        try:
            root.after_cancel(reg_sat_animation_id)
        except Exception:
            pass
        reg_sat_animation_id = None

    # safety checks
    if 'reg_sat_loop_img' not in available_image_dictionary:
        return
    regsat = available_image_dictionary['reg_sat_loop_img']
    if not regsat:
        return

    # prepare first frame
    first_frame, padx0, pady0 = regsat[0]
    w, h = first_frame.size

    # Create a single reusable PhotoImage once per run
    photo = ImageTk.PhotoImage(first_frame)  # initializes correct size
    display_label.configure(image=photo)
    display_label.image = photo
    display_label.grid(row=0, column=0, padx=padx0, pady=(pady0, 0), sticky="se")
    display_label.lift()

    # generation guard
    if 'REG_SAT_ANIM_GEN' not in globals():
        REG_SAT_ANIM_GEN = 0
    REG_SAT_ANIM_GEN += 1
    my_gen = REG_SAT_ANIM_GEN

    cycle_count = 0
    max_cycles = 5  # keep your original

    def play_sat_loop(index=0):
        nonlocal cycle_count
        if my_gen != REG_SAT_ANIM_GEN:
            return

        # respect timer override
        if timer_override and current_frame_index != 5:
            return

        frame, _, _ = regsat[index % len(regsat)]
        try:
            # Debug optional
            # print("[DEBUG] pasting new REGSAT frame into reusable PhotoImage")
            photo.paste(frame)   # reuse same PhotoImage
            display_label.lift()
        except Exception as e:
            print(f"[ERROR] displaying reg_sat frame: {e}")
            return

        next_index = (index + 1) % len(regsat)
        delay = 200 if next_index != 0 else 2000
        if next_index == 0:
            cycle_count += 1
            if cycle_count >= max_cycles:
                return

        globals()['reg_sat_animation_id'] = root.after(delay, play_sat_loop, next_index)

    play_sat_loop(0)


# update images/loops in queue design 7/10/25
def update_images():
    """
    (Scheduler Version) This function is now the central scheduler for all data fetching.
    - It handles low-demand images with simple timers.
    - It manages a queue for high-demand tasks, launching them only when the
      system has the capacity (low CPU) and the task's specific timer has expired.
    """
    global last_radar_update, last_sfc_update, last_vorticity_update, last_satellite_update
    global last_baro_update, last_national_satellite_scrape_time, last_lcl_radar_update
    global last_land_scrape_time, last_lightning_update, last_reg_sat_update, last_sfc_plots_update
    global last_monitor_check, update_images_timer
    global task_queue, TASK_IN_PROGRESS, CPU_IS_IDLE

    current_time = datetime.now()

    # --- Part 1: Low-Demand Image Updates (Unchanged) ---
    # These tasks are lightweight and continue to run on their own simple timers,
    # independent of the main queue.
    
    def update_baro_pic():
        global last_baro_update
        if not last_baro_update or (current_time - last_baro_update).total_seconds() >= 180:
            fetch_and_process_baro_pic(available_image_dictionary)
            last_baro_update = current_time

    def update_national_radar():
        global last_radar_update
        if box_variables[1] == 1:
            if last_radar_update is None or (current_time - last_radar_update).total_seconds() >= 600:
                fetch_and_process_national_radar(available_image_dictionary)
                last_radar_update = current_time

    def update_still_sat():
        """Schedules the still satellite image update every 10 minutes using asyncio tasks."""
        global last_still_sat_update

        if box_variables[4] == 1:
            current_time = datetime.now()

            # --- CORRECTED: Compare timedelta to timedelta ---
            # The integer 600 is now correctly wrapped in a timedelta object
            # for a valid comparison.
            if last_still_sat_update is None or (current_time - last_still_sat_update) >= timedelta(seconds=600):
                #print("[DEBUG] Submitting still sat update to the asyncio event loop...")
                try:
                    # Use the saved background event loop
                    if background_loop:
                        asyncio.run_coroutine_threadsafe(
                        fetch_and_process_still_sat(
                            available_image_dictionary,
                            lg_still_sat_choice_vars,
                            lg_still_sat,
                            lg_still_view
                        ),
                        background_loop
)
                        last_still_sat_update = current_time
                        #print("[DEBUG] line 6961. still sat image updated.")
                    else:
                        print("[ERROR] Background event loop is not running.")
                except Exception as e:
                    print(f"Error updating still sat: {e}")

            
    def update_national_sfc():    
        if box_variables[6] == 1:
            current_time = datetime.now()        
            if last_national_sfc_update is None or (current_time - last_national_sfc_update) >= timedelta(seconds=3600):            
                try:
                    fetch_and_process_national_sfc(available_image_dictionary)
                    #print("[DEBUG] line 6955. national sfc updated.")
                except Exception as e:
                    print(f"Error line 6866. updating national sfc: {e}")
                
    def update_radiosonde():
        """
        Checks for new radiosonde updates starting at 00Z or 12Z and continues every 10 minutes until a new image is successfully fetched.
        Stops checking after a successful update until the next 00Z or 12Z crossing.
        """
        global last_radiosonde_update, last_radiosonde_update_check, radiosonde_updated_flag

        # Check if the radiosonde display is enabled
        if box_variables[8] == 1:
            current_time = datetime.utcnow()  # Use UTC for comparison
            #print(f"line 6997. About to check for an updated radiosonde. Radiosonde updated flag: {radiosonde_updated_flag}")

            # Check if we crossed 00Z or 12Z since the last check
            if last_radiosonde_update_check is None or (
                (last_radiosonde_update_check.hour < 12 <= current_time.hour) or
                (last_radiosonde_update_check.hour >= 12 and current_time.hour < 12)
            ):
                #print("line 7001. Crossing 00Z or 12Z, allowing updates.")
                radiosonde_updated_flag = False  # Reset flag to allow updates
                last_radiosonde_update_check = current_time  # Update the last check time

            # Attempt to update if the flag is False and it has been at least 10 minutes
            # maybe change to elif
            if not radiosonde_updated_flag and (
                last_radiosonde_update is None or
                (current_time - last_radiosonde_update).total_seconds() >= 600
            ):
                #print("line 6510. Fetching and processing a new radiosonde image.")
                fetch_and_process_radiosonde(
                    available_image_dictionary,
                    background_loop,
                    sonde_letter_identifier
                )  # This function should internally set the flag to True on success
                last_radiosonde_update = current_time  # Update the last update time
                #print("[DEBUG] line 7038. came back from fetch and process radiosonde.")

            
    def update_vorticity():
        global last_vorticity_update
        
        if box_variables[9] == 1:  # Check if the update condition is met
            current_time = datetime.now()
            
            # Check if an hour has passed since the last update
            if last_vorticity_update is None or (current_time - last_vorticity_update) >= timedelta(seconds=3600):
                try:
                    fetch_and_process_vorticity(available_image_dictionary)
                    last_vorticity_update = current_time  # Update the last successful update time
                    #print("[DEBUG] line 7049. Vorticity updated.")
                except Exception as e:
                    print(f"Error line 7051. Updating vorticity: {e}")
                    
    def update_storm_reports():
        global last_storm_reports_update
        global box_variables, refresh_flag

        if box_variables[10] == 1 and not refresh_flag:  # Assuming box_variables and refresh_flag are properly defined elsewhere
            current_time = datetime.now()

            # Check if an hour has passed since the last scrape or if it's the first time
            if last_storm_reports_update is None or (current_time - last_storm_reports_update).total_seconds() >= 3600:
                try:
                    fetch_and_process_storm_reports(available_image_dictionary)
                    last_storm_reports_update = current_time  # Update the last successful update time
                    #print("Storm reports updated.")
                except Exception as e:
                    print(f"Error updating storm reports: {e}")
                    
    # Check the three conditions required to start a new task:
    # 1. Is the CPU idle?
    # 2. Is there another high-demand task already running?
    # 3. Is the UI ready (i.e., not in the middle of a user interaction)?
    # Check the three conditions required to start a new task.
    if CPU_IS_IDLE and not TASK_IN_PROGRESS and not any([aobs_only_click_flag, bobs_only_click_flag, cobs_only_click_flag]):
        
        # Iterate through the queue to find the first task that's ready to run.
        for i, task_name in enumerate(task_queue):
            
            # --- Check if this task is enabled by the user ---
            task_is_enabled = False
            if task_name == 'lightning' and box_variables[3] == 1: task_is_enabled = True
            if task_name == 'lcl_radar' and box_variables[2] == 1: task_is_enabled = True
            if task_name == 'observations': task_is_enabled = True # Always considered enabled
            if task_name == 'sfc_plots' and box_variables[7] == 1: task_is_enabled = True
            if task_name == 'reg_sat' and box_variables[5] == 1: task_is_enabled = True
            
            if not task_is_enabled:
                continue # Skip to the next task in the queue

            # --- Check the specific timer for this task ---
            timer_expired = False
            if task_name == 'lightning' and (last_lightning_update is None or (current_time - last_lightning_update).total_seconds() >= 240): timer_expired = True
            if task_name == 'lcl_radar' and (last_lcl_radar_update is None or (current_time - last_lcl_radar_update).total_seconds() >= 180): timer_expired = True
            if task_name == 'observations' and (last_land_scrape_time is None or (current_time - last_land_scrape_time).total_seconds() >= 480): timer_expired = True
            if task_name == 'sfc_plots' and (last_sfc_plots_update is None or (current_time - last_sfc_plots_update).total_seconds() >= 300): timer_expired = True
            if task_name == 'reg_sat' and (last_reg_sat_update is None or (current_time - last_reg_sat_update).total_seconds() >= 600): timer_expired = True

            if timer_expired:
                # We found a task that is ready!
                #print(f"[SCHEDULER] Conditions met. Starting task: '{task_name}'")
                
                # Set the global flag to prevent other tasks from starting
                TASK_IN_PROGRESS = True
                
                # Launch the appropriate task wrapper
                if task_name == 'lightning':
                    last_lightning_update = current_time
                    run_lightning_task()
                elif task_name == 'lcl_radar':
                    last_lcl_radar_update = current_time
                    run_lcl_radar_task()
                elif task_name == 'observations':
                    last_land_scrape_time = current_time
                    run_observations_task()
                elif task_name == 'sfc_plots':
                    last_sfc_plots_update = current_time
                    run_sfc_plots_task()
                elif task_name == 'reg_sat':
                    last_reg_sat_update = current_time
                    run_reg_sat_task()

                # Rotate the queue so this task moves to the back.
                # We do this by taking the executed task and all tasks before it
                # and moving them to the end of the list.
                for _ in range(i + 1):
                    task_queue.append(task_queue.pop(0))
                
                # IMPORTANT: We only run ONE high-demand task per cycle.
                # Break out of the for loop.
                break

    # --- Part 3: Call Low-Demand Updaters and Schedule Next Cycle ---
    update_baro_pic()
    update_national_radar()
    update_still_sat()
    update_national_sfc()
    update_radiosonde()
    update_vorticity()
    update_storm_reports()
    # ... (call all other low-demand updaters here) ...
    
    monitor_system_health()
    update_images_timer = root.after(60000, update_images)
    
def run_lightning_task():
    def task_wrapper():
        global TASK_IN_PROGRESS
        
        lightning_scraping_in_progress_ref = [lightning_scraping_in_progress]
        
        try:
            fetch_and_process_lightning(
                available_image_dictionary,
                lightning_lat,
                lightning_lon,
                CHROME_DRIVER_PATH,
                CHROMIUM_BIN,
                lightning_scraping_in_progress_ref,
                root
            )
        finally:
            #print("[SCHEDULER] 'lightning' task finished.")
            TASK_IN_PROGRESS = False
    threading.Thread(target=task_wrapper, daemon=True).start()

def run_lcl_radar_task():
    def task_wrapper():
        global TASK_IN_PROGRESS
        try:
            # This is where you would call your main lcl_radar function
            get_lcl_radar_loop(
                available_image_dictionary,
                box_variables,
                root,
                CHROME_DRIVER_PATH,
                CHROMIUM_BIN,
                radar_identifier,
                lcl_radar_zoom_clicks,
                auto_advance_frames
            )
        finally:
            #print("[SCHEDULER] 'lcl_radar' task finished.")
            TASK_IN_PROGRESS = False
    threading.Thread(target=task_wrapper, daemon=True).start()

def run_observations_task():
    def task_wrapper():
        global TASK_IN_PROGRESS
        try:
            # Build current target lists
            land_stations_to_scrape = [
                sid for is_buoy, sid in [
                    (aobs_buoy_signal, aobs_station_identifier),
                    (bobs_buoy_signal, bobs_station_identifier),
                    (cobs_buoy_signal, cobs_station_identifier),
                ] if not is_buoy and sid
            ]
            buoys_to_scrape = [
                code for is_buoy, code in [
                    (aobs_buoy_signal, aobs_buoy_code),
                    (bobs_buoy_signal, bobs_buoy_code),
                    (cobs_buoy_signal, cobs_buoy_code),
                ] if is_buoy and code
            ]

            # Submit work to the background loop and keep the futures
            futures = []
            if land_stations_to_scrape:
                f1 = asyncio.run_coroutine_threadsafe(
                    scrape_land_station_data_async(land_stations_to_scrape, background_loop, data_update_queue),
                    background_loop
                )
                futures.append(f1)
            if buoys_to_scrape:
                f2 = asyncio.run_coroutine_threadsafe(
                    get_buoy_data_async(buoys_to_scrape, background_loop, data_update_queue),
                    background_loop
                )
                futures.append(f2)

            # If nothing to do, release the gate immediately
            if not futures:
                return
            # Otherwise, wait for both futures to complete *in this worker thread*
            for fut in futures:
                try:
                    fut.result()  # propagate exceptions if any
                except Exception as e:
                    print(f"[OBS TASK] background future error: {e}")

        finally:
            TASK_IN_PROGRESS = False

    threading.Thread(target=task_wrapper, name="obs-task", daemon=True).start()


def run_sfc_plots_task():
    def task_wrapper():
        global TASK_IN_PROGRESS
        try:
            fetch_and_process_sfc_plots(
                available_image_dictionary,
                station_plot_lat,
                station_plot_lon,
                zoom_plot,
                CHROME_DRIVER_PATH,
                CHROMIUM_BIN
            )
        finally:
            #print("[SCHEDULER] 'sfc_plots' task finished.")
            TASK_IN_PROGRESS = False
    threading.Thread(target=task_wrapper, daemon=True).start()

def run_reg_sat_task():
    def task_wrapper():
        global TASK_IN_PROGRESS
        try:
            module_fetch_and_process_reg_sat_loop(
                available_image_dictionary,
                reg_sat_frames,
                box_variables,
                CHROME_DRIVER_PATH,
                CHROMIUM_BIN,
                reg_sat_choice_variables
            )
        finally:
            #print("[SCHEDULER] 'reg_sat' task finished.")
            TASK_IN_PROGRESS = False
    threading.Thread(target=task_wrapper, daemon=True).start()

# Swipe functionality for left swipe
def on_left_swipe(event):
    # Add last_displayed_index to globals used
    global current_frame_index, timer_override, refresh_flag, extremes_flag, lcl_radar_animation_id, reg_sat_animation_id, last_displayed_index

    if not refresh_flag and not extremes_flag:
        timer_override = True
        # num_frames is global now

        # Cancel animations... (keep this part)
        if lcl_radar_animation_id:
            root.after_cancel(lcl_radar_animation_id)
            lcl_radar_animation_id = None
        if reg_sat_animation_id:
            root.after_cancel(reg_sat_animation_id)
            reg_sat_animation_id = None

        # --- Calculate next frame index based on LAST DISPLAYED index ---
        if last_displayed_index == -1: # Handle initialization or error case
            current_target_index = 0
        else:
            current_target_index = (last_displayed_index + 1) % num_frames

        # Find the next *enabled* frame starting from the target index
        next_valid_index = current_target_index
        count = 0 # Safety break for infinite loop if all frames disabled
        while not box_variables[next_valid_index] and count < num_frames:
            next_valid_index = (next_valid_index + 1) % num_frames
            count += 1

        if count == num_frames and not box_variables[next_valid_index]:
            print("[WARN] No enabled frames to swipe to.")
            return # Or display a message / stay put

        # Set the global index and show the image
        current_frame_index = next_valid_index
        #print(f"[DEBUG] Left Swipe: last_displayed={last_displayed_index}, setting current_frame_index={current_frame_index}")
        show_image_in_display_frame(image_keys[current_frame_index])

# --- Modify on_right_swipe ---
def on_right_swipe(event):
    # Add last_displayed_index to globals used
    global current_frame_index, timer_override, refresh_flag, extremes_flag, lcl_radar_animation_id, reg_sat_animation_id, last_displayed_index

    if not refresh_flag and not extremes_flag:
        timer_override = True
        # num_frames is global now

        # Cancel animations... (keep this part)
        if lcl_radar_animation_id:
            root.after_cancel(lcl_radar_animation_id)
            lcl_radar_animation_id = None
        if reg_sat_animation_id:
            root.after_cancel(reg_sat_animation_id)
            reg_sat_animation_id = None

        # --- Calculate previous frame index based on LAST DISPLAYED index ---
        if last_displayed_index == -1: # Handle initialization or error case
             # Start from the end if swiping right initially
             current_target_index = num_frames - 1
        else:
             # Need '+ num_frames' to handle potential negative before modulo
             current_target_index = (last_displayed_index - 1 + num_frames) % num_frames

        # Find the previous *enabled* frame starting from the target index
        prev_valid_index = current_target_index
        count = 0 # Safety break
        while not box_variables[prev_valid_index] and count < num_frames:
            prev_valid_index = (prev_valid_index - 1 + num_frames) % num_frames
            count += 1

        if count == num_frames and not box_variables[prev_valid_index]:
            print("[WARN] No enabled frames to swipe to.")
            return # Or display a message / stay put

        # Set the global index and show the image
        current_frame_index = prev_valid_index
        #print(f"[DEBUG] Right Swipe: last_displayed={last_displayed_index}, setting current_frame_index={current_frame_index}")
        show_image_in_display_frame(image_keys[current_frame_index])

# --- Modify show_image_in_display_frame with diagnostics ---
def show_image_in_display_frame(image_key):
    # Add last_displayed_index to globals used
    global available_image_dictionary, display_image_frame, display_label, timer_override, last_displayed_index, lcl_radar_updated_flag
    global DISPLAY_FRAME_RESET_IN_PROGRESS
    
    if DISPLAY_FRAME_RESET_IN_PROGRESS:
        print("[INFO] Display frame is resetting — skipping image display.")
        return
    
    # --- DIAGNOSTIC 1: Function entry ---
    #print(f"[DIAG] show_image_in_display_frame called with key: {image_key}")

    # Find the index corresponding to the image_key being displayed
    try:
        index_to_display = image_keys.index(image_key)
        # --- DIAGNOSTIC 2: Index found ---
        #print(f"[DIAG] Index found: {index_to_display}")
    except ValueError:
        print(f"[ERROR] Image key '{image_key}' not found in image_keys list.")
        return # Exit if key is invalid

    # --- DIAGNOSTIC 3: Check against available_image_dictionary ---
    #print(f"[DIAG] Checking if key '{image_key}' is in available_image_dictionary...")
    if image_key not in available_image_dictionary:
        
        # Also maybe print the keys that ARE available for comparison:
        # print(f"[DIAG] Available keys: {list(available_image_dictionary.keys())}")
        return # Exit if image data not loaded

    #print(f"[DIAG] Key '{image_key}' found in dictionary.")

    # Clear existing widgets...
    for widget in display_image_frame.winfo_children():
        widget.grid_forget()
    #print("[DIAG] Cleared widgets in display_image_frame.")

    # Handle loops...
    if image_key == "lcl_radar_loop_img":
        if image_key in available_image_dictionary and len(available_image_dictionary[image_key]) >= 3:
            timer_override = False
            run_lcl_radar_loop_animation()
            last_displayed_index = index_to_display
        return
        
    if image_key == "reg_sat_loop_img":
        if image_key not in available_image_dictionary or not available_image_dictionary[image_key]:
            #print("[INFO] Skipping reg_sat — not in dictionary or empty.")
            return
        timer_override = False
        run_reg_sat_loop_animation()
        last_displayed_index = index_to_display
        return  # ✅ Make sure you exit!

    # Handle static images...
    try:
        from PIL import Image, ImageTk  # (top-level import is fine too)

        img_to_display, padx, pady = available_image_dictionary[image_key]

        if not display_label or not display_label.winfo_exists():
            print("[ERROR] display_label does not exist or is invalid!")
            return

        display_label.grid(row=0, column=0, padx=padx, pady=pady, sticky="se")

        # 🔎 Debug: confirm old image is being released
        if getattr(display_label, 'image', None):
            #print("[DEBUG] Releasing old image:", display_label.image)
            display_label.image = None

        if isinstance(img_to_display, Image.Image):   # PIL -> Tk
            photo = ImageTk.PhotoImage(img_to_display)
        else:                                         # already a PhotoImage
            photo = img_to_display

        display_label.configure(image=photo)
        display_label.image = photo
        #display_label.lift()
        transparent_frame.lift()

        last_displayed_index = index_to_display

    except Exception as e:
        print(f"[ERROR] An error occurred during static image display for key '{image_key}': {e}")
        import traceback; traceback.print_exc()

def auto_advance_frames():
    global current_frame_index, auto_advance_timer

    if auto_advance_timer is not None:
        root.after_cancel(auto_advance_timer)
        auto_advance_timer = None

    # Try to find the first valid frame to display
    attempts = 0
    shown = False

    while attempts < num_frames:
        idx = current_frame_index
        current_key = image_keys[idx]

        if box_variables[idx]:
            # Special case: lcl radar not ready
            if current_key == "lcl_radar_loop_img":
                if len(available_image_dictionary.get(current_key, [])) >= 3:
                    show_image_in_display_frame(current_key)
                    shown = True
                    break
                else:
                    pass
                    #print("[INFO] Skipping lcl radar in auto_advance — not ready.")
            # Special case: reg sat
            elif current_key == "reg_sat_loop_img":
                if len(available_image_dictionary.get(current_key, [])) >= 3:
                    show_image_in_display_frame(current_key)
                    shown = True
                    break
                else:
                    pass
                    #print("[INFO] Skipping reg sat in auto_advance — not ready.")

            # Normal case: static image
            else:
                show_image_in_display_frame(current_key)
                shown = True
                break

        # Try next
        current_frame_index = (current_frame_index + 1) % num_frames
        attempts += 1

    if not shown:
        print("[WARN] No valid frames to display — display will not change this cycle.")

    # Advance to the next frame for the *next* call
    current_frame_index = (current_frame_index + 1) % num_frames

    auto_advance_delay = 22000
    auto_advance_timer = root.after(auto_advance_delay, auto_advance_frames)

gold = 30.75
yellow = 30.35
gainsboro = 29.65
darkgrey = 29.25

ax.axhline(gold, color='gold', lw=81, alpha=.5)
ax.axhline(yellow, color='yellow', lw=49, alpha=.2)
ax.axhline(gainsboro, color='gainsboro', lw=49, alpha=.5)    
ax.axhline(darkgrey, color='darkgrey', lw=81, alpha=.5)

# Lines on minor ticks
for t in np.arange(29, 31, 0.05):
    ax.axhline(t, color='black', lw=.5, alpha=.2)
for u in np.arange(29, 31, 0.25):
    ax.axhline(u, color='black', lw=.7)

ax.tick_params(axis='x', direction='inout', length=5, width=1, color='black')
# Remove y-axis ticks without affecting the grid lines
ax.tick_params(axis='y', which='both', length=0)

plt.grid(True, color='.01')  # Draws default horiz and vert grid lines
#ax.yaxis.set_minor_locator(AutoMinorLocator(5))
#ax.yaxis.set_major_formatter(FormatStrFormatter('%2.2f'))

# Add annotation for day of the week - this defines it
day_label = ax.annotate('', xy=(0, 0), xycoords='data', ha='center', va='center',
                         fontsize=10, fontstyle='italic', color='blue')

# Set major and minor ticks format for midnight label and other vertical lines
ax.xaxis.set(
    major_locator=mdates.HourLocator(byhour=[0, 4, 8, 12, 16, 20]),
    major_formatter=mdates.DateFormatter('%-I%P'),
    minor_locator=mdates.HourLocator(interval=1),
    minor_formatter=ticker.FuncFormatter(lambda x, pos: '\n%a,%-m/%-d' if (isinstance(x, datetime) and x.hour == 0) else '')
)

ax.xaxis.set(
    minor_locator=mdates.DayLocator(),
    minor_formatter=mdates.DateFormatter("\n%a,%-m/%-d"),
)

# This line seems responsible for vertical lines
ax.grid(which='major', axis='both', linestyle='-', linewidth=1, color='black', alpha=1, zorder=10)

# Disable removing overlapping locations
ax.xaxis.remove_overlapping_locs = False

# Copying this over from daysleanbaro2-5-24. Not sure it's necessary
# This gets midnight of the current day, then figures the x value for 12 pm
now = datetime.now()
date_time = pd.to_datetime(now.strftime("%m/%d/%Y, %H:%M:%S"))
midnight = datetime.combine(date_time.date(), datetime.min.time())
x_value_12pm = mdates.date2num(midnight.replace(hour=12))

y_value_day_label = 30.92

# Add annotation for day of the week - this defines it
day_label = ax.annotate('', xy=(0,0), xycoords='data', ha='center', va='center',
                         fontsize=10, fontstyle='italic', color='blue')

# Set axis limits and labels
now = datetime.now()
time_delta = timedelta(minutes=3600)
start_time = now - time_delta

ax.set_xlim(start_time, now)
ax.set_ylim(29, 31)

ax.set_yticklabels([])

# # Create empty xs and ys arrays
# xs = []
# ys = []

# Create a line plot
line, = ax.plot([], [], 'r-')

# Get I2C bus
bus = smbus.SMBus(1)

yesterday_annotation = None
before_yesterday_annotation = None
today_annotation_flag = False
today_inHg_annotation_flag = False
#_day_3050_annotation = None

# Initialize a dictionary to keep track of annotations
annotations_created = {
    "before_yesterday": False,
    "bday_3050": False,
    "bday_3000": False,
    "bday_2950": False
}

def setup_transparent_frame():
    """
    (Corrected & Complete) Creates the main UI widgets ONCE using the
    pre-existing global StringVar objects. This is safe to copy and paste.
    """
    # Use the globally defined variables
    global persistent_widgets, timestamp_text
    global left_combined_text, middle_combined_text, right_combined_text

    transparent_frame.grid(row=0, column=0, sticky="nw")
    transparent_frame.lift()

    # --- Create Static Labels (Logo and Timestamp) ---
    logo_font = font.Font(family="Helvetica", size=16, weight="bold")
    logo_label = tk.Label(transparent_frame, text="The\nWeather\nObserver", fg="black", bg=tk_background_color, font=logo_font, anchor="w", justify="left")
    logo_label.grid(row=0, column=0, padx=10, pady=5, sticky='w')

    time_stamp_font = font.Font(family="Helvetica", size=8, weight="normal", slant="italic")
    timestamp_label = tk.Label(transparent_frame, textvariable=timestamp_text, fg="black", bg=tk_background_color, font=time_stamp_font, anchor="w", justify="left")
    timestamp_label.grid(row=0, column=0, padx=120, pady=(17, 5), sticky='w')

    # --- Create Buttons with their permanent properties ---
    # The font, width, and command will be set in the update function.
    left_button = tk.Button(transparent_frame, textvariable=left_combined_text, fg="black", bg=tk_background_color, anchor="w", justify="left", relief=tk.RAISED, bd=1, highlightthickness=0)
    left_button.grid(row=0, column=0, padx=200, pady=(5, 10), sticky='w')

    middle_button = tk.Button(transparent_frame, textvariable=middle_combined_text, fg="black", bg=tk_background_color, anchor="w", justify="left", relief=tk.RAISED, bd=1, highlightthickness=0)
    middle_button.grid(row=0, column=0, padx=475, pady=(5, 10), sticky='w')

    right_button = tk.Button(transparent_frame, textvariable=right_combined_text, fg="black", bg=tk_background_color, anchor="w", justify="left", relief=tk.RAISED, bd=1, highlightthickness=0)
    right_button.grid(row=0, column=0, padx=750, pady=(5, 10), sticky='w')

    # --- Store widgets and the timestamp StringVar for access in the update function ---
    persistent_widgets = {
        "timestamp_text": timestamp_text, # Storing the StringVar
        "left_button": left_button,
        "middle_button": middle_button,
        "right_button": right_button
    }
    
def update_transparent_frame_data():
    """
    (Replaces show_transparent_frame)
    Updates the text and commands of the persistent widgets.
    This is lightweight and does NOT create new widgets.
    """
    # This function needs to read the data and flags to work correctly.
    global alternative_town_1, alternative_town_2, alternative_town_3
    global aobs_only_click_flag, bobs_only_click_flag, cobs_only_click_flag, extremes_flag
    global awind, awtemp, atemp, bwind, bwtemp, btemp, cwind, cwtemp, ctemp
    global aobs_buoy_signal, bobs_buoy_signal, cobs_buoy_signal
    global left_combined_text, middle_combined_text, right_combined_text
    global persistent_widgets # We need this to access the buttons

    # --- UI and Flag Handling (This logic is unchanged) ---
    if not aobs_only_click_flag and not bobs_only_click_flag and not cobs_only_click_flag and not extremes_flag:
        frame1.grid_forget()
    if not extremes_flag:
        show_function_button_frame()

    # Make sure the frame is visible
    transparent_frame.grid(row=0, column=0, sticky="nw")
    #transparent_frame.lift()

    # --- Update Timestamp ---
    now = datetime.now()
    hourmin_str = now.strftime("%-I:%M %P")
    timestamp_str = f'Version {VERSION}\nLast Updated\n{now.strftime("%A")}\n{hourmin_str}'
    # We access the timestamp's StringVar via the persistent_widgets dictionary
    persistent_widgets["timestamp_text"].set(timestamp_str)

    # --- Define FULL on_click handlers ---
    # These are the complete functions you need.
    def aobs_buoy_on_click():
        global aobs_only_click_flag, aobs_buoy_signal
        

        forget_all_frames(); baro_frame.grid_forget(); transparent_frame.grid_forget()
        aobs_only_click_flag = True; aobs_buoy_signal = False; land_or_buoy()

    def aobs_on_click():
        global aobs_only_click_flag, aobs_buoy_signal
        forget_all_frames(); baro_frame.grid_forget(); transparent_frame.grid_forget()
        aobs_only_click_flag = True; aobs_buoy_signal = False; land_or_buoy()

    def bobs_buoy_on_click():
        global bobs_only_click_flag, bobs_buoy_signal
        forget_all_frames(); baro_frame.grid_forget(); transparent_frame.grid_forget()
        bobs_only_click_flag = True; bobs_buoy_signal = False; bobs_land_or_buoy()

    def bobs_on_click():
        global bobs_only_click_flag, bobs_buoy_signal
        forget_all_frames(); baro_frame.grid_forget(); transparent_frame.grid_forget()
        bobs_only_click_flag = True; bobs_buoy_signal = False; bobs_land_or_buoy()

    def cobs_buoy_on_click():
        global cobs_only_click_flag, cobs_buoy_signal
        forget_all_frames(); baro_frame.grid_forget(); transparent_frame.grid_forget()
        cobs_only_click_flag = True; cobs_buoy_signal = False; cobs_land_or_buoy()

    def cobs_on_click():
        global cobs_only_click_flag, cobs_buoy_signal
        forget_all_frames(); baro_frame.grid_forget(); transparent_frame.grid_forget()
        cobs_only_click_flag = True; cobs_buoy_signal = False; cobs_land_or_buoy()

    # --- Update Left Button ---
    left_button = persistent_widgets["left_button"]
    if aobs_buoy_signal:
        left_combined_text.set(f"Buoy: {alternative_town_1.upper()}\n{atemp}\n{awtemp}\nWind: {awind}")
        left_button.config(font=buoy_font, width=29, command=aobs_buoy_on_click)
    else:
        left_combined_text.set(f"{alternative_town_1}\nTemp: {atemp}\nWind: {awind}")
        left_button.config(font=obs_font, width=24, command=aobs_on_click)

    # --- Update Middle Button ---
    middle_button = persistent_widgets["middle_button"]
    if bobs_buoy_signal:
        middle_combined_text.set(f"Buoy: {alternative_town_2.upper()}\n{btemp}\n{bwtemp}\nWind: {bwind}")
        middle_button.config(font=buoy_font, width=29, command=bobs_buoy_on_click)
    else:
        middle_combined_text.set(f"{alternative_town_2}\nTemp: {btemp}\nWind: {bwind}")
        middle_button.config(font=obs_font, width=24, command=bobs_on_click)

    # --- Update Right Button ---
    right_button = persistent_widgets["right_button"]
    if cobs_buoy_signal:
        right_combined_text.set(f"Buoy: {alternative_town_3.upper()}\n{ctemp}\n{cwtemp}\nWind: {cwind}")
        right_button.config(font=buoy_font, width=29, command=cobs_buoy_on_click)
    else:
        right_combined_text.set(f"{alternative_town_3}\nTemp: {ctemp}\nWind: {cwind}")
        right_button.config(font=obs_font, width=24, command=cobs_on_click)

# This function is called periodically from FuncAnimation
#@profile
def animate(i):
    try:
        global xs, ys, line, yesterday_annotation, before_yesterday_annotation, threshold_x_value
        global inHg_correction_factor, refresh_flag, day_label
        global today_annotation_flag, today_inHg_annotation_flag, aobs_site
        
        # Set a threshold x value below which the before_yesterday_annotation should be removed
        threshold_left_x_value = mdates.date2num(datetime.now() - timedelta(days=2.4))

        # Set a threshold x value beyond which the x_value_12pm annotation should not be added on the right
        threshold_right_x_value = mdates.date2num(datetime.now() - timedelta(days=.125))
        
        # HP203B address, 0x77(118)
        # Send OSR and channel setting command, 0x44(68)
        bus.write_byte(0x77, 0x44 | 0x00)

        time.sleep(0.5)

        # HP203B address, 0x77(118)
        # Read data back from 0x10(16), 6 bytes
        # cTemp MSB, cTemp CSB, cTemp LSB, pressure MSB, pressure CSB, pressure LSB
        data = bus.read_i2c_block_data(0x77, 0x10, 6)

        # Convert the data to 20-bits
        # Correct for 160 feet above sea level
        # cpressure is pressure corrected for elevation
        cTemp = (((data[0] & 0x0F) * 65536) + (data[1] * 256) + data[2]) / 100.00
        fTemp = (cTemp * 1.8) + 32
        pressure = (((data[3] & 0x0F) * 65536) + (data[4] * 256) + data[5]) / 100.00
        cpressure = (pressure * 1.0058)
        inHg = (cpressure * .029529)
        
        if i == 0:        
            # calculate a correction factor only when i == 0
            inHg_correction_factor = (baro_input / inHg)
        # apply correct factor to each reading from sensor
        inHg = round(inHg * inHg_correction_factor, 3)
        #print("line 6682. inHg: ", inHg)
        # Define a flag to track if day names have been reassigned
        midnight_reassigned = False
       
        # Initialize the flag outside of the loop
        previous_day_annotations_created = False
       
        # Get time stamp
        now = datetime.now()
        date_time = pd.to_datetime(now.strftime("%m/%d/%Y, %H:%M:%S"))
        
        yesterday_name = now - timedelta(days=1)
        yesterday_name = yesterday_name.strftime('%A')
        
        before_yesterday_name = now - timedelta(days=2)
        before_yesterday_name = before_yesterday_name.strftime('%A')

        # Check if it's within the 5-minute window around midnight to reassign day names
        if 0 <= now.hour < 1 and 0 <= now.minute <= 5 and not midnight_reassigned:
            # Update day labels at midnight
            previous_annotation = datetime.now().strftime('%A')
            
            # not sure the following line is needed
            _day_label_annotation =  datetime.now().strftime('%A')
          
            yesterday_name = date_time - timedelta(days=1)
            yesterday_name = yesterday_name.strftime('%A')

            before_yesterday_name = date_time - timedelta(days=2)
            before_yesterday_name = before_yesterday_name.strftime('%A')

            # Set the flag to True to indicate that reassignment has occurred
            midnight_reassigned = True
            
            today_annotation_flag = False
            today_inHg_annotation_flag = False 

        # Build xs and ys arrays
        xs.append(date_time)
        ys.append(inHg)

        xs = xs[-1200:]
        ys = ys[-1200:]

        # Update day of the week label
        day_label.set_text(date_time.strftime('%A'))

        # This gets midnight of the current day, then figures the x value for 12 pm
        midnight = datetime.combine(date_time.date(), datetime.min.time())
        x_value_12pm = mdates.date2num(midnight.replace(hour=12))

        # noon_time = x_value_12pm
        x_value_yesterday = x_value_12pm - 1
        x_value_day_before = x_value_12pm - 2
        y_value_day_label = 30.92

        # Update day label position based on the x value for 12 pm
        previous_annotation = getattr(ax, "_day_label_annotation", None)
        
        if x_value_12pm < threshold_right_x_value and today_annotation_flag == False:  
            
            ax._day_label_annotation = ax.annotate(date_time.strftime('%A'), (x_value_12pm, y_value_day_label),
                                        ha='center', fontsize=10, fontstyle='italic', fontfamily='DejaVu Serif', fontweight='bold')
            
            today_annotation_flag = True
            
        if x_value_12pm < threshold_right_x_value + .08 and today_inHg_annotation_flag == False:
            # Your existing code with translucent box properties as arguments
            ax._day_3050_annotation = ax.annotate('30.50', (x_value_12pm - .001, 30.475),
                                                  ha='center', fontsize=10, fontfamily='DejaVu Serif')
                                                  

            # Your existing code with translucent box properties as arguments
            ax._day_3000_annotation = ax.annotate('30.00', (x_value_12pm - .001, 29.975),
                                                  ha='center', fontsize=10, fontfamily='DejaVu Serif')
                                                  

            # Your existing code with translucent box properties as arguments
            ax._day_2950_annotation = ax.annotate('29.50', (x_value_12pm - .001, 29.475),
                                                  ha='center', fontsize=10, fontfamily='DejaVu Serif')

            today_inHg_annotation_flag = True 

        # Annotate 'yesterday' at the specified coordinates if not removed
        if yesterday_annotation is None and x_value_yesterday < threshold_right_x_value + 0.2:
            yesterday_annotation = ax.annotate(f'{yesterday_name}', xy=(x_value_yesterday, y_value_day_label), xytext=(0, 0),
                        textcoords='offset points', ha='center',
                        fontsize=10, fontstyle='italic', fontfamily='DejaVu Serif', fontweight='bold', color='black')

            # Your existing code with translucent box properties as arguments
            ax._day_3050_annotation = ax.annotate('30.50', (x_value_yesterday - 0.001, 30.475),
                                                  ha='center', fontsize=10, fontfamily='DejaVu Serif')
                                                  

            # Your existing code with translucent box properties as arguments
            ax._day_3000_annotation = ax.annotate('30.00', (x_value_yesterday - 0.001, 29.975),
                                                  ha='center', fontsize=10, fontfamily='DejaVu Serif')
                                                  

            # Your existing code with translucent box properties as arguments
            ax._day_2950_annotation = ax.annotate('29.50', (x_value_yesterday - 0.001, 29.475),
                                                  ha='center', fontsize=10, fontfamily='DejaVu Serif')
                                                  


        # Check if x value is below the threshold, and remove before_yesterday_annotation if needed
        if before_yesterday_annotation and x_value_day_before < threshold_left_x_value:
            # If the before_yesterday label has already been created, skip updating it
            before_yesterday_annotation.remove()
            before_yesterday_annotation = None  # Set to None to indicate it has been removed 
            annotations_created["before_yesterday"] = False  # Reset the flag

        # Annotate 'day before yesterday' at the specified coordinates if not removed
        # Increase what's added to the threshold_left_x_value to make day before label disappear sooner
        #if not annotations_created["before_yesterday"] and x_value_day_before > threshold_left_x_value + 0.027:
        if not annotations_created["before_yesterday"] and x_value_day_before > threshold_left_x_value + 0.044:
            if before_yesterday_annotation is None:  # Ensure it's not already created
                before_yesterday_annotation = ax.annotate(
                    f'{before_yesterday_name}', xy=(x_value_day_before, y_value_day_label), xytext=(0, 0),
                    textcoords='offset points', ha='center',
                    fontsize=10, fontstyle='italic', fontfamily='DejaVu Serif', fontweight='bold', color='black')
                annotations_created["before_yesterday"] = True  # Mark as created
                
        # Check if x value is within the range to display other annotations
        if x_value_day_before > threshold_left_x_value - 0.044:
            # Check if the annotations have not been created yet
            if not annotations_created["bday_3050"]:
                ax._bday_3050_annotation = ax.annotate('30.50', (x_value_day_before - 0.001, 30.475),
                                                        ha='center', fontsize=10, fontfamily='DejaVu Serif')
                annotations_created["bday_3050"] = True  # Set the flag to True to indicate that the annotation has been created
                
            if not annotations_created["bday_3000"]:
                ax._bday_3000_annotation = ax.annotate('30.00', (x_value_day_before - 0.001, 29.975),
                                                        ha='center', fontsize=10, fontfamily='DejaVu Serif')
                annotations_created["bday_3000"] = True
                
            if not annotations_created["bday_2950"]:
                ax._bday_2950_annotation = ax.annotate('29.50', (x_value_day_before - 0.001, 29.475),
                                                        ha='center', fontsize=10, fontfamily='DejaVu Serif')
                annotations_created["bday_2950"] = True
                                
        else:            
            pass

        # Update the line data here so the line plots on top of labels
        line.set_data(xs, ys)

        ax.set_xlim(datetime.now() - timedelta(minutes=3600), datetime.now())

        print(i,",", now)
        
        if i == 1:            
            # Add label to the figure rather than the axes, ensuring it's outside the plotting area
            fig.text(0.5, 0.03, f"Barometric Pressure - {aobs_site}",
                     fontsize=12, ha='center', va='top', fontweight='bold', zorder=10)
        
        #fig.savefig("baro_trace.png")
        fig.savefig("baro_trace.png", bbox_inches="tight", pad_inches=0.5)

        # changed if condition when making obs buttons
        if refresh_flag == False and aobs_only_click_flag == False and bobs_only_click_flag == False and cobs_only_click_flag == False:
            #print("line 7070. checking flags deciding whether to go to show_transparent_frame.", refresh_flag)
            update_transparent_frame_data()
        
        else:
            #print("line 7174. in animate function. stuck here? test for scraped frame widgets, if none re-establish.")
            return #goes back to where the animate function was called from? cause of blank blue?
        
    except Exception as e:
        print("Problems with Display Baro Trace. line 7178", e)

# Create a function to start the animation
#@profile
def start_animation(): # code goes here once when the user starts barograph

    frame1.grid_forget()
    baro_frame.grid_forget()
    clear_frame(frame1)

    setup_transparent_frame()

    root.after(10000, return_to_image_cycle)
    
    ani = animation.FuncAnimation(fig, animate, interval=180000, save_count=1500)
    canvas.draw()

async def scrape_land_station_data_async(list_of_station_codes, loop, obs_data_queue):
    """
    (Thread-Safe) Scrapes land station data in the background and puts the
    results into a thread-safe queue for the main GUI thread to process.
    """
    if not list_of_station_codes:
        return

    #print(f"--- Background task started: Scraping {len(list_of_station_codes)} land station(s) ---")
    
    def blocking_scraper():
        # This blocking function remains the same, but it will return results
        # to the async wrapper, which then puts them in the queue.
        results = {}
        for code in list_of_station_codes:
            results[code] = ("N/A", "N/A")

        driver = None
        try:
            if not CHROME_DRIVER_PATH:
                print("ERROR: ChromeDriver path is not set. Cannot start browser.")
                return
            options = Options()
            options.add_argument('--headless')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            service = Service(CHROME_DRIVER_PATH)
            driver = webdriver.Chrome(service=service, options=options)
            try:
                pid = driver.service.process.pid
                #print(f"[OBS] DRIVER_START pid={pid}")
            except Exception:
                pass
                #print("[OBS] DRIVER_START pid=?")

            driver.set_page_load_timeout(20)
            driver.implicitly_wait(10)
            #print("LINE 7275 ASYNC SCRAPE OF LAND STATION DATA. DRIVER STARTED *************************************")
            for station_code in list_of_station_codes:
                temp, wind = "N/A", "N/A"
                try:
                    station_url = (
                        "https://www.weather.gov/wrh/timeseries?"
                        f"site={station_code}&hours=6&units=english&chart=off"
                        "&headers=none&obs=tabular&hourly=false&pview=standard&font=12"
                    )
                    driver.get(station_url)
                    table = driver.find_element(By.ID, "OBS_DATA")
                    headers = table.find_elements(By.CSS_SELECTOR, "thead tr#HEADER th")
                    col_indices = {h.get_attribute("id"): i for i, h in enumerate(headers)}
                    idx_temp = col_indices.get("temperature")
                    idx_winddir = col_indices.get("wind_dir")
                    idx_wind = col_indices.get("wind_speedgust")
                    first_valid_row_tds = None
                    rows = table.find_elements(By.CSS_SELECTOR, "tbody tr")
                    for r in rows[:3]:
                        tds = r.find_elements(By.TAG_NAME, "td")
                        if idx_temp is not None and len(tds) > idx_temp and tds[idx_temp].text.strip():
                            first_valid_row_tds = tds
                            break
                    if first_valid_row_tds:
                        tds = first_valid_row_tds
                        if idx_temp is not None:
                            temp_text = tds[idx_temp].text.strip()
                            if temp_text: temp = temp_text + chr(176)
                        if idx_winddir is not None and idx_wind is not None:
                            direction_text = tds[idx_winddir].text.strip()
                            wind_cell_text = tds[idx_wind].text.strip()
                            if direction_text and wind_cell_text:
                                wind_parts = [direction_text]
                                if "G" in wind_cell_text:
                                    speed_part, gust_part = wind_cell_text.split("G", 1)
                                    wind_parts.extend([f"at {speed_part} mph", f"G{gust_part}"])
                                else:
                                    wind_parts.append(f"at {wind_cell_text} mph")
                                wind = " ".join(wind_parts)
                    results[station_code] = (temp, wind)
                except Exception:
                    continue
        finally:
            if driver:
                pid = None
                try:
                    pid = driver.service.process.pid
                except Exception:
                    pass
                try:
                    driver.quit()
                    #print(f"[OBS] DRIVER_QUIT pid={pid} ok")
                except Exception as qe:
                    pass
                    #print(f"[OBS] DRIVER_QUIT pid={pid} raised {type(qe).__name__}")
                if pid is not None:
                    try:
                        os.kill(pid, 0)
                        #print(f"[OBS] DRIVER_KILL pid={pid} SIGKILL")
                        os.kill(pid, signal.SIGKILL)
                    except OSError:
                        pass
                    except Exception as ke:
                        pass
                        #print(f"[OBS] DRIVER_KILL pid={pid} error {type(ke).__name__}")
        
        return results

    # Run the blocking scraper in the background
    result_dict = await loop.run_in_executor(None, blocking_scraper)
    
    # Instead of returning the result, put it into the thread-safe queue
    if result_dict:
        obs_data_queue.put(result_dict)


def scrape_land_station_data(list_of_station_codes):
    """
    Scrapes temperature and wind data for a given list of land station codes
    using a single, shared browser instance for efficiency.
    """
    if not list_of_station_codes:
        return {}

    results = {}
    for code in list_of_station_codes:
        results[code] = ("N/A", "N/A")

    driver = None
    try:
        # Define your options for this specific function
        options = Options()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')

        # Point to the driver path determined at startup
        service = Service(CHROME_DRIVER_PATH)

        # Initialize the driver with both objects
        driver = webdriver.Chrome(service=service, options=options)
        #print("LINE 7356 SYNC SCRAPE OF LAND STATION DATA. DRIVER STARTED *************************************")
        # --- ADDED: Set timeouts to prevent the application from hanging ---
        driver.set_page_load_timeout(20) # Max time to wait for a page to load
        driver.implicitly_wait(10)       # Max time to wait for an element to appear
        # --- END OF ADDITION ---

        # --- Loop Through Stations and Scrape ---
        for station_code in list_of_station_codes:
            temp = "N/A"
            wind = "N/A"
            
            try:
                #print(f"  -> Scraping: {station_code}")
                station_url = (
                    "https://www.weather.gov/wrh/timeseries?"
                    f"site={station_code}&hours=6&units=english&chart=off"
                    "&headers=none&obs=tabular&hourly=false&pview=standard&font=12"
                )
                driver.get(station_url)

                table = driver.find_element(By.ID, "OBS_DATA")
                headers = table.find_elements(By.CSS_SELECTOR, "thead tr#HEADER th")
                col_indices = {h.get_attribute("id"): i for i, h in enumerate(headers)}
                
                idx_temp = col_indices.get("temperature")
                idx_winddir = col_indices.get("wind_dir")
                idx_wind = col_indices.get("wind_speedgust")

                first_valid_row_tds = None
                rows = table.find_elements(By.CSS_SELECTOR, "tbody tr")
                for r in rows[:3]:
                    tds = r.find_elements(By.TAG_NAME, "td")
                    if idx_temp is not None and len(tds) > idx_temp and tds[idx_temp].text.strip():
                        first_valid_row_tds = tds
                        break
                
                if first_valid_row_tds:
                    tds = first_valid_row_tds
                    if idx_temp is not None:
                        temp_text = tds[idx_temp].text.strip()
                        if temp_text: temp = temp_text + chr(176)

                    if idx_winddir is not None and idx_wind is not None:
                        direction_text = tds[idx_winddir].text.strip()
                        wind_cell_text = tds[idx_wind].text.strip()
                        if direction_text and wind_cell_text:
                            wind_parts = [direction_text]
                            if "G" in wind_cell_text:
                                speed_part, gust_part = wind_cell_text.split("G", 1)
                                wind_parts.extend([f"at {speed_part} mph", f"G{gust_part}"])
                            else:
                                wind_parts.append(f"at {wind_cell_text} mph")
                            wind = " ".join(wind_parts)
                
                results[station_code] = (temp, wind)
                #print(f"  -> Success for {station_code}: Temp={temp}, Wind='{wind}'")

            except Exception as e:
                print(f"  -> FAILED to scrape {station_code}: {e}")
                continue

    except Exception as e:
        print(f"A critical error occurred with the browser instance: {e}")
        return results

    finally:
        if driver:
            driver.quit()

    return results


def get_buoy_data(list_of_buoy_codes, is_async_call=False):
    """
    (Synchronous) Fetches and processes recent buoy data for a list of buoy codes.
    This is a blocking function, intended only for the program's initial startup.

    Args:
        list_of_buoy_codes (list): A list of buoy ID strings to fetch.
        is_async_call (bool): A flag to suppress logging when called from the async wrapper.
    """
    if not list_of_buoy_codes:
        return {}

    # This print statement will now ONLY run on the very first, direct synchronous call.
    if not is_async_call:
        print(f"--- Running SYNCHRONOUS buoy data fetch for: {list_of_buoy_codes} ---")
    
    results = {}

    def _parse_line(text_block, search_key):
        for line in text_block.strip().split('<br />'):
            if search_key in line:
                value_part = line.split(search_key)[1]
                return value_part.replace('</strong>', '').strip()
        return None

    for buoy_code in list_of_buoy_codes:
        temp, wtemp, wind = "Air Temp: N/A", "Water Temp: N/A", "Wind: N/A"
        rss_url = f"https://www.ndbc.noaa.gov/data/latest_obs/{buoy_code.lower()}.rss"
        try:
            response = requests.get(rss_url, timeout=15)
            response.raise_for_status()
            root = ElementTree.fromstring(response.content)
            description_element = root.find('.//channel/item/description')
            if description_element is None or not description_element.text:
                results[buoy_code] = (temp, wtemp, wind)
                continue
            
            description_text = description_element.text
            air_temp_raw = _parse_line(description_text, "Air Temperature:")
            if air_temp_raw:
                air_temp_val = air_temp_raw.split('&#176;F')[0]
                try: temp = f"Air Temp: {round(float(air_temp_val))}°"
                except (ValueError, TypeError): pass
            
            water_temp_raw = _parse_line(description_text, "Water Temperature:")
            if water_temp_raw:
                water_temp_val = water_temp_raw.split('&#176;F')[0]
                try: wtemp = f"Water Temp: {round(float(water_temp_val))}°"
                except (ValueError, TypeError): pass

            wind_dir_raw = _parse_line(description_text, "Wind Direction:")
            wind_speed_raw = _parse_line(description_text, "Wind Speed:")
            wind_gust_raw = _parse_line(description_text, "Wind Gust:")
            wd_cardinal, ws_mph, wg_mph = "Var.", None, None
            if wind_dir_raw: wd_cardinal = wind_dir_raw.split()[0]
            if wind_speed_raw:
                try:
                    speed_knots = float(wind_speed_raw.split()[0])
                    ws_mph = round(speed_knots * 1.15078)
                except (ValueError, TypeError, IndexError): pass
            if wind_gust_raw:
                try:
                    gust_knots = float(wind_gust_raw.split()[0])
                    wg_mph = round(gust_knots * 1.15078)
                except (ValueError, TypeError, IndexError): pass
            if ws_mph is not None:
                wind_parts = [wd_cardinal, f"at {ws_mph} mph"]
                if wg_mph is not None and wg_mph > 0:
                    wind_parts.append(f"G{wg_mph}")
                wind = " ".join(wind_parts)
            
            results[buoy_code] = (temp, wtemp, wind)

        except Exception as e:
            print(f"An error occurred in get_buoy_data for {buoy_code}: {e}")
            results[buoy_code] = (temp, wtemp, wind)
    
    return results

async def get_buoy_data_async(list_of_buoy_codes, loop, obs_data_queue):
    """
    (Thread-Safe) Fetches buoy data in the background and puts the
    results into a thread-safe queue for the main GUI thread to process.
    """
    if not list_of_buoy_codes:
        return
    
    print(f"--- Background task started: Fetching {len(list_of_buoy_codes)} buoy(s) ---")

    def blocking_fetcher():
        # This function now calls the synchronous version with a flag
        # to prevent it from printing the confusing log message.
        return get_buoy_data(list_of_buoy_codes, is_async_call=True)

    # Run the blocking fetcher in the background
    result_dict = await loop.run_in_executor(None, blocking_fetcher)

    # Instead of returning the result, put it into the thread-safe queue
    if result_dict:
        obs_data_queue.put(result_dict)

#@profile

# Code begins for nws lcl radar loop

def calc_reg_sat_padding(reg_sat_reg):
    if reg_sat_reg == 'taw':
        return (45, 12)
    elif reg_sat_reg == 'can':
        return (15, 52)
    else:
        return (150, 12)

# Function to fetch and process satellite frames
def fetch_and_process_reg_sat_loop():
    def threaded_fetch_and_process():
        global reg_sat_frames, last_reg_sat_update, reg_sat_reg, reg_sat_goes
        global available_image_dictionary, reg_sat_updated_flag

        current_time = datetime.now()
        base_url = "https://cdn.star.nesdis.noaa.gov/GOES{}/ABI/SECTOR/{}/GEOCOLOR/"
        num_images_to_scrape = 12

        try:
            # --- added: mirror LCL pattern; teardown old data at fetch start ---
            if 'full_reg_sat_teardown' in globals():
                full_reg_sat_teardown()
            reg_sat_updated_flag = False
            # --- end added ---

            # Get settings for the satellite and region
            reg_sat_goes, reg_sat_reg = get_reg_sat_settings()

            # Generate URLs to scrape
            urls_to_scrape = generate_reg_sat_urls(
                base_url.format(reg_sat_goes, reg_sat_reg),
                num_images_to_scrape,
                reg_sat_goes,
                reg_sat_reg
            )

            # Scrape and process images
            new_frames = scrape_and_store_reg_sat_images(urls_to_scrape, reg_sat_goes, reg_sat_reg)
            
            # Update the global frames only if new frames are successfully fetched
            if new_frames:
                reg_sat_frames = new_frames
                last_reg_sat_update = current_time

                if not callable(calc_reg_sat_padding):
                    print("[FATAL] 'calc_reg_sat_padding' was overwritten:", type(calc_reg_sat_padding))
                    return

                pad_x, pad_y = calc_reg_sat_padding(reg_sat_reg)
                available_image_dictionary['reg_sat_loop_img'] = [(frame, pad_x, pad_y) for frame in reg_sat_frames]
                reg_sat_updated_flag = True
            else:
                print("[DEBUG] line 8859. No new frames fetched. Keeping existing reg_sat_frames.")

        except Exception as e:
            print(f"[ERROR] Exception in fetch_and_process_reg_sat_loop: {e}")

    # Start the scraping process in a thread to keep the GUI responsive
    threading.Thread(target=threaded_fetch_and_process, daemon=True).start()
    
# Function to scrape and store frames in memory
def scrape_and_store_reg_sat_images(urls, reg_sat_goes, reg_sat_reg):
    frames = []

    try:
        # First, check if the paths were set at startup.
        if not (CHROMIUM_BIN and CHROME_DRIVER_PATH):
            print("ERROR: Chromium/ChromeDriver path not set. Cannot start browser.")
            return

        # Define your options for this specific function
        options = Options()
        options.binary_location = CHROMIUM_BIN
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        # Add any other specific options you need for this function...

        # Point to the driver path determined at startup
        service = Service(CHROME_DRIVER_PATH)

        # Initialize the driver with both objects
        driver = webdriver.Chrome(service=service, options=options)

    except Exception as e:
        print(f"Failed to initialize the driver in reg sat: {e}")
        return frames

    try:
        for url in reversed(urls):
            try:
                driver.get(url)
                if "404 Not Found" in driver.title:
                    print(f"No image found for URL in reg sat: {url}")
                    continue

                # Capture screenshot and process the image
                screenshot = driver.get_screenshot_as_png()
                screenshot = Image.open(BytesIO(screenshot))
                screenshot = trim_near_black_borders_reg_sat(screenshot)

                # Resize the image based on the region
                if reg_sat_reg == 'taw':
                    target_size = (858, 515)
                elif reg_sat_reg == 'can':
                    target_size = (900, 448)
                else:
                    target_size = (515, 515)

                screenshot = screenshot.resize(target_size, Image.LANCZOS)
                frames.append(screenshot)  # keep as PIL.Image
                # do NOT close here; we’re keeping the image for playback

            except Exception as e:
                print(f"Error processing image from URL {url} in reg sat: {e}")

    finally:
        driver.quit()

    #print(f"[DEBUG] Total frames scraped: {len(frames)}")
    return frames

# Function to trim black borders from an image
def trim_near_black_borders_reg_sat(img, threshold=30):
    try:
        grayscale_img = img.convert("L")
        binary_img = grayscale_img.point(lambda p: 255 if p > threshold else 0, '1')
        bbox = binary_img.getbbox()
        if bbox:
            return img.crop(bbox)
    except Exception as e:
        print(f"Error cropping the image in reg sat: {e}")
    return img

# Function to generate URLs for scraping
def generate_reg_sat_urls(base_url, num_images, reg_sat_goes, reg_sat_reg):
    urls = []
    current_time_utc = datetime.utcnow()

    for _ in range(num_images):
        if reg_sat_choice_variables[10] == 1 or reg_sat_choice_variables[13] == 1:
            time_offset = 20
            time_format = "%H%M"
            image_suffix = "500x500.jpg"
            valid_minutes = {0}
        elif reg_sat_choice_variables[11] == 1 or reg_sat_choice_variables[12] == 1:
            time_offset = 10
            time_format = "%H%M"
            image_suffix = "500x500.jpg"
            valid_minutes = {6}
        elif reg_sat_choice_variables[14] == 1:
            time_offset = 20
            time_format = "%H%M"
            image_suffix = "900x540.jpg"
            valid_minutes = {0}
        elif reg_sat_choice_variables[15] == 1:
            time_offset = 30
            time_format = "%H%M"
            image_suffix = "1125x560.jpg"
            valid_minutes = {0}
        else:
            time_offset = 10
            time_format = "%H%M"
            image_suffix = "600x600.jpg"
            valid_minutes = {6}

        current_time_utc -= timedelta(minutes=time_offset)
        while current_time_utc.minute % 10 not in valid_minutes:
            current_time_utc -= timedelta(minutes=1)

        year = current_time_utc.year
        day_of_year = current_time_utc.timetuple().tm_yday
        time_code = current_time_utc.strftime(time_format)

        url = f"{base_url}{year}{day_of_year:03d}{time_code}_GOES{reg_sat_goes}-ABI-{reg_sat_reg}-GEOCOLOR-{image_suffix}"
        urls.append(url)
        current_time_utc -= timedelta(minutes=5)

    return urls

# Function to determine satellite and region settings
def get_reg_sat_settings():
    selected_index = reg_sat_choice_variables.index(1)
    global reg_sat_goes, reg_sat_reg
    reg_sat_goes = 19  # Default value
    reg_sat_reg = 'unknown'  # Default value

    region_settings = [
        (18, 'pnw'), (18, 'psw'), (19, 'nr'), (19, 'sr'),
        (19, 'umv'), (19, 'smv'), (19, 'cgl'), (19, 'sp'),
        (19, 'ne'), (19, 'se'), (18, 'wus'), (19, 'eus'),
        (19, 'ga'), (19, 'car'), (19, 'taw'), (19, 'can')
    ]

    if 0 <= selected_index < len(region_settings):
        reg_sat_goes, reg_sat_reg = region_settings[selected_index]

    return reg_sat_goes, reg_sat_reg

# # Start with the national radar frame
current_frame_index = 0
timer_override = False

# Start the tkinter main loop
root.mainloop()
