import asyncio
import configparser
import json
import os
import re
import shutil
import subprocess
import threading

import requests


def ensure_network_manager_enabled_and_started():
    try:
        status = subprocess.check_output(
            ["systemctl", "is-active", "NetworkManager"],
            stderr=subprocess.STDOUT,
        ).decode("utf-8").strip()
        if status == "active":
            return
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass
    try:
        subprocess.check_call(["sudo", "systemctl", "enable", "NetworkManager"])
        subprocess.check_call(["sudo", "systemctl", "start", "NetworkManager"])
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"Failed to enable/start Network Manager: {e}")


def get_os_codename():
    try:
        with open("/etc/os-release") as f:
            for line in f:
                if line.startswith("VERSION_CODENAME="):
                    return line.strip().split("=")[1]
    except FileNotFoundError:
        pass
    return None


def detect_chromium_and_driver():
    chromium_bins = ("/usr/bin/chromium", "/usr/bin/chromium-browser")
    chromium_bin = next((p for p in chromium_bins if os.path.exists(p)), None)

    driver_path = "/usr/bin/chromedriver" if os.path.exists("/usr/bin/chromedriver") else shutil.which("chromedriver")

    if not chromium_bin or not driver_path:
        print(f"[DRIVER][FATAL] Missing binaries. chromium={chromium_bin}, chromedriver={driver_path}")
        return None, None

    try:
        browser_version = subprocess.check_output([chromium_bin, "--version"], text=True).strip()
        driver_version = subprocess.check_output([driver_path, "--version"], text=True).strip()
        browser_major = re.search(r"(?:Chromium|Chrome)\s+(\d+)\.", browser_version).group(1)
        driver_major = re.search(r"ChromeDriver\s+(\d+)\.", driver_version).group(1)
        print(f"[DRIVER] Chromium:     {browser_version}")
        print(f"[DRIVER] ChromeDriver: {driver_version}")
        if browser_major != driver_major:
            print(f"[DRIVER][WARN] Version mismatch: Chromium {browser_major} vs Driver {driver_major}.")
    except Exception as e:
        print(f"[DRIVER][WARN] Could not read versions: {e}")

    return chromium_bin, driver_path


def load_remote_secrets(
    logging_module,
    server_url_secrets,
    config_path="/home/santod/.config/weather_observer/secrets.ini",
):
    api_key = None

    logging_module.info("Attempting to read API key from secrets.ini")
    print("line 297 attempting to read API key from secrets.ini")
    try:
        config = configparser.ConfigParser()
        if not os.path.exists(config_path):
            logging_module.error(f"Configuration file not found at {config_path}")

        config.read(config_path)
        api_key = config.get("SECRETS", "API_KEY")
        logging_module.info("API key read successfully.")
        print(f"Using API Key: {api_key}")

    except configparser.NoSectionError:
        logging_module.error(f"Error: 'SECRETS' section not found in {config_path}")
    except configparser.NoOptionError:
        logging_module.error(f"Error: 'API_KEY' not found in 'SECRETS' section in {config_path}")
    except Exception as e:
        logging_module.error(f"Error reading configuration file {config_path}: {e}")

    if not api_key:
        logging_module.error("API Key could not be read. Exiting.")

    logging_module.info("Constructing request to fetch secrets.")
    request_data = {"api_key": api_key}
    request_json = json.dumps(request_data)
    logging_module.info(f"Request data: {request_json}")

    defaults = {
        "ACCESS_TOKEN": "",
        "API_SECRET_TOKEN": "",
        "EMAIL_PASSWORD_CODE": "",
        "FULLSCREEN_BREAK_PASSWORD": "",
        "IG_USER_ID": "",
        "PAGE_ACCESS_TOKEN": "",
        "PAGE_ID": "",
        "api_key": api_key,
    }

    logging_module.info(f"Sending request to {server_url_secrets}")
    try:
        response = requests.post(
            server_url_secrets,
            headers={"Content-Type": "application/json"},
            data=request_json,
        )
        logging_module.info(f"Received response status code: {response.status_code}")
        response.raise_for_status()

        response_data = response.json()
        logging_module.info("Successfully received secrets from server.")

        defaults.update(
            {
                "ACCESS_TOKEN": response_data.get("ACCESS_TOKEN"),
                "API_SECRET_TOKEN": response_data.get("API_SECRET_TOKEN"),
                "EMAIL_PASSWORD_CODE": response_data.get("EMAIL_PASSWORD_CODE"),
                "FULLSCREEN_BREAK_PASSWORD": response_data.get("FULLSCREEN_BREAK_PASSWORD"),
                "IG_USER_ID": response_data.get("IG_USER_ID"),
                "PAGE_ACCESS_TOKEN": response_data.get("PAGE_ACCESS_TOKEN"),
                "PAGE_ID": response_data.get("PAGE_ID"),
            }
        )

        if None in [
            defaults["ACCESS_TOKEN"],
            defaults["API_SECRET_TOKEN"],
            defaults["EMAIL_PASSWORD_CODE"],
            defaults["FULLSCREEN_BREAK_PASSWORD"],
            defaults["IG_USER_ID"],
            defaults["PAGE_ACCESS_TOKEN"],
            defaults["PAGE_ID"],
        ]:
            logging_module.warning("One or more secrets were not found in the server response.")

        logging_module.info("Secrets extracted successfully.")

    except requests.exceptions.RequestException as e:
        logging_module.error(f"Error connecting to server at {server_url_secrets}: {e}")
    except requests.exceptions.HTTPError as e:
        logging_module.error(f"HTTP Error received from server: {e.response.status_code} {e.response.reason}")
        logging_module.error(f"Server response content: {e.response.text}")
        if e.response.status_code == 401:
            logging_module.error("Authentication failed (401 Unauthorized). Check if the API Key is correct and valid on the server.")
    except json.JSONDecodeError as e:
        logging_module.error(f"Error decoding JSON response from server: {e}")
        logging_module.error(f"Server response content: {response.text}")
    except Exception as e:
        logging_module.error(f"An unexpected error occurred during secret retrieval: {e}")

    return defaults


def start_background_event_loop(globals_dict, asyncio_module=asyncio, threading_module=threading):
    def start_event_loop():
        loop = asyncio_module.new_event_loop()
        asyncio_module.set_event_loop(loop)
        globals_dict["background_loop"] = loop
        loop.run_forever()

    threading_module.Thread(target=start_event_loop, daemon=True).start()
