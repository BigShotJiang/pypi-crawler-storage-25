import threading
import tkinter as tk
from PIL import Image, ImageTk


DISPLAY_FRAME_WIDTH = 950
DISPLAY_FRAME_HEIGHT = 515
SHARED_IMAGE_X_SHIFT = 35
SHARED_IMAGE_Y_LIFT = 10
RADIOSONDE_Y_LIFT = 4
BAROGRAPH_PLACE_X = -14
BAROGRAPH_PLACE_Y = -15
WIDE_STILL_SAT_PLACE_X = 18
WIDE_STILL_SAT_PLACE_Y = -5
GLOBE_STILL_SAT_PLACE_X = 165
GLOBE_STILL_SAT_PLACE_Y = -4


def on_touch_start(event, globals_dict, root):
    print("Touch start detected at:", event.x, event.y)

    if globals_dict.get("debounce_timer") is not None:
        root.after_cancel(globals_dict["debounce_timer"])
        globals_dict["debounce_timer"] = None
        print("Existing debounce canceled by new touch.")

    globals_dict["start_x"] = event.x
    globals_dict["start_y"] = event.y


def reset_debounce(globals_dict):
    print("Debounce timer finished.")
    globals_dict["debounce_timer"] = None


def manage_timers_after_swipe(globals_dict, root, auto_advance_frames):
    auto_advance_timer = globals_dict.get("auto_advance_timer")
    if auto_advance_timer:
        root.after_cancel(auto_advance_timer)
        globals_dict["auto_advance_timer"] = None

    image_keys = globals_dict["image_keys"]
    current_frame_index = globals_dict["current_frame_index"]
    if image_keys[current_frame_index] in ["lcl_radar_loop_img", "reg_sat_loop_img"]:
        globals_dict["auto_advance_timer"] = root.after(30000, auto_advance_frames)
    else:
        globals_dict["auto_advance_timer"] = root.after(10000, auto_advance_frames)


def handle_swipe(
    event,
    globals_dict,
    root,
    on_right_swipe,
    on_left_swipe,
    auto_advance_frames,
    is_x11,
    time_module,
):
    if globals_dict.get("debounce_timer") is not None:
        return

    start_x = globals_dict.get("start_x")
    start_y = globals_dict.get("start_y")
    if start_x is None:
        return

    delta_x = event.x - start_x
    delta_y = event.y - start_y

    current_time_ms = int(time_module.time() * 1000)
    print(f"[{current_time_ms}] Motion: x={event.x}, y={event.y}, delta_x={delta_x:.2f}, delta_y={delta_y:.2f}")

    if abs(delta_x) > 30 and abs(delta_x) > abs(delta_y):
        if delta_x > 0:
            print("Swipe Right Detected -> Calling on_right_swipe")
            on_right_swipe(event)
        else:
            print("Swipe Left Detected -> Calling on_left_swipe")
            on_left_swipe(event)

        if is_x11:
            globals_dict["start_x"] = None
            globals_dict["start_y"] = None
            debounce_delay_ms = 600
            print(f"[{current_time_ms}] X11: Resetting start=None, Starting debounce for {debounce_delay_ms}ms")
        else:
            globals_dict["start_x"] = event.x
            globals_dict["start_y"] = event.y
            debounce_delay_ms = 300
            print(
                f"[{current_time_ms}] Wayland: Resetting start={globals_dict['start_x']}, "
                f"Starting debounce for {debounce_delay_ms}ms"
            )

        globals_dict["debounce_timer"] = root.after(
            debounce_delay_ms,
            lambda: reset_debounce(globals_dict),
        )
        manage_timers_after_swipe(globals_dict, root, auto_advance_frames)


def _cancel_animation(root, globals_dict, timer_key):
    animation_id = globals_dict.get(timer_key)
    if animation_id:
        try:
            root.after_cancel(animation_id)
        except Exception:
            pass
        globals_dict[timer_key] = None


def _stop_loop_animations(root, globals_dict):
    _cancel_animation(root, globals_dict, "lcl_radar_animation_id")
    _cancel_animation(root, globals_dict, "reg_sat_animation_id")
    globals_dict["LCL_RADAR_ANIM_GEN"] = globals_dict.get("LCL_RADAR_ANIM_GEN", 0) + 1
    globals_dict["REG_SAT_ANIM_GEN"] = globals_dict.get("REG_SAT_ANIM_GEN", 0) + 1


def _place_centered(display_label, photo, frame_width, frame_height, y_lift=0, x_shift=0):
    x_pos = max(0, (frame_width - photo.width()) // 2 - x_shift)
    y_pos = max(0, (frame_height - photo.height()) // 2 - y_lift)
    display_label.place(
        x=x_pos,
        y=y_pos,
        width=photo.width(),
        height=photo.height(),
        anchor="nw",
    )


def _recreate_display_label(globals_dict, display_image_frame):
    for child in list(display_image_frame.winfo_children()):
        try:
            child.destroy()
        except Exception:
            pass

    new_label = tk.Label(display_image_frame, bg=display_image_frame.cget("bg"), bd=0, highlightthickness=0)
    globals_dict["display_label"] = new_label
    return new_label


def on_left_swipe(event, globals_dict, root, num_frames, box_variables, show_image_in_display_frame):
    if globals_dict["refresh_flag"] or globals_dict["extremes_flag"]:
        return

    globals_dict["timer_override"] = True
    _stop_loop_animations(root, globals_dict)

    last_displayed_index = globals_dict.get("last_displayed_index", -1)
    if last_displayed_index == -1:
        current_target_index = 0
    else:
        current_target_index = (last_displayed_index + 1) % num_frames

    attempts = 0
    candidate_index = current_target_index
    while attempts < num_frames:
        if box_variables[candidate_index]:
            if show_image_in_display_frame(globals_dict["image_keys"][candidate_index]):
                globals_dict["current_frame_index"] = candidate_index
                return
        candidate_index = (candidate_index + 1) % num_frames
        attempts += 1

    print("[WARN] No displayable frames to swipe to.")


def on_right_swipe(event, globals_dict, root, num_frames, box_variables, show_image_in_display_frame):
    if globals_dict["refresh_flag"] or globals_dict["extremes_flag"]:
        return

    globals_dict["timer_override"] = True
    _stop_loop_animations(root, globals_dict)

    last_displayed_index = globals_dict.get("last_displayed_index", -1)
    if last_displayed_index == -1:
        current_target_index = num_frames - 1
    else:
        current_target_index = (last_displayed_index - 1 + num_frames) % num_frames

    attempts = 0
    candidate_index = current_target_index
    while attempts < num_frames:
        if box_variables[candidate_index]:
            if show_image_in_display_frame(globals_dict["image_keys"][candidate_index]):
                globals_dict["current_frame_index"] = candidate_index
                return
        candidate_index = (candidate_index - 1 + num_frames) % num_frames
        attempts += 1

    print("[WARN] No displayable frames to swipe to.")


def run_lcl_radar_loop_animation(globals_dict, available_image_dictionary, display_label, root):
    _cancel_animation(root, globals_dict, "lcl_radar_animation_id")

    if "lcl_radar_loop_img" not in available_image_dictionary:
        return
    lcl = available_image_dictionary["lcl_radar_loop_img"]
    if not lcl:
        return

    first_frame, padx0, pady0 = lcl[0]
    photo = ImageTk.PhotoImage(first_frame)
    display_label.configure(image=photo)
    display_label.image = photo
    _place_centered(display_label, photo, DISPLAY_FRAME_WIDTH, DISPLAY_FRAME_HEIGHT, y_lift=SHARED_IMAGE_Y_LIFT, x_shift=SHARED_IMAGE_X_SHIFT)
    display_label.lift()

    globals_dict["LCL_RADAR_ANIM_GEN"] = globals_dict.get("LCL_RADAR_ANIM_GEN", 0) + 1
    my_gen = globals_dict["LCL_RADAR_ANIM_GEN"]

    cycle_count = 0
    max_cycles = 3

    def play_loop(index=0):
        nonlocal cycle_count
        if my_gen != globals_dict.get("LCL_RADAR_ANIM_GEN"):
            return

        frame, _, _ = lcl[index % len(lcl)]
        try:
            photo.paste(frame)
            display_label.lift()
        except Exception as e:
            print(f"[ERROR] displaying frame: {e}")
            return

        next_index = (index + 1) % len(lcl)
        delay = 200 if next_index != 0 else 2000
        if next_index == 0:
            cycle_count += 1
            if cycle_count >= max_cycles:
                return

        globals_dict["lcl_radar_animation_id"] = root.after(delay, play_loop, next_index)

    play_loop(0)


def run_reg_sat_loop_animation(globals_dict, available_image_dictionary, display_label, root):
    _cancel_animation(root, globals_dict, "reg_sat_animation_id")

    if "reg_sat_loop_img" not in available_image_dictionary:
        return
    regsat = available_image_dictionary["reg_sat_loop_img"]
    if not regsat:
        return

    first_frame, padx0, pady0 = regsat[0]
    photo = ImageTk.PhotoImage(first_frame)
    display_label.configure(image=photo)
    display_label.image = photo
    _place_centered(display_label, photo, DISPLAY_FRAME_WIDTH, DISPLAY_FRAME_HEIGHT, y_lift=SHARED_IMAGE_Y_LIFT, x_shift=SHARED_IMAGE_X_SHIFT)
    display_label.lift()

    globals_dict["REG_SAT_ANIM_GEN"] = globals_dict.get("REG_SAT_ANIM_GEN", 0) + 1
    my_gen = globals_dict["REG_SAT_ANIM_GEN"]

    cycle_count = 0
    max_cycles = 5

    def play_sat_loop(index=0):
        nonlocal cycle_count
        if my_gen != globals_dict.get("REG_SAT_ANIM_GEN"):
            return

        if globals_dict.get("timer_override") and globals_dict.get("current_frame_index") != 5:
            return

        frame, _, _ = regsat[index % len(regsat)]
        try:
            photo.paste(frame)
            display_label.lift()
        except Exception as e:
            print(f"[ERROR] displaying reg_sat frame: {e}")
            return

        next_index = (index + 1) % len(regsat)
        delay = 200 if next_index != 0 else 2000
        if next_index == 0:
            cycle_count += 1
            if cycle_count >= max_cycles:
                return

        globals_dict["reg_sat_animation_id"] = root.after(delay, play_sat_loop, next_index)

    play_sat_loop(0)


def show_image_in_display_frame(
    image_key,
    globals_dict,
    root,
    available_image_dictionary,
    display_image_frame,
    display_label,
    transparent_frame,
    run_lcl_radar_loop_animation,
    run_reg_sat_loop_animation,
    orb_raise_callback=None,
    recreate_display_frame_callback=None,
):
    if globals_dict.get("DISPLAY_FRAME_RESET_IN_PROGRESS"):
        print("[INFO] Display frame is resetting — skipping image display.")
        return False

    image_keys = globals_dict["image_keys"]
    try:
        index_to_display = image_keys.index(image_key)
    except ValueError:
        print(f"[ERROR] Image key '{image_key}' not found in image_keys list.")
        return False

    if image_key not in available_image_dictionary:
        return False

    last_displayed_index = globals_dict.get("last_displayed_index", -1)
    previous_key = None
    if 0 <= last_displayed_index < len(image_keys):
        previous_key = image_keys[last_displayed_index]

    if (
        recreate_display_frame_callback
        and previous_key in {"lcl_radar_loop_img", "reg_sat_loop_img"}
        and image_key not in {"lcl_radar_loop_img", "reg_sat_loop_img"}
    ):
        recreate_display_frame_callback()
        display_image_frame = globals_dict["display_image_frame"]
        display_label = globals_dict["display_label"]

    _stop_loop_animations(root, globals_dict)
    display_label = _recreate_display_label(globals_dict, display_image_frame)

    if image_key == "lcl_radar_loop_img":
        if len(available_image_dictionary[image_key]) >= 3:
            globals_dict["timer_override"] = False
            run_lcl_radar_loop_animation()
            if orb_raise_callback:
                orb_raise_callback()
            globals_dict["last_displayed_index"] = index_to_display
            return True
        return False

    if image_key == "reg_sat_loop_img":
        if not available_image_dictionary[image_key]:
            return False
        globals_dict["timer_override"] = False
        run_reg_sat_loop_animation()
        if orb_raise_callback:
            orb_raise_callback()
        globals_dict["last_displayed_index"] = index_to_display
        return True

    try:
        img_to_display, _, _ = available_image_dictionary[image_key]

        if not display_label or not display_label.winfo_exists():
            print("[ERROR] display_label does not exist or is invalid!")
            return

        if getattr(display_label, "image", None):
            display_label.image = None

        if isinstance(img_to_display, Image.Image):
            photo = ImageTk.PhotoImage(img_to_display)
        else:
            photo = img_to_display

        display_label.configure(image=photo)
        display_label.image = photo
        if image_key == "baro_img":
            display_label.place(x=BAROGRAPH_PLACE_X, y=BAROGRAPH_PLACE_Y, width=photo.width(), height=photo.height(), anchor="nw")
        elif image_key == "still_sat_img":
            if photo.width() > 700:
                display_label.place(x=WIDE_STILL_SAT_PLACE_X, y=WIDE_STILL_SAT_PLACE_Y, width=photo.width(), height=photo.height(), anchor="nw")
            else:
                display_label.place(x=GLOBE_STILL_SAT_PLACE_X, y=GLOBE_STILL_SAT_PLACE_Y, width=photo.width(), height=photo.height(), anchor="nw")
        elif image_key == "radiosonde_img":
            _place_centered(display_label, photo, DISPLAY_FRAME_WIDTH, DISPLAY_FRAME_HEIGHT, y_lift=RADIOSONDE_Y_LIFT, x_shift=SHARED_IMAGE_X_SHIFT)
        else:
            _place_centered(display_label, photo, DISPLAY_FRAME_WIDTH, DISPLAY_FRAME_HEIGHT, y_lift=SHARED_IMAGE_Y_LIFT, x_shift=SHARED_IMAGE_X_SHIFT)
        try:
            transparent_frame.tk.call('raise', transparent_frame._w)
        except Exception:
            pass
        if orb_raise_callback:
            orb_raise_callback()
        globals_dict["last_displayed_index"] = index_to_display
        return True
    except Exception as e:
        print(f"[ERROR] An error occurred during static image display for key '{image_key}': {e}")
        import traceback
        traceback.print_exc()
        return False


def auto_advance_frames(
    globals_dict,
    root,
    image_keys,
    num_frames,
    box_variables,
    available_image_dictionary,
    show_image_in_display_frame,
):
    auto_advance_timer = globals_dict.get("auto_advance_timer")
    if auto_advance_timer is not None:
        root.after_cancel(auto_advance_timer)
        globals_dict["auto_advance_timer"] = None

    attempts = 0
    shown = False

    while attempts < num_frames:
        idx = globals_dict["current_frame_index"]
        current_key = image_keys[idx]

        if box_variables[idx]:
            if current_key == "lcl_radar_loop_img":
                if len(available_image_dictionary.get(current_key, [])) >= 3:
                    if show_image_in_display_frame(current_key):
                        shown = True
                        break
            elif current_key == "reg_sat_loop_img":
                if len(available_image_dictionary.get(current_key, [])) >= 3:
                    if show_image_in_display_frame(current_key):
                        shown = True
                        break
            else:
                if show_image_in_display_frame(current_key):
                    shown = True
                    break

        globals_dict["current_frame_index"] = (globals_dict["current_frame_index"] + 1) % num_frames
        attempts += 1

    if not shown:
        print("[WARN] No valid frames to display — display will not change this cycle.")

    globals_dict["current_frame_index"] = (globals_dict["current_frame_index"] + 1) % num_frames
    globals_dict["auto_advance_timer"] = root.after(
        22000,
        lambda: auto_advance_frames(
            globals_dict,
            root,
            image_keys,
            num_frames,
            box_variables,
            available_image_dictionary,
            show_image_in_display_frame,
        ),
    )


def return_to_image_cycle(
    globals_dict,
    root,
    frame1,
    display_image_frame,
    image_keys,
    show_image_in_display_frame,
    update_images,
    auto_advance_frames,
    show_function_button_frame,
    clear_random_map_ui,
    update_transparent_frame_data,
    xs,
):
    for timer_key in ["auto_advance_timer", "update_images_timer"]:
        timer_id = globals_dict.get(timer_key)
        if timer_id:
            root.after_cancel(timer_id)
            globals_dict[timer_key] = None

    for flag_name in ["refresh_flag", "extremes_flag", "reboot_shutdown_flag"]:
        globals_dict[flag_name] = False

    for timestamp_name in [
        "last_lcl_radar_update",
        "last_still_sat_update",
        "last_reg_sat_update",
        "last_sfc_plots_update",
        "last_radiosonde_update",
    ]:
        globals_dict[timestamp_name] = None

    clear_random_map_ui()

    for widget in frame1.winfo_children():
        widget.destroy()

    globals_dict["current_frame_index"] = 0

    if len(xs) != 1:
        update_transparent_frame_data()

    show_function_button_frame()
    frame1.grid_forget()

    display_image_frame.grid(row=0, column=0, padx=(140, 0), pady=(75, 0), sticky="sw")
    root.grid_rowconfigure(0, weight=0)
    root.grid_columnconfigure(0, weight=0)

    show_image_in_display_frame(image_keys[globals_dict["current_frame_index"]])
    update_images()
    auto_advance_frames()


def run_lightning_task(
    globals_dict,
    available_image_dictionary,
    lightning_lat,
    lightning_lon,
    chrome_driver_path,
    chromium_bin,
    root,
    fetch_and_process_lightning,
):
    def task_wrapper():
        globals_dict["TASK_IN_PROGRESS"] = True
        lightning_scraping_in_progress_ref = [globals_dict["lightning_scraping_in_progress"]]
        try:
            fetch_and_process_lightning(
                available_image_dictionary,
                lightning_lat,
                lightning_lon,
                chrome_driver_path,
                chromium_bin,
                lightning_scraping_in_progress_ref,
                root,
            )
        finally:
            globals_dict["TASK_IN_PROGRESS"] = False

    threading.Thread(target=task_wrapper, daemon=True).start()


def run_lcl_radar_task(
    globals_dict,
    available_image_dictionary,
    box_variables,
    root,
    chrome_driver_path,
    chromium_bin,
    radar_identifier,
    lcl_radar_zoom_clicks,
    auto_advance_frames,
    get_lcl_radar_loop,
):
    def task_wrapper():
        globals_dict["TASK_IN_PROGRESS"] = True
        try:
            get_lcl_radar_loop(
                available_image_dictionary,
                box_variables,
                root,
                chrome_driver_path,
                chromium_bin,
                radar_identifier,
                lcl_radar_zoom_clicks,
                auto_advance_frames,
            )
        finally:
            globals_dict["TASK_IN_PROGRESS"] = False

    threading.Thread(target=task_wrapper, daemon=True).start()


def run_sfc_plots_task(
    globals_dict,
    available_image_dictionary,
    station_plot_lat,
    station_plot_lon,
    zoom_plot,
    chrome_driver_path,
    chromium_bin,
    fetch_and_process_sfc_plots,
):
    def task_wrapper():
        globals_dict["TASK_IN_PROGRESS"] = True
        try:
            fetch_and_process_sfc_plots(
                available_image_dictionary,
                station_plot_lat,
                station_plot_lon,
                zoom_plot,
                chrome_driver_path,
                chromium_bin,
            )
        finally:
            globals_dict["TASK_IN_PROGRESS"] = False

    threading.Thread(target=task_wrapper, daemon=True).start()


def run_reg_sat_task(
    globals_dict,
    available_image_dictionary,
    reg_sat_frames,
    box_variables,
    chrome_driver_path,
    chromium_bin,
    reg_sat_choice_variables,
    fetch_and_process_reg_sat_loop,
):
    def task_wrapper():
        globals_dict["TASK_IN_PROGRESS"] = True
        try:
            fetch_and_process_reg_sat_loop(
                available_image_dictionary,
                reg_sat_frames,
                box_variables,
                chrome_driver_path,
                chromium_bin,
                reg_sat_choice_variables,
            )
        finally:
            globals_dict["TASK_IN_PROGRESS"] = False

    threading.Thread(target=task_wrapper, daemon=True).start()
