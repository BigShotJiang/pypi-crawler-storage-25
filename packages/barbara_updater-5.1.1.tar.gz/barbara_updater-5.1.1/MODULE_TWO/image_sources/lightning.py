import threading
import time
import requests
from io import BytesIO
from PIL import Image
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

def cleanup_lightning_image(available_image_dictionary):
    """Handles cleanup tasks when there's an error."""
    global lightning_img, lightning_scraping_in_progress
    lightning_img = None
    lightning_scraping_in_progress = False
    available_image_dictionary.pop("lightning_img", None)

# Code for lightning
def fetch_and_process_lightning(
    available_image_dictionary,
    lightning_lat,
    lightning_lon,
    CHROME_DRIVER_PATH,
    CHROMIUM_BIN,
    lightning_scraping_in_progress_ref,
    root
):
    """Fetches and processes a map of lightning strikes and assigns it to the 'lightning_img' variable."""
    global lightning_img, lightning_scraping_in_progress
    
    if lightning_scraping_in_progress_ref[0]:
        #print("[DEBUG] Lightning scrape already in progress. Skipping new request.")
        return

    lightning_scraping_in_progress_ref[0] = True
    
    lightning_url = (
        "https://www.lightningmaps.org/?lang=en#m=oss;t=1;s=200;o=0;b=0.00;ts=0;d=2;dl=2;dc=0;y="
        + str(lightning_lat) + ";x=" + str(lightning_lon) + ";z=6;"
    )

    def background_task():
        driver = None
        try:
            if not CHROME_DRIVER_PATH:
                print("ERROR: ChromeDriver path is not set. Cannot start browser.")
                cleanup_lightning_image(available_image_dictionary)
                return

            options = Options()
            options.binary_location = CHROMIUM_BIN
            options.add_argument('--headless')  # SAFER across devices
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument('--disable-gpu')

            service = Service(CHROME_DRIVER_PATH)
            driver = webdriver.Chrome(service=service, options=options)
            
            service_pid = driver.service.process.pid
            #print(f"[INFO] Started lightning chromedriver service with PID: {service_pid}")

            driver.set_page_load_timeout(30)
            driver.set_window_size(900, 770)
            driver.get(lightning_url)

            # Wait for the "Got it!" button and dismiss it
            WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.XPATH, "//a[@class='cc-btn cc-dismiss']"))
            ).click()

            time.sleep(3)

            WebDriverWait(driver, 10).until_not(
                EC.presence_of_element_located((By.XPATH, "//div[@class='cc-banner']"))
            )
            WebDriverWait(driver, 15).until(
                lambda d: d.execute_script('return document.readyState') == 'complete'
            )

            lightning_screenshot = driver.get_screenshot_as_png()
            new_img = Image.open(BytesIO(lightning_screenshot))
            crop_box = (46, 0, new_img.width, new_img.height - 90)
            resized_img = new_img.crop(crop_box).resize((865, 515), Image.LANCZOS)
            new_img.close()

            lightning_img = resized_img
            available_image_dictionary["lightning_img"] = (lightning_img, 0, 10)

        except Exception as e:
            print(f"[DEBUG] Selenium task for lightning failed: {e}")
            cleanup_lightning_image(available_image_dictionary)
        finally:
            lightning_scraping_in_progress_ref[0] = False
            if driver:
                driver.quit()

    # Start the full wrapper in a separate thread (nothing blocks Tk)
    threading.Thread(target=background_task, daemon=True).start()
