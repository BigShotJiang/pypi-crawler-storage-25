# Code to get the storm reports image

import requests
from PIL import Image, ImageTk, UnidentifiedImageError
from io import BytesIO

def fetch_and_process_storm_reports(available_image_dictionary):
    """
    Fetches the latest storm report GIF from the NOAA SPC website's 'today' URL,
    resizes it proportionally, and prepares it for display.
    """
    global storm_reports_img

    # --- KEY CHANGE (v5) ---
    # Using the 'today.gif' URL simplifies the code. We no longer need to
    # loop through previous dates to find the most recent image.
    storm_reports_url = 'https://www.spc.noaa.gov/climo/reports/today.gif'
    
    try:
        #print(f"Attempting to fetch image from: {storm_reports_url}")
        
        response = requests.get(storm_reports_url)

        if response.status_code == 200:
            img_data = response.content
            img = Image.open(BytesIO(img_data))

            # --- REVERTED CHANGE ---
            # The sharpening filter was creating undesirable artifacts ("ghosting").
            # We are removing it for a cleaner, though softer, upscale.
            
            original_width, original_height = img.size
            target_width = 640
            
            # Calculate the new height to maintain the aspect ratio
            aspect_ratio = original_height / original_width
            target_height = int(target_width * aspect_ratio)

            # Resize the image using the high-quality LANCZOS filter
            img = img.resize((target_width, target_height), Image.LANCZOS)
            
            #print(f"Successfully loaded image. Resized to {img.size}.")

            # Create a PhotoImage and save it to the global variable
            storm_reports_img = ImageTk.PhotoImage(img)

            # Store the image with padding values in the dictionary
            available_image_dictionary['storm_reports_img'] = (storm_reports_img, 100, 40)  

            return  # Exit after successfully loading an image

        else:
            print(f"Image not found at the 'today' URL (Status: {response.status_code}).")


    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Network error while fetching storm reports image: {e}")
    except UnidentifiedImageError as e:
        print(f"[ERROR] Cannot identify image file. The resource at the URL may not be a valid image: {e}")
    except Exception as e:
        print(f"[ERROR] An unexpected error occurred: {e}")
