
# Code begins for nws lcl radar loop

import threading
import requests
from io import BytesIO
from datetime import datetime
from PIL import Image, ImageChops
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from datetime import timedelta

REG_SAT_SETTINGS = [
    (18, 'pnw'), (19, 'umv'), (19, 'ne'), (19, 'can'),
    (18, 'psw'), (19, 'smv'), (19, 'se'), (19, 'ga'),
    (19, 'nr'), (19, 'cgl'), (18, 'wus'), (19, 'car'),
    (19, 'sr'), (19, 'sp'), (19, 'eus'), (19, 'taw')
]

REG_SAT_PADDING = {
    'taw': (45, 12),
    'can': (15, 52),
}

REG_SAT_IMAGE_OPTIONS = {
    3: {"time_offset": 30, "time_format": "%H%M", "image_suffix": "1125x560.jpg", "valid_minutes": {0}},
    7: {"time_offset": 10, "time_format": "%H%M", "image_suffix": "500x500.jpg", "valid_minutes": {6}},
    10: {"time_offset": 20, "time_format": "%H%M", "image_suffix": "500x500.jpg", "valid_minutes": {0}},
    11: {"time_offset": 20, "time_format": "%H%M", "image_suffix": "500x500.jpg", "valid_minutes": {0}},
    14: {"time_offset": 10, "time_format": "%H%M", "image_suffix": "500x500.jpg", "valid_minutes": {6}},
    15: {"time_offset": 20, "time_format": "%H%M", "image_suffix": "900x540.jpg", "valid_minutes": {0}},
}
        
# Function to trim black borders from an image
def trim_near_black_borders_reg_sat(img, threshold=30):
    try:
        grayscale_img = img.convert("L")
        binary_img = grayscale_img.point(lambda p: 255 if p > threshold else 0, '1')
        bbox = binary_img.getbbox()
        if bbox:
            return img.crop(bbox)
    except Exception as e:
        print(f"Error cropping the image in reg sat: {e}")
    return img

def generate_reg_sat_urls(base_url, num_images, reg_sat_goes, reg_sat_reg, reg_sat_choice_variables):
    urls = []
    current_time_utc = datetime.utcnow()
    selected_index = reg_sat_choice_variables.index(1)
    image_option = REG_SAT_IMAGE_OPTIONS.get(
        selected_index,
        {"time_offset": 10, "time_format": "%H%M", "image_suffix": "600x600.jpg", "valid_minutes": {6}},
    )

    for _ in range(num_images):
        current_time_utc -= timedelta(minutes=image_option["time_offset"])
        while current_time_utc.minute % 10 not in image_option["valid_minutes"]:
            current_time_utc -= timedelta(minutes=1)

        year = current_time_utc.year
        day_of_year = current_time_utc.timetuple().tm_yday
        time_code = current_time_utc.strftime(image_option["time_format"])

        url = (
            f"{base_url}{year}{day_of_year:03d}{time_code}_GOES{reg_sat_goes}-ABI-"
            f"{reg_sat_reg}-GEOCOLOR-{image_option['image_suffix']}"
        )
        urls.append(url)
        current_time_utc -= timedelta(minutes=5)

    return urls
    
# Function to scrape and store frames in memory
def scrape_and_store_reg_sat_images(urls, reg_sat_goes, reg_sat_reg, CHROMIUM_BIN, CHROME_DRIVER_PATH):
    frames = []

    try:
        # First, check if the paths were set at startup.
        if not (CHROMIUM_BIN and CHROME_DRIVER_PATH):
            print("ERROR: Chromium/ChromeDriver path not set. Cannot start browser.")
            return

        # Define your options for this specific function
        options = Options()
        options.binary_location = CHROMIUM_BIN
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        # Add any other specific options you need for this function...

        # Point to the driver path determined at startup
        service = Service(CHROME_DRIVER_PATH)

        # Initialize the driver with both objects
        driver = webdriver.Chrome(service=service, options=options)

    except Exception as e:
        print(f"Failed to initialize the driver in reg sat: {e}")
        return frames

    try:
        for url in reversed(urls):
            try:
                driver.get(url)
                if "404 Not Found" in driver.title:
                    print(f"No image found for URL in reg sat: {url}")
                    continue

                # Capture screenshot and process the image
                screenshot = driver.get_screenshot_as_png()
                screenshot = Image.open(BytesIO(screenshot))
                screenshot = trim_near_black_borders_reg_sat(screenshot)

                # Resize the image based on the region
                if reg_sat_reg == 'taw':
                    target_size = (858, 515)
                elif reg_sat_reg == 'can':
                    target_size = (900, 448)
                else:
                    target_size = (515, 515)

                screenshot = screenshot.resize(target_size, Image.LANCZOS)
                frames.append(screenshot)  # keep as PIL.Image
                # do NOT close here; we’re keeping the image for playback

            except Exception as e:
                print(f"Error processing image from URL {url} in reg sat: {e}")

    finally:
        driver.quit()

    #print(f"[DEBUG] Total frames scraped: {len(frames)}")
    return frames
    
# Function to fetch and process satellite frames
def fetch_and_process_reg_sat_loop(
    available_image_dictionary,
    reg_sat_frames,
    box_variables,
    CHROME_DRIVER_PATH,
    CHROMIUM_BIN,
    reg_sat_choice_variables
):
    def threaded_fetch_and_process():
        global last_reg_sat_update, reg_sat_reg, reg_sat_goes, reg_sat_updated_flag

        current_time = datetime.now()
        base_url = "https://cdn.star.nesdis.noaa.gov/GOES{}/ABI/SECTOR/{}/GEOCOLOR/"
        num_images_to_scrape = 12

        try:
            # --- added: mirror LCL pattern; teardown old data at fetch start ---
            if 'full_reg_sat_teardown' in globals():
                full_reg_sat_teardown()
            reg_sat_updated_flag = False
            # --- end added ---

            selected_index = reg_sat_choice_variables.index(1)
            if 0 <= selected_index < len(REG_SAT_SETTINGS):
                reg_sat_goes, reg_sat_reg = REG_SAT_SETTINGS[selected_index]
            else:
                reg_sat_goes, reg_sat_reg = 19, 'unknown'

            # Generate URLs to scrape
            urls_to_scrape = generate_reg_sat_urls(
                base_url.format(reg_sat_goes, reg_sat_reg),
                num_images_to_scrape,
                reg_sat_goes,
                reg_sat_reg,
                reg_sat_choice_variables
            )

            # Scrape and process images
            new_frames = scrape_and_store_reg_sat_images(
                urls_to_scrape,
                reg_sat_goes,
                reg_sat_reg,
                CHROMIUM_BIN,
                CHROME_DRIVER_PATH
            )
            
            # Update the global frames only if new frames are successfully fetched
            if new_frames:
                reg_sat_frames = new_frames
                last_reg_sat_update = current_time

                pad_x, pad_y = REG_SAT_PADDING.get(reg_sat_reg, (150, 12))
                available_image_dictionary['reg_sat_loop_img'] = [(frame, pad_x, pad_y) for frame in reg_sat_frames]
                reg_sat_updated_flag = True
            else:
                print("[DEBUG] line 8859. No new frames fetched. Keeping existing reg_sat_frames.")

        except Exception as e:
            print(f"[ERROR] Exception in fetch_and_process_reg_sat_loop: {e}")

    # Start the scraping process in a thread to keep the GUI responsive
    threading.Thread(target=threaded_fetch_and_process, daemon=True).start()
