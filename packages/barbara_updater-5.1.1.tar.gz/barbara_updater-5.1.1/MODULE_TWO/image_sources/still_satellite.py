import aiohttp
from io import BytesIO
from datetime import datetime
from PIL import Image, ImageTk

# # Code for still sat
async def fetch_and_process_still_sat(available_image_dictionary, lg_still_sat_choice_vars, lg_still_sat, lg_still_view):
    """Fetches and processes a weather satellite image and assigns it to 'still_sat_img'."""
    global still_sat_img, last_still_sat_update

    current_time = datetime.now()
    retries = 1  # Number of retries
    delay = 5  # Delay between retries (in seconds)

    for attempt in range(retries):
        try:
            # Check the user's choice using the IntVar
            choice = lg_still_sat_choice_vars.get()
            #print("line 8713. for debugging still sat position. choice 0 or 1 padx=150, otherwise padx=250: ", choice)
            if choice == 0 or choice == 1:  # Eastern or Western US
                window_width = 840
                window_height = 518
                image_size = '1250x750.jpg'
                pad_x = 170
                pad_y = 10
            elif choice == 2 or choice == 3:  # Globe East or West
                window_width = 518
                window_height = 518
                image_size = '678x678.jpg'
                pad_x = 165
                pad_y = 8

            lg_sat_url = f"https://cdn.star.nesdis.noaa.gov/GOES{lg_still_sat}/ABI/{lg_still_view}/GEOCOLOR/{image_size}"
            #print("line 9336. lg_sat_url: ", lg_sat_url)
            # Download the image asynchronously
            async with aiohttp.ClientSession() as session:
                async with session.get(lg_sat_url) as response:
                    response.raise_for_status()
                    image_data = await response.read()

            # Process the image using PIL
            satellite_screenshot_image = Image.open(BytesIO(image_data))

            dark_color_threshold = 50
            gray_image = satellite_screenshot_image.convert('L')
            non_dark_region = gray_image.point(lambda x: 0 if x < dark_color_threshold else 255, '1').getbbox()
            cropped_image = satellite_screenshot_image.crop(non_dark_region)
            resized_image = cropped_image.resize((window_width, window_height), Image.LANCZOS)
            satellite_screenshot_image.close()

            # Assign the processed image to the global variable
            still_sat_img = ImageTk.PhotoImage(resized_image)

            # Add the image to the global dictionary for reuse
            # Store the still satellite image with padding values in the available image dictionary
            available_image_dictionary["still_sat_img"] = (still_sat_img, pad_x, pad_y)

            #print("[DEBUG] Satellite image successfully added to available_image_dictionary.")

            # Update the timestamp for the last successful update
            last_still_sat_update = current_time
            
            return  # Exit the function if the image was successfully fetched

        except Exception as e:
            print(f"[ERROR] line 8797. Attempt {attempt + 1} failed: {e}")
            if attempt < retries - 1:
                await asyncio.sleep(delay)  # Wait before retrying

    print("[ERROR] line 8801. All retries failed. Unable to fetch satellite image.")
