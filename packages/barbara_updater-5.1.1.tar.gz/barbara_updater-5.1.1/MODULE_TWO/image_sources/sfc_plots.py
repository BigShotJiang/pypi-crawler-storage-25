import os
import io
import time
import requests
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Code to get sfc plots map
def fetch_and_process_sfc_plots(
    available_image_dictionary,
    station_plot_lat,
    station_plot_lon,
    zoom_plot,
    CHROME_DRIVER_PATH,
    CHROMIUM_BIN
):

    # --- Globals this function touches ---
    global sfc_plots_img, last_sfc_plots_update

    # Ensure globals exist
    try:
        _ = station_plot_lat; _ = station_plot_lon; _ = zoom_plot
    except NameError:
        print("[SFC] Missing required globals: station_plot_lat/station_plot_lon/zoom_plot")
        return

    # Config
    timeout_seconds = 30
    retry_attempts = 2   # total tries
    driver = None

    # Quick guard: driver path
    if not CHROME_DRIVER_PATH:
        print("[SFC] ERROR: ChromeDriver path is not set.")
        # Reuse prior image if present
        if sfc_plots_img:
            print("[SFC] Reusing previous image (no driver available).")
        else:
            print("[SFC] No prior image available.")
        return

    # Build URL once (values can be adjusted before each fetch if needed)
    base_url = "https://www.weather.gov/wrh/hazards/"
    extra_params = (
        "&boundaries=false,false,false,false,false,false,false,false,false,false,false"
        "&tab=observation&obs=true&obs_type=weather&elements=temp,dew,wind,gust,slp"
    )
    center_param = f"&center={station_plot_lat},{station_plot_lon}"
    sfc_plots_url = f"{base_url}?&zoom={zoom_plot}&scroll_zoom=false{center_param}{extra_params}"
    
    # Try/retry loop
    for attempt in range(1, retry_attempts + 1):
        try:
            # --- Driver setup ---
            options = Options()
            options.binary_location = CHROMIUM_BIN
            options.add_argument('--headless')
            # keep GPU enabled for RP4 per your note; if you see issues, swap to --disable-gpu
            options.add_argument('--enable-gpu')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')

            desired_aspect_ratio = 1.77  # for RP4
            if os.environ.get("XDG_SESSION_TYPE") == "wayland":
                desired_aspect_ratio = 1.395
            desired_width = 912
            desired_height = int(desired_width / desired_aspect_ratio)
            options.add_argument(f"--window-size={desired_width},{desired_height}")

            service = Service(CHROME_DRIVER_PATH)
            driver = webdriver.Chrome(service=service, options=options)

            # --- Navigate ---
            driver.get(sfc_plots_url)
            
            # Close the panel if present
            try:
                wait = WebDriverWait(driver, timeout_seconds)
                close_btn = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "a.panel-close")))
                close_btn.click()
            except Exception:
                # Not fatal if it doesn't exist / already closed
                pass

            # Hide non-essential elements to clean the screenshot
            try:
                elements_to_hide = [
                    '#feedback2',
                    '#app-nav > ul > li:nth-child(2) > a',
                    '#geocode > div > input',
                    '#app-nav > div.calcite-title.calcite-overflow-hidden > span.calcite-title-sub.hidden-xs'
                ]
                js_hide = "document.querySelectorAll(arguments[0]).forEach(el => el.style.display='none');"
                for sel in elements_to_hide:
                    driver.execute_script(js_hide, sel)

                # Also hide the full right-side overlay/options shell if it appears.
                driver.execute_script("""
                    const selectors = [
                        '.calcite-panels.calcite-panels-right',
                        '#panelLayers',
                        '#headingLayers',
                        '#collapseLayers',
                        '#overlay-body',
                        '#app-tabs'
                    ];
                    selectors.forEach((selector) => {
                        document.querySelectorAll(selector).forEach((el) => {
                            el.style.setProperty('display', 'none', 'important');
                            el.style.setProperty('visibility', 'hidden', 'important');
                            el.style.setProperty('height', '0', 'important');
                            el.style.setProperty('max-height', '0', 'important');
                            el.style.setProperty('width', '0', 'important');
                            el.style.setProperty('max-width', '0', 'important');
                            el.style.setProperty('overflow', 'hidden', 'important');
                            el.style.setProperty('pointer-events', 'none', 'important');
                        });
                    });
                """)
            except Exception:
                pass


            # Give the app time to render observations/timestamp
            time.sleep(10)

            # Timestamp (not fatal if missing)
            try:
                timestamp = driver.execute_script('return document.querySelector("#obs-timestamp")?.innerText || "";')
                if not timestamp:
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M UTC")
            except Exception:
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M UTC")

            # --- Screenshot + PIL ---
            png = driver.get_screenshot_as_png()
            
            img = Image.open(io.BytesIO(png))

            # Crop (same crop as your original)
            cropped = img.crop((42, 0, img.width, img.height))

            # Draw timestamp
            draw = ImageDraw.Draw(cropped)
            font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
            font_size = 12
            try:
                font = ImageFont.truetype(font_path, font_size)
            except Exception:
                font = ImageFont.load_default()
            # fixed position per your code
            draw.text((400, 24), timestamp, fill=(255, 255, 255), font=font)

            # --- Success path: publish image ---
            sfc_plots_img = cropped  # keep PIL image for reuse
            available_image_dictionary['sfc_plots_img'] = (sfc_plots_img, 0, 11)
            
            last_sfc_plots_update = datetime.now()
            # print("[SFC] Updated surface plots image successfully.")
            return

        except Exception as e:
            print(f"[SFC] Attempt {attempt}/{retry_attempts} failed: {e}")

        finally:
            # Always terminate the browser
            if driver:
                try:
                    driver.quit()
                except Exception:
                    pass
            driver = None

    # --- All retries failed: reuse previous image if we have one ---
    if sfc_plots_img:
        print("[SFC] Using previously loaded image due to repeated failures.")
        # keep available_image_dictionary as-is (already points to last good image)
    else:
        print("[SFC] ERROR: No valid image available to display after retries.")
