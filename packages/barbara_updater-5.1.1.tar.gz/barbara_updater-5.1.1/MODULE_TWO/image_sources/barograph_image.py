import os
from datetime import datetime
from PIL import Image, ImageTk, UnidentifiedImageError

def fetch_and_process_baro_pic(available_image_dictionary):
    global last_baro_update

    image_path = "/home/santod/baro_trace.png"

    try:
        if not os.path.exists(image_path):
            print("[ERROR] Barometric pressure image file not found.")
            return

        # Load pixels and close the file handle immediately
        with Image.open(image_path) as im:
            im.load()  # decouple from file
        im = im.crop((8, 8, im.width, im.height - 6)).resize((912, 547), Image.LANCZOS).convert("RGB")

        existing = available_image_dictionary.get("baro_img")
        if isinstance(existing, tuple) and len(existing) == 3 and hasattr(existing[0], "paste"):
            baro_img_tk = existing[0]
            baro_img_tk.paste(im)
        else:
            baro_img_tk = ImageTk.PhotoImage(im)
        available_image_dictionary["baro_img"] = (baro_img_tk, 15, 0)

        last_baro_update = datetime.now()

    except (FileNotFoundError, UnidentifiedImageError) as e:
        print(f"[ERROR] Failed to process barometric pressure image: {e}")
    except Exception as e:
        print(f"[ERROR] Unexpected error updating barometric pressure image: {e}")
