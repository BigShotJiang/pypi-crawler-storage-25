import requests
from PIL import Image, ImageTk, UnidentifiedImageError
from io import BytesIO
from datetime import datetime
from image_sources.radar_utils import convert_gif_to_jpg

# Code for national radar
    
def fetch_and_process_national_radar(available_image_dictionary):
    global last_radar_update

    try:
        # Step 1: Fetch the radar image
        radar_url = 'https://radar.weather.gov/ridge/standard/CONUS_0.gif'
        response = requests.get(radar_url, timeout=10)  # Add a timeout for reliability
        if response.status_code != 200:
            print("[ERROR] Failed to fetch national radar image. Status code:", response.status_code)
            return

        # Step 2: Convert GIF to JPG
        gif_data = response.content
        jpg_data = convert_gif_to_jpg(gif_data)  # Assume this function exists
        img_national_radar = Image.open(BytesIO(jpg_data))

        # Step 3: Resize the image
        img_national_radar = img_national_radar.resize((870, 510), Image.LANCZOS)

        # Step 4: Convert the image to PhotoImage
        radar_img_tk = ImageTk.PhotoImage(img_national_radar)

        # Store the national radar image with padding values in the available image dictionary
        available_image_dictionary["national_radar_img"] = (radar_img_tk, 0, 10)  

        # Step 6: Update the last update time
        last_radar_update = datetime.now()

        #print("[DEBUG] National radar image updated successfully.")

    except requests.exceptions.RequestException as e:
        print("[ERROR] Network error while fetching radar image:", e)
    except UnidentifiedImageError as e:
        print("[ERROR] Cannot identify image file:", e)
    except Exception as e:
        print("[ERROR] Unexpected error while fetching and processing national radar image:", e)
