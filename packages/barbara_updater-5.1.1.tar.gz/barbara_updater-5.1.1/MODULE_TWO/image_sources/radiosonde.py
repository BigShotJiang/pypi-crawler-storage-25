import aiohttp
from io import BytesIO
from datetime import datetime
from PIL import Image, ImageTk, ImageDraw, ImageFont
import asyncio

# code to get the radiosonde
def fetch_and_process_radiosonde(available_image_dictionary, background_loop, sonde_letter_identifier):
    """
    Fetches, processes, and saves a radiosonde image for reuse.
    """
    async def main():
        try:
            scrape_now = datetime.utcnow()
            if scrape_now.hour < 12:
                hour_str = "00"
                date = scrape_now.replace(hour=0, minute=0, second=0, microsecond=0)
            else:
                hour_str = "12"
                date = scrape_now.replace(hour=12, minute=0, second=0, microsecond=0)
            date_str = date.strftime('%y%m%d')

            sonde_sound_url = f"https://www.spc.noaa.gov/exper/soundings/{date_str}{hour_str}_OBS/{sonde_letter_identifier}.gif"

            async with aiohttp.ClientSession() as session:
                async with session.get(sonde_sound_url) as response:
                    if response.status != 200:
                        raise ValueError(f"Failed to fetch image. Status: {response.status}")
                    image_data = await response.read()
            global radiosonde_img
            sonde_sound_img = Image.open(BytesIO(image_data))
            crop_box = (0, 250, sonde_sound_img.width, sonde_sound_img.height)
            sonde_sound_img = sonde_sound_img.crop(crop_box).convert('RGBA')

            aspect_ratio = sonde_sound_img.width / sonde_sound_img.height
            desired_width = 880
            desired_height = int(desired_width / aspect_ratio * 1.18)
            sonde_sound_img = sonde_sound_img.resize((desired_width, desired_height), Image.LANCZOS)

            sonde_sound_img_with_white_bg = Image.new(
                'RGBA',
                (sonde_sound_img.width, sonde_sound_img.height),
                (255, 255, 255, 255)
            )
            sonde_sound_img_with_white_bg.paste(sonde_sound_img, (0, 0), sonde_sound_img)

            draw = ImageDraw.Draw(sonde_sound_img_with_white_bg)
            text = f'{sonde_letter_identifier}\n{scrape_now.strftime("%b %d")} {hour_str} GMT'

            font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
            font_size = 12
            try:
                font = ImageFont.truetype(font_path, font_size)
            except IOError:
                print("[DEBUG] Custom font not found. Using default font.")
                font = ImageFont.load_default()

            text_bbox = draw.textbbox((0, 0), text, font=font)
            text_width = text_bbox[2] - text_bbox[0]
            offset = 90
            text_x = (sonde_sound_img_with_white_bg.width - text_width) // 2 - offset
            text_y = 40
            draw.text((text_x, text_y), text, fill=(0, 0, 0), font=font)

            radiosonde_img = ImageTk.PhotoImage(sonde_sound_img_with_white_bg)
            available_image_dictionary['radiosonde_img'] = (radiosonde_img, 0, 17)
        except Exception as e:
            print(f"Error fetching or processing radiosonde image: {e}")

    # Schedule the coroutine on the background loop
    asyncio.run_coroutine_threadsafe(main(), background_loop)
