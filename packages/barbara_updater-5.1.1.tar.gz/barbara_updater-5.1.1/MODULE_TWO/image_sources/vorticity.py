# Code to get the vorticity image

import requests
from PIL import ImageTk, UnidentifiedImageError, Image
from io import BytesIO
from datetime import datetime

def fetch_and_process_vorticity(available_image_dictionary):
    """
    Conservative, drop-in replacement for the vorticity image fetcher.
    Preserves compatibility by keeping the global name `vorticity_img`
    and the `available_image_dictionary['vorticity_img']` entry, while
    explicitly releasing temporary PIL / BytesIO resources and removing
    the prior references so they can be collected.
    """
    global vorticity_img

    try:
        # choose XX based on UTC hour
        current_time = datetime.utcnow()
        times_intervals = [(2, 8), (8, 14), (14, 20), (20, 26)]
        XX_values = ['00', '06', '12', '18']
        XX = '18'
        for count, (start_hour, end_hour) in enumerate(times_intervals):
            if start_hour <= current_time.hour < end_hour:
                XX = XX_values[count]
                break

        # fetch (with timeout)
        vort_url = f'https://mag.ncep.noaa.gov/data/nam/{XX}/nam_namer_000_500_vort_ht.gif'
        resp = requests.get(vort_url, timeout=10)
        resp.raise_for_status()
        gif_bytes = resp.content  # small; acceptable

        # Open image from bytes, resize, then close intermediates
        bio = BytesIO(gif_bytes)
        img = None
        resized = None
        try:
            img = Image.open(bio)
            # Ensure concrete pixel data (avoid lazy file-backed operations)
            img_concrete = img.convert('RGBA')  # use 'RGB' if you do not need alpha
            resized = img_concrete.resize((820, 510), Image.LANCZOS)
            # close the concrete intermediate as we'll keep only `resized` briefly
            try:
                img_concrete.close()
            except Exception:
                pass
        finally:
            # close the file-backed image and BytesIO
            try:
                if img is not None:
                    img.close()
            except Exception:
                pass
            try:
                bio.close()
            except Exception:
                pass

        # Create PhotoImage from the resized PIL image
        new_photo = ImageTk.PhotoImage(resized)

        # We can close the resized PIL image now that PhotoImage has copied the pixels
        try:
            if resized is not None:
                resized.close()
        except Exception:
            pass

        # Remove previous references so GC/Tcl can free them
        # Pop dict entry first (if present)
        prev = available_image_dictionary.pop('vorticity_img', None)

        # Clear the old global reference (if any) to avoid duplicate refs
        try:
            vorticity_img = None
        except NameError:
            # if it didn't exist previously, ignore
            pass

        # Store new image (preserve old global name for compatibility)
        available_image_dictionary['vorticity_img'] = (new_photo, 0, 16)
        vorticity_img = new_photo

        # Optional: a single lightweight garbage collect here can help long-running processes
        # import gc; gc.collect()

    except requests.exceptions.RequestException as e:
        print("[ERROR] Network error while fetching vorticity image:", e)
    except UnidentifiedImageError as e:
        print("[ERROR] Cannot identify image file:", e)
    except Exception as e:
        print("[ERROR] Unexpected error during fetch and process of vorticity:", e)
