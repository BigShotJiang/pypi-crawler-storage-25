import requests
from PIL import Image, ImageTk, UnidentifiedImageError
from io import BytesIO
from datetime import datetime

def fetch_and_process_national_sfc(available_image_dictionary):
    global national_sfc_img, last_national_sfc_update

    try:
        # Step 1: Fetch the national surface image
        sfc_url = 'https://www.wpc.ncep.noaa.gov/basicwx/92fndfd.jpg'
        response = requests.get(sfc_url)
        if response.status_code != 200:
            print("[ERROR] Failed to fetch national sfc image. Status code:", response.status_code)
            return

        # Step 2: Convert the image to a PIL Image
        img_national_sfc = Image.open(BytesIO(response.content))

        # Step 3: Resize the image
        img_national_sfc = img_national_sfc.resize((840, 510), Image.LANCZOS)

        # Step 4: Convert the image to PhotoImage
        national_sfc_img = ImageTk.PhotoImage(img_national_sfc)

        # Step 5: Store the national surface image with padding values in the available image dictionary
        available_image_dictionary['national_sfc_img'] = (national_sfc_img, 0, 5)  

        # Step 6: Update the last update time
        last_national_sfc_update = datetime.now()

        # [DEBUG] Uncomment if needed: print("[DEBUG] National surface image updated.")

    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Network error while fetching national sfc image: {e}")
    except Image.UnidentifiedImageError as e:
        print(f"[ERROR] Cannot identify image file: {e}")
    except Exception as e:
        print(f"[ERROR] Unexpected error while fetching and processing national sfc image: {e}")
