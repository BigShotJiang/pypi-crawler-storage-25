import os
import time
import json
import base64
import signal
import zlib
import threading
import requests
from io import BytesIO
from datetime import datetime
from queue import Queue
from PIL import Image
from PIL import ImageTk
from PIL import ImageDraw
from PIL import ImageFont
from selenium import webdriver
from selenium.common.exceptions import TimeoutException, SessionNotCreatedException, WebDriverException
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from utils.image_helpers import is_black_image


def _normalize_radar_location_text(raw_text):
    text = " ".join((raw_text or "").split())
    if not text:
        return ""
    text = text.replace(",ME", ", ME").replace(",NH", ", NH").replace(",MA", ", MA")
    text = text.replace(",CT", ", CT").replace(",RI", ", RI").replace(",VT", ", VT")
    text = text.replace(",NY", ", NY").replace(",NJ", ", NJ").replace(",PA", ", PA")
    return text


def _fit_banner_text(draw, text, font, max_width):
    if not text:
        return ""
    if draw.textbbox((0, 0), text, font=font)[2] <= max_width:
        return text

    working_text = text
    replacements = [
        ("Station ", ""),
        (" in ", " "),
        ("International", "Intl"),
        ("Regional", "Reg"),
        ("Municipal", "Muni"),
        ("Airport", "Arpt"),
    ]
    for old, new in replacements:
        if old in working_text:
            candidate = working_text.replace(old, new)
            if draw.textbbox((0, 0), candidate, font=font)[2] <= max_width:
                return candidate
            working_text = candidate

    while len(working_text) > 4:
        candidate = working_text[:-4].rstrip(" ,") + "..."
        if draw.textbbox((0, 0), candidate, font=font)[2] <= max_width:
            return candidate
        working_text = working_text[:-1]
    return working_text


def _draw_radar_location_banner(image, location_text):
    if not location_text:
        return image

    draw = ImageDraw.Draw(image)
    font = None
    for font_path in (
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ):
        try:
            font = ImageFont.truetype(font_path, 16)
            break
        except Exception:
            continue
    if font is None:
        font = ImageFont.load_default()

    fitted_text = _fit_banner_text(draw, _normalize_radar_location_text(location_text), font, max_width=430)
    if not fitted_text:
        return image

    text_bbox = draw.textbbox((0, 0), fitted_text, font=font)
    text_width = text_bbox[2] - text_bbox[0]
    text_height = text_bbox[3] - text_bbox[1]
    text_x = max(255, 830 - text_width)
    text_y = max(4, (34 - text_height) // 2)
    draw.text((text_x, text_y), fitted_text, fill=(35, 35, 35), font=font)
    return image

def fetch_lcl_radar_coordinates(identifier):
    url = f"https://api.weather.gov/radar/stations/{identifier}"
    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        data = response.json()
        lat = data['geometry']['coordinates'][1]
        lon = data['geometry']['coordinates'][0]
        return lon, lat
    except requests.RequestException as e:
        print(f"Network-related error fetching data for radar site {identifier}: {e}")
        return None
        
def generate_lcl_radar_url(radar_identifier, latitude, longitude, zoom_level):
    settings = {
        "agenda": {
            "id": "local",
            "center": [longitude, latitude],
            "location": None,
            "zoom": zoom_level,
            "filter": None,
            "layer": "sr_bref",
            "station": radar_identifier
        },
        "animating": False,
        "base": "standard",
        "artcc": False,
        "county": False,
        "cwa": False,
        "rfc": False,
        "state": False,
        "menu": True,
        "shortFusedOnly": True,
        "opacity": {
            "alerts": 0.0,
            "local": 0.6,
            "localStations": 0.0,
            "national": 0.0
        }
    }
    settings_str = json.dumps(settings)
    encoded_settings = base64.b64encode(settings_str.encode('utf-8')).decode('utf-8')
    return f"https://radar.weather.gov/?settings=v1_{encoded_settings}"
    
def hide_additional_ui_elements(driver):
    wait = WebDriverWait(driver, 10)
    try:
        header_element = wait.until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="app"]/main/div/div/div[1]/div[2]/div'))
        )
        driver.execute_script("arguments[0].style.display='none'", header_element)

        primary_menu = wait.until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="app"]/main/div/div/div[1]'))
        )
        driver.execute_script("arguments[0].style.display='none'", primary_menu)

        buttons_to_hide = driver.find_element(By.XPATH, '//*[@id="app"]/header/div/div[3]')
        driver.execute_script("arguments[0].style.display='none'", buttons_to_hide)
        return True
    except Exception as e:
        print(f"Could not hide additional UI elements: {e}")
        return False
        
def lcl_radar_selenium(CHROME_DRIVER_PATH, CHROMIUM_BIN, max_retries=1, initial_delay=1):
    # First, check if the driver path was successfully set at startup.
    if not CHROME_DRIVER_PATH:
        print("ERROR: ChromeDriver path is not set. Cannot start lcl_radar_selenium.")
        return None

    driver = None
    
    # Define your options, maintaining the ones from your original code
    options = Options()
    options.binary_location = CHROMIUM_BIN
    options.add_argument("--headless")
    #chrome_options.add_argument("--enable-gpu") # Preserving this critical setting
    options.add_argument("--disable-gpu")
    
    # Add other standard arguments for stability
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")

    # The loop and retry logic remains the same
    for attempt in range(max_retries + 1):
        try:
            # Point to the driver path determined at startup
            service = Service(CHROME_DRIVER_PATH)

            # Initialize the driver with the correct service and your specific options
            driver = webdriver.Chrome(service=service, options=options)
            
            # Your original settings
            driver.set_window_size(905, 652)
            driver.set_script_timeout(30)
            
            return driver  # SUCCESS: return driver without closing it

        except (SessionNotCreatedException, TimeoutException, WebDriverException) as e:
            print(f"Attempt {attempt + 1}: Known error initializing Selenium WebDriver: {e}")
        except Exception as e:
            print(f"Attempt {attempt + 1}: Unexpected error initializing Selenium WebDriver: {e}")
        
        # Clean up only if driver was created but failed
        if driver:
            driver.quit()

        if attempt < max_retries:
            time.sleep(initial_delay * (2 ** attempt))

    print("Failed to start Selenium WebDriver after multiple attempts.")
    return None
    
def capture_lcl_radar_screenshots(driver, num_images=10, location_text=""):
    frames_with_timestamps = []
    attempts = 0
    #max_attempts = 20
    max_attempts = max(20, num_images * 3)
    captured_times = set()
    wait = WebDriverWait(driver, 10)

    captured_sigs = set()
    last_sig = None
    while len(frames_with_timestamps) < num_images and attempts < max_attempts:
        try:
            # ... (frame time and number extraction logic remains the same) ...
            frame_time = wait.until(
                EC.visibility_of_element_located((By.XPATH, '//*[@id="app"]/main/div/div/div[2]/div[2]/div[1]/div[1]/div[2]'))
            ).text
            
            if frame_time not in captured_times:
                vcr_controls = driver.find_element(By.XPATH, '//*[@id="app"]/main/div/div/div[2]/div[2]/div[2]')
                legend       = driver.find_element(By.XPATH, '//*[@id="app"]/main/div/div/div[2]/div[2]/div[3]')
                driver.execute_script("arguments[0].style.display='none'", vcr_controls)
                driver.execute_script("arguments[0].style.display='none'", legend)

                png = driver.get_screenshot_as_png()
                image = Image.open(BytesIO(png))
                resized_image = image.resize((850, 515), Image.BILINEAR)
                image.close()
                _draw_radar_location_banner(resized_image, location_text)
                
                # signature over the WHOLE frame to detect radar-echo changes
                thumb = resized_image.convert("RGB").resize((128, 128), Image.BILINEAR)
                sig = zlib.adler32(thumb.tobytes())
                thumb.close()
                # keep only new frames
                if sig not in captured_sigs and sig != last_sig:
                    frames_with_timestamps.append((frame_time, resized_image))
                    captured_sigs.add(sig)
                    last_sig = sig
                else:
                    resized_image.close()  # avoid leaking if we didn’t keep it

                driver.execute_script("arguments[0].style.display='block'", vcr_controls)
                driver.execute_script("arguments[0].style.display='block'", legend)

            # ... (logic to step to the next frame remains the same) ...
            step_fwd_button = wait.until(
                EC.element_to_be_clickable((By.XPATH, '//*[@id="app"]/main/div/div/div[2]/div[2]/div[2]/div[6]'))
            )
            step_fwd_button.click()
            time.sleep(1.5) # This sleep is still needed to wait for the next frame to load
            attempts += 1

        except Exception as e:
            print(f"Error capturing frame: {e}")
            time.sleep(1)
            continue

    timestamp_format = "%m/%d/%y %I:%M %p"
    frames_with_timestamps.sort(key=lambda x: datetime.strptime(x[0], timestamp_format))
    return [frame[1] for frame in frames_with_timestamps]

def fetch_lcl_radar_images(driver, radar_identifier, lcl_radar_zoom_clicks, num_images=10):
    try:
        coordinates = fetch_lcl_radar_coordinates(radar_identifier)
        if not coordinates:
            print("Failed to fetch radar coordinates.")
            return []

        lon, lat = coordinates
        radar_url = generate_lcl_radar_url(
            radar_identifier,
            lat,
            lon,
            6.6 + lcl_radar_zoom_clicks.get()
        )

        driver.get(radar_url)
        time.sleep(4)

        location_text = ""
        try:
            location_text = driver.find_element(
                By.CSS_SELECTOR,
                "#app > main > div > div > div.menu > div.menu-primary.menu-primary-open > div.menu-item.search-container > span",
            ).text
        except Exception:
            try:
                location_text = driver.execute_script("""
                    const el = document.querySelector(
                        '#app > main > div > div > div.menu > div.menu-primary.menu-primary-open > div.menu-item.search-container > span'
                    );
                    return el ? (el.textContent || '').trim() : '';
                """)
            except Exception:
                location_text = ""

        if not hide_additional_ui_elements(driver):
            print("Failed to hide UI elements.")
            return []

        images = capture_lcl_radar_screenshots(driver, num_images=num_images, location_text=location_text)
        return images if images else []

    except TimeoutException as e:
        print(f"TimeoutException: Failed to fetch lcl radar images: {e}")
        driver.save_screenshot('debug_screenshot_navigation.png')
        return []

    except Exception as e:
        print(f"Unexpected error during image fetching: {e}")
        return []

def check_scraping_done(queue, callback, root, available_image_dictionary):
    try:
        while not queue.empty():
            result = queue.get_nowait()

            if result == "DONE":
                #print("[DEBUG] line 8145. lcl radar Scraping process completed. Executing callback.")
                callback()
                return

            elif isinstance(result, list) and result:
                global lcl_radar_frames, lcl_radar_updated_flag
                lcl_radar_frames = result
                available_image_dictionary['lcl_radar_loop_img'] = [(frame, 0, 10) for frame in lcl_radar_frames]

                # ✅ Mark radar loop as ready once at least 3 frames are present
                if len(lcl_radar_frames) >= 3:
                    lcl_radar_updated_flag = True

        root.after(100, lambda: check_scraping_done(queue, callback, root, available_image_dictionary))

    except Exception as e:
        print(f"[ERROR] Error while checking lcl radar scraping status: {e}")
        root.after(100, lambda: check_scraping_done(queue, callback, root, available_image_dictionary))
        
def release_pil_objects(image_list_or_tuples):
    """
    Safely closes all PIL.Image objects within a list,
    even if they are nested inside tuples.
    """
    if not image_list_or_tuples:
        return

    for item in image_list_or_tuples:
        # Determine if the item is a direct image or a tuple (image, ...)
        image_to_close = None
        if isinstance(item, Image.Image):
            image_to_close = item
        elif isinstance(item, tuple) and len(item) > 0 and isinstance(item[0], Image.Image):
            image_to_close = item[0]

        # If we found a valid image, try to close it
        if image_to_close:
            try:
                image_to_close.close()
            except Exception:
                # Ignore errors if it's already closed or not a valid object
                pass

def full_lcl_radar_teardown(available_image_dictionary):
    """
    A single, centralized function to release all memory and
    clear all data associated with the local radar loop.
    """
    global lcl_radar_frames

    #print("[INFO] Performing full teardown of local radar resources.")

    # First, release the memory from the PIL objects in the dictionary
    if 'lcl_radar_loop_img' in available_image_dictionary:
        release_pil_objects(available_image_dictionary['lcl_radar_loop_img'])
        # Now remove the key from the dictionary
        available_image_dictionary.pop('lcl_radar_loop_img', None)

    # Then, release memory from the global frames list and clear it
    if 'lcl_radar_frames' in globals() and lcl_radar_frames:
        release_pil_objects(lcl_radar_frames)
        lcl_radar_frames.clear()
        
def get_lcl_radar_loop(
    available_image_dictionary,
    box_variables,
    root,
    CHROME_DRIVER_PATH,
    CHROMIUM_BIN,
    radar_identifier,
    lcl_radar_zoom_clicks,
    auto_advance_frames
):
    global placeholder_label, lcl_radar_updated_flag
    # ✅ Delete existing radar frames before starting a new scrape
    full_lcl_radar_teardown(available_image_dictionary)
    # ✅ Reset the flag so the display doesn't treat old frames as valid
    lcl_radar_updated_flag = False

    if box_variables[2] == 1:
        image_queue = Queue()

        def scraping_done_callback():
            global lcl_radar_updated_flag
            #print("[DEBUG] line 8437. Local radar loop scraping complete.")
            lcl_radar_updated_flag = True
            auto_advance_frames()

        def run_radar_scrape():
            driver = lcl_radar_selenium(CHROME_DRIVER_PATH, CHROMIUM_BIN)
            if driver is None:
                print("[ERROR] Failed to start Selenium WebDriver. Skipping radar image fetch.")
                image_queue.put("DONE")
                return

            service_pid = driver.service.process.pid

            try:
                while not image_queue.empty():
                    image_queue.get()

                images = fetch_lcl_radar_images(driver, radar_identifier, lcl_radar_zoom_clicks)

                if images:
                    image_queue.put(images)
                else:
                    print("[ERROR] No lcl radar images fetched.")
                    image_queue.put([])

            except Exception as e:
                print(f"[ERROR] Error during local radar image fetch: {e}")
                image_queue.put([])

            finally:
                image_queue.put("DONE")
                driver.quit()
                try:
                    os.kill(service_pid, 0)
                    print(f"[WARNING] chromedriver PID {service_pid} did not exit gracefully. Forcing termination.")
                    os.kill(service_pid, signal.SIGKILL)
                except OSError:
                    pass
                except Exception as e:
                    print(f"[ERROR] Error during final kill of PID {service_pid}: {e}")

        # Start the scraping process
        scraping_thread = threading.Thread(
            target=run_radar_scrape,
        )
        scraping_thread.start()

        # Schedule a callback to check when the scraping is done
        root.after(
            100,
            lambda: check_scraping_done(
                image_queue,
                scraping_done_callback,
                root,
                available_image_dictionary
            )
        )
        
