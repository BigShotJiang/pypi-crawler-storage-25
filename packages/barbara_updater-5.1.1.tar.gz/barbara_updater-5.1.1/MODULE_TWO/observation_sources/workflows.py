from map_rendering import capture_folium_map_screenshot

VALID_STATION_CHOICE_COLORS = [
    "#D94C4C",
    "#4A90E2",
    "#4FAF5A",
    "#E39A2D",
    "#8A5CCF",
]


def get_valid_station_choice_color(index):
    return VALID_STATION_CHOICE_COLORS[index % len(VALID_STATION_CHOICE_COLORS)]


def adjust_browser_window_size(driver, target_width, target_height):
    width, height = driver.execute_script("return [window.innerWidth, window.innerHeight];")
    width_diff = target_width - width
    height_diff = target_height - height
    current_size = driver.get_window_size()
    driver.set_window_size(
        current_size["width"] + width_diff,
        current_size["height"] + height_diff,
    )


def create_station_map_screenshot(
    stations,
    progress_label,
    frame,
    chrome_driver_path,
    calculate_center,
    calculate_zoom_level,
    build_bounds,
    folium_module,
    options_cls,
    service_cls,
    webdriver_module,
    os_module,
    time_module,
):
    if not stations:
        return False

    if progress_label:
        progress_label.config(text="Preparing map to display valid stations")
        frame.update_idletasks()

    center = calculate_center(stations)
    zoom_level = calculate_zoom_level(stations)

    if progress_label:
        progress_label.config(text="Preparing map to display valid stations")
        frame.update_idletasks()

    weather_map = folium_module.Map(
        location=center,
        zoom_start=zoom_level,
        width=450,
        height=300,
        control_scale=False,
        zoom_control=False,
    )

    for index, station in enumerate(stations):
        lat = station.get("latitude")
        lon = station.get("longitude")
        if lat is None or lon is None:
            continue
        flag_color = get_valid_station_choice_color(index)

        folium_module.Marker(
            location=(float(lat), float(lon)),
            icon=folium_module.DivIcon(
                html=(
                    f'<div style="width: 18px; height: 18px; background-color: {flag_color}; '
                    'border: 1px solid black; border-radius: 50%; '
                    'box-shadow: 0px 0px 2px rgba(0, 0, 0, 0.45); '
                    'transform: translate(-50%, -50%);">'
                    "</div>"
                )
            ),
        ).add_to(weather_map)

    bounds = build_bounds(stations)
    if bounds:
        try:
            weather_map.fit_bounds(bounds)
        except Exception:
            weather_map.location = center
            weather_map.zoom_start = zoom_level
    else:
        weather_map.location = center
        weather_map.zoom_start = zoom_level

    map_filename = "station_locations.html"
    weather_map.save(map_filename)
    try:
        return capture_folium_map_screenshot(
            map_filename,
            "station_locations.png",
            chrome_driver_path,
            options_cls,
            service_cls,
            webdriver_module,
            time_module,
            adjust_browser_window_size,
        )
    finally:
        if os_module.path.exists(map_filename):
            os_module.remove(map_filename)


def force_quit_webdriver(driver, os_module, signal_module):
    if not driver:
        return

    pid = None
    try:
        pid = driver.service.process.pid
    except Exception:
        pass

    try:
        driver.quit()
    except Exception:
        pass

    if pid is not None:
        try:
            os_module.kill(pid, 0)
            os_module.kill(pid, signal_module.SIGKILL)
        except OSError:
            pass
        except Exception:
            pass


def start_land_scrape_driver(
    chrome_driver_path,
    options_cls,
    service_cls,
    webdriver_module,
):
    print("-> Starting new Selenium browser instance...")
    if not chrome_driver_path:
        return None

    options = options_cls()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    service = service_cls(chrome_driver_path)
    driver = webdriver_module.Chrome(service=service, options=options)
    driver.set_page_load_timeout(20)
    driver.implicitly_wait(5)
    return driver


def scrape_single_land_station(
    driver,
    station_info,
    input_state,
    by_module,
    build_first_valid_row,
    build_scraped_station_result,
):
    station_id, raw_station_name, station_lat, station_lon, distance_km = station_info
    print(f"-> Checking station: {station_id} ({distance_km:.1f} km away)")

    url = (
        f"https://www.weather.gov/wrh/timeseries?site={station_id}&hours=6&units=english"
        "&chart=off&headers=none&obs=tabular&hourly=false&pview=standard&font=12"
    )
    driver.get(url)

    table = driver.find_element(by_module.ID, "OBS_DATA")
    headers = table.find_elements(by_module.CSS_SELECTOR, "thead tr#HEADER th")
    col_indices = {header.get_attribute("id"): index for index, header in enumerate(headers)}
    idx_temp = col_indices.get("temperature")
    if idx_temp is None:
        return None

    rows = table.find_elements(by_module.CSS_SELECTOR, "tbody tr")
    first_valid_row_tds = build_first_valid_row(rows, idx_temp)
    if not first_valid_row_tds:
        return None

    return build_scraped_station_result(
        station_id,
        raw_station_name,
        station_lat,
        station_lon,
        input_state,
        distance_km,
        first_valid_row_tds,
        col_indices,
    )


def find_and_scrape_land_stations_sequentially(
    station_candidates,
    progress_label,
    frame,
    num_stations_to_find,
    chrome_driver_path,
    options_cls,
    service_cls,
    webdriver_module,
    by_module,
    os_module,
    signal_module,
    input_state,
    build_first_valid_row,
    build_scraped_station_result,
):
    successful_scrapes = []
    driver = None

    def update_progress(message):
        if progress_label is None or frame is None:
            return
        progress_label.config(text=message, font=("Helvetica Neue", 12, "bold"))
        frame.update_idletasks()

    try:
        stations_checked = 0
        total_to_find = num_stations_to_find

        update_progress("Finding nearby stations...")

        for station_info in station_candidates:
            stations_checked += 1

            if len(successful_scrapes) >= total_to_find:
                print(f"-> Found {total_to_find} stations. Stopping search.")
                break

            progress_text = (
                f"Scanned {stations_checked} stations so far, found "
                f"{len(successful_scrapes)} of {total_to_find} valid stations"
            )
            update_progress(progress_text)

            station_id = station_info[0]
            try:
                if driver is None:
                    driver = start_land_scrape_driver(
                        chrome_driver_path,
                        options_cls,
                        service_cls,
                        webdriver_module,
                    )
                    if driver is None:
                        print("[FATAL] Could not start driver. Aborting scrape.")
                        break

                scraped_station = scrape_single_land_station(
                    driver,
                    station_info,
                    input_state,
                    by_module,
                    build_first_valid_row,
                    build_scraped_station_result,
                )
                if not scraped_station:
                    continue

                print(f"   [SUCCESS] Found valid data for {station_id}.")
                successful_scrapes.append(scraped_station)

            except Exception as e:
                print(
                    f"   [INFO] Station {station_id} failed check. Restarting browser. "
                    f"Reason: {type(e).__name__}"
                )
                force_quit_webdriver(driver, os_module, signal_module)
                driver = None
                continue

    finally:
        force_quit_webdriver(driver, os_module, signal_module)

    return successful_scrapes


def fetch_functional_buoy_help_candidates(
    buoy_candidates,
    max_workers,
    check_buoy_help_functionality,
    concurrent_futures_module,
):
    functional_buoys_data = []

    with concurrent_futures_module.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_buoy_id = {
            executor.submit(check_buoy_help_functionality, buoy_id): buoy_id
            for _, buoy_id in buoy_candidates
        }

        for future in concurrent_futures_module.as_completed(future_to_buoy_id):
            try:
                result = future.result()
                if result:
                    buoy_id, timestamp = result
                    print(f"  -> Functional buoy found: {buoy_id}")
                    functional_buys_count = len(functional_buoys_data) + 1
                    functional_buoys_data.append(result)
                    if functional_buys_count >= 3:
                        print("Found 3 functional buoys. Halting search.")
                        executor.shutdown(wait=False, cancel_futures=True)
                        break
            except Exception as e:
                print(f"Error processing a buoy future: {e}")

    return functional_buoys_data[:3]


def build_buoy_help_choice_entries(
    functional_buoys,
    fetch_recent_buoy_observation,
    build_buoy_choice_text,
):
    choice_entries = []

    for buoy in functional_buoys:
        buoy_id, lat, lon, latest_obs_time_utc = buoy

        try:
            recent_observation = fetch_recent_buoy_observation(buoy_id)
            if recent_observation:
                description_text = recent_observation["description_text"]
                buoy_info = build_buoy_choice_text(
                    buoy_id,
                    latest_obs_time_utc,
                    description_text,
                )
            else:
                buoy_info = build_buoy_choice_text(
                    buoy_id,
                    latest_obs_time_utc,
                    "",
                )
        except Exception as e:
            print(f"Failed to scrape details for {buoy_id}: {e}")
            buoy_info = build_buoy_choice_text(
                buoy_id,
                latest_obs_time_utc,
                "",
            )

        choice_entries.append(
            {
                "buoy_id": buoy_id,
                "latitude": lat,
                "longitude": lon,
                "latest_obs_time_utc": latest_obs_time_utc,
                "button_text": buoy_info,
            }
        )

    return choice_entries


def gather_buoy_help_choices(
    current_location,
    metadata_path,
    load_buoy_metadata,
    find_nearest_buoys,
    fetch_functional_candidates,
    build_final_buoy_list,
):
    metadata_result = load_buoy_metadata(path=metadata_path)
    if not metadata_result:
        print("Failed to find any buoys. Aborting.")
        return []

    all_buoys, _, buoy_coord_map = metadata_result

    print("Finding nearest buoys...")
    nearest_buoys = find_nearest_buoys(current_location, all_buoys)

    print(f"Found {len(nearest_buoys)} total buoys. Checking for recent data...")
    functional_buoys_with_time = fetch_functional_candidates(nearest_buoys)
    if len(functional_buoys_with_time) < 3:
        return []

    return build_final_buoy_list(
        functional_buoys_with_time,
        buoy_coord_map,
    )


def resolve_buoy_help_selection(
    buoy_help_flag,
    selected_buoy_code,
    apply_selection_globals,
    globals_dict,
    handlers_by_flag,
):
    apply_selection_globals(
        buoy_help_flag,
        selected_buoy_code,
        globals_dict,
    )
    return handlers_by_flag.get(buoy_help_flag)


def validate_buoy_observation_workflow(
    obs_type,
    buoy_code,
    current_only_click_flag,
    globals_dict,
    get_recent_observation,
    get_buoy_data,
    populate_buoy_globals,
    clear_only_click_flag,
    success_next_command,
    failure_back_command,
    return_to_image_cycle,
):
    try:
        recent_observation = get_recent_observation(buoy_code)
        if not recent_observation:
            raise ValueError(f"Data from buoy {buoy_code} is missing or invalid.")

        print(f"NDBC RSS check OK. Data for {buoy_code} is recent.")
        print(f"-> Pre-fetching data for buoy {buoy_code}...")
        buoy_data_results = get_buoy_data([buoy_code])

        populate_buoy_globals(
            obs_type,
            buoy_code,
            buoy_data_results,
            globals_dict,
        )
        print("   [SUCCESS] Global variables updated.")

        if current_only_click_flag:
            clear_only_click_flag(obs_type, globals_dict)
            next_function = return_to_image_cycle
        else:
            next_function = success_next_command

        return {
            "success": True,
            "message_text": None,
            "next_function": next_function,
            "recent_observation": recent_observation,
        }

    except Exception as e:
        print(f"An error occurred processing buoy {buoy_code}: {e}")
        return {
            "success": False,
            "message_text": (
                f"Data from buoy {buoy_code} is missing or invalid.\n"
                "Please select a different site."
            ),
            "next_function": failure_back_command,
            "recent_observation": None,
        }


def gather_land_station_choices(
    input_town,
    input_state,
    geocode_location,
    load_stations,
    build_candidates,
    scrape_station_choices,
):
    location = geocode_location(f"{input_town}, {input_state}")
    if location is None:
        raise ValueError("Geo-Location failed.")

    stations = load_stations()
    if not stations:
        raise ValueError("Could not load master station list.")

    candidates = build_candidates(
        stations,
        input_state,
        location.latitude,
        location.longitude,
    )

    valid_stations_data = scrape_station_choices(candidates)
    if not valid_stations_data:
        raise ValueError("No functioning stations could be found after checking.")

    return valid_stations_data


def display_station_map_image(
    frame,
    img_path,
    tk_module,
    image_module,
    image_tk_module,
    os_module,
):
    map_displayed = False
    map_container = getattr(frame, "station_map_container", None)
    if map_container is not None:
        try:
            if not map_container.winfo_exists():
                map_container = None
        except Exception:
            map_container = None

    if map_container is None:
        map_container = tk_module.Frame(frame, width=450, height=300, bg="#eef5fb", relief="solid", bd=1)
        map_container.place(x=564, y=184, width=450, height=300)
        map_container.grid_propagate(False)
        frame.station_map_container = map_container

    for child in map_container.winfo_children():
        child.destroy()

    if os_module.path.exists(img_path):
        try:
            img = image_module.open(img_path)
            img = img.resize((450, 300), image_module.LANCZOS)
            tk_img = image_tk_module.PhotoImage(img)
            label = tk_module.Label(map_container, image=tk_img, bd=0, highlightthickness=0)
            label.image = tk_img
            label.place(x=1, y=1, width=448, height=298)
            img.close()
            map_displayed = True
        finally:
            if os_module.path.exists(img_path):
                try:
                    os_module.remove(img_path)
                except OSError as e:
                    print(f"Error removing screenshot file {img_path}: {e}")

    if not map_displayed:
        placeholder_label = tk_module.Label(
            map_container,
            text="Map Unavailable",
            bg="grey",
            fg="white",
            font=("Helvetica", 12),
            justify="center",
        )
        placeholder_label.place(x=1, y=1, width=448, height=298)


def prepare_land_confirmation_display(
    selected_station_data,
    slot_config,
    abbreviation_func,
    globals_dict,
    apply_manual_land_confirmation_globals,
):
    if selected_station_data:
        apply_manual_land_confirmation_globals(
            selected_station_data,
            slot_config,
            abbreviation_func,
            globals_dict,
        )

    display_name = globals_dict.get(slot_config["town_var"], "")
    return selected_station_data or {"name": display_name}


def create_buoy_help_map_screenshot(
    functional_buoys,
    chrome_driver_path,
    calculate_center,
    calculate_zoom_level,
    folium_module,
    options_cls,
    service_cls,
    webdriver_module,
    os_module,
    time_module,
    adjust_window_size_func,
):
    center = calculate_center(functional_buoys)
    zoom_level = calculate_zoom_level(functional_buoys)

    weather_map = folium_module.Map(
        location=center,
        zoom_start=zoom_level,
        width=450,
        height=300,
        control_scale=False,
        zoom_control=False,
    )

    for buoy in functional_buoys:
        folium_module.Marker(
            location=(float(buoy[1]), float(buoy[2])),
            icon=folium_module.Icon(color="blue", icon="info-sign"),
        ).add_to(weather_map)

        folium_module.Marker(
            location=(float(buoy[1]), float(buoy[2])),
            icon=folium_module.DivIcon(
                html=f'''
                    <div style="
                        background-color: white;
                        padding: 2px 5px;
                        border-radius: 3px;
                        box-shadow: 0px 0px 2px rgba(0, 0, 0, 0.5);
                        font-size: 12px;
                        font-weight: bold;
                        text-align: center;
                        width: 50px;
                        transform: translate(-35%, -120%);
                        text-transform: uppercase;
                    ">
                        {buoy[0]}
                    </div>
                '''
            ),
        ).add_to(weather_map)

    if len(functional_buoys) > 1:
        latitudes = [float(buoy[1]) for buoy in functional_buoys]
        longitudes = [float(buoy[2]) for buoy in functional_buoys]
        min_lat, max_lat = min(latitudes), max(latitudes)
        min_lon, max_lon = min(longitudes), max(longitudes)
        padding_factor = 0.1
        lat_padding = (max_lat - min_lat) * padding_factor
        lon_padding = (max_lon - min_lon) * padding_factor
        bounds = [
            [min_lat - lat_padding, min_lon - lon_padding],
            [max_lat + lat_padding, max_lon + lon_padding],
        ]
        weather_map.fit_bounds(bounds)

    map_filename = "buoy_locations.html"
    weather_map.save(map_filename)

    try:
        return capture_folium_map_screenshot(
            map_filename,
            "buoy_locations.png",
            chrome_driver_path,
            options_cls,
            service_cls,
            webdriver_module,
            time_module,
            adjust_window_size_func,
        )
    finally:
        if os_module.path.exists(map_filename):
            os_module.remove(map_filename)


def submit_buoy_help_town_workflow(
    town,
    state,
    geolocator,
    find_buoy_choice,
):
    location = geolocator.geocode(f"{town}, {state}", timeout=10)
    if location:
        buoy_search_lat = float(location.latitude)
        buoy_search_lon = float(location.longitude)
        find_buoy_choice(buoy_search_lat, buoy_search_lon)
        return True

    print(f"Could not find location: {town}, {state}. Please check the input.")
    return False


def submit_buoy_help_coord_workflow(
    lat_value,
    lon_value,
    parse_coordinates,
    find_buoy_choice,
):
    buoy_search_lat, buoy_search_lon = parse_coordinates(lat_value, lon_value)
    find_buoy_choice(buoy_search_lat, buoy_search_lon)
    return buoy_search_lat, buoy_search_lon


def submit_buoy_help_near_me_workflow(
    latitude,
    longitude,
    find_buoy_choice,
):
    find_buoy_choice(latitude, longitude)
    return latitude, longitude
