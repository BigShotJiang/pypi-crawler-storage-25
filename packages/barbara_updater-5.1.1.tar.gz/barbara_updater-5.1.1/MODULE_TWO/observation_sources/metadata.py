from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class ObservationSiteMetadata:
    station_id: str
    display_name: str
    provider: str = ""
    state: str = ""
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    is_airport: bool = False
    raw_name: str = ""


def normalize_station_id(station_id: str) -> str:
    if not station_id:
        return ""
    return str(station_id).strip().upper()


def looks_like_airport_station(station_id: str, station_name: str = "") -> bool:
    sid = normalize_station_id(station_id)
    name = (station_name or "").strip().lower()

    airport_words = (
        "airport",
        "airfield",
        "jetport",
        "municipal",
        "regional airport",
        "international airport",
    )

    if len(sid) == 4 and sid.startswith("K"):
        return True

    if any(word in name for word in airport_words):
        return True

    return False


def choose_display_name(
    station_id: str,
    station_name: str = "",
    fallback_name: str = "",
) -> str:
    station_name = (station_name or "").strip()
    fallback_name = (fallback_name or "").strip()
    sid = normalize_station_id(station_id)

    if station_name:
        return station_name

    if fallback_name:
        return fallback_name

    return sid


def build_site_metadata(
    station_id: str,
    station_name: str = "",
    provider: str = "",
    state: str = "",
    latitude: Optional[float] = None,
    longitude: Optional[float] = None,
    fallback_name: str = "",
) -> ObservationSiteMetadata:
    sid = normalize_station_id(station_id)
    display_name = choose_display_name(
        station_id=sid,
        station_name=station_name,
        fallback_name=fallback_name,
    )

    return ObservationSiteMetadata(
        station_id=sid,
        display_name=display_name,
        provider=(provider or "").strip(),
        state=(state or "").strip(),
        latitude=latitude,
        longitude=longitude,
        is_airport=looks_like_airport_station(sid, station_name),
        raw_name=(station_name or "").strip(),
    )
    
def clean_station_name(raw_station_name: str) -> str:
    cleaned_name = raw_station_name or ""
    name_parts = cleaned_name.split(" ", 1)

    if len(name_parts) > 1 and any(char.isdigit() for char in name_parts[0]):
        cleaned_name = name_parts[1].strip()
    else:
        cleaned_name = cleaned_name.strip()

    return cleaned_name.title()
    
def build_selected_station_details(station_data: dict, buoy_id_set, abbreviation_func) -> dict:
    station_id = station_data["id"]
    station_state = station_data.get("state", "")
    latitude = station_data["latitude"]
    longitude = station_data["longitude"]
    is_buoy = station_id in buoy_id_set

    if is_buoy:
        abbreviated_name = normalize_station_id(station_id)
    else:
        cleaned_name = clean_station_name(station_data["name"])
        try:
            abbreviated_name = abbreviation_func(cleaned_name, station_state)
        except NameError:
            abbreviated_name = f"{cleaned_name}, {station_state}"

    return {
        "station_id": station_id,
        "station_state": station_state,
        "latitude": latitude,
        "longitude": longitude,
        "abbreviated_name": abbreviated_name,
        "is_buoy": is_buoy,
        "station_identifier": "" if is_buoy else station_id,
        "buoy_code": station_id if is_buoy else "",
    }

def apply_station_details_to_globals(station_details: dict, slot: dict, globals_dict: dict) -> None:
    globals_dict[slot['lat_var']] = station_details["latitude"]
    globals_dict[slot['lon_var']] = station_details["longitude"]
    globals_dict[slot['town_var']] = station_details["abbreviated_name"]
    globals_dict[slot['signal_var']] = station_details["is_buoy"]
    globals_dict[slot['id_var']] = station_details["station_identifier"]
    globals_dict[slot['buoy_var']] = station_details["buoy_code"]
    
    
def populate_multiple_selected_station_globals(
    selected_stations: list,
    buoy_id_set,
    abbreviation_func,
    station_slots: list,
    globals_dict: dict,
) -> None:
    for station_data, slot in zip(selected_stations, station_slots):
        station_details = build_selected_station_details(
            station_data,
            buoy_id_set,
            abbreviation_func,
        )
        apply_station_details_to_globals(station_details, slot, globals_dict)
  
def get_random_station_slots() -> list:
    return [
        {'id_var': 'aobs_station_identifier', 'buoy_var': 'aobs_buoy_code', 'signal_var': 'aobs_buoy_signal', 'town_var': 'alternative_town_1', 'lat_var': 'aobs_random_obs_lat', 'lon_var': 'aobs_random_obs_lon'},
        {'id_var': 'bobs_station_identifier', 'buoy_var': 'bobs_buoy_code', 'signal_var': 'bobs_buoy_signal', 'town_var': 'alternative_town_2', 'lat_var': 'bobs_random_obs_lat', 'lon_var': 'bobs_random_obs_lon'},
        {'id_var': 'cobs_station_identifier', 'buoy_var': 'cobs_buoy_code', 'signal_var': 'cobs_buoy_signal', 'town_var': 'alternative_town_3', 'lat_var': 'cobs_random_obs_lat', 'lon_var': 'cobs_random_obs_lon'}
    ]

def populate_random_station_selection_globals(
    selected_stations: list,
    buoy_id_set,
    abbreviation_func,
    globals_dict: dict,
) -> None:
    station_slots = get_random_station_slots()
    populate_multiple_selected_station_globals(
        selected_stations,
        buoy_id_set,
        abbreviation_func,
        station_slots,
        globals_dict,
    )

def _land_station_has_recent_complete_report(properties) -> bool:
    from dateutil import parser
    from datetime import datetime, timedelta, timezone

    ts = properties.get("timestamp")
    if not ts:
        return False

    observation_time = parser.parse(ts).astimezone(timezone.utc)
    if (datetime.now(timezone.utc) - observation_time) > timedelta(hours=2):
        return False

    temp_value = properties.get("temperature", {}).get("value")
    wind_speed_value = properties.get("windSpeed", {}).get("value")
    wind_direction_value = properties.get("windDirection", {}).get("value")
    text_description = (properties.get("textDescription") or "").lower()
    raw_message = (properties.get("rawMessage") or "").upper()
    calm_report = "calm" in text_description or "00000KT" in raw_message
    has_wind_signal = wind_speed_value is not None or wind_direction_value is not None or calm_report

    return temp_value is not None or has_wind_signal


def _degrees_to_cardinal(degrees) -> str:
    if degrees is None:
        return "Var."
    try:
        value = float(degrees) % 360
    except (TypeError, ValueError):
        return "Var."
    directions = [
        "N", "NNE", "NE", "ENE",
        "E", "ESE", "SE", "SSE",
        "S", "SSW", "SW", "WSW",
        "W", "WNW", "NW", "NNW",
    ]
    index = int((value + 11.25) // 22.5) % 16
    return directions[index]


def _celsius_to_rounded_fahrenheit(value) -> str:
    if value is None:
        return "N/A"
    try:
        return f"{round((float(value) * 9 / 5) + 32)}°"
    except (TypeError, ValueError):
        return "N/A"


def _wind_measurement_to_mph(measurement):
    if not isinstance(measurement, dict):
        return None

    value = measurement.get("value")
    if value is None:
        return None

    unit_code = str(measurement.get("unitCode") or "").strip().lower()

    try:
        numeric_value = float(value)
    except (TypeError, ValueError):
        return None

    if unit_code in {"wmoUnit:m_s-1".lower(), "m/s", "mps"}:
        return round(numeric_value * 2.23694)
    if unit_code in {"wmoUnit:km_h-1".lower(), "km/h", "kph", "km/hr"}:
        return round(numeric_value * 0.621371)
    if unit_code in {"wmoUnit:kn".lower(), "kn", "kt", "kts", "knot", "knots"}:
        return round(numeric_value * 1.15078)

    # Match the older working behavior more closely when the unit is missing.
    return round(numeric_value * 0.621371)


def build_land_station_observation_summary(properties: dict) -> tuple[str, str]:
    observation_fields = build_land_station_observation_fields(properties)
    temp = observation_fields["temperature"]

    if observation_fields["calm"]:
        return temp, "Calm"

    wind_speed_mph = observation_fields["wind_speed"]
    wind_gust_mph = observation_fields["wind_gust"]
    wind_direction = observation_fields["wind_direction"]

    if wind_speed_mph is None and wind_gust_mph is None:
        return temp, "N/A"

    base_speed = wind_speed_mph if wind_speed_mph is not None else 0
    wind = f"{wind_direction} at {base_speed} mph"
    if wind_gust_mph is not None and wind_gust_mph > max(base_speed, 0):
        wind += f" G{wind_gust_mph}"

    return temp, wind


def build_land_station_observation_fields(properties: dict) -> dict:
    temp_value = properties.get("temperature", {}).get("value")
    wind_speed_measurement = properties.get("windSpeed", {})
    wind_direction_value = properties.get("windDirection", {}).get("value")
    wind_gust_measurement = properties.get("windGust", {})
    text_description = (properties.get("textDescription") or "").lower()
    raw_message = (properties.get("rawMessage") or "").upper()

    calm_report = "calm" in text_description or "00000KT" in raw_message

    return {
        "temperature": _celsius_to_rounded_fahrenheit(temp_value).replace("°", ""),
        "wind_speed": _wind_measurement_to_mph(wind_speed_measurement),
        "wind_gust": _wind_measurement_to_mph(wind_gust_measurement),
        "wind_direction": _degrees_to_cardinal(wind_direction_value),
        "calm": calm_report,
    }


def fetch_valid_land_station_ids_fast(station_ids: list[str]) -> dict[str, tuple[str, str]]:
    import asyncio
    import aiohttp

    if not station_ids:
        return {}

    async def runner() -> dict[str, tuple[str, str]]:
        valid_data = {}
        # For random-site discovery, slow stations should simply lose the race.
        timeout = aiohttp.ClientTimeout(total=2.2, connect=0.8, sock_read=1.2)
        connector = aiohttp.TCPConnector(limit=80, limit_per_host=80)
        headers = {
            "User-Agent": "The Weather Observer random site checker",
            "Accept": "application/geo+json, application/json",
        }
        semaphore = asyncio.Semaphore(80)

        async with aiohttp.ClientSession(timeout=timeout, connector=connector, headers=headers) as session:
            async def fetch_one(station_id: str):
                url = f"https://api.weather.gov/stations/{station_id}/observations/latest"
                try:
                    async with semaphore:
                        async with session.get(url) as response:
                            if response.status >= 400:
                                return None
                            payload = await response.json()
                    properties = payload.get("properties", {})
                    if _land_station_has_recent_complete_report(properties):
                        return station_id, build_land_station_observation_summary(properties)
                except Exception:
                    return None
                return None

            results = await asyncio.gather(*(fetch_one(station_id) for station_id in station_ids))
            for result in results:
                if result:
                    station_id, observation_summary = result
                    valid_data[station_id] = observation_summary
        return valid_data

    return asyncio.run(runner())


def get_random_station_config() -> dict:
    return {
        "selection_count": 3,
        "search_radii": [20, 50, 100],
        "validation_chunk_size": 16,
        "buoy_worker_count": 6,
        "initial_message": "Please wait while 3 random sites are chosen for you.",
        "progress_message_template": "Searching for stations within {radius} miles...",
        "map_build_message": "Building map to show location of 3 sites...",
        "preload_message": "Pre-loading weather observations...",
        "empty_cache_message": "The pre-filtered random candidate station cache is empty.",
        "failure_message": "Could not find 3 functioning stations within the maximum 100 mile radius.",
    }

def find_valid_random_stations(
    candidate_stations: list,
    center_lat: float,
    center_lon: float,
    search_radii: list,
    selection_count: int,
    progress_label,
    frame,
    check_station_functionality,
    buoy_id_set,
    precomputed_radius_pools=None,
) -> list:
    import concurrent.futures
    import math
    import random

    if not candidate_stations or selection_count <= 0:
        return []

    random_station_config = get_random_station_config()

    def build_bounds(radius_miles: float):
        lat_deg_per_mile = 1.0 / 69.0
        lon_deg_per_mile = 1.0 / (math.cos(math.radians(center_lat)) * 69.0)
        lat_delta = radius_miles * lat_deg_per_mile
        lon_delta = radius_miles * lon_deg_per_mile
        return (
            center_lat - lat_delta,
            center_lat + lat_delta,
            center_lon - lon_delta,
            center_lon + lon_delta,
        )

    def in_bounds(station: dict, bounds: tuple) -> bool:
        min_lat, max_lat, min_lon, max_lon = bounds
        return (
            min_lat <= station["latitude"] <= max_lat
            and min_lon <= station["longitude"] <= max_lon
        )

    valid_stations = []
    valid_land_observations = {}
    valid_station_ids = set()
    checked_station_ids = set()
    previous_bounds = None
    chunk_size = max(selection_count + 1, random_station_config.get("validation_chunk_size", 6))
    buoy_worker_count = random_station_config.get("buoy_worker_count", 3)

    for radius in search_radii:
        progress_label.config(
            text=f"Searching for stations within {radius} miles..."
        )
        frame.update_idletasks()

        current_bounds = build_bounds(radius)
        newly_added_stations = []
        source_stations = candidate_stations
        if precomputed_radius_pools and radius in precomputed_radius_pools:
            source_stations = precomputed_radius_pools[radius] or []

        for station in source_stations:
            station_id = station.get("id")
            if not station_id or station_id in checked_station_ids:
                continue
            if not in_bounds(station, current_bounds):
                continue
            if previous_bounds is not None and in_bounds(station, previous_bounds):
                continue
            newly_added_stations.append(station)

        previous_bounds = current_bounds

        if not newly_added_stations:
            continue

        print(
            f"[RANDOM] Radius {radius} miles has {len(newly_added_stations)} unchecked candidate station(s). "
            f"Testing them in batches of {chunk_size}."
        )
        random.shuffle(newly_added_stations)

        for start_index in range(0, len(newly_added_stations), chunk_size):
            chunk = newly_added_stations[start_index:start_index + chunk_size]
            print(
                f"[RANDOM] Validating batch {start_index // chunk_size + 1} at {radius} miles: "
                f"{len(chunk)} station(s)."
            )
            for station in chunk:
                station_id = station.get("id")
                if station_id:
                    checked_station_ids.add(station_id)

            land_stations = [station for station in chunk if station.get("id") not in buoy_id_set]
            buoy_stations = [station for station in chunk if station.get("id") in buoy_id_set]

            valid_land_data = fetch_valid_land_station_ids_fast(
                [station["id"] for station in land_stations if station.get("id")]
            )
            valid_land_ids = set(valid_land_data.keys())
            valid_buoy_ids = set()

            if buoy_stations:
                with concurrent.futures.ThreadPoolExecutor(max_workers=buoy_worker_count) as executor:
                    future_to_station = {
                        executor.submit(check_station_functionality, station["id"], buoy_id_set): station
                        for station in buoy_stations
                        if station.get("id")
                    }
                    for future in concurrent.futures.as_completed(future_to_station):
                        station = future_to_station[future]
                        try:
                            if future.result():
                                valid_buoy_ids.add(station["id"])
                        except Exception:
                            pass

            print(
                f"[RANDOM] Batch result at {radius} miles: "
                f"{len(valid_land_ids)} valid land, {len(valid_buoy_ids)} valid buoy."
            )

            for station in chunk:
                station_id = station.get("id")
                if not station_id or station_id in valid_station_ids:
                    continue
                if station_id in valid_land_ids or station_id in valid_buoy_ids:
                    valid_station_ids.add(station_id)
                    valid_stations.append(station)
                    if station_id in valid_land_data:
                        valid_land_observations[station_id] = valid_land_data[station_id]
                    if len(valid_stations) >= selection_count:
                        return valid_stations[:selection_count], valid_land_observations

    return valid_stations[:selection_count], valid_land_observations
    
def check_random_station_functionality(station_id, buoy_id_set):
    import requests
    import threading
    from xml.etree import ElementTree
    from dateutil import parser
    from datetime import datetime, timedelta, timezone

    session_local = getattr(check_random_station_functionality, "_session_local", None)
    if session_local is None:
        session_local = threading.local()
        check_random_station_functionality._session_local = session_local

    session = getattr(session_local, "session", None)
    if session is None:
        session = requests.Session()
        session.headers.update({
            "User-Agent": "The Weather Observer random site checker",
            "Accept": "application/geo+json, application/json",
        })
        session_local.session = session

    if station_id in buoy_id_set:
        rss_url = f"https://www.ndbc.noaa.gov/data/latest_obs/{station_id.lower()}.rss"
        try:
            response = session.get(rss_url, timeout=8)
            if response.status_code != 200:
                return False

            root = ElementTree.fromstring(response.content)
            desc_element = root.find('.//channel/item/description')
            if desc_element is None or not desc_element.text:
                return False

            description_text = desc_element.text
            timestamp_line = description_text.strip().split('<br />')[0]
            timestamp_clean = timestamp_line.replace('<strong>', '').replace('</strong>', '').strip()
            if not timestamp_clean:
                return False

            last_obs_time = parser.parse(timestamp_clean, ignoretz=True)
            if (datetime.now() - last_obs_time) > timedelta(hours=2):
                return False

            parameter_count = sum(
                1 for key in [
                    "Air Temperature:",
                    "Water Temperature:",
                    "Wind Direction:",
                    "Wind Speed:",
                ]
                if key in description_text
            )
            return parameter_count >= 3

        except Exception:
            return False

    url = f"https://api.weather.gov/stations/{station_id}/observations/latest"
    try:
        response = session.get(url, timeout=8)
        response.raise_for_status()
        data = response.json()
        properties = data.get("properties", {})
        ts = properties.get("timestamp")
        if not ts:
            return False

        observation_time = parser.parse(ts).astimezone(timezone.utc)
        if (datetime.now(timezone.utc) - observation_time) > timedelta(hours=2):
            return False

        temp_value = properties.get("temperature", {}).get("value")
        wind_speed_value = properties.get("windSpeed", {}).get("value")
        wind_direction_value = properties.get("windDirection", {}).get("value")
        text_description = (properties.get("textDescription") or "").lower()
        raw_message = (properties.get("rawMessage") or "").upper()
        calm_report = "calm" in text_description or "00000KT" in raw_message
        has_wind_signal = wind_speed_value is not None or wind_direction_value is not None or calm_report

        return temp_value is not None or has_wind_signal

    except requests.exceptions.HTTPError:
        return False
    except Exception:
        return False
        
def preload_random_station_observations(
    aobs_buoy_signal,
    aobs_station_identifier,
    aobs_buoy_code,
    bobs_buoy_signal,
    bobs_station_identifier,
    bobs_buoy_code,
    cobs_buoy_signal,
    cobs_station_identifier,
    cobs_buoy_code,
    scrape_land_station_data,
    get_buoy_data,
    initial_land_data=None,
):
    land_data = dict(initial_land_data or {})
    land_to_scrape = [
        sid for is_buoy, sid in [
            (aobs_buoy_signal, aobs_station_identifier),
            (bobs_buoy_signal, bobs_station_identifier),
            (cobs_buoy_signal, cobs_station_identifier),
        ]
        if not is_buoy and sid
    ]

    buoys_to_scrape = [
        code for is_buoy, code in [
            (aobs_buoy_signal, aobs_buoy_code),
            (bobs_buoy_signal, bobs_buoy_code),
            (cobs_buoy_signal, cobs_buoy_code),
        ]
        if is_buoy and code
    ]

    missing_land_ids = [sid for sid in land_to_scrape if sid not in land_data]
    if missing_land_ids:
        land_data.update(scrape_land_station_data(missing_land_ids))
    buoy_data = get_buoy_data(buoys_to_scrape) if buoys_to_scrape else {}

    return land_data, buoy_data


def build_random_station_observation_values(
    is_buoy,
    station_identifier,
    buoy_code,
    land_data,
    buoy_data,
):
    if is_buoy:
        temp, water_temp, wind = buoy_data.get(buoy_code, ("N/A", "N/A", "N/A"))
        return {
            "temp": temp,
            "water_temp": water_temp,
            "wind": wind,
        }

    temp, wind = land_data.get(station_identifier, ("N/A", "N/A"))
    return {
        "temp": temp,
        "water_temp": "",
        "wind": wind,
    }


def populate_random_station_observation_globals(
    land_data,
    buoy_data,
    globals_dict,
):
    station_slots = [
        {
            "signal_var": "aobs_buoy_signal",
            "id_var": "aobs_station_identifier",
            "buoy_var": "aobs_buoy_code",
            "temp_var": "atemp",
            "water_temp_var": "awtemp",
            "wind_var": "awind",
        },
        {
            "signal_var": "bobs_buoy_signal",
            "id_var": "bobs_station_identifier",
            "buoy_var": "bobs_buoy_code",
            "temp_var": "btemp",
            "water_temp_var": "bwtemp",
            "wind_var": "bwind",
        },
        {
            "signal_var": "cobs_buoy_signal",
            "id_var": "cobs_station_identifier",
            "buoy_var": "cobs_buoy_code",
            "temp_var": "ctemp",
            "water_temp_var": "cwtemp",
            "wind_var": "cwind",
        },
    ]

    for slot in station_slots:
        observation_values = build_random_station_observation_values(
            globals_dict[slot["signal_var"]],
            globals_dict[slot["id_var"]],
            globals_dict[slot["buoy_var"]],
            land_data,
            buoy_data,
        )

        globals_dict[slot["temp_var"]] = observation_values["temp"]
        globals_dict[slot["water_temp_var"]] = observation_values["water_temp"]
        globals_dict[slot["wind_var"]] = observation_values["wind"]


def build_land_station_wind_text(selected_station_data: dict) -> str:
    wind_dir = selected_station_data.get("wind_direction", "")
    wind_speed = selected_station_data.get("wind_speed", "N/A")
    wind_gust = selected_station_data.get("wind_gust")

    wind_text = f"{wind_dir} at {wind_speed} mph"
    if wind_gust is not None:
        wind_text += f" G{wind_gust}"

    return wind_text


def build_manual_land_confirmation_details(
    selected_station_data: dict,
    abbreviation_func,
) -> dict:
    station_identifier = selected_station_data["identifier"]
    station_name = selected_station_data.get("name", "N/A")
    station_state = selected_station_data.get("state", "")

    try:
        abbreviated_name = abbreviation_func(station_name, station_state)
    except NameError:
        abbreviated_name = f"{station_name}, {station_state}"

    return {
        "station_identifier": station_identifier,
        "abbreviated_name": abbreviated_name,
        "buoy_signal": False,
        "temp": f"{selected_station_data.get('temperature', 'N/A')}°",
        "wind": build_land_station_wind_text(selected_station_data),
        "water_temp": "",
    }


def apply_manual_land_confirmation_globals(
    selected_station_data: dict,
    slot: dict,
    abbreviation_func,
    globals_dict: dict,
) -> None:
    confirmation_details = build_manual_land_confirmation_details(
        selected_station_data,
        abbreviation_func,
    )

    globals_dict[slot["id_var"]] = confirmation_details["station_identifier"]
    globals_dict[slot["town_var"]] = confirmation_details["abbreviated_name"]
    globals_dict[slot["signal_var"]] = confirmation_details["buoy_signal"]
    globals_dict[slot["temp_var"]] = confirmation_details["temp"]
    globals_dict[slot["wind_var"]] = confirmation_details["wind"]
    globals_dict[slot["water_temp_var"]] = confirmation_details["water_temp"]


def get_obs_slot_config(obs_type: str) -> dict:
    slot_configs = {
        "aobs": {
            "ordinal": "first",
            "town_var": "alternative_town_1",
            "signal_var": "aobs_buoy_signal",
            "buoy_var": "aobs_buoy_code",
            "temp_var": "atemp",
            "water_temp_var": "awtemp",
            "wind_var": "awind",
            "only_click_flag_var": "aobs_only_click_flag",
        },
        "bobs": {
            "ordinal": "second",
            "town_var": "alternative_town_2",
            "signal_var": "bobs_buoy_signal",
            "buoy_var": "bobs_buoy_code",
            "temp_var": "btemp",
            "water_temp_var": "bwtemp",
            "wind_var": "bwind",
            "only_click_flag_var": "bobs_only_click_flag",
        },
        "cobs": {
            "ordinal": "third",
            "town_var": "alternative_town_3",
            "signal_var": "cobs_buoy_signal",
            "buoy_var": "cobs_buoy_code",
            "temp_var": "ctemp",
            "water_temp_var": "cwtemp",
            "wind_var": "cwind",
            "only_click_flag_var": "cobs_only_click_flag",
        },
    }
    return slot_configs.get(obs_type, {})


def get_obs_ordinal(obs_type: str) -> str:
    slot = get_obs_slot_config(obs_type)
    return slot.get("ordinal", "[unknown]")


def apply_buoy_selection_globals(
    obs_type: str,
    buoy_code: str,
    globals_dict: dict,
) -> dict:
    slot = get_obs_slot_config(obs_type)
    if not slot:
        return {
            "ordinal": "[unknown]",
            "current_only_click_flag": False,
        }

    globals_dict[slot["signal_var"]] = True
    globals_dict[slot["buoy_var"]] = buoy_code

    return {
        "ordinal": slot["ordinal"],
        "current_only_click_flag": globals_dict[slot["only_click_flag_var"]],
    }


def apply_buoy_display_name(
    obs_type: str,
    buoy_code: str,
    globals_dict: dict,
) -> None:
    slot = get_obs_slot_config(obs_type)
    if slot:
        globals_dict[slot["town_var"]] = normalize_station_id(buoy_code)


def populate_single_buoy_observation_globals(
    obs_type: str,
    buoy_code: str,
    buoy_data_results: dict,
    globals_dict: dict,
) -> None:
    slot = get_obs_slot_config(obs_type)
    if not slot:
        return

    temp, water_temp, wind = buoy_data_results.get(buoy_code, ("N/A", "N/A", "N/A"))
    globals_dict[slot["temp_var"]] = temp
    globals_dict[slot["water_temp_var"]] = water_temp
    globals_dict[slot["wind_var"]] = wind


def clear_obs_only_click_flag(obs_type: str, globals_dict: dict) -> None:
    slot = get_obs_slot_config(obs_type)
    if slot:
        globals_dict[slot["only_click_flag_var"]] = False


def build_state_station_candidates(
    stations: list,
    input_state: str,
    center_latitude: float,
    center_longitude: float,
    distance_func,
) -> list:
    candidates = [
        (
            station["id"],
            station["name"],
            station["latitude"],
            station["longitude"],
            distance_func(
                (center_latitude, center_longitude),
                (station["latitude"], station["longitude"]),
            ).km,
        )
        for station in stations
        if station["state"] == input_state
    ]
    candidates.sort(key=lambda station: station[4])
    return candidates


def fetch_valid_land_station_choices_fast(
    station_candidates: list,
    input_state: str,
    num_stations_to_find: int,
    progress_label=None,
    frame=None,
):
    import asyncio
    import aiohttp
    from dateutil import parser

    if not station_candidates or num_stations_to_find <= 0:
        return []

    batch_size = 18

    async def runner():
        valid_choices = []
        timeout = aiohttp.ClientTimeout(total=2.2, connect=0.8, sock_read=1.2)
        connector = aiohttp.TCPConnector(limit=40, limit_per_host=40)
        headers = {
            "User-Agent": "The Weather Observer land station chooser",
            "Accept": "application/geo+json, application/json",
        }
        semaphore = asyncio.Semaphore(40)

        async with aiohttp.ClientSession(timeout=timeout, connector=connector, headers=headers) as session:
            async def fetch_one(candidate):
                station_id, raw_station_name, station_lat, station_lon, distance_km = candidate
                url = f"https://api.weather.gov/stations/{station_id}/observations/latest"
                try:
                    async with semaphore:
                        async with session.get(url) as response:
                            if response.status >= 400:
                                return None
                            payload = await response.json()
                    properties = payload.get("properties", {})
                    if not _land_station_has_recent_complete_report(properties):
                        return None

                    timestamp = properties.get("timestamp")
                    time_str = "N/A"
                    if timestamp:
                        try:
                            time_str = parser.parse(timestamp).strftime("%H:%MZ")
                        except Exception:
                            pass

                    observation_fields = build_land_station_observation_fields(properties)
                    return {
                        "identifier": station_id,
                        "name": clean_station_name(raw_station_name),
                        "latitude": station_lat,
                        "longitude": station_lon,
                        "state": input_state,
                        "distance_km": distance_km,
                        "time": time_str,
                        "temperature": observation_fields["temperature"],
                        "wind_speed": observation_fields["wind_speed"] if observation_fields["wind_speed"] is not None else "N/A",
                        "wind_gust": observation_fields["wind_gust"],
                        "wind_direction": "Calm" if observation_fields["calm"] else observation_fields["wind_direction"],
                    }
                except Exception:
                    return None

            total_candidates = len(station_candidates)
            for start in range(0, total_candidates, batch_size):
                batch = station_candidates[start:start + batch_size]
                scanned = min(start + len(batch), total_candidates)
                progress_text = (
                    f"Checked {scanned} nearby stations so far, found "
                    f"{len(valid_choices)} of {num_stations_to_find} valid stations"
                )
                if progress_label is not None:
                    progress_label.config(text=progress_text, font=("Helvetica Neue", 12, "bold"))
                if frame is not None:
                    frame.update_idletasks()

                batch_results = await asyncio.gather(*(fetch_one(candidate) for candidate in batch))
                for result in batch_results:
                    if result:
                        valid_choices.append(result)
                        if len(valid_choices) >= num_stations_to_find:
                            return valid_choices[:num_stations_to_find]

        return valid_choices[:num_stations_to_find]

    return asyncio.run(runner())


def find_first_valid_temperature_row(rows, temp_index):
    for row in rows[:3]:
        tds = row.find_elements("tag name", "td")
        if len(tds) > temp_index and tds[temp_index].text.strip():
            return tds
    return None


def parse_wind_observation(tds, col_indices: dict) -> dict:
    idx_winddir = col_indices.get("wind_dir")
    idx_wind = col_indices.get("wind_speedgust")
    wind_direction, wind_speed, wind_gust = "", "N/A", None

    if idx_winddir is not None and idx_wind is not None and len(tds) > max(idx_winddir, idx_wind):
        wind_dir_val = tds[idx_winddir].text.strip()
        wind_cell = tds[idx_wind].text.strip()
        if wind_cell and wind_dir_val:
            wind_direction = wind_dir_val
            parts = wind_cell.split("G", 1)
            try:
                wind_speed = int(parts[0])
                if len(parts) > 1:
                    wind_gust = int(parts[1])
            except (ValueError, TypeError):
                wind_speed = "N/A"

    return {
        "wind_direction": wind_direction,
        "wind_speed": wind_speed,
        "wind_gust": wind_gust,
    }


def build_scraped_land_station_result(
    station_id: str,
    raw_station_name: str,
    station_latitude,
    station_longitude,
    input_state: str,
    distance_km,
    tds,
    col_indices: dict,
) -> Optional[dict]:
    idx_temp = col_indices.get("temperature")
    if idx_temp is None or len(tds) <= idx_temp:
        return None

    temp_val_str = tds[idx_temp].text.strip()
    try:
        temp_val = int(temp_val_str)
    except (ValueError, TypeError):
        return None

    time_str = tds[0].text.strip() if len(tds) > 0 else "N/A"
    formatted_name = clean_station_name(raw_station_name)
    wind_values = parse_wind_observation(tds, col_indices)

    return {
        "identifier": station_id,
        "name": formatted_name,
        "latitude": station_latitude,
        "longitude": station_longitude,
        "state": input_state,
        "distance_km": distance_km,
        "time": time_str,
        "temperature": temp_val,
        "wind_speed": wind_values["wind_speed"],
        "wind_gust": wind_values["wind_gust"],
        "wind_direction": wind_values["wind_direction"],
    }


def calculate_station_map_center(stations: list) -> tuple:
    latitudes = [float(station["latitude"]) for station in stations if station.get("latitude") is not None]
    longitudes = [float(station["longitude"]) for station in stations if station.get("longitude") is not None]
    if not latitudes or not longitudes:
        return 0, 0
    return sum(latitudes) / len(latitudes), sum(longitudes) / len(longitudes)


def calculate_station_map_zoom_level(stations: list, geodesic_func) -> int:
    max_distance = 0
    if len(stations) < 2:
        return 10

    for first_index in range(len(stations)):
        for second_index in range(first_index + 1, len(stations)):
            try:
                point1 = (
                    float(stations[first_index]["latitude"]),
                    float(stations[first_index]["longitude"]),
                )
                point2 = (
                    float(stations[second_index]["latitude"]),
                    float(stations[second_index]["longitude"]),
                )
                distance = geodesic_func(point1, point2).kilometers
                if distance > max_distance:
                    max_distance = distance
            except (KeyError, ValueError, TypeError, AttributeError):
                continue

    if max_distance < 50:
        return 10
    if max_distance < 100:
        return 9
    if max_distance < 200:
        return 8
    if max_distance < 400:
        return 7
    if max_distance < 800:
        return 6
    if max_distance < 1600:
        return 5
    return 4


def build_station_map_bounds(stations: list):
    latitudes = [float(station["latitude"]) for station in stations if station.get("latitude") is not None]
    longitudes = [float(station["longitude"]) for station in stations if station.get("longitude") is not None]
    if not latitudes or not longitudes:
        return None

    min_lat, max_lat = min(latitudes), max(latitudes)
    min_lon, max_lon = min(longitudes), max(longitudes)
    lat_padding = (max_lat - min_lat) * 0.1
    lon_padding = (max_lon - min_lon) * 0.1

    return [
        [min_lat - lat_padding, min_lon - lon_padding],
        [max_lat + lat_padding, max_lon + lon_padding],
    ]


def build_land_station_wind_summary(station: dict) -> str:
    wind_info = f"Wind: {station.get('wind_direction', '')} {station.get('wind_speed', 'N/A')} mph"
    if station.get("wind_gust") is not None:
        wind_info += f", G{station['wind_gust']}"
    return wind_info


def build_land_station_choice_text(
    station: dict,
    input_state: str,
    abbreviation_func,
) -> str:
    try:
        abbreviated_name = abbreviation_func(station["name"], input_state)
    except NameError:
        abbreviated_name = station.get("name", "N/A")[:20]

    station_id_upper = station.get("identifier", "").upper()
    wind_info = build_land_station_wind_summary(station)

    return (
        f"{station_id_upper} {abbreviated_name}\n"
        f"Temp: {station.get('temperature', 'N/A')}°F, Time: {station.get('time', 'N/A')}\n"
        f"{wind_info}"
    )


def normalize_land_input_values(raw_town: str, raw_state: str) -> dict:
    entered_state = (raw_state or "").strip().upper()
    entered_town = (raw_town or "").strip()

    if len(entered_town) == 3:
        entered_town = entered_town.upper()
    else:
        entered_town = entered_town.title()

    return {
        "entered_town": entered_town,
        "entered_state": entered_state,
    }


def is_valid_land_input(entered_town: str, entered_state: str) -> bool:
    if not entered_town:
        return False
    if not entered_state or len(entered_state) != 2 or not entered_state.isalpha():
        return False
    return True


def apply_land_input_display_globals(
    ordinal: str,
    entered_town: str,
    entered_state: str,
    globals_dict: dict,
) -> None:
    display_value = f"{entered_town}, {entered_state}"

    if ordinal == "first":
        globals_dict["alternative_town_1"] = display_value
    elif ordinal == "second":
        globals_dict["alternative_town_2"] = display_value
    elif ordinal == "third":
        globals_dict["alternative_town_3"] = display_value


def parse_buoy_rss_value(text_block: str, search_key: str):
    for line in text_block.strip().split("<br />"):
        if search_key in line:
            value_part = line.split(search_key)[1]
            return value_part.replace("</strong>", "").strip()
    return None


def extract_buoy_rss_observation_fields(description_text: str) -> dict:
    return {
        "air_temp": parse_buoy_rss_value(description_text, "Air Temperature:"),
        "water_temp": parse_buoy_rss_value(description_text, "Water Temperature:"),
        "wind_dir": parse_buoy_rss_value(description_text, "Wind Direction:"),
        "wind_speed": parse_buoy_rss_value(description_text, "Wind Speed:"),
        "wind_gust": parse_buoy_rss_value(description_text, "Wind Gust:"),
    }


def format_buoy_choice_weather(scraped_data: dict) -> dict:
    air_temp_str = "N/A"
    water_temp_str = "N/A"
    wind_dir_str = "Var."
    wind_speed_str = "N/A"
    wind_gust_str = ""

    if scraped_data:
        if scraped_data["air_temp"]:
            try:
                air_temp_val = float(scraped_data["air_temp"].split("&#176;F")[0])
                air_temp_str = f"{round(air_temp_val)} °F"
            except (ValueError, TypeError):
                pass

        if scraped_data["water_temp"]:
            try:
                water_temp_val = float(scraped_data["water_temp"].split("&#176;F")[0])
                water_temp_str = f"{round(water_temp_val)} °F"
            except (ValueError, TypeError):
                pass

        if scraped_data["wind_dir"]:
            wind_dir_str = scraped_data["wind_dir"].split()[0]

        if scraped_data["wind_speed"]:
            try:
                speed_knots = float(scraped_data["wind_speed"].split()[0])
                wind_speed_str = f"{round(speed_knots * 1.15078)} mph"
            except (ValueError, TypeError, IndexError):
                pass

        if scraped_data["wind_gust"]:
            try:
                gust_knots = float(scraped_data["wind_gust"].split()[0])
                wind_gust_str = f", Gust: {round(gust_knots * 1.15078)} mph"
            except (ValueError, TypeError, IndexError):
                pass

    return {
        "air_temp_str": air_temp_str,
        "water_temp_str": water_temp_str,
        "wind_dir_str": wind_dir_str,
        "wind_speed_str": wind_speed_str,
        "wind_gust_str": wind_gust_str,
    }


def build_buoy_choice_button_text(
    buoy_id: str,
    latest_obs_time_utc,
    formatted_weather: dict,
) -> str:
    buoy_title = f"Buoy {buoy_id.upper()} ({latest_obs_time_utc.strftime('%b %d %H:%M UTC')})"
    return (
        f"{buoy_title}\n"
        f"  Air Temp: {formatted_weather['air_temp_str']}\n"
        f"  Water Temp: {formatted_weather['water_temp_str']}\n"
        f"  Wind Direction: {formatted_weather['wind_dir_str']}\n"
        f"  Wind Speed: {formatted_weather['wind_speed_str']}{formatted_weather['wind_gust_str']}"
    )


def build_buoy_choice_text_from_description(
    buoy_id: str,
    latest_obs_time_utc,
    description_text: str,
) -> str:
    scraped_data = extract_buoy_rss_observation_fields(description_text)
    formatted_weather = format_buoy_choice_weather(scraped_data)
    return build_buoy_choice_button_text(
        buoy_id,
        latest_obs_time_utc,
        formatted_weather,
    )


def apply_buoy_help_selection_globals(
    buoy_help_flag: str,
    selected_buoy_code: str,
    globals_dict: dict,
) -> None:
    selected_buoy_code = normalize_station_id(selected_buoy_code)
    if buoy_help_flag == "aobs":
        globals_dict["alternative_town_1"] = selected_buoy_code
    elif buoy_help_flag == "bobs":
        globals_dict["alternative_town_2"] = selected_buoy_code
    elif buoy_help_flag == "cobs":
        globals_dict["alternative_town_3"] = selected_buoy_code


def build_buoy_help_final_list(
    functional_buoys_with_time,
    buoy_coord_map,
):
    final_buoy_list = []

    for buoy_id, timestamp in functional_buoys_with_time:
        if buoy_id in buoy_coord_map:
            lat, lon = buoy_coord_map[buoy_id]
            final_buoy_list.append((buoy_id, lat, lon, timestamp))

    return final_buoy_list


def get_land_confirmation_slot_config(obs_type: str) -> dict:
    configs = {
        "aobs": {
            "id_var": "aobs_station_identifier",
            "town_var": "alternative_town_1",
            "signal_var": "aobs_buoy_signal",
            "temp_var": "atemp",
            "wind_var": "awind",
            "water_temp_var": "awtemp",
        },
        "bobs": {
            "id_var": "bobs_station_identifier",
            "town_var": "alternative_town_2",
            "signal_var": "bobs_buoy_signal",
            "temp_var": "btemp",
            "wind_var": "bwind",
            "water_temp_var": "bwtemp",
        },
        "cobs": {
            "id_var": "cobs_station_identifier",
            "town_var": "alternative_town_3",
            "signal_var": "cobs_buoy_signal",
            "temp_var": "ctemp",
            "wind_var": "cwind",
            "water_temp_var": "cwtemp",
        },
    }
    return configs.get(obs_type, {})


def calculate_buoy_help_center(functional_buoys):
    latitudes = [float(buoy[1]) for buoy in functional_buoys]
    longitudes = [float(buoy[2]) for buoy in functional_buoys]
    return sum(latitudes) / len(latitudes), sum(longitudes) / len(longitudes)


def calculate_buoy_help_zoom_level(functional_buoys, geodesic_func):
    buoy_list = list(functional_buoys)
    if len(buoy_list) == 1:
        print("Only one buoy found. Setting zoom level to 3.")
        return 3

    max_distance = 0
    for first_index in range(len(buoy_list)):
        for second_index in range(first_index + 1, len(buoy_list)):
            point1 = (float(buoy_list[first_index][1]), float(buoy_list[first_index][2]))
            point2 = (float(buoy_list[second_index][1]), float(buoy_list[second_index][2]))
            distance = geodesic_func(point1, point2).kilometers
            if distance > max_distance:
                max_distance = distance

    if max_distance < 50:
        return 10
    if max_distance < 100:
        return 9
    if max_distance < 200:
        return 8
    if max_distance < 400:
        return 7
    if max_distance < 800:
        return 6
    if max_distance < 1600:
        return 5
    if max_distance < 2500:
        return 4
    return 3


def normalize_buoy_help_town_state_input(town: str, state: str) -> dict:
    return {
        "town": (town or "").strip(),
        "state": (state or "").strip(),
    }


def parse_buoy_help_coordinates(lat_value: str, lon_value: str) -> tuple[float, float]:
    parsed_lat = float(lat_value)
    parsed_lon = -float(lon_value)
    return parsed_lat, parsed_lon


def find_buoy_help_nearest_buoys(current_location, all_buoys, geodesic_func):
    if not all_buoys:
        return []

    distances = []
    for buoy in all_buoys:
        try:
            dist_km = geodesic_func(
                current_location,
                (buoy["latitude"], buoy["longitude"]),
            ).km
            distances.append((dist_km, buoy["id"]))
        except (KeyError, TypeError):
            continue

    distances.sort(key=lambda item: item[0])
    return distances


def get_buoy_help_timezone_map() -> dict:
    return {
        "ADT": -3 * 3600,
        "AST": -4 * 3600,
        "EDT": -4 * 3600,
        "EST": -5 * 3600,
        "CDT": -5 * 3600,
        "CST": -6 * 3600,
        "MDT": -6 * 3600,
        "MST": -7 * 3600,
        "PDT": -7 * 3600,
        "PST": -8 * 3600,
        "AKDT": -8 * 3600,
        "AKST": -9 * 3600,
        "HADT": -9 * 3600,
        "HAST": -10 * 3600,
        "UTC": 0,
        "GMT": 0,
    }


def extract_buoy_rss_description_text(response_content, element_tree_module):
    root = element_tree_module.fromstring(response_content)
    desc_element = root.find(".//channel/item/description")
    if desc_element is None or not desc_element.text:
        return None
    return desc_element.text


def parse_buoy_rss_timestamp(
    description_text: str,
    parser_module,
    timezone_module,
):
    timestamp_line = description_text.strip().split("<br />")[0]
    timestamp_clean = timestamp_line.replace("<strong>", "").replace("</strong>", "").strip()
    if not timestamp_clean:
        return None

    last_obs_time = parser_module.parse(
        timestamp_clean,
        tzinfos=get_buoy_help_timezone_map(),
    )
    if last_obs_time.tzinfo is None:
        return None
    return last_obs_time.astimezone(timezone_module.utc)


def get_recent_buoy_rss_observation(
    buoy_id,
    max_obs_age,
    requests_module,
    element_tree_module,
    parser_module,
    datetime_module,
    timezone_module,
    timeout=10,
):
    rss_url = f"https://www.ndbc.noaa.gov/data/latest_obs/{buoy_id.lower()}.rss"
    response = requests_module.get(rss_url, timeout=timeout)
    if response.status_code != 200:
        return None

    description_text = extract_buoy_rss_description_text(
        response.content,
        element_tree_module,
    )
    if not description_text:
        return None

    obs_time_utc = parse_buoy_rss_timestamp(
        description_text,
        parser_module,
        timezone_module,
    )
    if obs_time_utc is None:
        return None

    if datetime_module.now(timezone_module.utc) - obs_time_utc > max_obs_age:
        return None

    return {
        "description_text": description_text,
        "obs_time_utc": obs_time_utc,
    }


def check_buoy_help_functionality(
    buoy_id,
    max_obs_age,
    requests_module,
    element_tree_module,
    parser_module,
    datetime_module,
    timezone_module,
):
    try:
        recent_observation = get_recent_buoy_rss_observation(
            buoy_id,
            max_obs_age,
            requests_module,
            element_tree_module,
            parser_module,
            datetime_module,
            timezone_module,
            timeout=10,
        )
        if not recent_observation:
            return None

        description_text = recent_observation["description_text"]
        obs_time_utc = recent_observation["obs_time_utc"]
        parameter_count = 0
        for key in [
            "Air Temperature:",
            "Water Temperature:",
            "Wind Direction:",
            "Wind Speed:",
        ]:
            if key in description_text:
                parameter_count += 1

        if parameter_count >= 3:
            return (buoy_id, obs_time_utc)

        print(f"  -> Skipping {buoy_id}: Recent report but only {parameter_count}/4 key parameters found.")
        return None

    except Exception:
        return None
