import threading
from image_sources.still_satellite import fetch_and_process_still_sat as explicit_fetch_and_process_still_sat
from image_sources.radiosonde import fetch_and_process_radiosonde as explicit_fetch_and_process_radiosonde

OBSERVATION_REFRESH_SLOTS = (
    ("aobs_buoy_signal", "aobs_station_identifier", "aobs_buoy_code"),
    ("bobs_buoy_signal", "bobs_station_identifier", "bobs_buoy_code"),
    ("cobs_buoy_signal", "cobs_station_identifier", "cobs_buoy_code"),
)


def cpu_lull_monitor(globals_dict, psutil_module):
    low_cpu_threshold = 20.0
    required_lull_duration = 5
    consecutive_low_cpu_seconds = 0

    while True:
        cpu_usage = psutil_module.cpu_percent(interval=1)

        if cpu_usage < low_cpu_threshold:
            consecutive_low_cpu_seconds += 1
        else:
            consecutive_low_cpu_seconds = 0
            if globals_dict.get("CPU_IS_IDLE"):
                globals_dict["CPU_IS_IDLE"] = False

        if consecutive_low_cpu_seconds >= required_lull_duration and not globals_dict.get("CPU_IS_IDLE"):
            globals_dict["CPU_IS_IDLE"] = True


def start_cpu_monitor(globals_dict, psutil_module):
    monitor_thread = threading.Thread(
        target=cpu_lull_monitor,
        args=(globals_dict, psutil_module),
        daemon=True,
    )
    monitor_thread.start()


def run_observations_task(
    globals_dict,
    asyncio_module,
    background_loop,
    data_update_queue,
    scrape_land_station_data_async,
    get_buoy_data_async,
):
    def task_wrapper():
        try:
            land_stations_to_scrape = []
            buoys_to_scrape = []
            for buoy_signal_key, station_id_key, buoy_code_key in OBSERVATION_REFRESH_SLOTS:
                if globals_dict[buoy_signal_key]:
                    buoy_code = globals_dict[buoy_code_key]
                    if buoy_code:
                        buoys_to_scrape.append(buoy_code)
                else:
                    station_id = globals_dict[station_id_key]
                    if station_id:
                        land_stations_to_scrape.append(station_id)

            futures = []
            if land_stations_to_scrape:
                futures.append(
                    asyncio_module.run_coroutine_threadsafe(
                        scrape_land_station_data_async(
                            land_stations_to_scrape,
                            background_loop,
                            data_update_queue,
                        ),
                        background_loop,
                    )
                )
            if buoys_to_scrape:
                futures.append(
                    asyncio_module.run_coroutine_threadsafe(
                        get_buoy_data_async(
                            buoys_to_scrape,
                            background_loop,
                            data_update_queue,
                        ),
                        background_loop,
                    )
                )

            if not futures:
                return

            for future in futures:
                try:
                    future.result()
                except Exception as e:
                    print(f"[OBS TASK] background future error: {e}")
        finally:
            globals_dict["TASK_IN_PROGRESS"] = False

    threading.Thread(target=task_wrapper, name="obs-task", daemon=True).start()


def update_images(
    globals_dict,
    root,
    datetime_cls,
    timedelta_cls,
    asyncio_module,
    monitor_system_health,
    fetch_and_process_baro_pic,
    fetch_and_process_still_sat,
    fetch_and_process_radiosonde,
    fetch_and_process_national_radar,
    fetch_and_process_national_sfc,
    fetch_and_process_vorticity,
    fetch_and_process_storm_reports,
    run_lightning_task,
    run_lcl_radar_task,
    run_observations_task,
    run_sfc_plots_task,
    run_reg_sat_task,
    update_transparent_frame_data=None,
):
    current_time = datetime_cls.now()

    if not globals_dict["last_baro_update"] or (current_time - globals_dict["last_baro_update"]).total_seconds() >= 180:
        fetch_and_process_baro_pic(globals_dict["available_image_dictionary"])
        globals_dict["last_baro_update"] = current_time

    if globals_dict["box_variables"][1] == 1:
        if globals_dict["last_radar_update"] is None or (current_time - globals_dict["last_radar_update"]).total_seconds() >= 600:
            fetch_and_process_national_radar(globals_dict["available_image_dictionary"])
            globals_dict["last_radar_update"] = current_time

    if globals_dict["box_variables"][4] == 1:
        still_sat_now = datetime_cls.now()
        if globals_dict["last_still_sat_update"] is None or (
            still_sat_now - globals_dict["last_still_sat_update"]
        ) >= timedelta_cls(seconds=600):
            try:
                if globals_dict["background_loop"]:
                    asyncio_module.run_coroutine_threadsafe(
                        explicit_fetch_and_process_still_sat(
                            globals_dict["available_image_dictionary"],
                            globals_dict["lg_still_sat_choice_vars"],
                            globals_dict["lg_still_sat"],
                            globals_dict["lg_still_view"],
                        ),
                        globals_dict["background_loop"],
                    )
                    globals_dict["last_still_sat_update"] = still_sat_now
                else:
                    print("[ERROR] Background event loop is not running.")
            except Exception as e:
                print(f"Error updating still sat: {e}")

    if globals_dict["box_variables"][6] == 1:
        national_sfc_now = datetime_cls.now()
        if globals_dict["last_national_sfc_update"] is None or (
            national_sfc_now - globals_dict["last_national_sfc_update"]
        ) >= timedelta_cls(seconds=3600):
            try:
                fetch_and_process_national_sfc(globals_dict["available_image_dictionary"])
                globals_dict["last_national_sfc_update"] = national_sfc_now
            except Exception as e:
                print(f"Error line 6866. updating national sfc: {e}")

    if globals_dict["box_variables"][8] == 1:
        current_time_utc = datetime_cls.utcnow()
        if globals_dict["last_radiosonde_update_check"] is None or (
            (globals_dict["last_radiosonde_update_check"].hour < 12 <= current_time_utc.hour) or
            (globals_dict["last_radiosonde_update_check"].hour >= 12 and current_time_utc.hour < 12)
        ):
            globals_dict["radiosonde_updated_flag"] = False
            globals_dict["last_radiosonde_update_check"] = current_time_utc

        if not globals_dict["radiosonde_updated_flag"] and (
            globals_dict["last_radiosonde_update"] is None or
            (current_time_utc - globals_dict["last_radiosonde_update"]).total_seconds() >= 600
        ):
            explicit_fetch_and_process_radiosonde(
                globals_dict["available_image_dictionary"],
                globals_dict["background_loop"],
                globals_dict["sonde_letter_identifier"],
            )
            globals_dict["last_radiosonde_update"] = current_time_utc

    if globals_dict["box_variables"][9] == 1:
        vorticity_now = datetime_cls.now()
        if globals_dict["last_vorticity_update"] is None or (
            vorticity_now - globals_dict["last_vorticity_update"]
        ) >= timedelta_cls(seconds=3600):
            try:
                fetch_and_process_vorticity(globals_dict["available_image_dictionary"])
                globals_dict["last_vorticity_update"] = vorticity_now
            except Exception as e:
                print(f"Error line 7051. Updating vorticity: {e}")

    if globals_dict["box_variables"][10] == 1 and not globals_dict["refresh_flag"]:
        storm_reports_now = datetime_cls.now()
        if globals_dict["last_storm_reports_update"] is None or (
            storm_reports_now - globals_dict["last_storm_reports_update"]
        ).total_seconds() >= 3600:
            try:
                fetch_and_process_storm_reports(globals_dict["available_image_dictionary"])
                globals_dict["last_storm_reports_update"] = storm_reports_now
            except Exception as e:
                print(f"Error updating storm reports: {e}")

    if (
        globals_dict["CPU_IS_IDLE"]
        and not globals_dict["TASK_IN_PROGRESS"]
        and not any([
            globals_dict["aobs_only_click_flag"],
            globals_dict["bobs_only_click_flag"],
            globals_dict["cobs_only_click_flag"],
        ])
    ):
        queued_task_settings = {
            "lightning": {
                "enabled": globals_dict["box_variables"][3] == 1,
                "last_update_key": "last_lightning_update",
                "interval_seconds": 240,
                "runner": run_lightning_task,
            },
            "lcl_radar": {
                "enabled": globals_dict["box_variables"][2] == 1,
                "last_update_key": "last_lcl_radar_update",
                "interval_seconds": 180,
                "runner": run_lcl_radar_task,
            },
            "observations": {
                "enabled": True,
                "last_update_key": "last_land_scrape_time",
                "interval_seconds": 480,
                "runner": run_observations_task,
            },
            "sfc_plots": {
                "enabled": globals_dict["box_variables"][7] == 1,
                "last_update_key": "last_sfc_plots_update",
                "interval_seconds": 300,
                "runner": run_sfc_plots_task,
            },
            "reg_sat": {
                "enabled": globals_dict["box_variables"][5] == 1,
                "last_update_key": "last_reg_sat_update",
                "interval_seconds": 600,
                "runner": run_reg_sat_task,
            },
        }

        for index, task_name in enumerate(globals_dict["task_queue"]):
            task_settings = queued_task_settings.get(task_name)
            if not task_settings or not task_settings["enabled"]:
                continue

            last_update = globals_dict[task_settings["last_update_key"]]
            timer_expired = (
                last_update is None
                or (current_time - last_update).total_seconds() >= task_settings["interval_seconds"]
            )

            if timer_expired:
                globals_dict["TASK_IN_PROGRESS"] = True
                globals_dict[task_settings["last_update_key"]] = current_time
                task_settings["runner"]()

                for _ in range(index + 1):
                    globals_dict["task_queue"].append(globals_dict["task_queue"].pop(0))
                break

    if (
        update_transparent_frame_data is not None
        and not globals_dict["refresh_flag"]
        and not globals_dict["aobs_only_click_flag"]
        and not globals_dict["bobs_only_click_flag"]
        and not globals_dict["cobs_only_click_flag"]
    ):
        update_transparent_frame_data()

    monitor_system_health()
    globals_dict["update_images_timer"] = root.after(
        60000,
        lambda: update_images(
            globals_dict,
            root,
            datetime_cls,
            timedelta_cls,
            asyncio_module,
            monitor_system_health,
            fetch_and_process_baro_pic,
            fetch_and_process_still_sat,
            fetch_and_process_radiosonde,
            fetch_and_process_national_radar,
            fetch_and_process_national_sfc,
            fetch_and_process_vorticity,
            fetch_and_process_storm_reports,
            run_lightning_task,
            run_lcl_radar_task,
            run_observations_task,
            run_sfc_plots_task,
            run_reg_sat_task,
            update_transparent_frame_data,
        ),
    )
