UI_TEXT = "#000000"
UI_MUTED = "#000000"
UI_PRIMARY = "#2d6f9f"
UI_PRIMARY_ACTIVE = "#255d86"
UI_SECONDARY = "#d7dfe5"
UI_SECONDARY_ACTIVE = "#c8d2da"
UI_BORDER = "#879dab"
UI_INPUT_BG = "#fbfdff"


def destroy_frame_widgets(frame, widget_types=None):
    for widget in frame.winfo_children():
        if widget_types is None or isinstance(widget, widget_types):
            widget.destroy()


def hide_ui_frames(
    forget_all_frames_fn,
    transparent_frame=None,
    baro_frame=None,
    function_button_frame=None,
):
    if function_button_frame is not None:
        function_button_frame.grid_forget()
    if baro_frame is not None:
        baro_frame.grid_forget()
    if transparent_frame is not None:
        try:
            transparent_frame.place_forget()
        except Exception:
            pass
        try:
            transparent_frame.grid_forget()
        except Exception:
            pass
    forget_all_frames_fn()


def prepare_frame1_screen(
    frame1,
    root,
    sticky="nsew",
    width=None,
    height=None,
    background=None,
    grid_propagate=None,
    row_weight=0,
    column_weight=0,
    geometry="1024x600",
):
    frame1.grid(row=0, column=0, sticky=sticky)
    if width is not None or height is not None or background is not None:
        config_kwargs = {}
        if width is not None:
            config_kwargs["width"] = width
        if height is not None:
            config_kwargs["height"] = height
        if background is not None:
            config_kwargs["bg"] = background
        frame1.config(**config_kwargs)
    if grid_propagate is not None:
        frame1.grid_propagate(grid_propagate)
    root.grid_rowconfigure(0, weight=row_weight)
    root.grid_columnconfigure(0, weight=column_weight)
    root.geometry(geometry)


def reset_for_frame1_display(
    frame1,
    root,
    forget_all_frames_fn,
    transparent_frame=None,
    baro_frame=None,
    function_button_frame=None,
    destroy_widget_types=None,
    destroy_all=False,
    sticky="nsew",
    width=None,
    height=None,
    background=None,
    grid_propagate=None,
    row_weight=0,
    column_weight=0,
    geometry="1024x600",
):
    hide_ui_frames(
        forget_all_frames_fn,
        transparent_frame=transparent_frame,
        baro_frame=baro_frame,
        function_button_frame=function_button_frame,
    )
    if destroy_all:
        destroy_frame_widgets(frame1)
    elif destroy_widget_types is not None:
        destroy_frame_widgets(frame1, destroy_widget_types)
    prepare_frame1_screen(
        frame1,
        root,
        sticky=sticky,
        width=width,
        height=height,
        background=background,
        grid_propagate=grid_propagate,
        row_weight=row_weight,
        column_weight=column_weight,
        geometry=geometry,
    )


def build_land_or_buoy_screen(
    frame1,
    tk_module,
    create_button_fn,
    button_font,
    tk_background_color,
    title_text,
    instruction_text,
    land_command,
    buoy_command,
    back_command=None,
    random_command=None,
    random_option_buttons=None,
    random_section_title="Random Options",
    random_section_text="Replace only this site, or generate a full new set of 3 random sites.",
):
    destroy_frame_widgets(frame1)
    frame1.grid(row=0, column=0, sticky="nsew")

    add_modern_screen_text(
        frame1,
        tk_module,
        tk_background_color,
        title_text,
        instruction_text,
        title_row=0,
        body_row=1,
        title_padx=50,
        title_pady=(50, 0),
        body_padx=50,
        body_pady=10,
        title_columnspan=1,
        body_columnspan=1,
        sticky="w",
    )

    if back_command is not None:
        back_button = create_modern_button(
            frame1,
            tk_module,
            " Back ",
            back_command,
            font=button_font,
            variant="secondary",
        )
        back_button.grid(row=2, column=0, padx=(50, 0), pady=30, sticky="w")

    land_button = create_modern_button(
        frame1,
        tk_module,
        " Land ",
        land_command,
        font=button_font,
        variant="secondary",
    )
    land_button.grid(row=2, column=0, padx=(200, 0), pady=30, sticky="w")

    buoy_button = create_modern_button(
        frame1,
        tk_module,
        " Buoy ",
        buoy_command,
        font=button_font,
        variant="secondary",
    )
    buoy_button.grid(row=2, column=0, padx=(350, 0), pady=30, sticky="w")

    if random_command is not None:
        random_button = create_button_fn(
            frame1,
            "Random",
            button_font,
            random_command,
        )
        random_button.grid(row=2, column=0, padx=(500, 0), pady=30, sticky="w")

    if random_option_buttons:
        panel_frame = tk_module.Frame(
            frame1,
            bg="#eef5fb",
            bd=2,
            relief="groove",
            highlightthickness=0,
        )
        panel_frame.grid(row=3, column=0, padx=(50, 0), pady=(8, 0), sticky="w")

        title_label = tk_module.Label(
            panel_frame,
            text=random_section_title,
            font=("Helvetica Neue", 16, "bold"),
            fg="black",
            bg="#eef5fb",
            anchor="w",
            justify="left",
        )
        title_label.grid(row=0, column=0, columnspan=2, padx=18, pady=(12, 4), sticky="w")

        body_label = tk_module.Label(
            panel_frame,
            text=random_section_text,
            font=("Helvetica Neue", 12),
            fg="black",
            bg="#eef5fb",
            anchor="w",
            justify="left",
        )
        body_label.grid(row=1, column=0, columnspan=2, padx=18, pady=(0, 12), sticky="w")

        for index, (label, command) in enumerate(random_option_buttons):
            button = create_modern_button(
                panel_frame,
                tk_module,
                label,
                command,
                font=button_font,
                variant="secondary",
            )
            button.grid(row=2, column=index, padx=(18 if index == 0 else 10, 18), pady=(0, 14), sticky="w")


def prepare_observation_button_edit(
    globals_dict,
    forget_all_frames_fn,
    baro_frame,
    transparent_frame,
    root_corner_canvas,
    only_click_flag_key,
    buoy_signal_key,
    next_screen_fn,
):
    transition_timer = globals_dict.get("TRANSITION_RETURN_TIMER")
    if transition_timer:
        try:
            globals_dict["root"].after_cancel(transition_timer)
        except Exception:
            pass
        globals_dict["TRANSITION_RETURN_TIMER"] = None

    transition_overlay = globals_dict.get("TRANSITION_OVERLAY_FRAME")
    if transition_overlay is not None:
        try:
            transition_overlay.destroy()
        except Exception:
            pass
        globals_dict["TRANSITION_OVERLAY_FRAME"] = None

    forget_all_frames_fn()
    baro_frame.grid_forget()
    try:
        root_corner_canvas.place_forget()
    except Exception:
        pass
    try:
        transparent_frame.place_forget()
    except Exception:
        pass
    try:
        transparent_frame.grid_forget()
    except Exception:
        pass
    globals_dict[only_click_flag_key] = True
    globals_dict[buoy_signal_key] = False
    next_screen_fn()


def add_weather_observer_header(
    frame,
    tk_module,
    background,
    text="The Weather Observer",
    padx=50,
    pady=(50, 0),
    sticky="nw",
    font=("Arial", 18, "bold"),
    columnspan=20,
    justify="left",
):
    logo_factory = getattr(frame, "_weather_observer_logo_factory", None)
    if logo_factory and text == "The Weather Observer":
        header_frame = tk_module.Frame(frame, bg=background)
        header_frame.grid(row=0, column=0, columnspan=columnspan, padx=padx, pady=pady, sticky=sticky)
        logo = logo_factory(header_frame, size=(65, 65))
        logo.grid(row=0, column=0, padx=(0, 6), pady=(6, 0), sticky="w")
        label = tk_module.Label(
            header_frame,
            text=text,
            font=font,
            bg=background,
            justify=justify,
        )
        label.grid(row=0, column=1, pady=(12, 0), sticky="w")
        return label

    label = tk_module.Label(
        frame,
        text=text,
        font=font,
        bg=background,
        justify=justify,
    )
    label.grid(row=0, column=0, columnspan=columnspan, padx=padx, pady=pady, sticky=sticky)
    return label


def add_modern_screen_text(
    frame,
    tk_module,
    background,
    title_text,
    body_text,
    title_row=0,
    body_row=1,
    title_padx=50,
    title_pady=(50, 0),
    body_padx=50,
    body_pady=6,
    title_columnspan=20,
    body_columnspan=20,
    sticky="nw",
):
    logo_factory = getattr(frame, "_weather_observer_logo_factory", None)
    if logo_factory and title_text == "The Weather Observer":
        header_frame = tk_module.Frame(frame, bg=background)
        header_frame.grid(
            row=title_row,
            column=0,
            columnspan=title_columnspan,
            padx=title_padx,
            pady=title_pady,
            sticky=sticky,
        )
        logo = logo_factory(header_frame, size=(65, 65))
        logo.grid(row=0, column=0, padx=(0, 6), pady=(6, 0), sticky="w")
        title_label = tk_module.Label(
            header_frame,
            text=title_text,
            font=("Helvetica Neue", 20, "bold"),
            fg=UI_TEXT,
            bg=background,
            justify="left",
        )
        title_label.grid(row=0, column=1, pady=(12, 0), sticky="w")
    else:
        title_label = tk_module.Label(
            frame,
            text=title_text,
            font=("Helvetica Neue", 20, "bold"),
            fg=UI_TEXT,
            bg=background,
            justify="left",
        )
        title_label.grid(
            row=title_row,
            column=0,
            columnspan=title_columnspan,
            padx=title_padx,
            pady=title_pady,
            sticky=sticky,
        )

    body_label = tk_module.Label(
        frame,
        text=body_text,
        font=("Helvetica Neue", 15),
        fg=UI_MUTED,
        bg=background,
        justify="left",
        anchor="w",
    )
    body_label.grid(
        row=body_row,
        column=0,
        columnspan=body_columnspan,
        padx=body_padx,
        pady=body_pady,
        sticky=sticky,
    )
    return title_label, body_label


def create_modern_button(
    frame,
    tk_module,
    text,
    command,
    font=("Helvetica Neue", 15, "bold"),
    variant="secondary",
):
    if variant == "primary":
        colors = {
            "bg": UI_PRIMARY,
            "fg": "white",
            "activebackground": UI_PRIMARY_ACTIVE,
            "activeforeground": "white",
        }
    else:
        colors = {
            "bg": UI_SECONDARY,
            "fg": UI_TEXT,
            "activebackground": UI_SECONDARY_ACTIVE,
            "activeforeground": UI_TEXT,
        }

    return tk_module.Button(
        frame,
        text=text,
        command=command,
        font=font,
        relief="flat",
        bd=0,
        highlightthickness=1,
        highlightbackground=UI_BORDER,
        highlightcolor=UI_PRIMARY,
        padx=12,
        pady=8,
        **colors,
    )


def style_input_entry(entry):
    entry.configure(
        font=("Helvetica Neue", 15),
        bg=UI_INPUT_BG,
        fg=UI_TEXT,
        insertbackground=UI_TEXT,
        relief="flat",
        highlightthickness=1,
        highlightbackground=UI_BORDER,
        highlightcolor=UI_PRIMARY,
        bd=0,
    )
    return entry


def build_message_action_screen(
    frame,
    tk_module,
    background,
    header_text,
    message_lines,
    action_buttons,
    header_font=("Arial", 18, "bold"),
    message_font=("Helvetica", 16),
    button_font=("Helvetica", 16, "bold"),
):
    add_weather_observer_header(
        frame,
        tk_module,
        background,
        text=header_text,
        font=header_font,
    )

    for index, message_text in enumerate(message_lines, start=1):
        label = tk_module.Label(
            frame,
            text=message_text,
            font=message_font,
            bg=background,
            justify="left",
        )
        label.grid(row=index, column=0, columnspan=20, padx=50, pady=25, sticky="nw")

    button_row = len(message_lines) + 1
    for button in action_buttons:
        button_widget = tk_module.Button(
            frame,
            text=button["text"],
            command=button["command"],
            font=button.get("font", button_font),
        )
        button_widget.grid(
            row=button_row,
            column=button.get("column", 0),
            columnspan=button.get("columnspan", 20),
            padx=button.get("padx", 50),
            pady=button.get("pady", (15, 0)),
            sticky=button.get("sticky", "nw"),
        )
