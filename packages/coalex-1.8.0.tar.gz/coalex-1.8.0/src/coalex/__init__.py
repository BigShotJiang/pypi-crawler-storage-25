"""Coalex Python SDK — AI governance observability."""

from coalex.agents import AgentDeclaration, declare_agent
from coalex.auto_instrument import (
    auto_instrument,
    instrument_anthropic,
    instrument_bedrock,
    instrument_langchain,
    instrument_llamaindex,
    instrument_openai,
    instrument_vertexai,
)
from coalex.config import CoalexConfig
from coalex.context import coalex_context
from coalex.evaluate import EvaluationDecision, evaluate
from coalex.prompts import PromptVersion, get_prompt
from coalex.resolve import ResolutionResult, resolve

__all__ = [
    "register",
    "declare_agent",
    "AgentDeclaration",
    "get_prompt",
    "PromptVersion",
    "evaluate",
    "EvaluationDecision",
    "resolve",
    "ResolutionResult",
    "coalex_context",
    "auto_instrument",
    "instrument_openai",
    "instrument_langchain",
    "instrument_llamaindex",
    "instrument_vertexai",
    "instrument_bedrock",
    "instrument_anthropic",
]

_config: CoalexConfig | None = None
_api_key: str | None = None


def register(
    *,
    endpoint: str = "https://traces.azure.coalex.ai",
    api_key: str = "dev",
    service_name: str = "coalex-sdk-python",
    filter_non_ai_spans: bool = False,
    suppress_export_errors: bool = True,
) -> None:
    """Configure the Coalex OTLP exporter.

    Call once at application startup. Sets the global TracerProvider
    with a BatchSpanProcessor exporting OTLP/HTTP to the Coalex proxy.

    The SDK always sends through the proxy (via LB) so that auth
    validation is in the path. Never send directly to the collector.

    Args:
        endpoint: Coalex proxy HTTP endpoint (default: cloud).
        api_key: API key for proxy authentication (default: "dev" for local).
        service_name: Service name for OTLP resource (default: "coalex-sdk-python").
        filter_non_ai_spans: If True, only export AI/LLM spans (default: False).
        suppress_export_errors: If True, suppress export errors gracefully (default: True).
    """
    global _config, _api_key

    from opentelemetry import trace
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
        OTLPSpanExporter,
    )
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    from coalex.filtering_exporter import FilteringSpanExporter
    from coalex.safe_exporter import SafeOTLPSpanExporter
    from coalex.span_processor import CoalexAttributePropagator

    _config = CoalexConfig(endpoint=endpoint, service_name=service_name)
    _api_key = api_key

    resource = Resource({"service.name": service_name})

    base_exporter = OTLPSpanExporter(
        endpoint=f"{_config.endpoint}/v1/traces",
        headers={"Authorization": f"Bearer {api_key}"},
    )

    # Wrap exporter chain: OTLP -> Safe -> Filtering (when enabled)
    safe_exporter = SafeOTLPSpanExporter(base_exporter, suppress_errors=suppress_export_errors)
    final_exporter = FilteringSpanExporter(safe_exporter) if filter_non_ai_spans else safe_exporter

    provider = TracerProvider(resource=resource)
    provider.add_span_processor(CoalexAttributePropagator())
    provider.add_span_processor(BatchSpanProcessor(final_exporter))
    trace.set_tracer_provider(provider)
