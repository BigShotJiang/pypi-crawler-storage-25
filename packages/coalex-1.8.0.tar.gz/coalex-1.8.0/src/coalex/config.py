"""SDK configuration."""

from dataclasses import dataclass


@dataclass(frozen=True)
class CoalexConfig:
    endpoint: str = "https://traces.azure.coalex.ai"
    service_name: str = "coalex-sdk-python"
