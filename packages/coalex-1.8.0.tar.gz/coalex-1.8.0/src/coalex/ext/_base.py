"""Shared helpers for coalex.ext span decorators."""

from __future__ import annotations

from opentelemetry import context, trace
from opentelemetry.context import Context

from coalex.ext._context_bridge import span_context_bridge


def _get_tracer() -> trace.Tracer:
    return trace.get_tracer("coalex.ext")


def _get_parent_context() -> Context:
    """Get the best available parent context for creating a child span.

    Checks the span context bridge first (fixes async boundary issues),
    then falls back to OTel's implicit context (normal case).
    """
    bridge_ctx = span_context_bridge.get_nearest_parent()
    if bridge_ctx is not None:
        return bridge_ctx
    return context.get_current()
