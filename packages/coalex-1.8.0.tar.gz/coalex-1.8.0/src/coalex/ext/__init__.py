"""coalex.ext — OpenInference-compatible span decorators for RAG pipelines.

Use these decorators to instrument custom retrieval, embedding, reranking,
tool, and guardrail logic without depending on LlamaIndex or LangChain
auto-instrumentors.

Example::

    from coalex.ext.retrieval import retrieval_span, Document

    @retrieval_span(name="pubmed_retrieval", query_arg="query")
    def retrieve(query: str) -> list[Document]:
        ...
        return [Document(content=abstract, id=pmid)]
"""

from coalex.ext.embedding import EmbeddingSpan, embedding_span
from coalex.ext.guardrail import guardrail_span
from coalex.ext.reranker import RerankerSpan, reranker_span
from coalex.ext.retrieval import Document, RetrievalSpan, encode_documents, retrieval_span
from coalex.ext.tool import tool_span

__all__ = [
    "Document",
    "encode_documents",
    "retrieval_span",
    "RetrievalSpan",
    "embedding_span",
    "EmbeddingSpan",
    "reranker_span",
    "RerankerSpan",
    "tool_span",
    "guardrail_span",
]
