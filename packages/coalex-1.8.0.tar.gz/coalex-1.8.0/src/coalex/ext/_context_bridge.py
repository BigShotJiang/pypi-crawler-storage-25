"""Thread-safe span context bridge for fixing OTel context propagation
across async/thread execution boundaries.

LangGraph's async task executor breaks OTel implicit context propagation.
This bridge tracks active TOOL/CHAIN spans in a global registry so that
ext decorators (@retrieval_span, etc.) can find the correct parent.
"""

import threading
import time

from opentelemetry import trace
from opentelemetry.context import Context

# TTL for stale entries (seconds) — safety net for spans that never end
_STALE_TTL = 300  # 5 minutes


class _SpanContextBridge:
    """Global registry of active parent span contexts, keyed by trace_id.

    Uses a stack per trace to handle nested TOOL spans correctly.
    Thread-safe via a threading.Lock.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        # trace_id -> list of (span_id, Context, timestamp)
        self._stack: dict[str, list[tuple[str, Context, float]]] = {}

    def push(self, span: trace.Span, ctx: Context) -> None:
        """Push a span's context onto the stack for its trace."""
        span_ctx = span.get_span_context()
        if not span_ctx.is_valid:
            return
        trace_id = format(span_ctx.trace_id, "032x")
        span_id = format(span_ctx.span_id, "016x")
        enriched_ctx = trace.set_span_in_context(span, ctx)
        with self._lock:
            self._stack.setdefault(trace_id, []).append((span_id, enriched_ctx, time.monotonic()))

    def pop(self, span_ctx: trace.SpanContext) -> None:
        """Pop a span's context from the stack."""
        if not span_ctx.is_valid:
            return
        trace_id = format(span_ctx.trace_id, "032x")
        span_id = format(span_ctx.span_id, "016x")
        with self._lock:
            stack = self._stack.get(trace_id, [])
            self._stack[trace_id] = [(sid, ctx, ts) for sid, ctx, ts in stack if sid != span_id]
            if not self._stack[trace_id]:
                del self._stack[trace_id]

    def get_nearest_parent(self) -> Context | None:
        """Get the most recently pushed context for the current trace.

        Uses the trace_id from the current (potentially stale) OTel context
        to look up the correct parent in the bridge.
        """
        current = trace.get_current_span()
        if not current or not current.get_span_context().is_valid:
            return None
        trace_id = format(current.get_span_context().trace_id, "032x")
        now = time.monotonic()
        with self._lock:
            stack = self._stack.get(trace_id, [])
            # Clean stale entries
            stack = [(sid, ctx, ts) for sid, ctx, ts in stack if now - ts < _STALE_TTL]
            self._stack[trace_id] = stack
            if stack:
                return stack[-1][1]  # Most recently pushed
        return None

    def clear(self) -> None:
        """Clear all stored contexts (for testing)."""
        with self._lock:
            self._stack.clear()


# Module-level singleton
span_context_bridge = _SpanContextBridge()
