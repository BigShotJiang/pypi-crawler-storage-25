"""Tests for coalex.declare_agent() SDK function (COA-270)."""

from unittest.mock import MagicMock, patch

import pytest
from coalex.agents import AgentDeclaration, declare_agent
from coalex.config import CoalexConfig


class TestDeclareAgent:
    def test_requires_register(self):
        """Raises RuntimeError when register() hasn't been called."""
        with (
            patch("coalex._config", None),
            patch("coalex._api_key", None),
            pytest.raises(RuntimeError, match="register"),
        ):
            declare_agent(agent_id="my-agent")

    def test_returns_agent_declaration_on_create(self):
        """Returns AgentDeclaration with lifecycle='declared' for new agent."""
        cfg = CoalexConfig(endpoint="http://localhost:8080")
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "agent_id": "new-agent",
            "lifecycle": "declared",
            "created": True,
        }
        mock_response.raise_for_status = MagicMock()

        with patch("coalex.agents.httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.return_value = mock_response
            mock_client_cls.return_value = mock_client

            result = declare_agent(
                agent_id="new-agent",
                _config=cfg,
                _api_key="test-key",
            )

        assert isinstance(result, AgentDeclaration)
        assert result.agent_id == "new-agent"
        assert result.lifecycle == "declared"
        assert result.created is True

    def test_returns_active_for_existing_observed_agent(self):
        """Returns lifecycle='active' when declaring an already-observed agent."""
        cfg = CoalexConfig(endpoint="http://localhost:8080")
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "agent_id": "existing-agent",
            "lifecycle": "active",
            "created": False,
        }
        mock_response.raise_for_status = MagicMock()

        with patch("coalex.agents.httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.return_value = mock_response
            mock_client_cls.return_value = mock_client

            result = declare_agent(
                agent_id="existing-agent",
                _config=cfg,
                _api_key="test-key",
            )

        assert result.lifecycle == "active"
        assert result.created is False

    def test_calls_correct_endpoint(self):
        """Verifies the HTTP call goes to /api/v1/agents with correct auth."""
        cfg = CoalexConfig(endpoint="http://localhost:8080")
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "agent_id": "a",
            "lifecycle": "declared",
            "created": True,
        }
        mock_response.raise_for_status = MagicMock()

        with patch("coalex.agents.httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.return_value = mock_response
            mock_client_cls.return_value = mock_client

            declare_agent(agent_id="a", _config=cfg, _api_key="my-key")

            call_args = mock_client.post.call_args
            assert call_args[0][0] == "http://localhost:8080/api/v1/agents"
            headers = call_args.kwargs.get("headers") or call_args[1].get("headers")
            assert headers["Authorization"] == "Bearer my-key"

    def test_payload_includes_display_name(self):
        """Verify display_name is sent in payload when provided."""
        cfg = CoalexConfig(endpoint="http://localhost:8080")
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "agent_id": "a",
            "lifecycle": "declared",
            "created": True,
        }
        mock_response.raise_for_status = MagicMock()

        with patch("coalex.agents.httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.return_value = mock_response
            mock_client_cls.return_value = mock_client

            declare_agent(
                agent_id="a",
                display_name="My Agent",
                _config=cfg,
                _api_key="k",
            )

            call_args = mock_client.post.call_args
            payload = call_args.kwargs.get("json") or call_args[1].get("json")
            assert payload["agent_id"] == "a"
            assert payload["display_name"] == "My Agent"

    def test_payload_omits_optional_fields_when_none(self):
        """Verify display_name and metadata are omitted when not provided."""
        cfg = CoalexConfig(endpoint="http://localhost:8080")
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "agent_id": "a",
            "lifecycle": "declared",
            "created": True,
        }
        mock_response.raise_for_status = MagicMock()

        with patch("coalex.agents.httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.return_value = mock_response
            mock_client_cls.return_value = mock_client

            declare_agent(agent_id="a", _config=cfg, _api_key="k")

            call_args = mock_client.post.call_args
            payload = call_args.kwargs.get("json") or call_args[1].get("json")
            assert payload == {"agent_id": "a"}

    def test_payload_includes_metadata(self):
        """Verify metadata is sent when provided."""
        cfg = CoalexConfig(endpoint="http://localhost:8080")
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "agent_id": "a",
            "lifecycle": "declared",
            "created": True,
        }
        mock_response.raise_for_status = MagicMock()

        with patch("coalex.agents.httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.return_value = mock_response
            mock_client_cls.return_value = mock_client

            declare_agent(
                agent_id="a",
                metadata={"env": "prod"},
                _config=cfg,
                _api_key="k",
            )

            call_args = mock_client.post.call_args
            payload = call_args.kwargs.get("json") or call_args[1].get("json")
            assert payload["metadata"] == {"env": "prod"}

    def test_result_is_frozen(self):
        """AgentDeclaration is immutable (frozen dataclass)."""
        decl = AgentDeclaration(agent_id="a", lifecycle="declared", created=True)
        with pytest.raises(AttributeError):
            decl.agent_id = "b"  # type: ignore[misc]
