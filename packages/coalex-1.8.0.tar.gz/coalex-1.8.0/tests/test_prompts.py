"""Tests for coalex.get_prompt() SDK function (COA-264)."""

from unittest.mock import MagicMock, patch

import pytest
from coalex.config import CoalexConfig
from coalex.prompts import PromptVersion, get_prompt


class TestGetPrompt:
    def test_requires_register(self):
        """Raises RuntimeError when register() hasn't been called."""
        with (
            patch("coalex._config", None),
            patch("coalex._api_key", None),
            pytest.raises(RuntimeError, match="register"),
        ):
            get_prompt(agent="my-agent", name="system")

    def test_returns_prompt_version(self):
        """Returns PromptVersion with correct fields."""
        cfg = CoalexConfig(endpoint="http://localhost:8080")
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "id": "uuid-123",
            "agent_id": "sales-copilot",
            "prompt_type": "system",
            "version": 3,
            "content": "You are a sales assistant.",
            "status": "production",
            "metadata": {"temperature": 0.7},
        }
        mock_response.raise_for_status = MagicMock()

        with patch("coalex.prompts.httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.get.return_value = mock_response
            mock_client_cls.return_value = mock_client

            result = get_prompt(
                agent="sales-copilot",
                name="system",
                _config=cfg,
                _api_key="test-key",
            )

        assert isinstance(result, PromptVersion)
        assert result.agent_id == "sales-copilot"
        assert result.name == "system"
        assert result.version == 3
        assert result.content == "You are a sales assistant."
        assert result.status == "production"
        assert result.metadata == {"temperature": 0.7}

    def test_calls_correct_endpoint(self):
        """Verifies the HTTP call goes to /api/v2/prompts/{agent}/{name}."""
        cfg = CoalexConfig(endpoint="http://localhost:8080")
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "id": "uuid-1",
            "agent_id": "a",
            "prompt_type": "system",
            "version": 1,
            "content": "c",
            "status": "production",
            "metadata": {},
        }
        mock_response.raise_for_status = MagicMock()

        with patch("coalex.prompts.httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.get.return_value = mock_response
            mock_client_cls.return_value = mock_client

            get_prompt(agent="my-agent", name="main", version="staging", _config=cfg, _api_key="my-key")

            call_args = mock_client.get.call_args
            assert call_args[0][0] == "http://localhost:8080/api/v2/prompts/my-agent/main"
            assert call_args.kwargs["params"] == {"version": "staging"}
            assert call_args.kwargs["headers"]["Authorization"] == "Bearer my-key"

    def test_default_version_is_production(self):
        """Default version parameter is 'production'."""
        cfg = CoalexConfig(endpoint="http://localhost:8080")
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "id": "uuid-1",
            "agent_id": "a",
            "prompt_type": "system",
            "version": 1,
            "content": "c",
            "status": "production",
            "metadata": {},
        }
        mock_response.raise_for_status = MagicMock()

        with patch("coalex.prompts.httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.get.return_value = mock_response
            mock_client_cls.return_value = mock_client

            get_prompt(agent="a", name="n", _config=cfg, _api_key="k")

            call_args = mock_client.get.call_args
            assert call_args.kwargs["params"]["version"] == "production"

    def test_result_is_frozen(self):
        """PromptVersion is immutable (frozen dataclass)."""
        pv = PromptVersion(
            id="uuid-1",
            agent_id="a",
            name="n",
            prompt_type="system",
            version=1,
            content="c",
            status="draft",
            metadata={},
        )
        with pytest.raises(AttributeError):
            pv.content = "new"  # type: ignore[misc]
