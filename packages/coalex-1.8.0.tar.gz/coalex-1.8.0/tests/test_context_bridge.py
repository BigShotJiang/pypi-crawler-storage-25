"""Unit tests for the span context bridge."""

from __future__ import annotations

import threading
import time
from unittest.mock import patch

from coalex.ext._context_bridge import _SpanContextBridge
from opentelemetry import context, trace
from opentelemetry.trace import NonRecordingSpan, SpanContext, TraceFlags


def _make_span_context(trace_id: int, span_id: int) -> SpanContext:
    return SpanContext(trace_id=trace_id, span_id=span_id, is_remote=False, trace_flags=TraceFlags(1))


def _make_span(trace_id: int, span_id: int) -> NonRecordingSpan:
    return NonRecordingSpan(_make_span_context(trace_id, span_id))


class TestSpanContextBridge:
    def test_push_pop_basic(self):
        bridge = _SpanContextBridge()
        span = _make_span(1, 100)
        ctx = context.get_current()

        bridge.push(span, ctx)

        # Set current span so bridge can find trace_id
        token = context.attach(trace.set_span_in_context(span))
        try:
            result = bridge.get_nearest_parent()
            assert result is not None
        finally:
            context.detach(token)

        bridge.pop(span.get_span_context())

        token = context.attach(trace.set_span_in_context(span))
        try:
            assert bridge.get_nearest_parent() is None
        finally:
            context.detach(token)

    def test_nested_tool_spans(self):
        bridge = _SpanContextBridge()
        outer = _make_span(1, 100)
        inner = _make_span(1, 200)
        ctx = context.get_current()

        bridge.push(outer, ctx)
        bridge.push(inner, ctx)

        # Should return inner (most recently pushed)
        token = context.attach(trace.set_span_in_context(inner))
        try:
            result = bridge.get_nearest_parent()
            assert result is not None
            # Verify it's the inner span's context
            result_span = trace.get_current_span(result)
            assert result_span.get_span_context().span_id == inner.get_span_context().span_id
        finally:
            context.detach(token)

        # Pop inner, should return outer
        bridge.pop(inner.get_span_context())
        token = context.attach(trace.set_span_in_context(outer))
        try:
            result = bridge.get_nearest_parent()
            assert result is not None
            result_span = trace.get_current_span(result)
            assert result_span.get_span_context().span_id == outer.get_span_context().span_id
        finally:
            context.detach(token)

    def test_different_traces(self):
        bridge = _SpanContextBridge()
        span_a = _make_span(1, 100)
        span_b = _make_span(2, 200)
        ctx = context.get_current()

        bridge.push(span_a, ctx)
        bridge.push(span_b, ctx)

        # In trace 1, should only find span_a
        token = context.attach(trace.set_span_in_context(span_a))
        try:
            result = bridge.get_nearest_parent()
            assert result is not None
            result_span = trace.get_current_span(result)
            assert result_span.get_span_context().span_id == span_a.get_span_context().span_id
        finally:
            context.detach(token)

        # In trace 2, should only find span_b
        token = context.attach(trace.set_span_in_context(span_b))
        try:
            result = bridge.get_nearest_parent()
            assert result is not None
            result_span = trace.get_current_span(result)
            assert result_span.get_span_context().span_id == span_b.get_span_context().span_id
        finally:
            context.detach(token)

    def test_stale_cleanup(self):
        bridge = _SpanContextBridge()
        span = _make_span(1, 100)
        ctx = context.get_current()

        bridge.push(span, ctx)

        # Advance monotonic time past TTL
        token = context.attach(trace.set_span_in_context(span))
        try:
            with patch("coalex.ext._context_bridge.time") as mock_time:
                # Push was at time 0, now at time 301 (past 300s TTL)
                mock_time.monotonic.return_value = time.monotonic() + 301
                result = bridge.get_nearest_parent()
                assert result is None
        finally:
            context.detach(token)

    def test_thread_safety(self):
        bridge = _SpanContextBridge()
        ctx = context.get_current()
        errors: list[Exception] = []

        def push_pop(tid: int) -> None:
            try:
                for i in range(100):
                    span = _make_span(tid, i + 1)
                    bridge.push(span, ctx)
                    bridge.pop(span.get_span_context())
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=push_pop, args=(t,)) for t in range(1, 5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0

    def test_clear(self):
        bridge = _SpanContextBridge()
        span = _make_span(1, 100)
        ctx = context.get_current()

        bridge.push(span, ctx)
        bridge.clear()

        token = context.attach(trace.set_span_in_context(span))
        try:
            assert bridge.get_nearest_parent() is None
        finally:
            context.detach(token)

    def test_invalid_span_context_ignored(self):
        bridge = _SpanContextBridge()
        # Invalid span (trace_id=0, span_id=0)
        invalid_span = NonRecordingSpan(SpanContext(trace_id=0, span_id=0, is_remote=False))
        ctx = context.get_current()

        bridge.push(invalid_span, ctx)
        # Should not crash and bridge should be empty
        assert bridge.get_nearest_parent() is None
