"""Integration tests for span context bridge fixing async parenting.

Simulates LangGraph's pattern of dispatching sync tool functions to
thread executors, which breaks OTel implicit context propagation.
"""

from __future__ import annotations

import concurrent.futures

from coalex.ext._context_bridge import span_context_bridge
from coalex.ext.retrieval import Document, retrieval_span
from opentelemetry import context, trace


@retrieval_span(name="pubmed_retrieval", query_arg="query")
def _retrieve_pubmed(query: str) -> list[Document]:
    """Simulated retrieval function decorated with @retrieval_span."""
    return [Document(content="result for " + query, id="pmid1")]


def test_retriever_parented_under_tool_across_thread(memory_exporter):
    """Core test: RETRIEVER span parents under TOOL span even across thread boundary.

    Simulates the LangGraph async context loss:
    1. Create a TOOL span (like OpenInference auto-instrumentor)
    2. In a separate thread (like LangGraph's executor), call @retrieval_span
    3. Verify RETRIEVER is a child of TOOL, not the root
    """
    tracer = trace.get_tracer("test")

    with tracer.start_as_current_span("coalex.invocation") as root_span:
        root_span.set_attribute("coalex.agent_id", "test-agent")

        # Capture context BEFORE the TOOL span — this simulates the stale
        # context that LangGraph copies to the thread pool at dispatch time
        stale_ctx = context.get_current()

        # OpenInference creates TOOL spans via start_span() WITHOUT setting
        # openinference.span.kind at creation time (it's set at on_end).
        # The bridge tracks ALL spans, so no attribute needed here.
        with (
            tracer.start_as_current_span("pubmed_search"),
            concurrent.futures.ThreadPoolExecutor() as pool,
        ):
            # Simulate LangGraph dispatching to thread executor with stale context
            future = pool.submit(_run_in_thread_with_context, stale_ctx)
            future.result()

    spans = memory_exporter.get_finished_spans()
    retriever = next(s for s in spans if s.name == "pubmed_retrieval")
    tool = next(s for s in spans if s.name == "pubmed_search")

    # RETRIEVER should be parented under TOOL, not under root
    assert retriever.parent is not None
    assert retriever.parent.span_id == tool.context.span_id


def _run_in_thread_with_context(ctx: context.Context) -> None:
    """Run the retrieval in a thread with an explicit (stale) context."""
    token = context.attach(ctx)
    try:
        _retrieve_pubmed(query="diabetes treatment")
    finally:
        context.detach(token)


def test_fallback_to_implicit_context_without_bridge(memory_exporter):
    """Without a TOOL span in the bridge, decorator uses implicit context (normal case)."""
    span_context_bridge.clear()
    tracer = trace.get_tracer("test")

    with tracer.start_as_current_span("coalex.invocation"):
        _retrieve_pubmed(query="test")

    spans = memory_exporter.get_finished_spans()
    retriever = next(s for s in spans if s.name == "pubmed_retrieval")
    root_span = next(s for s in spans if s.name == "coalex.invocation")

    # Should be child of root (implicit context, no bridge)
    assert retriever.parent is not None
    assert retriever.parent.span_id == root_span.context.span_id


def test_parallel_tools_correct_parenting(memory_exporter):
    """Two TOOL spans in same trace, each thread gets correct parent."""
    tracer = trace.get_tracer("test")

    with tracer.start_as_current_span("coalex.invocation"):
        # Create two TOOL spans sequentially, run retrieval in each
        with tracer.start_as_current_span("tool_1"):

            @retrieval_span(name="retrieval_1")
            def retrieve_1(query: str) -> list[Document]:
                return [Document(content="r1")]

            retrieve_1(query="q1")

        with tracer.start_as_current_span("tool_2"):

            @retrieval_span(name="retrieval_2")
            def retrieve_2(query: str) -> list[Document]:
                return [Document(content="r2")]

            retrieve_2(query="q2")

    spans = memory_exporter.get_finished_spans()
    r1 = next(s for s in spans if s.name == "retrieval_1")
    r2 = next(s for s in spans if s.name == "retrieval_2")
    t1 = next(s for s in spans if s.name == "tool_1")
    t2 = next(s for s in spans if s.name == "tool_2")

    assert r1.parent.span_id == t1.context.span_id
    assert r2.parent.span_id == t2.context.span_id
