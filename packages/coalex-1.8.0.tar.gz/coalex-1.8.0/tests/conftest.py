"""Shared test fixtures for SDK tests."""

import pytest
from coalex.span_processor import CoalexAttributePropagator
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter


@pytest.fixture(autouse=True)
def _reset_tracer_provider():
    """Reset the global TracerProvider before each test so set_tracer_provider works."""
    trace._TRACER_PROVIDER_SET_ONCE._done = False
    trace._TRACER_PROVIDER = None
    yield
    # Clean up after test
    provider = trace.get_tracer_provider()
    if isinstance(provider, TracerProvider):
        provider.shutdown()
    trace._TRACER_PROVIDER_SET_ONCE._done = False
    trace._TRACER_PROVIDER = None


@pytest.fixture()
def memory_exporter():
    """Provide an InMemorySpanExporter and a fresh TracerProvider with attribute propagation."""
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(CoalexAttributePropagator())
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    trace.set_tracer_provider(provider)
    return exporter
