"""Tests for coalex.register()."""

import coalex
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider


def test_register_sets_tracer_provider():
    """register() should install an SDK TracerProvider."""
    coalex.register(endpoint="http://localhost:8080")
    provider = trace.get_tracer_provider()
    assert isinstance(provider, TracerProvider)
    provider.shutdown()


def test_register_configures_endpoint():
    """register() should store the configured endpoint."""
    coalex.register(endpoint="http://localhost:9999")
    assert coalex._config is not None
    assert coalex._config.endpoint == "http://localhost:9999"
    provider = trace.get_tracer_provider()
    if isinstance(provider, TracerProvider):
        provider.shutdown()


def test_register_default_endpoint():
    """register() without args should use the cloud endpoint."""
    coalex.register()
    assert coalex._config is not None
    assert coalex._config.endpoint == "https://traces.azure.coalex.ai"
    provider = trace.get_tracer_provider()
    if isinstance(provider, TracerProvider):
        provider.shutdown()
