"""codevelopment"""

__version__ = "0.0.1"

from codevelopment.client import guidelines
