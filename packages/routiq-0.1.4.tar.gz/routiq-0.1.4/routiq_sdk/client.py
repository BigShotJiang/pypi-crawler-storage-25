"""Thin Routiq client — wraps the OpenAI SDK pointed at a Routiq gateway.

Usage:
    from routiq import RoutiqClient

    client = RoutiqClient(api_key="routiq-key", base_url="http://localhost:8001")

    # Let Routiq pick the model automatically based on request complexity
    response = client.chat(messages=[{"role": "user", "content": "Hello"}])

    # Pin a specific provider/model alias
    response = client.chat(model="claude-latest", messages=[...])
    response = client.chat(model="gemini-flash-latest", messages=[...])
    response = client.chat(model="deepseek-latest", messages=[...])

    # Async variant
    response = await client.achat(messages=[...])
"""
from __future__ import annotations

from typing import Any

import openai


class RoutiqClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = "http://localhost:8001",
    ) -> None:
        v1 = base_url.rstrip("/") + "/v1"
        self._sync = openai.OpenAI(api_key=api_key, base_url=v1)
        self._async = openai.AsyncOpenAI(api_key=api_key, base_url=v1)

    def chat(
        self,
        messages: list[dict[str, Any]],
        *,
        model: str = "auto",
        max_tokens: int | None = None,
        temperature: float | None = None,
        tools: list | None = None,
    ) -> openai.types.chat.ChatCompletion:
        kwargs: dict[str, Any] = {"model": model, "messages": messages}
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        if temperature is not None:
            kwargs["temperature"] = temperature
        if tools:
            kwargs["tools"] = tools
        return self._sync.chat.completions.create(**kwargs)

    async def achat(
        self,
        messages: list[dict[str, Any]],
        *,
        model: str = "auto",
        max_tokens: int | None = None,
        temperature: float | None = None,
        tools: list | None = None,
    ) -> openai.types.chat.ChatCompletion:
        kwargs: dict[str, Any] = {"model": model, "messages": messages}
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        if temperature is not None:
            kwargs["temperature"] = temperature
        if tools:
            kwargs["tools"] = tools
        return await self._async.chat.completions.create(**kwargs)
