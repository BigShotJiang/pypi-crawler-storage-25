"""Tests for routiq.pipeline.router — 3-tier routing and _resolve_tier."""
import pytest
from unittest.mock import patch, MagicMock, call
from routiq.pipeline.analyzer import Complexity
from routiq.pipeline import router as router_mod


def _settings(simple="gpt-4o-mini", medium="gpt-4o-mini", complex_="gpt-4o"):
    s = MagicMock()
    s.simple_model = simple
    s.medium_model = medium
    s.complex_model = complex_
    return s


# ── _resolve_tier ──────────────────────────────────────────────────────────

class TestResolveTier:
    def test_single_registered_entry(self):
        with patch("routiq.pipeline.router.resolve", return_value=("gpt-4o-mini", "openai")):
            with patch("routiq.pipeline.router.is_registered", return_value=True):
                model, provider = router_mod._resolve_tier("gpt-4o-mini")
        assert model == "gpt-4o-mini"
        assert provider == "openai"

    def test_first_of_two_is_registered_wins(self):
        resolve_map = {
            "gemini-flash-latest": ("gemini-2.5-flash", "gemini"),
            "gpt-4o-mini": ("gpt-4o-mini", "openai"),
        }
        registered = {"gemini"}

        with patch("routiq.pipeline.router.resolve", side_effect=lambda a: resolve_map[a]):
            with patch("routiq.pipeline.router.is_registered", side_effect=lambda p: p in registered):
                model, provider = router_mod._resolve_tier("gemini-flash-latest,gpt-4o-mini")
        assert model == "gemini-2.5-flash"
        assert provider == "gemini"

    def test_second_used_when_first_not_registered(self):
        resolve_map = {
            "gemini-flash-latest": ("gemini-2.5-flash", "gemini"),
            "gpt-4o-mini": ("gpt-4o-mini", "openai"),
        }
        registered = {"openai"}

        with patch("routiq.pipeline.router.resolve", side_effect=lambda a: resolve_map[a]):
            with patch("routiq.pipeline.router.is_registered", side_effect=lambda p: p in registered):
                model, provider = router_mod._resolve_tier("gemini-flash-latest,gpt-4o-mini")
        assert model == "gpt-4o-mini"
        assert provider == "openai"

    def test_fallback_to_last_when_none_registered(self):
        resolve_map = {
            "gemini-flash-latest": ("gemini-2.5-flash", "gemini"),
            "gpt-4o-mini": ("gpt-4o-mini", "openai"),
        }
        with patch("routiq.pipeline.router.resolve", side_effect=lambda a: resolve_map[a]):
            with patch("routiq.pipeline.router.is_registered", return_value=False):
                model, provider = router_mod._resolve_tier("gemini-flash-latest,gpt-4o-mini")
        assert model == "gpt-4o-mini"
        assert provider == "openai"

    def test_three_candidates_picks_second_registered(self):
        resolve_map = {
            "a": ("ma", "pa"),
            "b": ("mb", "pb"),
            "c": ("mc", "pc"),
        }
        registered = {"pb"}
        with patch("routiq.pipeline.router.resolve", side_effect=lambda a: resolve_map[a]):
            with patch("routiq.pipeline.router.is_registered", side_effect=lambda p: p in registered):
                model, provider = router_mod._resolve_tier("a,b,c")
        assert model == "mb"
        assert provider == "pb"

    def test_strips_whitespace_around_entries(self):
        with patch("routiq.pipeline.router.resolve", return_value=("gpt-4o-mini", "openai")):
            with patch("routiq.pipeline.router.is_registered", return_value=True):
                model, provider = router_mod._resolve_tier("  gpt-4o-mini  ")
        assert model == "gpt-4o-mini"

    def test_single_entry_fallback_even_if_not_registered(self):
        with patch("routiq.pipeline.router.resolve", return_value=("gpt-4o", "openai")):
            with patch("routiq.pipeline.router.is_registered", return_value=False):
                model, provider = router_mod._resolve_tier("gpt-4o")
        assert model == "gpt-4o"


# ── route() — no hint (pure complexity routing) ────────────────────────────

class TestRouteNoHint:
    """When model_hint is None, route purely on complexity tier."""

    def _route(self, complexity, simple=("gpt-4o-mini", "openai"),
               medium=("gpt-4o-mini", "openai"), complex_=("gpt-4o", "openai")):
        # Router calls _resolve_tier in order: complex, medium, simple
        settings = _settings()
        with patch("routiq.pipeline.router.get_settings", return_value=settings):
            with patch("routiq.pipeline.router._resolve_tier", side_effect=[complex_, medium, simple]):
                return router_mod.route(complexity)

    def test_simple_uses_simple_tier(self):
        provider, model, reason = self._route(Complexity.SIMPLE)
        assert model == "gpt-4o-mini"
        assert reason == "complexity_simple"

    def test_medium_uses_medium_tier(self):
        provider, model, reason = self._route(
            Complexity.MEDIUM,
            medium=("claude-haiku-4-5-20251001", "anthropic"),
        )
        assert model == "claude-haiku-4-5-20251001"
        assert reason == "complexity_medium"

    def test_complex_uses_complex_tier(self):
        provider, model, reason = self._route(
            Complexity.COMPLEX,
            complex_=("claude-sonnet-4-20250514", "anthropic"),
        )
        assert model == "claude-sonnet-4-20250514"
        assert reason == "complexity_complex"

    def test_provider_matches_tier(self):
        provider, model, reason = self._route(
            Complexity.COMPLEX,
            complex_=("gemini-2.5-pro", "gemini"),
        )
        assert provider == "gemini"


# ── route() — unknown model hint ───────────────────────────────────────────

class TestRouteUnknownHint:
    def test_unknown_model_passes_through(self):
        settings = _settings()
        with patch("routiq.pipeline.router.get_settings", return_value=settings):
            with patch("routiq.pipeline.router._resolve_tier", return_value=("gpt-4o-mini", "openai")):
                with patch("routiq.pipeline.router._known_models", return_value=frozenset()):
                    with patch("routiq.pipeline.router.resolve", return_value=("my-llm", "openai")):
                        provider, model, reason = router_mod.route(Complexity.SIMPLE, "my-llm")
        assert reason == "unknown_model_passthrough"
        assert model == "my-llm"

    def test_unknown_model_provider_preserved(self):
        settings = _settings()
        with patch("routiq.pipeline.router.get_settings", return_value=settings):
            with patch("routiq.pipeline.router._resolve_tier", return_value=("gpt-4o-mini", "openai")):
                with patch("routiq.pipeline.router._known_models", return_value=frozenset()):
                    with patch("routiq.pipeline.router.resolve", return_value=("custom-model", "custom")):
                        provider, model, reason = router_mod.route(Complexity.COMPLEX, "custom-model")
        assert provider == "custom"
        assert reason == "unknown_model_passthrough"


# ── route() — hint upgrade logic ───────────────────────────────────────────

class TestRouteHintUpgrade:
    def _route_with_hint(self, complexity, hint, hint_resolved,
                         simple=("gpt-4o-mini", "openai"),
                         medium=("gpt-4o-mini", "openai"),
                         complex_=("gpt-4o", "openai")):
        # Router calls _resolve_tier in order: complex, medium, simple
        settings = _settings()
        with patch("routiq.pipeline.router.get_settings", return_value=settings):
            with patch("routiq.pipeline.router._resolve_tier", side_effect=[complex_, medium, simple]):
                with patch("routiq.pipeline.router._known_models", return_value=frozenset([hint])):
                    with patch("routiq.pipeline.router.resolve", return_value=hint_resolved):
                        return router_mod.route(complexity, hint)

    def test_complex_request_upgrades_simple_tier_hint(self):
        provider, model, reason = self._route_with_hint(
            Complexity.COMPLEX,
            hint="gpt-4o-mini",
            hint_resolved=("gpt-4o-mini", "openai"),
            simple=("gpt-4o-mini", "openai"),
            complex_=("gpt-4o", "openai"),
        )
        assert model == "gpt-4o"
        assert reason == "complexity_complex"

    def test_complex_request_upgrades_medium_tier_hint(self):
        provider, model, reason = self._route_with_hint(
            Complexity.COMPLEX,
            hint="gpt-4o-mini",
            hint_resolved=("gpt-4o-mini", "openai"),
            simple=("gemini-2.5-flash", "gemini"),
            medium=("gpt-4o-mini", "openai"),
            complex_=("claude-sonnet-4-20250514", "anthropic"),
        )
        assert model == "claude-sonnet-4-20250514"
        assert reason == "complexity_complex"

    def test_medium_request_upgrades_simple_tier_hint(self):
        provider, model, reason = self._route_with_hint(
            Complexity.MEDIUM,
            hint="gemini-flash-latest",
            hint_resolved=("gemini-2.5-flash", "gemini"),
            simple=("gemini-2.5-flash", "gemini"),
            medium=("gpt-4o-mini", "openai"),
            complex_=("gpt-4o", "openai"),
        )
        assert model == "gpt-4o-mini"
        assert reason == "complexity_medium"

    def test_complex_request_respects_complex_tier_hint(self):
        """User explicitly requested the complex tier — no upgrade needed."""
        provider, model, reason = self._route_with_hint(
            Complexity.COMPLEX,
            hint="gpt-4o",
            hint_resolved=("gpt-4o", "openai"),
            complex_=("gpt-4o", "openai"),
        )
        assert model == "gpt-4o"
        assert reason == "hint_respected"

    def test_simple_request_never_downgrades_complex_hint(self):
        """User asked for expensive model on a simple request — respect it."""
        provider, model, reason = self._route_with_hint(
            Complexity.SIMPLE,
            hint="gpt-4o",
            hint_resolved=("gpt-4o", "openai"),
            simple=("gpt-4o-mini", "openai"),
            complex_=("gpt-4o", "openai"),
        )
        assert model == "gpt-4o"
        assert reason == "hint_respected"

    def test_medium_request_respects_complex_hint(self):
        provider, model, reason = self._route_with_hint(
            Complexity.MEDIUM,
            hint="gpt-4o",
            hint_resolved=("gpt-4o", "openai"),
            simple=("gpt-4o-mini", "openai"),
            medium=("gpt-4o-mini", "openai"),
            complex_=("gpt-4o", "openai"),
        )
        assert reason == "hint_respected"
        assert model == "gpt-4o"

    def test_cross_provider_upgrade_anthropic_to_openai(self):
        """Hint resolves to gemini (simple tier), request is COMPLEX → upgrade to claude."""
        provider, model, reason = self._route_with_hint(
            Complexity.COMPLEX,
            hint="gemini-flash-latest",
            hint_resolved=("gemini-2.5-flash", "gemini"),
            simple=("gemini-2.5-flash", "gemini"),
            complex_=("claude-sonnet-4-20250514", "anthropic"),
        )
        assert provider == "anthropic"
        assert reason == "complexity_complex"
