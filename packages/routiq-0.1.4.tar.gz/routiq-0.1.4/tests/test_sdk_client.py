"""Tests for routiq.sdk.client — RoutiqClient thin wrapper."""
import asyncio
import pytest
from unittest.mock import MagicMock, patch, AsyncMock
from routiq.sdk.client import RoutiqClient
from routiq import RoutiqClient as TopLevelExport


class TestRoutiqClientInit:
    def test_appends_v1_to_base_url(self):
        with patch("routiq.sdk.client.openai.OpenAI") as MockOAI:
            with patch("routiq.sdk.client.openai.AsyncOpenAI") as MockAOAI:
                RoutiqClient(api_key="rq-key", base_url="http://localhost:8001")
        MockOAI.assert_called_once_with(api_key="rq-key", base_url="http://localhost:8001/v1")
        MockAOAI.assert_called_once_with(api_key="rq-key", base_url="http://localhost:8001/v1")

    def test_strips_trailing_slash_from_base_url(self):
        with patch("routiq.sdk.client.openai.OpenAI") as MockOAI:
            with patch("routiq.sdk.client.openai.AsyncOpenAI"):
                RoutiqClient(api_key="rq-key", base_url="http://localhost:8001/")
        _, kwargs = MockOAI.call_args
        assert kwargs["base_url"] == "http://localhost:8001/v1"

    def test_default_base_url(self):
        with patch("routiq.sdk.client.openai.OpenAI") as MockOAI:
            with patch("routiq.sdk.client.openai.AsyncOpenAI"):
                RoutiqClient(api_key="rq-key")
        _, kwargs = MockOAI.call_args
        assert "localhost:8001" in kwargs["base_url"]

    def test_api_key_forwarded(self):
        with patch("routiq.sdk.client.openai.OpenAI") as MockOAI:
            with patch("routiq.sdk.client.openai.AsyncOpenAI"):
                RoutiqClient(api_key="my-secret-key")
        _, kwargs = MockOAI.call_args
        assert kwargs["api_key"] == "my-secret-key"


class TestRoutiqClientChat:
    def _client(self):
        with patch("routiq.sdk.client.openai.OpenAI") as MockOAI:
            with patch("routiq.sdk.client.openai.AsyncOpenAI"):
                client = RoutiqClient(api_key="rq-key")
                client._sync = MockOAI.return_value
                return client, MockOAI.return_value

    def test_chat_sends_model_and_messages(self):
        client, mock_sync = self._client()
        messages = [{"role": "user", "content": "hello"}]
        client.chat(messages=messages, model="claude-latest")
        mock_sync.chat.completions.create.assert_called_once_with(
            model="claude-latest", messages=messages
        )

    def test_chat_default_model_is_auto(self):
        client, mock_sync = self._client()
        messages = [{"role": "user", "content": "hi"}]
        client.chat(messages=messages)
        call_kwargs = mock_sync.chat.completions.create.call_args[1]
        assert call_kwargs["model"] == "auto"

    def test_chat_forwards_max_tokens(self):
        client, mock_sync = self._client()
        client.chat(messages=[{"role": "user", "content": "x"}], max_tokens=512)
        kwargs = mock_sync.chat.completions.create.call_args[1]
        assert kwargs["max_tokens"] == 512

    def test_chat_forwards_temperature(self):
        client, mock_sync = self._client()
        client.chat(messages=[{"role": "user", "content": "x"}], temperature=0.7)
        kwargs = mock_sync.chat.completions.create.call_args[1]
        assert kwargs["temperature"] == 0.7

    def test_chat_forwards_tools(self):
        client, mock_sync = self._client()
        tools = [{"type": "function", "function": {"name": "search"}}]
        client.chat(messages=[{"role": "user", "content": "x"}], tools=tools)
        kwargs = mock_sync.chat.completions.create.call_args[1]
        assert kwargs["tools"] == tools

    def test_chat_omits_none_max_tokens(self):
        client, mock_sync = self._client()
        client.chat(messages=[{"role": "user", "content": "x"}])
        kwargs = mock_sync.chat.completions.create.call_args[1]
        assert "max_tokens" not in kwargs

    def test_chat_omits_none_temperature(self):
        client, mock_sync = self._client()
        client.chat(messages=[{"role": "user", "content": "x"}])
        kwargs = mock_sync.chat.completions.create.call_args[1]
        assert "temperature" not in kwargs

    def test_chat_omits_empty_tools(self):
        client, mock_sync = self._client()
        client.chat(messages=[{"role": "user", "content": "x"}], tools=None)
        kwargs = mock_sync.chat.completions.create.call_args[1]
        assert "tools" not in kwargs

    def test_chat_returns_sdk_response(self):
        client, mock_sync = self._client()
        fake_response = MagicMock()
        mock_sync.chat.completions.create.return_value = fake_response
        result = client.chat(messages=[{"role": "user", "content": "x"}])
        assert result is fake_response


class TestRoutiqClientAchat:
    def _async_client(self):
        with patch("routiq.sdk.client.openai.OpenAI"):
            with patch("routiq.sdk.client.openai.AsyncOpenAI"):
                client = RoutiqClient(api_key="rq-key")
                mock_async = MagicMock()
                mock_async.chat.completions.create = AsyncMock(return_value=MagicMock())
                client._async = mock_async
                return client, mock_async

    def test_achat_is_awaitable(self):
        client, mock_async = self._async_client()
        result = asyncio.run(client.achat(messages=[{"role": "user", "content": "hi"}]))
        mock_async.chat.completions.create.assert_called_once()

    def test_achat_default_model_is_auto(self):
        client, mock_async = self._async_client()
        asyncio.run(client.achat(messages=[{"role": "user", "content": "hi"}]))
        kwargs = mock_async.chat.completions.create.call_args[1]
        assert kwargs["model"] == "auto"

    def test_achat_forwards_model(self):
        client, mock_async = self._async_client()
        asyncio.run(client.achat(
            messages=[{"role": "user", "content": "hi"}],
            model="gemini-flash-latest",
        ))
        kwargs = mock_async.chat.completions.create.call_args[1]
        assert kwargs["model"] == "gemini-flash-latest"

    def test_achat_forwards_max_tokens(self):
        client, mock_async = self._async_client()
        asyncio.run(client.achat(
            messages=[{"role": "user", "content": "hi"}],
            max_tokens=256,
        ))
        kwargs = mock_async.chat.completions.create.call_args[1]
        assert kwargs["max_tokens"] == 256

    def test_achat_returns_response(self):
        client, mock_async = self._async_client()
        fake = MagicMock()
        mock_async.chat.completions.create = AsyncMock(return_value=fake)
        result = asyncio.run(client.achat(messages=[{"role": "user", "content": "hi"}]))
        assert result is fake


class TestTopLevelExport:
    def test_routiq_client_importable_from_package(self):
        assert TopLevelExport is RoutiqClient
