"""Tests for routiq.pipeline.alias — model alias resolver."""
import pytest
import routiq.pipeline.alias as alias_mod
from routiq.pipeline.alias import infer_provider, resolve


@pytest.fixture(autouse=True)
def reset_alias_cache():
    """Reset global alias module state between tests."""
    alias_mod._cache = {}
    alias_mod._mtime = 0.0
    alias_mod._last_checked = 0.0
    yield
    alias_mod._cache = {}
    alias_mod._mtime = 0.0
    alias_mod._last_checked = 0.0


@pytest.fixture()
def models_yml(tmp_path):
    content = """
aliases:
  gemini-flash-latest:
    model: gemini-2.5-flash
    provider: gemini
  deepseek-latest:
    model: deepseek-chat
    provider: deepseek
  claude-latest:
    model: claude-sonnet-4-20250514
    provider: anthropic
"""
    p = tmp_path / "models.yml"
    p.write_text(content)
    return str(p)


@pytest.fixture()
def patched_settings(models_yml, monkeypatch):
    from unittest.mock import MagicMock
    settings = MagicMock()
    settings.models_yaml_path = models_yml
    monkeypatch.setattr("routiq.pipeline.alias.get_settings", lambda: settings)
    return settings


class TestInferProvider:
    def test_gpt_prefix(self):
        assert infer_provider("gpt-4o") == "openai"

    def test_gpt_mini(self):
        assert infer_provider("gpt-4o-mini") == "openai"

    def test_o1_prefix(self):
        assert infer_provider("o1-preview") == "openai"

    def test_o3_prefix(self):
        assert infer_provider("o3-mini") == "openai"

    def test_claude_prefix(self):
        assert infer_provider("claude-sonnet-4-20250514") == "anthropic"

    def test_claude_haiku(self):
        assert infer_provider("claude-haiku-4-5") == "anthropic"

    def test_unknown_raises_value_error(self):
        with pytest.raises(ValueError, match="Cannot infer provider"):
            infer_provider("gemini-2.5-flash")

    def test_deepseek_raises(self):
        with pytest.raises(ValueError):
            infer_provider("deepseek-chat")

    def test_empty_string_raises(self):
        with pytest.raises(ValueError):
            infer_provider("")


class TestResolve:
    def test_gpt_passthrough(self):
        model, provider = resolve("gpt-4o")
        assert model == "gpt-4o"
        assert provider == "openai"

    def test_claude_passthrough(self):
        model, provider = resolve("claude-sonnet-4-20250514")
        assert model == "claude-sonnet-4-20250514"
        assert provider == "anthropic"

    def test_alias_lookup_gemini(self, patched_settings):
        model, provider = resolve("gemini-flash-latest")
        assert model == "gemini-2.5-flash"
        assert provider == "gemini"

    def test_alias_lookup_deepseek(self, patched_settings):
        model, provider = resolve("deepseek-latest")
        assert model == "deepseek-chat"
        assert provider == "deepseek"

    def test_alias_lookup_anthropic(self, patched_settings):
        model, provider = resolve("claude-latest")
        assert model == "claude-sonnet-4-20250514"
        assert provider == "anthropic"

    def test_unknown_alias_raises(self, patched_settings):
        with pytest.raises(ValueError, match="Cannot infer provider"):
            resolve("nonexistent-alias")

    def test_missing_yaml_returns_empty_cache(self, monkeypatch):
        from unittest.mock import MagicMock
        settings = MagicMock()
        settings.models_yaml_path = "/nonexistent/path/models.yml"
        monkeypatch.setattr("routiq.pipeline.alias.get_settings", lambda: settings)
        # OSError on missing file → returns cached empty dict → infer_provider for gpt-*
        model, provider = resolve("gpt-4o")
        assert provider == "openai"
