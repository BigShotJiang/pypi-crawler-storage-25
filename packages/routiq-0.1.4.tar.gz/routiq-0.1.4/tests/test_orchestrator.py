"""Tests for routiq.pipeline.orchestrator — pipeline integration."""
import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from routiq.adapters.base import NormalizedResponse, TokenUsage
from routiq.pipeline import orchestrator
from routiq.pipeline.analyzer import Complexity


def run(coro):
    return asyncio.run(coro)


def _fake_response(model="gpt-4o-mini", provider="openai", content="Hello"):
    return NormalizedResponse(
        content=content,
        model=model,
        usage=TokenUsage(input_tokens=10, output_tokens=5),
        finish_reason="stop",
        provider=provider,
    )


def _cost_breakdown():
    from routiq.pipeline.cost import CostBreakdown
    return CostBreakdown(
        input_cost=0.001, output_cost=0.002,
        cache_read_cost=0.0, cache_creation_cost=0.0,
        total_cost=0.003, baseline_cost=0.005, saved_cost=0.002,
    )


@pytest.fixture()
def mock_pipeline(monkeypatch):
    """Patch all pipeline collaborators with controllable fakes."""
    cache_get = AsyncMock(return_value=None)       # cache miss by default
    cache_set = AsyncMock()
    cache_key  = MagicMock(return_value="test-key")
    cost_record = AsyncMock()
    cost_calc   = MagicMock(return_value=_cost_breakdown())
    cost_baseline = MagicMock(return_value=0.005)
    adapter_complete = AsyncMock(return_value=_fake_response())
    mock_adapter = MagicMock()
    mock_adapter.complete = adapter_complete

    monkeypatch.setattr("routiq.pipeline.orchestrator.cache.get",       cache_get)
    monkeypatch.setattr("routiq.pipeline.orchestrator.cache.set",       cache_set)
    monkeypatch.setattr("routiq.pipeline.orchestrator.cache.cache_key", cache_key)
    monkeypatch.setattr("routiq.pipeline.orchestrator.cost.record",      cost_record)
    monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_cost",     cost_calc)
    monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_baseline", cost_baseline)
    monkeypatch.setattr("routiq.pipeline.orchestrator.get_adapter",     MagicMock(return_value=mock_adapter))
    monkeypatch.setattr("routiq.pipeline.orchestrator.router.route",
                        MagicMock(return_value=("openai", "gpt-4o-mini", "complexity_simple")))
    monkeypatch.setattr("routiq.pipeline.orchestrator.analyzer.classify",
                        MagicMock(return_value=(Complexity.SIMPLE, "default")))
    monkeypatch.setattr("routiq.pipeline.orchestrator.alias.resolve",
                        MagicMock(return_value=("gpt-4o-mini", "openai")))

    return {
        "cache_get": cache_get,
        "cache_set": cache_set,
        "cache_key": cache_key,
        "cost_record": cost_record,
        "adapter_complete": adapter_complete,
        "mock_adapter": mock_adapter,
        "router_route": None,  # patched inline per test when needed
    }


# ── model sentinel handling ────────────────────────────────────────────────

class TestModelSentinelHandling:
    def test_auto_sentinel_passes_none_hint_to_router(self, monkeypatch):
        mock_route = MagicMock(return_value=("openai", "gpt-4o-mini", "complexity_simple"))

        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.get",           AsyncMock(return_value=None))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.set",           AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.cache_key",     MagicMock(return_value="k"))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.record",         AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_cost", MagicMock(return_value=_cost_breakdown()))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_baseline", MagicMock(return_value=0.0))
        mock_adapter = MagicMock()
        mock_adapter.complete = AsyncMock(return_value=_fake_response())
        monkeypatch.setattr("routiq.pipeline.orchestrator.get_adapter",         MagicMock(return_value=mock_adapter))
        monkeypatch.setattr("routiq.pipeline.orchestrator.analyzer.classify",   MagicMock(return_value=(Complexity.SIMPLE, "default")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.alias.resolve",       MagicMock(return_value=("", "")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.router.route",        mock_route)

        run(orchestrator.process({"model": "auto", "messages": [{"role": "user", "content": "hi"}]}))
        _, hint = mock_route.call_args[0]
        assert hint is None, f"expected None hint for model='auto', got {hint!r}"

    def test_empty_model_passes_none_hint_to_router(self, monkeypatch):
        mock_route = MagicMock(return_value=("openai", "gpt-4o-mini", "complexity_simple"))

        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.get",           AsyncMock(return_value=None))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.set",           AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.cache_key",     MagicMock(return_value="k"))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.record",         AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_cost", MagicMock(return_value=_cost_breakdown()))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_baseline", MagicMock(return_value=0.0))
        mock_adapter = MagicMock()
        mock_adapter.complete = AsyncMock(return_value=_fake_response())
        monkeypatch.setattr("routiq.pipeline.orchestrator.get_adapter",         MagicMock(return_value=mock_adapter))
        monkeypatch.setattr("routiq.pipeline.orchestrator.analyzer.classify",   MagicMock(return_value=(Complexity.SIMPLE, "default")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.alias.resolve",       MagicMock(return_value=("", "")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.router.route",        mock_route)

        run(orchestrator.process({"model": "", "messages": [{"role": "user", "content": "hi"}]}))
        _, hint = mock_route.call_args[0]
        assert hint is None

    def test_absent_model_passes_none_hint_to_router(self, monkeypatch):
        mock_route = MagicMock(return_value=("openai", "gpt-4o-mini", "complexity_simple"))

        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.get",           AsyncMock(return_value=None))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.set",           AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.cache_key",     MagicMock(return_value="k"))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.record",         AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_cost", MagicMock(return_value=_cost_breakdown()))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_baseline", MagicMock(return_value=0.0))
        mock_adapter = MagicMock()
        mock_adapter.complete = AsyncMock(return_value=_fake_response())
        monkeypatch.setattr("routiq.pipeline.orchestrator.get_adapter",         MagicMock(return_value=mock_adapter))
        monkeypatch.setattr("routiq.pipeline.orchestrator.analyzer.classify",   MagicMock(return_value=(Complexity.SIMPLE, "default")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.alias.resolve",       MagicMock(return_value=("", "")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.router.route",        mock_route)

        run(orchestrator.process({"messages": [{"role": "user", "content": "hi"}]}))
        _, hint = mock_route.call_args[0]
        assert hint is None

    def test_explicit_model_passes_hint_to_router(self, monkeypatch):
        mock_route = MagicMock(return_value=("anthropic", "claude-sonnet-4-20250514", "hint_respected"))

        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.get",           AsyncMock(return_value=None))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.set",           AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.cache_key",     MagicMock(return_value="k"))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.record",         AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_cost", MagicMock(return_value=_cost_breakdown()))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_baseline", MagicMock(return_value=0.0))
        mock_adapter = MagicMock()
        mock_adapter.complete = AsyncMock(return_value=_fake_response("claude-sonnet-4-20250514", "anthropic"))
        monkeypatch.setattr("routiq.pipeline.orchestrator.get_adapter",         MagicMock(return_value=mock_adapter))
        monkeypatch.setattr("routiq.pipeline.orchestrator.analyzer.classify",   MagicMock(return_value=(Complexity.SIMPLE, "default")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.alias.resolve",       MagicMock(return_value=("claude-sonnet-4-20250514", "anthropic")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.router.route",        mock_route)

        run(orchestrator.process({"model": "claude-latest", "messages": [{"role": "user", "content": "hi"}]}))
        _, hint = mock_route.call_args[0]
        assert hint == "claude-latest"

    def test_auto_sentinel_skips_alias_resolution(self, monkeypatch):
        mock_resolve = MagicMock(return_value=("", ""))

        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.get",           AsyncMock(return_value=None))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.set",           AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.cache_key",     MagicMock(return_value="k"))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.record",         AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_cost", MagicMock(return_value=_cost_breakdown()))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_baseline", MagicMock(return_value=0.0))
        mock_adapter = MagicMock()
        mock_adapter.complete = AsyncMock(return_value=_fake_response())
        monkeypatch.setattr("routiq.pipeline.orchestrator.get_adapter",         MagicMock(return_value=mock_adapter))
        monkeypatch.setattr("routiq.pipeline.orchestrator.analyzer.classify",   MagicMock(return_value=(Complexity.SIMPLE, "default")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.alias.resolve",       mock_resolve)
        monkeypatch.setattr("routiq.pipeline.orchestrator.router.route",
                            MagicMock(return_value=("openai", "gpt-4o-mini", "complexity_simple")))

        run(orchestrator.process({"model": "auto", "messages": [{"role": "user", "content": "hi"}]}))
        mock_resolve.assert_not_called()


# ── cache hit path ─────────────────────────────────────────────────────────

class TestCacheHit:
    def test_cache_hit_returns_without_adapter_call(self, monkeypatch):
        cached = _fake_response()
        mock_adapter = MagicMock()
        mock_adapter.complete = AsyncMock()

        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.get",           AsyncMock(return_value=cached))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.set",           AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.cache_key",     MagicMock(return_value="k"))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.record",         AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_baseline", MagicMock(return_value=0.0))
        monkeypatch.setattr("routiq.pipeline.orchestrator.get_adapter",         MagicMock(return_value=mock_adapter))
        monkeypatch.setattr("routiq.pipeline.orchestrator.alias.resolve",       MagicMock(return_value=("gpt-4o-mini", "openai")))

        run(orchestrator.process({"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "hi"}]}))
        mock_adapter.complete.assert_not_called()

    def test_cache_hit_records_zero_cost(self, monkeypatch):
        cached = _fake_response()
        cost_record = AsyncMock()

        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.get",           AsyncMock(return_value=cached))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.set",           AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.cache_key",     MagicMock(return_value="k"))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.record",         cost_record)
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_baseline", MagicMock(return_value=0.01))
        monkeypatch.setattr("routiq.pipeline.orchestrator.get_adapter",         MagicMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.alias.resolve",       MagicMock(return_value=("gpt-4o-mini", "openai")))

        run(orchestrator.process({"model": "gpt-4o-mini", "messages": [{"role": "user", "content": "hi"}]}))
        kwargs = cost_record.call_args[1]
        assert kwargs["total_cost"] == 0.0
        assert kwargs["cache_hit"] is True
        assert kwargs["routing_reason"] == "cache_hit"

    def test_cache_hit_response_has_openai_format(self, monkeypatch):
        cached = _fake_response(content="Cached answer")

        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.get",           AsyncMock(return_value=cached))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.set",           AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.cache_key",     MagicMock(return_value="k"))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.record",         AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_baseline", MagicMock(return_value=0.0))
        monkeypatch.setattr("routiq.pipeline.orchestrator.get_adapter",         MagicMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.alias.resolve",       MagicMock(return_value=("gpt-4o-mini", "openai")))

        result, _ = run(orchestrator.process({"model": "gpt-4o-mini", "messages": []}))
        assert result["object"] == "chat.completion"
        assert result["choices"][0]["message"]["content"] == "Cached answer"


# ── cache miss full pipeline ───────────────────────────────────────────────

class TestCacheMiss:
    def _full_patch(self, monkeypatch, response=None, route=None):
        resp = response or _fake_response()
        mock_adapter = MagicMock()
        mock_adapter.complete = AsyncMock(return_value=resp)

        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.get",           AsyncMock(return_value=None))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.set",           AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.cache_key",     MagicMock(return_value="k"))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.record",         AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_cost", MagicMock(return_value=_cost_breakdown()))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_baseline", MagicMock(return_value=0.005))
        monkeypatch.setattr("routiq.pipeline.orchestrator.get_adapter",         MagicMock(return_value=mock_adapter))
        monkeypatch.setattr("routiq.pipeline.orchestrator.analyzer.classify",   MagicMock(return_value=(Complexity.SIMPLE, "default")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.alias.resolve",       MagicMock(return_value=("gpt-4o-mini", "openai")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.router.route",
                            route or MagicMock(return_value=("openai", "gpt-4o-mini", "complexity_simple")))
        return mock_adapter

    def test_adapter_is_called_on_cache_miss(self, monkeypatch):
        mock_adapter = self._full_patch(monkeypatch)
        run(orchestrator.process({"messages": [{"role": "user", "content": "hi"}]}))
        mock_adapter.complete.assert_called_once()

    def test_response_has_openai_format(self, monkeypatch):
        self._full_patch(monkeypatch, response=_fake_response(content="Hi there"))
        result, _ = run(orchestrator.process({"messages": [{"role": "user", "content": "hi"}]}))
        assert result["object"] == "chat.completion"
        assert result["choices"][0]["message"]["content"] == "Hi there"
        assert result["choices"][0]["message"]["role"] == "assistant"

    def test_response_contains_request_id(self, monkeypatch):
        self._full_patch(monkeypatch)
        result, request_id = run(orchestrator.process({"messages": []}))
        assert request_id in result["id"]

    def test_cost_record_called_once(self, monkeypatch):
        cost_record = AsyncMock()
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.get",           AsyncMock(return_value=None))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.set",           AsyncMock())
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.cache_key",     MagicMock(return_value="k"))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.record",         cost_record)
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_cost", MagicMock(return_value=_cost_breakdown()))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cost.calculate_baseline", MagicMock(return_value=0.0))
        mock_adapter = MagicMock()
        mock_adapter.complete = AsyncMock(return_value=_fake_response())
        monkeypatch.setattr("routiq.pipeline.orchestrator.get_adapter",         MagicMock(return_value=mock_adapter))
        monkeypatch.setattr("routiq.pipeline.orchestrator.analyzer.classify",   MagicMock(return_value=(Complexity.SIMPLE, "default")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.alias.resolve",       MagicMock(return_value=("gpt-4o-mini", "openai")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.router.route",
                            MagicMock(return_value=("openai", "gpt-4o-mini", "complexity_simple")))

        run(orchestrator.process({"messages": [{"role": "user", "content": "hi"}]}))
        cost_record.assert_awaited_once()

    def test_cache_write_called_after_adapter(self, monkeypatch):
        cache_set = AsyncMock()
        self._full_patch(monkeypatch)
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.set", cache_set)
        run(orchestrator.process({"messages": []}))
        cache_set.assert_awaited_once()

    def test_response_usage_in_openai_format(self, monkeypatch):
        resp = _fake_response()
        resp.usage.input_tokens = 20
        resp.usage.output_tokens = 10
        self._full_patch(monkeypatch, response=resp)
        result, _ = run(orchestrator.process({"messages": []}))
        assert result["usage"]["prompt_tokens"] == 20
        assert result["usage"]["completion_tokens"] == 10
        assert result["usage"]["total_tokens"] == 30

    def test_adapter_receives_correct_model(self, monkeypatch):
        mock_adapter = self._full_patch(
            monkeypatch,
            route=MagicMock(return_value=("anthropic", "claude-sonnet-4-20250514", "hint_respected")),
        )
        run(orchestrator.process({"model": "claude-latest", "messages": []}))
        norm_req = mock_adapter.complete.call_args[0][0]
        assert norm_req.model == "claude-sonnet-4-20250514"

    def test_exception_propagates(self, monkeypatch):
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.get",       AsyncMock(return_value=None))
        monkeypatch.setattr("routiq.pipeline.orchestrator.cache.cache_key", MagicMock(return_value="k"))
        monkeypatch.setattr("routiq.pipeline.orchestrator.alias.resolve",   MagicMock(return_value=("gpt-4o-mini", "openai")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.analyzer.classify", MagicMock(return_value=(Complexity.SIMPLE, "default")))
        monkeypatch.setattr("routiq.pipeline.orchestrator.router.route",
                            MagicMock(return_value=("openai", "gpt-4o-mini", "complexity_simple")))
        mock_adapter = MagicMock()
        mock_adapter.complete = AsyncMock(side_effect=RuntimeError("provider down"))
        monkeypatch.setattr("routiq.pipeline.orchestrator.get_adapter", MagicMock(return_value=mock_adapter))

        with pytest.raises(RuntimeError, match="provider down"):
            run(orchestrator.process({"messages": [{"role": "user", "content": "hi"}]}))
