"""Tests for routiq.pipeline.analyzer — heuristic complexity classifier."""
import pytest
from routiq.pipeline.analyzer import Complexity, classify, COMPLEX_KEYWORDS


class TestClassifyDefault:
    def test_empty_messages_is_simple(self):
        c, reason = classify([], 0)
        assert c == Complexity.SIMPLE
        assert reason == "default"

    def test_short_plain_message_is_simple(self):
        c, reason = classify([{"role": "user", "content": "hello"}], 10)
        assert c == Complexity.SIMPLE
        assert reason == "default"


class TestRule1ToolUse:
    def test_tool_use_key_in_message(self):
        msgs = [{"role": "user", "content": "do something", "tool_use": {}}]
        c, reason = classify(msgs, 10)
        assert c == Complexity.COMPLEX
        assert reason == "tool_use_present"

    def test_tools_key_in_message(self):
        msgs = [{"role": "user", "tools": [{"name": "search"}]}]
        c, reason = classify(msgs, 10)
        assert c == Complexity.COMPLEX
        assert reason == "tool_use_present"

    def test_tool_use_type_in_content_block(self):
        msgs = [{"role": "user", "content": [{"type": "tool_use", "id": "x"}]}]
        c, reason = classify(msgs, 10)
        assert c == Complexity.COMPLEX
        assert reason == "tool_use_present"

    def test_text_block_without_tool_use_not_triggered(self):
        msgs = [{"role": "user", "content": [{"type": "text", "text": "hello"}]}]
        c, reason = classify(msgs, 10)
        assert c == Complexity.SIMPLE

    def test_tool_use_wins_over_large_token_count(self):
        msgs = [{"role": "user", "content": "x", "tool_use": {}}]
        c, reason = classify(msgs, 9999)
        assert reason == "tool_use_present"


class TestRule2LargeTokenCount:
    def test_2001_tokens_is_complex(self):
        c, reason = classify([{"role": "user", "content": "x"}], 2001)
        assert c == Complexity.COMPLEX
        assert reason == "token_count_gt_2000"

    def test_exactly_2000_tokens_is_not_complex(self):
        # rule is > 2000, not >=
        c, reason = classify([{"role": "user", "content": "x"}], 2000)
        assert c != Complexity.COMPLEX or reason != "token_count_gt_2000"

    def test_large_tokens_wins_over_keyword(self):
        msgs = [{"role": "user", "content": "analyze this"}]
        c, reason = classify(msgs, 2001)
        assert reason == "token_count_gt_2000"


class TestRule3MediumTokenCount:
    def test_801_tokens_is_medium(self):
        c, reason = classify([{"role": "user", "content": "x"}], 801)
        assert c == Complexity.MEDIUM
        assert reason == "token_count_gt_800"

    def test_exactly_800_tokens_is_not_medium(self):
        c, _ = classify([{"role": "user", "content": "x"}], 800)
        assert c == Complexity.SIMPLE

    def test_medium_token_range(self):
        for count in (801, 1000, 1500, 1999, 2000):
            c, reason = classify([{"role": "user", "content": "x"}], count)
            assert c == Complexity.MEDIUM, f"expected MEDIUM for token_count={count}"


class TestRule4Keywords:
    @pytest.mark.parametrize("keyword", sorted(COMPLEX_KEYWORDS))
    def test_every_keyword_triggers_complex(self, keyword):
        msgs = [{"role": "user", "content": f"please {keyword} this for me"}]
        c, reason = classify(msgs, 10)
        assert c == Complexity.COMPLEX
        assert reason == f"keyword:{keyword}"

    def test_keyword_match_is_case_insensitive(self):
        msgs = [{"role": "user", "content": "ANALYZE this code"}]
        c, reason = classify(msgs, 10)
        assert c == Complexity.COMPLEX

    def test_keyword_in_list_content_text_block(self):
        msgs = [{"role": "user", "content": [{"type": "text", "text": "debug the issue"}]}]
        c, reason = classify(msgs, 10)
        assert c == Complexity.COMPLEX
        assert reason == "keyword:debug"

    def test_keyword_in_list_content_case_insensitive(self):
        msgs = [{"role": "user", "content": [{"type": "text", "text": "REFACTOR the module"}]}]
        c, reason = classify(msgs, 10)
        assert c == Complexity.COMPLEX

    def test_keyword_in_second_message(self):
        msgs = [
            {"role": "user", "content": "hello"},
            {"role": "user", "content": "now implement a solution"},
        ]
        c, reason = classify(msgs, 10)
        assert c == Complexity.COMPLEX

    def test_non_keyword_word_is_simple(self):
        msgs = [{"role": "user", "content": "tell me a joke"}]
        c, reason = classify(msgs, 10)
        assert c == Complexity.SIMPLE

    def test_partial_keyword_match(self):
        # "analysis" contains "analy" but not "analyze" — should not trigger
        msgs = [{"role": "user", "content": "show me the analysis results"}]
        c, _ = classify(msgs, 10)
        # "analyze" not in content, so no keyword hit
        assert c == Complexity.SIMPLE


class TestRulePriority:
    def test_rule1_before_rule4(self):
        msgs = [{"role": "user", "content": "analyze this", "tool_use": {}}]
        _, reason = classify(msgs, 10)
        assert reason == "tool_use_present"

    def test_rule2_before_rule4(self):
        msgs = [{"role": "user", "content": "analyze this"}]
        _, reason = classify(msgs, 2001)
        assert reason == "token_count_gt_2000"

    def test_rule3_before_rule4(self):
        msgs = [{"role": "user", "content": "analyze this"}]
        _, reason = classify(msgs, 900)
        # token_count > 800 wins before keyword check
        assert reason == "token_count_gt_800"
