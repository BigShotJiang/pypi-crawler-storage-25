"""Tests for routiq.adapters.registry — adapter registration and lookup."""
import pytest
from unittest.mock import MagicMock, patch
import routiq.adapters.registry as reg


@pytest.fixture(autouse=True)
def clear_registry():
    reg._REGISTRY.clear()
    yield
    reg._REGISTRY.clear()


class TestIsRegistered:
    def test_false_when_empty(self):
        assert reg.is_registered("openai") is False

    def test_true_after_manual_set(self):
        reg._REGISTRY["openai"] = MagicMock()
        assert reg.is_registered("openai") is True

    def test_false_for_other_provider(self):
        reg._REGISTRY["openai"] = MagicMock()
        assert reg.is_registered("anthropic") is False

    def test_all_four_providers(self):
        for p in ("openai", "anthropic", "deepseek", "gemini"):
            reg._REGISTRY[p] = MagicMock()
            assert reg.is_registered(p) is True


class TestGetAdapter:
    def test_raises_runtime_error_when_uninitialised(self):
        with pytest.raises(RuntimeError, match="not initialised"):
            reg.get_adapter("openai")

    def test_returns_registered_adapter(self):
        mock = MagicMock()
        reg._REGISTRY["openai"] = mock
        assert reg.get_adapter("openai") is mock

    def test_raises_key_error_for_missing_provider(self):
        reg._REGISTRY["openai"] = MagicMock()
        with pytest.raises(KeyError, match="anthropic"):
            reg.get_adapter("anthropic")

    def test_error_message_names_the_provider(self):
        reg._REGISTRY["openai"] = MagicMock()
        with pytest.raises(KeyError) as exc_info:
            reg.get_adapter("gemini")
        assert "gemini" in str(exc_info.value)


class TestInitAdapters:
    def _make_settings(self, *, mock_mode=False, openai="", anthropic="",
                       deepseek="", gemini=""):
        s = MagicMock()
        s.routiq_mock_mode = mock_mode
        s.openai_api_key = openai
        s.anthropic_api_key = anthropic
        s.deepseek_api_key = deepseek
        s.gemini_api_key = gemini
        return s

    def test_mock_mode_registers_openai_and_anthropic_as_mock(self):
        settings = self._make_settings(mock_mode=True)
        with patch("routiq.adapters.registry.get_settings", return_value=settings):
            reg.init_adapters()
        assert "openai" in reg._REGISTRY
        assert "anthropic" in reg._REGISTRY

    def test_mock_mode_returns_early_no_real_adapters(self):
        settings = self._make_settings(mock_mode=True, openai="sk-real")
        with patch("routiq.adapters.registry.get_settings", return_value=settings):
            with patch("routiq.adapters.registry.OpenAIAdapter") as MockOAI:
                reg.init_adapters()
        MockOAI.assert_not_called()

    def test_openai_registered_when_key_set(self):
        settings = self._make_settings(openai="sk-test")
        with patch("routiq.adapters.registry.get_settings", return_value=settings):
            with patch("routiq.adapters.registry.OpenAIAdapter") as MockOAI:
                MockOAI.return_value = MagicMock()
                reg.init_adapters()
        assert "openai" in reg._REGISTRY

    def test_openai_not_registered_when_key_empty(self):
        settings = self._make_settings(openai="")
        with patch("routiq.adapters.registry.get_settings", return_value=settings):
            reg.init_adapters()
        assert "openai" not in reg._REGISTRY

    def test_anthropic_registered_when_key_set(self):
        settings = self._make_settings(anthropic="sk-ant-test")
        with patch("routiq.adapters.registry.get_settings", return_value=settings):
            with patch("routiq.adapters.registry.AnthropicAdapter") as MockAnth:
                MockAnth.return_value = MagicMock()
                reg.init_adapters()
        assert "anthropic" in reg._REGISTRY

    def test_deepseek_registered_when_key_set(self):
        settings = self._make_settings(deepseek="ds-key")
        with patch("routiq.adapters.registry.get_settings", return_value=settings):
            with patch("routiq.adapters.registry.DeepSeekAdapter") as MockDS:
                MockDS.return_value = MagicMock()
                reg.init_adapters()
        assert "deepseek" in reg._REGISTRY

    def test_deepseek_not_registered_when_key_empty(self):
        settings = self._make_settings(deepseek="")
        with patch("routiq.adapters.registry.get_settings", return_value=settings):
            reg.init_adapters()
        assert "deepseek" not in reg._REGISTRY

    def test_gemini_registered_when_key_set(self):
        settings = self._make_settings(gemini="AIza-test")
        with patch("routiq.adapters.registry.get_settings", return_value=settings):
            with patch("routiq.adapters.registry.GeminiAdapter") as MockGem:
                MockGem.return_value = MagicMock()
                reg.init_adapters()
        assert "gemini" in reg._REGISTRY

    def test_gemini_not_registered_when_key_empty(self):
        settings = self._make_settings(gemini="")
        with patch("routiq.adapters.registry.get_settings", return_value=settings):
            reg.init_adapters()
        assert "gemini" not in reg._REGISTRY

    def test_multiple_providers_registered_simultaneously(self):
        settings = self._make_settings(openai="sk-x", anthropic="sk-ant-x", gemini="AIza-x")
        with patch("routiq.adapters.registry.get_settings", return_value=settings):
            with patch("routiq.adapters.registry.OpenAIAdapter", return_value=MagicMock()):
                with patch("routiq.adapters.registry.AnthropicAdapter", return_value=MagicMock()):
                    with patch("routiq.adapters.registry.GeminiAdapter", return_value=MagicMock()):
                        reg.init_adapters()
        assert "openai" in reg._REGISTRY
        assert "anthropic" in reg._REGISTRY
        assert "gemini" in reg._REGISTRY
        assert "deepseek" not in reg._REGISTRY
