from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from datasets import Dataset

from mteb._create_dataloaders import (
    _create_dataloader_from_texts,
    create_dataloader,
)
from mteb.similarity_functions import similarity

from .evaluator import Evaluator

if TYPE_CHECKING:
    from datasets import Dataset

    from mteb.abstasks.task_metadata import TaskMetadata
    from mteb.models import EncoderProtocol
    from mteb.types import Array, EncodeKwargs

logger = logging.getLogger(__name__)


class ZeroShotClassificationEvaluator(Evaluator):
    def __init__(
        self,
        dataset: Dataset,
        input_column_name: str,
        candidate_labels: list[str],
        *,
        task_metadata: TaskMetadata,
        hf_split: str,
        hf_subset: str,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)

        self.dataset = dataset
        self.input_column_name = input_column_name
        self.candidate_labels = candidate_labels
        self.task_metadata = task_metadata
        self.hf_split = hf_split
        self.hf_subset = hf_subset

    def __call__(
        self,
        model: EncoderProtocol,
        *,
        encode_kwargs: EncodeKwargs,
        num_proc: int | None = None,
    ) -> Array:
        dataloader = create_dataloader(
            self.dataset,
            input_column=self.input_column_name,
            task_metadata=self.task_metadata,
            num_proc=num_proc,
            **encode_kwargs,
        )

        logger.info("Running zero-shot classification - Encoding labels...")
        text_label_embeddings = model.encode(
            _create_dataloader_from_texts(self.candidate_labels, **encode_kwargs),
            task_metadata=self.task_metadata,
            hf_subset=self.hf_subset,
            hf_split=self.hf_split,
            **encode_kwargs,
        )

        dataloader = create_dataloader(
            self.dataset,
            input_column=self.input_column_name,
            task_metadata=self.task_metadata,
            **encode_kwargs,
        )

        logger.info("Running zero-shot classification - Encoding samples...")
        input_embeddings = model.encode(
            dataloader,
            task_metadata=self.task_metadata,
            hf_subset=self.hf_subset,
            hf_split=self.hf_split,
            **encode_kwargs,
        )

        logger.info("Running zero-shot classification - Evaluating accuracy...")

        if self.task_metadata.modalities == ["image", "text"]:
            probs = similarity(text_label_embeddings, input_embeddings)
        else:
            probs = model.similarity(input_embeddings, text_label_embeddings)
        return probs
