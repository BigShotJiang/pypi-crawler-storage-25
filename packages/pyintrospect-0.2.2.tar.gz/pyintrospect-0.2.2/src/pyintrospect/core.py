import inspect
import os
from types import ModuleType, FunctionType, BuiltinFunctionType
def formatType(Type):
	try:
		return Type.__name__
	except AttributeError:
		return str(Type)
def getModuleMembers(Module):
	if not isinstance(Module, ModuleType):
		raise TypeError(f"Expected module object, got {type(Module).__name__}")
	return inspect.getmembers(Module)
def getVariableList(members, HideDunder=True):
	Variables = []
	for name, obj in members:
		if HideDunder:
			if name.startswith(("_", "__", "/")):
				continue
		if (not inspect.isroutine(obj) and not inspect.isclass(obj) and not inspect.ismodule(obj) and not name.isupper()):
			Variables.append((type(obj).__name__, name, obj))
		else:
			continue
	return Variables
def getConstantList(members, HideDunder=True):
	Constants = []
	for name, obj in members:
		if HideDunder:
			if name.startswith(("_", "__", "/")):
				continue
		if (name.isupper() and not inspect.isroutine(obj) and not inspect.isclass(obj) and not inspect.ismodule(obj)):
			Constants.append((type(obj).__name__, name, obj))
		else:
			continue
	return Constants
def getFunctionSignature(Function):
	try:
		Signature = inspect.signature(Function)
	except (ValueError, TypeError):
		return (None, Function.__name__, None)
	ReturnType = None
	if not Signature.return_annotation is inspect._empty:
		ReturnType = Signature.return_annotation
	return (formatType(ReturnType) if ReturnType else None, Function.__name__, str(Signature))
def getFunctionList(members, HideDunder=True):
	Functions = []
	for name, obj in members:
		if HideDunder:
			if name.startswith(("_", "__", "/")):
				continue
		if inspect.isroutine(obj):
			Functions.append(getFunctionSignature(obj))
		else:
			continue
	return Functions
def getClassBases(Cls):
	if not inspect.isclass(Cls):
		raise TypeError(f"'{Cls}' Expected class object")
	Bases = []
	for Base in Cls.__bases__:
		name = getattr(Base, "__qualname__", str(Base))
		if Base.__module__ == 'builtins':
			Bases.append(name)
		else:
			Bases.append(f"{Base.__module__}.{name}")
	return Bases
def getClassList(members, HideDunder=True):
	Classes = []
	for name, obj in members:
		if HideDunder:
			if name.startswith(("_", "__", "/")):
				continue
		if inspect.isclass(obj):
			try:
				InitSignature = inspect.signature(obj.__init__)
			except (ValueError, TypeError):
				InitSignature = None
			Bases = getClassBases(obj)
			Classes.append((name, Bases, InitSignature))
		else:
			continue
	return Classes
def getModulePath(Module):
	if not isinstance(Module, ModuleType):
		raise TypeError(f"Expected module object, got {type(Module).__name__}")
	try:
		return os.path.abspath(inspect.getfile(Module))
	except TypeError:
		return None
def getModuleList(members, HideDunder=True):
	Modules = []
	for name, obj in members:
		if HideDunder:
			if name.startswith(("_", "__", "/")):
				continue
		if inspect.ismodule(obj):
			Modules.append((name, getModulePath(obj)))
	return Modules
def getModuleSource(Module):
	if not isinstance(Module, ModuleType):
		raise TypeError(f"Expected module object, got {type(Module).__name__}")
	try:
		return inspect.getsource(Module)
	except (OSError, TypeError):
		try:
			path = inspect.getfile(Module)
			ext = os.path.splitext(path)[1].lower()
			if ext != ".py":
				return None
			with open(path, "r", encoding="utf-8", errors="ignore") as file:
				return file.read()
		except Exception:
			return None
def getDoc(obj):
	if not isinstance(obj, (FunctionType, BuiltinFunctionType)) and not isinstance(obj, ModuleType) and not isinstance(obj, type):
		raise TypeError(f"'{obj} is not a module, function or class")
	return inspect.getdoc(obj)