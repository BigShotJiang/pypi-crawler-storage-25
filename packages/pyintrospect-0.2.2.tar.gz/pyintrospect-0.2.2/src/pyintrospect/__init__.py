from .core import *
__version__ = "0.2.2"
class Reflect:
	def __init__(self, module, HideDunder=True, pretty=True):
		self.module = module
		self.members = getModuleMembers(module)
		self.HideDunder = HideDunder
		self.pretty = pretty
	def submodules(self):
		submodules = getModuleList(self.members, self.HideDunder)
		if self.pretty:
			print("Submodules:")
			print("")
			for name, path in submodules:
				print(f"  {name}: {path if path else 'Unknown'}")
			return None
		return submodules
	def variables(self):
		variables = getVariableList(self.members, self.HideDunder)
		if self.pretty:
			print("Variables:")
			print("")
			for typ,  name, value in variables:
				print(f"  {typ} {name} = {value}")
			return None
		return variables
	def constants(self):
		constants = getConstantList(self.members, self.HideDunder)
		if self.pretty:
			print("Constants:")
			print("")
			for typ, name, value in constants:
				print(f"  {typ} {name} = {value}")
			return None
		return constants
	def functions(self):
		functions = getFunctionList(self.members, self.HideDunder)
		if self.pretty:
			print("Functions:")
			print("")
			for returntype, functionname, signature in functions:
				line = f"  {functionname}{signature if signature else '()'}"
				if returntype:
					line = f"  {returntype} {functionname}{signature if signature else '()'}"
				print(line)
			return None
		return functions
	def classes(self):
		classes = getClassList(self.members, self.HideDunder)
		if self.pretty:
			print("Classes:")
			print("")
			for classname, bases, initsignature in classes:
				base_text = ", ".join(bases)
				print(f"  {classname}({base_text if base_text else 'object'}):")
				print(f"    __init__{initsignature if initsignature else '(self)'}")
				print("")
			return None
		return classes
	def source(self):
		source = getModuleSource(self.module)
		if self.pretty:
			print(f"{source if source else 'Unknown source'}")
			return None
		return source
	def path(self):
		path = getModulePath(self.module)
		if self.pretty:
			print(f"{path if path else 'Unknown path'}")
			return None
		return path
	def all(self):
		if self.pretty:
			self.summary()
			self.submodules()
			self.variables()
			self.constants()
			self.functions()
			self.classes()
			return None
		return {
			"summary": self.summary(),
			"submodules": self.submodules(),
			"variables": self.variables(),
			"constants": self.constants(),
			"functions": self.functions(),
			"classes": self.classes()
		}
	def summary(self):
		submodules = getModuleList(self.members, self.HideDunder)
		variables = getVariableList(self.members, self.HideDunder)
		constants = getConstantList(self.members, self.HideDunder)
		functions = getFunctionList(self.members, self.HideDunder)
		classes = getClassList(self.members, self.HideDunder)
		name = self.module.__name__
		file = getattr(self.module, "__file__", None)
		version = getattr(self.module, "__version__", None)
		path = getModulePath(self.module)
		data = {
			"name": name,
			"file": file,
			"version": version,
			"path": path,
			"submodules": len(submodules),
			"variables": len(variables),
			"constants": len(constants),
			"functions": len(functions),
			"classes": len(classes),
		}
		total = sum([
			data["submodules"],
			data["variables"],
			data["constants"],
			data["functions"],
			data["classes"]
		])
		data["total"] = total
		if self.pretty:
			print(f"Module: {name}")
			print(f"File: {file if file else 'Unknown'}")
			if version is not None:
				print(f"Version: {version}")
			print(f"Path: {path if path else 'Unknown'}")
			print(f"Submodules: {data['submodules']}")
			print(f"Variables: {data['variables']}")
			print(f"Constants: {data['constants']}")
			print(f"Functions: {data['functions']}")
			print(f"Classes: {data['classes']}")
			print(f"Total members: {total}")
			print("")
			return None
		return data
	def doc(self, attribute=None):
		if attribute is None:
			doc = getDoc(self.module)
		else:
			doc = getDoc(getattr(self.module, attribute, None))
		if self.pretty:
			if doc is None:
				print("Doc not found")
				print("")
				return None
			else:
				print("Doc:")
				print("")
				print(doc)
				print("")
				return None
		else:
			return doc
__all__ = ["Reflect", "__version__"]