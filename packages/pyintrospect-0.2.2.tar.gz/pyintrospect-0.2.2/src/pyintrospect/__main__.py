import sys
import importlib
import argparse
from . import Reflect, __version__
def print_help():
	print("pyintrospect - Simple Python introspection tool")
	print("")
	print("Usage:")
	print("  python -m pyintrospect <module> [options]")
	print("")
	print("Options:")
	print("")
	print("  Core:")
	print("    -a, --all          Show everything (default behavior)")
	print("    -h, --help         Show this help message")
	print("   -V, --version      Show version")
	print("")
	print("  Inspection:")
	print("    -f, --functions    Show functions")
	print("    -c, --classes      Show classes")
	print("    -v, --variables    Show variables")
	print("    -C, --constants    Show constants")
	print("    -m, --submodules   Show submodules")
	print("")
	print("  Detail:")
	print("    -s, --source       Show source code")
	print("    -p, --path         Show module path")
	print("    -d, --doc          Show module or object documentation")
	print("")
	print("  Formatting:")
	print("    -r, --raw          Disable pretty print")
	print("    -D, --dunder       Include dunder members")
	print("")
	print("Examples:")
	print("  python -m pyintrospect os")
	print("  python -m pyintrospect os --functions")
	print("  python -m pyintrospect requests --classes --raw")
	print("")
def parse_args():
	parser = argparse.ArgumentParser(add_help=False)
	parser.add_argument("module", nargs="?")
	parser.add_argument("-f", "--functions", action="store_true")
	parser.add_argument("-c", "--classes", action="store_true")
	parser.add_argument("-v", "--variables", action="store_true")
	parser.add_argument("-C", "--constants", action="store_true")
	parser.add_argument("-m", "--submodules", action="store_true")
	parser.add_argument("-a", "--all", action="store_true")
	parser.add_argument("-d", "--doc", nargs="?", const="__module__")
	parser.add_argument("-r", "--raw", dest="pretty", action="store_false", default=True)
	parser.add_argument("-D", "--dunder", dest="hide_dunder", action="store_false", default=True)
	parser.add_argument("-V", "--version", action="store_true")
	parser.add_argument("-h", "--help", action="store_true")
	parser.add_argument("-s", "--source", action="store_true")
	parser.add_argument("-p", "--path", action="store_true")
	return parser.parse_known_args()
def main():
	args, unknown = parse_args()
	if unknown:
		print_help()
		print(f"Invalid command: '{", ".join(unknown)}'")
		sys.exit(1)
	if not args:
		print_help()
		sys.exit(0)
	if args.version:
		print(f"Pyintrospect version {__version__}")
		sys.exit(0)
	if args.help:
		print_help()
		sys.exit(0)
	module_name = args.module
	if not module_name:
		print("Error: No module specified")
		sys.exit(1)
	try:
		module = importlib.import_module(module_name)
	except Exception as e:
		print(f"Error: Cannot import module '{module_name}'")
		print(f"  {e}")
		sys.exit(1)
	HideDunder = args.hide_dunder
	pretty = args.pretty
	R = Reflect(module, HideDunder=HideDunder, pretty=pretty)
	selected = any(
		value for key, value in vars(args).items()
			if value not in (None, False)
			and  key not in ["help", "version", "pretty", "hide_dunder", "all", "module"]
	)
	if args.all:
		if selected:
			print("Note: --all overrides other options")
		R.all()
		sys.exit(0)
	if not selected:
		R.all()
		sys.exit(0)
	if args.submodules:
		R.submodules()
	if args.variables:
		R.variables()
	if args.constants:
		R.constants()
	if args.functions:
		R.functions()
	if args.classes:
		R.classes()
	if args.source:
		R.source()
	if args.path:
		R.path()
	if args.doc:
		if args.doc == "__module__":
			R.doc()
		else:
			R.doc(args.doc)
if __name__ == "__main__":
	main()