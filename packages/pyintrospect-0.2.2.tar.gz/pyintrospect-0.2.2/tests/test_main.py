import sys
import pytest

from pyintrospect.__main__ import main


def test_main_help(monkeypatch, capsys):
	monkeypatch.setattr(sys, "argv", ["pyintrospect", "--help"])

	with pytest.raises(SystemExit) as e:
		main()

	assert e.value.code == 0
	assert "Usage:" in capsys.readouterr().out


def test_main_version(monkeypatch, capsys):
	monkeypatch.setattr(sys, "argv", ["pyintrospect", "--version"])

	with pytest.raises(SystemExit):
		main()

	assert "version" in capsys.readouterr().out.lower()


def test_main_invalid(monkeypatch, capsys):
	monkeypatch.setattr(
		sys,
		"argv",
		["pyintrospect", "no_module_123"]
	)

	with pytest.raises(SystemExit) as e:
		main()

	assert e.value.code == 1
	assert "Cannot import module" in capsys.readouterr().out


def test_main_functions(monkeypatch):
	monkeypatch.setattr(
		sys,
		"argv",
		["pyintrospect", "os", "--functions"]
	)

	main()