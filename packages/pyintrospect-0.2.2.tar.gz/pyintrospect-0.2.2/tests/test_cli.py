import subprocess
import sys


def run_cli(*args):
	return subprocess.run(
		[sys.executable, "-m", "pyintrospect", *args],
		capture_output=True,
		text=True
	)


def test_help():
	r = run_cli("--help")
	assert r.returncode == 0
	assert "Usage:" in r.stdout


def test_version():
	r = run_cli("--version")
	assert r.returncode == 0
	assert "version" in r.stdout.lower()


def test_invalid_module():
	r = run_cli("no_such_module_xyz")
	assert r.returncode == 1
	assert "Cannot import module" in r.stdout


def test_functions():
	r = run_cli("os", "--functions")
	assert r.returncode == 0


def test_raw():
	r = run_cli("os", "--raw")
	assert r.returncode == 0