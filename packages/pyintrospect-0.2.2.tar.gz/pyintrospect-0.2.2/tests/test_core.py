import types
import pytest
import inspect

from pyintrospect.core import (
	formatType,
	getModuleMembers,
	getVariableList,
	getConstantList,
	getFunctionList,
	getClassList,
	getClassBases,
	getModulePath,
	getModuleSource,
)

# -------------------------
# Fake module setup
# -------------------------

class FakeClassBase:
	pass

class FakeClass(FakeClassBase):
	def __init__(self, x, y: int = 1):
		self.x = x
		self.y = y

def fake_function(a, b: int) -> str:
	return str(a + b)

fake_module = types.ModuleType("fake_module")

fake_module.var1 = 123
fake_module.var2 = "hello"
fake_module.CONST = 999
fake_module._hidden = "should be hidden"
fake_module.func = fake_function
fake_module.FakeClass = FakeClass
fake_module.__version__ = "1.0"


# -------------------------
# Tests
# -------------------------

def test_formatType():
	assert formatType(int) == "int"
	assert formatType("abc") == "abc"


def test_getModuleMembers():
	members = getModuleMembers(fake_module)
	assert isinstance(members, list)
	assert ("var1", 123) in members


def test_getVariableList():
	members = getModuleMembers(fake_module)
	vars_ = getVariableList(members)

	names = [v[1] for v in vars_]
	assert "var1" in names
	assert "var2" in names
	assert "CONST" not in names  # constant bị loại


def test_getConstantList():
	members = getModuleMembers(fake_module)
	consts = getConstantList(members)

	names = [c[1] for c in consts]
	assert "CONST" in names
	assert "var1" not in names


def test_getFunctionList():
	members = getModuleMembers(fake_module)
	funcs = getFunctionList(members)

	assert len(funcs) == 1
	ret, name, sig = funcs[0]
	assert name == "func"
	assert "a" in sig


def test_getClassList():
	members = getModuleMembers(fake_module)
	classes = getClassList(members)

	assert len(classes) == 1
	name, bases, init = classes[0]

	assert name == "FakeClass"
	assert any("FakeClassBase" in b for b in bases)
	assert init is not None


def test_getClassBases():
	bases = getClassBases(FakeClass)
	assert "FakeClassBase" in bases[0]


def test_getModulePath():
	path = getModulePath(fake_module)
	assert path is None or isinstance(path, str)


def test_getModuleSource():
	src = getModuleSource(fake_module)
	assert src is None or isinstance(src, str)


def test_invalid_module_error():
	with pytest.raises(TypeError):
		getModuleMembers("not_a_module")