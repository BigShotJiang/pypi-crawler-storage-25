import types

from pyintrospect import Reflect


class Dummy:
	x = 10
	Y = 20

	def hello(self):
		return "hi"


def test_reflect_all_non_pretty():
	m = types.ModuleType("dummy")
	m.x = 1
	m.Y = 2
	m.Dummy = Dummy

	r = Reflect(m, HideDunder=True, pretty=False)
	result = r.all()

	assert isinstance(result, dict)
	assert "variables" in result
	assert "classes" in result


def test_reflect_summary():
	m = types.ModuleType("dummy2")
	m.a = 1
	m.B = 2

	r = Reflect(m, pretty=False)
	summary = r.summary()

	assert summary["name"] == "dummy2"
	assert "total" in summary


def test_hide_dunder():
	m = types.ModuleType("dummy3")
	m._hidden = 1
	m.visible = 2

	r = Reflect(m, HideDunder=True, pretty=False)
	vars_ = r.variables()

	names = [v[1] for v in vars_]
	assert "_hidden" not in names
	assert "visible" in names