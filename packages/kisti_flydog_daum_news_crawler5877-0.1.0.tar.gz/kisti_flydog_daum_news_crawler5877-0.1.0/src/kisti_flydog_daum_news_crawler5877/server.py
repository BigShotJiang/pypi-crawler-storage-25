import requests
from bs4 import BeautifulSoup

from mcp.server.fastmcp import FastMCP

# Initialize FastMCP server
mcp = FastMCP("daum_news_crawler5877")

@mcp.tool()
def get_crawling(keyword: str, numofpages: int) -> list:
    """
    Daum News titles are collected and stored in a list based on the number of news article pages related to the keywords requested by the user..
    
    Args:
        keyword (str): Keywords requested by users for Daum News search.
        numofpages (int): Number of Daum news pages to collect as requested by the user.
    
    Returns:
        list: Collected Daum News Titles.
    """
    
    '''
    NOTE:Daum 뉴스 쿼리스트링
    q : 키워드
    p : 페이지
    '''
    base_url = 'https://search.daum.net/search?nil_suggest=btn&w=news&DA=PGD&cluster=y&q=' + keyword + '&p='    

    daum_crawling = []

    #사람처럼 보이기 위한 헤더 설정
    headers = {'User-Agent': 'Mozilla/5.0 Chrome/124.0.0.0'}
    
    for i in range(1, numofpages+1, 1) :
        url = base_url + str(i)
        response = requests.get(url, headers=headers)
        soup = BeautifulSoup(response.content, 'html.parser')

        '''
        NOTE:HTML 구조 분석
        ul.c-list-basic(뉴스 리스트)
            li(각 뉴스별 리스트에 해당하는 아이템)
                div.c-tit-doc(뉴스 출처)
                div.c-item-content(뉴스 콘텐츠 전체)
                    div.item-title(뉴스 제목)
                        strong.tit-g
                    div.item-content(뉴스 콘텐츠)
        Xpath로 확인시 //div[@class='item-title'] 10건씩 확인 완료
        '''
        headlines = soup.find_all('div', {'class' : 'item-title'})

        for headline in headlines:
            title = headline.get_text(strip=True)
            daum_crawling.append(title)

    return daum_crawling

@mcp.tool()
def get_textwriter(contents: str) -> None:
    """
    Save the text entered by the user as contentfile.txt on the drive of the user's computer.

    Args:
        contents (str): Text entered by the user.

    Returns:
        None    
    """

    '''
    NOTE:파일 저장
    맥 파일 경로로 저장(D드라이브일 경우 D:/daum-news-title.txt로 수정)
    '''
    file_path = "/Users/user/Python/daum-news-title.txt"
    with open(file_path, "a", encoding="utf-8") as file:
        file.write(contents)
        file.write("\n") # Ensure the file ends with a newline

def main() -> None:
    # Initialize and run the server
    '''
    NOTE:로컬 테스트용
    keyword = "KISTI"
    pages = 3
    result = get_crawling(keyword, pages)

    if result:
        for title in result:
            get_textwriter(title)
    '''
    
    '''
    NOTE:MCP서버용
    '''
    print("Starting Daum News Crawler server...")
    mcp.run(transport='stdio')
    

if __name__ == "__main__":
   main()