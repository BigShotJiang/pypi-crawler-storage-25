# CLIPassMan (Console Smart Password Manager) <sup>v3.0.1</sup>

---

**Terminal-based smart password manager with deterministic password generation. Generate, manage, and retrieve passwords without storing them - all from your command line.**

---

[![PyPI - Downloads](https://img.shields.io/pypi/dm/clipassman?label=pypi%20downloads)](https://pypi.org/project/clipassman/)
[![PyPI Downloads](https://static.pepy.tech/badge/clipassman)](https://pepy.tech/projects/clipassman)
[![PyPI Weekly Downloads](https://static.pepy.tech/badge/clipassman/week)](https://pepy.tech/projects/clipassman)
![GitHub top language](https://img.shields.io/github/languages/top/smartlegionlab/clipassman)
[![GitHub release](https://img.shields.io/github/v/release/smartlegionlab/clipassman)](https://github.com/smartlegionlab/clipassman/)
[![PyPI version](https://img.shields.io/pypi/v/clipassman)](https://pypi.org/project/clipassman)
[![GitHub license](https://img.shields.io/github/license/smartlegionlab/clipassman)](https://github.com/smartlegionlab/clipassman/blob/master/LICENSE)
[![PyPI format](https://img.shields.io/pypi/format/clipassman)](https://pypi.org/project/clipassman)
![Platform](https://img.shields.io/badge/platform-windows%20%7C%20linux%20%7C%20macos-lightgrey)
[![GitHub stars](https://img.shields.io/github/stars/smartlegionlab/clipassman?style=social)](https://github.com/smartlegionlab/clipassman/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/smartlegionlab/clipassman?style=social)](https://github.com/smartlegionlab/clipassman/network/members)

---

## ⚠️ Disclaimer

**By using this software, you agree to the full disclaimer terms.**

**Summary:** Software provided "AS IS" without warranty. You assume all risks.

**Full legal disclaimer:** See [DISCLAIMER.md](https://github.com/smartlegionlab/clipassman/blob/master/DISCLAIMER.md)

---

## 🔄 Important: smartpasslib v3.0.0 Breaking Change

> **⚠️ This release (v3.0.1) uses [smartpasslib](https://github.com/smartlegionlab/smartpasslib) v3.0.0, which is NOT backward compatible with v2.x.x**

### Why the change?

**Smartpasslib v3.0.0 introduces fundamental improvements:**
- **Stronger cryptographic algorithm** — enhanced deterministic generation with better entropy distribution
- **Improved performance** — faster password generation, especially for longer passwords
- **Better cross-platform consistency** — identical results guaranteed across all platforms
- **Extended character set support** — wider range of special characters for stronger passwords
- **Future-proof architecture** — easier updates and security patches

### What changed:

- The core password generation algorithm has been completely redesigned
- Passwords created with v2.2.2 or earlier **cannot be regenerated** using v3.0.1
- Old metadata (`passwords.json`) will produce **different passwords** if used with v3.0.1

### What you need to do:

1. **Before upgrading** — retrieve and save all your existing passwords from the old version
2. **After upgrading** — recreate each password using the same secret phrases + lengths
3. **Update** your passwords on all websites/services

**No automatic migration** — you must manually regenerate every password.

📖 **Full migration instructions** → see [Migration Section](#migration-section)

---

## **Core Principles:**

- **Zero-Password Storage**: No passwords are ever stored or transmitted
- **Deterministic Regeneration**: Passwords are recreated identically from your secret phrase
- **Metadata Management**: Store only descriptions and verification keys
- **Terminal Processing**: All cryptographic operations happen in your CLI
- **On-Demand Discovery**: Passwords exist only when you generate them

**What You Can Do:**
1. **Create Smart Passwords**: Generate deterministic passwords from secret phrases
2. **Store Metadata Securely**: Keep password descriptions and lengths without storing passwords
3. **Regenerate Passwords**: Recreate passwords anytime using your secret phrase
4. **Manage Services**: Organize passwords for different accounts and services
5. **Secure Terminal Input**: Hidden secret phrase entry with getpass
6. **Verify Secrets**: Prove knowledge of secrets without exposing them
7. **Export/Import**: Backup and restore your password metadata
8. **Cross-Platform Management**: Works on any system with Python
9. **No GUI Dependencies**: Pure terminal interface for servers and remote systems

**Key Features:**
- **No Password Database**: Eliminates password storage completely
- **Interactive Terminal UI**: Clean, centered text with visual framing
- **Public Key Verification**: Verify secret knowledge without exposure
- **List View**: See all your password metadata in clear lists
- **Export/Import**: Backup and restore functionality with timestamped files
- **Bulk Operations**: Clear all passwords with double confirmation
- **Secure Hidden Input**: Hidden secret phrase entry via getpass
- **No Dependencies**: Only Python standard library + smartpasslib
- **Server Ready**: Perfect for headless systems and remote management

**Security Model:**
- **Proof of Knowledge**: Verify you know a secret without storing it
- **Deterministic Security**: Same secret + length = same password, always
- **Metadata Separation**: Non-sensitive data stored separately from verification
- **Local Processing**: No data leaves your computer
- **No Recovery Backdoors**: Lost secret = permanently lost access (by design)

---

## Research Paradigms & Publications

- **[Pointer-Based Security Paradigm](https://doi.org/10.5281/zenodo.17204738)** - Architectural Shift from Data Protection to Data Non-Existence
- **[Local Data Regeneration Paradigm](https://doi.org/10.5281/zenodo.17264327)** - Ontological Shift from Data Transmission to Synchronous State Discovery

---

## Technical Foundation

Powered by **[smartpasslib](https://github.com/smartlegionlab/smartpasslib) v3.0.0+** — The core library for deterministic password generation.

> ⚠️ **BREAKING CHANGE NOTICE**  
> **smartpasslib v3.0.0 is NOT backward compatible with v2.x.x**  
> Passwords generated with v2.x.x cannot be regenerated using v3.0.1 due to fundamental changes in the deterministic generation algorithm.

**What this means for you:**
- All passwords created with **v2.2.2 or earlier** must be **regenerated** after upgrading
- Old metadata (`passwords.json`) remains readable but will produce **different passwords** if used with v3.0.1
- You have two options:
  1. **Before upgrading** — manually retrieve and save all passwords from old version
  2. **After upgrading** — re-enter your secret phrases and recreate each entry with correct passwords

**Key principle** (unchanged): Instead of storing passwords, you store verification metadata. The actual password is regenerated on-demand from your secret phrase.

**What's NOT stored** (unchanged):
- Your secret phrase
- The actual password
- Any reversible password data

**What IS stored** (in `~/.config/smart_password_manager/passwords.json`):
- Public verification key (hash of secret)
- Service description
- Password length parameter

**Export format**: Same JSON structure, but v3.0.1 exports are **incompatible** with older versions. Always note which version created the export.

**Security model**: Proof of secret knowledge without secret storage or password transmission.

---

## File Locations

Starting from v3.0.1, configuration files are stored in:

| Platform | Configuration Path |
|----------|-------------------|
| Linux | `~/.config/smart_password_manager/passwords.json` |
| macOS | `~/.config/smart_password_manager/passwords.json` |
| Windows | `C:\Users\Username\.config\smart_password_manager\passwords.json` |

**Automatic Migration**:
- Old `~/.cases.json` files are automatically migrated on first run
- Original file is backed up as `~/.cases.json.bak`
- Migration is one-time and non-destructive
- All your existing passwords are preserved

---

## Migration Section

### Migrating from v2.x.x to v3.0.1

**⚠️ Before upgrading — follow these steps carefully**

**Step 1: Document your existing passwords**
- Open your current CLIPassMan (v2.2.2 or earlier)
- For each service, retrieve the password using your secret phrase
- Save passwords in a secure temporary location (e.g., encrypted note)

**Alternative method (more secure but manual):**
- Write down for each service: **Service description + Secret phrase + Length**
- After upgrading, you'll manually recreate entries and update passwords in services

**Step 2: Export old metadata (optional backup)**
- Select option **3: Export/Import Passwords**
- Choose **1: Export passwords to file**
- Save the JSON file as `passwords_v2_backup.json`

**Step 3: Upgrade to v3.0.1**
```bash
# Update via pip
pip install clipassman==3.0.1

# Or update smartpasslib
pip install smartpasslib==3.0.0

# Or rebuild executable with new version
```

**Step 4: Migrate your data**
- Option A: Start fresh — delete old `passwords.json` and add entries manually
- Option B: Keep metadata but manually verify each password (not recommended — easy to make mistakes)

**Step 5: Update passwords in all your services**
- After regenerating passwords with v3.0.1, update them in each website/service
- Test login before removing old access

**Important**: v2.x.x and v3.0.1 cannot share the same metadata file. Keep them completely separate.

---

## What's New in v3.0.1

### Breaking Change: smartpasslib v3.0.0

- **New cryptographic algorithm** — stronger and faster password generation
- **NOT backward compatible** with v2.x.x — all passwords must be regenerated
- **See migration section above** for detailed upgrade instructions

### Secret Phrase Requirements

- **Minimum 12 characters** enforced for all secret phrases
- **Password length minimum increased** from 4 to 12 characters
- **Better security guidance** with strong/weak examples

### Import/Export Functionality (from v2.2.2)

- **Export passwords**: Save your password metadata to JSON file with timestamp
- **Import passwords**: Restore from previously exported files
- **Format options**: Choose between pretty or minified JSON
- **Metadata inclusion**: Optional timestamp and version info in export
- **Safe import**: Merges with existing data, never overwrites existing entries
- **Import preview**: See export metadata before confirming
- **Statistics**: Clear feedback on added/skipped/invalid entries
- **Filename suggestions**: Auto-generated timestamps prevent overwrites

### Configuration Migration (from v2.2.2)

- **New config location**: Uses `~/.config/smart_password_manager/passwords.json`
- **Automatic migration**: Old `~/.cases.json` files are auto-migrated on first run
- **Cross-platform paths**: Works on Linux, macOS, and Windows
- **Safe backup**: Original file preserved as `.cases.json.bak`

### Improved Terminal UI (from v2.2.2)

- **Export/Import menu**: Dedicated option in main menu (option 3)
- **Better feedback**: Clear statistics after import
- **Format selection**: Choose JSON format during export
- **Filename suggestions**: Auto-generated timestamps
- **Consistent visual styling** throughout the application

### Security Improvements (from v2.2.2)

- **Stronger public key verification** using enhanced cryptographic methods
- **Better input validation** with clear error messages
- **Duplicate detection** - prevents creating multiple entries with same secret
- **Case-sensitive secrets** with clear user warnings

---

## Installation & Quick Start

### Prerequisites
- **Python 3.7+** required
- **pip** for package management

### Quick Run from Repository

```bash
# Clone and run in one go
git clone https://github.com/smartlegionlab/clipassman.git
cd clipassman
python clipassman/clipassman.py
```

### Quick Installation
```bash
# Install from PyPI
pip install clipassman==3.0.1

# For systems with package conflicts
pip install clipassman==3.0.1 --break-system-packages

# Verify installation
clipassman
```

### Manual Installation
```bash
# Clone repository
git clone https://github.com/smartlegionlab/clipassman.git
cd clipassman

# Install in development mode
pip install -e .

# Or install from local source
pip install .
```

---

## Quick Usage Guide

### Launching the Application
```bash
# Start interactive terminal interface
clipassman

# Or if installed locally
python -m clipassman.clipassman
```

### Creating Your First Password
1. Launch `clipassman`
2. Select option **1: Add Password**
3. Enter service description (e.g., "GitHub Account")
4. Enter your secret phrase (minimum 12 characters, never stored)
   - Good examples: `"MyCat🐱Hippo2026"` or `"P@ssw0rd!LongSecret"`
5. Confirm your secret phrase
6. Set password length (12-100 characters, 16-24 recommended)
7. Password is generated and displayed
8. Save it securely (not stored by system)

### Retrieving a Password
1. Launch `clipassman`
2. Select option **2: Get/Delete Password**
3. Choose password entry from numbered list
4. Select **1: Get password**
5. Enter your secret phrase (hidden input)
6. Password regenerates identically

### Exporting Passwords
1. Launch `clipassman`
2. Select option **3: Export/Import Passwords**
3. Select **1: Export passwords to file**
4. Choose filename (or press Enter for auto-generated with timestamp)
5. Select format (1: pretty JSON, 2: minified JSON)
6. Choose whether to include metadata (y/n)
7. File is saved with all your password metadata
8. Success message with filename and password count

### Importing Passwords
1. Launch `clipassman`
2. Select option **3: Export/Import Passwords**
3. Select **2: Import passwords from file**
4. Enter filename to import
5. Review export metadata if present (date, version, count)
6. Confirm import (y/n)
7. See statistics of added/skipped/invalid entries
8. Table automatically refreshes with new passwords

### Deleting Passwords
1. Select option **2: Get/Delete Password**
2. Choose password entry
3. Select **2: Delete entry**
4. Confirm deletion with 'y'
5. Only metadata removed - password can be recreated with secret

### Clearing All Passwords
1. Select option **4: Clear All Passwords**
2. First confirmation with 'y'
3. Type 'DELETE ALL' to confirm
4. All password entries are removed

### Managing Passwords
```bash
# Main menu options:
1: Add Password          # Create new password
2: Get/Delete Password   # Retrieve or remove password
3: Export/Import         # Backup or restore password metadata
4: Clear All Passwords   # Remove all entries (double confirmation)
5: Help                  # View documentation
0: Exit                  # Quit application
```

---

## Windows Standalone Executable

### Creating a Single-File *.exe

Build a standalone `clipassman.exe` that runs without Python installation:

#### Step 1: Get the Project Files
1. **Download project ZIP:**
   - Go to: https://github.com/smartlegionlab/clipassman
   - Click green "Code" button
   - Select "Download ZIP"
   - Extract to: `C:\clipassman-master`

#### Step 2: Install Python
1. Download Python installer from: https://python.org/downloads/
2. Run installer
3. **IMPORTANT:** Check "Add Python to PATH"
4. Click "Install Now"

#### Step 3: Open Command Prompt
1. Press `Win + R`
2. Type `cmd`, press Enter
3. Navigate to project folder:
   ```cmd
   cd C:\clipassman-master
   ```

#### Step 4: Create Virtual Environment
```cmd
# Create virtual environment
python -m venv venv

# Activate it (IMPORTANT!)
.\venv\Scripts\activate

# You should see (venv) in your command prompt
```

#### Step 5: Install Dependencies
```cmd
# Install PyInstaller in virtual environment
pip install pyinstaller
pip install smartpasslib==3.0.0
```

#### Step 6: Build Executable
```cmd
# Build single .exe file
pyinstaller --onefile --console --name "clipassman.exe" clipassman/clipassman.py

# Wait for build to complete (1-2 minutes)
```

#### Step 7: Find and Use
**Location:** `C:\clipassman-master\dist\clipassman.exe`

**Create desktop shortcut:**
1. Open `C:\clipassman-master\dist\` folder
2. Right-click `clipassman.exe`
3. Select "Create shortcut"
4. Drag shortcut to desktop
5. Rename shortcut to "CLIPassMan"
6. Double-click to start

**What you get:**
- Single file: `clipassman.exe` (~10MB)
- No Python required to run
- Works on any Windows 10/11 PC
- Can be copied to USB drive

---

## Core Components

### Terminal Interface Features

**Main Menu:**
```
********************************************************************************
********************** Smart Password Manager CLI v3.0.1 ***********************
******************************* Version: v3.0.1 ********************************
------------------------ Main Menu | Total passwords: 0 ------------------------
1: Add Password
2: Get/Delete Password
3: Export/Import Passwords
4: Clear All Passwords
5: Help
0: Exit
Choose an action:

```

**Password Creation:**
- Description input with validation
- Secret phrase entry with confirmation (minimum 12 characters)
- Password length selection (12-100 characters)
- Public key generation and display
- Generated password display

**Password Retrieval:**
- Numbered list of password entries
- Secret phrase entry via getpass (hidden)
- Public key verification
- Password regeneration

**Export/Import Interface:**
```
------------------------ Export/Import Menu ------------------------
1: Export passwords to file
2: Import passwords from file
0: ← Back to Main Menu
Choose an action:
```

### Security Implementation

**Public Key System:**
```python
# Generate public key from secret
public_key = SmartPasswordMaster.generate_public_key(secret)

# Verify secret without exposing it
is_valid = SmartPasswordMaster.check_public_key(secret, public_key)

# Generate password deterministically
password = SmartPasswordMaster.generate_smart_password(secret, length)
```

**Input Security:**
- Hidden secret input via `getpass.getpass()`
- Case-sensitive secret validation
- Duplicate detection prevention
- Input sanitization and validation
- **Minimum 12 character enforcement**

---

## Advanced Usage

### Password Management Strategy

**For Multiple Accounts:**
```bash
Description Examples:
- GitHub Personal Account
- Work Email - Office 365
- Social Media - Twitter
- Cloud Storage - Dropbox

Length Strategy:
- Critical accounts: 20-24 characters
- Important accounts: 16-20 characters
- General accounts: 12-16 characters
- Temporary accounts: 12-16 characters
```

### Secret Phrase Management

**Your secret phrase is the only key to all your passwords. Keep it safe, keep it secret.**

#### Minimum Requirements (enforced by the app):
- **At least 12 characters** — shorter secrets are not accepted
- **Case-sensitive** — "MySecret" and "mysecret" are different

#### Strong Secret Examples:
```
✅ "MyCat🐱Hippo2026"        — emoji + mixed case + numbers
✅ "P@ssw0rd!LongSecret"     — special chars + numbers + length
✅ "КотБегемот2026НаДиете"   — Cyrillic + numbers
✅ "Correct-Horse-Battery-42" — memorable phrase with separator
```

#### Weak Secret Examples (avoid):
```
❌ "password"                — dictionary word, too short
❌ "1234567890"              — only digits, too short
❌ "qwerty123"               — keyboard pattern
❌ "mysecret"                — common phrase, too short
```

#### Best Practices:
1. **Unique per service** - Different secret for each account type
2. **Memorable but complex** - Phrases you can remember
3. **Case-sensitive** - v3.0.1 enforces exact case matching
4. **No digital storage** - Keep only in memory
5. **Backup plan** - Physical written backup in secure location
6. **Export regularly** - Backup metadata after adding new passwords

### Backup Strategy

**Recommended workflow:**
1. Export metadata after adding new passwords
2. Store exports in secure, encrypted location
3. Keep exports across different machines for synchronization
4. Test import on a separate machine before relying on backups
5. Use timestamped exports to maintain version history

---

## Ecosystem Integration

### Part of Smart Password Suite

**Core Technology:**
- **[smartpasslib](https://github.com/smartlegionlab/smartpasslib)** - Core password generation library

**Desktop Application:**
- **[Desktop Smart Password Manager](https://github.com/smartlegionlab/smart-password-manager-desktop)** - Graphical interface with edit capabilities

**Other CLI Tools:**
- **[CLI Smart Password Generator](https://github.com/smartlegionlab/clipassgen/)** - Terminal-based password generation only

**Web Interface:**
- **[Web Smart Password Manager](https://github.com/smartlegionlab/smart-password-manager-web)** - Browser-based access

### Data Compatibility
- Uses same `~/.config/smart_password_manager/passwords.json` format as desktop manager
- Export files compatible across all ecosystem tools
- Consistent cryptographic operations across platforms
- Can share password metadata between CLI and desktop versions

### Comparison with Desktop Version

**CLI Advantages:**
- No GUI dependencies
- Works on servers and headless systems
- Faster for keyboard-centric users
- Scriptable and automatable
- Lower resource usage

**Desktop Advantages:**
- Graphical interface with table view
- Edit functionality for metadata
- Copy to clipboard with one click
- Better visual feedback
- Mouse support
- Context menu for quick actions

---

## Version History

| Version | smartpasslib | Status | Migration Required |
|---------|--------------|--------|---------------------|
| v2.2.2 and below | v2.x.x | ❌ Deprecated/Unsupported | Must migrate to v3.0.1 |
| v3.0.1+ | v3.0.0 | ✅ Current | N/A |

---

## License

**[BSD 3-Clause License](LICENSE)**

Copyright (c) 2026, Alexander Suvorov

---

## Support

- **CLI Manager Issues**: [GitHub Issues](https://github.com/smartlegionlab/clipassman/issues)
- **Core Library Issues**: [smartpasslib Issues](https://github.com/smartlegionlab/smartpasslib/issues)
- **Documentation**: Inline help (option 5) and this README

**Note**: Always test password generation with non-essential accounts first. Implementation security depends on proper usage.

---

## Security Warnings

### Secret Phrase Security

**Your secret phrase is the cryptographic master key**

1. **Permanent data loss**: Lost secret phrase = irreversible loss of all derived passwords
2. **No recovery mechanisms**: No password recovery, no secret reset, no administrative override
3. **Deterministic generation**: Identical input (secret + length) = identical output (password)
4. **Single point of failure**: Secret phrase is the sole authentication factor for all passwords
5. **Secure storage required**: Digital storage of secret phrases is prohibited

**Critical**: Test password regeneration with non-essential accounts before production use

### Secret Phrase Strength

**The security of your passwords depends entirely on your secret phrase.**

- **Minimum 12 characters** is enforced by the application
- Short secrets (under 12 chars) are **automatically rejected**
- Weak secrets like "password123" or "qwerty" will be rejected
- Use a mix of: uppercase, lowercase, numbers, symbols, emoji, or Cyrillic
- A 12-character secret with diverse character types provides **practical brute-force immunity**

**Remember:** The app cannot recover your secret phrase. If you lose it, all passwords are permanently lost.

### Export/Import Security Notes

- Export files contain ONLY metadata (public keys, descriptions, lengths)
- No passwords or secret phrases are ever exported
- Export files are plain JSON - store them securely
- Treat exported metadata as sensitive information
- Timestamped exports help maintain backup history

---

**Version**: 3.0.1 | [**Author**](https://smartlegionlab.ru): [Alexander Suvorov](https://alexander-suvorov.ru)

---

## Terminal Interface Examples

![clipassman](https://github.com/smartlegionlab/clipassman/blob/master/data/images/clipassman.png)

### Main Interface
```
********************************************************************************
********************** Smart Password Manager CLI v3.0.1 ***********************
******************************* Version: v3.0.1 ********************************
------------------------ Main Menu | Total passwords: 0 ------------------------
1: Add Password
2: Get/Delete Password
3: Export/Import Passwords
4: Clear All Passwords
5: Help
0: Exit
Choose an action: 1
---------------------------- Add new smart password ----------------------------
-------------------------------------------------------------------
Enter a descriptive name for this password (e.g., "GitHub Account")
-------------------------------------------------------------------
Description: Account 1

IMPORTANT: Your secret phrase (minimum 12 characters):
• Is case-sensitive
• Should be memorable but secure
• Will generate the same password every time
• Is never stored - only the hash is saved

Good examples: 'MyCat🐱Hippo2026' or 'P@ssw0rd!LongSecret'
Bad examples: 'password123', 'qwerty', 'mysecret'

Enter secret phrase (hidden): 
Confirm secret phrase (hidden): 
Enter password length (12-100, recommended 16-24): 16
--------------------------------------------------------------------------------
✓ Password metadata added successfully!
Description: Account 1
Length: 16 characters
Public Key: 9e279e242cbfd802...2d1d6c79c3dfa348
--------------------------- Your generated password: ---------------------------
lklkVJxrHffoT@5E
--------------------------------------------------------------------------------

Press Enter to continue... 
------------------------ Main Menu | Total passwords: 1 ------------------------
1: Add Password
2: Get/Delete Password
3: Export/Import Passwords
4: Clear All Passwords
5: Help
0: Exit
Choose an action: 2
-------------------------------- Password List: --------------------------------
1. Account 1 (16 chars)
0. ← Back
Select entry: 1
--------------------------------------------------------------------------------
Selected: Account 1
Length: 16 characters
1: Get password
2: Delete entry
0: ← Back
Select action: 1
--------------------------- Retrieve Smart Password ----------------------------
Description: Account 1
Length: 16 characters
Enter secret phrase (hidden): 
----------------------------- Generated Password: ------------------------------
lklkVJxrHffoT@5E
--------------------------------------------------------------------------------

Press Enter to continue... 
--------------------------------------------------------------------------------
Selected: Account 1
Length: 16 characters
1: Get password
2: Delete entry
0: ← Back
Select action: 0
-------------------------------- Password List: --------------------------------
1. Account 1 (16 chars)
0. ← Back
Select entry: 0
------------------------ Main Menu | Total passwords: 1 ------------------------
1: Add Password
2: Get/Delete Password
3: Export/Import Passwords
4: Clear All Passwords
5: Help
0: Exit
Choose an action: 5
------------------------------------- Help -------------------------------------

        CLIPASSMAN v3.0.1 - Console Smart Password Manager

        HOW IT WORKS:
        1. Provide a secret phrase (minimum 12 characters)
        2. System generates a public key from the secret
        3. Password is generated deterministically
        4. Same secret + same length = same password every time

        To retrieve a password:
        1. Enter the same secret phrase
        2. Password is regenerated identically

        SECURITY NOTES:
        • Passwords are NEVER stored anywhere
        • Secret phrases must be at least 12 characters
        • Case-sensitive secret phrases
        • Lost secret phrase = permanently lost passwords
        • Public key can be stored for verification

        For more information, visit the project page on GitHub: https://github.com/smartlegionlab/clipassman

        
----------------------------------------------------------------------
Complete documentation: https://github.com/smartlegionlab/smartpasslib
----------------------------------------------------------------------
--------------------------------------------------------------------------------

Press Enter to continue... 
------------------------ Main Menu | Total passwords: 1 ------------------------
1: Add Password
2: Get/Delete Password
3: Export/Import Passwords
4: Clear All Passwords
5: Help
0: Exit
Choose an action: 0
----------------- https://github.com/smartlegionlab/clipassman -----------------
--------------------- Copyright © 2026, Alexander Suvorov ----------------------
================================================================================


```

---

