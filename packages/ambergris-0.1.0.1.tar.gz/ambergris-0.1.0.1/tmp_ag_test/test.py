import ambergris
from ambergris import runners
from pathlib import Path
import json

dx_home = Path(".") / "home" / "dnanexus"
in_dir = dx_home / "in"
out_dir = dx_home / "out"

con_in = Path("/in")
con_out = Path("/out")

mounts = ambergris.make_bindmounts((in_dir.resolve(), con_in), (out_dir.resolve(), con_out))

with ambergris.open_container("alpine:latest", *mounts) as container:
    print(ambergris.exec_command(container, ["/bin/sh", "-c", "find /in/truths -name *.vcf.gz"]))