"""Report formatters."""
