"""Detect indices that look like audit/compliance data — flag for human review."""

from __future__ import annotations

import re

from ..models import Action, ClusterInfo, Confidence, Recommendation

COMPLIANCE_PATTERNS = [
    re.compile(r"audit", re.IGNORECASE),
    re.compile(r"compliance", re.IGNORECASE),
    re.compile(r"pci", re.IGNORECASE),
    re.compile(r"sox", re.IGNORECASE),
    re.compile(r"hipaa", re.IGNORECASE),
    re.compile(r"gdpr", re.IGNORECASE),
    re.compile(r"security[-_]log", re.IGNORECASE),
    re.compile(r"security[-_]audit", re.IGNORECASE),
    re.compile(r"legal[-_]hold", re.IGNORECASE),
    re.compile(r"legal[-_]retain", re.IGNORECASE),
    re.compile(r"forensic", re.IGNORECASE),
    re.compile(r"litigation", re.IGNORECASE),
]


class ComplianceDetector:
    def __init__(self, cost_per_gb_month: float):
        self.cost_per_gb_month = cost_per_gb_month

    def analyze(self, cluster: ClusterInfo) -> list[Recommendation]:
        recs: list[Recommendation] = []

        for idx in cluster.indices:
            if not any(p.search(idx.name) for p in COMPLIANCE_PATTERNS):
                continue

            reasons = [
                "Index name suggests audit or compliance data",
                f"Low query activity ({idx.query_total:,} queries observed)",
                f"Size: {idx.size_gb:.1f} GB",
                "May be subject to regulatory retention requirements — verify before deletion",
            ]

            recs.append(
                Recommendation(
                    action=Action.REVIEW,
                    target=idx.name,
                    confidence=Confidence.LOW,
                    reasons=reasons,
                    size_bytes=idx.size_bytes,
                    annual_savings=0,  # can't recommend deletion
                )
            )

        return recs
