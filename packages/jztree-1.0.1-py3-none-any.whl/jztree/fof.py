import numpy as np
from typing import Tuple
from dataclasses import replace
import jax
import jax.numpy as jnp
from jax.sharding import PartitionSpec as P

from .config import FofConfig, FofCatalogueConfig
from .data import  PosLvl, Label, Link, FofNodeData, ParticleData, FofCatalogue, InteractionList
from .data import PackedArray, TreeHierarchy, Pos, get_num, verify_ilist, get_pos
from .tools import inverse_of_splits, cumsum_starting_with_zero, offset_sum, div_ceil
from .tools import bucket_prefix_sum, masked_to_dense
from .tree import zsort, grouped_dense_interaction_list, build_tree_hierarchy
from .tree import simplify_interaction_list, zsort_and_tree, distr_grouped_dense_interaction_list
from .comm import pytree_len, all_to_all_with_irank, all_to_all_request
from .comm import all_to_all_request_children, all_to_all_with_splits
from .jax_ext import pcast_vma, pcast_like, get_rank_info, shard_map_constructor, tree_map_by_len
from .jax_ext import raise_if
from .stats import statistics, stats_callback, AllocStats

from jztree_cuda import ffi_fof
jax.ffi.register_ffi_target("FofNode2Node", ffi_fof.FofNode2Node(), platform="CUDA")
jax.ffi.register_ffi_target("FofLeaf2Leaf", ffi_fof.FofLeaf2Leaf(), platform="CUDA")
jax.ffi.register_ffi_target("InsertLinks", ffi_fof.InsertLinks(), platform="CUDA")
jax.ffi.register_ffi_target("NodeToChildLabel", ffi_fof.NodeToChildLabel(), platform="CUDA")

# ------------------------------------------------------------------------------------------------ #
#                                             FFI Calls                                            #
# ------------------------------------------------------------------------------------------------ #

def _fof_node2node(
        ilist: InteractionList, spl_parent: jax.Array, node_data: PosLvl, node_igroup: jax.Array, 
        rlink: float, boxsize: float = 0., block_size: int = 32
    ) -> Tuple[jax.Array, InteractionList]:
    assert ilist.ispl.shape[0] == spl_parent.shape[0], "Should both correspond to no. of nodes+1"
    assert len(node_data.lvl) == len(node_igroup), "Should both correspond to no. of childrne"
    assert ilist.isrc.size < 2**31, "So far only int32 supported {ilist_alloc_size/2**31}"
    assert ilist.isrc.dtype == ilist.ispl.dtype == spl_parent.dtype == node_igroup.dtype == jnp.int32
    
    size = len(node_data.pos)

    outputs = (
        jax.ShapeDtypeStruct((size,), jnp.int32), # node igroup
        jax.ShapeDtypeStruct((size+1,), jnp.int32), # node ilist splits
        jax.ShapeDtypeStruct((ilist.size(),), jnp.int32) # node-node ilist
    )

    res = jax.ffi.ffi_call("FofNode2Node", outputs, input_output_aliases={4:0})(
        ilist.ispl, ilist.isrc, spl_parent, node_data.pos_lvl(), node_igroup,
        r2link=np.float32(rlink*rlink), boxsize=np.float32(boxsize), block_size=np.int32(block_size),
        dim=np.int32(node_data.pos.shape[-1])
    )

    node_igroup, node_ilist_spl, node_ilist_ioth = pcast_like(res, like=ilist.isrc)

    node_ilist = verify_ilist(InteractionList(node_ilist_spl, node_ilist_ioth))

    n1, n2 = node_ilist.nfilled(), node_ilist.isrc.shape[0]
    node_igroup = node_igroup + raise_if(n1 > n2,
        "The interaction list allocation is too small. (need: {n1} have: {n2})\n"
        "Hint: Increase alloc_fac_ilist at least by a factor of {ratio:.1f}",
        n1=n1, n2=n2, ratio=n1/n2
    )

    stats_callback("allocation", AllocStats.record_filled_interactions, n1, n2)

    return node_igroup, node_ilist
_fof_node2node.jit = jax.jit(
    _fof_node2node, static_argnames=["boxsize", "rlink", "block_size"]
)

def _insert_links(igroup, iA, iB, num_links: jax.Array | None = None, block_size=64):
    ngroups = len(igroup)
    if num_links is None:
        num_links = jnp.array(len(iA), dtype=jnp.int32)
    
    out = (jax.ShapeDtypeStruct((ngroups,), jnp.int32),)

    igr_out = jax.ffi.ffi_call("InsertLinks", out, input_output_aliases={0:0})(
        igroup, iA, iB, num_links, block_size=np.int32(block_size)
    )[0]
    
    return pcast_like(igr_out, like=igroup)

def _node_to_child_label(igroup: jax.Array, lvl: jax.Array, spl: jax.Array,
                         rlink: float, dim: int, num: int | None = None,
                         size_child: int | None = None,
                         flag_local: jax.Array | None = None,
                         block_size: int = 64, dtype=jnp.float32) -> jax.Array:
    assert len(spl) == len(igroup) + 1 == len(lvl) + 1

    if size_child is None:
        size_child = igroup.size

    if flag_local is None:
        flag_local = jnp.ones(igroup.shape, dtype=jnp.bool)

    outputs = (jax.ShapeDtypeStruct((size_child,), jnp.int32),)
    igroup_child = jax.ffi.ffi_call("NodeToChildLabel",  outputs)(
        igroup, flag_local, lvl, spl, block_size=np.uint64(block_size),
        r2link=np.float32(rlink*rlink), dim=np.int32(dim),
        double_precision = (dtype == jnp.float64)
    )[0]

    if num is not None:
        igroup_child = jnp.where(jnp.arange(size_child) < num, igroup_child, 0)

    return igroup_child
_node_to_child_label.jit = jax.jit(_node_to_child_label, static_argnames=("size_child", "rlink", "block_size", "dim"))

def _fof_dual_walk(th: TreeHierarchy, rlink: float, boxsize: float=0., alloc_fac_ilist: int = 128
                  ) -> Tuple[FofNodeData, InteractionList]:
    nplanes = th.num_planes()
    size = th.size()

    # initialize top-level interaction list
    spl, ilist, nsup = grouped_dense_interaction_list(
        th.lvl.num(nplanes-1), size_ilist=int(th.size_leaves*alloc_fac_ilist), ngroup=32, size_super=size
    )
    # Define super-node data
    igroup = jnp.arange(size, dtype=jnp.int32)
    spl_n2n = th.ispl_n2n.append(spl, nsup+1, fill_value=spl[-1], resize=True)
    spl_n2n.ispl = spl_n2n.ispl + raise_if(spl_n2n.nfilled() > spl_n2n.size(),
        "No space for top-level splits\nHint: Increase alloc_fac_nodes."
    )

    max_lvl = th.info().max_lvl()
    nlvl = th.lvl.append(jnp.full_like(igroup, max_lvl), nsup, max_lvl, resize=True)

    def handle_level(i, carry):
        igroup, ilist = carry
        level = nplanes - 1 - i
        parent_spl = spl_n2n.get(level+1, size+1)

        igroup = _node_to_child_label(igroup, nlvl.get(level+1, size), parent_spl,
                                      num=th.num(level), rlink=rlink, dim=th.geom_cent.data.shape[-1],
                                      dtype=th.geom_cent.data.dtype)
        node_data = PosLvl(pos=th.geom_cent.get(level, size), lvl=nlvl.get(level, size))

        igroup, ilist = _fof_node2node(
            ilist, parent_spl, node_data, igroup, rlink=rlink, boxsize=boxsize
        )

        return igroup, ilist

    igroup, ilist = jax.lax.fori_loop(0, nplanes, handle_level, init_val=(igroup, ilist))
    
    node_data = FofNodeData(nlvl.get(0, size), igroup, spl_n2n.get(0, size+1))

    return node_data, ilist
_fof_dual_walk.jit = jax.jit(_fof_dual_walk, static_argnames=["rlink", "boxsize", "alloc_fac_ilist"])

def _fof_leaf2leaf(leaf_data: FofNodeData, ilist: InteractionList, posz: jax.Array,
                   rlink: float, boxsize: float = 0., block_size=32):
    assert len(leaf_data.spl) == len(ilist.ispl) == len(leaf_data.igroup)+1 == len(leaf_data.lvl)+1
    assert ilist.isrc.dtype == ilist.ispl.dtype == leaf_data.spl.dtype == leaf_data.igroup.dtype == jnp.int32

    part_igroup = _node_to_child_label(
        leaf_data.igroup, leaf_data.lvl, leaf_data.spl, rlink=rlink, size_child=len(posz),
        num=leaf_data.spl[-1], dim=posz.shape[-1], dtype=posz.dtype
    )

    igroup = jax.ffi.ffi_call("FofLeaf2Leaf", (jax.ShapeDtypeStruct((len(posz),), part_igroup.dtype),))(
        ilist.ispl, ilist.isrc, leaf_data.spl, posz, part_igroup,
        r2link=np.float32(rlink*rlink), boxsize=np.float32(boxsize), block_size=np.int32(block_size)
    )[0]

    return igroup
_fof_leaf2leaf.jit = jax.jit(_fof_leaf2leaf, static_argnames=["rlink", "boxsize", "block_size"])

# ------------------------------------------------------------------------------------------------ #
#                                         Helper Functions                                         #
# ------------------------------------------------------------------------------------------------ #

def _global_label_to_local_segment(labels: Label) -> jax.Array:
    """Map each global to the index of the first occurence of it"""
    # Note, currently the Fof self-linking detection can be wrong for index 0!
    pairs = labels.stacked()

    lab, indices, inv = jnp.unique(
        pairs, axis=0, size=len(pairs), return_index=True, return_inverse=True
    )
    
    return jnp.where(labels.igroup >= 0, indices[inv], labels.igroup)

def _masked_min_scatter(mask, arr, indices, values):
    indices = jnp.where(mask, indices, len(arr))

    # first we erase the initial value of arr at the update locations,
    # so we will only get the min of the updates
    arr = arr.at[indices].set(jnp.iinfo(arr.dtype).max)
    
    return arr.at[indices].min(values)

def _tree_where(condition: jax.Array, l1: Label, l2: Label) -> Label:
    return jax.tree.map(lambda x, y: jnp.where(condition, x, y), l1, l2)

def _label_min_max(l1: Label, l2: Label):
    lmax = _tree_where(l1 >= l2, l1, l2)
    lmin = _tree_where(~(l1 >= l2), l1, l2)
    return lmin, lmax

def fof_is_superset(igroup_sup, igroup, mask = None):
    """Checks whether every FoF group in igroup_sup is a superset of sets in igroup_low
    
    Useful for comparing different FoF implementations where labels may differ even when they
    represent the same groups.
    """
    # For this we need to check that if we link groups together as indicated by the super-grouping
    # that they are identical to the super groups

    # indicates the super group of each label in igroup
    label_map = jnp.zeros(len(igroup), dtype=jnp.int32).at[igroup].set(igroup_sup)
    
    if mask is None:
        return jnp.all(igroup_sup == label_map[igroup])
    else:
        return jnp.all((igroup_sup == label_map[igroup]) | ~mask)

# ------------------------------------------------------------------------------------------------ #
#                                        Distributed Linking                                       #
# ------------------------------------------------------------------------------------------------ #

def _distr_link_step(igroup: jax.Array, labels: Label, links: Link, nlinks: jax.Array
                           ) -> Tuple[jax.Array, Label, Link, jax.Array]:
    rank, ndev, axis_name = get_rank_info()
    dtype = igroup.dtype

    def contract(lA: Label, lB: Label):
        # Contracts labels as far as possible, given the locally available information
        # We do this step every time the local information may have changed

        lA = _tree_where(lA.irank == rank, labels[lA.igroup], lA)
        lB = _tree_where(lB.irank == rank, labels[lB.igroup], lB)
        are_local = (lA.irank == rank).astype(dtype) + (lB.irank == rank).astype(dtype)
        lmin, lmax = _label_min_max(lA, lB)
        return lmin, lmax, are_local

    # Communicate the links to the larger rank in the link
    send_rank = jnp.maximum(links.a.irank, links.b.irank)
    links, dev_spl = all_to_all_with_irank(
        send_rank, links, num=nlinks, axis_name=axis_name, copy_self=False
    )

    stats_callback("allocation", AllocStats.record_filled_links, dev_spl[-1], links.a.igroup.size)
    
    valid = jnp.arange(pytree_len(links), dtype=jnp.int32) < dev_spl[-1]

    lA, lB, are_local = contract(links.a, links.b)

    # Handle fully local links. Note that insert_links also contracts the local igroup graph
    igrA, num = masked_to_dense(lA.igroup, valid & (are_local==2))
    igrB, num = masked_to_dense(lB.igroup, valid & (are_local==2))
    igroup = _insert_links(igroup, igrA, igrB, num)
    labels = labels[igroup]

    is_root = (labels.irank == rank) & (labels.igroup == jnp.arange(len(labels.igroup)))

    # Dereference again, since labels may have changed
    lmin, lmax, are_local = contract(lA, lB)
    was_resolved = lmin == lmax

    # Handle partially local links. For these we need to update the higher root node to any
    # parent of the lower node
    # Multiple links may try to update a single root node at the same time. To deal with this
    # race condition, we take the minimum suggested update and then need to retry the unresolved
    # in the next iteration where we will continue try them at the larger node

    update = (are_local == 1) & (lmax.irank == rank)  & (~was_resolved)
    update = update & (labels[lmax.igroup] > lmin) & is_root[lmax.igroup]
    labels.irank = _masked_min_scatter(update, labels.irank, lmax.igroup, lmin.irank)
    # only update labels.igroup with links that point towards the same rank
    update = update & (labels[lmax.igroup].irank == lmin.irank)
    labels.igroup = _masked_min_scatter(update, labels.igroup, lmax.igroup, lmin.igroup)

    # Dereference again, since labels may have changed
    labels = labels[igroup]
    lmin, lmax, are_local = contract(lmin, lmax)

    was_resolved = lmin == lmax
    
    remaining_links = jax.tree.map(
        lambda l: masked_to_dense(l, valid & ~was_resolved)[0], Link(lmax, lmin)
    )

    return igroup, labels, remaining_links, jnp.sum(valid & ~was_resolved)
_distr_link_step.jit = jax.jit(_distr_link_step)

def _distr_contract(labels: Label, igroup: jax.Array, dev_spl: int):
    rank, ndev, axis_name = get_rank_info()

    igroup = igroup[igroup]
    labels = labels[igroup]

    # mask root labels of the local graph that lie remotely
    idx = jnp.arange(len(igroup))
    is_local_root = idx == igroup
    valid = (idx >= dev_spl[rank]) & (idx < dev_spl[rank+1])
    mask = valid & is_local_root & (labels.irank != rank)
    
    def contraction_step(carry):
        labels, mask, _ = carry
        non_loc_lab, num_uq, ind = masked_to_dense(labels, mask, get_indices=True)
        
        nloc_lab_new: Label = all_to_all_request(
            non_loc_lab.irank, non_loc_lab.igroup, labels, num=num_uq, axis_name=axis_name, copy_self=False
        )
        labels_new = Label(
            labels.irank.at[ind].set(nloc_lab_new.irank),
            labels.igroup.at[ind].set(nloc_lab_new.igroup)
        )
        labels_new = labels_new[igroup]

        mask = mask & (labels != labels_new)
        
        any_left = jax.lax.pmax(jnp.any(mask), axis_name)
        
        return labels_new, mask, any_left
    
    return jax.lax.while_loop(
        lambda c: c[2], contraction_step, (labels, mask, jnp.array(True))
    )[0]

def _distr_link(
        igroup: jax.Array,
        labels: jax.Array,
        links: Link,
        dev_spl: jax.Array,
        nlinks: jax.Array
    ):
    rank, ndev, axis_name = get_rank_info()

    def condition(carry):
        igroup, labels, links, nlinks = carry
        return jax.lax.psum(nlinks > 0, axis_name) > 0
    
    init_val = (igroup, labels, links, nlinks)
    igroup, labels, links, nlinks = jax.lax.while_loop(
        condition, lambda c: _distr_link_step(*c), init_val
    )

    return _distr_contract(labels, igroup, dev_spl)

def _distr_detect_new_cross_task_links(igroup, igroup_new, origin_group, dev_spl) -> Link:
    rank, ndev, axis_name = get_rank_info()
    
    valid = jnp.arange(len(igroup)) < dev_spl[-1]

    # find globally relevant root nodes that became linked
    was_root = jnp.arange(len(igroup)) == igroup
    irank = inverse_of_splits(dev_spl, igroup.size)
    remote = irank != rank
    mask = (igroup != igroup_new) & was_root & remote & valid
    indices = jnp.where(mask, size=len(igroup))
    num_links = jnp.sum(mask)
    
    links = Link(
        Label(irank[indices], origin_group[indices]),
        Label(irank[igroup_new[indices]], origin_group[igroup_new[indices]]),
    )

    return links, num_links

# ------------------------------------------------------------------------------------------------ #
#                                          Distributed FoF                                         #
# ------------------------------------------------------------------------------------------------ #

def _distr_fof_dual_walk(th: TreeHierarchy, rlink: float, boxsize: float = 0., 
                         alloc_fac_ilist = 32, size_links = None
                        ) -> Tuple[FofNodeData, InteractionList, PackedArray]:
    rank, ndev, axis_name = get_rank_info()

    size = th.size()
    if size_links is  None:
        size_links = size

    spl, ilist, nsup = distr_grouped_dense_interaction_list(
        th.num(th.num_planes()-1), size, int(th.size_leaves*alloc_fac_ilist), only_geq=True
    )
    # Define arrays we need during tree-walk
    spl_n2n = th.ispl_n2n.append(spl, nsup+1, fill_value=spl[-1], resize=True)
    spl_n2n.ispl = spl_n2n.ispl + raise_if(spl_n2n.nfilled() > spl_n2n.size(),
        "No space for top-level splits\nHint: Increase alloc_fac_nodes."
    )

    lvl_max = th.info().max_lvl()
    node_lvl = th.lvl.append(jnp.full(size, lvl_max), nsup, fill_value=lvl_max, resize=True)
    l2p = th.splits_leaf_to_part()

    # initialize labels of top-level
    igroup = pcast_vma(jnp.arange(size), axis_name)

    # Set up an empty PackedArray to save link data
    link_data = PackedArray.create_empty(
        (size_links, 4), levels=th.num_planes()+1, dtype=jnp.int32, vma=jax.typeof(rank).vma
    )

    def handle_plane(i: int, carry: Tuple[jax.Array, InteractionList, PackedArray]):
        level = th.num_planes() - 1 - i
        parent_igroup, ilist, link_data = carry

        parent_lvl = node_lvl.get(level+1, size)
        parent_spl = spl_n2n.get(level+1, size+1)

        igroup = _node_to_child_label(
            parent_igroup, parent_lvl, parent_spl, rlink=rlink, num=th.num(level),
            dim=th.geom_cent.data.shape[-1], dtype=th.geom_cent.data.dtype
        )

        poslvl = PosLvl(pos=th.geom_cent.get(level, size), lvl=th.lvl.get(level, size))
        pid = l2p[th.ispl_n2l.get(level, size)] # first particle id in each node
        
        # Request the remote node children that we need to interact with
        (poslvl, ids, pid), parent_spl, dev_spl = all_to_all_request_children(
            ilist.dev_spl, ilist.ids, parent_spl, (poslvl, jnp.arange(size), pid),
            axis_name=axis_name, err_hint_child="\nHint: Increase alloc_fac_nodes.",
            err_hint_parent="\nHint: Increase alloc_fac_nodes."
        )

        stats_callback("allocation", AllocStats.record_filled_nodes_interaction, dev_spl[-1], size)

        # Treat remote nodes as roots
        irank = inverse_of_splits(dev_spl, size)
        igroup = jnp.where(irank==rank, igroup, jnp.arange(size))

        igroup_new, ilist = _fof_node2node(
            ilist, parent_spl, poslvl, igroup, rlink=rlink, boxsize=boxsize
        )
        # Save cross-task links for later
        links, num_links = _distr_detect_new_cross_task_links(igroup, igroup_new, pid, dev_spl)
        link_data = link_data.append(links.stacked(axis=-1), num_links)

        # Remove 0 interaction nodes from interaction list (reduces unnecessary remote requests)
        ilist = replace(ilist, ids=ids, dev_spl=dev_spl)
        ilist = simplify_interaction_list(ilist, always_keep=(irank==rank))

        return igroup_new, ilist, link_data

    igroup, ilist, link_data = jax.lax.fori_loop(
        0, th.num_planes(), handle_plane, (igroup, ilist, link_data)
    )

    node_data = FofNodeData(th.lvl.get(0, size), igroup, spl=l2p)

    return node_data, ilist, link_data
_distr_fof_dual_walk.jit = jax.jit(
    _distr_fof_dual_walk, static_argnames=("alloc_fac_ilist", "boxsize", "rlink", "size_links")
)

def _distr_fof_leaf2leaf(node_data: FofNodeData, ilist: InteractionList,
                        link_data: PackedArray, posz: jax.Array,
                        rlink: float, boxsize: float = 0., block_size=32) -> Label:
    # We distinguish between global Labels that point to the global root particle
    # and local segment labels that point towards a locally known particle that has the
    # same group
    
    rank, ndev, axis_name = get_rank_info()
    size = len(posz)

    iseg = _node_to_child_label(
        node_data.igroup, node_data.lvl, node_data.spl, rlink=rlink, size_child=size,
        num=node_data.spl[-1], dim=posz.shape[-1], dtype=posz.dtype
    )

    numpart = node_data.spl[-1]
    (posz, pids), spl, dev_spl = all_to_all_request_children(
        ilist.dev_spl, ilist.ids, node_data.spl, (posz, jnp.arange(size)), axis_name=axis_name,
        err_hint_parent="\nHint: Increase alloc_fac_nodes.",
        err_hint_child="\nHint: Increase padding."
    )

    stats_callback("allocation", AllocStats.record_filled_part_interactions, dev_spl[-1], size)

    # Treat remote nodes as roots
    irank = inverse_of_splits(dev_spl, size)
    iseg = jnp.where(irank==rank, iseg, jnp.arange(size))

    iseg_new = jax.ffi.ffi_call("FofLeaf2Leaf", (jax.ShapeDtypeStruct((len(posz),), iseg.dtype),))(
        ilist.ispl, ilist.isrc, spl, posz, iseg,
        r2link=np.float32(rlink*rlink), boxsize=np.float32(boxsize), block_size=np.int32(block_size)
    )[0]

    # insert new links
    links, num_links = _distr_detect_new_cross_task_links(iseg, iseg_new, pids, dev_spl)
    link_data = link_data.append(links.stacked(axis=-1), num_links)

    link_data.ispl = link_data.ispl + raise_if(link_data.nfilled() > link_data.size(),
        "The link allocation is too small. (need: {n1} have: {n2})\n"
        "Hint: Increase alloc_fac_distr_links at least by a factor of {ratio:.1f}",
        n1=link_data.nfilled(), n2=link_data.size(), ratio=link_data.size()/link_data.size()
    )
    stats_callback("allocation", AllocStats.record_filled_links, link_data.nfilled(), link_data.size())

    links = Link.from_stacked(link_data.data)

    # Infer global labels
    labels = Label(jnp.full(iseg.shape, rank, dtype=jnp.int32), iseg)
    labels = _distr_link(iseg_new, labels, links, dev_spl, link_data.ispl[-1])
    
    labels = _tree_where(jnp.arange(len(labels.igroup)) < numpart, labels, Label(-1,-1))
    labels.ilocal_segment = iseg_new

    return labels
_distr_fof_leaf2leaf.jit = jax.jit(_distr_fof_leaf2leaf, static_argnames=["rlink", "boxsize", "block_size"])

# ------------------------------------------------------------------------------------------------ #
#                                   Ordering particles by groups                                   #
# ------------------------------------------------------------------------------------------------ #

def _fof_order(igroup: jax.Array, part: ParticleData, npart: int | None = None):
    if npart is None:
        npart = jnp.sum(~jnp.isnan(get_pos(part)[...,0]))
    igr = jnp.where(jnp.arange(len(igroup)) < npart, igroup, len(igroup))
    counts = jnp.zeros(len(igroup), dtype=igroup.dtype).at[igr].add(1)

    isort = jnp.argsort(igr, stable=True)
    part, counts = tree_map_by_len(lambda x: x[isort], (part, counts), len(counts))

    return part, counts

def _distr_fof_order(label: Label, part: ParticleData, size_out: int | None = None):
    """Rearanges particles in group-order and determines group-count at root-particles

    Group order means that each FoF-group contains group-count continguous particles, 
    starting at its root particle. Group roots are in z-order.
    Guarantees equal load balance if npart_tot % ndev == 0. Therefore, if positions were padded
    previously (to allow for load-imbalance) it is now possible to undo the padding by providing 
    size_out = npart_tot // ndev
    The last group on each device may span across one or more consecutive devices. This needs to be
    accounted for when e.g. summing group information
    """
    # Labels point towards the root of a group, which may lie on another task
    # Groups may be split over several tasks. We call disjoint parts of the group
    # that may lie on other tasks "segments". To count particles we first count
    # in segments and then send the segments to the root task
    rank, ndev, axis_name = get_rank_info()

    npart = get_num(part)
    size = len(label.igroup)

    if label.ilocal_segment is None:
        iseg = _global_label_to_local_segment(label)
    else:
        iseg = label.ilocal_segment

    # Count locally known roots
    is_segment_root = (iseg == jnp.arange(len(iseg))) & (jnp.arange(len(iseg)) < npart)
    seg_idx, num_segs = offset_sum(is_segment_root)
    seg_idx = jnp.where(jnp.arange(size) < npart, seg_idx[iseg], size) # mask invalid particles
    seg_counts = jnp.zeros(size, dtype=jnp.int32).at[seg_idx].add(1)

    # Send segments to root task
    segment_inv = jnp.where(is_segment_root, size=size, fill_value=size)[0]
    seg_label = label[segment_inv]
    
    (seg_counts, seg_igroup), dev_spl, inv = all_to_all_with_irank(
        seg_label.irank, (seg_counts, seg_label.igroup), 
        num=num_segs, get_inverse=True, axis_name=axis_name
    )
    group_counts = jnp.zeros(size, dtype=jnp.int32).at[seg_idx[seg_igroup]].add(seg_counts)

    group_offsets = cumsum_starting_with_zero(group_counts)
    # Mark counts at root particles for later
    idx = jnp.arange(size)
    is_group_root = (label.igroup == idx) & (label.irank == rank) & (idx < npart)
    root_group_counts = jnp.where(is_group_root, group_counts[seg_idx], 0)

    dev_counts = jax.lax.all_gather(jnp.sum(group_counts), axis_name)
    seg_offsets = group_offsets[seg_idx[seg_igroup]] + bucket_prefix_sum(seg_igroup, seg_counts, num=dev_spl[-1])

    # send back offsets
    dense_seg_offsets, dev_spl = all_to_all_with_splits(
        seg_offsets, dev_spl, axis_name=axis_name
    )
    seg_offsets = dense_seg_offsets[inv]

    part_seg_offset = bucket_prefix_sum(iseg, num=npart)

    with jax.enable_x64():
        dev_offsets = cumsum_starting_with_zero(jnp.astype(dev_counts, jnp.int64))
        seg_offsets = jnp.astype(dense_seg_offsets[inv], jnp.int64) + dev_offsets[seg_label.irank]
        
        part_gid = seg_offsets[seg_idx] + part_seg_offset.astype(jnp.int64)

        nparttot = dev_offsets[-1]
        target_global_dev_spl = jnp.pad(jnp.arange(ndev) * (nparttot // ndev), (0,1), constant_values=nparttot)

        send_irank = (jnp.searchsorted(target_global_dev_spl, part_gid, side="right") - 1).astype(jnp.int32)

    isort = jnp.argsort(send_irank) # do argsort with int32 -- int64 is extremely slow in jax
    dev_spl = jnp.searchsorted(send_irank[isort], jnp.arange(ndev+1, dtype=send_irank.dtype), side="left")

    with jax.enable_x64():
        part_gid, part, root_group_counts = tree_map_by_len(
            lambda x: x[isort], (part_gid, part, root_group_counts), size
        )
        (gid, part, gcnt), dev_spl = all_to_all_with_splits(
            (part_gid, part, root_group_counts), dev_spl
        )

        valid = jnp.arange(len(gid)) < dev_spl[-1]
        itarget = jnp.where(valid, gid - target_global_dev_spl[rank], jnp.arange(len(gid)))

        isort = jnp.zeros_like(itarget).at[itarget].set(jnp.arange(size))
        
        part, gcnt = tree_map_by_len(lambda x: x[isort], (part, gcnt), len(gcnt))
    
    if size_out is not None: # Coding-note: might save some space if already done in comm. output:
        part, gcnt = tree_map_by_len(lambda x: x[:size_out], (part, gcnt), len(gcnt))
    
    part.num = dev_spl[-1]

    return part, gcnt
_distr_fof_order.smap = shard_map_constructor(_distr_fof_order,
    in_specs=(P(-1), P(-1), None), static_argnames=["size_out"]
)

# ------------------------------------------------------------------------------------------------ #
#                                      Fof Catalogue Reduction                                     #
# ------------------------------------------------------------------------------------------------ #

def _distr_cross_task_group_info(group_counts: jax.Array, npart: int, npart_min: int = 20):
    """The last group of each rank may span accross ranks. Here, we identify for each
    rank the rank and the local remaining count of the first group which may have started elsewhere.
    """
    rank, ndev, axis_name = get_rank_info()
    if ndev == 1:
        return 0, 0

    idx = jnp.arange(len(group_counts))
    last_group_start = jnp.max(jnp.where((group_counts > 0) & (idx < npart), idx, 0))
    last_group_count = group_counts[last_group_start]

    with jax.enable_x64():
        dev_npart = jax.lax.all_gather(npart, axis_name)
        dev_spl = cumsum_starting_with_zero(jnp.astype(dev_npart, jnp.int64))

        gl_last_group_end = dev_spl[rank] + last_group_start + last_group_count
        dev_add_count = gl_last_group_end - dev_spl[:-1]
        dev_add_count = jnp.where((last_group_count < npart_min) | (jnp.arange(ndev) <= rank), 0, dev_add_count)
        dev_add_count = jnp.minimum(dev_add_count, dev_npart)

        dev_recv_count = jax.lax.all_to_all(dev_add_count, axis_name, 0, 0, tiled=True)

    first_group_count = jnp.max(dev_recv_count.astype(jnp.int32))
    first_group_rank = jnp.argmax(dev_recv_count.astype(jnp.int32))

    return first_group_rank, first_group_count

def _fof_catalogue_from_groups(
        part: ParticleData, # Particles must be in Group order! (See fof_order/distr_fof_order)
        group_counts: jax.Array,
        cfg_cata: FofCatalogueConfig = FofCatalogueConfig(),
        boxsize: float = 0.,
        size_cata: int | None = None
    ) -> FofCatalogue:
    """Reduces particle data to determine a Friends-of-Friends group-catalogue

    Some parts of the catalogue will be set to None if relevant particle attributes are missing.
    You may define your on data class that skips attributes that you are not interested in.
    Consider the "ParticleData" class to understand relevant attributes.
    """
    rank, ndev, axis_name = get_rank_info()

    npart = get_num(part, default_to_length=True)
    size_part = len(group_counts)
    npart_min = cfg_cata.npart_min

    if size_cata is None:
        size_cata = (size_part + npart_min - 1) // npart_min # Worst case estimate of catalogue size
    
    first_group_rank, first_group_count = _distr_cross_task_group_info(
        group_counts, npart, npart_min=npart_min
    )
    
    # To simplify reductions we add an extra group at the beginning that carries everything
    # that belongs to the previous task
    keep_as_group = group_counts >= npart_min

    # Create dense information
    csum = jnp.cumsum(keep_as_group.astype(jnp.int32))
    part_gr_idx, ngroups = csum, csum[-1]

    gr_start = jnp.where(keep_as_group, fill_value=size_part, size=size_cata)[0]
    gr_valid = jnp.arange(size_cata) < ngroups
    gr_counts = group_counts[gr_start] * gr_valid

    # add in extra group at beginning, we'll remove it later
    gr_start = jnp.pad(gr_start, (1,0), constant_values=0)
    gr_valid = jnp.pad(gr_valid, (1,0), constant_values=True)
    gr_counts = jnp.pad(gr_counts, (1,0), constant_values=first_group_count)

    idx = jnp.arange(size_part)
    part_valid = (part_gr_idx >= 0) & (idx < npart) &  (idx < gr_start[part_gr_idx] + gr_counts[part_gr_idx])
    part_gr_idx = jnp.where(part_valid, part_gr_idx, size_cata+1)

    def sum_particles(val, invalid_val=0):
        gr_val = jnp.zeros((size_cata+1,) + val.shape[1:], val.dtype)
        gr_val = gr_val.at[part_gr_idx].add(val)
        valid = gr_valid.reshape((size_cata+1,) + (1,) * (gr_val.ndim-1))
        gr_val = jnp.where(valid, gr_val, invalid_val)
        if ndev == 1: return gr_val
        # Correct the last group by adding segments on other tasks
        dev_mask = (np.arange(ndev) == first_group_rank).reshape((-1,) + (1,) * (gr_val.ndim-1))
        send_val = jnp.where(dev_mask, gr_val[0], 0)
        add_last_val = jax.lax.all_to_all(send_val, axis_name, 0, 0, tiled=True)
        return gr_val.at[ngroups].add(jnp.sum(add_last_val, axis=0))
    def get_gr_prop(val):
        if ndev==1: return val
        last_val = jax.lax.all_gather(val[ngroups], axis_name)
        return val.at[0].set(last_val[first_group_rank])
    def wrap_dx(dx):
        if boxsize:
            return ((dx + 0.5*boxsize) % boxsize) - 0.5 * boxsize
        else:
            return dx
    def wrap_pos(x):
        return x % boxsize if boxsize else x
    
    cata = FofCatalogue(ngroups=ngroups, count=gr_counts, offset=gr_start)

    if getattr(part, "mass", None) is not None:
        part_mass = getattr(part, "mass")
        if part_mass.size == 1: # constant masses
            gr_mass = cata.count * part_mass
        else:
            gr_mass = sum_particles(part_mass)
        cata.mass = gr_mass
    else:
        part_mass = jnp.array(1., dtype=get_pos(part).dtype)
        gr_mass = cata.count * part_mass

    if getattr(part, "pos", None) is not None:
        pos0 = get_gr_prop(part.pos[gr_start])
        m_x_pos = sum_particles(wrap_dx(part.pos - pos0[part_gr_idx]) * part_mass[...,None])
        cata.com_pos = wrap_pos((m_x_pos / gr_mass[:,None]) + pos0)

        dx = wrap_dx(part.pos - get_gr_prop(cata.com_pos)[part_gr_idx])
        m_x_r2 = sum_particles((dx[...,0]**2 + dx[...,1]**2 + dx[...,2]**2) * part_mass)
        cata.com_inertia_radius = jnp.sqrt(m_x_r2 / gr_mass)

    if getattr(part, "vel", None) is not None:
        vel0 = get_gr_prop(part.vel[gr_start])
        m_x_vel = sum_particles((part.vel - vel0[part_gr_idx]) * part_mass[...,None])
        cata.com_vel = (m_x_vel / gr_mass[:,None]) + vel0

    if getattr(part, "v_rad", None) is not None:
        sum_v_rad = sum_particles(part.v_rad * part_mass)
        cata.v_rad = sum_v_rad / gr_mass


    if getattr(part, "zplus1", None) is not None:
        scale_factor = 1 / part.zplus1
        sum_scale_factor = sum_particles(scale_factor * part_mass)
        cata.scale_factor = sum_scale_factor / gr_mass

    # remove the first "fake" group that we inserted:
    def remove_first(x):
        return x[1:] if len(x) == size_cata+1 else x
    cata = tree_map_by_len(remove_first, cata, len(cata.count))

    return cata
_fof_catalogue_from_groups.smap = shard_map_constructor(_fof_catalogue_from_groups,
    in_specs=(P(-1), P(-1), None, None, None),
    static_argnames=["cfg_cata", "boxsize", "size_cata"]
)

# ------------------------------------------------------------------------------------------------ #
#                                          User Interface                                          #
# ------------------------------------------------------------------------------------------------ #

def fof_labels(part: jax.Array | Pos, rlink: float, boxsize: float = 0., 
               cfg: FofConfig = FofConfig(), th: TreeHierarchy | None = None,
               output_order: str = "z") -> Tuple[jax.Array | Pos, jax.Array]:
    """Calculates the friends-of-friends group relation ship for single-GPU cases

    For multi-GPU, please use :func:`distr_fof_labels`

    Args:
        part: particles, can be a jax.Array or any particle data structure with
            a .pos atribute
        rlink: (absolute) linking length
        boxsize: if provided, distances use periodic wrapping
        cfg: controls low-level details
        th: May be provided to skip building a new tree-hierarchy inside of this function.
            See :func:`jztree.tree.zsort_and_tree`. If this argument is provided, particles 
            are assumed to be already in z-order.
        output_order: may be "z" or "input"
    Returns:
        (part, igroup) -- (possibly) reordered particles and group labels -- igroup points 
        to the first particle in z-order that belongs to the same group.
    """
    rank, ndev, axis_name = get_rank_info()

    assert ndev == 1, "Please use distr_fof_labels for multi-GPU"
    
    if th is None:
        partz, idz = zsort(part)
        th = build_tree_hierarchy(partz, cfg_tree=cfg.tree)
    else: # assume input is sorted
        partz, idz = part, None

    node_data, ilist = _fof_dual_walk(
        th, rlink=rlink, boxsize=boxsize, alloc_fac_ilist=cfg.alloc_fac_ilist
    )
    igroupz = _fof_leaf2leaf(
        node_data, ilist, get_pos(partz), rlink=rlink, boxsize=boxsize
    )

    if (output_order == "input") and (idz is not None):
        igroup = igroupz.at[idz].set(idz[igroupz])

        return part, igroup
    else:
        return partz, igroupz
fof_labels.jit = jax.jit(fof_labels, static_argnames=["rlink", "boxsize", "cfg", "output_order"])

def distr_fof_labels(
        part: Pos, rlink: float, boxsize: float = 0., cfg: FofConfig = FofConfig(), 
        th: TreeHierarchy | None = None, linearize_labels: bool = False
    ) -> Tuple[Pos, Label]:
    """Calculates the friends-of-friends group relation ship for multi-GPU cases.

    For single-GPU, please use :func:`fof_labels`

    Args:
        part: particles, should have some padding and follow the :class:`jztree.data.Pos`
            interface
        rlink: (absolute) linking length
        boxsize: if provided, distances use periodic wrapping
        cfg: controls low-level details
        th: May be provided to skip building a new tree-hierarchy inside of this function.
            See :func:`jztree.tree.zsort_and_tree`. If this argument is provided, particles 
            are assumed to be already in z-order.
        linearize_labels: if true, group labels will be output as a scalar global index.
            Only use this for comparing small setups against single-GPU.
    Returns:
        (partz, label) -- z-ordered particles and group labels -- label points to the rank
        and index of the first particle in z-order that belongs to the same group.
    """
    rank, ndev, axis_name = get_rank_info()

    if th is None:
        partz, th = zsort_and_tree(part, cfg.tree)
    else:
        partz = part # assume z-sorted

    posz = get_pos(partz)

    node_data, ilist, link_data = _distr_fof_dual_walk(
        th, rlink=rlink, boxsize=boxsize, alloc_fac_ilist=cfg.alloc_fac_ilist,
        size_links=int(cfg.alloc_fac_distr_links * len(posz))
    )

    labels = _distr_fof_leaf2leaf(node_data, ilist, link_data, posz, rlink=rlink, boxsize=boxsize)

    if linearize_labels:
        num = jax.lax.all_gather(jnp.sum(~jnp.isnan(posz[...,0]), axis=0), axis_name)
        dspl = cumsum_starting_with_zero(num)
        igroup = dspl[labels.irank] + labels.igroup

        return partz, igroup
    else:
        return partz, labels
distr_fof_labels.smap = shard_map_constructor(distr_fof_labels,
    in_specs=(P(-1), None, None, None, P(-1), None),
    static_argnames=["cfg", "rlink", "boxsize", "linearize_labels"]
)

def fof_and_catalogue(
        part: ParticleData,
        rlink: float,
        boxsize: float=0.,
        cfg: FofConfig = FofConfig(),
        th: TreeHierarchy | None = None
    ) -> Tuple[ParticleData, FofCatalogue]:
    """Puts particles in FoF-order and calculates the FoF-catalogue
    
    Supports single- and multi-GPU.

    Args:
        part: particles, should follow at least the interface of :class:`jztree.data.Pos`
            and may optionally contain additional elments as in 
            :class:`jztree.data.ParticleData` for calculating additional data in the
            catalogue. For multi-GPU, particles need to be padded to allow space for
            communication.
        rlink: (absolute) linking length
        boxsize: if provided, distances use periodic wrapping
        cfg: controls low-level details
        th: May be provided to skip building a new tree-hierarchy inside of this function.
            See :func:`jztree.tree.zsort_and_tree`. If this argument is provided, particles 
            are assumed to be already in z-order.
    Returns:
        (partf, catalogue) -- particles in FoF-order and the group catalogue. Each group
        forms a continous segment in the particle array, but the last group on each
        rank may continue on the next rank.
    """
    rank, ndev, axis_name = get_rank_info()
    
    if ndev == 1:
        partz, igroup = fof_labels(part, rlink=rlink, th=th, boxsize=boxsize, cfg=cfg)
        partf, counts = _fof_order(igroup, partz)
    else:
        partz, labels = distr_fof_labels(part, rlink=rlink, boxsize=boxsize, cfg=cfg, th=th)
        partf, counts = _distr_fof_order(labels, partz)
    
    catalogue = _fof_catalogue_from_groups(partf, counts, cfg.catalogue, boxsize=boxsize)

    return partf, catalogue
fof_and_catalogue.jit = jax.jit(fof_and_catalogue,
    static_argnames=["rlink", "boxsize", "cfg"]
)
fof_and_catalogue.smap = shard_map_constructor(fof_and_catalogue,
    in_specs=(P(-1), None, None, None, P(-1)),
    static_argnames=["rlink", "boxsize", "cfg"]
)