# dargslan-grub-check

**GRUB Bootloader Configuration Checker** — Audit boot entries, installed kernels, UEFI/Secure Boot status, and bootloader security. Zero external dependencies.

[![PyPI version](https://img.shields.io/pypi/v/dargslan-grub-check)](https://pypi.org/project/dargslan-grub-check/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Installation

```bash
pip install dargslan-grub-check
```

## CLI Usage

```bash
dargslan-grub report           # Full bootloader report
dargslan-grub entries          # Boot menu entries
dargslan-grub kernels          # Installed kernels
dargslan-grub defaults         # GRUB default settings
dargslan-grub mode             # UEFI/BIOS and Secure Boot
dargslan-grub issues           # Configuration issues
dargslan-grub json             # JSON output
```

## Python API

```python
from dargslan_grub_check import GrubCheck
gc = GrubCheck()
entries = gc.get_boot_entries()
kernels = gc.get_installed_kernels()
gc.print_report()
```

## More from Dargslan

- [Dargslan.com](https://dargslan.com) — Linux & DevOps eBook Store
- [Free Cheat Sheets](https://dargslan.com/cheat-sheets)
- [Blog & Tutorials](https://dargslan.com/blog)

## License

MIT — see [LICENSE](LICENSE)
