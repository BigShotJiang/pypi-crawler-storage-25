"""CLI for dargslan-grub-check — https://dargslan.com"""
import argparse

def main():
    parser = argparse.ArgumentParser(
        description="Dargslan GRUB Check — GRUB bootloader configuration checker",
        epilog="More tools at https://dargslan.com | eBooks: https://dargslan.com/books",
    )
    parser.add_argument("command", nargs="?", default="report",
                       choices=["report", "entries", "kernels", "defaults", "mode", "issues", "json"],
                       help="Command (default: report)")
    args = parser.parse_args()

    from dargslan_grub_check import GrubCheck
    gc = GrubCheck()
    import json

    if args.command == 'report': gc.print_report()
    elif args.command == 'entries':
        for e in gc.get_boot_entries(): print(f"  {e['title'][:60]}")
    elif args.command == 'kernels':
        for k in gc.get_installed_kernels():
            active = ' [RUNNING]' if k.get('running') else ''
            print(f"  {k['version']}{active}")
    elif args.command == 'defaults':
        for k, v in gc.get_grub_defaults().items(): print(f"  {k}={v}")
    elif args.command == 'mode':
        print(f"  Boot: {gc.check_boot_mode()}")
        sb = gc.check_secure_boot()
        if sb is not None: print(f"  Secure Boot: {'Yes' if sb else 'No'}")
        print(f"  Kernel: {gc.get_running_kernel()}")
    elif args.command == 'issues':
        for i in gc.audit(): print(f"  [{i['severity'].upper()}] {i['message']}")
    elif args.command == 'json': print(json.dumps(gc.audit(), indent=2))

if __name__ == "__main__": main()
