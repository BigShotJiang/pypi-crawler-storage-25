"""
dargslan-grub-check — GRUB Bootloader Configuration Checker

Audit boot entries, kernel versions, and bootloader security settings.
Zero external dependencies — parses GRUB config files directly.

Homepage: https://dargslan.com
Books: https://dargslan.com/books
Blog: https://dargslan.com/blog
"""

__version__ = "1.0.0"
__author__ = "Dargslan"
__url__ = "https://dargslan.com"

import os
import re
import subprocess
import json


class GrubCheck:
    """Check GRUB bootloader configuration and security."""

    def __init__(self):
        self.config_paths = [
            '/boot/grub/grub.cfg',
            '/boot/grub2/grub.cfg',
            '/etc/default/grub',
            '/boot/efi/EFI/ubuntu/grub.cfg',
            '/boot/efi/EFI/centos/grub.cfg',
            '/boot/efi/EFI/fedora/grub.cfg',
        ]

    def _read_file(self, path):
        try:
            with open(path, 'r') as f:
                return f.read()
        except (FileNotFoundError, PermissionError):
            return ''

    def _run(self, args):
        try:
            result = subprocess.run(args, capture_output=True, text=True, timeout=10)
            return result.stdout.strip() if result.returncode == 0 else ''
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return ''

    def find_config(self):
        found = {}
        for path in self.config_paths:
            if os.path.exists(path):
                found[path] = os.path.getsize(path)
        return found

    def get_grub_defaults(self):
        content = self._read_file('/etc/default/grub')
        defaults = {}
        for line in content.split('\n'):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            match = re.match(r'^(\w+)=(.*)$', line)
            if match:
                key = match.group(1)
                val = match.group(2).strip('"').strip("'")
                defaults[key] = val
        return defaults

    def get_boot_entries(self):
        entries = []
        for path in ['/boot/grub/grub.cfg', '/boot/grub2/grub.cfg']:
            content = self._read_file(path)
            if not content:
                continue

            current = None
            for line in content.split('\n'):
                line = line.strip()
                if line.startswith('menuentry '):
                    match = re.match(r"menuentry '([^']+)'", line)
                    if match:
                        current = {'title': match.group(1), 'config_file': path}
                elif current:
                    if line.startswith('linux ') or line.startswith('linuxefi '):
                        parts = line.split()
                        if len(parts) >= 2:
                            current['kernel'] = parts[1]
                            current['params'] = ' '.join(parts[2:])
                    elif line.startswith('initrd ') or line.startswith('initrdefi '):
                        parts = line.split()
                        if len(parts) >= 2:
                            current['initrd'] = parts[1]
                    elif line == '}':
                        entries.append(current)
                        current = None
            break
        return entries

    def get_installed_kernels(self):
        kernels = []
        boot_dir = '/boot'
        try:
            for f in sorted(os.listdir(boot_dir)):
                if f.startswith('vmlinuz-'):
                    version = f.replace('vmlinuz-', '')
                    size = os.path.getsize(os.path.join(boot_dir, f))
                    has_initrd = os.path.exists(os.path.join(boot_dir, f'initrd.img-{version}')) or \
                                 os.path.exists(os.path.join(boot_dir, f'initramfs-{version}.img'))
                    kernels.append({
                        'version': version,
                        'file': f,
                        'size_mb': round(size / 1024 / 1024, 1),
                        'has_initrd': has_initrd,
                    })
        except (FileNotFoundError, PermissionError):
            pass

        output = self._run(['uname', '-r'])
        if output:
            for k in kernels:
                k['running'] = k['version'] == output

        return kernels

    def get_running_kernel(self):
        return self._run(['uname', '-r'])

    def check_boot_mode(self):
        if os.path.isdir('/sys/firmware/efi'):
            return 'UEFI'
        return 'BIOS/Legacy'

    def check_secure_boot(self):
        try:
            sb_file = '/sys/firmware/efi/efivars/SecureBoot-8be4df61-93ca-11d2-aa0d-00e098032b8c'
            if os.path.exists(sb_file):
                with open(sb_file, 'rb') as f:
                    data = f.read()
                if len(data) >= 5 and data[4] == 1:
                    return True
            return False
        except (FileNotFoundError, PermissionError):
            return None

    def audit(self):
        issues = []

        defaults = self.get_grub_defaults()

        if 'GRUB_PASSWORD' not in str(self._read_file('/etc/default/grub')) and \
           not os.path.exists('/etc/grub.d/01_password') and \
           not os.path.exists('/boot/grub/user.cfg') and \
           not os.path.exists('/boot/grub2/user.cfg'):
            issues.append({'severity': 'info', 'message': 'GRUB password not set — anyone with physical access can modify boot parameters'})

        timeout = defaults.get('GRUB_TIMEOUT', '')
        if timeout and timeout not in ('0', '-1'):
            try:
                if int(timeout) > 10:
                    issues.append({'severity': 'info', 'message': f'GRUB timeout is {timeout}s — consider reducing for faster boot'})
            except ValueError:
                pass

        cmdline = defaults.get('GRUB_CMDLINE_LINUX_DEFAULT', '')
        if 'quiet' not in cmdline and 'splash' not in cmdline:
            issues.append({'severity': 'info', 'message': 'Boot messages are verbose — add quiet/splash for cleaner boot'})

        kernels = self.get_installed_kernels()
        if len(kernels) > 5:
            issues.append({'severity': 'info', 'message': f'{len(kernels)} kernel versions installed — consider cleaning old kernels'})

        for k in kernels:
            if not k.get('has_initrd'):
                issues.append({'severity': 'warning', 'message': f"Kernel {k['version']} missing initrd/initramfs"})

        boot_mode = self.check_boot_mode()
        secure_boot = self.check_secure_boot()
        if boot_mode == 'UEFI' and secure_boot is False:
            issues.append({'severity': 'info', 'message': 'UEFI system with Secure Boot disabled'})

        return issues

    def print_report(self):
        configs = self.find_config()
        defaults = self.get_grub_defaults()
        entries = self.get_boot_entries()
        kernels = self.get_installed_kernels()
        running = self.get_running_kernel()
        boot_mode = self.check_boot_mode()
        secure_boot = self.check_secure_boot()
        issues = self.audit()

        print(f"\n{'='*60}")
        print(f"  GRUB Bootloader Configuration Report")
        print(f"{'='*60}")

        print(f"\n  Boot Mode: {boot_mode}")
        if secure_boot is not None:
            print(f"  Secure Boot: {'Enabled' if secure_boot else 'Disabled'}")
        print(f"  Running Kernel: {running or 'N/A'}")

        if configs:
            print(f"\n  Config Files ({len(configs)}):")
            for path, size in configs.items():
                print(f"    {path} ({size} bytes)")

        if defaults:
            print(f"\n  GRUB Defaults:")
            for k, v in sorted(defaults.items()):
                print(f"    {k} = {v[:60]}")

        if entries:
            print(f"\n  Boot Entries ({len(entries)}):")
            for e in entries[:10]:
                print(f"    {e['title'][:50]}")
                if e.get('kernel'):
                    print(f"      Kernel: {e['kernel']}")

        if kernels:
            print(f"\n  Installed Kernels ({len(kernels)}):")
            for k in kernels:
                active = ' [RUNNING]' if k.get('running') else ''
                initrd = '' if k['has_initrd'] else ' [NO INITRD!]'
                print(f"    {k['version']} ({k['size_mb']} MB){active}{initrd}")

        if issues:
            print(f"\n  Issues ({len(issues)}):")
            for i in issues:
                print(f"    [{i['severity'].upper():8s}] {i['message']}")

        print(f"\n{'='*60}")
        print(f"  More tools: https://dargslan.com")
        print(f"  eBooks: https://dargslan.com/books")
        print(f"{'='*60}\n")


__all__ = ["GrubCheck"]
