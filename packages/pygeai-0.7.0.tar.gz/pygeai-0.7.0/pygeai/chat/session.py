from pygeai import logger
from pygeai.chat.clients import ChatClient

from pygeai.chat.settings import LLM_SETTINGS
from pygeai.core.common.exceptions import InvalidAPIResponseException


class AgentChatSession:

    def __init__(self, agent_name: str):
        self.client = ChatClient()
        self.agent_name = agent_name

    def stream_answer(self, messages):
        result = self.client.chat_completion(
            model=f"saia:agent:{self.agent_name}",
            messages=messages,
            stream=True,
            **LLM_SETTINGS
        )
        return result

    def get_answer(self, messages):
        answer = ""
        try:
            result = self.client.chat_completion(
                model=f"saia:agent:{self.agent_name}",
                messages=messages,
                stream=False,
                **LLM_SETTINGS
            )
            answer = result['choices'][0]['message']['content']
        except Exception as e:
            logger.error(f"Unable to communicate with specified agent {self.agent_name}: {e}")
            raise InvalidAPIResponseException(f"Unable to communicate with specified agent {self.agent_name}: {e}")

        return answer


class FlowChatSession:

    def __init__(self, flow_name: str):
        self.client = ChatClient()
        self.flow_name = flow_name

    def stream_answer(self, messages):
        result = self.client.chat_completion(
            model=f"saia:flow:{self.flow_name}",
            messages=messages,
            stream=True,
            **LLM_SETTINGS
        )
        return result

    def get_answer(self, messages):
        answer = ""
        try:
            result = self.client.chat_completion(
                model=f"saia:flow:{self.flow_name}",
                messages=messages,
                stream=False,
                **LLM_SETTINGS
            )
            answer = result['choices'][0]['message']['content']
        except Exception as e:
            logger.error(f"Unable to communicate with specified flow {self.flow_name}: {e}")
            raise InvalidAPIResponseException(f"Unable to communicate with specified flow {self.flow_name}: {e}")

        return answer


class AssistantChatSession:

    def __init__(self, assistant_name: str):
        self.client = ChatClient()
        self.assistant_name = assistant_name

    def stream_answer(self, messages):
        result = self.client.chat_completion(
            model=f"saia:assistant:{self.assistant_name}",
            messages=messages,
            stream=True,
            **LLM_SETTINGS
        )
        return result

    def get_answer(self, messages):
        answer = ""
        try:
            result = self.client.chat_completion(
                model=f"saia:assistant:{self.assistant_name}",
                messages=messages,
                stream=False,
                **LLM_SETTINGS
            )
            answer = result['choices'][0]['message']['content']
        except Exception as e:
            logger.error(f"Unable to communicate with specified assistant {self.assistant_name}: {e}")
            raise InvalidAPIResponseException(f"Unable to communicate with specified assistant {self.assistant_name}: {e}")

        return answer


class SearchChatSession:

    def __init__(self, search_name: str):
        self.client = ChatClient()
        self.search_name = search_name

    def stream_answer(self, messages):
        result = self.client.chat_completion(
            model=f"saia:search:{self.search_name}",
            messages=messages,
            stream=True,
            **LLM_SETTINGS
        )
        return result

    def get_answer(self, messages):
        answer = ""
        try:
            result = self.client.chat_completion(
                model=f"saia:search:{self.search_name}",
                messages=messages,
                stream=False,
                **LLM_SETTINGS
            )
            answer = result['choices'][0]['message']['content']
        except Exception as e:
            logger.error(f"Unable to communicate with specified search assistant {self.search_name}: {e}")
            raise InvalidAPIResponseException(f"Unable to communicate with specified search assistant {self.search_name}: {e}")

        return answer

