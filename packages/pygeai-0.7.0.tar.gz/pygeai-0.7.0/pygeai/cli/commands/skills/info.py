from pygeai.cli.commands import Option
from pygeai.cli.commands.skills.utils import display_skill_details
from pygeai.core.common.exceptions import MissingRequirementException
from pygeai.core.utils.console import Console
from pygeai.skills import SkillsEngine


def skill_info(option_list: list = None):
    """Show detailed information about a specific skill."""
    opts = {opt.name: arg for opt, arg in option_list} if option_list else {}

    skill_name = opts.get("skill")

    if not skill_name:
        raise MissingRequirementException(
            "Skill name is required. Use --skill <name>"
        )

    engine = SkillsEngine()
    skill = engine.get_skill(skill_name)

    if not skill:
        Console.write_error(f"Skill '{skill_name}' not found")
        Console.write_stdout("\nAvailable skills:")
        skills = engine.list_builtin_skills()
        for s in skills:
            Console.write_stdout(f"  - {s.name}")
        return

    display_skill_details(skill)


info_options = [
    Option("skill", ["--skill", "-s"], "Skill name", True),
]
