from pygeai.cli.commands import Option
from pygeai.cli.commands.skills.utils import display_skills_table
from pygeai.core.utils.console import Console
from pygeai.skills import SkillsEngine


def list_skills(option_list: list = None):
    """List available GEAI skills."""
    opts = {opt.name: arg for opt, arg in option_list} if option_list else {}

    engine = SkillsEngine()
    category = opts.get("category")

    skills = engine.list_builtin_skills(category=category)

    if not skills:
        if category:
            Console.write_stdout(f"No skills found in category '{category}'")
        else:
            Console.write_stdout("No skills available")
        return

    display_skills_table(skills, show_category=(category is None))

    Console.write_stdout(f"Total: {len(skills)} skill(s)")


list_options = [
    Option(
        "category",
        ["--category", "-c"],
        "Filter by category (cli, agent, tool, process, rag, core, evaluation, advanced)",
        True,
    ),
]
