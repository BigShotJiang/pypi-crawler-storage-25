from pygeai.cli.commands import ArgumentsEnum, Command
from pygeai.cli.commands.builders import build_help_text
from pygeai.cli.commands.skills.create import create_options, create_skill
from pygeai.cli.commands.skills.info import info_options, skill_info
from pygeai.cli.commands.skills.install import install_options, install_skill
from pygeai.cli.commands.skills.list_cmd import list_options, list_skills
from pygeai.cli.commands.skills.setup import setup_options, setup_skills
from pygeai.cli.commands.skills.validate import validate_options, validate_skill
from pygeai.core.utils.console import Console

SKILLS_HELP_TEXT = """GEAI CLI - SKILLS
-----------------

Manage agent skills for AI coding assistants.

Skills are modular instructions that enable AI coding agents (OpenCode, Claude Code,
Codex, Cursor, Coda-CLI) to effectively use PyGEAI SDK features.

Skills follow the Agent Skills standard (agentskills.io) with SKILL.md files
containing YAML frontmatter and markdown instructions.

USAGE
  geai skills <command> [options]

EXAMPLES
  # Interactive setup wizard
  geai skills setup

  # Install all skills to specific agents
  geai skills setup --agent claude-code,codex --skills all

  # List all available skills
  geai skills list

  # List skills by category
  geai skills list --category agent

  # Show skill details
  geai skills info --skill geai-agent-creator

  # Install single skill
  geai skills install --skill geai-cli-expert --agent coda-cli

  # Create new skill
  geai skills create --name my-skill --description "My custom skill"

  # Validate skill
  geai skills validate --path ./my-skill/

SKILL CATEGORIES
  cli          - CLI commands and configuration
  agent        - Agent development and management
  tool         - Tool development and management
  process      - Agentic process design and execution
  rag          - RAG assistants and document knowledge
  core         - Core services (LLM, embeddings, files, secrets)
  evaluation   - Evaluation and analytics
  advanced     - Advanced features (omni parsing, templates)
"""


def show_help():
    """Display help text for skills command."""
    help_text = build_help_text(skills_commands, SKILLS_HELP_TEXT)
    Console.write_stdout(help_text)


skills_commands = [
    Command(
        "help",
        ["help", "h"],
        "Display help for skills command",
        show_help,
        ArgumentsEnum.NOT_AVAILABLE,
        [],
        [],
    ),
    Command(
        "setup",
        ["setup", "init"],
        "Setup skills for coding agents (interactive wizard)",
        setup_skills,
        ArgumentsEnum.OPTIONAL,
        [],
        setup_options,
    ),
    Command(
        "list",
        ["list", "ls"],
        "List available GEAI skills",
        list_skills,
        ArgumentsEnum.OPTIONAL,
        [],
        list_options,
    ),
    Command(
        "install",
        ["install", "add"],
        "Install a skill to coding agent(s)",
        install_skill,
        ArgumentsEnum.OPTIONAL,
        [],
        install_options,
    ),
    Command(
        "info",
        ["info", "show"],
        "Show detailed skill information",
        skill_info,
        ArgumentsEnum.OPTIONAL,
        [],
        info_options,
    ),
    Command(
        "create",
        ["create", "new"],
        "Create a new skill from template",
        create_skill,
        ArgumentsEnum.OPTIONAL,
        [],
        create_options,
    ),
    Command(
        "validate",
        ["validate", "check"],
        "Validate skill format and structure",
        validate_skill,
        ArgumentsEnum.OPTIONAL,
        [],
        validate_options,
    ),
]

__all__ = ["skills_commands", "show_help"]
