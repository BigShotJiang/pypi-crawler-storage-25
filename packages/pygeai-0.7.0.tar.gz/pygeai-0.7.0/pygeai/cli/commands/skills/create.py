from pathlib import Path

from pygeai.cli.commands import Option
from pygeai.core.common.exceptions import MissingRequirementException
from pygeai.core.utils.console import Console


def create_skill(option_list: list = None):
    """Create a new skill from template."""
    opts = {opt.name: arg for opt, arg in option_list} if option_list else {}

    name = opts.get("name")
    description = opts.get("description")
    output = opts.get("output", f"./{name}") if name else None

    if not name:
        raise MissingRequirementException("Skill name is required. Use --name <name>")

    if not description:
        raise MissingRequirementException(
            "Description is required. Use --description <text>"
        )

    output_path = Path(output)
    if output_path.exists():
        Console.write_error(f"Output directory already exists: {output}")
        return

    output_path.mkdir(parents=True)

    category = opts.get("category", "other")
    author = opts.get("author", "custom")
    version = opts.get("version", "1.0.0")
    license_type = opts.get("license", "Apache-2.0")

    skill_md_content = f"""---
name: {name}
description: {description}
license: {license_type}
metadata:
  author: {author}
  version: "{version}"
  category: {category}
allowed-tools: pygeai
---

# {name.replace('-', ' ').title()}

{description}

## When to Use This Skill

Describe when developers should use this skill...

## Key Topics

- Topic 1
- Topic 2
- Topic 3

## Using PyGEAI SDK

### Example

```python
from pygeai import ...

# Your example code here
```

### CLI Usage

```bash
geai ...
```

## Best Practices

1. Best practice 1
2. Best practice 2

## References

- [PyGEAI Documentation](https://docs.globant.ai)
"""

    (output_path / "SKILL.md").write_text(skill_md_content)

    (output_path / "scripts").mkdir()
    (output_path / "references").mkdir()
    (output_path / "assets").mkdir()

    (output_path / "scripts" / ".gitkeep").touch()
    (output_path / "references" / ".gitkeep").touch()
    (output_path / "assets" / ".gitkeep").touch()

    Console.write_success(f"\n✓ Created skill '{name}' at {output_path}")
    Console.write_stdout("\nCreated structure:")
    Console.write_stdout(f"  {output_path}/")
    Console.write_stdout("    SKILL.md")
    Console.write_stdout("    scripts/")
    Console.write_stdout("    references/")
    Console.write_stdout("    assets/")
    Console.write_stdout("\nNext steps:")
    Console.write_stdout(f"  1. Edit {output_path}/SKILL.md with skill instructions")
    Console.write_stdout(f"  2. Add scripts to scripts/ directory")
    Console.write_stdout(f"  3. Add reference docs to references/ directory")
    Console.write_stdout(f"  4. Validate: geai skills validate --path {output_path}\n")


create_options = [
    Option("name", ["--name", "-n"], "Skill name (lowercase-with-hyphens)", True),
    Option("description", ["--description", "-d"], "Skill description", True),
    Option("output", ["--output", "-o"], "Output directory", True),
    Option(
        "category",
        ["--category", "-c"],
        "Skill category (cli, agent, tool, process, rag, core, evaluation, advanced)",
        True,
    ),
    Option("author", ["--author"], "Author name", True),
    Option("version", ["--version"], "Version (default: 1.0.0)", True),
    Option("license", ["--license"], "License (default: Apache-2.0)", True),
]
