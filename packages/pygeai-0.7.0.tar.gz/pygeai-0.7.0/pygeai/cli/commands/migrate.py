from typing import Tuple, Dict, Any, Optional, List
from pygeai import logger
from pygeai.cli.commands import Command, Option, ArgumentsEnum
from pygeai.cli.commands.builders import build_help_text
from pygeai.cli.texts.help import MIGRATE_HELP_TEXT
from pygeai.core.common.exceptions import MissingRequirementException
from pygeai.core.utils.console import Console
from pygeai.lab.managers import AILabManager
from pygeai.lab.models import FilterSettings

from pygeai.assistant.rag.clients import RAGAssistantClient
from pygeai.assistant.rag.mappers import RAGAssistantMapper
from pygeai.core.files.managers import FileManager
from pygeai.core.secrets.clients import SecretClient
from pygeai.migration.strategies import (
    ProjectMigrationStrategy,
    AgentMigrationStrategy,
    ToolMigrationStrategy,
    IntegrationMigrationStrategy,
    AgenticProcessMigrationStrategy,
    TaskMigrationStrategy,
    ArtifactTypeMigrationStrategy,
    UsageLimitMigrationStrategy,
    RAGAssistantMigrationStrategy,
    FileMigrationStrategy,
    SecretMigrationStrategy
)
from pygeai.migration.tools import MigrationTool, MigrationPlan, MigrationOrchestrator
from pygeai.migration.comparison import ProjectComparator, DiffFormatter
from pygeai.admin.clients import AdminClient


def show_help() -> None:
    """
    Displays help text in stdout.
    """
    help_text = build_help_text(migrate_commands, MIGRATE_HELP_TEXT)
    Console.write_stdout(help_text)


def prompt_with_retry(
    prompt_message: str,
    valid_choices: Optional[list] = None,
    allow_empty: bool = False
) -> str:
    """
    Prompt user for input with validation and retry logic.
    
    :param prompt_message: Message to display when prompting
    :param valid_choices: Optional list of valid input choices
    :param allow_empty: Whether to allow empty input
    :return: User's validated input string
    """
    while True:
        user_input = input(prompt_message).strip()
        
        if not user_input and not allow_empty:
            Console.write_stdout("Error: Input cannot be empty. Please try again.")
            continue
        
        if valid_choices and user_input not in valid_choices:
            Console.write_stdout(f"Error: Invalid choice '{user_input}'. Valid options: {', '.join(valid_choices)}")
            continue
        
        return user_input


def prompt_resource_selection(
    resource_type: str,
    items: list,
    id_field: str = "id",
    name_field: str = "name"
) -> Optional[str]:
    """
    Display a list of resources and let the user select which ones to migrate.
    
    :param resource_type: Type of resource being selected (for display purposes)
    :param items: List of resource items to display
    :param id_field: Name of the attribute containing the resource ID
    :param name_field: Name of the attribute containing the resource name
    :return: Comma-separated string of selected IDs, 'all' for all resources, or None to cancel
    """
    if not items:
        Console.write_stdout(f"No {resource_type} found.")
        return None
    
    Console.write_stdout(f"\nAvailable {resource_type}:")
    Console.write_stdout("  0. Cancel (don't migrate this resource type)")
    
    for idx, item in enumerate(items, 1):
        item_id = getattr(item, id_field, None)
        item_name = getattr(item, name_field, None) if hasattr(item, name_field) else None
        if item_name:
            Console.write_stdout(f"  {idx}. {item_name} (ID: {item_id})")
        else:
            Console.write_stdout(f"  {idx}. {item_id}")
    
    while True:
        selection = input(f"\nSelect {resource_type} (comma-separated numbers, or empty for all): ").strip()
        
        if not selection:
            return "all"
        
        if selection == "0":
            return None
        
        try:
            indices = [int(x.strip()) for x in selection.split(",")]
            if any(i < 0 or i > len(items) for i in indices):
                Console.write_stdout(f"Error: Invalid selection. Numbers must be between 0 and {len(items)}.")
                continue
            
            if 0 in indices:
                return None
            
            selected_ids = [getattr(items[i-1], id_field) for i in indices]
            return ",".join(str(sid) for sid in selected_ids)
        except (ValueError, IndexError):
            Console.write_stdout("Error: Invalid input format. Please enter comma-separated numbers.")
            continue


def get_source_configuration() -> Tuple[str, str, str, Optional[str]]:
    """
    Prompt user for source configuration and retrieve organization ID.
    
    :return: Tuple of (api_key, instance_url, project_id, organization_id)
    """
    Console.write_stdout("\n--- Source Configuration ---")
    from_api_key = prompt_with_retry("Source API key: ")
    from_instance = prompt_with_retry("Source instance URL: ")
    from_project_id = prompt_with_retry("Source project ID: ")
    
    admin_client = AdminClient(api_key=from_api_key, base_url=from_instance)
    source_token_info = admin_client.validate_api_token()
    from_organization_id = source_token_info.get("organizationId")
    
    return from_api_key, from_instance, from_project_id, from_organization_id


def get_destination_configuration(
    same_instance: bool,
    from_instance: str,
    from_api_key: str,
    from_organization_id: Optional[str],
    creating_project: bool
) -> Tuple[str, Optional[str], Optional[str]]:
    """
    Configure destination instance settings based on migration type.
    
    :param same_instance: Whether migration is within the same instance
    :param from_instance: Source instance URL
    :param from_api_key: Source API key
    :param from_organization_id: Source organization ID
    :param creating_project: Whether a new project will be created
    :return: Tuple of (instance_url, api_key, organization_id)
    """
    if same_instance:
        to_instance = from_instance
        to_organization_id = from_organization_id
        Console.write_stdout(f"Destination instance: {to_instance} (same as source)")
        Console.write_stdout(f"Destination organization ID: {to_organization_id} (same as source)")
        
        if creating_project:
            to_api_key = None
            Console.write_stdout("Destination API key: (will be created after project creation)")
        else:
            to_api_key = prompt_with_retry("Destination API key: ")
    else:
        Console.write_stdout("\n--- Destination Configuration ---")
        to_instance = prompt_with_retry("Destination instance URL: ")
        
        if creating_project:
            to_api_key = None
            to_organization_id = None
            Console.write_stdout("Destination API key: (will be created after project creation)")
            Console.write_stdout("Destination organization ID: (will be retrieved after project creation)")
        else:
            to_api_key = prompt_with_retry("Destination API key: ")
            dest_admin_client = AdminClient(api_key=to_api_key, base_url=to_instance)
            dest_token_info = dest_admin_client.validate_api_token()
            to_organization_id = dest_token_info.get("organizationId")
    
    return to_instance, to_api_key, to_organization_id


def get_project_creation_info(same_instance: bool) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str], Optional[str]]:
    """
    Prompt user for project creation information.
    
    :param same_instance: Whether migration is within the same instance
    :return: Tuple of (from_org_api_key, to_org_api_key, project_name, admin_email, project_id)
    """
    create_project = prompt_with_retry(
        "Create new destination project? (y/n): ",
        valid_choices=["y", "n"]
    )
    
    from_organization_api_key = None
    to_organization_api_key = None
    to_project_name = None
    admin_email = None
    to_project_id = None
    
    if create_project == "y":
        from_organization_api_key = prompt_with_retry("Source organization API key: ")
        if same_instance:
            to_organization_api_key = from_organization_api_key
            Console.write_stdout("Destination organization API key: (same as source)")
        else:
            to_organization_api_key = prompt_with_retry("Destination organization API key: ")
        to_project_name = prompt_with_retry("New project name: ")
        admin_email = prompt_with_retry("Admin email: ")
    else:
        to_project_id = prompt_with_retry("Destination project ID: ")
    
    return from_organization_api_key, to_organization_api_key, to_project_name, admin_email, to_project_id


def select_resource_types() -> List[int]:
    """
    Prompt user to select which resource types to migrate.
    
    :return: List of integers representing selected resource types (1-10)
    """
    Console.write_stdout("\n--- Resource Type Selection ---")
    Console.write_stdout("Which resource types do you want to migrate?")
    Console.write_stdout("  1. Agents")
    Console.write_stdout("  2. Integrations (recommended - migrates tool plugins with all their tools)")
    Console.write_stdout("  3. Tools (individual - only use if not migrating their parent integrations)")
    Console.write_stdout("  4. Agentic Processes")
    Console.write_stdout("  5. Tasks")
    Console.write_stdout("  6. Artifact Types")
    Console.write_stdout("  7. RAG Assistants")
    Console.write_stdout("  8. Files")
    Console.write_stdout("  9. Usage Limits")
    Console.write_stdout("  10. Secrets")
    
    while True:
        resource_choice = input("\nSelect resource types (comma-separated numbers, or empty for all): ").strip()
        if not resource_choice:
            return [1, 2, 4, 5, 6, 7, 8, 9, 10]  # Default includes integrations but not individual tools
        try:
            resource_types = [int(x.strip()) for x in resource_choice.split(",")]
            if any(i < 1 or i > 10 for i in resource_types):
                Console.write_stdout("Error: Invalid selection. Numbers must be between 1 and 10.")
                continue
            # Warn if both integrations and individual tools are selected
            if 2 in resource_types and 3 in resource_types:
                Console.write_stdout("Warning: Selecting both integrations (2) and tools (3) may cause duplicates.")
                Console.write_stdout("Recommendation: Use integrations (2) only - it includes all tools.")
            return resource_types
        except ValueError:
            Console.write_stdout("Error: Invalid input format. Please enter comma-separated numbers.")
            continue


def fetch_and_select_agents(lab_manager: AILabManager) -> Optional[str]:
    """
    Fetch and prompt user to select agents for migration.
    
    :param lab_manager: AI Lab manager instance
    :return: Comma-separated IDs, 'all', or None
    """
    try:
        agent_list = lab_manager.get_agent_list(FilterSettings(count=1000))
        agents = [a for a in agent_list.agents if a.id]
        if agents:
            selection = prompt_resource_selection("agents", agents, id_field="id", name_field="name")
            return selection
    except Exception as e:
        Console.write_stdout(f"Warning: Could not retrieve agents: {e}")
    return None


def fetch_and_select_integrations(lab_manager: AILabManager) -> Optional[str]:
    """
    Fetch and prompt user to select integrations for migration.
    
    :param lab_manager: AI Lab manager instance
    :return: Comma-separated IDs, 'all', or None
    """
    try:
        integration_list = lab_manager.list_integrations(FilterSettings(count=1000, access_scope="private"))
        integrations = [i for i in integration_list.plugins if i.id]
        if integrations:
            selection = prompt_resource_selection("integrations", integrations, id_field="id", name_field="name")
            return selection
    except Exception as e:
        Console.write_stdout(f"Warning: Could not retrieve integrations: {e}")
    return None


def fetch_and_select_tools(lab_manager: AILabManager) -> Optional[str]:
    """
    Fetch and prompt user to select tools for migration.
    
    :param lab_manager: AI Lab manager instance
    :return: Comma-separated IDs, 'all', or None
    """
    try:
        tool_list = lab_manager.list_tools(FilterSettings(count=1000))
        tools = [t for t in tool_list.tools if t.id]
        if tools:
            selection = prompt_resource_selection("tools", tools, id_field="id", name_field="name")
            return selection
    except Exception as e:
        Console.write_stdout(f"Warning: Could not retrieve tools: {e}")
    return None


def fetch_and_select_processes(lab_manager: AILabManager) -> Optional[str]:
    """
    Fetch and prompt user to select processes for migration.
    
    :param lab_manager: AI Lab manager instance
    :return: Comma-separated IDs, 'all', or None
    """
    try:
        process_list = lab_manager.list_processes(FilterSettings(count=1000))
        processes = [p for p in process_list.processes if p.id]
        if processes:
            selection = prompt_resource_selection("agentic processes", processes, id_field="id", name_field="name")
            return selection
    except Exception as e:
        Console.write_stdout(f"Warning: Could not retrieve agentic processes: {e}")
    return None


def fetch_and_select_tasks(lab_manager: AILabManager) -> Optional[str]:
    """
    Fetch and prompt user to select tasks for migration.
    
    :param lab_manager: AI Lab manager instance
    :return: Comma-separated IDs, 'all', or None
    """
    try:
        task_list = lab_manager.list_tasks(FilterSettings(count=1000))
        tasks = [t for t in task_list.tasks if t.id]
        if tasks:
            selection = prompt_resource_selection("tasks", tasks, id_field="id", name_field="name")
            return selection
    except Exception as e:
        Console.write_stdout(f"Warning: Could not retrieve tasks: {e}")
    return None


def fetch_and_select_artifact_types(lab_manager: AILabManager) -> Optional[str]:
    """
    Fetch and prompt user to select artifact types for migration.
    
    :param lab_manager: AI Lab manager instance
    :return: Comma-separated IDs, 'all', or None
    """
    try:
        artifact_type_list = lab_manager.list_artifact_types(FilterSettings(count=1000))
        artifact_types = [at for at in artifact_type_list.artifact_types if at.id]
        if artifact_types:
            selection = prompt_resource_selection("artifact types", artifact_types, id_field="id", name_field="name")
            return selection
    except Exception as e:
        Console.write_stdout(f"Warning: Could not retrieve artifact types: {e}")
    return None


def fetch_and_select_rag_assistants(from_api_key: str, from_instance: str) -> Optional[str]:
    """
    Fetch and prompt user to select RAG assistants for migration.
    
    :param from_api_key: Source API key
    :param from_instance: Source instance URL
    :return: Comma-separated names, 'all', or None
    """
    try:
        rag_client = RAGAssistantClient(api_key=from_api_key, base_url=from_instance)
        assistant_data = rag_client.get_assistants_from_project()
        assistants_raw = assistant_data.get("assistants", [])
        assistant_list = [RAGAssistantMapper.map_to_rag_assistant(a) for a in assistants_raw] if assistants_raw else []
        if assistant_list:
            selection = prompt_resource_selection("RAG assistants", assistant_list, id_field="name", name_field="name")
            return selection
    except Exception as e:
        Console.write_stdout(f"Warning: Could not retrieve RAG assistants: {e}")
    return None


def fetch_and_select_files(
    from_api_key: str,
    from_instance: str,
    from_organization_id: str,
    from_project_id: str
) -> Optional[str]:
    """
    Fetch and prompt user to select files for migration.
    
    :param from_api_key: Source API key
    :param from_instance: Source instance URL
    :param from_organization_id: Source organization ID
    :param from_project_id: Source project ID
    :return: Comma-separated file IDs, 'all', or None
    """
    try:
        file_manager = FileManager(
            api_key=from_api_key,
            base_url=from_instance,
            organization_id=from_organization_id,
            project_id=from_project_id
        )
        file_list_response = file_manager.get_file_list()
        files = [f for f in file_list_response.files if f.id]
        if files:
            selection = prompt_resource_selection("files", files, id_field="id", name_field="filename")
            return selection
    except Exception as e:
        Console.write_stdout(f"Warning: Could not retrieve files: {e}")
    return None


def fetch_and_select_secrets(from_api_key: str, from_instance: str) -> Optional[str]:
    """
    Fetch and prompt user to select secrets for migration.
    
    :param from_api_key: Source API key
    :param from_instance: Source instance URL
    :return: Comma-separated secret IDs, 'all', or None
    """
    try:
        secret_client = SecretClient(api_key=from_api_key, base_url=from_instance)
        secrets_data = secret_client.list_secrets(count=1000)
        secrets_list = secrets_data.get("secrets", []) if isinstance(secrets_data, dict) else []
        
        if secrets_list:
            secrets_objects = [type('obj', (object,), {'id': s.get('id'), 'name': s.get('name')})() 
                             for s in secrets_list if s.get('id')]
            selection = prompt_resource_selection("secrets", secrets_objects, id_field="id", name_field="name")
            return selection
    except Exception as e:
        Console.write_stdout(f"Warning: Could not retrieve secrets: {e}")
    return None


def handle_usage_limits_keys(
    same_instance: bool,
    from_organization_api_key: Optional[str],
    to_organization_api_key: Optional[str]
) -> Tuple[str, str]:
    """
    Ensure organization API keys are available for usage limits migration.
    
    :param same_instance: Whether migration is within the same instance
    :param from_organization_api_key: Source organization API key (may be None)
    :param to_organization_api_key: Destination organization API key (may be None)
    :return: Tuple of (from_org_api_key, to_org_api_key)
    """
    if not from_organization_api_key:
        from_organization_api_key = prompt_with_retry("Source organization API key (required for usage limits): ")
    if same_instance:
        to_organization_api_key = from_organization_api_key
    elif not to_organization_api_key:
        to_organization_api_key = prompt_with_retry("Destination organization API key (required for usage limits): ")
    
    return from_organization_api_key, to_organization_api_key


def show_summary_and_confirm(
    from_instance: str,
    from_project_id: str,
    to_instance: str,
    to_project_name: Optional[str],
    to_project_id: Optional[str],
    selected_resources: Dict[str, Any]
) -> Tuple[bool, bool]:
    """
    Display migration summary and prompt user for confirmation and error handling preference.
    
    :param from_instance: Source instance URL
    :param from_project_id: Source project ID
    :param to_instance: Destination instance URL
    :param to_project_name: Destination project name (if creating new project)
    :param to_project_id: Destination project ID (if using existing project)
    :param selected_resources: Dictionary of selected resources to migrate
    :return: Tuple of (confirmation, stop_on_error) - whether user confirmed migration and whether to stop on errors
    """
    Console.write_stdout("\n--- Migration Summary ---")
    Console.write_stdout(f"Source: {from_instance} / Project: {from_project_id}")
    Console.write_stdout(f"Destination: {to_instance} / Project: {to_project_name or to_project_id}")
    Console.write_stdout(f"Resources: {', '.join(selected_resources.keys()) if selected_resources else 'None'}")
    Console.write_stdout("")
    
    stop_on_error_response = prompt_with_retry("Stop migration on first error? (Y/n): ", valid_choices=["y", "n", "Y", "N", ""])
    stop_on_error = stop_on_error_response.lower() != "n"
    
    confirm = prompt_with_retry("Proceed with migration? (y/n): ", valid_choices=["y", "n"])
    return confirm == "y", stop_on_error


def build_option_list_and_execute(
    from_api_key: str,
    from_instance: str,
    from_project_id: str,
    from_organization_id: Optional[str],
    from_organization_api_key: Optional[str],
    to_api_key: Optional[str],
    to_instance: str,
    to_project_id: Optional[str],
    to_organization_id: Optional[str],
    to_organization_api_key: Optional[str],
    to_project_name: Optional[str],
    admin_email: Optional[str],
    selected_resources: Dict[str, Any],
    stop_on_error: bool
) -> None:
    """
    Build option list from interactive mode selections and execute migration.
    
    :param from_api_key: Source API key
    :param from_instance: Source instance URL
    :param from_project_id: Source project ID
    :param from_organization_id: Source organization ID
    :param from_organization_api_key: Source organization API key
    :param to_api_key: Destination API key
    :param to_instance: Destination instance URL
    :param to_project_id: Destination project ID
    :param to_organization_id: Destination organization ID
    :param to_organization_api_key: Destination organization API key
    :param to_project_name: New project name (if creating)
    :param admin_email: Admin email (if creating project)
    :param selected_resources: Dictionary of selected resources to migrate
    :param stop_on_error: Whether to stop migration on first error
    """
    option_list = []
    option_list.append((type('obj', (object,), {'name': 'from_api_key'})(), from_api_key))
    option_list.append((type('obj', (object,), {'name': 'from_instance'})(), from_instance))
    option_list.append((type('obj', (object,), {'name': 'from_project_id'})(), from_project_id))
    option_list.append((type('obj', (object,), {'name': 'from_organization_api_key'})(), from_organization_api_key))
    
    if from_organization_id:
        option_list.append((type('obj', (object,), {'name': 'from_organization_id'})(), from_organization_id))
    
    option_list.append((type('obj', (object,), {'name': 'to_api_key'})(), to_api_key))
    option_list.append((type('obj', (object,), {'name': 'to_instance'})(), to_instance))
    option_list.append((type('obj', (object,), {'name': 'to_organization_api_key'})(), to_organization_api_key))
    
    if to_project_id:
        option_list.append((type('obj', (object,), {'name': 'to_project_id'})(), to_project_id))
    if to_project_name:
        option_list.append((type('obj', (object,), {'name': 'to_project_name'})(), to_project_name))
    if admin_email:
        option_list.append((type('obj', (object,), {'name': 'admin_email'})(), admin_email))
    if to_organization_id:
        option_list.append((type('obj', (object,), {'name': 'to_organization_id'})(), to_organization_id))
    
    for resource_type, value in selected_resources.items():
        option_list.append((type('obj', (object,), {'name': resource_type})(), value))
    
    option_list.append((type('obj', (object,), {'name': 'stop_on_error'})(), "1" if stop_on_error else "0"))
    
    clone_project(option_list)


def clone_project_interactively() -> None:
    """
    Run interactive migration wizard with step-by-step prompts for all configuration.
    """
    Console.write_stdout("")
    Console.write_stdout("=" * 80)
    Console.write_stdout("PROJECT MIGRATION ASSISTANT")
    Console.write_stdout("=" * 80)
    Console.write_stdout("")
    
    migration_type = prompt_with_retry(
        "Migration type (1=same instance, 2=cross instance): ",
        valid_choices=["1", "2"]
    )
    same_instance = migration_type == "1"
    
    from_api_key, from_instance, from_project_id, from_organization_id = get_source_configuration()
    from_organization_api_key, to_organization_api_key, to_project_name, admin_email, to_project_id = get_project_creation_info(same_instance)
    
    creating_project = bool(to_project_name and admin_email)
    to_instance, to_api_key, to_organization_id = get_destination_configuration(
        same_instance, from_instance, from_api_key, from_organization_id, creating_project
    )
    
    resource_types_to_migrate = select_resource_types()
    
    # Auto-include dependencies for Agentic Processes
    if 4 in resource_types_to_migrate:  # Agentic Processes
        if 5 not in resource_types_to_migrate:  # Tasks
            resource_types_to_migrate.append(5)
            Console.write_stdout("Note: Auto-including Tasks (required by Agentic Processes)")
        if 6 not in resource_types_to_migrate:  # Artifact Types
            resource_types_to_migrate.append(6)
            Console.write_stdout("Note: Auto-including Artifact Types (required by Agentic Processes)")
    
    Console.write_stdout("\n--- Retrieving Available Resources ---")
    lab_manager = AILabManager(api_key=from_api_key, base_url=from_instance)
    
    selected_resources = {}
    
    if 1 in resource_types_to_migrate:  # Agents
        selection = fetch_and_select_agents(lab_manager)
        if selection:
            selected_resources["agents"] = selection
    
    if 2 in resource_types_to_migrate:  # Integrations
        selection = fetch_and_select_integrations(lab_manager)
        if selection:
            selected_resources["integrations"] = selection
    
    if 3 in resource_types_to_migrate:  # Tools
        selection = fetch_and_select_tools(lab_manager)
        if selection:
            selected_resources["tools"] = selection
    
    if 4 in resource_types_to_migrate:  # Agentic Processes
        selection = fetch_and_select_processes(lab_manager)
        if selection:
            selected_resources["agentic_processes"] = selection
    
    if 5 in resource_types_to_migrate:  # Tasks
        selection = fetch_and_select_tasks(lab_manager)
        if selection:
            selected_resources["tasks"] = selection
    
    if 6 in resource_types_to_migrate:  # Artifact Types
        selection = fetch_and_select_artifact_types(lab_manager)
        if selection:
            selected_resources["artifact_types"] = selection
    
    if 7 in resource_types_to_migrate:  # RAG Assistants
        selection = fetch_and_select_rag_assistants(from_api_key, from_instance)
        if selection:
            selected_resources["rag_assistants"] = selection
    
    if 8 in resource_types_to_migrate:  # Files
        selection = fetch_and_select_files(from_api_key, from_instance, from_organization_id, from_project_id)
        if selection:
            selected_resources["files"] = selection
    
    if 9 in resource_types_to_migrate:  # Usage Limits
        from_organization_api_key, to_organization_api_key = handle_usage_limits_keys(
            same_instance, from_organization_api_key, to_organization_api_key
        )
        selected_resources["usage_limits"] = True
    
    if 10 in resource_types_to_migrate:  # Secrets
        selection = fetch_and_select_secrets(from_api_key, from_instance)
        if selection:
            selected_resources["secrets"] = selection
    
    confirmed, stop_on_error = show_summary_and_confirm(from_instance, from_project_id, to_instance, to_project_name, to_project_id, selected_resources)
    if not confirmed:
        Console.write_stdout("Migration cancelled.")
        return
    
    build_option_list_and_execute(
        from_api_key, from_instance, from_project_id, from_organization_id, from_organization_api_key,
        to_api_key, to_instance, to_project_id, to_organization_id, to_organization_api_key,
        to_project_name, admin_email, selected_resources, stop_on_error
    )


def clone_project(option_list: list) -> None:
    """
    Clone a project with selected components from source to destination instance.
    
    Supports migration of agents, tools, agentic processes, tasks, usage limits,
    RAG assistants, files, and secrets between GEAI instances.
    
    :param option_list: List of (option_flag, option_value) tuples from CLI parsing
    """
    opts = {opt.name: arg for opt, arg in option_list}
    
    if 'interactive' in opts:
        clone_project_interactively()
        return
    
    from pygeai.cli.commands.common import get_boolean_value
    
    from_api_key = opts.get('from_api_key')
    from_organization_api_key = opts.get('from_organization_api_key')
    from_instance = opts.get('from_instance')
    from_project_id = opts.get('from_project_id')
    from_organization_id = opts.get('from_organization_id')
    to_api_key = opts.get('to_api_key')
    to_organization_api_key = opts.get('to_organization_api_key')
    to_instance = opts.get('to_instance')
    to_project_id = opts.get('to_project_id')
    to_organization_id = opts.get('to_organization_id')
    to_project_name = opts.get('to_project_name')
    admin_email = opts.get('admin_email')
    
    migrate_all = 'all' in opts
    migrate_agents = 'agents' in opts
    migrate_integrations = 'integrations' in opts
    migrate_tools = 'tools' in opts
    migrate_tool_plugins = 'tool_plugins' in opts
    migrate_processes = 'agentic_processes' in opts
    migrate_tasks = 'tasks' in opts
    migrate_artifact_types = 'artifact_types' in opts
    migrate_usage_limits = 'usage_limits' in opts
    migrate_rag_assistants = 'rag_assistants' in opts
    migrate_files = 'files' in opts
    migrate_secrets = 'secrets' in opts
    
    agent_ids = opts.get('agents', 'all') if migrate_agents else None
    integration_ids = opts.get('integrations', 'all') if migrate_integrations else None
    tool_ids = opts.get('tools', 'all') if migrate_tools else None
    tool_plugin_ids = opts.get('tool_plugins', 'all') if migrate_tool_plugins else None
    process_ids = opts.get('agentic_processes', 'all') if migrate_processes else None
    task_ids = opts.get('tasks', 'all') if migrate_tasks else None
    artifact_type_ids = opts.get('artifact_types', 'all') if migrate_artifact_types else None
    assistant_names = opts.get('rag_assistants', 'all') if migrate_rag_assistants else None
    file_ids = opts.get('files', 'all') if migrate_files else None
    secret_ids = opts.get('secrets', 'all') if migrate_secrets else None
    
    stop_on_error = get_boolean_value(opts.get('stop_on_error', '1'))

    if not all([from_api_key, from_instance, from_project_id]):
        raise MissingRequirementException("Source API key, instance, and project ID are required")

    if (to_project_name or admin_email) and not (to_project_name and admin_email):
        raise MissingRequirementException(
            "Both --to-project-name and --admin-email are required when creating a new project"
        )
    
    if to_project_id and (to_project_name or admin_email):
        raise MissingRequirementException(
            "Cannot specify both --to-project-id and project creation parameters (--to-project-name, --admin-email)"
        )
    
    if not to_project_id and not (to_project_name and admin_email):
        raise MissingRequirementException(
            "Must specify either --to-project-id (for existing project) or both --to-project-name and --admin-email (to create new project)"
        )
    
    if to_project_id and not to_api_key:
        raise MissingRequirementException(
            "Destination project API key (--to-api-key) is required when migrating to an existing project (--to-project-id)"
        )
    
    if to_project_name and admin_email:
        if not from_organization_api_key:
            raise MissingRequirementException(
                "Source organization scope API key (--from-org-key) is required for project creation"
            )
        if not (to_organization_api_key or from_organization_api_key):
            raise MissingRequirementException(
                "Destination organization scope API key (--to-org-key) is required for project creation in a different "
                "instance. Alternatively source organization scope (--from-org-key) can be used if project needs to be "
                "created in the same instance."
            )

    # Validate organization scope keys for usage limits migration
    if migrate_usage_limits:
        if not from_organization_api_key:
            raise MissingRequirementException(
                "Source organization scope API key (--from-org-key) is required for usage limits migration"
            )
        if not (to_organization_api_key or from_organization_api_key):
            raise MissingRequirementException(
                "Destination organization scope API key (--to-org-key) is required for usage limits migration in a "
                "different instance. Alternatively source organization scope (--from-org-key) can be used if limits "
                "need to be migrated in the same instance."
            )

    if to_project_name and admin_email:
        Console.write_stdout(f"Creating new project '{to_project_name}'...")
        
        org_key_to_use = to_organization_api_key or from_organization_api_key
        logger.debug("DEBUG: Preparing to create project with organization API key")
        logger.debug(f"  - to_organization_api_key exists: {to_organization_api_key is not None}")
        logger.debug(f"  - from_organization_api_key exists: {from_organization_api_key is not None}")
        logger.debug(f"  - Using key (first 20 chars): {org_key_to_use[:20] if org_key_to_use else 'None'}...")
        
        project_strategy = ProjectMigrationStrategy(
            from_api_key=from_organization_api_key,
            from_instance=from_instance,
            from_project_id=from_project_id,
            to_project_name=to_project_name,
            admin_email=admin_email,
            to_api_key=org_key_to_use,
            to_instance=to_instance
        )
        project_tool = MigrationTool(project_strategy)
        to_project_id = project_tool.run_migration()
        
        if not to_project_id:
            raise ValueError("Project creation did not return a project ID")
        
        Console.write_stdout(f"Project '{to_project_name}' created successfully with ID: {to_project_id}")
        
        from pygeai.auth.clients import AuthClient
        Console.write_stdout("Creating project API key for new project...")
        
        org_key_for_token_creation = to_organization_api_key or from_organization_api_key
        auth_client = AuthClient(
            api_key=org_key_for_token_creation,
            base_url=to_instance or from_instance
        )
        
        token_response = auth_client.create_project_api_token(
            project_id=to_project_id,
            name=f"Migration API Key for {to_project_name}",
            description=f"Auto-generated API key for project migration to {to_project_name}"
        )
        
        if not token_response or 'id' not in token_response:
            raise ValueError("Failed to create project API key")
        
        to_api_key = token_response['id']
        Console.write_stdout("Project API key created successfully")
        
        if not to_organization_id:
            Console.write_stdout("Retrieving destination organization ID...")
            dest_admin_client = AdminClient(api_key=to_api_key, base_url=to_instance or from_instance)
            dest_token_info = dest_admin_client.validate_api_token()
            to_organization_id = dest_token_info.get("organizationId")
            Console.write_stdout(f"Destination organization ID: {to_organization_id}")

    if migrate_all:
        migrate_agents = True
        migrate_integrations = True  # Use integrations instead of individual tools
        migrate_tools = False  # Don't migrate tools individually when using --all
        migrate_tool_plugins = False  # Don't duplicate integrations when using --all
        migrate_processes = True
        migrate_tasks = True
        migrate_artifact_types = True
        migrate_usage_limits = True if from_organization_id and to_organization_id else False
        migrate_rag_assistants = True
        migrate_files = True if from_organization_id and to_organization_id else False
        migrate_secrets = True
        agent_ids = "all"
        integration_ids = "all"  # Migrate integrations (tool-plugins) instead of tools
        tool_ids = None  # Don't set tool_ids when using --all
        tool_plugin_ids = None  # Don't set tool_plugin_ids when using --all
        process_ids = "all"
        task_ids = "all"
        artifact_type_ids = "all"
        assistant_names = "all"
        file_ids = "all"
        secret_ids = "all"
    
    if migrate_processes:
        if not migrate_tasks:
            migrate_tasks = True
            task_ids = "all"
            Console.write_stdout("Note: Auto-including Tasks (required by Agentic Processes)")
        if not migrate_artifact_types:
            migrate_artifact_types = True
            artifact_type_ids = "all"
            Console.write_stdout("Note: Auto-including Artifact Types (required by Agentic Processes)")

    strategies = []
    
    lab_manager = AILabManager(api_key=from_api_key, base_url=from_instance)

    if migrate_agents:
        if agent_ids == "all":
            agent_list = lab_manager.list_agents(FilterSettings(count=1000))
            discovered_agents = [agent.id for agent in agent_list.agents if agent.id]
            Console.write_stdout(f"Discovered {len(discovered_agents)} agents")
            for agent_id in discovered_agents:
                strategies.append(AgentMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    agent_id=agent_id,
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))
        elif agent_ids:
            for agent_id in agent_ids.split(','):
                strategies.append(AgentMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    agent_id=agent_id.strip(),
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))
    
    if migrate_integrations:
        if integration_ids == "all":
            integration_list = lab_manager.list_integrations(FilterSettings(count=1000, access_scope="private"))
            discovered_integrations = [integration.id for integration in integration_list.plugins if integration.id]
            Console.write_stdout(f"Discovered {len(discovered_integrations)} integrations")
            for integration_id in discovered_integrations:
                strategies.append(IntegrationMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    integration_id_or_name=integration_id,
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))
        elif integration_ids:
            integration_ids_list = [i.strip() for i in integration_ids.split(',')]
            Console.write_stdout(f"Migrating {len(integration_ids_list)} integrations")
            for integration_id in integration_ids_list:
                strategies.append(IntegrationMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    integration_id_or_name=integration_id,
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))
    
    if migrate_tools:
        Console.write_stdout("")
        Console.write_stdout("WARNING: Migrating tools individually is deprecated!")
        Console.write_stdout("    Tools that belong to integrations (tool-plugins) should be migrated")
        Console.write_stdout("    as a complete integration to preserve their grouping and shared configuration.")
        Console.write_stdout("    Use --integrations instead of --tools for modern tool-plugins.")
        Console.write_stdout("")
        
        if tool_ids == "all":
            # List tools and detect which belong to integrations
            tool_list = lab_manager.list_tools(FilterSettings(count=1000, access_scope="private"))
            discovered_tools = [tool for tool in tool_list.tools if tool.id]
            
            # Separate tools into integration-based and standalone
            integration_tool_ids = set()
            standalone_tool_ids = []
            integration_ids_to_migrate = set()
            
            for tool in discovered_tools:
                if tool.tool_plugin and tool.tool_plugin.id:
                    # This tool belongs to an integration
                    integration_tool_ids.add(tool.id)
                    integration_ids_to_migrate.add(tool.tool_plugin.id)
                else:
                    # Standalone tool
                    standalone_tool_ids.append(tool.id)
            
            if integration_ids_to_migrate:
                Console.write_stdout(f"Detected {len(integration_ids_to_migrate)} integrations with {len(integration_tool_ids)} tools")
                Console.write_stdout("   These will be migrated as integrations (preserving tool grouping)")
                
                for integration_id in integration_ids_to_migrate:
                    strategies.append(IntegrationMigrationStrategy(
                        from_api_key=from_api_key,
                        from_instance=from_instance,
                        integration_id_or_name=integration_id,
                        to_api_key=to_api_key,
                        to_instance=to_instance
                    ))
            
            if standalone_tool_ids:
                Console.write_stdout(f"Discovered {len(standalone_tool_ids)} standalone tools")
                Console.write_stdout("   These will be migrated individually")
                
                for tool_id in standalone_tool_ids:
                    strategies.append(ToolMigrationStrategy(
                        from_api_key=from_api_key,
                        from_instance=from_instance,
                        tool_id=tool_id,
                        to_api_key=to_api_key,
                        to_instance=to_instance
                    ))
        elif tool_ids:
            # For specific tool IDs, check if they belong to integrations
            for tool_id in tool_ids.split(','):
                tool_id = tool_id.strip()
                try:
                    tool = lab_manager.get_tool(tool_id=tool_id)
                    if tool.tool_plugin and tool.tool_plugin.id:
                        Console.write_stdout(f"WARNING: Tool '{tool_id}' belongs to integration '{tool.tool_plugin.name}'")
                        Console.write_stdout(f"    Consider migrating the entire integration '{tool.tool_plugin.id}' instead")
                except Exception as e:
                    logger.warning(f"Could not fetch tool {tool_id} details: {e}")
                
                strategies.append(ToolMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    tool_id=tool_id,
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))
    
    if migrate_tool_plugins:
        # Use new v3 integration endpoints to list and migrate integrations
        if tool_plugin_ids == "all":
            # List all integrations using v3 endpoint
            integration_list = lab_manager.list_integrations(FilterSettings(count=1000, access_scope="private"))
            discovered_integrations = [integration.id for integration in integration_list.plugins if integration.id]
            Console.write_stdout(f"Discovered {len(discovered_integrations)} tool plugins (integrations)")
            
            # Create IntegrationMigrationStrategy for each
            for integration_id in discovered_integrations:
                strategies.append(IntegrationMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    integration_id_or_name=integration_id,
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))
        else:
            # Specific plugin IDs provided - migrate these integrations
            target_plugin_ids = [pid.strip() for pid in tool_plugin_ids.split(',')]
            Console.write_stdout(f"Migrating {len(target_plugin_ids)} tool plugin(s) (integrations)")
            
            for plugin_id in target_plugin_ids:
                strategies.append(IntegrationMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    integration_id_or_name=plugin_id,
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))

    if migrate_tasks:
        if task_ids == "all":
            task_list = lab_manager.list_tasks(FilterSettings(count=1000))
            discovered_tasks = [task.id for task in task_list.tasks if task.id]
            Console.write_stdout(f"Discovered {len(discovered_tasks)} tasks")
            for task_id in discovered_tasks:
                strategies.append(TaskMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    task_id=task_id,
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))
        elif task_ids:
            for task_id in task_ids.split(','):
                strategies.append(TaskMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    task_id=task_id.strip(),
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))

    if migrate_artifact_types:
        if artifact_type_ids == "all":
            artifact_type_list = lab_manager.list_artifact_types(FilterSettings(count=1000))
            discovered_artifact_types = [at.id for at in artifact_type_list.artifact_types if at.id]
            Console.write_stdout(f"Discovered {len(discovered_artifact_types)} artifact types")
            for artifact_type_id in discovered_artifact_types:
                strategies.append(ArtifactTypeMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    artifact_type_id=artifact_type_id,
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))
        elif artifact_type_ids:
            for artifact_type_id in artifact_type_ids.split(','):
                strategies.append(ArtifactTypeMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    artifact_type_id=artifact_type_id.strip(),
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))

    if migrate_processes:
        if process_ids == "all":
            process_list = lab_manager.list_processes(FilterSettings(count=1000))
            discovered_processes = [proc.id for proc in process_list.processes if proc.id]
            Console.write_stdout(f"Discovered {len(discovered_processes)} agentic processes")
            for process_id in discovered_processes:
                strategies.append(AgenticProcessMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    process_id=process_id,
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))
        elif process_ids:
            for process_id in process_ids.split(','):
                strategies.append(AgenticProcessMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    process_id=process_id.strip(),
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))

    if migrate_usage_limits and from_organization_id and to_organization_id:
        strategies.append(UsageLimitMigrationStrategy(
            from_api_key=from_organization_api_key,
            from_instance=from_instance,
            from_organization_id=from_organization_id,
            to_organization_id=to_organization_id,
            to_api_key=to_organization_api_key or from_organization_api_key,
            to_instance=to_instance
        ))
    
    if migrate_rag_assistants:
        rag_client = RAGAssistantClient(api_key=from_api_key, base_url=from_instance)
        if assistant_names == "all":
            assistant_data = rag_client.get_assistants_from_project()
            assistants_raw = assistant_data.get("assistants", [])
            assistant_list = [RAGAssistantMapper.map_to_rag_assistant(a) for a in assistants_raw] if assistants_raw else []
            discovered_assistants = [assistant.name for assistant in assistant_list if assistant.name]
            Console.write_stdout(f"Discovered {len(discovered_assistants)} RAG assistants")
            for assistant_name in discovered_assistants:
                strategies.append(RAGAssistantMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    assistant_name=assistant_name,
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))
        elif assistant_names:
            for assistant_name in assistant_names.split(','):
                strategies.append(RAGAssistantMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    assistant_name=assistant_name.strip(),
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))
    
    if migrate_files and from_organization_id and from_project_id and to_organization_id and to_project_id:
        file_manager = FileManager(
            api_key=from_api_key,
            base_url=from_instance,
            organization_id=from_organization_id,
            project_id=from_project_id
        )
        if file_ids == "all":
            file_list_response = file_manager.get_file_list()
            discovered_files = [f.id for f in file_list_response.files if f.id]
            Console.write_stdout(f"Discovered {len(discovered_files)} files")
            for file_id in discovered_files:
                strategies.append(FileMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    from_organization_id=from_organization_id,
                    from_project_id=from_project_id,
                    to_organization_id=to_organization_id,
                    to_project_id=to_project_id,
                    file_id=file_id,
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))
        elif file_ids:
            for file_id in file_ids.split(','):
                strategies.append(FileMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    from_organization_id=from_organization_id,
                    from_project_id=from_project_id,
                    to_organization_id=to_organization_id,
                    to_project_id=to_project_id,
                    file_id=file_id.strip(),
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))

    if migrate_secrets:
        secret_client = SecretClient(api_key=from_api_key, base_url=from_instance)
        if secret_ids == "all":
            secrets_data = secret_client.list_secrets(count=1000)
            secrets_list = secrets_data.get("secrets", []) if isinstance(secrets_data, dict) else []
            discovered_secrets = [s.get('id') for s in secrets_list if s.get('id')]
            Console.write_stdout(f"Discovered {len(discovered_secrets)} secrets")
            for secret_id in discovered_secrets:
                strategies.append(SecretMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    secret_id=secret_id,
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))
        elif secret_ids:
            for secret_id in secret_ids.split(','):
                strategies.append(SecretMigrationStrategy(
                    from_api_key=from_api_key,
                    from_instance=from_instance,
                    secret_id=secret_id.strip(),
                    to_api_key=to_api_key,
                    to_instance=to_instance
                ))

    if not strategies:
        Console.write_stdout("No migration strategies configured. Use flags like --agents, --tools, --all, etc.")
        return

    dependencies = {}
    artifact_type_indices = []
    task_indices = []
    process_indices = []
    
    for idx, strategy in enumerate(strategies):
        if isinstance(strategy, ArtifactTypeMigrationStrategy):
            artifact_type_indices.append(idx)
        elif isinstance(strategy, TaskMigrationStrategy):
            task_indices.append(idx)
        elif isinstance(strategy, AgenticProcessMigrationStrategy):
            process_indices.append(idx)
    
    for process_idx in process_indices:
        deps = []
        deps.extend(artifact_type_indices)
        deps.extend(task_indices)
        if deps:
            dependencies[process_idx] = deps

    plan = MigrationPlan(
        strategies=strategies,
        dependencies=dependencies,
        stop_on_error=stop_on_error
    )
    orchestrator = MigrationOrchestrator(plan)
    
    try:
        result = orchestrator.execute()
        Console.write_stdout(f"Migration completed: {result['completed']}/{result['total']} successful")
        logger.info(f"Project cloning completed: {result}")
    except Exception as e:
        Console.write_stderr(f"Migration failed: {e}")
        logger.error(f"Project cloning failed: {e}")
        raise


def diff_projects(option_list: list) -> None:
    """
    Compare two projects and show differences in their resources.
    
    Compares agents, tools, processes, tasks, artifact types, RAG assistants,
    files, usage limits, and secrets between two GEAI projects.
    
    Project IDs and organization IDs are automatically detected from API keys if not provided.
    
    :param option_list: List of (option_flag, option_value) tuples from CLI parsing
    """
    opts = {opt.name: arg for opt, arg in option_list}
    
    from_api_key = opts.get('from_api_key')
    from_instance = opts.get('from_instance')
    from_project_id = opts.get('from_project_id')
    from_organization_id = opts.get('from_organization_id')
    from_organization_api_key = opts.get('from_organization_api_key')
    
    to_api_key = opts.get('to_api_key')
    to_instance = opts.get('to_instance')
    to_project_id = opts.get('to_project_id')
    to_organization_id = opts.get('to_organization_id')
    to_organization_api_key = opts.get('to_organization_api_key')
    
    output_file = opts.get('output')
    output_format = opts.get('format', 'text').lower()
    resource_types_str = opts.get('resource_types')
    
    from pygeai.cli.commands.common import get_boolean_value
    ignore_ids = get_boolean_value(opts.get('ignore_ids', '1'))
    
    if not all([from_api_key, from_instance, to_api_key]):
        raise MissingRequirementException(
            "Source and destination API keys and instances are required for comparison"
        )
    
    if output_format not in ['text', 'json', 'markdown']:
        Console.write_stderr(f"Invalid format '{output_format}', defaulting to 'text'")
        output_format = 'text'
    
    resource_types = None
    if resource_types_str:
        resource_types = [rt.strip() for rt in resource_types_str.split(',')]
        valid_types = [
            "agents", "tools", "processes", "tasks", "artifact_types",
            "rag_assistants", "files", "usage_limits", "secrets"
        ]
        invalid_types = [rt for rt in resource_types if rt not in valid_types]
        if invalid_types:
            Console.write_stderr(f"Warning: Invalid resource types will be ignored: {', '.join(invalid_types)}")
            resource_types = [rt for rt in resource_types if rt in valid_types]
    
    Console.write_stdout("Starting project comparison...")
    if ignore_ids:
        Console.write_stdout("Comparison mode: By NAME (ignoring resource IDs)")
    else:
        Console.write_stdout("Comparison mode: By ID")
    Console.write_stdout("")
    
    comparator = ProjectComparator(
        from_api_key=from_api_key,
        from_instance=from_instance,
        to_api_key=to_api_key,
        to_instance=to_instance if to_instance else from_instance,
        from_project_id=from_project_id,
        to_project_id=to_project_id,
        from_organization_id=from_organization_id,
        to_organization_id=to_organization_id,
        from_organization_api_key=from_organization_api_key,
        to_organization_api_key=to_organization_api_key,
        resource_types=resource_types,
        ignore_ids=ignore_ids
    )
    
    Console.write_stdout(f"Source: {comparator.from_instance} / Project: {comparator.from_project_id}")
    Console.write_stdout(f"Destination: {comparator.to_instance} / Project: {comparator.to_project_id}")
    Console.write_stdout("")
    
    try:
        diff = comparator.compare()
        formatter = DiffFormatter()
        
        if output_format == 'json':
            content = formatter.format_as_json(diff)
        elif output_format == 'markdown':
            content = formatter.format_as_markdown(diff)
        else:
            content = formatter.format_as_text(diff)
        
        if output_file:
            formatter.write_to_file(content, output_file)
            Console.write_stdout(f"\nComparison report saved to: {output_file}")
        else:
            Console.write_stdout(content)
        
        logger.info(f"Project comparison completed: {diff.summary.get('total_differences', 0)} differences found")
    except Exception as e:
        Console.write_stderr(f"Comparison failed: {e}")
        logger.error(f"Project comparison failed: {e}")
        raise


clone_project_options = [
    Option(
        "interactive",
        ["-i", "--interactive"],
        "Interactive mode: guided step-by-step migration wizard",
        False
    ),
    Option(
        "from_api_key",
        ["--from-api-key", "--from-key"],
        "Source instance project scope API key (required)",
        True
    ),
    Option(
        "from_organization_api_key",
        ["--from-org-key", "--from-organization-key", "--from-organization-api-key"],
        "Source instance organization scope API key (optional, for project creation)",
        True
    ),
    Option(
        "from_instance",
        ["--from-instance", "--from-url"],
        "Source instance URL (required)",
        True
    ),
    Option(
        "from_project_id",
        ["--from-project-id", "--from-pid"],
        "Source project ID (required)",
        True
    ),
    Option(
        "from_organization_id",
        ["--from-organization-id", "--from-oid"],
        "Source organization ID (required for usage limits and files)",
        True
    ),
    Option(
        "to_api_key",
        ["--to-api-key", "--to-key"],
        "Destination instance project scope API key (optional, defaults to source key)",
        True
    ),
    Option(
        "to_organization_api_key",
        ["--to-org-key", "--to-organization-key", "--to-organization-api-key"],
        "Destination instance organization scope API key (optional, for project creation)",
        True
    ),
    Option(
        "to_instance",
        ["--to-instance", "--to-url"],
        "Destination instance URL (optional, defaults to source URL)",
        True
    ),
    Option(
        "to_project_name",
        ["--to-project-name", "--to-name"],
        "Name for the new destination project (creates new project if specified with --admin-email)",
        True
    ),
    Option(
        "admin_email",
        ["--admin-email"],
        "Admin email for new project (required when creating new project)",
        True
    ),
    Option(
        "to_project_id",
        ["--to-project-id", "--to-pid"],
        "Destination project ID (optional for files)",
        True
    ),
    Option(
        "to_organization_id",
        ["--to-organization-id", "--to-oid"],
        "Destination organization ID (optional for usage limits and files)",
        True
    ),
    Option(
        "all",
        ["--all"],
        "Migrate all available components",
        False
    ),
    Option(
        "agents",
        ["--agents"],
        "Agent IDs to migrate: comma-separated IDs or 'all'",
        True
    ),
    Option(
        "integrations",
        ["--integrations"],
        "Integration IDs to migrate (recommended - migrates entire integrations with all tools): comma-separated IDs or 'all'",
        True
    ),
    Option(
        "tools",
        ["--tools"],
        "Tool IDs to migrate: comma-separated IDs or 'all'",
        True
    ),
    Option(
        "tool_plugins",
        ["--tool-plugins", "--plugins"],
        "Tool Plugin IDs to migrate (migrates all tools within these plugins): comma-separated IDs or 'all'",
        True
    ),
    Option(
        "agentic_processes",
        ["--agentic-processes", "--processes"],
        "Agentic process IDs to migrate: comma-separated IDs or 'all'",
        True
    ),
    Option(
        "tasks",
        ["--tasks"],
        "Task IDs to migrate: comma-separated IDs or 'all'",
        True
    ),
    Option(
        "artifact_types",
        ["--artifact-types"],
        "Artifact type IDs to migrate: comma-separated IDs or 'all'",
        True
    ),
    Option(
        "usage_limits",
        ["--usage-limits"],
        "Migrate usage limits (requires organization IDs)",
        False
    ),
    Option(
        "rag_assistants",
        ["--rag-assistants"],
        "RAG assistant names to migrate: comma-separated names or 'all'",
        True
    ),
    Option(
        "files",
        ["--files"],
        "File IDs to migrate: comma-separated IDs or 'all' (requires org/project IDs)",
        True
    ),
    Option(
        "secrets",
        ["--secrets"],
        "Secret IDs to migrate: comma-separated IDs or 'all'",
        True
    ),
    Option(
        "stop_on_error",
        ["--stop-on-error", "--soe"],
        "Stop migration on first error: 0: False, 1: True (default: 1)",
        True
    ),
]


diff_projects_options = [
    Option(
        "from_api_key",
        ["--from-api-key", "--from-key"],
        "Source instance project scope API key (required)",
        True
    ),
    Option(
        "from_instance",
        ["--from-instance", "--from-url"],
        "Source instance URL (required)",
        True
    ),
    Option(
        "from_project_id",
        ["--from-project-id", "--from-pid"],
        "Source project ID (optional, auto-detected from API key if not provided)",
        True
    ),
    Option(
        "from_organization_id",
        ["--from-organization-id", "--from-oid"],
        "Source organization ID (optional, auto-detected from API key; required for files comparison)",
        True
    ),
    Option(
        "from_organization_api_key",
        ["--from-org-key", "--from-organization-key"],
        "Source organization scope API key (optional, required for usage limits comparison)",
        True
    ),
    Option(
        "to_api_key",
        ["--to-api-key", "--to-key"],
        "Destination instance project scope API key (required)",
        True
    ),
    Option(
        "to_instance",
        ["--to-instance", "--to-url"],
        "Destination instance URL (required)",
        True
    ),
    Option(
        "to_project_id",
        ["--to-project-id", "--to-pid"],
        "Destination project ID (optional, auto-detected from API key if not provided)",
        True
    ),
    Option(
        "to_organization_id",
        ["--to-organization-id", "--to-oid"],
        "Destination organization ID (optional, required for files comparison)",
        True
    ),
    Option(
        "to_organization_api_key",
        ["--to-org-key", "--to-organization-key"],
        "Destination organization scope API key (optional, required for usage limits comparison)",
        True
    ),
    Option(
        "output",
        ["--output", "-o"],
        "Output file path (optional, prints to console if not specified)",
        True
    ),
    Option(
        "format",
        ["--format", "-f"],
        "Output format: text, json, markdown (default: text)",
        True
    ),
    Option(
        "resource_types",
        ["--resource-types", "--resources", "-r"],
        "Resource types to compare (comma-separated): agents,tools,processes,tasks,artifact_types,rag_assistants,files,usage_limits,secrets (default: all)",
        True
    ),
    Option(
        "ignore_ids",
        ["--ignore-ids", "--iid"],
        "Ignore resource IDs when comparing, compare by name instead: 0: False (default), 1: True",
        True
    ),
]


migrate_commands = [
    Command(
        "help",
        ["help", "h"],
        "Display help text",
        show_help,
        ArgumentsEnum.NOT_AVAILABLE,
        [],
        []
    ),
    Command(
        "clone_project",
        ["clone-project"],
        "Clone project components between instances",
        clone_project,
        ArgumentsEnum.REQUIRED,
        [],
        clone_project_options
    ),
    Command(
        "diff",
        ["diff", "compare"],
        "Compare two projects and show resource differences",
        diff_projects,
        ArgumentsEnum.REQUIRED,
        [],
        diff_projects_options
    ),
]
