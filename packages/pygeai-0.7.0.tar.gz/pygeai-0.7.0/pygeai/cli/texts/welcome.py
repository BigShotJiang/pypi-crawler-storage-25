WELCOME_BANNER = """
================================================================================
Welcome to PyGEAI
Globant Enterprise AI SDK - Command Line Interface
================================================================================

This wizard will guide you through initial setup and feature discovery.

Setup Steps:
  1. Configure credentials
  2. Explore available features
  3. Run your first command

Press Enter to continue or Ctrl+C to exit...
"""

FEATURE_CATEGORIES = {
    "1": {
        "name": "Template-Based Code Generation",
        "description": "Generate production-ready AI projects from templates",
        "commands": ["geai generate help"],
        "docs": "https://rt-gen029-gi.github.io/pygeai/content/templates.html",
        "examples": [
            "geai generate list                                    # List available templates",
            "geai generate create --template rag-basic --name my_rag",
            "geai generate create --template lab-agent-tools --name my_agent",
            "geai generate create --template lab-multi-agent --name content_team",
        ]
    },
    "2": {
        "name": "Chat - Universal Interface",
        "description": "Interact with Assistants, Agents, RAGs, and Flows",
        "commands": ["geai chat help"],
        "docs": "https://docs.globant.ai/en/wiki?34,Chat+API",
        "examples": [
            "geai chat agent --name \"MyAgent\"",
            "geai chat completion --model \"saia:assistant:MyAssistant\" --msg '[{\"role\": \"user\", \"content\": \"Hello\"}]'",
        ]
    },
    "3": {
        "name": "Organizations & Projects",
        "description": "Manage organizational structure",
        "commands": ["geai org help"],
        "examples": [
            "geai org get-organization-list",
            "geai org list-projects",
            "geai org create-project -n \"MyProject\" -e \"admin@example.com\"",
        ]
    },
    "4": {
        "name": "Assistants & RAG",
        "description": "Create and manage AI assistants",
        "commands": ["geai assistant help", "geai rag help"],
        "examples": [
            "geai assistant get-assistant --id <UUID>",
            "geai rag list-assistants",
        ]
    },
    "5": {
        "name": "The Lab - Agents & Tools",
        "description": "Build custom agents with tools",
        "commands": ["geai ai-lab help", "geai spec help"],
        "docs": "https://docs.globant.ai/en/wiki?1671,The+Lab",
        "examples": [
            "geai ai-lab list-agents",
            "geai spec load-agent --file \"agent_spec.json\"",
        ]
    },
    "6": {
        "name": "Analytics & Monitoring",
        "description": "Track usage and performance metrics",
        "commands": ["geai analytics help"],
        "examples": [
            "geai analytics usage",
            "geai analytics total-tokens --last-month",
        ]
    },
    "7": {
        "name": "LLM & Model Management",
        "description": "Manage language models and providers",
        "commands": ["geai llm help"],
        "examples": [
            "geai llm list-providers",
            "geai llm list-models",
        ]
    },
    "8": {
        "name": "Files, Embeddings & Reranking",
        "description": "Handle document processing and search",
        "commands": ["geai files help", "geai embeddings help", "geai rerank help"],
        "examples": [
            "geai files upload-file --file \"document.pdf\" --purpose \"assistants\"",
            "geai files list-files",
        ]
    },
    "9": {
        "name": "Authentication, Secrets & Admin",
        "description": "Security and administration tools",
        "commands": ["geai auth help", "geai secrets help", "geai admin help"],
        "examples": [
            "geai auth login",
            "geai secrets list",
        ]
    },
}

FEATURE_TOUR_HEADER = """
================================================================================
PyGEAI Feature Overview
================================================================================

Available capabilities:
"""

RESOURCES_FOOTER = """
================================================================================
Resources & Next Steps
================================================================================

Documentation:
  - Main docs:  https://docs.globant.ai/en/wiki?15,Globant+Enterprise+AI+Overview
  - Templates:  https://rt-gen029-gi.github.io/pygeai/content/templates.html
  - Chat API:   https://docs.globant.ai/en/wiki?34,Chat+API
  - The Lab:    https://docs.globant.ai/en/wiki?1671,The+Lab

Quick Reference:
  - Man pages:    geai-install-man
  - Command help: geai <command> h
  - Verbose mode: geai --verbose <command>

Advanced Configuration (Enterprise Environments):
  - Custom SSL certificates for self-signed or corporate CA:
      geai configure --ssl-cert-path /etc/ssl/certs/company-ca.pem
    Or set environment variable: GEAI_SSL_CERT_PATH
    Note: This validates SSL using custom certs, does NOT disable verification

Get Started:
  geai generate list                 # List available project templates
  geai generate create --template rag-basic --name my_rag
  geai llm list-providers            # List available LLM providers
  geai org get-organization-list     # List your organizations
  geai ai-lab list-agents            # List Lab agents
  geai chat help                     # Learn about chat interface

================================================================================
Setup complete! You're ready to use PyGEAI.
================================================================================
"""

COMPLETION_MESSAGE = """
================================================================================
Setup complete! You're ready to use PyGEAI.
================================================================================
"""
