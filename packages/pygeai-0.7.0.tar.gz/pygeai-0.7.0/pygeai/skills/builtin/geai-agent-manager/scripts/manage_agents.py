#!/usr/bin/env python3
from pygeai import Client

client = Client()

# List all agents
agents = client.agents.list()
for agent in agents:
    print(f"{agent.name}: {agent.model}")

# Update agent
client.agents.update(agent_id="agent-123", temperature=0.5)

# Delete agent
# client.agents.delete(agent_id="agent-123")
