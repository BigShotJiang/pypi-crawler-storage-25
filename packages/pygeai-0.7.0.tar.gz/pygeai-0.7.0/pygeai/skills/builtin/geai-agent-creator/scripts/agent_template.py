#!/usr/bin/env python3
"""Agent creation templates."""

TEMPLATES = {
    "code_reviewer": {
        "name": "Code Reviewer",
        "instructions": "You are an expert code reviewer. Analyze code for bugs, security issues, and best practices.",
        "model": "gpt-4o",
        "temperature": 0.3
    },
    
    "data_analyst": {
        "name": "Data Analyst",
        "instructions": "You are a data analyst. Analyze data, create visualizations, and provide insights.",
        "model": "gpt-4o",
        "temperature": 0.5
    },
    
    "technical_writer": {
        "name": "Technical Writer",
        "instructions": "You are a technical writer. Create clear, comprehensive documentation.",
        "model": "gpt-4o",
        "temperature": 0.6
    }
}

def create_agent_from_template(client, template_name):
    """Create agent from template."""
    template = TEMPLATES[template_name]
    return client.agents.create(**template)

if __name__ == "__main__":
    from pygeai import Client
    client = Client()
    agent = create_agent_from_template(client, "code_reviewer")
    print(f"Created agent: {agent.id}")
