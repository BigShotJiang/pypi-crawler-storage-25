#!/usr/bin/env python3
from pygeai import Client
client = Client()

# Get usage stats
stats = client.analytics.get_usage(period="30d")
print(f"Total requests: {stats.total_requests}")
print(f"Total cost: ${stats.total_cost:.2f}")
