#!/usr/bin/env python3
from pygeai import Client
client = Client()

# Create evaluation
eval_result = client.evaluations.create(
    dataset_id="dataset-123",
    model="gpt-4o",
    metrics=["accuracy", "relevance"]
)
print(f"Evaluation score: {eval_result.average_score:.2%}")
