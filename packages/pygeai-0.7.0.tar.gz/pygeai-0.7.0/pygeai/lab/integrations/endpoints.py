"""
Integration API v3 endpoint constants.

This module defines the v3 API endpoints for Integration (ToolPlugin) operations.
These endpoints support managing integrations that group related tools with shared
parameter configurations.
"""

# List all integrations in a project
LIST_INTEGRATIONS_V3 = "v3/tool-plugins"

# Get a specific integration by ID or name
GET_INTEGRATION_V3 = "v3/tool-plugins/{integrationIdOrName}"

# Get integration configuration (shared parameters)
GET_INTEGRATION_CONFIG_V3 = "v3/tool-plugins/{integrationIdOrName}/config"

# Set/update integration configuration (shared parameters)
SET_INTEGRATION_CONFIG_V3 = "v3/tool-plugins/{integrationIdOrName}/config"

# Delete an integration
DELETE_INTEGRATION_V3 = "v3/tool-plugins/{integrationIdOrName}"

# Export integration with all its tools and configuration
EXPORT_INTEGRATION_V3 = "v3/tool-plugins/{integrationIdOrName}/export"

# Import/create integration from manifest
IMPORT_INTEGRATION_V3 = "v3/tool-plugins/import"

# Update/re-import existing integration
UPDATE_INTEGRATION_V3 = "v3/tool-plugins/import/{integrationIdOrName}"

# Publish tools in an integration
PUBLISH_TOOLS_V3 = "v3/tool-plugins/{integrationIdOrName}/publish-tools"
