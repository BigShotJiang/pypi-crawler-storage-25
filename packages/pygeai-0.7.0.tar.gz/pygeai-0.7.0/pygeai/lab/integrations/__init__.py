"""
Integration management module for pygeai.lab.

This module provides clients, managers, and utilities for working with
Integrations (ToolPlugins) in the AI Lab. Integrations group related tools
with shared parameters that can be inherited or overridden at the tool level.
"""

from pygeai.lab.integrations.clients import IntegrationClient
from pygeai.lab.integrations.managers import IntegrationManager
from pygeai.lab.integrations.mappers import IntegrationMapper

__all__ = [
    'IntegrationClient',
    'IntegrationManager',
    'IntegrationMapper',
]
