import json
from json import JSONDecodeError
from typing import List

from pygeai.lab.models import Tool, ToolParameter, ToolMessage, ToolList


class ToolMapper:
    @classmethod
    def _map_parameters(cls, params_data: List[dict]) -> List[ToolParameter]:
        """
        Maps a list of parameter dictionaries to a list of ToolParameter objects.

        :param params_data: List[dict] - List of raw parameter data.
        :return: List[ToolParameter] - List of mapped ToolParameter objects.
        """
        return [
            ToolParameter(
                key=param.get("key"),
                data_type=param.get("dataType"),
                description=param.get("description"),
                is_required=param.get("isRequired"),
                type=param.get("type"),
                from_secret=param.get("fromSecret"),
                value=param.get("value")
            )
            for param in params_data
        ]

    @classmethod
    def _map_messages(cls, messages_data: List[dict]) -> List[ToolMessage]:
        """
        Maps a list of message dictionaries to a list of ToolMessage objects.

        :param messages_data: List[dict] - List of raw message data.
        :return: List[ToolMessage] - List of mapped ToolMessage objects.
        """
        return [
            ToolMessage(
                description=msg.get("description"),
                type=msg.get("type")
            )
            for msg in messages_data
        ]

    @classmethod
    def map_to_tool(cls, data: dict) -> Tool:
        """
        Maps a dictionary to a Tool object using Pydantic model validation.

        :param data: dict - The raw data, either input (under 'tool' key) or output (flat structure).
            Expected fields include name, description, scope, parameters, accessScope, publicName,
            icon, openApi, openApiJson, reportEvents, id, isDraft, messages, revision, status, toolPlugin, and version.
        :return: Tool - A Tool object representing the tool configuration.
        """
        tool_data = data.get("tool", data)

        # Handle openApiJson if it's a string (convert to dict)
        if "openApiJson" in tool_data and isinstance(tool_data["openApiJson"], str):
            try:
                tool_data["openApiJson"] = json.loads(tool_data["openApiJson"])
            except JSONDecodeError:
                raise ValueError("open_api_json must be a valid JSON string or a dict")

        # Use Pydantic's model_validate to automatically handle all fields including tool_plugin
        return Tool.model_validate(tool_data)

    @classmethod
    def map_to_tool_list(cls, data: dict) -> ToolList:
        """
        Maps an API response dictionary to a `ToolList` object.

        This method extracts tools from the given data, converts them into a list of `Tool` objects,
        and returns a `ToolList` containing the list.

        :param data: dict - The dictionary containing tool response data, expected to have a 'tools' key or be a list.
        :return: ToolList - A structured response containing a list of tools.
        """
        tool_list = []
        tools = data if isinstance(data, list) else data.get("tools", [])
        if tools and any(tools):
            for tool_data in tools:
                tool = cls.map_to_tool(tool_data)
                tool_list.append(tool)

        return ToolList(tools=tool_list)

    @classmethod
    def map_to_parameter_list(cls, data: dict) -> List[ToolParameter]:
        """
        Maps an API response dictionary to a list of ToolParameter objects.

        :param data: dict - The dictionary containing parameter response data, expected to have a 'parameters' key or be a list.
        :return: List[ToolParameter] - A list of ToolParameter objects.
        """
        params_data = data if isinstance(data, list) else data.get("parameters", [])
        return cls._map_parameters(params_data)

