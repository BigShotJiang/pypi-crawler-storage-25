# Tool-Plugin API endpoints

# List all tool-plugins in a project
LIST_TOOL_PLUGINS_V4 = "/v4/projects/{projectId}/tool-plugins"

# Get a specific tool-plugin by ID or name
GET_TOOL_PLUGIN_V4 = "/v4/projects/{projectId}/tool-plugins/{pluginIdOrName}"

# Get tool-plugin configuration (parameters)
GET_TOOL_PLUGIN_CONFIG_V4 = "/v4/projects/{projectId}/tool-plugins/{pluginIdOrName}/config"

# Set/update tool-plugin configuration (parameters)
SET_TOOL_PLUGIN_CONFIG_V4 = "/v4/projects/{projectId}/tool-plugins/{pluginIdOrName}/config"
