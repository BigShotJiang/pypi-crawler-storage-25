from typing import Optional

from pydantic.main import BaseModel


class OmniParserConfiguration(BaseModel):
    file_path: str
    start_page: Optional[int] = None
    end_page: Optional[int] = None
    hi_res_mode: Optional[bool] = None
    structure: Optional[str] = None
    dialogue: Optional[bool] = None
    output_format: Optional[str] = None
    password: Optional[str] = None
    cache: Optional[bool] = False
