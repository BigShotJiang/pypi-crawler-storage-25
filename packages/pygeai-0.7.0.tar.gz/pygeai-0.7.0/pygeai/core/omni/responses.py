from typing import List, Optional

from pydantic.main import BaseModel


class OmniParserPart(BaseModel):
    page: Optional[int] = None
    type: Optional[str] = None
    text: str
    mid_time: Optional[int] = None


class OmniParserUsage(BaseModel):
    total_cost: Optional[float] = None
    total_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    prompt_tokens: Optional[int] = None
    prompt_cost: Optional[float] = None
    completion_cost: Optional[float] = None
    currency: Optional[str] = None
    prompt_tokens_details: Optional[dict] = None
    completion_tokens_details: Optional[dict] = None


class OmniParserResponse(BaseModel):
    status: str
    parts: List[OmniParserPart]
    request_id: str
    usage: Optional[OmniParserUsage] = None
