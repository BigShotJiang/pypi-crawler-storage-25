from pygeai import logger
from pygeai.core.common.exceptions import APIError
from pygeai.core.omni.clients import OmniParserClient
from pygeai.core.omni.mappers import OmniParserResponseMapper
from pygeai.core.omni.models import OmniParserConfiguration
from pygeai.core.omni.responses import OmniParserResponse
from pygeai.core.handlers import ErrorHandler


class OmniParserManager:

    def __init__(self, api_key: str = None, base_url: str = None, alias: str = None):
        self.__client = OmniParserClient(api_key, base_url, alias)

    def process_file(
        self,
        configuration: OmniParserConfiguration
    ) -> OmniParserResponse:
        """
        Processes a file and returns a textual representation using the OmniParser API.

        This method accepts a configuration object containing all processing parameters and returns
        a structured response with the extracted text and metadata.

        :param configuration: OmniParserConfiguration - An instance containing the configuration for processing
                                                       the file, including:
            - file_path: str - Path to the file to be processed.
            - start_page: int, optional - First page number to begin processing from (1-based).
            - end_page: int, optional - Last page number to process (inclusive).
            - hi_res_mode: bool, optional - Request high-resolution OCR/vision mode for complex scans.
            - structure: str, optional - Set to "table" for spreadsheet/CSV-like sources.
            - dialogue: bool, optional - For audio/video: True to transcribe dialogue, False for visual descriptions.
            - output_format: str, optional - Preferred output format: "plainText", "html", or "markdown".
            - password: str, optional - Password for password-protected files.
            - cache: bool, optional - Whether to enable caching. Defaults to False.

        :return: OmniParserResponse - A response object containing the processed text parts and usage information.
        :raises APIError - If the API returns errors.
        """
        response_data = self.__client.process_file(
            file_path=configuration.file_path,
            start_page=configuration.start_page,
            end_page=configuration.end_page,
            hi_res_mode=configuration.hi_res_mode,
            structure=configuration.structure,
            dialogue=configuration.dialogue,
            output_format=configuration.output_format,
            password=configuration.password,
            cache=configuration.cache
        )

        if ErrorHandler.has_errors(response_data):
            error = ErrorHandler.extract_error(response_data)
            logger.error(f"Error received while processing file with OmniParser: {error}")
            raise APIError(f"Error received while processing file with OmniParser: {error}")

        result = OmniParserResponseMapper.map_to_omni_parser_response(response_data)
        return result
