import re
from pygeai import logger
from pygeai.core.common.exceptions import APIResponseError


def validate_status_code(response):
    if response.status_code >= 300:
        logger.error(f"Invalid status code returned from the API endpoint: {response.text}")
        raise APIResponseError(f"API returned an error: {response.text}")


def sanitize_project_name(name: str) -> str:
    if not name:
        return name
    
    sanitized = re.sub(r'[^a-zA-Z0-9\s_-]', '_', name)
    sanitized = re.sub(r'_{2,}', '_', sanitized)
    sanitized = sanitized.strip('_').strip()
    
    return sanitized


