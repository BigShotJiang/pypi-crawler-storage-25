from pygeai.core.common.config import SETTINGS_DIR


FIRST_RUN_MARKER = SETTINGS_DIR / ".first_run_complete"


def is_first_run() -> bool:
    """
    Check if this is the first run of the CLI.
    
    Returns:
        bool: True if this is the first run (marker file doesn't exist), False otherwise.
    """
    return not FIRST_RUN_MARKER.exists()


def mark_first_run_complete() -> None:
    """
    Mark that the first run wizard has been completed.
    
    Creates a marker file in the .geai directory.
    """
    FIRST_RUN_MARKER.touch()


def reset_first_run() -> None:
    """
    Reset the first run marker (for testing or re-running welcome wizard).
    
    Removes the marker file if it exists.
    """
    if FIRST_RUN_MARKER.exists():
        FIRST_RUN_MARKER.unlink()
