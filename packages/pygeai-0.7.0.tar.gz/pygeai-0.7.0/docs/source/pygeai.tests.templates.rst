pygeai.tests.templates package
==============================

Submodules
----------

pygeai.tests.templates.test\_api\_server\_template module
---------------------------------------------------------

.. automodule:: pygeai.tests.templates.test_api_server_template
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.templates.test\_chat\_agent\_streaming\_template module
--------------------------------------------------------------------

.. automodule:: pygeai.tests.templates.test_chat_agent_streaming_template
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.templates.test\_chat\_flow\_streaming\_template module
-------------------------------------------------------------------

.. automodule:: pygeai.tests.templates.test_chat_flow_streaming_template
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.templates.test\_chat\_rag\_streaming\_template module
------------------------------------------------------------------

.. automodule:: pygeai.tests.templates.test_chat_rag_streaming_template
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.templates.test\_evaluation\_basic\_template module
---------------------------------------------------------------

.. automodule:: pygeai.tests.templates.test_evaluation_basic_template
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.templates.test\_lab\_agent\_basic\_template module
---------------------------------------------------------------

.. automodule:: pygeai.tests.templates.test_lab_agent_basic_template
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.templates.test\_lab\_agent\_tools\_template module
---------------------------------------------------------------

.. automodule:: pygeai.tests.templates.test_lab_agent_tools_template
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.templates.test\_lab\_multi\_agent\_template module
---------------------------------------------------------------

.. automodule:: pygeai.tests.templates.test_lab_multi_agent_template
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.templates.test\_lab\_process\_basic\_template module
-----------------------------------------------------------------

.. automodule:: pygeai.tests.templates.test_lab_process_basic_template
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.templates.test\_rag\_basic\_template module
--------------------------------------------------------

.. automodule:: pygeai.tests.templates.test_rag_basic_template
   :members:
   :show-inheritance:
   :undoc-members:

pygeai.tests.templates.test\_web\_ui\_gradio\_template module
-------------------------------------------------------------

.. automodule:: pygeai.tests.templates.test_web_ui_gradio_template
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: pygeai.tests.templates
   :members:
   :show-inheritance:
   :undoc-members:
