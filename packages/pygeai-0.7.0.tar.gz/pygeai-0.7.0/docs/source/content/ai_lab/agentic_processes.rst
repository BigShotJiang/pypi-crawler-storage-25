Agentic Processes & Artifact Types
===================================

The Agentic Processes module provides functionality to create, manage, and orchestrate complex workflows involving multiple agents, tools, and artifacts in the Globant Enterprise AI Lab. Processes define the flow of execution, event handling, and data artifacts.

This section covers:

**Agentic Processes:**

* Creating processes
* Retrieving process information
* Updating process configuration
* Listing processes and instances
* Publishing process revisions
* Deleting processes

**Artifact Types:**

* Creating artifact type definitions
* Retrieving artifact type information
* Updating artifact type configuration
* Listing artifact types
* Deleting artifact types

For each operation, you have three implementation options:

* `Command Line`_
* `Low-Level Service Layer`_ (using clients)
* `High-Level Service Layer`_ (using managers)


Agentic Processes
-----------------

Create Process
~~~~~~~~~~~~~~

Creates a new agentic process with activities, signals, events, and sequence flows.

Command Line
^^^^^^^^^^^^

.. code-block:: shell

    geai lab process create \
      --key "product_review" \
      --name "Product Review Process" \
      --description "Automated product review workflow"

Low-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.processes.clients import AgenticProcessClient
    
    client = AgenticProcessClient()
    
    process_data = {
        "key": "product_review",
        "name": "Product Review Process",
        "description": "Automated product review workflow",
        "kb": {
            "name": "product-knowledge",
            "artifactTypeName": ["product-doc"]
        },
        "agenticActivities": [
            {
                "key": "analyze_product",
                "name": "Analyze Product",
                "taskName": "analysis-task",
                "agentName": "product-analyzer",
                "agentRevisionId": 0
            }
        ],
        "artifactSignals": [
            {
                "key": "artifact.upload.1",
                "name": "artifact.upload",
                "handlingType": "C",
                "artifactTypeName": ["product-doc"]
            }
        ],
        "userSignals": [
            {
                "key": "review_done",
                "name": "review-completed"
            }
        ],
        "startEvent": {
            "key": "artifact.upload.1",
            "name": "artifact.upload"
        },
        "endEvent": {
            "key": "end",
            "name": "Done"
        },
        "sequenceFlows": [
            {"key": "step1", "sourceKey": "artifact.upload.1", "targetKey": "analyze_product"},
            {"key": "step2", "sourceKey": "analyze_product", "targetKey": "review_done"},
            {"key": "stepEnd", "sourceKey": "review_done", "targetKey": "end"}
        ]
    }
    
    response = client.create_process(process_data=process_data, automatic_publish=False)
    print(response)

High-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.managers import AILabManager
    from pygeai.lab.models import (
        AgenticProcess, KnowledgeBase, AgenticActivity,
        ArtifactSignal, UserSignal, Event, SequenceFlow
    )
    
    manager = AILabManager()
    
    process = AgenticProcess(
        key="product_review",
        name="Product Review Process",
        description="Automated product review workflow",
        kb=KnowledgeBase(
            name="product-knowledge",
            artifact_type_name=["product-doc"]
        ),
        agentic_activities=[
            AgenticActivity(
                key="analyze_product",
                name="Analyze Product",
                task_name="analysis-task",
                agent_name="product-analyzer",
                agent_revision_id=0
            )
        ],
        artifact_signals=[
            ArtifactSignal(
                key="artifact.upload.1",
                name="artifact.upload",
                handling_type="C",
                artifact_type_name=["product-doc"]
            )
        ],
        user_signals=[
            UserSignal(key="review_done", name="review-completed")
        ],
        start_event=Event(key="artifact.upload.1", name="artifact.upload"),
        end_event=Event(key="end", name="Done"),
        sequence_flows=[
            SequenceFlow(key="step1", source_key="artifact.upload.1", target_key="analyze_product"),
            SequenceFlow(key="step2", source_key="analyze_product", target_key="review_done"),
            SequenceFlow(key="stepEnd", source_key="review_done", target_key="end")
        ]
    )
    
    result = manager.create_process(process=process, automatic_publish=False)
    print(f"Created process: {result.name}, ID: {result.id}")


Get Process
~~~~~~~~~~~

Retrieves detailed information about a specific process by its ID or name.

Command Line
^^^^^^^^^^^^

.. code-block:: shell

    geai lab process get --id "process-uuid"

Low-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.processes.clients import AgenticProcessClient
    
    client = AgenticProcessClient()
    
    process_data = client.get_process(process_id="process-uuid")
    print(process_data)

High-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.managers import AILabManager
    
    manager = AILabManager()
    
    process = manager.get_process(id_or_name="process-uuid")
    print(f"Process: {process.name}")
    print(f"Description: {process.description}")
    print(f"Activities: {len(process.agentic_activities)}")


List Processes
~~~~~~~~~~~~~~

Retrieves a list of processes with optional filtering.

Command Line
^^^^^^^^^^^^

.. code-block:: shell

    geai lab process list --start 0 --count 10

Low-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.processes.clients import AgenticProcessClient
    
    client = AgenticProcessClient()
    
    processes_list = client.list_processes(start="0", count="10")
    print(processes_list)

High-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.managers import AILabManager
    from pygeai.lab.models import FilterSettings
    
    manager = AILabManager()
    
    filter_settings = FilterSettings(start="0", count="10")
    processes = manager.list_processes(filter_settings=filter_settings)
    
    print(f"Found {len(processes.processes)} processes:")
    for process in processes.processes:
        print(f"  - {process.name} (ID: {process.id})")


List Process Instances
~~~~~~~~~~~~~~~~~~~~~~~

Retrieves instances of a specific process.

Command Line
^^^^^^^^^^^^

.. code-block:: shell

    geai lab process list-instances --id "process-uuid" --start 0 --count 10

Low-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.processes.clients import AgenticProcessClient
    
    client = AgenticProcessClient()
    
    instances = client.list_process_instances(
        process_id="process-uuid",
        start="0",
        count="10"
    )
    print(instances)

High-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.managers import AILabManager
    from pygeai.lab.models import FilterSettings
    
    manager = AILabManager()
    
    filter_settings = FilterSettings(start="0", count="10")
    instances = manager.list_process_instances(
        id_or_name="process-uuid",
        filter_settings=filter_settings
    )
    
    print(f"Found {len(instances.process_instances)} instances")


Update Process
~~~~~~~~~~~~~~

Updates an existing process configuration.

Command Line
^^^^^^^^^^^^

.. code-block:: shell

    geai lab process update \
      --id "process-uuid" \
      --name "Enhanced Product Review" \
      --description "Updated workflow with new features"

Low-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.processes.clients import AgenticProcessClient
    
    client = AgenticProcessClient()
    
    updated_data = {
        "name": "Enhanced Product Review",
        "description": "Updated workflow with new features"
    }
    
    response = client.update_process(
        process_id="process-uuid",
        process_data=updated_data,
        automatic_publish=False
    )
    print(response)

High-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.managers import AILabManager
    
    manager = AILabManager()
    
    # Get existing process
    existing_process = manager.get_process(id_or_name="process-uuid")
    
    # Update fields
    existing_process.name = "Enhanced Product Review"
    existing_process.description = "Updated workflow with new features"
    
    result = manager.update_process(
        id_or_name="process-uuid",
        process=existing_process,
        automatic_publish=False
    )
    print(f"Updated process: {result.name}")


Publish Process Revision
~~~~~~~~~~~~~~~~~~~~~~~~~

Publishes a specific revision of a process, making it active.

Command Line
^^^^^^^^^^^^

.. code-block:: shell

    geai lab process publish --id "process-uuid" --revision 2

Low-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.processes.clients import AgenticProcessClient
    
    client = AgenticProcessClient()
    
    response = client.publish_process_revision(
        process_id="process-uuid",
        revision=2
    )
    print(response)

High-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.managers import AILabManager
    
    manager = AILabManager()
    
    result = manager.publish_process_revision(
        id_or_name="process-uuid",
        revision=2
    )
    print(f"Published process revision: {result}")


Delete Process
~~~~~~~~~~~~~~

Deletes a specific process by its ID or name.

Command Line
^^^^^^^^^^^^

.. code-block:: shell

    geai lab process delete --id "process-uuid"

Low-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.processes.clients import AgenticProcessClient
    
    client = AgenticProcessClient()
    
    response = client.delete_process(process_id="process-uuid")
    print(response)

High-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.managers import AILabManager
    
    manager = AILabManager()
    
    result = manager.delete_process(id_or_name="process-uuid")
    print(f"Process deleted: {result}")


Artifact Types
--------------

Artifact types define the structure and metadata for artifacts used in agentic processes.

Create Artifact Type
~~~~~~~~~~~~~~~~~~~~

Creates a new artifact type definition.

Command Line
^^^^^^^^^^^^

.. code-block:: shell

    geai lab artifact-type create \
      --name "document-artifact" \
      --description "Document processing artifact type" \
      --tag "document-v1"

Low-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.processes.clients import AgenticProcessClient
    
    client = AgenticProcessClient()
    
    artifact_type_data = {
        "name": "document-artifact",
        "description": "Document processing artifact type",
        "tag": "document-v1"
    }
    
    response = client.create_artifact_type(
        name="document-artifact",
        description="Document processing artifact type",
        tag="document-v1"
    )
    print(response)

High-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.managers import AILabManager
    
    manager = AILabManager()
    
    result = manager.create_artifact_type(
        name="document-artifact",
        description="Document processing artifact type",
        tag="document-v1"
    )
    
    print(f"Created artifact type: {result.name}, ID: {result.id}")


Get Artifact Type
~~~~~~~~~~~~~~~~~

Retrieves information about a specific artifact type.

Command Line
^^^^^^^^^^^^

.. code-block:: shell

    geai lab artifact-type get --id "artifact-type-uuid"

Low-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.processes.clients import AgenticProcessClient
    
    client = AgenticProcessClient()
    
    artifact_type = client.get_artifact_type(id_or_name="artifact-type-uuid")
    print(artifact_type)

High-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.managers import AILabManager
    
    manager = AILabManager()
    
    artifact_type = manager.get_artifact_type(id_or_name="artifact-type-uuid")
    print(f"Artifact Type: {artifact_type.name}")
    print(f"Description: {artifact_type.description}")
    print(f"Tag: {artifact_type.tag}")


List Artifact Types
~~~~~~~~~~~~~~~~~~~

Retrieves a list of artifact type definitions.

Command Line
^^^^^^^^^^^^

.. code-block:: shell

    geai lab artifact-type list --start 0 --count 10

Low-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.processes.clients import AgenticProcessClient
    
    client = AgenticProcessClient()
    
    artifact_types = client.list_artifact_types(start="0", count="10")
    print(artifact_types)

High-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.managers import AILabManager
    from pygeai.lab.models import FilterSettings
    
    manager = AILabManager()
    
    filter_settings = FilterSettings(start="0", count="10")
    artifact_types = manager.list_artifact_types(filter_settings=filter_settings)
    
    print(f"Found {len(artifact_types.artifact_types)} artifact types:")
    for artifact_type in artifact_types.artifact_types:
        print(f"  - {artifact_type.name} (ID: {artifact_type.id})")


Update Artifact Type
~~~~~~~~~~~~~~~~~~~~

Updates an existing artifact type definition.

Command Line
^^^^^^^^^^^^

.. code-block:: shell

    geai lab artifact-type update \
      --id "artifact-type-uuid" \
      --name "document-artifact" \
      --description "Enhanced document processing artifact type" \
      --tag "document-v2"

Low-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.processes.clients import AgenticProcessClient
    
    client = AgenticProcessClient()
    
    response = client.update_artifact_type(
        id_or_name="artifact-type-uuid",
        name="document-artifact",
        description="Enhanced document processing artifact type",
        tag="document-v2"
    )
    print(response)

High-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.managers import AILabManager
    
    manager = AILabManager()
    
    result = manager.update_artifact_type(
        id_or_name="artifact-type-uuid",
        name="document-artifact",
        description="Enhanced document processing artifact type",
        tag="document-v2"
    )
    
    print(f"Updated artifact type: {result.name}")


Delete Artifact Type
~~~~~~~~~~~~~~~~~~~~

Deletes a specific artifact type by its ID or name.

Command Line
^^^^^^^^^^^^

.. code-block:: shell

    geai lab artifact-type delete --id "artifact-type-uuid"

Low-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.processes.clients import AgenticProcessClient
    
    client = AgenticProcessClient()
    
    response = client.delete_artifact_type(id_or_name="artifact-type-uuid")
    print(response)

High-Level Service Layer
^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: python

    from pygeai.lab.managers import AILabManager
    
    manager = AILabManager()
    
    result = manager.delete_artifact_type(id_or_name="artifact-type-uuid")
    print(f"Artifact type deleted: {result}")
