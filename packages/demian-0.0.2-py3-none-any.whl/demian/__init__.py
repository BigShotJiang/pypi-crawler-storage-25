"""Metadata-only Python placeholder for the Demian namespace, reserved for future agent and developer experience tooling."""

__version__ = "0.0.2"

name = "demian"
purpose = "Metadata-only Python placeholder for the Demian namespace, reserved for future agent and developer experience tooling."


def info():
    """Return package metadata."""
    return {"name": name, "version": __version__, "purpose": purpose}
