"""Smoke tests for polnor.mlflow.

Mocks the HTTP layer with `responses`. Exercises the contract of every
public function — happy path + a couple of error paths. Real
integration is covered by a separate e2e suite that hits the dev API.
"""

from __future__ import annotations

import os
import threading

import pytest
import responses

from polnor import mlflow
from polnor._client import Client, Config, PolnorAPIError


@pytest.fixture(autouse=True)
def env(monkeypatch):
    monkeypatch.setenv("POLNOR_API_URL", "https://api.example")
    monkeypatch.setenv("POLNOR_TOKEN", "test-token")
    monkeypatch.setenv("POLNOR_EXPERIMENT_ID", "exp-1")
    # Reset thread-local state explicitly. threading.local.__init__
    # in some interpreter versions doesn't clear attributes set on
    # the instance; deleting the known caches is reliable.
    for attr in ("runs", "client"):
        if hasattr(mlflow._local, attr):
            delattr(mlflow._local, attr)
    _ = threading  # silence unused import in some configurations
    yield


def url(path: str) -> str:
    return f"https://api.example/api/v1{path}"


@responses.activate
def test_start_and_end_run_with_context_manager():
    responses.post(url("/experiments/exp-1/runs"), json={"id": "r1", "name": "auto"})
    end_call = responses.patch(url("/experiments/exp-1/runs/r1"), status=204)

    with mlflow.start_run() as run:
        assert run.run_id == "r1"
        assert mlflow.active_run() is run

    assert end_call.call_count == 1
    body = responses.calls[1].request.body
    assert b"completed" in body


@responses.activate
def test_context_manager_marks_failed_on_exception():
    responses.post(url("/experiments/exp-1/runs"), json={"id": "r2", "name": "x"})
    end_call = responses.patch(url("/experiments/exp-1/runs/r2"), status=204)

    with pytest.raises(ZeroDivisionError):
        with mlflow.start_run():
            1 / 0

    assert end_call.call_count == 1
    assert b"failed" in responses.calls[1].request.body


@responses.activate
def test_log_metric_and_param_and_tag():
    responses.post(url("/experiments/exp-1/runs"), json={"id": "r3", "name": "x"})
    metric_call = responses.post(url("/experiments/exp-1/runs/r3/metrics"), status=204)
    param_call = responses.post(url("/experiments/exp-1/runs/r3/params"), status=204)
    tag_call = responses.post(url("/experiments/exp-1/runs/r3/tags"), status=204)
    responses.patch(url("/experiments/exp-1/runs/r3"), status=204)

    with mlflow.start_run():
        mlflow.log_metric("loss", 0.123)
        mlflow.log_param("optimizer", "adam")
        mlflow.set_tag("git_sha", "deadbeef")

    assert metric_call.call_count == 1
    assert param_call.call_count == 1
    assert tag_call.call_count == 1


@responses.activate
def test_log_metrics_batch():
    responses.post(url("/experiments/exp-1/runs"), json={"id": "r4", "name": "x"})
    batch = responses.post(url("/experiments/exp-1/runs/r4/metrics/batch"), status=204)
    responses.patch(url("/experiments/exp-1/runs/r4"), status=204)

    with mlflow.start_run():
        mlflow.log_metrics({"a": 1.0, "b": 2.0})

    assert batch.call_count == 1


def test_log_without_active_run_raises():
    with pytest.raises(RuntimeError, match="No active run"):
        mlflow.log_metric("x", 1.0)


def test_artifact_missing_file_raises():
    # log_artifact now actually uploads, but should still surface a
    # FileNotFoundError before talking to the server when the local
    # path doesn't exist.
    with pytest.raises(FileNotFoundError):
        mlflow.log_artifact("/tmp/__definitely_not_a_real_file_in_polnor__")


@responses.activate
def test_log_artifact_happy_path(tmp_path):
    # Server hands out a presigned URL → SDK does PUT to the URL.
    responses.post(url("/experiments/exp-1/runs"), json={"id": "r5", "name": "x"})
    responses.post(
        url("/experiments/exp-1/runs/r5/artifacts/presigned-url"),
        json={"upload_url": "https://s3.example/upload?sig=abc",
              "s3_uri": "s3://b/k", "expires_in": 3600},
    )
    upload = responses.put("https://s3.example/upload", status=200)
    responses.patch(url("/experiments/exp-1/runs/r5"), status=204)

    f = tmp_path / "model.pkl"
    f.write_bytes(b"\x80\x04model")
    with mlflow.start_run():
        mlflow.log_artifact(str(f), artifact_path="model.pkl")
    assert upload.call_count == 1


@responses.activate
def test_get_metric_history():
    responses.post(url("/experiments/exp-1/runs"), json={"id": "r6", "name": "x"})
    responses.get(
        url("/experiments/exp-1/runs/r6/metrics/loss"),
        json={"key": "loss", "data": [
            {"step": 0, "value": 1.0, "timestamp": "2026-01-01T00:00:00Z"},
            {"step": 1, "value": 0.5, "timestamp": "2026-01-01T00:01:00Z"},
        ]},
    )
    responses.patch(url("/experiments/exp-1/runs/r6"), status=204)

    with mlflow.start_run():
        history = mlflow.get_metric_history("loss")
    assert len(history) == 2
    assert history[0]["step"] == 0


@responses.activate
def test_5xx_retried_then_surfaced():
    # First two attempts 503, third raises; SDK gives up and re-raises.
    cfg = Config(api_url="https://api.example", token="t",
                 max_retries=2, backoff_base=0.0, timeout=1)
    client = Client(cfg)
    responses.post("https://api.example/api/v1/x", status=503, body="boom")

    with pytest.raises(PolnorAPIError) as ei:
        client.post("/x")
    assert ei.value.status == 503


def test_config_from_env_requires_url(monkeypatch):
    monkeypatch.delenv("POLNOR_API_URL", raising=False)
    with pytest.raises(RuntimeError, match="POLNOR_API_URL"):
        Config.from_env()


def test_config_from_env_requires_token(monkeypatch):
    monkeypatch.setenv("POLNOR_API_URL", "https://api.example")
    monkeypatch.delenv("POLNOR_TOKEN", raising=False)
    with pytest.raises(RuntimeError, match="POLNOR_TOKEN"):
        Config.from_env()
