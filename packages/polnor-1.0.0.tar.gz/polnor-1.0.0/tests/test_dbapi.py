"""Unit tests for polnor.dbapi (PEP 249) — HTTP-mocked."""

from __future__ import annotations

import pytest
import responses

import polnor.dbapi as dbapi
from polnor.dbapi.cursor import _apply_qmark_params, _sql_literal


def test_module_globals():
    assert dbapi.apilevel == "2.0"
    assert dbapi.threadsafety == 1
    assert dbapi.paramstyle == "qmark"


def test_qmark_substitution_basic():
    assert _apply_qmark_params("SELECT ?", (1,)) == "SELECT 1"
    assert _apply_qmark_params("WHERE a=?", ("x",)) == "WHERE a='x'"
    assert _apply_qmark_params("VALUES (?,?,?)", (1, "x", None)) == "VALUES (1,'x',NULL)"


def test_qmark_substitution_quote_escape():
    """Strings with embedded single quotes must be escaped — not injectable."""
    assert _apply_qmark_params("a=?", ("o'reilly",)) == "a='o''reilly'"


def test_qmark_substitution_bool():
    assert _apply_qmark_params("active=?", (True,)) == "active=TRUE"
    assert _apply_qmark_params("active=?", (False,)) == "active=FALSE"


def test_qmark_substitution_no_params():
    """No params → query unchanged, ? literals preserved."""
    assert _apply_qmark_params("SELECT '?'", None) == "SELECT '?'"


def test_qmark_substitution_count_mismatch():
    with pytest.raises(dbapi.ProgrammingError):
        _apply_qmark_params("? ?", (1,))  # too few
    with pytest.raises(dbapi.ProgrammingError):
        _apply_qmark_params("?", (1, 2))  # too many


def test_sql_literal_bytes():
    assert _sql_literal(b"\x01\x02") == "X'0102'"


def test_sql_literal_unsupported():
    with pytest.raises(dbapi.NotSupportedError):
        _sql_literal(object())


@responses.activate
def test_cursor_execute_fetchall():
    responses.post(
        "https://api.polnor.test/api/v1/sql/execute",
        json={"statement_id": "stmt-1"},
    )
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-1",
        json={"status": "succeeded", "rows_produced": 2, "duration_ms": 5},
    )
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-1/results",
        json={
            "schema": [{"name": "x", "type": "NUMBER"}, {"name": "y", "type": "STRING"}],
            "data": [[1, "a"], [2, "b"]],
        },
    )

    conn = dbapi.connect(token="t", api_url="https://api.polnor.test", warehouse_id="wh-1")
    cur = conn.cursor()
    cur.execute("SELECT * FROM t")
    rows = cur.fetchall()
    assert rows == [(1, "a"), (2, "b")]
    assert cur.description[0][0] == "x"
    assert cur.description[1][0] == "y"
    assert cur.rowcount == 2


@responses.activate
def test_cursor_fetchone_iteration():
    responses.post(
        "https://api.polnor.test/api/v1/sql/execute",
        json={"statement_id": "stmt-2"},
    )
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-2",
        json={"status": "succeeded"},
    )
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-2/results",
        json={"schema": [{"name": "v", "type": "INT"}], "data": [[1], [2], [3]]},
    )
    conn = dbapi.connect(token="t", api_url="https://api.polnor.test", warehouse_id="wh-1")
    cur = conn.cursor()
    cur.execute("SELECT v FROM t")
    assert cur.fetchone() == (1,)
    assert cur.fetchone() == (2,)
    assert cur.fetchone() == (3,)
    assert cur.fetchone() is None
    cur.execute("SELECT v FROM t")
    assert list(cur) == [(1,), (2,), (3,)]


@responses.activate
def test_cursor_execute_with_params():
    """Cursor.execute renders qmark params before submitting."""
    responses.post(
        "https://api.polnor.test/api/v1/sql/execute",
        json={"statement_id": "stmt-3"},
        match=[
            responses.matchers.json_params_matcher({
                "query": "SELECT * FROM t WHERE id=42 AND name='alice'",
                "warehouse_id": "wh-1",
            }),
        ],
    )
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-3",
        json={"status": "succeeded"},
    )
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-3/results",
        json={"schema": [], "data": []},
    )
    conn = dbapi.connect(token="t", api_url="https://api.polnor.test", warehouse_id="wh-1")
    cur = conn.cursor()
    cur.execute("SELECT * FROM t WHERE id=? AND name=?", (42, "alice"))
    assert cur.fetchall() == []


def test_connection_close_blocks_further_use():
    conn = dbapi.connect(token="t", api_url="https://api.polnor.test", warehouse_id="wh-1")
    conn.close()
    with pytest.raises(dbapi.ProgrammingError):
        conn.cursor()


def test_cursor_close_blocks_further_use():
    conn = dbapi.connect(token="t", api_url="https://api.polnor.test", warehouse_id="wh-1")
    cur = conn.cursor()
    cur.close()
    with pytest.raises(dbapi.InterfaceError):
        cur.fetchone()


def test_connect_requires_token(monkeypatch):
    """Empty token + no env + no config → InterfaceError."""
    monkeypatch.delenv("POLNOR_TOKEN", raising=False)
    monkeypatch.delenv("POLNOR_API_URL", raising=False)
    # Also pretend the config file doesn't exist by pointing at /nope
    from polnor import _client
    monkeypatch.setattr(_client, "CONFIG_PATH_TOML", _client.Path("/no/such/file.toml"))
    monkeypatch.setattr(_client, "CONFIG_PATH_INI", _client.Path("/no/such/file"))
    with pytest.raises(dbapi.InterfaceError):
        dbapi.connect()
