"""Unit tests for polnor.sql — HTTP-mocked, no prod call."""

from __future__ import annotations

import pytest
import responses

from polnor._client import Client, Config, reset_default_client, set_token
from polnor.sql import QueryResult, SQLError, sql


@pytest.fixture(autouse=True)
def _clean_default_client():
    reset_default_client()
    yield
    reset_default_client()


@pytest.fixture
def cfg():
    return Config(
        api_url="https://api.polnor.test",
        token="test-token",
        warehouse_id="wh-1",
    )


@responses.activate
def test_sql_succeeded(cfg):
    # Submit
    responses.post(
        "https://api.polnor.test/api/v1/sql/execute",
        json={"statement_id": "stmt-1", "status": "pending"},
    )
    # Poll → succeeded
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-1",
        json={"status": "succeeded", "duration_ms": 42},
    )
    # Results
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-1/results",
        json={
            "schema": [{"name": "x", "type": "NUMBER"}],
            "data": [[1], [2]],
            "rows_produced": 2,
        },
    )

    res = sql("SELECT 1", client=Client(cfg))
    assert isinstance(res, QueryResult)
    assert res.column_names() == ["x"]
    assert res.rows == [[1], [2]]
    assert len(res) == 2
    assert res.to_dicts() == [{"x": 1}, {"x": 2}]


@responses.activate
def test_sql_failed_raises(cfg):
    responses.post(
        "https://api.polnor.test/api/v1/sql/execute",
        json={"statement_id": "stmt-2"},
    )
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-2",
        json={"status": "failed", "error_message": "boom", "error_code": "OOPS"},
    )

    with pytest.raises(SQLError) as exc:
        sql("BAD SQL", client=Client(cfg))
    assert exc.value.statement_id == "stmt-2"
    assert exc.value.code == "OOPS"
    assert "boom" in str(exc.value)


@responses.activate
def test_sql_cancelled_raises(cfg):
    responses.post(
        "https://api.polnor.test/api/v1/sql/execute",
        json={"statement_id": "stmt-3"},
    )
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-3",
        json={"status": "cancelled"},
    )

    with pytest.raises(SQLError, match="cancelled"):
        sql("SELECT 1", client=Client(cfg))


def test_sql_requires_warehouse_id():
    cfg = Config(api_url="https://api.polnor.test", token="t")  # no warehouse_id
    with pytest.raises(SQLError, match="no warehouse_id"):
        sql("SELECT 1", client=Client(cfg))


@responses.activate
def test_sql_empty_results_for_dml(cfg):
    """DML statements (INSERT) yield empty rows but succeed."""
    responses.post(
        "https://api.polnor.test/api/v1/sql/execute",
        json={"statement_id": "stmt-4"},
    )
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-4",
        json={"status": "succeeded", "rows_produced": 0, "duration_ms": 10},
    )
    # /results returns 400 for DML (no rowset)
    responses.get(
        "https://api.polnor.test/api/v1/sql/statements/stmt-4/results",
        json={"error": "results not available"},
        status=400,
    )

    res = sql("INSERT INTO t VALUES (1)", client=Client(cfg))
    assert res.rows == []
    assert res.columns == []


@responses.activate
def test_set_token_overrides_default(cfg):
    responses.post(
        "https://api.polnor.com/api/v1/sql/execute",
        json={"statement_id": "stmt-5"},
    )
    responses.get(
        "https://api.polnor.com/api/v1/sql/statements/stmt-5",
        json={"status": "succeeded"},
    )
    responses.get(
        "https://api.polnor.com/api/v1/sql/statements/stmt-5/results",
        json={"schema": [], "data": []},
    )
    set_token("new-token", api_url="https://api.polnor.com", warehouse_id="wh-2")
    res = sql("SELECT 1")
    assert res.statement_id == "stmt-5"
