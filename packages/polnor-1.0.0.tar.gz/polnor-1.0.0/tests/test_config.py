"""Unit tests for polnor._client Config (env + TOML + INI resolution)."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from polnor._client import Config, PolnorConfigError


def test_config_from_env(monkeypatch):
    monkeypatch.setenv("POLNOR_API_URL", "https://api.polnor.com")
    monkeypatch.setenv("POLNOR_TOKEN", "tok-abc")
    monkeypatch.setenv("POLNOR_WAREHOUSE_ID", "wh-1")
    cfg = Config.from_env()
    assert cfg.api_url == "https://api.polnor.com"
    assert cfg.token == "tok-abc"
    assert cfg.warehouse_id == "wh-1"


def test_config_from_env_strips_trailing_slash(monkeypatch):
    monkeypatch.setenv("POLNOR_API_URL", "https://api.polnor.com/")
    monkeypatch.setenv("POLNOR_TOKEN", "tok-abc")
    cfg = Config.from_env()
    assert cfg.api_url == "https://api.polnor.com"


def test_config_from_env_missing_token(monkeypatch):
    monkeypatch.setenv("POLNOR_API_URL", "https://api.polnor.com")
    monkeypatch.delenv("POLNOR_TOKEN", raising=False)
    with pytest.raises(PolnorConfigError, match="POLNOR_TOKEN"):
        Config.from_env()


def test_config_from_toml_flat(tmp_path: Path):
    p = tmp_path / "config.toml"
    p.write_text(
        'host = "https://api.polnor.com"\n'
        'token = "tok-toml"\n'
        'workspace_id = "ws-1"\n'
        'warehouse_id = "wh-2"\n'
    )
    cfg = Config.from_file(p)
    assert cfg.api_url == "https://api.polnor.com"
    assert cfg.token == "tok-toml"
    assert cfg.workspace_slug == "ws-1"  # mapped from workspace_id
    assert cfg.warehouse_id == "wh-2"


def test_config_from_toml_profile(tmp_path: Path):
    p = tmp_path / "config.toml"
    p.write_text(
        '[default]\nhost = "https://default"\ntoken = "default-tok"\n\n'
        '[prod]\nhost = "https://prod"\ntoken = "prod-tok"\n'
    )
    cfg = Config.from_file(p, profile="prod")
    assert cfg.token == "prod-tok"
    assert cfg.api_url == "https://prod"


def test_config_from_ini_legacy(tmp_path: Path):
    """Legacy INI config (V0 SDK) must still load via Config.from_file."""
    p = tmp_path / "config"  # no extension → INI
    p.write_text(
        "[DEFAULT]\n"
        "api_url = https://api.polnor.com\n"
        "token = tok-ini\n"
        "workspace_slug = ws-a\n"
        "warehouse_id = wh-3\n"
    )
    cfg = Config.from_file(p)
    assert cfg.api_url == "https://api.polnor.com"
    assert cfg.token == "tok-ini"
    assert cfg.workspace_slug == "ws-a"
    assert cfg.warehouse_id == "wh-3"


def test_config_from_file_missing(tmp_path: Path):
    with pytest.raises(PolnorConfigError, match="not found"):
        Config.from_file(tmp_path / "nope.toml")


def test_resolve_prefers_env(monkeypatch, tmp_path: Path):
    """Env vars beat config file when both present."""
    p = tmp_path / "config.toml"
    p.write_text('host = "https://file"\ntoken = "from-file"\n')
    monkeypatch.setenv("POLNOR_API_URL", "https://env")
    monkeypatch.setenv("POLNOR_TOKEN", "from-env")
    # Even with a file present, env wins
    cfg = Config.resolve()
    assert cfg.token == "from-env"
    assert cfg.api_url == "https://env"
