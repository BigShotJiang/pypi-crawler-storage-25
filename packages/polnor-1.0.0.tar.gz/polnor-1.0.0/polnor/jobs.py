"""Job + Run resource — orchestrate task DAGs.

A job is a *template* (1 or N tasks with depends_on relations).
A run is an execution of that template (each task → a task_run).

Multi-task DAG (migs 094-096 server side) :

    polnor.jobs.create(name="etl", tasks=[
        {"key": "extract", "command": "python extract.py", "image": "python:3.11"},
        {"key": "transform", "command": "python transform.py", "image": "python:3.11",
         "depends_on": ["extract"]},
    ])
    run_id = polnor.jobs.run("etl")
    polnor.jobs.wait(run_id)       # block until terminal
    print(polnor.jobs.logs(run_id))
"""

from __future__ import annotations

import builtins
import time
from typing import Any

from ._client import Client, get_default_client
from ._resource import get_resource, list_resource, post_action

_PATH = "/jobs"
_RUN_PATH = "/runs"
_TERMINAL_RUN = {"success", "failed", "cancelled", "skipped"}


def list(*, client: Client | None = None) -> builtins.list[dict]:
    """List jobs in the workspace."""
    return list_resource(_PATH, client=client)


def get(name_or_id: str, *, client: Client | None = None) -> dict:
    """Fetch one job by id or name."""
    return get_resource(_PATH, name_or_id, client=client)


def create(
    *,
    name: str,
    description: str = "",
    command: str | None = None,
    image: str | None = None,
    tasks: builtins.list[dict] | None = None,
    schedule: str | None = None,
    env_vars: dict[str, str] | None = None,
    timeout_seconds: int | None = None,
    max_retries: int | None = None,
    client: Client | None = None,
) -> dict:
    """Create a job.

    Two modes :

    - Single-command (legacy) : pass ``command`` and ``image``.
    - DAG : pass ``tasks=[{key, command, image, depends_on=[...]}]``.

    When both are passed, ``tasks`` wins and ``command`` is ignored.
    """
    c = client or get_default_client()
    payload: dict[str, Any] = {"name": name, "description": description}
    if tasks is not None:
        payload["tasks"] = tasks
    else:
        if command is None or image is None:
            raise ValueError("create(): either tasks=[...] or command+image required")
        payload["command"] = command
        payload["image"] = image
    if schedule:
        payload["schedule"] = schedule
    if env_vars:
        payload["env_vars"] = env_vars
    if timeout_seconds is not None:
        payload["timeout_seconds"] = timeout_seconds
    if max_retries is not None:
        payload["max_retries"] = max_retries
    return c.post(_PATH, json=payload)


def delete(name_or_id: str, *, client: Client | None = None) -> None:
    """Delete a job (and its history of runs)."""
    c = client or get_default_client()
    job = get(name_or_id, client=c)
    c.delete(f"{_PATH}/{job['id']}")


def run(name_or_id: str, *, params: dict | None = None,
        client: Client | None = None) -> str:
    """Trigger a new run. Returns the ``run_id``.

    ``params`` is passed as-is to the run (job tasks can access them).
    """
    c = client or get_default_client()
    job = get(name_or_id, client=c)
    body = c.post(f"{_PATH}/{job['id']}/run", json={"params": params or {}})
    return body.get("run_id") or body.get("id") or ""


def get_run(run_id: str, *, client: Client | None = None) -> dict:
    """Fetch the run row."""
    c = client or get_default_client()
    return c.get(f"{_RUN_PATH}/{run_id}")


def cancel_run(run_id: str, *, client: Client | None = None) -> dict:
    """Request cancellation of a running run."""
    return post_action(_RUN_PATH, f"{run_id}/cancel", client=client)


def list_tasks(run_id: str, *, client: Client | None = None) -> builtins.list[dict]:
    """List task_runs for this run (empty list for single-command runs)."""
    c = client or get_default_client()
    body = c.get(f"{_RUN_PATH}/{run_id}/tasks")
    if isinstance(body, builtins.list):
        return body
    return body.get("data") or [] if isinstance(body, dict) else []


def logs(run_id: str, *, task_key: str | None = None, tail: int = 500,
         client: Client | None = None) -> builtins.list[dict]:
    """Fetch run logs. With ``task_key``, only that task's logs."""
    c = client or get_default_client()
    if task_key:
        body = c.get(f"{_RUN_PATH}/{run_id}/tasks/{task_key}/logs", params={"tail": tail})
    else:
        body = c.get(f"{_RUN_PATH}/{run_id}/logs", params={"tail": tail})
    if isinstance(body, builtins.list):
        return body
    return body.get("data") or body.get("logs") or [] if isinstance(body, dict) else []


def wait(run_id: str, *, timeout: float = 3600.0, poll_every: float = 5.0,
         client: Client | None = None) -> dict:
    """Block until the run reaches a terminal state or ``timeout``."""
    deadline = time.monotonic() + timeout
    last: dict = {}
    while time.monotonic() < deadline:
        last = get_run(run_id, client=client)
        status = last.get("status") or ""
        if status in _TERMINAL_RUN:
            return last
        time.sleep(poll_every)
    return last
