"""SQL surface — `polnor.sql("SELECT ...")` style queries.

Targets the control-plane endpoint ``POST /sql/execute`` which dispatches
to the warehouse's DuckDB sidecar (reads) or Spark sidecar (writes).
Submission is asynchronous; this module polls the statement until
terminal then fetches the result set.

Usage::

    import polnor
    df = polnor.sql("SELECT * FROM polnor.demo.default.orders LIMIT 5")
    polnor.sql("INSERT INTO polnor.demo.default.orders VALUES (1, 'alice')")
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, List

from ._client import Client, PolnorAPIError, get_default_client


class SQLError(RuntimeError):
    """Raised when a SQL statement fails or times out."""

    def __init__(self, message: str, *, statement_id: str | None = None, code: str | None = None):
        super().__init__(message)
        self.statement_id = statement_id
        self.code = code


@dataclass
class QueryResult:
    """Decoded /sql/statements/{id}/results payload.

    ``rows`` is a list of lists (cell order matches ``columns``).
    ``columns`` is a list of ``{"name": str, "type": str}``.

    The object is iterable and indexable like a list of rows, so the
    most common idioms work:

        for row in result: ...
        first = result[0]
        n = len(result)
    """

    statement_id: str
    columns: List[dict]
    rows: List[list]
    rows_produced: int = 0
    duration_ms: int = 0

    # --- Pythonic conveniences ---

    def __iter__(self):
        return iter(self.rows)

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, idx):
        return self.rows[idx]

    def column_names(self) -> List[str]:
        return [c["name"] for c in self.columns]

    def to_pandas(self):
        """Return a pandas DataFrame. Lazy import — pandas isn't required."""
        try:
            import pandas as pd
        except ImportError as e:  # pragma: no cover
            raise ImportError(
                "to_pandas() needs pandas: `pip install pandas`"
            ) from e
        return pd.DataFrame(self.rows, columns=self.column_names())

    def to_dicts(self) -> List[dict]:
        """Return rows as list of dicts keyed by column name."""
        names = self.column_names()
        return [dict(zip(names, r)) for r in self.rows]

    # IPython / Jupyter rich display — show as a pandas table if pandas
    # is installed, otherwise fall back to a plain repr.
    def _repr_html_(self) -> str:
        try:
            import pandas as pd  # noqa: F401
        except ImportError:
            return ""
        return self.to_pandas()._repr_html_()

    def __repr__(self) -> str:  # pragma: no cover
        preview = self.rows[:5]
        more = f" (+{len(self.rows) - 5} more)" if len(self.rows) > 5 else ""
        return (
            f"QueryResult(cols={self.column_names()}, "
            f"rows={len(self.rows)}{more}, duration_ms={self.duration_ms})"
        )


# Default polling parameters — kept conservative so a query that returns
# in 200ms doesn't waste an extra second sleeping.
_INITIAL_POLL_INTERVAL = 0.2
_MAX_POLL_INTERVAL = 2.0
_DEFAULT_TIMEOUT_S = 300.0


def sql(
    query: str,
    *,
    warehouse_id: str | None = None,
    schema: str | None = None,
    timeout: float = _DEFAULT_TIMEOUT_S,
    client: Client | None = None,
) -> QueryResult:
    """Run a SQL statement on a Polnor SQL warehouse and return the result.

    ``warehouse_id`` falls back to ``POLNOR_WAREHOUSE_ID`` env var or the
    one set in ``~/.polnor/config``. If none is configured the call
    raises a SQLError telling the caller to set one.

    The function blocks until the statement reaches a terminal state
    (succeeded / failed) or ``timeout`` seconds elapse.
    """
    c = client or get_default_client()
    wh_id = warehouse_id or c.cfg.warehouse_id
    if not wh_id:
        raise SQLError(
            "polnor.sql: no warehouse_id — pass warehouse_id=... or set "
            "POLNOR_WAREHOUSE_ID in env / config file."
        )

    payload: dict[str, Any] = {"query": query, "warehouse_id": wh_id}
    if schema:
        payload["schema"] = schema

    submit = c.post("/sql/execute", json=payload)
    statement_id = submit.get("statement_id")
    if not statement_id:
        raise SQLError(
            f"polnor.sql: submit returned no statement_id: {submit}",
        )

    return _poll_statement(c, statement_id, timeout=timeout)


def _poll_statement(c: Client, statement_id: str, *, timeout: float) -> QueryResult:
    """Poll /sql/statements/{id} until terminal, then fetch results."""
    deadline = time.monotonic() + timeout
    interval = _INITIAL_POLL_INTERVAL
    last_status: str = "pending"

    while time.monotonic() < deadline:
        st = c.get(f"/sql/statements/{statement_id}")
        last_status = st.get("status") or "unknown"
        if last_status == "succeeded":
            return _fetch_results(c, statement_id, st)
        if last_status == "failed":
            raise SQLError(
                st.get("error_message") or "statement failed",
                statement_id=statement_id,
                code=st.get("error_code"),
            )
        if last_status == "cancelled":
            raise SQLError(
                "statement was cancelled",
                statement_id=statement_id,
            )
        time.sleep(interval)
        # Backoff so a long-running query doesn't hammer the control plane,
        # but cap so we still wake up quickly when it finishes.
        interval = min(interval * 1.5, _MAX_POLL_INTERVAL)

    raise SQLError(
        f"statement {statement_id} did not finish within {timeout:.0f}s "
        f"(last status: {last_status})",
        statement_id=statement_id,
    )


def _fetch_results(c: Client, statement_id: str, statement_meta: dict) -> QueryResult:
    """Pull the result page. Empty data ⇒ empty rows but valid result."""
    try:
        body = c.get(f"/sql/statements/{statement_id}/results")
    except PolnorAPIError as e:
        # 400 with "results not available" means DDL/INSERT — no rows.
        if e.status in (400, 404):
            return QueryResult(
                statement_id=statement_id,
                columns=[],
                rows=[],
                rows_produced=int(statement_meta.get("rows_produced") or 0),
                duration_ms=int(statement_meta.get("duration_ms") or 0),
            )
        raise
    return QueryResult(
        statement_id=statement_id,
        columns=body.get("schema") or [],
        rows=body.get("data") or [],
        rows_produced=int(body.get("rows_produced") or 0),
        duration_ms=int(statement_meta.get("duration_ms") or 0),
    )
