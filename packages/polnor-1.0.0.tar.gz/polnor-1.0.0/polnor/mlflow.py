"""MLflow-compatible tracking surface for Polnor.

Drop-in shim for the bits of MLflow most jobs use::

    from polnor import mlflow

    with mlflow.start_run() as run:
        mlflow.log_param("learning_rate", 0.01)
        mlflow.log_param("optimizer", "adam")

        for epoch in range(10):
            mlflow.log_metric("loss", train_loss, step=epoch)
            mlflow.log_metric("accuracy", val_acc, step=epoch)

        mlflow.set_tag("git_commit", os.environ["CI_COMMIT_SHA"])

The active run is stored in a thread-local so nested calls in the
same job don't fight over a global; calling ``start_run`` twice
without ``end_run`` between them stacks runs the way MLflow's nested
runs do.

The following MLflow API is *not* implemented yet and will raise
``NotImplementedError``:

* ``log_artifact`` — needs a presigned-URL upload flow
* ``log_image`` / ``log_dict`` — derived from artifacts
* ``mlflow.search_runs`` — read-side, use the REST API directly

Server-side, metrics are stored as the *latest* value per key (JSONB
merge). A full time-series of ``(step, value, timestamp)`` per metric
is tracked separately in a future migration; until then,
``log_metric(..., step=...)`` records the value but not the step.
"""

from __future__ import annotations

import contextlib
import os
import threading
from dataclasses import dataclass
from typing import Any, Iterator, Mapping

from ._client import Client


# Thread-local stack of active runs; supports the nested-run pattern
# used by frameworks that spawn child runs per CV fold.
_local = threading.local()


def _stack() -> list["ActiveRun"]:
    if not hasattr(_local, "runs"):
        _local.runs = []
    return _local.runs


def _client() -> Client:
    """Single Client per thread, lazily constructed.

    Reusing the same Session across calls means TLS handshakes and
    auth resolution amortize across log_metric calls in a tight loop.
    """
    if not hasattr(_local, "client"):
        _local.client = Client()
    return _local.client


@dataclass
class ActiveRun:
    """Handle to a running experiment_run on the server.

    Returned by :func:`start_run`; usable as a context manager so the
    run is finalized on scope exit even when an exception escapes.
    """

    experiment_id: str
    run_id: str
    name: str

    def __enter__(self) -> "ActiveRun":
        _stack().append(self)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        # End with status='failed' when an exception escaped, otherwise
        # 'completed'. Errors in end_run itself are swallowed so they
        # don't replace the user's exception.
        status = "failed" if exc_type is not None else "completed"
        try:
            end_run(status=status)
        except Exception:
            pass


def _experiment_id_from_env() -> str:
    exp_id = os.environ.get("POLNOR_EXPERIMENT_ID")
    if not exp_id:
        raise RuntimeError(
            "No active experiment. Either:\n"
            "  - export POLNOR_EXPERIMENT_ID=<uuid>, or\n"
            "  - call mlflow.start_run(experiment_id=...)."
        )
    return exp_id


def start_run(
    *,
    experiment_id: str | None = None,
    run_name: str | None = None,
    params: Mapping[str, Any] | None = None,
    tags: Mapping[str, str] | None = None,
) -> ActiveRun:
    """Start a new run and make it the active one.

    The returned :class:`ActiveRun` is usable as a context manager. If
    ``experiment_id`` is omitted, ``POLNOR_EXPERIMENT_ID`` is used.
    """
    exp_id = experiment_id or _experiment_id_from_env()
    body: dict[str, Any] = {}
    if run_name:
        body["name"] = run_name
    if params:
        body["params"] = dict(params)
    if tags:
        body["tags"] = dict(tags)
    resp = _client().post(f"/experiments/{exp_id}/runs", body)
    run = ActiveRun(experiment_id=exp_id, run_id=resp["id"], name=resp.get("name", ""))
    _stack().append(run)
    return run


def active_run() -> ActiveRun | None:
    """Return the run on top of the active stack, or None."""
    s = _stack()
    return s[-1] if s else None


def _require_active() -> ActiveRun:
    run = active_run()
    if run is None:
        raise RuntimeError("No active run. Call start_run() first.")
    return run


def end_run(status: str = "completed") -> None:
    """Finish the active run with the given status.

    Pops the top of the active stack — nested runs continue to use the
    next-outer parent.
    """
    s = _stack()
    if not s:
        return  # no-op when called outside a run
    run = s.pop()
    _client().patch(
        f"/experiments/{run.experiment_id}/runs/{run.run_id}",
        {"status": status},
    )


def log_metric(key: str, value: float, step: int | None = None) -> None:
    """Record a single metric value on the active run.

    ``step`` is accepted for MLflow API compatibility but currently
    ignored server-side (latest-value-wins). The server will track
    full history once the per-step migration lands.
    """
    run = _require_active()
    body: dict[str, Any] = {"key": key, "value": float(value)}
    if step is not None:
        body["step"] = int(step)
    _client().post(
        f"/experiments/{run.experiment_id}/runs/{run.run_id}/metrics",
        body,
    )


def log_metrics(metrics: Mapping[str, float], step: int | None = None) -> None:
    """Batch variant — single round-trip per dict."""
    run = _require_active()
    _client().post(
        f"/experiments/{run.experiment_id}/runs/{run.run_id}/metrics/batch",
        {"metrics": {k: float(v) for k, v in metrics.items()}},
    )
    _ = step  # see log_metric for why we accept-and-ignore


def log_param(key: str, value: Any) -> None:
    """Record a hyperparameter on the active run."""
    run = _require_active()
    _client().post(
        f"/experiments/{run.experiment_id}/runs/{run.run_id}/params",
        {"key": key, "value": value},
    )


def log_params(params: Mapping[str, Any]) -> None:
    """Convenience: log_param in a loop."""
    for k, v in params.items():
        log_param(k, v)


def set_tag(key: str, value: str) -> None:
    run = _require_active()
    _client().post(
        f"/experiments/{run.experiment_id}/runs/{run.run_id}/tags",
        {"key": key, "value": str(value)},
    )


def set_tags(tags: Mapping[str, str]) -> None:
    for k, v in tags.items():
        set_tag(k, v)


def log_artifact(local_path: str, artifact_path: str | None = None) -> None:
    """Upload a local file as an artifact of the active run.

    Two-step flow: ask the server for a presigned PUT URL, then
    stream the file to S3 directly. The server records the artifact
    path in the run's JSONB ``artifacts`` list. Files larger than
    ~100 MB should ideally be chunked; we send a single PUT here and
    let the underlying TLS connection take care of the streaming.
    """
    import os
    if not os.path.isfile(local_path):
        raise FileNotFoundError(local_path)
    target = artifact_path or os.path.basename(local_path)
    run = _require_active()
    presign = _client().post(
        f"/experiments/{run.experiment_id}/runs/{run.run_id}/artifacts/presigned-url",
        {"path": target, "content_type": "application/octet-stream"},
    )
    upload_url = presign["upload_url"]

    # We bypass the SDK's auth-bearing Session for the actual PUT —
    # presigned URLs carry their own signature and don't accept the
    # Polnor Bearer header. Use a stripped-down requests call.
    import requests
    with open(local_path, "rb") as f:
        resp = requests.put(upload_url, data=f, timeout=300)
    if resp.status_code >= 400:
        raise RuntimeError(
            f"artifact upload failed ({resp.status_code}): {resp.text[:200]}"
        )


def get_metric_history(key: str) -> list[dict]:
    """Return every (step, value, timestamp) observation for a metric
    on the active run. Useful for building local plots or comparing
    across runs.
    """
    run = _require_active()
    resp = _client().get(
        f"/experiments/{run.experiment_id}/runs/{run.run_id}/metrics/{key}"
    )
    return resp.get("data", [])


@contextlib.contextmanager
def autolog(framework: str | None = None) -> Iterator[None]:
    """Lightweight autolog: open a run on enter, close on exit.

    The full MLflow autolog hooks (sklearn estimator inspection, etc.)
    aren't here yet. This context just gives users the convenient
    ``with mlflow.autolog():`` shape that frameworks tend to wrap.
    """
    run = start_run()
    if framework:
        try:
            set_tag("autolog.framework", framework)
        except Exception:
            pass
    try:
        yield
    finally:
        try:
            end_run("completed")
        except Exception:
            # Make sure the stack stays clean even if the network call fails.
            s = _stack()
            if s and s[-1] is run:
                s.pop()


__all__ = [
    "ActiveRun",
    "start_run",
    "end_run",
    "active_run",
    "log_metric",
    "log_metrics",
    "log_param",
    "log_params",
    "set_tag",
    "set_tags",
    "log_artifact",
    "get_metric_history",
    "autolog",
]
