"""Model registry resource — manage models and their versions.

Polnor's model registry is MLflow-compatible (mig 113). Use this module
for CRUD on models / versions; for inference deployment see
:mod:`polnor.endpoints`.
"""

from __future__ import annotations

import builtins
from typing import Any

from ._client import Client, get_default_client
from ._resource import get_resource, list_resource

_PATH = "/models"


def list(*, client: Client | None = None) -> builtins.list[dict]:
    """List models in the workspace."""
    return list_resource(_PATH, client=client)


def get(name_or_id: str, *, client: Client | None = None) -> dict:
    """Fetch one model by id or name."""
    return get_resource(_PATH, name_or_id, client=client)


def create(
    *,
    name: str,
    description: str = "",
    framework: str | None = None,
    tags: dict[str, str] | None = None,
    client: Client | None = None,
) -> dict:
    """Register a new model name in the workspace."""
    c = client or get_default_client()
    payload: dict[str, Any] = {"name": name, "description": description}
    if framework:
        payload["framework"] = framework
    if tags:
        payload["tags"] = tags
    return c.post(_PATH, json=payload)


def delete(name_or_id: str, *, client: Client | None = None) -> None:
    """Delete a model and all its versions."""
    c = client or get_default_client()
    m = get(name_or_id, client=c)
    c.delete(f"{_PATH}/{m['id']}")


def list_versions(name_or_id: str, *, client: Client | None = None) -> builtins.list[dict]:
    """List all versions of a model."""
    c = client or get_default_client()
    m = get(name_or_id, client=c)
    body = c.get(f"{_PATH}/{m['id']}/versions")
    if isinstance(body, builtins.list):
        return body
    return body.get("data") or [] if isinstance(body, dict) else []


def create_version(
    name_or_id: str,
    *,
    artifact_uri: str,
    description: str = "",
    framework: str | None = None,
    tags: dict[str, str] | None = None,
    client: Client | None = None,
) -> dict:
    """Register a new version of a model pointing at an S3 artifact URI."""
    c = client or get_default_client()
    m = get(name_or_id, client=c)
    payload: dict[str, Any] = {
        "artifact_uri": artifact_uri,
        "description": description,
    }
    if framework:
        payload["framework"] = framework
    if tags:
        payload["tags"] = tags
    return c.post(f"{_PATH}/{m['id']}/versions", json=payload)


def get_version(name_or_id: str, version: int | str, *,
                client: Client | None = None) -> dict:
    """Fetch one version of a model by version number or version_id."""
    c = client or get_default_client()
    m = get(name_or_id, client=c)
    return c.get(f"{_PATH}/{m['id']}/versions/{version}")
