"""Warehouse resource API — list / get / start / stop / pick default.

Mirrors the Databricks SDK's ``client.warehouses`` namespace. Every
function returns plain dicts (the API's JSON response) so the SDK stays
thin and the user can pick whatever fields they need.

Usage::

    import polnor
    for wh in polnor.warehouses.list():
        print(wh["name"], wh["status"])

    polnor.warehouses.start("sql-w")           # by name OR id
    info = polnor.warehouses.get("sql-w")
    print(info["ip_address"])
"""

from __future__ import annotations

import builtins
import time
from typing import Iterable

from ._client import Client, PolnorAPIError, get_default_client


# Treat these as "available for queries" so default() returns one quickly.
_USABLE_STATUSES = {"running"}
_TERMINAL_STATUSES = {"running", "stopped", "error", "deleted"}


def list(*, client: Client | None = None) -> builtins.list[dict]:
    """List every warehouse in the current workspace.

    Returns a list of dicts straight from ``GET /sql/warehouses``.

    (We shadow the builtin ``list`` here on purpose so the surface reads
    ``polnor.warehouses.list()`` Databricks-style; the body still
    references ``builtins.list`` for type checks.)
    """
    c = client or get_default_client()
    body = c.get("/sql/warehouses")
    if isinstance(body, builtins.list):
        return body
    return body.get("data") or body.get("warehouses") or []


def get(name_or_id: str, *, client: Client | None = None) -> dict:
    """Return one warehouse. Accepts the UUID or the name.

    Falls back to scanning the list when the API doesn't accept names
    directly (the backend handles either, but older builds may not).
    """
    c = client or get_default_client()
    try:
        return c.get(f"/sql/warehouses/{name_or_id}")
    except PolnorAPIError as e:
        if e.status == 404:
            for wh in list(client=c):
                if wh.get("id") == name_or_id or wh.get("name") == name_or_id:
                    return wh
        raise


def start(name_or_id: str, *, wait: bool = True, timeout: float = 600.0,
          client: Client | None = None) -> dict:
    """Start a stopped warehouse. With ``wait=True`` (default), blocks
    until the warehouse reaches a terminal state or ``timeout`` elapses.

    The POST is idempotent server-side — calling it on a running
    warehouse returns the current state without re-provisioning.
    """
    c = client or get_default_client()
    wh = get(name_or_id, client=c)
    wh_id = wh["id"]

    c.post(f"/sql/warehouses/{wh_id}/start")
    if not wait:
        return get(wh_id, client=c)
    return _wait_for_status(c, wh_id, _USABLE_STATUSES, timeout=timeout)


def stop(name_or_id: str, *, wait: bool = True, timeout: float = 300.0,
         client: Client | None = None) -> dict:
    """Stop a running warehouse. Returns the final dict."""
    c = client or get_default_client()
    wh = get(name_or_id, client=c)
    wh_id = wh["id"]
    c.post(f"/sql/warehouses/{wh_id}/stop")
    if not wait:
        return get(wh_id, client=c)
    return _wait_for_status(c, wh_id, {"stopped", "error"}, timeout=timeout)


def default(*, client: Client | None = None) -> dict | None:
    """Best-effort: return a usable warehouse for ``polnor.sql`` to target.

    Prefers the one configured via env / config file. Falls back to the
    first warehouse whose status is "running"; ``None`` if nothing is up.

    Callers that need a *specific* warehouse should pass ``warehouse_id``
    explicitly to ``polnor.sql`` instead of relying on this.
    """
    c = client or get_default_client()
    if c.cfg.warehouse_id:
        try:
            return get(c.cfg.warehouse_id, client=c)
        except PolnorAPIError:
            pass
    for wh in list(client=c):
        if wh.get("status") in _USABLE_STATUSES:
            return wh
    return None


# --- internals ---

def _wait_for_status(c: Client, wh_id: str, accept: Iterable[str], *,
                     timeout: float) -> dict:
    accept_set = set(accept) | _TERMINAL_STATUSES
    deadline = time.monotonic() + timeout
    last = {"status": "unknown"}
    while time.monotonic() < deadline:
        last = get(wh_id, client=c)
        status = last.get("status") or "unknown"
        if status in accept_set:
            return last
        time.sleep(5.0)
    return last
