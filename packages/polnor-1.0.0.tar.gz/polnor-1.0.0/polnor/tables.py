"""Catalog resource — databases (Iceberg namespaces) and tables.

Polnor's catalog is backed by Lakekeeper (Iceberg REST). This module
talks to Polnor's API which proxies to Lakekeeper + maintains a shadow
PG index for fast listing / search.
"""

from __future__ import annotations

import builtins
from typing import Any

from ._client import Client, get_default_client
from ._resource import list_resource

_DB_PATH = "/databases"


def list_databases(*, client: Client | None = None) -> builtins.list[dict]:
    """List databases (Iceberg namespaces) in the workspace."""
    return list_resource(_DB_PATH, client=client)


def create_database(
    *,
    name: str,
    description: str = "",
    location: str | None = None,
    client: Client | None = None,
) -> dict:
    """Create a new database/namespace.

    If ``location`` is omitted, Lakekeeper auto-builds one under the
    workspace's storage bucket root.
    """
    c = client or get_default_client()
    payload: dict[str, Any] = {"name": name, "description": description}
    if location:
        payload["location"] = location
    return c.post(_DB_PATH, json=payload)


def get_database(name: str, *, client: Client | None = None) -> dict:
    """Fetch one database by name."""
    c = client or get_default_client()
    return c.get(f"{_DB_PATH}/{name}")


def delete_database(name: str, *, client: Client | None = None) -> None:
    """Drop a database. The Iceberg namespace must be empty (or use cascade)."""
    c = client or get_default_client()
    c.delete(f"{_DB_PATH}/{name}")


def list(database_name: str, *, client: Client | None = None) -> builtins.list[dict]:
    """List tables in a database."""
    c = client or get_default_client()
    body = c.get(f"{_DB_PATH}/{database_name}/tables")
    if isinstance(body, builtins.list):
        return body
    return body.get("data") or body.get("tables") or [] if isinstance(body, dict) else []


def get(database_name: str, table_name: str, *, client: Client | None = None) -> dict:
    """Fetch one table's metadata (location, columns, snapshot, etc.)."""
    c = client or get_default_client()
    return c.get(f"{_DB_PATH}/{database_name}/tables/{table_name}")


def create(
    database_name: str,
    table_name: str,
    *,
    columns: builtins.list[dict],
    description: str = "",
    partition_columns: builtins.list[str] | None = None,
    properties: dict[str, str] | None = None,
    client: Client | None = None,
) -> dict:
    """Create a new Iceberg table.

    ``columns`` is a list of ``{"name": str, "type": str, "nullable": bool}``
    where type is one of: ``long``, ``int``, ``string``, ``double``,
    ``boolean``, ``timestamp``, ``date``, ``binary``.

    Example::

        polnor.tables.create("demo", "users",
            columns=[
                {"name": "id", "type": "long", "nullable": False},
                {"name": "email", "type": "string"},
                {"name": "created_at", "type": "timestamp"},
            ],
        )
    """
    c = client or get_default_client()
    payload: dict[str, Any] = {
        "name": table_name,
        "description": description,
        "columns": columns,
    }
    if partition_columns:
        payload["partition_columns"] = partition_columns
    if properties:
        payload["properties"] = properties
    return c.post(f"{_DB_PATH}/{database_name}/tables", json=payload)


def delete(database_name: str, table_name: str, *, client: Client | None = None) -> None:
    """Drop a table. Polnor purges metadata + data files in S3."""
    c = client or get_default_client()
    c.delete(f"{_DB_PATH}/{database_name}/tables/{table_name}")
