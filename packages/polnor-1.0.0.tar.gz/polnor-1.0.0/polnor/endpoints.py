"""Serving endpoint resource — deploy models and run predictions.

V1 model: the user provides a Docker image that exposes ``/predict``.
The backend dispatches it to an agent which ``docker run``s the image
on the compute VM. Once healthy, ``endpoints.predict()`` proxies HTTP
to the container's ``/predict``.

This module covers create / deploy / predict / stop / scale. Logs +
metrics also available.
"""

from __future__ import annotations

import builtins
from typing import Any

from ._client import Client, get_default_client
from ._resource import get_resource, list_resource, post_action, wait_for_status

_PATH = "/endpoints"
_READY = {"ready", "running"}
_TERMINAL = {"ready", "running", "stopped", "error"}


def list(*, client: Client | None = None) -> builtins.list[dict]:
    """List endpoints in the workspace."""
    return list_resource(_PATH, client=client)


def get(name_or_id: str, *, client: Client | None = None) -> dict:
    """Fetch one endpoint by id or name."""
    return get_resource(_PATH, name_or_id, client=client)


def create(
    *,
    name: str,
    image: str,
    model_version_id: str | None = None,
    min_replicas: int = 1,
    max_replicas: int = 1,
    instance_type: str = "cpu-small",
    gpu_type: str | None = None,
    environment: dict[str, str] | None = None,
    tags: dict[str, str] | None = None,
    auto_update: bool = False,
    client: Client | None = None,
) -> dict:
    """Create an endpoint pointing at a Docker image that exposes /predict.

    Set ``environment={"IMAGE": ..., "CONTAINER_PORT": "8080"}`` to tell
    the deployer which image to launch and what port it listens on.
    """
    c = client or get_default_client()
    env = dict(environment or {})
    env.setdefault("IMAGE", image)
    payload: dict[str, Any] = {
        "name": name,
        "min_replicas": min_replicas,
        "max_replicas": max_replicas,
        "instance_type": instance_type,
        "environment": env,
        "auto_update": auto_update,
    }
    if model_version_id:
        payload["model_version_id"] = model_version_id
    if gpu_type:
        payload["gpu_type"] = gpu_type
    if tags:
        payload["tags"] = tags
    return c.post(_PATH, json=payload)


def deploy(name_or_id: str, *, wait: bool = True, timeout: float = 600.0,
           client: Client | None = None) -> dict:
    """Trigger deployment. Server picks an agent with ``inference``
    capability and ``docker run``s the image on it.

    With ``wait=True``, blocks until status=ready (URL populated)
    or ``timeout`` elapses.
    """
    ep = get(name_or_id, client=client)
    post_action(_PATH, f"{ep['id']}/start", client=client)
    if not wait:
        return get(ep["id"], client=client)
    return wait_for_status(
        None, get_fn=get, name_or_id=ep["id"],
        target=_READY, terminal=_TERMINAL, timeout=timeout, client=client,
    )


def stop(name_or_id: str, *, wait: bool = True, timeout: float = 120.0,
         client: Client | None = None) -> dict:
    """Stop the endpoint container. The endpoint row stays."""
    ep = get(name_or_id, client=client)
    post_action(_PATH, f"{ep['id']}/stop", client=client)
    if not wait:
        return get(ep["id"], client=client)
    return wait_for_status(
        None, get_fn=get, name_or_id=ep["id"],
        target={"stopped"}, terminal=_TERMINAL, timeout=timeout, client=client,
    )


def delete(name_or_id: str, *, client: Client | None = None) -> None:
    """Delete the endpoint (also stops the container if running)."""
    c = client or get_default_client()
    ep = get(name_or_id, client=c)
    c.delete(f"{_PATH}/{ep['id']}")


def predict(name_or_id: str, inputs: Any, *, client: Client | None = None) -> dict:
    """Send ``{"inputs": ...}`` to the endpoint's /predict and return the response.

    The shape of ``inputs`` depends on the user's model image. For an
    sklearn-style API, typically a list of feature vectors.
    """
    c = client or get_default_client()
    ep = get(name_or_id, client=c)
    return c.post(f"{_PATH}/{ep['id']}/predict", json={"inputs": inputs})


def scale(name_or_id: str, *, replicas: int, client: Client | None = None) -> dict:
    """Scale the endpoint to ``replicas`` instances (V1: 1 → no-op for now)."""
    c = client or get_default_client()
    ep = get(name_or_id, client=c)
    return c.post(f"{_PATH}/{ep['id']}/scale", json={"replicas": replicas})


def logs(name_or_id: str, *, tail: int = 200, client: Client | None = None) -> builtins.list[dict]:
    """Fetch the endpoint container's recent logs."""
    c = client or get_default_client()
    ep = get(name_or_id, client=c)
    body = c.get(f"{_PATH}/{ep['id']}/logs", params={"limit": tail})
    if isinstance(body, builtins.list):
        return body
    return body.get("logs") or [] if isinstance(body, dict) else []
