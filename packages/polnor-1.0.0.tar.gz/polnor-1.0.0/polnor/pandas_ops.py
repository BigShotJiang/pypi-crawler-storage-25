"""Pandas bulk helpers — ``write_pandas`` and ``read_pandas``.

These wrap the SQL surface to give the Snowflake-style ergonomics
users expect ("just push my DataFrame to a table") without forcing
them to write the INSERT by hand.

Pandas + pyarrow are NOT install-time requirements; they're imported
on the first call. Users who never touch DataFrames don't pay the cost.

Limitations (V1) :

- ``write_pandas`` uses ``INSERT INTO ... VALUES (...)`` batches.
  Fast for thousands of rows, not millions. Tens-of-millions should
  go through Parquet → Iceberg ``COPY INTO`` (V2).
- The table must already exist (``mode="append"``) or you ask the SDK
  to ``CREATE TABLE`` from the DataFrame schema (``mode="create"``).
"""

from __future__ import annotations

import math
from typing import Any

from ._client import Client
from .sql import sql as _polnor_sql


# Reasonable default — Spark sidecar handles a few thousand-row INSERTs
# fast enough, and very large chunks risk hitting the 16MB JSON limit.
_DEFAULT_CHUNK_ROWS = 1000


def write_pandas(
    df,
    table: str,
    *,
    mode: str = "append",
    chunk_size: int = _DEFAULT_CHUNK_ROWS,
    warehouse_id: str | None = None,
    client: Client | None = None,
) -> int:
    """Bulk-insert a pandas DataFrame into an Iceberg table.

    ``table`` should be the fully-qualified Spark name. For Polnor's
    namespace layout that's typically
    ``<catalog>.\`<workspace>__<db>\`.\`<schema>\`.<table_name>``.
    For the simpler case where the user is in the right database
    context, ``demo.default.orders`` works too.

    ``mode`` :

    - ``"append"`` (default) : INSERT rows into an existing table.
    - ``"overwrite"`` : ``DELETE FROM table; INSERT INTO ...`` (best
      effort — Iceberg supports atomic overwrite, but our V1 just
      truncates + appends).
    - ``"create"`` : ``CREATE TABLE`` from DataFrame schema first, then
      INSERT. Errors if the table already exists.

    Returns the number of rows inserted.
    """
    try:
        import pandas as pd  # noqa: F401
    except ImportError as e:  # pragma: no cover
        raise ImportError("write_pandas needs pandas: `pip install pandas`") from e

    if len(df) == 0:
        return 0

    if mode == "create":
        _create_table_from_df(df, table, warehouse_id=warehouse_id, client=client)
    elif mode == "overwrite":
        _polnor_sql(f"DELETE FROM {table}",
                    warehouse_id=warehouse_id, client=client)
    elif mode != "append":
        raise ValueError(f"write_pandas: mode must be append/overwrite/create, got {mode!r}")

    columns = list(df.columns)
    cols_sql = ", ".join(_quote_ident(c) for c in columns)
    total = 0
    n_chunks = math.ceil(len(df) / chunk_size)
    for i in range(n_chunks):
        chunk = df.iloc[i * chunk_size:(i + 1) * chunk_size]
        values_sql = ",\n".join(
            "(" + ", ".join(_sql_value(row[c]) for c in columns) + ")"
            for _, row in chunk.iterrows()
        )
        _polnor_sql(
            f"INSERT INTO {table} ({cols_sql}) VALUES {values_sql}",
            warehouse_id=warehouse_id, client=client,
        )
        total += len(chunk)
    return total


def read_pandas(
    table: str,
    *,
    columns: list[str] | None = None,
    where: str | None = None,
    limit: int | None = None,
    warehouse_id: str | None = None,
    client: Client | None = None,
):
    """Read a table (or filtered subset) into a pandas DataFrame.

    Sugar around ``polnor.sql("SELECT ...").to_pandas()``. Optional
    arguments let you skip writing the SQL by hand for the common
    "fetch this table with these filters" pattern.

    ``table`` accepts both Spark-style backticks (``polnor.`foo`.bar``)
    and double-quote identifiers (``polnor."foo".bar``) — we normalise
    to double quotes so the DuckDB sidecar (which only understands
    standard SQL) can parse the query.
    """
    cols_sql = ", ".join(_quote_ident(c) for c in columns) if columns else "*"
    inner = f"SELECT {cols_sql} FROM {table}"
    if where:
        inner += f" WHERE {where}"
    if limit is not None:
        inner += f" LIMIT {int(limit)}"
    # Wrap in WITH so the polnor.sql() router sends this to Spark (which
    # handles 4-level Iceberg names — DuckDB's iceberg extension raises
    # "NameListToString NOT IMPLEMENTED" on nested namespaces). The
    # router's isWriteSQL regex matches WITH as the first keyword.
    q = f"WITH q AS ({inner}) SELECT * FROM q"
    return _polnor_sql(q, warehouse_id=warehouse_id, client=client).to_pandas()


# --- internals ---

def _create_table_from_df(df, table: str, *, warehouse_id, client) -> None:
    cols_decl = ", ".join(f"{_quote_ident(c)} {_sql_type_for(df[c].dtype)}"
                          for c in df.columns)
    # IF NOT EXISTS: Spark's catalog cache sometimes thinks a freshly
    # named table already exists. Idempotent CREATE is safe and matches
    # what most users do anyway (re-running a notebook cell).
    _polnor_sql(
        f"CREATE TABLE IF NOT EXISTS {table} ({cols_decl}) USING iceberg",
        warehouse_id=warehouse_id, client=client,
    )


def _quote_ident(name: str) -> str:
    """Backtick-quote an identifier (Spark/DuckDB syntax)."""
    return "`" + name.replace("`", "``") + "`"


def _sql_value(v: Any) -> str:
    """Render a Python value as a SQL literal. Mirrors dbapi.cursor._sql_literal."""
    if v is None:
        return "NULL"
    # pandas NA / NaT / NaN
    try:
        import pandas as pd
        if pd.isna(v):
            return "NULL"
    except Exception:
        pass
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, bytes):
        return f"X'{v.hex()}'"
    try:
        import datetime as _dt
        if isinstance(v, _dt.datetime):
            return f"TIMESTAMP '{v.isoformat(sep=' ')}'"
        if isinstance(v, _dt.date):
            return f"DATE '{v.isoformat()}'"
    except Exception:
        pass
    # Fallback: stringify + escape single quotes
    s = str(v).replace("'", "''")
    return f"'{s}'"


def _sql_type_for(dtype) -> str:
    """Map a numpy/pandas dtype to a Spark/Iceberg SQL type."""
    import numpy as np
    if np.issubdtype(dtype, np.integer):
        return "BIGINT"
    if np.issubdtype(dtype, np.floating):
        return "DOUBLE"
    if np.issubdtype(dtype, np.bool_):
        return "BOOLEAN"
    if np.issubdtype(dtype, np.datetime64):
        return "TIMESTAMP"
    return "STRING"
