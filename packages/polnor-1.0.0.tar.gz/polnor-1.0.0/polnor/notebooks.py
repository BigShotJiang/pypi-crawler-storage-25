"""Notebook resource — list / get / create / start / stop / delete.

Notebooks attach to a Compute (``compute_id``); the agent on that
compute launches the Jupyter sidecar on /start. ``polnor.notebooks.start``
returns once the sidecar is registered (status=running) or after the
``timeout`` if you pass ``wait=False`` to skip blocking.

Cell execution is exposed via the underlying API (the SDK ships only
``execute(cell_id, code)`` here — for interactive use, run ``polnor.sql``
inside the cell instead, it's the cleaner UX).
"""

from __future__ import annotations

import builtins
from typing import Any

from ._client import Client, get_default_client
from ._resource import get_resource, list_resource, post_action, wait_for_status

_PATH = "/notebooks"
_RUNNING = {"running"}
_TERMINAL = {"running", "stopped", "error"}


def list(*, client: Client | None = None) -> builtins.list[dict]:
    """List notebooks in the current workspace."""
    return list_resource(_PATH, client=client)


def get(name_or_id: str, *, client: Client | None = None) -> dict:
    """Fetch one notebook by id or name."""
    return get_resource(_PATH, name_or_id, client=client)


def create(
    *,
    name: str,
    compute_id: str | None = None,
    image: str | None = None,
    description: str = "",
    auto_shutdown_minutes: int | None = None,
    env_vars: dict[str, str] | None = None,
    client: Client | None = None,
) -> dict:
    """Create a notebook record. Doesn't start it — call ``start()`` next."""
    c = client or get_default_client()
    payload: dict[str, Any] = {"name": name, "description": description}
    if compute_id:
        payload["compute_id"] = compute_id
    if image:
        payload["image"] = image
    if auto_shutdown_minutes is not None:
        payload["auto_shutdown_minutes"] = auto_shutdown_minutes
    if env_vars:
        payload["env_vars"] = env_vars
    return c.post(_PATH, json=payload)


def start(name_or_id: str, *, wait: bool = True, timeout: float = 600.0,
          client: Client | None = None) -> dict:
    """Start the notebook's Jupyter sidecar on its compute.

    Idempotent on the server side; calling on a running notebook is a no-op.
    Blocks until status=running or timeout if wait=True.
    """
    nb = get(name_or_id, client=client)
    post_action(_PATH, f"{nb['id']}/start", client=client)
    if not wait:
        return get(nb["id"], client=client)
    return wait_for_status(
        None, get_fn=get, name_or_id=nb["id"],
        target=_RUNNING, terminal=_TERMINAL, timeout=timeout, client=client,
    )


def stop(name_or_id: str, *, wait: bool = True, timeout: float = 120.0,
         client: Client | None = None) -> dict:
    """Stop the notebook's sidecar. The compute stays up."""
    nb = get(name_or_id, client=client)
    post_action(_PATH, f"{nb['id']}/stop", client=client)
    if not wait:
        return get(nb["id"], client=client)
    return wait_for_status(
        None, get_fn=get, name_or_id=nb["id"],
        target={"stopped"}, terminal=_TERMINAL, timeout=timeout, client=client,
    )


def delete(name_or_id: str, *, client: Client | None = None) -> None:
    """Delete a notebook. The compute is untouched."""
    c = client or get_default_client()
    nb = get(name_or_id, client=c)
    c.delete(f"{_PATH}/{nb['id']}")


def execute_cell(notebook_name_or_id: str, cell_id: str, *,
                 client: Client | None = None) -> dict:
    """Run a cell that's already been created on the notebook. The cell's
    source is what was written via the UI / a separate ``cells`` API.
    """
    c = client or get_default_client()
    nb = get(notebook_name_or_id, client=c)
    return c.post(f"{_PATH}/{nb['id']}/cells/{cell_id}/execute")
