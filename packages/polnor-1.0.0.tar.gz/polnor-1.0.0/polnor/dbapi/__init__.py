"""PEP 249 (Python Database API Specification v2.0) implementation for Polnor.

Lets pandas, sqlalchemy, dbt and any other tool that speaks DBAPI talk
to a Polnor SQL warehouse without knowing anything about our HTTP API.

Quick start::

    import polnor.dbapi
    conn = polnor.dbapi.connect()   # auto-resolves token + warehouse from env/config
    cur = conn.cursor()
    cur.execute("SELECT * FROM demo.orders LIMIT 5")
    for row in cur.fetchall():
        print(row)

With pandas::

    import pandas as pd
    df = pd.read_sql("SELECT * FROM demo.orders LIMIT 5", conn)

Mandatory module-level globals (per PEP 249 §3):

- ``apilevel``: '2.0' — we implement the v2 spec.
- ``threadsafety``: 1 — module is safe to share, connections are not.
- ``paramstyle``: 'qmark' — parameters in queries use ``?`` placeholders.
"""

from .connection import Connection, connect
from .cursor import Cursor
from .errors import (
    DataError,
    DatabaseError,
    Error,
    InterfaceError,
    InternalError,
    NotSupportedError,
    OperationalError,
    ProgrammingError,
    Warning,
)

# PEP 249 §3 — Module Interface globals.
apilevel = "2.0"
# threadsafety levels: 0=module unsafe, 1=module safe but connections not,
# 2=module + conn safe, 3=everything thread-safe. We're 1: separate
# connections in different threads work fine, but don't share a Connection.
threadsafety = 1
paramstyle = "qmark"

__all__ = [
    "Connection",
    "Cursor",
    "DataError",
    "DatabaseError",
    "Error",
    "InterfaceError",
    "InternalError",
    "NotSupportedError",
    "OperationalError",
    "ProgrammingError",
    "Warning",
    "apilevel",
    "connect",
    "paramstyle",
    "threadsafety",
]
