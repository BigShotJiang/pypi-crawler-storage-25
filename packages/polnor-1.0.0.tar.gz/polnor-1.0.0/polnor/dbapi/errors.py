"""PEP 249 §4 — Exceptions.

The class hierarchy mandated by the spec::

    Exception
     +-- Warning
     +-- Error
          +-- InterfaceError
          +-- DatabaseError
               +-- DataError
               +-- OperationalError
               +-- IntegrityError       (not raised today; reserved)
               +-- InternalError
               +-- ProgrammingError
               +-- NotSupportedError

Polnor's ``polnor.PolnorAPIError`` is mapped to the right subclass at the
boundary: HTTP 4xx → ProgrammingError (caller's fault), HTTP 5xx →
OperationalError (server's fault), connection errors → InterfaceError.
"""

from __future__ import annotations


class Warning(Exception):  # noqa: A001 — PEP 249 mandates this exact name
    """Raised for important warnings like data truncation."""


class Error(Exception):
    """Base class for all errors raised by this module."""


class InterfaceError(Error):
    """Errors related to the database interface itself rather than the DB."""


class DatabaseError(Error):
    """Errors related to the database operation."""


class DataError(DatabaseError):
    """Errors due to problems with the processed data."""


class OperationalError(DatabaseError):
    """Errors related to the database's operation, not necessarily the caller.

    Example: an unexpected disconnect, OOM on the warehouse, etc.
    """


class IntegrityError(DatabaseError):
    """Relational integrity errors (FK, unique, check)."""


class InternalError(DatabaseError):
    """The database encountered an internal error."""


class ProgrammingError(DatabaseError):
    """SQL syntax errors, wrong table name, wrong number of parameters, etc."""


class NotSupportedError(DatabaseError):
    """A method or DBAPI feature isn't supported by the driver."""
