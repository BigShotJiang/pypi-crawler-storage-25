"""PEP 249 Connection — module-level ``connect()`` returns one of these.

Wraps a polnor.Client (HTTP). Multiple Cursors share the connection's
client but maintain their own result buffer + description.

Polnor's SQL warehouse is auto-commit at the engine level (every
statement is its own transaction); Connection.commit() and rollback()
are intentional no-ops to satisfy the DBAPI contract.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any

from .._client import Client, Config, DEFAULT_API_URL
from .errors import InterfaceError, ProgrammingError

if TYPE_CHECKING:  # avoid cycle
    from .cursor import Cursor


def connect(
    *,
    token: str | None = None,
    api_url: str | None = None,
    warehouse_id: str | None = None,
    workspace_slug: str | None = None,
    **_ignored: Any,
) -> "Connection":
    """Open a connection. Args fall back to env / config file resolution
    just like ``polnor.sql()`` does.

    Extra kwargs are silently ignored to match dbt / sqlalchemy that may
    pass driver-specific options we don't care about (e.g. ``host`` if
    someone passes a sqlalchemy URL).
    """
    # Allow callers to pass `host` like the CLI / dbt does — alias to api_url.
    if "host" in _ignored and not api_url:
        api_url = _ignored["host"]

    cfg_api_url = (api_url or os.environ.get("POLNOR_API_URL") or DEFAULT_API_URL).rstrip("/")
    cfg_token = token or os.environ.get("POLNOR_TOKEN") or ""
    if not cfg_token:
        # Last chance: try the resolver (config file)
        try:
            resolved = Config.resolve()
            cfg_token = resolved.token
            cfg_api_url = resolved.api_url
            if not warehouse_id:
                warehouse_id = resolved.warehouse_id
            if not workspace_slug:
                workspace_slug = resolved.workspace_slug
        except Exception as e:
            raise InterfaceError(
                f"polnor.dbapi.connect: no token available — pass token=... "
                f"or set POLNOR_TOKEN. ({e})"
            ) from e

    cfg = Config(
        api_url=cfg_api_url,
        token=cfg_token,
        workspace_slug=workspace_slug,
        warehouse_id=warehouse_id or os.environ.get("POLNOR_WAREHOUSE_ID"),
    )
    return Connection(Client(cfg))


class Connection:
    """PEP 249 §6 — Connection Objects."""

    def __init__(self, client: Client):
        self._client = client
        self._closed = False

    # --- PEP 249 §6.1 — required methods ---

    def close(self) -> None:
        """Close the connection. Subsequent uses raise InterfaceError."""
        self._closed = True
        # requests.Session is reusable across "connections" — nothing to release.

    def commit(self) -> None:
        """No-op: every SQL statement is auto-committed at the engine."""
        self._check_open()

    def rollback(self) -> None:
        """Not supported. Raises NotImplementedError-style at the DBAPI layer.

        Polnor's SQL surface is auto-commit; there's no transaction to
        roll back. We follow the PEP 249 advice and accept the call as
        a no-op rather than raise — sqlalchemy expects rollback() to be
        callable even when nothing's been done.
        """
        self._check_open()

    def cursor(self) -> "Cursor":
        """Return a new Cursor object using this connection."""
        self._check_open()
        from .cursor import Cursor  # local import to avoid cycle
        return Cursor(self)

    # --- context manager (PEP 249 optional but pandas uses it) ---

    def __enter__(self) -> "Connection":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    # --- internals ---

    def _check_open(self) -> None:
        if self._closed:
            raise ProgrammingError("operation on a closed connection")

    @property
    def client(self) -> Client:
        """The underlying ``polnor.Client`` for use by Cursor."""
        self._check_open()
        return self._client
