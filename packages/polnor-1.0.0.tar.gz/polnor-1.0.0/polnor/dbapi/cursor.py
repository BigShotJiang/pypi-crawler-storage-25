"""PEP 249 Cursor — buffers result rows and exposes ``description``.

A single Cursor maintains:

- ``description``: tuple of column metadata from the last execute().
- A row buffer materialised on the first fetchone/fetchmany/fetchall.
- ``rowcount``: number of rows (-1 before execute, or unknown).

Parameter substitution uses ``?`` (paramstyle="qmark"). Polnor's SQL API
doesn't accept native parameters, so we render ``?`` placeholders client
side with proper quoting before sending. That's enough for pandas /
sqlalchemy bind params and for dbt's compiled SQL.
"""

from __future__ import annotations

from typing import Any, Iterable, Sequence

from .._client import PolnorAPIError
from ..sql import SQLError, sql as _polnor_sql
from .errors import (
    DatabaseError,
    InterfaceError,
    NotSupportedError,
    OperationalError,
    ProgrammingError,
)


class Cursor:
    """PEP 249 §6.2 — Cursor Objects.

    Built on top of the existing ``polnor.sql()`` flow: submit + poll +
    fetch — but we keep the QueryResult around so ``description`` and
    paginated fetches work as PEP 249 expects.
    """

    # PEP 249 attribute. None means no rowset available.
    arraysize = 1

    def __init__(self, connection):
        self._connection = connection
        self._description: tuple | None = None
        self._rows: list[list] = []
        self._row_idx: int = 0
        self._rowcount: int = -1
        self._closed = False

    # --- PEP 249 attributes ---

    @property
    def description(self) -> tuple | None:
        """Tuple of 7-tuples per column (name, type_code, display_size,
        internal_size, precision, scale, null_ok). ``None`` before any
        rowset is produced. We only fill ``name`` + ``type_code``; the
        rest is set to None which is allowed by the spec.
        """
        return self._description

    @property
    def rowcount(self) -> int:
        """-1 if undefined / before execute, else number of rows."""
        return self._rowcount

    @property
    def connection(self):
        """Reference to the parent Connection (PEP 249 extension §A)."""
        return self._connection

    # --- PEP 249 methods ---

    def close(self) -> None:
        self._closed = True
        self._rows = []
        self._description = None

    def execute(self, operation: str, parameters: Sequence | None = None) -> "Cursor":
        """Run a SQL statement. Returns self to chain ``.fetchall()``."""
        self._check_open()
        query = _apply_qmark_params(operation, parameters)
        try:
            result = _polnor_sql(query, client=self._connection.client)
        except SQLError as e:
            raise ProgrammingError(str(e)) from e
        except PolnorAPIError as e:
            # 4xx → caller's fault, 5xx → server's fault
            cls = ProgrammingError if e.status < 500 else OperationalError
            raise cls(str(e)) from e
        except Exception as e:
            raise DatabaseError(str(e)) from e

        # Fill PEP 249 description + buffer
        self._description = tuple(
            (col["name"], col.get("type"), None, None, None, None, None)
            for col in result.columns
        )
        self._rows = list(result.rows)
        self._row_idx = 0
        self._rowcount = len(self._rows) if self._rows else (result.rows_produced or -1)
        return self

    def executemany(self, operation: str, seq_of_parameters: Iterable[Sequence]) -> None:
        """Run the same statement against each row in seq_of_parameters.

        Only the LAST statement's rowset is kept (per PEP 249). For bulk
        loads use ``polnor.write_pandas`` instead — it's far more efficient.
        """
        for params in seq_of_parameters:
            self.execute(operation, params)

    def fetchone(self) -> tuple | None:
        self._check_open()
        if self._row_idx >= len(self._rows):
            return None
        row = self._rows[self._row_idx]
        self._row_idx += 1
        return tuple(row)

    def fetchmany(self, size: int | None = None) -> list[tuple]:
        self._check_open()
        n = self.arraysize if size is None else size
        end = min(self._row_idx + n, len(self._rows))
        out = [tuple(r) for r in self._rows[self._row_idx:end]]
        self._row_idx = end
        return out

    def fetchall(self) -> list[tuple]:
        self._check_open()
        out = [tuple(r) for r in self._rows[self._row_idx:]]
        self._row_idx = len(self._rows)
        return out

    # PEP 249 says these should exist but be no-ops for drivers without input/output params
    def setinputsizes(self, sizes) -> None:
        self._check_open()

    def setoutputsize(self, size, column=None) -> None:
        self._check_open()

    # --- iteration (PEP 249 extension §A) ---

    def __iter__(self):
        return self

    def __next__(self) -> tuple:
        row = self.fetchone()
        if row is None:
            raise StopIteration
        return row

    # --- context manager (used by pandas.read_sql internals) ---

    def __enter__(self) -> "Cursor":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    # --- internals ---

    def _check_open(self) -> None:
        if self._closed:
            raise InterfaceError("operation on a closed cursor")


def _apply_qmark_params(query: str, params: Sequence | None) -> str:
    """Render ``?`` placeholders with the values from ``params``.

    Polnor's /sql/execute doesn't accept native parameters, so we render
    them client side. We quote strings with single quotes (escaping any
    embedded single quotes), inline numbers verbatim, format dates as
    SQL literals. None → NULL. Anything else falls back to ``repr()``
    which is wrong for most types — callers should pass strings/numbers/
    None when in doubt.

    NOTE: this is not SQL-injection safe for hostile inputs. Polnor's
    DBAPI is intended for trusted code paths (your own queries, dbt
    compiled SQL, etc.).
    """
    if params is None:
        return query
    out: list[str] = []
    pi = 0
    plist = list(params)
    for ch in query:
        if ch == "?":
            if pi >= len(plist):
                raise ProgrammingError(
                    f"not enough parameters: query has more ? than {len(plist)} values"
                )
            out.append(_sql_literal(plist[pi]))
            pi += 1
        else:
            out.append(ch)
    if pi != len(plist):
        raise ProgrammingError(
            f"too many parameters: query has {pi} ? but {len(plist)} values"
        )
    return "".join(out)


def _sql_literal(v: Any) -> str:
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, str):
        escaped = v.replace("'", "''")
        return f"'{escaped}'"
    if isinstance(v, bytes):
        # Hex literal — works in Spark + DuckDB
        return f"X'{v.hex()}'"
    # datetime / date support — keep it simple, callers can pre-format too
    try:
        import datetime as _dt
        if isinstance(v, (_dt.datetime, _dt.date)):
            return f"'{v.isoformat()}'"
    except Exception:  # pragma: no cover
        pass
    raise NotSupportedError(
        f"qmark substitution: unsupported parameter type {type(v).__name__}"
    )
