"""Polnor Python SDK.

Quick start::

    import polnor
    df = polnor.sql("SELECT * FROM polnor.demo.default.orders LIMIT 5").to_pandas()

Auth is auto-resolved in this order:

1. ``polnor.set_token("...")`` in code
2. ``POLNOR_API_URL`` + ``POLNOR_TOKEN`` (and optionally ``POLNOR_WAREHOUSE_ID``) env vars
3. ``~/.polnor/config`` (written by ``polnor auth login`` CLI)

Inside a Polnor notebook or job, the env vars are injected automatically
by the runtime — you don't need to call anything before ``polnor.sql(...)``.

Resources mirror the control-plane API. Every module exposes
``list / get / create / delete`` plus domain-specific verbs :

- ``polnor.sql(query)``        — run a SQL statement
- ``polnor.warehouses``        — SQL warehouses (start/stop/default)
- ``polnor.compute``           — VMs (start/stop, install_library, logs)
- ``polnor.notebooks``         — Jupyter notebooks (start/stop, execute_cell)
- ``polnor.jobs``              — job DAGs + runs (run/wait/logs/cancel_run)
- ``polnor.models``            — model registry (versions, artifacts)
- ``polnor.endpoints``         — model serving (deploy/predict/scale)
- ``polnor.tables``            — Iceberg catalog (databases + tables)
- ``polnor.dbapi``             — PEP 249 driver (pandas.read_sql, dbt, sqlalchemy)
- ``polnor.mlflow``            — MLflow-compatible tracking

Errors :

- :class:`polnor.PolnorAPIError` for HTTP failures (non-2xx)
- :class:`polnor.SQLError`       for failed statements
- :class:`polnor.PolnorConfigError` when auth cannot be resolved
"""

from . import (
    compute,
    dbapi,
    endpoints,
    jobs,
    mlflow,
    models,
    notebooks,
    tables,
    warehouses,
)
from ._client import (
    Client,
    Config,
    PolnorAPIError,
    PolnorConfigError,
    get_default_client,
    reset_default_client,
    set_token,
)
from .pandas_ops import read_pandas, write_pandas
from .sql import QueryResult, SQLError, sql

__all__ = [
    "Client",
    "Config",
    "PolnorAPIError",
    "PolnorConfigError",
    "QueryResult",
    "SQLError",
    "compute",
    "dbapi",
    "endpoints",
    "get_default_client",
    "jobs",
    "mlflow",
    "models",
    "notebooks",
    "read_pandas",
    "reset_default_client",
    "set_token",
    "sql",
    "tables",
    "warehouses",
    "write_pandas",
]
__version__ = "1.0.0"
