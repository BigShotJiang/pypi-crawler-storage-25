"""Shared helpers for the resource modules (notebooks, jobs, compute, ...).

Every resource module follows the same pattern :

- ``list()`` → ``GET /<resource>``
- ``get(name_or_id)`` → ``GET /<resource>/<id>`` with name fallback
- ``create(...)`` → ``POST /<resource>`` with kwargs as JSON body
- ``delete(name_or_id)`` → ``DELETE /<resource>/<id>``
- domain-specific verbs (start/stop/run/deploy/etc.) on top.

We thin-wrap responses : returning plain dicts is intentional. Users
get the full API payload (no surprise filtering) and we don't need to
maintain typed schemas in lockstep with the server.
"""

from __future__ import annotations

import builtins
import time
from typing import Any, Iterable

from ._client import Client, PolnorAPIError, get_default_client


def list_resource(path: str, *, client: Client | None = None) -> builtins.list[dict]:
    """``GET /<path>`` and unwrap to a list regardless of whether the API
    returns a bare list or a ``{"data": [...]}`` envelope.
    """
    c = client or get_default_client()
    body = c.get(path)
    if isinstance(body, builtins.list):
        return body
    if isinstance(body, dict):
        for key in ("data", "items", "results"):
            if key in body and isinstance(body[key], builtins.list):
                return body[key]
    return []


def get_resource(path: str, name_or_id: str, *, client: Client | None = None) -> dict:
    """``GET /<path>/<name_or_id>`` with a list-fallback if the API only
    accepts UUIDs but we got handed a name.
    """
    c = client or get_default_client()
    try:
        return c.get(f"{path}/{name_or_id}")
    except PolnorAPIError as e:
        if e.status == 404:
            for item in list_resource(path, client=c):
                if item.get("id") == name_or_id or item.get("name") == name_or_id:
                    return item
        raise


def wait_for_status(
    fetch: Iterable[dict] | None,
    *,
    get_fn,
    name_or_id: str,
    target: set[str],
    terminal: set[str],
    timeout: float = 600.0,
    poll_every: float = 5.0,
    client: Client | None = None,
) -> dict:
    """Poll ``get_fn(name_or_id, client=...)`` until status is in ``target``
    (success) or in ``terminal - target`` (gave up). Returns the last
    seen dict either way. ``fetch`` is unused — kept for symmetry.
    """
    accept = set(target) | set(terminal)
    deadline = time.monotonic() + timeout
    last: dict = {}
    while time.monotonic() < deadline:
        last = get_fn(name_or_id, client=client)
        status = last.get("status") or ""
        if status in accept:
            return last
        time.sleep(poll_every)
    return last


def post_action(path: str, action: str, *, json: Any | None = None,
                client: Client | None = None) -> dict:
    """``POST /<path>/<action>`` returning the parsed body (or empty dict)."""
    c = client or get_default_client()
    body = c.post(f"{path}/{action}", json=json)
    return body if isinstance(body, dict) else {}
