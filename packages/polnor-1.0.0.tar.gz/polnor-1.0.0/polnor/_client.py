"""Thin HTTP client shared by every polnor.* module.

Kept separate so submodules (sql, warehouses, notebooks, jobs, mlflow…)
share the same auth + retry plumbing without circular imports.

Auth resolution order (first one that produces a usable config wins):

1. ``polnor.set_token(...)`` / ``polnor.login()`` — explicit, in-process
2. Environment variables ``POLNOR_API_URL`` + ``POLNOR_TOKEN``
3. ``~/.polnor/config`` (INI file, written by ``polnor auth login`` CLI)

Outside any of those, the first API call raises with a clean message
telling the user what to set.
"""

from __future__ import annotations

import configparser
import os
import sys
import time
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

# tomllib is stdlib on 3.11+, fall back to tomli on 3.9/3.10. We only
# need the reader (TOML config file), not the writer — the CLI writes.
if sys.version_info >= (3, 11):  # pragma: no cover
    import tomllib as _toml
else:
    try:
        import tomli as _toml  # type: ignore
    except ImportError:  # pragma: no cover — only matters on 3.9/3.10
        _toml = None

try:
    import requests
except ImportError as e:  # pragma: no cover — caught early in install
    raise ImportError(
        "polnor SDK requires the 'requests' package. "
        "Install with `pip install polnor` or `pip install requests`."
    ) from e


DEFAULT_API_URL = "https://api.polnor.net"
# Preferred TOML location (matches the Go CLI `polnor auth login` output).
CONFIG_PATH_TOML = Path.home() / ".polnor" / "config.toml"
# Legacy INI fallback — 0.2.0 SDK wrote here. Kept for one release then dropped.
CONFIG_PATH_INI = Path.home() / ".polnor" / "config"
# What the rest of the code uses by default. We try TOML first, then INI.
CONFIG_PATH = CONFIG_PATH_TOML


class PolnorAPIError(RuntimeError):
    """Raised on a non-2xx API response with the body verbatim."""

    def __init__(self, status: int, body: str, *, method: str, url: str):
        super().__init__(f"{method} {url} → {status}: {body}")
        self.status = status
        self.body = body


class PolnorConfigError(RuntimeError):
    """Raised when no usable auth config can be resolved at call time."""


@dataclass
class Config:
    """SDK configuration. Read from env / config file / explicit set."""

    api_url: str
    token: str
    workspace_slug: str | None = None
    warehouse_id: str | None = None
    timeout: float = 30.0
    max_retries: int = 3
    backoff_base: float = 0.5

    @classmethod
    def from_env(cls) -> "Config":
        api_url = os.environ.get("POLNOR_API_URL", "").rstrip("/")
        token = os.environ.get("POLNOR_TOKEN", "")
        workspace = os.environ.get("POLNOR_WORKSPACE_SLUG") or None
        warehouse = (
            os.environ.get("POLNOR_WAREHOUSE_ID")
            or os.environ.get("POLNOR_WAREHOUSE")
            or None
        )
        if not api_url:
            raise PolnorConfigError(
                "POLNOR_API_URL is not set — point it at https://api.polnor.net "
                "(or your self-hosted control plane)."
            )
        if not token:
            raise PolnorConfigError(
                "POLNOR_TOKEN is not set — generate a personal access token "
                "from /settings/tokens and export POLNOR_TOKEN."
            )
        return cls(
            api_url=api_url,
            token=token,
            workspace_slug=workspace,
            warehouse_id=warehouse,
        )

    @classmethod
    def from_file(cls, path: Path | str | None = None, profile: str = "default") -> "Config":
        """Read config from a TOML or INI file.

        Format detection is by extension : ``.toml`` → TOML reader,
        anything else → INI. The Go CLI writes TOML to
        ``~/.polnor/config.toml`` ; the 0.2.0 SDK wrote INI to
        ``~/.polnor/config``. Both are accepted.

        Key mapping (CLI Go conventions → SDK Python) :
        - ``host``           → ``api_url``
        - ``workspace_id``   → ``workspace_slug``
        - ``token``, ``warehouse_id`` keep their names.
        """
        candidates: list[Path]
        if path is None:
            candidates = [CONFIG_PATH_TOML, CONFIG_PATH_INI]
        else:
            candidates = [Path(path).expanduser()]
        existing = next((p for p in candidates if p.exists()), None)
        if existing is None:
            tried = ", ".join(str(p) for p in candidates)
            raise PolnorConfigError(f"polnor config file not found (tried: {tried})")

        if existing.suffix == ".toml":
            return cls._from_toml(existing, profile)
        return cls._from_ini(existing, profile)

    @classmethod
    def _from_toml(cls, path: Path, profile: str) -> "Config":
        if _toml is None:
            raise PolnorConfigError(
                f"polnor config {path} is TOML but the TOML reader is missing — "
                f"`pip install tomli` on Python 3.9 / 3.10 (3.11+ has it built in)"
            )
        with path.open("rb") as f:
            data = _toml.load(f)
        # Two layouts accepted :
        #   1. Flat root-level keys (single profile)        — Go CLI default
        #   2. Tables per profile : [default]\ntoken=...    — multi-profile
        if profile in data and isinstance(data[profile], dict):
            section = data[profile]
        elif "default" in data and isinstance(data["default"], dict):
            section = data["default"]
        else:
            section = data
        return cls._from_dict(section, path, profile)

    @classmethod
    def _from_ini(cls, path: Path, profile: str) -> "Config":
        parser = configparser.ConfigParser()
        parser.read(path)
        section_name = "DEFAULT" if profile.lower() in ("default", "default") else profile
        if section_name != "DEFAULT" and section_name not in parser:
            raise PolnorConfigError(
                f"profile {profile!r} not found in {path} "
                f"(available: {', '.join(parser.sections())})"
            )
        section = parser[section_name] if section_name != "DEFAULT" else parser["DEFAULT"]
        return cls._from_dict(dict(section), path, profile)

    @classmethod
    def _from_dict(cls, section: Mapping[str, Any], path: Path, profile: str) -> "Config":
        # Accept Go CLI key names (host, workspace_id) and Python names too.
        api_url = (
            section.get("api_url")
            or section.get("host")
            or DEFAULT_API_URL
        ).rstrip("/")
        token = section.get("token", "") or ""
        workspace = (
            section.get("workspace_slug")
            or section.get("workspace_id")
            or None
        )
        warehouse = (
            section.get("warehouse_id")
            or section.get("warehouse")
            or None
        )
        if not token:
            raise PolnorConfigError(
                f"profile {profile!r} in {path} has no 'token' key"
            )
        return cls(
            api_url=api_url,
            token=token,
            workspace_slug=workspace,
            warehouse_id=warehouse,
        )

    @classmethod
    def resolve(cls, profile: str = "default") -> "Config":
        """Try env first, then config file. Raises with a clean hint if both fail."""
        env_url = os.environ.get("POLNOR_API_URL", "").rstrip("/")
        env_token = os.environ.get("POLNOR_TOKEN", "")
        if env_url and env_token:
            return cls.from_env()
        # Try TOML then INI fallback.
        for p in (CONFIG_PATH_TOML, CONFIG_PATH_INI):
            if p.exists():
                try:
                    return cls.from_file(p, profile=profile)
                except PolnorConfigError:
                    continue
        if env_url or env_token:
            return cls.from_env()  # will raise a precise message
        raise PolnorConfigError(
            "polnor: no credentials found.\n"
            "Either:\n"
            "  - export POLNOR_TOKEN=<your token>  (set POLNOR_API_URL too if not https://api.polnor.net)\n"
            f"  - or write a TOML config at {CONFIG_PATH_TOML} with `token`, `host`, `workspace_id`\n"
            "  - or call polnor.set_token('<token>') in code"
        )


class Client:
    """HTTP client with token auth + retry on 5xx / connection errors.

    Idempotency: every method here is safe to retry — they're either
    pure GETs or POST/PATCH endpoints that the server side already
    handles idempotently (start_run with the same body would create a
    second run, but that's a deliberate design — MLflow does the same).
    """

    def __init__(self, cfg: Config | None = None):
        self.cfg = cfg or Config.from_env()
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {self.cfg.token}",
            "Content-Type": "application/json",
            "User-Agent": "polnor-sdk-python/0.1.0",
        })
        if self.cfg.workspace_slug:
            self._session.headers["X-Workspace-Slug"] = self.cfg.workspace_slug

    # --- low-level ---

    def request(self, method: str, path: str, *, json: Any | None = None,
                params: Mapping[str, Any] | None = None) -> Any:
        url = self._build_url(path, params)
        last_err: Exception | None = None
        for attempt in range(self.cfg.max_retries):
            try:
                resp = self._session.request(
                    method, url, json=json, timeout=self.cfg.timeout
                )
            except requests.RequestException as e:
                last_err = e
                self._sleep(attempt)
                continue

            if resp.status_code >= 500:
                last_err = PolnorAPIError(resp.status_code, resp.text, method=method, url=url)
                self._sleep(attempt)
                continue
            if resp.status_code >= 400:
                raise PolnorAPIError(resp.status_code, resp.text, method=method, url=url)

            if resp.status_code == 204 or not resp.content:
                return None
            return resp.json()

        if last_err:
            raise last_err
        return None

    def _build_url(self, path: str, params: Mapping[str, Any] | None) -> str:
        base = f"{self.cfg.api_url}/api/v1{path}"
        if not params:
            return base
        return f"{base}?{urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})}"

    def _sleep(self, attempt: int) -> None:
        delay = self.cfg.backoff_base * (2 ** attempt)
        time.sleep(delay)

    # --- convenience wrappers ---

    def post(self, path: str, json: Any | None = None) -> Any:
        return self.request("POST", path, json=json)

    def patch(self, path: str, json: Any | None = None) -> Any:
        return self.request("PATCH", path, json=json)

    def put(self, path: str, json: Any | None = None) -> Any:
        return self.request("PUT", path, json=json)

    def delete(self, path: str) -> Any:
        return self.request("DELETE", path)

    def get(self, path: str, params: Mapping[str, Any] | None = None) -> Any:
        return self.request("GET", path, params=params)


# Process-wide default client. Lazily resolved on first use so importing
# `polnor` doesn't require credentials — only the first API call does.
_default_client: Client | None = None


def get_default_client() -> Client:
    global _default_client
    if _default_client is None:
        _default_client = Client(Config.resolve())
    return _default_client


def set_token(token: str, *, api_url: str | None = None, warehouse_id: str | None = None) -> None:
    """Override the default credentials in-process.

    Useful for notebooks/scripts that want to rotate a token without
    setting env vars or touching the config file. Replaces any previously
    resolved default client.
    """
    global _default_client
    cfg = Config(
        api_url=(api_url or os.environ.get("POLNOR_API_URL") or DEFAULT_API_URL).rstrip("/"),
        token=token,
        warehouse_id=warehouse_id or os.environ.get("POLNOR_WAREHOUSE_ID") or None,
    )
    _default_client = Client(cfg)


def reset_default_client() -> None:
    """Drop the cached default client. Next API call re-resolves config."""
    global _default_client
    _default_client = None
