"""Compute resource — VM lifecycle on the client's cloud provider.

Compute = the VMs that run notebooks, jobs, and model serving. Backend
provisions them through the configured cloud provider (OVH, Scaleway).

Use ``compute.create + compute.start`` to spin one up; ``compute.stop``
to free the VM (Polnor stops the VM entirely; status flips back to
"stopped" — re-``start`` provisions a fresh VM).
"""

from __future__ import annotations

import builtins
from typing import Any

from ._client import Client, get_default_client
from ._resource import get_resource, list_resource, post_action, wait_for_status

_PATH = "/compute"
_RUNNING = {"running"}
_TERMINAL = {"running", "stopped", "error"}


def list(*, client: Client | None = None) -> builtins.list[dict]:
    """List compute instances in the workspace."""
    return list_resource(_PATH, client=client)


def get(name_or_id: str, *, client: Client | None = None) -> dict:
    """Fetch one compute by id or name."""
    return get_resource(_PATH, name_or_id, client=client)


def create(
    *,
    name: str,
    cpu_cores: int = 2,
    memory_gb: int = 7,
    disk_gb: int = 50,
    gpu_type: str | None = None,
    gpu_count: int = 0,
    region: str = "GRA9",
    provider: str = "ovh",
    image: str | None = None,
    auto_stop_minutes: int = 30,
    tags: dict[str, str] | None = None,
    client: Client | None = None,
) -> dict:
    """Create a compute record. Doesn't start it — call ``start()`` next.

    GPU types depend on the provider — for OVH common ones are
    ``T4``, ``A10``, ``A100``. ``gpu_count=0`` (default) → CPU instance.
    """
    c = client or get_default_client()
    payload: dict[str, Any] = {
        "name": name,
        "type": "gpu" if gpu_count > 0 else "cpu",
        "provider": provider,
        "cpu_cores": cpu_cores,
        "memory_gb": memory_gb,
        "disk_gb": disk_gb,
        "region": region,
        "auto_stop_minutes": auto_stop_minutes,
    }
    if gpu_type:
        payload["gpu_type"] = gpu_type
    if gpu_count:
        payload["gpu_count"] = gpu_count
    if image:
        payload["image"] = image
    if tags:
        payload["tags"] = tags
    return c.post(_PATH, json=payload)


def start(name_or_id: str, *, wait: bool = True, timeout: float = 600.0,
          client: Client | None = None) -> dict:
    """Provision the VM. With ``wait=True`` (default) blocks until the
    agent connects (status=running) or ``timeout`` elapses.
    """
    cmp = get(name_or_id, client=client)
    post_action(_PATH, f"{cmp['id']}/start", client=client)
    if not wait:
        return get(cmp["id"], client=client)
    return wait_for_status(
        None, get_fn=get, name_or_id=cmp["id"],
        target=_RUNNING, terminal=_TERMINAL, timeout=timeout, client=client,
    )


def stop(name_or_id: str, *, wait: bool = True, timeout: float = 300.0,
         client: Client | None = None) -> dict:
    """Terminate the VM. The compute row is kept; re-start to get a new VM."""
    cmp = get(name_or_id, client=client)
    post_action(_PATH, f"{cmp['id']}/stop", client=client)
    if not wait:
        return get(cmp["id"], client=client)
    return wait_for_status(
        None, get_fn=get, name_or_id=cmp["id"],
        target={"stopped", "error"}, terminal=_TERMINAL, timeout=timeout, client=client,
    )


def delete(name_or_id: str, *, client: Client | None = None) -> None:
    """Delete the compute record (also frees the VM if still running)."""
    c = client or get_default_client()
    cmp = get(name_or_id, client=c)
    c.delete(f"{_PATH}/{cmp['id']}")


def logs(name_or_id: str, *, tail: int = 200, client: Client | None = None) -> builtins.list[dict]:
    """Fetch the most recent log entries from the compute's agent."""
    c = client or get_default_client()
    cmp = get(name_or_id, client=c)
    body = c.get(f"{_PATH}/{cmp['id']}/logs", params={"tail": tail})
    if isinstance(body, builtins.list):
        return body
    return body.get("data") or body.get("logs") or [] if isinstance(body, dict) else []


def install_library(name_or_id: str, *, libraries: builtins.list[dict],
                    client: Client | None = None) -> dict:
    """Install pip / conda libraries on the compute.

    ``libraries`` is a list of specs matching the agent's protocol::

        polnor.compute.install_library("my-compute", libraries=[
            {"pypi": {"package": "pendulum"}},
            {"pypi": {"package": "requests", "version": "2.32"}},
            {"conda": {"package": "numpy"}},
        ])
    """
    c = client or get_default_client()
    cmp = get(name_or_id, client=c)
    return c.post(f"{_PATH}/{cmp['id']}/libraries/install", json={"libraries": libraries})


def list_libraries(name_or_id: str, *, client: Client | None = None) -> builtins.list[dict]:
    """List libraries installed (or pending) on a compute."""
    c = client or get_default_client()
    cmp = get(name_or_id, client=c)
    body = c.get(f"{_PATH}/{cmp['id']}/libraries")
    if isinstance(body, dict) and "library_statuses" in body:
        return body["library_statuses"]
    return body if isinstance(body, builtins.list) else []
