from __future__ import annotations

from pathlib import Path

from wexample_migration.migration_state import MigrationState


def test_exists_false_when_no_file(tmp_path: Path) -> None:
    assert not MigrationState.exists(tmp_path)


def test_load_returns_empty_state_when_no_file(tmp_path: Path) -> None:
    state = MigrationState.load(tmp_path)
    assert state.current_version is None
    assert state.applied == []


def test_mark_applied_updates_current_version(tmp_path: Path) -> None:
    state = MigrationState.load(tmp_path)
    state.mark_applied("1.0.0")
    state.mark_applied("1.1.0")

    assert state.current_version == "1.1.0"
    assert len(state.applied) == 2


def test_save_and_reload(tmp_path: Path) -> None:
    state = MigrationState.load(tmp_path)
    state.mark_applied("1.0.0")
    state.save()

    assert MigrationState.exists(tmp_path)

    reloaded = MigrationState.load(tmp_path)
    assert reloaded.current_version == "1.0.0"
    assert len(reloaded.applied) == 1
    assert reloaded.applied[0].version == "1.0.0"


def test_state_file_path(tmp_path: Path) -> None:
    path = MigrationState.get_state_path(tmp_path)
    assert path == tmp_path / ".wex/migration/state.yml"
