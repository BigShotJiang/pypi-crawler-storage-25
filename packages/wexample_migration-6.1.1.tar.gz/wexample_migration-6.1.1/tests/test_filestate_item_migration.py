from __future__ import annotations

from pathlib import Path

import pytest

from wexample_migration.filestate.filestate_item_migration import FilestateItemMigration
from wexample_migration.migration_context import MigrationContext
from wexample_migration.migration_runner import MigrationRunner


def test_apply_is_abstract() -> None:
    """get_filestate_config must be implemented — base class raises."""

    class Incomplete(FilestateItemMigration):
        VERSION = "1.0.0"

    ctx = MigrationContext(target_path=Path("/tmp"))
    migration = Incomplete()
    with pytest.raises(NotImplementedError):
        migration.get_filestate_config(ctx)


def test_filestate_migration_creates_file(tmp_path: Path) -> None:
    runner = MigrationRunner(migrations=[CreateFileMigration])
    context = MigrationContext(target_path=tmp_path)

    applied = runner.run(context)

    assert applied == ["1.0.0"]
    assert (tmp_path / "migrated.txt").exists()
    assert (tmp_path / "migrated.txt").read_text() == "hello from migration"


def test_filestate_migration_dry_run_does_not_write(tmp_path: Path) -> None:
    runner = MigrationRunner(migrations=[CreateFileMigration])
    context = MigrationContext(target_path=tmp_path, dry_run=True)

    applied = runner.run(context)

    assert applied == ["1.0.0"]
    assert not (tmp_path / "migrated.txt").exists()


class CreateFileMigration(FilestateItemMigration):
    VERSION = "1.0.0"

    def get_filestate_config(self, context: MigrationContext) -> dict:
        return {
            "children": [
                {
                    "name": "migrated.txt",
                    "type": "file",
                    "should_exist": True,
                    "default_content": "hello from migration",
                }
            ]
        }
