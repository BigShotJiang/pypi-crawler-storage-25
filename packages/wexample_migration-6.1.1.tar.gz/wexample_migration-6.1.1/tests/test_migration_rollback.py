from __future__ import annotations

from pathlib import Path

from wexample_migration.abstract_migration import AbstractMigration
from wexample_migration.migration_context import MigrationContext
from wexample_migration.migration_runner import MigrationRunner
from wexample_migration.migration_state import MigrationState


def test_rollback_calls_migration_rollback_method(tmp_path: Path) -> None:
    Migration100.rolled_back = False
    runner = MigrationRunner(migrations=[Migration100, Migration110])
    context = MigrationContext(target_path=tmp_path)

    runner.run(context)
    assert (tmp_path / "v1").exists()

    rolled_back = runner.rollback(context)

    assert rolled_back == "1.1.0"
    # 1.1.0 has no rollback() override — no-op, that's fine
    state = MigrationState.load(tmp_path)
    assert state.current_version == "1.0.0"
    assert len(state.applied) == 1


def test_rollback_nothing_to_rollback(tmp_path: Path) -> None:
    runner = MigrationRunner(migrations=[Migration100])
    context = MigrationContext(target_path=tmp_path)

    result = runner.rollback(context)
    assert result is None


def test_rollback_with_custom_rollback_impl(tmp_path: Path) -> None:
    Migration100.rolled_back = False
    runner = MigrationRunner(migrations=[Migration100])
    context = MigrationContext(target_path=tmp_path)

    runner.run(context)
    rolled_back = runner.rollback(context)

    assert rolled_back == "1.0.0"
    assert Migration100.rolled_back is True
    state = MigrationState.load(tmp_path)
    assert state.current_version is None
    assert state.applied == []


def test_with_migration_workdir_mixin(tmp_path: Path) -> None:
    from wexample_migration.workdir.mixin.with_migration_workdir_mixin import (
        WithMigrationWorkdirMixin,
    )

    class FakeWorkdir(WithMigrationWorkdirMixin):
        def get_migrations(self):
            return [Migration100, Migration110]

        def get_path(self):
            return tmp_path

    workdir = FakeWorkdir()

    applied = workdir.migration_run()
    assert applied == ["1.0.0", "1.1.0"]

    status = workdir.migration_status()
    assert status["current_version"] == "1.1.0"
    assert status["pending"] == []

    rolled_back = workdir.migration_rollback()
    assert rolled_back == "1.1.0"

    status = workdir.migration_status()
    assert status["current_version"] == "1.0.0"
    assert status["pending"] == ["1.1.0"]


class Migration100(AbstractMigration):
    VERSION = "1.0.0"
    rolled_back: bool = False

    def apply(self, context: MigrationContext) -> None:
        (context.target_path / "v1").touch()

    def rollback(self, context: MigrationContext) -> None:
        Migration100.rolled_back = True
        (context.target_path / "v1").unlink(missing_ok=True)


class Migration110(AbstractMigration):
    VERSION = "1.1.0"

    def apply(self, context: MigrationContext) -> None:
        (context.target_path / "v1.1").touch()
