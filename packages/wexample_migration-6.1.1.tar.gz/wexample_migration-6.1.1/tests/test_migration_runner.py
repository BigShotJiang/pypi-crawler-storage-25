from __future__ import annotations

from pathlib import Path

from wexample_migration.abstract_migration import AbstractMigration
from wexample_migration.migration_context import MigrationContext
from wexample_migration.migration_runner import MigrationRunner
from wexample_migration.migration_state import MigrationState


def test_bootstrap_detects_legacy_version(tmp_path: Path) -> None:
    (tmp_path / "legacy_marker").touch()

    runner = MigrationRunner(migrations=[MigrationWithGuess, Migration110])
    context = MigrationContext(target_path=tmp_path)

    applied = runner.run(context)

    # 1.0.0 detected via guess_version — should be skipped, only 1.1.0 applied
    assert applied == ["1.1.0"]
    state = MigrationState.load(tmp_path)
    assert state.current_version == "1.1.0"
    assert state.applied[0].version == "1.1.0"


def test_bootstrap_no_match_applies_all(tmp_path: Path) -> None:
    runner = MigrationRunner(migrations=[MigrationWithGuess, Migration110])
    context = MigrationContext(target_path=tmp_path)

    # No legacy_marker file — guess_version returns False — applies everything
    applied = runner.run(context)
    assert applied == ["1.0.0", "1.1.0"]


def test_run_applies_all_migrations_on_fresh_workdir(tmp_path: Path) -> None:
    runner = MigrationRunner(migrations=[Migration100, Migration110, Migration200])
    context = MigrationContext(target_path=tmp_path)

    applied = runner.run(context)

    assert applied == ["1.0.0", "1.1.0", "2.0.0"]
    assert (tmp_path / "v1").exists()
    assert (tmp_path / "v1.1").exists()
    assert (tmp_path / "v2").exists()


def test_run_applies_in_semver_order(tmp_path: Path) -> None:
    # Pass migrations in wrong order — runner should sort them
    runner = MigrationRunner(migrations=[Migration200, Migration100, Migration110])
    context = MigrationContext(target_path=tmp_path)

    applied = runner.run(context)

    assert applied == ["1.0.0", "1.1.0", "2.0.0"]


def test_run_dry_run_does_not_write(tmp_path: Path) -> None:
    runner = MigrationRunner(migrations=[Migration100, Migration110])
    context = MigrationContext(target_path=tmp_path, dry_run=True)

    applied = runner.run(context)

    assert applied == ["1.0.0", "1.1.0"]
    assert not (tmp_path / "v1").exists()
    assert not MigrationState.exists(tmp_path)


def test_run_skips_already_applied_migrations(tmp_path: Path) -> None:
    state = MigrationState.load(tmp_path)
    state.mark_applied("1.0.0")
    state.save()

    runner = MigrationRunner(migrations=[Migration100, Migration110, Migration200])
    context = MigrationContext(target_path=tmp_path)

    applied = runner.run(context)

    assert applied == ["1.1.0", "2.0.0"]
    assert not (tmp_path / "v1").exists()


def test_status_returns_pending(tmp_path: Path) -> None:
    state = MigrationState.load(tmp_path)
    state.mark_applied("1.0.0")
    state.save()

    runner = MigrationRunner(migrations=[Migration100, Migration110, Migration200])
    context = MigrationContext(target_path=tmp_path)

    result = runner.status(context)

    assert result["current_version"] == "1.0.0"
    assert result["applied"] == ["1.0.0"]
    assert result["pending"] == ["1.1.0", "2.0.0"]


class Migration100(AbstractMigration):
    VERSION = "1.0.0"

    def apply(self, context: MigrationContext) -> None:
        (context.target_path / "v1").touch()


class Migration110(AbstractMigration):
    VERSION = "1.1.0"

    def apply(self, context: MigrationContext) -> None:
        (context.target_path / "v1.1").touch()


class Migration200(AbstractMigration):
    VERSION = "2.0.0"

    def apply(self, context: MigrationContext) -> None:
        (context.target_path / "v2").touch()


class MigrationWithGuess(AbstractMigration):
    VERSION = "1.0.0"

    def apply(self, context: MigrationContext) -> None:
        pass

    def guess_version(self, context: MigrationContext) -> bool:
        return (context.target_path / "legacy_marker").exists()
