from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

import yaml
from wexample_helpers.classes.base_class import BaseClass
from wexample_helpers.classes.field import public_field
from wexample_helpers.decorator.base_class import base_class

from wexample_migration.migration_applied_entry import MigrationAppliedEntry

if TYPE_CHECKING:
    pass

STATE_RELATIVE_PATH = ".wex/migration/state.yml"


@base_class
class MigrationState(BaseClass):
    applied: list[MigrationAppliedEntry] = public_field(
        factory=list,
        description="Ordered history of applied migrations",
    )
    current_version: str | None = public_field(
        default=None,
        description="Currently applied migration version",
    )
    target_path: Path = public_field(
        description="Root path of the workdir this state belongs to",
    )

    @classmethod
    def exists(cls, target_path: Path) -> bool:
        return cls.get_state_path(target_path).exists()

    @classmethod
    def get_state_path(cls, target_path: Path) -> Path:
        return target_path / STATE_RELATIVE_PATH

    @classmethod
    def load(cls, target_path: Path) -> MigrationState:
        state_path = cls.get_state_path(target_path)

        if not state_path.exists():
            return cls(target_path=target_path)

        with open(state_path) as f:
            data = yaml.safe_load(f) or {}

        applied = [MigrationAppliedEntry(**entry) for entry in data.get("applied", [])]

        return cls(
            target_path=target_path,
            current_version=data.get("current_version"),
            applied=applied,
        )

    def mark_applied(self, version: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self.applied.append(MigrationAppliedEntry(version=version, applied_at=now))
        self.current_version = version

    def save(self) -> None:
        state_path = self.get_state_path(self.target_path)
        state_path.parent.mkdir(parents=True, exist_ok=True)

        data = {
            "current_version": self.current_version,
            "applied": [
                {"version": e.version, "applied_at": e.applied_at} for e in self.applied
            ],
        }

        with open(state_path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, allow_unicode=True)
