from __future__ import annotations

import attrs


@attrs.define(kw_only=True)
class MigrationAppliedEntry:
    applied_at: str
    version: str
