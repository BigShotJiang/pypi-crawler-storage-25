from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_filestate.enum.scopes import Scope
from wexample_filestate.utils.file_state_manager import FileStateManager
from wexample_helpers.classes.abstract_method import abstract_method
from wexample_helpers.decorator.base_class import base_class
from wexample_prompt.common.io_manager import IoManager

from wexample_migration.abstract_migration import AbstractMigration

if TYPE_CHECKING:
    from wexample_config.const.types import DictConfig

    from wexample_migration.migration_context import MigrationContext


@base_class
class FilestateItemMigration(AbstractMigration):
    """
    Migration that applies a filestate configuration to the target workdir.

    Subclasses implement get_filestate_config() to declare the desired state
    using filestate options (children, should_exist, default_content, mode, etc.).
    The migration creates a FileStateManager rooted at context.target_path
    and applies the configuration, reusing filestate's operation pipeline,
    dry_run support, and rollback history.
    """

    def apply(self, context: MigrationContext) -> None:
        config = self.get_filestate_config(context)
        manager = FileStateManager.create_from_path(
            path=context.target_path,
            config=config,
            io=IoManager(),
        )

        if context.dry_run:
            manager.dry_run(scopes=set(Scope))
        else:
            manager.apply()

    @abstract_method
    def get_filestate_config(self, context: MigrationContext) -> DictConfig:
        pass
