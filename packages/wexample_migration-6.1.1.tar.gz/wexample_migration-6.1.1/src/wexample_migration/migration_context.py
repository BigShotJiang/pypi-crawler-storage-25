from __future__ import annotations

from pathlib import Path
from typing import Any

from wexample_helpers.classes.base_class import BaseClass
from wexample_helpers.classes.field import public_field
from wexample_helpers.decorator.base_class import base_class


@base_class
class MigrationContext(BaseClass):
    dry_run: bool = public_field(
        default=False,
        description="If True, migrations are evaluated but no changes are written",
    )
    extras: dict[str, Any] = public_field(
        factory=dict,
        description="Untyped parameter bag for caller-specific data (workdir, kernel, …). Migration package stays decoupled; consumers cast as needed.",
    )
    target_path: Path = public_field(
        description="Root path of the workdir being migrated",
    )
