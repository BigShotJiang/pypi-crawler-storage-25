from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from wexample_migration.abstract_migration import AbstractMigration
    from wexample_migration.migration_context import MigrationContext
    from wexample_migration.migration_runner import MigrationRunner


class WithMigrationWorkdirMixin:
    """
    Mixin for wex workdirs that support migrations.

    Mix this into a Workdir subclass and override get_migrations() to declare
    which AbstractMigration subclasses apply to this workdir. The mixin then
    provides migration_run(), migration_status(), and migration_rollback()
    methods that wex commands (filestate::migration/run, etc.) can call.

    Example:
        class MyWorkdir(WithMigrationWorkdirMixin, Workdir):
            def get_migrations(self):
                return [Migration100, Migration110, Migration200]
    """

    def get_migration_runner(self) -> MigrationRunner:
        from wexample_migration.migration_runner import MigrationRunner

        return MigrationRunner(migrations=self.get_migrations())

    def get_migrations(self) -> list[type[AbstractMigration]]:
        """Override to return the list of migration classes for this workdir."""
        return []

    def migration_rollback(self, extras: dict[str, Any] | None = None) -> str | None:
        """
        Rollback the last applied migration. Returns the rolled-back version,
        or None if there is nothing to rollback.
        """
        context = self._build_migration_context(extras=extras)
        return self.get_migration_runner().rollback(context)

    def migration_run(
        self,
        dry_run: bool = False,
        extras: dict[str, Any] | None = None,
    ) -> list[str]:
        """Apply all pending migrations. Returns the list of applied versions."""
        context = self._build_migration_context(dry_run=dry_run, extras=extras)
        return self.get_migration_runner().run(context)

    def migration_status(self, extras: dict[str, Any] | None = None) -> dict:
        """Return current version, applied history, and pending migrations."""
        context = self._build_migration_context(extras=extras)
        return self.get_migration_runner().status(context)

    def _build_migration_context(
        self,
        dry_run: bool = False,
        extras: dict[str, Any] | None = None,
    ) -> MigrationContext:
        from wexample_migration.migration_context import MigrationContext

        return MigrationContext(
            target_path=self.get_path(),
            dry_run=dry_run,
            extras=dict(extras) if extras else {},
        )
