from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import yaml
from wexample_helpers.classes.base_class import BaseClass
from wexample_helpers.classes.field import public_field
from wexample_helpers.decorator.base_class import base_class

if TYPE_CHECKING:
    from wexample_migration.abstract_migration import AbstractMigration
    from wexample_migration.migration_context import MigrationContext

_CONFIG_RELATIVE_PATH = ".wex/config.yml"
_VERSION_KEYS = ["wex.version", "global.version"]


def _dict_get_dotted(data: dict, dotted_key: str):
    keys = dotted_key.split(".")
    node = data
    for key in keys:
        if not isinstance(node, dict) or key not in node:
            return None
        node = node[key]
    return node


def _dict_set_dotted(data: dict, dotted_key: str, value) -> None:
    keys = dotted_key.split(".")
    node = data
    for key in keys[:-1]:
        node = node.setdefault(key, {})
    node[keys[-1]] = value


def _parse_version(version: str) -> tuple[int, ...]:
    try:
        return tuple(int(part) for part in version.split("."))
    except ValueError:
        return (0,)


@base_class
class MigrationRunner(BaseClass):
    migrations: list[type[AbstractMigration]] = public_field(
        factory=list,
        description="Ordered list of migration classes to manage",
    )

    def rollback(self, context: MigrationContext) -> str | None:
        """
        Rollback the migration matching the current version.
        Sets version back to the previous migration in the sorted list.
        Returns the rolled-back version, or None if nothing to rollback.
        """
        current_version = self._read_version(context.target_path)

        if current_version is None:
            return None

        sorted_migrations = self._sorted_migrations()
        current_idx = next(
            (
                i
                for i, m in enumerate(sorted_migrations)
                if m.get_version() == current_version
            ),
            None,
        )

        if current_idx is None:
            return None

        migration_cls = sorted_migrations[current_idx]
        migration_cls().rollback(context)

        previous_version = (
            sorted_migrations[current_idx - 1].get_version()
            if current_idx > 0
            else None
        )

        if not context.dry_run:
            if previous_version is not None:
                self._write_version(context.target_path, previous_version)

        return current_version

    def run(self, context: MigrationContext) -> list[str]:
        """
        Apply all pending migrations. Returns the list of applied (or would-be) versions.
        """
        current_version = self._read_version(context.target_path)

        if current_version is None:
            current_version = self._bootstrap_version(context)

        applied = []
        for migration_cls in self._pending_migrations(current_version):
            migration = migration_cls()

            if not migration.is_applicable(context):
                continue

            if not context.dry_run:
                migration.apply(context)
                self._write_version(context.target_path, migration_cls.get_version())

            applied.append(migration_cls.get_version())
            current_version = migration_cls.get_version()

        return applied

    def status(self, context: MigrationContext) -> dict:
        """
        Return current version and pending migrations. Does not apply anything.
        """
        current_version = self._read_version(context.target_path)
        pending = self._pending_migrations(current_version)

        sorted_migrations = self._sorted_migrations()
        applied = (
            [
                m.get_version()
                for m in sorted_migrations
                if _parse_version(m.get_version()) <= _parse_version(current_version)
            ]
            if current_version is not None
            else []
        )

        return {
            "current_version": current_version,
            "applied": applied,
            "pending": [cls.get_version() for cls in pending],
        }

    def _bootstrap_version(self, context: MigrationContext) -> str | None:
        """
        Detect the version of a legacy workdir with no version in config.yml.
        Iterates migrations in reverse order, returns the first matching guess_version().
        """
        for migration_cls in reversed(self._sorted_migrations()):
            if migration_cls().guess_version(context):
                return migration_cls.get_version()
        return None

    def _pending_migrations(
        self, current_version: str | None
    ) -> list[type[AbstractMigration]]:
        sorted_migrations = self._sorted_migrations()

        if current_version is None:
            return sorted_migrations

        return [
            m
            for m in sorted_migrations
            if _parse_version(m.get_version()) > _parse_version(current_version)
        ]

    def _read_version(self, target_path: Path) -> str | None:
        config_path = target_path / _CONFIG_RELATIVE_PATH
        if not config_path.exists():
            return None

        with open(config_path) as f:
            data = yaml.safe_load(f) or {}

        for dotted_key in _VERSION_KEYS:
            value = _dict_get_dotted(data, dotted_key)
            if value is not None:
                return str(value)

        return None

    def _sorted_migrations(self) -> list[type[AbstractMigration]]:
        return sorted(self.migrations, key=lambda m: _parse_version(m.get_version()))

    def _write_version(self, target_path: Path, version: str) -> None:
        config_path = target_path / _CONFIG_RELATIVE_PATH
        if not config_path.exists():
            return

        with open(config_path) as f:
            data = yaml.safe_load(f) or {}

        # Write to the first key that already exists, or default to the first
        written = False
        for dotted_key in _VERSION_KEYS:
            if _dict_get_dotted(data, dotted_key) is not None:
                _dict_set_dotted(data, dotted_key, version)
                written = True
                break

        if not written:
            _dict_set_dotted(data, _VERSION_KEYS[0], version)

        with open(config_path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, allow_unicode=True)
