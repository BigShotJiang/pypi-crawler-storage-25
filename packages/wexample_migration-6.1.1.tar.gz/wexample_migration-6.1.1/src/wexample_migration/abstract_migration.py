from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from wexample_helpers.classes.abstract_method import abstract_method
from wexample_helpers.classes.base_class import BaseClass
from wexample_helpers.decorator.base_class import base_class

if TYPE_CHECKING:
    from wexample_migration.migration_context import MigrationContext


@base_class
class AbstractMigration(BaseClass):
    # Override in each migration subclass
    VERSION: ClassVar[str] = ""
    DESCRIPTION: ClassVar[str] = ""

    @classmethod
    def get_version(cls) -> str:
        return cls.VERSION

    @abstract_method
    def apply(self, context: MigrationContext) -> None:
        pass

    def guess_version(self, context: MigrationContext) -> bool:
        """
        Bootstrap fallback: inspect the workdir state and return True if it
        matches the version this migration targets. Only called when no
        state file exists. Override in migrations that need to support
        legacy workdir detection (e.g. wex v5 → v6).
        """
        return False

    def is_applicable(self, context: MigrationContext) -> bool:
        """Optional guard. Return False to skip this migration."""
        return True

    def rollback(self, context: MigrationContext) -> None:
        """Override to support rollback. No-op by default."""
