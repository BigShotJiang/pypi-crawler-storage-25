from setuptools import setup, find_packages
import os

VERSION = "1.4.11"
DESCRIPTION = "compile python to ELF - Cython based compiler"

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="pycc-compiler",
    version=VERSION,
    author="pycc-dev",
    description=DESCRIPTION,
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    py_modules=["pycc"],
    install_requires=[
        "cython>=3.0.0",
    ],
    entry_points={
        "console_scripts": [
            "pycc=pycc:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Cython",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)
