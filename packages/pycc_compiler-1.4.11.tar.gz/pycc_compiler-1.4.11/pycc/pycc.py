#!/usr/bin/env python3

import os
import sys
import shutil
import subprocess
import re
import readline
import time

VERSION = "1.4.11"
DESCRIPTION = "compile python to ELF"

RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
CYAN = '\033[96m'
NC = '\033[0m'

VERBOSE = False
QUIET = False

def print_error(msg):
    print(f"pycc: {RED}error:{NC} {msg}", file=sys.stderr)

def print_warning(msg):
    if not QUIET:
        print(f"pycc: {YELLOW}warning:{NC} {msg}", file=sys.stderr)

def print_success(msg):
    if VERBOSE and not QUIET:
        print(f"pycc: {GREEN}success:{NC} {msg}", file=sys.stderr)

def print_info(msg):
    if VERBOSE and not QUIET:
        print(f"pycc: {msg}", file=sys.stderr)

def print_debug(msg):
    if VERBOSE:
        print(msg, file=sys.stderr)

def print_cmd(cmd):
    if VERBOSE:
        print(' '.join(cmd), file=sys.stderr)

def spinning_cursor():
    while True:
        for cursor in '|/-\\':
            yield cursor

def show_progress(message, duration=0.5):
    spinner = spinning_cursor()
    end_time = time.time() + duration
    while time.time() < end_time:
        sys.stderr.write(f'\r{message} {next(spinner)} ')
        sys.stderr.flush()
        time.sleep(0.1)
    sys.stderr.write('\r' + ' ' * (len(message) + 2) + '\r')
    sys.stderr.flush()

def get_python_version():
    env_version = os.environ.get('PYCC_PY_VERSION')
    if env_version:
        return env_version
    try:
        result = subprocess.run(
            ['python3', '-c', 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")'],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except:
        pass
    return "3.13"

def get_clang_version():
    try:
        result = subprocess.run(['clang', '--version'], capture_output=True, text=True)
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            if lines:
                return lines[0]
    except:
        pass
    return "clang"

def get_python_include():
    py_version = get_python_version()
    include_path = f"/data/data/com.termux/files/usr/include/python{py_version}"
    if os.path.exists(include_path):
        return include_path
    try:
        result = subprocess.run(['python3-config', '--includes'], capture_output=True, text=True)
        if result.returncode == 0:
            match = re.search(r'-I([^\s]+)', result.stdout)
            if match:
                return match.group(1)
    except:
        pass
    return include_path

def get_python_lib():
    py_version = get_python_version()
    lib_path = f"/data/data/com.termux/files/usr/lib"
    lib_name = f"python{py_version}"
    return lib_path, lib_name

def get_compiler(input_file):
    if input_file.endswith(('.c')):
        return 'clang'
    elif input_file.endswith(('.cpp', '.cc', '.cxx')):
        return 'clang++'
    else:
        return None

def is_valid_module_name(name):
    return re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', name) is not None

def fix_module_name(input_file):
    base_name = os.path.splitext(os.path.basename(input_file))[0]
    if is_valid_module_name(base_name):
        return input_file, None
    new_base_name = f"pycc_v{VERSION}_{base_name}"
    new_base_name = re.sub(r'[^a-zA-Z0-9_]', '_', new_base_name)
    if not re.match(r'^[a-zA-Z_]', new_base_name):
        new_base_name = '_' + new_base_name
    new_file = os.path.join(os.path.dirname(input_file), f"{new_base_name}.py")
    print_warning(f"Invalid module name '{base_name}', renamed to '{new_base_name}'")
    shutil.copy2(input_file, new_file)
    return new_file, new_base_name

def add_compile_marker(output_file):
    marker = f"Compiled by pycc {VERSION}"
    try:
        with open(output_file, 'ab') as f:
            f.write(f"\n{marker}\0".encode())
    except:
        pass

def run_clang_mode(args):
    if len(args) < 2:
        print_error("--clang mode missing arguments")
        sys.exit(1)
    clang_args = args[1:]
    compiler = 'clang'
    output_file = None
    for i, arg in enumerate(clang_args):
        if arg in ['-o', '--output'] and i + 1 < len(clang_args):
            output_file = clang_args[i + 1]
            break
    for arg in clang_args:
        if not arg.startswith('-') and os.path.exists(arg):
            ext_compiler = get_compiler(arg)
            if ext_compiler:
                compiler = ext_compiler
            break
    if not output_file:
        for arg in clang_args:
            if not arg.startswith('-') and os.path.exists(arg):
                base_name = os.path.splitext(os.path.basename(arg))[0]
                output_file = f"./{base_name}.out"
                clang_args = clang_args[:] + ['-o', output_file]
                break
    cmd = [compiler] + clang_args
    print_cmd(cmd)
    result = subprocess.run(cmd)
    sys.exit(result.returncode)

def compile_to_so(input_file, output, opt_level, other_flags, site_install, py_version, py_include, py_lib_path, py_lib_name):
    file_ext = os.path.splitext(input_file)[1].lower()
    is_c = file_ext in ['.c', '.cpp', '.cc', '.cxx']
    work_dir = os.path.expanduser('~/tmp/pycc_build')
    os.makedirs(work_dir, exist_ok=True)
    try:
        if is_c:
            so_output = output if output else f"{os.path.splitext(os.path.basename(input_file))[0]}.so"
            compiler = 'clang' if file_ext == '.c' else 'clang++'
            cmd = [compiler, '-shared', '-fPIC', f'-O{opt_level}', '-o', so_output, input_file,
                   f'-I{py_include}', f'-L{py_lib_path}', f'-l{py_lib_name}',
                   '-lpthread', '-lm', '-lutil', '-ldl'] + other_flags
            print_cmd(cmd)
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode != 0:
                print_error("Compilation error:")
                print(result.stderr, file=sys.stderr)
                sys.exit(1)
            os.chmod(so_output, 0o755)
            add_compile_marker(so_output)
            if site_install:
                target = os.path.join(f"{py_lib_path}/python{py_version}/site-packages", os.path.basename(so_output))
                shutil.copy2(so_output, target)
                os.chmod(target, 0o755)
                add_compile_marker(target)
                if VERBOSE and not QUIET:
                    print_success(f"Installed to: {target}")
            elif VERBOSE and not QUIET:
                print_info(f"Shared library: {so_output}")
            return
        base_name = os.path.splitext(os.path.basename(input_file))[0]
        module_name = output if output else base_name
        module_name = os.path.splitext(os.path.basename(module_name))[0]
        if not is_valid_module_name(module_name):
            print_error(f"Invalid module name '{module_name}'")
            sys.exit(1)
        module_pyx = os.path.join(work_dir, f"{module_name}.pyx")
        shutil.copy2(input_file, module_pyx)
        out_file = os.path.join(work_dir, f"{module_name}.c")
        cmd = ['cython', '--embed', '-3', module_pyx, '-o', out_file]
        print_cmd(cmd)
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print_error("Cython error:")
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
        so_output = output if output else f"{module_name}.so"
        cmd = ['clang', '-shared', '-fPIC', f'-O{opt_level}', '-o', so_output, out_file,
               f'-I{py_include}', f'-L{py_lib_path}', f'-l{py_lib_name}',
               '-lpthread', '-lm', '-lutil', '-ldl'] + other_flags
        print_cmd(cmd)
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print_error("Compilation error:")
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
        os.chmod(so_output, 0o755)
        add_compile_marker(so_output)
        if site_install:
            target = os.path.join(f"{py_lib_path}/python{py_version}/site-packages", os.path.basename(so_output))
            shutil.copy2(so_output, target)
            os.chmod(target, 0o755)
            add_compile_marker(target)
            if VERBOSE and not QUIET:
                print_success(f"Installed to: {target}")
        elif VERBOSE and not QUIET:
            print_info(f"Shared library: {so_output}")
    finally:
        if os.path.exists(work_dir):
            shutil.rmtree(work_dir)

interactive_code = []

def is_print_statement(line):
    stripped = line.strip()
    return re.match(r'^print\s*\(', stripped) is not None

def is_shell_command(line):
    return line.strip().startswith('shell:')

def is_os_system_output(line):
    stripped = line.strip()
    return re.search(r'^os\.system\s*\(\s*[\'"]?(echo|printf)\s*', stripped) is not None

def interactive_mode():
    global interactive_code
    clang_ver = get_clang_version()
    py_ver = get_python_version()
    print(f"{GREEN}pycc version {VERSION}{NC} [{clang_ver}]")
    print(f"Python {py_ver}")
    print(f'Enter Python commands, type {CYAN}RUN{NC} to compile and execute, {CYAN}exit{NC} to quit')
    history_file = os.path.expanduser('~/.pycc_history')
    try:
        readline.read_history_file(history_file)
    except:
        pass
    temp_py = os.path.expanduser('~/tmp/__pycc_interaction__.py')
    temp_bin = os.path.expanduser('~/tmp/__pycc_interaction__.out')
    os.makedirs(os.path.dirname(temp_py), exist_ok=True)
    try:
        while True:
            try:
                line = input(f"{BLUE}P>>{NC} ").strip()
                if not line:
                    continue
                if line.lower() == 'exit':
                    break
                if line.upper() == 'RUN':
                    if interactive_code:
                        with open(temp_py, 'w') as f:
                            f.write('\n'.join(interactive_code))
                        show_progress("Compiling", 0.8)
                        pycc_cmd = sys.argv[0]
                        if not os.path.exists(pycc_cmd):
                            pycc_cmd = shutil.which('pycc')
                            if not pycc_cmd:
                                pycc_cmd = sys.executable + ' ' + __file__
                        cmd = [pycc_cmd, temp_py, '-o', temp_bin, '-q']
                        result = subprocess.run(cmd, capture_output=True, text=True)
                        if result.returncode != 0:
                            print(f"{RED}Compilation failed:{NC}")
                            if result.stderr:
                                for err_line in result.stderr.split('\n'):
                                    if err_line.strip():
                                        clean_line = re.sub(r'\x1b\[[0-9;]*m', '', err_line)
                                        if clean_line.strip():
                                            print(f"  {clean_line}")
                            continue
                        os.system('clear')
                        print(f"{CYAN}Running...{NC}\n")
                        subprocess.run([temp_bin])
                        print(f"\n{CYAN}--- Done ---{NC}")
                    else:
                        print(f"{YELLOW}No code to execute{NC}")
                    continue
                if is_shell_command(line):
                    shell_cmd = line[6:].strip()
                    if shell_cmd:
                        print(f"{CYAN}$ {shell_cmd}{NC}")
                        os.system(shell_cmd)
                    continue
                if is_os_system_output(line):
                    temp_os_py = os.path.expanduser('~/tmp/__pycc_os__.py')
                    with open(temp_os_py, 'w') as f:
                        f.write('\n'.join(interactive_code) + '\n' + line)
                    subprocess.run(['python3', temp_os_py])
                    os.unlink(temp_os_py)
                    continue
                if is_print_statement(line):
                    temp_print_py = os.path.expanduser('~/tmp/__pycc_print__.py')
                    with open(temp_print_py, 'w') as f:
                        f.write('\n'.join(interactive_code) + '\n' + line)
                    subprocess.run(['python3', temp_print_py])
                    os.unlink(temp_print_py)
                    continue
                interactive_code.append(line)
                try:
                    readline.write_history_file(history_file)
                except:
                    pass
            except KeyboardInterrupt:
                print(f"\n{YELLOW}Use 'exit' to quit{NC}")
            except EOFError:
                break
    finally:
        for f in [temp_py, temp_bin]:
            if os.path.exists(f):
                os.unlink(f)
    if interactive_code:
        print(f"{YELLOW}Unsaved code left (use RUN to execute){NC}")
    try:
        readline.write_history_file(history_file)
    except:
        pass

def main():
    global VERBOSE, QUIET
    if len(sys.argv) > 1 and sys.argv[1] in ['-i', '--interactive']:
        interactive_mode()
        return
    if len(sys.argv) > 1 and sys.argv[1] in ['--clang', '-clg']:
        run_clang_mode(sys.argv[1:])
        return
    if '--version' in sys.argv:
        print(f"pycc {VERSION}")
        print(DESCRIPTION)
        return
    if '--help' in sys.argv or '-h' in sys.argv:
        print(f"pycc {VERSION} - {DESCRIPTION}")
        print("\nUsage: pycc [options] <input.py/.pyx/.c/.cpp>")
        print("       pycc --clang [clang options...]")
        print("       pycc -i --interactive")
        print("\nOptions:")
        print("  -O0/-O1/-O2/-O3    Optimization level")
        print("  -o, --output        Output file")
        print("  -run                Compile and run")
        print("  -c                  Generate C file")
        print("  -cpp                Generate C++ file")
        print("  -so                 Generate shared library")
        print("  --site, -s          Install to site-packages")
        print("  -i, --interactive   Interactive mode")
        print("  -v                  Verbose mode")
        print("  -q                  Quiet mode")
        print("  -###                Show commands only")
        print("  --version           Version info")
        print("  --help, -h          This help")
        print("\nEnvironment:")
        print("  PYCC_PY_VERSION     Python version")
        return
    if len(sys.argv) < 2:
        print_error("Missing input file")
        sys.exit(1)
    input_file = None
    other_args = []
    script_args = []
    args_iter = iter(sys.argv[1:])
    for arg in args_iter:
        if not arg.startswith('-') and input_file is None:
            input_file = arg
        elif arg.startswith('-'):
            if arg == '-v':
                VERBOSE = True
            elif arg == '-q':
                QUIET = True
            else:
                other_args.append(arg)
                if arg in ['-o', '--output']:
                    try:
                        other_args.append(next(args_iter))
                    except StopIteration:
                        pass
        else:
            (script_args if input_file is not None else other_args).append(arg)
    if not input_file or not os.path.exists(input_file):
        print_error(f"File not found: {input_file}")
        sys.exit(1)
    file_ext = os.path.splitext(input_file)[1].lower()
    is_python = file_ext == '.py'
    is_pyx = file_ext == '.pyx'
    is_c = file_ext in ['.c', '.cpp', '.cc', '.cxx']
    output_c = '-c' in other_args
    output_cpp = '-cpp' in other_args
    output_so = '-so' in other_args
    run = '-run' in other_args
    dry_run = '-###' in other_args
    site_install = '--site' in other_args or '-s' in other_args
    if sum([output_c, output_cpp, output_so]) > 1:
        print_error("Only one of -c, -cpp, -so allowed")
        sys.exit(1)
    if is_c and not (output_c or output_cpp or output_so):
        clang_args = [sys.argv[0], '--clang'] + sys.argv[1:]
        has_output = any(a in ['-o', '--output'] for a in sys.argv[1:])
        if not has_output:
            base_name = os.path.splitext(os.path.basename(input_file))[0]
            new_args = []
            for a in sys.argv[1:]:
                if a == input_file:
                    new_args.extend(['-o', f"{base_name}.out", a])
                else:
                    new_args.append(a)
            clang_args = [sys.argv[0], '--clang'] + new_args
        run_clang_mode(clang_args)
        return
    if is_c and output_so:
        opt_level = "0"
        for opt in ['-O3', '-O2', '-O1', '-O0']:
            if opt in other_args:
                opt_level = opt[2]
                other_args = [a for a in other_args if a != opt]
                break
        for flag in ['-so', '--site', '-s']:
            if flag in other_args:
                other_args = [a for a in other_args if a != flag]
        other_flags = [a for a in other_args if a.startswith('-') and a not in ['-o', '--output']]
        output = None
        for i, a in enumerate(other_args):
            if a in ['-o', '--output'] and i + 1 < len(other_args):
                output = other_args[i + 1]
                break
        compile_to_so(input_file, output, opt_level, other_flags, site_install,
                      get_python_version(), get_python_include(), *get_python_lib())
        return
    if not (is_python or is_pyx):
        print_error(f"Unsupported file type: {input_file}")
        sys.exit(1)
    opt_level = "0"
    for opt in ['-O3', '-O2', '-O1', '-O0']:
        if opt in other_args:
            opt_level = opt[2]
            other_args = [a for a in other_args if a != opt]
            break
    if run:
        other_args = [a for a in other_args if a != '-run']
    if dry_run:
        other_args = [a for a in other_args if a != '-###']
    for flag in ['-c', '-cpp', '-so', '--site', '-s']:
        if flag in other_args:
            other_args = [a for a in other_args if a != flag]
    other_flags = [a for a in other_args if a.startswith('-') and a not in ['-o', '--output']]
    output = None
    for i, a in enumerate(other_args):
        if a in ['-o', '--output'] and i + 1 < len(other_args):
            output = other_args[i + 1]
            break
    if output_so:
        compile_to_so(input_file, output, opt_level, other_flags, site_install,
                      get_python_version(), get_python_include(), *get_python_lib())
        return
    if output_c or output_cpp:
        original_input = input_file
        input_file, new_name = fix_module_name(input_file)
        should_cleanup = new_name is not None
        work_dir = os.path.expanduser('~/tmp/pycc_build')
        os.makedirs(work_dir, exist_ok=True)
        try:
            base_name = os.path.splitext(os.path.basename(input_file))[0]
            pyx_file = os.path.join(work_dir, f"{base_name}.pyx")
            shutil.copy2(input_file, pyx_file)
            if output_c:
                out_file = os.path.join(work_dir, f"{base_name}.c")
                cython_cmd = ['cython', '--embed', '-3', pyx_file, '-o', out_file]
            else:
                out_file = os.path.join(work_dir, f"{base_name}.cpp")
                cython_cmd = ['cython', '--embed', '-3', '--cplus', pyx_file, '-o', out_file]
            if dry_run:
                print(' '.join(cython_cmd))
                return
            result = subprocess.run(cython_cmd, capture_output=True, text=True)
            if result.returncode != 0:
                print_error("Cython error:")
                print(result.stderr, file=sys.stderr)
                sys.exit(1)
            final_output = output if output else out_file
            shutil.copy2(out_file, final_output)
            if VERBOSE and not QUIET:
                print_info(f"Generated: {final_output}")
        finally:
            if os.path.exists(work_dir) and not dry_run:
                shutil.rmtree(work_dir)
            if should_cleanup and os.path.exists(input_file):
                os.remove(input_file)
        return
    original_input = input_file
    input_file, new_name = fix_module_name(input_file)
    should_cleanup = new_name is not None
    py_version = get_python_version()
    py_include = get_python_include()
    py_lib_path, py_lib_name = get_python_lib()
    work_dir = os.path.expanduser('~/tmp/pycc_build')
    os.makedirs(work_dir, exist_ok=True)
    try:
        base_name = os.path.splitext(os.path.basename(input_file))[0]
        pyx_file = os.path.join(work_dir, f"{base_name}.pyx")
        shutil.copy2(input_file, pyx_file)
        out_file = os.path.join(work_dir, f"{base_name}.c")
        cython_cmd = ['cython', '--embed', '-3', pyx_file, '-o', out_file]
        if dry_run:
            print(' '.join(cython_cmd))
            return
        result = subprocess.run(cython_cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print_error("Cython error:")
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
        if run:
            final_output = os.path.join(work_dir, f"{base_name}.out")
        else:
            final_output = output if output else f"./{base_name}.out"
        compile_cmd = [
            'clang', f'-O{opt_level}', '-o', final_output, out_file,
            f'-I{py_include}', f'-L{py_lib_path}', f'-l{py_lib_name}',
            '-lpthread', '-lm', '-lutil', '-ldl'
        ] + other_flags
        print_cmd(compile_cmd)
        result = subprocess.run(compile_cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print_error("Compilation error:")
            print(result.stderr, file=sys.stderr)
            sys.exit(1)
        os.chmod(final_output, 0o755)
        add_compile_marker(final_output)
        if not run and not QUIET:
            print_info(f"Executable: {final_output}")
        if run:
            subprocess.run([final_output] + script_args)
    finally:
        if os.path.exists(work_dir) and not dry_run:
            shutil.rmtree(work_dir)
        if should_cleanup and os.path.exists(input_file):
            os.remove(input_file)

if __name__ == '__main__':
    main()
