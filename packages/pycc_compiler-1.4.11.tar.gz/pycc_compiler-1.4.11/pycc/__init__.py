from .pycc import main, VERSION

__version__ = VERSION
__all__ = ["main", "VERSION"]
