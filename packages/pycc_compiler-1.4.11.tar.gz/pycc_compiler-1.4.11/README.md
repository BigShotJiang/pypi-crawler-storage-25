# pycc-compiler

Compile Python/Pyrex files to standalone ELF executables/shared libraries using Cython and clang.

## Installation

```bash
pip install pycc-compiler
```
Or from source:

```bash
git clone ...
cd pycc-compiler
pip install .
```

Dependencies

· Python 3.8+
· Cython
· clang (or clang++)

On Termux:

```bash
pkg install clang cython python-dev
```

Usage

Basic Compilation

```bash
pycc main.py              # generates ./main.out
pycc main.py -o prog      # generates ./prog
pycc -run main.py         # compile and run
```

Generate C/C++ Code

```bash
pycc -c main.py -o main.c      # generate C file
pycc -cpp main.py -o main.cpp  # generate C++ file
```

Shared Libraries

```bash
pycc -so main.py -o lib.so           # generate shared library
pycc -s -so main.py                  # install to site-packages
```

C/C++ Files
```bash
pycc --clang main.c -o prog          # compile C file
pycc --clang main.cpp -o prog        # compile C++ file
```

Interactive Mode

```bash
pycc -i
P>> import numpy as np
P>> x = np.array([1,2,3])
P>> print(x)
P>> RUN
```

Options
Option Description
-O0, -O1, -O2, -O3 Optimization level
-o, --output Output file name
-run Compile and run
-c Generate C file
-cpp Generate C++ file
-so Generate shared library
--site, -s Install to site-packages
-i, --interactive Interactive mode
-v Verbose mode
-q Quiet mode
--clang, -clg Forward to clang/clang++

Environment Variables

· PYCC_PY_VERSION - Specify Python version (auto-detected)

Features

MIT
