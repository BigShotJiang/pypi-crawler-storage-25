import argparse
import logging
import sys
import os
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

from .providers.openrouter import OpenRouterProvider
from .providers.codex_direct import CodexDirectProvider
from .providers.codexbar import CodexBarProvider
from .stores.google_sheets import GoogleSheetsStore

def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Collect token usage and push to Google Sheets")
    parser.add_argument("-i", "--init", action="store_true",
                        help="Overwrite the sheets (uses df_to_sheet). Default: append.")
    parser.add_argument("--log-level", default="INFO",
                        help="Logging level (DEBUG, INFO, WARNING, ERROR)")
    parser.add_argument("--codex", action="store_true", help="Only run direct Codex API fetch")
    parser.add_argument("--codex-bar", action="store_true", help="Only run codexbar fetch")
    parser.add_argument("--openrouter", action="store_true", help="Only run OpenRouter fetch")
    return parser.parse_args(argv)

def main(argv=None) -> None:
    args = parse_args(argv)

    numeric_level = getattr(logging, args.log_level.upper(), logging.INFO)
    logging.basicConfig(level=numeric_level, format="%(asctime)s %(levelname)s: %(message)s")

    now_stamp = datetime.now(ZoneInfo("America/New_York")).strftime("%Y-%m-%d %H:%M:%S")
    had_error = False

    run_all = not (args.codex or args.codex_bar or args.openrouter)
    run_codex = run_all or args.codex
    run_codex_bar = run_all or args.codex_bar
    run_openrouter = run_all or args.openrouter

    try:
        store = GoogleSheetsStore()
    except Exception:
        logging.exception("Failed to initialize GoogleSheetsStore")
        sys.exit(1)

    if run_codex:
        try:
            provider = CodexDirectProvider()
            df = provider.fetch(now=now_stamp)
            store.save(df, name="codex", init=args.init)
        except Exception:
            logging.exception("Failed to process direct Codex data")
            had_error = True

    if run_codex_bar:
        try:
            provider = CodexBarProvider()
            df = provider.fetch(now=now_stamp)
            store.save(df, name="codexbar", init=args.init)
        except Exception:
            logging.exception("Failed to process codexbar data")
            had_error = True

    if run_openrouter:
        try:
            provider = OpenRouterProvider()
            df = provider.fetch(now=now_stamp)
            store.save(df, name="openrouter", init=args.init)
        except Exception:
            logging.exception("Failed to process OpenRouter data")
            had_error = True

    if had_error:
        logging.error("Completed with errors")
        sys.exit(1)

    logging.info("All sources written successfully")

if __name__ == "__main__":
    main()
