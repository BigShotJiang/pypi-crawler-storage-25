import requests
import pandas as pd
from typing import Optional
from .base import BaseProvider
from project_toolkit import settings

OPENROUTER_KEYS = [
    "limit", "limit_reset", "limit_remaining", "include_byok_in_limit",
    "usage", "usage_daily", "usage_weekly", "usage_monthly",
    "byok_usage", "byok_usage_daily", "byok_usage_weekly", "byok_usage_monthly",
    "is_free_tier", "expires_at"
]

class OpenRouterProvider(BaseProvider):
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or settings.env("OPENROUTER_API_KEY")

    def fetch(self, now: str) -> pd.DataFrame:
        if not self.api_key:
            raise ValueError("OPENROUTER_API_KEY not found")

        response = requests.get(
            "https://openrouter.ai/api/v1/key",
            headers={"Authorization": f"Bearer {self.api_key}"},
        )
        response.raise_for_status()
        data = response.json().get("data", {})

        row = {"time": now}
        row.update({k: data.get(k) for k in OPENROUTER_KEYS})

        df = pd.DataFrame([row])
        df.attrs["raw_json"] = data
        return df
