from abc import ABC, abstractmethod
import pandas as pd
from typing import Optional

class BaseProvider(ABC):
    @abstractmethod
    def fetch(self, now: str) -> pd.DataFrame:
        """Fetch usage data and return as a DataFrame."""
        pass
