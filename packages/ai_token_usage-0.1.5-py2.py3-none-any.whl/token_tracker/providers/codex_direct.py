import requests
import pandas as pd
import json
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Optional
from .base import BaseProvider
from project_toolkit import settings

CODEX_DIRECT_COLS = [
    "time", "email", "plan_type",
    "rate_limit.p.used_percent", "rate_limit.p.limit_window_seconds",
    "rate_limit.p.reset_after_seconds", "rate_limit.p.reset_at",
    "rate_limit.s.used_percent", "rate_limit.s.limit_window_seconds",
    "rate_limit.s.reset_after_seconds", "rate_limit.s.reset_at",
    "credits.has_credits", "credits.unlimited",
    "credits.overage_limit_reached", "credits.balance",
    "spend_control.reached", "spend_control.individual_limit"
]

class CodexDirectProvider(BaseProvider):
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or settings.env("CODEX_API_KEY")
        if not self.api_key:
            auth_file = Path.home() / ".config" / "codex" / "auth.json"
            if auth_file.exists():
                try:
                    with auth_file.open("r") as f:
                        auth_data = json.load(f)
                        self.api_key = auth_data.get("token") or auth_data.get("CODEX_API_KEY")
                except Exception:
                    pass

    def fetch(self, now: str) -> pd.DataFrame:
        if not self.api_key:
            raise ValueError("CODEX_API_KEY not found in environment or auth file")

        response = requests.get(
            "https://chatgpt.com/backend-api/wham/usage",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Accept": "application/json"
            }
        )
        response.raise_for_status()
        data = response.json()

        def convert_ts(ts):
            if not ts:
                return None
            return datetime.fromtimestamp(ts, tz=ZoneInfo("America/New_York")).isoformat()

        rate_limit = data.get("rate_limit", {}) or {}
        primary = rate_limit.get("primary_window", {}) or {}
        secondary = rate_limit.get("secondary_window", {}) or {}
        credits_data = data.get("credits", {}) or {}
        spend_control = data.get("spend_control", {}) or {}

        row = {
            "time": now,
            "email": data.get("email"),
            "plan_type": data.get("plan_type"),
            "rate_limit.p.used_percent": primary.get("used_percent"),
            "rate_limit.p.limit_window_seconds": primary.get("limit_window_seconds"),
            "rate_limit.p.reset_after_seconds": primary.get("reset_after_seconds"),
            "rate_limit.p.reset_at": convert_ts(primary.get("reset_at")),
            "rate_limit.s.used_percent": secondary.get("used_percent"),
            "rate_limit.s.limit_window_seconds": secondary.get("limit_window_seconds"),
            "rate_limit.s.reset_after_seconds": secondary.get("reset_after_seconds"),
            "rate_limit.s.reset_at": convert_ts(secondary.get("reset_at")),
            "credits.has_credits": credits_data.get("has_credits"),
            "credits.unlimited": credits_data.get("unlimited"),
            "credits.overage_limit_reached": credits_data.get("overage_limit_reached"),
            "credits.balance": credits_data.get("balance"),
            "spend_control.reached": spend_control.get("reached"),
            "spend_control.individual_limit": spend_control.get("individual_limit")
        }

        df = pd.DataFrame([row], columns=CODEX_DIRECT_COLS)
        df.attrs["raw_json"] = data
        return df
