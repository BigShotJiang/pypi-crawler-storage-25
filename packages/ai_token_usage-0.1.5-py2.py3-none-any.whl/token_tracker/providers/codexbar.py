import subprocess
import shlex
import json
import re
import pandas as pd
from typing import Optional
from .base import BaseProvider

COL_TIME = "time"
COL_CODEX_USAGE = "Codex Usage"
COL_CODEX_RESETS = "Codex Resets"
COL_CODEX_5HR_USAGE = "Codex 5hr Usage"
COL_CODEX_5HR_RESET = "Codex 5hr Reset"
COL_CODEX_WEEKLY_USAGE = "Codex Weekly Usage"
COL_CODEX_WEEKLY_RESET = "Codex Weekly Reset"
COL_CODEX_CREDITS = "Codex Credits"
COL_CODEX_PLAN = "Codex Plan"
COL_COPILOT_PREMIUM = "Copilot Premium"
COL_COPILOT_CHAT = "Copilot Chat"
COL_COPILOT_PLAN = "Copilot Plan"
COL_GEMINI_PRO = "Gemini Pro"
COL_GEMINI_PRO_RESETS = "Gemini Pro Resets"
COL_GEMINI_FLASH = "Gemini Flash"
COL_GEMINI_FLASH_RESET = "Gemini Flash Reset"
COL_GEMINI_FLASH_LITE = "Gemini Flash Lite"
COL_GEMINI_FLASHLITE_RESET = "Gemini Flashlite Reset"
COL_ANTIGRAVITY_CLAUDE = "Antigravity Claude"
COL_ANTIGRAVITY_CLAUDE_RESET = "Antigravity Claude Reset"
COL_ANTIGRAVITY_GEMINI_PRO = "Antigravity Gemini Pro"
COL_ANTIGRAVITY_GEMINI_PRO_RESET = "Antigravity Gemini Pro Reset"
COL_ANTIGRAVITY_FLASHLITE = "Antigravity Flashlite"
COL_ANTIGRAVITY_FLASHLITE_RESETS = "Antigravity Flashlite Resets"
COL_ANTIGRAVITY_PLAN = "Antigravity Plan"

CODEXBAR_COLS = [
    COL_TIME, COL_CODEX_USAGE, COL_CODEX_RESETS, COL_CODEX_5HR_USAGE, COL_CODEX_5HR_RESET,
    COL_CODEX_WEEKLY_USAGE, COL_CODEX_WEEKLY_RESET, COL_CODEX_CREDITS, COL_CODEX_PLAN,
    COL_COPILOT_PREMIUM, COL_COPILOT_CHAT, COL_COPILOT_PLAN, COL_GEMINI_PRO, COL_GEMINI_PRO_RESETS,
    COL_GEMINI_FLASH, COL_GEMINI_FLASH_RESET, COL_GEMINI_FLASH_LITE, COL_GEMINI_FLASHLITE_RESET,
    COL_ANTIGRAVITY_CLAUDE, COL_ANTIGRAVITY_CLAUDE_RESET, COL_ANTIGRAVITY_GEMINI_PRO,
    COL_ANTIGRAVITY_GEMINI_PRO_RESET, COL_ANTIGRAVITY_FLASHLITE, COL_ANTIGRAVITY_FLASHLITE_RESETS,
    COL_ANTIGRAVITY_PLAN,
]

PROVIDER_MAP = {
    "codex": {
        "primary": (COL_CODEX_5HR_USAGE, COL_CODEX_5HR_RESET),
        "secondary": (COL_CODEX_WEEKLY_USAGE, COL_CODEX_WEEKLY_RESET)
    },
    "copilot": {
        "primary": (COL_COPILOT_PREMIUM, None),
        "secondary": (COL_COPILOT_CHAT, None)
    },
    "gemini": {
        "primary": (COL_GEMINI_PRO, COL_GEMINI_PRO_RESETS),
        "secondary": (COL_GEMINI_FLASH_LITE, COL_GEMINI_FLASHLITE_RESET),
        "tertiary": (COL_GEMINI_FLASH, COL_GEMINI_FLASH_RESET)
    },
    "antigravity": {
        "primary": (COL_ANTIGRAVITY_CLAUDE, COL_ANTIGRAVITY_CLAUDE_RESET),
        "secondary": (COL_ANTIGRAVITY_GEMINI_PRO, COL_ANTIGRAVITY_GEMINI_PRO_RESET),
        "tertiary": (COL_ANTIGRAVITY_FLASHLITE, COL_ANTIGRAVITY_FLASHLITE_RESETS)
    },
}

class CodexBarProvider(BaseProvider):
    def __init__(self, command: str = "codexbar usage --json"):
        self.command = command

    def fetch(self, now: str) -> pd.DataFrame:
        try:
            proc = subprocess.run(shlex.split(self.command), capture_output=True, text=True, check=True)
            out_text = proc.stdout
        except Exception:
            proc = subprocess.run(self.command, capture_output=True, text=True, shell=True)
            if proc.returncode != 0:
                raise RuntimeError(f"Command failed: {proc.stderr or proc.stdout}")
            out_text = proc.stdout

        m = re.search(r"(\[|\{)", out_text)
        if not m:
            raise ValueError("No JSON found in command output")
        data = json.loads(out_text[m.start():].strip())
        items = data if isinstance(data, list) else [data]

        out = {c: None for c in CODEXBAR_COLS}
        out[COL_TIME] = now

        for item in items:
            prov = (item.get("provider") or item.get("source") or "").lower()
            usage = item.get("usage") or {}

            plan = usage.get("loginMethod") or (usage.get("identity") or {}).get("loginMethod")
            if ("antigravity" in prov or "local" in prov) and plan and out.get(COL_ANTIGRAVITY_PLAN) is None:
                out[COL_ANTIGRAVITY_PLAN] = plan

            if "codex" in prov:
                out[COL_CODEX_CREDITS] = (item.get("credits") or {}).get("remaining")
                if plan and out.get(COL_CODEX_PLAN) is None:
                    out[COL_CODEX_PLAN] = plan

            for key, mapping in PROVIDER_MAP.items():
                if key in prov:
                    for slot, (val_col, reset_col) in mapping.items():
                        slot_data = usage.get(slot) or {}
                        val = slot_data.get("usedPercent")
                        rst = slot_data.get("resetDescription") or slot_data.get("resetsAt")
                        
                        if val_col and out.get(val_col) is None:
                            out[val_col] = val
                        if reset_col and out.get(reset_col) is None:
                            out[reset_col] = rst

        out[COL_CODEX_USAGE] = out.get(COL_CODEX_5HR_USAGE) if out.get(COL_CODEX_5HR_USAGE) is not None else out.get(COL_CODEX_WEEKLY_USAGE)
        out[COL_CODEX_RESETS] = out.get(COL_CODEX_5HR_RESET) if out.get(COL_CODEX_5HR_RESET) is not None else out.get(COL_CODEX_WEEKLY_RESET)

        df = pd.DataFrame([[out[c] for c in CODEXBAR_COLS]], columns=CODEXBAR_COLS)
        df.attrs["raw_json"] = data
        return df
