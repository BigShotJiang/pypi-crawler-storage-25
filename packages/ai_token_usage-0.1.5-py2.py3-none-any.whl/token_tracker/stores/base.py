from abc import ABC, abstractmethod
import pandas as pd

class BaseStore(ABC):
    @abstractmethod
    def save(self, df: pd.DataFrame, name: str, init: bool = False) -> None:
        """Save the DataFrame to the store."""
        pass
