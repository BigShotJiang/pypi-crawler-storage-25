"""Stores for Token Tracker."""
