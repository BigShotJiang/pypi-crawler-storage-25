import logging
import json
import hashlib
from pathlib import Path
import pandas as pd
from .base import BaseStore
from project_toolkit import settings

class GoogleSheetsStore(BaseStore):
    def __init__(self, sheet_id: str = None):
        self.sheet_id = sheet_id or settings.env("TOKEN_USAGE_SHEET_ID")
        if not self.sheet_id:
            raise RuntimeError("Environment variable TOKEN_USAGE_SHEET_ID is not set")
        
        from project_toolkit.google.sheet import GoogleSheetsManager
        self.manager = GoogleSheetsManager()

    def _last_fetch_file(self, name: str) -> Path:
        return Path.cwd() / f"{name}_last_fetch.json"

    def _load_hash_data(self, name: str) -> dict:
        p = self._last_fetch_file(name)
        if not p.exists():
            return {}
        try:
            with p.open("r", encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            logging.exception("Failed to load %s", p)
            return {}

    def _write_hash_data(self, name: str, data: dict) -> None:
        p = self._last_fetch_file(name)
        tmp = p.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, sort_keys=True, ensure_ascii=False, default=str)
        tmp.replace(p)

    def _snapshot_hash(self, df: pd.DataFrame) -> str:
        df2 = df.copy()
        if "time" in getattr(df2, "columns", []):
            df2 = df2.drop(columns=["time"], errors=True)

        records = df2.where(pd.notnull(df2), None).to_dict(orient="records")
        s = json.dumps(records, sort_keys=True, default=str, separators=(',', ':'))
        return hashlib.sha256(s.encode("utf-8")).hexdigest()

    def save(self, df: pd.DataFrame, name: str, init: bool = False) -> None:
        if df is None or getattr(df, "empty", False):
            logging.warning("Provided DataFrame is empty; not writing to sheet %s", name)
            return

        raw = getattr(df, "attrs", {}).get("raw_json")
        if raw is None:
            try:
                raw = df.where(pd.notnull(df), None).to_dict(orient="records")
            except Exception:
                raw = df.to_dict(orient="records") if hasattr(df, "to_dict") else (df if isinstance(df, (list, dict)) else None)

        try:
            curr_hash = self._snapshot_hash(df)
        except Exception:
            logging.exception("Failed to compute snapshot hash for %s", name)
            curr_hash = None
            if raw is not None:
                try:
                    if isinstance(raw, list) and all(isinstance(r, dict) for r in raw):
                        raw_no_time = [{k: v for k, v in r.items() if k != "time"} for r in raw]
                    elif isinstance(raw, dict):
                        raw_no_time = {k: v for k, v in raw.items() if k != "time"}
                    else:
                        raw_no_time = raw
                    s = json.dumps(raw_no_time, sort_keys=True, default=str, separators=(',', ':'))
                    curr_hash = hashlib.sha256(s.encode('utf-8')).hexdigest()
                except Exception:
                    logging.exception("Failed to compute fallback hash from raw for %s", name)

        stored_data = self._load_hash_data(name)
        stored_hash = stored_data.get("hash")

        if not init and curr_hash is not None and stored_hash == curr_hash:
            logging.info("No change detected for %s — skipping write", name)
        else:
            try:
                if init:
                    logging.info("Initializing sheet '%s' (sheet_id=%s)", name, self.sheet_id)
                    self.manager.df_to_sheet(df, sheet_id=self.sheet_id, sheet_name=name)
                else:
                    logging.info("Appending to sheet '%s' (sheet_id=%s)", name, self.sheet_id)
                    self.manager.append_to_sheet(df, sheet_id=self.sheet_id, sheet_name=name)
            except Exception:
                logging.exception("Failed to write DataFrame to Google Sheets")
                raise

        try:
            self._write_hash_data(name, {"hash": curr_hash, "raw": raw})
        except Exception:
            logging.exception("Failed to update %s_last_fetch.json", name)
