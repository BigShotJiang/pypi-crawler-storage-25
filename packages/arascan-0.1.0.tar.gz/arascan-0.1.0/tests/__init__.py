"""ARA test suite."""
