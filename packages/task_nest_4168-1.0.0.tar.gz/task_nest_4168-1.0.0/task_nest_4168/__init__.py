"""Calc Rack — Breeze Collection"""
__version__ = "1.0.0"
