def main() -> None:
    print("Hello from wesh!")
