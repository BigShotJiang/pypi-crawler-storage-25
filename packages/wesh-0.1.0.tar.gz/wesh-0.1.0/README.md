This will be a fork of Whoosh.
