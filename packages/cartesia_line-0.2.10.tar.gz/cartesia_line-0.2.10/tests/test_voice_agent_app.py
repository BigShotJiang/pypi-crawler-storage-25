"""
Tests for line/voice_agent_app.py

Focuses on:
1. ConversationRunner webhook loop behavior
2. _cancel_agent_task behavior
3. History management
4. _get_processed_history whitespace restoration
"""

import asyncio
from datetime import datetime
from typing import AsyncIterator, List
from unittest.mock import AsyncMock, MagicMock

from fastapi import WebSocket, WebSocketDisconnect
import pytest

from line._harness_types import EndCallOutput, MessageOutput, TransferOutput
from line.agent import TurnEnv
from line.events import (
    AgentEndCall,
    AgentSendText,
    AgentTextSent,
    AgentToolCalled,
    AgentToolReturned,
    AgentTransferCall,
    AgentUpdateCall,
    CallEnded,
    CallStarted,
    InputEvent,
    LogMessage,
    OutputEvent,
    UserTextSent,
    UserTurnEnded,
    UserTurnStarted,
)
from line.voice_agent_app import (
    AgentEnv,
    ConversationRunner,
    _call_request_from_start_data,
    _consume_expected_ack_back_prefix,
    _get_processed_history,
    _parse_committed,
)

# ============================================================
# Fixtures and Helpers
# ============================================================

env = AgentEnv()


def create_mock_websocket() -> MagicMock:
    """Create a mock WebSocket with async methods."""
    ws = MagicMock(spec=WebSocket)
    ws.receive_json = AsyncMock()
    ws.send_json = AsyncMock()
    return ws


async def noop_agent(env: TurnEnv, event: InputEvent) -> AsyncIterator[OutputEvent]:
    """Agent that yields nothing."""
    return
    yield  # Make this a generator


class TestConversationRunner:
    # ============================================================
    # WS disconnect
    # ============================================================
    @pytest.mark.asyncio
    async def test_disconnect_creates_call_ended_event(self):
        """Verify CallEnded is added to history on disconnect."""
        ws = create_mock_websocket()
        ws.receive_json.side_effect = [WebSocketDisconnect()]

        runner = ConversationRunner(ws, noop_agent, env)
        await runner.run()

        # History should have CallStarted and CallEnded
        assert len(runner.history) == 2
        assert isinstance(runner.history[0], CallStarted)
        assert isinstance(runner.history[1], CallEnded)

    @pytest.mark.asyncio
    async def test_disconnect_sets_shutdown_event(self):
        """Verify shutdown_event is set on disconnect."""
        ws = create_mock_websocket()
        ws.receive_json.side_effect = WebSocketDisconnect()

        runner = ConversationRunner(ws, noop_agent, env)
        assert not runner.shutdown_event.is_set()

        await runner.run()

        assert runner.shutdown_event.is_set()

    # ============================================================
    # Fatal error handling
    # ============================================================
    @pytest.mark.asyncio
    async def test_fatal_error_closes_websocket(self):
        """Verify websocket is closed when a fatal exception occurs during message processing."""
        ws = create_mock_websocket()
        ws.close = AsyncMock()

        # First call raises a generic exception, simulating a fatal error
        ws.receive_json.side_effect = RuntimeError("Simulated fatal error")

        runner = ConversationRunner(ws, noop_agent, env)
        await runner.run()

        # Verify shutdown_event is set
        assert runner.shutdown_event.is_set()

        # Verify error was sent with full traceback
        ws.send_json.assert_called()
        sent_data = ws.send_json.call_args[0][0]
        assert "error" in sent_data.get("type", "") or "content" in sent_data
        # Error message should contain both the exception and traceback info
        assert "Simulated fatal error" in str(sent_data)
        assert "RuntimeError" in str(sent_data)

        # Verify websocket was closed
        ws.close.assert_called_once()

    @pytest.mark.asyncio
    async def test_fatal_error_stops_loop(self):
        """Verify the run loop exits after a fatal error."""
        ws = create_mock_websocket()
        ws.close = AsyncMock()
        call_count = 0

        async def receive_with_error():
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return {"type": "message", "content": "hello"}
            # Second call raises a fatal error
            raise ValueError("Something went wrong")

        ws.receive_json = receive_with_error

        runner = ConversationRunner(ws, noop_agent, env)
        await runner.run()

        # Loop should have exited after the error
        assert call_count == 2
        assert runner.shutdown_event.is_set()
        ws.close.assert_called_once()

        # Verify error message contains full traceback
        ws.send_json.assert_called()
        sent_data = ws.send_json.call_args[0][0]
        assert "Something went wrong" in str(sent_data)
        assert "ValueError" in str(sent_data)

    @pytest.mark.asyncio
    async def test_disconnect_stops_loop(self):
        """Verify the run loop exits after disconnect."""
        ws = create_mock_websocket()
        call_count = 0

        async def receive_with_count():
            nonlocal call_count
            call_count += 1
            if call_count >= 2:
                raise WebSocketDisconnect()
            return {"type": "message", "content": "hello"}

        ws.receive_json = receive_with_count

        runner = ConversationRunner(ws, noop_agent, env)
        await runner.run()

        # Loop should have exited - verify we didn't spin forever
        assert call_count == 2

    # ============================================================
    # cancelling agents
    # ============================================================

    @pytest.mark.asyncio
    async def test_cancel_triggered_by_user_turn_started(self):
        """Verify agent task is cancelled when UserTurnStarted arrives."""
        ws = create_mock_websocket()
        agent_started = asyncio.Event()
        agent_cancelled = asyncio.Event()
        proceed_to_yield = asyncio.Future()

        async def blocking_agent(env, event):
            agent_started.set()
            try:
                await proceed_to_yield  # Block until cancelled or released
                yield AgentSendText(text="should not reach")
            except asyncio.CancelledError:
                agent_cancelled.set()
                raise

        msg_idx = 0

        async def receive_messages():
            nonlocal msg_idx
            if msg_idx == 0:
                await agent_started.wait()
                msg_idx += 1
                return {"type": "user_state", "value": "speaking"}  # Triggers cancel
            raise WebSocketDisconnect()

        ws.receive_json = receive_messages

        runner = ConversationRunner(ws, blocking_agent, env)
        await runner.run()

        assert agent_cancelled.is_set(), "Agent task should have been cancelled"

    @pytest.mark.asyncio
    async def test_cancel_when_no_task_running(self):
        """Verify no error when cancel filter triggers but no task exists."""
        ws = create_mock_websocket()

        def never_run(e):
            return False

        def default_cancel(e):
            return isinstance(e, UserTurnStarted)

        ws.receive_json.side_effect = [
            {"type": "user_state", "value": "speaking"},  # Would trigger cancel
            WebSocketDisconnect(),
        ]

        runner = ConversationRunner(ws, (noop_agent, never_run, default_cancel), env)

        # Should not raise
        await runner.run()
        assert runner.agent_task is None

    @pytest.mark.asyncio
    async def test_cancel_already_completed_task(self):
        """Verify no error when cancel triggers after task naturally completed."""
        ws = create_mock_websocket()
        agent_completed = asyncio.Event()

        async def quick_agent(env, event):
            yield AgentSendText(text="quick response")
            agent_completed.set()

        call_count = 0

        async def receive_messages():
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                await agent_completed.wait()
                return {"type": "user_state", "value": "speaking"}  # Triggers cancel
            raise WebSocketDisconnect()

        ws.receive_json = receive_messages

        runner = ConversationRunner(ws, quick_agent, env)

        # Should not raise
        await runner.run()

    @pytest.mark.asyncio
    async def test_disconnect_awaits_running_agent_task(self):
        """Disconnect should await/cancel any running agent task.

        EXPECTED: When WebSocketDisconnect occurs, any running agent task
        should be awaited before run() returns.

        BUG: Currently, the task may be left dangling.
        """
        ws = create_mock_websocket()
        agent_started = asyncio.Event()
        agent_finished = asyncio.Event()
        agent_blocking = asyncio.Future()

        async def blocking_agent(env, event):
            agent_started.set()
            await agent_blocking  # Block until cancelled
            yield AgentSendText(text="response")
            agent_finished.set()

        async def receive_messages():
            await agent_started.wait()
            print("Disconnecting")
            raise WebSocketDisconnect()

        ws.receive_json = receive_messages

        runner = ConversationRunner(ws, blocking_agent, env)
        runner_task = runner.run()
        agent_blocking.set_result(None)
        await runner_task

        assert agent_finished.is_set(), (
            "Agent task should be awaited/cancelled on disconnect so it can clean up"
        )

    """Tests for history accumulation and processing."""
    # ============================================================
    # History management
    # ============================================================

    @pytest.mark.asyncio
    async def test_history_accumulates_events(self):
        """Verify events are appended to history in order."""
        ws = create_mock_websocket()
        call_count = 0

        async def receive_messages():
            nonlocal call_count
            call_count += 1
            messages = [
                {"type": "user_state", "value": "speaking"},
                {"type": "message", "content": "hello"},
                {"type": "user_state", "value": "idle"},
            ]
            if call_count <= len(messages):
                return messages[call_count - 1]
            raise WebSocketDisconnect()

        ws.receive_json = receive_messages

        runner = ConversationRunner(ws, noop_agent, env)
        await runner.run()

        # Should have: CallStarted, UserTurnStarted, UserTextSent, UserTurnEnded, CallEnded
        assert len(runner.history) == 5
        assert isinstance(runner.history[0], CallStarted)
        assert isinstance(runner.history[1], UserTurnStarted)
        assert isinstance(runner.history[2], UserTextSent)
        assert runner.history[2].content == "hello"
        assert isinstance(runner.history[3], UserTurnEnded)
        assert isinstance(runner.history[4], CallEnded)

    @pytest.mark.asyncio
    async def test_unknown_message_type_is_dropped(self):
        """Messages with an unrecognized 'type' are logged and skipped, not fatal."""
        ws = create_mock_websocket()
        call_count = 0

        async def receive_messages():
            nonlocal call_count
            call_count += 1
            messages = [
                {"type": "totally_unknown", "foo": "bar"},
                {"type": "message", "content": "hello"},
                {"type": "user_state", "value": "idle"},
            ]
            if call_count <= len(messages):
                return messages[call_count - 1]
            raise WebSocketDisconnect()

        ws.receive_json = receive_messages

        runner = ConversationRunner(ws, noop_agent, env)
        await runner.run()

        # The unknown message should have been dropped; the rest processed normally.
        # History: CallStarted, UserTextSent, UserTurnEnded, CallEnded
        assert any(isinstance(ev, UserTextSent) for ev in runner.history)
        assert not runner.shutdown_event.is_set() or isinstance(runner.history[-1], CallEnded)

    @pytest.mark.asyncio
    async def test_extra_fields_are_ignored(self):
        """Messages with extra unknown fields should parse successfully."""
        ws = create_mock_websocket()
        call_count = 0

        async def receive_messages():
            nonlocal call_count
            call_count += 1
            messages = [
                {"type": "message", "content": "hello", "extra_field": 123, "nested": {"a": 1}},
                {"type": "user_state", "value": "idle"},
            ]
            if call_count <= len(messages):
                return messages[call_count - 1]
            raise WebSocketDisconnect()

        ws.receive_json = receive_messages

        runner = ConversationRunner(ws, noop_agent, env)
        await runner.run()

        # Should have processed both messages without error.
        assert any(isinstance(ev, UserTextSent) and ev.content == "hello" for ev in runner.history)

    def test_turn_content_collects_events_since_turn_started(self):
        """Verify _turn_content collects the right events."""
        ws = create_mock_websocket()
        runner = ConversationRunner(ws, noop_agent, env)

        # Pass history as argument to the pure function
        history = [
            CallStarted(),
            UserTurnStarted(),
            UserTextSent(content="first"),
            UserTextSent(content="second"),
        ]

        content = runner._turn_content(
            history,
            UserTurnStarted,
            (UserTextSent,),
        )

        assert len(content) == 2
        assert content[0].content == "first"
        assert content[1].content == "second"

    def test_turn_content_empty_when_no_start_event(self):
        """Verify _turn_content returns empty list when no start event found."""
        ws = create_mock_websocket()
        runner = ConversationRunner(ws, noop_agent, env)

        history = [
            CallStarted(),
            UserTextSent(content="orphan"),
        ]

        content = runner._turn_content(
            history,
            UserTurnStarted,
            (UserTextSent,),
        )

        assert content == []

    def test_process_input_event_updates_history(self):
        """Verify _process_input_event returns updated history."""
        ws = create_mock_websocket()
        runner = ConversationRunner(ws, noop_agent, env)

        initial_history: List[InputEvent] = []
        event = CallStarted()

        result_event, new_history = runner._process_input_event(initial_history, event)

        assert len(new_history) == 1
        assert new_history[0] is event
        assert isinstance(result_event, CallStarted)

    def test_process_input_event_preserves_existing_events(self):
        """Verify existing history is preserved when adding new events."""
        ws = create_mock_websocket()
        runner = ConversationRunner(ws, noop_agent, env)

        existing = [CallStarted(), UserTurnStarted()]
        new_event = UserTextSent(content="test")

        _, new_history = runner._process_input_event(existing, new_event)

        assert len(new_history) == 3
        assert new_history[0] is existing[0]
        assert new_history[1] is existing[1]
        assert new_history[2] is new_event


# ============================================================
# 2) _get_processed_history tests
# ============================================================


class TestGetProcessedHistory:
    """Tests for whitespace restoration in history."""

    def test_empty_history(self):
        result = _get_processed_history([("x", True)], [])
        assert result == []

    def test_no_agent_text_events(self):
        history = [CallStarted(), UserTextSent(content="x")]
        result = _get_processed_history([], history)
        assert result == history

    def test_restores_whitespace(self):
        result = _get_processed_history([("a b", True)], [AgentTextSent(content="ab")])
        assert len(result) == 1
        assert result[0].content == "a b"

    def test_partial_commit(self):
        result = _get_processed_history([("a b c", True)], [AgentTextSent(content="ab")])
        assert len(result) == 1
        assert result[0].content == "a b"

    def test_multiple_agent_text_events(self):
        history = [
            AgentTextSent(content="ab"),
            AgentTextSent(content="cd"),
        ]
        result = _get_processed_history([("a b c d", True)], history)
        assert len(result) == 1
        assert result[0].content == "a b c d"

    def test_no_spaces_passthrough(self):
        result = _get_processed_history([("ab", True)], [AgentTextSent(content="ab")])
        assert len(result) == 1
        assert result[0].content == "ab"

    def test_mixed_events_preserved(self):
        history = [
            CallStarted(),
            AgentTextSent(content="ab"),
            UserTurnStarted(),
        ]
        result = _get_processed_history([("a b", True)], history)
        assert len(result) == 3
        assert isinstance(result[0], CallStarted)
        assert result[1].content == "a b"
        assert isinstance(result[2], UserTurnStarted)


# ============================================================
# _parse_committed tests (helper function)
# ============================================================


class TestParseCommitted:
    """Tests for the _parse_committed helper function."""

    def test_exact_match(self):
        """When speech exactly matches pending (minus whitespace)."""
        committed, _, remaining = _parse_committed("abc", "a b c")
        assert committed == "a b c"
        assert remaining == ""

    def test_partial_match(self):
        """When speech matches only the beginning of pending."""
        committed, _, remaining = _parse_committed("abc", "a b c d")
        assert committed == "a b c"
        assert remaining == " d"

    def test_empty_pending(self):
        """Empty pending text returns speech text for non-latin handling."""
        committed, _, remaining = _parse_committed("abc", "abc")
        assert committed == "abc"
        assert remaining == ""

    def test_preserves_punctuation(self):
        """Punctuation is preserved during matching."""
        committed, _, remaining = _parse_committed("a!", "a!")
        assert committed == "a!"
        assert remaining == ""

    def test_non_space_commit_preserves_remaining(self):
        """Partial commit of non-latin text should preserve remaining."""
        # Pending has two "sentences", only first is committed
        speech = "a"
        pending = "ab"

        committed, _, remaining = _parse_committed(speech, pending)

        assert committed == "a"
        assert remaining == "b", (
            f"Expected remaining to be 'b', got '{remaining}'. "
            "Non-latin partial commit should preserve remaining text."
        )

    def test_non_space_commit_preserves_skips_as_necessary(self):
        """Partial commit of non-latin text should preserve remaining."""
        # Pending has two "sentences", only first is committed
        speech = "b"
        pending = "abc"

        committed, _, remaining = _parse_committed(speech, pending)

        assert committed == "b"
        assert remaining == "c", (
            f"Expected remaining to be 'c', got '{remaining}'. "
            "Non-latin partial commit should preserve remaining text."
        )

    def test_emojis_spliced_back_like_whitespace(self):
        """Emojis stripped by API harness are restored like whitespace."""
        # API harness strips emojis from AgentTextSent, just like whitespace
        committed, _, remaining = _parse_committed("Hello world", "Hello 👋 world")
        assert committed == "Hello 👋 world"
        assert remaining == ""

    def test_tts_inserted_full_stop_is_skipped(self):
        """TTS-inserted full stop absent from pending is ignored."""
        # TTS adds a period after "Hello" that wasn't in the original text
        committed, remaining_committed, remaining = _parse_committed("Hello.World", "Hello World")
        assert committed == "Hello World"
        assert remaining_committed == ""
        assert remaining == ""

    def test_tts_inserted_devanagari_danda_is_skipped(self):
        """TTS-inserted Devanagari danda (।) absent from pending is ignored."""
        committed, remaining_committed, remaining = _parse_committed("नमस्ते।दुनिया", "नमस्ते दुनिया")
        assert committed == "नमस्ते दुनिया"
        assert remaining_committed == ""
        assert remaining == ""

    def test_tts_inserted_cjk_full_stop_is_skipped(self):
        """TTS-inserted ideographic full stop (。) absent from pending is ignored."""
        committed, remaining_committed, remaining = _parse_committed("你好。世界", "你好世界")
        assert committed == "你好世界"
        assert remaining_committed == ""
        assert remaining == ""

    def test_full_stop_present_in_both_is_preserved(self):
        """A full stop that exists in both committed and pending is kept."""
        committed, remaining_committed, remaining = _parse_committed("Hello.World", "Hello. World")
        assert committed == "Hello. World"
        assert remaining_committed == ""
        assert remaining == ""

    def test_trailing_tts_full_stop_is_skipped(self):
        """A TTS-inserted full stop at the end of committed is cleaned up."""
        committed, remaining_committed, remaining = _parse_committed("Hello.", "Hello World")
        assert committed == "Hello"
        assert remaining_committed == ""
        assert remaining == " World"

    def test_empty_pending_with_committed_returns_committed(self):
        """When pending_text is empty but committed has content, return committed as-is."""
        committed, remaining_committed, remaining = _parse_committed("Hello world", "")
        assert committed == "Hello world"
        assert remaining_committed == ""
        assert remaining == ""


# ============================================================
# Uninterruptible message tests
# ============================================================


class TestUninterruptibleMessages:
    """Tests for AgentSendText(interruptible=False) handling."""

    @pytest.mark.asyncio
    async def test_uninterruptible_maps_to_message_output_with_interruptible_false(self):
        """AgentSendText(interruptible=False) maps to MessageOutput(interruptible=False)."""
        ws = create_mock_websocket()
        runner = ConversationRunner(ws, noop_agent, env)

        result = runner._map_output_event(AgentSendText(text="This call is recorded.", interruptible=False))
        assert isinstance(result, MessageOutput)
        assert result.content == "This call is recorded."
        assert result.interruptible is False

    @pytest.mark.asyncio
    async def test_regular_send_text_maps_to_interruptible_true(self):
        """AgentSendText maps to MessageOutput(interruptible=True) by default."""
        ws = create_mock_websocket()
        runner = ConversationRunner(ws, noop_agent, env)

        result = runner._map_output_event(AgentSendText(text="Hello!"))
        assert isinstance(result, MessageOutput)
        assert result.content == "Hello!"
        assert result.interruptible is True

    @pytest.mark.asyncio
    async def test_cancel_filter_still_applies_during_uninterruptible(self):
        """Cancel filter applies normally even during uninterruptible playback."""
        ws = create_mock_websocket()
        agent_started = asyncio.Event()
        agent_cancelled = asyncio.Event()
        proceed_to_yield = asyncio.Future()

        async def blocking_agent(env, event):
            if isinstance(event, CallStarted):
                agent_started.set()
                try:
                    yield AgentSendText(text="Legal disclaimer.", interruptible=False)
                    await proceed_to_yield
                except asyncio.CancelledError:
                    agent_cancelled.set()
                    raise

        msg_idx = 0

        async def receive_messages():
            nonlocal msg_idx
            if msg_idx == 0:
                await agent_started.wait()
                msg_idx += 1
                return {"type": "user_state", "value": "speaking"}
            raise WebSocketDisconnect()

        ws.receive_json = receive_messages

        runner = ConversationRunner(ws, blocking_agent, env)
        await runner.run()
        assert agent_cancelled.is_set()

    @pytest.mark.asyncio
    async def test_emitted_agent_text_tracks_interruptibility(self):
        """emitted_agent_text records (text, interruptible) tuples."""
        ws = create_mock_websocket()

        async def scripted_agent(env, event):
            if isinstance(event, CallStarted):
                yield AgentSendText(text="Let me check.", interruptible=True)
                yield AgentSendText(text="Legal notice.", interruptible=False)
                yield AgentSendText(text="How can I help?", interruptible=True)

        runner = ConversationRunner(ws, scripted_agent, env)
        await runner._start_agent_task(TurnEnv(), CallStarted())
        if runner.agent_task:
            await runner.agent_task

        assert runner.emitted_agent_text == [
            ("Let me check.", True),
            ("Legal notice.", False),
            ("How can I help?", True),
        ]

    def test_uninterruptible_precommit_before_user_event(self):
        """Uninterruptible text is pre-committed in full before user events."""
        # Agent emitted uninterruptible text, partial ack-back arrived, then user spoke
        chunks = [("This call is recorded.", False)]
        history = [
            AgentTextSent(content="Thiscall"),  # partial ack-back
            UserTextSent(content="Hi"),
        ]
        result = _get_processed_history(chunks, history)
        assert len(result) == 2
        assert isinstance(result[0], AgentTextSent)
        assert result[0].content == "This call is recorded."
        assert isinstance(result[1], UserTextSent)

    def test_late_ack_back_deduped_after_precommit(self):
        """Late ack-backs for pre-committed text are deduplicated."""
        chunks = [("This call is recorded.", False)]
        history = [
            AgentTextSent(content="Thiscall"),  # partial ack-back before user event
            UserTextSent(content="Hi"),
            AgentTextSent(content="isrecorded."),  # late ack-back after user event
        ]
        result = _get_processed_history(chunks, history)
        # Should have: AgentTextSent (pre-committed), UserTextSent. Late ack-back deduped.
        agent_texts = [e for e in result if isinstance(e, AgentTextSent)]
        assert len(agent_texts) == 1
        assert agent_texts[0].content == "This call is recorded."
        user_texts = [e for e in result if isinstance(e, UserTextSent)]
        assert len(user_texts) == 1

    def test_interruptible_text_not_precommitted(self):
        """Interruptible text is NOT pre-committed — only ack'd text appears."""
        chunks = [("Hello world", True)]
        history = [
            AgentTextSent(content="Hello"),  # partial ack-back
            UserTextSent(content="Stop"),
        ]
        result = _get_processed_history(chunks, history)
        agent_texts = [e for e in result if isinstance(e, AgentTextSent)]
        assert len(agent_texts) == 1
        assert agent_texts[0].content == "Hello"

    def test_consecutive_uninterruptible_chunks_precommitted(self):
        """Multiple consecutive uninterruptible chunks are all pre-committed."""
        chunks = [("Legal notice.", False), (" Terms apply.", False)]
        history = [
            AgentTextSent(content="Legal"),  # partial ack-back of first chunk
            UserTextSent(content="Hi"),
        ]
        result = _get_processed_history(chunks, history)
        agent_texts = [e for e in result if isinstance(e, AgentTextSent)]
        assert len(agent_texts) == 1
        assert agent_texts[0].content == "Legal notice. Terms apply."

    def test_interruptible_then_uninterruptible_precommit(self):
        """Interruptible text before uninterruptible is not extended; uninterruptible
        is pre-committed when ack-backs reach it."""
        chunks = [("Hello there.", True), ("This call is recorded.", False)]
        history = [
            AgentTextSent(content="Hellothere.Thiscall"),  # ack-back spans both chunks
            UserTextSent(content="Hi"),
        ]
        result = _get_processed_history(chunks, history)
        agent_texts = [e for e in result if isinstance(e, AgentTextSent)]
        assert len(agent_texts) == 1
        # Whitespace restored + uninterruptible chunk completed
        assert agent_texts[0].content == "Hello there.This call is recorded."

    def test_mixed_ack_back_with_late_dedup(self):
        """Full flow: interruptible ack-back, uninterruptible pre-commit, late dedup."""
        chunks = [("Hello.", True), ("Legal notice.", False)]
        history = [
            AgentTextSent(content="Hello.Legal"),  # ack-back covers interruptible + partial uninterruptible
            UserTextSent(content="Bye"),
            AgentTextSent(content="notice."),  # late ack-back for rest of uninterruptible
        ]
        result = _get_processed_history(chunks, history)
        agent_texts = [e for e in result if isinstance(e, AgentTextSent)]
        assert len(agent_texts) == 1
        assert agent_texts[0].content == "Hello.Legal notice."

    def test_identical_text_interruptible_then_uninterruptible(self):
        """When interruptible and uninterruptible chunks have identical text,
        consumed_pos lands inside the interruptible chunk (ambiguous) so we
        do NOT pre-commit. The text appears after the user event via ack-back."""
        chunks = [("Hello", True), ("Hello", False)]
        history = [
            AgentTextSent(content="Hel"),  # partial ack-back, inside interruptible chunk
            UserTextSent(content="Stop"),
            AgentTextSent(content="loHello"),  # late ack-back spanning both chunks
        ]
        result = _get_processed_history(chunks, history)
        agent_texts = [e for e in result if isinstance(e, AgentTextSent)]
        user_texts = [e for e in result if isinstance(e, UserTextSent)]
        # Interruptible chunk → no pre-commit. Ack-back text appears after user.
        assert len(agent_texts) == 2
        assert agent_texts[0].content == "Hel"
        assert result.index(agent_texts[0]) < result.index(user_texts[0])
        assert result.index(user_texts[0]) < result.index(agent_texts[1])

    def test_no_ack_backs_before_user_event_no_precommit(self):
        """With zero ack-backs, consumed_pos is at chunk start (boundary),
        so we do NOT pre-commit — no evidence the chunk was being spoken.
        Self-correcting: once ack-back arrives, next call will pre-commit."""
        chunks = [("Legal notice.", False)]
        history = [
            UserTextSent(content="Hi"),  # user speaks before any ack-back
            AgentTextSent(content="Legalnotice."),  # late ack-back
        ]
        result = _get_processed_history(chunks, history)
        agent_texts = [e for e in result if isinstance(e, AgentTextSent)]
        user_texts = [e for e in result if isinstance(e, UserTextSent)]
        # No pre-commit (consumed_pos=0, at boundary). Text appears after user.
        assert len(agent_texts) == 1
        assert agent_texts[0].content == "Legal notice."
        assert result.index(user_texts[0]) < result.index(agent_texts[0])

    def test_multi_turn_no_retroactive_precommit(self):
        """Uninterruptible text from turn 2 must NOT be retroactively
        pre-committed before user events from turn 1.

        Scenario:
        - Turn 1: agent says "Hello" (interruptible), fully ack'd, user speaks
        - Turn 2: agent says "Legal notice." (uninterruptible)
        - User speaks again

        Without the strict consumed_pos check, reprocessing would find the
        uninterruptible chunk and pre-commit it before turn 1's user event.
        """
        chunks = [("Hello", True), ("Legal notice.", False)]
        history = [
            AgentTextSent(content="Hello"),  # full ack-back for turn 1
            UserTextSent(content="Hi there"),  # user speaks after turn 1
            AgentTextSent(content="Legalnotice."),  # ack-back for turn 2
            UserTextSent(content="Thanks"),  # user speaks after turn 2
        ]
        result = _get_processed_history(chunks, history)
        agent_texts = [e for e in result if isinstance(e, AgentTextSent)]
        user_texts = [e for e in result if isinstance(e, UserTextSent)]
        # Turn 1 agent text before turn 1 user text
        assert result.index(agent_texts[0]) < result.index(user_texts[0])
        # Turn 2 agent text should NOT appear before turn 1 user text
        # (consumed_pos=5 is at chunk boundary, not strictly inside)
        assert result.index(user_texts[0]) < result.index(agent_texts[1])

    @pytest.mark.asyncio
    async def test_late_ack_back_after_cancel_does_not_leak_into_processed_history(self):
        """Late disclaimer ack-back should not leak or duplicate user events after cancel+restart."""
        ws = create_mock_websocket()
        first_turn_started = asyncio.Event()
        first_turn_block = asyncio.Future()

        async def scripted_agent(env, event):
            if isinstance(event, CallStarted):
                yield AgentSendText(text="This call may be recorded.", interruptible=False)
                first_turn_started.set()
                await first_turn_block
            elif isinstance(event, UserTurnEnded):
                yield AgentSendText(text="Thank you", interruptible=True)

        runner = ConversationRunner(ws, scripted_agent, env)

        await runner._start_agent_task(TurnEnv(), CallStarted())
        await first_turn_started.wait()

        # UserTurnEnded starts a new LM run and cancels the old task.
        await runner._start_agent_task(TurnEnv(), UserTurnEnded())
        if runner.agent_task:
            await runner.agent_task

        # Simulate the raw history as the run loop would produce it:
        # partial ack-back, user events, late ack-back, then normal ack-back
        history: List[InputEvent] = [
            CallStarted(),
            AgentTextSent(content="Thiscallmay"),  # partial ack-back before user
            UserTextSent(content="Hello?"),
            UserTurnEnded(content=[]),
            AgentTextSent(content="berecorded."),  # late ack-back after user
            AgentTextSent(content="Thankyou"),  # ack-back for second turn
        ]
        processed = _get_processed_history(runner.emitted_agent_text, history)

        # The uninterruptible disclaimer should be pre-committed before user text
        agent_texts = [e for e in processed if isinstance(e, AgentTextSent)]
        user_texts = [e for e in processed if isinstance(e, UserTextSent)]
        assert len(user_texts) == 1
        assert user_texts[0].content == "Hello?"

        # Should have disclaimer (pre-committed) and "Thank you" — no duplicates
        assert len(agent_texts) == 2
        assert "recorded" in agent_texts[0].content
        assert agent_texts[1].content == "Thank you"

        # Disclaimer must appear before user text
        disclaimer_idx = processed.index(agent_texts[0])
        user_idx = processed.index(user_texts[0])
        assert disclaimer_idx < user_idx


# ============================================================
# Adversarial _consume_expected_ack_back_prefix tests
# ============================================================


class TestConsumeExpectedAckBackAdversarial:
    """Adversarial edge cases for _consume_expected_ack_back_prefix."""

    # -- Pure full-stop committed text should NOT match --

    def test_lone_full_stop_does_not_match_pending(self):
        """A lone TTS-injected '.' must not falsely suppress against real pending text."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix(".", "Hello")
        assert consumed == 0
        assert remaining_c == "."
        assert remaining_p == "Hello"

    def test_multiple_full_stops_do_not_match_pending(self):
        """Pure full-stop committed '...' must not match against any pending text."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("...", "Hello world")
        assert consumed == 0
        assert remaining_c == "..."
        assert remaining_p == "Hello world"

    def test_devanagari_full_stop_does_not_match_pending(self):
        """Devanagari danda '।' alone must not falsely suppress."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("।", "नमस्ते")
        assert consumed == 0
        assert remaining_c == "।"
        assert remaining_p == "नमस्ते"

    def test_cjk_full_stop_does_not_match_pending(self):
        """CJK full stop '。' alone must not falsely suppress."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("。", "你好")
        assert consumed == 0
        assert remaining_c == "。"
        assert remaining_p == "你好"

    # -- Full stops combined with real content SHOULD match --

    def test_leading_full_stop_before_real_content_is_consumed(self):
        """A TTS-injected leading '.' before real content is valid noise."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix(".Hello", "Hello")
        assert consumed == 6  # ".Hello" fully consumed
        assert remaining_c == ""
        assert remaining_p == ""

    def test_multiple_trailing_full_stops_after_real_match(self):
        """Multiple TTS-injected trailing full stops are swept after a real match."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("Hello...", "Hello")
        assert consumed == 8
        assert remaining_c == ""
        assert remaining_p == ""

    def test_mixed_full_stop_types_around_real_content(self):
        """Mixed full stop characters (.।。) around real content are all swept."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix(".Hello।。", "Hello")
        assert consumed == 8
        assert remaining_c == ""
        assert remaining_p == ""

    # -- Whitespace and emoji in pending --

    def test_leading_whitespace_in_pending_is_skipped(self):
        """Leading whitespace in pending is harness-stripped and should be skipped."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("Hello", "  Hello")
        assert consumed == 5
        assert remaining_c == ""
        assert remaining_p == ""

    def test_emoji_in_pending_is_skipped(self):
        """Emoji characters in pending are harness-stripped and should be skipped."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("Hellothere", "Hello 👋 there")
        assert consumed == 10
        assert remaining_c == ""
        assert remaining_p == ""

    def test_emoji_only_pending_does_not_match(self):
        """Pure emoji pending with real committed text should not match."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("Hello", "👋🎉")
        assert consumed == 0
        assert remaining_c == "Hello"
        assert remaining_p == "👋🎉"

    # -- Partial consumption and multi-chunk scenarios --

    def test_partial_committed_against_longer_pending(self):
        """Committed is a prefix of the full pending text; remainder stays pending."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("Hello", "Hello world goodbye")
        assert consumed == 5
        assert remaining_c == ""
        # Leading whitespace after match is drained (it's harness-stripped)
        assert remaining_p == "world goodbye"

    def test_multi_chunk_drain_then_corrupt_chunk(self):
        """After partial consumption, a non-matching chunk passes through untouched."""
        # Chunk 1: partial match
        consumed1, rem_c1, rem_p = _consume_expected_ack_back_prefix("Hello", "Hello world")
        assert consumed1 == 5
        assert rem_c1 == ""
        assert rem_p == "world"

        # Chunk 2: corrupted, doesn't match remaining pending
        consumed2, rem_c2, rem_p2 = _consume_expected_ack_back_prefix("Xorld", rem_p)
        assert consumed2 == 0
        assert rem_c2 == "Xorld"
        assert rem_p2 == "world"

    def test_committed_longer_than_pending(self):
        """Committed extends beyond pending — partial match, remainder in committed."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix(
            "HelloworldExtra", "Hello world"
        )
        assert consumed > 0
        assert remaining_c == "Extra"
        assert remaining_p == ""

    def test_single_char_match(self):
        """A single-character match is sufficient to count as a real match."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("H", "Hello")
        assert consumed == 1
        assert remaining_c == ""
        assert remaining_p == "ello"

    # -- Unicode and accented characters --

    def test_accented_characters(self):
        """Accented characters should match exactly."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("Héllocafé", "Héllo café")
        assert consumed == 9
        assert remaining_c == ""
        assert remaining_p == ""

    # -- Empty / degenerate inputs --

    def test_empty_committed_returns_zero(self):
        """Empty committed text means nothing to consume."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("", "Hello")
        assert consumed == 0
        assert remaining_c == ""
        assert remaining_p == "Hello"

    def test_empty_pending_returns_zero(self):
        """Empty pending text means nothing to match against."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("Hello", "")
        assert consumed == 0
        assert remaining_c == "Hello"
        assert remaining_p == ""

    def test_both_empty(self):
        """Both empty — no-op."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("", "")
        assert consumed == 0
        assert remaining_c == ""
        assert remaining_p == ""

    # -- Boundary between uninterruptible and interruptible in same chunk --

    def test_interruptible_suffix_preserved_after_uninterruptible_prefix(self):
        """When a chunk straddles the boundary, only the uninterruptible prefix is consumed."""
        # Agent emitted "Hold." (uninterruptible), then "So yes" (interruptible)
        # Harness bundles: "Hold.Soyes"
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("Hold.Soyes", "Hold.")
        assert consumed == 5  # "Hold." consumed
        assert remaining_c == "Soyes"
        assert remaining_p == ""

    def test_tts_injects_full_stop_at_boundary(self):
        """TTS injects a period between uninterruptible and interruptible text."""
        # Agent emitted "Hold" (uninterruptible), TTS adds ".", then interruptible text follows
        # Harness sends: "Hold.Soyes"
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("Hold.Soyes", "Hold")
        # "Hold" matches real chars, trailing "." is swept
        assert consumed == 5  # "Hold" + "."
        assert remaining_c == "Soyes"
        assert remaining_p == ""

    # -- Full stop at chunk boundary after partial drain --

    def test_full_stop_only_chunk_after_pending_drained(self):
        """Once pending is empty, a full-stop-only chunk should pass through."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix(".", "")
        assert consumed == 0
        assert remaining_c == "."
        assert remaining_p == ""

    def test_full_stop_only_chunk_with_remaining_pending(self):
        """A full-stop-only ack-back must not consume from remaining pending text."""
        # This is the key adversarial case: pending has real text left,
        # but the ack-back is just TTS noise — must not falsely suppress.
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix(".", " world")
        assert consumed == 0
        assert remaining_c == "."
        assert remaining_p == " world"

    # -- Full-prefix match guard: reject coincidental partial overlaps --

    def test_stale_dedup_coincidental_first_char_match(self):
        """Stale pre_committed_dedup='bcd' must not corrupt unrelated ack-back 'bye'.

        Scenario 1: Turn 1 pre-commits 'bcd', turn 2 ack-back is 'bye'.
        The leading 'b' matches but this is coincidental — must reject.
        """
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("bye", "bcd")
        assert consumed == 0
        assert remaining_c == "bye"
        assert remaining_p == "bcd"

    def test_stale_dedup_whitespace_induced_partial_match(self):
        """Stale pre_committed_dedup=' world' must not corrupt unrelated ack-back 'wonderful'.

        Scenario 5: Leading whitespace in pending is skipped, then 'wo' matches
        coincidentally. Neither side is fully consumed — must reject.
        """
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("wonderful", " world")
        assert consumed == 0
        assert remaining_c == "wonderful"
        assert remaining_p == " world"

    def test_partial_overlap_both_sides_leftover_rejected(self):
        """Any partial overlap where both sides have remaining chars is rejected."""
        consumed, remaining_c, remaining_p = _consume_expected_ack_back_prefix("abcXYZ", "abcDEF")
        assert consumed == 0
        assert remaining_c == "abcXYZ"
        assert remaining_p == "abcDEF"


# ============================================================
# AgentEndCall / AgentTransferCall -> OutputMessage mapping tests
# ============================================================


class TestEndCallAndTransferCallMapping:
    """Tests for _map_output_event forwarding interruptible on end_call and transfer_call."""

    def _map(self, event):
        ws = create_mock_websocket()
        runner = ConversationRunner(ws, noop_agent, env)
        return runner._map_output_event(event)

    def test_end_call_interruptible_false(self):
        """AgentEndCall(interruptible=False) maps to EndCallOutput(interruptible=False)."""
        result = self._map(AgentEndCall(interruptible=False))
        assert isinstance(result, EndCallOutput)
        assert result.interruptible is False

    def test_end_call_interruptible_true_by_default(self):
        """AgentEndCall() defaults to interruptible=True."""
        result = self._map(AgentEndCall())
        assert isinstance(result, EndCallOutput)
        assert result.interruptible is True

    def test_transfer_call_interruptible_false(self):
        """AgentTransferCall(interruptible=False) maps to TransferOutput(interruptible=False)."""
        result = self._map(AgentTransferCall(target_phone_number="+14155551234", interruptible=False))
        assert isinstance(result, TransferOutput)
        assert result.target_phone_number == "+14155551234"
        assert result.interruptible is False

    def test_transfer_call_interruptible_true_by_default(self):
        """AgentTransferCall() defaults to interruptible=True."""
        result = self._map(AgentTransferCall(target_phone_number="+14155551234"))
        assert isinstance(result, TransferOutput)
        assert result.interruptible is True


# ============================================================
# AgentUpdateCall -> ConfigOutput mapping tests
# ============================================================


class TestUpdateCallMapping:
    """Tests for _map_output_event handling of AgentUpdateCall language mapping."""

    def _map(self, event):
        """Helper to call _map_output_event on a ConversationRunner."""
        ws = create_mock_websocket()
        runner = ConversationRunner(ws, noop_agent, env)
        return runner._map_output_event(event)

    def test_language_sets_both(self):
        """language='fr' sets TTS language and STT config (backward compat)."""
        result = self._map(AgentUpdateCall(language="fr"))
        assert result.tts.language == "fr"
        assert result.stt is not None
        assert result.stt.language == "fr"

    def test_multilingual_forwards_sentinel(self):
        """language='multilingual' forwards the sentinel verbatim on all three fields."""
        result = self._map(AgentUpdateCall(language="multilingual"))
        assert result.tts.language == "multilingual"
        assert result.stt is not None
        assert result.stt.language == "multilingual"
        assert result.language == "multilingual"

    def test_all_none_defaults(self):
        """No fields set -> TTS language None, STT config None (no change)."""
        result = self._map(AgentUpdateCall())
        assert result.tts.language is None
        assert result.stt is None


# ============================================================
# WebSocket output truncation tests
# ============================================================


class TestEventMessageTruncation:
    """Tests for _map_output_event truncation of large output event payloads."""

    def _map(self, event):
        ws = create_mock_websocket()
        runner = ConversationRunner(ws, noop_agent, env)
        return runner._map_output_event(event)

    def test_small_result_not_truncated(self):
        """Tool results under the limit are passed through unchanged."""
        event = AgentToolReturned(tool_call_id="1", tool_name="menu_info", tool_args={}, result="small")
        output = self._map(event)
        assert output.result == "small"

    def test_large_result_truncated(self):
        """Tool results over 30KB are truncated to avoid large WebSocket payloads."""
        large_result = "x" * 40_000
        event = AgentToolReturned(tool_call_id="1", tool_name="menu_info", tool_args={}, result=large_result)
        output = self._map(event)
        assert len(output.result) < 32_000
        assert output.result.endswith("... [truncated]")
        assert output.result.startswith("x" * 100)

    def test_result_at_boundary_not_truncated(self):
        """Tool results exactly at 30000 chars are not truncated."""
        boundary_result = "y" * 30_000
        event = AgentToolReturned(
            tool_call_id="1", tool_name="menu_info", tool_args={}, result=boundary_result
        )
        output = self._map(event)
        assert output.result == boundary_result

    def test_none_result_unchanged(self):
        """None results are passed through as None."""
        event = AgentToolReturned(tool_call_id="1", tool_name="menu_info", tool_args={}, result=None)
        output = self._map(event)
        assert output.result is None

    def test_large_tool_args_truncated(self):
        """AgentToolCalled with large tool_args gets a sentinel dict."""
        large_args = {"data": "x" * 40_000}
        event = AgentToolCalled(tool_call_id="1", tool_name="big_tool", tool_args=large_args)
        output = self._map(event)
        assert output.arguments["_truncated"] is True
        assert "_preview" in output.arguments
        assert len(output.arguments["_preview"]) == 200

    def test_small_tool_args_not_truncated(self):
        """AgentToolCalled with small tool_args passes through unchanged."""
        args = {"query": "hello"}
        event = AgentToolCalled(tool_call_id="1", tool_name="search", tool_args=args)
        output = self._map(event)
        assert output.arguments == args

    def test_large_tool_returned_args_truncated(self):
        """AgentToolReturned also truncates large tool_args."""
        large_args = {"data": "x" * 40_000}
        event = AgentToolReturned(tool_call_id="1", tool_name="big_tool", tool_args=large_args, result="ok")
        output = self._map(event)
        assert output.arguments["_truncated"] is True

    def test_large_log_metadata_truncated(self):
        """LogMessage with large metadata truncates only the inner metadata key."""
        large_metadata = {"blob": "z" * 40_000}
        event = LogMessage(name="test", level="info", message="hi", metadata=large_metadata)
        output = self._map(event)
        assert output.metadata["level"] == "info"
        assert output.metadata["message"] == "hi"
        inner = output.metadata["metadata"]
        assert isinstance(inner, dict)
        assert inner["_truncated"] is True
        assert "_preview" in inner

    def test_small_log_metadata_not_truncated(self):
        """LogMessage with small metadata passes through with original values."""
        event = LogMessage(name="test", level="info", message="hi", metadata={"key": "val"})
        output = self._map(event)
        assert output.metadata["level"] == "info"
        assert output.metadata["message"] == "hi"
        assert output.metadata["metadata"] == {"key": "val"}

    def test_non_serializable_result_does_not_crash(self):
        """Non-JSON-serializable result (e.g. datetime) is converted via str, not crash."""
        event = AgentToolReturned(tool_call_id="1", tool_name="t", tool_args={}, result=datetime.now())
        output = self._map(event)
        assert isinstance(output.result, str)

    def test_non_serializable_tool_args_does_not_crash(self):
        """Non-JSON-serializable values in tool_args don't crash json.dumps."""
        event = AgentToolCalled(tool_call_id="1", tool_name="t", tool_args={"ts": datetime.now()})
        output = self._map(event)
        assert isinstance(output.arguments, dict)

    def test_non_serializable_log_metadata_does_not_crash(self):
        """Non-JSON-serializable values in LogMessage metadata don't crash json.dumps."""
        event = LogMessage(name="test", level="info", message="hi", metadata={"ts": datetime.now()})
        output = self._map(event)
        assert isinstance(output.metadata, dict)


# ============================================================
# Start message tests
# ============================================================


class TestCallRequestFromStartData:
    """Tests for _call_request_from_start_data parsing."""

    def test_valid_start_message(self):
        data = {
            "type": "start",
            "call_id": "call-123",
            "from": "+15551234567",
            "to": "+15559876543",
            "agent_call_id": "ac-456",
            "agent": {"system_prompt": "You are helpful.", "introduction": "Hello!"},
            "metadata": {"key": "value"},
        }
        result = _call_request_from_start_data(data)
        assert result.call_id == "call-123"
        assert result.from_ == "+15551234567"
        assert result.to == "+15559876543"
        assert result.agent_call_id == "ac-456"
        assert result.agent.system_prompt == "You are helpful."
        assert result.agent.introduction == "Hello!"
        assert result.metadata == {"key": "value"}

    def test_defaults_for_missing_fields(self):
        data = {"type": "start"}
        result = _call_request_from_start_data(data)
        assert result.call_id == "unknown"
        assert result.from_ == "unknown"
        assert result.to == "unknown"
        assert result.agent_call_id == "unknown"
        assert result.agent.system_prompt is None
        assert result.agent.introduction is None
        assert result.metadata == {}

    def test_extra_fields_ignored(self):
        data = {
            "type": "start",
            "call_id": "call-123",
            "from": "+1555",
            "to": "+1555",
            "agent_call_id": "ac-1",
            "agent": {},
            "future_field": "should be ignored",
        }
        result = _call_request_from_start_data(data)
        assert result.call_id == "call-123"
