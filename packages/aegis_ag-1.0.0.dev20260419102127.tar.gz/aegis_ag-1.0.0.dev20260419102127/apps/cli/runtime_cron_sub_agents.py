"""Prompt composers for scheduled and delegated CLI runtime turns."""

from __future__ import annotations

from collections.abc import Mapping
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import subprocess
import sys
from typing import Any

from packages.cron import CronJob


def cron_skill_ids(value: object) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        raw_items = value.replace("\n", ",").split(",")
    elif isinstance(value, (list, tuple)):
        raw_items = [str(item) for item in value]
    else:
        raw_items = [str(value)]
    return tuple(dict.fromkeys(item.strip() for item in raw_items if item.strip()))


def compose_cron_prompt(runtime: Any, job: CronJob, *, user_prompt: str, session_id: str) -> str:
    skill_sections = _skill_sections(runtime, cron_skill_ids(job.payload.get("skills")), session_id=session_id)
    sections = [
        "[SYSTEM: This turn is running as a scheduled Aegis cron job.]",
        "The scheduler will surface the final response; do not call tool.message.send from this job.",
        "The user may not be present, so avoid interactive clarification and make conservative assumptions.",
        "If there is no useful update, respond exactly [SILENT].",
        "",
        f"Cron job: {job.name} ({job.job_id})",
        f"Schedule: {job.schedule_text}",
    ]
    if skill_sections:
        sections.extend(["", "Scheduled skill instructions:", "\n\n".join(skill_sections)])
    sections.extend(["", f"Scheduled task:\n{user_prompt}"])
    return "\n".join(sections).strip()


def run_sub_agent_task(
    runtime: Any,
    *,
    session_id: str,
    task: str,
    name: str | None = None,
    skills: tuple[str, ...] = (),
) -> Mapping[str, Any]:
    result = run_sub_agent_tasks(
        runtime,
        session_id=session_id,
        tasks=({"task": task, "name": name, "skills": skills},),
        max_concurrency=1,
    )
    results = tuple(result.get("results") or ())
    if not results:
        return {
            "name": name or "sub-agent",
            "summary": "sub-agent did not return a result",
            "skills": list(skills),
            "status": "failed",
        }
    return results[0]


def run_sub_agent_tasks(
    runtime: Any,
    *,
    session_id: str,
    tasks: tuple[Mapping[str, Any], ...],
    max_concurrency: int = 3,
) -> Mapping[str, Any]:
    if runtime.sub_agent_active:
        raise RuntimeError("nested sub-agent delegation is not allowed")
    normalized = tuple(_normalize_sub_agent_task(item) for item in tasks)
    if not normalized:
        raise ValueError("tool.sub_agents requires at least one task")
    workers = max(1, min(int(max_concurrency or 1), len(normalized), 3))
    results: list[Mapping[str, Any] | None] = [None] * len(normalized)
    object.__setattr__(runtime, "sub_agent_active", True)
    try:
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {
                executor.submit(
                    _run_one_sub_agent_child,
                    runtime,
                    parent_session_id=session_id,
                    task=item["task"],
                    name=item.get("name"),
                    skills=tuple(item.get("skills") or ()),
                ): index
                for index, item in enumerate(normalized)
            }
            for future in as_completed(futures):
                index = futures[future]
                results[index] = future.result()
    finally:
        object.__setattr__(runtime, "sub_agent_active", False)
    resolved = tuple(item for item in results if item is not None)
    summary = "\n".join(
        f"{index + 1}. {item.get('name') or 'sub-agent'}: {item.get('summary') or item.get('status') or 'finished'}"
        for index, item in enumerate(resolved)
    )
    return {
        "summary": summary or "sub-agent pool finished",
        "results": list(resolved),
        "max_concurrency": workers,
    }


def _run_one_sub_agent_child(
    runtime: Any,
    *,
    parent_session_id: str,
    task: str,
    name: str | None,
    skills: tuple[str, ...],
) -> Mapping[str, Any]:
    resume_result = runtime.resume(parent_session_id)
    child_session_id = resume_result.session.session_id
    prompt = _compose_sub_agent_prompt(
        runtime,
        task=task,
        name=name,
        skills=skills,
        session_id=child_session_id,
    )
    command = (
        sys.executable,
        "-m",
        "apps.cli",
        "--state-dir",
        str(runtime.paths.state_dir),
        "--profile-dir",
        str(runtime.paths.profile_dir),
        "wake",
        "--session-id",
        child_session_id,
        "--message",
        prompt,
    )
    env = dict(os.environ)
    env["AEGIS_SUB_AGENT_CHILD"] = "1"
    completed = subprocess.run(
        command,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    output = "\n".join(
        part.strip()
        for part in (completed.stdout, completed.stderr)
        if part and part.strip()
    ).strip()
    status = "completed" if completed.returncode == 0 else "failed"
    return {
        "name": name or "sub-agent",
        "summary": _child_output_summary(output, status=status),
        "skills": list(skills),
        "session_id": child_session_id,
        "status": status,
        "exit_code": completed.returncode,
    }


def _normalize_sub_agent_task(item: Mapping[str, Any]) -> Mapping[str, Any]:
    task = str(item.get("task") or item.get("prompt") or "").strip()
    if not task:
        raise ValueError("sub-agent tasks require 'task'")
    name = item.get("name")
    name_text = None if name is None else str(name).strip() or None
    skills = cron_skill_ids(item.get("skills"))
    return {"task": task, "name": name_text, "skills": skills}


def _child_output_summary(output: str, *, status: str) -> str:
    lines = [line.strip() for line in output.splitlines() if line.strip()]
    if not lines:
        return f"sub-agent {status} with no output"
    selected = lines[-8:]
    summary = "\n".join(selected).strip()
    if status == "failed":
        return f"sub-agent failed:\n{summary}"
    return summary


def _compose_sub_agent_prompt(
    runtime: Any,
    *,
    task: str,
    name: str | None,
    skills: tuple[str, ...],
    session_id: str,
) -> str:
    sections = [
        "[SYSTEM: You are running as a bounded Aegis sub-agent.]",
        "Return a concise final result for the parent agent.",
        "Do not call tool.sub_agents, tool.clarify, or tool.message.send.",
        "Use tools only when they materially advance this delegated task.",
        f"Sub-agent name: {name or 'sub-agent'}",
    ]
    skill_sections = _skill_sections(runtime, skills, session_id=session_id)
    if skill_sections:
        sections.extend(["", "Sub-agent skill instructions:", "\n\n".join(skill_sections)])
    sections.extend(["", f"Delegated task:\n{task}"])
    return "\n".join(sections).strip()


def _skill_sections(runtime: Any, skill_ids: tuple[str, ...], *, session_id: str) -> list[str]:
    sections: list[str] = []
    for skill_id in skill_ids:
        try:
            skill = runtime.inspect_skill(skill_id, session_id=session_id)
        except Exception as error:
            sections.append(f"Skill {skill_id}: unavailable ({error}).")
            continue
        sections.append(
            "\n".join(
                (
                    f"Skill: {skill.display_name} ({skill.skill_id})",
                    f"Summary: {skill.summary}",
                    "Instructions:",
                    skill.instruction_text.strip() or "<empty>",
                )
            )
        )
    return sections
