"""Packaged dashboard frontend assets."""
