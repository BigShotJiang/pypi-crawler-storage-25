"""Generation context enrichment helpers for the kernel lifecycle."""

from __future__ import annotations

from typing import Any
from uuid import uuid4

from packages.contracts.runtime import ContextBundle

from .intent_selection import augment_context_with_intent_selection


def build_context_for_generation(
    *,
    dependencies: Any,
    request: Any,
    profile: Any,
    session: Any,
    intent: Any,
    goals: tuple[Any, ...],
    memories: tuple[Any, ...],
    context: ContextBundle,
    decision: Any,
    plan: Any,
    continuity: Any,
    clock: Any,
    skill_definitions: Any,
    augment_clock: Any,
) -> ContextBundle:
    if request.tool_name is not None:
        return context
    enriched_context = context
    augment = getattr(dependencies.context, "augment_for_generation", None)
    if callable(augment):
        enriched = augment(
            session=session,
            goals=goals,
            memories=memories,
            context=context,
            intent=intent,
            decision=decision,
            plan=plan,
            continuity=continuity,
        )
        if isinstance(enriched, ContextBundle):
            enriched_context = enriched
    activation = getattr(dependencies.skill_runtime, "activate", None)
    skill_activate = None
    if callable(activation):
        skill_activate = lambda skill_id: activation(skill_id, session_id=session.session_id)
    routed_skill_id = str(request.event.payload.get("skill_route", "") or "").strip() or None
    skill_disclose = _skill_disclosure_emitter(dependencies, request=request, session=session, intent=intent)
    enriched_context = augment_context_with_intent_selection(
        context=enriched_context,
        intent=intent,
        skill_definitions=skill_definitions(session, profile=profile),
        skill_activate=skill_activate,
        skill_disclose=skill_disclose,
        routed_skill_id=routed_skill_id,
    )
    if clock is None:
        return enriched_context
    return augment_clock(enriched_context, clock=clock)


def _skill_disclosure_emitter(dependencies: Any, *, request: Any, session: Any, intent: Any):
    telemetry_emit = getattr(dependencies.telemetry, "emit", None)
    if not callable(telemetry_emit):
        return None

    def skill_disclose(definition: object, overlay_lines: tuple[str, ...]) -> None:
        instruction_text = str(getattr(definition, "instruction_text", "") or "").strip()
        dependencies.telemetry.emit(
            {
                "event_id": f"telemetry:{session.session_id}:skill.disclosed:{uuid4().hex}",
                "event_type": "skill.disclosed",
                "session_id": session.session_id,
                "source": "kernel",
                "payload": {
                    "trigger_event_id": request.event.event_id,
                    "intent": intent.intent,
                    "skill_id": str(getattr(definition, "skill_id", "") or "").strip(),
                    "display_name": str(getattr(definition, "display_name", "") or "").strip(),
                    "summary": str(getattr(definition, "summary", "") or "").strip(),
                    "disclosure_kind": "intent.overlay",
                    "overlay_line_count": len(overlay_lines),
                    "instruction_line_count": len(instruction_text.splitlines()) if instruction_text else 0,
                    "instruction_char_count": len(instruction_text),
                },
            }
        )

    return skill_disclose


__all__ = ["build_context_for_generation"]
