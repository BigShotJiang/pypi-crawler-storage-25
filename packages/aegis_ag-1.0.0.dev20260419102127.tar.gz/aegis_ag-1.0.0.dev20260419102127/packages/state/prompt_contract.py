"""Prompt contract assembly for Aegis canonical identity and user state."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .governance import (
    aegis_text,
    build_companion_identity_state,
    clone_text,
    parse_user_profile_content,
    render_user_profile_text,
    user_profile_text,
)
from .loader import LoadedProfile

PromptMode = Literal["full", "minimal"]

_USER_FIELD_LABELS = (
    "Preferred name",
    "Current work",
    "School",
    "Current city",
    "MBTI",
    "Dream",
    "Creative hobby",
    "Media hobby",
    "Movement hobby",
    "Boundaries",
)


@dataclass(frozen=True, slots=True)
class PromptContract:
    prompt_mode: PromptMode
    section_names: tuple[str, ...]
    instruction_refs: tuple[str, ...]
    stable_prefix_refs: tuple[str, ...] = ()
    profile_snapshot_refs: tuple[str, ...] = ()


def build_identity_kernel(profile: LoadedProfile) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    return (
        "section:identity-kernel",
        "identity-product=Aegis",
        f"identity-display-name={identity.display_name}",
        "identity-source=aegis-charter, canonical-identity, canonical-user, continuity-governance",
        (
            f"Answer as {identity.display_name}, a named Aegis clone. Let the immutable AEGIS charter "
            "define the core contract, and let canonical identity, user, relationship, and work state "
            "carry durable truth across wake, recovery, chat, and voice surfaces."
        ),
    )


def build_aegis_section(profile: LoadedProfile) -> tuple[str, ...]:
    path = profile.aegis_path or "<packaged>"
    return (
        "section:aegis",
        f"aegis-path={path}",
        f"aegis-charter={aegis_text(profile)}",
    )


def build_identity_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    lines = [
        "section:identity",
        f"identity-charter-extension={clone_text(profile)}",
        f"identity-preset={identity.personality_preset}",
        f"identity-label={identity.personality_label}",
        f"identity-traits={', '.join(identity.personality_traits) or 'grounded, durable'}",
    ]
    if prompt_mode == "full":
        lines.extend(
            (
                f"identity-working-style={identity.personality_summary}",
                f"identity-initiative={identity.initiative}",
                f"identity-relational-stance={identity.relational_stance}",
            )
        )
    return tuple(lines)


def build_user_snapshot_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    parsed_profile = parse_user_profile_content(user_profile_text(profile))
    known_fields = dict(parsed_profile.field_values)
    durable_notes = parsed_profile.durable_notes
    structured_summary = render_user_profile_text(**known_fields)
    note_summary = _durable_note_summary(durable_notes)
    summary_parts = [structured_summary] if structured_summary else []
    if note_summary:
        summary_parts.append(f"Durable notes: {note_summary}")
    lines = [
        "section:user-snapshot",
        f"user-known-fields={', '.join(known_fields.keys()) or 'none'}",
        f"user-summary={' | '.join(summary_parts) or 'No durable user profile facts are set yet.'}",
    ]
    if prompt_mode == "full":
        lines.extend(
            (
                f"active-display-name={identity.display_name}",
                f"mode={identity.mode}",
                f"continuity-notes={', '.join(identity.continuity_notes) or 'none'}",
                f"user-canonical-fields={', '.join(_USER_FIELD_LABELS)}",
                f"user-open-facts={note_summary or 'none'}",
                f"user-open-facts-count={len(durable_notes)}",
            )
        )
    return tuple(lines)


def build_personality_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    return build_identity_section(profile, prompt_mode=prompt_mode)


def build_runtime_contract_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    lines = [
        "section:runtime-contract",
        f"prompt-mode={prompt_mode}",
        "Protect continuity, disclose uncertainty, and stay legible.",
        "Keep one coherent long-lived identity across wake, recovery, chat, and voice surfaces.",
        "Treat AEGIS.md as immutable core identity; never try to rewrite it.",
        "Canonical personal-AI writes flow through runtime reconciliation and canonical state/work owners; prompt projections never become the storage model.",
        "Keep shared user state limited to stable user facts; do not store transient tasks, one-off asks, or generic session chatter there.",
        (
            "When durable user truth changes, reconcile concise labeled lines or structured fields keyed by canonical labels such as Preferred name, Current work, School, Current city, MBTI, Dream, Creative hobby, Media hobby, Movement hobby, and Boundaries, and keep any unmatched durable notes in canonical user state instead of dropping them."
        ),
        "When the user shares concrete durable identity, preferences, boundaries, or recurring work context, preserve that change through the canonical state owners; do not wait for an explicit 'remember this' instruction.",
        "If the user asks what you already know, answer from current identity, user, relationship, and work state first; only write when the turn adds or corrects durable facts.",
        "Do not run a formal onboarding ritual. If durable user facts are still thin, ask only for the next most relevant detail when it materially helps continuity or the current task.",
        "If the runtime context has no durable goals yet, naturally help the user name one foundational ongoing thread for this clone once the opening grounding is sufficient.",
        "When the user names that foundational thread, settle it durably in canonical work state instead of leaving it as chat-only context.",
        "When the user explicitly redefines this clone's voice, stance, initiative, or collaboration rhythm, reconcile that durable delta through the canonical state owners so it persists across wake, recovery, chat, and voice surfaces.",
    ]
    if prompt_mode == "full":
        lines.extend(
            (
                f"governance={identity.governance_summary}",
                f"voice-identity={identity.voice_identity_summary}",
                "grounding-policy=durable user and relationship context should deepen through normal conversation, not a file-first onboarding gate.",
            )
        )
    return tuple(lines)


def build_prompt_contract(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> PromptContract:
    stable_sections: list[tuple[str, tuple[str, ...]]] = [
        ("identity-kernel", build_identity_kernel(profile)),
        ("aegis", build_aegis_section(profile)),
        ("identity", build_identity_section(profile, prompt_mode=prompt_mode)),
        ("runtime-contract", build_runtime_contract_section(profile, prompt_mode=prompt_mode)),
    ]
    profile_snapshot_sections: list[tuple[str, tuple[str, ...]]] = [
        ("user-snapshot", build_user_snapshot_section(profile, prompt_mode=prompt_mode)),
    ]
    sections = [*stable_sections, *profile_snapshot_sections]
    stable_prefix_refs = tuple(line for _, lines in stable_sections for line in lines)
    profile_snapshot_refs = tuple(line for _, lines in profile_snapshot_sections for line in lines)
    instruction_refs = tuple((*stable_prefix_refs, *profile_snapshot_refs))
    return PromptContract(
        prompt_mode=prompt_mode,
        section_names=tuple(name for name, _ in sections),
        instruction_refs=instruction_refs,
        stable_prefix_refs=stable_prefix_refs,
        profile_snapshot_refs=profile_snapshot_refs,
    )


def _durable_note_summary(notes: tuple[str, ...], *, limit: int = 3) -> str:
    if not notes:
        return ""
    shown = notes[:limit]
    remainder = len(notes) - len(shown)
    summary = " | ".join(shown)
    if remainder > 0:
        summary += f" | +{remainder} more"
    return summary
