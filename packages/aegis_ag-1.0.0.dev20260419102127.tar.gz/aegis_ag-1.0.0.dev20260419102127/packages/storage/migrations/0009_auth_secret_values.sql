CREATE TABLE IF NOT EXISTS auth_secret_values (
    reference_id TEXT PRIMARY KEY,
    key_id TEXT NOT NULL,
    nonce_b64 TEXT NOT NULL,
    ciphertext_b64 TEXT NOT NULL,
    mac_hex TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(reference_id) REFERENCES auth_secret_references(reference_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_auth_secret_values_updated
    ON auth_secret_values(updated_at DESC, reference_id ASC);
