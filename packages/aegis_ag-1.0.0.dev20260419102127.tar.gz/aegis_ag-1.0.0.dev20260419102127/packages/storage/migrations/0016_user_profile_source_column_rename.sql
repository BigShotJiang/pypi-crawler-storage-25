ALTER TABLE user_cards
    RENAME COLUMN source_friend_path TO source_user_profile_path;
