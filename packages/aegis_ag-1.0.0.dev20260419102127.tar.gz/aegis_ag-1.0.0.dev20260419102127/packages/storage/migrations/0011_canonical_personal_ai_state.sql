CREATE TABLE IF NOT EXISTS clone_identities (
    clone_id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL,
    display_name TEXT NOT NULL,
    identity_mode TEXT NOT NULL,
    personality_preset TEXT NOT NULL,
    initiative TEXT NOT NULL,
    relational_stance TEXT NOT NULL,
    voice_contract TEXT NOT NULL,
    working_style_contract TEXT NOT NULL,
    charter_extension TEXT,
    governance_flags_json TEXT NOT NULL,
    source_manifest_path TEXT,
    source_clone_path TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(profile_id) REFERENCES profiles(profile_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_clone_identities_profile_id
    ON clone_identities(profile_id);

CREATE TABLE IF NOT EXISTS user_cards (
    user_card_id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL,
    preferred_name TEXT,
    locale TEXT,
    timezone TEXT,
    communication_preferences_json TEXT NOT NULL,
    boundaries_json TEXT NOT NULL,
    biography_fragments_json TEXT NOT NULL,
    shared_preferences_json TEXT NOT NULL,
    source_friend_path TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(profile_id) REFERENCES profiles(profile_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_user_cards_profile_id
    ON user_cards(profile_id);

CREATE TABLE IF NOT EXISTS relationship_memories (
    relationship_id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL,
    clone_id TEXT NOT NULL,
    user_card_id TEXT,
    interaction_preferences_json TEXT NOT NULL,
    repair_history_json TEXT NOT NULL,
    trust_markers_json TEXT NOT NULL,
    expectations_json TEXT NOT NULL,
    local_corrections_json TEXT NOT NULL,
    continuity_notes_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(profile_id) REFERENCES profiles(profile_id),
    FOREIGN KEY(clone_id) REFERENCES clone_identities(clone_id),
    FOREIGN KEY(user_card_id) REFERENCES user_cards(user_card_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_relationship_memories_profile_id
    ON relationship_memories(profile_id);

CREATE INDEX IF NOT EXISTS idx_relationship_memories_clone_id
    ON relationship_memories(clone_id);

CREATE TABLE IF NOT EXISTS identity_ledger_entries (
    entry_id TEXT PRIMARY KEY,
    clone_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    action TEXT NOT NULL,
    summary TEXT NOT NULL,
    metadata_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(clone_id) REFERENCES clone_identities(clone_id),
    FOREIGN KEY(profile_id) REFERENCES profiles(profile_id)
);

CREATE INDEX IF NOT EXISTS idx_identity_ledger_entries_clone_created
    ON identity_ledger_entries(clone_id, created_at ASC, entry_id ASC);

CREATE TABLE IF NOT EXISTS user_card_ledger_entries (
    entry_id TEXT PRIMARY KEY,
    user_card_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    action TEXT NOT NULL,
    summary TEXT NOT NULL,
    metadata_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(user_card_id) REFERENCES user_cards(user_card_id),
    FOREIGN KEY(profile_id) REFERENCES profiles(profile_id)
);

CREATE INDEX IF NOT EXISTS idx_user_card_ledger_entries_card_created
    ON user_card_ledger_entries(user_card_id, created_at ASC, entry_id ASC);

CREATE TABLE IF NOT EXISTS relationship_ledger_entries (
    entry_id TEXT PRIMARY KEY,
    relationship_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    action TEXT NOT NULL,
    summary TEXT NOT NULL,
    metadata_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(relationship_id) REFERENCES relationship_memories(relationship_id),
    FOREIGN KEY(profile_id) REFERENCES profiles(profile_id)
);

CREATE INDEX IF NOT EXISTS idx_relationship_ledger_entries_rel_created
    ON relationship_ledger_entries(relationship_id, created_at ASC, entry_id ASC);
