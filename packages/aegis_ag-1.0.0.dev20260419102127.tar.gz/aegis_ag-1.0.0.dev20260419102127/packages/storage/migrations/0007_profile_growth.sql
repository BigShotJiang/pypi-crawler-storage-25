CREATE TABLE IF NOT EXISTS profile_growth (
    profile_id TEXT PRIMARY KEY REFERENCES profiles(profile_id) ON DELETE CASCADE,
    growth_score INTEGER NOT NULL DEFAULT 0,
    total_dialogues INTEGER NOT NULL DEFAULT 0,
    total_tokens INTEGER NOT NULL DEFAULT 0,
    total_experiences INTEGER NOT NULL DEFAULT 0,
    promoted_experiences INTEGER NOT NULL DEFAULT 0,
    active_days INTEGER NOT NULL DEFAULT 0,
    streak_days INTEGER NOT NULL DEFAULT 0,
    first_dialogue_at TEXT,
    last_dialogue_at TEXT,
    last_active_day TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
