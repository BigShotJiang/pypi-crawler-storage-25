ALTER TABLE profiles RENAME COLUMN soul_path TO clone_path;
