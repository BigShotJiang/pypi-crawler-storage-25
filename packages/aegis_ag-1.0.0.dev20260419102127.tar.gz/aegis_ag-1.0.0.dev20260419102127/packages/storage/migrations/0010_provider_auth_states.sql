CREATE TABLE IF NOT EXISTS provider_auth_states (
    provider_id TEXT PRIMARY KEY,
    auth_type TEXT NOT NULL,
    status TEXT NOT NULL,
    source TEXT NOT NULL,
    profile_id TEXT,
    transport_id TEXT,
    provider_kind TEXT NOT NULL,
    base_url TEXT,
    default_model TEXT,
    runtime_enabled INTEGER NOT NULL DEFAULT 1,
    summary TEXT NOT NULL DEFAULT '',
    metadata_json TEXT NOT NULL DEFAULT '{}',
    discovered_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_provider_auth_states_status
    ON provider_auth_states(status ASC, provider_id ASC);
