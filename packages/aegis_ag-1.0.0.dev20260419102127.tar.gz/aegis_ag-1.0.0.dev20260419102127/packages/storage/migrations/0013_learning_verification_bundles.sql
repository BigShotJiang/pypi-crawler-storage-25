ALTER TABLE procedures ADD COLUMN verification_bundle_id TEXT;
ALTER TABLE procedures ADD COLUMN skill_id TEXT;

CREATE TABLE IF NOT EXISTS verification_bundles (
    bundle_id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL REFERENCES profiles(profile_id) ON DELETE CASCADE,
    candidate_id TEXT NOT NULL,
    method TEXT NOT NULL,
    status TEXT NOT NULL,
    notes TEXT NOT NULL,
    evidence_ids_json TEXT NOT NULL,
    scenario_ids_json TEXT NOT NULL,
    verified_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_verification_bundles_profile_status
    ON verification_bundles(profile_id, status, updated_at DESC, bundle_id ASC);
