ALTER TABLE memories
    ADD COLUMN metadata_json TEXT NOT NULL DEFAULT '{}';

UPDATE memories
SET metadata_json = '{}'
WHERE metadata_json IS NULL;
