CREATE TABLE IF NOT EXISTS token_usage_events (
    usage_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    profile_id TEXT NOT NULL,
    run_id TEXT,
    source_event_id TEXT,
    provider_id TEXT,
    model_id TEXT,
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens INTEGER NOT NULL DEFAULT 0,
    unit TEXT NOT NULL DEFAULT 'tokens',
    metadata_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_token_usage_events_session
    ON token_usage_events(session_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_token_usage_events_created
    ON token_usage_events(created_at DESC, usage_id ASC);
