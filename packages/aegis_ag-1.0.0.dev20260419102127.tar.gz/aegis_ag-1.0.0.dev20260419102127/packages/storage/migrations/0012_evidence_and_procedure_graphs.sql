CREATE TABLE IF NOT EXISTS artifacts (
    artifact_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    name TEXT NOT NULL,
    uri TEXT NOT NULL,
    checksum TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_artifacts_session_created
    ON artifacts(session_id, created_at ASC, artifact_id ASC);

CREATE TABLE IF NOT EXISTS procedure_libraries (
    profile_id TEXT PRIMARY KEY REFERENCES profiles(profile_id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS procedures (
    procedure_id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL REFERENCES procedure_libraries(profile_id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    summary TEXT NOT NULL,
    status TEXT NOT NULL,
    trigger_refs_json TEXT NOT NULL,
    evidence_refs_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_procedures_profile_status
    ON procedures(profile_id, status, updated_at DESC, procedure_id ASC);

CREATE TABLE IF NOT EXISTS procedure_steps (
    step_id TEXT PRIMARY KEY,
    procedure_id TEXT NOT NULL REFERENCES procedures(procedure_id) ON DELETE CASCADE,
    step_order INTEGER NOT NULL,
    title TEXT NOT NULL,
    instruction TEXT NOT NULL,
    tool_name TEXT
);

CREATE INDEX IF NOT EXISTS idx_procedure_steps_procedure_order
    ON procedure_steps(procedure_id, step_order ASC, step_id ASC);
