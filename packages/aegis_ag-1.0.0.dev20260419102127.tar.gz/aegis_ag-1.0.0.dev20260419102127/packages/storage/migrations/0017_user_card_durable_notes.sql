ALTER TABLE user_cards
    ADD COLUMN durable_notes_json TEXT NOT NULL DEFAULT '[]';
