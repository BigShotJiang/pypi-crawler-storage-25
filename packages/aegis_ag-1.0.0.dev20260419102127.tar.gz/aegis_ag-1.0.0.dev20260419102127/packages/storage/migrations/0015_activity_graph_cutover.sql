ALTER TABLE goal_graphs RENAME TO activity_graphs;
ALTER TABLE goal_nodes RENAME TO activity_nodes;
ALTER TABLE goal_lifecycle_events RENAME TO activity_lifecycle_events;

DROP INDEX IF EXISTS idx_goal_graphs_revision;
DROP INDEX IF EXISTS idx_goal_nodes_session_order;
DROP INDEX IF EXISTS idx_goal_nodes_status;
DROP INDEX IF EXISTS idx_goal_lifecycle_events_goal;

CREATE INDEX IF NOT EXISTS idx_activity_graphs_revision
    ON activity_graphs(session_id, updated_at DESC);

CREATE INDEX IF NOT EXISTS idx_activity_nodes_session_order
    ON activity_nodes(session_id, goal_order ASC, goal_id ASC);

CREATE INDEX IF NOT EXISTS idx_activity_nodes_status
    ON activity_nodes(session_id, status ASC, priority DESC, goal_id ASC);

CREATE INDEX IF NOT EXISTS idx_activity_lifecycle_events_goal
    ON activity_lifecycle_events(goal_id, created_at DESC, event_id ASC);
