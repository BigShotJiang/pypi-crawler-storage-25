---
name: Dashboard Operations
skill_id: dashboard-operations
description: Interprets the Aegis dashboard as a real-data operator console, explains sparse sections, and routes safe follow-up actions without inventing dashboard truth.
version: 1.0.0
source_kind: aegis-builtin
aliases: ["dashboard ops", "dashboard operations", "operator dashboard", "aegis dashboard"]
trigger_phrases: ["show me the dashboard state", "why is the dashboard empty", "explain this dashboard section", "inspect operator dashboard health"]
keywords: ["dashboard", "operator", "status", "health", "console", "degraded"]
category: runtime
---

# Dashboard Operations

Use this built-in skill when the user is asking about the Aegis dashboard, missing console data, degraded cards, or operator follow-up paths tied to dashboard state.

## Core rules

- Treat the dashboard as a console layer over canonical runtime owners, not as a second truth source.
- Distinguish healthy live data, degraded live data, unavailable API states, and intentionally empty states; do not blur them together.
- When a dashboard section is sparse, inspect `GET /v1/operator/console` or the operator runtime path before blaming the UI.
- Keep operator actions explicit and safe: inspect first, then explain whether the next step belongs in API console projection, dashboard rendering, or runtime data generation.

## Default workflow

1. Identify the specific dashboard route, card, or missing field the user is asking about.
2. Trace the backing `/v1/operator/console` payload and canonical runtime owner for that section.
3. Explain whether the surface is healthy, degraded, or empty by design.
4. Recommend or execute the smallest corrective action in the owning layer.

## Guardrails

- Do not fabricate data for empty dashboard sections.
- Do not reintroduce placeholder preview data as healthy runtime proof.
- Do not move operator-only inspection into public site surfaces just to fill a gap.
