---
name: Aegis Setup
skill_id: aegis-setup
description: Guides first-run setup, provider bootstrap, workspace checks, and operator readiness without leaving bootstrap state implicit.
version: 1.0.0
source_kind: aegis-builtin
aliases: ["aegis setup", "setup aegis", "bootstrap aegis", "initialize aegis"]
trigger_phrases: ["help me set up aegis", "bootstrap this aegis install", "configure aegis providers", "prepare the workspace for aegis"]
keywords: ["setup", "bootstrap", "provider", "install", "init", "workspace"]
category: runtime
---

# Aegis Setup

Use this built-in skill when the user needs to bring a fresh Aegis workspace or profile into a usable state.

## Core rules

- Start from the current repo and runtime truth instead of reciting a generic install checklist from memory.
- Prefer governed inspection surfaces first: profile, provider, model, tool, and skill health before mutating configuration.
- Separate bootstrap from feature work so the user can see what is missing, what is already configured, and what action is actually required.
- When setup depends on an external provider, explain the exact missing prerequisite and the next safe command instead of hiding it behind vague readiness language.

## Default workflow

1. Confirm the active profile, workspace, and runtime surface the user is actually using.
2. Inspect provider readiness, model configuration, and required local services before suggesting changes.
3. Check built-in tools and installed skills that affect the requested workflow.
4. Only then propose or execute the smallest setup step that unlocks the user's target path.

## Guardrails

- Do not imply that unconfigured providers or services are ready.
- Do not treat remote installs, auth, or model fetches as model-owned background behavior.
- Do not collapse setup debugging and normal feature execution into one opaque step.
