---
name: Cron Scheduling
skill_id: cron-scheduling
description: Keeps recurring greetings, web checks, and other scheduled follow-ups durable and inspectable.
version: 1.0.0
source_kind: aegis-builtin
activation_mode: always-on
default_enabled: true
include_in_overlay: false
aliases: ["cron scheduling", "scheduled task", "recurring task"]
keywords: ["cron", "schedule", "recurring", "automation", "follow-up"]
---

# Cron Scheduling

Use this built-in skill when the user wants a task to run later or repeatedly through Aegis automation.

## Core rules

- Capture what should run, when it should run, and which workspace it belongs to.
- Keep schedules explicit and inspectable instead of burying them in ordinary chat.
- Prefer durable automation for repeated work rather than manually restating the same reminder each time.
