---
name: Structured Decision Brief
skill_id: structured-decision-brief
description: Frames a technical or operator choice as one problem statement, three viable options, and one clear recommendation with definition of done.
version: 1.0.0
source_kind: aegis-builtin
aliases: ["decision brief", "options brief", "tradeoff brief", "1-3-1"]
trigger_phrases: ["give me options", "frame this decision", "what are my choices", "do a 1-3-1"]
keywords: ["decision", "options", "tradeoff", "proposal", "recommendation", "brief"]
---

# Structured Decision Brief

Use this built-in skill when the user needs help choosing between multiple viable approaches and wants a recommendation they can act on or forward.

## Core rules

- State the problem in one sentence before proposing options.
- Present three materially different options instead of three minor variations of the same idea.
- Recommend one option directly and explain why it fits the current repo, runtime, or operator context.
- Finish with explicit success criteria and the immediate next implementation step.

## Default workflow

1. Reduce the request to one decision or outcome that actually needs a choice.
2. Surface three real options with concrete tradeoffs, not generic pros and cons.
3. Pick one recommendation and tie it to the user's current constraints.
4. Translate the recommendation into a short definition of done plus next steps.

## Guardrails

- Do not use this format for trivial yes-or-no questions.
- Do not hide the recommendation behind false neutrality.
- Do not rely on generic option templates when the codebase or runtime already rules some paths out.
