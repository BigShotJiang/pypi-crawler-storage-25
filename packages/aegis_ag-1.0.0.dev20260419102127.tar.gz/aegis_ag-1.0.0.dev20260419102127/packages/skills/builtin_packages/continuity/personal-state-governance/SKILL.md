---
name: Personal State Governance
skill_id: personal-state-governance
description: Keeps canonical identity, shared user truth, and relationship continuity aligned with the runtime-owned state model.
version: 1.0.0
source_kind: aegis-builtin
activation_mode: always-on
default_enabled: true
include_in_overlay: true
aliases: ["personal state", "profile governance", "continuity governance"]
trigger_phrases: ["persist my profile", "remember this about me", "update the identity posture", "keep our relationship notes aligned"]
keywords: ["continuity", "profile", "identity", "relationship", "governance", "canonical"]
category: continuity
---

# Personal State Governance

Use this built-in skill whenever the turn changes durable identity, shared user facts, or clone-local relationship context.

## Core rules

- Treat canonical identity, user, and relationship records as the source of truth for continuity.
- Persist durable profile changes through governed runtime surfaces instead of leaving them as chat-only drift.
- Keep clone posture, shared user facts, and relationship notes legible, inspectable, and recoverable across future turns.
- When a user asks what is already known, answer from current canonical state first and only write if the turn adds or corrects durable facts.
