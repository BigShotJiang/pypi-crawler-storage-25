"""Main client for Qirabot SDK."""

from __future__ import annotations

import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Iterator

from qirabot._transport import Transport
from qirabot.actions import Action
from qirabot.exceptions import QirabotTimeoutError
from qirabot.task_context import TaskContext


@dataclass
class DeviceInfo:
    """Device information."""

    id: str
    name: str
    platform: str
    online: bool

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DeviceInfo:
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            platform=data.get("platform", ""),
            online=data.get("online", False),
        )


@dataclass
class TaskResult:
    """Result of a completed task."""

    id: str
    status: str
    current_step: int = 0
    source: str = ""
    error: str = ""
    steps: list[dict[str, Any]] = field(default_factory=list)

    @property
    def succeeded(self) -> bool:
        return self.status == "succeeded"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TaskResult:
        return cls(
            id=data.get("id", ""),
            status=data.get("status", ""),
            current_step=data.get("currentStep", 0),
            source=data.get("source", ""),
            error=data.get("error", ""),
        )


class Qirabot:
    """Qirabot SDK client.

    Usage::

        bot = Qirabot("qk_xxx", base_url="https://app.qirabot.com")
        with bot.task("device-id") as t:
            t.click("Login button")
            t.type("username", "admin")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://app.qirabot.com",
        timeout: float = 30.0,
        verify_ssl: bool = True,
    ):
        self._transport = Transport(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            verify_ssl=verify_ssl,
        )

    def devices(self) -> list[DeviceInfo]:
        """List all devices for the current user."""
        resp = self._transport.request("GET", "/devices")
        return [DeviceInfo.from_dict(d) for d in resp] if isinstance(resp, list) else []

    def active_devices(self) -> list[DeviceInfo]:
        """List online devices for the current user."""
        resp = self._transport.request("GET", "/devices/active")
        return [DeviceInfo.from_dict(d) for d in resp] if isinstance(resp, list) else []

    def submit(
        self,
        device_id: str = "",
        *,
        actions: list[Action] | None = None,
        instruction: str = "",
        model_alias: str = "",
        language: str = "",
        max_steps: int = 10,
        screenshot_mode: str = "cloud",
    ) -> str:
        """Submit actions for autonomous execution and return the task ID immediately.

        Use ``wait()`` to poll for completion.

        Args:
            device_id: The device to run on (optional if sandbox is configured).
            actions: List of actions to execute sequentially.
            instruction: Shorthand for a single AI action. Mutually exclusive with ``actions``.
            model_alias: Optional AI model alias.
            language: Optional language (e.g. "zh", "en").
            max_steps: Max steps for AI instruction (default 10).
            screenshot_mode: "cloud" (default) or "none".

        Returns:
            The task ID string.
        """
        if instruction and actions:
            raise ValueError("Cannot specify both 'actions' and 'instruction'")
        if not instruction and not actions:
            raise ValueError("Must specify either 'actions' or 'instruction'")

        if instruction:
            steps = [Action.ai(instruction, max_steps=max_steps, model_alias=model_alias or None, language=language or None)]
        else:
            steps = actions  # type: ignore[assignment]

        body: dict[str, Any] = {
            "actions": [a.to_dict() for a in steps],
        }
        if device_id:
            body["deviceId"] = device_id
        if model_alias:
            body["modelAlias"] = model_alias
        if language:
            body["language"] = language
        if screenshot_mode != "cloud":
            body["screenshotMode"] = screenshot_mode

        resp = self._transport.post("/sdk/tasks/submit", body)
        return resp["taskId"]

    def wait(
        self,
        task_id: str,
        timeout: float = 120.0,
        poll_interval: float = 3.0,
    ) -> TaskResult:
        """Poll until a submitted task reaches a terminal state.

        Args:
            task_id: The task ID returned by ``submit()``.
            timeout: Maximum seconds to wait (default 120).
            poll_interval: Seconds between polls (default 3).

        Returns:
            A :class:`TaskResult` with the final status and steps.

        Raises:
            QirabotTimeoutError: If the task does not complete within the timeout.
        """
        deadline = time.monotonic() + timeout
        while True:
            resp = self._transport.request("GET", f"/tasks/{task_id}")
            status = resp.get("status", "")
            if status not in ("pending", "running"):
                result = TaskResult.from_dict(resp)
                steps_resp = self._transport.request("GET", f"/tasks/{task_id}/steps")
                if isinstance(steps_resp, list):
                    result.steps = steps_resp
                return result
            if time.monotonic() >= deadline:
                raise QirabotTimeoutError(f"Task {task_id} did not complete within {timeout}s")
            time.sleep(poll_interval)

    @contextmanager
    def task(
        self,
        device_id: str,
        model_alias: str = "",
        language: str = "",
        screenshot_mode: str = "cloud",
    ) -> Iterator[TaskContext]:
        """Create a task on a device and return an interactive context.

        Args:
            device_id: The device to connect to.
            model_alias: Optional AI model alias to use (default: server default).
            language: Optional language for AI responses (e.g. "zh", "en", "ja").
            screenshot_mode: Screenshot storage mode:
                - "cloud": store to cloud, return path (default)
                - "inline": no cloud storage, send binary via WebSocket
                - "none": no screenshots stored or returned

        Yields:
            A TaskContext that auto-completes on exit.
        """
        body: dict[str, Any] = {"deviceId": device_id}
        if model_alias:
            body["modelAlias"] = model_alias
        if language:
            body["language"] = language
        if screenshot_mode != "cloud":
            body["screenshotMode"] = screenshot_mode

        resp = self._transport.post("/sdk/tasks", body)
        task_id = resp["taskId"]

        ctx = TaskContext(
            transport=self._transport,
            task_id=task_id,
            device_id=device_id,
            screenshot_mode=screenshot_mode,
        )
        with ctx:
            yield ctx

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._transport.close()

    def __enter__(self) -> Qirabot:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
