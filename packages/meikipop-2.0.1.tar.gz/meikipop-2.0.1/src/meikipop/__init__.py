"""meikipop - Universal Japanese OCR popup dictionary"""

__version__ = "2.0.1"
__author__ = "rtr46"
__license__ = "GPL-3.0"