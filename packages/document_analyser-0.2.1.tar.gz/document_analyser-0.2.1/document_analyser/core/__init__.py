# Core configuration
