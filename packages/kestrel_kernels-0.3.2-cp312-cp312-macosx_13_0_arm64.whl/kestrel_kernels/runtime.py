"""Stable runtime API surface for Kestrel kernels.

This module provides a single place for kernel entrypoints used by Kestrel.
Callers should depend on this API rather than deep internal module paths.
"""


import sys
from dataclasses import dataclass
from functools import lru_cache
from typing import Any, Callable

import torch


from kestrel_kernels.flash_attn.cute.mask_ids import PREFIX_LM_730_MASK_ID as _PREFIX_LM_730_HASH


def _missing_runtime_fn(domain: str, name: str, exc: Exception) -> Callable[..., Any]:
    def _missing(*_args, **_kwargs):
        raise RuntimeError(
            f"kestrel-kernels: '{domain}.{name}' is unavailable on this platform/runtime. "
            f"Original import error: {type(exc).__name__}: {exc}"
        ) from exc

    return _missing


def _missing_prefix_mask() -> Callable[..., Any]:
    def _mask(*_args, **_kwargs):
        raise RuntimeError(
            "kestrel-kernels: prefix-LM mask support requires the CuTe flash-attention runtime."
        )

    _mask.__cute_hash__ = _PREFIX_LM_730_HASH
    return _mask


def _topk_torch_fwd(
    x: torch.Tensor,
    k: int,
    softmax: bool = False,
) -> tuple[torch.Tensor, torch.Tensor]:
    values, indices = torch.topk(x, k=k, dim=-1)
    if softmax:
        values = torch.softmax(values.float(), dim=-1).to(x.dtype)
    return values, indices.to(torch.int32)


def _moe_topk_fwd(
    cuda_topk_fwd: Callable[..., Any],
) -> Callable[..., tuple[torch.Tensor, torch.Tensor]]:
    def _topk_fwd(
        x: torch.Tensor,
        k: int,
        softmax: bool = False,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if (
            x.is_cuda
            and x.dtype == torch.bfloat16
            and x.ndim == 2
            and x.is_contiguous()
            and x.size(1) == 64
            and k == 8
            and softmax
        ):
            return cuda_topk_fwd(x, k, softmax=softmax)
        return _topk_torch_fwd(x, k, softmax=softmax)

    return _topk_fwd


@dataclass(frozen=True)
class AttentionRuntime:
    flash_attn_fwd: Callable[..., Any]
    prefix_lm_mask_730: Callable[..., Any]


@dataclass(frozen=True)
class MoeRuntime:
    fp8_quant_cute: Callable[..., Any]
    gelu_residual_cute: Callable[..., Any]
    moe_sum: Callable[..., Any]
    topk_fwd: Callable[..., Any]
    has_cute_moe_config: Callable[..., Any]
    get_cute_moe_block_m: Callable[..., Any]
    get_cute_moe_config: Callable[..., Any]
    invoke_cute_moe_down: Callable[..., Any]
    invoke_cute_moe_down_fp8: Callable[..., Any]
    invoke_cute_moe_up: Callable[..., Any]
    invoke_cute_moe_up_fp8: Callable[..., Any]
    moe_align_block_size: Callable[..., Any]
    moe_lora_align_block_size: Callable[..., Any]
    dtype_to_triton: Callable[..., Any]
    invoke_fused_moe_kernel_triton: Callable[..., Any]
    invoke_fused_moe_kernel_triton_fp8: Callable[..., Any]
    get_triton_moe_config: Callable[..., Any]
    invoke_moe_gemm: Callable[..., Any]
    get_moe_block_m: Callable[..., Any]


@dataclass(frozen=True)
class CacheRuntime:
    reshape_and_cache_flash: Callable[..., Any]


@dataclass(frozen=True)
class RotaryRuntime:
    rotary_embedding: Callable[..., Any]


@dataclass(frozen=True)
class TauRuntime:
    tau_tail_apply_into: Callable[..., Any]


@dataclass(frozen=True)
class VisionRuntime:
    fused_linear_bias_residual_into: Callable[..., Any]


@dataclass(frozen=True)
class LinearRuntime:
    linear: Callable[..., Any]


@dataclass(frozen=True)
class GeluRuntime:
    gelu_cute: Callable[..., Any]


@dataclass(frozen=True)
class DenseRuntime:
    # High-level cross-arch API — handles shape validation, 3D→2D
    # reshape, variant selection, and fallback-to-torch. Each backend
    # (CUDA, MPS, …) supplies its own implementation under the same
    # name. Compare ``RotaryRuntime.rotary_embedding`` /
    # ``TauRuntime.tau_tail_apply_into`` — arch-neutral fields that work
    # cross-arch without ``is_cuda`` gates at the call site.
    fused_mlp_gelu_bias_residual: Callable[..., Any]
    # ``layernorm_bias_into(out, x, weight, bias, eps, *, variant="auto",
    #                       fallback_to_torch=False) -> None``
    layernorm_bias_into: Callable[..., Any]
    # ``layernorm_bias(x, weight, bias, *, eps=1e-5,
    #                  fallback_to_torch=False) -> Tensor``
    layernorm_bias: Callable[..., Any]


@dataclass(frozen=True)
class SamplingRuntime:
    """Sampling entry point published by every backend.

    ``(logits, temperatures, top_p, *, out=None, generator=None)
      -> token_ids[B]``

    CUDA: clamp + softmax + cubin top_p sampler (existing chain).
    MPS:  one fused Metal dispatch — temperature scale + online
          softmax + top-K + top-p truncate + exp-race sample.
    CPU / other: torch reference.
    """

    sample_step_from_logits: Callable[..., Any]


class KernelRuntime:
    """Unified kernel runtime view used by Kestrel."""

    @property
    def attention(self) -> AttentionRuntime:
        # `interface._flash_attn_fwd` is cutlass-free (dispatch goes through
        # shipped cubins). `mask_definitions.cute_prefix_lm_mask_730` is the
        # real cute.jit mask, but importing it requires cutlass — wheel
        # installs without the `jit` dependency-group fall back to a stub
        # callable that carries the same `__cute_hash__`, so dispatch-by-hash
        # still picks the matching cubin variant without ever invoking
        # the mask.
        try:
            from kestrel_kernels.flash_attn.cute.interface import _flash_attn_fwd
        except Exception as exc:
            return AttentionRuntime(
                flash_attn_fwd=_missing_runtime_fn("attention", "flash_attn_fwd", exc),
                prefix_lm_mask_730=_missing_prefix_mask(),
            )

        try:
            from kestrel_kernels.flash_attn.cute.mask_definitions import (
                cute_prefix_lm_mask_730,
            )
        except Exception:
            prefix_lm_mask_730 = _missing_prefix_mask()
        else:
            cute_prefix_lm_mask_730.__cute_hash__ = _PREFIX_LM_730_HASH
            prefix_lm_mask_730 = cute_prefix_lm_mask_730

        return AttentionRuntime(
            flash_attn_fwd=_flash_attn_fwd,
            prefix_lm_mask_730=prefix_lm_mask_730,
        )

    @property
    def moe(self) -> MoeRuntime:
        try:
            from kestrel_kernels.cute_moe import (
                has_cute_moe_config,
                get_cute_moe_block_m,
                get_cute_moe_config,
                invoke_cute_moe_down,
                invoke_cute_moe_down_fp8,
                invoke_cute_moe_up,
                invoke_cute_moe_up_fp8,
            )
            from kestrel_kernels.fp8_quant_cute import fp8_quant_cute
            from kestrel_kernels.gelu_residual import gelu_residual_cute
            from kestrel_kernels.moe_align import (
                moe_align_block_size,
                moe_lora_align_block_size,
            )
            from kestrel_kernels.moe_sum_ops import moe_sum
            from kestrel_kernels.topk import topk_fwd as cuda_topk_fwd
            from kestrel_kernels.moe_triton import (
                dtype_to_triton,
                invoke_fused_moe_kernel,
                invoke_fused_moe_kernel_fp8_w8a8,
            )
            from kestrel_kernels.moe_triton_configs import get_triton_moe_config
            from kestrel_kernels.moe_dispatch import invoke_moe_gemm, get_moe_block_m
        except Exception as exc:
            return MoeRuntime(
                fp8_quant_cute=_missing_runtime_fn("moe", "fp8_quant_cute", exc),
                gelu_residual_cute=_missing_runtime_fn("moe", "gelu_residual_cute", exc),
                moe_sum=_missing_runtime_fn("moe", "moe_sum", exc),
                topk_fwd=_missing_runtime_fn("moe", "topk_fwd", exc),
                has_cute_moe_config=lambda *_args, **_kwargs: False,
                get_cute_moe_block_m=_missing_runtime_fn("moe", "get_cute_moe_block_m", exc),
                get_cute_moe_config=_missing_runtime_fn("moe", "get_cute_moe_config", exc),
                invoke_cute_moe_down=_missing_runtime_fn("moe", "invoke_cute_moe_down", exc),
                invoke_cute_moe_down_fp8=_missing_runtime_fn("moe", "invoke_cute_moe_down_fp8", exc),
                invoke_cute_moe_up=_missing_runtime_fn("moe", "invoke_cute_moe_up", exc),
                invoke_cute_moe_up_fp8=_missing_runtime_fn("moe", "invoke_cute_moe_up_fp8", exc),
                moe_align_block_size=_missing_runtime_fn("moe", "moe_align_block_size", exc),
                moe_lora_align_block_size=_missing_runtime_fn(
                    "moe", "moe_lora_align_block_size", exc
                ),
                dtype_to_triton=_missing_runtime_fn("moe", "dtype_to_triton", exc),
                invoke_fused_moe_kernel_triton=_missing_runtime_fn(
                    "moe", "invoke_fused_moe_kernel_triton", exc
                ),
                invoke_fused_moe_kernel_triton_fp8=_missing_runtime_fn(
                    "moe", "invoke_fused_moe_kernel_triton_fp8", exc
                ),
                get_triton_moe_config=lambda *_a, **_kw: None,
                invoke_moe_gemm=_missing_runtime_fn("moe", "invoke_moe_gemm", exc),
                get_moe_block_m=_missing_runtime_fn("moe", "get_moe_block_m", exc),
            )

        return MoeRuntime(
            fp8_quant_cute=fp8_quant_cute,
            gelu_residual_cute=gelu_residual_cute,
            moe_sum=moe_sum,
            topk_fwd=_moe_topk_fwd(cuda_topk_fwd),
            has_cute_moe_config=has_cute_moe_config,
            get_cute_moe_block_m=get_cute_moe_block_m,
            get_cute_moe_config=get_cute_moe_config,
            invoke_cute_moe_down=invoke_cute_moe_down,
            invoke_cute_moe_down_fp8=invoke_cute_moe_down_fp8,
            invoke_cute_moe_up=invoke_cute_moe_up,
            invoke_cute_moe_up_fp8=invoke_cute_moe_up_fp8,
            moe_align_block_size=moe_align_block_size,
            moe_lora_align_block_size=moe_lora_align_block_size,
            dtype_to_triton=dtype_to_triton,
            invoke_fused_moe_kernel_triton=invoke_fused_moe_kernel,
            invoke_fused_moe_kernel_triton_fp8=invoke_fused_moe_kernel_fp8_w8a8,
            get_triton_moe_config=get_triton_moe_config,
            invoke_moe_gemm=invoke_moe_gemm,
            get_moe_block_m=get_moe_block_m,
        )

    @property
    def cache(self) -> CacheRuntime:
        from kestrel_kernels.kv_cache_write_ops import reshape_and_cache_flash

        return CacheRuntime(reshape_and_cache_flash=reshape_and_cache_flash)

    @property
    def rotary(self) -> RotaryRuntime:
        from kestrel_kernels.rotary_embedding_ops import rotary_embedding

        return RotaryRuntime(rotary_embedding=rotary_embedding)

    @property
    def tau(self) -> TauRuntime:
        from kestrel_kernels.tau_tail_ops import tau_tail_apply_into

        return TauRuntime(tau_tail_apply_into=tau_tail_apply_into)

    @property
    def vision(self) -> VisionRuntime:
        from kestrel_kernels.fused_linear_residual_ops import (
            fused_linear_bias_residual_into,
        )

        return VisionRuntime(
            fused_linear_bias_residual_into=fused_linear_bias_residual_into
        )

    @property
    def linear(self) -> LinearRuntime:
        from kestrel_kernels.linear_ops import linear

        return LinearRuntime(linear=linear)

    @property
    def gelu(self) -> GeluRuntime:
        from kestrel_kernels.gelu_residual import gelu_cute

        return GeluRuntime(gelu_cute=gelu_cute)

    @property
    def dense(self) -> DenseRuntime:
        from kestrel_kernels.fused_mlp_ops import fused_mlp_gelu_bias_residual_cuda
        from kestrel_kernels.layernorm_cuda_ops import (
            layernorm_bias,
            layernorm_bias_into,
        )

        return DenseRuntime(
            fused_mlp_gelu_bias_residual=fused_mlp_gelu_bias_residual_cuda,
            layernorm_bias_into=layernorm_bias_into,
            layernorm_bias=layernorm_bias,
        )

    @property
    def sampling(self) -> SamplingRuntime:
        from kestrel_kernels.sampling import sample_step_from_logits

        return SamplingRuntime(sample_step_from_logits=sample_step_from_logits)

    @property
    def compute_capability(self) -> tuple[int, int]:
        if not torch.cuda.is_available():
            return (0, 0)
        return torch.cuda.get_device_capability()

    @property
    def is_sm90(self) -> bool:
        major, _minor = self.compute_capability
        return major == 9


@lru_cache(maxsize=1)
def get_runtime() -> KernelRuntime:
    if sys.platform == "darwin":
        # Deferred because MPSKernelRuntime's module imports this module —
        # breaking the circular import at function call time.
        from kestrel_kernels.mps.runtime import MPSKernelRuntime

        return MPSKernelRuntime()
    return KernelRuntime()


__all__ = [
    "AttentionRuntime",
    "CacheRuntime",
    "DenseRuntime",
    "GeluRuntime",
    "KernelRuntime",
    "LinearRuntime",
    "MoeRuntime",
    "RotaryRuntime",
    "SamplingRuntime",
    "TauRuntime",
    "VisionRuntime",
    "get_runtime",
]
