"""Host-side dispatch prep for the SM100 tcgen MoE path.

Lives in its own module so the runtime (AOT) dispatch path can import
it without dragging cutlass / cute-dsl into the import graph. The JIT
side (`cute_moe_fp8_sm100_tcgen.py`) re-imports the same symbol so it
stays in lock-step with the kernel's `__call__` argument order.
"""

import torch


def prepare_tcgen_dispatch_tensors(
    kind: str,
    A_fp8_bits,                  # (num_tokens, K) for up; (num_tokens*top_k, K) for down — uint8
    A_scale,                     # fp32, per-token (up) or per-assignment (down)
    B_fp8_bits,                  # (E, N, K) uint8
    B_scale,                     # (E, N) fp32
    C2d,                         # (num_assignments, N) bf16 — flat output view
    *,
    sorted_token_ids,            # (M_padded,) int32 — moe_align output
    expert_ids,                  # (max_blocks,) int32 — moe_align output
    num_tokens_post_padded,      # (1,) int32 — moe_align output
    topk_weights,                # (num_assignments,) bf16 OR None
    mul_routed_weight: bool,
    top_k: int,
    block_m: int,
    num_experts: int,
) -> list:
    """Build the flat tensor list `_FusedMoeMatmulCuTeTcgenFp8.__call__` wants.

    All host-side prep that doesn't fit in a `@cute.jit` kernel:
    - cu_seqlens_m from expert_ids + num_tokens_post_padded (sync-free)
    - A_idx (per-padded-row source index into A's row space)
    - A_routed = A.index_select(0, A_idx)
    - mRowScale = A_scale.gather(0, A_idx) * (topk_weights[A_idx] if down)
    - B permuted (E, N, K) → (N, K, E) for the GEMM's expected layout

    Returned order matches the @cute.jit `__call__` signature exactly.
    """
    is_down = kind == "down"
    num_valid_tokens = int(A_fp8_bits.shape[0]) * top_k
    device = A_fp8_bits.device

    # Sync-free cu_seqlens_m: count expert assignments only at positions
    # < ceil_div(num_tokens_post_padded, block_m). moe_align fills unused
    # slots with 0 (per moe_align/kernel.py:142), so a value-only mask
    # would over-count expert 0.
    eid_long = expert_ids.long()
    max_blocks = expert_ids.shape[0]
    n_used_blocks = (num_tokens_post_padded.long() + block_m - 1) // block_m  # (1,) i64
    arange_blocks = torch.arange(max_blocks, device=device, dtype=torch.int64)
    valid_block_mask = (arange_blocks < n_used_blocks).long()
    counts = torch.zeros(num_experts, dtype=torch.int64, device=device)
    counts.scatter_add_(0, eid_long.clamp_max(num_experts - 1), valid_block_mask)
    # cudagraph-safe: pad a leading zero onto `counts` and cumsum, instead
    # of allocating empty + per-element index assignment. Item-level writes
    # on a graph-captured stream raise cudaErrorStreamCaptureUnsupported.
    zero_pad = counts.new_zeros(1)
    cu_seqlens_m = (
        (torch.cat([zero_pad, counts]) * block_m)
        .cumsum(0)
        .to(torch.int32)
    )

    # A_idx + A_routed + mRowScale, all on device. Clamp both sides:
    # moe_align doesn't initialize the padding slots in `sorted_token_ids`
    # (the buffer is torch.empty), so values there can be any int32 — including
    # negatives, which would slip past clamp_max and turn into OOB indices
    # after // top_k. The kernel's epilogue still skips writes for padded
    # rows via the aid-sentinel check; we just need A_idx in-range so the
    # host-side index_select is safe.
    sti_clamped = sorted_token_ids.clamp(min=0, max=num_valid_tokens - 1).long()
    if is_down:
        A_idx_long = sti_clamped
    else:
        A_idx_long = sti_clamped // top_k
    A_view = A_fp8_bits.view(torch.float8_e4m3fn)
    A_routed = A_view.index_select(0, A_idx_long)
    row_scale = A_scale.gather(0, A_idx_long)
    if mul_routed_weight:
        row_scale = row_scale * topk_weights.gather(0, A_idx_long).to(torch.float32)

    # B permute (E, N, K) → (N, K, E) — view-only, no data movement.
    B_view = B_fp8_bits.view(torch.float8_e4m3fn)
    B_perm = B_view.permute(1, 2, 0)

    mAidPerRow = sorted_token_ids[: A_idx_long.shape[0]]

    # Order matches `_FusedMoeMatmulCuTeTcgenFp8.__call__`:
    #   (A_routed, B_perm, mC, mAidPerRow, mRowScale, mBScale, cu_seqlens_m,
    #    stream, use_pdl) — `_invoke_aot` injects stream + scalar args itself.
    return [A_routed, B_perm, C2d, mAidPerRow, row_scale, B_scale, cu_seqlens_m]
