"""PTX inline-assembly helpers used by the CuTe MoE kernel templates.

This module contains only device-side helpers invoked from inside
@cute.kernel functions (byte packing, FP8→BF16 conversion, WGMMA glue,
streaming stores, etc.). The runtime/loader plumbing that used to live
here is gone — dispatch goes through kestrel_kernels.cubin_runtime now.
"""

import math
from typing import Type

import cutlass
import cutlass.cute as cute
from cutlass.cute.nvgpu import cpasync
from cutlass import Float32, Int32, const_expr
from cutlass.cute.nvgpu import warpgroup

from cutlass.cutlass_dsl import dsl_user_op, T
from cutlass._mlir.dialects import llvm


# =============================================================================
# PTX Inline Assembly Helpers
# =============================================================================


@dsl_user_op
def bitcast_bf16_to_i32(bf16_val, *, loc=None, ip=None) -> Int32:
    """Bitcast a single BF16 value to i32 (zero-extended).

    This is needed because:
    1. Int32(bf16_val) does float-to-int conversion, not bitcast
    2. Our smem holds packed FP8 data in "BF16" slots (16 bits = 2 packed FP8)

    The returned i32 has the 16-bit value in the low bits and zeros in the high bits.
    This works with cvt_fp8x2_lo_to_bf16x2 which extracts only the low 16 bits.
    """
    from cutlass._mlir.dialects import arith

    # Get the IR value (bfloat16 type)
    ir_val = bf16_val.ir_value(loc=loc, ip=ip)
    # Bitcast bfloat16 → i16 (same size, just type change)
    i16_val = llvm.bitcast(T.i16(), ir_val, loc=loc, ip=ip)
    # Zero-extend i16 → i32
    i32_val = arith.extui(T.i32(), i16_val, loc=loc, ip=ip)
    return Int32(i32_val)


@dsl_user_op
def bitcast_f16_to_i32(f16_val, *, loc=None, ip=None) -> Int32:
    """Bitcast a single F16 value to i32 (zero-extended).

    Same as bitcast_bf16_to_i32 but for F16. Both are 16-bit floats.
    The returned i32 has the 16-bit value in the low bits and zeros in the high bits.
    """
    from cutlass._mlir.dialects import arith

    ir_val = f16_val.ir_value(loc=loc, ip=ip)
    i16_val = llvm.bitcast(T.i16(), ir_val, loc=loc, ip=ip)
    i32_val = arith.extui(T.i32(), i16_val, loc=loc, ip=ip)
    return Int32(i32_val)


@dsl_user_op
def pack_b16x2_to_b32(lo: Int32, hi: Int32, *, loc=None, ip=None) -> Int32:
    """Pack two 16-bit values into one 32-bit value.

    Input: lo and hi are 32-bit values where only the low 16 bits are used.
    Output: 32-bit value with {hi[15:0], lo[15:0]}.
    """
    result = llvm.inline_asm(
        T.i32(),
        [Int32(lo).ir_value(loc=loc, ip=ip), Int32(hi).ir_value(loc=loc, ip=ip)],
        """
        {
            .reg .b16 lo16, hi16;
            mov.b32 {lo16, _}, $1;
            mov.b32 {hi16, _}, $2;
            mov.b32 $0, {lo16, hi16};
        }
        """,
        "=r,r,r",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )
    return Int32(result)


@dsl_user_op
def unpack_b32_lo16(packed: Int32, *, loc=None, ip=None) -> Int32:
    """Extract low 16 bits from 32-bit value, zero-extended to 32 bits."""
    result = llvm.inline_asm(
        T.i32(),
        [Int32(packed).ir_value(loc=loc, ip=ip)],
        """
        {
            .reg .b16 lo16, hi16;
            mov.b32 {lo16, hi16}, $1;
            mov.b32 $0, {lo16, 0};
        }
        """,
        "=r,r",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )
    return Int32(result)


@dsl_user_op
def unpack_b32_hi16(packed: Int32, *, loc=None, ip=None) -> Int32:
    """Extract high 16 bits from 32-bit value, zero-extended to 32 bits."""
    result = llvm.inline_asm(
        T.i32(),
        [Int32(packed).ir_value(loc=loc, ip=ip)],
        """
        {
            .reg .b16 lo16, hi16;
            mov.b32 {lo16, hi16}, $1;
            mov.b32 $0, {hi16, 0};
        }
        """,
        "=r,r",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )
    return Int32(result)


@dsl_user_op
def cvt_fp8x2_to_bf16x2(packed_fp8x2: Int32, *, loc=None, ip=None) -> Int32:
    """Convert 2 E4M3 FP8 values (from low 16 bits of 32-bit reg) to 2 packed BF16 values.

    Input: 32-bit register with 2 packed FP8 values in the low 16 bits (high 16 bits ignored)
    Output: 32-bit register containing 2 packed BF16 values

    This is the main conversion function. Use bitcast_bf16_to_i32 to prepare the input.
    Conversion chain: E4M3 → F16 → F32 → BF16
    """
    result = llvm.inline_asm(
        T.i32(),
        [Int32(packed_fp8x2).ir_value(loc=loc, ip=ip)],
        """
        {
            .reg .b16 lo, hi;
            .reg .b32 f16x2;
            .reg .f16 f16_0, f16_1;
            .reg .f32 f32_0, f32_1;
            .reg .b16 bf16_0, bf16_1;

            mov.b32 {lo, hi}, $1;
            cvt.rn.f16x2.e4m3x2 f16x2, lo;
            mov.b32 {f16_0, f16_1}, f16x2;
            cvt.f32.f16 f32_0, f16_0;
            cvt.f32.f16 f32_1, f16_1;
            cvt.rn.bf16.f32 bf16_0, f32_0;
            cvt.rn.bf16.f32 bf16_1, f32_1;
            mov.b32 $0, {bf16_0, bf16_1};
        }
        """,
        "=r,r",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )
    return Int32(result)


@dsl_user_op
def cvt_fp8x2_to_f16x2(packed_fp8x2: Int32, *, loc=None, ip=None) -> Int32:
    """Convert 2 E4M3 FP8 values to 2 packed F16 values (FAST - single PTX instruction).

    Input: 32-bit register with 2 packed FP8 values in the low 16 bits
    Output: 32-bit register containing 2 packed F16 values

    This is much faster than cvt_fp8x2_to_bf16x2 as it's a single instruction.
    """
    result = llvm.inline_asm(
        T.i32(),
        [Int32(packed_fp8x2).ir_value(loc=loc, ip=ip)],
        """
        {
            .reg .b16 lo, hi;
            mov.b32 {lo, hi}, $1;
            cvt.rn.f16x2.e4m3x2 $0, lo;
        }
        """,
        "=r,r",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )
    return Int32(result)


@dsl_user_op
def mma_sync_m16n8k32_row_col_f32_e4m3_e4m3(
    a0: Int32,
    a1: Int32,
    a2: Int32,
    a3: Int32,
    b0: Int32,
    b1: Int32,
    c0: Float32,
    c1: Float32,
    c2: Float32,
    c3: Float32,
    *,
    loc=None,
    ip=None,
):
    """Issue one FP8 tensorcore MMA instruction via inline PTX.

    PTX:
      mma.sync.aligned.m16n8k32.row.col.f32.e4m3.e4m3.f32
    """
    result = llvm.inline_asm(
        llvm.StructType.get_literal([T.f32(), T.f32(), T.f32(), T.f32()]),
        [
            Int32(a0).ir_value(loc=loc, ip=ip),
            Int32(a1).ir_value(loc=loc, ip=ip),
            Int32(a2).ir_value(loc=loc, ip=ip),
            Int32(a3).ir_value(loc=loc, ip=ip),
            Int32(b0).ir_value(loc=loc, ip=ip),
            Int32(b1).ir_value(loc=loc, ip=ip),
            Float32(c0).ir_value(loc=loc, ip=ip),
            Float32(c1).ir_value(loc=loc, ip=ip),
            Float32(c2).ir_value(loc=loc, ip=ip),
            Float32(c3).ir_value(loc=loc, ip=ip),
        ],
        """
        mma.sync.aligned.m16n8k32.row.col.f32.e4m3.e4m3.f32
        {$0, $1, $2, $3}, {$4, $5, $6, $7}, {$8, $9}, {$10, $11, $12, $13};
        """,
        "=f,=f,=f,=f,r,r,r,r,r,r,f,f,f,f",
        has_side_effects=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )
    return (
        Float32(llvm.extractvalue(T.f32(), result, [0], loc=loc, ip=ip)),
        Float32(llvm.extractvalue(T.f32(), result, [1], loc=loc, ip=ip)),
        Float32(llvm.extractvalue(T.f32(), result, [2], loc=loc, ip=ip)),
        Float32(llvm.extractvalue(T.f32(), result, [3], loc=loc, ip=ip)),
    )


@dsl_user_op
def mma_sync_m16n8k32_row_col_f32_e4m3_e4m3_chunk(
    a_regs: list,   # [(a0, a1, a2, a3), ...] length M (MMA_M)
    b_regs: list,   # [(b0, b1), ...] length N (MMA_N)
    c_regs: list,   # M-list of N-list of (c0, c1, c2, c3) — accumulator
    *,
    loc=None,
    ip=None,
):
    """Issue M*N FP8 mma.sync instructions in a single inline_asm block.

    Each `mma.sync.aligned.m16n8k32.row.col.f32.e4m3.e4m3.f32` shares its A
    operand across the N inner iterations and its B operand across the M
    outer iterations, so the asm references each (M*4 + N*2) operand
    register set once. The accumulator (C in / D out) is per-cell.

    Identical SASS to looping `mma_sync_m16n8k32_row_col_f32_e4m3_e4m3`
    M*N times — same `mma.sync` instructions emitted by ptxas — but the
    MLIR IR collapses to one `llvm.inline_asm` op instead of M*N. The
    cute-dsl JIT compile time and peak memory scale with IR size, so for
    big configs (e.g. block_m=128 / num_warps=4 → M=8, N=4 → 32 MMAs per
    K-fragment) this matters by 30×+ for compile, with no runtime cost.

    Operand layout in the merged inline_asm operand list:
      - outputs: 4*M*N f32 (D regs), `=f` constraints
      - inputs: 4*M i32 (A regs, `r`) + 2*N i32 (B regs, `r`) +
                4*M*N f32 (C regs, `f`)
    """
    M = len(a_regs)
    N = len(b_regs)
    assert M >= 1 and N >= 1, "M and N must be positive"
    assert len(c_regs) == M and all(len(row) == N for row in c_regs), \
        "c_regs must be MxN nested"

    # Asm placeholder indices.
    out_base = 0
    a_base = 4 * M * N
    b_base = a_base + 4 * M
    c_base = b_base + 2 * N

    lines = []
    for m in range(M):
        for n in range(N):
            cell = m * N + n
            d = [out_base + cell * 4 + r for r in range(4)]
            a = [a_base + m * 4 + r for r in range(4)]
            b = [b_base + n * 2 + r for r in range(2)]
            c = [c_base + cell * 4 + r for r in range(4)]
            lines.append(
                f"mma.sync.aligned.m16n8k32.row.col.f32.e4m3.e4m3.f32 "
                f"{{${d[0]}, ${d[1]}, ${d[2]}, ${d[3]}}}, "
                f"{{${a[0]}, ${a[1]}, ${a[2]}, ${a[3]}}}, "
                f"{{${b[0]}, ${b[1]}}}, "
                f"{{${c[0]}, ${c[1]}, ${c[2]}, ${c[3]}}};"
            )
    asm = "\n        ".join(lines)

    # Constraints: outputs first, then inputs (matches MLIR LLVM dialect).
    constraints = (
        ",".join(["=f"] * (4 * M * N))
        + ","
        + ",".join(["r"] * (4 * M))           # A as i32
        + ","
        + ",".join(["r"] * (2 * N))           # B as i32
        + ","
        + ",".join(["f"] * (4 * M * N))       # C as f32
    )

    operands = []
    for m in range(M):
        for r in range(4):
            operands.append(Int32(a_regs[m][r]).ir_value(loc=loc, ip=ip))
    for n in range(N):
        for r in range(2):
            operands.append(Int32(b_regs[n][r]).ir_value(loc=loc, ip=ip))
    for m in range(M):
        for n in range(N):
            for r in range(4):
                operands.append(Float32(c_regs[m][n][r]).ir_value(loc=loc, ip=ip))

    result_type = llvm.StructType.get_literal([T.f32()] * (4 * M * N))
    result = llvm.inline_asm(
        result_type,
        operands,
        asm,
        constraints,
        has_side_effects=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )

    out = []
    for m in range(M):
        row = []
        for n in range(N):
            cell = m * N + n
            row.append(tuple(
                Float32(llvm.extractvalue(T.f32(), result, [cell * 4 + r],
                                          loc=loc, ip=ip))
                for r in range(4)
            ))
        out.append(row)
    return out


@dsl_user_op
def cvt_fp8x4_to_f16x4_lo_hi(packed_fp8x4: Int32, *, loc=None, ip=None):
    """Convert 4 E4M3 FP8 values to 4 F16 values, returning lo and hi pairs.

    Input: 32-bit register with 4 packed FP8 values (each FP8 is 8 bits)
    Output: (lo_f16x2, hi_f16x2) - two i32 registers each with 2 packed F16

    This matches Triton's F2FP.F16.E4M3.UNPACK_B + F2FP.F16.E4M3.UNPACK_B.H1 pattern,
    avoiding the PRMT overhead from separate lo/hi extraction.
    """
    result = llvm.inline_asm(
        T.i64(),  # Pack both i32 results into i64
        [Int32(packed_fp8x4).ir_value(loc=loc, ip=ip)],
        """
        {
            .reg .b16 lo_fp8x2, hi_fp8x2;
            .reg .b32 lo_f16x2, hi_f16x2;
            mov.b32 {lo_fp8x2, hi_fp8x2}, $1;
            cvt.rn.f16x2.e4m3x2 lo_f16x2, lo_fp8x2;
            cvt.rn.f16x2.e4m3x2 hi_f16x2, hi_fp8x2;
            mov.b64 $0, {lo_f16x2, hi_f16x2};
        }
        """,
        "=l,r",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )
    return result


@dsl_user_op
def unpack_i64_lo32(packed_i64, *, loc=None, ip=None) -> Int32:
    """Extract low 32 bits from i64."""
    from cutlass._mlir.dialects import arith
    i32_val = arith.trunci(T.i32(), packed_i64, loc=loc, ip=ip)
    return Int32(i32_val)


@dsl_user_op
def unpack_i64_hi32(packed_i64, *, loc=None, ip=None) -> Int32:
    """Extract high 32 bits from i64."""
    from cutlass._mlir.dialects import arith
    shift_amt = arith.constant(T.i64(), 32, loc=loc, ip=ip)
    shifted = arith.shrui(packed_i64, shift_amt, loc=loc, ip=ip)
    i32_val = arith.trunci(T.i32(), shifted, loc=loc, ip=ip)
    return Int32(i32_val)


@dsl_user_op
def i32_to_f16x2(packed_i32: Int32, *, loc=None, ip=None):
    """Bitcast i32 to 2 packed F16 (returns tuple of 2 f16 values for CuTe fragment)."""
    from cutlass._mlir import ir
    from cutlass._mlir.dialects import arith
    ir_val = Int32(packed_i32).ir_value(loc=loc, ip=ip)
    f16_type = ir.F16Type.get()
    vec_type = ir.VectorType.get([2], f16_type)
    vec_f16x2 = llvm.bitcast(vec_type, ir_val, loc=loc, ip=ip)
    idx_0 = arith.constant(T.i32(), 0, loc=loc, ip=ip)
    idx_1 = arith.constant(T.i32(), 1, loc=loc, ip=ip)
    f16_lo = llvm.extractelement(vec_f16x2, idx_0, loc=loc, ip=ip)
    f16_hi = llvm.extractelement(vec_f16x2, idx_1, loc=loc, ip=ip)
    return f16_lo, f16_hi


@dsl_user_op
def cvt_bf16_to_f16(bf16_val, *, loc=None, ip=None):
    """Convert a single BF16 value to F16 (single PTX instruction).

    Input: BF16 value
    Output: F16 value

    Uses cvt.rn.f16.bf16 which is a single instruction on SM90.
    """
    ir_bf16 = bf16_val.ir_value(loc=loc, ip=ip)
    ir_i16 = llvm.bitcast(T.i16(), ir_bf16, loc=loc, ip=ip)

    result_i16 = llvm.inline_asm(
        T.i16(),
        [ir_i16],
        "cvt.rn.f16.bf16 $0, $1;",
        "=h,h",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )

    result_f16 = llvm.bitcast(T.f16(), result_i16, loc=loc, ip=ip)
    return result_f16


@dsl_user_op
def load_bf16x2_as_i32(ptr, *, loc=None, ip=None) -> Int32:
    """Load 2 consecutive BF16 values from gmem as an Int32.

    Input: pointer to gmem (Int64 address)
    Output: Int32 containing {bf16[1], bf16[0]}

    Uses ld.global.b32 for a single 32-bit load.
    """
    result = llvm.inline_asm(
        T.i32(),
        [ptr],
        "ld.global.b32 $0, [$1];",
        "=r,l",
        has_side_effects=True,
        loc=loc,
        ip=ip,
    )
    return Int32(result)


@dsl_user_op
def cvt_bf16x2_to_f16x2(packed_bf16x2: Int32, *, loc=None, ip=None) -> Int32:
    """Convert 2 packed BF16 values to 2 packed F16 values (2 PTX instructions).

    Input: 32-bit register with 2 packed BF16 values {bf16[1], bf16[0]}
    Output: 32-bit register containing 2 packed F16 values {f16[1], f16[0]}
    """
    result = llvm.inline_asm(
        T.i32(),
        [Int32(packed_bf16x2).ir_value(loc=loc, ip=ip)],
        """
        {
            .reg .b16 bf16_0, bf16_1, f16_0, f16_1;
            mov.b32 {bf16_0, bf16_1}, $1;
            cvt.rn.f16.bf16 f16_0, bf16_0;
            cvt.rn.f16.bf16 f16_1, bf16_1;
            mov.b32 $0, {f16_0, f16_1};
        }
        """,
        "=r,r",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )
    return Int32(result)


@dsl_user_op
def store_smem_b32(value: Int32, smem_ptr, *, loc=None, ip=None) -> None:
    """Store 32 bits to shared memory.

    Input: value (Int32), smem_ptr (Int64 address)
    """
    if hasattr(smem_ptr, 'ir_value'):
        ptr_ir = smem_ptr.ir_value(loc=loc, ip=ip)
    else:
        ptr_ir = smem_ptr

    llvm.inline_asm(
        None,
        [ptr_ir, Int32(value).ir_value(loc=loc, ip=ip)],
        "st.shared.b32 [$0], $1;",
        "l,r",
        has_side_effects=True,
        loc=loc,
        ip=ip,
    )


@dsl_user_op
def load_smem_u32(smem_ptr, *, loc=None, ip=None) -> Int32:
    """Load 32 bits from shared memory.

    Input: smem_ptr - Int64 address in shared memory
    Output: Int32 with loaded value
    """
    if hasattr(smem_ptr, 'ir_value'):
        ptr_ir = smem_ptr.ir_value(loc=loc, ip=ip)
    else:
        ptr_ir = smem_ptr

    result = llvm.inline_asm(
        T.i32(),
        [ptr_ir],
        "ld.shared.u32 $0, [$1];",
        "=r,l",
        has_side_effects=True,
        loc=loc,
        ip=ip,
    )
    return Int32(result)


@dsl_user_op
def byte_perm_u32(a: Int32, b: Int32, selector: int, *, loc=None, ip=None) -> Int32:
    """Byte permutation using PTX prmt instruction.

    Selects 4 bytes from the concatenation of b and a (8 bytes total).
    Byte indices: a[0..3] = indices 0..3, b[0..3] = indices 4..7.

    The selector is a 16-bit immediate where each nibble (4 bits) specifies
    which source byte to place in the corresponding result byte position.

    Example: selector=0x5140 produces result[0]=a[0], result[1]=b[0],
             result[2]=a[1], result[3]=b[1]

    Input: a, b - Int32 source values, selector - 16-bit immediate
    Output: Int32 with permuted bytes
    """
    ir_a = Int32(a).ir_value(loc=loc, ip=ip)
    ir_b = Int32(b).ir_value(loc=loc, ip=ip)

    result = llvm.inline_asm(
        T.i32(),
        [ir_a, ir_b],
        f"prmt.b32 $0, $1, $2, {selector};",
        "=r,r,r",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )
    return Int32(result)


@dsl_user_op
def warp_sync(*, loc=None, ip=None) -> None:
    """Synchronize all threads within a warp."""
    llvm.inline_asm(
        None,
        [],
        "bar.warp.sync 0xffffffff;",
        "",
        has_side_effects=True,
        loc=loc,
        ip=ip,
    )


@dsl_user_op
def load_smem_u16(smem_ptr, *, loc=None, ip=None) -> Int32:
    """Load 16 bits from shared memory, zero-extended to 32 bits.

    Input: smem_ptr - Int64 address in shared memory
    Output: Int32 with loaded 16-bit value zero-extended
    """
    # Convert smem_ptr to IR value if it has ir_value method
    if hasattr(smem_ptr, 'ir_value'):
        ptr_ir = smem_ptr.ir_value(loc=loc, ip=ip)
    else:
        ptr_ir = smem_ptr

    result = llvm.inline_asm(
        T.i32(),
        [ptr_ir],
        "ld.shared.u16 $0, [$1];",
        "=r,l",
        has_side_effects=True,
        loc=loc,
        ip=ip,
    )
    return Int32(result)


@dsl_user_op
def store_smem_u16(value: Int32, smem_ptr, *, loc=None, ip=None) -> None:
    """Store low 16 bits to shared memory.

    Input: value - Int32 with value in low 16 bits, smem_ptr - Int64 address
    """
    # Convert smem_ptr to IR value if it has ir_value method
    if hasattr(smem_ptr, 'ir_value'):
        ptr_ir = smem_ptr.ir_value(loc=loc, ip=ip)
    else:
        ptr_ir = smem_ptr

    # Note: with no output, operands are numbered starting at $0
    # $0 = ptr_ir (l = 64-bit), $1 = value (r = 32-bit)
    llvm.inline_asm(
        None,
        [ptr_ir, Int32(value).ir_value(loc=loc, ip=ip)],
        "{ .reg .b16 v16; mov.b32 {v16, _}, $1; st.shared.b16 [$0], v16; }",
        "l,r",
        has_side_effects=True,
        loc=loc,
        ip=ip,
    )


@dsl_user_op
def cvt_fp8x2_to_f16_both(packed_fp8_in_f16, *, loc=None, ip=None):
    """Convert 2 packed FP8 to 2 separate F16 values using LLVM vector extraction.

    Input: F16 value that actually holds 2 packed FP8 values (from ldmatrix on packed smem)
    Output: Tuple of (f16_lo, f16_hi) - both converted F16 values

    Uses LLVM vector<2 x f16> and extractelement to avoid PRMT overhead from trunci/shrui.

    Hardware path (sm_89+). For sm_80/sm_86 use
    :func:`cvt_fp8x2_to_f16_both_software` — Ampere PTX has no
    `cvt.rn.f16x2.e4m3x2`.
    """
    from cutlass._mlir import ir
    from cutlass._mlir.dialects import arith

    # Bitcast f16 → i16 (LLVM inline asm can't handle f16 directly)
    ir_f16 = packed_fp8_in_f16.ir_value(loc=loc, ip=ip)
    ir_i16 = llvm.bitcast(T.i16(), ir_f16, loc=loc, ip=ip)

    # PTX: convert 2 FP8 → 2 F16 packed in 32-bit register
    result_i32 = llvm.inline_asm(
        T.i32(),
        [ir_i16],
        "cvt.rn.f16x2.e4m3x2 $0, $1;",
        "=r,h",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )

    # Bitcast i32 → vector<2 x f16> using MLIR's native VectorType
    f16_type = ir.F16Type.get()
    vec_type = ir.VectorType.get([2], f16_type)
    vec_f16x2 = llvm.bitcast(vec_type, result_i32, loc=loc, ip=ip)

    # Extract elements from vector (result type inferred from vector)
    idx_0 = arith.constant(T.i32(), 0, loc=loc, ip=ip)
    idx_1 = arith.constant(T.i32(), 1, loc=loc, ip=ip)
    f16_lo = llvm.extractelement(vec_f16x2, idx_0, loc=loc, ip=ip)
    f16_hi = llvm.extractelement(vec_f16x2, idx_1, loc=loc, ip=ip)

    return f16_lo, f16_hi


@dsl_user_op
def cvt_fp8x2_to_f16_both_software(packed_fp8_in_f16, *, loc=None, ip=None):
    """Pure-software E4M3 → F16 conversion for pre-sm_89 (sm_80/sm_86).

    Mirrors the contract of :func:`cvt_fp8x2_to_f16_both` (1 F16 holding
    2 packed FP8 bytes → 2 separate F16 values) using only PTX available
    on Ampere. Those archs lack `cvt.rn.f16x2.e4m3x2`.

    Per FP8 byte ``b``:

    * ``sign = (b & 0x80)`` — moves to bit 15.
    * ``mag  = b & 0x7F``.
    * ``f16_body = 0x7E00`` when ``mag == 0x7F`` (E4M3 NaN — quiet F16
      NaN, exp=0x1F, mantissa MSB set).
    * ``f16_body = (mag << 7) + 0x2000`` when ``0 < mag < 0x7F`` —
      f16_exp = e4m3_exp + 8 (bias 15 vs 7), f16_mantissa = e4m3_mantissa
      << 7 (10 mantissa bits vs 3).
    * ``f16_body = 0`` when ``mag == 0`` (±0).
    * ``f16 = sign | f16_body``.

    The formula is exact for FP8 normals (mag ≥ 0x08). For FP8 subnormals
    (mag ∈ [1, 7]) it's approximate — the shifted-mag-plus-bias form
    places them where same-bit-pattern normals would be, overshooting by
    up to ~4.5× on the smallest subnormal (mag=1). Same approximation as
    the bf16 software path in flash_attn/cute/utils.py and accepted there
    for softmax KV — the absolute error caps at ~0.008 which is dominated
    by E4M3 representation noise. ``mag == 0`` and ``mag == 0x7F`` are
    handled exactly via ``selp``.

    Op count: ~20 PTX ops vs ~5 for the sm_89+ hw path.
    """
    from cutlass._mlir import ir
    from cutlass._mlir.dialects import arith

    # Bitcast f16 → i16 → zext to i32 so PRMT (which is .b32) can spread
    # the two FP8 bytes into two halfword lanes.
    ir_f16 = packed_fp8_in_f16.ir_value(loc=loc, ip=ip)
    ir_i16 = llvm.bitcast(T.i16(), ir_f16, loc=loc, ip=ip)
    ir_i32 = arith.extui(T.i32(), ir_i16, loc=loc, ip=ip)

    asm = (
        "{\n"
        ".reg .b32 x, mag, sign, body;\n"
        ".reg .b16 m0, m1, v0, v1;\n"
        ".reg .pred p;\n"
        # Spread bytes 0 and 1 of $1 into halfword-0 and halfword-1 low
        # bytes. PRMT control 0x4140 (lsb-first nibbles): byte0 = src[0],
        # byte1 = src[4] (zero), byte2 = src[1], byte3 = src[4] (zero).
        # Result: 0x00b1_00b0 — each byte sits in bits[7:0] of its half.
        "prmt.b32 x, $1, $1, 0x4140;\n"
        "and.b32  mag, x, 0x007F007F;\n"
        "and.b32  sign, x, 0x00800080;\n"
        # Sign bit moves from bit 7 (per byte) to bit 15 of each half.
        "shl.b32  sign, sign, 8;\n"
        # mag bits[6:0] → bits[13:7] of each half. Add 0x2000 = (8 << 10)
        # to shift the f16 exp by the e4m3→f16 bias delta (15-7).
        "shl.b32  body, mag, 7;\n"
        "add.s32  body, body, 0x20002000;\n"
        # Per-half corrections: mag==0 → 0; mag==0x7F → F16 NaN 0x7E00.
        "mov.b32  {m0, m1}, mag;\n"
        "mov.b32  {v0, v1}, body;\n"
        "setp.eq.u16 p, m0, 0;\n"
        "selp.b16 v0, 0, v0, p;\n"
        "setp.eq.u16 p, m0, 0x7F;\n"
        "selp.b16 v0, 0x7E00, v0, p;\n"
        "setp.eq.u16 p, m1, 0;\n"
        "selp.b16 v1, 0, v1, p;\n"
        "setp.eq.u16 p, m1, 0x7F;\n"
        "selp.b16 v1, 0x7E00, v1, p;\n"
        "mov.b32  body, {v0, v1};\n"
        "or.b32   $0, body, sign;\n"
        "}\n"
    )

    result_i32 = llvm.inline_asm(
        T.i32(),
        [ir_i32],
        asm,
        "=r,r",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )

    f16_type = ir.F16Type.get()
    vec_type = ir.VectorType.get([2], f16_type)
    vec_f16x2 = llvm.bitcast(vec_type, result_i32, loc=loc, ip=ip)
    idx_0 = arith.constant(T.i32(), 0, loc=loc, ip=ip)
    idx_1 = arith.constant(T.i32(), 1, loc=loc, ip=ip)
    f16_lo = llvm.extractelement(vec_f16x2, idx_0, loc=loc, ip=ip)
    f16_hi = llvm.extractelement(vec_f16x2, idx_1, loc=loc, ip=ip)

    return f16_lo, f16_hi


@dsl_user_op
def cvt_fp8x4_to_f16x4_packed(packed_fp8x4: Int32, *, loc=None, ip=None):
    """Convert 4 packed FP8 values to 2 packed F16x2 values (Int32 → two Int32).

    Input: Int32 containing 4 packed E4M3 FP8 values (each 8 bits)
    Output: Tuple of (lo_f16x2, hi_f16x2) - two Int32 values, each containing 2 packed F16

    This avoids all bitcast overhead by working entirely with Int32 registers.
    Uses two F2FP instructions (one for low 2 FP8, one for high 2 FP8).
    """
    ir_i32 = Int32(packed_fp8x4).ir_value(loc=loc, ip=ip)

    # PTX: Split into lo/hi 16-bit halves, convert each to f16x2
    # Low 2 FP8 → 2 F16 packed in Int32
    lo_i32 = llvm.inline_asm(
        T.i32(),
        [ir_i32],
        "{ .reg .b16 lo; mov.b32 {lo, _}, $1; cvt.rn.f16x2.e4m3x2 $0, lo; }",
        "=r,r",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )

    # High 2 FP8 → 2 F16 packed in Int32
    hi_i32 = llvm.inline_asm(
        T.i32(),
        [ir_i32],
        "{ .reg .b16 hi; mov.b32 {_, hi}, $1; cvt.rn.f16x2.e4m3x2 $0, hi; }",
        "=r,r",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )

    return Int32(lo_i32), Int32(hi_i32)


# Keep the separate functions for compatibility but have them call the combined one
@dsl_user_op
def cvt_fp8x2_to_f16_lo(packed_fp8_in_f16, *, loc=None, ip=None):
    """Convert low FP8 from packed pair to F16.

    Note: For best performance, use cvt_fp8x2_to_f16_both to get both values
    with a single conversion instruction.
    """
    from cutlass._mlir.dialects import arith

    ir_f16 = packed_fp8_in_f16.ir_value(loc=loc, ip=ip)
    ir_i16 = llvm.bitcast(T.i16(), ir_f16, loc=loc, ip=ip)

    result_i32 = llvm.inline_asm(
        T.i32(),
        [ir_i16],
        "cvt.rn.f16x2.e4m3x2 $0, $1;",
        "=r,h",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )

    lo_i16 = arith.trunci(T.i16(), result_i32, loc=loc, ip=ip)
    result_f16 = llvm.bitcast(T.f16(), lo_i16, loc=loc, ip=ip)
    return result_f16


@dsl_user_op
def cvt_fp8x2_to_f16_hi(packed_fp8_in_f16, *, loc=None, ip=None):
    """Convert high FP8 from packed pair to F16.

    Note: For best performance, use cvt_fp8x2_to_f16_both to get both values
    with a single conversion instruction.
    """
    from cutlass._mlir.dialects import arith

    ir_f16 = packed_fp8_in_f16.ir_value(loc=loc, ip=ip)
    ir_i16 = llvm.bitcast(T.i16(), ir_f16, loc=loc, ip=ip)

    result_i32 = llvm.inline_asm(
        T.i32(),
        [ir_i16],
        "cvt.rn.f16x2.e4m3x2 $0, $1;",
        "=r,h",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )

    shift_16 = arith.constant(T.i32(), 16, loc=loc, ip=ip)
    shifted = arith.shrui(result_i32, shift_16, loc=loc, ip=ip)
    hi_i16 = arith.trunci(T.i16(), shifted, loc=loc, ip=ip)
    result_f16 = llvm.bitcast(T.f16(), hi_i16, loc=loc, ip=ip)
    return result_f16


@dsl_user_op
def extract_f16_lo(packed_f16x2: Int32, *, loc=None, ip=None):
    """Extract the low F16 from a 32-bit value containing 2 packed F16.

    Input: 32-bit register with {f16_hi, f16_lo}
    Output: Single F16 value (the low one)
    """
    from cutlass._mlir.dialects import arith

    ir_val = Int32(packed_f16x2).ir_value(loc=loc, ip=ip)
    # Truncate to i16 (keeps low 16 bits)
    i16_val = arith.trunci(T.i16(), ir_val, loc=loc, ip=ip)
    # Bitcast i16 → f16
    f16_val = llvm.bitcast(T.f16(), i16_val, loc=loc, ip=ip)
    return f16_val


@dsl_user_op
def extract_f16_hi(packed_f16x2: Int32, *, loc=None, ip=None):
    """Extract the high F16 from a 32-bit value containing 2 packed F16.

    Input: 32-bit register with {f16_hi, f16_lo}
    Output: Single F16 value (the high one)
    """
    from cutlass._mlir.dialects import arith

    ir_val = Int32(packed_f16x2).ir_value(loc=loc, ip=ip)
    # Shift right by 16 to get high 16 bits in low position
    shift_amt = arith.constant(T.i32(), 16, loc=loc, ip=ip)
    shifted = arith.shrui(ir_val, shift_amt, loc=loc, ip=ip)
    # Truncate to i16
    i16_val = arith.trunci(T.i16(), shifted, loc=loc, ip=ip)
    # Bitcast i16 → f16
    f16_val = llvm.bitcast(T.f16(), i16_val, loc=loc, ip=ip)
    return f16_val


@dsl_user_op
def cvt_fp8x2_to_bf16_lo_hi(packed_fp8x2: Int32, *, loc=None, ip=None):
    """Convert 2 FP8 to 2 separate BF16 values (combined operation for speed).

    Input: 32-bit value with 2 packed FP8 in low 16 bits
    Returns: Tuple of (bf16_lo, bf16_hi) as separate 16-bit values in i32 registers

    This combines the conversion and extraction into one PTX block to reduce overhead.
    Returns two i32 values where each has a BF16 in the low 16 bits.
    """
    # Returns (lo, hi) packed as i64, then caller unpacks
    result = llvm.inline_asm(
        T.i64(),
        [Int32(packed_fp8x2).ir_value(loc=loc, ip=ip)],
        """
        {
            .reg .b16 fp8_lo, fp8_hi;
            .reg .b32 f16x2;
            .reg .f16 f16_0, f16_1;
            .reg .f32 f32_0, f32_1;
            .reg .b16 bf16_0, bf16_1;
            .reg .b32 out_lo, out_hi;

            mov.b32 {fp8_lo, fp8_hi}, $1;
            cvt.rn.f16x2.e4m3x2 f16x2, fp8_lo;
            mov.b32 {f16_0, f16_1}, f16x2;
            cvt.f32.f16 f32_0, f16_0;
            cvt.f32.f16 f32_1, f16_1;
            cvt.rn.bf16.f32 bf16_0, f32_0;
            cvt.rn.bf16.f32 bf16_1, f32_1;
            mov.b32 out_lo, {bf16_0, 0};
            mov.b32 out_hi, {bf16_1, 0};
            mov.b64 $0, {out_lo, out_hi};
        }
        """,
        "=l,r",
        has_side_effects=False,
        loc=loc,
        ip=ip,
    )
    return result


@dsl_user_op
def unpack_bf16_pair_lo(packed_i64, *, loc=None, ip=None):
    """Extract the low BF16 from packed i64 result of cvt_fp8x2_to_bf16_lo_hi."""
    from cutlass._mlir.dialects import arith

    ir_val = packed_i64
    # Truncate i64 to i32 (keeps low 32 bits)
    i32_val = arith.trunci(T.i32(), ir_val, loc=loc, ip=ip)
    # Truncate to i16
    i16_val = arith.trunci(T.i16(), i32_val, loc=loc, ip=ip)
    # Bitcast to bf16
    bf16_val = llvm.bitcast(T.bf16(), i16_val, loc=loc, ip=ip)
    return bf16_val


@dsl_user_op
def unpack_bf16_pair_hi(packed_i64, *, loc=None, ip=None):
    """Extract the high BF16 from packed i64 result of cvt_fp8x2_to_bf16_lo_hi."""
    from cutlass._mlir.dialects import arith

    ir_val = packed_i64
    # Shift right by 32 to get high 32 bits
    shift_amt = arith.constant(T.i64(), 32, loc=loc, ip=ip)
    shifted = arith.shrui(ir_val, shift_amt, loc=loc, ip=ip)
    # Truncate to i32
    i32_val = arith.trunci(T.i32(), shifted, loc=loc, ip=ip)
    # Truncate to i16
    i16_val = arith.trunci(T.i16(), i32_val, loc=loc, ip=ip)
    # Bitcast to bf16
    bf16_val = llvm.bitcast(T.bf16(), i16_val, loc=loc, ip=ip)
    return bf16_val


@dsl_user_op
def extract_bf16_lo(packed_bf16x2: Int32, *, loc=None, ip=None):
    """Extract the low BF16 from a 32-bit value containing 2 packed BF16.

    Input: 32-bit register with {bf16_hi, bf16_lo}
    Output: Single BF16 value (the low one)
    """
    from cutlass._mlir.dialects import arith

    ir_val = Int32(packed_bf16x2).ir_value(loc=loc, ip=ip)
    # Truncate to i16 (keeps low 16 bits)
    i16_val = arith.trunci(T.i16(), ir_val, loc=loc, ip=ip)
    # Bitcast i16 → bfloat16
    bf16_val = llvm.bitcast(T.bf16(), i16_val, loc=loc, ip=ip)
    return bf16_val


@dsl_user_op
def extract_bf16_hi(packed_bf16x2: Int32, *, loc=None, ip=None):
    """Extract the high BF16 from a 32-bit value containing 2 packed BF16.

    Input: 32-bit register with {bf16_hi, bf16_lo}
    Output: Single BF16 value (the high one)
    """
    from cutlass._mlir.dialects import arith

    ir_val = Int32(packed_bf16x2).ir_value(loc=loc, ip=ip)
    # Shift right by 16 to get high 16 bits in low position
    shift_amt = arith.constant(T.i32(), 16, loc=loc, ip=ip)
    shifted = arith.shrui(ir_val, shift_amt, loc=loc, ip=ip)
    # Truncate to i16
    i16_val = arith.trunci(T.i16(), shifted, loc=loc, ip=ip)
    # Bitcast i16 → bfloat16
    bf16_val = llvm.bitcast(T.bf16(), i16_val, loc=loc, ip=ip)
    return bf16_val


@dsl_user_op
def store_streaming_b32(value: Int32, gmem_ptr: cute.Pointer, *, loc=None, ip=None) -> None:
    """Store 32 bits (e.g. 2xBF16) with cache streaming hint (st.global.cs).

    Bypasses L1 and marks for early L2 eviction - useful for scattered write-only stores.
    """
    llvm.inline_asm(
        None,
        [gmem_ptr.toint(loc=loc, ip=ip).ir_value(), Int32(value).ir_value(loc=loc, ip=ip)],
        "st.global.cs.b32 [$0], $1;",
        "l,r",
        has_side_effects=True,
        loc=loc,
        ip=ip,
    )


@dsl_user_op
def store_streaming_b128(
    v0: Int32, v1: Int32, v2: Int32, v3: Int32, gmem_ptr: cute.Pointer, *, loc=None, ip=None
) -> None:
    """Store 128 bits (e.g. 8xBF16) with cache streaming hint (st.global.cs.v4.b32).

    Stores 4x32-bit values in a single 128-bit transaction.
    Bypasses L1 and marks for early L2 eviction - useful for scattered write-only stores.
    """
    llvm.inline_asm(
        None,
        [
            gmem_ptr.toint(loc=loc, ip=ip).ir_value(),
            Int32(v0).ir_value(loc=loc, ip=ip),
            Int32(v1).ir_value(loc=loc, ip=ip),
            Int32(v2).ir_value(loc=loc, ip=ip),
            Int32(v3).ir_value(loc=loc, ip=ip),
        ],
        "st.global.cs.v4.b32 [$0], {$1, $2, $3, $4};",
        "l,r,r,r,r",
        has_side_effects=True,
        loc=loc,
        ip=ip,
    )


@dsl_user_op
def shfl_sync_idx_b32(value: Int32, src_lane: Int32, *, loc=None, ip=None) -> Int32:
    """Warp shuffle - read value from src_lane within the warp.

    Uses shfl.sync.idx.b32 with full mask (0xffffffff) for all threads participating.
    The fourth operand 0x1f means width=32 (full warp).
    The fifth operand 0xffffffff is the membership mask (all threads participate).
    """
    result = llvm.inline_asm(
        T.i32(),
        [Int32(value).ir_value(loc=loc, ip=ip), Int32(src_lane).ir_value(loc=loc, ip=ip)],
        "shfl.sync.idx.b32 $0, $1, $2, 0x1f, 0xffffffff;",
        "=r,r,r",
        has_side_effects=True,  # Synchronization point
        loc=loc,
        ip=ip,
    )
    return Int32(result)


def tiled_copy_2d_bypass(
    dtype: Type[cutlass.Numeric], major_mode_size: int, num_threads: int
) -> cute.TiledCopy:
    """Like copy_utils.tiled_copy_2d but with L1 cache bypass for async copies.

    Uses LoadCacheMode.GLOBAL which generates cp.async.cg (bypass L1, cache in L2),
    matching Triton's LDGSTS.E.BYPASS.128 pattern for gathered/scattered access.
    """
    num_copy_bits = math.gcd(major_mode_size, 128 // dtype.width) * dtype.width
    copy_elems = num_copy_bits // dtype.width
    copy_op = cpasync.CopyG2SOp(cache_mode=cpasync.LoadCacheMode.GLOBAL)
    copy_atom = cute.make_copy_atom(copy_op, dtype, num_bits_per_copy=num_copy_bits)
    gmem_threads_per_row = major_mode_size // copy_elems
    assert num_threads % gmem_threads_per_row == 0
    thr_layout = cute.make_ordered_layout(
        (num_threads // gmem_threads_per_row, gmem_threads_per_row),
        order=(1, 0),
    )
    val_layout = cute.make_layout((1, copy_elems))
    return cute.make_tiled_copy_tv(copy_atom, thr_layout, val_layout)


# =============================================================================
# WGMMA Helper
# =============================================================================


@cute.jit
def _wgmma_gemm_no_fence(
    tiled_mma: cute.TiledMma,
    acc: cute.Tensor,
    tCrA: cute.Tensor,
    tCrB: cute.Tensor,
    wg_wait: cutlass.Constexpr[int] = 0,
) -> None:
    warpgroup.fence()
    mma_atom = cute.make_mma_atom(tiled_mma.op)
    mma_atom.set(warpgroup.Field.ACCUMULATE, True)
    for k in cutlass.range_constexpr(cute.size(tCrA.shape[2])):
        cute.gemm(mma_atom, acc, tCrA[None, None, k], tCrB[None, None, k], acc)
    warpgroup.commit_group()
    if const_expr(wg_wait >= 0):
        warpgroup.wait_group(wg_wait)

