"""CuTe MoE kernel dispatch via AOT-emitted host wrappers.

Four public entries (up/down × bf16/fp8). Each variant ships as a
self-contained `.so` that bundles the cute-compiled launch logic — grid
derivation, smem optin, cluster dims, warpgroup register reallocation,
PDL stream serialization. Dispatch resolves the `.so`, builds memref
structs from torch tensors in the wrapper's argument order, and invokes
the exported `ciface` entry.

When `KESTREL_CUTE_JIT=1` is set, missing variants are compiled on
demand (source install only).
"""

# PEP 563: keep annotations as strings so type-only references (e.g.
# `torch.Tensor` in the signatures below) don't get evaluated at import
# time. Lets tests that fake `sys.modules['torch']` with a stub module
# (see tests/test_cubin_bundles_launch_config.py) transitively import
# this file without tripping AttributeError on torch.Tensor.
from __future__ import annotations

import ctypes

import torch

from kestrel_kernels.arch import get_cuda_arch, sm_arch_at_least
from kestrel_kernels.cute_aot_runtime import AotFamily
from kestrel_kernels.cute_moe.config import CuteMoeConfig, MoeVariant, get_cute_moe_config
from kestrel_kernels.fallback import ceil_div, is_cute_jit_enabled


_CUTE_TOP_K_UP_DECODE = 8


def _jit_compile_fn_factory(variant: MoeVariant):
    """Produce a cute `compile_fn(arch)` for a single MoE variant."""
    from scripts.precompile import cubin_bundles as _cubin_bundles
    return _cubin_bundles._compile_cute_moe(variant)


_family = AotFamily(
    "cute_moe",
    jit_compile_fn=_jit_compile_fn_factory if is_cute_jit_enabled() else None,
)


def _variant_for_config(
    kind: str, config: CuteMoeConfig, N: int, K: int, use_pdl: bool,
) -> MoeVariant:
    return MoeVariant(
        kind=kind,
        block_m=config.block_m, block_n=config.block_n, block_k=config.block_k,
        num_warps=config.num_warps, num_stages=config.num_stages,
        N=N, K=K, dtype=config.dtype,
        kernel_type=config.kernel_type, use_pdl=use_pdl,
        cluster_M=config.cluster_M,
    )


def _shrink_routing_for_em_launch(
    config: CuteMoeConfig, top_k: int, num_valid_tokens: int,
    sorted_token_ids: torch.Tensor, expert_ids: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Avoid launching M-blocks that would exit due to routing padding.

    Matches the Triton MoE reference: cap the M-block grid at
    num_valid_tokens * block_m, which is an upper bound on post-padded M.
    """
    em_full = int(sorted_token_ids.numel())
    em_launch = min(em_full, num_valid_tokens * int(config.block_m))
    if em_launch < em_full:
        sorted_token_ids = sorted_token_ids[:em_launch]
        m_blocks = ceil_div(em_launch, int(config.block_m))
        expert_ids = expert_ids[:m_blocks]
    return sorted_token_ids, expert_ids


def _invoke_aot(variant: MoeVariant, tensors: list,
                first_tensor: torch.Tensor) -> None:
    arch = get_cuda_arch()
    bundle = _family.resolve(variant, arch)
    if bundle is None:
        raise RuntimeError(
            f"No cute_moe AOT variant for {variant.variant_key} on arch={arch}. "
            f"Ship a tuned config for this GPU or set KESTREL_CUTE_JIT=1 to "
            f"compile on demand."
        )

    device_index = int(first_tensor.device.index or 0)
    bundle.aot._ensure_device(device_index)

    if len(bundle.memref_specs) != len(tensors):
        raise RuntimeError(
            f"cute_moe/{variant.variant_key}: memref count mismatch "
            f"(wrapper expects {len(bundle.memref_specs)}, got {len(tensors)})"
        )

    structs = [spec.build(t) for t, spec in zip(tensors, bundle.memref_specs)]
    struct_ptrs = [ctypes.pointer(s) for s in structs]
    stream = ctypes.c_void_p(
        torch.cuda.current_stream(first_tensor.device).cuda_stream
    )
    bundle.aot.call(bundle.arg_kinds, struct_ptrs, [], ctypes.pointer(stream))


def _invoke_cute_moe_impl(
    kind: str,
    A: torch.Tensor,
    B: torch.Tensor,
    C: torch.Tensor,
    *,
    topk_weights: torch.Tensor | None,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    mul_routed_weight: bool,
    top_k: int,
    config: CuteMoeConfig,
) -> None:
    if A.dtype != torch.bfloat16:
        raise ValueError(f"CuTe fused MoE supports bfloat16 only (got {A.dtype})")
    if not (A.is_cuda and B.is_cuda and C.is_cuda):
        raise ValueError("A/B/C must be CUDA tensors")
    if A.ndim != 2:
        raise ValueError("A must be 2D")
    if B.ndim != 3:
        raise ValueError("B must be 3D [E, N, K]")
    if C.ndim != 3:
        raise ValueError("C must be 3D [M, top_k, N]")
    if B.stride(-1) != 1 or C.stride(-1) != 1:
        raise ValueError("B and C must be contiguous in their last dimension")
    if B.shape[2] != A.shape[1]:
        raise ValueError("A and B must have the same K dimension")
    if sorted_token_ids.dtype != torch.int32 or expert_ids.dtype != torch.int32:
        raise ValueError("sorted_token_ids and expert_ids must be int32")
    if num_tokens_post_padded.dtype != torch.int32:
        raise ValueError("num_tokens_post_padded must be int32")
    if mul_routed_weight:
        if topk_weights is None:
            raise ValueError("topk_weights is required when mul_routed_weight=True")
    else:
        topk_weights = torch.empty((0,), device=A.device, dtype=A.dtype)

    C2d = C.view(-1, C.shape[-1])
    num_valid_tokens = int(A.shape[0]) * int(top_k)
    sorted_token_ids, expert_ids = _shrink_routing_for_em_launch(
        config, top_k, num_valid_tokens, sorted_token_ids, expert_ids,
    )

    variant = _variant_for_config(
        kind, config, int(B.shape[1]), int(A.shape[1]), use_pdl=False,
    )

    # Memref order matches the kernel class's `__call__` signature:
    # (mA, mB, mC, mTopkWeights, mSortedTokenIds, mExpertIds, mNumTokensPostPadded).
    _invoke_aot(
        variant,
        [A, B, C2d, topk_weights,
         sorted_token_ids, expert_ids, num_tokens_post_padded],
        A,
    )


def _invoke_cute_moe_fp8_impl(
    kind: str,
    A_fp8_bits: torch.Tensor,
    A_scale: torch.Tensor,
    B_fp8_bits: torch.Tensor,
    B_scale: torch.Tensor,
    C: torch.Tensor,
    *,
    topk_weights: torch.Tensor | None,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    mul_routed_weight: bool,
    top_k: int,
    config: CuteMoeConfig,
    use_pdl: bool = False,
) -> None:
    if A_fp8_bits.dtype != torch.uint8:
        raise ValueError(f"Expected FP8 activation bits as uint8 (got {A_fp8_bits.dtype})")
    if B_fp8_bits.dtype != torch.uint8:
        raise ValueError(f"Expected FP8 weight bits as uint8 (got {B_fp8_bits.dtype})")
    if A_scale.dtype not in (torch.float16, torch.float32):
        raise ValueError(f"Expected A_scale float16/float32 (got {A_scale.dtype})")
    if B_scale.dtype not in (torch.float16, torch.float32):
        raise ValueError(f"Expected B_scale float16/float32 (got {B_scale.dtype})")
    if C.dtype != torch.bfloat16:
        raise ValueError(f"CuTe fused MoE FP8 expects bfloat16 C (got {C.dtype})")
    if not (
        A_fp8_bits.is_cuda and A_scale.is_cuda
        and B_fp8_bits.is_cuda and B_scale.is_cuda and C.is_cuda
    ):
        raise ValueError("FP8 inputs must be CUDA tensors")
    if A_fp8_bits.ndim != 2 or A_scale.ndim != 1:
        raise ValueError("A_fp8_bits must be 2D and A_scale must be 1D")
    if B_fp8_bits.ndim != 3 or B_scale.ndim != 2:
        raise ValueError("B_fp8_bits must be 3D [E, N, K] and B_scale 2D [E, N]")
    if C.ndim != 3:
        raise ValueError("C must be 3D [M, top_k, N]")
    if A_fp8_bits.stride(-1) != 1 or B_fp8_bits.stride(-1) != 1 or C.stride(-1) != 1:
        raise ValueError("A_fp8_bits, B_fp8_bits and C must be contiguous in the last dim")
    if A_scale.shape[0] != A_fp8_bits.shape[0]:
        raise ValueError("A_scale must have length matching A_fp8_bits.shape[0]")
    if B_fp8_bits.shape[2] != A_fp8_bits.shape[1]:
        raise ValueError("A_fp8_bits and B_fp8_bits must have the same K dimension")
    if int(A_fp8_bits.shape[1]) % int(config.block_k) != 0:
        raise ValueError("CuTe FP8 kernel requires K divisible by block_k")
    if B_scale.shape[0] != B_fp8_bits.shape[0] or B_scale.shape[1] != B_fp8_bits.shape[1]:
        raise ValueError("B_scale must have shape [E, N] matching B_fp8_bits")
    if B_scale.stride(-1) != 1:
        raise ValueError("B_scale must be contiguous in its last dimension")
    if sorted_token_ids.dtype != torch.int32 or expert_ids.dtype != torch.int32:
        raise ValueError("sorted_token_ids and expert_ids must be int32")
    if num_tokens_post_padded.dtype != torch.int32:
        raise ValueError("num_tokens_post_padded must be int32")
    if mul_routed_weight:
        if topk_weights is None:
            raise ValueError("topk_weights is required when mul_routed_weight=True")
    else:
        topk_weights = torch.empty((0,), device=C.device, dtype=C.dtype)

    arch = get_cuda_arch()

    if config.kernel_type == "wgmma" and not sm_arch_at_least(arch, 90):
        raise ValueError(f"FP8 WGMMA kernels require SM90+ (got arch={arch})")
    if use_pdl and not sm_arch_at_least(arch, 90):
        raise ValueError(f"FP8 PDL kernels require SM90+ (got arch={arch})")

    if A_scale.dtype != torch.float32:
        A_scale = A_scale.to(dtype=torch.float32)
    if B_scale.dtype != torch.float32:
        B_scale = B_scale.to(dtype=torch.float32)

    C2d = C.view(-1, C.shape[-1])
    num_valid_tokens = int(A_fp8_bits.shape[0]) * int(top_k)
    sorted_token_ids, expert_ids = _shrink_routing_for_em_launch(
        config, top_k, num_valid_tokens, sorted_token_ids, expert_ids,
    )

    # tcgen has no PDL variant in the shipped bundle (cubin_bundles arch
    # filter excludes _pdl on sm_100/sm_110), so a caller passing
    # use_pdl=True would build a variant_key with `_pdl` and miss the
    # AOT artifact. Force it off here so the variant_key matches what's
    # shipped.
    if config.kernel_type == "tcgen":
        use_pdl = False

    variant = _variant_for_config(
        kind, config, int(C2d.shape[1]), int(A_fp8_bits.shape[1]), use_pdl=use_pdl,
    )

    if config.kernel_type == "tcgen":
        # SM100 path: pre-permute A, pre-fuse mRowScale, permute B, pre-build
        # cu_seqlens_m on the host so the AOT cubin gets a contiguous-A GEMM
        # with TMA bulk loads instead of cp.async-with-gather. The kernel
        # itself sees a flat tensor list (see cute_moe_fp8_sm100_tcgen.py).
        # NB: import from the runtime-clean module — `cute_moe_fp8_sm100_tcgen`
        # has top-level cutlass/cute imports that aren't shipped runtime deps.
        from kestrel_kernels.cute_moe._tcgen_routing import (
            prepare_tcgen_dispatch_tensors,
        )
        tcgen_tensors = prepare_tcgen_dispatch_tensors(
            kind, A_fp8_bits, A_scale, B_fp8_bits, B_scale, C2d,
            sorted_token_ids=sorted_token_ids,
            expert_ids=expert_ids,
            num_tokens_post_padded=num_tokens_post_padded,
            topk_weights=topk_weights if mul_routed_weight else None,
            mul_routed_weight=mul_routed_weight,
            top_k=top_k,
            block_m=int(config.block_m),
            num_experts=int(B_fp8_bits.shape[0]),
        )
        _invoke_aot(variant, tcgen_tensors, A_fp8_bits)
        return

    # Memref order matches the fp8 kernel's `__call__` signature:
    # (mAbits, mAScale, mBbits, mBScale, mC, mTopkWeights, mSortedTokenIds,
    # mExpertIds, mNumTokensPostPadded).
    _invoke_aot(
        variant,
        [A_fp8_bits, A_scale, B_fp8_bits, B_scale, C2d, topk_weights,
         sorted_token_ids, expert_ids, num_tokens_post_padded],
        A_fp8_bits,
    )


def invoke_cute_moe_up(
    A: torch.Tensor,
    B: torch.Tensor,
    C: torch.Tensor,
    *,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    config: CuteMoeConfig | None = None,
) -> None:
    """CuTe fused MoE up-projection (no routed-weight scaling)."""
    if config is None:
        config = get_cute_moe_config(
            "up", A.shape[0],
            num_experts=B.shape[0],
            hidden_size=A.shape[1],
            intermediate_size=B.shape[1] // 2,
        )
    _invoke_cute_moe_impl(
        "up", A, B, C,
        topk_weights=None,
        sorted_token_ids=sorted_token_ids,
        expert_ids=expert_ids,
        num_tokens_post_padded=num_tokens_post_padded,
        mul_routed_weight=False,
        top_k=_CUTE_TOP_K_UP_DECODE,
        config=config,
    )


def invoke_cute_moe_down(
    A: torch.Tensor,
    B: torch.Tensor,
    C: torch.Tensor,
    *,
    topk_weights: torch.Tensor,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    config: CuteMoeConfig | None = None,
) -> None:
    """CuTe fused MoE down-projection (includes routed-weight scaling)."""
    if config is None:
        config = get_cute_moe_config(
            "down", C.shape[0],
            num_experts=B.shape[0],
            hidden_size=B.shape[1],
            intermediate_size=B.shape[2],
        )
    _invoke_cute_moe_impl(
        "down", A, B, C,
        topk_weights=topk_weights,
        sorted_token_ids=sorted_token_ids,
        expert_ids=expert_ids,
        num_tokens_post_padded=num_tokens_post_padded,
        mul_routed_weight=True,
        top_k=1,
        config=config,
    )


def invoke_cute_moe_up_fp8(
    A_fp8_bits: torch.Tensor,
    A_scale: torch.Tensor,
    B_fp8_bits: torch.Tensor,
    B_scale: torch.Tensor,
    C: torch.Tensor,
    *,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    config: CuteMoeConfig | None = None,
    use_pdl: bool = False,
) -> None:
    """CuTe fused MoE up-projection with FP8 activations + weights (W8A8).

    `use_pdl=True` enables Programmatic Dependent Launch — the kernel
    waits via `griddepcontrol_wait()` before loading A tiles, allowing
    overlap with a preceding producer (e.g., FP8 quantization). SM90+ only.
    """
    if config is None:
        config = get_cute_moe_config(
            "up", A_fp8_bits.shape[0],
            num_experts=B_fp8_bits.shape[0],
            hidden_size=A_fp8_bits.shape[1],
            intermediate_size=B_fp8_bits.shape[1] // 2,
            dtype="fp8",
        )
    _invoke_cute_moe_fp8_impl(
        "up", A_fp8_bits, A_scale, B_fp8_bits, B_scale, C,
        topk_weights=None,
        sorted_token_ids=sorted_token_ids,
        expert_ids=expert_ids,
        num_tokens_post_padded=num_tokens_post_padded,
        mul_routed_weight=False,
        top_k=_CUTE_TOP_K_UP_DECODE,
        config=config,
        use_pdl=use_pdl,
    )


def invoke_cute_moe_down_fp8(
    A_fp8_bits: torch.Tensor,
    A_scale: torch.Tensor,
    B_fp8_bits: torch.Tensor,
    B_scale: torch.Tensor,
    C: torch.Tensor,
    *,
    topk_weights: torch.Tensor,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_padded: torch.Tensor,
    config: CuteMoeConfig | None = None,
    use_pdl: bool = False,
) -> None:
    """CuTe fused MoE down-projection with FP8 activations + weights."""
    if config is None:
        config = get_cute_moe_config(
            "down", C.shape[0],
            num_experts=B_fp8_bits.shape[0],
            hidden_size=B_fp8_bits.shape[1],
            intermediate_size=B_fp8_bits.shape[2],
            dtype="fp8",
        )
    _invoke_cute_moe_fp8_impl(
        "down", A_fp8_bits, A_scale, B_fp8_bits, B_scale, C,
        topk_weights=topk_weights,
        sorted_token_ids=sorted_token_ids,
        expert_ids=expert_ids,
        num_tokens_post_padded=num_tokens_post_padded,
        mul_routed_weight=True,
        top_k=1,
        config=config,
        use_pdl=use_pdl,
    )
