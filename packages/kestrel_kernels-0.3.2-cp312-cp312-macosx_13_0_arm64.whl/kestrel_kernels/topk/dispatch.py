"""TopK dispatch — resolves on first call, then direct function pointer."""


import torch

from kestrel_kernels.cubin_runtime import CubinFamily
from kestrel_kernels.fallback import ceil_div, warn_fallback_once

_family = CubinFamily("topk_bfloat16_n64_k8_softmax")


def _topk_torch_fallback(
    x: torch.Tensor, k: int, values: torch.Tensor, indices: torch.Tensor
) -> None:
    """Reference path used when no cubin is shipped for the current arch."""
    raw_values, raw_indices = torch.topk(x, k=k, dim=-1)
    values.copy_(torch.softmax(raw_values.float(), dim=-1).to(x.dtype))
    indices.copy_(raw_indices.to(torch.int32))


def topk_fwd(x: torch.Tensor, k: int, softmax: bool = False):
    if not (
        x.is_cuda
        and x.dtype == torch.bfloat16
        and x.ndim == 2
        and x.is_contiguous()
        and x.size(1) == 64
        and k == 8
        and softmax
    ):
        raise ValueError(
            f"topk_fwd only supports bfloat16 contiguous CUDA tensors with "
            f"shape (M, 64), k=8, softmax=True; got dtype={x.dtype}, "
            f"shape={tuple(x.shape)}, k={k}, softmax={softmax}"
        )

    M = x.size(0)
    values = torch.empty((M, k), dtype=x.dtype, device=x.device)
    indices = torch.empty((M, k), dtype=torch.int32, device=x.device)

    if not _family.is_available():
        warn_fallback_once(
            "topk_fwd_no_cubin",
            "kestrel-kernels: no topk cubin bundle for the current CUDA "
            "architecture; using PyTorch fallback.",
        )
        _topk_torch_fallback(x, k, values, indices)
        return values, indices

    _family.resolve_dispatch(x, grid_x=ceil_div(M, 128))(x, values, indices)
    return values, indices


__all__ = ["topk_fwd"]
