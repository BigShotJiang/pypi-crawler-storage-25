"""Fused MLP dispatch — direct call into _pybridge."""


import torch

from kestrel_kernels._pybridge import fused_mlp_gelu_bias_residual as _raw


def fused_mlp_gelu_bias_residual_cuda(out, hidden, x, w1, b1, w2, b2, residual):
    dtype_code = 0 if x.dtype == torch.bfloat16 else 1
    _raw(out, hidden, x, w1, b1, w2, b2, residual, dtype_code)
