"""Layernorm — CUDA backend. Raw kernel callables + the high-level
``layernorm_bias_into`` / ``layernorm_bias`` API exposed via
``DenseRuntime``."""


import torch
import torch.nn.functional as F

from kestrel_kernels._pybridge import layernorm_bias_cuda as _raw


def _check(x):
    if x.dtype != torch.bfloat16:
        raise RuntimeError("x must be bf16")
    if x.size(-1) % 8 != 0:
        # The kernel uses 8-element vector loads; non-multiples of 8 produce
        # misaligned address errors. Callers should fall back to torch.
        raise RuntimeError(f"x last dim must be a multiple of 8, got {x.size(-1)}")


def layernorm_bias_cuda(out, x, weight, bias, eps):
    _check(x)
    _raw(out, x, weight, bias, eps, 0)


def layernorm_bias_reload_cuda(out, x, weight, bias, eps):
    _check(x)
    _raw(out, x, weight, bias, eps, 1)


def layernorm_bias_into(
    out: torch.Tensor,
    x: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor,
    eps: float = 1e-5,
    *,
    variant: str = "auto",
    fallback_to_torch: bool = False,
) -> None:
    """LayerNorm forward: ``out = (x - mean) / sqrt(var + eps) * weight + bias``.

    - ``x`` may be 2D ``(M, N)`` or 3D ``(B, T, N)``; ``weight`` / ``bias``
      are 1-D ``(N,)``.
    - ``variant`` chooses an epilogue strategy on CUDA — ``"default"``
      caches x in registers (fewer reads, more reg pressure);
      ``"reload_x"`` reloads x in the output pass (more reads, lower reg
      pressure). ``"auto"`` picks ``"reload_x"`` for the SigLIP-vision
      width (N=1152) and ``"default"`` otherwise.
    - If ``fallback_to_torch=True``, unsupported inputs (e.g. fp16
      query, non-mul-of-8 last dim) silently fall back to
      ``F.layer_norm`` instead of raising.
    """
    if x.ndim not in (2, 3):
        raise ValueError(f"x must be 2D or 3D, got {tuple(x.shape)}")
    if out.shape != x.shape:
        raise ValueError(f"out must match x shape {tuple(x.shape)}, got {tuple(out.shape)}")
    if weight.ndim != 1 or bias.ndim != 1:
        raise ValueError("weight and bias must be 1D")
    if x.shape[-1] != weight.shape[0] or weight.shape != bias.shape:
        raise ValueError("weight/bias must match x last dimension")

    if x.ndim == 3:
        b, t, n = x.shape
        x2 = x.reshape(b * t, n)
        # ``out.view(...)`` (not ``reshape``) so a non-contiguous output
        # raises rather than allocating a temporary that the kernel
        # writes to while the caller's tensor stays unchanged.
        out2 = out.view(b * t, n)
    else:
        x2 = x
        out2 = out

    # Resolve + validate variant *outside* the try/except so a typo
    # ("defualt") raises ``ValueError`` instead of being swallowed by
    # ``fallback_to_torch``.
    if variant == "auto":
        variant = "reload_x" if int(x2.shape[1]) == 1152 else "default"
    if variant not in ("default", "reload_x"):
        raise ValueError(f"Unknown layernorm variant: {variant!r}")

    try:
        if variant == "default":
            layernorm_bias_cuda(out2, x2, weight, bias, float(eps))
        else:  # variant == "reload_x"
            layernorm_bias_reload_cuda(out2, x2, weight, bias, float(eps))
    except Exception:
        if not fallback_to_torch:
            raise
        out2.copy_(F.layer_norm(x2, (x2.shape[1],), weight, bias, float(eps)))


def layernorm_bias(
    x: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor,
    *,
    eps: float = 1e-5,
    fallback_to_torch: bool = False,
) -> torch.Tensor:
    out = torch.empty_like(x)
    layernorm_bias_into(
        out, x, weight, bias, eps,
        fallback_to_torch=fallback_to_torch,
    )
    return out
