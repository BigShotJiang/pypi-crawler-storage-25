"""Rotary embedding dispatch API."""

from kestrel_kernels.rotary_embedding_ops.dispatch import rotary_embedding

__all__ = ["rotary_embedding"]
