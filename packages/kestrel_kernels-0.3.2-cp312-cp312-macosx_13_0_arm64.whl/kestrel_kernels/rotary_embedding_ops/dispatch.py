"""Rotary embedding dispatch — direct call into _pybridge."""


from kestrel_kernels._pybridge import rotary_embedding as _raw
from kestrel_kernels.fallback import should_use_cuda_impl
from kestrel_kernels.rotary_embedding_ops.fallback import rotary_embedding_torch

_SUPPORTED_SMS = {80, 86, 87, 89, 90, 100, 110, 120}


def rotary_embedding(positions, query, key, head_size, cos_sin_cache):
    if not should_use_cuda_impl(
        device=query.device,
        kernel_key="rotary_embedding",
        op_name="rotary_embedding",
        supported_sms=_SUPPORTED_SMS,
    ):
        rotary_embedding_torch(positions, query, key, head_size, cos_sin_cache)
        return
    _raw(positions, query, key, head_size, cos_sin_cache)


__all__ = ["rotary_embedding"]
