
import torch


def _apply_rotary_inplace(
    x: torch.Tensor,
    *,
    cos: torch.Tensor,
    sin: torch.Tensor,
    embed_dim: int,
) -> None:
    x0 = x[..., :embed_dim].to(torch.float32)
    x1 = x[..., embed_dim : 2 * embed_dim].to(torch.float32)
    out0 = (x0 * cos - x1 * sin).to(dtype=x.dtype)
    out1 = (x1 * cos + x0 * sin).to(dtype=x.dtype)
    x[..., :embed_dim] = out0
    x[..., embed_dim : 2 * embed_dim] = out1


def rotary_embedding_torch(
    positions: torch.Tensor,
    query: torch.Tensor,
    key: torch.Tensor,
    head_size: int,
    cos_sin_cache: torch.Tensor,
) -> None:
    if positions.device != query.device:
        raise ValueError("positions must be on the same device as query/key")
    if query.device != key.device:
        raise ValueError("query and key must be on the same device")
    if query.dtype != key.dtype:
        raise ValueError("query and key must have matching dtype")
    if cos_sin_cache.dtype != torch.float32:
        raise ValueError("cos_sin_cache must be float32")

    rot_dim = int(cos_sin_cache.shape[-1])
    if rot_dim % 2 != 0:
        raise ValueError("cos_sin_cache last dimension must be even")
    embed_dim = rot_dim // 2
    if head_size < 2 * embed_dim:
        raise ValueError("head_size must be at least cos/sin rotary dimension")

    flat_pos = positions.reshape(-1).to(torch.long)
    cache = cos_sin_cache.index_select(0, flat_pos).view(*positions.shape, rot_dim)
    cos = cache[..., :embed_dim].unsqueeze(-2)
    sin = cache[..., embed_dim:].unsqueeze(-2)

    _apply_rotary_inplace(query, cos=cos, sin=sin, embed_dim=embed_dim)
    _apply_rotary_inplace(key, cos=cos, sin=sin, embed_dim=embed_dim)


__all__ = ["rotary_embedding_torch"]
