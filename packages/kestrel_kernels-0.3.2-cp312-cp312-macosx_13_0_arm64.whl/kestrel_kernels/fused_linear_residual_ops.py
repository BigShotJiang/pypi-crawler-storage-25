"""Fused linear+bias+residual dispatch — direct call into _pybridge."""


import torch

from kestrel_kernels._pybridge import fused_linear_bias_residual as _raw


def fused_linear_bias_residual_into(*, x, w, b, residual, out):
    if x.ndim == 3:
        bsz, t, c = x.shape
        x = x.reshape(bsz * t, c)
        residual = residual.reshape(bsz * t, residual.shape[-1])
        out = out.reshape(bsz * t, out.shape[-1])
    dtype_code = 0 if x.dtype == torch.bfloat16 else 1
    _raw(out, x, w, b, residual, dtype_code)


__all__ = ["fused_linear_bias_residual_into"]
