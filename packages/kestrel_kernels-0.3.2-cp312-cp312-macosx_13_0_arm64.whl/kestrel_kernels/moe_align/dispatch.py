"""MoE align block size dispatch via the cubin bundle runtime.

Six cubin variants per (dtype, topk, num_experts, block_size) tuple:
  small                  - single-CTA shared-memory path (one launch)
  large_align + scatter  - two-kernel multi-CTA path
  lora_small             - single-CTA LoRA path
  lora_large_align + scatter  - two-kernel multi-CTA LoRA path (scatter 2D)

Small vs large is picked by the same heuristic the CUDA extension uses:
small_batch_expert_mode = (num_experts <= 64) and (T*K < 1024).

When KESTREL_CUTE_JIT=1 is set (dev autotuning only), missing variants
are compiled on demand via `cute.compile()` and registered with the cubin
family so subsequent calls dispatch normally. This lets
`scripts/grid_search_cute_moe.py` benchmark arbitrary block sizes without
shipping every candidate in the bundle.
"""


import torch

from kestrel_kernels.cubin_runtime import CubinFamily
from kestrel_kernels.fallback import ceil_div, is_cute_jit_enabled, warn_and_run_fallback
from kestrel_kernels.moe_align.fallback import (
    moe_align_block_size_torch_into,
    moe_lora_align_block_size_torch_into,
)

_family = CubinFamily("moe_align")

_SMALL_BATCH_EXPERT_LIMIT = 64
_SMALL_BATCH_NUMEL_LIMIT = 1024
_LARGE_SCATTER_THREADS = 256

_CUMSUM_BUFFER_CACHE: dict = {}
_LORA_STRIDE_CACHE: dict = {}

_ENABLE_JIT = is_cute_jit_enabled()
if _ENABLE_JIT:
    # Eagerly import cubin_bundles so its module-level CuTe DSL env-var
    # setup (KEEP_CUBIN/PTX/DUMP_DIR) runs before any other module pulls
    # in cutlass. The compile helpers we call later need those env vars
    # to have been set at cutlass import time.
    from scripts.precompile import cubin_bundles as _cubin_bundles


def _tag(topk_ids: torch.Tensor, topk: int, num_experts: int, block_size: int) -> str:
    """Variant-key suffix shared by all phases at one (dtype, topk, e, bs) tuple."""
    dtype_name = "i32" if topk_ids.dtype == torch.int32 else "i64"
    return f"{dtype_name}_k{topk}_e{num_experts}_b{block_size}"


def _cumsum_buffer(device: torch.device, num_experts: int, max_loras: int = 1) -> torch.Tensor:
    """Per-stream scratch buffer reused across calls on the hot path.

    For LoRA large path the buffer is sized for all loras at once to avoid
    races between per-lora blocks. If a caller captures a CUDA graph with a
    given max_loras, subsequent calls with a larger max_loras will raise
    rather than silently under-allocate — re-allocation inside the graph
    would be a silent correctness break.
    """
    dev_idx = int(device.index or 0)
    stream_id = int(torch.cuda.current_stream(device).cuda_stream)
    key = (dev_idx, stream_id, int(num_experts), int(max_loras))
    buf = _CUMSUM_BUFFER_CACHE.get(key)
    required = int(num_experts) * int(max_loras)
    if buf is None:
        buf = torch.empty((required,), device=device, dtype=torch.int32)
        _CUMSUM_BUFFER_CACHE[key] = buf
    elif buf.numel() < required:
        raise RuntimeError(
            f"moe_align cumsum buffer overflow: need {required} elements, "
            f"have {buf.numel()}. Pre-allocate for the expected max_loras "
            f"before CUDA graph capture."
        )
    return buf


def _lora_strides(
    device: torch.device, max_tokens_padded: int, max_blocks: int
) -> tuple[torch.Tensor, torch.Tensor]:
    """Cache the [1]-int32 stride tensors the LoRA kernels take as arguments."""
    key = (int(device.index or 0), int(max_tokens_padded), int(max_blocks))
    tensors = _LORA_STRIDE_CACHE.get(key)
    if tensors is None:
        tensors = (
            torch.tensor([max_tokens_padded], device=device, dtype=torch.int32),
            torch.tensor([max_blocks], device=device, dtype=torch.int32),
        )
        _LORA_STRIDE_CACHE[key] = tensors
    return tensors


def _run_torch_fallback(fallback_fn, kernel_key: str, **kwargs) -> None:
    from kestrel_kernels.arch import get_cuda_arch
    warn_and_run_fallback(
        kernel_key=kernel_key,
        message=(
            f"kestrel-kernels: falling back to PyTorch for {kernel_key} "
            f"(no cubin bundle for arch={get_cuda_arch()})."
        ),
        fallback=fallback_fn,
        kwargs=kwargs,
    )


def _jit_ensure_variant(
    variant_key: str, phase: str, topk_ids: torch.Tensor,
    num_experts: int, block_size: int,
) -> None:
    """JIT-compile a moe_align variant on demand and install it on _family.

    Only invoked under KESTREL_CUTE_JIT=1 (dev autotuning). Requires a
    source install where `scripts/precompile.cubin_bundles` is importable.
    """
    device_index = int(topk_ids.device.index or 0)
    if (variant_key, device_index) in _family._handles:
        return

    from cutlass import Int32, Int64
    topk_dtype = Int32 if topk_ids.dtype == torch.int32 else Int64
    topk = int(topk_ids.shape[1])
    spec = _cubin_bundles._MOE_ALIGN_PHASES[phase]
    _cubin_bundles.jit_compile_and_install(
        family=_family,
        variant_key=variant_key,
        compile_fn=_cubin_bundles._compile_moe_align(
            phase, topk_dtype, topk, num_experts, block_size,
        ),
        block_x=spec["block"][0],
        device_index=device_index,
    )


def _ensure_variants_or_fallback(
    variant_keys: tuple[tuple[str, str], ...],
    topk_ids: torch.Tensor,
    num_experts: int,
    block_size: int,
) -> bool:
    """Check that every (phase, variant_key) is available; JIT-install if needed.

    Returns True if all variants are ready to dispatch, False if any is
    missing and cannot be JIT-compiled (caller should run the torch fallback).
    """
    for phase, key in variant_keys:
        if _family.is_available(key):
            continue
        if _ENABLE_JIT:
            _jit_ensure_variant(key, phase, topk_ids, num_experts, block_size)
            continue
        return False
    return True


def moe_align_block_size(
    topk_ids: torch.Tensor,
    num_experts: int,
    block_size: int,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_pad: torch.Tensor,
) -> None:
    """CuTe DSL moe_align_block_size (CUDA-only)."""
    if topk_ids.device.type != "cuda":
        raise ValueError("topk_ids must be a CUDA tensor")
    if not topk_ids.is_contiguous() or topk_ids.ndim != 2:
        raise ValueError("topk_ids must be a contiguous 2D tensor [num_tokens, top_k]")
    if topk_ids.dtype not in (torch.int32, torch.int64):
        raise ValueError("topk_ids must be int32 or int64")
    if (
        sorted_token_ids.dtype != torch.int32
        or sorted_token_ids.ndim != 1
        or not sorted_token_ids.is_contiguous()
    ):
        raise ValueError("sorted_token_ids must be a contiguous int32 1D tensor")
    if (
        expert_ids.dtype != torch.int32
        or expert_ids.ndim != 1
        or not expert_ids.is_contiguous()
    ):
        raise ValueError("expert_ids must be a contiguous int32 1D tensor")
    if (
        num_tokens_post_pad.dtype != torch.int32
        or num_tokens_post_pad.ndim != 1
        or num_tokens_post_pad.numel() != 1
        or not num_tokens_post_pad.is_contiguous()
    ):
        raise ValueError("num_tokens_post_pad must be contiguous int32 with shape (1,)")

    topk = int(topk_ids.shape[1])
    numel = int(topk_ids.numel())
    tag = _tag(topk_ids, topk, int(num_experts), int(block_size))
    small = (int(num_experts) <= _SMALL_BATCH_EXPERT_LIMIT) and (numel < _SMALL_BATCH_NUMEL_LIMIT)

    needed_keys = (
        (("small", f"small_{tag}"),) if small
        else (("large_align", f"large_align_{tag}"), ("large_scatter", f"large_scatter_{tag}"))
    )
    if not _ensure_variants_or_fallback(needed_keys, topk_ids, int(num_experts), int(block_size)):
        _run_torch_fallback(
            moe_align_block_size_torch_into,
            "moe_align_block_size",
            topk_ids=topk_ids,
            num_experts=num_experts,
            block_size=block_size,
            sorted_token_ids=sorted_token_ids,
            expert_ids=expert_ids,
            num_tokens_post_pad=num_tokens_post_pad,
        )
        return

    if small:
        _family.resolve_dispatch(topk_ids, variant_key=f"small_{tag}", grid_x=1)(
            topk_ids, sorted_token_ids, expert_ids, num_tokens_post_pad,
        )
        return

    cumsum = _cumsum_buffer(topk_ids.device, int(num_experts))
    _family.resolve_dispatch(topk_ids, variant_key=f"large_align_{tag}", grid_x=2)(
        topk_ids, sorted_token_ids, expert_ids, num_tokens_post_pad, cumsum,
    )
    if numel > 0:
        grid_x = ceil_div(numel, _LARGE_SCATTER_THREADS)
        _family.resolve_dispatch(topk_ids, variant_key=f"large_scatter_{tag}", grid_x=grid_x)(
            topk_ids, sorted_token_ids, cumsum,
        )


def moe_lora_align_block_size(
    topk_ids: torch.Tensor,
    token_lora_mapping: torch.Tensor,
    num_experts: int,
    block_size: int,
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_pad: torch.Tensor,
) -> None:
    """CuTe DSL moe_lora_align_block_size (CUDA-only)."""
    if topk_ids.device.type != "cuda":
        raise ValueError("topk_ids must be a CUDA tensor")
    if not topk_ids.is_contiguous() or topk_ids.ndim != 2:
        raise ValueError("topk_ids must be a contiguous 2D tensor [num_tokens, top_k]")
    if topk_ids.dtype not in (torch.int32, torch.int64):
        raise ValueError("topk_ids must be int32 or int64")
    if token_lora_mapping.device != topk_ids.device:
        raise ValueError("token_lora_mapping must be on the same device as topk_ids")
    if (
        token_lora_mapping.dtype != torch.int32
        or token_lora_mapping.ndim != 1
        or token_lora_mapping.shape[0] != topk_ids.shape[0]
        or not token_lora_mapping.is_contiguous()
    ):
        raise ValueError("token_lora_mapping must be a contiguous int32 1D tensor of length num_tokens")
    if sorted_token_ids.dtype != torch.int32 or sorted_token_ids.ndim != 2 or not sorted_token_ids.is_contiguous():
        raise ValueError("sorted_token_ids must be a contiguous int32 2D tensor")
    if expert_ids.dtype != torch.int32 or expert_ids.ndim != 2 or not expert_ids.is_contiguous():
        raise ValueError("expert_ids must be a contiguous int32 2D tensor")
    if num_tokens_post_pad.dtype != torch.int32 or num_tokens_post_pad.ndim != 1 or not num_tokens_post_pad.is_contiguous():
        raise ValueError("num_tokens_post_pad must be a contiguous int32 1D tensor")

    max_loras = int(sorted_token_ids.shape[0])
    if expert_ids.shape[0] != max_loras or num_tokens_post_pad.shape[0] != max_loras:
        raise ValueError("expert_ids and num_tokens_post_pad must have leading dim == max_loras")

    topk = int(topk_ids.shape[1])
    numel = int(topk_ids.numel())
    tag = _tag(topk_ids, topk, int(num_experts), int(block_size))
    small = (int(num_experts) <= _SMALL_BATCH_EXPERT_LIMIT) and (numel < _SMALL_BATCH_NUMEL_LIMIT)

    num_tokens_post_pad.zero_()

    needed_keys = (
        (("lora_small", f"lora_small_{tag}"),) if small
        else (
            ("lora_large_align", f"lora_large_align_{tag}"),
            ("lora_large_scatter", f"lora_large_scatter_{tag}"),
        )
    )
    if not _ensure_variants_or_fallback(needed_keys, topk_ids, int(num_experts), int(block_size)):
        _run_torch_fallback(
            moe_lora_align_block_size_torch_into,
            "moe_lora_align_block_size",
            topk_ids=topk_ids,
            token_lora_mapping=token_lora_mapping,
            num_experts=num_experts,
            block_size=block_size,
            sorted_token_ids=sorted_token_ids,
            expert_ids=expert_ids,
            num_tokens_post_pad=num_tokens_post_pad,
        )
        return

    sorted_stride, expert_stride = _lora_strides(
        topk_ids.device, int(sorted_token_ids.shape[1]), int(expert_ids.shape[1]),
    )
    sorted_flat = sorted_token_ids.view(-1)
    expert_flat = expert_ids.view(-1)

    if small:
        _family.resolve_dispatch(topk_ids, variant_key=f"lora_small_{tag}", grid_x=max_loras)(
            topk_ids, token_lora_mapping, sorted_flat, expert_flat,
            num_tokens_post_pad, sorted_stride, expert_stride,
        )
        return

    cumsum = _cumsum_buffer(topk_ids.device, int(num_experts), max_loras=max_loras)
    _family.resolve_dispatch(
        topk_ids, variant_key=f"lora_large_align_{tag}", grid_x=max_loras * 2,
    )(
        topk_ids, token_lora_mapping, sorted_flat, expert_flat,
        num_tokens_post_pad, sorted_stride, expert_stride, cumsum,
    )
    if numel > 0:
        grid_y = ceil_div(numel, _LARGE_SCATTER_THREADS)
        _family.resolve_dispatch(
            topk_ids, variant_key=f"lora_large_scatter_{tag}",
            grid_x=max_loras, grid_y=grid_y,
        )(
            topk_ids, token_lora_mapping, sorted_flat,
            sorted_stride, num_tokens_post_pad, cumsum,
        )


__all__ = ["moe_align_block_size", "moe_lora_align_block_size"]
