"""PointTracker: thin wrapper around the vendored point-tracker network."""

from __future__ import annotations

import dataclasses
from collections.abc import Sequence
from typing import Optional

import numpy as np
import torch
import torch.nn.functional as F

from . import _model


_DEFAULT_REPO = "moondream/tracking"
_DEFAULT_FILENAME = "model.safetensors"
_DEFAULT_IMAGE_SIZE = 256


@dataclasses.dataclass
class TrackerState:
    seed_points_norm: torch.Tensor             # [Q, 2] normalized 0..1
    orig_h: Optional[int] = None
    orig_w: Optional[int] = None
    scale: Optional[float] = None
    pad_x: Optional[int] = None
    pad_y: Optional[int] = None
    model_state: Optional[_model._TrackerModelState] = None


class PointTracker:
    def __init__(
        self,
        net: _model._TrackerNet,
        *,
        image_size: int,
        device: torch.device,
        dtype: torch.dtype,
    ):
        self._net = net
        self._image_size = image_size
        self._device = device
        self._dtype = dtype
        # Lazy-built on the first replay-eligible step; dropped on reset().
        self._graph: Optional[torch.cuda.CUDAGraph] = None
        self._g_vs: Optional[torch.Tensor] = None
        self._g_state_in: Optional[_model._TrackerModelState] = None
        self._g_state_out: Optional[_model._TrackerModelState] = None
        self._g_tracks_out: Optional[torch.Tensor] = None

    @classmethod
    def from_pretrained(
        cls,
        repo_id: str = _DEFAULT_REPO,
        *,
        filename: str = _DEFAULT_FILENAME,
        revision: Optional[str] = None,
        device: str | torch.device = "cuda",
        dtype: Optional[torch.dtype] = None,
        image_size: int = _DEFAULT_IMAGE_SIZE,
        local_path: Optional[str] = None,
    ) -> "PointTracker":
        from safetensors.torch import load_file

        if local_path is None:
            from huggingface_hub import hf_hub_download
            local_path = hf_hub_download(
                repo_id=repo_id, filename=filename, revision=revision
            )

        device = torch.device(device)
        if dtype is None:
            dtype = torch.float16 if device.type == "cuda" else torch.float32

        # The coordinate head's bin count (256/axis) is baked into the trained
        # weights; outputs only line up with letterboxed pixels at image_size=256.
        if image_size != _DEFAULT_IMAGE_SIZE:
            raise ValueError(
                f"image_size={image_size} not supported; only "
                f"{_DEFAULT_IMAGE_SIZE} matches the trained head bin count"
            )

        net = _model._TrackerNet(image_size=(image_size, image_size))
        sd = load_file(local_path)

        patches = image_size // 8
        if "image_pos_emb" in sd and sd["image_pos_emb"].shape[1] != patches * patches:
            sd["image_pos_emb"] = _interp_pos_emb(
                sd["image_pos_emb"], (patches, patches)
            )

        # query_pos_embed is a deterministic sincos buffer regenerated in __init__
        # and intentionally omitted from the saved file; everything else must load.
        result = net.load_state_dict(sd, strict=False)
        if result.unexpected_keys:
            raise RuntimeError(
                f"unexpected keys in tracker checkpoint: {list(result.unexpected_keys)}"
            )
        leftover = set(result.missing_keys) - {"query_pos_embed"}
        if leftover:
            raise RuntimeError(f"missing keys in tracker checkpoint: {sorted(leftover)}")
        net.to(device=device, dtype=dtype).eval()
        return cls(net, image_size=image_size, device=device, dtype=dtype)

    def reset(self, points_norm: Sequence[tuple[float, float]]) -> TrackerState:
        if len(points_norm) == 0:
            raise ValueError("points_norm must be non-empty")
        seeds = torch.tensor(
            [(float(x), float(y)) for x, y in points_norm], dtype=torch.float32
        )
        if not torch.all((seeds >= 0.0) & (seeds <= 1.0)):
            raise ValueError("seed points must be in [0, 1]")
        # Q is baked into the captured graph; recapture on every reset.
        self._discard_graph()
        return TrackerState(seed_points_norm=seeds)

    @torch.inference_mode()
    def step(
        self, frame: np.ndarray, state: TrackerState
    ) -> tuple[list[tuple[float, float]], TrackerState]:
        if frame.ndim != 3 or frame.shape[2] != 3:
            raise ValueError(f"expected HxWx3 RGB frame, got shape {frame.shape}")
        if frame.dtype != np.uint8:
            raise ValueError(
                f"expected uint8 RGB frame in [0, 255]; got dtype {frame.dtype}"
            )
        if state.scale is None:
            self._pin_frame_geometry(frame, state)
        elif frame.shape[:2] != (state.orig_h, state.orig_w):
            raise ValueError(
                f"frame size changed mid-session: pinned "
                f"{(state.orig_h, state.orig_w)}, got {frame.shape[:2]}"
            )

        vs = self._prepare_input(frame, state)

        if state.model_state is None:
            # First step is eager — produces a hot state to capture against.
            qp = self._seeds_to_query_tensor(state)
            tracks, _, _, model_state = self._net(vs, query_points=qp)
            state.model_state = _ensure_tensor_step(model_state, self._device)
        else:
            if self._graph is None and self._device.type == "cuda":
                self._build_graph(vs, state.model_state)
            if self._graph is not None:
                self._g_vs.copy_(vs)
                _copy_state_inplace(self._g_state_in, state.model_state)
                self._graph.replay()
                tracks = self._g_tracks_out
                state.model_state = self._g_state_out
            else:
                tracks, _, _, model_state = self._net(vs, state=state.model_state)
                state.model_state = model_state

        # tracks: [B=1, T=1, Q, 2] in letterboxed pixel coords.
        preds_lb = tracks[0, 0].float().cpu().numpy()
        out: list[tuple[float, float]] = []
        for q in range(preds_lb.shape[0]):
            x_lb, y_lb = float(preds_lb[q, 0]), float(preds_lb[q, 1])
            x_orig = (x_lb - state.pad_x) / state.scale
            y_orig = (y_lb - state.pad_y) / state.scale
            out.append((x_orig / state.orig_w, y_orig / state.orig_h))
        return out, state

    def _build_graph(
        self, sample_vs: torch.Tensor, init_state: _model._TrackerModelState
    ) -> None:
        self._g_vs = torch.empty_like(sample_vs)
        self._g_state_in = _allocate_state_like(init_state)
        self._g_vs.copy_(sample_vs)
        _copy_state_inplace(self._g_state_in, init_state)

        # Warmup on a side stream — required by torch.cuda.graph capture.
        warmup_stream = torch.cuda.Stream(self._device)
        warmup_stream.wait_stream(torch.cuda.current_stream(self._device))
        with torch.cuda.stream(warmup_stream):
            for _ in range(3):
                self._net(self._g_vs, state=self._g_state_in)
        torch.cuda.current_stream(self._device).wait_stream(warmup_stream)

        self._graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(self._graph):
            tracks, _, _, output_state = self._net(
                self._g_vs, state=self._g_state_in
            )
        self._g_tracks_out = tracks
        self._g_state_out = output_state

    def _discard_graph(self) -> None:
        self._graph = None
        self._g_vs = None
        self._g_state_in = None
        self._g_state_out = None
        self._g_tracks_out = None

    def _pin_frame_geometry(self, frame: np.ndarray, state: TrackerState) -> None:
        h, w = frame.shape[:2]
        scale = min(self._image_size / w, self._image_size / h)
        state.orig_h, state.orig_w, state.scale = h, w, scale
        state.pad_x = (self._image_size - int(round(w * scale))) // 2
        state.pad_y = (self._image_size - int(round(h * scale))) // 2

    def _prepare_input(
        self, frame: np.ndarray, state: TrackerState
    ) -> torch.Tensor:
        new_w = int(round(state.orig_w * state.scale))
        new_h = int(round(state.orig_h * state.scale))
        t = (
            torch.from_numpy(frame)
            .to(self._device, non_blocking=True)
            .permute(2, 0, 1).unsqueeze(0).to(self._dtype)
        )
        resized = F.interpolate(
            t, size=(new_h, new_w), mode="bilinear", align_corners=False
        )
        canvas = torch.full(
            (1, 3, self._image_size, self._image_size),
            128.0, device=self._device, dtype=self._dtype,
        )
        canvas[
            :, :, state.pad_y : state.pad_y + new_h,
            state.pad_x : state.pad_x + new_w,
        ] = resized
        # Model expects HWC layout, normalized to [-1, 1]. Final shape [1,1,H,W,3].
        return canvas.permute(0, 2, 3, 1).unsqueeze(0) / 127.5 - 1.0

    def _seeds_to_query_tensor(self, state: TrackerState) -> torch.Tensor:
        seeds = state.seed_points_norm                      # [Q, 2]
        # Clamp the resulting letterboxed pixel to [0, image_size - 1] so
        # boundary seeds (e.g. (1.0, 1.0)) don't sample past the last pixel
        # center under embed_queries' grid_sample(align_corners=False).
        max_coord = self._image_size - 1
        x_lb = (seeds[:, 0] * state.orig_w * state.scale + state.pad_x).clamp(0, max_coord)
        y_lb = (seeds[:, 1] * state.orig_h * state.scale + state.pad_y).clamp(0, max_coord)
        # Query format (t, x, y); t=0 anchors the seeds at the first frame.
        qp = torch.stack([torch.zeros_like(x_lb), x_lb, y_lb], dim=-1).unsqueeze(0)
        return qp.to(device=self._device, dtype=self._dtype)


def _ensure_tensor_step(
    state: _model._TrackerModelState, device: torch.device
) -> _model._TrackerModelState:
    # state.step must be a tensor for cudagraph replay; Python ints get baked in.
    if isinstance(state.step, torch.Tensor):
        return state
    return _model._TrackerModelState(
        step=torch.tensor(int(state.step), dtype=torch.int64, device=device),
        query_points=state.query_points,
        hidden_state=state.hidden_state,
    )


def _allocate_state_like(
    state: _model._TrackerModelState,
) -> _model._TrackerModelState:
    return _model._TrackerModelState(
        step=torch.empty_like(state.step)
        if isinstance(state.step, torch.Tensor)
        else torch.zeros((), dtype=torch.int64, device=state.query_points.device),
        query_points=torch.empty_like(state.query_points),
        hidden_state=[
            _model.RecurrentBlockCache(
                rg_lru_state=torch.empty_like(c.rg_lru_state),
                conv1d_state=torch.empty_like(c.conv1d_state),
            )
            for c in state.hidden_state
        ],
    )


def _copy_state_inplace(
    dst: _model._TrackerModelState, src: _model._TrackerModelState
) -> None:
    if isinstance(src.step, torch.Tensor):
        dst.step.copy_(src.step)
    else:
        dst.step.fill_(int(src.step))
    dst.query_points.copy_(src.query_points)
    for d, s in zip(dst.hidden_state, src.hidden_state):
        d.rg_lru_state.copy_(s.rg_lru_state)
        d.conv1d_state.copy_(s.conv1d_state)


def _interp_pos_emb(src: torch.Tensor, new_grid: tuple[int, int]) -> torch.Tensor:
    N, C = src.shape[-2:]
    h = w = int(round(N**0.5))
    grid = src.reshape(1, h, w, C).permute(0, 3, 1, 2)
    grid = F.interpolate(grid, size=new_grid, mode="bilinear", align_corners=False)
    return grid.permute(0, 2, 3, 1).reshape(1, new_grid[0] * new_grid[1], C)
