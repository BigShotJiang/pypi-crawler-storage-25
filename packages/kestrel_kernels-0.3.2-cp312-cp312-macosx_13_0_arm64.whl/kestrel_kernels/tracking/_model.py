import dataclasses
from typing import List, NamedTuple

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F


class RMSNorm(nn.Module):
  # Upstream `(scale + 1)` parameter convention.
  def __init__(self, width: int, eps: float = 1e-6):
    super().__init__()
    self.width = width
    self.eps = eps
    self.scale = nn.Parameter(torch.empty([width]))

  def forward(self, x):
    return F.rms_norm(x, [self.width], weight=self.scale + 1.0, eps=self.eps)


class BlockDiagonalLinear(nn.Module):
  def __init__(self, width: int, num_blocks: int):
    super().__init__()
    self.width = width
    self.num_blocks = num_blocks
    self.block_width = width // num_blocks
    self.w = nn.Parameter(
        torch.empty([num_blocks, self.block_width, self.block_width])
    )
    self.b = nn.Parameter(torch.empty([num_blocks, self.block_width]))

  def forward(self, x):
    x = x.unflatten(-1, (self.num_blocks, self.block_width))
    y = torch.einsum("... h i, h i j -> ... h j", x, self.w) + self.b
    return y.flatten(-2)


def rnn_scan(x, a, h0):
  # Linear recurrence in fp32. Returns (y in x's dtype, last_h in fp32).
  if x.shape[1] == 1:
    if h0 is None:
      return x, x[:, 0].float()
    y = a.float() * h0[:, None] + x.float()
    return y.to(x.dtype), y[:, -1]
  h_t = h0 if h0 is not None else torch.zeros_like(x[:, 0], dtype=torch.float32)
  y = torch.zeros_like(x)
  for t in range(x.shape[1]):
    h_t = a[:, t].float() * h_t + x[:, t].float()
    y[:, t] = h_t.to(x.dtype)
  return y, h_t


class RGLRU(nn.Module):
  def __init__(self, width: int, num_heads: int):
    super().__init__()
    self.width = width
    self.num_heads = num_heads
    self.a_param = nn.Parameter(torch.empty([width]))
    self.input_gate = BlockDiagonalLinear(width, num_heads)
    self.a_gate = BlockDiagonalLinear(width, num_heads)

  def forward(self, x, cache=None):
    _, l, _ = x.shape
    segment_pos = torch.arange(l, device=x.device)
    if cache is not None:
      segment_pos = segment_pos + 1
    reset = segment_pos == 0

    gate_x = torch.sigmoid(self.input_gate(x))
    gate_a = torch.sigmoid(self.a_gate(x))
    log_a = -8.0 * gate_a * F.softplus(self.a_param)
    a = torch.exp(log_a)
    a_square = torch.exp(2 * log_a)

    multiplier = torch.sqrt(1 - a_square)
    multiplier = reset[..., None] + ~reset[..., None] * multiplier
    normalized_x = (x * gate_x) * multiplier.type(x.dtype)
    return rnn_scan(normalized_x, a, cache)


class CausalConv1D(nn.Module):
  def __init__(self, width: int, temporal_width: int):
    super().__init__()
    self.width = width
    self.temporal_width = temporal_width
    self.w = nn.Parameter(torch.empty([temporal_width, width]))
    self.b = nn.Parameter(torch.empty([width]))

  def forward(self, x, cache=None):
    if cache is None:
      cache = torch.zeros(
          (x.shape[0], self.temporal_width - 1, x.shape[2]),
          dtype=x.dtype, device=x.device,
      )
    x = torch.cat([cache, x], dim=1)
    if x.shape[1] == self.temporal_width:
      y = (x * self.w.unsqueeze(0)).sum(1, keepdims=True) + self.b[None, None, :]
    else:
      y = F.conv1d(
          x.transpose(1, 2), self.w.t().unsqueeze(1), self.b, groups=x.shape[-1]
      ).transpose(1, 2).contiguous()
    return y, x[:, 1 - self.temporal_width:]


class Einsum(nn.Module):
  def __init__(self, w_shape, b_shape, eqn: str):
    super().__init__()
    self.eqn = eqn
    self.w = nn.Parameter(torch.empty(tuple(w_shape)))
    self.b = nn.Parameter(torch.empty(tuple(b_shape)))

  def forward(self, x):
    return torch.einsum(self.eqn, x, self.w) + self.b


class RecurrentBlockCache(NamedTuple):
  rg_lru_state: torch.Tensor
  conv1d_state: torch.Tensor


class RecurrentBlock(nn.Module):
  def __init__(self, width, num_heads, lru_width=None, conv1d_temporal_width=4):
    super().__init__()
    self.width = width
    self.num_heads = num_heads
    self.lru_width = lru_width or width
    self.linear_y = nn.Linear(width, self.lru_width)
    self.linear_x = nn.Linear(width, self.lru_width)
    self.linear_out = nn.Linear(self.lru_width, width)
    self.conv_1d = CausalConv1D(self.lru_width, conv1d_temporal_width)
    self.rg_lru = RGLRU(self.lru_width, num_heads)

  def forward(self, x, cache=None):
    y = F.gelu(self.linear_y(x), approximate="tanh")
    x = self.linear_x(x)
    x, conv1d_state = self.conv_1d(
        x, None if cache is None else cache.conv1d_state
    )
    x, rg_lru_state = self.rg_lru(
        x, None if cache is None else cache.rg_lru_state
    )
    return self.linear_out(x * y), RecurrentBlockCache(
        rg_lru_state=rg_lru_state, conv1d_state=conv1d_state
    )


class MLPBlock(nn.Module):
  def __init__(self, width, expanded_width):
    super().__init__()
    self.ffw_up = Einsum(
        w_shape=(2, width, expanded_width),
        b_shape=(2, 1, 1, expanded_width),
        eqn="...td,cdD->c...tD",
    )
    self.ffw_down = nn.Linear(expanded_width, width)

  def forward(self, x):
    out = self.ffw_up(x)
    return self.ffw_down(F.gelu(out[0], approximate="tanh") * out[1])


class ResidualBlock(nn.Module):
  def __init__(
      self, width, mlp_expanded_width, num_heads,
      lru_width=None, conv1d_temporal_width=4,
  ):
    super().__init__()
    self.temporal_pre_norm = RMSNorm(width)
    self.recurrent_block = RecurrentBlock(
        width, num_heads, lru_width, conv1d_temporal_width
    )
    self.channel_pre_norm = RMSNorm(width)
    self.mlp_block = MLPBlock(width, mlp_expanded_width)

  def forward(self, x, cache=None):
    raw_x = x
    x, cache = self.recurrent_block(self.temporal_pre_norm(raw_x), cache)
    residual = x + raw_x
    return self.mlp_block(self.channel_pre_norm(residual)) + residual, cache


def posemb_sincos_2d(h, w, width, temperature=10_000.0, dtype=np.float32):
  # MoCo v3 sin-cos 2D positional embedding.
  y, x = np.mgrid[:h, :w]
  assert width % 4 == 0
  omega = 1.0 / (temperature ** (np.arange(width // 4) / (width // 4 - 1)))
  y = np.einsum("m,d->md", y.flatten(), omega)
  x = np.einsum("m,d->md", x.flatten(), omega)
  pe = np.concatenate([np.sin(x), np.cos(x), np.sin(y), np.cos(y)], axis=1)
  return np.asarray(pe, dtype)[None, :, :]


class _EncoderBlock(nn.Module):
  # Pre-LN ViT block. Parameter names mirror the upstream layout
  # (`ln_1`, `self_attention`, `ln_2`, `mlp.{0,3}`) so saved weights load.
  def __init__(self, num_heads, hidden_dim, mlp_dim):
    super().__init__()
    self.num_heads = num_heads
    self.ln_1 = nn.LayerNorm(hidden_dim, eps=1e-6)
    self.self_attention = nn.MultiheadAttention(
        hidden_dim, num_heads, dropout=0.0, batch_first=True
    )
    self.ln_2 = nn.LayerNorm(hidden_dim, eps=1e-6)
    # Dropouts kept as no-ops to align mlp.0 / mlp.3 with the linears.
    self.mlp = nn.Sequential(
        nn.Linear(hidden_dim, mlp_dim), nn.GELU(), nn.Dropout(0.0),
        nn.Linear(mlp_dim, hidden_dim), nn.Dropout(0.0),
    )

  def forward(self, input):
    x = self.ln_1(input)
    x, _ = self.self_attention(x, x, x, need_weights=False)
    x = x + input
    return x + self.mlp(self.ln_2(x))


class _SpatioTemporalBlock(nn.Module):
  # SSM along time per spatial token, then ViT across spatial tokens per frame.
  def __init__(self, width, num_heads, lru_width):
    super().__init__()
    self.ssm_block = ResidualBlock(width, width * 4, num_heads, lru_width)
    self.vit_block = _EncoderBlock(num_heads, width, width * 4)

  def forward(self, x, cache=None):
    b, t, n, c = x.shape
    x = x.permute(0, 2, 1, 3).reshape(b * n, t, c)
    x, ssm_cache = self.ssm_block(x, cache)
    x = x.reshape(b, n, t, c).permute(0, 2, 1, 3).reshape(b * t, n, c)
    x = self.vit_block(x)
    return x.reshape(b, t, n, c), ssm_cache


@dataclasses.dataclass
class _TrackerModelState:
  step: int
  query_points: torch.Tensor
  hidden_state: List[RecurrentBlockCache] = None


def _head(width, out_dim):
  return nn.Sequential(
      nn.Linear(width, 256), nn.LayerNorm(256), nn.GELU(),
      nn.Linear(256, 256), nn.LayerNorm(256), nn.GELU(),
      nn.Linear(256, out_dim),
  )


class _TrackerNet(nn.Module):
  def __init__(
      self, image_size,
      width=768, patch_size=(8, 8), num_heads=12, lru_width=768, depth=12,
  ):
    super().__init__()
    self.width = width
    self.patch_size = patch_size
    self.image_size = image_size

    self.lin_proj = nn.Conv2d(3, width, patch_size, stride=patch_size)
    self.blocks = nn.ModuleList(
        [_SpatioTemporalBlock(width, num_heads, lru_width) for _ in range(depth)]
    )
    self.encoder_norm = nn.LayerNorm(width)
    self.mask_token = nn.Parameter(torch.zeros((1, 1, 1, width)))
    self.unknown_token = nn.Parameter(torch.zeros((1, 1, width)))
    self.point_query_token = nn.Parameter(torch.zeros((1, 1, 1, width)))
    h, w = image_size[0] // patch_size[0], image_size[1] // patch_size[1]
    self.image_pos_emb = nn.Parameter(torch.zeros((1, h * w, width)))
    self.register_buffer(
        "query_pos_embed",
        torch.tensor(posemb_sincos_2d(image_size[0], image_size[1], width)),
    )
    # Buffer (vs allocating in forward) so cudagraph capture doesn't see a
    # CPU→CUDA tensor creation, which it disallows.
    self.register_buffer(
        "image_size_buf",
        torch.tensor(image_size, dtype=torch.float32),
        persistent=False,
    )
    self.visible_head = _head(width, 1)
    self.coordinate_head = _head(width, 512)

  def embed_queries(self, timesteps, query_points):
    b, q, _ = query_points.shape
    t, c = timesteps, self.width
    tiled_point_query_tokens = self.point_query_token.repeat(b, 1, q, 1)
    mask_tokens = self.mask_token.repeat(b, t, q, 1)
    unknown_tokens = self.unknown_token.repeat(b, t, q, 1)
    query_pos_embed = self.query_pos_embed.view(
        1, self.image_size[0], self.image_size[1], c
    ).repeat(b, 1, 1, 1)
    query_timesteps = query_points[..., :1]
    query_positions = query_points[..., 1:]
    # grid_sample expects coords in [-1, 1]; we swap h↔w due to grid_sample
    # convention.
    query_pos_embed_spatial = F.grid_sample(
        query_pos_embed.permute(0, 3, 2, 1),
        (query_positions.unsqueeze(1) / self.image_size_buf) * 2 - 1,
        align_corners=False,
    ).permute(0, 2, 3, 1)
    point_query_tokens = tiled_point_query_tokens + query_pos_embed_spatial

    if t == 1:
      mask_and_query_tokens = torch.where(
          query_timesteps.unsqueeze(1) == 0, point_query_tokens, mask_tokens
      )
    else:
      queries_late_or_early = (query_timesteps >= t) | (query_timesteps < 0)
      mask_and_query_tokens = mask_tokens.scatter(
          dim=1,
          index=query_timesteps.unsqueeze(1).long().clamp(0, t - 1).repeat(1, 1, 1, c),
          src=point_query_tokens,
      )
      mask_and_query_tokens = torch.where(
          queries_late_or_early.unsqueeze(1), mask_tokens, mask_and_query_tokens
      )
    is_unknown = (
        torch.arange(t, device=query_points.device)[None, :, None, None]
        < query_timesteps.unsqueeze(1)
    )
    return torch.where(is_unknown, unknown_tokens, mask_and_query_tokens)

  def prediction_heads(self, x):
    soft_argmax_threshold = 20
    softmax_temperature = 0.5
    # coordinate_head runs in the model's compute dtype (e.g. fp16); promote
    # to fp32 only for the soft-argmax math below.
    track_logits = self.coordinate_head(x).float()
    position_x, position_y = track_logits.chunk(2, dim=-1)
    argmax_x = position_x.argmax(dim=-1, keepdim=True)
    argmax_y = position_y.argmax(dim=-1, keepdim=True)
    index = torch.arange(position_x.shape[-1], device=x.device).repeat(
        *argmax_x.shape[:-1], 1
    )
    mask_x = (torch.abs(argmax_x - index) <= soft_argmax_threshold).float()
    mask_y = (torch.abs(argmax_y - index) <= soft_argmax_threshold).float()
    probs_x = F.softmax(position_x * softmax_temperature, dim=-1) * mask_x
    probs_y = F.softmax(position_y * softmax_temperature, dim=-1) * mask_y
    probs_x = probs_x / probs_x.sum(dim=-1, keepdim=True)
    probs_y = probs_y / probs_y.sum(dim=-1, keepdim=True)
    tracks_x = torch.sum(probs_x * index, dim=-1)[..., None]
    tracks_y = torch.sum(probs_y * index, dim=-1)[..., None]
    tracks = torch.cat([tracks_x, tracks_y], dim=-1) + 0.5
    return tracks, track_logits, self.visible_head(x)

  def forward(self, video, query_points=None, state=None):
    b, t, h_in, w_in, c_in = video.shape
    video_in = video.permute(0, 1, 4, 2, 3).reshape(b * t, c_in, h_in, w_in)
    video_tokens = self.lin_proj(video_in)
    _, c_proj, h, w = video_tokens.shape
    video_tokens = (
        video_tokens.reshape(b, t, c_proj, h * w).transpose(2, 3).contiguous()
    )
    video_tokens = video_tokens + self.image_pos_emb.unsqueeze(0)

    if state is not None:
      if query_points is None:
        query_points = state.query_points
      query_points = torch.cat(
          [query_points[..., :1] - state.step, query_points[..., 1:]], dim=-1
      )
      step = state.step
    else:
      step = 0

    point_tokens = self.embed_queries(t, query_points)
    x = torch.cat([video_tokens, point_tokens], dim=2)

    ssm_cache = []
    cache_in = state.hidden_state if state is not None else [None] * len(self.blocks)
    for blk, cache in zip(self.blocks, cache_in):
      x, layer_cache = blk(x, cache=cache)
      ssm_cache.append(layer_cache)
    x = self.encoder_norm(x)
    point_tokens = x[:, :, h * w:, :]
    return (
        *self.prediction_heads(point_tokens),
        _TrackerModelState(
            step=step + t,
            query_points=state.query_points if state is not None else query_points,
            hidden_state=ssm_cache,
        ),
    )
