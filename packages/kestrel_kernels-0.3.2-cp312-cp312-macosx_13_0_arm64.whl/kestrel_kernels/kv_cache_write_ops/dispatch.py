"""KV-cache write dispatch — direct call into _pybridge."""


import torch

from kestrel_kernels._pybridge import reshape_and_cache_flash as _raw
from kestrel_kernels.fallback import should_use_cuda_impl
from kestrel_kernels.kv_cache_write_ops.fallback import reshape_and_cache_flash_torch

_SUPPORTED_SMS = {80, 86, 87, 89, 90, 100, 110, 120}


def reshape_and_cache_flash(key, value, key_cache, value_cache,
                            slot_mapping, kv_cache_dtype, k_scale, v_scale):
    if not should_use_cuda_impl(
        device=key.device,
        kernel_key="kv_cache_write",
        op_name="reshape_and_cache_flash",
        supported_sms=_SUPPORTED_SMS,
    ):
        reshape_and_cache_flash_torch(
            key, value, key_cache, value_cache,
            slot_mapping, kv_cache_dtype, k_scale, v_scale,
        )
        return
    if slot_mapping.numel() == 0:
        return
    dtype_code = 0 if key.dtype == torch.bfloat16 else 1
    is_fp8 = int(kv_cache_dtype in ("fp8", "fp8_e4m3"))
    _raw(key, value, key_cache, value_cache, slot_mapping,
         k_scale, v_scale, dtype_code, is_fp8)


__all__ = ["reshape_and_cache_flash"]
