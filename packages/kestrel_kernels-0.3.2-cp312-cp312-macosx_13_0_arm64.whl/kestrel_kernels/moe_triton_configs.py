"""Triton MoE kernel configs tuned per SM architecture.

Configs live in configs/triton_moe_*.json and are loaded at import time.
Each file declares its own sm_major / num_experts / intermediate_size in
the body, so this module is a thin JSON loader — no per-GPU branching lives
in Python.

To add configs for a new GPU architecture:
1. Run scripts/tune_triton_moe.py on the new hardware
2. Save the result as configs/triton_moe_E{E}_H{H}_I{I}_{dtype}_{gpu}.json
   with top-level keys sm_major / num_experts / intermediate_size / configs
"""

import json
from pathlib import Path

import torch

_CONFIGS_DIR = Path(__file__).parent / "configs"

# Default SM version used when no arch-specific config exists. B200 is the
# newest target we tune against and its configs generalize reasonably.
_DEFAULT_SM = 10


def _load_configs(
    dtype_str: str,
) -> dict[int, dict[tuple[int, int], dict[int, dict[str, int]]]]:
    """Load all triton_moe_*_{dtype}_*.json into the nested-dict schema.

    Returns {sm_major: {(num_experts, intermediate_size): {num_tokens: config}}}.
    """
    table: dict[int, dict[tuple[int, int], dict[int, dict[str, int]]]] = {}

    if not _CONFIGS_DIR.exists():
        return table

    for path in sorted(_CONFIGS_DIR.glob(f"triton_moe_*_{dtype_str}_*.json")):
        try:
            with open(path) as f:
                data = json.load(f)
            sm_major = int(data["sm_major"])
            num_experts = int(data["num_experts"])
            intermediate_size = int(data["intermediate_size"])
            raw_configs = data["configs"]
        except (KeyError, ValueError, json.JSONDecodeError) as e:
            # Malformed config — skip it so one bad file doesn't block import.
            print(f"warning: failed to load {path.name}: {e}")
            continue

        shape_key = (num_experts, intermediate_size)
        sm_entry = table.setdefault(sm_major, {})
        shape_entry = sm_entry.setdefault(shape_key, {})
        for tokens_str, cfg in raw_configs.items():
            shape_entry[int(tokens_str)] = {k: int(v) for k, v in cfg.items()}

    return table


_BF16_CONFIGS = _load_configs("bf16")
_FP8_CONFIGS = _load_configs("fp8")


def _resolve_sm() -> int:
    if torch.cuda.is_available():
        return torch.cuda.get_device_capability()[0]
    return _DEFAULT_SM


def _lookup(
    table: dict[int, dict[tuple[int, int], dict[int, dict[str, int]]]],
    num_experts: int,
    input_size: int,
    num_tokens: int,
) -> dict[str, int] | None:
    sm = _resolve_sm()
    shape_configs = table.get(sm, {}).get((num_experts, input_size))
    if not shape_configs and sm <= _DEFAULT_SM:
        shape_configs = table.get(_DEFAULT_SM, {}).get((num_experts, input_size))
    if not shape_configs:
        return None
    nearest = min(shape_configs.keys(), key=lambda m: abs(m - num_tokens))
    raw = shape_configs[nearest]
    return {k.upper(): int(v) for k, v in raw.items()}


def get_triton_moe_config(
    num_experts: int, input_size: int, num_tokens: int, *, fp8: bool = False,
) -> dict[str, int] | None:
    """Get a tuned Triton MoE config for the current GPU.

    Returns an uppercased config dict ready for Triton kernel launch,
    or None if no configs exist for this shape.
    """
    return _lookup(
        _FP8_CONFIGS if fp8 else _BF16_CONFIGS,
        num_experts, input_size, num_tokens,
    )
