"""cublasLt linear projection: out = x @ w.T [+ bias].

Drop-in replacement for F.linear that bypasses PyTorch's cuBLAS dispatch
overhead. Falls back to F.linear if the kernel is unavailable.

Supports a scratch buffer pool to eliminate per-call tensor allocations
during prefill. Call set_scratch_pool() before a batch of linear calls,
clear_scratch_pool() after.
"""


import torch

# Scratch buffer pool: pre-allocated output tensors keyed by (M, N).
_scratch_pool: dict[tuple[int, int], torch.Tensor] | None = None


def set_scratch_pool(pool: dict[tuple[int, int], torch.Tensor]) -> None:
    """Activate scratch buffer pool for output tensor reuse."""
    global _scratch_pool
    _scratch_pool = pool


def clear_scratch_pool() -> None:
    """Deactivate scratch buffer pool."""
    global _scratch_pool
    _scratch_pool = None


def _get_or_alloc(m: int, n: int, dtype: torch.dtype, device: torch.device) -> torch.Tensor:
    if _scratch_pool is not None:
        buf = _scratch_pool.get((m, n))
        if buf is not None:
            return buf
    return torch.empty(m, n, dtype=dtype, device=device)


from kestrel_kernels._pybridge import linear as _raw_linear

# Empty bias placeholder so the C wrapper always gets a valid tensor.
# Skip allocation when CUDA isn't available — the kernel itself only
# runs on CUDA, so this constant is unreachable on other backends, but
# the module is still imported (e.g. on macOS via MPS dispatch) and
# allocating a CUDA tensor at import time would crash.
_NO_BIAS = (
    torch.empty(0, dtype=torch.bfloat16, device="cuda")
    if torch.cuda.is_available()
    else None
)


def linear(x: torch.Tensor, w: torch.Tensor, bias: torch.Tensor | None = None,
           out: torch.Tensor | None = None) -> torch.Tensor:
    """Linear projection: out = x @ w.T [+ bias].

    Uses cublasLt via _pybridge. Pass out= or set_scratch_pool() to avoid allocation.
    """
    if x.ndim == 3:
        bsz, t, c = x.shape
        x2 = x.reshape(bsz * t, c)
    else:
        bsz = 0
        x2 = x
    if out is None:
        out = _get_or_alloc(x2.size(0), w.size(0), x2.dtype, x2.device)
    dtype_code = 0 if x2.dtype == torch.bfloat16 else 1
    has_bias = 1 if bias is not None else 0
    _raw_linear(out, x2, w, has_bias, bias if bias is not None else _NO_BIAS, dtype_code)
    if bsz:
        return out.view(bsz, t, w.size(0))
    return out


__all__ = ["linear", "set_scratch_pool", "clear_scratch_pool"]
