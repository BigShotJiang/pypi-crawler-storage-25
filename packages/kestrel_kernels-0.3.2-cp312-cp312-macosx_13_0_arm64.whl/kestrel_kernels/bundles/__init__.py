"""Packaged runtime bundles for direct-cubin kernel launchers."""
