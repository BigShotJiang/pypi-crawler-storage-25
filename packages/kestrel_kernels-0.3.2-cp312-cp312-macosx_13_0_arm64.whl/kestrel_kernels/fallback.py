"""Shared helpers for kernel dispatch and fallbacks."""


import logging
import os
import threading
from typing import Any, Callable, Iterable, TypeVar
import warnings

log = logging.getLogger(__name__)

import torch

from kestrel_kernels.arch import get_cuda_compute_capability


_FALLBACK_WARNED: set[str] = set()
_FALLBACK_WARN_LOCK = threading.Lock()
_T = TypeVar("_T")


def ceil_div(n: int, d: int) -> int:
    """Ceiling division for non-negative ints: ceil_div(7, 2) == 4."""
    return (n + d - 1) // d


def is_cute_jit_enabled() -> bool:
    """True if the dev-time CuTe JIT-on-miss path should run.

    Reads `KESTREL_CUTE_JIT` first, then the legacy `KESTREL_CUTE_MOE_JIT`
    (with a one-time deprecation warning) so older scripts keep working
    while the new name propagates.
    """
    if os.environ.get("KESTREL_CUTE_JIT") == "1":
        return True
    if os.environ.get("KESTREL_CUTE_MOE_JIT") == "1":
        warn_fallback_once(
            "kestrel_cute_moe_jit_deprecated",
            "KESTREL_CUTE_MOE_JIT is deprecated; use KESTREL_CUTE_JIT instead. "
            "The legacy name will be removed in a future release.",
        )
        return True
    return False


def warn_fallback_once(kernel_key: str, message: str) -> None:
    with _FALLBACK_WARN_LOCK:
        if kernel_key in _FALLBACK_WARNED:
            return
        _FALLBACK_WARNED.add(kernel_key)
    warnings.warn(message, RuntimeWarning, stacklevel=2)


def device_capability(device: torch.device) -> tuple[int, int]:
    """Return (major, minor) capability for a CUDA device, else (0, 0)."""
    if device.type != "cuda":
        return (0, 0)
    index = int(torch.cuda.current_device() if device.index is None else device.index)
    return get_cuda_compute_capability(index)


def warn_and_run_fallback(
    *,
    kernel_key: str,
    message: str,
    fallback: Callable[..., _T],
    args: tuple[Any, ...] = (),
    kwargs: dict[str, Any] | None = None,
) -> _T:
    warn_fallback_once(kernel_key, message)
    if kwargs is None:
        kwargs = {}
    return fallback(*args, **kwargs)


def should_use_cuda_impl(
    *,
    device: torch.device,
    kernel_key: str,
    op_name: str,
    supported_sms: Iterable[int],
) -> bool:
    """Return True when CUDA impl is supported on `device`, else warn once and return False."""
    major, minor = device_capability(device)
    sm = major * 10 + minor
    allowed = sorted({int(v) for v in supported_sms})
    if sm in allowed:
        return True
    warn_fallback_once(
        kernel_key,
        "kestrel-kernels: falling back to PyTorch for "
        f"{op_name} (arch=sm{major}{minor}, supported_sms={allowed}).",
    )
    return False
