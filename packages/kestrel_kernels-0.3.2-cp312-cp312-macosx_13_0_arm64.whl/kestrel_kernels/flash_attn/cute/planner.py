
from dataclasses import dataclass
from typing import Callable, Optional

import torch


@dataclass(frozen=True)
class FlashAttnArchCaps:
    supports_decode_fastpath: bool
    supports_fp8_kv_decode: bool
    supports_paged_prefill_fp8: bool


@dataclass(frozen=True)
class FlashAttnForwardPlan:
    paged_kv_non_tma: bool
    use_decode_fastpath: bool
    use_paged_prefill_fp8: bool


_FLASH_ATTN_ARCH_CAPS = {
    80: FlashAttnArchCaps(
        supports_decode_fastpath=True,
        supports_fp8_kv_decode=True,
        supports_paged_prefill_fp8=False,
    ),
    86: FlashAttnArchCaps(
        supports_decode_fastpath=True,
        supports_fp8_kv_decode=True,
        supports_paged_prefill_fp8=False,
    ),
    87: FlashAttnArchCaps(
        supports_decode_fastpath=True,
        supports_fp8_kv_decode=True,
        supports_paged_prefill_fp8=False,
    ),
    89: FlashAttnArchCaps(
        supports_decode_fastpath=True,
        supports_fp8_kv_decode=True,
        supports_paged_prefill_fp8=False,
    ),
    90: FlashAttnArchCaps(
        supports_decode_fastpath=True,
        supports_fp8_kv_decode=True,
        supports_paged_prefill_fp8=True,
    ),
    100: FlashAttnArchCaps(
        supports_decode_fastpath=True,
        supports_fp8_kv_decode=True,
        supports_paged_prefill_fp8=True,
    ),
    110: FlashAttnArchCaps(
        # Jetson Thor — datacenter Blackwell, same TCGen05 path as sm_100.
        # Decode + FP8 KV decode + paged-prefill FP8 cubins ship via the
        # forward_sm100/decode_sm90/persistent_split_fused arch_filter
        # union in scripts/precompile/cubin_bundles.py.
        supports_decode_fastpath=True,
        supports_fp8_kv_decode=True,
        supports_paged_prefill_fp8=True,
    ),
    120: FlashAttnArchCaps(
        supports_decode_fastpath=True,
        supports_fp8_kv_decode=True,
        supports_paged_prefill_fp8=False,
    ),
}
_DEFAULT_FLASH_ATTN_ARCH_CAPS = FlashAttnArchCaps(
    supports_decode_fastpath=False,
    supports_fp8_kv_decode=False,
    supports_paged_prefill_fp8=False,
)


def get_flash_attn_arch_caps(device_sm: int) -> FlashAttnArchCaps:
    return _FLASH_ATTN_ARCH_CAPS.get(device_sm, _DEFAULT_FLASH_ATTN_ARCH_CAPS)


def infer_paged_kv_non_tma(
    *,
    compute_capability: int,
    page_table: Optional[torch.Tensor],
    page_size: Optional[int],
    paged_kv_non_tma: Optional[bool],
) -> bool:
    if paged_kv_non_tma is not None:
        return paged_kv_non_tma
    if compute_capability in (8, 9):
        # For SM8x/SM90, use the non-TMA (cp.async) path for all paged KV to
        # support arbitrary page sizes.
        return page_table is not None
    # SM100 currently uses a non-TMA path when page_size != 128.
    return page_size not in (None, 128)


def make_forward_plan(
    *,
    device_sm: int,
    compute_capability: int,
    page_table: Optional[torch.Tensor],
    page_size: Optional[int],
    paged_kv_non_tma: Optional[bool],
    cu_seqlens_q: Optional[torch.Tensor],
    cu_seqlens_k: Optional[torch.Tensor],
    seqused_q: Optional[torch.Tensor],
    seqused_k: Optional[torch.Tensor],
    seqlen_q: Optional[int],
    head_dim: int,
    head_dim_v: int,
    score_mod: Optional[Callable],
    mask_mod: Optional[Callable],
    aux_tensors: Optional[list[torch.Tensor]],
    learnable_sink: Optional[torch.Tensor],
    is_split_kv: bool,
    kv_is_fp8: bool,
) -> FlashAttnForwardPlan:
    caps = get_flash_attn_arch_caps(device_sm)
    resolved_paged_kv_non_tma = infer_paged_kv_non_tma(
        compute_capability=compute_capability,
        page_table=page_table,
        page_size=page_size,
        paged_kv_non_tma=paged_kv_non_tma,
    )
    eligible_for_decode_fastpath = (
        caps.supports_decode_fastpath
        and page_table is not None
        and page_size == 1
        and cu_seqlens_q is None
        and cu_seqlens_k is None
        and seqused_q is None
        and seqused_k is not None
        and seqlen_q == 1
        and head_dim_v == head_dim
        and score_mod is None
        and mask_mod is None
        and aux_tensors is None
        and learnable_sink is None
        and not is_split_kv
        and head_dim in (64, 128)
    )
    use_decode_fastpath = eligible_for_decode_fastpath and (
        not kv_is_fp8 or caps.supports_fp8_kv_decode
    )
    use_paged_prefill_fp8 = (
        kv_is_fp8
        and caps.supports_paged_prefill_fp8
        and page_table is not None
        and resolved_paged_kv_non_tma
    )
    return FlashAttnForwardPlan(
        paged_kv_non_tma=resolved_paged_kv_non_tma,
        use_decode_fastpath=use_decode_fastpath,
        use_paged_prefill_fp8=use_paged_prefill_fp8,
    )


def decode_debug_impl_name(device_sm: int) -> str:
    return {
        80: "sm80_decode",
        86: "sm86_decode",
        87: "sm87_decode",
        89: "sm89_decode",
        90: "sm90_decode",
        100: "sm100_decode",
        120: "sm120_decode",
    }.get(device_sm, f"sm{device_sm}_decode")
