"""Flash Attention CUTE dispatch package.

Kept deliberately cutlass-free at import time: production wheels resolve
dispatch through `kestrel_kernels.flash_attn.cute.dispatch` + shipped
cubin bundles, which don't need cutlass-dsl installed. The
cutlass-DSL kernel class modules (`flash_fwd.py`, `flash_fwd_sm100.py`,
`flash_decode_sm90.py`, etc.) are only imported from the JIT path
(`KESTREL_CUTE_JIT=1`) via `scripts/precompile/cubin_bundles._compile_flash_attn_*`.
"""

__version__ = "0.1.0"


__all__ = []
