"""Flash-attention dispatch: cubin launchers + AOT forward wrapper.

One entry per kernel class. `launch_forward` resolves the AOT-emitted
host wrapper (which bakes TMA desc construction, cluster config, etc.)
and calls its `ciface` entry. The other `launch_*` variants dispatch
directly through the cubin runtime.

None-valued compile-time args (e.g. `window_size_left=None`) get folded
out by `cute.compile` into compile-time constants, so the cubin/wrapper
runtime ABI excludes them. Callers only pass what's present.

When `KESTREL_CUTE_JIT=1`, missing variants are compiled on demand via
`cubin_bundles.jit_compile_and_install` (cubin families) or
`AotFamily`'s built-in JIT path (forward). Source install only.
"""


import ctypes

import torch

from kestrel_kernels.cubin_runtime import CubinFamily
from kestrel_kernels.cute_aot_runtime import AotFamily
from kestrel_kernels.fallback import ceil_div, is_cute_jit_enabled
from kestrel_kernels.flash_attn.cute.variant import (
    FlashAttnVariant,
    FlashAttnSm80ForwardVariant,
    FlashAttnDecodePersistentSplitFusedVariant,
)


_family = CubinFamily("flash_attn")

_ENABLE_JIT = is_cute_jit_enabled()
if _ENABLE_JIT:
    from scripts.precompile import cubin_bundles as _cubin_bundles
    from scripts.precompile.cubin_bundles import (
        _compile_flash_attn_forward,
        _compile_flash_attn_decode_sm90,
        _compile_flash_attn_sm80_forward,
        _compile_flash_attn_persistent_split_fused,
    )
else:
    _cubin_bundles = None
    _compile_flash_attn_forward = None
    _compile_flash_attn_decode_sm90 = None
    _compile_flash_attn_sm80_forward = None
    _compile_flash_attn_persistent_split_fused = None


_aot_forward = AotFamily(
    "flash_attn",
    jit_compile_fn=_compile_flash_attn_forward if _ENABLE_JIT else None,
)

_M_BLOCK = 128  # matches interface_sm90 default for all shipped variants


def _ensure_available(variant_key: str, first_tensor: torch.Tensor,
                      jit_compile_fn_factory, variant_for_jit,
                      block_x: int) -> bool:
    """Ensure the cubin family has `variant_key` ready to launch.

    Returns True if the variant is usable (either shipped in the bundle
    for this arch, already JIT-installed for this device, or just
    JIT-compiled on demand). Returns False if not shipped and either
    JIT is disabled or JIT compilation fails — callers should fall back
    to torch in that case.
    """
    if _family.is_available(variant_key):
        return True
    device_index = int(first_tensor.device.index or 0)
    if (variant_key, device_index) in _family._handles:
        return True
    if not _ENABLE_JIT:
        return False
    try:
        _cubin_bundles.jit_compile_and_install(
            family=_family,
            variant_key=variant_key,
            compile_fn=jit_compile_fn_factory(variant_for_jit),
            block_x=block_x,
            device_index=device_index,
        )
    except Exception as exc:
        # Make JIT failures visible during iteration. Production path
        # should either ship the bundle or set `KESTREL_CUTE_JIT_STRICT=1`
        # to re-raise; for now print+return-False so the caller's error
        # message points at the right diagnostic.
        import os as _os
        import traceback as _tb
        if _os.environ.get("KESTREL_CUTE_JIT_STRICT") == "1":
            raise
        print(f"[kestrel-kernels] JIT compile failed for {variant_key}:",
              flush=True)
        _tb.print_exc()
        return False
    return True


# The cute DSL kernel ABI puts all tensor structs first, then scalars,
# regardless of the __call__ wrapper's argument ordering. `launch_*`
# functions below pass args in that tensors-then-scalars order, matching
# how `_build_param_signature` emits the manifest's `param_signature`.


# ---------------------------------------------------------------------------
# launch_forward — FlashAttentionForwardSm90 / FlashAttentionForwardSm100
#
# Forward needs the cute-emitted host wrapper (TMA descriptors + scheduler
# Params). We ship an AOT `.so` per (variant, arch). See
# docs/CUTE_RUNTIME_REFACTOR_DESIGN.md § "Flash Attention Host Wrapper: AOT Path".
# ---------------------------------------------------------------------------

def launch_forward(
    variant: FlashAttnVariant,
    q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, out: torch.Tensor,
    softmax_scale: float, k_scale: float, v_scale: float,
    seqused_q: torch.Tensor | None,
    seqused_k: torch.Tensor | None,
    page_table: torch.Tensor | None,
    *,
    batch_size: int, seqlen_q: int | None, num_heads_kv: int,
    qhead_per_kvhead: int, pack_gqa: bool, sm_count: int,
) -> bool:
    assert variant.kind in ("forward_sm90", "forward_sm100")

    from kestrel_kernels.arch import get_cuda_arch
    bundle = _aot_forward.resolve(variant, get_cuda_arch())
    if bundle is None:
        del batch_size, seqlen_q, num_heads_kv, qhead_per_kvhead, pack_gqa, sm_count
        del seqused_q, seqused_k, page_table, softmax_scale, k_scale, v_scale
        del k, v, out
        return False

    bundle.aot._ensure_device(int(q.device.index or 0))

    # Memref order matches the compile_fn's tensor order:
    #   dense: (Q, K, V, O); seqused_q: + mSeqUsedQ;
    #   paged_kv_non_tma:    + mSeqUsedK, mPageTable.
    tensors: list[torch.Tensor] = [q, k, v, out]
    if variant.seqused_q:
        assert seqused_q is not None
        tensors.append(seqused_q)
    if variant.paged_kv_non_tma:
        assert seqused_k is not None and page_table is not None
        tensors.extend([seqused_k, page_table])

    if len(bundle.memref_specs) != len(tensors):
        raise RuntimeError(
            f"memref count mismatch for {variant.variant_key}: "
            f"ciface expects {len(bundle.memref_specs)}, got {len(tensors)}"
        )

    structs = [s.build(t) for t, s in zip(tensors, bundle.memref_specs)]
    struct_ptrs = [ctypes.pointer(s) for s in structs]

    sm = ctypes.c_float(float(softmax_scale))
    ks = ctypes.c_float(float(k_scale))
    vs = ctypes.c_float(float(v_scale))
    scalar_ptrs = [ctypes.pointer(sm), ctypes.pointer(ks), ctypes.pointer(vs)]

    stream = ctypes.c_void_p(torch.cuda.current_stream(q.device).cuda_stream)
    bundle.aot.call(bundle.arg_kinds, struct_ptrs, scalar_ptrs,
                    ctypes.pointer(stream))
    return True


# ---------------------------------------------------------------------------
# launch_decode_sm90 — FlashAttentionDecodeSm90 (all sm_8x/9x/10x/12x archs)
# ---------------------------------------------------------------------------

def launch_decode_sm90(
    variant: FlashAttnVariant,
    q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, out: torch.Tensor,
    softmax_scale: float, k_scale: float, v_scale: float,
    seqused_k: torch.Tensor, page_table: torch.Tensor,
    *,
    batch_size: int, num_heads_kv: int,
) -> bool:
    assert variant.kind == "decode_sm90"
    if not _ensure_available(variant.variant_key, q,
                             _compile_flash_attn_decode_sm90, variant, block_x=128):
        return False
    launcher = _family.resolve_dispatch(
        q, variant_key=variant.variant_key,
        grid_x=batch_size, grid_y=num_heads_kv,
    )
    launcher(q, k, v, out, seqused_k, page_table,
             softmax_scale, k_scale, v_scale)
    return True


# ---------------------------------------------------------------------------
# launch_sm80_forward — dense prefill on sm_80/86/87/89/120
# ---------------------------------------------------------------------------

def launch_sm80_forward(
    variant: FlashAttnSm80ForwardVariant,
    q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, out: torch.Tensor,
    softmax_scale: float, k_scale: float, v_scale: float,
    seqused_q: torch.Tensor | None = None,
    seqused_k: torch.Tensor | None = None,
    page_table: torch.Tensor | None = None,
    *,
    batch_size: int, seqlen_q: int, num_heads: int,
) -> bool:
    if not _ensure_available(variant.variant_key, q,
                             _compile_flash_attn_sm80_forward, variant, block_x=128):
        return False
    num_m_blocks = ceil_div(seqlen_q, _M_BLOCK)
    # The sm80 kernel decodes `m_block, num_head, batch_size = cute.arch.block_idx()`
    # — a 3D grid. Must match what `FlashAttentionForwardSm80.__call__`
    # launches (`grid=(num_m_blocks, num_heads, batch_size)`). Collapsing
    # `batch * num_heads` into grid_y leaves `batch_size = blockIdx.z = 0`
    # inside the kernel and misinterprets `blockIdx.y` as the head index
    # — output is correct only for batch==1, where batch*num_heads == num_heads
    # and every block happens to see batch_idx=0 anyway.
    launcher = _family.resolve_dispatch(
        q, variant_key=variant.variant_key,
        grid_x=num_m_blocks, grid_y=num_heads, grid_z=batch_size,
    )
    # `softmax_scale`, `k_scale`, `v_scale` match the Float32 scalar args
    # on `FlashAttentionForwardSm80.__call__`. BF16 variants still accept
    # the scales; callers pass 1.0 for BF16 KV.
    if variant.paged_kv_non_tma:
        assert seqused_k is not None and page_table is not None
        if variant.seqused_q:
            assert seqused_q is not None
            launcher(q, k, v, out, seqused_q, seqused_k, page_table,
                     softmax_scale, k_scale, v_scale)
        else:
            launcher(q, k, v, out, seqused_k, page_table,
                     softmax_scale, k_scale, v_scale)
    else:
        launcher(q, k, v, out, softmax_scale, k_scale, v_scale)
    return True


# ---------------------------------------------------------------------------
# launch_persistent_split_fused — CUDA-graph decode with split scheduler
# ---------------------------------------------------------------------------

def launch_persistent_split_fused(
    variant: FlashAttnDecodePersistentSplitFusedVariant,
    q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, out: torch.Tensor,
    softmax_scale: float, k_scale: float, v_scale: float,
    seqused_k: torch.Tensor, page_table: torch.Tensor,
    out_partial: torch.Tensor, lse_partial: torch.Tensor,
    split_counters: torch.Tensor,
    *,
    sm_count: int,
) -> bool:
    if not _ensure_available(variant.variant_key, q,
                             _compile_flash_attn_persistent_split_fused, variant,
                             block_x=128):
        return False
    launcher = _family.resolve_dispatch(
        q, variant_key=variant.variant_key,
        grid_x=int(sm_count), grid_y=1,
    )
    launcher(q, k, v, out, seqused_k, page_table,
             out_partial, lse_partial, split_counters,
             softmax_scale, k_scale, v_scale)
    return True


__all__ = [
    "launch_forward",
    "launch_decode_sm90",
    "launch_sm80_forward",
    "launch_persistent_split_fused",
]
