"""Cutlass-free runtime helpers for mask_mod dispatch.

The runtime dispatch path (`interface.py`, `interface_sm90.py`,
`interface_sm8x_prefill.py`, `fallback.py`) needs two things from
`mask_definitions`: the canonical string ID of each shipped mask and a
hash function that maps a user-provided callable back to that ID.
`mask_definitions.py` itself is cutlass-heavy (it defines `@cute.jit`
mask functions), so importing it would pull `cutlass` into the runtime
import chain — breaking installs without the `[jit]` extra.

This module keeps only the pure-Python pieces so the dispatch path
stays cutlass-free. `mask_definitions.py` is still imported from the
JIT build path (`scripts/precompile/cubin_bundles._compile_flash_attn_*`)
when cubins need to be compiled on demand.
"""

import hashlib
import inspect
from typing import Callable


PREFIX_LM_730_MASK_ID = (
    "kestrel_kernels.flash_attn.cute.mask_definitions.cute_prefix_lm_mask_730"
)


def hash_callable(func: Callable) -> str:
    """Hash a callable based on source/bytecode + closure cells.

    Fast-path: if the callable (or its `__wrapped__` base) has a
    `__cute_hash__` attribute, return that value directly. Shipped
    mask_mods surfaced via `kestrel_kernels.runtime` set this attribute
    to the matching `*_MASK_ID` constant so runtime dispatch can
    identify the caller's mask without tracing it.
    """
    if hasattr(func, "__cute_hash__"):
        return func.__cute_hash__

    if hasattr(func, "__wrapped__"):
        base_func = func.__wrapped__
        if hasattr(base_func, "__cute_hash__"):
            return base_func.__cute_hash__
        func = base_func

    try:
        data = inspect.getsource(func).encode()
    except (OSError, TypeError):
        if hasattr(func, "__code__") and func.__code__ is not None:
            data = func.__code__.co_code
        else:
            data = repr(func).encode()

    hasher = hashlib.sha256(data)

    if hasattr(func, "__closure__") and func.__closure__ is not None:
        for cell in func.__closure__:
            hasher.update(repr(cell.cell_contents).encode())

    return hasher.hexdigest()


__all__ = ["PREFIX_LM_730_MASK_ID", "hash_callable"]
