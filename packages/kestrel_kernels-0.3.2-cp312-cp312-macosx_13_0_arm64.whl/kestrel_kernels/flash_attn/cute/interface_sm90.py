# Copyright (c) 2025, Jay Shah, Ganesh Bikshandi, Ying Zhang, Vijay Thakkar, Pradeep Ramani, Tri Dao.
# [2025-07-04] Version in Cute-DSL, for Hopper and Blackwell. You'll need install nvidia-cutlass-dsl==4.2.0.

# Supported features:
# - BF16 & FP16 dtype
# - noncausal & causal attention
# - MHA, GQA, MQA
# - hdim 64, 96, 128.
# - (hdim_qk, hdim_v) = (192, 128) for Blackwell (i.e. DeepSeek shape)
# - varlen
# - sliding window
# - bwd pass for Ampere (will also run on Hopper/Blackwell, but will be slow)

# Features not supported yet:
# - general SplitKV (except the SM90 page_size==1 decode fused path)
# - tuned block sizes
# - append KV to existing KV cache
# - FP8
# - bwd pass optimized for Hopper/Blackwell

from functools import lru_cache as _lru_cache
from importlib import import_module as _import_module
from typing import Optional, Tuple, Callable

import torch

from kestrel_kernels.arch import get_cuda_compute_capability
from kestrel_kernels.flash_attn.cute import dispatch as flash_attn_dispatch
from kestrel_kernels.flash_attn.cute.fallback import flash_attn_fwd_torch_fallback
from kestrel_kernels.flash_attn.cute.mask_ids import PREFIX_LM_730_MASK_ID
from kestrel_kernels.flash_attn.cute.planner import (
    decode_debug_impl_name,
    make_forward_plan,
)
from kestrel_kernels.flash_attn.cute.variant import (
    FlashAttnDecodePersistentSplitFusedVariant,
    FlashAttnVariant,
)


@_lru_cache(maxsize=1)
def _validated_fwd():
    """Lazy ref to the public validator. Autograd Functions route through
    this so grad callers hit the same validation as direct
    `interface._flash_attn_fwd` invocations."""
    return _import_module("kestrel_kernels.flash_attn.cute.interface")._flash_attn_fwd


def _has_tcgen05(compute_capability: int) -> bool:
    """True for archs with 5th-gen Tensor Cores (tcgen05) — datacenter
    Blackwell. cc=10 is B200 / GB200 sm_100; cc=11 is Jetson Thor sm_110
    (the same TCGen05 path with the sm_110a codegen target). cc=12
    (consumer Blackwell) lacks tcgen05/wgmma and routes through the SM80
    kernel path instead.
    """
    return compute_capability in (10, 11)


def num_splits_heuristic(total_mblocks, num_SMs, num_n_blocks, max_splits):
    # If num_n_blocks is too small, use 1 split. For example, we never split for hdim = 128 and seqlen_k = 512.
    if num_n_blocks <= 4:
        return 1

    # NOTE: We should revisit this heuristic after persistence is supported for split KV.
    # Sometimes, it's ideal to over-schedule splits for better efficiency.
    return min(num_SMs // total_mblocks, max_splits, num_n_blocks)


_decode_persistent_split_fused_counter_cache: dict[
    tuple[int, int, int, int], torch.Tensor
] = {}


def _get_decode_persistent_split_fused_counters(
    *,
    device: torch.device,
    batch_size: int,
    num_kv_heads: int,
    group_count: int,
) -> torch.Tensor:
    """Get a reusable int32 counter buffer for the fused persistent split path.

    Important: we intentionally do *not* zero the buffer here to avoid capturing a memset
    into CUDA graphs. The fused kernel resets counters to 0 after each replay.
    """
    if device.type != "cuda":
        raise ValueError(f"Expected CUDA device; got {device!r}")
    if device.index is None:
        dev_index = int(torch.cuda.current_device())
        device = torch.device("cuda", dev_index)
    else:
        dev_index = int(device.index)

    batch_size = int(batch_size)
    num_kv_heads = int(num_kv_heads)
    group_count = int(group_count)
    if batch_size <= 0:
        raise ValueError(f"batch_size must be positive (got {batch_size})")
    if num_kv_heads <= 0:
        raise ValueError(f"num_kv_heads must be positive (got {num_kv_heads})")
    if group_count <= 0:
        raise ValueError(f"group_count must be positive (got {group_count})")

    shape = (batch_size, num_kv_heads * group_count)
    key = (dev_index, batch_size, num_kv_heads, group_count)
    buf = _decode_persistent_split_fused_counter_cache.get(key)
    if (
        buf is None
        or buf.device != device
        or buf.dtype != torch.int32
        or tuple(buf.shape) != shape
    ):
        buf = torch.zeros(shape, device=device, dtype=torch.int32)
        _decode_persistent_split_fused_counter_cache[key] = buf
    return buf


def _try_cubin_launch(
    *,
    dispatch_plan,
    compute_capability: int,
    kv_is_fp8: bool,
    head_dim: int,
    causal: bool,
    mask_mod,
    score_mod,
    softcap,
    seqused_q,
    pack_gqa: bool,
    num_splits: int,
    is_split_kv: bool,
    batch_size: int,
    seqlen_q,
    num_head_kv: int,
    qhead_per_kvhead: int,
    q, k, v, out, lse,
    softmax_scale: float,
    k_scale_val: float,
    v_scale_val: float,
    cu_seqlens_q, cu_seqlens_k, seqused_k, page_table,
    window_size_left, window_size_right, learnable_sink, aux_tensors,
    device,
) -> bool:
    """Try to serve this forward/decode call from the cubin bundle.

    Returns True on success, False if no shipped variant matches (caller
    falls back to torch SDPA). Shipped cubins cover bf16 only, no
    split-kv, no varlen cu_seqlens, no window / learnable sink / aux
    tensors, no custom mask_mods beyond `prefix_lm_730`, and no LSE
    output (the cubins are compiled with `mLSE=None`).
    """
    if q.dtype is not torch.bfloat16:
        return False
    if is_split_kv or num_splits > 1:
        return False
    if cu_seqlens_q is not None or cu_seqlens_k is not None:
        return False
    if window_size_left is not None or window_size_right is not None:
        return False
    if learnable_sink is not None or aux_tensors is not None:
        return False
    if lse is not None:
        return False
    # Shipped cubins don't apply score_mod or softcap — the compile
    # helpers in `cubin_bundles.py` wire `score_mod=None` and there's
    # no softcap arg in the kernel signature. Let torch SDPA handle
    # these rather than silently skip the transform.
    if score_mod is not None or softcap is not None:
        return False
    # Shipped cubin variants are MHA-only (compiled with qhead_per_kvhead=1
    # in cubin_bundles); GQA/MQA requests must fall through to torch rather
    # than silently launching an MHA kernel on grouped heads.
    if qhead_per_kvhead != 1:
        return False

    mask_mod_name: Optional[str] = None
    if mask_mod is not None:
        if getattr(mask_mod, "__cute_hash__", None) != PREFIX_LM_730_MASK_ID:
            return False
        mask_mod_name = "prefix_lm_730"

    k_for_call, v_for_call = k, v
    if kv_is_fp8 and (dispatch_plan.use_decode_fastpath or dispatch_plan.use_paged_prefill_fp8):
        k_for_call = k.view(torch.uint8)
        v_for_call = v.view(torch.uint8)

    dtype_kv_name = "fp8_e4m3" if kv_is_fp8 else "bf16"

    if dispatch_plan.use_decode_fastpath:
        if head_dim not in (64, 128) or not causal:
            return False
        if seqused_k is None or page_table is None:
            return False
        variant = FlashAttnVariant(
            kind="decode_sm90",
            dtype_name="bf16",
            dtype_kv_name=dtype_kv_name,
            head_dim=head_dim,
            causal=True,
            mask_mod_name=None,
            paged_kv_non_tma=False,
            seqused_q=False,
        )
        return flash_attn_dispatch.launch_decode_sm90(
            variant, q, k_for_call, v_for_call, out,
            float(softmax_scale), float(k_scale_val), float(v_scale_val),
            seqused_k, page_table,
            batch_size=batch_size, num_heads_kv=num_head_kv,
        )

    # Forward path
    if compute_capability == 9:
        kind = "forward_sm90"
    elif _has_tcgen05(compute_capability):
        kind = "forward_sm100"
    else:
        return False
    # Shipped forward variants: paged text + non-paged vision (hd=72 bf16 non-causal).
    if (page_table is None or seqused_k is None) and not (
        head_dim == 72 and not causal and not kv_is_fp8
    ):
        return False
    variant = FlashAttnVariant(
        kind=kind,
        dtype_name="bf16",
        dtype_kv_name="fp8_e4m3" if kv_is_fp8 else None,
        head_dim=head_dim,
        causal=causal,
        mask_mod_name=mask_mod_name,
        paged_kv_non_tma=bool(dispatch_plan.paged_kv_non_tma),
        seqused_q=seqused_q is not None,
    )
    sm_count = int(torch.cuda.get_device_properties(device).multi_processor_count)
    return flash_attn_dispatch.launch_forward(
        variant, q, k_for_call, v_for_call, out,
        float(softmax_scale), float(k_scale_val), float(v_scale_val),
        seqused_q, seqused_k, page_table,
        batch_size=batch_size, seqlen_q=seqlen_q, num_heads_kv=num_head_kv,
        qhead_per_kvhead=qhead_per_kvhead, pack_gqa=bool(pack_gqa),
        sm_count=sm_count,
    )


def _flash_attn_fwd_impl(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k: Optional[torch.Tensor] = None,
    seqused_q: Optional[torch.Tensor] = None,
    seqused_k: Optional[torch.Tensor] = None,
    page_table: Optional[torch.Tensor] = None,
    softmax_scale: Optional[float] = None,
    causal: bool = False,
    softcap: Optional[float] = None,
    window_size_left: Optional[int] = None,
    window_size_right: Optional[int] = None,
    learnable_sink: Optional[torch.Tensor] = None,
    m_block_size: int = 128,
    n_block_size: int = 128,
    num_threads: int = 384,
    num_splits: int = 1,
    pack_gqa: Optional[bool] = None,
    compute_capability: Optional[tuple[int, int]] = None,
    score_mod: Optional[Callable] = None,
    mask_mod: Optional[Callable] = None,
    return_lse: bool = False,
    out: Optional[torch.Tensor] = None,
    lse: Optional[torch.Tensor] = None,
    aux_tensors: Optional[list[torch.Tensor]] = None,
    paged_kv_non_tma: Optional[bool] = None,
    k_scale: Optional[float] = None,
    v_scale: Optional[float] = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Forward pass for FlashAttention (kernel-selection + dispatch).

    Caller (`interface._flash_attn_fwd`) owns arg validation, softmax_scale
    / softcap / window-size normalization, and out/lse allocation. This
    function trusts its inputs.

    Args:
        ...
        score_mod: A callable that takes the attention scores and applies a modification.
        mask_mod: A callable that takes token position information and selectively masks
        return_lse: Whether to return the log softmax of the attention scores. If set to True will always calculate
        out: Optional pre-allocated output tensor. If None, will be allocated internally.
        lse: Optional pre-allocated log-sum-exp tensor. If None, will be allocated when needed.
        aux_tensors: Some score_mods will want to read from global aux_tensors. This is how we thread them through to the inner kernel.
    """
    # All arg validation, softmax_scale / softcap / window_size
    # normalization, and out / lse allocation is done by the caller
    # (interface._flash_attn_fwd). We only extract shape / dtype /
    # compute-capability info needed by the kernel-selection logic.
    k_scale_val = 1.0 if k_scale is None else float(k_scale)
    v_scale_val = 1.0 if v_scale is None else float(v_scale)
    kv_is_fp8 = k.dtype == torch.float8_e4m3fn

    num_head, head_dim = q.shape[-2:]
    num_head_kv = k.shape[-2]
    head_dim_v = v.shape[-1]
    qhead_per_kvhead = num_head // num_head_kv
    if pack_gqa is None:
        pack_gqa = qhead_per_kvhead > 1

    if cu_seqlens_q is None:
        batch_size, seqlen_q = q.shape[:2]
        total_q = batch_size * seqlen_q
    else:
        batch_size = cu_seqlens_q.shape[0] - 1
        seqlen_q = None
        total_q = q.shape[0]

    if page_table is not None:
        num_pages, page_size = k.shape[:2]
        seqlen_k = num_pages * page_size
    else:
        num_pages, page_size = None, None
        seqlen_k = k.shape[-3]

    q_batch_seqlen_shape = (batch_size, seqlen_q) if cu_seqlens_q is None else (total_q,)
    lse_shape = (batch_size, num_head, seqlen_q) if cu_seqlens_q is None else (num_head, total_q)

    device = q.device
    requires_grad = q.requires_grad or k.requires_grad or v.requires_grad

    cc_major, cc_minor = int(compute_capability[0]), int(compute_capability[1])
    compute_capability = cc_major
    device_sm = cc_major * 10 + cc_minor

    # `local` is derived from the caller-normalized (causal, window_*) pair.
    local = mask_mod is None and not causal and (
        window_size_left is not None or window_size_right is not None
    )

    if compute_capability == 9:  # TODO: tune block size according to hdim.
        if head_dim == head_dim_v == 128 and not causal and not local:
            n_block_size = 192

    if _has_tcgen05(compute_capability):
        # TODO: fix the varlen case
        if (
            pack_gqa
            and (128 % qhead_per_kvhead != 0)
            or (cu_seqlens_q is not None or seqused_q is not None)
        ):
            pack_gqa = False
        # TODO: fix GQA + SplitKV + non-varlen
        if pack_gqa and num_splits != 1 and cu_seqlens_q is None:
            pack_gqa = False

    if num_splits < 1:
        max_seqlen_k = seqlen_k if cu_seqlens_k is None else (cu_seqlens_k[1:] - cu_seqlens_k[:-1]).max().item()
        max_seqlen_q = seqlen_q if cu_seqlens_q is None else (cu_seqlens_q[1:] - cu_seqlens_q[:-1]).max().item()
        seqlen_q_packgqa = max_seqlen_q * qhead_per_kvhead
        seqlen_k_loaded = max_seqlen_k if not local else max(0, min(max_seqlen_k, window_size_right + window_size_left + 1 + m_block_size))
        num_n_blocks = (seqlen_k_loaded + n_block_size - 1) // n_block_size
        num_m_blocks = (seqlen_q_packgqa + m_block_size - 1) // m_block_size
        total_mblocks = batch_size * num_head_kv * num_m_blocks
        num_splits = num_splits_heuristic(
            total_mblocks,
            torch.cuda.get_device_properties(device).multi_processor_count,
            num_n_blocks,
            128,
        )

    # Optional: SM90 decode-only persistent split path (page_size==1).
    #
    # Default behavior: enable only during CUDA graph capture (decode is graph-replayed in
    # production) and only for small batches where the baseline grid under-fills the GPU.
    #
    sm90_persist_oversub = 4
    # Cross-arch B=1/2/4 sweeps on L40S, H100, B200, and RTX PRO 6000 show
    # persistent split is consistently useful for B=1 captured decode, while
    # B=2/B=4 usually lose to native decode once the extra partial-output
    # traffic and counter coordination are included.
    persistent_split_batch_limit = 1
    sm90_persistent_split_enabled = (
        torch.cuda.is_current_stream_capturing()
        and (not requires_grad)
        and device_sm in (89, 90, 100, 110, 120)
        and batch_size <= persistent_split_batch_limit
        and page_table is not None
        and page_size == 1
        and cu_seqlens_q is None
        and cu_seqlens_k is None
        and seqused_q is None
        and seqused_k is not None
        and seqlen_q == 1
        and head_dim_v == head_dim
        and score_mod is None
        and mask_mod is None
        and aux_tensors is None
        and learnable_sink is None
        # Shipped persistent-split-fused cubin variants are hd=64 only
        # (see `build_persistent_split_fused_variants` — no hd=128
        # entries). The kernel also doesn't emit LSE partials; when
        # the caller requests LSE, fall through to the non-split path.
        and head_dim == 64
        and lse is None
    )
    sm_count: int | None = None
    if sm90_persistent_split_enabled:
        sm_count = int(torch.cuda.get_device_properties(device).multi_processor_count)

    if sm90_persistent_split_enabled:
        assert sm_count is not None
        # Baseline SM90 decode launches one CTA per (batch, kv_head_group).
        # Simplified group_count heuristic — matches what the kernel class
        # would report for our shipped variants (MHA → 1; modest GQA → 1;
        # wide GQA → ceil(qhead_per_kvhead / 8)).
        group_count = 1 if qhead_per_kvhead <= 8 else (qhead_per_kvhead + 7) // 8
        head_groups = num_head_kv * group_count
        baseline_blocks = batch_size * head_groups
        # Heuristic: use split-KV when the baseline grid is too small to fill the GPU.
        #
        # For this kernel on H100 we tend to be limited to ~4 CTAs/SM (register + smem),
        # so target at least one full "wave" of work:
        #
        #   target_tasks ~= sm_count * persist_oversub
        target_tasks = int(sm_count) * int(sm90_persist_oversub)
        desired_splits = (target_tasks + baseline_blocks - 1) // max(1, baseline_blocks)
        if desired_splits <= 1:
            sm90_persistent_split_enabled = False
            # Avoid accidentally selecting the unsupported generic SplitKV path on SM90.
            num_splits = 1
        else:
            # Compile with a small fixed max_splits (for graph capture), and let the kernel compute
            # active splits from seqused_k at runtime. This makes CUDA graph replay adapt to the
            # *actual* KV work (instead of being tied to the page_table capacity used during capture).
            if head_dim == 64 and int(qhead_per_kvhead) == 1:
                # MHA decode: baseline is already 1 CTA per head, so splitting too much can be
                # net-negative (extra partial traffic + counter coordination).
                #
                # Target ~1 CTA/SM worth of split work for the common B<=4 decode graphs.
                sm90_max_splits = (int(sm_count) + baseline_blocks - 1) // max(1, baseline_blocks)
                sm90_max_splits = max(2, min(int(sm90_max_splits), 4))
            else:
                sm90_max_splits = max(2, min(int(desired_splits), 6))

            # Split-token heuristic:
            # - Target ~740-1000 decode context lengths (Moondream-ish) and keep split sizes aligned.
            if head_dim == 64 and int(qhead_per_kvhead) == 1:
                # Keep the active split count modest for typical decode lengths.
                sm90_split_tokens = 256 if sm90_max_splits >= 3 else 64
            else:
                sm90_split_tokens = 192 if head_dim == 128 else 64

            out_partial = torch.empty(
                sm90_max_splits,
                *q_batch_seqlen_shape,
                num_head,
                head_dim_v,
                dtype=torch.float32,
                device=device,
            )
            lse_partial = torch.empty(
                sm90_max_splits, *lse_shape, dtype=torch.float32, device=device
            )
            # Counter is per (batch, head_group). Use group_count from earlier.
            split_counters = _get_decode_persistent_split_fused_counters(
                device=device,
                batch_size=batch_size,
                num_kv_heads=num_head_kv,
                group_count=group_count,
            )
            if _flash_attn_decode_persistent_split_fused(
                q, k, v, out, lse,
                page_table=page_table, seqused_k=seqused_k,
                softmax_scale=softmax_scale,
                k_scale=k_scale_val, v_scale=v_scale_val,
                causal=causal, local=local,
                window_size_left=window_size_left,
                window_size_right=window_size_right,
                qhead_per_kvhead=qhead_per_kvhead,
                num_splits=sm90_max_splits,
                split_tokens=sm90_split_tokens,
                persist_oversub=sm90_persist_oversub,
                sm_count=sm_count,
                out_partial=out_partial, lse_partial=lse_partial,
                split_counters=split_counters,
            ):
                _flash_attn_fwd_impl._debug_last_impl = "decode_persistent_split_fused"
                return out, lse
            # Else: the fused variant wasn't shipped for this (head_dim,
            # num_splits, split_tokens) combo — fall through to the non-split
            # decode path below.

    if mask_mod is not None and pack_gqa:
        raise NotImplementedError(
            "mask_mod is not supported with pack_gqa=True on the cubin path."
        )

    is_split_kv = num_splits > 1
    dispatch_plan = make_forward_plan(
        device_sm=device_sm,
        compute_capability=compute_capability,
        page_table=page_table,
        page_size=page_size,
        paged_kv_non_tma=paged_kv_non_tma,
        cu_seqlens_q=cu_seqlens_q,
        cu_seqlens_k=cu_seqlens_k,
        seqused_q=seqused_q,
        seqused_k=seqused_k,
        seqlen_q=seqlen_q,
        head_dim=head_dim,
        head_dim_v=head_dim_v,
        score_mod=score_mod,
        mask_mod=mask_mod,
        aux_tensors=aux_tensors,
        learnable_sink=learnable_sink,
        is_split_kv=is_split_kv,
        kv_is_fp8=kv_is_fp8,
    )
    # SM8x / consumer Blackwell (cc=12) take the decode fastpath for paged
    # single-token decode. Eligible dense prefill is handled upstream by
    # `interface_sm8x_prefill`; anything else (paged prefill, FP8 KV prefill,
    # sliding window, etc.) has no kernel on these archs — fall back to torch.
    if compute_capability in (8, 12) and not dispatch_plan.use_decode_fastpath:
        _flash_attn_fwd_impl._debug_last_impl = "torch_sdpa_fallback"
        return flash_attn_fwd_torch_fallback(
            q=q,
            k=k,
            v=v,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            seqused_q=seqused_q,
            seqused_k=seqused_k,
            page_table=page_table,
            softmax_scale=softmax_scale,
            causal=causal,
            window_size_left=window_size_left,
            window_size_right=window_size_right,
            score_mod=score_mod,
            mask_mod=mask_mod,
            aux_tensors=aux_tensors,
            learnable_sink=learnable_sink,
            out=out,
            lse=lse,
            k_scale=k_scale_val,
            v_scale=v_scale_val,
        )

    # FP8 KV cache is supported for:
    # 1. SM80/SM86/SM87/SM89/SM90/SM100/SM120 decode fastpath
    #    (paged KV with page_size==1, seqlen_q==1)
    # 2. SM90/SM100/SM120 paged prefill with paged_kv_non_tma=True
    intra_wg_overlap = True
    if kv_is_fp8 and not dispatch_plan.use_decode_fastpath and not dispatch_plan.use_paged_prefill_fp8:
        raise NotImplementedError(
            "FP8 KV cache is currently supported only for:\n"
            "  1. SM80/SM86/SM87/SM89/SM90/SM100/SM120 decode fastpath "
            "(paged KV with page_size==1, seqlen_q==1)\n"
            "  2. SM90/SM100/SM120 paged prefill with paged_kv_non_tma=True"
        )

    # --- Cubin dispatch ----------------------------------------------------
    # Shipped variants cover the Moondream hot path. Anything else (custom
    # mask_mod, score_mod, softcap, aux_tensors, varlen cu_seqlens,
    # explicit split-kv, window / sink) takes the torch SDPA fallback —
    # we don't ship JIT for wheel installs, and training-only paths were
    # deleted in PR #22.
    if _try_cubin_launch(
        dispatch_plan=dispatch_plan, compute_capability=compute_capability,
        kv_is_fp8=kv_is_fp8, head_dim=head_dim,
        causal=causal, mask_mod=mask_mod, score_mod=score_mod, softcap=softcap,
        seqused_q=seqused_q,
        pack_gqa=pack_gqa, num_splits=num_splits, is_split_kv=is_split_kv,
        batch_size=batch_size, seqlen_q=seqlen_q, num_head_kv=num_head_kv,
        qhead_per_kvhead=qhead_per_kvhead,
        q=q, k=k, v=v, out=out, lse=lse,
        softmax_scale=softmax_scale, k_scale_val=k_scale_val, v_scale_val=v_scale_val,
        cu_seqlens_q=cu_seqlens_q, cu_seqlens_k=cu_seqlens_k,
        seqused_k=seqused_k, page_table=page_table,
        window_size_left=window_size_left, window_size_right=window_size_right,
        learnable_sink=learnable_sink, aux_tensors=aux_tensors,
        device=device,
    ):
        _flash_attn_fwd_impl._debug_last_impl = (
            decode_debug_impl_name(device_sm) if dispatch_plan.use_decode_fastpath else "fwd"
        )
        return out, lse

    _flash_attn_fwd_impl._debug_last_impl = "torch_sdpa_fallback"
    return flash_attn_fwd_torch_fallback(
        q=q, k=k, v=v,
        cu_seqlens_q=cu_seqlens_q, cu_seqlens_k=cu_seqlens_k,
        seqused_q=seqused_q, seqused_k=seqused_k, page_table=page_table,
        softmax_scale=softmax_scale, causal=causal, softcap=softcap,
        window_size_left=window_size_left, window_size_right=window_size_right,
        learnable_sink=learnable_sink, score_mod=score_mod, mask_mod=mask_mod,
        aux_tensors=aux_tensors,
        out=out, lse=lse, k_scale=k_scale_val, v_scale=v_scale_val,
    )



def _flash_attn_decode_persistent_split_fused(
    q: torch.Tensor, k: torch.Tensor, v: torch.Tensor,
    out: torch.Tensor, lse: Optional[torch.Tensor],
    *,
    page_table: torch.Tensor, seqused_k: torch.Tensor,
    softmax_scale: float, k_scale: float = 1.0, v_scale: float = 1.0,
    causal: bool, local: bool,
    window_size_left: Optional[int], window_size_right: Optional[int],
    qhead_per_kvhead: int,
    num_splits: int, split_tokens: int, persist_oversub: int, sm_count: int,
    out_partial: torch.Tensor, lse_partial: torch.Tensor,
    split_counters: torch.Tensor,
) -> bool:
    """Decode-only persistent split with in-kernel combine
    (page_size==1, seqlen_q==1). Returns True on launch, False if no
    shipped cubin matches this (head_dim, num_splits, split_tokens,
    split_tokens) tuple — caller should fall back to the non-split decode
    path. `sm_count` is used only to choose the launch grid for the current
    device; it is not part of the cubin identity. The eligibility gate in
    `_flash_attn_fwd_impl` is responsible for only calling this function
    when LSE isn't requested, no sliding window, etc.; this function does
    not validate those invariants."""
    kv_is_fp8 = k.dtype == torch.float8_e4m3fn
    variant = FlashAttnDecodePersistentSplitFusedVariant(
        dtype_name="bf16",
        dtype_kv_name="fp8_e4m3" if kv_is_fp8 else "bf16",
        head_dim=int(q.shape[-1]),
        num_splits=int(num_splits),
        split_tokens=int(split_tokens),
    )
    k_for_call = k.view(torch.uint8) if kv_is_fp8 else k
    v_for_call = v.view(torch.uint8) if kv_is_fp8 else v
    return flash_attn_dispatch.launch_persistent_split_fused(
        variant, q, k_for_call, v_for_call, out,
        float(softmax_scale), float(k_scale), float(v_scale),
        seqused_k, page_table, out_partial, lse_partial, split_counters,
        sm_count=int(sm_count),
    )
