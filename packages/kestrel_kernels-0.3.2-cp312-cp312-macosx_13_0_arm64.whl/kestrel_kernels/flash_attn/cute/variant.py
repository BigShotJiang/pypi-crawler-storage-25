"""Flash-attention kernel variants for cubin bundle lookup.

Single source of truth for the variant-key format used by both the
cubin-bundle builder in `scripts/precompile/cubin_bundles.py` and the
runtime dispatch in `dispatch.py`. Mirrors the pattern `MoeVariant` set
up in `cute_moe/config.py`.

Three dataclasses, matching the three kernel classes that survive the
PR #22 deletion:

- `FlashAttnVariant` — `FlashAttentionForwardSm90` /
  `FlashAttentionForwardSm100` / `FlashAttentionDecodeSm90`.
- `FlashAttnSm80ForwardVariant` — `FlashAttentionForwardSm80` (dense
  prefill for sm_80 / sm_86 / sm_87 / sm_89 / sm_120).
- `FlashAttnDecodePersistentSplitFusedVariant` —
  `FlashAttentionDecodePersistentSplitFused` (small-batch
  decode fast-path during CUDA graph capture).
"""

from dataclasses import dataclass
from typing import Literal, Optional


@dataclass(frozen=True)
class FlashAttnVariant:
    """Forward / decode variant for the SM90 or SM100 kernel classes.

    Identifies one shipped cubin in `bundles/flash_attn/`. Both `forward`
    variants — sm_90 and sm_100 — share this dataclass because they have
    the same variant-key schema; the arch tag baked into the key
    (`sm90` vs `sm100`) disambiguates which kernel class to instantiate.
    """

    kind: Literal["forward_sm90", "forward_sm100", "decode_sm90"]
    dtype_name: str              # "bf16"
    dtype_kv_name: Optional[str] # "bf16" / "fp8_e4m3" / None (defaults to dtype_name)
    head_dim: int
    causal: bool
    mask_mod_name: Optional[str] # "prefix_lm_730" or None
    paged_kv_non_tma: bool
    seqused_q: bool = False

    @property
    def variant_key(self) -> str:
        # Suffix rules match the post-#22 `.so` filename encoding so the
        # cubin keys are a drop-in for the old precompiled filenames.
        # `decode` always emits `_{dtype_kv_name}` even when KV matches Q
        # dtype — the decode family was shipped that way under the old
        # precompile script and tests monkeypatch against those names.
        if self.kind == "decode_sm90":
            dtype_kv = self.dtype_kv_name or self.dtype_name
            dtype_kv_str = f"_{dtype_kv}"
        else:
            dtype_kv_str = (
                f"_{self.dtype_kv_name}"
                if self.dtype_kv_name is not None and self.dtype_kv_name != self.dtype_name
                else ""
            )
        causal_str = "_causal" if self.causal else ""
        mask_str = f"_{self.mask_mod_name}" if self.mask_mod_name else ""
        paged_str = "_paged" if self.paged_kv_non_tma else ""
        seqused_q_str = "_sequsedq" if self.seqused_q else ""
        return (
            f"{self.kind}_{self.dtype_name}{dtype_kv_str}"
            f"_hd{self.head_dim}{causal_str}{mask_str}{paged_str}{seqused_q_str}"
        )


@dataclass(frozen=True)
class FlashAttnSm80ForwardVariant:
    """Prefill variant for `FlashAttentionForwardSm80`.

    Used on sm_80/86/87/89/120. MHA only. Routed to via
    `interface._flash_attn_fwd` when `sm8x_prefill.is_eligible` returns
    True.

    `dtype_kv_name=None` means KV matches Q dtype (historical default).
    `dtype_kv_name="fp8_e4m3"` selects the dual-smem FP8 path: cp.async
    into FP8 smem, convert to BF16 staging smem, then ldmatrix / mma as
    usual. See `docs/SM80_FP8_KV_DESIGN.md`.
    """

    dtype_name: str                    # "bf16"
    head_dim: int
    causal: bool
    mask_mod_name: Optional[str]       # "prefix_lm_730" or None
    dtype_kv_name: Optional[str] = None  # "fp8_e4m3" or None (= dtype_name)
    paged_kv_non_tma: bool = False
    seqused_q: bool = False

    @property
    def variant_key(self) -> str:
        dtype_kv_str = (
            f"_{self.dtype_kv_name}"
            if self.dtype_kv_name is not None and self.dtype_kv_name != self.dtype_name
            else ""
        )
        causal_str = "_causal" if self.causal else ""
        mask_str = f"_{self.mask_mod_name}" if self.mask_mod_name else ""
        paged_str = "_paged" if self.paged_kv_non_tma else ""
        seqused_q_str = "_sequsedq" if self.seqused_q else ""
        return (
            f"forward_sm80_{self.dtype_name}{dtype_kv_str}"
            f"_hd{self.head_dim}{causal_str}{mask_str}{paged_str}{seqused_q_str}"
        )


@dataclass(frozen=True)
class FlashAttnDecodePersistentSplitFusedVariant:
    """Persistent split-fused decode variant for
    `FlashAttentionDecodePersistentSplitFused`.

    Engaged during CUDA graph capture for small batches where the
    baseline grid underfills the GPU. Variant tuple identifies a
    specific (num_splits, split_tokens) compile-time point; the device
    SM count is a runtime launch parameter.
    """

    dtype_name: str              # "bf16"
    dtype_kv_name: str           # "bf16" / "fp8_e4m3"
    head_dim: int
    num_splits: int
    split_tokens: int

    @property
    def variant_key(self) -> str:
        return (
            f"persistent_split_fused_decode_{self.dtype_name}_{self.dtype_kv_name}"
            f"_hd{self.head_dim}_s{self.num_splits}_t{self.split_tokens}"
        )


# ---------------------------------------------------------------------------
# Shipped variant inventory — the kernel/arch combinations compiled into
# `bundles/flash_attn/` and dispatched at runtime. Imported by both the
# cubin-bundle builder and the runtime resolver.
# ---------------------------------------------------------------------------

_FORWARD_DECODE_VARIANTS_COMMON = [
    # Text forward (causal, paged, BF16 KV)
    ("forward", "bf16", None, 64, True, None, True, False),
    ("forward", "bf16", None, 64, True, None, True, True),
    # Text forward (causal, paged, FP8 KV)
    ("forward", "bf16", "fp8_e4m3", 64, True, None, True, False),
    ("forward", "bf16", "fp8_e4m3", 64, True, None, True, True),
    # Text forward (prefix-lm mask, paged, BF16 KV)
    ("forward", "bf16", None, 64, False, "prefix_lm_730", True, False),
    ("forward", "bf16", None, 64, False, "prefix_lm_730", True, True),
    # Text forward (prefix-lm mask, paged, FP8 KV)
    ("forward", "bf16", "fp8_e4m3", 64, False, "prefix_lm_730", True, False),
    ("forward", "bf16", "fp8_e4m3", 64, False, "prefix_lm_730", True, True),
    # Vision forward (non-paged, non-causal)
    ("forward", "bf16", None, 72, False, None, False, False),
]

_DECODE_VARIANTS = [
    # Text decode (BF16 KV)
    ("decode", "bf16", "bf16", 64, True, None, False, False),
    # Text decode (FP8 KV)
    ("decode", "bf16", "fp8_e4m3", 64, True, None, False, False),
]


def build_sm90_variants() -> list[FlashAttnVariant]:
    """All forward + decode variants shipped for SM90."""
    out: list[FlashAttnVariant] = []
    for (_, dt, dt_kv, hd, causal, mask, paged, sq) in _FORWARD_DECODE_VARIANTS_COMMON:
        out.append(FlashAttnVariant(
            kind="forward_sm90",
            dtype_name=dt, dtype_kv_name=dt_kv, head_dim=hd,
            causal=causal, mask_mod_name=mask, paged_kv_non_tma=paged,
            seqused_q=sq,
        ))
    for (_, dt, dt_kv, hd, causal, mask, paged, sq) in _DECODE_VARIANTS:
        out.append(FlashAttnVariant(
            kind="decode_sm90",
            dtype_name=dt, dtype_kv_name=dt_kv, head_dim=hd,
            causal=causal, mask_mod_name=mask, paged_kv_non_tma=paged,
            seqused_q=sq,
        ))
    return out


def build_sm100_variants() -> list[FlashAttnVariant]:
    """Forward + decode variants shipped for SM100 (datacenter Blackwell,
    the only arch that uses the tcgen05 `FlashAttentionForwardSm100`)."""
    out: list[FlashAttnVariant] = []
    for (_, dt, dt_kv, hd, causal, mask, paged, sq) in _FORWARD_DECODE_VARIANTS_COMMON:
        out.append(FlashAttnVariant(
            kind="forward_sm100",
            dtype_name=dt, dtype_kv_name=dt_kv, head_dim=hd,
            causal=causal, mask_mod_name=mask, paged_kv_non_tma=paged,
            seqused_q=sq,
        ))
    for (_, dt, dt_kv, hd, causal, mask, paged, sq) in _DECODE_VARIANTS:
        out.append(FlashAttnVariant(
            kind="decode_sm90",
            dtype_name=dt, dtype_kv_name=dt_kv, head_dim=hd,
            causal=causal, mask_mod_name=mask, paged_kv_non_tma=paged,
            seqused_q=sq,
        ))
    return out


def build_sm80_family_decode_variants() -> list[FlashAttnVariant]:
    """Decode variants for sm_80/86/87/89/120 (all share the SM90 decode
    kernel class — the `arch` param on `FlashAttentionDecodeSm90` handles
    the target)."""
    return [
        FlashAttnVariant(
            kind="decode_sm90",
            dtype_name=dt, dtype_kv_name=dt_kv, head_dim=hd,
            causal=causal, mask_mod_name=mask, paged_kv_non_tma=paged,
            seqused_q=sq,
        )
        for (_, dt, dt_kv, hd, causal, mask, paged, sq) in _DECODE_VARIANTS
    ]


def build_sm80_forward_variants() -> list[FlashAttnSm80ForwardVariant]:
    """SM80 prefill variants for sm_80/86/87/89/120."""
    return [
        # BF16 KV (vision and text paths).
        FlashAttnSm80ForwardVariant("bf16", 72, False, None),
        FlashAttnSm80ForwardVariant("bf16", 64, True, None),
        FlashAttnSm80ForwardVariant("bf16", 64, True, None, None, True),
        FlashAttnSm80ForwardVariant("bf16", 64, True, None, None, True, True),
        FlashAttnSm80ForwardVariant("bf16", 64, False, "prefix_lm_730"),
        FlashAttnSm80ForwardVariant("bf16", 64, False, "prefix_lm_730", None, True),
        FlashAttnSm80ForwardVariant("bf16", 64, False, "prefix_lm_730", None, True, True),
        # FP8 KV (text paths only — vision runs don't store FP8 KV).
        FlashAttnSm80ForwardVariant("bf16", 64, True, None, "fp8_e4m3"),
        FlashAttnSm80ForwardVariant("bf16", 64, True, None, "fp8_e4m3", True),
        FlashAttnSm80ForwardVariant("bf16", 64, True, None, "fp8_e4m3", True, True),
        FlashAttnSm80ForwardVariant("bf16", 64, False, "prefix_lm_730", "fp8_e4m3"),
        FlashAttnSm80ForwardVariant("bf16", 64, False, "prefix_lm_730", "fp8_e4m3", True),
        FlashAttnSm80ForwardVariant("bf16", 64, False, "prefix_lm_730", "fp8_e4m3", True, True),
    ]


def build_persistent_split_fused_variants() -> list[FlashAttnDecodePersistentSplitFusedVariant]:
    """Persistent split-fused decode variants."""
    out: list[FlashAttnDecodePersistentSplitFusedVariant] = []
    for (dt, dt_kv, hd, nsplits, split_tokens) in [
        # BF16 KV (num_splits 2-4, split_tokens 64 or 256)
        ("bf16", "bf16", 64, 2, 64),
        ("bf16", "bf16", 64, 2, 256),
        ("bf16", "bf16", 64, 3, 64),
        ("bf16", "bf16", 64, 3, 256),
        ("bf16", "bf16", 64, 4, 64),
        ("bf16", "bf16", 64, 4, 256),
        # FP8 KV
        ("bf16", "fp8_e4m3", 64, 2, 64),
        ("bf16", "fp8_e4m3", 64, 2, 256),
        ("bf16", "fp8_e4m3", 64, 3, 64),
        ("bf16", "fp8_e4m3", 64, 3, 256),
        ("bf16", "fp8_e4m3", 64, 4, 64),
        ("bf16", "fp8_e4m3", 64, 4, 256),
    ]:
        out.append(FlashAttnDecodePersistentSplitFusedVariant(
            dtype_name=dt, dtype_kv_name=dt_kv, head_dim=hd,
            num_splits=nsplits, split_tokens=split_tokens,
        ))
    return out


__all__ = [
    "FlashAttnVariant",
    "FlashAttnSm80ForwardVariant",
    "FlashAttnDecodePersistentSplitFusedVariant",
    "build_sm90_variants",
    "build_sm100_variants",
    "build_sm80_family_decode_variants",
    "build_sm80_forward_variants",
    "build_persistent_split_fused_variants",
]
