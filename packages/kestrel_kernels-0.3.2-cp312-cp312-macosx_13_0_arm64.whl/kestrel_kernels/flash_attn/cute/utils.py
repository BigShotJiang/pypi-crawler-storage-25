# Copyright (c) 2025, Tri Dao.

import math
import re
from typing import Type, Callable, Optional, Tuple, overload
from functools import partial

import cutlass
import cutlass.cute as cute

from cutlass import Float32, Int32, const_expr
from cutlass.cutlass_dsl import T, dsl_user_op
from cutlass._mlir.dialects import nvvm, llvm
from cutlass.cute.runtime import from_dlpack


# cute.arch.{fma,mul,add}_packed_f32x2 uses RZ rounding mode by default
fma_packed_f32x2 = partial(cute.arch.fma_packed_f32x2, rnd=nvvm.RoundingModeKind.RN)
mul_packed_f32x2 = partial(cute.arch.mul_packed_f32x2, rnd=nvvm.RoundingModeKind.RN)
add_packed_f32x2 = partial(cute.arch.add_packed_f32x2, rnd=nvvm.RoundingModeKind.RN)
sub_packed_f32x2 = partial(
    cute.arch.calc_packed_f32x2_op,
    src_c=None,
    calc_func=nvvm.sub_packed_f32x2,
    rnd=nvvm.RoundingModeKind.RN,
)


def create_softcap_scoremod(softcap_val):
    inv_softcap = 1.0 / softcap_val

    @cute.jit
    def scoremod_premask_fn(acc_S_SSA, batch_idx, head_idx, q_idx, kv_idx, aux_tensors):
        scores = acc_S_SSA * inv_softcap
        return scores * cute.math.tanh(scores, fastmath=True)

    return scoremod_premask_fn


def convert_from_dlpack(x, leading_dim, alignment=16, divisibility=1, enable_tvm_ffi=False) -> cute.Tensor:
    return (
        from_dlpack(x, assumed_align=alignment, enable_tvm_ffi=enable_tvm_ffi)
        .mark_layout_dynamic(leading_dim=leading_dim)
        .mark_compact_shape_dynamic(
            mode=leading_dim, stride_order=x.dim_order(), divisibility=divisibility
        )
    )


def convert_from_dlpack_leading_static(
    x, leading_dim, alignment=16, static_modes=None, stride_order=None
) -> cute.Tensor:
    if stride_order is None:
        stride_order = x.dim_order()
    x_ = from_dlpack(x, assumed_align=alignment)
    for i in range(x.ndim):
        if i != leading_dim and (static_modes is None or i not in static_modes):
            x_ = x_.mark_compact_shape_dynamic(mode=i, stride_order=stride_order)
    return x_


def make_tiled_copy_A(
    copy_atom: cute.CopyAtom, tiled_mma: cute.TiledMma, swapAB: cutlass.Constexpr[bool] = False
) -> cute.TiledCopy:
    if const_expr(swapAB):
        return cute.make_tiled_copy_B(copy_atom, tiled_mma)
    else:
        return cute.make_tiled_copy_A(copy_atom, tiled_mma)


def make_tiled_copy_B(
    copy_atom: cute.CopyAtom, tiled_mma: cute.TiledMma, swapAB: cutlass.Constexpr[bool] = False
) -> cute.TiledCopy:
    if const_expr(swapAB):
        return cute.make_tiled_copy_A(copy_atom, tiled_mma)
    else:
        return cute.make_tiled_copy_B(copy_atom, tiled_mma)


def mma_make_fragment_A(
    smem: cute.Tensor, thr_mma: cute.core.ThrMma, swapAB: cutlass.Constexpr[bool] = False
) -> cute.Tensor:
    if const_expr(swapAB):
        return mma_make_fragment_B(smem, thr_mma)
    else:
        return thr_mma.make_fragment_A(thr_mma.partition_A(smem))


def mma_make_fragment_B(
    smem: cute.Tensor, thr_mma: cute.core.ThrMma, swapAB: cutlass.Constexpr[bool] = False
) -> cute.Tensor:
    if const_expr(swapAB):
        return mma_make_fragment_A(smem, thr_mma)
    else:
        return thr_mma.make_fragment_B(thr_mma.partition_B(smem))


def get_smem_store_atom(
    arch: cutlass.Constexpr[int], element_type: Type[cute.Numeric], transpose: bool = False
) -> cute.CopyAtom:
    if const_expr(arch < 90 or element_type.width != 16):
        return cute.make_copy_atom(
            cute.nvgpu.CopyUniversalOp(),
            element_type,
            num_bits_per_copy=2 * element_type.width,
        )
    else:
        return cute.make_copy_atom(
            cute.nvgpu.warp.StMatrix8x8x16bOp(transpose=transpose, num_matrices=4),
            element_type,
        )


@cute.jit
def warp_reduce(
    val: cute.TensorSSA | cute.Numeric,
    op: Callable,
    width: cutlass.Constexpr[int] = cute.arch.WARP_SIZE,
) -> cute.TensorSSA | cute.Numeric:
    if const_expr(isinstance(val, cute.TensorSSA)):
        res = cute.make_rmem_tensor(val.shape, val.dtype)
        res.store(val)
        for i in cutlass.range_constexpr(cute.size(val.shape)):
            res[i] = warp_reduce(res[i], op, width)
        return res.load()
    else:
        for i in cutlass.range_constexpr(int(math.log2(width))):
            val = op(val, cute.arch.shuffle_sync_bfly(val, offset=1 << i))
    return val


def convert_layout_acc_mn(acc_layout: cute.Layout, transpose: bool = False) -> cute.Layout:
    """
    For Sm80, convert ((2, 2), MMA_M, MMA_N, ...) to ((2, MMA_M), (2, MMA_N), ...).
    For Sm90, convert ((2, 2, V), MMA_M, MMA_N, ...) to ((2, MMA_M), (2, V, MMA_N), ...).
    """
    acc_layout_col_major = cute.make_layout(acc_layout.shape)
    shape = (
        (acc_layout_col_major.shape[0][1], acc_layout_col_major.shape[1]),  # MMA_M
        (
            acc_layout_col_major.shape[0][0],
            *acc_layout_col_major.shape[0][2:],
            acc_layout_col_major.shape[2],
        ),  # MMA_N
        *acc_layout_col_major.shape[3:],
    )
    stride = (
        (acc_layout_col_major.stride[0][1], acc_layout_col_major.stride[1]),  # MMA_M
        (
            acc_layout_col_major.stride[0][0],
            *acc_layout_col_major.stride[0][2:],
            acc_layout_col_major.stride[2],
        ),  # MMA_N
        *acc_layout_col_major.stride[3:],
    )
    if const_expr(transpose):
        shape = (shape[1], shape[0], *shape[2:])
        stride = (stride[1], stride[0], *stride[2:])
    acc_layout_mn = cute.make_layout(shape, stride=stride)
    return cute.composition(acc_layout, acc_layout_mn)


def make_acc_tensor_mn_view(acc: cute.Tensor, transpose: bool = False) -> cute.Tensor:
    return cute.make_tensor(acc.iterator, convert_layout_acc_mn(acc.layout, transpose=transpose))


@cute.jit
def convert_layout_acc_frgA(acc_layout: cute.Layout) -> cute.Layout:
    # For back to back gemm, convert layout of acc0 to gemm 1 accept layout.
    # For Sm80, as the mma instruction shape is 16x8x16, we need to convert from (4, MMA_M, MMA_N) to ((4, 2), MMA_M, MMA_N / 2)
    # For Sm90, FP16/BF16, convert acc_layout from ((2, 2, N / 8), MMA_M, MMA_N) to ((2, 2, 2), MMA_M, (N / 16, MMA_N))
    # TODO: Sm90 FP8
    if const_expr(cute.rank(acc_layout.shape[0]) == 3):  # Sm90
        l = cute.logical_divide(
            acc_layout, ((None, None, 2), None, None)
        )  # ((2, 2, (2, N / 16)), MMA_M, MMA_N)
        rA_mma_view = cute.make_layout(
            (
                (l.shape[0][0], l.shape[0][1], l.shape[0][2][0]),
                l.shape[1],
                (l.shape[0][2][1], l.shape[2]),
            ),
            stride=(
                (l.stride[0][0], l.stride[0][1], l.stride[0][2][0]),
                l.stride[1],
                (l.stride[0][2][1], l.stride[2]),
            ),
        )
    else:  # Sm80
        # (4, MMA_M, MMA_N) -> (4, MMA_M, (2, MMA_N / 2))
        l = cute.logical_divide(acc_layout, (None, None, 2))
        rA_mma_view = cute.make_layout(
            (
                (l.shape[0], l.shape[2][0]),
                l.shape[1],
                l.shape[2][1],
            ),
            stride=(
                (l.stride[0], l.stride[2][0]),
                l.stride[1],
                l.stride[2][1],
            ),
        )
    return rA_mma_view


def make_acc_tensor_frgA_view(acc: cute.Tensor) -> cute.Tensor:
    return cute.make_tensor(acc.iterator, convert_layout_acc_frgA(acc.layout))


def select(a: cute.Tensor, mode: list[int]) -> cute.Tensor:
    return cute.make_tensor(a.iterator, cute.select(a.layout, mode))


def transpose_view(a: cute.Tensor) -> cute.Tensor:
    """Transpose the first two dimensions of a tensor on smem."""
    shape = (a.shape[1], a.shape[0], *a.shape[2:])
    order = (1, 0, *range(2, cute.rank(a)))
    return cute.composition(a, cute.make_ordered_layout(shape, order=order))
    # stride = (a.layout.stride[1], a.layout.stride[0], *a.layout.stride[2:])
    # return cute.make_tensor(a.iterator, cute.make_layout(shape, stride=stride))


def parse_swizzle_from_pointer(ptr: cute.Pointer) -> cute.Swizzle:
    """Extract swizzle parameters from a pointer's swizzle_type.

    The swizzle_type string has the form '!cute.swizzle<"S<b,m,s>">' where
    b, m, s are the swizzle parameters (bits, base, shift).

    Returns:
        A cute.Swizzle object constructed from the extracted parameters

    Raises:
        ValueError: If the swizzle_type string cannot be parsed
    """
    # Ideally there should be a better API to get swizzle parameters, but we'll just parse
    # the string here.
    swizzle_str = str(ptr.type.swizzle_type)
    # Extract the inner part "S<b,m,s>"
    match = re.search(r"S<(\d+),(\d+),(\d+)>", swizzle_str)
    if match:
        b, m, s = int(match.group(1)), int(match.group(2)), int(match.group(3))
        return cute.make_swizzle(b, m, s)
    else:
        raise ValueError(f"Could not parse swizzle_type: {swizzle_str}")


@cute.jit
def exp2f(x: cute.TensorSSA | Float32) -> cute.TensorSSA | Float32:
    """exp2f calculation for both vector and scalar.
    :param x: input value
    :type x: cute.TensorSSA or Float32
    :return: exp2 value
    :rtype: cute.TensorSSA or Float32
    """
    if const_expr(isinstance(x, cute.TensorSSA)):
        res = cute.make_rmem_tensor(x.shape, Float32)
        res.store(x)
        for i in cutlass.range_constexpr(cute.size(x.shape)):
            res[i] = cute.math.exp2(res[i], fastmath=True)
        return res.load()
    else:
        return cute.math.exp2(x, fastmath=True)


@dsl_user_op
def log2f(a: float | Float32, *, loc=None, ip=None) -> Float32:
    return Float32(
        llvm.inline_asm(
            T.f32(),
            [Float32(a).ir_value(loc=loc, ip=ip)],
            "lg2.approx.ftz.f32 $0, $1;",
            "=f,f",
            has_side_effects=False,
            is_align_stack=False,
            asm_dialect=llvm.AsmDialect.AD_ATT,
        )
    )


@dsl_user_op
def logf(a: float | Float32, *, loc=None, ip=None) -> Float32:
    return log2f(a, loc=loc, ip=ip) * math.log(2.0)


@dsl_user_op
def fmax(
    a: float | Float32, b: float | Float32, c: float | Float32 | None = None, *, loc=None, ip=None
) -> Float32:
    from cutlass import CUDA_VERSION

    if CUDA_VERSION.major == 12 and CUDA_VERSION.minor == 9:
        return Float32(
            nvvm.fmax(
                T.f32(),
                Float32(a).ir_value(loc=loc, ip=ip),
                Float32(b).ir_value(loc=loc, ip=ip),
                c=Float32(c).ir_value(loc=loc, ip=ip) if c is not None else None,
                loc=loc,
                ip=ip,
            )
        )
    return Float32(
        nvvm.fmax(
            Float32(a).ir_value(loc=loc, ip=ip),
            Float32(b).ir_value(loc=loc, ip=ip),
            c=Float32(c).ir_value(loc=loc, ip=ip) if c is not None else None,
            loc=loc,
            ip=ip,
        )
    )


@cute.jit
def fmax_reduce(
    x: cute.TensorSSA, init_val: float | Float32 | None = None, arch: cutlass.Constexpr[int] = 80
) -> Float32:
    if const_expr(arch < 100 or cute.size(x.shape) % 8 != 0):
        # if const_expr(init_val is None):
        #     init_val = -cutlass.Float32.if
        # return x.reduce(cute.ReductionOp.MAX, init_val, 0)
        res = cute.make_rmem_tensor(x.shape, Float32)
        res.store(x)
        # local_max = [res[0], res[1]]
        # for i in cutlass.range_constexpr(2, cute.size(x.shape), 2):
        #     local_max[0] = fmax(local_max[0], res[i + 0])
        #     local_max[1] = fmax(local_max[1], res[i + 1])
        # local_max[0] = fmax(local_max[0], local_max[1])
        # return local_max[0] if const_expr(init_val is None) else fmax(local_max[0], init_val)
        local_max = [res[0], res[1], res[2], res[3]]
        for i in cutlass.range_constexpr(4, cute.size(x.shape), 4):
            local_max[0] = fmax(local_max[0], res[i + 0])
            local_max[1] = fmax(local_max[1], res[i + 1])
            local_max[2] = fmax(local_max[2], res[i + 2])
            local_max[3] = fmax(local_max[3], res[i + 3])
        local_max[0] = fmax(local_max[0], local_max[1])
        local_max[2] = fmax(local_max[2], local_max[3])
        local_max[0] = fmax(local_max[0], local_max[2])
        return local_max[0] if const_expr(init_val is None) else fmax(local_max[0], init_val)
    else:
        # [2025-06-15] x.reduce only seems to use 50% 3-input max and 50% 2-input max
        # We instead force the 3-input max.
        res = cute.make_rmem_tensor(x.shape, Float32)
        res.store(x)
        local_max_0 = (
            fmax(init_val, res[0], res[1])
            if const_expr(init_val is not None)
            else fmax(res[0], res[1])
        )
        local_max = [
            local_max_0,
            fmax(res[2], res[3]),
            fmax(res[4], res[5]),
            fmax(res[6], res[7]),
        ]
        for i in cutlass.range_constexpr(8, cute.size(x.shape), 8):
            local_max[0] = fmax(local_max[0], res[i], res[i + 1])
            local_max[1] = fmax(local_max[1], res[i + 2], res[i + 3])
            local_max[2] = fmax(local_max[2], res[i + 4], res[i + 5])
            local_max[3] = fmax(local_max[3], res[i + 6], res[i + 7])
        local_max[0] = fmax(local_max[0], local_max[1])
        return fmax(local_max[0], local_max[2], local_max[3])


@cute.jit
def fadd_reduce(
    x: cute.TensorSSA, init_val: float | Float32 | None = None, arch: cutlass.Constexpr[int] = 80
) -> Float32:
    if const_expr(arch < 100 or cute.size(x.shape) % 8 != 0):
        if const_expr(init_val is None):
            init_val = Float32.zero
        return x.reduce(cute.ReductionOp.ADD, init_val, 0)
        # res = cute.make_fragment(x.shape, Float32)
        # res.store(x)
        # local_sum = [res[0], res[1], res[2], res[3]]
        # for i in cutlass.range_constexpr(4, cute.size(x.shape), 4):
        #     local_sum[0] += res[i + 0]
        #     local_sum[1] += res[i + 1]
        #     local_sum[2] += res[i + 2]
        #     local_sum[3] += res[i + 3]
        # local_sum[0] += local_sum[1]
        # local_sum[2] += local_sum[3]
        # local_sum[0] += local_sum[2]
        # return local_sum[0] if const_expr(init_val is None) else local_sum[0] + init_val
    else:
        res = cute.make_rmem_tensor(x.shape, Float32)
        res.store(x)
        local_sum_0 = (
            add_packed_f32x2((init_val, 0.0), (res[0], res[1]))
            # add_packed_f32x2((init_val / 2, init_val / 2), (res[0], res[1]))
            if const_expr(init_val is not None)
            else (res[0], res[1])
        )
        local_sum = [local_sum_0, (res[2], res[3]), (res[4], res[5]), (res[6], res[7])]
        for i in cutlass.range_constexpr(8, cute.size(x.shape), 8):
            local_sum[0] = add_packed_f32x2(local_sum[0], (res[i + 0], res[i + 1]))
            local_sum[1] = add_packed_f32x2(local_sum[1], (res[i + 2], res[i + 3]))
            local_sum[2] = add_packed_f32x2(local_sum[2], (res[i + 4], res[i + 5]))
            local_sum[3] = add_packed_f32x2(local_sum[3], (res[i + 6], res[i + 7]))
        local_sum[0] = add_packed_f32x2(local_sum[0], local_sum[1])
        local_sum[2] = add_packed_f32x2(local_sum[2], local_sum[3])
        local_sum[0] = add_packed_f32x2(local_sum[0], local_sum[2])
        return local_sum[0][0] + local_sum[0][1]


@dsl_user_op
def atomic_add_fp32(a: float | Float32, gmem_ptr: cute.Pointer, *, loc=None, ip=None) -> None:
    # gmem_ptr_i64 = gmem_ptr.toint(loc=loc, ip=ip).ir_value()
    # # cache_hint = cutlass.Int64(0x12F0000000000000)
    # llvm.inline_asm(
    #     None,
    #     [gmem_ptr_i64, Float32(a).ir_value(loc=loc, ip=ip)],
    #     # [gmem_ptr_i64, Float32(a).ir_value(loc=loc, ip=ip), cache_hint.ir_value()],
    #     "red.global.add.f32 [$0], $1;",
    #     # "red.global.add.L2::cache_hint.f32 [$0], $1, 0x12F0000000000000;",
    #     # "red.global.add.L2::cache_hint.f32 [$0], $1, $2;",
    #     "l,f",
    #     # "l,f,l",
    #     has_side_effects=True,
    #     is_align_stack=False,
    #     asm_dialect=llvm.AsmDialect.AD_ATT,
    # )
    nvvm.atomicrmw(
        res=T.f32(), op=nvvm.AtomicOpKind.FADD, ptr=gmem_ptr.llvm_ptr, a=Float32(a).ir_value()
    )


@dsl_user_op
def atomic_add_acq_rel_i32(a: int | Int32, gmem_ptr: cute.Pointer, *, loc=None, ip=None) -> Int32:
    gmem_ptr_i64 = gmem_ptr.toint(loc=loc, ip=ip).ir_value()
    old = llvm.inline_asm(
        T.i32(),
        [gmem_ptr_i64, Int32(a).ir_value(loc=loc, ip=ip)],
        "atom.global.add.acq_rel.gpu.s32 $0, [$1], $2;",
        "=r,l,r",
        has_side_effects=True,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
    )
    return cutlass.Int32(old)


@dsl_user_op
def atomic_add_release_i32(a: int | Int32, gmem_ptr: cute.Pointer, *, loc=None, ip=None) -> Int32:
    gmem_ptr_i64 = gmem_ptr.toint(loc=loc, ip=ip).ir_value()
    old = llvm.inline_asm(
        T.i32(),
        [gmem_ptr_i64, Int32(a).ir_value(loc=loc, ip=ip)],
        "atom.global.add.release.gpu.s32 $0, [$1], $2;",
        "=r,l,r",
        has_side_effects=True,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
    )
    return cutlass.Int32(old)


@dsl_user_op
def ld_acquire_i32(gmem_ptr: cute.Pointer, *, loc=None, ip=None) -> Int32:
    gmem_ptr_i64 = gmem_ptr.toint(loc=loc, ip=ip).ir_value()
    val = llvm.inline_asm(
        T.i32(),
        [gmem_ptr_i64],
        "ld.global.acquire.gpu.b32 $0, [$1];",
        "=r,l",
        has_side_effects=True,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
    )
    return cutlass.Int32(val)


@dsl_user_op
def atomic_exch_i32(a: int | Int32, gmem_ptr: cute.Pointer, *, loc=None, ip=None) -> Int32:
    return cutlass.Int32(
        nvvm.atomicrmw(
            res=T.i32(),
            op=nvvm.AtomicOpKind.EXCH,
            ptr=gmem_ptr.llvm_ptr,
            a=Int32(a).ir_value(),
        )
    )


@dsl_user_op
def fence_sc_gpu(*, loc=None, ip=None) -> None:
    nvvm.fence_sc_gpu()


@dsl_user_op
def elem_pointer(x: cute.Tensor, coord: cute.Coord, *, loc=None, ip=None) -> cute.Pointer:
    return x.iterator + cute.crd2idx(coord, x.layout, loc=loc, ip=ip)


@dsl_user_op
def elem_pointer_i64(x: cute.Tensor, coord: cute.Coord, *, loc=None, ip=None) -> cute.Pointer:
    flat_coord_i64 = tuple(cutlass.Int64(c) for c in cute.flatten(coord))
    flat_stride = cute.flatten_to_tuple(x.stride)
    assert len(flat_coord_i64) == len(flat_stride), (
        "Coordinate and stride must have the same length"
    )
    offset = sum(c * s for c, s in zip(flat_coord_i64, flat_stride))
    # HACK: we assume that applying the offset does not change the pointer alignment
    byte_offset = offset * x.element_type.width // 8
    return cute.make_ptr(
        x.element_type,
        x.iterator.toint() + byte_offset,
        x.memspace,
        assumed_align=x.iterator.alignment,
    )


@cute.jit
def predicate_k(tAcA: cute.Tensor, limit: cutlass.Int32) -> cute.Tensor:
    # Only compute predicates for the "k" dimension. For the mn dimension, we will use "if"
    tApA = cute.make_rmem_tensor(
        cute.make_layout(
            (cute.size(tAcA, mode=[0, 1]), cute.size(tAcA, mode=[1]), cute.size(tAcA, mode=[2])),
            stride=(cute.size(tAcA, mode=[2]), 0, 1),
        ),
        cutlass.Boolean,
    )
    for rest_v in cutlass.range_constexpr(tApA.shape[0]):
        for rest_k in cutlass.range_constexpr(tApA.shape[2]):
            tApA[rest_v, 0, rest_k] = cute.elem_less(tAcA[(0, rest_v), 0, rest_k][1], limit)
    return tApA


def canonical_warp_group_idx(sync: bool = True) -> cutlass.Int32:
    warp_group_idx = cute.arch.thread_idx()[0] // 128
    if const_expr(sync):
        warp_group_idx = cute.arch.make_warp_uniform(warp_group_idx)
    return warp_group_idx


# @dsl_user_op
# def warp_vote_any_lt(a: float | Float32, b: float | Float32, *, loc=None, ip=None) -> cutlass.Boolean:
#     mask = cutlass.Int32(-1)
#     return cutlass.Boolean(
#         llvm.inline_asm(
#             T.i32(),
#             [Float32(a).ir_value(loc=loc, ip=ip), Float32(b).ir_value(loc=loc, ip=ip), mask.ir_value(loc=loc, ip=ip)],
#             ".pred p1, p2;\n"
#             "setp.lt.f32 p1, $1, $2;\n"
#             "vote.sync.any.pred p2, p1, $3;\n"
#             "selp.u32 $0, 1, 0, p2;",
#             # "selp.u32 $0, 1, 0, p1;",
#             "=r,f,f,r",
#             has_side_effects=False,
#             is_align_stack=False,
#             asm_dialect=llvm.AsmDialect.AD_ATT,
#         )
#     )


@cute.jit
def shuffle_sync(
    value: cute.Numeric,
    offset: cute.typing.Int,
    width: cutlass.Constexpr[int] = cute.arch.WARP_SIZE,
) -> cute.Numeric:
    assert value.width % 32 == 0, "value type must be a multiple of 32 bits"
    # 1 -> 0b11111, 2 -> 0b11110, 4 -> 0b11100, 8 -> 0b11000, 16 -> 0b10000, 32 -> 0b00000
    mask = cute.arch.WARP_SIZE - width
    clamp = cute.arch.WARP_SIZE - 1
    mask_and_clamp = mask << 8 | clamp
    val = cute.make_rmem_tensor(1, type(value))
    val[0] = value
    val_i32 = cute.recast_tensor(val, cutlass.Int32)
    for i in cutlass.range_constexpr(cute.size(val_i32)):
        val_i32[i] = cute.arch.shuffle_sync(val_i32[i], offset, mask_and_clamp=mask_and_clamp)
    return val[0]


@dsl_user_op
def shr_u32(val: cutlass.Uint32, shift: cutlass.Uint32, *, loc=None, ip=None) -> cutlass.Uint32:
    return cutlass.Uint32(
        llvm.inline_asm(
            T.i32(),
            [
                cutlass.Uint32(val).ir_value(loc=loc, ip=ip),
                cutlass.Uint32(shift).ir_value(loc=loc, ip=ip),
            ],
            "shr.s32 $0, $1, $2;",
            "=r,r,r",
            has_side_effects=False,
            is_align_stack=False,
            asm_dialect=llvm.AsmDialect.AD_ATT,
        )
    )


@cute.jit
def warp_prefix_sum(val: cutlass.Int32, lane: Optional[cutlass.Int32] = None) -> cutlass.Int32:
    if const_expr(lane is None):
        lane = cute.arch.lane_idx()
    # if cute.arch.thread_idx()[0] >= 128 and cute.arch.thread_idx()[0] < 128 + 32 and cute.arch.block_idx()[0] == 0: cute.printf("tidx = %d, val = %d", cute.arch.thread_idx()[0] % 32, val)
    for i in cutlass.range_constexpr(int(math.log2(cute.arch.WARP_SIZE))):
        offset = 1 << i
        # Very important that we set mask_and_clamp to 0
        partial_sum = cute.arch.shuffle_sync_up(val, offset=offset, mask_and_clamp=0)
        if lane >= offset:
            val += partial_sum
        # if cute.arch.thread_idx()[0] >= 128 and cute.arch.thread_idx()[0] < 128 + 32 and cute.arch.block_idx()[0] == 0: cute.printf("tidx = %d, partial_sum = %d, val = %d", cute.arch.thread_idx()[0] % 32, partial_sum, val)
    return val


@dsl_user_op
def cvt_f16x2_f32(
    a: float | Float32, b: float | Float32, to_dtype: Type, *, loc=None, ip=None
) -> cutlass.Int32:
    assert to_dtype in [cutlass.BFloat16, cutlass.Float16], "to_dtype must be BFloat16 or Float16"
    return cutlass.Int32(
        llvm.inline_asm(
            T.i32(),
            [Float32(a).ir_value(loc=loc, ip=ip), Float32(b).ir_value(loc=loc, ip=ip)],
            f"cvt.rn.{'bf16x2' if to_dtype is cutlass.BFloat16 else 'f16x2'}.f32 $0, $2, $1;",
            "=r,f,f",
            has_side_effects=False,
            is_align_stack=False,
            asm_dialect=llvm.AsmDialect.AD_ATT,
        )
    )


@dsl_user_op
def cvt_fp8x2_to_f16_both(packed_fp8_in_f16, *, loc=None, ip=None):
    """Convert 2 packed E4M3 FP8 values into 2 FP16 scalars.

    PTX uses `cvt.rn.f16x2.e4m3x2`, which is supported on sm89+.
    Input is a 16-bit register value (passed via an f16-typed lane) containing
    two packed FP8 bytes.
    """
    from cutlass._mlir import ir
    from cutlass._mlir.dialects import arith

    ir_f16 = packed_fp8_in_f16.ir_value(loc=loc, ip=ip)
    ir_i16 = llvm.bitcast(T.i16(), ir_f16, loc=loc, ip=ip)
    result_i32 = llvm.inline_asm(
        T.i32(),
        [ir_i16],
        "cvt.rn.f16x2.e4m3x2 $0, $1;",
        "=r,h",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )

    f16_type = ir.F16Type.get()
    vec_type = ir.VectorType.get([2], f16_type)
    vec_f16x2 = llvm.bitcast(vec_type, result_i32, loc=loc, ip=ip)
    idx_0 = arith.constant(T.i32(), 0, loc=loc, ip=ip)
    idx_1 = arith.constant(T.i32(), 1, loc=loc, ip=ip)
    f16_lo = llvm.extractelement(vec_f16x2, idx_0, loc=loc, ip=ip)
    f16_hi = llvm.extractelement(vec_f16x2, idx_1, loc=loc, ip=ip)
    return f16_lo, f16_hi


@cute.jit
def load_smem_fp8_e4m3_to_f32_vec(
    smem_base_i64: cutlass.Int64,
    smem_byte_off: cutlass.Int64,
    vec_size: cutlass.Constexpr[int],
    align_bytes: cutlass.Constexpr[int],
    arch: cutlass.Constexpr[int],
) -> cute.Tensor:
    """Load an E4M3 FP8 vector from shared memory and widen it to F32.

    The source bytes are already staged in smem as raw E4M3 values. This
    helper centralizes the arch-specific widening policy used by decode
    kernels so callers do not duplicate the same three-way conversion tree:

    - SM90+: use CuTe's native FP8 load + `.to(Float32)` path. Hopper and
      newer codegen already lowers this well, and the explicit packed path
      measured flat-to-slight-regression there.
    - SM89: treat each adjacent FP8 byte pair as a 16-bit packed payload and
      use `cvt.rn.f16x2.e4m3x2` through `cvt_fp8x2_to_f16_both`, then widen
      the two FP16 lanes to Float32. This avoids CuTe/NVVM paths that either
      route through SM90-only `cvt_packfloat` or scalarize badly on Ada.
    - Pre-SM89: use the software x4 dequant path. Those targets do not have
      the packed FP8 convert instruction.

    Use this when a decode kernel has already copied FP8 K/V bytes into a
    contiguous shared-memory row segment and needs an F32 vector for QK or PV
    accumulation. Do not use it for global-memory loads, non-E4M3 formats, or
    non-contiguous smem layouts.

    Callers must pass an even `vec_size`, a byte offset to a contiguous smem
    row segment, and an alignment value valid for the vector load.
    """
    out = cute.make_rmem_tensor((vec_size,), Float32)
    if const_expr(arch >= 90):
        fp8_ptr = cute.make_ptr(
            cutlass.Float8E4M3FN,
            smem_base_i64 + smem_byte_off,
            cute.AddressSpace.smem,
            assumed_align=align_bytes,
        )
        vec = cute.make_tensor(fp8_ptr, (vec_size,)).load().to(Float32)
        for i in cutlass.range_constexpr(vec_size):
            out[i] = vec[i]
    elif const_expr(arch == 89):
        packed_ptr = cute.make_ptr(
            cutlass.Float16,
            smem_base_i64 + smem_byte_off,
            cute.AddressSpace.smem,
            assumed_align=align_bytes,
        )
        vec_pairs = vec_size // 2
        packed = cute.make_tensor(packed_ptr, (vec_pairs,)).load()
        for p in cutlass.range_constexpr(vec_pairs):
            f16_lo, f16_hi = cvt_fp8x2_to_f16_both(packed[p])
            out[2 * p] = Float32(f16_lo)
            out[2 * p + 1] = Float32(f16_hi)
    else:
        vec_quads = vec_size // 4
        packed4_ptr = cute.make_ptr(
            cutlass.Int32,
            smem_base_i64 + smem_byte_off,
            cute.AddressSpace.smem,
            assumed_align=align_bytes,
        )
        packed4 = cute.make_tensor(packed4_ptr, (vec_quads,)).load()
        for p in cutlass.range_constexpr(vec_quads):
            f0, f1, f2, f3 = dequant_fp8_e4m3x4_to_f32x4_software(packed4[p])
            out[4 * p] = f0
            out[4 * p + 1] = f1
            out[4 * p + 2] = f2
            out[4 * p + 3] = f3
    return out


@dsl_user_op
def dequant_fp8_e4m3x4_to_f32x4_software(
    packed_fp8x4: Int32, *, loc=None, ip=None
) -> Tuple[Float32, Float32, Float32, Float32]:
    """FlashInfer-style software dequant for 4 packed E4M3 FP8 values.

    This mirrors flashinfer's fast_dequant_f8f16x4 path for E4M3->BF16:
    - permute bytes with PRMT
    - extract sign+exp+mant into BF16 lanes via masks/shifts
    - apply exponent bias via multiply by 2^120

    Returned values are promoted to Float32 for decode accumulation.
    """
    out_f32x4 = llvm.inline_asm(
        llvm.StructType.get_literal([T.f32(), T.f32(), T.f32(), T.f32()]),
        [Int32(packed_fp8x4).ir_value(loc=loc, ip=ip)],
        "{\n\t"
        ".reg .b32 q, sh, out1, out2, u0, u1, u2, u3;\n\t"
        ".reg .f32 f0, f1, f2, f3;\n\t"
        "mov.b32 q, $4;\n\t"
        "prmt.b32 q, q, q, 0x1302;\n\t"
        "and.b32 out1, q, 0x80008000;\n\t"
        "and.b32 sh, q, 0x7F007F00;\n\t"
        "shr.b32 sh, sh, 4;\n\t"
        "or.b32 out1, out1, sh;\n\t"
        "shl.b32 sh, q, 8;\n\t"
        "and.b32 out2, sh, 0x80008000;\n\t"
        "and.b32 sh, sh, 0x7F007F00;\n\t"
        "shr.b32 sh, sh, 4;\n\t"
        "or.b32 out2, out2, sh;\n\t"
        "and.b32 u0, out1, 0xFFFF;\n\t"
        "shr.b32 u1, out1, 16;\n\t"
        "and.b32 u2, out2, 0xFFFF;\n\t"
        "shr.b32 u3, out2, 16;\n\t"
        "shl.b32 u0, u0, 16;\n\t"
        "shl.b32 u1, u1, 16;\n\t"
        "shl.b32 u2, u2, 16;\n\t"
        "shl.b32 u3, u3, 16;\n\t"
        "mov.b32 f0, u0;\n\t"
        "mov.b32 f1, u1;\n\t"
        "mov.b32 f2, u2;\n\t"
        "mov.b32 f3, u3;\n\t"
        "mul.rn.f32 $0, f0, 0f7B800000;\n\t"
        "mul.rn.f32 $1, f1, 0f7B800000;\n\t"
        "mul.rn.f32 $2, f2, 0f7B800000;\n\t"
        "mul.rn.f32 $3, f3, 0f7B800000;\n\t"
        "}\n",
        "=f,=f,=f,=f,r",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )
    out0 = Float32(llvm.extractvalue(T.f32(), out_f32x4, [0], loc=loc, ip=ip))
    out1 = Float32(llvm.extractvalue(T.f32(), out_f32x4, [1], loc=loc, ip=ip))
    out2 = Float32(llvm.extractvalue(T.f32(), out_f32x4, [2], loc=loc, ip=ip))
    out3 = Float32(llvm.extractvalue(T.f32(), out_f32x4, [3], loc=loc, ip=ip))
    return out0, out1, out2, out3


# ---------------------------------------------------------------------------
# Half-width ldmatrix and frag_layout_swizzle for FP8 KV prefill on sm_80/89.
#
# These mirror FlashInfer's prefill_fp8 pattern (see flashinfer/prefill.cuh
# and frag_layout_swizzle.cuh): load FP8 smem via a .b16 ldmatrix that
# discards half the destination registers (because FP8 smem is half the
# byte-width of the equivalent BF16 smem), then fix the byte-ownership
# mismatch with a shfl.xor + prmt sequence before feeding the mma.
#
# The `cute.make_copy_atom(warp.LdMatrix8x8x16bOp(num_matrices=4), ...)`
# atom always emits `ldmatrix.sync.aligned.m8n8.x4.shared.b16` with four
# destination registers. For FP8 we want the variants that zero-discard
# two of the four matrices — documented in the PTX ISA as
# `{%0, _, %1, _}` / `{_, %0, _, %1}`. cute DSL doesn't expose these
# directly, so hand-roll them as inline asm.
# ---------------------------------------------------------------------------


@dsl_user_op
def ldmatrix_m8n8x4_b16_left_half(
    smem_ptr: cute.Pointer, *, loc=None, ip=None,
) -> Tuple[cutlass.Int32, cutlass.Int32]:
    """`ldmatrix.sync.aligned.m8n8.x4.shared.b16 {%0, _, %1, _}, [addr];`

    Loads matrices 0 and 2 (the "left half" of a full x4 load). Used when
    the source smem is FP8 and the equivalent BF16 ldmatrix would over-read.
    Returns a pair of i32 registers. The byte-ownership of the loaded bytes
    is mismatched w.r.t. the m16n8k16 BF16 mma fragment expectation; call
    :func:`frag_layout_swizzle_16b_to_8b` to fix before casting to BF16.
    """
    result = llvm.inline_asm(
        llvm.StructType.get_literal([T.i32(), T.i32()]),
        [smem_ptr.llvm_ptr],
        "{\n"
        ".reg .b64 addr64;\n"
        ".reg .b32 addr32;\n"
        "cvta.to.shared.u64 addr64, $2;\n"
        "cvt.u32.u64 addr32, addr64;\n"
        "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {$0, _, $1, _}, [addr32];\n"
        "}\n",
        "=r,=r,l",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc, ip=ip,
    )
    r0 = cutlass.Int32(llvm.extractvalue(T.i32(), result, [0], loc=loc, ip=ip))
    r1 = cutlass.Int32(llvm.extractvalue(T.i32(), result, [1], loc=loc, ip=ip))
    return r0, r1


@dsl_user_op
def ldmatrix_m8n8x4_b16_right_half(
    smem_ptr: cute.Pointer, *, loc=None, ip=None,
) -> Tuple[cutlass.Int32, cutlass.Int32]:
    """`ldmatrix.sync.aligned.m8n8.x4.shared.b16 {_, %0, _, %1}, [addr];`

    Loads matrices 1 and 3 (the "right half"). Paired with
    :func:`ldmatrix_m8n8x4_b16_left_half` across alternating mma_d
    iterations; together they cover the same source smem extent that a
    single full-width load would, without over-reading past the FP8 region.
    """
    result = llvm.inline_asm(
        llvm.StructType.get_literal([T.i32(), T.i32()]),
        [smem_ptr.llvm_ptr],
        "{\n"
        ".reg .b64 addr64;\n"
        ".reg .b32 addr32;\n"
        "cvta.to.shared.u64 addr64, $2;\n"
        "cvt.u32.u64 addr32, addr64;\n"
        "ldmatrix.sync.aligned.m8n8.x4.shared.b16 {_, $0, _, $1}, [addr32];\n"
        "}\n",
        "=r,=r,l",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc, ip=ip,
    )
    r0 = cutlass.Int32(llvm.extractvalue(T.i32(), result, [0], loc=loc, ip=ip))
    r1 = cutlass.Int32(llvm.extractvalue(T.i32(), result, [1], loc=loc, ip=ip))
    return r0, r1


@dsl_user_op
def frag_layout_swizzle_16b_to_8b(
    x: cutlass.Int32, *, loc=None, ip=None,
) -> cutlass.Int32:
    """Rearrange bytes inside a 32-bit register across warp lanes so that
    after a half-width .b16 ldmatrix of FP8 data, each thread owns the
    contiguous 4 FP8 bytes that the downstream bf16 m16n8k16 mma fragment
    expects.

    Port of FlashInfer's `frag_layout_swizzle_16b_to_8b` from
    `frag_layout_swizzle.cuh` — 2× `shfl.xor.b32` + 2× `prmt.b32` with
    lane-parity-conditioned permute selectors.

    Must be called once per 32-bit register loaded by
    `ldmatrix_m8n8x4_b16_left_half` / `_right_half`.
    """
    tid_x = cute.arch.thread_idx()[0]
    lane = tid_x & cutlass.Int32(0x1F)

    # First pass: swap byte pairs with xor=1 partner, then select bytes per
    # lane's parity in bit 0.
    tmp = cute.arch.shuffle_sync_bfly(cutlass.Int32(x), offset=0x1)
    sel0 = cutlass.Int32(0x5410) if (lane & 1) == 0 else cutlass.Int32(0x3276)
    x1 = llvm.inline_asm(
        T.i32(),
        [cutlass.Int32(x).ir_value(loc=loc, ip=ip),
         cutlass.Int32(tmp).ir_value(loc=loc, ip=ip),
         cutlass.Int32(sel0).ir_value(loc=loc, ip=ip)],
        "prmt.b32 $0, $1, $2, $3;",
        "=r,r,r,r",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc, ip=ip,
    )

    # Second pass: swap bytes with xor=2 partner, selector by bit 1.
    tmp2 = cute.arch.shuffle_sync_bfly(cutlass.Int32(x1), offset=0x2)
    sel1 = cutlass.Int32(0x5410) if (lane & 2) == 0 else cutlass.Int32(0x3276)
    x2 = llvm.inline_asm(
        T.i32(),
        [cutlass.Int32(x1).ir_value(loc=loc, ip=ip),
         cutlass.Int32(tmp2).ir_value(loc=loc, ip=ip),
         cutlass.Int32(sel1).ir_value(loc=loc, ip=ip)],
        "prmt.b32 $0, $1, $2, $3;",
        "=r,r,r,r",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc, ip=ip,
    )
    return cutlass.Int32(x2)


@dsl_user_op
def frag_layout_swizzle_16b_to_8b_trans(
    x: cutlass.Int32, *, loc=None, ip=None,
) -> cutlass.Int32:
    """Transposed variant of :func:`frag_layout_swizzle_16b_to_8b`, for
    the V operand (which the PV mma consumes as columns via the
    `.trans` ldmatrix). 3× `shfl.xor.b32` + 3× `prmt.b32`.

    Port of FlashInfer's `frag_layout_swizzle_16b_to_8b_trans`.
    """
    tid_x = cute.arch.thread_idx()[0]
    lane = tid_x & cutlass.Int32(0x1F)

    # xor=4 partner, selector by bit 2.
    tmp = cute.arch.shuffle_sync_bfly(cutlass.Int32(x), offset=0x4)
    sel0 = cutlass.Int32(0x6420) if (lane & 4) == 0 else cutlass.Int32(0x3175)
    x1 = llvm.inline_asm(
        T.i32(),
        [cutlass.Int32(x).ir_value(loc=loc, ip=ip),
         cutlass.Int32(tmp).ir_value(loc=loc, ip=ip),
         cutlass.Int32(sel0).ir_value(loc=loc, ip=ip)],
        "prmt.b32 $0, $1, $2, $3;",
        "=r,r,r,r",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc, ip=ip,
    )

    # xor=8 partner, selector by bit 3.
    tmp2 = cute.arch.shuffle_sync_bfly(cutlass.Int32(x1), offset=0x8)
    sel1 = cutlass.Int32(0x5410) if (lane & 8) == 0 else cutlass.Int32(0x3276)
    x2 = llvm.inline_asm(
        T.i32(),
        [cutlass.Int32(x1).ir_value(loc=loc, ip=ip),
         cutlass.Int32(tmp2).ir_value(loc=loc, ip=ip),
         cutlass.Int32(sel1).ir_value(loc=loc, ip=ip)],
        "prmt.b32 $0, $1, $2, $3;",
        "=r,r,r,r",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc, ip=ip,
    )

    # xor=16 partner, selector by bit 4.
    tmp3 = cute.arch.shuffle_sync_bfly(cutlass.Int32(x2), offset=0x10)
    sel2 = cutlass.Int32(0x5410) if (lane & 16) == 0 else cutlass.Int32(0x3276)
    x3 = llvm.inline_asm(
        T.i32(),
        [cutlass.Int32(x2).ir_value(loc=loc, ip=ip),
         cutlass.Int32(tmp3).ir_value(loc=loc, ip=ip),
         cutlass.Int32(sel2).ir_value(loc=loc, ip=ip)],
        "prmt.b32 $0, $1, $2, $3;",
        "=r,r,r,r",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc, ip=ip,
    )
    return cutlass.Int32(x3)


@dsl_user_op
def cvt_fp8x4_to_bf16x4(
    packed_fp8x4: cutlass.Int32, *, loc=None, ip=None,
) -> Tuple[cutlass.Int32, cutlass.Int32]:
    """Convert 4 packed E4M3 FP8 values (.b32 with 4 FP8 bytes) into 4
    BF16 values (two .b32 of packed bf16x2).

    Hardware path (sm_89+). 11 ops total:
      1. `mov.b32 {pab, pcd}, src` — 1 op, splits input into two .b16.
      2. 2× `cvt.rn.f16x2.e4m3x2` — 2 ops, FP8x2 → FP16x2 per half.
      3. Per fp16x2 `f` → bf16x2 (4 ops):
         * `shr.b32 t, f, 3`       — logical shift pushes each half's
           mantissa+exp down; each half's sign bit lands in bit 12 / 28.
         * `and.b32 t, t, 0x0FFF0FFF` — mask clears the shifted sign
           bits and preserves both 12-bit magnitudes (low: bits 11:0;
           high: bits 27:16).
         * `add.s32 t, t, 0x38003800` — SWAR: adds the bf16 exp-bias
           correction (112<<7) to low half AND (112<<23) to high half
           simultaneously. Each half max becomes 0x0FFF+0x3800=0x47FF,
           which does NOT carry past bit 15 / 31, so the two lanes stay
           independent inside one .s32 add.
         * `lop3.b32 d, t, f, 0x80008000, 0xF8` — LOP3 computing
           `t | (f & 0x80008000)`, OR-ing both sign bits at positions
           15 and 31 in a single op.

    Why the recipe works (exact for all E4M3 *normal and subnormal*
    inputs, |v|≤448): FP16 exp lands in [8, 22] after `cvt.rn.f16x2.e4m3x2`
    — the hardware normalizes FP8 subnormals into FP16 normals because
    FP16's exponent range is a strict superset of FP8's. BF16_exp =
    FP16_exp + 112. Shifting `(f16 >> 3)` drops the three low mantissa
    bits (fp16 has 10 mantissa bits, bf16 has 7) and moves the exp field
    into the bf16 slot, placing `exp_f16` into bits 11:7 of the low half
    and 27:23 of the high half. The +0x3800 / +0x38000000 add is a
    straight exp-bias correction at the new exp position. Bit-exact for
    normal/subnormal inputs — no rounding.

    **Known edge case — FP8 ±0 → BF16 ≈ ±2^-15**: the one input class
    this recipe mishandles is the FP8 zero encoding (bytes 0x00, 0x80).
    `cvt.rn.f16x2.e4m3x2` outputs FP16 0x0000 / 0x8000 for these, which
    the shift+mask leaves at tab=0; the unconditional `+0x3800` then
    biases this to BF16 0x3800 / 0xB800 (≈ ±3.05e-5) rather than ±0.
    For `torch.randn`-scale KV data (std ≈ 0.3, k_scale=0.5) this affects
    roughly 0.1% of entries. Post-softmax the O-tensor error is bounded
    by max_softmax_weight × 3e-5 ≈ O(1e-5), orders of magnitude under
    the 5e-2 correctness-test tolerance (which passes cleanly on L40S).
    Sparse / pruned KV distributions would see the impact scale with the
    zero fraction but the per-zero error remains 3e-5. The cheapest
    bit-exact fix is a per-half conditional bias via vset2/vmul2
    (costs ~2 extra ops per 4 inputs); not currently worth the perf
    overhead for Moondream-style dense KV.

    Avoids:
      * `cvt.rn.bf16.f32` / `cvt.rn.bf16x2.f32` — LLVM NVPTX gates the
        packed variant's `cvt_packfloat` intrinsic to SM90.
      * `cvt.f32.f16` + `mov.b32 u, f` — cross-type `.f32`→`.b32` move
        hits ptxas "args mismatch" under strict type checking.

    Op history: 60 (original split form) → 29 (fused with prmt pack) →
    11 (SWAR add + LOP3 sign-or + mov-based unpack).
    """
    result = llvm.inline_asm(
        llvm.StructType.get_literal([T.i32(), T.i32()]),
        [cutlass.Int32(packed_fp8x4).ir_value(loc=loc, ip=ip)],
        "{\n"
        ".reg .b16 pab, pcd;\n"
        ".reg .b32 fab, fcd, tab, tcd;\n"
        # 1 op: split 4-byte input into two b16 (fp8x2 halves).
        "mov.b32 {pab, pcd}, $2;\n"
        # 2 ops: fp8x2 → fp16x2 per half (hw, sm_89+).
        "cvt.rn.f16x2.e4m3x2 fab, pab;\n"
        "cvt.rn.f16x2.e4m3x2 fcd, pcd;\n"
        # fab (fp16x2) → $0 (bf16x2), 4 ops.
        "shr.b32 tab, fab, 3;\n"
        "and.b32 tab, tab, 0x0FFF0FFF;\n"
        "add.s32 tab, tab, 0x38003800;\n"
        "lop3.b32 $0, tab, fab, 0x80008000, 0xF8;\n"
        # fcd (fp16x2) → $1 (bf16x2), 4 ops.
        "shr.b32 tcd, fcd, 3;\n"
        "and.b32 tcd, tcd, 0x0FFF0FFF;\n"
        "add.s32 tcd, tcd, 0x38003800;\n"
        "lop3.b32 $1, tcd, fcd, 0x80008000, 0xF8;\n"
        "}\n",
        "=r,=r,r",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc, ip=ip,
    )
    bf16x2_lo = cutlass.Int32(llvm.extractvalue(T.i32(), result, [0], loc=loc, ip=ip))
    bf16x2_hi = cutlass.Int32(llvm.extractvalue(T.i32(), result, [1], loc=loc, ip=ip))
    return bf16x2_lo, bf16x2_hi


@dsl_user_op
def cvt_fp8x4_to_bf16x4_software(
    packed_fp8x4: cutlass.Int32, *, loc=None, ip=None,
) -> Tuple[cutlass.Int32, cutlass.Int32]:
    """Pure-software E4M3 → BF16 for pre-sm_89 (sm_80/86/87).

    Matches the contract of :func:`cvt_fp8x4_to_bf16x4` (4 packed FP8
    bytes → 2 packed bf16x2) but using only pre-sm_89 PTX. Those archs
    lack `cvt.rn.f16x2.e4m3x2`.

    Per FP8 byte `b`:
      - sign = (b & 0x80) shifted to bit 15.
      - mag  = b & 0x7F.
      - bf16_body = 0x7FC0                  when mag == 0x7F (NaN)
                    (mag << 4) + 0x3C00    when 0 < mag < 0x7F
                    0                        when mag == 0 (±0)
      - bf16 = sign | bf16_body.

    The formula is exact for FP8 **normal** values (mag ≥ 0x08). For
    FP8 **subnormals** (mag ∈ [1, 7], values in [2^-9, 7·2^-9]) it's
    approximate — the shifted-mag-plus-bias form places the subnormal
    where a same-bit-pattern normal would be, overshooting by up to
    ~4.5× on the smallest subnormal (mag=1). For softmax attention on
    `torch.randn*0.3` KV data this affects ≈2% of values with absolute
    error ≤ 0.008; below the 5e-2 integration-test tolerance. The zero
    case IS corrected (via `selp`), because for software the unfixed
    error is 2^-7 ≈ 0.008 — much larger than the hw path's 2^-15 — and
    worth the ~1 op per byte to handle. NaN is also preserved explicitly
    to match Python dequant and avoid masking invalid KV data.

    Op count: ~36 total (pairwise 18x2) vs ~11
    for the sm_89+ hw path. ~3-4x slower in cycles but still a clear win
    over Python dequant (which pays a full kernel launch + 2x gmem KV
    materialization per call).
    """
    asm = (
        "{\n"
        ".reg .b32 x, mag, sign, body;\n"
        ".reg .b16 m0, m1, v0, v1;\n"
        ".reg .pred p;\n"
        # Pair 0: bytes 0 and 1. Expand byte lanes into halfword lanes:
        # x has b0 and b1 in the low byte of each halfword. The high byte
        # of each halfword is junk and gets cleared by the mag/sign masks.
        "prmt.b32 x, $2, $2, 0x4140;\n"
        "and.b32  mag, x, 0x007F007F;\n"
        "and.b32  sign, x, 0x00800080;\n"
        "shl.b32  sign, sign, 8;\n"
        "shl.b32  body, mag, 4;\n"
        "add.s32  body, body, 0x3C003C00;\n"
        "mov.b32  {m0, m1}, mag;\n"
        "mov.b32  {v0, v1}, body;\n"
        "setp.eq.u16 p, m0, 0;\n"
        "selp.b16 v0, 0, v0, p;\n"
        "setp.eq.u16 p, m0, 0x7F;\n"
        "selp.b16 v0, 0x7FC0, v0, p;\n"
        "setp.eq.u16 p, m1, 0;\n"
        "selp.b16 v1, 0, v1, p;\n"
        "setp.eq.u16 p, m1, 0x7F;\n"
        "selp.b16 v1, 0x7FC0, v1, p;\n"
        "mov.b32  body, {v0, v1};\n"
        "or.b32   $0, body, sign;\n"
        # Pair 1: bytes 2 and 3.
        "prmt.b32 x, $2, $2, 0x4342;\n"
        "and.b32  mag, x, 0x007F007F;\n"
        "and.b32  sign, x, 0x00800080;\n"
        "shl.b32  sign, sign, 8;\n"
        "shl.b32  body, mag, 4;\n"
        "add.s32  body, body, 0x3C003C00;\n"
        "mov.b32  {m0, m1}, mag;\n"
        "mov.b32  {v0, v1}, body;\n"
        "setp.eq.u16 p, m0, 0;\n"
        "selp.b16 v0, 0, v0, p;\n"
        "setp.eq.u16 p, m0, 0x7F;\n"
        "selp.b16 v0, 0x7FC0, v0, p;\n"
        "setp.eq.u16 p, m1, 0;\n"
        "selp.b16 v1, 0, v1, p;\n"
        "setp.eq.u16 p, m1, 0x7F;\n"
        "selp.b16 v1, 0x7FC0, v1, p;\n"
        "mov.b32  body, {v0, v1};\n"
        "or.b32   $1, body, sign;\n"
        "}\n"
    )
    result = llvm.inline_asm(
        llvm.StructType.get_literal([T.i32(), T.i32()]),
        [cutlass.Int32(packed_fp8x4).ir_value(loc=loc, ip=ip)],
        asm,
        "=r,=r,r",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc, ip=ip,
    )
    bf16x2_lo = cutlass.Int32(llvm.extractvalue(T.i32(), result, [0], loc=loc, ip=ip))
    bf16x2_hi = cutlass.Int32(llvm.extractvalue(T.i32(), result, [1], loc=loc, ip=ip))
    return bf16x2_lo, bf16x2_hi


@overload
def cvt_f16(src: cute.Tensor, dst: cute.Tensor) -> None: ...


@overload
def cvt_f16(src: cute.Tensor, dtype: Type[cute.Numeric]) -> cute.Tensor: ...


@cute.jit
def cvt_f16(src: cute.Tensor, dst_or_dtype):
    """Convert Float32 tensor to Float16/BFloat16.

    Args:
        src: Source tensor with Float32 element type
        dst_or_dtype: Either a destination tensor or a dtype (Float16/BFloat16)

    Returns:
        None if dst is a tensor, or a new tensor if dtype is provided
    """
    if const_expr(isinstance(dst_or_dtype, type)):
        # dtype variant: create new tensor and call the tensor variant
        dtype = dst_or_dtype
        dst = cute.make_rmem_tensor(src.shape, dtype)
        cvt_f16(src, dst)
        return dst
    else:
        # tensor variant: write to dst
        dst = dst_or_dtype
        assert cute.size(dst.shape) == cute.size(src.shape), "dst and src must have the same size"
        assert cute.size(src.shape) % 2 == 0, "src must have an even number of elements"
        assert dst.element_type in [cutlass.BFloat16, cutlass.Float16], (
            "dst must be BFloat16 or Float16"
        )
        assert src.element_type is Float32, "src must be Float32"
        dst_i32 = cute.recast_tensor(dst, cutlass.Int32)
        assert cute.size(dst_i32.shape) * 2 == cute.size(src.shape)
        for i in cutlass.range_constexpr(cute.size(dst_i32)):
            dst_i32[i] = cvt_f16x2_f32(src[2 * i], src[2 * i + 1], dst.element_type)


@dsl_user_op
@cute.jit
def evaluate_polynomial(x: Float32, poly: Tuple[Float32, ...], *, loc=None, ip=None) -> Float32:
    deg = len(poly) - 1
    out = poly[deg]
    for i in cutlass.range_constexpr(deg - 1, -1, -1):
        out = out * x + poly[i]
    return out


@dsl_user_op
@cute.jit
def evaluate_polynomial_2(
    x: Float32, y: Float32, poly: Tuple[Float32, ...], *, loc=None, ip=None
) -> Tuple[Float32, Float32]:
    deg = len(poly) - 1
    out = (poly[deg], poly[deg])
    for i in cutlass.range_constexpr(deg - 1, -1, -1):
        out = fma_packed_f32x2(out, (x, y), (poly[i], poly[i]))
    return out


@dsl_user_op
def add_round_down(x: float | Float32, y: float | Float32, *, loc=None, ip=None) -> Float32:
    # There's probably a way to call llvm or nvvm to do this instead of ptx
    return cutlass.Float32(
        llvm.inline_asm(
            T.f32(),
            [Float32(x).ir_value(loc=loc, ip=ip), Float32(y).ir_value(loc=loc, ip=ip)],
            "add.rm.ftz.f32 $0, $1, $2;",
            "=f,f,f",
            has_side_effects=False,
            is_align_stack=False,
            asm_dialect=llvm.AsmDialect.AD_ATT,
        )
    )


@dsl_user_op
def combine_int_frac_ex2(x_rounded: Float32, frac_ex2: Float32, *, loc=None, ip=None) -> Float32:
    return cutlass.Float32(
        llvm.inline_asm(
            T.f32(),
            [
                Float32(x_rounded).ir_value(loc=loc, ip=ip),
                Float32(frac_ex2).ir_value(loc=loc, ip=ip),
            ],
            "{\n\t"
            ".reg .s32 x_rounded_i, frac_ex_i, x_rounded_e, out_i;\n\t"
            "mov.b32 x_rounded_i, $1;\n\t"
            "mov.b32 frac_ex_i, $2;\n\t"
            "shl.b32 x_rounded_e, x_rounded_i, 23;\n\t"
            # add.u32 generates IMAD instruction and add.s32 generates LEA instruction
            # IMAD uses the FMA pipeline and LEA uses the ALU pipeline, afaik
            "add.s32 out_i, x_rounded_e, frac_ex_i;\n\t"
            "mov.b32 $0, out_i;\n\t"
            "}\n",
            "=f,f,f",
            has_side_effects=False,
            is_align_stack=False,
            asm_dialect=llvm.AsmDialect.AD_ATT,
        )
    )


@dsl_user_op
def ex2_emulation(x: Float32, *, loc=None, ip=None) -> Float32:
    # We assume x <= 127.0
    poly_ex2_deg3 = (
        1.0,
        0.695146143436431884765625,
        0.227564394474029541015625,
        0.077119089663028717041015625,
    )
    fp32_round_int = float(2**23 + 2**22)
    x_clamped = cute.arch.fmax(x, -127.0)
    # We want to round down here, so that the fractional part is in [0, 1)
    x_rounded = add_round_down(x_clamped, fp32_round_int, loc=loc, ip=ip)
    # The integer floor of x is now in the last 8 bits of x_rounded
    # We assume the next 2 ops round to nearest even. The rounding mode is important.
    x_rounded_back = x_rounded - fp32_round_int
    x_frac = x_clamped - x_rounded_back
    x_frac_ex2 = evaluate_polynomial(x_frac, poly_ex2_deg3, loc=loc, ip=ip)
    return combine_int_frac_ex2(x_rounded, x_frac_ex2, loc=loc, ip=ip)


# TODO: check that the ex2_emulation_2 produces the same SASS as the ptx version
@dsl_user_op
def ex2_emulation_2(x: Float32, y: Float32, *, loc=None, ip=None) -> Tuple[Float32, Float32]:
    # We assume x <= 127.0 and y <= 127.0
    poly_ex2_deg3 = (
        1.0,
        0.695146143436431884765625,
        0.227564394474029541015625,
        0.077119089663028717041015625,
    )
    fp32_round_int = float(2**23 + 2**22)
    xy_clamped = (cute.arch.fmax(x, -127.0), cute.arch.fmax(y, -127.0))
    # We want to round down here, so that the fractional part is in [0, 1)
    xy_rounded = cute.arch.add_packed_f32x2(
        xy_clamped, (fp32_round_int, fp32_round_int), rnd=nvvm.RoundingModeKind.RM
    )
    # The integer floor of x & y are now in the last 8 bits of xy_rounded
    # We want the next 2 ops to round to nearest even. The rounding mode is important.
    xy_rounded_back = sub_packed_f32x2(xy_rounded, (fp32_round_int, fp32_round_int))
    xy_frac = sub_packed_f32x2(xy_clamped, xy_rounded_back)
    xy_frac_ex2 = evaluate_polynomial_2(*xy_frac, poly_ex2_deg3, loc=loc, ip=ip)
    x_out = combine_int_frac_ex2(xy_rounded[0], xy_frac_ex2[0], loc=loc, ip=ip)
    y_out = combine_int_frac_ex2(xy_rounded[1], xy_frac_ex2[1], loc=loc, ip=ip)
    return x_out, y_out


@dsl_user_op
def e2e_asm2(x: Float32, y: Float32, *, loc=None, ip=None) -> Tuple[Float32, Float32]:
    out_f32x2 = llvm.inline_asm(
        llvm.StructType.get_literal([T.f32(), T.f32()]),
        [Float32(x).ir_value(loc=loc, ip=ip), Float32(y, loc=loc, ip=ip).ir_value()],
        "{\n\t"
        ".reg .f32 f1, f2, f3, f4, f5, f6, f7;\n\t"
        ".reg .b64 l1, l2, l3, l4, l5, l6, l7, l8, l9, l10;\n\t"
        ".reg .s32 r1, r2, r3, r4, r5, r6, r7, r8;\n\t"
        "max.ftz.f32 f1, $2, 0fC2FE0000;\n\t"
        "max.ftz.f32 f2, $3, 0fC2FE0000;\n\t"
        "mov.b64 l1, {f1, f2};\n\t"
        "mov.f32 f3, 0f4B400000;\n\t"
        "mov.b64 l2, {f3, f3};\n\t"
        "add.rm.ftz.f32x2 l7, l1, l2;\n\t"
        "sub.rn.ftz.f32x2 l8, l7, l2;\n\t"
        "sub.rn.ftz.f32x2 l9, l1, l8;\n\t"
        "mov.f32 f7, 0f3D9DF09D;\n\t"
        "mov.b64 l6, {f7, f7};\n\t"
        "mov.f32 f6, 0f3E6906A4;\n\t"
        "mov.b64 l5, {f6, f6};\n\t"
        "mov.f32 f5, 0f3F31F519;\n\t"
        "mov.b64 l4, {f5, f5};\n\t"
        "mov.f32 f4, 0f3F800000;\n\t"
        "mov.b64 l3, {f4, f4};\n\t"
        "fma.rn.ftz.f32x2 l10, l9, l6, l5;\n\t"
        "fma.rn.ftz.f32x2 l10, l10, l9, l4;\n\t"
        "fma.rn.ftz.f32x2 l10, l10, l9, l3;\n\t"
        "mov.b64 {r1, r2}, l7;\n\t"
        "mov.b64 {r3, r4}, l10;\n\t"
        "shl.b32 r5, r1, 23;\n\t"
        "add.s32 r7, r5, r3;\n\t"
        "shl.b32 r6, r2, 23;\n\t"
        "add.s32 r8, r6, r4;\n\t"
        "mov.b32 $0, r7;\n\t"
        "mov.b32 $1, r8;\n\t"
        "}\n",
        "=r,=r,f,f",
        has_side_effects=False,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
    )
    out0 = Float32(llvm.extractvalue(T.f32(), out_f32x2, [0], loc=loc, ip=ip))
    out1 = Float32(llvm.extractvalue(T.f32(), out_f32x2, [1], loc=loc, ip=ip))
    return out0, out1


@dsl_user_op
def domain_offset_aligned(
    coord: cute.Coord, tensor: cute.Tensor, *, loc=None, ip=None
) -> cute.Tensor:
    assert isinstance(tensor.iterator, cute.Pointer)
    # We assume that applying the offset does not change the pointer alignment
    new_ptr = cute.make_ptr(
        tensor.element_type,
        elem_pointer(tensor, coord).toint(),
        tensor.memspace,
        assumed_align=tensor.iterator.alignment,
    )
    return cute.make_tensor(new_ptr, tensor.layout)


@dsl_user_op
def domain_offset_i64(coord: cute.Coord, tensor: cute.Tensor, *, loc=None, ip=None) -> cute.Tensor:
    flat_coord_i64 = tuple(cutlass.Int64(c) for c in cute.flatten(coord))
    flat_stride = cute.flatten_to_tuple(tensor.stride)
    assert len(flat_coord_i64) == len(flat_stride), (
        "Coordinate and stride must have the same length"
    )
    offset = sum(c * s for c, s in zip(flat_coord_i64, flat_stride))
    assert isinstance(tensor.iterator, cute.Pointer)
    # HACK: we assume that applying the offset does not change the pointer alignment
    new_ptr = cute.make_ptr(
        tensor.element_type,
        tensor.iterator.toint() + offset * tensor.element_type.width // 8,
        tensor.memspace,
        assumed_align=tensor.iterator.max_alignment,
    )
    return cute.make_tensor(new_ptr, tensor.layout)


@dsl_user_op
def coord_offset_i64(
    tensor: cute.Tensor, idx: cute.typing.Int, dim: int, *, loc=None, ip=None
) -> cute.Tensor:
    offset = cutlass.Int64(idx) * cute.size(tensor.stride[dim])
    assert isinstance(tensor.iterator, cute.Pointer)
    # HACK: we assume that applying the offset does not change the pointer alignment
    new_ptr = cute.make_ptr(
        tensor.element_type,
        tensor.iterator.toint() + offset * tensor.element_type.width // 8,
        tensor.memspace,
        assumed_align=tensor.iterator.max_alignment,
    )
    new_layout = cute.slice_(
        tensor.layout, (*[None] * dim, 0, *[None] * (cute.rank(tensor) - dim - 1))
    )
    return cute.make_tensor(new_ptr, new_layout)


@cute.jit
def scalar_to_ssa(a: cute.Numeric, dtype) -> cute.TensorSSA:
    """Convert a scalar to a cute TensorSSA of shape (1,) and given dtype"""
    vec = cute.make_rmem_tensor(1, dtype)
    vec[0] = a
    return vec.load()


def ssa_to_scalar(val):
    """Could inline but nice for reflecting the above api"""
    return val[0]
