"""SM8x (Ampere/Orin) dense-prefill leaf module.

`interface._flash_attn_fwd` picks this path over `interface_sm90` when a
call is eligible (`is_eligible(...)` below); that function owns the
validation and everything else falls through to the SM90 dispatcher.

Exposed entry points:
    is_eligible(...)   - boolean gate the caller checks first.
    run(...)           - actually run the SM80 forward kernel.

Dispatches to shipped cubin bundles via
`flash_attn_dispatch.launch_sm80_forward`; if no variant is shipped for
the caller's arch the launch returns False and we raise so the outer
`_flash_attn_fwd` can surface a clear "not implemented" rather than
silently produce zeros.
"""

from typing import Callable, Optional, Tuple

import torch

from kestrel_kernels.flash_attn.cute import dispatch as flash_attn_dispatch
from kestrel_kernels.flash_attn.cute.mask_ids import (
    PREFIX_LM_730_MASK_ID,
    hash_callable,
)
from kestrel_kernels.flash_attn.cute.variant import (
    FlashAttnSm80ForwardVariant,
    build_sm80_forward_variants,
)

_SM8X_PREFILL_SUPPORTED_SMS = {80, 86, 87, 89, 120}
# Native FP8 KV prefill is supported across the whole sm_80 family:
# `flash_fwd._convert_fp8_to_bf16_stage` compile-time dispatches to
# `cvt_fp8x4_to_bf16x4` (hw `cvt.rn.f16x2.e4m3x2`, sm_89+) or
# `cvt_fp8x4_to_bf16x4_software` (software PTX, sm_80/86/87). No
# separate FP8-min-sm gate is needed; the set above is authoritative.

# The exact shape of `is_eligible` pre-migration was "anything dense prefill
# on cc=8/12 with bf16/fp16 + hd in {64,72,128}", relying on the JIT path to
# fill in any combo not already shipped as `.so`. With runtime JIT deps
# removed, unshipped combos need to fall through to sm90 / torch SDPA
# instead of entering this path and hitting a hard error in `_run_kernel`.
# Keep this set in lockstep with `build_sm80_forward_variants()` in
# `variant.py` — it IS the runtime eligibility gate.
_SHIPPED_SM80_FORWARD_KEYS = frozenset(
    (
        v.dtype_name,
        v.head_dim,
        v.causal,
        v.mask_mod_name,
        v.dtype_kv_name,
        v.paged_kv_non_tma,
        v.seqused_q,
    )
    for v in build_sm80_forward_variants()
)

_TORCH_DTYPE_TO_NAME = {
    torch.bfloat16: "bf16",
    torch.float16: "f16",
}


def _is_prefix_lm_730_hash(mask_mod_hash: int | bool) -> bool:
    return bool(mask_mod_hash and mask_mod_hash == PREFIX_LM_730_MASK_ID)


def _to_prefill_kv_dtype(
    *,
    k: torch.Tensor,
    v: torch.Tensor,
    target_dtype: torch.dtype,
    k_scale: float,
    v_scale: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    def convert(t: torch.Tensor, scale: float) -> torch.Tensor:
        if t.dtype == torch.float8_e4m3fn:
            t = t.to(dtype=target_dtype)
            if scale != 1.0:
                t = t * scale
            return t
        if t.dtype != target_dtype:
            return t.to(dtype=target_dtype)
        return t
    return convert(k, k_scale), convert(v, v_scale)


def _index_select_first_dim(t: torch.Tensor, idx: torch.Tensor) -> torch.Tensor:
    # Torch 2.4 on Jetson lacks a float8 index_select CUDA kernel.
    if t.dtype == torch.float8_e4m3fn:
        return t.view(torch.uint8).index_select(0, idx).view(torch.float8_e4m3fn)
    return t.index_select(0, idx)


def _run_kernel(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    out: torch.Tensor,
    softmax_scale: float,
    k_scale: float,
    v_scale: float,
    head_dim: int,
    causal: bool,
    mask_mod_hash: int | bool,
    dtype_kv_name: str | None,
    seqused_q: Optional[torch.Tensor] = None,
    seqused_k: Optional[torch.Tensor] = None,
    page_table: Optional[torch.Tensor] = None,
) -> None:
    """Dispatch one prefill call through the shipped sm80 cubin
    bundle. Shape args (batch/seqlen/num_heads) derive from `q` per the
    BSHD layout that `is_eligible` already enforced.

    `dtype_kv_name` selects the FP8 variant; when None the BF16 variant is
    used and scales must be 1.0. For FP8 variants, k/v are expected as
    `torch.float8_e4m3fn` tensors — caller should not have pre-dequantized.
    """
    dtype_name = _TORCH_DTYPE_TO_NAME[q.dtype]
    mask_mod_name = "prefix_lm_730" if _is_prefix_lm_730_hash(mask_mod_hash) else None
    variant = FlashAttnSm80ForwardVariant(
        dtype_name=dtype_name,
        head_dim=head_dim,
        causal=causal,
        mask_mod_name=mask_mod_name,
        dtype_kv_name=dtype_kv_name,
        paged_kv_non_tma=page_table is not None,
        seqused_q=seqused_q is not None,
    )
    # FP8 KV: pass a uint8 view to the cubin (matches its Uint8 memref
    # spec from `_compile_flash_attn_sm80_forward`).
    k_for_call = k.view(torch.uint8) if dtype_kv_name == "fp8_e4m3" else k
    v_for_call = v.view(torch.uint8) if dtype_kv_name == "fp8_e4m3" else v
    batch_size, seqlen_q, num_heads, _ = q.shape
    if not flash_attn_dispatch.launch_sm80_forward(
        variant, q, k_for_call, v_for_call, out,
        softmax_scale, k_scale, v_scale,
        seqused_q=seqused_q,
        seqused_k=seqused_k, page_table=page_table,
        batch_size=batch_size, seqlen_q=seqlen_q, num_heads=num_heads,
    ):
        raise RuntimeError(
            f"No sm80 forward cubin for {variant.variant_key} on this arch. "
            f"Ship a tuned variant or set KESTREL_CUTE_JIT=1 to compile on demand."
        )


def is_eligible(
    *,
    cc_major: int,
    cc_minor: int,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    cu_seqlens_q: Optional[torch.Tensor],
    cu_seqlens_k: Optional[torch.Tensor],
    seqused_q: Optional[torch.Tensor],
    seqused_k: Optional[torch.Tensor],
    page_table: Optional[torch.Tensor],
    score_mod: Optional[Callable],
    mask_mod: Optional[Callable],
    softcap: Optional[float],
    causal: bool,
    window_size_left: Optional[int],
    window_size_right: Optional[int],
    aux_tensors: Optional[list],
    learnable_sink: Optional[torch.Tensor],
    num_splits: int,
    lse: Optional[torch.Tensor],
) -> bool:
    """Return True iff this call should take the SM8x prefill path.

    Unsupported combinations — decode fastpath, GQA, sliding window,
    unshipped FP8/paged variants, etc — should fall through to
    `interface_sm90._flash_attn_fwd_impl` or the torch SDPA fallback.
    `return_lse`/`requires_grad` callers fall into this path too; the
    shipped sm80 cubin doesn't emit LSE partials, so the caller gets back
    whichever tensor it pre-allocated for `lse` (or `None`) unchanged —
    matching pre-cubin behavior.
    """
    device_sm = cc_major * 10 + cc_minor
    if device_sm not in _SM8X_PREFILL_SUPPORTED_SMS:
        return False
    if q.ndim != 4 or k.ndim != 4 or v.ndim != 4:
        return False
    if q.dtype not in _TORCH_DTYPE_TO_NAME:
        return False
    # Dense prefill: decode fastpath (page_size==1, seqlen_q==1) still
    # belongs on sm90.
    if page_table is not None and int(k.shape[1]) == 1 and int(q.shape[1]) == 1:
        return False
    if int(k.shape[-2]) != int(q.shape[-2]):
        return False  # MHA only
    if cu_seqlens_q is not None or cu_seqlens_k is not None:
        return False
    if score_mod is not None or softcap is not None:
        return False
    if aux_tensors is not None:
        return False
    if learnable_sink is not None or num_splits != 1:
        return False
    # Shipped sm80 cubin variants don't emit LSE partials. `is_eligible=False`
    # here routes LSE-requesting callers through `interface_sm90` → torch
    # SDPA fallback, which has a matching NotImplementedError with a pointer
    # at the `jit` dependency group (where the JIT cute kernel that DOES
    # populate lse lives).
    if lse is not None:
        return False
    if (window_size_left is not None and window_size_left >= 0) or (
        window_size_right is not None and window_size_right >= 0
    ):
        return False
    mask_mod_hash = hash_callable(mask_mod) if mask_mod is not None else False
    if mask_mod is not None and not _is_prefix_lm_730_hash(mask_mod_hash):
        return False
    # Only claim eligibility for combinations that map to a shipped
    # cubin. Pre-migration, misses were caught by the JIT path; now that
    # JIT isn't a runtime dep, anything not in `_SHIPPED_SM80_FORWARD_KEYS`
    # must fall through to sm90 / torch SDPA instead of hitting the
    # "No sm80 forward cubin for ..." raise in `_run_kernel`.
    dtype_name = _TORCH_DTYPE_TO_NAME[q.dtype]
    head_dim = int(q.shape[-1])
    mask_mod_name = "prefix_lm_730" if mask_mod is not None else None
    native_bf16_kv_inputs = k.dtype == q.dtype and v.dtype == q.dtype
    fp8_kv_inputs = k.dtype == torch.float8_e4m3fn and v.dtype == torch.float8_e4m3fn
    # FP8 KV eligibility: both k and v must be float8_e4m3fn, and a
    # matching native FP8 variant must be shipped. Every arch in
    # `_SM8X_PREFILL_SUPPORTED_SMS` has a convert path (hw on sm_89+,
    # software on sm_80/86/87 — dispatched at compile time inside
    # `flash_fwd._convert_fp8_to_bf16_stage`), so no extra FP8 sm gate.
    dtype_kv_name: Optional[str] = None
    if fp8_kv_inputs:
        dtype_kv_name = "fp8_e4m3"
    paged_key_allowed = page_table is not None and seqused_k is not None
    if (
        paged_key_allowed
        and (native_bf16_kv_inputs or fp8_kv_inputs)
        and (
            dtype_name,
            head_dim,
            bool(causal),
            mask_mod_name,
            dtype_kv_name,
            True,
            seqused_q is not None,
        )
        in _SHIPPED_SM80_FORWARD_KEYS
    ):
        return True
    if (
        dtype_name,
        head_dim,
        bool(causal),
        mask_mod_name,
        dtype_kv_name,
        False,
        False,
    ) in _SHIPPED_SM80_FORWARD_KEYS:
        return True
    # Fall back to BF16 variant via Python dequant if no native FP8 variant.
    return (
        dtype_name,
        head_dim,
        bool(causal),
        mask_mod_name,
        None,
        False,
        False,
    ) in _SHIPPED_SM80_FORWARD_KEYS


def run(
    *,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    out: torch.Tensor,
    seqused_q: Optional[torch.Tensor],
    seqused_k: Optional[torch.Tensor],
    page_table: Optional[torch.Tensor],
    softmax_scale: float,
    causal: bool,
    mask_mod: Optional[Callable],
    k_scale: float,
    v_scale: float,
    device_sm: int,
) -> Tuple[torch.Tensor, None]:
    """Run the SM80 forward kernel. Caller must have already validated
    via `is_eligible(...)`.

    Sets `run._debug_last_impl` so `interface._flash_attn_fwd` can
    propagate it up. The shipped sm80 cubin doesn't emit LSE partials,
    so `is_eligible` rejects LSE-requesting callers — no need to handle
    `lse` here.
    """
    batch_size, q_len, num_heads, head_dim = q.shape
    mask_mod_hash = hash_callable(mask_mod) if mask_mod is not None else False

    # Decide native-FP8 vs bf16-variant-with-Python-dequant. Native FP8
    # is selected when K/V are both float8_e4m3fn AND a native FP8 cubin
    # is shipped for this combo. The `is_eligible` gate already restricted
    # us to `_SM8X_PREFILL_SUPPORTED_SMS`; the compile-time convert
    # dispatch in `flash_fwd._convert_fp8_to_bf16_stage` handles per-arch
    # selection between hw and software E4M3 → BF16 paths.
    dtype_name = _TORCH_DTYPE_TO_NAME[q.dtype]
    mask_mod_name = "prefix_lm_730" if _is_prefix_lm_730_hash(mask_mod_hash) else None
    fp8_kv_inputs = (k.dtype == torch.float8_e4m3fn and v.dtype == torch.float8_e4m3fn)
    native_bf16_kv_inputs = k.dtype == q.dtype and v.dtype == q.dtype
    native_fp8 = (
        fp8_kv_inputs
        and (dtype_name, head_dim, bool(causal), mask_mod_name, "fp8_e4m3", False, False)
            in _SHIPPED_SM80_FORWARD_KEYS
    )

    native_paged = (
        page_table is not None
        and seqused_k is not None
        and (native_bf16_kv_inputs or fp8_kv_inputs)
        and (
            dtype_name,
            head_dim,
            bool(causal),
            mask_mod_name,
            "fp8_e4m3" if fp8_kv_inputs else None,
            True,
            seqused_q is not None,
        )
        in _SHIPPED_SM80_FORWARD_KEYS
    )

    if native_paged:
        _run_kernel(
            q=q, k=k, v=v, out=out,
            softmax_scale=softmax_scale,
            k_scale=k_scale if fp8_kv_inputs else 1.0,
            v_scale=v_scale if fp8_kv_inputs else 1.0,
            head_dim=head_dim, causal=causal, mask_mod_hash=mask_mod_hash,
            dtype_kv_name="fp8_e4m3" if fp8_kv_inputs else None,
            seqused_q=seqused_q, seqused_k=seqused_k, page_table=page_table,
        )
        run._debug_last_impl = f"sm{device_sm}_paged_prefill"
        return out, None

    if page_table is None and seqused_q is None and seqused_k is None:
        if native_fp8:
            # Native FP8 variant: pass FP8 tensors straight through with
            # scales. The cubin's kernel body dequantizes on the load path.
            _run_kernel(
                q=q, k=k, v=v, out=out,
                softmax_scale=softmax_scale, k_scale=k_scale, v_scale=v_scale,
                head_dim=head_dim, causal=causal, mask_mod_hash=mask_mod_hash,
                dtype_kv_name="fp8_e4m3",
            )
        else:
            # BF16 variant path: pre-dequantize K/V in Python, then call
            # the bf16 cubin with scale=1.0 (no-op fold).
            k_use, v_use = _to_prefill_kv_dtype(
                k=k, v=v, target_dtype=q.dtype, k_scale=k_scale, v_scale=v_scale,
            )
            _run_kernel(
                q=q, k=k_use, v=v_use, out=out,
                softmax_scale=softmax_scale, k_scale=1.0, v_scale=1.0,
                head_dim=head_dim, causal=causal, mask_mod_hash=mask_mod_hash,
                dtype_kv_name=None,
            )
    else:
        # Remaining varlen / paged KV cases on sm_80 fall back to flattening
        # pages + iterating one batch at a time, calling the dense kernel per row.
        out.zero_()
        total_pages = int(k.shape[0]) if page_table is not None else 0
        page_size = int(k.shape[1]) if page_table is not None else 0
        page_table_long = page_table.to(dtype=torch.long) if page_table is not None else None

        for row in range(batch_size):
            q_len_row = int(seqused_q[row].item()) if seqused_q is not None else q_len
            if q_len_row <= 0:
                continue
            q_row = q[row : row + 1, :q_len_row].contiguous()

            if page_table is None:
                kv_len_row = int(seqused_k[row].item()) if seqused_k is not None else int(k.shape[1])
                if kv_len_row <= 0:
                    continue
                k_row = k[row : row + 1, :kv_len_row].contiguous()
                v_row = v[row : row + 1, :kv_len_row].contiguous()
            else:
                page_row = page_table_long[row]
                valid_pages = (page_row >= 0) & (page_row < total_pages)
                available_pages = int(valid_pages.sum().item())
                if available_pages <= 0:
                    continue
                available_kv_len = available_pages * page_size
                kv_len_row = (
                    min(int(seqused_k[row].item()), available_kv_len)
                    if seqused_k is not None
                    else available_kv_len
                )
                if kv_len_row <= 0:
                    continue
                pages_needed = min((kv_len_row + page_size - 1) // page_size, available_pages)
                page_ids = page_row[valid_pages][:pages_needed]
                k_pages = _index_select_first_dim(k, page_ids)
                v_pages = _index_select_first_dim(v, page_ids)
                k_row = k_pages.reshape(pages_needed * page_size, num_heads, head_dim)[:kv_len_row]
                v_row = v_pages.reshape(pages_needed * page_size, num_heads, head_dim)[:kv_len_row]
                k_row = k_row.unsqueeze(0).contiguous()
                v_row = v_row.unsqueeze(0).contiguous()

            out_row = out[row : row + 1, :q_len_row]
            if native_fp8:
                # Native FP8 variant: `k_row` / `v_row` are still FP8
                # (the `_to_prefill_kv_dtype` dequant wasn't run above in
                # this branch), pass them through with scales. The gather
                # for paged case already produced FP8 per-row tensors.
                _run_kernel(
                    q=q_row, k=k_row, v=v_row, out=out_row,
                    softmax_scale=softmax_scale, k_scale=k_scale, v_scale=v_scale,
                    head_dim=head_dim, causal=causal, mask_mod_hash=mask_mod_hash,
                    dtype_kv_name="fp8_e4m3",
                )
            else:
                k_row_bf, v_row_bf = _to_prefill_kv_dtype(
                    k=k_row, v=v_row, target_dtype=q.dtype,
                    k_scale=k_scale, v_scale=v_scale,
                )
                _run_kernel(
                    q=q_row, k=k_row_bf, v=v_row_bf, out=out_row,
                    softmax_scale=softmax_scale, k_scale=1.0, v_scale=1.0,
                    head_dim=head_dim, causal=causal, mask_mod_hash=mask_mod_hash,
                    dtype_kv_name=None,
                )

    run._debug_last_impl = f"sm{device_sm}_prefill"
    return out, None


run._debug_last_impl = None
