"""FP8 quantization dispatch — direct cubin path with variant selection."""


import torch

from kestrel_kernels.cubin_runtime import CubinFamily
from kestrel_kernels.fallback import ceil_div, warn_and_run_fallback
from kestrel_kernels.fp8_quant_cute.fallback import fp8_quant_torch_into

_family = CubinFamily("fp8_quant")
_KERNEL_KEY = "fp8_quant_cute"
_SUPPORTED_HIDDEN = {1024, 2048}


def _pick_warps_per_block(hidden: int, num_rows: int) -> int:
    # Benchmarked crossover: w=1 wins for h=2048 always (register pressure)
    # and for h=1024 up to ~512 rows; w=8 wins for h=1024 above that.
    if hidden >= 2048 or num_rows <= 512:
        return 1
    return 8


def fp8_quant_cute(
    out_bits: torch.Tensor,
    out_scale: torch.Tensor,
    inp: torch.Tensor,
    *,
    use_pdl: bool = False,
) -> None:
    num_rows, hidden = inp.shape
    if num_rows == 0:
        return

    warps_per_block = _pick_warps_per_block(hidden, num_rows)
    pdl_suffix = "_pdl" if use_pdl else ""
    variant_key = f"h{hidden}_w{warps_per_block}{pdl_suffix}"

    if hidden in _SUPPORTED_HIDDEN and _family.is_available(variant_key):
        grid_x = num_rows if warps_per_block == 1 else ceil_div(num_rows, warps_per_block)
        dispatch = _family.resolve_dispatch(inp, variant_key=variant_key, grid_x=grid_x)
        dispatch(out_bits, out_scale, inp)
        return

    warn_and_run_fallback(
        kernel_key=_KERNEL_KEY,
        message=f"kestrel-kernels: no fp8_quant cubin bundle for variant={variant_key!r}; using PyTorch fallback.",
        fallback=fp8_quant_torch_into,
        kwargs={"out_bits": out_bits, "out_scale": out_scale, "inp": inp},
    )


__all__ = ["fp8_quant_cute"]
