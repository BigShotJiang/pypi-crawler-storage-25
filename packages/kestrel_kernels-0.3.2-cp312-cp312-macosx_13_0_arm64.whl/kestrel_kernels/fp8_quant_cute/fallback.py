"""Torch fallback for FP8 row-wise quantization."""


import torch


_FP8_E4M3_MAX = 448.0


def fp8_quant_torch_into(
    *,
    out_bits: torch.Tensor,
    out_scale: torch.Tensor,
    inp: torch.Tensor,
) -> None:
    absmax = inp.abs().amax(dim=1).float()
    scale = (absmax / _FP8_E4M3_MAX).clamp(min=1e-6)
    out_scale.copy_(scale)
    x_scaled = inp.float() / scale.unsqueeze(1)
    x_clamped = x_scaled.clamp(-_FP8_E4M3_MAX, _FP8_E4M3_MAX)
    out_bits.copy_(x_clamped.to(torch.float8_e4m3fn).view(torch.uint8))


__all__ = ["fp8_quant_torch_into"]
