
import torch


def tau_tail_apply_into_torch(
    *,
    qkv_out: torch.Tensor,
    tok_qv_lin: torch.Tensor,
    tau_pos_table: torch.Tensor,
    position_ids: torch.Tensor,
) -> None:
    qkv_dim = int(qkv_out.shape[-1])
    if qkv_dim % 3 != 0:
        raise ValueError(f"qkv_out last dimension must be divisible by 3, got {qkv_dim}")
    q_dim = qkv_dim // 3
    n_heads = int(tok_qv_lin.shape[-1] // 2)
    if n_heads == 0 or (q_dim % n_heads) != 0:
        raise ValueError("qkv_out and tok_qv_lin are shape-incompatible for tau fallback")
    head_dim = q_dim // n_heads

    tok_qv = torch.tanh(tok_qv_lin)
    tok_q = tok_qv[..., :n_heads]
    tok_v = tok_qv[..., n_heads:]
    tau_pos = tau_pos_table[position_ids]

    q = qkv_out[..., :q_dim].view(*qkv_out.shape[:2], n_heads, head_dim)
    v = qkv_out[..., 2 * q_dim :].view(*qkv_out.shape[:2], n_heads, head_dim)
    q.mul_((tok_q + tau_pos).unsqueeze(-1))
    v.mul_((tok_v + tau_pos).unsqueeze(-1))


__all__ = ["tau_tail_apply_into_torch"]
