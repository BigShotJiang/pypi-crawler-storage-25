"""Tau-tail dispatch API."""

from kestrel_kernels.tau_tail_ops.dispatch import tau_tail_apply_into

__all__ = ["tau_tail_apply_into"]
