"""Tau-tail dispatch — direct call into _pybridge."""


import torch

from kestrel_kernels._pybridge import tau_tail_apply_cuda as _raw
from kestrel_kernels.fallback import should_use_cuda_impl
from kestrel_kernels.tau_tail_ops.fallback import tau_tail_apply_into_torch

_SUPPORTED_SMS = {80, 86, 87, 89, 90, 100, 110, 120}


def tau_tail_apply_into(*, qkv_out, tok_qv_lin, tau_pos_table, position_ids):
    if not should_use_cuda_impl(
        device=qkv_out.device,
        kernel_key="tau_tail_apply_into_non_supported_arch",
        op_name="tau_tail_apply_into",
        supported_sms=_SUPPORTED_SMS,
    ):
        tau_tail_apply_into_torch(
            qkv_out=qkv_out, tok_qv_lin=tok_qv_lin,
            tau_pos_table=tau_pos_table, position_ids=position_ids,
        )
        return
    dtype_code = 1 if qkv_out.dtype == torch.bfloat16 else 0
    _raw(qkv_out, tok_qv_lin, tau_pos_table, position_ids, dtype_code)


__all__ = ["tau_tail_apply_into"]
