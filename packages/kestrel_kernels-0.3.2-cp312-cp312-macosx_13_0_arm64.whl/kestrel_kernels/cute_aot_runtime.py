"""Direct runtime for AOT-compiled CuTe kernels.

The AOT `.so` (built by `scripts/precompile/cute_aot_build.py`) exports
three symbols per variant:

    _mlir_<prefix>_cuda_init(void **packed)          # packed = [&lib_ptr, &err]
    _mlir_<prefix>_cuda_load_to_device(void **)      # packed = [&lib_ptr, &dev, &err]
    _mlir_<prefix>__mlir_ciface_<fn>(void **, int32) # packed as per header:
        [&tensor_struct_0, ..., &scalar_0, ..., &stream, &err_slot]

Each `Tensor_mX_t` struct is `{void *data; int32_t dynamic_shapes[N];
int64_t dynamic_strides[M];}` — one `MemrefStructSpec` per memref
describes which (N, M) apply and which dims the mask counts as dynamic.

`AotFamily` wraps the per-family lookup + cache + (optional) JIT
fallback so each dispatch module is a thin adapter: pack args in the
wrapper's declared order, call `ciface`. No per-family resolver code.

No `libcute_dsl_runtime.so` / `apache-tvm-ffi` dep at runtime. Pure
ctypes.
"""


import ctypes
import json
import sys
from pathlib import Path
from typing import Callable

import torch


_SHARED_LIB_EXT = ".dll" if sys.platform == "win32" else ".so"


class MemrefStructSpec:
    """Layout of one `Tensor_mX_t` struct. `shape_mask`/`stride_mask` are
    per-dim 0/1 (in user layout); positions flagged 1 become slots in the
    struct's `dynamic_shapes[]` / `dynamic_strides[]` arrays."""

    __slots__ = ("shape_mask", "stride_mask", "_struct_t",
                 "_shape_indices", "_stride_indices")

    def __init__(self, shape_mask, stride_mask):
        self.shape_mask = tuple(int(m) for m in shape_mask)
        self.stride_mask = tuple(int(m) for m in stride_mask)
        self._shape_indices = tuple(i for i, m in enumerate(self.shape_mask) if m)
        self._stride_indices = tuple(i for i, m in enumerate(self.stride_mask) if m)
        self._struct_t = _memref_struct_type(
            len(self._shape_indices), len(self._stride_indices),
        )

    def build(self, tensor: torch.Tensor):
        inst = self._struct_t()
        inst.data = ctypes.c_void_p(tensor.data_ptr())
        if self._shape_indices:
            sh = tensor.shape
            for j, i in enumerate(self._shape_indices):
                inst.dynamic_shapes[j] = int(sh[i])
        if self._stride_indices:
            st = tensor.stride()
            for j, i in enumerate(self._stride_indices):
                inst.dynamic_strides[j] = int(st[i])
        return inst

    def to_json(self) -> dict:
        return {"shape_mask": list(self.shape_mask),
                "stride_mask": list(self.stride_mask)}

    @classmethod
    def from_json(cls, obj: dict) -> "MemrefStructSpec":
        return cls(obj["shape_mask"], obj["stride_mask"])


_MEMREF_STRUCT_CACHE: dict = {}


def _memref_struct_type(n_shapes: int, n_strides: int):
    """Cached ctypes Structure matching emitted `Tensor_mX_t`."""
    key = (n_shapes, n_strides)
    if key in _MEMREF_STRUCT_CACHE:
        return _MEMREF_STRUCT_CACHE[key]
    fields: list = [("data", ctypes.c_void_p)]
    if n_shapes > 0:
        fields.append(("dynamic_shapes", ctypes.c_int32 * n_shapes))
    if n_strides > 0:
        fields.append(("dynamic_strides", ctypes.c_int64 * n_strides))

    class _MemrefStruct(ctypes.Structure):
        _fields_ = fields
    _MEMREF_STRUCT_CACHE[key] = _MemrefStruct
    return _MemrefStruct


class CuteAotVariant:
    """One AOT-linked cute wrapper, resolved lazily on first dispatch."""

    def __init__(self, so_path: Path, symbols: dict[str, str]):
        """`symbols` maps {"cuda_init", "cuda_load_to_device", "ciface"}
        to their exported symbol names (see
        `cute_aot_build.aot_symbol_names`)."""
        self.so_path = Path(so_path)
        self._symbols = symbols
        self._dll: ctypes.CDLL | None = None
        self._ciface: Callable | None = None
        self._cuda_init: Callable | None = None
        self._cuda_load: Callable | None = None
        self._library = ctypes.c_void_p(0)
        self._loaded_devices: set[int] = set()

    def _load(self) -> None:
        if self._dll is not None:
            return
        try:
            ctypes.CDLL("libcudart.so.12", mode=ctypes.RTLD_GLOBAL)
        except OSError:
            pass
        self._dll = ctypes.CDLL(str(self.so_path), mode=ctypes.RTLD_LOCAL)
        for name, attr in [("cuda_init", "_cuda_init"),
                           ("cuda_load_to_device", "_cuda_load"),
                           ("ciface", "_ciface")]:
            fn = getattr(self._dll, self._symbols[name])
            fn.argtypes = [ctypes.c_void_p]
            fn.restype = None
            setattr(self, attr, fn)
        # `_mlir_ciface_` takes (void **args, int32_t num_args).
        self._ciface.argtypes = [ctypes.c_void_p, ctypes.c_int32]

    def _ensure_device(self, device_index: int) -> None:
        if device_index in self._loaded_devices:
            return
        self._load()

        err = ctypes.c_int32(0)
        libptr = ctypes.pointer(self._library)

        self._call_cuda_init_or_load(
            self._cuda_init, [ctypes.pointer(libptr), ctypes.pointer(err)],
            err, "cuda_init",
        )
        dev = ctypes.c_int32(device_index)
        self._call_cuda_init_or_load(
            self._cuda_load,
            [ctypes.pointer(libptr), ctypes.pointer(dev), ctypes.pointer(err)],
            err, "cuda_load_to_device",
        )
        self._loaded_devices.add(device_index)

    @staticmethod
    def _call_cuda_init_or_load(fn, ptrs, err_slot, label):
        """Build a void*[] from `ptrs`, call `fn(packed)`, raise on
        non-zero error. Shared helper for cuda_init / cuda_load_to_device
        which differ only in how many pointer slots the cute-DSL wrapper
        reads off the packed array."""
        packed = (ctypes.c_void_p * len(ptrs))()
        for i, p in enumerate(ptrs):
            packed[i] = ctypes.cast(p, ctypes.c_void_p)
        fn(ctypes.cast(packed, ctypes.c_void_p))
        if err_slot.value:
            raise RuntimeError(f"{label} failed: rc={err_slot.value}")

    def call(self, arg_kinds: list[str], memref_ptrs: list,
             scalar_ptrs: list, stream_ptr: "ctypes.c_void_p") -> None:
        """Invoke ciface with packed-args built in the wrapper's declared
        order. `arg_kinds` is a list of "memref" / "scalar" / "stream"
        tags (one per arg), matching the emitted wrapper's signature.
        `memref_ptrs` and `scalar_ptrs` are consumed in order as each
        corresponding tag is hit; `stream_ptr` is a single value used
        for every "stream" tag. Caller keeps underlying ctypes alive."""
        num_args = len(arg_kinds) + 1  # +1 for trailing error slot
        packed = (ctypes.c_void_p * num_args)()
        mr_iter = iter(memref_ptrs)
        sc_iter = iter(scalar_ptrs)
        for i, kind in enumerate(arg_kinds):
            if kind == "memref":
                packed[i] = ctypes.cast(next(mr_iter), ctypes.c_void_p)
            elif kind == "scalar":
                packed[i] = ctypes.cast(next(sc_iter), ctypes.c_void_p)
            elif kind == "stream":
                packed[i] = ctypes.cast(stream_ptr, ctypes.c_void_p)
            else:
                raise RuntimeError(f"unknown arg kind {kind!r}")
        err = ctypes.c_int32(0)
        packed[len(arg_kinds)] = ctypes.cast(ctypes.pointer(err), ctypes.c_void_p)
        self._ciface(ctypes.cast(packed, ctypes.c_void_p), ctypes.c_int32(num_args))
        if err.value:
            raise RuntimeError(f"{self._symbols['ciface']}: rc={err.value}")


class AotVariantBundle:
    """One resolved variant: `.so` handle + metadata, ready to invoke."""

    __slots__ = ("aot", "memref_specs", "arg_kinds")

    def __init__(self, aot: CuteAotVariant, memref_specs: tuple,
                 arg_kinds: list) -> None:
        self.aot = aot
        self.memref_specs = memref_specs
        self.arg_kinds = arg_kinds


class AotFamily:
    """Resolves AOT-emitted cute wrappers for one kernel family.

    Metadata source priority:
      1. Shipped bundle manifest at `bundles/<family>/manifest.json`
         (`variants[variant_key].aot`).
      2. Sidecar JSON (`<so_path>.aot.json`) for JIT-built variants.

    When `jit_compile_fn` is provided, cache misses compile on demand
    via `build_aot_variant` (source install only). The factory takes
    the `variant` object passed to `resolve()` and returns a
    `compile_fn(arch) -> (kernel_target, *fake_args)` suitable for
    `cute.compile()`.
    """

    def __init__(self, family_name: str,
                 jit_compile_fn: Callable[[object], Callable[[str], tuple]] | None = None):
        self.family_name = family_name
        self.jit_compile_fn = jit_compile_fn
        self._cache: dict[tuple[str, str], AotVariantBundle] = {}
        # Tri-state: False = not loaded, None = no manifest, dict = loaded.
        self._manifest: "dict | None | bool" = False

    @property
    def bundle_dir(self) -> Path:
        # On multi-CUDA aarch64 wheels, ``kestrel_kernels.KERNEL_DIR`` points
        # at the cu<major>/ subdir matching torch's CUDA major; the
        # cute-dsl AOT shared libs in ``bundles/<family>/`` link against
        # cuBLAS/cuBLASLt/cudart for that major.
        from kestrel_kernels import KERNEL_DIR
        return KERNEL_DIR / "bundles" / self.family_name

    def _load_manifest(self) -> "dict | None":
        if self._manifest is not False:
            return self._manifest
        mf = self.bundle_dir / "manifest.json"
        self._manifest = None
        if mf.exists():
            try:
                self._manifest = json.loads(mf.read_text())
            except Exception:
                pass
        return self._manifest

    def _read_meta(self, variant_key: str, so_path: Path):
        """Returns (symbols, arg_kinds, memref_specs) or None."""
        if not so_path.exists():
            return None
        sources = []
        mf = self._load_manifest() or {}
        ship_meta = mf.get("variants", {}).get(variant_key, {}).get("aot")
        if ship_meta:
            sources.append(ship_meta)
        sidecar = so_path.with_suffix(".aot.json")
        if sidecar.exists():
            try:
                sources.append(json.loads(sidecar.read_text()))
            except Exception:
                pass
        for meta in sources:
            symbols = meta.get("symbols")
            arg_kinds = meta.get("arg_kinds")
            specs_list = meta.get("memref_specs")
            if symbols and arg_kinds and specs_list:
                return (symbols, list(arg_kinds),
                        tuple(MemrefStructSpec.from_json(s) for s in specs_list))
        return None

    def resolve(self, variant, arch: str) -> "AotVariantBundle | None":
        """Look up or build the AOT wrapper for `(variant, arch)`.

        `variant` may be any object with a `.variant_key` attribute, or
        a bare string. Returns None if no shipped variant exists and
        JIT is disabled / fails.
        """
        variant_key = getattr(variant, "variant_key", variant)
        cache_key = (variant_key, arch)
        cached = self._cache.get(cache_key)
        if cached is not None:
            return cached

        so_path = self.bundle_dir / f"{variant_key}_{arch}{_SHARED_LIB_EXT}"
        meta = self._read_meta(variant_key, so_path)
        if meta is None:
            if self.jit_compile_fn is None:
                return None
            try:
                so_path, symbols, arg_kinds, memref_specs = self._jit_build(
                    variant, arch, so_path,
                )
            except Exception as exc:
                # Surface the underlying compile failure when KESTREL_CUTE_JIT_DEBUG=1.
                # Otherwise silently fall back so the caller's "set
                # KESTREL_CUTE_JIT=1" hint stays accurate when JIT is off.
                import os, traceback
                if os.environ.get("KESTREL_CUTE_JIT_DEBUG") == "1":
                    print(f"[AotFamily] JIT build failed for {variant_key} on {arch}: "
                          f"{type(exc).__name__}: {exc}", flush=True)
                    traceback.print_exc()
                return None
        else:
            symbols, arg_kinds, memref_specs = meta

        bundle = AotVariantBundle(
            aot=CuteAotVariant(so_path, symbols),
            memref_specs=memref_specs,
            arg_kinds=arg_kinds,
        )
        self._cache[cache_key] = bundle
        return bundle

    def _jit_build(self, variant, arch: str, so_path: Path):
        import cutlass.cute as cute
        from scripts.precompile import cubin_bundles as _cubin_bundles
        from scripts.precompile.cute_aot_build import (
            build_aot_variant, aot_symbol_names, aot_arg_kinds,
        )

        compile_fn = self.jit_compile_fn(variant)
        fn_args = compile_fn(arch)
        kernel_target, *args = fn_args
        with _cubin_bundles.target_arch_env(arch):
            compiled = cute.compile(
                kernel_target, *args,
                options=_cubin_bundles.cute_compile_options_for_target_arch(arch),
            )

        variant_key = getattr(variant, "variant_key", variant)
        so_path.parent.mkdir(parents=True, exist_ok=True)
        build_aot_variant(compiled, variant_key, so_path)
        symbols = aot_symbol_names(variant_key, compiled.function_name)
        arg_kinds = aot_arg_kinds(compiled)
        memref_specs = tuple(
            MemrefStructSpec(
                shape_mask=list(a.dynamic_shapes_mask),
                stride_mask=list(a.dynamic_strides_mask),
            )
            for a in args if hasattr(a, "dynamic_shapes_mask")
        )

        so_path.with_suffix(".aot.json").write_text(json.dumps({
            "symbols": symbols,
            "arg_kinds": arg_kinds,
            "memref_specs": [s.to_json() for s in memref_specs],
        }))

        return so_path, symbols, arg_kinds, memref_specs


__all__ = ["AotFamily", "AotVariantBundle", "CuteAotVariant", "MemrefStructSpec"]
