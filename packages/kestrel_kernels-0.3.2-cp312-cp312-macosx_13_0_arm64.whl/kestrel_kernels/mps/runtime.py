"""MPS KernelRuntime.

Subclasses ``KernelRuntime`` and overrides every property so no CUDA-only
import is ever triggered on macOS. Real implementations land module-by-module;
un-implemented callables raise ``NotImplementedError`` via ``_mps_not_implemented``
until their PR arrives.
"""

from typing import Any, Callable

from kestrel_kernels.mps.attention import (
    flash_attn_fwd_mps,
    prefix_lm_mask_730_mps,
)
from kestrel_kernels.mps.cache import reshape_and_cache_flash_mps
from kestrel_kernels.mps.dense import (
    fused_mlp_gelu_bias_residual_cuda_mps,
    layernorm_bias as layernorm_bias_mps,
    layernorm_bias_into as layernorm_bias_into_mps,
)
from kestrel_kernels.mps.moe import (
    gelu_residual_cute_mps,
    get_moe_block_m_mps,
    invoke_moe_gemm_mps,
    moe_align_block_size_mps,
    moe_sum_mps,
    topk_fwd_mps,
)
from kestrel_kernels.mps.projection import (
    fused_linear_bias_residual_into_mps,
    gelu_cute_mps,
    linear_mps,
)
from kestrel_kernels.mps.rotary import rotary_embedding_mps
from kestrel_kernels.mps.sampling import sample_step_from_logits_mps
from kestrel_kernels.mps.tau import tau_tail_apply_into_mps
from kestrel_kernels.runtime import (
    AttentionRuntime,
    CacheRuntime,
    DenseRuntime,
    GeluRuntime,
    KernelRuntime,
    LinearRuntime,
    MoeRuntime,
    RotaryRuntime,
    SamplingRuntime,
    TauRuntime,
    VisionRuntime,
)


def _mps_not_implemented(domain: str, name: str) -> Callable[..., Any]:
    def _stub(*_args, **_kwargs):
        raise NotImplementedError(
            f"kestrel-kernels MPS backend: '{domain}.{name}' is not yet "
            f"implemented. See docs/MAC_SUPPORT.md for the roadmap."
        )

    return _stub


class MPSKernelRuntime(KernelRuntime):
    """PyTorch MPS backend.

    Properties return sub-runtimes populated with real torch-based
    implementations where available; callables that haven't been ported yet
    raise ``NotImplementedError``. See ``docs/MAC_SUPPORT.md`` for roadmap.
    """

    @property
    def attention(self) -> AttentionRuntime:
        return AttentionRuntime(
            flash_attn_fwd=flash_attn_fwd_mps,
            prefix_lm_mask_730=prefix_lm_mask_730_mps,
        )

    @property
    def moe(self) -> MoeRuntime:
        # MoE paths implemented in v1: unified ``invoke_moe_gemm`` (torch
        # per-expert loop), ``moe_sum``, ``gelu_residual_cute``,
        # ``moe_align_block_size``, ``get_moe_block_m``. CuTe / FP8 / Triton
        # variants and MoE-LoRA alignment stay stubbed — the dispatcher
        # never selects those paths on MPS (feature-detection lambdas
        # return False/None).
        return MoeRuntime(
            fp8_quant_cute=_mps_not_implemented("moe", "fp8_quant_cute"),
            gelu_residual_cute=gelu_residual_cute_mps,
            moe_sum=moe_sum_mps,
            topk_fwd=topk_fwd_mps,
            has_cute_moe_config=lambda *_a, **_kw: False,
            get_cute_moe_block_m=_mps_not_implemented("moe", "get_cute_moe_block_m"),
            get_cute_moe_config=_mps_not_implemented("moe", "get_cute_moe_config"),
            invoke_cute_moe_down=_mps_not_implemented("moe", "invoke_cute_moe_down"),
            invoke_cute_moe_down_fp8=_mps_not_implemented(
                "moe", "invoke_cute_moe_down_fp8"
            ),
            invoke_cute_moe_up=_mps_not_implemented("moe", "invoke_cute_moe_up"),
            invoke_cute_moe_up_fp8=_mps_not_implemented(
                "moe", "invoke_cute_moe_up_fp8"
            ),
            moe_align_block_size=moe_align_block_size_mps,
            moe_lora_align_block_size=_mps_not_implemented(
                "moe", "moe_lora_align_block_size"
            ),
            dtype_to_triton=_mps_not_implemented("moe", "dtype_to_triton"),
            invoke_fused_moe_kernel_triton=_mps_not_implemented(
                "moe", "invoke_fused_moe_kernel_triton"
            ),
            invoke_fused_moe_kernel_triton_fp8=_mps_not_implemented(
                "moe", "invoke_fused_moe_kernel_triton_fp8"
            ),
            get_triton_moe_config=lambda *_a, **_kw: None,
            invoke_moe_gemm=invoke_moe_gemm_mps,
            get_moe_block_m=get_moe_block_m_mps,
        )

    @property
    def cache(self) -> CacheRuntime:
        return CacheRuntime(
            reshape_and_cache_flash=reshape_and_cache_flash_mps,
        )

    @property
    def rotary(self) -> RotaryRuntime:
        return RotaryRuntime(
            rotary_embedding=rotary_embedding_mps,
        )

    @property
    def tau(self) -> TauRuntime:
        return TauRuntime(
            tau_tail_apply_into=tau_tail_apply_into_mps,
        )

    @property
    def vision(self) -> VisionRuntime:
        return VisionRuntime(
            fused_linear_bias_residual_into=fused_linear_bias_residual_into_mps,
        )

    @property
    def linear(self) -> LinearRuntime:
        return LinearRuntime(linear=linear_mps)

    @property
    def gelu(self) -> GeluRuntime:
        return GeluRuntime(gelu_cute=gelu_cute_mps)

    @property
    def dense(self) -> DenseRuntime:
        return DenseRuntime(
            fused_mlp_gelu_bias_residual=fused_mlp_gelu_bias_residual_cuda_mps,
            layernorm_bias_into=layernorm_bias_into_mps,
            layernorm_bias=layernorm_bias_mps,
        )

    @property
    def sampling(self) -> SamplingRuntime:
        return SamplingRuntime(sample_step_from_logits=sample_step_from_logits_mps)

    @property
    def compute_capability(self) -> tuple[int, int]:
        return (0, 0)

    @property
    def is_sm90(self) -> bool:
        return False


__all__ = ["MPSKernelRuntime"]
