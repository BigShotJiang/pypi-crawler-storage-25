"""PyTorch MPS backend for kestrel-kernels.

This backend is selected automatically when running on macOS / when CUDA is
unavailable. See ``docs/MAC_SUPPORT.md`` for the full design.

Version 1 is a skeleton: every kernel method raises ``NotImplementedError``.
Implementations land in follow-up PRs.
"""
