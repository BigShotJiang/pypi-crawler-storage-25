"""MPS dense ops: layernorm + fused MLP.

LayerNorm goes through the native Metal kernel
``torch.ops.kestrel_mps.layer_norm`` lifted from MLX's
``layer_norm_single_row``. The high-level ``layernorm_bias_into`` /
``layernorm_bias`` API matches the CUDA backend so kestrel can call
``_KERNELS.dense.layernorm_bias_into(...)`` arch-agnostically.

``fused_mlp_gelu_bias_residual_cuda_mps`` is still a torch composition —
the underlying matmul + gelu + add already dispatch to MPSGraph kernels
that are hard to beat without a custom matmul.
"""

import torch
import torch.nn.functional as F

# Side-effect import: loads the pre-built Metal library + registers ops
# under ``torch.ops.kestrel_mps`` at first use.
from kestrel_kernels.mps import _native


def layernorm_bias_into(
    out: torch.Tensor,
    x: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor,
    eps: float = 1e-5,
    *,
    variant: str = "auto",
    fallback_to_torch: bool = False,
) -> None:
    """LayerNorm forward via the Metal kernel.

    ``variant`` is accepted for signature parity with the CUDA backend
    (which has register-pressure variants); on MPS both map to the same
    kernel since the Metal kernel doesn't have the same ldg/stg knobs.
    """
    if x.ndim not in (2, 3):
        raise ValueError(f"x must be 2D or 3D, got {tuple(x.shape)}")
    if out.shape != x.shape:
        raise ValueError(f"out must match x shape {tuple(x.shape)}, got {tuple(out.shape)}")
    if weight.ndim != 1 or bias.ndim != 1:
        raise ValueError("weight and bias must be 1D")
    if x.shape[-1] != weight.shape[0] or weight.shape != bias.shape:
        raise ValueError("weight/bias must match x last dimension")

    if x.ndim == 3:
        b, t, n = x.shape
        x2 = x.reshape(b * t, n)
        # ``out.view(...)`` (not ``reshape``) so a non-contiguous output
        # raises rather than allocating a temporary that the kernel
        # writes to while the caller's tensor stays unchanged.
        out2 = out.view(b * t, n)
    else:
        x2 = x
        out2 = out

    # ``variant`` is accepted for signature parity with CUDA but ignored
    # at dispatch (Metal kernel has no register-pressure variants).
    # Validate up front so a typo raises rather than being swallowed
    # by ``fallback_to_torch``.
    if variant not in ("auto", "default", "reload_x"):
        raise ValueError(f"Unknown layernorm variant: {variant!r}")

    try:
        torch.ops.kestrel_mps.layer_norm(out2, x2, weight, bias, float(eps))
    except Exception:
        if not fallback_to_torch:
            raise
        out2.copy_(F.layer_norm(x2, (x2.shape[1],), weight, bias, float(eps)))


def layernorm_bias(
    x: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor,
    *,
    eps: float = 1e-5,
    fallback_to_torch: bool = False,
) -> torch.Tensor:
    out = torch.empty_like(x)
    layernorm_bias_into(
        out, x, weight, bias, eps,
        fallback_to_torch=fallback_to_torch,
    )
    return out


def fused_mlp_gelu_bias_residual_cuda_mps(
    out: torch.Tensor,
    hidden: torch.Tensor,  # workspace; unused on MPS (torch handles allocation)
    x: torch.Tensor,
    w1: torch.Tensor,
    b1: torch.Tensor,
    w2: torch.Tensor,
    b2: torch.Tensor,
    residual: torch.Tensor,
) -> None:
    """In-place ``out = residual + F.linear(F.gelu(F.linear(x, w1, b1)), w2, b2)``.

    ``hidden`` is a pre-allocated workspace the CUDA kernel writes the GELU'd
    intermediate into; PyTorch handles that allocation implicitly, so the
    argument is accepted for signature parity and not otherwise used.
    """
    h = F.gelu(F.linear(x, w1, b1))
    result = residual + F.linear(h, w2, b2)
    out.copy_(result)


__all__ = [
    "fused_mlp_gelu_bias_residual_cuda_mps",
    "layernorm_bias",
    "layernorm_bias_into",
]
