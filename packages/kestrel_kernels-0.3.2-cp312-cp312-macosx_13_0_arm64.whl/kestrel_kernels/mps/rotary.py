"""MPS rotary embedding.

Routes through the native Metal kernel registered as
``torch.ops.kestrel_mps.rotary_embedding``. Loading of the extension +
metallib happens in ``kestrel_kernels.mps._native`` at import time; a
failure there raises (no silent torch fallback).
"""

import torch

# Side-effect import: loads the pre-built Metal library + registers ops
# under ``torch.ops.kestrel_mps`` at first ``rotary`` use. A build or
# install defect here raises immediately rather than silently falling
# back to a Python path.
from kestrel_kernels.mps import _native


def rotary_embedding_mps(
    positions: torch.Tensor,
    query: torch.Tensor,
    key: torch.Tensor,
    head_size: int,
    cos_sin_cache: torch.Tensor,
) -> None:
    """In-place RoPE on ``query`` and ``key`` using a cached cos/sin table.

    Workaround for a B>1, q_len=1 correctness bug in the underlying
    ``torch.ops.kestrel_mps.rotary_embedding`` Metal kernel: the kernel
    uses ``data.stride(-3)`` (q_len-dim stride) as its per-token stride.
    For a contiguous ``[B, q_len, H, D]`` tensor that's correct, but for
    a non-contiguous ``[B, q_len=1, H, D]`` view sliced out of a fused
    QKV projection (typical decode K), ``stride(-3) = qkv_dim`` while
    consecutive tokens are actually separated by ``stride(-4) = qkv_dim``
    along the B dim — and the kernel iterates ``token = 0..B-1`` because
    ``positions.numel() = B``. The result is that token=1 reads/writes
    the wrong memory and slot 1's K never gets rotated, producing
    silently corrupted output at any B>1 decode.

    Fix: when q_len == 1, squeeze it out so the kernel sees a
    rank-3 tensor ``[B, H, D]`` whose ``stride(-3)`` IS the B stride.
    ``squeeze`` is a view, so in-place rotation still updates the
    caller's tensor. No copy.
    """
    if (
        query.dim() == 4
        and query.size(1) == 1
        and key.dim() == 4
        and key.size(1) == 1
    ):
        query = query.squeeze(1)
        key = key.squeeze(1)
        # Match positions: kernel reads ``positions[token]`` for
        # token in [0, total_tokens). With squeezed query (B, H, D),
        # total_tokens = B; positions must be a flat [B] tensor.
        if positions.dim() > 1:
            positions = positions.reshape(-1)
    torch.ops.kestrel_mps.rotary_embedding(
        positions, query, key, head_size, cos_sin_cache
    )


__all__ = ["rotary_embedding_mps"]
