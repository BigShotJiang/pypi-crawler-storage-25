"""Load the native ``_kestrel_mps`` extension + shipped metallib.

Runs exactly once per package import on macOS. A missing extension or
metallib on darwin means a broken install — we raise rather than fall
back. On non-darwin imports we no-op: the artifacts aren't built off
APPLE, but downstream code (e.g. ``mps/runtime.py``) still gets imported
for type / dispatch checks (see ``tests/mps/test_platform_dispatch.py``
non-darwin path) and shouldn't error.
"""

from __future__ import annotations

import os
import sys


def _load() -> None:
    if sys.platform != "darwin":
        return  # no native build off APPLE; ``MPSKernelRuntime`` not used
    pkg_dir = os.path.dirname(os.path.dirname(__file__))
    metallib = os.path.join(pkg_dir, "kestrel_mps.metallib")
    if not os.path.exists(metallib):
        raise RuntimeError(
            f"kestrel_kernels: missing {metallib}. The macOS wheel must ship "
            "the pre-compiled Metal library; reinstall the package."
        )
    from kestrel_kernels import _kestrel_mps

    _kestrel_mps.set_metallib_path(metallib)


_load()
