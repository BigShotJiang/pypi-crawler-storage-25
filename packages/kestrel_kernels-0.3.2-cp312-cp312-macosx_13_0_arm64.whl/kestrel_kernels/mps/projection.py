"""MPS projection + activation ops.

Thin PyTorch wrappers that mirror the CUDA cublasLt / cubin entry points:

- ``linear_mps`` — ``F.linear``, keeping the CUDA signature (``out=`` reuse,
  optional 3D batch reshape).
- ``gelu_cute_mps`` — ``F.gelu`` with the CUDA shape validation stripped
  (no per-variant cubin on MPS, any last-dim works).
"""

import torch
import torch.nn.functional as F


def linear_mps(
    x: torch.Tensor,
    w: torch.Tensor,
    bias: torch.Tensor | None = None,
    out: torch.Tensor | None = None,
) -> torch.Tensor:
    """Linear projection ``out = x @ w.T [+ bias]`` on MPS.

    Matches ``kestrel_kernels.linear_ops.linear`` exactly: when ``x`` is
    3D ``(bsz, t, c)`` the call is flattened to 2D, written into (or
    allocated as) a 2D ``out`` buffer, and the returned tensor is a 3D
    view ``(bsz, t, out_dim)``.
    """
    if x.ndim == 3:
        bsz, t, c = x.shape
        x2 = x.reshape(bsz * t, c)
    else:
        bsz = 0
        x2 = x
    result = F.linear(x2, w, bias)
    if out is not None:
        out.copy_(result)
    else:
        out = result
    if bsz:
        return out.view(bsz, t, w.size(0))
    return out


def gelu_cute_mps(
    inp: torch.Tensor, out: torch.Tensor | None = None
) -> torch.Tensor:
    """Plain GELU activation on MPS.

    Matches ``kestrel_kernels.gelu_residual.gelu_cute`` — including the
    contract that the returned tensor has ``inp``'s logical shape even
    when the caller hands us a flattened scratch ``out`` buffer (see
    ``gelu_residual/dispatch.py::_normalize_gelu_out``).
    """
    if out is None:
        return F.gelu(inp)
    out.copy_(F.gelu(inp).reshape(out.shape))
    if out.shape != inp.shape:
        if out.numel() != inp.numel():
            raise ValueError(
                "gelu_cute_mps out tensor must match the input shape or "
                f"have the same number of elements, got "
                f"inp={tuple(inp.shape)} out={tuple(out.shape)}"
            )
        return out.view_as(inp)
    return out


def fused_linear_bias_residual_into_mps(
    *,
    x: torch.Tensor,
    w: torch.Tensor,
    b: torch.Tensor,
    residual: torch.Tensor,
    out: torch.Tensor,
) -> None:
    """In-place ``out = residual + F.linear(x, w, b)`` on MPS.

    Mirrors ``kestrel_kernels.fused_linear_residual_ops.fused_linear_bias_residual_into``.
    The CUDA kernel fuses the GEMM with the residual add in one launch; on
    MPS we do the equivalent in two torch ops.
    """
    result = residual + F.linear(x, w, b)
    out.copy_(result.reshape(out.shape))


__all__ = [
    "linear_mps",
    "gelu_cute_mps",
    "fused_linear_bias_residual_into_mps",
]
