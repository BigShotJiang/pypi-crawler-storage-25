"""MoE sum dispatch — direct call into _pybridge."""


import torch

from kestrel_kernels._pybridge import moe_sum_bf16 as _raw
from kestrel_kernels.fallback import should_use_cuda_impl
from kestrel_kernels.moe_sum_ops.fallback import moe_sum_torch

_SUPPORTED_SMS = {80, 86, 87, 89, 90, 100, 110, 120}


def moe_sum(inp: torch.Tensor, out: torch.Tensor) -> None:
    if not should_use_cuda_impl(
        device=inp.device,
        kernel_key="moe_sum_non_supported_arch",
        op_name="moe_sum",
        supported_sms=_SUPPORTED_SMS,
    ):
        moe_sum_torch(inp, out)
        return
    if (inp.dtype == torch.bfloat16 and inp.size(1) == 8
            and (inp.size(2) % 8) == 0
            and inp.is_contiguous() and out.is_contiguous()):
        _raw(inp, out)
    else:
        moe_sum_torch(inp, out)


__all__ = ["moe_sum"]
