"""Typer application for the `pmem` CLI.

The CLI layer parses arguments, calls service use cases, and renders safe
messages. Database writes, filesystem policy, and domain rules stay below this
layer so commands remain easy to test and extend.
"""

import json
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from pmem import __version__
from pmem.domain.conflicts import ConflictCheckReport
from pmem.domain.import_bundle import ImportDryRunReport
from pmem.errors import PmemError, PmemValidationError
from pmem.repositories.failures import FailureRecord
from pmem.services.baseline import compare_run_to_baseline, set_baseline_run
from pmem.services.conflict_detection import (
    check_bundle_conflicts,
    conflict_check_report_json,
)
from pmem.services.conflict_resolution import (
    conflict_resolution_result_json,
    record_conflict_resolution,
)
from pmem.services.decision_logging import log_decision
from pmem.services.export_bundle import (
    export_bundle,
    export_bundle_result_json,
)
from pmem.services.failure_clustering import (
    DEFAULT_SIMILARITY_THRESHOLD,
    failure_cluster_payload,
)
from pmem.services.failure_embeddings import (
    DEFAULT_EMBEDDING_DIMENSION,
    failure_embedding_payload,
)
from pmem.services.failure_exports import (
    export_failure_records,
    failure_export_payload,
)
from pmem.services.failure_logging import log_failure
from pmem.services.failure_patterns import (
    failure_analysis_summary_payload,
    failure_pattern_report_payload,
)
from pmem.services.import_apply import (
    apply_import_bundle,
    import_apply_result_json,
)
from pmem.services.import_dry_run import (
    dry_run_import_bundle,
    import_dry_run_report_json,
)
from pmem.services.note_logging import add_note
from pmem.services.project_export import export_project
from pmem.services.project_init import init_project
from pmem.services.run_capture import run_command
from pmem.services.shared_paths import (
    list_shared_path_statuses,
    register_shared_path,
    shared_path_registration_json,
    shared_path_statuses_json,
)
from pmem.services.tracking import track_path
from pmem.summary import ProjectSummary, get_project_summary, summary_json_payload

console = Console()

app = typer.Typer(
    add_completion=False,
    help="Local-first long-horizon project memory for AI research.",
    no_args_is_help=True,
)

share_app = typer.Typer(
    add_completion=False,
    help="Register and inspect explicit local shared memory paths.",
    no_args_is_help=True,
)
app.add_typer(share_app, name="share")

failures_app = typer.Typer(
    add_completion=False,
    help="List and export confirmed failure records with privacy-safe defaults.",
    no_args_is_help=True,
)
app.add_typer(failures_app, name="failures")


def _version_callback(show_version: bool) -> None:
    """Print the installed CLI version and exit.

    Keeping version handling in one callback makes the smoke test tiny while
    leaving room for richer diagnostics in a future `pmem doctor` command.
    """

    if show_version:
        console.print(f"pmem {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            callback=_version_callback,
            is_eager=True,
            help="Show the installed pmem version and exit.",
        ),
    ] = False,
) -> None:
    """Run the pmem command-line interface.

    The callback is intentionally light in D2. It provides help/version behavior
    without pretending that Phase 1 commands are implemented before their gates.
    """


@app.command("init")
def init_command(
    name: Annotated[
        str | None,
        typer.Option(
            "--name",
            help="Optional local project name. Defaults to the current directory name.",
        ),
    ] = None,
    goal: Annotated[
        str | None,
        typer.Option(
            "--goal",
            help="Optional project goal stored in the local project record.",
        ),
    ] = None,
    objective: Annotated[
        str | None,
        typer.Option(
            "--objective",
            help="Optional current objective stored in the local project record.",
        ),
    ] = None,
    metric: Annotated[
        str | None,
        typer.Option(
            "--metric",
            help="Optional primary metric name.",
        ),
    ] = None,
    metric_direction: Annotated[
        str | None,
        typer.Option(
            "--metric-direction",
            help="Metric direction when a metric or target is provided: max or min.",
        ),
    ] = None,
    target: Annotated[
        float | None,
        typer.Option(
            "--target",
            help="Optional numeric target value. Requires --metric and --metric-direction.",
        ),
    ] = None,
) -> None:
    """Initialize project-local `.pmem/` state."""

    try:
        result = init_project(
            project_root=Path.cwd(),
            project_name=name,
            goal=goal,
            current_objective=objective,
            primary_metric=metric,
            metric_direction=metric_direction,
            target_value=target,
        )
    except PmemError as exc:
        _exit_with_error(exc)

    if result.already_initialized:
        console.print("projmem is already initialized.")
    else:
        console.print("Initialized projmem at .pmem/")
    console.print("Database ready.")


@app.command("track")
def track_command(
    path: Annotated[
        str,
        typer.Argument(help="Project-relative file path to track."),
    ],
    update: Annotated[
        bool,
        typer.Option(
            "--update",
            help="Refresh the stored SHA-256 if the file is already tracked.",
        ),
    ] = False,
) -> None:
    """Track one project file by SHA-256."""

    try:
        result = track_path(project_root=Path.cwd(), user_path=path, update=update)
    except PmemError as exc:
        _exit_with_error(exc)

    if result.updated:
        console.print(f"Updated {result.path}")
    elif result.already_tracked:
        console.print(f"{result.path} is already tracked.")
    else:
        console.print(f"Tracked {result.path}")
    console.print(f"sha256: {result.sha256}")


@app.command(
    "run",
    context_settings={
        "allow_extra_args": True,
        "ignore_unknown_options": True,
    },
)
def run_cli_command(
    command: Annotated[
        list[str] | None,
        typer.Argument(help="Command argv to execute after `--`."),
    ] = None,
    name: Annotated[
        str | None,
        typer.Option(
            "--name",
            help="Optional human label for this run.",
        ),
    ] = None,
    timeout: Annotated[
        float | None,
        typer.Option(
            "--timeout",
            help="Optional timeout in seconds.",
        ),
    ] = None,
    seed: Annotated[
        str | None,
        typer.Option(
            "--seed",
            help="Optional reproducibility seed recorded with the run.",
        ),
    ] = None,
    config: Annotated[
        str | None,
        typer.Option(
            "--config",
            help="Optional project-relative JSON config file to hash and store with redaction.",
        ),
    ] = None,
    metrics: Annotated[
        str | None,
        typer.Option(
            "--metrics",
            help="Optional project-relative JSON metrics file to load after the command.",
        ),
    ] = None,
    artifact: Annotated[
        list[str] | None,
        typer.Option(
            "--artifact",
            help="Optional project-relative artifact file to hash after the command.",
        ),
    ] = None,
) -> None:
    """Run a command and capture local evidence."""

    try:
        result = run_command(
            project_root=Path.cwd(),
            command_args=command or [],
            name=name,
            timeout_seconds=timeout,
            seed=seed,
            config_path=config,
            metrics_path=metrics,
            artifact_paths=tuple(artifact or ()),
        )
    except PmemError as exc:
        _exit_with_error(exc)

    console.print(f"Run {result.record.run_id} {result.record.status}")
    if result.record.exit_code is not None:
        console.print(f"exit_code: {result.record.exit_code}")
    console.print(f"stdout: {result.stdout_path}")
    console.print(f"stderr: {result.stderr_path}")
    if result.artifact_count:
        console.print(f"artifacts: {result.artifact_count}")


@app.command("log-failure")
def log_failure_command(
    run_id: Annotated[
        str,
        typer.Argument(help="Run id to attach the confirmed failure to."),
    ],
    error_type: Annotated[
        str,
        typer.Argument(help="Short error type or failure class."),
    ],
    description: Annotated[
        str,
        typer.Argument(help="Human-readable failure description."),
    ],
    severity: Annotated[
        str,
        typer.Option(
            "--severity",
            help="Failure severity: critical, high, medium, or low.",
        ),
    ] = "medium",
    source: Annotated[
        str,
        typer.Option(
            "--source",
            help="Failure source: user_confirmed, auto_technical, or promoted_candidate.",
        ),
    ] = "user_confirmed",
    tag: Annotated[
        list[str] | None,
        typer.Option(
            "--tag",
            help="Failure tag. Can be provided multiple times.",
        ),
    ] = None,
    root_cause: Annotated[
        str | None,
        typer.Option(
            "--root-cause",
            help="Optional concise root cause. Do not include secrets.",
        ),
    ] = None,
    lesson: Annotated[
        str | None,
        typer.Option(
            "--lesson",
            help="Optional lesson learned. Do not include secrets.",
        ),
    ] = None,
    output: Annotated[
        str,
        typer.Option(
            "--output",
            help="Output format: text or json.",
        ),
    ] = "text",
) -> None:
    """Record a confirmed failure for an existing run."""

    try:
        output_format = _validate_output_format(output)
        record = log_failure(
            project_root=Path.cwd(),
            run_id=run_id,
            error_type=error_type,
            description=description,
            root_cause=root_cause,
            lesson=lesson,
            severity=severity,
            tags=tuple(tag or ()),
            source=source,
        )
    except PmemError as exc:
        _exit_with_error(exc)

    if output_format == "json":
        console.print_json(data=_failure_record_json(record))
        return

    console.print(f"Logged failure {record.id}")
    console.print(f"run_id: {record.run_id}")
    console.print(f"severity: {record.severity}")
    if record.tags_json != "[]":
        console.print(f"tags: {record.tags_json}")


@app.command("log-decision")
def log_decision_command(
    description: Annotated[
        str,
        typer.Argument(help="Decision summary."),
    ],
    rationale: Annotated[
        str | None,
        typer.Option(
            "--rationale",
            help="Optional rationale for the decision.",
        ),
    ] = None,
    experiment_id: Annotated[
        str | None,
        typer.Option(
            "--experiment-id",
            help="Optional experiment id linked to this decision.",
        ),
    ] = None,
    related_experiment: Annotated[
        list[str] | None,
        typer.Option(
            "--related-experiment",
            help="Related experiment id. Can be provided multiple times.",
        ),
    ] = None,
    author: Annotated[
        str | None,
        typer.Option(
            "--author",
            help="Optional author label.",
        ),
    ] = None,
) -> None:
    """Record a durable project decision."""

    try:
        record = log_decision(
            project_root=Path.cwd(),
            description=description,
            rationale=rationale,
            experiment_id=experiment_id,
            related_experiments=tuple(related_experiment or ()),
            author=author,
        )
    except PmemError as exc:
        _exit_with_error(exc)

    console.print(f"Logged decision {record.id}")
    console.print(f"project_id: {record.project_id}")
    if record.experiment_id:
        console.print(f"experiment_id: {record.experiment_id}")


@app.command("note")
def note_command(
    content: Annotated[
        str,
        typer.Argument(help="Note content."),
    ],
    experiment_id: Annotated[
        str | None,
        typer.Option(
            "--experiment-id",
            help="Optional experiment id linked to this note.",
        ),
    ] = None,
    run_id: Annotated[
        str | None,
        typer.Option(
            "--run-id",
            help="Optional run id linked to this note.",
        ),
    ] = None,
    tag: Annotated[
        list[str] | None,
        typer.Option(
            "--tag",
            help="Note tag. Can be provided multiple times.",
        ),
    ] = None,
    resolved: Annotated[
        bool,
        typer.Option(
            "--resolved",
            help="Mark the note as already resolved.",
        ),
    ] = False,
) -> None:
    """Record a lightweight project note."""

    try:
        record = add_note(
            project_root=Path.cwd(),
            content=content,
            experiment_id=experiment_id,
            run_id=run_id,
            tags=tuple(tag or ()),
            resolved=resolved,
        )
    except PmemError as exc:
        _exit_with_error(exc)

    console.print(f"Logged note {record.id}")
    console.print(f"project_id: {record.project_id}")
    if record.run_id:
        console.print(f"run_id: {record.run_id}")


@app.command("baseline")
def baseline_command(
    run_id: Annotated[
        str,
        typer.Argument(help="Run id to mark as baseline or compare to baseline."),
    ],
    compare: Annotated[
        bool,
        typer.Option(
            "--compare",
            help="Compare the run to the experiment baseline instead of marking it.",
        ),
    ] = False,
) -> None:
    """Mark or compare an experiment baseline run."""

    try:
        if compare:
            comparison = compare_run_to_baseline(project_root=Path.cwd(), run_id=run_id)
            console.print(f"Compared {comparison.run_id} to baseline.")
            console.print(f"baseline_run_id: {comparison.baseline_run_id}")
            console.print(f"experiment_id: {comparison.experiment_id}")
            console.print(f"metrics: {len(comparison.metric_deltas)}")
            for metric, delta in comparison.metric_deltas.items():
                console.print(f"{metric}: {delta:+.6f}")
            return
        else:
            baseline = set_baseline_run(project_root=Path.cwd(), run_id=run_id)
    except PmemError as exc:
        _exit_with_error(exc)

    console.print(f"Marked {baseline.run_id} as baseline.")
    console.print(f"experiment_id: {baseline.experiment_id}")
    console.print(f"metrics: {baseline.metric_count}")


@app.command("summary")
def summary_command(
    output: Annotated[
        str,
        typer.Option(
            "--output",
            help="Output format: text or json.",
        ),
    ] = "text",
) -> None:
    """Print a project summary with D18 timeline/status information."""

    try:
        output_format = _validate_output_format(output)
        summary = get_project_summary(project_root=Path.cwd())
    except PmemError as exc:
        _exit_with_error(exc)

    if output_format == "json":
        console.print_json(data=summary_json_payload(summary))
        return

    _print_summary(summary)


@app.command("export")
def export_command(
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Write the Phase 1 project export as JSON.",
        ),
    ] = False,
) -> None:
    """Export project-local memory as JSON without copying artifact contents."""

    try:
        if not json_output:
            raise PmemValidationError("Export currently supports --json only.")
        payload = export_project(project_root=Path.cwd())
    except PmemError as exc:
        _exit_with_error(exc)

    console.print_json(data=payload)


@app.command("export-bundle")
def export_bundle_command(
    out: Annotated[
        str,
        typer.Option(
            "--out",
            help="Output path for the Phase 2 export bundle JSON.",
        ),
    ],
    scope: Annotated[
        str,
        typer.Option(
            "--scope",
            help="Export scope. D25 supports project only.",
        ),
    ] = "project",
    include_artifacts: Annotated[
        bool,
        typer.Option(
            "--include-artifacts",
            help="Include explicit artifact bytes as base64 payloads.",
        ),
    ] = False,
    redact_fields: Annotated[
        str | None,
        typer.Option(
            "--redact-fields",
            help="Comma-separated privacy-sensitive field paths to replace with [REDACTED].",
        ),
    ] = None,
    freeze_timestamp: Annotated[
        str | None,
        typer.Option(
            "--freeze-timestamp",
            help="UTC ISO timestamp for deterministic bundle generation.",
        ),
    ] = None,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Write the export-bundle result as JSON.",
        ),
    ] = False,
) -> None:
    """Write a deterministic Phase 2 export bundle."""

    try:
        result = export_bundle(
            project_root=Path.cwd(),
            output_path=out,
            scope=scope,
            include_artifacts=include_artifacts,
            redact_fields=(redact_fields or "",),
            freeze_timestamp=freeze_timestamp,
        )
    except PmemError as exc:
        _exit_with_error(exc)

    if json_output:
        console.print_json(data=export_bundle_result_json(result))
        return

    console.print(f"Exported bundle: {result.display_path}")
    console.print(f"manifest_hash: {result.manifest_hash}")
    console.print(f"payload_hash: {result.payload_hash}")
    console.print(f"artifacts: {result.artifact_count}")


@app.command("import")
def import_command(
    bundle: Annotated[
        str,
        typer.Argument(help="Project-relative export bundle JSON path."),
    ],
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Validate the bundle and preview conflicts without writing to the database.",
        ),
    ] = False,
    apply: Annotated[
        bool,
        typer.Option(
            "--apply",
            help="Apply a validated bundle into pending/quarantine state.",
        ),
    ] = False,
    confirm: Annotated[
        bool,
        typer.Option(
            "--confirm",
            help="Confirm import apply after reviewing dry-run output.",
        ),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Write the import report as JSON.",
        ),
    ] = False,
) -> None:
    """Validate or quarantine-apply a Phase 2 bundle."""

    try:
        if dry_run and apply:
            raise PmemValidationError("Choose either --dry-run or --apply, not both.")
        if not dry_run and not apply:
            raise PmemValidationError("Import requires --dry-run or --apply.")
        if apply:
            result = apply_import_bundle(
                project_root=Path.cwd(),
                bundle_path=bundle,
                confirm=confirm,
            )
            if json_output:
                console.print_json(data=import_apply_result_json(result))
            else:
                console.print("Import apply: PENDING")
                console.print(f"import_job_id: {result.job.id}")
                console.print("Database mutation: import_jobs/audit_events only")
                console.print(f"integrity_check: {result.integrity_check}")
            return
        report = dry_run_import_bundle(project_root=Path.cwd(), bundle_path=bundle)
    except PmemError as exc:
        _exit_with_error(exc)

    if json_output:
        console.print_json(data=import_dry_run_report_json(report))
    else:
        _print_import_dry_run_report(report)

    if not report.ok:
        raise typer.Exit(code=1)


@app.command("conflict-check")
def conflict_check_command(
    bundle: Annotated[
        str,
        typer.Argument(help="Project-relative export bundle JSON path."),
    ],
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Write the conflict report as JSON.",
        ),
    ] = False,
) -> None:
    """Detect Phase 2 import conflicts without mutating local data."""

    try:
        report = check_bundle_conflicts(project_root=Path.cwd(), bundle_path=bundle)
    except PmemError as exc:
        _exit_with_error(exc)

    if json_output:
        console.print_json(data=conflict_check_report_json(report))
    else:
        _print_conflict_check_report(report)

    if not report.validation_ok:
        raise typer.Exit(code=1)


@app.command("resolve")
def resolve_command(
    conflict_id: Annotated[
        str,
        typer.Argument(help="Conflict id from `pmem conflict-check`."),
    ],
    action: Annotated[
        str,
        typer.Option(
            "--action",
            help=(
                "Resolution action: skip, keep-local, manual-required, duplicate, "
                "take-imported, overwrite."
            ),
        ),
    ],
    before_hash: Annotated[
        str | None,
        typer.Option(
            "--before-hash",
            help="Optional sha256 hash of local evidence before resolution.",
        ),
    ] = None,
    after_hash: Annotated[
        str | None,
        typer.Option(
            "--after-hash",
            help="Optional sha256 hash of chosen evidence after resolution.",
        ),
    ] = None,
    confirm: Annotated[
        bool,
        typer.Option(
            "--confirm",
            help="Confirm destructive-looking actions. Canonical data is still not overwritten.",
        ),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Write the resolution audit result as JSON.",
        ),
    ] = False,
) -> None:
    """Record a non-destructive conflict resolution audit event."""

    try:
        result = record_conflict_resolution(
            project_root=Path.cwd(),
            conflict_id=conflict_id,
            action=action,
            before_hash=before_hash,
            after_hash=after_hash,
            confirm=confirm,
        )
    except PmemError as exc:
        _exit_with_error(exc)

    if json_output:
        console.print_json(data=conflict_resolution_result_json(result))
        return

    console.print("Conflict resolution recorded.")
    console.print(f"conflict_id: {result.conflict_id}")
    console.print(f"action: {result.action}")
    console.print("Database mutation: audit_events only")
    console.print("Canonical data mutation: none")


@failures_app.command("list")
def failures_list_command(
    include_text: Annotated[
        bool,
        typer.Option(
            "--include-text",
            help="Include raw failure description/root-cause/lesson text.",
        ),
    ] = False,
    confirm: Annotated[
        bool,
        typer.Option(
            "--confirm",
            help="Confirm that raw failure text may be printed.",
        ),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Write failure records as JSON.",
        ),
    ] = False,
) -> None:
    """List confirmed failures without exposing raw text by default."""

    try:
        _require_failure_text_confirmation(include_text=include_text, confirm=confirm)
        payload = failure_export_payload(Path.cwd(), include_text=include_text)
    except PmemError as exc:
        _exit_with_error(exc)

    if json_output:
        console.print_json(data=payload)
        return

    _print_failure_records(payload)


@failures_app.command("export")
def failures_export_command(
    out: Annotated[
        str,
        typer.Option(
            "--out",
            help="Project-relative JSON output path.",
        ),
    ],
    include_text: Annotated[
        bool,
        typer.Option(
            "--include-text",
            help="Include raw failure description/root-cause/lesson text.",
        ),
    ] = False,
    confirm: Annotated[
        bool,
        typer.Option(
            "--confirm",
            help="Confirm that raw failure text may be written.",
        ),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Write export result metadata as JSON.",
        ),
    ] = False,
) -> None:
    """Export confirmed failures to reviewable JSON."""

    try:
        _require_failure_text_confirmation(include_text=include_text, confirm=confirm)
        result = export_failure_records(
            Path.cwd(),
            output_path=out,
            include_text=include_text,
        )
    except PmemError as exc:
        _exit_with_error(exc)

    result_payload = {
        "ok": True,
        "path": result.display_path,
        "schema_version": result.payload["schema_version"],
        "privacy_mode": result.payload["privacy_mode"],
        "include_text": result.payload["include_text"],
        "record_count": result.payload["record_count"],
    }
    if json_output:
        console.print_json(data=result_payload)
        return

    console.print(f"Exported failures: {result.display_path}")
    console.print(f"records: {result.payload['record_count']}")
    console.print(f"privacy_mode: {result.payload['privacy_mode']}")


@failures_app.command("embed")
def failures_embed_command(
    dimension: Annotated[
        int,
        typer.Option(
            "--dimension",
            help="Hashing-vector dimension for local failure embeddings.",
        ),
    ] = DEFAULT_EMBEDDING_DIMENSION,
    include_text: Annotated[
        bool,
        typer.Option(
            "--include-text",
            help="Derive vectors from raw failure description/root-cause/lesson text.",
        ),
    ] = False,
    confirm: Annotated[
        bool,
        typer.Option(
            "--confirm",
            help="Confirm that raw failure text may be used to derive embeddings.",
        ),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Write embedding records as JSON.",
        ),
    ] = False,
) -> None:
    """Compute deterministic local failure embeddings."""

    try:
        _require_failure_text_confirmation(include_text=include_text, confirm=confirm)
        payload = failure_embedding_payload(
            Path.cwd(),
            include_text=include_text,
            dimension=dimension,
        )
    except PmemError as exc:
        _exit_with_error(exc)

    if json_output:
        console.print_json(data=payload)
        return

    console.print(f"Failure embeddings: {payload['record_count']}")
    console.print(f"method: {payload['method']}")
    console.print(f"dimension: {payload['dimension']}")
    console.print(f"privacy_mode: {payload['privacy_mode']}")


@failures_app.command("cluster")
def failures_cluster_command(
    dimension: Annotated[
        int,
        typer.Option(
            "--dimension",
            help="Hashing-vector dimension for local failure embeddings.",
        ),
    ] = DEFAULT_EMBEDDING_DIMENSION,
    threshold: Annotated[
        float,
        typer.Option(
            "--threshold",
            help="Cosine similarity threshold from 0.0 to 1.0.",
        ),
    ] = DEFAULT_SIMILARITY_THRESHOLD,
    include_text: Annotated[
        bool,
        typer.Option(
            "--include-text",
            help="Derive clusters from raw failure description/root-cause/lesson text.",
        ),
    ] = False,
    confirm: Annotated[
        bool,
        typer.Option(
            "--confirm",
            help="Confirm that raw failure text may be used to derive clusters.",
        ),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Write cluster report as JSON.",
        ),
    ] = False,
) -> None:
    """Cluster local failure embeddings without network or vector DB."""

    try:
        _require_failure_text_confirmation(include_text=include_text, confirm=confirm)
        payload = failure_cluster_payload(
            Path.cwd(),
            include_text=include_text,
            dimension=dimension,
            similarity_threshold=threshold,
        )
    except PmemError as exc:
        _exit_with_error(exc)

    if json_output:
        console.print_json(data=payload)
        return

    console.print(f"Failure clusters: {payload['cluster_count']}")
    console.print(f"records: {payload['record_count']}")
    console.print(f"threshold: {payload['similarity_threshold']}")
    console.print(f"privacy_mode: {payload['privacy_mode']}")
    for cluster in payload["clusters"]:
        console.print(
            f"- {cluster['cluster_id']}: size={cluster['size']} "
            f"prototype={cluster['prototype_failure_id']}"
        )


@failures_app.command("patterns")
def failures_patterns_command(
    dimension: Annotated[
        int,
        typer.Option(
            "--dimension",
            help="Hashing-vector dimension for local failure pattern analysis.",
        ),
    ] = DEFAULT_EMBEDDING_DIMENSION,
    threshold: Annotated[
        float,
        typer.Option(
            "--threshold",
            help="Cosine similarity threshold from 0.0 to 1.0.",
        ),
    ] = DEFAULT_SIMILARITY_THRESHOLD,
    include_text: Annotated[
        bool,
        typer.Option(
            "--include-text",
            help="Derive text terms from raw failure description/root-cause/lesson text.",
        ),
    ] = False,
    confirm: Annotated[
        bool,
        typer.Option(
            "--confirm",
            help="Confirm that raw failure text may be used to derive pattern signals.",
        ),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Write pattern report as JSON.",
        ),
    ] = False,
) -> None:
    """Generate human-reviewable failure pattern candidates."""

    try:
        _require_failure_text_confirmation(include_text=include_text, confirm=confirm)
        payload = failure_pattern_report_payload(
            Path.cwd(),
            include_text=include_text,
            dimension=dimension,
            similarity_threshold=threshold,
        )
    except PmemError as exc:
        _exit_with_error(exc)

    if json_output:
        console.print_json(data=payload)
        return

    _print_failure_pattern_report(payload)


@failures_app.command("summary")
def failures_summary_command(
    dimension: Annotated[
        int,
        typer.Option(
            "--dimension",
            help="Hashing-vector dimension for local failure analysis summary.",
        ),
    ] = DEFAULT_EMBEDDING_DIMENSION,
    threshold: Annotated[
        float,
        typer.Option(
            "--threshold",
            help="Cosine similarity threshold from 0.0 to 1.0.",
        ),
    ] = DEFAULT_SIMILARITY_THRESHOLD,
    include_text: Annotated[
        bool,
        typer.Option(
            "--include-text",
            help="Derive summary signals from raw failure description/root-cause/lesson text.",
        ),
    ] = False,
    confirm: Annotated[
        bool,
        typer.Option(
            "--confirm",
            help="Confirm that raw failure text may be used to derive summary signals.",
        ),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Write failure analysis summary as JSON.",
        ),
    ] = False,
) -> None:
    """Summarize failure analysis status and top pattern candidates."""

    try:
        _require_failure_text_confirmation(include_text=include_text, confirm=confirm)
        payload = failure_analysis_summary_payload(
            Path.cwd(),
            include_text=include_text,
            dimension=dimension,
            similarity_threshold=threshold,
        )
    except PmemError as exc:
        _exit_with_error(exc)

    if json_output:
        console.print_json(data=payload)
        return

    _print_failure_analysis_summary(payload)


@share_app.command("init")
def share_init_command(
    path: Annotated[
        str,
        typer.Argument(help="Local directory to register as an explicit shared memory path."),
    ],
    alias: Annotated[
        str | None,
        typer.Option(
            "--alias",
            help="Unique local alias for the shared memory path.",
        ),
    ] = None,
    mode: Annotated[
        str,
        typer.Option(
            "--mode",
            help="Shared path mode: read, write, or read_write.",
        ),
    ] = "read_write",
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Write the registration result as JSON.",
        ),
    ] = False,
) -> None:
    """Register a local shared memory path without starting sync."""

    try:
        result = register_shared_path(Path.cwd(), path, alias=alias, mode=mode)
    except PmemError as exc:
        _exit_with_error(exc)

    if json_output:
        console.print_json(data=shared_path_registration_json(result))
        return

    console.print("Shared path registered.")
    console.print(f"alias: {result.record.alias}")
    console.print(f"mode: {result.record.mode}")
    console.print(f"status: {result.status.status}")
    console.print(f"path: {result.status.path_display}")
    console.print("Sync: none")


@share_app.command("status")
def share_status_command(
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Write shared path status as JSON.",
        ),
    ] = False,
) -> None:
    """Inspect registered shared memory paths."""

    try:
        statuses = list_shared_path_statuses(Path.cwd())
    except PmemError as exc:
        _exit_with_error(exc)

    if json_output:
        console.print_json(data=shared_path_statuses_json(statuses))
        return

    console.print("Shared paths:")
    if not statuses:
        console.print("- none")
        return
    for status in statuses:
        console.print(f"- {status.alias}: {status.status} ({status.mode}) {status.path_display}")


def _validate_output_format(value: str) -> str:
    """Validate machine-readable output mode flags."""

    cleaned = value.strip().lower()
    if cleaned not in {"text", "json"}:
        raise PmemValidationError("Output format must be text or json.")
    return cleaned


def _require_failure_text_confirmation(*, include_text: bool, confirm: bool) -> None:
    """Require explicit confirmation before exposing raw failure free text."""

    if include_text and not confirm:
        raise PmemValidationError("Failure text export requires --confirm with --include-text.")


def _failure_record_json(record: FailureRecord) -> dict[str, object]:
    """Return the D15 JSON payload for one confirmed failure.

    description, root_cause, and lesson are intentionally omitted: they are
    free-text fields that may contain sensitive data (see SECURITY.md).
    """

    return {
        "id": record.id,
        "run_id": record.run_id,
        "error_type": record.error_type,
        "severity": record.severity,
        "tags": json.loads(record.tags_json),
        "source": record.source,
        "created_at": record.created_at,
    }


def _print_failure_records(payload: dict[str, object]) -> None:
    """Render D35 failure records without raw free text by default."""

    records = payload["records"]
    if not isinstance(records, list):
        records = []
    console.print(f"Failures: {payload['record_count']}")
    console.print(f"privacy_mode: {payload['privacy_mode']}")
    if not records:
        console.print("- none")
        return
    for record in records:
        if not isinstance(record, dict):
            continue
        tags = record.get("tags")
        tags_text = ",".join(str(tag) for tag in tags) if isinstance(tags, list) else ""
        console.print(
            "- "
            f"{record.get('id')}: {record.get('severity')} "
            f"{record.get('source')} {record.get('error_type')} "
            f"run={record.get('run_id')} tags={tags_text}"
        )
        if record.get("text_included") is True:
            console.print(f"  description: {record.get('description')}")
            if record.get("root_cause") is not None:
                console.print(f"  root_cause: {record.get('root_cause')}")
            if record.get("lesson") is not None:
                console.print(f"  lesson: {record.get('lesson')}")


def _print_summary(summary: ProjectSummary) -> None:
    """Render the human-readable D17/D18 project summary."""

    console.print(f"Project: {summary.project_name}")
    console.print(f"Objective: {summary.objective or 'not set'}")
    console.print(f"Primary metric: {summary.primary_metric or 'not set'}")
    console.print(f"Metric direction: {summary.metric_direction or 'not set'}")
    console.print(
        "Target: "
        + (f"{summary.target_value:.6g}" if summary.target_value is not None else "not set")
    )
    console.print(f"Run count: {summary.run_count}")
    console.print(f"Best run: {summary.best_run_id or 'none'}")
    console.print(
        "Best metric value: "
        + (f"{summary.best_metric_value:.6g}" if summary.best_metric_value is not None else "none")
    )
    console.print(f"Target status: {summary.target_status}")
    console.print("Timeline:")
    for item in summary.timeline:
        console.print(f"- {item.name}: {item.status} - {item.detail}")
    console.print("Warnings:")
    if summary.warnings:
        for warning in summary.warnings:
            console.print(f"- {warning}")
    else:
        console.print("- none")


def _print_failure_pattern_report(payload: dict[str, object]) -> None:
    """Render D38 pattern candidates without raw failure text."""

    console.print(f"Failure pattern candidates: {payload['pattern_count']}")
    console.print(f"records: {payload['record_count']}")
    console.print(f"clusters: {payload['cluster_count']}")
    console.print(f"privacy_mode: {payload['privacy_mode']}")
    console.print("heuristic: metadata-first, human review required")
    patterns = payload["patterns"]
    if not isinstance(patterns, list) or not patterns:
        console.print("- none")
        return
    for pattern in patterns:
        if not isinstance(pattern, dict):
            continue
        console.print(
            "- "
            f"{pattern.get('pattern_id')}: {pattern.get('heuristic_label')} "
            f"cluster={pattern.get('cluster_id')} evidence={pattern.get('evidence_count')} "
            f"score={pattern.get('heuristic_score')}"
        )
        console.print(f"  why: {pattern.get('explanation')}")
        console.print(f"  next: {pattern.get('review_recommendation')}")


def _print_failure_analysis_summary(payload: dict[str, object]) -> None:
    """Render D39 failure analysis summary for the CLI."""

    console.print("Failure analysis summary")
    console.print(f"status: {payload['status']}")
    console.print(f"records: {payload['record_count']}")
    console.print(f"clusters: {payload['cluster_count']}")
    console.print(f"pattern_candidates: {payload['pattern_count']}")
    console.print(f"privacy_mode: {payload['privacy_mode']}")
    console.print("Top pattern candidates:")
    patterns = payload["top_patterns"]
    if not isinstance(patterns, list) or not patterns:
        console.print("- none")
    else:
        for pattern in patterns:
            if not isinstance(pattern, dict):
                continue
            console.print(
                "- "
                f"{pattern.get('pattern_id')}: {pattern.get('heuristic_label')} "
                f"evidence={pattern.get('evidence_count')}"
            )
    console.print("Next actions:")
    actions = payload["next_actions"]
    if isinstance(actions, list):
        for action in actions:
            console.print(f"- {action}")


def _print_import_dry_run_report(report: ImportDryRunReport) -> None:
    """Render the human-readable D23 import dry-run report."""

    console.print(f"Import dry-run: {'PASS' if report.ok else 'FAIL'}")
    console.print(f"Bundle: {report.bundle_path}")
    console.print(f"export_format_version: {report.export_format_version or 'unknown'}")
    console.print(f"schema_version: {report.schema_version or 'unknown'}")
    console.print("Database mutation: none")
    console.print("Entities:")
    for entity_type, count in sorted(report.entity_counts.items()):
        console.print(f"- {entity_type}: {count}")

    console.print("PRIVACY REVIEW:")
    if report.privacy_review:
        for item in report.privacy_review:
            console.print(f"- {item.field}: {item.count} - {item.message}")
    else:
        console.print("- no free-text or artifact metadata warnings detected")

    console.print("Conflicts:")
    if report.conflicts:
        for item in report.conflicts:
            console.print(
                f"- {item.conflict_type}: {item.entity_type} {item.entity_id} - {item.message}"
            )
    else:
        console.print("- none")

    if report.warnings:
        console.print("Warnings:")
        for warning in report.warnings:
            console.print(f"- {warning.code}: {warning.message}")

    if report.errors:
        console.print("Errors:")
        for error in report.errors:
            field = f"{error.field}: " if error.field else ""
            console.print(f"- {error.code}: {field}{error.message}")


def _print_conflict_check_report(report: ConflictCheckReport) -> None:
    """Render the human-readable D27 conflict-check report."""

    data = conflict_check_report_json(report)
    console.print(f"Conflict check: {'PASS' if data['validation_ok'] else 'FAIL'}")
    console.print(f"Bundle: {data['bundle_path']}")
    console.print("Database mutation: none")
    console.print(f"Conflicts: {data['conflict_count']}")
    conflicts = data["conflicts"]
    if conflicts:
        for item in conflicts:
            console.print(
                "- "
                f"{item['conflict_type']}: {item['entity_type']} {item['entity_id']} "
                f"({item['severity']})"
            )
    else:
        console.print("- none")
    validation_errors = data["validation_errors"]
    if validation_errors:
        console.print("Validation errors:")
        for error in validation_errors:
            field = f"{error['field']}: " if error["field"] else ""
            console.print(f"- {error['code']}: {field}{error['message']}")


def _exit_with_error(exc: PmemError) -> None:
    """Render expected errors without exposing tracebacks or raw internals."""

    console.print(f"Error: {exc}", style="red", markup=False)
    raise typer.Exit(code=1)
