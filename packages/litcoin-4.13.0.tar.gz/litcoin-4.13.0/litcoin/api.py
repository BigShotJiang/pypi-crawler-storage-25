"""
Low-level HTTP client for the LITCOIN coordinator API.
"""

import time
import logging
import requests as _requests

log = logging.getLogger("litcoin")

COORDINATOR_URL = "https://api.litcoin.app"
SDK_VERSION = "4.13.0"
BACKOFF = [2, 4, 8, 16, 30, 60]


class APIError(Exception):
    """Raised when the coordinator returns an error."""
    def __init__(self, status, message, body=None):
        self.status = status
        self.message = message
        self.body = body
        super().__init__(f"HTTP {status}: {message}")


class CoordinatorAPI:
    """HTTP client wrapping all coordinator endpoints."""

    def __init__(self, base_url=None):
        self.base_url = (base_url or COORDINATOR_URL).rstrip("/")
        self.session = _requests.Session()
        self.session.headers["Content-Type"] = "application/json"
        self.session.headers["X-Litcoin-SDK"] = SDK_VERSION

    def _request(self, method, path, retries=3, **kwargs):
        url = f"{self.base_url}{path}"
        for attempt in range(retries):
            try:
                r = self.session.request(method, url, timeout=30, **kwargs)
                if r.status_code == 429:
                    wait = BACKOFF[min(attempt, len(BACKOFF) - 1)]
                    log.warning(f"Rate limited on {path}, retry in {wait}s")
                    time.sleep(wait)
                    continue
                return r
            except Exception as e:
                if attempt < retries - 1:
                    wait = BACKOFF[min(attempt, len(BACKOFF) - 1)]
                    log.warning(f"Request failed ({e}), retry in {wait}s")
                    time.sleep(wait)
                else:
                    raise APIError(0, f"All {retries} retries exhausted: {e}")
        raise APIError(429, "Rate limited after all retries")

    def _get(self, path, **kwargs):
        return self._request("GET", path, **kwargs)

    def _post(self, path, **kwargs):
        return self._request("POST", path, **kwargs)

    # ─── Auth ─────────────────────────────────────────────────────────────────

    def get_nonce(self, wallet):
        r = self._post("/v1/auth/nonce", json={"miner": wallet})
        if r.status_code != 200:
            raise APIError(r.status_code, "Nonce failed", r.text)
        return r.json()["message"]

    def verify_auth(self, wallet, message, signature):
        r = self._post("/v1/auth/verify", json={
            "miner": wallet, "message": message, "signature": signature
        })
        if r.status_code != 200:
            raise APIError(r.status_code, "Auth verify failed", r.text)
        return r.json()["token"]

    # ─── Mining ───────────────────────────────────────────────────────────────

    def get_challenge(self, nonce, auth_token):
        r = self._get("/v1/challenge", params={"nonce": nonce},
                       headers={"Authorization": f"Bearer {auth_token}"})
        if r.status_code == 401:
            raise APIError(401, "Auth expired")
        if r.status_code == 403:
            raise APIError(403, r.json().get("error", "Forbidden"), r.text)
        if r.status_code != 200:
            raise APIError(r.status_code, "Challenge failed", r.text)
        return r.json()

    def submit_solution(self, challenge_id, artifact, nonce, auth_token):
        r = self._post("/v1/submit", json={
            "challengeId": challenge_id, "artifact": artifact, "nonce": nonce
        }, headers={"Authorization": f"Bearer {auth_token}"})
        if r.status_code == 401:
            raise APIError(401, "Auth expired")
        if r.status_code not in (200, 201):
            raise APIError(r.status_code, "Submit failed", r.text)
        return r.json()

    # ─── Claims ───────────────────────────────────────────────────────────────

    def claims_status(self, wallet):
        r = self._get("/v1/claims/status", params={"wallet": wallet})
        if r.status_code != 200:
            raise APIError(r.status_code, "Claims status failed", r.text)
        return r.json()

    def claims_sign(self, wallet):
        r = self._post("/v1/claims/sign", json={"wallet": wallet})
        if r.status_code != 200:
            raise APIError(r.status_code, "Claims sign failed", r.text)
        return r.json()

    def claims_bankr(self, wallet):
        """Claim via coordinator (for Bankr smart wallets)."""
        r = self._post("/v1/claims/bankr", json={"wallet": wallet})
        if r.status_code != 200:
            raise APIError(r.status_code, "Bankr claim failed", r.text)
        return r.json()

    # ─── Stats ────────────────────────────────────────────────────────────────

    def network_stats(self):
        r = self._get("/v1/claims/stats")
        return r.json()

    def leaderboard(self, limit=20):
        r = self._get("/v1/claims/leaderboard", params={"limit": limit})
        return r.json()

    def health(self):
        r = self._get("/v1/health")
        return r.json()

    # ─── Staking ──────────────────────────────────────────────────────────────

    def get_boost(self, wallet):
        r = self._get("/v1/boost", params={"wallet": wallet})
        if r.status_code != 200:
            raise APIError(r.status_code, "Boost check failed", r.text)
        return r.json()

    def register_staker(self, wallet):
        r = self._post("/v1/staking/register", json={"wallet": wallet})
        return r.json()

    def staking_yield(self, wallet):
        r = self._get("/v1/staking/yield", params={"wallet": wallet})
        return r.json()

    def staking_stats(self):
        r = self._get("/v1/staking/stats")
        return r.json()

    # ─── Compute ──────────────────────────────────────────────────────────────

    def compute_request(self, prompt, model=None, max_tokens=4096, wallet=None):
        payload = {"prompt": prompt, "maxTokens": max_tokens}
        if model:
            payload["model"] = model
        if wallet:
            payload["wallet"] = wallet
        r = self._post("/v1/compute/request", json=payload)
        if r.status_code != 200:
            raise APIError(r.status_code, "Compute request failed", r.text)
        return r.json()

    def compute_health(self):
        r = self._get("/v1/compute/health")
        return r.json()

    def compute_providers(self):
        r = self._get("/v1/compute/providers")
        return r.json()

    def compute_stats(self):
        r = self._get("/v1/compute/stats")
        return r.json()

    # ─── Research ──────────────────────────────────────────────────────────

    def research_list_tasks(self, task_type=None):
        params = {}
        if task_type:
            params["type"] = task_type
        r = self._get("/v1/research/tasks", params=params)
        return r.json()

    def research_get_task(self, task_id):
        r = self._get(f"/v1/research/task/{task_id}")
        if r.status_code != 200:
            raise APIError(r.status_code, "Task not found", r.text)
        return r.json()

    def research_fetch_task(self, task_type=None, miner=None):
        payload = {}
        if task_type:
            payload["type"] = task_type
        if miner:
            payload["miner"] = miner
        r = self._post("/v1/research/task", json=payload)
        if r.status_code != 200:
            raise APIError(r.status_code, r.json().get("error", "No tasks"), r.text)
        return r.json()

    def research_submit(self, task_id, miner, code, model=None, model_provider=None, reasoning=None, auth_token=None, actual_model=None):
        """Submit a research solution.

        actual_model: the model name resolved from the LLM API response (e.g.
            OpenRouter returns the actually-routed underlying model when the
            request used "auto" or a ":free" tag). The coordinator prefers
            this over `model` for benchmark attribution. Optional; older
            coordinators ignore unknown payload fields, so passing it is safe.
        """
        payload = {"taskId": task_id, "miner": miner, "code": code}
        if model:
            payload["model"] = model
        if model_provider:
            payload["modelProvider"] = model_provider
        if reasoning:
            payload["reasoning"] = reasoning
        if actual_model:
            payload["actual_model"] = actual_model

        headers = {}
        if auth_token:
            headers["Authorization"] = f"Bearer {auth_token}"

        r = self._post("/v1/research/submit", json=payload, headers=headers, retries=1)

        if r.status_code == 202:
            # Async mode — poll for result
            data = r.json()
            sub_id = data.get("submissionId")
            if not sub_id:
                raise APIError(202, "Queued but no submissionId returned")

            import time as _time
            poll_start = _time.time()
            while _time.time() - poll_start < 600:  # 10 min max (continuous verification queue)
                _time.sleep(5)
                try:
                    pr = self._get(f"/v1/research/submission-status/{sub_id}")
                    if pr.status_code == 404:
                        raise APIError(404, "Submission expired or not found")
                    pd = pr.json()
                    status = pd.get("status", "unknown")
                    if status in ("pending", "verifying"):
                        continue
                    if status in ("complete", "failed"):
                        return pd
                except APIError:
                    raise
                except Exception:
                    continue
            raise APIError(408, "Timed out waiting for verification result")

        if r.status_code not in (200, 429):
            raise APIError(r.status_code, "Submit failed", r.text)
        return r.json()

    def research_results(self, task_id=None, miner=None, limit=50):
        params = {"limit": limit}
        if task_id:
            params["taskId"] = task_id
        if miner:
            params["miner"] = miner
        r = self._get("/v1/research/results", params=params)
        return r.json()

    def research_leaderboard(self, task_id=None):
        params = {}
        if task_id:
            params["taskId"] = task_id
        r = self._get("/v1/research/leaderboard", params=params)
        return r.json()

    def research_stats(self):
        r = self._get("/v1/research/stats")
        return r.json()

    def research_history(self, miner, task_id=None):
        params = {"miner": miner}
        if task_id:
            params["taskId"] = task_id
        r = self._get("/v1/research/history", params=params)
        return r.json()

    def research_post_bounty(self, title, task_type, description, baseline, constraints, reward_base=None, tags=None, poster=None):
        payload = {
            "title": title, "type": task_type,
            "description": description, "baseline": baseline,
            "constraints": constraints,
        }
        if reward_base:
            payload["reward_base"] = reward_base
        if tags:
            payload["tags"] = tags
        if poster:
            payload["poster"] = poster
        r = self._post("/v1/research/bounty", json=payload)
        if r.status_code != 200:
            raise APIError(r.status_code, "Bounty post failed", r.text)
        return r.json()

    # ─── Miner Status (V3) ───────────────────────────────────────────

    def miner_status(self, wallet):
        """Full miner status: mining, relay, earnings, guild, health."""
        r = self._get("/v1/miner/status", params={"wallet": wallet})
        return r.json()

    # ─── Guild Yield (V3) ────────────────────────────────────────────

    def guild_yield(self):
        """Network-wide guild yield history and member data."""
        r = self._get("/v1/guilds/yield")
        return r.json()

    def guild_member_yield(self, wallet):
        """Individual member yield history."""
        r = self._get(f"/v1/guilds/yield/{wallet}")
        return r.json()

    # ─── Protocol Stats ──────────────────────────────────────────────

    def protocol_stats(self):
        """Cached protocol stats: totalStaked, litcreditSupply, prices."""
        r = self._get("/v1/protocol/stats")
        return r.json()

    # ─── TCG Intelligence (Cards) ─────────────────────────────────────────────

    def tcg_stats(self):
        """TCG catalog statistics: cards indexed, per-game breakdown, price points, sentiment queue."""
        r = self._get("/v1/tcg/stats")
        return r.json()

    def tcg_search(self, game=None, query=None, set_code=None, rarity=None, has_profile=None, sort="name", limit=50, offset=0):
        """Search TCG catalog. game: pokemon, mtg, yugioh, onepiece, greedisland (or None for all).
        has_profile: True (only AI-profiled cards), False (only not yet profiled), None (no filter).
        sort: name, number, rarity, price-desc, price-asc, recent."""
        params = {"limit": min(limit, 100), "offset": offset, "sort": sort}
        if game: params["game"] = game
        if query: params["q"] = query
        if set_code: params["set"] = set_code
        if rarity: params["rarity"] = rarity
        if has_profile is True: params["has_profile"] = "true"
        elif has_profile is False: params["has_profile"] = "false"
        r = self._get("/v1/tcg/cards", params=params)
        return r.json()

    def tcg_card(self, game, set_code, card_number):
        """Full card details + latest price. universal_id is 'game:set:number'."""
        r = self._get(f"/v1/tcg/cards/{game}/{set_code}/{card_number}")
        return r.json()

    def tcg_price_history(self, game, set_code, card_number, days=90):
        """Daily price history for one card (max 365 days)."""
        r = self._get(f"/v1/tcg/cards/{game}/{set_code}/{card_number}/prices", params={"days": min(days, 365)})
        return r.json()

    def tcg_trending(self, game=None, days=7, limit=20):
        """Trending cards by recent price momentum + sentiment volume."""
        params = {"days": min(days, 90), "limit": min(limit, 100)}
        if game: params["game"] = game
        r = self._get("/v1/tcg/trending", params=params)
        return r.json()

    def tcg_prices_live(self):
        """Latest live prices for top-N highest-value cards per game (refreshed every 30 min)."""
        r = self._get("/v1/tcg/prices/live")
        return r.json()

    # ─── Delegation (Liquidity → Production) ──────────────────────────────────

    def delegation_domain(self):
        """Reveal the EIP-712 typed-data domain so a client can sign offline."""
        r = self._get("/v1/delegate/eip712/domain")
        if r.status_code != 200:
            raise APIError(r.status_code, "domain fetch failed", r.text)
        return r.json()

    def delegation_pools(self):
        """All six archetype pool aggregates."""
        r = self._get("/v1/delegate/pools")
        if r.status_code != 200:
            raise APIError(r.status_code, "pools fetch failed", r.text)
        return r.json()

    def delegation_pool(self, pool_id):
        """One pool's aggregate stats + backers."""
        r = self._get(f"/v1/delegate/pool/{int(pool_id)}")
        if r.status_code != 200:
            raise APIError(r.status_code, "pool fetch failed", r.text)
        return r.json()

    def delegation_positions(self, wallet):
        """Active delegations for a wallet."""
        r = self._get(f"/v1/delegate/positions/{wallet}")
        if r.status_code != 200:
            raise APIError(r.status_code, "positions fetch failed", r.text)
        return r.json()

    def delegation_nonce(self, wallet, message_type=0):
        """Next valid nonce for the wallet+message_type (0=Delegation, 1=Undelegation)."""
        r = self._get(f"/v1/delegate/nonce/{wallet}", params={"type": int(message_type)})
        if r.status_code != 200:
            raise APIError(r.status_code, "nonce fetch failed", r.text)
        return r.json()

    def delegation_history(self, wallet, limit=25):
        """Recent delegation actions audit log."""
        r = self._get(f"/v1/delegate/history/{wallet}", params={"limit": min(int(limit), 100)})
        if r.status_code != 200:
            raise APIError(r.status_code, "history fetch failed", r.text)
        return r.json()

    def delegate_via_bankr(self, bankr_key, allocations, expires=None):
        """Coordinator-signed delegation via Bankr key. Allocations: [{poolId, bps}]."""
        body = {"bankrKey": bankr_key, "allocations": allocations}
        if expires is not None:
            body["expires"] = int(expires)
        r = self._post("/v1/bankr/delegate", json=body)
        if r.status_code != 200:
            raise APIError(r.status_code, "delegate failed", r.text)
        return r.json()

    def undelegate_via_bankr(self, bankr_key, pool_ids, expires=None):
        """Start undelegation cooldown via Bankr key."""
        body = {"bankrKey": bankr_key, "poolIds": list(map(int, pool_ids))}
        if expires is not None:
            body["expires"] = int(expires)
        r = self._post("/v1/bankr/undelegate", json=body)
        if r.status_code != 200:
            raise APIError(r.status_code, "undelegate failed", r.text)
        return r.json()

    def commission_status(self, wallet):
        """Claimable commission for a wallet."""
        r = self._get("/v1/delegate/claim/status", params={"wallet": wallet})
        if r.status_code != 200:
            raise APIError(r.status_code, "commission status failed", r.text)
        return r.json()

    def sign_commission_claim(self, wallet):
        """Get a coordinator-signed commission claim ready to submit on-chain."""
        r = self._post("/v1/delegate/claim/sign", json={"wallet": wallet})
        if r.status_code != 200:
            raise APIError(r.status_code, "claim sign failed", r.text)
        return r.json()

    # ─── Bankr safety system (pending list / confirm / revoke) ───────────────

    def list_pending_delegations(self, wallet, include_resolved=False):
        """Pending Bankr delegations for a wallet awaiting the safety window."""
        r = self._get(f"/v1/delegate/pending/{wallet}", params={"includeResolved": "true" if include_resolved else "false"})
        if r.status_code != 200:
            raise APIError(r.status_code, "pending list failed", r.text)
        return r.json()

    def confirm_pending_delegation(self, pending_id, bankr_key=None, wallet_signature=None):
        """Confirm a pending delegation immediately (skips the safety window)."""
        body = {}
        if bankr_key: body["bankrKey"] = bankr_key
        if wallet_signature: body["walletSignature"] = wallet_signature
        r = self._post(f"/v1/delegate/pending/{int(pending_id)}/confirm", json=body)
        if r.status_code != 200:
            raise APIError(r.status_code, "confirm failed", r.text)
        return r.json()

    def revoke_pending_delegation(self, pending_id, bankr_key=None, wallet_signature=None):
        """Revoke a pending delegation before the safety window elapses."""
        body = {}
        if bankr_key: body["bankrKey"] = bankr_key
        if wallet_signature: body["walletSignature"] = wallet_signature
        r = self._post(f"/v1/delegate/pending/{int(pending_id)}/revoke", json=body)
        if r.status_code != 200:
            raise APIError(r.status_code, "revoke failed", r.text)
        return r.json()

    def bind_telegram(self, wallet, chat_id, wallet_signature):
        """
        Bind a Telegram chat for safety notifications. wallet_signature must
        be over the message: 'LITCOIN delegation telegram-bind <wallet> <chat_id>'
        """
        r = self._post("/v1/delegate/telegram/bind", json={
            "wallet": wallet, "chatId": int(chat_id), "walletSignature": wallet_signature,
        })
        if r.status_code != 200:
            raise APIError(r.status_code, "telegram bind failed", r.text)
        return r.json()
