# Contributing to coding-cli-runtime

## Development setup

```bash
cd packages/coding-cli-runtime

# Install dependencies with uv (recommended)
uv sync --group dev

# Or use pip
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

## Quality checks

```bash
# Run all checks (same as CI)
uv run --project . --group dev python -m ruff check src tests
uv run --project . --group dev python -m ruff format --check src tests
uv run --project . --group dev python -m mypy src
uv run --project . --group dev python -m pytest -v

# Pre-commit (if installed)
uv run --project . --group dev pre-commit run --all-files

# Build and validate
uv run --project . --group dev python -m build --no-isolation --sdist --wheel
uv run --project . --group dev python -m twine check dist/*
```

## Pull request process

1. Run all quality checks locally before pushing.
2. Update `CHANGELOG.md` under `[Unreleased]` for any user-visible changes.
3. CI enforces the same checks — PRs must pass before merge.
