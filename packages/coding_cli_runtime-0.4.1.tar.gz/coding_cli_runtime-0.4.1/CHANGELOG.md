# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/).

## [Unreleased]

## [0.4.1] - 2026-04-10

### Added
- `list_provider_ids()` — returns the list of supported provider IDs.

### Changed
- Headless launch helpers (`build_claude_headless_core`,
  `build_codex_headless_core`, `build_copilot_headless_core`,
  `build_gemini_headless_core`) now accept an optional `contract` parameter
  to skip redundant `get_provider_contract()` lookups when the caller already
  has a contract instance. Passing a contract for the wrong provider raises
  `ValueError`.

### Fixed
- Auth resolution no longer couples to the internal contract registry;
  uses `get_provider_contract()` and `list_provider_ids()` instead.

## [0.4.0] - 2026-04-09

### Added
- `OutputContract`, `IoContract`, `SessionDiscoveryContract`,
  `DiagnosticsContract` sub-contracts on `ProviderContract`, with data
  populated for all four providers.
- `WorkspaceEnvVar` structured type with `name` + `value_source` semantics
  (replaces bare env-var name strings in `IoContract.workspace_env_vars`).
- `WorkspaceEnvValueSource` — closed vocabulary (`"execution_dir"` /
  `"workspace_root"`) for `WorkspaceEnvVar.value_source`.
- `resolve_workspace_env()` — turns `IoContract.workspace_env_vars` into a
  concrete env overlay from an execution directory.
- `resolve_session_search_paths()` — expands `SessionDiscoveryContract`
  roots into concrete host paths.
- `is_provider_installed()` — checks whether a provider CLI binary is on
  PATH.
- README sections: "Query provider I/O conventions" and "Common integration
  tasks" with copy-pasteable examples.
- `WorkspaceEnvVar` added to key-types table in README.

### Changed
- Gemini `session_glob` tightened from `"*.json"` to `"*/chats/session-*.json"`
  to match the real `tmp/{hash}/chats/session-*.json` layout.
- Claude `session_glob` tightened from `"*.jsonl"` to
  `"*/conversation.jsonl"` to match per-project subdirectory structure.

## [0.3.0] - 2026-04-09

### Added
- Per-provider headless launch helpers: `build_claude_headless_core()`,
  `build_codex_headless_core()`, `build_copilot_headless_core()`,
  `build_gemini_headless_core()`. These emit the standard non-interactive
  flags for each provider; callers append app-specific tails.
- Session log discovery section in README.
- API summary table in README.

### Changed
- `build_codex_exec_spec()` now delegates to `build_codex_headless_core()`.
  `full_auto` and `skip_git_repo_check` params preserved.
- README rewritten with task-oriented examples, `run_interactive_session`
  usage, `uv add` install, and API summary.

## [0.2.0] - 2026-04-08

### Added
- `ProviderContract` API — structured, nested metadata for all four provider
  CLIs (Claude, Codex, Gemini, Copilot). Composed of `AuthContract`,
  `PathContract`, `HeadlessContract`, `PromptTransport`, `ApprovalContract`,
  `SandboxContract`.
- `get_provider_contract(provider_id)` — returns structured contract for a
  provider.
- `build_env_overlay(contract, api_key, base_url)` — builds provider-specific
  env var overlay from contract metadata.
- `resolve_config_paths(contract, containerized)` — resolves host and container
  config directory paths.
- `render_prompt(transport, prompt)` — resolves prompt delivery into argv args +
  stdin text based on provider transport mode.
- `PromptPayload` dataclass for resolved prompt delivery.
- `resolve_auth()` — resolves provider auth status from environment.
- `__version__` attribute.
- `CONTRIBUTING.md` with development setup and quality checks.

### Changed
- `run_interactive_session()` observability kwargs (`job_name`, `phase_tag`)
  now have sensible defaults so callers don't need to supply them.
- `CliRunResult.command` type widened from `tuple[str, ...]` to `Sequence[str]`.
- Provider model catalogs resolved with three-tier fallback: user override
  file > live CLI discovery > hardcoded fallback.

### Fixed
- Copilot BYOK (`COPILOT_PROVIDER_API_KEY`) now discoverable via contract
  but not reported as "required" in `resolve_auth()` — BYOK is opt-in.

## [0.1.0] - 2026-04-07

### Added
- Provider metadata and controls for Claude, Codex, Copilot, and Gemini CLIs.
- Shared request/result contracts (`CliRunRequest`, `CliRunResult`, `CliLaunchSpec`).
- Schema loading and payload validation (`load_schema`, `validate_payload`).
- Synchronous and asynchronous subprocess execution helpers.
- Interactive session execution with transcript mirroring.
- Session log discovery and parsing utilities.
- Claude reasoning policy resolution.
- Log redaction helpers.
- Copilot reasoning log parsing and classification.
- PEP 561 `py.typed` markers for both `coding_cli_runtime` and `shared_cli_runtime`.
- Packaged JSON schemas and Copilot reasoning baseline data.
- Playground knowledge base with probing guides and experiment templates.
