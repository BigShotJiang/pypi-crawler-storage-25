from __future__ import annotations

import os
from pathlib import Path

import pytest

from coding_cli_runtime.copilot_reasoning_logs import (
    classify_reasoning_fields,
    extract_default_reasoning,
    extract_final_request_options,
    extract_session_id,
    find_process_log_for_session,
)


def test_extract_session_id() -> None:
    markdown = "# Share Export\n\n**Session ID:** `session-123`\n"

    assert extract_session_id(markdown) == "session-123"
    assert extract_session_id("missing") is None


def test_extract_final_request_options_parses_nested_json_block() -> None:
    log_text = """
prefix text
Final request options: {"reasoning_effort":"medium","nested":{"label":"{kept}"}}
suffix text
"""

    assert extract_final_request_options(log_text) == {
        "reasoning_effort": "medium",
        "nested": {"label": "{kept}"},
    }


def test_extract_final_request_options_rejects_non_object_payload() -> None:
    log_text = "Final request options: [1, 2, 3]"

    assert extract_final_request_options(log_text) == {}


@pytest.mark.parametrize(
    ("options", "expected"),
    [
        (
            {"reasoning_effort": "high"},
            ("reasoning_effort", "high", "high", ""),
        ),
        (
            {"thinking_budget": 0},
            ("thinking_budget", "0", "", "0"),
        ),
        ({}, ("none", "", "", "")),
    ],
)
def test_classify_reasoning_fields(
    options: dict[str, object], expected: tuple[str, str, str, str]
) -> None:
    assert classify_reasoning_fields(options) == expected


def test_extract_default_reasoning() -> None:
    log_text = "descriptor defaultReasoningEffort=medium more text"

    assert extract_default_reasoning(log_text) == "medium"
    assert extract_default_reasoning("missing") == ""


def test_find_process_log_for_session_returns_newest_match(tmp_path: Path) -> None:
    logs_dir = tmp_path / "logs"
    logs_dir.mkdir()

    older = logs_dir / "process-old.log"
    newer = logs_dir / "process-new.log"
    ignored = logs_dir / "notes.log"

    older.write_text("session-123 older", encoding="utf-8")
    newer.write_text("session-123 newer", encoding="utf-8")
    ignored.write_text("session-123 ignored", encoding="utf-8")

    os.utime(older, (1_700_000_000, 1_700_000_000))
    os.utime(newer, (1_700_000_100, 1_700_000_100))

    assert find_process_log_for_session("session-123", logs_dir) == newer
    assert find_process_log_for_session("missing", logs_dir) is None
    assert find_process_log_for_session("", logs_dir) is None
