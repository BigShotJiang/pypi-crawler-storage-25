from __future__ import annotations

import os
import re
import shutil
import stat
import subprocess
import sys
from pathlib import Path


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _write_copilot_stub(tmp_path: Path) -> Path:
    stub_path = tmp_path / "copilot_stub.sh"
    stub_path.write_text(
        """#!/usr/bin/env bash
set -euo pipefail

share_path=""
previous=""
for arg in "$@"; do
  if [[ "$previous" == "--share" ]]; then
    share_path="$arg"
    previous=""
    continue
  fi
  previous="$arg"
done

if [[ -n "$share_path" ]]; then
  mkdir -p "$(dirname "$share_path")"
  printf '**Session ID:** `stub-session`\\n' >"$share_path"
fi

printf 'stub-output\\n'
printf 'stub-stderr\\n' >&2
""",
        encoding="utf-8",
    )
    stub_path.chmod(stub_path.stat().st_mode | stat.S_IXUSR)
    return stub_path


def _run_subprocess(
    command: list[str],
    *,
    cwd: Path,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        command,
        cwd=cwd,
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )
    assert completed.returncode == 0, completed.stderr
    return completed


def test_copilot_reasoning_probe_dry_run_uses_package_local_results(tmp_path) -> None:
    repo_root = _repo_root()
    script_path = (
        repo_root
        / "packages"
        / "coding-cli-runtime"
        / "playground"
        / "copilot-cli"
        / "experiments"
        / "reasoning_effort_probe.py"
    )
    results_root = script_path.parent / "results"
    before = set(results_root.glob("reasoning_probe_*")) if results_root.exists() else set()

    completed = _run_subprocess(
        [
            sys.executable,
            str(script_path),
            "--dry-run",
            "--max-models",
            "1",
            "--max-prompts",
            "1",
        ],
        cwd=tmp_path,
    )

    match = re.search(r"^Output dir:\s+(.+)$", completed.stdout, re.MULTILINE)
    assert match, completed.stdout
    output_dir = Path(match.group(1).strip())
    assert output_dir.parent == results_root
    assert output_dir.exists()
    assert (output_dir / "manifest.json").exists()
    assert (output_dir / "raw").is_dir()

    after = set(results_root.glob("reasoning_probe_*")) if results_root.exists() else set()
    created = after - before
    assert output_dir in created or output_dir.exists()
    shutil.rmtree(output_dir)


def test_claude_effort_probe_dry_run_uses_package_local_results(tmp_path) -> None:
    repo_root = _repo_root()
    script_path = (
        repo_root
        / "packages"
        / "coding-cli-runtime"
        / "playground"
        / "claude-code"
        / "experiments"
        / "effort_probe.py"
    )
    results_root = script_path.parent / "results"
    before = set(results_root.glob("effort_probe_*")) if results_root.exists() else set()

    completed = _run_subprocess(
        [
            sys.executable,
            str(script_path),
            "--dry-run",
            "--model",
            "claude-opus-4-6",
            "--effort",
            "low",
            "--method",
            "flag",
        ],
        cwd=tmp_path,
    )

    match = re.search(r"^\[dry-run\] output_dir=(.+)$", completed.stdout, re.MULTILINE)
    assert match, completed.stdout
    output_dir = Path(match.group(1).strip())
    assert output_dir.parent == results_root
    assert output_dir.exists()
    assert (output_dir / "raw").is_dir()

    after = set(results_root.glob("effort_probe_*")) if results_root.exists() else set()
    created = after - before
    assert output_dir in created or output_dir.exists()
    shutil.rmtree(output_dir)


def test_copilot_shell_experiments_use_results_dir_and_relative_scripts(tmp_path) -> None:
    repo_root = _repo_root()
    experiments_dir = (
        repo_root / "packages" / "coding-cli-runtime" / "playground" / "copilot-cli" / "experiments"
    )
    stub_path = _write_copilot_stub(tmp_path)
    caller_cwd = tmp_path / "caller"
    caller_cwd.mkdir()
    base_env = dict(os.environ)
    base_env["COPILOT_BIN"] = str(stub_path)
    base_env["MODEL"] = "stub-model"
    base_env["PYTHON_BIN"] = sys.executable

    cases = [
        (
            "text_access.sh",
            [
                "no_at.stdout.txt",
                "no_at.stderr.txt",
                "no_at.md",
                "with_at.stdout.txt",
                "with_at.stderr.txt",
                "with_at.md",
                "run_info.txt",
                "work/secret_note.txt",
            ],
        ),
        (
            "image_access.sh",
            [
                "no_at.stdout.txt",
                "no_at.stderr.txt",
                "no_at.md",
                "with_at.stdout.txt",
                "with_at.stderr.txt",
                "with_at.md",
                "run_info.txt",
                "work/color_grid.png",
            ],
        ),
        (
            "streaming_check.sh",
            [
                "stream.stdout.txt",
                "stream.stderr.txt",
                "stream.md",
                "run_info.txt",
                "work/prompt.txt",
            ],
        ),
    ]

    for script_name, expected_files in cases:
        run_dir = tmp_path / script_name.replace(".sh", "")
        env = dict(base_env)
        env["RESULTS_DIR"] = str(run_dir)
        completed = _run_subprocess(
            ["bash", str(experiments_dir / script_name)],
            cwd=caller_cwd,
            env=env,
        )
        assert completed.stderr == ""
        for relative_path in expected_files:
            assert (run_dir / relative_path).exists(), relative_path
        stderr_files = sorted(run_dir.glob("*.stderr.txt"))
        assert stderr_files
        for stderr_file in stderr_files:
            assert "stub-stderr" in stderr_file.read_text(encoding="utf-8")


def test_run_all_aggregates_copilot_experiment_outputs(tmp_path) -> None:
    repo_root = _repo_root()
    script_path = (
        repo_root
        / "packages"
        / "coding-cli-runtime"
        / "playground"
        / "copilot-cli"
        / "experiments"
        / "run_all.sh"
    )
    stub_path = _write_copilot_stub(tmp_path)
    output_root = tmp_path / "run_all"
    caller_cwd = tmp_path / "caller"
    caller_cwd.mkdir()
    env = dict(os.environ)
    env["COPILOT_BIN"] = str(stub_path)
    env["MODEL"] = "stub-model"
    env["PYTHON_BIN"] = sys.executable
    env["RESULTS_DIR"] = str(output_root)

    completed = _run_subprocess(["bash", str(script_path)], cwd=caller_cwd, env=env)

    assert f"Results saved under: {output_root}" in completed.stdout
    assert (output_root / "text_access" / "run_info.txt").exists()
    assert (output_root / "image_access" / "run_info.txt").exists()
    assert (output_root / "streaming_check" / "run_info.txt").exists()
