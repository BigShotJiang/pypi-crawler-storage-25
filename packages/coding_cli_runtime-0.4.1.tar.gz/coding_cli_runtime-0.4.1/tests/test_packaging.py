from __future__ import annotations

import re
import subprocess
import sys
import tarfile
import zipfile
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parents[1]


def _read_pyproject_version() -> str:
    pyproject = PACKAGE_ROOT / "pyproject.toml"
    match = re.search(r'^version\s*=\s*"([^"]+)"', pyproject.read_text(), re.MULTILINE)
    assert match, "Could not find version in pyproject.toml"
    return match.group(1)


def test_version_sync() -> None:
    """Ensure __init__.py __version__ matches pyproject.toml version."""
    from coding_cli_runtime import __version__

    pyproject_version = _read_pyproject_version()
    assert __version__ == pyproject_version, (
        f"__init__.py __version__={__version__!r} != pyproject.toml version={pyproject_version!r}"
    )


def test_builds_wheel_and_sdist(tmp_path) -> None:
    package_root = PACKAGE_ROOT
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "build",
            "--no-isolation",
            "--sdist",
            "--wheel",
            "--outdir",
            str(tmp_path),
        ],
        cwd=package_root,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    wheel_paths = sorted(tmp_path.glob("*.whl"))
    sdist_paths = sorted(tmp_path.glob("*.tar.gz"))
    assert wheel_paths
    assert sdist_paths

    wheel_path = wheel_paths[0]
    sdist_path = sdist_paths[0]
    version = _read_pyproject_version()
    assert wheel_path.name.startswith(f"coding_cli_runtime-{version}-")
    assert sdist_path.name == f"coding_cli_runtime-{version}.tar.gz"

    with zipfile.ZipFile(wheel_path) as archive:
        names = set(archive.namelist())
    assert "coding_cli_runtime/__init__.py" in names
    assert "coding_cli_runtime/py.typed" in names
    assert "coding_cli_runtime/copilot_reasoning_baseline.json" in names
    assert "coding_cli_runtime/schemas/normalized_run_result.v1.json" in names
    assert "coding_cli_runtime/schemas/reasoning_metadata.v1.json" in names
    assert any(name.endswith(".dist-info/licenses/LICENSE") for name in names)

    with tarfile.open(sdist_path, "r:gz") as archive:
        names = set(archive.getnames())
    prefix = f"coding_cli_runtime-{version}"
    assert f"{prefix}/LICENSE" in names
    assert f"{prefix}/src/coding_cli_runtime/__init__.py" in names
    assert f"{prefix}/src/coding_cli_runtime/py.typed" in names
    assert f"{prefix}/src/coding_cli_runtime/copilot_reasoning_baseline.json" in names
    assert f"{prefix}/src/coding_cli_runtime/schemas/normalized_run_result.v1.json" in names
    assert f"{prefix}/src/coding_cli_runtime/schemas/reasoning_metadata.v1.json" in names

    import_result = subprocess.run(
        [
            sys.executable,
            "-c",
            (
                "import json, sys;"
                f"sys.path.insert(0, {str(wheel_path)!r});"
                "import coding_cli_runtime;"
                "import coding_cli_runtime.json_io as json_io;"
                "import coding_cli_runtime;"
                "schema = coding_cli_runtime.load_schema('normalized_run_result.v1');"
                "baseline = json_io.load_packaged_json_object('copilot_reasoning_baseline.json');"
                "provider = coding_cli_runtime.get_provider_spec('copilot');"
                "model = provider.model('claude-sonnet-4.5');"
                "print(json.dumps({"
                "'path': coding_cli_runtime.__file__,"
                "'schema_type': schema['type'],"
                "'reasoning_schema': model.metadata['reasoningSchema'],"
                "'baseline_has_models': 'models' in baseline"
                "}))"
            ),
        ],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        check=False,
    )
    assert import_result.returncode == 0, import_result.stderr
    assert "coding_cli_runtime/__init__.py" in import_result.stdout
    assert '"schema_type": "object"' in import_result.stdout
    assert '"baseline_has_models": true' in import_result.stdout
    assert '"reasoning_schema": "thinking_budget"' in import_result.stdout
