from __future__ import annotations

import os
import subprocess
import sys

from coding_cli_runtime import get_copilot_model_catalog, get_provider_spec, load_schema
from coding_cli_runtime.json_io import load_packaged_json_object


def test_packaged_schema_loads() -> None:
    schema = load_schema("normalized_run_result.v1")
    assert schema["type"] == "object"
    assert "properties" in schema


def test_packaged_copilot_baseline_loads() -> None:
    catalog = get_copilot_model_catalog()
    assert "claude-sonnet-4.5" in catalog
    assert "goldeneye" in catalog
    provider = get_provider_spec("copilot")
    model = provider.model("claude-sonnet-4.5")
    assert model is not None
    assert model.metadata["reasoningSchema"] == "thinking_budget"
    goldeneye = provider.model("goldeneye")
    assert goldeneye is not None
    goldeneye_reasoning = goldeneye.control("model_reasoning")
    assert goldeneye_reasoning is not None
    assert goldeneye_reasoning.choice_values() == ("low", "medium", "high")


def test_coding_cli_runtime_submodule_alias_loads_packaged_resources() -> None:
    payload = load_packaged_json_object("copilot_reasoning_baseline.json")
    assert "models" in payload
    assert "claude-sonnet-4.5" in payload["models"]


def test_subprocess_import_uses_packaged_runtime(tmp_path) -> None:
    env = dict(os.environ)
    env.pop("PYTHONPATH", None)
    command = [
        sys.executable,
        "-c",
        (
            "import coding_cli_runtime, json;"
            "print(json.dumps({'path': coding_cli_runtime.__file__,"
            "'models': sorted(coding_cli_runtime.get_copilot_model_catalog())[:2]}))"
        ),
    ]
    result = subprocess.run(
        command,
        cwd=tmp_path,
        capture_output=True,
        text=True,
        check=False,
        env=env,
    )
    assert result.returncode == 0, result.stderr
    assert "coding_cli_runtime" in result.stdout
    assert "models" in result.stdout
