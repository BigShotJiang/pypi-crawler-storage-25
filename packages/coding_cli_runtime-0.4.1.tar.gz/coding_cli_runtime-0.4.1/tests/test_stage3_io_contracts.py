"""Tests for provider I/O contract types."""

from __future__ import annotations

from typing import get_args, get_type_hints

from coding_cli_runtime.provider_contracts import (
    WorkspaceEnvValueSource,
    WorkspaceEnvVar,
    get_provider_contract,
)

ALL_PROVIDERS = ("claude", "codex", "gemini", "copilot")


# ── OutputContract ────────────────────────────────────────────────────


class TestOutputContract:
    def test_claude_has_format_flag(self) -> None:
        c = get_provider_contract("claude")
        assert c.output.format_flag == "--output-format"
        assert "text" in c.output.supported_formats
        assert "json" in c.output.supported_formats
        assert "stream-json" in c.output.supported_formats
        assert c.output.default_format == "text"

    def test_codex_has_output_path_flag(self) -> None:
        c = get_provider_contract("codex")
        assert c.output.output_path_flag == "-o"
        assert c.output.schema_path_flag == "--output-schema"
        assert c.output.format_flag is None

    def test_gemini_has_no_output_flags(self) -> None:
        c = get_provider_contract("gemini")
        assert c.output.format_flag is None
        assert c.output.output_path_flag is None
        assert len(c.output.supported_formats) == 0

    def test_copilot_has_share_flag(self) -> None:
        c = get_provider_contract("copilot")
        assert c.output.output_path_flag == "--share"
        assert c.output.format_flag is None
        assert "markdown" in c.output.supported_formats


# ── IoContract ────────────────────────────────────────────────────────


class TestIoContract:
    def test_workspace_env_value_source_is_closed_vocabulary(self) -> None:
        hints = get_type_hints(WorkspaceEnvVar)
        assert hints["value_source"] == WorkspaceEnvValueSource
        assert get_args(WorkspaceEnvValueSource) == ("execution_dir", "workspace_root")

    def test_gemini_file_reference_prefix(self) -> None:
        c = get_provider_contract("gemini")
        assert c.io.file_reference_prefix == "@"

    def test_other_providers_no_file_reference(self) -> None:
        for pid in ("claude", "codex", "copilot"):
            c = get_provider_contract(pid)
            assert c.io.file_reference_prefix is None

    def test_gemini_workspace_env_var(self) -> None:
        c = get_provider_contract("gemini")
        assert len(c.io.workspace_env_vars) == 1
        wev = c.io.workspace_env_vars[0]
        assert wev.name == "GEMINI_CLI_IDE_WORKSPACE_PATH"
        assert wev.value_source == "execution_dir"

    def test_other_providers_no_workspace_env_vars(self) -> None:
        for pid in ("claude", "codex", "copilot"):
            c = get_provider_contract(pid)
            assert c.io.workspace_env_vars == ()


# ── SessionDiscoveryContract ──────────────────────────────────────────


class TestSessionDiscoveryContract:
    def test_all_providers_have_session_discovery(self) -> None:
        for pid in ALL_PROVIDERS:
            c = get_provider_contract(pid)
            assert c.session_discovery is not None

    def test_codex_session_roots(self) -> None:
        c = get_provider_contract("codex")
        assert "sessions" in c.session_discovery.session_roots
        assert "archived_sessions" in c.session_discovery.session_roots

    def test_claude_session_glob(self) -> None:
        c = get_provider_contract("claude")
        assert c.session_discovery.session_glob == "*/conversation.jsonl"

    def test_copilot_session_discovery(self) -> None:
        c = get_provider_contract("copilot")
        assert "session-state" in c.session_discovery.session_roots
        assert "events.jsonl" in c.session_discovery.session_glob

    def test_gemini_session_discovery(self) -> None:
        c = get_provider_contract("gemini")
        assert "tmp" in c.session_discovery.session_roots
        assert c.session_discovery.session_glob == "*/chats/session-*.json"


# ── DiagnosticsContract ───────────────────────────────────────────────


class TestDiagnosticsContract:
    def test_copilot_has_diagnostics(self) -> None:
        c = get_provider_contract("copilot")
        assert c.diagnostics is not None
        assert "process-*.log" in c.diagnostics.log_glob

    def test_other_providers_no_diagnostics(self) -> None:
        for pid in ("claude", "codex", "gemini"):
            c = get_provider_contract(pid)
            assert c.diagnostics is None
