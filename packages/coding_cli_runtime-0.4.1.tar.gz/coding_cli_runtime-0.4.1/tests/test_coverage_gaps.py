"""Tests for failure_classification, codex_cli, schema_validation, reasoning,
redaction, json_io, provider_controls, and auth modules."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from coding_cli_runtime.auth import resolve_auth
from coding_cli_runtime.codex_cli import CodexExecSpec, build_codex_exec_spec
from coding_cli_runtime.contracts import AuthMode
from coding_cli_runtime.failure_classification import (
    FailureClassification,
    classify_provider_failure,
)
from coding_cli_runtime.json_io import (
    load_json_object,
    load_json_value,
    load_jsonl_rows,
    load_jsonl_rows_text,
    load_optional_json_object,
)
from coding_cli_runtime.provider_controls import build_model_id, resolve_provider_model_controls
from coding_cli_runtime.reasoning import resolve_claude_reasoning_policy
from coding_cli_runtime.redaction import redact_text
from coding_cli_runtime.schema_validation import SchemaValidationError, validate_payload

# ── failure_classification ─────────────────────────────────────────────


class TestFailureClassification:
    def test_claude_rate_limited(self) -> None:
        result = classify_provider_failure(
            provider="claude", stderr_text="Error: rate limit exceeded"
        )
        assert result.category == "rate_limited"
        assert result.provider == "claude"

    def test_claude_auth_failure(self) -> None:
        result = classify_provider_failure(
            provider="claude", stderr_text="invalid api key provided"
        )
        assert result.retryable is False

    def test_claude_overloaded(self) -> None:
        result = classify_provider_failure(
            provider="claude", stderr_text="overloaded_error: server busy"
        )
        assert result.retryable is True
        assert result.category == "network_transient"

    def test_codex_falls_through_to_unknown(self) -> None:
        result = classify_provider_failure(provider="codex", stderr_text="some error")
        assert result.category == "unknown"
        assert result.provider == "codex"

    def test_codex_no_dedicated_classifier(self) -> None:
        # Codex has no dedicated classifier — all inputs fall through to unknown
        result = classify_provider_failure(provider="codex", stderr_text="invalid api key")
        assert result.category == "unknown"
        assert result.retryable is False

    def test_gemini_auth_expired(self) -> None:
        result = classify_provider_failure(
            provider="gemini", stderr_text="authentication timed out waiting for login"
        )
        assert result.category == "auth_expired"
        assert result.retryable is False

    def test_gemini_token_expired(self) -> None:
        result = classify_provider_failure(
            provider="gemini", stderr_text="token expired, please re-authenticate"
        )
        assert result.category == "auth_expired"

    def test_gemini_auth_or_permission(self) -> None:
        result = classify_provider_failure(
            provider="gemini", stderr_text="permission denied for this resource"
        )
        assert result.category == "auth_or_permission"
        assert result.retryable is False

    def test_gemini_rate_limited(self) -> None:
        result = classify_provider_failure(
            provider="gemini", stderr_text="RESOURCE_EXHAUSTED: quota exceeded"
        )
        assert result.category == "rate_limited"

    def test_copilot_auth_missing(self) -> None:
        result = classify_provider_failure(
            provider="copilot",
            stderr_text="no authentication information found, please run gh auth login",
        )
        assert result.category == "auth_missing"
        assert result.retryable is False

    def test_copilot_unknown_fallback(self) -> None:
        result = classify_provider_failure(
            provider="copilot", stderr_text="unauthorized: invalid token"
        )
        assert result.category == "unknown"

    def test_unknown_provider(self) -> None:
        result = classify_provider_failure(provider="unknown", stderr_text="some error")
        assert isinstance(result, FailureClassification)
        assert result.provider == "unknown"

    def test_empty_stderr(self) -> None:
        result = classify_provider_failure(provider="claude", stderr_text="")
        assert isinstance(result, FailureClassification)

    def test_case_insensitive_provider(self) -> None:
        result = classify_provider_failure(provider="CLAUDE", stderr_text="rate limit exceeded")
        assert result.category == "rate_limited"
        assert result.provider == "claude"

    def test_gemini_transient_network(self) -> None:
        result = classify_provider_failure(
            provider="gemini",
            stderr_text="UNAVAILABLE: network error during StreamGenerateContent",
        )
        assert result.retryable is True

    def test_copilot_session_store_locked(self) -> None:
        result = classify_provider_failure(
            provider="copilot",
            stderr_text="session store: database is locked",
        )
        assert result.retryable is True


# ── codex_cli ──────────────────────────────────────────────────────────


class TestCodexCli:
    def _build(self, **overrides: Any) -> CodexExecSpec:
        defaults: dict[str, Any] = {
            "codex_bin": "codex",
            "model": "gpt-5.4",
            "cwd": Path("/tmp/project"),
            "output_schema_path": Path("/tmp/schema.json"),
            "output_path": Path("/tmp/out.json"),
            "model_reasoning": "medium",
            "json_output": True,
            "sandbox": "danger-full-access",
        }
        defaults.update(overrides)
        return build_codex_exec_spec(**defaults)

    def test_basic_command_shape(self) -> None:
        spec = self._build()
        assert spec.cmd_parts[0] == "codex"
        assert "exec" in spec.cmd_parts
        assert "--json" in spec.cmd_parts
        assert "--full-auto" in spec.cmd_parts
        assert "--skip-git-repo-check" in spec.cmd_parts
        assert "--model" in spec.cmd_parts
        assert "gpt-5.4" in spec.cmd_parts

    def test_no_json_output(self) -> None:
        spec = self._build(json_output=False)
        assert "--json" not in spec.cmd_parts

    def test_full_auto_always_included(self) -> None:
        spec = self._build()
        assert "--full-auto" in spec.cmd_parts

    def test_skip_git_repo_check_always_included(self) -> None:
        spec = self._build()
        assert "--skip-git-repo-check" in spec.cmd_parts

    def test_full_auto_false_omits_flag(self) -> None:
        spec = self._build(full_auto=False)
        assert "--full-auto" not in spec.cmd_parts

    def test_skip_git_repo_check_false_omits_flag(self) -> None:
        spec = self._build(skip_git_repo_check=False)
        assert "--skip-git-repo-check" not in spec.cmd_parts

    def test_sandbox_value(self) -> None:
        spec = self._build(sandbox="read-only")
        idx = list(spec.cmd_parts).index("--sandbox")
        assert spec.cmd_parts[idx + 1] == "read-only"

    def test_extra_args(self) -> None:
        spec = self._build(extra_args=("--verbose",))
        assert "--verbose" in spec.cmd_parts

    def test_display_text_includes_placeholder(self) -> None:
        spec = self._build(stdin_placeholder="<prompt>")
        assert "<prompt>" in spec.display_text

    def test_display_text_no_placeholder(self) -> None:
        spec = self._build(stdin_placeholder=None)
        assert "<prompt>" not in spec.display_text

    def test_effective_reasoning(self) -> None:
        spec = self._build(model_reasoning="high")
        assert spec.effective_reasoning == "high"

    def test_missing_reasoning_raises(self) -> None:
        with pytest.raises(ValueError, match="reasoning effort"):
            self._build(model_reasoning=None, model_controls=None)


# ── schema_validation ─────────────────────────────────────────────────


class TestSchemaValidation:
    def test_valid_payload(self) -> None:
        payload = {
            "provider": "claude",
            "model": "claude-sonnet-4-6",
            "run_id": "test_01",
            "status": "completed",
            "error_code": "none",
            "duration_seconds": 12.5,
        }
        validate_payload(payload, "normalized_run_result.v1")

    def test_missing_required_field(self) -> None:
        payload = {
            "provider": "claude",
            "model": "claude-sonnet-4-6",
            "status": "completed",
            "error_code": "none",
            "duration_seconds": 1.0,
        }
        with pytest.raises(SchemaValidationError, match="run_id"):
            validate_payload(payload, "normalized_run_result.v1")

    def test_non_dict_payload(self) -> None:
        with pytest.raises(SchemaValidationError, match="object"):
            validate_payload(["not", "a", "dict"], "normalized_run_result.v1")

    def test_wrong_type(self) -> None:
        payload = {
            "provider": "claude",
            "model": "claude-sonnet-4-6",
            "run_id": "test_01",
            "status": "completed",
            "error_code": "none",
            "duration_seconds": "not_a_number",
        }
        with pytest.raises(SchemaValidationError):
            validate_payload(payload, "normalized_run_result.v1")

    def test_nested_required_field_missing(self) -> None:
        payload = {
            "provider": "claude",
            "model": "claude-sonnet-4-6",
            "run_id": "test_01",
            "status": "completed",
            "error_code": "none",
            "duration_seconds": 12.5,
            "reasoning": {
                "mode": "effort",
                # missing "effort" — should be caught by nested required
            },
        }
        with pytest.raises(SchemaValidationError, match="reasoning"):
            validate_payload(payload, "normalized_run_result.v1")

    def test_nested_wrong_type(self) -> None:
        payload = {
            "provider": "claude",
            "model": "claude-sonnet-4-6",
            "run_id": "test_01",
            "status": "completed",
            "error_code": "none",
            "duration_seconds": 12.5,
            "reasoning": {
                "mode": 12345,  # should be string
                "effort": "high",
                "thinking_budget_tokens": None,
            },
        }
        with pytest.raises(SchemaValidationError, match="reasoning.mode"):
            validate_payload(payload, "normalized_run_result.v1")


# ── reasoning ─────────────────────────────────────────────────────────


class TestReasoning:
    def test_adaptive_model_with_effort(self) -> None:
        policy = resolve_claude_reasoning_policy(
            model="claude-sonnet-4-6", thinking_tokens=None, effort="high"
        )
        assert policy.mode == "effort"
        assert policy.effective_effort == "high"

    def test_adaptive_model_no_effort_no_tokens(self) -> None:
        policy = resolve_claude_reasoning_policy(
            model="claude-sonnet-4-6", thinking_tokens=None, effort=None
        )
        assert policy.mode == "none"

    def test_non_adaptive_model_with_tokens(self) -> None:
        policy = resolve_claude_reasoning_policy(
            model="claude-haiku-4-5-20251001", thinking_tokens=4096, effort=None
        )
        assert policy.thinking_tokens == 4096

    def test_non_adaptive_model_zero_tokens(self) -> None:
        policy = resolve_claude_reasoning_policy(
            model="claude-haiku-4-5-20251001", thinking_tokens=0, effort=None
        )
        assert policy.mode == "disabled"
        assert policy.thinking_tokens == 0
        assert policy.disable_via_env_setting is False

    def test_effort_normalization(self) -> None:
        policy = resolve_claude_reasoning_policy(
            model="claude-sonnet-4-6", thinking_tokens=None, effort="LOW"
        )
        assert policy.effective_effort == "low"

    def test_effort_overrides_tokens_on_adaptive(self) -> None:
        policy = resolve_claude_reasoning_policy(
            model="claude-opus-4-6", thinking_tokens=8192, effort="medium"
        )
        assert policy.mode == "effort"
        assert policy.effective_effort == "medium"

    def test_none_model(self) -> None:
        policy = resolve_claude_reasoning_policy(model=None, thinking_tokens=None, effort=None)
        assert policy.mode == "none"
        assert policy.effective_effort is None

    def test_non_adaptive_with_positive_tokens(self) -> None:
        policy = resolve_claude_reasoning_policy(
            model="claude-haiku-4-5-20251001", thinking_tokens=4096, effort=None
        )
        assert policy.mode == "legacy_tokens"
        assert policy.thinking_tokens == 4096

    def test_adaptive_zero_tokens_disables(self) -> None:
        policy = resolve_claude_reasoning_policy(
            model="claude-sonnet-4-6", thinking_tokens=0, effort=None
        )
        assert policy.mode == "disabled"
        assert policy.disable_via_env_setting is True


# ── redaction ─────────────────────────────────────────────────────────


class TestRedaction:
    def test_redacts_api_key(self) -> None:
        result = redact_text("api_key=secret123")
        assert "secret123" not in result
        assert "api_key" in result

    def test_redacts_authorization_header(self) -> None:
        result = redact_text("Authorization: Bearer mytoken")
        assert "mytoken" not in result

    def test_redacts_token(self) -> None:
        result = redact_text("token=xyz123")
        assert "xyz123" not in result

    def test_no_sensitive_data_unchanged(self) -> None:
        text = "this is normal text with no secrets"
        assert redact_text(text) == text

    def test_multiple_patterns(self) -> None:
        text = "api_key=secret1 and token=secret2"
        result = redact_text(text)
        assert "secret1" not in result
        assert "secret2" not in result

    def test_empty_text(self) -> None:
        assert redact_text("") == ""


# ── json_io ───────────────────────────────────────────────────────────


class TestJsonIo:
    def test_load_json_value(self, tmp_path: Path) -> None:
        p = tmp_path / "test.json"
        p.write_text('{"key": "value"}')
        result = load_json_value(p)
        assert result == {"key": "value"}

    def test_load_json_value_non_object(self, tmp_path: Path) -> None:
        p = tmp_path / "test.json"
        p.write_text("[1, 2, 3]")
        result = load_json_value(p)
        assert result == [1, 2, 3]

    def test_load_json_object(self, tmp_path: Path) -> None:
        p = tmp_path / "test.json"
        p.write_text('{"key": "value"}')
        result = load_json_object(p)
        assert result == {"key": "value"}

    def test_load_json_object_not_dict_raises(self, tmp_path: Path) -> None:
        p = tmp_path / "test.json"
        p.write_text("[1, 2, 3]")
        with pytest.raises(ValueError, match="object"):
            load_json_object(p)

    def test_load_optional_json_object_missing(self, tmp_path: Path) -> None:
        result = load_optional_json_object(tmp_path / "missing.json")
        assert result is None

    def test_load_optional_json_object_valid(self, tmp_path: Path) -> None:
        p = tmp_path / "test.json"
        p.write_text('{"key": "value"}')
        result = load_optional_json_object(p)
        assert result == {"key": "value"}

    def test_load_optional_json_object_invalid(self, tmp_path: Path) -> None:
        p = tmp_path / "test.json"
        p.write_text("not json")
        result = load_optional_json_object(p)
        assert result is None

    def test_load_jsonl_rows_text_valid(self) -> None:
        text = '{"a": 1}\n{"b": 2}\n'
        rows = load_jsonl_rows_text(text)
        assert len(rows) == 2
        assert rows[0] == {"a": 1}

    def test_load_jsonl_rows_text_empty(self) -> None:
        assert load_jsonl_rows_text("") == []

    def test_load_jsonl_rows_text_blank_lines(self) -> None:
        text = '{"a": 1}\n\n   \n{"b": 2}\n'
        rows = load_jsonl_rows_text(text)
        assert len(rows) == 2

    def test_load_jsonl_rows_text_invalid_raises(self) -> None:
        text = '{"a": 1}\nnot json\n'
        with pytest.raises(ValueError):
            load_jsonl_rows_text(text, skip_invalid=False)

    def test_load_jsonl_rows_text_skip_invalid(self) -> None:
        text = '{"a": 1}\nnot json\n{"b": 2}\n'
        rows = load_jsonl_rows_text(text, skip_invalid=True)
        assert len(rows) == 2

    def test_load_jsonl_rows_missing_file(self, tmp_path: Path) -> None:
        result = load_jsonl_rows(tmp_path / "missing.jsonl")
        assert result == []

    def test_load_jsonl_rows_valid(self, tmp_path: Path) -> None:
        p = tmp_path / "test.jsonl"
        p.write_text('{"x": 1}\n{"y": 2}\n')
        rows = load_jsonl_rows(p)
        assert len(rows) == 2


# ── provider_controls ─────────────────────────────────────────────────


class TestProviderControls:
    def test_codex_reasoning_effort(self) -> None:
        result = resolve_provider_model_controls(provider="codex", model_reasoning="high")
        applied = result.get("applied", {})
        assert applied.get("reasoning_effort") == "high"

    def test_gemini_no_controls(self) -> None:
        result = resolve_provider_model_controls(provider="gemini")
        applied = result.get("applied", {})
        assert applied == {} or "reasoning_effort" not in applied

    def test_unknown_provider(self) -> None:
        result = resolve_provider_model_controls(provider="unknown")
        assert isinstance(result, dict)
        assert result.get("provider") == "unknown"

    def test_build_model_id_no_controls(self) -> None:
        assert build_model_id("gpt-5.4") == "gpt-5.4"

    def test_build_model_id_with_reasoning(self) -> None:
        result = build_model_id("gpt-5.4", applied_controls={"reasoning_effort": "high"})
        assert "high" in result
        assert "gpt-5.4" in result

    def test_build_model_id_empty_controls(self) -> None:
        assert build_model_id("claude-sonnet-4-6", applied_controls={}) == "claude-sonnet-4-6"


# ── auth ──────────────────────────────────────────────────────────────


class TestAuth:
    def test_claude_env_present(self) -> None:
        result = resolve_auth("claude", {"CLAUDE_API_KEY": "sk-test"})
        assert result.mode == AuthMode.ENV
        assert result.present_env == ("CLAUDE_API_KEY",)
        assert result.missing_env == ()

    def test_claude_env_missing(self) -> None:
        result = resolve_auth("claude", {})
        assert result.mode == AuthMode.CLI_LOGIN
        assert result.missing_env == ("CLAUDE_API_KEY",)

    def test_codex_env_present(self) -> None:
        result = resolve_auth("codex", {"OPENAI_API_KEY": "sk-test"})
        assert result.mode == AuthMode.ENV

    def test_gemini_env_present(self) -> None:
        result = resolve_auth("gemini", {"GEMINI_API_KEY": "key"})
        assert result.mode == AuthMode.ENV

    def test_copilot_cli_login(self) -> None:
        result = resolve_auth("copilot", {})
        assert result.mode == AuthMode.CLI_LOGIN
        assert result.required_env == ()
        assert "BYOK" in result.hint

    def test_unknown_provider(self) -> None:
        result = resolve_auth("unknown_provider", {})
        assert result.mode == AuthMode.CLI_LOGIN

    def test_case_insensitive(self) -> None:
        result = resolve_auth("CLAUDE", {"CLAUDE_API_KEY": "sk-test"})
        assert result.mode == AuthMode.ENV
        assert result.provider == "claude"

    def test_whitespace_stripped(self) -> None:
        result = resolve_auth("  claude  ", {"CLAUDE_API_KEY": "sk-test"})
        assert result.provider == "claude"
        assert result.mode == AuthMode.ENV


# ── provider_controls (deeper coverage) ───────────────────────────────


class TestProviderControlsDeep:
    def test_normalize_reasoning_effort_whitespace(self) -> None:
        result = resolve_provider_model_controls(provider="codex", model_reasoning="  high  ")
        assert result["applied"]["reasoning_effort"] == "high"

    def test_normalize_reasoning_effort_empty(self) -> None:
        result = resolve_provider_model_controls(provider="codex", model_reasoning="   ")
        assert "reasoning_effort" not in result["applied"]

    def test_normalize_thinking_tokens_string(self) -> None:
        result = resolve_provider_model_controls(
            provider="claude", thinking_tokens=None, model_controls={"thinking_tokens": "4096"}
        )
        assert result["requested"]["thinking_tokens"] == 4096

    def test_normalize_thinking_tokens_bool_ignored(self) -> None:
        result = resolve_provider_model_controls(
            provider="claude", model_controls={"thinking_tokens": True}
        )
        assert "thinking_tokens" not in result["requested"]

    def test_normalize_thinking_tokens_negative_clamps(self) -> None:
        result = resolve_provider_model_controls(
            provider="claude", model_controls={"thinking_tokens": -10}
        )
        assert result["requested"]["thinking_tokens"] == 0

    def test_normalize_thinking_tokens_string_invalid(self) -> None:
        result = resolve_provider_model_controls(
            provider="claude", model_controls={"thinking_tokens": "not_a_number"}
        )
        assert "thinking_tokens" not in result["requested"]

    def test_normalize_claude_effort_valid(self) -> None:
        result = resolve_provider_model_controls(provider="claude", effort="Medium")
        assert result["applied"]["effort"] == "medium"

    def test_normalize_claude_effort_invalid(self) -> None:
        result = resolve_provider_model_controls(provider="claude", effort="super-high")
        assert "effort" not in result["applied"]

    def test_normalize_claude_effort_non_string(self) -> None:
        result = resolve_provider_model_controls(provider="claude", model_controls={"effort": 42})
        assert "effort" not in result["requested"]

    def test_model_controls_dict_overrides_individual(self) -> None:
        result = resolve_provider_model_controls(
            provider="codex",
            model_reasoning="low",
            model_controls={"reasoning_effort": "high"},
        )
        assert result["applied"]["reasoning_effort"] == "high"

    def test_ignored_keys_reported(self) -> None:
        result = resolve_provider_model_controls(provider="gemini", model_reasoning="high")
        assert "reasoning_effort" in result["ignored_keys"]
        assert result["applied"] == {}

    def test_copilot_reasoning_effort(self) -> None:
        result = resolve_provider_model_controls(provider="copilot", model_reasoning="medium")
        assert result["applied"]["reasoning_effort"] == "medium"

    def test_build_model_id_multiple_controls(self) -> None:
        result = build_model_id(
            "claude-sonnet-4-6",
            applied_controls={"effort": "medium", "thinking_tokens": 8192},
        )
        assert "claude-sonnet-4-6:" in result
        assert "effort=medium" in result
        assert "thinking_tokens=8192" in result

    def test_non_string_keys_ignored(self) -> None:
        result = resolve_provider_model_controls(
            provider="codex",
            model_controls={42: "value"},  # type: ignore[dict-item]
        )
        assert result["applied"] == {}


# ── schema_validation (deeper coverage) ───────────────────────────────


class TestSchemaValidationDeep:
    def test_load_schema(self) -> None:
        from coding_cli_runtime.schema_validation import load_schema

        schema = load_schema("normalized_run_result.v1")
        assert "properties" in schema
        assert "required" in schema

    def test_load_schema_not_found(self) -> None:
        from coding_cli_runtime.schema_validation import load_schema

        with pytest.raises(FileNotFoundError, match="schema not found"):
            load_schema("nonexistent_schema")

    def test_load_schema_with_json_suffix(self) -> None:
        from coding_cli_runtime.schema_validation import load_schema

        schema = load_schema("normalized_run_result.v1.json")
        assert "properties" in schema

    def test_type_check_boolean_not_integer(self) -> None:
        payload = {
            "provider": "claude",
            "model": "claude-sonnet-4-6",
            "run_id": "test",
            "status": "completed",
            "error_code": "none",
            "duration_seconds": True,  # bool should not match number
        }
        with pytest.raises(SchemaValidationError, match="duration_seconds"):
            validate_payload(payload, "normalized_run_result.v1")

    def test_null_type_accepted(self) -> None:
        payload = {
            "provider": "claude",
            "model": "claude-sonnet-4-6",
            "run_id": "test",
            "status": "completed",
            "error_code": "none",
            "duration_seconds": 1.0,
            "reasoning": {
                "mode": "effort",
                "effort": "high",
                "thinking_budget_tokens": None,
            },
        }
        validate_payload(payload, "normalized_run_result.v1")

    def test_no_properties_in_schema_passes(self) -> None:
        from coding_cli_runtime.schema_validation import validate_payload as vp

        with pytest.MonkeyPatch.context() as mp:
            mp.setattr(
                "coding_cli_runtime.schema_validation.load_schema",
                lambda _: {"required": []},
            )
            vp({"any": "thing"}, "fake")


# ── copilot_reasoning_logs ────────────────────────────────────────────


class TestCopilotReasoningLogs:
    def test_extract_session_id(self) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import extract_session_id

        text = "some text **Session ID:** `abc-123-def` more text"
        assert extract_session_id(text) == "abc-123-def"

    def test_extract_session_id_not_found(self) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import extract_session_id

        assert extract_session_id("no session here") is None

    def test_extract_final_request_options(self) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import extract_final_request_options

        log = 'stuff\nFinal request options: {"reasoning_effort": "high", "model": "gpt-5.4"}\nmore'
        opts = extract_final_request_options(log)
        assert opts["reasoning_effort"] == "high"

    def test_extract_final_request_options_no_marker(self) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import extract_final_request_options

        assert extract_final_request_options("no marker here") == {}

    def test_extract_final_request_options_no_json(self) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import extract_final_request_options

        assert extract_final_request_options("Final request options: broken") == {}

    def test_extract_final_request_options_non_dict(self) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import extract_final_request_options

        assert extract_final_request_options("Final request options: [1,2,3]") == {}

    def test_classify_reasoning_fields_effort(self) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import classify_reasoning_fields

        schema, value, effort, budget = classify_reasoning_fields({"reasoning_effort": "high"})
        assert schema == "reasoning_effort"
        assert value == "high"
        assert effort == "high"

    def test_classify_reasoning_fields_budget(self) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import classify_reasoning_fields

        schema, value, effort, budget = classify_reasoning_fields({"thinking_budget": 4096})
        assert schema == "thinking_budget"
        assert budget == "4096"
        assert effort == ""

    def test_classify_reasoning_fields_none(self) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import classify_reasoning_fields

        schema, value, effort, budget = classify_reasoning_fields({})
        assert schema == "none"

    def test_extract_default_reasoning(self) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import extract_default_reasoning

        assert extract_default_reasoning("defaultReasoningEffort=medium") == "medium"
        assert extract_default_reasoning("no match") == ""

    def test_find_process_log_empty_session_id(self, tmp_path: Path) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import find_process_log_for_session

        assert find_process_log_for_session("", tmp_path) is None

    def test_find_process_log_missing_dir(self, tmp_path: Path) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import find_process_log_for_session

        assert find_process_log_for_session("abc", tmp_path / "nonexistent") is None

    def test_find_process_log_match(self, tmp_path: Path) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import find_process_log_for_session

        log = tmp_path / "process-1.log"
        log.write_text("session abc-123 started")
        result = find_process_log_for_session("abc-123", tmp_path)
        assert result == log

    def test_find_process_log_no_match(self, tmp_path: Path) -> None:
        from coding_cli_runtime.copilot_reasoning_logs import find_process_log_for_session

        log = tmp_path / "process-1.log"
        log.write_text("session xyz started")
        result = find_process_log_for_session("abc-123", tmp_path)
        assert result is None


# ── provider_specs (serialization + helpers) ──────────────────────────


class TestProviderSpecs:
    def test_choice_spec_to_dict(self) -> None:
        from coding_cli_runtime.provider_specs import ChoiceSpec

        cs = ChoiceSpec(value="low", label="Low effort", description="desc", metadata={"k": "v"})
        d = cs.to_dict()
        assert d["value"] == "low"
        assert d["label"] == "Low effort"
        assert d["description"] == "desc"
        assert d["metadata"] == {"k": "v"}

    def test_choice_spec_minimal_to_dict(self) -> None:
        from coding_cli_runtime.provider_specs import ChoiceSpec

        cs = ChoiceSpec(value="x")
        d = cs.to_dict()
        assert d == {"value": "x"}
        assert "label" not in d

    def test_control_spec_to_dict(self) -> None:
        from coding_cli_runtime.provider_specs import ChoiceSpec, ControlSpec

        cs = ControlSpec(
            name="effort",
            kind="choice",
            label="Effort",
            description="desc",
            choices=(ChoiceSpec(value="low"),),
            default="low",
            required=True,
            editable=False,
            advanced=True,
            metadata={"k": "v"},
        )
        d = cs.to_dict()
        assert d["name"] == "effort"
        assert d["required"] is True
        assert d["editable"] is False
        assert d["advanced"] is True
        assert len(d["choices"]) == 1
        assert d["default"] == "low"

    def test_control_spec_choice_values(self) -> None:
        from coding_cli_runtime.provider_specs import ChoiceSpec, ControlSpec

        cs = ControlSpec(
            name="x",
            kind="choice",
            label="X",
            choices=(ChoiceSpec(value="a"), ChoiceSpec(value="b")),
        )
        assert cs.choice_values() == ("a", "b")

    def test_model_spec_to_dict(self) -> None:
        from coding_cli_runtime.provider_specs import ModelSpec

        ms = ModelSpec(name="gpt-5.4", description="desc", metadata={"k": "v"})
        d = ms.to_dict()
        assert d["name"] == "gpt-5.4"
        assert d["description"] == "desc"

    def test_model_spec_control_lookup(self) -> None:
        from coding_cli_runtime.provider_specs import ControlSpec, ModelSpec

        ctrl = ControlSpec(name="effort", kind="choice", label="E")
        ms = ModelSpec(name="m", controls=(ctrl,))
        assert ms.control("effort") is ctrl
        assert ms.control("nonexistent") is None

    def test_provider_spec_to_dict(self) -> None:
        from coding_cli_runtime.provider_specs import ProviderSpec

        ps = ProviderSpec(
            provider_id="test",
            label="Test",
            model_source="code",
            default_model="m1",
            default_concurrency=5,
            models=(),
            notes=("note1",),
            metadata={"k": "v"},
        )
        d = ps.to_dict()
        assert d["providerId"] == "test"
        assert d["defaultModel"] == "m1"
        assert d["notes"] == ["note1"]
        assert d["metadata"] == {"k": "v"}

    def test_provider_spec_model_lookup(self) -> None:
        from coding_cli_runtime.provider_specs import ModelSpec, ProviderSpec

        m = ModelSpec(name="gpt-5.4")
        ps = ProviderSpec(
            provider_id="test",
            label="Test",
            model_source="code",
            default_model="gpt-5.4",
            default_concurrency=5,
            models=(m,),
        )
        assert ps.model("gpt-5.4") is m
        assert ps.model("nonexistent") is None
        assert ps.model_names == ("gpt-5.4",)

    def test_provider_spec_control_lookup(self) -> None:
        from coding_cli_runtime.provider_specs import ControlSpec, ProviderSpec

        ctrl = ControlSpec(name="x", kind="choice", label="X")
        ps = ProviderSpec(
            provider_id="test",
            label="Test",
            model_source="code",
            default_model=None,
            default_concurrency=1,
            models=(),
            controls=(ctrl,),
        )
        assert ps.control("x") is ctrl
        assert ps.control("nonexistent") is None

    def test_get_provider_spec_all_providers(self) -> None:
        from coding_cli_runtime.provider_specs import get_provider_spec

        for pid in ("claude", "codex", "gemini", "copilot"):
            spec = get_provider_spec(pid)
            assert spec.provider_id == pid
            assert len(spec.models) > 0

    def test_serialize_provider_specs(self) -> None:
        from coding_cli_runtime.provider_specs import serialize_provider_specs

        data = serialize_provider_specs()
        assert isinstance(data, list)
        assert len(data) == 4
        ids = {d["providerId"] for d in data}
        assert ids == {"claude", "codex", "gemini", "copilot"}

    def test_list_provider_specs(self) -> None:
        from coding_cli_runtime.provider_specs import list_provider_specs

        specs = list_provider_specs()
        assert len(specs) == 4
