"""Reasoning control policy helpers shared across Claude callers."""

from __future__ import annotations

from .contracts import ClaudeReasoningPolicy

CLAUDE_ADAPTIVE_THINKING_MODELS: tuple[str, ...] = ("claude-sonnet-4-6", "claude-opus-4-6")
CLAUDE_EFFORT_CHOICES: tuple[str, ...] = ("low", "medium", "high")
CLAUDE_DEFAULT_THINKING_TOKENS = 8192


def _normalize_claude_effort(value: str | None) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip().lower()
    if normalized in CLAUDE_EFFORT_CHOICES:
        return normalized
    return None


def _uses_claude_adaptive_thinking_model(model: str | None) -> bool:
    normalized = (model or "").strip().lower()
    if not normalized:
        return False
    return any(normalized.startswith(prefix) for prefix in CLAUDE_ADAPTIVE_THINKING_MODELS)


def resolve_claude_reasoning_policy(
    *,
    model: str | None,
    thinking_tokens: int | None,
    effort: str | None,
) -> ClaudeReasoningPolicy:
    normalized_tokens: int | None = None
    if isinstance(thinking_tokens, int):
        normalized_tokens = max(int(thinking_tokens), 0)
    normalized_effort = _normalize_claude_effort(effort)
    adaptive_model = _uses_claude_adaptive_thinking_model(model)

    if adaptive_model:
        if normalized_effort:
            # --effort explicitly set: use it, ignore thinking tokens.
            return ClaudeReasoningPolicy(
                mode="effort",
                effective_effort=normalized_effort,
                effort_source="flag",
                thinking_tokens=None,
            )
        if normalized_tokens is None:
            # Neither --effort nor --thinking-tokens: let Claude Code
            # handle its own defaults.
            return ClaudeReasoningPolicy(
                mode="none",
                effective_effort=None,
                effort_source=None,
                thinking_tokens=None,
            )
        if normalized_tokens <= 0:
            return ClaudeReasoningPolicy(
                mode="disabled",
                effective_effort=None,
                effort_source="thinking_tokens<=0",
                thinking_tokens=0,
                disable_via_env_setting=True,
            )
        # --thinking-tokens passed without --effort: respect the explicit
        # token budget and pass it through to the CLI as-is.
        return ClaudeReasoningPolicy(
            mode="legacy_tokens",
            effective_effort=None,
            effort_source=None,
            thinking_tokens=normalized_tokens,
        )

    if normalized_tokens is None:
        return ClaudeReasoningPolicy(
            mode="none",
            effective_effort=None,
            effort_source=None,
            thinking_tokens=None,
        )
    if normalized_tokens > 0:
        return ClaudeReasoningPolicy(
            mode="legacy_tokens",
            effective_effort=None,
            effort_source=None,
            thinking_tokens=normalized_tokens,
        )
    return ClaudeReasoningPolicy(
        mode="disabled",
        effective_effort=None,
        effort_source="thinking_tokens<=0",
        thinking_tokens=0,
        disable_via_env_setting=False,
    )
