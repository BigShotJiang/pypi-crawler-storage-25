"""Reusable Codex CLI launch helpers."""

from __future__ import annotations

import json
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .provider_controls import resolve_provider_model_controls


@dataclass(frozen=True)
class CodexExecSpec:
    cmd_parts: tuple[str, ...]
    display_text: str
    applied_controls: dict[str, Any]
    effective_reasoning: str


def _resolve_codex_reasoning(
    *,
    model_reasoning: str | None = None,
    model_controls: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], str]:
    controls = resolve_provider_model_controls(
        provider="codex",
        model_reasoning=model_reasoning,
        model_controls=model_controls,
    )
    applied_raw = controls.get("applied")
    applied_controls = applied_raw if isinstance(applied_raw, dict) else {}
    effective_reasoning_raw = applied_controls.get("reasoning_effort")
    if isinstance(effective_reasoning_raw, str) and effective_reasoning_raw.strip():
        return applied_controls, effective_reasoning_raw
    if isinstance(model_reasoning, str) and model_reasoning.strip():
        return applied_controls, model_reasoning
    raise ValueError("Codex launch requires a reasoning effort")


def build_codex_exec_spec(
    *,
    codex_bin: str,
    model: str,
    cwd: Path,
    output_schema_path: Path,
    output_path: Path,
    model_reasoning: str | None = None,
    model_controls: dict[str, Any] | None = None,
    json_output: bool,
    sandbox: str,
    full_auto: bool = True,
    skip_git_repo_check: bool = True,
    extra_args: tuple[str, ...] | list[str] | None = None,
    stdin_placeholder: str | None = "<prompt>",
) -> CodexExecSpec:
    applied_controls, effective_reasoning = _resolve_codex_reasoning(
        model_reasoning=model_reasoning,
        model_controls=model_controls,
    )
    reasoning_config_value = json.dumps(effective_reasoning)

    from .headless import build_codex_headless_core

    cmd_parts: list[str] = build_codex_headless_core(
        model,
        binary=str(codex_bin),
        sandbox_mode=sandbox if sandbox else None,
        full_auto=full_auto,
        skip_git_repo_check=skip_git_repo_check,
    )
    if json_output:
        cmd_parts.append("--json")
    cmd_parts.extend(
        [
            "--config",
            f"model_reasoning_effort={reasoning_config_value}",
            "-C",
            str(cwd),
            "--output-schema",
            str(output_schema_path),
            "-o",
            str(output_path),
        ]
    )
    if extra_args:
        cmd_parts.extend([str(part) for part in extra_args])
    display_parts = [shlex.quote(part) for part in cmd_parts]
    if stdin_placeholder is not None:
        display_parts.append(stdin_placeholder)
    return CodexExecSpec(
        cmd_parts=tuple(cmd_parts),
        display_text=" ".join(display_parts),
        applied_controls=applied_controls,
        effective_reasoning=effective_reasoning,
    )
