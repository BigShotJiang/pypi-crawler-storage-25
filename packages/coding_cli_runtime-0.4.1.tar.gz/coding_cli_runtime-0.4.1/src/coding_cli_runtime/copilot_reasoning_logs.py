"""Copilot share-export and process-log parsing helpers."""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from pathlib import Path
from typing import Any

SESSION_ID_RE = re.compile(r"\*\*Session ID:\*\*\s*`([^`]+)`")
DEFAULT_REASONING_RE = re.compile(r"defaultReasoningEffort=([A-Za-z0-9_-]+)")


def extract_session_id(markdown_text: str) -> str | None:
    match = SESSION_ID_RE.search(markdown_text)
    return match.group(1) if match else None


def extract_final_request_options(log_text: str) -> dict[str, Any]:
    marker = "Final request options:"
    idx = log_text.find(marker)
    if idx < 0:
        return {}

    start = log_text.find("{", idx)
    if start < 0:
        return {}

    try:
        parsed, _ = json.JSONDecoder().raw_decode(log_text[start:])
    except json.JSONDecodeError:
        return {}
    if not isinstance(parsed, Mapping):
        return {}
    return dict(parsed)


def classify_reasoning_fields(options: Mapping[str, Any]) -> tuple[str, str, str, str]:
    reasoning_effort = options.get("reasoning_effort")
    thinking_budget = options.get("thinking_budget")
    if reasoning_effort is not None:
        value = str(reasoning_effort)
        return "reasoning_effort", value, value, ""
    if thinking_budget is not None:
        value = str(thinking_budget)
        return "thinking_budget", value, "", value
    return "none", "", "", ""


def extract_default_reasoning(log_text: str) -> str:
    match = DEFAULT_REASONING_RE.search(log_text)
    return match.group(1) if match else ""


def find_process_log_for_session(
    session_id: str,
    logs_dir: Path,
    *,
    max_candidates: int = 400,
) -> Path | None:
    if not session_id or not logs_dir.exists():
        return None

    candidates: list[tuple[float, Path]] = []
    for path in logs_dir.glob("process-*.log"):
        try:
            mtime = path.stat().st_mtime
        except OSError:
            continue
        candidates.append((mtime, path))

    candidates.sort(key=lambda item: item[0], reverse=True)
    for _, path in candidates[:max_candidates]:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if session_id in text:
            return path
    return None
