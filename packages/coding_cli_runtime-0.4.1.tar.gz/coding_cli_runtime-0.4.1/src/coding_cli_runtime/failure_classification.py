"""Provider stderr classification for retry and failure-injection handling."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class FailureClassification:
    provider: str
    retryable: bool
    category: str


def _classify_gemini(stderr_text: str) -> FailureClassification:
    lowered = stderr_text.lower()

    auth_expiry_markers = (
        "authentication timed out",
        "token expired",
        "refresh token",
        "please run gemini auth login",
        "reauthenticate",
    )
    if any(marker in lowered for marker in auth_expiry_markers):
        return FailureClassification(provider="gemini", retryable=False, category="auth_expired")

    auth_or_permission_markers = (
        "invalid api key",
        "permission denied",
        "unauthorized",
        "forbidden",
    )
    if any(marker in lowered for marker in auth_or_permission_markers):
        return FailureClassification(
            provider="gemini", retryable=False, category="auth_or_permission"
        )

    rate_limit_markers = (
        "quota",
        "rate limit",
        "resource exhausted",
        "insufficient_quota",
        "exhausted your capacity",
        "billing",
    )
    if any(marker in lowered for marker in rate_limit_markers):
        return FailureClassification(provider="gemini", retryable=False, category="rate_limited")

    always_transient_markers = (
        "eai_again",
        "getaddrinfo",
        "temporary failure in name resolution",
        "enotfound",
        "etimedout",
        "econnreset",
        "econnrefused",
        "socket hang up",
    )
    if any(marker in lowered for marker in always_transient_markers):
        return FailureClassification(
            provider="gemini", retryable=True, category="network_transient"
        )

    stdin_transport_markers = ("no input provided via stdin",)
    if any(marker in lowered for marker in stdin_transport_markers):
        return FailureClassification(
            provider="gemini", retryable=True, category="cli_stdin_transient"
        )

    weak_transient_markers = (
        "network error",
        "failed, reason:",
    )
    if not any(marker in lowered for marker in weak_transient_markers):
        return FailureClassification(provider="gemini", retryable=False, category="unknown")

    signal_markers = (
        "cloudcode-pa.googleapis.com",
        "streamgeneratecontent",
        "loadcodeassist",
        "gaxioserror",
        "fetcherror",
    )
    if any(marker in lowered for marker in signal_markers):
        return FailureClassification(
            provider="gemini", retryable=True, category="network_transient"
        )

    return FailureClassification(provider="gemini", retryable=False, category="unknown")


def _classify_copilot(stderr_text: str) -> FailureClassification:
    lowered = stderr_text.lower()

    auth_markers = (
        "no authentication information found",
        "copilot can be authenticated",
        "gh auth login",
    )
    if any(marker in lowered for marker in auth_markers):
        return FailureClassification(provider="copilot", retryable=False, category="auth_missing")

    # Copilot CLI sometimes exits before producing stderr and only logs this in
    # ~/.copilot/logs/process-*.log. Treat this startup path as transient.
    startup_rate_limit_markers = (
        "failed to list models: 429",
        "error posting to endpoint: too many requests",
        "failed to open sse stream",
        "error loading models",
    )
    if any(marker in lowered for marker in startup_rate_limit_markers):
        return FailureClassification(
            provider="copilot", retryable=True, category="startup_rate_limited"
        )

    session_store_lock_markers = (
        "database is locked",
        "session store",
    )
    if all(marker in lowered for marker in session_store_lock_markers):
        return FailureClassification(
            provider="copilot", retryable=True, category="session_store_locked"
        )

    return FailureClassification(provider="copilot", retryable=False, category="unknown")


def _classify_claude(stderr_text: str) -> FailureClassification:
    lowered = stderr_text.lower()

    auth_markers = (
        "not authenticated",
        "authentication required",
        "please run claude auth login",
        "please run /login",
        "invalid api key",
        "unauthorized",
        "forbidden",
    )
    if any(marker in lowered for marker in auth_markers):
        return FailureClassification(provider="claude", retryable=False, category="auth_missing")

    rate_limit_markers = (
        "rate limit",
        "too many requests",
        "quota",
        "insufficient_quota",
    )
    if any(marker in lowered for marker in rate_limit_markers):
        return FailureClassification(provider="claude", retryable=False, category="rate_limited")

    transient_markers = (
        "overloaded",
        "temporarily unavailable",
        "please try again",
        "eai_again",
        "getaddrinfo",
        "temporary failure in name resolution",
        "enotfound",
        "etimedout",
        "econnreset",
        "econnrefused",
        "socket hang up",
        "network error",
    )
    if any(marker in lowered for marker in transient_markers):
        return FailureClassification(
            provider="claude", retryable=True, category="network_transient"
        )

    return FailureClassification(provider="claude", retryable=False, category="unknown")


def classify_provider_failure(*, provider: str, stderr_text: str) -> FailureClassification:
    provider_key = provider.strip().lower()
    if provider_key == "gemini":
        return _classify_gemini(stderr_text)
    if provider_key == "copilot":
        return _classify_copilot(stderr_text)
    if provider_key == "claude":
        return _classify_claude(stderr_text)
    return FailureClassification(provider=provider_key, retryable=False, category="unknown")
