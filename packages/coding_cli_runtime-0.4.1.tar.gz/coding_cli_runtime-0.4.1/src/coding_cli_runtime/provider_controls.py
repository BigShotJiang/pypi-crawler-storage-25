"""Provider model-control normalization helpers."""

from __future__ import annotations

from typing import Any

PROVIDER_SUPPORTED_MODEL_CONTROLS: dict[str, set[str]] = {
    "codex": {"reasoning_effort"},
    "claude": {"effort", "thinking_tokens"},
    "copilot": {"reasoning_effort"},
    "gemini": set(),
}


def _normalize_reasoning_effort(value: Any) -> str | None:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return None


def _normalize_thinking_tokens(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return max(int(value), 0)
    if isinstance(value, str):
        try:
            parsed = int(value.strip())
        except ValueError:
            return None
        return max(parsed, 0)
    return None


def _normalize_claude_effort(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip().lower()
    if normalized in {"low", "medium", "high"}:
        return normalized
    return None


def resolve_provider_model_controls(
    *,
    provider: str,
    model_reasoning: str | None = None,
    thinking_tokens: int | None = None,
    effort: str | None = None,
    model_controls: dict[str, Any] | None = None,
) -> dict[str, Any]:
    provider_value = str(provider).strip().lower()
    requested_raw: dict[str, Any] = {}

    if isinstance(model_controls, dict):
        for key, value in model_controls.items():
            if isinstance(key, str):
                requested_raw[key] = value

    if "reasoning_effort" not in requested_raw and model_reasoning is not None:
        requested_raw["reasoning_effort"] = model_reasoning
    if "thinking_tokens" not in requested_raw and thinking_tokens is not None:
        requested_raw["thinking_tokens"] = thinking_tokens
    if "effort" not in requested_raw and effort is not None:
        requested_raw["effort"] = effort

    requested: dict[str, Any] = {}
    reasoning_effort = _normalize_reasoning_effort(requested_raw.get("reasoning_effort"))
    if reasoning_effort is not None:
        requested["reasoning_effort"] = reasoning_effort

    tokens_value = _normalize_thinking_tokens(requested_raw.get("thinking_tokens"))
    if tokens_value is not None:
        requested["thinking_tokens"] = tokens_value

    effort_value = _normalize_claude_effort(requested_raw.get("effort"))
    if effort_value is not None:
        requested["effort"] = effort_value

    supported = PROVIDER_SUPPORTED_MODEL_CONTROLS.get(provider_value, set())
    applied = {key: requested[key] for key in sorted(requested) if key in supported}
    ignored_keys = [key for key in sorted(requested) if key not in supported]

    return {
        "provider": provider_value,
        "requested": requested,
        "applied": applied,
        "ignored_keys": ignored_keys,
    }


def build_model_id(model: str, *, applied_controls: dict[str, Any] | None = None) -> str:
    controls = dict(applied_controls or {})
    if not controls:
        return model
    if set(controls.keys()) == {"reasoning_effort"}:
        return f"{model}:{controls['reasoning_effort']}"
    suffix = ",".join(f"{key}={controls[key]}" for key in sorted(controls))
    return f"{model}:{suffix}"
