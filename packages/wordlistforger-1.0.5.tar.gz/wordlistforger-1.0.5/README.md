# WordlistForger

Advanced wordlist generator with pattern, lock, and mask support.


## Full Documentation

https://github.com/m14r41/WordlistForger/edit/main/README.md

## Usage

> You can use `wordlistForger` or  `wordlistorger` to run the command.

```bash
wordlistforger -p abc123 -l 100

# Generate API keys wordlist
wordlistForger -p api_key7m9xq2kpl4 -l 10   --strict-case
wordlistForger -p api_key7m9xq2kpl4 -l 10   --lock api_key --live

# Generate ORDER ID
wordlistForger -p ODER-ID-1943AC -l 10 --lock ODER-ID --live
wordlistForger -p ODER-ID-1943AC -l 10 --lock ODER-ID --strict-case --live