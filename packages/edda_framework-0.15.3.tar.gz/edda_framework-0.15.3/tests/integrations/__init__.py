"""Edda integrations tests."""
