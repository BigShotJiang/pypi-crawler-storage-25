#!/usr/bin/env python
from __future__ import print_function

import builtins
from datetime import datetime

from MediBot import MediBot_UI


def _patient_info(count):
    rows = []
    for idx in range(count):
        rows.append((
            "05/{:02d}/2026".format(idx + 1),
            "Patient {}".format(idx + 1),
            "PID{}".format(idx + 1),
            "D{:03d}".format(idx + 1),
            {},
        ))
    return rows


def _patient_info_with_names(count):
    rows = []
    for idx in range(count):
        rows.append((
            "05/01/2026",
            "Patient {:02d}".format(idx + 1),
            "PID{}".format(idx + 1),
            "D{:03d}".format(idx + 1),
            {},
        ))
    return rows


def _patch_input(monkeypatch, values):
    pending = list(values)

    def fake_input(prompt=""):
        if not pending:
            raise AssertionError("preview requested more input than expected")
        return pending.pop(0)

    monkeypatch.setattr(builtins, "input", fake_input)
    return pending


def test_option_a_preview_records_enter_skip_and_cancel(monkeypatch, capsys):
    _patch_input(monkeypatch, ["12", "s", "0", ""])

    summary = MediBot_UI.run_option_a_minutes_entry_preview(
        _patient_info(3),
        date_of_service_label="05/01/2026",
    )

    assert summary["entered"] == 1
    assert summary["skipped"] == 1
    assert summary["cancelled"] == 1
    assert summary["rows"][0]["minutes"] == "12"
    assert summary["rows"][0]["status"] == "ENTERED"
    assert summary["rows"][0]["charge_display"] == "$450"
    assert summary["rows"][0]["charge_note"] == ""
    assert summary["rows"][1]["status"] == "SKIPPED"
    assert summary["rows"][1]["charge_display"] == "SKIPPED"
    assert summary["rows"][2]["status"] == "CANCELLED"
    assert summary["rows"][2]["charge_display"] == "CANCELLED"
    output = capsys.readouterr().out
    assert "CHARGE" in output
    assert "NOTE" in output
    assert "Service line input complete: entered=1, skipped=1, cancelled=1." in output
    assert "Returning to MediBot workflow..." in output


def test_option_a_preview_back_revises_previous_row_and_quit_returns(monkeypatch, capsys):
    _patch_input(monkeypatch, ["10", "b", "15", "q"])

    summary = MediBot_UI.run_option_a_minutes_entry_preview(_patient_info(2))

    assert summary["entered"] == 1
    assert summary["skipped"] == 0
    assert summary["cancelled"] == 0
    assert summary["rows"][0]["minutes"] == "15"
    assert summary["rows"][0]["status"] == "ENTERED"
    assert summary["rows"][1]["minutes"] == ""
    assert summary["rows"][1]["status"] == "PENDING"
    assert "Returning to MediBot workflow..." in capsys.readouterr().out


def test_option_a_preview_zero_cancel_is_immediate(monkeypatch):
    _patch_input(monkeypatch, ["0", ""])

    summary = MediBot_UI.run_option_a_minutes_entry_preview(_patient_info(1))

    assert summary["entered"] == 0
    assert summary["cancelled"] == 1
    assert summary["rows"][0]["minutes"] == ""
    assert summary["rows"][0]["status"] == "CANCELLED"


def test_option_a_preview_rejects_minutes_outside_5_to_59(monkeypatch, capsys):
    _patch_input(monkeypatch, ["4", "60", "113", "5", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)

    summary = MediBot_UI.run_option_a_minutes_entry_preview(_patient_info(1))

    output = capsys.readouterr().out
    assert output.count("Invalid input. Enter minutes 5-59") >= 3
    assert summary["entered"] == 1
    assert summary["rows"][0]["minutes"] == "5"
    assert summary["rows"][0]["status"] == "ENTERED"
    assert summary["rows"][0]["charge_display"] == "$450"


def test_option_a_preview_empty_input_quit_leaves_rows_pending(monkeypatch, capsys):
    _patch_input(monkeypatch, ["", "q"])

    summary = MediBot_UI.run_option_a_minutes_entry_preview(_patient_info(1))

    assert summary["entered"] == 0
    assert summary["skipped"] == 0
    assert summary["cancelled"] == 0
    assert summary["rows"][0]["status"] == "PENDING"
    assert summary["rows"][0]["charge_display"] == "PENDING"
    output = capsys.readouterr().out
    assert "Please enter minutes or a command." in output
    assert "Returning to MediBot workflow..." in output


def test_option_a_preview_strips_midnight_time_from_date_only_dos(monkeypatch, capsys):
    _patch_input(monkeypatch, ["q"])

    MediBot_UI.run_option_a_minutes_entry_preview(
        _patient_info(1),
        date_of_service_label=datetime(2026, 1, 20, 0, 0, 0),
    )

    output = capsys.readouterr().out
    assert "DOS: 2026-01-20" in output
    assert "DOS: 2026-01-20 00:00:00" not in output


def test_option_a_preview_clears_screen_before_each_table_redraw(monkeypatch):
    clear_commands = []
    _patch_input(monkeypatch, ["", "q"])

    def fake_system(command):
        clear_commands.append(command)
        return 0

    monkeypatch.setattr(MediBot_UI.os, "system", fake_system)

    MediBot_UI.run_option_a_minutes_entry_preview(_patient_info(1))

    assert len(clear_commands) == 2
    assert clear_commands == ["cls" if MediBot_UI.os.name == "nt" else "clear"] * 2


def test_option_a_preview_paginates_lists_longer_than_25(monkeypatch, capsys):
    _patch_input(monkeypatch, ["q"])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)

    MediBot_UI.run_option_a_minutes_entry_preview(_patient_info_with_names(43))

    output = capsys.readouterr().out
    assert "Page 1 of 2 - showing patients 1-25 of 43" in output
    assert "Showing patients 1-25 of 43; pages advance automatically." in output
    assert "Patient 25" in output
    assert "Patient 26" not in output


def test_option_a_preview_does_not_show_pagination_for_25_or_fewer(monkeypatch, capsys):
    _patch_input(monkeypatch, ["q"])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)

    MediBot_UI.run_option_a_minutes_entry_preview(_patient_info_with_names(25))

    output = capsys.readouterr().out
    assert "Page 1 of" not in output
    assert "pages advance automatically" not in output
    assert "Patient 25" in output


def test_option_a_preview_advances_to_next_page_at_patient_26(monkeypatch, capsys):
    inputs = ["s"] * 25 + ["q"]
    _patch_input(monkeypatch, inputs)
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)

    summary = MediBot_UI.run_option_a_minutes_entry_preview(_patient_info_with_names(43))

    output = capsys.readouterr().out
    assert "Page 2 of 2 - showing patients 26-43 of 43" in output
    assert "Enter minutes 5-59 for patient 26 of 43" in output
    assert summary["skipped"] == 25
    assert summary["rows"][24]["status"] == "SKIPPED"
    assert summary["rows"][25]["status"] == "PENDING"


def test_option_a_preview_auto_cancelled_rows_are_displayed_and_not_prompted(monkeypatch, capsys):
    _patch_input(monkeypatch, ["9", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    patient_info = [
        ("05/01/2026", "Patient 01", "PID1", "Unknown", {
            "_option_a_preview_status": "CANCELLED",
            "_option_a_preview_status_reason": "docx_diagnosis_unknown",
        }),
        ("05/01/2026", "Patient 02", "PID2", "D002", {}),
    ]

    summary = MediBot_UI.run_option_a_minutes_entry_preview(patient_info)

    output = capsys.readouterr().out
    assert "Patient 01" in output
    assert "CANCELLED" in output
    assert "Enter minutes 5-59 for patient 2 of 2" in output
    assert "Enter minutes for patient 1 of 2" not in output
    assert summary["entered"] == 1
    assert summary["cancelled"] == 1
    assert summary["rows"][0]["status"] == "CANCELLED"
    assert summary["rows"][1]["minutes"] == "9"


def test_option_a_preview_all_auto_cancelled_rows_render_without_prompt(monkeypatch, capsys):
    _patch_input(monkeypatch, [""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    patient_info = [
        ("05/01/2026", "Patient 01", "PID1", "Unknown", {
            "_option_a_preview_status": "CANCELLED",
            "_option_a_preview_status_reason": "docx_diagnosis_unknown",
        }),
        ("05/01/2026", "Patient 02", "PID2", "Unknown", {
            "_option_a_preview_status": "CANCELLED",
            "_option_a_preview_status_reason": "docx_diagnosis_unknown",
        }),
    ]

    summary = MediBot_UI.run_option_a_minutes_entry_preview(patient_info)

    output = capsys.readouterr().out
    assert "Patient 01" in output
    assert "Patient 02" in output
    assert "CANCELLED" in output
    assert "No pending patients remain for this DOS." in output
    assert "Enter minutes for patient" not in output
    assert summary["entered"] == 0
    assert summary["cancelled"] == 2


def test_option_a_preview_final_entry_redraws_completed_table(monkeypatch, capsys):
    _patch_input(monkeypatch, ["5", "6", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    patient_info = [
        ("05/01/2026", "Patient 01", "PID1", "D001", {}),
        ("05/01/2026", "Patient 02", "PID2", "D002", {}),
    ]

    summary = MediBot_UI.run_option_a_minutes_entry_preview(patient_info)

    output = capsys.readouterr().out
    assert "Patient 01" in output
    assert "$450" in output
    assert "baseline 5-15" not in output
    assert "Patient 02" in output
    assert "No pending patients remain for this DOS." in output
    assert output.rfind("No pending patients remain for this DOS.") < output.rfind("Service line input complete")
    assert summary["entered"] == 2
    assert summary["rows"][1]["minutes"] == "6"


def test_option_a_preview_completed_table_can_edit_existing_row(monkeypatch, capsys):
    _patch_input(monkeypatch, ["2", "8", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    patient_info = [
        ("05/01/2026", "Patient 01", "PID1", "D001", {
            "_option_a_preview_status": "ENTERED",
            "_option_a_preview_minutes": "5",
        }),
        ("05/01/2026", "Patient 02", "PID2", "D002", {
            "_option_a_preview_status": "ENTERED",
            "_option_a_preview_minutes": "6",
        }),
    ]

    summary = MediBot_UI.run_option_a_minutes_entry_preview(patient_info)

    output = capsys.readouterr().out
    assert "Press Enter to accept, enter row number to edit minutes" in output
    assert "Enter minutes 5-59 for patient 2 of 2" in output
    assert "$450" in output
    assert "baseline 5-15" not in output
    assert summary["entered"] == 2
    assert summary["rows"][0]["minutes"] == "5"
    assert summary["rows"][1]["minutes"] == "8"


def test_option_a_preview_completed_table_edit_rejects_invalid_minutes(monkeypatch, capsys):
    _patch_input(monkeypatch, ["2", "4", "60", "8", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    patient_info = [
        ("05/01/2026", "Patient 01", "PID1", "D001", {
            "_option_a_preview_status": "ENTERED",
            "_option_a_preview_minutes": "5",
        }),
        ("05/01/2026", "Patient 02", "PID2", "D002", {
            "_option_a_preview_status": "ENTERED",
            "_option_a_preview_minutes": "6",
        }),
    ]

    summary = MediBot_UI.run_option_a_minutes_entry_preview(patient_info)

    output = capsys.readouterr().out
    assert output.count("Invalid input. Enter minutes 5-59") >= 2
    assert summary["rows"][0]["minutes"] == "5"
    assert summary["rows"][1]["minutes"] == "8"
    assert summary["rows"][1]["status"] == "ENTERED"


def test_service_line_input_preview_accepts_review_only_diagnosis_and_cpt_edits(monkeypatch, capsys):
    _patch_input(monkeypatch, ["dx=H25.812", "cpt=00142", "12", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)

    summary = MediBot_UI.run_service_line_input_entry(_patient_info(1))

    row = summary["rows"][0]
    output = capsys.readouterr().out
    assert "Diagnosis updated for review." in output
    assert "CPT updated for review." in output
    assert row["diagnosis"] == "H25.812"
    assert row["diagnosis_code"] == "H25.812"
    assert row["diagnosis_source"] == "operator_overlay"
    assert row["cpt"] == "00142"
    assert row["cpt_code"] == "00142"
    assert row["cpt_source"] == "operator_overlay"
    assert row["cpt_confidence"] == "operator_confirmed"
    assert row["cpt_status"] == "operator_corrected"
    assert row["minutes"] == "12"
    assert row["status"] == "ENTERED"
    assert row["charge_display"] == "$450"
    assert row["workflow_boundary"] == "preview_only_review_required"
    assert row["claims_completion"] is False
    assert row["mutates_billing_state"] is False


def test_service_line_input_diagnosis_edit_displays_icd10_from_medisoft_bridge(monkeypatch, capsys):
    _patch_input(monkeypatch, ["dx=25812", "12", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)

    summary = MediBot_UI.run_service_line_input_entry(
        _patient_info(1),
        diagnosis_options=["H25.812", "25812"],
        diagnosis_display_map={
            "25812": "H25.812",
            "H25812": "H25.812",
        },
    )

    row = summary["rows"][0]
    output = capsys.readouterr().out
    assert "Diagnosis updated for review." in output
    assert row["diagnosis_raw_value"] == "25812"
    assert row["diagnosis"] == "H25.812"
    assert row["diagnosis_code"] == "H25.812"
    assert row["diagnosis_display_source"] == "crosswalk.diagnosis_to_medisoft"
    assert row["diagnosis_source"] == "operator_overlay"
    assert row["minutes"] == "12"


def test_service_line_input_initial_docx_shorthand_displays_icd10_from_bridge(monkeypatch, capsys):
    _patch_input(monkeypatch, ["12", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    patient_info = [("05/01/2026", "Patient 01", "PID1", "25812", {})]

    summary = MediBot_UI.run_service_line_input_entry(
        patient_info,
        diagnosis_options=["H25.812", "25812"],
        diagnosis_display_map={
            "25812": "H25.812",
            "H25812": "H25.812",
        },
    )

    row = summary["rows"][0]
    output = capsys.readouterr().out
    assert "H25.812" in output
    assert "25812" not in output
    assert row["diagnosis_raw_value"] == "25812"
    assert row["diagnosis"] == "H25.812"
    assert row["diagnosis_code"] == "H25.812"
    assert row["diagnosis_display_source"] == "crosswalk.diagnosis_to_medisoft"


def test_service_line_input_unknown_diagnosis_uses_intake_handler(monkeypatch, capsys):
    _patch_input(monkeypatch, ["dx=H26.101", "12", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    calls = []

    def fake_intake_handler(row, field_name, value):
        calls.append((field_name, value, row.get("patient_id")))
        return {
            "ok": True,
            "message": "Crosswalk updated; Service Line Input row updated.",
            "row_updates": {
                "diagnosis": "H26.101",
                "diagnosis_code": "H26.101",
                "diagnosis_source": "operator_crosswalk_intake",
                "cpt": "00140",
                "cpt_code": "00140",
                "cpt_source": "operator_crosswalk_intake",
                "cpt_confidence": "operator_confirmed",
                "cpt_status": "operator_corrected",
                "validation_status": "review_required",
                "validation_note": "crosswalk intake confirmed",
                "crosswalk_intake_save_ok": True,
            },
            "crosswalk_intake_events": [{
                "schema_version": "service_line_input_crosswalk_intake_event.v1",
                "workflow_boundary": "confirmed_config_update",
                "claims_completion": False,
                "mutates_dat": False,
                "mutates_837p": False,
                "charges_entered": False,
            }],
        }

    summary = MediBot_UI.run_service_line_input_entry(
        _patient_info(1),
        diagnosis_options=["H25.812"],
        cpt_options=["00142"],
        crosswalk_intake_handler=fake_intake_handler,
    )

    row = summary["rows"][0]
    output = capsys.readouterr().out
    assert calls == [("diagnosis", "H26.101", "PID1")]
    assert "Crosswalk updated; Service Line Input row updated." in output
    assert row["diagnosis"] == "H26.101"
    assert row["diagnosis_source"] == "operator_crosswalk_intake"
    assert row["cpt"] == "00140"
    assert row["cpt_source"] == "operator_crosswalk_intake"
    assert row["minutes"] == "12"
    assert row["charge_display"] == "$450"
    assert row["workflow_boundary"] == "preview_only_review_required"
    assert row["claims_completion"] is False
    assert row["crosswalk_intake_events"][0]["workflow_boundary"] == "confirmed_config_update"
    assert row["crosswalk_intake_events"][0]["mutates_837p"] is False


def test_service_line_input_unknown_diagnosis_without_handler_stays_review_only(monkeypatch, capsys):
    _patch_input(monkeypatch, ["dx=H26.101", "q"])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)

    summary = MediBot_UI.run_service_line_input_entry(
        _patient_info(1),
        diagnosis_options=["H25.812"],
    )

    row = summary["rows"][0]
    output = capsys.readouterr().out
    assert "Invalid diagnosis. Choose one of the listed diagnosis codes." in output
    assert row["diagnosis"] == "D00.1"
    assert row["status"] == "PENDING"
    assert row["claims_completion"] is False
    assert row["mutates_billing_state"] is False


def test_service_line_input_empty_option_list_treats_edit_as_unknown_when_handler_exists(monkeypatch, capsys):
    _patch_input(monkeypatch, ["cpt=00140", "12", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    calls = []

    def fake_intake_handler(row, field_name, value):
        calls.append((field_name, value))
        return {
            "ok": True,
            "message": "Crosswalk updated; Service Line Input row updated.",
            "row_updates": {
                "diagnosis": "H26.101",
                "diagnosis_code": "H26.101",
                "diagnosis_source": "operator_crosswalk_intake",
                "cpt": "00140",
                "cpt_code": "00140",
                "cpt_source": "operator_crosswalk_intake",
                "cpt_confidence": "operator_confirmed",
                "cpt_status": "operator_corrected",
                "crosswalk_intake_save_ok": True,
            },
        }

    summary = MediBot_UI.run_service_line_input_entry(
        _patient_info(1),
        diagnosis_options=[],
        cpt_options=[],
        crosswalk_intake_handler=fake_intake_handler,
    )

    row = summary["rows"][0]
    assert calls == [("cpt", "00140")]
    assert "Crosswalk updated; Service Line Input row updated." in capsys.readouterr().out
    assert row["diagnosis"] == "H26.101"
    assert row["cpt"] == "00140"
    assert row["minutes"] == "12"


def test_service_line_input_completed_table_direct_edits_preserve_minutes_status_and_charge(monkeypatch, capsys):
    _patch_input(monkeypatch, ["1 dx=H40.11X2", "1 cpt=00140", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    patient_info = [(
        "05/01/2026",
        "Patient 01",
        "PID1",
        "D001",
        {
            "_service_line_input_status": "ENTERED",
            "_service_line_input_minutes": "18",
            "_service_line_input_cpt": "00142",
        },
    )]

    summary = MediBot_UI.run_service_line_input_entry(patient_info)

    row = summary["rows"][0]
    output = capsys.readouterr().out
    assert "Diagnosis updated for review." in output
    assert "CPT updated for review." in output
    assert row["diagnosis"] == "H40.11X2"
    assert row["cpt"] == "00140"
    assert row["minutes"] == "18"
    assert row["status"] == "ENTERED"
    assert row["charge_display"] == "$540"
    assert row["charge_note"] == ""
    assert row["workflow_boundary"] == "preview_only_review_required"
    assert row["claims_completion"] is False
    assert row["mutates_billing_state"] is False


def test_option_a_preview_renders_injected_charge_helper_output(monkeypatch, capsys):
    _patch_input(monkeypatch, ["18", ""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)

    def fake_charge_helper(context):
        return {
            "charge_status": "calculated",
            "charge_display": "$999",
            "charge_amount": "999.00",
            "charge_note": "paired DOS anchor",
            "charge_rule_id": "same_patient_dos_anchor",
            "workflow_boundary": "operational_charge_entry",
            "claims_completion": True,
            "mutates_billing_state": True,
            "charges_entered": True,
            "claim_submitted": True,
            "dat_mutation": True,
            "x12_837p_mutation": True,
        }

    summary = MediBot_UI.run_option_a_minutes_entry_preview(
        _patient_info(1),
        charge_calculator=fake_charge_helper,
    )

    output = capsys.readouterr().out
    assert "CHARGE" in output
    assert "$999" in output
    assert "paired DOS anchor" in output
    assert summary["rows"][0]["status"] == "ENTERED"
    assert summary["rows"][0]["charge_display"] == "$999"
    assert summary["rows"][0]["charge_note"] == "paired DOS anchor"
    assert summary["rows"][0]["workflow_boundary"] == "preview_only_review_required"
    assert summary["rows"][0]["claims_completion"] is False
    assert summary["rows"][0]["mutates_billing_state"] is False
    assert summary["rows"][0]["charges_entered"] is False
    assert "claim_submitted" not in summary["rows"][0]
    assert "dat_mutation" not in summary["rows"][0]
    assert "x12_837p_mutation" not in summary["rows"][0]


def test_service_line_input_sanitizes_hydrated_row_even_when_charge_not_recalculated(monkeypatch):
    _patch_input(monkeypatch, [""])
    monkeypatch.setattr(MediBot_UI.os, "system", lambda command: 0)
    patient_info = [(
        "05/01/2026",
        "Patient 01",
        "PID1",
        "D001",
        {
            "_service_line_input_status": "ENTERED",
            "_service_line_input_minutes": "12",
            "_service_line_input_charge_display": "$450",
            "_service_line_input_charge_note": "baseline 5-15",
            "_service_line_input_charge_rule_id": "baseline_5_15",
            "_service_line_input_workflow_boundary": "operational_charge_entry",
            "_service_line_input_claims_completion": True,
            "_service_line_input_mutates_billing_state": True,
            "charges_entered": True,
            "claim_submitted": True,
            "dat_mutation": True,
            "x12_837p_mutation": True,
        },
    )]

    summary = MediBot_UI.run_service_line_input_entry(patient_info)

    row = summary["rows"][0]
    assert row["charge_display"] == "$450"
    assert row["charge_note"] == ""
    assert row["workflow_name"] == "service_line_input"
    assert row["workflow_boundary"] == "preview_only_review_required"
    assert row["claims_completion"] is False
    assert row["mutates_billing_state"] is False
    assert row["charges_entered"] is False
    assert "claim_submitted" not in row
    assert "dat_mutation" not in row
    assert "x12_837p_mutation" not in row
