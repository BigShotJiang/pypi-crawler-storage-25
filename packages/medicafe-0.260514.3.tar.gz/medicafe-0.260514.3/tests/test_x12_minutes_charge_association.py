import json
import os
import sys


REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
SCRIPT_DIR = os.path.join(REPO_ROOT, "scripts", "unified_model")
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

from workflow_boundary_contract import assert_workflow_boundary_clean

import run_x12_minutes_charge_association as assoc


def _meta(run_id="test-run", basename="claim.txt", sha="abc123"):
    return {
        "run_id": run_id,
        "source_file_basename": basename,
        "source_file_sha256_prefix": sha,
    }


def test_current_generated_shape_uses_sv1_charge_and_mj_minutes():
    text = (
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001*005010X222A1~"
        "CLM*123*450***11:B:1*Y*A*Y*Y~"
        "HI*ABK:H2511~"
        "LX*1~"
        "SV1*HC:00142:24*450*MJ*15***1~"
        "DTP*472*D8*20260101~"
        "SE*8*0001~"
    )

    parsed = assoc.parse_x12_minutes_charge_rows(text, _meta())

    assert parsed["claims"] == 1
    assert parsed["service_lines"] == 1
    assert parsed["service_lines_with_observation"] == 1
    assert parsed["warning_counts"] == {}
    row = parsed["rows"][0]
    assert row["schema_version"] == assoc.ROW_SCHEMA_VERSION
    assert row["run_id"] == "test-run"
    assert row["source_file_basename"] == "claim.txt"
    assert row["source_file_sha256_prefix"] == "abc123"
    assert row["cpt_code"] == "00142"
    assert row["procedure_modifier"] == "24"
    assert row["line_charge_amount"] == "450.00"
    assert row["claim_charge_amount"] == "450.00"
    assert row["service_unit_code"] == "MJ"
    assert row["anesthesia_minutes"] == "15"
    assert row["lx"] == "1"
    assert row["service_date"] == "20260101"
    assert row["observation_basis"] == "sv1_charge_mj_minutes"
    assert row["warning_codes"] == []
    assert row["line_count_in_claim"] == 1
    assert row["validation_mode"] == assoc.VALIDATION_MODE_HISTORICAL_837P
    assert row["historical_out_of_custody_expected"] is True
    assert row["custody_required_for_stage2b_validation"] is False
    assert row["submitted_claim_number_hash"]
    assert "CLM*123" not in json.dumps(row, sort_keys=True)


def test_non_mj_and_malformed_service_lines_are_warned_not_observed():
    text = (
        "ST*837*0001~"
        "LX*1~"
        "SV1*HC:00142:24*450*UN*1***1~"
        "LX*2~"
        "SV1*HC:00145:24*BAD*MJ*15***1~"
        "LX*3~"
        "SV1*HC:00140:24*540*MJ*18***1~"
        "SE*8*0001~"
    )

    parsed = assoc.parse_x12_minutes_charge_rows(text, _meta())

    assert parsed["service_lines"] == 3
    assert parsed["service_lines_with_observation"] == 1
    assert len(parsed["rows"]) == 1
    assert parsed["rows"][0]["cpt_code"] == "00140"
    assert parsed["warning_counts"][assoc.WARNING_NON_MJ_SERVICE_UNIT] == 1
    assert parsed["warning_counts"][assoc.WARNING_INVALID_CHARGE] == 1


def test_report_inventory_probability_privacy_and_operator_summary(tmp_path):
    claim_path = tmp_path / "claim_payload.txt"
    claim_path.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001~HI*ABK:H2511~LX*1~SV1*HC:00142:24*450*MJ*15***1~DTP*472*D8*20260101~SE*5*0001~"
        "ST*837*0002~HI*ABK:H2512~LX*1~SV1*HC:00142:24*450*MJ*15***1~SE*5*0002~"
        "ST*837*0003~HI*ABK:H4301~LX*1~SV1*HC:00145:24*540*MJ*28***1~SE*5*0003~",
        encoding="utf-8",
    )
    lab_dir = tmp_path / "lab"

    summary, rows, artifacts = assoc.run_analysis(
        [str(claim_path)],
        str(lab_dir),
        run_id="fixed-run",
    )

    assert summary["files_scanned"] == 1
    assert summary["files_parsed"] == 1
    assert summary["total_claims"] == 3
    assert summary["total_observations"] == 3
    assert summary["minutes_to_charge"]["15"]["total_pairs"] == 2
    assert summary["minutes_to_charge"]["15"]["associations"][0]["code"] == "450.00"
    assert summary["minutes_to_charge"]["15"]["associations"][0]["probability"] == 1.0
    assert summary["charge_to_minutes"]["540.00"]["associations"][0]["code"] == "28"
    assert summary["health_telemetry"]["trust_level"] == "high"
    assert len(rows) == 3

    rows_text = (lab_dir / "reports" / "x12_minutes_charge_rows_fixed-run.jsonl").read_text(encoding="utf-8")
    summary_text = (lab_dir / "reports" / "x12_minutes_charge_summary_fixed-run.json").read_text(encoding="utf-8")
    summary_txt_text = (lab_dir / "reports" / "x12_minutes_charge_summary_fixed-run.txt").read_text(encoding="utf-8")
    assert "patient_name" not in rows_text
    assert "member_id" not in rows_text
    assert "CLM01" not in rows_text
    assert str(claim_path) not in rows_text
    assert str(claim_path) not in summary_text
    assert str(claim_path) not in summary_txt_text
    assert "Minutes/Charge Retrospective Review" in summary_txt_text
    assert "Top Minutes To Charge Observations" in summary_txt_text
    assert "15       $450.00" in summary_txt_text
    assert "Privacy" in summary_txt_text
    assert os.path.exists(artifacts["summary_json"])

    operator_text = "\n".join(assoc.format_operator_summary_lines(summary, max_rows=2))
    assert "Minutes/Charge Review Results" in operator_text
    assert "Files: 1 analyzed" in operator_text
    assert "15 min -> $450.00" in operator_text

    assert_workflow_boundary_clean(
        "x12_minutes_charge_report_only_review",
        {"analytics_run_id": "fixed-run"},
        [
            {
                "name": "saved_837p_inventory",
                "role": "evidence_source",
                "identity": {"analytics_run_id": "fixed-run"},
                "status": "completed",
                "classification": "note_present",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
            {
                "name": os.path.basename(artifacts["summary_json"]),
                "role": "report_artifact",
                "identity": {"analytics_run_id": "fixed-run"},
                "status": "completed",
                "classification": "review_required",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
        ],
    )


def test_submission_index_inventory_is_reused_for_minutes_charge(tmp_path):
    receipts = tmp_path / "claims"
    receipts.mkdir()
    output = tmp_path / "outbox"
    output.mkdir()

    indexed_claim = receipts / "sent_indexed.txt"
    indexed_claim.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001~LX*1~SV1*HC:00142:24*450*MJ*15***1~SE*5*0001~",
        encoding="utf-8",
    )
    legacy_claim = output / "legacy_generated.txt"
    legacy_claim.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0002~LX*1~SV1*HC:00145:24*540*MJ*28***1~SE*5*0002~",
        encoding="utf-8",
    )
    with (receipts / "submission_index.jsonl").open("w", encoding="utf-8") as f:
        f.write(json.dumps({"record_type": "submission", "receipt_file": indexed_claim.name}))
        f.write("\n")
        f.write(json.dumps({"record_type": "submission", "receipt_file": "missing.txt"}))
        f.write("\n")
        f.write("{not-json}\n")

    summary, rows, _artifacts = assoc.run_analysis(
        [str(receipts), str(output)],
        str(tmp_path / "lab"),
        run_id="inventory-run",
    )

    inventory = summary["file_inventory"]
    assert summary["files_scanned"] == 2
    assert summary["total_observations"] == 2
    assert inventory["submission_index_existing_receipt_files"] == 1
    assert inventory["submission_index_missing_receipt_files"] == 1
    assert inventory["submission_index_invalid_json_lines"] == 1
    assert sorted([row["anesthesia_minutes"] for row in rows]) == ["15", "28"]


def test_stage2a_age_and_stage2b_historical_anchor_flags_are_scored(tmp_path):
    claims = tmp_path / "claims"
    claims.mkdir()
    claim_path = claims / "sent_pair.txt"
    claim_path.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001~"
        "NM1*IL*1*DOE*JANE****MI*MEM123~"
        "DMG*D8*19800102*F~"
        "CLM*SECRETCLAIM1*580***11:B:1*Y*A*Y*Y~"
        "LX*1~SV1*HC:00142:AA*580*MJ*15***1~DTP*472*D8*20260101~"
        "SE*8*0001~"
        "ST*837*0002~"
        "NM1*IL*1*DOE*JANE****MI*MEM123~"
        "DMG*D8*19800102*F~"
        "CLM*SECRETCLAIM2*580***11:B:1*Y*A*Y*Y~"
        "LX*1~SV1*HC:00142:AA*580*MJ*9***1~DTP*472*D8*20260110~"
        "SE*8*0002~"
        "ST*837*0003~"
        "NM1*IL*1*OLDER*PAT****MI*MEM999~"
        "DMG*D8*19500101*F~"
        "CLM*SECRETCLAIM3*540***11:B:1*Y*A*Y*Y~"
        "LX*1~SV1*HC:00142:AA*540*MJ*40***1~DTP*472*D8*20260102~"
        "SE*8*0003~",
        encoding="utf-8",
    )
    with (claims / "submission_index.jsonl").open("w", encoding="utf-8") as f:
        f.write(json.dumps({"record_type": "submission", "receipt_file": claim_path.name}))
        f.write("\n")

    summary, rows, artifacts = assoc.run_analysis([str(claims)], str(tmp_path / "lab"), run_id="stage2-run")

    assert summary["validation_mode"] == assoc.VALIDATION_MODE_HISTORICAL_837P
    assert summary["historical_out_of_custody_expected"] is True
    assert summary["custody_required_for_stage2b_validation"] is False
    assert summary["stage2b_eligible_group_count"] == 1
    assert summary["stage2b_submitted_pair_group_count"] == 1

    model_eval = summary["model_evaluation"]
    assert model_eval["models"][assoc.MODEL_STAGE1]["exact_match_rows"] == 0
    assert model_eval["models"][assoc.MODEL_STAGE2A]["exact_match_rows"] == 2
    assert model_eval["models"][assoc.MODEL_STAGE2B]["exact_match_rows"] == 3
    assert model_eval["stage2b_retrospective_anchor_validation"]["second_dos_match_rows"] == 1
    assert model_eval["stage2b_live_custody_projection"]["scored"] is False

    by_minutes = dict((row["anesthesia_minutes"], row) for row in rows)
    assert by_minutes["15"]["age_years_at_dos"] == 45
    assert by_minutes["15"]["stage2a_rule"] == "stage2a_15_age_le_45_580"
    assert by_minutes["9"]["dos_sequence_role"] == "second_dos"
    assert by_minutes["9"]["stage2b_retrospective_prediction"] == "580.00"
    assert by_minutes["9"]["stage2b_ambiguity_code"] == assoc.AMBIG_SUBMITTED_MATCH
    assert by_minutes["40"]["stage2a_rule"] == "stage2a_40_age_gt_65_540"

    rows_text = (tmp_path / "lab" / "reports" / "x12_minutes_charge_rows_stage2-run.jsonl").read_text(encoding="utf-8")
    groups_text = (tmp_path / "lab" / "reports" / "x12_minutes_charge_groups_stage2-run.jsonl").read_text(encoding="utf-8")
    model_text = (tmp_path / "lab" / "reports" / "x12_minutes_charge_model_eval_stage2-run.json").read_text(encoding="utf-8")
    combined = rows_text + groups_text + model_text
    assert "JANE" not in combined
    assert "MEM123" not in combined
    assert "19800102" not in combined
    assert "SECRETCLAIM" not in combined
    assert str(claim_path) not in combined
    assert os.path.exists(artifacts["groups_jsonl"])
    assert os.path.exists(artifacts["model_eval_json"])


def test_stage1_zero_low_and_high_domain_boundaries_are_explicit():
    rows = [
        {"anesthesia_minutes": "0", "line_charge_amount": "0.00"},
        {"anesthesia_minutes": "4", "line_charge_amount": "450.00"},
        {"anesthesia_minutes": "65", "line_charge_amount": "580.00"},
    ]

    analyzed, groups, model_eval = assoc.apply_model_analysis(rows)

    assert groups == []
    assert analyzed[0]["stage1_predicted_charge_amount"] == ""
    assert analyzed[0]["stage1_ambiguity_code"] == assoc.AMBIG_CANCELLED
    assert analyzed[1]["stage1_predicted_charge_amount"] == ""
    assert analyzed[1]["stage1_ambiguity_code"] == assoc.AMBIG_LOW_DOMAIN
    assert analyzed[2]["stage1_predicted_charge_amount"] == "580.00"
    assert analyzed[2]["stage1_rule"] == "stage1_cap_to_59"
    assert model_eval["models"][assoc.MODEL_STAGE1]["included_rows"] == 1
    assert model_eval["models"][assoc.MODEL_STAGE1]["exact_match_rows"] == 1


def test_email_flow_bundles_report_only_boundary_without_local_workflow_completion(tmp_path, monkeypatch):
    from MediCafe import error_reporter

    claims = tmp_path / "claims"
    claims.mkdir()
    outbox = tmp_path / "outbox"
    outbox.mkdir()
    claim_path = claims / "sent_claim.txt"
    claim_path.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260101*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260101*1200*1*X*005010X222A1~"
        "ST*837*0001~LX*1~SV1*HC:00142:24*450*MJ*15***1~SE*5*0001~",
        encoding="utf-8",
    )

    captured = {}

    def fake_runtime_context():
        return {
            "medi": {
                "local_claims_path": str(claims),
                "outputFilePath": str(outbox),
                "local_storage_path": str(tmp_path / "storage"),
            }
        }

    def fake_collect_support_bundle(include_traceback=True, extra_meta=None, extra_files=None, **kwargs):
        captured["include_traceback"] = include_traceback
        captured["extra_meta"] = dict(extra_meta or {})
        captured["extra_files"] = list(extra_files or [])
        return str(tmp_path / "medicafe_bundle_x12_minutes_charge_analytics.zip")

    def fake_submit_support_bundle_email(**kwargs):
        captured["submit_kwargs"] = dict(kwargs)
        return True

    monkeypatch.setenv("MEDICAFE_LAB_DIR", str(tmp_path / "lab"))
    monkeypatch.setattr(error_reporter, "_get_error_reporter_runtime_context", fake_runtime_context)
    monkeypatch.setattr(error_reporter, "collect_support_bundle", fake_collect_support_bundle)
    monkeypatch.setattr(error_reporter, "submit_support_bundle_email", fake_submit_support_bundle_email)

    rc = error_reporter.email_x12_minutes_charge_analytics_flow()

    assert rc == 0
    meta = captured["extra_meta"]
    assert captured["include_traceback"] is False
    assert meta["bundle_kind"] == "x12_minutes_charge_analytics"
    assert meta["x12_minutes_charge_workflow_boundary"] == "report_only_review_required"
    assert meta["x12_minutes_charge_claim_workflow_completion"] is False
    assert meta["x12_minutes_charge_mutates_billing_state"] is False
    assert meta["x12_minutes_charge_mutates_dat"] is False
    assert meta["x12_minutes_charge_mutates_837p"] is False
    assert meta["x12_minutes_charge_charges_entered"] is False
    assert meta["x12_minutes_charge_files_scanned"] == 1
    assert meta["x12_minutes_charge_total_claims"] == 1
    assert meta["x12_minutes_charge_total_service_lines"] == 1
    assert meta["x12_minutes_charge_service_lines_with_observation"] == 1
    assert meta["x12_minutes_charge_total_observations"] == 1
    assert captured["submit_kwargs"]["skip_interactive_reauth"] is True
    assert captured["submit_kwargs"]["include_traceback"] is False
    assert [name for name, _path in captured["extra_files"]] == [
        "x12_minutes_charge_summary.json",
        "x12_minutes_charge_summary.txt",
        "x12_minutes_charge_rows.jsonl",
        "x12_minutes_charge_groups.jsonl",
        "x12_minutes_charge_model_eval.json",
    ]
    assert meta["x12_minutes_charge_operational_charge_update"] is False
    assert meta["x12_minutes_charge_validation_mode"] == assoc.VALIDATION_MODE_HISTORICAL_837P
    assert meta["x12_minutes_charge_historical_out_of_custody_expected"] is True
    assert meta["x12_minutes_charge_custody_required_for_stage2b_validation"] is False

    meta_text = json.dumps(meta, sort_keys=True)
    assert str(claims) not in meta_text
    assert str(outbox) not in meta_text
    assert str(claim_path) not in meta_text

    identity = {
        "analytics_run_id": meta["x12_minutes_charge_run_id"],
        "bundle_kind": "x12_minutes_charge_analytics",
    }
    assert_workflow_boundary_clean(
        "x12_minutes_charge_support_bundle_boundary",
        identity,
        [
            {
                "name": "analytics_report_generation",
                "role": "attempt",
                "identity": identity,
                "status": "completed",
                "classification": "review_required",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
            {
                "name": "support_bundle_metadata",
                "role": "package",
                "identity": identity,
                "status": "completed",
                "classification": "review_required",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
            {
                "name": "support_email_delivery",
                "role": "support_send",
                "identity": identity,
                "status": "completed",
                "classification": "review_required",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
        ],
    )


def test_email_flow_code_one_writes_self_test_diagnostic_breadcrumb(tmp_path, monkeypatch):
    from MediCafe import error_reporter

    storage = tmp_path / "storage"

    def fake_runtime_context():
        return {
            "config": {},
            "medi": {
                "local_storage_path": str(storage),
                "local_claims_path": "",
                "outputFilePath": "",
            },
            "diagnostics": {},
        }

    def fail_collect_support_bundle(**kwargs):
        raise AssertionError("bundle collection should not run without scan roots")

    monkeypatch.setattr(error_reporter, "_get_error_reporter_runtime_context", fake_runtime_context)
    monkeypatch.setattr(error_reporter, "collect_support_bundle", fail_collect_support_bundle)

    rc = error_reporter.email_x12_minutes_charge_analytics_flow()

    assert rc == 1
    diag_path = storage / "reports" / "x12_minutes_charge_review_latest.json"
    assert diag_path.exists()
    diag = json.loads(diag_path.read_text(encoding="utf-8"))
    diag_text = json.dumps(diag, sort_keys=True)
    assert diag["status"] == "failed"
    assert diag["stage"] == "resolve_scan_roots"
    assert diag["reason_code"] == "no_saved_claim_file_locations_configured"
    assert diag["exit_code"] == 1
    assert diag["workflow_boundary"] == "report_only_review_required"
    assert diag["claim_workflow_completion"] is False
    assert str(tmp_path) not in diag_text


def test_self_test_bundle_attaches_latest_minutes_charge_failure_diagnostic(tmp_path, monkeypatch):
    from MediCafe import error_reporter

    storage = tmp_path / "storage"
    reports = storage / "reports"
    reports.mkdir(parents=True)
    diag_path = reports / "x12_minutes_charge_review_latest.json"
    diag_path.write_text(json.dumps({
        "schema_version": 1,
        "status": "failed",
        "stage": "resolve_scan_roots",
        "reason_code": "no_saved_claim_file_locations_configured",
    }), encoding="utf-8")

    captured = {}

    def fake_runtime_context():
        return {
            "config": {"MediLink_Config": {"local_storage_path": str(storage)}},
            "medi": {
                "local_storage_path": str(storage),
                "logging": {},
                "error_reporting": {"email": {}},
            },
            "diagnostics": {},
        }

    def fake_build_support_zip(zip_path, local_storage_path, max_log_lines, traceback_text,
                               include_winscp, meta, claim_failure_summary=None,
                               extra_files=None, **kwargs):
        captured["zip_path"] = zip_path
        captured["extra_files"] = list(extra_files or [])
        captured["meta"] = dict(meta or {})
        return True

    monkeypatch.setattr(error_reporter, "_get_error_reporter_runtime_context", fake_runtime_context)
    monkeypatch.setattr(error_reporter, "_build_support_zip", fake_build_support_zip)

    zip_path = error_reporter.collect_test_support_bundle()

    assert zip_path == captured["zip_path"]
    names = [name for name, _value in captured["extra_files"]]
    assert "x12_minutes_charge_review_latest.json" in names
    attached = dict(captured["extra_files"])["x12_minutes_charge_review_latest.json"]
    assert attached == str(diag_path)
    assert captured["meta"]["bundle_kind"] == "test"


def test_error_reporter_can_load_minutes_charge_script_by_file_path(tmp_path):
    from MediCafe import error_reporter

    script_path = tmp_path / "run_x12_minutes_charge_association.py"
    script_path.write_text(
        "def marker_for_path_load():\n"
        "    return 'loaded'\n",
        encoding="utf-8",
    )

    mod = error_reporter._load_x12_minutes_charge_script_from_path(
        "_test_x12_minutes_charge_path_load",
        str(script_path),
    )

    assert mod.marker_for_path_load() == "loaded"


def test_minutes_charge_review_command_is_reporting_boundary_not_local_claim_workflow():
    from MediCafe import launcher

    assert "send_minutes_charge_review" not in launcher._LOCAL_WORKFLOW_COMMANDS
    assert_workflow_boundary_clean(
        "x12_minutes_charge_launcher_reporting_boundary",
        {"command": "send_minutes_charge_review"},
        [
            {
                "name": "troubleshooting_menu_action",
                "role": "operator_request",
                "identity": {"command": "send_minutes_charge_review"},
                "status": "started",
                "classification": "in_flight",
                "terminal": False,
                "accepted": False,
                "claims_completion": False,
            },
            {
                "name": "medicafe_cli_reporting_command",
                "role": "subprocess",
                "identity": {"command": "send_minutes_charge_review"},
                "status": "completed",
                "classification": "review_required",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
        ],
    )
