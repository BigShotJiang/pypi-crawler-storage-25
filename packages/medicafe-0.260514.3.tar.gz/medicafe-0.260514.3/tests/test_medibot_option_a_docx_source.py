#!/usr/bin/env python
from __future__ import print_function

import importlib.util
import builtins
import inspect
import json
import os
import sys

from workflow_boundary_contract import assert_workflow_boundary_clean


_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_medibot_script_module():
    medibot_dir = os.path.join(_PROJECT_ROOT, "MediBot")
    if medibot_dir not in sys.path:
        sys.path.insert(0, medibot_dir)
    module_path = os.path.join(medibot_dir, "MediBot.py")
    spec = importlib.util.spec_from_file_location("medibot_script_for_option_a_docx_source_test", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _entry(date_value, name, patient_id, diagnosis):
    return (date_value, name, patient_id, diagnosis, {"Patient ID": patient_id})


def test_option_a_preview_entries_use_single_docx_dos_and_schedule_order(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    new_patient_info = [
        _entry("01-20-2026", "CSV One", "1", "CSV1"),
        _entry("01-21-2026", "CSV Other DOS", "2", "CSV2"),
        _entry("01-20-2026", "CSV Three", "3", "CSV3"),
        _entry("01-20-2026", "CSV Two", "2", "CSV2"),
    ]
    index_data = {
        "schedules": {
            "01-20-2026": {
                "current": {
                    "patients": {
                        "3": {"diagnosis": "DOCX3", "position": 30},
                        "1": {"diagnosis": "DOCX1", "position": 10},
                        "2": {"diagnosis": "DOCX2", "position": 20},
                        "9": {"diagnosis": "DOCX9", "position": 5},
                    }
                }
            }
        }
    }

    monkeypatch.setattr(medibot_script, "load_docx_schedule_index", lambda local_storage_path: index_data)
    monkeypatch.setattr(
        medibot_script,
        "get_schedules_for_dates",
        lambda data, dates: {"01-20-2026": data["schedules"]["01-20-2026"]["current"]},
    )

    preview_entries, preview_dos = medibot_script.build_option_a_preview_entries_from_docx_index(
        new_patient_info,
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert preview_dos == "01-20-2026"
    assert [entry[2] for entry in preview_entries] == ["9", "1", "2", "3"]
    assert [entry[1] for entry in preview_entries] == [
        "Patient ID 9",
        "CSV One",
        "CSV Two",
        "CSV Three",
    ]
    assert [entry[3] for entry in preview_entries] == ["DOCX9", "DOCX1", "DOCX2", "DOCX3"]


def test_option_a_preview_entries_fall_back_when_docx_index_missing(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    monkeypatch.setattr(medibot_script, "load_docx_schedule_index", lambda local_storage_path: {})
    monkeypatch.setattr(medibot_script, "get_schedules_for_dates", lambda data, dates: {})

    preview_entries, preview_dos = medibot_script.build_option_a_preview_entries_from_docx_index(
        [_entry("01-20-2026", "CSV One", "1", "CSV1")],
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert preview_entries is None
    assert preview_dos is None


def test_service_line_input_hydrates_same_patient_prior_dos_charge_anchor(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    status = {
        "version": 1,
        "schema_version": "service_line_input_state.v1",
        "workflow_name": "service_line_input",
        "rows": {
            "1|01-20-2026": {
                "patient_id": "1",
                "dos": "01-20-2026",
                "status": "entered",
                "minutes": "42",
                "charge_display": "$580",
                "charge_amount": "580.00",
                "workflow_boundary": "preview_only_review_required",
                "claims_completion": False,
                "mutates_billing_state": False,
            }
        },
    }
    (tmp_path / medibot_script.SERVICE_LINE_INPUT_STATE_FILENAME).write_text(
        json.dumps(status),
        encoding="utf-8",
    )
    index_data = {
        "schedules": {
            "01-21-2026": {
                "current": {
                    "patients": {
                        "1": {"diagnosis": "DOCX1", "position": 5},
                    }
                }
            }
        }
    }

    monkeypatch.setattr(medibot_script, "load_docx_schedule_index", lambda local_storage_path: index_data)
    monkeypatch.setattr(
        medibot_script,
        "get_schedules_for_dates",
        lambda data, dates: {"01-21-2026": data["schedules"]["01-21-2026"]["current"]},
    )

    groups = medibot_script.build_service_line_input_dos_groups_from_docx_index(
        [_entry("01-21-2026", "CSV One", "1", "CSV1")],
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    payload = groups[0]["entries"][0][4]
    assert payload["_service_line_input_same_patient_anchor_charge_amount"] == "580.00"
    assert payload["_service_line_input_same_patient_anchor_charge_display"] == "$580"
    assert payload["_service_line_input_same_patient_anchor_charge_rule_id"] == "same_patient_dos_anchor"
    assert "01-20-2026" in payload["_service_line_input_same_patient_anchor_charge_note"]


def test_option_a_preview_entries_tag_unknown_docx_diagnosis_auto_cancel(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    index_data = {
        "schedules": {
            "01-20-2026": {
                "current": {
                    "patients": {
                        "1": {"diagnosis": "Unknown", "position": 10},
                        "2": {"diagnosis": "Not Found", "position": 20},
                        "3": {"diagnosis": "DOCX3", "position": 30},
                    }
                }
            }
        }
    }

    monkeypatch.setattr(medibot_script, "load_docx_schedule_index", lambda local_storage_path: index_data)
    monkeypatch.setattr(
        medibot_script,
        "get_schedules_for_dates",
        lambda data, dates: {"01-20-2026": data["schedules"]["01-20-2026"]["current"]},
    )

    preview_entries, preview_dos = medibot_script.build_option_a_preview_entries_from_docx_index(
        [
            _entry("01-20-2026", "CSV One", "1", "CSV1"),
            _entry("01-20-2026", "CSV Two", "2", "CSV2"),
            _entry("01-20-2026", "CSV Three", "3", "CSV3"),
        ],
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert preview_dos == "01-20-2026"
    assert preview_entries[0][3] == "Unknown"
    assert preview_entries[0][4]["_option_a_preview_status"] == "CANCELLED"
    assert preview_entries[0][4]["_option_a_preview_status_reason"] == "docx_diagnosis_unknown"
    assert preview_entries[1][3] == "Not Found"
    assert preview_entries[1][4]["_option_a_preview_status"] == "CANCELLED"
    assert "_option_a_preview_status" not in preview_entries[2][4]


def test_option_a_preview_groups_multiple_docx_dos_values_for_current_session(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    log_events = []
    new_patient_info = [
        _entry("01-21-2026", "Upstream Three", "3", "CSV3"),
        _entry("01-20-2026", "Upstream Two", "2", "CSV2"),
        _entry("01-20-2026", "Upstream One", "1", "CSV1"),
        _entry("01-22-2026", "Historical Missing", "9", "CSV9"),
    ]
    index_data = {
        "schedules": {
            "01-20-2026": {
                "current": {
                    "patients": {
                        "7": {"diagnosis": "DOCX7", "position": 5},
                        "2": {"diagnosis": "DOCX2", "position": 20},
                        "1": {"diagnosis": "DOCX1", "position": 10},
                    }
                }
            },
            "01-21-2026": {
                "current": {
                    "patients": {
                        "3": {"diagnosis": "DOCX3", "position": 5},
                    }
                }
            },
        }
    }

    monkeypatch.setattr(medibot_script, "load_docx_schedule_index", lambda local_storage_path: index_data)
    monkeypatch.setattr(
        medibot_script.MediLink_ConfigLoader,
        "log",
        lambda message, level="INFO", **kwargs: log_events.append((level, message)),
    )
    monkeypatch.setattr(
        medibot_script,
        "get_schedules_for_dates",
        lambda data, dates: {
            key: value["current"]
            for key, value in data["schedules"].items()
            if key in dates
        },
    )

    groups = medibot_script.build_option_a_preview_dos_groups_from_docx_index(
        new_patient_info,
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert [group["dos"] for group in groups] == ["01-20-2026", "01-21-2026"]
    assert [entry[2] for entry in groups[0]["entries"]] == ["7", "1", "2"]
    assert [entry[1] for entry in groups[0]["entries"]] == [
        "Patient ID 7",
        "Upstream One",
        "Upstream Two",
    ]
    assert [entry[3] for entry in groups[0]["entries"]] == ["DOCX7", "DOCX1", "DOCX2"]
    assert groups[0]["entries"][0][4]["_option_a_preview_source"]["docx_position"] == 5
    assert [entry[2] for entry in groups[1]["entries"]] == ["3"]
    assert any(
        level == "WARNING"
        and "no matching preprocessed patient name" in message
        and "patient_id=7" in message
        and "dos=01-20-2026" in message
        for level, message in log_events
    )


def test_option_a_session_scope_uses_full_preprocessed_rows_before_triage_filters():
    medibot_script = _load_medibot_script_module()
    reverse_mapping = {
        "Patient ID #2": "Patient ID",
        "Patient Name": "Patient Name",
    }
    rows = [
        {
            "Patient ID": "1",
            "Patient Name": "Medicare Existing",
            "Surgery Date": "01-20-2026",
            "_all_surgery_dates": ["01-20-2026", "01-21-2026"],
            "_surgery_date_to_diagnosis": {
                "01-20-2026": "CSV1A",
                "01-21-2026": "CSV1B",
            },
        },
        {
            "Patient ID": "2",
            "Patient Name": "Private New",
            "Surgery Date": "01-20-2026",
            "_all_surgery_dates": ["01-20-2026"],
            "_surgery_date_to_diagnosis": {"01-20-2026": "CSV2"},
        },
    ]

    entries = medibot_script.build_option_a_preview_session_patient_info_from_csv_rows(
        rows,
        reverse_mapping,
    )

    assert [entry[2] for entry in entries] == ["1", "1", "2"]
    assert [entry[1] for entry in entries] == [
        "Medicare Existing",
        "Medicare Existing",
        "Private New",
    ]
    assert [medibot_script._normalize_option_a_preview_date(entry[0]) for entry in entries] == [
        "01-20-2026",
        "01-21-2026",
        "01-20-2026",
    ]


def test_option_a_printed_docx_scope_intentionally_outlives_ahk_triage_selection(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    reverse_mapping = {
        "Patient ID #2": "Patient ID",
        "Patient Name": "Patient Name",
    }
    preprocessed_session_rows = [
        {
            "Patient ID": "1",
            "Patient Name": "Medicare Existing",
            "Surgery Date": "01-20-2026",
            "_all_surgery_dates": ["01-20-2026"],
            "_surgery_date_to_diagnosis": {"01-20-2026": "CSV1"},
        },
        {
            "Patient ID": "2",
            "Patient Name": "Private New",
            "Surgery Date": "01-20-2026",
            "_all_surgery_dates": ["01-20-2026"],
            "_surgery_date_to_diagnosis": {"01-20-2026": "CSV2"},
        },
    ]
    # AHK intake may later narrow to only patient 2, but Option A is a
    # printed-DOCX companion. It should still show patient 1 when the DOCX
    # schedule for the current CSV session includes that row.
    ahk_selected_patient_ids = ["2"]
    index_data = {
        "schedules": {
            "01-20-2026": {
                "current": {
                    "patients": {
                        "1": {"diagnosis": "DOCX1", "position": 10},
                        "2": {"diagnosis": "DOCX2", "position": 20},
                    }
                }
            }
        }
    }

    monkeypatch.setattr(medibot_script, "load_docx_schedule_index", lambda local_storage_path: index_data)
    monkeypatch.setattr(
        medibot_script,
        "get_schedules_for_dates",
        lambda data, dates: {"01-20-2026": data["schedules"]["01-20-2026"]["current"]},
    )

    option_a_scope = medibot_script.build_option_a_preview_session_patient_info_from_csv_rows(
        preprocessed_session_rows,
        reverse_mapping,
    )
    groups = medibot_script.build_option_a_preview_dos_groups_from_docx_index(
        option_a_scope,
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert ahk_selected_patient_ids == ["2"]
    assert [entry[2] for entry in groups[0]["entries"]] == ["1", "2"]
    assert [entry[1] for entry in groups[0]["entries"]] == ["Medicare Existing", "Private New"]


def test_option_a_multi_dos_controller_prompts_between_dos_and_persists(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    calls = []
    inputs = [""]

    def fake_input(prompt=""):
        if not inputs:
            raise AssertionError("unexpected prompt: {}".format(prompt))
        return inputs.pop(0)

    def fake_preview(entries, date_of_service_label=None, charge_calculator=None):
        calls.append((date_of_service_label, list(entries)))
        row = entries[0]
        return {
            "entered": 1,
            "skipped": 0,
            "cancelled": 0,
            "rows": [{
                "patient_id": row[2],
                "date": date_of_service_label,
                "name": row[1],
                "diagnosis": row[3],
                "cpt": "00142",
                "minutes": "12",
                "status": "ENTERED",
                "charge_display": "$450",
                "charge_amount": "450.00",
                "charge_note": "baseline 5-15",
                "charge_rule_id": "baseline_5_15",
                "charge_status": "calculated",
                "charge_schema_version": "charges_tool.v1",
                "charge_source": "baseline_minutes_tier",
                "workflow_boundary": "preview_only_review_required",
                "claims_completion": False,
                "mutates_billing_state": False,
                "billable": True,
                "requires_operator_review": True,
                "source": row[4]["_option_a_preview_source"],
            }],
        }

    monkeypatch.setattr(builtins, "input", fake_input)
    monkeypatch.setattr(medibot_script.MediBot_UI, "run_service_line_input_entry", fake_preview)
    monkeypatch.setattr(
        medibot_script,
        "build_service_line_input_dos_groups_from_docx_index",
        lambda new_patient_info, config: [
            {"dos": "01-20-2026", "entries": [
                ("01-20-2026", "Upstream One", "1", "DOCX1", {
                    "_option_a_preview_source": {
                        "patient_id": "1",
                        "dos": "01-20-2026",
                        "docx_diagnosis": "DOCX1",
                        "docx_position": 10,
                    }
                })
            ]},
            {"dos": "01-21-2026", "entries": [
                ("01-21-2026", "Upstream Two", "2", "DOCX2", {
                    "_option_a_preview_source": {
                        "patient_id": "2",
                        "dos": "01-21-2026",
                        "docx_diagnosis": "DOCX2",
                        "docx_position": 20,
                    }
                })
            ]},
        ],
    )

    result = medibot_script.run_option_a_multi_dos_minutes_preview(
        [_entry("01-20-2026", "Upstream One", "1", "CSV1")],
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert [call[0] for call in calls] == ["01-20-2026", "01-21-2026"]
    assert result["service_line_input_session_id"].startswith("service_line_input_")
    assert result["option_a_session_id"] == result["service_line_input_session_id"]
    assert result["dos_total"] == 2
    assert result["dos_completed"] == 2
    service_line_status_path = tmp_path / medibot_script.SERVICE_LINE_INPUT_STATE_FILENAME
    assert service_line_status_path.exists()
    service_line_status = json.loads(service_line_status_path.read_text(encoding="utf-8"))
    assert service_line_status["schema_version"] == "service_line_input_state.v1"
    assert service_line_status["workflow_name"] == "service_line_input"
    status_path = tmp_path / medibot_script.OPTION_A_MINUTES_STATUS_FILENAME
    assert status_path.exists()
    status = json.loads(status_path.read_text(encoding="utf-8"))
    assert status["rows"]["1|01-20-2026"]["status"] == "entered"
    assert status["rows"]["1|01-20-2026"]["minutes"] == "12"
    assert status["rows"]["1|01-20-2026"]["service_line_input_session_id"] == result["service_line_input_session_id"]
    assert status["rows"]["1|01-20-2026"]["option_a_session_id"] == result["service_line_input_session_id"]
    assert service_line_status["rows"]["1|01-20-2026"]["status"] == "entered"
    assert service_line_status["rows"]["1|01-20-2026"]["legacy_row_key"] == "1|01-20-2026"
    assert service_line_status["rows"]["1|01-20-2026"]["service_line_row_key"] == "1|01-20-2026|anesthesia|10"
    assert service_line_status["rows"]["1|01-20-2026"]["target_identity"] == {
        "patient_id": "1",
        "dos": "01-20-2026",
        "service_line_kind": "anesthesia",
        "line_ordinal": 10,
        "docx_position": 10,
    }
    assert len(service_line_status["events"]) >= 2
    assert service_line_status["events"][0]["workflow_boundary"] == "preview_only_review_required"
    assert service_line_status["events"][0]["claims_completion"] is False
    assert service_line_status["events"][0]["mutates_dat"] is False
    assert service_line_status["events"][0]["mutates_837p"] is False
    assert status["rows"]["1|01-20-2026"]["charge_display"] == "$450"
    assert status["rows"]["1|01-20-2026"].get("charge_note", "") == ""
    assert status["rows"]["1|01-20-2026"]["charge_rule_id"] == "baseline_5_15"
    assert status["rows"]["1|01-20-2026"]["charge_schema_version"] == "charges_tool.v1"
    assert status["rows"]["1|01-20-2026"]["charge_source"] == "baseline_minutes_tier"
    assert status["rows"]["1|01-20-2026"]["workflow_boundary"] == "preview_only_review_required"
    assert status["rows"]["1|01-20-2026"]["claims_completion"] is False
    assert status["rows"]["1|01-20-2026"]["mutates_billing_state"] is False
    assert status["rows"]["1|01-20-2026"]["billable"] is True
    assert status["rows"]["1|01-20-2026"]["requires_operator_review"] is True
    assert status["rows"]["1|01-20-2026"]["cpt"] == "00142"
    assert status["rows"]["2|01-21-2026"]["status"] == "entered"
    artifact_paths = result["artifact_paths"]
    assert artifact_paths["candidate_json"]
    assert artifact_paths["candidate_txt"]
    assert os.path.exists(artifact_paths["candidate_json"])
    candidate = json.loads(open(artifact_paths["candidate_json"], "r").read())
    assert candidate["schema_version"] == "service_line_input_candidate_package.v1"
    assert candidate["workflow_boundary"] == "preview_only_review_required"
    assert candidate["claims_completion"] is False
    assert candidate["cleanup_readiness"]["cleanup_readiness"] == "not_ready"
    assert candidate["cleanup_readiness"]["legacy_marker_count"] >= 1
    assert result["review_completion"]["candidate_json"] == artifact_paths["candidate_json"]
    assert result["review_completion"]["cleanup_readiness"] == "not_ready"


def test_service_line_input_new_entrypoints_match_legacy_option_a_wrappers(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    groups = [{"dos": "01-20-2026", "entries": [
        ("01-20-2026", "Upstream One", "1", "DOCX1", {
            "_service_line_input_source": {
                "patient_id": "1",
                "dos": "01-20-2026",
                "docx_diagnosis": "DOCX1",
                "docx_position": 10,
            }
        })
    ]}]

    monkeypatch.setattr(
        medibot_script,
        "build_option_a_preview_dos_groups_from_docx_index",
        lambda new_patient_info, config: groups,
    )

    assert medibot_script.build_service_line_input_dos_groups_from_docx_index([], {}) == groups

    summary = {
        "rows": [{
            "patient_id": "1",
            "date": "01-20-2026",
            "diagnosis": "DOCX1",
            "diagnosis_source": "operator_overlay",
            "validation_status": "review_required",
            "validation_note": "diagnosis edited in Service Line Input",
            "minutes": "12",
            "status": "ENTERED",
            "workflow_boundary": "operational_charge_entry",
            "claims_completion": True,
            "mutates_billing_state": True,
            "source": {
                "patient_id": "1",
                "dos": "01-20-2026",
                "docx_diagnosis": "DOCX1",
                "docx_position": 10,
            },
        }]
    }

    assert medibot_script.persist_service_line_input_summary(
        str(tmp_path),
        "service_line_input_test",
        "01-20-2026",
        summary,
    )
    loaded = medibot_script._load_option_a_minutes_status(str(tmp_path))
    row = loaded["rows"]["1|01-20-2026"]
    assert row["status"] == "entered"
    assert row["diagnosis"] == "DOCX1"
    assert row["diagnosis_code"] == "DOCX1"
    assert row["diagnosis_source"] == "operator_overlay"
    assert row["validation_status"] == "review_required"
    assert row["workflow_name"] == "service_line_input"
    assert row["workflow_boundary"] == "preview_only_review_required"
    assert row["claims_completion"] is False
    assert row["mutates_billing_state"] is False


def test_service_line_input_suggests_cpt_from_diagnosis_to_procedure_preview_only(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    calls = []

    def fake_preview(entries, date_of_service_label=None, charge_calculator=None):
        row = entries[0]
        result = charge_calculator({
            "patient_id": row[2],
            "dos": date_of_service_label,
            "diagnosis": row[3],
            "cpt": "",
            "minutes": "12",
            "status": "ENTERED",
            "source": row[4]["_service_line_input_source"],
        })
        calls.append(result)
        return {
            "entered": 1,
            "skipped": 0,
            "cancelled": 0,
            "rows": [{
                "patient_id": row[2],
                "date": date_of_service_label,
                "name": row[1],
                "diagnosis": row[3],
                "cpt": result.get("cpt"),
                "cpt_source": result.get("cpt_source"),
                "cpt_confidence": result.get("cpt_confidence"),
                "cpt_status": result.get("cpt_status"),
                "minutes": "12",
                "status": "ENTERED",
                "charge_display": result.get("charge_display"),
                "charge_amount": result.get("charge_amount"),
                "charge_note": result.get("charge_note"),
                "charge_rule_id": result.get("charge_rule_id"),
                "charge_status": result.get("charge_status"),
                "workflow_name": result.get("workflow_name"),
                "workflow_boundary": result.get("workflow_boundary"),
                "claims_completion": result.get("claims_completion"),
                "mutates_billing_state": result.get("mutates_billing_state"),
                "billable": result.get("billable"),
                "requires_operator_review": result.get("requires_operator_review"),
                "source": row[4]["_service_line_input_source"],
            }],
        }

    monkeypatch.setattr(medibot_script.MediBot_UI, "run_service_line_input_entry", fake_preview)
    monkeypatch.setattr(
        medibot_script,
        "build_service_line_input_dos_groups_from_docx_index",
        lambda new_patient_info, config: [
            {"dos": "01-20-2026", "entries": [
                ("01-20-2026", "One", "1", "25811", {
                    "_service_line_input_source": {
                        "patient_id": "1",
                        "dos": "01-20-2026",
                        "docx_diagnosis": "25811",
                        "docx_position": 1,
                    }
                })
            ]}
        ],
    )

    result = medibot_script.run_service_line_input_multi_dos_entry(
        [_entry("01-20-2026", "One", "1", "25811")],
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
        crosswalk={
            "diagnosis_to_medisoft": {"H25.811": "25811"},
            "diagnosis_to_procedure": {"H25.811": "00142"},
        },
    )

    assert result["service_line_input_session_id"].startswith("service_line_input_")
    assert calls[0]["cpt"] == "00142"
    assert calls[0]["cpt_source"] == "crosswalk.diagnosis_to_procedure"
    assert calls[0]["workflow_boundary"] == "preview_only_review_required"
    assert calls[0]["claims_completion"] is False
    assert calls[0]["mutates_billing_state"] is False
    state = json.loads((tmp_path / medibot_script.SERVICE_LINE_INPUT_STATE_FILENAME).read_text(encoding="utf-8"))
    state_row = state["rows"]["1|01-20-2026"]
    assert state_row["workflow_name"] == "service_line_input"
    assert state_row["cpt"] == "00142"
    assert state_row["cpt_source"] == "crosswalk.diagnosis_to_procedure"
    assert state_row["cpt_confidence"] == "crosswalk_confirmed"
    assert state_row["cpt_status"] == "suggested"
    assert state_row["claims_completion"] is False
    assert state_row["mutates_billing_state"] is False
    assert state_row["charges_entered"] is False
    assert "claim_submitted" not in state_row
    assert "dat_mutation" not in state_row
    assert "x12_837p_mutation" not in state_row


def test_service_line_input_option_sets_include_unambiguous_diagnosis_display_bridge():
    medibot_script = _load_medibot_script_module()

    option_sets = medibot_script._service_line_input_option_sets_from_crosswalk({
        "diagnosis_to_medisoft": {
            "H25.812": "25812",
            "H25.811": "25811",
        },
        "diagnosis_to_procedure": {
            "H25.812": "00142",
        },
    })

    assert "25812" in option_sets["diagnosis_options"]
    assert "H25.812" in option_sets["diagnosis_options"]
    assert option_sets["diagnosis_display_map"]["25812"] == "H25.812"
    assert option_sets["diagnosis_display_map"]["H25812"] == "H25.812"


def test_service_line_input_option_sets_do_not_display_ambiguous_medisoft_bridge():
    medibot_script = _load_medibot_script_module()

    option_sets = medibot_script._service_line_input_option_sets_from_crosswalk({
        "diagnosis_to_medisoft": {
            "H25.811": "25811",
            "H25.812": "25811",
        },
    })

    assert "25811" in option_sets["diagnosis_options"]
    assert option_sets["diagnosis_display_map"]["H25811"] == "H25.811"
    assert option_sets["diagnosis_display_map"]["H25812"] == "H25.812"
    assert "25811" not in option_sets["diagnosis_display_map"]


def test_service_line_input_crosswalk_intake_handler_updates_config_only(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    import MediBot.MediBot_Crosswalk_Utils as crosswalk_utils

    saved = []

    def fake_save_crosswalk(client, config, crosswalk, skip_api_operations=False, api_cache=None):
        saved.append({
            "config": config,
            "crosswalk": json.loads(json.dumps(crosswalk)),
            "skip_api_operations": skip_api_operations,
        })
        return True

    inputs = ["", "00140", "y"]

    def fake_input(prompt=""):
        if not inputs:
            raise AssertionError("unexpected intake prompt: {}".format(prompt))
        return inputs.pop(0)

    monkeypatch.setattr(builtins, "input", fake_input)
    monkeypatch.setattr(crosswalk_utils, "save_crosswalk", fake_save_crosswalk)

    crosswalk = {
        "diagnosis_to_medisoft": {},
        "diagnosis_to_procedure": {},
        "procedure_to_diagnosis": {},
    }
    option_sets = medibot_script._service_line_input_option_sets_from_crosswalk(crosswalk)
    handler = medibot_script._service_line_input_crosswalk_intake_handler(
        {"MediLink_Config": {"local_storage_path": str(tmp_path), "endpoints": []}},
        crosswalk,
        option_sets,
    )
    option_sets["crosswalk_intake_handler"] = handler

    result = handler(
        {
            "patient_id": "1",
            "date": "01-20-2026",
            "diagnosis": "H25.812",
            "cpt": "",
        },
        "diagnosis",
        "H26.101",
    )

    assert result["ok"] is True
    assert saved and saved[0]["skip_api_operations"] is True
    assert crosswalk["diagnosis_to_medisoft"]["H26.101"] == "26101"
    assert crosswalk["diagnosis_to_procedure"]["H26.101"] == "00140"
    assert "H26.101" in crosswalk["procedure_to_diagnosis"]["00140"]
    assert option_sets["crosswalk_intake_handler"] is handler
    assert option_sets["diagnosis_display_map"]["26101"] == "H26.101"
    assert result["row_updates"]["diagnosis"] == "H26.101"
    assert result["row_updates"]["diagnosis_raw_value"] == "H26.101"
    assert result["row_updates"]["cpt"] == "00140"
    event = result["crosswalk_intake_events"][0]
    assert event["workflow_boundary"] == "confirmed_config_update"
    assert event["apply_report"]["schema_version"] == "service_line_input_crosswalk_intake_save.v1"
    assert event["apply_report"]["save_ok"] is True
    assert event["apply_report"]["patch_sha256"]
    assert event["apply_report"]["changed_map_names"] == [
        "diagnosis_to_medisoft",
        "diagnosis_to_procedure",
        "procedure_to_diagnosis",
    ]
    assert event["claims_completion"] is False
    assert event["mutates_dat"] is False
    assert event["mutates_837p"] is False
    assert event["charges_entered"] is False


def test_service_line_input_crosswalk_intake_wrapper_saves_with_audit_metadata(tmp_path):
    from MediCafe import service_line_input_model as model
    import MediBot.MediBot_Crosswalk_Utils as crosswalk_utils

    saved = []

    def fake_save_crosswalk(client, config, crosswalk, skip_api_operations=False, api_cache=None):
        saved.append({
            "crosswalk": json.loads(json.dumps(crosswalk)),
            "skip_api_operations": skip_api_operations,
        })
        return True

    crosswalk = {
        "diagnosis_to_medisoft": {},
        "diagnosis_to_procedure": {},
        "procedure_to_diagnosis": {},
    }
    patch = model.build_service_line_crosswalk_intake_patch(
        crosswalk,
        "H26.101",
        "26101",
        "00140",
        source={"typed_value": "H26.101", "patient_name": "SHOULD_DROP"},
    )
    merged, report = crosswalk_utils.save_service_line_input_crosswalk_intake_patch(
        {"MediLink_Config": {"local_storage_path": str(tmp_path), "endpoints": []}},
        crosswalk,
        patch,
        row_target_identity={"patient_id": "1", "dos": "01-20-2026"},
        save_fn=fake_save_crosswalk,
    )

    assert saved and saved[0]["skip_api_operations"] is True
    assert merged["diagnosis_to_medisoft"]["H26.101"] == "26101"
    assert crosswalk["diagnosis_to_procedure"]["H26.101"] == "00140"
    assert report["schema_version"] == "service_line_input_crosswalk_intake_save.v1"
    assert report["workflow_boundary"] == "confirmed_config_update"
    assert report["save_ok"] is True
    assert report["changed"] is True
    assert len(report["patch_sha256"]) == 64
    assert report["changed_map_names"] == [
        "diagnosis_to_medisoft",
        "diagnosis_to_procedure",
        "procedure_to_diagnosis",
    ]
    assert "H26.101" in report["changed_keys"]
    assert "00140" in report["changed_keys"]
    assert report["target_identity"] == {"patient_id": "1", "dos": "01-20-2026"}
    assert report["claims_completion"] is False
    assert report["mutates_dat"] is False
    assert report["mutates_837p"] is False
    assert "patient_name" not in json.dumps(report)

    telemetry_path = tmp_path / "telemetry" / "service_line_input_crosswalk_intake_events.jsonl"
    assert telemetry_path.exists()
    line = telemetry_path.read_text(encoding="utf-8").strip()
    assert "service_line_input_crosswalk_intake_save.v1" in line
    assert "SHOULD_DROP" not in line


def test_service_line_input_crosswalk_intake_wrapper_fail_closed_on_save_failure(tmp_path):
    from MediCafe import service_line_input_model as model
    import MediBot.MediBot_Crosswalk_Utils as crosswalk_utils

    def failing_save_crosswalk(client, config, crosswalk, skip_api_operations=False, api_cache=None):
        return False

    crosswalk = {
        "diagnosis_to_medisoft": {},
        "diagnosis_to_procedure": {},
        "procedure_to_diagnosis": {},
    }
    patch = model.build_service_line_crosswalk_intake_patch(
        crosswalk,
        "H26.101",
        "26101",
        "00140",
    )
    merged, report = crosswalk_utils.save_service_line_input_crosswalk_intake_patch(
        {"MediLink_Config": {"local_storage_path": str(tmp_path), "endpoints": []}},
        crosswalk,
        patch,
        row_target_identity={"patient_id": "1", "dos": "01-20-2026"},
        save_fn=failing_save_crosswalk,
    )

    assert report["save_ok"] is False
    assert report["save_error"] == "save_crosswalk_returned_false"
    assert crosswalk["diagnosis_to_medisoft"] == {}
    assert merged["diagnosis_to_medisoft"] == {}
    assert report["claims_completion"] is False
    assert report["mutates_837p"] is False


def test_service_line_input_crosswalk_intake_wrapper_fail_closed_on_save_exception(tmp_path):
    from MediCafe import service_line_input_model as model
    import MediBot.MediBot_Crosswalk_Utils as crosswalk_utils

    def exploding_save_crosswalk(client, config, crosswalk, skip_api_operations=False, api_cache=None):
        raise RuntimeError("simulated write failure")

    crosswalk = {
        "diagnosis_to_medisoft": {},
        "diagnosis_to_procedure": {},
        "procedure_to_diagnosis": {},
    }
    patch = model.build_service_line_crosswalk_intake_patch(
        crosswalk,
        "H26.101",
        "26101",
        "00140",
    )
    merged, report = crosswalk_utils.save_service_line_input_crosswalk_intake_patch(
        {"MediLink_Config": {"local_storage_path": str(tmp_path), "endpoints": []}},
        crosswalk,
        patch,
        row_target_identity={"patient_id": "1", "dos": "01-20-2026"},
        save_fn=exploding_save_crosswalk,
    )

    assert report["save_ok"] is False
    assert report["save_error"] == "save_failed"
    assert crosswalk["diagnosis_to_medisoft"] == {}
    assert merged["diagnosis_to_medisoft"] == {}
    assert report["claims_completion"] is False
    assert report["mutates_dat"] is False
    assert report["mutates_837p"] is False


def test_service_line_input_crosswalk_intake_wrapper_revalidates_stale_patch_before_save(tmp_path):
    from MediCafe import service_line_input_model as model
    import MediBot.MediBot_Crosswalk_Utils as crosswalk_utils

    def fail_save_crosswalk(client, config, crosswalk, skip_api_operations=False, api_cache=None):
        raise AssertionError("stale conflicting patch must not call save_crosswalk")

    original_crosswalk = {
        "diagnosis_to_medisoft": {},
        "diagnosis_to_procedure": {},
        "procedure_to_diagnosis": {},
    }
    patch = model.build_service_line_crosswalk_intake_patch(
        original_crosswalk,
        "H26.101",
        "26101",
        "00140",
    )
    current_crosswalk = {
        "diagnosis_to_medisoft": {"H25.811": "26101"},
        "diagnosis_to_procedure": {},
        "procedure_to_diagnosis": {},
    }

    merged, report = crosswalk_utils.save_service_line_input_crosswalk_intake_patch(
        {"MediLink_Config": {"local_storage_path": str(tmp_path), "endpoints": []}},
        current_crosswalk,
        patch,
        row_target_identity={"patient_id": "1", "dos": "01-20-2026"},
        save_fn=fail_save_crosswalk,
    )

    assert report["save_ok"] is False
    assert report["save_error"] == "service_line_crosswalk_intake_patch_revalidation_failed"
    assert report["revalidation_conflicts"]
    assert current_crosswalk["diagnosis_to_medisoft"] == {"H25.811": "26101"}
    assert merged == current_crosswalk
    assert report["claims_completion"] is False
    assert report["mutates_837p"] is False


def test_service_line_input_crosswalk_intake_wrapper_revalidates_disk_before_save(tmp_path):
    from MediCafe import service_line_input_model as model
    import MediBot.MediBot_Crosswalk_Utils as crosswalk_utils

    def fail_save_crosswalk(client, config, crosswalk, skip_api_operations=False, api_cache=None):
        raise AssertionError("disk-stale conflicting patch must not call save_crosswalk")

    crosswalk_path = tmp_path / "crosswalk.json"
    crosswalk_path.write_text(json.dumps({
        "diagnosis_to_medisoft": {"H25.811": "26101"},
        "diagnosis_to_procedure": {},
        "procedure_to_diagnosis": {},
    }), encoding="utf-8")
    in_memory_crosswalk = {
        "diagnosis_to_medisoft": {},
        "diagnosis_to_procedure": {},
        "procedure_to_diagnosis": {},
    }
    patch = model.build_service_line_crosswalk_intake_patch(
        in_memory_crosswalk,
        "H26.101",
        "26101",
        "00140",
    )

    merged, report = crosswalk_utils.save_service_line_input_crosswalk_intake_patch(
        {
            "MediLink_Config": {
                "local_storage_path": str(tmp_path),
                "crosswalkPath": str(crosswalk_path),
                "endpoints": [],
            }
        },
        in_memory_crosswalk,
        patch,
        row_target_identity={"patient_id": "1", "dos": "01-20-2026"},
        save_fn=fail_save_crosswalk,
    )

    assert report["save_ok"] is False
    assert report["save_error"] == "service_line_crosswalk_intake_patch_revalidation_failed"
    assert report["current_crosswalk_revalidation_source"] == "disk"
    assert report["revalidation_conflicts"]
    assert in_memory_crosswalk["diagnosis_to_medisoft"] == {}
    assert merged["diagnosis_to_medisoft"] == {"H25.811": "26101"}
    assert report["claims_completion"] is False
    assert report["mutates_837p"] is False


def test_service_line_input_crosswalk_intake_wrapper_skips_save_for_noop_patch(tmp_path):
    from MediCafe import service_line_input_model as model
    import MediBot.MediBot_Crosswalk_Utils as crosswalk_utils

    def fail_save_crosswalk(client, config, crosswalk, skip_api_operations=False, api_cache=None):
        raise AssertionError("no-op patch should not call save_crosswalk")

    crosswalk = {
        "diagnosis_to_medisoft": {"H26.101": "26101"},
        "diagnosis_to_procedure": {"H26.101": "00140"},
        "procedure_to_diagnosis": {"00140": ["H26.101"]},
    }
    patch = model.build_service_line_crosswalk_intake_patch(
        crosswalk,
        "H26.101",
        "26101",
        "00140",
    )
    merged, report = crosswalk_utils.save_service_line_input_crosswalk_intake_patch(
        {"MediLink_Config": {"local_storage_path": str(tmp_path), "endpoints": []}},
        crosswalk,
        patch,
        row_target_identity={"patient_id": "1", "dos": "01-20-2026"},
        save_fn=fail_save_crosswalk,
    )

    assert report["save_ok"] is True
    assert report["save_skipped"] is True
    assert report["save_skipped_reason"] == "no_crosswalk_changes"
    assert report["changed"] is False
    assert report["affected_entries"] == []
    assert merged == crosswalk
    assert report["claims_completion"] is False
    assert report["mutates_837p"] is False


def test_service_line_input_crosswalk_intake_wrapper_preserves_state_owned_sidecar_with_real_save(tmp_path):
    from MediCafe import MediLink_ConfigLoader as loader
    from MediCafe import service_line_input_model as model
    import MediBot.MediBot_Crosswalk_Utils as crosswalk_utils

    config_path = str(tmp_path / "config.json")
    crosswalk_path = str(tmp_path / "crosswalk.json")
    with open(config_path, "w", encoding="utf-8") as handle:
        json.dump({"MediLink_Config": {"local_storage_path": str(tmp_path), "crosswalkPath": crosswalk_path}}, handle)
    with open(crosswalk_path, "w", encoding="utf-8") as handle:
        json.dump({"payer_id": {}}, handle)

    loader.clear_config_cache()
    loader.load_configuration(config_path, crosswalk_path)
    config = {"MediLink_Config": {"local_storage_path": str(tmp_path), "crosswalkPath": crosswalk_path, "endpoints": {}}}
    crosswalk = {
        "payer_id": {},
        "diagnosis_to_medisoft": {},
        "diagnosis_to_procedure": {},
        "procedure_to_diagnosis": {},
        "optum_payer_list": {
            "metadata": {"last_update": "today"},
            "payers": {"87726": {"search_claim": True}},
        },
    }
    patch = model.build_service_line_crosswalk_intake_patch(
        crosswalk,
        "H26.101",
        "26101",
        "00140",
    )

    _merged, report = crosswalk_utils.save_service_line_input_crosswalk_intake_patch(
        config,
        crosswalk,
        patch,
        row_target_identity={"patient_id": "1", "dos": "01-20-2026"},
    )

    assert report["save_ok"] is True
    with open(crosswalk_path, "r", encoding="utf-8") as handle:
        saved = json.load(handle)
    assert saved["diagnosis_to_medisoft"]["H26.101"] == "26101"
    assert saved["diagnosis_to_procedure"]["H26.101"] == "00140"
    assert "optum_payer_list" not in saved
    state_path = tmp_path / "crosswalk.state.json"
    with open(str(state_path), "r", encoding="utf-8") as handle:
        state_doc = json.load(handle)
    assert state_doc["optum_payer_list"] == crosswalk["optum_payer_list"]


def test_service_line_input_crosswalk_intake_wrapper_rejects_wrong_boundary_without_save(tmp_path):
    from MediCafe import service_line_input_model as model
    import MediBot.MediBot_Crosswalk_Utils as crosswalk_utils

    def fail_save_crosswalk(client, config, crosswalk, skip_api_operations=False, api_cache=None):
        raise AssertionError("wrong-boundary patch must not call save_crosswalk")

    crosswalk = {
        "diagnosis_to_medisoft": {},
        "diagnosis_to_procedure": {},
        "procedure_to_diagnosis": {},
    }
    patch = model.build_service_line_crosswalk_intake_patch(
        crosswalk,
        "H26.101",
        "26101",
        "00140",
    )
    patch["workflow_boundary"] = "preview_only_review_required"
    merged, report = crosswalk_utils.save_service_line_input_crosswalk_intake_patch(
        {"MediLink_Config": {"local_storage_path": str(tmp_path), "endpoints": []}},
        crosswalk,
        patch,
        save_fn=fail_save_crosswalk,
    )

    assert report["save_ok"] is False
    assert report["save_error"] == "invalid_service_line_crosswalk_intake_boundary"
    assert merged == crosswalk
    assert crosswalk["diagnosis_to_medisoft"] == {}


def test_service_line_input_crosswalk_intake_rejects_conflict_without_save(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    import MediBot.MediBot_Crosswalk_Utils as crosswalk_utils

    def fail_save_crosswalk(client, config, crosswalk, skip_api_operations=False, api_cache=None):
        raise AssertionError("conflicting intake must not call save_crosswalk")

    inputs = ["", "00142"]

    def fake_input(prompt=""):
        if not inputs:
            raise AssertionError("unexpected intake prompt: {}".format(prompt))
        return inputs.pop(0)

    monkeypatch.setattr(builtins, "input", fake_input)
    monkeypatch.setattr(crosswalk_utils, "save_crosswalk", fail_save_crosswalk)

    crosswalk = {
        "diagnosis_to_medisoft": {"H25.811": "25812"},
        "diagnosis_to_procedure": {"H25.811": "00142"},
        "procedure_to_diagnosis": {"00142": ["H25.811"]},
    }
    option_sets = medibot_script._service_line_input_option_sets_from_crosswalk(crosswalk)
    handler = medibot_script._service_line_input_crosswalk_intake_handler(
        {"MediLink_Config": {"local_storage_path": str(tmp_path), "endpoints": []}},
        crosswalk,
        option_sets,
    )

    result = handler(
        {"patient_id": "1", "date": "01-20-2026"},
        "diagnosis",
        "H25.812",
    )

    assert result["ok"] is False
    assert "medisoft_shorthand_already_points_to_different_diagnosis" in result["message"]
    assert "already mapped to H25.811" in result["message"]
    assert "row unchanged" in result["message"]
    assert crosswalk["diagnosis_to_medisoft"] == {"H25.811": "25812"}


def test_service_line_input_crosswalk_intake_persisted_as_overlay_event(tmp_path):
    medibot_script = _load_medibot_script_module()
    event = {
        "schema_version": "service_line_input_crosswalk_intake_event.v1",
        "workflow_boundary": "confirmed_config_update",
        "target_identity": {"patient_id": "1", "dos": "01-20-2026"},
        "diagnosis_code": "H26.101",
        "medisoft_code": "26101",
        "cpt_code": "00140",
        "save_ok": True,
        "claims_completion": True,
        "mutates_billing_state": True,
        "mutates_dat": True,
        "mutates_837p": True,
        "charges_entered": True,
    }
    summary = {
        "rows": [{
            "patient_id": "1",
            "date": "01-20-2026",
            "diagnosis": "H26.101",
            "diagnosis_source": "operator_crosswalk_intake",
            "cpt": "00140",
            "cpt_source": "operator_crosswalk_intake",
            "minutes": "12",
            "status": "ENTERED",
            "crosswalk_intake_save_ok": True,
            "crosswalk_intake_message": "Crosswalk updated; Service Line Input row updated.",
            "crosswalk_intake_events": [event],
            "workflow_boundary": "operational_charge_entry",
            "claims_completion": True,
            "mutates_billing_state": True,
            "source": {
                "patient_id": "1",
                "dos": "01-20-2026",
                "docx_diagnosis": "H26.101",
                "docx_position": 4,
            },
        }],
    }

    assert medibot_script.persist_service_line_input_summary(
        str(tmp_path),
        "service_line_input_test",
        "01-20-2026",
        summary,
    )

    state = json.loads((tmp_path / medibot_script.SERVICE_LINE_INPUT_STATE_FILENAME).read_text(encoding="utf-8"))
    row = state["rows"]["1|01-20-2026"]
    assert row["crosswalk_intake_save_ok"] is True
    assert row["crosswalk_intake_message"] == "Crosswalk updated; Service Line Input row updated."
    assert row["workflow_boundary"] == "preview_only_review_required"
    assert row["claims_completion"] is False
    assert row["mutates_billing_state"] is False
    assert row["mutates_dat"] is False
    assert row["mutates_837p"] is False
    intake_event = row["crosswalk_intake_events"][0]
    assert intake_event["workflow_boundary"] == "confirmed_config_update"
    assert intake_event["claims_completion"] is False
    assert intake_event["mutates_billing_state"] is False
    assert intake_event["mutates_dat"] is False
    assert intake_event["mutates_837p"] is False
    assert intake_event["charges_entered"] is False
    assert state["events"][-1]["workflow_boundary"] == "confirmed_config_update"
    assert state["events"][-1]["mutates_837p"] is False


def test_service_line_input_crosswalk_intake_handler_has_no_billing_custody_calls():
    medibot_script = _load_medibot_script_module()
    source = inspect.getsource(medibot_script._service_line_input_crosswalk_intake_handler)

    assert "MediLink_837p" not in source
    assert "apply_proposal_file" not in source
    assert "process_and_write_file" not in source
    assert "write_output_file" not in source
    assert "save_service_line_input_crosswalk_intake_patch" in source
    assert "save_crosswalk(" not in source
    assert "merge_crosswalk_with_service_line_intake_patch" not in source


def test_option_a_multi_dos_controller_q_returns_before_next_dos(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    calls = []
    inputs = ["q"]

    def fake_input(prompt=""):
        return inputs.pop(0)

    def fake_preview(entries, date_of_service_label=None, charge_calculator=None):
        calls.append(date_of_service_label)
        return {"entered": 0, "skipped": 1, "cancelled": 0, "rows": []}

    monkeypatch.setattr(builtins, "input", fake_input)
    monkeypatch.setattr(medibot_script.MediBot_UI, "run_service_line_input_entry", fake_preview)
    monkeypatch.setattr(
        medibot_script,
        "build_service_line_input_dos_groups_from_docx_index",
        lambda new_patient_info, config: [
            {"dos": "01-20-2026", "entries": [_entry("01-20-2026", "One", "1", "D1")]},
            {"dos": "01-21-2026", "entries": [_entry("01-21-2026", "Two", "2", "D2")]},
        ],
    )

    result = medibot_script.run_option_a_multi_dos_minutes_preview(
        [_entry("01-20-2026", "One", "1", "D1")],
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    assert calls == ["01-20-2026"]
    assert result["dos_completed"] == 1


def test_option_a_sidecar_hydrates_same_patient_dos_only(monkeypatch, tmp_path):
    medibot_script = _load_medibot_script_module()
    status = {
        "version": 1,
        "rows": {
            "1|01-20-2026": {
                "patient_id": "1",
                "dos": "01-20-2026",
                "status": "entered",
                "minutes": "18",
                "charge_display": "$540",
                "charge_amount": "540.00",
                "charge_note": "baseline 16-35",
                "charge_rule_id": "baseline_16_35",
                "charge_status": "calculated",
                "charge_schema_version": "charges_tool.v1",
                "charge_source": "baseline_minutes_tier",
                "workflow_boundary": "preview_only_review_required",
                "claims_completion": False,
                "mutates_billing_state": False,
                "billable": True,
                "requires_operator_review": True,
                "cpt": "00142",
                "diagnosis": "H40.11X2",
                "diagnosis_code": "H40.11X2",
                "diagnosis_source": "operator_overlay",
                "validation_status": "review_required",
            },
            "1|01-21-2026": {
                "patient_id": "1",
                "dos": "01-21-2026",
                "status": "cancelled",
                "charge_display": "$999",
                "charge_note": "wrong DOS evidence",
            },
            "2|01-21-2026": {
                "patient_id": "2",
                "dos": "01-21-2026",
                "status": "entered",
                "minutes": "22",
                "charge_display": "$999",
                "charge_note": "wrong patient and DOS evidence",
            },
        },
    }
    (tmp_path / medibot_script.OPTION_A_MINUTES_STATUS_FILENAME).write_text(
        json.dumps(status),
        encoding="utf-8",
    )
    index_data = {
        "schedules": {
            "01-20-2026": {
                "current": {
                    "patients": {
                        "1": {"diagnosis": "DOCX1", "position": 10},
                        "2": {"diagnosis": "DOCX2", "position": 20},
                    }
                }
            }
        }
    }

    monkeypatch.setattr(medibot_script, "load_docx_schedule_index", lambda local_storage_path: index_data)
    monkeypatch.setattr(
        medibot_script,
        "get_schedules_for_dates",
        lambda data, dates: {"01-20-2026": data["schedules"]["01-20-2026"]["current"]},
    )

    groups = medibot_script.build_option_a_preview_dos_groups_from_docx_index(
        [
            _entry("01-20-2026", "One", "1", "CSV1"),
            _entry("01-20-2026", "Two", "2", "CSV2"),
        ],
        {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
    )

    first_payload = groups[0]["entries"][0][4]
    second_payload = groups[0]["entries"][1][4]
    assert first_payload["_option_a_preview_status"] == "ENTERED"
    assert first_payload["_option_a_preview_minutes"] == "18"
    assert first_payload["_option_a_preview_charge_display"] == "$540"
    assert first_payload.get("_option_a_preview_charge_note", "") == ""
    assert first_payload["_option_a_preview_charge_rule_id"] == "baseline_16_35"
    assert first_payload["_option_a_preview_charge_schema_version"] == "charges_tool.v1"
    assert first_payload["_option_a_preview_charge_source"] == "baseline_minutes_tier"
    assert first_payload["_option_a_preview_workflow_boundary"] == "preview_only_review_required"
    assert first_payload["_option_a_preview_claims_completion"] is False
    assert first_payload["_option_a_preview_mutates_billing_state"] is False
    assert first_payload["_option_a_preview_billable"] is True
    assert first_payload["_option_a_preview_requires_operator_review"] is True
    assert first_payload["_option_a_preview_cpt"] == "00142"
    assert first_payload["_option_a_preview_diagnosis"] == "H40.11X2"
    assert first_payload["_option_a_preview_diagnosis_code"] == "H40.11X2"
    assert first_payload["_option_a_preview_diagnosis_source"] == "operator_overlay"
    assert "_option_a_preview_status" not in second_payload
    assert "_option_a_preview_charge_display" not in second_payload


def test_option_a_sidecar_workflow_boundary_same_patient_dos(tmp_path):
    medibot_script = _load_medibot_script_module()
    session_id = "option_a_test_session"
    summary = {
        "rows": [{
            "patient_id": "1",
            "diagnosis": "DOCX1",
            "minutes": "12",
            "status": "ENTERED",
            "workflow_boundary": "operational_charge_entry",
            "claims_completion": True,
            "mutates_billing_state": True,
            "billable": "False",
            "requires_operator_review": "True",
            "source": {
                "patient_id": "1",
                "dos": "01-20-2026",
                "docx_diagnosis": "DOCX1",
                "docx_position": 10,
            },
        }]
    }

    assert medibot_script.persist_option_a_minutes_summary(
        str(tmp_path),
        session_id,
        "01-20-2026",
        summary,
    )
    status_path = tmp_path / medibot_script.OPTION_A_MINUTES_STATUS_FILENAME
    status = json.loads(status_path.read_text(encoding="utf-8"))
    row = status["rows"]["1|01-20-2026"]
    assert row["workflow_boundary"] == "preview_only_review_required"
    assert row["claims_completion"] is False
    assert row["mutates_billing_state"] is False
    assert row["billable"] is False
    assert row["requires_operator_review"] is True

    assert_workflow_boundary_clean("option_a_minutes_entry", {
        "patient_id": "1",
        "dos": "01-20-2026",
    }, [
        {
            "name": "docx_index_candidate",
            "role": "intent",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "requested",
        },
        {
            "name": "preview_attempt",
            "role": "attempt",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "completed",
            "accepted": True,
        },
        {
            "name": "sidecar_row",
            "role": "package",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "classification": "accepted_for_anchor",
            "claims_completion": False,
        },
        {
            "name": "dat_export_absent",
            "role": "artifact",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "classification": "missing",
        },
        {
            "name": "stale_sidecar_row",
            "role": "artifact",
            "identity": {"patient_id": "1", "dos": "01-19-2026"},
            "classification": "ignored_mismatch",
        },
    ])


def test_option_a_charge_workflow_boundary_is_preview_only_same_patient_dos():
    assert_workflow_boundary_clean("option_a_charge_entry", {
        "patient_id": "1",
        "dos": "01-20-2026",
    }, [
        {
            "name": "preview_attempt",
            "role": "attempt",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "completed",
            "accepted": True,
        },
        {
            "name": "sidecar_row_status",
            "role": "state",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "completed",
            "classification": "accepted_for_anchor",
            "claims_completion": False,
        },
        {
            "name": "charge_result",
            "role": "package",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "completed",
            "classification": "review_required",
            "claims_completion": False,
        },
        {
            "name": "wrong_dos_charge_result",
            "role": "artifact",
            "identity": {"patient_id": "1", "dos": "01-21-2026"},
            "classification": "ignored_mismatch",
        },
        {
            "name": "wrong_patient_charge_result",
            "role": "artifact",
            "identity": {"patient_id": "2", "dos": "01-20-2026"},
            "classification": "ignored_mismatch",
        },
        {
            "name": "medisoft_charge_entry_absent",
            "role": "artifact",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "classification": "missing",
            "claims_completion": False,
        },
    ])


def test_service_line_input_workflow_boundary_uses_same_patient_dos_and_review_only_state():
    assert_workflow_boundary_clean("service_line_input", {
        "patient_id": "1",
        "dos": "01-20-2026",
    }, [
        {
            "name": "docx_index_candidate",
            "role": "intent",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "ready",
            "classification": "review_required",
            "claims_completion": False,
        },
        {
            "name": "service_line_input_attempt",
            "role": "attempt",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "completed",
            "terminal": True,
            "accepted": True,
        },
        {
            "name": "service_line_input_state_row",
            "role": "state",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "completed",
            "classification": "review_required",
            "claims_completion": False,
        },
        {
            "name": "legacy_option_a_state_row",
            "role": "state",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "completed",
            "classification": "review_required",
            "claims_completion": False,
        },
        {
            "name": "unrelated_dos_state_row",
            "role": "state",
            "identity": {"patient_id": "1", "dos": "01-21-2026"},
            "classification": "ignored_mismatch",
            "claims_completion": False,
        },
    ])


def test_option_a_charge_workflow_boundary_cancelled_skipped_do_not_claim_charge_completion():
    assert_workflow_boundary_clean("option_a_charge_entry", {
        "patient_id": "1",
        "dos": "01-20-2026",
    }, [
        {
            "name": "cancelled_preview_attempt",
            "role": "attempt",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "cancelled",
            "terminal": True,
            "fail_closed": True,
        },
        {
            "name": "cancelled_sidecar_row",
            "role": "state",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "cancelled",
            "classification": "fail_closed",
            "terminal": True,
            "fail_closed": True,
            "claims_completion": False,
        },
        {
            "name": "charge_result",
            "role": "package",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "classification": "review_required",
            "claims_completion": False,
        },
    ])
