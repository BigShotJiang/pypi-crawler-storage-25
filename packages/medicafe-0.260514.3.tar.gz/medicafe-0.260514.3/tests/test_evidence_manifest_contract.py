# -*- coding: utf-8 -*-
"""Executable contract tests for the unified evidence manifest resolver.

These tests intentionally skip until MediCafe.evidence_manifest exists. They
define the first migration slice for the future build agent without breaking
the current branch before that implementation lands.
"""

from __future__ import print_function

import json
import os
import shutil
import sqlite3
import sys
import tempfile
import time
import unittest


_TEST_DIR = os.path.dirname(os.path.abspath(__file__))
if _TEST_DIR not in sys.path:
    sys.path.insert(0, _TEST_DIR)

from workflow_boundary_contract import assert_workflow_boundary_clean


def _load_evidence_manifest():
    """Load resolver; prefer importlib (works across PEP 562 / lazy package attrs)."""
    try:
        import importlib

        return importlib.import_module("MediCafe.evidence_manifest")
    except ImportError:
        pass
    try:
        from MediCafe import evidence_manifest
    except ImportError as exc:
        raise unittest.SkipTest("MediCafe.evidence_manifest not implemented yet: {0}".format(exc))
    return evidence_manifest


def _write_json(path, obj):
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(obj, handle)


def _archive_names(manifest):
    names = []
    for attachment in manifest.get("attachments", []):
        if isinstance(attachment, dict):
            names.append(attachment.get("archive_name"))
    return names


class EvidenceManifestPhaseCContractTests(unittest.TestCase):
    def setUp(self):
        self.lab_root = tempfile.mkdtemp(prefix="mc_ev_manifest_")
        self.reports_dir = os.path.join(self.lab_root, "reports")
        os.makedirs(self.reports_dir)

    def tearDown(self):
        shutil.rmtree(self.lab_root, ignore_errors=True)

    def _phase_c_request(self, evidence_manifest, run_id):
        return evidence_manifest.build_evidence_request(
            "pipeline_failure_report",
            "unit_test",
            self.lab_root,
            anchor_run_id="shadow-run",
            active_run_id="shadow-run",
            failed_phase="C",
            error_code="PHASE_C_DB_WRITE_ERROR",
            operator_surface="developer_support",
        )

    def test_phase_c_known_run_missing_summary_records_required_gap_without_latest_fallback(self):
        evidence_manifest = _load_evidence_manifest()
        c_run_id = "phase-c-target"
        stale_path = os.path.join(self.reports_dir, "ingest_write_summary_stale.json")
        _write_json(stale_path, {"run_id": "stale", "summary_schema_version": 1})
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_phase_c_run_id": c_run_id,
                "last_phase_c_ok": False,
                "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
            },
        )
        _write_json(
            os.path.join(self.lab_root, "run_cursor.json"),
            {"last_phase_c_run_id": c_run_id},
        )

        request = self._phase_c_request(evidence_manifest, c_run_id)
        manifest = evidence_manifest.resolve_evidence_manifest(request)

        self.assertNotIn("ingest_write_summary_stale.json", _archive_names(manifest))
        missing = manifest.get("missing_required_evidence", [])
        missing_names = [item.get("archive_name") for item in missing if isinstance(item, dict)]
        self.assertIn("ingest_write_summary_{0}.json".format(c_run_id), missing_names)
        self.assertNotEqual(
            evidence_manifest.manifest_to_extra_meta(manifest).get("attachment_contract_status"),
            "pass",
        )

    def test_phase_c_present_summary_is_attached_and_manifest_sha_mismatch_requires_review(self):
        evidence_manifest = _load_evidence_manifest()
        c_run_id = "phase-c-present"
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_phase_c_run_id": c_run_id,
                "last_phase_c_ok": False,
                "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
                "last_manifest_sha256": "sha-current",
                "last_ingest_manifest_sha256": "sha-old",
            },
        )
        _write_json(
            os.path.join(self.lab_root, "run_cursor.json"),
            {
                "last_phase_c_run_id": c_run_id,
                "last_manifest_sha256": "sha-current",
                "last_ingest_manifest_sha256": "sha-old",
            },
        )
        summary_name = "ingest_write_summary_{0}.json".format(c_run_id)
        _write_json(
            os.path.join(self.reports_dir, summary_name),
            {
                "run_id": c_run_id,
                "ok": False,
                "error_code": "PHASE_C_DB_WRITE_ERROR",
                "manifest_sha256": "sha-old",
                "summary_schema_version": 2,
                "db_error_detail": "database is locked",
            },
        )

        request = self._phase_c_request(evidence_manifest, c_run_id)
        manifest = evidence_manifest.resolve_evidence_manifest(request)
        meta = evidence_manifest.manifest_to_extra_meta(manifest)

        self.assertIn(summary_name, _archive_names(manifest))
        self.assertEqual(manifest.get("scope", {}).get("coherence_status"), "review_required")
        self.assertEqual(meta.get("coherence_status"), "review_required")
        self.assertIn("missing_required_evidence", meta)
        self.assertIn(meta.get("attachment_contract_status"), ("pass", "degraded"))

    def test_phase_c_ingest_manifest_sha_mismatch_requires_review(self):
        evidence_manifest = _load_evidence_manifest()
        c_run_id = "phase-c-ingest-sha"
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_phase_c_run_id": c_run_id,
                "last_phase_c_ok": False,
                "last_ingest_manifest_sha256": "sha-ingest-current",
            },
        )
        _write_json(
            os.path.join(self.lab_root, "run_cursor.json"),
            {
                "last_phase_c_run_id": c_run_id,
                "last_ingest_manifest_sha256": "sha-ingest-current",
            },
        )
        _write_json(
            os.path.join(self.reports_dir, "ingest_write_summary_{0}.json".format(c_run_id)),
            {
                "run_id": c_run_id,
                "ok": False,
                "manifest_sha256": "sha-ingest-old",
            },
        )

        request = self._phase_c_request(evidence_manifest, c_run_id)
        manifest = evidence_manifest.resolve_evidence_manifest(request)

        self.assertEqual(manifest.get("scope", {}).get("coherence_status"), "review_required")

    def test_phase_c_shadow_recovery_report_is_attached_when_present(self):
        evidence_manifest = _load_evidence_manifest()
        c_run_id = "phase-c-after-recovery"
        recovery_name = "phase_c_shadow_recovery_shadow-run.json"
        recovery_path = os.path.join(self.reports_dir, recovery_name)
        _write_json(recovery_path, {
            "status": "completed",
            "action": "phase_c_shadow_rebuild",
            "source_files_touched": False,
        })
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_phase_c_run_id": c_run_id,
                "last_phase_c_ok": False,
                "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
                "last_phase_c_shadow_recovery_status": "completed",
                "last_phase_c_shadow_recovery_report_path": recovery_path,
            },
        )
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})

        request = self._phase_c_request(evidence_manifest, c_run_id)
        manifest = evidence_manifest.resolve_evidence_manifest(request)
        names = _archive_names(manifest)

        self.assertIn(recovery_name, names)
        rows = [
            row for row in manifest.get("attachments", [])
            if isinstance(row, dict) and row.get("archive_name") == recovery_name
        ]
        self.assertEqual(rows[0].get("scope"), "phase_c_shadow_recovery")
        corr = [
            row for row in manifest.get("attachments", [])
            if isinstance(row, dict) and row.get("archive_name") == evidence_manifest.PHASE_C_CORRELATION_ARCHIVE_NAME
        ][0]
        self.assertIn("last_phase_c_shadow_recovery_status=completed", corr.get("inline_content", ""))

    def test_phase_c_bundle_attaches_shadow_recovery_txt_stderr_tail_and_db_probe(self):
        evidence_manifest = _load_evidence_manifest()
        c_run_id = "phase-c-probe-pack"
        recovery_name = "phase_c_shadow_recovery_shadow-run.json"
        recovery_path = os.path.join(self.reports_dir, recovery_name)
        _write_json(recovery_path, {"status": "completed", "action": "phase_c_shadow_rebuild"})
        recovery_txt = recovery_path[:-5] + ".txt"
        with open(recovery_txt, "w", encoding="utf-8") as tf:
            tf.write("shadow recovery log line\n")
        stderr_path = os.path.join(self.reports_dir, "phase_c_ingest_stderr_tail_latest.txt")
        with open(stderr_path, "w", encoding="utf-8") as sf:
            sf.write("sqlite trace\n")
        ingest_diag = os.path.join(self.reports_dir, "ingest_from_manifest_diagnostics_latest.json")
        _write_json(
            ingest_diag,
            {"schema_version": 1, "error_code": "PHASE_C_DB_WRITE_ERROR", "db_error_detail": "unit"},
        )

        db_path = os.path.join(self.lab_root, "unified_model_xp.db")
        conn = sqlite3.connect(db_path)
        conn.execute(
            "CREATE TABLE ingest_artifact (ingest_key TEXT, source_system TEXT, source_type TEXT, "
            "source_ref TEXT, message_id TEXT, attachment_name TEXT, attachment_sha256 TEXT, "
            "payload_json TEXT, ingest_status TEXT)"
        )
        conn.commit()
        conn.close()

        summary_name = "ingest_write_summary_{0}.json".format(c_run_id)
        _write_json(
            os.path.join(self.reports_dir, summary_name),
            {
                "run_id": c_run_id,
                "ok": False,
                "error_code": "PHASE_C_DB_WRITE_ERROR",
                "summary_schema_version": 1,
                "manifest_sha256": "aa",
            },
        )
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_phase_c_run_id": c_run_id,
                "last_phase_c_ok": False,
                "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
                "last_shadow_pipeline_run_id": "shadow-run",
                "last_phase_c_shadow_recovery_report_path": recovery_path,
            },
        )
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})

        request = self._phase_c_request(evidence_manifest, c_run_id)
        manifest = evidence_manifest.resolve_evidence_manifest(request)
        names = _archive_names(manifest)

        self.assertIn(recovery_name, names)
        self.assertIn(os.path.basename(recovery_txt), names)
        self.assertIn("phase_c_ingest_stderr_tail_latest.txt", names)
        self.assertIn("phase_c_db_health_probe_latest.json", names)
        self.assertIn("ingest_from_manifest_diagnostics_latest.json", names)
        self.assertIn(evidence_manifest.PHASE_C_CORRELATION_ARCHIVE_NAME, names)

    def test_phase_c_execution_handoff_attached_when_state_points_to_files(self):
        evidence_manifest = _load_evidence_manifest()
        c_run_id = "phase-c-exec-handoff"
        handoff_json = os.path.join(self.reports_dir, "phase_c_execution_handoff_shadow-run.json")
        _write_json(handoff_json, {"schema_version": 1, "blocker_class": "phase_c_expected_summary_missing"})
        handoff_txt = handoff_json[:-5] + ".txt"
        with open(handoff_txt, "w", encoding="utf-8") as tf:
            tf.write("Phase C Execution / Handoff Diagnostic\n")
        bootstrap_path = os.path.join(self.reports_dir, "ingest_from_manifest_bootstrap_latest.json")
        _write_json(
            bootstrap_path,
            {
                "schema_version": 1,
                "stage": "before_run_ingest",
                "sys_argv": ["ingest_from_manifest.py"],
            },
        )
        bootstrap_timeline_path = os.path.join(
            self.reports_dir, "ingest_from_manifest_bootstrap_timeline_latest.jsonl")
        with open(bootstrap_timeline_path, "w", encoding="utf-8") as bf:
            bf.write('{"schema_version":1,"stage":"before_run_ingest","stage_seq":1}\n')
        current_attempt_path = os.path.join(self.reports_dir, "phase_c_current_attempt_latest.json")
        _write_json(
            current_attempt_path,
            {
                "schema_version": 1,
                "phase_c_attempt_id": "shadow-run-phase-c",
                "last_reached_stage": "bootstrap_timeline",
                "current_blocker": "phase_c_script_entered_but_no_finish_diag_current_attempt",
            },
        )
        _write_json(
            os.path.join(self.reports_dir, "xp_phase_smoke_latest.json"),
            {"schema_version": 1, "overall_status": "blocked", "first_blocker": "phase_c"},
        )
        with open(os.path.join(self.reports_dir, "xp_phase_smoke_latest.txt"), "w", encoding="utf-8") as sf:
            sf.write("XP Phase Smoke\n")
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_phase_c_run_id": c_run_id,
                "last_phase_c_ok": False,
                "last_phase_c_error_code": "PHASE_C_HANDOFF_INCOHERENT",
                "last_shadow_pipeline_run_id": "shadow-run",
                "last_phase_c_execution_handoff_report_path": handoff_json,
            },
        )
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})

        request = self._phase_c_request(evidence_manifest, c_run_id)
        manifest = evidence_manifest.resolve_evidence_manifest(request)
        names = _archive_names(manifest)

        self.assertIn("phase_c_execution_handoff_shadow-run.json", names)
        self.assertIn("phase_c_execution_handoff_shadow-run.txt", names)
        self.assertIn("ingest_from_manifest_bootstrap_latest.json", names)
        self.assertIn("ingest_from_manifest_bootstrap_timeline_latest.jsonl", names)
        self.assertIn("phase_c_current_attempt_latest.json", names)
        self.assertIn("xp_phase_smoke_latest.json", names)
        self.assertIn("xp_phase_smoke_latest.txt", names)
        rows = [
            row
            for row in manifest.get("attachments", [])
            if isinstance(row, dict)
            and row.get("archive_name") == "phase_c_execution_handoff_shadow-run.json"
        ]
        self.assertEqual(rows[0].get("scope"), "phase_c_execution_handoff")
        bootstrap_rows = [
            row
            for row in manifest.get("attachments", [])
            if isinstance(row, dict)
            and row.get("archive_name") == "ingest_from_manifest_bootstrap_latest.json"
        ]
        self.assertEqual(bootstrap_rows[0].get("scope"), "phase_c_ingest_bootstrap")
        timeline_rows = [
            row
            for row in manifest.get("attachments", [])
            if isinstance(row, dict)
            and row.get("archive_name") == "ingest_from_manifest_bootstrap_timeline_latest.jsonl"
        ]
        self.assertEqual(timeline_rows[0].get("scope"), "phase_c_ingest_bootstrap_timeline")
        current_rows = [
            row
            for row in manifest.get("attachments", [])
            if isinstance(row, dict)
            and row.get("archive_name") == "phase_c_current_attempt_latest.json"
        ]
        self.assertEqual(current_rows[0].get("scope"), "phase_c_current_attempt")
        smoke_rows = [
            row
            for row in manifest.get("attachments", [])
            if isinstance(row, dict)
            and row.get("archive_name") == "xp_phase_smoke_latest.json"
        ]
        self.assertEqual(smoke_rows[0].get("scope"), "xp_phase_smoke")

    def test_phase_c_execution_handoff_attached_when_cursor_holds_report_path(self):
        evidence_manifest = _load_evidence_manifest()
        c_run_id = "phase-c-cursor-handoff"
        handoff_json = os.path.join(self.reports_dir, "phase_c_execution_handoff_shadow-run.json")
        _write_json(handoff_json, {"schema_version": 1})
        handoff_txt = handoff_json[:-5] + ".txt"
        with open(handoff_txt, "w", encoding="utf-8") as tf:
            tf.write("txt\n")
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_phase_c_run_id": c_run_id,
                "last_phase_c_ok": False,
                "last_shadow_pipeline_run_id": "shadow-run",
            },
        )
        _write_json(
            os.path.join(self.lab_root, "run_cursor.json"),
            {"last_phase_c_execution_handoff_report_path": handoff_json},
        )

        request = self._phase_c_request(evidence_manifest, c_run_id)
        manifest = evidence_manifest.resolve_evidence_manifest(request)
        names = _archive_names(manifest)

        self.assertIn("phase_c_execution_handoff_shadow-run.json", names)
        self.assertIn("phase_c_execution_handoff_shadow-run.txt", names)

    def test_phase_c_self_heal_status_attached_when_file_present(self):
        evidence_manifest = _load_evidence_manifest()
        c_run_id = "phase-c-self-heal"
        sh_path = os.path.join(self.reports_dir, "phase_c_self_heal_status_latest.txt")
        with open(sh_path, "w", encoding="utf-8") as tf:
            tf.write("Phase C Self-Heal Status\n")
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_phase_c_run_id": c_run_id,
                "last_phase_c_ok": False,
                "last_shadow_pipeline_run_id": "shadow-run",
            },
        )
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})

        request = self._phase_c_request(evidence_manifest, c_run_id)
        manifest = evidence_manifest.resolve_evidence_manifest(request)
        names = _archive_names(manifest)
        self.assertIn("phase_c_self_heal_status_latest.txt", names)
        rows = [
            row
            for row in manifest.get("attachments", [])
            if isinstance(row, dict) and row.get("archive_name") == "phase_c_self_heal_status_latest.txt"
        ]
        self.assertEqual(rows[0].get("scope"), "phase_c_self_heal_status")

    def test_phase_c_subprocess_zero_missing_ingest_diag_attaches_handoff_and_run_aligned_files(self):
        evidence_manifest = _load_evidence_manifest()
        c_run_id = "phase-c-subproc-zero"
        summary_name = "ingest_write_summary_{0}.json".format(c_run_id)
        _write_json(
            os.path.join(self.reports_dir, summary_name),
            {"run_id": c_run_id, "ok": False, "manifest_sha256": "sha-old"},
        )
        handoff_json = os.path.join(self.reports_dir, "phase_c_execution_handoff_shadow-run.json")
        _write_json(
            handoff_json,
            {
                "schema_version": 1,
                "phase_c_subprocess_return_code": 0,
                "blocker_class": "phase_c_script_entered_but_no_finish_diag",
            },
        )
        with open(handoff_json[:-5] + ".txt", "w", encoding="utf-8") as tf:
            tf.write("subprocess launched rc=0\n")
        _write_json(
            os.path.join(self.reports_dir, "ingest_from_manifest_bootstrap_latest.json"),
            {"schema_version": 1, "stage": "before_run_ingest"},
        )
        with open(os.path.join(self.reports_dir, "phase_c_ingest_stderr_tail_latest.txt"), "w", encoding="utf-8") as sf:
            sf.write("stderr tail\n")
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_phase_c_run_id": c_run_id,
                "last_phase_c_ok": False,
                "last_phase_c_error_code": "PHASE_C_HANDOFF_INCOHERENT",
                "last_shadow_pipeline_run_id": "shadow-run",
                "last_phase_c_execution_handoff_report_path": handoff_json,
                "last_phase_c_execution_handoff_status": "failed",
                "last_phase_c_execution_handoff_blocker_class": "phase_c_script_entered_but_no_finish_diag",
                "last_manifest_sha256": "sha-current",
                "last_ingest_manifest_sha256": "sha-old",
            },
        )
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})

        request = self._phase_c_request(evidence_manifest, c_run_id)
        manifest = evidence_manifest.resolve_evidence_manifest(request)
        names = _archive_names(manifest)

        self.assertIn(summary_name, names)
        self.assertIn("phase_c_execution_handoff_shadow-run.json", names)
        self.assertIn("phase_c_execution_handoff_shadow-run.txt", names)
        self.assertIn("ingest_from_manifest_bootstrap_latest.json", names)
        self.assertIn("phase_c_ingest_stderr_tail_latest.txt", names)
        self.assertIn("phase_c_db_health_probe_latest.json", names)
        self.assertNotIn("ingest_from_manifest_diagnostics_latest.json", names)

    def test_manifest_extra_file_merge_keeps_contract_attachment_first(self):
        evidence_manifest = _load_evidence_manifest()
        if not hasattr(evidence_manifest, "merge_extra_files"):
            raise unittest.SkipTest("merge_extra_files not implemented yet")

        primary = [("diagnostics_state.json", "manifest-current")]
        secondary = [("diagnostics_state.json", "legacy-stale"), ("legacy.txt", "legacy")]

        merged = evidence_manifest.merge_extra_files(primary, secondary)

        self.assertEqual(merged[0], ("diagnostics_state.json", "manifest-current"))
        self.assertEqual([item[0] for item in merged].count("diagnostics_state.json"), 1)
        self.assertIn(("legacy.txt", "legacy"), merged)


class EvidenceManifestPhaseFAndDatTests(unittest.TestCase):
    def setUp(self):
        self.lab_root = tempfile.mkdtemp(prefix="mc_ev_pf_")
        self.reports_dir = os.path.join(self.lab_root, "reports")
        os.makedirs(self.reports_dir)

    def tearDown(self):
        shutil.rmtree(self.lab_root, ignore_errors=True)

    def test_collect_shadow_evidence_index_paths_skips_missing(self):
        evidence_manifest = _load_evidence_manifest()
        phase_sum = os.path.join(self.reports_dir, "phase_b_x.json")
        _write_json(phase_sum, {"run_id": "b"})
        index_path = os.path.join(self.reports_dir, "shadow_evidence_index_run1.json")
        _write_json(
            index_path,
            {
                "artifact_files": [
                    {"role": "phase_b_summary", "path": phase_sum, "exists": True},
                    {"role": "phase_c_summary", "path": "__MISSING__", "exists": False},
                ]
            },
        )
        rows = evidence_manifest.collect_shadow_evidence_index_referenced_paths(index_path)
        basenames = [r[0] for r in rows]
        self.assertIn(os.path.basename(phase_sum), basenames)
        self.assertEqual(len(rows), 1)

    def test_phase_f_manifest_unions_phase_c_when_failed_phase_c(self):
        evidence_manifest = _load_evidence_manifest()
        c_run = "c-run-1"
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_phase_c_run_id": c_run,
                "last_phase_c_ok": False,
                "last_shadow_pipeline_phase_run_ids": {"C": c_run},
            },
        )
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})
        summ = os.path.join(self.reports_dir, "ingest_write_summary_{0}.json".format(c_run))
        _write_json(summ, {"run_id": c_run, "manifest_sha256": "m1", "ok": False})
        rj = os.path.join(self.reports_dir, "shadow_run_report_anchor.json")
        _write_json(rj, {"run_id": "anchor"})
        rt = os.path.join(self.reports_dir, "shadow_run_report_anchor.txt")
        with open(rt, "w", encoding="utf-8") as handle:
            handle.write("txt\n")
        ix = os.path.join(self.reports_dir, "shadow_evidence_index_anchor.json")
        _write_json(ix, {"artifact_files": []})
        req = evidence_manifest.build_evidence_request(
            "phase_f_evidence",
            "test",
            self.lab_root,
            anchor_run_id="anchor",
            failed_phase="C",
            error_code="PHASE_C_DB_WRITE_ERROR",
            phase_f_report_json_path=rj,
            phase_f_report_txt_path=rt,
            phase_f_evidence_index_path=ix,
        )
        man = evidence_manifest.resolve_evidence_manifest(req)
        names = _archive_names(man)
        self.assertIn("ingest_write_summary_{0}.json".format(c_run), names)
        self.assertIn(evidence_manifest.PHASE_F_BC_CORRELATION_ARCHIVE_NAME, names)

    def test_pipeline_failure_manifest_includes_prefetched_report_context(self):
        evidence_manifest = _load_evidence_manifest()
        _write_json(os.path.join(self.lab_root, "diagnostics_state.json"), {})
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})
        phase_b_report = os.path.join(self.reports_dir, "artifact_discovery_summary_b-run.json")
        _write_json(phase_b_report, {"phase": "B", "run_id": "b-run"})
        projection_summary = {"phase": "pipeline", "failed_phase": "B"}
        req = evidence_manifest.build_evidence_request(
            "pipeline_failure_report",
            "test",
            self.lab_root,
            anchor_run_id="shadow-run",
            failed_phase="B",
            error_code="PHASE_B_ROOT_RESOLUTION_FAIL",
            _prefetched_evidence_tuples=[
                ("artifact_discovery_summary_b-run.json", phase_b_report),
                ("projection_parity_summary.json", projection_summary),
            ],
        )
        man = evidence_manifest.resolve_evidence_manifest(req)
        names = _archive_names(man)
        self.assertIn("diagnostics_state.json", names)
        self.assertIn("run_cursor.json", names)
        self.assertIn("artifact_discovery_summary_b-run.json", names)
        self.assertIn("projection_parity_summary.json", names)
        self.assertIn(
            ("projection_parity_summary.json", projection_summary),
            evidence_manifest.manifest_to_extra_files(man),
        )
        self.assertEqual(
            evidence_manifest.manifest_to_extra_meta(man).get("bundle_kind"),
            "pipeline_failure_report",
        )

    def test_required_phase_c_summary_upgrades_prefetched_duplicate_attachment(self):
        evidence_manifest = _load_evidence_manifest()
        c_run = "c-required"
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {"last_phase_c_run_id": c_run, "last_phase_c_ok": False},
        )
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {"last_phase_c_run_id": c_run})
        summary_name = "ingest_write_summary_{0}.json".format(c_run)
        summary_path = os.path.join(self.reports_dir, summary_name)
        _write_json(summary_path, {"run_id": c_run, "ok": False})
        req = evidence_manifest.build_evidence_request(
            "pipeline_failure_report",
            "test",
            self.lab_root,
            anchor_run_id="shadow-run",
            failed_phase="C",
            error_code="PHASE_C_DB_WRITE_ERROR",
            _prefetched_evidence_tuples=[(summary_name, summary_path)],
        )

        man = evidence_manifest.resolve_evidence_manifest(req)
        rows = [
            row for row in man.get("attachments", [])
            if isinstance(row, dict) and row.get("archive_name") == summary_name
        ]

        self.assertEqual(len(rows), 1)
        self.assertTrue(rows[0].get("required"))
        self.assertEqual(rows[0].get("scope"), "phase_c_run")
        self.assertEqual(rows[0].get("run_id"), c_run)

    def test_manifest_skips_historical_layer1_prefetched_attachment(self):
        evidence_manifest = _load_evidence_manifest()
        _write_json(os.path.join(self.lab_root, "diagnostics_state.json"), {})
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})
        old_name = "layer1_join_debug_summary_old-run.json"
        old_path = os.path.join(self.reports_dir, old_name)
        _write_json(old_path, {"run_id": "old-run"})
        old_epoch = int(time.time()) - (evidence_manifest.ATTACHMENT_STALE_AFTER_SEC + 60)
        os.utime(old_path, (old_epoch, old_epoch))
        req = evidence_manifest.build_evidence_request(
            "pipeline_failure_report",
            "test",
            self.lab_root,
            anchor_run_id="shadow-run",
            _prefetched_evidence_tuples=[(old_name, old_path)],
        )

        man = evidence_manifest.resolve_evidence_manifest(req)
        rows = [
            row for row in man.get("attachments", [])
            if isinstance(row, dict) and row.get("archive_name") == old_name
        ]

        self.assertEqual(len(rows), 0)
        snap = evidence_manifest.manifest_enqueue_snapshot(man)
        snap_rows = [
            row for row in snap.get("attachments_summary", [])
            if isinstance(row, dict) and row.get("archive_name") == old_name
        ]
        self.assertEqual(len(snap_rows), 0)

    def test_layer1_prefetched_artifacts_attach_only_current_effective_context(self):
        evidence_manifest = _load_evidence_manifest()
        anchor = "run-current"
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_discovery_ok": True,
                "last_phase_b_run_id": "b1",
                "last_manifest_sha256": "m",
                "last_ingest_manifest_sha256": "m",
                "last_phase_c_ok": True,
                "last_shadow_pipeline_run_id": anchor,
            },
        )
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})
        _write_json(
            os.path.join(self.reports_dir, "artifact_discovery_summary_b1.json"),
            {"run_id": "b1", "counts_by_class": {"csv": 1, "docx": 1, "dat": 1}},
        )
        _write_json(
            os.path.join(self.reports_dir, "qa_canonical_summary_{0}.json".format(anchor)),
            {"run_id": anchor, "rows_selected": 1},
        )
        old_name = "layer1_join_debug_summary_old-run.json"
        cur_name = "layer1_join_debug_summary_{0}.json".format(anchor)
        old_path = os.path.join(self.reports_dir, old_name)
        cur_path = os.path.join(self.reports_dir, cur_name)
        _write_json(old_path, {"run_id": "old-run"})
        _write_json(cur_path, {"run_id": anchor})
        req = evidence_manifest.build_evidence_request(
            "pipeline_failure_report",
            "test",
            self.lab_root,
            anchor_run_id=anchor,
            _prefetched_evidence_tuples=[(old_name, old_path), (cur_name, cur_path)],
        )

        man = evidence_manifest.resolve_evidence_manifest(req)
        rows = {
            row.get("archive_name"): row
            for row in man.get("attachments", [])
            if isinstance(row, dict) and row.get("archive_name") in (old_name, cur_name)
        }
        self.assertNotIn(old_name, rows)
        self.assertEqual(rows[cur_name].get("scope"), "current_layer1_context")

    def test_review_dat_qa_full_block_requires_layer1_and_qa_files(self):
        evidence_manifest = _load_evidence_manifest()
        rid = "anchor-dat"
        _write_json(os.path.join(self.lab_root, "diagnostics_state.json"), {})
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})
        req = evidence_manifest.build_evidence_request(
            "run_evidence_bundle",
            "test",
            self.lab_root,
            anchor_run_id=rid,
            recommendation_action_kind="review_dat_qa_full_block",
        )
        man = evidence_manifest.resolve_evidence_manifest(req)
        missing = [m.get("archive_name") for m in man.get("missing_required_evidence", []) if isinstance(m, dict)]
        self.assertTrue(any("qa_canonical_summary_{0}.json".format(rid) in (n or "") for n in missing))

    def test_phase_d_dat_verification_rerun_applies_dat_qa_contract_like_review(self):
        evidence_manifest = _load_evidence_manifest()
        rid = "anchor-dat-rerun"
        _write_json(os.path.join(self.lab_root, "diagnostics_state.json"), {})
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})
        req = evidence_manifest.build_evidence_request(
            "run_evidence_bundle",
            "test",
            self.lab_root,
            anchor_run_id=rid,
            recommendation_action_kind="phase_d_dat_verification_rerun",
        )
        man = evidence_manifest.resolve_evidence_manifest(req)
        missing = [m.get("archive_name") for m in man.get("missing_required_evidence", []) if isinstance(m, dict)]
        self.assertTrue(any("qa_canonical_summary_{0}.json".format(rid) in (n or "") for n in missing))

    def test_review_dat_qa_full_block_uses_phase_d_run_id_for_phase_d_artifacts(self):
        evidence_manifest = _load_evidence_manifest()
        anchor = "shadow-anchor"
        d_run = "phase-d-run"
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_shadow_pipeline_run_id": anchor,
                "last_phase_d_run_id": d_run,
                "last_shadow_pipeline_phase_run_ids": {"D": d_run},
            },
        )
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {"last_phase_d_run_id": d_run})
        _write_json(os.path.join(self.reports_dir, "qa_canonical_summary_{0}.json".format(d_run)), {"run_id": d_run})
        with open(os.path.join(self.reports_dir, "qa_reject_samples_{0}.jsonl".format(d_run)), "w", encoding="utf-8") as handle:
            handle.write(json.dumps({"run_id": d_run, "dat_payer_resolution_status": "resolved_from_context"}) + "\n")
        _write_json(os.path.join(self.reports_dir, "layer1_join_debug_summary_{0}.json".format(d_run)), {"run_id": d_run})
        with open(os.path.join(self.reports_dir, "layer1_join_debug_pack_{0}.txt".format(d_run)), "w", encoding="utf-8") as handle:
            handle.write("Layer 1 debug\n")
        with open(os.path.join(self.reports_dir, "artifact_triage_pack_{0}.txt".format(anchor)), "w", encoding="utf-8") as handle:
            handle.write("triage\n")
        with open(os.path.join(self.reports_dir, "run_artifact_index_{0}.txt".format(anchor)), "w", encoding="utf-8") as handle:
            handle.write("index\n")
        req = evidence_manifest.build_evidence_request(
            "run_evidence_bundle",
            "test",
            self.lab_root,
            anchor_run_id=anchor,
            recommendation_action_kind="review_dat_qa_full_block",
        )

        man = evidence_manifest.resolve_evidence_manifest(req)
        names = _archive_names(man)
        missing = [m.get("archive_name") for m in man.get("missing_required_evidence", []) if isinstance(m, dict)]

        self.assertIn("qa_canonical_summary_{0}.json".format(d_run), names)
        self.assertIn("qa_reject_samples_{0}.jsonl".format(d_run), names)
        self.assertIn("layer1_join_debug_summary_{0}.json".format(d_run), names)
        self.assertFalse(any("qa_canonical_summary_{0}.json".format(anchor) in (n or "") for n in missing))
        self.assertEqual(man.get("scope", {}).get("phase_d_artifact_run_id"), d_run)
        self.assertEqual(
            man.get("scope", {}).get("dat_payer_resolution_evidence_status"),
            "current_resolution_diagnostics_present",
        )

    def test_review_dat_qa_full_block_last_phase_d_run_id_beats_stale_phase_map(self):
        """Explicit last_phase_d_run_id on diagnostics_state must not lose to a stale cursor phase map."""
        evidence_manifest = _load_evidence_manifest()
        anchor = "shadow-anchor"
        d_correct = "phase-d-authoritative"
        d_stale_map = "phase-d-stale-map"
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_shadow_pipeline_run_id": anchor,
                "last_phase_d_run_id": d_correct,
            },
        )
        _write_json(
            os.path.join(self.lab_root, "run_cursor.json"),
            {"last_shadow_pipeline_phase_run_ids": {"D": d_stale_map}},
        )
        _write_json(
            os.path.join(self.reports_dir, "qa_canonical_summary_{0}.json".format(d_correct)),
            {"run_id": d_correct, "dat_payer_resolution_status": "ok"},
        )
        with open(os.path.join(self.reports_dir, "qa_reject_samples_{0}.jsonl".format(d_correct)), "w", encoding="utf-8") as handle:
            handle.write(json.dumps({"run_id": d_correct}) + "\n")
        _write_json(
            os.path.join(self.reports_dir, "layer1_join_debug_summary_{0}.json".format(d_correct)),
            {"run_id": d_correct},
        )
        with open(os.path.join(self.reports_dir, "layer1_join_debug_pack_{0}.txt".format(d_correct)), "w", encoding="utf-8") as handle:
            handle.write("Layer 1 debug\n")
        with open(os.path.join(self.reports_dir, "artifact_triage_pack_{0}.txt".format(anchor)), "w", encoding="utf-8") as handle:
            handle.write("triage\n")
        with open(os.path.join(self.reports_dir, "run_artifact_index_{0}.txt".format(anchor)), "w", encoding="utf-8") as handle:
            handle.write("index\n")
        req = evidence_manifest.build_evidence_request(
            "run_evidence_bundle",
            "test",
            self.lab_root,
            anchor_run_id=anchor,
            recommendation_action_kind="review_dat_qa_full_block",
        )
        man = evidence_manifest.resolve_evidence_manifest(req)
        names = _archive_names(man)
        self.assertIn("qa_canonical_summary_{0}.json".format(d_correct), names)
        self.assertNotIn("qa_canonical_summary_{0}.json".format(d_stale_map), names)
        self.assertEqual(man.get("scope", {}).get("phase_d_artifact_run_id"), d_correct)

    def test_review_dat_qa_full_block_request_phase_map_beats_live_phase_d_state(self):
        """Anchored run-evidence requests must not attach a later live Phase D context."""
        evidence_manifest = _load_evidence_manifest()
        anchor = "shadow-anchor"
        d_anchor = "phase-d-anchor"
        d_live = "phase-d-live"
        _write_json(
            os.path.join(self.lab_root, "diagnostics_state.json"),
            {
                "last_shadow_pipeline_run_id": anchor,
                "last_phase_d_run_id": d_live,
                "last_shadow_pipeline_phase_run_ids": {"D": d_live},
            },
        )
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {"last_phase_d_run_id": d_live})
        for rid in (d_anchor, d_live):
            _write_json(os.path.join(self.reports_dir, "qa_canonical_summary_{0}.json".format(rid)), {"run_id": rid})
            with open(os.path.join(self.reports_dir, "qa_reject_samples_{0}.jsonl".format(rid)), "w", encoding="utf-8") as handle:
                handle.write(json.dumps({"run_id": rid, "dat_payer_resolution_status": "resolved_from_context"}) + "\n")
            _write_json(os.path.join(self.reports_dir, "layer1_join_debug_summary_{0}.json".format(rid)), {"run_id": rid})
            with open(os.path.join(self.reports_dir, "layer1_join_debug_pack_{0}.txt".format(rid)), "w", encoding="utf-8") as handle:
                handle.write("Layer 1 debug\n")
        with open(os.path.join(self.reports_dir, "artifact_triage_pack_{0}.txt".format(anchor)), "w", encoding="utf-8") as handle:
            handle.write("triage\n")
        with open(os.path.join(self.reports_dir, "run_artifact_index_{0}.txt".format(anchor)), "w", encoding="utf-8") as handle:
            handle.write("index\n")
        req = evidence_manifest.build_evidence_request(
            "run_evidence_bundle",
            "test",
            self.lab_root,
            anchor_run_id=anchor,
            phase_run_id_map={"D": d_anchor},
            recommendation_action_kind="review_dat_qa_full_block",
        )
        man = evidence_manifest.resolve_evidence_manifest(req)
        names = _archive_names(man)
        self.assertIn("qa_canonical_summary_{0}.json".format(d_anchor), names)
        self.assertNotIn("qa_canonical_summary_{0}.json".format(d_live), names)
        self.assertEqual(man.get("scope", {}).get("phase_d_artifact_run_id"), d_anchor)
        self.assertEqual(man.get("scope", {}).get("phase_run_id_map", {}).get("D"), d_anchor)

    def test_run_evidence_phase_d_followup_marked_non_anchor_closure(self):
        evidence_manifest = _load_evidence_manifest()
        anchor = "shadow-anchor"
        d_anchor = "phase-d-anchor"
        d_live = "phase-d-live"
        _write_json(os.path.join(self.lab_root, "diagnostics_state.json"), {})
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})
        _write_json(os.path.join(self.reports_dir, "qa_canonical_summary_{0}.json".format(d_live)), {"run_id": d_live})
        with open(os.path.join(self.reports_dir, "qa_reject_samples_{0}.jsonl".format(d_live)), "w", encoding="utf-8") as handle:
            handle.write(json.dumps({"run_id": d_live}) + "\n")
        _write_json(
            os.path.join(self.reports_dir, "dat_anchor_failure_profile_{0}.json".format(d_live)),
            {"run_id": d_live, "schema_version": "dat_anchor_failure_profile_v1"},
        )
        with open(os.path.join(self.reports_dir, "dat_anchor_failure_profile_{0}.txt".format(d_live)), "w", encoding="utf-8") as handle:
            handle.write("DAT Anchor Failure Profile\n")
        with open(os.path.join(self.reports_dir, "run_evidence_phase_d_followup_note_{0}.txt".format(anchor)), "w", encoding="utf-8") as handle:
            handle.write("accepted_as_reviewed_anchor_milestone=False\n")
        req = evidence_manifest.build_evidence_request(
            "run_evidence_bundle",
            "test",
            self.lab_root,
            anchor_run_id=anchor,
            phase_run_id_map={"D": d_anchor},
            phase_d_artifact_run_id=d_anchor,
            phase_d_followup_run_id=d_live,
            phase_d_followup_anchor_run_id=anchor,
        )

        man = evidence_manifest.resolve_evidence_manifest(req)
        rows = {
            row.get("archive_name"): row
            for row in man.get("attachments", [])
            if isinstance(row, dict)
        }
        for name in (
                "qa_canonical_summary_{0}.json".format(d_live),
                "qa_reject_samples_{0}.jsonl".format(d_live),
                "dat_anchor_failure_profile_{0}.json".format(d_live),
                "dat_anchor_failure_profile_{0}.txt".format(d_live),
                "run_evidence_phase_d_followup_note_{0}.txt".format(anchor)):
            self.assertEqual(rows[name].get("source_kind"), "followup_only")
            self.assertEqual(rows[name].get("freshness"), "followup_only")
            self.assertEqual(rows[name].get("scope"), "phase_d_followup")
            self.assertEqual(rows[name].get("run_id"), d_live)
        self.assertEqual(man.get("scope", {}).get("phase_d_artifact_run_id"), d_anchor)
        self.assertEqual(man.get("scope", {}).get("phase_d_followup_run_id"), d_live)
        self.assertIn("phase_d_followup_not_anchor_closure", man.get("validation", {}).get("warnings", []))

    def test_review_dat_qa_full_block_marks_pre_resolution_diagnostics_stale(self):
        evidence_manifest = _load_evidence_manifest()
        rid = "phase-d-old"
        _write_json(os.path.join(self.lab_root, "diagnostics_state.json"), {
            "last_phase_d_run_id": rid,
            "last_phase_d_dat_telemetry": {
                "dat_selected_count": 4,
                "dat_qa_pass_count": 0,
                "dat_qa_reject_count": 4,
            },
            "phase_d_remediation": {
                "issue_code": "PHASE_D_DAT_QA_FULL_BLOCK",
                "status": "active",
            },
        })
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})
        _write_json(os.path.join(self.reports_dir, "qa_canonical_summary_{0}.json".format(rid)), {"run_id": rid})
        with open(os.path.join(self.reports_dir, "qa_reject_samples_{0}.jsonl".format(rid)), "w", encoding="utf-8") as handle:
            handle.write(json.dumps({"run_id": rid, "reject_reason": "QA_DAT_PAYER_ANCHOR_MISSING"}) + "\n")
        req = evidence_manifest.build_evidence_request(
            "run_evidence_bundle",
            "test",
            self.lab_root,
            anchor_run_id="shadow-anchor",
            recommendation_action_kind="review_dat_qa_full_block",
        )

        man = evidence_manifest.resolve_evidence_manifest(req)

        self.assertEqual(
            man.get("scope", {}).get("dat_payer_resolution_evidence_status"),
            "stale_pre_resolution_diagnostics",
        )
        self.assertEqual(
            man.get("scope", {}).get("layer1_runbook_key"),
            "phase_d_dat_qa_full_block_stale_diagnostics",
        )
        self.assertEqual(
            man.get("scope", {}).get("layer1_runbook_action_kind"),
            "phase_d_dat_verification_rerun",
        )
        self.assertIn(
            "dat_payer_resolution_diagnostics_stale_pre_resolution",
            man.get("validation", {}).get("warnings", []),
        )

    def test_review_dat_qa_full_block_marks_shadow_context_superseded_by_fresh_phase_d(self):
        evidence_manifest = _load_evidence_manifest()
        anchor = "shadow-anchor"
        d_run = "phase-d-fresh"
        _write_json(os.path.join(self.lab_root, "diagnostics_state.json"), {
            "last_shadow_pipeline_run_id": anchor,
            "last_phase_d_run_id": d_run,
            "phase_d_remediation": {
                "issue_code": "",
                "status": "resolved",
                "context_run_id": d_run,
            },
        })
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})
        _write_json(os.path.join(self.reports_dir, "qa_canonical_summary_{0}.json".format(d_run)), {
            "run_id": d_run,
            "dat_telemetry": {
                "dat_selected_count": 419,
                "dat_qa_pass_count": 397,
                "dat_qa_reject_count": 22,
                "dat_canonical_record_count": 1610,
            },
        })
        with open(os.path.join(self.reports_dir, "qa_reject_samples_{0}.jsonl".format(d_run)), "w", encoding="utf-8") as handle:
            handle.write(json.dumps({"run_id": d_run, "dat_payer_resolution_status": "resolved_from_context"}) + "\n")
        req = evidence_manifest.build_evidence_request(
            "run_evidence_bundle",
            "test",
            self.lab_root,
            anchor_run_id=anchor,
            recommendation_action_kind="review_dat_qa_full_block",
        )

        man = evidence_manifest.resolve_evidence_manifest(req)
        scope = man.get("scope", {})
        note = [
            row for row in man.get("attachments", [])
            if isinstance(row, dict) and row.get("archive_name") == "dat_qa_full_block_recommendation_lines.txt"
        ][0].get("inline_content", "")

        self.assertEqual(scope.get("dat_qa_full_block_context_status"), "superseded_by_fresh_phase_d_context")
        self.assertEqual(scope.get("phase_d_dat_qa_pass_count"), 397)
        self.assertEqual(scope.get("phase_d_dat_canonical_record_count"), 1610)
        self.assertIn("dat_qa_full_block_context_status=superseded_by_fresh_phase_d_context", note)
        self.assertIn("historical/superseded", note)
        self.assertIn(
            "dat_qa_full_block_context_superseded_by_fresh_phase_d",
            man.get("validation", {}).get("warnings", []),
        )


class OperatorEvidenceContractHelperTests(unittest.TestCase):
    def setUp(self):
        self.lab_root = tempfile.mkdtemp(prefix="mc_ev_ui_")
        self.reports_dir = os.path.join(self.lab_root, "reports")
        os.makedirs(self.reports_dir)

    def tearDown(self):
        shutil.rmtree(self.lab_root, ignore_errors=True)

    def test_manifest_enqueue_snapshot_omits_inline_payload(self):
        evidence_manifest = _load_evidence_manifest()
        man = {
            "schema_version": 1,
            "request": {"bundle_kind": "run_evidence_bundle"},
            "scope": {},
            "validation": {},
            "missing_required_evidence": [],
            "operator_contract": {},
            "attachments": [
                {
                    "archive_name": "n.txt",
                    "required": True,
                    "inline_content": "SECRET" * 100,
                    "scope": "x",
                    "source_kind": "inline",
                }
            ],
        }
        snap = evidence_manifest.manifest_enqueue_snapshot(man)
        self.assertTrue(snap.get("attachments_summary"))
        row = snap["attachments_summary"][0]
        self.assertTrue(row.get("has_inline_content"))
        self.assertGreater(int(row.get("inline_len", 0) or 0), 50)
        self.assertNotIn("inline_content", snap)

    def test_operator_evidence_contract_preview_lines_system_health(self):
        evidence_manifest = _load_evidence_manifest()
        _write_json(os.path.join(self.lab_root, "diagnostics_state.json"), {})
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})
        lines = evidence_manifest.operator_evidence_contract_preview_lines(
            self.lab_root,
            {"recommended_report_kind": "system_health_pack"},
        )
        self.assertTrue(any("attachment_contract_status=" in ln for ln in lines))


class RemittanceParseYieldManifestTests(unittest.TestCase):
    def setUp(self):
        self.lab_root = tempfile.mkdtemp(prefix="mc_ev_remit_")
        self.reports_dir = os.path.join(self.lab_root, "reports")
        os.makedirs(self.reports_dir)
        _write_json(os.path.join(self.lab_root, "diagnostics_state.json"), {})
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})

    def tearDown(self):
        shutil.rmtree(self.lab_root, ignore_errors=True)

    def _resolve(self, evidence_manifest, bundle_kind):
        req = evidence_manifest.build_evidence_request(
            bundle_kind,
            "unit_test",
            self.lab_root,
            anchor_run_id="run-remit",
        )
        return evidence_manifest.resolve_evidence_manifest(req)

    def test_remittance_parse_yield_latest_files_attach_for_system_health_and_run_evidence(self):
        evidence_manifest = _load_evidence_manifest()
        json_name = "remittance_parse_yield_latest.json"
        txt_name = "remittance_parse_yield_latest.txt"
        _write_json(
            os.path.join(self.reports_dir, json_name),
            {"sync_id": "sync-1", "persisted_claim_count": 2},
        )
        with open(os.path.join(self.reports_dir, txt_name), "w", encoding="utf-8") as handle:
            handle.write("remittance parser yield\n")

        for bundle_kind in ("system_health_pack", "run_evidence_bundle"):
            man = self._resolve(evidence_manifest, bundle_kind)
            names = _archive_names(man)
            rows = {
                row.get("archive_name"): row
                for row in man.get("attachments", [])
                if isinstance(row, dict)
            }
            meta = evidence_manifest.manifest_to_extra_meta(man)
            extra_files = evidence_manifest.manifest_to_extra_files(man)
            extra_file_names = [item[0] for item in extra_files]

            self.assertIn(json_name, names)
            self.assertIn(txt_name, names)
            self.assertEqual(rows[json_name].get("scope"), "local_runtime_latest")
            self.assertEqual(rows[txt_name].get("scope"), "local_runtime_latest")
            self.assertFalse(rows[json_name].get("required"))
            self.assertFalse(rows[txt_name].get("required"))
            self.assertIn(json_name, extra_file_names)
            self.assertIn(txt_name, extra_file_names)
            self.assertEqual(meta.get("remittance_parse_yield_present"), True)
            self.assertEqual(meta.get("remittance_parse_yield_json_attached"), True)
            self.assertEqual(meta.get("remittance_parse_yield_txt_attached"), True)
            self.assertEqual(
                meta.get("remittance_parse_yield_attachment_names"),
                [json_name, txt_name],
            )
            self.assertEqual(meta.get("remittance_parse_yield_scope"), "local_runtime_latest")

    def test_missing_remittance_parse_yield_latest_files_do_not_degrade_contract(self):
        evidence_manifest = _load_evidence_manifest()
        for bundle_kind in ("system_health_pack", "run_evidence_bundle"):
            man = self._resolve(evidence_manifest, bundle_kind)
            names = _archive_names(man)
            missing = [
                item.get("archive_name")
                for item in man.get("missing_required_evidence", [])
                if isinstance(item, dict)
            ]
            meta = evidence_manifest.manifest_to_extra_meta(man)

            self.assertNotIn("remittance_parse_yield_latest.json", names)
            self.assertNotIn("remittance_parse_yield_latest.txt", names)
            self.assertFalse(any((name or "").startswith("remittance_parse_yield") for name in missing))
            self.assertEqual(meta.get("attachment_contract_status"), "pass")
            self.assertEqual(meta.get("remittance_parse_yield_present"), False)
            self.assertEqual(meta.get("remittance_parse_yield_json_attached"), False)
            self.assertEqual(meta.get("remittance_parse_yield_txt_attached"), False)
            self.assertEqual(meta.get("remittance_parse_yield_attachment_names"), [])
            self.assertEqual(meta.get("remittance_parse_yield_scope"), "local_runtime_latest")
            self.assertNotIn("extra_meta", meta)


class ServiceLineInputPreviewManifestTests(unittest.TestCase):
    def setUp(self):
        self.lab_root = tempfile.mkdtemp(prefix="mc_ev_service_line_")
        self.reports_dir = os.path.join(self.lab_root, "reports")
        os.makedirs(self.reports_dir)
        _write_json(os.path.join(self.lab_root, "diagnostics_state.json"), {})
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})

    def tearDown(self):
        shutil.rmtree(self.lab_root, ignore_errors=True)

    def test_service_line_input_preview_manifest_is_review_only_without_raw_sidecar(self):
        evidence_manifest = _load_evidence_manifest()
        _write_json(os.path.join(self.lab_root, ".service_line_input_state.json"), {
            "workflow_name": "service_line_input",
            "claims_completion": True,
            "mutates_billing_state": True,
            "mutates_dat": True,
            "mutates_837p": True,
            "charges_entered": True,
        })
        _write_json(os.path.join(self.lab_root, ".option_a_minutes_status.json"), {
            "workflow_name": "legacy_option_a",
            "claims_completion": True,
            "charges_entered": True,
        })
        _write_json(os.path.join(self.reports_dir, "stale_service_line_input_837p.json"), {
            "claims_completion": True,
            "mutates_837p": True,
        })
        _write_json(os.path.join(self.reports_dir, "stale_service_line_input_dat.json"), {
            "mutates_dat": True,
            "charges_entered": True,
        })
        req = evidence_manifest.build_evidence_request(
            "service_line_input_preview",
            "unit_test",
            self.lab_root,
            service_line_input_session_id="service-line-session",
        )

        man = evidence_manifest.resolve_evidence_manifest(req)
        names = _archive_names(man)
        meta = evidence_manifest.manifest_to_extra_meta(man)
        extra_files = evidence_manifest.manifest_to_extra_files(man)
        extra_file_names = [item[0] for item in extra_files]

        self.assertEqual(meta.get("bundle_kind"), "service_line_input_preview")
        self.assertEqual(meta.get("service_line_input_workflow_name"), "service_line_input")
        self.assertEqual(meta.get("service_line_input_workflow_boundary"), "preview_only_review_required")
        self.assertEqual(meta.get("service_line_input_claims_completion"), False)
        self.assertEqual(meta.get("service_line_input_mutates_billing_state"), False)
        self.assertEqual(meta.get("service_line_input_mutates_dat"), False)
        self.assertEqual(meta.get("service_line_input_mutates_837p"), False)
        self.assertEqual(meta.get("service_line_input_charges_entered"), False)
        self.assertEqual(meta.get("service_line_input_raw_sidecar_attachment_policy"), "not_attached")
        self.assertEqual(meta.get("service_line_input_cleanup_readiness"), "not_ready")
        self.assertEqual(meta.get("service_line_input_cleanup_marker_count"), 4)
        self.assertIn("legacy_option_a_markers_present", meta.get("service_line_input_cleanup_blockers"))
        self.assertEqual(meta.get("service_line_input_session_id"), "service-line-session")
        self.assertEqual(meta.get("attachment_contract_status"), "pass")
        self.assertIn("service_line_input_preview_boundary.txt", names)
        self.assertIn("service_line_input_preview_boundary.txt", extra_file_names)
        self.assertNotIn(".service_line_input_state.json", names)
        self.assertNotIn(".option_a_minutes_status.json", names)
        self.assertNotIn("stale_service_line_input_837p.json", names)
        self.assertNotIn("stale_service_line_input_dat.json", names)

        assert_workflow_boundary_clean("service_line_input_preview_manifest", {
            "service_line_input_session_id": "service-line-session",
        }, [
            {
                "name": "service_line_input_preview_manifest",
                "role": "package",
                "identity": {"service_line_input_session_id": "service-line-session"},
                "status": "completed",
                "classification": "review_required",
                "terminal": True,
                "accepted": False,
                "claims_completion": False,
            },
            {
                "name": "raw_sidecar_attachment",
                "role": "artifact",
                "identity": {"service_line_input_session_id": "service-line-session"},
                "classification": "missing",
                "claims_completion": False,
            },
        ])

    def test_service_line_input_preview_manifest_summarizes_intake_telemetry_without_raw_jsonl(self):
        evidence_manifest = _load_evidence_manifest()
        telemetry_dir = os.path.join(self.lab_root, "telemetry")
        os.makedirs(telemetry_dir)
        telemetry_path = os.path.join(telemetry_dir, "service_line_input_crosswalk_intake_events.jsonl")
        with open(telemetry_path, "w") as handle:
            handle.write(json.dumps({
                "schema_version": "service_line_input_crosswalk_intake_save.v1",
                "workflow_boundary": "confirmed_config_update",
                "save_ok": True,
                "save_error": "",
                "changed_map_names": ["diagnosis_to_medisoft"],
                "changed_keys": ["H26.101", "00140"],
                "current_crosswalk_revalidation_source": "disk",
                "claims_completion": False,
                "mutates_837p": False,
            }))
            handle.write("\n")
        req = evidence_manifest.build_evidence_request(
            "service_line_input_preview",
            "unit_test",
            self.lab_root,
            service_line_input_session_id="service-line-session",
        )

        man = evidence_manifest.resolve_evidence_manifest(req)
        names = _archive_names(man)
        meta = evidence_manifest.manifest_to_extra_meta(man)
        extra_files = evidence_manifest.manifest_to_extra_files(man)
        extra_by_name = dict(extra_files)

        self.assertEqual(meta.get("service_line_input_crosswalk_intake_telemetry_present"), True)
        self.assertEqual(meta.get("service_line_input_crosswalk_intake_telemetry_event_count"), 1)
        self.assertEqual(
            meta.get("service_line_input_crosswalk_intake_telemetry_attachment_policy"),
            "summary_only_raw_jsonl_not_attached",
        )
        self.assertEqual(
            meta.get("service_line_input_crosswalk_intake_telemetry_latest_boundary"),
            "confirmed_config_update",
        )
        self.assertIn("service_line_input_crosswalk_intake_telemetry_summary.txt", names)
        self.assertIn(
            "latest_current_crosswalk_revalidation_source=disk",
            extra_by_name["service_line_input_crosswalk_intake_telemetry_summary.txt"],
        )
        self.assertNotIn("service_line_input_crosswalk_intake_events.jsonl", names)


class DiagnosticAttemptManifestTests(unittest.TestCase):
    def setUp(self):
        self.lab_root = tempfile.mkdtemp(prefix="mc_ev_attempt_")
        self.reports_dir = os.path.join(self.lab_root, "reports")
        os.makedirs(self.reports_dir)
        _write_json(os.path.join(self.lab_root, "diagnostics_state.json"), {})
        _write_json(os.path.join(self.lab_root, "run_cursor.json"), {})

    def tearDown(self):
        shutil.rmtree(self.lab_root, ignore_errors=True)

    def _resolve(self, evidence_manifest, bundle_kind):
        req = evidence_manifest.build_evidence_request(
            bundle_kind,
            "unit_test",
            self.lab_root,
            anchor_run_id="anchor-1",
            active_run_id="context-1",
        )
        return evidence_manifest.resolve_evidence_manifest(req)

    def test_diagnostic_attempt_files_attach_to_system_health_and_run_evidence(self):
        evidence_manifest = _load_evidence_manifest()
        _write_json(
            os.path.join(self.reports_dir, "diagnostic_attempt_anchor.json"),
            {"target_anchor_run_id": "anchor-1", "target_context_run_id": "context-1", "status": "completed"},
        )
        with open(os.path.join(self.reports_dir, "diagnostic_attempt_anchor.txt"), "w", encoding="utf-8") as handle:
            handle.write("anchored attempt\n")
        _write_json(
            os.path.join(self.reports_dir, "diagnostic_attempt_latest.json"),
            {"target_anchor_run_id": "other", "status": "active", "current_blocker": "running"},
        )
        with open(os.path.join(self.reports_dir, "diagnostic_attempt_latest.txt"), "w", encoding="utf-8") as handle:
            handle.write("latest active attempt\n")

        for bundle_kind in ("system_health_pack", "run_evidence_bundle"):
            man = self._resolve(evidence_manifest, bundle_kind)
            names = _archive_names(man)
            rows = {
                row.get("archive_name"): row
                for row in man.get("attachments", [])
                if isinstance(row, dict)
            }
            extra_names = [item[0] for item in evidence_manifest.manifest_to_extra_files(man)]
            meta = evidence_manifest.manifest_to_extra_meta(man)

            self.assertIn("diagnostic_attempt_anchor.json", names)
            self.assertIn("diagnostic_attempt_anchor.txt", names)
            self.assertNotIn("diagnostic_attempt_latest.json", names)
            self.assertNotIn("diagnostic_attempt_latest.txt", names)
            self.assertIn("diagnostic_attempt_anchor.json", extra_names)
            self.assertEqual(rows["diagnostic_attempt_anchor.json"].get("scope"), "diagnostic_attempt_contract")
            self.assertEqual(rows["diagnostic_attempt_anchor.json"].get("run_id"), "anchor-1")
            self.assertEqual(rows["diagnostic_attempt_anchor.json"].get("hash_status"), "ok")
            self.assertTrue(rows["diagnostic_attempt_anchor.json"].get("content_sha256"))
            self.assertTrue(rows["diagnostic_attempt_anchor.json"].get("size_bytes") > 0)
            self.assertEqual(rows["diagnostic_attempt_anchor.json"].get("review_role"), "primary_evidence")
            self.assertTrue((man.get("scope") or {}).get("bundle_review_group"))
            self.assertEqual(man.get("bundle_review_group"), (man.get("scope") or {}).get("bundle_review_group"))
            self.assertEqual(meta.get("diagnostic_attempt_attachment_count"), 2)
            self.assertTrue(meta.get("diagnostic_attempt_ignored_mismatch_count", 0) >= 1)
            self.assertEqual(meta.get("bundle_review_group"), man.get("bundle_review_group"))
            self.assertEqual(meta.get("diagnostic_attempt_scope_anchor_run_id"), "anchor-1")
            self.assertEqual(meta.get("diagnostic_attempt_scope_context_run_id"), "context-1")
            assert_workflow_boundary_clean(
                "diagnostic_attempt_bundle_scope",
                {"anchor_run_id": "anchor-1", "context_run_id": "context-1"},
                [
                    {
                        "name": "diagnostic_attempt_anchor",
                        "role": "attachment",
                        "identity": {"anchor_run_id": "anchor-1", "context_run_id": "context-1"},
                        "status": "completed",
                        "accepted": True,
                    },
                    {
                        "name": "diagnostic_attempt_latest",
                        "role": "attachment_candidate",
                        "identity": {"anchor_run_id": "other"},
                        "status": "active",
                        "classification": "ignored_mismatch",
                    },
                    {
                        "name": "run_evidence_bundle",
                        "role": "package",
                        "identity": {"anchor_run_id": "anchor-1", "context_run_id": "context-1"},
                        "classification": "review_required",
                    },
                ],
            )

    def test_phase_d_diagnostic_attempt_context_can_match_anchor_phase_d_run(self):
        evidence_manifest = _load_evidence_manifest()
        _write_json(
            os.path.join(self.reports_dir, "diagnostic_attempt_phase_d_manual_same_anchor_d.json"),
            {
                "target_anchor_run_id": "anchor-1",
                "target_context_run_id": "phase-d-1",
                "status": "completed",
                "accepted_for_anchor": True,
            },
        )
        with open(os.path.join(self.reports_dir, "diagnostic_attempt_phase_d_manual_same_anchor_d.txt"), "w", encoding="utf-8") as handle:
            handle.write("same anchor phase d attempt\n")

        req = evidence_manifest.build_evidence_request(
            "run_evidence_bundle",
            "unit_test",
            self.lab_root,
            anchor_run_id="anchor-1",
            active_run_id="anchor-1",
            phase_d_artifact_run_id="phase-d-1",
        )
        man = evidence_manifest.resolve_evidence_manifest(req)
        names = _archive_names(man)
        meta = evidence_manifest.manifest_to_extra_meta(man)

        self.assertIn("diagnostic_attempt_phase_d_manual_same_anchor_d.json", names)
        self.assertIn("diagnostic_attempt_phase_d_manual_same_anchor_d.txt", names)
        self.assertEqual(meta.get("diagnostic_attempt_attachment_count"), 2)
        self.assertEqual(meta.get("diagnostic_attempt_scope_anchor_run_id"), "anchor-1")
        self.assertEqual(meta.get("diagnostic_attempt_scope_context_run_id"), "anchor-1")

    def test_unrelated_stale_diagnostic_attempt_does_not_override_anchored_scope(self):
        evidence_manifest = _load_evidence_manifest()
        _write_json(
            os.path.join(self.reports_dir, "diagnostic_attempt_anchor.json"),
            {"target_anchor_run_id": "anchor-1", "status": "completed"},
        )
        _write_json(
            os.path.join(self.reports_dir, "diagnostic_attempt_stale_other.json"),
            {"target_anchor_run_id": "other", "status": "completed"},
        )
        with open(os.path.join(self.reports_dir, "diagnostic_attempt_stale_other.txt"), "w", encoding="utf-8") as handle:
            handle.write("stale unrelated\n")

        man = self._resolve(evidence_manifest, "run_evidence_bundle")
        names = _archive_names(man)

        self.assertIn("diagnostic_attempt_anchor.json", names)
        self.assertNotIn("diagnostic_attempt_stale_other.json", names)
        self.assertNotIn("diagnostic_attempt_stale_other.txt", names)

    def test_db_hydration_note_attaches_to_run_evidence_and_cloud_health(self):
        evidence_manifest = _load_evidence_manifest()

        for bundle_kind in ("run_evidence_bundle", "cloud_health_escalation"):
            man = self._resolve(evidence_manifest, bundle_kind)
            name = "run_evidence_db_hydration_note_anchor-1.txt"
            rows = {
                row.get("archive_name"): row
                for row in man.get("attachments", [])
                if isinstance(row, dict)
            }
            self.assertIn(name, rows)
            self.assertEqual(rows[name].get("scope"), "db_hydration_cumulative_lab_state")
            self.assertEqual(rows[name].get("source_kind"), "cumulative_db_health")
            self.assertEqual(rows[name].get("run_id"), "anchor-1")
            with open(rows[name].get("source_path"), "r", encoding="utf-8") as handle:
                body = handle.read()
            self.assertIn("Run Evidence DB Hydration Note", body)
            self.assertIn("scope=cumulative_lab_db_state", body)

    def test_support_preflight_latest_attaches_as_live_status_not_anchor_evidence(self):
        evidence_manifest = _load_evidence_manifest()
        for name in ("support_send_stale_preflight_latest.txt", "support_send_stale_preflight_latest.json"):
            path = os.path.join(self.reports_dir, name)
            with open(path, "w", encoding="utf-8") as handle:
                if name.endswith(".json"):
                    json.dump({"job_id": "job-live", "status": "running"}, handle)
                else:
                    handle.write("support_send_stale_preflight\n")

        man = self._resolve(evidence_manifest, "run_evidence_bundle")
        rows = {
            row.get("archive_name"): row
            for row in man.get("attachments", [])
            if isinstance(row, dict)
        }

        for name in ("support_send_stale_preflight_latest.txt", "support_send_stale_preflight_latest.json"):
            self.assertIn(name, rows)
            self.assertEqual(rows[name].get("scope"), "live_support_queue_status")
            self.assertEqual(rows[name].get("source_kind"), "live_status")
            self.assertEqual(rows[name].get("freshness"), "live_status")
            self.assertEqual(rows[name].get("run_id"), "")

    def test_diagnostic_attempt_collector_api_is_used_when_available(self):
        evidence_manifest = _load_evidence_manifest()
        calls = []
        api_path = os.path.join(self.reports_dir, "diagnostic_attempt_api.json")
        _write_json(api_path, {"anchor_run_id": "anchor-1"})

        class FakeAttemptsModule(object):
            @staticmethod
            def collect_bundle_attempt_files(lab_root, anchor_run_id="", context_run_id="", include_latest=True):
                calls.append((lab_root, anchor_run_id, context_run_id, include_latest))
                return [("diagnostic_attempt_api.json", api_path)]

        import MediCafe
        old_module = sys.modules.get("MediCafe.diagnostic_attempts")
        old_attr = getattr(MediCafe, "diagnostic_attempts", None)
        had_attr = hasattr(MediCafe, "diagnostic_attempts")
        sys.modules["MediCafe.diagnostic_attempts"] = FakeAttemptsModule
        MediCafe.diagnostic_attempts = FakeAttemptsModule
        try:
            man = self._resolve(evidence_manifest, "system_health_pack")
        finally:
            if old_module is None:
                try:
                    del sys.modules["MediCafe.diagnostic_attempts"]
                except KeyError:
                    pass
            else:
                sys.modules["MediCafe.diagnostic_attempts"] = old_module
            if had_attr:
                MediCafe.diagnostic_attempts = old_attr
            else:
                try:
                    delattr(MediCafe, "diagnostic_attempts")
                except AttributeError:
                    pass

        self.assertEqual(calls, [(self.lab_root, "anchor-1", "context-1", True)])
        self.assertIn("diagnostic_attempt_api.json", _archive_names(man))

    def test_diagnostic_attempt_collector_wrong_target_is_final_guarded(self):
        evidence_manifest = _load_evidence_manifest()
        api_path = os.path.join(self.reports_dir, "diagnostic_attempt_api_wrong.json")
        _write_json(api_path, {"anchor_run_id": "other-anchor", "status": "completed"})

        class FakeAttemptsModule(object):
            @staticmethod
            def collect_bundle_attempt_files(lab_root, anchor_run_id="", context_run_id="", include_latest=True):
                return [("diagnostic_attempt_api_wrong.json", api_path)]

        import MediCafe
        old_module = sys.modules.get("MediCafe.diagnostic_attempts")
        old_attr = getattr(MediCafe, "diagnostic_attempts", None)
        had_attr = hasattr(MediCafe, "diagnostic_attempts")
        sys.modules["MediCafe.diagnostic_attempts"] = FakeAttemptsModule
        MediCafe.diagnostic_attempts = FakeAttemptsModule
        try:
            man = self._resolve(evidence_manifest, "run_evidence_bundle")
        finally:
            if old_module is None:
                try:
                    del sys.modules["MediCafe.diagnostic_attempts"]
                except KeyError:
                    pass
            else:
                sys.modules["MediCafe.diagnostic_attempts"] = old_module
            if had_attr:
                MediCafe.diagnostic_attempts = old_attr
            else:
                try:
                    delattr(MediCafe, "diagnostic_attempts")
                except AttributeError:
                    pass

        self.assertNotIn("diagnostic_attempt_api_wrong.json", _archive_names(man))
        meta = evidence_manifest.manifest_to_extra_meta(man)
        self.assertEqual(meta.get("diagnostic_attempt_attachment_count"), 0)
        self.assertTrue(meta.get("diagnostic_attempt_ignored_mismatch_count", 0) >= 1)


if __name__ == "__main__":
    unittest.main()
