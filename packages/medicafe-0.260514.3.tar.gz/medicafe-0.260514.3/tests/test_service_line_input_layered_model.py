#!/usr/bin/env python
from __future__ import print_function

import copy
import os
import sys

_TESTS_ROOT = os.path.dirname(os.path.abspath(__file__))
if _TESTS_ROOT not in sys.path:
    sys.path.insert(0, _TESTS_ROOT)

from workflow_boundary_contract import assert_workflow_boundary_clean

from MediCafe import service_line_input_model as model


def test_target_identity_normalizes_dos_defaults_and_preserves_legacy_row_key():
    identity = model.build_service_line_target_identity(
        patient_id=" 000123 ",
        dos="2026/01/20",
        docx_position="7",
    )

    assert identity == {
        "patient_id": "000123",
        "dos": "01-20-2026",
        "service_line_kind": "anesthesia",
        "line_ordinal": 1,
        "docx_position": 7,
    }
    assert model.build_legacy_service_line_row_key(
        identity["patient_id"],
        identity["dos"],
    ) == "000123|01-20-2026"
    assert model.build_service_line_row_key(
        identity["patient_id"],
        identity["dos"],
        identity["service_line_kind"],
        identity["line_ordinal"],
    ) == "000123|01-20-2026|anesthesia|1"
    parsed_layered = model.parse_legacy_service_line_row_key(
        "000123|01-20-2026|anesthesia|1",
    )
    assert parsed_layered == ("000123", "01-20-2026")

    patient_id, dos = model.parse_legacy_service_line_row_key(" 000123 | 01/20/2026 ")
    assert patient_id == "000123"
    assert dos == "01-20-2026"

    legacy_identity = model.build_service_line_target_identity(
        legacy_row_key="000123|01/20/2026",
    )
    assert legacy_identity["patient_id"] == "000123"
    assert legacy_identity["dos"] == "01-20-2026"
    assert legacy_identity["service_line_kind"] == "anesthesia"
    assert legacy_identity["line_ordinal"] == 1


def test_code_and_dos_normalization_match_current_service_line_formats():
    assert model.normalize_dos_string("01/20/2026") == "01-20-2026"
    assert model.normalize_dos_string("2026-01-20") == "01-20-2026"
    assert model.normalize_dos_string("01-20-2026 00:00:00") == "01-20-2026"
    assert model.normalize_diagnosis_code(" h25.812 ") == "H25812"
    assert model.normalize_cpt_code(" 00142-aa ") == "00142AA"


def test_effective_row_resolver_uses_operator_overlay_over_crosswalk_docx_and_fallback():
    docx_row = {
        "patient_id": "1",
        "dos": "01/20/2026",
        "diagnosis": "H25.812",
        "cpt": "12345",
        "docx_position": 3,
    }
    fallback = {
        "patient_id": "1",
        "dos": "01-20-2026",
        "diagnosis": "FALLBACK",
        "cpt": "99999",
        "status": "PENDING",
    }
    crosswalk = {
        "diagnosis_to_procedure": {
            "H25.812": "00142",
        },
    }
    overlay = {
        "target_identity": {
            "patient_id": "1",
            "dos": "2026-01-20",
        },
        "corrections": {
            "cpt": " 66984 ",
            "status": "ENTERED",
        },
    }

    effective = model.resolve_effective_service_line_row(
        docx_row=docx_row,
        crosswalk=crosswalk,
        operator_overlay=overlay,
        fallback=fallback,
    )

    assert effective["cpt"] == "66984"
    assert effective["cpt_source"] == "operator_overlay"
    assert effective["cpt_confidence"] == "operator_confirmed"
    assert effective["cpt_status"] == "operator_corrected"
    assert effective["diagnosis"] == "H25.812"
    assert effective["status"] == "ENTERED"
    assert effective["patient_id"] == "1"
    assert effective["dos"] == "01-20-2026"
    assert effective["docx_position"] == 3
    assert effective["operator_overlay_applied"] is True


def test_effective_row_field_level_precedence_for_diagnosis_cpt_minutes_and_charge():
    effective = model.resolve_effective_service_line_row(
        fallback={
            "patient_id": "1",
            "dos": "01-20-2026",
            "diagnosis": "FALLBACK",
            "cpt": "99999",
            "minutes": "9",
            "charge_display": "$111",
        },
        docx_row={
            "patient_id": "1",
            "dos": "01-20-2026",
            "diagnosis": "H25.812",
            "cpt": "12345",
            "minutes": "12",
            "charge_display": "$222",
        },
        crosswalk={
            "diagnosis_to_procedure": {
                "H25.812": "00142",
            },
        },
        operator_overlay={
            "target_identity": {
                "patient_id": "1",
                "dos": "01-20-2026",
            },
            "values": {
                "minutes": "18",
                "charge_display": "$540",
            },
        },
    )

    assert effective["diagnosis"] == "H25.812"
    assert effective["diagnosis_normalized"] == "H25812"
    assert effective["cpt"] == "00142"
    assert effective["cpt_source"] == "crosswalk.diagnosis_to_procedure"
    assert effective["minutes"] == "18"
    assert effective["minutes_normalized"] == 18
    assert effective["charge_display"] == "$540"
    assert effective["workflow_boundary"] == "preview_only_review_required"
    assert effective["claims_completion"] is False
    assert effective["mutates_billing_state"] is False


def test_operator_diagnosis_and_cpt_override_preserved_over_crosswalk_prediction():
    effective = model.resolve_effective_service_line_row(
        docx_row={
            "patient_id": "1",
            "dos": "01-20-2026",
            "diagnosis": "H25.812",
            "cpt": "12345",
        },
        crosswalk={
            "diagnosis_to_procedure": {
                "H25.812": "00142",
                "H40.11X2": "00140",
            },
        },
        operator_overlay={
            "target_identity": {
                "patient_id": "1",
                "dos": "01-20-2026",
            },
            "corrections": {
                "diagnosis": "H40.11X2",
                "cpt": " 66984 ",
            },
        },
    )

    assert effective["diagnosis"] == "H40.11X2"
    assert effective["diagnosis_normalized"] == "H4011X2"
    assert effective["cpt"] == "66984"
    assert effective["cpt_source"] == "operator_overlay"
    assert effective["cpt_confidence"] == "operator_confirmed"
    assert effective["cpt_status"] == "operator_corrected"


def test_crosswalk_cpt_prediction_overrides_docx_observation_with_source_confidence():
    effective = model.resolve_effective_service_line_row(
        docx_row={
            "patient_id": "1",
            "dos": "01-20-2026",
            "diagnosis": "H25.812",
            "cpt": "12345",
        },
        crosswalk={
            "diagnosis_to_procedure": {
                "H25.812": "00142",
            },
        },
        fallback={
            "cpt": "99999",
        },
    )

    assert effective["cpt"] == "00142"
    assert effective["cpt_source"] == "crosswalk.diagnosis_to_procedure"
    assert effective["cpt_confidence"] == "crosswalk_confirmed"
    assert effective["cpt_status"] == "suggested"
    assert effective["diagnosis_normalized"] == "H25812"


def test_medisoft_shorthand_and_icd10_diagnosis_predict_same_cpt():
    crosswalk = {
        "diagnosis_to_medisoft": {
            "H25.811": "25811",
        },
        "diagnosis_to_procedure": {
            "H25.811": "00142",
        },
    }

    shorthand = model.predict_cpt_from_crosswalk(crosswalk, "25811")
    icd10 = model.predict_cpt_from_crosswalk(crosswalk, "H25.811")

    assert model.normalize_diagnosis_code("25811") == "25811"
    assert model.normalize_diagnosis_code("H25.811") == "H25811"
    assert shorthand["cpt"] == "00142"
    assert icd10["cpt"] == "00142"
    assert shorthand["cpt_prediction_diagnosis_code"] == "H25.811"
    assert icd10["cpt_prediction_diagnosis_code"] == "H25.811"


def test_ambiguous_medisoft_shorthand_does_not_predict_cpt():
    crosswalk = {
        "diagnosis_to_medisoft": {
            "H25.811": "25811",
            "H25.812": "25811",
        },
        "diagnosis_to_procedure": {
            "H25.811": "00142",
            "H25.812": "00145",
        },
    }

    assert model.predict_cpt_from_crosswalk(crosswalk, "25811") == {}
    assert model.predict_cpt_from_crosswalk(crosswalk, "H25.811")["cpt"] == "00142"


def test_crosswalk_intake_patch_updates_all_three_maps_without_billing_custody():
    crosswalk = {
        "diagnosis_to_medisoft": {
            "H25.812": "25812",
        },
        "diagnosis_to_procedure": {
            "H25.812": "00142",
        },
        "procedure_to_diagnosis": {
            "00142": ["H25.812"],
        },
    }

    patch = model.build_service_line_crosswalk_intake_patch(
        crosswalk,
        "H26.101",
        "26101",
        "00140",
        source={"typed_value": "H26.101"},
    )
    merged, report = model.merge_crosswalk_with_service_line_intake_patch(crosswalk, patch)

    assert patch["workflow_boundary"] == "confirmed_config_update"
    assert patch["valid"] is True
    assert patch["claim_workflow_completion"] is False
    assert patch["mutates_dat"] is False
    assert patch["mutates_837p"] is False
    assert patch["charges_entered"] is False
    assert report["workflow_boundary"] == "confirmed_config_update"
    assert report["changed"] is True
    assert report["diagnosis_to_medisoft_upserted"] == 1
    assert report["diagnosis_to_procedure_upserted"] == 1
    assert report["procedure_to_diagnosis_added"] == 1
    assert merged["diagnosis_to_medisoft"]["H26.101"] == "26101"
    assert merged["diagnosis_to_procedure"]["H26.101"] == "00140"
    assert "H26.101" in merged["procedure_to_diagnosis"]["00140"]
    assert "H26.101" not in crosswalk["diagnosis_to_medisoft"]


def test_crosswalk_intake_patch_rejects_conflicting_bridge():
    crosswalk = {
        "diagnosis_to_medisoft": {
            "H25.811": "25811",
        },
        "diagnosis_to_procedure": {
            "H25.811": "00142",
        },
        "procedure_to_diagnosis": {
            "00142": ["H25.811"],
        },
    }

    patch = model.build_service_line_crosswalk_intake_patch(
        crosswalk,
        "H25.812",
        "25811",
        "00142",
    )
    merged, report = model.merge_crosswalk_with_service_line_intake_patch(crosswalk, patch)

    assert patch["valid"] is False
    assert patch["conflicts"]
    assert report["changed"] is False
    assert report["error"] == "service_line_crosswalk_intake_patch_not_valid"
    assert merged == crosswalk


def test_crosswalk_intake_event_and_boundary_do_not_claim_billing_custody():
    patch = model.build_service_line_crosswalk_intake_patch(
        {},
        "H26.101",
        "26101",
        "00140",
    )
    _merged, report = model.merge_crosswalk_with_service_line_intake_patch({}, patch)
    event = model.build_service_line_crosswalk_intake_event(
        {
            "patient_id": "1",
            "dos": "01-20-2026",
            "line_ordinal": 1,
        },
        patch,
        apply_report=report,
        save_ok=True,
        message="Crosswalk updated; Service Line Input row updated.",
    )

    assert event["workflow_boundary"] == "confirmed_config_update"
    assert event["target_identity"]["patient_id"] == "1"
    assert event["target_identity"]["dos"] == "01-20-2026"
    assert event["save_ok"] is True
    assert event["claims_completion"] is False
    assert event["mutates_billing_state"] is False
    assert event["mutates_dat"] is False
    assert event["mutates_837p"] is False
    assert event["charges_entered"] is False

    assert_workflow_boundary_clean("service_line_input_crosswalk_intake", {
        "patient_id": "1",
        "dos": "01-20-2026",
    }, [
        {
            "name": "unknown_code_intake_attempt",
            "role": "attempt",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "completed",
            "accepted": True,
        },
        {
            "name": "crosswalk_config_patch",
            "role": "state",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "status": "completed",
            "classification": "review_required",
            "claims_completion": False,
        },
        {
            "name": "dat_export_absent",
            "role": "artifact",
            "identity": {"patient_id": "1", "dos": "01-20-2026"},
            "classification": "missing",
            "claims_completion": False,
        },
        {
            "name": "wrong_dos_intake_event",
            "role": "artifact",
            "identity": {"patient_id": "1", "dos": "01-21-2026"},
            "classification": "ignored_mismatch",
            "claims_completion": False,
        },
    ])


def test_candidate_package_is_review_only_and_shapes_service_line_rows():
    package = model.build_service_line_candidate_package("session-1", [{
        "patient_id": "1",
        "dos": "2026-01-20",
        "diagnosis": "H25.811",
        "cpt": "00142",
        "minutes": "12",
        "status": "ENTERED",
        "charge_display": "$450",
        "charge_amount": "450.00",
        "charge_rule_id": "baseline_5_15",
        "charge_source": "baseline_minutes_tier",
        "line_ordinal": "2",
        "docx_position": "2",
        "claims_completion": True,
        "mutates_billing_state": True,
        "charges_entered": True,
    }], generated_at_utc="2026-01-20T00:00:00Z")

    row = package["candidate_rows"][0]
    assert package["schema_version"] == "service_line_input_candidate_package.v1"
    assert package["workflow_boundary"] == "preview_only_review_required"
    assert package["claims_completion"] is False
    assert package["mutates_billing_state"] is False
    assert package["charges_entered"] is False
    assert package["review_completion"]["service_line_input_review_complete"] is True
    assert row["schema_version"] == "service_line_input_candidate_row.v1"
    assert row["service_line_row_key"] == "1|01-20-2026|anesthesia|2"
    assert row["diagnosis_normalized"] == "H25811"
    assert row["cpt_code"] == "00142"
    assert row["minutes_normalized"] == 12
    assert row["claims_completion"] is False
    assert row["mutates_billing_state"] is False
    assert row["charges_entered"] is False
    report = model.format_service_line_candidate_report_text(package)
    assert "Service Line Input Review Summary" in report
    assert "Billing custody: claims_completion=False" in report


def test_parity_report_compares_candidate_rows_to_downstream_without_custody():
    candidates = [{
        "patient_id": "1",
        "dos": "01-20-2026",
        "line_ordinal": 1,
        "diagnosis": "H25.811",
        "cpt": "00142",
        "minutes": "12",
        "charge_amount": "450.00",
        "status": "ENTERED",
    }, {
        "patient_id": "2",
        "dos": "01-20-2026",
        "line_ordinal": 1,
        "diagnosis": "H25.812",
        "cpt": "00142",
        "minutes": "18",
        "charge_amount": "540.00",
        "status": "ENTERED",
    }]
    downstream = [{
        "patient_id": "1",
        "dos": "01-20-2026",
        "line_ordinal": 1,
        "diagnosis": "H25.811",
        "cpt": "00142",
        "minutes": "12",
        "charge_amount": "$450.00",
    }, {
        "patient_id": "9",
        "dos": "01-20-2026",
        "line_ordinal": 1,
        "diagnosis": "H25.811",
        "cpt": "00142",
        "minutes": "12",
        "charge_amount": "450.00",
    }]

    report = model.build_service_line_parity_report(
        "session-1",
        candidates,
        downstream,
        validation_id="dat-837p-review",
        generated_at_utc="2026-01-20T00:00:00Z",
    )

    assert report["schema_version"] == "service_line_input_parity_report.v1"
    assert report["workflow_boundary"] == "preview_only_review_required"
    assert report["exact_match_count"] == 1
    assert report["missing_downstream_count"] == 1
    assert report["unrelated_downstream_count"] == 1
    assert report["prediction_accuracy"] == 0.5
    assert report["claims_completion"] is False
    assert report["mutates_dat"] is False
    assert report["mutates_837p"] is False
    assert report["charges_entered"] is False


def test_overlay_event_records_changes_without_billing_custody():
    previous = {
        "patient_id": "1",
        "dos": "01-20-2026",
        "diagnosis": "H25.811",
        "cpt": "00142",
        "minutes": "12",
        "status": "ENTERED",
    }
    current = dict(previous)
    current["cpt"] = "00145"
    current["minutes"] = "18"

    event = model.build_service_line_overlay_event(
        previous,
        current,
        "session-1",
        action="operator_corrected",
        generated_at_utc="2026-01-20T00:00:00Z",
    )

    assert event["schema_version"] == "service_line_input_overlay_event.v1"
    assert event["workflow_boundary"] == "preview_only_review_required"
    assert event["changed_fields"]["cpt_code"]["before"] == "00142"
    assert event["changed_fields"]["cpt_code"]["after"] == "00145"
    assert event["effective_after"]["diagnosis_code"] == "H25.811"
    assert event["effective_after"]["cpt_code"] == "00145"
    assert event["claims_completion"] is False
    assert event["mutates_billing_state"] is False
    assert event["charges_entered"] is False


def test_cleanup_readiness_reports_legacy_markers_without_deleting_anything():
    report = model.build_service_line_cleanup_readiness_report(
        [{"marker": "SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP"}],
        release_cycle_complete=False,
    )

    assert report["schema_version"] == "service_line_input_cleanup_readiness.v1"
    assert report["cleanup_readiness"] == "not_ready"
    assert report["legacy_marker_count"] == 1
    assert "release_cycle_validation_not_confirmed" in report["blockers"]
    assert report["claims_completion"] is False


def test_wrong_target_operator_overlay_is_ignored():
    effective = model.resolve_effective_service_line_row(
        docx_row={
            "patient_id": "1",
            "dos": "01-20-2026",
            "diagnosis": "H25.812",
        },
        crosswalk={
            "diagnosis_to_procedure": {
                "H25.812": "00142",
                "H40.11X2": "00140",
            },
        },
        operator_overlay={
            "target_identity": {
                "patient_id": "2",
                "dos": "01-20-2026",
            },
            "corrections": {
                "diagnosis": "H40.11X2",
                "cpt": "66984",
                "status": "ENTERED",
            },
        },
    )

    assert effective["patient_id"] == "1"
    assert effective["dos"] == "01-20-2026"
    assert effective["diagnosis"] == "H25.812"
    assert effective["cpt"] == "00142"
    assert effective["cpt_source"] == "crosswalk.diagnosis_to_procedure"
    assert effective["operator_overlay_applied"] is False
    assert effective["operator_overlay_ignored"] is True
    assert effective.get("status") != "ENTERED"


def test_stale_same_patient_overlay_with_wrong_docx_position_is_ignored():
    effective = model.resolve_effective_service_line_row(
        docx_row={
            "patient_id": "1",
            "dos": "01-20-2026",
            "diagnosis": "H25.812",
            "docx_position": 3,
        },
        crosswalk={
            "diagnosis_to_procedure": {
                "H25.812": "00142",
                "H40.11X2": "00140",
            },
        },
        operator_overlay={
            "target_identity": {
                "patient_id": "1",
                "dos": "01-20-2026",
                "docx_position": 9,
            },
            "corrections": {
                "diagnosis": "H40.11X2",
                "cpt": "66984",
                "minutes": "18",
            },
        },
    )

    assert effective["docx_position"] == 3
    assert effective["diagnosis"] == "H25.812"
    assert effective["cpt"] == "00142"
    assert "minutes" not in effective
    assert effective["operator_overlay_applied"] is False
    assert effective["operator_overlay_ignored"] is True


def test_effective_row_resolver_does_not_mutate_docx_row_or_crosswalk():
    docx_row = {
        "patient_id": "1",
        "dos": "01-20-2026",
        "diagnosis": "H25.812",
        "cpt": "12345",
        "source": {
            "docx_position": 1,
        },
    }
    crosswalk = {
        "diagnosis_to_medisoft": {
            "H25.812": "H25.812",
        },
        "diagnosis_to_procedure": {
            "H25.812": "00142",
        },
    }
    original_docx = copy.deepcopy(docx_row)
    original_crosswalk = copy.deepcopy(crosswalk)

    effective = model.resolve_effective_service_line_row(
        docx_row=docx_row,
        crosswalk=crosswalk,
        operator_overlay={
            "target_identity": {
                "patient_id": "1",
                "dos": "01-20-2026",
            },
            "corrections": {
                "minutes": "12",
            },
        },
    )

    assert effective["cpt"] == "00142"
    assert effective["minutes"] == "12"
    assert docx_row == original_docx
    assert crosswalk == original_crosswalk


def test_review_complete_status_sets_review_flags_without_billing_completion():
    effective = model.resolve_effective_service_line_row(
        docx_row={
            "patient_id": "1",
            "dos": "01-20-2026",
            "diagnosis": "H25.812",
        },
        operator_overlay={
            "target_identity": {
                "patient_id": "1",
                "dos": "01-20-2026",
            },
            "values": {
                "review_status": "COMPLETED",
                "minutes": "18",
            },
        },
    )

    assert effective["review_status"] == "review_complete"
    assert effective["service_line_review_status"] == "review_complete"
    assert effective["service_line_review_complete"] is True
    assert effective["review_complete_claims_completion"] is False
    assert effective["claims_completion"] is False
    assert effective["mutates_billing_state"] is False
    assert effective["billing_boundary_review_only"] is True
    validation = model.validate_service_line_preview_boundary(effective)
    assert validation["boundary_clean"] is True
    assert validation["violations"] == []


def test_complete_target_fields_fills_identity_row_keys_and_effective_shape():
    shaped = model.shape_effective_service_line_row({
        "Patient ID": " 000123 ",
        "Surgery Date": "2026/01/20",
        "line_ordinal": "2",
        "docx_position": "4",
        "diagnosis_code": " h25.812 ",
        "CPT Code": " 00142-aa ",
        "entered_minutes": "15",
        "amount": "450.00",
        "display_charge": "$450",
        "review_state": "ready",
    })

    assert shaped["patient_id"] == "000123"
    assert shaped["dos"] == "01-20-2026"
    assert shaped["service_line_kind"] == "anesthesia"
    assert shaped["line_ordinal"] == 2
    assert shaped["docx_position"] == 4
    assert shaped["target_identity"] == {
        "patient_id": "000123",
        "dos": "01-20-2026",
        "service_line_kind": "anesthesia",
        "line_ordinal": 2,
        "docx_position": 4,
    }
    assert shaped["legacy_row_key"] == "000123|01-20-2026"
    assert shaped["service_line_row_key"] == "000123|01-20-2026|anesthesia|2"
    assert shaped["diagnosis"] == "h25.812"
    assert shaped["diagnosis_normalized"] == "H25812"
    assert shaped["cpt"] == "00142AA"
    assert shaped["minutes"] == "15"
    assert shaped["minutes_normalized"] == 15
    assert shaped["charge_amount"] == "450.00"
    assert shaped["charge_display"] == "$450"
    assert shaped["review_status"] == "review_complete"
    assert shaped["service_line_review_complete"] is True
    assert shaped["schema_version"] == "service_line_input_effective_row.v1"


def test_preview_boundary_sanitization_removes_mutation_fields_and_is_contract_clean():
    raw = {
        "patient_id": "1",
        "dos": "01-20-2026",
        "charge_display": "$450",
        "workflow_name": "claim_submission",
        "workflow_boundary": "operational_charge_entry",
        "claims_completion": True,
        "mutates_billing_state": True,
        "mutates_dat": True,
        "mutates_837p": True,
        "charges_entered": True,
        "claim_workflow_completion": True,
        "claim_submitted": True,
        "dat_mutation": True,
        "dat_write": True,
        "x12_837p_mutation": True,
        "837p_write": True,
        "operational_charge_update": True,
        "_service_line_input_claim_submitted": True,
        "_service_line_input_mutates_dat": True,
        "_service_line_input_mutates_837p": True,
        "source": {
            "patient_id": "1",
            "dos": "01-20-2026",
            "charges_entered": True,
            "mutates_dat": True,
            "mutates_837p": True,
        },
    }
    raw_before = copy.deepcopy(raw)

    sanitized = model.sanitize_service_line_preview_row(raw)

    assert raw == raw_before
    assert sanitized["workflow_name"] == "service_line_input"
    assert sanitized["workflow_boundary"] == "preview_only_review_required"
    assert sanitized["claims_completion"] is False
    assert sanitized["mutates_billing_state"] is False
    assert sanitized["mutates_dat"] is False
    assert sanitized["mutates_837p"] is False
    assert sanitized["charges_entered"] is False
    assert sanitized["charge_display"] == "$450"
    for key in (
            "claim_workflow_completion",
            "claim_submitted",
            "dat_mutation",
            "dat_write",
            "x12_837p_mutation",
            "837p_write",
            "operational_charge_update",
            "_service_line_input_claim_submitted",
            "_service_line_input_mutates_dat",
            "_service_line_input_mutates_837p"):
        assert key not in sanitized
    assert "charges_entered" not in sanitized["source"]
    assert "mutates_dat" not in sanitized["source"]
    assert "mutates_837p" not in sanitized["source"]
    assert sanitized["billing_boundary_review_only"] is True
    validation = model.validate_service_line_preview_boundary(sanitized)
    assert validation["boundary_clean"] is True
    assert validation["violations"] == []

    target_identity = model.build_service_line_target_identity(row=sanitized)
    assert_workflow_boundary_clean("service_line_input", target_identity, [
        {
            "name": "service_line_input_effective_row",
            "role": "state",
            "identity": target_identity,
            "status": "completed",
            "classification": "review_required",
            "claims_completion": sanitized["claims_completion"],
        },
        {
            "name": "billing_mutation_absent",
            "role": "artifact",
            "identity": target_identity,
            "classification": "missing",
            "claims_completion": False,
        },
    ])
