#!/usr/bin/env python
"""
Retrospective anesthesia minutes <-> charged amount analytics from saved 837P/X12 files.

Report-only, XP-compatible (Python 3.4.4, stdlib only).
"""
from __future__ import print_function

import argparse
from decimal import Decimal, InvalidOperation
import hashlib
import io
import json
import os
import sys
import uuid

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

import x12_analytics_common as x12c


ROW_SCHEMA_VERSION = "x12_minutes_charge_row_v2"
GROUP_SCHEMA_VERSION = "x12_minutes_charge_group_v1"
MODEL_EVAL_SCHEMA_VERSION = "x12_minutes_charge_model_eval_v1"
SUMMARY_SCHEMA_VERSION = "x12_minutes_charge_summary_v2"

WARNING_MISSING_SV1 = "missing_sv1"
WARNING_MALFORMED_SEGMENT = "malformed_segment"
WARNING_MISSING_CHARGE = "missing_charge"
WARNING_INVALID_CHARGE = "invalid_charge"
WARNING_MISSING_MINUTES = "missing_minutes"
WARNING_INVALID_MINUTES = "invalid_minutes"
WARNING_NON_MJ_SERVICE_UNIT = "non_mj_service_unit"
WARNING_MISSING_CPT = "missing_cpt"

PHI_FIELDS_SUPPRESSED = list(x12c.PHI_FIELDS_SUPPRESSED)
PHI_FIELDS_SUPPRESSED.extend([
    "patient_group_hash_salt",
    "raw_patient_identity",
    "patient_first_name",
    "patient_last_name",
    "subscriber_first_name",
    "subscriber_last_name",
])

VALIDATION_MODE_HISTORICAL_837P = "historical_submitted_837p"
WORKFLOW_BOUNDARY = "report_only_review_required"

MODEL_STAGE1 = "stage1_three_tier_cap"
MODEL_STAGE2A = "stage2a_age_disposition"
MODEL_STAGE2B = "stage2b_retrospective_anchor_validation"

AMBIG_SUBMITTED_MATCH = "submitted_837p_validation_match"
AMBIG_SUBMITTED_MISS = "submitted_837p_validation_miss"
AMBIG_CUSTODY_NOT_EVALUABLE = "custody_projection_not_evaluable_historical"
AMBIG_MISSING_PATIENT = "missing_patient_group_key"
AMBIG_MISSING_DOB = "missing_or_ambiguous_dob"
AMBIG_SINGLE_DOS = "single_dos_only"
AMBIG_MORE_THAN_TWO_DOS = "more_than_two_dos"
AMBIG_MISSING_ORDER = "missing_submission_order"
AMBIG_ANCHOR_PATTERN_ORDER_UNKNOWN = "anchor_pattern_present_order_unknown"
AMBIG_CHARGES_NO_ANCHOR = "charges_do_not_show_anchor_pattern"
AMBIG_CANCELLED = "cancelled_minutes_zero"
AMBIG_LOW_DOMAIN = "minutes_below_supported_domain"


def _normalize_amount(value):
    text = x12c.to_text(value).strip()
    if not text:
        return "", WARNING_MISSING_CHARGE
    try:
        amount = Decimal(text)
    except (InvalidOperation, ValueError):
        return "", WARNING_INVALID_CHARGE
    try:
        return "{0:.2f}".format(amount), ""
    except Exception:
        return x12c.to_text(amount), ""


def _normalize_minutes(value):
    text = x12c.to_text(value).strip()
    if not text:
        return "", WARNING_MISSING_MINUTES
    try:
        amount = Decimal(text)
    except (InvalidOperation, ValueError):
        return "", WARNING_INVALID_MINUTES
    try:
        if amount != amount.to_integral_value():
            return "", WARNING_INVALID_MINUTES
    except Exception:
        return "", WARNING_INVALID_MINUTES
    try:
        minutes = int(amount)
    except Exception:
        return "", WARNING_INVALID_MINUTES
    if minutes < 0:
        return "", WARNING_INVALID_MINUTES
    return str(minutes), ""


def _clean_identity_token(value):
    out = []
    for ch in x12c.to_text(value).upper():
        if ch.isalnum():
            out.append(ch)
    return "".join(out)


def _hash_patient_group(identity_parts, salt):
    parts = []
    for value in identity_parts or []:
        text = _clean_identity_token(value)
        if text:
            parts.append(text)
    if not parts:
        return ""
    raw = "{0}|{1}".format(x12c.to_text(salt), "|".join(parts))
    try:
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
    except Exception:
        return hashlib.sha256(raw.encode("latin-1", "ignore")).hexdigest()[:16]


def _parse_nm1_identity(segment):
    fields = segment.split("*")
    entity = fields[1].strip() if len(fields) > 1 else ""
    entity_type = fields[2].strip() if len(fields) > 2 else ""
    last_name = fields[3].strip() if len(fields) > 3 else ""
    first_name = fields[4].strip() if len(fields) > 4 else ""
    member_id = fields[9].strip() if len(fields) > 9 else ""
    if entity not in ("IL", "QC"):
        return None
    return {
        "entity": entity,
        "entity_type": entity_type,
        "last_name": last_name,
        "first_name": first_name,
        "member_id": member_id,
    }


def _parse_dmg(segment):
    fields = segment.split("*")
    if len(fields) < 3:
        return "", ""
    qualifier = fields[1].strip()
    dob = fields[2].strip()
    sex = fields[3].strip() if len(fields) > 3 else ""
    if qualifier != "D8":
        return "", sex
    return dob, sex


def _parse_clm_amount(segment):
    fields = segment.split("*")
    if len(fields) < 3:
        return ""
    amount, warning = _normalize_amount(fields[2])
    if warning:
        return ""
    return amount


def _parse_clm01(segment):
    fields = segment.split("*")
    if len(fields) < 2:
        return ""
    return fields[1].strip()


def _parse_yyyymmdd(value):
    text = x12c.to_text(value).strip()
    if len(text) < 8:
        return None
    text = text[:8]
    try:
        return int(text[0:4]), int(text[4:6]), int(text[6:8])
    except Exception:
        return None


def _date_sort_value(value):
    parsed = _parse_yyyymmdd(value)
    if not parsed:
        return 0
    year, month, day = parsed
    return year * 10000 + month * 100 + day


def _days_between_yyyymmdd(first, second):
    import datetime
    a = _parse_yyyymmdd(first)
    b = _parse_yyyymmdd(second)
    if not a or not b:
        return None
    try:
        da = datetime.date(a[0], a[1], a[2])
        db = datetime.date(b[0], b[1], b[2])
        return abs((db - da).days)
    except Exception:
        return None


def _age_at_dos(dob, dos):
    dob_parts = _parse_yyyymmdd(dob)
    dos_parts = _parse_yyyymmdd(dos)
    if not dob_parts or not dos_parts:
        return None
    by, bm, bd = dob_parts
    sy, sm, sd = dos_parts
    try:
        age = sy - by
        if (sm, sd) < (bm, bd):
            age -= 1
        if age < 0 or age > 130:
            return None
        return age
    except Exception:
        return None


def _age_bucket(age):
    if age is None:
        return "unknown"
    if age <= 45:
        return "45_or_less"
    if age < 60:
        return "46_to_59"
    if age <= 65:
        return "60_to_65"
    return "over_65"


def _make_patient_context(claim_state, salt):
    identity = claim_state.get("patient_identity") or claim_state.get("subscriber_identity") or {}
    dob = claim_state.get("patient_dob", "")
    sex = claim_state.get("patient_sex", "")
    identity_parts = [
        identity.get("member_id", ""),
        identity.get("last_name", ""),
        identity.get("first_name", ""),
        dob,
        sex,
    ]
    group_hash = _hash_patient_group(identity_parts, salt)
    source = "missing_identity"
    if group_hash:
        if identity.get("member_id") and dob:
            source = "member_id_dob"
        elif identity.get("member_id"):
            source = "member_id"
        elif dob:
            source = "name_dob"
        else:
            source = "name_only"
    return {
        "patient_group_hash": group_hash,
        "patient_group_source": source,
        "patient_dob_present": bool(dob),
    }


def _parse_dtp_472(segment):
    fields = segment.split("*")
    if len(fields) < 4:
        return ""
    if fields[1].strip() != "472":
        return ""
    qualifier = fields[2].strip()
    value = fields[3].strip()
    if qualifier == "D8":
        return value
    if qualifier == "RD8":
        return value
    return ""


def _parse_sv1_service_line(segment, source_meta, current_lx, line_count):
    warnings = []
    fields = segment.split("*")
    if len(fields) < 2:
        return None, [WARNING_MALFORMED_SEGMENT]

    composite = x12c.split_composites(fields[1])
    qualifier = composite[0].strip() if len(composite) > 0 else ""
    cpt_code = x12c.normalize_code(composite[1]) if len(composite) > 1 else ""
    procedure_modifier = x12c.to_text(composite[2]).strip() if len(composite) > 2 else ""
    if qualifier != "HC" or not cpt_code:
        x12c.add_warning(warnings, WARNING_MISSING_CPT)

    raw_charge = fields[2].strip() if len(fields) > 2 else ""
    raw_unit = fields[3].strip() if len(fields) > 3 else ""
    raw_minutes = fields[4].strip() if len(fields) > 4 else ""

    charge, charge_warning = _normalize_amount(raw_charge)
    if charge_warning:
        x12c.add_warning(warnings, charge_warning)

    minutes = ""
    minutes_warning = ""
    if raw_unit != "MJ":
        x12c.add_warning(warnings, WARNING_NON_MJ_SERVICE_UNIT)
    else:
        minutes, minutes_warning = _normalize_minutes(raw_minutes)
        if minutes_warning:
            x12c.add_warning(warnings, minutes_warning)

    row = None
    if cpt_code and charge and raw_unit == "MJ" and minutes:
        row = {
            "schema_version": ROW_SCHEMA_VERSION,
            "run_id": source_meta.get("run_id", ""),
            "source_file_basename": source_meta.get("source_file_basename", ""),
            "source_file_sha256_prefix": source_meta.get("source_file_sha256_prefix", ""),
            "inventory_sources": list(source_meta.get("inventory_sources") or []),
            "claim_index_in_file": int(source_meta.get("claim_index_in_file", 0) or 0),
            "st_control_number_hash": source_meta.get("st_control_number_hash", ""),
            "x12_observation_sequence": int(source_meta.get("x12_observation_sequence", 0) or 0),
            "cpt_code": cpt_code,
            "procedure_modifier": procedure_modifier,
            "line_charge_amount": charge,
            "claim_charge_amount": source_meta.get("claim_charge_amount", ""),
            "submitted_claim_number_hash": source_meta.get("submitted_claim_number_hash", ""),
            "service_unit_code": raw_unit,
            "anesthesia_minutes": minutes,
            "lx": current_lx,
            "service_date": "",
            "patient_group_hash": source_meta.get("patient_group_hash", ""),
            "patient_group_source": source_meta.get("patient_group_source", "missing_identity"),
            "patient_dob_present": bool(source_meta.get("patient_dob_present", False)),
            "age_years_at_dos": "",
            "age_bucket_at_dos": "unknown",
            "age_le_45_at_dos": None,
            "age_lt_60_at_dos": None,
            "age_gt_65_at_dos": None,
            "validation_mode": VALIDATION_MODE_HISTORICAL_837P,
            "custody_state_at_analysis": "out_of_custody_expected",
            "historical_out_of_custody_expected": True,
            "custody_required_for_stage2b_validation": False,
            "custody_sensitive_rule_suppressed": True,
            "submission_index_match": "submission_index" in list(source_meta.get("inventory_sources") or []),
            "both_claims_observed_in_837p": False,
            "both_claims_submitted_observed": False,
            "generated_sequence_known": True,
            "submitted_sequence_known": False,
            "dos_sequence_role": "unknown",
            "dos_gap_days": "",
            "observation_basis": "sv1_charge_mj_minutes",
            "warning_codes": list(warnings),
            "line_count_in_claim": line_count,
        }
    return row, warnings


def _claim_minutes_charge_context(claim_segments, source_meta):
    warnings = []
    rows = []
    service_lines = []
    current_lx = ""
    claim_state = {
        "subscriber_identity": None,
        "patient_identity": None,
        "patient_dob": "",
        "patient_sex": "",
        "claim_charge_amount": "",
        "claim_number": "",
    }

    for segment in claim_segments:
        if segment.startswith("NM1*"):
            identity = _parse_nm1_identity(segment)
            if identity is not None:
                if identity.get("entity") == "QC":
                    claim_state["patient_identity"] = identity
                elif identity.get("entity") == "IL":
                    claim_state["subscriber_identity"] = identity
        elif segment.startswith("DMG*"):
            dob, sex = _parse_dmg(segment)
            if dob:
                claim_state["patient_dob"] = dob
            if sex:
                claim_state["patient_sex"] = sex
        elif segment.startswith("CLM*"):
            claim_state["claim_charge_amount"] = _parse_clm_amount(segment)
            claim_state["claim_number"] = _parse_clm01(segment)
        elif segment.startswith("LX*"):
            fields = segment.split("*")
            current_lx = fields[1].strip() if len(fields) > 1 else ""
        elif segment.startswith("SV1*"):
            line_meta = dict(source_meta)
            patient_context = _make_patient_context(claim_state, source_meta.get("patient_hash_salt", ""))
            for key in patient_context:
                line_meta[key] = patient_context[key]
            line_meta["claim_charge_amount"] = claim_state.get("claim_charge_amount", "")
            line_meta["submitted_claim_number_hash"] = _hash_patient_group([claim_state.get("claim_number", "")], source_meta.get("patient_hash_salt", ""))
            line_meta["x12_observation_sequence"] = int(source_meta.get("x12_observation_sequence", 0) or 0) + len(rows) + 1
            row, line_warnings = _parse_sv1_service_line(
                segment,
                line_meta,
                current_lx,
                0,
            )
            service_lines.append({"row": row, "warnings": line_warnings})
            for code in line_warnings:
                x12c.add_warning(warnings, code)
            if row is not None:
                rows.append(row)
        elif segment.startswith("DTP*472*") and service_lines:
            service_date = _parse_dtp_472(segment)
            if service_date:
                last = service_lines[-1].get("row")
                if last is not None:
                    last["service_date"] = service_date
                    age = _age_at_dos(claim_state.get("patient_dob", ""), service_date)
                    if age is not None:
                        last["age_years_at_dos"] = age
                        last["age_bucket_at_dos"] = _age_bucket(age)
                        last["age_le_45_at_dos"] = bool(age <= 45)
                        last["age_lt_60_at_dos"] = bool(age < 60)
                        last["age_gt_65_at_dos"] = bool(age > 65)

    if not service_lines:
        x12c.add_warning(warnings, WARNING_MISSING_SV1)

    line_count = len(service_lines)
    for row in rows:
        row["line_count_in_claim"] = line_count
    return rows, line_count, warnings


def parse_x12_minutes_charge_rows(text, source_meta):
    segments = x12c.split_x12_segments(text)
    claims = x12c.claim_records_from_segments(segments)
    rows = []
    warning_counts = {}
    total_service_lines = 0
    service_lines_with_observation = 0

    for claim_index, claim in enumerate(claims):
        claim_meta = dict(source_meta)
        claim_meta["claim_index_in_file"] = claim_index + 1
        segments_for_claim = claim.get("segments") or []
        if segments_for_claim and segments_for_claim[0].startswith("ST*"):
            st_fields = segments_for_claim[0].split("*")
            claim_meta["st_control_number_hash"] = _hash_patient_group([st_fields[2] if len(st_fields) > 2 else ""], source_meta.get("patient_hash_salt", ""))
        claim_rows, line_count, claim_warnings = _claim_minutes_charge_context(
            segments_for_claim,
            claim_meta,
        )
        total_service_lines += line_count
        service_lines_with_observation += len(claim_rows)
        x12c.copy_warning_counts(claim_warnings, warning_counts)
        for row in claim_rows:
            rows.append(row)
            x12c.copy_warning_counts(row.get("warning_codes") or [], warning_counts)

    return {
        "claims": len(claims),
        "service_lines": total_service_lines,
        "service_lines_with_observation": service_lines_with_observation,
        "rows": rows,
        "warning_counts": warning_counts,
    }


def analyze_files(paths, run_id, patient_hash_salt=None):
    file_results = []
    all_rows = []
    warning_counts = {}
    observation_sequence = 0
    for item in paths:
        if isinstance(item, dict):
            path = item.get("path", "")
            sources = item.get("sources") or []
        else:
            path = item
            sources = []
        result = {
            "source_file_basename": os.path.basename(path),
            "inventory_sources": list(sources),
            "parsed": False,
            "claims": 0,
            "service_lines": 0,
            "service_lines_with_observation": 0,
            "warning_counts": {},
        }
        try:
            text = x12c.read_file_text(path)
            file_hash_prefix = x12c.sha256_prefix_for_file(path)
            source_meta = {
                "run_id": run_id,
                "source_file_basename": os.path.basename(path),
                "source_file_sha256_prefix": file_hash_prefix,
                "inventory_sources": list(sources),
                "patient_hash_salt": patient_hash_salt or "",
            }
            parsed = parse_x12_minutes_charge_rows(text, source_meta)
            result["source_file_sha256_prefix"] = file_hash_prefix
            result["claims"] = parsed.get("claims", 0)
            result["service_lines"] = parsed.get("service_lines", 0)
            result["service_lines_with_observation"] = parsed.get("service_lines_with_observation", 0)
            result["warning_counts"] = parsed.get("warning_counts") or {}
            result["parsed"] = bool(parsed.get("claims") or parsed.get("service_lines") or parsed.get("rows"))
            for row in parsed.get("rows") or []:
                observation_sequence += 1
                row["x12_observation_sequence"] = observation_sequence
                all_rows.append(row)
            x12c.merge_warning_counts(warning_counts, result["warning_counts"])
        except Exception:
            result["parsed"] = False
            result["warning_counts"] = {WARNING_MALFORMED_SEGMENT: 1}
            x12c.merge_warning_counts(warning_counts, result["warning_counts"])
        file_results.append(result)
    return file_results, all_rows, warning_counts


def _amount_cents(value):
    try:
        return int((Decimal(x12c.to_text(value)) * Decimal("100")).to_integral_value())
    except Exception:
        return 0


def _charge_text_from_cents(cents):
    if cents is None:
        return ""
    try:
        return "{0:.2f}".format(Decimal(int(cents)) / Decimal("100"))
    except Exception:
        return ""


def _minutes_int(row):
    try:
        return int(x12c.to_text(row.get("anesthesia_minutes")).strip())
    except Exception:
        return None


def _row_age(row):
    try:
        value = row.get("age_years_at_dos")
        if value == "" or value is None:
            return None
        return int(value)
    except Exception:
        return None


def _stage1_prediction(minutes):
    if minutes is None:
        return "", "", "missing_minutes"
    if minutes == 0:
        return "", "cancelled_zero_minutes", AMBIG_CANCELLED
    if minutes < 5:
        return "", "below_supported_domain", AMBIG_LOW_DOMAIN
    effective = minutes
    rule = "stage1_5_15_450"
    if minutes > 59:
        effective = 59
        rule = "stage1_cap_to_59"
    if effective <= 15:
        return "450.00", rule, ""
    if effective <= 35:
        return "540.00", "stage1_16_35_540", ""
    return "580.00", rule if rule == "stage1_cap_to_59" else "stage1_36_59_580", ""


def _stage2a_prediction(minutes, age, stage1_charge):
    if not stage1_charge:
        return "", "stage2a_not_evaluable", "stage1_not_evaluable"
    if minutes is None:
        return stage1_charge, "stage2a_fallback_stage1", ""
    effective = minutes
    if effective > 59:
        effective = 59
    if effective == 15:
        if age is None:
            return stage1_charge, "stage2a_15_missing_age_fallback_stage1", AMBIG_MISSING_DOB
        if age <= 45:
            return "580.00", "stage2a_15_age_le_45_580", ""
        if age < 60:
            return "540.00", "stage2a_15_age_lt_60_540", ""
        return stage1_charge, "stage2a_15_age_60_or_more_stage1", ""
    if effective == 40:
        if age is None:
            return stage1_charge, "stage2a_40_missing_age_fallback_stage1", AMBIG_MISSING_DOB
        if age > 65:
            return "540.00", "stage2a_40_age_gt_65_540", ""
        return stage1_charge, "stage2a_40_age_65_or_less_stage1", ""
    return stage1_charge, "stage2a_fallback_stage1", ""


def _prediction_match(row, predicted):
    actual = x12c.to_text(row.get("line_charge_amount")).strip()
    if not predicted or not actual:
        return False
    return _amount_cents(actual) == _amount_cents(predicted)


def _append_exception(bucket, row, model_key, predicted, ambiguity):
    actual = x12c.to_text(row.get("line_charge_amount")).strip()
    minutes = x12c.to_text(row.get("anesthesia_minutes")).strip()
    key = "{0}|{1}|{2}|{3}".format(minutes, actual, predicted, ambiguity)
    item = bucket.get(key)
    if item is None:
        item = {
            "anesthesia_minutes": minutes,
            "observed_charge_amount": actual,
            "predicted_charge_amount": predicted,
            "model": model_key,
            "ambiguity_code": ambiguity or "",
            "count": 0,
        }
        bucket[key] = item
    item["count"] = int(item.get("count", 0) or 0) + 1


def _evaluate_model(rows, model_key, prediction_field, ambiguity_field):
    total = 0
    included = 0
    exact = 0
    exception_bucket = {}
    ambiguity_counts = {}
    for row in rows:
        total += 1
        predicted = x12c.to_text(row.get(prediction_field)).strip()
        ambiguity = x12c.to_text(row.get(ambiguity_field)).strip()
        if ambiguity:
            ambiguity_counts[ambiguity] = int(ambiguity_counts.get(ambiguity, 0) or 0) + 1
        if not predicted:
            continue
        included += 1
        if _prediction_match(row, predicted):
            exact += 1
        else:
            _append_exception(exception_bucket, row, model_key, predicted, ambiguity)
    exceptions = [exception_bucket[key] for key in exception_bucket]
    exceptions.sort(key=lambda r: (-int(r.get("count", 0) or 0), r.get("anesthesia_minutes", ""), r.get("observed_charge_amount", "")))
    return {
        "model": model_key,
        "total_rows": total,
        "included_rows": included,
        "excluded_rows": max(0, total - included),
        "exact_match_rows": exact,
        "exception_rows": max(0, included - exact),
        "exact_match_rate": round(float(exact) / float(included), 6) if included else 0.0,
        "ambiguity_counts": ambiguity_counts,
        "top_exceptions": exceptions[:50],
    }


def _group_rows_for_stage2b(rows):
    groups = {}
    for row in rows:
        key = x12c.to_text(row.get("patient_group_hash")).strip()
        if not key:
            continue
        group = groups.get(key)
        if group is None:
            group = []
            groups[key] = group
        group.append(row)
    return groups


def _distinct_sorted_dos(group_rows):
    values = {}
    for row in group_rows:
        dos = x12c.to_text(row.get("service_date")).strip()
        if dos:
            values[dos] = True
    out = sorted(values.keys(), key=lambda v: (_date_sort_value(v), v))
    return out


def _first_observed_charge_for_dos(group_rows, dos):
    selected = []
    for row in group_rows:
        if x12c.to_text(row.get("service_date")).strip() == dos:
            selected.append(row)
    selected.sort(key=lambda r: int(r.get("x12_observation_sequence", 0) or 0))
    if selected:
        return x12c.to_text(selected[0].get("line_charge_amount")).strip()
    return ""


def _all_observed_charges(group_rows):
    out = {}
    for row in group_rows:
        charge = x12c.to_text(row.get("line_charge_amount")).strip()
        if charge:
            out[charge] = True
    return sorted(out.keys(), key=lambda v: (_amount_cents(v), v))


def _higher_candidate_charge(group_rows):
    best = 0
    for row in group_rows:
        cents = _amount_cents(row.get("stage2a_predicted_charge_amount") or row.get("stage1_predicted_charge_amount"))
        if cents > best:
            best = cents
    return _charge_text_from_cents(best) if best else ""


def apply_model_analysis(rows):
    for row in rows:
        minutes = _minutes_int(row)
        age = _row_age(row)
        stage1, stage1_rule, stage1_ambiguity = _stage1_prediction(minutes)
        stage2a, stage2a_rule, stage2a_ambiguity = _stage2a_prediction(minutes, age, stage1)
        row["baseline_stage1_charge"] = stage1
        row["stage1_predicted_charge_amount"] = stage1
        row["stage1_rule"] = stage1_rule
        row["stage1_match"] = _prediction_match(row, stage1) if stage1 else False
        row["stage1_ambiguity_code"] = stage1_ambiguity
        row["age_adjusted_stage2a_charge"] = stage2a
        row["stage2a_predicted_charge_amount"] = stage2a
        row["stage2a_rule"] = stage2a_rule
        row["stage2a_match"] = _prediction_match(row, stage2a) if stage2a else False
        row["stage2a_ambiguity_code"] = stage2a_ambiguity
        row["higher_candidate_charge_for_pair"] = ""
        row["observed_anchor_charge"] = ""
        row["observed_mimic_charge"] = ""
        row["stage2b_anchor_charge_source"] = "unknown"
        row["stage2b_eligible"] = False
        row["stage2b_ineligible_reason"] = ""
        row["stage2b_retrospective_prediction"] = stage2a
        row["stage2b_retrospective_match"] = _prediction_match(row, stage2a) if stage2a else False
        row["stage2b_confidence"] = "low"
        row["stage2b_ambiguity_code"] = stage2a_ambiguity

    groups = []
    grouped = _group_rows_for_stage2b(rows)
    for key in grouped:
        group_rows = grouped[key]
        group_rows.sort(key=lambda r: int(r.get("x12_observation_sequence", 0) or 0))
        distinct_dos = _distinct_sorted_dos(group_rows)
        row_count = len(group_rows)
        dos_count = len(distinct_dos)
        submitted_count = 0
        for row in group_rows:
            if row.get("submission_index_match"):
                submitted_count += 1
        all_submitted = bool(row_count and submitted_count == row_count)
        higher_candidate = _higher_candidate_charge(group_rows)
        observed_charges = _all_observed_charges(group_rows)
        first_dos = distinct_dos[0] if distinct_dos else ""
        second_dos = distinct_dos[1] if len(distinct_dos) > 1 else ""
        anchor_charge = _first_observed_charge_for_dos(group_rows, first_dos) if first_dos else ""
        second_charge = _first_observed_charge_for_dos(group_rows, second_dos) if second_dos else ""
        dos_gap = _days_between_yyyymmdd(first_dos, second_dos) if first_dos and second_dos else None
        eligible = bool(dos_count == 2)
        ineligible_reason = ""
        if dos_count == 0:
            ineligible_reason = AMBIG_MISSING_ORDER
        elif dos_count == 1:
            ineligible_reason = AMBIG_SINGLE_DOS
        elif dos_count > 2:
            ineligible_reason = AMBIG_MORE_THAN_TWO_DOS
        anchor_source = "unknown"
        group_ambiguity = ""
        if eligible:
            if higher_candidate and len(observed_charges) == 1 and _amount_cents(observed_charges[0]) == _amount_cents(higher_candidate):
                anchor_source = "higher_candidate"
                group_ambiguity = AMBIG_SUBMITTED_MATCH
            elif anchor_charge and second_charge and _amount_cents(anchor_charge) == _amount_cents(second_charge):
                anchor_source = "first_dos_observed_charge"
                group_ambiguity = AMBIG_SUBMITTED_MATCH
            elif anchor_charge and second_charge:
                anchor_source = "first_dos_observed_charge"
                group_ambiguity = AMBIG_CHARGES_NO_ANCHOR
            else:
                group_ambiguity = AMBIG_ANCHOR_PATTERN_ORDER_UNKNOWN
        else:
            group_ambiguity = ineligible_reason

        for row in group_rows:
            role = "single_dos"
            dos = x12c.to_text(row.get("service_date")).strip()
            if eligible:
                if dos == first_dos:
                    role = "first_dos"
                elif dos == second_dos:
                    role = "second_dos"
                else:
                    role = "multi_dos_extra"
            elif dos_count > 2:
                role = "multi_dos_extra"
            row["patient_group_row_count"] = row_count
            row["patient_group_distinct_dos_count"] = dos_count
            row["dos_sequence_role"] = role
            row["dos_gap_days"] = dos_gap if dos_gap is not None else ""
            row["both_claims_observed_in_837p"] = bool(eligible)
            row["both_claims_submitted_observed"] = bool(eligible and all_submitted)
            row["submitted_sequence_known"] = bool(eligible and all_submitted)
            row["stage2b_eligible"] = bool(eligible)
            row["stage2b_ineligible_reason"] = ineligible_reason
            row["higher_candidate_charge_for_pair"] = higher_candidate
            row["observed_anchor_charge"] = anchor_charge
            row["observed_mimic_charge"] = second_charge
            row["stage2b_anchor_charge_source"] = anchor_source
            row["stage2b_confidence"] = "high" if eligible and all_submitted else ("medium" if eligible else "low")
            if eligible and role == "second_dos" and anchor_charge:
                row["stage2b_retrospective_prediction"] = anchor_charge
                row["stage2b_retrospective_match"] = _prediction_match(row, anchor_charge)
                row["stage2b_ambiguity_code"] = AMBIG_SUBMITTED_MATCH if row["stage2b_retrospective_match"] else AMBIG_SUBMITTED_MISS
            elif eligible and anchor_source == "higher_candidate" and higher_candidate:
                row["stage2b_retrospective_prediction"] = higher_candidate
                row["stage2b_retrospective_match"] = _prediction_match(row, higher_candidate)
                row["stage2b_ambiguity_code"] = AMBIG_SUBMITTED_MATCH if row["stage2b_retrospective_match"] else AMBIG_SUBMITTED_MISS
            else:
                row["stage2b_ambiguity_code"] = group_ambiguity

        groups.append({
            "schema_version": GROUP_SCHEMA_VERSION,
            "patient_group_hash": key,
            "validation_mode": VALIDATION_MODE_HISTORICAL_837P,
            "workflow_boundary": WORKFLOW_BOUNDARY,
            "patient_group_row_count": row_count,
            "patient_group_distinct_dos_count": dos_count,
            "stage2b_eligible": eligible,
            "stage2b_ineligible_reason": ineligible_reason,
            "both_claims_observed_in_837p": bool(eligible),
            "both_claims_submitted_observed": bool(eligible and all_submitted),
            "historical_out_of_custody_expected": True,
            "custody_sensitive_rule_suppressed": True,
            "custody_projection_not_evaluable_reason": AMBIG_CUSTODY_NOT_EVALUABLE,
            "submitted_sequence_known": bool(eligible and all_submitted),
            "dos_gap_days": dos_gap if dos_gap is not None else "",
            "higher_candidate_charge_for_pair": higher_candidate,
            "observed_anchor_charge": anchor_charge,
            "observed_mimic_charge": second_charge,
            "stage2b_anchor_charge_source": anchor_source,
            "stage2b_ambiguity_code": group_ambiguity,
            "distinct_observed_charge_count": len(observed_charges),
        })

    for row in rows:
        if not x12c.to_text(row.get("patient_group_hash")).strip():
            row["patient_group_row_count"] = 0
            row["patient_group_distinct_dos_count"] = 0
            row["stage2b_eligible"] = False
            row["stage2b_ineligible_reason"] = AMBIG_MISSING_PATIENT
            row["stage2b_ambiguity_code"] = AMBIG_MISSING_PATIENT
            row["stage2b_confidence"] = "low"

    groups.sort(key=lambda r: (-int(r.get("patient_group_row_count", 0) or 0), r.get("patient_group_hash", "")))
    model_eval = build_model_evaluation(rows, groups)
    return rows, groups, model_eval


def build_model_evaluation(rows, groups):
    bucket_counts = {}
    for row in rows:
        code = x12c.to_text(row.get("stage2b_ambiguity_code")).strip()
        if code:
            bucket_counts[code] = int(bucket_counts.get(code, 0) or 0) + 1
    eligible_groups = 0
    submitted_pair_groups = 0
    retrospective_match_rows = 0
    retrospective_miss_rows = 0
    for group in groups:
        if group.get("stage2b_eligible"):
            eligible_groups += 1
        if group.get("both_claims_submitted_observed"):
            submitted_pair_groups += 1
    for row in rows:
        if row.get("stage2b_eligible") and row.get("dos_sequence_role") == "second_dos":
            if row.get("stage2b_retrospective_match"):
                retrospective_match_rows += 1
            else:
                retrospective_miss_rows += 1
    return {
        "schema_version": MODEL_EVAL_SCHEMA_VERSION,
        "validation_mode": VALIDATION_MODE_HISTORICAL_837P,
        "workflow_boundary": WORKFLOW_BOUNDARY,
        "claim_workflow_completion": False,
        "operational_charge_update": False,
        "custody_state_at_analysis": "out_of_custody_expected",
        "historical_out_of_custody_expected": True,
        "custody_required_for_stage2b_validation": False,
        "models": {
            MODEL_STAGE1: _evaluate_model(rows, MODEL_STAGE1, "stage1_predicted_charge_amount", "stage1_ambiguity_code"),
            MODEL_STAGE2A: _evaluate_model(rows, MODEL_STAGE2A, "stage2a_predicted_charge_amount", "stage2a_ambiguity_code"),
            MODEL_STAGE2B: _evaluate_model(rows, MODEL_STAGE2B, "stage2b_retrospective_prediction", "stage2b_ambiguity_code"),
        },
        "stage2b_retrospective_anchor_validation": {
            "eligible_patient_groups": eligible_groups,
            "submitted_pair_groups": submitted_pair_groups,
            "second_dos_match_rows": retrospective_match_rows,
            "second_dos_miss_rows": retrospective_miss_rows,
            "ambiguity_counts": bucket_counts,
        },
        "stage2b_live_custody_projection": {
            "scored": False,
            "reason": AMBIG_CUSTODY_NOT_EVALUABLE,
            "historical_out_of_custody_expected": True,
        },
    }


def _finalize_value_counts(counts, value_key, numeric=False):
    rows = []
    for value in counts:
        rows.append({
            value_key: value,
            "count": int(counts.get(value, 0) or 0),
        })
    if numeric:
        rows.sort(key=lambda r: (int(r.get(value_key, 0) or 0), r.get(value_key, "")))
    else:
        rows.sort(key=lambda r: (-int(r.get("count", 0) or 0), r.get(value_key, "")))
    return rows


def build_summary(run_id, scan_roots, file_results, all_rows, warning_counts, groups=None, model_eval=None):
    minutes_to_charge = {}
    charge_to_minutes = {}
    minutes_counts = {}
    charge_counts = {}
    distinct_cpts = set()
    claims = 0
    service_lines = 0
    service_lines_with_observation = 0
    parsed_files = 0
    rejected_files = 0

    for result in file_results:
        if result.get("parsed"):
            parsed_files += 1
        else:
            rejected_files += 1
        claims += int(result.get("claims", 0) or 0)
        service_lines += int(result.get("service_lines", 0) or 0)
        service_lines_with_observation += int(result.get("service_lines_with_observation", 0) or 0)

    for row in all_rows:
        minutes = x12c.to_text(row.get("anesthesia_minutes")).strip()
        charge = x12c.to_text(row.get("line_charge_amount")).strip()
        cpt = x12c.normalize_code(row.get("cpt_code"))
        if not minutes or not charge:
            continue
        if cpt:
            distinct_cpts.add(cpt)
        minutes_counts[minutes] = int(minutes_counts.get(minutes, 0) or 0) + 1
        charge_counts[charge] = int(charge_counts.get(charge, 0) or 0) + 1
        x12c.increment_nested_count(minutes_to_charge, minutes, charge)
        x12c.increment_nested_count(charge_to_minutes, charge, minutes)

    summary = {
        "schema_version": SUMMARY_SCHEMA_VERSION,
        "run_id": run_id,
        "generated_at_utc": x12c.iso_utc_now(),
        "validation_mode": VALIDATION_MODE_HISTORICAL_837P,
        "workflow_boundary": WORKFLOW_BOUNDARY,
        "claim_workflow_completion": False,
        "operational_charge_update": False,
        "historical_out_of_custody_expected": True,
        "custody_required_for_stage2b_validation": False,
        "scan_root_count": len(scan_roots or []),
        "scan_root_labels": [x12c.path_label(p) for p in (scan_roots or [])],
        "files_scanned": len(file_results),
        "files_parsed": parsed_files,
        "files_rejected": rejected_files,
        "total_claims": claims,
        "total_service_lines": service_lines,
        "service_lines_with_observation": service_lines_with_observation,
        "total_observations": len(all_rows),
        "distinct_cpt_count": len(distinct_cpts),
        "distinct_minutes_count": len(minutes_counts),
        "distinct_charge_count": len(charge_counts),
        "warning_totals": warning_counts,
        "minutes_to_charge": x12c.finalize_probability_map(minutes_to_charge, "observation_weighted_support"),
        "charge_to_minutes": x12c.finalize_probability_map(charge_to_minutes, "observation_weighted_support"),
        "minutes_counts": _finalize_value_counts(minutes_counts, "anesthesia_minutes", numeric=True),
        "charge_counts": _finalize_value_counts(charge_counts, "line_charge_amount"),
        "model_evaluation": model_eval or {},
        "stage2b_group_count": len(groups or []),
        "stage2b_eligible_group_count": len([g for g in (groups or []) if g.get("stage2b_eligible")]),
        "stage2b_submitted_pair_group_count": len([g for g in (groups or []) if g.get("both_claims_submitted_observed")]),
        "privacy": {
            "phi_fields_suppressed": PHI_FIELDS_SUPPRESSED,
            "hash_policy": "run-local salted SHA-256 prefix, first 16 hex chars; salt is not emitted",
            "sample_rows_are_sanitized": True,
            "pseudonymous_patient_groups_emitted": True,
        },
    }
    if service_lines:
        summary["service_line_observation_rate"] = round(float(service_lines_with_observation) / float(service_lines), 6)
    else:
        summary["service_line_observation_rate"] = 0.0
    if parsed_files:
        summary["average_claims_per_parsed_file"] = round(float(claims) / float(parsed_files), 6)
        summary["average_service_lines_per_parsed_file"] = round(float(service_lines) / float(parsed_files), 6)
    else:
        summary["average_claims_per_parsed_file"] = 0.0
        summary["average_service_lines_per_parsed_file"] = 0.0
    return summary


def build_health_telemetry(summary):
    summary = summary if isinstance(summary, dict) else {}
    inventory = summary.get("file_inventory") if isinstance(summary.get("file_inventory"), dict) else {}
    service_lines = int(summary.get("total_service_lines", 0) or 0)
    observed = int(summary.get("service_lines_with_observation", 0) or 0)
    files_parsed = int(summary.get("files_parsed", 0) or 0)
    files_scanned = int(summary.get("files_scanned", 0) or 0)
    missing_index_files = int(inventory.get("submission_index_missing_receipt_files", 0) or 0)
    invalid_index_lines = int(inventory.get("submission_index_invalid_json_lines", 0) or 0)
    observation_rate = 0.0
    if service_lines:
        observation_rate = float(observed) / float(service_lines)

    reasons = []
    trust_level = "high"
    if files_scanned == 0:
        trust_level = "low"
        reasons.append("no_candidate_files_found")
    if files_parsed == 0 and files_scanned:
        trust_level = "low"
        reasons.append("candidate_files_not_parseable")
    if service_lines == 0 and files_parsed:
        trust_level = "low"
        reasons.append("no_service_lines_found")
    if service_lines and observation_rate < 0.8:
        trust_level = "medium" if trust_level == "high" else trust_level
        reasons.append("service_line_observation_rate_below_80_percent")
    if missing_index_files:
        trust_level = "medium" if trust_level == "high" else trust_level
        reasons.append("submission_index_references_missing_files")
    if invalid_index_lines:
        trust_level = "medium" if trust_level == "high" else trust_level
        reasons.append("submission_index_has_invalid_json_lines")
    if not reasons:
        reasons.append("candidate_files_parsed_with_high_minutes_charge_observation")

    return {
        "trust_level": trust_level,
        "trust_reasons": reasons,
        "processed_837p_file_count": files_scanned,
        "parsed_837p_file_count": files_parsed,
        "claim_loop_count": int(summary.get("total_claims", 0) or 0),
        "service_line_count": service_lines,
        "service_lines_with_observation": observed,
        "service_lines_without_observation": max(0, service_lines - observed),
        "service_line_observation_rate": round(observation_rate, 6),
        "emitted_observation_count": int(summary.get("total_observations", 0) or 0),
        "submission_index_existing_receipt_files": int(inventory.get("submission_index_existing_receipt_files", 0) or 0),
        "fallback_content_scan_candidates": int(inventory.get("fallback_content_scan_candidates", 0) or 0),
    }


def write_reports(lab_dir, run_id, summary, rows, groups, model_eval):
    reports_dir = os.path.join(lab_dir, "reports")
    x12c.ensure_dir(reports_dir)
    summary_json = os.path.join(reports_dir, "x12_minutes_charge_summary_{0}.json".format(run_id))
    summary_txt = os.path.join(reports_dir, "x12_minutes_charge_summary_{0}.txt".format(run_id))
    rows_jsonl = os.path.join(reports_dir, "x12_minutes_charge_rows_{0}.jsonl".format(run_id))
    groups_jsonl = os.path.join(reports_dir, "x12_minutes_charge_groups_{0}.jsonl".format(run_id))
    model_eval_json = os.path.join(reports_dir, "x12_minutes_charge_model_eval_{0}.json".format(run_id))

    x12c.write_json(summary_json, summary)
    x12c.write_jsonl(rows_jsonl, rows)
    x12c.write_jsonl(groups_jsonl, groups)
    x12c.write_json(model_eval_json, model_eval)
    with io.open(summary_txt, "w", encoding="utf-8") as f:
        for line in format_summary_lines(summary):
            f.write(line)
            f.write("\n")

    summary["artifacts"] = {
        "summary_json": summary_json,
        "summary_txt": summary_txt,
        "rows_jsonl": rows_jsonl,
        "groups_jsonl": groups_jsonl,
        "model_eval_json": model_eval_json,
    }
    return summary["artifacts"]


def _top_observation_rows(mapping, max_rows=12):
    return x12c.top_association_rows(mapping, max_rows=max_rows, support_key="observation_weighted_support")


def format_operator_summary_lines(summary, max_rows=5):
    health = summary.get("health_telemetry") or {}
    lines = []
    lines.append("Minutes/Charge Review Results")
    lines.append("Files: {0} analyzed ({1} parsed, {2} rejected)".format(
        x12c.fmt_count(summary.get("files_scanned", 0)),
        x12c.fmt_count(summary.get("files_parsed", 0)),
        x12c.fmt_count(summary.get("files_rejected", 0))))
    lines.append("Claims: {0} | Observed service lines: {1}/{2} ({3}) | Trust: {4}".format(
        x12c.fmt_count(summary.get("total_claims", 0)),
        x12c.fmt_count(summary.get("service_lines_with_observation", 0)),
        x12c.fmt_count(summary.get("total_service_lines", 0)),
        x12c.fmt_percent(summary.get("service_line_observation_rate", 0.0)),
        health.get("trust_level", "unknown")))
    model_eval = summary.get("model_evaluation") or {}
    stage2b = (model_eval.get("models") or {}).get(MODEL_STAGE2B) or {}
    if stage2b:
        lines.append("Stage 2B retrospective model: {0}/{1} exact ({2}); historical out-of-custody expected".format(
            x12c.fmt_count(stage2b.get("exact_match_rows", 0)),
            x12c.fmt_count(stage2b.get("included_rows", 0)),
            x12c.fmt_percent(stage2b.get("exact_match_rate", 0.0))))
    top_rows = _top_observation_rows(summary.get("minutes_to_charge") or {}, max_rows=max_rows)
    if top_rows:
        lines.append("Top minutes -> charge observations:")
        for row in top_rows:
            lines.append("  {0} min -> ${1}  {2} ({3} line(s))".format(
                row.get("left", ""),
                row.get("right", ""),
                x12c.fmt_percent(row.get("probability", 0.0)),
                x12c.fmt_count(row.get("count", 0))))
    else:
        lines.append("Top minutes -> charge observations: none")
    return lines


def format_summary_lines(summary):
    lines = []
    lines.append("Minutes/Charge Retrospective Review")
    lines.append("====================================")
    lines.append("Generated: {0}".format(summary.get("generated_at_utc", "")))
    lines.append("Run ID: {0}".format(summary.get("run_id", "")))
    lines.append("")
    lines.append("This report summarizes historical anesthesia minutes and charged amounts found in saved 837P/X12 claim files.")
    lines.append("It is report-only and does not change billing behavior, pricing tiers, DAT files, or claim status.")

    x12c.section(lines, "Executive Summary")
    lines.append("Files analyzed: {0} ({1} parsed, {2} rejected)".format(
        x12c.fmt_count(summary.get("files_scanned", 0)),
        x12c.fmt_count(summary.get("files_parsed", 0)),
        x12c.fmt_count(summary.get("files_rejected", 0))))
    lines.append("Claim loops found: {0}".format(x12c.fmt_count(summary.get("total_claims", 0))))
    lines.append("Service lines observed: {0} of {1} ({2})".format(
        x12c.fmt_count(summary.get("service_lines_with_observation", 0)),
        x12c.fmt_count(summary.get("total_service_lines", 0)),
        x12c.fmt_percent(summary.get("service_line_observation_rate", 0.0))))
    lines.append("Observation rows emitted: {0}".format(x12c.fmt_count(summary.get("total_observations", 0))))
    lines.append("Distinct minutes: {0} | Distinct charges: {1} | Distinct CPTs: {2}".format(
        x12c.fmt_count(summary.get("distinct_minutes_count", 0)),
        x12c.fmt_count(summary.get("distinct_charge_count", 0)),
        x12c.fmt_count(summary.get("distinct_cpt_count", 0))))
    lines.append("Average claims per parsed file: {0}".format(x12c.fmt_float(summary.get("average_claims_per_parsed_file", 0.0), 2)))
    lines.append("Average service lines per parsed file: {0}".format(x12c.fmt_float(summary.get("average_service_lines_per_parsed_file", 0.0), 2)))
    lines.append("Validation mode: {0}".format(summary.get("validation_mode", VALIDATION_MODE_HISTORICAL_837P)))
    lines.append("Historical out-of-custody state is expected and is not counted as a Stage 2B failure.")

    inventory = summary.get("file_inventory") or {}
    health = summary.get("health_telemetry") or {}
    x12c.section(lines, "Reliability")
    if health:
        lines.append("Trust level: {0}".format(health.get("trust_level", "unknown")))
        reasons = health.get("trust_reasons") or []
        lines.append("Why: {0}".format(x12c.limit_join(reasons, limit=10)))
        lines.append("Unobserved service lines: {0}".format(x12c.fmt_count(health.get("service_lines_without_observation", 0))))
    else:
        lines.append("Trust level: unknown")
    if inventory:
        lines.append("Archive sources: {0} candidate file(s), {1} from submission index, {2} from content scan".format(
            x12c.fmt_count(inventory.get("unique_candidate_files", 0)),
            x12c.fmt_count(inventory.get("unique_submission_index_files", 0)),
            x12c.fmt_count(inventory.get("unique_content_scan_files", 0))))
        lines.append("Submission index receipts: {0} existing, {1} missing, {2} invalid JSON line(s)".format(
            x12c.fmt_count(inventory.get("submission_index_existing_receipt_files", 0)),
            x12c.fmt_count(inventory.get("submission_index_missing_receipt_files", 0)),
            x12c.fmt_count(inventory.get("submission_index_invalid_json_lines", 0))))

    model_eval = summary.get("model_evaluation") or {}
    models = model_eval.get("models") or {}
    x12c.section(lines, "Heuristic Model Scores")
    rows = []
    for key in [MODEL_STAGE1, MODEL_STAGE2A, MODEL_STAGE2B]:
        item = models.get(key) or {}
        rows.append([
            key,
            x12c.fmt_count(item.get("included_rows", 0)),
            x12c.fmt_count(item.get("exact_match_rows", 0)),
            x12c.fmt_count(item.get("exception_rows", 0)),
            x12c.fmt_percent(item.get("exact_match_rate", 0.0)),
        ])
    for line in x12c.table_lines(["Model", "Scored", "Matched", "Exceptions", "Rate"], rows):
        lines.append(line)

    stage2b = model_eval.get("stage2b_retrospective_anchor_validation") or {}
    x12c.section(lines, "Stage 2B Retrospective Validation")
    lines.append("Eligible patient groups: {0}".format(x12c.fmt_count(stage2b.get("eligible_patient_groups", 0))))
    lines.append("Submitted pair groups: {0}".format(x12c.fmt_count(stage2b.get("submitted_pair_groups", 0))))
    lines.append("Second-DOS anchor matches: {0}".format(x12c.fmt_count(stage2b.get("second_dos_match_rows", 0))))
    lines.append("Second-DOS anchor misses: {0}".format(x12c.fmt_count(stage2b.get("second_dos_miss_rows", 0))))
    lines.append("Live custody projection: not scored for historical submitted 837P review.")
    ambiguity_counts = stage2b.get("ambiguity_counts") or {}
    if ambiguity_counts:
        for code in sorted(ambiguity_counts.keys()):
            lines.append("{0}: {1}".format(code, x12c.fmt_count(ambiguity_counts.get(code))))

    x12c.section(lines, "Top Minutes To Charge Observations")
    rows = []
    for row in _top_observation_rows(summary.get("minutes_to_charge") or {}, max_rows=20):
        rows.append([
            row.get("left", ""),
            "${0}".format(row.get("right", "")),
            x12c.fmt_count(row.get("count", 0)),
            x12c.fmt_percent(row.get("probability", 0.0)),
        ])
    for line in x12c.table_lines(["Minutes", "Charge", "Lines", "Probability"], rows):
        lines.append(line)

    x12c.section(lines, "Top Charge To Minutes Observations")
    rows = []
    for row in _top_observation_rows(summary.get("charge_to_minutes") or {}, max_rows=20):
        rows.append([
            "${0}".format(row.get("left", "")),
            row.get("right", ""),
            x12c.fmt_count(row.get("count", 0)),
            x12c.fmt_percent(row.get("probability", 0.0)),
        ])
    for line in x12c.table_lines(["Charge", "Minutes", "Lines", "Probability"], rows):
        lines.append(line)

    x12c.section(lines, "Warnings")
    warning_totals = summary.get("warning_totals") or {}
    if warning_totals:
        for code in sorted(warning_totals.keys()):
            lines.append("{0}: {1}".format(code, x12c.fmt_count(warning_totals.get(code))))
    else:
        lines.append("none")

    x12c.section(lines, "Privacy")
    privacy = summary.get("privacy") or {}
    lines.append("Report rows use source basenames plus SHA-256 prefixes for auditability.")
    lines.append("Suppressed fields: {0}".format(x12c.limit_join(privacy.get("phi_fields_suppressed") or PHI_FIELDS_SUPPRESSED, limit=20)))
    return lines


def run_analysis(scan_roots, lab_dir, run_id=None):
    run_id = run_id or x12c.make_run_id()
    patient_hash_salt = uuid.uuid4().hex + uuid.uuid4().hex
    inventory_paths, inventory_summary = x12c.build_x12_scan_inventory(scan_roots)
    file_results, rows, warning_counts = analyze_files(inventory_paths, run_id, patient_hash_salt=patient_hash_salt)
    rows, groups, model_eval = apply_model_analysis(rows)
    summary = build_summary(run_id, scan_roots, file_results, rows, warning_counts, groups=groups, model_eval=model_eval)
    summary["file_inventory"] = inventory_summary
    summary["health_telemetry"] = build_health_telemetry(summary)
    artifacts = write_reports(lab_dir, run_id, summary, rows, groups, model_eval)
    return summary, rows, artifacts


def parse_args(argv):
    parser = argparse.ArgumentParser(description="Build minutes <-> charge analytics from saved 837P/X12 files.")
    parser.add_argument("--root", action="append", default=[], help="File or directory to scan. May be repeated.")
    parser.add_argument("--lab-dir", default="", help="Lab directory for reports. Defaults to MEDICAFE_LAB_DIR or ./lab.")
    parser.add_argument("--config", default="", help="Optional config.json for local_claims_path/outputFilePath roots.")
    parser.add_argument("--run-id", default="", help="Optional deterministic run id.")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv if argv is not None else sys.argv[1:])
    workspace = x12c.workspace_root_for_script(__file__)
    config_path = args.config or os.path.join(workspace, "json", "config.json")
    lab_dir = args.lab_dir or x12c.default_lab_dir(workspace)
    scan_roots = list(args.root or [])
    if not scan_roots:
        scan_roots.extend(x12c.load_config_roots(config_path))
    if not scan_roots:
        print("No scan roots provided and no config roots found.", file=sys.stderr)
        return 2
    summary, rows, artifacts = run_analysis(scan_roots, lab_dir, args.run_id or None)
    print("Wrote summary: {0}".format(artifacts.get("summary_json")))
    print("Wrote rows: {0}".format(artifacts.get("rows_jsonl")))
    print("files_scanned={0} observations={1}".format(summary.get("files_scanned"), len(rows)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
