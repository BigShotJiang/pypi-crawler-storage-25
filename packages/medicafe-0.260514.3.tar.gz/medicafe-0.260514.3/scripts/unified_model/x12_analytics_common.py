#!/usr/bin/env python
"""
Shared read-only X12 analytics helpers.

XP-compatible (Python 3.4.4, stdlib only).
"""
from __future__ import print_function

import hashlib
import io
import json
import os
import time
import uuid


X12_EXTENSIONS = set([".837p", ".837", ".x12", ".edi", ".txt"])
X12_TOKENS = ("ISA*", "GS*HC", "ST*837", "CLM*", "SV1*")

PHI_FIELDS_SUPPRESSED = [
    "patient_name",
    "member_id",
    "member_dob",
    "full_local_path",
    "claim_number",
    "CLM01",
    "REF_6R",
]


def to_text(value):
    if value is None:
        return ""
    try:
        return str(value)
    except Exception:
        return ""


def path_label(path):
    path = to_text(path).strip()
    if not path:
        return ""
    base = os.path.basename(os.path.normpath(path))
    if base:
        return base
    drive, _tail = os.path.splitdrive(path)
    if drive:
        return drive
    return "root"


def make_run_id():
    ts = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    try:
        suffix = uuid.uuid4().hex[:8]
    except Exception:
        suffix = hashlib.sha256(to_text(time.time()).encode("utf-8")).hexdigest()[:8]
    return "{0}-{1}".format(ts, suffix)


def iso_utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def normalize_code(value):
    out = []
    for ch in to_text(value).upper():
        if ch.isalnum():
            out.append(ch)
    return "".join(out)


def split_x12_segments(text):
    segments = []
    for raw in to_text(text).replace("\r", "\n").split("~"):
        segment = raw.strip()
        if segment:
            segments.append(segment)
    return segments


def split_composites(field):
    return to_text(field).split(":")


def add_warning(warnings, code):
    if code not in warnings:
        warnings.append(code)


def copy_warning_counts(warnings, warning_counts):
    for code in warnings:
        warning_counts[code] = int(warning_counts.get(code, 0) or 0) + 1


def merge_warning_counts(target, source):
    for code in source:
        target[code] = int(target.get(code, 0) or 0) + int(source.get(code, 0) or 0)


def claim_records_from_segments(segments):
    claims = []
    current = None
    for segment in segments:
        if segment.startswith("ST*"):
            if current is not None:
                claims.append(current)
            current = {"segments": []}
        if current is None:
            continue
        current["segments"].append(segment)
        if segment.startswith("SE*"):
            claims.append(current)
            current = None
    if current is not None and current.get("segments"):
        claims.append(current)
    if not claims:
        has_claim_content = False
        for segment in segments:
            if segment.startswith("HI*") or segment.startswith("SV1*") or segment.startswith("CLM*"):
                has_claim_content = True
                break
        if has_claim_content:
            claims.append({"segments": segments})
    return claims


def looks_like_x12_claim_text(text):
    if not text:
        return False
    score = 0
    for token in X12_TOKENS:
        if token in text:
            score += 1
    return score >= 2 and ("SV1*" in text or "HI*" in text)


def read_file_text(path, max_bytes=None):
    with open(path, "rb") as f:
        if max_bytes:
            data = f.read(max_bytes)
        else:
            data = f.read()
    try:
        return data.decode("utf-8", "replace")
    except Exception:
        try:
            return data.decode("latin-1", "replace")
        except Exception:
            return ""


def sha256_prefix_for_file(path, prefix_len=16):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()[:prefix_len]


def iter_candidate_x12_files(roots):
    seen = set()
    for root in roots:
        if not root:
            continue
        root = os.path.abspath(root)
        if os.path.isfile(root):
            candidates = [root]
        else:
            candidates = []
            for dirpath, dirnames, filenames in os.walk(root):
                for filename in filenames:
                    candidates.append(os.path.join(dirpath, filename))
        for path in candidates:
            key = os.path.normcase(os.path.abspath(path))
            if key in seen:
                continue
            seen.add(key)
            _, ext = os.path.splitext(path.lower())
            try:
                preview = read_file_text(path, max_bytes=16384)
            except Exception:
                continue
            if ext in X12_EXTENSIONS or "837" in os.path.basename(path).lower():
                if looks_like_x12_claim_text(preview):
                    yield path
            elif looks_like_x12_claim_text(preview):
                yield path


def is_submission_index_entry(row):
    if not isinstance(row, dict):
        return False
    notes = to_text(row.get("notes")).strip()
    record_type = to_text(row.get("record_type")).strip()
    if notes == "ack event" or record_type == "ack_event":
        return False
    return (not record_type) or record_type == "submission"


def submission_index_path(receipts_root):
    return os.path.join(receipts_root, "submission_index.jsonl")


def resolve_receipt_path(receipts_root, receipt_file):
    receipt_file = to_text(receipt_file).strip()
    if not receipt_file:
        return ""
    if os.path.isabs(receipt_file):
        return os.path.normpath(receipt_file)
    if receipts_root:
        return os.path.normpath(os.path.join(receipts_root, receipt_file))
    return os.path.normpath(receipt_file)


def read_submission_index_receipt_paths(receipts_root):
    """
    Return submitted receipt files from local_claims_path/submission_index.jsonl.
    Older installs may lack this index, so absence is reported, not fatal.
    """
    stats = {
        "index_path": "",
        "index_present": False,
        "rows_read": 0,
        "submission_rows": 0,
        "receipt_references": 0,
        "existing_receipt_files": 0,
        "missing_receipt_files": 0,
        "invalid_json_lines": 0,
    }
    paths = []
    if not receipts_root:
        return paths, stats
    index_path = receipts_root
    if os.path.isdir(receipts_root):
        index_path = submission_index_path(receipts_root)
    else:
        if os.path.basename(receipts_root).lower() != "submission_index.jsonl":
            return paths, stats
        receipts_root = os.path.dirname(receipts_root)
    stats["index_path"] = index_path
    if not os.path.isfile(index_path):
        return paths, stats
    stats["index_present"] = True
    try:
        with io.open(index_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                stats["rows_read"] += 1
                try:
                    row = json.loads(line)
                except Exception:
                    stats["invalid_json_lines"] += 1
                    continue
                if not is_submission_index_entry(row):
                    continue
                stats["submission_rows"] += 1
                receipt_file = (
                    row.get("receipt_file")
                    or row.get("file_path")
                    or row.get("file_name")
                    or ""
                )
                path = resolve_receipt_path(receipts_root, receipt_file)
                if not path:
                    continue
                stats["receipt_references"] += 1
                if os.path.isfile(path):
                    stats["existing_receipt_files"] += 1
                    paths.append(path)
                else:
                    stats["missing_receipt_files"] += 1
    except Exception:
        return paths, stats
    return paths, stats


def build_x12_scan_inventory(scan_roots):
    """
    Prefer submitted files named by submission_index.jsonl, then add older
    unindexed archives discovered by X12 content scan.
    """
    roots = list(scan_roots or [])
    by_path = {}
    ordered = []
    index_stats = []

    def add_path(path, source):
        if not path:
            return
        key = os.path.normcase(os.path.abspath(path))
        item = by_path.get(key)
        if item is None:
            item = {"path": os.path.abspath(path), "sources": []}
            by_path[key] = item
            ordered.append(key)
        if source not in item["sources"]:
            item["sources"].append(source)

    for root in roots:
        root_text = to_text(root).strip()
        if not root_text:
            continue
        idx_paths, stats = read_submission_index_receipt_paths(root_text)
        if stats.get("index_present"):
            index_stats.append(stats)
        for path in idx_paths:
            add_path(path, "submission_index")

    fallback_count = 0
    for path in iter_candidate_x12_files(roots):
        fallback_count += 1
        add_path(path, "content_scan")

    rows = [by_path[key] for key in ordered]
    summary = {
        "scan_root_count": len(roots),
        "scan_root_labels": [path_label(p) for p in roots],
        "submission_index_count": len(index_stats),
        "submission_index_rows_read": sum([int(s.get("rows_read", 0) or 0) for s in index_stats]),
        "submission_index_submission_rows": sum([int(s.get("submission_rows", 0) or 0) for s in index_stats]),
        "submission_index_receipt_references": sum([int(s.get("receipt_references", 0) or 0) for s in index_stats]),
        "submission_index_existing_receipt_files": sum([int(s.get("existing_receipt_files", 0) or 0) for s in index_stats]),
        "submission_index_missing_receipt_files": sum([int(s.get("missing_receipt_files", 0) or 0) for s in index_stats]),
        "submission_index_invalid_json_lines": sum([int(s.get("invalid_json_lines", 0) or 0) for s in index_stats]),
        "fallback_content_scan_candidates": fallback_count,
        "unique_candidate_files": len(rows),
        "unique_submission_index_files": len([r for r in rows if "submission_index" in r.get("sources", [])]),
        "unique_content_scan_files": len([r for r in rows if "content_scan" in r.get("sources", [])]),
    }
    return rows, summary


def increment_nested_count(bucket, first, second, weight=None):
    first_map = bucket.get(first)
    if first_map is None:
        first_map = {}
        bucket[first] = first_map
    item = first_map.get(second)
    if item is None:
        item = {"count": 0, "weighted_support": 0.0}
        first_map[second] = item
    item["count"] = int(item.get("count", 0) or 0) + 1
    if weight is None:
        weight = 1.0
    item["weighted_support"] = float(item.get("weighted_support", 0.0) or 0.0) + float(weight or 0.0)


def finalize_probability_map(bucket, support_key):
    out = {}
    for first in sorted(bucket.keys()):
        inner = bucket[first]
        total = 0
        for second in inner:
            total += int(inner[second].get("count", 0) or 0)
        rows = []
        for second in sorted(inner.keys()):
            count = int(inner[second].get("count", 0) or 0)
            weighted = float(inner[second].get("weighted_support", 0.0) or 0.0)
            prob = 0.0
            if total:
                prob = float(count) / float(total)
            row = {
                "code": second,
                "count": count,
                "probability": round(prob, 6),
            }
            row[support_key] = round(weighted, 6)
            rows.append(row)
        rows.sort(key=lambda r: (-int(r.get("count", 0) or 0), r.get("code", "")))
        out[first] = {
            "total_pairs": total,
            "associations": rows,
        }
    return out


def ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def write_json(path, payload):
    with io.open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True))
        f.write("\n")


def write_jsonl(path, rows):
    with io.open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, sort_keys=True, ensure_ascii=True, separators=(",", ":")))
            f.write("\n")


def fmt_percent(value):
    try:
        return "{0:.1f}%".format(float(value or 0.0) * 100.0)
    except Exception:
        return "0.0%"


def fmt_float(value, digits=2):
    try:
        return ("{0:." + str(int(digits)) + "f}").format(float(value or 0.0))
    except Exception:
        return "0.00"


def fmt_count(value):
    try:
        return str(int(value or 0))
    except Exception:
        return "0"


def limit_join(values, limit=12):
    values = values or []
    shown = []
    for value in values[:limit]:
        shown.append(to_text(value))
    if not shown:
        return "none"
    more = len(values) - len(shown)
    text = ", ".join(shown)
    if more > 0:
        text = "{0} (+{1} more)".format(text, more)
    return text


def section(lines, title):
    if lines:
        lines.append("")
    lines.append(title)
    lines.append("-" * len(title))


def table_lines(headers, rows):
    headers = [to_text(h) for h in headers]
    widths = [len(h) for h in headers]
    clean_rows = []
    for row in rows or []:
        clean = [to_text(cell) for cell in row]
        clean_rows.append(clean)
        for idx, cell in enumerate(clean):
            if idx < len(widths) and len(cell) > widths[idx]:
                widths[idx] = len(cell)
    if not clean_rows:
        return ["none"]
    fmt_parts = []
    for width in widths:
        fmt_parts.append("{0:<" + str(width) + "}")
    sep = "  "
    out = []
    out.append(sep.join([fmt_parts[idx].format(headers[idx]) for idx in range(len(headers))]))
    out.append(sep.join(["-" * width for width in widths]))
    for clean in clean_rows:
        cells = []
        for idx in range(len(headers)):
            cell = clean[idx] if idx < len(clean) else ""
            cells.append(fmt_parts[idx].format(cell))
        out.append(sep.join(cells))
    return out


def top_association_rows(mapping, max_rows=12, support_key="weighted_support"):
    collected = []
    for left in (mapping or {}):
        bucket = mapping.get(left) or {}
        total = int(bucket.get("total_pairs", 0) or 0)
        for assoc in bucket.get("associations") or []:
            collected.append({
                "left": left,
                "right": assoc.get("code", ""),
                "count": int(assoc.get("count", 0) or 0),
                "probability": float(assoc.get("probability", 0.0) or 0.0),
                "weighted": float(assoc.get(support_key, 0.0) or 0.0),
                "left_total": total,
            })
    collected.sort(key=lambda r: (
        -int(r.get("count", 0) or 0),
        -float(r.get("probability", 0.0) or 0.0),
        r.get("left", ""),
        r.get("right", ""),
    ))
    return collected[:max_rows]


def workspace_root_for_script(script_file):
    return os.path.abspath(os.path.join(os.path.dirname(script_file), os.pardir, os.pardir))


def default_lab_dir(workspace_root):
    env_lab = os.environ.get("MEDICAFE_LAB_DIR", "")
    if env_lab:
        return os.path.abspath(os.path.expandvars(os.path.expanduser(env_lab)))
    return os.path.join(workspace_root, "lab")


def load_config_roots(config_path):
    roots = []
    if not config_path or not os.path.exists(config_path):
        return roots
    try:
        with io.open(config_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return roots
    if not isinstance(data, dict):
        return roots
    cfg = data.get("MediLink_Config")
    if not isinstance(cfg, dict):
        cfg = data
    for key in ("local_claims_path", "outputFilePath"):
        value = cfg.get(key)
        if value and isinstance(value, str):
            roots.append(value)
    return roots
