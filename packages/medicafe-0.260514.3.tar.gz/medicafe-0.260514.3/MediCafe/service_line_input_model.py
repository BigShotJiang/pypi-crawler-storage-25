#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Pure Service Line Input row-layering helpers.

This module is intentionally side-effect free. It builds normalized row
identity, review-only row surfaces, and effective preview rows without writing
state, DAT files, claims, or support artifacts.
"""
from __future__ import print_function

import copy
from datetime import datetime


SERVICE_LINE_INPUT_WORKFLOW_NAME = "service_line_input"
SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY = "preview_only_review_required"
SERVICE_LINE_INPUT_DEFAULT_KIND = "anesthesia"

SERVICE_LINE_INPUT_MODEL_VERSION = "service_line_input_layered_model.v1"
SERVICE_LINE_INPUT_TARGET_SCHEMA_VERSION = "service_line_input_target.v1"
SERVICE_LINE_INPUT_ROW_SCHEMA_VERSION = "service_line_input_row.v1"
SERVICE_LINE_INPUT_EFFECTIVE_ROW_SCHEMA_VERSION = "service_line_input_effective_row.v1"
SERVICE_LINE_INPUT_STATE_SCHEMA_VERSION = "service_line_input_state.v1"
SERVICE_LINE_INPUT_LEGACY_ROW_KEY_SCHEMA_VERSION = "option_a_minutes_row_key.v1"
SERVICE_LINE_INPUT_CANDIDATE_PACKAGE_SCHEMA_VERSION = "service_line_input_candidate_package.v1"
SERVICE_LINE_INPUT_CANDIDATE_ROW_SCHEMA_VERSION = "service_line_input_candidate_row.v1"
SERVICE_LINE_INPUT_PARITY_SCHEMA_VERSION = "service_line_input_parity_report.v1"
SERVICE_LINE_INPUT_OVERLAY_EVENT_SCHEMA_VERSION = "service_line_input_overlay_event.v1"
SERVICE_LINE_INPUT_CLEANUP_READINESS_SCHEMA_VERSION = "service_line_input_cleanup_readiness.v1"
SERVICE_LINE_INPUT_CROSSWALK_INTAKE_PATCH_SCHEMA_VERSION = "service_line_input_crosswalk_intake_patch.v1"
SERVICE_LINE_INPUT_CROSSWALK_INTAKE_EVENT_SCHEMA_VERSION = "service_line_input_crosswalk_intake_event.v1"

SERVICE_LINE_INPUT_CPT_SOURCE_CROSSWALK = "crosswalk.diagnosis_to_procedure"
SERVICE_LINE_INPUT_CPT_CONFIDENCE_CROSSWALK = "crosswalk_confirmed"
SERVICE_LINE_INPUT_CPT_STATUS_SUGGESTED = "suggested"

SERVICE_LINE_INPUT_CPT_SOURCE_OPERATOR = "operator_overlay"
SERVICE_LINE_INPUT_CPT_CONFIDENCE_OPERATOR = "operator_confirmed"
SERVICE_LINE_INPUT_CPT_STATUS_OPERATOR = "operator_corrected"

SERVICE_LINE_INPUT_CPT_SOURCE_DOCX = "docx_observation"

SERVICE_LINE_INPUT_REVIEW_STATUS_PENDING = "pending"
SERVICE_LINE_INPUT_REVIEW_STATUS_NEEDS_REVIEW = "needs_review"
SERVICE_LINE_INPUT_REVIEW_STATUS_COMPLETE = "review_complete"
SERVICE_LINE_INPUT_REVIEW_STATUS_SKIPPED = "skipped"
SERVICE_LINE_INPUT_REVIEW_STATUS_CANCELLED = "cancelled"
SERVICE_LINE_INPUT_REVIEW_STATUS_INVALID = "invalid"

_TARGET_PATIENT_KEYS = (
    "patient_id",
    "Patient ID",
    "Patient ID #2",
    "patientId",
)
_TARGET_DOS_KEYS = (
    "dos",
    "date",
    "date_of_service",
    "surgery_date",
    "Surgery Date",
)
_TARGET_KIND_KEYS = (
    "service_line_kind",
    "line_kind",
)
_TARGET_ORDINAL_KEYS = (
    "line_ordinal",
    "service_line_ordinal",
)
_TARGET_DOCX_POSITION_KEYS = (
    "docx_position",
    "position",
)

_FORBIDDEN_MUTATION_FIELD_NAMES = set([
    "charges_entered",
    "charge_entered",
    "claim_submitted",
    "claim_submission",
    "claim_submission_complete",
    "claim_completed",
    "claims_completed",
    "claim_workflow_completion",
    "dat_mutation",
    "dat_write",
    "mutates_dat",
    "x12_837p_mutation",
    "x12_mutation",
    "837p_mutation",
    "837p_write",
    "mutates_837p",
    "billing_state_mutation",
    "billing_mutation",
    "operational_charge_update",
    "medisoft_charge_entry",
    "medisoft_charge_entered",
])

_FORBIDDEN_MUTATION_FIELD_SUFFIXES = (
    "_charges_entered",
    "_charge_entered",
    "_claim_submitted",
    "_claim_workflow_completion",
    "_dat_mutation",
    "_dat_write",
    "_mutates_dat",
    "_x12_837p_mutation",
    "_x12_mutation",
    "_837p_mutation",
    "_837p_write",
    "_mutates_837p",
    "_billing_state_mutation",
    "_billing_mutation",
    "_operational_charge_update",
)


def _clean_text(value):
    return str(value or "").strip()


def _iso_utc_now():
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")


def normalize_patient_id(value):
    """Return the display-compatible patient id key used by MediBot rows."""
    return _clean_text(value)


def normalize_service_line_kind(value):
    text = _clean_text(value).lower().replace(" ", "_")
    if not text:
        return SERVICE_LINE_INPUT_DEFAULT_KIND
    return text


def _positive_int(value, default_value):
    try:
        number = int(value)
    except Exception:
        return default_value
    if number < 1:
        return default_value
    return number


def _normalize_optional_int_or_text(value):
    text = _clean_text(value)
    if not text:
        return None
    try:
        return int(text)
    except Exception:
        return text


def normalize_dos_string(value):
    """Normalize DOS values to MediBot's MM-DD-YYYY row-key format."""
    if value is None:
        return ""
    if hasattr(value, "strftime"):
        try:
            return value.strftime("%m-%d-%Y")
        except Exception:
            return _clean_text(value)

    text = _clean_text(value)
    if not text:
        return ""
    for suffix in (" 00:00:00", "T00:00:00"):
        if text.endswith(suffix):
            text = text[:-len(suffix)]
            break
    for fmt in (
            "%m-%d-%Y",
            "%m/%d/%Y",
            "%Y-%m-%d",
            "%Y/%m/%d",
            "%m-%d-%y",
            "%m/%d/%y"):
        try:
            return datetime.strptime(text, fmt).strftime("%m-%d-%Y")
        except Exception:
            pass
    return text


def normalize_date_of_service_string(value):
    return normalize_dos_string(value)


def normalize_service_line_code(value):
    """Normalize diagnosis/CPT values the same way existing CPT lookup does."""
    out = []
    for ch in _clean_text(value).upper():
        if ch.isalnum():
            out.append(ch)
    return "".join(out)


def normalize_diagnosis_code(value):
    return normalize_service_line_code(value)


def normalize_cpt_code(value):
    return normalize_service_line_code(value)


def format_diagnosis_display_code(value):
    text = _clean_text(value).strip().upper()
    normalized = normalize_diagnosis_code(text)
    if normalized and len(normalized) > 3 and normalized[0].isalpha():
        return "{0}.{1}".format(normalized[:3], normalized[3:])
    return text


def diagnosis_code_is_icd_like(value):
    normalized = normalize_diagnosis_code(value)
    if len(normalized) < 4:
        return False
    if not normalized[0].isalpha():
        return False
    has_digit = False
    for ch in normalized:
        if ch.isdigit():
            has_digit = True
            break
    return has_digit


def cpt_code_is_supported_shape(value):
    normalized = normalize_cpt_code(value)
    return len(normalized) == 5 and normalized.isalnum()


def suggest_medisoft_shorthand_for_diagnosis(diagnosis):
    """Return the legacy fallback shorthand, without claiming it is valid."""
    text = _clean_text(diagnosis).strip().upper()
    if not text:
        return ""
    try:
        candidate = text.lstrip("H").lstrip("T8").replace(".", "")[-5:]
    except Exception:
        return ""
    if candidate and len(candidate) >= 3:
        return candidate
    return ""


def _normalized_values(values):
    out = []
    if isinstance(values, str):
        values = [values]
    for value in values or []:
        normalized = normalize_service_line_code(value)
        if normalized and normalized not in out:
            out.append(normalized)
    return out


def build_diagnosis_bridge_index(crosswalk):
    """Return full/shorthand bridge indexes with ambiguity metadata."""
    medisoft = {}
    if isinstance(crosswalk, dict) and isinstance(crosswalk.get("diagnosis_to_medisoft"), dict):
        medisoft = crosswalk.get("diagnosis_to_medisoft") or {}
    by_any = {}
    by_shorthand = {}
    by_full = {}
    for full_dx, shorthand in medisoft.items():
        full_norm = normalize_diagnosis_code(full_dx)
        short_norm = normalize_diagnosis_code(shorthand)
        if not full_norm or not short_norm:
            continue
        record = {
            "diagnosis_code": format_diagnosis_display_code(full_dx),
            "diagnosis_code_normalized": full_norm,
            "medisoft_code": _clean_text(shorthand).strip().upper(),
            "medisoft_code_normalized": short_norm,
        }
        by_full.setdefault(full_norm, []).append(record)
        by_shorthand.setdefault(short_norm, []).append(record)
        by_any.setdefault(full_norm, []).append(record)
        by_any.setdefault(short_norm, []).append(record)
    ambiguous_shorthand = {}
    for short_norm in by_shorthand:
        full_norms = sorted(list(set([r.get("diagnosis_code_normalized", "") for r in by_shorthand.get(short_norm) or []])))
        if len(full_norms) > 1:
            ambiguous_shorthand[short_norm] = full_norms
    return {
        "by_any": by_any,
        "by_full": by_full,
        "by_shorthand": by_shorthand,
        "ambiguous_shorthand": ambiguous_shorthand,
    }


def resolve_diagnosis_display_from_crosswalk(crosswalk, diagnosis):
    norm = normalize_diagnosis_code(diagnosis)
    if not norm:
        return ""
    bridge = build_diagnosis_bridge_index(crosswalk)
    records = bridge.get("by_any", {}).get(norm) or []
    if norm in bridge.get("ambiguous_shorthand", {}):
        return format_diagnosis_display_code(diagnosis)
    if records:
        return records[0].get("diagnosis_code") or format_diagnosis_display_code(diagnosis)
    return format_diagnosis_display_code(diagnosis)


def code_known_in_crosswalk(crosswalk, code, code_kind):
    normalized = normalize_service_line_code(code)
    if not normalized or not isinstance(crosswalk, dict):
        return False
    if code_kind == "diagnosis":
        bridge = build_diagnosis_bridge_index(crosswalk)
        if normalized in bridge.get("by_any", {}):
            return True
        dx_to_proc = crosswalk.get("diagnosis_to_procedure")
        if isinstance(dx_to_proc, dict):
            for dx in dx_to_proc:
                if normalize_diagnosis_code(dx) == normalized:
                    return True
        proc_to_dx = crosswalk.get("procedure_to_diagnosis")
        if isinstance(proc_to_dx, dict):
            for _cpt, values in proc_to_dx.items():
                if isinstance(values, (list, tuple)):
                    if normalized in _normalized_values(values):
                        return True
                elif normalize_diagnosis_code(values) == normalized:
                    return True
    if code_kind == "cpt":
        dx_to_proc = crosswalk.get("diagnosis_to_procedure")
        if isinstance(dx_to_proc, dict):
            for _dx, cpt in dx_to_proc.items():
                if normalize_cpt_code(cpt) == normalized:
                    return True
        proc_to_dx = crosswalk.get("procedure_to_diagnosis")
        if isinstance(proc_to_dx, dict):
            for cpt in proc_to_dx:
                if normalize_cpt_code(cpt) == normalized:
                    return True
    return False


def normalize_service_line_review_status(value):
    """Return the review-state vocabulary used by preview-only rows."""
    text = _clean_text(value).lower().replace("-", "_").replace(" ", "_")
    if not text:
        return SERVICE_LINE_INPUT_REVIEW_STATUS_PENDING
    if text in ("pending", "open", "new", "not_started"):
        return SERVICE_LINE_INPUT_REVIEW_STATUS_PENDING
    if text in ("needs_review", "review_required", "requires_review", "requested"):
        return SERVICE_LINE_INPUT_REVIEW_STATUS_NEEDS_REVIEW
    if text in (
            "review_complete",
            "reviewed",
            "complete",
            "completed",
            "done",
            "entered",
            "ok",
            "ready",
            "confirmed",
            "operator_confirmed"):
        return SERVICE_LINE_INPUT_REVIEW_STATUS_COMPLETE
    if text in ("skip", "skipped"):
        return SERVICE_LINE_INPUT_REVIEW_STATUS_SKIPPED
    if text in ("cancelled", "canceled", "cancel"):
        return SERVICE_LINE_INPUT_REVIEW_STATUS_CANCELLED
    if text in ("invalid", "error"):
        return SERVICE_LINE_INPUT_REVIEW_STATUS_INVALID
    return text


def normalize_service_line_row_status(value):
    """Return row status semantics, distinct from review-completion state."""
    text = _clean_text(value).lower().replace("-", "_").replace(" ", "_")
    if text in ("entered", "review_complete", "reviewed", "complete", "completed", "done", "ok"):
        return "entered"
    if text in ("skip", "skipped"):
        return "skipped"
    if text in ("auto_cancelled", "auto_canceled"):
        return "auto_cancelled"
    if text in ("cancelled", "canceled", "cancel"):
        return "cancelled"
    if text in ("invalid", "error"):
        return "invalid"
    return "pending"


def _get_first_mapping_value(mapping, keys):
    if not isinstance(mapping, dict):
        return None
    for key in keys:
        if key in mapping and mapping.get(key) is not None and mapping.get(key) != "":
            return mapping.get(key)
    return None


def _nested_identity_source(row):
    if not isinstance(row, dict):
        return {}
    for key in ("target_identity", "identity", "source"):
        value = row.get(key)
        if isinstance(value, dict):
            return value
    return {}


def parse_legacy_service_line_row_key(row_key):
    """Return ``(patient_id, dos)`` from the legacy ``patient|dos`` key."""
    text = _clean_text(row_key)
    if "|" not in text:
        return ("", "")
    parts = text.split("|")
    return (normalize_patient_id(parts[0]), normalize_dos_string(parts[1]))


def build_legacy_service_line_row_key(patient_id, dos):
    return "{0}|{1}".format(normalize_patient_id(patient_id), normalize_dos_string(dos))


def build_service_line_row_key(patient_id, dos, service_line_kind=None, line_ordinal=None):
    """Return a layered key while keeping patient|DOS as the leading segment."""
    legacy_key = build_legacy_service_line_row_key(patient_id, dos)
    kind = normalize_service_line_kind(service_line_kind)
    ordinal = _positive_int(line_ordinal, 1)
    return "{0}|{1}|{2}".format(legacy_key, kind, ordinal)


def build_service_line_target_identity(row=None, patient_id=None, dos=None,
                                       service_line_kind=None, line_ordinal=None,
                                       docx_position=None, legacy_row_key=None):
    """Return normalized identity keys suitable for workflow-boundary tests."""
    source = row if isinstance(row, dict) else {}
    nested = _nested_identity_source(source)

    if legacy_row_key is None:
        legacy_row_key = source.get("legacy_row_key") or source.get("row_key")

    legacy_patient_id = ""
    legacy_dos = ""
    if legacy_row_key:
        legacy_patient_id, legacy_dos = parse_legacy_service_line_row_key(legacy_row_key)

    if patient_id is None:
        patient_id = _get_first_mapping_value(source, _TARGET_PATIENT_KEYS)
    if patient_id is None:
        patient_id = _get_first_mapping_value(nested, _TARGET_PATIENT_KEYS)
    if patient_id is None:
        patient_id = legacy_patient_id

    if dos is None:
        dos = _get_first_mapping_value(source, _TARGET_DOS_KEYS)
    if dos is None:
        dos = _get_first_mapping_value(nested, _TARGET_DOS_KEYS)
    if dos is None:
        dos = legacy_dos

    if service_line_kind is None:
        service_line_kind = _get_first_mapping_value(source, _TARGET_KIND_KEYS)
    if service_line_kind is None:
        service_line_kind = _get_first_mapping_value(nested, _TARGET_KIND_KEYS)

    if line_ordinal is None:
        line_ordinal = _get_first_mapping_value(source, _TARGET_ORDINAL_KEYS)
    if line_ordinal is None:
        line_ordinal = _get_first_mapping_value(nested, _TARGET_ORDINAL_KEYS)

    if docx_position is None:
        docx_position = _get_first_mapping_value(source, _TARGET_DOCX_POSITION_KEYS)
    if docx_position is None:
        docx_position = _get_first_mapping_value(nested, _TARGET_DOCX_POSITION_KEYS)

    identity = {
        "patient_id": normalize_patient_id(patient_id),
        "dos": normalize_dos_string(dos),
        "service_line_kind": normalize_service_line_kind(service_line_kind),
        "line_ordinal": _positive_int(line_ordinal, 1),
    }
    normalized_position = _normalize_optional_int_or_text(docx_position)
    if normalized_position is not None:
        identity["docx_position"] = normalized_position
    return identity


def build_service_line_target_record(row=None, patient_id=None, dos=None,
                                     service_line_kind=None, line_ordinal=None,
                                     docx_position=None, legacy_row_key=None):
    """Return identity plus schema and row-key metadata for row surfaces."""
    identity = build_service_line_target_identity(
        row=row,
        patient_id=patient_id,
        dos=dos,
        service_line_kind=service_line_kind,
        line_ordinal=line_ordinal,
        docx_position=docx_position,
        legacy_row_key=legacy_row_key,
    )
    legacy_key = build_legacy_service_line_row_key(
        identity.get("patient_id"),
        identity.get("dos"),
    )
    record = {
        "schema_version": SERVICE_LINE_INPUT_TARGET_SCHEMA_VERSION,
        "workflow_name": SERVICE_LINE_INPUT_WORKFLOW_NAME,
        "workflow_boundary": SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        "target_identity": dict(identity),
        "patient_id": identity.get("patient_id", ""),
        "dos": identity.get("dos", ""),
        "service_line_kind": identity.get("service_line_kind", SERVICE_LINE_INPUT_DEFAULT_KIND),
        "line_ordinal": identity.get("line_ordinal", 1),
        "legacy_row_key": legacy_key,
        "service_line_row_key": build_service_line_row_key(
            identity.get("patient_id"),
            identity.get("dos"),
            identity.get("service_line_kind"),
            identity.get("line_ordinal"),
        ),
        "legacy_row_key_schema_version": SERVICE_LINE_INPUT_LEGACY_ROW_KEY_SCHEMA_VERSION,
    }
    if "docx_position" in identity:
        record["docx_position"] = identity.get("docx_position")
    return record


def _apply_service_line_review_flags(row):
    status_source = _first_non_empty(
        row,
        ("review_status", "service_line_review_status", "review_state", "status"),
    )
    row_status = normalize_service_line_row_status(status_source)
    review_status = normalize_service_line_review_status(status_source)
    if row_status in ("entered", "skipped", "cancelled", "auto_cancelled"):
        review_status = SERVICE_LINE_INPUT_REVIEW_STATUS_COMPLETE
    row["row_status"] = row_status
    row["service_line_row_status"] = row_status
    row["review_status"] = review_status
    row["service_line_review_status"] = review_status
    row["service_line_review_complete"] = (
        review_status == SERVICE_LINE_INPUT_REVIEW_STATUS_COMPLETE
    )
    row["review_complete_claims_completion"] = False
    return row


def _apply_service_line_boundary_flags(row):
    row["workflow_name"] = SERVICE_LINE_INPUT_WORKFLOW_NAME
    row["workflow_boundary"] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY
    row["claims_completion"] = False
    row["mutates_billing_state"] = False
    row["mutates_dat"] = False
    row["mutates_837p"] = False
    row["charges_entered"] = False
    row["billing_boundary_review_only"] = True
    return row


def complete_service_line_target_fields(row=None, target_identity=None):
    """Return a copy with normalized target identity and row-key fields."""
    if not isinstance(row, dict):
        row = {}
    out = _copy_without_mutation_fields(row)
    if target_identity is None:
        identity = build_service_line_target_identity(row=out)
    else:
        identity = build_service_line_target_identity(row=target_identity)
    target_record = build_service_line_target_record(row=identity)
    out["patient_id"] = target_record.get("patient_id", "")
    out["dos"] = target_record.get("dos", "")
    out["service_line_kind"] = target_record.get("service_line_kind", SERVICE_LINE_INPUT_DEFAULT_KIND)
    out["line_ordinal"] = target_record.get("line_ordinal", 1)
    if "docx_position" in target_record:
        out["docx_position"] = target_record.get("docx_position")
    elif "docx_position" in out:
        del out["docx_position"]
    out["target_identity"] = dict(target_record.get("target_identity") or {})
    out["legacy_row_key"] = target_record.get("legacy_row_key")
    out["service_line_row_key"] = target_record.get("service_line_row_key")
    out["legacy_row_key_schema_version"] = SERVICE_LINE_INPUT_LEGACY_ROW_KEY_SCHEMA_VERSION
    return out


def _normalize_effective_row_amount_fields(row):
    minutes = _first_non_empty(
        row,
        ("minutes", "entered_minutes", "operator_minutes", "anesthesia_minutes"),
    )
    if minutes != "" and "minutes" not in row:
        row["minutes"] = minutes
    if minutes != "":
        try:
            row["minutes_normalized"] = int(_clean_text(minutes))
        except Exception:
            pass

    charge_amount = _first_non_empty(row, ("charge_amount", "amount", "charge"))
    if charge_amount != "" and "charge_amount" not in row:
        row["charge_amount"] = charge_amount
    charge_display = _first_non_empty(row, ("charge_display", "display_charge"))
    if charge_display != "" and "charge_display" not in row:
        row["charge_display"] = charge_display


def shape_effective_service_line_row(row=None, target_identity=None):
    """Return the canonical pure effective-row shape for preview/review."""
    out = complete_service_line_target_fields(row=row, target_identity=target_identity)
    _normalize_effective_row_codes(out)
    _normalize_effective_row_amount_fields(out)
    _apply_service_line_review_flags(out)
    out["layering_model_version"] = SERVICE_LINE_INPUT_MODEL_VERSION
    out["schema_version"] = SERVICE_LINE_INPUT_EFFECTIVE_ROW_SCHEMA_VERSION
    _apply_service_line_boundary_flags(out)
    return out


def validate_service_line_preview_boundary(row):
    """Return pure validation evidence for the preview-only boundary."""
    violations = []
    if not isinstance(row, dict):
        row = {}
        violations.append("row_not_mapping")
    for key in row.keys():
        if _field_name_is_forbidden_mutation(key):
            if not bool(row.get(key)):
                continue
            violations.append("forbidden_mutation_field:{0}".format(key))
    if row.get("workflow_name") not in (None, "", SERVICE_LINE_INPUT_WORKFLOW_NAME):
        violations.append("workflow_name_not_service_line_input")
    if row.get("workflow_boundary") not in (None, "", SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY):
        violations.append("workflow_boundary_not_preview_only")
    if bool(row.get("claims_completion")):
        violations.append("claims_completion_true")
    if bool(row.get("mutates_billing_state")):
        violations.append("mutates_billing_state_true")
    if bool(row.get("mutates_dat")):
        violations.append("mutates_dat_true")
    if bool(row.get("mutates_837p")):
        violations.append("mutates_837p_true")
    if bool(row.get("charges_entered")):
        violations.append("charges_entered_true")
    return {
        "schema_version": "service_line_input_preview_boundary_validation.v1",
        "workflow_name": SERVICE_LINE_INPUT_WORKFLOW_NAME,
        "workflow_boundary": SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        "boundary_clean": not bool(violations),
        "violations": violations,
        "claims_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
    }


def _field_name_is_forbidden_mutation(name):
    normalized = _clean_text(name).lower().replace("-", "_")
    if normalized in _FORBIDDEN_MUTATION_FIELD_NAMES:
        return True
    for suffix in _FORBIDDEN_MUTATION_FIELD_SUFFIXES:
        if normalized.endswith(suffix):
            return True
    return False


def _copy_without_mutation_fields(value):
    if isinstance(value, dict):
        out = {}
        for key, nested_value in value.items():
            if _field_name_is_forbidden_mutation(key):
                continue
            out[key] = _copy_without_mutation_fields(nested_value)
        return out
    if isinstance(value, list):
        return [_copy_without_mutation_fields(item) for item in value]
    return copy.deepcopy(value)


def sanitize_service_line_preview_row(row):
    """Return a review-only row with billing-mutation claims stripped."""
    if not isinstance(row, dict):
        row = {}
    out = _copy_without_mutation_fields(row)
    out["schema_version"] = out.get("schema_version") or SERVICE_LINE_INPUT_ROW_SCHEMA_VERSION
    _apply_service_line_review_flags(out)
    _apply_service_line_boundary_flags(out)
    return out


def sanitize_service_line_preview_rows(rows):
    return [sanitize_service_line_preview_row(row) for row in rows or []]


def predict_cpt_from_crosswalk(crosswalk, diagnosis):
    """Return confirmed CPT prediction evidence from diagnosis_to_procedure."""
    if not isinstance(crosswalk, dict):
        return {}
    diagnosis_norm = normalize_diagnosis_code(diagnosis)
    if not diagnosis_norm:
        return {}

    candidates = [diagnosis_norm]
    bridge = build_diagnosis_bridge_index(crosswalk)
    if diagnosis_norm in bridge.get("ambiguous_shorthand", {}):
        return {}
    for record in bridge.get("by_any", {}).get(diagnosis_norm) or []:
        source_norm = normalize_diagnosis_code(record.get("diagnosis_code_normalized"))
        mapped_norm = normalize_diagnosis_code(record.get("medisoft_code_normalized"))
        if source_norm and source_norm not in candidates:
            candidates.append(source_norm)
        if mapped_norm and mapped_norm not in candidates:
            candidates.append(mapped_norm)

    dx_to_proc = crosswalk.get("diagnosis_to_procedure")
    if not isinstance(dx_to_proc, dict):
        return {}
    for key, cpt in dx_to_proc.items():
        key_norm = normalize_diagnosis_code(key)
        if key_norm in candidates:
            cpt_norm = normalize_cpt_code(cpt)
            if cpt_norm:
                return {
                    "cpt": cpt_norm,
                    "cpt_source": SERVICE_LINE_INPUT_CPT_SOURCE_CROSSWALK,
                    "cpt_confidence": SERVICE_LINE_INPUT_CPT_CONFIDENCE_CROSSWALK,
                    "cpt_status": SERVICE_LINE_INPUT_CPT_STATUS_SUGGESTED,
                    "cpt_prediction_diagnosis_code": _clean_text(key),
                }
    return {}


def _find_existing_normalized_key(mapping, code):
    target = normalize_service_line_code(code)
    if not target or not isinstance(mapping, dict):
        return ""
    for key in mapping:
        if normalize_service_line_code(key) == target:
            return key
    return ""


def _normalized_list_contains(values, code):
    target = normalize_service_line_code(code)
    return bool(target and target in _normalized_values(values))


def build_service_line_crosswalk_intake_patch(crosswalk, diagnosis_code, medisoft_code, cpt_code,
                                              source=None):
    """Build a confirmed-config-update patch for an SLI unknown-code intake."""
    if not isinstance(crosswalk, dict):
        crosswalk = {}
    dx_display = format_diagnosis_display_code(diagnosis_code)
    dx_norm = normalize_diagnosis_code(dx_display)
    medisoft_norm = normalize_diagnosis_code(medisoft_code)
    cpt_norm = normalize_cpt_code(cpt_code)
    errors = []
    conflicts = []
    if not diagnosis_code_is_icd_like(dx_display):
        errors.append("diagnosis_code_must_be_full_icd10_like")
    if not medisoft_norm:
        errors.append("medisoft_shorthand_required")
    if not cpt_code_is_supported_shape(cpt_norm):
        errors.append("cpt_code_must_be_5_alphanumeric_characters")

    dx_to_medisoft = crosswalk.get("diagnosis_to_medisoft")
    if not isinstance(dx_to_medisoft, dict):
        dx_to_medisoft = {}
    dx_to_proc = crosswalk.get("diagnosis_to_procedure")
    if not isinstance(dx_to_proc, dict):
        dx_to_proc = {}
    proc_to_dx = crosswalk.get("procedure_to_diagnosis")
    if not isinstance(proc_to_dx, dict):
        proc_to_dx = {}

    existing_dx_medisoft_key = _find_existing_normalized_key(dx_to_medisoft, dx_display)
    existing_dx_medisoft_value = normalize_diagnosis_code(dx_to_medisoft.get(existing_dx_medisoft_key)) if existing_dx_medisoft_key else ""
    if existing_dx_medisoft_value and existing_dx_medisoft_value != medisoft_norm:
        conflicts.append({
            "key": "diagnosis_to_medisoft",
            "existing_key": existing_dx_medisoft_key,
            "existing_value": dx_to_medisoft.get(existing_dx_medisoft_key),
            "proposed_key": dx_display,
            "proposed_value": medisoft_norm,
        })
    for existing_dx, existing_medisoft in dx_to_medisoft.items():
        if normalize_diagnosis_code(existing_medisoft) == medisoft_norm and normalize_diagnosis_code(existing_dx) != dx_norm:
            conflicts.append({
                "key": "diagnosis_to_medisoft",
                "existing_key": existing_dx,
                "existing_value": existing_medisoft,
                "proposed_key": dx_display,
                "proposed_value": medisoft_norm,
                "reason": "medisoft_shorthand_already_points_to_different_diagnosis",
            })

    existing_dx_proc_key = _find_existing_normalized_key(dx_to_proc, dx_display)
    existing_dx_proc_value = normalize_cpt_code(dx_to_proc.get(existing_dx_proc_key)) if existing_dx_proc_key else ""
    if existing_dx_proc_value and existing_dx_proc_value != cpt_norm:
        conflicts.append({
            "key": "diagnosis_to_procedure",
            "existing_key": existing_dx_proc_key,
            "existing_value": dx_to_proc.get(existing_dx_proc_key),
            "proposed_key": dx_display,
            "proposed_value": cpt_norm,
        })

    proc_existing_key = _find_existing_normalized_key(proc_to_dx, cpt_norm)
    proc_values = proc_to_dx.get(proc_existing_key) if proc_existing_key else []
    proc_has_dx = _normalized_list_contains(proc_values, dx_display)

    changes = {
        "diagnosis_to_medisoft": {
            "key": existing_dx_medisoft_key or dx_display,
            "value": medisoft_norm,
            "action": "already_present" if existing_dx_medisoft_value == medisoft_norm else "upsert",
        },
        "diagnosis_to_procedure": {
            "key": existing_dx_proc_key or dx_display,
            "value": cpt_norm,
            "action": "already_present" if existing_dx_proc_value == cpt_norm else "upsert",
        },
        "procedure_to_diagnosis": {
            "key": proc_existing_key or cpt_norm,
            "value": dx_display,
            "action": "already_present" if proc_has_dx else "append",
        },
    }
    return {
        "schema_version": SERVICE_LINE_INPUT_CROSSWALK_INTAKE_PATCH_SCHEMA_VERSION,
        "workflow_name": "service_line_input_crosswalk_intake",
        "workflow_boundary": "confirmed_config_update",
        "classification": "crosswalk_config_update",
        "source": _copy_without_mutation_fields(source or {}),
        "diagnosis_code": dx_display,
        "diagnosis_code_normalized": dx_norm,
        "medisoft_code": medisoft_norm,
        "medisoft_code_normalized": medisoft_norm,
        "cpt_code": cpt_norm,
        "changes": changes,
        "errors": errors,
        "conflicts": conflicts,
        "valid": (not errors and not conflicts),
        "requires_operator_confirmation": True,
        "claim_workflow_completion": False,
        "claims_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
    }


def merge_crosswalk_with_service_line_intake_patch(crosswalk, patch):
    merged = copy.deepcopy(crosswalk if isinstance(crosswalk, dict) else {})
    report = {
        "schema_version": "service_line_input_crosswalk_intake_apply.v1",
        "workflow_name": "service_line_input_crosswalk_intake",
        "workflow_boundary": "confirmed_config_update",
        "changed": False,
        "diagnosis_to_medisoft_upserted": 0,
        "diagnosis_to_procedure_upserted": 0,
        "procedure_to_diagnosis_added": 0,
        "error": "",
        "claim_workflow_completion": False,
        "claims_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
    }
    if not isinstance(patch, dict) or patch.get("schema_version") != SERVICE_LINE_INPUT_CROSSWALK_INTAKE_PATCH_SCHEMA_VERSION:
        report["error"] = "invalid_service_line_crosswalk_intake_patch"
        return merged, report
    if patch.get("workflow_boundary") != "confirmed_config_update":
        report["error"] = "invalid_service_line_crosswalk_intake_boundary"
        return merged, report
    if not patch.get("valid"):
        report["error"] = "service_line_crosswalk_intake_patch_not_valid"
        return merged, report

    if not isinstance(merged.get("diagnosis_to_medisoft"), dict):
        merged["diagnosis_to_medisoft"] = {}
    if not isinstance(merged.get("diagnosis_to_procedure"), dict):
        merged["diagnosis_to_procedure"] = {}
    if not isinstance(merged.get("procedure_to_diagnosis"), dict):
        merged["procedure_to_diagnosis"] = {}

    changes = patch.get("changes") or {}
    dx_med = changes.get("diagnosis_to_medisoft") or {}
    if dx_med.get("action") == "upsert":
        merged["diagnosis_to_medisoft"][dx_med.get("key")] = dx_med.get("value")
        report["diagnosis_to_medisoft_upserted"] += 1
        report["changed"] = True
    dx_proc = changes.get("diagnosis_to_procedure") or {}
    if dx_proc.get("action") == "upsert":
        merged["diagnosis_to_procedure"][dx_proc.get("key")] = dx_proc.get("value")
        report["diagnosis_to_procedure_upserted"] += 1
        report["changed"] = True
    proc_dx = changes.get("procedure_to_diagnosis") or {}
    if proc_dx.get("action") == "append":
        key = proc_dx.get("key")
        current = merged["procedure_to_diagnosis"].get(key)
        if not isinstance(current, list):
            current = []
        if not _normalized_list_contains(current, proc_dx.get("value")):
            current.append(proc_dx.get("value"))
            merged["procedure_to_diagnosis"][key] = sorted(current)
            report["procedure_to_diagnosis_added"] += 1
            report["changed"] = True
    return merged, report


def build_service_line_crosswalk_intake_event(row, patch, apply_report=None, save_ok=False,
                                              message=None):
    target = build_service_line_target_record(row=row or {})
    event = {
        "schema_version": SERVICE_LINE_INPUT_CROSSWALK_INTAKE_EVENT_SCHEMA_VERSION,
        "workflow_name": "service_line_input_crosswalk_intake",
        "workflow_boundary": "confirmed_config_update",
        "target_identity": target.get("target_identity"),
        "legacy_row_key": target.get("legacy_row_key"),
        "service_line_row_key": target.get("service_line_row_key"),
        "diagnosis_code": _clean_text((patch or {}).get("diagnosis_code")),
        "medisoft_code": _clean_text((patch or {}).get("medisoft_code")),
        "cpt_code": _clean_text((patch or {}).get("cpt_code")),
        "patch_valid": bool((patch or {}).get("valid")),
        "save_ok": bool(save_ok),
        "message": _clean_text(message),
        "apply_report": _copy_without_mutation_fields(apply_report or {}),
        "claim_workflow_completion": False,
        "claims_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
    }
    return event


def build_service_line_candidate_row(row):
    """Return a normalized review-only candidate service-line row."""
    shaped = shape_effective_service_line_row(row or {})
    clean = sanitize_service_line_preview_row(shaped)
    target = build_service_line_target_record(row=clean)
    diagnosis = _first_non_empty(clean, ("diagnosis", "diagnosis_code", "docx_diagnosis"))
    cpt = _first_non_empty(clean, ("cpt", "cpt_code", "procedure_code"))
    minutes = _first_non_empty(clean, ("minutes", "entered_minutes", "operator_minutes", "anesthesia_minutes"))
    charge_amount = _first_non_empty(clean, ("charge_amount", "amount", "charge"))
    candidate = {
        "schema_version": SERVICE_LINE_INPUT_CANDIDATE_ROW_SCHEMA_VERSION,
        "workflow_name": SERVICE_LINE_INPUT_WORKFLOW_NAME,
        "workflow_boundary": SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        "target_identity": dict(target.get("target_identity") or {}),
        "legacy_row_key": target.get("legacy_row_key"),
        "service_line_row_key": target.get("service_line_row_key"),
        "patient_id": target.get("patient_id", ""),
        "dos": target.get("dos", ""),
        "service_line_kind": target.get("service_line_kind", SERVICE_LINE_INPUT_DEFAULT_KIND),
        "line_ordinal": target.get("line_ordinal", 1),
        "status": normalize_service_line_row_status(clean.get("status") or clean.get("review_status")),
        "review_status": normalize_service_line_review_status(clean.get("review_status") or clean.get("status")),
        "diagnosis": _clean_text(diagnosis),
        "diagnosis_code": _clean_text(diagnosis),
        "diagnosis_normalized": normalize_diagnosis_code(diagnosis),
        "diagnosis_source": _clean_text(clean.get("diagnosis_source") or "docx_observation"),
        "cpt": normalize_cpt_code(cpt),
        "cpt_code": normalize_cpt_code(cpt),
        "cpt_source": _clean_text(clean.get("cpt_source")),
        "cpt_confidence": _clean_text(clean.get("cpt_confidence")),
        "cpt_status": _clean_text(clean.get("cpt_status")),
        "cpt_prediction_diagnosis_code": _clean_text(clean.get("cpt_prediction_diagnosis_code")),
        "minutes": _clean_text(minutes),
        "charge_display": _clean_text(clean.get("charge_display")),
        "charge_amount": _clean_text(charge_amount),
        "charge_note": _clean_text(clean.get("charge_note")),
        "charge_rule_id": _clean_text(clean.get("charge_rule_id")),
        "charge_source": _clean_text(clean.get("charge_source")),
        "charge_status": _clean_text(clean.get("charge_status")),
        "charge_schema_version": _clean_text(clean.get("charge_schema_version")),
        "validation_status": _clean_text(clean.get("validation_status") or "review_required"),
        "validation_note": _clean_text(clean.get("validation_note")),
        "source": _copy_without_mutation_fields(clean.get("source") or {}),
    }
    if "docx_position" in target:
        candidate["docx_position"] = target.get("docx_position")
    if minutes != "":
        try:
            candidate["minutes_normalized"] = int(_clean_text(minutes))
        except Exception:
            pass
    _apply_service_line_boundary_flags(candidate)
    return sanitize_service_line_preview_row(candidate)


def build_service_line_candidate_package(session_id, rows, generated_at_utc=None):
    """Return a review-only local package of candidate service-line rows."""
    candidate_rows = []
    for row in rows or []:
        candidate_rows.append(build_service_line_candidate_row(row))
    completion = build_service_line_review_completion_summary(session_id, candidate_rows)
    package = {
        "schema_version": SERVICE_LINE_INPUT_CANDIDATE_PACKAGE_SCHEMA_VERSION,
        "generated_at_utc": generated_at_utc or _iso_utc_now(),
        "workflow_name": SERVICE_LINE_INPUT_WORKFLOW_NAME,
        "workflow_boundary": SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        "service_line_input_session_id": _clean_text(session_id),
        "row_count": len(candidate_rows),
        "candidate_rows": candidate_rows,
        "review_completion": {
            "schema_version": completion.get("schema_version"),
            "service_line_input_review_complete": bool(completion.get("service_line_input_review_complete")),
            "entered": int(completion.get("entered", 0) or 0),
            "skipped": int(completion.get("skipped", 0) or 0),
            "cancelled": int(completion.get("cancelled", 0) or 0),
            "pending": int(completion.get("pending", 0) or 0),
            "invalid": int(completion.get("invalid", 0) or 0),
            "row_count": int(completion.get("row_count", 0) or 0),
        },
        "claims_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
    }
    return package


def format_service_line_candidate_report_lines(package):
    """Return ASCII lines for the local candidate/review report."""
    package = package if isinstance(package, dict) else {}
    completion = package.get("review_completion") if isinstance(package.get("review_completion"), dict) else {}
    lines = []
    lines.append("Service Line Input Review Summary")
    lines.append("=================================")
    lines.append("Generated: {0}".format(package.get("generated_at_utc", "")))
    lines.append("Session: {0}".format(package.get("service_line_input_session_id", "")))
    lines.append("Workflow boundary: {0}".format(package.get("workflow_boundary", SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY)))
    lines.append("Billing custody: claims_completion=False mutates_dat=False mutates_837p=False charges_entered=False")
    lines.append("")
    lines.append("Rows: {0} | entered={1} skipped={2} cancelled={3} pending={4} invalid={5}".format(
        int(completion.get("row_count", package.get("row_count", 0)) or 0),
        int(completion.get("entered", 0) or 0),
        int(completion.get("skipped", 0) or 0),
        int(completion.get("cancelled", 0) or 0),
        int(completion.get("pending", 0) or 0),
        int(completion.get("invalid", 0) or 0),
    ))
    lines.append("Review complete: {0}".format(bool(completion.get("service_line_input_review_complete"))))
    lines.append("")
    lines.append("Candidates")
    lines.append("DOS         PID        LN  DX          CPT    MIN   CHARGE    NOTE")
    lines.append("----------  ---------  --  ----------  -----  ----  --------  ------------------------")
    rows = package.get("candidate_rows") or []
    if not rows:
        lines.append("none")
    for row in rows:
        lines.append("{0:<10}  {1:<9}  {2:>2}  {3:<10}  {4:<5}  {5:<4}  {6:<8}  {7}".format(
            _clean_text(row.get("dos"))[:10],
            _clean_text(row.get("patient_id"))[:9],
            _clean_text(row.get("line_ordinal"))[:2],
            _clean_text(row.get("diagnosis") or row.get("diagnosis_code"))[:10],
            _clean_text(row.get("cpt") or row.get("cpt_code"))[:5],
            _clean_text(row.get("minutes"))[:4],
            _clean_text(row.get("charge_display"))[:8],
            _clean_text(row.get("charge_note"))[:24],
        ))
    return lines


def format_service_line_candidate_report_text(package):
    return "\n".join(format_service_line_candidate_report_lines(package)) + "\n"


def _parity_compare_text(left, right):
    return _clean_text(left) == _clean_text(right)


def _parity_compare_code(left, right):
    return normalize_service_line_code(left) == normalize_service_line_code(right)


def _parity_compare_amount(left, right):
    left_text = _clean_text(left).replace("$", "").replace(",", "")
    right_text = _clean_text(right).replace("$", "").replace(",", "")
    if not left_text and not right_text:
        return True
    try:
        return round(float(left_text or 0.0), 2) == round(float(right_text or 0.0), 2)
    except Exception:
        return left_text == right_text


def _candidate_lookup_keys(row):
    candidate = build_service_line_candidate_row(row)
    keys = []
    if candidate.get("service_line_row_key"):
        keys.append(candidate.get("service_line_row_key"))
    if candidate.get("legacy_row_key"):
        keys.append(candidate.get("legacy_row_key"))
    return candidate, keys


def build_service_line_parity_report(session_id, candidate_rows, downstream_rows,
                                     validation_id=None, generated_at_utc=None):
    """Compare SLI candidate rows to downstream DAT/837P evidence without custody."""
    downstream_by_key = {}
    downstream_clean_rows = []
    for row in downstream_rows or []:
        clean, keys = _candidate_lookup_keys(row)
        downstream_clean_rows.append(clean)
        for key in keys:
            downstream_by_key.setdefault(key, []).append(clean)

    results = []
    used_downstream_ids = set()
    exact = 0
    mismatch = 0
    missing = 0
    for row in candidate_rows or []:
        candidate, keys = _candidate_lookup_keys(row)
        matched = None
        matched_key = ""
        for key in keys:
            bucket = downstream_by_key.get(key) or []
            if len(bucket) == 1:
                matched = bucket[0]
                matched_key = key
                break
        if matched is None:
            missing += 1
            results.append({
                "target_identity": candidate.get("target_identity"),
                "service_line_row_key": candidate.get("service_line_row_key"),
                "legacy_row_key": candidate.get("legacy_row_key"),
                "parity_status": "missing_downstream",
                "mismatch_fields": [],
            })
            continue
        used_downstream_ids.add(id(matched))
        mismatch_fields = []
        if not _parity_compare_code(candidate.get("diagnosis_code"), matched.get("diagnosis_code")):
            mismatch_fields.append("diagnosis_code")
        if not _parity_compare_code(candidate.get("cpt_code"), matched.get("cpt_code")):
            mismatch_fields.append("cpt_code")
        if not _parity_compare_text(candidate.get("minutes"), matched.get("minutes")):
            mismatch_fields.append("minutes")
        if not _parity_compare_amount(candidate.get("charge_amount"), matched.get("charge_amount")):
            mismatch_fields.append("charge_amount")
        status = "exact_match" if not mismatch_fields else "mismatch"
        if status == "exact_match":
            exact += 1
        else:
            mismatch += 1
        results.append({
            "target_identity": candidate.get("target_identity"),
            "service_line_row_key": candidate.get("service_line_row_key"),
            "legacy_row_key": candidate.get("legacy_row_key"),
            "matched_key": matched_key,
            "parity_status": status,
            "mismatch_fields": mismatch_fields,
        })

    unrelated = 0
    for row in downstream_clean_rows:
        if id(row) not in used_downstream_ids:
            unrelated += 1

    total = len(candidate_rows or [])
    accuracy = 0.0
    if total:
        accuracy = round(float(exact) / float(total), 6)
    return {
        "schema_version": SERVICE_LINE_INPUT_PARITY_SCHEMA_VERSION,
        "generated_at_utc": generated_at_utc or _iso_utc_now(),
        "workflow_name": SERVICE_LINE_INPUT_WORKFLOW_NAME,
        "workflow_boundary": SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        "service_line_input_session_id": _clean_text(session_id),
        "validation_id": _clean_text(validation_id),
        "candidate_count": total,
        "downstream_count": len(downstream_clean_rows),
        "exact_match_count": exact,
        "mismatch_count": mismatch,
        "missing_downstream_count": missing,
        "unrelated_downstream_count": unrelated,
        "prediction_accuracy": accuracy,
        "rows": results,
        "claims_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
    }


def build_service_line_overlay_event(previous_row, new_row, session_id,
                                     action=None, generated_at_utc=None):
    """Return one append-only review event for changed overlay fields."""
    previous = build_service_line_candidate_row(previous_row or {})
    current = build_service_line_candidate_row(new_row or {})
    changed = {}
    for field in (
            "status",
            "diagnosis_code",
            "diagnosis_source",
            "cpt_code",
            "cpt_source",
            "minutes",
            "charge_amount",
            "charge_display",
            "charge_rule_id",
            "charge_source",
            "charge_note",
            "validation_status",
            "validation_note"):
        before = previous.get(field)
        after = current.get(field)
        if _clean_text(before) != _clean_text(after):
            changed[field] = {
                "before": _clean_text(before),
                "after": _clean_text(after),
            }
    if not changed:
        return None
    event = {
        "schema_version": SERVICE_LINE_INPUT_OVERLAY_EVENT_SCHEMA_VERSION,
        "generated_at_utc": generated_at_utc or _iso_utc_now(),
        "workflow_name": SERVICE_LINE_INPUT_WORKFLOW_NAME,
        "workflow_boundary": SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        "service_line_input_session_id": _clean_text(session_id),
        "event_action": _clean_text(action or "row_overlay_updated"),
        "target_identity": current.get("target_identity"),
        "legacy_row_key": current.get("legacy_row_key"),
        "service_line_row_key": current.get("service_line_row_key"),
        "changed_fields": changed,
        "before": dict([(key, value.get("before", "")) for key, value in changed.items()]),
        "after": dict([(key, value.get("after", "")) for key, value in changed.items()]),
        "effective_before": {
            "diagnosis_code": previous.get("diagnosis_code", ""),
            "cpt_code": previous.get("cpt_code", ""),
            "minutes": previous.get("minutes", ""),
            "status": previous.get("status", ""),
            "charge_amount": previous.get("charge_amount", ""),
        },
        "effective_after": {
            "diagnosis_code": current.get("diagnosis_code", ""),
            "cpt_code": current.get("cpt_code", ""),
            "minutes": current.get("minutes", ""),
            "status": current.get("status", ""),
            "charge_amount": current.get("charge_amount", ""),
        },
        "source": "service_line_input_overlay",
        "classification": "review_required",
        "claims_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
    }
    return event


def build_service_line_cleanup_readiness_report(marker_rows=None, release_cycle_complete=False):
    """Return telemetry for later removal of legacy Option A compatibility."""
    markers = []
    for row in marker_rows or []:
        if isinstance(row, dict):
            markers.append(dict(row))
        else:
            markers.append({"marker": _clean_text(row)})
    blockers = []
    if not release_cycle_complete:
        blockers.append("release_cycle_validation_not_confirmed")
    if markers:
        blockers.append("legacy_option_a_markers_present")
    return {
        "schema_version": SERVICE_LINE_INPUT_CLEANUP_READINESS_SCHEMA_VERSION,
        "workflow_name": SERVICE_LINE_INPUT_WORKFLOW_NAME,
        "workflow_boundary": SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        "cleanup_readiness": "ready" if not blockers else "not_ready",
        "release_cycle_complete": bool(release_cycle_complete),
        "legacy_marker_count": len(markers),
        "legacy_markers": markers,
        "blockers": blockers,
        "claims_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
    }


def _merge_values(base, values):
    if not isinstance(values, dict):
        return
    for key, value in values.items():
        if _field_name_is_forbidden_mutation(key):
            continue
        if value is None:
            continue
        if isinstance(value, str) and value == "":
            continue
        base[key] = copy.deepcopy(value)


def _overlay_values(operator_overlay):
    if not isinstance(operator_overlay, dict):
        return {}
    values = {}
    for key, value in operator_overlay.items():
        if key in ("target_identity", "identity", "corrections", "values"):
            continue
        values[key] = value
    for nested_key in ("values", "corrections"):
        nested = operator_overlay.get(nested_key)
        if isinstance(nested, dict):
            for key, value in nested.items():
                values[key] = value
    return values


def _identity_has_patient_dos(identity):
    return bool(identity.get("patient_id")) or bool(identity.get("dos"))


def _mapping_has_any_key(mapping, keys):
    if not isinstance(mapping, dict):
        return False
    nested = _nested_identity_source(mapping)
    for key in keys:
        if key in mapping and mapping.get(key) is not None and mapping.get(key) != "":
            return True
        if key in nested and nested.get(key) is not None and nested.get(key) != "":
            return True
    return False


def service_line_targets_match(expected_identity, candidate_identity):
    expected = build_service_line_target_identity(row=expected_identity)
    candidate = build_service_line_target_identity(row=candidate_identity)
    for key in ("patient_id", "dos"):
        if expected.get(key) and candidate.get(key) != expected.get(key):
            return False
    if _mapping_has_any_key(candidate_identity, _TARGET_KIND_KEYS):
        if candidate.get("service_line_kind") != expected.get("service_line_kind"):
            return False
    if _mapping_has_any_key(candidate_identity, _TARGET_ORDINAL_KEYS):
        if candidate.get("line_ordinal") != expected.get("line_ordinal"):
            return False
    if _mapping_has_any_key(candidate_identity, _TARGET_DOCX_POSITION_KEYS):
        if candidate.get("docx_position") != expected.get("docx_position"):
            return False
    return True


def _operator_overlay_matches_target(operator_overlay, target_identity):
    if not isinstance(operator_overlay, dict):
        return False
    overlay_identity_source = operator_overlay.get("target_identity")
    if not isinstance(overlay_identity_source, dict):
        overlay_identity_source = operator_overlay.get("identity")
    if not isinstance(overlay_identity_source, dict):
        overlay_identity_source = operator_overlay
    overlay_identity = build_service_line_target_identity(row=overlay_identity_source)
    has_identity_scope = (
        _mapping_has_any_key(overlay_identity_source, _TARGET_PATIENT_KEYS)
        or _mapping_has_any_key(overlay_identity_source, _TARGET_DOS_KEYS)
        or _mapping_has_any_key(overlay_identity_source, _TARGET_KIND_KEYS)
        or _mapping_has_any_key(overlay_identity_source, _TARGET_ORDINAL_KEYS)
        or _mapping_has_any_key(overlay_identity_source, _TARGET_DOCX_POSITION_KEYS)
    )
    if not has_identity_scope:
        return True
    target = build_service_line_target_identity(row=target_identity)
    for key in ("patient_id", "dos"):
        keys = _TARGET_PATIENT_KEYS if key == "patient_id" else _TARGET_DOS_KEYS
        if _mapping_has_any_key(overlay_identity_source, keys):
            if target.get(key) and overlay_identity.get(key) != target.get(key):
                return False
            if not target.get(key):
                return False
    if _mapping_has_any_key(overlay_identity_source, _TARGET_KIND_KEYS):
        if overlay_identity.get("service_line_kind") != target.get("service_line_kind"):
            return False
    if _mapping_has_any_key(overlay_identity_source, _TARGET_ORDINAL_KEYS):
        if overlay_identity.get("line_ordinal") != target.get("line_ordinal"):
            return False
    if _mapping_has_any_key(overlay_identity_source, _TARGET_DOCX_POSITION_KEYS):
        if overlay_identity.get("docx_position") != target.get("docx_position"):
            return False
    return True


def _first_non_empty(mapping, keys):
    if not isinstance(mapping, dict):
        return ""
    for key in keys:
        value = mapping.get(key)
        if value is not None and value != "":
            return value
    return ""


def _normalize_effective_row_codes(row):
    diagnosis = _first_non_empty(row, ("diagnosis", "docx_diagnosis", "diagnosis_code"))
    if diagnosis != "":
        row["diagnosis"] = _clean_text(diagnosis)
        diagnosis_norm = normalize_diagnosis_code(diagnosis)
        if diagnosis_norm:
            row["diagnosis_normalized"] = diagnosis_norm
    cpt = _first_non_empty(row, ("cpt", "cpt_code", "procedure_code", "CPT", "CPT Code"))
    cpt_norm = normalize_cpt_code(cpt)
    if cpt_norm:
        row["cpt"] = cpt_norm


def resolve_effective_service_line_row(docx_row=None, crosswalk=None,
                                       operator_overlay=None, fallback=None,
                                       target_identity=None):
    """Layer fallback, DOCX, crosswalk CPT prediction, then operator overlay."""
    base = {}
    if isinstance(fallback, dict):
        _merge_values(base, fallback)
    if isinstance(docx_row, dict):
        _merge_values(base, docx_row)

    if target_identity is None:
        target_source = {}
        if isinstance(fallback, dict):
            _merge_values(target_source, fallback)
        if isinstance(docx_row, dict):
            _merge_values(target_source, docx_row)
        target_identity = build_service_line_target_identity(row=target_source)
    else:
        target_identity = build_service_line_target_identity(row=target_identity)

    overlay_applied = _operator_overlay_matches_target(operator_overlay, target_identity)
    overlay = _overlay_values(operator_overlay) if overlay_applied else {}

    diagnosis_for_prediction = _first_non_empty(
        overlay,
        ("diagnosis", "docx_diagnosis", "diagnosis_code"),
    )
    if diagnosis_for_prediction == "":
        diagnosis_for_prediction = _first_non_empty(
            base,
            ("diagnosis", "docx_diagnosis", "diagnosis_code"),
        )

    prediction = predict_cpt_from_crosswalk(crosswalk, diagnosis_for_prediction)
    if prediction:
        _merge_values(base, prediction)

    if overlay:
        overlay_had_cpt = bool(normalize_cpt_code(_first_non_empty(
            overlay,
            ("cpt", "cpt_code", "procedure_code", "CPT", "CPT Code"),
        )))
        _merge_values(base, overlay)
        if overlay_had_cpt:
            base["cpt_source"] = overlay.get("cpt_source") or SERVICE_LINE_INPUT_CPT_SOURCE_OPERATOR
            base["cpt_confidence"] = overlay.get("cpt_confidence") or SERVICE_LINE_INPUT_CPT_CONFIDENCE_OPERATOR
            base["cpt_status"] = overlay.get("cpt_status") or SERVICE_LINE_INPUT_CPT_STATUS_OPERATOR
    elif not prediction and normalize_cpt_code(_first_non_empty(base, ("cpt", "cpt_code", "procedure_code"))):
        base.setdefault("cpt_source", SERVICE_LINE_INPUT_CPT_SOURCE_DOCX)

    _normalize_effective_row_codes(base)

    base["operator_overlay_applied"] = bool(overlay)
    base["operator_overlay_ignored"] = bool(operator_overlay) and not bool(overlay)
    base = shape_effective_service_line_row(base, target_identity=target_identity)

    return sanitize_service_line_preview_row(base)


def build_service_line_review_completion_summary(session_id, rows):
    """Return review-lane completion evidence without billing custody."""
    clean_rows = sanitize_service_line_preview_rows(rows)
    entered = 0
    skipped = 0
    cancelled = 0
    pending = 0
    invalid = 0
    for row in clean_rows:
        status = normalize_service_line_row_status(row.get("review_status") or row.get("status"))
        if status == "entered":
            entered += 1
        elif status == "skipped":
            skipped += 1
        elif status in ("cancelled", "auto_cancelled"):
            cancelled += 1
        elif status == "invalid":
            invalid += 1
        else:
            pending += 1
    summary = {
        "schema_version": "service_line_input_review_completion.v1",
        "workflow_name": SERVICE_LINE_INPUT_WORKFLOW_NAME,
        "workflow_boundary": SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        "service_line_input_session_id": _clean_text(session_id),
        "service_line_input_review_complete": pending == 0 and invalid == 0,
        "entered": entered,
        "skipped": skipped,
        "cancelled": cancelled,
        "pending": pending,
        "invalid": invalid,
        "row_count": len(clean_rows),
        "rows": clean_rows,
    }
    return sanitize_service_line_preview_row(summary)
