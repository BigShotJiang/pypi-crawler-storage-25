#!/usr/bin/env python
# pyright: reportAttributeAccessIssue=false
"""
Cloud Readiness launcher menu/actions extracted from launcher.py.

Keeps top-level launcher flow small while preserving exact operator-facing
menu wording and behavior.
"""
from __future__ import print_function

import binascii
import calendar
import io
import json
import os
import re
import sys
import threading
import time
import zipfile
from contextlib import contextmanager

try:
    from MediCafe import cloud_work_shutdown
except Exception:
    cloud_work_shutdown = None


def _console_heartbeat_enabled():
    env = str(os.environ.get('MEDICAFE_FORCE_CONSOLE_HEARTBEAT', '') or '').strip().lower()
    if env in ('1', 'true', 'yes', 'on'):
        return True
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


def _stdout_is_tty():
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


def _heartbeat_legacy_mode():
    env = str(os.environ.get('MEDICAFE_CONSOLE_HEARTBEAT_LEGACY', '') or '').strip().lower()
    return env in ('1', 'true', 'yes', 'on')


_POST_UPDATE_AUTOFOLLOW_STATE_FILENAME = 'post_update_cloud_autofollow_state.json'
_POST_UPDATE_DIAGNOSTIC_ATTACHMENT_BASENAME = 'post_update_autofollow_diagnostic_attachment.txt'
_CLOUD_WORK_SHUTDOWN_REQUEST_FILENAME = 'cloud_work_shutdown_request.json'
_POST_UPDATE_ACTIVE_STATUSES = (
    'evaluating_recommendation',
    'waiting_for_fresh_pipeline',
    'queued_send',
    'running_send',
    'running_diagnostic_action',
    'waiting_for_recommended_followup',
    'shutdown_requested',
)
_POST_UPDATE_DIAGNOSTIC_ACTIONS = (
    'historical_phase_d_reprocess',
    'phase_d_dat_smoke',
    'phase_d_dat_verification_rerun',
)
_POST_UPDATE_FINISHED_STATUSES = ('idle', 'succeeded', 'failed', 'stale')
_POST_UPDATE_STALE_DEFAULT_SEC = 2 * 60 * 60
_POST_UPDATE_MISSING_JOB_STALE_DEFAULT_SEC = 5 * 60
_POST_UPDATE_WATCHDOG_DEFAULT_SEC = 10 * 60
_POST_UPDATE_WATCHDOG_POLL_DEFAULT_SEC = 15
_POST_UPDATE_DIAGNOSTIC_HANDOFF_LIMIT = 3
_POST_UPDATE_DAT_SMOKE_HANDOFF_TIMEOUT_DEFAULT_SEC = 10 * 60
_POST_UPDATE_SAFE_CANCEL_GRACE_DEFAULT_SEC = 60
_POST_UPDATE_SAFE_CANCEL_POLL_DEFAULT_SEC = 2
_CLOUD_READINESS_AUTOFOLLOW_STATE_FILENAME = 'cloud_readiness_autofollow_state.json'
_CLOUD_READINESS_AUTOFOLLOW_DEDUP_DEFAULT_SEC = 15 * 60
_MAIN_MENU_CLOUD_AUTOFOLLOW_SOURCE = 'main_menu_cloud_autofollow'
_MAIN_MENU_CLOUD_AUTOFOLLOW_MODE = 'main_menu_autofollow'


def _utc_now():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def _automatic_routing_reason_line(recommendation=None, fallback_reason=''):
    try:
        from MediCafe import launcher_next_step_assistant as assistant
        return assistant.automatic_routing_reason_line(
            recommendation if isinstance(recommendation, dict) else {},
            fallback_reason=fallback_reason,
        )
    except Exception:
        reason = str(fallback_reason or '').strip() or 'automatic routing used the current recommendation'
        return 'Why: {0}.'.format(reason.rstrip('.'))


def _parse_iso_utc_to_epoch(value):
    raw = str(value or '').strip()
    if not raw:
        return None
    try:
        return calendar.timegm(time.strptime(raw, '%Y-%m-%dT%H:%M:%SZ'))
    except Exception:
        return None

# ASCII-only spinner for XP / narrow consoles (no Unicode).
_HEARTBEAT_SPINNER_FRAMES = ('|', '/', '-', '\\')


class _ConsoleHeartbeatProgress(object):
    """Thread-safe mutable stage text for console heartbeat updates."""

    def __init__(self, activity_label, sparse_log=False):
        self._activity_label = str(activity_label or 'working').strip() or 'working'
        self._stage = ''
        self._lock = threading.Lock()
        self._sparse_log = bool(sparse_log)
        self._sparse_last = None

    def update(self, stage_label):
        stage_text = str(stage_label or '').strip()
        with self._lock:
            self._stage = stage_text
            if self._sparse_log and stage_text and stage_text != self._sparse_last:
                self._sparse_last = stage_text
                try:
                    print('  ... {0}'.format(stage_text), flush=True)
                except Exception:
                    pass

    def render(self):
        with self._lock:
            stage_text = self._stage
        if stage_text:
            return '{0}; {1}'.format(self._activity_label, stage_text)
        return self._activity_label

    def get_activity(self):
        with self._lock:
            return self._activity_label

    def get_stage(self):
        with self._lock:
            return self._stage


@contextmanager
def _console_activity_heartbeat(activity_label, first_delay_sec=2.0, interval_sec=4.0):
    """Show liveness during blocking work: TTY uses milestone + single-line pulse; else sparse stage lines."""
    tty = _stdout_is_tty()
    legacy = _heartbeat_legacy_mode()
    enabled = _console_heartbeat_enabled()

    use_legacy_worker = enabled and tty and legacy
    use_new_pulse = enabled and tty and not legacy
    sparse_log = not (use_legacy_worker or use_new_pulse)

    progress = _ConsoleHeartbeatProgress(activity_label, sparse_log=sparse_log)

    if not use_legacy_worker and not use_new_pulse:
        yield progress
        return

    stop = threading.Event()
    state = {'live_width': 0}

    def _worker_legacy():
        delay = first_delay_sec
        while True:
            if stop.wait(delay):
                return
            try:
                print('  ... still working ({0})'.format(progress.render()), flush=True)
            except Exception:
                pass
            delay = interval_sec

    def _worker_new_pulse():
        delay = first_delay_sec
        last_milestone_stage = None
        stage_idx = 0
        live_width = 0
        live_first = True
        pulse = 0
        had_live = False

        while True:
            if stop.wait(delay):
                break
            activity = progress.get_activity()
            stage = progress.get_stage()
            label = stage if stage else activity

            if stage and stage != last_milestone_stage:
                if had_live and live_width > 0:
                    try:
                        sys.stdout.write('\n')
                        sys.stdout.flush()
                    except Exception:
                        pass
                stage_idx += 1
                try:
                    print('  [{0}] {1}'.format(stage_idx, stage), flush=True)
                except Exception:
                    pass
                last_milestone_stage = stage
                live_first = True
                live_width = 0
                had_live = True

            spin = _HEARTBEAT_SPINNER_FRAMES[pulse % len(_HEARTBEAT_SPINNER_FRAMES)]
            pulse += 1
            line = '  working: {0}  {1}'.format(label, spin)
            try:
                padded = line.ljust(max(live_width, len(line)))
                if live_first:
                    sys.stdout.write(padded)
                    live_first = False
                else:
                    sys.stdout.write('\r' + padded)
                sys.stdout.flush()
                live_width = len(padded)
                state['live_width'] = live_width
                had_live = True
            except Exception:
                pass
            delay = interval_sec

    target = _worker_legacy if use_legacy_worker else _worker_new_pulse
    thread = threading.Thread(target=target)
    thread.daemon = True
    thread.start()
    try:
        yield progress
    finally:
        stop.set()
        thread.join(timeout=0.5)
        if use_new_pulse and state.get('live_width', 0) > 0:
            try:
                w = int(state['live_width'])
                sys.stdout.write('\r' + (' ' * w) + '\n')
                sys.stdout.flush()
            except Exception:
                pass


@contextmanager
def _maybe_console_activity_heartbeat(activity_label, quiet=False):
    if quiet:
        yield _ConsoleHeartbeatProgress(activity_label)
        return
    with _console_activity_heartbeat(activity_label) as heartbeat:
        yield heartbeat


class LauncherCloudReadinessMixin(object):
    """Mixin providing Cloud Readiness menus and action handlers."""

    def _new_support_send_operation_id(self, send_type):
        token = ''
        try:
            token = binascii.hexlify(os.urandom(3)).decode('ascii')
        except Exception:
            token = str(int(time.time() * 1000) % 1000000)
        return 'ssop_{0}_{1}_{2}'.format(
            str(send_type or 'unknown').strip() or 'unknown',
            time.strftime('%Y%m%d%H%M%S', time.gmtime()),
            token,
        )

    def _support_send_progress_log_level(self, event_name, payload):
        """INFO on progress_stage change per job_id; DEBUG on heartbeat repeats."""
        log_level = 'INFO'
        ev = str(event_name or '').strip()
        if ev != 'support_send_job_progress' or not isinstance(payload, dict):
            return log_level
        cache = getattr(self, '_support_send_progress_last_stage', None)
        if not isinstance(cache, dict):
            cache = {}
            setattr(self, '_support_send_progress_last_stage', cache)
        jid = str(payload.get('job_id', '') or '').strip()
        stage = str(payload.get('progress_stage', '') or '').strip()
        key = jid or '__no_job__'
        prev = cache.get(key)
        if prev == stage:
            return 'DEBUG'
        cache[key] = stage
        return 'INFO'

    def _log_support_send_event(self, event_name, details):
        """Best-effort centralized logging for support send diagnostics."""
        try:
            from MediCafe.MediLink_ConfigLoader import log as config_log
            payload = details if isinstance(details, dict) else {}
            log_level = self._support_send_progress_log_level(event_name, payload)
            parts = []
            for key in (
                    'operation_id',
                    'job_id',
                    'send_type',
                    'phase',
                    'status',
                    'progress_stage',
                    'heartbeat_at_utc',
                    'duration_ms',
                    'source',
                    'send_source',
                    'operator_execution_mode',
                    'policy_decision',
                    'policy_reason',
                    'installed_version',
                    'recommendation_action_kind',
                    'frozen_recommendation',
                    'result_message'):
                if key in payload:
                    parts.append('{0}={1}'.format(key, payload.get(key)))
            summary = ' '.join(parts).strip()
            config_log(
                'CloudReadiness {0}{1}'.format(
                    str(event_name or ''),
                    (' ' + summary) if summary else '',
                ),
                level=log_level,
                console_output=False,
            )
        except Exception:
            pass

    def _post_update_autofollow_stale_sec(self):
        raw = str(os.environ.get('MEDICAFE_POST_UPDATE_AUTOFOLLOW_STALE_SEC', '') or '').strip()
        if not raw:
            return _POST_UPDATE_STALE_DEFAULT_SEC
        try:
            value = int(raw)
        except Exception:
            return _POST_UPDATE_STALE_DEFAULT_SEC
        return max(60, value)

    def _post_update_autofollow_missing_job_stale_sec(self):
        raw = str(os.environ.get('MEDICAFE_POST_UPDATE_AUTOFOLLOW_MISSING_JOB_STALE_SEC', '') or '').strip()
        if not raw:
            return _POST_UPDATE_MISSING_JOB_STALE_DEFAULT_SEC
        try:
            value = int(raw)
        except Exception:
            return _POST_UPDATE_MISSING_JOB_STALE_DEFAULT_SEC
        return max(30, value)

    def _post_update_safe_cancel_grace_sec(self):
        raw = str(os.environ.get('MEDICAFE_CLOUD_SHUTDOWN_GRACE_SEC', '') or '').strip()
        if not raw:
            return _POST_UPDATE_SAFE_CANCEL_GRACE_DEFAULT_SEC
        try:
            value = int(raw)
        except Exception:
            return _POST_UPDATE_SAFE_CANCEL_GRACE_DEFAULT_SEC
        return max(0, value)

    def _post_update_safe_cancel_poll_sec(self):
        raw = str(os.environ.get('MEDICAFE_CLOUD_SHUTDOWN_POLL_SEC', '') or '').strip()
        if not raw:
            return _POST_UPDATE_SAFE_CANCEL_POLL_DEFAULT_SEC
        try:
            value = int(raw)
        except Exception:
            return _POST_UPDATE_SAFE_CANCEL_POLL_DEFAULT_SEC
        return max(1, value)

    def _post_update_shutdown_request_id(self):
        try:
            token = binascii.hexlify(os.urandom(4)).decode('ascii')
        except Exception:
            token = str(int(time.time() * 1000) % 100000000)
        return 'cloud_shutdown_{0}_{1}'.format(os.getpid(), token)

    def _post_update_autofollow_state_path(self):
        cr = self._cloud_readiness_service()
        if cr is None:
            return ''
        try:
            lab_root = cr.resolve_lab_root(self.repo_root)
        except Exception:
            lab_root = ''
        if not lab_root:
            return ''
        return os.path.join(lab_root, 'reports', _POST_UPDATE_AUTOFOLLOW_STATE_FILENAME)

    def _cloud_work_shutdown_request_path(self):
        state_path = self._post_update_autofollow_state_path()
        if not state_path:
            return ''
        if cloud_work_shutdown is not None:
            return cloud_work_shutdown.request_path(os.path.dirname(os.path.dirname(state_path)))
        return os.path.join(os.path.dirname(state_path), _CLOUD_WORK_SHUTDOWN_REQUEST_FILENAME)

    def _read_cloud_work_shutdown_request(self):
        state_path = self._post_update_autofollow_state_path()
        if not state_path:
            return {}
        if cloud_work_shutdown is not None:
            return cloud_work_shutdown.read_request(os.path.dirname(os.path.dirname(state_path)))
        path = self._cloud_work_shutdown_request_path()
        if not path or not os.path.isfile(path):
            return {}
        try:
            with open(path, 'r') as handle:
                data = json.load(handle)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _write_cloud_work_shutdown_request(self, payload):
        state_path = self._post_update_autofollow_state_path()
        if not state_path:
            return ''
        if cloud_work_shutdown is not None:
            return cloud_work_shutdown.write_request(os.path.dirname(os.path.dirname(state_path)), payload)
        path = self._cloud_work_shutdown_request_path()
        if not path:
            return ''
        data = payload if isinstance(payload, dict) else {}
        try:
            parent = os.path.dirname(path)
            if parent and not os.path.isdir(parent):
                os.makedirs(parent)
            tmp_path = path + '.tmp'
            with io.open(tmp_path, 'w', encoding='utf-8') as handle:
                json.dump(data, handle, indent=2, sort_keys=True)
                handle.write('\n')
            if os.path.exists(path):
                try:
                    os.remove(path)
                except Exception:
                    pass
            os.rename(tmp_path, path)
            return path
        except Exception:
            return ''

    def _read_post_update_autofollow_state(self):
        path = self._post_update_autofollow_state_path()
        if not path or not os.path.isfile(path):
            return {}
        try:
            with open(path, 'r') as handle:
                data = json.load(handle)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _write_post_update_autofollow_state(self, state):
        path = self._post_update_autofollow_state_path()
        if not path:
            return False
        payload = state if isinstance(state, dict) else {}
        try:
            parent = os.path.dirname(path)
            if parent and not os.path.isdir(parent):
                os.makedirs(parent)
            tmp_path = path + '.tmp'
            with io.open(tmp_path, 'w', encoding='utf-8') as handle:
                json.dump(payload, handle, indent=2, sort_keys=True)
                handle.write('\n')
            if os.path.exists(path):
                try:
                    os.remove(path)
                except Exception:
                    pass
            os.rename(tmp_path, path)
            return True
        except Exception:
            return False

    def _patch_post_update_autofollow_state(self, updates):
        state = self._read_post_update_autofollow_state()
        if not isinstance(state, dict):
            state = {}
        state.update(updates or {})
        state['updated_at_utc'] = _utc_now()
        self._write_post_update_autofollow_state(state)
        return state

    def _post_update_phase_c_probe_enabled(self):
        raw = str(os.environ.get('MEDICAFE_POST_UPDATE_PHASE_C_PROBE', '1') or '').strip().lower()
        return raw not in ('0', 'false', 'no', 'off', 'n')

    def _maybe_start_post_update_phase_c_probe(self, installed_version):
        """
        Start one shadow pipeline probe per installed version when post-update
        evidence would otherwise keep reporting stale Phase C handoff data.

        This intentionally uses the orchestrator path instead of invoking Phase C
        directly, so Phase B->C manifest lineage and pipeline locking stay the
        single source of truth.
        """
        version = str(installed_version or '').strip()
        if not self._post_update_phase_c_probe_enabled():
            self._patch_post_update_autofollow_state({
                'phase_c_probe_status': 'disabled',
                'phase_c_probe_reason': 'MEDICAFE_POST_UPDATE_PHASE_C_PROBE=0',
            })
            return False
        st0 = self._read_post_update_autofollow_state()
        if str(st0.get('phase_c_probe_started_for_version', '') or '').strip() == version:
            return False
        cr = self._cloud_readiness_service()
        if cr is None:
            return False
        lab_root = ''
        try:
            lab_root = cr.resolve_lab_root(self.repo_root)
        except Exception:
            lab_root = ''
        if not lab_root:
            return False
        diag = {}
        cursor = {}
        try:
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'r') as handle:
                raw = json.load(handle)
            if isinstance(raw, dict):
                diag = raw
        except Exception:
            diag = {}
        try:
            with open(os.path.join(lab_root, 'run_cursor.json'), 'r') as handle:
                raw = json.load(handle)
            if isinstance(raw, dict):
                cursor = raw
        except Exception:
            cursor = {}
        freshness = ''
        try:
            from MediCafe.layer1_readiness_model import classify_phase_c_handoff_freshness
            hf = classify_phase_c_handoff_freshness(lab_root, diag, cursor)
            if isinstance(hf, dict):
                freshness = str(hf.get('phase_c_handoff_freshness') or '').strip()
        except Exception:
            freshness = ''
        current_attempt_path = str(
            diag.get('last_phase_c_current_attempt_path')
            or cursor.get('last_phase_c_current_attempt_path')
            or os.path.join(lab_root, 'reports', 'phase_c_current_attempt_latest.json')
            or ''
        ).strip()
        current_attempt_present = bool(current_attempt_path and os.path.isfile(current_attempt_path))
        circuit_open = bool(diag.get('phase_c_circuit_open') or cursor.get('phase_c_circuit_open'))
        has_phase_c_context = bool(
            diag.get('last_manifest_sha256')
            or cursor.get('last_manifest_sha256')
            or diag.get('last_phase_c_run_id')
            or cursor.get('last_phase_c_run_id')
            or diag.get('last_phase_c_execution_handoff_report_path')
            or cursor.get('last_phase_c_execution_handoff_report_path')
        )
        should_probe = (
            freshness == 'phase_c_handoff_stale_after_deploy'
            or circuit_open
            or (has_phase_c_context and not current_attempt_present)
        )
        if not should_probe:
            self._patch_post_update_autofollow_state({
                'phase_c_probe_status': 'not_needed',
                'phase_c_probe_reason': freshness or 'current_attempt_present',
            })
            return False
        self._patch_post_update_autofollow_state({
            'phase_c_probe_status': 'starting',
            'phase_c_probe_reason': freshness or ('phase_c_circuit_open' if circuit_open else 'current_attempt_missing'),
            'phase_c_probe_started_for_version': version,
            'phase_c_probe_started_at_utc': _utc_now(),
        })
        try:
            ok, msg, data = cr.run_shadow_pipeline(self.repo_root, self.python_exe, self.environment)
        except Exception as exc:
            self._patch_post_update_autofollow_state({
                'phase_c_probe_status': 'failed_to_start',
                'phase_c_probe_error': str(exc)[:300],
                'phase_c_probe_finished_at_utc': _utc_now(),
            })
            return False
        self._patch_post_update_autofollow_state({
            'phase_c_probe_status': 'started' if ok else 'failed_to_start',
            'phase_c_probe_start_message': str(msg or '')[:300],
            'phase_c_probe_start_payload': data if isinstance(data, dict) else {},
            'phase_c_probe_finished_at_utc': '' if ok else _utc_now(),
        })
        try:
            self._log_post_update_autofollow_event('phase_c_probe_started' if ok else 'phase_c_probe_failed_to_start', {
                'installed_version': version,
                'status': 'phase_c_probe',
                'stage': 'post_update_phase_c_probe',
                'ok': bool(ok),
                'reason': freshness or ('phase_c_circuit_open' if circuit_open else 'current_attempt_missing'),
                'message': str(msg or '')[:300],
            })
        except Exception:
            pass
        return bool(ok)

    def _assess_post_update_evidence_freshness(self, installed_version):
        cr = self._cloud_readiness_service()
        if cr is None:
            return {}
        lab_root = ''
        try:
            lab_root = cr.resolve_lab_root(self.repo_root)
        except Exception:
            lab_root = ''
        if not lab_root:
            return {}
        try:
            from MediCafe.post_update_evidence_freshness import assess_post_update_evidence_freshness
            return assess_post_update_evidence_freshness(lab_root, installed_version)
        except Exception as exc:
            return {
                'post_update_evidence_freshness_status': 'unavailable',
                'post_update_freshness_blocking_reason': 'freshness_assessment_error:{0}'.format(
                    exc.__class__.__name__),
                'post_update_fresh_pipeline_status': 'unknown',
                'installed_version': str(installed_version or ''),
            }

    def _patch_post_update_freshness_fields(self, assessment):
        data = assessment if isinstance(assessment, dict) else {}
        keys = (
            'post_update_evidence_freshness_status',
            'post_update_fresh_shadow_run_id',
            'post_update_fresh_machine_app_version',
            'post_update_freshness_blocking_reason',
            'post_update_fresh_pipeline_status',
        )
        updates = {}
        for key in keys:
            if key in data:
                updates[key] = data.get(key)
        if data.get('shadow_report_path'):
            updates['post_update_fresh_shadow_report_path'] = data.get('shadow_report_path')
        if data.get('evidence_mode'):
            updates['post_update_fresh_evidence_mode'] = data.get('evidence_mode')
        if updates:
            return self._patch_post_update_autofollow_state(updates)
        return self._read_post_update_autofollow_state()

    def _queue_post_update_fresh_pipeline_unavailable(self, installed_version, assessment, reason):
        version = str(installed_version or '').strip()
        info = assessment if isinstance(assessment, dict) else {}
        reason_text = str(reason or info.get('post_update_freshness_blocking_reason') or 'fresh_pipeline_unavailable').strip()
        lines = [
            'event=post_update_fresh_pipeline_unavailable',
            'reason={0}'.format(reason_text),
            'freshness_status={0}'.format(str(info.get('post_update_evidence_freshness_status', '') or '-')),
            'fresh_pipeline_status={0}'.format(str(info.get('post_update_fresh_pipeline_status', '') or '-')),
            'last_completed_run_id={0}'.format(str(info.get('last_completed_run_id', '') or '-')),
            'active_run_id={0}'.format(str(info.get('active_run_id', '') or '-')),
            'shadow_report_path={0}'.format(str(info.get('shadow_report_path', '') or '-')),
        ]
        self._write_post_update_autofollow_diagnostic_attachment(lines, installed_version=version)
        self._patch_post_update_autofollow_state({
            'status': 'evaluating_recommendation',
            'stage': 'post_update_fresh_pipeline_unavailable',
            'recommendation_action_kind': 'post_update_fresh_pipeline_unavailable',
            'send_type': 'system_health',
            'last_reason': reason_text,
        })
        rec = {
            'primary_send': 'system_health',
            'preferred_when_stable': 'system_health',
            'best_now_send': 'system_health',
            'summary_line': 'Post-update fresh pipeline evidence is unavailable.',
            'why_lines': [reason_text],
            'why_summary': reason_text,
            'pipeline_label': str(info.get('post_update_fresh_pipeline_status', '') or 'unknown'),
            'pipeline_running': str(info.get('post_update_fresh_pipeline_status', '') or '') == 'running',
            'recommended_action_kind': 'post_update_fresh_pipeline_unavailable',
            'best_now_action_kind': 'post_update_fresh_pipeline_unavailable',
            'preferred_when_stable_action_kind': 'post_update_fresh_pipeline_unavailable',
            'recommended_report_kind': 'system_health_pack',
            'recommended_artifact_classes': [],
            'action_requires_confirmation': False,
            'action_preview': {},
            'action_reason_lines': [reason_text],
            'post_update_evidence_freshness': dict(info),
        }
        return self._queue_post_update_recommendation_evidence(
            rec,
            'system_health',
            version,
            'post_update_fresh_pipeline_unavailable',
            reason_text,
        )

    def _ensure_post_update_fresh_evidence(self, installed_version):
        version = str(installed_version or '').strip()
        assessment = self._assess_post_update_evidence_freshness(version)
        self._patch_post_update_freshness_fields(assessment)
        status = str(assessment.get('post_update_evidence_freshness_status', '') or '').strip()
        if status == 'fresh':
            return True

        st0 = self._read_post_update_autofollow_state()
        already_started = (
            str(st0.get('post_update_fresh_pipeline_started_for_version', '') or '').strip() == version
        )
        if status == 'live_status' or already_started:
            self._patch_post_update_autofollow_state({
                'status': 'waiting_for_fresh_pipeline',
                'stage': 'waiting_for_fresh_pipeline',
                'last_reason': str(assessment.get('post_update_freshness_blocking_reason') or 'fresh_pipeline_running'),
                'post_update_fresh_pipeline_started_for_version': version,
                'phase_c_probe_status': 'superseded_by_post_update_freshness_gate',
                'phase_c_probe_reason': 'package_wide_freshness_required',
            })
            self._start_post_update_autofollow_watchdog(version)
            return False

        cr = self._cloud_readiness_service()
        if cr is None:
            self._queue_post_update_fresh_pipeline_unavailable(version, assessment, 'cloud_readiness_unavailable')
            return False
        self._patch_post_update_autofollow_state({
            'status': 'waiting_for_fresh_pipeline',
            'stage': 'starting_fresh_pipeline',
            'last_reason': str(assessment.get('post_update_freshness_blocking_reason') or 'fresh_pipeline_required'),
            'post_update_fresh_pipeline_started_for_version': version,
            'post_update_fresh_pipeline_started_at_utc': _utc_now(),
            'phase_c_probe_status': 'superseded_by_post_update_freshness_gate',
            'phase_c_probe_reason': 'package_wide_freshness_required',
        })
        try:
            ok, msg, data = cr.run_shadow_pipeline(self.repo_root, self.python_exe, self.environment)
        except Exception as exc:
            failed = dict(assessment)
            failed['post_update_freshness_blocking_reason'] = 'fresh_pipeline_start_exception:{0}'.format(
                exc.__class__.__name__)
            self._patch_post_update_freshness_fields(failed)
            self._queue_post_update_fresh_pipeline_unavailable(version, failed, failed.get('post_update_freshness_blocking_reason'))
            return False
        self._patch_post_update_autofollow_state({
            'post_update_fresh_pipeline_launch_ok': bool(ok),
            'post_update_fresh_pipeline_launch_message': str(msg or '')[:300],
            'post_update_fresh_pipeline_launch_payload': data if isinstance(data, dict) else {},
            'post_update_fresh_pipeline_status': 'running' if ok else 'launch_failed',
        })
        if not ok:
            failed = dict(assessment)
            failed['post_update_fresh_pipeline_status'] = 'launch_failed'
            failed['post_update_freshness_blocking_reason'] = str(msg or 'fresh_pipeline_launch_failed')[:300]
            self._queue_post_update_fresh_pipeline_unavailable(version, failed, failed.get('post_update_freshness_blocking_reason'))
            return False
        self._log_post_update_autofollow_event('fresh_pipeline_started', {
            'installed_version': version,
            'status': 'waiting_for_fresh_pipeline',
            'stage': 'starting_fresh_pipeline',
            'reason': str(assessment.get('post_update_freshness_blocking_reason') or 'fresh_pipeline_required'),
            'message': str(msg or '')[:300],
        })
        self._start_post_update_autofollow_watchdog(version)
        return False

    def _write_post_update_autofollow_diagnostic_attachment(self, lines, installed_version=''):
        """Small lab/reports note for next run-evidence or system-health Cloud Readiness bundles."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return ''
        lab_root = ''
        try:
            lab_root = cr.resolve_lab_root(self.repo_root)
        except Exception:
            lab_root = ''
        if not lab_root:
            return ''
        reports_dir = os.path.join(lab_root, 'reports')
        iv = str(installed_version or '').strip()
        if not iv:
            pst = self._read_post_update_autofollow_state()
            if isinstance(pst, dict):
                iv = str(pst.get('installed_version', '') or '').strip()
        try:
            if reports_dir and not os.path.isdir(reports_dir):
                os.makedirs(reports_dir)
            path = os.path.join(reports_dir, _POST_UPDATE_DIAGNOSTIC_ATTACHMENT_BASENAME)
            hdr = [
                'post_update_cloud_autofollow diagnostic_attachment',
                'generated_at_utc={0}'.format(_utc_now()),
                'installed_version={0}'.format(iv or '-'),
                'source=post_update_cloud_autofollow',
            ]
            body = hdr + list(lines if isinstance(lines, list) else [lines])
            with io.open(path, 'w', encoding='utf-8') as handle:
                handle.write('\n'.join([str(line) for line in body]) + '\n')
            return path
        except Exception:
            return ''

    def _post_update_dat_smoke_handoff_timeout_sec(self):
        raw = str(os.environ.get('MEDICAFE_POST_UPDATE_DAT_SMOKE_HANDOFF_TIMEOUT_SEC', '') or '').strip()
        if not raw:
            return _POST_UPDATE_DAT_SMOKE_HANDOFF_TIMEOUT_DEFAULT_SEC
        try:
            value = int(raw)
        except Exception:
            return _POST_UPDATE_DAT_SMOKE_HANDOFF_TIMEOUT_DEFAULT_SEC
        if value < 1:
            return _POST_UPDATE_DAT_SMOKE_HANDOFF_TIMEOUT_DEFAULT_SEC
        return value

    def _read_post_update_dat_smoke_state(self):
        cr = self._cloud_readiness_service()
        if cr is None or not hasattr(cr, 'read_phase_d_dat_smoke_state'):
            return {}
        try:
            data = cr.read_phase_d_dat_smoke_state(self.repo_root)
        except Exception:
            data = {}
        return data if isinstance(data, dict) else {}

    def _post_update_dat_smoke_handoff_diagnostics(self, smoke_state):
        data = smoke_state if isinstance(smoke_state, dict) else {}
        keys = (
            'last_status',
            'last_assessment',
            'last_assessment_detail',
            'last_started_at_utc',
            'last_finished_at_utc',
            'last_report_path',
            'last_error',
            'last_requested_anchor_run_id',
            'last_requested_context_run_id',
            'last_remediation_issue_code',
            'last_reference_phase_d_summary_path',
            'last_smoke_run_id',
        )
        out = {}
        for key in keys:
            if key in data:
                out[key] = data.get(key)
        return out

    def _post_update_dat_smoke_target_matches(self, smoke_state, rec, post_update_state=None):
        data = smoke_state if isinstance(smoke_state, dict) else {}
        pst = post_update_state if isinstance(post_update_state, dict) else {}
        # Align with _run_phase_d_dat_smoke_action (uses _dat_smoke_target_from_rec only).
        # Post-update autofollow also stamps context_run_id via _send_job_anchor_context_issue,
        # which may use recommendation_live_run_id; that must not override the smoke launch
        # identity unless the in-flight smoke state already agrees (see pst coherence below).
        anchor, context, issue_code, _ref_path = self._dat_smoke_target_from_rec(rec if isinstance(rec, dict) else {})
        if not anchor:
            anchor = str(pst.get('anchor_run_id', '') or '').strip()
        if not context:
            context = str(pst.get('context_run_id', '') or anchor or '').strip()
        else:
            pst_c = str(pst.get('context_run_id', '') or '').strip()
            state_context = str(data.get('last_requested_context_run_id', '') or '').strip()
            if (
                pst_c
                and state_context
                and pst_c == state_context
                and pst_c != context
                and anchor
                and context == anchor
            ):
                context = pst_c
        if not issue_code:
            issue_code = str(pst.get('remediation_issue_code', '') or pst.get('issue_code', '') or '').strip()
        state_anchor = str(data.get('last_requested_anchor_run_id', '') or '').strip()
        state_context = str(data.get('last_requested_context_run_id', '') or '').strip()
        state_issue = str(data.get('last_remediation_issue_code', '') or '').strip()
        if anchor and state_anchor and anchor != state_anchor:
            return False
        if context and state_context and context != state_context:
            return False
        if issue_code and state_issue and issue_code != state_issue:
            return False
        return True

    def _write_post_update_dat_smoke_timeout_attachment(self, smoke_state, installed_version, next_action):
        data = smoke_state if isinstance(smoke_state, dict) else {}
        lines = [
            'diagnostic_action_id=phase_d_dat_smoke',
            'diagnostic_result=timeout_fail_closed',
            'fail_closed=true',
            'next_action_after_timeout={0}'.format(str(next_action or '') or '-'),
            'state_last_status={0}'.format(str(data.get('last_status', '') or '-')[:200]),
            'state_last_started_at_utc={0}'.format(str(data.get('last_started_at_utc', '') or '-')[:200]),
            'state_last_finished_at_utc={0}'.format(str(data.get('last_finished_at_utc', '') or '-')[:200]),
            'state_last_report_path={0}'.format(str(data.get('last_report_path', '') or '-')[:500]),
            'target_anchor_run_id={0}'.format(str(data.get('last_requested_anchor_run_id', '') or '-')[:200]),
            'target_context_run_id={0}'.format(str(data.get('last_requested_context_run_id', '') or '-')[:200]),
            'target_issue_code={0}'.format(str(data.get('last_remediation_issue_code', '') or '-')[:200]),
            'note=DAT smoke was still non-terminal at handoff timeout; no smoke report is accepted as anchored evidence.',
        ]
        return self._write_post_update_autofollow_diagnostic_attachment(
            lines,
            installed_version=installed_version,
        )

    def _post_update_dat_smoke_handoff_gate(self, state, rec, next_action, installed_version):
        smoke_state = self._read_post_update_dat_smoke_state()
        if not smoke_state:
            return None
        if not self._post_update_dat_smoke_target_matches(smoke_state, rec, post_update_state=state):
            return None
        status = str(smoke_state.get('last_status', '') or '').strip().lower()
        finished_at = str(smoke_state.get('last_finished_at_utc', '') or '').strip()
        report_path = str(smoke_state.get('last_report_path', '') or '').strip()
        if status not in ('started', 'running') or finished_at or report_path:
            return None

        started_epoch = _parse_iso_utc_to_epoch(smoke_state.get('last_started_at_utc'))
        if started_epoch is not None:
            age = int(time.time() - started_epoch)
            if age >= self._post_update_dat_smoke_handoff_timeout_sec():
                attachment = self._write_post_update_dat_smoke_timeout_attachment(
                    smoke_state,
                    installed_version,
                    next_action,
                )
                self._patch_post_update_autofollow_state({
                    'status': 'running_diagnostic_action',
                    'stage': 'phase_d_dat_smoke',
                    'diagnostic_action_id': 'phase_d_dat_smoke',
                    'recommendation_action_kind': next_action,
                    'last_reason': 'diagnostic_action_smoke_timeout_fail_closed',
                    'dat_smoke_diagnostics': self._post_update_dat_smoke_handoff_diagnostics(smoke_state),
                    'dat_smoke_timeout_attachment': attachment,
                })
                self._log_post_update_autofollow_event('diagnostic_handoff_smoke_timeout', {
                    'installed_version': installed_version,
                    'status': 'running_diagnostic_action',
                    'stage': 'phase_d_dat_smoke',
                    'diagnostic_action_id': 'phase_d_dat_smoke',
                    'recommendation_action_kind': next_action,
                    'reason': 'diagnostic_action_smoke_timeout_fail_closed',
                })
                return None

        if str(state.get('last_reason', '') or '') == 'diagnostic_action_waiting_for_dat_smoke_completion':
            return state
        self._log_post_update_autofollow_event('diagnostic_handoff_waiting', {
            'installed_version': installed_version,
            'status': 'running_diagnostic_action',
            'stage': 'phase_d_dat_smoke',
            'diagnostic_action_id': 'phase_d_dat_smoke',
            'recommendation_action_kind': next_action,
            'reason': 'diagnostic_action_waiting_for_dat_smoke_completion',
        })
        return self._patch_post_update_autofollow_state({
            'status': 'running_diagnostic_action',
            'stage': 'phase_d_dat_smoke',
            'diagnostic_action_id': 'phase_d_dat_smoke',
            'recommendation_action_kind': next_action,
            'last_reason': 'diagnostic_action_waiting_for_dat_smoke_completion',
            'dat_smoke_diagnostics': self._post_update_dat_smoke_handoff_diagnostics(smoke_state),
        })

    def _log_post_update_autofollow_event(self, event_name, details=None):
        try:
            from MediCafe.MediLink_ConfigLoader import log as config_log
            payload = details if isinstance(details, dict) else {}
            parts = []
            for key in (
                    'installed_version',
                    'previous_installed_version',
                    'status',
                    'stage',
                    'reason',
                    'recommendation_action_kind',
                    'send_type',
                    'job_id',
                    'diagnostic_action_id',
                    'action'):
                if key in payload:
                    parts.append('{0}={1}'.format(key, payload.get(key)))
            for key in ('cancel_ok', 'cancel_policy_reason'):
                if key in payload:
                    parts.append('{0}={1}'.format(key, payload.get(key)))
            summary = (' ' + ' '.join(parts)) if parts else ''
            config_log(
                'PostUpdateCloudAutoFollow {0}{1}'.format(str(event_name or ''), summary),
                level='INFO',
                console_output=False,
            )
        except Exception:
            pass

    def _find_background_support_send_job(self, job_id):
        jid = str(job_id or '').strip()
        if not jid:
            return {}
        for row in self._background_support_send_jobs(limit=100):
            if not isinstance(row, dict):
                continue
            if str(row.get('job_id', '') or '').strip() == jid:
                return row
        return {}

    def _patch_post_update_send_job_result(
            self,
            result,
            installed_version,
            recommendation_action_kind,
            send_type,
            last_reason,
            default_stage='queued_send'):
        data = result if isinstance(result, dict) else {}
        job_id = str(data.get('job_id', '') or '').strip()
        job_status = str(data.get('status', '') or '').strip()
        next_status = 'running_send' if job_status == 'running' else 'queued_send'
        if str(data.get('policy_decision', '') or '') == 'deduplicated' and job_status == 'succeeded':
            next_status = 'succeeded'
        stage = str(data.get('policy_decision', '') or default_stage or 'queued_send')
        state = self._patch_post_update_autofollow_state({
            'status': next_status,
            'stage': stage,
            'job_id': job_id,
            'last_reason': str(last_reason or 'recommended_send_queued'),
            'finished_at_utc': _utc_now() if next_status == 'succeeded' else '',
        })
        self._log_post_update_autofollow_event('job_queued', {
            'installed_version': installed_version,
            'status': next_status,
            'stage': stage,
            'job_id': job_id,
            'recommendation_action_kind': recommendation_action_kind,
            'send_type': send_type,
            'reason': str(last_reason or 'recommended_send_queued'),
        })
        if job_id and next_status in ('queued_send', 'running_send'):
            self._start_post_update_autofollow_watchdog(str(installed_version or '').strip())
        return state

    def _queue_post_update_recommendation_evidence(
            self,
            recommendation,
            send_type,
            installed_version,
            recommendation_action_kind,
            last_reason):
        ok = bool(self._send_bundle_for_operator_type(
            send_type,
            recommendation=recommendation,
            operator_execution_mode='post_update_autofollow',
            source='post_update_cloud_autofollow',
            priority='high',
            pause_for_ack=False,
            installed_version=installed_version,
            recommendation_action_kind=recommendation_action_kind,
        ))
        if ok:
            result = getattr(self, '_last_support_send_enqueue_result', {})
            return self._patch_post_update_send_job_result(
                result,
                installed_version,
                recommendation_action_kind,
                send_type,
                last_reason,
                default_stage='queued_send',
            )
        self._log_post_update_autofollow_event('diagnostic_handoff_send_failed', {
            'installed_version': installed_version,
            'status': 'failed',
            'stage': recommendation_action_kind,
            'recommendation_action_kind': recommendation_action_kind,
            'send_type': send_type,
            'reason': last_reason,
        })
        return self._patch_post_update_autofollow_state({
            'status': 'failed',
            'stage': str(recommendation_action_kind or 'post_update_recommendation_send'),
            'finished_at_utc': _utc_now(),
            'last_reason': str(last_reason or 'recommended_send_failed'),
        })

    def _refresh_post_update_diagnostic_handoff(self, state):
        st = state if isinstance(state, dict) else {}
        if str(st.get('status', '') or '').strip() != 'running_diagnostic_action':
            return st
        diagnostic = str(st.get('diagnostic_action_id', '') or '').strip()
        if diagnostic not in _POST_UPDATE_DIAGNOSTIC_ACTIONS:
            return st
        rec = self._operator_support_send_rec()
        if not isinstance(rec, dict) or not rec:
            return st
        plan = self._recommendation_execution_plan(rec)
        next_action = str(plan.get('preferred_action', '') or '').strip() or 'send_bundle'
        installed_version = str(st.get('installed_version', '') or '').strip()
        if bool(plan.get('unstable')):
            if str(st.get('last_reason', '') or '') != 'diagnostic_action_waiting_for_pipeline_idle':
                self._log_post_update_autofollow_event('diagnostic_handoff_waiting', {
                    'installed_version': installed_version,
                    'status': 'running_diagnostic_action',
                    'stage': diagnostic,
                    'diagnostic_action_id': diagnostic,
                    'recommendation_action_kind': next_action,
                    'reason': 'pipeline_running_after_diagnostic_action',
                })
                return self._patch_post_update_autofollow_state({
                    'status': 'running_diagnostic_action',
                    'stage': diagnostic,
                    'diagnostic_action_id': diagnostic,
                    'recommendation_action_kind': next_action,
                    'last_reason': 'diagnostic_action_waiting_for_pipeline_idle',
                })
            return st
        if diagnostic == 'phase_d_dat_smoke':
            gate_state = self._post_update_dat_smoke_handoff_gate(st, rec, next_action, installed_version)
            if gate_state is not None:
                return gate_state
        if next_action == diagnostic:
            send_type = str(plan.get('best_now_send') or plan.get('preferred_send') or 'system_health').strip()
            if send_type not in ('run_evidence', 'system_health'):
                send_type = 'system_health'
            self._log_post_update_autofollow_event('diagnostic_handoff_unresolved', {
                'installed_version': installed_version,
                'status': 'running_diagnostic_action',
                'stage': diagnostic,
                'diagnostic_action_id': diagnostic,
                'recommendation_action_kind': next_action,
                'send_type': send_type,
                'reason': 'same_recommendation_after_diagnostic_action',
            })
            return self._queue_post_update_recommendation_evidence(
                rec,
                send_type,
                installed_version,
                next_action,
                'diagnostic_action_unresolved_send_queued',
            )
        count = 0
        try:
            count = int(st.get('diagnostic_handoff_count', 0) or 0)
        except Exception:
            count = 0
        count += 1
        if count > _POST_UPDATE_DIAGNOSTIC_HANDOFF_LIMIT:
            send_type = str(plan.get('best_now_send') or plan.get('preferred_send') or 'system_health').strip()
            if send_type not in ('run_evidence', 'system_health'):
                send_type = 'system_health'
            self._log_post_update_autofollow_event('diagnostic_handoff_loop_guard', {
                'installed_version': installed_version,
                'status': 'running_diagnostic_action',
                'stage': diagnostic,
                'diagnostic_action_id': diagnostic,
                'recommendation_action_kind': next_action,
                'send_type': send_type,
                'reason': 'diagnostic_handoff_limit',
            })
            return self._queue_post_update_recommendation_evidence(
                rec,
                send_type,
                installed_version,
                next_action,
                'diagnostic_handoff_limit_send_queued',
            )
        self._patch_post_update_autofollow_state({
            'status': 'evaluating_recommendation',
            'stage': 'diagnostic_handoff_recompute',
            'previous_diagnostic_action_id': diagnostic,
            'diagnostic_action_id': '',
            'diagnostic_handoff_count': count,
            'recommendation_action_kind': next_action,
            'last_reason': 'diagnostic_action_completed_recomputing',
        })
        self._log_post_update_autofollow_event('diagnostic_handoff_following', {
            'installed_version': installed_version,
            'status': 'evaluating_recommendation',
            'stage': 'diagnostic_handoff_recompute',
            'diagnostic_action_id': diagnostic,
            'recommendation_action_kind': next_action,
            'reason': 'diagnostic_action_completed_recomputing',
        })
        started = bool(self._start_cloud_recommendation_followthrough(
            recommendation=rec,
            trigger='post_update_diagnostic_handoff:{0}'.format(diagnostic),
            source='post_update_cloud_autofollow',
            operator_execution_mode='post_update_autofollow',
            installed_version=installed_version,
            post_update=True,
        ))
        if not started:
            return self._patch_post_update_autofollow_state({
                'status': 'failed',
                'stage': next_action,
                'finished_at_utc': _utc_now(),
                'last_reason': 'diagnostic_handoff_followup_not_started',
            })
        return self._read_post_update_autofollow_state()

    def _refresh_post_update_fresh_pipeline_wait(self, state):
        st = state if isinstance(state, dict) else {}
        if str(st.get('status', '') or '').strip() != 'waiting_for_fresh_pipeline':
            return st
        version = str(st.get('installed_version', '') or '').strip()
        assessment = self._assess_post_update_evidence_freshness(version)
        self._patch_post_update_freshness_fields(assessment)
        status = str(assessment.get('post_update_evidence_freshness_status', '') or '').strip()
        if status == 'fresh':
            self._patch_post_update_autofollow_state({
                'status': 'evaluating_recommendation',
                'stage': 'fresh_pipeline_completed_recomputing',
                'last_reason': 'fresh_pipeline_completed_recomputing',
                'post_update_fresh_pipeline_finished_at_utc': _utc_now(),
            })
            self._log_post_update_autofollow_event('fresh_pipeline_completed', {
                'installed_version': version,
                'status': 'evaluating_recommendation',
                'stage': 'fresh_pipeline_completed_recomputing',
                'reason': 'fresh_pipeline_completed_recomputing',
                'run_id': str(assessment.get('post_update_fresh_shadow_run_id', '') or ''),
            })
            self._run_post_update_cloud_autofollow(
                version,
                str(st.get('previous_installed_version', '') or ''),
            )
            return self._read_post_update_autofollow_state()

        started_epoch = _parse_iso_utc_to_epoch(st.get('started_at_utc') or st.get('updated_at_utc'))
        if started_epoch is not None:
            age = int(time.time() - started_epoch)
            if age >= self._post_update_autofollow_stale_sec():
                self._log_post_update_autofollow_event('fresh_pipeline_timeout', {
                    'installed_version': version,
                    'status': 'waiting_for_fresh_pipeline',
                    'stage': str(st.get('stage', '') or ''),
                    'reason': 'fresh_pipeline_timeout',
                })
                return self._queue_post_update_fresh_pipeline_unavailable(
                    version,
                    assessment,
                    'fresh_pipeline_timeout',
                )
        return self._patch_post_update_autofollow_state({
            'status': 'waiting_for_fresh_pipeline',
            'stage': 'waiting_for_fresh_pipeline',
            'last_reason': str(assessment.get('post_update_freshness_blocking_reason') or 'fresh_pipeline_running'),
        })

    def _refresh_post_update_autofollow_state(self):
        state = self._read_post_update_autofollow_state()
        if not state:
            return {}
        status = str(state.get('status', '') or '').strip()
        if status not in _POST_UPDATE_ACTIVE_STATUSES:
            return state

        diagnostic_state = self._refresh_post_update_diagnostic_handoff(state)
        if diagnostic_state is not state:
            return diagnostic_state

        fresh_wait_state = self._refresh_post_update_fresh_pipeline_wait(state)
        if fresh_wait_state is not state:
            return fresh_wait_state

        job_id = str(state.get('job_id', '') or '').strip()
        # State patches merge into the JSON file; a prior queued send can leave job_id set.
        # While a diagnostic action is active, that id is not the in-flight diagnostic work;
        # polling it here can overwrite running_diagnostic_action with stale send progress.
        if job_id and status != 'running_diagnostic_action':
            manager = self._support_send_job_manager()
            if manager is not None and hasattr(manager, 'ensure_pending_worker_liveness'):
                try:
                    manager.ensure_pending_worker_liveness(reason='post_update_autofollow_poll')
                except Exception:
                    pass
            job = self._find_background_support_send_job(job_id)
            job_status = str(job.get('status', '') or '').strip() if isinstance(job, dict) else ''
            if job_status in ('queued', 'running'):
                return self._patch_post_update_autofollow_state({
                    'status': 'queued_send' if job_status == 'queued' else 'running_send',
                    'stage': str(job.get('progress_stage', '') or job_status),
                    'job_id': job_id,
                    'last_reason': 'support_send_{0}'.format(job_status),
                })
            if job_status in ('succeeded', 'failed', 'canceled', 'blocked'):
                next_status = 'succeeded' if job_status == 'succeeded' else 'failed'
                self._log_post_update_autofollow_event('completion', {
                    'installed_version': state.get('installed_version'),
                    'status': next_status,
                    'stage': str(job.get('progress_stage', '') or job_status),
                    'job_id': job_id,
                    'reason': job_status,
                })
                return self._patch_post_update_autofollow_state({
                    'status': next_status,
                    'stage': str(job.get('progress_stage', '') or job_status),
                    'finished_at_utc': str(job.get('finished_at_utc', '') or _utc_now()),
                    'last_reason': job_status,
                })
            if not job:
                missing_anchor = _parse_iso_utc_to_epoch(
                    state.get('updated_at_utc') or state.get('started_at_utc')
                )
                missing_age = None
                if missing_anchor is not None:
                    missing_age = int(time.time() - missing_anchor)
                if missing_anchor is None or missing_age >= self._post_update_autofollow_missing_job_stale_sec():
                    self._log_post_update_autofollow_event('stale', {
                        'installed_version': state.get('installed_version'),
                        'status': 'stale',
                        'stage': state.get('stage'),
                        'job_id': state.get('job_id'),
                        'diagnostic_action_id': state.get('diagnostic_action_id'),
                        'reason': 'missing_job_stale',
                    })
                    return self._patch_post_update_autofollow_state({
                        'status': 'stale',
                        'stage': str(state.get('stage', '') or status),
                        'finished_at_utc': _utc_now(),
                        'last_reason': 'missing_job_stale',
                    })
            else:
                # Job row exists but status is empty or unknown; do not hold the guard forever.
                # Treat this as operator attention needed so routing can proceed explicitly.
                raw_status = str(job.get('status', '') or '').strip()
                self._log_post_update_autofollow_event('unknown_job_status', {
                    'installed_version': state.get('installed_version'),
                    'status': state.get('status'),
                    'stage': state.get('stage'),
                    'job_id': job_id,
                    'reason': 'unknown_job_status:{0}'.format(raw_status or 'empty'),
                })
                stage = str(job.get('progress_stage', '') or '').strip() or (raw_status or 'unknown')
                return self._patch_post_update_autofollow_state({
                    'status': 'failed',
                    'stage': stage,
                    'job_id': job_id,
                    'finished_at_utc': _utc_now(),
                    'last_reason': 'needs_operator_attention_unknown_job_status',
                })

        started_epoch = _parse_iso_utc_to_epoch(state.get('started_at_utc') or state.get('updated_at_utc'))
        if started_epoch is not None:
            age = int(time.time() - started_epoch)
            if age >= self._post_update_autofollow_stale_sec():
                self._log_post_update_autofollow_event('stale', {
                    'installed_version': state.get('installed_version'),
                    'status': 'stale',
                    'stage': state.get('stage'),
                    'job_id': state.get('job_id'),
                    'diagnostic_action_id': state.get('diagnostic_action_id'),
                    'reason': 'stale_timeout',
                })
                return self._patch_post_update_autofollow_state({
                    'status': 'stale',
                    'stage': str(state.get('stage', '') or status),
                    'finished_at_utc': _utc_now(),
                    'last_reason': 'stale_timeout',
                })
        return state

    def _post_update_autofollow_watchdog_max_sec(self):
        raw = str(os.environ.get('MEDICAFE_POST_UPDATE_AUTOFOLLOW_WATCHDOG_SEC', '') or '').strip()
        if not raw:
            return _POST_UPDATE_WATCHDOG_DEFAULT_SEC
        try:
            value = int(raw)
        except Exception:
            return _POST_UPDATE_WATCHDOG_DEFAULT_SEC
        return max(60, value)

    def _post_update_autofollow_watchdog_poll_sec(self):
        raw = str(os.environ.get('MEDICAFE_POST_UPDATE_AUTOFOLLOW_WATCHDOG_POLL_SEC', '') or '').strip()
        if not raw:
            return _POST_UPDATE_WATCHDOG_POLL_DEFAULT_SEC
        try:
            value = int(raw)
        except Exception:
            return _POST_UPDATE_WATCHDOG_POLL_DEFAULT_SEC
        return max(5, value)

    def _start_post_update_autofollow_watchdog(self, installed_version):
        version = str(installed_version or '').strip()
        existing = getattr(self, '_post_update_autofollow_watchdog_thread', None)
        existing_version = str(getattr(self, '_post_update_autofollow_watchdog_version', '') or '').strip()
        try:
            if existing is not None and existing.is_alive() and existing_version == version:
                return False
        except Exception:
            pass
        max_sec = self._post_update_autofollow_watchdog_max_sec()
        poll_sec = self._post_update_autofollow_watchdog_poll_sec()

        def _watchdog():
            started = time.time()
            while True:
                job_id = ''
                status = ''
                try:
                    state = self._refresh_post_update_autofollow_state()
                    if not isinstance(state, dict) or not state:
                        return
                    if version and str(state.get('installed_version', '') or '').strip() != version:
                        return
                    status = str(state.get('status', '') or '').strip()
                    if status not in _POST_UPDATE_ACTIVE_STATUSES:
                        return
                    job_id = str(state.get('job_id', '') or '').strip()
                    manager = self._support_send_job_manager()
                    if manager is not None and hasattr(manager, 'ensure_pending_worker_liveness'):
                        try:
                            manager.ensure_pending_worker_liveness(
                                reason='post_update_autofollow_watchdog')
                        except Exception:
                            pass
                    try:
                        if time.time() - float(started) >= float(max_sec):
                            diag = {
                                'event': 'watchdog_timeout',
                                'at_utc': _utc_now(),
                                'watchdog_max_sec': int(max_sec),
                                'watchdog_poll_sec': int(poll_sec),
                                'installed_version': version,
                                'status_at_timeout': status,
                                'stage_at_timeout': str(state.get('stage', '') or ''),
                                'job_id': job_id,
                                'reason': 'watchdog_timeout',
                            }
                            try:
                                self._patch_post_update_autofollow_state({
                                    'watchdog_diagnostics': diag,
                                    'last_reason': 'watchdog_timeout',
                                })
                            except Exception:
                                pass
                            self._log_post_update_autofollow_event('watchdog_timeout', {
                                'installed_version': version,
                                'status': status,
                                'stage': str(state.get('stage', '') or ''),
                                'job_id': job_id,
                                'reason': 'watchdog_timeout',
                            })
                            return
                    except Exception:
                        return
                except Exception:
                    return
                try:
                    time.sleep(float(poll_sec))
                except Exception:
                    return

        thread = threading.Thread(target=_watchdog)
        thread.daemon = True
        thread.start()
        self._post_update_autofollow_watchdog_thread = thread
        self._post_update_autofollow_watchdog_version = version
        return True

    def _is_post_update_autofollow_active(self, state=None):
        current = state if isinstance(state, dict) else self._refresh_post_update_autofollow_state()
        status = str(current.get('status', '') or '').strip()
        return status in _POST_UPDATE_ACTIVE_STATUSES

    def _print_post_update_autofollow_status_banner(self, passive=False):
        if passive:
            state = self._read_post_update_autofollow_state()
        else:
            state = self._refresh_post_update_autofollow_state()
        if not isinstance(state, dict) or not state:
            return False
        status = str(state.get('status', '') or '').strip()
        if status not in _POST_UPDATE_ACTIVE_STATUSES and status != 'stale':
            return False
        print('')
        if status == 'stale':
            print('[POST-UPDATE CLOUD EVIDENCE STALE]')
        else:
            print('[POST-UPDATE CLOUD EVIDENCE ACTIVE]')
        print('  MediCafe version: {0}'.format(str(state.get('installed_version', '') or '-')))
        print('  Status: {0} stage={1}'.format(status or '-', str(state.get('stage', '') or '-')))
        job_id = str(state.get('job_id', '') or '').strip()
        diagnostic = str(state.get('diagnostic_action_id', '') or '').strip()
        if job_id:
            print('  Job: {0}'.format(job_id))
        if diagnostic:
            print('  Diagnostic action: {0}'.format(diagnostic))
        print('  Monitor: Troubleshooting -> Cloud Readiness -> Background cloud jobs')
        print('')
        return True

    def _post_update_guard_choice(self, action_name, state):
        action = str(action_name or 'this action').strip() or 'this action'
        print('Choose how to proceed:')
        print(' 1) Wait and keep MediCafe open')
        print(' 2) Safely cancel background cloud jobs and continue')
        print(' 3) Force override and continue')
        print(' 0) Back to menu')
        print('')
        try:
            choice = (self._prompt('Selection: ') or '').strip()
        except Exception:
            choice = ''
        lowered = choice.lower()
        if lowered in ('2', 'c', 'cancel', 'safe', 'safe cancel'):
            return 'safe_cancel'
        if lowered in ('3', 'f', 'force', 'override'):
            return 'force'
        if lowered in ('1', 'w', 'wait'):
            return 'wait'
        self._log_post_update_autofollow_event('blocked_action_choice', {
            'installed_version': (state or {}).get('installed_version') if isinstance(state, dict) else '',
            'status': (state or {}).get('status') if isinstance(state, dict) else '',
            'stage': (state or {}).get('stage') if isinstance(state, dict) else '',
            'job_id': (state or {}).get('job_id') if isinstance(state, dict) else '',
            'action': action,
            'reason': 'operator_wait_or_back',
        })
        return 'wait'

    def _cloud_shutdown_request_terminal(self, request):
        if cloud_work_shutdown is not None:
            return cloud_work_shutdown.request_is_terminal(request)
        status = str((request if isinstance(request, dict) else {}).get('status', '') or '').strip()
        return status in ('canceled', 'stopped', 'completed', 'terminal')

    def _mark_post_update_safe_cancel_terminal(self, action_name, request_id, reason):
        return self._patch_post_update_autofollow_state({
            'status': 'failed',
            'stage': 'safe_cancel',
            'finished_at_utc': _utc_now(),
            'last_reason': str(reason or 'safe_cancel_completed'),
            'safe_cancel_at_utc': _utc_now(),
            'safe_cancel_action': str(action_name or ''),
            'shutdown_request_id': str(request_id or ''),
            'shutdown_status': 'terminal',
        })

    def _request_post_update_safe_cancel(self, action_name, state):
        st = state if isinstance(state, dict) else {}
        request_id = self._post_update_shutdown_request_id()
        requested_at = _utc_now()
        request = {
            'schema_version': 1,
            'request_id': request_id,
            'requested_at_utc': requested_at,
            'source': 'launcher_post_update_guard',
            'action_name': str(action_name or ''),
            'reason': 'operator_safe_cancel',
            'status': 'requested',
        }
        request_path = self._write_cloud_work_shutdown_request(request)
        job_id = str(st.get('job_id', '') or '').strip()
        cancel_summary = {}
        manager = self._support_send_job_manager()
        if manager is not None and job_id and hasattr(manager, 'request_job_shutdown_if_possible'):
            try:
                cancel_summary = manager.request_job_shutdown_if_possible(
                    job_id,
                    reason='post_update_safe_cancel',
                    request_id=request_id,
                )
            except Exception as exc:
                cancel_summary = {
                    'ok': False,
                    'policy_reason': 'safe_cancel_error',
                    'message': str(exc),
                }
        elif manager is not None and job_id and hasattr(manager, 'cancel_job_if_possible'):
            try:
                cancel_summary = manager.cancel_job_if_possible(
                    job_id,
                    reason='post_update_safe_cancel',
                )
            except Exception as exc:
                cancel_summary = {
                    'ok': False,
                    'policy_reason': 'safe_cancel_error',
                    'message': str(exc),
                }
        elif not job_id:
            cancel_summary = {
                'ok': True,
                'policy_reason': 'no_job_id',
                'message': 'No background job id recorded.',
            }
        else:
            cancel_summary = {
                'ok': False,
                'policy_reason': 'no_manager',
                'message': 'Support send queue unavailable.',
            }
        policy_reason = str(cancel_summary.get('policy_reason', '') or '') if isinstance(cancel_summary, dict) else ''
        self._patch_post_update_autofollow_state({
            'status': 'shutdown_requested',
            'stage': 'safe_cancel_requested',
            'last_reason': policy_reason or 'operator_safe_cancel_requested',
            'shutdown_requested': True,
            'shutdown_requested_at_utc': requested_at,
            'shutdown_request_id': request_id,
            'shutdown_request_path': request_path,
            'shutdown_status': 'requested',
            'safe_cancel_action': str(action_name or ''),
            'safe_cancel_summary': cancel_summary if isinstance(cancel_summary, dict) else {},
        })
        self._log_post_update_autofollow_event('safe_cancel_requested', {
            'installed_version': st.get('installed_version'),
            'status': st.get('status'),
            'stage': st.get('stage'),
            'job_id': job_id,
            'diagnostic_action_id': st.get('diagnostic_action_id'),
            'action': str(action_name or ''),
            'reason': policy_reason or 'operator_safe_cancel_requested',
        })
        return request_id, request_path, cancel_summary

    def _wait_for_post_update_safe_cancel(self, action_name, request_id, cancel_summary):
        reason = str((cancel_summary if isinstance(cancel_summary, dict) else {}).get('policy_reason', '') or '')
        if reason in ('canceled_queued', 'already_terminal'):
            self._mark_post_update_safe_cancel_terminal(action_name, request_id, reason or 'safe_cancel_completed')
            return True
        if reason == 'no_job_id':
            state_now = self._read_post_update_autofollow_state()
            diagnostic = str((state_now if isinstance(state_now, dict) else {}).get('diagnostic_action_id', '') or '').strip()
            status_now = str((state_now if isinstance(state_now, dict) else {}).get('status', '') or '').strip()
            if not diagnostic and status_now != 'running_diagnostic_action':
                self._mark_post_update_safe_cancel_terminal(action_name, request_id, reason)
                return True
        deadline = time.time() + float(self._post_update_safe_cancel_grace_sec())
        poll_sec = self._post_update_safe_cancel_poll_sec()
        while True:
            state = self._refresh_post_update_autofollow_state()
            if not self._is_post_update_autofollow_active(state):
                return True
            request = self._read_cloud_work_shutdown_request()
            if self._cloud_shutdown_request_terminal(request):
                self._mark_post_update_safe_cancel_terminal(action_name, request_id, 'cloud_work_shutdown_terminal')
                return True
            if time.time() >= deadline:
                return False
            try:
                time.sleep(poll_sec)
            except Exception:
                return False

    def _try_post_update_safe_cancel_and_continue(self, action_name, state):
        print('[SAFE CANCEL] Requesting background cloud jobs to stop at safe checkpoints...')
        request_id, _request_path, cancel_summary = self._request_post_update_safe_cancel(action_name, state)
        reason = str(cancel_summary.get('policy_reason', '') or '') if isinstance(cancel_summary, dict) else ''
        if reason == 'canceled_queued':
            print('  Queued background job was canceled.')
        elif reason == 'cancel_requested_running':
            print('  Cancel requested; waiting for the running job to reach a safe checkpoint.')
        elif reason == 'no_job_id':
            print('  No background job id was recorded; cancel marker written for pipeline/diagnostic work.')
        elif reason:
            print('  Cancel result: {0}'.format(reason))
        if self._wait_for_post_update_safe_cancel(action_name, request_id, cancel_summary):
            print('  Safe cancel completed. Continuing with {0}.'.format(str(action_name or 'requested action')))
            return True
        print('  Safe cancel is still waiting on running Cloud work.')
        print('  No running process was killed.')
        try:
            choice = (self._prompt('Type FORCE to force override, WAIT to keep waiting, or press Enter for menu: ') or '').strip()
        except Exception:
            choice = ''
        if choice.upper() == 'FORCE':
            return self._apply_post_update_forced_override(action_name, state, cancel_first=False)
        if choice.upper() == 'WAIT':
            return False
        return False

    def _apply_post_update_forced_override(self, action_name, state, cancel_first=True):
        action = str(action_name or 'this action').strip() or 'this action'
        st = state if isinstance(state, dict) else {}
        cancel_summary = {}
        job_id = str(st.get('job_id', '') or '').strip()
        manager = self._support_send_job_manager()
        if cancel_first and manager is not None and job_id and hasattr(manager, 'cancel_job_if_possible'):
            try:
                cancel_summary = manager.cancel_job_if_possible(
                    job_id,
                    reason='post_update_manual_override',
                )
            except Exception as exc:
                cancel_summary = {
                    'ok': False,
                    'policy_reason': 'cancel_error',
                    'message': str(exc),
                }
        elif not job_id:
            cancel_summary = {
                'ok': True,
                'policy_reason': 'no_job_id',
                'message': 'No background job id recorded.',
            }
        elif cancel_first:
            cancel_summary = {
                'ok': False,
                'policy_reason': 'no_manager',
                'message': 'Support send queue unavailable.',
            }
        else:
            cancel_summary = {
                'ok': False,
                'policy_reason': 'forced_without_cancel',
                'message': 'Forced override did not wait for cancel.',
            }

        cancel_ok = bool(cancel_summary.get('ok')) if isinstance(cancel_summary, dict) else False
        cancel_reason = str(cancel_summary.get('policy_reason', '') or '') if isinstance(cancel_summary, dict) else ''
        finished_reason = 'manual_override_forced'
        if cancel_reason == 'running_not_cancelable':
            finished_reason = 'manual_override_running_job_continues'

        self._patch_post_update_autofollow_state({
            'status': 'failed',
            'stage': 'manual_override',
            'finished_at_utc': _utc_now(),
            'last_reason': finished_reason,
            'manual_override_at_utc': _utc_now(),
            'manual_override_action': action,
            'manual_override_mode': 'forced',
        })
        self._log_post_update_autofollow_event('manual_override_applied', {
            'installed_version': st.get('installed_version'),
            'status': 'failed',
            'stage': 'manual_override',
            'job_id': st.get('job_id'),
            'diagnostic_action_id': st.get('diagnostic_action_id'),
            'action': action,
            'reason': finished_reason,
            'cancel_ok': cancel_ok,
            'cancel_policy_reason': cancel_reason,
        })
        print('')
        print('[FORCE OVERRIDE] Post-update cloud evidence guard cleared for: {0}'.format(action))
        if isinstance(cancel_summary, dict):
            if cancel_reason == 'running_not_cancelable':
                print('  Warning: A background send may still be running; evidence may be incomplete.')
            elif cancel_ok and cancel_reason == 'canceled_queued':
                print('  Queued background job was canceled.')
            elif cancel_ok and cancel_reason in ('already_terminal', 'no_job_id'):
                pass
            elif not cancel_ok:
                msg = str(cancel_summary.get('message', '') or '').strip()
                if msg:
                    print('  Note: {0}'.format(msg))
        print('')
        return True

    def _try_post_update_manual_override(self, action_name, state):
        """Prompt for OVERRIDE, cancel queued job if possible, clear post-update guard. Returns True if override applied."""
        action = str(action_name or 'this action').strip() or 'this action'
        st = state if isinstance(state, dict) else {}
        self._log_post_update_autofollow_event('manual_override_requested', {
            'installed_version': st.get('installed_version'),
            'status': st.get('status'),
            'stage': st.get('stage'),
            'job_id': st.get('job_id'),
            'diagnostic_action_id': st.get('diagnostic_action_id'),
            'action': action,
            'reason': 'manual_override_requested',
        })
        print('  You may type OVERRIDE to abandon post-update cloud evidence and proceed.')
        print('  This cancels a queued background send job when possible; a running send is not killed.')
        print('  Proceeding may invalidate or omit developer evidence for this update.')
        print('')
        try:
            choice = (self._prompt(
                '  Type OVERRIDE to proceed, or press Enter to stay blocked: '
            ) or '').strip()
        except Exception:
            choice = ''
        if choice != 'OVERRIDE':
            self._log_post_update_autofollow_event('manual_override_declined', {
                'installed_version': st.get('installed_version'),
                'status': st.get('status'),
                'stage': st.get('stage'),
                'job_id': st.get('job_id'),
                'diagnostic_action_id': st.get('diagnostic_action_id'),
                'action': action,
                'reason': 'manual_override_declined',
            })
            return False
        return self._apply_post_update_forced_override(action_name, state, cancel_first=True)

    def _post_update_autofollow_still_blocks_action(self, action_name):
        """Return True if post-update autofollow is active and the action stays blocked (override declined)."""
        state = self._refresh_post_update_autofollow_state()
        if not self._is_post_update_autofollow_active(state):
            return False
        action = str(action_name or 'this action').strip() or 'this action'
        self._log_post_update_autofollow_event('blocked_action', {
            'installed_version': state.get('installed_version'),
            'status': state.get('status'),
            'stage': state.get('stage'),
            'job_id': state.get('job_id'),
            'diagnostic_action_id': state.get('diagnostic_action_id'),
            'action': action,
            'reason': 'post_update_autofollow_active',
        })
        print('')
        print('[BLOCKED] Post-update developer evidence is still being generated for MediCafe {0}.'.format(
            str(state.get('installed_version', '') or '-')))
        print('  {0} now can interrupt or invalidate the bundle.'.format(action.capitalize()))
        print('  Status: {0} stage={1}'.format(str(state.get('status', '') or '-'), str(state.get('stage', '') or '-')))
        job_id = str(state.get('job_id', '') or '').strip()
        diagnostic = str(state.get('diagnostic_action_id', '') or '').strip()
        if job_id:
            print('  Job: {0}'.format(job_id))
        if diagnostic:
            print('  Diagnostic action: {0}'.format(diagnostic))
        print('  Monitor: Troubleshooting -> Cloud Readiness -> Background cloud jobs')
        print('')
        choice = self._post_update_guard_choice(action, state)
        if choice == 'safe_cancel' and self._try_post_update_safe_cancel_and_continue(action_name, state):
            return False
        if choice == 'force' and self._try_post_update_manual_override(action_name, state):
            return False
        try:
            self._prompt('Press Enter to return to menu...')
        except Exception:
            pass
        return True

    def _post_update_queued_bundle_candidates(self, installed_version, limit=5):
        version = str(installed_version or '').strip()
        if not version:
            return []
        queue_dirs = []
        try:
            storage = str(self.environment.get('local_storage_path', '') or '').strip()
        except Exception:
            storage = ''
        if storage:
            queue_dirs.append(os.path.join(storage, 'reports_queue'))
        try:
            queue_dirs.append(os.path.join(self.repo_root, 'reports_queue'))
        except Exception:
            pass
        seen_dirs = set()
        candidates = []
        for queue_dir in queue_dirs:
            if not queue_dir or queue_dir in seen_dirs:
                continue
            seen_dirs.add(queue_dir)
            try:
                names = os.listdir(queue_dir)
            except Exception:
                continue
            for name in names:
                if not name.lower().endswith('.zip'):
                    continue
                path = os.path.join(queue_dir, name)
                try:
                    if not os.path.isfile(path):
                        continue
                except Exception:
                    continue
                meta = {}
                try:
                    with zipfile.ZipFile(path, 'r') as zf:
                        if 'meta.json' not in zf.namelist():
                            continue
                        raw = zf.read('meta.json').decode('utf-8', 'ignore')
                        parsed = json.loads(raw)
                        if isinstance(parsed, dict):
                            meta = parsed
                except Exception:
                    continue
                extra = meta.get('extra_context', {}) if isinstance(meta.get('extra_context', {}), dict) else {}
                job_context = extra.get('support_send_job_context', {}) if isinstance(extra.get('support_send_job_context', {}), dict) else {}
                meta_version = str(job_context.get('installed_version', '') or meta.get('app_version', '') or '').strip()
                source = str(job_context.get('source', '') or extra.get('send_source', '') or '').strip()
                if meta_version != version:
                    continue
                if source and source != 'post_update_cloud_autofollow':
                    continue
                if not source and str(extra.get('operator_execution_mode', '') or '') != 'post_update_autofollow':
                    continue
                try:
                    mtime = os.path.getmtime(path)
                except Exception:
                    mtime = 0.0
                candidates.append({
                    'path': path,
                    'name': name,
                    'mtime': mtime,
                    'app_version': meta.get('app_version', ''),
                    'source': source,
                    'bundle_kind': meta.get('bundle_kind', ''),
                })
        candidates.sort(key=lambda row: float(row.get('mtime') or 0.0), reverse=True)
        return candidates[:max(1, int(limit or 1))]

    def _recover_post_update_autofollow_for_current_version(self, version, state):
        if not isinstance(state, dict):
            return ''
        current_version = str(state.get('installed_version', '') or '').strip()
        if current_version != str(version or '').strip():
            return ''
        status = str(state.get('status', '') or '').strip()
        job_id = str(state.get('job_id', '') or '').strip()
        job = self._find_background_support_send_job(job_id) if job_id else {}
        job_status = str(job.get('status', '') or '').strip() if isinstance(job, dict) else ''
        if job_status == 'succeeded':
            self._patch_post_update_autofollow_state({
                'status': 'succeeded',
                'stage': str(job.get('progress_stage', '') or 'succeeded'),
                'finished_at_utc': str(job.get('finished_at_utc', '') or _utc_now()),
                'last_reason': 'support_send_succeeded_after_restart',
            })
            self._log_post_update_autofollow_event('recovered_success', {
                'installed_version': version,
                'status': 'succeeded',
                'stage': str(job.get('progress_stage', '') or 'succeeded'),
                'job_id': job_id,
                'reason': 'support_send_succeeded_after_restart',
            })
            return 'handled'
        if job_status in ('queued', 'running', 'failed', 'blocked', 'canceled'):
            manager = self._support_send_job_manager()
            if manager is not None and hasattr(manager, 'recover_jobs_after_launcher_restart'):
                try:
                    recovery = manager.recover_jobs_after_launcher_restart(
                        source='post_update_cloud_autofollow',
                        installed_version=version,
                    )
                except Exception as exc:
                    recovery = {'error': str(exc)}
                recovered_ids = recovery.get('recovered_job_ids', []) if isinstance(recovery, dict) else []
                queued_ids = recovery.get('queued_job_ids', []) if isinstance(recovery, dict) else []
                if job_id in recovered_ids or job_id in queued_ids or job_status in ('queued', 'running'):
                    self._patch_post_update_autofollow_state({
                        'status': 'queued_send',
                        'stage': 'recovered_after_launcher_restart',
                        'job_id': job_id,
                        'last_reason': 'support_send_recovered_after_launcher_restart',
                    })
                    self._log_post_update_autofollow_event('recovered_job', {
                        'installed_version': version,
                        'status': 'queued_send',
                        'stage': 'recovered_after_launcher_restart',
                        'job_id': job_id,
                        'reason': 'support_send_recovered_after_launcher_restart',
                    })
                    self._start_post_update_autofollow_watchdog(version)
                    return 'active'
        queued_bundles = self._post_update_queued_bundle_candidates(version, limit=1)
        if queued_bundles and job_status != 'succeeded':
            first_bundle = queued_bundles[0]
            self._patch_post_update_autofollow_state({
                'recovery_bundle_path': str(first_bundle.get('path', '') or ''),
                'last_reason': 'queued_post_update_bundle_found_for_retry',
            })
            self._log_post_update_autofollow_event('retry_needed', {
                'installed_version': version,
                'status': status,
                'stage': str(state.get('stage', '') or ''),
                'job_id': job_id,
                'reason': 'queued_post_update_bundle_found_for_retry',
            })
            return 'rerun'
        if status in _POST_UPDATE_ACTIVE_STATUSES or status in ('failed', 'stale'):
            self._log_post_update_autofollow_event('retry_needed', {
                'installed_version': version,
                'status': status,
                'stage': str(state.get('stage', '') or ''),
                'job_id': job_id,
                'reason': 'same_version_incomplete_or_failed',
            })
            return 'rerun'
        return 'handled'

    def _start_post_update_cloud_autofollow_thread(self, installed_version):
        version = str(installed_version or '').strip()
        if not version or version == 'unknown':
            self._log_post_update_autofollow_event('skipped', {
                'installed_version': version or 'unknown',
                'reason': 'empty_installed_version',
            })
            return False
        state = self._refresh_post_update_autofollow_state()
        state_version = str(state.get('installed_version', '') or '').strip() if isinstance(state, dict) else ''
        recovery_action = ''
        if state_version == version:
            recovery_action = self._recover_post_update_autofollow_for_current_version(version, state)
            if recovery_action == 'active':
                return False
            if recovery_action == 'handled':
                self._log_post_update_autofollow_event('skipped', {
                    'installed_version': version,
                    'status': str(state.get('status', '') or ''),
                    'stage': str(state.get('stage', '') or ''),
                    'reason': 'no_installed_version_change',
                })
                return False
        state = self._refresh_post_update_autofollow_state()
        if self._is_post_update_autofollow_active(state) and recovery_action != 'rerun':
            self._log_post_update_autofollow_event('skipped', {
                'installed_version': version,
                'status': state.get('status'),
                'stage': state.get('stage'),
                'job_id': state.get('job_id'),
                'reason': 'already_active',
            })
            return False
        previous = str(state.get('installed_version', '') or '').strip() if isinstance(state, dict) else ''
        if not previous:
            self._patch_post_update_autofollow_state({
                'installed_version': version,
                'previous_installed_version': '',
                'status': 'idle',
                'stage': 'baseline_recorded',
                'started_at_utc': '',
                'finished_at_utc': '',
                'last_reason': 'baseline_version_recorded',
            })
            self._log_post_update_autofollow_event('skipped', {
                'installed_version': version,
                'status': 'idle',
                'stage': 'baseline_recorded',
                'reason': 'baseline_version_recorded',
            })
            return False
        force_retry = recovery_action == 'rerun'
        if previous == version and not force_retry:
            self._log_post_update_autofollow_event('skipped', {
                'installed_version': version,
                'status': str(state.get('status', '') or ''),
                'stage': str(state.get('stage', '') or ''),
                'reason': 'no_installed_version_change',
            })
            return False
        existing = getattr(self, '_post_update_autofollow_thread', None)
        try:
            if existing is not None and existing.is_alive():
                return False
        except Exception:
            pass
        now = _utc_now()
        reason = 'retry_incomplete_same_version' if force_retry else 'installed_version_changed'
        previous_for_state = str(state.get('previous_installed_version', '') or '').strip() if force_retry else previous
        if not previous_for_state:
            previous_for_state = previous
        self._write_post_update_autofollow_state({
            'installed_version': version,
            'previous_installed_version': previous_for_state,
            'status': 'evaluating_recommendation',
            'stage': 'starting',
            'recommendation_action_kind': '',
            'send_type': '',
            'anchor_run_id': '',
            'context_run_id': '',
            'job_id': '',
            'diagnostic_action_id': '',
            'started_at_utc': now,
            'updated_at_utc': now,
            'finished_at_utc': '',
            'last_reason': reason,
            'recovery_bundle_path': str(state.get('recovery_bundle_path', '') or '') if force_retry else '',
        })
        self._log_post_update_autofollow_event('started', {
            'installed_version': version,
            'previous_installed_version': previous_for_state,
            'status': 'evaluating_recommendation',
            'stage': 'starting',
            'reason': reason,
        })

        def _worker():
            try:
                self._run_post_update_cloud_autofollow(version, previous_for_state)
            except Exception as exc:
                self._patch_post_update_autofollow_state({
                    'status': 'failed',
                    'stage': 'exception',
                    'finished_at_utc': _utc_now(),
                    'last_reason': 'exception:{0}'.format(exc.__class__.__name__),
                })
                self._log_post_update_autofollow_event('failed', {
                    'installed_version': version,
                    'previous_installed_version': previous_for_state,
                    'status': 'failed',
                    'stage': 'exception',
                    'reason': exc.__class__.__name__,
                })

        thread = threading.Thread(target=_worker)
        thread.daemon = True
        thread.start()
        self._post_update_autofollow_thread = thread
        return True

    def _run_post_update_cloud_autofollow(self, installed_version, previous_version):
        version = str(installed_version or '').strip()
        previous = str(previous_version or '').strip()
        self._patch_post_update_autofollow_state({
            'status': 'evaluating_recommendation',
            'stage': 'computing_recommendation',
            'last_reason': 'computing_recommendation',
        })
        if not self._ensure_post_update_fresh_evidence(version):
            return True
        rec = self._operator_support_send_rec()
        if not isinstance(rec, dict) or not rec:
            self._patch_post_update_autofollow_state({
                'status': 'failed',
                'stage': 'recommendation_unavailable',
                'finished_at_utc': _utc_now(),
                'last_reason': 'recommendation_unavailable',
            })
            self._log_post_update_autofollow_event('failed', {
                'installed_version': version,
                'previous_installed_version': previous,
                'status': 'failed',
                'stage': 'recommendation_unavailable',
                'reason': 'recommendation_unavailable',
            })
            return False
        plan = self._recommendation_execution_plan(rec)
        anchor, context, _issue = self._send_job_anchor_context_issue(rec)
        self._patch_post_update_autofollow_state({
            'status': 'evaluating_recommendation',
            'stage': 'recommendation_selected',
            'recommendation_action_kind': plan.get('preferred_action') or '',
            'send_type': plan.get('best_now_send') if plan.get('unstable') else plan.get('preferred_send'),
            'anchor_run_id': anchor,
            'context_run_id': context,
            'last_reason': 'recommendation_selected',
        })
        self._log_post_update_autofollow_event('recommendation_selected', {
            'installed_version': version,
            'previous_installed_version': previous,
            'status': 'evaluating_recommendation',
            'stage': 'recommendation_selected',
            'recommendation_action_kind': plan.get('preferred_action'),
            'send_type': plan.get('best_now_send') if plan.get('unstable') else plan.get('preferred_send'),
        })
        started = self._start_cloud_recommendation_followthrough(
            recommendation=rec,
            trigger='post_update_installed:{0}'.format(version),
            source='post_update_cloud_autofollow',
            operator_execution_mode='post_update_autofollow',
            installed_version=version,
            post_update=True,
        )
        if not started:
            st = self._read_post_update_autofollow_state()
            lr = str(st.get('last_reason', '') or '').strip()
            if lr == 'diagnostic_action_not_started':
                self._log_post_update_autofollow_event('failed', {
                    'installed_version': version,
                    'previous_installed_version': previous,
                    'status': 'failed',
                    'stage': str(st.get('stage', '') or 'diagnostic_failed'),
                    'reason': 'diagnostic_action_not_started',
                    'historical_helper_stage': (
                        ((st.get('historical_helper_diagnostics') or {}) if isinstance(st.get('historical_helper_diagnostics'), dict) else {}).get(
                            'hist_helper_stage')),
                })
                return False
            self._patch_post_update_autofollow_state({
                'status': 'failed',
                'stage': 'not_started',
                'finished_at_utc': _utc_now(),
                'last_reason': 'followthrough_not_started',
            })
            self._log_post_update_autofollow_event('failed', {
                'installed_version': version,
                'previous_installed_version': previous,
                'status': 'failed',
                'stage': 'not_started',
                'reason': 'followthrough_not_started',
            })
            return False
        state = self._read_post_update_autofollow_state()
        if str(state.get('status', '') or '') == 'evaluating_recommendation':
            self._patch_post_update_autofollow_state({
                'status': 'succeeded',
                'stage': 'started_without_background_tracking',
                'finished_at_utc': _utc_now(),
                'last_reason': 'started_without_background_tracking',
            })
        self._start_post_update_autofollow_watchdog(version)
        return True
    def _cloud_readiness_service(self):
        resolver = getattr(self, '_cloud_readiness_resolver', None)
        if callable(resolver):
            try:
                return resolver()
            except Exception:
                return None
        return None

    def _env_flag_value(self, name, default=False):
        env_flag_fn = getattr(self, '_env_flag_fn', None)
        if callable(env_flag_fn):
            try:
                return env_flag_fn(name, default)
            except Exception:
                return default
        return default

    def _print_phase_f_status(self):
        """Print interpreted pipeline health snapshot before Cloud Readiness choices."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        lab_root = cr.resolve_lab_root(self.repo_root)
        for line in cr.get_health_lines(lab_root, self._env_flag_value):
            print(line)

    def _print_manual_pipeline_runbook(self, action_code):
        """Print what-to-expect runbook after manual pipeline trigger."""
        code = str(action_code or '').upper().strip()
        print('')
        print('Manual pipeline runbook:')
        print(' - heartbeat_timeout_sec=120')
        if code == 'A':
            print(' - expected_progression=B->C->D->E->F')
            print(' - expected_artifacts=artifact_discovery_summary_, ingest_write_summary_, qa_canonical_summary_, projection_parity_summary_, shadow_run_report_')
            print(' - if_no_new_artifacts_within_timeout=Open latest Artifact Triage Pack; if still stalled, retrigger A and inspect delivery diagnostics.')
        elif code == 'B':
            print(' - expected_artifact=artifact_discovery_summary_<run_id>.json/.txt')
            print(' - if_missing_after_timeout=Verify source folders, then retrigger B or run A for coherent pipeline execution.')
        elif code == 'C':
            print(' - expected_artifact=ingest_write_summary_<run_id>.json/.txt')
            print(' - if_missing_after_timeout=Confirm manifest exists; review ingest anomalies and rerun C or full A.')
        elif code == 'D':
            print(' - expected_artifact=qa_canonical_summary_<run_id>.json/.txt')
            print(' - if_missing_after_timeout=Check QA prerequisites and rerun D; inspect reject samples when produced.')
        elif code == 'E':
            print(' - expected_artifact=projection_parity_summary_<run_id>.json/.txt')
            print(' - if_missing_after_timeout=Validate parity inputs and rerun E; inspect deviation samples if coverage/parity issues appear.')
        print(' - verify_with=Cloud Phase Artifact Tools -> A/B')

    def _sanitize_json_health_ledgers_action(self):
        """
        Strip non-JSON / non-object lines from submission_index.jsonl and
        remittance_parsed.jsonl, then refresh the JSON health snapshot.
        """
        print('')
        print('This removes lines that are not valid JSON objects from:')
        print('  - submission_index.jsonl (local claims path)')
        print('  - remittance_parsed.jsonl (local storage path)')
        print('A timestamped .sanitized_bak.* file is created before each rewrite.')
        print('Row-level warnings (missing patient_id, placeholders, etc.) are unchanged.')
        print('')
        try:
            from MediCafe.MediLink_ConfigLoader import load_configuration
            from MediCafe import json_health
            config, _ = load_configuration()
        except Exception as exc:
            print('Configuration load failed: {0}'.format(exc))
            return
        with _console_activity_heartbeat('JSON ledger sanitize'):
            results = json_health.sanitize_jsonl_artifacts_for_config(config, backup=True)
        any_changed = False
        for row in results:
            ak = str(row.get('artifact_key', '') or '-')
            try:
                dropped = int(row.get('lines_dropped', 0) or 0)
            except Exception:
                dropped = 0
            changed = bool(row.get('changed'))
            err = str(row.get('error') or '')
            if changed:
                any_changed = True
            print('  {0}: invalid_removed={1} rewritten={2} detail={3}'.format(
                ak, dropped, changed, err or '-'))
        if any_changed:
            print('Refreshing JSON health snapshot...')
            with _console_activity_heartbeat('JSON health re-scan'):
                summary = json_health.run_json_health_scan(config=config, persist=True)
            print('JSON health status: {0}'.format(summary.get('status', '-')))
        else:
            print('No invalid JSON lines were removed.')

    def _run_system_health_triage(self):
        """Run migration audit + refresh unified system-health pack, then print quick hints."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        migration_stage = str(os.environ.get('MEDICAFE_MIGRATION_STAGE', 'xp_validation') or 'xp_validation').strip().lower()
        if migration_stage not in ('xp_validation', 'dual_run_pre_cutover', 'cutover'):
            migration_stage = 'xp_validation'
        cloud_required = str(os.environ.get('MEDICAFE_CLOUD_REQUIRED', '') or '').strip().lower() in (
            '1', 'true', 'yes', 'on',
        )
        with _console_activity_heartbeat('system health triage: audit + pack refresh'):
            ok, msg, data = cr.run_system_health_triage(
                self.repo_root,
                self.python_exe,
                self.environment,
                self._env_flag_value,
                scope='both',
                cloud_required=cloud_required,
                migration_stage=migration_stage,
            )
        if msg:
            print(msg)
        hints = []
        artifacts = []
        if isinstance(data, dict):
            hints = data.get('hints', []) if isinstance(data.get('hints', []), list) else []
            artifacts = data.get('artifacts', []) if isinstance(data.get('artifacts', []), list) else []
            runbook_lines = data.get('runbook_lines', []) if isinstance(data.get('runbook_lines', []), list) else []
        else:
            runbook_lines = []
        if hints:
            print('')
            print('Manual validation quick hints:')
            for line in hints:
                print(' - {0}'.format(line))
        if runbook_lines:
            print('')
            print('Decision runbook:')
            for line in runbook_lines:
                print(' - {0}'.format(line))
        if artifacts:
            print('')
            print('Generated artifacts:')
            for path in artifacts:
                print(' - {0}'.format(path))
        if not ok:
            print('Triage finished with issues. Review artifacts for details.')

    def _open_report_result(self, ok, msg, path, print_msg_always=False):
        """Shared open/print handler for report-style (ok, msg, path) calls."""
        if print_msg_always and msg:
            print(msg)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
            return True
        if (not print_msg_always) and msg:
            print(msg)
        return False

    def _open_latest_system_health_pack(self):
        """Open latest combined system-health pack snapshot."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        with _console_activity_heartbeat('building system health pack snapshot') as heartbeat:
            ok, msg, path = cr.open_latest_system_health_pack(
                self.repo_root,
                self._env_flag_value,
                progress_callback=heartbeat.update,
            )
        self._open_report_result(ok, msg, path)

    def _open_data_plane_audit_report(self, report_type='overview', limit=40):
        """Generate and open DB data audit report (counts + patient chain sample)."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        hb_label = 'DB data audit report ({0})'.format(report_type)
        with _console_activity_heartbeat(hb_label):
            ok, msg, path = cr.open_data_plane_audit_report(
                self.repo_root, report_type=report_type, limit=limit)
        self._open_report_result(ok, msg, path, print_msg_always=True)

    def _open_latest_data_plane_audit_report(self, report_type='overview'):
        """Open latest generated DB data audit report for report_type."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_latest_data_plane_audit_report(
            self.repo_root, report_type=report_type)
        self._open_report_result(ok, msg, path)

    def _open_patient_flow_runbook_by_reference(self):
        """Prompt for patient reference and open patient flow runbook."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        patient_ref = (self._prompt(
            'Enter patient reference (patient_id / external_patient_id / patient_key): ') or '').strip()
        if not patient_ref:
            print('Cancelled.')
            return
        with _console_activity_heartbeat('patient flow runbook: generating'):
            ok, msg, path = cr.open_patient_flow_runbook(self.repo_root, patient_ref)
        self._open_report_result(ok, msg, path, print_msg_always=True)

    def _cloud_db_inspection_menu(self):
        """DB content inspection tools for manual data-quality audits."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Cloud DB Inspection', width=40)
            self._print_troubleshooting_group('Inventory & Quality', [
                '1)  Generate DB overview report (counts + quality)',
                '2)  Open latest DB overview report',
                '3)  Generate recent patient sample report',
                '4)  Generate high-risk patient sample report',
            ])
            self._print_troubleshooting_group('Patient Drilldown', [
                '5)  Open patient flow runbook by patient reference',
                '6)  Open Patient Flow Runbook (auto-populated list)',
                '7)  Guided Patient Completeness Runbook',
            ])
            print('Navigation')
            print(' 0)  Back to Cloud Readiness menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                print('Generating DB overview report...')
                self._open_data_plane_audit_report(report_type='overview', limit=60)
            elif choice == '2':
                print('Opening latest DB overview report...')
                self._open_latest_data_plane_audit_report(report_type='overview')
            elif choice == '3':
                print('Generating recent patient sample report...')
                self._open_data_plane_audit_report(report_type='recent', limit=60)
            elif choice == '4':
                print('Generating high-risk patient sample report...')
                self._open_data_plane_audit_report(report_type='high_risk', limit=60)
            elif choice == '5':
                print('Opening patient flow runbook by manual reference...')
                self._open_patient_flow_runbook_by_reference()
            elif choice == '6':
                print('Opening patient flow runbook by auto-populated reference...')
                self._open_patient_flow_runbook_for_id()
            elif choice == '7':
                print('Starting guided patient completeness runbook...')
                self._guided_patient_completeness_runbook()
            else:
                print('Invalid choice.')
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _open_report_delivery_status(self):
        """Open compact report delivery/send diagnostics snapshot."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_report_delivery_status(self.repo_root)
        self._open_report_result(ok, msg, path)

    def _open_phase_f_shadow_report(self):
        """View latest Shadow Health report (Phase F) - txt or json."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_phase_f_shadow_report(self.repo_root)
        self._open_report_result(ok, msg, path)

    def _send_latest_system_health_pack(self, send_source='manual_system_health_pack', operator_execution_mode='explicit_send_menu', recommendation=None):
        """Send latest unified system-health pack with related artifacts. Returns True on send success."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return False
        op_id = self._new_support_send_operation_id('system_health')
        t0 = time.time()
        has_recommendation = bool(isinstance(recommendation, dict) and recommendation)
        self._log_support_send_event('support_send_start', {
            'operation_id': op_id,
            'send_type': 'system_health',
            'phase': 'start',
            'status': 'running',
            'send_source': str(send_source or 'manual_system_health_pack'),
            'operator_execution_mode': str(operator_execution_mode or 'explicit_send_menu'),
            'frozen_recommendation': has_recommendation,
        })
        with _console_activity_heartbeat('sending system health pack: bundle + delivery') as heartbeat:
            ok, msg, data = cr.send_latest_system_health_pack(
                self.repo_root,
                self._env_flag_value,
                progress_callback=heartbeat.update,
                recommendation=recommendation,
                send_source=send_source,
                operator_execution_mode=operator_execution_mode,
            )
        elapsed_ms = int(max(0.0, time.time() - t0) * 1000.0)
        self._log_support_send_event('support_send_finish', {
            'operation_id': op_id,
            'send_type': 'system_health',
            'phase': 'finish',
            'status': 'ok' if ok else 'failed',
            'duration_ms': elapsed_ms,
            'send_source': str(send_source or 'manual_system_health_pack'),
            'operator_execution_mode': str(operator_execution_mode or 'explicit_send_menu'),
            'frozen_recommendation': has_recommendation,
            'result_message': str(msg or ''),
        })
        if msg:
            print(msg)
        runbook_lines = data.get('pre_send_runbook_lines', []) if isinstance(data, dict) else []
        if runbook_lines:
            print('')
            print('Pre-send runbook:')
            for line in runbook_lines:
                print(' - {0}'.format(line))
        if not ok:
            print('')
            print('Opening report delivery diagnostics to help triage send failure...')
            self._open_report_delivery_status()
        return bool(ok)

    def _operator_support_send_rec(self):
        cr = self._cloud_readiness_service()
        if cr is None:
            return {}
        try:
            rec = cr.compute_operator_support_send_recommendation(
                self.repo_root, self._env_flag_value)
            return rec if isinstance(rec, dict) else {}
        except Exception:
            return {}

    def _print_operator_send_why(self):
        rec = self._operator_support_send_rec()
        if not rec:
            print('Recommendation unavailable.')
            return
        line = rec.get('summary_line', '')
        if line:
            print(line)
        for w in rec.get('why_lines', []) or []:
            w = str(w or '').strip()
            if w:
                print(' - {0}'.format(w))
        hist_skip = str(rec.get('historical_reprocess_not_triggered_reason', '') or '').strip()
        dat_skip = str(rec.get('dat_smoke_not_triggered_reason', '') or '').strip()
        qa_full_block_skip = str(rec.get('dat_qa_full_block_not_triggered_reason', '') or '').strip()
        if hist_skip and str(rec.get('recommended_action_kind', '') or '').strip() != 'historical_phase_d_reprocess':
            print(' - historical_reprocess_not_triggered_reason={0}'.format(hist_skip))
        if dat_skip and str(rec.get('recommended_action_kind', '') or '').strip() != 'phase_d_dat_smoke':
            print(' - dat_smoke_not_triggered_reason={0}'.format(dat_skip))
        if qa_full_block_skip and str(rec.get('recommended_action_kind', '') or '').strip() != 'review_dat_qa_full_block':
            print(' - dat_qa_full_block_not_triggered_reason={0}'.format(qa_full_block_skip))
        preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        if preview and str(rec.get('recommended_action_kind', '') or '') == 'historical_phase_d_reprocess':
            print(' - targeted_artifact_classes={0}'.format(','.join(self._recommended_artifact_classes(rec)) or '-'))
            print(' - qa_policy_version={0}'.format(str(preview.get('qa_policy_version', '') or '-')))
            print(' - latest_phase_c_inserted_count={0}'.format(int(preview.get('latest_phase_c_inserted_count', 0) or 0)))
            print(' - latest_phase_c_skipped_count={0}'.format(int(preview.get('latest_phase_c_skipped_count', 0) or 0)))
            print(' - latest_phase_d_rows_selected={0}'.format(int(preview.get('latest_phase_d_rows_selected', 0) or 0)))
        if preview and str(rec.get('recommended_action_kind', '') or '') == 'phase_d_dat_smoke':
            print(' - anchor_run_id={0}'.format(str(preview.get('anchor_run_id', '') or '-')))
            print(' - phase_d_context_run_id={0}'.format(str(preview.get('phase_d_context_run_id', '') or '-')))
            print(' - strict_milestone_verdict={0}'.format(str(preview.get('strict_milestone_verdict', '') or '-')))
            print(' - reference_phase_d_summary_path={0}'.format(str(preview.get('reference_phase_d_summary_path', '') or '-')))
        if preview and str(rec.get('recommended_action_kind', '') or '') == 'phase_d_dat_verification_rerun':
            print(' - anchor_run_id={0}'.format(str(preview.get('anchor_run_id', '') or '-')))
            print(' - phase_d_context_run_id={0}'.format(str(preview.get('phase_d_context_run_id', '') or '-')))
            print(' - dat_payer_resolution_evidence_status={0}'.format(str(preview.get('dat_payer_resolution_evidence_status', '') or '-')))
            print(' - dat_selected_count={0}'.format(int(preview.get('dat_selected_count', 0) or 0)))
            print(' - dat_qa_pass_count={0}'.format(int(preview.get('dat_qa_pass_count', 0) or 0)))
            print(' - dat_qa_reject_count={0}'.format(int(preview.get('dat_qa_reject_count', 0) or 0)))
            print(' - phase_d_summary_path={0}'.format(str(preview.get('phase_d_summary_path', '') or '-')))
            print(' - qa_reject_samples_path={0}'.format(str(preview.get('qa_reject_samples_path', '') or '-')))
        if preview and str(rec.get('recommended_action_kind', '') or '') == 'review_dat_qa_full_block':
            print(' - anchor_run_id={0}'.format(str(preview.get('anchor_run_id', '') or '-')))
            print(' - anchored_diagnosis_source={0}'.format(str(preview.get('anchored_diagnosis_source', '') or '-')))
            print(' - smoke_source_accepted={0}'.format(bool(preview.get('smoke_source_accepted'))))
            print(' - ignored_smoke_mismatch={0}'.format(bool(preview.get('ignored_smoke_mismatch'))))
            sak = str(preview.get('smoke_anchor_run_id', '') or '').strip()
            if sak:
                print(' - smoke_anchor_run_id={0}'.format(sak))
            smn = str(preview.get('source_mismatch_note', '') or '').strip()
            if smn:
                print(' - source_mismatch_note={0}'.format(smn))
            print(' - dat_selected_count={0}'.format(int(preview.get('dat_selected_count', 0) or 0)))
            print(' - dat_qa_pass_count={0}'.format(int(preview.get('dat_qa_pass_count', 0) or 0)))
            print(' - dat_qa_reject_count={0}'.format(int(preview.get('dat_qa_reject_count', 0) or 0)))
            print(' - dat_canonical_record_count={0}'.format(int(preview.get('dat_canonical_record_count', 0) or 0)))
            print(' - phase_d_summary_path={0}'.format(str(preview.get('phase_d_summary_path', '') or '-')))
            print(' - qa_reject_samples_path={0}'.format(str(preview.get('qa_reject_samples_path', '') or '-')))
            srp = str(preview.get('smoke_report_path', '') or '').strip()
            if bool(preview.get('ignored_smoke_mismatch')):
                print(' - ignored_smoke_report_path={0}'.format(srp or '-'))
                if srp:
                    print(' - (ignore this smoke report for anchored review unless its report JSON anchor matches the reviewed run.)')
            else:
                print(' - smoke_report_path={0}'.format(srp or '-'))
                if srp:
                    print(' - (smoke reports use the filename written under phase_d_dat_smoke_lab/reports/, often keyed by the smoke pipeline run id or anchor id from the report JSON.)')

    def _support_send_type_label(self, primary_send):
        p = str(primary_send or '').strip()
        if p == 'run_evidence':
            return 'run evidence bundle (B..F)'
        if p == 'system_health':
            return 'System Health Pack'
        return p or '(unknown)'

    def _recommended_artifact_classes(self, rec):
        classes = rec.get('recommended_artifact_classes', []) if isinstance(rec, dict) else []
        if not isinstance(classes, list):
            return []
        out = []
        for item in classes:
            text = str(item or '').strip().lower()
            if text and text not in out:
                out.append(text)
        return out

    def _recommended_action_label(self, action_kind, rec, send_type=''):
        kind = str(action_kind or 'send_bundle').strip()
        if kind == 'historical_phase_d_reprocess':
            classes = self._recommended_artifact_classes(rec)
            label = ', '.join(classes) if classes else 'targeted classes'
            return 'historical Phase D re-evaluation ({0})'.format(label)
        if kind == 'phase_d_dat_smoke':
            preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
            anchor = str(preview.get('anchor_run_id', '') or rec.get('recommendation_anchor_run_id', '') or '').strip()
            if anchor:
                return 'Phase D DAT smoke (anchor {0})'.format(anchor)
            return 'Phase D DAT smoke'
        if kind == 'phase_d_dat_verification_rerun':
            preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
            phase_d = str(preview.get('phase_d_context_run_id', '') or '').strip()
            if phase_d:
                return 'focused Phase D DAT verification rerun (Phase D {0})'.format(phase_d)
            return 'focused Phase D DAT verification rerun'
        if kind == 'review_dat_qa_full_block':
            preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
            anchor = str(preview.get('anchor_run_id', '') or rec.get('recommendation_anchor_run_id', '') or '').strip()
            if anchor:
                return 'anchored run evidence bundle for DAT QA full-block (anchor {0})'.format(anchor)
            return 'anchored run evidence bundle for DAT QA full-block'
        if kind == 'wait_for_stable':
            stable_kind = str(
                rec.get('preferred_when_stable_action_kind')
                or rec.get('recommended_action_kind')
                or 'send_bundle'
            ).strip()
            if stable_kind == 'wait_for_stable':
                return 'wait for stable pipeline state'
            return 'wait for stable pipeline state, then {0}'.format(
                self._recommended_action_label(stable_kind, rec, send_type=send_type)
            )
        return self._support_send_type_label(send_type or rec.get('best_now_send') or rec.get('preferred_when_stable') or rec.get('primary_send') or 'system_health')

    def _print_historical_phase_d_reprocess_preview(self, data):
        preview = data if isinstance(data, dict) else {}
        print('Historical Phase D re-evaluation preview:')
        print(' - targeted_artifact_classes={0}'.format(','.join(self._recommended_artifact_classes({'recommended_artifact_classes': preview.get('targeted_artifact_classes', [])})) or '-'))
        print(' - qa_policy_version={0}'.format(str(preview.get('qa_version', '') or '-')))
        print(' - targeted_artifact_count={0}'.format(int(preview.get('targeted_artifact_count', 0) or 0)))
        reject_counts = preview.get('reject_counts_by_class', {}) if isinstance(preview.get('reject_counts_by_class', {}), dict) else {}
        if reject_counts:
            parts = []
            for key in sorted(reject_counts):
                try:
                    value = int(reject_counts.get(key, 0) or 0)
                except Exception:
                    value = 0
                if value > 0:
                    parts.append('{0}:{1}'.format(key, value))
            print(' - reject_counts_by_class={0}'.format(', '.join(parts) if parts else 'none'))
        pending_counts = preview.get('pending_replay_counts_by_class', {}) if isinstance(preview.get('pending_replay_counts_by_class', {}), dict) else {}
        if pending_counts:
            parts = []
            for key in sorted(pending_counts):
                try:
                    value = int(pending_counts.get(key, 0) or 0)
                except Exception:
                    value = 0
                if value > 0:
                    parts.append('{0}:{1}'.format(key, value))
            print(' - pending_replay_counts_by_class={0}'.format(', '.join(parts) if parts else 'none'))
        report_path = str(preview.get('report_path', '') or '').strip()
        if report_path:
            print(' - preview_report={0}'.format(report_path))

    def _run_historical_phase_d_reprocess_action(self, rec, confirm_prompt=False, quiet=False):
        cr = self._cloud_readiness_service()
        if cr is None:
            return False
        classes = self._recommended_artifact_classes(rec)
        ctx_rid = ''
        if isinstance(rec, dict):
            ctx_rid = str(rec.get('recommendation_anchor_run_id') or rec.get('run_id') or '').strip()
        diag_ctx = ''
        anchor_line = ''
        if isinstance(rec, dict):
            prv = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
            anchor_line = str(
                prv.get('anchor_run_id')
                or rec.get('recommendation_anchor_run_id')
                or rec.get('run_id')
                or ''
            ).strip()
        if anchor_line:
            diag_ctx += 'anchor_run_id={0}\n'.format(anchor_line)
        if ctx_rid:
            diag_ctx += 'remediation_context_run_id={0}\n'.format(ctx_rid)

        preview_failure_note = []

        def _append_hist_diag(note_list):
            if cr is None:
                return
            try:
                hist = cr.get_last_historical_phase_d_reprocess_helper_diagnostics()
            except Exception:
                hist = {}
            if not isinstance(hist, dict):
                return
            for key in (
                    'hist_helper_stage',
                    'resolved_script_path',
                    'recommended_action_kind',
                    'script_resolution_ok',
                    'resolution_message',
                    'import_exception_class',
                    'import_exception_message',
                    'helper_functions_missing'):
                if key not in hist:
                    continue
                val = hist.get(key)
                if val is None or val == '':
                    continue
                note_list.append('hist_helper:{0}={1}'.format(key, val))
            cand = hist.get('script_path_candidates')
            if isinstance(cand, list) and cand:
                note_list.append('hist_helper:script_path_candidates={0}'.format(
                    ';'.join([str(p)[:240] for p in cand[:6]])))

        with _maybe_console_activity_heartbeat('historical Phase D re-evaluation: preview', quiet=quiet):
            ok_preview, msg_preview, preview = cr.preview_historical_phase_d_reprocess(
                self.repo_root,
                artifact_classes=classes,
                remediation_context_run_id=ctx_rid or None,
            ) if cr is not None else (False, 'Cloud Readiness unavailable', None)

        _append_hist_diag(preview_failure_note)

        if msg_preview and not quiet:
            print(msg_preview)
        if preview and not quiet:
            self._print_historical_phase_d_reprocess_preview(preview)
        if not ok_preview:
            note_lines = list(preview_failure_note)
            note_lines.insert(0, 'failure_reason=historical_preview_failed')
            if msg_preview:
                note_lines.append('preview_msg={0}'.format(msg_preview[:800]))
            if diag_ctx:
                note_lines.append(diag_ctx.strip())
            attachment = self._write_post_update_autofollow_diagnostic_attachment(note_lines)
            self._log_support_send_event('historical_phase_d_reprocess_preview_failed', {
                'anchor_run_id': anchor_line or ctx_rid or '',
                'context_run_id': ctx_rid or '',
                'attachment_path': attachment,
                'hist_helper_preview_lines': preview_failure_note[:12],
            })
            return False
        if confirm_prompt:
            confirm = (self._prompt('Proceed with historical Phase D re-evaluation? [y/N]: ') or 'n').strip().lower()
            if confirm not in ('y', 'yes'):
                print('Cancelled.')
                return False
        else:
            if not quiet:
                print('Auto-follow-through: proceeding with historical Phase D re-evaluation without prompt.')
        run_failure_note = list(preview_failure_note)
        with _maybe_console_activity_heartbeat('historical Phase D re-evaluation: reset + Phase D launch', quiet=quiet):
            ok_run, msg_run, data = cr.run_historical_phase_d_reprocess(
                self.repo_root,
                self.python_exe,
                self.environment,
                artifact_classes=classes,
                remediation_context_run_id=ctx_rid or None,
            ) if cr is not None else (False, 'Cloud Readiness unavailable', None)
            _append_hist_diag(run_failure_note)
        if msg_run and not quiet:
            print(msg_run)
        if isinstance(data, dict) and not quiet:
            report_path = str(data.get('execution_report_path', '') or '').strip()
            if report_path:
                print('Execution report: {0}'.format(report_path))
            attempt_path = str(data.get('phase_d_attempt_path', '') or '').strip()
            if attempt_path:
                print('Phase D rerun attempt: {0}'.format(attempt_path))
        if ok_run:
            if not quiet:
                print('Historical Phase D re-evaluation action completed. Reopen Cloud Readiness after the Phase D rerun settles for the next recommendation.')
            return True
        note_lines = list(run_failure_note)
        note_lines.insert(0, 'failure_reason=historical_run_failed')
        if msg_run:
            note_lines.append('run_msg={0}'.format(msg_run[:800]))
        if isinstance(data, dict) and data.get('phase_d_launch_error'):
            note_lines.append('phase_d_launch_error={0}'.format(str(data.get('phase_d_launch_error'))[:400]))
        if diag_ctx:
            note_lines.append(diag_ctx.strip())
        attachment = self._write_post_update_autofollow_diagnostic_attachment(note_lines)
        self._log_support_send_event('historical_phase_d_reprocess_run_failed', {
            'anchor_run_id': anchor_line or ctx_rid or '',
            'attachment_path': attachment,
        })
        return False

    def _dat_smoke_target_from_rec(self, rec):
        preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        rem = rec.get('phase_d_remediation') if isinstance(rec.get('phase_d_remediation'), dict) else {}
        anchor = str(
            preview.get('anchor_run_id')
            or rec.get('recommendation_anchor_run_id')
            or rec.get('run_id')
            or ''
        ).strip()
        context = str(preview.get('phase_d_context_run_id') or anchor or '').strip()
        issue_code = str(
            preview.get('remediation_issue_code')
            or rem.get('issue_code')
            or ''
        ).strip()
        ref_path = str(preview.get('reference_phase_d_summary_path', '') or '').strip()
        return anchor, context, issue_code, ref_path

    def _run_phase_d_dat_smoke_action(self, rec, announce_prefix='', quiet=False):
        anchor, context, issue_code, ref_path = self._dat_smoke_target_from_rec(rec if isinstance(rec, dict) else {})
        if announce_prefix and not quiet:
            print(str(announce_prefix))
        if not quiet:
            print(_automatic_routing_reason_line(
                rec if isinstance(rec, dict) else {},
                fallback_reason='DAT smoke is the current Cloud Readiness recommendation',
            ))
        if self._run_phase_d_dat_smoke(
                reference_phase_d_summary_path=ref_path,
                anchor_run_id=anchor,
                context_run_id=context,
                issue_code=issue_code):
            return True
        return False

    def _review_dat_qa_full_block_action(self, rec, operator_execution_mode='follow_recommendation', pause_for_ack=True, installed_version='', recommendation_action_kind='review_dat_qa_full_block', source='cloud_readiness_follow_recommendation', quiet=False):
        preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        anchor_run_id = str(
            preview.get('anchor_run_id')
            or rec.get('recommendation_anchor_run_id')
            or rec.get('run_id')
            or ''
        ).strip()
        if anchor_run_id and not quiet:
            print('Sending anchored run evidence bundle for DAT QA full-block (anchor {0})...'.format(anchor_run_id))
        elif not quiet:
            print('Sending anchored run evidence bundle for DAT QA full-block...')
        if not quiet:
            print('QA summary, reject samples, shadow report, and embedded closure context will be attached automatically.')
        ok_send = bool(self._send_bundle_for_operator_type(
            'run_evidence',
            recommendation=rec,
            operator_execution_mode=operator_execution_mode,
            source=source,
            priority='high',
            pause_for_ack=pause_for_ack,
            installed_version=installed_version,
            recommendation_action_kind=recommendation_action_kind,
            send_source_override='follow_rec_deferred_dat_qa_full_block'
            if operator_execution_mode == 'follow_recommendation_deferred'
            else 'follow_rec_dat_qa_full_block',
        ))
        if ok_send:
            return True
        if not quiet:
            print('Run-evidence send did not complete; opening latest artifact triage pack for context.')
            self._open_latest_artifact_triage_pack()
        return False

    def _run_phase_d_dat_verification_rerun_action(self, rec, confirm_prompt=True, quiet=False):
        rec2 = dict(rec) if isinstance(rec, dict) else {}
        rec2['recommended_action_kind'] = 'historical_phase_d_reprocess'
        rec2['recommended_artifact_classes'] = ['dat']
        preview = rec2.get('action_preview') if isinstance(rec2.get('action_preview'), dict) else {}
        phase_d = str(preview.get('phase_d_context_run_id', '') or '').strip()
        if phase_d and not rec2.get('recommendation_anchor_run_id'):
            rec2['recommendation_anchor_run_id'] = phase_d
        if not quiet:
            print('Starting focused Phase D DAT verification rerun with current resolver diagnostics...')
        return self._run_historical_phase_d_reprocess_action(rec2, confirm_prompt=confirm_prompt, quiet=quiet)

    def _queue_phase_d_dat_smoke_deferred(self, rec, reason='pipeline_running'):
        cr = self._cloud_readiness_service()
        if cr is None:
            return False
        anchor, context, issue_code, ref_path = self._dat_smoke_target_from_rec(rec if isinstance(rec, dict) else {})
        return bool(cr.write_operator_deferred_phase_d_dat_smoke(
            self.repo_root,
            anchor,
            context,
            issue_code=issue_code,
            reference_phase_d_summary_path=ref_path,
            reason=reason,
        ))

    def _try_deferred_phase_d_dat_smoke(self):
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        intent = cr.read_operator_deferred_phase_d_dat_smoke(self.repo_root)
        if not isinstance(intent, dict):
            return
        running, _ = cr.check_pipeline_running_for_action(self.repo_root, 'Deferred Phase D DAT smoke')
        if running:
            return
        rec = self._operator_support_send_rec()
        if not isinstance(rec, dict):
            cr.clear_operator_deferred_phase_d_dat_smoke(self.repo_root)
            return
        if str(rec.get('recommended_action_kind', '') or '').strip() != 'phase_d_dat_smoke':
            cr.clear_operator_deferred_phase_d_dat_smoke(self.repo_root)
            return
        live_anchor, live_context, live_issue, _live_ref = self._dat_smoke_target_from_rec(rec)
        stale = (
            str(intent.get('anchor_run_id', '') or '').strip() != live_anchor
            or str(intent.get('context_run_id', '') or '').strip() != live_context
            or str(intent.get('issue_code', '') or '').strip() != live_issue
        )
        if stale:
            cr.clear_operator_deferred_phase_d_dat_smoke(self.repo_root)
            return
        if self._run_phase_d_dat_smoke_action(rec, announce_prefix='Auto-starting deferred DAT smoke...', quiet=True):
            cr.clear_operator_deferred_phase_d_dat_smoke(self.repo_root)

    def _maybe_autorun_phase_d_dat_smoke(self, rec):
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        if not isinstance(rec, dict):
            return
        if str(rec.get('recommended_action_kind', '') or '').strip() != 'phase_d_dat_smoke':
            return
        if bool(rec.get('pipeline_running')):
            # Queue one-shot deferred smoke while pipeline is active.
            self._queue_phase_d_dat_smoke_deferred(rec, reason='pipeline_running')
            return
        anchor, context, issue_code, _ref = self._dat_smoke_target_from_rec(rec)
        if not anchor or not context:
            return
        target_key = '{0}|{1}|{2}'.format(anchor, context, issue_code)
        attempted = str(getattr(self, '_dat_smoke_autorun_target_attempted', '') or '').strip()
        if attempted == target_key:
            return
        setattr(self, '_dat_smoke_autorun_target_attempted', target_key)
        state = cr.read_phase_d_dat_smoke_state(self.repo_root)
        if isinstance(state, dict):
            same = (
                str(state.get('last_requested_anchor_run_id', '') or '').strip() == anchor
                and str(state.get('last_requested_context_run_id', '') or '').strip() == context
                and str(state.get('last_remediation_issue_code', '') or '').strip() == issue_code
            )
            if same:
                status = str(state.get('last_status', '') or '').strip().lower()
                if status in ('running', 'started'):
                    return
                cooldown = str(state.get('cooldown_until_utc', '') or '').strip()
                if cooldown:
                    try:
                        from calendar import timegm
                        from datetime import datetime
                        until_epoch = timegm(datetime.strptime(cooldown, '%Y-%m-%dT%H:%M:%SZ').timetuple())
                    except Exception:
                        until_epoch = 0
                    if until_epoch and until_epoch > time.time():
                        return
        if self._run_phase_d_dat_smoke_action(
                rec,
                announce_prefix='DAT smoke auto-started from current recommendation.',
                quiet=True):
            # Clear stale deferred intent after successful auto-start for same target.
            intent = cr.read_operator_deferred_phase_d_dat_smoke(self.repo_root)
            if isinstance(intent, dict):
                same = (
                    str(intent.get('anchor_run_id', '') or '').strip() == anchor
                    and str(intent.get('context_run_id', '') or '').strip() == context
                    and str(intent.get('issue_code', '') or '').strip() == issue_code
                )
                if same:
                    cr.clear_operator_deferred_phase_d_dat_smoke(self.repo_root)

    def _print_health_reporting_status(self, rec):
        """Compact status for Health & Reporting (uses compute_operator_support_send_recommendation)."""
        if not isinstance(rec, dict):
            return
        pipe = str(rec.get('pipeline_label', '') or ('running' if rec.get('pipeline_running') else 'idle'))
        run_disp = str(rec.get('run_id', '') or '').strip() or '-'
        pws = str(rec.get('preferred_when_stable') or rec.get('primary_send') or 'system_health').strip()
        if pws not in ('run_evidence', 'system_health'):
            pws = 'system_health'
        bns = str(rec.get('best_now_send') or pws).strip()
        if bns not in ('run_evidence', 'system_health'):
            bns = pws
        best_now_action = str(rec.get('best_now_action_kind', '') or rec.get('recommended_action_kind', '') or 'send_bundle').strip()
        stable_action = str(rec.get('preferred_when_stable_action_kind', '') or rec.get('recommended_action_kind', '') or 'send_bundle').strip()
        why = str(rec.get('why_summary', '') or '').strip() or '-'
        print('Health & Reporting - Status:')
        print('  Pipeline: {0}'.format(pipe))
        print('  Current run: {0}'.format(run_disp))
        print('  Best now: {0}'.format(self._recommended_action_label(best_now_action, rec, send_type=bns)))
        print('  Best after stable: {0}'.format(self._recommended_action_label(stable_action, rec, send_type=pws)))
        report_kind = str(rec.get('recommended_report_kind', '') or '').strip()
        if report_kind:
            print('  Recommended report: {0}'.format(report_kind))
        print('  Why: {0}'.format(why))
        print('')

    def _support_send_job_manager(self):
        cr = self._cloud_readiness_service()
        if cr is None:
            return None
        try:
            from MediCafe import support_send_jobs
        except Exception:
            return None
        lab_root = cr.resolve_lab_root(self.repo_root)
        cache = getattr(self, '_support_send_job_manager_cache', None)
        if isinstance(cache, dict):
            if cache.get('lab_root') == lab_root and cache.get('manager') is not None:
                return cache.get('manager')

        def _manager_logger(event_name, details=None):
            payload = details if isinstance(details, dict) else {'result_message': str(details or '')}
            suffix = str(event_name or 'manager').strip() or 'manager'
            self._log_support_send_event('support_send_{0}'.format(suffix), payload)

        manager = support_send_jobs.SupportSendJobManager(
            repo_root=self.repo_root,
            lab_root=lab_root,
            logger_fn=_manager_logger,
            python_exe=getattr(self, 'python_exe', ''),
        )
        setattr(self, '_support_send_job_manager_cache', {'lab_root': lab_root, 'manager': manager})
        return manager

    def _support_send_manager_list_jobs(self, manager, limit=30, ensure_liveness=True):
        if manager is None:
            return []
        try:
            jobs = manager.list_jobs(limit=limit, ensure_liveness=ensure_liveness)
        except TypeError:
            jobs = manager.list_jobs(limit=limit)
        return jobs if isinstance(jobs, list) else []

    def _background_support_send_jobs(self, limit=30, ensure_liveness=True):
        manager = self._support_send_job_manager()
        if manager is None:
            return []
        try:
            jobs = self._support_send_manager_list_jobs(
                manager,
                limit=limit,
                ensure_liveness=ensure_liveness,
            )
        except Exception:
            return []
        return jobs

    def _active_background_support_send_jobs(self, limit=30, preflight=True):
        manager = self._support_send_job_manager()
        if manager is not None and preflight:
            try:
                manager.preflight_reap_stale_running_jobs()
                manager._ensure_worker_locked()
            except Exception:
                pass
        active = []
        for row in self._background_support_send_jobs(limit=limit, ensure_liveness=preflight):
            if not isinstance(row, dict):
                continue
            status = str(row.get('status', '') or '').strip()
            if status in ('queued', 'running'):
                active.append(row)
        return active

    def _latest_finished_background_support_send_job(self, limit=30, ensure_liveness=True):
        for row in self._background_support_send_jobs(limit=limit, ensure_liveness=ensure_liveness):
            if not isinstance(row, dict):
                continue
            status = str(row.get('status', '') or '').strip()
            if status not in ('succeeded', 'failed', 'canceled', 'blocked'):
                continue
            if str(row.get('finished_at_utc', '') or '').strip():
                return row
        return None

    def _support_send_operator_state(self, row):
        payload = row if isinstance(row, dict) else {}
        status = str(payload.get('status', '') or '').strip().lower()
        stage = str(payload.get('progress_stage', '') or '').strip()
        stage_key = stage.lower()
        delivery_state = str(payload.get('delivery_state', '') or '').strip()
        delivery_issue = str(payload.get('delivery_issue_code', '') or '').strip()

        if status == 'queued':
            return 'pending/queued'
        if status == 'running':
            assembling_tokens = (
                'bundle',
                'zip',
                'attachment',
                'payload',
                'snapshot',
                'collect',
                'writing',
                'creating',
                'adding',
                'assembling',
            )
            for token in assembling_tokens:
                if token in stage_key:
                    return 'assembling bundle'
            if 'send' in stage_key or 'email' in stage_key or 'gmail' in stage_key or 'delivery' in stage_key:
                return 'sending to support'
            return 'running'
        if status == 'succeeded':
            return 'sent/succeeded'
        if status == 'blocked':
            return 'blocked'
        if status == 'failed':
            if delivery_issue or delivery_state:
                return 'blocked/needs attention'
            return 'failed'
        if status == 'canceled':
            return 'canceled'
        if status:
            return status
        return 'unknown'

    def _support_send_status_counts(self, jobs):
        counts = {
            'pending': 0,
            'assembling': 0,
            'sending': 0,
            'succeeded': 0,
            'blocked': 0,
            'failed': 0,
        }
        for row in jobs if isinstance(jobs, list) else []:
            if not isinstance(row, dict):
                continue
            operator_state = self._support_send_operator_state(row)
            if operator_state == 'pending/queued':
                counts['pending'] += 1
            elif operator_state == 'assembling bundle':
                counts['assembling'] += 1
            elif operator_state == 'sending to support':
                counts['sending'] += 1
            elif operator_state == 'sent/succeeded':
                counts['succeeded'] += 1
            elif operator_state.startswith('blocked'):
                counts['blocked'] += 1
            elif operator_state == 'failed':
                counts['failed'] += 1
        return counts

    def _support_send_status_summary_line(self, jobs):
        counts = self._support_send_status_counts(jobs)
        parts = []
        for key, label in (
                ('pending', 'pending/queued'),
                ('assembling', 'assembling'),
                ('sending', 'sending'),
                ('succeeded', 'succeeded/sent'),
                ('blocked', 'blocked'),
                ('failed', 'failed')):
            value = int(counts.get(key, 0) or 0)
            if value:
                parts.append('{0}={1}'.format(label, value))
        if not parts:
            return 'Status: no active or recent support bundle jobs.'
        return 'Status: {0}'.format(', '.join(parts))

    def _latest_support_send_stale_preflight_audit(self):
        manager = self._support_send_job_manager()
        if manager is None or not hasattr(manager, 'read_stale_preflight_audit'):
            return {}
        try:
            audit = manager.read_stale_preflight_audit()
        except Exception:
            audit = {}
        return audit if isinstance(audit, dict) else {}

    def _support_send_stale_preflight_summary_line(self, audit):
        payload = audit if isinstance(audit, dict) else {}
        found = int(payload.get('stale_running_jobs_found', 0) or 0)
        if found <= 0:
            return ''
        resolved = int(payload.get('resolved_count', 0) or 0)
        unresolved = int(payload.get('unresolved_count', 0) or 0)
        term = int(payload.get('termination_attempt_count', 0) or 0)
        written = str(payload.get('written_at_utc', '') or '').strip()
        parts = ['stale blockers found={0}'.format(found), 'cleaned={0}'.format(resolved)]
        if term:
            parts.append('termination attempts={0}'.format(term))
        if unresolved:
            parts.append('still blocked={0}'.format(unresolved))
        line = 'Support-send cleanup: ' + ', '.join(parts)
        if written:
            line += ' at {0}'.format(written)
        return line

    def _maybe_print_support_send_shp_stuck_hint(self):
        mgr = self._support_send_job_manager()
        if mgr is None:
            return False
        try:
            threshold_run = max(1, int(getattr(mgr, 'running_abandoned_sec', 86400) or 86400) // 4)
            for row in mgr.list_jobs(limit=30):
                if not isinstance(row, dict):
                    continue
                if str(row.get('send_type', '') or '').strip() != 'system_health':
                    continue
                st = str(row.get('status', '') or '').strip()
                if st == 'running':
                    ra = mgr._running_age_sec(row)
                    if ra is not None and int(ra) > threshold_run:
                        self._log_support_send_event('support_send_stuck_hint', {
                            'job_id': str(row.get('job_id', '') or ''),
                            'status': st,
                            'hint': 'auto_reap_attempt_pending',
                        })
                        mgr.preflight_reap_stale_running_jobs()
                        mgr._ensure_worker_locked()
                        return True
                elif st == 'blocked':
                    pr = str(row.get('policy_reason', '') or '').strip()
                    ja = mgr._job_age_sec(row)
                    if pr == 'single_flight_busy' and ja is not None and int(ja) > 900:
                        self._log_support_send_event('support_send_stuck_hint', {
                            'job_id': str(row.get('job_id', '') or ''),
                            'status': st,
                            'policy_reason': pr,
                            'hint': 'auto_reap_attempt_pending',
                        })
                        mgr.preflight_reap_stale_running_jobs()
                        mgr._ensure_worker_locked()
                        return True
        except Exception:
            pass
        return False

    def _print_background_support_send_status_banner(self, passive=False):
        if self._print_post_update_autofollow_status_banner(passive=passive):
            return True
        active = self._active_background_support_send_jobs(limit=30, preflight=not passive)
        if not active:
            if passive:
                return False
            return bool(self._maybe_print_support_send_shp_stuck_hint())
        latest = active[0]
        job_id = str(latest.get('job_id', '') or '-')
        status = str(latest.get('status', '') or '-')
        stage = str(latest.get('progress_stage', '') or '-')
        print('')
        print('[BACKGROUND CLOUD JOB ACTIVE] Evidence delivery is running in the background.')
        print('  Latest job: {0} status={1} stage={2}'.format(job_id, status, stage))
        print('  Operator status: {0}'.format(self._support_send_operator_state(latest)))
        if not passive:
            self._maybe_print_support_send_shp_stuck_hint()
        if len(active) > 1:
            print('  Additional active jobs: {0}'.format(len(active) - 1))
        print('  Monitor: Troubleshooting -> Cloud Readiness -> Background cloud jobs')
        print('')
        return True

    def _confirm_exit_with_active_support_send_jobs(self):
        # Post-update guard: _post_update_autofollow_still_blocks_action is True when exit must stay blocked.
        if self._post_update_autofollow_still_blocks_action('exit'):
            return False
        active = self._active_background_support_send_jobs(limit=30)
        if not active:
            return True
        latest = active[0]
        job_id = str(latest.get('job_id', '') or '-')
        status = str(latest.get('status', '') or '-')
        stage = str(latest.get('progress_stage', '') or '-')
        print('')
        print('[WARNING] Background cloud job still active.')
        print('  Closing MediCafe now may interrupt evidence delivery.')
        print('  Job: {0} status={1} stage={2}'.format(job_id, status, stage))
        print('  Operator status: {0}'.format(self._support_send_operator_state(latest)))
        if len(active) > 1:
            print('  Additional active jobs: {0}'.format(len(active) - 1))
        print('  Monitor: Troubleshooting -> Cloud Readiness -> Background cloud jobs')
        print('')
        try:
            choice = (self._prompt('Type y/yes to exit anyway, or press Enter to keep MediCafe open: ') or '').strip()
        except Exception:
            choice = ''
        if choice.lower() in ('y', 'yes'):
            return True
        print('Exit canceled. Keep MediCafe open until the background cloud job finishes.')
        try:
            self._prompt('Press Enter to return to menu...')
        except Exception:
            pass
        return False

    def _cloud_readiness_autofollow_state_path(self):
        cr = self._cloud_readiness_service()
        if cr is None:
            return ''
        try:
            lab_root = cr.resolve_lab_root(self.repo_root)
        except Exception:
            lab_root = ''
        if not lab_root:
            return ''
        return os.path.join(lab_root, 'reports', _CLOUD_READINESS_AUTOFOLLOW_STATE_FILENAME)

    def _read_cloud_readiness_autofollow_state(self):
        path = self._cloud_readiness_autofollow_state_path()
        if not path or not os.path.isfile(path):
            return {}
        try:
            with io.open(path, 'r', encoding='utf-8') as handle:
                data = json.load(handle)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _write_cloud_readiness_autofollow_state(self, state):
        path = self._cloud_readiness_autofollow_state_path()
        if not path:
            return False
        payload = state if isinstance(state, dict) else {}
        try:
            parent = os.path.dirname(path)
            if parent and not os.path.isdir(parent):
                os.makedirs(parent)
            tmp_path = path + '.tmp'
            with io.open(tmp_path, 'w', encoding='utf-8') as handle:
                json.dump(payload, handle, indent=2, sort_keys=True)
                handle.write('\n')
            if os.path.exists(path):
                try:
                    os.remove(path)
                except Exception:
                    pass
            os.rename(tmp_path, path)
            return True
        except Exception:
            return False

    def _cloud_readiness_autofollow_enabled(self):
        raw = str(os.environ.get('MEDICAFE_CLOUD_READINESS_AUTOFOLLOW', '1') or '').strip().lower()
        return raw not in ('0', 'false', 'no', 'off', 'n')

    def _cloud_readiness_autofollow_dedup_sec(self):
        raw = str(os.environ.get('MEDICAFE_CLOUD_READINESS_AUTOFOLLOW_DEDUP_SEC', '') or '').strip()
        if not raw:
            return _CLOUD_READINESS_AUTOFOLLOW_DEDUP_DEFAULT_SEC
        try:
            return max(1, int(raw))
        except Exception:
            return _CLOUD_READINESS_AUTOFOLLOW_DEDUP_DEFAULT_SEC

    def _main_menu_cloud_autofollow_enabled(self):
        raw = str(os.environ.get('MEDICAFE_MAIN_MENU_CLOUD_AUTOFOLLOW', '1') or '').strip().lower()
        return raw not in ('0', 'false', 'no', 'off', 'n')

    def _quiet_cloud_autofollow_terminal(self, source='', operator_execution_mode='', quiet=False):
        src = str(source or '').strip()
        mode = str(operator_execution_mode or '').strip()
        return bool(
            quiet
            or src in ('post_update_cloud_autofollow', _MAIN_MENU_CLOUD_AUTOFOLLOW_SOURCE)
            or mode in ('post_update_autofollow', _MAIN_MENU_CLOUD_AUTOFOLLOW_MODE)
        )

    def _cloud_readiness_autofollow_key(self, recommendation, plan):
        rec = recommendation if isinstance(recommendation, dict) else {}
        pl = plan if isinstance(plan, dict) else {}
        anchor, context, issue = self._send_job_anchor_context_issue(rec)
        parts = [
            str(pl.get('preferred_action') or ''),
            str(pl.get('preferred_send') or ''),
            str(pl.get('best_now_send') or ''),
            str(pl.get('report_kind') or ''),
            anchor,
            context,
            issue,
            'running' if bool(pl.get('unstable')) else 'idle',
            str(rec.get('recommendation_source_scope', '') or ''),
            str(rec.get('recommended_report_kind', '') or ''),
            str(rec.get('recommended_action_kind', '') or ''),
            str(rec.get('preferred_when_stable_action_kind', '') or ''),
            str(rec.get('best_now_action_kind', '') or ''),
        ]
        return '|'.join(parts)

    def _cloud_readiness_autofollow_recently_attempted(self, key):
        state = self._read_cloud_readiness_autofollow_state()
        if str(state.get('last_key', '') or '') != str(key or ''):
            return False
        try:
            last_epoch = float(state.get('last_started_epoch', 0.0) or 0.0)
        except Exception:
            last_epoch = 0.0
        if last_epoch <= 0:
            return False
        return (time.time() - last_epoch) < float(self._cloud_readiness_autofollow_dedup_sec())

    def _patch_cloud_readiness_autofollow_state(self, updates):
        state = self._read_cloud_readiness_autofollow_state()
        if not isinstance(state, dict):
            state = {}
        state.update(updates or {})
        state['updated_at_utc'] = _utc_now()
        self._write_cloud_readiness_autofollow_state(state)
        return state

    def _maybe_autofollow_cloud_readiness_recommendation(
            self,
            recommendation,
            trigger='cloud_readiness_menu',
            source='cloud_readiness_menu_autofollow',
            operator_execution_mode='cloud_readiness_autofollow',
            quiet=False,
            queue_best_now_when_unstable=False):
        rec = recommendation if isinstance(recommendation, dict) else {}
        if not rec or not self._cloud_readiness_autofollow_enabled():
            return False
        if not bool(rec.get('autonomous_followthrough_allowed')):
            return False
        if bool(rec.get('action_requires_confirmation')) or bool(rec.get('operator_manual_review_required')):
            return False
        plan = self._recommendation_execution_plan(rec)
        key = self._cloud_readiness_autofollow_key(rec, plan)
        if self._cloud_readiness_autofollow_recently_attempted(key):
            return False
        action = str(plan.get('preferred_action') or '').strip()
        self._patch_cloud_readiness_autofollow_state({
            'last_key': key,
            'last_started_epoch': time.time(),
            'last_started_at_utc': _utc_now(),
            'last_trigger': str(trigger or 'cloud_readiness_menu'),
            'last_recommendation_action_kind': action,
            'last_status': 'starting',
            'last_operator_burden_policy': str(rec.get('operator_burden_policy', '') or ''),
            'last_autonomous_followthrough_reason': str(rec.get('autonomous_followthrough_reason', '') or ''),
        })
        started = bool(self._start_cloud_recommendation_followthrough(
            recommendation=rec,
            trigger=trigger,
            source=source,
            operator_execution_mode=operator_execution_mode,
            post_update=False,
            quiet=quiet,
            queue_best_now_when_unstable=queue_best_now_when_unstable,
        ))
        result = getattr(self, '_last_support_send_enqueue_result', {})
        self._patch_cloud_readiness_autofollow_state({
            'last_status': 'started' if started else 'not_started',
            'last_finished_at_utc': _utc_now(),
            'last_support_send_result': result if isinstance(result, dict) else {},
        })
        return started

    def _start_main_menu_cloud_readiness_autofollow_thread(self):
        """Quietly evaluate and follow Cloud Readiness recommendation from the main menu."""
        if not self._main_menu_cloud_autofollow_enabled():
            return False
        existing = getattr(self, '_main_menu_cloud_autofollow_thread', None)
        try:
            if existing is not None and existing.is_alive():
                return False
        except Exception:
            pass

        def _worker():
            try:
                state = self._refresh_post_update_autofollow_state()
                if self._is_post_update_autofollow_active(state):
                    return
                rec = self._operator_support_send_rec()
                self._maybe_autofollow_cloud_readiness_recommendation(
                    rec,
                    trigger='main_menu_launch',
                    source=_MAIN_MENU_CLOUD_AUTOFOLLOW_SOURCE,
                    operator_execution_mode=_MAIN_MENU_CLOUD_AUTOFOLLOW_MODE,
                    quiet=True,
                    queue_best_now_when_unstable=True,
                )
            except Exception as exc:
                try:
                    self._log_support_send_event('main_menu_autofollow_failed', {
                        'source': _MAIN_MENU_CLOUD_AUTOFOLLOW_SOURCE,
                        'operator_execution_mode': _MAIN_MENU_CLOUD_AUTOFOLLOW_MODE,
                        'status': 'failed',
                        'result_message': exc.__class__.__name__,
                    })
                except Exception:
                    pass

        thread = threading.Thread(target=_worker)
        thread.daemon = True
        thread.start()
        self._main_menu_cloud_autofollow_thread = thread
        return True


    def _recommendation_execution_plan(self, recommendation):
        rec = recommendation if isinstance(recommendation, dict) else {}
        preferred_action = str(
            rec.get('preferred_when_stable_action_kind')
            or rec.get('recommended_action_kind')
            or 'send_bundle'
        ).strip()
        unstable = bool(rec.get('pipeline_running'))
        preferred_send = str(rec.get('preferred_when_stable') or rec.get('primary_send') or 'system_health').strip()
        if preferred_send not in ('run_evidence', 'system_health'):
            preferred_send = 'system_health'
        best_now_send = str(rec.get('best_now_send') or preferred_send).strip()
        if best_now_send not in ('run_evidence', 'system_health'):
            best_now_send = preferred_send
        return {
            'preferred_action': preferred_action,
            'unstable': unstable,
            'preferred_send': preferred_send,
            'best_now_send': best_now_send,
            'artifact_classes': self._recommended_artifact_classes(rec),
            'report_kind': str(rec.get('recommended_report_kind', '') or '').strip(),
        }

    def _start_cloud_recommendation_followthrough(
            self,
            recommendation=None,
            trigger='launcher',
            source='launcher_update_autofollow',
            operator_execution_mode='follow_recommendation_deferred',
            installed_version='',
            post_update=False,
            quiet=False,
            queue_best_now_when_unstable=None):
        """
        Auto-follow Cloud Readiness recommendation without manual menu navigation.
        Returns True when a run/send/defer action was accepted.
        """
        cr = self._cloud_readiness_service()
        if cr is None:
            return False
        rec = recommendation if isinstance(recommendation, dict) and recommendation else self._operator_support_send_rec()
        if not isinstance(rec, dict) or not rec:
            return False
        plan = self._recommendation_execution_plan(rec)
        preferred_action = plan['preferred_action']
        unstable = plan['unstable']
        pws = plan['preferred_send']
        bns = plan['best_now_send']
        classes = plan['artifact_classes']
        report_kind = plan['report_kind']
        action_send_type = bns if unstable else pws

        quiet_autofollow = self._quiet_cloud_autofollow_terminal(
            source,
            operator_execution_mode,
            quiet=quiet or bool(post_update),
        )
        if queue_best_now_when_unstable is None:
            queue_best_now_when_unstable = bool(post_update)
        if not quiet_autofollow:
            print('')
            print('[AUTO CLOUD] Follow-through triggered ({0}).'.format(str(trigger or 'launcher')))
            summary = str(rec.get('summary_line', '') or '').strip()
            if summary:
                print('  {0}'.format(summary))
            print('  {0}'.format(_automatic_routing_reason_line(
                rec,
                fallback_reason='Cloud Readiness selected the recommended follow-through action',
            )))
            print('  Status updates appear in menu banners and Cloud Readiness background jobs.')
        self._log_support_send_event('auto_followthrough_start', {
            'trigger': str(trigger or 'launcher'),
            'preferred_action': preferred_action,
            'unstable': unstable,
            'preferred_send': pws,
            'best_now_send': bns,
        })
        if post_update:
            anchor, context, _issue = self._send_job_anchor_context_issue(rec)
            self._patch_post_update_autofollow_state({
                'recommendation_action_kind': preferred_action,
                'send_type': action_send_type,
                'anchor_run_id': anchor,
                'context_run_id': context,
                'remediation_issue_code': _issue,
                'stage': 'executing_recommendation',
                'last_reason': 'executing_recommendation',
            })

        started = False
        if queue_best_now_when_unstable and unstable:
            # Avoid a long hard block while the pipeline settles: send the best-now bundle
            # and preserve the stable preference as deferred Cloud Readiness intent.
            if preferred_action == 'phase_d_dat_smoke':
                self._queue_phase_d_dat_smoke_deferred(rec, reason='pipeline_running')
            elif preferred_action in ('historical_phase_d_reprocess', 'phase_d_dat_verification_rerun', 'review_dat_qa_full_block'):
                try:
                    cr.write_operator_deferred_support_send(
                        self.repo_root,
                        pws,
                        'pipeline_running',
                        action_kind=preferred_action,
                        artifact_classes=classes,
                        recommended_report_kind=report_kind,
                    )
                except Exception:
                    pass
            started = bool(self._send_bundle_for_operator_type(
                bns,
                recommendation=rec,
                operator_execution_mode=operator_execution_mode,
                source=source,
                priority='high',
                pause_for_ack=False,
                installed_version=installed_version,
                recommendation_action_kind=preferred_action,
            ))
            if post_update:
                result = getattr(self, '_last_support_send_enqueue_result', {})
                self._patch_post_update_send_job_result(
                    result,
                    installed_version,
                    preferred_action,
                    bns,
                    'best_now_send_queued_preferred_deferred',
                    default_stage='queued_send',
                )
        elif unstable and preferred_action == 'phase_d_dat_smoke':
            started = bool(self._queue_phase_d_dat_smoke_deferred(rec, reason='pipeline_running'))
        elif unstable and preferred_action in ('historical_phase_d_reprocess', 'phase_d_dat_verification_rerun', 'review_dat_qa_full_block'):
            started = bool(cr.write_operator_deferred_support_send(
                self.repo_root,
                pws,
                'pipeline_running',
                action_kind=preferred_action,
                artifact_classes=classes,
                recommended_report_kind=report_kind,
            ))
        elif unstable:
            if pws != bns:
                try:
                    cr.write_operator_deferred_support_send(
                        self.repo_root,
                        pws,
                        'pipeline_running',
                        action_kind=preferred_action,
                        artifact_classes=classes,
                        recommended_report_kind=report_kind,
                    )
                except Exception:
                    pass
            started = bool(self._send_bundle_for_operator_type(
                bns,
                recommendation=rec,
                operator_execution_mode=operator_execution_mode,
                source=source,
                priority='high',
                pause_for_ack=False,
                installed_version=installed_version,
                recommendation_action_kind=preferred_action,
            ))
        elif preferred_action == 'historical_phase_d_reprocess':
            if post_update:
                self._patch_post_update_autofollow_state({
                    'status': 'running_diagnostic_action',
                    'stage': 'historical_phase_d_reprocess',
                    'diagnostic_action_id': 'historical_phase_d_reprocess',
                    'last_reason': 'diagnostic_action_started',
                })
            started = bool(self._run_historical_phase_d_reprocess_action(
                rec, confirm_prompt=False, quiet=quiet_autofollow))
            if post_update and started:
                self._log_post_update_autofollow_event('diagnostic_action_started', {
                    'installed_version': installed_version,
                    'status': 'running_diagnostic_action',
                    'stage': 'historical_phase_d_reprocess',
                    'diagnostic_action_id': 'historical_phase_d_reprocess',
                    'recommendation_action_kind': preferred_action,
                    'reason': 'historical_phase_d_reprocess_launched',
                })
        elif preferred_action == 'phase_d_dat_smoke':
            if post_update:
                self._patch_post_update_autofollow_state({
                    'status': 'running_diagnostic_action',
                    'stage': 'phase_d_dat_smoke',
                    'diagnostic_action_id': 'phase_d_dat_smoke',
                    'last_reason': 'diagnostic_action_started',
                })
            started = bool(self._run_phase_d_dat_smoke_action(
                rec,
                announce_prefix='Starting DAT smoke (diagnostic, non-blocking)...',
                quiet=quiet_autofollow))
            if post_update and started:
                self._log_post_update_autofollow_event('diagnostic_action_started', {
                    'installed_version': installed_version,
                    'status': 'running_diagnostic_action',
                    'stage': 'phase_d_dat_smoke',
                    'diagnostic_action_id': 'phase_d_dat_smoke',
                    'recommendation_action_kind': preferred_action,
                    'reason': 'phase_d_dat_smoke_launched',
                })
        elif preferred_action == 'phase_d_dat_verification_rerun':
            if post_update:
                self._patch_post_update_autofollow_state({
                    'status': 'running_diagnostic_action',
                    'stage': 'phase_d_dat_verification_rerun',
                    'diagnostic_action_id': 'phase_d_dat_verification_rerun',
                    'last_reason': 'diagnostic_action_started',
                })
            started = bool(self._run_phase_d_dat_verification_rerun_action(
                rec, confirm_prompt=False, quiet=quiet_autofollow))
            if post_update and started:
                self._log_post_update_autofollow_event('diagnostic_action_started', {
                    'installed_version': installed_version,
                    'status': 'running_diagnostic_action',
                    'stage': 'phase_d_dat_verification_rerun',
                    'diagnostic_action_id': 'phase_d_dat_verification_rerun',
                    'recommendation_action_kind': preferred_action,
                    'reason': 'phase_d_dat_verification_rerun_launched',
                })
        elif preferred_action == 'review_dat_qa_full_block':
            started = bool(self._review_dat_qa_full_block_action(
                rec,
                operator_execution_mode=operator_execution_mode,
                pause_for_ack=False,
                installed_version=installed_version,
                recommendation_action_kind=preferred_action,
                source=source,
                quiet=quiet_autofollow,
            ))
        else:
            started = bool(self._send_bundle_for_operator_type(
                pws,
                recommendation=rec,
                operator_execution_mode=operator_execution_mode,
                source=source,
                priority='high',
                pause_for_ack=False,
                installed_version=installed_version,
                recommendation_action_kind=preferred_action,
            ))
        if post_update and preferred_action in ('send_bundle', 'review_dat_qa_full_block') and not unstable:
            result = getattr(self, '_last_support_send_enqueue_result', {})
            self._patch_post_update_send_job_result(
                result,
                installed_version,
                preferred_action,
                pws,
                'recommended_send_queued',
                default_stage='queued_send',
            )
        if post_update and preferred_action in ('historical_phase_d_reprocess', 'phase_d_dat_smoke', 'phase_d_dat_verification_rerun') and not unstable and not started:
            fail_patch = {
                'status': 'failed',
                'stage': preferred_action,
                'finished_at_utc': _utc_now(),
                'last_reason': 'diagnostic_action_not_started',
            }
            if preferred_action in ('historical_phase_d_reprocess', 'phase_d_dat_verification_rerun') and cr is not None:
                try:
                    hh = cr.get_last_historical_phase_d_reprocess_helper_diagnostics()
                    if isinstance(hh, dict) and hh:
                        fail_patch['historical_helper_diagnostics'] = hh
                except Exception:
                    pass
            if preferred_action == 'phase_d_dat_smoke' and cr is not None:
                try:
                    dss = cr.read_phase_d_dat_smoke_state(self.repo_root)
                    if isinstance(dss, dict) and any(str(dss.get(k, '') or '').strip() for k in (
                            'last_status', 'last_assessment', 'last_report_path', 'last_finished_at_utc',
                            'last_requested_anchor_run_id', 'last_requested_context_run_id',
                            'last_remediation_issue_code')):
                        fail_patch['dat_smoke_diagnostics'] = {
                            'last_requested_anchor_run_id': str(dss.get('last_requested_anchor_run_id', '') or ''),
                            'last_requested_context_run_id': str(dss.get('last_requested_context_run_id', '') or ''),
                            'last_remediation_issue_code': str(dss.get('last_remediation_issue_code', '') or ''),
                            'last_started_at_utc': str(dss.get('last_started_at_utc', '') or ''),
                            'last_finished_at_utc': str(dss.get('last_finished_at_utc', '') or ''),
                            'last_status': str(dss.get('last_status', '') or ''),
                            'last_report_path': str(dss.get('last_report_path', '') or ''),
                            'last_assessment': str(dss.get('last_assessment', '') or ''),
                            'cooldown_until_utc': str(dss.get('cooldown_until_utc', '') or ''),
                        }
                except Exception:
                    pass
            self._patch_post_update_autofollow_state(fail_patch)
        self._log_support_send_event('auto_followthrough_finish', {
            'trigger': str(trigger or 'launcher'),
            'preferred_action': preferred_action,
            'unstable': unstable,
            'started': started,
        })
        return started
    def _normalize_recommendation_for_send_job(self, recommendation):
        rec = recommendation if isinstance(recommendation, dict) else {}
        if not rec:
            return {}
        normalized = {}
        for key in (
                'recommended_action_kind',
                'preferred_when_stable_action_kind',
                'best_now_action_kind',
                'recommended_report_kind',
                'recommendation_source_scope',
                'recommendation_anchor_run_id',
                'recommendation_live_run_id',
                'recommendation_live_run_status',
                'summary_line'):
            if key in rec:
                normalized[key] = rec.get(key)
        preview = rec.get('action_preview', {})
        if isinstance(preview, dict):
            normalized['action_preview'] = dict(preview)
        rem = rec.get('phase_d_remediation', {})
        if isinstance(rem, dict):
            normalized['phase_d_remediation'] = dict(rem)
        return normalized

    def _send_job_anchor_context_issue(self, recommendation):
        rec = recommendation if isinstance(recommendation, dict) else {}
        preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        rem = rec.get('phase_d_remediation', {}) if isinstance(rec.get('phase_d_remediation', {}), dict) else {}
        anchor = str(
            preview.get('anchor_run_id')
            or rec.get('recommendation_anchor_run_id')
            or rec.get('run_id')
            or ''
        ).strip()
        context = str(
            preview.get('phase_d_context_run_id')
            or rec.get('recommendation_live_run_id')
            or anchor
            or ''
        ).strip()
        issue_code = str(
            preview.get('remediation_issue_code')
            or rem.get('issue_code')
            or ''
        ).strip()
        return anchor, context, issue_code

    def _try_enqueue_support_send(self, send_type, recommendation=None, source='cloud_readiness_follow_recommendation', operator_execution_mode='follow_recommendation', priority='high', pause_for_ack=True, installed_version='', recommendation_action_kind=''):
        manager = self._support_send_job_manager()
        quiet_terminal = self._quiet_cloud_autofollow_terminal(source, operator_execution_mode)
        if manager is None:
            if not quiet_terminal:
                print('Background cloud jobs unavailable (support send queue could not be initialized).')
            return {'handled': True, 'ok': False}
        rec = recommendation if isinstance(recommendation, dict) else {}
        anchor, context, issue_code = self._send_job_anchor_context_issue(rec)
        scope = str(rec.get('recommendation_source_scope', '') or 'latest_live_snapshot').strip()
        source_scope_hash = '{0}|{1}|{2}'.format(str(source or ''), str(operator_execution_mode or ''), scope)
        if installed_version or recommendation_action_kind:
            source_scope_hash = '{0}|version={1}|action={2}'.format(
                source_scope_hash,
                str(installed_version or ''),
                str(recommendation_action_kind or ''),
            )
        layer1_blocker = ''
        layer1_readiness = rec.get('layer1_readiness')
        if isinstance(layer1_readiness, dict):
            layer1_blocker = str(layer1_readiness.get('layer1_current_blocker', '') or '').strip()
        if not layer1_blocker:
            layer1_blocker = str(rec.get('layer1_current_blocker', '') or '').strip()
        job_payload = {
            'source': str(source or 'cloud_readiness_follow_recommendation'),
            'priority': str(priority or 'high'),
            'send_type': str(send_type or ''),
            'anchor_run_id': anchor,
            'context_run_id': context,
            'issue_code': issue_code,
            'requested_artifact_scope': scope,
            'source_scope_hash': source_scope_hash,
            'operator_execution_mode': str(operator_execution_mode or ''),
            'installed_version': str(installed_version or ''),
            'recommendation_action_kind': str(recommendation_action_kind or ''),
            'frozen_recommendation': self._normalize_recommendation_for_send_job(rec),
        }
        if str(send_type or '') == 'system_health':
            job_payload['layer1_current_blocker'] = layer1_blocker
        if str(source or '') == 'post_update_cloud_autofollow':
            pst = self._read_post_update_autofollow_state()
            if isinstance(pst, dict):
                job_payload['post_update_autofollow_lab_state'] = {
                    'lab_status': str(pst.get('status', '') or ''),
                    'lab_stage': str(pst.get('stage', '') or ''),
                    'lab_job_id': str(pst.get('job_id', '') or ''),
                    'lab_last_reason': str(pst.get('last_reason', '') or ''),
                    'installed_version': str(pst.get('installed_version', '') or str(installed_version or '')),
                    'lab_state_updated_at_utc': str(pst.get('updated_at_utc', '') or ''),
                    'post_update_evidence_freshness_status': str(pst.get('post_update_evidence_freshness_status', '') or ''),
                    'post_update_fresh_shadow_run_id': str(pst.get('post_update_fresh_shadow_run_id', '') or ''),
                    'post_update_fresh_machine_app_version': str(pst.get('post_update_fresh_machine_app_version', '') or ''),
                    'post_update_freshness_blocking_reason': str(pst.get('post_update_freshness_blocking_reason', '') or ''),
                    'post_update_fresh_pipeline_status': str(pst.get('post_update_fresh_pipeline_status', '') or ''),
                }
        try:
            cr = self._cloud_readiness_service()
            lab_root_snap = cr.resolve_lab_root(self.repo_root)
            if lab_root_snap:
                from MediCafe import evidence_manifest as em

                bk = 'run_evidence_bundle' if str(send_type or '') == 'run_evidence' else 'system_health_pack'
                req_snap = em.build_evidence_request(
                    bk,
                    str(source or ''),
                    str(lab_root_snap),
                    anchor_run_id=str(anchor or ''),
                    active_run_id=str(anchor or ''),
                    recommendation_action_kind=str(
                        rec.get('recommended_action_kind', '') or recommendation_action_kind or ''
                    ),
                    failed_phase=str(rec.get('failed_phase', '') or ''),
                    error_code=str(rec.get('error_code', '') or ''),
                )
                man_snap = em.resolve_evidence_manifest(req_snap)
                job_payload['evidence_manifest_schema_version'] = man_snap.get('schema_version')
                job_payload['bundle_kind'] = bk
                job_payload['failed_phase'] = str(rec.get('failed_phase', '') or '')
                job_payload['error_code'] = str(rec.get('error_code', '') or '')
                miss = man_snap.get('missing_required_evidence')
                job_payload['missing_required_evidence'] = list(miss) if isinstance(miss, list) else []
                oc = man_snap.get('operator_contract')
                job_payload['operator_contract'] = dict(oc) if isinstance(oc, dict) else {}
                job_payload['evidence_manifest_enqueue'] = em.manifest_enqueue_snapshot(man_snap)
        except Exception:
            pass
        if str(send_type or '') == 'system_health':
            dedup_key = manager.policy.dedup_key(job_payload)
            existing = manager.find_existing_job_for_dedup_key(dedup_key)
            if isinstance(existing, dict) and str(existing.get('job_id', '') or '').strip():
                manager.preflight_reap_stale_running_jobs()
                manager._ensure_worker_locked()
                ejid = str(existing.get('job_id', '') or '-')
                ejst = str(existing.get('status', '') or '-')
                if not quiet_terminal:
                    print(
                        'An SHP send is already in flight (job_id={0}, status={1}); releasing the worker now.'.format(
                            ejid, ejst))
                self._last_support_send_enqueue_result = {
                    'accepted': True,
                    'policy_decision': 'promoted_existing',
                    'policy_reason': 'equivalent_shp_already_active',
                    'job_id': ejid,
                    'status': ejst,
                }
                return {'handled': True, 'ok': True}
        result = manager.enqueue(job_payload)
        self._last_support_send_enqueue_result = result if isinstance(result, dict) else {}
        if not bool(result.get('accepted')):
            msg = str(result.get('message', '') or 'Unable to schedule background support send.')
            if not quiet_terminal:
                print(msg)
            return {'handled': True, 'ok': False}
        job_id = str(result.get('job_id', '') or '').strip() or '-'
        if not quiet_terminal:
            print('Background cloud job accepted: {0}'.format(job_id))
            print('Monitor: Troubleshooting -> Cloud Readiness -> Background cloud jobs')
            if pause_for_ack:
                print('Keep MediCafe open until this job finishes.')
        if pause_for_ack and not quiet_terminal:
            try:
                self._prompt('Press Enter to continue...')
            except Exception:
                pass
        return {'handled': True, 'ok': True}

    def _send_bundle_for_operator_type(
            self,
            send_type,
            recommendation=None,
            operator_execution_mode='follow_recommendation',
            source='cloud_readiness_follow_recommendation',
            priority='high',
            pause_for_ack=True,
            send_source_override='',
            installed_version='',
            recommendation_action_kind=''):
        """Queue run_evidence or system_health send; returns True if the job was accepted.

        send_source_override is kept for call-site compatibility; execution uses the job
        worker and frozen recommendation context.
        """
        _ = send_source_override
        st = str(send_type or '').strip()
        quiet_terminal = self._quiet_cloud_autofollow_terminal(source, operator_execution_mode)
        if st == 'run_evidence':
            if not quiet_terminal:
                self._maybe_warn_pipeline_running('Send latest run evidence bundle')
            enqueue = self._try_enqueue_support_send(
                'run_evidence',
                recommendation=recommendation,
                source=source,
                operator_execution_mode=operator_execution_mode,
                priority=priority,
                pause_for_ack=pause_for_ack,
                installed_version=installed_version,
                recommendation_action_kind=recommendation_action_kind,
            )
            return bool(enqueue.get('ok'))
        cr = self._cloud_readiness_service()
        if cr is not None:
            _, warn_msg = cr.check_pipeline_running_for_action(self.repo_root, 'Send System Health Pack')
            if warn_msg and not quiet_terminal:
                print(warn_msg)
        enqueue = self._try_enqueue_support_send(
            'system_health',
            recommendation=recommendation,
            source=source,
            operator_execution_mode=operator_execution_mode,
            priority=priority,
            pause_for_ack=pause_for_ack,
            installed_version=installed_version,
            recommendation_action_kind=recommendation_action_kind,
        )
        return bool(enqueue.get('ok'))

    def _offer_explicit_sends_after_failure(self):
        ans = (self._prompt('Open explicit send and phase tools menu? [y/N]: ') or 'n').strip().lower()
        if ans in ('y', 'yes'):
            self._cloud_other_support_sends_menu()

    def _follow_recommendation_flow(self):
        """Single guided path: send now, defer, why, package override, historical re-eval, or DAT smoke."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        rec = self._operator_support_send_rec()
        if not rec:
            print('Recommendation unavailable.')
            return
        pws = str(rec.get('preferred_when_stable') or rec.get('primary_send') or 'system_health').strip()
        if pws not in ('run_evidence', 'system_health'):
            pws = 'system_health'
        bns = str(rec.get('best_now_send') or pws).strip()
        if bns not in ('run_evidence', 'system_health'):
            bns = pws
        summary = rec.get('summary_line', '')
        if summary:
            print(summary)
        print(_automatic_routing_reason_line(
            rec,
            fallback_reason='Cloud Readiness selected the recommended follow-up',
        ))
        unstable = bool(rec.get('pipeline_running'))
        preferred_action = str(rec.get('preferred_when_stable_action_kind', '') or rec.get('recommended_action_kind', '') or 'send_bundle').strip()
        best_now_action = str(rec.get('best_now_action_kind', '') or preferred_action or 'send_bundle').strip()
        report_kind = str(rec.get('recommended_report_kind', '') or '').strip()
        classes = self._recommended_artifact_classes(rec)

        while True:
            print('')
            if unstable and preferred_action in ('historical_phase_d_reprocess', 'phase_d_dat_smoke', 'phase_d_dat_verification_rerun', 'review_dat_qa_full_block'):
                print('Follow recommendation (pipeline active):')
                if preferred_action == 'review_dat_qa_full_block':
                    print('  1) Remind me when stable (then send {0})'.format(
                        self._recommended_action_label(preferred_action, rec, send_type=pws)))
                else:
                    print('  1) Remind me when stable (then run {0})'.format(
                        self._recommended_action_label(preferred_action, rec, send_type=pws)))
                print('  2) Send best available now ({0})'.format(self._support_send_type_label(bns)))
                print('  3) Show why')
                print('  4) Choose a different package')
                print('  0) Back')
            elif unstable:
                print('Follow recommendation (pipeline active):')
                print('  1) Send best available now ({0})'.format(self._support_send_type_label(bns)))
                print('  2) Remind me when stable (then send preferred after idle)')
                print('  3) Show why')
                print('  4) Choose a different package')
                print('  0) Back')
            elif preferred_action in ('historical_phase_d_reprocess', 'phase_d_dat_smoke', 'phase_d_dat_verification_rerun', 'review_dat_qa_full_block'):
                print('Follow recommendation:')
                if preferred_action == 'review_dat_qa_full_block':
                    print('  1) Send {0}'.format(self._recommended_action_label(preferred_action, rec, send_type=pws)))
                else:
                    print('  1) Run {0}'.format(self._recommended_action_label(preferred_action, rec, send_type=pws)))
                print('  2) Show why')
                print('  3) Choose a different package')
                print('  0) Back')
            else:
                print('Follow recommendation:')
                print('  1) Send now ({0})'.format(self._support_send_type_label(pws)))
                print('  2) Show why')
                print('  3) Choose a different package')
                print('  0) Back')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            if unstable and preferred_action in ('historical_phase_d_reprocess', 'phase_d_dat_smoke', 'phase_d_dat_verification_rerun', 'review_dat_qa_full_block'):
                if choice == '1':
                    if preferred_action == 'phase_d_dat_smoke':
                        if self._queue_phase_d_dat_smoke_deferred(rec, reason='pipeline_running'):
                            print('Saved. Open Cloud Readiness again after the pipeline idles to auto-run DAT smoke.')
                        else:
                            print('Could not save reminder.')
                    else:
                        if cr.write_operator_deferred_support_send(
                                self.repo_root,
                                pws,
                                'pipeline_running',
                                action_kind=preferred_action,
                                artifact_classes=classes,
                                recommended_report_kind=report_kind):
                            if preferred_action == 'review_dat_qa_full_block':
                                print('Saved. Open Cloud Readiness again after the pipeline idles to send the anchored DAT QA full-block run evidence bundle.')
                            elif preferred_action == 'phase_d_dat_verification_rerun':
                                print('Saved. Open Cloud Readiness again after the pipeline idles to run the focused Phase D DAT verification rerun.')
                            else:
                                print('Saved. Open Cloud Readiness again after the pipeline idles to run the historical Phase D re-evaluation.')
                        else:
                            print('Could not save reminder.')
                    return
                if choice == '2':
                    ok_send = self._send_bundle_for_operator_type(bns, recommendation=rec, operator_execution_mode='follow_recommendation')
                    if not ok_send:
                        self._offer_explicit_sends_after_failure()
                    return
                if choice == '3':
                    self._print_operator_send_why()
                    continue
                if choice == '4':
                    self._cloud_other_support_sends_menu()
                    return
                print('Invalid choice.')
                continue
            if unstable:
                if choice == '1':
                    ok_send = self._send_bundle_for_operator_type(bns, recommendation=rec, operator_execution_mode='follow_recommendation')
                    if not ok_send:
                        self._offer_explicit_sends_after_failure()
                    return
                if choice == '2':
                    if cr.write_operator_deferred_support_send(
                            self.repo_root,
                            pws,
                            'pipeline_running',
                            action_kind=preferred_action,
                            artifact_classes=classes,
                            recommended_report_kind=report_kind):
                        print('Saved. Open Cloud Readiness again after the pipeline idles to follow the current recommendation.')
                    else:
                        print('Could not save reminder.')
                    return
                if choice == '3':
                    self._print_operator_send_why()
                    continue
                if choice == '4':
                    self._cloud_other_support_sends_menu()
                    return
                print('Invalid choice.')
                continue
            if preferred_action in ('historical_phase_d_reprocess', 'phase_d_dat_smoke', 'phase_d_dat_verification_rerun', 'review_dat_qa_full_block'):
                if choice == '1':
                    if preferred_action == 'phase_d_dat_smoke':
                        ok_action = self._run_phase_d_dat_smoke_action(
                            rec, announce_prefix='Starting DAT smoke (diagnostic, non-blocking)...'
                        )
                    elif preferred_action == 'phase_d_dat_verification_rerun':
                        ok_action = self._run_phase_d_dat_verification_rerun_action(rec)
                    elif preferred_action == 'review_dat_qa_full_block':
                        ok_action = self._review_dat_qa_full_block_action(rec, operator_execution_mode='follow_recommendation')
                    else:
                        ok_action = self._run_historical_phase_d_reprocess_action(rec, confirm_prompt=False)
                    if ok_action:
                        cr.clear_operator_deferred_support_send(self.repo_root)
                        cr.clear_operator_deferred_phase_d_dat_smoke(self.repo_root)
                    return
                if choice == '2':
                    self._print_operator_send_why()
                    continue
                if choice == '3':
                    self._cloud_other_support_sends_menu()
                    return
                print('Invalid choice.')
                continue
            if choice == '1':
                ok_send = self._send_bundle_for_operator_type(pws, recommendation=rec, operator_execution_mode='follow_recommendation')
                if not ok_send:
                    self._offer_explicit_sends_after_failure()
                return
            if choice == '2':
                self._print_operator_send_why()
                continue
            if choice == '3':
                self._cloud_other_support_sends_menu()
                return
            print('Invalid choice.')

    def _cloud_investigate_patient_data_menu(self):
        while True:
            self._clear_console()
            self._print_legacy_banner('Investigate Patient / Data Issue', width=40)
            self._print_troubleshooting_group('Choose action', [
                '1) Guided completeness check',
                '2) Trace a patient flow',
                '3) DB / audit tools',
            ])
            print('Navigation')
            print(' 0)  Back to Cloud Readiness menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                print('Starting guided patient completeness runbook...')
                self._guided_patient_completeness_runbook()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '2':
                print('Opening patient flow runbook (auto-populated list)...')
                self._open_patient_flow_runbook_for_id()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '3':
                self._cloud_db_inspection_menu()
            else:
                print('Invalid choice.')
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass

    def _open_recommended_lab_report(self):
        """Open the report aligned with the current recommendation."""
        rec = self._operator_support_send_rec()
        report_kind = str(rec.get('recommended_report_kind', '') or '').strip()
        action_kind = str(
            rec.get('best_now_action_kind')
            or rec.get('preferred_when_stable_action_kind')
            or rec.get('recommended_action_kind')
            or ''
        ).strip()
        bns = str(
            rec.get('best_now_send')
            or rec.get('preferred_when_stable')
            or rec.get('primary_send')
            or 'system_health'
        ).strip()
        if bns not in ('run_evidence', 'system_health'):
            bns = 'system_health'
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        if report_kind == 'artifact_triage_pack' or bns == 'run_evidence':
            print('Opening latest artifact triage pack...')
            ok, msg, path = cr.open_latest_artifact_triage_pack(self.repo_root)
            if ok and path:
                print('Opening: {0}'.format(path))
                self._launch_viewer(path)
                return
            if msg:
                print(msg)
            print('Falling back to run artifact index...')
            self._open_latest_run_artifact_index()
            return
        print('Opening latest System Health Pack...')
        self._open_latest_system_health_pack()

    def _cloud_health_reporting_advanced_menu(self):
        """Power-user Health & Reporting actions (triage, explicit open, phase tools, sends)."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Advanced Tools (Health & Reporting)', width=40)
            self._print_troubleshooting_group('Choose action', [
                '1) Run System Health Triage now',
                '2) Open latest System Health Pack',
                '3) Open phase artifact tools',
                '4) Other support sends',
            ])
            print('Navigation')
            print(' 0)  Back to Cloud Readiness menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                print('Running system health triage (audit + pack refresh)...')
                self._run_system_health_triage()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '2':
                print('Opening latest System Health Pack...')
                self._open_latest_system_health_pack()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '3':
                self._cloud_phase_artifacts_menu()
            elif choice == '4':
                self._cloud_other_support_sends_menu()
            else:
                print('Invalid choice.')
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass

    def _try_print_background_support_send_notice(self, passive=False):
        manager = self._support_send_job_manager()
        if manager is None:
            return
        latest = self._latest_finished_background_support_send_job(
            limit=30,
            ensure_liveness=not passive,
        )
        if not isinstance(latest, dict):
            return
        finished = str(latest.get('finished_at_utc', '') or '').strip()
        if not finished:
            return
        state = manager.read_notice_state()
        seen = str(state.get('last_seen_finished_at_utc', '') or '').strip() if isinstance(state, dict) else ''
        if seen == finished:
            return
        print('[NOTICE] Background cloud job {0}: {1}'.format(
            str(latest.get('job_id', '') or '-'),
            str(latest.get('status', '') or '-'),
        ))
        msg = str(latest.get('result_message', '') or '').strip()
        if msg:
            print('         {0}'.format(msg))
        if str(latest.get('policy_reason', '') or '').startswith('stale_') or latest.get('stale_reaped_at_utc'):
            pid = str(latest.get('worker_pid', '') or '').strip()
            reason = str(latest.get('policy_reason', '') or '').strip()
            if pid or reason:
                print('         Cleanup: worker_pid={0} reason={1}'.format(pid or '-', reason or '-'))
            audit = self._latest_support_send_stale_preflight_audit()
            summary = self._support_send_stale_preflight_summary_line(audit)
            if summary:
                print('         {0}'.format(summary))
        manager.write_notice_state({
            'last_seen_finished_at_utc': finished,
            'last_seen_job_id': str(latest.get('job_id', '') or ''),
        })

    def _background_cloud_jobs_menu(self):
        manager = self._support_send_job_manager()
        if manager is None:
            print('Background cloud jobs unavailable.')
            return
        while True:
            self._clear_console()
            self._print_legacy_banner('Background Cloud Jobs', width=40)
            jobs = manager.list_jobs(limit=20)
            audit = {}
            if hasattr(manager, 'read_stale_preflight_audit'):
                try:
                    audit = manager.read_stale_preflight_audit()
                except Exception:
                    audit = {}
            stale_summary = self._support_send_stale_preflight_summary_line(audit)
            if stale_summary:
                print(stale_summary)
                print('Cleanup audit: support_send_stale_preflight_latest.txt / .json')
                print('')
            if not jobs:
                print('No background jobs yet.')
            else:
                print('Recent jobs:')
                print(self._support_send_status_summary_line(jobs))
                idx = 1
                for row in jobs:
                    jid = str(row.get('job_id', '') or '-')
                    status = str(row.get('status', '') or '-')
                    stage = str(row.get('progress_stage', '') or '-')
                    anchor = str(row.get('anchor_run_id', '') or '-')
                    hb = str(row.get('heartbeat_at_utc', '') or '-')
                    print(' {0}) {1} status={2} anchor={3}'.format(idx, jid, status, anchor))
                    print('    operator_status={0}'.format(self._support_send_operator_state(row)))
                    print('    heartbeat={0} stage={1}'.format(hb, stage))
                    msg = str(row.get('result_message', '') or '').strip()
                    if msg:
                        print('    message={0}'.format(msg))
                    idx += 1
            print('')
            print('Actions')
            print(' O<n>) Open job log for item n   (example: O1)')
            print(' D<n>) Open delivery diagnostics path for item n')
            print(' R<n>) Retry item n')
            print(' C<n>) Cancel item n (queued/blocked cancel immediately; running jobs stop at checkpoints)')
            print(' 0) Back')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            if not choice:
                continue
            action = choice[:1].upper()
            idx_raw = choice[1:].strip()
            try:
                idx = int(idx_raw)
            except Exception:
                idx = -1
            if idx < 1 or idx > len(jobs):
                print('Invalid selection.')
                try:
                    self._prompt('Press Enter to continue...')
                except Exception:
                    pass
                continue
            row = jobs[idx - 1]
            job_id = str(row.get('job_id', '') or '').strip()
            if action == 'O':
                log_path = os.path.join(manager.jobs_dir, 'job_{0}.log'.format(job_id))
                if os.path.exists(log_path):
                    print('Opening: {0}'.format(log_path))
                    self._launch_viewer(log_path)
                else:
                    print('Log file not found.')
            elif action == 'D':
                delivery = str(row.get('delivery_status_path', '') or '').strip()
                if not delivery or not os.path.exists(delivery):
                    delivery = str(row.get('delivery_diagnostics_resolved_path', '') or '').strip()
                if (not delivery or not os.path.exists(delivery)) and manager is not None:
                    try:
                        if hasattr(manager, 'resolve_delivery_diagnostics_path'):
                            delivery = str(manager.resolve_delivery_diagnostics_path(row) or '').strip()
                    except Exception:
                        delivery = ''
                if delivery and os.path.exists(delivery):
                    if str(row.get('delivery_status_path', '') or '').strip() != delivery:
                        print('Opening lab delivery status (job-specific path is set after send completes):')
                    print('Opening: {0}'.format(delivery))
                    self._launch_viewer(delivery)
                else:
                    print('Delivery diagnostics path unavailable for this job.')
                    if str(row.get('status', '') or '').strip().lower() == 'queued':
                        print(
                            '  Hint: queued jobs have no per-job delivery log until the worker runs. '
                            'If this job stays queued, try R<n> Retry or send again from the menu to wake the queue.'
                        )
            elif action == 'R':
                res = manager.retry(job_id)
                if bool(res.get('accepted')):
                    print('Retry queued: {0}'.format(str(res.get('job_id', '') or '-')))
                else:
                    print(str(res.get('message', '') or 'Retry rejected.'))
            elif action == 'C':
                if hasattr(manager, 'request_job_shutdown_if_possible'):
                    res = manager.request_job_shutdown_if_possible(
                        job_id,
                        reason='operator_menu_cancel',
                        request_id=self._post_update_shutdown_request_id(),
                    )
                    msg = str(res.get('message', '') or '').strip()
                    if bool(res.get('ok')):
                        print('Cancel result: ok policy={0}{1}'.format(
                            str(res.get('policy_reason', '') or '-'),
                            ' ({0})'.format(msg) if msg else '',
                        ))
                    else:
                        print('Cancel not applied: {0}{1}'.format(
                            str(res.get('policy_reason', '') or '-'),
                            ' ({0})'.format(msg) if msg else '',
                        ))
                elif not hasattr(manager, 'cancel_job_if_possible'):
                    print('Cancel is not available for this build.')
                else:
                    res = manager.cancel_job_if_possible(job_id, reason='operator_menu_cancel')
                    msg = str(res.get('message', '') or '').strip()
                    if bool(res.get('ok')):
                        print('Cancel result: ok policy={0}{1}'.format(
                            str(res.get('policy_reason', '') or '-'),
                            ' ({0})'.format(msg) if msg else '',
                        ))
                    else:
                        print('Cancel not applied: {0}{1}'.format(
                            str(res.get('policy_reason', '') or '-'),
                            ' ({0})'.format(msg) if msg else '',
                        ))
            else:
                print('Invalid action.')
            try:
                self._prompt('Press Enter to continue...')
            except Exception:
                pass

    def _try_prompt_deferred_operator_send(self):
        """One-shot: if a deferred recommended action exists and pipeline is idle, offer to run it."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        intent = cr.read_operator_deferred_support_send(self.repo_root)
        if not intent:
            return
        running, _ = cr.check_pipeline_running_for_action(self.repo_root, 'Deferred recommended action')
        if running:
            return

        rec = self._operator_support_send_rec()
        fresh_send = str(
            (rec.get('preferred_when_stable') or rec.get('primary_send') or 'system_health')).strip()
        if fresh_send not in ('run_evidence', 'system_health'):
            fresh_send = 'system_health'
        stale_send = str(intent.get('primary_send', '') or '').strip()
        if stale_send not in ('run_evidence', 'system_health'):
            stale_send = 'system_health'
        fresh_action = str(
            rec.get('preferred_when_stable_action_kind')
            or rec.get('recommended_action_kind')
            or 'send_bundle'
        ).strip()
        stale_action = str(intent.get('action_kind', '') or 'send_bundle').strip()

        print('')
        print('A deferred support action is pending (pipeline is now idle).')
        if fresh_action != stale_action or fresh_send != stale_send:
            print('When you deferred, the suggested action was: {0}.'.format(
                self._recommended_action_label(stale_action, rec, send_type=stale_send)))
            summ = rec.get('summary_line', '')
            if summ:
                print('Current recommendation: {0}'.format(summ))
            else:
                print('Current recommendation: {0}.'.format(
                    self._recommended_action_label(fresh_action, rec, send_type=fresh_send)))
        else:
            print('Current recommendation: {0}.'.format(
                self._recommended_action_label(fresh_action, rec, send_type=fresh_send)))

        prompt = 'Run the current recommendation now? [Y/n]: '
        if fresh_action == 'send_bundle':
            prompt = 'Send using the current recommendation now? [Y/n]: '
        ans = (self._prompt(prompt) or 'y').strip().lower()
        if ans not in ('y', 'yes', ''):
            print('Skipped. The reminder will stay pending.')
            return

        ok_action = False
        if fresh_action == 'historical_phase_d_reprocess':
            ok_action = self._run_historical_phase_d_reprocess_action(rec, confirm_prompt=False)
        elif fresh_action == 'phase_d_dat_smoke':
            ok_action = self._run_phase_d_dat_smoke_action(
                rec, announce_prefix='Starting deferred DAT smoke (diagnostic, non-blocking)...'
            )
        elif fresh_action == 'phase_d_dat_verification_rerun':
            ok_action = self._run_phase_d_dat_verification_rerun_action(rec)
        elif fresh_action == 'review_dat_qa_full_block':
            ok_action = self._review_dat_qa_full_block_action(
                rec,
                operator_execution_mode='follow_recommendation_deferred',
            )
        elif fresh_send == 'run_evidence':
            self._maybe_warn_pipeline_running('Send latest run evidence bundle')
            ok_action = bool(self._send_bundle_for_operator_type(
                'run_evidence',
                recommendation=rec,
                operator_execution_mode='follow_recommendation_deferred',
                source='deferred_operator_send',
                priority='high',
            ))
        else:
            _, warn_msg = cr.check_pipeline_running_for_action(self.repo_root, 'Send System Health Pack')
            if warn_msg:
                print(warn_msg)
            ok_action = bool(self._send_bundle_for_operator_type(
                'system_health',
                recommendation=rec,
                operator_execution_mode='follow_recommendation_deferred',
                source='deferred_operator_send',
                priority='high',
            ))

        if ok_action:
            cr.clear_operator_deferred_support_send(self.repo_root)
        else:
            print('The deferred action did not complete successfully. The reminder will stay pending.')

    def _send_recommended_support_bundle(self):
        """Compatibility: same as Follow recommendation guided flow."""
        self._follow_recommendation_flow()

    def _cloud_other_support_sends_menu(self):
        """Explicit sends beyond the recommended default."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Other Support Sends', width=40)
            self._print_troubleshooting_group('Choose send', [
                '1) Send latest System Health Pack (broad audit + companions)',
                '2) Send latest run evidence bundle (coherent B..F)',
                '3) Open Cloud Phase Artifact tools (phase-specific evidence sends)',
            ])
            print('Navigation')
            print(' 0)  Back to Cloud Readiness menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                rec = self._operator_support_send_rec()
                cr = self._cloud_readiness_service()
                if cr is not None:
                    _, warn_msg = cr.check_pipeline_running_for_action(
                        self.repo_root, 'Send System Health Pack')
                    if warn_msg:
                        print(warn_msg)
                ok_send = self._send_bundle_for_operator_type(
                    'system_health',
                    recommendation=rec,
                    operator_execution_mode='explicit_send_menu',
                    source='other_support_sends_menu',
                    priority='normal',
                )
                if not ok_send:
                    print('System Health Pack send did not complete successfully.')
            elif choice == '2':
                rec = self._operator_support_send_rec()
                self._maybe_warn_pipeline_running('Send latest run evidence bundle')
                ok_send = self._send_bundle_for_operator_type(
                    'run_evidence',
                    recommendation=rec,
                    operator_execution_mode='explicit_send_menu',
                    source='other_support_sends_menu',
                    priority='normal',
                )
                if not ok_send:
                    print('Run evidence bundle send did not complete successfully.')
            elif choice == '3':
                self._cloud_phase_artifacts_menu()
            else:
                print('Invalid choice.')
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _print_runbook_block(self, heading, runbook_lines):
        """Print runbook lines while preserving headings and numbered actions."""
        if not runbook_lines:
            return
        print('')
        print(heading)
        for line in runbook_lines:
            line_text = str(line or '')
            stripped = line_text.strip()
            if not stripped:
                continue
            if line_text.startswith(' - ') or line_text.startswith('- '):
                print(line_text)
                continue
            is_numbered = False
            for idx in range(1, 10):
                if stripped.startswith('{0})'.format(idx)):
                    is_numbered = True
                    break
            if stripped.endswith(':'):
                print(stripped)
            elif is_numbered:
                print(' {0}'.format(stripped))
            else:
                print(' - {0}'.format(stripped))

    def _guided_patient_completeness_runbook(self):
        """Run guided letter-based patient completeness inspection with embedded runbook output."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        with _console_activity_heartbeat('guided patient completeness: loading options'):
            ok, msg, data = cr.get_guided_patient_completeness_options(self.repo_root)
        if msg:
            print(msg)
        runbook_lines = data.get('runbook_lines', []) if isinstance(data, dict) else []
        actions = data.get('actions', []) if isinstance(data, dict) else []
        if not ok:
            self._print_runbook_block('Guided runbook context:', runbook_lines)
            has_action_section = any(
                str(line or '').strip().lower() == 'what to do now:'
                for line in runbook_lines
            )
            if actions and not has_action_section:
                print('')
                print('What To Do Now:')
                step = 1
                for item in actions:
                    print(' {0}) {1}'.format(step, item))
                    step += 1
            return

        options = data.get('options', []) if isinstance(data, dict) else []
        self._print_runbook_block('Guided runbook context:', runbook_lines)
        if not options:
            print('No guided patient options available.')
            return

        print('')
        print('Guided patient completeness selections:')
        for item in options:
            code = str(item.get('code', '') or '').upper()
            title = item.get('title', '')
            display_id = item.get('display_id', '-')
            risk = item.get('risk_label', 'UNKNOWN')
            reason = item.get('reason', '')
            run_id = item.get('context_run_id', '') or '-'
            print(' {0}) {1}'.format(code, title))
            print('    patient={0} risk={1} run_id={2}'.format(display_id, risk, run_id))
            print('    why={0}'.format(reason))
        print(' 0) Cancel')

        choice = (self._prompt('Select guided option: ') or '').strip().upper()
        if not choice or choice == '0':
            print('Cancelled.')
            return

        print('Generating patient completeness runbook...')
        with _console_activity_heartbeat('guided patient completeness: generating runbook'):
            ok_open, msg_open, path = cr.open_guided_patient_completeness_runbook(
                self.repo_root, choice)
        if msg_open:
            print(msg_open)
        if ok_open and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)



    def _open_patient_flow_runbook_for_id(self):
        """Open patient flow runbook from auto-populated patient references."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        with _console_activity_heartbeat('patient flow runbook: loading references'):
            ok_opts, msg_opts, data_opts = cr.get_patient_flow_reference_options(self.repo_root, limit=12)
        if msg_opts:
            print(msg_opts)
        if not ok_opts or not isinstance(data_opts, dict):
            runbook_lines = data_opts.get('runbook_lines', []) if isinstance(data_opts, dict) else []
            self._print_runbook_block('Patient flow context:', runbook_lines)
            return

        options = data_opts.get('options', []) if isinstance(data_opts.get('options', []), list) else []
        if not options:
            print('No patient flow options available.')
            return

        print('')
        print('Patient flow references (auto-populated):')
        for item in options:
            idx = item.get('index', '?')
            display_id = item.get('display_id', '-')
            ref = item.get('patient_ref', '-')
            risk = item.get('risk_label', 'UNKNOWN')
            score = item.get('risk_score', 0)
            print(' {0}) patient={1} ref={2} risk={3} score={4}'.format(idx, display_id, ref, risk, score))
        print(' 0) Cancel')

        choice = (self._prompt('Select patient flow option: ') or '').strip()
        if not choice or choice == '0':
            print('Cancelled.')
            return

        selected = None
        for item in options:
            if str(item.get('index', '')) == choice:
                selected = item
                break
        if not isinstance(selected, dict):
            print('Invalid selection.')
            return

        patient_ref = str(selected.get('patient_ref', '') or '').strip()
        print('Generating patient flow runbook for {0}...'.format(patient_ref))
        with _console_activity_heartbeat('patient flow runbook: generating'):
            ok, msg, path = cr.open_patient_flow_runbook(self.repo_root, patient_ref)
        self._open_report_result(ok, msg, path, print_msg_always=True)

    def _open_latest_artifact_triage_pack(self):
        """Open latest run-scoped artifact triage pack."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_latest_artifact_triage_pack(self.repo_root)
        self._open_report_result(ok, msg, path)

    def _open_latest_run_artifact_index(self):
        """Open latest run-scoped artifact index."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_latest_run_artifact_index(self.repo_root)
        self._open_report_result(ok, msg, path)

    def _open_run_artifact_index_for_run_id(self, run_id):
        """Open run-scoped artifact index for explicit run ID."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_run_artifact_index_for_run_id(self.repo_root, run_id)
        self._open_report_result(ok, msg, path)

    def _send_latest_run_evidence_bundle(self, send_source='manual_run_evidence_bundle', operator_execution_mode='explicit_send_menu', frozen_recommendation=None):
        """Send latest coherent run evidence bundle across phases B..F. Returns True on send success."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return False
        op_id = self._new_support_send_operation_id('run_evidence')
        t0 = time.time()
        has_recommendation = bool(isinstance(frozen_recommendation, dict) and frozen_recommendation)
        self._log_support_send_event('support_send_start', {
            'operation_id': op_id,
            'send_type': 'run_evidence',
            'phase': 'start',
            'status': 'running',
            'send_source': str(send_source or 'manual_run_evidence_bundle'),
            'operator_execution_mode': str(operator_execution_mode or 'explicit_send_menu'),
            'frozen_recommendation': has_recommendation,
        })
        with _console_activity_heartbeat('sending run evidence bundle: bundle + delivery') as heartbeat:
            ok, msg, data = cr.send_latest_run_evidence_bundle(
                self.repo_root,
                progress_callback=heartbeat.update,
                send_source=send_source,
                operator_execution_mode=operator_execution_mode,
                frozen_recommendation=frozen_recommendation if isinstance(frozen_recommendation, dict) else None,
            )
        elapsed_ms = int(max(0.0, time.time() - t0) * 1000.0)
        self._log_support_send_event('support_send_finish', {
            'operation_id': op_id,
            'send_type': 'run_evidence',
            'phase': 'finish',
            'status': 'ok' if ok else 'failed',
            'duration_ms': elapsed_ms,
            'send_source': str(send_source or 'manual_run_evidence_bundle'),
            'operator_execution_mode': str(operator_execution_mode or 'explicit_send_menu'),
            'frozen_recommendation': has_recommendation,
            'result_message': str(msg or ''),
        })
        if msg:
            print(msg)
        runbook_lines = data.get('runbook_lines', []) if isinstance(data, dict) else []
        if runbook_lines:
            print('')
            print('Bundle runbook:')
            for line in runbook_lines:
                print(' - {0}'.format(line))
        if not ok:
            print('')
            print('Opening report delivery diagnostics to help triage send failure...')
            self._open_report_delivery_status()
        return bool(ok)

    def _cloud_readiness_advanced_menu(self):
        """Cloud Readiness & Advanced submenu with consolidated health-first actions."""
        cr = self._cloud_readiness_service()
        if cr is None:
            try:
                import MediCafe.launcher as _launch_mod
                _already = getattr(_launch_mod, '_cloud_readiness_import_user_message_emitted', False)
            except Exception:
                _already = False
            if not _already:
                print('Cloud Readiness unavailable this session.')
            return
        bootstrap_ok, bootstrap_msg, _ = cr.ensure_lab_ready(
            self.repo_root, self.python_exe, self.environment, self._env_flag_value,
            skip_recent_success_autopipeline=True)
        first_loop = True
        deferred_prompt_done = False
        recommendation_autofollow_done = False
        while True:
            self._clear_console()
            self._print_legacy_banner('Cloud Readiness & Advanced Tools', width=40)
            if first_loop:
                print('Tip: Use 1) Follow recommendation for guided send/defer; 3) Open recommended lab report.')
                print('      S/W/O still work as shortcuts. Use Troubleshooting item 1 only for crash/incident bundles.')
                # Slots 6-8 are intentionally unused in this menu; advanced path is 9 (see group labels above).
                print('Note: choices 6-8 are unused here; use 9 for Advanced tools.')
            if first_loop and bootstrap_msg:
                level = 'WARNING' if not bootstrap_ok else 'INFO'
                print('[{0}] {1}'.format(level, bootstrap_msg))
            first_loop = False
            if not deferred_prompt_done:
                self._try_deferred_phase_d_dat_smoke()
                deferred_prompt_done = True
            self._try_print_background_support_send_notice()
            self._print_background_support_send_status_banner()
            self._print_phase_f_status()
            print('')
            rec = self._operator_support_send_rec()
            if not recommendation_autofollow_done:
                self._maybe_autofollow_cloud_readiness_recommendation(
                    rec,
                    trigger='cloud_readiness_menu_open',
                )
                recommendation_autofollow_done = True
            self._maybe_autorun_phase_d_dat_smoke(rec)
            self._print_health_reporting_status(rec)
            self._print_troubleshooting_group('Health & Reporting', [
                '1)  Follow recommendation...',
                '2)  Investigate patient / data issue...',
                '3)  Open recommended lab report',
                '4)  Background cloud jobs...',
                '5)  Sanitize local JSON ledgers (drop invalid JSONL lines)...',
                '9)  Advanced tools (triage, explicit open, phase tools, sends)...',
                '     (aliases: S=follow  W=why  O=other sends)',
            ])
            self._print_troubleshooting_group('Manual Pipeline Control', [
                'A) Trigger full shadow pipeline (A->F, background)',
                'B) Trigger Phase B discovery (background)',
                'C) Trigger Phase C ingest (background)',
                'D) Trigger Phase D QA (background)',
                'E) Trigger Phase E projection/parity (background)',
                'M) Run DAT smoke (diagnostic; not milestone closure)',
                '     Report: see phase_d_dat_smoke_lab/reports/ after completion (filename from smoke run; check report JSON for paths).',
            ])
            print('Navigation')
            print(' 0)  Back to Troubleshooting menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            choice_u = choice.upper()
            if choice == '0':
                return
            need_pause = False
            if choice_u == 'S' or choice == '1':
                self._follow_recommendation_flow()
            elif choice_u == 'W':
                self._print_operator_send_why()
                need_pause = True
            elif choice_u == 'O':
                self._cloud_other_support_sends_menu()
            elif choice == '2':
                self._cloud_investigate_patient_data_menu()
            elif choice == '3':
                self._open_recommended_lab_report()
                need_pause = True
            elif choice == '4':
                self._background_cloud_jobs_menu()
            elif choice == '5':
                self._sanitize_json_health_ledgers_action()
                need_pause = True
            elif choice_u == 'A':
                print('Triggering full shadow pipeline (non-blocking)...')
                if self._run_shadow_pipeline():
                    self._print_manual_pipeline_runbook('A')
                need_pause = True
            elif choice_u == 'B':
                print('Triggering manual discovery run (non-blocking)...')
                if self._run_phase_b_discovery_manual():
                    self._print_manual_pipeline_runbook('B')
                need_pause = True
            elif choice_u == 'C':
                print('Triggering manual Phase C ingest pass (non-blocking)...')
                if self._run_phase_c_ingest_manual():
                    self._print_manual_pipeline_runbook('C')
                need_pause = True
            elif choice_u == 'D':
                print('Triggering manual Phase D run (non-blocking)...')
                if self._run_phase_d_manual():
                    self._print_manual_pipeline_runbook('D')
                need_pause = True
            elif choice_u == 'E':
                print('Triggering manual Phase E run (non-blocking)...')
                if self._run_phase_e_manual():
                    self._print_manual_pipeline_runbook('E')
                need_pause = True
            elif choice_u == 'M':
                print('Starting DAT smoke (diagnostic, non-blocking)...')
                rec_now = rec if isinstance(rec, dict) else {}
                if str(rec_now.get('recommended_action_kind', '') or '').strip() == 'phase_d_dat_smoke':
                    ok_smoke = self._run_phase_d_dat_smoke_action(rec_now)
                else:
                    ok_smoke = self._run_phase_d_dat_smoke()
                if ok_smoke:
                    print(
                        'DAT smoke state and reports will be recorded under phase_d_dat_smoke_state.json '
                        'and phase_d_dat_smoke_lab/reports/.'
                    )
                need_pause = True
            elif choice == '9':
                self._cloud_health_reporting_advanced_menu()
            else:
                print('Invalid choice.')
                need_pause = True
            if need_pause:
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass

    def _cloud_phase_artifacts_menu(self):
        """Run-centric artifact tools for latest coherent pipeline evidence."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Cloud Phase Artifact Tools', width=40)
            self._print_troubleshooting_group('Run-Centric Artifact Workflow', [
                'A) Open latest Artifact Triage Pack',
                'B) Open latest run artifact index',
                'C) Send latest run evidence bundle',
                'D) Enter run ID and inspect artifact index',
            ])
            self._print_troubleshooting_group('Advanced', [
                'E) Phase-specific deep dive tools...',
                'F) Open report delivery diagnostics',
            ])
            print('Navigation')
            print(' 0)  Back to Cloud Readiness menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            choice_u = choice.upper()
            if choice == '0':
                return
            elif choice_u == 'A':
                print('Opening latest artifact triage pack...')
                self._open_latest_artifact_triage_pack()
            elif choice_u == 'B':
                print('Opening latest run artifact index...')
                self._open_latest_run_artifact_index()
            elif choice_u == 'C':
                rec = self._operator_support_send_rec()
                self._maybe_warn_pipeline_running('Send latest run evidence bundle')
                ok_send = self._send_bundle_for_operator_type(
                    'run_evidence',
                    recommendation=rec,
                    operator_execution_mode='phase_artifact_tools',
                    source='phase_artifact_tools',
                    priority='normal',
                )
                if not ok_send:
                    print('Run evidence bundle send did not complete successfully.')
            elif choice_u == 'D':
                run_id = (self._prompt('Enter run ID to inspect: ') or '').strip()
                if not run_id:
                    print('Cancelled.')
                else:
                    print('Opening artifact index for run {0}...'.format(run_id))
                    self._open_run_artifact_index_for_run_id(run_id)
            elif choice_u == 'E':
                self._cloud_phase_deep_dive_menu()
            elif choice_u == 'F':
                print('Opening report delivery diagnostics...')
                self._open_report_delivery_status()
            else:
                print('Invalid choice.')
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _print_deep_dive_action_runbook(self, action_key):
        """Print short runbook note for deep-dive phase action."""
        key = str(action_key or '').strip()
        print('')
        if key == '1':
            print('Runbook: Use discovery summary to confirm artifact classes/total before downstream phases.')
        elif key == '2':
            print('Runbook: Use manifest location when diagnosing ingest source selection/path drift.')
        elif key == '3':
            print('Runbook: Send B evidence when discovery outputs appear inconsistent or empty.')
        elif key == '4':
            print('Runbook: Use ingest summary to verify inserted/failed/anomaly counters.')
        elif key == '5':
            print('Runbook: Send C evidence when ingest counters or anomalies need external triage.')
        elif key == '6':
            print('Runbook: Use QA summary for pass/reject ratios and cutover quality checks.')
        elif key == '7':
            print('Runbook: Reject samples are for root-causing QA failures, not routine healthy runs.')
        elif key == '8':
            print('Runbook: Send D evidence when reject patterns need support analysis.')
        elif key == '9':
            print('Runbook: Projection summary confirms coverage and parity status.')
        elif key == '10':
            print('Runbook: Deviation samples explain projection/parity drifts in detail.')
        elif key == '11':
            print('Runbook: Send E evidence for parity/coverage escalation cases.')
        elif key == '12':
            print('Runbook: Phase F advanced is for packaging/index rebuild and strict run-id recovery.')

    def _cloud_phase_deep_dive_menu(self):
        """Deep-dive submenu for per-phase summary/sample/evidence files."""
        while True:
            self._clear_console()
            self._print_legacy_banner('Cloud Phase Deep Dive', width=40)
            self._print_troubleshooting_group('Phase B Discovery', [
                '1)  Open latest artifact discovery summary',
                '2)  Open latest manifest location',
                '3)  Send latest discovery evidence bundle',
            ])
            self._print_troubleshooting_group('Phase C Ingest', [
                '4)  Open latest Phase C summary',
                '5)  Send latest Phase C evidence bundle',
            ])
            self._print_troubleshooting_group('Phase D QA', [
                '6)  Open latest Phase D summary',
                '7)  Open latest Phase D reject sample file',
                '8)  Send Phase D evidence bundle',
            ])
            self._print_troubleshooting_group('Phase E Projection', [
                '9)  Open latest Phase E summary',
                '10) Open latest Phase E deviation sample file',
                '11) Send Phase E evidence bundle',
            ])
            self._print_troubleshooting_group('Phase F', [
                '12) Phase F advanced tools...',
            ])
            print('Navigation')
            print(' 0)  Back to Artifact Tools')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest artifact discovery summary...')
                self._open_phase_b_summary()
            elif choice == '2':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest manifest location...')
                self._open_phase_b_manifest_location()
            elif choice == '3':
                self._print_deep_dive_action_runbook(choice)
                self._maybe_warn_pipeline_running('Send Phase B evidence')
                print('Sending latest discovery evidence via support bundle...')
                self._send_phase_b_evidence()
            elif choice == '4':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest Phase C summary...')
                self._open_phase_c_summary()
            elif choice == '5':
                self._print_deep_dive_action_runbook(choice)
                self._maybe_warn_pipeline_running('Send Phase C evidence')
                print('Sending latest Phase C evidence via support bundle...')
                self._send_phase_c_evidence()
            elif choice == '6':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest Phase D summary...')
                self._open_phase_d_summary()
            elif choice == '7':
                self._print_deep_dive_action_runbook(choice)
                print('Opening reject sample file...')
                self._open_phase_d_reject_sample()
            elif choice == '8':
                self._print_deep_dive_action_runbook(choice)
                self._maybe_warn_pipeline_running('Send Phase D evidence')
                print('Sending Phase D evidence via support bundle...')
                self._send_phase_d_evidence()
            elif choice == '9':
                self._print_deep_dive_action_runbook(choice)
                print('Opening latest Phase E summary...')
                self._open_phase_e_summary()
            elif choice == '10':
                self._print_deep_dive_action_runbook(choice)
                print('Opening deviation sample file...')
                self._open_phase_e_deviation_samples()
            elif choice == '11':
                self._print_deep_dive_action_runbook(choice)
                self._maybe_warn_pipeline_running('Send Phase E evidence')
                print('Sending Phase E evidence via support bundle...')
                self._send_phase_e_evidence()
            elif choice == '12':
                self._print_deep_dive_action_runbook(choice)
                self._phase_f_advanced_menu()
            else:
                print('Invalid choice.')
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _phase_f_advanced_menu(self):
        """Phase F advanced submenu."""
        _RUN_ID_RE = re.compile(r'^\d{8}-\d{6}-[a-f0-9]{8}$')
        while True:
            self._clear_console()
            self._print_legacy_banner('Phase F Advanced Tools', width=40)
            print('')
            print('Phase F Advanced')
            print(' 1) Rebuild Shadow Health report (latest)')
            print(' 2) Rebuild Shadow Health report for run ID (strict)')
            suggested = self._get_last_shadow_pipeline_run_id()
            if suggested:
                print('     (suggested: {0})'.format(suggested))
            print(' 3) Open Phase F Evidence Index')
            print(' 0) Back')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '0':
                return
            elif choice == '1':
                self._maybe_warn_pipeline_running('Rebuild Phase F')
                print('Triggering manual Phase F packaging pass...')
                self._run_phase_f_manual()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '2':
                self._maybe_warn_pipeline_running('Rebuild Phase F (strict)')
                prompt_text = 'Enter run ID [YYYYMMDD-HHMMSS-<8hex>]'
                if suggested:
                    prompt_text += ' (suggested: {0})'.format(suggested)
                prompt_text += ': '
                rid = (self._prompt(prompt_text) or '').strip()
                if not rid:
                    print('Cancelled.')
                    try:
                        self._prompt('Press Enter to return to menu...')
                    except Exception:
                        pass
                    continue
                if not _RUN_ID_RE.match(rid):
                    confirm = (self._prompt(
                        'Format may be non-standard; proceed anyway? [y/N]: ') or '').strip().lower()
                    if confirm not in ('y', 'yes'):
                        print('Cancelled.')
                        try:
                            self._prompt('Press Enter to return to menu...')
                        except Exception:
                            pass
                        continue
                print('Triggering Phase F packaging for run {0}...'.format(rid))
                cr = self._cloud_readiness_service()
                if cr is not None:
                    ok, msg, _ = cr.run_phase_f_manual_for_run_id(
                        self.repo_root, self.python_exe, self.environment, rid)
                    if ok:
                        print('Phase F packaging started in background.')
                    elif msg:
                        print(msg)
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '3':
                print('Opening latest Phase F evidence index...')
                self._open_phase_f_evidence_index()
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            else:
                print('Invalid choice.')

    def _get_last_shadow_pipeline_run_id(self):
        """Return last_shadow_pipeline_run_id from diagnostics_state.json or empty string."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return ''
        lab_root = cr.resolve_lab_root(self.repo_root)
        state_path = os.path.join(lab_root, 'diagnostics_state.json')
        if not os.path.exists(state_path):
            return ''
        try:
            with open(state_path, 'r', encoding='utf-8') as f:
                state = json.load(f)
            return state.get('last_shadow_pipeline_run_id', '') or ''
        except (IOError, OSError, ValueError):
            return ''

    def _maybe_warn_pipeline_running(self, action_name):
        """Print warning if pipeline is running."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        running, warn_msg = cr.check_pipeline_running_for_action(
            self.repo_root, action_name)
        if warn_msg:
            print(warn_msg)

    def _run_phase_f_manual(self):
        """Trigger manual Phase F packaging pass (non-blocking)."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, _ = cr.run_phase_f_manual(
            self.repo_root, self.python_exe, self.environment)
        if ok:
            print('Phase F packaging started in background.')
        elif msg:
            print(msg)

    def _open_phase_f_evidence_index(self):
        """View latest Phase F evidence index."""
        cr = self._cloud_readiness_service()
        if cr is None:
            return
        ok, msg, path = cr.open_phase_f_evidence_index(self.repo_root)
        self._open_report_result(ok, msg, path)
