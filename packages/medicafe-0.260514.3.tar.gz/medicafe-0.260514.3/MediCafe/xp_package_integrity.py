#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""XP packaged-file integrity checks.

The XP runtime executes several ``scripts/unified_model`` files as plain files
installed by ``setup.py`` data_files.  Package version checks alone do not prove
those files were updated, so this module verifies their hashes against the
manifest generated at build time.
"""
from __future__ import print_function

import hashlib
import json
import os
import sys


MANIFEST_BASENAME = "xp_packaged_file_manifest.json"
MANIFEST_SCHEMA_VERSION = 1

XP_CRITICAL_RELATIVE_FILES = (
    "scripts/unified_model/discover_artifacts.py",
    "scripts/unified_model/ingest_from_manifest.py",
    "scripts/unified_model/lab_lock.py",
    "scripts/unified_model/dat_payer_resolution.py",
    "scripts/unified_model/dat_shape_contract.py",
    "scripts/unified_model/patient_field_mapper.py",
    "scripts/unified_model/phase_c_common.py",
    "scripts/unified_model/phase_c_current_attempt.py",
    "scripts/unified_model/phase_c_self_heal_state.py",
    "scripts/unified_model/phase_f_common.py",
    "scripts/unified_model/run_qa_canonical.py",
    "scripts/unified_model/run_shadow_pipeline.py",
    "scripts/unified_model/run_tracked_diagnostic.py",
    "scripts/unified_model/run_x12_cpt_dx_association.py",
    "scripts/unified_model/run_x12_minutes_charge_association.py",
    "scripts/unified_model/x12_analytics_common.py",
    "scripts/unified_model/xp_phase_smoke.py",
    "scripts/unified_model/package_shadow_run_report.py",
)

XP_CRITICAL_MEDICAFE_MODULE_FILES = (
    "MediCafe/cloud_readiness.py",
    "MediCafe/cloud_readiness_patient_tools.py",
    "MediCafe/cloud_readiness_recommendations.py",
    "MediCafe/diagnostic_attempts.py",
    "MediCafe/evidence_manifest.py",
    "MediCafe/launcher_cloud_readiness_mixin.py",
    "MediCafe/layer1_runbook_model.py",
    "MediCafe/layer1_readiness_model.py",
    "MediCafe/phase_d_developer_unblock.py",
)

XP_CRITICAL_MEDIBOT_MODULE_FILES = (
    "MediBot/MediBot_docx_decoder.py",
)

XP_PACKAGE_MODULE_PREFIXES = (
    "MediCafe/",
    "MediBot/",
    "MediLink/",
    "xp_client/",
)


def _norm_rel(path):
    return str(path or "").replace("\\", "/").strip().lstrip("/")


def _discover_unified_model_py_files(project_root):
    root = os.path.join(project_root, "scripts", "unified_model")
    if not os.path.isdir(root):
        return []

    out = []
    for current_root, dirnames, filenames in os.walk(root):
        if "__pycache__" in dirnames:
            dirnames.remove("__pycache__")
        for name in filenames:
            if not name.endswith(".py"):
                continue
            full_path = os.path.join(current_root, name)
            try:
                rel_path = os.path.relpath(full_path, project_root)
            except Exception:
                continue
            out.append(_norm_rel(rel_path))
    return sorted(set(out))


def default_expected_files(project_root=None):
    files = set(XP_CRITICAL_RELATIVE_FILES)
    files.update(XP_CRITICAL_MEDICAFE_MODULE_FILES)
    files.update(XP_CRITICAL_MEDIBOT_MODULE_FILES)
    if project_root:
        files.update(_discover_unified_model_py_files(project_root))
    return sorted(files)


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _file_record(root, rel_path):
    rel_path = _norm_rel(rel_path)
    path = os.path.join(root, rel_path.replace("/", os.sep))
    if not os.path.isfile(path):
        return {
            "path": rel_path,
            "present": False,
            "size_bytes": 0,
            "sha256": "",
            "sha256_prefix16": "",
        }
    try:
        sha = _sha256_file(path)
        size = int(os.path.getsize(path))
    except Exception:
        sha = ""
        size = 0
    return {
        "path": rel_path,
        "present": bool(sha),
        "size_bytes": size,
        "sha256": sha,
        "sha256_prefix16": sha[:16],
    }


def build_expected_manifest(project_root, version="", files=None):
    records = []
    if files is None:
        files = default_expected_files(project_root)
    for rel_path in files:
        records.append(_file_record(project_root, rel_path))
    return {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "package_name": "medicafe",
        "version": str(version or ""),
        "files": records,
    }


def write_expected_manifest(project_root, version="", output_path=None):
    manifest = build_expected_manifest(project_root, version=version)
    missing = [r.get("path") for r in manifest.get("files", []) if not r.get("present")]
    if missing:
        raise RuntimeError("Cannot write XP package manifest; missing critical files: {0}".format(", ".join(missing)))
    if output_path is None:
        output_path = os.path.join(project_root, "MediCafe", MANIFEST_BASENAME)
    with open(output_path, "w") as fh:
        json.dump(manifest, fh, indent=2, sort_keys=True)
        fh.write("\n")
    return manifest


def expected_manifest_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), MANIFEST_BASENAME)


def load_expected_manifest(path=None):
    path = path or expected_manifest_path()
    try:
        with open(path, "r") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def _user_base_root():
    """Return PEP 370 user base directory (used by pip install --user data_files)."""
    try:
        import site
        ub = getattr(site, "USER_BASE", None)
        if not ub and hasattr(site, "getuserbase"):
            try:
                ub = site.getuserbase()
            except Exception:
                ub = None
        if ub:
            return os.path.abspath(ub)
    except Exception:
        pass
    return None


def _prefer_user_scheme_for_data_files():
    """
    True when this MediCafe install loads from the user site-packages tree.

    Pip installs ``data_files`` under USER_BASE (not sys.prefix) for ``pip install
    --user``. In that case we must resolve scripts against USER_BASE *before*
    sys.prefix so we hash the files that accompany this wheel, not a stale
    system-wide tree left under prefix.
    """
    try:
        import site
        mf = os.path.normcase(os.path.abspath(expected_manifest_path()))
        us = site.getusersitepackages()
        if not us:
            return False
        us_abs = os.path.normcase(os.path.abspath(us))
        return bool(mf.startswith(us_abs))
    except Exception:
        return False


def _candidate_install_roots(explicit_root=None, include_package_parent=False):
    """
    Search roots for setuptools ``data_files`` (scripts/unified_model/...).

    Include USER_BASE because ``pip install --user`` places those files outside
    sys.prefix. When the embedded manifest is loaded from user site-packages,
    check USER_BASE before prefix so a leftover prefix copy does not cause false
    mismatches.
    """
    seen = set()
    candidates = []

    def add_unique(root):
        if not root:
            return
        try:
            root = os.path.abspath(root)
        except Exception:
            return
        key = os.path.normcase(root)
        if key not in seen:
            seen.add(key)
            candidates.append(root)

    ub = _user_base_root()
    prefer_user = _prefer_user_scheme_for_data_files()
    try:
        package_parent = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    except Exception:
        package_parent = None

    if explicit_root:
        add_unique(explicit_root)

    if include_package_parent:
        add_unique(package_parent)

    prefix_roots = [sys.prefix, getattr(sys, "exec_prefix", None)]
    if prefer_user:
        if ub:
            add_unique(ub)
        for root in prefix_roots:
            add_unique(root)
    else:
        for root in prefix_roots:
            add_unique(root)
        if ub:
            add_unique(ub)

    return candidates


def _resolve_installed_path(rel_path, install_root=None):
    rel_path = _norm_rel(rel_path)
    include_package_parent = rel_path.startswith(XP_PACKAGE_MODULE_PREFIXES)
    for root in _candidate_install_roots(install_root, include_package_parent=include_package_parent):
        path = os.path.join(root, rel_path.replace("/", os.sep))
        if os.path.isfile(path):
            return path
    first = _candidate_install_roots(install_root, include_package_parent=include_package_parent)
    root = first[0] if first else os.getcwd()
    return os.path.join(root, rel_path.replace("/", os.sep))


def verify_installed_files(install_root=None, expected_manifest=None):
    manifest = expected_manifest or load_expected_manifest()
    files = manifest.get("files") if isinstance(manifest, dict) else None
    result = {
        "ok": False,
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "expected_manifest_path": expected_manifest_path(),
        "expected_version": str(manifest.get("version", "") if isinstance(manifest, dict) else ""),
        "install_root": os.path.abspath(install_root) if install_root else "",
        "verified_count": 0,
        "missing": [],
        "mismatched": [],
        "checked_files": [],
        "error": "",
    }
    if not isinstance(files, list) or not files:
        result["error"] = "expected_manifest_missing_or_empty"
        return result

    for expected in files:
        rel_path = _norm_rel(expected.get("path") if isinstance(expected, dict) else "")
        if not rel_path:
            continue
        path = _resolve_installed_path(rel_path, install_root=install_root)
        actual = _file_record(os.path.dirname(path), os.path.basename(path))
        actual["path"] = rel_path
        actual["installed_path"] = path
        expected_sha = str(expected.get("sha256") or "")
        expected_size = int(expected.get("size_bytes") or 0)
        actual_sha = str(actual.get("sha256") or "")
        actual_size = int(actual.get("size_bytes") or 0)
        if not actual.get("present"):
            result["missing"].append(rel_path)
        elif expected_sha and actual_sha != expected_sha:
            result["mismatched"].append({
                "path": rel_path,
                "expected_sha256_prefix16": expected_sha[:16],
                "actual_sha256_prefix16": actual_sha[:16],
                "expected_size_bytes": expected_size,
                "actual_size_bytes": actual_size,
                "installed_path": path,
            })
        else:
            result["verified_count"] += 1
        result["checked_files"].append(actual)

    result["ok"] = not result["missing"] and not result["mismatched"] and not result["error"]
    return result


def verify_installed_files_cli(argv=None):
    argv = argv or sys.argv[1:]
    install_root = argv[0] if argv else None
    result = verify_installed_files(install_root=install_root)
    print(json.dumps(result, sort_keys=True))
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    sys.exit(verify_installed_files_cli())
