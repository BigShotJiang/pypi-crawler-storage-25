#MediBot.py
# pyright: reportOptionalMemberAccess=false, reportOptionalCall=false, reportGeneralTypeIssues=false, reportAttributeAccessIssue=false, reportIndexIssue=false, reportUnboundVariable=false
import os, sys  # Must be imported first

if sys.version_info[0] >= 3:
    raw_input = input

# Add parent directory of the project to the Python path
project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_dir not in sys.path:
    # Ensure project root is at the front of sys.path to avoid site-packages shadowing
    sys.path.insert(0, project_dir)
else:
    # Ensure it's at the front to avoid site-packages shadowing even if already present
    try:
        if sys.path[0] != project_dir:
            sys.path.remove(project_dir)
            sys.path.insert(0, project_dir)
    except Exception:
        pass

import subprocess, tempfile, traceback, re, time, threading, json, io
try:
    import msvcrt  # Windows-specific module
except ImportError:
    msvcrt = None  # Not available on non-Windows systems
from collections import OrderedDict
from datetime import datetime # Added for primary surgery date logic
import MediBot_Notepad_Utils  # For generating notepad files
try:
    # Python 3.4.4 on XP does not have typing enhancements; avoid heavy typing usage
    from collections import namedtuple
except Exception:
    namedtuple = None

# Error reporting imports for automated crash reporting
try:
    from MediCafe.error_reporter import capture_unhandled_traceback, submit_support_bundle_email
except ImportError:
    capture_unhandled_traceback = None
    submit_support_bundle_email = None

# ============================================================================
# MINIMAL PROTECTION: Import State Validation
# ============================================================================

def validate_critical_imports():
    """Validate that critical imports are in expected state before proceeding"""
    critical_modules = {
        'MediBot_Preprocessor': None,
        'MediBot_Preprocessor_lib': None,
        'MediBot_UI': None,
        'MediBot_Crosswalk_Library': None
    }
    
    # Test imports and capture state
    try:
        from MediCafe.core_utils import import_medibot_module_with_debug
        
        for module_name in critical_modules.keys():
            try:
                module = import_medibot_module_with_debug(module_name)
                critical_modules[module_name] = module
            except Exception as e:
                print("  ERROR: {} import failed with exception: {}".format(module_name, e))
                critical_modules[module_name] = None
    except Exception as e:
        print("CRITICAL: Failed to import core utilities: {}".format(e))
        return False, critical_modules
    
    # Check for None imports (the specific failure pattern)
    failed_imports = []
    for module_name, module in critical_modules.items():
        if module is None:
            failed_imports.append(module_name)
    
    if failed_imports:
        print("CRITICAL: Import failures detected:")
        for failed in failed_imports:
            print("  - {}: Import returned None".format(failed))
        return False, critical_modules

    total_count = len(critical_modules)
    try:
        MediLink_ConfigLoader.log(
            "Import check: {}/{} critical modules loaded".format(total_count, total_count),
            level="INFO"
        )
    except Exception:
        pass
    return True, critical_modules

# Use core utilities for standardized imports
from MediCafe.core_utils import (
    import_medibot_module_with_debug, 
    get_config_loader_with_fallback,
    get_api_client_factory
)

# Initialize configuration loader with fallback
MediLink_ConfigLoader = get_config_loader_with_fallback()

# Import MediBot modules using centralized import functions with debugging
MediBot_dataformat_library = import_medibot_module_with_debug('MediBot_dataformat_library')
MediBot_Preprocessor = import_medibot_module_with_debug('MediBot_Preprocessor')
MediBot_Preprocessor_lib = import_medibot_module_with_debug('MediBot_Preprocessor_lib')
try:
    from MediBot.MediBot_docx_index import (
        load_docx_schedule_index,
        get_schedules_for_dates,
        normalize_date_value,
    )
except Exception:
    load_docx_schedule_index = None
    get_schedules_for_dates = None
    normalize_date_value = None
try:
    from MediBot.MediBot_ServiceLineInput import calculate_service_line_amount_result
except Exception:
    try:
        from MediBot_ServiceLineInput import calculate_service_line_amount_result
    except Exception:
        try:
            from MediBot.MediBot_OptionA_Charge import calculate_option_a_charge_result
        except Exception:
            try:
                from MediBot_OptionA_Charge import calculate_option_a_charge_result
            except Exception:
                calculate_option_a_charge_result = None
            calculate_service_line_amount_result = calculate_option_a_charge_result
        else:
            calculate_service_line_amount_result = calculate_option_a_charge_result

calculate_option_a_charge_result = calculate_service_line_amount_result

try:
    from MediCafe import service_line_input_model as ServiceLineInputModel
except Exception:
    ServiceLineInputModel = None

# Import UI components with function extraction
MediBot_UI = import_medibot_module_with_debug('MediBot_UI')
if MediBot_UI:
    app_control = getattr(MediBot_UI, 'app_control', None)
    manage_script_pause = getattr(MediBot_UI, 'manage_script_pause', None)
    user_interaction = getattr(MediBot_UI, 'user_interaction', None)
    get_app_control = getattr(MediBot_UI, '_get_app_control', None)
else:
    app_control = None
    manage_script_pause = None
    user_interaction = None
    get_app_control = None


def _ac():
    if not MediBot_UI:
        return None
    try:
        return get_app_control() if get_app_control else getattr(MediBot_UI, 'app_control', None)
    except Exception:
        return getattr(MediBot_UI, 'app_control', None)


def _run_with_stage_heartbeat(stage_label, work_fn, warn_after_seconds=5.0, heartbeat_seconds=2.0):
    """Run a stage with delayed mandatory heartbeat for long operations.

    Silent for quick stages (< warn_after_seconds). For longer stages, prints
    progress heartbeat until completion.
    """
    started_at = time.time()
    stop_event = threading.Event()
    heartbeat_state = {'started': False}

    def _heartbeat_loop():
        while not stop_event.wait(0.25):
            elapsed = time.time() - started_at
            if elapsed < warn_after_seconds:
                continue
            if not heartbeat_state['started']:
                heartbeat_state['started'] = True
                print("[WORKING] {} (>{:.0f}s)".format(stage_label, warn_after_seconds))
                print("          Still running... elapsed {:.1f}s".format(elapsed))
                continue
            if stop_event.wait(heartbeat_seconds):
                break
            elapsed = time.time() - started_at
            print("          Still running... elapsed {:.1f}s ({})".format(elapsed, stage_label))

    worker = threading.Thread(target=_heartbeat_loop)
    worker.daemon = True
    worker.start()
    try:
        result = work_fn()
    finally:
        stop_event.set()
        try:
            worker.join(0.5)
        except Exception:
            pass
    elapsed = time.time() - started_at
    if heartbeat_state['started']:
        print("[DONE] {} ({:.1f}s)".format(stage_label, elapsed))
    return result

# Import crosswalk library
MediBot_Crosswalk_Library = import_medibot_module_with_debug('MediBot_Crosswalk_Library')
if MediBot_Crosswalk_Library:
    crosswalk_update = getattr(MediBot_Crosswalk_Library, 'crosswalk_update', None)
else:
    crosswalk_update = None

# Initialize API client variables
api_client = None
factory = None

try:
    # Try to get API client factory
    factory = get_api_client_factory()
    if factory:
        api_client = factory.get_shared_client()  # Use shared client for token caching benefits
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log("MediBot using API Factory with shared client", level="INFO")
except ImportError as e:
    # Fallback to basic API client
    try:
        from MediCafe.core_utils import get_api_client
        api_client = get_api_client()
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log("MediBot using fallback API client", level="WARNING")
    except ImportError as e2:
        # Make API client optional - don't log warning for now
        pass

# Buffer for startup warnings/errors so we can re-display them after clearing the console
STARTUP_NOTICES = []

# Flag to track non-normal startup conditions
_non_normal_startup = False

def mark_non_normal_startup():
    """Mark that a non-normal startup condition was detected."""
    global _non_normal_startup
    _non_normal_startup = True

def _record_startup_notice(level, message):
    """Record a startup notice, log it, and print it immediately.
    Stored notices will be reprinted after the screen is cleared.
    """
    try:
        STARTUP_NOTICES.append((level, message))
    except Exception:
        pass
    try:
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log(message, level=level)
    except Exception:
        pass
    try:
        print(message)
    except Exception:
        pass

def record_startup_warning(message):
    """Record a startup warning."""
    _record_startup_notice('WARNING', message)
    mark_non_normal_startup()

def record_startup_error(message):
    """Record a startup error."""
    _record_startup_notice('ERROR', message)
    mark_non_normal_startup()

def _preprocessed_csv_has_rows(csv_data):
    """Return True when there is at least one row available for intake."""
    return bool(csv_data)

def _empty_preprocessed_csv_shape_blocked():
    """Return True when empty preprocessing was caused by the intake shape guard."""
    try:
        if MediBot_Preprocessor_lib and hasattr(MediBot_Preprocessor_lib, 'get_last_csv_preprocess_snapshot'):
            snapshot = MediBot_Preprocessor_lib.get_last_csv_preprocess_snapshot()
            return bool(snapshot and snapshot.get('stage') == 'intake_blocked_missing_patient_id_header')
    except Exception:
        pass
    return False

def _handle_empty_preprocessed_csv(csv_data):
    """Report an empty post-filter CSV and tell the caller whether to stop."""
    if _preprocessed_csv_has_rows(csv_data):
        return False

    summary_text = None
    shape_blocker_text = None
    try:
        if MediBot_Preprocessor_lib and hasattr(MediBot_Preprocessor_lib, 'get_last_filter_rows_summary'):
            summary = MediBot_Preprocessor_lib.get_last_filter_rows_summary()
            if summary and hasattr(MediBot_Preprocessor_lib, 'format_filter_rows_summary'):
                summary_text = MediBot_Preprocessor_lib.format_filter_rows_summary(summary)
    except Exception:
        summary_text = None
    try:
        if MediBot_Preprocessor_lib and hasattr(MediBot_Preprocessor_lib, 'get_last_csv_preprocess_snapshot'):
            snapshot = MediBot_Preprocessor_lib.get_last_csv_preprocess_snapshot()
            if snapshot and snapshot.get('stage') == 'intake_blocked_missing_patient_id_header':
                expected = snapshot.get('expected_patient_id_headers') or []
                headers = snapshot.get('cleaned_headers') or []
                shape_blocker_text = (
                    "CSV shape blocker: expected MediBot intake header 'Patient ID' "
                    "(accepted compatibility headers: {0}); "
                    "found headers (first {1}): {2}. "
                ).format(
                    expected,
                    min(len(headers), 12),
                    ", ".join([str(h) for h in headers[:12]]) if headers else "<none>",
                )
    except Exception:
        shape_blocker_text = None

    message = (
        "No eligible patient rows remain after CSV preprocessing. "
        "Rows without Patient ID values and excluded insurance rows "
        "(AETNA, AETNA MEDICARE, HUMANA MED HMO) are skipped. "
        "{}"
        "{}"
        "Please review the source CSV if patients were expected."
    ).format(
        shape_blocker_text or "",
        "Filter summary: {}. ".format(summary_text) if summary_text else ""
    )
    try:
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log(message, level="WARNING")
    except Exception:
        pass
    try:
        print(message)
    except Exception:
        pass
    return True

def identify_field(header, field_mapping):
    for medisoft_field, patterns in field_mapping.items():
        for pattern in patterns:
            if re.search(pattern, header, re.IGNORECASE):
                return medisoft_field
    return None

    # Add this print to a function that is calling identify_field
    #print("Warning: No matching field found for CSV header '{}'".format(header))

def create_patient_entries_from_row(row, reverse_mapping):
    """
    Helper function to create patient entries from a row with surgery date handling.
    
    Args:
        row: The CSV row containing patient data
        reverse_mapping: The reverse mapping for field lookups
        
    Returns:
        list: List of tuples (surgery_date, patient_name, patient_id, diagnosis_code, row)
    """
    patient_id = row.get(reverse_mapping['Patient ID #2'])
    patient_name = row.get(reverse_mapping['Patient Name'])
    
    # Get all surgery dates for this patient
    all_surgery_dates = row.get('_all_surgery_dates', [row.get('Surgery Date')])
    surgery_date_to_diagnosis = row.get('_surgery_date_to_diagnosis', {})
    
    patient_entries = []
    
    # Sort surgery dates chronologically to ensure proper ordering
    sorted_surgery_dates = []
    for surgery_date in all_surgery_dates:
        try:
            if hasattr(surgery_date, 'strftime'):
                # Already a datetime object
                sorted_surgery_dates.append(surgery_date)
            elif isinstance(surgery_date, str):
                # Convert string to datetime for sorting
                surgery_date_dt = datetime.strptime(surgery_date, '%m-%d-%Y')
                sorted_surgery_dates.append(surgery_date_dt)
            else:
                # Fallback - use as is
                sorted_surgery_dates.append(surgery_date)
        except (ValueError, TypeError):
            # If parsing fails, use the original value
            sorted_surgery_dates.append(surgery_date)
    
    # Sort the dates chronologically
    sorted_surgery_dates.sort()
    
    # Create entries for each surgery date in chronological order
    # The enhanced table display will group by patient_id and show dashed lines for secondary dates
    for surgery_date in sorted_surgery_dates:
        try:
            if hasattr(surgery_date, 'strftime'):
                surgery_date_str = surgery_date.strftime('%m-%d-%Y')
            elif isinstance(surgery_date, str):
                surgery_date_str = surgery_date
            else:
                surgery_date_str = str(surgery_date)
        except Exception:
            surgery_date_str = str(surgery_date)
        
        # Get the diagnosis code for this surgery date
        diagnosis_code = surgery_date_to_diagnosis.get(surgery_date_str, 'N/A')
        
        # Add entry for this surgery date
        patient_entries.append((surgery_date, patient_name, patient_id, diagnosis_code, row))
    
    return patient_entries


def build_option_a_preview_session_patient_info_from_csv_rows(csv_data, reverse_mapping):
    """
    Build the broad in-memory session scope used by Service Line Input.

    This intentionally runs before Medicare/private and existing/new filters
    narrow the AHK intake path. Service Line Input should mirror the printed DOCX for
    the current CSV session while using CSV rows only as a name/payload lookup.
    """
    patient_info = []
    for row in csv_data or []:
        if not isinstance(row, dict):
            continue
        try:
            patient_info.extend(create_patient_entries_from_row(row, reverse_mapping))
        except Exception:
            continue
    return patient_info


def build_service_line_input_session_patient_info_from_csv_rows(csv_data, reverse_mapping):
    return build_option_a_preview_session_patient_info_from_csv_rows(csv_data, reverse_mapping)


def _normalize_option_a_preview_date(value):
    if ServiceLineInputModel is not None:
        try:
            normalized = ServiceLineInputModel.normalize_dos_string(value)
            if normalized:
                return normalized
        except Exception:
            pass
    if normalize_date_value is not None:
        try:
            return normalize_date_value(value)
        except Exception:
            pass
    if value is None:
        return None
    if hasattr(value, 'strftime'):
        try:
            return value.strftime('%m-%d-%Y')
        except Exception:
            return str(value)
    text = str(value).strip()
    if not text:
        return None
    for fmt in ('%m-%d-%Y', '%m/%d/%Y', '%Y-%m-%d', '%Y/%m/%d'):
        try:
            return datetime.strptime(text, fmt).strftime('%m-%d-%Y')
        except Exception:
            pass
    return text


def _option_a_preview_local_storage_path(config):
    try:
        local_storage_path = config.get('MediLink_Config', {}).get('local_storage_path')
    except Exception:
        local_storage_path = None
    if local_storage_path:
        return local_storage_path
    try:
        return config.get('local_storage_path')
    except Exception:
        return None


def _option_a_preview_docx_auto_status(diagnosis):
    text = str(diagnosis or '').strip().lower()
    if text in ('', 'unknown', 'not found', 'not_found', 'not-found'):
        return 'CANCELLED'
    return None


SERVICE_LINE_INPUT_STATE_FILENAME = '.service_line_input_state.json'
SERVICE_LINE_INPUT_STATE_SCHEMA_VERSION = 'service_line_input_state.v1'
SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY = 'preview_only_review_required'
SERVICE_LINE_INPUT_WORKFLOW_NAME = 'service_line_input'
SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS = (
    'claims_completion',
    'mutates_billing_state',
    'mutates_dat',
    'mutates_837p',
    'charges_entered',
)

# SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP: keep these constants and wrapper
# helpers through the first release cycle so existing XP sidecars/importers
# remain readable while new code writes `.service_line_input_state.json`.
OPTION_A_MINUTES_STATUS_FILENAME = '.option_a_minutes_status.json'
OPTION_A_MINUTES_STATUS_VERSION = 1


def _option_a_minutes_status_path(local_storage_path):
    if not local_storage_path:
        return None
    return os.path.join(local_storage_path, OPTION_A_MINUTES_STATUS_FILENAME)


def _service_line_input_state_path(local_storage_path):
    if not local_storage_path:
        return None
    return os.path.join(local_storage_path, SERVICE_LINE_INPUT_STATE_FILENAME)


def _option_a_minutes_row_key(patient_id, dos):
    if ServiceLineInputModel is not None:
        try:
            return ServiceLineInputModel.build_legacy_service_line_row_key(patient_id, dos)
        except Exception:
            pass
    return "{0}|{1}".format(str(patient_id or '').strip(), str(dos or '').strip())


def _load_service_line_input_json(path):
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, 'r') as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            data = {}
    except Exception:
        data = {}
    return data


def _normalize_service_line_input_state(data, source_name=''):
    if not isinstance(data, dict):
        data = {}
    data.setdefault('version', OPTION_A_MINUTES_STATUS_VERSION)
    data.setdefault('schema_version', SERVICE_LINE_INPUT_STATE_SCHEMA_VERSION)
    data.setdefault('workflow_name', SERVICE_LINE_INPUT_WORKFLOW_NAME)
    if source_name:
        data.setdefault('state_source', source_name)
    data.setdefault('version', OPTION_A_MINUTES_STATUS_VERSION)
    if not isinstance(data.get('rows'), dict):
        data['rows'] = {}
    if not isinstance(data.get('sessions'), dict):
        data['sessions'] = {}
    if not isinstance(data.get('events'), list):
        data['events'] = []
    return data


def _load_service_line_input_state(local_storage_path):
    new_path = _service_line_input_state_path(local_storage_path)
    legacy_path = _option_a_minutes_status_path(local_storage_path)
    data = _load_service_line_input_json(new_path)
    if data is not None:
        return _normalize_service_line_input_state(data, 'service_line_input')
    data = _load_service_line_input_json(legacy_path)
    if data is not None:
        data = _normalize_service_line_input_state(data, 'legacy_option_a')
        data.setdefault('legacy_option_a_state_path', legacy_path)
        return data
    return _normalize_service_line_input_state({}, 'new_empty')


def _load_option_a_minutes_status(local_storage_path):
    return _load_service_line_input_state(local_storage_path)


def _write_service_line_input_json(path, data, schema_version=None):
    if not path:
        return False
    parent = os.path.dirname(path)
    try:
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
    except Exception:
        pass
    data = dict(data or {})
    data['version'] = OPTION_A_MINUTES_STATUS_VERSION
    if schema_version:
        data['schema_version'] = schema_version
        data['workflow_name'] = SERVICE_LINE_INPUT_WORKFLOW_NAME
    data['updated_at_epoch'] = int(time.time())
    tmp_path = path + '.tmp'
    try:
        with open(tmp_path, 'w') as handle:
            json.dump(data, handle, indent=2, sort_keys=True)
        attempts = 0
        while attempts < 3:
            attempts += 1
            try:
                if os.path.exists(path):
                    os.remove(path)
                os.rename(tmp_path, path)
                return True
            except Exception:
                if attempts < 3:
                    time.sleep(0.05 * attempts)
        return False
    except Exception:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
    return False


def _write_service_line_input_state(local_storage_path, data):
    new_path = _service_line_input_state_path(local_storage_path)
    legacy_path = _option_a_minutes_status_path(local_storage_path)
    new_ok = _write_service_line_input_json(
        new_path,
        data,
        schema_version=SERVICE_LINE_INPUT_STATE_SCHEMA_VERSION,
    )
    legacy_ok = _write_service_line_input_json(legacy_path, data)
    return bool(new_ok or legacy_ok)


def _write_option_a_minutes_status(local_storage_path, data):
    return _write_service_line_input_state(local_storage_path, data)


def _service_line_input_reports_dir(local_storage_path):
    if not local_storage_path:
        return None
    return os.path.join(local_storage_path, 'reports')


def _service_line_input_safe_name(value):
    text = str(value or '').strip()
    out = []
    for ch in text:
        if ch.isalnum() or ch in ('-', '_'):
            out.append(ch)
        else:
            out.append('_')
    safe = ''.join(out).strip('_')
    return safe or 'service_line_input'


def _write_service_line_input_artifact_json(path, payload):
    if not path:
        return ''
    parent = os.path.dirname(path)
    try:
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
    except Exception:
        pass
    try:
        with io.open(path, 'w', encoding='utf-8') as handle:
            handle.write(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True))
            handle.write('\n')
        return path
    except Exception:
        return ''


def _write_service_line_input_artifact_text(path, text):
    if not path:
        return ''
    parent = os.path.dirname(path)
    try:
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
    except Exception:
        pass
    try:
        with io.open(path, 'w', encoding='utf-8') as handle:
            handle.write(str(text or ''))
        return path
    except Exception:
        return ''


def _service_line_input_cleanup_marker_rows():
    return [
        {
            'marker': 'SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP',
            'surface': 'runtime compatibility wrappers and legacy imports',
            'cleanup_condition': 'remove after release-cycle validation proves service_line_input entrypoints and sidecar keys are sufficient',
        },
        {
            'marker': OPTION_A_MINUTES_STATUS_FILENAME,
            'surface': 'legacy local sidecar mirror',
            'cleanup_condition': 'remove after XP deployments no longer read legacy Option A status files',
        },
        {
            'marker': 'run_option_a_minutes_entry_preview',
            'surface': 'legacy UI entrypoint',
            'cleanup_condition': 'remove after callers and tests use run_service_line_input_entry only',
        },
        {
            'marker': 'run_option_a_multi_dos_minutes_preview',
            'surface': 'legacy controller entrypoint',
            'cleanup_condition': 'remove after callers and tests use run_service_line_input_multi_dos_entry only',
        },
    ]


def _build_service_line_input_cleanup_readiness():
    if ServiceLineInputModel is not None:
        try:
            return ServiceLineInputModel.build_service_line_cleanup_readiness_report(
                _service_line_input_cleanup_marker_rows(),
                release_cycle_complete=False,
            )
        except Exception:
            pass
    return {
        'schema_version': 'service_line_input_cleanup_readiness.v1',
        'workflow_name': SERVICE_LINE_INPUT_WORKFLOW_NAME,
        'workflow_boundary': SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        'cleanup_readiness': 'not_ready',
        'legacy_marker_count': len(_service_line_input_cleanup_marker_rows()),
        'legacy_markers': _service_line_input_cleanup_marker_rows(),
        'blockers': ['release_cycle_validation_not_confirmed', 'legacy_option_a_markers_present'],
        'claims_completion': False,
        'mutates_billing_state': False,
        'mutates_dat': False,
        'mutates_837p': False,
        'charges_entered': False,
    }


def _write_service_line_input_review_artifacts(local_storage_path, session_id, completed_rows, review_completion):
    if not local_storage_path:
        return {}
    reports_dir = _service_line_input_reports_dir(local_storage_path)
    if not reports_dir:
        return {}
    safe_session = _service_line_input_safe_name(session_id)
    cleanup_readiness = _build_service_line_input_cleanup_readiness()
    package = None
    if ServiceLineInputModel is not None:
        try:
            package = ServiceLineInputModel.build_service_line_candidate_package(
                session_id,
                completed_rows,
            )
        except Exception:
            package = None
    if not isinstance(package, dict):
        package = {
            'schema_version': 'service_line_input_candidate_package.v1',
            'workflow_name': SERVICE_LINE_INPUT_WORKFLOW_NAME,
            'workflow_boundary': SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
            'service_line_input_session_id': session_id,
            'row_count': len(completed_rows or []),
            'candidate_rows': completed_rows or [],
            'review_completion': review_completion or {},
            'claims_completion': False,
            'mutates_billing_state': False,
            'mutates_dat': False,
            'mutates_837p': False,
            'charges_entered': False,
        }
    package['cleanup_readiness'] = cleanup_readiness
    package['review_completion'] = package.get('review_completion') or review_completion or {}
    package['claims_completion'] = False
    package['mutates_billing_state'] = False
    package['mutates_dat'] = False
    package['mutates_837p'] = False
    package['charges_entered'] = False
    json_path = os.path.join(reports_dir, 'service_line_input_candidate_{0}.json'.format(safe_session))
    txt_path = os.path.join(reports_dir, 'service_line_input_candidate_{0}.txt'.format(safe_session))
    written_json = _write_service_line_input_artifact_json(json_path, package)
    if ServiceLineInputModel is not None:
        try:
            text = ServiceLineInputModel.format_service_line_candidate_report_text(package)
        except Exception:
            text = ''
    else:
        text = ''
    if not text:
        text = 'Service Line Input Review Summary\nSession: {0}\nworkflow_boundary={1}\nclaims_completion=False\n'.format(
            session_id,
            SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        )
    written_txt = _write_service_line_input_artifact_text(txt_path, text)
    return {
        'candidate_json': written_json,
        'candidate_txt': written_txt,
        'cleanup_readiness': cleanup_readiness,
        'package': package,
    }


def _print_service_line_input_review_summary(review_completion, artifact_paths):
    review_completion = review_completion if isinstance(review_completion, dict) else {}
    print("\nService Line Input Review Summary")
    print("Rows: {0} | entered={1} skipped={2} cancelled={3} pending={4} invalid={5}".format(
        review_completion.get('row_count', 0),
        review_completion.get('entered', 0),
        review_completion.get('skipped', 0),
        review_completion.get('cancelled', 0),
        review_completion.get('pending', 0),
        review_completion.get('invalid', 0),
    ))
    print("Review complete: {0}".format(bool(review_completion.get('service_line_input_review_complete'))))
    txt_path = ''
    if isinstance(artifact_paths, dict):
        txt_path = artifact_paths.get('candidate_txt') or ''
    if txt_path:
        print("Review report: {0}".format(txt_path))
    print("Boundary: preview_only_review_required; no DAT/837P/Medisoft charge-entry mutation.")


def _new_service_line_input_session_id():
    return "service_line_input_{0}_{1}".format(int(time.time()), os.getpid())


def _new_option_a_session_id():
    # SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP: legacy wrapper.
    return _new_service_line_input_session_id()


def _option_a_status_to_sidecar(status):
    text = str(status or '').strip().upper()
    if text == 'ENTERED':
        return 'entered'
    if text == 'SKIPPED':
        return 'skipped'
    if text == 'CANCELLED':
        return 'cancelled'
    return ''


def _option_a_bool_value(value):
    if isinstance(value, bool):
        return value
    text = str(value or '').strip().lower()
    if text in ('1', 'true', 'yes', 'y', 'on'):
        return True
    return False


def _sidecar_status_to_preview(status):
    text = str(status or '').strip().lower()
    if text == 'entered':
        return 'ENTERED'
    if text == 'skipped':
        return 'SKIPPED'
    if text == 'cancelled':
        return 'CANCELLED'
    return ''


def _set_service_line_input_payload(row_payload, service_key, legacy_key, value):
    row_payload[service_key] = value
    row_payload[legacy_key] = value


def _set_service_line_input_false_boundary_flags(row_payload):
    for false_key in SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS:
        row_payload[false_key] = False
        row_payload['_service_line_input_{0}'.format(false_key)] = False
        row_payload['_option_a_preview_{0}'.format(false_key)] = False
    row_payload['workflow_name'] = SERVICE_LINE_INPUT_WORKFLOW_NAME
    row_payload['_service_line_input_workflow_name'] = SERVICE_LINE_INPUT_WORKFLOW_NAME
    row_payload['_option_a_preview_workflow_name'] = SERVICE_LINE_INPUT_WORKFLOW_NAME
    row_payload['workflow_boundary'] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY
    row_payload['_service_line_input_workflow_boundary'] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY
    row_payload['_option_a_preview_workflow_boundary'] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY


def _service_line_input_visible_charge_note(row):
    if not isinstance(row, dict):
        return ''
    note = str(row.get('charge_note') or '').strip()
    rule_id = str(row.get('charge_rule_id') or '').strip().lower()
    source = str(row.get('charge_source') or '').strip().lower()
    if note.lower().startswith('baseline ') or rule_id.startswith('baseline_') or source == 'baseline_minutes_tier':
        return ''
    return note


def _normalize_service_line_input_code(value):
    if ServiceLineInputModel is not None:
        try:
            return ServiceLineInputModel.normalize_service_line_code(value)
        except Exception:
            pass
    out = []
    for ch in str(value or '').upper():
        if ch.isalnum():
            out.append(ch)
    return ''.join(out)


def _service_line_input_cpt_suggestion(crosswalk, diagnosis):
    if ServiceLineInputModel is not None:
        try:
            return ServiceLineInputModel.predict_cpt_from_crosswalk(crosswalk, diagnosis)
        except Exception:
            pass
    if not isinstance(crosswalk, dict):
        return {}
    diagnosis_norm = _normalize_service_line_input_code(diagnosis)
    if not diagnosis_norm:
        return {}
    candidates = [diagnosis_norm]
    medisoft = crosswalk.get('diagnosis_to_medisoft')
    if isinstance(medisoft, dict):
        shorthand_matches = []
        for source_dx, mapped_dx in medisoft.items():
            source_norm = _normalize_service_line_input_code(source_dx)
            mapped_norm = _normalize_service_line_input_code(mapped_dx)
            if diagnosis_norm == source_norm and mapped_norm:
                candidates.append(mapped_norm)
            if diagnosis_norm == mapped_norm and source_norm:
                if source_norm not in shorthand_matches:
                    shorthand_matches.append(source_norm)
                candidates.append(source_norm)
        if len(shorthand_matches) > 1:
            return {}
    dx_to_proc = crosswalk.get('diagnosis_to_procedure')
    if not isinstance(dx_to_proc, dict):
        return {}
    for key, cpt in dx_to_proc.items():
        key_norm = _normalize_service_line_input_code(key)
        if key_norm in candidates:
            cpt_norm = _normalize_service_line_input_code(cpt)
            if cpt_norm:
                return {
                    'cpt': cpt_norm,
                    'cpt_source': 'crosswalk.diagnosis_to_procedure',
                    'cpt_confidence': 'crosswalk_confirmed',
                    'cpt_status': 'suggested',
                    'diagnosis_code': str(key or ''),
                }
    return {}


def _service_line_input_diagnosis_display_value(value):
    text = str(value or '').strip().upper()
    normalized = _normalize_service_line_input_code(text)
    if normalized and len(normalized) > 3 and normalized[0].isalpha():
        return "{0}.{1}".format(normalized[:3], normalized[3:])
    return text


def _service_line_input_amount_calculator_with_cpt(crosswalk, base_calculator):
    calculator = base_calculator or calculate_service_line_amount_result

    def calculate(context):
        ctx = dict(context or {})
        suggestion = {}
        if not ctx.get('cpt'):
            suggestion = _service_line_input_cpt_suggestion(crosswalk, ctx.get('diagnosis'))
            if suggestion.get('cpt'):
                ctx['cpt'] = suggestion.get('cpt')
        result = calculator(ctx) if calculator is not None else {}
        if not isinstance(result, dict):
            result = {}
        if suggestion.get('cpt'):
            result.setdefault('cpt', suggestion.get('cpt'))
            result['cpt_source'] = suggestion.get('cpt_source')
            result['cpt_confidence'] = suggestion.get('cpt_confidence')
            result['cpt_status'] = suggestion.get('cpt_status')
        result['workflow_name'] = SERVICE_LINE_INPUT_WORKFLOW_NAME
        result['workflow_boundary'] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY
        for false_key in SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS:
            result[false_key] = False
        return result

    return calculate


def _service_line_input_option_sets_from_crosswalk(crosswalk):
    diagnosis_options = []
    cpt_options = []
    diagnosis_display_map = {}

    def add_value(target, value):
        text = str(value or '').strip().upper()
        if text and text not in target:
            target.append(text)

    def add_display_mapping(raw_value, display_value):
        normalized = _normalize_service_line_input_code(raw_value)
        display = _service_line_input_diagnosis_display_value(display_value)
        if normalized and display:
            diagnosis_display_map[normalized] = display

    if not isinstance(crosswalk, dict):
        return {
            'diagnosis_options': diagnosis_options,
            'cpt_options': cpt_options,
            'diagnosis_display_map': diagnosis_display_map,
        }

    dx_to_proc = crosswalk.get('diagnosis_to_procedure')
    if isinstance(dx_to_proc, dict):
        for diagnosis, cpt in dx_to_proc.items():
            add_value(diagnosis_options, diagnosis)
            add_display_mapping(diagnosis, diagnosis)
            add_value(cpt_options, cpt)

    proc_to_dx = crosswalk.get('procedure_to_diagnosis')
    if isinstance(proc_to_dx, dict):
        for cpt, diagnoses in proc_to_dx.items():
            add_value(cpt_options, cpt)
            if isinstance(diagnoses, (list, tuple)):
                for diagnosis in diagnoses:
                    add_value(diagnosis_options, diagnosis)
                    add_display_mapping(diagnosis, diagnosis)
            else:
                add_value(diagnosis_options, diagnoses)
                add_display_mapping(diagnoses, diagnoses)

    medisoft = crosswalk.get('diagnosis_to_medisoft')
    if isinstance(medisoft, dict):
        medisoft_reverse = {}
        for source_dx, mapped_dx in medisoft.items():
            add_value(diagnosis_options, source_dx)
            add_value(diagnosis_options, mapped_dx)
            source_display = _service_line_input_diagnosis_display_value(source_dx)
            source_norm = _normalize_service_line_input_code(source_dx)
            mapped_norm = _normalize_service_line_input_code(mapped_dx)
            if source_norm:
                add_display_mapping(source_norm, source_display)
            if mapped_norm and source_display:
                medisoft_reverse.setdefault(mapped_norm, []).append(source_display)
        for mapped_norm, displays in medisoft_reverse.items():
            unique = []
            for display in displays:
                if _normalize_service_line_input_code(display) not in [
                        _normalize_service_line_input_code(item) for item in unique]:
                    unique.append(display)
            if len(unique) == 1:
                add_display_mapping(mapped_norm, unique[0])

    diagnosis_options.sort()
    cpt_options.sort()
    return {
        'diagnosis_options': diagnosis_options,
        'cpt_options': cpt_options,
        'diagnosis_display_map': diagnosis_display_map,
    }


def _service_line_input_prompt_required(prompt, default_value=''):
    default_text = str(default_value or '').strip()
    if default_text:
        raw = input("{0} [{1}]: ".format(prompt, default_text))
        value = str(raw or '').strip()
        if not value:
            return default_text
        return value
    return str(input("{0}: ".format(prompt)) or '').strip()


def _service_line_input_build_unknown_code_values(row, field_name, value, crosswalk):
    typed = str(value or '').strip().upper()
    current_dx = str(row.get('diagnosis') or row.get('diagnosis_code') or '').strip().upper()
    current_cpt = str(row.get('cpt') or row.get('cpt_code') or '').strip().upper()
    diagnosis = ''
    medisoft = ''
    cpt = ''
    if field_name == 'diagnosis':
        typed_norm = _normalize_service_line_input_code(typed)
        if typed_norm and typed_norm[0].isalpha():
            diagnosis = _service_line_input_diagnosis_display_value(typed)
            if ServiceLineInputModel is not None:
                try:
                    medisoft = ServiceLineInputModel.suggest_medisoft_shorthand_for_diagnosis(diagnosis)
                except Exception:
                    medisoft = ''
        else:
            medisoft = typed_norm
        cpt = current_cpt
    elif field_name == 'cpt':
        cpt = _normalize_service_line_input_code(typed)
        diagnosis = current_dx if current_dx and current_dx != '-NOT FOUND-' else ''
        if ServiceLineInputModel is not None:
            try:
                diagnosis = ServiceLineInputModel.resolve_diagnosis_display_from_crosswalk(crosswalk, diagnosis)
                if not ServiceLineInputModel.diagnosis_code_is_icd_like(diagnosis):
                    diagnosis = ''
            except Exception:
                pass
        if ServiceLineInputModel is not None:
            try:
                medisoft = ServiceLineInputModel.suggest_medisoft_shorthand_for_diagnosis(diagnosis)
            except Exception:
                medisoft = ''
    return diagnosis, medisoft, cpt


def _service_line_input_intake_conflict_message(conflict):
    if not isinstance(conflict, dict):
        return str(conflict)
    reason = str(conflict.get('reason') or '').strip()
    key = str(conflict.get('key') or '').strip()
    existing_key = str(conflict.get('existing_key') or '').strip()
    existing_value = str(conflict.get('existing_value') or '').strip()
    proposed_key = str(conflict.get('proposed_key') or '').strip()
    proposed_value = str(conflict.get('proposed_value') or '').strip()
    if reason == 'medisoft_shorthand_already_points_to_different_diagnosis':
        return (
            "Medisoft shorthand {0} is already mapped to {1}; row unchanged "
            "(medisoft_shorthand_already_points_to_different_diagnosis)."
        ).format(proposed_value or existing_value or 'that code', existing_key or 'another diagnosis')
    if key == 'diagnosis_to_procedure':
        return (
            "Diagnosis {0} already points to CPT {1}; row unchanged "
            "(diagnosis_to_procedure_conflict)."
        ).format(existing_key or proposed_key or 'this diagnosis', existing_value or 'another CPT')
    if key == 'diagnosis_to_medisoft':
        return (
            "Diagnosis {0} already has Medisoft shorthand {1}; row unchanged "
            "(diagnosis_to_medisoft_conflict)."
        ).format(existing_key or proposed_key or 'this diagnosis', existing_value or 'another value')
    return str(reason or key or 'crosswalk_conflict')


def _service_line_input_intake_problem_messages(errors=None, conflicts=None):
    messages = []
    for error in errors or []:
        code = str(error or '').strip()
        if code == 'diagnosis_code_must_be_full_icd10_like':
            messages.append(
                "Use the full ICD-10 diagnosis code, for example H25.812 "
                "(diagnosis_code_must_be_full_icd10_like)."
            )
        elif code == 'medisoft_shorthand_required':
            messages.append("Medisoft shorthand is required for the bridge (medisoft_shorthand_required).")
        elif code == 'cpt_code_must_be_5_alphanumeric_characters':
            messages.append("Use a 5-character CPT/procedure code such as 00142 (cpt_code_must_be_5_alphanumeric_characters).")
        elif code:
            messages.append(code)
    for conflict in conflicts or []:
        messages.append(_service_line_input_intake_conflict_message(conflict))
    return messages


def _service_line_input_intake_save_failure_message(apply_report):
    report = apply_report if isinstance(apply_report, dict) else {}
    save_error = str(report.get('save_error') or report.get('error') or '').strip()
    messages = _service_line_input_intake_problem_messages(
        report.get('revalidation_errors') or [],
        report.get('revalidation_conflicts') or [],
    )
    if save_error == 'service_line_crosswalk_intake_patch_revalidation_failed':
        lead = "Crosswalk changed while saving; row unchanged. Reopen the row and try again."
        if messages:
            lead = lead + " " + " ".join(messages)
        return lead + " ({0})".format(save_error)
    if save_error == 'save_crosswalk_returned_false':
        return "Crosswalk file could not be saved; row unchanged (save_crosswalk_returned_false)."
    if save_error == 'save_failed':
        return "Crosswalk save raised an error; row unchanged (save_failed)."
    if save_error == 'invalid_service_line_crosswalk_intake_boundary':
        return "Crosswalk update was rejected because it was not a config-update patch; row unchanged."
    if save_error == 'service_line_crosswalk_intake_patch_not_valid':
        return "Crosswalk update was rejected because the mapping was not valid; row unchanged."
    if save_error:
        return "Crosswalk intake not saved: {0}; row unchanged.".format(save_error)
    return "Crosswalk save failed; row unchanged."


def _service_line_input_crosswalk_intake_handler(config, crosswalk, option_sets):
    def handle(row, field_name, value):
        if ServiceLineInputModel is None:
            return {'ok': False, 'message': 'Crosswalk intake helper unavailable; row unchanged.'}
        print("\nNew Service Line Input code")
        print("This can update crosswalk config only; it does not enter charges, write DAT, or create 837P files.")
        diagnosis, medisoft, cpt = _service_line_input_build_unknown_code_values(
            row,
            field_name,
            value,
            crosswalk,
        )
        if not diagnosis:
            diagnosis = _service_line_input_prompt_required("Full ICD-10 diagnosis code")
        if not medisoft:
            try:
                medisoft = ServiceLineInputModel.suggest_medisoft_shorthand_for_diagnosis(diagnosis)
            except Exception:
                medisoft = ''
        medisoft = _service_line_input_prompt_required("Medisoft shorthand", medisoft)
        if not cpt:
            cpt = _service_line_input_prompt_required("CPT code")
        source = {
            'field_name': field_name,
            'typed_value': str(value or '').strip(),
            'patient_id': row.get('patient_id') or '',
            'dos': row.get('date') or '',
        }
        patch = ServiceLineInputModel.build_service_line_crosswalk_intake_patch(
            crosswalk,
            diagnosis,
            medisoft,
            cpt,
            source=source,
        )
        if not patch.get('valid'):
            problems = _service_line_input_intake_problem_messages(
                patch.get('errors') or [],
                patch.get('conflicts') or [],
            )
            try:
                MediLink_ConfigLoader.log(
                    "Service Line Input crosswalk intake rejected: {0}".format(
                        ', '.join(problems) or 'invalid mapping',
                    ),
                    config if isinstance(config, dict) else None,
                    level="WARNING",
                )
            except Exception:
                pass
            return {
                'ok': False,
                'message': 'Crosswalk intake not saved: {0}'.format(', '.join(problems) or 'invalid mapping'),
            }
        print("\nConfirm crosswalk update:")
        print("  Diagnosis: {0}".format(patch.get('diagnosis_code')))
        print("  Medisoft shorthand: {0}".format(patch.get('medisoft_code')))
        print("  CPT: {0}".format(patch.get('cpt_code')))
        print("  Updates: diagnosis_to_medisoft, diagnosis_to_procedure, procedure_to_diagnosis")
        choice = (input("Save this crosswalk update? [y/N]: ") or '').strip().lower()
        if choice not in ('y', 'yes'):
            return {'ok': False, 'message': 'Crosswalk update cancelled; row unchanged.'}
        save_ok = False
        apply_report = {}
        merged = crosswalk
        try:
            from MediBot.MediBot_Crosswalk_Utils import save_service_line_input_crosswalk_intake_patch
            merged, apply_report = save_service_line_input_crosswalk_intake_patch(
                config if isinstance(config, dict) else {},
                crosswalk,
                patch,
                row_target_identity={
                    'patient_id': row.get('patient_id') or source.get('patient_id') or '',
                    'dos': row.get('date') or source.get('dos') or '',
                },
            )
            save_ok = bool(apply_report.get('save_ok'))
        except Exception as exc:
            apply_report['error'] = 'save_failed:{0}'.format(str(exc)[:120])
            apply_report['save_error'] = 'save_failed'
            save_ok = False
        message = (
            'Crosswalk updated; Service Line Input row updated.'
            if save_ok else
            _service_line_input_intake_save_failure_message(apply_report)
        )
        if not save_ok and apply_report.get('save_error'):
            message = _service_line_input_intake_save_failure_message(apply_report)
        try:
            MediLink_ConfigLoader.log(
                "Service Line Input crosswalk intake {0}: diagnosis={1} medisoft={2} cpt={3}".format(
                    'saved' if save_ok else 'save_failed',
                    patch.get('diagnosis_code') or '',
                    patch.get('medisoft_code') or '',
                    patch.get('cpt_code') or '',
                ),
                config if isinstance(config, dict) else None,
                level="INFO" if save_ok else "WARNING",
            )
        except Exception:
            pass
        event = ServiceLineInputModel.build_service_line_crosswalk_intake_event(
            row,
            patch,
            apply_report=apply_report,
            save_ok=save_ok,
            message=message,
        )
        if not save_ok:
            return {
                'ok': False,
                'message': message,
                'crosswalk_intake_events': [event],
            }
        try:
            if isinstance(merged, dict) and merged is not crosswalk:
                crosswalk.clear()
                crosswalk.update(merged)
        except Exception:
            pass
        try:
            refreshed = _service_line_input_option_sets_from_crosswalk(crosswalk)
            option_sets.clear()
            option_sets.update(refreshed)
            option_sets['crosswalk_intake_handler'] = handle
        except Exception:
            pass
        return {
            'ok': True,
            'message': message,
            'row_updates': {
                'diagnosis': patch.get('diagnosis_code'),
                'diagnosis_code': patch.get('diagnosis_code'),
                'diagnosis_raw_value': (
                    str(value or '').strip().upper()
                    if field_name == 'diagnosis'
                    else patch.get('diagnosis_code')
                ),
                'diagnosis_source': 'operator_crosswalk_intake',
                'cpt': patch.get('cpt_code'),
                'cpt_code': patch.get('cpt_code'),
                'cpt_source': 'operator_crosswalk_intake',
                'cpt_confidence': 'operator_confirmed',
                'cpt_status': 'operator_corrected',
                'validation_status': 'review_required',
                'validation_note': 'crosswalk intake confirmed',
                'crosswalk_intake_save_ok': True,
                'crosswalk_intake_message': message,
            },
            'crosswalk_intake_events': [event],
        }
    return handle


def _run_service_line_input_ui_entry(entries, dos, charge_calculator, option_sets):
    try:
        return MediBot_UI.run_service_line_input_entry(
            entries,
            date_of_service_label=dos,
            charge_calculator=charge_calculator,
            diagnosis_options=option_sets.get('diagnosis_options') or [],
            cpt_options=option_sets.get('cpt_options') or [],
            diagnosis_display_map=option_sets.get('diagnosis_display_map') or {},
            crosswalk_intake_handler=option_sets.get('crosswalk_intake_handler'),
        )
    except TypeError:
        return MediBot_UI.run_service_line_input_entry(
            entries,
            date_of_service_label=dos,
            charge_calculator=charge_calculator,
        )


def _option_a_preview_fallback_name(patient_id):
    patient_id_text = str(patient_id or '').strip()
    if patient_id_text:
        return "Patient ID {0}".format(patient_id_text)
    return "Unknown Patient"


def _log_option_a_missing_upstream_name(patient_id, dos):
    try:
        MediLink_ConfigLoader.log(
            "Service Line Input DOCX row has no matching preprocessed patient name; using ID fallback. patient_id={} dos={}".format(
                str(patient_id or '').strip() or 'UNKNOWN',
                str(dos or '').strip() or 'UNKNOWN',
            ),
            level="WARNING",
        )
    except Exception:
        pass


def _service_line_input_same_patient_anchor(status_rows, patient_id, dos):
    patient_id_text = str(patient_id or '').strip()
    dos_text = _normalize_option_a_preview_date(dos) or str(dos or '').strip()
    if not patient_id_text or not isinstance(status_rows, dict):
        return {}
    best = {}
    best_amount = -1
    for _row_key, row in status_rows.items():
        if not isinstance(row, dict):
            continue
        row_patient = str(row.get('patient_id') or '').strip()
        row_dos = _normalize_option_a_preview_date(row.get('dos')) or str(row.get('dos') or '').strip()
        if row_patient != patient_id_text or row_dos == dos_text:
            continue
        if str(row.get('status') or '').strip().lower() != 'entered':
            continue
        if str(row.get('workflow_boundary') or '').strip() != SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY:
            continue
        amount_text = str(row.get('charge_amount') or '').strip()
        display_text = str(row.get('charge_display') or '').strip()
        if not amount_text and not display_text:
            continue
        try:
            amount_value = int(float(amount_text))
        except Exception:
            amount_value = 0
        if amount_value >= best_amount:
            best_amount = amount_value
            best = {
                'same_patient_anchor_charge_amount': amount_text,
                'same_patient_anchor_charge_display': display_text,
                'same_patient_anchor_charge_rule_id': 'same_patient_dos_anchor',
                'same_patient_anchor_charge_note': 'same-patient DOS anchor from {0}'.format(row_dos or 'prior DOS'),
                'same_patient_anchor_source_dos': row_dos,
            }
    return best


def _option_a_preview_row_payload(upstream_entry):
    if (
        upstream_entry
        and len(upstream_entry) > 4
        and isinstance(upstream_entry[4], dict)
    ):
        return dict(upstream_entry[4])
    return {}


def build_option_a_preview_entries_from_docx_index(new_patient_info, config):
    """
    Build Service Line Input rows from the authoritative DOCX schedule index.

    The DOCX index owns DOS selection and schedule order. The upstream
    preprocessed patient entries are used only to attach display names and row
    payloads already associated earlier in the workflow.
    """
    if not new_patient_info:
        return None, None
    if load_docx_schedule_index is None or get_schedules_for_dates is None:
        return None, None
    local_storage_path = _option_a_preview_local_storage_path(config or {})
    if not local_storage_path:
        return None, None

    active_date = _normalize_option_a_preview_date(new_patient_info[0][0])
    if not active_date:
        return None, None

    upstream_by_patient_id = {}
    for entry in new_patient_info:
        if not isinstance(entry, tuple) or len(entry) < 4:
            continue
        entry_date = _normalize_option_a_preview_date(entry[0])
        if entry_date != active_date:
            continue
        patient_id = str(entry[2] or '').strip()
        if patient_id and patient_id not in upstream_by_patient_id:
            upstream_by_patient_id[patient_id] = entry

    try:
        index_data = load_docx_schedule_index(local_storage_path)
        schedules = get_schedules_for_dates(index_data, [active_date])
    except Exception:
        return None, None

    current = schedules.get(active_date)
    if not isinstance(current, dict):
        return None, None
    patients = current.get('patients')
    if not isinstance(patients, dict):
        return None, None

    ordered = []
    for patient_id, payload in patients.items():
        patient_id_text = str(patient_id or '').strip()
        if not patient_id_text:
            continue
        upstream_entry = upstream_by_patient_id.get(patient_id_text)
        if not isinstance(payload, dict):
            payload = {}
        position = payload.get('position')
        try:
            position_key = int(position)
        except Exception:
            position_key = 999999
        if upstream_entry:
            upstream_diagnosis = upstream_entry[3]
            upstream_name = upstream_entry[1]
        else:
            upstream_diagnosis = ''
            upstream_name = _option_a_preview_fallback_name(patient_id_text)
            _log_option_a_missing_upstream_name(patient_id_text, active_date)
        diagnosis = payload.get('diagnosis') or upstream_diagnosis
        row_payload = _option_a_preview_row_payload(upstream_entry)
        source_payload = {
            'patient_id': patient_id_text,
            'dos': active_date,
            'docx_diagnosis': diagnosis,
            'docx_position': position,
            'line_ordinal': position_key,
        }
        _set_service_line_input_payload(
            row_payload,
            '_service_line_input_source',
            '_option_a_preview_source',
            source_payload,
        )
        _set_service_line_input_payload(
            row_payload,
            '_service_line_input_diagnosis_source',
            '_option_a_preview_diagnosis_source',
            'docx',
        )
        auto_status = _option_a_preview_docx_auto_status(diagnosis)
        if auto_status:
            _set_service_line_input_payload(
                row_payload,
                '_service_line_input_status',
                '_option_a_preview_status',
                auto_status,
            )
            _set_service_line_input_payload(
                row_payload,
                '_service_line_input_status_reason',
                '_option_a_preview_status_reason',
                'docx_diagnosis_unknown',
            )
        ordered.append((
            position_key,
            patient_id_text,
            (active_date, upstream_name, patient_id_text, diagnosis, row_payload),
        ))

    if not ordered:
        return None, None
    ordered.sort(key=lambda item: (item[0], item[1]))
    return [item[2] for item in ordered], active_date


def build_service_line_input_entries_from_docx_index(new_patient_info, config):
    return build_option_a_preview_entries_from_docx_index(new_patient_info, config)


def build_option_a_preview_dos_groups_from_docx_index(new_patient_info, config):
    """
    Build current-session Service Line Input groups from DOCX-index schedules.

    Returns a list of dicts: {dos, entries}. The broad upstream entries define
    the current CSV session DOS scope and provide names/payloads by patient ID.
    For each in-scope DOS, the DOCX index owns the visible row set and order.
    """
    if not new_patient_info:
        return []
    if load_docx_schedule_index is None or get_schedules_for_dates is None:
        return []
    local_storage_path = _option_a_preview_local_storage_path(config or {})
    if not local_storage_path:
        return []

    upstream_by_date = {}
    for entry in new_patient_info:
        if not isinstance(entry, tuple) or len(entry) < 4:
            continue
        entry_date = _normalize_option_a_preview_date(entry[0])
        patient_id = str(entry[2] or '').strip()
        if not entry_date or not patient_id:
            continue
        date_bucket = upstream_by_date.setdefault(entry_date, {})
        if patient_id not in date_bucket:
            date_bucket[patient_id] = entry
    if not upstream_by_date:
        return []

    requested_dates = sorted(upstream_by_date.keys())
    try:
        index_data = load_docx_schedule_index(local_storage_path)
        schedules = get_schedules_for_dates(index_data, requested_dates)
    except Exception:
        return []
    if not isinstance(schedules, dict):
        return []

    status_data = _load_option_a_minutes_status(local_storage_path)
    status_rows = status_data.get('rows', {})
    groups = []
    for dos in requested_dates:
        current = schedules.get(dos)
        if not isinstance(current, dict):
            continue
        patients = current.get('patients')
        if not isinstance(patients, dict):
            continue
        upstream_by_patient_id = upstream_by_date.get(dos, {})
        ordered = []
        for patient_id, payload in patients.items():
            patient_id_text = str(patient_id or '').strip()
            if not patient_id_text:
                continue
            upstream_entry = upstream_by_patient_id.get(patient_id_text)
            if not isinstance(payload, dict):
                payload = {}
            position = payload.get('position')
            try:
                position_key = int(position)
            except Exception:
                position_key = 999999
            if upstream_entry:
                upstream_diagnosis = upstream_entry[3]
                upstream_name = upstream_entry[1]
            else:
                upstream_diagnosis = ''
                upstream_name = _option_a_preview_fallback_name(patient_id_text)
                _log_option_a_missing_upstream_name(patient_id_text, dos)
            diagnosis = payload.get('diagnosis') or upstream_diagnosis
            row_payload = _option_a_preview_row_payload(upstream_entry)
            source_payload = {
                'patient_id': patient_id_text,
                'dos': dos,
                'docx_diagnosis': diagnosis,
                'docx_position': position,
                'line_ordinal': position_key,
            }
            _set_service_line_input_payload(
                row_payload,
                '_service_line_input_source',
                '_option_a_preview_source',
                source_payload,
            )
            _set_service_line_input_payload(
                row_payload,
                '_service_line_input_diagnosis_source',
                '_option_a_preview_diagnosis_source',
                'docx',
            )
            anchor = _service_line_input_same_patient_anchor(status_rows, patient_id_text, dos)
            for anchor_key, anchor_value in anchor.items():
                _set_service_line_input_payload(
                    row_payload,
                    '_service_line_input_{0}'.format(anchor_key),
                    '_option_a_preview_{0}'.format(anchor_key),
                    anchor_value,
                )
            persisted = status_rows.get(_option_a_minutes_row_key(patient_id_text, dos))
            if isinstance(persisted, dict):
                persisted_status = _sidecar_status_to_preview(persisted.get('status'))
                if persisted_status:
                    _set_service_line_input_payload(
                        row_payload,
                        '_service_line_input_status',
                        '_option_a_preview_status',
                        persisted_status,
                    )
                    if persisted.get('minutes'):
                        _set_service_line_input_payload(
                            row_payload,
                            '_service_line_input_minutes',
                            '_option_a_preview_minutes',
                            str(persisted.get('minutes')),
                        )
                    for state_key, service_key, legacy_key in (
                        ('charge_display', '_service_line_input_charge_display', '_option_a_preview_charge_display'),
                        ('charge_amount', '_service_line_input_charge_amount', '_option_a_preview_charge_amount'),
                        ('charge_note', '_service_line_input_charge_note', '_option_a_preview_charge_note'),
                        ('charge_rule_id', '_service_line_input_charge_rule_id', '_option_a_preview_charge_rule_id'),
                        ('charge_status', '_service_line_input_charge_status', '_option_a_preview_charge_status'),
                        ('charge_schema_version', '_service_line_input_charge_schema_version', '_option_a_preview_charge_schema_version'),
                        ('charge_source', '_service_line_input_charge_source', '_option_a_preview_charge_source'),
                        ('workflow_name', '_service_line_input_workflow_name', '_option_a_preview_workflow_name'),
                        ('workflow_boundary', '_service_line_input_workflow_boundary', '_option_a_preview_workflow_boundary'),
                        ('claims_completion', '_service_line_input_claims_completion', '_option_a_preview_claims_completion'),
                        ('mutates_billing_state', '_service_line_input_mutates_billing_state', '_option_a_preview_mutates_billing_state'),
                        ('billable', '_service_line_input_billable', '_option_a_preview_billable'),
                        ('requires_operator_review', '_service_line_input_requires_operator_review', '_option_a_preview_requires_operator_review'),
                        ('cpt', '_service_line_input_cpt', '_option_a_preview_cpt'),
                        ('cpt_code', '_service_line_input_cpt_code', '_option_a_preview_cpt_code'),
                        ('cpt_source', '_service_line_input_cpt_source', '_option_a_preview_cpt_source'),
                        ('cpt_confidence', '_service_line_input_cpt_confidence', '_option_a_preview_cpt_confidence'),
                        ('cpt_status', '_service_line_input_cpt_status', '_option_a_preview_cpt_status'),
                        ('diagnosis', '_service_line_input_diagnosis', '_option_a_preview_diagnosis'),
                        ('diagnosis_code', '_service_line_input_diagnosis_code', '_option_a_preview_diagnosis_code'),
                        ('diagnosis_source', '_service_line_input_diagnosis_source', '_option_a_preview_diagnosis_source'),
                        ('validation_status', '_service_line_input_validation_status', '_option_a_preview_validation_status'),
                        ('validation_note', '_service_line_input_validation_note', '_option_a_preview_validation_note'),
                    ):
                        if persisted.get(state_key) is not None and persisted.get(state_key) != '':
                            if state_key == 'charge_note':
                                persisted_note = _service_line_input_visible_charge_note(persisted)
                                if not persisted_note:
                                    continue
                                _set_service_line_input_payload(
                                    row_payload,
                                    service_key,
                                    legacy_key,
                                    persisted_note,
                                )
                                continue
                            _set_service_line_input_payload(
                                row_payload,
                                service_key,
                                legacy_key,
                                persisted.get(state_key),
                            )
                    status_reason = str(
                        persisted.get('status_reason') or 'service_line_input_state_hydrated'
                    )
                    _set_service_line_input_payload(
                        row_payload,
                        '_service_line_input_status_reason',
                        '_option_a_preview_status_reason',
                        status_reason,
                    )
            else:
                auto_status = _option_a_preview_docx_auto_status(diagnosis)
                if auto_status:
                    _set_service_line_input_payload(
                        row_payload,
                        '_service_line_input_status',
                        '_option_a_preview_status',
                        auto_status,
                    )
                    _set_service_line_input_payload(
                        row_payload,
                        '_service_line_input_status_reason',
                        '_option_a_preview_status_reason',
                        'docx_diagnosis_unknown',
                    )
            ordered.append((
                position_key,
                patient_id_text,
                (dos, upstream_name, patient_id_text, diagnosis, row_payload),
            ))
        if ordered:
            ordered.sort(key=lambda item: (item[0], item[1]))
            groups.append({'dos': dos, 'entries': [item[2] for item in ordered]})
    return groups


def build_service_line_input_dos_groups_from_docx_index(new_patient_info, config):
    return build_option_a_preview_dos_groups_from_docx_index(new_patient_info, config)


def persist_service_line_input_summary(local_storage_path, service_line_input_session_id, dos, summary):
    data = _load_service_line_input_state(local_storage_path)
    rows_state = data.setdefault('rows', {})
    events_state = data.setdefault('events', [])
    session_state = data.setdefault('sessions', {}).setdefault(service_line_input_session_id, {
        'started_at_epoch': int(time.time()),
        'dos_completed': [],
    })
    if dos not in session_state.get('dos_completed', []):
        session_state.setdefault('dos_completed', []).append(dos)
    session_state['updated_at_epoch'] = int(time.time())
    for row in summary.get('rows', []) if isinstance(summary, dict) else []:
        if ServiceLineInputModel is not None:
            try:
                row = ServiceLineInputModel.sanitize_service_line_preview_row(row)
            except Exception:
                pass
        source = row.get('source') if isinstance(row, dict) else {}
        if not isinstance(source, dict):
            source = {}
        patient_id = source.get('patient_id') or row.get('patient_id')
        row_dos = source.get('dos') or dos
        status = _option_a_status_to_sidecar(row.get('status'))
        if not patient_id or not row_dos or not status:
            continue
        status_reason = row.get('status_reason')
        review_status = status
        if status == 'cancelled' and str(status_reason or '').strip() == 'docx_diagnosis_unknown':
            review_status = 'auto_cancelled'
        state_row = {
            'patient_id': str(patient_id),
            'dos': _normalize_option_a_preview_date(row_dos) or str(row_dos),
            'status': status,
            'review_status': review_status,
            'docx_diagnosis': source.get('docx_diagnosis') or row.get('diagnosis') or '',
            'docx_position': source.get('docx_position'),
            'diagnosis_code': row.get('diagnosis_code') or row.get('diagnosis') or source.get('docx_diagnosis') or '',
            'diagnosis_source': row.get('diagnosis_source') or 'docx',
            'validation_status': row.get('validation_status') or 'review_required',
            'validation_note': row.get('validation_note') or '',
            'updated_at_epoch': int(time.time()),
            'service_line_input_session_id': service_line_input_session_id,
            'option_a_session_id': service_line_input_session_id,
        }
        if ServiceLineInputModel is not None:
            try:
                target_record = ServiceLineInputModel.build_service_line_target_record(
                    row=row,
                    patient_id=patient_id,
                    dos=row_dos,
                    line_ordinal=source.get('line_ordinal') or source.get('docx_position'),
                    docx_position=source.get('docx_position'),
                )
                state_row['target_identity'] = target_record.get('target_identity')
                state_row['legacy_row_key'] = target_record.get('legacy_row_key')
                state_row['service_line_row_key'] = target_record.get('service_line_row_key')
                state_row['service_line_kind'] = target_record.get('service_line_kind')
                state_row['line_ordinal'] = target_record.get('line_ordinal')
                state_row['target_schema_version'] = target_record.get('schema_version')
            except Exception:
                pass
        if status == 'entered':
            state_row['minutes'] = str(row.get('minutes') or '')
        for key in (
                'charge_display',
                'charge_amount',
                'charge_note',
                'charge_rule_id',
                'charge_status',
                'charge_schema_version',
                'charge_source',
                'workflow_name',
                'workflow_boundary',
                'claims_completion',
                'mutates_billing_state',
                'billable',
                'requires_operator_review',
                'cpt',
                'cpt_code',
                'cpt_source',
                'cpt_confidence',
                'cpt_status',
                'diagnosis',
                'diagnosis_code',
                'diagnosis_source',
                'validation_status',
                'validation_note',
                'crosswalk_intake_save_ok',
                'crosswalk_intake_message'):
            if row.get(key) is not None and row.get(key) != '':
                if key in ('claims_completion', 'mutates_billing_state'):
                    state_row[key] = False
                elif key in ('billable', 'requires_operator_review'):
                    state_row[key] = _option_a_bool_value(row.get(key))
                elif key == 'crosswalk_intake_save_ok':
                    state_row[key] = _option_a_bool_value(row.get(key))
                elif key == 'charge_note':
                    visible_note = _service_line_input_visible_charge_note(row)
                    if visible_note:
                        state_row[key] = visible_note
                else:
                    state_row[key] = str(row.get(key))
        if state_row.get('cpt') and not state_row.get('cpt_code'):
            state_row['cpt_code'] = state_row.get('cpt')
        if state_row.get('diagnosis') and not state_row.get('diagnosis_code'):
            state_row['diagnosis_code'] = state_row.get('diagnosis')
        state_row['workflow_name'] = SERVICE_LINE_INPUT_WORKFLOW_NAME
        state_row['workflow_boundary'] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY
        for false_key in SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS:
            state_row[false_key] = False
        intake_events = row.get('crosswalk_intake_events')
        if isinstance(intake_events, list):
            safe_events = []
            for intake_event in intake_events:
                if not isinstance(intake_event, dict):
                    continue
                event_copy = dict(intake_event)
                event_copy['service_line_input_session_id'] = service_line_input_session_id
                event_copy['workflow_boundary'] = 'confirmed_config_update'
                event_copy['claim_workflow_completion'] = False
                event_copy['claims_completion'] = False
                event_copy['mutates_billing_state'] = False
                event_copy['mutates_dat'] = False
                event_copy['mutates_837p'] = False
                event_copy['charges_entered'] = False
                safe_events.append(event_copy)
            if safe_events:
                state_row['crosswalk_intake_events'] = safe_events
        if ServiceLineInputModel is not None:
            try:
                state_row = ServiceLineInputModel.sanitize_service_line_preview_row(state_row)
            except Exception:
                pass
        for false_key in SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS:
            state_row[false_key] = False
        if isinstance(state_row.get('crosswalk_intake_events'), list):
            for event_copy in state_row.get('crosswalk_intake_events') or []:
                if isinstance(event_copy, dict):
                    event_copy['workflow_boundary'] = 'confirmed_config_update'
                    event_copy['claim_workflow_completion'] = False
                    event_copy['claims_completion'] = False
                    event_copy['mutates_billing_state'] = False
                    event_copy['mutates_dat'] = False
                    event_copy['mutates_837p'] = False
                    event_copy['charges_entered'] = False
        if status_reason:
            state_row['status_reason'] = str(status_reason)
        legacy_row_key = _option_a_minutes_row_key(patient_id, row_dos)
        previous_row = rows_state.get(legacy_row_key)
        if ServiceLineInputModel is not None:
            try:
                event = ServiceLineInputModel.build_service_line_overlay_event(
                    previous_row or {},
                    state_row,
                    service_line_input_session_id,
                    action='row_persisted',
                )
                if event:
                    events_state.append(event)
            except Exception:
                pass
        for intake_event in state_row.get('crosswalk_intake_events') or []:
            if isinstance(intake_event, dict):
                events_state.append(intake_event)
        rows_state[legacy_row_key] = state_row
    return _write_service_line_input_state(local_storage_path, data)


def persist_option_a_minutes_summary(local_storage_path, option_a_session_id, dos, summary):
    # SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP: legacy wrapper.
    return persist_service_line_input_summary(
        local_storage_path,
        option_a_session_id,
        dos,
        summary,
    )


def run_service_line_input_multi_dos_entry(new_patient_info, config, charge_calculator=None, crosswalk=None):
    local_storage_path = _option_a_preview_local_storage_path(config or {})
    if charge_calculator is None:
        charge_calculator = calculate_service_line_amount_result
    if not isinstance(crosswalk, dict):
        crosswalk = {}
    charge_calculator = _service_line_input_amount_calculator_with_cpt(crosswalk, charge_calculator)
    option_sets = _service_line_input_option_sets_from_crosswalk(crosswalk)
    option_sets['crosswalk_intake_handler'] = _service_line_input_crosswalk_intake_handler(
        config,
        crosswalk,
        option_sets,
    )
    groups = build_service_line_input_dos_groups_from_docx_index(new_patient_info, config)
    if not groups:
        preview_entries, preview_dos = build_service_line_input_entries_from_docx_index(new_patient_info, config)
        if preview_entries:
            groups = [{'dos': preview_dos, 'entries': preview_entries}]
        else:
            groups = [{'dos': str(new_patient_info[0][0] or '') if new_patient_info else '', 'entries': new_patient_info}]

    session_id = _new_service_line_input_session_id()
    completed = []
    completed_rows = []
    for idx, group in enumerate(groups):
        dos = group.get('dos') or ''
        entries = group.get('entries') or []
        if idx > 0:
            print("\nNext Service Line Input DOS: {0} ({1} patient(s) pending in this session).".format(
                dos or 'Unknown',
                len(entries),
            ))
            choice = (input("Press Enter to continue, or q to return to MediBot workflow: ") or "").strip().lower()
            if choice == 'q':
                break
        summary = _run_service_line_input_ui_entry(
            entries,
            dos,
            charge_calculator,
            option_sets,
        )
        if local_storage_path:
            persist_service_line_input_summary(local_storage_path, session_id, dos, summary)
        completed.append({'dos': dos, 'summary': summary})
        if isinstance(summary, dict):
            completed_rows.extend(summary.get('rows') or [])
    review_completion = {
        'workflow_name': SERVICE_LINE_INPUT_WORKFLOW_NAME,
        'workflow_boundary': SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        'service_line_input_session_id': session_id,
        'service_line_input_review_complete': True,
        'claims_completion': False,
        'mutates_billing_state': False,
        'mutates_dat': False,
        'mutates_837p': False,
        'charges_entered': False,
    }
    if ServiceLineInputModel is not None:
        try:
            review_completion = ServiceLineInputModel.build_service_line_review_completion_summary(
                session_id,
                completed_rows,
            )
        except Exception:
            pass
    if len(completed) != len(groups):
        review_completion['service_line_input_review_complete'] = False
        review_completion['review_completion_blocker'] = 'operator_returned_before_all_dos'
    artifact_paths = {}
    if local_storage_path:
        artifact_paths = _write_service_line_input_review_artifacts(
            local_storage_path,
            session_id,
            completed_rows,
            review_completion,
        )
        if isinstance(artifact_paths, dict):
            if artifact_paths.get('candidate_json'):
                review_completion['candidate_json'] = artifact_paths.get('candidate_json')
            if artifact_paths.get('candidate_txt'):
                review_completion['candidate_txt'] = artifact_paths.get('candidate_txt')
            cleanup = artifact_paths.get('cleanup_readiness')
            if isinstance(cleanup, dict):
                review_completion['cleanup_readiness'] = cleanup.get('cleanup_readiness')
                review_completion['cleanup_blockers'] = cleanup.get('blockers') or []
    _print_service_line_input_review_summary(review_completion, artifact_paths)
    return {
        'service_line_input_session_id': session_id,
        'option_a_session_id': session_id,
        'dos_total': len(groups),
        'dos_completed': len(completed),
        'review_completion': review_completion,
        'artifact_paths': artifact_paths,
        'completed': completed,
    }


def run_option_a_multi_dos_minutes_preview(new_patient_info, config, charge_calculator=None, crosswalk=None):
    # SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP: legacy wrapper.
    return run_service_line_input_multi_dos_entry(
        new_patient_info,
        config,
        charge_calculator=charge_calculator,
        crosswalk=crosswalk,
    )

# Global flag to control AHK execution method - set to True to use optimized stdin method
USE_AHK_STDIN_OPTIMIZATION = True

def _get_ahk_timing_settings():
    """Fetch AHK timing settings from config with safe defaults.
    Returns (key_delay_ms, key_press_ms, post_send_sleep_ms).
    """
    key_delay_ms = 0 
    key_press_ms = 0
    post_send_sleep_ms = 0
    try:
        config, _ = MediBot_Preprocessor_lib.get_cached_configuration()
        # Allow flat keys in config for simplicity/XP safety
        key_delay_ms = int(config.get('AHK_KEY_DELAY_MS', key_delay_ms))
        key_press_ms = int(config.get('AHK_KEY_PRESS_MS', key_press_ms))
        post_send_sleep_ms = int(config.get('AHK_POST_SEND_SLEEP_MS', post_send_sleep_ms))
    except Exception:
        # Use defaults on any error
        pass
    return key_delay_ms, key_press_ms, post_send_sleep_ms

def _build_ahk_script_with_handshake(core_send_command, done_token):
    """Build a complete AHK script that:
    - Sets stable, slightly slowed input timing (prevents UI overrun)
    - Executes the provided send command (expected to include {Enter} as field advance)
    - Sleeps briefly to allow UI to settle
    - Emits a completion token to stdout (so Python can block until completion)

    NOTE (future option - burst mode): To reduce process spawn overhead, we can batch
    multiple send commands into a single AHK script by concatenating several
    `SendInput, ...{Enter}` lines separated by short `Sleep` calls, then append a single
    `FileAppend, DONE, *` at the end. Python would then wait for "DONE" once per burst
    (e.g., 3–5 fields), instead of once per field.
    """
    # Keep delays configurable; defaults are tuned for responsiveness while avoiding overruns
    key_delay_ms, key_press_ms, post_send_sleep_ms = _get_ahk_timing_settings()
    # SetKeyDelay, DelayBetweenKeysMs, KeyPressDurationMs
    preamble = (
        "#NoEnv\r\n"
        "#NoTrayIcon\r\n"
        "SendMode, Input\r\n"
        "SetKeyDelay, {0}, {1}\r\n".format(key_delay_ms, key_press_ms)
    )
    # After each send, give UI a short moment before declaring done
    epilogue = (
        "\r\nSleep, {sleep}\r\n"
        "FileAppend, {done}, *\r\n"
        "ExitApp\r\n"
    ).format(sleep=post_send_sleep_ms, done=done_token)
    return preamble + core_send_command + epilogue

# Function to execute an AutoHotkey script
def run_ahk_script(script_content):
    """
    Execute an AutoHotkey script using either optimized stdin method or traditional file method.
    Blocks until AHK confirms completion by writing a token to stdout.
    Automatically falls back to file method if stdin method fails.

    Future: Add optional burst mode to submit several send commands in one script, reducing
    process overhead while keeping a single completion token per burst.
    """
    done_token = "OK"
    full_script = _build_ahk_script_with_handshake(script_content + "\r\n", done_token)
    if USE_AHK_STDIN_OPTIMIZATION:
        try:
            # Optimized method: Execute AHK script via stdin pipe - eliminates temporary file creation
            # Compatible with Windows XP and AutoHotkey v1.x. In AHK v1, '*' tells AHK to read the script from stdin.
            process = subprocess.Popen(
                [
                    MediBot_Preprocessor_lib.AHK_EXECUTABLE,
                    '/ErrorStdOut',  # Route script errors to stderr for capture
                    '/CP65001',      # Treat incoming script as UTF-8 (robust with minimal overhead)
                    '*'
                ],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                shell=False
            )

            # Send script content via stdin
            stdout, stderr = process.communicate(input=full_script.encode('utf-8'))

            if process.returncode == 0:
                try:
                    decoded_out = stdout.decode('utf-8', errors='ignore') if stdout else ''
                except Exception:
                    decoded_out = str(stdout)
                # Require the done token to ensure UI is ready before proceeding
                if done_token in decoded_out:
                    return  # Success
                # If we got here, AHK exited 0 but no token was seen; fall through to log and fallback
                MediLink_ConfigLoader.log("AHK completed without handshake token; attempting fallback.", level="WARNING")

            # Non-zero exit code: log details and fall back to file-based method
            print("AHK script failed with exit status: {}".format(process.returncode))
            MediLink_ConfigLoader.log("AHK script failed with exit status: {}".format(process.returncode), level="ERROR")
            if stderr:
                try:
                    decoded_err = stderr.decode('utf-8', errors='ignore')
                except Exception:
                    decoded_err = str(stderr)
                print("AHK Error: {}".format(decoded_err))
                MediLink_ConfigLoader.log("AHK Error: {}".format(decoded_err), level="ERROR")

        except Exception as e:
            # If stdin method fails, fall back to traditional file method
            print("AHK stdin execution failed, falling back to file method: {}".format(e))
            MediLink_ConfigLoader.log("AHK stdin execution failed, falling back to file method: {}".format(e), level="ERROR")
            # Continue to fallback implementation below
    
    # Traditional file-based method (fallback or when optimization disabled)
    temp_script_name = None  # Initialize variable to hold the name of the temporary script file
    try:
        # Create a temporary AHK script file
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.ahk', encoding='utf-8') as temp_script:
            temp_script_name = temp_script.name  # Store the name of the temporary script file
            temp_script.write(full_script)  # Write the script content to the temporary file
            temp_script.flush()  # Ensure the file is written to disk
        # Attempt to run the AHK script and capture stdout to verify handshake
        process = subprocess.Popen(
            [MediBot_Preprocessor_lib.AHK_EXECUTABLE, temp_script_name],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            shell=False
        )
        stdout, stderr = process.communicate()
        if process.returncode != 0:
            raise subprocess.CalledProcessError(process.returncode, 'AutoHotkey', output=stderr)
        try:
            decoded_out = stdout.decode('utf-8', errors='ignore') if stdout else ''
        except Exception:
            decoded_out = str(stdout)
        if done_token not in decoded_out:
            MediLink_ConfigLoader.log("AHK file-exec completed without handshake token.", level="WARNING")
            # Proceed, but warn; on older systems stdout may be suppressed
    except subprocess.CalledProcessError as e:
        print("AHK script failed with exit status: {}".format(e.returncode))  # Log the exit status of the failed script
        MediLink_ConfigLoader.log("AHK script failed with exit status: {}".format(e.returncode), level="ERROR")
        print("Output from AHK script: {}".format(e.output))  # Log the output from the failed script
        MediLink_ConfigLoader.log("Output from AHK script: {}".format(e.output), level="ERROR")
    except Exception as e:
        print("An unexpected error occurred while running the AHK script: {}".format(e))  # Log any unexpected errors
        MediLink_ConfigLoader.log("An unexpected error occurred while running the AHK script: {}".format(e), level="ERROR")
        traceback.print_exc()  # Print the full traceback for debugging purposes
    finally:
        # Delete the temporary script file
        if temp_script_name:
            try:
                os.unlink(temp_script_name)  # Attempt to delete the temporary script file
            except OSError as e:
                print("Error deleting temporary script file: {}".format(e))  # Log any errors encountered while deleting the file
                MediLink_ConfigLoader.log("Error deleting temporary script file: {}".format(e), level="ERROR")
                # Future Improvement: Implement a cleanup mechanism to handle orphaned temporary files

# Module-scope context container for cross-callback state (XP/3.4.4 compatible)
try:
    # Avoid dataclasses to maintain 3.4.4 compatibility without external deps
    class MediBotContext(object):
        def __init__(self):
            self.last_processed_entry = None
            self.parsed_address_components = {}
            self.current_patient_context = None
    CTX = MediBotContext()
except Exception:
    # Fallback simple dict if class definition fails for any reason
    CTX = {
        'last_processed_entry': None,
        'parsed_address_components': {},
        'current_patient_context': None,
    }

# Backwards-compatible globals (maintain import contract for MediBot_UI and hotkeys)
last_processed_entry = None
parsed_address_components = {}
current_patient_context = None

def process_field(medisoft_field, csv_row, parsed_address_components, reverse_mapping, csv_data, fixed_values):
    global last_processed_entry
    
    try:
        # Attempt to retrieve the value for the current medisoft_field from parsed_address_components
        value = parsed_address_components.get(medisoft_field, '') if medisoft_field in parsed_address_components else ''
        
        # If no value is found, check if there is a fixed value available for this field
        if not value:
            if medisoft_field in fixed_values:
                value = fixed_values[medisoft_field][0]  # Use the fixed value if available
        
        # If still no value, check if the field is present in the reverse mapping
        if not value and medisoft_field in reverse_mapping:
            # Retrieve the corresponding CSV header from the reverse mapping
            csv_header = reverse_mapping[medisoft_field]
            value = csv_row.get(csv_header, '')  # Get the value from the CSV row using the header
            
            # Log the detected field and its value after assignment
            MediLink_ConfigLoader.log("Detected {}: {}".format(medisoft_field, value), level="DEBUG")

        # Format the value for the AutoHotkey script, or default to sending an Enter key if no value is found
        formatted_value = (MediBot_dataformat_library.format_data(medisoft_field, value, csv_data, reverse_mapping, parsed_address_components)
                           if value else 'Send, {Enter}')
        
        # Execute the AutoHotkey script with the formatted value
        run_ahk_script(formatted_value)

        # Update the last processed entry with the current field and its value
        last_processed_entry = (medisoft_field, value)
        try:
            # Keep CTX in sync for consumers that adopt CTX
            if hasattr(CTX, 'last_processed_entry'):
                CTX.last_processed_entry = last_processed_entry
            else:
                CTX['last_processed_entry'] = last_processed_entry
        except Exception:
            pass
        return 'continue', last_processed_entry  # Indicate to continue processing
    except Exception as e:
        # Handle any exceptions that occur during processing
        return handle_error(e, medisoft_field, last_processed_entry, csv_data, reverse_mapping)

def handle_error(error, medisoft_field, last_processed_entry, csv_data, reverse_mapping):
    global current_patient_context
    try:
        MediLink_ConfigLoader.log("Error in process_field: {}".format(error), level="ERROR")
    except Exception:
        pass
    print("An error occurred while processing {0}: {1}".format(medisoft_field, error))
    
    # Update patient context with current error information for F11 menu
    if current_patient_context is None:
        current_patient_context = {}
    current_patient_context.update({
        'last_field': medisoft_field,
        'error_occurred': True,
        'error_message': str(error)
    })
    try:
        if hasattr(CTX, 'current_patient_context'):
            CTX.current_patient_context = current_patient_context
        else:
            CTX['current_patient_context'] = current_patient_context
    except Exception:
        pass
    
    # Assuming the interaction mode is 'error' in this case
    interaction_mode = 'error'
    response = user_interaction(csv_data, interaction_mode, str(error), reverse_mapping)
    return response, last_processed_entry

# iterating through each field defined in the field_mapping.
def iterate_fields(csv_row, field_mapping, parsed_address_components, reverse_mapping, csv_data, fixed_values):
    global last_processed_entry
    # Check for user action at the start of each field processing
    for medisoft_field in field_mapping.keys():
        action = manage_script_pause(csv_data,'',reverse_mapping) # per-field pause availability. Necessary to provide frequent opportunities for the user to pause the script.
        if action != 0:  # If action is either 'Retry' (-1) or 'Skip' (1)
            return action  # Break out and pass the action up
        
        # Process each field in the row
        response, last_processed_entry = process_field(
            medisoft_field, csv_row, parsed_address_components, reverse_mapping, csv_data, fixed_values
        )
        # Respect field-level control actions from process_field/user_interaction.
        if response in (-2, -1, 1):
            return response
        try:
            if hasattr(CTX, 'last_processed_entry'):
                CTX.last_processed_entry = last_processed_entry
            else:
                CTX['last_processed_entry'] = last_processed_entry
        except Exception:
            pass
        
    return 0 # Default action to continue

def _mark_charges_entered_if_possible(config, row, reverse_mapping):
    """
    Best-effort billing-status update after a row is fully entered in Medisoft.

    This marks charges_entered per DOS so downstream intake/reconciliation can
    reason about charge-entry progress without waiting for claim submission.
    """
    if not config or not isinstance(row, dict) or not isinstance(reverse_mapping, dict):
        return
    try:
        medilink_dir = os.path.join(project_dir, 'MediLink')
        if medilink_dir not in sys.path:
            sys.path.insert(0, medilink_dir)
        import MediLink_Scheduler as _billing_scheduler
        _billing_scheduler.mark_charges_entered_for_row(config, row, reverse_mapping)
    except Exception:
        # Never let billing-status bookkeeping block operator flow.
        pass


def data_entry_loop(csv_data, field_mapping, reverse_mapping, fixed_values, config=None):
    global last_processed_entry, parsed_address_components, current_patient_context
    # Do NOT convert these to locals. The F11 pause/retry menu and MediBot_UI depend on
    # these globals to reflect real-time state across callbacks and hotkey handlers.
    # last_processed_entry, parsed_address_components = None, {}  # This would break F11 context.
    error_message = ''  # Initialize error_message once
    current_row_index = 0
    # PERFORMANCE FIX: Cache list length to avoid repeated len() calls
    csv_data_length = len(csv_data)

    while current_row_index < csv_data_length:
        row = csv_data[current_row_index]
        
        # PERFORMANCE FIX: Clear accumulating memory while preserving F11 menu context
        # Store patient context before clearing last_processed_entry for F11 "Retry last entry" functionality
        if last_processed_entry is not None:
            patient_name = row.get(reverse_mapping.get('Patient Name', ''), 'Unknown Patient')
            surgery_date = row.get('Surgery Date', 'Unknown Date')
            current_patient_context = {
                'patient_name': patient_name,
                'surgery_date': surgery_date,
                'last_field': last_processed_entry[0] if last_processed_entry else None,
                'last_value': last_processed_entry[1] if last_processed_entry else None,
                'row_index': current_row_index
            }
            try:
                if hasattr(CTX, 'current_patient_context'):
                    CTX.current_patient_context = current_patient_context
                else:
                    CTX['current_patient_context'] = current_patient_context
            except Exception:
                pass
        
        # Clear memory-accumulating structures while preserving F11 context above
        last_processed_entry = None
        parsed_address_components = {}
        try:
            if hasattr(CTX, 'last_processed_entry'):
                CTX.last_processed_entry = None
                CTX.parsed_address_components = {}
            else:
                CTX['last_processed_entry'] = None
                CTX['parsed_address_components'] = {}
        except Exception:
            pass
        
        # Handle script pause at the start of each row (patient record). 
        manage_script_pause(csv_data, error_message, reverse_mapping)
        error_message = ''  # Clear error message for the next iteration
        
        if _ac() and _ac().get_pause_status():
            continue  # Skip processing this row if the script is paused

        # I feel like this is overwriting what would have already been idenfitied in the mapping. 
        # This probably needs to be initialized differently.
        # Note: parsed_address_components is now explicitly cleared above for performance
        # parsed_address_components = {'City': '', 'State': '', 'Zip Code': ''}
        # parsed_address_components = {}  # Moved to top of loop for memory management

        # Process each field in the row
        action = iterate_fields(row, field_mapping, parsed_address_components, reverse_mapping, csv_data, fixed_values)
        # TODO (Low) add a feature here where if you accidentally started overwriting a patient that you could go back 2 patients.
        # Need to tell the user which patient we're talking about because it won't be obvious anymore.
        if action == -1:  # Retry
            continue  # Remain on the current row. 
        elif action == 1:  # Skip
            if current_row_index == len(csv_data) - 1:  # If it's the last row
                MediLink_ConfigLoader.log("Reached the end of the patient list.")
                print("Reached the end of the patient list. Looping back to the beginning.")
                current_row_index = 0  # Reset to the first row
            else:
                current_row_index += 1 # Move to the next row
            continue
        elif action == -2:  # Go back two patients and redo
            current_row_index = max(0, current_row_index - 2)  # Go back two rows, but not below 0
            continue

        # Row was entered without retry/skip: record charge-entry completion per DOS.
        _mark_charges_entered_if_possible(config, row, reverse_mapping)

        # Code to handle the end of a patient record
        # TODO One day this can just not pause...
        if _ac():
            _ac().set_pause_status(True)  # Pause at the end of processing each patient record
        
        # PERFORMANCE FIX: Explicit cleanup at end of patient processing
        # Clear global state to prevent accumulation over processing sessions
        # Note: current_patient_context is preserved for F11 menu functionality
        if current_row_index != len(csv_data) - 1:  # Not the last patient
            last_processed_entry = None
            parsed_address_components.clear()
            try:
                if hasattr(CTX, 'last_processed_entry'):
                    CTX.last_processed_entry = None
                    CTX.parsed_address_components = {}
                else:
                    CTX['last_processed_entry'] = None
                    CTX['parsed_address_components'] = {}
            except Exception:
                pass
            
        current_row_index += 1  # Move to the next row by default

def open_medisoft(shortcut_path):
    try:
        os.startfile(shortcut_path)
        print("Medisoft is being opened...\n")
    except subprocess.CalledProcessError as e:
        print("Failed to open Medisoft:", e)
        print("Please manually open Medisoft.")
    except Exception as e:
        print("An unexpected error occurred:", e)
        print("Please manually open Medisoft.")
    finally:
        print("Press 'F12' to begin data entry.")

# Placeholder for any cleanup
def cleanup():
    print("\n**** Medibot Finished! ****\n")
    # THis might need to delete the staging stuff that gets set up by mostly MediLink but maybe other stuff too.
    pass 

class ExecutionState:
    def __init__(self, config_path, crosswalk_path, preloaded_config=None, preloaded_crosswalk=None):
        """
        Initialize execution state with configuration.
        
        Args:
            config_path: Path to config file (used if preloaded_config is None)
            crosswalk_path: Path to crosswalk file (used if preloaded_crosswalk is None)
            preloaded_config: Optional pre-loaded config dict to avoid double-loading
            preloaded_crosswalk: Optional pre-loaded crosswalk dict to avoid double-loading
        """
        try:
            # Use pre-loaded values if provided, otherwise load from paths
            if preloaded_config is not None and preloaded_crosswalk is not None:
                config, crosswalk = preloaded_config, preloaded_crosswalk
                MediLink_ConfigLoader.log("Using pre-loaded configuration", level="DEBUG")
            else:
                config, crosswalk = MediLink_ConfigLoader.load_configuration(config_path, crosswalk_path)
                MediLink_ConfigLoader.log("Loaded configuration from paths", level="DEBUG")
            
            MediLink_ConfigLoader.log("Configuration type: {}".format(type(config)), level="DEBUG")
            self.verify_config_type(config)
            self.crosswalk = crosswalk
            self.config = config
            MediLink_ConfigLoader.log("Config loaded successfully...")

            # Get APIClient via factory
            try:
                from MediCafe.api_factory import APIClientFactory
                factory = APIClientFactory()
                self.api_client = factory.get_shared_client()  # Use shared client for token caching benefits
                MediLink_ConfigLoader.log("ExecutionState using API Factory with shared client", level="INFO")
            except ImportError as e:
                # Fallback to basic API client
                try:
                    from MediCafe.core_utils import get_api_client
                    self.api_client = get_api_client()
                    MediLink_ConfigLoader.log("ExecutionState using fallback API client", level="WARNING")
                except ImportError as e2:
                    self.api_client = None
            
            # Log before calling crosswalk_update
            if self.api_client is not None:
                MediLink_ConfigLoader.log("Updating crosswalk with client and config...", level="INFO")
                update_successful = crosswalk_update(self.api_client, config, crosswalk)
            else:
                MediLink_ConfigLoader.log("Skipping crosswalk update - API client not available", level="WARNING")
                update_successful = False
            if update_successful:
                MediLink_ConfigLoader.log("Crosswalk update completed successfully.", level="INFO")
                print("Crosswalk update completed successfully.")
            else:
                record_startup_error("Crosswalk update failed.")
            
            # Check for non-normal conditions from crosswalk update
            try:
                if MediBot_Crosswalk_Library and hasattr(MediBot_Crosswalk_Library, '_api_unavailability_detected'):
                    # Check if any endpoint is unavailable (set is truthy if non-empty)
                    if MediBot_Crosswalk_Library._api_unavailability_detected:
                        mark_non_normal_startup()
                if MediBot_Crosswalk_Library and hasattr(MediBot_Crosswalk_Library, '_mains_data_load_failed'):
                    if MediBot_Crosswalk_Library._mains_data_load_failed:
                        mark_non_normal_startup()
                if MediBot_Preprocessor_lib and hasattr(MediBot_Preprocessor_lib, '_mains_file_missing'):
                    if MediBot_Preprocessor_lib._mains_file_missing:
                        mark_non_normal_startup()
            except Exception:
                pass  # Don't let flag checking break startup

        except Exception as e:
            record_startup_error("MediBot: Failed to load or update configuration: {}".format(e))
            raise  # Re-throwing the exception or using a more sophisticated error handling mechanism might be needed
            # Handle the exception somehow (e.g., retry, halt, log)??
        
    def verify_config_type(self, config):
        MediLink_ConfigLoader.log("Verifying configuration type: {}".format(type(config)), level="DEBUG")
        if not isinstance(config, (dict, OrderedDict)):
            raise TypeError("Error: Configuration must be a dictionary or an OrderedDict. Check unpacking.")

# Import centralized logging configuration and timing utils
try:
    from MediCafe.logging_config import PERFORMANCE_LOGGING
except ImportError:
    PERFORMANCE_LOGGING = False
try:
    from MediCafe.timing_utils import start_run, stage_timer, noop_timer, is_timing_enabled, get_storage_path
except ImportError:
    start_run = None
    stage_timer = None
    noop_timer = type('_Noop', (), {'__enter__': lambda self: self, '__exit__': lambda self, *a: False})()
    is_timing_enabled = None
    get_storage_path = None

# Main script execution wrapped in try-except for error handling
if __name__ == "__main__":
    # Install unhandled exception hook to capture tracebacks
    try:
        if capture_unhandled_traceback is not None:
            sys.excepthook = capture_unhandled_traceback
    except Exception:
        pass

    e_state = None
    try:
        if PERFORMANCE_LOGGING:
            print("Initializing. Loading configuration and preparing environment...")
        
        # PROTECTION: Validate critical imports before proceeding
        import_valid, import_state = validate_critical_imports()
        if not import_valid:
            print("CRITICAL: Import validation failed. Cannot continue.")
            print("This indicates a fundamental system configuration issue.")
            print("Please check:")
            print("  1. All MediBot modules exist in the MediBot directory")
            print("  2. Python path is correctly configured")
            print("  3. No syntax errors in MediBot modules")
            sys.exit(1)
        
        # Default configuration paths
        json_dir = os.path.join(os.path.dirname(__file__), '..', 'json')
        default_config_path = os.path.join(json_dir, 'config.json')
        default_crosswalk_path = os.path.join(json_dir, 'crosswalk.json')
        
        # Use MediCafe configuration system
        preloaded_config, preloaded_crosswalk = None, None
        config_path, crosswalk_path = None, None
        
        try:
            config_loader = get_config_loader_with_fallback()
            if config_loader and len(sys.argv) <= 1:
                preloaded_config, preloaded_crosswalk = config_loader.load_configuration()
            else:
                config_path = sys.argv[1] if len(sys.argv) > 1 else default_config_path
        except Exception:
            mark_non_normal_startup()  # Configuration loading failed
            config_path = sys.argv[1] if len(sys.argv) > 1 else default_config_path
        
        # Define crosswalk path if not pre-loaded
        if preloaded_crosswalk is None:
            crosswalk_path = sys.argv[2] if len(sys.argv) > 2 else default_crosswalk_path
        
        e_state = ExecutionState(config_path, crosswalk_path, preloaded_config, preloaded_crosswalk)
        
        # Phase 3: Check and update OPTUMAI payer list (non-blocking)
        try:
            from MediCafe.payer_list_updater import update_optumai_payer_ids
            # Reuse ExecutionState's shared client for token caching benefits
            if e_state.api_client is not None:
                update_optumai_payer_ids(e_state.api_client, e_state.config, e_state.crosswalk, force=False)
        except Exception:
            mark_non_normal_startup()  # OPTUMAI payer list update failed
            # Silently skip on any error (non-blocking)
            pass
        
        # Initialize constants from config
        MediBot_Preprocessor_lib.initialize(e_state.config)
        
        # PERFORMANCE OPTIMIZATION: Load both Medicare and Private patient databases during startup
        # Files are small (10K-20K rows each) so memory usage is minimal (~4MB total)
        # This eliminates the 1-2 second delay from user workflow entirely
        print("Loading patient databases...")
        MediLink_ConfigLoader.log("Loading patient databases...", level="INFO")
        
        try:
            medicare_path = e_state.config.get('MEDICARE_MAPAT_MED_PATH', "")
            private_path = e_state.config.get('MAPAT_MED_PATH', "")
            
            # Load both databases into separate caches
            medicare_cache = MediBot_Preprocessor.load_existing_patient_ids(medicare_path) if medicare_path else {}
            private_cache = MediBot_Preprocessor.load_existing_patient_ids(private_path) if private_path else {}
            
            # Store both caches for later use
            MediBot_Preprocessor.set_patient_caches(medicare_cache, private_cache)
            
            if PERFORMANCE_LOGGING:
                print("Patient databases loaded: {} Medicare, {} Private patients".format(
                    len(medicare_cache), len(private_cache)))
            MediLink_ConfigLoader.log("Patient databases loaded: {} Medicare, {} Private patients".format(
                len(medicare_cache), len(private_cache)), level="INFO")
                
        except Exception as e:
            mark_non_normal_startup()  # Patient database loading failed
            MediLink_ConfigLoader.log("Warning: Could not load patient databases: {}".format(e), level="WARNING")
            if PERFORMANCE_LOGGING:
                print("Warning: Could not load patient databases - will load on demand")
        
        if PERFORMANCE_LOGGING:
            print("Loading CSV Data...")
        MediLink_ConfigLoader.log("Loading CSV Data...", level="INFO")
        csv_data = MediBot_Preprocessor_lib.load_csv_data(MediBot_Preprocessor_lib.CSV_FILE_PATH)
        
        # Pre-process CSV data to add combined fields & crosswalk values
        if PERFORMANCE_LOGGING:
            print("Pre-Processing CSV...")
        MediLink_ConfigLoader.log("Pre-processing CSV Data...", level="INFO")
        
        preprocessing_start_time = time.time()
        if PERFORMANCE_LOGGING:
            print("Starting CSV preprocessing at: {}".format(time.strftime("%H:%M:%S")))
        MediLink_ConfigLoader.log("Starting CSV preprocessing at: {}".format(time.strftime("%H:%M:%S")), level="INFO")

        _storage = get_storage_path(config=e_state.config, repo_root=project_dir) if get_storage_path else None
        run_id = start_run('medibot', storage_path=_storage) if (start_run and is_timing_enabled and is_timing_enabled()) else None
        _ctx = stage_timer(run_id, 'medibot', 'csv_preprocessing') if (run_id and stage_timer) else noop_timer

        # PROTECTION: Validate MediBot_Preprocessor before calling preprocess_csv_data
        if MediBot_Preprocessor is None:
            print("CRITICAL: MediBot_Preprocessor is None when trying to call preprocess_csv_data")
            print("This indicates the import failed silently during execution.")
            print("Import state at failure:")
            for module_name, module in import_state.items():
                status = "None" if module is None else "OK"
                print("  - {}: {}".format(module_name, status))
            print("Please check for syntax errors or missing dependencies in MediBot modules.")
            sys.exit(1)
        
        if not hasattr(MediBot_Preprocessor, 'preprocess_csv_data'):
            print("CRITICAL: MediBot_Preprocessor missing preprocess_csv_data function")
            print("Available functions: {}".format([attr for attr in dir(MediBot_Preprocessor) if not attr.startswith('_')]))
            sys.exit(1)

        with _ctx:
            MediBot_Preprocessor.preprocess_csv_data(csv_data, e_state.crosswalk)

        # TIMING: End CSV preprocessing timing
        preprocessing_end_time = time.time()
        preprocessing_duration = preprocessing_end_time - preprocessing_start_time
        if PERFORMANCE_LOGGING:
            print("CSV preprocessing completed at: {} (Duration: {:.2f} seconds)".format(
                time.strftime("%H:%M:%S"), preprocessing_duration))
        MediLink_ConfigLoader.log("CSV preprocessing completed at: {} (Duration: {:.2f} seconds)".format(
            time.strftime("%H:%M:%S"), preprocessing_duration), level="INFO")

        if _handle_empty_preprocessed_csv(csv_data):
            try:
                from MediCafe.action_intent import (
                    mark_user_exit,
                    ACTION_EXIT_REASON_INTAKE_CSV_SHAPE_BLOCKED,
                    ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS,
                )
                reason = ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS
                if _empty_preprocessed_csv_shape_blocked():
                    reason = ACTION_EXIT_REASON_INTAKE_CSV_SHAPE_BLOCKED
                mark_user_exit(reason)
            except Exception:
                pass
            print("")
            if _empty_preprocessed_csv_shape_blocked():
                print("MediBot cannot continue: CSV_FILE_PATH does not look like the MediBot intake CSV.")
            else:
                print("MediBot cannot continue: no eligible patient rows remain after preprocessing.")
            print("Check: Patient ID column name (must match intake export, e.g. 'Patient ID'),")
            print("insurance exclusions, and CSV_FILE_PATH in config. Full filter summary is in the log.")
            print("")
            try:
                raw_input("Press Enter to return to the launcher...")
            except Exception:
                try:
                    input("Press Enter to return to the launcher...")
                except Exception:
                    pass
            sys.exit(0)
        
        headers = csv_data[0].keys()  # Ensure all headers are in place
        
        print("Running intake scan...")
        MediLink_ConfigLoader.log("Performing Intake Scan...", level="INFO")
        identified_fields = MediBot_Preprocessor.intake_scan(headers, MediBot_Preprocessor_lib.field_mapping)
        
        # Reverse the identified_fields mapping for lookup
        reverse_mapping = {v: k for k, v in identified_fields.items()}
        service_line_input_session_patient_info = build_service_line_input_session_patient_info_from_csv_rows(
            csv_data,
            reverse_mapping
        )
        
        # CSV Patient Triage
        interaction_mode = 'triage'  # Start in triage mode
        error_message = ""  # This will be filled if an error has occurred
        
        print("Load complete.")
        MediLink_ConfigLoader.log("Load Complete event triggered. Clearing console. Displaying Menu...", level="INFO")
        
        # If non-normal startup conditions were detected, pause before clearing screen
        if _non_normal_startup:
            print("\n" + "="*70)
            print("NON-NORMAL STARTUP CONDITIONS DETECTED")
            print("="*70)
            print("One or more issues were encountered during startup.")
            print("Please review the messages above before continuing.")
            print("="*70)
            raw_input("\nPress Enter to continue to the menu...")
        
        # Windows XP console buffer fix: Use cls with echo to reset buffer state
        # Add a debug switch to optionally skip clearing the console for debugging purposes
        CLEAR_CONSOLE_ON_LOAD = True  # Clear screen before menu for cleaner UI
        if CLEAR_CONSOLE_ON_LOAD:
            _ = os.system('cls && echo.')
            # Re-display critical startup notices so the user still sees them
            if STARTUP_NOTICES:
                print("Important notices from startup:")
                for lvl, msg in STARTUP_NOTICES:
                    try:
                        print("[{}] {}".format(lvl, msg))
                    except Exception:
                        print(msg)
                print("-" * 60)
        
        proceed, selected_patient_ids, selected_indices, fixed_values, is_medicare = user_interaction(csv_data, interaction_mode, error_message, reverse_mapping)

        if proceed:
            # NOTE: Deductible v1.5 cache build happens during CSV intake (process_csvs),
            # not in this post-triage execution path.
            # Filter csv_data for selected patients from Triage mode
            csv_data = [row for index, row in enumerate(csv_data) if index in selected_indices]
            patient_id_field = reverse_mapping.get('Patient ID #2', '')
            rows_by_patient_id = {}
            if patient_id_field:
                for row in csv_data:
                    pid = row.get(patient_id_field)
                    if pid and pid not in rows_by_patient_id:
                        rows_by_patient_id[pid] = row
            
            # Check if MAPAT_MED_PATH is missing or invalid
            if (not _ac()) or (not _ac().get_mapat_med_path()) or (not os.path.exists(_ac().get_mapat_med_path())):
                record_startup_warning("Warning: MAPAT.MED PATH is missing or invalid. Please check the path configuration.")

            # PERFORMANCE OPTIMIZATION: Select the appropriate pre-loaded patient cache
            # Both caches were loaded during startup, now we just select the right one
            _run_with_stage_heartbeat(
                "Selecting {} patient cache".format("Medicare" if is_medicare else "Private"),
                lambda: MediBot_Preprocessor.select_active_cache(is_medicare)
            )
            if PERFORMANCE_LOGGING:
                print("Using {} patient cache for existing patient check".format("Medicare" if is_medicare else "Private"))

            # Perform the existing patients check (now uses cached data)
            existing_patients, patients_to_process = _run_with_stage_heartbeat(
                "Checking existing patients",
                lambda: MediBot_Preprocessor.check_existing_patients(
                    selected_patient_ids,
                    _ac().get_mapat_med_path() if _ac() else ''
                )
            )
            
            # Initialize patient_info and table_title for notepad generation
            # These may be populated by existing_patients or remain empty
            patient_type = "MEDICARE" if is_medicare else "PRIVATE"
            patient_info = []
            table_title = "{} PATIENTS - EXISTING: No existing patients in this batch.".format(patient_type)
            
            if existing_patients:
                # Collect surgery dates and patient info for existing patients
                for patient_id, patient_name in existing_patients:
                    try:
                        # Find the row for this patient
                        patient_row = rows_by_patient_id.get(patient_id)
                        if patient_row is None:
                            raise ValueError("Patient row not found for patient ID: {}".format(patient_id))
                        
                        # Use helper function to create patient entries
                        patient_entries = create_patient_entries_from_row(patient_row, reverse_mapping)
                        patient_info.extend(patient_entries)
                            
                    except Exception as e:
                        MediLink_ConfigLoader.log("Warning: Error retrieving data for patient ID '{}': {}".format(patient_id, e), level="WARNING")
                        patient_info.append(('Unknown Date', patient_name, patient_id, 'N/A', None))  # Append with 'Unknown Date' if there's an error

                # Display existing patients table using the enhanced display function
                table_title = "{} PATIENTS - EXISTING: The following patient(s) already EXIST in the system but may have new dates of service.\n      Their diagnosis codes may need to be updated manually by the user to the following list:".format(patient_type)
                _run_with_stage_heartbeat(
                    "Rendering existing-patient table",
                    lambda: MediBot_UI.display_enhanced_patient_table(
                        patient_info,
                        table_title,
                        show_line_numbers=False,
                        config=e_state.config
                    )
                )
                
                # Existing patients should be shown in Notepad/reference tables only.
                # AHK intake must remain strictly limited to NEW patients to avoid
                # re-entering records that already exist in Medisoft.
                patients_to_process_set = set(patients_to_process)
                csv_data = [row for row in csv_data if row.get(patient_id_field) in patients_to_process_set]

            # Identify dual-date NEW patients for anticipatory display
            dual_date_new_patients = []
            for row in csv_data:
                if len(row.get('_all_surgery_dates', [])) > 1:
                    patient_entries = create_patient_entries_from_row(row, reverse_mapping)
                    dual_date_new_patients.extend(patient_entries)
            
            # Define dual-date title once if needed
            dual_date_title = "{} PATIENTS - DUAL DATE-OF-SERVICE (ANTICIPATORY): These patients have multiple dates of service.\n      After the first date is entered via AHK, they will become EXISTING patients and may need manual diagnosis updates:".format(patient_type) if dual_date_new_patients else None

            # Generate notepad file if there's content to display
            if patient_info or dual_date_new_patients:
                try:
                    if dual_date_new_patients:
                        notepad_file_path = _run_with_stage_heartbeat(
                            "Generating combined notepad reference table",
                            lambda: MediBot_Notepad_Utils.generate_combined_patients_notepad(
                                patient_info, table_title, dual_date_new_patients, dual_date_title, config=e_state.config
                            )
                        )
                    elif patient_info:
                        notepad_file_path = _run_with_stage_heartbeat(
                            "Generating existing-patient notepad reference table",
                            lambda: MediBot_Notepad_Utils.generate_existing_patients_notepad(
                                patient_info,
                                table_title,
                                config=e_state.config
                            )
                        )
                    else:
                        notepad_file_path = None

                    if notepad_file_path:
                        print("Patient reference table saved and opened in notepad: {}".format(notepad_file_path))
                except Exception as e:
                    print("Warning: Error creating notepad file: {}".format(e))

            # Display dual-date patients table on screen
            if dual_date_new_patients:
                _run_with_stage_heartbeat(
                    "Rendering dual-date anticipatory table",
                    lambda: MediBot_UI.display_enhanced_patient_table(
                        dual_date_new_patients,
                        dual_date_title,
                        show_line_numbers=False,
                        config=e_state.config
                    )
                )

            # Show NEW patients that will be processed (if any)
            new_patient_info = []
            if patients_to_process:
                # Collect surgery dates and patient info for NEW patients
                for row in csv_data:
                    # Use helper function to create patient entries
                    patient_entries = create_patient_entries_from_row(row, reverse_mapping)
                    new_patient_info.extend(patient_entries)

                # Display new patients table using the enhanced display function
                _run_with_stage_heartbeat(
                    "Rendering new-patient intake table",
                    lambda: MediBot_UI.display_enhanced_patient_table(
                        new_patient_info,
                        "{} PATIENTS - NEW: The following patient(s) will be automatically entered into Medisoft:".format(patient_type),
                        show_line_numbers=True,
                        config=e_state.config
                    )
                )

            service_line_input_patient_info = service_line_input_session_patient_info or new_patient_info
            service_line_input_docx_groups_available = False
            try:
                service_line_input_docx_groups_available = bool(
                    build_service_line_input_dos_groups_from_docx_index(
                        service_line_input_patient_info,
                        e_state.config
                    )
                )
            except Exception:
                service_line_input_docx_groups_available = False

            # Check if there are patients left to process
            if len(patients_to_process) == 0:
                if service_line_input_docx_groups_available:
                    try_preview = (input(
                        "\nOptional preview: open Service Line Input screen now? [y/N]: "
                    ) or "n").strip().lower()
                    if try_preview in ['y', 'yes']:
                        try:
                            run_service_line_input_multi_dos_entry(
                                service_line_input_patient_info,
                                e_state.config,
                                crosswalk=e_state.crosswalk
                            )
                        except Exception as e:
                            MediLink_ConfigLoader.log(
                                "Service Line Input failed: {}".format(e),
                                level="WARNING"
                            )
                proceed = input("\nAll patients have been processed. Continue anyway?: ").lower().strip() in ['yes', 'y']
            else:
                try_preview = (input(
                    "\nOptional preview: open Service Line Input screen now? [y/N]: "
                ) or "n").strip().lower()
                if try_preview in ['y', 'yes']:
                    try:
                        run_service_line_input_multi_dos_entry(
                            service_line_input_patient_info,
                            e_state.config,
                            crosswalk=e_state.crosswalk
                        )
                    except Exception as e:
                        MediLink_ConfigLoader.log(
                            "Service Line Input failed: {}".format(e),
                            level="WARNING"
                        )
                proceed = input("\nDo you want to proceed with entering {} new patient(s) into Medisoft? (yes/no): ".format(len(patients_to_process))).lower().strip() in ['yes', 'y']

            # Legacy MediBot_Charges / MediLink_Charges enrichment was quarantined.
            # Current charge work must stay on the Service Line Input preview-only boundary
            # unless a separate tested charge-entry workflow is designed.

            if proceed:
                print("\nRemember, when in Medisoft:")
                print("  Press 'F8'  to create a New Patient.")
                print("  Press 'F12' to begin data entry.")
                print("  Press 'F11' at any time to Pause.")
                print("\n*** Press [Enter] when ready to begin! ***")
                input()
                MediLink_ConfigLoader.log("Opening Medisoft...")
                open_medisoft(_ac().get_medisoft_shortcut() if _ac() else '')
                if _ac():
                    _ac().set_pause_status(True)
                _ = manage_script_pause(csv_data, error_message, reverse_mapping)
                data_entry_loop(
                    csv_data,
                    MediBot_Preprocessor_lib.field_mapping,
                    reverse_mapping,
                    fixed_values,
                    config=e_state.config
                )
                cleanup()                
            else:
                print("Data entry canceled by user. Exiting MediBot.")
    except Exception as e:
        if e_state:
            interaction_mode = 'error'  # Switch to error mode
            error_message = str(e)  # Capture the error message
        
        # ENHANCED ERROR DIAGNOSTICS
        print("\n" + "="*60)
        print("MEDIBOT EXECUTION FAILURE")
        print("=" * 60)
        print("Error: {}".format(e))
        print("Error type: {}".format(type(e).__name__))
        
        # Check for the specific failure pattern
        if "'NoneType' object has no attribute" in str(e):
            print("DIAGNOSIS: This is the import failure pattern.")
            print("A module import returned None, causing a method call to fail.")
            print("This typically indicates:")
            print("  1. Syntax error in a MediBot module")
            print("  2. Missing dependency")
            print("  3. Import path issue")
            print("  4. Circular import problem")
            
            # Show current import state
            print("Current import state:")
            try:
                import_state = {
                    'MediBot_Preprocessor': MediBot_Preprocessor,
                    'MediBot_Preprocessor_lib': MediBot_Preprocessor_lib,
                    'MediBot_UI': MediBot_UI,
                    'MediBot_Crosswalk_Library': MediBot_Crosswalk_Library
                }
                for module_name, module in import_state.items():
                    status = "None" if module is None else "OK"
                    print("  - {}: {}".format(module_name, status))
            except Exception as diag_e:
                print("  - Unable to diagnose import state: {}".format(diag_e))
        
        print("=" * 60)

        # Collect and submit error report
        try:
            if submit_support_bundle_email is not None:
                from MediCafe.error_reporter import collect_support_bundle, optional_error_report_manifest
                zip_path = collect_support_bundle(
                    include_traceback=True,
                    evidence_manifest=optional_error_report_manifest('medibot_startup_import_failure'),
                )
                if zip_path:
                    try:
                        from MediCafe.core_utils import check_internet_connection
                        online = check_internet_connection()
                    except ImportError:
                        # If we can't check connectivity during error reporting, assume offline
                        # to preserve the error bundle for later
                        online = False
                        print("Warning: Could not check internet connectivity - preserving error bundle.")
                    if online:
                        success = submit_support_bundle_email(zip_path)
                        if success:
                            # On success, remove the bundle
                            try:
                                os.remove(zip_path)
                            except Exception:
                                pass
                        else:
                            # Preserve bundle for manual retry
                            print("Error report send failed - bundle preserved at {} for retry.".format(zip_path))
                    else:
                        print("Offline - error bundle queued at {} for retry when online.".format(zip_path))
                else:
                    print("Failed to create error report bundle.")
            else:
                print("Error reporting not available - check MediCafe installation.")
        except Exception as report_e:
            print("Error report collection failed: {}".format(report_e))

        # Handle the error by calling user interaction with the error information
        if 'identified_fields' in locals():
            _ = user_interaction(csv_data, interaction_mode, error_message, reverse_mapping)
        else:
            print("Please ensure CSV headers match expected field names in config file, then re-run Medibot.")
