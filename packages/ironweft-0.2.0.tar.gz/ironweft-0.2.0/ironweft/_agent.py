from __future__ import annotations
import functools
from typing import TYPE_CHECKING
from ._exceptions import AuthorizationDenied, AgentSuspended, AgentRetired

if TYPE_CHECKING:
    from ._client import Client


class AgentHandle:
    """
    A client scoped to a specific agent_id.

    Obtained via ``client.agent("agt_xxx")`` — not instantiated directly.
    """

    def __init__(self, client: "Client", agent_id: str):
        self._client = client
        self._agent_id = agent_id

    # ── credential ─────────────────────────────────────────────────────────────

    def credential(
        self,
        scopes: list[str],
        ttl_minutes: int = 15,
        context: dict | None = None,
    ) -> str:
        """Issue a short-lived credential. Returns the raw JWT string."""
        resp = self._client.issue_credential(
            agent_id=self._agent_id,
            scopes=scopes,
            ttl_minutes=ttl_minutes,
            context=context,
        )
        return resp["credential"]

    # ── authorize ──────────────────────────────────────────────────────────────

    def check(
        self,
        action: str,
        credential: str,
        resource: str = "",
        parameters: dict | None = None,
    ) -> dict:
        """
        Call /authorize and return the response.
        Raises AuthorizationDenied, AgentSuspended, or AgentRetired on non-allow decisions.
        """
        resp = self._client.authorize(
            credential=credential,
            action=action,
            resource=resource,
            parameters=parameters,
        )
        decision = resp.get("decision", "deny")

        if decision == "retired":
            raise AgentRetired(f"Agent {self._agent_id} is hard-locked and cannot act")
        if decision == "suspended":
            raise AgentSuspended(
                action=action,
                agent_id=self._agent_id,
                reason=resp.get("reason", ""),
                audit_event_id=resp.get("audit_event_id", ""),
            )
        if decision != "allow":
            raise AuthorizationDenied(
                action=action,
                agent_id=self._agent_id,
                reason=resp.get("reason", ""),
                audit_event_id=resp.get("audit_event_id", ""),
            )
        return resp

    def batch(
        self,
        actions: list[dict],
        credential: str,
        *,
        skip_cache: bool = False,
    ) -> dict:
        """
        Evaluate multiple actions in one request.

        Cached allows are served locally; the rest are batched into a single
        API call. Raises AuthorizationDenied if any action is denied or challenged
        — check the raw response via client.authorize_batch() if you need
        per-action control flow.

        Returns the full batch response: {results, summary}.
        """
        return self._client.authorize_batch(
            credential=credential,
            actions=actions,
            skip_cache=skip_cache,
        )

    def gate(
        self,
        action: str,
        scopes: list[str],
        resource: str = "",
        ttl_minutes: int = 15,
    ):
        """
        Decorator. Issues a fresh credential and calls /authorize before each
        invocation. The wrapped function only runs on an explicit allow decision.

        Usage::

            agent = client.agent("agt_4ae283ac")

            @agent.gate("payment.send", scopes=["payments:write"])
            def send_payment(amount, account_id):
                ...
        """
        def decorator(fn):
            @functools.wraps(fn)
            def wrapper(*args, **kwargs):
                cred = self.credential(scopes=scopes, ttl_minutes=ttl_minutes)
                self.check(action=action, credential=cred, resource=resource)
                return fn(*args, **kwargs)
            return wrapper
        return decorator

    # ── lifecycle ──────────────────────────────────────────────────────────────

    def suspend(self) -> dict:
        """Manually suspend this agent."""
        return self._client.update_agent_status(self._agent_id, "suspended")

    def reactivate(self) -> dict:
        """Reactivate a suspended agent."""
        return self._client.update_agent_status(self._agent_id, "active")

    def retire(self) -> dict:
        """Hard-lock this agent. Irreversible."""
        return self._client.update_agent_status(self._agent_id, "retired")

    # ── inspection ─────────────────────────────────────────────────────────────

    def permissions(self) -> dict:
        """Return current status, roles, and metadata for this agent."""
        return self._client.get_agent(self._agent_id)

    def audit_trail(self, limit: int = 50) -> list[dict]:
        """Return the tamper-evident audit trail for this agent."""
        return self._client.get_audit_trail(agent_id=self._agent_id, limit=limit)
