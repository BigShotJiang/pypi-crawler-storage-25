from __future__ import annotations
import httpx
from ._cache import AuthCache
from ._exceptions import IronWeftError


class Client:
    """
    IronWeft API client.

    Usage::

        from ironweft import Client

        client = Client(api_key="iw_live_xxx")
        agent  = client.agent("agt_4ae283ac")

    Cache:
        authorize() results are cached in-process by default. Only 'allow'
        decisions are cached; deny and challenge always round-trip. TTL is
        bound to the credential's JWT expiry. Disable with cache=False.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://ironweft.io",
        cache: bool = True,
    ):
        if not api_key:
            raise IronWeftError("api_key is required")
        self._api_key  = api_key
        self._base_url = base_url.rstrip("/")
        self._headers  = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type":  "application/json",
        }
        self._cache: AuthCache | None = AuthCache() if cache else None

    # ── internal ──────────────────────────────────────────────────────────────

    def _request(self, method: str, path: str, **kwargs) -> dict:
        with httpx.Client(timeout=10.0) as http:
            resp = http.request(
                method,
                f"{self._base_url}{path}",
                headers=self._headers,
                **kwargs,
            )
        try:
            data = resp.json()
        except Exception:
            data = {"detail": resp.text}

        if resp.status_code >= 400:
            raise IronWeftError(
                f"IronWeft API {resp.status_code}: {data.get('detail', resp.text)}"
            )
        return data

    # ── agents ────────────────────────────────────────────────────────────────

    def register_agent(
        self,
        name: str,
        sponsor_id: str,
        roles: list[str] | None = None,
        description: str = "",
        metadata: dict | None = None,
    ) -> dict:
        """Register a new agent. Returns agent_id, public_key, status."""
        return self._request("POST", "/agents", json={
            "agent_name":   name,
            "sponsor_id":   sponsor_id,
            "initial_roles": roles or [],
            "description":  description,
            "metadata":     metadata or {},
        })

    def get_agent(self, agent_id: str) -> dict:
        """Fetch an agent's current status, roles, and metadata."""
        return self._request("GET", f"/agents/{agent_id}/permissions")

    def update_agent_status(self, agent_id: str, status: str) -> dict:
        """Set agent status: active | suspended | retired."""
        return self._request("PATCH", f"/agents/{agent_id}", json={"status": status})

    # ── credentials ───────────────────────────────────────────────────────────

    def issue_credential(
        self,
        agent_id: str,
        scopes: list[str],
        ttl_minutes: int = 15,
        context: dict | None = None,
    ) -> dict:
        """Issue a short-lived scoped JWT. Returns credential, expires_at, scopes."""
        return self._request("POST", "/agents/credentials", json={
            "agent_id":   agent_id,
            "scopes":     scopes,
            "ttl_minutes": ttl_minutes,
            "context":    context or {},
        })

    # ── authorize ─────────────────────────────────────────────────────────────

    def authorize(
        self,
        credential: str,
        action: str,
        resource: str = "",
        parameters: dict | None = None,
        context: dict | None = None,
        initiator: str | None = None,
        *,
        skip_cache: bool = False,
    ) -> dict:
        """
        Check policy before an agent action.

        Returns decision, reason, allowed_scopes, audit_event_id.
        allow decisions are cached in-process (TTL = credential expiry).
        Pass skip_cache=True to force a live round-trip (e.g. after a policy change).
        """
        params = parameters or {}

        if self._cache and not skip_cache:
            cached = self._cache.get(credential, action, resource, params)
            if cached is not None:
                return cached

        result = self._request("POST", "/authorize", json={
            "credential": credential,
            "action":     action,
            "resource":   resource,
            "parameters": params,
            "context":    context or {},
            **({"initiator": initiator} if initiator else {}),
        })

        if self._cache and result.get("decision") == "allow":
            self._cache.set(credential, action, resource, params, result)

        return result

    def authorize_batch(
        self,
        credential: str,
        actions: list[dict],
        *,
        skip_cache: bool = False,
    ) -> dict:
        """
        Evaluate up to 50 actions in a single request.

        Each action dict: {action, resource?, parameters?, context?, initiator?, ref?}
        Cached 'allow' decisions are served locally; uncached actions are
        bundled into a single batch request. Returns the full batch response
        shape: {results: [...], summary: {...}}.

        Pass skip_cache=True to force all actions to round-trip.
        """
        if not actions:
            return {"results": [], "summary": {"total": 0, "allow": 0, "deny": 0, "challenge": 0}}

        results: list[dict | None] = [None] * len(actions)
        uncached_indices: list[int] = []

        # Serve cached allows locally
        if self._cache and not skip_cache:
            for i, a in enumerate(actions):
                cached = self._cache.get(
                    credential,
                    a["action"],
                    a.get("resource", ""),
                    a.get("parameters") or {},
                )
                if cached is not None:
                    results[i] = {
                        "ref":            a.get("ref"),
                        "action":         a["action"],
                        "decision":       cached["decision"],
                        "reason":         cached.get("reason", ""),
                        "audit_event_id": cached.get("audit_event_id"),
                        "_cached":        True,
                    }
                else:
                    uncached_indices.append(i)
        else:
            uncached_indices = list(range(len(actions)))

        # Batch request for uncached items
        if uncached_indices:
            batch_actions = []
            for i in uncached_indices:
                a = actions[i]
                item: dict = {
                    "action":   a["action"],
                    "resource": a.get("resource", ""),
                }
                if a.get("parameters"):
                    item["parameters"] = a["parameters"]
                if a.get("context"):
                    item["context"] = a["context"]
                if a.get("initiator"):
                    item["initiator"] = a["initiator"]
                if a.get("ref") is not None:
                    item["ref"] = a["ref"]
                batch_actions.append(item)

            resp = self._request("POST", "/authorize/batch", json={
                "credential": credential,
                "actions":    batch_actions,
            })

            for j, i in enumerate(uncached_indices):
                r = resp["results"][j]
                results[i] = r
                if self._cache and r.get("decision") == "allow":
                    a = actions[i]
                    self._cache.set(
                        credential,
                        a["action"],
                        a.get("resource", ""),
                        a.get("parameters") or {},
                        r,
                    )

        final = [r for r in results if r is not None]
        allow_ct     = sum(1 for r in final if r["decision"] == "allow")
        deny_ct      = sum(1 for r in final if r["decision"] == "deny")
        challenge_ct = sum(1 for r in final if r["decision"] == "challenge")

        return {
            "results": final,
            "summary": {
                "total":     len(final),
                "allow":     allow_ct,
                "deny":      deny_ct,
                "challenge": challenge_ct,
            },
        }

    def invalidate_cache(self, credential: str | None = None) -> None:
        """
        Evict cached decisions. Pass a credential to evict only that credential's
        entries (e.g. after receiving a policy-change webhook). Omit to clear all.
        """
        if self._cache is None:
            return
        if credential:
            self._cache.invalidate_credential(credential)
        else:
            self._cache.clear()

    # ── audit ─────────────────────────────────────────────────────────────────

    def get_audit_trail(
        self,
        agent_id: str | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """Fetch tamper-evident audit events, optionally filtered by agent."""
        params: dict = {"limit": limit}
        if agent_id:
            params["agent_id"] = agent_id
        return self._request("GET", "/audit", params=params)

    # ── agent handle ──────────────────────────────────────────────────────────

    def agent(self, agent_id: str) -> "AgentHandle":
        """Return a handle scoped to a specific agent for cleaner call chains."""
        from ._agent import AgentHandle
        return AgentHandle(client=self, agent_id=agent_id)
