from __future__ import annotations
import base64
import json
import time
import threading


def _jwt_exp(token: str) -> float:
    try:
        payload = token.split(".")[1]
        payload += "=" * (4 - len(payload) % 4)
        data = json.loads(base64.urlsafe_b64decode(payload))
        return float(data.get("exp", 0))
    except Exception:
        return 0.0


class AuthCache:
    """
    In-process cache for IronWeft allow decisions.

    Only caches 'allow' — deny and challenge are never served from cache.
    TTL is bound to the credential's JWT expiry so a cached allow can
    never outlive the credential that earned it.

    Thread-safe. One instance per Client.
    """

    def __init__(self) -> None:
        self._store: dict[tuple, tuple[dict, float]] = {}
        self._lock = threading.Lock()

    @staticmethod
    def _key(credential: str, action: str, resource: str, parameters: dict) -> tuple:
        return (credential, action, resource, json.dumps(parameters, sort_keys=True))

    def get(self, credential: str, action: str, resource: str, parameters: dict) -> dict | None:
        key = self._key(credential, action, resource, parameters)
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            response, expires_at = entry
            if time.time() >= expires_at:
                del self._store[key]
                return None
            return {**response, "_cached": True}

    def set(self, credential: str, action: str, resource: str, parameters: dict, response: dict) -> None:
        exp = _jwt_exp(credential)
        if exp <= time.time():
            return  # credential already expired — don't cache
        key = self._key(credential, action, resource, parameters)
        with self._lock:
            self._store[key] = (response, exp)

    def invalidate_credential(self, credential: str) -> None:
        """Evict all entries for a given credential. Call when you know policy changed."""
        with self._lock:
            keys = [k for k in self._store if k[0] == credential]
            for k in keys:
                del self._store[k]

    def clear(self) -> None:
        with self._lock:
            self._store.clear()

    def size(self) -> int:
        with self._lock:
            return len(self._store)
