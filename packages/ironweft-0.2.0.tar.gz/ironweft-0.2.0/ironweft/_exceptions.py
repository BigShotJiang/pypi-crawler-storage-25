class IronWeftError(Exception):
    """Base exception for all IronWeft errors."""


class AuthorizationDenied(IronWeftError):
    def __init__(self, action: str, agent_id: str, reason: str = "", audit_event_id: str = ""):
        self.action = action
        self.agent_id = agent_id
        self.reason = reason
        self.audit_event_id = audit_event_id
        super().__init__(f"Action '{action}' denied for agent {agent_id}: {reason}")


class AgentSuspended(AuthorizationDenied):
    """Raised when the agent (or a node in its delegation chain) is suspended."""


class AgentRetired(IronWeftError):
    """Raised when the agent has been hard-locked and cannot be reactivated."""
