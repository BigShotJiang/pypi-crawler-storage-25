# IronWeft Python SDK

Python SDK for [IronWeft](https://ironweft.io) — credential lifecycle management for AI agents.

## Install

```bash
pip install ironweft
```

## Quickstart

```python
from ironweft import Client

client = Client(api_key="iw_live_xxx")

# Register an agent (one-time)
resp = client.register_agent(
    name="Grace",
    sponsor_id="user_margaret_chen",
    roles=["call_agent"],
)
agent = client.agent(resp["agent_id"])

# Gate any function — IronWeft checks policy before it runs
@agent.gate("payment.send", scopes=["payments:write"])
def send_payment(amount, account_id):
    ...

# Or check explicitly
cred = agent.credential(scopes=["payments:write"])
result = agent.check("payment.send", credential=cred, resource="account_7721")
```

## Exceptions

```python
from ironweft import AuthorizationDenied, AgentSuspended, AgentRetired

try:
    send_payment(2400, "account_7721")
except AgentSuspended:
    # 3+ consecutive denies — agent auto-suspended
    ...
except AuthorizationDenied as e:
    print(e.reason, e.audit_event_id)
```

## Docs

Full API reference at [ironweft.io/docs](https://ironweft.io/docs)
