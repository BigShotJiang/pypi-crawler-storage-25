# Release History

## 1.0.0b1 (2026-05-06)

### Other Changes

  - Initial version