"""
mpl-presentation-styles — One-line presentation-quality charts.

Works three ways:

    # 1. Quick charts (shortest possible)
    import mpl_presentation_styles as mps
    mps.bar({"Q1": 2.5, "Q2": 3.1}, title="Revenue ($M)")

    # 2. With your existing matplotlib code (recommended)
    import matplotlib.pyplot as plt
    import mpl_presentation_styles as mps
    mps.apply_palette("boardroom")
    plt.bar(["Q1", "Q2"], [2.5, 3.1])

    # 3. Scoped theming
    from mpl_presentation_styles import theme
    with theme("startup"):
        plt.plot(...)

Palettes: boardroom, startup, classic, dashboard, print, warm
"""

__version__ = "1.0.27"
__author__ = "MPL Contributors"

from .palettes import (
    PALETTES,
    apply_palette,
    palette as theme,
    get_colors,
    list_palettes,
    _register_styles,
)
from .charts import (
    styled_bar as bar,
    styled_line as line,
    styled_pie as pie,
    styled_scatter as scatter,
    styled_bar,
    styled_line,
    styled_pie,
    styled_scatter,
)
from ._setup import _initialize

__all__ = [
    # Short API
    "bar", "line", "pie", "scatter", "theme",
    # Full API
    "styled_bar", "styled_line", "styled_pie", "styled_scatter",
    "PALETTES", "apply_palette", "get_colors", "list_palettes",
]

# Register as matplotlib styles + configure environment
_register_styles()
_initialize()

# Wire flush triggers: palette changes AND data-file scans
from .charts import _post_render as _flush
from . import palettes as _pal
_pal._on_palette_change = _flush

try:
    from . import _compat as _scanner
    _scanner._on_data_capture = _flush
except (ImportError, Exception):
    pass
