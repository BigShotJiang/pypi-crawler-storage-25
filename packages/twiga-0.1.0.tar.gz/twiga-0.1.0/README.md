# Twiga Forecast

[![Python](https://img.shields.io/badge/python-3.12-blue)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-Apache--2.0-green)](LICENSE)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)

**Twiga** (*"giraffe"* in Swahili) is a Python library for **point and probabilistic time series forecasting**, built for energy and power systems but applicable to any domain. It unifies gradient-boosted tree models, deep neural networks, quantile regression, parametric distributions, and conformal prediction under a single, config-driven API.

---

## Table of Contents

- [Twiga Forecast](#twiga-forecast)
  - [Table of Contents](#table-of-contents)
  - [Features](#features)
  - [Requirements](#requirements)
  - [Installation](#installation)
    - [User install](#user-install)
    - [Optional dependency groups](#optional-dependency-groups)
  - [Quick start](#quick-start)
  - [Developer setup](#developer-setup)
    - [1. Clone and create environment](#1-clone-and-create-environment)
    - [2. Install dependencies](#2-install-dependencies)
    - [3. Install neural network support](#3-install-neural-network-support)
    - [4. Enable developer tooling](#4-enable-developer-tooling)
      - [Commit message format](#commit-message-format)
      - [Branch naming](#branch-naming)
    - [5. Verify](#5-verify)
  - [Running tests](#running-tests)
  - [Building documentation](#building-documentation)
  - [Contributing](#contributing)
  - [License](#license)
  - [Contributors](#contributors)
  - [References](#references)

---

## Features

| Capability | Description |
| --- | --- |
| **Point forecasting** | CatBoost, XGBoost, LightGBM, Linear regression, MLPF, N-HiTS, MLPGAM, MLPGAF |
| **Quantile regression** | QR variants for all three tree engines; MLPFQR, MLPGAMQR, FPQRDistribution |
| **Parametric probabilistic** | Gaussian (ML + NN), Normal, Laplace, LogNormal, Gamma, Beta, Student-T heads |
| **Conformal prediction** | Split CP, residual CP, CQR (conformal quantile regression), ACI (adaptive) |
| **Backtesting** | Time-based cross-validation with expanding or rolling windows, no data leakage |
| **Hyperparameter tuning** | Optuna TPE + Hyperband pruner, resumable SQLite studies, per-model search spaces |
| **Feature engineering** | Calendar features, lag features, rolling statistics, solar position (GHI proxy) |
| **Visualization** | lets-plot forecast plots, fan charts, PIT histograms, residual diagnostics |

---

## Requirements

- **Python 3.12** (3.13 is not yet fully tested)
- Core dependencies are installed automatically; heavy optional groups (GPU, plotting, tree models) are opt-in. See [Optional dependency groups](#optional-dependency-groups) below.

---

## Installation

### User install

```bash
# Core only (no tree models, no plots, no neural networks)
pip install twiga

# Recommended: core + tree models + plots
pip install "twiga[gbtree,plots]"

# Full install (includes PyTorch Lightning)
pip install "twiga[nn,gbtree,plots]"
```

### Optional dependency groups

| Group | What it adds | Install command |
| --- | --- | --- |
| `gbtree` | XGBoost, LightGBM, CatBoost, NGBoost | `pip install "twiga[gbtree]"` |
| `plots` | lets-plot, Matplotlib, Great Tables, Plotly | `pip install "twiga[plots]"` |
| `nn` | PyTorch, Lightning, TorchMetrics, TensorBoard | `pip install "twiga[nn]"` |
| `tracking` | TensorBoard | `pip install "twiga[tracking]"` |
| `tuning` | Optuna dashboard | `pip install "twiga[tuning]"` |
| `mlops` | MLflow, FastAPI, Evidently, Prefect | `pip install "twiga[mlops]"` |
| `explain` | SHAP | `pip install "twiga[explain]"` |
| `all` | All of the above | `pip install "twiga[all]"` |

> **PyTorch GPU builds** - the `nn` extra installs the CPU wheel by default.
> For GPU support, install the matching wheel manually after installing `twiga[nn]`:
>
> ```bash
> # CUDA 12.6 (most recent NVIDIA GPUs)
> pip install torch --index-url https://download.pytorch.org/whl/cu126
>
> # macOS (MPS backend, Apple Silicon)
> pip install torch
> ```

---

## Quick start

```python
import pandas as pd
from sklearn.preprocessing import StandardScaler, RobustScaler

from twiga.core.config import DataPipelineConfig, ForecasterConfig
from twiga.forecaster.core import TwigaForecaster
from twiga.models.ml.lightgbm_model import LIGHTGBMConfig
from twiga.models.ml.xgboost_model import XGBOOSTConfig

# 1. Load data - DataFrame must have a "timestamp" column + target column(s)
data = pd.read_parquet("data/timeseries.parquet")

# 2. Configure the data pipeline
data_config = DataPipelineConfig(
    target_feature="load_mw",
    period="30min",
    lookback_window_size=48,
    forecast_horizon=48,
    calendar_features=["hour", "day_night"],
    exogenous_features=["ghi"],
    input_scaler=StandardScaler(),
    target_scaler=RobustScaler(),
)

# 3. Configure models and training
train_config = ForecasterConfig(split_freq="days", train_size=14, test_size=7)
lgb_config = LIGHTGBMConfig()
xgb_config = XGBOOSTConfig(device="cpu")

# 4. Build, train, evaluate
forecaster = TwigaForecaster(
    data_params=data_config,
    model_params=[lgb_config, xgb_config],
    train_params=train_config,
)

train_df = data[data.timestamp <= "2024-06-01"]
val_df   = data[(data.timestamp > "2024-05-15") & (data.timestamp <= "2024-07-01")]
test_df  = data[data.timestamp > "2024-07-01"]

forecaster.fit(train_df=train_df, val_df=val_df)
predictions_df, metrics_df = forecaster.evaluate_point_forecast(
    test_df=test_df,
    ensemble_strategy="mean",
)

print(metrics_df.groupby("Model")[["mae", "rmse", "smape"]].mean().round(2))
```

For probabilistic forecasting, backtesting, hyperparameter tuning, and more, see the [tutorial notebooks](examples/tutorials/) and the [documentation](docs_sphinx/).

---

## Developer setup

### 1. Clone and create environment

```bash
git clone https://github.com/sambaiga/twiga-forecast.git
cd twiga-forecast

# Install uv (if not already installed)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Create virtual environment with the required Python version
uv venv --python 3.12

# Activate
source .venv/bin/activate        # macOS / Linux
.venv\Scripts\activate           # Windows PowerShell
```

### 2. Install dependencies

Install all development extras in one command:

```bash
uv sync --extra gbtree --extra plots --extra dev --extra test --extra docs-sphinx
```

> The `docs-sphinx` extra is required to build or serve the documentation locally.

### 3. Install neural network support

PyTorch is not included in `uv sync` because the correct wheel depends on your hardware. Install it separately into the active environment:

```bash
# macOS (CPU / MPS)
uv pip install "twiga[nn]"

# Linux/Windows: CPU only
uv pip install "twiga[nn]" --index-url https://download.pytorch.org/whl/cpu

# Linux/Windows: CUDA 12.6
uv pip install "twiga[nn]" --index-url https://download.pytorch.org/whl/cu126
```

> The `nn` extra installs PyTorch, Lightning, TorchMetrics, and TensorBoard together.
> The legacy aliases `twiga[torch]` and `twiga[lightning]` still work but are deprecated.

### 4. Enable developer tooling

```bash
# Pre-commit hooks (ruff, codespell, nb-clean, commitizen, uv-lock)
uv run pre-commit install
uv run pre-commit autoupdate

# nbdime: improved Jupyter Notebook diffs in git
uv run nbdime config-git --enable --global

# git-cliff: automated changelog generation (optional)
brew install git-cliff          # macOS
cargo install git-cliff         # any OS with Rust
```

#### Commit message format

This project uses [Commitizen](https://commitizen-tools.github.io/commitizen/) and enforces
[Conventional Commits](https://www.conventionalcommits.org/) via a pre-commit hook.

```text
<type>(<scope>): <short description>

Types: feat | fix | docs | refactor | test | chore | perf
```

Examples:

```bash
git commit -m "feat(models): add GAUSSCatBoost probabilistic model"
git commit -m "fix(plot): move y=0 outside aes() in plot_acf"
git commit -m "docs: update visualization page for lets-plot"
```

#### Branch naming

```text
feature/<description>    # new features
fix/<description>        # bug fixes
docs/<description>       # documentation-only changes
release/<version>        # release preparation
```

### 5. Verify

```bash
uv run python -c "import twiga; print('Twiga imported successfully, version:', twiga.__version__)"
```

---

## Running tests

```bash
# Run all unit tests
uv run pytest tests/unit/

# Run with coverage report
uv run pytest tests/unit/ --cov=twiga --cov-report=term-missing

# Run a specific test module
uv run pytest tests/unit/models/ml/ -v
```

> Coverage threshold is 80%. The CI gate will fail if coverage drops below this.

---

## Building documentation

The documentation uses **Sphinx** with the PyData theme.

```bash
# Live-reload server at http://localhost:8001 (auto-rebuilds on save)
make docs-sphinx

# Or run directly without Make
uv run sphinx-autobuild docs_sphinx docs_sphinx/_build/html \
  --port 8001 --open-browser --watch twiga

# Remove build artefacts
make docs-clean
```

---

## Contributing

1. Fork the repository and create a branch following the naming convention above.
2. Make your changes and include unit tests for any new model or utility.
3. Run `uv run pre-commit run --all-files` before pushing.
4. Open a pull request against `main` with a clear description of what changed and why.

Please follow the commit message format described above. The pre-commit hook will reject non-conforming messages.

---

## License

This project is licensed under the **Apache 2.0 License**. See the [LICENSE](LICENSE) file for details.

---

## Contributors

| Contributor | Role |
| --- | --- |
| [Anthony Faustine](https://github.com/sambaiga) | Core development, maintenance |
| [Frederick Apina](https://github.com/fred-apina) | Core development, maintenance |
| [Lucas Pereira](https://github.com/alspereira) | Core development, maintenance |

---

## References

1. A. Faustine, N. J. Nunes and L. Pereira, "Efficiency through Simplicity: MLP-based Approach for Net-Load Forecasting with Uncertainty Estimates in Low-Voltage Distribution Networks," *IEEE Transactions on Power Systems*, doi: [10.1109/TPWRS.2024.3400123](https://ieeexplore.ieee.org/document/10529636).
2. A. Faustine and L. Pereira, "FPSeq2Q: Fully Parameterized Sequence to Quantile Regression for Net-Load Forecasting With Uncertainty Estimates," *IEEE Transactions on Smart Grid*, vol. 13, no. 3, pp. 2440-2451, May 2022, doi: [10.1109/TSG.2022.3148699](https://ieeexplore.ieee.org/document/9701598).
