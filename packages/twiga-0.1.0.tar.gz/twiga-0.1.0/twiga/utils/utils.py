import os
from pathlib import Path

from twiga.core.data.processing import get_target_sequences


def format_target(targets, input_window_size, forecast_horizon, stride=1):
    """Format the target data for training the model.

    Args:
        targets (np.ndarray): Target data of shape (n_samples, n_features).
        input_window_size (int): Input window size (lookback).
        forecast_horizon (int): Forecast horizon.
        stride (int, optional): Step between consecutive windows. Use
            ``stride=forecast_horizon`` for non-overlapping windows.
            Defaults to 1.

    Returns:
        (np.ndarray): Target sequences of shape (n_sequences, forecast_horizon, n_features).
    """
    return get_target_sequences(targets, input_window_size, forecast_horizon, stride=stride)


def get_latest_checkpoint(checkpoint_path):
    """Get the path of the latest checkpoint file.

    Args:
        checkpoint_path (str): Path to the directory containing the checkpoint files.

    Returns:
        latest_file (str): Path of the latest checkpoint file.
    """
    checkpoint_path = Path(checkpoint_path)
    latest_file = max(checkpoint_path.glob("*.ckpt"), key=os.path.getctime, default=None)
    latest_file = str(latest_file) if latest_file else None
    return latest_file
