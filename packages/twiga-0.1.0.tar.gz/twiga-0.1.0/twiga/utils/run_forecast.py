"""Entry-point script for training and evaluating Twiga forecasting models.

All pipeline stages are broken into reusable functions so each step can be
called independently, tested in isolation, or composed into larger workflows.

Example:
    Run with defaults::

        python run_forecast.py

    Override config at import time::

        from run_forecast import run_pipeline, PipelineConfig

        run_pipeline(PipelineConfig(dataset_name="MLVS-PT", epochs=100))
"""

from __future__ import annotations

from dataclasses import dataclass, field
from io import StringIO
import os
from pathlib import Path
import warnings

import numpy as np
import pandas as pd
from rich.console import Console
from rich.table import Table
from scipy import signal
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import torch

from twiga.core.config import DataPipelineConfig, ForecasterConfig
from twiga.core.plot import plot_forecast_grid
from twiga.core.utils.logger import LogContext, configure, get_logger, log_section
from twiga.forecaster.core import TwigaForecaster
from twiga.models.ml.lightgbm_model import LIGHTGBMConfig
from twiga.models.nn.mlpf_model import MLPFConfig
from twiga.models.nn.mlpgaf_model import MLPGAFConfig
from twiga.models.nn.mlpgam_model import MLPGAMConfig
from twiga.utils.data_loading import load_dataset

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Pipeline configuration
# ---------------------------------------------------------------------------


@dataclass
class PipelineConfig:
    """Top-level configuration for a full forecasting pipeline run.

    All values can be overridden at the call-site; nothing is hardcoded in
    the pipeline functions themselves.

    Attributes:
        dataset_name: Registered dataset identifier passed to
            :func:`~twiga.utils.data_loading.load_dataset`.
        data_path: Directory that contains raw dataset files.
        output_dir: Root directory where results (plots, CSVs) are written.
            Sub-directories ``plots/``, ``predictions/`` and ``metrics/``
            are created automatically.
        train_start: Inclusive start of the training window (``"YYYY-MM"``).
        train_end: Inclusive end of the training window (``"YYYY-MM"``).
        test_start: Inclusive start of the evaluation window (``"YYYY-MM"``).
        test_end: Inclusive end of the evaluation window (``"YYYY-MM"``).
        input_window_size: Number of historical time-steps fed to the model.
        forecast_horizon: Number of future steps the model predicts.
        period: Sampling frequency of the time series (e.g. ``"30min"``).
        out_activation: Output-layer activation function name.
        epochs: Maximum training epochs for neural-network models.
        train_val_split: Fraction of training data used for fitting; the
            remainder forms the validation set.
        num_trials: Optuna trial budget for hyper-parameter search.
        split_freq: Unit of cross-validation splits (``"months"``,
            ``"weeks"``).
        cv_train_size: Number of *split_freq* units in each CV training fold.
        cv_test_size: Number of *split_freq* units in each CV test fold.
        metrics: Forecast accuracy metrics to compute.
        ensemble_strategy: Strategy passed to
            :meth:`~twiga.forecaster.core.TwigaForecaster.evaluate_point_forecast`.
            ``None`` evaluates each model independently.
        figure_size: ``(width, height)`` in inches for result plots.
        plot_dpi: DPI used when saving figures to disk.
        log_level: Console log level (``"DEBUG"``, ``"INFO"``, …).
        log_file: Optional path for a persistent plain-text log file.
            ``None`` disables file logging.
        use_latex: Activate LaTeX rendering in Matplotlib.
        num_threads: CPU thread budget for PyTorch and OpenMP.
    """

    # Dataset ----------------------------------------------------------------
    dataset_name: str = "MLVS-PT"
    project_name: str | None = None
    data_path: str | Path = "data/"
    output_dir: str | Path = "results/"

    # Time windows -----------------------------------------------------------
    train_start: str = "2019-03"
    train_end: str = "2020-02"
    test_start: str = "2020-03"
    test_end: str = "2020-06"

    # Data pipeline ----------------------------------------------------------
    input_window_size: int = 48
    forecast_horizon: int = 48
    period: str = "30min"

    # Model training ---------------------------------------------------------
    out_activation: str = "Identity"
    epochs: int = 50
    train_val_split: float = 0.7

    # Hyper-parameter tuning -------------------------------------------------
    num_trials: int = 10

    # Cross-validation / evaluation ------------------------------------------
    split_freq: str = "months"
    cv_train_size: int = 3
    cv_test_size: int = 1
    metrics: list[str] = field(default_factory=lambda: ["rmse", "mae", "corr"])
    ensemble_strategy: str | None = None

    # Plotting ---------------------------------------------------------------
    figure_size: tuple[int, int] = (9, 3)
    plot_dpi: int = 150

    # Logging ----------------------------------------------------------------
    log_level: str = "INFO"
    log_file: str | Path | None = None

    # Environment ------------------------------------------------------------
    use_latex: bool = True
    num_threads: int = 1


# ---------------------------------------------------------------------------
# Output directory helpers
# ---------------------------------------------------------------------------


def _resolve_output_dirs(output_dir: str | Path) -> dict[str, Path]:
    """Create and return all result sub-directories.

    Three sub-directories are created under *output_dir* if they do not
    already exist: ``plots/``, ``predictions/``, and ``metrics/``.

    Args:
        output_dir: Root results directory.

    Returns:
        Mapping of ``{"plots": Path, "predictions": Path, "metrics": Path}``.
    """
    root = Path(output_dir)
    dirs: dict[str, Path] = {
        "plots": root / "plots",
        "predictions": root / "predictions",
        "metrics": root / "metrics",
    }
    for path in dirs.values():
        path.mkdir(parents=True, exist_ok=True)

    log.debug("Output directories resolved  root=%s", root)
    return dirs


# ---------------------------------------------------------------------------
# Environment setup
# ---------------------------------------------------------------------------


def setup_environment(cfg: PipelineConfig) -> None:
    """Configure the runtime environment.

    Sets the OpenMP and PyTorch thread counts, suppresses third-party
    warnings, and applies the Twiga Matplotlib style.

    Args:
        cfg: Pipeline configuration.
    """
    os.environ["OMP_NUM_THREADS"] = str(cfg.num_threads)
    torch.set_num_threads(cfg.num_threads)
    warnings.filterwarnings("ignore")
    log.debug(
        "Environment configured  threads=%d  latex=%s",
        cfg.num_threads,
        cfg.use_latex,
    )


# ---------------------------------------------------------------------------
# Data loading & preprocessing
# ---------------------------------------------------------------------------


def load_and_preprocess(
    cfg: PipelineConfig,
) -> tuple[pd.DataFrame, str, list, list, list, float, float]:
    """Load a registered dataset and apply standard preprocessing.

    Applies a length-3 median filter to the target series to suppress
    impulse noise, then forward-fills any remaining ``NaN`` values.

    Args:
        cfg: Pipeline configuration.

    Returns:
        A 7-tuple of ``(data, target_series, calendar_variables,
        exogenous_features, lags, latitude, longitude)``.
    """
    log.info("Loading dataset '%s' from '%s'", cfg.dataset_name, cfg.data_path)

    (
        data,
        target_series,
        calendar_variables,
        exogenous_features,
        lags,
        latitude,
        longitude,
    ) = load_dataset(cfg.dataset_name, data_path=str(cfg.data_path))

    log.debug(
        "Raw data  shape=%s  target='%s'  n_lags=%d",
        data.shape,
        target_series,
        len(lags),
    )

    data[target_series] = signal.medfilt(data[target_series].values, 3)
    data.ffill(inplace=True)

    log.info("Preprocessing done  rows=%d  target='%s'", len(data), target_series)
    return data, target_series, calendar_variables, exogenous_features, lags, latitude, longitude


# ---------------------------------------------------------------------------
# Configuration builders
# ---------------------------------------------------------------------------


def build_data_config(
    cfg: PipelineConfig,
    target_series: str,
    lags: list,
    calendar_variables: list,
    exogenous_features: list,
    latitude: float,
    longitude: float,
) -> DataPipelineConfig:
    """Construct a :class:`~twiga.core.config.DataPipelineConfig`.

    Input and target scalers are instantiated fresh on every call so that
    separate pipeline runs do not share scaler state.

    Args:
        cfg: Pipeline configuration.
        target_series: Name of the column to forecast.
        lags: Lag feature column names returned by the dataset loader.
        calendar_variables: Calendar-derived feature column names.
        exogenous_features: External regressor column names.
        latitude: Geographic latitude used for solar-position features.
        longitude: Geographic longitude used for solar-position features.

    Returns:
        Fully populated :class:`~twiga.core.config.DataPipelineConfig`.
    """
    data_config = DataPipelineConfig(
        target_feature=target_series,
        historical_features=lags,
        period=cfg.period,
        latitude=latitude,
        longitude=longitude,
        calendar_features=calendar_variables,
        exogenous_features=exogenous_features,
        forecast_horizon=cfg.forecast_horizon,
        lookback_window_size=cfg.input_window_size,
        input_scaler=StandardScaler(),
        target_scaler=MinMaxScaler(feature_range=(-1, 1)),
    )

    log.debug(
        "DataPipelineConfig  horizon=%d  lookback=%d  period=%s",
        cfg.forecast_horizon,
        cfg.input_window_size,
        cfg.period,
    )
    return data_config


def build_model_configs(
    cfg: PipelineConfig,
) -> list:
    """Instantiate all model configurations for the ensemble.

    Neural-network input/output dimensions are auto-populated by
    :class:`~twiga.forecaster.core.TwigaForecaster` from *data_config*,
    so configs only need training hyperparameters set explicitly.

    Args:
        cfg: Pipeline configuration.
        data_config: Data pipeline config from :func:`build_data_config`.

    Returns:
        List of model config objects ready for
        :class:`~twiga.forecaster.core.TwigaForecaster`.
    """
    mlpf_config = MLPFConfig(  # type: ignore[call-arg]
        out_activation_function=cfg.out_activation,  # type: ignore[arg-type]
        max_epochs=cfg.epochs,
        rich_progress_bar=False,
    )

    mlpgam_config = MLPGAMConfig(  # type: ignore[call-arg]
        out_activation_function=cfg.out_activation,  # type: ignore[arg-type]
        max_epochs=cfg.epochs,
        rich_progress_bar=False,
    )

    mlpgaf_config = MLPGAFConfig(  # type: ignore[call-arg]
        out_activation_function=cfg.out_activation,  # type: ignore[arg-type]
        max_epochs=cfg.epochs,
        rich_progress_bar=False,
    )

    model_configs = [mlpf_config, mlpgam_config, mlpgaf_config]
    log.debug(
        "Model configs  models=[%s]",
        ", ".join(type(m).__name__ for m in model_configs),
    )
    return model_configs


def build_forecaster_config(cfg: PipelineConfig) -> ForecasterConfig:
    """Construct a :class:`~twiga.core.config.ForecasterConfig`.

    Args:
        cfg: Pipeline configuration.

    Returns:
        Populated :class:`~twiga.core.config.ForecasterConfig`.
    """
    forecaster_config = ForecasterConfig(
        split_freq=cfg.split_freq,  # type: ignore[arg-type]
        train_size=cfg.cv_train_size,
        test_size=cfg.cv_test_size,
        metrics=cfg.metrics,
        project_name=cfg.dataset_name if cfg.project_name is None else cfg.project_name,
    )

    log.debug(
        "ForecasterConfig  split_freq=%s  train_size=%d  test_size=%d",
        cfg.split_freq,
        cfg.cv_train_size,
        cfg.cv_test_size,
    )
    return forecaster_config


# ---------------------------------------------------------------------------
# Data splitting
# ---------------------------------------------------------------------------


def split_data(
    data: pd.DataFrame,
    cfg: PipelineConfig,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Slice *data* into training and test DataFrames.

    Both bounds are inclusive and match the ``"YYYY-MM"`` format stored in
    :class:`PipelineConfig`.

    Args:
        data: Full dataset ``DataFrame`` with a ``timestamp`` column.
        cfg: Pipeline configuration containing date-range strings.

    Returns:
        A 2-tuple of ``(train_df, test_df)``.
    """
    train_df = data[(data.timestamp >= cfg.train_start) & (data.timestamp <= cfg.train_end)]
    test_df = data[(data.timestamp >= cfg.test_start) & (data.timestamp <= cfg.test_end)]

    log.info(
        "Data split  train=[%s → %s] n=%d  test=[%s → %s] n=%d",
        cfg.train_start,
        cfg.train_end,
        len(train_df),
        cfg.test_start,
        cfg.test_end,
        len(test_df),
    )
    return train_df, test_df


# ---------------------------------------------------------------------------
# Forecaster lifecycle
# ---------------------------------------------------------------------------


def build_forecaster(
    data_config: DataPipelineConfig,
    model_configs: list,
    forecaster_config: ForecasterConfig,
) -> TwigaForecaster:
    """Initialise a :class:`~twiga.forecaster.core.TwigaForecaster`.

    Args:
        data_config: Data pipeline configuration.
        model_configs: List of model configs to include in the ensemble.
        forecaster_config: Training and evaluation configuration.

    Returns:
        An uninitialised :class:`~twiga.forecaster.core.TwigaForecaster`.
    """
    forecaster = TwigaForecaster(
        data_params=data_config,
        model_params=model_configs,
        train_params=forecaster_config,
    )
    log.debug("TwigaForecaster instantiated")
    return forecaster


def tune_and_fit(
    forecaster: TwigaForecaster,
    train_df: pd.DataFrame,
    cfg: PipelineConfig,
) -> None:
    """Run hyper-parameter tuning then re-fit on the full training set.

    Tuning uses a temporal split of *train_df* at ``train_val_split`` to
    find the best hyper-parameters.  After tuning, the models are re-fitted
    on the **full** *train_df* so that all available training data is used
    for the final benchmark evaluation.

    Args:
        forecaster: Uninitialised forecaster from :func:`build_forecaster`.
        train_df: Full training ``DataFrame``.
        cfg: Pipeline configuration supplying ``train_val_split`` and
            ``num_trials``.
    """
    split_idx = int(len(train_df) * cfg.train_val_split)
    fit_df = train_df.iloc[:split_idx]
    val_df = train_df.iloc[split_idx:]

    log.info(
        "Hyper-parameter tuning  trials=%d  fit_n=%d  val_n=%d",
        cfg.num_trials,
        len(fit_df),
        len(val_df),
    )
    with LogContext(log, phase="tuning"):
        forecaster.tune(train_df=fit_df, val_df=val_df, num_trials=cfg.num_trials)

    # Re-fit on the full training set so evaluation uses all available data.
    # Use the last ``1 - train_val_split`` fraction as the validation signal.
    log.info("Re-fitting on full train set  n=%d  val_n=%d", len(train_df), len(val_df))
    with LogContext(log, phase="fitting"):
        forecaster.fit(train_df=train_df, val_df=val_df)


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------


def evaluate(
    forecaster: TwigaForecaster,
    test_df: pd.DataFrame,
    cfg: PipelineConfig,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Run point-forecast evaluation and log the metric table.

    Args:
        forecaster: Fitted :class:`~twiga.forecaster.core.TwigaForecaster`.
        test_df: Hold-out evaluation ``DataFrame``.
        cfg: Pipeline configuration supplying ``ensemble_strategy``.

    Returns:
        A 2-tuple of ``(pred, metric)`` ``DataFrame`` objects where *pred*
        contains per-step predictions and *metric* contains aggregate
        accuracy scores.
    """
    log.info("Evaluating point forecast  test_n=%d", len(test_df))

    with LogContext(log, phase="evaluation"):
        pred, metric = forecaster.evaluate_point_forecast(
            test_df=test_df,
            ensemble_strategy=cfg.ensemble_strategy,
        )

    log.info("Evaluation complete")
    res = metric.groupby("Model")[["mae", "corr", "nbias", "rmse", "wmape", "smape"]].mean().round(2).reset_index()
    res = res.rename(
        columns={"mae": "MAE", "corr": "Corr", "wmape": "WMAPE", "smape": "SMAPE", "nbias": "NBIAS", "rmse": "RMSE"},
    )
    # metric_name = ["MAE", "Corr", "SMAPE", "RMSE"]
    minimize_cols = ["MAE", "SMAPE", "RMSE"]
    maximize_cols = ["Corr"]

    # table = create_model_performance_table(res, metric_name, minimize_cols, maximize_cols)
    # log.info(table.as_latex())
    # Terminal-friendly rich table built directly from res
    display_cols = ["MAE", "Corr", "NBIAS", "RMSE", "WMAPE", "SMAPE"]
    best = {
        col: res[col].min() if col in minimize_cols else res[col].max()
        for col in display_cols
        if col in minimize_cols + maximize_cols
    }

    rich_table = Table(title="Model Performance", header_style="bold cyan", show_lines=False)
    rich_table.add_column("Model", style="bold white")
    for col in display_cols:
        rich_table.add_column(col, justify="right")

    for _, row in res.iterrows():
        cells = []
        for col in display_cols:
            val = str(row[col])
            if col in best and row[col] == best[col]:
                val = f"[bold green]{val}[/bold green]"
            cells.append(val)
        rich_table.add_row(str(row["Model"]), *cells)

    buf = StringIO()
    Console(file=buf, highlight=False).print(rich_table)
    log.info("Evaluation results\n%s", buf.getvalue())

    return pred, metric


# ---------------------------------------------------------------------------
# Saving results
# ---------------------------------------------------------------------------


def save_predictions(
    pred: pd.DataFrame,
    output_dirs: dict[str, Path],
    cfg: PipelineConfig,
) -> Path:
    """Persist the predictions ``DataFrame`` to a CSV file.

    The file is written to ``<output_dir>/predictions/`` and named using
    the dataset name and test window for unambiguous identification.

    Args:
        pred: Predictions ``DataFrame`` returned by :func:`evaluate`.
        output_dirs: Directory mapping from :func:`_resolve_output_dirs`.
        cfg: Pipeline configuration supplying naming information.

    Returns:
        Resolved path of the saved CSV file.
    """
    filename = f"{cfg.dataset_name}_{cfg.test_start}_{cfg.test_end}_predictions.csv"
    out_path = output_dirs["predictions"] / filename
    pred.to_csv(out_path, index=True)
    log.info("Predictions saved  path=%s", out_path)
    return out_path


def save_metrics(
    metric: pd.DataFrame,
    output_dirs: dict[str, Path],
    cfg: PipelineConfig,
) -> Path:
    """Persist the evaluation metrics ``DataFrame`` to a CSV file.

    The file is written to ``<output_dir>/metrics/`` and named using the
    dataset name and test window.

    Args:
        metric: Metrics ``DataFrame`` returned by :func:`evaluate`.
        output_dirs: Directory mapping from :func:`_resolve_output_dirs`.
        cfg: Pipeline configuration supplying naming information.

    Returns:
        Resolved path of the saved CSV file.
    """
    filename = f"{cfg.dataset_name}_{cfg.test_start}_{cfg.test_end}_metrics.csv"
    out_path = output_dirs["metrics"] / filename
    metric.to_csv(out_path, index=True)
    log.info("Metrics saved  path=%s", out_path)
    return out_path


# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------


def visualize_results(
    pred: pd.DataFrame,
    output_dirs: dict[str, Path],
    cfg: PipelineConfig,
) -> Path:
    """Visualize forecasting results for all models and save to disk.

    Creates one subplot per model showing predicted vs actual values over
    a one-week horizon, then writes the figure as a PDF to the plots
    sub-directory.

    Args:
        pred: Forecast ``DataFrame`` containing columns ``"Actual"``,
            ``"forecast"``, ``"Model"``, and ``"target"``.
        output_dirs: Directory mapping from :func:`_resolve_output_dirs`.
        cfg: Pipeline configuration supplying ``figure_size`` and
            ``dataset_name``.

    Returns:
        Resolved path of the saved PDF file.
    """
    from lets_plot import ggsave

    p = plot_forecast_grid(
        pred,
        actual_col="Actual",
        forecast_col="forecast",
        model_col="Model",
        n_samples_per_model=7 * 48,
        title=f"{cfg.dataset_name} - Forecast vs Actual",
        x_label="Sample",
        y_label="P (kW)",
    )

    plot_filename = f"{cfg.dataset_name}_{cfg.test_start}_{cfg.test_end}_forecast.pdf"
    out_path = output_dirs["plots"] / plot_filename
    ggsave(p, str(out_path))

    log.info("Figure saved  path=%s", out_path)
    return out_path


# ---------------------------------------------------------------------------
# Top-level orchestrator
# ---------------------------------------------------------------------------


def run_pipeline(
    cfg: PipelineConfig | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Execute the full forecasting pipeline end-to-end.

    Pipeline stages:

    1. Logging activation
    2. Environment setup
    3. Data loading and preprocessing
    4. Config construction (data, models, forecaster)
    5. Data splitting
    6. Forecaster initialisation
    7. Hyper-parameter tuning and model fitting
    8. Evaluation
    9. Saving predictions and metrics
    10. Plotting and saving figures

    Args:
        cfg: Pipeline configuration.  Defaults to :class:`PipelineConfig`
            with all default values when ``None``.

    Returns:
        A 2-tuple of ``(pred, metric)`` ``DataFrame`` objects from
        :func:`evaluate`.
    """
    if cfg is None:
        cfg = PipelineConfig()

    configure(level=cfg.log_level, log_file=cfg.log_file)
    output_dirs = _resolve_output_dirs(cfg.output_dir)

    log_section(log, "Environment Setup")
    setup_environment(cfg)

    log_section(log, "Data Loading")
    (
        data,
        target_series,
        calendar_variables,
        exogenous_features,
        lags,
        latitude,
        longitude,
    ) = load_and_preprocess(cfg)

    log_section(log, "Configuration")
    data_config = build_data_config(
        cfg,
        target_series,
        lags,
        calendar_variables,
        exogenous_features,
        latitude,
        longitude,
    )
    model_configs = build_model_configs(cfg)
    forecaster_config = build_forecaster_config(cfg)

    log_section(log, "Data Splitting")
    train_df, test_df = split_data(data, cfg)

    log_section(log, "Forecaster Initialisation")
    forecaster = build_forecaster(data_config, model_configs, forecaster_config)

    log_section(log, "Tuning & Fitting")
    tune_and_fit(forecaster, train_df, cfg)

    log_section(log, "Evaluation")
    pred, metric = evaluate(forecaster, test_df, cfg)

    log_section(log, "Saving Results")
    save_predictions(pred, output_dirs, cfg)
    save_metrics(metric, output_dirs, cfg)

    log_section(log, "Plotting")
    visualize_results(pred, output_dirs, cfg)

    return pred, metric


# ---------------------------------------------------------------------------
# Script entry-point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    pipeline_cfg = PipelineConfig(
        dataset_name="MLVS-PT",
        data_path="examples/data",
        output_dir="results/",
        train_start="2019-03",
        train_end="2020-02",
        test_start="2020-03",
        test_end="2020-06",
        input_window_size=48,
        forecast_horizon=48,
        period="30min",
        out_activation="Identity",
        epochs=50,
        train_val_split=0.7,
        num_trials=1,
        split_freq="months",
        cv_train_size=3,
        cv_test_size=1,
        metrics=["rmse", "mae", "corr"],
        ensemble_strategy=None,
        figure_size=(9, 3),
        plot_dpi=150,
        log_level="INFO",
        log_file="results/run.log",
        use_latex=True,
        num_threads=1,
    )

    run_pipeline(pipeline_cfg)
