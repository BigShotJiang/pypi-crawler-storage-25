from pathlib import Path

import pandas as pd

from twiga.core.data.autores import AutoregressTransformer
from twiga.core.data.feature import add_day_night_feature, add_fourier_features
from twiga.core.data.processing import augment_timeseries_signature, normalise_timestamp_column
from twiga.core.data.selection import select_top_features


def get_best_autoregessive_features(
    data: pd.DataFrame,
    target_series: str,
    rolling_type: list[str] | None = None,
    periods: list[int] | None = None,
    n_samples: int = 48,
    top_k: int = 2,
) -> list[str]:
    """Get the best autoregressive features using AutoregressTransformer.

    Args:
        data (pd.DataFrame): Input time series data.
        target_series (str): Target series name.
        rolling_type (list[str], optional): List of rolling functions to apply. Defaults to ["mean"].
        periods (list[int], optional): List of periods for lag and rolling features. Defaults to [1, 2, 3, 4, 5, 6, 7].
        n_samples (int, optional): Number of samples in the input window. Defaults to 48.
        top_k (int, optional): Number of top features to select. Defaults to 5.

    Returns:
        list[str]: List of selected top autoregressive features.

    """
    if periods is None:
        periods = [1, 2, 3, 4, 5, 6, 7]
    if rolling_type is None:
        rolling_type = ["mean"]
    auto_res = AutoregressTransformer(
        n_samples=n_samples,
        lags=periods,
        windows=periods,
        window_funcs=rolling_type,
        value_column=target_series,
    )
    df = data.copy()
    df = auto_res.fit_transform(df)
    top_k = max(1, top_k - 1)

    historical_features = []  # type: ignore[var-annotated]
    feature = list(filter(lambda x: "lag" in x, df.columns))
    historical_features += select_top_features(data=df, features=feature, target=target_series, top_k=top_k)
    feature = list(filter(lambda x: "rolling" in x, df.columns))
    historical_features += select_top_features(data=df, features=feature, target=target_series, top_k=top_k)
    return historical_features


def get_best_temporal_features(
    data: pd.DataFrame,
    target_series: str,
    latitude: float | None = None,
    longitude: float | None = None,
    date_col_name: str = "timestamp",
    top_k: int = 2,
) -> list[str]:
    """Get the best temporal features using TemporalFeatureTransformer.

    Args:
        data (pd.DataFrame): Input time series data.
        latitude : (float) The latitude of the location.
        longitude : (float) The longitude of the location.
        date_col_name (str, optional): Timestamp column name. Defaults to "timestamp".
        target_series (str): Target series name.
        top_k (int, optional): Number of top features to select. Defaults to 5.

    Returns:
        list[str]: List of selected top temporal features.
    """
    df = data[[date_col_name, target_series]].copy()

    df = augment_timeseries_signature(df, date_column=date_col_name)
    df.rename(columns=lambda x: x.replace(f"{date_col_name}_", ""), inplace=True)
    df = df[
        [date_col_name, target_series]
        + ["quarter", "month", "yweek", "mweek", "wday", "mday", "qday", "yday", "weekend", "hour", "minute"]
    ]
    if (latitude is not None) and (longitude is not None):
        df = add_day_night_feature(df, latitude=latitude, longitude=longitude)

    numeric_cols = df.drop(columns=[date_col_name, target_series]).select_dtypes("number").columns.tolist()
    for col in numeric_cols:
        period = df[col].nunique()
        if period < 3:
            continue
        df = add_fourier_features(data=df, calendar_variables=[col], periods=[period])

    feature = df.drop(columns=[date_col_name, target_series]).columns.tolist()
    calendar_variables = select_top_features(data=df, features=feature, target=target_series, top_k=top_k)
    return calendar_variables  # type: ignore[return-value]


def load_dataset(
    dataset: str = "MLVS-PT",
    data_path: str | Path = "../../MLP-benchmark/dataset",
    rolling_type: list[str] | None = None,
    periods: list[int] | None = None,
    n_samples: int = 48,
    top_k: int = 2,
) -> tuple[pd.DataFrame, str, list[str], list[str], list[int], float, float]:
    """Load and preprocess dataset based on the dataset name.

    Args:
        dataset: Name of the dataset to load (e.g., 'MLVS-PT', 'ALBANIA').
        data_path: Path to the dataset directory.
        rolling_type (list[str], optional): List of rolling functions to apply. Defaults to ["mean"].
        periods (list[int], optional): List of periods for lag and rolling features. Defaults to [1, 2, 3, 4, 5, 6, 7].
        n_samples (int, optional): Number of samples in the input window. Defaults to 48.
        top_k (int, optional): Number of top features to select. Defaults to 5

    Returns:
        tuple containing:
            - DataFrame with the loaded data.
            - Target series name.
            - list of calendar variables.
            - list of exogenous features.
            - list of lag values.
            - Latitude of the location.
            - Longitude of the location.

    Raises:
        ValueError: If an unsupported dataset is provided.
    """
    if rolling_type is None:
        rolling_type = ["mean"]
    if periods is None:
        periods = [1, 2, 3, 4, 5, 6, 7]
    data_path = Path(data_path)
    if dataset == "ALBANIA":
        # calendar_variables = ["hour", "day_night", "wday", "yday"]
        # lags = []
        exogenous_features = ["Humidity", "Temperature"]
        target_series = "NetLoad"
        latitude = 41.1529058
        longitude = 20.1605717
        data = pd.read_parquet(data_path / "albania_res.parquet").reset_index().drop(columns=["index"])
        data = normalise_timestamp_column(data, "timestamp")
        data = data[["timestamp", target_series] + exogenous_features]

    elif dataset == "PV-MLVS-UK":
        # calendar_variables = ["hour", "day_night", "wday", "yday"]
        exogenous_features = ["Ghi"]
        target_series = "PV(MW)"
        # lags = []
        latitude = 55.3617609
        longitude = -3.4433238
        data = pd.read_parquet(data_path / "MLVS-UK.parquet").reset_index().drop(columns=["index"])
        data = normalise_timestamp_column(data, "timestamp")
        data = data[["timestamp", target_series] + exogenous_features]

    elif dataset == "PV-UK":
        # calendar_variables = ["hour", "day_night", "wday", "yday"]
        exogenous_features = ["Ghi", "Temperature"]
        target_series = "PV(MW)"
        # lags = []
        latitude = 55.3617609
        longitude = -3.4433238
        data = pd.read_parquet(data_path / "hybrid_res.parquet").reset_index().drop(columns=["index"])
        data = normalise_timestamp_column(data, "timestamp")
        data = data[["timestamp", target_series] + exogenous_features]

    elif dataset == "MLVS-PT":
        latitude = 32.371666
        longitude = -16.274998
        # calendar_variables = ["hour", "day_night", "wday", "yday"]
        exogenous_features = ["Ghi", "Temperature"]
        target_series = "NetLoad(kW)"
        # lags = []
        data = pd.read_parquet(data_path / "MLVS-PT.parquet")
        data = normalise_timestamp_column(data, "timestamp")
        data = data[["timestamp", target_series] + exogenous_features]

    elif dataset == "Building-Load":
        # calendar_variables = ["dayofyear", "week"]
        target_series = "Load(kW)"
        # lags = []
        latitude = 32.371666
        longitude = -16.274998
        exogenous_features = []
        data = pd.read_parquet(data_path / "MTP_Building_13_load_pv.parquet").reset_index()
        data = normalise_timestamp_column(data, "timestamp")
        data = data[["timestamp", target_series] + exogenous_features]

    elif dataset == "Building-PV":
        # calendar_variables = []
        exogenous_features = ["Ghi", "GtiFixedTilt"]
        target_series = "PV(kW)"
        # lags = [1]
        latitude = 32.371666
        longitude = -16.274998
        data = pd.read_parquet(data_path / "MTP_Building_13_load_pv.parquet").reset_index()
        data = normalise_timestamp_column(data, "timestamp")
        data = data[["timestamp", target_series] + exogenous_features]

    elif dataset == "UPAC":
        # calendar_variables = ["hour", "day_night", "wday", "yday"]
        exogenous_features = ["GHI"]
        target_series = "PV(W)"
        # lags = [1]
        latitude = 32.371666
        longitude = -16.274998
        data = pd.read_csv(data_path / "pr11_prod_2019-2021.csv").reset_index().drop(columns=["index"])
        # data = data[data["PV Power"] > 0]
        data = normalise_timestamp_column(data, "timestamp")
        data.rename(columns={"PV Power": "PV(W)"}, inplace=True)
        data = data[["timestamp", target_series] + exogenous_features]

    elif dataset in ("ETTh1", "ETTh2"):
        # Electricity Transformer Temperature datasets (hourly, 7 features).
        # Download from: https://github.com/zhouhaoyi/ETDataset
        # Expected file: examples/data/ETTh1.csv  or  ETTh2.csv
        # Columns: date, HUFL, HULL, MUFL, MULL, LUFL, LULL, OT  # codespell:ignore ot
        # Target: OT (oil temperature).  Exogenous: 6 transformer-load features.  # codespell:ignore ot
        # Approximate location: Yunnan Province, China.
        target_series = "OT"  # codespell:ignore ot
        exogenous_features = ["HUFL", "HULL", "MUFL", "MULL", "LUFL", "LULL"]
        latitude = 25.0
        longitude = 102.0
        csv_path = data_path / f"{dataset}.csv"
        if not csv_path.exists():
            raise FileNotFoundError(
                f"{dataset} CSV not found at '{csv_path}'.\n"
                "Download from https://github.com/zhouhaoyi/ETDataset and place "
                f"'{dataset}.csv' in the data directory.",
            )
        data = pd.read_csv(csv_path)
        data.rename(columns={"date": "timestamp"}, inplace=True)
        data = normalise_timestamp_column(data, "timestamp")
        data = data[["timestamp", target_series] + exogenous_features]

    else:
        raise ValueError(f"Unsupported dataset: {dataset}")
    data.fillna(method="ffill", inplace=True)
    data = data.dropna()
    historical_features = get_best_autoregessive_features(
        data=data,
        target_series=target_series,
        rolling_type=rolling_type,
        periods=periods,
        n_samples=n_samples,
        top_k=top_k,
    )
    calendar_features = get_best_temporal_features(
        data=data,
        target_series=target_series,
        latitude=latitude,
        longitude=longitude,
        date_col_name="timestamp",
        top_k=top_k,
    )

    periods = sorted({int(feat.split("_")[-1]) for feat in historical_features if "lag" in feat or "rolling" in feat})
    rolling_type = sorted({feat.split("_")[-3] for feat in historical_features if "rolling" in feat})
    max_period = max(periods) if periods else 0
    periods = [int(p / n_samples) for p in periods]
    if max_period > 0:
        auto_res = AutoregressTransformer(
            n_samples=n_samples,
            lags=periods,
            windows=periods,
            window_funcs=rolling_type,
            value_column=target_series,
        )
    data = auto_res.fit_transform(data.copy())[max_period:]

    return (
        data,
        target_series,
        calendar_features,
        exogenous_features,
        historical_features,
        latitude,
        longitude,
    )
