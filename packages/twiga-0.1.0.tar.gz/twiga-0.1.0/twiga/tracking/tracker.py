"""MLflow experiment tracker for Twiga forecasting workflows.

This module provides the TwigaTracker class, a context manager designed to bridge
TwigaForecaster workflows with MLflow 2.x. It handles lifecycle management,
custom PyFunc serialization to ensure preprocessing pipelines are preserved,
dataset lineage tracking, and system metric logging.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
import shutil
import subprocess
import tempfile
import traceback
from typing import TYPE_CHECKING, Any

import pandas as pd

from twiga.core.exceptions import require_extra

require_extra("mlflow", "mlops")

import mlflow  # noqa: E402
import mlflow.data  # noqa: E402
import mlflow.pyfunc  # noqa: E402
import mlflow.pytorch  # noqa: E402

if TYPE_CHECKING:
    from twiga.forecaster.core import TwigaForecaster

log = logging.getLogger(__name__)


class TwigaForecasterWrapper(mlflow.pyfunc.PythonModel):
    """A PyFunc wrapper to ensure TwigaForecaster remains reproducible.

    This wrapper ensures that when a model is loaded from the MLflow Registry,
    the full TwigaForecaster object (including its DataPipeline and Conformal
    logic) is used for inference, regardless of whether the underlying
    architecture is PyTorch or Scikit-Learn.
    """

    def __init__(self, forecaster: TwigaForecaster) -> None:
        """Initializes the wrapper with a fitted forecaster."""
        self.forecaster = forecaster

    def predict(self, context: mlflow.pyfunc.PythonModelContext, model_input: pd.DataFrame) -> pd.DataFrame:
        """Unified prediction interface for MLflow serving.

        Args:
            context: MLflow context for the model.
            model_input: Input features for prediction.

        Returns:
            pd.DataFrame: Point forecasts.
        """
        predictions, _ = self.forecaster.evaluate_point_forecast(model_input)
        return predictions


class TwigaTracker:
    """Context manager for tracking Twiga experiments in MLflow.

    Provides high-level utilities for logging metadata, models, and evaluation
    results while maintaining strict MLOps standards for lineage and reproducibility.
    """

    def __init__(
        self,
        experiment: str = "twiga",
        run_name: str | None = None,
        tracking_uri: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> None:
        """Initializes the tracker and sets the tracking URI.

        Args:
            experiment: Name of the MLflow experiment.
            run_name: Optional name for this specific run.
            tracking_uri: Optional URI for the MLflow tracking server.
            tags: Initial tags to attach to the run.
        """
        self.experiment = experiment
        self.run_name = run_name
        self.tags = tags or {}
        self._run: mlflow.ActiveRun | None = None

        if tracking_uri:
            mlflow.set_tracking_uri(tracking_uri)

    def _get_git_commit(self) -> str | None:
        """Safely retrieves the current git commit hash."""
        git_exe = shutil.which("git")
        if not git_exe:
            return None

        try:
            return subprocess.check_output(  # noqa: S603
                [git_exe, "rev-parse", "HEAD"],
                stderr=subprocess.DEVNULL,
                timeout=5,
                text=True,
            ).strip()
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            return None

    def __enter__(self) -> TwigaTracker:
        """Starts an MLflow run and enables system metrics logging.

        Returns:
            TwigaTracker: The current instance with an active run.
        """
        mlflow.set_experiment(self.experiment)

        # Enable 2.x System Metrics (CPU/GPU/RAM)
        mlflow.enable_system_metrics_logging()

        # Add Git Metadata using the safe helper method
        if commit := self._get_git_commit():
            self.tags["mlflow.source.git.commit"] = commit
        else:
            log.warning("Git commit capture skipped or failed.")

        try:
            from prefect.runtime import flow_run

            self.tags["prefect.run_id"] = flow_run.id
        except ImportError:
            pass

        self._run = mlflow.start_run(run_name=self.run_name, tags=self.tags)
        return self

    @property
    def run_id(self) -> str:
        """The active MLflow run ID, or ``'unknown'`` if no run is active."""
        return self._run.info.run_id if self._run else "unknown"

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Ends the MLflow run and captures error traces on failure.

        Args:
            exc_type: Exception class.
            exc_val: Exception instance.
            exc_tb: Exception traceback.
        """
        if exc_type:
            status = "FAILED"
            # Log full traceback for better debugging
            error_trace = "".join(traceback.format_exception(exc_type, exc_val, exc_tb))
            mlflow.log_text(error_trace, "diagnostics/error_trace.log")
            mlflow.set_tag("error.message", str(exc_val))
            mlflow.set_tag("error.type", exc_type.__name__)
        else:
            status = "FINISHED"

        mlflow.end_run(status=status)

    def log_dataset(
        self,
        df: pd.DataFrame,
        name: str,
        source: str = "unknown",
        context: str = "training",
    ) -> None:
        """Logs dataset lineage for reproducibility.

        Args:
            df: The pandas DataFrame to track.
            name: Human-readable name of the dataset.
            source: Origin of data (e.g., S3 URI, SQL Query).
            context: Context of the data usage (e.g., 'training', 'test').
        """
        dataset = mlflow.data.from_pandas(df, source=source, name=name)
        mlflow.log_input(dataset, context=context)

    def log_forecaster_metadata(self, forecaster: Any) -> None:
        """Harvests all available configurations and hyperparameters.

        Consolidates Pydantic configs and top-level primitive attributes into
        MLflow parameters.
        """
        params: dict[str, Any] = {}

        # 1. Harvest from Pydantic config objects
        configs = ["data_pipeline", "conformal_params", "train_params", "model_params"]
        for cfg_name in configs:
            if cfg := getattr(forecaster, cfg_name, None):
                # Robust Pydantic-to-dict conversion
                if hasattr(cfg, "model_dump"):  # Pydantic v2
                    data = cfg.model_dump()
                elif hasattr(cfg, "dict"):  # Pydantic v1
                    data = cfg.dict()
                else:
                    data = cfg

                # Ensure we have a dictionary before flattening
                if isinstance(data, dict):
                    prefix = cfg_name.split("_")[0]
                    params.update(self._flatten_dict(data, prefix=prefix))
                else:
                    # Fallback for unexpected types
                    params[cfg_name] = str(data)

        # 2. Harvest top-level primitive attributes (skipping duplicates)
        for k, v in forecaster.__dict__.items():
            if isinstance(v, (int, float, str, bool)) and not k.startswith("_") and k not in params:
                params[k] = v

        # 3. Size-safe logging
        self._send_to_mlflow(params)

    def _send_to_mlflow(self, params: dict[str, Any]) -> None:
        """Internal helper to handle MLflow's 4000 char limit."""
        safe_params: dict[str, str] = {}
        for k, v in params.items():
            val_str = str(v)
            if len(val_str) > 4000:
                mlflow.log_text(val_str, f"params/{k}.json")
                safe_params[k] = "logged_as_artifact"
            else:
                safe_params[k] = val_str
        mlflow.log_params(safe_params)

    def log_model(self, forecaster: TwigaForecaster, sample_input: pd.DataFrame) -> None:
        """Logs the entire forecaster as a PyFunc model with environment dependencies.

        Args:
            forecaster: The fitted TwigaForecaster.
            sample_input: Sample data used to infer the model schema/signature.
        """
        try:
            predictions_df, _ = forecaster.evaluate_point_forecast(sample_input)
            signature = mlflow.models.infer_signature(sample_input, predictions_df)
        except Exception:
            # Signature inference is best-effort - fall back to no signature
            # so that a misconfigured sample_input never blocks model logging.
            log.warning(
                "Could not infer MLflow model signature from sample_input; logging model without signature.",
                exc_info=True,
            )
            signature = None

        # Generate standard environment
        conda_env = mlflow.pyfunc.get_default_conda_env()

        # Add Twiga-specific dependencies.
        # Package name is "twiga" (as defined in pyproject.toml).
        conda_env["dependencies"][-1]["pip"].extend(
            [
                "twiga",
                "lightning>=2.0",
                "pydantic>=2.0",
            ]
        )

        mlflow.pyfunc.log_model(
            artifact_path="model",
            python_model=TwigaForecasterWrapper(forecaster),
            signature=signature,
            conda_env=conda_env,
            registered_model_name=f"{forecaster.project_name}_{forecaster.model_type}",
        )

    def log_evaluation(self, metrics_df: pd.DataFrame, results_df: pd.DataFrame) -> None:
        """Logs summary metrics and interactive evaluation tables.

        Args:
            metrics_df: DataFrame containing computed metrics per split/sample.
            results_df: DataFrame containing actual values and predictions.
        """
        # Log mean metrics
        numeric_metrics = metrics_df.select_dtypes("number").mean().to_dict()
        mlflow.log_metrics(numeric_metrics)

        # MLflow 2.5+ Table Logging
        mlflow.log_table(data=results_df, artifact_file="evaluation/predictions.json")

        # Fallback to Parquet via temporary directory
        with tempfile.TemporaryDirectory() as tmp_dir:
            temp_path = Path(tmp_dir) / "eval_results.parquet"
            results_df.to_parquet(temp_path)
            mlflow.log_artifact(str(temp_path), "evaluation")

    @staticmethod
    def _flatten_dict(d: dict[str, Any], prefix: str = "", sep: str = ".") -> dict[str, Any]:
        """Recursively flattens nested dictionaries for parameter logging.

        Args:
            d: Dictionary to flatten.
            prefix: String to prepend to keys.
            sep: Separator between nested keys.

        Returns:
            dict[str, Any]: A flat dictionary.
        """
        out: dict[str, Any] = {}
        for k, v in d.items():
            full_key = f"{prefix}{sep}{k}" if prefix else k
            if isinstance(v, dict):
                out.update(TwigaTracker._flatten_dict(v, prefix=full_key, sep=sep))
            elif isinstance(v, (list, tuple)):
                out[full_key] = json.dumps(v)
            else:
                out[full_key] = v
        return out
