"""Twiga MLflow experiment tracking integration.

Provides a :class:`TwigaTracker` context manager that wraps MLflow runs
and integrates transparently with the :class:`~twiga.forecaster.core.TwigaForecaster`
training and evaluation workflow.

Example::

    from twiga.tracking import TwigaTracker

    with TwigaTracker(experiment="energy-forecast", run_name="lgbm-v1") as tracker:
        forecaster.fit(train_df, val_df)
        _, metrics = forecaster.evaluate(test_df)
        tracker.log_metrics(metrics)
        tracker.log_forecaster(forecaster)
"""

from __future__ import annotations

from twiga.tracking.tracker import TwigaTracker

__all__ = ["TwigaTracker"]
