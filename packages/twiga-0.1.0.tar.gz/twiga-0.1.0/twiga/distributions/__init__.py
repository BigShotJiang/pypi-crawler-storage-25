"""Probabilistic distribution heads and conformal prediction for Twiga.

Sub-packages:
  distributions.conformal  - post-hoc conformal prediction wrappers
  distributions.nn         - parametric / quantile / CRC output heads
"""

from twiga.distributions.conformal import (
    BaseConformal,
    Conformal,
    ConformalQuantileRegressor,
    ConformalResidualFitting,
    SplitConformal,
)

# distributions.nn imports are intentionally NOT eagerly aggregated here
# to avoid a circular dependency: distributions.nn.fpquantile depends on
# twiga.models.nn.core.embedding, which would trigger twiga.models.nn
# before the forecaster package has finished loading.
# Import directly from twiga.distributions.nn if you need the nn heads.

__all__ = [
    "BaseConformal",
    "Conformal",
    "ConformalQuantileRegressor",
    "ConformalResidualFitting",
    "SplitConformal",
]
