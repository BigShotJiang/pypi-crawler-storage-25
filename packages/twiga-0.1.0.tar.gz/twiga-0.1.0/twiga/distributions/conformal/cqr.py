import numpy as np

from twiga.distributions.conformal.base import BaseConformal


class ConformalQuantileRegressor(BaseConformal):
    """Conformal quantile regression for uncertainty estimation.

    Implements conformal prediction intervals for quantile regression models using
    either scaled or unscaled non-conformity scores.

    Attributes:
        score_type (str): Type of non-conformity score ('scaled' or 'unscaled')
        alpha (float): Significance level for prediction intervals
        q_hat (float | np.ndarray): Calibrated threshold(s)
        _EPS (float): Numerical stability constant

    Args:
        score_type: Score calculation method. Defaults to 'scaled'.
        alpha: Significance level (0 < alpha < 1). Defaults to 0.1.

    Raises:
        ValueError: For invalid score_type or alpha values.
    """

    _EPS: float = 1e-6

    def __init__(self, score_type: str = "scaled", alpha: float = 0.1) -> None:
        super().__init__(alpha)  # Pass only alpha to BaseConformal
        if score_type not in ("scaled", "unscaled"):
            raise ValueError(f"Invalid score_type: {score_type}")
        self.score_type = score_type
        if not 0 < alpha < 1:
            raise ValueError("alpha must be between 0 and 1")

    def get_scores(self, lower_quantile: np.ndarray, upper_quantile: np.ndarray, targets: np.ndarray) -> np.ndarray:
        """Computes non-conformity scores for quantile predictions.

        Args:
            lower_quantile: Predicted lower quantiles
            upper_quantile: Predicted upper quantiles
            targets: Ground truth values

        Returns:
            Array of non-conformity scores
        """
        self._validate_inputs(lower_quantile, targets)
        self._validate_inputs(upper_quantile, targets)

        if self.score_type == "scaled":
            return self._calculate_scaled_cqr_score(lower_quantile, upper_quantile, targets)
        return self._calculate_unscaled_cqr_score(lower_quantile, upper_quantile, targets)

    def _calculate_unscaled_cqr_score(
        self,
        lower_quantile: np.ndarray,
        upper_quantile: np.ndarray,
        targets: np.ndarray,
    ) -> np.ndarray:
        """Calculates unscaled conformity scores."""
        return np.maximum(lower_quantile - targets, targets - upper_quantile)

    def _calculate_scaled_cqr_score(
        self,
        lower_quantile: np.ndarray,
        upper_quantile: np.ndarray,
        targets: np.ndarray,
    ) -> np.ndarray:
        """Calculates scaled conformity scores."""
        scaling_factor = upper_quantile - lower_quantile + ConformalQuantileRegressor._EPS
        return np.maximum((lower_quantile - targets) / scaling_factor, (targets - upper_quantile) / scaling_factor)

    def generate_intervals(
        self,
        lower_quantile: np.ndarray,
        upper_quantile: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Generates calibrated prediction intervals.

        Args:
            lower_quantile: Predicted lower quantiles
            upper_quantile: Predicted upper quantiles

        Returns:
            Tuple of (lower intervals, upper intervals)
        """
        if self.score_type == "scaled":
            scaling_factor = upper_quantile - lower_quantile + ConformalQuantileRegressor._EPS
            return (lower_quantile - self.q_hat * scaling_factor, upper_quantile + self.q_hat * scaling_factor)
        return (lower_quantile - self.q_hat, upper_quantile + self.q_hat)
