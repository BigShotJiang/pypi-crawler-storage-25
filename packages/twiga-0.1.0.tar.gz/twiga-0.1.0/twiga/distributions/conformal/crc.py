import numpy as np

from twiga.distributions.conformal.base import BaseConformal


class ConformalResidualFitting(BaseConformal):
    """Conformal residual fitting for uncertainty estimation.

    Implements conformal prediction intervals using residual-based scoring with
    optional scale adaptation.

    Attributes:
        score_type (str): Score calculation method ('res' or 'sign-res')
        alpha (float): Significance level for intervals
        q_hat (float | np.ndarray): Calibrated threshold(s)

    Args:
        score_type: Residual scoring method. Defaults to 'res'.
        alpha: Significance level (0 < alpha < 1). Defaults to 0.1.

    Raises:
        ValueError: For invalid score_type or alpha values.
    """

    def __init__(self, score_type: str = "res", alpha: float = 0.1) -> None:
        """Initializes residual fitter with validation."""
        if score_type not in ("res", "sign-res"):
            raise ValueError(f"Invalid score_type: {score_type}")
        if not 0 < alpha < 1:
            raise ValueError("alpha must be between 0 and 1")
        self.score_type = score_type
        self.alpha = alpha

    def _validate_scale(self, sigma: np.ndarray, targets: np.ndarray) -> None:
        """Validates scale factor array.

        Args:
            sigma: Scale factors array
            targets: Ground truth values

        Raises:
            ValueError: For invalid scale factors or shape mismatch
        """
        if np.any(sigma <= 0) or np.any(np.isnan(sigma)):
            raise ValueError("Scale factors must be positive and non-null")
        self._validate_inputs(sigma, targets)

    def get_scores(self, predicts: np.ndarray, sigma: np.ndarray, targets: np.ndarray) -> np.ndarray:
        """Computes scaled residual scores.

        Args:
            predicts: Model predictions
            sigma: Scale factors
            targets: Ground truth values

        Returns:
            Array of non-conformity scores
        """
        self._validate_inputs(predicts, targets)
        self._validate_scale(sigma, targets)

        if self.score_type == "res":
            return self._calculate_signed_residuals(predicts, sigma, targets)
        return self._calculate_absolute_residuals(predicts, sigma, targets)

    @staticmethod
    def _calculate_signed_residuals(loc: np.ndarray, sigma: np.ndarray, targets: np.ndarray) -> np.ndarray:
        """Computes signed residuals normalized by scale."""
        return (loc - targets) / sigma

    @staticmethod
    def _calculate_absolute_residuals(loc: np.ndarray, sigma: np.ndarray, targets: np.ndarray) -> np.ndarray:
        """Computes absolute residuals normalized by scale."""
        return np.abs(loc - targets) / sigma

    def generate_intervals(self, loc: np.ndarray, sigma: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Generates calibrated prediction intervals.

        Args:
            loc: Point estimates
            sigma: Scale factors

        Returns:
            Tuple of (lower intervals, upper intervals)
        """
        return (loc - sigma * self.q_hat, loc + sigma * self.q_hat)
