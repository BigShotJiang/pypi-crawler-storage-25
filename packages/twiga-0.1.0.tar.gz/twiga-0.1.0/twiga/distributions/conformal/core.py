from twiga.distributions.conformal.base import SplitConformal
from twiga.distributions.conformal.cqr import ConformalQuantileRegressor
from twiga.distributions.conformal.crc import ConformalResidualFitting


class Conformal:
    """Factory class to create method-specific conformal predictors."""

    def __new__(  # type: ignore[misc]
        cls,
        method: str,
        score_type: str = "res",
        alpha: float = 0.1,
    ) -> SplitConformal | ConformalQuantileRegressor | ConformalResidualFitting:
        method_map = {
            "residual": SplitConformal,
            "quantile": ConformalQuantileRegressor,
            "residual-fitting": ConformalResidualFitting,
        }

        if method not in method_map:
            raise ValueError(f"Invalid method: {method}")

        # Return an instance of the selected subclass
        return method_map[method](score_type=score_type, alpha=alpha)  # type: ignore[abstract, return-value]
