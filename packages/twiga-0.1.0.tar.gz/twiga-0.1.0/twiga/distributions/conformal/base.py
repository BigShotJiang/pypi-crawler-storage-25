from abc import ABC, abstractmethod
import math

import numpy as np

from twiga.core.utils.logger import get_logger

log = get_logger(__name__)


import warnings


def calculate_conformal_value(scores: np.ndarray, alpha: float, axis: int = 0) -> np.ndarray:
    """Calculate the 1-alpha quantile of scores for conformal prediction using NumPy.

    This function computes the threshold value (quantile) used to construct prediction
    sets based on the given non-conformity scores and significance level alpha.
    If the scores are empty or the quantile value exceeds 1,
    it returns an array of np.inf.

    Args:
        scores (np.ndarray): Non-conformity scores with shape (N, ...).
        alpha (float): Significance level, must be between 0 and 1.
        axis (int): Axis along which to compute the quantile. Defaults to 0.

    Returns:
        np.ndarray: The threshold value used to construct prediction sets, with shape
        (scores.shape[1:]).

    Raises:
        ValueError: If alpha is not between 0 and 1.
    """
    if alpha >= 1 or alpha <= 0:
        raise ValueError("Significance level 'alpha' must be in (0,1).")

    if scores.size == 0 or scores.shape[0] == 0:
        warnings.warn(
            "The number of scores is 0, which is invalid. \
                      The threshold is set to inf.",
            stacklevel=2,
        )
        return np.full(scores.shape[1:], np.inf)

    num_sample = scores.shape[0]
    mid_point = math.ceil((num_sample + 1) * (1 - alpha))

    if mid_point > num_sample:
        warnings.warn(
            f"The quantile value exceeds 1 (k={mid_point}, N={num_sample}). \
                The threshold is set to inf. Consider increasing the number of samples.",
            stacklevel=2,
        )
        return np.full(scores.shape[1:], np.inf)

    k_index = mid_point - 1  # Convert to 0-based index
    partitioned = np.partition(scores, k_index, axis=0)
    return partitioned[k_index]


class BaseConformal(ABC):
    """Abstract base class for Conformal Prediction in Regression.

    Provides core functionality for constructing prediction intervals with
    finite-sample coverage guarantees.

    Attributes:
        alpha (float): Significance level for prediction intervals (0 < alpha < 1).
        q_hat (float | np.ndarray): Calibrated threshold(s) for intervals.


    Args:
        alpha: Significance level (0 < alpha < 1). Defaults to 0.1.

    Raises:
        ValueError: If alpha is not in (0, 1).
    """

    def __init__(self, alpha: float = 0.1) -> None:
        """Initializes base conformal predictor with validation."""
        if not 0 < alpha < 1:
            raise ValueError(f"Invalid alpha {alpha}: must be in (0, 1)")

        self.alpha = alpha
        self.q_hat: float | np.ndarray = 0.0

    def _validate_inputs(self, predictions: np.ndarray, targets: np.ndarray) -> None:
        """Validates shape consistency between predictions and targets.

        Args:
            predictions: Model outputs array
            targets: Ground truth values array

        Raises:
            ValueError: For shape mismatch
        """
        if predictions.shape != targets.shape:
            raise ValueError(f"Shape mismatch: predictions {predictions.shape} vs targets {targets.shape}")

    def calibrate(self, *calib_args, axis: int = 0) -> None:
        """Calibrates conformal thresholds using provided arguments.

        Args:
            *calib_args: Implementation-specific calibration data
            axis: Axis for quantile computation. Defaults to 0.

        Raises:
            ValueError: If calibration data validation fails
        """
        scores = self.get_scores(*calib_args)
        self.q_hat = self.calculate_conformal_quantile(scores, axis=axis)

    def calculate_conformal_quantile(self, scores: np.ndarray, axis: int = 0) -> float | np.ndarray:
        """Computes (1-alpha)-adjusted quantile of non-conformity scores.

        Implements conformal quantile adjustment from Lei et al. (2017).

        Args:
            scores: Non-conformity scores array
            axis: Quantile computation axis. Defaults to 0.

        Returns:
            Quantile values for interval construction

        Raises:
            ValueError: For empty scores array
        """
        if scores.size == 0:
            raise ValueError("Cannot compute quantile from empty scores array")

        try:
            return calculate_conformal_value(scores, self.alpha, axis)

        except Exception:
            log.exception("Quantile calculation failed")
            raise

    @abstractmethod
    def get_scores(self, *args) -> np.ndarray:
        """Computes non-conformity scores from inputs.

        Must be implemented by concrete subclasses.

        Returns:
            Array of non-conformity scores
        """
        raise NotImplementedError("Subclasses must implement get_scores")

    @abstractmethod
    def generate_intervals(self, *pred_args) -> tuple[np.ndarray, np.ndarray]:
        """Generates prediction intervals from inputs.

        Must be implemented by concrete subclasses.

        Returns:
            Tuple of (lower bounds, upper bounds)
        """
        raise NotImplementedError("Subclasses must implement generate_intervals")


class SplitConformal(BaseConformal):
    """Implements residual-based conformal prediction for regression tasks.

    Attributes:
        score_type (str): Type of non-conformity score ('res' or 'sign-res').
    """

    def __init__(self, score_type: str = "res", alpha: float = 0.1):
        super().__init__(alpha)
        if score_type not in ("res", "sign-res"):
            raise ValueError(f"Invalid score_type: {score_type}")
        self.score_type = score_type

    def get_scores(self, predicts: np.ndarray, targets: np.ndarray) -> np.ndarray:
        """Computes non-conformity scores based on residuals.

        Args:
            predicts (np.ndarray): Model predictions.
            targets (np.ndarray): Ground truth targets.

        Returns:
            np.ndarray: Non-conformity scores.
        """
        self._validate_inputs(predicts, targets)
        if self.score_type == "res":
            return np.abs(targets - predicts)
        return targets - predicts

    def generate_intervals(self, mu_pred: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Generates prediction intervals.

        Args:
            mu_pred (np.ndarray): Model predictions.

        Returns:
            tuple[np.ndarray, np.ndarray]: Lower and upper bounds.
        """
        return mu_pred - self.q_hat, mu_pred + self.q_hat
