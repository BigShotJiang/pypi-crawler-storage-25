import numpy as np
from numpy.typing import NDArray


def interpolate_quantile(
    predictions: NDArray[np.float64],
    sorted_quantiles: list[float] | NDArray[np.float64],
    target_quantile: float = 0.5,
) -> NDArray[np.float64]:
    """Interpolate predictions at a target quantile using linear interpolation.

    Args:
        predictions: Array of predictions with shape (B, Q, C), where B is batch size,
            Q is number of quantiles, and C is number of channels.
        sorted_quantiles: Sorted list or array of quantile levels (e.g., [0.1, 0.3, 0.7]).
        target_quantile: The target quantile to interpolate (default: 0.5 for median).

    Returns:
        Interpolated predictions at target_quantile with shape (B, C).

    Raises:
        ValueError: If sorted_quantiles is empty, predictions has incorrect shape,
            number of quantiles does not match predictions, quantiles are not sorted,
            or target_quantile is outside the range of sorted_quantiles.
    """
    # Convert inputs to NumPy arrays
    predictions = np.asarray(predictions, dtype=np.float64)
    sorted_quantiles = np.asarray(sorted_quantiles, dtype=np.float64)

    # Validate inputs
    if len(sorted_quantiles) == 0:
        raise ValueError("sorted_quantiles cannot be empty")
    if predictions.shape[1] != len(sorted_quantiles):
        raise ValueError(
            f"Number of quantiles ({predictions.shape[1]}) must match "
            f"length of sorted_quantiles ({len(sorted_quantiles)})",
        )

    if not np.all(sorted_quantiles[:-1] <= sorted_quantiles[1:]):
        raise ValueError("sorted_quantiles must be sorted in ascending order")

    # Check if target_quantile exists in sorted_quantiles
    if target_quantile in sorted_quantiles:
        idx = np.where(sorted_quantiles == target_quantile)[0][0]
        return predictions[:, idx, :]

    # Find indices where quantiles are below target_quantile
    lower_mask = sorted_quantiles < target_quantile
    if not lower_mask.any() or lower_mask.all():
        raise ValueError(
            f"Cannot interpolate: {target_quantile} is outside the range of provided quantiles {sorted_quantiles}",
        )

    # Get indices for interpolation
    lower_idx = np.where(lower_mask)[0][-1]  # Last index where quantile < target
    upper_idx = lower_idx + 1  # First index where quantile > target

    # Get quantile values and corresponding predictions
    p_lower, p_upper = sorted_quantiles[lower_idx], sorted_quantiles[upper_idx]
    q_lower, q_upper = predictions[:, lower_idx, :], predictions[:, upper_idx, :]

    # Compute interpolation weight
    weight = (target_quantile - p_lower) / (p_upper - p_lower)

    # Perform linear interpolation
    return q_lower + (q_upper - q_lower) * weight


def get_median_prediction(
    predictions: NDArray[np.float64],
    quantiles: list[float] | NDArray[np.float64],
) -> NDArray[np.float64]:
    """Compute the median prediction (quantile = 0.5) for given predictions.

    Args:
        predictions: Array of predictions with shape (B, Q, C), where B is batch size,
            Q is number of quantiles, and C is number of channels.
        quantiles: List or array of quantile levels (e.g., [0.1, 0.3, 0.7]).

    Returns:
        Median predictions with shape (B, C).

    Raises:
        ValueError: If quantiles is empty, predictions has incorrect shape,
            or number of quantiles does not match predictions.
    """
    sorted_quantiles = np.asarray(sorted(quantiles), dtype=np.float64)
    return interpolate_quantile(predictions, sorted_quantiles, target_quantile=0.5)


def get_sigma_prediction(
    predictions: NDArray[np.float64],
    quantiles: list[float] | NDArray[np.float64],
) -> NDArray[np.float64]:
    """Compute sigma using predictions at quantiles 0.25 and 0.75.

    Sigma is calculated as (upper_prediction - lower_prediction) / (2 * 0.6745),
    where upper_prediction and lower_prediction are at quantiles 0.75 and 0.25,
    respectively, and 0.6745 is the z-score for the 25th/75th percentiles.

    Args:
        predictions: Array of predictions with shape (B, Q, C), where B is batch size,
            Q is number of quantiles, and C is number of channels.
        quantiles: List or array of quantile levels (e.g., [0.1, 0.3, 0.7]).

    Returns:
        Sigma predictions with shape (B, C).

    Raises:
        ValueError: If quantiles is empty, predictions has incorrect shape,
            number of quantiles does not match predictions, or interpolation
            is not possible for quantiles 0.25 or 0.75.
    """
    sorted_quantiles = np.asarray(sorted(quantiles), dtype=np.float64)
    lower_prediction = interpolate_quantile(predictions, sorted_quantiles, target_quantile=0.25)
    upper_prediction = interpolate_quantile(predictions, sorted_quantiles, target_quantile=0.75)
    return (upper_prediction - lower_prediction) / (2 * 0.6745)
