"""Probabilistic output heads for neural time series forecasting.

Each distribution module shares a common interface:

    forward(x)              → distribution parameters as tensors
    get_distribution(...)   → torch.distributions object
    get_log_likelihood(...) → negative log-likelihood scalar

Supported distributions and their typical use cases:

    NormalDistribution           - symmetric, unbounded targets (energy demand, temperature)
    LaplaceDistribution          - like Normal but robust to outliers (heavy-tailed residuals)
    StudentTDistribution         - heavier tails than Normal, finite-variance (financial returns)
    LogNormalDistribution        - strictly positive, right-skewed targets (prices, volumes)
    GammaDistribution            - strictly positive, flexible shape (load, wind speed)
    BetaDistribution             - bounded [0, 1] targets (capacity factors, fill rates)
    AdditiveNormalDistribution   - Normal head preserving additive backbone structure (MLPGAM/MLPGAF)
    AdditiveLaplaceDistribution  - Laplace head preserving additive backbone structure
    AdditiveStudentTDistribution - Student-T head preserving additive backbone structure
    AdditiveLogNormalDistribution - Log-Normal head preserving additive backbone structure
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any

import torch
from torch import nn
import torch.nn.functional as F

# ── Base ──────────────────────────────────────────────────────────────────────


class BaseDistribution(ABC, nn.Module):
    """Abstract base for probabilistic output heads.

    Subclasses must implement :meth:`forward`, :meth:`get_distribution`,
    and :meth:`get_log_likelihood`.

    All heads share the same input contract:
        x: (B, hidden_size) - latent representation from encoder/decoder.

    All heads share the same output contract for forecasting tensors:
        shape (B, forecast_horizon, num_target_output).
    """

    def __init__(
        self,
        num_target_output: int,
        hidden_size: int,
        forecast_horizon: int,
    ) -> None:
        super().__init__()

        if num_target_output <= 0:
            raise ValueError("num_target_output must be positive")
        if hidden_size <= 0:
            raise ValueError("hidden_size must be positive")
        if forecast_horizon <= 0:
            raise ValueError("forecast_horizon must be positive")

        self.num_target_output = num_target_output
        self.forecast_horizon = forecast_horizon
        self.hidden_size = hidden_size

    def _reshape(self, t: torch.Tensor) -> torch.Tensor:
        """Reshape flat (B, H*O) → (B, H, O)."""
        return t.view(t.size(0), self.forecast_horizon, self.num_target_output)

    def _make_linear(self) -> nn.Linear:
        """Convenience: linear projecting hidden_size → H * O."""
        return nn.Linear(self.hidden_size, self.forecast_horizon * self.num_target_output)

    @abstractmethod
    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, ...]:
        """Map latent x → distribution parameters."""

    @abstractmethod
    def get_distribution(self, *params: torch.Tensor) -> torch.distributions.Distribution:
        """Construct a torch Distribution from predicted parameters."""

    @abstractmethod
    def get_log_likelihood(self, *params: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """Return mean negative log-likelihood over the batch."""

    def forecast(self, z: torch.Tensor) -> tuple[torch.Tensor, ...]:
        """Inference-mode forward (no gradient).

        Args:
            z: Latent tensor of shape ``(B, hidden_size)`` from the backbone.

        Returns:
            Tuple of distribution parameter tensors, same as :meth:`forward`.
            The first element is always the location/mean parameter.
        """
        with torch.no_grad():
            return self(z)

    def step(
        self,
        z: torch.Tensor,
        y: torch.Tensor,
        metric_fn: Callable[..., Any],
        epoch: int | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Compute NLL loss and metric for one training/validation step.

        Args:
            z: Latent tensor of shape ``(B, hidden_size)`` from the backbone.
            y: Target tensor of shape ``(B, forecast_horizon, num_target_output)``.
            metric_fn: Callable returning a scalar metric given ``(pred, target)``.
            epoch: Current epoch (unused here; available for subclasses).

        Returns:
            Tuple of ``(nll_loss, metric)``.
        """
        params = self(z)
        loss = self.get_log_likelihood(*params, targets=y)
        metric = metric_fn(params[0], y)  # params[0] is always the location/mean
        return loss, metric


# ── Normal ────────────────────────────────────────────────────────────────────


class NormalDistribution(BaseDistribution):
    """Normal (Gaussian) output head.

    Best for: symmetric, unbounded targets - energy demand, temperature.

    Parameters predicted:
        mu    - mean (unconstrained)
        sigma - std dev  (exp of log_scale, strictly positive)

    Args:
        num_target_output: Number of output features per time step.
        hidden_size: Dimensionality of the input latent vector.
        forecast_horizon: Number of forecast time steps.
        out_activation_function: Optional activation applied to mu. Defaults to Identity.
    """

    def __init__(
        self,
        num_target_output: int = 1,
        hidden_size: int = 256,
        forecast_horizon: int = 48,
        out_activation_function: nn.Module | None = None,
    ) -> None:
        super().__init__(num_target_output, hidden_size, forecast_horizon)
        self.mu_layer = nn.Sequential(
            self._make_linear(),
            out_activation_function or nn.Identity(),
        )
        self.log_scale_layer = self._make_linear()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Predict mu and sigma.

        Args:
            x: Latent tensor of shape (B, hidden_size).

        Returns:
            Tuple of (mu, sigma), each of shape (B, forecast_horizon, num_target_output).
        """
        mu = self._reshape(self.mu_layer(x))
        sigma = self._reshape(self.log_scale_layer(x)).mul(0.5).exp()
        return mu, sigma

    def get_distribution(self, mu: torch.Tensor, sigma: torch.Tensor) -> torch.distributions.Normal:  # type: ignore[override]
        return torch.distributions.Normal(mu, sigma)

    def get_log_likelihood(self, mu: torch.Tensor, sigma: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        return -self.get_distribution(mu, sigma).log_prob(targets).mean()


# ── Laplace ───────────────────────────────────────────────────────────────────


class LaplaceDistribution(BaseDistribution):
    """Laplace output head.

    Best for: targets with heavier tails than Normal, robust to outliers -
    electricity prices, wind speed residuals.

    Parameters predicted:
        mu    - location (unconstrained)
        scale - scale (exp of log_scale, strictly positive)
    """

    def __init__(
        self,
        num_target_output: int = 1,
        hidden_size: int = 256,
        forecast_horizon: int = 48,
        out_activation_function: nn.Module | None = None,
    ) -> None:
        super().__init__(num_target_output, hidden_size, forecast_horizon)
        self.mu_layer = nn.Sequential(
            self._make_linear(),
            out_activation_function or nn.Identity(),
        )
        self.log_scale_layer = self._make_linear()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Predict mu and scale.

        Args:
            x: Latent tensor of shape (B, hidden_size).

        Returns:
            Tuple of (mu, scale), each of shape (B, forecast_horizon, num_target_output).
        """
        mu = self._reshape(self.mu_layer(x))
        scale = self._reshape(self.log_scale_layer(x)).exp()
        return mu, scale

    def get_distribution(self, mu: torch.Tensor, scale: torch.Tensor) -> torch.distributions.Laplace:  # type: ignore[override]
        return torch.distributions.Laplace(mu, scale)

    def get_log_likelihood(self, mu: torch.Tensor, scale: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        return -self.get_distribution(mu, scale).log_prob(targets).mean()


# ── Student-T ─────────────────────────────────────────────────────────────────


class StudentTDistribution(BaseDistribution):
    """Student-T output head.

    Best for: targets with very heavy tails and potential outliers -
    financial returns, spot electricity prices.

    Parameters predicted:
        mu  - location (unconstrained)
        sigma - scale (exp of log_scale, strictly positive)
        df  - degrees of freedom (softplus, clipped to ≥ 2 for finite variance)

    Note:
        Degrees of freedom are predicted per-sample but averaged across the
        forecast horizon so the model learns a single df per series.
    """

    def __init__(
        self,
        num_target_output: int = 1,
        hidden_size: int = 256,
        forecast_horizon: int = 48,
        out_activation_function: nn.Module | None = None,
        min_df: float = 2.1,
    ) -> None:
        super().__init__(num_target_output, hidden_size, forecast_horizon)
        self.min_df = min_df
        self.mu_layer = nn.Sequential(
            self._make_linear(),
            out_activation_function or nn.Identity(),
        )
        self.log_scale_layer = self._make_linear()
        # df predicted as a single scalar per output, broadcast over horizon
        self.df_layer = nn.Linear(hidden_size, num_target_output)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Predict mu, sigma, and degrees of freedom.

        Args:
            x: Latent tensor of shape (B, hidden_size).

        Returns:
            Tuple of (mu, sigma, df):
                - mu, sigma: shape (B, forecast_horizon, num_target_output)
                - df:        shape (B, 1, num_target_output), broadcast-compatible
        """
        mu = self._reshape(self.mu_layer(x))
        sigma = self._reshape(self.log_scale_layer(x)).mul(0.5).exp()
        # softplus ensures df > 0; clamp ensures finite variance (df > 2)
        df = F.softplus(self.df_layer(x)).unsqueeze(1).clamp(min=self.min_df)
        return mu, sigma, df

    def get_distribution(self, mu: torch.Tensor, sigma: torch.Tensor, df: torch.Tensor) -> torch.distributions.StudentT:  # type: ignore[override]
        return torch.distributions.StudentT(df=df, loc=mu, scale=sigma)

    def get_log_likelihood(  # type: ignore[override]
        self,
        mu: torch.Tensor,
        sigma: torch.Tensor,
        df: torch.Tensor,
        targets: torch.Tensor,
    ) -> torch.Tensor:
        return -self.get_distribution(mu, sigma, df).log_prob(targets).mean()


# ── Log-Normal ────────────────────────────────────────────────────────────────


class LogNormalDistribution(BaseDistribution):
    """Log-Normal output head.

    Best for: strictly positive, right-skewed targets - renewable generation,
    gas prices, load with zero floor.

    Parameters predicted:
        mu    - mean of log(target) (unconstrained)
        sigma - std of log(target) (exp of log_scale, strictly positive)

    Note:
        Targets must be strictly positive. Apply a small epsilon shift in the
        data pipeline if zeros are possible (e.g., target = max(y, 1e-6)).
    """

    def __init__(
        self,
        num_target_output: int = 1,
        hidden_size: int = 256,
        forecast_horizon: int = 48,
        out_activation_function: nn.Module | None = None,
    ) -> None:
        super().__init__(num_target_output, hidden_size, forecast_horizon)
        self.mu_layer = nn.Sequential(
            self._make_linear(),
            out_activation_function or nn.Identity(),
        )
        self.log_scale_layer = self._make_linear()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Predict mu and sigma of the underlying Normal (in log space).

        Args:
            x: Latent tensor of shape (B, hidden_size).

        Returns:
            Tuple of (mu, sigma), each of shape (B, forecast_horizon, num_target_output).
        """
        mu = self._reshape(self.mu_layer(x))
        sigma = self._reshape(self.log_scale_layer(x)).mul(0.5).exp()
        return mu, sigma

    def get_distribution(self, mu: torch.Tensor, sigma: torch.Tensor) -> torch.distributions.LogNormal:  # type: ignore[override]
        return torch.distributions.LogNormal(mu, sigma)

    def get_log_likelihood(self, mu: torch.Tensor, sigma: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        return -self.get_distribution(mu, sigma).log_prob(targets).mean()


# ── Additive Normal ────────────────────────────────────────────────────────────


class AdditiveNormalDistribution(BaseDistribution):
    """Normal output head preserving additive backbone structure.

    For use with :class:`~twiga.models.nn.net.mlpfgam.MLPGAMNetwork` and
    :class:`~twiga.models.nn.net.mlpfgaf.MLPGAFNetwork`, whose ``encode()``
    already returns the additive mean directly as a flat ``(B, H*O)`` vector.
    The mean is taken as-is (no projection) to honour the additive decomposition;
    only the scale is learned via a separate linear layer.

    Parameters predicted:
        mu    - additive mean (reshaped directly from latent, no projection)
        sigma - std dev (exp of log_scale, strictly positive)

    Args:
        num_target_output: Number of output features per time step.
        hidden_size: Must equal ``forecast_horizon * num_target_output``.
        forecast_horizon: Number of forecast time steps.
        out_activation_function: Optional activation applied to mu. Defaults to Identity.
    """

    def __init__(
        self,
        num_target_output: int = 1,
        hidden_size: int = 256,
        forecast_horizon: int = 48,
        out_activation_function: nn.Module | None = None,
    ) -> None:
        super().__init__(num_target_output, hidden_size, forecast_horizon)
        self.out_activation = out_activation_function or nn.Identity()
        self.log_scale_layer = self._make_linear()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Predict mu and sigma.

        Args:
            x: Latent tensor of shape (B, hidden_size) - the additive mean from the backbone.

        Returns:
            Tuple of (mu, sigma), each of shape (B, forecast_horizon, num_target_output).
        """
        mu = self.out_activation(self._reshape(x))
        sigma = self._reshape(self.log_scale_layer(x)).mul(0.5).exp()
        return mu, sigma

    def get_distribution(self, mu: torch.Tensor, sigma: torch.Tensor) -> torch.distributions.Normal:  # type: ignore[override]
        return torch.distributions.Normal(mu, sigma)

    def get_log_likelihood(self, mu: torch.Tensor, sigma: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        return -self.get_distribution(mu, sigma).log_prob(targets).mean()


# ── Additive Laplace ───────────────────────────────────────────────────────────


class AdditiveLaplaceDistribution(BaseDistribution):
    """Laplace output head preserving additive backbone structure.

    Analogous to :class:`AdditiveNormalDistribution` but with Laplace tails.
    Best for: heavy-tailed, outlier-robust targets - electricity prices, wind residuals.

    Parameters predicted:
        mu    - additive location (reshaped directly from latent, no projection)
        scale - scale (exp of log_scale, strictly positive)
    """

    def __init__(
        self,
        num_target_output: int = 1,
        hidden_size: int = 256,
        forecast_horizon: int = 48,
        out_activation_function: nn.Module | None = None,
    ) -> None:
        super().__init__(num_target_output, hidden_size, forecast_horizon)
        self.out_activation = out_activation_function or nn.Identity()
        self.log_scale_layer = self._make_linear()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Predict mu and scale.

        Args:
            x: Latent tensor of shape (B, hidden_size) - the additive location from the backbone.

        Returns:
            Tuple of (mu, scale), each of shape (B, forecast_horizon, num_target_output).
        """
        mu = self.out_activation(self._reshape(x))
        scale = self._reshape(self.log_scale_layer(x)).exp()
        return mu, scale

    def get_distribution(self, mu: torch.Tensor, scale: torch.Tensor) -> torch.distributions.Laplace:  # type: ignore[override]
        return torch.distributions.Laplace(mu, scale)

    def get_log_likelihood(self, mu: torch.Tensor, scale: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        return -self.get_distribution(mu, scale).log_prob(targets).mean()


# ── Additive Student-T ─────────────────────────────────────────────────────────


class AdditiveStudentTDistribution(BaseDistribution):
    """Student-T output head preserving additive backbone structure.

    Best for: very heavy tails - spot electricity prices, financial returns.

    Parameters predicted:
        mu    - additive location (reshaped directly from latent, no projection)
        sigma - scale (exp of log_scale, strictly positive)
        df    - degrees of freedom (softplus, clipped to ≥ min_df for finite variance)
    """

    def __init__(
        self,
        num_target_output: int = 1,
        hidden_size: int = 256,
        forecast_horizon: int = 48,
        out_activation_function: nn.Module | None = None,
        min_df: float = 2.1,
    ) -> None:
        super().__init__(num_target_output, hidden_size, forecast_horizon)
        self.min_df = min_df
        self.out_activation = out_activation_function or nn.Identity()
        self.log_scale_layer = self._make_linear()
        self.df_layer = nn.Linear(hidden_size, num_target_output)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Predict mu, sigma, and degrees of freedom.

        Args:
            x: Latent tensor of shape (B, hidden_size) - the additive location from the backbone.

        Returns:
            Tuple of (mu, sigma, df):
                - mu, sigma: shape (B, forecast_horizon, num_target_output)
                - df:        shape (B, 1, num_target_output), broadcast-compatible
        """
        mu = self.out_activation(self._reshape(x))
        sigma = self._reshape(self.log_scale_layer(x)).mul(0.5).exp()
        df = F.softplus(self.df_layer(x)).unsqueeze(1).clamp(min=self.min_df)
        return mu, sigma, df

    def get_distribution(self, mu: torch.Tensor, sigma: torch.Tensor, df: torch.Tensor) -> torch.distributions.StudentT:  # type: ignore[override]
        return torch.distributions.StudentT(df=df, loc=mu, scale=sigma)

    def get_log_likelihood(  # type: ignore[override]
        self,
        mu: torch.Tensor,
        sigma: torch.Tensor,
        df: torch.Tensor,
        targets: torch.Tensor,
    ) -> torch.Tensor:
        return -self.get_distribution(mu, sigma, df).log_prob(targets).mean()


# ── Additive Log-Normal ────────────────────────────────────────────────────────


class AdditiveLogNormalDistribution(BaseDistribution):
    """Log-Normal output head preserving additive backbone structure.

    Best for: strictly positive, right-skewed targets - renewable generation, gas prices.

    Parameters predicted:
        mu    - additive log-space mean (reshaped directly from latent, no projection)
        sigma - std of log(target) (exp of log_scale, strictly positive)

    Note:
        Targets must be strictly positive.
    """

    def __init__(
        self,
        num_target_output: int = 1,
        hidden_size: int = 256,
        forecast_horizon: int = 48,
        out_activation_function: nn.Module | None = None,
    ) -> None:
        super().__init__(num_target_output, hidden_size, forecast_horizon)
        self.out_activation = out_activation_function or nn.Identity()
        self.log_scale_layer = self._make_linear()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Predict mu and sigma of the underlying Normal (in log space).

        Args:
            x: Latent tensor of shape (B, hidden_size) - the additive log-mean from the backbone.

        Returns:
            Tuple of (mu, sigma), each of shape (B, forecast_horizon, num_target_output).
        """
        mu = self.out_activation(self._reshape(x))
        sigma = self._reshape(self.log_scale_layer(x)).mul(0.5).exp()
        return mu, sigma

    def get_distribution(self, mu: torch.Tensor, sigma: torch.Tensor) -> torch.distributions.LogNormal:  # type: ignore[override]
        return torch.distributions.LogNormal(mu, sigma)

    def get_log_likelihood(self, mu: torch.Tensor, sigma: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        return -self.get_distribution(mu, sigma).log_prob(targets).mean()


# ── Gamma ─────────────────────────────────────────────────────────────────────


class GammaDistribution(BaseDistribution):
    """Gamma output head.

    Best for: strictly positive targets with flexible skew - solar irradiance,
    wind power, load at aggregate level.

    Parameters predicted:
        concentration - shape parameter α (softplus, strictly positive)
        rate          - rate parameter β  (softplus, strictly positive)

    Note:
        Mean of Gamma(α, β) = α/β. Targets must be strictly positive.
    """

    def __init__(
        self,
        num_target_output: int = 1,
        hidden_size: int = 256,
        forecast_horizon: int = 48,
    ) -> None:
        super().__init__(num_target_output, hidden_size, forecast_horizon)
        self.concentration_layer = self._make_linear()
        self.rate_layer = self._make_linear()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Predict concentration and rate.

        Args:
            x: Latent tensor of shape (B, hidden_size).

        Returns:
            Tuple of (concentration, rate), each of shape (B, forecast_horizon, num_target_output).
        """
        concentration = F.softplus(self._reshape(self.concentration_layer(x)))
        rate = F.softplus(self._reshape(self.rate_layer(x)))
        return concentration, rate

    def get_distribution(self, concentration: torch.Tensor, rate: torch.Tensor) -> torch.distributions.Gamma:  # type: ignore[override]
        return torch.distributions.Gamma(concentration, rate)

    def get_log_likelihood(  # type: ignore[override]
        self,
        concentration: torch.Tensor,
        rate: torch.Tensor,
        targets: torch.Tensor,
    ) -> torch.Tensor:
        return -self.get_distribution(concentration, rate).log_prob(targets).mean()


# ── Beta ──────────────────────────────────────────────────────────────────────


class BetaDistribution(BaseDistribution):
    """Beta output head.

    Best for: bounded [0, 1] targets - capacity factors, state of charge,
    fill rates, normalised demand ratios.

    Parameters predicted:
        alpha - first shape parameter  (softplus, strictly positive)
        beta  - second shape parameter (softplus, strictly positive)

    Note:
        Targets must lie strictly in (0, 1). Apply a clamp in the data
        pipeline if boundary values are possible:
            target = target.clamp(1e-6, 1 - 1e-6)
    """

    def __init__(
        self,
        num_target_output: int = 1,
        hidden_size: int = 256,
        forecast_horizon: int = 48,
    ) -> None:
        super().__init__(num_target_output, hidden_size, forecast_horizon)
        self.alpha_layer = self._make_linear()
        self.beta_layer = self._make_linear()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Predict alpha and beta.

        Args:
            x: Latent tensor of shape (B, hidden_size).

        Returns:
            Tuple of (alpha, beta), each of shape (B, forecast_horizon, num_target_output).
        """
        alpha = F.softplus(self._reshape(self.alpha_layer(x)))
        beta = F.softplus(self._reshape(self.beta_layer(x)))
        return alpha, beta

    def get_distribution(self, alpha: torch.Tensor, beta: torch.Tensor) -> torch.distributions.Beta:  # type: ignore[override]
        return torch.distributions.Beta(alpha, beta)

    def get_log_likelihood(self, alpha: torch.Tensor, beta: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        return -self.get_distribution(alpha, beta).log_prob(targets).mean()


# ── Registry ──────────────────────────────────────────────────────────────────


DISTRIBUTIONS: dict[str, type[BaseDistribution]] = {
    "normal": NormalDistribution,
    "laplace": LaplaceDistribution,
    "student_t": StudentTDistribution,
    "log_normal": LogNormalDistribution,
    "gamma": GammaDistribution,
    "beta": BetaDistribution,
    "additive_normal": AdditiveNormalDistribution,
    "additive_laplace": AdditiveLaplaceDistribution,
    "additive_student_t": AdditiveStudentTDistribution,
    "additive_log_normal": AdditiveLogNormalDistribution,
}


def build_distribution(
    distribution: str,
    num_target_output: int,
    hidden_size: int,
    forecast_horizon: int,
    **kwargs,
) -> BaseDistribution:
    """Instantiate a distribution head by name.

    Args:
        distribution: One of 'normal', 'laplace', 'student_t', 'log_normal',
            'gamma', 'beta', 'additive_normal', 'additive_laplace',
            'additive_student_t', 'additive_log_normal'.
        num_target_output: Number of output features per time step.
        hidden_size: Dimensionality of the input latent vector.
        forecast_horizon: Number of forecast time steps.
        **kwargs: Additional keyword arguments forwarded to the distribution class
            (e.g., out_activation_function, min_df).

    Returns:
        Instantiated distribution head.

    Raises:
        ValueError: If distribution name is not recognised.

    Example:
        >>> head = build_distribution("student_t", num_target_output=1, hidden_size=256, forecast_horizon=24)
    """
    if distribution not in DISTRIBUTIONS:
        raise ValueError(f"Unknown distribution '{distribution}'. Choose from: {list(DISTRIBUTIONS.keys())}")
    return DISTRIBUTIONS[distribution](
        num_target_output=num_target_output,
        hidden_size=hidden_size,
        forecast_horizon=forecast_horizon,
        **kwargs,
    )
