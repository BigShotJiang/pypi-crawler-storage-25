from __future__ import annotations

from collections.abc import Callable
from typing import Any, cast

import numpy as np
import torch
from torch import nn

from twiga.distributions.nn.custom_loss import QuantileHuberLoss, QuantileLoss


def get_median_quantile(quantile_hats: torch.Tensor, probs: torch.Tensor | list) -> torch.Tensor:
    """Compute the median (0.5 quantile) from a quantile tensor of shape (B, N, T, C).

    Args:
        quantile_hats (torch.Tensor): Tensor of shape (B, N, T, C) containing quantile values.
        probs (torch.Tensor or list): Quantile probabilities (e.g., [0.1, 0.3, 0.5, 0.7, 0.9]).

    Returns:
        torch.Tensor: Median values of shape (B, T, C).

    Raises:
        ValueError: If input shapes are invalid or interpolation is not possible.
    """
    # Validate input
    if quantile_hats.dim() != 4:
        raise ValueError(f"Expected 4D tensor, got {quantile_hats.dim()}D")
    batch_size, num_quantiles, horizon, num_outputs = quantile_hats.shape
    if num_quantiles < 1:
        raise ValueError(f"Number of quantiles {num_quantiles} must be at least 1")

    # Convert probs to tensor if necessary
    probs = (
        torch.tensor(probs, dtype=torch.float, device=quantile_hats.device)
        if not isinstance(probs, torch.Tensor)
        else probs
    )
    if probs.shape != (num_quantiles,):
        raise ValueError(f"probs must have length {num_quantiles}, got {probs.shape}")

    # Sort probabilities and quantiles
    sorted_indices = torch.argsort(probs)
    probs = probs[sorted_indices]
    quantile_hats = quantile_hats[:, sorted_indices, :, :]

    # Check if 0.5 quantile exists
    median_idx = (probs == 0.5).nonzero(as_tuple=True)[0]
    if median_idx.numel() > 0:
        return quantile_hats[:, int(median_idx.item()), :, :].contiguous()  # Shape: (B, T, C)

    # Find the two quantiles bracketing 0.5
    lower_idx = (probs < 0.5).nonzero(as_tuple=True)[0]
    if lower_idx.numel() == 0 or lower_idx[-1] == num_quantiles - 1:
        raise ValueError("Cannot interpolate: 0.5 is outside the range of provided quantiles")

    lower_idx = int(lower_idx[-1].item())  # type: ignore[assignment]  # Last index where prob < 0.5
    upper_idx = lower_idx + 1  # First index where prob > 0.5

    # Get probabilities and quantile values
    p_lower = probs[lower_idx]
    p_upper = probs[upper_idx]
    q_lower = quantile_hats[:, lower_idx, :, :]  # Shape: (B, T, C)
    q_upper = quantile_hats[:, upper_idx, :, :]  # Shape: (B, T, C)

    # Linear interpolation: median = q_lower + (q_upper - q_lower) * (0.5 - p_lower) / (p_upper - p_lower)
    weight = (0.5 - p_lower) / (p_upper - p_lower)
    median = q_lower + (q_upper - q_lower) * weight

    return median.contiguous()


class QRDistribution(nn.Module):
    """QRNetwork is a neural network for forecasting quantiles using a quantile value network.

    Args:
        quantiles (list): List of quantiles to forecast. Default is None.
        num_outputs (int): Number of output features. Default is 1.
        latent_size (int): Size of the hidden layers. Default is 256.
        horizon (int): Number of time steps to forecast. Default is 48.
        out_activation_function (nn.Module): Activation function to use in the output layer. Default is nn.Identity().
    """

    def __init__(
        self,
        quantiles: list[float] | None = None,
        num_outputs: int = 1,
        hidden_size: int = 256,
        horizon: int = 48,
        eps: float = 1e-6,
        kappa: float = 0.5,
        output_activation: nn.Module | None = None,
        conf_level: float = 0.05,
        loss_fn: str = "pinball",
    ):
        super().__init__()

        if not 0 < conf_level < 1:
            raise ValueError("conf_level must be between 0 and 1")

        quantile_bounds = [conf_level / 2, 1 - conf_level / 2]
        if quantiles is None:
            quantiles = np.arange(0.1, 1, 0.1).round(1).tolist()

        quantiles.insert(0, quantile_bounds[0])
        quantiles.append(quantile_bounds[-1])

        self.num_outputs = num_outputs
        self.horizon = horizon

        self.output_activation = output_activation or nn.Identity()

        taus = torch.tensor(quantiles)
        self.register_buffer("taus", taus)
        self.loss_fn = loss_fn
        self.conf_level = conf_level

        self.quantile_value_layer = nn.Sequential(
            nn.Linear(hidden_size, horizon * num_outputs * len(quantiles)),
            self.output_activation,
        )
        if loss_fn == "pinball":
            self.quantile_loss = QuantileLoss(kappa=kappa, reduction="mean")
        elif loss_fn == "huber-pinball":
            self.quantile_loss = QuantileHuberLoss(kappa=kappa, reduction="mean")  # type: ignore[assignment]
        else:
            raise ValueError(f"Unknown loss function: {loss_fn}. Use 'pinball' or 'huber-pinball'.")

    def forward(self, x):
        """Forward pass of the quantile regression network with monotonicity enforcement.

        This implementation prevents quantile crossing by reparameterizing the output
        as a base quantile + strictly positive increments, then taking the cumulative sum.

        Mathematical formulation:

            Let τ = [τ₁ < τ₂ < … < τₖ] be the sorted quantile levels (e.g. [0.1, 0.2, …, 0.9])

            Let z ∈ ℝ^{B × (k) × H × D} be the raw output of the final linear layer
            (where k = len(taus), H = forecast horizon, D = number of output variables / targets)

            We split the output into:
                q₁ = z[:, 0,   :, :]           # lowest quantile (base)
                δᵢ = softplus(z[:, i, :, :])   for i = 1, …, k-1

            Then the monotonic quantiles are constructed as:

                Q̂(τ₁) = q₁
                Q̂(τ₂) = q₁ + δ₁
                Q̂(τ₃) = q₁ + δ₁ + δ₂
                ...
                Q̂(τₖ) = q₁ + δ₁ + δ₂ + … + δ_{k-1}

            Which is equivalent to:

                Q̂(τⱼ) = q₁ + ∑_{i=1}^{j-1} δᵢ     for j = 1, …, k   (with empty sum = 0)

            Because δᵢ = softplus(…) > 0 ∀ i, we have:

                Q̂(τ₁) < Q̂(τ₂) < … < Q̂(τₖ)     (strictly increasing)

        This guarantees non-crossing quantiles **by construction**, independent of the training loss.

        Args:
            x (torch.Tensor): Input features
                Shape: (B, N, C)   - batch, time/context length, features

        Returns:
            torch.Tensor: Estimated quantile values Q(τⱼ | x)
                Shape: (B, K, H, D) where K = len(self.taus)
                and values are guaranteed to be strictly increasing along dim=1
        """
        raw_output = self.quantile_value_layer(x)
        raw_output = raw_output.view(x.size(0), len(self.taus), self.horizon, self.num_outputs)

        # Base = prediction for the lowest quantile
        base_quantile = raw_output[:, :1, :, :]  # (B, 1, H, D)

        # Increments for moving to the next higher quantiles
        increments = raw_output[:, 1:, :, :]  # (B, K-1, H, D)

        # Guarantee strictly positive steps
        positive_increments = nn.functional.softplus(increments)  # (B, K-1, H, D)

        # Build monotonic sequence: base + cumsum(positive increments)
        monotonic_quantiles = torch.cat([base_quantile, positive_increments], dim=1)
        quantile_values = torch.cumsum(monotonic_quantiles, dim=1)  # (B, K, H, D)

        return quantile_values

    def forecast(self, input_tensor: torch.Tensor) -> dict:
        """Forecast quantiles for the given input tensor.

        Args:
            input_tensor: Input tensor of shape (batch_size, z_dim).

        Returns:
            torch.Tensor: Forecasted quantiles of shape
                (batch_size, n_quantiles, horizon, num_outputs).
        """
        # Apply quantile proposal layer
        with torch.no_grad():
            _taus = cast("torch.Tensor", self.taus)
            quantile_values = self(input_tensor)
            loc = get_median_quantile(quantile_values, _taus)

            return {
                "loc": loc,
                "quantiles": quantile_values,
                "conf_level": self.conf_level,
                "quantile_levels": _taus.cpu().numpy(),
            }

    def step(
        self,
        z: torch.Tensor,
        y: torch.Tensor,
        metric_fn: Callable[..., Any],
        epoch: int | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Perform a single training/validation step.

        Args:
            z: Latent tensor of shape ``(B, hidden_size)`` from the backbone.
            y: Target tensor of shape ``(B, forecast_horizon, num_outputs)``.
            metric_fn: Callable returning a scalar metric given ``(pred, target)``.
            epoch: Current epoch (unused; accepted for interface consistency).

        Returns:
            Tuple of ``(quantile_loss, metric)``.
        """
        _taus = cast("torch.Tensor", self.taus)
        quantile_values = self(z)
        y_pred = get_median_quantile(quantile_values, _taus)

        y_quantiles = y.unsqueeze(1).expand_as(quantile_values)

        taus = _taus.view(1, len(_taus), 1, 1).expand_as(quantile_values)
        if self.loss_fn == "pinball":
            loss = self.quantile_loss(quantile_values, taus, y_quantiles)
        elif self.loss_fn == "huber-pinball":
            loss = self.quantile_loss(inputs=quantile_values, quantiles=taus, targets=y_quantiles)
        metric = metric_fn(y_pred, y)
        return loss, metric
