import torch
from torch import nn
import torch.nn.functional as F


def loss_reduction(loss: torch.Tensor, reduction: str) -> torch.Tensor:
    """Apply the specified reduction method to the given loss tensor.

    Args:
        loss: The computed loss tensor.
        reduction: Specifies the reduction to apply: 'none', 'mean', or 'sum'.

    Returns:
        The reduced loss tensor. If 'none', returns the original tensor; if 'mean' or 'sum', returns a scalar.

    Raises:
        ValueError: If reduction is not one of 'none', 'mean', or 'sum'.
    """
    if reduction == "mean":
        return loss.mean()
    if reduction == "sum":
        return loss.sum()
    if reduction == "none":
        return loss
    raise ValueError(f"Invalid reduction type: {reduction}. Must be 'none', 'mean', or 'sum'.")


def interval_loss(
    boundaries: torch.Tensor,
    targets: torch.Tensor,
    width_penalty: float = 1.0,
    coverage_penalty: float = 1.0,
    reduction: str = "mean",
) -> torch.Tensor:
    """Compute a general-purpose loss for interval-based approaches, penalizing wide intervals and ensuring coverage.

    Args:
        boundaries: Predicted interval boundaries of shape (N, Q, T, C), where N is batch size,
                    Q is the number of boundaries (Q >= 2), T is number of targets, and C is number of features.
                    Boundaries are assumed to be sorted in ascending order (e.g., lower to upper quantiles).
        targets: True values of shape (N, T, C).
        width_penalty: Scaling factor for the interval width penalty (default: 1.0).
        coverage_penalty: Scaling factor for the coverage penalty (default: 1.0).
        reduction: Specifies the reduction to apply: 'none', 'mean', or 'sum' (default: 'mean').

    Returns:
        The computed loss tensor, reduced according to the specified method.

    Raises:
        ValueError: If boundaries do not have at least 2 dimensions, Q < 2, or shapes are incompatible.
    """
    if boundaries.ndim < 2 or boundaries.shape[1] < 2:
        raise ValueError(f"Boundaries must have at least 2 dimensions and Q >= 2, got shape {boundaries.shape}")
    if targets.ndim < 2:
        raise ValueError(f"Targets must have at least 2 dimensions, got shape {targets.shape}")
    if boundaries.shape[0] != targets.shape[0] or boundaries.shape[2:] != targets.shape[1:]:
        raise ValueError(f"Shapes incompatible: boundaries={boundaries.shape}, targets={targets.shape}")

    # 1. Width penalty: Penalize the sum of differences between consecutive boundaries
    interval_widths = boundaries[:, 1:, :, :] - boundaries[:, :-1, :, :]  # Shape: (N, Q-1, T, C)
    width_loss = width_penalty * torch.abs(interval_widths).sum(dim=1)  # Sum over Q-1 intervals

    # 2. Coverage penalty: Penalize when true values fall outside the outermost boundaries
    lower_bound = boundaries[:, 0, :, :]  # Lowest boundary (e.g., smallest quantile)
    upper_bound = boundaries[:, -1, :, :]  # Highest boundary (e.g., largest quantile)
    outside_lower = F.relu(lower_bound - targets)  # Positive when target < lower_bound
    outside_upper = F.relu(targets - upper_bound)  # Positive when target > upper_bound
    coverage_loss = coverage_penalty * (outside_lower + outside_upper)

    # Combine losses
    loss = width_loss + coverage_loss

    return loss_reduction(loss, reduction)


def pin_ball_loss(
    inputs: torch.Tensor,
    targets: torch.Tensor,
    quantiles: torch.Tensor,
    kappa: float = 0.0,
    reduction: str = "none",
) -> torch.Tensor:
    """Compute the pinball loss for quantile regression.

    The pinball loss measures the accuracy of predicted quantiles, penalizing overestimation and
    underestimation asymmetrically based on the quantile level.

    Args:
        inputs: Predicted values of shape (N, Q, T, C), where N is batch size, Q is number of quantiles,
            T is number of targets, and C is number of features.
        targets: True target values of shape (N, Q, T, C).
        quantiles: Quantile levels of shape (Q,).
        kappa: Smoothing parameter for softplus approximation (default: 0.0, uses max).
        reduction: Specifies the reduction to apply: 'none', 'mean', or 'sum' (default: 'none').

    Returns:
        The computed pinball loss tensor, reduced according to the specified method.

    Raises:
        ValueError: If shapes of inputs and targets do not match, or if quantiles shape is incompatible.
    """
    if targets.shape != inputs.shape:
        raise ValueError(f"Targets shape {targets.shape} must match inputs shape {inputs.shape}")

    error = targets - inputs
    if kappa > 0:
        loss = (quantiles * error + kappa * F.softplus(-error / kappa)).sum(dim=1)
    else:
        loss = torch.max(quantiles * error, (quantiles - 1) * error).sum(dim=1)

    return loss_reduction(loss, reduction)


def quantile_huber_loss(
    inputs: torch.Tensor,
    targets: torch.Tensor,
    quantiles: torch.Tensor,
    kappa: float = 0.25,
    eps: float = 1e-8,
    reduction: str = "none",
) -> torch.Tensor:
    """Compute the quantile Huber loss for robust quantile regression.

    The Huber loss combines L1 and L2 losses, switching at kappa, and is adjusted for quantiles:
    - For |error| <= kappa: 0.5 * error^2
    - For |error| > kappa: kappa * (|error| - 0.5 * kappa)

    Args:
        inputs: Predicted values of shape (N, Q, T, C), where N is batch size, Q is number of quantiles,
            T is number of targets, and C is number of features.
        targets: True target values of shape (N, Q, T, C).
        quantiles: Quantile levels of shape (Q,).
        kappa: Threshold for switching between L2 and L1 loss (default: 0.25).
        eps: Small value to prevent division by zero (default: 1e-8).
        reduction: Specifies the reduction to apply: 'none', 'mean', or 'sum' (default: 'none').

    Returns:
        The computed quantile Huber loss tensor, reduced according to the specified method.

    Raises:
        ValueError: If shapes of inputs and targets do not match, or if quantiles shape is incompatible.
    """
    if targets.shape != inputs.shape:
        raise ValueError(f"Targets shape {targets.shape} must match inputs shape {inputs.shape}")
    # if inputs.shape[1] != quantiles.shape[0]:
    #    raise ValueError(f"Number of quantiles in inputs {inputs.shape[1]} must match quantiles {quantiles.shape[0]}")

    errors = targets - inputs
    huber_loss = torch.where(
        errors.abs() <= kappa,
        0.5 * errors.pow(2),
        kappa * (errors.abs() - 0.5 * kappa),
    )
    quantile_mask = torch.abs(quantiles - (errors.detach() < 0).float())
    loss = (quantile_mask * (huber_loss / (kappa + eps))).sum(dim=1)

    return loss_reduction(loss, reduction)


def quantile_proposal_loss(
    quantile: torch.Tensor,
    quantile_hats: torch.Tensor,
    taus: torch.Tensor,
    reduction: str = "none",
) -> torch.Tensor:
    """Compute the quantile proposal loss to ensure non-crossing quantiles.

    This loss ensures predicted quantiles adhere to specified levels and do not cross each other.

    Args:
        quantile: True quantile values of shape (N, Q, T, C).
        quantile_hats: Predicted quantile values of shape (N, Q, T, C).
        taus: Quantile levels of shape (N, Q, T).
        reduction: Specifies the reduction to apply: 'none', 'mean', or 'sum' (default: 'none').

    Returns:
        The computed quantile proposal loss tensor, reduced according to the specified method.

    Raises:
        ValueError: If shapes are incompatible or if inputs require gradients when they shouldn't.
    """
    if taus.requires_grad:
        raise ValueError("Quantile levels (taus) should not require gradients")
    if quantile_hats.requires_grad:
        raise ValueError("Predicted quantile values (quantile_hats) should not require gradients")
    if quantile.requires_grad:
        raise ValueError("True quantile values (quantile) should not require gradients")

    gradients1 = quantile - quantile_hats[:, :-1, :]  # Shape: (batch_size, num_quantiles-1, num_actions)
    gradients2 = quantile - quantile_hats[:, 1:, :]  # Shape: (batch_size, num_quantiles-1, num_actions)
    flag_1 = quantile > torch.cat([quantile_hats[:, :1, :], quantile[:, :-1, :]], dim=1)
    flag_2 = quantile < torch.cat([quantile[:, 1:, :], quantile_hats[:, -1:, :]], dim=1)
    gradients = (torch.where(flag_1, gradients1, -gradients1) + torch.where(flag_2, gradients2, -gradients2)).view(
        gradients1.shape,
    )
    loss = torch.mul(gradients.detach(), taus[:, 1:-1, :].unsqueeze(-1)).sum(dim=1)

    return loss_reduction(loss, reduction)


class QuantileLoss(nn.Module):
    """Quantile loss module for quantile regression.

    Computes the pinball loss between predicted quantiles and target values.

    Attributes:
        kappa: Smoothing parameter for softplus approximation.
        reduction: Reduction method: 'none', 'mean', or 'sum'.

    Args:
        kappa: Smoothing parameter for softplus approximation (default: 0.0).
        reduction: Reduction method: 'none', 'mean', or 'sum' (default: 'mean').
    """

    def __init__(self, kappa: float = 0.0, reduction: str = "mean") -> None:
        """Initialize the QuantileLoss module.

        Args:
            kappa: Smoothing parameter for softplus approximation (default: 0.0).
            reduction: Reduction method: 'none', 'mean', or 'sum' (default: 'mean').

        Raises:
            ValueError: If kappa < 0 or reduction is invalid.
        """
        super().__init__()
        if kappa < 0:
            raise ValueError("kappa must be non-negative")
        self.kappa = kappa
        self.reduction = reduction

    def forward(self, inputs: torch.Tensor, quantiles: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """Compute the quantile loss.

        Args:
            inputs: Predicted quantiles of shape (B, N) where B is batch size and N is number of quantiles.
            quantiles: Quantile levels of shape (N,).
            targets: Ground truth targets of shape (B, 1) or (B, N).

        Returns:
            The computed quantile loss tensor, reduced according to the specified method.
        """
        return pin_ball_loss(inputs, targets, quantiles, kappa=self.kappa, reduction=self.reduction)


class QuantileHuberLoss(nn.Module):
    """Quantile Huber loss module for robust quantile regression.

    Computes the Huber loss adjusted for quantiles, less sensitive to outliers than L2 loss.

    Attributes:
        kappa: Threshold for switching between L2 and L1 loss.
        eps: Small value to prevent division by zero.
        reduction: Reduction method: 'none', 'mean', or 'sum'.

    Args:
        kappa: Threshold for switching between L2 and L1 loss (default: 1.0).
        eps: Small value to prevent division by zero (default: 1e-8).
        reduction: Reduction method: 'none', 'mean', or 'sum' (default: 'mean').
    """

    def __init__(self, kappa: float = 1.0, eps: float = 1e-8, reduction: str = "mean") -> None:
        """Initialize the QuantileHuberLoss module.

        Args:
            kappa: Threshold for switching between L2 and L1 loss (default: 1.0).
            eps: Small value to prevent division by zero (default: 1e-8).
            reduction: Reduction method: 'none', 'mean', or 'sum' (default: 'mean').

        Raises:
            ValueError: If kappa <= 0 or eps <= 0.
        """
        super().__init__()
        if kappa <= 0:
            raise ValueError("kappa must be positive")
        if eps <= 0:
            raise ValueError("eps must be positive")
        self.kappa = kappa
        self.eps = eps
        self.reduction = reduction

    def forward(self, inputs: torch.Tensor, quantiles: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """Compute the quantile Huber loss.

        Args:
            inputs: Predicted values of shape (N, Q, T, C).
            quantiles: Quantile levels of shape (Q,).
            targets: True target values of shape (N, Q, T, C).

        Returns:
            The computed quantile Huber loss tensor, reduced according to the specified method.
        """
        return quantile_huber_loss(
            inputs,
            targets,
            quantiles,
            kappa=self.kappa,
            eps=self.eps,
            reduction=self.reduction,
        )


class QuantileProposalLoss(nn.Module):
    """Quantile proposal loss module to ensure non-crossing quantiles.

    Computes a loss to enforce that predicted quantiles adhere to specified levels and do not cross.

    Attributes:
        reduction: Reduction method: 'none', 'mean', or 'sum'.

    Args:
        reduction: Reduction method: 'none', 'mean', or 'sum' (default: 'none').
    """

    def __init__(self, reduction: str = "none") -> None:
        """Initialize the QuantileProposalLoss module.

        Args:
            reduction: Reduction method: 'none', 'mean', or 'sum' (default: 'none').
        """
        super().__init__()
        self.reduction = reduction

    def forward(self, quantile: torch.Tensor, quantile_hats: torch.Tensor, taus: torch.Tensor) -> torch.Tensor:
        """Compute the quantile proposal loss.

        Args:
            quantile: True quantile values of shape (N, Q, T, C).
            quantile_hats: Predicted quantile values of shape (N, Q, T, C).
            taus: Quantile levels of shape (N, Q, T).

        Returns:
            The computed quantile proposal loss tensor, reduced according to the specified method.
        """
        return quantile_proposal_loss(quantile, quantile_hats, taus, reduction=self.reduction)
