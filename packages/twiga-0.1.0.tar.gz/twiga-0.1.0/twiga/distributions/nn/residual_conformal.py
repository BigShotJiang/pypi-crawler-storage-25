"""Conditional Residual Calibration (CRC) distribution heads.

Two variants are provided:

    CRCDistribution           - for standard backbones (e.g. MLPFNetwork) whose
                                latent size differs from H*O.  The mean is computed
                                via a learned linear projection from the latent.

    AdditiveCRCDistribution   - for additive backbones (e.g. MLPGAMNetwork,
                                MLPGAFNetwork) whose encode() already returns the
                                additive mean directly as a flat (B, H*O) vector.
                                The mean is taken as-is (no projection) to honour
                                the additive decomposition.

Both share the same uncertainty head: a two-layer MLP conditioned on the
detached mean prediction that outputs a per-step scale estimate σ.  The
calibration objective for σ is selected via ``sigma_loss_fn``:

    ``"gaussian"`` - heteroscedastic Gaussian NLL::

        L_σ = 0.5 · (r² / σ² + log σ²)      r = |y − μ|

    ``"laplace"``  - Laplace NLL (robust to heavy tails)::

        L_σ = |r| / σ + log(2σ)

    ``"mse"``      - distribution-free MSE on residual magnitude::

        L_σ = (σ − |r|)²

    ``"hybrid"``   - (default) convex combination of MSE and L1::

        L_σ = α · MSE(σ, |r|) + (1 − α) · L1(σ, |r|)

The mean is trained jointly via MAE.  ``get_distribution`` returns a
Normal(μ, σ) for downstream interval construction.
"""

from __future__ import annotations

from collections.abc import Callable

import torch
from torch import nn
import torch.nn.functional as F

from twiga.distributions.nn.parametric import BaseDistribution
from twiga.models.nn.core.linear import create_linear_layer as create_linear

_SIGMA_LOSS_FNS = {"gaussian", "laplace", "mse", "hybrid"}


def _sigma_calibration_loss(
    sigma: torch.Tensor,
    residual: torch.Tensor,
    loss_fn: str,
    alpha: float,
) -> torch.Tensor:
    """Compute the uncertainty-calibration loss for a CRC head.

    Args:
        sigma:    Predicted scale, shape ``(B, H, O)``, strictly positive.
        residual: Absolute residual ``|y − μ|``, same shape as ``sigma``.
        loss_fn:  One of ``"gaussian"``, ``"laplace"``, ``"mse"``, ``"hybrid"``.
        alpha:    MSE weight used only by the ``"hybrid"`` mode.

    Returns:
        Scalar loss tensor.
    """
    s = sigma.clamp(min=1e-6)
    if loss_fn == "gaussian":
        return (0.5 * (residual**2 / s**2 + torch.log(s**2))).mean()
    if loss_fn == "laplace":
        return (residual / s + torch.log(2.0 * s)).mean()
    if loss_fn == "mse":
        return F.mse_loss(sigma, residual)
    # hybrid (default)
    return alpha * F.mse_loss(sigma, residual) + (1.0 - alpha) * F.l1_loss(sigma, residual)


# ── CRC for standard backbones ─────────────────────────────────────────────────


class CRCDistribution(BaseDistribution):
    """CRC head for standard (non-additive) backbones such as MLPFNetwork.

    The mean is computed by projecting the latent vector ``z`` (shape
    ``(B, hidden_size)``) through a linear layer to ``(B, H*O)``.  The scale
    is then predicted by a two-layer MLP conditioned on the detached mean.

    Args:
        num_target_output: Number of output features per time step.
        hidden_size: Dimensionality of the backbone latent vector.
        forecast_horizon: Number of forecast time steps.
        out_activation_function: Optional activation applied to the mean output.
        sigma_loss_fn: Calibration objective for σ - one of ``"gaussian"``,
            ``"laplace"``, ``"mse"``, or ``"hybrid"`` (default).
        alpha: MSE weight used only when ``sigma_loss_fn="hybrid"``.
        activation: Hidden-layer activation name for the sigma MLP.
    """

    def __init__(
        self,
        num_target_output: int = 1,
        hidden_size: int = 256,
        forecast_horizon: int = 48,
        out_activation_function: nn.Module | None = None,
        sigma_loss_fn: str = "hybrid",
        alpha: float = 0.1,
        activation: str = "ReLU",
    ) -> None:
        if sigma_loss_fn not in _SIGMA_LOSS_FNS:
            raise ValueError(f"sigma_loss_fn must be one of {_SIGMA_LOSS_FNS}, got '{sigma_loss_fn}'")
        super().__init__(num_target_output, hidden_size, forecast_horizon)
        self.sigma_loss_fn = sigma_loss_fn
        self.alpha = alpha
        self.mu_layer = nn.Sequential(
            self._make_linear(),
            out_activation_function or nn.Identity(),
        )
        ho = forecast_horizon * num_target_output
        self.sigma_net = nn.Sequential(
            create_linear(ho, hidden_size, activation=activation),
            nn.Linear(hidden_size, ho),
        )

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Predict mean and scale.

        Args:
            x: Latent tensor of shape ``(B, hidden_size)``.

        Returns:
            Tuple of ``(mu, sigma)``, each of shape
            ``(B, forecast_horizon, num_target_output)``.
        """
        mu = self._reshape(self.mu_layer(x))
        ho = self.forecast_horizon * self.num_target_output
        sigma_input = mu.detach().reshape(mu.size(0), ho)
        sigma = F.softplus(self.sigma_net(sigma_input))
        sigma = sigma.view(mu.size(0), self.forecast_horizon, self.num_target_output)
        return mu, sigma

    def get_distribution(self, mu: torch.Tensor, sigma: torch.Tensor) -> torch.distributions.Normal:  # type: ignore[override]
        return torch.distributions.Normal(mu, sigma.clamp(min=1e-6))

    def get_log_likelihood(self, mu: torch.Tensor, sigma: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        """CRC loss: MAE on mean + selected calibration loss on scale."""
        residual = (targets - mu.detach()).abs()
        sigma_loss = _sigma_calibration_loss(sigma, residual, self.sigma_loss_fn, self.alpha)
        point_loss = F.l1_loss(mu, targets)
        return point_loss + sigma_loss

    def step(
        self,
        z: torch.Tensor,
        y: torch.Tensor,
        metric_fn: Callable[..., torch.Tensor],
        epoch: int | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Compute CRC loss and metric for one training step.

        The mean trains via MAE; sigma trains via the selected calibration
        objective (gaussian / laplace / mse / hybrid).
        """
        mu, sigma = self(z)
        loss = self.get_log_likelihood(mu, sigma, y)
        metric = metric_fn(mu, y)
        return loss, metric

    def forecast(self, z: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Inference-mode prediction (no gradient).

        Returns:
            Tuple of ``(mu, sigma)``.
        """
        with torch.no_grad():
            return self(z)


# ── CRC for additive backbones ─────────────────────────────────────────────────


class AdditiveCRCDistribution(BaseDistribution):
    """CRC head for additive backbones (MLPGAMNetwork, MLPGAFNetwork).

    The backbone's ``encode()`` already returns the additive mean as a flat
    ``(B, H*O)`` vector - no further projection is applied to preserve the
    additive decomposition.  Only the scale MLP is learned.

    Args:
        num_target_output: Number of output features per time step.
        hidden_size: Must equal ``forecast_horizon * num_target_output``
            (the additive backbone's encode_size).
        forecast_horizon: Number of forecast time steps.
        out_activation_function: Optional activation applied to the mean.
        sigma_loss_fn: Calibration objective for σ - one of ``"gaussian"``,
            ``"laplace"``, ``"mse"``, or ``"hybrid"`` (default).
        alpha: MSE weight used only when ``sigma_loss_fn="hybrid"``.
        activation: Hidden-layer activation name for the sigma MLP.
    """

    def __init__(
        self,
        num_target_output: int = 1,
        hidden_size: int = 256,
        forecast_horizon: int = 48,
        out_activation_function: nn.Module | None = None,
        sigma_loss_fn: str = "hybrid",
        alpha: float = 0.1,
        activation: str = "ReLU",
    ) -> None:
        if sigma_loss_fn not in _SIGMA_LOSS_FNS:
            raise ValueError(f"sigma_loss_fn must be one of {_SIGMA_LOSS_FNS}, got '{sigma_loss_fn}'")
        super().__init__(num_target_output, hidden_size, forecast_horizon)
        self.sigma_loss_fn = sigma_loss_fn
        self.alpha = alpha
        self.out_activation = out_activation_function or nn.Identity()
        # sigma MLP conditioned on flattened mu; hidden width matches encode_size
        ho = forecast_horizon * num_target_output
        self.sigma_net = nn.Sequential(
            create_linear(ho, hidden_size, activation=activation),
            nn.Linear(hidden_size, ho),
        )

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Predict mean and scale.

        Args:
            x: Latent tensor of shape ``(B, hidden_size)`` - the additive mean.

        Returns:
            Tuple of ``(mu, sigma)``, each of shape
            ``(B, forecast_horizon, num_target_output)``.
        """
        mu = self.out_activation(self._reshape(x))
        ho = self.forecast_horizon * self.num_target_output
        sigma_input = mu.detach().reshape(mu.size(0), ho)
        sigma = F.softplus(self.sigma_net(sigma_input))
        sigma = sigma.view(mu.size(0), self.forecast_horizon, self.num_target_output)
        return mu, sigma

    def get_distribution(self, mu: torch.Tensor, sigma: torch.Tensor) -> torch.distributions.Normal:  # type: ignore[override]
        return torch.distributions.Normal(mu, sigma.clamp(min=1e-6))

    def get_log_likelihood(self, mu: torch.Tensor, sigma: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        """CRC loss: MAE on mean + selected calibration loss on scale."""
        residual = (targets - mu.detach()).abs()
        sigma_loss = _sigma_calibration_loss(sigma, residual, self.sigma_loss_fn, self.alpha)
        point_loss = F.l1_loss(mu, targets)
        return point_loss + sigma_loss

    def step(
        self,
        z: torch.Tensor,
        y: torch.Tensor,
        metric_fn: Callable[..., torch.Tensor],
        epoch: int | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Compute CRC loss and metric for one training step."""
        mu, sigma = self(z)
        loss = self.get_log_likelihood(mu, sigma, y)
        metric = metric_fn(mu, y)
        return loss, metric

    def forecast(self, z: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Inference-mode prediction (no gradient).

        Returns:
            Tuple of ``(mu, sigma)``.
        """
        with torch.no_grad():
            return self(z)
