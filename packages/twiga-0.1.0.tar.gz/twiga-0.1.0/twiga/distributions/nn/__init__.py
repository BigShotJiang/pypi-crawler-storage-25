"""Probabilistic output heads for neural forecasting models.

Safe exports: parametric distributions, QR, and losses.

Modules NOT exported here due to cross-package dependencies on twiga.models.nn:
  - fpquantile (FPQRDistribution) - depends on models.nn.core.embedding
  - residual_conformal (CRCDistribution) - depends on models.nn.core.linear

Import those directly, e.g.:
  from twiga.distributions.nn.residual_conformal import CRCDistribution
  from twiga.distributions.nn.fpquantile import FPQRDistribution
"""

from twiga.distributions.nn.custom_loss import QuantileHuberLoss, QuantileLoss, QuantileProposalLoss
from twiga.distributions.nn.parametric import (
    DISTRIBUTIONS,
    AdditiveLaplaceDistribution,
    AdditiveLogNormalDistribution,
    AdditiveNormalDistribution,
    AdditiveStudentTDistribution,
    BaseDistribution,
    BetaDistribution,
    GammaDistribution,
    LaplaceDistribution,
    LogNormalDistribution,
    NormalDistribution,
    StudentTDistribution,
    build_distribution,
)
from twiga.distributions.nn.quantile import QRDistribution

__all__ = [
    # Base
    "BaseDistribution",
    "DISTRIBUTIONS",
    "build_distribution",
    # Parametric
    "NormalDistribution",
    "LaplaceDistribution",
    "StudentTDistribution",
    "LogNormalDistribution",
    "GammaDistribution",
    "BetaDistribution",
    # Additive parametric (for GAM/GAF backbones)
    "AdditiveNormalDistribution",
    "AdditiveLaplaceDistribution",
    "AdditiveStudentTDistribution",
    "AdditiveLogNormalDistribution",
    # Quantile
    "QRDistribution",
    # Losses
    "QuantileLoss",
    "QuantileHuberLoss",
    "QuantileProposalLoss",
]
