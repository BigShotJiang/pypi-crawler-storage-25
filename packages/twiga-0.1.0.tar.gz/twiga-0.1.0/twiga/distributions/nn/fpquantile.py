from __future__ import annotations

from collections.abc import Callable
from typing import Any, cast

import torch
from torch import nn
import torch.nn.functional as F

from twiga.models.nn.core.embedding import DataEmbedding, TimeEmbedding

from .custom_loss import QuantileHuberLoss, QuantileLoss, QuantileProposalLoss


class CosinetauEmbedding(nn.Module):
    """A PyTorch module for embedding time values using cosine transformations.

    This module transforms time values into cosine-based features and embeds them
    into a higher-dimensional space using a linear layer and activation function.

    Args:
        num_cosines (int, optional): Number of cosine functions. Defaults to 32.
        z_dim (int, optional): Output embedding dimension. Defaults to 128.
        num_outputs (int, optional): Scaling factor for input size. Defaults to 48.
        activation (nn.Module, optional): Activation function.
            Defaults to nn.LeakyReLU().
    """

    def __init__(
        self,
        num_cosines: int = 32,
        z_dim: int = 128,
        num_outputs: int = 48,
    ):
        super().__init__()
        self.net = TimeEmbedding(num_cosines * num_outputs, z_dim)
        self.num_cosines = num_cosines
        self.z_dim = z_dim
        self.m_factor = num_outputs

    def forward(self, taus: torch.Tensor) -> torch.Tensor:
        """Transforms time values into cosine-based embeddings.

        Args:
            taus: Input tensor of shape (batch_size, num_outputs, num_inputs).

        Returns:
            Tensor of shape (batch_size, num_outputs, z_dim) containing
            embedded time values.
        """
        # Calculate i * pi (i=1,...,num_cosines)
        i_pi = torch.pi * torch.arange(
            start=1,
            end=self.num_cosines + 1,
            dtype=taus.dtype,
            device=taus.device,
        ).view(1, 1, 1, self.num_cosines)

        # Calculate cos(i * pi * tau)
        cosines = torch.cos(taus.unsqueeze(-1) * i_pi)

        # Flatten to (batch_size, num_quantile, num_inputs * num_cosines)
        # Embed using the network
        tau_z = self.net(cosines.flatten(2, 3))
        return tau_z


class QuantileProposal(nn.Module):
    """A neural network module for proposing confidence quantiles.

    This module generates quantile estimates from input features using a linear layer, dropout, and softmax
    normalization. It computes cumulative probabilities (taus), midpoints (tau_hats), and entropies, ensuring
    quantiles stay within specified bounds based on a significance level (conf_level).

    Attributes:
        n_quantiles: Number of quantiles to propose.
        z_dim: Dimensionality of the input features.
        conf_level: Significance level tensor for quantile bounds.
        net: Linear layer transforming input features to quantile logits.
        dropout: Dropout layer for regularization.
        tau_0: Initial tau value buffer (zeros).

    Args:
        n_quantiles: Number of quantiles to propose (default: 10).
        z_dim: Dimensionality of the input features (default: 64).
        dropout: Dropout rate for regularization (default: 0.1).
        conf_level: Significance level for quantile estimation (default: 0.05).
    """

    def __init__(
        self,
        n_quantiles: int = 10,
        z_dim: int = 64,
        dropout: float = 0.1,
        conf_level: float = 0.05,
        n_outputs: int = 1,
    ) -> None:
        """Initialize the QuantileProposal module.

        Args:
            n_quantiles: Number of quantiles to propose (default: 10).
            z_dim: Dimensionality of the input features (default: 64).
            dropout: Dropout rate for regularization (default: 0.1).
            conf_level: Significance level for quantile estimation (default: 0.05).
            n_outputs: num of output dimension.

        Raises:
            ValueError: If n_quantiles <= 0, z_dim <= 0, dropout < 0, or conf_level not in (0, 1).
        """
        super().__init__()

        if n_quantiles <= 0:
            raise ValueError("n_quantiles must be positive.")
        if n_outputs <= 0:
            raise ValueError("n_outputs must be positive.")
        if z_dim <= 0:
            raise ValueError("z_dim must be positive.")
        if dropout < 0:
            raise ValueError("dropout must be non-negative.")
        if not 0 < conf_level < 1:
            raise ValueError("conf_level must be between 0 and 1.")

        self.n_quantiles = n_quantiles
        self.n_outputs = n_outputs
        self.z_dim = z_dim
        self.net = nn.Linear(z_dim, n_quantiles * n_outputs)
        self.dropout = nn.Dropout(dropout)
        self.register_buffer("conf_level", torch.tensor([conf_level]))
        self.register_buffer("tau_0", torch.zeros(1, 1, n_outputs))

        # Initialize weights with Xavier uniform
        nn.init.xavier_uniform_(self.net.weight, gain=0.01)

    def forward(self, z: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Perform a forward pass to compute quantiles and related metrics.

        Args:
            z: Input tensor of shape (batch_size, z_dim).

        Returns:
            Tuple containing:
                - taus: Cumulative probabilities, shape (batch_size, n_quantiles + 1, 1).
                - tau_hats: Midpoint quantiles, shape (batch_size, n_quantiles, 1).
                - entropies: Entropy of the probability distributions, shape (batch_size, 1).

        Raises:
            ValueError: If z does not have the expected shape (batch_size, z_dim) or if internal tensor shapes
                do not match expected dimensions.
        """
        if z.dim() != 2 or z.shape[1] != self.z_dim:
            raise ValueError(f"Expected z shape (batch_size, {self.z_dim}), got {z.shape}")

        batch_size = z.shape[0]

        z_out = self.dropout(self.net(z)).reshape(batch_size, self.n_quantiles, self.n_outputs)

        # Compute probabilities via softmax
        log_probs = F.log_softmax(z_out, dim=1)
        probs = log_probs.exp()

        # Compute cumulative taus (τ_0 to τ_N)
        tau_0 = cast("torch.Tensor", self.tau_0).repeat(batch_size, 1, 1)  # Shape: (batch_size, 1, n_outputs)
        taus_1_n = torch.cumsum(probs, dim=1)  # Shape: (batch_size, n_quantiles, n_outputs)
        taus = torch.cat((tau_0, taus_1_n), dim=1)  # Shape: (batch_size, n_quantiles + 1, n_outputs)

        # Compute tau_hats (midpoints between consecutive taus)
        tau_hats = (taus[:, :-1, :] + taus[:, 1:, :]) / 2.0  # Shape: (batch_size, n_quantiles, 1)
        _conf_level = cast("torch.Tensor", self.conf_level)
        tau_hats = torch.clamp(
            tau_hats,
            min=_conf_level.item() / 2.0,
            max=1 - (_conf_level.item() / 2.0),
        ).detach()

        # Compute entropies
        entropies = torch.sum(-log_probs * probs, dim=1)  # Shape: (batch_size, 1)

        return taus, tau_hats, entropies


class FPQRDistribution(nn.Module):
    """A neural network for forecasting quantiles using a quantile value network.

    This module predicts quantiles for a forecasting task, combining a quantile
    proposal layer with a linear output layer to produce quantile forecasts.

    Args:
        n_quantiles (int | None): Number of quantiles to forecast.
            If None, defaults to 9.
        num_outputs (int): Number of output features. Defaults to 1.
        hidden_dim (int): Size of the hidden layers. Defaults to 256.
        horizon (int): Number of time steps to forecast. Defaults to 48.
        dropout (float): Dropout rate for the quantile proposal layer.
            Defaults to 0.1.
        conf_level (float): Confidence level for quantile proposal. Defaults to 0.05.
        output_activation (nn.Module | None): Activation function for the output
            layer. Defaults to nn.Identity().
    """

    def __init__(
        self,
        n_quantiles: int | None = 9,
        num_outputs: int = 1,
        hidden_size: int = 256,
        horizon: int = 48,
        dropout: float = 0.1,
        conf_level: float = 0.05,
        kappa: float = 0.25,
        num_cosines: int = 32,
        output_activation: nn.Module | None = None,
        loss_fn: str = "pinball",
    ):
        super().__init__()

        # Handle default for n_quantiles
        if n_quantiles is None:
            n_quantiles = 9

        # Validate inputs
        self._validate_inputs(n_quantiles, num_outputs, hidden_size, horizon, dropout, conf_level)

        self.n_quantiles = n_quantiles
        self.num_outputs = num_outputs
        self.horizon = horizon
        self.output_activation = output_activation or nn.Identity()
        self.relu = nn.ReLU(inplace=True)
        self.loss_fn = loss_fn

        self.quantile_proposal = QuantileProposal(
            n_quantiles=n_quantiles,
            z_dim=hidden_size,
            dropout=dropout,
            conf_level=conf_level,
            n_outputs=horizon,
        )
        if num_cosines > 0:
            self.quantile_cosine = CosinetauEmbedding(
                num_cosines=num_cosines,
                z_dim=hidden_size,
                num_outputs=horizon,
            )
        else:
            self.quantile_cosine = DataEmbedding(c_in=horizon, hidden_size=hidden_size, pos_embed_type="PosEmb")  # type: ignore[assignment]

        self.quantile_output = nn.Sequential(
            nn.Linear(hidden_size, horizon * num_outputs),
            self.output_activation,
        )
        self.quantile_proposal_loss = QuantileProposalLoss(reduction="mean")
        if loss_fn == "pinball":
            self.quantile_loss = QuantileLoss(kappa=kappa, reduction="mean")
        elif loss_fn == "huber-pinball":
            self.quantile_loss = QuantileHuberLoss(kappa=kappa, reduction="mean")  # type: ignore[assignment]
        else:
            raise ValueError(f"Unknown loss function: {loss_fn}. Use 'pinball' or 'huber-pinball'.")

    def _validate_inputs(
        self,
        n_quantiles: int,
        num_outputs: int,
        hidden_size: int,
        horizon: int,
        dropout: float,
        conf_level: float,
    ) -> None:
        """Validates input parameters for the FPQRDistribution module.

        Args:
            n_quantiles: Number of quantiles to forecast.
            num_outputs: Number of output features.
            hidden_size: Size of the latent/hidden dimension from the backbone.
            horizon: Number of time steps to forecast.
            dropout: Dropout rate for the quantile proposal layer.
            conf_level: Confidence level for quantile proposal.

        Raises:
            ValueError: If any input parameter is invalid.
        """
        if n_quantiles <= 0:
            raise ValueError("n_quantiles must be positive")
        if num_outputs <= 0:
            raise ValueError("num_outputs must be positive")
        if hidden_size <= 0:
            raise ValueError("hidden_size must be positive")
        if horizon <= 0:
            raise ValueError("horizon must be positive")
        if not 0 <= dropout <= 1:
            raise ValueError("dropout must be between 0 and 1")
        if not 0 < conf_level < 1:
            raise ValueError("conf_level must be between 0 and 1")

    def _get_quantile_values(self, quantile_levels: torch.Tensor, context_features: torch.Tensor) -> torch.Tensor:
        """Computes quantile values based on the quantile proposal.

        Args:
            quantile_levels: Tensor of shape (batch_size, n_quantiles, z_dim).
            context_features: Tensor of shape (batch_size, z_dim).

        Returns:
            torch.Tensor: Quantile values of shape
                (batch_size, n_quantiles, horizon, num_outputs).
        """
        # Apply cosine transformation to quantile levels
        quantile_embedding = self.quantile_cosine(quantile_levels)

        # Expand context features to match quantile embedding shape
        context_expanded = context_features.unsqueeze(1).expand_as(quantile_embedding)
        # Combine embeddings with ReLU activation
        combined_embedding = self.relu(quantile_embedding * context_expanded + context_expanded)

        # Compute quantile values
        output_quantiles = self.quantile_output(combined_embedding)

        # Reshape to (batch_size, n_quantiles, horizon, num_outputs)
        output_quantiles = output_quantiles.view(
            context_features.size(0),
            -1,
            self.horizon,
            self.num_outputs,
        )
        return output_quantiles

    def forecast(self, input_tensor: torch.Tensor) -> dict[str, Any]:  # type: ignore[override]
        """Forecast quantiles for the given input tensor.

        ``quantile_levels`` is the per-sample proposal grid averaged across the
        batch and horizon dimensions so that downstream consumers receive a
        fixed 1-D array of representative probability levels, matching the
        interface expected by :class:`~twiga.forecaster.result.ForecastResult`.

        Args:
            input_tensor: Input tensor of shape (batch_size, z_dim).

        Returns:
            Dict with keys:

            - ``"loc"``: expected value (weighted sum of quantiles),
              shape ``(B, horizon, num_outputs)``.
            - ``"quantiles"``: quantile forecasts,
              shape ``(B, n_quantiles, horizon, num_outputs)``.
            - ``"quantile_levels"``: representative 1-D numpy array of length
              ``n_quantiles`` (mean of ``tau_hats`` over batch and horizon).
            - ``"conf_level"``: significance level scalar.
        """
        with torch.no_grad():
            taus, tau_hats, _ = self.quantile_proposal(input_tensor)
            quantile_values = self._get_quantile_values(tau_hats, input_tensor)
            loc = (quantile_values * (taus[:, 1:, :, None] - taus[:, :-1, :, None])).sum(dim=1)

            # Preserve full (B, N, horizon) so the evaluation pipeline can
            # compute exact per-step pinball using the proposal's own tau values
            # instead of a representative mean.  Downstream consumers that only
            # need a flat list (column names, CRPS, sharpness) derive it by
            # averaging over the batch and horizon dimensions.
            quantile_levels = tau_hats.cpu().numpy()  # (B, N, horizon)

            return {
                "loc": loc,
                "quantiles": quantile_values,
                "quantile_levels": quantile_levels,
                "conf_level": self.quantile_proposal.conf_level.item(),
            }

    def forward(self, input_tensor: torch.Tensor) -> tuple[torch.Tensor, ...]:  # type: ignore[override]
        """Forward pass of the quantile forecasting network.

        Args:
            input_tensor: Input tensor of shape (batch_size, z_dim).

        Returns:
            torch.Tensor: Forecasted quantiles of shape
                (batch_size, n_quantiles, horizon, num_outputs).
        """
        # Apply quantile proposal layer
        taus, tau_hats, entropies = self.quantile_proposal(input_tensor)
        quantile_values = self._get_quantile_values(tau_hats, input_tensor)

        return quantile_values, taus, tau_hats, entropies

    def step(
        self,
        z: torch.Tensor,
        y: torch.Tensor,
        metric_fn: Callable[..., Any],
        epoch: int | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Perform a single training/validation step.

        Args:
            z: Latent tensor of shape ``(B, hidden_size)`` from the backbone.
            y: Target tensor of shape ``(B, forecast_horizon, num_outputs)``.
            metric_fn: Callable returning a scalar metric given ``(pred, target)``.
            epoch: Current epoch (unused; accepted for interface consistency).

        Returns:
            Tuple of ``(loss, metric)``.
        """
        quantile_values, taus, tau_hats, entropies = self(z)
        y_pred = (quantile_values * (taus[:, 1:, :, None] - taus[:, :-1, :, None])).sum(dim=1)

        y_quantiles = y.unsqueeze(1).expand_as(quantile_values)

        if self.loss_fn == "pinball":
            quantile_loss = self.quantile_loss(
                quantile_values,
                tau_hats.unsqueeze(-1).expand_as(quantile_values),
                y_quantiles,
            )
        elif self.loss_fn == "huber-pinball":
            quantile_loss = self.quantile_loss(
                inputs=quantile_values,
                quantiles=tau_hats.unsqueeze(-1).expand_as(quantile_values),
                targets=y_quantiles,
            )

        with torch.no_grad():
            quantile = self._get_quantile_values(taus[:, 1:-1, :], z)

        quantile_proposal_loss = self.quantile_proposal_loss(
            quantile=quantile,
            quantile_hats=quantile_values.detach(),
            taus=taus.detach(),
        )
        loss = quantile_loss + quantile_proposal_loss - entropies.mean()
        metric = metric_fn(y_pred, y)
        return loss, metric
