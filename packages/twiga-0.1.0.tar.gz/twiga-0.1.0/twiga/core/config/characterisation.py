"""Configuration for signal characterisation and forecastability analysis."""

from __future__ import annotations

from pydantic import BaseModel, Field


class CharacterisationConfig(BaseModel):
    """Configuration for :class:`~twiga.core.data.characterisation.SignalCharacteriser`.

    All parameters have safe defaults suitable for 30-minute power system
    datasets.  Override :attr:`n_samples_per_day` for hourly (``24``) or
    15-minute (``96``) data so that lag suggestions are scaled to the correct
    calendar multiples.

    Args:
        alpha: Significance level for ADF/KPSS stationarity tests and
            ACF/PACF confidence bands.  Defaults to ``0.05``.
        ramp_threshold_pct: Percentile of the absolute first difference
            ``|Δy|`` above which a timestep is classified as a ramp event.
            Defaults to ``90.0``.
        n_samples_per_day: Number of observations per day for the target
            series (e.g. ``48`` for 30-minute, ``24`` for hourly, ``96``
            for 15-minute data).  Used to scale suggested lags to
            calendar-aligned multiples.  Defaults to ``48``.
        max_lag_acf: Maximum lag passed to ACF estimation.
            ``None`` lets the function infer from series length.
            Defaults to ``None``.
        max_lag_pacf: Maximum lag passed to PACF/AR-order estimation.
            ``None`` infers from series length.  Defaults to ``None``.
        max_seasonal_periods: Maximum number of seasonal periods to return.
            Defaults to ``3``.
        n_neighbors_ami: k for the k-nearest-neighbour MI estimator used in
            AMI profiling.  Higher values reduce variance but increase bias.
            Defaults to ``8``.
        ami_max_horizons: Maximum horizon included in the AMI profile.
            ``None`` uses the maximum feasible horizon, which can be slow for
            long series.  Defaults to ``None``.
        ami_noise_floor: Fraction of ``ami_h1`` below which the AMI profile
            is treated as noise.  Defaults to ``0.10``.
        ami_h1_low: ``AMI(h=1)`` below this threshold classifies the series
            as ``'low'`` predictability.  Defaults to ``0.15``.
        rel_auc_low: ``rel_auc`` below this threshold classifies the series
            as ``'low'``.  Defaults to ``0.15``.
        rel_auc_high: ``rel_auc`` at or above this threshold classifies the
            series as ``'high'``.  Defaults to ``0.33``.
    """

    alpha: float = Field(
        default=0.05,
        gt=0.0,
        lt=1.0,
        description="Significance level for stationarity tests and ACF/PACF bands.",
    )
    ramp_threshold_pct: float = Field(
        default=90.0,
        gt=0.0,
        le=100.0,
        description="Percentile of |Δy| above which a step is a ramp event.",
    )
    n_samples_per_day: int = Field(
        default=48,
        gt=0,
        description="Observations per calendar day (48 for 30-min, 24 for hourly).",
    )
    max_lag_acf: int | None = Field(
        default=None,
        ge=1,
        description="Maximum ACF lag. None infers from series length.",
    )
    max_lag_pacf: int | None = Field(
        default=None,
        ge=1,
        description="Maximum PACF lag. None infers from series length.",
    )
    max_seasonal_periods: int = Field(
        default=3,
        gt=0,
        description="Maximum number of seasonal periods reported.",
    )
    n_neighbors_ami: int = Field(
        default=8,
        gt=0,
        description=(
            "k for the k-nearest-neighbour MI estimator used in AMI profiling. "
            "Higher values reduce variance but increase bias."
        ),
    )
    ami_max_horizons: int | None = Field(
        default=None,
        ge=1,
        description=(
            "Maximum horizon included in the AMI profile. None uses the maximum "
            "feasible horizon, which can be slow for long series."
        ),
    )
    ami_noise_floor: float = Field(
        default=0.10,
        gt=0.0,
        lt=1.0,
        description=(
            "Fraction of ami_h1 below which the AMI profile is treated as noise. "
            "effective_horizon is the first h where AMI < ami_noise_floor * ami_h1."
        ),
    )
    ami_h1_low: float = Field(
        default=0.15,
        gt=0.0,
        description="AMI(h=1) below this threshold classifies the series as 'low' predictability.",
    )
    rel_auc_low: float = Field(
        default=0.15,
        gt=0.0,
        description="rel_auc below this threshold classifies the series as 'low'.",
    )
    rel_auc_high: float = Field(
        default=0.33,
        gt=0.0,
        description="rel_auc at or above this threshold classifies the series as 'high'.",
    )
