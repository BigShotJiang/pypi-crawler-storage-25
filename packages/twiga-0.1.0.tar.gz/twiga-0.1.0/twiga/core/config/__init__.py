"""Domain-specific configuration classes.

These configs describe the problem domain (data structure, CV strategy,
uncertainty quantification) rather than a specific model architecture.
"""

from pydantic import Field

from .base import BaseModelConfig
from .characterisation import CharacterisationConfig
from .conformal import ConformalConfig
from .data import DataPipelineConfig
from .forecaster import ForecasterConfig
from .neural import BaseMLPConfig, NeuralModelConfig
from .search_space import BaseSearchSpace

__all__ = [
    "BaseMLPConfig",
    "BaseModelConfig",
    "BaseSearchSpace",
    "CharacterisationConfig",
    "ConformalConfig",
    "DataPipelineConfig",
    "Field",
    "ForecasterConfig",
    "NeuralModelConfig",
]
