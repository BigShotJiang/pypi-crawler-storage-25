"""Base configuration model shared by all model types.

Defines :class:`BaseModelConfig`, the common Pydantic base that every concrete
model config inherits from.  It wires the optional ``search_space`` field into
:meth:`get_optuna_params` so Optuna integration works consistently across the
whole model zoo without any per-model boilerplate.
"""

from __future__ import annotations

from typing import Any, Literal

import optuna
from pydantic import BaseModel, ConfigDict, Field

from .search_space import BaseSearchSpace


class BaseModelConfig(BaseModel):
    """Shared base configuration for all forecasting models.

    Provides the ``name``, ``domain``, and ``search_space`` fields that every
    concrete config is expected to expose, along with a uniform
    :meth:`get_optuna_params` that merges fixed config values with any
    search-space suggestions.

    Subclass this to define model-specific configurations::

        class MyModelConfig(BaseModelConfig):
            name: Literal["my_model"] = Field(default="my_model", exclude=True)
            hidden_size: int = 128
            dropout: float = 0.3
            search_space: BaseSearchSpace = BaseSearchSpace(
                hidden_size=[64, 128, 256],
                dropout=(0.0, 0.5),
            )

    Args:
        name (Literal["base_model"], optional): Model type identifier. Excluded
            from parameter tuning. Defaults to ``"base_model"``.
        domain (Literal["nn"], optional): Modelling domain identifier. Excluded
            from parameter tuning. Defaults to ``"nn"``.
        search_space (BaseSearchSpace | None, optional): Hyperparameter search
            space. When set, its fields are merged into the output of
            :meth:`get_optuna_params` for HPO. Defaults to None.
    """

    name: Literal["base_model"] = Field(
        default="base_model",
        description="Model type identifier. Fixed per subclass; excluded from tuning.",
        exclude=True,
    )
    domain: Literal["nn"] = Field(
        default="nn",
        description="Modelling domain identifier. Fixed to 'nn'; excluded from tuning.",
        exclude=True,
    )
    search_space: BaseSearchSpace | None = Field(
        default=None,
        description="Hyperparameter search space configuration.",
        exclude=True,
    )

    model_config = ConfigDict(extra="allow")
    __pydantic_extra__: dict[str, Any] = Field(default_factory=dict, init=False)

    def get_optuna_params(self, trial: optuna.Trial) -> dict[str, Any]:
        """Return fixed config values merged with Optuna search-space suggestions.

        Fixed parameters come from :meth:`pydantic.BaseModel.model_dump` (with
        ``name`` and ``search_space`` excluded).  If a ``search_space`` is set,
        its fields are sampled for ``trial`` and override any overlapping fixed
        values, allowing a single config object to serve both fixed and tuned
        usage patterns.

        Args:
            trial (optuna.Trial): Active Optuna trial.

        Returns:
            dict[str, Any]: Combined parameter dict ready to pass to the model
                constructor.
        """
        base_params = self.model_dump(exclude={"name", "search_space"})
        if self.search_space:
            search_params = self.search_space.get_optuna_params(trial, prefix=self.name)
            return {**base_params, **search_params}
        return base_params
