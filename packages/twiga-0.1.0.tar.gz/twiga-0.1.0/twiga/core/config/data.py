"""Data pipeline configuration.

Defines :class:`DataPipelineConfig`, which describes the structure of the
input time-series dataset: target variables, feature groups, sequence lengths,
scalers, and lag/window engineering parameters.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class DataPipelineConfig(BaseModel):
    """Configuration for a time-series data pipeline.

    Captures everything the pipeline needs to know about the raw dataset:
    which column to forecast, which features are available, how long the
    lookback and forecast windows are, what scalers to apply, and which
    lag/rolling-window features to engineer.

    Args:
        target_feature (list[str] | str): Target variable name(s) to forecast.
        period (str): Sampling frequency using pandas offset aliases
            (e.g. ``"1H"``, ``"30min"``).
        lookback_window_size (int): Number of past timesteps fed to the model
            as input.
        forecast_horizon (int): Number of future timesteps to predict.
        latitude (float | None, optional): Latitude for day/night feature
            calculation. Defaults to None.
        longitude (float | None, optional): Longitude for day/night feature
            calculation. Defaults to None.
        historical_features (list[str] | None, optional): Features whose future
            values are unknown (historical context only). Defaults to None.
        calendar_features (list[str] | None, optional): Cyclical temporal
            features derived from the timestamp column. Defaults to None.
        exogenous_features (list[str] | None, optional): Features known over
            the full lookback + forecast horizon. Defaults to None.
        future_covariates (list[str] | None, optional): Features known only
            over the forecast horizon. Defaults to None.
        input_scaler (object | None, optional): Scaler applied to input
            features. Defaults to None.
        target_scaler (object | None, optional): Scaler applied to the target
            variable. Defaults to None.
        lags (list[int] | None, optional): Lag intervals in periods for
            feature engineering. Defaults to None.
        windows (list[int] | int | None, optional): Window sizes for rolling
            statistics. Defaults to None.
        window_funcs (list[str] | str | None, optional): Aggregation functions
            applied to rolling windows (e.g. ``"mean"``, ``"std"``).
            Defaults to None.
        date_column (str, optional): Name of the datetime column.
            Defaults to ``"timestamp"``.
    """

    target_feature: list[str] | str = Field(description="Target variable name(s) to forecast.")
    period: str = Field(description="Sampling frequency using pandas offset aliases (e.g. '1H', '30min').")
    lookback_window_size: int = Field(description="Number of past timesteps used as model input.")
    forecast_horizon: int = Field(description="Number of future timesteps to predict.")

    latitude: float | None = Field(default=None, description="Latitude for day/night feature calculation.")
    longitude: float | None = Field(default=None, description="Longitude for day/night feature calculation.")

    historical_features: list[str] | None = Field(
        default=None,
        description="Features whose future values are unknown (historical context only).",
    )
    calendar_features: list[str] | None = Field(
        default=None,
        description="Cyclical temporal features derived from the timestamp column.",
    )
    exogenous_features: list[str] | None = Field(
        default=None,
        description="Features known over the full lookback + forecast horizon.",
    )
    future_covariates: list[str] | None = Field(
        default=None,
        description="Features known only over the forecast horizon.",
    )

    input_scaler: object | None = Field(default=None, description="Scaler applied to input features.")
    target_scaler: object | None = Field(default=None, description="Scaler applied to the target variable.")

    lags: list[int] | None = Field(default=None, description="Lag intervals in periods for feature engineering.")
    windows: list[int] | int | None = Field(default=None, description="Window sizes for rolling statistics.")
    window_funcs: list[str] | str | None = Field(
        default=None,
        description="Aggregation functions applied to rolling windows (e.g. 'mean', 'std').",
    )

    date_column: str = Field(default="timestamp", description="Name of the datetime column.")
    stride: int = Field(
        default=1,
        ge=1,
        description=(
            "Step between consecutive sliding windows. Default 1 produces fully overlapping windows "
            "(maximum data augmentation for ML/NN training). Set to forecast_horizon for "
            "non-overlapping windows - recommended when evaluating baselines to avoid "
            "pseudo-replication in backtesting metrics."
        ),
    )
