"""Conformal prediction configuration.

Defines :class:`ConformalConfig`, which controls the prediction method,
nonconformity score type, and significance level for conformal prediction
wrappers applied to point forecasters.
"""

from __future__ import annotations

from typing import Annotated, Literal
import warnings

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class ConformalConfig(BaseModel):
    """Configuration for conformal prediction methods.

    Supports three conformal predictors - residual-based, quantile-based, and
    residual-fitting - each with compatible nonconformity score types.

    Args:
        method (Literal["residual", "quantile", "residual-fitting"], optional):
            Conformal prediction method:

            - ``"residual"`` - nonconformity scores based on absolute residuals
              ``|y - ŷ|``.
            - ``"quantile"`` - quantile regression for prediction intervals.
            - ``"residual-fitting"`` - fits a secondary model to predict
              residuals for adaptive interval widths.

            Defaults to ``"residual"``.
        score_type (str, optional): Nonconformity score type.
            ``"scaled"`` / ``"unscaled"`` for quantile method;
            ``"res"`` / ``"sign-res"`` for residual-based methods.
            Defaults to ``"res"``.
        alpha (float, optional): Significance level controlling the confidence
            level ``(1 - alpha)`` of the prediction intervals.  Must be in
            ``(0, 1)``.  For example ``alpha=0.1`` → 90 % coverage.
            Defaults to 0.1.

    Raises:
        ValueError: If ``method="quantile"`` is combined with a residual
            score type, or if a residual method is combined with a quantile
            score type.

    Examples:
        >>> ConformalConfig(method="residual", score_type="res", alpha=0.1)
        ConformalConfig(method='residual', score_type='res', alpha=0.1)
        >>> ConformalConfig(method="quantile", score_type="scaled", alpha=0.05)
        ConformalConfig(method='quantile', score_type='scaled', alpha=0.05)
    """

    method: Annotated[
        Literal["residual", "quantile", "residual-fitting"],
        Field(
            default="residual",
            description=(
                "Conformal prediction method. "
                "'residual': absolute residual scores. "
                "'quantile': quantile regression intervals. "
                "'residual-fitting': secondary model predicts residuals for adaptive widths."
            ),
        ),
    ]

    score_type: Annotated[
        Literal["scaled", "unscaled", "res", "sign-res"],
        Field(
            default="res",
            description=(
                "Nonconformity score type. "
                "'scaled'/'unscaled': for quantile method. "
                "'res'/'sign-res': for residual-based methods."
            ),
        ),
    ]

    alpha: Annotated[
        float,
        Field(
            default=0.1,
            gt=0.0,
            lt=1.0,
            description=(
                "Significance level for prediction intervals. "
                "Controls coverage as (1 - alpha). "
                "Example: alpha=0.1 → 90% prediction intervals."
            ),
        ),
    ]

    model_config = ConfigDict(extra="forbid")

    @field_validator("alpha")
    @classmethod
    def warn_extreme_alpha(cls, v: float) -> float:
        """Warn if alpha is likely to produce degenerate intervals."""
        if v < 0.01:
            warnings.warn(
                "alpha < 0.01 may produce excessively wide prediction intervals.",
                UserWarning,
                stacklevel=2,
            )
        if v > 0.5:
            warnings.warn(
                "alpha > 0.5 may produce excessively narrow prediction intervals.",
                UserWarning,
                stacklevel=2,
            )
        return v

    @model_validator(mode="after")
    def validate_method_score_compatibility(self) -> ConformalConfig:
        """Validate that method and score_type are compatible."""
        if self.method == "quantile" and self.score_type not in ("scaled", "unscaled"):
            raise ValueError(
                f"method='quantile' requires score_type in ('scaled', 'unscaled'), got '{self.score_type}'",
            )
        if self.method in ("residual", "residual-fitting") and self.score_type not in ("res", "sign-res"):
            raise ValueError(
                f"method='{self.method}' requires score_type in ('res', 'sign-res'), got '{self.score_type}'",
            )
        return self
