"""Forecaster cross-validation and experiment configuration.

Defines :class:`ForecasterConfig`, which controls the time-series
cross-validation strategy, project metadata, and output paths used by the
top-level forecaster runner.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class ForecasterConfig(BaseModel):
    """Configuration for the forecaster cross-validation runner.

    Controls how the time-series is split for evaluation (split frequency,
    window type, train/test sizes), and holds project-level metadata such as
    the project name and output file name.

    Args:
        domain (Literal["ml"], optional): Modelling domain identifier. Fixed
            to ``"ml"``; excluded from parameter tuning. Defaults to ``"ml"``.
        split_freq (str, optional): Unit for ``train_size``, ``test_size``, and
            ``gap``. One of ``"days"``, ``"hours"``, ``"weeks"``, ``"months"``,
            ``"years"``. Defaults to ``"months"``.
        test_size (int, optional): Number of ``split_freq`` units in each test
            fold. Defaults to 1.
        train_size (int, optional): Number of ``split_freq`` units in each
            training fold (rolling window only). Defaults to 1.
        gap (int, optional): Number of ``split_freq`` units between the end
            of the training fold and the start of the test fold. Defaults to 0.
        stride (int | None, optional): Step size between consecutive splits in
            ``split_freq`` units. None uses ``test_size`` as the stride.
            Defaults to None.
        window (Literal["expanding", "rolling"], optional): Cross-validation
            window strategy. Defaults to ``"expanding"``.
        num_splits (int | None, optional): Maximum number of CV splits.
            None uses all available splits. Defaults to None.
        project_name (str, optional): Experiment / project name used for
            logging and output paths. Defaults to ``"experiment"``.
        file_name (str | None, optional): Output file name. None auto-generates
            from the project name. Defaults to None.
        seed (int, optional): Random seed for reproducibility. Defaults to 42.
        date_column (str, optional): Name of the datetime column in the
            dataset. Defaults to ``"timestamp"``.
        root_dir (str, optional): Root directory for output artefacts.
            Defaults to ``"../"``.
        metrics (tuple[str] | list[str] | None, optional): Evaluation metrics
            to compute and log. None uses the runner's defaults.
            Defaults to None.
    """

    domain: Literal["ml"] = Field(
        default="ml",
        description="Modelling domain identifier, fixed to 'ml'. Excluded from parameter tuning.",
        exclude=True,
    )

    split_freq: Literal["days", "minutes", "hours", "weeks", "months", "years"] = Field(
        default="months",
        description="Unit for train_size, test_size, and gap.",
    )
    test_size: int = Field(default=1, description="Number of split_freq units in each test fold.")
    train_size: int = Field(default=1, description="Number of split_freq units per training fold (rolling only).")
    gap: int = Field(default=0, description="Units between end of train fold and start of test fold.")
    stride: int | None = Field(
        default=None,
        description="Step between consecutive splits in split_freq units. None uses test_size.",
    )
    window: Literal["expanding", "rolling"] = Field(
        default="expanding",
        description="Cross-validation window strategy.",
    )
    num_splits: int | None = Field(
        default=None,
        description="Maximum number of CV splits. None uses all available.",
    )

    project_name: str = Field(default="experiment", description="Experiment name used for logging and output paths.")
    file_name: str | None = Field(default=None, description="Output file name. None auto-generates.")
    seed: int = Field(default=42, description="Random seed for reproducibility.")
    date_column: str = Field(default="timestamp", description="Name of the datetime column.")
    root_dir: str = Field(default="../", description="Root directory for output artefacts.")
    metrics: tuple[str, ...] | list[str] | None = Field(
        default=None,
        description="Evaluation metrics to compute and log. None uses runner defaults.",
    )
    checkpoints_path: str | None = Field(
        default=None,
        description=(
            "Explicit checkpoint directory path.  When set, overrides the default path "
            "derived from root_dir / 'checkpoints' / project_name / model_type.  "
            "Setting this allows on_load_checkpoint() to work on a fresh (unfitted) "
            "forecaster without calling fit() first."
        ),
    )
