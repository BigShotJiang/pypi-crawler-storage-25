"""Hyperparameter search space validation and Optuna sampling.

Defines :class:`BaseSearchSpace`, the Pydantic model that validates search
space definitions and generates Optuna parameter suggestions from them.  All
model configs that support HPO hold a ``search_space`` field typed to this
class or a subclass.
"""

from __future__ import annotations

import math
from typing import Any

import optuna
from pydantic import BaseModel, ConfigDict, Field, model_validator


def make_hashable(item: Any) -> Any:
    """Recursively convert lists to tuples so values can be put in a set."""
    if isinstance(item, list):
        return tuple(make_hashable(i) for i in item)
    return item


class BaseSearchSpace(BaseModel):
    """Pydantic model for validating hyperparameter optimisation search spaces.

    Each field must be either:

    - A ``tuple[float, float]`` or ``tuple[int, int]`` representing a
      continuous range ``(low, high)``.  Float ranges spanning more than one
      order of magnitude (``high / low >= 10``) are sampled on a log scale
      automatically.
    - A ``list`` of at least one categorical value.

    The class uses ``extra="allow"`` so that concrete search spaces can be
    defined inline without subclassing::

        space = BaseSearchSpace(
            latent_size=[64, 128, 256],
            dropout=(0.0, 0.5),
        )

    Args:
        **kwargs: Any keyword argument whose value is a valid range tuple or
            categorical list.

    Examples:
        >>> space = BaseSearchSpace(lr=(1e-4, 1e-2), activation=["relu", "tanh"])
        >>> params = space.get_optuna_params(trial, prefix="mlp")
    """

    model_config = ConfigDict(extra="allow")
    __pydantic_extra__: dict[str, Any] = Field(default_factory=dict, init=False)

    @model_validator(mode="after")
    def validate_search_space(self) -> BaseSearchSpace:
        """Validate all fields have valid types and structure."""
        for name, value in self.model_dump().items():
            if isinstance(value, tuple):
                if len(value) != 2:
                    raise ValueError(f"{name}: range tuple must have exactly 2 elements")
                if not all(isinstance(v, int | float) for v in value):
                    raise TypeError(f"{name}: range tuple must contain only numeric values")
                if value[0] >= value[1]:
                    raise ValueError(f"{name}: range must satisfy low < high, got {value}")
            elif isinstance(value, list):
                if not value:
                    raise ValueError(f"{name}: categorical list must contain at least one choice")
                hashable = [make_hashable(v) for v in value]
                if len(set(hashable)) != len(hashable):
                    raise ValueError(f"{name}: categorical list contains duplicate values")
            else:
                raise TypeError(f"{name}: expected tuple (range) or list (categorical), got {type(value).__name__}")
        return self

    def get_optuna_params(self, trial: optuna.Trial, prefix: str = "") -> dict[str, Any]:
        """Generate Optuna parameter suggestions for all fields.

        Args:
            trial (optuna.Trial): Active Optuna trial.
            prefix (str, optional): Prefix prepended to each parameter name
                in the trial (e.g. the model name) to avoid collisions when
                multiple search spaces are sampled in the same trial.
                Defaults to ``""``.

        Returns:
            dict[str, Any]: Mapping of field names (without prefix) to their
                sampled values.
        """
        params: dict[str, Any] = {}
        for name, value in self.model_dump().items():
            trial_name = f"{prefix}_{name}" if prefix else name
            if isinstance(value, tuple):
                low, high = value
                if all(isinstance(v, int) for v in value):
                    params[name] = trial.suggest_int(trial_name, low, high)
                else:
                    params[name] = trial.suggest_float(trial_name, low, high, log=self._should_use_log(low, high))
            elif isinstance(value, list):
                params[name] = trial.suggest_categorical(trial_name, value)
        return params

    def validate_against(self, config: BaseModel) -> None:
        """Raise ValueError if any search space field name is not present on config.

        Catches typos in search space definitions early - before an Optuna trial
        is run - so that mis-spelled field names produce a clear error instead of
        silently sampling a parameter that never gets applied.

        Args:
            config: The model config instance (or class) whose fields define the
                valid parameter names.

        Raises:
            ValueError: If one or more field names in this search space do not
                exist on *config*.

        Examples:
            >>> space = BaseSearchSpace(hiddn_dim=[64, 128])  # typo!
            >>> space.validate_against(my_model_config)
            Traceback (most recent call last):
                ...
            ValueError: Search space contains unknown fields: {'hiddn_dim'}. ...

        """
        config_fields = set(config.model_fields)
        space_fields = set(self.model_dump())
        unknown = space_fields - config_fields
        if unknown:
            raise ValueError(
                f"Search space contains unknown fields: {unknown}. "
                f"Valid fields for {type(config).__name__}: {sorted(config_fields)}",
            )

    @staticmethod
    def _should_use_log(low: float, high: float) -> bool:
        """Return True if the range warrants log-scale sampling.

        Applies log scale when both bounds are positive and the ratio spans at
        least one order of magnitude.

        Args:
            low (float): Lower bound.
            high (float): Upper bound.

        Returns:
            bool: True if log scale should be used.
        """
        if low <= 0 or high <= 0:
            return False
        ratio = high / low
        return ratio >= 10 and math.log10(ratio) >= 1
