"""Configuration for neural network models with integrated training and HPO.

Extends :class:`BaseModelConfig` with:

- Standard training parameters (batch size, epochs, optimizer, scheduler)
- Two-level conditional HPO system that is fully reusable across models

Subclasses should only define the model architecture via the ``search_space``
field. Optimizer, scheduler and training hyperparameters are handled centrally
using three class-level dictionaries and conditional sampling logic.

The method :meth:`get_optuna_params` combines subclass architecture suggestions
with training hyperparameters selected via Optuna-compatible conditional spaces.

HPO structure:
    - BASE_TRAINING_SEARCH_SPACE     global categorical choices
    - OPTIMIZER_PARAM_SEARCH         optimizer-specific ranges
    - SCHEDULER_PARAM_SEARCH         scheduler-specific ranges

Examples:
    Customizing ranges for one model family:

    >>> class TransformerConfig(NeuralModelConfig):
    ...     OPTIMIZER_PARAM_SEARCH: ClassVar = {
    ...         **NeuralModelConfig.OPTIMIZER_PARAM_SEARCH,
    ...         "adamw": {"lr": (3e-5, 8e-4)},
    ...     }
    ...
    ...     search_space = Field(
    ...         default=BaseSearchSpace(num_layers=[6, 12], d_model=[384, 512]),
    ...     )
"""

from __future__ import annotations

from typing import ClassVar, Literal

import optuna
from pydantic import Field

from .base import BaseModelConfig
from .search_space import BaseSearchSpace


class NeuralModelConfig(BaseModelConfig):
    """Configuration for neural network-based forecasting models.

    Extends :class:`BaseModelConfig` with training infrastructure fields and a
    shared three-dict HPO system for optimizer, scheduler, and batch-size
    search.  See the module docstring for a full explanation of the search
    space design.

    The optimizer and scheduler are selected via :attr:`optimizer_type` and
    :attr:`lr_scheduler_type`.  Both are captured by
    ``save_hyperparameters()`` in
    :class:`~twiga.models.nn.core.base.BaseNeuralModel` at training time, so
    they must be declared as fields here.

    Optional fine-grained overrides can be supplied via
    :attr:`optimizer_params` and :attr:`scheduler_params`.  When provided they
    are merged into the corresponding entry of
    ``BaseNeuralModel.OPTIMIZERS`` / ``BaseNeuralModel.SCHEDULERS``, allowing
    partial overrides (e.g. only ``lr``) without replacing the full dict.

    Args:
        name (Literal["neural_model"], optional): Model type identifier.
            Defaults to ``"neural_model"``.
        domain (Literal["nn"], optional): Modelling domain identifier.
            Defaults to ``"nn"``.
        rich_progress_bar (bool, optional): Enable rich progress bars.
            Defaults to True.
        wandb_logging (bool, optional): Enable Weights & Biases logging.
            Defaults to False.
        drop_last (bool, optional): Drop the last incomplete batch.
            Defaults to True.
        num_workers (int, optional): DataLoader worker count. Defaults to 8.
        batch_size (int, optional): Training batch size. Defaults to 64.
        pin_memory (bool, optional): Pin memory for faster GPU transfer.
            Defaults to True.
        max_epochs (int, optional): Maximum training epochs. Defaults to 10.
        patience (int, optional): Early-stopping patience in epochs.
            Defaults to 10.
        resume_training (bool, optional): Resume from last checkpoint.
            Defaults to True.
        seed (int, optional): Positive integer random seed. Defaults to 42.
        metric (Literal["mae", "mse", "smape"], optional): Validation metric.
            Defaults to ``"mae"``.
        optimizer_type (Literal[...], optional): Native ``torch.optim``
            optimizer. Defaults to ``"adamw"``.
        lr_scheduler_type (Literal[...], optional): Native
            ``torch.optim.lr_scheduler`` class. Defaults to ``"multi_step"``.
        optimizer_params (dict | None, optional): Partial override for the
            selected optimizer's default params. Defaults to None.
        scheduler_params (dict | None, optional): Partial override for the
            selected scheduler's default params. Defaults to None.
    """

    name: Literal["neural_model"] = Field(  # type: ignore[assignment]
        default="neural_model",
        description="Model type identifier.",
        exclude=True,
    )
    domain: Literal["nn"] = Field(
        default="nn",
        description="Modelling domain identifier, fixed to 'nn'. Excluded from tuning.",
        exclude=True,
    )

    # ── Training infrastructure ───────────────────────────────────────────────
    rich_progress_bar: bool = Field(True, description="Enable rich progress bars during training.")
    wandb_logging: bool = Field(False, description="Enable logging to Weights & Biases.")
    drop_last: bool = Field(
        True,
        description="Drop the last incomplete batch when dataset size is not divisible by batch_size.",
    )
    num_workers: int = Field(8, description="Number of DataLoader worker processes.")
    batch_size: int = Field(64, description="Training batch size.")
    pin_memory: bool = Field(True, description="Pin memory for faster CPU→GPU transfer.")
    max_epochs: int = Field(10, description="Maximum number of training epochs.")
    patience: int = Field(10, description="Early-stopping patience (epochs without improvement).")
    resume_training: bool = Field(True, description="Resume training from the last checkpoint.")
    seed: int = Field(
        default=42,
        gt=0,
        description="Positive integer seed for reproducibility.",
    )

    # ── Evaluation ────────────────────────────────────────────────────────────
    metric: Literal["mae", "mse", "smape"] = Field(
        "mae",
        description="Metric used for validation and early stopping.",
    )

    # ── Optimizer ─────────────────────────────────────────────────────────────
    optimizer_type: Literal[
        "adam",
        "adamw",
        "nadam",
        "radam",
        "adamax",
        "adafactor",
        "adagrad",
        "adadelta",
        "rmsprop",
        "rprop",
        "asgd",
        "sgd",
        "muon",
    ] = Field(
        "adamw",
        description=(
            "Optimizer to use during training. All options are native torch.optim algorithms. "
            "Default parameter sets live in BaseNeuralModel.OPTIMIZERS and can be partially "
            "overridden via optimizer_params."
        ),
    )
    optimizer_params: dict | None = Field(
        default_factory=lambda: {"lr": 1e-3, "weight_decay": 1e-6},
        description=(
            "Partial override for the selected optimizer's default parameters. "
            "Only the supplied keys are overridden; unspecified keys retain BaseNeuralModel defaults. "
            "Example: {'lr': 2e-4} changes only the learning rate."
        ),
    )

    # ── Scheduler ─────────────────────────────────────────────────────────────
    lr_scheduler_type: Literal[
        "step",
        "multi_step",
        "multiplicative",
        "exponential",
        "constant",
        "linear_decay",
        "polynomial",
        "cosine_annealing",
        "cosine_annealing_lr",
        "cyclic",
        "reduce_on_plateau",
        "one_cycle",
        "warmup_multi_step",
        "warmup_cosine",
    ] = Field(
        "multi_step",
        description=(
            "Learning rate scheduler. All options are native torch.optim.lr_scheduler classes. "
            "Default parameter sets live in BaseNeuralModel.SCHEDULERS and can be partially "
            "overridden via scheduler_params."
        ),
    )
    scheduler_params: dict | None = Field(
        default_factory=lambda: {
            "milestones": [],
            "prob_decay_1": 0.50,
            "prob_decay_2": 0.90,
            "gamma": 0.1,
        },
        description=(
            "Partial override for the selected scheduler's default parameters. "
            "Only the supplied keys are overridden; unspecified keys retain BaseNeuralModel defaults. "
            "Example: {'gamma': 0.05} changes only the decay factor."
        ),
    )

    # ── Shared HPO search-space infrastructure ────────────────────────────────

    BASE_TRAINING_SEARCH_SPACE: ClassVar[BaseSearchSpace] = BaseSearchSpace(  # type: ignore[call-arg]
        optimizer_type=["adam", "adamw"],
        lr_scheduler_type=["warmup_cosine", "multi_step", "reduce_on_plateau"],
        batch_size=[8, 16, 32, 64],
    )

    # Dictionary mapping types to their specific BaseSearchSpace
    OPTIMIZER_PARAM_SEARCH: ClassVar[dict[str, BaseSearchSpace]] = {
        "adam": BaseSearchSpace(lr=(1e-4, 1e-2), weight_decay=(1e-7, 1e-4)),  # type: ignore[call-arg]
        "adamw": BaseSearchSpace(lr=(1e-4, 1e-2), weight_decay=(1e-6, 1e-3)),  # type: ignore[call-arg]
        "muon": BaseSearchSpace(lr=(1e-3, 1e-1), momentum=(0.9, 0.99), ns_steps=[4, 6, 8]),  # type: ignore[call-arg]
    }

    SCHEDULER_PARAM_SEARCH: ClassVar[dict[str, BaseSearchSpace]] = {
        "warmup_cosine": BaseSearchSpace(  # type: ignore[call-arg]
            warmup_epochs=[3, 5, 10],
            eta_min=(1e-7, 1e-5),
        ),
        "multi_step": BaseSearchSpace(  # type: ignore[call-arg]
            prob_decay_1=(0.3, 0.6),
            prob_decay_2=(0.7, 0.95),
            gamma=[0.1, 0.2, 0.5],
        ),
        "reduce_on_plateau": BaseSearchSpace(  # type: ignore[call-arg]
            factor=[0.1, 0.2, 0.5],
            prob_patience=(0.05, 0.2),
        ),
    }

    @classmethod
    def sample_training_params(cls, trial: optuna.Trial) -> dict:
        """Sample optimizer, scheduler, and batch-size using BaseSearchSpace logic."""
        # 1. Sample top-level choices
        base_params = cls.BASE_TRAINING_SEARCH_SPACE.get_optuna_params(trial)

        opt_type = base_params["optimizer_type"]
        sch_type = base_params["lr_scheduler_type"]

        # 2. Sample conditional optimizer params using 'opt' prefix
        opt_space = cls.OPTIMIZER_PARAM_SEARCH.get(opt_type)
        optimizer_params = opt_space.get_optuna_params(trial, prefix="opt") if opt_space else {}

        # 3. Sample conditional scheduler params using 'sch' prefix
        sch_space = cls.SCHEDULER_PARAM_SEARCH.get(sch_type)
        scheduler_params = sch_space.get_optuna_params(trial, prefix="sch") if sch_space else {}

        return {
            "optimizer_type": opt_type,
            "lr_scheduler_type": sch_type,
            "batch_size": base_params["batch_size"],
            "optimizer_params": optimizer_params,
            "scheduler_params": scheduler_params,
        }

    @classmethod
    def from_data_config(cls, data_config, **kwargs):
        """Create a config instance with dimensions derived from a DataPipelineConfig.

        Args:
            data_config (DataPipelineConfig): Pipeline config providing feature
                counts and sequence dimensions.
            **kwargs: Additional fields forwarded to the constructor, allowing
                any field to be overridden at instantiation time.

        Returns:
            NeuralModelConfig: Populated config instance.

        Raises:
            TypeError: If ``data_config.target_feature`` is not ``str`` or
                ``list[str]``.
            AttributeError: If ``data_config`` is missing ``forecast_horizon``.
        """
        if isinstance(data_config.target_feature, str):
            num_target_feature = 1
        elif isinstance(data_config.target_feature, list):
            num_target_feature = len(data_config.target_feature)
        else:
            raise TypeError("target_feature must be str or list[str]")

        if not hasattr(data_config, "forecast_horizon"):
            raise AttributeError("DataPipelineConfig missing forecast_horizon")

        return cls(
            num_target_feature=num_target_feature,
            num_historical_features=len(data_config.historical_features or []),
            num_calendar_features=len(data_config.calendar_features or []),
            num_exogenous_features=len(data_config.exogenous_features or []),
            num_future_covariates=len(data_config.future_covariates or []),
            forecast_horizon=data_config.forecast_horizon,
            lookback_window_size=data_config.lookback_window_size,
            **kwargs,
        )

    def get_optuna_params(self, trial: optuna.Trial) -> dict:
        """Standard HPO sampling for all neural models.

        Combines child-specific architecture parameters with the
        standardized conditional optimizer and scheduler search space.
        """
        # 1. Get the 'flat' parameters defined in the child's search_space field
        # (e.g., hidden_dim, num_layers, etc.)
        params = super().get_optuna_params(trial)

        # 2. Inject the 'conditional' training parameters
        training_params = self.sample_training_params(trial)
        params.update(training_params)

        return params


class BaseMLPConfig(NeuralModelConfig):
    """Base configuration shared by all MLP-based time series forecasting models.

    Provides common input dimensions, sequence parameters, core MLP architecture
    flags, and a reusable set of hyperparameter ranges suitable for most MLP-style
    forecasters.

    Intended to be subclassed by concrete model configurations (e.g. MLPFConfig,
    MLPGAFConfig, etc.) that may add model-specific layers, gating mechanisms,
    patching strategies, or loss/regularization terms.

    The class defines:

    - Standard feature counts and sequence lengths
    - Shared embedding, normalization, and MLP block options
    - A baseline search space (`BASE_MLP_SEARCH`) that subclasses can inherit,
      extend, or override when defining their `search_space`.

    Attributes:
        num_target_feature: Number of variables / time series to forecast
        num_historical_features: Number of time-varying past covariates
        num_calendar_features: Number of known calendar / time-of-day features
        num_exogenous_features: Number of known static or slow-changing features
        num_future_covariates: Number of future-known (forecastable) covariates

        forecast_horizon: Number of future steps to predict
        lookback_window_size: Length of historical input context

        embedding_size: Dimension used for value and positional embeddings
        embedding_type: Positional encoding strategy (None = disabled)
        value_embed_type: Method for projecting/embedding input values

        use_norm: Apply LayerNorm inside MLP blocks
        use_bias: Include bias terms in linear layers
        use_residual: Use residual connections within MLP blocks
        use_temporal_mixer: Insert temporal mixing layer before the encoder

        latent_size: Dimension of the final encoded representation
        hidden_dim: Base hidden dimension inside MLP layers
        width_multiplier: Expansion ratio inside feed-forward blocks
        num_layers: Number of MLP blocks / layers per encoder

        activation_function: Activation function in hidden layers
        out_activation_function: Activation applied to model outputs

        dropout: Dropout probability during training
        alpha: Weight for combining MSE and MAE in the loss (0 = pure MAE)

        BASE_MLP_SEARCH: Class-level dictionary of default hyperparameter ranges.
            Intended to be merged / overridden in subclasses when building
            the final `search_space`.
    """

    # Input dimensions
    num_target_feature: int = Field(
        0,
        description=(
            "Number of target variables / series to forecast. "
            "Defaults to 0 and is auto-populated from DataPipelineConfig when passed to TwigaForecaster."
        ),
    )
    num_historical_features: int = Field(0, description="Number of time-varying historical covariates")
    num_calendar_features: int = Field(0, description="Number of known calendar / positional features")
    num_exogenous_features: int = Field(0, description="Number of known static or slow-varying features")
    num_future_covariates: int = Field(0, description="Number of future-known (forecastable) covariates")

    # Sequence lengths
    forecast_horizon: int = Field(
        0,
        description=(
            "Number of future time steps to predict. "
            "Defaults to 0 and is auto-populated from DataPipelineConfig when passed to TwigaForecaster."
        ),
    )
    lookback_window_size: int = Field(
        0,
        description=(
            "Length of historical input sequence. "
            "Defaults to 0 and is auto-populated from DataPipelineConfig when passed to TwigaForecaster."
        ),
    )

    # Embeddings
    embedding_size: int = Field(28, description="Embedding dimension")
    embedding_type: Literal["PosEmb", "LearnPosEmb"] | None = Field(
        None,
        description="Positional encoding type (None = disabled)",
    )
    value_embed_type: Literal["ConvEmb", "LinearEmb"] | None = Field(
        None,
        description="Input value embedding/projection type (None = disabled)",
    )

    # MLP block options
    use_norm: bool = Field(True, description="Use LayerNorm in MLP blocks")
    use_bias: bool = Field(True, description="Include bias in linear layers")
    use_residual: bool = Field(False, description="Residual connections in MLPs")
    use_temporal_mixer: bool = Field(False, description="Add temporal mixing layer before encoder")

    # MLP dimensions
    latent_size: int = Field(128, description="Dimension of encoded representation")
    hidden_dim: int = Field(256, description="Base hidden size in MLP layers")
    width_multiplier: float = Field(2.0, description="Feed-forward expansion factor")
    num_layers: int = Field(2, description="Number of MLP blocks per encoder")

    # Activations
    activation_function: Literal["SiLU", "ELU", "LeakyReLU", "ReLU", "GELU"] = Field(
        "SiLU",
        description="Activation function in hidden layers",
    )
    out_activation_function: Literal["Identity", "Tanh", "Sigmoid"] = Field(
        "Identity",
        description="Final output activation",
    )

    # Regularization & loss
    dropout: float = Field(0.25, description="Dropout probability")
    alpha: float = Field(0.1, description="MSE/MAE mixture weight (0 = MAE only)")

    # Shared HPO ranges
    base_mlp_search: ClassVar[dict] = {
        "latent_size": [16, 32, 64, 128, 256],
        "hidden_dim": [32, 64, 128, 256],  # capped at 256; 512 rarely justified for time series
        "num_layers": (2, 5),  # capped at 5; deeper MLPs overfit on typical forecast horizons
        "width_multiplier": [0.5, 1.0, 1.5, 2.0],  # removed 3.0; 3× expansion is expensive
        "embedding_size": [8, 16, 28, 32],
        "value_embed_type": [None, "LinearEmb", "ConvEmb"],
        "embedding_type": [None, "PosEmb", "LearnPosEmb"],
        "dropout": (0.05, 0.5),
        "alpha": (0.05, 0.9),
        "use_norm": [False, True],
        "use_residual": [False, True],
        "activation_function": ["SiLU", "ELU", "LeakyReLU", "ReLU", "GELU"],
    }
