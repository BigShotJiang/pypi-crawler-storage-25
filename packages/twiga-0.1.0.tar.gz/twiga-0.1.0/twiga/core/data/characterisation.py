r"""Target signal characterisation for Layer 1 of the Twiga diagnostic workflow.

Stage 1 of the domain intelligence protocol characterises the target series
:math:`y_t` along four dimensions before any feature engineering or model
training occurs:

1. **Stationarity** -- joint ADF/KPSS testing determines the integration
   order *d* and governs whether autoregressive features operate on levels
   or differences.
2. **Predictability and complexity** -- sample entropy, permutation entropy,
   and the Hurst exponent are computed separately for the full series, stable
   demand windows, and high-ramp windows to identify regime-dependent changes
   in signal structure.
3. **Temporal structure** -- ACF/PACF analysis identifies the effective lag
   order :math:`\hat{p}` and dominant seasonal periodicities, which directly
   parameterise the autoregressive window and calendar encoding.
4. **Forecastability** -- horizon-specific Auto-Mutual Information (AMI) on
   first-differenced values quantifies how much the past tells us about the
   future at each horizon and how far that information persists.

The results are collected in a :class:`CharacterisationResult` whose
:meth:`~CharacterisationResult.to_pipeline_hints` method returns a dict of
``DataPipeline`` constructor kwargs, closing the Stage 1 to Stage 4 loop.
"""

from __future__ import annotations

from typing import Any, Literal

import numpy as np
import pandas as pd
from pydantic import BaseModel, ConfigDict, Field, field_validator

from twiga.core.config.characterisation import CharacterisationConfig  # noqa: F401
from twiga.core.stats.ami import get_ami_profile
from twiga.core.stats.autocorr import estimate_ar_order
from twiga.core.stats.entropy import (
    get_hurst_exponent,
    get_permutation_entropy,
    get_sample_entropy,
)
from twiga.core.stats.seasonality import get_acf_values
from twiga.core.stats.stationarity import adf_test, kpss_test
from twiga.core.utils.logger import get_logger

log = get_logger(__name__)

# Minimum number of observations required for meaningful entropy estimates.
_MIN_ENTROPY_OBS: int = 30

# Minimum number of observations required for stationarity testing.
_MIN_STATIONARITY_OBS: int = 10

# Minimum number of observations for ACF/PACF.
_MIN_TEMPORAL_OBS: int = 20

# Minimum number of observations (in the differenced series) for AMI computation.
# Must be greater than n_neighbors + 1 for at least one horizon to be feasible.
_MIN_AMI_OBS: int = 30


# ---------------------------------------------------------------------------
# Result models  (frozen -- diagnostic outputs are immutable)
# ---------------------------------------------------------------------------


class StationarityResult(BaseModel):
    """Joint ADF/KPSS stationarity diagnosis.

    Args:
        adf_statistic: ADF test statistic (more negative implies stronger
            evidence of stationarity).
        adf_pvalue: ADF p-value.  Values below ``alpha`` reject the unit-root
            null hypothesis (i.e. the series is stationary).
        kpss_statistic: KPSS test statistic.
        kpss_pvalue: KPSS p-value.  Values below ``alpha`` reject the
            stationarity null hypothesis (i.e. the series is non-stationary).
        integration_order: Recommended differencing order *d*.  ``0`` means
            operate on levels; ``1`` means first-difference before modelling.
        verdict: Human-readable joint interpretation of the two tests.
        recommendation: One-sentence operational guidance derived from
            ``verdict``.
    """

    model_config = ConfigDict(frozen=True)

    adf_statistic: float
    adf_pvalue: float = Field(ge=0.0, le=1.0)
    kpss_statistic: float
    kpss_pvalue: float = Field(ge=0.0, le=1.0)
    integration_order: int = Field(ge=0, le=2)
    verdict: Literal[
        "stationary",
        "non-stationary",
        "near-integrated",
        "fractional",
    ]
    recommendation: str


class ComplexityProfile(BaseModel):
    """Entropy and long-memory profile for a single operating regime.

    Args:
        regime: One of ``"full"``, ``"stable"``, or ``"ramp"``.
        n_observations: Number of timesteps in the regime window used
            for the computation.
        sample_entropy: Sample entropy of the regime series.  Lower values
            indicate more regular, predictable behaviour.
        permutation_entropy: Normalised permutation entropy.
        hurst_exponent: Hurst exponent (H).  ``H > 0.5`` indicates
            persistent, trend-following behaviour; ``H < 0.5`` indicates
            mean-reversion; ``H ≈ 0.5`` is consistent with a random walk.
    """

    model_config = ConfigDict(frozen=True)

    regime: Literal["full", "stable", "ramp"]
    n_observations: int = Field(ge=0)
    sample_entropy: float
    permutation_entropy: float
    hurst_exponent: float


class TemporalStructureResult(BaseModel):
    """Lag order and seasonal period estimates from ACF/PACF analysis.

    Args:
        ar_order: Suggested AR order *p̂* from the PACF cutoff (Box-Jenkins
            methodology).
        significant_lags: All lags where the PACF is statistically
            significant outside the ``alpha``-level confidence band.
        seasonal_periods: Dominant seasonal periods detected as local
            maxima in the ACF above the confidence band, measured in
            number of timesteps.
        dominant_period: The lag with the single largest ACF value among
            :attr:`seasonal_periods`.  ``None`` if no seasonal periods are
            detected.
        suggested_lags: Calendar-aligned lag multiples derived from
            :attr:`seasonal_periods` and scaled by ``n_samples_per_day``.
            These are ready for direct use as the ``lags`` argument of
            :class:`~twiga.core.data.pipeline.DataPipeline`.
    """

    model_config = ConfigDict(frozen=True)

    ar_order: int = Field(ge=0)
    significant_lags: list[int]
    seasonal_periods: list[int]
    dominant_period: int | None
    suggested_lags: list[int]

    @field_validator("suggested_lags", "significant_lags", "seasonal_periods", mode="before")
    @classmethod
    def _sort_ascending(cls, v: list[int]) -> list[int]:
        return sorted(v)


class PredictabilityResult(BaseModel):
    """AMI-based forecastability classification from the horizon-specific profile.

    Quantifies *how much* information the past contains about each future step
    and *how far* that information persists across horizons.  Two complementary
    measures drive the classification:

    - **ami_h1** -- the level anchor: AMI at the shortest horizon (h = 1).
      A weak h = 1 signal implies low predictability regardless of the decay
      shape.
    - **rel_auc** -- the persistence measure: mean AMI across all horizons
      divided by ami_h1.  A high rel_auc means the signal decays slowly;
      a low rel_auc means it collapses immediately after h = 1.

    Classification rule (applied in order):

    1. ``ami_h1 < ami_h1_low`` → ``"low"`` (signal is too weak at h = 1).
    2. ``rel_auc < rel_auc_low`` → ``"low"`` (signal collapses immediately).
    3. ``rel_auc >= rel_auc_high`` → ``"high"`` (signal is sustained).
    4. Otherwise → ``"moderate"``.

    Args:
        ami_h1: AMI at horizon h = 1 in nats.  Acts as the level anchor for
            the classification.  Zero when no meaningful signal is detected.
        auc: Mean AMI across all computed horizons (nats).  Equivalent to
            the area under the AMI profile divided by the number of horizons.
        rel_auc: ``auc / ami_h1``; zero when ``ami_h1`` is zero.  Captures
            signal persistence independently of signal strength.
        peak_ami: Maximum AMI value (nats) across all horizons.
        peak_horizon: Horizon at which the AMI profile is maximised.
        effective_horizon: First horizon *h* at which the AMI profile drops
            below ``ami_noise_floor * ami_h1``.  ``None`` when ``ami_h1``
            is zero or the profile never decays to the noise floor within the
            computed range.  Used by :meth:`CharacterisationResult.to_pipeline_hints`
            to bound the useful forecast window.
        n_horizons: Number of horizons included in the AMI profile.
        label: Forecastability class - ``"low"``, ``"moderate"``, or ``"high"``.
    """

    model_config = ConfigDict(frozen=True)

    ami_h1: float = Field(ge=0.0, description="AMI at horizon h=1 (level anchor), in nats.")
    auc: float = Field(ge=0.0, description="Mean AMI across all horizons (nats).")
    rel_auc: float = Field(ge=0.0, description="auc / ami_h1; zero when ami_h1 is zero.")
    peak_ami: float = Field(ge=0.0, description="Maximum AMI value across the profile (nats).")
    peak_horizon: int = Field(ge=1, description="Horizon at which AMI is maximised.")
    effective_horizon: int | None = Field(
        default=None,
        description=(
            "First horizon where AMI falls below noise_floor * ami_h1.  "
            "None when ami_h1 is zero or the profile does not decay within the computed range."
        ),
    )
    n_horizons: int = Field(ge=1, description="Number of horizons in the AMI profile.")
    label: Literal["low", "moderate", "high"]


class CharacterisationResult(BaseModel):
    """Complete Stage 1 characterisation of a target series.

    Aggregates the outputs of the four diagnostic dimensions and exposes
    :meth:`to_pipeline_hints` as the closure mechanism to Stage 4.

    Args:
        target_column: Name of the target column that was characterised.
        n_observations: Total number of observations in the input series.
        stationarity: Joint ADF/KPSS stationarity result.
        complexity: Complexity profiles for the full series, the stable
            demand regime, and the ramp-event regime (always in this order).
        temporal: ACF/PACF-based lag order and seasonal period estimates.
        predictability: AMI-based forecastability classification across
            forecast horizons.
    """

    model_config = ConfigDict(frozen=True)

    target_column: str
    n_observations: int = Field(gt=0)
    stationarity: StationarityResult
    complexity: list[ComplexityProfile]
    temporal: TemporalStructureResult
    predictability: PredictabilityResult

    def to_pipeline_hints(self) -> dict[str, Any]:
        """Return ``DataPipeline`` constructor kwargs derived from Stage 1.

        The returned dict can be unpacked directly into
        :class:`~twiga.core.data.pipeline.DataPipeline` to close the
        Stage 1 to Stage 4 parametrisation loop::

            hints = result.to_pipeline_hints()
            pipe = DataPipeline(
                target_feature=["net_load"],
                period="30min",
                forecast_horizon=48,
                **hints,
            )

        Returns:
            Dict with keys:

            - ``"lags"`` -- list of suggested lag values for the ``lags``
              parameter of ``DataPipeline``.  Empty list when no seasonal
              periods are detected.
            - ``"lookback_window_size"`` -- ``max(lags)`` when lags are
              available, otherwise ``n_samples_per_day * 7`` as a safe
              weekly fallback.
            - ``"integration_order"`` -- integration order *d* from the
              stationarity result, for downstream use with
              :class:`~twiga.core.data.diff.TimeSeriesDifferentiator`.
            - ``"max_forecast_horizon"`` -- :attr:`PredictabilityResult.effective_horizon`,
              the first horizon at which the AMI profile decays to noise level.
              ``None`` when no meaningful AMI signal is detected or the profile
              does not decay within the computed range.
        """
        lags = self.temporal.suggested_lags

        if lags:
            lookback = max(lags)
        else:
            # Safe fallback: one week of observations.
            dominant = self.temporal.dominant_period
            lookback = dominant * 7 if dominant else 7 * 48

        return {
            "lags": lags,
            "lookback_window_size": lookback,
            "integration_order": self.stationarity.integration_order,
            "max_forecast_horizon": self.predictability.effective_horizon,
        }


# ---------------------------------------------------------------------------
# SignalCharacteriser
# ---------------------------------------------------------------------------


class SignalCharacteriser:
    """Orchestrates the three Stage 1 diagnostic dimensions for a target series.

    :class:`SignalCharacteriser` is a pure diagnostic tool, not a pipeline
    step.  It does not inherit from :class:`~sklearn.base.BaseEstimator` and
    does not transform data.  It consumes a target series, runs the three
    diagnostic routines, and returns a :class:`CharacterisationResult` whose
    :meth:`~CharacterisationResult.to_pipeline_hints` method feeds directly
    into :class:`~twiga.core.data.pipeline.DataPipeline` construction.

    Args:
        config: Diagnostic configuration.  Defaults to
            :class:`CharacterisationConfig` with all defaults when ``None``.

    Example::

        config = CharacterisationConfig(n_samples_per_day=48)
        characteriser = SignalCharacteriser(config)
        result = characteriser.analyse(df["net_load"], target_column="net_load")

        hints = result.to_pipeline_hints()
        # hints == {"lags": [48, 96, 336], "lookback_window_size": 336,
        #           "integration_order": 0}

        summary_df = SignalCharacteriser.summary(result)
    """

    def __init__(self, config: CharacterisationConfig | None = None) -> None:
        self.config: CharacterisationConfig = config or CharacterisationConfig()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyse(
        self,
        series: pd.Series | np.ndarray,
        target_column: str = "target",
    ) -> CharacterisationResult:
        """Run all three Stage 1 diagnostic dimensions on ``series``.

        The series should be drawn from the **training split only** to
        prevent data leakage.  It must be sorted in chronological order,
        regularly spaced, and free of NaN values.

        Args:
            series: 1-D target series values.
            target_column: Name label attached to the result for
                traceability.  Defaults to ``"target"``.

        Returns:
            :class:`CharacterisationResult` containing the full Stage 1
            diagnostic output.

        Raises:
            ValueError: If ``series`` contains fewer than
                ``_MIN_STATIONARITY_OBS`` observations or is not 1-D.
        """
        arr = self._validate_series(series, target_column)
        n = len(arr)

        log.info(
            "SignalCharacteriser: analysing '%s' (%d observations).",
            target_column,
            n,
        )

        stationarity = self._assess_stationarity(arr)
        stable_mask, ramp_mask = self._detect_ramp_windows(arr)
        complexity = [
            self._compute_complexity(arr, "full"),
            self._compute_complexity(arr[stable_mask], "stable"),
            self._compute_complexity(arr[ramp_mask], "ramp"),
        ]
        temporal = self._analyse_temporal_structure(arr)
        predictability = self._compute_predictability(arr)

        return CharacterisationResult(
            target_column=target_column,
            n_observations=n,
            stationarity=stationarity,
            complexity=complexity,
            temporal=temporal,
            predictability=predictability,
        )

    @staticmethod
    def summary(result: CharacterisationResult) -> pd.DataFrame:
        """Return a human-readable tabular summary of a characterisation result.

        Produces a two-column DataFrame (``Dimension``, ``Value``) suitable
        for display in a notebook or for logging as a text artefact.

        Args:
            result: A :class:`CharacterisationResult` produced by
                :meth:`analyse`.

        Returns:
            ``pd.DataFrame`` with columns ``["Dimension", "Value"]``.
        """
        rows: list[dict[str, str]] = []

        # Header
        rows.append({"Dimension": "Target", "Value": result.target_column})
        rows.append({"Dimension": "Observations", "Value": str(result.n_observations)})

        # Stationarity
        s = result.stationarity
        rows += [
            {"Dimension": "Stationarity / verdict", "Value": s.verdict},
            {"Dimension": "Stationarity / integration order (d)", "Value": str(s.integration_order)},
            {"Dimension": "Stationarity / ADF p-value", "Value": f"{s.adf_pvalue:.4f}"},
            {"Dimension": "Stationarity / KPSS p-value", "Value": f"{s.kpss_pvalue:.4f}"},
            {"Dimension": "Stationarity / recommendation", "Value": s.recommendation},
        ]

        # Complexity by regime
        for profile in result.complexity:
            pfx = f"Complexity / {profile.regime}"
            rows += [
                {"Dimension": f"{pfx} / n_obs", "Value": str(profile.n_observations)},
                {"Dimension": f"{pfx} / sample entropy", "Value": _fmt(profile.sample_entropy)},
                {"Dimension": f"{pfx} / permutation entropy", "Value": _fmt(profile.permutation_entropy)},
                {"Dimension": f"{pfx} / Hurst exponent", "Value": _fmt(profile.hurst_exponent)},
            ]

        # Temporal structure
        t = result.temporal
        rows += [
            {"Dimension": "Temporal / AR order (p̂)", "Value": str(t.ar_order)},
            {
                "Dimension": "Temporal / significant PACF lags",
                "Value": str(t.significant_lags) if t.significant_lags else "none",
            },
            {
                "Dimension": "Temporal / seasonal periods (steps)",
                "Value": str(t.seasonal_periods) if t.seasonal_periods else "none",
            },
            {"Dimension": "Temporal / dominant period (steps)", "Value": str(t.dominant_period)},
            {
                "Dimension": "Temporal / suggested DataPipeline lags",
                "Value": str(t.suggested_lags) if t.suggested_lags else "none",
            },
        ]

        # Predictability (AMI profile)
        p = result.predictability
        eff_h = str(p.effective_horizon) if p.effective_horizon is not None else "full range"
        rows += [
            {"Dimension": "Predictability / label", "Value": p.label},
            {"Dimension": "Predictability / AMI(h=1)", "Value": _fmt(p.ami_h1)},
            {"Dimension": "Predictability / mean AMI (AUC)", "Value": _fmt(p.auc)},
            {"Dimension": "Predictability / rel_auc", "Value": _fmt(p.rel_auc)},
            {"Dimension": "Predictability / peak AMI", "Value": _fmt(p.peak_ami)},
            {"Dimension": "Predictability / peak horizon", "Value": str(p.peak_horizon)},
            {"Dimension": "Predictability / effective horizon", "Value": eff_h},
            {"Dimension": "Predictability / n horizons", "Value": str(p.n_horizons)},
        ]

        return pd.DataFrame(rows)

    @staticmethod
    def interpreted_summary(
        result: CharacterisationResult,
        config: CharacterisationConfig | None = None,
    ) -> pd.DataFrame:
        """Return a theory-grounded summary with an ``Interpretation`` column.

        Extends :meth:`summary` with a third column that explains what each
        metric value means, how it was derived, and what it implies for the
        modelling pipeline.  All interpretations are derived from
        ``result`` and ``config`` alone - no external globals are required.

        Args:
            result: A :class:`CharacterisationResult` produced by
                :meth:`analyse`.
            config: The :class:`CharacterisationConfig` used to produce
                ``result``.  Defaults to a fresh instance with all defaults
                when ``None``.

        Returns:
            ``pd.DataFrame`` with columns
            ``["Dimension", "Value", "Interpretation"]``.

        Example::

            result = SignalCharacteriser().analyse(df["net_load"])
            df = SignalCharacteriser.interpreted_summary(result)
        """
        cfg = config or CharacterisationConfig()
        base = SignalCharacteriser.summary(result)
        s = result.stationarity
        t = result.temporal
        p = result.predictability
        cp = {c.regime: c for c in result.complexity}
        spd = cfg.n_samples_per_day  # steps per day

        # ---- Stationarity verdict lookup ---------------------------------
        _stat_verdict_map = {
            "stationary": (
                "ADF and KPSS agree: level-stationary. AR features operate on raw values. "
                "No differencing step needed in DataPipeline."
            ),
            "non-stationary": (
                "Unit root present (ADF fails to reject). Apply first-differencing (d=1) "
                "before AR modelling to prevent spurious long-run correlations."
            ),
            "near-integrated": (
                "Borderline: near unit root but inconclusive. Consider first-differencing "
                "as a precaution and monitor the ACF of residuals for slow decay."
            ),
            "fractional": (
                "Tests disagree: ADF rejects the unit root but KPSS rejects stationarity. "
                "Classic signature of fractional integration (d in (0,1)). Apply d=1 as a "
                "conservative choice and inspect the ACF of the differenced series for "
                "residual slow decay."
            ),
        }

        interps: dict[str, str] = {
            "Target": "Series being characterised.",
            "Observations": (
                f"{result.n_observations:,} training observations. "
                "All Stage 1 diagnostics are computed on this split only."
            ),
            "Stationarity / verdict": _stat_verdict_map.get(s.verdict, "-"),
            "Stationarity / integration order (d)": (
                "d=0: operate on raw levels. AR features require no preprocessing."
                if s.integration_order == 0
                else (
                    f"d={s.integration_order}: apply {s.integration_order}-order differencing. "
                    "This value is returned by to_pipeline_hints() and can be passed directly "
                    "to TimeSeriesDifferentiator."
                )
            ),
            "Stationarity / ADF p-value": (
                f"p={s.adf_pvalue:.4f} < 0.05: rejects H\u2080 (unit root). "
                "Augmented Dickey-Fuller finds evidence of stationarity."
                if s.adf_pvalue < 0.05
                else (
                    f"p={s.adf_pvalue:.4f} \u2265 0.05: fails to reject H\u2080 (unit root). "
                    "Augmented Dickey-Fuller finds evidence of non-stationarity."
                )
            ),
            "Stationarity / KPSS p-value": (
                f"p={s.kpss_pvalue:.4f} > 0.05: fails to reject H\u2080 (stationary). "
                "KPSS is consistent with stationarity."
                if s.kpss_pvalue > 0.05
                else (
                    f"p={s.kpss_pvalue:.4f} \u2264 0.05: rejects H\u2080 (stationary). "
                    "KPSS detects a non-stationary trend."
                )
            ),
            "Stationarity / recommendation": ("Operational guidance derived from the joint ADF/KPSS verdict above."),
        }

        # ---- Complexity per regime ---------------------------------------
        for regime, profile in cp.items():
            n_obs = profile.n_observations
            pct = 100.0 * n_obs / result.n_observations
            label = "all training data" if regime == "full" else f"{pct:.1f}% of training data"
            pfx = f"Complexity / {regime}"
            interps[f"{pfx} / n_obs"] = f"{n_obs:,} observations in the {regime} regime ({label})."
            interps[f"{pfx} / sample entropy"] = _interp_sample_entropy(profile.sample_entropy, regime)
            interps[f"{pfx} / permutation entropy"] = _interp_perm_entropy(
                profile.permutation_entropy, profile.sample_entropy, regime
            )
            interps[f"{pfx} / Hurst exponent"] = _interp_hurst(profile.hurst_exponent)

        # ---- Temporal structure ------------------------------------------
        n_sig = len(t.significant_lags)
        interps.update(
            {
                "Temporal / AR order (p\u0302)": (
                    f"PACF cutoff at p\u0302={t.ar_order}. AR features should span at least "
                    f"{t.ar_order} steps. Used to anchor AutoregressTransformer lags."
                ),
                "Temporal / significant PACF lags": (
                    f"{n_sig} lags with significant partial autocorrelation. "
                    "Each contributes independent predictive information after partialling "
                    "out shorter lags."
                    if n_sig > 0
                    else "No significant PACF lags detected. AR features may add limited value."
                ),
                "Temporal / seasonal periods (steps)": (
                    f"Seasonal peaks at {t.seasonal_periods} steps. "
                    "Each motivates a sine/cosine feature pair in TemporalFeatureTransformer."
                    if t.seasonal_periods
                    else "No significant seasonal periods detected. Calendar encodings less critical."
                ),
                "Temporal / dominant period (steps)": (
                    f"Primary seasonal cycle at {t.dominant_period} steps "
                    f"({t.dominant_period / spd:.1f} days). "
                    "Highest-priority period for Fourier encoding."
                    if t.dominant_period
                    else "No dominant period identified."
                ),
                "Temporal / suggested DataPipeline lags": (
                    f"Calendar-aligned lags {t.suggested_lags} derived from detected seasonal "
                    "periods. Ready to pass as DataPipelineConfig(lags=...) and returned by "
                    "to_pipeline_hints()."
                    if t.suggested_lags
                    else "No calendar-aligned lags suggested. Fall back to AR order as the window size."
                ),
            }
        )

        # ---- Predictability (AMI) ----------------------------------------
        _pred_label_map = {
            "low": (
                "Low: AMI(h=1) is weak or rel_auc is very small. The series has little "
                "exploitable structure beyond very short horizons. Forecast accuracy will "
                "degrade quickly; consider a shorter forecast_horizon."
            ),
            "moderate": (
                "Moderate: meaningful predictive signal exists but decays noticeably across "
                "horizons. Standard forecast_horizon is viable; accuracy fades past the "
                "effective horizon."
            ),
            "high": (
                "High: strong, sustained AMI signal across horizons. Longer forecast windows "
                "remain data-driven; model capacity matters more than horizon length."
            ),
        }
        interps.update(
            {
                "Predictability / label": _pred_label_map[p.label],
                "Predictability / AMI(h=1)": (
                    f"AMI at h=1 = {p.ami_h1:.4f} nats. Level anchor for the profile. "
                    + (
                        "Strong 1-step signal (> 0.15 nats). "
                        if p.ami_h1 > 0.15
                        else "Weak 1-step signal (\u2264 0.15 nats). Series is close to unpredictable at h=1. "
                    )
                    + "Computed on first-differenced series to remove level persistence."
                ),
                "Predictability / mean AMI (AUC)": (
                    f"Mean AMI across all {p.n_horizons} horizons = {p.auc:.4f} nats. "
                    "Higher values indicate more sustained predictive structure throughout "
                    "the forecast window."
                ),
                "Predictability / rel_auc": (
                    f"rel_auc = mean_AMI / AMI(h=1) = {p.rel_auc:.4f}. "
                    + (
                        f"High (\u2265 {cfg.rel_auc_high}): signal decays slowly. "
                        "Wide forecast window is well-supported."
                        if p.rel_auc >= cfg.rel_auc_high
                        else (
                            f"Low (< {cfg.rel_auc_low}): signal collapses immediately after h=1. "
                            "Keep forecast_horizon short."
                            if p.rel_auc < cfg.rel_auc_low
                            else f"Moderate [{cfg.rel_auc_low}, {cfg.rel_auc_high}): "
                            "signal sustains for a few horizons then fades."
                        )
                    )
                ),
                "Predictability / peak AMI": (
                    f"Maximum AMI = {p.peak_ami:.4f} nats at horizon h={p.peak_horizon}. "
                    "This lag distance carries the most exploitable information about the future."
                ),
                "Predictability / peak horizon": (
                    f"AMI is maximised at h={p.peak_horizon} steps. "
                    "Can serve as an alternative anchor for the lookback window size."
                ),
                "Predictability / effective horizon": (
                    f"AMI drops below the noise floor ({cfg.ami_noise_floor * 100:.0f}% of "
                    f"AMI(h=1)) at h={p.effective_horizon}. Information beyond this point is "
                    "indistinguishable from noise. This is the data-driven upper bound for "
                    "forecast_horizon."
                    if p.effective_horizon is not None
                    else (
                        "AMI never decays to the noise floor within the computed range. "
                        "The series remains predictable across all tested horizons; "
                        "forecast_horizon is not constrained by this diagnostic."
                    )
                ),
                "Predictability / n horizons": (
                    f"{p.n_horizons} horizons computed "
                    f"(bounded by ami_max_horizons={cfg.ami_max_horizons}). "
                    "Increase this in CharacterisationConfig to extend the profile."
                ),
            }
        )

        base["Interpretation"] = base["Dimension"].map(lambda d: interps.get(d, "-"))
        return base

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_series(
        series: pd.DataFrame | pd.Series | np.ndarray,
        target_column: str,
    ) -> np.ndarray:
        """Convert to 1-D float ndarray and run basic sanity checks."""
        if isinstance(series, pd.DataFrame):
            if target_column not in series.columns:
                raise ValueError(
                    f"Column '{target_column}' not found in DataFrame. Available columns: {list(series.columns)}."
                )
            series = series[target_column]
        arr = np.asarray(series, dtype=float).squeeze()
        if arr.ndim != 1:
            raise ValueError(f"series must be 1-D; got shape {arr.shape} for '{target_column}'.")
        if len(arr) < _MIN_STATIONARITY_OBS:
            raise ValueError(
                f"series '{target_column}' has {len(arr)} observations; at least {_MIN_STATIONARITY_OBS} are required."
            )
        if not np.isfinite(arr).all():
            raise ValueError(
                f"series '{target_column}' contains NaN or infinite values. "
                "Remove or impute them before calling analyse()."
            )
        return arr

    def _assess_stationarity(self, arr: np.ndarray) -> StationarityResult:
        """Run joint ADF/KPSS testing and derive the integration order.

        Joint verdict rules (following Kwiatkowski et al. 1992):

        - ADF rejects H0 (stationary) **and** KPSS fails to reject H0
          (stationary) → *stationary*, d = 0.
        - ADF fails to reject H0 **and** KPSS rejects H0 (non-stationary)
          → *non-stationary*, d = 1.
        - Both fail to reject their respective H0 → *near-integrated*, d = 1.
        - Both reject their respective H0 → *fractional*, d = 1
          (conservative; practitioner should inspect further).
        """
        alpha = self.config.alpha

        try:
            adf_result = adf_test(arr)
            adf_stat = float(adf_result[0])
            adf_pval = float(adf_result[1])
        except Exception as exc:
            log.warning("ADF test failed: %s. Defaulting to non-stationary.", exc)
            adf_stat, adf_pval = np.nan, 1.0

        try:
            kpss_result = kpss_test(arr)
            kpss_stat = float(kpss_result[0])
            kpss_pval = float(kpss_result[1])
        except Exception as exc:
            log.warning("KPSS test failed: %s. Defaulting to non-stationary.", exc)
            kpss_stat, kpss_pval = np.nan, 0.0

        adf_stationary = adf_pval < alpha  # ADF rejects unit-root null
        kpss_stationary = kpss_pval >= alpha  # KPSS fails to reject stationarity null

        if adf_stationary and kpss_stationary:
            verdict: Literal["stationary", "non-stationary", "near-integrated", "fractional"] = "stationary"
            integration_order = 0
            recommendation = (
                "Both tests agree the series is stationary. Operate the autoregressive backbone on levels (d=0)."
            )
        elif not adf_stationary and not kpss_stationary:
            verdict = "non-stationary"
            integration_order = 1
            recommendation = (
                "Both tests agree the series is non-stationary. "
                "Apply first-differencing (d=1) before modelling to prevent spurious regression."
            )
        elif not adf_stationary and kpss_stationary:
            verdict = "near-integrated"
            integration_order = 1
            recommendation = (
                "Tests disagree: the series may be near-integrated or exhibit "
                "long memory. Apply first-differencing (d=1) as a conservative measure."
            )
        else:
            # adf_stationary and not kpss_stationary
            verdict = "fractional"
            integration_order = 1
            recommendation = (
                "Tests disagree: possible fractional integration. "
                "Apply first-differencing (d=1) and inspect ACF for slow decay."
            )

        log.info(
            "Stationarity verdict: %s (d=%d) | ADF p=%.4f, KPSS p=%.4f",
            verdict,
            integration_order,
            adf_pval,
            kpss_pval,
        )

        return StationarityResult(
            adf_statistic=adf_stat,
            adf_pvalue=float(np.clip(adf_pval, 0.0, 1.0)),
            kpss_statistic=kpss_stat,
            kpss_pvalue=float(np.clip(kpss_pval, 0.0, 1.0)),
            integration_order=integration_order,
            verdict=verdict,
            recommendation=recommendation,
        )

    def _detect_ramp_windows(self, arr: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Partition the series into stable and ramp-event boolean masks.

        A timestep is classified as a ramp event when the absolute first
        difference ``|Δy_t|`` exceeds the ``ramp_threshold_pct`` percentile
        of all non-zero absolute differences.  The masks are aligned to the
        original series length (the first element is always stable because
        there is no preceding step to difference).

        Returns:
            Tuple of ``(stable_mask, ramp_mask)``, both boolean arrays of
            the same length as ``arr``.
        """
        abs_diff = np.abs(np.diff(arr))
        threshold = np.percentile(abs_diff, self.config.ramp_threshold_pct)

        ramp_flags = abs_diff >= threshold
        # Prepend False for index 0 (no predecessor)
        ramp_flags = np.concatenate([[False], ramp_flags])

        ramp_mask = ramp_flags
        stable_mask = ~ramp_flags

        n_ramp = int(ramp_mask.sum())
        n_stable = int(stable_mask.sum())
        log.debug(
            "Ramp detection (pct=%.0f): %d ramp steps, %d stable steps.",
            self.config.ramp_threshold_pct,
            n_ramp,
            n_stable,
        )
        return stable_mask, ramp_mask

    def _compute_complexity(
        self,
        arr: np.ndarray,
        regime: str,
    ) -> ComplexityProfile:
        """Compute sample entropy, permutation entropy, and Hurst exponent.

        Returns ``np.nan`` for any metric when the regime window has fewer
        than :data:`_MIN_ENTROPY_OBS` observations, rather than raising.

        Args:
            arr: Regime-filtered 1-D float array.
            regime: One of ``"full"``, ``"stable"``, ``"ramp"``.

        Returns:
            :class:`ComplexityProfile` for the regime.
        """
        n = len(arr)

        if n < _MIN_ENTROPY_OBS:
            log.debug(
                "Complexity skipped for regime '%s': only %d observations (minimum %d). Metrics set to NaN.",
                regime,
                n,
                _MIN_ENTROPY_OBS,
            )
            return ComplexityProfile(
                regime=regime,  # type: ignore[arg-type]
                n_observations=n,
                sample_entropy=np.nan,
                permutation_entropy=np.nan,
                hurst_exponent=np.nan,
            )

        samp_ent = get_sample_entropy(arr)
        perm_ent = get_permutation_entropy(arr, normalize=True)
        hurst = get_hurst_exponent(arr)

        log.debug(
            "Complexity / %s (n=%d): SampEn=%.4f, PermEn=%.4f, Hurst=%.4f",
            regime,
            n,
            samp_ent,
            perm_ent,
            hurst,
        )

        return ComplexityProfile(
            regime=regime,  # type: ignore[arg-type]
            n_observations=n,
            sample_entropy=float(samp_ent),
            permutation_entropy=float(perm_ent),
            hurst_exponent=float(hurst),
        )

    def _analyse_temporal_structure(self, arr: np.ndarray) -> TemporalStructureResult:
        """Estimate AR order and dominant seasonal periods from ACF/PACF.

        **AR order** is the PACF cutoff lag (Box-Jenkins methodology) via
        :func:`~twiga.core.stats.autocorr.estimate_ar_order`.

        **Seasonal period detection** finds local maxima in the ACF that
        lie above the ``alpha``-level confidence band.  Peaks are ranked by
        ACF magnitude; the top ``max_seasonal_periods`` are returned.

        **Suggested lags** are produced by taking each detected seasonal
        period *P* and emitting ``[P, 2*P]`` (current cycle and one
        lookback).  Multiples are capped at 7 * n_samples_per_day (one
        week) to avoid unnecessarily large feature matrices.  The list is
        deduplicated and sorted.
        """
        n = len(arr)
        cfg = self.config

        if n < _MIN_TEMPORAL_OBS:
            log.warning(
                "Temporal analysis skipped: series too short (%d < %d).",
                n,
                _MIN_TEMPORAL_OBS,
            )
            return TemporalStructureResult(
                ar_order=0,
                significant_lags=[],
                seasonal_periods=[],
                dominant_period=None,
                suggested_lags=[],
            )

        # --- PACF: AR order ---
        max_pacf = cfg.max_lag_pacf or min(int(12 * (n / 100) ** 0.25), n // 3)
        max_pacf = max(1, max_pacf)

        try:
            significant_lags, ar_order = estimate_ar_order(arr, maxlag=max_pacf, alpha=cfg.alpha)
        except Exception as exc:
            log.warning("PACF analysis failed: %s. Defaulting ar_order=0.", exc)
            significant_lags, ar_order = [], 0

        # --- ACF: seasonal period detection ---
        try:
            acf_values, acf_confint = get_acf_values(
                arr,
                maxlag=cfg.max_lag_acf,
                alpha=cfg.alpha,
                seasonal_length=cfg.n_samples_per_day,
            )
            seasonal_periods, dominant_period = self._detect_acf_peaks(
                acf_values, acf_confint, cfg.max_seasonal_periods
            )
        except Exception as exc:
            log.warning("ACF analysis failed: %s. No seasonal periods detected.", exc)
            seasonal_periods, dominant_period = [], None

        # --- Suggested lags ---
        suggested_lags = self._build_suggested_lags(seasonal_periods, cfg.n_samples_per_day)

        log.info(
            "Temporal structure: AR order=%d, seasonal periods=%s, suggested lags=%s",
            ar_order,
            seasonal_periods,
            suggested_lags,
        )

        return TemporalStructureResult(
            ar_order=ar_order,
            significant_lags=[int(x) for x in significant_lags],
            seasonal_periods=[int(p) for p in seasonal_periods],
            dominant_period=int(dominant_period) if dominant_period is not None else None,
            suggested_lags=[int(x) for x in suggested_lags],
        )

    def _compute_predictability(self, arr: np.ndarray) -> PredictabilityResult:
        """Compute the AMI-based forecastability profile for the series.

        AMI is computed on first-differenced values via
        :func:`~twiga.core.stats.ami.get_ami_profile`.  First-differencing
        removes level persistence so that AMI reflects exploitable structure
        beyond the random-walk baseline.

        The two-stage classification rule is:

        1. ``AMI(h=1) < ami_h1_low`` → ``"low"`` (signal too weak at h = 1).
        2. ``rel_auc < rel_auc_low`` → ``"low"`` (signal collapses immediately).
        3. ``rel_auc >= rel_auc_high`` → ``"high"`` (signal is sustained).
        4. Otherwise → ``"moderate"``.

        A fallback :class:`PredictabilityResult` with ``label="low"`` and
        all metrics set to zero is returned when the differenced series is too
        short or when AMI computation raises an exception.

        Args:
            arr: 1-D float array of the full target series (levels, not
                differenced).  Differencing is applied internally.

        Returns:
            :class:`PredictabilityResult` with the full AMI forecastability
            profile.
        """
        cfg = self.config
        n_diff = len(arr) - 1  # length of the differenced series

        def _fallback(reason: str) -> PredictabilityResult:
            log.warning("AMI profiling skipped: %s.  Returning low-predictability fallback.", reason)
            return PredictabilityResult(
                ami_h1=0.0,
                auc=0.0,
                rel_auc=0.0,
                peak_ami=0.0,
                peak_horizon=1,
                effective_horizon=None,
                n_horizons=1,
                label="low",
            )

        if n_diff < _MIN_AMI_OBS:
            return _fallback(f"differenced series too short ({n_diff} < {_MIN_AMI_OBS})")

        try:
            horizons, ami_values = get_ami_profile(
                arr,
                n_neighbors=cfg.n_neighbors_ami,
                max_horizons=cfg.ami_max_horizons,
                random_state=42,
            )
        except Exception as exc:  # noqa: BLE001
            return _fallback(f"get_ami_profile raised {exc!r}")

        if len(ami_values) == 0:
            return _fallback("AMI profile returned empty arrays")

        ami_h1 = float(ami_values[0])
        auc = float(ami_values.mean())
        rel_auc = auc / ami_h1 if ami_h1 > 0.0 else 0.0
        peak_idx = int(ami_values.argmax())
        peak_ami = float(ami_values[peak_idx])
        peak_horizon = int(horizons[peak_idx])
        n_horizons = len(horizons)

        # Effective horizon: first h where AMI < noise_floor * ami_h1.
        if ami_h1 > 0.0:
            noise_threshold = cfg.ami_noise_floor * ami_h1
            below = np.where(ami_values < noise_threshold)[0]
            effective_horizon: int | None = int(horizons[below[0]]) if below.size > 0 else None
        else:
            effective_horizon = None

        # Two-stage classification.
        if ami_h1 < cfg.ami_h1_low:
            label: Literal["low", "moderate", "high"] = "low"
        elif rel_auc < cfg.rel_auc_low:
            label = "low"
        elif rel_auc >= cfg.rel_auc_high:
            label = "high"
        else:
            label = "moderate"

        log.info(
            "Predictability: label=%s, AMI(h=1)=%.4f, rel_auc=%.4f, peak=%.4f@h=%d, effective_h=%s.",
            label,
            ami_h1,
            rel_auc,
            peak_ami,
            peak_horizon,
            effective_horizon,
        )

        return PredictabilityResult(
            ami_h1=ami_h1,
            auc=auc,
            rel_auc=rel_auc,
            peak_ami=peak_ami,
            peak_horizon=peak_horizon,
            effective_horizon=effective_horizon,
            n_horizons=n_horizons,
            label=label,
        )

    # ------------------------------------------------------------------
    # Internal utilities
    # ------------------------------------------------------------------

    @staticmethod
    def _detect_acf_peaks(
        acf_values: np.ndarray,
        acf_confint: np.ndarray,
        max_peaks: int,
    ) -> tuple[list[int], int | None]:
        """Identify seasonal periods as significant local maxima in the ACF.

        A lag *L* is a candidate peak when:
        1. The ACF value lies above the upper confidence interval bound
           (i.e. it is statistically significant).
        2. It is a local maximum relative to its immediate neighbours.

        Candidates are ranked by ACF magnitude; the top ``max_peaks`` are
        returned as seasonal periods.

        Args:
            acf_values: ACF values excluding lag 0 (length ``maxlag``).
            acf_confint: Confidence interval bounds, shape
                ``(maxlag, 2)``, excluding lag 0.
            max_peaks: Maximum number of peaks to return.

        Returns:
            Tuple of ``(seasonal_periods, dominant_period)``.
            ``dominant_period`` is the lag with the highest ACF value
            among the detected peaks, or ``None`` if no peaks are found.
        """
        if len(acf_values) == 0:
            return [], None

        # statsmodels returns CI bounds *centred on the ACF estimate*, so
        # acf_confint[:, 0] is the lower bound of the CI for each lag.
        # A lag is significantly positive when its lower CI bound is above 0
        # (i.e., zero lies outside the confidence interval).
        significant = acf_confint[:, 0] > 0

        # Among significant lags, keep only local maxima.
        n = len(acf_values)
        peaks: list[tuple[int, float]] = []  # (lag_1indexed, acf_value)

        for i in range(n):
            if not significant[i]:
                continue
            left = acf_values[i - 1] if i > 0 else -np.inf
            right = acf_values[i + 1] if i < n - 1 else -np.inf
            if acf_values[i] >= left and acf_values[i] >= right:
                # Lags in get_acf_values are 1-indexed (lag 0 removed)
                peaks.append((i + 1, float(acf_values[i])))

        if not peaks:
            return [], None

        # Rank by ACF magnitude, descending.
        peaks.sort(key=lambda x: x[1], reverse=True)
        top_peaks = peaks[:max_peaks]
        seasonal_periods = sorted(p[0] for p in top_peaks)
        dominant_period = max(top_peaks, key=lambda x: x[1])[0]

        return seasonal_periods, dominant_period

    @staticmethod
    def _build_suggested_lags(
        seasonal_periods: list[int],
        n_samples_per_day: int,
    ) -> list[int]:
        """Derive calendar-aligned lag multiples from detected seasonal periods.

        For each detected period *P*, emits ``P`` and ``7 * P / dominant_period``
        to capture the current-cycle and one-week lookback without blindly
        multiplying every period.  The weekly cap is ``7 * n_samples_per_day``.

        In the common case of a daily period (``P == n_samples_per_day``),
        this yields ``[P, 7*P]``, i.e. same-day-lag and same-weekday-lag.

        Args:
            seasonal_periods: Sorted list of detected seasonal periods in steps.
            n_samples_per_day: Observations per calendar day.

        Returns:
            Deduplicated, sorted list of suggested lag values.
        """
        weekly_cap = 7 * n_samples_per_day
        lag_set: set[int] = set()

        for period in seasonal_periods:
            lag_set.add(period)
            weekly_equiv = period * 7
            if weekly_equiv <= weekly_cap:
                lag_set.add(weekly_equiv)
            else:
                lag_set.add(weekly_cap)

        # Always include a short-range lag (half-day) when any period is
        # detected, to capture intra-day autocorrelation.
        if seasonal_periods:
            half_day = n_samples_per_day // 2
            if half_day > 0:
                lag_set.add(half_day)

        return sorted(lag_set)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _fmt(value: float) -> str:
    """Format a float metric for display; renders NaN as 'n/a'."""
    if np.isnan(value):
        return "n/a"
    return f"{value:.4f}"


def _interp_sample_entropy(se: float, regime: str) -> str:
    """Interpret a sample entropy value for a given operating regime.

    Sample entropy (Richman & Moorman, 2000) measures template-match
    regularity in amplitude.  Lower values indicate more regular, recurring
    patterns; higher values indicate complexity/irregularity.  The thresholds
    used here are heuristic defaults calibrated for power-system time series;
    they depend on the embedding dimension (m) and tolerance (r) used during
    computation.

    Args:
        se: Sample entropy value.
        regime: Operating regime label (e.g. ``"full"``, ``"stable"``,
            ``"ramp"``).

    Returns:
        Human-readable interpretation string.
    """
    if np.isnan(se):
        return f"SampEn=n/a in the {regime} regime (insufficient observations)."
    if se < 0.5:
        return (
            f"SampEn={se:.3f} (low). Regular, recurring amplitude patterns dominate "
            f"the {regime} regime. Standard AR features are likely sufficient."
        )
    if se < 1.5:
        return (
            f"SampEn={se:.3f} (moderate). Mix of structure and noise in the {regime} regime. "
            "Non-linear features may add value."
        )
    return (
        f"SampEn={se:.3f} (high). Complex, irregular amplitude dynamics in the {regime} regime. "
        "Non-linear exogenous features are recommended."
    )


def _interp_perm_entropy(pe: float, se: float, regime: str) -> str:
    """Interpret a permutation entropy value for a given operating regime.

    Permutation entropy (Bandt & Pompe, 2002) measures ordinal pattern
    diversity in the direction (up/down) of successive values.  Values near
    1.0 mean ordinal patterns are close to uniformly distributed.

    The SampEn vs PermEn contrast is diagnostically important: low SampEn
    with high PermEn signals bounded amplitude (regular magnitude) but
    complex directional dynamics.

    Args:
        pe: Normalised permutation entropy value in [0, 1].
        se: Sample entropy of the same regime (used for the contrast note).
        regime: Operating regime label.

    Returns:
        Human-readable interpretation string.
    """
    if np.isnan(pe):
        return f"PermEn=n/a in the {regime} regime (insufficient observations)."
    if pe < 0.5:
        return (
            f"PermEn={pe:.3f} (low). Strong ordinal structure: up/down transitions "
            f"in the {regime} regime follow predictable patterns."
        )
    if pe < 0.8:
        return f"PermEn={pe:.3f} (moderate). Mixed ordinal diversity in the {regime} regime."
    contrast = (
        " Note: low SampEn + high PermEn indicates bounded amplitude but complex "
        "directional dynamics - the series stays within a range but its up/down "
        "transitions are hard to predict."
        if (not np.isnan(se) and se < 0.5)
        else ""
    )
    return (
        f"PermEn={pe:.3f} (high, near 1.0). Ordinal patterns approach uniform "
        f"distribution in the {regime} regime. Complex state-space transitions." + contrast
    )


def _interp_hurst(h: float) -> str:
    """Interpret a Hurst exponent value.

    The Hurst exponent (Hurst, 1951) characterises long-range memory:

    - H < 0.5: anti-persistent (mean-reverting)
    - H = 0.5: random walk (no memory)
    - H > 0.5: persistent (long-range positive autocorrelation)

    Args:
        h: Hurst exponent estimate.

    Returns:
        Human-readable interpretation string with AR window guidance.
    """
    if np.isnan(h):
        return "H=n/a (insufficient observations for Hurst estimation)."
    if h < 0.4:
        return (
            f"H={h:.3f} (anti-persistent). Shocks dissipate rapidly. "
            "Short-lag AR features preferred; long windows add noise."
        )
    if h < 0.5:
        return f"H={h:.3f} (mildly mean-reverting). Near random walk. Moderate AR window; avoid very long lookbacks."
    if h < 0.65:
        return (
            f"H={h:.3f} (mild persistence). Standard AR window is well-calibrated. "
            "Long-range memory is present but modest."
        )
    return (
        f"H={h:.3f} (strong long-range memory). Shocks persist across many steps. "
        "Longer lookback windows and rolling statistics are beneficial."
    )
