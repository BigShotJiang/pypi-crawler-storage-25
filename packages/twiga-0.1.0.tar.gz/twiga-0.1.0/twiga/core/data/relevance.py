"""Unified Relevance and Association Analysis Module."""

from typing import Any, Literal

import numpy as np
import pandas as pd

from twiga.core.stats.association import compute_anova_f, compute_chi2, rank_correlation
from twiga.core.stats.mutual_information import compute_mutual_information
from twiga.core.stats.ppscore import compute_ppscore
from twiga.core.stats.xicorr import compute_xicorr
from twiga.core.utils.logger import get_logger

log = get_logger(__name__)


class AssociationAnalyzer:
    """A unified interface for calculating and visualizing feature associations."""

    def __init__(self, method="spearman", task="regression", **kwargs):
        self.method = method
        self.task = task

    @staticmethod
    def compute(
        data: pd.DataFrame,
        target_col: str,
        variable_cols: list[str],
        method: Literal["pearson", "spearman", "kendall", "xicor", "pps", "mi", "anova", "chi2"] = "spearman",
        task: Literal["regression", "classification"] = "regression",
        **kwargs: Any,
    ) -> pd.DataFrame:
        """Calculate association between target and features using the chosen method.

        Args:
            data: Input DataFrame.
            target_col: The dependent variable.
            variable_cols: List of independent variables.
            method: The statistical method to use.
            task: Task type (regression/classification) for PPS, MI, and ANOVA.
            **kwargs: Method-specific args:
                - pps: sample, cross_validation, random_seed
                - xicor: ties
                - mi: random_state, n_neighbors
                - rank: N/A (standard pandas implementation)

        Returns:
            DataFrame with columns ['target', 'feature', 'score'] and optionally ['p_value'].
        """
        method_lower = method.lower()
        log.debug("Computing association using method: %s", method_lower)

        # 1. Rank Correlations
        if method_lower in ["pearson", "spearman", "kendall"]:
            df = rank_correlation(data, target_col, variable_cols, method=method)
            return df.rename(columns={"correlation": "score"})

        # 2. Xi Correlation
        if method_lower == "xicor":
            df = compute_xicorr(data, target_col, variable_cols, ties=kwargs.get("ties", "auto"))
            return df.rename(columns={"col1": "target", "col2": "feature", "xicor": "score"})

        # 3. PPS (Predictive Power Score)
        if method_lower == "pps":
            results = []
            for col in variable_cols:
                res = compute_ppscore(
                    data,
                    x=col,
                    y=target_col,
                    sample=kwargs.get("sample", 5000),
                    cross_validation=kwargs.get("cross_validation", 4),
                    random_seed=kwargs.get("random_seed", 123),
                )
                results.append(res)

            df = pd.DataFrame(results).sort_values("ppscore", ascending=False)
            return df.rename(columns={"x": "feature", "y": "target", "ppscore": "score"})[
                ["target", "feature", "score"]
            ]

        # 4. Mutual Information
        if method_lower == "mi":
            return compute_mutual_information(
                data,
                target_col,
                variable_cols,
                task=task,
                random_state=kwargs.get("random_state", 200),
                pivot=False,
            )

        # 5. ANOVA F-Score (Merged with p-values)
        if method_lower == "anova":
            f_df, p_df = compute_anova_f(data, target_col, variable_cols, task=task, pivot=False)
            # Merge to ensure p_value stays aligned with the correct feature
            df = f_df.merge(p_df, on=["target", "feature"])
            return df.rename(columns={"f_score": "score"})

        # 6. Chi-Square
        if method_lower == "chi2":
            return compute_chi2(data, target_col, variable_cols, pivot=False).rename(columns={"chi2_score": "score"})

        raise ValueError(f"Unsupported method: {method}")

    @staticmethod
    def plot_heatmap(
        assoc_df: pd.DataFrame,
        score_col: str = "score",
        target_col_name: str = "target",
        feature_col_name: str = "feature",
    ):
        """Visualize association results using a heatmap.

        Args:
            assoc_df: DataFrame returned by .compute().
            score_col: Column name to use for the heatmap values.
            target_col_name: Name of the column representing the Y axis (target).
            feature_col_name: Name of the column representing the X axis (feature).
        """
        if assoc_df.empty:
            log.warning("Attempted to plot an empty association DataFrame.")
            return None

        plot_df = assoc_df.copy()

        # Mapping internal standard names to plotter-expected names
        rename_map = {score_col: "correlation", feature_col_name: "col1", target_col_name: "col2"}

        # Only rename if the columns actually exist in the provided dataframe
        plot_df = plot_df.rename(columns={k: v for k, v in rename_map.items() if k in plot_df.columns})

        from twiga.core.plot import correlation_heatmap  # lazy: requires plots extra

        return correlation_heatmap(plot_df)
