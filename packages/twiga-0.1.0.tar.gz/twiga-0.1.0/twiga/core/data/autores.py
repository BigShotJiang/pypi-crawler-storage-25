import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.utils.validation import check_is_fitted

from .processing import augment_lags, augment_rolling


class AutoregressTransformer(TransformerMixin, BaseEstimator):
    """A transformer for adding autoregressive features to time series data.

    Applies lagged features and optionally rolling statistics to a specified value column
    using the pytimetk library.

    Args:
        n_samples (int): Number of samples per period (e.g., 24 for hourly data in a day).
            Must be positive. Default is 1.
        lags (list[int] | int | None): Lag intervals to create. Converted to list if int.
            Must be positive integers. Default is None.
        windows (list[int] | int | None): Window sizes for rolling statistics.
            Converted to list if int. Must be positive integers. Default is None.
        window_funcs (list[str] | str | None): Functions for rolling stats (e.g., 'mean', 'sum').
            Converted to list if str. Default is None.
        date_column (str): Name of the datetime column in the input data. Default is 'timestamp'.
        value_column (str): Name of the column to apply transformations to. Default is 'value'.

    Attributes:
        lags (list[int]): Normalized list of lag intervals.
        windows (list[int]): Normalized list of window sizes.
        window_funcs (list[str]): Normalized list of window functions.
        n_samples (int): Number of samples per period.
        max_data_drop (int): Maximum number of rows dropped due to lagging or rolling.

    Raises:
        ValueError: If n_samples, lags, or windows are not positive, or if parameters are invalid.
    """

    def __init__(
        self,
        n_samples: int = 1,
        lags: list[int] | int | None = None,
        windows: list[int] | int | None = None,
        window_funcs: list[str] | str | None = None,
        date_column: str = "timestamp",
        value_column: str = "value",
    ):
        self.n_samples = n_samples
        self.lags = lags
        self.windows = windows
        self.window_funcs = window_funcs
        self.date_column = date_column
        self.value_column = value_column
        self.max_data_drop = 0

        # Normalize and validate parameters
        self._validate_params()
        self._is_fitted = False

    def _validate_params(self):
        """Validate and normalize initialization parameters."""
        if not isinstance(self.n_samples, int) or self.n_samples <= 0:
            raise ValueError(f"n_samples must be a positive integer, got: {self.n_samples}")

        # Normalize lags
        if self.lags is not None:
            if isinstance(self.lags, int):
                self.lags = [self.lags]
            if not isinstance(self.lags, list) or not all(isinstance(lag, int) and lag > 0 for lag in self.lags):
                raise ValueError(f"lags must be a positive integer or list of positive integers, got: {self.lags}")

        # Normalize windows
        if self.windows is not None:
            if isinstance(self.windows, int):
                self.windows = [self.windows]
            if not isinstance(self.windows, list) or not all(isinstance(w, int) and w > 0 for w in self.windows):
                raise ValueError(
                    f"windows must be a positive integer or list of positive integers, got: {self.windows}",
                )

        # Normalize window_funcs
        if self.window_funcs is not None:
            if isinstance(self.window_funcs, str):
                self.window_funcs = [self.window_funcs]
            if not isinstance(self.window_funcs, list) or not all(isinstance(f, str) for f in self.window_funcs):
                raise ValueError(f"window_funcs must be a string or list of strings, got: {self.window_funcs}")

        # Compute max_data_drop deterministically from params (no data needed)
        _max = 0
        if self.lags:
            _max = max(_max, max(int(lag * self.n_samples) for lag in self.lags))
        if self.windows:
            _max = max(_max, max(int(w * self.n_samples) for w in self.windows))
        self.max_data_drop = _max

    def fit(self, X: pd.DataFrame, y=None):
        """Fit the transformer. Validates input data and returns self.

        Args:
            X (pd.DataFrame): Input data with date_column and value_column.
            y (None): Ignored, for sklearn compatibility.

        Returns:
            self: Fitted transformer.

        Raises:
            ValueError: If required columns are missing from X.
        """
        if not isinstance(X, pd.DataFrame):
            raise TypeError("X must be a pandas DataFrame")
        if self.date_column not in X.columns:
            raise ValueError(f"date_column '{self.date_column}' not found in X")
        if self.value_column not in X.columns:
            raise ValueError(f"value_column '{self.value_column}' not found in X")
        self.is_fitted_ = True
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transform the input data by adding lagged and rolling features.

        Args:
            X (pd.DataFrame): Input data with date_column and value_column.

        Returns:
            pd.DataFrame: Transformed data with added features.

        Raises:
            ValueError: If X is invalid or transformation fails.
        """
        check_is_fitted(self, "is_fitted_")
        if not isinstance(X, pd.DataFrame):
            raise TypeError("X must be a pandas DataFrame")

        result = X.copy()

        # Apply lags if specified
        if self.lags:
            lags_scaled = [int(lag * self.n_samples) for lag in sorted(self.lags)]  # type: ignore[arg-type]
            self.max_data_drop = max(self.max_data_drop, max(lags_scaled))
            result = augment_lags(
                data=result,
                date_column=self.date_column,
                value_column=self.value_column,
                lags=lags_scaled,
            )

        # Apply rolling statistics if specified
        if self.windows and self.window_funcs:
            windows_scaled = [int(w * self.n_samples) for w in sorted(self.windows)]  # type: ignore[arg-type]
            self.max_data_drop = max(self.max_data_drop, max(windows_scaled))
            result = augment_rolling(
                data=result,
                date_column=self.date_column,
                value_column=self.value_column,
                window=windows_scaled,
                window_func=self.window_funcs,  # type: ignore[arg-type]
                min_periods=1,  # Avoid NaNs for small windows
            )

        return result.iloc[self.max_data_drop :]

    def get_generated_column_names(self) -> list[str]:
        """Return the column names that :meth:`transform` will add, without needing data.

        The names are derived deterministically from the constructor parameters
        and the ``n_samples`` period multiplier, so they are available as soon
        as the transformer is instantiated.

        Returns:
            List of new column names in the order they are added: lags first
            (ascending), then rolling features (ascending window × func order).
        """
        value_col = self.value_column if isinstance(self.value_column, str) else self.value_column[0]
        names: list[str] = []

        if self.lags:
            for lag in sorted(self.lags):  # type: ignore[arg-type]
                names.append(f"{value_col}_lag_{int(lag * self.n_samples)}")

        if self.windows and self.window_funcs:
            for w in sorted(self.windows):  # type: ignore[arg-type]
                for func in self.window_funcs:
                    if isinstance(func, tuple):
                        fname = func[0]
                    elif func == "quantile":
                        fname = "quantile_50"
                    else:
                        fname = func
                    names.append(f"{value_col}_rolling_{fname}_win_{int(w * self.n_samples)}")

        return names

    def fit_transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        """Fits the transformer to the data and transforms it."""
        return self.fit(X, y).transform(X)
