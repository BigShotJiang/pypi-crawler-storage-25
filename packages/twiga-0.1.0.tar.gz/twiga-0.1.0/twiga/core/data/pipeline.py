import re

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin, clone
from sklearn.compose import ColumnTransformer
from sklearn.exceptions import NotFittedError
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer
from sklearn.utils.validation import check_is_fitted

from twiga.core.data.autores import AutoregressTransformer
from twiga.core.data.processing import (
    _validate_target_feature,
    get_feature_sequences,
    get_n_sample_per_day,
    get_target_sequences,
    stack_features,
)
from twiga.core.data.temporal import TemporalFeatureTransformer
from twiga.core.utils.logger import get_logger

log = get_logger(__name__)


class DataPipeline(TransformerMixin, BaseEstimator):
    """A transformer for preparing time series forecasting datasets.

    Handles feature engineering, scaling, and temporal structure creation for forecasting
    models. Supports lagged features, rolling statistics, temporal features (e.g., hour,
    day/night), and Fourier transformations for cyclical patterns.

    Attributes:
        target_feature (list[str]): Names of target variable(s) to forecast.
        historical_features (list[str]): Historical features with unknown future values.
        calendar_features (list[str]): Cyclical temporal features (e.g., hour, day_of_week).
        exogenous_features (list[str]): Known future features available over the full horizon.
        future_covariates (list[str]): Known future features available over forecast horizon only.
        input_scaler (Transformer): Feature scaler for input features (default: FunctionTransformer).
        target_scaler (Transformer): Feature scaler for target(s) (default: FunctionTransformer).
        lags (list[int]): Lag intervals for feature engineering.
        windows (list[int]): Window sizes for rolling statistics.
        window_funcs (list[str]): Functions for rolling window calculations (e.g., 'mean').
        period (str): Time series split frequency (e.g., '30min', '1H').
        lookback_window_size (int): Number of past observations per sample.
        forecast_horizon (int): Number of future steps to predict.
        latitude (float): Latitude for day/night feature calculation.
        longitude (float): Longitude for day/night feature calculation.
        date_column (str): Name of datetime column (default: 'timestamp').
        n_samples (int): Samples per day calculated from period.
        max_data_drop (int): Maximum data loss from feature engineering steps.
        exog_periods (list[int]): Cycle lengths for calendar features.
        data_pipeline (Pipeline): Built preprocessing pipeline.
        data (pd.DataFrame): Transformed data stored for extraction methods.
    """

    def __init__(
        self,
        target_feature: list[str] | str,
        period: str,
        lookback_window_size: int,
        forecast_horizon: int,
        latitude: float | None = None,
        longitude: float | None = None,
        historical_features: list[str] | None = None,
        calendar_features: list[str] | None = None,
        exogenous_features: list[str] | None = None,
        future_covariates: list[str] | None = None,
        input_scaler: object | None = None,
        target_scaler: object | None = None,
        lags: list[int] | None = None,
        windows: list[int] | int | None = None,
        window_funcs: list[str] | str | None = None,
        date_column: str = "timestamp",
        stride: int = 1,
    ):
        """Initializes the DataPipeline transformer with data preparation parameters."""
        # Parameter validation and conversion
        self.target_feature = _validate_target_feature(target_feature)
        self._validate_period(period)
        self.period = period
        if lookback_window_size <= 0:
            raise ValueError("lookback_window_size must be positive")
        if forecast_horizon <= 0:
            raise ValueError("forecast_horizon must be positive")

        self.latitude = latitude
        self.longitude = longitude
        self.lookback_window_size = lookback_window_size
        self.forecast_horizon = forecast_horizon
        # Store user-specified historical features separately so repeated
        # fit() calls don't accumulate auto-generated lag/window column names.
        self._user_historical_features: list[str] = list(historical_features or [])
        self.historical_features: list[str] = list(self._user_historical_features)
        self.calendar_features = calendar_features or []
        self.exogenous_features = exogenous_features or []
        self.future_covariates = future_covariates or []
        self.input_scaler = input_scaler or FunctionTransformer()
        self.target_scaler = target_scaler or FunctionTransformer()
        self.lags = lags or []
        self.windows = [windows] if isinstance(windows, int) else (windows or [])
        self.window_funcs = [window_funcs] if isinstance(window_funcs, str) else (window_funcs or [])
        self.date_column = date_column
        self.stride = stride
        self.n_samples = get_n_sample_per_day(self.period)
        self.max_data_drop = 0
        self.exog_periods = None
        self.data_pipeline = None
        self._is_fitted = False
        self.data = None
        # Column names generated by AutoregressTransformer (populated at fit time)
        self._lag_feature_cols: list[str] = []
        self.set_feature_covariate_column()

    def set_feature_covariate_column(self):
        """Sets feature and covariate column lists."""
        self.feature_columns = (
            self.target_feature + self.historical_features + self.exogenous_features + self.calendar_features
        )
        self.covariate_columns = self.exogenous_features + self.calendar_features + self.future_covariates

    def _validate_period(self, period):
        """Validates the period parameter."""
        _alias_map = {"H": "h", "T": "min"}
        period_pattern = r"^\d+[a-zA-Z]+$"
        if not isinstance(period, str) or not re.match(period_pattern, period):
            raise ValueError(
                f"Period must be a string in the format '<number><unit>' (e.g., '30min', '1h'), got: {period}",
            )
        unit_match = re.search(r"[a-zA-Z]+$", period)
        normalised = (
            period
            if not unit_match
            else (period[: -len(unit_match.group())] + _alias_map.get(unit_match.group(), unit_match.group()))
        )
        if not pd.tseries.frequencies.to_offset(normalised):
            raise ValueError(f"Invalid period: {period}")

    def _build_pipeline(self) -> Pipeline:
        """Builds the preprocessing and scaling pipeline."""
        steps = []
        feature_pipeline = self._build_feature_pipeline()
        if feature_pipeline:
            steps.append(("feature_extraction", feature_pipeline))
        steps.append(("scaling", self._build_scaling_pipeline()))
        return Pipeline(steps=steps)

    def _build_feature_pipeline(self) -> Pipeline:
        """Constructs the feature extraction pipeline.

        As a side-effect, populates :attr:`_lag_feature_cols` with the column
        names that :class:`AutoregressTransformer` will add, and merges them
        into :attr:`historical_features` so they are picked up by
        :meth:`_extract_features` and the scaling pipeline.
        """
        # Reset to the user-specified list so repeated fit() calls don't
        # accumulate generated names.
        self.historical_features = list(self._user_historical_features)
        self._lag_feature_cols = []

        feature_steps = []
        if self.calendar_features:
            self.temporal_feature_transformer = TemporalFeatureTransformer(
                calendar_features=self.calendar_features,
                latitude=self.latitude,
                longitude=self.longitude,
                date_column=self.date_column,
            )
            feature_steps.append(("temporal_features", self.temporal_feature_transformer))
        if self.lags or self.windows:
            self.autoregress_transformer = AutoregressTransformer(
                n_samples=self.n_samples,
                lags=self.lags,
                windows=self.windows,
                window_funcs=self.window_funcs,
                date_column=self.date_column,
                value_column=self.target_feature[0] if len(self.target_feature) == 1 else self.target_feature,  # type: ignore[arg-type]
            )
            feature_steps.append(("autoregress", self.autoregress_transformer))
            self.max_data_drop = self.autoregress_transformer.max_data_drop

            # Auto-register generated lag/window column names so that
            # _extract_features() and the scaling pipeline see them without
            # requiring the user to list them manually in historical_features.
            generated = self.autoregress_transformer.get_generated_column_names()
            existing = set(self.historical_features)
            new_cols = [c for c in generated if c not in existing]
            if new_cols:
                self._lag_feature_cols = new_cols
                self.historical_features = self.historical_features + new_cols
                self.set_feature_covariate_column()

        return Pipeline(steps=feature_steps) if feature_steps else None

    def _build_scaling_pipeline(self) -> ColumnTransformer:
        """Constructs a column-wise scaling transformer.

        Lag and rolling-window columns are scaled with a clone of
        ``target_scaler`` (same class and parameters, fitted independently on
        those columns) because they contain lagged values of the target and
        should be in the same normalized space.  User-specified
        ``historical_features`` and ``exogenous_features`` are scaled with
        ``input_scaler`` as before.
        """
        transformers = [("target_scaling", self.target_scaler, self.target_feature)]

        # Lag/window columns: clone target_scaler so they share the same
        # normalization family without interfering with the target fit.
        if self._lag_feature_cols:
            transformers.append(("lag_scaling", clone(self.target_scaler), self._lag_feature_cols))

        # User-specified historical features and exogenous features.
        lag_set = set(self._lag_feature_cols)
        non_lag_historical = [f for f in self.historical_features if f not in lag_set]
        numerical_features = non_lag_historical + self.exogenous_features
        if numerical_features:
            transformers.append(("numerical_scaling", self.input_scaler, numerical_features))

        scaling_transformer = ColumnTransformer(
            transformers=transformers,
            remainder="passthrough",
            verbose_feature_names_out=False,
            n_jobs=-1,
        )
        scaling_transformer.set_output(transform="pandas")
        return scaling_transformer

    def fit(self, data: pd.DataFrame, y=None):
        """Fits the data pipeline to the provided time series data."""
        self.data_pipeline = self._build_pipeline()
        try:
            self.data_pipeline.fit(data)  # type: ignore[attr-defined]
            self._is_fitted = True
        except Exception as e:
            self._is_fitted = False
            raise RuntimeError(f"Fitting failed: {e!s}") from e
        return self

    def prepare_data(self, data: pd.DataFrame) -> None:
        """Prepares the data by applying the pipeline and sorting."""
        # Check if pipeline is fitted (using check_is_fitted)
        if not self._is_fitted or self.data_pipeline is None:
            raise NotFittedError("DataPipeline is not initialized. Call fit() first.")
        try:
            # Check pipeline and components
            check_is_fitted(self.data_pipeline)

        except NotFittedError as err:
            raise NotFittedError("DataPipeline is not fitted. Call fit() first.") from err

        data_transformed = self.data_pipeline.transform(data)
        self.data = data_transformed.sort_values(by=self.date_column)

    def _extract_features(self, data_transformed: pd.DataFrame) -> np.ndarray:
        """Extracts features from the transformed data."""
        features = data_transformed[self.feature_columns].values.astype(np.float64)
        if len(features) == 0:
            raise ValueError("Ensure you have at least one historical feature to train the model.")
        return get_feature_sequences(
            features,
            lookback_window_size=self.lookback_window_size,
            forecast_horizon=self.forecast_horizon,
            stride=self.stride,
        )

    def _extract_targets(self, data_transformed: pd.DataFrame) -> np.ndarray:
        """Extracts targets from the transformed data."""
        targets = data_transformed[self.target_feature].values.astype(np.float64)
        return get_target_sequences(
            targets,
            lookback_window_size=self.lookback_window_size,
            forecast_horizon=self.forecast_horizon,
            stride=self.stride,
        )

    def _extract_future_exogenous(self, data_transformed: pd.DataFrame) -> np.ndarray | None:
        """Extracts future exogenous features from the transformed data."""
        future_exogenous = data_transformed[self.covariate_columns].values.astype(np.float64)
        if len(future_exogenous) == 0 or future_exogenous.shape[1] == 0:
            return None
        return get_target_sequences(
            future_exogenous,
            lookback_window_size=self.lookback_window_size,
            forecast_horizon=self.forecast_horizon,
            stride=self.stride,
        )

    def get_ground_truth_sequences(self, data: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        """Extract ground truth sequences aligned with the feature extraction window.

        This is the **pure data extraction** method: it applies the same
        preparation steps as :meth:`transform_features` so that the returned
        timestamps and targets have the same first dimension as the feature
        arrays, but it does **not** load or modify any model checkpoint.

        Prefer this method when checkpoint side effects are undesirable - for
        example inside :meth:`~twiga.forecaster.abstract.AbstractForecaster.forecast`.
        For evaluation workflows that also need the checkpoint restored, use
        :meth:`~twiga.forecaster.base.BaseForecaster.get_ground_truth` instead.

        Args:
            data: DataFrame containing the raw input data including the date
                column and target feature(s).

        Returns:
            Tuple of:
                - timestamps: Integer (nanosecond) timestamp array aligned
                  with the prediction sequences.
                - targets: Scaled target sequences of shape
                  ``(num_sequences, forecast_horizon, num_targets)``.
        """
        self.prepare_data(data)
        targets = self._extract_targets(self.data)

        # Get timestamps from prepared data
        try:
            timestamps = self.data[self.date_column].sort_values()
            timestamps = timestamps.astype("int64").values.reshape(-1, 1)
        except Exception:
            log.exception("Error converting date column to numeric")
            raise

        timestamps = get_target_sequences(
            timestamps,
            lookback_window_size=self.lookback_window_size,
            forecast_horizon=self.forecast_horizon,
            stride=self.stride,
        )
        return timestamps, targets

    def transform_features(self, data: pd.DataFrame) -> np.ndarray:
        """Transforms the data into features for forecasting or prediction."""
        self.prepare_data(data)
        features = self._extract_features(self.data)
        future_exogenous = self._extract_future_exogenous(self.data)
        return stack_features(features, future_exogenous)

    def transform_targets(self, data: pd.DataFrame) -> np.ndarray:
        """Transforms the data into targets for forecasting."""
        self.prepare_data(data)
        return self._extract_targets(self.data)

    def transform(self, data: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        """Transforms the data into features and targets for forecasting."""
        self.prepare_data(data)
        features = self._extract_features(self.data)
        future_exogenous = self._extract_future_exogenous(self.data)
        features = stack_features(features, future_exogenous)
        targets = self._extract_targets(self.data)
        return features, targets

    def fit_transform(self, X: pd.DataFrame, y=None) -> tuple[np.ndarray, np.ndarray]:
        """Fits the transformer to the data and transforms it."""
        return self.fit(X, y).transform(X)

    def __sklearn_is_fitted__(self):
        """Hook for sklearn's estimator validation."""
        return self._is_fitted

    def _more_tags(self):
        """Metadata for sklearn compatibility."""
        return {"requires_fit": True, "allow_nan": False, "multioutput": True}
