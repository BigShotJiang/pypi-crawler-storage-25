from collections.abc import Callable
import contextlib
from functools import partial
import inspect
from itertools import product
import multiprocessing
import re
from typing import Any

import numpy as np
import pandas as pd
import tqdm

from twiga.core.utils.logger import get_logger

log = get_logger(__name__)


def normalise_timestamp_column(df: pd.DataFrame, col: str) -> pd.DataFrame:
    """Normalise a timestamp column to tz-naive ``datetime64[ns]``.

    This is the single canonical entry point for datetime normalisation across
    the library.  It accepts any of the three forms a timestamp column can
    arrive in and always returns the same shape so that all downstream
    transformers can assume tz-naive data:

    * **tz-naive** ``datetime64[ns]`` - returned unchanged (fast path).
    * **tz-aware** ``DatetimeTZDtype`` (e.g. UTC from ``pd.to_datetime(...,
      utc=True)``) - converted to UTC wall-clock time then timezone info is
      dropped.
    * **object / string** - parsed with ``utc=True`` so that any embedded
      timezone offset is honoured, then timezone info is dropped.

    Args:
        df: Input DataFrame.  A copy is returned only when the column is
            modified; the original is returned unchanged for the fast path.
        col: Name of the timestamp column.

    Returns:
        DataFrame with *col* as tz-naive ``datetime64[ns]``.

    Raises:
        KeyError: If *col* is not present in *df*.
        ValueError: If the column cannot be parsed as datetime.
    """
    if col not in df.columns:
        raise KeyError(f"Timestamp column '{col}' not found in DataFrame.")

    s = df[col]
    dtype = s.dtype

    if isinstance(dtype, pd.DatetimeTZDtype):
        # tz-aware → convert to UTC wall-clock time → drop tz info
        df = df.copy()
        df[col] = s.dt.tz_convert("UTC").dt.tz_localize(None)
    elif hasattr(dtype, "kind") and dtype.kind == "M":
        # Already tz-naive datetime64 - nothing to do
        pass
    else:
        # object dtype (strings or Python datetime objects) → parse → strip tz
        df = df.copy()
        try:
            parsed = pd.to_datetime(s, utc=True)
        except Exception as exc:
            raise ValueError(f"Cannot parse column '{col}' as datetime: {exc}") from exc
        df[col] = parsed.dt.tz_localize(None)

    return df


def drop_na(data: pd.DataFrame) -> pd.DataFrame:
    """Drops rows with NaN values based on a threshold.

    Args:
        data (pd.DataFrame): Input DataFrame.
        threshold (float): Fraction of NaNs allowed per row (0.0 means drop any NaN).

    Returns:
        pd.DataFrame: DataFrame with NaN rows dropped.
    """
    return data.dropna()


def check_dataframe_or_groupby(data: pd.DataFrame | pd.core.groupby.generic.DataFrameGroupBy) -> None:
    """Check if data is a pandas DataFrame or GroupBy object.

    Args:
        data: Input data to check.

    Raises:
        TypeError: If data is not a pandas DataFrame or GroupBy object.
    """
    if not isinstance(data, pd.DataFrame | pd.core.groupby.generic.DataFrameGroupBy):
        raise TypeError("Data must be a pandas DataFrame or GroupBy object.")


def check_date_column(data: pd.DataFrame | pd.core.groupby.generic.DataFrameGroupBy, date_column: str) -> None:
    """Check if date_column exists and contains valid datetime values.

    Args:
        data: DataFrame or GroupBy object containing the date column.
        date_column: Name of the column containing dates.

    Raises:
        ValueError: If date_column is not found or does not contain valid datetime values.
    """
    df = data.obj if isinstance(data, pd.core.groupby.generic.DataFrameGroupBy) else data
    if date_column not in df.columns:
        raise ValueError(f"Date column '{date_column}' not found in DataFrame.")
    if not pd.api.types.is_datetime64_any_dtype(df[date_column]):
        try:
            pd.to_datetime(df[date_column], utc=True)
        except (ValueError, TypeError):
            log.exception(f"Column '{date_column}' must contain valid datetime values.")


def check_value_column(
    data: pd.DataFrame | pd.core.groupby.generic.DataFrameGroupBy,
    value_column: str | list[str],
    require_numeric_dtype: bool = False,
) -> None:
    """Check if value_column(s) exist in the DataFrame.

    Args:
        data: DataFrame or GroupBy object containing the value column(s).
        value_column: Column name or list of column names to check.
        require_numeric_dtype: If True, enforce numeric dtype for value columns. Defaults to False.

    Raises:
        ValueError: If any value_column is not found or, if required, is not numeric.
    """
    df = data.obj if isinstance(data, pd.core.groupby.generic.DataFrameGroupBy) else data
    value_columns = [value_column] if isinstance(value_column, str) else value_column
    for col in value_columns:
        if col not in df.columns:
            raise ValueError(f"Value column '{col}' not found in DataFrame.")
        if require_numeric_dtype and not pd.api.types.is_numeric_dtype(df[col]):
            raise ValueError(f"Value column '{col}' must be numeric.")


def reduce_memory_usage(df: pd.DataFrame) -> pd.DataFrame:
    """Reduce memory usage by optimizing data types.

    Args:
        df: Input DataFrame to optimize.

    Returns:
        DataFrame with optimized data types.

    Notes:
        Float columns are converted to float32, integer columns to int32, and object columns to category where possible.
        Conversion failures for category type are silently ignored.
    """
    for col in df.columns:
        if pd.api.types.is_float_dtype(df[col]):
            df[col] = df[col].astype("float32")
        elif pd.api.types.is_integer_dtype(df[col]):
            df[col] = df[col].astype("int32")
        elif pd.api.types.is_object_dtype(df[col]):
            with contextlib.suppress(ValueError, TypeError):
                df[col] = df[col].astype("category")
    return df


def sort_dataframe(
    data: pd.DataFrame | pd.core.groupby.generic.DataFrameGroupBy,
    date_column: str,
    keep_grouped_df: bool = False,
) -> tuple[pd.DataFrame | pd.core.groupby.generic.DataFrameGroupBy, pd.Index]:
    """Sort DataFrame by date_column and return sorted DataFrame and original index.

    Args:
        data: DataFrame or GroupBy object to sort.
        date_column: Name of the column containing dates.
        keep_grouped_df: If True and data is a GroupBy, return a GroupBy object. Defaults to False.

    Returns:
        Tuple containing the sorted DataFrame or GroupBy object and the original index.
    """
    if isinstance(data, pd.core.groupby.generic.DataFrameGroupBy):
        df = data.obj
        group_names = data.keys if isinstance(data.keys, list) else [data.keys]
    else:
        df = data
        group_names = None

    idx_unsorted = df.index
    df_sorted = df.sort_values(date_column)

    if keep_grouped_df and group_names:
        return df_sorted.groupby(group_names), idx_unsorted
    return df_sorted, idx_unsorted


def get_threads(threads: int) -> int:
    """Validate and adjust the number of threads for parallel processing.

    Args:
        threads: Number of threads to use. Use -1 for all available cores.

    Returns:
        Number of threads to use.

    Raises:
        ValueError: If threads is less than -1 or equal to 0.
    """
    max_threads = multiprocessing.cpu_count()
    if threads == -1:
        return max_threads
    if threads < 1:
        raise ValueError("Threads must be -1 (all cores) or a positive integer.")
    return min(threads, max_threads)


def conditional_tqdm(iterable, total: int, desc: str, display: bool) -> list:
    """Wrap iterable with tqdm progress bar if display is True.

    Args:
        iterable: Iterable to wrap.
        total: Total number of items in the iterable.
        desc: Description for the progress bar.
        display: If True, show progress bar.

    Returns:
        List of items from the iterable.
    """
    if display:
        return list(tqdm.tqdm(iterable, total=total, desc=desc))
    return list(iterable)


def augment_rolling(
    data: pd.DataFrame | pd.core.groupby.generic.DataFrameGroupBy,
    date_column: str,
    value_column: str | list[str],
    window_func: str | list[str | tuple[str, Callable[..., Any]]] = "mean",
    window: int | tuple[int, int] | list[int] = 2,
    min_periods: int | None = None,
    center: bool = False,
    threads: int = 1,
    show_progress: bool = True,
    reduce_memory: bool = False,
    **kwargs,
) -> pd.DataFrame:
    """Apply rolling window functions to a pandas DataFrame or GroupBy object.

    This function sorts the data by the date column and applies one or more rolling window functions
    (e.g., mean, sum, or custom functions) to the specified value column(s) with given window sizes.
    Parallel processing is used for GroupBy objects when threads > 1, but may have overhead for small datasets.

    Args:
        data: Input DataFrame or GroupBy object to process.
        date_column: Name of the column containing dates, used for sorting.
        value_column: Column name or list of column names to apply rolling functions to.
        window_func: Function(s) to apply. Can be a string (e.g., "mean", "sum"), or a list of
            strings or tuples of (name, callable). Defaults to "mean".
        window: Size(s) of the rolling window(s). Can be an integer, tuple (range of sizes),
            or list of integers. Defaults to 2.
        min_periods: Minimum observations in window to produce a value. Defaults to window size.
        center: If True, center the rolling window. Defaults to False (trailing window).
        threads: Number of threads for parallel processing. Use -1 for all cores, 1 for serial.
            Defaults to 1.
        show_progress: If True, display a progress bar during processing. Defaults to True.
        reduce_memory: If True, optimize DataFrame memory usage. Defaults to False.
        **kwargs: Additional arguments to pass to pandas rolling functions.

    Returns:
        DataFrame with new columns for each function, window size, and value column, sorted by original index.

    Raises:
        TypeError: If data, window_func, or window is of an invalid type.
        ValueError: If date_column, value_column, window, or threads are invalid.

    Examples:
        >>> import pandas as pd
        >>> df = pd.DataFrame(
        ...     {
        ...         "date": pd.to_datetime(["2023-01-01", "2023-01-02", "2023-01-03"]),
        ...         "value": [10, 20, 30],
        ...         "id": ["A", "A", "A"],
        ...     }
        ... )
        >>> rolled_df = augment_rolling(
        ...     df,
        ...     date_column="date",
        ...     value_column="value",
        ...     window_func=["mean", ("range", lambda x: x.max() - x.min())],
        ...     window=[2, 3],
        ... )
        >>> print(rolled_df)
        date  value id value_rolling_mean_win_2 value_rolling_mean_win_3 value_rolling_range_win_2
        0 2023-01-01     10  A                       NaN                       NaN                        NaN
        1 2023-01-02     20  A                      15.0                       NaN                       10.0
        2 2023-01-03     30  A                      25.0                      20.0                       10.0
        >>> rolled_grouped = augment_rolling(
        ...     df.groupby("id"), date_column="date", value_column="value", window_func="sum", window=(1, 2)
        ... )
        >>> print(rolled_grouped)
                date  value id  value_rolling_sum_win_1  value_rolling_sum_win_2
        0 2023-01-01     10  A                     10.0                     10.0
        1 2023-01-02     20  A                     20.0                     30.0
        2 2023-01-03     30  A                     30.0                     50.0
    """
    # Checks
    check_dataframe_or_groupby(data)
    check_date_column(data, date_column)
    check_value_column(data, value_column)

    # Reduce memory if requested
    if reduce_memory:
        data = reduce_memory_usage(data if isinstance(data, pd.DataFrame) else data.obj)

    # Sort data
    data, idx_unsorted = sort_dataframe(data, date_column, keep_grouped_df=True)

    # Normalize inputs
    value_columns = [value_column] if isinstance(value_column, str) else value_column
    if not isinstance(window, int | tuple | list):
        raise TypeError("`window` must be an integer, tuple, or list.")
    windows = (
        [window]
        if isinstance(window, int)
        else list(range(window[0], window[1] + 1))
        if isinstance(window, tuple)
        else window
    )
    window_funcs = [window_func] if isinstance(window_func, str | tuple) else window_func
    threads = get_threads(threads)

    # Apply rolling functions
    ret = _augment_rolling_pandas(
        data,
        date_column,
        value_columns,
        window_funcs,  # type: ignore[arg-type]
        windows,
        min_periods,
        center,
        threads,
        show_progress,
        **kwargs,
    )

    # Reduce memory again if requested
    if reduce_memory:
        ret = reduce_memory_usage(ret)

    # Restore original index order
    return ret.sort_index()


def _augment_rolling_pandas(
    data: pd.DataFrame | pd.core.groupby.generic.DataFrameGroupBy,
    date_column: str,
    value_columns: list[str],
    window_funcs: list[str | tuple[str, Callable[..., Any]]],
    windows: list[int],
    min_periods: int | None,
    center: bool,
    threads: int,
    show_progress: bool,
    **kwargs,
) -> pd.DataFrame:
    """Apply rolling window functions to a pandas DataFrame or GroupBy object (internal).

    Args:
        data: Input DataFrame or GroupBy object to process.
        date_column: Name of the column containing dates (unused but kept for interface consistency).
        value_columns: List of column names to apply rolling functions to.
        window_funcs: List of functions to apply (strings or tuples of name and callable).
        windows: List of window sizes.
        min_periods: Minimum observations in window to produce a value.
        center: If True, center the rolling window.
        threads: Number of threads for parallel processing.
        show_progress: If True, display a progress bar.
        **kwargs: Additional arguments to pass to pandas rolling functions.

    Returns:
        DataFrame with new columns for each function, window size, and value column.

    Raises:
        ValueError: If window_func format or function name is invalid.
        TypeError: If window_func type is invalid or tuple format is incorrect.
        Exception: If a function fails during application.
    """
    data_copy = data.copy() if isinstance(data, pd.DataFrame) else data.obj.copy()

    def process_group(group: pd.DataFrame) -> pd.DataFrame:
        """Process a single group or DataFrame with rolling functions."""
        for col, window, func in product(value_columns, windows, window_funcs):
            min_periods_eff = window if min_periods is None else min_periods
            if isinstance(func, tuple):
                if len(func) != 2 or not isinstance(func[0], str):
                    raise ValueError(f"Invalid tuple format for window_func: {func}")
                func_name, func_callable = func
                new_column = f"{col}_rolling_{func_name}_win_{window}"
                if inspect.isfunction(func_callable) and len(inspect.signature(func_callable).parameters) == 1:
                    try:
                        group[new_column] = (
                            group[col]
                            .rolling(window=window, min_periods=min_periods_eff, center=center, **kwargs)
                            .apply(func_callable, raw=True)
                        )
                    except Exception:
                        log.exception(f"Error applying function '{func_name}'")
                        raise
                else:
                    raise TypeError(f"Invalid callable for '{func_name}'")
            elif isinstance(func, str):
                new_column = f"{col}_rolling_{func}_win_{window}"
                if func == "quantile":
                    new_column = f"{col}_rolling_quantile_50_win_{window}"
                    group[new_column] = (
                        group[col]
                        .rolling(window=window, min_periods=min_periods_eff, center=center, **kwargs)
                        .quantile(q=0.5)
                    )
                    log.warning(
                        "Using 'quantile' defaults to 50th percentile (0.5). For custom quantiles, use a tuple like "
                        "('quantile_75', lambda x: pd.Series(x).quantile(0.75)).",
                    )
                else:
                    rolling_func = getattr(
                        group[col].rolling(window=window, min_periods=min_periods_eff, center=center, **kwargs),
                        func,
                        None,
                    )
                    if rolling_func is None:
                        raise ValueError(f"Invalid function name: {func}")
                    group[new_column] = rolling_func()
            else:
                raise TypeError(f"Invalid function type: {type(func)}")
        return group

    if isinstance(data, pd.core.groupby.generic.DataFrameGroupBy):
        group_names = data.keys if isinstance(data.keys, list) else [data.keys]
        grouped = data_copy.groupby(group_names)
        if threads == 1:
            result_dfs = [
                process_group(group)
                for _, group in conditional_tqdm(
                    grouped,
                    total=len(grouped),
                    desc="Calculating Rolling...",
                    display=show_progress,
                )
            ]
        else:
            with multiprocessing.Pool(processes=threads) as pool:
                func = partial(process_group)
                result_dfs = conditional_tqdm(
                    pool.imap(func, (group for _, group in grouped)),
                    total=len(grouped),
                    desc="Calculating Rolling...",
                    display=show_progress,
                )
    else:
        result_dfs = [process_group(data_copy)]

    return pd.concat(result_dfs).sort_index()


def augment_lags(
    data: pd.DataFrame | pd.core.groupby.generic.DataFrameGroupBy,
    date_column: str,
    value_column: str | list[str],
    lags: int | tuple[int, int] | list[int] = 1,
    reduce_memory: bool = False,
) -> pd.DataFrame:
    """Add lagged columns to a pandas DataFrame or GroupBy object.

    This function takes a DataFrame or GroupBy object, sorts it by the specified date column,
    and adds lagged versions of the specified value column(s) based on the provided lags.

    Args:
        data: Input DataFrame or GroupBy object to add lagged columns to.
        date_column: Name of the column containing dates, used for sorting.
        value_column: Column name or list of column names to add lagged values for.
        lags: Number of lagged values to add. Can be an integer (single lag), tuple (range of lags),
            or list (specific lags). Defaults to 1.
        reduce_memory: If True, optimize DataFrame memory usage by adjusting data types. Defaults to False.

    Returns:
        DataFrame with lagged columns added, sorted by original index.

    Raises:
        TypeError: If data or lags is of an invalid type.
        ValueError: If date_column or value_column is invalid.

    Examples:
        >>> import pandas as pd
        >>> df = pd.DataFrame(
        ...     {
        ...         "date": pd.to_datetime(["2023-01-01", "2023-01-02", "2023-01-03"]),
        ...         "value": [10, 20, 30],
        ...         "id": ["A", "A", "A"],
        ...     }
        ... )
        >>> lagged_df = augment_lags(df, date_column="date", value_column="value", lags=[1, 2])
        >>> print(lagged_df)
                date  value id  value_lag_1  value_lag_2
        0 2023-01-01     10  A          NaN          NaN
        1 2023-01-02     20  A         10.0          NaN
        2 2023-01-03     30  A         20.0         10.0
    """
    # Checks
    check_dataframe_or_groupby(data)
    check_value_column(data, value_column)
    check_date_column(data, date_column)

    # Reduce memory if requested
    if reduce_memory:
        data = reduce_memory_usage(data if isinstance(data, pd.DataFrame) else data.obj)

    # Sort data
    data, idx_unsorted = sort_dataframe(data, date_column, keep_grouped_df=True)

    # Apply lagging
    ret = _augment_lags_pandas(data, date_column, value_column, lags)

    # Reduce memory again if requested
    if reduce_memory:
        ret = reduce_memory_usage(ret)

    # Restore original index order
    return ret.sort_index()


def _augment_lags_pandas(
    data: pd.DataFrame | pd.core.groupby.generic.DataFrameGroupBy,
    date_column: str,
    value_column: str | list[str],
    lags: int | tuple[int, int] | list[int] = 1,
) -> pd.DataFrame:
    """Add lagged columns to a pandas DataFrame or GroupBy object (internal).

    Args:
        data: Input DataFrame or GroupBy object to add lagged columns to.
        date_column: Name of the column containing dates (unused but kept for interface consistency).
        value_column: Column name or list of column names to add lagged values for.
        lags: Number of lagged values to add (int, tuple, or list). Defaults to 1.

    Returns:
        DataFrame with lagged columns added.

    Raises:
        TypeError: If lags is not an int, tuple, or list.
    """
    value_columns = [value_column] if isinstance(value_column, str) else value_column

    if isinstance(lags, int):
        lags = [lags]
    elif isinstance(lags, tuple):
        lags = list(range(lags[0], lags[1] + 1))
    elif not isinstance(lags, list):
        raise TypeError(f"Invalid lags specification: type {type(lags)}. Use int, tuple, or list.")

    # DataFrame case
    if isinstance(data, pd.DataFrame):
        df = data.copy()
        for col in value_columns:
            for lag in lags:
                df[f"{col}_lag_{lag}"] = df[col].shift(lag)

    # GroupBy case
    else:
        group_names = data.keys if isinstance(data.keys, list) else [data.keys]
        df = data.obj.copy()
        for col in value_columns:
            for lag in lags:
                df[f"{col}_lag_{lag}"] = df.groupby(group_names)[col].shift(lag)

    return df


def check_series_or_datetime(idx: pd.Series | pd.DatetimeIndex) -> None:
    """Check if idx is a pandas Series or DatetimeIndex.

    Args:
        idx: Input to check.

    Raises:
        TypeError: If idx is not a pandas Series or DatetimeIndex.
    """
    if not isinstance(idx, pd.Series | pd.DatetimeIndex):
        raise TypeError("idx must be a pandas Series or DatetimeIndex object.")


def week_of_month(dates: pd.Series) -> pd.Series:
    """Calculate the week of the month for each date.

    Args:
        dates: Series of datetime values.

    Returns:
        Series containing the week of the month (1 to 5).
    """
    return ((dates.dt.day - 1) // 7 + 1).astype("int32")


def augment_timeseries_signature(
    data: pd.DataFrame | pd.core.groupby.generic.DataFrameGroupBy,
    date_column: str,
    reduce_memory: bool = False,
    engine: str = "pandas",
) -> pd.DataFrame:
    """Add 29 datetime-based features to a pandas DataFrame or GroupBy object.

    This function takes a DataFrame and a date column, extracting 29 time series features
    such as year, month, day, and more, adding them as new columns prefixed with the date_column name.

    Args:
        data: Input DataFrame or GroupBy object containing the time series data.
        date_column: Name of the column containing datetime values.
        reduce_memory: If True, optimize DataFrame memory usage by converting to smaller dtypes. Defaults to False.
        engine: Engine to use for feature generation. Only 'pandas' is supported. Defaults to 'pandas'.

    Returns:
        DataFrame with 29 new datetime features added.

    Raises:
        TypeError: If data is not a pandas DataFrame or GroupBy object.
        ValueError: If date_column is invalid or engine is not 'pandas'.

    Features:
        - _index_num: Datetime as seconds since epoch.
        - _year: Year of the datetime.
        - _year_iso: ISO year.
        - _yearstart: 1 if first day of year, 0 otherwise.
        - _yearend: 1 if last day of year, 0 otherwise.
        - _leapyear: 1 if leap year, 0 otherwise.
        - _half: Half year (1 for Jan-Jun, 2 for Jul-Dec).
        - _quarter: Quarter (1 to 4).
        - _quarteryear: Year and quarter (e.g., '2023Q1').
        - _quarterstart: 1 if first day of quarter, 0 otherwise.
        - _quarterend: 1 if last day of quarter, 0 otherwise.
        - _month: Month number (1 to 12).
        - _month_lbl: Month name (e.g., 'January').
        - _monthstart: 1 if first day of month, 0 otherwise.
        - _monthend: 1 if last day of month, 0 otherwise.
        - _yweek: ISO week of the year.
        - _mweek: Week of the month.
        - _wday: Day of week (1=Monday, 7=Sunday).
        - _wday_lbl: Day of week name (e.g., 'Monday').
        - _mday: Day of month.
        - _qday: Day of quarter.
        - _yday: Day of year.
        - _weekend: 1 if weekend (Sat/Sun), 0 otherwise.
        - _hour: Hour of day.
        - _minute: Minute of hour.
        - _second: Second of minute.
        - _msecond: Microsecond.
        - _nsecond: Nanosecond.
        - _am_pm: 'am' or 'pm'.
    """
    check_dataframe_or_groupby(data)
    check_date_column(data, date_column)

    if isinstance(data, pd.core.groupby.generic.DataFrameGroupBy):
        data = data.obj

    if reduce_memory:
        data = reduce_memory_usage(data)

    if engine != "pandas":
        raise ValueError("Only 'pandas' engine is supported.")

    ret = pd.concat(
        [
            data,
            get_timeseries_signature(data[date_column], reduce_memory=reduce_memory, engine=engine).drop(
                date_column,
                axis=1,
            ),
        ],
        axis=1,
    )

    if reduce_memory:
        ret = reduce_memory_usage(ret)

    return ret


def get_timeseries_signature(
    idx: pd.Series | pd.DatetimeIndex,
    reduce_memory: bool = False,
    engine: str = "pandas",
) -> pd.DataFrame:
    """Convert a timestamp to a set of 29 time series features.

    Args:
        idx: Pandas Series or DatetimeIndex containing datetime values.
        reduce_memory: If True, optimize DataFrame memory usage by converting to smaller dtypes. Defaults to False.
        engine: Engine to use for feature generation. Only 'pandas' is supported. Defaults to 'pandas'.

    Returns:
        DataFrame with 29 datetime features.

    Raises:
        TypeError: If idx is not a pandas Series or DatetimeIndex.
        ValueError: If engine is not 'pandas'.

    Features:
        See augment_timeseries_signature for feature descriptions.
    """
    check_series_or_datetime(idx)

    if isinstance(idx, pd.DatetimeIndex):
        idx = pd.Series(idx, name="idx")

    if not isinstance(idx, pd.Series):
        raise TypeError("idx must be a pandas Series or DatetimeIndex object")

    if engine != "pandas":
        raise ValueError("Only 'pandas' engine is supported.")

    ret = _get_timeseries_signature_pandas(idx)

    if reduce_memory:
        ret = reduce_memory_usage(ret)

    return ret


def _get_timeseries_signature_pandas(idx: pd.Series | pd.DatetimeIndex) -> pd.DataFrame:
    """Internal function to compute time series signature using pandas.

    Args:
        idx: Pandas Series or DatetimeIndex containing datetime values.

    Returns:
        DataFrame with 29 datetime features.
    """
    if isinstance(idx, pd.DatetimeIndex):
        idx = pd.Series(idx, name="idx")

    if idx.name is None:
        idx.name = "idx"

    data = idx.to_frame()
    name = idx.name

    data = _pandas_timeseries_signature(data, date_column=name)

    return data


def _pandas_timeseries_signature(data: pd.DataFrame, date_column: str) -> pd.DataFrame:
    """Compute 29 datetime features from a date column using pandas.

    Args:
        data: DataFrame containing the date column.
        date_column: Name of the column containing datetime values.

    Returns:
        DataFrame with 29 datetime features.
    """
    name = date_column
    data = normalise_timestamp_column(data, name)
    idx = data[name]

    data[f"{name}_index_num"] = idx.astype(np.int64) // 10**9
    data[f"{name}_year"] = idx.dt.year
    data[f"{name}_year_iso"] = idx.dt.isocalendar().year
    data[f"{name}_yearstart"] = idx.dt.is_year_start.astype("uint8")
    data[f"{name}_yearend"] = idx.dt.is_year_end.astype("uint8")
    data[f"{name}_leapyear"] = idx.dt.is_leap_year.astype("uint8")
    data[f"{name}_half"] = pd.Series(np.where((idx.dt.quarter <= 2), 1, 2), index=idx.index)
    data[f"{name}_quarter"] = idx.dt.quarter
    data[f"{name}_quarteryear"] = pd.Series(pd.PeriodIndex(idx, freq="Q"), index=idx.index).dt.strftime("%YQ%q")
    data[f"{name}_quarterstart"] = idx.dt.is_quarter_start.astype("uint8")
    data[f"{name}_quarterend"] = idx.dt.is_quarter_end.astype("uint8")
    data[f"{name}_month"] = idx.dt.month
    data[f"{name}_month_lbl"] = idx.dt.month_name()
    data[f"{name}_monthstart"] = idx.dt.is_month_start.astype("uint8")
    data[f"{name}_monthend"] = idx.dt.is_month_end.astype("uint8")
    data[f"{name}_yweek"] = idx.dt.isocalendar().week
    data[f"{name}_mweek"] = week_of_month(idx)
    data[f"{name}_wday"] = idx.dt.dayofweek + 1
    data[f"{name}_wday_lbl"] = idx.dt.day_name()
    data[f"{name}_mday"] = idx.dt.day
    data[f"{name}_qday"] = (idx - pd.PeriodIndex(idx, freq="Q").start_time).dt.days + 1
    data[f"{name}_yday"] = idx.dt.dayofyear
    data[f"{name}_weekend"] = pd.Series(np.where((idx.dt.dayofweek >= 5), 1, 0), index=idx.index)
    data[f"{name}_hour"] = idx.dt.hour
    data[f"{name}_minute"] = idx.dt.minute
    data[f"{name}_second"] = idx.dt.second
    data[f"{name}_msecond"] = idx.dt.microsecond
    data[f"{name}_nsecond"] = idx.dt.nanosecond
    data[f"{name}_am_pm"] = pd.Series(np.where((idx.dt.hour <= 12), "am", "pm"), index=idx.index)

    return data


def separate_trigonometric_features(features: list[str]) -> tuple[list[str], list[str]]:
    """Separates features into trigonometric and non-trigonometric lists.

    Args:
        features: List of feature names to be categorized
    Returns:
        tuple: (features_with_trig, features_without_trig) where:
            - features_with_trig: Features containing '_sin', '_cos', or '_cosin'
            - features_without_trig: Features without these patterns
    Example:
        >>> features = ["temp_sin", "humidity", "pressure_cos", "wind_cosin"]
        >>> separate_trigonometric_features(features)
        (['temp_sin', 'pressure_cos', 'wind_cosin'], ['humidity'])
    """
    trig_suffixes = ["_sin", "_cos", "_cosin"]
    base_features = set()
    non_trig_features = []

    for feature in features:
        for suffix in trig_suffixes:
            if feature.endswith(suffix):
                base_features.add(feature[: -len(suffix)])
                break
        else:  # No break, so no trig suffix found
            non_trig_features.append(feature)

    return list(base_features), non_trig_features


def _validate_target_feature(target_feature: list[str] | str) -> list[str]:
    r"""Validate and normalize the target series input.

    This function ensures that the `target_feature` input is either a string or a list of strings.
    If the input is a string, it is converted into a single-element list. If the input is a list,
    it is validated to contain only strings and returned as-is. Otherwise, a `ValueError` is raised.

    Args:
        target_feature (list[str] | str): The target series to validate. This can be a single string
            or a list of strings.

    Returns:
        list[str]: A list of strings representing the target series.

    Raises:
        ValueError: If `target_feature` is neither a string nor a list of strings, or if the list
            contains non-string elements.

    Examples:
        >>> _validate_target_feature("series1")
        ['series1']
        >>> _validate_target_feature(["series1", "series2"])
        ['series1', 'series2']
        >>> _validate_target_feature(123)
        ValueError: target_feature: 123 should be a string or a list of strings
        >>> _validate_target_feature(["series1", 123])
        ValueError: target_feature: ['series1', 123] contains non-string elements
    """
    if isinstance(target_feature, str):
        return [target_feature]
    if isinstance(target_feature, list):
        if not all(isinstance(ts, str) for ts in target_feature):
            raise ValueError(f"target_feature: {target_feature} contains non-string elements")
        return target_feature
    raise ValueError(f"target_feature: {target_feature} should be a string or a list of strings")


def get_n_sample_per_day(period: str) -> int:
    """Calculate the number of samples taken per day based on the given period in minutes or hours.

    This function uses pandas.Timedelta to interpret the period string (e.g., '30min', '1h')
    and calculates the number of samples per day based on 1440 minutes/day. Only units
    'min' or 'h' are allowed (deprecated aliases 'T' and 'H' are accepted and normalised).

    Args:
        period (str): The period string in pandas offset format (e.g., '30min', '1h').

    Returns:
        int: The number of samples taken per day.

    Raises:
        TypeError: If the period is not a string.
        ValueError: If the period is invalid or uses units other than 'min', 'h'.

    Examples:
        >>> get_n_sample_per_day("30min")
        48
        >>> get_n_sample_per_day("15min")
        96
        >>> get_n_sample_per_day("1h")
        24
        >>> get_n_sample_per_day("2h")
        12
    """
    # Map deprecated uppercase aliases to their modern equivalents
    _alias_map = {"H": "h", "T": "min"}

    if not isinstance(period, str):
        raise TypeError(f"Invalid period format: {period}. Must be a string like '30min' or '1h'.")
    unit_match = re.search(r"[a-zA-Z]+$", period)
    if not unit_match:
        raise ValueError(f"Period {period} must specify a unit ('min', 'h').")
    raw_unit = unit_match.group()
    normalised_period = period[: -len(raw_unit)] + _alias_map.get(raw_unit, raw_unit)
    unit = _alias_map.get(raw_unit, raw_unit).lower()
    allowed_units = {"min", "h"}
    if unit not in allowed_units:
        raise ValueError(f"Period unit '{raw_unit}' is not allowed. Use 'min' or 'h' only.")
    if pd.tseries.frequencies.to_offset(normalised_period) is None:
        raise ValueError(f"Invalid period format: {period}. Use pandas offset aliases like '30min' or '1h'.")
    period_delta = pd.Timedelta(normalised_period)
    period_minutes = period_delta.total_seconds() / 60
    minutes_per_day = 24 * 60
    samples = int(minutes_per_day / period_minutes)
    return samples


def detect_missing_date(dataset: pd.DataFrame, period: int = 30):
    """Fill missing dates in a time series dataset with NaN values.

    Parameters
    ----------
    - dataset (pd.DataFrame): The input time series dataset with a datetime index.
    - period (int): The split_freq, in minutes, for the new date range. Default is 30 minutes.

    Returns:
    -------
    - pd.DataFrame: The input dataset with missing dates filled with NaN values.
    """
    data = dataset.copy()
    index_name = data.index.name
    min_dt = min([data.index.min()])
    max_dt = max([data.index.max()]) + pd.Timedelta(minutes=period)
    dt_rng = pd.date_range(min_dt, max_dt, freq=f"{period}T")
    data = data.reindex(dt_rng)
    data.index.name = index_name
    return data


def get_periods_for_exog_variable(hparams, data):
    exog = data[hparams["time_varying_known_categorical_feature"]].values
    exog_periods = [len(np.unique(exog[:, size])) for size in range(exog.shape[-1])]
    return exog_periods


def load_data(a_path, a_cols, a_rename=None, a_idx_field="timestamp", a_period="1T", a_timezone=None):
    data = pd.DataFrame()
    for path in a_path:
        data_temp = pd.read_csv(path, usecols=a_cols)
        data = pd.concat([data, data_temp], ignore_index=True)

    data[a_idx_field] = pd.to_datetime(data[a_idx_field], utc=True)

    if a_rename is not None:
        data.rename(columns=a_rename, inplace=True)
    data.set_index(a_idx_field, inplace=True)
    # data = data.interpolate(method="time")
    if a_timezone is not None:
        data.index = data.index.tz_convert(a_timezone)

    # data.index = pd.to_datetime(data.index)
    data = data.resample(a_period).mean()
    # data = resample(data, rate=a_period, short_rate='T', max_gap="30T")

    return data


def get_index(
    dataframe: pd.DataFrame,
    lookback_window_size: int,
    forecast_horizon: int,
    test: bool = True,
    date_col_name: str = "timestamp",
) -> np.ndarray:
    """Generate past and future index arrays for time series windows.

    Args:
        dataframe (pd.DataFrame): DataFrame containing the timestamp column.
        lookback_window_size (int): Size of the past window.
        forecast_horizon (int): Size of the future prediction window.
        test (bool, optional): If True, step by forecast_horizon; else, step by 1. Defaults to True.
        date_col_name (str, optional): Name of the timestamp column. Defaults to "timestamp".

    Returns:
        np.ndarray: 2D array with shape (n_windows, lookback_window_size + forecast_horizon),
                    where each row is [past_indices, future_indices].

    Raises:
        TypeError: If inputs do not match expected types.
        ValueError: If lookback_window_size or forecast_horizon are non-positive.
        KeyError: If date_col_name is not in dataframe.
    """
    if date_col_name not in dataframe.columns:
        raise KeyError(f"Column '{date_col_name}' not found in dataframe")

    if lookback_window_size <= 0 or forecast_horizon <= 0:
        raise ValueError("lookback_window_size or forecast_horizon are non-positive")

    # Extract index array
    index = np.asarray(dataframe[date_col_name])

    # Calculate the number of windows
    max_idx = len(index) - lookback_window_size - forecast_horizon + 1
    if max_idx <= 0:
        return np.array([])  # Return empty array if insufficient data

    # Define step size and compute number of windows based on original range logic
    step = forecast_horizon if test else 1
    n_windows = (max_idx + step - 1) // step if test else max_idx  # Match original range behavior

    # Generate start indices for all windows
    start_indices = np.arange(0, n_windows * step, step)

    # Ensure we don’t exceed the valid range
    start_indices = start_indices[start_indices < max_idx]

    # Create past and future index arrays using broadcasting
    past_offsets = np.arange(lookback_window_size)
    future_offsets = np.arange(lookback_window_size, lookback_window_size + forecast_horizon)

    # Compute all past and future indices
    past_indices = start_indices[:, np.newaxis] + past_offsets  # Shape: (n_windows, window_size)
    future_indices = start_indices[:, np.newaxis] + future_offsets  # Shape: (n_windows, horizon)

    # Extract values from the original index array
    past_values = index[past_indices]
    future_values = index[future_indices]

    # Concatenate along the second axis
    return np.concatenate((past_values, future_values), axis=1)


def stack_features(past_features: np.ndarray, future_covariates: np.ndarray | None = None) -> np.ndarray:
    """Combines past features and future covariates into a single feature array.

    Args:
        past_features: A 2D or 3D NumPy array of past exogenous features. If 2D, it is reshaped
            to 3D. Expected shape is (num_timesteps, num_features) for 2D or
            (batch_size, num_timesteps, num_features) for 3D.
        future_covariates: An optional 2D or 3D NumPy array of future covariates. If 2D, it is
            reshaped to 3D. Expected shape is (num_timesteps, num_features) for 2D or
            (batch_size, num_timesteps, num_features) for 3D. Defaults to None.

    Returns:
        A 3D NumPy array with combined features and covariates along the time axis.
        Shape is (batch_size, total_timesteps, max_features), where total_timesteps is
        the sum of past and future timesteps (padded if necessary), and max_features is
        the maximum of past and covariate features (padded with zeros if needed).

    Raises:
        ValueError: If past_features or future_covariates have invalid dimensions (not 2D or 3D).
        ValueError: If batch sizes mismatch after reshaping.

    Example:
        >>> import numpy as np
        >>> past = np.ones((96, 2))  # 96 timesteps, 2 features
        >>> future = np.ones((48, 10))  # 48 timesteps, 10 features
        >>> result = combine_past_future_exogenous(past, future)
        >>> print(result.shape)  # Output: (1, 144, 10)
        >>> print(result[0, :2])  # First two timesteps of past
        [[1. 1. 0. 0. 0. 0. 0. 0. 0. 0.]
         [1. 1. 0. 0. 0. 0. 0. 0. 0. 0.]]
        >>> print(result[0, 96:98])  # First two timesteps of future
        [[1. 1. 1. 1. 1. 1. 1. 1. 1. 1.]
         [1. 1. 1. 1. 1. 1. 1. 1. 1. 1.]]
    """
    # Validate dimensions of past_features
    if past_features.ndim not in (2, 3):
        raise ValueError(f"past_features must be a 2D or 3D array, got {past_features.ndim} dimensions")

    # Reshape past_features to 3D if 2D
    if past_features.ndim == 2:
        num_timesteps, num_features = past_features.shape
        past_features = past_features.reshape((1, num_timesteps, num_features))
    batch_size, lookback_window_size, num_features = past_features.shape

    # Handle future_covariates if provided
    if future_covariates is not None:
        # Validate dimensions
        if future_covariates.ndim not in (2, 3):
            raise ValueError(f"future_covariates must be a 2D or 3D array, got {future_covariates.ndim} dimensions")

        # Reshape future_covariates to 3D if 2D
        if future_covariates.ndim == 2:
            cov_timesteps, cov_features = future_covariates.shape
            future_covariates = future_covariates.reshape((1, cov_timesteps, cov_features))

        # Extract shapes
        cov_batch_size, cov_timesteps, cov_features = future_covariates.shape

        # Check batch size compatibility
        if cov_batch_size != batch_size:
            raise ValueError(
                f"Batch size mismatch: past_features has {batch_size}, future_covariates has {cov_batch_size}",
            )

        # Determine maximum feature size and pad the smaller array
        max_features = max(num_features, cov_features)
        if num_features < max_features:
            feature_padding = np.zeros(
                (batch_size, lookback_window_size, max_features - num_features),
                dtype=past_features.dtype,
            )
            past_features = np.concatenate([past_features, feature_padding], axis=-1)
        elif cov_features < max_features:
            feature_padding = np.zeros(
                (cov_batch_size, cov_timesteps, max_features - cov_features),
                dtype=future_covariates.dtype,
            )
            future_covariates = np.concatenate([future_covariates, feature_padding], axis=-1)

        # Combine along the time axis (no timestep padding needed here)
        combined_features = np.concatenate([past_features, future_covariates], axis=1)
    else:
        combined_features = past_features

    return combined_features


def unstack_features(
    combined_features: np.ndarray,
    lookback_window_size: int,
    num_padding: int,
    forecast_horizon: int | None = None,
) -> tuple[np.ndarray, np.ndarray | None]:
    """Inverse operation to split combined features into past and future parts.

    Args:
        combined_features: 3D array of shape (batch_size, total_timesteps, max_features).
        lookback_window_size: Number of timesteps corresponding to past features.
        num_padding: If negative, drop last -num_padding features from past;
                     if non-negative, drop last num_padding features from future.
        forecast_horizon: Number of timesteps corresponding to future features.
                          If None, only past features are present.

    Returns:
        A tuple (past, future) where:
            - past is the past features (possibly trimmed).
            - future is the future features (trimmed as needed) or None.
    """
    # Ensure combined_features is 3D
    if combined_features.ndim == 2:
        combined_features = combined_features.reshape((1, *combined_features.shape))

    batch_size, total_timesteps, max_features = combined_features.shape

    if forecast_horizon is None:
        if total_timesteps != lookback_window_size:
            raise ValueError(
                f"Total timesteps in combined_features ({total_timesteps}) "
                f"must equal lookback_window_size ({lookback_window_size}) when no future_covariates are provided.",
            )
        past = combined_features
        future = None
    else:
        if total_timesteps != lookback_window_size + forecast_horizon:
            raise ValueError(
                f"Total timesteps in combined_features ({total_timesteps}) "
                f"must equal lookback_window_size ({lookback_window_size}) + forecast_horizon ({forecast_horizon}).",
            )
        past = combined_features[:, :lookback_window_size, :]
        future = combined_features[:, lookback_window_size : lookback_window_size + forecast_horizon, :]
        # If num_padding is negative, trim the past features
        if num_padding < 0:
            past = past[:, :, :num_padding]
        # If non-negative, trim the future features
        else:
            future = future[:, :, :-num_padding]
    return past, future


def get_target_sequences(targets, lookback_window_size, forecast_horizon, stride=1):
    """Extract sequences of target data for forecasting.

    Parameters
    ----------
    targets (np.ndarray): The target data array of shape (n_samples, n_features).
    lookback_window_size (int): The size of the input window.
    forecast_horizon (int): The forecast horizon.
    stride (int): Step between consecutive windows. Default 1 (fully overlapping).
        Use ``stride=forecast_horizon`` for non-overlapping windows equivalent to
        ``get_daily_sequences`` with ``target_mode=True``.

    Returns:
    -------
    np.ndarray: The extracted target sequences of shape (n_sequences, forecast_horizon, n_features).
    """
    all_windows = np.squeeze(
        np.lib.stride_tricks.sliding_window_view(targets[lookback_window_size:], (forecast_horizon, targets.shape[1])),
        axis=1,
    )
    all_windows = all_windows.reshape(all_windows.shape[0], forecast_horizon, -1)
    return all_windows[::stride]


def get_feature_sequences(features, lookback_window_size, forecast_horizon, stride=1):
    """Extract sequences of feature data for forecasting.

    Parameters
    ----------
    features (np.ndarray): The feature data array of shape (n_samples, n_features).
    lookback_window_size (int): The size of the input window.
    forecast_horizon (int): The forecast horizon.
    stride (int): Step between consecutive windows. Default 1 (fully overlapping).
        Use ``stride=forecast_horizon`` for non-overlapping windows equivalent to
        ``get_daily_sequences`` with ``target_mode=False``.

    Returns:
    -------
    np.ndarray: The extracted feature sequences of shape (n_sequences, lookback_window_size, n_features).
    """
    all_windows = np.squeeze(
        np.lib.stride_tricks.sliding_window_view(features, window_shape=(lookback_window_size, features.shape[1])),
        axis=1,
    )
    all_windows = all_windows.reshape(all_windows.shape[0], lookback_window_size, -1)[:-forecast_horizon]
    return all_windows[::stride]


def get_daily_sequences(data, lookback_window_size, forecast_horizon, target_mode=False):
    """Extract daily sequences of feature or target data for forecasting.

    Parameters
    ----------
    data (np.ndarray): The data array of shape (n_samples, n_features).
    lookback_window_size (int): The size of the input window.
    forecast_horizon (int): The forecast horizon.
    target_mode (bool): Whether to extract target sequences instead of feature sequences.

    Returns:
    -------
    np.ndarray: The extracted sequences of shape (n_sequences, window_size, n_features).
    """
    nb_obs, nb_features = data.shape
    list_range = range(0, nb_obs - lookback_window_size - forecast_horizon + 1, forecast_horizon)
    num_sequences = len(list_range)

    # Preallocate an array for the results
    sequences_array = np.empty((num_sequences, forecast_horizon if target_mode else lookback_window_size, nb_features))

    # for idx, i in enumerate(tqdm(list_range, desc="Processing sequences")):
    for idx, i in enumerate(
        list_range,
    ):
        if target_mode:
            sequences_array[idx] = np.expand_dims(
                data[i + lookback_window_size : i + lookback_window_size + forecast_horizon, :],
                axis=0,
            )
        else:
            sequences_array[idx] = np.expand_dims(data[i : i + lookback_window_size, :], axis=0)

    return sequences_array


def split_features_by_group(
    x,
    lookback_window_size: int,
    forecast_horizon: int,
    groups: list[dict],
    num_past_features: int,
    num_covariate_features: int,
):
    """Split input tensor into per-group past and future feature tensors.

    This function splits features according to the DataPipeline column ordering:
    - Past features order: [target, historical, exogenous, calendar]
    - Future features order: [exogenous, calendar, future_covariates]

    Args:
        x: Input tensor of shape (batch_size, total_timesteps, total_features)
        lookback_window_size: Number of past timesteps
        forecast_horizon: Number of future timesteps
        groups: List of group definitions from _define_feature_groups
        num_past_features: Total number of past features
        num_covariate_features: Total number of covariate features

    Returns:
        Tuple of (past_groups, future_groups) lists
    """
    # Split full input into past and future blocks
    past_full, future_full = unstack_features(
        x,
        lookback_window_size=lookback_window_size,
        forecast_horizon=forecast_horizon,
        num_padding=num_past_features - num_covariate_features,
    )

    past_groups: list[np.ndarray | None] = []
    future_groups: list[np.ndarray | None] = []

    # Calculate offsets based on group ordering
    # Past: historical -> exogenous -> calendar
    # Future: exogenous -> calendar -> future_covariates

    past_offset = 0
    future_offset = 0

    for group in groups:
        size = group["size"]

        # Past part
        if group["has_past"] and size > 0:
            # Handle potential trimming from unstack_features
            if past_full is not None and past_offset + size <= past_full.shape[2]:
                past_slice = past_full[:, :, past_offset : past_offset + size]
                past_groups.append(past_slice)
                past_offset += size
            else:
                past_groups.append(None)
        else:
            past_groups.append(None)

        # Future part
        if group["has_future"] and size > 0:
            # Handle potential trimming and check if future exists
            if future_full is not None and future_offset + size <= future_full.shape[2]:
                future_slice = future_full[:, :, future_offset : future_offset + size]
                future_groups.append(future_slice)
                future_offset += size
            else:
                future_groups.append(None)
        else:
            future_groups.append(None)

    return past_groups, future_groups


def define_feature_groups(
    num_target: int,
    num_hist: int,
    num_cal: int,
    num_exo: int,
    num_fut_cov: int,
    past_len: int,
    future_len: int,
) -> list[dict]:
    """Create feature groups that match DataPipeline column ordering."""
    groups = []

    # Group 1: Target + Historical (past only)
    if num_target > 0:
        groups.append(
            {
                "name": "historical_target",
                "size": num_target,
                "has_past": True,
                "has_future": False,
                "context_past": past_len,
                "context_future": 0,
            },
        )
    # Group 2: Historical (past only)
    if num_hist > 0:
        groups.append(
            {
                "name": "historical",
                "size": num_hist,
                "has_past": True,
                "has_future": False,
                "context_past": past_len,
                "context_future": 0,
            },
        )

    # Group 3: Exogenous (past + future)
    if num_exo > 0:
        groups.append(
            {
                "name": "exogenous",
                "size": num_exo,
                "has_past": True,
                "has_future": True,
                "context_past": past_len,
                "context_future": future_len,
            },
        )

    # Group 4: Calendar (past + future)
    if num_cal > 0:
        groups.append(
            {
                "name": "calendar",
                "size": num_cal,
                "has_past": True,
                "has_future": True,
                "context_past": past_len,
                "context_future": future_len,
            },
        )

    # Group 5: Future covariates (future only)
    if num_fut_cov > 0:
        groups.append(
            {
                "name": "future_covariates",
                "size": num_fut_cov,
                "has_past": False,
                "has_future": True,
                "context_past": 0,
                "context_future": future_len,
            },
        )

    # Filter out empty groups
    active_groups = [g for g in groups if g["size"] > 0]  # type: ignore[operator]
    if not active_groups:
        raise ValueError("At least one feature group must have positive size")

    return active_groups
