from __future__ import annotations

from lightning.pytorch.core import LightningDataModule
import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset


class TimeseriesDataModule(LightningDataModule):
    """A PyTorch Lightning DataModule for managing time series data loading and processing.

    Handles dataset creation, automatic tensor conversion, and provides configurable data loaders
    for training and validation. Designed for seamless integration with PyTorch Lightning workflows.

    Args:
        train_inputs (np.ndarray): Input features for training data. Shape: (num_samples, num_features)
        train_targets (np.ndarray): Target values for training data. Shape: (num_samples, ...)
        val_inputs (np.ndarray, optional): Input features for validation data. Defaults to None.
        val_targets (np.ndarray, optional): Target values for validation data. Defaults to None.
        batch_size (int, optional): Number of samples per batch. Defaults to 64.
        num_workers (int, optional): Parallel workers for data loading. Defaults to 1.
        persistent_workers (bool, optional): Maintain worker processes between epochs.
            Requires num_workers > 0. Defaults to True.
        pin_memory (bool, optional): Enable fast GPU transfer for CUDA devices. Defaults to True.

    Raises:
        ValueError: If validation inputs/targets are partially provided
        TypeError: If input arrays are not numpy ndarrays

    Attributes:
        train_dataset (TensorDataset): Training dataset containing (inputs, targets) tensors
        val_dataset (TensorDataset, optional): Validation dataset if validation data provided

    Example:
        >>> import numpy as np
        >>> train_inputs = np.random.rand(100, 10).astype(np.float32)
        >>> train_targets = np.random.rand(100, 1).astype(np.float32)
        >>> dm = TimeseriesDataModule(train_inputs, train_targets, batch_size=32, num_workers=4)
        >>> trainer.fit(model, dm)
    """

    def __init__(
        self,
        train_inputs: np.ndarray,
        train_targets: np.ndarray,
        val_inputs: np.ndarray | None = None,
        val_targets: np.ndarray | None = None,
        batch_size: int = 64,
        num_workers: int = 1,
        persistent_workers: bool = True,
        pin_memory: bool = True,
    ):
        """Initialize data module with training/validation data and loading parameters."""
        super().__init__()

        if not all(isinstance(arr, np.ndarray) for arr in [train_inputs, train_targets]):
            raise TypeError("All input arrays must be numpy ndarrays")

        if (val_inputs is None) != (val_targets is None):
            raise ValueError("Must provide both val_inputs and val_targets or neither")

        self.train_inputs = train_inputs
        self.train_targets = train_targets
        self.val_inputs = val_inputs
        self.val_targets = val_targets
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.persistent_workers = persistent_workers and num_workers > 0
        self.pin_memory = pin_memory

    def setup(self, stage: str | None = None) -> None:
        """Create tensor datasets from numpy arrays.

        Automatically called by Lightning during trainer.fit(). Converts numpy arrays
        to PyTorch tensors and creates TensorDataset objects for training/validation.

        Args:
            stage (str, optional): Current pipeline stage ('fit', 'validate', etc).
                Defaults to None.
        """
        self.train_dataset = TensorDataset(
            torch.from_numpy(self.train_inputs).float(),
            torch.from_numpy(self.train_targets).float(),
        )

        if self.val_inputs is not None and self.val_targets is not None:
            self.val_dataset = TensorDataset(
                torch.from_numpy(self.val_inputs).float(),
                torch.from_numpy(self.val_targets).float(),
            )

    def train_dataloader(self) -> DataLoader:
        """Generate training data loader with configured batching and shuffling.

        Returns:
            DataLoader: Configured loader for training data with:
                - Random shuffling between epochs
                - Specified batch size
                - Parallel workers if num_workers > 0
                - Pinned memory for GPU acceleration
        """
        return DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            persistent_workers=self.persistent_workers,
            pin_memory=self.pin_memory,
            drop_last=self.num_workers > 0,
            prefetch_factor=2 if self.num_workers > 0 else None,
        )

    def val_dataloader(self) -> list[DataLoader] | list:
        """Generate validation data loader if validation data exists.

        Returns:
            DataLoader | None: Configured loader for validation data with:
                - Sequential ordering
                - Same batch size as training
                - Parallel workers if num_workers > 0
                - Pinned memory for GPU acceleration
        """
        if hasattr(self, "val_dataset") and len(self.val_dataset) > 0:
            return [
                DataLoader(
                    self.val_dataset,
                    batch_size=self.batch_size,
                    shuffle=False,
                    num_workers=self.num_workers,
                    persistent_workers=self.persistent_workers,
                    pin_memory=self.pin_memory,
                    drop_last=self.num_workers > 0,
                    prefetch_factor=2 if self.num_workers > 0 else None,
                ),
            ]
        return []
