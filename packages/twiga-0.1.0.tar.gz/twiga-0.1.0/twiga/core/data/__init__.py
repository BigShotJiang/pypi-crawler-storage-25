"""Data pipeline, feature engineering, and preprocessing utilities."""

from twiga.core.config.characterisation import CharacterisationConfig
from twiga.core.data.autores import AutoregressTransformer
from twiga.core.data.characterisation import CharacterisationResult, SignalCharacteriser
from twiga.core.data.feature import add_day_night_feature, add_fourier_features
from twiga.core.data.pipeline import DataPipeline
from twiga.core.data.processing import augment_timeseries_signature, normalise_timestamp_column, stack_features
from twiga.core.data.relevance import AssociationAnalyzer
from twiga.core.data.selection import compute_rf_importance, select_top_features
from twiga.core.data.temporal import TemporalFeatureTransformer

__all__ = [
    "AssociationAnalyzer",
    "CharacterisationConfig",
    "CharacterisationResult",
    "SignalCharacteriser",
    "AutoregressTransformer",
    "DataPipeline",
    "TemporalFeatureTransformer",
    "add_day_night_feature",
    "add_fourier_features",
    "augment_timeseries_signature",
    "normalise_timestamp_column",
    "compute_rf_importance",
    "select_top_features",
    "stack_features",
]
