from astral import LocationInfo
from astral.sun import sun
import numpy as np
import pandas as pd

from .processing import _pandas_timeseries_signature


def compute_netload_ghi(load, ghi, num_samples_per_day):
    """Compute the net load by subtracting normalized GHI from normalized load.

    Args:
        load (np.ndarray): Array of load values.
        ghi (np.ndarray): Array of GHI (Global Horizontal Irradiance) values.
        num_samples_per_day (int): Number of samples per day.

    Returns:
        np.ndarray: Net load (normalized load - normalized GHI) for valid segments.
    """
    # Ensure inputs are NumPy arrays
    load = np.asarray(load)
    ghi = np.asarray(ghi)

    # Calculate the number of complete days
    n_days = (len(load) - num_samples_per_day) // num_samples_per_day
    if n_days <= 0:
        return np.array([])  # Return empty array if insufficient data

    # Define the total number of elements to extract
    total_elements = n_days * num_samples_per_day

    # Reshape load and ghi into 2D arrays: (n_days, num_samples_per_day)
    start_idx = num_samples_per_day
    end_idx = start_idx + total_elements  # 24 + 23,976 = 24,000
    load_segments = load[start_idx - num_samples_per_day : end_idx - num_samples_per_day].reshape(
        n_days,
        num_samples_per_day,
    )
    ghi_segments = ghi[start_idx:end_idx].reshape(n_days, num_samples_per_day)

    # Normalize each day's load and GHI by their respective maximum absolute values
    load_max = np.abs(load_segments).max(axis=1, keepdims=True)
    ghi_max = np.abs(ghi_segments).max(axis=1, keepdims=True)

    # Avoid division by zero
    load_max = np.where(load_max == 0, 1, load_max)
    ghi_max = np.where(ghi_max == 0, 1, ghi_max)

    # Compute normalized values
    load_norm = load_segments / load_max
    ghi_norm = ghi_segments / ghi_max

    # Compute net load
    net_load = load_norm - ghi_norm

    # Flatten back to 1D array
    return net_load.ravel()


def get_sunrise_sunset(
    start_date: pd.Timestamp,
    end_date: pd.Timestamp,
    latitude: float = 32.738274,
    longitude: float = -16.738519,
) -> dict[str, dict[str, pd.Timestamp]]:
    """Get the sunrise and sunset times for a given location and period of time.

    Args:
        start_date: Start date (e.g., "YYYY-MM-DD" or datetime.date object).
        end_date: End date (e.g., "YYYY-MM-DD" or datetime.date object).
        latitude: Latitude of the location. Defaults to 32.738274.
        longitude: Longitude of the location. Defaults to -16.738519.

    Returns:
        Dictionary with dates as keys and dicts of sunrise/sunset times as values.
    """
    # Convert inputs to date objects if needed
    start_date = pd.Timestamp(start_date).date()
    end_date = pd.Timestamp(end_date).date()

    location = LocationInfo(latitude=latitude, longitude=longitude)
    days = pd.date_range(start=start_date, end=end_date, freq="D")

    # Preallocate arrays for sunrise and sunset times
    # sunrises = np.empty(len(days), dtype="datetime64[ns]")
    # sunsets = np.empty(len(days), dtype="datetime64[ns]")

    # Initialize lists to store sunrise and sunset times
    sunrises = []
    sunsets = []

    # Compute sunrise/sunset for all days
    for _, current_date in enumerate(days):
        s = sun(location.observer, date=current_date)
        # sunrises[i] = np.datetime64(s["sunrise"])
        # sunsets[i] = np.datetime64(s["sunset"])

        sunrises.append(s["sunrise"].replace(tzinfo=None))
        sunsets.append(s["sunset"].replace(tzinfo=None))

    # Create DataFrame and convert to dictionary
    df = pd.DataFrame({"date": days.date, "sunrise": sunrises, "sunset": sunsets})
    df["sunrise"] = pd.to_datetime(df["sunrise"])
    df["sunset"] = pd.to_datetime(df["sunset"])
    return df.set_index("date").to_dict(orient="index")


def add_day_night_feature(
    data: pd.DataFrame,
    latitude: float,
    longitude: float,
    date_col_name: str = "timestamp",
) -> pd.DataFrame:
    """Add a day/night feature to the dataset based on sunrise/sunset times.

    Args:
        data: Input dataset with a datetime column.
        latitude: Latitude of the location.
        longitude: Longitude of the location.
        date_col_name: Name of the datetime column. Defaults to "timestamp".

    Returns:
        Dataset with a "day_night" column (1 for day, 0 for night).

    Raises:
        ValueError: If ``date_col_name`` is not datetime-like.
        KeyError: If ``date_col_name`` is not in the DataFrame.
    """
    # Check if date_col_name exists and is datetime-like
    if date_col_name not in data.columns:
        raise KeyError(f"Column '{date_col_name}' not found in DataFrame")
    if not pd.api.types.is_datetime64_any_dtype(data[date_col_name]):
        raise ValueError(f"Column '{date_col_name}' must be datetime-like")

    # Get date range
    min_date = data[date_col_name].min().date()
    max_date = data[date_col_name].max().date()

    # Get sunrise/sunset times
    sunrise_sunset = get_sunrise_sunset(min_date, max_date, latitude, longitude)

    # Extract dates and unique dates
    dates = data[date_col_name].dt.date
    unique_dates = np.unique(dates)

    # Create sunrise/sunset Series directly from dictionary
    sunrise_times = pd.Series({date: sunrise_sunset[date]["sunrise"] for date in unique_dates})
    sunset_times = pd.Series({date: sunrise_sunset[date]["sunset"] for date in unique_dates})

    # Map to all timestamps efficiently
    sunrise = sunrise_times.reindex(dates, method="ffill").values
    sunset = sunset_times.reindex(dates, method="ffill").values

    # Extract time components as seconds since midnight in one go
    times = data[date_col_name].dt
    time_seconds = (times.hour * 3600 + times.minute * 60 + times.second).values
    sunrise_seconds = (sunrise.astype("datetime64[ns]").astype("int64") // 10**9 % 86400).astype(np.int32)
    sunset_seconds = (sunset.astype("datetime64[ns]").astype("int64") // 10**9 % 86400).astype(np.int32)

    # Vectorized day/night computation
    day_night = np.where((time_seconds >= sunrise_seconds) & (time_seconds <= sunset_seconds), 1, 0)

    # Add to DataFrame
    data["day_night"] = day_night
    return data


def add_temporal_feature(data: pd.DataFrame, date_col_name: str = "timestamp") -> pd.DataFrame:
    """Add temporal features to the dataset.

    Args:
        data: Input dataset with a datetime column.
        date_col_name: Name of the datetime column. Defaults to "timestamp".

    Returns:
        Dataset with additional temporal features.
    """
    # Check if date_col_name exists and is datetime-like
    if date_col_name not in data.columns:
        raise KeyError(f"Column '{date_col_name}' not found in DataFrame")
    if not pd.api.types.is_datetime64_any_dtype(data[date_col_name]):
        raise ValueError(f"Column '{date_col_name}' must be datetime-like")

    data = _pandas_timeseries_signature(data, date_column=date_col_name)
    data.rename(columns=lambda x: x.replace(f"{date_col_name}_", ""), inplace=True)
    return data


def get_fourier_series(dates: pd.Series | np.ndarray | list, period: float, series_order: int = 1) -> np.ndarray:
    """Compute Fourier series components for seasonality modeling, identical to Prophet's implementation.

    Args:
        dates (pd.Series, np.ndarray, or list): Timestamps or time values. If not datetime-like,
            assumed to be days since epoch (1970-01-01).
        period (float): Period of the seasonality in days (e.g., 365.25 for yearly, 7 for weekly).
        series_order (int): Number of Fourier components (sine and cosine pairs).

    Returns:
        np.ndarray: Matrix of shape (len(dates), 2 * series_order) where each column is a
            sine or cosine term: [sin(2πt/period), cos(2πt/period), sin(4πt/period), ...].

    Raises:
        ValueError: If period <= 0, series_order < 0, or dates is empty/invalid.
    """
    if period <= 0:
        raise ValueError(f"Period must be a positive number, got {period}")
    if not isinstance(series_order, int) or series_order < 0:
        raise ValueError(f"Series order must be a non-negative integer, got {series_order}")

    # Convert dates to array, ensuring proper handling of lists
    dates = np.asarray(dates)
    if dates.size == 0:
        raise ValueError("Dates array cannot be empty")

    # Convert to days since epoch if datetime-like
    if pd.api.types.is_datetime64_any_dtype(dates) or (dates.size > 0 and isinstance(dates[0], pd.Timestamp)):
        # Convert to datetime64 array first, then compute days since epoch
        dates = pd.to_datetime(dates).to_numpy(dtype="datetime64[ns]")
        t = (dates - np.datetime64("1970-01-01")) / np.timedelta64(1, "D")
    else:
        # Assume input is already in days if not datetime-like
        t = dates.astype(float)

    # Precompute constants
    n = len(t)

    k = np.arange(1, series_order + 1)  # Orders 1 to series_order
    omega = 2.0 * np.pi / period  # Angular split_freq

    # Vectorized computation of all terms
    x = omega * t[:, np.newaxis] * k  # Shape: (n, series_order)

    sin_terms = np.sin(x)  # Shape: (n, series_order)
    cos_terms = np.cos(x)  # Shape: (n, series_order)

    # Interleave sine and cosine terms
    features = np.zeros((n, 2 * series_order), dtype=float)

    features[:, 0::2] = sin_terms  # Even indices: sin
    features[:, 1::2] = cos_terms  # Odd indices: cos

    return features


def add_fourier_features(data: pd.DataFrame, calendar_variables: list[str], periods: list[int]) -> pd.DataFrame:
    """Add Fourier series features for trigonometric calendar features.

    Args:
        data (pd.DataFrame): Input data.
        date_col_name (str): Name of the datetime column (unused here, kept for consistency).
        periods (list[int]): Periods for each trigonometric feature.
        calendar_variables (list[str]): Names of the calendar variables.

    Returns:
            pd.DataFrame: Data with added sin/cos columns.
    """
    result = data.copy()
    for var, period in zip(calendar_variables, periods, strict=True):
        sin_col = f"{var}_sin"
        cos_col = f"{var}_cos"
        cosin_col = f"{var}_cosin"
        if sin_col in result or cos_col in result:
            continue

        features = get_fourier_series(dates=result[var].values, period=period, series_order=1)
        result[sin_col], result[cos_col] = features[:, 0::2], features[:, 1::2]
        result[cosin_col] = result[sin_col] + result[cos_col]

    return result
