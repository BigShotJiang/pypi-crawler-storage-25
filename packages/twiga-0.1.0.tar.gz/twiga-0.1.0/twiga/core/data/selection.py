"""Feature selection pipeline.

Statistical compute functions live in ``twiga.core.stats.selection`` and are
re-exported here for backwards compatibility.  Only the orchestration function
:func:`select_top_features` is defined in this module.
"""

from __future__ import annotations

from functools import reduce
from typing import Literal

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.feature_selection import SelectFromModel
from sklearn.preprocessing import LabelEncoder

from twiga.core.stats.association import compute_anova_f, compute_chi2, rank_correlation
from twiga.core.stats.mutual_information import compute_mutual_information
from twiga.core.stats.ppscore import compute_ppscore
from twiga.core.stats.xicorr import compute_xicorr
from twiga.core.utils.logger import get_logger

log = get_logger(__name__)


def compute_rf_importance(
    data: pd.DataFrame,
    target: str,
    features: str | list[str],
    task: str = "regression",
    n_estimators: int = 50,
    random_state: int | None = 42,
    n_jobs: int = -1,
    pivot: bool = True,
) -> pd.DataFrame:
    """Compute Random Forest feature importance using SelectFromModel.

    Uses mean impurity decrease (MDI) across trees, selected via a mean-importance
    threshold internally. MDI importance is a model-based measure - unlike
    statistical tests it captures non-linear interactions automatically.

    Args:
        data: Input DataFrame.
        target: Target column.
        features: Feature column(s).
        task: "regression" or "classification".
        n_estimators: Number of trees in the forest. Defaults to 50.
        random_state: Random seed. Defaults to 42.
        n_jobs: Number of jobs for parallelisation. Defaults to -1 (all cores).
        pivot: If True, pivot result with features as index. Defaults to True.

    Returns:
        DataFrame with ["feature", "rf_importance"] in long format, or pivoted
        with features as index.

    Example:
        >>> df = pd.DataFrame({"x1": [1, 2, 3], "x2": [4, 5, 6], "y": [0, 1, 0]})
        >>> compute_rf_importance(df, "y", ["x1", "x2"], task="classification")
    """
    if isinstance(features, str):
        features = [features]
    inputs = data[features].values
    y = data[target].values

    estimator = (
        RandomForestRegressor(n_estimators=n_estimators, random_state=random_state, n_jobs=n_jobs)
        if task == "regression"
        else RandomForestClassifier(n_estimators=n_estimators, random_state=random_state, n_jobs=n_jobs)
    )

    selector = SelectFromModel(estimator, threshold="mean")
    selector.fit(inputs, y)
    importances = selector.estimator_.feature_importances_

    result = pd.DataFrame({"feature": features, "rf_importance": importances})
    result = result.sort_values("rf_importance", ascending=False)
    if pivot:
        result = result.set_index("feature")
    return result


def select_top_features(
    data: pd.DataFrame,
    features: list[str],
    target: str,
    task: Literal["regression", "classification"] = "regression",
    top_k: int = 5,
    alpha: float | None = 0.05,
    rank_aggregation: Literal["borda_count", "arith_rank", "geom_rank"] = "borda_count",
    include_pps: bool = True,
    include_xi: bool = True,
    include_rf: bool = True,
    include_chi2: bool = True,
    random_state: int = 42,
    return_scores: bool = False,
) -> list[str] | tuple[list[str], pd.DataFrame]:
    """Selects top-k features using a robust ensemble of statistical metrics.

    Combines linear, non-linear, and model-based relevance scores.
    Note: Alpha filtering applies only to ANOVA and Chi-square p-values.
    """
    if not features:
        return ([], pd.DataFrame()) if return_scores else []

    working_df = data.copy()

    # 1. Standardize Target
    if task == "classification" and not pd.api.types.is_numeric_dtype(working_df[target]):
        le = LabelEncoder()
        working_df[target] = le.fit_transform(working_df[target].astype(str))

    scores_list = []

    # --- METRIC COLLECTION ---

    # Spearman (Absolute)
    corr_df = rank_correlation(working_df, target, features, method="spearman")
    scores_list.append(corr_df.assign(abs_corr=corr_df["correlation"].abs())[["feature", "abs_corr"]])

    # ANOVA (F-score + P-value)
    f_df, p_df = compute_anova_f(working_df, target, features, task=task, pivot=False)
    scores_list.extend([f_df[["feature", "f_score"]], p_df[["feature", "p_value"]]])

    # Mutual Information
    mi_df = compute_mutual_information(working_df, target, features, task=task, random_state=random_state, pivot=False)
    scores_list.append(mi_df.rename(columns={"score": "mi_score"})[["feature", "mi_score"]])

    # Xi Correlation
    if include_xi:
        xi_df = compute_xicorr(working_df, target, features)
        scores_list.append(xi_df.rename(columns={"col2": "feature", "xicor": "xi_score"})[["feature", "xi_score"]])

    # PPS
    if include_pps:
        # Note: mapping random_state to internal random_seed parameter
        pps_res = [compute_ppscore(working_df, x=f, y=target, random_seed=random_state) for f in features]
        scores_list.append(
            pd.DataFrame(pps_res).rename(columns={"x": "feature", "ppscore": "pps_score"})[["feature", "pps_score"]],
        )

    # Random Forest Importance
    if include_rf:
        rf_df = compute_rf_importance(working_df, target, features, task=task, random_state=random_state, pivot=False)
        scores_list.append(rf_df[["feature", "rf_importance"]])

    # Chi-Square (Classification only, non-negative values)
    if include_chi2 and task == "classification":
        if (working_df[features] >= 0).all().all():
            chi_df = compute_chi2(working_df, target, features, pivot=False)
            scores_list.append(
                chi_df.rename(columns={"chi2_score": "chi2_score", "p_value": "chi2_p_value"})[
                    ["feature", "chi2_score", "chi2_p_value"]
                ],
            )
        else:
            log.debug("Chi-square skipped: Dataset contains negative values.")

    # 2. MERGE & FILTER
    master_scores = reduce(lambda left, r: pd.merge(left, r, on="feature", how="outer"), scores_list)

    # Apply Significance Filter (Alpha) if p-values are present
    p_cols = [c for c in ["p_value", "chi2_p_value"] if c in master_scores.columns]
    if alpha is not None and p_cols:
        initial_count = len(master_scores)
        # Feature passes if ANY of the p-values meet the threshold
        master_scores = master_scores[master_scores[p_cols].min(axis=1) <= alpha].copy()
        log.debug("Alpha filter (p <= %s) removed %d features", alpha, initial_count - len(master_scores))

    if master_scores.empty:
        log.warning("Selection failed: No features passed the p-value threshold.")
        return ([], master_scores) if return_scores else []

    # 3. ROBUST RANK AGGREGATION
    # Identify score columns (ignore metadata, raw correlations, and p-values)
    exclude = ["feature", "target", "p_value", "chi2_p_value", "correlation"]
    rank_input_cols = [c for c in master_scores.columns if c not in exclude]

    # NaN Handling: Fill with 0 (worst case) then rank (Higher = Better)
    ranks = master_scores[rank_input_cols].fillna(0).rank(ascending=True)

    # Arithmetic Mean
    master_scores["arith_rank"] = ranks.mean(axis=1)

    # Geometric Mean (Penalizes 'one-hit wonders')
    master_scores["geom_rank"] = np.exp(np.log(ranks).mean(axis=1))

    # Borda Count (Consensus sum)
    master_scores["borda_count"] = ranks.sum(axis=1)

    # 4. FINAL SELECTION
    sort_col = rank_aggregation if rank_aggregation in master_scores.columns else "borda_count"
    master_scores = master_scores.sort_values(sort_col, ascending=False).reset_index(drop=True)

    top_features = master_scores.head(top_k)["feature"].tolist()

    log.info("Selected top %d features using %s", len(top_features), sort_col)
    return (top_features, master_scores) if return_scores else top_features
