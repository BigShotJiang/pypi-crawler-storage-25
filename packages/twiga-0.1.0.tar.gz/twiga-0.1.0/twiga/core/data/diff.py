from typing import Any, Self

import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin


class TimeSeriesDifferentiator(BaseEstimator, TransformerMixin):
    """Transforms time series data using N-th order differentiation.

    This transformer calculates the difference between consecutive points to
    remove trends. It stores the necessary boundary values to allow for
    perfect reconstruction (inverse transformation) of the original scale.

    Attributes:
        order (int): The number of times differentiation is applied.
        history_ (dict): Internal storage for boundary values (initial and last)
            needed to reverse the transformation.
    """

    def __init__(self, order: int = 1) -> None:
        """Initializes the transformer.

        Args:
            order: The order of differentiation. Must be >= 1.
        """
        if order < 1:
            raise ValueError(f"Order must be >= 1, got {order}")
        self.order = order
        self.history_: dict[str, list[float]] = {}

    def fit(self, X: np.ndarray, y: Any = None) -> Self:
        """Stores anchor values needed to reverse differentiation.

        Args:
            X: 1D NumPy array representing the time series.
            y: Ignored. Included for Scikit-Learn API compatibility.

        Returns:
            Self: The fitted transformer instance.
        """
        # Ensure 1D
        data = X.flatten()

        initials = []
        lasts = []

        # Iteratively differentiate to capture the 'seed' values for each order
        current_series = data.copy()
        for _ in range(self.order):
            initials.append(float(current_series[0]))
            lasts.append(float(current_series[-1]))
            current_series = np.diff(current_series)

        self.history_ = {"initial_values": initials, "last_values": lasts}
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        """Applies N-th order differentiation.

        Args:
            X: 1D NumPy array to transform.

        Returns:
            np.ndarray: Differentiated series, padded with NaNs to maintain
                the original input length.
        """
        diffed = np.diff(X.flatten(), n=self.order)
        # Pad with NaNs at the beginning to keep array size consistent
        return np.concatenate([np.full(self.order, np.nan), diffed])

    def inverse_transform(self, X: np.ndarray) -> np.ndarray:
        """Reverts differentiation using stored initial values.

        Args:
            X: Differentiated 1D NumPy array (can contain leading NaNs).

        Returns:
            np.ndarray: The reconstructed original time series.
        """
        # Remove NaNs
        res = X[~np.isnan(X)].copy()

        # Reverse the process: Start from the highest order and integrate up
        for i in reversed(range(self.order)):
            seed = self.history_["initial_values"][i]
            res = np.cumsum(np.insert(res, 0, seed))

        return res

    def forecast_inverse(self, predictions: np.ndarray) -> np.ndarray:
        """Reverts differentiation for future predictions.

        Uses the 'last_values' from the training set to project predictions
        back into the original data scale.

        Args:
            predictions: Differentiated predicted values.

        Returns:
            np.ndarray: Predictions scaled to the original series.
        """
        res = predictions.copy()
        for i in reversed(range(self.order)):
            last_val = self.history_["last_values"][i]
            res = np.cumsum(res) + last_val

        return res
