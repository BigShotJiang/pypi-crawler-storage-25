"""SHAP-based feature attribution for Twiga ML models.

Requires the ``explain`` extra::

    pip install 'twiga[explain]'
"""

from twiga.core.exceptions import require_extra

require_extra("shap", "explain")

from twiga.core.explain.shap_explainer import ShapExplainer, ShapResult  # noqa: E402

__all__ = ["ShapExplainer", "ShapResult"]
