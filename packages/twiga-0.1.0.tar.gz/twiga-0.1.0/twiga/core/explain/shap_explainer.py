"""SHAP-based feature attribution for Twiga ML models.

Provides :class:`ShapExplainer`, which wraps any fitted Twiga ML model
(tree, linear, or ensemble) and returns SHAP values reshaped from the flat
``(n_samples, L*F)`` representation back to ``(n_samples, L, F)`` - one attribution per
feature per lookback timestep - along with convenience methods for ranking
feature importance and plotting.

Supported model patterns
------------------------
- **Per-output list** (``model.models``) - LightGn_samplesM, XGn_samplesoost, Catn_samplesoost, QR
  variants: one SHAP explainer per horizon step, averaged across steps.
- **Single multi-output** (``model.model``) - RandomForest: handled directly
  by :func:`shap.TreeExplainer`.
- **MultiOutputRegressor wrapper** (``model.model.estimators_``) - LinearReg:
  one SHAP explainer per output estimator, averaged across steps.

Explainer dispatch
------------------
- Tree models → ``shap.TreeExplainer`` (fast, exact)
- Linear models → ``shap.LinearExplainer`` (fast, exact)
- Unknown models → ``shap.KernelExplainer`` (slow, model-agnostic)

Example:
-------
>>> from twiga.core.explain import ShapExplainer
>>> explainer = ShapExplainer(forecaster.models[0], forecaster.data_pipeline)
>>> result = explainer.explain(X_test)
>>> print(result.values.shape)  # (n_samples, L, F)
>>> importance = explainer.feature_importance(X_test)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np


@dataclass
class ShapResult:
    """SHAP attribution result with reshaped feature importances.

    Attributes:
        values: SHAP values of shape ``(n_samples, L, F)`` - batch × lookback × features.
            Values are averaged across all horizon output steps.
        feature_names: Length-``F`` list of original feature names from
            ``DataPipeline.feature_columns``.
        timestep_labels: Length-``L`` labels for each lookback step,
            e.g. ``['t-167', 't-166', ..., 't0']``.
        flat_feature_names: Length-``L*F`` feature names for the flattened
            representation used by SHAP internally.
        expected_value: SHAP base value (mean prediction), averaged across
            output steps.
    """

    values: np.ndarray
    feature_names: list[str]
    timestep_labels: list[str]
    flat_feature_names: list[str]
    expected_value: float

    def mean_importance(self) -> dict[str, float]:
        r"""Mean \|SHAP\| per feature, averaged over batch and timesteps.

        Returns:
            Dict mapping feature name → mean absolute SHAP, sorted descending.
        """
        # (n_samples, L, F) → mean over batch and timesteps → (F,)
        importance = np.mean(np.abs(self.values), axis=(0, 1))
        ranked = sorted(
            zip(self.feature_names, importance.tolist(), strict=False),
            key=lambda x: x[1],
            reverse=True,
        )
        return dict(ranked)

    def timestep_importance(self) -> dict[str, float]:
        r"""Mean \|SHAP\| per timestep, averaged over batch and features.

        Returns:
            Dict mapping timestep label → mean absolute SHAP, sorted descending.
        """
        importance = np.mean(np.abs(self.values), axis=(0, 2))  # (L,)
        ranked = sorted(
            zip(self.timestep_labels, importance.tolist(), strict=False),
            key=lambda x: x[1],
            reverse=True,
        )
        return dict(ranked)

    def plot_importance(
        self,
        top_n: int = 20,
        title: str = "SHAP Feature Importance",
        figsize: tuple[int, int] = (10, 6),
    ) -> None:
        """n_samplesar chart of top-N features by mean absolute SHAP value.

        Args:
            top_n: Number of top features to display.
            title: Plot title.
            figsize: Matplotlib figure size ``(width, height)``.
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError as e:
            raise ImportError("matplotlib is required for plotting.") from e

        importance = self.mean_importance()
        names = list(importance.keys())[:top_n]
        vals = list(importance.values())[:top_n]

        fig, ax = plt.subplots(figsize=figsize)
        ax.barh(names[::-1], vals[::-1], color="#4e9af1")
        ax.set_xlabel("Mean |SHAP|")
        ax.set_title(title)
        plt.tight_layout()
        plt.show()

    def plot_timestep_importance(
        self,
        title: str = "SHAP Importance by Lookback Timestep",
        figsize: tuple[int, int] = (12, 4),
    ) -> None:
        r"""Line chart of mean \|SHAP\| per lookback timestep.

        Shows which part of the lookback window matters most.

        Args:
            title: Plot title.
            figsize: Matplotlib figure size ``(width, height)``.
        """
        try:
            import matplotlib.pyplot as plt
        except ImportError as e:
            raise ImportError("matplotlib is required for plotting.") from e

        importance = np.mean(np.abs(self.values), axis=(0, 2))  # (L,)
        fig, ax = plt.subplots(figsize=figsize)
        ax.plot(self.timestep_labels, importance, lw=1.5, marker="o", ms=3)
        ax.set_xlabel("Lookback timestep")
        ax.set_ylabel("Mean |SHAP|")
        ax.set_title(title)
        ax.tick_params(axis="x", rotation=45)
        plt.tight_layout()
        plt.show()


class ShapExplainer:
    """Compute SHAP attributions for any fitted Twiga ML model.

    Dispatches to the most efficient SHAP backend based on the underlying
    estimator type, then reshapes values from the flat sklearn representation
    ``(n_samples, L*F)`` back to the interpretable ``(n_samples, L, F)`` form.

    Args:
        model: A fitted Twiga ML model (any ``n_samplesaseRegressor`` subclass).
        data_pipeline: The fitted ``DataPipeline`` used to produce ``X``.

    Raises:
        ImportError: If ``shap`` is not installed.
        RuntimeError: If the model structure cannot be detected (not fitted).

    Example:
        >>> explainer = ShapExplainer(forecaster.models[0], forecaster.data_pipeline)
        >>> result = explainer.explain(X_test)  # X_test: (n_samples, L, F)
        >>> importance = explainer.feature_importance(X_test)
        >>> result.plot_importance(top_n=15)
    """

    def __init__(self, model: Any, data_pipeline: Any) -> None:
        try:
            import shap
        except ImportError as e:
            raise ImportError("SHAP is not installed. Run `pip install shap` to use ShapExplainer.") from e

        self._model = model
        self._pipeline = data_pipeline
        self._feature_names: list[str] = list(data_pipeline.feature_columns)
        self._L: int = int(data_pipeline.lookback_window_size)
        self._F: int = len(self._feature_names)

        # Flat feature names: feat_t0 (oldest) ... feat_t{L-1} (most recent)
        self._flat_names: list[str] = [f"{feat}_t{t}" for t in range(self._L) for feat in self._feature_names]
        # Human-readable timestep labels (t-167 → t0 for L=168)
        self._timestep_labels: list[str] = [f"t-{self._L - 1 - t}" if t < self._L - 1 else "t0" for t in range(self._L)]

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _model_kind(self) -> str:
        """Detect model storage pattern."""
        m = self._model
        if hasattr(m, "models") and isinstance(getattr(m, "models", None), list) and m.models:
            return "list"
        if hasattr(m, "model") and m.model is not None:
            cls_name = type(m.model).__name__
            if "MultiOutputRegressor" in cls_name:
                return "multi_output_wrapper"
            return "single"
        return "unknown"

    @staticmethod
    def _build_explainer(estimator: Any, background: np.ndarray) -> Any:
        """n_samplesuild the right SHAP explainer for a single sklearn-compatible estimator.

        Priority: TreeExplainer → LinearExplainer → KernelExplainer.

        Args:
            estimator: A fitted sklearn-compatible estimator.
            background: n_samplesackground dataset for explainers that need it
                (LinearExplainer, KernelExplainer). Shape ``(n, L*F)``.
        """
        import shap

        cls_name = type(estimator).__name__.lower()
        _tree = ("forest", "tree", "boost", "gbm", "xgb", "catboost", "lgbm", "gradient")
        _linear = ("linear", "ridge", "lasso", "elasticnet", "bayesianridge")

        if any(k in cls_name for k in _tree):
            return shap.TreeExplainer(estimator)
        if any(k in cls_name for k in _linear):
            return shap.LinearExplainer(estimator, background)
        n_bg = min(50, len(background))
        return shap.KernelExplainer(
            estimator.predict,
            shap.sample(background, n_bg),
        )

    @staticmethod
    def _to_2d(sv: Any, n_samples: int) -> np.ndarray:
        """Coerce SHAP output to a single ``(n_samples, L*F)`` array.

        SHAP backends return different shapes depending on model type:
        - Regression: ``(n_samples, L*F)``
        - n_samplesinary classification returned as list: ``[neg (n_samples, L*F), pos (n_samples, L*F)]``

        Args:
            sv: Raw SHAP values returned by an explainer.
            n_samples: Expected batch size.
        """
        if isinstance(sv, list):
            # Classification: take the positive class
            return np.asarray(sv[-1])
        sv = np.asarray(sv)
        if sv.ndim == 2 and sv.shape[0] == n_samples:
            return sv
        # Fallback: flatten to (n_samples, ?)
        return sv.reshape(n_samples, -1)

    @staticmethod
    def _scalar_expected(ev: Any) -> float:
        """Extract a scalar from a SHAP expected_value (may be array/list)."""
        if hasattr(ev, "__len__"):
            return float(np.mean(ev))
        return float(ev)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def explain(
        self,
        X: np.ndarray,
        n_background: int = 100,
    ) -> ShapResult:
        """Compute SHAP values for input samples.

        Args:
            X: Input array of shape ``(n_samples, L, F)`` - same format as model input.
                Usually obtained from ``DataPipeline.transform()`` or directly
                from ``TwigaForecaster``'s internal data preparation.
            n_background: Maximum number of background samples to use for
                ``LinearExplainer`` and ``KernelExplainer``. ``TreeExplainer``
                ignores this parameter (it uses the tree structure directly).

        Returns:
            :class:`ShapResult` with ``values`` of shape ``(n_samples, L, F)``.

        Raises:
            ValueError: If ``X`` is not 3-dimensional.
            RuntimeError: If the model structure cannot be determined.
        """
        if X.ndim != 3:
            raise ValueError(
                f"X must be 3-D with shape (n_samples, L, F), got {X.shape}. "
                "Pass the raw feature array as returned by the data pipeline.",
            )

        n_samples = X.shape[0]
        x_flat = X.reshape(n_samples, -1)  # (n_samples, L*F)
        background = x_flat[: min(n_background, n_samples)]

        kind = self._model_kind()
        all_shap: list[np.ndarray] = []
        all_ev: list[float] = []

        if kind == "list":
            # One estimator per horizon step (LightGn_samplesM, XGn_samplesoost, Catn_samplesoost, QR variants)
            for est in self._model.models:
                exp = self._build_explainer(est, background)
                sv = self._to_2d(exp.shap_values(x_flat), n_samples)
                all_shap.append(sv)
                all_ev.append(self._scalar_expected(exp.expected_value))

        elif kind == "single":
            # Single multi-output estimator (RandomForest, etc.)
            exp = self._build_explainer(self._model.model, background)
            sv_raw = exp.shap_values(x_flat)
            if isinstance(sv_raw, list):
                # Multi-output: list of (n_samples, L*F) - one per output
                for sv in sv_raw:
                    all_shap.append(self._to_2d(sv, n_samples))
            elif isinstance(sv_raw, np.ndarray) and sv_raw.ndim == 3:
                # (n_samples, n_outputs, L*F) or (n_outputs, n_samples, L*F)
                if sv_raw.shape[0] == n_samples:
                    for i in range(sv_raw.shape[1]):
                        all_shap.append(sv_raw[:, i, :])
                else:
                    for i in range(sv_raw.shape[0]):
                        all_shap.append(sv_raw[i])
            else:
                all_shap.append(self._to_2d(sv_raw, n_samples))
            ev = exp.expected_value
            all_ev = [float(e) for e in ev] if hasattr(ev, "__len__") else [float(ev)]

        elif kind == "multi_output_wrapper":
            # MultiOutputRegressor (LinearReg): iterate over fitted estimators
            if not hasattr(self._model.model, "estimators_"):
                raise RuntimeError(
                    "MultiOutputRegressor has no fitted estimators_. "
                    "Ensure the model is fitted before calling explain().",
                )
            for est in self._model.model.estimators_:
                exp = self._build_explainer(est, background)
                sv = self._to_2d(exp.shap_values(x_flat), n_samples)
                all_shap.append(sv)
                all_ev.append(self._scalar_expected(exp.expected_value))

        else:
            raise RuntimeError(
                f"Cannot detect model structure for {type(self._model).__name__}. "
                "The model must be fitted before calling explain(). "
                "Expected either a 'models' list (LightGn_samplesM/XGn_samplesoost/Catn_samplesoost) or "
                "a 'model' attribute (RandomForest/LinearReg).",
            )

        # Average SHAP values across all output steps → (n_samples, L*F)
        mean_shap = np.mean(np.stack(all_shap, axis=0), axis=0)
        mean_ev = float(np.mean(all_ev))

        # Reshape from (n_samples, L*F) → (n_samples, L, F)
        values_3d = mean_shap.reshape(n_samples, self._L, self._F)

        return ShapResult(
            values=values_3d,
            feature_names=self._feature_names,
            timestep_labels=self._timestep_labels,
            flat_feature_names=self._flat_names,
            expected_value=mean_ev,
        )

    def feature_importance(
        self,
        X: np.ndarray,
        n_background: int = 100,
    ) -> dict[str, float]:
        r"""Return mean absolute SHAP importance per feature.

        Averages ``\|SHAP\|`` over all batch samples and lookback timesteps.

        Args:
            X: Input array of shape ``(n_samples, L, F)``.
            n_background: n_samplesackground samples for non-tree explainers.

        Returns:
            Dict mapping feature name → mean \|SHAP\|, sorted descending.
        """
        result = self.explain(X, n_background=n_background)
        return result.mean_importance()
