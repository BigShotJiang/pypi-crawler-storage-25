from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.special import expit

from twiga.forecaster.result import ForecastResult

from .point import get_pointwise_metrics, validate_inputs


def winkler_score(
    pred: np.ndarray,
    true: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    alpha: float | None = None,
) -> float:
    r"""Calculate the median Winkler score to evaluate prediction interval coverage and width.

    The Winkler score for each data point is:

    .. math::

        WinklerScore = Upper - Lower + \frac{2}{\alpha} \times (Lower - True)
            \times (True < Lower) + \frac{2}{\alpha} \times (True - Upper) \times (True > Upper)

    This function returns the median of these scores, as per Winkler's 1972 paper:
    R. L. Winkler, "A Decision-Theoretic Approach to Interval Estimation,"
    Journal of the American Statistical Association, vol. 67, no. 337, pp. 187–191, 1972.

    Args:
        pred: Predicted values.
        true: True values.
        lower: Lower bounds of the prediction intervals.
        upper: Upper bounds of the prediction intervals.
        alpha: Significance level for the intervals. Defaults to None.

    Returns:
        float: Median Winkler score.

    Raises:
        ValueError: If alpha is None.

    Examples:
        >>> pred = np.array([10, 15, 20, 25, 30])
        >>> true = np.array([11, 14, 19, 26, 29])
        >>> lower = np.array([9, 13, 18, 24, 28])
        >>> upper = np.array([12, 17, 22, 27, 31])
        >>> score = winkler_score(pred, true, lower, upper, 0.05)
        >>> print(f"Median Winkler Score: {score:.2f}")
    """
    if alpha is None:
        raise ValueError("Alpha cannot be None for the Winkler score calculation.")

    scores = (
        upper
        - lower
        + (2.0 / alpha) * (lower - true) * (true < lower)
        + (2.0 / alpha) * (true - upper) * (true > upper)
    )
    return np.median(scores)


def interval_coverage(true: np.ndarray, lower: np.ndarray, upper: np.ndarray) -> float:
    r"""Calculate the coverage proportion of prediction intervals.

    The coverage is:

    .. math::

        Coverage = \frac{1}{n} \sum_{i=1}^{n} \mathbb{1}(lower_i \leq true_i \leq upper_i)

    where :math:`\mathbb{1}` is the indicator function (1 if true, 0 otherwise), and
    :math:`n` is the number of observations.

    Args:
        true: True values.
        lower: Lower bounds of the prediction intervals.
        upper: Upper bounds of the prediction intervals.

    Returns:
        float: Proportion of true values within the intervals (0 to 1).

    Examples:
        >>> true = np.array([10, 15, 20, 25, 30])
        >>> lower = np.array([8, 14, 18, 22, 28])
        >>> upper = np.array([12, 16, 22, 28, 32])
        >>> coverage = interval_coverage(true, lower, upper)
        >>> print(f"Coverage: {coverage:.2f}")
    """
    coverage = ((true >= lower) & (true <= upper)).mean()
    return coverage


def ace(coverage: float, alpha: float) -> float:
    r"""Calculate the Average Coverage Error (ACE).

    The ACE is:

    .. math::

        ACE = Coverage - (1 - \alpha)

    where :math:`Coverage` is the proportion of true values within the prediction intervals.

    Args:
        coverage: Coverage proportion (0 to 1).
        alpha: Significance level for the prediction intervals.

    Returns:
        float: Average Coverage Error.

    Examples:
        >>> coverage = 0.95
        >>> alpha = 0.05
        >>> error = ace(coverage, alpha)
        >>> print(f"ACE: {error:.2f}")
    """
    return coverage - (1 - alpha)


def nmpi(lower: np.ndarray, upper: np.ndarray, scale: float) -> float:
    r"""Calculate the Normalized Median Prediction Interval (NMPI).

    The NMPI is:

    .. math::

        NMPI = \text{median}(\left| Upper - Lower \right|)


    Args:
        lower: Lower bounds of the prediction intervals.
        upper: Upper bounds of the prediction intervals.
        scale: Scaling factor for the NMPI.

    Returns:
        float: Median prediction interval width.

    Examples:
        >>> lower = np.array([8, 14, 18, 22, 28])
        >>> upper = np.array([12, 16, 22, 28, 32])
        >>> width = nmpi(lower, upper)
        >>> print(f"NMPI: {width:.2f}")
    """
    return np.median(np.abs(upper - lower)) / scale


def gamma_nmpi_score(nmpi: float, true_nmpic: float, k: float = 1, smoothing: float = 1e-6) -> float:
    r"""Calculate the Gamma NMPI Score.

    The score is:

    .. math::

        \gamma_{NMPI} = 1 - \text{expit}\left( k \times (\text{NMPI}_{diff} - \text{smoothing})^2 \right)

    where :math:`\text{expit}(x) = \frac{1}{1 + e^{-x}}`, and :math:`\text{NMPI}_{diff}` is the
    absolute difference between the calculated and true NMPI.

    Args:
        nmpi: Calculated NMPI value.
        true_nmpic: True NMPI value.
        k: Scaling factor. Defaults to 1.
        smoothing: Smoothing parameter. Defaults to 1e-6.

    Returns:
        Gamma NMPI Score.

    Examples:
        >>> nmpi_val = 4.0
        >>> true_nmpic_val = 3.5
        >>> score = gamma_nmpi_score(nmpi_val, true_nmpic_val, k=1.0, smoothing=0.5)
        >>> print(f"Gamma NMPI Score: {score:.2f}")
    """
    nmpic_diff = np.abs(nmpi - true_nmpic)
    return 1 - expit(k * (nmpic_diff - smoothing) ** 2)


def standardized_gamma_nmpi(nmpi: float, true_nmpic: float, k: float = 1, smoothing: float = 1e-10) -> float:
    r"""Calculate the standardized gamma NMPI score.

    This score quantifies the NMPI's position relative to the minimum and maximum possible
      scores based on the true NMPI.

    Args:
        nmpi: NMPI score to standardize.
        true_nmpic: True NMPI score (ground truth).
        k: Scaling factor. Defaults to 1.
        smoothing: Smoothing parameter. Defaults to 1e-10.

    Returns:
        float: Standardized gamma NMPI score.
    """
    score = gamma_nmpi_score(nmpi, true_nmpic, k, smoothing)
    max_score = gamma_nmpi_score(true_nmpic, true_nmpic, k, smoothing)
    min_score_left = gamma_nmpi_score(0.0, true_nmpic, k, smoothing)
    min_score_right = gamma_nmpi_score(1.0, true_nmpic, k, smoothing)

    denom_right = max_score - min_score_right
    denom_left = max_score - min_score_left
    right = 0.0 if denom_right == 0 else (score - min_score_right) / denom_right
    left = 0.0 if denom_left == 0 else (score - min_score_left) / denom_left
    return float(np.where(true_nmpic <= nmpi, right, left))


def gamma_coverage_score(picp: float, alpha: float) -> float:
    r"""Calculate the Gamma Coverage Score.

    The score is:

    .. math::

        \gamma_{\text{coverage}} = \frac{\exp(-\text{diff}) - \exp(-(1 - \alpha))}{1 - \exp(-(1 - \alpha))}

    where :math:`\text{diff} = 1 - \alpha - \text{PICP}` if :math:`\text{PICP} \leq 1 - \alpha`, else 0.

    Args:
        picp (float): Proportion of intervals containing the true value (PICP).
        alpha (float): Significance level for the prediction intervals.

    Returns:
        float: Gamma Coverage Score.

    Raises:
        ValueError: If PICP or alpha is not between 0 and 1.

    Examples:
        >>> picp = 0.95
        >>> alpha = 0.05
        >>> score = gamma_coverage_score(picp, alpha)
        >>> print(f"Gamma Coverage Score: {score:.2f}")
    """
    if not 0 <= picp <= 1:
        raise ValueError("PICP must be between 0 and 1.")
    if not 0 <= alpha <= 1:
        raise ValueError("alpha must be between 0 and 1.")

    diff = np.where(picp <= 1 - alpha, 1 - alpha - picp, 0.0)
    score = np.exp(-diff)
    min_score = np.exp(-(1 - alpha))
    return (score - min_score) / (1 - min_score)


def cwe_score(
    nmpi: float,
    picp: float,
    error: float | None,
    true_nmpic: float,
    alpha: float = 0.90,
    beta: int = 1,
    k: float = 1.0,
    smoothing: float = 1e-6,
) -> float:
    r"""Calculate the Combined Weighting Index (CWI) score for probabilistic forecasts.

    The CWI is:

    .. math::

        CWI = \frac{(1 + \beta^2) \cdot \gamma_{pic} \cdot \gamma_{nmpic}}{\beta^2 \cdot
            \gamma_{nmpic} + \gamma_{pic}}

    Adjusted by :math:`CWI \cdot (1 - \text{error})` if error is provided, and further by
    :math:`\text{picp}` if :math:`\text{picp} \leq 0.5`.

    Args:
        nmpi: NMPI metric value.
        picp: PIC score.
        error: Forecast error (difference from true value).
        true_nmpic: True NMPI score.
        alpha: Significance level for PIC. Defaults to 0.90.
        beta: Calibration emphasis parameter. Defaults to 1.
        k: Scaling factor for NMPI. Defaults to 1.0.
        smoothing: Smoothing parameter. Defaults to 1e-6.

    Returns:
        float: CWI score.
    """
    gamma_pic = gamma_coverage_score(picp=picp, alpha=alpha)
    gamma_nmpic = standardized_gamma_nmpi(nmpi=nmpi, true_nmpic=true_nmpic, k=k, smoothing=smoothing)
    gamma_nmpic = np.where((nmpi <= true_nmpic) & (picp >= alpha), gamma_pic, gamma_nmpic)  # type: ignore[assignment]

    num = (1 + beta**2) * gamma_pic * gamma_nmpic
    denom = (beta**2 * gamma_nmpic) + gamma_pic
    cwe = num / denom

    if error is not None:
        cwe *= 1 - error
    if picp <= 0.5:
        cwe *= picp
    return cwe


def msis(
    true: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    y_train: np.ndarray,
    alpha: float,
    seasonality: int = 1,
) -> float:
    r"""Calculate the Mean Scaled Interval Score (MSIS).

    MSIS is the M4/M5 competition standard for evaluating prediction intervals.
    It measures interval sharpness and coverage simultaneously, scaled by the
    naive seasonal forecast error to make it comparable across series:

    .. math::

        MSIS = \frac{1}{n} \sum_{t=1}^{n} \frac{W_t}{\frac{1}{T-s}
            \sum_{i=s+1}^{T} |y_i - y_{i-s}|}

    where :math:`W_t = (U_t - L_t) + \frac{2}{\alpha}(L_t - y_t)\mathbb{1}_{y_t < L_t}
    + \frac{2}{\alpha}(y_t - U_t)\mathbb{1}_{y_t > U_t}`, :math:`s` is the seasonality
    period, and :math:`T` is the length of the training series.

    Args:
        true: True values for the forecast period, shape ``(n,)``.
        lower: Lower bounds of prediction intervals, shape ``(n,)``.
        upper: Upper bounds of prediction intervals, shape ``(n,)``.
        y_train: Historical training values used to compute the seasonal scaling
            factor, shape ``(T,)`` where ``T > s``.
        alpha: Significance level of the prediction interval, in ``(0, 1)``.
        seasonality: Seasonal period ``s`` for the naive scaling baseline.
            Defaults to ``1`` (non-seasonal naïve).

    Returns:
        float: MSIS value. Lower is better.

    Raises:
        ValueError: If ``alpha`` is not in ``(0, 1)``.
        ValueError: If ``len(y_train) <= seasonality``.
        ValueError: If shapes of ``true``, ``lower``, and ``upper`` do not match.

    References:
        Makridakis et al. (2020). The M4 Competition: 100,000 time series and
        61 forecasting methods. *International Journal of Forecasting*, 36(1), 54–74.

    Examples:
        >>> import numpy as np
        >>> true = np.array([2.0, 3.0, 4.0])
        >>> lower = np.array([1.5, 2.5, 3.5])
        >>> upper = np.array([2.5, 3.5, 4.5])
        >>> y_train = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        >>> msis(true, lower, upper, y_train, alpha=0.1)
    """
    if not 0 < alpha < 1:
        raise ValueError(f"alpha must be in (0, 1), got {alpha}")
    if len(y_train) <= seasonality:
        raise ValueError(f"len(y_train)={len(y_train)} must be > seasonality={seasonality}.")
    true = np.asarray(true, dtype=float)
    lower = np.asarray(lower, dtype=float)
    upper = np.asarray(upper, dtype=float)
    if true.shape != lower.shape or true.shape != upper.shape:
        raise ValueError("true, lower, and upper must have the same shape.")

    winkler = (
        (upper - lower) + (2.0 / alpha) * np.maximum(lower - true, 0.0) + (2.0 / alpha) * np.maximum(true - upper, 0.0)
    )
    y_train = np.asarray(y_train, dtype=float)
    naive_mae = np.mean(np.abs(y_train[seasonality:] - y_train[:-seasonality]))
    return float(np.mean(winkler) / naive_mae)


def get_interval_metrics(
    pred: np.ndarray,
    true: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    alpha: float = 0.01,
    true_nmpi: float | None = None,
) -> pd.DataFrame:
    """Calculates interval prediction metrics and returns them as a DataFrame.

    Args:
        pred: Predicted values as a NumPy array.
        true: True values as a NumPy array.
        lower: Lower bounds of prediction intervals as a NumPy array.
        upper: Upper bounds of prediction intervals as a NumPy array.
        alpha: Significance level for metrics (default: 0.01). Must be in (0, 1).
        true_nmpi: True normalized mean prediction interval. If None, computed as true.std().

    Returns:
        A pandas DataFrame containing the following metrics:
            - Winkler Score
            - Coverage
            - ACE (Absolute Coverage Error)
            - NMPI (Normalized Mean Prediction Interval)
            - CWE (Coverage Width Error)

    Raises:
        ValueError: If inputs are invalid (e.g., mismatched shapes, invalid alpha).
    """
    pred, true = validate_inputs(pred, true)
    lower, upper = validate_inputs(lower, upper)

    if not 0 < alpha < 1:
        raise ValueError(f"alpha must be between 0 and 1, got {alpha}")
    if true_nmpi is not None and true_nmpi <= 0:
        raise ValueError(f"true_nmpi must be positive, got {true_nmpi}")

    coverage = interval_coverage(true, lower, upper)
    interval_width = nmpi(lower, upper, scale=true.max())
    metrics = {
        "winkle-score": winkler_score(pred, true, lower, upper, alpha),
        "picp": coverage,
        "ace": ace(coverage, alpha),
        "nmpi": interval_width,
        "cwe": cwe_score(
            nmpi=interval_width,
            picp=coverage,
            error=None,
            true_nmpic=true.std() if true_nmpi is None else true_nmpi,
            alpha=alpha,
        ),
    }
    return pd.DataFrame.from_dict(metrics, orient="index").T


def evaluate_interval_forecast(
    result: ForecastResult,
    alpha: float = 0.01,
    true_nmpi: float | None = None,
) -> pd.DataFrame:
    """Evaluate interval forecasts by computing daily point and interval metrics.

    Args:
        result: :class:`~twiga.forecaster.result.ForecastResult` with
            ``ground_truth``, ``lower``, and ``upper`` set,
            ``kind=ForecastKind.INTERVAL``.
        alpha: Significance level used for Winkler score and coverage
            computations.  Must be in ``(0, 1)``.  Defaults to ``0.01``.
        true_nmpi: Reference normalised median prediction interval width.
            When ``None`` the standard deviation of the true values is used.

    Returns:
        DataFrame of per-day, per-target point and interval metrics indexed
        by daily timestamp.
    """
    from twiga.core.metrics._core import _evaluate_loop

    def metric_fn(day_idx: int, target_idx: int) -> pd.DataFrame:
        true_vals = result.ground_truth[day_idx, :, target_idx]  # type: ignore[index]
        pred_vals = result.loc[day_idx, :, target_idx]
        lower_vals = result.lower[day_idx, :, target_idx]  # type: ignore[index]
        upper_vals = result.upper[day_idx, :, target_idx]  # type: ignore[index]
        point_scores = get_pointwise_metrics(y=true_vals, y_hat=pred_vals, metric_names=None)
        interval_scores = get_interval_metrics(pred_vals, true_vals, lower_vals, upper_vals, alpha, true_nmpi)
        return pd.concat([point_scores, interval_scores], axis=1)

    return _evaluate_loop(result, metric_fn)
