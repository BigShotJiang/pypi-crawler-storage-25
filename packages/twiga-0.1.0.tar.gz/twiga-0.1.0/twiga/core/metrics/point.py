from __future__ import annotations

from collections.abc import Callable
from typing import Any

import numpy as np
from numpy.typing import ArrayLike
import pandas as pd

from twiga.core.utils.logger import get_logger
from twiga.forecaster.result import ForecastResult

log = get_logger(__name__)

# ArrayLike = np.ndarray | pd.Series


def validate_inputs(
    y: np.ndarray | pd.Series,
    y_hat: np.ndarray | pd.Series,
    require_1d: bool = False,
) -> tuple[np.ndarray, np.ndarray]:
    """Validate and convert input arrays for metric functions.

    Args:
        y: Actual values.
        y_hat: Predicted values.
        require_1d: If True, ensure inputs are 1D arrays. Defaults to False.

    Returns:
        Validated NumPy arrays for y and y_hat.

    Raises:
        ValueError: If shapes of y and y_hat do not match or if require_1d is True and inputs are not 1D.
    """
    y = np.asarray(y)
    y_hat = np.asarray(y_hat)
    if y.shape != y_hat.shape:
        raise ValueError(f"Shapes of y {y.shape} and y_hat {y_hat.shape} must match.")
    if require_1d and (y.ndim != 1 or y_hat.ndim != 1):
        raise ValueError("Inputs must be 1D arrays.")
    return y, y_hat


def error(y: ArrayLike, y_hat: ArrayLike) -> np.ndarray:
    """Calculate the raw error between actual and predicted values.

    The error is defined as the difference between actual values `y` and predicted values `y_hat`.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.

    Returns:
        Raw errors, `y - y_hat`, with the same shape as inputs.

    Raises:
        ValueError: If `y` and `y_hat` have incompatible shapes.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> error(y, y_hat)
        array([-0.1,  0.1, -0.2])
    """
    y, y_hat = validate_inputs(y, y_hat)
    return y - y_hat


def abs_error(y: ArrayLike, y_hat: ArrayLike) -> np.ndarray:
    """Calculate the absolute error between actual and predicted values.

    The absolute error is the absolute value of the difference between actual values `y` and predicted values `y_hat`.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.

    Returns:
        Absolute errors, `|y - y_hat|`, with the same shape as inputs.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> abs_error(y, y_hat)
        array([0.1, 0.1, 0.2])
    """
    return np.abs(error(y, y_hat))


def res(y: ArrayLike, y_hat: ArrayLike, axis: int = 0) -> float | np.ndarray:
    r"""Calculate the Mean Error (ME) between actual and predicted values.

    The mean error is the average of the raw errors over the specified axis:
    \[
    ME = \frac{1}{T} \sum_{t=1}^{T} (y_t - \hat{y}_t)
    \]
    where \( T \) is the number of samples, \( y_t \) is the actual value, and \( \hat{y}_t \)
    is the predicted value at time \( t \).

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        axis: Axis along which to compute the mean. Defaults to 0.

    Returns:
        Mean error, scalar if 1D input, array if multi-dimensional.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> res(y, y_hat)
        -0.033333333333333326  # Average of [-0.1, 0.1, -0.2]
    """
    return np.nanmean(error(y, y_hat), axis=axis)


def mae(y: ArrayLike, y_hat: ArrayLike, axis: int = 0) -> float | np.ndarray:
    r"""Calculate the Mean Absolute Error (MAE) between actual and predicted values.

    The MAE is the average of the absolute errors over the specified axis:
    \[
    MAE = \frac{1}{T} \sum_{t=1}^{T} |y_t - \hat{y}_t|
    \]
    where \( T \) is the number of samples, \( y_t \) is the actual value, and \( \hat{y}_t \) is
    the predicted value at time \( t \).

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        axis: Axis along which to compute the mean. Defaults to 0.

    Returns:
        MAE, scalar if 1D input, array if multi-dimensional.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> mae(y, y_hat)
        0.13333333333333333  # Average of [0.1, 0.1, 0.2]
    """
    return np.nanmean(abs_error(y, y_hat), axis=axis)


def get_scaled(y: ArrayLike, h: int = 1, metric: str = "mae", axis: int = 0) -> float | np.ndarray:
    r"""Calculate the scaling factor for error metrics based on historical differences.

    The scaling factor \( E_m \) is computed over lagged differences \( y[t+h] - y[t] \):
    - If `metric="mae"`: \( E_m = \frac{1}{n-h} \sum_{i=1}^{n-h} |y_{i+h} - y_i| \),
    - If `metric="mse"`: \( E_m = \frac{1}{n-h} \sum_{i=1}^{n-h} (y_{i+h} - y_i)^2 \),
    - If `metric="rmse"`: \( E_m = \sqrt{\frac{1}{n-h} \sum_{i=1}^{n-h} (y_{i+h} - y_i)^2} \),
    where \( n \) is the length of `y`, and \( h \) is the lag.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        h: Lag or horizon for scaling computation. Defaults to 1.
        metric: Scaling metric ('mae', 'mse', 'rmse'). Defaults to "mae".
        axis: Axis along which to compute the mean. Defaults to 0.

    Returns:
        Scaling factor, scalar if 1D input, array if multi-dimensional.

    Raises:
        ValueError: If `metric` is not one of 'mae', 'mse', or 'rmse'.
        ValueError: If `h` is greater than or equal to the length of `y`.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3, 4, 5])
        >>> get_scaled(y, h=1, metric="mae")
        1.0  # MAE of differences [1, 1, 1, 1]
    """
    y = np.asarray(y)
    if h >= len(y):
        raise ValueError(f"Lag h={h} must be less than the length of y={len(y)}.")
    diff = y[h:] - y[:-h]
    if metric == "mae":
        scale = np.nanmean(np.abs(diff), axis=axis)
    elif metric == "mse":
        scale = np.nanmean(np.power(diff, 2), axis=axis)
    elif metric == "rmse":
        scale = np.sqrt(np.nanmean(np.power(diff, 2), axis=axis))
    else:
        raise ValueError(f"Unknown `metric={metric}`. Must be one of ('mae', 'mse', 'rmse').")
    return scale


def abs_scaled_error(y: ArrayLike, y_hat: ArrayLike, h: int, axis: int = 0, metric: str = "mae") -> np.ndarray:
    r"""Calculate the Absolute Scaled Error (ASE) between actual and predicted values.

    The ASE scales the absolute error by a baseline error metric:
    \[
    ASE = \frac{AE(y_{t_p+1:t_p+T}, \hat{y}_{t_p+1:t_p+T})}{E_m}
    \]
    where \( AE = |y_t - \hat{y}_t| \), and \( E_m \) is the baseline error from `get_scaled`.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        h: Lag or horizon for scaling computation.
        axis: Axis along which to compute the mean for scaling. Defaults to 0.
        metric: Baseline error metric ('mae', 'mse', 'rmse'). Defaults to "mae".

    Returns:
        Absolute scaled errors, same shape as `error(y, y_hat)`.

    Raises:
        ValueError: If shapes of `y` and `y_hat` do not match.
        ValueError: If `h` is greater than or equal to the length of `y`.
        ValueError: If `metric` is invalid.
        ValueError: If scale factor is zero or NaN.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3, 4, 5])
        >>> y_hat = np.array([1.1, 2.2, 3.1, 4.3, 5.2])
        >>> abs_scaled_error(y, y_hat, h=1, metric="mae")
        array([0.1, 0.2, 0.1, 0.3, 0.2])  # Scaled by MAE of [1, 1, 1, 1] = 1.0
    """
    y, y_hat = validate_inputs(y, y_hat)
    scale = get_scaled(y, h, metric, axis)
    if np.any(scale == 0) or np.any(np.isnan(scale)):
        raise ValueError("Scale factor is zero or NaN, cannot compute scaled error.")
    return abs_error(y, y_hat) / scale


def mase(y: ArrayLike, y_hat: ArrayLike, h: int = 1, axis: int = 0) -> float | np.ndarray:
    r"""Calculate the Mean Absolute Scaled Error (MASE) between actual and predicted values.

    The MASE is the mean of the absolute scaled errors:
    \[
    MASE = \frac{1}{T} \sum_{t=1}^{T} \left| \frac{y_t - \hat{y}_t}{\frac{1}{n-h}
    \sum_{i=h+1}^{n} |y_i - y_{i-h}|} \right|
    \]
    where \( T \) is the forecast period length, \( n \) is the total observations, and \( h \) is the lag.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        h: Lag or horizon for scaling. Defaults to 1.
        axis: Axis along which to compute the mean. Defaults to 0.

    Returns:
        MASE, scalar if 1D input, array if multi-dimensional.

    Raises:
        ValueError: If shapes of `y` and `y_hat` do not match.
        ValueError: If `h` is invalid or scale is zero/NaN.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3, 4, 5])
        >>> y_hat = np.array([1.1, 2.2, 3.1, 4.3, 5.2])
        >>> mase(y, y_hat, h=1)
        0.18  # Mean of [0.1, 0.2, 0.1, 0.3, 0.2] scaled by 1.0
    """
    return np.nanmean(abs_scaled_error(y, y_hat, h, axis, metric="mae"), axis=axis)


def squared_error(y: ArrayLike, y_hat: ArrayLike) -> np.ndarray:
    """Calculate the squared error between actual and predicted values.

    The squared error is the square of the difference between actual values `y` and predicted values `y_hat`.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.

    Returns:
        Squared errors, `(y - y_hat)^2`, with the same shape as inputs.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> squared_error(y, y_hat)
        array([0.01, 0.01, 0.04])
    """
    return np.square(error(y, y_hat))


def mse(y: ArrayLike, y_hat: ArrayLike, axis: int = 0) -> float | np.ndarray:
    r"""Calculate the Mean Squared Error (MSE) between actual and predicted values.

    The MSE is the average of the squared errors over the specified axis:
    \[
    MSE = \frac{1}{T} \sum_{t=1}^{T} (y_t - \hat{y}_t)^2
    \]
    where \( T \) is the number of samples, \( y_t \) is the actual value, and \( \hat{y}_t \) is the predicted value.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        axis: Axis along which to compute the mean. Defaults to 0.

    Returns:
        MSE, scalar if 1D input, array if multi-dimensional.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> mse(y, y_hat)
        0.02  # Average of [0.01, 0.01, 0.04]
    """
    return np.nanmean(squared_error(y, y_hat), axis=axis)


def squared_scaled_error(y: ArrayLike, y_hat: ArrayLike, h: int, axis: int = 0) -> np.ndarray:
    r"""Calculate the Squared Scaled Error (SSE) between actual and predicted values.

    The SSE scales the squared error by the MSE of a naive forecast:
    \[
    SSE = \frac{(y_t - \hat{y}_t)^2}{\frac{1}{n-h} \sum_{i=h+1}^{n} (y_i - y_{i-h})^2}
    \]
    where \( h \) is the lag, and \( n \) is the total observations.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        h: Lag or horizon for scaling computation.
        axis: Axis along which to compute the mean for scaling. Defaults to 0.

    Returns:
        Squared scaled errors, same shape as `squared_error(y, y_hat)`.

    Raises:
        ValueError: If shapes of `y` and `y_hat` do not match.
        ValueError: If `h` is invalid or scale is zero/NaN.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3, 4, 5])
        >>> y_hat = np.array([1.1, 2.2, 3.1, 4.3, 5.2])
        >>> squared_scaled_error(y, y_hat, h=1)
        array([0.01, 0.04, 0.01, 0.09, 0.04])  # Scaled by MSE of [1, 1, 1, 1] = 1.0
    """
    y, y_hat = validate_inputs(y, y_hat)
    scale = get_scaled(y, h, metric="mse", axis=axis)
    if np.any(scale == 0) or np.any(np.isnan(scale)):
        raise ValueError("Scale factor is zero or NaN, cannot compute scaled error.")
    return squared_error(y, y_hat) / scale


def msse(y: ArrayLike, y_hat: ArrayLike, h: int = 1, axis: int = 0) -> float | np.ndarray:
    r"""Calculate the Mean Squared Scaled Error (MSSE) between actual and predicted values.

    The MSSE is the mean of the squared scaled errors:
    \[
    MSSE = \frac{1}{T} \sum_{t=1}^{T} \frac{(y_t - \hat{y}_t)^2}{\frac{1}{n-h} \sum_{i=h+1}^{n} (y_i - y_{i-h})^2}
    \]
    where \( T \) is the forecast period length, \( n \) is the total observations, and \( h \) is the lag.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        h: Lag or horizon for scaling computation.
        axis: Axis along which to compute the mean. Defaults to 0.

    Returns:
        MSSE, scalar if 1D input, array if multi-dimensional.

    Raises:
        ValueError: If shapes of `y` and `y_hat` do not match.
        ValueError: If `h` is invalid or scale is zero/NaN.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3, 4, 5])
        >>> y_hat = np.array([1.1, 2.2, 3.1, 4.3, 5.2])
        >>> msse(y, y_hat, h=1)
        0.038  # Mean of [0.01, 0.04, 0.01, 0.09, 0.04] scaled by 1.0
    """
    return np.nanmean(squared_scaled_error(y, y_hat, h, axis), axis=axis)


def rmse(y: ArrayLike, y_hat: ArrayLike, axis: int = 0) -> float | np.ndarray:
    r"""Calculate the Root Mean Squared Error (RMSE) between actual and predicted values.

    The RMSE is the square root of the mean squared error:
    \[
    RMSE = \sqrt{\frac{1}{T} \sum_{t=1}^{T} (y_t - \hat{y}_t)^2}
    \]
    where \( T \) is the number of samples, \( y_t \) is the actual value, and \( \hat{y}_t \) is the predicted value.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        axis: Axis along which to compute the mean. Defaults to 0.

    Returns:
        RMSE, scalar if 1D input, array if multi-dimensional.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> rmse(y, y_hat)
        0.14142135623730953  # sqrt(0.02)
    """
    return np.sqrt(mse(y, y_hat, axis))


def nrmse(y, y_hat, scale=None, axis=0, scale_method="max"):
    """Calculate the Normalized Root Mean Squared Error (NRMSE) between actual and predicted values.

    NRMSE is computed as RMSE divided by a scaling factor, which can be provided or computed from `y`.

    Args:
        y: Actual values.
        y_hat: Predicted values, same shape as `y`.
        scale: Scaling factor. If None, computed based on `scale_method`.
        axis: Axis along which to compute RMSE and scaling factor. Defaults to 0.
        scale_method: Method to compute scale if not provided:
            - "max": Maximum of `y`.
            - "range": Range (max - min) of `y`.
            - "mean": Mean of `y`.
            Defaults to "max".

    Returns:
        NRMSE value(s).

    Raises:
        ValueError: If `y` and `y_hat` shapes don’t match or if scale is zero.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3, 4, 5])
        >>> y_hat = np.array([1.1, 2.2, 3.1, 4.3, 5.2])
        >>> nrmse(y, y_hat)
        0.03898720291794133  # RMSE / max(y)
    """
    y = np.asarray(y)
    y_hat = np.asarray(y_hat)
    if y.shape != y_hat.shape:
        raise ValueError(f"Shapes of y {y.shape} and y_hat {y_hat.shape} must match.")
    if scale is None:
        if scale_method == "max":
            scale = np.max(y, axis=axis)
        elif scale_method == "range":
            scale = np.ptp(y, axis=axis)
        elif scale_method == "mean":
            scale = np.mean(y, axis=axis)
        else:
            raise ValueError(f"Unknown scale_method '{scale_method}'. Use 'max', 'range', or 'mean'.")
    else:
        scale = np.asarray(scale)
    if np.any(scale == 0):
        raise ValueError("Scale factor must be non-zero.")
    rmse_value = rmse(y, y_hat, axis=axis)
    return rmse_value / scale


def rmsse(y: ArrayLike, y_hat: ArrayLike, h: int = 1, axis: int = 0) -> float | np.ndarray:
    r"""Calculate the Root Mean Squared Scaled Error (RMSSE) between actual and predicted values.

    The RMSSE scales the RMSE by the RMSE of a naive forecast:
    \[
    RMSSE = \frac{\sqrt{\frac{1}{T} \sum_{t=1}^{T} (y_t - \hat{y}_t)^2}}{\sqrt{\frac{1}{n-h}
    \sum_{i=h+1}^{n}(y_i - y_{i-h})^2}}
    \]
    where \( T \) is the forecast period length, \( n \) is the total observations, and \( h \) is the lag.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        h: Lag or horizon for scaling computation.
        axis: Axis along which to compute the mean. Defaults to 0.

    Returns:
        RMSSE, scalar if 1D input, array if multi-dimensional.

    Raises:
        ValueError: If shapes of `y` and `y_hat` do not match.
        ValueError: If `h` is invalid or scale is zero/NaN.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3, 4, 5])
        >>> y_hat = np.array([1.1, 2.2, 3.1, 4.3, 5.2])
        >>> rmsse(y, y_hat, h=1)
        0.19518001458970666  # sqrt(0.038) / sqrt(1.0)
    """
    scale = get_scaled(y, h, metric="rmse", axis=axis)
    if np.any(scale == 0) or np.any(np.isnan(scale)):
        raise ValueError("Scale factor is zero or NaN, cannot compute scaled error.")
    return rmse(y, y_hat, axis) / scale


def absolute_percentage_error(y: ArrayLike, y_hat: ArrayLike) -> np.ndarray:
    r"""Calculate the Absolute Percentage Error (APE) between actual and predicted values.

    The APE is the absolute error as a percentage of the actual value:
    \[
    APE = 100 \times \frac{|y_t - \hat{y}_t|}{|y_t|}
    \]

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.

    Returns:
        APE values in percent, same shape as inputs.

    Raises:
        ValueError: If any `y` value is zero.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> absolute_percentage_error(y, y_hat)
        array([10.0, 5.0, 6.66666667])
    """
    y, y_hat = validate_inputs(y, y_hat)
    if not (y != 0).all():
        raise ValueError("`actual_series` must be strictly positive to compute the MAPE.")
    return 100 * (abs_error(y, y_hat) / np.abs(y))


def mape(y: ArrayLike, y_hat: ArrayLike, axis: int = 0) -> float | np.ndarray:
    r"""Calculate the Mean Absolute Percentage Error (MAPE) between actual and predicted values.

    The MAPE is the mean of the absolute percentage errors:
    \[
    MAPE = \frac{1}{T} \sum_{t=1}^{T} 100 \times \frac{|y_t - \hat{y}_t|}{|y_t|}
    \]
    where \( T \) is the number of samples.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        axis: Axis along which to compute the mean. Defaults to 0.

    Returns:
        MAPE in percent, scalar if 1D input, array if multi-dimensional.

    Raises:
        ValueError: If any `y` value is zero.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> mape(y, y_hat)
        7.222222222222222  # Mean of [10.0, 5.0, 6.66666667]
    """
    return np.nanmean(absolute_percentage_error(y, y_hat), axis=axis)


def wmape(y: ArrayLike, y_hat: ArrayLike, axis: int = 0) -> float | np.ndarray:
    r"""Calculate the Weighted Mean Absolute Percentage Error (WMAPE) between actual and predicted values.

    The WMAPE is the sum of absolute errors divided by the sum of actual values, expressed as a percentage:
    \[
    WMAPE = 100 \times \frac{\sum_{t=1}^{T} |y_t - \hat{y}_t|}{\sum_{t=1}^{T} |y_t|}
    \]
    where \( T \) is the number of samples.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        axis: Axis along which to compute the sums. Defaults to 0.

    Returns:
        WMAPE in percent, scalar if 1D input, array if multi-dimensional.

    Raises:
        ValueError: If the sum of `y` along the axis is zero.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> wmape(y, y_hat)
        6.666666666666667  # 100 * (0.1 + 0.1 + 0.2) / (1 + 2 + 3)
    """
    y, y_hat = validate_inputs(y, y_hat)
    y_sum = np.sum(np.abs(y), axis=axis)
    if np.any(y_sum == 0):
        raise ValueError("Sum of actual values must be non-zero to compute WMAPE.")
    return 100 * (np.sum(abs_error(y, y_hat), axis=axis) / y_sum)


def symmetrical_abs_percent_error(y: ArrayLike, y_hat: ArrayLike) -> np.ndarray:
    r"""Calculate the Symmetrical Absolute Percentage Error (SAPE) between actual and predicted values.

    The SAPE adjusts for asymmetry in percentage errors:
    \[
    SAPE = 200 \times \frac{|y_t - \hat{y}_t|}{|y_t| + |\hat{y}_t|}
    \]

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.

    Returns:
        SAPE values in percent, same shape as inputs.

    Raises:
        ValueError: If both `y` and `y_hat` are zero at any point.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> symmetrical_abs_percent_error(y, y_hat)
        array([9.52380952, 5.12820513, 6.4516129 ])
    """
    y, y_hat = validate_inputs(y, y_hat)
    denominator = np.abs(y) + np.abs(y_hat)
    if not np.all(denominator != 0):
        raise ValueError("Both `y` and `y_hat` must not be zero simultaneously to compute sMAPE.")
    return 200.0 * abs_error(y, y_hat) / denominator


def smape(y: ArrayLike, y_hat: ArrayLike, axis: int = 0) -> float | np.ndarray:
    r"""Calculate the Symmetric Mean Absolute Percentage Error (sMAPE) between actual and predicted values.

    The sMAPE is the mean of the symmetrical absolute percentage errors:
    \[
    sMAPE = \frac{1}{T} \sum_{t=1}^{T} 200 \times \frac{|y_t - \hat{y}_t|}{|y_t| + |\hat{y}_t|}
    \]
    where \( T \) is the number of samples.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        axis: Axis along which to compute the mean. Defaults to 0.

    Returns:
        sMAPE in percent, scalar if 1D input, array if multi-dimensional.

    Raises:
        ValueError: If both `y` and `y_hat` are zero at any point.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> smape(y, y_hat)
        7.034542516666667  # Mean of [9.52380952, 5.12820513, 6.4516129]
    """
    return np.nanmean(symmetrical_abs_percent_error(y, y_hat), axis=axis)


def ope(y: ArrayLike, y_hat: ArrayLike, axis: int = 0) -> float | np.ndarray:
    r"""Calculate the Overall Percentage Error (OPE) between actual and predicted values.

    The OPE is the percentage error of the summed actual and predicted values:
    \[
    OPE = 100 \times \left| \frac{\sum_{t=1}^{T} y_t - \sum_{t=1}^{T} \hat{y}_t}{\sum_{t=1}^{T} y_t} \right|
    \]
    where \( T \) is the number of samples.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        axis: Axis along which to compute the sums. Defaults to 0.

    Returns:
        OPE in percent, scalar if 1D input, array if multi-dimensional.

    Raises:
        ValueError: If the sum of `y` along the axis is zero.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> overall_percentage_error(y, y_hat)
        3.3333333333333335  # |6 - 6.2| / 6 * 100
    """
    y, y_hat = validate_inputs(y, y_hat)
    y_sum = np.sum(y, axis=axis)
    y_hat_sum = np.sum(y_hat, axis=axis)
    if np.any(y_sum == 0):
        raise ValueError("Sum of actual values must be non-zero to compute OPE.")
    return 100.0 * np.abs((y_sum - y_hat_sum) / y_sum)


def corr(y: ArrayLike, y_hat: ArrayLike) -> float:
    """Calculate the Pearson Correlation Coefficient between actual and predicted values.

    Args:
        y: Actual values, must be 1D.
        y_hat: Predicted values, must be 1D and same shape as `y`.

    Returns:
        Pearson correlation coefficient between -1 and 1.

    Raises:
        ValueError: If inputs are not 1D or have incompatible shapes.
    """
    y, y_hat = validate_inputs(y, y_hat, require_1d=True)
    return np.corrcoef(y, y_hat)[0, 1]


def nbias(y: ArrayLike, y_hat: ArrayLike, axis: int = 0) -> float | np.ndarray:
    r"""Calculate the Normalised Bias Error (NBE) between actual and predicted values.

    The NBE normalizes the bias by the sum of actual and predicted values:
    \[
    NBE = \sum_{t=1}^{T} \frac{y_t - \hat{y}_t}{y_t + \hat{y}_t}
    \]
    where \( T \) is the number of samples.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.
        axis: Axis along which to compute the sum. Defaults to 0.

    Returns:
        NBE, scalar if 1D input, array if multi-dimensional.

    Raises:
        ValueError: If the denominator (y + y_hat) is zero at any point.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1, 2, 3])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> normalised_bias_error(y, y_hat)
        -0.029304029304029298  # Sum of [-0.04761905, 0.02564103, -0.03076923]
    """
    y, y_hat = validate_inputs(y, y_hat)
    scale = y + y_hat
    if not np.all(scale != 0):
        raise ValueError("Scale (y + y_hat) must be non-zero to compute NBE.")
    return np.sum(error(y, y_hat) / scale, axis=axis)


def r_squared(y: ArrayLike, y_hat: ArrayLike) -> float:
    r"""Calculate the Coefficient of Determination (R²) between actual and predicted values.

    R² measures the proportion of variance in the actual values explained by the predictions:
    \[
    R^2 = 1 - \frac{\sum_{t=1}^{T} (y_t - \hat{y}_t)^2}{\sum_{t=1}^{T} (y_t - \bar{y})^2}
    \]
    where :math:`\bar{y}` is the mean of the actual values.  A perfect forecast yields
    ``R² = 1``; a constant mean prediction yields ``R² = 0``; worse-than-mean predictions
    can yield negative values.

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.

    Returns:
        R² coefficient, scalar if 1D input, array if multi-dimensional.

    Raises:
        ValueError: If `y` and `y_hat` have incompatible shapes.
        ValueError: If the variance of `y` is zero (constant series).

    Examples:
        >>> import numpy as np
        >>> y = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        >>> y_hat = np.array([1.1, 2.0, 2.9, 4.1, 5.0])
        >>> r_squared(y, y_hat)
        0.994
    """
    y, y_hat = validate_inputs(y, y_hat)
    ss_res = np.nansum(squared_error(y, y_hat), axis=0)
    ss_tot = np.nansum((y - np.nanmean(y, axis=0)) ** 2, axis=0)
    if np.any(ss_tot == 0):
        raise ValueError("Variance of `y` is zero; R² is undefined for a constant series.")
    return float(1.0 - ss_res / ss_tot)


def rmsle(y: ArrayLike, y_hat: ArrayLike, axis: int = 0) -> float | np.ndarray:
    r"""Calculate the Root Mean Squared Log Error (RMSLE).

    The RMSLE penalises under-predictions more than over-predictions and is
    scale-invariant on a log scale:
    \[
    RMSLE = \sqrt{\frac{1}{T} \sum_{t=1}^{T} \bigl(\log(1 + \hat{y}_t) - \log(1 + y_t)\bigr)^2}
    \]

    Args:
        y: Actual values, must be non-negative, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, must be non-negative, same shape as `y`.
        axis: Axis along which to compute the mean. Defaults to 0.

    Returns:
        RMSLE, scalar if 1D input, array if multi-dimensional.

    Raises:
        ValueError: If any value in `y` or `y_hat` is negative.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1.0, 2.0, 3.0])
        >>> y_hat = np.array([1.1, 1.9, 3.2])
        >>> rmsle(y, y_hat)
        0.07663...
    """
    y, y_hat = validate_inputs(y, y_hat)
    if np.any(y < 0) or np.any(y_hat < 0):
        raise ValueError("RMSLE requires non-negative values for `y` and `y_hat`.")
    log_diff = np.log1p(y_hat) - np.log1p(y)
    return float(np.sqrt(np.nanmean(log_diff**2, axis=axis)))


def medae(y: ArrayLike, y_hat: ArrayLike) -> float:
    r"""Calculate the Median Absolute Error (MedAE) between actual and predicted values.

    MedAE is robust to outliers, unlike MAE:
    \[
    MedAE = \text{median}\!\left(\lvert y_t - \hat{y}_t \rvert\right)
    \]

    Args:
        y: Actual values, shape (n_samples,) or (n_samples, n_features).
        y_hat: Predicted values, same shape as `y`.

    Returns:
        Median absolute error, scalar.

    Raises:
        ValueError: If `y` and `y_hat` have incompatible shapes.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1.0, 2.0, 3.0, 100.0])
        >>> y_hat = np.array([1.1, 2.0, 2.9, 90.0])
        >>> medae(y, y_hat)
        0.1
    """
    return float(np.median(abs_error(y, y_hat)))


def skill_score(
    y: ArrayLike,
    y_hat: ArrayLike,
    y_naive: ArrayLike,
    metric: str = "mae",
) -> float:
    r"""Calculate the Skill Score of a forecast relative to a naive baseline.

    The Skill Score quantifies the relative improvement of a model over a
    naive baseline forecast:
    \[
    SS = 1 - \frac{\text{metric}(y, \hat{y})}{\text{metric}(y, y_{\text{naive}})}
    \]
    A positive score indicates improvement over the baseline; 0 means no
    improvement; negative values indicate the model is worse than the baseline.

    Args:
        y: Actual values, shape (n_samples,).
        y_hat: Model predictions, same shape as `y`.
        y_naive: Naive baseline predictions (e.g. seasonal naïve, persistence),
            same shape as `y`.
        metric: Error metric to use for comparison.  One of ``'mae'``, ``'mse'``,
            ``'rmse'``.  Defaults to ``'mae'``.

    Returns:
        Skill score, typically in (-∞, 1]. Perfect skill = 1.

    Raises:
        ValueError: If `metric` is not one of the supported values.
        ValueError: If the naive baseline metric is zero.

    Examples:
        >>> import numpy as np
        >>> y = np.array([1.0, 2.0, 3.0, 4.0])
        >>> y_hat = np.array([1.1, 2.1, 3.0, 4.0])
        >>> y_naive = np.array([1.0, 1.0, 1.0, 1.0])
        >>> skill_score(y, y_hat, y_naive, metric="mae")
        0.9333...
    """
    metric_fns: dict[str, Callable[..., Any]] = {"mae": mae, "mse": mse, "rmse": rmse}
    if metric not in metric_fns:
        raise ValueError(f"metric must be one of {sorted(metric_fns)}, got {metric!r}.")
    fn = metric_fns[metric]
    score_model = fn(y, y_hat)
    score_naive = fn(y, y_naive)
    if score_naive == 0:
        raise ValueError("Naive baseline metric is zero; skill score is undefined.")
    return float(1.0 - score_model / score_naive)


def get_pointwise_metrics(y: ArrayLike, y_hat: ArrayLike, metric_names: list[str] | None) -> pd.DataFrame:
    """Compute specified metrics for actual and predicted values.

    This function takes actual values `y`, predicted values `y_hat`, and a list of metric names,
    and returns a DataFrame with metric names as columns and their computed aggregate values
    (mean or sum) as values. If a metric computation fails (e.g., due to division by zero),
    that metric is skipped and a warning is logged.

    Args:
        y: Actual values, must be a 1D array or Series.
        y_hat: Predicted values, must be a 1D array or Series with the same shape as `y`.
        metric_names: List of metric names to compute. Supported metrics that return
            aggregate values are: 'res', 'mae', 'mase', 'mse', 'msse', 'rmse', 'rmsse',
            'mape', 'wmape', 'smape', 'ope', 'corr', 'nbias', 'r2', 'rmsle', 'medae'.

    Returns:
        pd.DataFrame: A DataFrame with one row containing the computed metric values for all
        successfully computed metrics.

    Raises:
        ValueError: If `y` or `y_hat` are not 1D arrays, have different shapes, or if an unknown
                    metric name is provided.
    """
    # Validate inputs using the general validation function
    y, y_hat = validate_inputs(y, y_hat, require_1d=True)

    # Dictionary mapping metric names to their functions.
    # These functions should be defined elsewhere and imported as needed.
    metric_functions: dict[str, Callable[..., Any]] = {
        "res": res,
        "mae": mae,
        "mase": mase,
        "mse": mse,
        "msse": msse,
        "rmse": rmse,
        "rmsse": rmsse,
        "mape": mape,
        "wmape": wmape,
        "smape": smape,
        "ope": ope,
        "corr": corr,
        "nbias": nbias,
        "r2": r_squared,
        "rmsle": rmsle,
        "medae": medae,
    }

    # Initialize the results dictionary.
    results = {}
    metric_names = metric_names or list(metric_functions)
    # Compute each specified metric.
    for name in metric_names:
        if name not in metric_functions:
            raise ValueError(f"Unknown metric name: {name}")
        metric_func = metric_functions[name]
        try:
            # Compute the metric with y and y_hat.
            value = metric_func(y, y_hat)
            results[name] = value
        except Exception as e:
            # Log a warning and skip the metric if computation fails.
            log.warning("Skipping metric %r due to error: %s", name, e)

    # Return the results as a single-row DataFrame.
    return pd.DataFrame.from_dict(results, orient="index").T


def evaluate_point_forecast(
    result: ForecastResult,
    metric_names: list[str] | None = None,
) -> pd.DataFrame:
    """Evaluate point forecasts by computing daily pointwise metrics.

    Args:
        result: :class:`~twiga.forecaster.result.ForecastResult` with
            ``ground_truth`` set, ``kind=ForecastKind.POINT``.
        metric_names: Metric names to compute.  When ``None`` all supported
            point metrics are computed.

    Returns:
        DataFrame of per-day, per-target metrics indexed by daily timestamp.
    """
    from twiga.core.metrics._core import _evaluate_loop

    def metric_fn(day_idx: int, target_idx: int) -> pd.DataFrame:
        true_vals = result.ground_truth[day_idx, :, target_idx]  # type: ignore[index]
        pred_vals = result.loc[day_idx, :, target_idx]
        return get_pointwise_metrics(y=true_vals, y_hat=pred_vals, metric_names=metric_names)

    return _evaluate_loop(result, metric_fn)
