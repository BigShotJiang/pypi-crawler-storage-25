"""Probabilistic forecast metrics for Twiga.

Provides low-level scoring functions (pinball loss, CRPS, NLL, calibration)
together with high-level evaluate helpers that mirror the interface of
:func:`~twiga.core.metrics.point.evaluate_point_forecast` and
:func:`~twiga.core.metrics.interval.evaluate_interval_forecast`.

All *evaluate_* functions accept an ``outputs`` dict and return a
:class:`pandas.DataFrame` indexed by daily timestamp so they can be used
interchangeably with the other evaluate helpers.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from twiga.forecaster.result import ForecastResult

from .point import get_pointwise_metrics, validate_inputs

# ---------------------------------------------------------------------------
# Low-level scoring primitives
# ---------------------------------------------------------------------------


def continuous_ranked_probability_score(true: np.ndarray, samples: np.ndarray) -> float:
    r"""Compute the Continuous Ranked Probability Score (CRPS).

    The CRPS is a proper scoring rule that generalises the MAE to
    probabilistic forecasts:

    .. math::

        \text{CRPS}(F, y) = \int_{-\infty}^{\infty}
            \left(F(z) - \mathbf{1}\{z \geq y\}\right)^2 \mathrm{d}z

    Args:
        true: Ground-truth values, shape ``(n_obs,)``.
        samples: Predicted samples, shape ``(n_samples, n_obs)``.

    Returns:
        Mean CRPS over all observations.

    References:
        Gneiting, T., & Raftery, A. E. (2007). Strictly proper scoring rules,
        prediction, and estimation. *Journal of the American Statistical
        Association*, 102(477), 359–378.

    Examples:
        >>> true = np.array([1.0, 2.0, 3.0])
        >>> samples = np.array([[1.2, 2.1, 2.9], [1.0, 2.0, 3.0], [0.8, 1.9, 3.1]])
        >>> continuous_ranked_probability_score(true, samples)
        0.05555555555555555
    """
    num_samples = samples.shape[0]
    absolute_error = np.mean(np.abs(samples - true), axis=0)
    samples_sorted = np.sort(samples, axis=0)
    differences = samples_sorted[1:] - samples_sorted[:-1]
    weights = np.arange(1, num_samples) * np.arange(num_samples - 1, 0, -1)
    weights = np.expand_dims(weights, -1)
    per_observation_crps = absolute_error - np.sum(differences * weights, axis=0) / num_samples**2
    return float(np.mean(per_observation_crps))


def continuous_ranked_probability_score_pwm(true: np.ndarray, samples: np.ndarray) -> float:
    r"""Compute the CRPS using Probability Weighted Moments (PWM).

    Equivalent to :func:`continuous_ranked_probability_score` but uses the
    PWM estimator, which is numerically preferable for small sample sizes.

    Args:
        true: Ground-truth values, shape ``(n_obs,)``.
        samples: Predicted samples, shape ``(n_samples, n_obs)``.

    Returns:
        Mean CRPS over all observations.

    References:
        Zamo, M., & Naveau, P. (2017). Estimation of the Continuous Ranked
        Probability Score with Limited Information and Applications to
        Ensemble Weather Forecasts. *Monthly Weather Review*, 145(3),
        1023–1037.

    Examples:
        >>> true = np.array([1.0, 2.0, 3.0])
        >>> samples = np.array([[1.2, 2.1, 2.9], [1.0, 2.0, 3.0], [0.8, 1.9, 3.1]])
        >>> continuous_ranked_probability_score_pwm(true, samples)
        0.05555555555555555
    """
    num_samples = samples.shape[0]
    absolute_error = np.mean(np.abs(samples - true), axis=0)
    if num_samples == 1:
        return float(np.mean(absolute_error))
    samples_sorted = np.sort(samples, axis=0)
    differences = samples_sorted[1:] - samples_sorted[:-1]
    weights = np.arange(1, num_samples) * np.arange(num_samples - 1, 0, -1)
    weights = np.expand_dims(weights, -1)
    per_observation_crps = absolute_error - np.sum(differences * weights, axis=0) / num_samples**2
    return float(np.mean(per_observation_crps))


def dawid_sebastiani_score(true: np.ndarray, loc: np.ndarray, scale: np.ndarray) -> float:
    r"""Compute the Dawid-Sebastiani Score (DSS) for parametric Normal forecasts.

    DSS is a proper scoring rule for location-scale forecasts.  Under a Normal
    predictive distribution :math:`\mathcal{N}(\mu_t, \sigma_t^2)`, the score is:

    .. math::

        DSS(y_t, \mu_t, \sigma_t) = \frac{(y_t - \mu_t)^2}{\sigma_t^2} + 2 \log \sigma_t

    The mean over observations is returned.  Lower values indicate better
    calibrated and sharper forecasts.

    Args:
        true: Ground-truth values, shape ``(n_obs,)``.
        loc: Predicted means, shape ``(n_obs,)``.
        scale: Predicted standard deviations (σ > 0), shape ``(n_obs,)``.

    Returns:
        Mean DSS over all observations.

    Raises:
        ValueError: If any value in ``scale`` is non-positive.

    References:
        Dawid, A. P., & Sebastiani, P. (1999). Coherent dispersion criteria for
        optimal experimental design. *The Annals of Statistics*, 27(1), 65–81.

    Examples:
        >>> import numpy as np
        >>> true = np.array([1.0, 2.0, 3.0])
        >>> loc = np.array([1.1, 1.9, 3.1])
        >>> scale = np.array([0.5, 0.5, 0.5])
        >>> dawid_sebastiani_score(true, loc, scale)
    """
    true = np.asarray(true, dtype=float)
    loc = np.asarray(loc, dtype=float)
    scale = np.asarray(scale, dtype=float)
    if np.any(scale <= 0):
        raise ValueError("scale must be strictly positive for DSS computation.")
    scores = ((true - loc) ** 2) / (scale**2) + 2.0 * np.log(scale)
    return float(np.mean(scores))


def energy_score(true: np.ndarray, samples: np.ndarray) -> float:
    r"""Compute the Energy Score (ES) for ensemble / sample-based forecasts.

    The Energy Score is the multivariate generalisation of CRPS.  It reduces to
    CRPS in the univariate case but extends naturally to joint forecast
    distributions over the full forecast horizon:

    .. math::

        ES(F, \mathbf{y}) = \mathbb{E}_F\|\mathbf{X} - \mathbf{y}\|_2
            - \tfrac{1}{2}\,\mathbb{E}_F\|\mathbf{X} - \mathbf{X}'\|_2

    The empirical approximation with :math:`M` samples is:

    .. math::

        ES \approx \frac{1}{M} \sum_{i=1}^{M} \|\mathbf{x}_i - \mathbf{y}\|_2
            - \frac{1}{2M^2} \sum_{i=1}^{M}\sum_{j=1}^{M} \|\mathbf{x}_i - \mathbf{x}_j\|_2

    Args:
        true: Ground-truth vector, shape ``(n_obs,)``.
        samples: Ensemble samples, shape ``(n_samples, n_obs)``.

    Returns:
        Energy Score (non-negative scalar). Lower is better.

    References:
        Gneiting, T., & Raftery, A. E. (2007). Strictly proper scoring rules,
        prediction, and estimation. *Journal of the American Statistical
        Association*, 102(477), 359–378.

    Examples:
        >>> import numpy as np
        >>> true = np.array([1.0, 2.0, 3.0])
        >>> samples = np.array([[1.2, 2.1, 2.9], [0.8, 1.9, 3.1], [1.0, 2.0, 3.0]])
        >>> energy_score(true, samples)
    """
    true = np.asarray(true, dtype=float)
    samples = np.asarray(samples, dtype=float)
    n_samples = samples.shape[0]

    # E[||X - y||_2]
    mean_dist_to_obs = np.mean(np.linalg.norm(samples - true[None, :], axis=1))

    # E[||X - X'||_2] via pairwise distances (O(M²) — acceptable for typical ensemble sizes)
    diffs = samples[:, None, :] - samples[None, :, :]  # (M, M, n_obs)
    pairwise_norms = np.linalg.norm(diffs, axis=-1)  # (M, M)
    mean_pairwise = np.sum(pairwise_norms) / (n_samples**2)

    return float(mean_dist_to_obs - 0.5 * mean_pairwise)


def brier_score(true: np.ndarray, samples: np.ndarray, threshold: float) -> float:
    r"""Compute the Brier Score for a probabilistic event forecast.

    The Brier Score measures the accuracy of probabilistic binary event
    predictions.  Here the event is :math:`y_t \leq \text{threshold}` and the
    predicted probability is estimated from ensemble samples:

    .. math::

        BS = \frac{1}{n} \sum_{t=1}^{n} \bigl(\hat{p}_t - o_t\bigr)^2

    where :math:`\hat{p}_t = \frac{1}{M}\sum_{i=1}^{M}\mathbb{1}(x_{i,t} \leq \text{threshold})`
    and :math:`o_t = \mathbb{1}(y_t \leq \text{threshold})`.

    Args:
        true: Ground-truth values, shape ``(n_obs,)``.
        samples: Ensemble samples, shape ``(n_samples, n_obs)``.
        threshold: Event threshold; the event is defined as ``y ≤ threshold``.

    Returns:
        Brier Score in ``[0, 1]``. Lower is better; 0 is perfect.

    References:
        Brier, G. W. (1950). Verification of forecasts expressed in terms of
        probability. *Monthly Weather Review*, 78(1), 1–3.

    Examples:
        >>> import numpy as np
        >>> true = np.array([1.0, 2.0, 3.0, 4.0])
        >>> samples = np.random.normal(2.5, 1.0, (100, 4))
        >>> brier_score(true, samples, threshold=2.5)
    """
    true = np.asarray(true, dtype=float)
    samples = np.asarray(samples, dtype=float)
    predicted_prob = np.mean(samples <= threshold, axis=0)  # (n_obs,)
    observed = (true <= threshold).astype(float)
    return float(np.mean((predicted_prob - observed) ** 2))


# ---------------------------------------------------------------------------
# Per-day metric helpers
# ---------------------------------------------------------------------------


def get_parametric_metrics(
    true: np.ndarray,
    loc: np.ndarray,
    scale: np.ndarray,
    log_likelihood: np.ndarray | None = None,
) -> pd.DataFrame:
    """Compute point and parametric distribution metrics for a single day/target slice.

    The negative log-likelihood (NLL) is computed under a Normal distribution
    assumption unless *log_likelihood* is provided explicitly.

    Args:
        true: Ground-truth values, shape ``(time_steps,)``.
        loc: Predicted means, shape ``(time_steps,)``.
        scale: Predicted standard deviations, shape ``(time_steps,)``.
        log_likelihood: Pre-computed log-likelihood values,
            shape ``(time_steps,)``.  When supplied, NLL is ``-mean(log_likelihood)``;
            otherwise it is computed from *loc* and *scale* under a Normal
            assumption.

    Returns:
        Single-row DataFrame with point metrics and NLL.

    Raises:
        ValueError: If *scale* contains non-positive values.
    """
    true, loc = validate_inputs(true, loc, require_1d=True)
    scale = np.asarray(scale)
    if np.any(scale <= 0):
        raise ValueError("scale must be strictly positive for NLL computation.")

    point_scores = get_pointwise_metrics(y=true, y_hat=loc, metric_names=None)

    if log_likelihood is not None:
        nll = float(-np.mean(log_likelihood))
    else:
        # Normal log-likelihood: -0.5 * [log(2π σ²) + (y - μ)² / σ²]
        nll = float(np.mean(0.5 * np.log(2 * np.pi * scale**2) + (true - loc) ** 2 / (2 * scale**2)))

    dss = dawid_sebastiani_score(true, loc, scale)
    prob_scores = pd.DataFrame({"nll": [nll], "dss": [dss]})
    return pd.concat([point_scores, prob_scores], axis=1)


def get_samples_metrics(
    true: np.ndarray,
    loc: np.ndarray,
    samples: np.ndarray,
) -> pd.DataFrame:
    """Compute point and sample-based metrics for a single day/target slice.

    Args:
        true: Ground-truth values, shape ``(time_steps,)``.
        loc: Point predictions (e.g. sample mean or median),
            shape ``(time_steps,)``.
        samples: Posterior/ensemble samples, shape ``(n_samples, time_steps)``.

    Returns:
        Single-row DataFrame with point metrics and CRPS.
    """
    true, loc = validate_inputs(true, loc, require_1d=True)

    point_scores = get_pointwise_metrics(y=true, y_hat=loc, metric_names=None)

    crps = continuous_ranked_probability_score(true, samples)
    es = energy_score(true, samples)
    prob_scores = pd.DataFrame({"crps": [crps], "energy_score": [es]})
    return pd.concat([point_scores, prob_scores], axis=1)


# ---------------------------------------------------------------------------
# High-level evaluate functions
# ---------------------------------------------------------------------------


def evaluate_samples_forecast(result: ForecastResult) -> pd.DataFrame:
    """Evaluate sample-based forecasts by computing daily point and CRPS metrics.

    Args:
        result: :class:`~twiga.forecaster.result.ForecastResult` with
            ``ground_truth`` and ``samples`` set,
            ``kind=ForecastKind.SAMPLES``.

    Returns:
        DataFrame of per-day, per-target point metrics and CRPS indexed by
        daily timestamp.
    """
    from twiga.core.metrics._core import _evaluate_loop

    def metric_fn(day_idx: int, target_idx: int) -> pd.DataFrame:
        true_vals = result.ground_truth[day_idx, :, target_idx]  # type: ignore[index]
        loc_vals = result.loc[day_idx, :, target_idx]
        sample_vals = result.samples[day_idx, :, :, target_idx]  # type: ignore[index]
        return get_samples_metrics(true=true_vals, loc=loc_vals, samples=sample_vals)

    return _evaluate_loop(result, metric_fn)


def evaluate_parametric_forecast(result: ForecastResult) -> pd.DataFrame:
    """Evaluate parametric forecasts by computing daily point and NLL metrics.

    The NLL is computed under a Normal distribution assumption when
    ``result.log_likelihood`` is absent.  Pass pre-computed log-likelihood
    values via that attribute to override this behaviour.

    Args:
        result: :class:`~twiga.forecaster.result.ForecastResult` with
            ``ground_truth`` and ``scale`` set,
            ``kind=ForecastKind.PARAMETRIC``.

    Returns:
        DataFrame of per-day, per-target point metrics and NLL indexed by
        daily timestamp.

    Raises:
        ValueError: If any *scale* value is non-positive.
    """
    from twiga.core.metrics._core import _evaluate_loop

    log_likelihood: np.ndarray | None = getattr(result, "log_likelihood", None)

    def metric_fn(day_idx: int, target_idx: int) -> pd.DataFrame:
        true_vals = result.ground_truth[day_idx, :, target_idx]  # type: ignore[index]
        loc_vals = result.loc[day_idx, :, target_idx]
        scale_vals = result.scale[day_idx, :, target_idx]  # type: ignore[index]
        ll_vals = log_likelihood[day_idx, :, target_idx] if log_likelihood is not None else None
        return get_parametric_metrics(true=true_vals, loc=loc_vals, scale=scale_vals, log_likelihood=ll_vals)

    return _evaluate_loop(result, metric_fn)
