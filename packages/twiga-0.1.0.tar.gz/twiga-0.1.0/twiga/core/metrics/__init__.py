"""Twiga forecast evaluation metrics.

This package exposes both the low-level scoring primitives and high-level
evaluation helpers.  The primary entry point for downstream code is
:func:`evaluate_forecast`, which dispatches to the correct evaluate function
based on the :attr:`~twiga.forecaster.result.ForecastResult.kind` of the
result, eliminating the need for callers to import or select individual
evaluation functions.

Supported ``kind`` values (corresponding to
:class:`~twiga.forecaster.result.ForecastKind`):

* ``"point"``      → :func:`~twiga.core.metrics.point.evaluate_point_forecast`
* ``"interval"``   → :func:`~twiga.core.metrics.interval.evaluate_interval_forecast`
* ``"quantile"``   → :func:`~twiga.core.metrics.quantile.evaluate_quantile_forecast`
* ``"samples"``    → :func:`~twiga.core.metrics.prob.evaluate_samples_forecast`
* ``"parametric"`` → :func:`~twiga.core.metrics.prob.evaluate_parametric_forecast`
"""

from __future__ import annotations

import pandas as pd

from twiga.forecaster.result import ForecastResult

from .interval import evaluate_interval_forecast, msis
from .parametric import laplace_nll, normal_crps, normal_nll
from .point import evaluate_point_forecast, medae, r_squared, rmsle, skill_score
from .prob import (
    brier_score,
    dawid_sebastiani_score,
    energy_score,
    evaluate_parametric_forecast,
    evaluate_samples_forecast,
)
from .quantile import evaluate_quantile_forecast, wql
from .stats import diebold_mariano_test, giacomini_white_test

__all__ = [
    "brier_score",
    "dawid_sebastiani_score",
    "diebold_mariano_test",
    "giacomini_white_test",
    "energy_score",
    "evaluate_forecast",
    "evaluate_interval_forecast",
    "evaluate_parametric_forecast",
    "evaluate_point_forecast",
    "evaluate_quantile_forecast",
    "evaluate_samples_forecast",
    "laplace_nll",
    "medae",
    "msis",
    "normal_crps",
    "normal_nll",
    "r_squared",
    "rmsle",
    "skill_score",
    "wql",
]

# Map each ForecastKind value to the corresponding evaluate function.
# Kept as a module-level constant so the dict is built once.
_EVALUATE_DISPATCH: dict = {
    "point": evaluate_point_forecast,
    "interval": evaluate_interval_forecast,
    "quantile": evaluate_quantile_forecast,
    "samples": evaluate_samples_forecast,
    "parametric": evaluate_parametric_forecast,
}


def evaluate_forecast(result: ForecastResult, **kwargs: object) -> pd.DataFrame:
    """Dispatch forecast evaluation to the kind-appropriate function.

    This is the single entry point for evaluation so callers do not need to
    know or import individual evaluate functions.  The correct function is
    selected from an internal dispatch table keyed on
    :attr:`~twiga.forecaster.result.ForecastResult.kind`.

    Args:
        result: A :class:`~twiga.forecaster.result.ForecastResult` whose
            ``ground_truth`` field is set.  The ``kind`` attribute determines
            which evaluate function is called.
        **kwargs: Extra keyword arguments forwarded to the underlying evaluate
            function (e.g. ``alpha`` for interval or quantile forecasts).

    Returns:
        DataFrame of per-day, per-target metrics indexed by daily timestamp.

    Raises:
        ValueError: If ``result.ground_truth`` is ``None`` or ``result.kind``
            is not one of the supported values.

    Examples:
        >>> result = ForecastResult(kind=ForecastKind.POINT, ground_truth=y, ...)
        >>> metrics_df = evaluate_forecast(result)
    """
    if result.ground_truth is None:
        raise ValueError(
            "ForecastResult.ground_truth must be set before calling evaluate_forecast(). "
            "Pass it to ForecastResult.evaluate(ground_truth) or set it directly.",
        )
    kind = result.kind.value
    if kind not in _EVALUATE_DISPATCH:
        raise ValueError(f"Unsupported forecast kind {kind!r}. Expected one of {sorted(_EVALUATE_DISPATCH.keys())}.")
    return _EVALUATE_DISPATCH[kind](result, **kwargs)
