"""Statistical significance tests for forecast comparison.

Provides model-comparison tests that go beyond point metric summaries to
determine whether observed differences in forecast accuracy are statistically
significant.

References:
    Diebold, F. X., & Mariano, R. S. (1995). Comparing predictive accuracy.
    *Journal of Business & Economic Statistics*, 13(3), 253–263.

    Giacomini, R., & White, H. (2006). Tests of conditional predictive ability.
    *Econometrica*, 74(6), 1545–1578.
"""

from __future__ import annotations

import numpy as np
from scipy import stats

__all__ = ["diebold_mariano_test", "giacomini_white_test"]


def _hac_variance(d: np.ndarray, h: int) -> float:
    """HAC long-run variance estimator with Bartlett kernel, bandwidth ``h - 1``.

    Args:
        d: 1-D loss differential series.
        h: Forecast horizon (sets number of lags to include).

    Returns:
        HAC variance estimate (clipped to a small positive floor).
    """
    n = len(d)
    d_centered = d - d.mean()
    gamma0 = np.dot(d_centered, d_centered) / n
    hac = gamma0
    for lag in range(1, h):
        weight = 1.0 - lag / h  # Bartlett weight
        gamma_lag = np.dot(d_centered[lag:], d_centered[:-lag]) / n
        hac += 2.0 * weight * gamma_lag
    return max(float(hac), 1e-12)


def diebold_mariano_test(
    p_real: np.ndarray,
    p_pred_1: np.ndarray,
    p_pred_2: np.ndarray,
    norm: int = 1,
    version: str = "multivariate",
    h: int = 1,
) -> float | np.ndarray:
    r"""One-sided Diebold-Mariano (DM) test for equal predictive accuracy.

    Tests the null hypothesis H0 that forecast ``p_pred_1`` has equal or
    *lower* loss than forecast ``p_pred_2`` against the one-sided alternative
    H1 that ``p_pred_2`` is strictly more accurate.  **Rejecting H0** (small
    p-value) means ``p_pred_2`` is significantly more accurate.

    The loss differential is :math:`d_t = g(e_{1,t}) - g(e_{2,t})` where
    :math:`g(e) = |e|^{norm}` (``norm=1`` → MAE-based, ``norm=2`` →
    MSE-based).  The test statistic

    .. math::

        DM = \frac{\bar{d}}{\sqrt{\hat{\sigma}^2_{\text{HAC}} / T}}
        \xrightarrow{d} \mathcal{N}(0,1)

    uses a Bartlett HAC variance estimator with bandwidth ``h - 1`` to
    account for serial correlation in multi-step forecasts.

    Args:
        p_real: Observed values, shape ``(n_days, n_steps)`` or ``(T,)``.
        p_pred_1: Forecast 1 predictions, same shape as ``p_real``.
        p_pred_2: Forecast 2 predictions, same shape as ``p_real``.
        norm: Loss function norm.  ``1`` for MAE-based, ``2`` for MSE-based.
            Defaults to ``1``.
        version: Test variant.

            - ``"multivariate"``: single test on the mean loss differential
              averaged across steps (default).
            - ``"univariate"``: independent test per time step (column),
              returns an array of p-values of length ``n_steps``.

        h: Forecast horizon used to set the HAC bandwidth.  Set to the
            number of steps ahead you are forecasting.  Defaults to ``1``.

    Returns:
        One-sided p-value (float) for ``"multivariate"``, or 1-D array of
        p-values (one per step) for ``"univariate"``.

    Raises:
        ValueError: If input shapes do not match.
        ValueError: If ``version`` is not ``"univariate"`` or ``"multivariate"``.
        ValueError: If ``norm`` is not 1 or 2.

    References:
        Diebold, F. X., & Mariano, R. S. (1995). Comparing predictive accuracy.
        *Journal of Business & Economic Statistics*, 13(3), 253–263.

    Examples:
        >>> import numpy as np
        >>> rng = np.random.default_rng(0)
        >>> real = rng.normal(0, 1, (100, 24))
        >>> pred1 = real + rng.normal(0, 0.5, real.shape)
        >>> pred2 = real + rng.normal(0, 0.3, real.shape)  # better forecast
        >>> p = diebold_mariano_test(real, pred1, pred2, version="multivariate")
    """
    p_real = np.asarray(p_real, dtype=float)
    p_pred_1 = np.asarray(p_pred_1, dtype=float)
    p_pred_2 = np.asarray(p_pred_2, dtype=float)

    if p_real.shape != p_pred_1.shape or p_real.shape != p_pred_2.shape:
        raise ValueError("p_real, p_pred_1, and p_pred_2 must have the same shape.")
    if norm not in (1, 2):
        raise ValueError(f"norm must be 1 or 2, got {norm}.")
    if version not in ("univariate", "multivariate"):
        raise ValueError(f"version must be 'univariate' or 'multivariate', got {version!r}.")

    e1 = p_real - p_pred_1
    e2 = p_real - p_pred_2

    if norm == 1:
        loss1 = np.abs(e1)
        loss2 = np.abs(e2)
    else:
        loss1 = e1**2
        loss2 = e2**2

    if version == "multivariate":
        # Aggregate across steps first, then test once
        d = loss1.mean(axis=-1) - loss2.mean(axis=-1) if p_real.ndim > 1 else loss1 - loss2
        d = d.ravel()
        n = len(d)
        d_bar = d.mean()
        hac = _hac_variance(d, h)
        dm_stat = d_bar / np.sqrt(hac / n)
        return float(1.0 - stats.norm.cdf(dm_stat))

    # univariate: independent test per column (time step)
    if p_real.ndim == 1:
        p_real = p_real[:, None]
        loss1 = loss1[:, None]
        loss2 = loss2[:, None]

    n_days, n_steps = loss1.shape
    p_values = np.empty(n_steps)
    for s in range(n_steps):
        d_s = loss1[:, s] - loss2[:, s]
        d_bar_s = d_s.mean()
        hac_s = _hac_variance(d_s, h)
        dm_stat_s = d_bar_s / np.sqrt(hac_s / n_days)
        p_values[s] = 1.0 - stats.norm.cdf(dm_stat_s)
    return p_values


def giacomini_white_test(
    p_real: np.ndarray,
    p_pred_1: np.ndarray,
    p_pred_2: np.ndarray,
    norm: int = 1,
    version: str = "multivariate",
) -> float | np.ndarray:
    r"""One-sided Giacomini-White (GW) test for Conditional Predictive Accuracy (CPA).

    Tests the null hypothesis H0 that forecast ``p_pred_1`` has equal or
    lower *conditional* expected loss than ``p_pred_2`` against the
    one-sided alternative H1 that ``p_pred_2`` is conditionally more accurate.
    **Rejecting H0** (small p-value) means ``p_pred_2`` is significantly
    more accurate *given the available information set*.

    Unlike DM, the GW test conditions on lagged loss differentials, making it
    more powerful when one model systematically exploits information that the
    other misses.  The instruments are :math:`h_t = [1, d_{t-1}]`, and the
    test statistic is :math:`T \cdot R^2 \sim \chi^2(q)` where :math:`q` is
    the number of instruments.

    Args:
        p_real: Observed values, shape ``(n_days, n_steps)`` or ``(T,)``.
        p_pred_1: Forecast 1 predictions, same shape as ``p_real``.
        p_pred_2: Forecast 2 predictions, same shape as ``p_real``.
        norm: Loss function norm.  ``1`` for MAE-based, ``2`` for MSE-based.
            Defaults to ``1``.
        version: Test variant.

            - ``"multivariate"``: single test on the mean loss differential
              averaged across steps (default).
            - ``"univariate"``: independent test per time step, returns an
              array of p-values of length ``n_steps``.

    Returns:
        One-sided p-value (float) for ``"multivariate"``, or 1-D array of
        p-values (one per step) for ``"univariate"``.

    Raises:
        ValueError: If input shapes do not match or are 1-D (use ``(T, 1)``
            for a single-step series).
        ValueError: If ``version`` is not ``"univariate"`` or ``"multivariate"``.
        ValueError: If ``norm`` is not 1 or 2.

    References:
        Giacomini, R., & White, H. (2006). Tests of conditional predictive
        ability. *Econometrica*, 74(6), 1545–1578.

    Examples:
        >>> import numpy as np
        >>> rng = np.random.default_rng(0)
        >>> real = rng.normal(0, 1, (100, 24))
        >>> pred1 = real + rng.normal(0, 0.5, real.shape)
        >>> pred2 = real + rng.normal(0, 0.3, real.shape)  # better forecast
        >>> p = giacomini_white_test(real, pred1, pred2, version="multivariate")
    """
    p_real = np.asarray(p_real, dtype=float)
    p_pred_1 = np.asarray(p_pred_1, dtype=float)
    p_pred_2 = np.asarray(p_pred_2, dtype=float)

    if p_real.shape != p_pred_1.shape or p_real.shape != p_pred_2.shape:
        raise ValueError("p_real, p_pred_1, and p_pred_2 must have the same shape.")
    if p_real.ndim == 1 or (p_real.ndim == 2 and p_real.shape[1] == 1):
        raise ValueError(
            "Inputs must have shape (n_days, n_steps) with n_steps > 1. "
            "For a single-step series pass shape (T, 1) and use version='univariate'.",
        )
    if norm not in (1, 2):
        raise ValueError(f"norm must be 1 or 2, got {norm}.")
    if version not in ("univariate", "multivariate"):
        raise ValueError(f"version must be 'univariate' or 'multivariate', got {version!r}.")

    e1 = p_real - p_pred_1
    e2 = p_real - p_pred_2

    d_full = np.abs(e1) - np.abs(e2) if norm == 1 else e1**2 - e2**2

    n_days = d_full.shape[0]
    tau = 1  # one-step lag instruments

    def _gw_stat_1d(d: np.ndarray) -> tuple[float, int]:
        """Compute the signed GW statistic and instrument count for a 1-D loss differential."""
        instruments = np.stack([np.ones(n_days - tau), d[:-tau]])  # (q, n-tau)
        d_t = d[tau:]  # (n-tau,)
        n_t = len(d_t)
        q = instruments.shape[0]

        # Moment conditions: reg[j, :] = instruments[j, :] * d_t
        reg = instruments * d_t[None, :]  # (q, n-tau)

        betas = np.linalg.lstsq(reg.T, np.ones(n_t), rcond=None)[0]
        fitted = reg.T @ betas  # (n-tau,)
        residuals = np.ones(n_t) - fitted
        r2 = 1.0 - np.mean(residuals**2)
        gw = n_t * r2 * np.sign(d_t.mean())
        return float(gw), q

    if version == "multivariate":
        d = d_full.mean(axis=1)  # (n_days,)
        gw_stat, q = _gw_stat_1d(d)
        p_value = float(1.0 - stats.chi2.cdf(gw_stat, df=q))
        return p_value

    # univariate: independent test per step
    n_steps = d_full.shape[1]
    p_values = np.empty(n_steps)
    for s in range(n_steps):
        gw_stat, q = _gw_stat_1d(d_full[:, s])
        p_values[s] = float(1.0 - stats.chi2.cdf(gw_stat, df=q))
    return p_values
