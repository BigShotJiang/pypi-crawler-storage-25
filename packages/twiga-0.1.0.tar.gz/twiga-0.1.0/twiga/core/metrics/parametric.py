"""Analytical scoring functions for parametric forecast distributions.

These are closed-form implementations that avoid Monte Carlo sampling for
distributions where exact formulae exist.  All functions accept NumPy arrays
and return scalar floats.
"""

from __future__ import annotations

from math import erf, log, pi, sqrt

import numpy as np

__all__ = [
    "normal_crps",
    "normal_nll",
    "laplace_nll",
]

_SQRT2 = sqrt(2.0)
_SQRTPI = sqrt(pi)
_LOG2PI_HALF = 0.5 * log(2.0 * pi)


def normal_nll(true: np.ndarray, loc: np.ndarray, scale: np.ndarray) -> float:
    r"""Negative log-likelihood under a Normal predictive distribution.

    .. math::

        NLL = \frac{1}{n} \sum_{t=1}^{n}
            \left[ \frac{1}{2} \log(2\pi\sigma_t^2)
            + \frac{(y_t - \mu_t)^2}{2\sigma_t^2} \right]

    Args:
        true: Ground-truth values, shape ``(n,)``.
        loc: Predicted means μ, shape ``(n,)``.
        scale: Predicted standard deviations σ > 0, shape ``(n,)``.

    Returns:
        Mean NLL over all observations.

    Raises:
        ValueError: If any ``scale`` value is non-positive.

    Examples:
        >>> import numpy as np
        >>> normal_nll(np.array([1.0, 2.0]), np.array([1.1, 1.9]), np.array([0.5, 0.5]))
        1.0439...
    """
    true = np.asarray(true, dtype=float)
    loc = np.asarray(loc, dtype=float)
    scale = np.asarray(scale, dtype=float)
    if np.any(scale <= 0):
        raise ValueError("scale must be strictly positive.")
    nll = 0.5 * np.log(2.0 * np.pi * scale**2) + (true - loc) ** 2 / (2.0 * scale**2)
    return float(np.mean(nll))


def normal_crps(true: np.ndarray, loc: np.ndarray, scale: np.ndarray) -> float:
    r"""Analytical CRPS for a Normal predictive distribution.

    The closed-form CRPS under :math:`\mathcal{N}(\mu, \sigma^2)` is:

    .. math::

        CRPS(\mathcal{N}(\mu, \sigma^2), y)
            = \sigma \left[ \frac{y - \mu}{\sigma}
            \left( 2\Phi\!\left(\frac{y - \mu}{\sigma}\right) - 1 \right)
            + 2\phi\!\left(\frac{y - \mu}{\sigma}\right)
            - \frac{1}{\sqrt{\pi}} \right]

    where :math:`\Phi` and :math:`\phi` are the Normal CDF and PDF respectively.

    Args:
        true: Ground-truth values, shape ``(n,)``.
        loc: Predicted means μ, shape ``(n,)``.
        scale: Predicted standard deviations σ > 0, shape ``(n,)``.

    Returns:
        Mean CRPS over all observations.  Lower is better; 0 is perfect.

    Raises:
        ValueError: If any ``scale`` value is non-positive.

    References:
        Gneiting, T., Raftery, A. E., Westveld, A. H., & Goldman, T. (2005).
        Calibrated probabilistic forecasting using ensemble model output
        statistics and minimum CRPS estimation. *Monthly Weather Review*,
        133(5), 1098–1118.

    Examples:
        >>> import numpy as np
        >>> normal_crps(np.array([1.0, 2.0]), np.array([1.0, 2.0]), np.array([1.0, 1.0]))
        0.5641...  # σ / sqrt(π) for perfectly calibrated forecast
    """
    true = np.asarray(true, dtype=float)
    loc = np.asarray(loc, dtype=float)
    scale = np.asarray(scale, dtype=float)
    if np.any(scale <= 0):
        raise ValueError("scale must be strictly positive.")

    z = (true - loc) / scale
    # Standard Normal CDF via erf: Φ(z) = 0.5 * (1 + erf(z / sqrt(2)))
    phi_z = 0.5 * (1.0 + np.vectorize(erf)(z / _SQRT2))
    # Standard Normal PDF: φ(z) = exp(-z²/2) / sqrt(2π)
    pdf_z = np.exp(-0.5 * z**2) / (sqrt(2.0 * pi))

    crps_per_obs = scale * (z * (2.0 * phi_z - 1.0) + 2.0 * pdf_z - 1.0 / _SQRTPI)
    return float(np.mean(crps_per_obs))


def laplace_nll(true: np.ndarray, loc: np.ndarray, scale: np.ndarray) -> float:
    r"""Negative log-likelihood under a Laplace predictive distribution.

    .. math::

        NLL = \frac{1}{n} \sum_{t=1}^{n}
            \left[ \log(2b_t) + \frac{|y_t - \mu_t|}{b_t} \right]

    where :math:`b_t` is the scale (diversity) parameter of the Laplace distribution.

    Args:
        true: Ground-truth values, shape ``(n,)``.
        loc: Predicted means μ, shape ``(n,)``.
        scale: Predicted Laplace scale b > 0, shape ``(n,)``.

    Returns:
        Mean NLL over all observations.

    Raises:
        ValueError: If any ``scale`` value is non-positive.

    Examples:
        >>> import numpy as np
        >>> laplace_nll(np.array([1.0, 2.0]), np.array([1.1, 1.9]), np.array([0.5, 0.5]))
        1.1931...
    """
    true = np.asarray(true, dtype=float)
    loc = np.asarray(loc, dtype=float)
    scale = np.asarray(scale, dtype=float)
    if np.any(scale <= 0):
        raise ValueError("scale must be strictly positive.")
    nll = np.log(2.0 * scale) + np.abs(true - loc) / scale
    return float(np.mean(nll))
