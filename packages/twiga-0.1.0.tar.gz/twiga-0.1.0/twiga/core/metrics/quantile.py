from __future__ import annotations

import numpy as np
import pandas as pd

from twiga.forecaster.result import ForecastResult

from .interval import get_interval_metrics
from .point import get_pointwise_metrics


def reliability_scores(
    true: np.ndarray,
    quantile_preds: np.ndarray,
    quantile_levels: np.ndarray | list[float] | tuple[float, ...],
    quantile_axis: int | None = None,
    eps: float = 1e-8,
    return_uniformity_test: bool = False,
) -> np.ndarray | tuple[np.ndarray, dict]:
    r"""Compute Probability Integral Transform (PIT) values to assess forecast reliability / calibration.

    For a well-calibrated probabilistic forecast, the PIT values

    .. math::

        u_i = F_i(y_i) \quad \text{where } F_i \text{ is the predicted CDF for sample } i

    should be uniformly distributed on [0,1]. Deviations indicate miscalibration
    (e.g. underdispersion → U-shape, overdispersion → peaked at 0.5, bias → shifted).

    The CDF is approximated piecewise-linearly from the quantiles with linear tail extrapolation.
    Quantile predictions are sorted per sample to ensure monotonicity, and a check is performed
    that the corresponding quantile levels remain strictly increasing (i.e., that the original
    predictions were not crossed).

    Args:
        true: Observed values, any shape (will be flattened internally).
        quantile_preds: Predicted quantiles, shape with one axis holding quantiles.
            Remaining dimensions must match ``true.shape`` after axis movement.
        quantile_levels: Quantile levels τ ∈ (0,1), strictly increasing.
        quantile_axis: Axis of ``quantile_preds`` that holds the quantiles.
            If None, inferred (usually 0 or 1).
        eps: Small value for fallback in failed extrapolation.
        return_uniformity_test: If True, also return a dict with KS test statistic & p-value.
            Requires `scipy` to be installed.

    Returns:
        PIT values (flattened, shape (n_elements,)) in [0,1].
        If return_uniformity_test=True: tuple (pit_values, {'ks_stat': float, 'ks_pvalue': float})

    Raises:
        ValueError: Invalid shapes, insufficient quantiles, non-monotonic levels,
                    non-monotonic predictions after sorting, etc.
    """
    true_arr = np.asarray(true, dtype=np.float64)
    q_preds = np.asarray(quantile_preds, dtype=np.float64)
    taus = np.asarray(quantile_levels, dtype=np.float64)

    if true_arr.size == 0:
        raise ValueError("true cannot be empty")
    if q_preds.size == 0:
        raise ValueError("quantile_preds cannot be empty")
    if len(taus) < 2:
        raise ValueError("At least 2 quantile levels required for extrapolation")
    if np.any((taus <= 0) | (taus >= 1)):
        raise ValueError("Quantile levels must be in (0,1)")
    if np.any(np.diff(taus) <= 0):
        raise ValueError("Quantile levels must be strictly increasing")

    # Infer / move quantile axis to 0
    if quantile_axis is None:
        if q_preds.shape[0] == len(taus):
            quantile_axis = 0
        elif q_preds.ndim > 1 and q_preds.shape[1] == len(taus):
            quantile_axis = 1
        else:
            raise ValueError(f"Cannot infer quantile axis. shape={q_preds.shape}, len(quantile_levels)={len(taus)}")

    if quantile_axis != 0:
        q_preds = np.moveaxis(q_preds, quantile_axis, 0)

    if q_preds.shape[1:] != true_arr.shape:
        raise ValueError(f"Shape mismatch: quantile_preds[1:] = {q_preds.shape[1:]} vs true.shape = {true_arr.shape}")

    n_quantiles = len(taus)
    n_elements = true_arr.size
    true_flat = true_arr.ravel()  # (n_elements,)
    q_flat = q_preds.reshape(n_quantiles, n_elements)  # (n_q, n_elements)

    # Sort quantiles (and corresponding taus) per sample
    sort_idx = np.argsort(q_flat, axis=0)  # (n_q, n_elements)
    q_sorted = np.take_along_axis(q_flat, sort_idx, axis=0)
    tau_broad = np.broadcast_to(taus[:, None], (n_quantiles, n_elements))
    tau_sorted = np.take_along_axis(tau_broad, sort_idx, axis=0)

    # --- MONOTONICITY CHECK ---
    # After sorting quantiles, the corresponding tau values must be strictly increasing
    # for each sample to define a valid CDF.
    if not np.all(np.diff(tau_sorted, axis=0) > 0):
        raise ValueError(
            "Quantile predictions are not monotonic with respect to quantile levels "
            "for at least one sample. The resulting CDF would be invalid.",
        )

    # Tail extrapolation (vectorized)
    q0, q1 = q_sorted[0], q_sorted[1]
    tau0, tau1 = tau_sorted[0], tau_sorted[1]
    with np.errstate(divide="ignore", invalid="ignore"):
        slope_left = (q1 - q0) / (tau1 - tau0 + 1e-12)
    q_left = np.where(
        np.isfinite(slope_left),
        q0 + (0.0 - tau0) * slope_left,
        q0 - eps,
    )

    q_last, q_prev = q_sorted[-1], q_sorted[-2]
    tau_last, tau_prev = tau_sorted[-1], tau_sorted[-2]
    with np.errstate(divide="ignore", invalid="ignore"):
        slope_right = (q_last - q_prev) / (tau_last - tau_prev + 1e-12)
    q_right = np.where(
        np.isfinite(slope_right),
        q_last + (1.0 - tau_last) * slope_right,
        q_last + eps,
    )

    # Extended CDF points & levels
    q_ext = np.concatenate([q_left[None], q_sorted, q_right[None]], axis=0)  # (n_q+2, n_elements)
    tau_ext = np.concatenate([[0.0], taus, [1.0]])[:, None]  # (n_q+2, 1)

    # PIT = linear interpolation of tau_ext at true value in q_ext space
    pit_values = np.zeros(n_elements, dtype=np.float64)
    for i in range(n_elements):  # loop over samples (could be vectorized with care)
        pit_values[i] = np.interp(
            true_flat[i],
            q_ext[:, i],
            tau_ext[:, 0],
            left=0.0,
            right=1.0,
        )

    if return_uniformity_test:
        # Import scipy only when needed
        try:
            from scipy import stats
        except ImportError as err:
            raise ImportError(
                "scipy is required for uniformity test. Install scipy or set return_uniformity_test=False.",
            ) from err
        ks_stat, ks_pvalue = stats.kstest(pit_values, "uniform")
        return pit_values, {"ks_stat": ks_stat, "ks_pvalue": ks_pvalue}

    return pit_values


def pinball_score(
    true: np.ndarray,
    quantile_preds: np.ndarray,
    quantile_levels: np.ndarray | list[float] | tuple[float, ...],
    quantile_axis: int | None = None,
) -> float:
    r"""Mean pinball (quantile) loss across samples, time steps, channels and quantile levels.

    The pinball loss for a single prediction is:

    .. math::

        \rho_\tau(e) = \max(\tau e,\; (\tau-1)e), \quad e = y - \hat{q}_\tau

    The returned value is the average over **all** dimensions.

    Args:
        true: Ground truth values, shape ``(batch, horizon, channels)`` (or any shape).
        quantile_preds: Predicted quantiles. The quantile axis can be any dimension,
            but the remaining dimensions must match ``true.shape``.
        quantile_levels: Quantile levels τ ∈ (0,1), length must match the quantile dimension.
        quantile_axis: Explicitly specify which axis of ``quantile_preds`` holds the quantiles.
            If ``None``, the function tries to infer it (first or second axis).

    Returns:
        Scalar mean pinball loss.
    """
    true = np.asarray(true)
    quantile_preds = np.asarray(quantile_preds)
    taus = np.asarray(quantile_levels)

    if len(taus) == 0:
        raise ValueError("quantile_levels cannot be empty")
    if np.any((taus <= 0) | (taus >= 1)):
        raise ValueError("Quantile levels must be strictly between 0 and 1.")

    if quantile_axis is None:
        if quantile_preds.shape[0] == len(taus):
            quantile_axis = 0
        elif quantile_preds.ndim > 1 and quantile_preds.shape[1] == len(taus):
            quantile_axis = 1
        else:
            raise ValueError(
                f"Cannot infer quantile axis. quantile_preds.shape = {quantile_preds.shape}, "
                f"len(quantile_levels) = {len(taus)}. Please provide quantile_axis explicitly.",
            )

    if quantile_axis != 0:
        quantile_preds = np.moveaxis(quantile_preds, quantile_axis, 0)

    if quantile_preds.shape[1:] != true.shape:
        raise ValueError(
            f"Shape mismatch after removing quantile axis: "
            f"quantile_preds[1:] = {quantile_preds.shape[1:]}, true.shape = {true.shape}",
        )

    errors = true - quantile_preds
    taus_reshaped = taus.reshape(-1, *[1] * true.ndim)

    loss = np.maximum(taus_reshaped * errors, (taus_reshaped - 1.0) * errors)

    return float(loss.mean())


def crps_quantile(
    true: np.ndarray,
    quantile_preds: np.ndarray,
    quantile_levels: np.ndarray | list[float] | tuple[float, ...],
    quantile_axis: int | None = None,
    normalization: bool = True,
    eps: float = 1e-8,
) -> float:
    r"""Continuous Ranked Probability Score (CRPS) from quantile forecasts.

    The CRPS is a proper scoring rule that measures the accuracy of a probabilistic
    forecast. It compares the predicted cumulative distribution function (CDF) with
    the empirical CDF of the observation. Lower values indicate better forecasts,
    and 0 is perfect.

    For a set of predicted quantiles :math:`\hat{q}_{\tau_k}` at levels
    :math:`\tau_k`, the CRPS can be approximated as:

    .. math::
        \text{CRPS} \approx \frac{1}{N} \sum_{i=1}^N \int_{-\infty}^{\infty}
        \bigl( F_i(x) - \mathbf{1}_{x \ge y_i} \bigr)^2 dx

    where :math:`F_i` is the piecewise‑linear CDF constructed from the quantiles,
    with linear tails extrapolated to :math:`\tau=0` and :math:`\tau=1`. The integral
    is evaluated via the trapezoidal rule over the extended quantile points.

    Args:
        true: Ground truth values, shape ``(n_samples,)`` or any multi‑dimensional shape.
        quantile_preds: Predicted quantiles. The quantile axis can be any dimension,
            but the remaining dimensions must match ``true.shape``.
        quantile_levels: Quantile levels :math:`\tau \in (0,1)`, length must match the
            quantile dimension and be strictly increasing. At least two levels are required.
        quantile_axis: Explicitly specify which axis of ``quantile_preds`` holds the
            quantiles. If ``None``, the function tries to infer it (first or second axis).
        normalization: If True, divide the final CRPS by the standard deviation of
            the true values (scale‑independent).
        eps: Small constant used when extrapolation fails (e.g., identical quantiles).

    Returns:
        Scalar mean CRPS over all elements. Returns ``np.nan`` if ``true`` is empty.

    Raises:
        ValueError: If inputs are invalid, e.g., empty arrays, insufficient quantiles,
                    quantile levels not in (0,1), or shape mismatches.

    Example:
        >>> true = np.array([0.0, 2.0])
        >>> quantile_preds = np.array([[-0.5, 1.8], [0.2, 2.5], [0.8, 3.1]])
        >>> quantile_levels = [0.2, 0.5, 0.8]
        >>> crps_quantile(true, quantile_preds, quantile_levels, quantile_axis=0)
        0.18333333333333332
    """
    true = np.asarray(true)
    quantile_preds = np.asarray(quantile_preds)
    taus = np.asarray(quantile_levels)

    # --- Validation ---
    if true.size == 0:
        return np.nan
    if quantile_preds.size == 0:
        raise ValueError("quantile_preds cannot be empty")
    if len(taus) == 0:
        raise ValueError("quantile_levels cannot be empty")
    if len(taus) < 2:
        raise ValueError("At least two quantile levels are required for tail extrapolation.")
    if np.any((taus <= 0) | (taus >= 1)):
        raise ValueError("Quantile levels must be strictly between 0 and 1.")
    if np.any(np.diff(taus) <= 0):
        raise ValueError("Quantile levels must be strictly increasing.")

    # --- Quantile axis inference / movement ---
    if quantile_axis is None:
        if quantile_preds.shape[0] == len(taus):
            quantile_axis = 0
        elif quantile_preds.ndim > 1 and quantile_preds.shape[1] == len(taus):
            quantile_axis = 1
        else:
            raise ValueError(
                f"Cannot infer quantile axis. quantile_preds.shape = {quantile_preds.shape}, "
                f"len(quantile_levels) = {len(taus)}. Provide quantile_axis explicitly.",
            )
    if quantile_axis != 0:
        quantile_preds = np.moveaxis(quantile_preds, quantile_axis, 0)

    if quantile_preds.shape[1:] != true.shape:
        raise ValueError(
            f"Shape mismatch after removing quantile axis: "
            f"quantile_preds[1:] = {quantile_preds.shape[1:]}, true.shape = {true.shape}",
        )

    # --- Flatten all non‑quantile dimensions ---
    n_quantiles = len(taus)
    n_elements = true.size
    true_flat = true.ravel()  # (n_elements,)
    quantile_flat = quantile_preds.reshape(n_quantiles, n_elements)  # (n_q, n_elements)

    # --- Sort quantiles and taus together for each sample ---
    # Get indices that sort each column (sample) of quantile_flat
    sort_idx = np.argsort(quantile_flat, axis=0)  # (n_q, n_elements)
    # Use advanced indexing to reorder quantiles and taus per column
    q_sorted = np.take_along_axis(quantile_flat, sort_idx, axis=0)  # (n_q, n_elements)
    # For taus, broadcast to (n_q, n_elements) then sort per column
    tau_broad = np.broadcast_to(taus[:, None], (n_quantiles, n_elements))
    tau_sorted = np.take_along_axis(tau_broad, sort_idx, axis=0)  # (n_q, n_elements)

    # --- Tail extrapolation (vectorized across samples) ---
    # Left tail: use first two sorted quantiles
    q0 = q_sorted[0, :]  # first quantile (smallest) per sample
    q1 = q_sorted[1, :]  # second quantile per sample
    tau0 = tau_sorted[0, :]
    tau1 = tau_sorted[1, :]

    # Avoid division by zero where tau1 == tau0 (shouldn't happen, but guard)
    with np.errstate(divide="ignore", invalid="ignore"):
        slope_left = (q1 - q0) / (tau1 - tau0 + 1e-12)  # add tiny epsilon for safety
    # Where slope is undefined (tau1 ≈ tau0), fallback to using eps
    q_left = np.where(np.isfinite(slope_left), q0 + (0.0 - tau0) * slope_left, q0 - eps)

    # Right tail: use last two quantiles
    q_last = q_sorted[-1, :]
    q_second_last = q_sorted[-2, :]
    tau_last = tau_sorted[-1, :]
    tau_second_last = tau_sorted[-2, :]
    with np.errstate(divide="ignore", invalid="ignore"):
        slope_right = (q_last - q_second_last) / (tau_last - tau_second_last + 1e-12)
    q_right = np.where(np.isfinite(slope_right), q_last + (1.0 - tau_last) * slope_right, q_last + eps)

    # q_ext: shape (n_q+2, n_elements)
    q_ext = np.concatenate([q_left[None, :], q_sorted, q_right[None, :]], axis=0)
    # tau_ext: shape (n_q+2, 1) broadcastable to samples
    tau_ext = np.concatenate([[0.0], taus, [1.0]])[:, None]  # (n_q+2, 1)

    ind = (true_flat[None, :] <= q_ext).astype(float)  # (n_q+2, n_elements)

    integrand = (tau_ext - ind) ** 2  # (n_q+2, n_elements)

    crps_per_sample = np.trapezoid(integrand, x=q_ext, axis=0)  # type: ignore[attr-defined]  # (n_elements,)

    mean_crps = crps_per_sample.mean()

    if normalization:
        std_true = np.std(true)
        if std_true > 0:
            mean_crps /= std_true

    return float(mean_crps)


def quantile_sharpness(
    quantile_preds: np.ndarray,
    quantile_levels: list[float] | tuple[float, ...] | np.ndarray,
    quantile_axis: int | None = None,
) -> float:
    r"""Compute mean sharpness over symmetric quantile pairs (vectorized).

    Sharpness measures the average width of symmetric prediction intervals
    (e.g. for levels :math:`\tau` and :math:`1-\tau`). Narrower intervals
    indicate a sharper, more confident forecast.

    This implementation is fully vectorized across both samples and quantile pairs,
    using NumPy's advanced indexing for efficiency.

    Args:
        quantile_preds: Predicted quantiles. The quantile axis can be any dimension,
            but the remaining dimensions are treated as independent samples.
        quantile_levels: Quantile levels :math:`\tau \in (0,1)`, strictly increasing.
        quantile_axis: Axis of ``quantile_preds`` that holds the quantiles.
            If ``None``, the function tries to infer it (first or second axis).

    Returns:
        Mean interval width over all symmetric pairs found. Returns ``0.0``
        when no symmetric pairs exist.

    Raises:
        ValueError: If inputs are invalid (empty, quantile levels not in (0,1),
                    non‑increasing levels, shape mismatch, etc.).
    """
    q_preds = np.asarray(quantile_preds, dtype=np.float64)
    taus = np.asarray(quantile_levels, dtype=np.float64)

    if q_preds.size == 0:
        raise ValueError("quantile_preds cannot be empty")
    if len(taus) == 0:
        raise ValueError("quantile_levels cannot be empty")
    if np.any((taus <= 0) | (taus >= 1)):
        raise ValueError("Quantile levels must be strictly between 0 and 1.")
    if np.any(np.diff(taus) <= 0):
        raise ValueError("Quantile levels must be strictly increasing.")

    # --- Quantile axis inference / movement ---
    if quantile_axis is None:
        if q_preds.shape[0] == len(taus):
            quantile_axis = 0
        elif q_preds.ndim > 1 and q_preds.shape[1] == len(taus):
            quantile_axis = 1
        else:
            raise ValueError(
                f"Cannot infer quantile axis. quantile_preds.shape = {q_preds.shape}, "
                f"len(quantile_levels) = {len(taus)}. Provide quantile_axis explicitly.",
            )
    if quantile_axis != 0:
        q_preds = np.moveaxis(q_preds, quantile_axis, 0)

    n_quantiles = len(taus)
    n_elements = q_preds.size // n_quantiles
    q_flat = q_preds.reshape(n_quantiles, n_elements)  # (n_q, n_elements)

    # Build a mapping from tau value to its index (using rounding to avoid floating errors)
    tau_to_idx = {round(float(t), 8): i for i, t in enumerate(taus)}
    # Get all tau values that have a complement > themselves
    lower_taus = [t for t in tau_to_idx if t < 0.5 and (1.0 - t) in tau_to_idx]
    if not lower_taus:
        return 0.0

    lower_indices = np.array([tau_to_idx[t] for t in lower_taus], dtype=int)
    upper_indices = np.array([tau_to_idx[1.0 - t] for t in lower_taus], dtype=int)

    # Compute widths for all pairs and all samples in one vectorized operation
    widths = q_flat[upper_indices] - q_flat[lower_indices]  # (n_pairs, n_elements)

    mean_widths_per_pair = np.mean(widths, axis=1)
    return float(np.mean(mean_widths_per_pair))


def calibration_coverage(
    true: np.ndarray,
    quantile_preds: np.ndarray,
    quantile_levels: list[float] | tuple[float, ...] | np.ndarray,
    quantile_axis: int | None = None,
) -> np.ndarray:
    r"""Compute empirical coverage for each quantile level.

    For a well-calibrated forecast, the fraction of observations below the
    predicted :math:`\tau`-quantile should be close to :math:`\tau`.

    Args:
        true: Ground truth values, any shape.
        quantile_preds: Predicted quantiles. The quantile axis can be any dimension,
            but the remaining dimensions must match ``true.shape``.
        quantile_levels: Quantile levels :math:`\tau \in (0,1)`, strictly increasing.
        quantile_axis: Axis of ``quantile_preds`` that holds the quantiles.
            If ``None``, the function tries to infer it (first or second axis).

    Returns:
        Empirical coverage for each quantile level, shape ``(n_levels,)``.

    Raises:
        ValueError: If inputs are invalid (empty, quantile levels not in (0,1),
                    non‑increasing, shape mismatch, etc.).
    """
    true_arr = np.asarray(true, dtype=np.float64)
    q_preds = np.asarray(quantile_preds, dtype=np.float64)
    taus = np.asarray(quantile_levels, dtype=np.float64)

    if true_arr.size == 0:
        raise ValueError("true cannot be empty")
    if q_preds.size == 0:
        raise ValueError("quantile_preds cannot be empty")
    if len(taus) == 0:
        raise ValueError("quantile_levels cannot be empty")
    if np.any((taus <= 0) | (taus >= 1)):
        raise ValueError("Quantile levels must be strictly between 0 and 1.")
    if np.any(np.diff(taus) <= 0):
        raise ValueError("Quantile levels must be strictly increasing.")

    # --- Quantile axis inference / movement ---
    if quantile_axis is None:
        if q_preds.shape[0] == len(taus):
            quantile_axis = 0
        elif q_preds.ndim > 1 and q_preds.shape[1] == len(taus):
            quantile_axis = 1
        else:
            raise ValueError(
                f"Cannot infer quantile axis. quantile_preds.shape = {q_preds.shape}, "
                f"len(quantile_levels) = {len(taus)}. Provide quantile_axis explicitly.",
            )
    if quantile_axis != 0:
        q_preds = np.moveaxis(q_preds, quantile_axis, 0)

    if q_preds.shape[1:] != true_arr.shape:
        raise ValueError(f"Shape mismatch: quantile_preds[1:] = {q_preds.shape[1:]}, true.shape = {true_arr.shape}")

    n_quantiles = len(taus)
    n_elements = true_arr.size
    true_flat = true_arr.ravel()  # (n_elements,)
    q_flat = q_preds.reshape(n_quantiles, n_elements)  # (n_q, n_elements)

    coverage: np.ndarray = (true_flat[None, :] <= q_flat).mean(axis=1)  # (n_q,)
    return coverage


def _pinball_exact_taus(
    true: np.ndarray,
    quantile_preds: np.ndarray,
    quantile_levels: np.ndarray,
) -> float:
    """Mean pinball loss when each quantile/step has its own tau value.

    Handles the FPQR case where ``quantile_levels`` is ``(N, T)`` - i.e. each
    quantile proposal is different for every time step within the horizon.

    Args:
        true: Ground truth, shape ``(T,)``.
        quantile_preds: Predicted quantiles, shape ``(N, T)``.
        quantile_levels: Per-step tau values, shape ``(N, T)``.

    Returns:
        Scalar mean pinball loss averaged over all ``(N, T)`` elements.
    """
    errors = true[None, :] - quantile_preds  # (N, T)
    loss = np.maximum(quantile_levels * errors, (quantile_levels - 1.0) * errors)
    return float(loss.mean())


def wql(
    true: np.ndarray,
    quantile_preds: np.ndarray,
    quantile_levels: np.ndarray | list[float] | tuple[float, ...],
    quantile_axis: int | None = None,
) -> float:
    r"""Compute the Weighted Quantile Loss (WQL), also known as the scaled pinball loss.

    WQL is the GluonTS / M5 standard aggregate quantile metric.  It is the mean
    pinball loss normalised by the total absolute volume of observations, making
    it comparable across series with different scales:

    .. math::

        WQL = \frac{2 \sum_{\tau} \sum_{t} \rho_\tau(y_t, \hat{q}_{\tau,t})}
              {|\mathcal{T}| \cdot \sum_t |y_t|}

    where :math:`\rho_\tau(y, q) = \max(\tau(y-q),\, (\tau-1)(y-q))` is the
    pinball (check) loss.

    Args:
        true: Ground truth values, shape ``(n_samples,)`` or any shape compatible
            with ``quantile_preds`` after removing the quantile axis.
        quantile_preds: Predicted quantiles. The quantile axis can be any dimension,
            but the remaining dimensions must match ``true.shape``.
        quantile_levels: Quantile levels τ ∈ (0,1), length must match the quantile
            dimension and be strictly increasing.
        quantile_axis: Explicitly specify which axis of ``quantile_preds`` holds the
            quantiles. If ``None``, the function tries to infer it.

    Returns:
        Scalar WQL. Lower is better; 0 is perfect.

    Raises:
        ValueError: If inputs are invalid (empty, levels out of range, shape mismatch,
                    or zero total observation volume).

    References:
        Alexandrov et al. (2020). GluonTS: Probabilistic and neural time series
        modeling in Python. *Journal of Machine Learning Research*, 21(116), 1–6.

    Examples:
        >>> import numpy as np
        >>> true = np.array([1.0, 2.0, 3.0])
        >>> quantile_preds = np.array([[0.8, 1.8, 2.8], [1.0, 2.0, 3.0], [1.2, 2.2, 3.2]])
        >>> wql(true, quantile_preds, [0.1, 0.5, 0.9], quantile_axis=0)
    """
    true_arr = np.asarray(true, dtype=float)
    q_preds = np.asarray(quantile_preds, dtype=float)
    taus = np.asarray(quantile_levels, dtype=float)

    if true_arr.size == 0:
        raise ValueError("true cannot be empty")
    if len(taus) == 0:
        raise ValueError("quantile_levels cannot be empty")
    if np.any((taus <= 0) | (taus >= 1)):
        raise ValueError("Quantile levels must be strictly between 0 and 1.")

    if quantile_axis is None:
        if q_preds.shape[0] == len(taus):
            quantile_axis = 0
        elif q_preds.ndim > 1 and q_preds.shape[1] == len(taus):
            quantile_axis = 1
        else:
            raise ValueError(
                f"Cannot infer quantile axis. quantile_preds.shape={q_preds.shape}, "
                f"len(quantile_levels)={len(taus)}. Provide quantile_axis explicitly.",
            )
    if quantile_axis != 0:
        q_preds = np.moveaxis(q_preds, quantile_axis, 0)

    if q_preds.shape[1:] != true_arr.shape:
        raise ValueError(
            f"Shape mismatch after removing quantile axis: "
            f"quantile_preds[1:] = {q_preds.shape[1:]}, true.shape = {true_arr.shape}",
        )

    total_volume = np.sum(np.abs(true_arr))
    if total_volume == 0:
        raise ValueError("Sum of |true| is zero; WQL is undefined.")

    errors = true_arr[None, :] - q_preds  # (n_q, *true.shape)
    taus_reshaped = taus.reshape(-1, *[1] * true_arr.ndim)
    pinball_losses = np.maximum(taus_reshaped * errors, (taus_reshaped - 1.0) * errors)
    return float(2.0 * pinball_losses.sum() / (len(taus) * total_volume))


def get_quantile_metrics(
    true: np.ndarray,
    quantiles: np.ndarray,
    quantile_levels: list[float] | np.ndarray,
) -> pd.DataFrame:
    """Compute quantile‑based metrics for a single slice (e.g., one day, one target).

    Given ground truth values and the corresponding predicted quantiles,
    this function calculates the following aggregated metrics:

    - **pinball**: Mean pinball loss over all samples and quantile levels.
    - **crps**: Continuous Ranked Probability Score approximated from the
      piecewise‑linear CDF built from the quantiles (with linear tail
      extrapolation). Lower is better; 0 is perfect.
    - **calibration_error**: Mean absolute deviation between the empirical
      coverage (fraction of true values ≤ predicted quantile) and the nominal
      quantile levels. A perfectly calibrated forecast yields 0.
    - **sharpness**: Average width of symmetric prediction intervals
      (e.g., for levels τ and 1‑τ). Narrower intervals indicate sharper
      forecasts.

    Args:
        true: Ground truth values. Shape (n_samples,).
        quantiles: Predicted quantiles. Shape (n_quantiles, n_samples).
        quantile_levels: List of quantile levels corresponding to the first
            dimension of `quantiles`. Must be strictly increasing and lie in
            (0,1). Length must equal `n_quantiles`.

    Returns:
        A single‑row pandas DataFrame with the columns:
            "pinball", "crps", "calibration_error", "sharpness".

    Raises:
        ValueError: If input shapes are inconsistent or if quantile levels
            are invalid (the underlying metric functions will raise).
    """
    levels = np.asarray(quantile_levels)

    if levels.ndim == 2:
        # Per-step taus (FPQR): shape (N, T).
        # Use exact per-step tau for pinball; representative mean for other metrics.
        pinball = _pinball_exact_taus(true, quantiles, levels)
        rep_levels = levels.mean(axis=1)  # (N,) - monotonic representative grid
    else:
        # Standard 1-D taus shared across all time steps.
        pinball = pinball_score(true, quantile_preds=quantiles, quantile_levels=levels, quantile_axis=0)
        rep_levels = levels

    crps = crps_quantile(
        true,
        quantile_preds=quantiles,
        quantile_levels=rep_levels,
        quantile_axis=0,
        normalization=False,
    )
    sharpness = quantile_sharpness(quantile_preds=quantiles, quantile_levels=rep_levels, quantile_axis=0)

    # Calibration error: mean |empirical - nominal|
    empirical = np.array([np.mean(true <= q) for q in quantiles])
    nominal = rep_levels
    calib_error = float(np.mean(np.abs(empirical - nominal)))

    wql_score = wql(true, quantiles, quantile_levels=rep_levels, quantile_axis=0)
    return pd.DataFrame(
        [{"pinball": pinball, "wql": wql_score, "crps": crps, "calibration_error": calib_error, "sharpness": sharpness}]
    )


def evaluate_quantile_forecast(
    result: ForecastResult,
    alpha: float = 0.01,
    true_nmpi: float | None = None,
    metric_names: list[str] | None = None,
) -> pd.DataFrame:
    """Evaluate quantile forecasts by computing daily point, interval, and quantile metrics.

    Args:
        result: :class:`~twiga.forecaster.result.ForecastResult` with
            ``ground_truth``, ``quantiles``, and ``quantile_levels`` set,
            ``kind=ForecastKind.QUANTILE``.
        alpha: Significance level for interval metrics; the outermost quantile
            pair (``q[0]`` / ``q[-1]``) is used as lower/upper bounds.
            Defaults to ``0.01``.
        true_nmpi: Optional reference value for NMPI normalisation.  When
            ``None`` the standard deviation of the true values is used.
        metric_names: Point metric names to compute.  ``None`` computes all.

    Returns:
        DataFrame of per‑day, per‑target metrics indexed by daily timestamp.
        Columns include point metrics, interval metrics (coverage, NMPI, …),
        and quantile metrics (pinball, crps, calibration_error, sharpness).
    """
    from twiga.core.metrics._core import _evaluate_loop

    quantile_levels_raw = result.quantile_levels  # list[float] | np.ndarray | None

    def metric_fn(day_idx: int, target_idx: int) -> pd.DataFrame:
        true_vals = result.ground_truth[day_idx, :, target_idx]  # type: ignore[index]
        pred_vals = result.loc[day_idx, :, target_idx]
        # quantiles shape: (n_levels, n_steps) for this day/target
        q_vals = result.quantiles[day_idx, :, :, target_idx]  # type: ignore[index]
        lower_vals = q_vals[0]
        upper_vals = q_vals[-1]

        # For FPQR, quantile_levels is a 3-D ndarray (B, N, T); slice per day.
        if isinstance(quantile_levels_raw, np.ndarray) and quantile_levels_raw.ndim == 3:
            day_levels: list[float] | np.ndarray = quantile_levels_raw[day_idx]  # (N, T)
        else:
            day_levels = quantile_levels_raw or []  # type: ignore[assignment]

        point_scores = get_pointwise_metrics(y=true_vals, y_hat=pred_vals, metric_names=metric_names)
        interval_scores = get_interval_metrics(pred_vals, true_vals, lower_vals, upper_vals, alpha, true_nmpi)
        quantile_scores = get_quantile_metrics(true=true_vals, quantiles=q_vals, quantile_levels=day_levels)
        return pd.concat([point_scores, interval_scores, quantile_scores], axis=1)

    return _evaluate_loop(result, metric_fn)
