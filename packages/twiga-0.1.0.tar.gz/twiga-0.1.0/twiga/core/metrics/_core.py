"""Shared loop infrastructure for all evaluate_* metric functions.

This module is private to the metrics package.  External code should import
from :mod:`twiga.core.metrics` directly.
"""

from __future__ import annotations

from collections.abc import Callable

import pandas as pd

from twiga.forecaster.result import ForecastResult

__all__: list[str] = []  # private module - nothing exported


def _evaluate_loop(
    result: ForecastResult,
    metric_fn: Callable[[int, int], pd.DataFrame],
) -> pd.DataFrame:
    """Iterate over every (day, target) slice, apply *metric_fn*, and assemble.

    This is the single implementation of the day × target double loop that
    every ``evaluate_*`` function shares.  Each caller defines a two-argument
    closure that extracts the relevant arrays for a given ``(day_idx,
    target_idx)`` pair and returns a single-row metrics DataFrame.  The loop
    then attaches ``"target"`` and ``"timestamp"`` columns and concatenates
    across days.

    Args:
        result: A :class:`~twiga.forecaster.result.ForecastResult` whose
            ``ground_truth`` is already set (the caller is responsible for
            checking this).
        metric_fn: ``metric_fn(day_idx, target_idx) -> pd.DataFrame`` -
            returns a single-row DataFrame of scalar metrics for the given
            slice.  Must **not** insert ``"target"`` or ``"timestamp"``
            columns; the loop does that.

    Returns:
        DataFrame indexed by daily timestamp with one row per (day, target).
    """
    num_days, _, num_targets = result.loc.shape
    daily_rows: list[pd.DataFrame] = []

    for day_idx in range(num_days):
        day_metrics: list[pd.DataFrame] = []

        for target_idx in range(num_targets):
            scores = metric_fn(day_idx, target_idx)
            scores.insert(0, "target", result.targets[target_idx])
            day_metrics.append(scores)

        day_df = pd.concat(day_metrics, ignore_index=True)

        # Extract the daily timestamp from the first target column (axis-0).
        # Using index 0 avoids the subtle scoping bug in the original code
        # where the last target_idx from the inner loop was used.
        ts = pd.to_datetime(result.timestamps[day_idx, :, 0], unit="ns", utc=True)
        daily_timestamp = ts.round("D")[-1]
        day_df.insert(0, "timestamp", daily_timestamp)

        daily_rows.append(day_df)

    df = pd.concat(daily_rows, ignore_index=True)
    df.set_index("timestamp", inplace=True)
    return df
