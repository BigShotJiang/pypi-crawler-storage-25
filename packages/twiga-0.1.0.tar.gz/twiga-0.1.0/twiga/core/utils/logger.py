"""twiga.core.logging.

------------------
Logging infrastructure for the Twiga forecasting library.

Library logging rules applied:
  - Only a NullHandler is attached at import time so Twiga never forces
    output on the caller (PEP 3118 / logging HOWTO).
  - Every Twiga module calls get_logger(__name__) for a named child logger.
  - configure() is the single opt-in entry point for user code / scripts.

Example:
    Inside any Twiga module::

        from twiga.core.logging import get_logger

        log = get_logger(__name__)
        log.info("Training started")

    From an experiment script::

        from twiga.core.logging import configure

        configure(level="INFO", log_file="results/run.log")
"""

from __future__ import annotations

from datetime import datetime
import logging
from pathlib import Path
import sys
import traceback

# ---------------------------------------------------------------------------
# ANSI palette
# ---------------------------------------------------------------------------

_RESET = "\033[0m"
_BOLD = "\033[1m"
_DIM = "\033[2m"

_COLOURS: dict[str, str] = {
    "DEBUG": "\033[36m",  # cyan
    "INFO": "\033[32m",  # green
    "WARNING": "\033[33m",  # yellow
    "ERROR": "\033[31m",  # red
    "CRITICAL": "\033[41;97m",  # white on red
}

_ABBREV: dict[str, str] = {
    "DEBUG": "DBG",
    "INFO": "INF",
    "WARNING": "WRN",
    "ERROR": "ERR",
    "CRITICAL": "CRT",
}


# ---------------------------------------------------------------------------
# Formatters
# ---------------------------------------------------------------------------


class _ColourFormatter(logging.Formatter):
    """Compact, colour-coded formatter for interactive console output.

    Produces single-line records such as::

        12:34:56  INF  forecaster.core  ❯  Fitting MLP-GAM …
        12:34:57  WRN  models.nn        ❯  No GPU found, falling back to CPU

    Colour is applied per level and stripped automatically when the stream
    is not a TTY.
    """

    _FMT = (
        "{dim}{time}{reset}  "
        "{colour}{bold}{level}{reset}  "
        "{dim}{name:<26}{reset}  "
        "{dim}❯{reset}  "
        "{colour}{message}{reset}"
    )

    def format(self, record: logging.LogRecord) -> str:
        """Format a log record with ANSI colour codes.

        Args:
            record: The log record to format.

        Returns:
            Formatted string with ANSI escape sequences.
        """
        colour = _COLOURS.get(record.levelname, "")
        level = _ABBREV.get(record.levelname, record.levelname[:3])
        time = datetime.fromtimestamp(record.created).strftime("%H:%M:%S")
        name = _trim_name(record.name)

        line = self._FMT.format(
            dim=_DIM,
            reset=_RESET,
            bold=_BOLD,
            colour=colour,
            time=time,
            level=level,
            name=name,
            message=record.getMessage(),
        )

        if record.exc_info:
            tb = "".join(traceback.format_exception(*record.exc_info))
            line += f"\n{_DIM}{tb.rstrip()}{_RESET}"

        return line


class _PlainFormatter(logging.Formatter):
    """Structured plain-text formatter for file output and log aggregators.

    Produces records such as::

        2024-03-11 12:34:56 | INFO     | twiga.forecaster.core | Fitting MLP-GAM …

    No ANSI codes are emitted, making this safe for log files, Datadog,
    and any other structured-log sink.
    """

    _FMT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    _DATE = "%Y-%m-%d %H:%M:%S"

    def __init__(self) -> None:
        super().__init__(fmt=self._FMT, datefmt=self._DATE)

    def format(self, record: logging.LogRecord) -> str:
        """Format a log record as plain structured text.

        Args:
            record: The log record to format.

        Returns:
            Formatted string without ANSI codes.
        """
        result = super().format(record)
        if record.exc_info:
            tb = "".join(traceback.format_exception(*record.exc_info))
            result += "\n" + tb.rstrip()
        return result


# ---------------------------------------------------------------------------
# Root library logger
# ---------------------------------------------------------------------------

_ROOT = "twiga"

# NullHandler → library never emits output unless configure() is called
_root_logger = logging.getLogger(_ROOT)
_root_logger.addHandler(logging.NullHandler())
_root_logger.propagate = False  # do not bubble into the user's root logger


def get_logger(name: str) -> logging.Logger:
    """Return a named child of the Twiga root logger.

    Call once at module level in every Twiga submodule::

        log = get_logger(__name__)

    Args:
        name: Dotted module name, typically ``__name__``. Automatically
            prefixed with ``"twiga."`` if not already present.

    Returns:
        A :class:`logging.Logger` that inherits handlers from the Twiga
        root logger.
    """
    if not name.startswith(_ROOT):
        name = f"{_ROOT}.{name}"
    return logging.getLogger(name)


# ---------------------------------------------------------------------------
# Public configuration API
# ---------------------------------------------------------------------------


def configure(
    level: str | int = "INFO",
    *,
    colour: bool = True,
    log_file: str | Path | None = None,
    file_level: str | int = "DEBUG",
    capture_warnings: bool = True,
) -> logging.Logger:
    """Activate Twiga logging. Call **once** from user code or experiment scripts.

    Sets up a console handler (optionally colour-coded) and an optional
    file handler. Safe to call multiple times - existing handlers are
    cleared before new ones are attached.

    Args:
        level: Console log level. Accepts level names (``"DEBUG"``,
            ``"INFO"``, …) or integer constants (``logging.DEBUG``, …).
            Defaults to ``"INFO"``.
        colour: Enable ANSI colour in console output. Automatically
            disabled when stdout is not a TTY (e.g. CI or redirected
            output). Defaults to ``True``.
        log_file: Optional path for a plain-text log file. Parent
            directory is created automatically if it does not exist.
            Defaults to ``None``.
        file_level: Log level for the file handler. Defaults to
            ``"DEBUG"`` so full detail is always captured on disk even
            when the console shows only ``"INFO"``.
        capture_warnings: Route :func:`warnings.warn` calls through the
            logging system. Defaults to ``True``.

    Returns:
        The configured root Twiga :class:`logging.Logger`.

    Raises:
        ValueError: If ``level`` or ``file_level`` is not a recognised
            log-level string.

    Example::

        configure(level="DEBUG", log_file="results/run.log")
    """
    root = logging.getLogger(_ROOT)
    for _h in root.handlers[:]:
        _h.close()
    root.handlers.clear()
    root.setLevel(logging.DEBUG)  # handlers apply their own level filters

    # -- Console handler --------------------------------------------------
    use_colour = colour and _is_tty(sys.stdout)
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(_parse_level(level))
    console.setFormatter(_ColourFormatter() if use_colour else _PlainFormatter())
    root.addHandler(console)

    # -- File handler -----------------------------------------------------
    if log_file is not None:
        path = Path(log_file)
        path.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(path, encoding="utf-8")
        fh.setLevel(_parse_level(file_level))
        fh.setFormatter(_PlainFormatter())
        root.addHandler(fh)

    # -- Python warnings → logging ----------------------------------------
    if capture_warnings:
        logging.captureWarnings(True)
        py_warn = logging.getLogger("py.warnings")
        py_warn.handlers = root.handlers

    # -- Silence noisy third-party loggers --------------------------------
    _noisy = ["matplotlib", "PIL", "urllib3", "filelock"]
    for name in _noisy:
        logging.getLogger(name).setLevel(logging.WARNING)

    return root


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


class LogContext:
    """Context manager that appends key-value pairs to every log record.

    Useful for attaching ephemeral context (model name, fold index, epoch)
    to a block of log calls without mutating the logger itself.

    Args:
        logger: The logger to augment inside the block.
        **context: Arbitrary key-value pairs appended to each message.

    Example::

        with LogContext(log, model="MLP-GAM", fold=2):
            log.info("Training started")
        # → "Training started  model=MLP-GAM  fold=2"
    """

    def __init__(self, logger: logging.Logger, **context: object) -> None:
        self._logger = logger
        self._context = context
        self._filter: logging.Filter | None = None

    def __enter__(self) -> LogContext:
        """Attach the context-injection filter to the logger."""
        suffix = "  " + "  ".join(f"{k}={v}" for k, v in self._context.items())

        class _Inject(logging.Filter):
            def filter(self_, record: logging.LogRecord) -> bool:  # noqa: N805
                record.msg = str(record.msg) + suffix
                return True

        self._filter = _Inject()
        self._logger.addFilter(self._filter)
        return self

    def __exit__(self, *_: object) -> None:
        """Remove the context-injection filter from the logger."""
        if self._filter is not None:
            self._logger.removeFilter(self._filter)


def log_section(logger: logging.Logger, title: str, width: int = 58) -> None:
    """Emit a visual section divider to mark pipeline stages.

    Args:
        logger: Logger used to emit the divider.
        title: Short label displayed at the centre of the line.
        width: Total character width of the divider. Defaults to 58.

    Example::

        log_section(log, "Data Loading")
        # → ──────────────────── Data Loading ────────────────────
    """
    pad = max(0, width - len(title) - 2)
    left = "─" * (pad // 2)
    right = "─" * (pad - pad // 2)
    logger.info("%s %s %s", left, title, right)


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _trim_name(name: str) -> str:
    """Shorten a dotted logger name to its last two segments.

    Args:
        name: Full dotted logger name, e.g. ``"twiga.forecaster.core"``.

    Returns:
        Shortened name, e.g. ``"forecaster.core"``.
    """
    parts = name.split(".")
    return ".".join(parts[-2:]) if len(parts) > 2 else name  # noqa: PLR2004


def _parse_level(level: str | int) -> int:
    """Resolve a log-level name or integer to a logging level constant.

    Args:
        level: Level name (``"DEBUG"``, ``"INFO"``, …) or integer constant.

    Returns:
        Integer logging level constant.

    Raises:
        TypeError: If ``level`` is an unrecognised string.
    """
    if isinstance(level, int):
        return level
    numeric = logging.getLevelName(level.upper())
    if not isinstance(numeric, int):
        raise TypeError(f"Unknown log level {level!r}. Use DEBUG / INFO / WARNING / ERROR / CRITICAL.")
    return numeric


def _is_tty(stream: object) -> bool:
    """Check whether a stream is connected to an interactive terminal.

    Args:
        stream: Any stream object, typically ``sys.stdout``.

    Returns:
        ``True`` if the stream exposes a TTY, ``False`` otherwise.
    """
    try:
        return stream.isatty()  # type: ignore[attr-defined]
    except AttributeError:
        return False
