"""Twiga statistical analysis toolkit - flat public API.

All statistical functions are re-exported here so callers can do::

    from twiga.core.stats import rank_correlation, compute_xicorr, adf_test
"""

from .ami import get_ami_profile
from .association import compute_anova_f, compute_chi2, rank_correlation
from .autocorr import calculate_durbin_watson, estimate_ar_order, get_pacf_values
from .entropy import (
    get_approx_entropy,
    get_dfa_exponent,
    get_hurst_exponent,
    get_permutation_entropy,
    get_sample_entropy,
)
from .mutual_information import compute_mutual_information
from .ppscore import compute_ppscore
from .residual import cooks_distance, get_standardized_residual, leverage_statistic
from .seasonality import get_acf_values, get_trend_seasonality
from .stationarity import adf_test, kpss_test
from .utils import get_entropy_parameters, get_optimal_lags, normalise_series, prepare_data
from .xicorr import compute_xicorr

__all__ = [
    # AMI forecastability profiling
    "get_ami_profile",
    # association
    "rank_correlation",
    "compute_anova_f",
    "compute_chi2",
    # autocorrelation
    "get_pacf_values",
    "estimate_ar_order",
    "calculate_durbin_watson",
    # entropy / complexity
    "get_approx_entropy",
    "get_permutation_entropy",
    "get_sample_entropy",
    "get_hurst_exponent",
    "get_dfa_exponent",
    # mutual information
    "compute_mutual_information",
    # predictive power score
    "compute_ppscore",
    # residual diagnostics
    "leverage_statistic",
    "get_standardized_residual",
    "cooks_distance",
    # seasonality / ACF / decomposition
    "get_acf_values",
    "get_trend_seasonality",
    # stationarity
    "adf_test",
    "kpss_test",
    # utils
    "normalise_series",
    "prepare_data",
    "get_optimal_lags",
    "get_entropy_parameters",
    # xi correlation
    "compute_xicorr",
]
