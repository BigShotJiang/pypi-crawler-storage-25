"""Xi Correlation Analysis Module.

This module implements Chatterjee's Xi correlation coefficient, a non-parametric
measure of dependence that can detect any functional relationship between
variables. Unlike Spearman or Pearson, Xi is asymmetric and excels at detecting
non-monotonic patterns (e.g., parabolic, sinusoidal, or step functions).
"""

from typing import Any
import warnings

import numpy as np
import pandas as pd
from scipy.stats import norm, rankdata

from twiga.core.utils.logger import get_logger

log = get_logger(__name__)


def _xicor_vector(x: np.ndarray, y: np.ndarray, ties: bool | str = "auto") -> tuple[float, float]:
    r"""Vectorized calculation of Chatterjee's Xi correlation (ξ).

    Based on Chatterjee (2021). The p-value is asymptotic one-sided (right tail).

    ξ = 1 - [ n * Σ |r_{i+1} - r_i| ] / [ 2 * Σ ℓ_i * (n - ℓ_i) ]

    where:
      - Data is sorted by x (ties in x broken deterministically via stable sort).
      - r_i = number of j such that y_j ≤ y_i   (after sorting by x)
      - ℓ_i = number of j such that y_j ≥ y_i   (after sorting by x)

    When there are no ties in y, this reduces exactly to the classic formula:
        1 - 3 * Σ |r_{i+1} - r_i| / (n² - 1)

    Args:
        x: Predictor array.
        y: Target array.
        ties: 'auto' (recommended), True (force general ties-aware formula),
              False (assume no ties in y → faster computation).

    Returns:
        A tuple of (xi_statistic, p_value). Returns (np.nan, np.nan) for
        degenerate cases (n < 2, constant y, or presence of NaNs).
    """
    x = np.asarray(x).ravel()
    y = np.asarray(y).ravel()
    n = len(y)

    # Handle degenerate cases early
    if n < 2 or np.isnan(x).any() or np.isnan(y).any():
        return np.nan, np.nan

    if n < 50:
        warnings.warn("Xi p-value is asymptotic; n < 50 may be unreliable.", UserWarning, stacklevel=2)

    # Determine whether to use the general ties-aware formula
    if ties == "auto":
        has_ties_in_y = len(np.unique(y)) < n
    elif isinstance(ties, bool):
        has_ties_in_y = ties
    else:
        raise ValueError(f"ties must be 'auto' or boolean, got {ties}")

    # Step 1: Stable sort by x (deterministic tie-breaking in x)
    order = np.argsort(x, kind="stable")
    y_sorted = y[order]

    # Step 2: r_i = number of y_j <= y_i (max rank)
    r = rankdata(y_sorted, method="max").astype(np.int64)

    # Common computation
    abs_diff_sum = np.sum(np.abs(np.diff(r)))

    if not has_ties_in_y:
        # Fast path: no ties in y → simplified classic formula
        statistic = 1.0 - (3.0 * abs_diff_sum / (n**2 - 1.0))
    else:
        # General formula: handles ties in y correctly
        l_data = n + 1 - rankdata(y_sorted, method="min").astype(np.int64)

        numerator = n * abs_diff_sum
        denominator = 2.0 * np.sum(l_data * (n - l_data))

        if denominator == 0:  # all y values identical
            return np.nan, np.nan

        statistic = 1.0 - (numerator / denominator)

    # Step 4: Asymptotic one-sided p-value (right tail for positive dependence)
    p_value = norm.sf(statistic, loc=0.0, scale=np.sqrt(2.0 / (5.0 * n)))

    return statistic, p_value


def _xicor_for_pair(data: pd.DataFrame, x_col: str, y_col: str, ties: bool | str = "auto") -> dict[str, Any]:
    """Helper to compute Xi correlation for one (x, y) pair."""
    x_vals = data[x_col].values
    y_vals = data[y_col].values

    # Guard against constant columns (would cause division by zero)
    if np.unique(x_vals).size <= 1 or np.unique(y_vals).size <= 1:
        return {"x": x_col, "y": y_col, "xicor": np.nan, "p_value": np.nan}

    xicor, p_val = _xicor_vector(x_vals, y_vals, ties)
    return {"x": x_col, "y": y_col, "xicor": xicor, "p_value": p_val}


def compute_xicorr(
    data: pd.DataFrame,
    target_col: str,
    variable_cols: list[str],
    ties: bool | str = "auto",
) -> pd.DataFrame:
    """Compute Xi correlation between target and multiple features.

    Args:
        data: Input DataFrame.
        target_col: Name of the dependent variable (y).
        variable_cols: List of independent variables (x) to test against the target.
        ties: Whether to account for ties in the target variable y.
              'auto' is recommended (detects ties automatically).

    Returns:
        DataFrame with columns ['col1', 'col2', 'xicor', 'p_value']
        sorted by xicor descending.
    """
    # 1. Clean data: Drop rows with NaNs in any relevant column
    relevant_cols = [target_col] + variable_cols
    subset = data[relevant_cols].dropna()

    if len(subset) < 2:
        return pd.DataFrame(columns=["col1", "col2", "xicor", "p_value"])

    # 2. Compute Xi for each variable
    scores = [_xicor_for_pair(subset, x_col, target_col, ties) for x_col in variable_cols]

    # 3. Format and sort results
    df_results = pd.DataFrame(scores)

    # Standardize column names: col1 = target, col2 = feature
    df_results = df_results.rename(columns={"y": "col1", "x": "col2"})

    return df_results.sort_values("xicor", ascending=False).reset_index(drop=True)
