"""Predictive Power Score (PPS) Analysis Module.

This module provides tools to calculate the Predictive Power Score (PPS),
an asymmetric, data-type-agnostic score that can detect linear or non-linear
relationships between two columns.

The score ranges from 0 (no predictive power) to 1 (perfect prediction).
It compares a Decision Tree model's performance against a naive baseline.
"""

from typing import Any

import numpy as np
import pandas as pd
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor

from twiga.core.utils.logger import get_logger

log = get_logger(__name__)


def _encode_series(series: pd.Series) -> tuple[np.ndarray, np.ndarray]:
    """Encodes categorical data to numeric formats for Scikit-Learn.

    Args:
        series: A pandas Series containing numeric or categorical data.

    Returns:
        A tuple containing (X_encoded, y_encoded).
    """
    if pd.api.types.is_numeric_dtype(series):
        return series.values.reshape(-1, 1), series.values

    encoded_values = LabelEncoder().fit_transform(series.astype(str))
    return encoded_values.reshape(-1, 1), encoded_values


def _error_dict(x: str, y: str, msg: str) -> dict[str, Any]:
    """Generates a standardized error dictionary for failed PPS calculations."""
    return {
        "x": x,
        "y": y,
        "ppscore": 0.0,
        "case": "error",
        "baseline_score": np.nan,
        "model_score": np.nan,
        "error": msg,
    }


def compute_ppscore(
    df: pd.DataFrame,
    x: str,
    y: str,
    sample: int | None = 5000,
    cross_validation: int = 4,
    random_seed: int = 123,
    catch_errors: bool = True,
) -> dict[str, Any]:
    """Calculates the Predictive Power Score for a single (x, y) pair.

    Args:
        df: The input pandas DataFrame.
        x: The name of the predictor (feature) column.
        y: The name of the target column to be predicted.
        sample: Max rows to sample. If None, uses all rows.
        cross_validation: Number of folds for cross-validation.
        random_seed: Seed for reproducibility.
        catch_errors: If True, returns error dict instead of raising Exception.

    Returns:
        A dictionary containing the PPS and underlying metrics.
    """
    try:
        # 1. Data Preparation
        data = df[[x, y]].dropna().copy()
        if sample and len(data) > sample:
            data = data.sample(sample, random_state=random_seed)

        if len(data) < cross_validation:
            return _error_dict(x, y, "Insufficient data after dropna")

        # 2. Task Detection
        unique_y = data[y].nunique()
        if unique_y <= 1:
            return _error_dict(x, y, "Target is constant")

        is_classification = (
            pd.api.types.is_categorical_dtype(data[y])
            or pd.api.types.is_object_dtype(data[y])
            or (pd.api.types.is_numeric_dtype(data[y]) and unique_y <= 20)
        )

        # 3. Encoding
        x_encoded, _ = _encode_series(data[x])
        _, y_encoded = _encode_series(data[y])

        # 4. Model Selection
        if is_classification:
            model = DecisionTreeClassifier(random_state=random_seed)
            scorer = "f1_weighted"
            baseline_model = DummyClassifier(strategy="most_frequent")
            perfect_score = 1.0
        else:
            model = DecisionTreeRegressor(random_state=random_seed)
            scorer = "neg_mean_absolute_error"
            baseline_model = DummyRegressor(strategy="mean")
            perfect_score = 0.0

        # 5. Scoring
        model_score = np.mean(cross_val_score(model, x_encoded, y_encoded, cv=cross_validation, scoring=scorer))
        baseline_score = np.mean(
            cross_val_score(baseline_model, x_encoded, y_encoded, cv=cross_validation, scoring=scorer),
        )

        # 6. Normalization
        if model_score <= baseline_score:
            ppscore = 0.0
        else:
            # Improvement over baseline relative to perfect score
            ppscore = (model_score - baseline_score) / (perfect_score - baseline_score)

        return {
            "x": x,
            "y": y,
            "ppscore": max(0.0, min(1.0, ppscore)),
            "case": "classification" if is_classification else "regression",
            "baseline_score": baseline_score,
            "model_score": model_score,
            "error": None,
        }

    except Exception as e:
        if catch_errors:
            return _error_dict(x, y, str(e))
        raise
