"""Horizon-specific Auto-Mutual Information (AMI) for forecastability profiling.

AMI measures how much the past of a series tells us about its future at each
forecast horizon *h*.  Unlike linear autocorrelation (ACF), AMI captures
nonlinear dependence, making it a richer characterisation of exploitable
structure across horizons.

All computation is performed on **first-differenced** values
``Δx_t = x_t - x_{t-1}``.  Level-based AMI is deceptive for series with
strong trend or level persistence (FX rates, electricity prices): such series
exhibit high AMI purely because consecutive levels are correlated, not because
the past contains exploitable information about future *changes*.
First-differencing removes level persistence so that AMI reflects structure
beyond the random-walk baseline.

References:
    Fraser, A. M., & Swinney, H. L. (1986). Independent coordinates for
    strange attractors from mutual information.
    *Physical Review A*, 33(2), 1134.
"""

from __future__ import annotations

import warnings

import numpy as np
import pandas as pd
from sklearn.feature_selection import mutual_info_regression

from twiga.core.utils.logger import get_logger

log = get_logger(__name__)


def get_ami_profile(
    series: np.ndarray | pd.Series,
    n_neighbors: int = 8,
    max_horizons: int | None = None,
    random_state: int = 42,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute the horizon-specific Auto-Mutual Information (AMI) profile.

    AMI(h) = I(Δx_t ; Δx_{t+h}) is estimated via the k-nearest-neighbour
    (kNN) estimator of Kraskov et al. (2004) as implemented in
    :func:`sklearn.feature_selection.mutual_info_regression`.  The kNN
    estimator is invariant to monotone rescaling, so no standardisation of
    the differenced series is applied.

    The profile is computed on the first-differenced series to remove level
    persistence and trend.  The raw (level) series is **not** modified by
    this function.

    Args:
        series: 1-D target series as a numpy array or pandas Series.
            Must be free of NaN values and have length >= ``n_neighbors + 2``
            after differencing.
        n_neighbors: Number of nearest neighbours for the kNN MI estimator.
            Higher values reduce variance but increase bias.  Defaults to
            ``8``, following the convention of Catt (2024).
        max_horizons: Maximum horizon *h* to include in the profile.  When
            ``None`` the maximum feasible horizon
            ``n_diff - (n_neighbors + 1)`` is used.  Provide an explicit
            value to cap the profile for long series and reduce runtime.
            Defaults to ``None``.
        random_state: Random seed for the kNN MI estimator.  Defaults to
            ``42``.

    Returns:
        Tuple ``(horizons, ami_values)`` where:

        - ``horizons`` is a 1-D integer array ``[1, 2, ..., max_h]``.
        - ``ami_values`` is a 1-D float array of non-negative AMI values
          (in nats) at each horizon, clipped to ``[0, inf)``.

        Both arrays are empty when the differenced series is too short to
        compute at least one horizon.

    Raises:
        ValueError: If ``series`` is not 1-D after squeezing.

    Examples:
        >>> import numpy as np
        >>> rng = np.random.default_rng(0)
        >>> signal = np.sin(2 * np.pi * np.arange(500) / 48) + 0.1 * rng.standard_normal(500)
        >>> horizons, ami = get_ami_profile(signal, max_horizons=96)
        >>> print(f"AMI(h=1)={ami[0]:.3f}  peak_h={horizons[ami.argmax()]}")
    """
    arr = np.asarray(series, dtype=float).squeeze()
    if arr.ndim != 1:
        raise ValueError(f"series must be 1-D after squeezing; got shape {arr.shape}.")

    diff = np.diff(arr)
    n_diff = len(diff)
    min_obs = n_neighbors + 2  # need at least this many pairs for h=1

    if n_diff < min_obs:
        log.warning(
            "AMI profile skipped: differenced series has %d observations "
            "(minimum %d for n_neighbors=%d).  Returning empty arrays.",
            n_diff,
            min_obs,
            n_neighbors,
        )
        return np.empty(0, dtype=int), np.empty(0, dtype=float)

    max_h_feasible = n_diff - (n_neighbors + 1)
    max_h = min(max_horizons, max_h_feasible) if max_horizons is not None else max_h_feasible

    if max_h < 1:
        log.warning(
            "AMI profile skipped: max_h=%d is less than 1.  Increase series length or reduce n_neighbors.",
            max_h,
        )
        return np.empty(0, dtype=int), np.empty(0, dtype=float)

    log.info(
        "Computing AMI profile: n_diff=%d, max_h=%d, n_neighbors=%d.",
        n_diff,
        max_h,
        n_neighbors,
    )

    horizons = np.arange(1, max_h + 1, dtype=int)
    ami_values = np.empty(max_h, dtype=float)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for idx, h in enumerate(horizons):
            x_past = diff[:-h].reshape(-1, 1)
            x_future = diff[h:]
            ami_raw = mutual_info_regression(
                x_past,
                x_future,
                n_neighbors=n_neighbors,
                random_state=random_state,
            )[0]
            ami_values[idx] = max(0.0, float(ami_raw))

    log.debug(
        "AMI profile complete: AMI(h=1)=%.4f, peak=%.4f@h=%d, mean=%.4f.",
        ami_values[0],
        ami_values.max(),
        int(horizons[ami_values.argmax()]),
        ami_values.mean(),
    )

    return horizons, ami_values
