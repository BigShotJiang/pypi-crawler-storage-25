"""Feature Association and Statistical Relevance Module.

This module provides univariate statistical measures to quantify the
relationship between features and a target variable, supporting
regression and classification tasks.
"""

import numpy as np
import pandas as pd
from sklearn.feature_selection import chi2, f_classif, f_regression


def rank_correlation(
    data: pd.DataFrame,
    target_col: str,
    variable_cols: list[str],
    method: str = "spearman",
) -> pd.DataFrame:
    """Compute correlation between target and each variable.

    Args:
        data: Input DataFrame.
        target_col: Name of target column.
        variable_cols: List of feature column names.
        method: 'pearson', 'kendall', or 'spearman'.

    Returns:
        DataFrame with columns ['target', 'feature', 'correlation']
        sorted by absolute correlation descending.
    """
    # dropna handles cases where missing values would return NaN or break logic
    relevant_cols = [target_col] + variable_cols
    subset = data[relevant_cols].dropna()

    if subset.empty:
        return pd.DataFrame(columns=["target", "feature", "correlation"])

    corrs = subset[variable_cols].corrwith(subset[target_col], method=method)

    result = pd.DataFrame({"target": target_col, "feature": corrs.index, "correlation": corrs.values})

    return result.sort_values("correlation", key=np.abs, ascending=False).reset_index(drop=True)


def compute_anova_f(
    data: pd.DataFrame,
    target: str,
    features: str | list[str],
    task: str = "regression",
    normalize: bool = False,
    pivot: bool = False,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Compute ANOVA F-scores and p-values for features.

    Args:
        data: Input DataFrame.
        target: Target column name.
        features: Feature column(s).
        task: "regression" (f_regression) or "classification" (f_classif).
        normalize: If True, scale F-scores to [0, 1].
        pivot: If True, return with features as index and target as column.

    Returns:
        Tuple of (f_scores_df, p_values_df).
    """
    if isinstance(features, str):
        features = [features]

    # Clean data for the specific pair/set
    subset = data[[target] + features].dropna()
    x_vals = subset[features].values
    y_vals = subset[target].values

    if task == "regression":
        f_scores, p_values = f_regression(x_vals, y_vals)
    elif task == "classification":
        f_scores, p_values = f_classif(x_vals, y_vals)
    else:
        raise ValueError("task must be 'regression' or 'classification'")

    if normalize and len(f_scores) > 0:
        max_score = np.max(f_scores)
        if max_score > 0:
            f_scores = f_scores / max_score

    df = pd.DataFrame({"target": target, "feature": features, "f_score": f_scores, "p_value": p_values})

    f_scores_df = df[["target", "feature", "f_score"]].sort_values("f_score", ascending=False)
    p_values_df = df[["target", "feature", "p_value"]].sort_values("p_value")

    if pivot:
        f_scores_df = f_scores_df.pivot(index="feature", columns="target", values="f_score")
        p_values_df = p_values_df.pivot(index="feature", columns="target", values="p_value")

    return f_scores_df.reset_index() if not pivot else f_scores_df, p_values_df


def compute_chi2(
    data: pd.DataFrame,
    target: str,
    features: str | list[str],
    pivot: bool = False,
) -> pd.DataFrame:
    """Compute Chi-square statistic for categorical features.

    Requires non-negative feature values (e.g., counts, binary flags).
    """
    if isinstance(features, str):
        features = [features]

    subset = data[[target] + features].dropna()
    if subset[features].min().min() < 0:
        raise ValueError("Chi-square requires non-negative feature values.")

    scores, p_vals = chi2(subset[features].values, subset[target].values)

    result = pd.DataFrame({"target": target, "feature": features, "chi2_score": scores, "p_value": p_vals})
    result = result.sort_values("chi2_score", ascending=False)

    if pivot:
        return result.set_index("feature")[["chi2_score"]]
    return result.reset_index(drop=True)
