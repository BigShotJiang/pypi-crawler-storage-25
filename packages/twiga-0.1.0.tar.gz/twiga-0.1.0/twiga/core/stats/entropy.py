"""Entropy measures for time series forecastability analysis."""

import antropy as ant
import numpy as np
import pandas as pd

from twiga.core.utils.logger import get_logger

from .utils import get_entropy_parameters, normalise_series

log = get_logger(__name__)


def get_approx_entropy(
    series: np.ndarray | pd.Series,
    order: int | None = None,
    metric: str = "chebyshev",
    r: float | None = None,
) -> float:
    """Calculate approximate entropy for a time series.

    Approximate entropy (ApEn) quantifies the regularity and unpredictability
    of fluctuations in time-series data. Lower values indicate more regular
    and predictable patterns, while higher values suggest more randomness.

    Args:
        series: One-dimensional time series data.
        order: Embedding dimension (pattern length). Determines the length
            of sequences to compare. Default is 2.
        metric: Distance metric for pattern matching. Default is 'chebyshev'.
            Other options include 'euclidean', 'cityblock', etc.
        r: Tolerance threshold for pattern matching. If None, defaults to
            0.2 * std(series), which is the standard practice. This parameter
            defines what "similar" means when comparing patterns.

    Returns:
        Approximate entropy value. Returns np.nan if calculation fails.

    Examples:
        >>> import numpy as np
        >>> regular_series = np.array([1, 2, 1, 2, 1, 2])
        >>> get_approx_entropy(regular_series)
        0.123  # Low entropy - regular pattern

        >>> random_series = np.random.rand(100)
        >>> get_approx_entropy(random_series)
        0.876  # High entropy - random pattern

    Notes:
        The default tolerance r = 0.2 * std is based on the work of Pincus (1991)
        and is widely used in physiological time series analysis.
    """
    if order is None:
        params = get_entropy_parameters(series, method="approximate")
        order = int(params.get("order", 2))
        r = params.get("r", None)
    try:
        series = normalise_series(series)
        if r is None:
            r = 0.2 * np.std(series, ddof=0)
        return ant.app_entropy(series, order=order, metric=metric, tolerance=r)
    except (ValueError, RuntimeError) as e:
        log.warning("Approximate entropy calculation failed: %s", str(e))
        return np.nan


def get_permutation_entropy(
    series: np.ndarray | pd.Series,
    order: int | None = None,
    delay: int = 1,
    normalize: bool = True,
) -> float:
    """Calculate permutation entropy for a time series.

    Permutation entropy (PE) measures the complexity of a time series by
    analyzing the order relations between values. It captures the diversity
    of patterns in the data, with higher values indicating more complex and
    less predictable behavior.

    Args:
        series: One-dimensional time series data.
        order: Embedding dimension (pattern length). Determines the length
            of sequences to analyze. Default is 3.
        delay: Time delay between elements in the sequence. Default is 1.
        normalize: Whether to normalize the entropy value to [0, 1]. Default is True.

    Returns:
        Permutation entropy value. Returns np.nan if calculation fails.

    Examples:
        >>> import numpy as np
        >>> regular_series = np.array([1, 2, 3, 1, 2, 3])
        >>> get_permutation_entropy(regular_series)
        0.123  # Low entropy - regular pattern

        >>> random_series = np.random.rand(100)
        >>> get_permutation_entropy(random_series)
        0.876  # High entropy - random pattern

    Notes:
        The choice of order and delay can significantly affect the PE value.
        Common practice is to use order=3 and delay=1 for many applications.
    """
    if order is None:
        params = get_entropy_parameters(series, method="permutation")
        order = int(params.get("order", 2))
        delay = int(params.get("delay", 1))
    try:
        series = normalise_series(series)
        return ant.perm_entropy(series, order=order, delay=delay, normalize=normalize)
    except (ValueError, RuntimeError) as e:
        log.warning("Permutation entropy calculation failed: %s", str(e))
        return np.nan


def get_sample_entropy(series: np.ndarray | pd.Series, order: int | None = None, r: float | None = None) -> float:
    """Calculate sample entropy for a time series.

    Sample entropy (SampEn) quantifies the regularity and complexity of a time
    series by measuring the likelihood that similar patterns will not be followed
    by additional similar values. Lower values indicate more regular and predictable
    patterns, while higher values suggest more randomness.

    Args:
        series: One-dimensional time series data.
        order: Embedding dimension (pattern length). Determines the length
            of sequences to compare. Default is 2.
        r: Tolerance threshold for pattern matching. If None, defaults to
            0.2 * std(series), which is the standard practice. This parameter
            defines what "similar" means when comparing patterns.

    Returns:
        Sample entropy value. Returns np.nan if calculation fails.

    Examples:
        >>> import numpy as np
        >>> regular_series = np.array([1, 2, 1, 2, 1, 2])
        >>> get_sample_entropy(regular_series)
        0.123  # Low entropy - regular pattern

        >>> random_series = np.random.rand(100)
        >>> get_sample_entropy(random_series)
        0.876  # High entropy - random pattern

    Notes:
        The default tolerance r = 0.2 * std is based on the work of Richman and Moorman (2000)
        and is widely used in physiological time series analysis.
        Sample entropy always uses Chebyshev distance metric internally.

        Interpretation guidelines for forecastability (approximate, with standard parameters):
            - Values < 0.5: Highly regular, predictable patterns - excellent forecastability
            - Values 0.5-1.0: Moderately predictable with some randomness - good forecastability
            - Values > 1.0: High complexity, chaotic behavior - challenging to forecast

        Note: These ranges are context-dependent and vary with data characteristics,
        embedding dimension, and tolerance threshold. Use relative comparisons between
        series rather than absolute thresholds when possible.
    """
    if order is None:
        params = get_entropy_parameters(series, method="sample")
        order = int(params.get("order", 2))
        r = params.get("r", None)
    try:
        series = normalise_series(series)
        if r is None:
            r = 0.2 * np.std(series, ddof=0)
        return ant.sample_entropy(series, order=order, tolerance=r)
    except (ValueError, RuntimeError) as e:
        log.warning("Sample entropy calculation failed: %s", str(e))
        return np.nan


def get_hurst_exponent(series: np.ndarray | pd.Series) -> float:
    """Calculate Hurst exponent for a time series.

    The Hurst exponent (H) measures the long-term memory of a time series. It
    quantifies the tendency of a time series to either regress strongly to the
    mean (H < 0.5), behave like a random walk (H ≈ 0.5), or exhibit long-term
    positive autocorrelation (H > 0.5).

    Args:
        series: One-dimensional time series data.

    Returns:
        Hurst exponent value. Returns np.nan if calculation fails.

    Examples:
        >>> import numpy as np
        >>> random_series = np.random.rand(100)
        >>> get_hurst_exponent(random_series)
        0.5  # Random walk - no long-term memory
    """
    try:
        from hurst import compute_Hc

        clean_series = normalise_series(series)
        hurst_exponent, _, _ = compute_Hc(clean_series, kind="change", simplified=True)
        return float(hurst_exponent)
    except (ValueError, RuntimeError, TypeError, ImportError, ZeroDivisionError) as e:
        log.warning("Hurst exponent calculation failed: %s", str(e))
        return np.nan


def get_dfa_exponent(series: np.ndarray | pd.Series) -> float:
    """Calculate Detrended Fluctuation Analysis (DFA) exponent for a time series.

    The DFA exponent (alpha) quantifies the presence of long-range correlations
    in a time series. It measures how the root-mean-square fluctuation of the
    integrated and detrended time series scales with the window size. Values
    of alpha indicate:
        - alpha < 0.5: Anti-persistent behavior (values tend to revert to the mean)
        - alpha ≈ 0.5: Uncorrelated (white noise)
        - alpha > 0.5: Persistent behavior (values tend to continue in the same direction)
    """
    try:
        clean_series = normalise_series(series)
        return float(ant.detrended_fluctuation(clean_series))
    except (ValueError, RuntimeError, TypeError, ImportError, ZeroDivisionError) as e:
        log.warning("DFA exponent calculation failed: %s", str(e))
        return np.nan
