from __future__ import annotations

import numpy as np
from numpy.typing import NDArray


def leverage_statistic(x: NDArray[np.float64]) -> NDArray[np.float64]:
    r"""Compute the hat-matrix diagonal (leverage) for OLS.

    Args:
        x: Feature matrix **without** intercept column.
           Shape ``(n_samples, n_features)``. 1-D arrays are reshaped to
           ``(n_samples, 1)``.

    Returns:
        Leverage values for each observation. Each value lies in ``[0, 1]``.
        High values indicate observations far from the feature centroid.

    Notes:
        The hat matrix is:

        .. math::
            H = x(x^{\\top}x)^{-1}x^{\\top}

        The diagonal :math:`h_{ii}` is the **leverage**. It measures how much
        the :math:`i`-th point influences the fitted coefficients. Points
        with :math:`h_{ii} > \\frac{2(p+1)}{n}` are often considered high-leverage.

    Examples:
        >>> x = np.array([[1], [2], [3]])
        >>> leverage_statistic(x)
        array([0.7, 0.45, 0.85])
    """
    if x.ndim == 1:
        x = x.reshape(-1, 1)

    x_aug = np.column_stack([np.ones(x.shape[0]), x])

    try:
        xtx_inv = np.linalg.inv(x_aug.T @ x_aug)
    except np.linalg.LinAlgError:  # pragma: no cover
        xtx_inv = np.linalg.pinv(x_aug.T @ x_aug)

    return np.diag(x_aug @ xtx_inv @ x_aug.T)


def get_standardized_residual(
    y_true: NDArray[np.float64],
    y_pred: NDArray[np.float64],
    x: NDArray[np.float64],
) -> NDArray[np.float64]:
    r"""Compute standardized residuals for OLS diagnostics.

    Args:
        y_true: True target values. Shape ``(n_samples,)``.
        y_pred: Model predictions. Same shape as ``y_true``.
        x: Feature matrix **without** intercept (same as used for fitting).

    Returns:
        Standardized residuals :math:`\\tilde{r}_i`. Under OLS assumptions,
        they approximately follow :math:`N(0,1)`.

    Notes:
        Raw residual: :math:`r_i = y_i - \\hat{y}_i`.

        Variance of :math:`r_i`: :math:`\\sigma^2 (1 - h_{ii})`.

        Standardized residual:

        .. math::
            \\tilde{r}_i = \\frac{r_i}{\\hat{\\sigma} \\sqrt{1 - h_{ii}}}

        This removes heteroscedasticity due to leverage and enables
        normality checks via Q-Q plots.

    Examples:
        >>> y_true = np.array([3.0, 5.0, 7.0])
        >>> y_pred = np.array([3.1, 4.8, 7.2])
        >>> x = np.array([[1], [2], [3]])
        >>> get_standardized_residual(y_true, y_pred, x)
        array([-0.14..., -0.28...,  0.42...])
    """
    residuals = y_true - y_pred
    n_samples = len(residuals)
    n_params = x.shape[1] + 1
    sigma2_hat = np.sum(residuals**2) / (n_samples - n_params)

    lev = leverage_statistic(x)
    denominator = np.sqrt(sigma2_hat) * np.sqrt(1 - lev)
    return residuals / denominator


def cooks_distance(
    standardized_residuals: NDArray[np.float64],
    leverage: NDArray[np.float64],
    n_features: int,
) -> NDArray[np.float64]:
    r"""Compute Cook's distance  influence of each observation.

    Args:
        standardized_residuals: Output from :func:`get_standardized_residual`.
        leverage: Output from :func:`leverage_statistic`.
        n_features: Number of predictor variables (excluding intercept).

    Returns:
        Cook's distance :math:`D_i` for each observation.

    Notes:
        Cook's distance measures how much the regression coefficients would
        change if the :math:`i`-th point were deleted:

        .. math::
            D_i = \\frac{\\tilde{r}_i^2}{p+1} \\cdot \\frac{h_{ii}}{1 - h_{ii}}

        where :math:`p` is the number of predictors.

        Rule of thumb:
        - :math:`D_i > 1`: highly influential
        - :math:`D_i > \\frac{4}{n}`: potentially problematic

    Examples:
        >>> std_res = np.array([2.0, 0.5, 3.0])
        >>> lev = np.array([0.8, 0.3, 0.9])
        >>> cooks_distance(std_res, lev, n_features=2)
        array([8.0, 0.107..., 27.0])
    """
    multiplier = leverage / (1 - leverage)
    return (standardized_residuals**2 / (n_features + 1)) * multiplier
