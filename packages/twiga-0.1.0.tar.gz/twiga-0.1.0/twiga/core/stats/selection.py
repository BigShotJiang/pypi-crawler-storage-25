"""Statistical feature-selection metrics.

Provides DataFrame-level wrappers around scikit-learn selection scorers:
  - compute_association   : absolute Pearson (regression) or ANOVA F (classification)
  - compute_anova_f       : F-scores + p-values via f_regression / f_classif
  - compute_mutual_information : parallel MI via mutual_info_regression / _classif
  - compute_chi2          : Chi-square statistic for non-negative categorical features
  - compute_rf_importance : Random Forest MDI feature importance
"""

from __future__ import annotations

from functools import reduce
from typing import Literal

from joblib import Parallel, delayed
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.feature_selection import (
    SelectFromModel,
    f_classif,
    f_regression,
    mutual_info_classif,
    mutual_info_regression,
)

from twiga.core.utils.logger import get_logger

log = get_logger(__name__)


def compute_mutual_information(
    data: pd.DataFrame,
    target: str,
    features: str | list[str],
    task: Literal["regression", "classification"] = "regression",
    threshold: float | None = None,
    random_state: int | None = 200,
    pivot: bool = True,
    n_jobs: int = -1,
) -> pd.DataFrame:
    """Compute mutual information in parallel per feature.

    Args:
        data: Input DataFrame.
        target: Target column name.
        features: Feature column(s).
        task: "regression" or "classification".
        threshold: Minimum MI score to keep.
        random_state: Random seed.
        pivot: If True, pivot result.
        n_jobs: Parallel jobs (-1 = all cores).

    Returns:
        DataFrame with ["target", "feature", "score"] or pivoted.

    Example:
        >>> df = pd.DataFrame({"x": [1, 2, 3], "y": [1, 2, 3]})
        >>> compute_mutual_information(df, "y", "x", task="regression")
    """
    if isinstance(features, str):
        features = [features]

    inputs = data[features].values.astype(np.float64)
    target_vals = data[target].values
    n_features = inputs.shape[1]

    mi_func = mutual_info_regression if task == "regression" else mutual_info_classif

    mi_scores = np.array(
        Parallel(n_jobs=n_jobs)(
            delayed(lambda col: mi_func(col, target_vals, random_state=random_state)[0])(inputs[:, [i]])
            for i in range(n_features)
        ),
    )

    result = pd.DataFrame({"feature": features, "score": mi_scores, "target": target})
    result = result[["target", "feature", "score"]].sort_values("score", ascending=False)

    if threshold is not None:
        result = result[result["score"] >= threshold]

    if pivot:
        result = result.pivot(index="feature", columns="target", values="score")

    return result
