import numpy as np
import pandas as pd
from statsmodels.stats.stattools import durbin_watson
from statsmodels.tsa.stattools import pacf

from twiga.core.utils.logger import get_logger

log = get_logger(__name__)


def get_pacf_values(series, maxlag, alpha=0.05, method="ywm"):
    """Calculate PACF values and confidence intervals.

    Computes the Partial Autocorrelation Function using the Yule-Walker method
    and removes lag 0 (which is always 1.0) for practical use.

    Args:
        series: Time series data as numpy array or pandas Series.
        maxlag: Maximum lag order to calculate.
        alpha: Significance level for confidence intervals. Default is 0.05
            for 95% confidence.
        method: PACF estimation method. Default is 'ywm' (Yule-Walker).
            Other options include 'ols', 'ywunbiased', 'ld'.

    Returns:
        Tuple of (pacf_values, pacf_confint):
            - pacf_values: PACF coefficients excluding lag 0 (numpy array)
            - pacf_confint: Confidence intervals for each lag (numpy array of tuples)

    Examples:
        >>> import numpy as np
        >>> series = np.random.randn(100)
        >>> pacf_vals, conf_int = get_pacf_values(series, maxlag=10)
        >>> print(f"PACF at lag 1: {pacf_vals[0]:.4f}")
    """
    series_array = np.asarray(series, dtype=float)

    if len(series_array) == 0:
        raise ValueError("Series must contain at least one value.")

    if not np.all(np.isfinite(series_array)):
        raise ValueError("Series contains non-finite values.")

    if np.std(series_array, ddof=0) == 0:
        log.warning("PACF calculation skipped: constant series")
        pacf_values = np.zeros(maxlag + 1, dtype=float)
        pacf_values[0] = 1.0
        pacf_confint = np.zeros((maxlag + 1, 2), dtype=float)
    else:
        pacf_values, pacf_confint = pacf(series_array, nlags=maxlag, alpha=alpha, method=method)

    # Remove lag 0 (always 1.0)
    pacf_values = pacf_values[1:]
    pacf_confint = pacf_confint[1:]
    return pacf_values, pacf_confint


def estimate_ar_order(series: np.ndarray | pd.Series, maxlag: int, alpha: float = 0.05, method: str = "ywm"):
    """Estimate optimal AR model order using PACF analysis.

    Implements the Box-Jenkins methodology for AR order selection by analyzing
    the Partial Autocorrelation Function cutoff pattern. An AR(p) process should
    have significant PACF values up to lag p, then cut off to zero.

    Args:
        series: Time series data as numpy array or pandas Series.
        maxlag: Maximum lag order to evaluate.
        alpha: Significance level for confidence intervals. Default is 0.05
            for 95% confidence bands.
        method: PACF estimation method. Default is 'ywm' (Yule-Walker).

    Returns:
        Tuple of (significant_lags, suggested_ar_order):
            - significant_lags: List of integer lag values where PACF is
              statistically significant (outside confidence interval)
            - suggested_ar_order: Integer AR order where PACF cuts off.
              Represents the last consecutive significant lag.

    Examples:
        >>> import numpy as np
        >>> # Simulate AR(2) process
        >>> series = np.random.randn(200)
        >>> sig_lags, ar_order = estimate_ar_order(series, maxlag=10)
        >>> print(f"Suggested AR order: {ar_order}")
        >>> print(f"All significant lags: {sig_lags}")

    Note:
        If PACF shows non-consecutive significant lags (e.g., lags 1, 2, 5 are
        significant but 3, 4 are not), this suggests a more complex process
        (ARMA or seasonal) rather than pure AR.
    """
    _, pacf_confint = get_pacf_values(series, maxlag, alpha, method)

    # Identify significant lags (lag is significant if 0 is outside CI)
    significant_lags = []
    for i, (lower_ci, upper_ci) in enumerate(pacf_confint, 1):
        if lower_ci > 0 or upper_ci < 0:
            significant_lags.append(i)

    # Suggest AR order based on PACF cutoff
    # AR order is typically where PACF cuts off (becomes insignificant)
    suggested_ar_order = 0
    for i, (lower_ci, upper_ci) in enumerate(pacf_confint, 1):
        if lower_ci > 0 or upper_ci < 0:
            suggested_ar_order = i
        else:
            break  # First non-significant lag suggests AR cutoff

    return significant_lags, suggested_ar_order


def calculate_durbin_watson(series: np.ndarray | pd.Series, use_diff: bool = True) -> float:
    """Calculate Durbin-Watson statistic for autocorrelation testing.

    The Durbin-Watson statistic tests for first-order (lag-1) autocorrelation
    in time series or regression residuals. It's particularly useful for
    validating model assumptions.

    The statistic ranges from 0 to 4 with the following interpretation:
        - DW ≈ 2.0: No autocorrelation (ideal for residuals)
        - DW < 2.0: Positive autocorrelation (successive values similar)
        - DW > 2.0: Negative autocorrelation (successive values alternate)
        - DW ≈ 0.0: Strong positive autocorrelation
        - DW ≈ 4.0: Strong negative autocorrelation

    Args:
        series: Time series data or model residuals as numpy array or
            pandas Series.
        use_diff: Whether to apply first-differencing before testing.
            Set to True (default) for raw time series to remove trends.
            Set to False when testing residuals from fitted models, as
            they should already be stationary.

    Returns:
        Durbin-Watson statistic as float. Returns np.nan if:
            - Series is too short (n < 2)
            - After differencing, fewer than 3 observations remain
            - Calculation fails due to invalid data

    Raises:
        Does not raise exceptions; returns np.nan on failure and logs warnings.

    Examples:
        >>> import numpy as np
        >>> # Test raw time series (with differencing)
        >>> data = np.random.randn(100)
        >>> dw = calculate_durbin_watson(data, use_diff=True)
        >>> print(f"DW statistic: {dw:.4f}")
        >>>
        >>> # Test model residuals (no differencing)
        >>> # residuals = model.resid
        >>> # dw = calculate_durbin_watson(residuals, use_diff=False)

    Note:
        The Durbin-Watson test is most reliable for testing residuals from
        linear regression models. For general time series, consider also using
        the Ljung-Box test which can detect autocorrelation at multiple lags.
    """
    try:
        n = len(series)

        if n < 2:
            log.warning("Series too short for Durbin-Watson test (n=%d)", n)
            return np.nan

        # Apply first differencing if requested
        if use_diff:
            test_series = np.diff(series)
            if len(test_series) < 3:
                log.warning(
                    "Insufficient data after differencing for Durbin-Watson test (n=%d)",
                    len(test_series),
                )
                return np.nan
        else:
            test_series = series

        test_series = np.asarray(test_series, dtype=float)

        if not np.all(np.isfinite(test_series)):
            log.warning("Durbin-Watson calculation failed: non-finite values present")
            return np.nan

        if np.std(test_series, ddof=0) == 0:
            log.warning("Durbin-Watson calculation failed: constant series")
            return np.nan

        dw_stat = durbin_watson(test_series)

        log.debug("Durbin-Watson statistic calculated: %.4f", dw_stat)
        return float(np.asarray(dw_stat).item())

    except (ValueError, TypeError) as e:
        log.warning("Durbin-Watson calculation failed: %s", e)
        return np.nan
