"""Mutual Information Analysis Module.

Mutual Information (MI) measures the dependence between two variables.
It is non-negative, symmetric (mostly), and captures any kind of
relationship (linear or non-linear).
"""

from typing import Any

import numpy as np
import pandas as pd
from sklearn.feature_selection import mutual_info_classif, mutual_info_regression


def compute_mutual_information(
    data: pd.DataFrame,
    target: str,
    features: str | list[str],
    task: str = "regression",
    threshold: float | None = None,
    random_state: int | None = 200,
    pivot: bool = True,
) -> pd.DataFrame:
    """Compute mutual information between features and target.

    Args:
        data: Input DataFrame.
        target: Target column name.
        features: Feature column(s).
        task: "regression" or "classification".
        threshold: Minimum MI score to keep.
        random_state: Seed for reproducibility.
        pivot: If True, return with features as index.

    Returns:
        DataFrame containing MI scores.
    """
    if isinstance(features, str):
        features = [features]

    # Clean data: MI is sensitive to NaNs
    subset = data[[target] + features].dropna()
    if subset.empty:
        return pd.DataFrame(columns=["target", "feature", "score"])

    x_vals = subset[features].values
    y_vals = subset[target].values

    # Logic: Call the vectorized sklearn function once instead of looping
    if task == "regression":
        scores = mutual_info_regression(x_vals, y_vals, random_state=random_state)
    elif task == "classification":
        scores = mutual_info_classif(x_vals, y_vals, random_state=random_state)
    else:
        raise ValueError("task must be 'regression' or 'classification'")

    result = pd.DataFrame({"target": target, "feature": features, "score": scores})

    # Filtering and Sorting
    if threshold is not None:
        result = result[result["score"] >= threshold]

    result = result.sort_values("score", ascending=False)

    if pivot:
        return result.pivot(index="feature", columns="target", values="score")

    return result.reset_index(drop=True)
