"""Core utility helpers for time-series preprocessing and lag selection."""

import math
import re
from typing import Any

import numpy as np
import pandas as pd
from statsmodels.stats.diagnostic import acorr_ljungbox
from statsmodels.tsa.ar_model import AutoReg

from twiga.core.utils.logger import get_logger

log = get_logger(__name__)

_DEFAULT_EMBEDDING_DIM = 3
_EMBEDDING_CONFIG: list[tuple[float, float, int]] = [
    (0, 15, 4),
    (15, 30, 3),
    (30, 60, 2),
    (60, 1440, 6),
    (1440, 10080, 7),
    (10080, float("inf"), 4),
]


def _validate_input(data: pd.DataFrame, value_col_name: str, timestamp_col_name: str) -> None:
    """Validate input dataframe and required columns.

    Args:
        data: Input dataframe to validate.
        value_col_name: Name of the value column.
        timestamp_col_name: Name of the timestamp column.

    Raises:
        ValueError: If validation fails.
    """
    if not isinstance(data, pd.DataFrame):
        raise TypeError("Input data must be a pandas DataFrame.")
    if data.empty:
        raise ValueError("Input DataFrame is empty.")
    if value_col_name not in data.columns:
        raise ValueError(f"Value column '{value_col_name}' not found in data.")
    if timestamp_col_name not in data.columns:
        raise ValueError(f"Timestamp column '{timestamp_col_name}' not found in data.")
    if data[value_col_name].isnull().all():
        raise ValueError(f"Value column '{value_col_name}' contains only NaN values.")


def normalise_series(series: pd.Series | np.ndarray) -> pd.Series:
    """Normalize a series by centering and scaling to unit variance.

    Args:
        series: Input time-series values.

    Returns:
        Normalized series values.

    Raises:
        ValueError: If the series is empty or has zero/invalid variance.
    """
    clean_series = pd.Series(series).dropna()
    if clean_series.empty:
        raise ValueError("Input series is empty after dropping NaN values")

    mean_val = clean_series.mean()
    std_val = clean_series.std()

    if not np.isfinite(std_val) or np.isclose(std_val, 0.0):
        raise ValueError(f"Series has zero or invalid variance before normalization: std={std_val}, mean={mean_val}")

    series_normalized = (clean_series - mean_val) / std_val

    if not np.isfinite(series_normalized).all():
        raise ValueError("Normalization resulted in non-finite values")

    if np.isclose(series_normalized.std(), 0.0):
        raise ValueError("Series has zero variance after normalization")

    return series_normalized


def prepare_data(
    data: pd.DataFrame,
    value_col_name: str,
    timestamp_col_name: str,
    min_data_points: int = 30,
) -> pd.Series:
    """Prepare and clean input data for entropy calculations.

    Args:
        data: Input time-series dataframe.
        value_col_name: Name of the value column.
        timestamp_col_name: Name of the timestamp column.
        min_data_points: Minimum non-zero data points required.

    Returns:
        Cleaned series containing valid, positive values.

    Raises:
        ValueError: If data preparation fails.
    """
    _validate_input(data, value_col_name, timestamp_col_name)

    sorted_data = data.sort_values(timestamp_col_name).reset_index(drop=True)
    series = sorted_data[value_col_name].dropna()

    series_clean = series[series > 0]
    if len(series_clean) < min_data_points:
        raise ValueError(
            f"Insufficient non-zero data points: {len(series_clean)} (minimum required: {min_data_points})",
        )

    if not np.isfinite(series_clean).all():
        raise ValueError("Series contains non-finite values after cleaning")

    std_val = series_clean.std()
    if not np.isfinite(std_val) or np.isclose(std_val, 0.0):
        raise ValueError(
            f"Series has zero or invalid variance (constant values): std={std_val}, mean={series_clean.mean()}",
        )

    return series_clean


def get_sample_per_day(frequency: str | pd.Timedelta) -> int:
    """Calculate the number of samples per day from a sampling frequency.

    Supports pandas frequency strings and unit-only abbreviations like
    ``h``, ``min``, and ``s``.

    Args:
        frequency: Sampling frequency as a string or pandas Timedelta.

    Returns:
        Number of samples per day for the given frequency.

    Raises:
        ValueError: If the frequency cannot be parsed or is invalid.
    """
    if isinstance(frequency, pd.Timedelta):
        frequency_seconds = frequency.total_seconds()
    else:
        if not isinstance(frequency, str) or not frequency.strip():
            raise ValueError("Frequency must be a non-empty string or pandas Timedelta")

        frequency = frequency.strip()

        if re.match(r"^[A-Za-z]+$", frequency):
            frequency = f"1{frequency}"

        try:
            timedelta = pd.Timedelta(frequency)
            frequency_seconds = timedelta.total_seconds()
        except (ValueError, pd.errors.ParserError) as exc:
            raise ValueError(
                f"Unable to parse frequency '{frequency}'. Use pandas frequency strings like '30min', '1H', '15T'",
            ) from exc

    if frequency_seconds <= 0:
        raise ValueError("Frequency must represent a positive time duration")

    samples_per_day = 86400 / frequency_seconds

    return int(samples_per_day)


def _compute_ljung_box_pvalue(residuals: pd.Series | np.ndarray, lag: int) -> float | None:
    """Compute Ljung-Box p-value at a given lag.

    Args:
        residuals: Residual series from fitted model.
        lag: Lag index for the Ljung-Box test.

    Returns:
        p-value for the given lag, or ``np.nan`` if calculation fails.
    """
    try:
        lb_result = acorr_ljungbox(residuals, lags=[lag], return_df=True)
        return float(lb_result["lb_pvalue"].iloc[0])
    except (ValueError, IndexError) as exc:
        log.warning("Ljung-Box test failed for lag %d: %s", lag, exc)
        return np.nan


def _fit_model_for_lag(
    series: pd.Series | np.ndarray,
    lag: int,
    n: int,
    lb_test: bool = True,
) -> dict[str, Any] | None:
    """Fit an autoregressive model for a specific lag and return diagnostics.

    Args:
        series: Time-series data.
        lag: Lag count for the AR model.
        n: Total series length (used for minimum-data threshold check).
        lb_test: Whether to compute the Ljung-Box p-value on residuals.

    Returns:
        Dictionary with keys ``lag``, ``aic``, ``bic``, ``hqic``,
        ``lb_pvalue`` on success; ``None`` when insufficient data
        (``n - lag <= 10``) or model fitting fails.
    """
    if n - lag <= 10:
        return None

    try:
        model = AutoReg(series, lags=lag, old_names=False).fit()
        return {
            "lag": lag,
            "aic": model.aic,
            "bic": model.bic,
            "hqic": model.hqic,
            "lb_pvalue": _compute_ljung_box_pvalue(model.resid, lag) if lb_test else None,
        }
    except Exception as exc:
        log.warning("Model fitting failed for lag %d: %s", lag, exc)
        return None


def get_optimal_lags(
    series: pd.Series | np.ndarray,
    max_lags: int | None = None,
    min_data_points: int = 30,
    period: str | None = None,
    lb_test: bool = True,
) -> dict[str, Any]:
    """Select optimal autoregressive lags using multiple information criteria.

    The selection process evaluates fitted autoregressive models and compares:

    - AIC (Akaike Information Criterion)
    - BIC (Bayesian Information Criterion)
    - HQIC (Hannan-Quinn Information Criterion)

    Optionally, Ljung-Box residual diagnostics are also computed.

    Args:
        series: Time-series data.
        max_lags: Maximum lag count to evaluate. If ``None``, inferred from size.
        min_data_points: Minimum required series length.
        period: Optional seasonal period string (for example, ``"D"`` or ``"H"``).
        lb_test: Whether to include Ljung-Box residual diagnostics.

    Returns:
        Dictionary containing optimal lag by criterion and diagnostics.

    Raises:
        ValueError: If the series is too short or no model can be fitted.
    """
    n = len(series)

    if n < min_data_points:
        raise ValueError(f"Series too short: {n} observations. Need at least {min_data_points}.")

    if max_lags is None:
        max_lags = min(int(12 * (n / 100) ** 0.25), n // 3)

    if period:
        try:
            seasonal_lags = get_sample_per_day(period)
            max_lags = max(max_lags, seasonal_lags)
        except ValueError as exc:
            log.warning("Could not parse period '%s': %s", period, exc)

    max_lags = min(max_lags, n // 2)

    if max_lags < 1:
        raise ValueError("Insufficient data for lag selection.")

    criteria: dict[str, list] = {"lags": [], "aic": [], "bic": [], "hqic": [], "lb_pvalue": []}

    for lag in range(1, max_lags + 1):
        result = _fit_model_for_lag(series, lag=lag, n=n, lb_test=lb_test)
        if result is None:
            continue
        criteria["lags"].append(result["lag"])
        criteria["aic"].append(result["aic"])
        criteria["bic"].append(result["bic"])
        criteria["hqic"].append(result["hqic"])
        criteria["lb_pvalue"].append(result["lb_pvalue"])

    if not criteria["lags"]:
        raise ValueError("No valid lag models could be fitted.")

    optimal_aic = criteria["lags"][np.argmin(criteria["aic"])]
    optimal_bic = criteria["lags"][np.argmin(criteria["bic"])]
    optimal_hqic = criteria["lags"][np.argmin(criteria["hqic"])]

    return {
        "AIC": optimal_aic,
        "BIC": optimal_bic,
        "HQIC": optimal_hqic,
        "criteria_values": criteria,
        "max_lags_tested": max_lags,
        "valid_models": len(criteria["lags"]),
    }


def _normalise_period(period: str) -> str:
    """Normalise deprecated pandas frequency aliases (e.g. 'H'→'h', 'T'→'min')."""
    _alias_map = {"H": "h", "T": "min"}
    m = re.search(r"[a-zA-Z]+$", period)
    if m and m.group() in _alias_map:
        return period[: -len(m.group())] + _alias_map[m.group()]
    return period


def get_optimal_embedding(period: str) -> int:
    """Determine an embedding dimension from a pandas-style frequency period.

    Args:
        period: Sampling period string (for example, ``"15min"`` or ``"1h"``).

    Returns:
        Embedding dimension inferred from configured period buckets.
    """
    try:
        period_td = pd.Timedelta(_normalise_period(period))
        period_minutes = period_td.total_seconds() / 60.0

        for min_minutes, max_minutes, emb_dim in _EMBEDDING_CONFIG:
            if min_minutes < period_minutes <= max_minutes:
                log.debug(
                    "Period '%s' (%.1f minutes) mapped to embedding dimension %d",
                    period,
                    period_minutes,
                    emb_dim,
                )
                return emb_dim

    except (ValueError, TypeError) as exc:
        log.warning(
            "Could not parse period '%s': %s. Using default emb_dim=%d",
            period,
            exc,
            _DEFAULT_EMBEDDING_DIM,
        )

    return _DEFAULT_EMBEDDING_DIM


def _estimate_delay_from_autocorrelation(
    series: pd.Series | np.ndarray,
    max_lag: int | None = None,
) -> int:
    """Estimate time delay using the first ACF crossing below exp(-1)."""
    values = np.asarray(series, dtype=float)
    n = len(values)
    if n < 8:
        return 1

    centered = values - np.mean(values)
    variance = np.var(centered)
    if np.isclose(variance, 0.0):
        return 1

    if max_lag is None:
        max_lag = min(50, max(2, n // 4))

    acf_threshold = np.exp(-1)
    for lag in range(1, max_lag + 1):
        numerator = np.dot(centered[:-lag], centered[lag:])
        autocorr = numerator / ((n - lag) * variance)
        if autocorr <= acf_threshold:
            return lag

    return 1


def get_entropy_parameters(
    series: pd.Series | np.ndarray,
    method: str,
    period: str | pd.Timedelta | None = None,
    data_driven_delay: bool = True,
) -> dict[str, float | int]:
    """Recommend entropy embedding/tolerance parameters from theory-informed rules.

    Rules implemented:
    - Sample/Approximate entropy: ``m`` in {2, 3}, ``r`` in [0.1*sigma, 0.25*sigma].
    - Permutation entropy: ``m`` in [3, 7] with sample-size constraint ``n >> m!``.
    - Optional data-driven delay from autocorrelation first crossing.

    Args:
        series: Input series values.
        method: One of ``"sample"``, ``"approximate"``, or ``"permutation"``.
        period: Optional frequency hint used as a weak prior for embedding.
        data_driven_delay: Whether to estimate delay from autocorrelation.

    Returns:
        Parameter dictionary suitable for entropy functions.

    Raises:
        ValueError: If method is unsupported or series is invalid.
    """
    clean_series = normalise_series(series)
    n = len(clean_series)
    sigma = float(np.std(clean_series, ddof=0))
    method_key = method.strip().lower()

    if method_key in {"sample", "approximate", "sample_entropy", "approx_entropy"}:
        base_m = 2 if n < 200 else 3
        if period is not None:
            try:
                period_m = get_optimal_embedding(str(period))
                base_m = int(np.clip(period_m, 2, 3))
            except ValueError:
                base_m = 2 if n < 200 else 3

        lower_r = 0.1 * sigma
        upper_r = 0.25 * sigma
        recommended_r = float(np.clip(0.2 * sigma, lower_r, upper_r))

        return {
            "order": base_m,
            "tolerance": recommended_r,
            "r": recommended_r,
        }

    if method_key in {"permutation", "perm", "permutation_entropy"}:
        if n < 30:
            log.warning(
                "Very short series (n=%d) may be unstable for permutation entropy.",
                n,
            )

        max_order_by_sample = 3
        for candidate in range(3, 8):
            if n >= 10 * math.factorial(candidate):
                max_order_by_sample = candidate

        base_order = 3
        if period is not None:
            try:
                base_order = int(np.clip(get_optimal_embedding(str(period)), 3, 7))
            except ValueError:
                base_order = 3

        order = int(min(base_order, max_order_by_sample))
        delay = _estimate_delay_from_autocorrelation(clean_series) if data_driven_delay else 1

        return {
            "order": order,
            "delay": int(max(1, delay)),
        }

    raise ValueError("Unsupported method. Use 'sample', 'approximate', or 'permutation'.")
