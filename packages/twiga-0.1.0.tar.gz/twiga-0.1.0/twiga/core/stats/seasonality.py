"""Seasonality utilities for autocorrelation-based analysis and decomposition."""

import numpy as np
import pandas as pd
from statsmodels.tsa.seasonal import MSTL
from statsmodels.tsa.stattools import acf

from twiga.core.utils.logger import get_logger

log = get_logger(__name__)


def get_acf_values(  # pylint: disable=too-many-arguments,too-many-positional-arguments
    series: pd.Series | np.ndarray,
    maxlag: int | None = None,
    alpha: float = 0.05,
    seasonal_length: int | None = None,
    fft: bool = True,
    adjusted: bool = False,
    missing: str = "none",
) -> tuple[np.ndarray, np.ndarray]:
    """Compute ACF values and confidence intervals excluding lag 0.

    Args:
        series: Input time series.
        maxlag: Maximum lag to compute. If None, inferred from series length.
        alpha: Significance level for confidence intervals.
        seasonal_length: Optional seasonal period used to ensure enough lag coverage.
        fft: Whether to compute ACF using FFT.
        adjusted: Whether to use n-k denominator in autocovariance.
        missing: Missing-value handling mode for statsmodels ACF.

    Returns:
        Tuple of (acf_values, acf_confint), both excluding lag 0.

    Raises:
        ValueError: If ACF calculation fails.
    """
    n = len(series)

    if maxlag is None:
        maxlag = min(seasonal_length * 3, n // 3) if seasonal_length else min(int(12 * (n / 100) ** 0.25), n // 3, 100)

        # Ensure reasonable bounds for ACF
        maxlag = min(maxlag, n // 3, 200)

    seasonal_coverage = seasonal_length * 3 if seasonal_length is not None else 0
    maxlag = max(maxlag, seasonal_coverage)

    try:
        # qstat=False is required here since we unpack only (acf, confint)
        acf_values, acf_confint = acf(
            series,
            nlags=maxlag,
            alpha=alpha,
            missing=missing,
            qstat=False,
            adjusted=adjusted,
            fft=fft,
        )

        # Remove lag 0 (always 1.0)
        acf_values = acf_values[1:]
        acf_confint = acf_confint[1:]
        log.debug("ACF calculated for %d lags", maxlag)

    except Exception as e:
        raise ValueError(f"ACF calculation failed: {e}") from e

    return acf_values, acf_confint


def get_trend_seasonality(
    series: pd.Series,
    periods: list[int],
    component_names: list[str] | None = None,
    iterate: int = 3,
    seasonal_deg: int = 0,
    inner_iter: int = 2,
    outer_iter: int = 0,
) -> pd.DataFrame:
    """Decompose a time series into trend, seasonal components, and residuals using MSTL.

    MSTL (Multiple Seasonal-Trend decomposition using Loess) extends STL to
    handle multiple seasonality periods simultaneously — e.g. daily (48) and
    weekly (48 * 7) patterns in a 30-minute series.

    Args:
        series: Input time series as a pandas Series with a DatetimeIndex.
            Must not contain NaN values.
        periods: List of seasonal period lengths in number of observations.
            For example, ``[48]`` for a single daily cycle at 30-minute
            resolution, or ``[48, 336]`` for daily + weekly.
        component_names: Names for the seasonal components, one per period.
            If ``None``, defaults to ``["Seasonal_<p>" for p in periods]``.
        iterate: Number of outer MSTL iterations. Defaults to ``3``.
        seasonal_deg: Degree of the seasonal LOESS smoother (0 = constant,
            1 = linear). Defaults to ``0``.
        inner_iter: Number of inner loop iterations in STL. Defaults to ``2``.
        outer_iter: Number of outer (robustness) iterations in STL.
            Defaults to ``0``.

    Returns:
        DataFrame with the same index as ``series`` containing one column per
        seasonal component (named from ``component_names``), plus ``"Trend"``
        and ``"Residual"`` columns.

    Raises:
        ValueError: If ``len(periods) != len(component_names)`` when
            ``component_names`` is provided.
        ValueError: If ``series`` contains NaN values.
        ValueError: If any period is less than 2.

    Examples:
        >>> import pandas as pd, numpy as np
        >>> idx = pd.date_range("2024-01-01", periods=1000, freq="30min")
        >>> ts = pd.Series(np.sin(np.linspace(0, 40 * np.pi, 1000)), index=idx)
        >>> result = get_trend_seasonality(ts, periods=[48], component_names=["Daily"])
        >>> result.columns.tolist()
        ['Daily', 'Trend', 'Residual']
    """
    if component_names is None:
        component_names = [f"Seasonal_{p}" for p in periods]
    if len(periods) != len(component_names):
        raise ValueError(f"len(periods)={len(periods)} must equal len(component_names)={len(component_names)}.")
    if any(p < 2 for p in periods):
        raise ValueError("All period values must be >= 2.")
    if series.isna().any():
        raise ValueError("series contains NaN values; fill or drop them before decomposition.")

    mstl = MSTL(
        series,
        periods=periods,
        iterate=iterate,
        stl_kwargs={
            "seasonal_deg": seasonal_deg,
            "inner_iter": inner_iter,
            "outer_iter": outer_iter,
        },
    )
    result = mstl.fit()

    out = pd.DataFrame(index=series.index)
    seasonal = result.seasonal
    if seasonal.ndim == 2:
        for i, name in enumerate(component_names):
            if i < seasonal.shape[1]:
                out[name] = seasonal.values[:, i]
            else:
                log.warning("Period %d was dropped by MSTL (exceeds half the series length).", periods[i])
    else:
        # Single seasonal component (either one period requested, or all others were dropped)
        out[component_names[0]] = seasonal.values
        for name in component_names[1:]:
            log.warning("Component %r was dropped by MSTL (exceeds half the series length).", name)

    out["Trend"] = result.trend.values
    out["Residual"] = result.resid.values
    return out
