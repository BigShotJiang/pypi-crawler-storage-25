"""Stationarity test utilities for ADF and KPSS."""

from typing import Any
import warnings

import numpy as np
import pandas as pd
from statsmodels.tools.sm_exceptions import InterpolationWarning
from statsmodels.tsa.stattools import adfuller, kpss


def adf_test(
    values: pd.Series | np.ndarray,
    maxlag: int | None = None,
    regression: str = "c",
    autolag: str = "BIC",
) -> tuple[Any, ...]:
    """Run the Augmented Dickey-Fuller (ADF) test.

    Args:
        values: Input time series values.
        maxlag: Maximum lag order. If None, inferred from sample size.
        regression: Regression component ("c", "ct", "ctt", or "n").
        autolag: Method for automatic lag selection.

    Returns:
        Statsmodels ADF result tuple.

    Raises:
        ValueError: If input validation fails or test execution fails.
    """
    n = len(values)
    if n < 10:
        raise ValueError(f"Insufficient data: {n} observations. Need at least 10.")
    if maxlag is not None and (maxlag < 0 or maxlag >= n):
        raise ValueError(f"Invalid maxlag: {maxlag}. Must be between 0 and {n - 1}.")

    if maxlag is None:
        maxlag = min(int(12 * (n / 100) ** 0.25), n // 3)
    maxlag = min(maxlag, int((n - 1) ** (1 / 3)))

    try:
        return adfuller(
            values,
            maxlag=maxlag,
            regression=regression,
            autolag=autolag,
        )
    except Exception as e:
        raise ValueError(f"ADF test failed: {e}") from e


def kpss_test(
    values: pd.Series | np.ndarray,
    regression: str = "c",
    maxlag: int | None = None,
    suppress_interpolation_warning: bool = True,
) -> tuple[Any, ...]:
    """Run the KPSS stationarity test.

    Args:
        values: Input time series values.
        regression: Regression component ("c" or "ct").
        maxlag: Number of lags. If None, inferred from sample size.
        suppress_interpolation_warning: Whether to silence boundary p-value
            interpolation warnings from statsmodels.

    Returns:
        Statsmodels KPSS result tuple.

    Raises:
        ValueError: If input validation fails or test execution fails.
    """
    n = len(values)
    if n < 10:
        raise ValueError(f"Insufficient data: {n} observations. Need at least 10.")
    if maxlag is not None and (maxlag < 0 or maxlag >= n):
        raise ValueError(f"Invalid maxlag: {maxlag}. Must be between 0 and {n - 1}.")

    if maxlag is None:
        maxlag = int(4 * (n / 100) ** 0.25)
    maxlag = min(maxlag, int(4 * (n / 100) ** 0.25))

    try:
        with warnings.catch_warnings():
            if suppress_interpolation_warning:
                warnings.filterwarnings("ignore", category=InterpolationWarning)
            return kpss(
                values,
                regression=regression,
                nlags=maxlag,
            )
    except Exception as e:
        raise ValueError(f"KPSS test failed: {e}") from e
