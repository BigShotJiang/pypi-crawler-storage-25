"""Environment-driven configuration for Twiga MLOps components.

All settings can be overridden with ``TWIGA_`` prefixed environment variables,
making the library 12-factor compliant for containerised deployments.

Example environment variables::

    TWIGA_MLFLOW_TRACKING_URI=http://mlflow:5000
    TWIGA_MLFLOW_EXPERIMENT=energy-forecast
    TWIGA_SERVE_API_KEY=super-secret-key
    TWIGA_MODEL_CHECKPOINT_DIR=/mnt/models/checkpoints

Usage::

    from twiga.core.settings import TwigaSettings

    settings = TwigaSettings()
    tracker = TwigaTracker(
        experiment=settings.mlflow_experiment,
        tracking_uri=settings.mlflow_tracking_uri,
    )
"""

from __future__ import annotations

from pydantic import Field

try:
    from pydantic_settings import BaseSettings, SettingsConfigDict
except ModuleNotFoundError as exc:
    raise ModuleNotFoundError(
        "TwigaSettings requires the 'mlops' extra. Install with: pip install twiga[mlops]"
    ) from exc

__all__ = ["TwigaSettings"]


class TwigaSettings(BaseSettings):
    """Twiga runtime settings resolved from environment variables.

    Attributes:
        mlflow_tracking_uri: URI of the MLflow tracking server.
        mlflow_experiment: Default experiment name for training runs.
        serve_api_key: Secret key enforced by the FastAPI ``X-API-Key``
            header.  An empty string disables auth (development only).
        model_checkpoint_dir: Default root directory for model checkpoints.
        serve_report_dir: Directory where Evidently monitoring reports are saved.
    """

    model_config = SettingsConfigDict(
        env_prefix="TWIGA_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="allow",
    )

    mlflow_tracking_uri: str = Field(
        default="http://localhost:5000",
        description="MLflow tracking server URI.",
    )
    mlflow_experiment: str = Field(
        default="twiga",
        description="Default MLflow experiment name.",
    )
    serve_api_key: str = Field(
        default="",
        description="API key for X-API-Key header auth. Empty = no auth (dev only).",
    )
    model_checkpoint_dir: str = Field(
        default="checkpoints",
        description="Root directory for saved model checkpoints.",
    )
    serve_report_dir: str = Field(
        default="reports",
        description="Directory for Evidently monitoring HTML reports.",
    )
