"""Plotly plotting utilities with Twiga branding.

This module provides functions to create Plotly visualizations with consistent
Twiga styling and theming that aligns with the lets-plot Twiga theme.
"""

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import plotly.io as pio
from plotly.subplots import make_subplots

from .theme import (
    DEFAULT_FONT_FAMILY,
    TWIGA_PALETTE,
)


def set_plotly_theme(size: int = 12, font_family: str = DEFAULT_FONT_FAMILY) -> None:
    """Set the Twiga theme for Plotly plots.

    Applies Twiga branding with minimalist design philosophy matching the
    lets-plot theme. Features clean layouts, no grid lines, and consistent
    typography scaling.

    Args:
        size: Base font size in points. Defaults to 12. Other elements scale
            proportionally from this base.
        font_family: Font family string with fallbacks. Defaults to Segoe UI
            with modern alternatives. Recommended: "Inter", "Roboto",
            "Source Sans Pro", "IBM Plex Sans", "Nunito Sans".

    Example:
        >>> import plotly.graph_objects as go
        >>> from src.plot.plotly_plot import set_plotly_theme
        >>> set_plotly_theme(size=14)
        >>> fig = go.Figure(data=go.Scatter(x=[0, 1], y=[0, 1]))
        >>> fig.show()

    Note:
        This function modifies global Plotly state. Once called, all plots in
        the current session will use the Twiga theme unless explicitly overridden.

        To revert to default Plotly styling:
        >>> import plotly.io as pio
        >>> pio.templates.default = "plotly"
    """
    title_size = int(size * 1.6)
    axis_label_size = int(size * 1.2)

    custom_template = go.layout.Template(
        layout=go.Layout(
            colorway=TWIGA_PALETTE,
            xaxis={
                "showline": True,
                "showgrid": False,
                "showticklabels": True,
                "linecolor": "rgb(204, 204, 204)",
                "linewidth": 2,
                "ticks": "outside",
                "tickfont": {
                    "family": font_family,
                    "size": size,
                    "color": "rgb(82, 82, 82)",
                },
                "title": {
                    "font": {
                        "family": font_family,
                        "size": axis_label_size,
                        "color": "rgb(82, 82, 82)",
                    }
                },
            },
            yaxis={
                "showline": True,
                "showgrid": False,
                "showticklabels": True,
                "linecolor": "rgb(204, 204, 204)",
                "linewidth": 2,
                "ticks": "outside",
                "tickfont": {
                    "family": font_family,
                    "size": size,
                    "color": "rgb(82, 82, 82)",
                },
                "title": {
                    "font": {
                        "family": font_family,
                        "size": axis_label_size,
                        "color": "rgb(82, 82, 82)",
                    }
                },
            },
            title={
                "font": {
                    "family": font_family,
                    "size": title_size,
                    "color": "rgb(82, 82, 82)",
                },
                "x": 0.5,
                "xanchor": "center",
            },
            font={
                "size": size,
                "family": font_family,
                "color": "rgb(82, 82, 82)",
            },
            legend={
                "orientation": "h",
                "yanchor": "bottom",
                "y": 1.02,
                "xanchor": "center",
                "x": 0.5,
                "font": {
                    "family": font_family,
                    "size": size,
                },
            },
            plot_bgcolor="white",
            paper_bgcolor="white",
            autosize=True,
            margin={"l": 60, "r": 10, "t": 60, "b": 50},
        )
    )

    # Set the custom template as the default
    pio.templates["custom"] = custom_template
    pio.templates.default = "custom"


def fig_layout(
    fig: go.Figure,
    n_rows: int = 1,
    height_per_row: int = 150,
) -> go.Figure:
    """Apply standardized layout settings to a Plotly figure.

    Args:
        fig: Plotly figure object to modify.
        n_rows: Number of subplot rows (affects height calculation). Defaults to 1.
        height_per_row: Height in pixels allocated per subplot row. Defaults to 150.

    Returns:
        Modified figure with updated layout and annotations.
    """
    total_height = max(height_per_row * n_rows, 350)  # Ensure a minimum height for single-row plots
    fig.update_layout(autosize=True, margin={"l": 60, "r": 40, "t": 60, "b": 80}, height=total_height)
    fig.update_xaxes(title="")

    annotations = [
        {
            "xref": "paper",
            "yref": "paper",
            "x": 0.5,
            "y": -0.2,
            "xanchor": "center",
            "yanchor": "top",
            "font": {
                "family": DEFAULT_FONT_FAMILY,
                "size": 12,
                "color": "rgb(150,150,150)",
            },
            "showarrow": False,
        }
    ]

    fig.update_layout(annotations=annotations)
    return fig


def line_plot(
    data,
    x_col: str,
    y_col: str | list[str],
    y_label: str = "Power(kW)",
    line_shape: str = "hv",
    n_rows: int = 1,
) -> None:
    """Create a time series line plot with Twiga branding.

    This function generates an interactive line plot using Plotly Express with
    the Twiga theme applied. The plot automatically uses the custom template
    if `set_plotly_theme()` has been called.

    Args:
        data: DataFrame containing the time series data.
        x_col: Column name for x-axis (typically timestamp).
        y_col: Column name(s) for y-axis values. Can be a string or list of strings.
        y_label: Label for the y-axis. Defaults to "Power(kW)".
        line_shape: Line interpolation shape ('linear', 'spline', 'hv', 'vh', 'hvh', 'vhv').
            Defaults to "hv" (horizontal-then-vertical step).
        n_rows: Number of subplot rows (affects height calculation). Defaults to 1.

    Example:
        >>> from src.plot.plotly_plot import set_plotly_theme, line_plot
        >>> set_plotly_theme()
        >>> line_plot(data=df, x_col="timestamp", y_col="energy_kwh", y_label="Energy (kWh)")

    Note:
        Call `set_plotly_theme()` before using this function to ensure Twiga
        branding is applied. The figure is displayed automatically via `.show()`.
    """
    fig = px.line(data, x=x_col, y=y_col, line_shape=line_shape)
    fig.update_yaxes(title_text=y_label)
    fig = fig_layout(fig, n_rows=n_rows)
    fig.show()


def dual_line_plot(
    df: pd.DataFrame,
    target_col: str,
    exog_col: str | None = None,
    target_unit: str | None = None,
    exog_unit: str | None = None,
    colors: list[str] | None = None,
    dataset_name: str | None = None,
    n_rows: int = 1,
) -> go.Figure:
    """Creates a time series plot with optional dual-axis for exogenous data.

    Args:
        df: DataFrame containing the time series data.
        target_col: Column name for the primary Y-axis.
        exog_col: Optional column name for the secondary Y-axis.
        target_unit: Optional unit for the target (e.g., 'MW', 'USD').
        exog_unit: Optional unit for the exogenous variable.
        colors: Optional hex colors. Defaults to color-blind safe Blue/Vermilion.
        dataset_name: Optional name for the chart title.
        n_rows: Number of subplot rows (affects height calculation). Defaults to 1.

    Returns:
        A formatted plotly Figure object.
    """
    # 1. Setup Defaults (Color-blind safe: Okabe-Ito Blue & Vermilion)
    set_plotly_theme()
    plot_colors = colors or ["#0072B2", "#D55E00"]
    t_unit = target_unit or ""
    e_unit = exog_unit or ""
    display_name = dataset_name or "Dataset"

    # 2. Determine Subplot Strategy
    has_exog = exog_col is not None and exog_col in df.columns
    fig = make_subplots(specs=[[{"secondary_y": True}]]) if has_exog else go.Figure()

    # 3. Add Primary Trace (Target)
    fig.add_trace(
        go.Scatter(
            x=df["timestamp"],
            y=df[target_col],
            mode="lines",
            name=target_col,
            line={"color": plot_colors[0], "width": 2},
            hovertemplate=f"<b>{target_col}</b><br>%{{y:.2f}} {t_unit}<extra></extra>".strip(),
        ),
        secondary_y=False if has_exog else None,
    )

    # 4. Add Secondary Trace (Exogenous) - Conditional
    if has_exog:
        fig.add_trace(
            go.Scatter(
                x=df["timestamp"],
                y=df[exog_col],
                mode="lines",
                name=exog_col,
                line={"color": plot_colors[1], "width": 2},
                opacity=0.8,
                hovertemplate=f"<b>{exog_col}</b><br>%{{y:.2f}} {e_unit}<extra></extra>".strip(),
            ),
            secondary_y=True,
        )

    # 5. Apply Twiga Layout helper
    fig = fig_layout(fig=fig, n_rows=n_rows)

    # 6. Fine-tune Layout and Axes
    subtitle = f"Target: {target_col} vs. Exog: {exog_col}" if has_exog else f"Target: {target_col}"

    fig.update_layout(
        title_text=f"<b>{display_name}</b><br>{subtitle}",
        legend={
            "orientation": "h",
            "yanchor": "bottom",
            "y": 1.02,
            "xanchor": "right",
            "x": 1,
        },
        hovermode="x unified",
    )

    fig.update_xaxes(title_text="Time")

    # Primary Y-axis title
    y1_title = f"{target_col} ({t_unit})" if t_unit else target_col
    fig.update_yaxes(title_text=y1_title, secondary_y=False if has_exog else None)

    # Secondary Y-axis title (Conditional)
    if has_exog:
        y2_title = f"{exog_col} ({e_unit})" if e_unit else exog_col
        fig.update_yaxes(title_text=y2_title, secondary_y=True)

    return fig
