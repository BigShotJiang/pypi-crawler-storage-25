"""Professional Great Tables formatting aligned with the Twiga brand.

All table functions return ``GT`` objects that render directly in Jupyter
notebooks and can be exported to HTML, LaTeX, or RTF via the Great Tables API.
"""

from __future__ import annotations

from great_tables import GT, loc, style
import pandas as pd

# ── Twiga brand tokens ─────────────────────────────────────────────────────────
_TEAL = "#107591"  # deep teal  - headers, highlights, borders
_TEAL_MID = "#069fac"  # mid teal   - secondary accents
_TEAL_LIGHT = "#e8f5f8"  # pale teal  - row-stripe / best-value fill
_TEAL_BEST = "#d0ecf1"  # highlight  - best value cell background
_TEXT_DARK = "#2d3748"  # charcoal   - body text
_TEXT_MUTED = "#718096"  # slate      - caption / source notes
_WHITE = "#ffffff"
_STRIPE = "#f7fbfc"  # very faint teal - alternating row stripe


# ── Public API ─────────────────────────────────────────────────────────────────


def twiga_gt(
    gt: GT,
    *,
    width: str = "100%",
    striped: bool = True,
    n_rows: int | None = None,
) -> GT:
    """Apply the Twiga brand theme to any Great Tables ``GT`` object.

    Drop-in equivalent of :func:`twiga_theme` for tables.  Call this last,
    after ``.tab_header()``, ``.cols_label()``, ``.tab_source_note()``, etc.

    Args:
        gt: Any ``GT`` object to style.
        width: CSS width for the table container. Defaults to ``"100%"``.
        striped: If ``True``, apply alternating teal-tinted row stripes.
            Requires ``n_rows`` to work; if omitted, stripes are skipped.
        n_rows: Number of data rows in the table (needed for striping).

    Returns:
        The same ``GT`` object with Twiga styling applied.

    Examples:
        >>> from great_tables import GT, md
        >>> from twiga.core.plot.gt import twiga_gt
        >>>
        >>> table = twiga_gt(
        ...     GT(df)
        ...     .tab_header(title=md("**My Table**"), subtitle="Description")
        ...     .cols_label(col_a=md("**Col A**"), col_b=md("**Col B**"))
        ...     .tab_source_note("Source: Twiga Forecast"),
        ...     n_rows=len(df),
        ... )
        >>> table
    """
    gt = (
        gt.tab_options(
            # ── Container ──────────────────────────────────────────────────
            table_width=width,
            container_width=width,
            # ── Fonts ──────────────────────────────────────────────────────
            table_font_names=["Inter", "Segoe UI", "Roboto", "Helvetica Neue", "sans-serif"],
            table_font_size="13px",
            table_font_color=_TEXT_DARK,
            # ── Header (title / subtitle) ───────────────────────────────────
            heading_background_color=_WHITE,
            heading_title_font_size="16px",
            heading_title_font_weight="bold",
            heading_subtitle_font_size="13px",
            heading_padding="10px",
            # ── Column labels ───────────────────────────────────────────────
            column_labels_background_color=_TEAL,
            column_labels_font_weight="bold",
            column_labels_font_size="13px",
            column_labels_padding="9px",
            column_labels_border_bottom_color=_TEAL_MID,
            column_labels_border_bottom_width="1px",
            column_labels_border_bottom_style="solid",
            # ── Table body ──────────────────────────────────────────────────
            data_row_padding="7px",
            table_body_border_bottom_color="#e8e8e8",
            table_body_border_bottom_width="1px",
            table_body_border_bottom_style="solid",
            # ── Outer borders ───────────────────────────────────────────────
            table_border_top_color=_TEAL,
            table_border_top_width="2px",
            table_border_top_style="solid",
            table_border_bottom_color=_TEAL,
            table_border_bottom_width="1px",
            table_border_bottom_style="solid",
            # ── Source note ─────────────────────────────────────────────────
            source_notes_font_size="11px",
            source_notes_padding="6px",
        )
        # ── Title - charcoal, bold (neutral, matches twiga_theme title) ───
        .tab_style(
            style=style.text(color="#333333", weight="bold"),
            locations=loc.title(),
        )
        # ── Subtitle - muted slate ────────────────────────────────────────
        .tab_style(
            style=style.text(color=_TEXT_MUTED),
            locations=loc.subtitle(),
        )
        # ── Column label text - white on teal ─────────────────────────────
        .tab_style(
            style=style.text(color=_WHITE),
            locations=loc.column_labels(),
        )
        # ── Source note - muted ───────────────────────────────────────────
        .tab_style(
            style=style.text(color=_TEXT_MUTED, style="italic"),
            locations=loc.source_notes(),
        )
    )

    # ── Alternating row stripes ──────────────────────────────────────────────
    if striped and n_rows is not None:
        even_rows = list(range(1, n_rows, 2))
        if even_rows:
            gt = gt.tab_style(
                style=style.fill(color=_STRIPE),
                locations=loc.body(rows=even_rows),
            )

    return gt


def create_model_performance_table(
    res: pd.DataFrame,
    metrics: list[str],
    minimize_cols: list[str] | None = None,
    maximize_cols: list[str] | None = None,
    title: str = "Model Performance",
    subtitle: str | None = None,
    source_note: str = "Twiga Forecast",
    decimals: int = 3,
) -> GT:
    """Create a Twiga-branded performance comparison table with Great Tables.

    Renders model metrics in a clean, publication-ready table.  Best values
    are highlighted with a teal fill and bold text; alternating row stripes
    improve readability.

    Args:
        res: DataFrame with one row per model and metric columns.
        metrics: Column names to format as numbers.
        minimize_cols: Metric columns where a *lower* value is better
            (e.g. MAE, RMSE).  The minimum value is highlighted.
        maximize_cols: Metric columns where a *higher* value is better
            (e.g. Pearson-r).  The maximum value is highlighted.
        title: Table title.
        subtitle: Optional subtitle shown below the title.
        source_note: Attribution line shown at the bottom of the table.
        decimals: Decimal places for numeric formatting.

    Returns:
        A ``GT`` object ready for display in a Jupyter notebook.

    Examples:
        >>> from twiga.core.plot.gt import create_model_performance_table
        >>> table = create_model_performance_table(
        ...     metrics_df,
        ...     metrics=["MAE", "RMSE", "Pearson-r"],
        ...     minimize_cols=["MAE", "RMSE"],
        ...     maximize_cols=["Pearson-r"],
        ... )
        >>> table  # displays inline in a notebook
    """
    default_subtitle = subtitle or "Metric comparison across all evaluated models"

    gt = (
        GT(res)
        # ── Header ──────────────────────────────────────────────────────────
        .tab_header(title=title, subtitle=default_subtitle)
        # ── Numeric formatting ───────────────────────────────────────────────
        .fmt_number(columns=metrics, decimals=decimals)
        # ── Source note ──────────────────────────────────────────────────────
        .tab_source_note(source_note)
        # ── Global table options ─────────────────────────────────────────────
        .tab_options(
            # Fonts
            table_font_names=["Inter", "Segoe UI", "Roboto", "Helvetica Neue", "sans-serif"],
            # Title block
            heading_background_color=_WHITE,
            heading_title_font_size="15px",
            heading_title_font_weight="bold",
            heading_subtitle_font_size="12px",
            # Column labels (header row)
            column_labels_background_color=_TEAL,
            column_labels_font_weight="bold",
            column_labels_font_size="12px",
            column_labels_padding="8px",
            # Body
            data_row_padding="6px",
            table_font_size="12px",
            table_font_color=_TEXT_DARK,
            # Borders
            table_border_top_color=_TEAL,
            table_border_top_width="2px",
            table_border_bottom_color=_TEAL,
            table_border_bottom_width="1px",
            column_labels_border_bottom_color=_TEAL_MID,
            column_labels_border_bottom_width="1px",
            # Source note
            source_notes_font_size="11px",
            source_notes_padding="6px",
        )
        # ── Title text styling ───────────────────────────────────────────────
        .tab_style(
            style=style.text(color=_TEAL, weight="bold"),
            locations=loc.title(),
        )
        .tab_style(
            style=style.text(color=_TEXT_MUTED),
            locations=loc.subtitle(),
        )
        # ── Column label text color (white on teal background) ───────────────
        .tab_style(
            style=style.text(color=_WHITE),
            locations=loc.column_labels(),
        )
        # ── Source note text color ───────────────────────────────────────────
        .tab_style(
            style=style.text(color=_TEXT_MUTED),
            locations=loc.source_notes(),
        )
    )

    # ── Alternating row stripes ──────────────────────────────────────────────
    even_rows = list(range(1, len(res), 2))
    if even_rows:
        gt = gt.tab_style(
            style=style.fill(color=_STRIPE),
            locations=loc.body(rows=even_rows),
        )

    # ── Best-value highlighting ──────────────────────────────────────────────
    if minimize_cols:
        for col in minimize_cols:
            if col in res.columns:
                best_idx = int(res[col].idxmin())
                gt = gt.tab_style(
                    style=[
                        style.fill(color=_TEAL_BEST),
                        style.text(weight="bold", color=_TEAL),
                    ],
                    locations=loc.body(rows=best_idx, columns=col),
                )

    if maximize_cols:
        for col in maximize_cols:
            if col in res.columns:
                best_idx = int(res[col].idxmax())
                gt = gt.tab_style(
                    style=[
                        style.fill(color=_TEAL_BEST),
                        style.text(weight="bold", color=_TEAL),
                    ],
                    locations=loc.body(rows=best_idx, columns=col),
                )

    return gt


def create_backtest_summary_table(
    res: pd.DataFrame,
    metrics: list[str],
    fold_col: str = "fold",
    model_col: str = "Model",
    minimize_cols: list[str] | None = None,
    maximize_cols: list[str] | None = None,
    title: str = "Backtesting Results",
    source_note: str = "Twiga Forecast",
    decimals: int = 3,
) -> GT:
    """Render backtesting fold-level results as a branded Great Tables table.

    Similar to :func:`create_model_performance_table` but designed for
    fold-by-model breakdowns from :meth:`TwigaForecaster.backtesting`.

    Args:
        res: DataFrame with fold and model columns plus metric columns.
        metrics: Numeric columns to format.
        fold_col: Column identifying the CV fold.
        model_col: Column identifying the model name.
        minimize_cols: Metrics where lower is better.
        maximize_cols: Metrics where higher is better.
        title: Table title.
        source_note: Attribution shown at the bottom.
        decimals: Decimal places for numeric columns.

    Returns:
        A ``GT`` object.
    """
    subtitle = f"Performance across {res[fold_col].nunique()} folds - {res[model_col].nunique()} model(s)"
    return create_model_performance_table(
        res=res,
        metrics=metrics,
        minimize_cols=minimize_cols,
        maximize_cols=maximize_cols,
        title=title,
        subtitle=subtitle,
        source_note=source_note,
        decimals=decimals,
    )
