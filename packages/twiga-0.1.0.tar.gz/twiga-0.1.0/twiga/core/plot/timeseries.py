"""Time‑series and forecast visualisation functions.

All functions return ``ggplot`` objects styled with the official Twiga theme.
"""

from __future__ import annotations

from typing import Any, Literal

from lets_plot import (
    aes,
    facet_wrap,
    geom_line,
    geom_rect,
    geom_ribbon,
    ggplot,
    ggsize,
    labs,
    layer_tooltips,
    scale_color_manual,
    scale_fill_manual,
    scale_x_datetime,
)
import numpy as np
import pandas as pd

from ._constants import (
    ACTUAL_COLOR,
    ALPHA_HIGH,
    ALPHA_LOW,
    ALPHA_MEDIUM,
    ALPHA_OPAQUE,
    ALPHA_VERY_HIGH,
    CAPTION_DEFAULT,
    FIGURE_SIZE_DEFAULT,
    FIGURE_SIZE_LARGE,
    FORECAST_COLOR,
    FORECAST_INTERVAL_ALPHA_MAX,
    FORECAST_INTERVAL_ALPHA_MIN,
    LINE_SIZE_LARGE,
    LINE_SIZE_MEDIUM,
    LINE_SIZE_SMALL,
    LINE_SIZE_XLARGE,
    RIBBON_ALPHA_MAX,
    RIBBON_ALPHA_MIN,
    RIBBON_FILL,
)
from .theme import TWIGA_PALETTE, twiga_theme

# ----------------------------------------------------------------------
# plot_forecast
# ----------------------------------------------------------------------


def plot_forecast(
    data: pd.DataFrame,
    *,
    date_col: str | None = None,
    actual_col: str = "Actual",
    forecast_col: str = "forecast",
    lower_col: str | None = None,
    upper_col: str | None = None,
    model_name: str | None = None,
    title: str | None = None,
    subtitle: str | None = None,
    x_label: str = "Time step",
    y_label: str = "Value",
    n_samples: int | None = None,
    caption: str = CAPTION_DEFAULT,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_DEFAULT,
    # --- Visual parameters ---
    ribbon_fill: str = RIBBON_FILL,
    ribbon_alpha: float = ALPHA_LOW,
    actual_line_size: float = LINE_SIZE_MEDIUM,
    actual_alpha: float = ALPHA_HIGH,
    forecast_line_size: float = LINE_SIZE_XLARGE,
    forecast_alpha: float = ALPHA_OPAQUE,
) -> Any:
    """Visualize forecast vs actual values with an optional prediction interval.

    Produces a clean two-layer plot: a light grey *actual* line underneath a
    bold Twiga-teal *forecast* line, with an optional translucent ribbon for
    confidence / prediction intervals.

    Args:
        data: DataFrame containing the columns specified by ``actual_col``,
            ``forecast_col``, and optionally ``date_col``, ``lower_col``,
            ``upper_col``.
        date_col: Column name for the x-axis (dates or ordered labels).
            If ``None`` or not found, an integer sample index is used.
        actual_col: Column containing observed (true) values.
        forecast_col: Column containing model predictions.
        lower_col: Column for the lower bound of the prediction interval.
        upper_col: Column for the upper bound of the prediction interval.
        model_name: Model identifier shown in the auto-generated title.
        title: Override the auto-generated title.
        subtitle: Optional subtitle shown below the title.
        x_label: X-axis label.
        y_label: Y-axis label.
        n_samples: If given, only the first ``n_samples`` rows are plotted.
        caption: Plot caption (attribution / tool credit).
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size as ``(width_px, height_px)``.
        ribbon_fill: Fill colour for the prediction interval ribbon.
        ribbon_alpha: Transparency of the ribbon (0 = invisible, 1 = opaque).
        actual_line_size: Stroke width of the actual (observed) line.
        actual_alpha: Transparency of the actual line.
        forecast_line_size: Stroke width of the forecast line.
        forecast_alpha: Transparency of the forecast line.

    Returns:
        A Lets-Plot ``ggplot`` object.

    Examples:
        >>> from twiga.core.plot import plot_forecast
        >>> p = plot_forecast(results, date_col="ds", actual_col="y", forecast_col="yhat")
        >>> p
    """
    # Defensive check for core columns
    for col in [actual_col, forecast_col]:
        if col not in data.columns:
            raise ValueError(f"Required column '{col}' not found in DataFrame.")

    plot_df = data.head(n_samples).copy() if n_samples is not None else data.copy()

    # Determine X-axis column and type
    is_datetime = False
    if date_col and date_col in plot_df.columns:
        x = date_col
        if pd.api.types.is_datetime64_any_dtype(plot_df[x]):
            is_datetime = True
    else:
        plot_df["_step"] = range(len(plot_df))
        x = "_step"
        if x_label == "Time step":
            x_label = "Sample"

    # Map color names to dummy columns to ensure a legend is generated
    plot_df["_Series_Actual"] = "Actual"
    plot_df["_Series_Forecast"] = "Forecast"

    p = ggplot(plot_df)

    # 1. Prediction Interval (Ribbon)
    if lower_col in plot_df.columns and upper_col in plot_df.columns:
        p += geom_ribbon(
            aes(x=x, ymin=lower_col, ymax=upper_col),
            fill=ribbon_fill,
            alpha=ribbon_alpha,
            color="none",
            tooltips=layer_tooltips().line(f"Interval| @{{{lower_col}}} – @{{{upper_col}}}"),
        )

    # 2. Actual Line (Background)
    p += geom_line(
        aes(x=x, y=actual_col, color="_Series_Actual"),
        size=actual_line_size,
        alpha=actual_alpha,
        tooltips=layer_tooltips().line(f"Actual| @{{{actual_col}}}").disable_splitting(),
    )

    # 3. Forecast Line (Foreground)
    p += geom_line(
        aes(x=x, y=forecast_col, color="_Series_Forecast"),
        size=forecast_line_size,
        alpha=forecast_alpha,
        tooltips=layer_tooltips().line(f"Forecast| @{{{forecast_col}}}").disable_splitting(),
    )

    # Theme and Labels
    default_title = f"{model_name} - Forecast vs Actual" if model_name else "Forecast vs Actual"

    p += (
        scale_color_manual(
            name="",
            values={"Actual": ACTUAL_COLOR, "Forecast": FORECAST_COLOR},
        )
        + labs(
            title=title or default_title,
            subtitle=subtitle,
            x=x_label,
            y=y_label,
            caption=caption,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )

    if is_datetime:
        p += scale_x_datetime()

    return p


# ----------------------------------------------------------------------
# plot_timeseries
# ----------------------------------------------------------------------


def plot_timeseries(
    data: pd.DataFrame,
    y_cols: list[str] | str,
    *,
    date_col: str | None = None,
    band_col: str | None = None,
    band_labels: dict[int, str] | None = None,
    title: str = "Time Series",
    subtitle: str | None = None,
    x_label: str = "Time",
    y_label: str = "Value",
    n_samples: int | None = None,
    caption: str = CAPTION_DEFAULT,
    grid: bool = False,
    font_size: int = 10,
    show_x_axis: bool = True,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    fig_size: tuple[int, int] = (820, 280),
    # --- Visual parameters ---
    series_line_size: float = LINE_SIZE_SMALL,
    series_alpha: float = ALPHA_OPAQUE,
    band_alpha: float = ALPHA_MEDIUM,
    band_colors: dict[int, str] | None = None,
) -> Any:
    """Plot one or multiple time series from a DataFrame.

    Data is melted to long format internally; each series receives a distinct
    colour from the Twiga palette.

    Args:
        data: Source DataFrame.
        y_cols: One or more column names to plot on the y-axis.
        date_col: Column for the x-axis. Falls back to an integer index.
        band_col: Optional binary/categorical column used to shade the
            background (e.g. ``"day_night"``).  Each unique value gets a
            distinct semi-transparent ribbon.
        band_labels: Mapping from ``band_col`` value to display label,
            e.g. ``{0: "Night", 1: "Day"}``.
        title: Plot title.
        subtitle: Optional subtitle.
        x_label: X-axis label.
        y_label: Y-axis label.
        n_samples: Limit to the first N rows.
        caption: Plot caption.
        grid: If True, draw subtle horizontal reference lines.
        font_size: Base font size in points.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        fig_size: Figure size ``(width_px, height_px)``.
        series_line_size: Stroke width of the time series lines.
        series_alpha: Transparency of the time series lines.
        band_alpha: Transparency of the background shading bands.
        band_colors: Mapping from band value to fill colour.
            Defaults to ``{0: "#d4e8f7", 1: "#fff9e6"}`` for night/day.

    Returns:
        A Lets-Plot ``ggplot`` object.

    Examples:
        >>> from twiga.core.plot import plot_timeseries
        >>> p = plot_timeseries(
        ...     df, ["NetLoad(kW)"], date_col="timestamp", band_col="day_night", band_labels={0: "Night", 1: "Day"}
        ... )
        >>> p
    """
    if isinstance(y_cols, str):
        y_cols = [y_cols]

    if band_colors is None:
        band_colors = {0: "#d4e8f7", 1: "#fff9e6"}  # night=blue, day=yellow

    plot_df = data.head(n_samples).copy() if n_samples is not None else data.copy()

    if date_col and date_col in plot_df.columns:
        x = date_col
    else:
        plot_df["_step"] = range(len(plot_df))
        x = "_step"

    valid_cols = [c for c in y_cols if c in plot_df.columns]
    # Use an internal name that won't clash with any user column (pandas 2.x
    # raises ValueError when value_name matches a column being melted).
    _val_name = "_ts_value"
    keep = [x] + valid_cols
    if band_col and band_col in plot_df.columns:
        keep.append(band_col)
    long_df = plot_df[keep].melt(
        id_vars=[x] + ([band_col] if band_col and band_col in plot_df.columns else []),
        var_name="_series",
        value_name=_val_name,
    )

    n_series = len(valid_cols)
    colors = TWIGA_PALETTE[:n_series]  # uses new order (deep blue first)

    p = ggplot(long_df, aes(x=x))

    # ── Background bands (day/night shading) ───────────────────────────────
    if band_col and band_col in plot_df.columns:
        # Build run-length encoded segments for the band column
        band_series = plot_df[[x, band_col]].copy()
        band_series["_grp"] = (band_series[band_col] != band_series[band_col].shift()).cumsum()
        segments = (
            band_series.groupby("_grp")
            .agg(xmin=(x, "first"), xmax=(x, "last"), band=(band_col, "first"))
            .reset_index(drop=True)
        )
        # Compute finite y-range from data so geom_rect renders correctly.
        # Lets-Plot drops rectangles with infinite ymin/ymax silently.
        _y_vals = plot_df[valid_cols].select_dtypes("number")
        _y_min = float(_y_vals.min().min())
        _y_max = float(_y_vals.max().max())
        _y_pad = (_y_max - _y_min) * 0.05 or 1.0

        _labels = band_labels or {}
        for _, row in segments.iterrows():
            bval = row["band"]
            fill_color = band_colors.get(int(bval), "#eeeeee")
            label = _labels.get(int(bval), str(bval))
            p += geom_rect(
                xmin=row["xmin"],
                xmax=row["xmax"],
                ymin=_y_min - _y_pad,
                ymax=_y_max + _y_pad,
                fill=fill_color,
                size=0,
                alpha=band_alpha,
                tooltips=layer_tooltips().line(label),
            )

    p += (
        geom_line(
            aes(y=_val_name, color="_series"),
            size=series_line_size,
            alpha=series_alpha,
            tooltips=layer_tooltips().disable_splitting(),
        )
        + scale_color_manual(values=dict(zip(valid_cols, colors, strict=False)), name="Series")
        + labs(
            title=title,
            subtitle=subtitle,
            x=x_label,
            y=y_label,
            caption=caption,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )
    return p


# ----------------------------------------------------------------------
# plot_forecast_grid
# ----------------------------------------------------------------------


def plot_forecast_grid(
    data: pd.DataFrame,
    *,
    date_col: str | None = None,
    actual_col: str = "Actual",
    forecast_col: str = "forecast",
    model_col: str = "Model",
    n_samples_per_model: int | None = None,
    title: str = "Forecast vs Actual",
    x_label: str = "Sample",
    y_label: str = "Value",
    caption: str = CAPTION_DEFAULT,
    ncol: int = 1,
    panel_height: int = 240,
    fig_width: int = 860,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    # --- Visual parameters ---
    actual_line_size: float = LINE_SIZE_SMALL,
    actual_alpha: float = ALPHA_HIGH,
    forecast_line_size: float = LINE_SIZE_LARGE,
    forecast_alpha: float = ALPHA_OPAQUE,
) -> Any:
    """Faceted forecast grid - one panel per model.

    Equivalent to the classic multi-subplot matplotlib view but rendered as a
    single Lets-Plot ``ggplot`` with ``facet_wrap``.

    Args:
        data: DataFrame with columns for actuals, forecasts, and model names.
        date_col: Column for x-axis. Falls back to integer index.
        actual_col: Observed values column.
        forecast_col: Predicted values column.
        model_col: Column that identifies each model (used for faceting).
        n_samples_per_model: Rows shown per model panel (default: all rows).
        title: Overall plot title.
        x_label: X-axis label.
        y_label: Y-axis label.
        caption: Plot caption.
        ncol: Number of facet columns.
        panel_height: Height in pixels of each individual panel row.
        fig_width: Total figure width in pixels.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        actual_line_size: Stroke width of the actual (observed) lines.
        actual_alpha: Transparency of the actual lines.
        forecast_line_size: Stroke width of the forecast lines.
        forecast_alpha: Transparency of the forecast lines.

    Returns:
        A Lets-Plot ``ggplot`` object.
    """
    # 1. Optimized Data Slicing & Step Generation
    if n_samples_per_model:
        plot_df = data.groupby(model_col, sort=False).head(n_samples_per_model).copy()
    else:
        plot_df = data.copy()

    plot_df["_step"] = plot_df.groupby(model_col, sort=False).cumcount()

    # 2. X-axis and Datetime handling
    is_datetime = False
    if date_col and date_col in plot_df.columns:
        x_col = date_col
        if pd.api.types.is_datetime64_any_dtype(plot_df[x_col]):
            is_datetime = True
    else:
        x_col = "_step"
        if x_label == "Sample":
            x_label = "Step"

    # 3. Reshape to long-form for consistent color mapping
    _extra = [model_col, x_col]
    _actual_df = plot_df[_extra + [actual_col]].rename(columns={actual_col: "_value"}).assign(_series="Actual")
    _fcst_df = plot_df[_extra + [forecast_col]].rename(columns={forecast_col: "_value"}).assign(_series="Forecast")
    long_df = pd.concat([_actual_df, _fcst_df], ignore_index=True)

    # 4. Calculate dynamic figure height
    n_models = plot_df[model_col].nunique()
    n_rows = -(-n_models // ncol)  # Ceiling division
    fig_height = panel_height * n_rows

    # 5. Build Plot
    p = (
        ggplot(long_df, aes(x=x_col, y="_value", color="_series"))
        + geom_line(
            data=long_df[long_df["_series"] == "Actual"],
            size=actual_line_size,
            alpha=actual_alpha,
        )
        + geom_line(
            data=long_df[long_df["_series"] == "Forecast"],
            size=forecast_line_size,
            alpha=forecast_alpha,
        )
        + scale_color_manual(
            name="",
            values={"Actual": ACTUAL_COLOR, "Forecast": FORECAST_COLOR},
        )
        + facet_wrap(model_col, ncol=ncol)
        + labs(title=title, x=x_label, y=y_label, caption=caption)
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(fig_width, fig_height)
    )

    if is_datetime:
        p += scale_x_datetime()

    return p


# ----------------------------------------------------------------------
# plot_quantile_fan
# ----------------------------------------------------------------------


def plot_quantile_fan(
    data: pd.DataFrame,
    *,
    date_col: str | None = None,
    actual_col: str = "Actual",
    median_col: str = "q50",
    quantile_pairs: list[tuple[str, str]] | None = None,
    title: str = "Probabilistic Forecast - Fan Chart",
    subtitle: str | None = None,
    x_label: str = "Time step",
    y_label: str = "Value",
    n_samples: int | None = None,
    caption: str = CAPTION_DEFAULT,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_LARGE,
    # --- Visual parameters ---
    ribbon_fill: str = RIBBON_FILL,
    min_ribbon_alpha: float = RIBBON_ALPHA_MIN,
    max_ribbon_alpha: float = RIBBON_ALPHA_MAX,
    actual_line_size: float = LINE_SIZE_MEDIUM,
    actual_alpha: float = ALPHA_HIGH,
    median_line_size: float = LINE_SIZE_XLARGE,
    median_alpha: float = ALPHA_OPAQUE,
) -> Any:
    """Fan chart for multi-quantile probabilistic forecasts.

    Renders graduated ribbon bands from widest (lightest) to narrowest
    (most opaque), with the median line on top and actual observations in
    light grey underneath.  Widely used in meteorological and energy
    forecasting literature to communicate forecast uncertainty.

    Args:
        data: DataFrame with quantile and actual columns.
        date_col: Column for the x-axis. Falls back to integer index.
        actual_col: Column of observed values.
        median_col: Column of median (q50) forecasts.
        quantile_pairs: List of ``(lower_col, upper_col)`` column pairs,
            ordered from **widest** to **narrowest** interval.  Auto-detected
            from ``qXX`` columns if ``None``.
        title: Plot title.
        subtitle: Optional subtitle (auto-generated if ``None``).
        x_label: X-axis label.
        y_label: Y-axis label.
        n_samples: Limit to the first N rows.
        caption: Plot caption.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        ribbon_fill: Fill colour for the quantile ribbons. Defaults to ``TWIGA_PALETTE[3]`` (emerald).
        min_ribbon_alpha: Transparency of the widest (outermost) ribbon.
        max_ribbon_alpha: Transparency of the narrowest (innermost) ribbon.
        actual_line_size: Stroke width of the actual (observed) line.
        actual_alpha: Transparency of the actual line.
        median_line_size: Stroke width of the median forecast line.
        median_alpha: Transparency of the median line.

    Returns:
        A Lets-Plot ``ggplot`` object.

    Examples:
        >>> from twiga.core.plot import plot_quantile_fan
        >>> p = plot_quantile_fan(
        ...     results,
        ...     median_col="q50",
        ...     quantile_pairs=[("q10", "q90"), ("q25", "q75")],
        ... )
        >>> p
    """
    import re

    plot_df = data.head(n_samples).copy() if n_samples is not None else data.copy()

    if date_col and date_col in plot_df.columns:
        x = date_col
    else:
        plot_df["_step"] = range(len(plot_df))
        x = "_step"
        if x_label == "Time step":
            x_label = "Sample"

    if quantile_pairs is None:
        q_cols = [c for c in plot_df.columns if re.match(r"^q\d+$", c)]
        q_levels = sorted({int(c[1:]) for c in q_cols})
        quantile_pairs = []
        for lvl in q_levels:
            complement = 100 - lvl
            if lvl < complement and f"q{lvl}" in plot_df.columns and f"q{complement}" in plot_df.columns:
                quantile_pairs.append((f"q{lvl}", f"q{complement}"))
        quantile_pairs = sorted(
            quantile_pairs,
            key=lambda t: int(t[1][1:]) - int(t[0][1:]),
            reverse=True,
        )

    n_bands = len(quantile_pairs)
    alphas = np.linspace(min_ribbon_alpha, max_ribbon_alpha, n_bands) if n_bands > 0 else []

    p = ggplot(plot_df)

    for (lower_col, upper_col), alpha_val in zip(quantile_pairs, alphas, strict=False):
        if lower_col in plot_df.columns and upper_col in plot_df.columns:
            p += geom_ribbon(
                aes(x=x, ymin=lower_col, ymax=upper_col),
                fill=ribbon_fill,
                alpha=float(alpha_val),
                color="none",
            )

    if actual_col in plot_df.columns:
        p += geom_line(
            aes(x=x, y=actual_col),
            color=ACTUAL_COLOR,
            size=actual_line_size,
            alpha=actual_alpha,
        )

    if median_col in plot_df.columns:
        p += geom_line(
            aes(x=x, y=median_col),
            color=FORECAST_COLOR,
            size=median_line_size,
            alpha=median_alpha,
        )

    interval_str = (
        "Intervals: " + ", ".join(f"{int(t[1][1:]) - int(t[0][1:])}%" for t in quantile_pairs) if quantile_pairs else ""
    )
    p += (
        labs(
            title=title,
            subtitle=subtitle or interval_str or None,
            x=x_label,
            y=y_label,
            caption=caption,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )
    return p


# ----------------------------------------------------------------------
# plot_forecast_intervals
# ----------------------------------------------------------------------


def plot_forecast_intervals(
    data: pd.DataFrame,
    interval_specs: list[dict[str, str]],
    *,
    date_col: str | None = None,
    actual_col: str = "Actual",
    title: str = "Forecast Interval Comparison",
    subtitle: str | None = None,
    x_label: str = "Time step",
    y_label: str = "Value",
    n_samples: int | None = None,
    caption: str = CAPTION_DEFAULT,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_LARGE,
    # --- Visual parameters ---
    min_ribbon_alpha: float = FORECAST_INTERVAL_ALPHA_MIN,
    max_ribbon_alpha: float = FORECAST_INTERVAL_ALPHA_MAX,
    actual_line_size: float = LINE_SIZE_MEDIUM,
    actual_alpha: float = ALPHA_VERY_HIGH,
    center_line_size: float = LINE_SIZE_LARGE,
    center_alpha: float = ALPHA_OPAQUE,
) -> Any:
    """Overlay multiple models' prediction intervals for direct comparison.

    Renders each model as a semi-transparent ribbon + centre line, making
    sharpness and coverage differences across methods immediately visible
    (e.g. CQR vs CRC vs parametric Normal).

    Args:
        data: DataFrame with actual values and all interval columns.
        interval_specs: List of dicts, one per method. Each dict must have:
            - ``"model"``  - display name
            - ``"lower"``  - lower bound column name
            - ``"upper"``  - upper bound column name
            - ``"center"`` - centre / median column (optional)
        date_col: Column for the x-axis. If None, integer steps are used.
        actual_col: Column of observed values.
        title: Plot title.
        subtitle: Optional subtitle (auto-generated from model names if None).
        x_label: X-axis label.
        y_label: Y-axis label.
        n_samples: Limit to the first N rows.
        caption: Plot caption.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        min_ribbon_alpha: Transparency of the first method's ribbon.
        max_ribbon_alpha: Transparency of the last method's ribbon.
        actual_line_size: Stroke width of the actual (observed) line.
        actual_alpha: Transparency of the actual line.
        center_line_size: Stroke width of the centre/median lines.
        center_alpha: Transparency of the centre lines.

    Returns:
        A Lets-Plot ``ggplot`` object.

    Examples:
        >>> specs = [
        ...     {"model": "CQR", "lower": "lo_c", "upper": "hi_c", "center": "q50_c"},
        ...     {"model": "Norm", "lower": "lo_n", "upper": "hi_n", "center": "mu_n"},
        ... ]
        >>> p = plot_forecast_intervals(df, specs, date_col="ds")
    """
    # Defensive slicing
    plot_df = data.head(n_samples).copy() if n_samples is not None else data.copy()

    # 1. X-axis and Datetime Handling
    is_datetime = False
    if date_col and date_col in plot_df.columns:
        x_col = date_col
        if pd.api.types.is_datetime64_any_dtype(plot_df[x_col]):
            is_datetime = True
    else:
        plot_df["_step"] = range(len(plot_df))
        x_col = "_step"
        if x_label == "Time step":
            x_label = "Sample"

    # 2. Setup Legend Mapping
    n_methods = len(interval_specs)
    ribbon_alphas = np.linspace(min_ribbon_alpha, max_ribbon_alpha, max(n_methods, 1))
    model_colors = {}

    p = ggplot(plot_df)

    # 3. Layer: Actual Line (Background)
    if actual_col in plot_df.columns:
        p += geom_line(
            aes(x=x_col, y=actual_col),
            color=ACTUAL_COLOR,
            size=actual_line_size,
            alpha=actual_alpha,
        )

    # 4. Layers: Models (Ribbons then Lines)
    for i, spec in enumerate(interval_specs):
        model_name = spec.get("model", f"Method {i + 1}")
        color = TWIGA_PALETTE[i % len(TWIGA_PALETTE)]
        model_colors[model_name] = color

        lower, upper = spec.get("lower"), spec.get("upper")
        center = spec.get("center")

        # Create unique label column to force legend creation
        lbl_col = f"_lbl_{i}"
        plot_df[lbl_col] = model_name

        if lower and upper and lower in plot_df.columns and upper in plot_df.columns:
            p += geom_ribbon(
                aes(x=x_col, ymin=lower, ymax=upper, fill=lbl_col),
                alpha=float(ribbon_alphas[i]),
                color="none",
            )

        if center and center in plot_df.columns:
            p += geom_line(
                aes(x=x_col, y=center, color=lbl_col),
                size=center_line_size,
                alpha=center_alpha,
            )

    # 5. Final Assembly
    auto_sub = "  ·  ".join(s.get("model", f"M{i + 1}") for i, s in enumerate(interval_specs))

    p += (
        scale_color_manual(name="Model", values=model_colors)
        + scale_fill_manual(name="Model", values=model_colors)
        + labs(
            title=title,
            subtitle=subtitle or auto_sub,
            x=x_label,
            y=y_label,
            caption=caption,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )

    if is_datetime:
        p += scale_x_datetime()

    return p
