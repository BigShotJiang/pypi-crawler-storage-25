"""Twiga visualisation toolkit - flat public API.

All plotting functions are re-exported here so callers can do::

    from twiga.core.plot import plot_forecast, twiga_theme

Functions return Lets-Plot ``ggplot`` objects unless stated otherwise.

Usage example:
    >>> from twiga.core.plot import plot_forecast, twiga_theme
    >>> p = plot_forecast(data, actual_col="y", forecast_col="yhat")
    >>> p
"""

# Distribution plots
from .distribution import (
    plot_cdf,
    plot_density,
    plot_distribution,
    plot_kde,
)

# Data exploration plots
from .exploration import (
    correlation_heatmap,
    line_plot,
    scatter_matrix,
    scatter_plot,
)
from .residuals import (
    normal_q_qplot,
    residual_leverage_plot,
    residual_plot,
    squared_residual_plot,
)

# Statistical & evaluation plots
from .stats import (
    plot_acf,
    plot_metrics_bar,
    plot_pit_histogram,
    plot_reliability_diagram,
)
from .theme import TWIGA_PALETTE, twiga_theme

# Time series & forecast plots
from .timeseries import (
    plot_forecast,
    plot_forecast_grid,
    plot_forecast_intervals,
    plot_quantile_fan,
    plot_timeseries,
)

__all__ = [
    # Theme
    "TWIGA_PALETTE",
    "twiga_theme",
    # Timeseries
    "plot_forecast",
    "plot_forecast_grid",
    "plot_forecast_intervals",
    "plot_quantile_fan",
    "plot_timeseries",
    # Exploration
    "correlation_heatmap",
    "line_plot",
    "scatter_matrix",
    "scatter_plot",
    # Distribution
    "plot_cdf",
    "plot_density",
    "plot_distribution",
    "plot_kde",
    # Stats
    "plot_acf",
    "plot_metrics_bar",
    "plot_pit_histogram",
    "plot_reliability_diagram",
    "residual_plot",
    "normal_q_qplot",
    "squared_residual_plot",
    "residual_leverage_plot",
]
