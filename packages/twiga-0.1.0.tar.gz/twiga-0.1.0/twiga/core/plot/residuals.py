"""Diagnostic residual plots for Twiga Forecast models.

All four standard regression diagnostics - Tukey-Anscombe, Normal Q-Q,
Scale-Location, and Residuals vs Leverage - are implemented using Lets-Plot
and the official Twiga theme.
"""

from __future__ import annotations

from typing import Any, Literal

from lets_plot import (
    aes,
    geom_hline,
    geom_line,
    geom_point,
    geom_qq,
    geom_qq_line,
    geom_smooth,
    ggplot,
    ggsize,
    labs,
    scale_color_manual,
)
import numpy as np
import pandas as pd

from ._constants import (
    ALPHA_HIGH,
    CAPTION_DEFAULT,
    FIGURE_SIZE_SMALL,
    FORECAST_COLOR,
    LINE_SIZE_LARGE,
    LINE_SIZE_MEDIUM,
    LINE_SIZE_SMALL,
    POINT_SIZE_MEDIUM,
    POINT_SIZE_SMALL,
    REFERENCE_LINE_COLOR,
    SMOOTH_COLOR,
)
from .theme import TWIGA_PALETTE, twiga_theme

# ----------------------------------------------------------------------
# residual_plot (Tukey-Anscombe)
# ----------------------------------------------------------------------


def residual_plot(
    data: pd.DataFrame,
    x_col: str = "fitted",
    y_col: str = "residuals",
    color_col: str = "split",
    title: str = "Tukey-Anscombe Plot",
    subtitle: str = "Residuals vs Fitted - check linearity & homoscedasticity",
    x_label: str = "Fitted",
    y_label: str = "Residuals",
    caption: str = CAPTION_DEFAULT,
    font_size: int = 10,
    show_x_axis: bool = True,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_SMALL,
    # --- Visual parameters ---
    point_size: float = POINT_SIZE_SMALL,
    point_alpha: float = ALPHA_HIGH,
    zero_line_color: str = REFERENCE_LINE_COLOR,
    zero_line_type: str = "dashed",
    zero_line_size: float = LINE_SIZE_MEDIUM,
    smooth_method: Literal["lm", "loess"] = "loess",
    smooth_line_size: float = LINE_SIZE_LARGE,
    smooth_color: str = FORECAST_COLOR,
    smooth_se: bool = False,
) -> Any:
    """Tukey-Anscombe plot: residuals vs fitted values.

    Scatter of residuals against fitted values overlaid with a LOESS smooth
    and a horizontal zero line.  Use this plot to detect non-linearity and
    heteroscedasticity.

    Args:
        data: DataFrame with columns for fitted values and residuals.
        x_col: Column of fitted values (x-axis).
        y_col: Column of residual values (y-axis).
        color_col: Column used to colour points by cross-validation split.
        title: Plot title.
        subtitle: Plot subtitle.
        x_label: X-axis label.
        y_label: Y-axis label.
        caption: Plot caption.
        font_size: Base font size.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor.
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        point_size: Size of scatter points.
        point_alpha: Transparency of points.
        zero_line_color: Colour of the horizontal zero line.
        zero_line_type: Linetype of the zero line.
        zero_line_size: Stroke width of the zero line.
        smooth_method: Smoothing method ("lm" or "loess").
        smooth_line_size: Stroke width of the smooth line.
        smooth_color: Colour of the smooth line.
        smooth_se: Whether to show confidence band around smooth.

    Returns:
        A Lets-Plot ``ggplot`` object.
    """
    return (
        ggplot(data, aes(x_col, y_col, color=color_col))
        + geom_point(alpha=point_alpha, size=point_size)
        + geom_hline(
            yintercept=0,
            linetype=zero_line_type,
            color=zero_line_color,
            size=zero_line_size,
        )
        + geom_smooth(
            method=smooth_method,
            se=smooth_se,
            color=smooth_color,
            size=smooth_line_size,
        )
        + scale_color_manual(values=TWIGA_PALETTE)
        + labs(
            title=title,
            subtitle=subtitle,
            x=x_label,
            y=y_label,
            caption=caption,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )


# ----------------------------------------------------------------------
# normal_q_qplot
# ----------------------------------------------------------------------


def normal_q_qplot(
    data: pd.DataFrame,
    sample_col: str = "residual",
    color_col: str = "split",
    title: str = "Normal Q-Q Plot",
    subtitle: str = "Standardised residuals vs theoretical normal quantiles",
    x_label: str = "Theoretical Quantiles",
    y_label: str = "Standardised Residuals",
    caption: str = CAPTION_DEFAULT,
    font_size: int = 10,
    show_x_axis: bool = True,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_SMALL,
    # --- Visual parameters ---
    point_size: float = POINT_SIZE_SMALL,
    point_alpha: float = ALPHA_HIGH,
    qq_line_color: str = REFERENCE_LINE_COLOR,
    qq_line_type: str = "dashed",
    qq_line_size: float = LINE_SIZE_MEDIUM,
) -> Any:
    """Normal Q-Q plot for standardised residuals.

    Points should fall on the red reference line if residuals are normally
    distributed.  Systematic departures indicate heavy tails or skewness.

    Args:
        data: DataFrame with a column of standardised residuals.
        sample_col: Column of sample values to check against the normal.
        color_col: Column used to colour points by split.
        title: Plot title.
        subtitle: Plot subtitle.
        x_label: X-axis label.
        y_label: Y-axis label.
        caption: Plot caption.
        font_size: Base font size.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor.
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        point_size: Size of Q-Q points.
        point_alpha: Transparency of points.
        qq_line_color: Colour of the reference diagonal line.
        qq_line_type: Linetype of the reference line.
        qq_line_size: Stroke width of the reference line.

    Returns:
        A Lets-Plot ``ggplot`` object.
    """
    return (
        ggplot(data, aes(sample=sample_col, color=color_col))
        + geom_qq(alpha=point_alpha, size=point_size)
        + geom_qq_line(
            color=qq_line_color,
            linetype=qq_line_type,
            size=qq_line_size,
        )
        + scale_color_manual(values=TWIGA_PALETTE)
        + labs(
            title=title,
            subtitle=subtitle,
            x=x_label,
            y=y_label,
            caption=caption,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )


# ----------------------------------------------------------------------
# squared_residual_plot (Scale-Location)
# ----------------------------------------------------------------------


def squared_residual_plot(
    data: pd.DataFrame,
    x_col: str = "fitted",
    y_col: str = "sqrt_abs_std_res",
    color_col: str = "split",
    title: str = "Scale-Location Plot",
    subtitle: str = "Check for homoscedasticity - expect a flat LOESS band",
    x_label: str = "Fitted",
    y_label: str = "√|Std. Residuals|",
    caption: str = CAPTION_DEFAULT,
    font_size: int = 10,
    show_x_axis: bool = True,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_SMALL,
    # --- Visual parameters ---
    point_size: float = POINT_SIZE_SMALL,
    point_alpha: float = ALPHA_HIGH,
    smooth_method: Literal["lm", "loess"] = "loess",
    smooth_line_size: float = LINE_SIZE_LARGE,
    smooth_color: str = FORECAST_COLOR,
    smooth_se: bool = False,
) -> Any:
    """Scale-Location plot: √|standardised residuals| vs fitted.

    A roughly horizontal LOESS band indicates constant variance
    (homoscedasticity).  A rising or falling band suggests heteroscedasticity.

    Args:
        data: DataFrame with fitted values and pre-computed √|std. residuals|.
        x_col: Column of fitted values.
        y_col: Column of √|standardised residuals|.
        color_col: Column used to colour points by split.
        title: Plot title.
        subtitle: Plot subtitle.
        x_label: X-axis label.
        y_label: Y-axis label.
        caption: Plot caption.
        font_size: Base font size.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor.
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        point_size: Size of scatter points.
        point_alpha: Transparency of points.
        smooth_method: Smoothing method ("lm" or "loess").
        smooth_line_size: Stroke width of the smooth line.
        smooth_color: Colour of the smooth line.
        smooth_se: Whether to show confidence band.

    Returns:
        A Lets-Plot ``ggplot`` object.
    """
    return (
        ggplot(data, aes(x_col, y_col, color=color_col))
        + geom_point(alpha=point_alpha, size=point_size)
        + geom_smooth(
            method=smooth_method,
            se=smooth_se,
            color=smooth_color,
            size=smooth_line_size,
        )
        + scale_color_manual(values=TWIGA_PALETTE)
        + labs(
            title=title,
            subtitle=subtitle,
            x=x_label,
            y=y_label,
            caption=caption,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )


# ----------------------------------------------------------------------
# residual_leverage_plot
# ----------------------------------------------------------------------


def residual_leverage_plot(
    data: pd.DataFrame,
    x_col: str = "leverage",
    y_col: str = "std_res",
    color_col: str = "split",
    featuresize: int | None = None,
    title: str = "Residuals vs Leverage",
    subtitle: str = "Dashed lines: Cook's distance 0.5 (amber) and 1.0 (vermilion)",
    x_label: str = "Leverage",
    y_label: str = "Std. Residuals",
    caption: str = CAPTION_DEFAULT,
    font_size: int = 10,
    show_x_axis: bool = True,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_SMALL,
    # --- Visual parameters ---
    point_size: float = POINT_SIZE_SMALL,
    point_alpha: float = ALPHA_HIGH,
    smooth_method: Literal["lm", "loess"] = "loess",
    smooth_line_size: float = LINE_SIZE_LARGE,
    smooth_color: str = FORECAST_COLOR,
    smooth_se: bool = False,
    cook_05_color: str = TWIGA_PALETTE[1],  # amber
    cook_05_linetype: str = "dashed",
    cook_05_line_size: float = LINE_SIZE_SMALL,
    cook_10_color: str = TWIGA_PALETTE[2],  # vermilion
    cook_10_linetype: str = "dashed",
    cook_10_line_size: float = LINE_SIZE_SMALL,
) -> Any:
    """Residuals vs leverage plot with Cook's distance contours.

    Points outside the dashed Cook's distance contours (0.5 and 1.0) are
    potentially influential observations worth investigating.

    Args:
        data: DataFrame with leverage and standardised residuals columns.
        x_col: Column of leverage values.
        y_col: Column of standardised residuals.
        color_col: Column used to colour points by split.
        featuresize: Number of predictors *p* in the model (defaults to 1).
        title: Plot title.
        subtitle: Plot subtitle.
        x_label: X-axis label.
        y_label: Y-axis label.
        caption: Plot caption.
        font_size: Base font size.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor.
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        point_size: Size of scatter points.
        point_alpha: Transparency of points.
        smooth_method: Smoothing method for the LOESS trend.
        smooth_line_size: Stroke width of the smooth line.
        smooth_color: Colour of the smooth line.
        smooth_se: Whether to show confidence band.
        cook_05_color: Colour of the Cook's distance = 0.5 contour.
        cook_05_linetype: Linetype of the 0.5 contour.
        cook_05_line_size: Stroke width of the 0.5 contour.
        cook_10_color: Colour of the Cook's distance = 1.0 contour.
        cook_10_linetype: Linetype of the 1.0 contour.
        cook_10_line_size: Stroke width of the 1.0 contour.

    Returns:
        A Lets-Plot ``ggplot`` object.
    """
    p = featuresize or 1
    x_range = np.linspace(1e-4, float(data[x_col].max()) * 1.1, 120)
    cook_05 = np.sqrt(0.5 * (p + 1) * (1 - x_range) / x_range)
    cook_10 = np.sqrt(1.0 * (p + 1) * (1 - x_range) / x_range)

    return (
        ggplot(data, aes(x_col, y_col, color=color_col))
        + geom_point(alpha=point_alpha, size=point_size)
        + geom_smooth(
            method=smooth_method,
            se=smooth_se,
            color=smooth_color,
            size=smooth_line_size,
        )
        # Cook's distance = 0.5 contour
        + geom_line(
            aes(x=x_range, y=cook_05),
            color=cook_05_color,
            linetype=cook_05_linetype,
            size=cook_05_line_size,
        )
        + geom_line(
            aes(x=x_range, y=-cook_05),
            color=cook_05_color,
            linetype=cook_05_linetype,
            size=cook_05_line_size,
        )
        # Cook's distance = 1.0 contour
        + geom_line(
            aes(x=x_range, y=cook_10),
            color=cook_10_color,
            linetype=cook_10_linetype,
            size=cook_10_line_size,
        )
        + geom_line(
            aes(x=x_range, y=-cook_10),
            color=cook_10_color,
            linetype=cook_10_linetype,
            size=cook_10_line_size,
        )
        + scale_color_manual(values=TWIGA_PALETTE)
        + labs(
            title=title,
            subtitle=subtitle,
            x=x_label,
            y=y_label,
            caption=caption,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )
