"""Statistical and evaluation plots: ACF, metrics bar, reliability, PIT.

All functions return ``ggplot`` objects styled with the official Twiga theme.
"""

from __future__ import annotations

from typing import Any, Literal

from lets_plot import (
    aes,
    geom_bar,
    geom_hline,
    geom_line,
    geom_point,
    geom_segment,
    ggplot,
    ggsize,
    labs,
    layer_tooltips,
    scale_color_manual,
    scale_fill_manual,
    scale_x_continuous,
    scale_y_continuous,
)
import numpy as np
import pandas as pd

from ._constants import (
    ACTUAL_COLOR,
    ALPHA_HIGH,
    ALPHA_OPAQUE,
    ALPHA_VERY_HIGH,
    BAR_WIDTH_DEFAULT,
    CAPTION_DEFAULT,
    FIGURE_SIZE_MEDIUM,
    FIGURE_SIZE_SMALL,
    FORECAST_COLOR,
    LINE_SIZE_LARGE,
    LINE_SIZE_MEDIUM,
    LINE_SIZE_SMALL,
    LINE_SIZE_TINY,
    POINT_SIZE_LARGE,
    POINT_SIZE_MEDIUM,
    REFERENCE_LINE_COLOR,
    SEGMENT_WIDTH_DEFAULT,
)
from .theme import TWIGA_PALETTE, twiga_theme

# ----------------------------------------------------------------------
# plot_acf
# ----------------------------------------------------------------------


def plot_acf(
    series: pd.Series | np.ndarray,
    *,
    max_lag: int = 40,
    partial: bool = False,
    alpha: float = 0.05,
    title: str | None = None,
    x_label: str = "Lag",
    caption: str = CAPTION_DEFAULT,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_MEDIUM,
    # --- Visual parameters ---
    bar_width: float = SEGMENT_WIDTH_DEFAULT,
    point_size: float = POINT_SIZE_MEDIUM,
    ci_line_type: str = "dashed",
    ci_line_color: str = REFERENCE_LINE_COLOR,
    ci_line_size: float = LINE_SIZE_SMALL,
    zero_line_color: str = "#444444",
    zero_line_size: float = LINE_SIZE_TINY,
) -> Any:
    """Autocorrelation (ACF) or partial autocorrelation (PACF) bar chart.

    Computes the ACF/PACF via ``statsmodels`` and renders vertical bars with
    a 95 % confidence band (±1.96 / √n, dashed lines).

    Args:
        series: 1-D time series (array or pandas Series).
        max_lag: Maximum lag to display.
        partial: If ``True``, compute PACF instead of ACF.
        alpha: Significance level for the confidence interval. Default 0.05
            gives ±1.96 / √n bands.
        title: Plot title. Auto-generated from ``partial`` if ``None``.
        x_label: X-axis label.
        caption: Plot caption.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        bar_width: Width of the vertical bars (passed as ``size`` to ``geom_segment``).
        point_size: Size of the points drawn at the top of each bar.
        ci_line_type: Linetype for the confidence interval bands (e.g. "dashed", "solid").
        ci_line_color: Colour of the CI lines. Defaults to ``TWIGA_PALETTE[2]`` (vermilion).
        ci_line_size: Stroke width of the CI lines.
        zero_line_color: Colour of the horizontal line at zero.
        zero_line_size: Stroke width of the zero line.

    Returns:
        A Lets-Plot ``ggplot`` object.

    Examples:
        >>> from twiga.core.plot import plot_acf
        >>> p = plot_acf(df["load"], max_lag=48, title="Load ACF")
        >>> p
    """
    from statsmodels.tsa.stattools import acf, pacf

    arr = np.asarray(series).ravel()
    n = len(arr)
    ci = 1.96 / np.sqrt(n)

    vals = pacf(arr, nlags=max_lag, method="ywm") if partial else acf(arr, nlags=max_lag, fft=True)

    lags = np.arange(len(vals))
    df_acf = pd.DataFrame({"lag": lags, "acf": vals})
    df_acf["color"] = np.where(np.abs(df_acf["acf"]) > ci, FORECAST_COLOR, ACTUAL_COLOR)

    auto_title = "Partial Autocorrelation (PACF)" if partial else "Autocorrelation (ACF)"

    p = (
        ggplot(df_acf, aes(x="lag", y="acf"))
        + geom_segment(
            aes(x="lag", xend="lag", yend="acf", color="color"),
            y=0,
            size=bar_width,
            tooltips=layer_tooltips().disable_splitting(),
        )
        + geom_point(aes(color="color"), size=point_size)
        + geom_hline(yintercept=0, color=zero_line_color, size=zero_line_size)
        + geom_hline(yintercept=ci, linetype=ci_line_type, color=ci_line_color, size=ci_line_size)
        + geom_hline(yintercept=-ci, linetype=ci_line_type, color=ci_line_color, size=ci_line_size)
        + scale_color_manual(
            values={FORECAST_COLOR: FORECAST_COLOR, ACTUAL_COLOR: ACTUAL_COLOR},
            guide="none",
        )
        + labs(
            title=title or auto_title,
            subtitle=f"95 % confidence band: ±{ci:.3f}  (n = {n:,})",
            x=x_label,
            y="ACF" if not partial else "PACF",
            caption=caption,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )
    return p


# ----------------------------------------------------------------------
# plot_metrics_bar
# ----------------------------------------------------------------------


def plot_metrics_bar(
    data: pd.DataFrame,
    metric_col: str,
    *,
    model_col: str = "Model",
    lower_is_better: bool = True,
    title: str | None = None,
    x_label: str | None = None,
    caption: str = CAPTION_DEFAULT,
    horizontal: bool = True,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = (520, 340),
    # --- Visual parameters ---
    bar_width: float = BAR_WIDTH_DEFAULT,
    best_bar_color: str = FORECAST_COLOR,
    other_bar_color: str = "#cfd8dc",
) -> Any:
    """Bar chart comparing a single metric across models.

    The best model (lowest or highest value depending on ``lower_is_better``)
    is highlighted in Twiga deep teal; all others use a muted grey.

    Args:
        data: DataFrame with a model-name column and a numeric metric column.
        metric_col: Column of numeric metric values to plot.
        model_col: Column identifying each model.
        lower_is_better: If ``True`` the minimum bar is highlighted in teal.
        title: Plot title.
        x_label: Axis label for the metric axis.
        caption: Plot caption.
        horizontal: If ``True`` (default) renders a horizontal bar chart
            (models on y, metric on x).
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        bar_width: Width of the bars (0–1, where 1 fills the whole bin).
        best_bar_color: Colour for the best model bar. Defaults to deep blue.
        other_bar_color: Colour for the non‑best bars.

    Returns:
        A Lets-Plot ``ggplot`` object.

    Examples:
        >>> from twiga.core.plot import plot_metrics_bar
        >>> p = plot_metrics_bar(results, metric_col="MAE", title="MAE by Model", lower_is_better=True)
        >>> p
    """
    df = data[[model_col, metric_col]].dropna().copy()
    best_val = df[metric_col].min() if lower_is_better else df[metric_col].max()
    df["_highlight"] = df[metric_col] == best_val

    # Sort by metric so bars are ordered best → worst
    df = df.sort_values(metric_col, ascending=not lower_is_better).reset_index(drop=True)

    if horizontal:
        p = (
            ggplot(df, aes(x=metric_col, y=model_col, fill="_highlight"))
            + geom_bar(stat="identity", width=bar_width, show_legend=False)
            + scale_fill_manual(values={True: best_bar_color, False: other_bar_color})
            + labs(
                title=title or f"{metric_col} by Model",
                x=x_label or metric_col,
                y="",
                caption=caption,
            )
            + twiga_theme(
                show_x_axis=show_x_axis,
                font_size=font_size,
                line_width=line_width,
                x_axis_angle=x_axis_angle,
                legend_pos=legend_pos,
                grid=grid,
            )
            + ggsize(*fig_size)
        )
    else:
        p = (
            ggplot(df, aes(x=model_col, y=metric_col, fill="_highlight"))
            + geom_bar(stat="identity", width=bar_width, show_legend=False)
            + scale_fill_manual(values={True: best_bar_color, False: other_bar_color})
            + labs(
                title=title or f"{metric_col} by Model",
                x="",
                y=x_label or metric_col,
                caption=caption,
            )
            + twiga_theme(
                show_x_axis=show_x_axis,
                font_size=font_size,
                line_width=line_width,
                x_axis_angle=x_axis_angle,
                legend_pos=legend_pos,
                grid=grid,
            )
            + ggsize(*fig_size)
        )
    return p


# ----------------------------------------------------------------------
# plot_reliability_diagram
# ----------------------------------------------------------------------


def plot_reliability_diagram(
    nominal: np.ndarray | list[float],
    empirical: np.ndarray | list[float],
    *,
    group_col: str | None = None,
    groups: list[str] | None = None,
    title: str = "Reliability Diagram",
    subtitle: str = "Empirical vs nominal coverage - perfect calibration on the diagonal",
    caption: str = CAPTION_DEFAULT,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = (440, 400),
    # --- Visual parameters ---
    line_size: float = LINE_SIZE_LARGE,
    line_alpha: float = ALPHA_OPAQUE,
    point_size: float = POINT_SIZE_LARGE,
    point_alpha: float = ALPHA_VERY_HIGH,
    diagonal_line_color: str = "#cccccc",
    diagonal_line_type: str = "dashed",
    diagonal_line_size: float = LINE_SIZE_LARGE,
) -> Any:
    """Coverage reliability diagram for probabilistic forecasts.

    Plots empirical coverage against nominal coverage levels.  Points
    lying on the diagonal indicate perfect calibration; points above
    indicate conservative intervals (over-coverage); points below indicate
    anti-conservative intervals (under-coverage).

    Args:
        nominal: Nominal coverage levels (x-axis), e.g. ``[0.5, 0.6, ..., 0.95]``.
        empirical: Empirical (observed) coverage at each level (y-axis).
            For multiple methods, pass a 2-D array of shape
            ``(n_levels, n_methods)`` and provide ``groups``.
        group_col: Name to use for the group/method column when building
            the long-form DataFrame.
        groups: Method names when ``empirical`` is 2-D.
        title: Plot title.
        subtitle: Plot subtitle.
        caption: Plot caption.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        line_size: Stroke width of the main lines (empirical coverage).
        line_alpha: Transparency of the main lines.
        point_size: Size of the markers at each coverage level.
        point_alpha: Transparency of the markers.
        diagonal_line_color: Colour of the perfect‑calibration diagonal.
        diagonal_line_type: Linetype of the diagonal (e.g. "dashed", "solid").
        diagonal_line_size: Stroke width of the diagonal.

    Returns:
        A Lets-Plot ``ggplot`` object.

    Examples:
        >>> from twiga.core.plot import plot_reliability_diagram
        >>> p = plot_reliability_diagram(
        ...     nominal=np.linspace(0.1, 0.95, 18),
        ...     empirical=np.array([[cqr_cov], [crc_cov]]).T,
        ...     groups=["CQR", "CRC"],
        ... )
        >>> p
    """
    nom = np.asarray(nominal).ravel()
    emp = np.asarray(empirical)

    if emp.ndim == 1:
        df = pd.DataFrame({"nominal": nom, "empirical": emp.ravel()})
        color_col = None
    else:
        if emp.shape[0] != len(nom):
            emp = emp.T
        n_methods = emp.shape[1]
        method_names = groups or [f"Method {i + 1}" for i in range(n_methods)]
        frames = [
            pd.DataFrame({"nominal": nom, "empirical": emp[:, i], group_col or "method": method_names[i]})
            for i in range(n_methods)
        ]
        df = pd.concat(frames, ignore_index=True)
        color_col = group_col or "method"

    aes_kw: dict[str, str] = {"x": "nominal", "y": "empirical"}
    if color_col:
        aes_kw["color"] = color_col

    n_colors = df[color_col].nunique() if color_col else 1

    p = (
        ggplot(df, aes(**aes_kw))
        # Perfect-calibration diagonal
        + geom_line(
            aes(x="nominal", y="nominal"),
            data=pd.DataFrame({"nominal": [0.0, 1.0]}),
            color=diagonal_line_color,
            linetype=diagonal_line_type,
            size=diagonal_line_size,
        )
        + geom_line(size=line_size, alpha=line_alpha)
        + geom_point(size=point_size, alpha=point_alpha)
        + scale_color_manual(values=TWIGA_PALETTE[:n_colors])
        + scale_x_continuous(limits=[0.0, 1.0])
        + scale_y_continuous(limits=[0.0, 1.0])
        + labs(
            title=title,
            subtitle=subtitle,
            x="Nominal Coverage",
            y="Empirical Coverage",
            caption=caption,
            color="Method",
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )
    return p


# ----------------------------------------------------------------------
# plot_pit_histogram
# ----------------------------------------------------------------------


def plot_pit_histogram(
    pit_values: np.ndarray | pd.Series,
    *,
    n_bins: int = 20,
    title: str = "PIT Histogram",
    subtitle: str = "Uniform distribution indicates a well-calibrated forecast",
    caption: str = CAPTION_DEFAULT,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_SMALL,
    # --- Visual parameters ---
    bar_fill_color: str = FORECAST_COLOR,
    bar_alpha: float = ALPHA_HIGH,
    bar_width_factor: float = 0.92,
    reference_line_color: str = REFERENCE_LINE_COLOR,
    reference_line_type: str = "dashed",
    reference_line_size: float = LINE_SIZE_MEDIUM,
) -> Any:
    """Probability Integral Transform (PIT) histogram.

    A diagnostic tool for probabilistic forecast calibration
    (Gneiting et al., 2007).  PIT values that are U[0, 1] indicate a
    perfectly calibrated forecast.

    Shape interpretation:
        - **Flat**   → well-calibrated
        - **U-shape** → over-dispersed (intervals too wide)
        - **Hump**   → under-dispersed (intervals too narrow / overconfident)
        - **Skewed** → systematic bias in the predicted distribution

    Args:
        pit_values: 1-D array of PIT values in [0, 1].
        n_bins: Number of histogram bins.
        title: Plot title.
        subtitle: Plot subtitle.
        caption: Plot caption.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        bar_fill_color: Colour for the histogram bars. Defaults to deep blue.
        bar_alpha: Transparency of the bars.
        bar_width_factor: Fraction of the bin width to use for bar width (0–1).
        reference_line_color: Colour of the uniform reference line. Defaults to vermilion.
        reference_line_type: Linetype of the reference line.
        reference_line_size: Stroke width of the reference line.

    Returns:
        A Lets-Plot ``ggplot`` object.

    Examples:
        >>> from twiga.core.plot import plot_pit_histogram
        >>> pit = compute_pit(y_true, predictive_cdf)
        >>> p = plot_pit_histogram(pit, title="Normal Model - PIT")
        >>> p
    """
    vals = np.asarray(pit_values).ravel()
    vals = vals[(vals >= 0) & (vals <= 1)]
    n = len(vals)

    counts, bin_edges = np.histogram(vals, bins=n_bins, range=(0.0, 1.0))
    bin_centers = 0.5 * (bin_edges[:-1] + bin_edges[1:])
    uniform_ref = 1.0 / n_bins
    df_pit = pd.DataFrame(
        {
            "bin": bin_centers,
            "freq": counts / n,
            "bw": bin_edges[1] - bin_edges[0],
        },
    )

    return (
        ggplot(df_pit, aes(x="bin", y="freq"))
        + geom_bar(
            fill=bar_fill_color,
            alpha=bar_alpha,
            stat="identity",
            width=float(df_pit["bw"].iloc[0]) * bar_width_factor,
            show_legend=False,
        )
        + geom_hline(
            yintercept=uniform_ref,
            color=reference_line_color,
            linetype=reference_line_type,
            size=reference_line_size,
        )
        + scale_x_continuous(limits=[0.0, 1.0])
        + labs(
            title=title,
            subtitle=subtitle,
            x="PIT value",
            y="Relative frequency",
            caption=caption,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )
