"""Data exploration plots: line, scatter, scatter matrix, correlation heatmap.

All functions return ``ggplot`` objects styled with the official Twiga theme.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Literal

from lets_plot import (
    aes,
    facet_grid,
    facet_wrap,
    geom_density,
    geom_jitter,
    geom_line,
    geom_point,
    geom_smooth,
    geom_tile,
    ggplot,
    ggsize,
    labs,
    layer_tooltips,
    scale_color_manual,
    scale_fill_gradient2,
    scale_fill_manual,
)
import numpy as np
import pandas as pd

from ._constants import (
    ALPHA_HIGH,
    ALPHA_OPAQUE,
    ALPHA_VERY_LOW,
    CAPTION_DEFAULT,
    FIGURE_SIZE_SMALL,
    FIGURE_SIZE_SQUARE,
    FORECAST_COLOR,
    LINE_SIZE_LARGE,
    LINE_SIZE_XLARGE,
    POINT_SIZE_MEDIUM,
    POINT_SIZE_SMALL,
    POINT_SIZE_XLARGE,
    SMOOTH_COLOR,
)
from .theme import TWIGA_PALETTE, twiga_theme

# ----------------------------------------------------------------------
# line_plot
# ----------------------------------------------------------------------


def line_plot(
    y: Sequence[float],
    x: Sequence[float] | None,
    *,
    title: str = "Charge Curve",
    y_label: str = "Voltage (V)",
    x_label: str | None = None,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_SMALL,
    caption: str = CAPTION_DEFAULT,
    # --- Visual parameters ---
    line_color: str = FORECAST_COLOR,
    line_size: float = LINE_SIZE_XLARGE,
    line_alpha: float = 1.0,
) -> Any:
    """Plot a clean line curve (e.g. charge/discharge profile).

    Args:
        y: Y-values.
        x: Optional X-values. If ``None``, a normalised [0, 1] range is used.
        title: Plot title.
        y_label: Y-axis label.
        x_label: X-axis label.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        caption: Plot caption.
        line_color: Colour of the line. Defaults to ``TWIGA_PALETTE[0]`` (deep blue).
        line_size: Stroke width of the line.
        line_alpha: Transparency of the line.

    Returns:
        A Lets-Plot ``ggplot`` object.
    """
    y_arr = np.asarray(y)
    x_arr = np.linspace(0, 1, len(y_arr)) if x is None else np.asarray(x)
    if x_arr.shape != y_arr.shape:
        raise ValueError("x and y must have the same length.")

    return (
        ggplot()
        + geom_line(
            aes(x=x_arr, y=y_arr),
            color=line_color,
            size=line_size,
            alpha=line_alpha,
            stat="identity",
            sampling=None,
            tooltips=layer_tooltips().disable_splitting(),
        )
        + labs(
            x=x_label or "Normalised Time",
            y=y_label,
            title=title,
            caption=caption,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )


# ----------------------------------------------------------------------
# scatter_plot
# ----------------------------------------------------------------------


def scatter_plot(
    data: pd.DataFrame,
    x_col: str = "cycle",
    y_col: str = "value",
    color_col: str = "group",
    facet: bool = True,  # Added facet option
    title: str | None = None,
    caption: str = CAPTION_DEFAULT,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    # --- Visual parameters ---
    point_size: float = POINT_SIZE_XLARGE,
    point_alpha: float = ALPHA_HIGH,
    smooth_method: Literal["lm", "loess"] = "loess",
    smooth_line_size: float = LINE_SIZE_LARGE,
    smooth_color: str = SMOOTH_COLOR,
) -> Any:
    """Create a faceted scatter plot with a LOESS trend line per group.

    Args:
        data: Input DataFrame.
        x_col: Column for the x-axis.
        y_col: Column for the y-axis.
        color_col: Column used for colour encoding.
        facet: If True, wrap the plot into multiple panels based on ``color_col``.
        title: Optional plot title.
        caption: Plot caption.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        point_size: Size of the scatter points.
        point_alpha: Transparency of the scatter points.
        smooth_method: Smoothing method for the trend line ("lm" or "loess").
        smooth_line_size: Stroke width of the trend line.
        smooth_color: Colour of the trend line. Defaults to ``TWIGA_PALETTE[1]`` (amber).

    Returns:
        A Lets-Plot ``ggplot`` object.
    """
    plot = (
        ggplot(data, aes(x=x_col, y=y_col, color=color_col))
        + geom_point(size=point_size, alpha=point_alpha)
        + geom_smooth(method=smooth_method, size=smooth_line_size, color=smooth_color, seed=42)
        + scale_color_manual(values=TWIGA_PALETTE)
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + labs(
            title=title or f"{y_col} vs {x_col}",
            x=x_col,
            y=y_col,
            caption=caption,
            color=color_col,
        )
    )

    if facet:
        plot += facet_wrap(color_col, ncol=4)

    return plot


# ----------------------------------------------------------------------
# scatter_matrix
# ----------------------------------------------------------------------


def scatter_matrix(
    data: pd.DataFrame,
    variables: list[str],
    targets: list[str],
    hue_col: str | None = None,
    n_sample: int | None = 1000,
    random_state: int = 111,
    title: str | None = None,
    caption: str = CAPTION_DEFAULT,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = (700, 700),
    sort_by_variance: bool = False,
    diag: Literal["scatter", "density", "none"] = "density",
    # --- Visual parameters ---
    point_size: float = POINT_SIZE_SMALL,
    point_alpha: float = ALPHA_HIGH,
    density_alpha: float = ALPHA_VERY_LOW,
) -> Any:
    """Create a scatter-plot matrix (pair plot) using Lets-Plot.

    Args:
        data: Input DataFrame.
        variables: Column names for the x-axes.
        targets: Column names for the y-axes.
        hue_col: Optional colour-encoding column.
        n_sample: Rows to sample. ``None`` uses all rows.
        random_state: Random seed for sampling.
        title: Optional title.
        caption: Plot caption.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        sort_by_variance: Sort axes by descending variance.
        diag: Diagonal cell treatment - ``"density"``, ``"scatter"``, or
            ``"none"``.
        point_size: Size of the scatter points in off-diagonal cells.
        point_alpha: Transparency of the scatter points.
        density_alpha: Transparency of the density fill on the diagonal.

    Returns:
        A Lets-Plot ``ggplot`` object with a faceted scatter matrix.
    """
    if n_sample is not None:
        data = data.sample(n=n_sample, random_state=random_state)

    required = set(variables) | set(targets)
    if hue_col:
        required.add(hue_col)
    missing = required - set(data.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")

    if sort_by_variance:
        all_cols = sorted(required - ({hue_col} if hue_col else set()))
        variances = {c: float(pd.to_numeric(data[c], errors="coerce").var(ddof=0)) for c in all_cols}
        variables = sorted(variables, key=lambda c: (-variances.get(c, float("nan")), c))
        targets = sorted(targets, key=lambda c: (-variances.get(c, float("nan")), c))

    frames = []
    for x_var in variables:
        for y_var in targets:
            sub = data[[x_var, y_var] + ([hue_col] if hue_col else [])].copy()
            sub = sub.rename(columns={x_var: "x_val", y_var: "y_val"})
            sub["x_var"] = x_var
            sub["y_var"] = y_var
            frames.append(sub)
    long_df = pd.concat(frames, ignore_index=True)

    if diag in ("none", "density"):
        scatter_df = long_df[long_df["x_var"] != long_df["y_var"]]
        diag_df = long_df[long_df["x_var"] == long_df["y_var"]] if diag == "density" else None
    else:
        scatter_df = long_df
        diag_df = None

    aes_kw: dict[str, str] = {"x": "x_val", "y": "y_val"}
    if hue_col:
        aes_kw["color"] = hue_col

    p = ggplot(scatter_df, aes(**aes_kw)) + geom_point(
        alpha=point_alpha,
        size=point_size,
        tooltips=layer_tooltips().disable_splitting(),
    )

    if diag_df is not None:
        d_aes: dict[str, str] = {"x": "x_val"}
        if hue_col:
            d_aes["fill"] = hue_col
        p += geom_density(data=diag_df, mapping=aes(**d_aes), alpha=density_alpha)

    if hue_col:
        p += scale_color_manual(values=TWIGA_PALETTE)

    p += (
        facet_grid("x_var", "y_var")
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + labs(title=title or "Scatter Matrix", caption=caption)
        + ggsize(*fig_size)
    )
    return p


# ----------------------------------------------------------------------
# correlation_heatmap
# ----------------------------------------------------------------------


def correlation_heatmap(
    corr_df: pd.DataFrame,
    title: str | None = None,
    caption: str = CAPTION_DEFAULT,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_SQUARE,
    # --- Visual parameters ---
    cmap_low: str = TWIGA_PALETTE[3],  # emerald
    cmap_mid: str = "#f7f7f7",
    cmap_high: str = TWIGA_PALETTE[2],  # vermilion
) -> Any:
    """Create a correlation heatmap from a long-form correlation DataFrame.

    The input must contain columns ``col1``, ``col2``, and ``correlation``,
    matching the output of :class:`twiga.core.stats.corr.CorrelationAnalyzer`.

    Args:
        corr_df: Long-form correlation data.
        title: Plot title.
        caption: Plot caption.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        cmap_low: Hex colour for the negative extreme.
        cmap_mid: Hex colour for zero.
        cmap_high: Hex colour for the positive extreme.

    Returns:
        A Lets-Plot ``ggplot`` object.
    """
    required = {"col1", "col2", "correlation"}
    if not required.issubset(corr_df.columns):
        raise ValueError(f"corr_df must contain {sorted(required)}, got {sorted(corr_df.columns)}")
    return (
        ggplot(corr_df, aes(x="col1", y="col2", fill="correlation"))
        + geom_tile()
        + scale_fill_gradient2(low=cmap_low, mid=cmap_mid, high=cmap_high, midpoint=0)
        + labs(
            title=title or "Correlation Heatmap",
            caption=caption,
            fill="r",
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )
