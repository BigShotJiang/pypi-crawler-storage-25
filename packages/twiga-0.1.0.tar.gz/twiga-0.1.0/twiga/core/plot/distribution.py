"""Distribution plots: density, KDE, CDF, mean±std bands.

All functions return ``ggplot`` objects styled with the official Twiga theme.
"""

from __future__ import annotations

from typing import Any, Literal

from lets_plot import (
    aes,
    flavor_high_contrast_dark,
    flavor_solarized_light,
    geom_density,
    geom_line,
    geom_ribbon,
    geom_step,
    ggplot,
    ggsize,
    guide_legend,
    guides,
    labs,
    layer_tooltips,
    scale_color_manual,
    scale_fill_manual,
)
import numpy as np
import pandas as pd

from ._constants import (
    ALPHA_LOW,
    ALPHA_MEDIUM,
    ALPHA_OPAQUE,
    ALPHA_VERY_HIGH,
    CAPTION_DEFAULT,
    FIGURE_SIZE_SMALL,
    LINE_SIZE_LARGE,
    LINE_SIZE_MEDIUM,
)
from .theme import TWIGA_PALETTE, twiga_theme

# ----------------------------------------------------------------------
# plot_density
# ----------------------------------------------------------------------


def plot_density(
    df: pd.DataFrame,
    *,
    title: str = "Density Plot",
    subtitle: str | None = None,
    n_samples: int | None = None,
    x_col: str = "value",
    color_col: str = "distribution",
    x_label: str = "Value",
    y_label: str = "Density",
    alpha: float = ALPHA_MEDIUM,
    line_size: float = LINE_SIZE_LARGE,
    adjust: float = 1.0,
    font_size: int = 10,
    caption: str = CAPTION_DEFAULT,
    flavor: Literal["dark", "light"] | None = "light",
    show_x_axis: bool = True,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_SMALL,
) -> Any:
    """Overlaid kernel density plot for multiple distributions.

    Args:
        df: Long-format DataFrame with at least ``x_col`` and ``color_col``.
        title: Plot title.
        subtitle: Optional subtitle.
        n_samples: Limit rows to N samples.
        x_col: Numeric column for the x-axis.
        color_col: Categorical column that defines each distribution group.
        x_label: X-axis label.
        y_label: Y-axis label.
        alpha: Fill transparency (0–1).
        line_size: Density outline stroke width.
        adjust: KDE bandwidth multiplier (>1 = smoother).
        font_size: Base font size.
        caption: Plot caption.
        flavor: ``"dark"`` for high-contrast dark, ``"light"`` for solarised
            light, ``None`` for plain Twiga theme.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.

    Returns:
        A Lets-Plot ``ggplot`` object.
    """
    missing = {x_col, color_col} - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")

    if n_samples is not None:
        df = df.head(n_samples)

    n_groups = df[color_col].nunique()
    colors = TWIGA_PALETTE[:n_groups]

    p = (
        ggplot(df, aes(x=x_col, color=color_col, fill=color_col))
        + geom_density(
            alpha=alpha,
            size=line_size,
            adjust=adjust,
            tooltips=layer_tooltips().disable_splitting(),
        )
        + scale_color_manual(values=colors)
        + scale_fill_manual(values=colors)
        + labs(
            title=title,
            subtitle=subtitle or "Empirical Density Estimates",
            caption=caption,
            x=x_label,
            y=y_label,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + guides(fill=guide_legend(nrow=1), color=guide_legend(nrow=1))
        + ggsize(*fig_size)
    )

    if flavor == "dark":
        p += flavor_high_contrast_dark()
    elif flavor == "light":
        p += flavor_solarized_light()

    return p


# ----------------------------------------------------------------------
# plot_kde (wrapper)
# ----------------------------------------------------------------------


def plot_kde(
    df: pd.DataFrame,
    x_col: str,
    color_col: str | None = None,
    *,
    title: str = "Density",
    x_label: str | None = None,
    alpha: float = ALPHA_VERY_HIGH,
    line_size: float = LINE_SIZE_LARGE,
    caption: str = CAPTION_DEFAULT,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_SMALL,
) -> Any:
    """Kernel density estimate with optional per-group colour encoding.

    Thin wrapper around :func:`plot_density` using the ``plot_kde`` name.

    Args:
        df: Source DataFrame.
        x_col: Numeric column to estimate density for.
        color_col: Optional categorical column for per-group density curves.
        title: Plot title.
        x_label: X-axis label (defaults to ``x_col``).
        alpha: Fill transparency.
        line_size: Density outline stroke width.
        caption: Plot caption.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.

    Returns:
        A Lets-Plot ``ggplot`` object.
    """
    df_in = df.copy()
    if color_col is None or color_col not in df_in.columns:
        df_in["_group"] = "data"
        color_col = "_group"

    return plot_density(
        df_in,
        title=title,
        x_col=x_col,
        color_col=color_col,
        x_label=x_label or x_col,
        alpha=alpha,
        line_size=line_size,
        caption=caption,
        flavor=None,
        show_x_axis=show_x_axis,
        font_size=font_size,
        line_width=line_width,
        x_axis_angle=x_axis_angle,
        legend_pos=legend_pos,
        grid=grid,
        fig_size=fig_size,
    )


# ----------------------------------------------------------------------
# plot_cdf
# ----------------------------------------------------------------------


def plot_cdf(
    df: pd.DataFrame,
    x_col: str,
    color_col: str | None = None,
    *,
    title: str = "Cumulative Distribution",
    x_label: str | None = None,
    caption: str = CAPTION_DEFAULT,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = FIGURE_SIZE_SMALL,
    # --- Visual parameters ---
    step_line_size: float = LINE_SIZE_LARGE,
    step_alpha: float = ALPHA_OPAQUE,
) -> Any:
    """Empirical cumulative distribution function (ECDF).

    Computes the ECDF per group and renders step lines with Twiga-palette
    colours.

    Args:
        df: Source DataFrame.
        x_col: Numeric column for the x-axis.
        color_col: Optional categorical grouping column.
        title: Plot title.
        x_label: X-axis label (defaults to ``x_col``).
        caption: Plot caption.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        step_line_size: Stroke width of the step lines.
        step_alpha: Transparency of the step lines.

    Returns:
        A Lets-Plot ``ggplot`` object.
    """
    groups = df[color_col].unique().tolist() if color_col else [None]
    frames: list[pd.DataFrame] = []
    for grp in groups:
        sub = df[df[color_col] == grp] if (color_col and grp is not None) else df
        vals = sub[x_col].dropna().sort_values().reset_index(drop=True)
        n = len(vals)
        frame = pd.DataFrame({x_col: vals.values, "cdf": np.arange(1, n + 1) / n})
        if color_col:
            frame[color_col] = grp
        frames.append(frame)

    cdf_df = pd.concat(frames, ignore_index=True)
    aes_kw: dict[str, str] = {"x": x_col, "y": "cdf"}
    if color_col:
        aes_kw["color"] = color_col

    return (
        ggplot(cdf_df, aes(**aes_kw))
        + geom_step(size=step_line_size, alpha=step_alpha)
        + scale_color_manual(values=TWIGA_PALETTE[: len(groups)])
        + labs(
            title=title,
            x=x_label or x_col,
            y="Cumulative Probability",
            caption=caption,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )


# ----------------------------------------------------------------------
# plot_distribution
# ----------------------------------------------------------------------


def plot_distribution(
    df: pd.DataFrame,
    x_col: str,
    y_col: str,
    color_col: str | None = None,
    *,
    title: str | None = None,
    x_label: str | None = None,
    y_label: str | None = None,
    alpha: float = ALPHA_LOW,
    caption: str = CAPTION_DEFAULT,
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
    fig_size: tuple[int, int] = (560, 320),
    # --- Visual parameters ---
    ribbon_alpha: float = ALPHA_LOW,
    line_size: float = LINE_SIZE_LARGE,
) -> Any:
    """Mean ± standard-deviation band grouped by ``x_col``.

    Groups by ``x_col`` (and optionally ``color_col``), computes per-group
    mean and std for ``y_col``, then renders the mean as a line with a
    translucent ±1σ ribbon.

    Args:
        df: Source DataFrame.
        x_col: Grouping / x-axis column (e.g. ``"hour"``).
        y_col: Numeric column whose distribution to visualise.
        color_col: Optional secondary grouping column.
        title: Plot title.
        x_label: X-axis label.
        y_label: Y-axis label.
        alpha: Ribbon transparency (deprecated, use ribbon_alpha).
        caption: Plot caption.
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points.
        line_width: Stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.
        fig_size: Figure size ``(width_px, height_px)``.
        ribbon_alpha: Transparency of the ±1σ ribbon.
        line_size: Stroke width of the mean line.

    Returns:
        A Lets-Plot ``ggplot`` object.
    """
    # Use ribbon_alpha if provided, else fall back to alpha for backward compatibility
    ribbon_alpha_val = ribbon_alpha if "ribbon_alpha" in locals() else alpha

    group_cols = [x_col] + ([color_col] if color_col else [])
    agg = df.groupby(group_cols)[y_col].agg(mean="mean", std="std").reset_index()
    agg["lower"] = agg["mean"] - agg["std"].fillna(0)
    agg["upper"] = agg["mean"] + agg["std"].fillna(0)

    aes_line: dict[str, str] = {"x": x_col, "y": "mean"}
    aes_rib: dict[str, str] = {"x": x_col, "ymin": "lower", "ymax": "upper"}
    if color_col:
        aes_line["color"] = color_col
        aes_rib["fill"] = color_col

    n = df[color_col].nunique() if color_col else 1
    return (
        ggplot(agg)
        + geom_ribbon(aes(**aes_rib), alpha=ribbon_alpha_val, color="none")
        + geom_line(aes(**aes_line), size=line_size)
        + scale_color_manual(values=TWIGA_PALETTE[:n])
        + scale_fill_manual(values=TWIGA_PALETTE[:n])
        + labs(
            title=title or f"Distribution of {y_col} by {x_col}",
            x=x_label or x_col,
            y=y_label or y_col,
            caption=caption,
        )
        + twiga_theme(
            show_x_axis=show_x_axis,
            font_size=font_size,
            line_width=line_width,
            x_axis_angle=x_axis_angle,
            legend_pos=legend_pos,
            grid=grid,
        )
        + ggsize(*fig_size)
    )
