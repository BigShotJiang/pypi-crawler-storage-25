"""Twiga Forecast theme and colour palette for Lets-Plot."""

from __future__ import annotations

from typing import Any, Literal

from lets_plot import element_blank, element_line, element_text, theme

DEFAULT_FONT_FAMILY = "'Segoe UI', Inter, Roboto, 'Helvetica Neue', Arial, sans-serif"

# ── Twiga brand palette ────────────────────────────────────────────────────────
# 10-colour, colorblind-friendly sequence derived from the Twiga brand identity.
# Primary accent is Twiga deep-teal; remaining colours follow a ColorBrewer /
# Wong (2011) safe combination.
TWIGA_PALETTE = [
    "#0072B2",
    "#D55E00",
    "#009E73",
    "#E69F00",
    "#7035B7",
    "#57B8E0",
    "#CC79A7",
    "#56595E",
    "#A19368",
    "#8AABB4",
]

# Legacy palette names kept for backward compatibility
pro_colors = TWIGA_PALETTE
pro_colors_old = [
    "#0078D4",
    "#00B294",
    "#FF8C00",
    "#D83B01",
    "#5C2D91",
    "#107C10",
    "#605E5C",
    "#E1DFDD",
]
tableau10 = [
    "#1f77b4",
    "#ff7f0e",
    "#2ca02c",
    "#d62728",
    "#9467bd",
    "#8c564b",
    "#e377c2",
    "#7f7f7f",
    "#bcbd22",
    "#17becf",
]


def twiga_theme(
    show_x_axis: bool = True,
    font_size: int = 10,
    line_width: float = 0.8,
    x_axis_angle: int = 0,
    legend_pos: Literal["top", "bottom", "left", "right", "none"] = "top",
    grid: bool = False,
) -> Any:
    """Official Twiga Forecast theme for Lets-Plot visualizations.

    Produces clean, publication-quality figures aligned with the Twiga brand:
    left-aligned title, optional subtle horizontal grid, no vertical grid,
    and a professional Inter/Segoe-UI font stack.

    Args:
        show_x_axis: Whether to render x-axis labels, ticks, and title.
        font_size: Base font size in points (axis labels, legend text).
        line_width: Base stroke width for axis lines and ticks.
        x_axis_angle: Rotation angle for x-axis tick labels.
        legend_pos: Legend anchor - "top", "bottom", "left", "right", or "none".
        grid: If True, draw subtle horizontal reference lines.

    Returns:
        A Lets-Plot ``theme`` object ready to be added to any ``ggplot``.

    Examples:
        >>> from twiga.core.plot import twiga_theme, TWIGA_PALETTE
        >>> p = ggplot(df, aes("x", "y")) + geom_line() + twiga_theme()
    """
    font_family = "Inter, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif"
    title_size = int(font_size * 1.55)
    subtitle_size = int(font_size * 1.2)
    axis_title_size = int(font_size * 1.1)

    base = theme(
        # ── Legend ──────────────────────────────────────────────────────────
        legend_position=legend_pos,
        legend_background=element_blank(),
        legend_key=element_blank(),
        legend_spacing=10,
        # ── Backgrounds & whitespace ─────────────────────────────────────────
        plot_background=element_blank(),
        panel_background=element_blank(),
        panel_border=element_blank(),
        plot_margin=[16, 16, 10, 10],  # top, right, bottom, left - breathing room
        strip_background=element_blank(),
        strip_text=element_text(face="bold", size=font_size, hjust=0),
        # ── Grid lines ──────────────────────────────────────────────────────
        panel_grid_minor=element_blank(),
        panel_grid_major_x=element_blank(),
        panel_grid_major_y=(element_line(color="#e8e8e8", size=0.4) if grid else element_blank()),
        # ── Axes - light strokes let data dominate ───────────────────────────
        axis_line=element_line(size=line_width, color="#bbbbbb"),
        axis_ticks=element_line(size=line_width * 0.75, color="#bbbbbb"),
        # ── Global text ─────────────────────────────────────────────────────
        text=element_text(
            family=font_family,
            size=font_size,
            color="#2d2d2d",
        ),
        axis_text_x=element_text(
            angle=x_axis_angle,
            hjust=0.5,
            margin=[8, 0, 0, 0],
            color="#666666",
        ),
        axis_text_y=element_text(
            margin=[0, 0, 0, 8],
            color="#666666",
        ),
        axis_title_x=element_text(
            size=axis_title_size,
            face="bold",
            margin=[10, 0, 0, 0],
        ),
        axis_title_y=element_text(
            size=axis_title_size,
            face="bold",
            margin=[0, 10, 0, 0],
        ),
        # ── Title / subtitle / caption ───────────────────────────────────────
        plot_title=element_text(
            size=title_size,
            face="bold",
            hjust=0,
            margin=[0, 0, 6, 0],
            color="#333333",
        ),
        plot_subtitle=element_text(
            size=subtitle_size,
            hjust=0,
            margin=[0, 0, 18, 0],
            color="#6b6b6b",
        ),
        plot_caption=element_text(
            size=int(font_size * 0.82),
            face="italic",
            hjust=1.0,
            color="#999999",
            margin=[12, 0, 0, 0],
        ),
        # ── Legend text ──────────────────────────────────────────────────────
        legend_title=element_text(
            size=axis_title_size,
            face="bold",
        ),
        legend_text=element_text(size=font_size),
    )

    if not show_x_axis:
        base += theme(
            axis_title_x=element_blank(),
            axis_text_x=element_blank(),
            axis_ticks_x=element_blank(),
            axis_line_x=element_blank(),
        )
    return base
