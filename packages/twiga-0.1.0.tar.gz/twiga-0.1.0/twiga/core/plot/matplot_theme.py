import contextlib
import shutil
from typing import Any

from cycler import cycler
import matplotlib as mpl
from matplotlib import font_manager
from matplotlib_inline.backend_inline import set_matplotlib_formats

from twiga.core.utils.logger import get_logger

log = get_logger(__name__)

_FONT_CANDIDATES = ["Inter", "Segoe UI", "Roboto", "Helvetica Neue", "Helvetica", "Arial"]


def _resolve_font(candidates: list[str]) -> str:
    """Return the first font from candidates that matplotlib can find.

    Falls back to ``'DejaVu Sans'`` - matplotlib's guaranteed built-in -
    if none of the candidates are installed on the system.

    Args:
        candidates: Ordered list of preferred font names.

    Returns:
        Name of the first available font, or ``'DejaVu Sans'``.
    """
    available = {f.name for f in font_manager.fontManager.ttflist}
    for font in candidates:
        if font in available:
            log.debug("Resolved font: %s", font)
            return font
    log.debug("No preferred font found - falling back to DejaVu Sans")
    return "DejaVu Sans"


def golden_height(width: float) -> float:
    """Calculate height maintaining golden ratio (≈0.618)."""
    return width * 0.618


def configure_matlib_style(
    latex: bool = False,
    style: list[str] | None = None,
    font_size: int = 10,
    fig_width: float | None = None,
    fig_height: float | None = None,
    dpi: int = 480,
    color_cycle: list[str] | None = None,
    custom_rc: dict[str, Any] | None = None,
) -> None:
    """Configure scientific plotting styles with small fonts and publication-quality settings.

    Applies matplotlib configuration with optimized defaults for scientific plotting,
    including font sizes, figure dimensions, and color cycles. Supports LaTeX rendering
    and custom style specifications.

    Args:
        latex: Enable LaTeX text rendering. Defaults to False.
        style: Custom matplotlib style specifications. If None, uses ["science", "no-latex"]
            when latex is False, else ["science"]. Defaults to None.
        font_size: Base font size in points. Defaults to 10.
        fig_width: Figure width in inches. If None, uses matplotlib's default. Defaults to None.
        fig_height: Figure height in inches. If None, uses matplotlib's default. Defaults to None.
        dpi: Output resolution for saved figures. Defaults to 480.
        color_cycle: Custom color cycle using hex codes. If None, uses predefined colors.
            Defaults to None.
        custom_rc: Additional matplotlib rcParams to override defaults. Defaults to None.

    Raises:
        ImportError: If required styles (e.g., science) are not available
        OSError: If LaTeX dependencies are missing when latex=True
    """
    # Default color cycle
    default_colors = [
        "#107591",
        "#00c0bf",
        "#f69a48",
        "#fdcd49",
        "#8da798",
        "#a19368",
        "#525252",
        "#a6761d",
        "#7035b7",
        "#cf166e",
    ]

    # Resolve a single font name matplotlib can actually use.
    # CSS-style font stacks are not supported - matplotlib needs one name
    # that is present in fontManager.ttflist.
    font_family = _resolve_font(_FONT_CANDIDATES)

    title_size = int(font_size * 1.5)
    small_font_size = int(font_size * 0.8)
    if fig_width is not None:
        fig_height = golden_height(fig_width) or fig_height

    # Base configuration
    plot_config = {
        "figure.dpi": dpi,
        "savefig.dpi": dpi,
        "figure.figsize": (
            fig_width or mpl.rcParams["figure.figsize"][0],
            fig_height or mpl.rcParams["figure.figsize"][1],
        ),
        # Font settings
        "font.size": font_size,
        "font.family": font_family,
        "axes.labelsize": font_size,
        "axes.titlesize": title_size,
        "axes.edgecolor": "#555555",
        "axes.facecolor": "white",
        "axes.labelcolor": "#333333",
        "axes.titlecolor": "#333333",
        "xtick.labelsize": small_font_size,
        "ytick.labelsize": small_font_size,
        "xtick.color": "#555555",
        "ytick.color": "#555555",
        "xtick.direction": "out",
        "ytick.direction": "out",
        "legend.fontsize": small_font_size,
        # Line and axis settings
        "axes.linewidth": 0.7,
        "grid.linewidth": 0.5,
        "lines.linewidth": 1.2,
        "lines.markeredgewidth": 0.8,
        # Layout and spacing
        "savefig.bbox": "tight",
        "mathtext.fontset": "dejavuserif",
        "savefig.pad_inches": 0.05,
        "figure.autolayout": True,
        # Legend customization
        "legend.frameon": False,
        "legend.handlelength": 1.4,
        "legend.labelspacing": 0.3,
        # Color cycle
        "axes.prop_cycle": cycler(color=color_cycle or default_colors),
    }

    latex_available = shutil.which("latex") is not None
    use_latex = latex and latex_available

    # LaTeX configuration - overrides font.family when active
    if use_latex:
        plot_config.update(
            {
                "text.usetex": True,
                "font.family": "serif",
                "font.serif": ["Computer Modern Roman", "DejaVu Serif"],
                "text.latex.preamble": r"\usepackage{amsmath,amssymb}",
                "axes.formatter.use_mathtext": True,
            },
        )

    # Apply custom rcParams
    if custom_rc:
        plot_config.update(custom_rc)

    # Apply style and settings
    try:
        if style is None:
            style = ["science", "no-latex"] if not use_latex else ["science"]

        mpl.style.use(style)  # type: ignore[attr-defined]
        mpl.rcParams.update(plot_config)

        # Set output formats for IPython
        set_matplotlib_formats("svg", "pdf", "png")

    except (ImportError, OSError) as e:
        log.info("Style configuration warning: %s", e)
        mpl.rcParams.update(plot_config)


# Context manager version for temporary styling
@contextlib.contextmanager
def plotting_context(**kwargs):
    original_rc = mpl.rcParams.copy()
    configure_matlib_style(**kwargs)
    try:
        yield
    finally:
        mpl.rcParams.update(original_rc)


# Backward-compatible alias (was in utils.py)
configure_plotting = configure_matlib_style


def plot_prediction(ax, true, mu, date=None, true_max=None):
    """Plot true vs predicted values on a matplotlib Axes.

    Lightweight helper kept for backward compatibility and for users who
    prefer a matplotlib workflow.  The Twiga library itself uses
    :func:`~twiga.core.plot.plot_forecast` (Lets-Plot)
    for all built-in visualisations.

    Args:
        ax: Target matplotlib ``Axes``.
        true: Observed values array.
        mu: Predicted values array.
        date: Optional x-axis values. Defaults to integer index.
        true_max: Unused - kept for backward compatibility.

    Returns:
        The modified ``Axes`` object.
    """
    import numpy as _np

    x = _np.arange(len(true)) if date is None else date
    (true_line,) = ax.plot(x, true, ".", mec="#E69F00", mfc="None", ms=3, label="Actual")
    (pred_line,) = ax.plot(x, mu, c="#107591", lw=1.2, alpha=0.9, label="Forecast")
    ax.set_ylabel("Value")
    ax.autoscale(tight=True)
    ax.legend(
        [true_line, pred_line],
        ["Actual", "Forecast"],
        loc="upper center",
        bbox_to_anchor=(0.5, -0.15),
        ncol=2,
        frameon=False,
    )
    return ax
