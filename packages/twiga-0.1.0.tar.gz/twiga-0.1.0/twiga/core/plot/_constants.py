"""Shared default visual parameters for all plotting functions.

All functions should import these constants and use them as fallback defaults.
Individual functions may still override them with explicit keyword arguments.
"""

from .theme import TWIGA_PALETTE

# ---- Colour constants -------------------------------------------------
ACTUAL_COLOR: str = "#0072B2"
FORECAST_COLOR: str = "#D55E00"
RIBBON_FILL: str = TWIGA_PALETTE[3]  # "#009E73" – emerald
REFERENCE_LINE_COLOR: str = TWIGA_PALETTE[2]  # "#D55E00" – vermilion
SMOOTH_COLOR: str = TWIGA_PALETTE[1]  # "#E69F00" – amber

# ---- Line sizes -------------------------------------------------------
LINE_SIZE_TINY: float = 0.6
LINE_SIZE_SMALL: float = 0.75
LINE_SIZE_MEDIUM: float = 0.9
LINE_SIZE_LARGE: float = 1.2
LINE_SIZE_XLARGE: float = 1.4

# ---- Point sizes ------------------------------------------------------
POINT_SIZE_SMALL: float = 1.8
POINT_SIZE_MEDIUM: float = 2.5
POINT_SIZE_LARGE: float = 3.0
POINT_SIZE_XLARGE: float = 3.5

# ---- Alpha (transparency) values --------------------------------------
ALPHA_VERY_LOW: float = 0.08
ALPHA_LOW: float = 0.15
ALPHA_MEDIUM: float = 0.25
ALPHA_HIGH: float = 0.65
ALPHA_VERY_HIGH: float = 0.85
ALPHA_OPAQUE: float = 0.95

# ---- Bar / segment widths ---------------------------------------------
BAR_WIDTH_DEFAULT: float = 0.6
SEGMENT_WIDTH_DEFAULT: float = 1.0

# ---- Ribbon alpha ranges ----------------------------------------------
RIBBON_ALPHA_MIN: float = 0.08
RIBBON_ALPHA_MAX: float = 0.30
FORECAST_INTERVAL_ALPHA_MIN: float = 0.12
FORECAST_INTERVAL_ALPHA_MAX: float = 0.22

# ---- Figure sizes -----------------------------------------------------
FIGURE_SIZE_DEFAULT: tuple[int, int] = (820, 300)
FIGURE_SIZE_SMALL: tuple[int, int] = (500, 300)
FIGURE_SIZE_MEDIUM: tuple[int, int] = (640, 300)
FIGURE_SIZE_LARGE: tuple[int, int] = (820, 380)
FIGURE_SIZE_SQUARE: tuple[int, int] = (500, 500)

# ---- Miscellaneous ----------------------------------------------------
FONT_SIZE_BASE: int = 10
LINE_WIDTH_AXIS: float = 0.8
CAPTION_DEFAULT: str = "Twiga Forecast"
