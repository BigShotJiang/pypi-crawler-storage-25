"""Twiga library exception hierarchy."""

from __future__ import annotations

import importlib

__all__ = [
    "ConfigurationError",
    "MissingExtraError",
    "NotFittedError",
    "PipelineError",
    "TwigaError",
    "require_extra",
]


class TwigaError(Exception):
    """Base class for all twiga library exceptions."""


class ConfigurationError(TwigaError, ValueError):
    """Raised when a configuration is invalid or incompatible."""


class NotFittedError(TwigaError, RuntimeError):
    """Raised when a model or pipeline is used before fitting."""


class PipelineError(TwigaError, RuntimeError):
    """Raised for errors in the data pipeline."""


class MissingExtraError(TwigaError, ImportError):
    """Raised when an optional dependency is not installed."""


def require_extra(package: str, extra: str) -> None:
    """Raise a helpful ImportError if an optional dependency is missing.

    Args:
        package: The Python package to check (e.g. ``"shap"``).
        extra: The twiga extras group that provides it (e.g. ``"explain"``).

    Raises:
        MissingExtraError: If *package* cannot be imported.

    Example:
        >>> require_extra("shap", "explain")
    """
    try:
        importlib.import_module(package)
    except ImportError:
        raise MissingExtraError(
            f"'{package}' is required but not installed. Install it with:  pip install 'twiga[{extra}]'"
        ) from None
