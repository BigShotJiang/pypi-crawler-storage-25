"""Twiga production serving layer.

Provides a FastAPI application factory, checkpoint loader, Evidently monitor,
and Pydantic request / response schemas for deploying trained forecasters.

Quickstart::

    from twiga import TwigaForecaster
    from twiga.serve import create_app

    forecaster = TwigaForecaster(data_params=..., model_params=..., train_params=...)
    app = create_app(forecaster, report_dir="reports/")

    # launch with:  uvicorn my_module:app --host 0.0.0.0 --port 8000
"""

from __future__ import annotations

from twiga.serve.app import create_app
from twiga.serve.loader import ModelLoader
from twiga.serve.monitor import ForecastMonitor
from twiga.serve.schemas import (
    ForecastRequest,
    ForecastResponse,
    HealthResponse,
    IntervalRequest,
    IntervalResponse,
    MonitorResponse,
)

__all__ = [
    "create_app",
    "ModelLoader",
    "ForecastMonitor",
    "ForecastRequest",
    "ForecastResponse",
    "IntervalRequest",
    "IntervalResponse",
    "HealthResponse",
    "MonitorResponse",
]
