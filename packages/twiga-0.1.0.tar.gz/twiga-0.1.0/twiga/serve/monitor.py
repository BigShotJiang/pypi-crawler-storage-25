"""Production monitoring for Twiga forecasting models using Evidently.

This module provides a comprehensive monitoring suite for deployed forecasting
models. It integrates Evidently for drift detection and performance tracking,
with seamless MLflow logging for artifacts and metrics.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from evidently import DataDefinition, Dataset, Report
from evidently.core.datasets import Regression
from evidently.metrics import DriftedColumnsCount
from evidently.presets import DataDriftPreset, RegressionPreset
import mlflow
import numpy as np
import pandas as pd

from twiga.core.utils.logger import get_logger, log_section

log = get_logger(__name__)

__all__ = ["ForecastMonitor"]


class ForecastMonitor:
    """Monitoring suite for deployed forecasting models using Evidently.

    This class handles feature data drift, prediction drift, and regression
    performance monitoring. It automatically saves HTML + JSON reports and
    logs key metrics to MLflow when an active run exists.

    Attributes:
        report_dir: Directory where HTML and JSON reports are saved.
        target_col: Name of the target column in performance data.
        prediction_col: Default name for single prediction column.
        nan_policy: Policy for handling missing values ("drop", "fill", "skip").
    """

    def __init__(
        self,
        report_dir: str | Path = "reports",
        target_col: str = "target",
        prediction_col: str = "prediction",
        nan_policy: Literal["drop", "fill", "skip"] = "skip",
    ) -> None:
        """Initialize the ForecastMonitor.

        Args:
            report_dir: Directory for saving monitoring reports.
            target_col: Column name for the target variable.
            prediction_col: Default column name for predictions.
            nan_policy: How to handle NaN values in reference/current data.
        """
        self.report_dir = Path(report_dir)
        self.report_dir.mkdir(parents=True, exist_ok=True)

        self.target_col = target_col
        self.prediction_col = prediction_col
        self.nan_policy = nan_policy

        self._reference: pd.DataFrame | None = None

    def set_reference(self, reference_df: pd.DataFrame) -> None:
        """Set the reference (baseline) dataset for drift comparison.

        Args:
            reference_df: DataFrame representing the training or baseline data.
        """
        self._reference = reference_df.copy()
        log.info("Reference dataset set | shape=%s", reference_df.shape)

    def run_data_drift(
        self,
        current_df: pd.DataFrame,
        feature_cols: list[str] | None = None,
        categorical_cols: list[str] | None = None,
        time_col: str | None = None,
        drift_threshold: float = 0.5,
    ) -> tuple[bool, dict[str, Any]]:
        """Evaluate distribution shift in input features.

        Args:
            current_df: Current production data.
            feature_cols: Specific features to monitor (if None, uses intersection).
            categorical_cols: Explicit list of categorical columns.
            time_col: Column for optional temporal sorting.
            drift_threshold: Threshold for alerting on dataset drift score.

        Returns:
            Tuple of (is_alert, summary_dict).
        """
        self._require_reference()
        if current_df.empty:
            log.warning("Current data is empty. Skipping drift calculation.")
            return False, {"dataset_drift_score": 0.0, "drift_detected": False, "error": "empty_current_data"}
        log_section(log, "Data Drift Report")

        ref, cur = self._prepare_data(current_df, feature_cols, categorical_cols, time_col)

        data_def = DataDefinition(
            numerical_columns=ref.select_dtypes("number").columns.tolist(),
            categorical_columns=(categorical_cols or ref.select_dtypes(exclude="number").columns.tolist()),
        )

        report = Report(
            metrics=[
                DataDriftPreset(),  # Rich per-column drift + visualizations
                DriftedColumnsCount(),  # Easy extraction of drifted column count
            ]
        )

        snapshot = report.run(
            reference_data=Dataset.from_pandas(ref, data_definition=data_def),
            current_data=Dataset.from_pandas(cur, data_definition=data_def),
        )

        report_path = self._save_report(snapshot, prefix="data_drift")
        summary = self._extract_drift_summary(snapshot, report_path)

        is_alert = summary["dataset_drift_score"] >= drift_threshold

        if mlflow.active_run():
            mlflow.log_metric("feature_drift_score", summary["dataset_drift_score"])

        self._log_drift_alert("DATA", is_alert, summary["dataset_drift_score"], drift_threshold)

        return is_alert, summary

    def run_prediction_drift(
        self,
        current_predictions: np.ndarray | pd.Series | pd.DataFrame,
        reference_predictions: np.ndarray | pd.Series | pd.DataFrame,
        prediction_cols: list[str] | None = None,
        drift_threshold: float = 0.5,
    ) -> tuple[bool, dict[str, Any]]:
        """Evaluate shift in model predictions.

        Supports single-output and multi-output forecasts.

        Args:
            current_predictions: Predictions from the current period.
            reference_predictions: Predictions from the reference period.
            prediction_cols: Custom column names for multi-output cases.
            drift_threshold: Threshold for alerting.

        Returns:
            Tuple of (is_alert, summary_dict).
        """
        log_section(log, "Prediction Drift Report")

        ref_df = self._predictions_to_df(reference_predictions, prediction_cols)
        cur_df = self._predictions_to_df(current_predictions, prediction_cols)

        data_def = DataDefinition(numerical_columns=ref_df.columns.tolist())

        report = Report(
            metrics=[
                DataDriftPreset(),
                DriftedColumnsCount(),
            ]
        )

        snapshot = report.run(
            reference_data=Dataset.from_pandas(ref_df, data_definition=data_def),
            current_data=Dataset.from_pandas(cur_df, data_definition=data_def),
        )

        report_path = self._save_report(snapshot, prefix="prediction_drift")
        summary = self._extract_drift_summary(snapshot, report_path)

        if mlflow.active_run():
            mlflow.log_metric("prediction_drift_score", summary["dataset_drift_score"])

        is_alert = summary["dataset_drift_score"] >= drift_threshold
        self._log_drift_alert("PREDICTION", is_alert, summary["dataset_drift_score"], drift_threshold)

        return is_alert, summary

    def run_performance(
        self,
        current_df: pd.DataFrame,
        target_col: str | None = None,
        prediction_col: str | None = None,
    ) -> dict[str, Any]:
        """Track regression performance metrics (MAE, RMSE, MAPE).

        Args:
            current_df: DataFrame containing both target and predictions.
            target_col: Override for target column name.
            prediction_col: Override for prediction column name.

        Returns:
            Dictionary with performance metrics and report path.
        """
        log_section(log, "Regression Performance Report")

        target = target_col or self.target_col
        prediction = prediction_col or self.prediction_col

        if target not in current_df.columns or prediction not in current_df.columns:
            raise KeyError(f"Required columns missing: '{target}' or '{prediction}'")

        data_def = DataDefinition(
            numerical_columns=[target, prediction],
            regression=[Regression(target=target, prediction=prediction)],
        )

        report = Report(metrics=[RegressionPreset()])

        snapshot = report.run(
            reference_data=None,
            current_data=Dataset.from_pandas(current_df, data_definition=data_def),
        )

        report_path = self._save_report(snapshot, prefix="performance")
        summary = self._extract_performance_summary(snapshot, report_path)

        if mlflow.active_run():
            for m in ["mae", "rmse", "mape"]:
                if val := summary.get(m):
                    mlflow.log_metric(f"prod_{m}", val)

        return summary

    def run_full_monitoring(
        self,
        current_df: pd.DataFrame,
        current_predictions: np.ndarray | pd.Series | pd.DataFrame,
        reference_predictions: np.ndarray | pd.Series | pd.DataFrame,
        feature_cols: list[str] | None = None,
        categorical_cols: list[str] | None = None,
        target_col: str | None = None,
        prediction_col: str | None = None,
        drift_threshold: float = 0.5,
    ) -> dict[str, Any]:
        """Run data drift, prediction drift, and performance monitoring in one call.

        Args:
            current_df: Current production features and actuals.
            current_predictions: Model predictions on current data.
            reference_predictions: Reference (baseline) predictions.
            feature_cols: Features to monitor for data drift.
            categorical_cols: Explicit categorical columns.
            target_col: Override target column.
            prediction_col: Override prediction column.
            drift_threshold: Alert threshold for both drift types.

        Returns:
            Dictionary containing overall alert flag and detailed results.
        """
        log_section(log, "FULL MONITORING RUN")

        data_drift_alert, data_summary = self.run_data_drift(
            current_df=current_df,
            feature_cols=feature_cols,
            categorical_cols=categorical_cols,
            drift_threshold=drift_threshold,
        )

        pred_drift_alert, pred_summary = self.run_prediction_drift(
            current_predictions=current_predictions,
            reference_predictions=reference_predictions,
            prediction_cols=None,
            drift_threshold=drift_threshold,
        )

        perf_summary = self.run_performance(
            current_df=current_df,
            target_col=target_col,
            prediction_col=prediction_col,
        )

        overall_alert = data_drift_alert or pred_drift_alert

        return {
            "overall_alert": overall_alert,
            "data_drift": {"alert": data_drift_alert, **data_summary},
            "prediction_drift": {"alert": pred_drift_alert, **pred_summary},
            "performance": perf_summary,
            "timestamp": datetime.now(UTC).isoformat(),
        }

    # ------------------------------------------------------------------
    # Internal Helpers
    # ------------------------------------------------------------------

    def _predictions_to_df(self, data: Any, prediction_cols: list[str] | None = None) -> pd.DataFrame:
        """Convert predictions in various formats to a pandas DataFrame.

        Args:
            data: Predictions as ndarray, Series, or DataFrame.
            prediction_cols: Custom column names (for multi-output).

        Returns:
            DataFrame with prediction columns.
        """
        if isinstance(data, pd.DataFrame):
            return data.copy()
        arr = np.asarray(data)
        # Handle empty array
        if arr.size == 0:
            cols = prediction_cols or [self.prediction_col]
            return pd.DataFrame(columns=cols)
        # Handle scalar (0‑dimensional)
        if arr.ndim == 0:
            arr = np.array([arr.item()])
        if arr.ndim == 1:
            cols = prediction_cols or [self.prediction_col]
            return pd.DataFrame(arr.reshape(-1, 1), columns=cols)
        cols = prediction_cols or [f"pred_{i}" for i in range(arr.shape[1])]
        return pd.DataFrame(arr.reshape(arr.shape[0], -1), columns=cols)

    def _prepare_data(
        self,
        cur: pd.DataFrame,
        f_cols: list[str] | None,
        c_cols: list[str] | None,
        t_col: str | None,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Prepare reference and current data (alignment + missing value handling)."""
        ref = self._reference.copy()
        cur = cur.copy()

        cols = list(dict.fromkeys((f_cols or []) + (c_cols or [])))
        if not cols:
            cols = list(set(ref.columns) & set(cur.columns))

        ref, cur = ref[cols], cur[cols]

        if t_col:
            if t_col in ref.columns:
                ref = ref.sort_values(t_col)
            if t_col in cur.columns:
                cur = cur.sort_values(t_col)

        return self._handle_missing_values(ref, cur)

    def _extract_drift_summary(self, snapshot: Any, report_path: Path) -> dict[str, Any]:
        """Extract drift metrics from the Evidently snapshot.

        Args:
            snapshot: Evidently ``Snapshot`` returned by ``Report.run()``.
            report_path: Path where the HTML report was saved.

        Returns:
            Summary dict with keys: ``n_drifted``, ``total``,
            ``dataset_drift_score``, ``drift_detected``, ``feature_drift``,
            ``report_path``, ``timestamp``.
        """
        res: dict[str, Any] = {
            "feature_drift": {},
            "n_drifted": 0,
            "total": 0,
            "report_path": str(report_path),
            "timestamp": datetime.now(UTC).isoformat(),
        }

        try:
            for metric_result in snapshot.metric_results.values():
                if hasattr(metric_result, "count") and hasattr(metric_result, "share"):
                    res["n_drifted"] = int(metric_result.count.value)
                    share = metric_result.share.value
                    total = metric_result.count.value / share if share else 0
                    res["total"] = int(round(total))
                    break
        except Exception:
            log.exception(
                "Drift metric extraction failed from Evidently snapshot. "
                "Check that evidently>=0.7 is installed and the Report ran successfully."
            )

        res["dataset_drift_score"] = round(res["n_drifted"] / res["total"], 4) if res["total"] > 0 else 0.0
        res["drift_detected"] = res["n_drifted"] > 0

        return res

    def _extract_performance_summary(self, snapshot: Any, report_path: Path) -> dict[str, Any]:
        """Extract MAE, RMSE, and MAPE from RegressionPreset snapshot results."""
        import json

        summary: dict[str, Any] = {
            "report_path": str(report_path),
            "timestamp": datetime.now(UTC).isoformat(),
        }

        try:
            data = json.loads(snapshot.json())
            for entry in data.get("metrics", []):
                name = entry.get("metric_name", "")
                value = entry.get("value")
                if value is None:
                    continue
                # Scalar value
                scalar = float(value) if isinstance(value, (int, float)) else None
                # MeanStd value
                if isinstance(value, dict):
                    scalar = float(value.get("mean", float("nan")))
                if scalar is None or not np.isfinite(scalar):
                    continue
                if name.startswith("MAE("):
                    summary["mae"] = round(scalar, 4)
                elif name.startswith("RMSE("):
                    summary["rmse"] = round(scalar, 4)
                elif name.startswith("MAPE("):
                    summary["mape"] = round(scalar, 4)
        except Exception:
            log.exception("Performance metric extraction failed.")

        return summary

    def _save_report(self, snapshot: Any, prefix: str) -> Path:
        """Save HTML (human-readable) and JSON (machine-readable) reports.

        Args:
            snapshot: Evidently ``Snapshot`` returned by ``Report.run()``.
            prefix: Filename prefix (e.g. ``"data_drift"``).

        Also logs them as MLflow artifacts if an active run exists.
        """
        ts = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        base_path = self.report_dir / f"{prefix}_{ts}"

        html_path = base_path.with_suffix(".html")
        json_path = base_path.with_suffix(".json")

        snapshot.save_html(str(html_path))
        snapshot.save_json(str(json_path))

        if mlflow.active_run():
            mlflow.log_artifact(str(html_path), artifact_path="monitoring_reports")
            mlflow.log_artifact(str(json_path), artifact_path="monitoring_reports")

        return html_path.resolve()

    def _log_drift_alert(self, drift_type: str, is_alert: bool, score: float, threshold: float) -> None:
        """Log drift detection result at appropriate severity level."""
        if is_alert:
            log.warning(
                "%s DRIFT DETECTED: Score %.4f exceeds threshold %.4f",
                drift_type,
                score,
                threshold,
            )
        else:
            log.info("No significant %s drift detected.", drift_type.lower())

    def _require_reference(self) -> None:
        """Ensure reference data has been set."""
        if self._reference is None:
            raise RuntimeError("Reference data not set. Call set_reference() first.")

    def _handle_missing_values(self, ref: pd.DataFrame, cur: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Apply the configured NaN handling policy."""
        if self.nan_policy == "drop":
            return ref.dropna(), cur.dropna()
        if self.nan_policy == "fill":
            return ref.fillna(0), cur.fillna(0)
        return ref, cur
