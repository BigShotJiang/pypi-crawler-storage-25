"""Pydantic request and response schemas for the Twiga serving API.

All schemas use strict typing and are self-documenting through ``Field``
descriptions, consistent with the rest of the Twiga config system.
"""

from __future__ import annotations

from typing import Any, Literal

import numpy as np
from pydantic import BaseModel, Field, field_validator, model_validator

# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------


class ForecastRequest(BaseModel):
    """Payload for a point or interval forecast request.

    Args:
        records: Time series records as a list of dicts (each dict is one
            row, must contain the ``timestamp`` column and all feature
            columns required by the fitted pipeline).
        ensemble_strategy: How to combine predictions from multiple models.
            ``None`` returns predictions per model.
        prepare_test_data: Whether to prepend training tail rows before
            transforming (mirrors the forecaster flag).

    Example::

        {
            "records": [
                {"timestamp": "2024-01-01T00:00:00", "temperature": 12.5, ...},
                ...
            ],
            "ensemble_strategy": "mean"
        }
    """

    records: list[dict[str, Any]] = Field(
        description="List of row dicts representing the input time series.",
        min_length=1,
    )
    ensemble_strategy: Literal["mean", "median", "weighted_mean"] | None = Field(
        default=None,
        description="Ensemble aggregation strategy across models.",
    )
    prepare_test_data: bool = Field(
        default=True,
        description="Prepend training tail to the input before transforming.",
    )

    @field_validator("records")
    @classmethod
    def records_not_empty(cls, v: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Validate records list is non-empty."""
        if not v:
            raise ValueError("records must contain at least one row.")
        return v


class IntervalRequest(ForecastRequest):
    """Payload for a conformal prediction interval request.

    Extends :class:`ForecastRequest` with coverage level control.

    Args:
        alpha: Miscoverage rate.  ``alpha=0.1`` targets 90 % coverage.
    """

    alpha: float = Field(
        default=0.1,
        ge=0.0,
        lt=1.0,
        description="Miscoverage rate (1 - alpha = nominal coverage).",
    )


class HealthRequest(BaseModel):
    """Empty request body for health-check endpoints."""


# ---------------------------------------------------------------------------
# Response schemas
# ---------------------------------------------------------------------------


class ModelPrediction(BaseModel):
    """Point predictions for a single model.

    Args:
        model: Model identifier string.
        predictions: Nested list of shape ``(n_batch, n_horizon, n_targets)``.
        inference_time: Wall-clock seconds spent on inference.
    """

    model: str = Field(description="Model identifier.")
    predictions: list[list[list[float]]] = Field(
        description="Predictions array (n_batch × n_horizon × n_targets).",
    )
    inference_time: float = Field(
        default=0.0,
        description="Inference wall-clock time in seconds.",
    )


class ForecastResponse(BaseModel):
    """Response for a point forecast request.

    Args:
        forecasts: Per-model prediction payloads.
        targets: Target variable names in the same order as the innermost
            dimension of each ``predictions`` array.
        forecast_horizon: Number of future time steps predicted.
    """

    forecasts: list[ModelPrediction] = Field(
        description="Predictions from each model.",
    )
    targets: list[str] = Field(
        description="Target variable names (innermost prediction dimension).",
    )
    forecast_horizon: int = Field(
        description="Number of future steps in each prediction.",
    )

    @classmethod
    def from_arrays(
        cls,
        predictions: dict[str, np.ndarray],
        inference_times: dict[str, float],
        targets: list[str],
        forecast_horizon: int,
    ) -> ForecastResponse:
        """Build a response from raw numpy prediction arrays.

        Args:
            predictions: Mapping of model name → array ``(B, H, T)``.
            inference_times: Mapping of model name → seconds.
            targets: Target variable names.
            forecast_horizon: Number of forecast steps.

        Returns:
            Populated :class:`ForecastResponse`.
        """
        forecasts = [
            ModelPrediction(
                model=name,
                predictions=arr.tolist(),
                inference_time=inference_times.get(name, 0.0),
            )
            for name, arr in predictions.items()
        ]
        return cls(forecasts=forecasts, targets=targets, forecast_horizon=forecast_horizon)


class IntervalPrediction(BaseModel):
    """Conformal interval prediction for a single model.

    Args:
        model: Model identifier string.
        lower: Lower bound array ``(n_batch, n_horizon, n_targets)``.
        forecast: Point forecast array ``(n_batch, n_horizon, n_targets)``.
        upper: Upper bound array ``(n_batch, n_horizon, n_targets)``.
        coverage: Nominal coverage level ``(1 - alpha)``.
        inference_time: Wall-clock seconds spent on inference.
    """

    model: str = Field(description="Model identifier.")
    lower: list[list[list[float]]] = Field(description="Lower prediction bound.")
    forecast: list[list[list[float]]] = Field(description="Point forecast.")
    upper: list[list[list[float]]] = Field(description="Upper prediction bound.")
    coverage: float = Field(description="Nominal coverage level.")
    inference_time: float = Field(default=0.0, description="Inference time in seconds.")


class IntervalResponse(BaseModel):
    """Response for a conformal interval forecast request.

    Args:
        forecasts: Per-model interval prediction payloads.
        targets: Target variable names.
        forecast_horizon: Number of future time steps predicted.
    """

    forecasts: list[IntervalPrediction] = Field(
        description="Interval predictions from each model.",
    )
    targets: list[str] = Field(description="Target variable names.")
    forecast_horizon: int = Field(description="Number of forecast steps.")

    @classmethod
    def from_arrays(
        cls,
        predictions: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]],
        inference_times: dict[str, float],
        targets: list[str],
        forecast_horizon: int,
        alpha: float = 0.1,
    ) -> IntervalResponse:
        """Build a response from raw numpy interval arrays.

        Args:
            predictions: Mapping of model name → ``(lower, forecast, upper)``.
            inference_times: Mapping of model name → seconds.
            targets: Target variable names.
            forecast_horizon: Number of forecast steps.
            alpha: Miscoverage rate used during calibration.

        Returns:
            Populated :class:`IntervalResponse`.
        """
        forecasts = [
            IntervalPrediction(
                model=name,
                lower=lower.tolist(),
                forecast=fc.tolist(),
                upper=upper.tolist(),
                coverage=round(1.0 - alpha, 4),
                inference_time=inference_times.get(name, 0.0),
            )
            for name, (lower, fc, upper) in predictions.items()
        ]
        return cls(forecasts=forecasts, targets=targets, forecast_horizon=forecast_horizon)


class HealthResponse(BaseModel):
    """Health-check response.

    Args:
        status: ``"ok"`` when the service is ready.
        models: Names of loaded models.
        forecast_horizon: Configured forecast horizon.
        targets: Configured target variables.
    """

    status: Literal["ok", "degraded"] = Field(description="Service status.")
    models: list[str] = Field(description="Loaded model names.")
    forecast_horizon: int = Field(description="Configured forecast horizon.")
    targets: list[str] = Field(description="Configured target variable names.")


class MonitorResponse(BaseModel):
    """Response payload for a monitoring / drift report request.

    Args:
        drift_detected: Whether data drift was detected overall.
        n_drifted_features: Number of features that drifted.
        feature_drift: Per-feature drift scores.
        report_path: Path to the full HTML report on disk.
    """

    drift_detected: bool = Field(description="Overall drift flag.")
    n_drifted_features: int = Field(description="Number of drifted features.")
    feature_drift: dict[str, float] = Field(
        description="Per-feature drift score (higher = more drift).",
    )
    report_path: str | None = Field(
        default=None,
        description="Absolute path to the saved HTML drift report.",
    )
