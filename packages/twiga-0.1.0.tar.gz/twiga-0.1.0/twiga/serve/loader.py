"""Checkpoint loader for Twiga model serving.

Handles loading a fitted :class:`~twiga.forecaster.core.TwigaForecaster`
from a checkpoint directory at API startup time, keeping the heavy
deserialisation out of the request path.
"""

from __future__ import annotations

from pathlib import Path
import threading

from twiga.core.exceptions import NotFittedError
from twiga.core.utils.logger import get_logger
from twiga.forecaster.core import TwigaForecaster

log = get_logger(__name__)


class ModelLoader:
    """Lazy, thread-safe checkpoint loader for a :class:`~twiga.forecaster.core.TwigaForecaster`.

    The forecaster is deserialised from disk exactly once on first access and
    cached for the process lifetime.  A :class:`threading.Lock` ensures that
    concurrent requests from multiple threads (e.g. a Uvicorn worker with a
    thread pool) cannot trigger a double-load race.

    Args:
        forecaster: A pre-instantiated (but not yet loaded) forecaster whose
            ``checkpoints_path`` points to a valid checkpoint directory.

    Example::

        loader = ModelLoader(forecaster)
        forecaster = loader.load()  # loads once; subsequent calls are no-ops
        loader.reload()  # force reload from disk
    """

    def __init__(self, forecaster: TwigaForecaster) -> None:
        self._forecaster = forecaster
        self._loaded: bool = False
        self._lock: threading.Lock = threading.Lock()

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def load(self) -> TwigaForecaster:
        """Load the forecaster from its checkpoint directory.

        Idempotent and thread-safe - subsequent calls return the cached
        instance without re-reading from disk.

        Returns:
            The loaded :class:`~twiga.forecaster.core.TwigaForecaster`.

        Raises:
            NotFittedError: If no checkpoint files are found.
            ValueError: If ``checkpoints_path`` is not configured.
        """
        if not self._loaded:
            with self._lock:
                # Double-checked locking: re-test inside the lock so only one
                # thread performs the expensive deserialisation.
                if not self._loaded:
                    self._do_load()
                    self._loaded = True
        return self._forecaster

    def reload(self) -> TwigaForecaster:
        """Force a fresh load from disk, discarding the cached model.

        Useful for hot-reloading after a new model version has been promoted
        to the checkpoint directory.

        Returns:
            The freshly loaded :class:`~twiga.forecaster.core.TwigaForecaster`.

        Raises:
            NotFittedError: If no checkpoint files are found.
        """
        log.info("Reloading forecaster from checkpoint")
        with self._lock:
            self._loaded = False
            self._do_load()
            self._loaded = True
        return self._forecaster

    @property
    def is_loaded(self) -> bool:
        """``True`` if the forecaster has been successfully loaded."""
        return self._loaded

    @property
    def targets(self) -> list[str]:
        """Target variable names from the fitted data pipeline.

        Raises:
            NotFittedError: If the forecaster has not been loaded yet.
        """
        self._require_loaded()
        pipeline = self._forecaster.data_pipeline
        targets = pipeline.target_feature
        return targets if isinstance(targets, list) else [targets]

    @property
    def forecast_horizon(self) -> int:
        """Forecast horizon from the fitted data pipeline.

        Raises:
            NotFittedError: If the forecaster has not been loaded yet.
        """
        self._require_loaded()
        return self._forecaster.data_pipeline.forecast_horizon

    @property
    def model_names(self) -> list[str]:
        """Names of all loaded models.

        Raises:
            NotFittedError: If the forecaster has not been loaded yet.
        """
        self._require_loaded()
        return [m.model_type for m in self._forecaster.models]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _do_load(self) -> None:
        """Deserialise the checkpoint and mark loader as ready."""
        forecaster = self._forecaster

        if not hasattr(forecaster, "checkpoints_path") or not forecaster.checkpoints_path:
            raise ValueError(
                "forecaster.checkpoints_path is not set. "
                "Initialise the forecaster with a valid root_dir and project_name."
            )

        checkpoint_dir = Path(forecaster.checkpoints_path)
        if not checkpoint_dir.exists():
            raise NotFittedError(
                f"Checkpoint directory does not exist: {checkpoint_dir}. "
                "Train and save the forecaster before starting the API."
            )

        checkpoint_files = sorted(
            [f for f in checkpoint_dir.glob("*") if f.is_file()],
            key=lambda f: f.stat().st_mtime,
            reverse=True,
        )

        if not checkpoint_files:
            raise NotFittedError(
                f"No checkpoint files found in {checkpoint_dir}. Train the forecaster before starting the API."
            )

        log.info(
            "Loading forecaster from checkpoint  path=%s",
            checkpoint_files[0],
        )
        forecaster.on_load_checkpoint()
        self._loaded = True
        log.info(
            "Forecaster loaded  models=%s  horizon=%d  targets=%s",
            self.model_names,
            self.forecast_horizon,
            self.targets,
        )

    def _require_loaded(self) -> None:
        """Raise :exc:`~twiga.core.exceptions.NotFittedError` if not loaded."""
        if not self._loaded:
            raise NotFittedError("ModelLoader has not been loaded yet. Call loader.load() first.")
