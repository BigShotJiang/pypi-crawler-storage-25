"""FastAPI application factory for Twiga model serving.

Creates a production-ready REST API that exposes a fitted
:class:`~twiga.forecaster.core.TwigaForecaster` for point forecasting,
conformal interval forecasting, and production monitoring.

Authentication
--------------
All non-health endpoints require an ``X-API-Key`` header.  Set the key via
the ``TWIGA_SERVE_API_KEY`` environment variable (or the :class:`TwigaSettings`
``serve_api_key`` field).  If the variable is empty the server starts without
auth enforcement - **never run without a key in production**.

Async design
------------
CPU-bound prediction and Evidently monitoring calls run inside
:func:`anyio.to_thread.run_sync` so the event loop is never blocked.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
import math
from typing import Annotated, Any

import anyio
from fastapi import Depends, FastAPI, HTTPException, Request, Security, status
from fastapi.responses import JSONResponse
from fastapi.security import APIKeyHeader
import pandas as pd
from pydantic import BaseModel, Field

from twiga.core.data.processing import normalise_timestamp_column
from twiga.core.exceptions import NotFittedError
from twiga.core.utils.logger import get_logger, log_section
from twiga.forecaster.core import TwigaForecaster
from twiga.serve.loader import ModelLoader
from twiga.serve.monitor import ForecastMonitor
from twiga.serve.schemas import (
    ForecastRequest,
    ForecastResponse,
    HealthResponse,
    IntervalRequest,
    IntervalResponse,
    MonitorResponse,
)

log = get_logger(__name__)

__all__ = ["create_app", "get_forecaster"]

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

_API_KEY_HEADER = APIKeyHeader(name="X-API-Key", auto_error=False)


def _make_api_key_dep(expected_key: str | None):
    """Return a FastAPI dependency that enforces *expected_key* when set."""

    async def _check(key: str | None = Security(_API_KEY_HEADER)) -> None:
        if not expected_key:
            # No key configured - open access (dev/local mode).
            return
        if key != expected_key:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Invalid or missing API key.",
            )

    return _check


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class PerformanceResponse(BaseModel):
    """Evidently regression performance report.

    Attributes:
        mae: Mean Absolute Error.
        rmse: Root Mean Square Error.
        mape: Mean Absolute Percentage Error.
        report_path: Path to the generated HTML report on disk.
    """

    mae: float | None = Field(..., description="Mean Absolute Error")
    rmse: float | None = Field(..., description="Root Mean Square Error")
    mape: float | None = Field(..., description="Mean Absolute Percentage Error")
    report_path: str = Field(..., description="Path to saved HTML report")


class ReloadResponse(BaseModel):
    """Response for model reload endpoint.

    Attributes:
        status: The outcome of the reload operation.
        models: List of model identifiers currently loaded.
    """

    status: str = Field(..., description="Reload status (e.g., 'reloaded')")
    models: list[str] = Field(..., description="List of loaded model names")


# ---------------------------------------------------------------------------
# Dependency placeholder
# ---------------------------------------------------------------------------


def get_forecaster() -> TwigaForecaster:
    """FastAPI dependency placeholder for the TwigaForecaster.

    The actual implementation is injected via ``app.dependency_overrides``
    inside :func:`create_app`.

    Raises:
        NotImplementedError: If accessed before being overridden.
    """
    raise NotImplementedError("Forecaster dependency not initialized.")


ForecasterDep = Annotated[TwigaForecaster, Depends(get_forecaster)]


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------


def create_app(
    forecaster: TwigaForecaster,
    report_dir: str = "reports",
    title: str = "Twiga Forecast API",
    version: str = "0.1.0",
    api_key: str | None = None,
) -> FastAPI:
    """Create and configure the Twiga serving FastAPI application.

    Args:
        forecaster: Configured (fitted or loadable) forecaster instance.
        report_dir: Directory where monitoring reports are stored.
        title: Title shown in the OpenAPI docs.
        version: Semantic version string for the API.
        api_key: Secret key for ``X-API-Key`` auth.  Pass ``None`` to run
            without auth (development only).  Defaults to the value of the
            ``TWIGA_SERVE_API_KEY`` environment variable when not supplied.

    Returns:
        A configured :class:`fastapi.FastAPI` instance.
    """
    # Resolve API key: caller wins, else fall back to env var via settings.
    if api_key is None:
        try:
            from twiga.core.settings import TwigaSettings

            api_key = TwigaSettings().serve_api_key or None  # empty string → None
        except Exception:
            api_key = None

    auth_dep = _make_api_key_dep(api_key)

    loader = ModelLoader(forecaster)
    monitor = ForecastMonitor(report_dir=report_dir)

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
        log_section(log, "Twiga API Startup")
        try:
            await anyio.to_thread.run_sync(loader.load)
            await anyio.to_thread.run_sync(lambda: monitor.set_reference(_get_reference_data(loader)))
            log.info("Twiga Forecast API ready")
        except (NotFittedError, ValueError) as exc:
            log.exception("Failed to load model at startup: %s", exc)  # noqa: TRY401
            raise RuntimeError(f"API startup failed: {exc}") from exc
        yield
        log.info("Twiga Forecast API shutting down")

    app = FastAPI(
        title=title,
        version=version,
        description="REST API for Twiga point and probabilistic forecasting.",
        lifespan=lifespan,
    )

    app.dependency_overrides[get_forecaster] = lambda: loader.load()

    # ── Exception handlers ──────────────────────────────────────────────────

    @app.exception_handler(NotFittedError)
    async def not_fitted_handler(request: Request, exc: NotFittedError) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content={"detail": str(exc)},
        )

    @app.exception_handler(ValueError)
    async def value_error_handler(request: Request, exc: ValueError) -> JSONResponse:
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content={"detail": f"Data validation error: {exc!s}"},
        )

    # ── Endpoints ───────────────────────────────────────────────────────────

    @app.get("/health", response_model=HealthResponse, tags=["Ops"])
    async def health() -> HealthResponse:
        """Return the current health and configuration of the service."""
        service_status = "ok" if loader.is_loaded else "degraded"
        return HealthResponse(
            status=service_status,
            models=loader.model_names if loader.is_loaded else [],
            forecast_horizon=loader.forecast_horizon if loader.is_loaded else 0,
            targets=loader.targets if loader.is_loaded else [],
        )

    @app.post(
        "/predict",
        response_model=ForecastResponse,
        tags=["Forecast"],
        dependencies=[Depends(auth_dep)],
    )
    async def predict(request: ForecastRequest, fc: ForecasterDep) -> ForecastResponse:
        """Generate point forecasts for the provided input records."""
        df = _records_to_df(request.records, date_col=fc.data_pipeline.date_column)
        log.info("POST /predict rows=%d strategy=%s", len(df), request.ensemble_strategy)

        try:
            predictions, inference_times = await anyio.to_thread.run_sync(
                lambda: fc.predict(
                    df,
                    ensemble_strategy=request.ensemble_strategy,
                    prepare_test_data=request.prepare_test_data,
                )
            )
        except Exception as exc:
            log.exception("Prediction failed")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Prediction failed: {exc}",
            ) from exc

        return ForecastResponse.from_arrays(
            predictions=predictions,
            inference_times=inference_times,
            targets=loader.targets,
            forecast_horizon=loader.forecast_horizon,
        )

    @app.post(
        "/predict-interval",
        response_model=IntervalResponse,
        tags=["Forecast"],
        dependencies=[Depends(auth_dep)],
    )
    async def predict_interval(request: IntervalRequest, fc: ForecasterDep) -> IntervalResponse:
        """Generate conformal prediction intervals."""
        df = _records_to_df(request.records, date_col=fc.data_pipeline.date_column)
        log.info("POST /predict-interval rows=%d", len(df))

        try:
            predictions, inference_times = await anyio.to_thread.run_sync(
                lambda: fc.predict_interval(
                    df,
                    ensemble_strategy=request.ensemble_strategy,
                    prepare_test_data=request.prepare_test_data,
                )
            )
        except Exception as exc:
            log.exception("Interval prediction failed")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Interval prediction failed: {exc}",
            ) from exc

        return IntervalResponse.from_arrays(
            predictions=predictions,
            inference_times=inference_times,
            targets=loader.targets,
            forecast_horizon=loader.forecast_horizon,
            alpha=request.alpha,
        )

    @app.post(
        "/monitor/drift",
        response_model=MonitorResponse,
        tags=["Monitor"],
        dependencies=[Depends(auth_dep)],
    )
    async def monitor_drift(request: ForecastRequest) -> MonitorResponse:
        """Analyse data drift between reference and production data."""
        df = _records_to_df(request.records)
        try:
            _is_alert, summary = await anyio.to_thread.run_sync(lambda: monitor.run_data_drift(df))
        except Exception as exc:
            log.exception("Drift monitoring failed")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=str(exc),
            ) from exc

        return MonitorResponse(
            drift_detected=summary.get("drift_detected", False),
            n_drifted_features=summary.get("n_drifted", 0),
            feature_drift=summary.get("feature_drift", {}),
            report_path=summary.get("report_path"),
        )

    @app.post(
        "/monitor/performance",
        response_model=PerformanceResponse,
        tags=["Monitor"],
        dependencies=[Depends(auth_dep)],
    )
    async def monitor_performance(request: ForecastRequest) -> PerformanceResponse:
        """Evaluate model performance metrics against ground truth."""
        df = _records_to_df(request.records)
        try:
            summary = await anyio.to_thread.run_sync(lambda: monitor.run_performance(df))
        except KeyError as exc:
            raise ValueError(f"Missing expected column for evaluation: {exc}") from exc
        except Exception as exc:
            log.exception("Performance monitoring failed")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=str(exc),
            ) from exc

        # Guard NaN / Infinity before JSON serialisation
        clean = {
            k: (None if isinstance(v, float) and (math.isnan(v) or math.isinf(v)) else v) for k, v in summary.items()
        }
        return PerformanceResponse(**clean)

    @app.post(
        "/reload",
        response_model=ReloadResponse,
        tags=["Ops"],
        dependencies=[Depends(auth_dep)],
    )
    async def reload_model() -> ReloadResponse:
        """Reload the model from the configured checkpoint path."""
        log.info("POST /reload - reloading model checkpoint")
        try:
            await anyio.to_thread.run_sync(loader.reload)
            await anyio.to_thread.run_sync(lambda: monitor.set_reference(_get_reference_data(loader)))
        except (NotFittedError, ValueError) as exc:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=f"Reload failed: {exc}",
            ) from exc

        return ReloadResponse(status="reloaded", models=loader.model_names)

    return app


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _records_to_df(records: list[dict[str, Any]], date_col: str = "timestamp") -> pd.DataFrame:
    """Convert a list of row-dicts to a pandas DataFrame with normalised timestamps.

    Args:
        records: List of dicts representing time-series observations.
        date_col: Name of the datetime column to parse. Defaults to ``"timestamp"``.

    Returns:
        DataFrame with the date column as tz-naive ``datetime64[ns]`` (when present).

    Raises:
        ValueError: If the timestamp column cannot be parsed as datetime.
    """
    df = pd.DataFrame(records)
    # Resolve the column to parse: prefer the caller's date_col when it is a
    # string that exists in the DataFrame; otherwise fall back to "timestamp".
    col: str | None = None
    if isinstance(date_col, str) and date_col in df.columns:
        col = date_col
    elif "timestamp" in df.columns:
        col = "timestamp"
    if col is not None:
        df = normalise_timestamp_column(df, col)
    return df


def _get_reference_data(loader: ModelLoader) -> pd.DataFrame:
    """Extract reference data from the loaded forecaster data pipeline.

    Args:
        loader: Initialised :class:`ModelLoader`.

    Returns:
        Copy of the reference DataFrame, or an empty DataFrame if unavailable.
    """
    try:
        fc = loader.load()
        pipeline = fc.data_pipeline
        if hasattr(pipeline, "data") and pipeline.data is not None:
            return pipeline.data.copy()
    except (AttributeError, TypeError, ValueError) as exc:
        log.warning("Could not extract reference data from pipeline: %s", exc)
    return pd.DataFrame()
