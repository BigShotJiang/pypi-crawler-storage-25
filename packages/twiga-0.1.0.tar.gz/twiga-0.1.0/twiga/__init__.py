"""Twiga - point and probabilistic time series forecasting.

Public API
----------
The symbols exported here are the **stable public API**.  Everything else
(submodules, internal helpers, model classes) may change without notice.

Stable
~~~~~~
- :class:`TwigaForecaster`          - main entry point
- :class:`DataPipelineConfig`       - data pipeline configuration
- :class:`ForecasterConfig`         - training configuration
- :class:`BaseModelConfig`          - base model configuration
- :class:`ConformalConfig`          - conformal prediction configuration
- :func:`get_model`                 - registry lookup by name
- :func:`evaluate_forecast`         - evaluation helper

Experimental (may change in minor versions)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- :class:`BaseMLPConfig`, :class:`NeuralModelConfig`, :class:`BaseSearchSpace`
- :class:`ForecastResult`, :class:`ForecastCollection`, :class:`ForecastKind`

Optional submodule imports
~~~~~~~~~~~~~~~~~~~~~~~~~~
Tree-boosting models require ``pip install 'twiga[gbtree]'``::

    from twiga.models.ml import LIGHTGBMConfig, LIGHTGBMModel

Neural network models require ``pip install 'twiga[nn]'``::

    from twiga.models.nn import MLPFConfig, MLPFModel

SHAP explainability requires ``pip install 'twiga[explain]'``::

    from twiga.core.explain import ShapExplainer

Plotting requires ``pip install 'twiga[plots]'``::

    from twiga.core.plot import plot_forecast
"""

from importlib.metadata import PackageNotFoundError, version

from twiga.core.config import (
    BaseMLPConfig,
    BaseModelConfig,
    BaseSearchSpace,
    ConformalConfig,
    DataPipelineConfig,
    ForecasterConfig,
    NeuralModelConfig,
)
from twiga.core.exceptions import (
    ConfigurationError,
    MissingExtraError,
    NotFittedError,
    PipelineError,
    TwigaError,
    require_extra,
)
from twiga.core.metrics import evaluate_forecast
from twiga.core.utils import configure, get_logger
from twiga.forecaster.core import TwigaForecaster
from twiga.forecaster.registry import get_model
from twiga.forecaster.result import ForecastCollection, ForecastKind, ForecastResult

__all__ = [
    # ── Stable public API ──────────────────────────────────────────────────
    # Main entry point
    "TwigaForecaster",
    # Configuration
    "DataPipelineConfig",
    "ForecasterConfig",
    "BaseModelConfig",
    "ConformalConfig",
    # Registry
    "get_model",
    # Evaluation
    "evaluate_forecast",
    # Exceptions
    "TwigaError",
    "ConfigurationError",
    "MissingExtraError",
    "NotFittedError",
    "PipelineError",
    "require_extra",
    # Logging
    "configure",
    "get_logger",
    # ── Experimental ──────────────────────────────────────────────────────
    "BaseMLPConfig",
    "BaseSearchSpace",
    "NeuralModelConfig",
    "ForecastCollection",
    "ForecastKind",
    "ForecastResult",
]

try:
    __version__ = version("twiga")
except PackageNotFoundError:
    __version__ = "0.0.1"
