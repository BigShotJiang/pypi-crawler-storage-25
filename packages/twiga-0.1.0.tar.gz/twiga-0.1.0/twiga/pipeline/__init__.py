"""Twiga Prefect pipeline orchestration.

Provides Prefect tasks and flows for training, evaluation, retraining,
and scheduled inference - closing the MLOps loop between model development
and production deployment.

Quickstart::

    from twiga.pipeline import training_flow, retraining_flow

    # Run a training flow locally
    training_flow(
        data_path="data/load.parquet",
        checkpoint_dir="checkpoints/",
        experiment="load-forecast",
    )
"""

from __future__ import annotations

from twiga.pipeline.schemas import DriftSummary, RetrainingResult, TrainingResult
from twiga.pipeline.tasks import (
    evaluate_model,
    fit_forecaster,
    load_data,
    run_drift_check,
    save_checkpoint,
)

__all__ = [
    # Flows (lazy - imported only when accessed to avoid early Prefect decorator application)
    "training_flow",
    "retraining_flow",
    # Schemas
    "TrainingResult",
    "RetrainingResult",
    "DriftSummary",
    # Tasks
    "load_data",
    "fit_forecaster",
    "evaluate_model",
    "save_checkpoint",
    "run_drift_check",
]


def __getattr__(name: str):
    if name in ("training_flow", "retraining_flow"):
        from twiga.pipeline import flows as _flows  # noqa: PLC0415

        return getattr(_flows, name)
    raise AttributeError(f"module 'twiga.pipeline' has no attribute {name!r}")
