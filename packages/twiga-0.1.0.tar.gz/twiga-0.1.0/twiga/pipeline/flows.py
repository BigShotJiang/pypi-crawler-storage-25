"""Prefect flows for Twiga MLOps pipelines.

Provides two top-level flows:

- :func:`training_flow` - full train → evaluate → checkpoint → MLflow cycle.
- :func:`retraining_flow` - drift-triggered retrain with promotion logic.

Both flows are composable and can be scheduled via Prefect deployments or
triggered manually from Python.
"""

from __future__ import annotations

from pathlib import Path
from uuid import uuid4

import pandas as pd
from prefect import flow, get_run_logger
from prefect.artifacts import create_markdown_artifact
from prefect.blocks.system import Secret
from prefect.exceptions import PrefectException
import requests

from twiga.core.exceptions import NotFittedError
from twiga.core.utils.logger import get_logger, log_section
from twiga.forecaster.core import TwigaForecaster
from twiga.pipeline.schemas import DriftSummary, RetrainingResult, TrainingResult
from twiga.pipeline.tasks import (
    decide_retrain,
    evaluate_model,
    fit_forecaster,
    load_data,
    log_to_mlflow,
    run_drift_check,
    save_checkpoint,
)
from twiga.tracking.tracker import TwigaTracker

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_metrics_summary(metrics_df: pd.DataFrame) -> dict[str, dict[str, float]]:
    """Aggregate a Twiga metrics DataFrame into a flat summary dict.

    Args:
        metrics_df: DataFrame returned by ``evaluate_model``.

    Returns:
        Nested dict of ``{model: {metric: value}}``.
    """
    summary: dict[str, dict[str, float]] = {}
    numeric_cols = metrics_df.select_dtypes("number").columns.tolist()
    group_col = "Model" if "Model" in metrics_df.columns else None

    if group_col:
        for model, grp in metrics_df.groupby(group_col):
            summary[str(model)] = {col: round(float(grp[col].mean()), 6) for col in numeric_cols}
    else:
        summary["model"] = {col: round(float(metrics_df[col].mean()), 6) for col in numeric_cols}

    return summary


def _publish_metrics_artifact(
    metrics_summary: dict[str, dict[str, float]],
    run_label: str,
    artifact_key_prefix: str = "evaluation-metrics",
) -> None:
    """Publish a Markdown metrics table as a Prefect artifact with a unique key.

    Args:
        metrics_summary: Nested ``{model: {metric: value}}`` dict.
        run_label: Human-readable label for the artifact.
        artifact_key_prefix: Base key; full key becomes ``{prefix}-{run_label}``.
    """
    safe_label = run_label.replace(" ", "-").replace("_", "-").lower()[:50]
    if not safe_label:
        safe_label = str(uuid4())[:8]
    artifact_key = f"{artifact_key_prefix}-{safe_label}"

    lines = [
        f"## Twiga Evaluation Metrics - {run_label}\n",
        "| Model | Metric | Value |",
        "|-------|--------|-------|",
    ]
    for model, model_metrics in metrics_summary.items():
        for metric, value in model_metrics.items():
            lines.append(f"| {model} | {metric} | {value:.4f} |")

    create_markdown_artifact(
        key=artifact_key,
        markdown="\n".join(lines),
        description=f"Evaluation metrics for run: {run_label}",
    )


# ---------------------------------------------------------------------------
# Training Flow
# ---------------------------------------------------------------------------


@flow(name="twiga-training", log_prints=True)
def training_flow(
    forecaster: TwigaForecaster,
    data_path: str | Path,
    date_col: str = "timestamp",
    train_end: str | None = None,
    test_start: str | None = None,
    tune: bool = False,
    num_trials: int = 20,
    ensemble_strategy: str | None = None,
    experiment: str = "twiga",
    run_name: str | None = None,
    tags: dict[str, str] | None = None,
    report_dir: str | Path = "reports",
) -> TrainingResult:
    """Full training pipeline: load → fit → evaluate → checkpoint → MLflow.

    Args:
        forecaster: Configured (unfitted) forecaster instance.
        data_path: Path to the dataset file (``.parquet`` or ``.csv``).
        date_col: Name of the timestamp column in the dataset.
        train_end: Inclusive end date for the training split (``YYYY-MM-DD``).
        test_start: Inclusive start date for the test split (``YYYY-MM-DD``).
        tune: If ``True``, run Optuna HPO before the final fit.
        num_trials: Number of Optuna trials (used when ``tune=True``).
        ensemble_strategy: Ensemble aggregation strategy for evaluation.
        experiment: MLflow experiment name.
        run_name: Human-readable MLflow run label.
        tags: Optional MLflow tags dict.
        report_dir: Directory for Evidently HTML reports.

    Returns:
        :class:`~twiga.pipeline.schemas.TrainingResult` with ``checkpoint_path``,
        ``mlflow_run_id``, and ``metrics``.
    """
    prefect_log = get_run_logger()
    log_section(log, "Twiga Training Flow")

    train_df, test_df = load_data(
        data_path=data_path,
        date_col=date_col,
        train_end=train_end,
        test_start=test_start,
    )

    fitted_forecaster = fit_forecaster(
        forecaster=forecaster,
        train_df=train_df,
        tune=tune,
        num_trials=num_trials,
    )

    predictions_df, metrics_df = evaluate_model(
        forecaster=fitted_forecaster,
        test_df=test_df,
        ensemble_strategy=ensemble_strategy,
    )

    checkpoint_path = save_checkpoint(forecaster=fitted_forecaster)

    mlflow_run_id = log_to_mlflow(
        forecaster=fitted_forecaster,
        metrics_df=metrics_df,
        predictions_df=predictions_df,
        experiment=experiment,
        run_name=run_name,
        tags=tags,
    )

    metrics_summary = _build_metrics_summary(metrics_df)
    _publish_metrics_artifact(metrics_summary, run_name or experiment)

    prefect_log.info(
        "Training flow complete | checkpoint=%s | mlflow_run=%s",
        checkpoint_path,
        mlflow_run_id,
    )

    return TrainingResult(
        checkpoint_path=checkpoint_path,
        mlflow_run_id=mlflow_run_id,
        metrics=metrics_summary,
    )


# ---------------------------------------------------------------------------
# Retraining Flow
# ---------------------------------------------------------------------------


@flow(name="twiga-retraining", log_prints=True)
def retraining_flow(
    forecaster: TwigaForecaster,
    reference_data_path: str | Path,
    current_data_path: str | Path,
    date_col: str = "timestamp",
    train_end: str | None = None,
    test_start: str | None = None,
    drift_threshold: float = 0.5,
    performance_threshold: float | None = None,
    metric_key: str = "mae",
    minimize: bool = True,
    tune: bool = False,
    num_trials: int = 20,
    ensemble_strategy: str | None = None,
    experiment: str = "twiga-retrain",
    run_name: str | None = None,
    tags: dict[str, str] | None = None,
    report_dir: str | Path = "reports",
    fastapi_reload_url: str | None = None,
    fastapi_reload_api_key_secret: str | None = None,
) -> RetrainingResult:
    """Drift-aware retraining flow: check → retrain → promote if better.

    Args:
        forecaster: Configured (unfitted) forecaster. The current checkpoint
            is loaded for baseline evaluation before retraining.
        reference_data_path: Path to the reference (historical) dataset.
        current_data_path: Path to the current production data window.
        date_col: Timestamp column name.
        train_end: End date for the training split of current data.
        test_start: Start date for the test split of current data.
        drift_threshold: Fraction of drifted features that triggers retrain.
        performance_threshold: Optional absolute metric threshold that also
            triggers retraining.
        metric_key: Metric column used for performance comparison.
        minimize: If ``True``, lower metric is better (e.g. MAE, RMSE).
        tune: Run HPO during retraining.
        num_trials: HPO trial budget.
        ensemble_strategy: Ensemble strategy for evaluation.
        experiment: MLflow experiment name.
        run_name: MLflow run label.
        tags: MLflow tags dict.
        report_dir: Directory for Evidently HTML reports.
        fastapi_reload_url: Optional webhook URL to hot-reload the API after
            model promotion (e.g. ``"http://api:8000"``).
        fastapi_reload_api_key_secret: Name of a Prefect Secret holding the
            ``X-API-Key`` value for the reload webhook.

    Returns:
        :class:`~twiga.pipeline.schemas.RetrainingResult` with full decision
        context: ``retrained``, ``promoted``, ``drift_summary``,
        ``checkpoint_path``, ``mlflow_run_id``, and ``metrics``.
    """
    prefect_log = get_run_logger()
    log_section(log, "Twiga Retraining Flow")

    # 1. Load reference and current data
    ref_train, ref_test = load_data(
        data_path=reference_data_path,
        date_col=date_col,
        train_end=None,
        test_start=None,
    )
    cur_train, cur_test = load_data(
        data_path=current_data_path,
        date_col=date_col,
        train_end=train_end,
        test_start=test_start,
    )

    # 2. Drift check
    drift_raw = run_drift_check(
        reference_df=ref_train,
        current_df=cur_train,
        report_dir=report_dir,
    )
    drift_summary = DriftSummary.from_dict(drift_raw)

    # 3. Evaluate incumbent model
    # Distinguish "no checkpoint yet" (expected on first run) from unexpected errors.
    incumbent_metric: float | None = None
    try:
        forecaster.on_load_checkpoint()
        # If on_load_checkpoint returned without loading a model the forecaster
        # is still unfitted - treat as "no incumbent".
        if forecaster.model is None:
            prefect_log.info("No incumbent checkpoint found - first run, retraining unconditionally.")
        else:
            _, incumbent_metrics_df = evaluate_model(
                forecaster=forecaster,
                test_df=ref_test,
                ensemble_strategy=ensemble_strategy,
            )
            if metric_key in incumbent_metrics_df.columns:
                incumbent_metric = float(incumbent_metrics_df[metric_key].mean())
                prefect_log.info("Incumbent %s = %.4f", metric_key, incumbent_metric)
            else:
                prefect_log.warning(
                    "Metric key %r not found in incumbent evaluation - treating as no incumbent.",
                    metric_key,
                )
    except (NotFittedError, ValueError) as exc:
        # Expected: checkpoint dir missing or empty on a first run.
        prefect_log.info("No incumbent model available (%s) - will retrain.", exc)
    except Exception as exc:
        # Unexpected: corrupted checkpoint, pipeline error, etc.
        prefect_log.warning(
            "Unexpected error evaluating incumbent model: %s - assuming retrain needed.",
            exc,
        )

    # 4. Decision
    should_retrain = decide_retrain(
        drift_summary=drift_raw,
        incumbent_metric=incumbent_metric,
        drift_threshold=drift_threshold,
        performance_threshold=performance_threshold,
        minimize=minimize,
    )

    if not should_retrain:
        prefect_log.info("No retraining triggered - incumbent model is healthy")
        return RetrainingResult(
            retrained=False,
            promoted=False,
            drift_summary=drift_summary,
        )

    prefect_log.info("Retraining triggered - fitting new model on current data")

    # 5. Retrain under a TwigaTracker MLflow run
    with TwigaTracker(experiment=experiment, run_name=run_name, tags=tags) as tracker:
        tracker._send_to_mlflow(
            {
                "drift_score": drift_summary.dataset_drift_score,
                "n_drifted": drift_summary.n_drifted,
                "drift_threshold": drift_threshold,
            }
        )

        new_forecaster = fit_forecaster(
            forecaster=forecaster,
            train_df=cur_train,
            tune=tune,
            num_trials=num_trials,
        )

        new_predictions, new_metrics_df = evaluate_model(
            forecaster=new_forecaster,
            test_df=cur_test,
            ensemble_strategy=ensemble_strategy,
        )

        new_metric: float | None = None
        if metric_key in new_metrics_df.columns:
            new_metric = float(new_metrics_df[metric_key].mean())
            prefect_log.info("New model %s = %.4f", metric_key, new_metric)

        # Promotion: new model wins only if it beats the incumbent.
        promoted = False
        if incumbent_metric is None:
            promoted = True
        elif new_metric is not None:
            promoted = new_metric < incumbent_metric if minimize else new_metric > incumbent_metric

        checkpoint_path: str | None = None
        mlflow_run_id: str | None = None
        metrics_summary: dict[str, dict[str, float]] | None = None

        if promoted:
            prefect_log.info(
                "New model promoted | %s: %.4f → %.4f",
                metric_key,
                incumbent_metric if incumbent_metric is not None else float("nan"),
                new_metric if new_metric is not None else float("nan"),
            )
            checkpoint_path = save_checkpoint(forecaster=new_forecaster)
            tracker.log_forecaster_metadata(new_forecaster)
            if new_forecaster.data_pipeline and new_forecaster.data_pipeline.data is not None:
                tracker.log_model(new_forecaster, sample_input=new_forecaster.data_pipeline.data)
            tracker.log_evaluation(new_metrics_df, results_df=new_predictions)
            metrics_summary = _build_metrics_summary(new_metrics_df)
            _publish_metrics_artifact(metrics_summary, run_name or experiment)

            # Optional FastAPI hot-reload webhook
            if fastapi_reload_url:
                _trigger_api_reload(fastapi_reload_url, fastapi_reload_api_key_secret, prefect_log)

            mlflow_run_id = tracker.run_id
        else:
            prefect_log.info(
                "New model NOT promoted | incumbent %s = %.4f vs new = %.4f",
                metric_key,
                incumbent_metric,
                new_metric,
            )

    return RetrainingResult(
        retrained=True,
        promoted=promoted,
        drift_summary=drift_summary,
        checkpoint_path=checkpoint_path,
        mlflow_run_id=mlflow_run_id,
        metrics=metrics_summary,
    )


# ---------------------------------------------------------------------------
# Webhook helper
# ---------------------------------------------------------------------------


def _trigger_api_reload(
    reload_url: str,
    api_key_secret: str | None,
    prefect_log: object,
) -> None:
    """POST to the FastAPI ``/reload`` endpoint after model promotion.

    Logs a warning on failure so that a broken webhook does not surface as an
    unhandled exception inside the retraining flow.

    Args:
        reload_url: Base URL of the serving API (e.g. ``"http://api:8000"``).
        api_key_secret: Optional name of a Prefect Secret containing the
            ``X-API-Key`` value.
        prefect_log: Prefect run logger (duck-typed, uses ``.info`` / ``.warning``).
    """
    headers: dict[str, str] = {}
    if api_key_secret:
        try:
            secret_block = Secret.load(api_key_secret)
            headers["X-API-Key"] = secret_block.get()
        except PrefectException:
            prefect_log.warning(  # type: ignore[union-attr]
                "Prefect Secret %r not found; sending reload without API key.", api_key_secret
            )

    try:
        resp = requests.post(f"{reload_url}/reload", headers=headers, timeout=5)
        resp.raise_for_status()
        prefect_log.info("FastAPI reload triggered successfully")  # type: ignore[union-attr]
    except Exception as exc:
        prefect_log.warning("Failed to trigger FastAPI reload: %s", exc)  # type: ignore[union-attr]
