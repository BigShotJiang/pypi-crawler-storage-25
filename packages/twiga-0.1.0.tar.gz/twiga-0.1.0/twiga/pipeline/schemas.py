"""Typed result containers for Twiga pipeline flows.

Replaces the untyped ``dict[str, Any]`` return values from
:func:`~twiga.pipeline.flows.training_flow` and
:func:`~twiga.pipeline.flows.retraining_flow` with explicit dataclasses,
giving callers IDE support, static type checking, and clear contracts.

Example::

    result: TrainingResult = training_flow(forecaster, data_path="data.parquet")
    print(result.mlflow_run_id)
    print(result.metrics["lgbm"]["mae"])
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = ["DriftSummary", "RetrainingResult", "TrainingResult"]


@dataclass
class DriftSummary:
    """Evidently drift report summary produced by the ``run-drift-check`` task.

    Attributes:
        drift_detected: ``True`` when at least one feature drifted.
        dataset_drift_score: Fraction of features that drifted (0..1).
        n_drifted: Number of drifted features.
        total: Total number of monitored features.
        feature_drift: Per-feature drift scores keyed by column name.
        report_path: Absolute path to the saved HTML report (or ``None``).
        timestamp: ISO-8601 timestamp when the report was generated.
    """

    drift_detected: bool = False
    dataset_drift_score: float = 0.0
    n_drifted: int = 0
    total: int = 0
    feature_drift: dict[str, float] = field(default_factory=dict)
    report_path: str | None = None
    timestamp: str = ""

    @classmethod
    def from_dict(cls, d: dict) -> DriftSummary:
        """Build from the raw dict returned by :func:`~twiga.pipeline.tasks.run_drift_check`.

        Unknown keys in *d* are silently ignored so the schema can evolve
        without breaking callers that still pass raw dicts.
        """
        return cls(
            drift_detected=d.get("drift_detected", False),
            dataset_drift_score=d.get("dataset_drift_score", 0.0),
            n_drifted=d.get("n_drifted", 0),
            total=d.get("total", 0),
            feature_drift=d.get("feature_drift", {}),
            report_path=d.get("report_path"),
            timestamp=d.get("timestamp", ""),
        )


@dataclass
class TrainingResult:
    """Typed output of :func:`~twiga.pipeline.flows.training_flow`.

    Attributes:
        checkpoint_path: Absolute path to the saved checkpoint directory.
        mlflow_run_id: MLflow run ID for the training run.
        metrics: Aggregated evaluation metrics keyed by model name, then
            metric name. Example: ``{"lgbm": {"mae": 0.12, "rmse": 0.18}}``.
    """

    checkpoint_path: str
    mlflow_run_id: str
    metrics: dict[str, dict[str, float]] = field(default_factory=dict)


@dataclass
class RetrainingResult:
    """Typed output of :func:`~twiga.pipeline.flows.retraining_flow`.

    Attributes:
        retrained: Whether a new model was trained in this run.
        promoted: Whether the new model replaced the incumbent.
        drift_summary: Structured Evidently drift report.
        checkpoint_path: Path to the new checkpoint (``None`` if not promoted).
        mlflow_run_id: MLflow run ID for the retraining run (``None`` if not
            retrained or not promoted).
        metrics: Aggregated evaluation metrics for the new model (``None`` if
            not promoted).
    """

    retrained: bool
    promoted: bool
    drift_summary: DriftSummary
    checkpoint_path: str | None = None
    mlflow_run_id: str | None = None
    metrics: dict[str, dict[str, float]] | None = None
