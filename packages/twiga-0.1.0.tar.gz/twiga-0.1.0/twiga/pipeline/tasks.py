"""Prefect tasks for Twiga MLOps pipeline steps.

Each task is atomic, retryable, cacheable, and focused on a single responsibility.
Designed for Prefect 3.x with proper observability and resilience.
"""

from __future__ import annotations

from datetime import timedelta
from pathlib import Path
from typing import Any

import mlflow
import pandas as pd
from prefect import get_run_logger, task
from prefect.artifacts import create_markdown_artifact
from prefect.tasks import task_input_hash

from twiga.core.data.processing import normalise_timestamp_column
from twiga.core.utils.logger import get_logger
from twiga.forecaster.core import TwigaForecaster
from twiga.serve.monitor import ForecastMonitor

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Data Tasks
# ---------------------------------------------------------------------------


@task(
    name="load-data",
    retries=3,
    retry_delay_seconds=30,
    cache_key_fn=task_input_hash,
    cache_expiration=timedelta(hours=1),
    persist_result=True,  # Persist result for better UI visibility & debugging
)
def load_data(
    data_path: str | Path,
    date_col: str = "timestamp",
    train_end: str | None = None,
    test_start: str | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Load and split a time series dataset into train/test splits.

    Args:
        data_path: Path to the dataset file (``.parquet``, ``.csv``, or ``.tsv``).
        date_col: Name of the timestamp column.
        train_end: Inclusive end date for the training split (``YYYY-MM-DD``).
            If `None`, 80% of data is used for training.
        test_start: Inclusive start date for the test split (``YYYY-MM-DD``).
            If `None`, the remaining 20% is used.

    Returns:
        Tuple of (train_df, test_df) DataFrames.

    Raises:
        FileNotFoundError: If the data file does not exist.
        ValueError: If the file format is unsupported or the date column is missing.
    """
    prefect_log = get_run_logger()
    path = Path(data_path)

    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")

    prefect_log.info("Loading dataset from %s", path)

    if path.suffix == ".parquet":
        df = pd.read_parquet(path)
    elif path.suffix in {".csv", ".tsv"}:
        df = pd.read_csv(path)
    else:
        raise ValueError(f"Unsupported file format: {path.suffix}")

    if date_col not in df.columns:
        raise ValueError(f"Date column '{date_col}' not found.")

    df = normalise_timestamp_column(df, date_col)
    df = df.sort_values(date_col).reset_index(drop=True)

    if train_end and test_start:
        train_df = df[df[date_col] <= pd.to_datetime(train_end)].copy()
        test_df = df[df[date_col] >= pd.to_datetime(test_start)].copy()
    else:
        split_idx = int(len(df) * 0.8)
        train_df = df.iloc[:split_idx].copy()
        test_df = df.iloc[split_idx:].copy()

    prefect_log.info("Data loaded → train=%d rows, test=%d rows", len(train_df), len(test_df))
    return train_df, test_df


# ---------------------------------------------------------------------------
# Training Tasks
# ---------------------------------------------------------------------------


@task(name="fit-forecaster", retries=2, retry_delay_seconds=60)
def fit_forecaster(
    forecaster: TwigaForecaster,
    train_df: pd.DataFrame,
    val_df: pd.DataFrame | None = None,
    tune: bool = False,
    num_trials: int = 20,
) -> TwigaForecaster:
    """Fit (or tune + fit) the Twiga forecaster.

    Args:
        forecaster: Configured but unfitted forecaster instance.
        train_df: Training DataFrame.
        val_df: Optional validation DataFrame for early stopping.
        tune: If True, run Optuna hyperparameter tuning before the final fit.
        num_trials: Number of Optuna trials (used only when tune=True).

    Returns:
        The fitted TwigaForecaster.
    """
    prefect_log = get_run_logger()
    prefect_log.info("Fitting forecaster | tune=%s | trials=%d", tune, num_trials)

    if tune:
        prefect_log.info("Running hyperparameter tuning...")
        forecaster.tune(train_df, val_df, num_trials=num_trials)

    forecaster.fit(train_df, val_df)
    prefect_log.info("Forecaster fitted successfully")
    return forecaster


@task(name="evaluate-model")
def evaluate_model(
    forecaster: TwigaForecaster,
    test_df: pd.DataFrame,
    ensemble_strategy: str | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Evaluate a fitted forecaster on test data.

    Args:
        forecaster: Fitted TwigaForecaster.
        test_df: Test DataFrame.
        ensemble_strategy: Optional ensemble aggregation strategy.

    Returns:
        Tuple of (predictions_df, metrics_df) as returned by the forecaster.
    """
    prefect_log = get_run_logger()
    prefect_log.info("Evaluating on %d test rows", len(test_df))

    predictions_df, metrics_df = forecaster.evaluate(test_df, ensemble_strategy=ensemble_strategy)

    for _, row in metrics_df.iterrows():
        model = row.get("Model", "unknown")
        mae = row.get("mae", float("nan"))
        rmse = row.get("rmse", float("nan"))
        prefect_log.info("Model=%s | MAE=%.4f | RMSE=%.4f", model, mae, rmse)

    return predictions_df, metrics_df


@task(name="save-checkpoint", retries=2, retry_delay_seconds=30)
def save_checkpoint(forecaster: TwigaForecaster) -> str:
    """Save the fitted forecaster checkpoint to disk.

    Args:
        forecaster: Fitted TwigaForecaster.

    Returns:
        Absolute path to the checkpoint directory.

    Raises:
        RuntimeError: If the checkpoint path is not configured.
    """
    prefect_log = get_run_logger()

    if not hasattr(forecaster, "checkpoints_path") or not forecaster.checkpoints_path:
        raise RuntimeError(
            "forecaster.checkpoints_path is not configured. "
            "Ensure the forecaster was initialised with a valid root_dir."
        )

    path = forecaster.on_save_checkpoint()
    prefect_log.info("Checkpoint saved → %s", path)
    return path


# ---------------------------------------------------------------------------
# Monitoring Tasks
# ---------------------------------------------------------------------------


@task(name="run-drift-check", retries=2, retry_delay_seconds=30)
def run_drift_check(
    reference_df: pd.DataFrame,
    current_df: pd.DataFrame,
    report_dir: str | Path = "reports",
    feature_cols: list[str] | None = None,
) -> dict[str, Any]:
    """Run an Evidently data drift check and publish a Prefect artifact.

    Args:
        reference_df: Training reference DataFrame.
        current_df: Current production data window.
        report_dir: Directory for saving the HTML report.
        feature_cols: Subset of features to include. Defaults to all shared numeric columns.

    Returns:
        Drift summary dict with keys: drift_detected, dataset_drift_score,
        n_drifted, total, feature_drift, report_path, timestamp.
    """
    prefect_log = get_run_logger()
    prefect_log.info(
        "Running drift check | ref=%d rows | cur=%d rows",
        len(reference_df),
        len(current_df),
    )

    monitor = ForecastMonitor(report_dir=report_dir)
    monitor.set_reference(reference_df)

    is_alert, summary = monitor.run_data_drift(current_df, feature_cols=feature_cols)

    # Log drift metrics to MLflow if an active run exists
    if mlflow.active_run():
        mlflow.log_metrics(
            {
                "drift_score": summary.get("dataset_drift_score", 0.0),
                "n_drifted_features": summary.get("n_drifted", 0),
            }
        )
        mlflow.log_param("drift_alert", is_alert)

    # Create a Prefect artifact for UI visibility
    create_markdown_artifact(
        key="drift-report",
        markdown=f"""### Drift Check Summary
- **Drift Detected**: {summary.get("drift_detected", False)}
- **Drift Score**: {summary.get("dataset_drift_score", 0.0):.4f}
- **Drifted Features**: {summary.get("n_drifted", 0)} / {summary.get("total", 0)}
- **Report Path**: {summary.get("report_path", "N/A")}
""",
        description="Evidently Data Drift Report",
    )

    prefect_log.info(
        "Drift check complete | detected=%s | score=%.4f | drifted=%d",
        summary.get("drift_detected", False),
        summary.get("dataset_drift_score", 0.0),
        summary.get("n_drifted", 0),
    )
    return summary


# ---------------------------------------------------------------------------
# Decision Task
# ---------------------------------------------------------------------------


@task(name="decide-retrain")
def decide_retrain(
    drift_summary: dict[str, Any],
    incumbent_metric: float | None,
    drift_threshold: float = 0.5,
    performance_threshold: float | None = None,
    minimize: bool = True,
) -> bool:
    """Decide whether retraining should be triggered.

    Retraining is triggered if:
    - The fraction of drifted features exceeds `drift_threshold`, OR
    - The incumbent model's performance metric exceeds `performance_threshold`.

    Args:
        drift_summary: Output of `run_drift_check`.
        incumbent_metric: Current model's performance value (e.g., MAE, RMSE).
        drift_threshold: Fraction of drifted features that triggers a retrain (0..1).
        performance_threshold: Optional absolute metric threshold.
        minimize: If True, lower metric is better (e.g., error metrics).
            If False, higher is better (e.g., accuracy).

    Returns:
        True if retraining should occur.
    """
    drift_score = drift_summary.get("dataset_drift_score", 0.0)
    drift_triggered = drift_score >= drift_threshold

    performance_triggered = False
    if performance_threshold is not None and incumbent_metric is not None:
        if minimize:
            performance_triggered = incumbent_metric > performance_threshold
        else:
            performance_triggered = incumbent_metric < performance_threshold

    return drift_triggered or performance_triggered


# ---------------------------------------------------------------------------
# MLflow Logging Task
# ---------------------------------------------------------------------------


@task(name="log-to-mlflow", retries=2, retry_delay_seconds=30)
def log_to_mlflow(
    forecaster: TwigaForecaster,
    metrics_df: pd.DataFrame,
    predictions_df: pd.DataFrame | None = None,
    experiment: str = "twiga",
    run_name: str | None = None,
    tags: dict[str, str] | None = None,
) -> str:
    """Log a training/retraining run to MLflow using TwigaTracker.

    Args:
        forecaster: Fitted TwigaForecaster.
        metrics_df: Metrics DataFrame from `evaluate_model`.
        predictions_df: Optional predictions DataFrame for interactive tables.
        experiment: MLflow experiment name.
        run_name: Optional human‑readable run label.
        tags: Optional MLflow tags dict.

    Returns:
        The MLflow run ID.
    """
    from twiga.tracking.tracker import TwigaTracker

    prefect_log = get_run_logger()
    prefect_log.info("Logging to MLflow experiment=%s", experiment)

    with TwigaTracker(
        experiment=experiment,
        run_name=run_name,
        tags=tags or {},
    ) as tracker:
        tracker.log_forecaster_metadata(forecaster)

        # Log model with signature if reference data is available
        if forecaster.data_pipeline and forecaster.data_pipeline.data is not None:
            sample_input = forecaster.data_pipeline.data.head(100)
            tracker.log_model(forecaster, sample_input=sample_input)
        else:
            log.warning("No data pipeline reference available; skipping model signature logging.")

        tracker.log_evaluation(metrics_df, results_df=predictions_df or pd.DataFrame())

        run_id = tracker.run_id

    prefect_log.info("MLflow logging completed | run_id=%s", run_id)
    return run_id
