from __future__ import annotations

from abc import ABC
from collections.abc import Callable
from pathlib import Path
import time
from timeit import default_timer
from typing import Any

import joblib
import numpy as np
import optuna
import pandas as pd

from twiga.core.backtester import TimeBasedCV
from twiga.core.data.pipeline import DataPipeline
from twiga.core.data.processing import normalise_timestamp_column
from twiga.core.exceptions import NotFittedError
from twiga.core.utils.logger import LogContext, get_logger, log_section
from twiga.forecaster.result import ForecastKind, RawPrediction
from twiga.forecaster.utils import build_forecast_result

from .abstract import AbstractForecaster

log = get_logger(__name__)


class BaseForecaster(TimeBasedCV, AbstractForecaster, ABC):
    """Base forecaster class that provides model training, checkpointing,prediction, and evaluation capabilities.

    Example:
        >>> class MyForecaster(BaseForecaster):
        ...     def predict(self, test_df: pd.DataFrame, covariate_df: pd.DataFrame | None) -> dict:
        ...         # Implement prediction logic here
        ...         return {"loc": np.zeros((10, 1))}
        >>> forecaster = MyForecaster(split_freq="months", test_size=1, train_size=1, project_name="my-project")
        >>> forecaster.fit(train_df)
        >>> results_df, metrics_df = forecaster.evaluate(test_df)
    """

    def __init__(
        self,
        split_freq: str = "months",
        test_size: int = 1,
        train_size: int = 1,
        gap: int = 0,
        domain: str = "ml",
        stride: int | None = None,
        window: str = "expanding",
        date_column: str = "timestamp",
        num_splits: int | None = None,
        project_name: str = "experiment",
        file_name: str | None = None,
        seed: int = 42,
        root_dir: str = "../",
        metrics: tuple[str] | list[str] | None = None,
        checkpoints_path: str | None = None,
    ) -> None:
        """Initialize the BaseForecaster.

        Args:
            split_freq (str): Frequency of the data, e.g., "months".
            test_size (int): Number of periods to forecast.
            train_size (int): Training window size.
            gap (int): Gap between training and forecast periods.
            stride (int | None): Step size between splits.
            window (str): Window type (e.g., "expanding").
            date_column (str): Name of the timestamp column.
            domain (str): Domain of the data (e.g., "ml").
            num_splits (int | None): Number of splits for cross-validation.
            project_name (str): Experiment name.
            file_name (str | None): Optional file name for checkpoints.
            seed (int): Random seed.
            root_dir (str): Root directory for results.
            trial (Any | None): Optional trial object (for hyperparameter optimization).
            metrics (list[str]): List of metrics to evaluate.
            checkpoints_path (str | None): Explicit checkpoint directory.  When
                set, overrides the path derived from root_dir/project_name/model_type
                and is available immediately - before fit() is called.
        """
        super().__init__(
            split_freq=split_freq,
            train_size=train_size,
            test_size=test_size,
            gap=gap,
            stride=stride,
            window=window,
            date_column=date_column,
            num_splits=num_splits,
        )
        self.project_name: str = project_name
        self.file_name: str | None = file_name  # type: ignore[assignment]
        # Use the explicitly supplied path when provided; _create_folder() will
        # fill it in from root_dir/project_name/model_type when fit() runs.
        self.checkpoints_path: Path | None = Path(checkpoints_path) if checkpoints_path else None
        self.logs_path = None
        self.model_type = None
        self.domain = domain
        self.seed: int = seed
        self.root_dir = Path(root_dir)
        self.metrics: list[str] = list(metrics) if metrics else []
        self.model: Any | None = None
        self.train_df: pd.DataFrame | None = None
        self.models: list = []
        self.conformals: dict[str, Any] = {}
        self.conformal_params: Any | None = None
        self.data_pipeline: DataPipeline | None = None

    def _create_folder(self) -> None:
        """Create directory structure for experiment artifacts.

        Initializes the following paths:
        - results/: Final model outputs/analyses
        - logs/: Training logs/metrics
        - figures/: Visualizations/plots
        - checkpoints/: Model weight snapshots

        Directory structure:
        {root_dir}/{artifact_type}/{experiment_name}/{model_type}/[file_name]

        Raises:
            PermissionError: If directory creation fails due to insufficient rights
            RuntimeError: If required attributes are missing before invocation

        Example:
            >>> forecaster = TimeSeriesForecaster(
            ...     root_dir="experiments", project_name="baseline", model_type="transformer"
            ... )
            >>> forecaster._create_folder()
        """
        # Validate required attributes
        required_attrs = ["root_dir", "project_name", "model_type"]
        if any(getattr(self, attr, None) is None for attr in required_attrs):
            raise RuntimeError("Missing required directory configuration attributes")

        # Base path constructor
        base = Path(self.root_dir)
        paths = {
            "results_path": base / "results" / self.project_name / self.model_type,
            "logs_path": base / "logs" / self.project_name / self.model_type,
            "figures_path": base / "figures" / self.project_name / self.model_type,
            # Respect an explicitly configured checkpoints_path; otherwise derive it.
            "checkpoints_path": (
                Path(self.checkpoints_path)
                if self.checkpoints_path
                else base / "checkpoints" / self.project_name / self.model_type
            ),
        }

        # Add file_name to checkpoints if provided (only when path is derived)
        if not self.checkpoints_path and hasattr(self, "file_name") and self.file_name:
            paths["checkpoints_path"] = paths["checkpoints_path"] / self.file_name

        # Create directories
        for name, path in paths.items():
            try:
                path.mkdir(parents=True, exist_ok=True)
                setattr(self, name, path)
            except PermissionError as exc:
                raise PermissionError(f"Failed to create directory {path} due to insufficient permissions") from exc

    def on_save_checkpoint(self) -> str:
        """Save the data pipeline and model to a versioned checkpoint file.

        Writes ``model_and_pipeline.pkl`` for ML/baseline domains alongside a
        ``_checkpoint_manifest.json`` that records the version, timestamp, and
        model type.  The manifest is the authoritative source for
        :meth:`on_load_checkpoint` - avoiding brittle mtime-based selection.

        Returns:
            Absolute path to the checkpoint directory as a string.

        Example:
            >>> path = forecaster.on_save_checkpoint()
        """
        from datetime import UTC, datetime
        import json

        checkpoints_dir = Path(self.checkpoints_path)

        if self.domain in ("ml", "baseline"):
            checkpoint_path = checkpoints_dir / "model_and_pipeline.pkl"
            save_dict = {"model": self.model, "data_pipeline": self.data_pipeline}
            joblib.dump(save_dict, checkpoint_path)

            manifest_path = checkpoints_dir / "_checkpoint_manifest.json"
            # Increment version monotonically from any existing manifest.
            current_version = 0
            if manifest_path.exists():
                try:
                    existing = json.loads(manifest_path.read_text())
                    current_version = int(existing.get("version", 0))
                except (json.JSONDecodeError, KeyError, ValueError):
                    pass

            manifest = {
                "version": current_version + 1,
                "checkpoint_file": checkpoint_path.name,
                "model_type": self.model_type,
                "saved_at": datetime.now(UTC).isoformat(),
            }
            manifest_path.write_text(json.dumps(manifest, indent=2))
            log.info(
                "Checkpoint saved  path=%s  version=%d",
                checkpoint_path,
                manifest["version"],
            )

        return str(checkpoints_dir)

    def on_load_checkpoint(self) -> None:
        """Load the model and data pipeline from the versioned checkpoint.

        Prefers the ``_checkpoint_manifest.json`` written by
        :meth:`on_save_checkpoint` to identify the checkpoint file.  Falls
        back to mtime-based selection only when no manifest is present
        (e.g. checkpoints written by an older version of Twiga).

        Raises:
            ValueError: If ``checkpoints_path`` is not set or the domain is
                unsupported.

        Example:
            >>> forecaster.on_load_checkpoint()
        """
        import json

        if not hasattr(self, "checkpoints_path") or not self.checkpoints_path:
            raise ValueError(
                "checkpoints_path is not set. Either call fit() first, or supply "
                "checkpoints_path in ForecasterConfig so it is available before fit()."
            )

        checkpoint_dir = Path(self.checkpoints_path)
        if not checkpoint_dir.exists():
            log.warning("Checkpoint directory does not exist: %s", checkpoint_dir)
            return

        # ── Manifest-based selection (preferred) ────────────────────────────
        manifest_path = checkpoint_dir / "_checkpoint_manifest.json"
        if manifest_path.exists():
            try:
                manifest = json.loads(manifest_path.read_text())
                checkpoint_file = checkpoint_dir / manifest["checkpoint_file"]
                log.info(
                    "Loading checkpoint via manifest  file=%s  version=%s  saved_at=%s",
                    checkpoint_file.name,
                    manifest.get("version"),
                    manifest.get("saved_at"),
                )
            except (json.JSONDecodeError, KeyError) as exc:
                log.warning("Checkpoint manifest is corrupt (%s); falling back to mtime selection.", exc)
                checkpoint_file = None
        else:
            checkpoint_file = None

        # ── mtime fallback (legacy checkpoints without a manifest) ──────────
        if checkpoint_file is None or not checkpoint_file.exists():
            pkl_files = sorted(
                [f for f in checkpoint_dir.glob("*.pkl") if f.is_file()],
                key=lambda f: f.stat().st_mtime,
                reverse=True,
            )
            if not pkl_files:
                log.warning("No checkpoint files found in %s", checkpoint_dir)
                return
            checkpoint_file = pkl_files[0]
            log.info("Loading checkpoint via mtime fallback  file=%s", checkpoint_file.name)

        load_strategies: dict[str, Callable[[Path], None]] = {
            "ml": self._load_ml_checkpoint,
            "baseline": self._load_ml_checkpoint,
            "nn": self._load_nn_checkpoint,
        }

        if self.domain not in load_strategies:
            raise ValueError(f"Unsupported domain: {self.domain!r}. Supported: {list(load_strategies)}")

        try:
            if self.domain in ("ml", "baseline"):
                load_strategies[self.domain](checkpoint_file)
            else:
                load_strategies[self.domain]()  # type: ignore[call-arg]
            log.info("Checkpoint loaded successfully  file=%s", checkpoint_file)
        except (OSError, RuntimeError, EOFError, KeyError) as exc:
            log.warning("Failed to load checkpoint %s: %s", checkpoint_file, exc)

    def _load_ml_checkpoint(self, checkpoint_path: Path) -> None:
        """Load a machine learning checkpoint using joblib.

        Args:
            checkpoint_path: Path to the checkpoint file.

        Raises:
            RuntimeError: If the checkpoint is missing required keys.
        """
        data = joblib.load(checkpoint_path)
        if "model" in data and "data_pipeline" in data:
            self.model = data["model"]
            self.data_pipeline = data["data_pipeline"]
            # Restore the full model list so _predict_core iterates over the
            # correct fitted models rather than any unfitted models that were
            # registered during __init__ of the loaded forecaster.
            if "models" in data:
                self.models = data["models"]
            else:
                # Legacy checkpoint without "models" key - derive from the single model.
                self.models = [self.model]

    def _load_nn_checkpoint(self) -> None:
        """Load a neural network checkpoint using the model's load method.

        Raises:
            AttributeError: If the model lacks a load_checkpoint method.
            RuntimeError: If the model's data_pipeline is not set.
        """
        if not hasattr(self.model, "load_checkpoint"):
            raise AttributeError("Model does not support checkpoint loading for neural network domain")

        self.model.load_checkpoint()  # type: ignore[union-attr]
        if hasattr(self.model, "data_pipeline"):
            self.data_pipeline = self.model.data_pipeline  # type: ignore[union-attr]

    def load_checkpoint_and_datapipe(self) -> None:
        """Load the model checkpoint and restore the data pipeline from disk."""
        self.on_load_checkpoint()

    def _prepare_features(
        self,
        train_df: pd.DataFrame,
        val_df: pd.DataFrame | None = None,
        train_ratio: float = 1.0,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, np.ndarray | None]:
        """Prepare training and validation features using the data pipeline.

        Handles data splitting, transformation, and temporal filtering based on
        the configured lookback window and maximum data drop.

        Args:
            train_df: Training dataset containing features and target
            val_df: Optional validation dataset. If not provided and train_ratio < 1.0,
                will split training data into train/validation sets
            train_ratio: Proportion of training data to use (1.0 = use all data).
                Ignored if val_df is provided

        Returns:
            tuple: Contains four elements in order:
                - Training features array
                - Training targets array
                - Validation features array or None
                - Validation targets array or None

        Raises:
            ValueError: If data pipeline is not initialized
            RuntimeError: If model is not properly initialized before preprocessing

        Example:
            >>> train_feats, train_tgt, val_feats, val_tgt = model._prepare_features(
            ...     train_data, val_data=None, train_ratio=0.8
            ... )
        """
        self.train_df = pd.concat([train_df.copy(), val_df.copy()], axis=0) if val_df is not None else train_df.copy()
        if self.model is None:
            raise RuntimeError("Model must be initialized before feature preparation")

        if not hasattr(self.data_pipeline, "transform"):
            raise ValueError("Data pipeline must be initialized with transform method")

        # Fit data pipeline if not already fitted
        if self.data_pipeline.data_pipeline is None:  # type: ignore[union-attr]
            raise ValueError("Data pipeline not initialized. Call data_pipeline.fit() first")

        # Handle data splitting
        if val_df is None and train_ratio < 1.0:
            split_idx = int(train_ratio * len(train_df))
            train_split = train_df.iloc[:split_idx]
            val_split = train_df.iloc[split_idx:]
        else:
            train_split = train_df.copy()
            val_split = val_df.copy() if val_df is not None else None

        # Transform data
        train_features, train_target = self.data_pipeline.transform(train_split)  # type: ignore[union-attr]
        val_features, val_target = self.data_pipeline.transform(val_split) if val_split is not None else (None, None)  # type: ignore[union-attr]

        # Apply temporal filtering
        self._apply_temporal_filtering()

        return train_features, train_target, val_features, val_target

    def _apply_temporal_filtering(self) -> None:
        """Filter training data based on lookback window and data drop parameters.

        The function sorts the training data by the specified date column and then selects
        the required number of data points based on the sum of the lookback window size and
        the maximum data drop. If the available data is insufficient, a detailed error message is raised.
        """
        self.train_df = self.train_df.sort_values(by=self.data_pipeline.date_column)  # type: ignore[union-attr]

        data_drop = self.data_pipeline.max_data_drop  # type: ignore[union-attr]
        lookback_size = self.data_pipeline.lookback_window_size  # type: ignore[union-attr]
        required_samples = data_drop + lookback_size

        if len(self.train_df) < required_samples:
            raise ValueError(
                f"Not enough data to train the model. "
                f"At least {required_samples} data points are required, but only {len(self.train_df)} were provided.",
            )

        self.train_df = self.train_df.iloc[-required_samples:]

    def _fit(  # type: ignore[override]
        self,
        train_df: pd.DataFrame,
        val_df: pd.DataFrame | None = None,
        train_ratio: float = 1.0,
        trial: optuna.Trial | None = None,
    ) -> float:
        """Fit the model using the provided training data.

        Args:
            train_df (pd.DataFrame): Training data.
            val_df (pd.DataFrame | None): Optional validation data.
            train_ratio (float): Proportion of data to use for training (default is 1.0).
            trial (object | None): Optional trial object for hyperparameter optimization.

        Returns:
            float: Training wall time or cost metric (if trial is provided).

        Raises:
            ValueError: If the model instance is not initialized.

        Example:
            >>> wall_time = forecaster.fit(train_df, val_df, train_ratio=0.8)
        """
        train_feature, train_target, val_feature, val_target = self._prepare_features(
            train_df,
            val_df,
            train_ratio,
        )

        if self.model is None:
            raise NotFittedError("Model is not initialised. Call get_model_from_registry() before fit().")

        start_time = default_timer()
        log_section(log, f"Training {self.model_type}")
        if self.domain in ("ml", "baseline"):
            if val_feature is not None and val_target is not None:
                self.model.fit(train_feature, train_target, eval_set=(val_feature, val_target))
            else:
                self.model.fit(train_feature, train_target)
        elif self.domain == "nn":
            self.model.checkpoints_path = self.checkpoints_path
            self.model.logs_path = self.logs_path
            self.model.project_name = self.project_name
            self.model.file_name = self.file_name
            self.model.data_pipeline = self.data_pipeline
            self.model.fit(train_feature, train_target, val_feature, val_target, trial=trial)
        else:
            raise ValueError(f"Unknown domain: {self.domain!r}. Expected 'ml', 'baseline', or 'nn'.")
        self.train_walltime = default_timer() - start_time
        log.info(
            "Training %s complete  duration=%.2f min",  # ← no f-string
            self.model_type,
            self.train_walltime / 60,
        )
        self.on_save_checkpoint()
        return self.train_walltime

    def _objective_fn(self, trial, train_df, val_df):

        self.model.update(trial)

        # Record parameter count so the post-hoc complexity filter can use it.
        # self.model.model is the nn.Module re-initialised inside update().
        n_params = sum(p.numel() for p in self.model.model.parameters())
        trial.set_user_attr("n_params", n_params)

        try:
            self._fit(train_df, val_df, trial=trial)
        except optuna.exceptions.TrialPruned:
            log.debug("Trial %d pruned", trial.number)
            raise
        except Exception as e:
            log.exception("Trial %d failed during fitting", trial.number)
            raise optuna.exceptions.TrialPruned() from e

        _, metrics = self._evaluate(val_df)
        cost = float(metrics.groupby("Model", sort=False)["mae"].mean().mean())
        trial.set_user_attr("rmse", float(metrics["rmse"].mean()))
        trial.set_user_attr("std_dev", float(metrics["mae"].std()))
        log.debug("Trial %d complete  mae=%.5f  n_params=%d", trial.number, cost, n_params)
        return round(cost, 5)

    def create_optuna_study(
        self,
        num_trials: int = 10,
        reduction_factor: int = 3,
        patience: int = 2,
        load_if_exists: bool = True,
        base_pruner: Any | None = None,
        sampler: Any | None = None,
        direction: str = "minimize",
    ):
        """Create or load an Optuna study for hyperparameter optimization.

        This method configures an Optuna study with a Hyperband pruner wrapped by a PatientPruner
        (if no custom pruner is provided) and a TPESampler with the instance's seed (if no custom
        sampler is provided). The study is stored in a SQLite database within the results directory.

        Args:
            num_trials (int): Number of trials for the study (unused in study setup).
            reduction_factor (int): Reduction factor for HyperbandPruner.
            patience (int): Patience for PatientPruner.
            load_if_exists (bool): Whether to load an existing study if it exists.
            base_pruner (Any | None): Custom pruner to use instead of the default.
            sampler (Any | None): Custom sampler to use instead of the default.
            direction (str): Direction of optimization, either "minimize" or "maximize".

        Returns:
            optuna.Study: Configured Optuna study.
        """
        if num_trials < 1:
            raise ValueError(f"num_trials must be ≥1, got {num_trials}")
        if reduction_factor < 2:
            raise ValueError(f"reduction_factor must be ≥2, got {reduction_factor}")
        if patience < 0:
            raise ValueError(f"patience must be a non-negative integer, got {patience}")

        if self.logs_path is None:
            raise ValueError("logs_path is not set - call fit() before create_optuna_study().")
        study_name = f"{self.project_name}_{self.model_type}"
        safe_study_name = study_name.replace("/", "_").replace("\\", "_")
        file_path = Path(self.logs_path) / f"{safe_study_name}.log"
        file_path.parent.mkdir(parents=True, exist_ok=True)

        lock_obj = optuna.storages.journal.JournalFileOpenLock(str(file_path))  # type: ignore[attr-defined]
        storage = optuna.storages.JournalStorage(
            optuna.storages.journal.JournalFileBackend(str(file_path), lock_obj=lock_obj),  # type: ignore[attr-defined]
        )

        if base_pruner is None:
            base_pruner = optuna.pruners.HyperbandPruner(
                min_resource=patience,
                max_resource="auto",
                reduction_factor=reduction_factor,
            )

        if sampler is None:
            sampler = optuna.samplers.TPESampler(
                seed=self.seed,
                multivariate=True,
                n_startup_trials=patience * 2,
                constant_liar=True,
                group=True,
            )

        return optuna.create_study(
            direction=direction,
            pruner=base_pruner,
            sampler=sampler,
            study_name=study_name,
            storage=storage if load_if_exists else None,
            load_if_exists=load_if_exists,
        )

    def _tune(
        self,
        train_df: pd.DataFrame,
        val_df: pd.DataFrame,
        num_trials: int = 10,
        reduction_factor: int = 3,
        patience: int = 5,
        load_if_exists: bool = True,
        base_pruner: Any | None = None,
        sampler: Any | None = None,
        initial_params: dict | None = None,
        direction: str = "minimize",
    ) -> dict:
        """Perform hyperparameter tuning using Optuna.

        This method sets up an Optuna study to perform hyperparameter optimization for the model.
        It uses a Hyperband pruner (wrapped by a PatientPruner) with the given reduction factor and
        patience. If a study with the given name already exists and load_if_exists is True, the study
        is loaded from disk.

        Args:
            train_df (pd.DataFrame): Training DataFrame.
            val_df (pd.DataFrame): Validation DataFrame.
            num_trials (int, optional): Number of trials for hyperparameter optimization.
                Must be ≥ 1. Defaults to 10.
            reduction_factor (int, optional): Reduction factor for the Hyperband pruner.
                Must be ≥ 2. Defaults to 3.
            patience (int, optional): Patience for the PatientPruner (number of trials to wait before pruning).
                Must be a non-negative integer. Defaults to 2.
            load_if_exists (bool, optional): If True, load the study from disk if it exists.
                Defaults to True.
            base_pruner (optional): An optional custom pruner. If None, a Hyperband pruner is used.
            sampler (optional): An optional custom sampler. If None, a TPESampler seeded with `self.seed` is used.
            initial_params (dict | None): Optional initial hyperparameter configuration to enqueue.
            direction (str): Direction of optimization, either "minimize" or "maximize".

        Returns:
            dict: The best hyperparameter configuration found by the study.

        Raises:
            ValueError: If any of the tuning parameters are invalid.

        Example:
            >>> best_params = forecaster._tune(train_df, val_df, num_trials=20, reduction_factor=3, patience=2)
            >>> print("Best hyperparameters:", best_params)
        """
        # Validate input parameters
        study = self.create_optuna_study(
            num_trials=num_trials,
            reduction_factor=reduction_factor,
            patience=patience,
            load_if_exists=load_if_exists,
            base_pruner=base_pruner,
            sampler=sampler,
            direction=direction,
        )
        with LogContext(log, model=self.model_type, trials=num_trials):
            log.info("Starting hyperparameter tuning")

            if initial_params is not None:
                study.enqueue_trial(initial_params, skip_if_exists=True)

            study.optimize(lambda trial: self._objective_fn(trial, train_df, val_df), n_trials=num_trials)

        completed = [t for t in study.trials if t.state == optuna.trial.TrialState.COMPLETE]
        if not completed:
            log.warning(
                "No trials completed successfully for %s - returning empty params",
                self.model_type,
            )
            return {}

        # ── Complexity-aware selection (strategy 2C) ─────────────────────────
        # Among all trials within `complexity_tolerance` of the best MAE,
        # prefer the one with the fewest parameters.  Falls back to the
        # pure-MAE best when n_params was not recorded (e.g. ML models).
        best_mae = study.best_trial.value
        tolerance = getattr(self, "complexity_tolerance", 0.02)

        eligible = [t for t in completed if t.value <= best_mae * (1.0 + tolerance)]

        has_complexity = all("n_params" in t.user_attrs for t in eligible)
        if has_complexity:
            best_trial = min(eligible, key=lambda t: t.user_attrs["n_params"])
            log.info(
                "Complexity filter applied  tolerance=%.0f%%  eligible=%d  "
                "selected_trial=%d  mae=%.5f  n_params=%d  "
                "(best_mae=%.5f  delta=%.5f)",
                tolerance * 100,
                len(eligible),
                best_trial.number,
                best_trial.value,
                best_trial.user_attrs["n_params"],
                best_mae,
                best_trial.value - best_mae,
            )
        else:
            best_trial = study.best_trial
            log.info(
                "Tuning complete  best_trial=%d  mae=%.5f",
                best_trial.number,
                best_trial.value,
            )

        best_params = best_trial.params

        # Save the best parameters to a file
        np.save(f"{self.results_path}/best_params.npy", best_params)  # type: ignore[attr-defined]
        return best_params

    def prepare_test_data(self, test_df=None):
        """Prepares and returns a formatted test DataFrame for prediction.

        This method checks the consistency of the training DataFrame and test DataFrame,
        concatenates them if both are provided, and sorts the resulting DataFrame by the
        date column defined in the data pipeline.

        Args:
            test_df (pandas.DataFrame, optional): A DataFrame containing test data.
                If not provided, the training DataFrame is used as test data.

        Raises:
            ValueError: If the training DataFrame length does not match the expected
                lookback window size plus maximum data drop.
            ValueError: If neither training data nor test data is provided.

        Returns:
            pandas.DataFrame: A sorted DataFrame ready for prediction.
        """
        if test_df is not None:
            test_df = test_df.copy()

        # Retrieve parameters from the data pipeline.
        max_data_drop = self.data_pipeline.max_data_drop
        lookback_window = self.data_pipeline.lookback_window_size

        # Validate the training DataFrame length if it exists.
        if self.train_df is not None and len(self.train_df) != lookback_window + max_data_drop:
            raise ValueError(
                "The length of the training DataFrame does not match "
                "the expected lookback_window_size + max_data_drop.",
            )

        # Ensure that at least one of train_df or test_df is provided.
        if self.train_df is None and test_df is None:
            raise ValueError("You cannot call prediction without specifying test data.")

        # Sort the DataFrame based on the date column from the data pipeline.
        date_column = self.data_pipeline.date_column

        # Normalise timestamps on both sides to tz-naive before any concat/sort.
        # train_df may be tz-aware when loaded from an old checkpoint; test_df may
        # arrive tz-aware from an external caller.  This is a no-op when both are
        # already tz-naive (the common path after normalise_timestamp_column is
        # applied at all ingestion points).
        if test_df is not None and date_column in test_df.columns:
            test_df = normalise_timestamp_column(test_df, date_column)
        if self.train_df is not None and date_column in self.train_df.columns:
            self.train_df = normalise_timestamp_column(self.train_df, date_column)

        # If both training and test data are provided, concatenate them.
        if test_df is not None and self.train_df is not None:
            test_df = pd.concat([self.train_df, test_df], axis=0)
        # If only training data is available, use it as test data.
        elif test_df is None and self.train_df is not None:
            test_df = self.train_df

        test_df = test_df.sort_values(by=date_column)

        return test_df

    def create_results_df(
        self,
        time_stamp: np.ndarray,
        ground_truth: np.ndarray,
        predictions: np.ndarray,
        target_feature: list[str],
        date_column: str,
    ) -> pd.DataFrame:
        """Create a results DataFrame with the timestamp index, ground truth, and forecasted values.

        Args:
            time_stamp (np.ndarray): Timestamp index.
            ground_truth (np.ndarray): Ground truth values.
            predictions (np.ndarray): Forecasted values.
            target_feature (list[str]): List of target series names.
            date_column (str): Name of the date column.

        Returns:
            pd.DataFrame: DataFrame with ground truth and forecasted values indexed by timestamp.

        Example:
            >>> results_df = forecaster.create_results_df(ts, gt, pred, ["temp"], "Date")
        """
        if time_stamp.size != ground_truth.size:
            raise ValueError(f"Shape mismatch: timestamps ({time_stamp.shape}) vs ground truth ({ground_truth.shape})")
        results_df = pd.DataFrame(index=pd.to_datetime(time_stamp.flatten(), unit="ns", utc=True))
        results_df.index.name = date_column

        for target_idx, target_name in enumerate(target_feature):
            results_df[target_name] = ground_truth[:, :, target_idx].flatten()
            results_df[f"{target_name}_forecast"] = predictions[:, :, target_idx].flatten()

        return results_df

    def get_ground_truth(self, test_df: pd.DataFrame | None = None) -> tuple[np.ndarray, np.ndarray]:
        """Load the latest checkpoint and return inverse-scaled ground truth sequences.

        **Side effect**: calls :meth:`load_checkpoint_and_datapipe`, which
        calls :meth:`on_load_checkpoint` and may overwrite ``self.model`` and
        ``self.data_pipeline`` from disk.  Use this method during evaluation
        (where the checkpoint state is desired).  For pure data extraction
        without checkpoint side effects - e.g. inside :meth:`forecast` - use
        ``self.data_pipeline.get_ground_truth_sequences()`` directly instead.

        Args:
            test_df: Test DataFrame. If ``None``, uses ``self.train_df``.

        Returns:
            Tuple of:
                - time_stamp: Timestamp array aligned with prediction sequences.
                - ground_truth: Inverse-scaled ground truth array of shape
                  ``(num_sequences, forecast_horizon, num_targets)``.
        """
        self.load_checkpoint_and_datapipe()
        time_stamp, ground_truth = self.data_pipeline.get_ground_truth_sequences(test_df)  # type: ignore[union-attr]
        ground_truth = self._rescale_predictions(ground_truth)
        return time_stamp, ground_truth  # type: ignore[return-value]

    def _inverse_scale_predictions(self, scaled_predictions: np.ndarray, is_scale: bool = False) -> np.ndarray:
        """Reverse feature scaling on model predictions.

        Args:
            scaled_predictions: Predictions in scaled space
            is_scale: Flag indicating whether to apply inverse scaling

        Returns:
            Predictions in original data space
        """
        try:
            scaler = self.data_pipeline.data_pipeline.named_steps["scaling"]  # type: ignore[union-attr]
            target_scaler = scaler.named_transformers_["target_scaling"]
        except KeyError as e:
            raise RuntimeError(f"Missing pipeline component: {e!s}") from e

        original_shape = scaled_predictions.shape
        reshaped = scaled_predictions.reshape(-1, original_shape[-1])
        if is_scale and hasattr(target_scaler, "scale_"):
            rescaled = reshaped * target_scaler.scale_
        else:
            rescaled = target_scaler.inverse_transform(reshaped)
        return rescaled.reshape(original_shape)

    def _rescale_predictions(
        self,
        predictions: np.ndarray | dict[str, np.ndarray] | tuple[np.ndarray, ...] | RawPrediction,
    ) -> RawPrediction | np.ndarray:
        """Inverse-transform scaled model output to the original data scale.

        Accepts either a :class:`~twiga.forecaster.result.RawPrediction` (preferred)
        or the legacy ``ndarray | dict | tuple`` union for backward compatibility.
        Plain ``np.ndarray`` inputs (e.g. from :meth:`get_ground_truth`) are
        returned as ``np.ndarray``; all other inputs return a :class:`RawPrediction`.

        Args:
            predictions: Scaled model output in any supported format.

        Returns:
            Rescaled :class:`RawPrediction`, or a plain ``np.ndarray`` when a
            bare array is supplied.

        Raises:
            TypeError: If *predictions* is not a supported type.
        """
        # Fast path: plain array (used by get_ground_truth)
        if isinstance(predictions, np.ndarray):
            return self._inverse_scale_predictions(predictions)

        # Convert legacy formats to RawPrediction once
        if not isinstance(predictions, RawPrediction):
            predictions = RawPrediction.from_model_output(predictions)

        return self._rescale_raw(predictions)

    def _rescale_raw(self, raw: RawPrediction) -> RawPrediction:
        """Inverse-scale a :class:`RawPrediction` in-place and return it.

        Each field is rescaled according to its semantic role:
        - ``loc`` and bounds use full inverse transform.
        - ``scale`` uses the scale-only path (multiply by ``scale_`` factor).
        - ``quantiles`` / ``samples`` are flattened to 3-D, rescaled, reshaped.

        Args:
            raw: Unscaled typed prediction container.

        Returns:
            The same :class:`RawPrediction` instance with all arrays rescaled.
        """
        raw.loc = self._inverse_scale_predictions(raw.loc)

        if raw.kind == ForecastKind.INTERVAL:
            if raw.lower is not None:
                raw.lower = self._inverse_scale_predictions(raw.lower)
            if raw.upper is not None:
                raw.upper = self._inverse_scale_predictions(raw.upper)

        elif raw.kind == ForecastKind.PARAMETRIC and raw.scale is not None:
            raw.scale = self._inverse_scale_predictions(raw.scale, is_scale=True)

        elif raw.kind == ForecastKind.QUANTILE and raw.quantiles is not None:
            n_batch, n_q, n_h, n_c = raw.quantiles.shape
            raw.quantiles = self._inverse_scale_predictions(raw.quantiles.reshape(n_batch * n_q, n_h, n_c)).reshape(
                n_batch, n_q, n_h, n_c
            )

        elif raw.kind == ForecastKind.SAMPLES and raw.samples is not None:
            n_batch, n_s, n_h, n_c = raw.samples.shape
            raw.samples = self._inverse_scale_predictions(raw.samples.reshape(n_batch * n_s, n_h, n_c)).reshape(
                n_batch, n_s, n_h, n_c
            )

        return raw

    def _predict(self, test_df: pd.DataFrame, covariate_df: pd.DataFrame | None) -> RawPrediction:
        """Execute prediction workflow with data transformation and scaling inversion.

        Args:
            test_df: Test DataFrame containing input features.
            covariate_df: Optional DataFrame containing external covariates.

        Returns:
            Rescaled :class:`~twiga.forecaster.result.RawPrediction` containing
            ``loc`` and any kind-specific fields (``scale``, ``quantiles``, etc.).

        Raises:
            RuntimeError: If data pipeline components are not properly initialized.
            ValueError: For invalid input data formats.
        """
        self._validate_data_pipeline()

        try:
            features = self.data_pipeline.transform_features(test_df)  # type: ignore[union-attr]
            if self.domain not in ("ml", "baseline"):
                import torch  # noqa: PLC0415

                features = torch.FloatTensor(features)

        except ValueError as exc:
            raise ValueError(f"Feature transformation failed: {exc!s}") from exc

        start_time = time.perf_counter()
        raw_output = self.model.forecast(features)  # type: ignore[union-attr]
        self.test_walltime = time.perf_counter() - start_time
        log.info("Prediction completed in %.2f seconds", self.test_walltime)

        result = self._rescale_predictions(raw_output)
        # _rescale_predictions guarantees RawPrediction when input is not a bare ndarray
        if isinstance(result, np.ndarray):
            return RawPrediction(loc=result)
        return result

    def _validate_data_pipeline(self) -> None:
        """Ensure data pipeline is properly configured before transformations."""
        if not hasattr(self.data_pipeline, "data_pipeline"):
            raise AttributeError("Data pipeline component structure is invalid")

        if self.data_pipeline.data_pipeline is None:  # type: ignore[union-attr]
            raise ValueError(
                "Data pipeline not initialized. Required steps:\n"
                "1. Prepare data preprocessing steps\n"
                "2. Call .fit() with training data\n"
                f"Missing pipeline: {self.data_pipeline.__class__.__name__}",
            )

    def _evaluate(
        self,
        test_df: pd.DataFrame | None = None,
        covariate_df: pd.DataFrame | None = None,
        time_stamp=None,
        ground_truth=None,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Perform prediction on the test DataFrame and return results and evaluation metrics.

        Args:
            test_df (pd.DataFrame | None): Test DataFrame with prediction inputs.
            covariate_df (pd.DataFrame | None): DataFrame with covariate features.
            time_stamp (pd.DataFrame|None): timestamp for creating results dataframe
            ground_truth (pd.DataFrame|None): dataframe with ground truth for computing metrics.

        Returns:
            tuple[pd.DataFrame, pd.DataFrame]: Tuple containing:
                - results_df: DataFrame with ground truth and forecasted values.
                - metrics_df: DataFrame with evaluation metrics.
        """
        raw = self._predict(test_df, covariate_df)
        forecast = raw.loc
        if time_stamp is None or ground_truth is None:
            time_stamp, ground_truth = self.get_ground_truth(test_df=test_df)
        if forecast.shape != ground_truth.shape:
            raise ValueError("Shape mismatch: 'forecast' and 'ground_truth' must have the same shape.")

        target_feature = self.data_pipeline.target_feature  # type: ignore[union-attr]
        targets = [target_feature] if isinstance(target_feature, str) else list(target_feature)
        result = build_forecast_result(
            model_name=self.model_type,
            pred=forecast,
            timestamps=time_stamp,
            targets=targets,
            ground_truth=ground_truth,
        )
        metrics_df = result.evaluate(metric_names=self.metrics)
        metrics_df["test-time"] = self.test_walltime
        metrics_df["Model"] = self.model_type.upper()

        results_df = self.create_results_df(
            time_stamp,
            ground_truth,
            forecast,
            self.data_pipeline.target_feature,  # type: ignore[union-attr]
            self.data_pipeline.date_column,  # type: ignore[union-attr]
        )
        results_df["Model"] = self.model_type.upper()

        return results_df, metrics_df

    def _backtester(
        self,
        data: pd.DataFrame,
        train_ratio: float = 1.0,
        start_dt: object | None = None,
        end_dt: object | None = None,
        verbose: bool = True,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Perform backtesting by iterating over splits of the dataset.

        Args:
            data (pd.DataFrame): DataFrame containing the full dataset.
            train_ratio (float): Proportion of data to use for training.
            start_dt (object | None): Optional start date for splitting.
            end_dt (object | None): Optional end date for splitting.
            verbose (bool): If True, logs information about each fold.

        Returns:
            tuple[pd.DataFrame, pd.DataFrame]: Tuple containing:
                - metrics: DataFrame of metrics for all folds.
                - forecast: DataFrame of forecasts for all folds.
        """
        metrics_list: list[pd.DataFrame] = []
        forecast_list: list[pd.DataFrame] = []

        for train_df, test_df, scheme, key in self.split(data, start_dt, end_dt):
            if verbose:
                log.info("Backtesting - Fold %d", key + 1)
                log.info(
                    "Train window: %s to %s",
                    scheme["train_period"][0],
                    scheme["train_period"][1],
                )
                log.info(
                    "Test window: %s to %s",
                    scheme["test_period"][0],
                    scheme["test_period"][1],
                )
            try:
                self.data_pipeline.fit(train_df.copy())  # type: ignore[union-attr]
                self._fit(train_df=train_df, train_ratio=train_ratio)
                pred, metric = self._evaluate(test_df=test_df)
                metric["Folds"] = key + 1
                pred["Folds"] = key + 1
                metrics_list.append(metric)
                forecast_list.append(pred)
            except Exception:
                log.exception("Unexpected error in fold %d", key + 1)
                continue

        metrics = pd.concat(metrics_list, axis=0) if metrics_list else pd.DataFrame()
        forecast = pd.concat(forecast_list, axis=0) if forecast_list else pd.DataFrame()

        return forecast, metrics
