from collections.abc import Callable

import numpy as np
import pandas as pd

from twiga.core.data.pipeline import DataPipeline
from twiga.forecaster.result import ForecastKind, ForecastResult, RawPrediction


def get_prediction_array(is_interval: bool, pred: np.ndarray | tuple | dict | RawPrediction) -> np.ndarray:
    """Extract the point-prediction array from different prediction formats.

    Args:
        is_interval: Whether the prediction includes intervals (lower, loc, upper).
        pred: The prediction - a RawPrediction, np.ndarray, tuple (lower, loc, upper), or dict.

    Returns:
        The extracted point-prediction array (loc).
    """
    if isinstance(pred, RawPrediction):
        return pred.loc
    if is_interval:
        pred_array = pred[1]  # (lower, loc, upper) → loc
    elif isinstance(pred, dict):
        pred_array = pred["loc"]
    elif isinstance(pred, tuple):
        pred_array = pred[0]  # (loc, quantiles_hat) or (loc, scale) → loc
    elif isinstance(pred, np.ndarray):
        pred_array = pred
    else:
        raise ValueError("Unsupported prediction format. Expected RawPrediction, np.ndarray, tuple, or dict.")
    return pred_array


def validate_shapes(
    prediction_dict: dict,
    timestamps: np.ndarray,
    ground_truth: np.ndarray,
    is_interval: bool,
) -> tuple[int, int, int]:
    """Validate shapes of predictions, timestamps, and ground truth.

    Args:
        prediction_dict: Dictionary of model predictions.
        timestamps: Array of timestamps.
        ground_truth: Array of ground truth values.
        is_interval: Whether predictions include intervals (lower, loc, upper).

    Returns:
        Tuple of (num_samples, horizon, num_targets).

    Raises:
        ValueError: If shapes do not match expected dimensions.
    """
    # Extract shape from first prediction (interval forecasts return tuple)
    first_pred = next(iter(prediction_dict.values()))
    pred_array = get_prediction_array(is_interval, first_pred)
    num_samples, horizon, num_targets = pred_array.shape

    if ground_truth.shape != (num_samples, horizon, num_targets):
        raise ValueError(
            f"Ground truth shape {ground_truth.shape} does not match prediction "
            f"shape ({num_samples}, {horizon}, {num_targets})",
        )
    if timestamps.shape != (num_samples, horizon, num_targets):
        raise ValueError(
            f"Timestamp shape {timestamps.shape} does not match expected ({num_samples}, {horizon}, {num_targets})",
        )

    # Validate all predictions
    for model_name, pred in prediction_dict.items():
        pred_array = get_prediction_array(is_interval, pred)
        if pred_array.shape != (num_samples, horizon, num_targets):
            raise ValueError(
                f"Model {model_name} prediction shape {pred_array.shape} does not "
                f"match expected ({num_samples}, {horizon}, {num_targets})",
            )
    return num_samples, horizon, num_targets


def build_ground_truth_df(
    timestamps: np.ndarray,
    ground_truth: np.ndarray,
    data_pipeline: "DataPipeline",
) -> pd.DataFrame:
    """Build ground truth DataFrame.

    Args:
        timestamps: Array of timestamps.
        ground_truth: Array of ground truth values.
        data_pipeline: DataPipeline instance with target_feature and date_column.

    Returns:
        DataFrame with columns: timestamp, target, Actual.
    """
    timestamps_flat = pd.to_datetime(timestamps.flatten(), unit="ns", utc=True)
    ground_truth_flat = ground_truth.reshape(-1, ground_truth.shape[-1])
    return pd.DataFrame(
        {
            "timestamp": timestamps_flat,
            "target": np.tile(data_pipeline.target_feature, len(timestamps_flat)),
            "Actual": ground_truth_flat.ravel(),
        },
    )


def build_predictions_and_metrics(
    prediction_dict: dict,
    test_times: dict,
    ground_truth: np.ndarray,
    timestamps: np.ndarray,
    evaluation_fn: Callable,  # type: ignore[type-arg]
    is_interval: bool,
    data_pipeline: DataPipeline,
    metrics: list | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Build predictions and metrics DataFrames.

    Args:
        prediction_dict: Dictionary of model predictions.
        test_times: Dictionary of inference times per model.
        ground_truth: Array of ground truth values.
        timestamps: Array of timestamps.
        evaluation_fn: Function to evaluate predictions.
        is_interval: Whether predictions include intervals (lower, loc, upper).
        data_pipeline: DataPipeline instance with target_feature.
        metrics: List of metric names (for point forecasts).

    Returns:
        Tuple of:
            - DataFrame with columns: timestamp, Model, target, forecast, [lower, upper].
            - DataFrame with columns: Model, target, MetricName, Value, inference-time.
    """
    predictions_data = []
    metrics_data = []
    num_targets = ground_truth.shape[-1]
    timestamps_flat = pd.to_datetime(timestamps.flatten(), unit="ns", utc=True)

    for model_name, pred in prediction_dict.items():
        if is_interval:
            lower, forecast, upper = pred
            eval_input = {
                "true": ground_truth,
                "lower": lower,
                "loc": forecast,
                "upper": upper,
                "index": timestamps,
                "targets": data_pipeline.target_feature,
            }
            lower_flat = lower.reshape(-1, num_targets)
            upper_flat = upper.reshape(-1, num_targets)
        else:
            forecast = pred
            eval_input = {
                "true": ground_truth,
                "loc": forecast,
                "index": timestamps,
                "targets": data_pipeline.target_feature,
            }
            lower_flat = upper_flat = None

        metrics_df = evaluation_fn(eval_input)
        metrics_df["Model"] = model_name.upper()
        metrics_df["inference-time"] = test_times[model_name]
        metrics_data.append(metrics_df)

        forecast_flat = forecast.reshape(-1, num_targets)
        model_df: dict = {
            "timestamp": timestamps_flat,
            "Model": model_name.upper(),
            "target": np.tile(data_pipeline.target_feature, len(timestamps_flat)),
            "forecast": forecast_flat.ravel(),
        }
        if is_interval:
            model_df["lower"] = lower_flat.ravel()  # type: ignore[union-attr]
            model_df["upper"] = upper_flat.ravel()  # type: ignore[union-attr]
        predictions_data.append(pd.DataFrame(model_df))

    return pd.concat(predictions_data, ignore_index=True), pd.concat(metrics_data, ignore_index=True)


def merge_and_format_results(
    predictions_df: pd.DataFrame,
    ground_truth_df: pd.DataFrame,
    data_pipeline: "DataPipeline",
) -> pd.DataFrame:
    """Merge predictions with ground truth and format the result.

    Args:
        predictions_df: DataFrame with predictions.
        ground_truth_df: DataFrame with ground truth.
        data_pipeline: DataPipeline instance with date_column.

    Returns:
        Merged DataFrame with timestamp as index.
    """
    results_df = pd.merge(
        predictions_df,
        ground_truth_df,
        on=["timestamp", "target"],
        how="left",
    )
    results_df.set_index("timestamp", inplace=True)
    results_df.index.name = data_pipeline.date_column
    return results_df


def build_forecast_result(
    model_name: str,
    pred: np.ndarray | dict | tuple,
    timestamps: np.ndarray,
    targets: list[str],
    ground_truth: np.ndarray | None = None,
    inference_time: float = 0.0,
) -> ForecastResult:
    """Build a :class:`~twiga.forecaster.result.ForecastResult` from raw model output.

    Inspects *pred* to detect the output type and constructs the appropriate
    :class:`~twiga.forecaster.result.ForecastKind`.  This is the single place
    in the codebase where raw prediction formats are converted to the typed
    result container, eliminating scattered ``isinstance`` checks elsewhere.

    Supported *pred* formats:

    * ``np.ndarray`` - interpreted as a point forecast (``loc``).
    * ``tuple[np.ndarray, np.ndarray, np.ndarray]`` - interpreted as a
      conformal interval ``(lower, loc, upper)``.
    * ``dict`` with key ``"loc"`` only - point forecast.
    * ``dict`` with keys ``"loc"`` and ``"scale"`` - parametric forecast.
    * ``dict`` with keys ``"loc"`` and ``"quantiles"`` - quantile forecast.
    * ``dict`` with keys ``"loc"`` and ``"samples"`` - sample-based forecast.

    Args:
        model_name: Human-readable model identifier stored on the result.
        pred: Raw model output in one of the supported formats described above.
        timestamps: Prediction timestamps, shape ``(n_batch, n_horizon, n_targets)``.
        targets: Ordered list of target variable names.
        ground_truth: Optional observed values, same shape as ``loc``.
        inference_time: Wall-clock inference duration in seconds.

    Returns:
        A fully initialised :class:`~twiga.forecaster.result.ForecastResult`.

    Raises:
        TypeError: If *pred* is not a ``np.ndarray``, ``tuple``, or ``dict``.
        ValueError: If a ``dict`` *pred* lacks the required ``"loc"`` key,
            or if a ``tuple`` *pred* does not have exactly three elements.
    """
    kwargs: dict = {
        "timestamps": timestamps,
        "targets": targets,
        "model_name": model_name,
        "ground_truth": ground_truth,
        "inference_time": inference_time,
    }

    # RawPrediction is the canonical return type from _predict() - dispatch first.
    if isinstance(pred, RawPrediction):
        kw = {**kwargs, "kind": pred.kind}
        if pred.kind == ForecastKind.PARAMETRIC:
            return ForecastResult(loc=pred.loc, scale=pred.scale, **kw)
        if pred.kind == ForecastKind.QUANTILE:
            return ForecastResult(
                loc=pred.loc,
                quantiles=pred.quantiles,
                quantile_levels=pred.quantile_levels,
                conf_level=pred.conf_level,
                **kw,
            )
        if pred.kind == ForecastKind.SAMPLES:
            return ForecastResult(loc=pred.loc, samples=pred.samples, **kw)
        if pred.kind == ForecastKind.INTERVAL:
            return ForecastResult(loc=pred.loc, lower=pred.lower, upper=pred.upper, **kw)
        # POINT (and any unknown kind) - loc only
        return ForecastResult(loc=pred.loc, **kw)

    if isinstance(pred, np.ndarray):
        return ForecastResult(loc=pred, kind=ForecastKind.POINT, **kwargs)

    if isinstance(pred, tuple):
        if len(pred) != 3:
            raise ValueError(f"Tuple prediction must have exactly 3 elements (lower, loc, upper), got {len(pred)}.")
        lower, loc, upper = pred
        return ForecastResult(loc=loc, kind=ForecastKind.INTERVAL, lower=lower, upper=upper, **kwargs)

    if isinstance(pred, dict):
        if "loc" not in pred:
            raise ValueError("Dict prediction must contain the key 'loc'.")
        loc = pred["loc"]

        if "scale" in pred:
            return ForecastResult(loc=loc, scale=pred["scale"], kind=ForecastKind.PARAMETRIC, **kwargs)

        if "quantiles" in pred:
            return ForecastResult(
                loc=loc,
                quantiles=pred["quantiles"],
                quantile_levels=pred.get("quantile_levels"),
                kind=ForecastKind.QUANTILE,
                **kwargs,
            )

        if "samples" in pred:
            return ForecastResult(loc=loc, samples=pred["samples"], kind=ForecastKind.SAMPLES, **kwargs)

        # dict with only "loc" → treat as point
        return ForecastResult(loc=loc, kind=ForecastKind.POINT, **kwargs)

    raise TypeError(
        f"Unsupported prediction type {type(pred).__name__!r}. "
        "Expected RawPrediction, np.ndarray, tuple[ndarray, ndarray, ndarray], or dict.",
    )
