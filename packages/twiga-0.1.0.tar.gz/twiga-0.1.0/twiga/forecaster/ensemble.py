import enum

import numpy as np


class EnsembleStrategy(enum.StrEnum):
    """Enum defining strategies for combining model predictions in an ensemble.

    Attributes:
        MEAN (str): Compute the mean of predictions.
        MEDIAN (str): Compute the median of predictions.
        WEIGHTED (str): Compute a weighted sum of predictions.
    """

    MEAN = "mean"
    MEDIAN = "median"
    WEIGHTED = "weighted"


def compute_ensemble_predictions(
    predictions: list[np.ndarray],
    model_names: list[str],
    ensemble_strategy: EnsembleStrategy,
    ensemble_weights: dict[str, float] | None = None,
) -> np.ndarray:
    """Generate ensemble predictions by combining predictions from multiple models.

    Args:
        predictions: List of model predictions, where each prediction is a 3D NumPy
            array with shape (num_samples, horizon, num_targets).
        model_names: List of model names corresponding to the predictions.
        ensemble_strategy: Strategy for combining predictions, one of
            EnsembleStrategy.MEAN, EnsembleStrategy.MEDIAN, or
            EnsembleStrategy.WEIGHTED.
        ensemble_weights: Dictionary mapping model names to their weights for the
            weighted ensemble strategy. Required if ensemble_strategy is
            EnsembleStrategy.WEIGHTED. Defaults to None.

    Returns:
        A 3D NumPy array of ensemble predictions with shape
        (num_samples, horizon, num_targets).

    Raises:
        ValueError: If predictions is empty, prediction shapes are inconsistent,
            weights are required but not provided, the number of weights does not
            match the number of models, or the ensemble strategy is unknown.
    """
    if not predictions:
        raise ValueError("At least one prediction is required.")
    shapes = [p.shape for p in predictions]
    if len(set(shapes)) > 1:
        raise ValueError(f"Inconsistent prediction shapes: {shapes}")
    num_samples, horizon, num_targets = shapes[0]
    pred_array = np.stack(predictions, axis=-1)
    if ensemble_strategy == EnsembleStrategy.MEAN:
        return np.mean(pred_array, axis=-1)
    if ensemble_strategy == EnsembleStrategy.MEDIAN:
        return np.median(pred_array, axis=-1)
    if ensemble_strategy == EnsembleStrategy.WEIGHTED:
        if not ensemble_weights:
            raise ValueError("Weights required for weighted ensemble strategy.")
        unknown_keys = set(ensemble_weights) - set(model_names)
        if unknown_keys:
            raise ValueError(
                f"ensemble_weights contains unknown model names: {unknown_keys}. Valid model names: {model_names}",
            )
        weights = np.array([ensemble_weights.get(name, 0.0) for name in model_names])
        if len(weights) != pred_array.shape[-1]:
            raise ValueError("Number of weights must match number of models.")
        total = weights.sum()
        if not np.isclose(total, 1.0, atol=1e-6):
            raise ValueError(
                f"ensemble_weights must sum to 1.0, got {total:.6f}. Normalize your weights before passing them.",
            )
        return np.einsum("ntcm,m->ntc", pred_array, weights)
    raise ValueError(f"Unknown ensemble strategy: {ensemble_strategy}")
