from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

from twiga.core.config import BaseModelConfig, ConformalConfig, DataPipelineConfig, ForecasterConfig
from twiga.core.data.pipeline import DataPipeline
from twiga.distributions.conformal.core import Conformal

if TYPE_CHECKING:
    from twiga.core.explain import ShapResult

from .base import BaseForecaster
from .result import ForecastKind, RawPrediction

# Maps (arch_name, distribution) → concrete model name used by the registry.
# Only base arch configs (mlpf, mlpgam, mlpgaf) participate; all other configs
# are passed through unchanged.
_DISTRIBUTION_MAP: dict[str, dict[str, str]] = {
    "mlpf": {
        "normal": "mlpfnormal",
        "laplace": "mlpflaplace",
        "lognormal": "mlpflognormal",
        "gamma": "mlpfgamma",
        "beta": "mlpfbeta",
        "qr": "mlpfqr",
        "fpqr": "mlpffpqr",
        "crc": "mlpfcrc",
    },
    "mlpgam": {
        "normal": "mlpgamnormal",
        "laplace": "mlpgamlaplace",
        "lognormal": "mlpgamlognormal",
        "gamma": "mlpgamgamma",
        "beta": "mlpgambeta",
        "studentt": "mlpgamstudentt",
        "qr": "mlpgamqr",
        "fpqr": "mlpgamfpqr",
        "crc": "mlpgamcrc",
    },
    "mlpgaf": {
        "normal": "mlpgafnormal",
        "laplace": "mlpgaflaplace",
        "lognormal": "mlpgaflognormal",
        "gamma": "mlpgafgamma",
        "beta": "mlpgafbeta",
        "studentt": "mlpgafstudentt",
        "qr": "mlpgafqr",
        "fpqr": "mlpgaffpqr",
        "crc": "mlpgafcrc",
    },
    "nhits": {
        "normal": "nhitsnormal",
        "laplace": "nhitslaplace",
        "lognormal": "nhitslognormal",
        "gamma": "nhitsgamma",
        "beta": "nhitsbeta",
        "studentt": "nhitsstudentt",
        "qr": "nhitsqr",
        "fpqr": "nhitsfpqr",
    },
}


class TwigaForecaster(BaseForecaster):
    """Machine Learning Forecaster for time series predictions.

    This forecaster initializes a data pipeline and dynamically loads machine learning
    models based on provided configurations. The configurations can be specified as Pydantic
    models or dictionaries. Once the models are loaded, they can be trained, evaluated,
    and backtested.

    Example:
        >>> from twiga.core.config import BaseModelConfig, DataPipelineConfig, ForecasterConfig
        >>> data_params = DataPipelineConfig(date_column="date", ...)
        >>> model_config = BaseModelConfig(name="linear", ...)
        >>> train_params = ForecasterConfig(...)
        >>> forecaster = TwigaForecaster(data_params, model_config, train_params)
        >>> forecaster.fit(train_df)
        >>> predictions, metrics = forecaster.evaluate_point_forecast(test_df)
    """

    def __init__(
        self,
        data_params: DataPipelineConfig,
        model_params: BaseModelConfig | list[BaseModelConfig] | dict | list[dict],
        train_params: ForecasterConfig,
        conformal_params: ConformalConfig | None = None,
    ) -> None:
        """Initialize TwigaForecaster.

        Args:
            data_params: Configuration for the data pipeline.
            model_params: Configuration for the model(s). Can be a single Pydantic config,
                a dictionary, or a list of either. Neural network configs with unset dims
                (``num_target_feature``, ``forecast_horizon``, ``lookback_window_size`` equal
                to 0) are auto-populated from *data_params*. Base arch configs with a
                ``distribution`` field set are automatically resolved to the corresponding
                probabilistic variant (e.g. ``MLPFConfig(distribution='normal')`` becomes
                an ``MLPFNormalConfig``).
            train_params: Training configuration parameters.
            conformal_params: Optional conformal prediction configuration.
        """
        # Set the date column in the training parameters.
        train_params.date_column = data_params.date_column
        super().__init__(**train_params.model_dump())

        self.data_pipeline = DataPipeline(**data_params.model_dump())
        self.domain = "ml"
        self.models = []
        self.conformal = {}  # type: ignore[var-annotated]

        # Pre-process NN configs before registry lookup.
        model_params = self._resolve_distribution(model_params)  # type: ignore[assignment]
        model_params = self._auto_fill_nn_dims(model_params, data_params)  # type: ignore[arg-type, assignment]

        self.get_model_from_registry(model_params)  # type: ignore[arg-type]
        self.conformal_params = conformal_params

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_distribution(
        model_params: BaseModelConfig | list[BaseModelConfig] | dict | list[dict],
    ) -> list[BaseModelConfig | dict]:
        """Resolve ``distribution`` field on base arch configs to concrete classes.

        If a config is one of the base MLP architectures (mlpf / mlpgam / mlpgaf) and
        has a non-None ``distribution`` attribute, this method looks up the concrete
        probabilistic variant name in :data:`_DISTRIBUTION_MAP`, loads the corresponding
        config class via the registry, and returns a new instance carrying all original
        field values.

        Configs without a ``distribution`` field, or with ``distribution=None``, are
        returned unchanged.
        """
        import importlib

        if isinstance(model_params, (BaseModelConfig, dict)):
            model_params = [model_params]  # type: ignore[assignment]

        result = []
        for cfg in model_params:
            if isinstance(cfg, BaseModelConfig):
                dist = getattr(cfg, "distribution", None)
                arch = getattr(cfg, "name", None)
                if dist is not None and arch in _DISTRIBUTION_MAP:
                    variant_map = _DISTRIBUTION_MAP[arch]
                    if dist not in variant_map:
                        raise ValueError(
                            f"Unknown distribution {dist!r} for {arch!r}. Valid options: {sorted(variant_map)}",
                        )
                    target_name = variant_map[dist]
                    # Use case-insensitive lookup to find the concrete config class,
                    # because the registry's `name.upper()` convention breaks for
                    # CamelCase names like MLPFLaplaceConfig → mlpflaplace.
                    module = importlib.import_module(f"twiga.models.nn.{target_name}_model")
                    target_config_cls = next(
                        (getattr(module, attr) for attr in dir(module) if attr.lower() == f"{target_name}config"),
                        None,
                    )
                    if target_config_cls is None:
                        raise ImportError(
                            f"Could not find a config class for '{target_name}' in twiga.models.nn.{target_name}_model",
                        )
                    # Rebuild config using the concrete class; 'distribution' is excluded
                    # from model_dump() so it won't be passed as an unknown kwarg.
                    # Extra fields (e.g. n_quantiles, conf_level from FPQR) are included
                    # in model_dump() because BaseModelConfig uses extra="allow".
                    cfg = target_config_cls(**cfg.model_dump())
            result.append(cfg)
        return result  # type: ignore[return-value]

    @staticmethod
    def _auto_fill_nn_dims(
        model_params: list[BaseModelConfig | dict],
        data_params: DataPipelineConfig,
    ) -> list[BaseModelConfig | dict]:
        """Fill sentinel-zero NN dims from *data_params*.

        For any config that is an instance of :class:`~twiga.core.config.neural.BaseMLPConfig`
        where one of ``num_target_feature``, ``forecast_horizon``, or
        ``lookback_window_size`` is still at its default of 0, all six dimension fields
        are populated from *data_params*.  Configs with explicitly set (non-zero) dims
        are left untouched.
        """
        from twiga.core.config.neural import BaseMLPConfig

        target = data_params.target_feature
        num_targets = len(target) if isinstance(target, list) else 1

        dim_updates = {
            "num_target_feature": num_targets,
            "num_historical_features": len(data_params.historical_features or []),
            "num_calendar_features": len(data_params.calendar_features or []),
            "num_exogenous_features": len(data_params.exogenous_features or []),
            "num_future_covariates": len(data_params.future_covariates or []),
            "forecast_horizon": data_params.forecast_horizon,
            "lookback_window_size": data_params.lookback_window_size,
        }

        result = []
        for cfg in model_params:
            if isinstance(cfg, BaseMLPConfig) and (
                cfg.num_target_feature == 0 or cfg.forecast_horizon == 0 or cfg.lookback_window_size == 0
            ):
                cfg = cfg.model_copy(update=dim_updates)
            result.append(cfg)
        return result

    # ------------------------------------------------------------------
    # Public methods
    # ------------------------------------------------------------------

    def calibrate(
        self,
        calibrate_df: pd.DataFrame | None = None,
        covariate_df: pd.DataFrame | None = None,
        ensemble_strategy: str | None = None,
        ensemble_weights: dict[str, float] | None = None,
    ) -> None:
        """Calibrate conformal prediction models using calibration data.

        Args:
            calibrate_df: Calibration dataset. If None, uses the stored training data.
            covariate_df: Optional covariate dataset.
            ensemble_strategy: Strategy for combining model predictions.
            ensemble_weights: Weights for weighted ensemble strategy.

        Raises:
            ValueError: If ``conformal_params`` is not set.
        """
        self.conformal.clear()
        if self.conformal_params is None:
            raise ValueError("Conformal parameters are not set. Cannot calibrate.")

        calibrate_df = self.prepare_test_data(test_df=calibrate_df)
        _, ground_truth = self.get_ground_truth(test_df=calibrate_df)

        prediction_dict, _ = self.predict(
            test_df=calibrate_df,
            covariate_df=covariate_df,
            ensemble_strategy=ensemble_strategy,
            ensemble_weights=ensemble_weights,
            prepare_test_data=False,
        )

        for model_name, forecast in prediction_dict.items():
            conf_model = Conformal(
                method=self.conformal_params.method,
                score_type=self.conformal_params.score_type,
                alpha=self.conformal_params.alpha,
            )

            method = self.conformal_params.method
            if method == "quantile":
                # QR models: quantiles stored in RawPrediction.quantiles or
                # the legacy (loc, quantiles_hat) 2-tuple.
                if isinstance(forecast, RawPrediction):
                    if forecast.quantiles is None:
                        raise ValueError(
                            "conformal method='quantile' requires a QR RawPrediction with quantiles field set.",
                        )
                    quantiles_hat = forecast.quantiles
                elif isinstance(forecast, tuple):
                    _, quantiles_hat = forecast
                else:
                    raise ValueError(
                        "conformal method='quantile' requires a QR model "
                        "returning RawPrediction(kind=QUANTILE) or (loc, quantiles_hat).",
                    )
                lower = quantiles_hat[:, 0, :, :]
                upper = quantiles_hat[:, -1, :, :]
                conf_model.calibrate(lower, upper, ground_truth)

            elif method == "residual-fitting":
                # Gaussian/scale models: scale in RawPrediction.scale.
                if isinstance(forecast, RawPrediction):
                    if forecast.scale is None:
                        raise ValueError(
                            "conformal method='residual-fitting' requires a parametric RawPrediction "
                            "with scale field set.",
                        )
                    loc, sigma = forecast.loc, forecast.scale
                elif isinstance(forecast, dict):
                    loc, sigma = forecast["loc"], forecast["scale"]
                elif isinstance(forecast, tuple):
                    loc, sigma = forecast[0], forecast[1]
                else:
                    raise ValueError(
                        "conformal method='residual-fitting' requires a model returning both loc and scale.",
                    )
                conf_model.calibrate(loc, sigma, ground_truth)

            else:
                # method="residual" - SplitConformal expects (loc, targets)
                if isinstance(forecast, RawPrediction):
                    loc = forecast.loc
                elif isinstance(forecast, dict):
                    loc = forecast["loc"]
                elif isinstance(forecast, tuple):
                    loc = forecast[0]
                else:
                    loc = forecast
                conf_model.calibrate(loc, ground_truth)  # type: ignore[attr-defined]

            self.conformal[model_name] = conf_model

    def explain(
        self,
        X: np.ndarray,
        model_idx: int = 0,
        n_background: int = 100,
    ) -> ShapResult:
        """Compute SHAP feature attributions for a fitted ML model.

        Builds a :class:`~twiga.core.explain.ShapExplainer` for the model at
        position *model_idx* in ``self.models``, runs SHAP over *X*, and returns
        a :class:`~twiga.core.explain.ShapResult` with values reshaped to
        ``(B, L, F)`` - one attribution per sample, per lookback step, per feature.

        Only ML models (``domain="ml"``) are supported.  Neural-network models
        require gradient-based attribution and are not currently handled.

        Args:
            X: Feature array of shape ``(B, L, F)`` as produced by the data
                pipeline (e.g. from ``DataPipeline.transform()``).
            model_idx: Index into ``self.models`` of the model to explain.
                Defaults to ``0`` (the first / only model).
            n_background: Number of background samples for ``LinearExplainer``
                and ``KernelExplainer``.  Ignored for tree models.

        Returns:
            :class:`~twiga.core.explain.ShapResult` with:

            - ``values``  - SHAP array ``(B, L, F)``
            - ``feature_names``  - original F feature names
            - ``timestep_labels``  - L lookback labels (``'t-L+1'`` … ``'t0'``)
            - ``expected_value``  - SHAP base value (mean prediction)

        Raises:
            IndexError: If *model_idx* is out of range.
            RuntimeError: If no models are fitted or the domain is not ``"ml"``.
            ImportError: If ``shap`` is not installed.

        Example:
            >>> result = forecaster.explain(X_test)
            >>> result.plot_importance(top_n=20)
            >>> importance = result.mean_importance()
        """
        from twiga.core.explain import ShapExplainer  # lazy: requires explain extra

        if not self.models:
            raise RuntimeError("No fitted models found. Call fit() before explain().")
        if model_idx >= len(self.models):
            raise IndexError(f"model_idx={model_idx} is out of range; forecaster has {len(self.models)} model(s).")
        model = self.models[model_idx]
        explainer = ShapExplainer(model, self.data_pipeline)
        return explainer.explain(X, n_background=n_background)
