"""Forecast result containers for Twiga.

This module defines the core data structures used to represent, store,
and convert model forecast outputs - primarily :class:`ForecastResult`
and :class:`ForecastCollection`.

Key design choices:
- Kind-aware results avoid isinstance checks downstream
- NumPy arrays are kept until explicit .to_dataframe() call
- Ground truth is optional (present in evaluation, absent in prediction)
- Sample-based forecasts are summarized to quantiles in DataFrame output
- :class:`RawPrediction` provides a typed intermediate container between
  raw model output and inverse-scaled :class:`ForecastResult`, eliminating
  the ``isinstance(pred, dict | tuple | ndarray)`` chain in rescaling.
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from enum import StrEnum

import numpy as np
import pandas as pd

__all__ = ["ForecastCollection", "ForecastKind", "ForecastResult", "RawPrediction"]

_SAMPLE_SUMMARY_QUANTILES = (0.1, 0.5, 0.9)


class ForecastKind(StrEnum):
    """Supported forecast output types.

    Values are strings and can be used directly as dict keys.
    """

    POINT = "point"
    PARAMETRIC = "parametric"
    QUANTILE = "quantile"
    SAMPLES = "samples"
    INTERVAL = "interval"


@dataclass
class RawPrediction:
    """Typed intermediate container for unscaled model output.

    Sits between the model's ``forward()`` / ``forecast()`` call and the
    inverse-scaling step, replacing the untyped ``np.ndarray | dict | tuple``
    union.  Only ``loc`` is required; the remaining fields are populated
    according to the model's output kind.

    Attributes:
        loc: Point predictions (mean/median), shape ``(B, H, T)``.
        kind: Determines which optional arrays are expected.
        scale: Parametric std-dev / scale, same shape as ``loc``.
        quantiles: shape ``(B, N_q, H, T)``.
        quantile_levels: Corresponding probability levels.
        samples: shape ``(B, N_samples, H, T)``.
        conf_level: Coverage levels for conformal methods.
    """

    loc: np.ndarray
    kind: ForecastKind = ForecastKind.POINT

    # INTERVAL kind
    lower: np.ndarray | None = None
    upper: np.ndarray | None = None

    # PARAMETRIC kind
    scale: np.ndarray | None = None

    # QUANTILE kind
    quantiles: np.ndarray | None = None
    quantile_levels: list[float] | np.ndarray | None = None
    conf_level: list[float] | np.ndarray | None = None

    # SAMPLES kind
    samples: np.ndarray | None = None

    @classmethod
    def from_model_output(
        cls,
        output: np.ndarray | dict[str, np.ndarray] | tuple[np.ndarray, ...],
    ) -> RawPrediction:
        """Build a :class:`RawPrediction` from a raw model ``forecast()`` output.

        Supports:
        * ``np.ndarray`` - point forecast.
        * ``tuple[lower, loc, upper]`` - conformal interval (3-element).
        * ``dict`` with key ``"loc"`` - parametric / quantile / sample / point.

        Args:
            output: Raw model output in one of the supported formats.

        Returns:
            A typed :class:`RawPrediction` instance.

        Raises:
            TypeError: If *output* is not a supported type.
            ValueError: If a dict lacks ``"loc"``, or a tuple does not have
                exactly three elements.
        """
        if isinstance(output, np.ndarray):
            return cls(loc=output, kind=ForecastKind.POINT)

        if isinstance(output, tuple):
            if len(output) != 3:
                raise ValueError(
                    f"Tuple model output must have exactly 3 elements (lower, loc, upper), got {len(output)}."
                )
            lower, loc, upper = output
            return cls(loc=loc, lower=lower, upper=upper, kind=ForecastKind.INTERVAL)

        if isinstance(output, dict):
            if "loc" not in output:
                raise ValueError("Dict model output must contain the key 'loc'.")
            loc = output["loc"]

            if "scale" in output:
                return cls(loc=loc, scale=output["scale"], kind=ForecastKind.PARAMETRIC)
            if "quantiles" in output:
                return cls(
                    loc=loc,
                    quantiles=output["quantiles"],
                    quantile_levels=output.get("quantile_levels"),
                    conf_level=output.get("conf_level"),
                    kind=ForecastKind.QUANTILE,
                )
            if "samples" in output:
                return cls(loc=loc, samples=output["samples"], kind=ForecastKind.SAMPLES)
            return cls(loc=loc, kind=ForecastKind.POINT)

        raise TypeError(
            f"Unsupported model output type {type(output).__name__!r}. Expected np.ndarray, tuple, or dict."
        )


@dataclass
class ForecastResult:
    """Container for one model's forecast output.

    Attributes:
        timestamps: shape (n_batch, n_horizon, n_targets)
        loc: point predictions (mean/median), shape (n_batch, n_horizon, n_targets)
        targets: ordered list of target variable names
        model_name: human-readable model identifier
        kind: determines which optional arrays are expected and how to convert
        ground_truth: optional, same shape as loc
        scale: parametric std-dev / scale, same shape as loc
        quantiles: shape (n_batch, n_q, n_horizon, n_targets)
        quantile_levels: corresponding probability levels (e.g. [0.1, 0.5, 0.9])
        samples: shape (n_batch, n_samples, n_horizon, n_targets)
        lower: lower bound, same shape as loc
        upper: upper bound, same shape as loc
        inference_time: inference duration in seconds
        conf_level:
        metric_name:
    """

    # Required
    timestamps: np.ndarray
    loc: np.ndarray
    targets: list[str]
    model_name: str
    kind: ForecastKind

    # Optional ground truth
    ground_truth: np.ndarray | None = None

    # Kind-specific (checked in __post_init__)
    scale: np.ndarray | None = None
    quantiles: np.ndarray | None = None
    quantile_levels: list[float] | np.ndarray | None = None
    conf_level: list[float] | np.ndarray | None = None
    samples: np.ndarray | None = None
    lower: np.ndarray | None = None
    upper: np.ndarray | None = None

    # Metadata
    inference_time: float = 0.0

    def __post_init__(self) -> None:
        """Validate required fields for the given kind."""
        required = {
            ForecastKind.PARAMETRIC: ["scale"],
            ForecastKind.QUANTILE: ["quantiles"],
            ForecastKind.SAMPLES: ["samples"],
            ForecastKind.INTERVAL: ["lower", "upper"],
        }.get(self.kind, [])

        missing = [f for f in required if getattr(self, f) is None]
        if missing:
            raise ValueError(f"ForecastResult(kind={self.kind.value!r}) missing fields: {missing}")

    def to_dataframe(self, fmt: str = "long") -> pd.DataFrame:
        """Convert forecast to tidy DataFrame.

        Always includes: timestamp, target, model, forecast.
        Optional: actual (when ground_truth is present).

        Additional columns depend on forecast kind:

        - ``POINT``: no extra columns
        - ``PARAMETRIC``: scale
        - ``INTERVAL``: lower, upper
        - ``QUANTILE`` (fmt="wide"): q_0.10, q_0.50, ...
        - ``QUANTILE`` (fmt="long"): q_level, quantile_forecast
        - ``SAMPLES``: q_0.10, q_0.50, q_0.90 (empirical quantiles)

        Args:
            fmt: "long" (default) or "wide" - only affects QUANTILE

        Returns:
            pandas DataFrame in long or wide format

        Raises:
            ValueError: if fmt is invalid
        """
        if fmt not in {"long", "wide"}:
            raise ValueError(f"fmt must be 'long' or 'wide', got {fmt!r}")

        n_batch, n_horizon, n_targets = self.loc.shape
        n_steps = n_batch * n_horizon

        ts_flat = pd.to_datetime(self.timestamps[:, :, 0].flatten(), unit="ns", utc=True)
        timestamps_col = np.repeat(ts_flat, n_targets)
        targets_col = np.tile(self.targets, n_steps)
        forecast_col = self.loc.reshape(-1)

        data = {
            "timestamp": timestamps_col,
            "target": targets_col,
            "model": self.model_name,
            "forecast": forecast_col,
        }

        if self.ground_truth is not None:
            data["actual"] = self.ground_truth.reshape(-1)

        df = pd.DataFrame(data)

        if self.kind == ForecastKind.PARAMETRIC:
            df["scale"] = self.scale.reshape(-1)  # type: ignore[union-attr]

        elif self.kind == ForecastKind.INTERVAL:
            df["lower"] = self.lower.reshape(-1)  # type: ignore[union-attr]
            df["upper"] = self.upper.reshape(-1)  # type: ignore[union-attr]

        elif self.kind == ForecastKind.QUANTILE:
            n_q = self.quantiles.shape[1]  # type: ignore[union-attr]
            # Derive representative 1-D levels for column naming.
            # quantile_levels may be a list, 1-D array, or a 3-D ndarray (B, N, T)
            # from FPQR; in the latter cases we average to get a flat (N,) array.
            raw_levels = self.quantile_levels
            if isinstance(raw_levels, np.ndarray):
                if raw_levels.ndim == 3:
                    levels: list | np.ndarray = raw_levels.mean(axis=(0, 2))  # (N,)
                elif raw_levels.ndim == 2:
                    levels = raw_levels.mean(axis=1)  # (N,)
                else:
                    levels = raw_levels
            else:
                levels = raw_levels or list(range(n_q))

            if fmt == "wide":
                for i, lvl in enumerate(levels):
                    col = f"q_{lvl:.2f}" if isinstance(lvl, float) else f"q_{lvl}"
                    df[col] = self.quantiles[:, i].reshape(-1)  # type: ignore[union-attr, index]
            else:
                frames = []
                for i, lvl in enumerate(levels):
                    sub = df.copy()
                    sub["q_level"] = lvl
                    sub["quantile_forecast"] = self.quantiles[:, i].reshape(-1)  # type: ignore[union-attr, index]
                    frames.append(sub)
                return pd.concat(frames, ignore_index=True)

        elif self.kind == ForecastKind.SAMPLES:
            sorted_samples = np.sort(self.samples, axis=1)  # type: ignore[union-attr, arg-type]
            n = sorted_samples.shape[1]
            for q in _SAMPLE_SUMMARY_QUANTILES:
                idx = int(q * (n - 1))
                df[f"q_{q:.2f}"] = sorted_samples[:, idx].reshape(-1)

        return df

    def evaluate(
        self,
        ground_truth: np.ndarray | None = None,
        **kwargs,
    ) -> pd.DataFrame:
        """Evaluate forecast against ground truth using kind-appropriate metrics.

        Forwards to :func:`twiga.core.metrics.evaluate_forecast`.

        Args:
            ground_truth: shape ``(n_batch, n_horizon, n_targets)``.  When
                omitted the ``ground_truth`` stored on the result is used.
            **kwargs: forwarded to the underlying evaluate function.

        Returns:
            DataFrame of per-day, per-target metrics.

        Raises:
            ValueError: if no ground truth is available.
        """
        from twiga.core.metrics import evaluate_forecast

        gt = ground_truth if ground_truth is not None else self.ground_truth
        if gt is None:
            raise ValueError("ground_truth must be provided to evaluate() or stored on the ForecastResult.")
        # Attach gt to a copy so we don't mutate self when it wasn't stored.
        obj = self if self.ground_truth is not None else dataclasses.replace(self, ground_truth=gt)
        return evaluate_forecast(obj, **kwargs)


@dataclass
class ForecastCollection:
    """Collection of ForecastResult objects from multiple models."""

    results: dict[str, ForecastResult] = field(default_factory=dict)

    def __getitem__(self, model_name: str) -> ForecastResult:
        return self.results[model_name]

    def __contains__(self, model_name: object) -> bool:
        return model_name in self.results

    def __iter__(self):
        return iter(self.results.values())

    def __len__(self) -> int:
        return len(self.results)

    def add(self, result: ForecastResult) -> None:
        """Add or replace result using its model_name as key."""
        self.results[result.model_name] = result

    @property
    def model_names(self) -> list[str]:
        return list(self.results.keys())

    def to_dataframe(self, fmt: str = "long") -> pd.DataFrame:
        """Concatenate all model forecasts into one DataFrame.

        Args:
            fmt: passed to each ForecastResult.to_dataframe()

        Returns:
            Combined long-format DataFrame

        Raises:
            ValueError: if collection is empty
        """
        if not self.results:
            raise ValueError("ForecastCollection is empty")

        return pd.concat(
            [r.to_dataframe(fmt=fmt) for r in self.results.values()],
            ignore_index=True,
        )
