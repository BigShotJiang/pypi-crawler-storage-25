import importlib
from typing import Any

# Cache to store loaded models and configs
_model_cache: dict[str, dict[str, type]] = {}


def get_model(name: str, domain: str | None = None) -> tuple[type, type]:
    """Lazily load the model and config classes from models/ml/ or models/nn/.

    Args:
        name (str): The name of the model (e.g., "linear", "lstm").
        domain (str, optional): The specific domain to look in ("ml" or "nn").
                                If None, searches both.

    Returns:
        tuple[Type, Type]: A tuple of (model_class, config_class).

    Raises:
        ValueError: If the model is not found in the specified or default domains.
    """
    # Check if the model is already cached
    if name in _model_cache:
        return _model_cache[name]["model"], _model_cache[name]["config"]

    # Define which domains to search
    domains = [domain] if domain else ["ml", "nn", "baseline"]

    # Try importing from each domain
    for dir_name in domains:
        module_name = f"models.{dir_name}.{name}_model"  # e.g., "models.ml.linear_model"
        try:
            # Import the module dynamically
            module = importlib.import_module(f"twiga.{module_name}")
            # Primary lookup: exact uppercase (e.g. "catboost" → "CATBOOSTModel")
            upper = name.upper()
            if hasattr(module, f"{upper}Model"):
                model_cls = getattr(module, f"{upper}Model")
                config_cls = getattr(module, f"{upper}Config")
            else:
                # Fallback: find the unique class ending with "Model" / "Config"
                # (handles compound names like "mlpfstudentt" → "MLPFStudentTModel")
                import inspect

                model_candidates = [
                    v
                    for k, v in inspect.getmembers(module, inspect.isclass)
                    if k.endswith("Model") and not k.startswith("Base") and v.__module__ == module.__name__
                ]
                config_candidates = [
                    v
                    for k, v in inspect.getmembers(module, inspect.isclass)
                    if k.endswith("Config") and not k.startswith("Base") and v.__module__ == module.__name__
                ]
                if not model_candidates or not config_candidates:
                    continue
                model_cls = model_candidates[0]
                config_cls = config_candidates[0]
        except ImportError:
            continue  # Try the next domain if import fails
        else:
            # Cache the result and return if the import is successful
            _model_cache[name] = {"model": model_cls, "config": config_cls}
            return model_cls, config_cls

    # If no model is found, raise an error
    raise ValueError(
        f"Model '{name}' not found in {domains}. Ensure the file is named '{name}_model.py' in models/{domain}/",
    )


def get_model_from_dict(config_dict: dict[str, Any], domain: str | None = None) -> object:
    """Load a model instance from a configuration dictionary using the model registry.

    Args:
        config_dict (dict[str, Any]): A dictionary containing the model configuration,
                                      including the 'name' key (e.g., {"name": "linear", "param1": value}).
        domain (str, optional): The specific domain to look in ("ml" or "nn"). If None, searches both.

    Returns:
        object: An instance of the model class initialized with the provided configuration.

    Raises:
        ValueError: If 'name' is not provided in the config dictionary or if the model is not found.
        pydantic.ValidationError: If the dictionary does not match the config class's requirements.
    """
    # Extract the model name from the dictionary
    name = config_dict.get("name")
    if not name:
        raise ValueError("Model name must be provided in the config dictionary.")

    # Get the model and config classes using the registry
    model_cls, config_cls = get_model(name, domain=domain)

    # Create an instance of the config class with the dictionary
    config_cls = config_cls(**config_dict)

    # Instantiate and return the model with the config
    return model_cls, config_cls
