"""Forecaster hierarchy and model registry for Twiga."""

from twiga.forecaster.abstract import AbstractForecaster
from twiga.forecaster.base import BaseForecaster
from twiga.forecaster.core import TwigaForecaster
from twiga.forecaster.registry import get_model, get_model_from_dict
from twiga.forecaster.result import ForecastCollection, ForecastKind, ForecastResult

__all__ = [
    "AbstractForecaster",
    "BaseForecaster",
    "ForecastCollection",
    "ForecastKind",
    "ForecastResult",
    "TwigaForecaster",
    "get_model",
    "get_model_from_dict",
]
