from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any

import numpy as np
import pandas as pd

from twiga.core.config import BaseModelConfig
from twiga.core.utils.logger import get_logger

from .ensemble import EnsembleStrategy, compute_ensemble_predictions
from .registry import get_model, get_model_from_dict
from .result import ForecastCollection
from .utils import (  # type: ignore[attr-defined]
    build_forecast_result,
    build_ground_truth_df,
    build_predictions_and_metrics,
    merge_and_format_results,
    validate_shapes,
)

log = get_logger(__name__)


class AbstractForecaster(ABC):
    """Abstract base class for time series forecasters with default implementations.

    Provides implementations for fitting, evaluating, and tuning models. Subclasses must
    implement model-specific methods.
    """

    def get_model_from_registry(self, model_params: list[BaseModelConfig] | list[dict]) -> None:
        """Load and instantiate models based on the provided configurations.

        Args:
            model_params: List of model configurations as Pydantic models or dictionaries.

        Raises:
            TypeError: If model_params contains invalid types or mismatched configurations.
            ValueError: If a dictionary configuration lacks a model name.
        """
        if isinstance(model_params, BaseModelConfig | dict):
            model_params = [model_params]
        for cfg in model_params:
            if not isinstance(cfg, BaseModelConfig | dict):
                raise TypeError(f"Expected Pydantic model or dict, got {type(cfg)}")
            if isinstance(cfg, BaseModelConfig):
                model_name = cfg.name
                domain_name = cfg.domain
                model_cls, config_cls = get_model(model_name, domain=domain_name)
            else:
                model_name = cfg.get("name")  # type: ignore[assignment]
                if model_name is None:
                    raise ValueError("Model name must be provided in configuration.")
                domain_name = cfg.get("domain")  # type: ignore[assignment]
                model_cls, config_cls = get_model_from_dict(cfg, domain=domain_name)  # type: ignore[misc]
            if not isinstance(cfg, config_cls):
                raise TypeError(f"Config for '{model_name}' must be {config_cls.__name__}, got {type(cfg).__name__}")
            self.models.append(model_cls(cfg))  # type: ignore[attr-defined]

    @abstractmethod
    def _fit(self, train_df: pd.DataFrame, val_df: pd.DataFrame | None, train_ratio: float) -> None:
        """Fit a single model.

        Args:
            train_df: Training dataset.
            val_df: Validation dataset, if any.
            train_ratio: Ratio of data to use for training.
        """

    @abstractmethod
    def _evaluate(
        self,
        test_df: pd.DataFrame,
        covariate_df: pd.DataFrame | None,
        time_stamp: np.ndarray,
        ground_truth: np.ndarray,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Evaluate a single model.

        Args:
            test_df: Test dataset.
            covariate_df: Covariate dataset, if any.
            time_stamp: Timestamp data from ground truth.
            ground_truth: Ground truth data.

        Returns:
            Tuple of predictions and metrics DataFrames.
        """

    @abstractmethod
    def _tune(
        self,
        train_df: pd.DataFrame,
        val_df: pd.DataFrame,
        num_trials: int,
        reduction_factor: int,
        patience: int,
        load_if_exists: bool,
    ) -> dict[str, Any]:
        """Tune a single model's hyperparameters.

        Args:
            train_df: Training dataset.
            val_df: Validation dataset.
            num_trials: Number of trials.
            reduction_factor: Reduction factor.
            patience: Patience.
            load_if_exists: Whether to load an existing study.

        Returns:
            Dictionary of best hyperparameters.
        """

    @abstractmethod
    def _create_folder(self) -> None:
        """Create a folder for model artifacts."""

    @abstractmethod
    def prepare_test_data(self, test_df: pd.DataFrame | None) -> pd.DataFrame:
        """Prepare test data for evaluation.

        Args:
            test_df: Test dataset, if any.

        Returns:
            Processed test DataFrame.
        """

    @abstractmethod
    def get_ground_truth(self, test_df: pd.DataFrame, **kwargs) -> tuple[np.ndarray, np.ndarray]:
        """Retrieve ground truth data.

        Args:
            test_df: Test dataset.
            **kwargs: Additional keyword arguments for subclass implementations.

        Returns:
            Tuple of (timestamps, ground truth) as NumPy arrays.
        """

    @abstractmethod
    def _backtester(
        self,
        data: pd.DataFrame,
        train_ratio: float,
        start_dt: object | None,
        end_dt: object | None,
        verbose: bool,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Perform backtesting for a single model.

        Args:
            data: Complete dataset for backtesting.
            train_ratio: Ratio of data to use for training.
            start_dt: Start date for backtesting, if any.
            end_dt: End date for backtesting, if any.
            verbose: Whether to display detailed logs.

        Returns:
            Tuple of predictions and metrics DataFrames.
        """

    @abstractmethod
    def _predict(self, test_df: pd.DataFrame, covariate_df: pd.DataFrame | None) -> np.ndarray:
        """Generate predictions for a **single** model instance.

        This is the per-model implementation hook called once per model by
        :meth:`_predict_core`.  Subclasses must implement it to transform
        *test_df* through the data pipeline and return raw (scaled) predictions
        from ``self.model``.  Inverse-scaling and ensemble aggregation are
        handled by the callers; this method should not perform them.

        Args:
            test_df: Test dataset (already prepared by :meth:`prepare_test_data`).
            covariate_df: Dataset with additional covariates, if any.

        Returns:
            3D NumPy array of predictions with shape
            ``(num_sequences, forecast_horizon, num_targets)``,
            or a dict/tuple of such arrays for probabilistic models.
        """

    def fit(
        self,
        train_df: pd.DataFrame,
        val_df: pd.DataFrame | None = None,
        train_ratio: float = 1.0,
    ) -> None:
        """Fit the forecaster models using training and optional validation data.

        Args:
            train_df: Training dataset.
            val_df: Validation dataset, if any.
            train_ratio: Ratio of data to use for training.
        """
        required_cols = (
            [self.data_pipeline.target_feature]  # type: ignore[attr-defined]
            if isinstance(self.data_pipeline.target_feature, str)  # type: ignore[attr-defined]
            else list(self.data_pipeline.target_feature)  # type: ignore[attr-defined]
        )
        missing = [c for c in required_cols if c not in train_df.columns]
        if missing:
            raise ValueError(f"train_df is missing required target column(s): {missing}")
        if self.data_pipeline.date_column not in train_df.columns:  # type: ignore[attr-defined]
            raise ValueError(f"train_df is missing date column: {self.data_pipeline.date_column!r}")  # type: ignore[attr-defined]

        if self.data_pipeline.data_pipeline is None:  # type: ignore[attr-defined]
            self.data_pipeline.fit(train_df.copy())  # type: ignore[attr-defined]
        for model in self.models:  # type: ignore[attr-defined]
            self.model = model
            self.model_type = model.model_config.name
            self.domain = model.model_config.domain
            self._create_folder()
            self._fit(train_df=train_df, val_df=val_df, train_ratio=train_ratio)

    def _predict_core(
        self,
        test_df: pd.DataFrame,
        covariate_df: pd.DataFrame | None = None,
        ensemble_strategy: str | None = None,
        ensemble_weights: dict[str, float] | None = None,
        prepare_test_data: bool = True,
        is_interval: bool = False,
    ) -> tuple[dict, dict[str, float]]:
        """Multi-model orchestration layer for point or interval forecasts.

        Iterates over every model in ``self.models``, delegates to
        :meth:`_predict` for each one, optionally wraps the output in
        conformal prediction intervals, then aggregates into an ensemble when
        requested.  This method is the single internal entry point called by
        both :meth:`predict` (``is_interval=False``) and
        :meth:`predict_interval` (``is_interval=True``).

        Args:
            test_df: Test dataset.
            covariate_df: Dataset with additional covariates, if any.
            ensemble_strategy: Strategy for combining model predictions, if any.
            ensemble_weights: Weights for weighted ensemble strategy, if any.
            prepare_test_data: Whether to preprocess the test data via
                :meth:`prepare_test_data` before iterating over models.
                Pass ``False`` when the caller has already prepared the data.
            is_interval: When ``True``, wraps each model's point predictions
                with calibrated conformal intervals using ``self.conformal``.

        Returns:
            Tuple of:
                - Dictionary mapping model names to predictions (np.ndarray for
                  point forecasts, tuple[np.ndarray, np.ndarray, np.ndarray]
                  for interval forecasts).
                - Dictionary mapping model names to inference times (seconds).

        Raises:
            ValueError: If no models are available, predictions are not 3D
                arrays, or conformal settings are missing/uncalibrated when
                ``is_interval=True``.
        """
        if not self.models:  # type: ignore[attr-defined]
            raise ValueError("No models available for prediction.")
        if is_interval:
            if self.conformal_params is None:  # type: ignore[attr-defined]
                raise ValueError("Conformal parameters are not set.")
            if not self.conformal:  # type: ignore[attr-defined]
                raise ValueError("Conformal model is not calibrated.")
        if prepare_test_data:
            test_df = self.prepare_test_data(test_df)
        predictions = []
        model_names = []
        test_times = {}
        for model in self.models:  # type: ignore[attr-defined]
            self.model = model
            self.model_type = model.model_config.name
            self.domain = model.model_config.domain
            forecast = self._predict(test_df, covariate_df)

            # Extract the point-prediction array regardless of the return type.
            # _predict() now always returns RawPrediction; the legacy branches
            # below guard against any caller that still bypasses _rescale_raw().
            from twiga.forecaster.result import RawPrediction

            if isinstance(forecast, RawPrediction):
                loc = forecast.loc
            elif isinstance(forecast, dict):
                loc = forecast["loc"]
            elif isinstance(forecast, tuple):
                loc = forecast[0]
            else:
                loc = forecast

            if not isinstance(loc, np.ndarray) or loc.ndim != 3:
                raise ValueError(f"Expected 3D NumPy array from _predict for {self.model_type}, got {type(forecast)}")
            if is_interval:
                if self.model_type not in self.conformal:  # type: ignore[attr-defined]
                    raise ValueError(f"Conformal model for {self.model_type} is not calibrated.")
                conformal_model = self.conformal[self.model_type]  # type: ignore[attr-defined]
                from twiga.distributions.conformal.cqr import ConformalQuantileRegressor

                if isinstance(conformal_model, ConformalQuantileRegressor):
                    # QR forecast: quantiles are stored in RawPrediction.quantiles
                    # or the legacy tuple second element.
                    if isinstance(forecast, RawPrediction) and forecast.quantiles is not None:
                        quantiles_hat = forecast.quantiles
                    elif isinstance(forecast, tuple) and len(forecast) == 2:
                        _, quantiles_hat = forecast
                    else:
                        raise TypeError(
                            "ConformalQuantileRegressor requires a QR model; "
                            "expected RawPrediction with quantiles or a 2-tuple.",
                        )
                    q_lower = quantiles_hat[:, 0, :, :]
                    q_upper = quantiles_hat[:, -1, :, :]
                    lower, upper = conformal_model.generate_intervals(q_lower, q_upper)
                else:
                    lower, upper = conformal_model.generate_intervals(loc)
                predictions.append((lower, loc, upper))
            else:
                predictions.append(loc)
            model_names.append(self.model_type)
            test_times[self.model_type] = self.test_walltime or 0.0  # type: ignore[attr-defined]
        prediction_dict = dict(zip(model_names, predictions, strict=True))
        if ensemble_strategy and len(predictions) > 1 and isinstance(loc, np.ndarray):
            ensemble_strategy = EnsembleStrategy(ensemble_strategy)
            ensemble_pred = self._get_ensemble_predictions(
                predictions,
                model_names,
                ensemble_strategy,
                ensemble_weights,
                is_interval,
            )
            prediction_dict["Ensemble"] = ensemble_pred
            test_times["Ensemble"] = np.mean(list(test_times.values()))
        return prediction_dict, test_times

    def _get_ensemble_predictions(
        self,
        predictions: list,
        model_names: list[str],
        ensemble_strategy: EnsembleStrategy,
        ensemble_weights: dict[str, float] | None,
        is_interval: bool,
    ) -> np.ndarray | tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Generate ensemble predictions from individual model predictions.

        Args:
            predictions: List of model predictions (np.ndarray or tuple of np.ndarray).
            model_names: List of model names.
            ensemble_strategy: Strategy for combining predictions.
            ensemble_weights: Weights for weighted ensemble, if any.
            is_interval: Whether predictions include conformal intervals.

        Returns:
            Ensemble prediction (np.ndarray for point forecasts, tuple[np.ndarray, np.ndarray, np.ndarray]
            for interval forecasts).
        """
        if is_interval:
            lower_preds = [pred[0] for pred in predictions]
            point_preds = [pred[1] for pred in predictions]
            upper_preds = [pred[2] for pred in predictions]
            ensemble_lower = compute_ensemble_predictions(lower_preds, model_names, ensemble_strategy, ensemble_weights)
            ensemble_point = compute_ensemble_predictions(point_preds, model_names, ensemble_strategy, ensemble_weights)
            ensemble_upper = compute_ensemble_predictions(upper_preds, model_names, ensemble_strategy, ensemble_weights)
            return ensemble_lower, ensemble_point, ensemble_upper

        return compute_ensemble_predictions(predictions, model_names, ensemble_strategy, ensemble_weights)

    def predict(
        self,
        test_df: pd.DataFrame,
        covariate_df: pd.DataFrame | None = None,
        ensemble_strategy: str | None = None,
        ensemble_weights: dict[str, float] | None = None,
        prepare_test_data: bool = True,
    ) -> tuple[dict[str, np.ndarray], dict[str, float]]:
        """Generate point predictions using the ensemble of forecasting models.

        Args:
            test_df: Test dataset.
            covariate_df: Dataset with additional covariates, if any.
            ensemble_strategy: Strategy for combining model predictions, if any.
            ensemble_weights: Weights for weighted ensemble strategy, if any.
            prepare_test_data: Whether to preprocess the test data.

        Returns:
            Tuple of:
                - Dictionary mapping model names to 3D NumPy array predictions.
                - Dictionary mapping model names to inference times.

        Raises:
            ValueError: If predictions are not 3D NumPy arrays.
        """
        return self._predict_core(
            test_df=test_df,
            covariate_df=covariate_df,
            ensemble_strategy=ensemble_strategy,
            ensemble_weights=ensemble_weights,
            prepare_test_data=prepare_test_data,
            is_interval=False,
        )

    def predict_interval(
        self,
        test_df: pd.DataFrame,
        covariate_df: pd.DataFrame | None = None,
        ensemble_strategy: str | None = None,
        ensemble_weights: dict[str, float] | None = None,
        prepare_test_data: bool = True,
    ) -> tuple[dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]], dict[str, float]]:
        """Generate conformal interval predictions for the given test data.

        Args:
            test_df: Test dataset.
            covariate_df: Dataset with additional covariates, if any.
            ensemble_strategy: Strategy for combining model predictions, if any.
            ensemble_weights: Weights for weighted ensemble strategy, if any.
            prepare_test_data: Whether to preprocess the test data.

        Returns:
            Tuple of:
                - Dictionary mapping model names to tuples of (lower, forecast, upper) arrays.
                - Dictionary mapping model names to inference times.

        Raises:
            ValueError: If conformal parameters or models are not set, or predictions are not 3D NumPy arrays.
        """
        return self._predict_core(
            test_df=test_df,
            covariate_df=covariate_df,
            ensemble_strategy=ensemble_strategy,
            ensemble_weights=ensemble_weights,
            prepare_test_data=prepare_test_data,
            is_interval=True,
        )

    def forecast(
        self,
        test_df: pd.DataFrame,
        covariate_df: pd.DataFrame | None = None,
        ensemble_strategy: str | None = None,
        ensemble_weights: dict[str, float] | None = None,
    ) -> ForecastCollection:
        """Generate predictions and return them as a typed :class:`~twiga.forecaster.result.ForecastCollection`.

        Unlike :meth:`predict`, this method wraps each model's output in a
        :class:`~twiga.forecaster.result.ForecastResult` with timestamps and target
        names populated, enabling structured downstream access (``to_dataframe()``,
        ``evaluate()``, etc.).

        The test data must contain the target column(s) so that timestamps can be
        aligned with the pipeline's sequence layout.  For forward-looking prediction
        where actuals are unavailable, use :meth:`predict` directly.

        Args:
            test_df: Test dataset. Must include the target column(s).
            covariate_df: Optional covariate dataset.
            ensemble_strategy: Strategy for combining model predictions.
            ensemble_weights: Weights for weighted ensemble strategy.

        Returns:
            :class:`~twiga.forecaster.result.ForecastCollection` containing one
            :class:`~twiga.forecaster.result.ForecastResult` per model (plus an
            optional ``"Ensemble"`` entry when *ensemble_strategy* is set).
        """
        test_df = self.prepare_test_data(test_df)
        # Get timestamps aligned with the prediction sequences, without ground truth.
        timestamps, _ = self.data_pipeline.get_ground_truth_sequences(test_df)  # type: ignore[attr-defined]

        prediction_dict, test_times = self._predict_core(
            test_df=test_df,
            covariate_df=covariate_df,
            ensemble_strategy=ensemble_strategy,
            ensemble_weights=ensemble_weights,
            prepare_test_data=False,
        )

        target_feature = self.data_pipeline.target_feature  # type: ignore[attr-defined]
        targets = list(target_feature) if isinstance(target_feature, str) else target_feature

        collection = ForecastCollection()
        for model_name, pred in prediction_dict.items():
            result = build_forecast_result(
                model_name=model_name,
                pred=pred,
                timestamps=timestamps,
                targets=targets,
                inference_time=test_times.get(model_name, 0.0),
            )
            collection.add(result)
        return collection

    def evaluate(
        self,
        test_df: pd.DataFrame | None = None,
        covariate_df: pd.DataFrame | None = None,
        ensemble_strategy: str | None = None,
        ensemble_weights: dict[str, float] | None = None,
        prediction_fn: Callable | None = None,
        evaluation_fn: Callable | None = None,
        is_interval: bool = False,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Evaluate forecaster models on test data, supporting point or interval forecasts.

        Args:
            test_df: Test dataset, if any. Uses default test data if None.
            covariate_df: Dataset with additional covariates, if any.
            ensemble_strategy: Strategy for combining model predictions, if any.
            ensemble_weights: Weights for weighted ensemble strategy, if any.
            prediction_fn: Function to generate predictions (e.g., predict or predict_interval).
            evaluation_fn: Function to evaluate predictions (e.g., evaluate_point_forecast or
                evaluate_interval_forecast).
            is_interval: Whether the evaluation is for interval forecasts (adds lower/upper bounds).

        Returns:
            Tuple of:
                - DataFrame with columns: timestamp, Model, target, forecast, Actual, [lower, upper]
                  (if is_interval=True).
                - DataFrame with columns: Model, target, MetricName, Value, inference-time.

        Raises:
            ValueError: If ground truth, timestamp, or prediction shapes do not match.
        """
        test_df = self.prepare_test_data(test_df)
        timestamps, ground_truth = self.get_ground_truth(test_df)
        prediction_dict, test_times = prediction_fn(  # type: ignore[misc]
            test_df=test_df,
            covariate_df=covariate_df,
            ensemble_strategy=ensemble_strategy,
            ensemble_weights=ensemble_weights,
            prepare_test_data=False,
        )
        validate_shapes(prediction_dict, timestamps, ground_truth, is_interval)
        ground_truth_df = build_ground_truth_df(timestamps, ground_truth, self.data_pipeline)  # type: ignore[attr-defined]
        predictions_df, metrics_df = build_predictions_and_metrics(
            prediction_dict,
            test_times,
            ground_truth,
            timestamps,
            evaluation_fn,
            is_interval,
            self.data_pipeline,  # type: ignore[attr-defined]
            self.metrics,  # type: ignore[attr-defined]
        )
        results_df = merge_and_format_results(predictions_df, ground_truth_df, self.data_pipeline)  # type: ignore[attr-defined]
        return results_df, metrics_df

    def evaluate_point_forecast(
        self,
        test_df: pd.DataFrame | None = None,
        covariate_df: pd.DataFrame | None = None,
        ensemble_strategy: str | None = None,
        ensemble_weights: dict[str, float] | None = None,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Evaluate point forecasts (wrapper for evaluate).

        Args:
            test_df: Test dataset, if any. Uses default test data if None.
            covariate_df: Dataset with additional covariates, if any.
            ensemble_strategy: Strategy for combining model predictions, if any.
            ensemble_weights: Weights for weighted ensemble strategy, if any.

        Returns:
            Tuple of:
                - DataFrame with columns: timestamp, Model, target, forecast, Actual.
                - DataFrame with columns: Model, target, MetricName, Value, inference-time.
        """
        return self._evaluate_core(
            expected_kind="point",
            test_df=test_df,
            covariate_df=covariate_df,
            ensemble_strategy=ensemble_strategy,
            ensemble_weights=ensemble_weights,
        )

    def evaluate_interval_forecast(
        self,
        test_df: pd.DataFrame | None = None,
        covariate_df: pd.DataFrame | None = None,
        ensemble_strategy: str | None = None,
        ensemble_weights: dict[str, float] | None = None,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Evaluate interval forecasts (wrapper for evaluate).

        Args:
            test_df: Test dataset, if any. Uses default test data if None.
            covariate_df: Dataset with additional covariates, if any.
            ensemble_strategy: Strategy for combining model predictions, if any.
            ensemble_weights: Weights for weighted ensemble strategy, if any.

        Returns:
            Tuple of:
                - DataFrame with columns: timestamp, Model, target, forecast, Actual, lower, upper.
                - DataFrame with columns: Model, target, MetricName, Value, inference-time.
        """
        return self._evaluate_core(
            expected_kind="interval",
            test_df=test_df,
            covariate_df=covariate_df,
            ensemble_strategy=ensemble_strategy,
            ensemble_weights=ensemble_weights,
            is_interval=True,
        )

    def _evaluate_core(
        self,
        expected_kind: str,
        test_df: pd.DataFrame | None,
        covariate_df: pd.DataFrame | None,
        ensemble_strategy: str | None,
        ensemble_weights: dict[str, float] | None,
        is_interval: bool = False,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Shared implementation for all evaluate methods.

        Routes predictions through ``build_forecast_result`` → ``ForecastResult.evaluate()``
        so that metric dispatch is always handled by the ``ForecastKind``-aware path in
        :func:`~twiga.core.metrics.evaluate_forecast` rather than duplicated here.

        Args:
            expected_kind: ``ForecastKind`` value string (e.g. ``"point"``, ``"interval"``,
                ``"quantile"``, ``"parametric"``).
            test_df: Test dataset (already prepared by the calling method).
            covariate_df: Optional covariate dataset.
            ensemble_strategy: Ensemble strategy name, if any.
            ensemble_weights: Ensemble weights, if any.
            is_interval: Whether to request interval predictions and include lower/upper
                bounds in the output DataFrame.

        Returns:
            ``(results_df, metrics_df)`` in the same format as ``evaluate_point_forecast``.
        """
        from .result import ForecastKind

        test_df = self.prepare_test_data(test_df)
        timestamps, ground_truth = self.get_ground_truth(test_df)
        prediction_dict, test_times = self._predict_core(
            test_df=test_df,
            covariate_df=covariate_df,
            ensemble_strategy=ensemble_strategy,
            ensemble_weights=ensemble_weights,
            prepare_test_data=False,
            is_interval=is_interval,
        )

        target_feature = self.data_pipeline.target_feature  # type: ignore[attr-defined]
        targets = [target_feature] if isinstance(target_feature, str) else list(target_feature)
        num_targets = ground_truth.shape[-1]
        timestamps_flat = pd.to_datetime(timestamps.flatten(), unit="ns", utc=True)
        predictions_data = []
        metrics_data = []

        for model_name, pred in prediction_dict.items():
            result = build_forecast_result(
                model_name=model_name,
                pred=pred,
                timestamps=timestamps,
                targets=targets,
                inference_time=test_times.get(model_name, 0.0),
            )

            if result.kind.value != expected_kind:
                raise ValueError(
                    f"Model '{model_name}' produced a '{result.kind.value}' forecast; "
                    f"expected '{expected_kind}'. Check your model and distribution config.",
                )

            # ForecastResult.evaluate() calls to_metrics_inputs() then evaluate_forecast(kind=...)
            metrics_df = result.evaluate(ground_truth)
            metrics_df["Model"] = model_name.upper()
            metrics_df["inference-time"] = test_times.get(model_name, 0.0)
            metrics_data.append(metrics_df)

            forecast_flat = result.loc.reshape(-1, num_targets)
            model_row: dict = {
                "timestamp": timestamps_flat,
                "Model": model_name.upper(),
                "target": np.tile(target_feature, len(timestamps_flat)),
                "forecast": forecast_flat.ravel(),
            }
            if is_interval and result.lower is not None and result.upper is not None:
                model_row["lower"] = result.lower.reshape(-1, num_targets).ravel()  # type: ignore[union-attr]
                model_row["upper"] = result.upper.reshape(-1, num_targets).ravel()  # type: ignore[union-attr]
            predictions_data.append(pd.DataFrame(model_row))

        predictions_df = pd.concat(predictions_data, ignore_index=True)
        metrics_df_all = pd.concat(metrics_data, ignore_index=True)
        ground_truth_df = build_ground_truth_df(timestamps, ground_truth, self.data_pipeline)  # type: ignore[attr-defined]
        results_df = merge_and_format_results(predictions_df, ground_truth_df, self.data_pipeline)  # type: ignore[attr-defined]
        return results_df, metrics_df_all

    def _evaluate_prob_forecast(
        self,
        expected_kind: str,
        test_df: pd.DataFrame | None,
        covariate_df: pd.DataFrame | None,
        ensemble_strategy: str | None,
        ensemble_weights: dict[str, float] | None,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Backward-compatible alias for :meth:`_evaluate_core`."""
        return self._evaluate_core(
            expected_kind=expected_kind,
            test_df=test_df,
            covariate_df=covariate_df,
            ensemble_strategy=ensemble_strategy,
            ensemble_weights=ensemble_weights,
        )

    def evaluate_quantile_forecast(
        self,
        test_df: pd.DataFrame | None = None,
        covariate_df: pd.DataFrame | None = None,
        ensemble_strategy: str | None = None,
        ensemble_weights: dict[str, float] | None = None,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Evaluate quantile forecasts, computing pinball loss, calibration error, and sharpness.

        Requires QR models (e.g. ``QRXGBOOSTConfig``, ``MLPGAMConfig(distribution="qr")``).

        Returns:
            Tuple of:
                - DataFrame with columns: timestamp, Model, target, forecast (median), Actual.
                - DataFrame with per-day, per-target metrics: pinball, calibration_error, sharpness,
                  plus standard point metrics (mae, rmse, …).
        """
        return self._evaluate_prob_forecast(
            expected_kind="quantile",
            test_df=test_df,
            covariate_df=covariate_df,
            ensemble_strategy=ensemble_strategy,
            ensemble_weights=ensemble_weights,
        )

    def evaluate_parametric_forecast(
        self,
        test_df: pd.DataFrame | None = None,
        covariate_df: pd.DataFrame | None = None,
        ensemble_strategy: str | None = None,
        ensemble_weights: dict[str, float] | None = None,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Evaluate parametric probabilistic forecasts, computing NLL and point metrics.

        Works with Gaussian ML models (``GAUSSCATBOOSTConfig``) and neural parametric heads
        (``MLPFConfig(distribution="normal")``, ``"laplace"``, ``"gamma"``, etc.).

        NLL is computed under a Normal distribution assumption unless the model supplies
        a ``"log_likelihood"`` key (neural parametric heads do this automatically via
        :class:`~twiga.forecaster.result.ForecastResult`).

        Returns:
            Tuple of:
                - DataFrame with columns: timestamp, Model, target, forecast (mean), Actual.
                - DataFrame with per-day, per-target metrics: nll, plus standard point
                  metrics (mae, rmse, …).
        """
        return self._evaluate_prob_forecast(
            expected_kind="parametric",
            test_df=test_df,
            covariate_df=covariate_df,
            ensemble_strategy=ensemble_strategy,
            ensemble_weights=ensemble_weights,
        )

    def backtesting(
        self,
        data: pd.DataFrame,
        train_ratio: float = 1.0,
        start_dt: object | None = None,
        end_dt: object | None = None,
        verbose: bool = True,
        trial: object | None = None,
        ensemble_strategy: str | None = None,
        ensemble_weights: dict[str, float] | None = None,
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Perform backtesting on the forecaster models.

        Args:
            data: Complete dataset for backtesting.
            train_ratio: Ratio of data to use for training in backtesting.
            start_dt: Start date for backtesting, if any.
            end_dt: End date for backtesting, if any.
            verbose: Whether to display detailed logs during backtesting.
            trial: Trial identifier or configuration, if any.
            ensemble_strategy: Strategy for combining model predictions, if any.
            ensemble_weights: Weights for weighted ensemble strategy, if any.

        Returns:
            Tuple of concatenated predictions and backtesting metrics.

        Raises:
            ValueError: If no models are available or no metrics are returned.
        """
        if not self.models:  # type: ignore[attr-defined]
            raise ValueError("No models available for backtesting.")

        metrics_list: list[pd.DataFrame] = []
        forecast_list: list[pd.DataFrame] = []

        for train_df, test_df, scheme, key in self.split(data, start_dt, end_dt):  # type: ignore[attr-defined]
            self.file_name = f"backtesting_fold_{key + 1}"
            if verbose:
                log.info("Backtesting - Fold %d", key + 1)
                log.info("Train window: %s to %s", scheme["train_period"][0], scheme["train_period"][1])
                log.info("Test window: %s to %s", scheme["test_period"][0], scheme["test_period"][1])
            try:
                self.fit(train_df=train_df, train_ratio=train_ratio)
                pred, metric = self.evaluate_point_forecast(test_df=test_df, ensemble_strategy=ensemble_strategy)
                metric["Folds"] = key + 1
                pred["Folds"] = key + 1
                metrics_list.append(metric)
                forecast_list.append(pred)
            except Exception:
                log.exception("Unexpected error in fold %d", key + 1)
                continue

        predictions = pd.concat(forecast_list, ignore_index=True)
        metrics = pd.concat(metrics_list, ignore_index=True)
        return predictions, metrics

    def _format_keys_single(self, d: dict, name: str) -> dict:
        """Remove the given prefix (with an underscore appended) from dictionary keys.

        Args:
            d: Input dictionary.
            name: Prefix name to remove.

        Returns:
            Dictionary with modified keys.

        Example:
            >>> data = {"catboost_time": 10, "catboost_model": "x", "leng": 10}
            >>> _format_keys_single(data, "catboost")
            {'time': 10, 'model': 'x', 'leng': 10}
        """
        prefix = name + "_"
        return {(key.removeprefix(prefix)): value for key, value in d.items()}

    def tune(
        self,
        train_df: pd.DataFrame,
        val_df: pd.DataFrame,
        num_trials: int = 10,
        reduction_factor: int = 3,
        patience: int = 10,
        load_if_exists: bool = True,
        initial_params: dict | None = None,
        direction: str = "minimize",
        sampler: object | None = None,
        base_pruner: object | None = None,
    ) -> None:
        """Perform hyperparameter tuning and update models with optimal parameters.

        Args:
            train_df (pd.DataFrame): DataFrame containing training data.
            val_df (pd.DataFrame): DataFrame containing validation data.
            num_trials (int, optional): Number of trials for hyperparameter tuning.
            reduction_factor (int, optional): Reduction factor for the tuning pruner.
            patience (int, optional): Patience for the tuning process.
            load_if_exists (bool, optional): If True, load an existing tuning study if available.
            initial_params (dict | None, optional): Initial parameters for tuning.
            direction (str, optional): Direction of optimization, either 'minimize' or 'maximize
            sampler (object | None, optional): Sampler object for hyperparameter sampling.
            base_pruner (object | None, optional): Pruner object for early stopping.
        """
        if self.data_pipeline.data_pipeline is None:  # type: ignore[attr-defined]
            self.data_pipeline.fit(train_df.copy())  # type: ignore[attr-defined]

        for idx, model in enumerate(self.models):  # type: ignore[attr-defined]
            self.model = model
            self.model_type = self.model.model_config.name
            self.domain = self.model.model_config.domain
            self._create_folder()
            if hasattr(self.model.model_config, "initial_params"):
                initial_params = self.model.model_config.initial_params or initial_params

            best_params = self._tune(  # type: ignore[call-arg]
                train_df,
                val_df,
                num_trials=num_trials,
                reduction_factor=reduction_factor,
                patience=patience,
                load_if_exists=load_if_exists,
                base_pruner=None,
                sampler=None,
                initial_params=initial_params,
                direction=direction,
            )
            original_config = model.model_config
            model_name = original_config.name

            best_params = self._format_keys_single(best_params, model_name)
            if isinstance(original_config, BaseModelConfig):
                updated_config = original_config.model_copy(update=best_params)
            else:
                updated_config = original_config | best_params

            if isinstance(updated_config, dict):
                model_cls, config_cls = get_model_from_dict(updated_config, self.domain)
                validated_config = config_cls(**updated_config)
            else:
                model_cls, config_cls = get_model(model_name, self.domain)
                if not isinstance(updated_config, config_cls):
                    raise TypeError(
                        f"Updated config must be {config_cls.__name__}, got {type(updated_config).__name__}",
                    )
                validated_config = updated_config
            self.models[idx] = model_cls(validated_config)  # type: ignore[attr-defined]
