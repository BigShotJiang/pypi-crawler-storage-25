"""ML, NN, and baseline forecasting models for Twiga."""

from twiga.models.baseline import (
    DRIFTConfig,
    DRIFTModel,
    NAIVEConfig,
    NAIVEModel,
    SEASONALNAIVEConfig,
    SEASONALNAIVEModel,
    WINDOWAVERAGEConfig,
    WINDOWAVERAGEModel,
)

__all__ = [
    "DRIFTConfig",
    "DRIFTModel",
    "NAIVEConfig",
    "NAIVEModel",
    "SEASONALNAIVEConfig",
    "SEASONALNAIVEModel",
    "WINDOWAVERAGEConfig",
    "WINDOWAVERAGEModel",
]

# ML models - always available for linear/RF; tree-boosting requires gbtree extra
try:
    from twiga.models.ml import (
        LINEAREGConfig,
        LINEAREGModel,
        QRRANDOMFORESTConfig,
        QRRANDOMFORESTModel,
        RANDOMFORESTConfig,
        RANDOMFORESTModel,
    )

    __all__ += [
        "LINEAREGConfig",
        "LINEAREGModel",
        "RANDOMFORESTConfig",
        "RANDOMFORESTModel",
        "QRRANDOMFORESTConfig",
        "QRRANDOMFORESTModel",
    ]
except ImportError:
    pass

try:
    from twiga.models.ml import CATBOOSTConfig, CATBOOSTModel

    __all__ += ["CATBOOSTConfig", "CATBOOSTModel"]
except ImportError:
    pass

try:
    from twiga.models.ml import GAUSSCATBOOSTConfig, GAUSSCATBOOSTModel

    __all__ += ["GAUSSCATBOOSTConfig", "GAUSSCATBOOSTModel"]
except ImportError:
    pass

try:
    from twiga.models.ml import LIGHTGBMConfig, LIGHTGBMModel

    __all__ += ["LIGHTGBMConfig", "LIGHTGBMModel"]
except ImportError:
    pass

try:
    from twiga.models.ml import XGBOOSTConfig, XGBOOSTModel

    __all__ += ["XGBOOSTConfig", "XGBOOSTModel"]
except ImportError:
    pass

try:
    from twiga.models.ml import (
        QRCATBOOSTConfig,
        QRCATBOOSTModel,
        QRLIGHTGBMConfig,
        QRLIGHTGBMModel,
        QRXGBOOSTConfig,
        QRXGBOOSTModel,
    )

    __all__ += [
        "QRCATBOOSTConfig",
        "QRCATBOOSTModel",
        "QRLIGHTGBMConfig",
        "QRLIGHTGBMModel",
        "QRXGBOOSTConfig",
        "QRXGBOOSTModel",
    ]
except ImportError:
    pass
