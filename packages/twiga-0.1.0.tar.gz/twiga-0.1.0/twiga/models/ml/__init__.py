"""Machine learning forecasting models (tree-based and linear).

Tree-boosting models (CATBoost, LightGBM, XGBoost, NGBoost) require the
``gbtree`` extra::

    pip install 'twiga[gbtree]'

Linear and random-forest models are available with the default install.
"""

from twiga.models.ml.lineareg_model import LINEAREGConfig, LINEAREGModel
from twiga.models.ml.qrrandomforest_model import QRRANDOMFORESTConfig, QRRANDOMFORESTModel
from twiga.models.ml.randomforest_model import RANDOMFORESTConfig, RANDOMFORESTModel

__all__ = [
    "LINEAREGConfig",
    "LINEAREGModel",
    "RANDOMFORESTConfig",
    "RANDOMFORESTModel",
    "QRRANDOMFORESTConfig",
    "QRRANDOMFORESTModel",
]

try:
    from twiga.models.ml.catboost_model import CATBOOSTConfig, CATBOOSTModel
    from twiga.models.ml.gausscatboost_model import GAUSSCATBOOSTConfig, GAUSSCATBOOSTModel
    from twiga.models.ml.qrcatboost_model import QRCATBOOSTConfig, QRCATBOOSTModel

    __all__ += [
        "CATBOOSTConfig",
        "CATBOOSTModel",
        "GAUSSCATBOOSTConfig",
        "GAUSSCATBOOSTModel",
        "QRCATBOOSTConfig",
        "QRCATBOOSTModel",
    ]
except ImportError:
    pass

try:
    from twiga.models.ml.lightgbm_model import LIGHTGBMConfig, LIGHTGBMModel
    from twiga.models.ml.qrlightgbm_model import QRLIGHTGBMConfig, QRLIGHTGBMModel

    __all__ += [
        "LIGHTGBMConfig",
        "LIGHTGBMModel",
        "QRLIGHTGBMConfig",
        "QRLIGHTGBMModel",
    ]
except ImportError:
    pass

try:
    from twiga.models.ml.qrxgboost_model import QRXGBOOSTConfig, QRXGBOOSTModel
    from twiga.models.ml.xgboost_model import XGBOOSTConfig, XGBOOSTModel

    __all__ += [
        "XGBOOSTConfig",
        "XGBOOSTModel",
        "QRXGBOOSTConfig",
        "QRXGBOOSTModel",
    ]
except ImportError:
    pass

try:
    from twiga.models.ml.ngboostexponential_model import NGBOOSTEXPONENTIALConfig, NGBOOSTEXPONENTIALModel
    from twiga.models.ml.ngboostlognormal_model import NGBOOSTLOGNORMALConfig, NGBOOSTLOGNORMALModel
    from twiga.models.ml.ngboostnormal_model import NGBOOSTNORMALConfig, NGBOOSTNORMALModel

    __all__ += [
        "NGBOOSTNORMALConfig",
        "NGBOOSTNORMALModel",
        "NGBOOSTLOGNORMALConfig",
        "NGBOOSTLOGNORMALModel",
        "NGBOOSTEXPONENTIALConfig",
        "NGBOOSTEXPONENTIALModel",
    ]
except ImportError:
    pass
