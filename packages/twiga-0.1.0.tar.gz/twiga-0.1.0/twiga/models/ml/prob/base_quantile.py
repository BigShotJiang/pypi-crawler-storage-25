from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.isotonic import IsotonicRegression
from sklearn.multioutput import MultiOutputRegressor

from twiga.core.utils.logger import get_logger
from twiga.distributions.ml.utils import get_median_prediction, get_sigma_prediction
from twiga.models.ml.core.base_regressor import BaseRegressor

log = get_logger(__name__)


def enforce_monotonic_quantiles(predictions: np.ndarray) -> np.ndarray:
    """Enforce that quantile predictions are strictly increasing for each sample.

    Args:
        predictions: shape (n_samples, n_quantiles) raw predictions.

    Returns:
        np.ndarray: Monotonic predictions of the same shape.
    """
    n_samples, n_q = predictions.shape
    monotonic = np.empty_like(predictions)

    for i in range(n_samples):
        # Use isotonic regression to fit a non‑decreasing function
        iso = IsotonicRegression(increasing=True, y_min=0, y_max=np.inf)
        # Fit on the quantile indices (0..n_q-1) and the raw predictions
        monotonic[i] = iso.fit_transform(np.arange(n_q), predictions[i])
    return monotonic


class BaseQuantileRegressor(BaseRegressor):
    """Base class for quantile regression models compatible with scikit-learn pipelines.

    Supports multiple quantile models for probabilistic forecasting using any regression model
    (e.g., LightGBM, XGBoost, CatBoost). Automatically handles multi-output regression depending
    on model capabilities.

    Attributes:
        data_pipeline (Any | None): Optional preprocessing pipeline.
        model_instance (Any): Regression model class.
        model_config (dict): Configuration dictionary for the model.
        quantiles (list[float]): List of quantiles including confidence interval bounds.
        conf_level (float): Confidence level for interval predictions.
        supports_multi_output (bool): Whether the model supports multi-output regression.
        models (dict[float, Any]): Mapping from quantile to its corresponding trained model.
        num_targets (int | None): Number of output targets for multi-output cases.
        horizon (int): Prediction horizon length.
    """

    def __init__(
        self,
        data_pipeline: Any | None = None,
        model_instance: Any = None,
        model_config: dict | None = None,
        quantiles: list[float] | None = None,
        conf_level: float = 0.05,
    ) -> None:
        """Initializes the BaseQuantileRegressor.

        Args:
            data_pipeline (Any | None): Optional feature preprocessing pipeline.
            model_instance (Any): Regression model class (e.g., LGBMRegressor).
            model_config (dict | None): Parameters to initialize the model.
            quantiles (list[float] | None): List of quantiles to model (e.g., [0.25, 0.5, 0.75]).
                Defaults to [0.25, 0.5, 0.75, 0.95] plus confidence bounds.
            conf_level (float): Confidence level for interval bounds (e.g., 0.05 for 95% CI).
        """
        super().__init__(data_pipeline=data_pipeline)
        self.data_pipeline = data_pipeline
        self.model_instance = model_instance
        self.model_params = model_config or {}
        self.conf_level = conf_level
        self.num_targets: int | None = None
        self.horizon: int | None = None

        # Combine user quantiles with bounds from the confidence level
        quantile_bounds = [conf_level / 2, 1 - conf_level / 2]
        default_quantiles = [0.25, 0.5, 0.75, 0.95]
        self.quantiles = sorted(set((quantiles or default_quantiles) + quantile_bounds))

        self.supports_multi_output = self._check_multi_output_support()
        self.model = self._initialize_models()

    def _check_multi_output_support(self) -> bool:
        """Checks if the regression model supports multi-output natively.

        Returns:
            bool: True if model supports multi-output; otherwise, False.
        """
        estimator = self.model_instance(**self.model_params)
        return estimator.__class__.__name__ not in ["XGBRegressor"]

    def _initialize_models(self) -> dict[float, Any]:
        """Initializes one model per quantile.

        Returns:
            dict[float, Any]: Mapping of quantile to its corresponding model instance.
        """
        model_name = self.model_instance.__name__
        if model_name == "CatBoostRegressor":
            quantile_str = ",".join(map(str, sorted(self.quantiles)))
            config = self.model_params.copy()
            config["loss_function"] = f"MultiQuantile:alpha={quantile_str}"
            model = self.model_instance(**config)
            models = MultiOutputRegressor(model)

        elif model_name == "XGBRegressor":
            config = self.model_params.copy()
            config["quantile_alpha"] = sorted(self.quantiles)
            model = self.model_instance(**config)
            models = MultiOutputRegressor(model)
        else:
            models = {}
            for alpha in self.quantiles:
                config = self.model_params.copy()
                if model_name == "LGBMRegressor":
                    config["objective"] = "quantile"
                    config["alpha"] = alpha

                else:
                    ValueError(f"Unsupported model type: {model_name}")

                model = self.model_instance(**config)
                if self.supports_multi_output:
                    model = MultiOutputRegressor(model)

                models[alpha] = model

        return models

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        eval_set: tuple[np.ndarray, np.ndarray] | None = None,
        verbose: bool = False,
    ) -> BaseQuantileRegressor:
        """Fit the regression model to the training data.

        Args:
            X (np.ndarray): Training input features.
            y (np.ndarray): Target values corresponding to the training inputs.
            eval_set: Optional ``(X_val, y_val)`` for early stopping (reserved for
                future per-backend support; currently accepted but not forwarded).
            verbose (bool): Flag to control verbosity (default is False).

        Returns:
            BaseQuantileRegressor: The instance itself.

        Raises:
            ValueError: If no model has been set prior to calling fit.

        Example:
            >>> X = np.random.rand(10, 5, 3)
            >>> y = np.random.rand(10, 5, 2)
            >>> reg = BaseQuantileRegressor(model_instance=LinearRegression)
            >>> reg.fit(X, y, verbose=True)
        """
        if self.model is None:
            raise ValueError("No model has been set for the regressor.")

        self.num_targets = y.shape[-1] if y.ndim == 3 else 1
        self.horizon = y.shape[1]

        x_formatted = self.format_features(X)
        y_formatted = self.format_features(y)

        self._capture_feature_names(X, x_formatted.shape[1])

        if verbose:
            log.info("Fitting model with features shape %s and targets shape %s", x_formatted.shape, y_formatted.shape)
        if isinstance(self.model, dict):
            for _, model in self.model.items():
                model.fit(self._apply_feature_names(x_formatted), y_formatted)
        else:
            self.model.fit(self._apply_feature_names(x_formatted), y_formatted)

        log.info("Model fitting completed.")
        return self

    def _predict(self, x: np.ndarray) -> np.ndarray:
        """Predict quantile values for each sample and target.

        Args:
            x (np.ndarray): Input array of shape (n_samples, seq_len, n_features).

        Returns:
            np.ndarray: Array of shape (n_samples, n_quantiles, horizon, num_targets),
                where each slice [:, i, :, :] corresponds to predictions for the i-th quantile.

        Example:
            >>> import numpy as np
            >>> from sklearn.linear_model import LinearRegression
            >>> # Initialize regressor with a simple model
            >>> regressor = BaseQuantileRegressor(
            ...     model_instance=LinearRegression, quantiles=[0.25, 0.5, 0.75], conf_level=0.05
            ... )
            >>> # Example data: 10 samples, sequence length 5, 3 features
            >>> X = np.random.rand(10, 5, 3)
            >>> y = np.random.rand(10, 5, 2)  # 2 target variables
            >>> # Fit the model
            >>> regressor.fit(X, y)
            >>> # Predict quantiles
            >>> predictions = regressor._predict(X)
            >>> print(predictions.shape)  # Expected shape: (10, 5, 5, 2)
        """
        batch_size, seq_len, _ = x.shape
        x_formatted = self._apply_feature_names(self.format_features(x))

        if isinstance(self.model, dict):
            # Initialize array to store predictions with shape (n_quantiles, batch_size, horizon, num_targets)
            predictions = np.empty((len(self.quantiles), x_formatted.shape[0], self.horizon, self.num_targets))  # type: ignore[arg-type]

            for i, alpha in enumerate(sorted(self.quantiles)):
                raw_pred = self.model[alpha].predict(x_formatted)
                predictions[i] = raw_pred.reshape(batch_size, self.horizon, self.num_targets)
            # Transpose to get desired shape (batch_size, n_quantiles, horizon, num_targets)
            return predictions.transpose(1, 0, 2, 3)
        raw_pred = self.model.predict(x_formatted)  # type: ignore[union-attr]
        prediction = raw_pred.reshape(batch_size, len(self.quantiles), self.horizon, self.num_targets)
        return prediction

    def predict(self, X: np.ndarray, sigma: bool = False):
        """Predict quantile values and optionally sigma for the input data.

        Args:
            X (np.ndarray): Input features of shape (n_samples, seq_len, n_features).
            sigma (bool): Whether to return sigma predictions (default is True).

        Returns:
            tuple: Median predictions and either sigma predictions or full quantile predictions.
        """
        predictions = self._predict(X)
        # Apply monotonicity along the quantile axis (axis=1)
        # Reshape to 2D (batch * horizon * n_targets, n_q)
        flat_shape = (-1, len(self.quantiles))
        flat_preds = predictions.transpose(0, 2, 3, 1).reshape(flat_shape)
        flat_fixed = enforce_monotonic_quantiles(flat_preds)
        # Reshape back
        predictions = flat_fixed.reshape(
            predictions.shape[0],
            predictions.shape[2],
            predictions.shape[3],
            len(self.quantiles),
        ).transpose(0, 3, 1, 2)

        median_prediction = get_median_prediction(predictions, self.quantiles)
        if sigma:
            sigma_prediction = get_sigma_prediction(predictions, self.quantiles)
            return median_prediction, sigma_prediction
        return median_prediction, predictions

    def forecast(self, x: np.ndarray, sigma: bool = False) -> dict:
        """Forecast output using the fitted regression model.

        Args:
            x (np.ndarray): Input features for forecasting.
            sigma (bool): Whether to return sigma predictions (default is False).

        Returns:
            dict: A dictionary containing the predicted values with key "loc".

        Example:
            >>> x = np.random.rand(10, 5, 3)
            >>> reg = BaseRegressor()
            >>> reg.model = SomeModel()  # assign a model implementing predict
            >>> forecast_output = reg.forecast(x)
            >>> "loc" in forecast_output
            True
        """
        loc, quantiles_hat = self.predict(x, sigma=sigma)
        if sigma:
            return {"loc": loc, "scale": quantiles_hat}
        return {
            "loc": loc,
            "quantiles": quantiles_hat,
            "conf_level": self.conf_level,
            "quantile_levels": self.quantiles,
        }

    def get_median_quantile(self, predictions: np.ndarray) -> np.ndarray:
        """Get median quantile predictions for the input data.

        Args:
            predictions (np.ndarray): Input features of shape (n_samples, n_features).

        Returns:
            np.ndarray: Median quantile predictions of shape (n_samples, n_targets).
        """
        return get_median_prediction(predictions, self.quantiles)

    def get_sigma_quantile(self, predictions: np.ndarray) -> np.ndarray:
        """Get sigma quantile predictions for the input data.

        Args:
            predictions (np.ndarray): Input features of shape (n_samples, n_features).

        Returns:
            np.ndarray: Sigma quantile predictions of shape (n_samples, n_targets).
        """
        return get_sigma_prediction(predictions, self.quantiles)

    def update(self, trial):
        """Update the quantile regression model using hyperparameter suggestions.

        The model is re-instantiated with new parameters obtained from the configuration's
        search space.

        Args:
            trial: An Optuna trial object used to sample hyperparameters.
        """
        self.model_params = self.model_config.get_optuna_params(trial=trial)
        self._initialize_models()
