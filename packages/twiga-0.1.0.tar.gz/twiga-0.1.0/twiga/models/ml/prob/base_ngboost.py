"""Base class for NGBoost probabilistic regression models."""

from __future__ import annotations

from typing import ClassVar

import numpy as np

from twiga.models.ml.core.base_regressor import BaseRegressor


class BaseNGBoostRegressor(BaseRegressor):
    """Base class for NGBoost-based probabilistic forecasting models.

    Trains one :class:`ngboost.NGBRegressor` per flattened output column
    (horizon × targets) so that multi-horizon multi-target forecasting is
    supported without any changes to the single-output NGBoost API.

    Subclasses must set:

    - ``_dist`` - the NGBoost distribution class (e.g. ``Normal``).
    - ``_LOC_KEY`` - key in ``pred_dist(...).params`` to use as ``"loc"``.
    - ``_SCALE_KEY`` - key in ``pred_dist(...).params`` to use as ``"scale"``.

    Attributes:
        model_config: Model configuration (set by subclass).
        _models: List of fitted ``NGBRegressor`` instances, one per output column.
        _n_out: Number of flattened output columns (horizon × n_targets).
        num_targets: Number of forecast targets (set during :meth:`fit`).
        _horizon: Forecast horizon (set during :meth:`fit`).
    """

    _dist: ClassVar[type]
    _LOC_KEY: ClassVar[str]
    _SCALE_KEY: ClassVar[str]

    def __init__(self) -> None:
        super().__init__()
        self._models: list = []
        self._n_out: int | None = None
        self._horizon: int | None = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_ngb(self):  # type: ignore[return]
        """Instantiate a fresh NGBRegressor with the current config params."""
        from ngboost import NGBRegressor
        from ngboost.scores import CRPScore, LogScore

        _score_map = {"LogScore": LogScore, "CRPScore": CRPScore}
        score_cls = _score_map.get(getattr(self.model_config, "score", "LogScore"), LogScore)
        params = self.model_config.model_dump()
        return NGBRegressor(Dist=self._dist, Score=score_cls, verbose=False, **params)

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def fit(self, X: np.ndarray, y: np.ndarray, verbose: bool = False) -> BaseNGBoostRegressor:
        """Fit one NGBRegressor per output column.

        Args:
            X: Training features of shape ``(n_samples, seq_len, n_features)``.
            y: Targets of shape ``(n_samples, horizon, n_targets)``.
            verbose: Ignored (NGBoost verbosity is always silenced).

        Returns:
            Self for method chaining.

        Raises:
            ValueError: If ``X`` or ``y`` are not 3-dimensional.
        """
        if X.ndim != 3 or y.ndim != 3:
            raise ValueError("X and y must be 3-dimensional arrays.")

        _, _, self.num_targets = y.shape
        self._horizon = y.shape[1]

        x_fmt = self.format_features(X)  # (n_samples, n_in_features)
        y_fmt = self.format_features(y)  # (n_samples, horizon * n_targets)
        self._n_out = y_fmt.shape[1]

        self._models = []
        for col in range(self._n_out):
            m = self._build_ngb()
            m.fit(x_fmt, y_fmt[:, col])
            self._models.append(m)

        return self

    def predict(self, X: np.ndarray) -> tuple[np.ndarray, np.ndarray]:  # type: ignore[override]
        """Predict distribution parameters for each forecast horizon.

        Args:
            X: Input features of shape ``(n_samples, seq_len, n_features)``.

        Returns:
            Tuple ``(loc, scale)`` each of shape
            ``(n_samples, horizon, n_targets)``.

        Raises:
            ValueError: If the model has not been fitted yet.
        """
        if not self._models:
            raise ValueError("Model has not been fitted yet.")

        batch_size = X.shape[0]
        x_fmt = self.format_features(X)

        locs, scales = [], []
        for m in self._models:
            dist = m.pred_dist(x_fmt)
            locs.append(dist.params[self._LOC_KEY])
            scales.append(dist.params[self._SCALE_KEY])

        # Stack along axis=1 → (n_samples, n_out), then reshape
        loc = np.stack(locs, axis=1).reshape(batch_size, self._horizon, self.num_targets)
        scale = np.stack(scales, axis=1).reshape(batch_size, self._horizon, self.num_targets)
        return loc, scale

    def forecast(self, x: np.ndarray) -> dict:
        """Return distribution parameters for downstream probabilistic evaluation.

        Args:
            x: Input features of shape ``(n_samples, seq_len, n_features)``.

        Returns:
            Dictionary with keys ``"loc"`` and ``"scale"``.
        """
        loc, scale = self.predict(x)
        return {"loc": loc, "scale": scale}

    def update(self, trial) -> None:
        """Re-initialise with hyperparameters suggested by an Optuna trial.

        Args:
            trial: Optuna trial object used to sample hyperparameters.
        """
        new_params = self.model_config.get_optuna_params(trial=trial)
        # Patch config fields so _build_ngb picks them up on the next fit
        for key, val in new_params.items():
            if hasattr(self.model_config, key):
                object.__setattr__(self.model_config, key, val)
        self._models = []
        self.num_targets = None
        self._horizon = None
        self._n_out = None
