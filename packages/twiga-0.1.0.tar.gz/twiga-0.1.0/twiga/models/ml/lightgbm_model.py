"""LightGBM point forecasting model configuration and wrapper.

Uses a per-output model list (one :class:`~lightgbm.LGBMRegressor` per horizon step)
to enable early stopping via callbacks when a validation set is provided.
"""

from typing import Literal, override

import lightgbm as lgb
from lightgbm import LGBMRegressor
import numpy as np
from pydantic import Field

from twiga.core.config import BaseModelConfig, BaseSearchSpace

from .core.base_regressor import BaseRegressor


class LIGHTGBMConfig(BaseModelConfig):
    """Configuration for LightGBM point forecasting.

    Attributes:
        name: Model identifier fixed to ``"lightgbm"``.
        domain: Domain fixed to ``"ml"``. Excluded from tuning.
        random_state: Seed for reproducibility.
        verbose: LightGBM verbosity (-1 silent, 0 warnings, 1 info).
        boosting_type: Gradient boosting method.
        objective: LightGBM regression objective.
        metric: Evaluation metric used when an eval set is provided.
        bagging_freq: Enable bagging by setting to a positive integer
            (bagging performed every ``bagging_freq`` iterations).
        early_stopping_rounds: Stop training if the validation metric does
            not improve for this many rounds. Only activates when an
            ``eval_set`` is passed to :meth:`LIGHTGBMModel.fit`.
            Excluded from model params (passed via LightGBM callbacks).
        search_space: Optuna hyperparameter search space.
    """

    name: Literal["lightgbm"] = Field(  # type: ignore[assignment]
        default="lightgbm",
        description="Model identifier fixed to 'lightgbm'.",
        alias="model_name",
        exclude=True,
    )
    domain: Literal["ml"] = Field(  # type: ignore[assignment]
        default="ml",
        description="Modelling domain identifier, fixed to 'ml'.",
        exclude=True,
    )
    random_state: int = Field(
        default=42,
        gt=0,
        description="Positive integer seed for reproducibility.",
    )
    verbose: Literal[-1, 0, 1] = Field(
        default=-1,
        description="Verbosity level: -1 (silent), 0 (warnings), 1 (info).",
    )
    boosting_type: Literal["gbdt", "dart", "goss"] = Field(
        default="gbdt",
        description="Gradient boosting method.",
    )
    objective: Literal["regression"] = Field(
        default="regression",
        description="LightGBM regression objective.",
    )
    metric: Literal["rmse"] = Field(
        default="rmse",
        description="Evaluation metric (root mean squared error).",
    )
    bagging_freq: int = Field(
        default=1,
        description="Bagging frequency. Set > 0 to enable bagging.",
    )
    early_stopping_rounds: int = Field(
        default=50,
        ge=1,
        description=(
            "Rounds without improvement before early stopping via LightGBM callbacks. "
            "Only activates when eval_set is passed to fit()."
        ),
        exclude=True,
    )
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            learning_rate=(1e-3, 0.3),
            num_leaves=(16, 256),
            n_estimators=(100, 2000),
            subsample=(0.5, 1.0),
            colsample_bytree=(0.3, 1.0),
            min_data_in_leaf=(5, 100),
            reg_alpha=(0.0, 10.0),
            reg_lambda=(0.0, 10.0),
            linear_tree=[True, False],
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


class LIGHTGBMModel(BaseRegressor):
    """Multi-output LightGBM regression model.

    Fits one :class:`~lightgbm.LGBMRegressor` per output step (horizon),
    enabling per-target early stopping via LightGBM callbacks when a
    validation set is provided.

    Args:
        model_config: LightGBM configuration. Defaults to :class:`LIGHTGBMConfig`.
    """

    def __init__(self, model_config: LIGHTGBMConfig | None = None):
        self.model_config = model_config or LIGHTGBMConfig()
        self._params: dict = self.model_config.model_dump()
        self.models: list[LGBMRegressor] = []
        self.num_targets: int | None = None

    @override
    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        eval_set: tuple[np.ndarray, np.ndarray] | None = None,
        verbose: bool = False,
    ) -> "LIGHTGBMModel":
        """Fit one LGBMRegressor per output step.

        Args:
            X: Shape ``(B, L, F)`` - batch × sequence × features.
            y: Shape ``(B, L, H)`` - batch × sequence × horizons.
            eval_set: Optional ``(X_val, y_val)`` for early stopping.
                Each per-output model receives its corresponding validation
                column and uses :func:`lightgbm.early_stopping` with the
                ``early_stopping_rounds`` from the config.
            verbose: Whether to print LightGBM training logs.

        Returns:
            Self for method chaining.
        """
        self.num_targets = y.shape[-1] if y.ndim == 3 else 1
        x_fmt = self.format_features(X)
        y_fmt = self.format_features(y)
        n_outputs = y_fmt.shape[1]

        callbacks: list = [lgb.log_evaluation(-1 if not verbose else 1)]
        x_val_fmt: np.ndarray | None = None
        y_val_fmt: np.ndarray | None = None
        if eval_set is not None:
            x_val_fmt = self.format_features(eval_set[0])
            y_val_fmt = self.format_features(eval_set[1])
            callbacks.append(lgb.early_stopping(self.model_config.early_stopping_rounds, verbose=False))

        self._capture_feature_names(X, x_fmt.shape[1])

        self.models = []
        for j in range(n_outputs):
            m = LGBMRegressor(**self._params)
            fit_kwargs: dict = {"callbacks": callbacks}
            if x_val_fmt is not None and y_val_fmt is not None:
                fit_kwargs["eval_set"] = [(self._apply_feature_names(x_val_fmt), y_val_fmt[:, j])]
            m.fit(self._apply_feature_names(x_fmt), y_fmt[:, j], **fit_kwargs)
            self.models.append(m)

        return self

    @override
    def predict(self, x: np.ndarray) -> np.ndarray:
        """Predict output using fitted per-output models.

        Args:
            x: Shape ``(B, L, F)``.

        Returns:
            Predictions of shape ``(B, L, H)``.

        Raises:
            ValueError: If the model has not been fitted or x is not 3-D.
        """
        if not self.models:
            raise ValueError("Model has not been fitted yet.")
        if x.ndim != 3:
            raise ValueError("Input array x must be 3-dimensional.")

        batch_size = x.shape[0]
        x_fmt = self._apply_feature_names(self.format_features(x))
        preds = np.stack([m.predict(x_fmt) for m in self.models], axis=1)
        return preds.reshape(batch_size, -1, self.num_targets)

    @override
    def update(self, trial) -> None:
        """Rebuild models from an Optuna trial's suggested hyperparameters.

        Stores the sampled params; they are applied on the next :meth:`fit` call.
        """
        self._params = self.model_config.get_optuna_params(trial=trial)
        self.models = []
        self.num_targets = None
