from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, RegressorMixin

from twiga.core.utils.logger import get_logger

log = get_logger(__name__)


class BaseRegressor(BaseEstimator, RegressorMixin):
    """A base class for regression models compliant with scikit-learn pipelines.

    Provides common functionality for feature formatting, model fitting, and forecasting.

    Attributes:
        model (Any | None): The regression model to be used. Must implement fit and predict methods.
        data_pipeline (Any | None): Optional pipeline to preprocess data.
        num_targets (int | None): The number of target variables.
        feature_names_ (list[str] | None): Column names captured at fit time (sklearn convention).
            Set when X is a DataFrame; otherwise synthetic names ``f0, f1, ...`` are used.
            Used at predict time to avoid sklearn feature-name mismatch warnings.
    """

    def __init__(self, data_pipeline: Any | None = None) -> None:
        """Initialize the BaseRegressor with an optional data pipeline.

        Args:
            data_pipeline (Any | None): Data pipeline for preprocessing (default is None).

        Example:
            >>> reg = BaseRegressor()
        """
        self.data_pipeline: Any | None = data_pipeline
        self.num_targets: int | None = None
        self.model: Any | None = None
        self.feature_names_: list[str] | None = None

    def format_features(self, x: np.ndarray | pd.DataFrame) -> np.ndarray:
        """Format the input features by flattening multi-dimensional arrays into 2D arrays.

        Args:
            x: Input features. If X has more than 2 dimensions,
                it is reshaped to have shape (samples, features).

        Returns:
            np.ndarray: The formatted 2D feature array.

        Example:
            >>> x = np.random.rand(10, 5, 3)
            >>> reg = BaseRegressor()
            >>> x_formatted = reg.format_features(x)
            >>> x_formatted.shape
            (10, 15)
        """
        if isinstance(x, pd.DataFrame):
            x = x.to_numpy()
        if x.ndim > 2:
            x = x.reshape(x.shape[0], -1)
        return x

    def _capture_feature_names(self, X: np.ndarray | pd.DataFrame, n_flat_cols: int) -> None:
        """Capture flat feature names after format_features() has been applied.

        Names are stored in ``feature_names_`` so that predict() can wrap the
        flattened array in a DataFrame, keeping sklearn estimators consistent
        between fit and predict regardless of when the checkpoint was saved.

        Args:
            X: The raw (pre-format) input passed to fit().
            n_flat_cols: Number of columns after flattening (``x_fmt.shape[1]``).
        """
        if isinstance(X, pd.DataFrame) and X.shape[1] == n_flat_cols:
            self.feature_names_ = list(X.columns)
        else:
            self.feature_names_ = [f"f{i}" for i in range(n_flat_cols)]

    def _apply_feature_names(self, x_fmt: np.ndarray) -> pd.DataFrame | np.ndarray:
        """Wrap a flat 2D array in a DataFrame when feature names are available.

        This ensures that estimators fitted with named columns (whether from
        previous checkpoints or the current session) always receive consistent
        input at predict time, eliminating sklearn feature-name mismatch warnings.

        Args:
            x_fmt: Flat 2D numpy array from format_features().

        Returns:
            DataFrame with stored column names, or the original array if no
            names were captured (e.g. before first fit).
        """
        if self.feature_names_ is not None:
            return pd.DataFrame(x_fmt, columns=self.feature_names_)
        return x_fmt

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        eval_set: tuple[np.ndarray, np.ndarray] | None = None,
        verbose: bool = False,
    ) -> BaseRegressor:
        """Fit the regression model to the training data.

        Args:
            X (np.ndarray): Training input features.
            y (np.ndarray): Target values corresponding to the training inputs.
            eval_set: Optional ``(X_val, y_val)`` tuple for early stopping.
                Passed through to subclass implementations that support it.
            verbose (bool): Flag to control verbosity (default is False).

        Returns:
            BaseRegressor: The instance itself.

        Raises:
            ValueError: If no model has been set prior to calling fit.

        Example:
            >>> X = np.random.rand(10, 5, 3)
            >>> y = np.random.rand(10, 5, 2)
            >>> reg = BaseRegressor()
            >>> reg.model = SomeModel()  # assign a model implementing fit/predict
            >>> reg.fit(X, y, verbose=True)
        """
        if self.model is None:
            raise ValueError("No model has been set for the regressor.")

        self.num_targets = y.shape[-1] if y.ndim == 3 else 1

        x_formatted = self.format_features(X)
        y_formatted = self.format_features(y)

        self._capture_feature_names(X, x_formatted.shape[1])

        if verbose:
            log.info("Fitting model with features shape %s and targets shape %s", x_formatted.shape, y_formatted.shape)
        self.model.fit(self._apply_feature_names(x_formatted), y_formatted)
        log.info("Model fitting completed.")
        return self

    def predict(self, x: np.ndarray) -> np.ndarray:
        """Predict output using the fitted regression model.

        Args:
            x (np.ndarray): Input features for prediction. Expected to be 3D (samples, time_steps, channels).

        Returns:
            np.ndarray: Predicted values, reshaped to (samples, time_steps, num_targets).

        Raises:
            ValueError: If no model has been set or if the input array is not 3-dimensional.

        Example:
            >>> x = np.random.rand(10, 5, 3)
            >>> reg = BaseRegressor()
            >>> reg.model = SomeModel()  # assign a model implementing predict
            >>> predictions = reg.predict(X)
            >>> predictions.shape  # Expected: (10, 5, num_targets)
        """
        if self.model is None:
            raise ValueError("No model has been set for the regressor.")

        if x.ndim != 3:
            raise ValueError("Input array x must be 3-dimensional.")

        batch_size, seq_len, _ = x.shape
        x_formatted = self.format_features(x)
        raw_pred = self.model.predict(self._apply_feature_names(x_formatted))
        return raw_pred.reshape(batch_size, -1, self.num_targets)

    def forecast(self, x: np.ndarray) -> np.ndarray | dict:
        """Forecast output using the fitted regression model.

        Args:
            x (np.ndarray): Input features for forecasting.

        Returns:
            dict: A dictionary containing the predicted values with key "loc".

        Example:
            >>> x = np.random.rand(10, 5, 3)
            >>> reg = BaseRegressor()
            >>> reg.model = SomeModel()  # assign a model implementing predict
            >>> forecast_output = reg.forecast(x)
            >>> "loc" in forecast_output
            True
        """
        loc = self.predict(x)
        return loc

    def get_params(self, deep: bool = True) -> dict:
        """Return the model parameters.

        Args:
            deep (bool): If True, return parameters for this estimator and its subobjects.

        Returns:
            dict: A dictionary of parameters.

        Example:
            >>> reg = BaseRegressor()
            >>> params = reg.get_params()
        """
        return {"model": self.model}

    def update(self, trial: Any) -> None:
        """Rebuild the model from an Optuna trial's suggested hyperparameters.

        Subclasses should override this to apply trial params to ``self.model_config``
        and reinitialise the underlying estimator.  The base implementation is a no-op.

        Args:
            trial: An ``optuna.Trial`` object.
        """

    def set_params(self, **params: Any) -> BaseRegressor:
        """Set the model parameters.

        Args:
            **params: Parameters to set in the model.

        Returns:
            BaseRegressor: The instance with updated parameters.

        Example:
            >>> reg = BaseRegressor()
            >>> reg = reg.set_params(model=SomeModel())
        """
        for key, value in params.items():
            setattr(self, key, value)
        return self
