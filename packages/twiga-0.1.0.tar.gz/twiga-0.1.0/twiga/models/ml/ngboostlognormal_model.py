"""NGBoost LogNormal probabilistic model for multi-horizon forecasting."""

from __future__ import annotations

from typing import Literal

import numpy as np
from pydantic import Field

from twiga.core.config import BaseModelConfig, BaseSearchSpace
from twiga.models.ml.prob.base_ngboost import BaseNGBoostRegressor


class NGBOOSTLOGNORMALConfig(BaseModelConfig):
    """Configuration for the NGBoost LogNormal probabilistic forecasting model.

    Uses natural gradient boosting with a log-normal predictive distribution.
    Suitable for strictly positive targets such as solar irradiance, wind
    speed, electricity price, or non-negative load.

    Follows the ``scipy.stats.lognorm`` parameter convention:

    - ``scale = exp(μ_log)`` - geometric mean (location-like quantity).
    - ``s = σ_log`` - standard deviation in log-space (shape parameter).

    Attributes:
        name: Model identifier fixed to ``"ngboostlognormal"``.
        domain: Domain fixed to ``"ml"``. Excluded from tuning.
        n_estimators: Number of boosting iterations.
        learning_rate: Shrinkage applied to each tree.
        minibatch_frac: Row-subsample fraction per iteration.
        col_sample: Column-subsample fraction per iteration.
        random_state: Seed for reproducibility.
        score: Scoring rule - ``"LogScore"`` (MLE) or ``"CRPScore"``.
        search_space: Hyperparameter search space for Optuna tuning.

    Example:
        >>> from twiga.models.ml import NGBOOSTLOGNORMALConfig
        >>> cfg = NGBOOSTLOGNORMALConfig(n_estimators=300, score="CRPScore")
    """

    name: Literal["ngboostlognormal"] = Field(  # type: ignore[assignment]
        default="ngboostlognormal",
        description="Model identifier fixed to 'ngboostlognormal'.",
        alias="model_name",
        exclude=True,
    )
    domain: Literal["ml"] = Field(  # type: ignore[assignment]
        default="ml",
        description="Model domain fixed to 'ml'.",
        exclude=True,
    )
    n_estimators: int = Field(default=500, gt=0, description="Number of boosting iterations.")
    learning_rate: float = Field(default=0.01, gt=0.0, description="Step size shrinkage for each boosting round.")
    minibatch_frac: float = Field(
        default=1.0,
        gt=0.0,
        le=1.0,
        description="Row-subsample fraction per iteration (1.0 = no subsampling).",
    )
    col_sample: float = Field(
        default=1.0,
        gt=0.0,
        le=1.0,
        description="Column-subsample fraction per iteration (1.0 = no subsampling).",
    )
    random_state: int = Field(default=42, gt=0, description="Random seed for reproducibility.")
    score: Literal["LogScore", "CRPScore"] = Field(
        default="LogScore",
        description="Scoring rule: 'LogScore' (negative log-likelihood) or 'CRPScore' (CRPS).",
        exclude=True,
    )
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            n_estimators=(100, 1000),
            learning_rate=(1e-3, 0.3),
            minibatch_frac=(0.1, 1.0),
            col_sample=(0.1, 1.0),
        ),
        description="Hyperparameter search space for Optuna tuning.",
        exclude=True,
    )


class NGBOOSTLOGNORMALModel(BaseNGBoostRegressor):
    """NGBoost probabilistic model with a LogNormal predictive distribution.

    Wraps :class:`ngboost.NGBRegressor` with ``Dist=LogNormal``, training one
    regressor per flattened output column for multi-horizon / multi-target
    support.

    **Parameter convention** (follows ``scipy.stats.lognorm``):

    - ``loc`` (exposed as ``"loc"``) - ``scale = exp(μ_log)``, the geometric mean.
    - ``scale`` (exposed as ``"scale"``) - ``s = σ_log``, the log-space std-dev.

    Use this model when the target variable is strictly positive and its
    logarithm is approximately Gaussian (e.g. solar irradiance, wind power,
    non-negative energy prices).

    Attributes:
        model_config: Instance of :class:`NGBOOSTLOGNORMALConfig`.

    Args:
        model_config: Model configuration. Defaults to
            :class:`NGBOOSTLOGNORMALConfig`.

    Example:
        >>> import numpy as np
        >>> from twiga.models.ml import NGBOOSTLOGNORMALModel
        >>> model = NGBOOSTLOGNORMALModel()
        >>> X = np.random.randn(100, 10, 5)
        >>> y = np.abs(np.random.randn(100, 48, 1)) + 0.1  # strictly positive
        >>> model.fit(X, y)
        >>> loc, scale = model.predict(X)
        >>> loc.shape, scale.shape
        ((100, 48, 1), (100, 48, 1))
    """

    def __init__(self, model_config: NGBOOSTLOGNORMALConfig | None = None) -> None:
        super().__init__()
        self.model_config = model_config if model_config is not None else NGBOOSTLOGNORMALConfig()

    @property
    def _dist(self):  # type: ignore[override]
        from ngboost.distns import LogNormal

        return LogNormal

    # LogNormal scipy.stats.lognorm params: s (sigma_log), scale (exp(mu_log))
    # We expose: loc = scale (geometric mean), scale = s (log-space std-dev)
    _LOC_KEY: str = "scale"  # exp(mu_log)  → geometric mean → location-like
    _SCALE_KEY: str = "s"  # sigma_log    → spread in log-space

    def predict(self, X: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Predict geometric mean and log-space std-dev for each forecast horizon.

        Args:
            X: Input features of shape ``(n_samples, seq_len, n_features)``.

        Returns:
            Tuple ``(loc, scale)`` where:

            - ``loc = exp(μ_log)`` - geometric mean (strictly positive),
              shape ``(n_samples, horizon, n_targets)``.
            - ``scale = σ_log`` - standard deviation in log-space,
              shape ``(n_samples, horizon, n_targets)``.
        """
        return super().predict(X)

    def forecast(self, x: np.ndarray) -> dict:
        """Return LogNormal distribution parameters.

        Args:
            x: Input features of shape ``(n_samples, seq_len, n_features)``.

        Returns:
            Dictionary with:

            - ``"loc"``: geometric mean ``exp(μ_log)``, always > 0,
              shape ``(n_samples, horizon, n_targets)``.
            - ``"scale"``: log-space std-dev ``σ_log``,
              shape ``(n_samples, horizon, n_targets)``.
        """
        loc, scale = self.predict(x)
        return {"loc": loc, "scale": scale}
