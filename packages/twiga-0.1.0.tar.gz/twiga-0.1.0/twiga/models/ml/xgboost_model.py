"""XGBoost point forecasting model configuration and wrapper.

Uses ``tree_method="hist"`` (XGBoost 3.x recommended default) for fast histogram-based
training with native multi-output support and optional GPU acceleration.
Early stopping activates automatically when an ``eval_set`` is passed to :meth:`fit`.
"""

from typing import Literal, override

import numpy as np
from pydantic import Field
from xgboost import XGBRegressor

from twiga.core.config import BaseModelConfig, BaseSearchSpace

from .core.base_regressor import BaseRegressor


class XGBOOSTConfig(BaseModelConfig):
    """Configuration for XGBoost point forecasting.

    Attributes:
        name: Model identifier fixed to ``"xgboost"``.
        domain: Domain fixed to ``"ml"``. Excluded from tuning.
        random_state: Seed for reproducibility.
        verbose: Verbosity level (0 silent, 1 minimal, 2 detailed).
        device: Hardware target (``"cpu"`` or ``"gpu"``).
        tree_method: Tree construction algorithm. ``"hist"`` is required for
            native multi-output and GPU training (XGBoost 3.x default).
        objective: XGBoost regression objective.
        early_stopping_rounds: Stop training if validation metric does not
            improve for this many consecutive rounds. Only activates when
            an ``eval_set`` is passed to :meth:`XGBOOSTModel.fit`.
        search_space: Optuna hyperparameter search space.
    """

    name: Literal["xgboost"] = Field(  # type: ignore[assignment]
        default="xgboost",
        description="Model identifier fixed to 'xgboost'.",
        alias="model_name",
        exclude=True,
    )
    domain: Literal["ml"] = Field(  # type: ignore[assignment]
        default="ml",
        description="Modelling domain identifier, fixed to 'ml'.",
        exclude=True,
    )
    random_state: int = Field(
        default=42,
        gt=0,
        description="Positive integer seed for reproducibility.",
    )
    verbose: Literal[0, 1, 2] = Field(
        default=0,
        description="Verbosity level: 0 (silent), 1 (minimal), 2 (detailed).",
    )
    device: Literal["cpu", "gpu"] = Field(
        default="cpu",
        description="Hardware acceleration: 'cpu' or 'gpu'.",
    )
    tree_method: Literal["hist", "approx", "exact"] = Field(
        default="hist",
        description=(
            "Tree construction algorithm. 'hist' (histogram) is recommended "
            "for speed and is required for GPU training and native multi-output "
            "regression (XGBoost 3.x)."
        ),
    )
    objective: Literal["reg:squarederror"] = Field(
        default="reg:squarederror",
        description="XGBoost regression objective.",
    )
    early_stopping_rounds: int = Field(
        default=50,
        ge=1,
        description=(
            "Rounds without improvement before early stopping. "
            "Only activates when eval_set is passed to fit(). "
            "Excluded from model params - injected at fit-time only."
        ),
        exclude=True,
    )
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            learning_rate=(1e-3, 0.3),
            n_estimators=(100, 2000),
            max_depth=(3, 10),
            subsample=(0.5, 1.0),
            gamma=(0.0, 5.0),
            colsample_bytree=(0.3, 1.0),
            min_child_weight=(1, 20),
            reg_alpha=(0.0, 10.0),
            reg_lambda=(0.1, 10.0),
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


class XGBOOSTModel(BaseRegressor):
    """Multi-output XGBoost regression model.

    Wraps :class:`~xgboost.XGBRegressor` using native multi-output support
    (``tree_method="hist"``). Accepts an optional validation set to activate
    early stopping during training.

    Args:
        model_config: XGBoost configuration. Defaults to :class:`XGBOOSTConfig`.
    """

    def __init__(self, model_config: XGBOOSTConfig | None = None):
        self.model_config = model_config or XGBOOSTConfig()
        self.model = XGBRegressor(**self.model_config.model_dump())

    @override
    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        eval_set: tuple[np.ndarray, np.ndarray] | None = None,
        verbose: bool = False,
    ) -> "XGBOOSTModel":
        """Fit the XGBoost model, optionally with early stopping.

        Args:
            X: Shape ``(B, L, F)`` - batch × sequence × features.
            y: Shape ``(B, L, H)`` - batch × sequence × horizons.
            eval_set: Optional ``(X_val, y_val)`` for early stopping.
                When provided, training stops if the validation metric does
                not improve for ``early_stopping_rounds`` consecutive rounds.
            verbose: Whether to print XGBoost training logs.

        Returns:
            Self for method chaining.
        """
        self.num_targets = y.shape[-1] if y.ndim == 3 else 1
        x_fmt = self.format_features(X)
        y_fmt = self.format_features(y)

        self._capture_feature_names(X, x_fmt.shape[1])

        fit_kwargs: dict = {"verbose": verbose}
        if eval_set is not None:
            x_val_fmt = self._apply_feature_names(self.format_features(eval_set[0]))
            y_val_fmt = self.format_features(eval_set[1])
            fit_kwargs["eval_set"] = [(x_val_fmt, y_val_fmt)]
            # Inject early_stopping_rounds only when eval_set is present
            self.model = XGBRegressor(
                **self.model_config.model_dump(),
                early_stopping_rounds=self.model_config.early_stopping_rounds,
            )

        if self.model is None:
            raise ValueError("No model has been set for the regressor.")
        self.model.fit(self._apply_feature_names(x_fmt), y_fmt, **fit_kwargs)
        return self

    @override
    def update(self, trial) -> None:
        """Rebuild model from an Optuna trial's suggested hyperparameters."""
        params = self.model_config.get_optuna_params(trial=trial)
        self.model = XGBRegressor(**params)
