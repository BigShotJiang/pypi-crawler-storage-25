"""CatBoost point forecasting model configuration and wrapper."""

from typing import Literal

from catboost import CatBoostRegressor
from pydantic import Field
from sklearn.multioutput import MultiOutputRegressor

from twiga.core.config import BaseModelConfig, BaseSearchSpace

from .core.base_regressor import BaseRegressor


class CATBOOSTConfig(BaseModelConfig):
    """Configuration model for CatBoost algorithms.

    Attributes:
        name: Identifier for the model type, fixed to "catboost".
        task_type: Hardware acceleration type ("GPU" or "CPU").
        random_state: Seed for random number generation.
        verbose: Verbosity level (0 silent, 1 minimal, 2 detailed).
        allow_writing_files: Whether the model may write files to disk.
        l2_leaf_reg: L2 regularisation coefficient on leaf values.
        bagging_temperature: Bayesian bootstrap temperature; 1.0 = uniform,
            0.0 = no bagging. Higher values add more variance.
        search_space: Optuna hyperparameter search space.
    """

    name: Literal["catboost"] = Field(  # type: ignore[assignment]
        default="catboost",
        description="Identifier for the model type, fixed to 'catboost'.",
        alias="model_name",
    )
    domain: Literal["ml"] = Field(  # type: ignore[assignment]
        default="ml",
        description="Modelling domain identifier, fixed to 'ml'.",
        exclude=True,
    )
    task_type: Literal["GPU", "CPU"] = Field(
        default="CPU",
        description="Hardware acceleration type.",
    )
    random_state: int = Field(
        default=42,
        gt=0,
        description="Positive integer seed for reproducibility.",
    )
    verbose: Literal[0, 1, 2] = Field(
        default=0,
        description="Verbosity level: 0 (silent), 1 (minimal), 2 (detailed).",
    )
    allow_writing_files: bool = Field(
        default=False,
        description="Whether the model may write files to disk during training.",
    )
    l2_leaf_reg: float = Field(
        default=3.0,
        ge=0.0,
        description="L2 regularisation coefficient on leaf values. Higher values reduce overfitting on noisy data.",
    )
    bagging_temperature: float = Field(
        default=1.0,
        ge=0.0,
        description="Bayesian bootstrap sampling temperature. 1.0 = standard bootstrap; 0.0 = no bagging.",
    )
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            learning_rate=(1e-3, 0.3),
            depth=(4, 8),
            iterations=(100, 2000),
            min_data_in_leaf=(1, 100),
            l2_leaf_reg=(1.0, 10.0),
            bagging_temperature=(0.0, 1.0),
        ),
        description="Hyperparameter search space for Optuna tuning.",
        exclude=True,
    )


class CATBOOSTModel(BaseRegressor):
    """Multi-output CatBoost regression model.

    Wraps :class:`~catboost.CatBoostRegressor` in a
    :class:`~sklearn.multioutput.MultiOutputRegressor` to support
    multi-step-ahead point forecasting.

    Args:
        model_config: CatBoost configuration. Defaults to :class:`CATBOOSTConfig`.
    """

    def __init__(self, model_config: CATBOOSTConfig | None = None):
        self.model_config = model_config if model_config is not None else CATBOOSTConfig()
        self.model = MultiOutputRegressor(CatBoostRegressor(**self.model_config.model_dump()))

    def update(self, trial) -> None:
        """Rebuild model from an Optuna trial's suggested hyperparameters."""
        params = self.model_config.get_optuna_params(trial=trial)
        self.model = MultiOutputRegressor(CatBoostRegressor(**params))
