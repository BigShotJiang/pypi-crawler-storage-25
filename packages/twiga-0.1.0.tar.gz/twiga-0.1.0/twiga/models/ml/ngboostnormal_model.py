"""NGBoost Normal probabilistic model for multi-horizon forecasting."""

from __future__ import annotations

from typing import Literal

import numpy as np
from pydantic import Field

from twiga.core.config import BaseModelConfig, BaseSearchSpace
from twiga.models.ml.prob.base_ngboost import BaseNGBoostRegressor


class NGBOOSTNORMALConfig(BaseModelConfig):
    """Configuration for the NGBoost Normal probabilistic forecasting model.

    Uses natural gradient boosting with a Gaussian predictive distribution
    N(μ, σ²). Unlike the two-stage GAUSS* models, NGBoost jointly optimises
    μ and σ via the natural gradient of the chosen scoring rule, which tends
    to produce better-calibrated uncertainty estimates.

    Attributes:
        name: Model identifier fixed to ``"ngboostnormal"``.
        domain: Domain fixed to ``"ml"``. Excluded from tuning.
        n_estimators: Number of boosting iterations.
        learning_rate: Shrinkage applied to each tree.
        minibatch_frac: Row-subsample fraction per iteration.
        col_sample: Column-subsample fraction per iteration.
        random_state: Seed for reproducibility.
        score: Scoring rule - ``"LogScore"`` (MLE) or ``"CRPScore"``.
        search_space: Hyperparameter search space for Optuna tuning.

    Example:
        >>> from twiga.models.ml import NGBOOSTNORMALConfig
        >>> cfg = NGBOOSTNORMALConfig(n_estimators=200, learning_rate=0.05)
    """

    name: Literal["ngboostnormal"] = Field(  # type: ignore[assignment]
        default="ngboostnormal",
        description="Model identifier fixed to 'ngboostnormal'.",
        alias="model_name",
        exclude=True,
    )
    domain: Literal["ml"] = Field(  # type: ignore[assignment]
        default="ml",
        description="Model domain fixed to 'ml'.",
        exclude=True,
    )
    n_estimators: int = Field(default=500, gt=0, description="Number of boosting iterations.")
    learning_rate: float = Field(default=0.01, gt=0.0, description="Step size shrinkage for each boosting round.")
    minibatch_frac: float = Field(
        default=1.0,
        gt=0.0,
        le=1.0,
        description="Row-subsample fraction per iteration (1.0 = no subsampling).",
    )
    col_sample: float = Field(
        default=1.0,
        gt=0.0,
        le=1.0,
        description="Column-subsample fraction per iteration (1.0 = no subsampling).",
    )
    random_state: int = Field(default=42, gt=0, description="Random seed for reproducibility.")
    score: Literal["LogScore", "CRPScore"] = Field(
        default="LogScore",
        description="Scoring rule: 'LogScore' (negative log-likelihood) or 'CRPScore' (CRPS).",
        exclude=True,
    )
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            n_estimators=(100, 1000),
            learning_rate=(1e-3, 0.3),
            minibatch_frac=(0.1, 1.0),
            col_sample=(0.1, 1.0),
        ),
        description="Hyperparameter search space for Optuna tuning.",
        exclude=True,
    )


class NGBOOSTNORMALModel(BaseNGBoostRegressor):
    """NGBoost probabilistic model with a Normal (Gaussian) predictive distribution.

    Wraps :class:`ngboost.NGBRegressor` with ``Dist=Normal``, training one
    regressor per flattened output column to support multi-horizon and
    multi-target forecasting.

    The model jointly learns the conditional mean μ and standard deviation σ
    via natural gradient boosting on the selected scoring rule (log-likelihood
    or CRPS). Unlike ``GAUSSCATBOOSTModel``, which uses CatBoost's native
    ``RMSEWithUncertainty`` loss, NGBoost directly maximises the scoring rule
    via natural gradients.

    Attributes:
        model_config: Instance of :class:`NGBOOSTNORMALConfig`.

    Args:
        model_config: Model configuration. Defaults to
            :class:`NGBOOSTNORMALConfig`.

    Example:
        >>> import numpy as np
        >>> from twiga.models.ml import NGBOOSTNORMALModel
        >>> model = NGBOOSTNORMALModel()
        >>> X = np.random.randn(100, 10, 5)
        >>> y = np.random.randn(100, 48, 1)
        >>> model.fit(X, y)
        >>> loc, scale = model.predict(X)
        >>> loc.shape, scale.shape
        ((100, 48, 1), (100, 48, 1))
    """

    def __init__(self, model_config: NGBOOSTNORMALConfig | None = None) -> None:
        super().__init__()
        self.model_config = model_config if model_config is not None else NGBOOSTNORMALConfig()

    # Bind NGBoost distribution and parameter keys
    @property
    def _dist(self):  # type: ignore[override]
        from ngboost.distns import Normal

        return Normal

    _LOC_KEY: str = "loc"
    _SCALE_KEY: str = "scale"

    def predict(self, X: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Predict μ and σ for each forecast horizon.

        Args:
            X: Input features of shape ``(n_samples, seq_len, n_features)``.

        Returns:
            Tuple ``(loc, scale)`` - conditional mean μ and standard deviation σ,
            each of shape ``(n_samples, horizon, n_targets)``.
        """
        return super().predict(X)

    def forecast(self, x: np.ndarray) -> dict:
        """Return Normal distribution parameters.

        Args:
            x: Input features of shape ``(n_samples, seq_len, n_features)``.

        Returns:
            Dictionary with:

            - ``"loc"``: conditional mean μ, shape ``(n_samples, horizon, n_targets)``.
            - ``"scale"``: conditional std-dev σ, shape ``(n_samples, horizon, n_targets)``.
        """
        loc, scale = self.predict(x)
        return {"loc": loc, "scale": scale}
