"""NGBoost Exponential probabilistic model for multi-horizon forecasting."""

from __future__ import annotations

from typing import Literal

import numpy as np
from pydantic import Field

from twiga.core.config import BaseModelConfig, BaseSearchSpace
from twiga.models.ml.prob.base_ngboost import BaseNGBoostRegressor


class NGBOOSTEXPONENTIALConfig(BaseModelConfig):
    """Configuration for the NGBoost Exponential probabilistic forecasting model.

    Uses natural gradient boosting with an exponential predictive distribution.
    The exponential distribution has a single parameter ``scale = 1 / λ``, where
    λ is the rate. Both the mean and the standard deviation equal ``scale``.

    Suited for non-negative targets exhibiting exponential decay or inter-arrival
    times - e.g. rare demand events, sparse consumption spikes, or inter-event
    durations in energy systems.

    Attributes:
        name: Model identifier fixed to ``"ngboostexponential"``.
        domain: Domain fixed to ``"ml"``. Excluded from tuning.
        n_estimators: Number of boosting iterations.
        learning_rate: Shrinkage applied to each tree.
        minibatch_frac: Row-subsample fraction per iteration.
        col_sample: Column-subsample fraction per iteration.
        random_state: Seed for reproducibility.
        score: Scoring rule - ``"LogScore"`` (MLE) or ``"CRPScore"``.
        search_space: Hyperparameter search space for Optuna tuning.

    Example:
        >>> from twiga.models.ml import NGBOOSTEXPONENTIALConfig
        >>> cfg = NGBOOSTEXPONENTIALConfig(n_estimators=400, score="CRPScore")
    """

    name: Literal["ngboostexponential"] = Field(  # type: ignore[assignment]
        default="ngboostexponential",
        description="Model identifier fixed to 'ngboostexponential'.",
        alias="model_name",
        exclude=True,
    )
    domain: Literal["ml"] = Field(  # type: ignore[assignment]
        default="ml",
        description="Model domain fixed to 'ml'.",
        exclude=True,
    )
    n_estimators: int = Field(default=500, gt=0, description="Number of boosting iterations.")
    learning_rate: float = Field(default=0.01, gt=0.0, description="Step size shrinkage for each boosting round.")
    minibatch_frac: float = Field(
        default=1.0,
        gt=0.0,
        le=1.0,
        description="Row-subsample fraction per iteration (1.0 = no subsampling).",
    )
    col_sample: float = Field(
        default=1.0,
        gt=0.0,
        le=1.0,
        description="Column-subsample fraction per iteration (1.0 = no subsampling).",
    )
    random_state: int = Field(default=42, gt=0, description="Random seed for reproducibility.")
    score: Literal["LogScore", "CRPScore"] = Field(
        default="LogScore",
        description="Scoring rule: 'LogScore' (negative log-likelihood) or 'CRPScore' (CRPS).",
        exclude=True,
    )
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            n_estimators=(100, 1000),
            learning_rate=(1e-3, 0.3),
            minibatch_frac=(0.1, 1.0),
            col_sample=(0.1, 1.0),
        ),
        description="Hyperparameter search space for Optuna tuning.",
        exclude=True,
    )


class NGBOOSTEXPONENTIALModel(BaseNGBoostRegressor):
    """NGBoost probabilistic model with an Exponential predictive distribution.

    Wraps :class:`ngboost.NGBRegressor` with ``Dist=Exponential``, training one
    regressor per flattened output column for multi-horizon / multi-target
    support.

    The exponential distribution has one parameter, ``scale = 1 / λ``, which
    equals both the mean and the standard deviation. Both ``"loc"`` and
    ``"scale"`` in the returned forecast dict are set to this parameter.

    Use this model for non-negative targets with memoryless, decay-like
    behaviour - inter-arrival durations, sparse demand spikes, or short-term
    outage durations.

    Attributes:
        model_config: Instance of :class:`NGBOOSTEXPONENTIALConfig`.

    Args:
        model_config: Model configuration. Defaults to
            :class:`NGBOOSTEXPONENTIALConfig`.

    Example:
        >>> import numpy as np
        >>> from twiga.models.ml import NGBOOSTEXPONENTIALModel
        >>> model = NGBOOSTEXPONENTIALModel()
        >>> X = np.random.randn(100, 10, 5)
        >>> y = np.random.exponential(scale=2.0, size=(100, 48, 1))
        >>> model.fit(X, y)
        >>> loc, scale = model.predict(X)
        >>> loc.shape, scale.shape
        ((100, 48, 1), (100, 48, 1))
    """

    def __init__(self, model_config: NGBOOSTEXPONENTIALConfig | None = None) -> None:
        super().__init__()
        self.model_config = model_config if model_config is not None else NGBOOSTEXPONENTIALConfig()

    @property
    def _dist(self):  # type: ignore[override]
        from ngboost.distns import Exponential

        return Exponential

    # Exponential has only one param: scale (= mean = std = 1/λ)
    _LOC_KEY: str = "scale"
    _SCALE_KEY: str = "scale"

    def predict(self, X: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Predict the exponential rate parameter for each forecast horizon.

        Args:
            X: Input features of shape ``(n_samples, seq_len, n_features)``.

        Returns:
            Tuple ``(loc, scale)`` where both arrays equal the predicted
            ``scale = 1 / λ`` (the mean and std-dev of the exponential
            distribution), each of shape ``(n_samples, horizon, n_targets)``.
        """
        return super().predict(X)

    def forecast(self, x: np.ndarray) -> dict:
        """Return Exponential distribution parameters.

        Args:
            x: Input features of shape ``(n_samples, seq_len, n_features)``.

        Returns:
            Dictionary with:

            - ``"loc"``: predicted ``scale = 1/λ`` (the mean), always > 0,
              shape ``(n_samples, horizon, n_targets)``.
            - ``"scale"``: same as ``"loc"`` - for the exponential distribution,
              mean and std-dev are identical.
        """
        loc, scale = self.predict(x)
        return {"loc": loc, "scale": scale}
