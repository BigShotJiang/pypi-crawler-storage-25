"""Quantile Random Forest probabilistic forecasting model.

Uses Zillow's ``quantile-forest`` library
(:class:`~quantile_forest.RandomForestQuantileRegressor`).  A single forest is
trained once; every quantile is obtained at inference time via a single
``predict(X, quantiles=[...])`` call - no per-quantile retraining needed.
"""

from __future__ import annotations

from typing import Literal, override

import numpy as np
from pydantic import Field
from quantile_forest import RandomForestQuantileRegressor

from twiga.distributions.ml.utils import get_median_prediction, get_sigma_prediction
from twiga.models.ml.prob.base_quantile import enforce_monotonic_quantiles
from twiga.models.ml.randomforest_model import RANDOMFORESTConfig

from .core.base_regressor import BaseRegressor


class QRRANDOMFORESTConfig(RANDOMFORESTConfig):
    """Configuration for the Quantile Random Forest probabilistic model.

    Extends :class:`RANDOMFORESTConfig` - inherits ``random_state``,
    ``n_jobs``, and the full search space.

    Attributes:
        name: Fixed to ``"qrrandomforest"``.
        quantiles: Quantile levels to predict at inference time.
            Combined with confidence-interval bounds derived from
            ``conf_level``.
        conf_level: Half-width of the symmetric confidence interval.
            E.g. ``0.1`` → 5th and 95th percentile bounds.
    """

    name: Literal["qrrandomforest"] = Field(  # type: ignore[assignment]
        default="qrrandomforest",
        description="Model identifier fixed to 'qrrandomforest'.",
        alias="model_name",
        exclude=True,
    )
    quantiles: list[float] | None = Field(
        default=sorted([0.05, 0.25, 0.5, 0.75, 0.95]),
        description="Quantile levels to predict at inference time.",
        exclude=True,
    )
    conf_level: float | None = Field(
        default=0.1,
        description=("Confidence level: adds conf_level/2 and 1-conf_level/2 bounds to the quantile list."),
        exclude=True,
    )


class QRRANDOMFORESTModel(BaseRegressor):
    """Quantile Random Forest for probabilistic multi-horizon forecasting.

    Wraps :class:`~quantile_forest.RandomForestQuantileRegressor` which trains
    a single forest and delivers any quantile at inference time without
    retraining.  Monotonicity across quantiles is enforced post-hoc via
    isotonic regression, consistent with all other QR variants in this
    library.

    The ``eval_set`` argument is accepted in :meth:`fit` for API compatibility
    but silently ignored - QRF has no early stopping.

    Args:
        model_config: Configuration object. Defaults to
            :class:`QRRANDOMFORESTConfig`.

    Example::

        model = QRRANDOMFORESTModel()
        model.fit(X_train, y_train)
        loc, quantiles = model.predict(X_test)
    """

    def __init__(self, model_config: QRRANDOMFORESTConfig | None = None) -> None:
        self.model_config = model_config or QRRANDOMFORESTConfig()
        self.num_targets: int | None = None
        self.horizon: int | None = None

        conf_level: float = self.model_config.conf_level or 0.1
        quantile_bounds = [conf_level / 2, 1 - conf_level / 2]
        base_quantiles: list[float] = self.model_config.quantiles or [0.05, 0.25, 0.5, 0.75, 0.95]
        self.quantiles: list[float] = sorted(set(base_quantiles + quantile_bounds))
        self.conf_level: float = conf_level

        self.model = RandomForestQuantileRegressor(**self.model_config.model_dump())

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        eval_set: tuple[np.ndarray, np.ndarray] | None = None,
        verbose: bool = False,
    ) -> QRRANDOMFORESTModel:
        """Fit the Quantile Random Forest.

        Args:
            X: Shape ``(B, L, F)`` - batch × sequence × features.
            y: Shape ``(B, L, H)`` - batch × sequence × horizons.
            eval_set: Accepted for API compatibility; ignored (QRF has no
                early stopping).
            verbose: Unused; included for interface consistency.

        Returns:
            Self for method chaining.
        """
        if y.ndim == 3:
            _, self.horizon, self.num_targets = y.shape
        else:
            self.horizon = 1
            self.num_targets = 1

        x_fmt = self.format_features(X)
        y_fmt = self.format_features(y)
        self.model.fit(x_fmt, y_fmt)
        return self

    def _predict_quantiles(self, x: np.ndarray) -> np.ndarray:
        """Return raw quantile predictions.

        Args:
            x: Shape ``(B, L, F)``.

        Returns:
            Array of shape ``(B, n_quantiles, horizon, num_targets)``.
        """
        batch_size = x.shape[0]
        x_fmt = self.format_features(x)
        # quantile-forest returns (n_samples, n_quantiles, n_outputs) for multi-output
        raw = self.model.predict(x_fmt, quantiles=self.quantiles)
        n_q = len(self.quantiles)
        return raw.reshape(batch_size, n_q, self.horizon, self.num_targets)  # type: ignore[arg-type]

    def predict(self, X: np.ndarray, sigma: bool = False):
        """Predict quantile values and optionally sigma.

        Args:
            X: Shape ``(B, L, F)``.
            sigma: If ``True``, return ``(median, sigma)`` derived from the
                interquartile range; otherwise return ``(median, quantiles)``.

        Returns:
            Tuple of ``(median, quantiles_or_sigma)`` where ``median`` has
            shape ``(B, H)`` and the second element has shape
            ``(B, n_quantiles, horizon, num_targets)`` or ``(B, H)``.
        """
        predictions = self._predict_quantiles(X)

        # Enforce monotonicity along the quantile axis
        n_q = len(self.quantiles)
        flat_preds = predictions.transpose(0, 2, 3, 1).reshape(-1, n_q)
        flat_fixed = enforce_monotonic_quantiles(flat_preds)
        predictions = flat_fixed.reshape(
            predictions.shape[0],
            predictions.shape[2],
            predictions.shape[3],
            n_q,
        ).transpose(0, 3, 1, 2)

        median = get_median_prediction(predictions, self.quantiles)
        if sigma:
            return median, get_sigma_prediction(predictions, self.quantiles)
        return median, predictions

    def forecast(self, x: np.ndarray, sigma: bool = False) -> dict:
        """Return distribution parameters as a dictionary.

        Args:
            x: Shape ``(B, L, F)``.
            sigma: If ``True``, return ``"scale"`` (sigma) instead of full
                quantiles.

        Returns:
            Dict with keys ``"loc"``, ``"quantiles"``, ``"conf_level"``,
            ``"quantile_levels"`` - or ``"loc"`` and ``"scale"`` when
            ``sigma=True``.
        """
        loc, quantiles_or_sigma = self.predict(x, sigma=sigma)
        if sigma:
            return {"loc": loc, "scale": quantiles_or_sigma}
        return {
            "loc": loc,
            "quantiles": quantiles_or_sigma,
            "conf_level": self.conf_level,
            "quantile_levels": self.quantiles,
        }

    def update(self, trial) -> None:
        """Rebuild model from an Optuna trial's suggested hyperparameters."""
        params = self.model_config.get_optuna_params(trial=trial)
        self.model = RandomForestQuantileRegressor(**params)
