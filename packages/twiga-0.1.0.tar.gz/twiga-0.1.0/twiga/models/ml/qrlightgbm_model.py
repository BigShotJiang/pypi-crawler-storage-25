from typing import Literal

from lightgbm import LGBMRegressor
from pydantic import Field

from .lightgbm_model import LIGHTGBMConfig
from .prob.base_quantile import BaseQuantileRegressor


class QRLIGHTGBMConfig(LIGHTGBMConfig):
    """Configuration model for QRLightGBM algorithms.

    This class extends ``LIGHTGBMConfig`` with parameters specific to QRLightGBM,
    enabling hardware acceleration and hyperparameter tuning. It includes fixed
    parameters and a hyperparameter search space for tuning key parameters.

    Attributes:
        name (Literal["qrlightgbm"]): Model identifier fixed to "qrlightgbm".
            Input can be provided using the alias "model_name".
        objective (Literal["regression"]): Regression objective.
    """

    name: Literal["qrlightgbm"] = Field(  # type: ignore[assignment]
        default="qrlightgbm",
        description="Model identifier fixed to 'qrlightgbm'.",
        alias="model_name",
        exclude=True,
    )

    objective: Literal["quantile"] = Field(  # type: ignore[assignment]
        default="quantile",
        description="Quantile Regression objective (only 'regression' is supported).",
    )
    quantiles: list | None = Field(
        default=sorted([0.05, 0.25, 0.5, 0.75, 0.95]),
        description="quantile fractions for fitting quantile regression model.",
        exclude=True,
    )

    conf_level: float | None = Field(
        default=0.1,
        description="Confidence level for quantile regression model.",
        exclude=True,
    )


class QRLIGHTGBMModel(BaseQuantileRegressor):
    """QRLightGBM regression model with multi-output support.

    This class provides an interface for initializing and updating an QRLGBMRegressor
    model for regression tasks. It uses a configuration model (``QRLIGHTGBMConfig``)
    to manage hyperparameters and settings.

    Args:
        model_config (QRLIGHTGBMConfig | None): Configuration for LightGBM. If None,
            the default configuration is used.

    Attributes:
        model_config (QRLIGHTGBMConfig): The configuration object for LightGBM.
        model (MultiOutputRegressor): The instantiated LightGBM regressor wrapped for
            multi-output regression.
    """

    def __init__(self, model_config: QRLIGHTGBMConfig | None = None):
        self.model_config = model_config or QRLIGHTGBMConfig()
        super().__init__(
            model_config=self.model_config.model_dump(),
            model_instance=LGBMRegressor,
            quantiles=self.model_config.quantiles,
            conf_level=self.model_config.conf_level,  # type: ignore[arg-type]
        )
