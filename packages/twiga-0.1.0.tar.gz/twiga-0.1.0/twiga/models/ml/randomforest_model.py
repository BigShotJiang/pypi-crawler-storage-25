"""Random Forest point forecasting model configuration and wrapper.

Uses scikit-learn's :class:`~sklearn.ensemble.RandomForestRegressor` with native
multi-output support (no :class:`~sklearn.multioutput.MultiOutputRegressor` needed).
"""

from typing import Literal, override

import numpy as np
from pydantic import Field
from sklearn.ensemble import RandomForestRegressor

from twiga.core.config import BaseModelConfig, BaseSearchSpace

from .core.base_regressor import BaseRegressor


class RANDOMFORESTConfig(BaseModelConfig):
    """Configuration for Random Forest point forecasting.

    Attributes:
        name: Model identifier fixed to ``"randomforest"``.
        domain: Domain fixed to ``"ml"``. Excluded from tuning.
        random_state: Seed for reproducibility.
        n_jobs: Number of parallel jobs during fit and predict.
            ``-1`` uses all available CPUs.
        search_space: Optuna hyperparameter search space.
    """

    name: Literal["randomforest"] = Field(  # type: ignore[assignment]
        default="randomforest",
        description="Model identifier fixed to 'randomforest'.",
        alias="model_name",
        exclude=True,
    )
    domain: Literal["ml"] = Field(  # type: ignore[assignment]
        default="ml",
        description="Modelling domain identifier, fixed to 'ml'.",
        exclude=True,
    )
    random_state: int = Field(
        default=42,
        gt=0,
        description="Positive integer seed for reproducibility.",
    )
    n_jobs: int = Field(
        default=-1,
        description="Number of parallel jobs. -1 = all available CPUs.",
    )
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            n_estimators=(100, 1000),
            max_depth=(3, 20),
            min_samples_split=(2, 20),
            min_samples_leaf=(1, 20),
            max_features=["sqrt", "log2"],
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


class RANDOMFORESTModel(BaseRegressor):
    """Multi-output Random Forest regression model.

    Wraps :class:`~sklearn.ensemble.RandomForestRegressor` which natively
    handles multi-output regression without requiring
    :class:`~sklearn.multioutput.MultiOutputRegressor`.

    Random Forest is a strong non-parametric baseline with built-in
    feature importance, requires no scaling, and is robust to outliers.
    It does not support early stopping; the ``eval_set`` argument is
    accepted but silently ignored.

    Args:
        model_config: RF configuration. Defaults to :class:`RANDOMFORESTConfig`.
    """

    def __init__(self, model_config: RANDOMFORESTConfig | None = None):
        super().__init__()
        self.model_config = model_config or RANDOMFORESTConfig()
        self.model = RandomForestRegressor(**self.model_config.model_dump())

    @override
    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        eval_set: tuple[np.ndarray, np.ndarray] | None = None,
        verbose: bool = False,
    ) -> "RANDOMFORESTModel":
        """Fit the Random Forest model.

        Args:
            X: Shape ``(B, L, F)`` - batch × sequence × features.
            y: Shape ``(B, L, H)`` - batch × sequence × horizons.
            eval_set: Accepted for API compatibility; ignored (RF has no
                early stopping).
            verbose: Unused; included for interface consistency.

        Returns:
            Self for method chaining.
        """
        self.num_targets = y.shape[-1] if y.ndim == 3 else 1
        x_fmt = self.format_features(X)
        y_fmt = self.format_features(y)
        self._capture_feature_names(X, x_fmt.shape[1])
        self.model.fit(self._apply_feature_names(x_fmt), y_fmt)
        return self

    @override
    def update(self, trial) -> None:
        """Rebuild model from an Optuna trial's suggested hyperparameters."""
        params = self.model_config.get_optuna_params(trial=trial)
        self.model = RandomForestRegressor(**params)
