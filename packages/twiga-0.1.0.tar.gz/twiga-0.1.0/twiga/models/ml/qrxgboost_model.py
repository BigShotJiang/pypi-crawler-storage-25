"""Module implementing XGBoost configuration and model classes.

This module provides the configuration class ``XGBOOSTConfig`` for specifying
hyperparameters and settings for XGBoost, and the model class ``XGBOOSTModel`` which
wraps an XGBoost regressor for regression tasks.
"""

from typing import Literal

from pydantic import Field
from xgboost import XGBRegressor

from .prob.base_quantile import BaseQuantileRegressor
from .xgboost_model import XGBOOSTConfig


class QRXGBOOSTConfig(XGBOOSTConfig):
    """Configuration model for QRXGBoost algorithm.

    This class extends ``XGBOOSTConfig`` with parameters specific to QRXGBoost,
    enabling reproducibility, verbosity control, and hyperparameter tuning. It
    includes fixed parameters as well as a hyperparameter search space defining
    ranges for tuning key parameters.

    Attributes:
        name (Literal["qrxgboost"]): Identifier for the model type, fixed to
            "qrxgboost". Excluded from parameter tuning. Input can be provided using
            the alias "model_name".
        quantiles (list|None): List of quantile fractions for fitting the
            quantile regression model. Defaults to sorted list of common quantiles.
        conf_level (float|None): Confidence level for the quantile regression model.
            Defaults to 0.1, which corresponds to a 90% confidence interval.
        objective (Literal["reg:squarederror"]): Objective function for XGBoost.
    """

    name: Literal["qrxgboost"] = Field(  # type: ignore[assignment]
        default="qrxgboost",
        description=("Identifier for the model type, fixed to 'qrxgboost'. Excluded from parameter tuning."),
        alias="model_name",
        exclude=True,
    )

    quantiles: list | None = Field(
        default=sorted([0.05, 0.25, 0.5, 0.75, 0.95]),
        description="quantile fractions for fitting quantile regression model.",
        exclude=True,
    )

    conf_level: float | None = Field(
        default=0.1,
        description="Confidence level for quantile regression model.",
        exclude=True,
    )

    objective: Literal["reg:quantileerror"] = Field(  # type: ignore[assignment]
        default="reg:quantileerror",
        description="Objective function for QRXGBoost.",
    )


class QRXGBOOSTModel(BaseQuantileRegressor):
    """Quantile Regression model using QXGBoost as the underlying estimator.

    This class provides an interface for initializing and updating an XGBoost model
    for quantile regression tasks. It utilizes a configuration model (``QRXGBOOSTConfig``) to
    manage hyperparameters and settings.

    Args:
        model_config (XGBOOSTConfig | None): Configuration for XGBoost. Defaults
            to None, in which case the default configuration is used.

    Attributes:
        model_config (XGBOOSTConfig): The configuration object for XGBoost.
        model (XGBRegressor): The instantiated XGBRegressor model.
    """

    def __init__(self, model_config: XGBOOSTConfig | None = None):
        self.model_config = model_config if model_config is not None else QRXGBOOSTConfig()

        super().__init__(
            model_config=self.model_config.model_dump(),
            model_instance=XGBRegressor,
            quantiles=self.model_config.quantiles,  # type: ignore[attr-defined]
            conf_level=self.model_config.conf_level,  # type: ignore[attr-defined]
        )
