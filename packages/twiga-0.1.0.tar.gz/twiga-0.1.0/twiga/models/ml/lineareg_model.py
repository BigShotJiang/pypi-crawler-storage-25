from typing import Literal

from pydantic import Field
from sklearn.linear_model import LinearRegression
from sklearn.multioutput import MultiOutputRegressor

from twiga.core.config import BaseModelConfig, BaseSearchSpace
from twiga.models.ml.core.base_regressor import BaseRegressor


class LINEAREGConfig(BaseModelConfig):
    """Configuration model for Linear Regression algorithms.

    This class extends ``BaseModelConfig`` with parameters specific to Linear Regression,
    enabling configuration for basic regression tasks. It includes fixed parameters and
    a hyperparameter search space for tuning key parameters.

    Attributes:
        name (Literal["linear_regression"]): Model identifier fixed to "linear_regression".
            Input can be provided using the alias "model_name".
        domain (Literal["ml"]): Model domain fixed to "ml". Excluded from parameter tuning.
        fit_intercept (bool): Whether to calculate the intercept for this model.
        search_space (BaseSearchSpace): Hyperparameter search space for optimization.
    """

    name: Literal["lineareg"] = Field(  # type: ignore[assignment]
        default="lineareg",
        description="Model identifier fixed to 'lineareg'.",
        alias="model_name",
        exclude=True,
    )
    domain: Literal["ml"] = Field(default="ml", description="Model domain fixed to 'ml'.", exclude=True)  # type: ignore[assignment]
    fit_intercept: bool = Field(default=True, description="Whether to calculate the intercept for this model.")
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            fit_intercept=[True, False],
        ),
        description="Hyperparameter search space for optimization.",
        exclude=True,
    )


class LINEAREGModel(BaseRegressor):
    """Linear Regression model with multi-output support.

    This class provides an interface for initializing and updating a LinearRegression
    model for regression tasks. It uses a configuration model (``LinearRegressionConfig``)
    to manage hyperparameters and settings.

    Args:
        model_config (LinearRegressionConfig | None): Configuration for Linear Regression. If None,
            the default configuration is used.

    Attributes:
        model_config (LinearRegressionConfig): The configuration object for Linear Regression.
        model (MultiOutputRegressor): The instantiated Linear Regression model wrapped for
            multi-output regression.
    """

    def __init__(self, model_config: LINEAREGConfig | None = None):
        self.model_config = model_config or LINEAREGConfig()
        self.model = MultiOutputRegressor(LinearRegression(**self.model_config.model_dump()))

    def update(self, trial):
        """Update the Linear Regression model using hyperparameter suggestions.

        Args:
            trial: An Optuna trial object used to sample hyperparameters.

        The model is re-instantiated with new parameters obtained from the configuration's
        search space.
        """
        params = self.model_config.get_optuna_params(trial=trial)
        self.model = MultiOutputRegressor(LinearRegression(**params))
