from typing import Literal

from catboost import CatBoostRegressor
from pydantic import Field

from .catboost_model import CATBOOSTConfig
from .prob.base_quantile import BaseQuantileRegressor


class QRCATBOOSTConfig(CATBOOSTConfig):
    """Configuration model for QRCatBoost algorithms.

    This class extends CATBOOSTConfig with parameters specific to CatBoost, enabling hardware acceleration,
    reproducibility, verbosity control, and hyperparameter tuning. The configuration includes fixed parameters as
    well as a hyperparameter search space that defines ranges for parameters used during optimization.

    Attributes:
        name (Literal["qrcatboost"]):
            Identifier for the model type, fixed to "qrcatboost". This field is excluded from parameter tuning.
            Input can be provided using the alias "name".
        task_type (Literal["GPU", "CPU"]):
            Hardware acceleration type. Use "GPU" for GPU acceleration or "CPU" for standard processing.
        random_state (int):
            A positive integer seed used for random number generation to ensure reproducibility.
        verbose (Literal[0, 1, 2]):
            Verbosity level for model output. Acceptable values are:
                0 - Silent,
                1 - Minimal,
                2 - Detailed.
        allow_writing_files (bool):
            Flag indicating whether the model is allowed to write files to disk during training.
        search_space (BaseSearchSpace):
            Hyperparameter search space defining ranges for tuning parameters such as learning_rate, depth,
            iterations, and min_data_in_leaf.

    Examples:
        How to use:
            >>> # Instantiate the configuration with a positive seed value.
            >>> config = CATBOOSTConfig(seed=42)
            >>> print(config.task_type)
            CPU
            >>>
            >>> # Integrate with an Optuna study for hyperparameter tuning:
            >>> import optuna
            >>> def objective(trial):
            ...     params = config.get_optuna_params(trial)
            ...     # Train your model with the suggested parameters and return an evaluation metric.
            ...     return evaluate_model(params)
            >>> study = optuna.create_study(direction="minimize")
            >>> study.optimize(objective, n_trials=10)
    """

    name: Literal["qrcatboost"] = Field(  # type: ignore[assignment]
        default="qrcatboost",
        description="Identifier for the model type, fixed to 'catboost'. Excluded from parameter tuning.",
        alias="model_name",  # Allows input using "name" while avoiding conflict.
        exclude=True,
    )
    quantiles: list | None = Field(
        default=sorted([0.05, 0.25, 0.5, 0.75, 0.95]),
        description="quantile fractions for fitting quantile regression model.",
        exclude=True,
    )

    conf_level: float | None = Field(
        default=0.1,
        description="Confidence level for quantile regression model.",
        exclude=True,
    )


class QRCATBOOSTModel(BaseQuantileRegressor):
    """A quantile regression model class using CatBoost as the underlying model.

    Inherits from:
        BaseQuantileRegressor: The base regressor class providing core methods.

    Args:
        seed (int | None): Random seed for reproducibility. Defaults to None.
        verbose (int | bool | None): Controls verbosity of CatBoost. Defaults to 0.
        **kwargs: Additional keyword arguments to pass to the CatBoostRegressor.

    Attributes:
        name (str): Name of the model ("CATBOOST").
        model_params (dict): Parameters for the CatBoostRegressor.
        model (MultiOutputRegressor): A CatBoostRegressor wrapped for multi-output regression.
    """

    def __init__(self, model_config: CATBOOSTConfig | None = None):
        self.model_config = model_config if model_config is not None else QRCATBOOSTConfig()
        super().__init__(
            model_config=self.model_config.model_dump(),
            model_instance=CatBoostRegressor,
            quantiles=self.model_config.quantiles,  # type: ignore[attr-defined]
            conf_level=self.model_config.conf_level,  # type: ignore[attr-defined]
        )
