"""Gaussian CatBoost probabilistic model using RMSEWithUncertainty.

Replaces the previous two-stage custom-loss approach (GaussianMeanLoss +
GaussianSigmaLoss) with CatBoost's built-in ``RMSEWithUncertainty`` loss,
which jointly optimises mean and aleatoric uncertainty via the negative
log-likelihood of a Normal distribution with GPU support.

Epistemic (knowledge) uncertainty is obtained post-training through
:meth:`GAUSSCATBOOSTModel.predict_with_uncertainty`, which calls
``virtual_ensembles_predict`` with ``prediction_type="TotalUncertainty"``.
"""

from __future__ import annotations

from typing import Literal, override

from catboost import CatBoostRegressor
import numpy as np
from pydantic import Field

from twiga.core.config import BaseSearchSpace
from twiga.models.ml.catboost_model import CATBOOSTConfig

from .core.base_regressor import BaseRegressor


class GAUSSCATBOOSTConfig(CATBOOSTConfig):
    """Configuration for the Gaussian CatBoost probabilistic model.

    Extends :class:`CATBOOSTConfig` with:

    * Tighter hyperparameter search bounds for faster convergence.
    * ``od_type`` / ``od_wait`` for built-in overfitting detection.
    * ``virtual_ensembles_count`` to control the number of virtual ensemble
      snapshots used to estimate epistemic uncertainty.

    Attributes:
        name: Fixed to ``"gausscatboost"``.
        od_type: Overfitting detection strategy (``"Iter"`` or
            ``"IncToDec"``).  Active only when an eval set is provided to
            :meth:`GAUSSCATBOOSTModel.fit`.
        od_wait: Number of iterations without improvement before early
            stopping triggers.
        virtual_ensembles_count: Number of virtual ensemble snapshots used
            by :meth:`predict_with_uncertainty`.  Not passed to
            ``CatBoostRegressor`` (excluded from ``model_dump``).
    """

    name: Literal["gausscatboost"] = Field(  # type: ignore[assignment]
        default="gausscatboost",
        description="Fixed model identifier.",
        alias="model_name",
    )
    domain: Literal["ml"] = Field(
        default="ml",
        description="Modelling domain identifier, fixed to 'ml'.",
        exclude=True,
    )
    od_type: Literal["Iter", "IncToDec"] = Field(
        default="Iter",
        description="Overfitting detection type. 'Iter' stops after od_wait "
        "iterations with no improvement on the eval set.",
    )
    od_wait: int = Field(
        default=20,
        ge=1,
        description="Number of iterations to wait for improvement before early stopping (requires eval_set in fit()).",
    )
    virtual_ensembles_count: int = Field(
        default=10,
        ge=1,
        description="Number of virtual ensemble snapshots used to estimate "
        "epistemic uncertainty via virtual_ensembles_predict. "
        "Not passed to CatBoostRegressor.",
        exclude=True,
    )
    # Override base search space: tighter depth/iteration bounds + extra params
    search_space: BaseSearchSpace = Field(
        default_factory=lambda: BaseSearchSpace(  # type: ignore[call-arg]
            learning_rate=(1e-3, 0.3),
            depth=(4, 8),
            iterations=(100, 2000),
            min_data_in_leaf=(1, 50),
            l2_leaf_reg=(1.0, 10.0),
            bagging_temperature=(0.0, 1.0),
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


class GAUSSCATBOOSTModel(BaseRegressor):
    """Probabilistic CatBoost model predicting mean and uncertainty.

    Uses ``loss_function="RMSEWithUncertainty"`` which maximises the
    log-likelihood of a Normal distribution, jointly learning the mean μ
    and aleatoric scale σ in a single model.

    For multi-horizon forecasting (H output steps), one
    :class:`~catboost.CatBoostRegressor` is trained per output, yielding
    H models.  This avoids :class:`~sklearn.multioutput.MultiOutputRegressor`
    while preserving support for ``virtual_ensembles_predict``.

    Uncertainty decomposition via :meth:`predict_with_uncertainty` returns
    three components per output step:

    * ``mean`` - predicted mean (same as :meth:`predict` μ output).
    * ``knowledge_uncertainty`` - epistemic (model) uncertainty estimated
      from variance across virtual ensemble snapshots.
    * ``data_uncertainty`` - aleatoric uncertainty encoded in the model's
      second output (exp of predicted log-σ).

    Args:
        model_config: Model configuration. Defaults to
            :class:`GAUSSCATBOOSTConfig`.

    Example::

        model = GAUSSCATBOOSTModel()
        model.fit(X_train, y_train)
        mu, sigma = model.predict(X_test)
        unc = model.predict_with_uncertainty(X_test)  # (B, L, H, 3)
    """

    def __init__(self, model_config: GAUSSCATBOOSTConfig | None = None) -> None:
        self.model_config = model_config if model_config is not None else GAUSSCATBOOSTConfig()
        params = self.model_config.model_dump()
        params["loss_function"] = "RMSEWithUncertainty"
        self._base_params: dict = params
        self.virtual_ensembles_count: int = self.model_config.virtual_ensembles_count
        self.models: list[CatBoostRegressor] = []
        self.num_targets: int | None = None

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    @override
    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        eval_set: tuple[np.ndarray, np.ndarray] | None = None,
        verbose: bool = False,
    ) -> GAUSSCATBOOSTModel:
        """Fit one ``RMSEWithUncertainty`` model per output step.

        Args:
            X: Shape ``(B, L, F)`` - batch × sequence × features.
            y: Shape ``(B, L, H)`` - batch × sequence × horizons.
            eval_set: Optional ``(X_val, y_val)`` for early stopping.
                When provided, ``od_type`` / ``od_wait`` from the config
                activate CatBoost's overfitting detector.
            verbose: Whether to print CatBoost training logs.

        Returns:
            Self for method chaining.

        Raises:
            ValueError: If ``X`` or ``y`` are not 3-dimensional.
        """
        if X.ndim != 3 or y.ndim != 3:
            raise ValueError("X and y must be 3-dimensional arrays.")

        batch_size, _, _ = X.shape
        _, _, self.num_targets = y.shape

        x_2d = self.format_features(X)  # (B, L*F)
        y_2d = self.format_features(y)  # (B, L*H)
        n_outputs = y_2d.shape[1]  # L * H

        self._capture_feature_names(X, x_2d.shape[1])

        # Prepare validation data once if provided
        x_val_2d: np.ndarray | None = None
        y_val_2d: np.ndarray | None = None
        if eval_set is not None:
            x_val_2d = self._apply_feature_names(self.format_features(eval_set[0]))
            y_val_2d = self.format_features(eval_set[1])

        self.models = []
        for j in range(n_outputs):
            m = CatBoostRegressor(**self._base_params)
            fit_kwargs: dict = {"verbose": verbose}
            if x_val_2d is not None and y_val_2d is not None:
                fit_kwargs["eval_set"] = (x_val_2d, y_val_2d[:, j])
            m.fit(self._apply_feature_names(x_2d), y_2d[:, j], **fit_kwargs)
            self.models.append(m)

        return self

    # ------------------------------------------------------------------
    # Predict
    # ------------------------------------------------------------------

    @override
    def predict(self, X: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Predict mean (μ) and scale (σ) for all output steps.

        Args:
            X: Shape ``(B, L, F)``.

        Returns:
            Tuple ``(mu, sigma)`` each of shape ``(B, L, H)``.
            ``sigma = exp(log_sigma)`` is guaranteed positive.

        Raises:
            ValueError: If the model has not been fitted or X is not 3-D.
        """
        if not self.models:
            raise ValueError("Model has not been fitted yet.")
        if X.ndim != 3:
            raise ValueError("Input array X must be 3-dimensional.")

        batch_size, _, _ = X.shape
        x_2d = self._apply_feature_names(self.format_features(X))

        # Each model returns (B, 2): col 0 = μ, col 1 = log σ
        preds = np.stack([m.predict(x_2d) for m in self.models], axis=1)
        # preds shape: (B, L*H, 2)

        mu_flat = preds[:, :, 0]  # (B, L*H)
        sigma_flat = np.exp(preds[:, :, 1])  # (B, L*H)  σ = exp(log σ)

        mu = mu_flat.reshape(batch_size, -1, self.num_targets)
        sigma = sigma_flat.reshape(batch_size, -1, self.num_targets)
        return mu, sigma

    # ------------------------------------------------------------------
    # Uncertainty decomposition
    # ------------------------------------------------------------------

    def predict_with_uncertainty(self, X: np.ndarray) -> np.ndarray:
        """Return mean, epistemic, and aleatoric uncertainty per output.

        Uses ``virtual_ensembles_predict(prediction_type="TotalUncertainty")``
        which - for models trained with ``RMSEWithUncertainty`` - returns
        three values per sample:

        * Column 0: mean prediction (μ).
        * Column 1: knowledge (epistemic) uncertainty - variance across
          virtual ensemble snapshots.
        * Column 2: data (aleatoric) uncertainty - derived from the
          predicted log-σ output.

        Args:
            X: Shape ``(B, L, F)``.

        Returns:
            Array of shape ``(B, L, H, 3)`` - last axis is
            ``[mean, knowledge_uncertainty, data_uncertainty]``.

        Raises:
            ValueError: If the model has not been fitted.
        """
        if not self.models:
            raise ValueError("Model has not been fitted yet.")

        batch_size, _, _ = X.shape
        x_2d = self.format_features(X)

        results = []
        for m in self.models:
            unc = m.virtual_ensembles_predict(
                x_2d,
                prediction_type="TotalUncertainty",
                virtual_ensembles_count=self.virtual_ensembles_count,
            )
            # unc shape: (B, 3) - [mean, knowledge_unc, data_unc]
            results.append(unc)

        out = np.stack(results, axis=1)  # (B, L*H, 3)
        return out.reshape(batch_size, -1, self.num_targets, 3)

    # ------------------------------------------------------------------
    # HPO
    # ------------------------------------------------------------------

    @override
    def update(self, trial) -> None:
        """Rebuild model from an Optuna trial's suggested hyperparameters.

        Args:
            trial: Optuna trial object.
        """
        params = self.model_config.get_optuna_params(trial=trial)
        params["loss_function"] = "RMSEWithUncertainty"
        self._base_params = params
        self.models = []
        self.num_targets = None
