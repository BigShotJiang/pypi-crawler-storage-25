"""Context-Parroting Baseline with tau support and simplex projection.

Supports any number of target columns. Each target is processed independently
using the selected forecasting strategy.

Two forecasting strategies selectable via ``method``:

* ``"parrot"`` - copy the tail that follows the best-matching motif (original).
* ``"simplex"`` - autoregressive k-NN simplex projection (Sugihara-style weighted
  average of k nearest neighbours in delay-embedding space).
"""

from __future__ import annotations

from typing import Literal

import numpy as np
from pydantic import Field, field_validator
from scipy.spatial.distance import cdist
from sklearn.base import BaseEstimator, RegressorMixin

from twiga.core.config import BaseModelConfig, BaseSearchSpace


class CONTEXTPARROTConfig(BaseModelConfig):
    """Configuration for the context-parroting baseline model.

    Attributes:
        name: Fixed to ``"context_parrot"``.
        domain: Fixed to ``"baseline"``. Excluded from model params.
        embedding_dim: Delay embedding dimension D (motif length).
        tau: Delay (lag) between embedding coordinates.
        method: Forecasting strategy - ``"parrot"`` copies the tail after the
            best-matching motif; ``"simplex"`` uses autoregressive k-NN
            simplex projection.
        k: Number of nearest neighbours for simplex projection. Defaults to
            ``embedding_dim + 1`` when ``None``. Ignored for ``"parrot"`` method.
        search_space: Optuna search space for ``embedding_dim``.
    """

    name: Literal["context_parrot"] = Field(  # type: ignore[assignment]
        default="context_parrot",
        description="Model identifier fixed to 'context_parrot'.",
        alias="model_name",
        exclude=True,
    )
    domain: Literal["baseline"] = Field(  # type: ignore[assignment]
        default="baseline",
        description="Modelling domain identifier, fixed to 'baseline'.",
        exclude=True,
    )
    embedding_dim: int = Field(
        default=10,
        gt=0,
        description="Delay embedding dimension D (motif length).",
    )
    tau: int = Field(
        default=1,
        gt=0,
        description="Delay (lag) between embedding coordinates.",
    )
    method: Literal["parrot", "simplex"] = Field(
        default="parrot",
        description=(
            "Forecasting strategy: 'parrot' copies the tail after the best-matching "
            "motif; 'simplex' uses autoregressive k-NN simplex projection."
        ),
    )
    k: int | None = Field(
        default=None,
        gt=0,
        description=(
            "Number of nearest neighbours for simplex projection. "
            "Defaults to embedding_dim + 1 when None. Ignored for 'parrot' method."
        ),
    )
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(embedding_dim=[5, 10, 24, 48, 96]),
        description="Optuna search space for embedding_dim.",
        exclude=True,
    )

    @field_validator("embedding_dim", "tau")
    @classmethod
    def _validate_positive(cls, v: int) -> int:
        if v <= 0:
            raise ValueError(f"{cls.__name__} must be positive, got {v}")
        return v


class CONTEXTPARROTModel(BaseEstimator, RegressorMixin):
    """Context-parroting forecaster supporting multiple target columns.

    Implements two non-parametric forecasting strategies based on delay-
    coordinate embedding of the input window. Each target column is processed
    independently using the selected strategy.

    The first ``num_targets`` columns of ``x`` are treated as the target series.
    The model has no trainable parameters; ``fit`` only validates shape and
    stores metadata.

    Args:
        model_config: Configuration object. Defaults to
            :class:`CONTEXTPARROTConfig` (strategy ``"parrot"``).

    Example::

        model = CONTEXTPARROTModel()
        model.fit(X_train, y_train)
        preds = model.predict(X_test)  # shape (B, H, num_targets)
    """

    def __init__(self, model_config: CONTEXTPARROTConfig | None = None) -> None:
        super().__init__()
        self.model_config = model_config or CONTEXTPARROTConfig()
        self.num_targets: int | None = None
        self.horizon: int | None = None
        self.model: None = None

    @property
    def min_seq_len(self) -> int:
        """Minimum lookback window length required.

        Derived from the constraint that n_candidates = L - 2*D >= 1,
        which gives L >= 2*D + 1.
        """
        return 2 * self.model_config.embedding_dim + 1

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        eval_set: tuple[np.ndarray, np.ndarray] | None = None,
        verbose: bool = False,
    ) -> CONTEXTPARROTModel:
        """Validate input shape and store metadata.

        Args:
            X: Shape ``(B, L, F)`` - lookback features; first ``T`` columns
               are the target series used for matching.
            y: Shape ``(B, H, T)`` - targets used to determine horizon and T.
            eval_set: Ignored; accepted for interface compatibility.
            verbose: Ignored.

        Returns:
            Self.
        """
        if X.ndim != 3 or y.ndim != 3:
            raise ValueError("X and y must be 3-dimensional arrays (B, L, F) and (B, H, T).")

        _, seq_len, _ = X.shape
        _, horizon, num_targets = y.shape

        if seq_len < self.min_seq_len:
            raise ValueError(
                f"Sequence length ({seq_len}) is too short. "
                f"Minimum required for D={self.model_config.embedding_dim}, "
                f"tau={self.model_config.tau} is {self.min_seq_len}."
            )

        self.horizon = horizon
        self.num_targets = num_targets
        return self

    # ====================== Core Helpers ======================

    @staticmethod
    def _delay_embedding(data: np.ndarray, D: int, tau: int) -> np.ndarray:
        """Safe vectorized delay embedding.

        Returns shape ``(n_windows, D)`` where each row is
        ``[x_t, x_{t+tau}, ..., x_{t+(D-1)*tau}]``.
        """
        n = len(data)
        if (D - 1) * tau + 1 > n:
            raise ValueError("Not enough data points for the requested embedding.")
        n_windows = n - (D - 1) * tau
        starts = np.arange(n_windows)
        offsets = np.arange(D) * tau
        return data[starts[:, None] + offsets[None, :]]  # (n_windows, D)

    @staticmethod
    def _simplex_embed(x: np.ndarray, m: int, tau: int):
        """Delay-coordinate embedding for simplex projection.

        Returns:
            x_lib: shape ``(L, m)`` - library of embedded state vectors.
            y_lib: shape ``(L,)``   - one-step-ahead targets.
        """
        n = len(x)
        max_lag = (m - 1) * tau
        if n - tau - max_lag <= 0:
            return np.empty((0, m)), np.empty((0,))
        idxs = np.arange(max_lag, n - tau)
        x_lib = np.column_stack([x[idxs - j * tau] for j in range(m)])
        y_lib = x[idxs + tau]
        return x_lib, y_lib

    @staticmethod
    def _simplex_state(series: np.ndarray, m: int, tau: int) -> np.ndarray:
        """Build the current state vector from the tail of a series."""
        needed = (m - 1) * tau
        if len(series) - 1 - needed < 0:
            raise ValueError("Insufficient history to form the current state.")
        base = len(series) - 1
        return np.array([series[base - j * tau] for j in range(m)], dtype=np.float64)

    @staticmethod
    def _simplex_step(state: np.ndarray, x_lib: np.ndarray, y_lib: np.ndarray, k: int) -> float:
        """One-step Sugihara simplex projection: exponentially-weighted k-NN average."""
        dists = np.linalg.norm(x_lib - state[None, :], axis=1)
        idx = np.argpartition(dists, k - 1)[:k]
        nn_d, nn_y = dists[idx], y_lib[idx]
        d1 = nn_d.min()
        if d1 == 0.0:
            mask = (nn_d == 0.0).astype(np.float64)
            w = mask / mask.sum()
        else:
            w = np.exp(-nn_d / d1)
            w /= w.sum()
        return float(np.dot(w, nn_y))

    # ====================== Prediction ======================

    def predict(self, x: np.ndarray) -> np.ndarray:
        """Forecast using the configured method ('parrot' or 'simplex').

        Args:
            x: Shape ``(B, L, F)``. The first ``num_targets`` columns are the
               target series used for matching.

        Returns:
            Predictions of shape ``(B, H, num_targets)``.
        """
        if self.horizon is None or self.num_targets is None:
            raise ValueError("Model has not been fitted yet. Call fit() first.")
        if x.ndim != 3:
            raise ValueError("Input x must be a 3-dimensional array of shape (B, L, F).")

        b_size, seq_len, _ = x.shape
        if self.min_seq_len > seq_len:
            raise ValueError(f"Sequence length {seq_len} < minimum required {self.min_seq_len}.")

        if self.model_config.method == "parrot":
            return self._predict_parrot(x, b_size, seq_len)
        return self._predict_simplex(x, b_size)

    def _predict_parrot(self, x: np.ndarray, b_size: int, seq_len: int) -> np.ndarray:
        """Copy the tail that follows the best-matching motif for each target."""
        emb_dim = self.model_config.embedding_dim
        tau = self.model_config.tau
        horizon = self.horizon
        num_targets = self.num_targets
        output = np.empty((b_size, horizon, num_targets), dtype=np.float64)

        for b in range(b_size):
            for t in range(num_targets):
                series = x[b, :, t].astype(np.float64)

                n_candidates = seq_len - 2 * emb_dim
                if n_candidates < 1:
                    output[b, :, t] = series[-1]
                    continue

                candidates = self._delay_embedding(series[: seq_len - emb_dim], emb_dim, tau)
                tail_start = -emb_dim * tau - (emb_dim - 1) * tau
                query = self._delay_embedding(series[tail_start:], emb_dim, tau)[-1:].reshape(1, -1)
                distances = cdist(candidates, query, metric="euclidean").ravel()
                best_idx = int(np.argmin(distances))

                forecast_start = best_idx + emb_dim * tau
                tail = series[forecast_start:]

                if len(tail) >= horizon:
                    output[b, :, t] = tail[:horizon]
                elif len(tail) > 0:
                    repeats = horizon // len(tail) + 1
                    output[b, :, t] = np.tile(tail, repeats)[:horizon]
                else:
                    output[b, :, t] = series[-1]

        return output

    def _predict_simplex(self, x: np.ndarray, b_size: int) -> np.ndarray:
        """Autoregressive k-NN simplex projection for each target (Sugihara-style)."""
        emb_dim = self.model_config.embedding_dim
        tau = self.model_config.tau
        horizon = self.horizon
        num_targets = self.num_targets
        k_cfg = self.model_config.k
        output = np.empty((b_size, horizon, num_targets), dtype=np.float64)

        for b in range(b_size):
            for t in range(num_targets):
                series = x[b, :, t].astype(np.float64)
                x_lib, y_lib = self._simplex_embed(series, emb_dim, tau)

                if len(x_lib) == 0:
                    output[b, :, t] = series[-1]
                    continue

                k = k_cfg if k_cfg is not None else (emb_dim + 1)
                k = max(1, min(k, len(x_lib)))

                history = series.copy()
                preds = []
                for _ in range(horizon):
                    state = self._simplex_state(history, emb_dim, tau)
                    val = self._simplex_step(state, x_lib, y_lib, k)
                    preds.append(val)
                    history = np.append(history, val)

                output[b, :, t] = np.asarray(preds, dtype=np.float64)

        return output

    def forecast(self, x: np.ndarray) -> np.ndarray:
        """Alias for predict."""
        return self.predict(x)

    def update(self, trial) -> None:
        """Support HPO for embedding_dim."""
        params = self.model_config.get_optuna_params(trial=trial)
        new_dim = params.get("embedding_dim", self.model_config.embedding_dim)
        self.model_config = CONTEXTPARROTConfig(
            embedding_dim=new_dim,
            tau=self.model_config.tau,
            method=self.model_config.method,
            k=self.model_config.k,
        )
