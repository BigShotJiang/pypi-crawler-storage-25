"""Naive baseline forecasting models.

Provides two persistence strategies for point forecasting:

* ``"last"`` - broadcasts the last training-set target value to every test
  sample and every horizon step.  Use this when you want a single fixed
  reference derived from the training distribution.

* ``"window_last"`` - for each test window, uses the most recently observed
  target values from the input context ``X[:, -1, :num_targets]`` as the
  prediction for all forecast horizon steps.  This is the standard
  *persistence* or *naïve* forecast: ŷ_{t+h} = y_t for all h.

  .. important::

     ``"window_last"`` assumes that the **first** ``num_targets`` features at
     the final time step of ``X`` (i.e. ``X[:, -1, :num_targets]``) are the
     most-recent target observations.  Twiga's
     :class:`~twiga.core.data.pipeline.DataPipeline` places target lags as
     the leading feature columns by default, so this convention holds for
     standard configurations.

* ``"mean"`` - broadcasts the per-output training mean to every test sample
  and step.  Useful as a constant-mean lower bound.

* ``"zero"`` - predicts zero everywhere.  Useful when the target is a
  centred or differenced series.
"""

from __future__ import annotations

from typing import Literal

import numpy as np
from pydantic import Field

from twiga.core.config import BaseModelConfig, BaseSearchSpace
from twiga.models.ml.core.base_regressor import BaseRegressor


class NAIVEConfig(BaseModelConfig):
    """Configuration for the naive baseline forecasting model.

    Attributes:
        name: Fixed to ``"naive"``.
        domain: Fixed to ``"baseline"``.  Excluded from model params.
        strategy: Prediction strategy.

            * ``"last"``        - last training-set target (constant across all
              test windows).
            * ``"window_last"`` - last observed value in each test window
              (per-sample persistence, true naïve forecast).
            * ``"mean"``        - training-set per-output mean (constant
              across all test windows).
            * ``"zero"``        - predict zero everywhere.

        search_space: Optuna search space exposing ``strategy`` as a
            categorical knob so HPO sweeps can include baseline comparisons.
    """

    name: Literal["naive"] = Field(  # type: ignore[assignment]
        default="naive",
        description="Model identifier fixed to 'naive'.",
        alias="model_name",
        exclude=True,
    )
    domain: Literal["baseline"] = Field(  # type: ignore[assignment]
        default="baseline",
        description="Modelling domain identifier, fixed to 'baseline'.",
        exclude=True,
    )
    strategy: Literal["last", "window_last", "mean", "zero"] = Field(
        default="window_last",
        description=(
            "Prediction strategy: 'last' (last training value), "
            "'window_last' (last value in each test window - true naïve), "
            "'mean' (training mean), or 'zero'."
        ),
    )
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            strategy=["last", "window_last", "mean", "zero"],
        ),
        description="Optuna search space for the naive strategy.",
        exclude=True,
    )


class NAIVEModel(BaseRegressor):
    """Naive baseline for point multi-horizon forecasting.

    Implements four persistence strategies that serve as reference baselines
    for benchmarking learned models.  The model has no trainable parameters;
    ``fit`` only stores summary statistics from the training targets.

    For the ``"window_last"`` strategy the model is a true per-window
    persistence forecast: ŷ_{t+h} = y_t for all h, using the most recently
    observed target values from the input context.

    The ``eval_set`` argument in :meth:`fit` is accepted for API
    compatibility and silently ignored.

    Args:
        model_config: Configuration object.  Defaults to
            :class:`NAIVEConfig` (strategy ``"window_last"``).

    Example::

        model = NAIVEModel()
        model.fit(X_train, y_train)
        preds = model.predict(X_test)  # shape (B, L, H)
    """

    def __init__(self, model_config: NAIVEConfig | None = None) -> None:
        self.model_config = model_config or NAIVEConfig()
        self._constant: np.ndarray | None = None  # used by last / mean / zero
        self.num_targets: int | None = None
        self.horizon: int | None = None
        self.model = None  # no sklearn model - override BaseRegressor guard

    @property
    def min_seq_len(self) -> int:
        """Minimum lookback window length required by this model.

        All naive strategies work with any L ≥ 1, so this always returns
        ``1``.  Provided for API consistency with other baseline models.
        """
        return 1

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        eval_set: tuple[np.ndarray, np.ndarray] | None = None,
        verbose: bool = False,
    ) -> NAIVEModel:
        """Compute and store the training-set constant.

        Args:
            X: Shape ``(B, L, F)`` - ignored except for shape information.
            y: Shape ``(B, L, H)`` - training targets.
            eval_set: Accepted for API compatibility; silently ignored.
            verbose: Unused; included for interface consistency.

        Returns:
            Self for method chaining.
        """
        if y.ndim == 3:
            _, self.horizon, self.num_targets = y.shape
        else:
            self.horizon = 1
            self.num_targets = 1

        y_fmt = self.format_features(y)  # (B, L*H)

        strategy = self.model_config.strategy
        if strategy == "last":
            self._constant = y_fmt[-1]  # last training sample, shape (L*H,)
        elif strategy == "mean":
            self._constant = y_fmt.mean(axis=0)  # per-output mean, shape (L*H,)
        elif strategy == "zero":
            self._constant = np.zeros(y_fmt.shape[1])
        # "window_last" requires no stored constant - uses X at predict time

        return self

    # ------------------------------------------------------------------
    # Predict
    # ------------------------------------------------------------------

    def predict(self, x: np.ndarray) -> np.ndarray:
        """Return naive predictions for the input batch.

        Args:
            x: Shape ``(B, L, F)``.

        Returns:
            Predictions of shape ``(B, L, H)``.

        Raises:
            ValueError: If the model has not been fitted or x is not 3-D.
        """
        if self.num_targets is None:
            raise ValueError("Model has not been fitted yet.")
        if x.ndim != 3:
            raise ValueError("Input array x must be 3-dimensional.")

        batch_size = x.shape[0]
        strategy = self.model_config.strategy

        if strategy == "window_last":
            # Per-window persistence: take the last time step's leading
            # num_targets features as the prediction for all horizon steps.
            last_obs = x[:, -1, : self.num_targets]  # (B, H)
            preds = np.broadcast_to(
                last_obs[:, np.newaxis, :],
                (batch_size, self.horizon, self.num_targets),
            ).copy()
        else:
            # Broadcast stored constant to all samples
            preds = np.broadcast_to(
                self._constant,  # (L*H,)
                (batch_size, len(self._constant)),  # type: ignore[arg-type]
            ).copy()
            preds = preds.reshape(batch_size, self.horizon, self.num_targets)

        return preds

    def forecast(self, x: np.ndarray) -> np.ndarray:
        """Return naive point forecast (raw array, no wrapping dict)."""
        return self.predict(x)

    def update(self, trial) -> None:
        """Rebuild config from an Optuna trial's suggested strategy."""
        params = self.model_config.get_optuna_params(trial=trial)
        new_strategy = params.get("strategy", self.model_config.strategy)
        self.model_config = NAIVEConfig(strategy=new_strategy)
        self._constant = None
