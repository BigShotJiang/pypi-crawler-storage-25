"""Window-average baseline model.

Computes the mean of the last ``window_size`` observed target values
within each input window and broadcasts that mean to all forecast
horizon steps:

    ŷ_{t+h} = mean(y_{t-W+1}, …, y_t)   for h = 1, …, H

Unlike :class:`~twiga.models.baseline.naive_model.NAIVEModel` with
``strategy="mean"`` (which uses a fixed training-set mean), this model
adapts to the **local level** of each test window, making it a stronger
and more practically relevant baseline.

**Feature-column convention**: ``X[:, t, :num_targets]`` must contain
the raw observed target values at time step *t* within the lookback
window.  See :mod:`twiga.models.baseline.seasonal_naive_model` for a
full explanation of this convention.
"""

from __future__ import annotations

from typing import Literal

import numpy as np
from pydantic import Field, field_validator

from twiga.core.config import BaseModelConfig, BaseSearchSpace
from twiga.models.ml.core.base_regressor import BaseRegressor


class WINDOWAVERAGEConfig(BaseModelConfig):
    """Configuration for the window-average baseline model.

    Attributes:
        name: Fixed to ``"window_average"``.
        domain: Fixed to ``"baseline"``.  Excluded from model params.
        window_size: Number of the most-recent time steps to average.
            ``None`` (default) uses the full lookback window length L.
            Must be a positive integer when specified.
        search_space: Optuna search space exposing common window sizes
            as a categorical knob.
    """

    name: Literal["window_average"] = Field(  # type: ignore[assignment]
        default="window_average",
        description="Model identifier fixed to 'window_average'.",
        alias="model_name",
        exclude=True,
    )
    domain: Literal["baseline"] = Field(  # type: ignore[assignment]
        default="baseline",
        description="Modelling domain identifier, fixed to 'baseline'.",
        exclude=True,
    )
    window_size: int | None = Field(
        default=None,
        description=(
            "Number of most-recent steps to average.  None = full lookback "
            "window.  Must be a positive integer when specified."
        ),
    )
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            window_size=[4, 8, 12, 24, 48, 96, 168],
        ),
        description="Optuna search space for window_size.",
        exclude=True,
    )

    @field_validator("window_size")
    @classmethod
    def _validate_window_size(cls, v: int | None) -> int | None:
        if v is not None and v <= 0:
            raise ValueError(f"window_size must be a positive integer, got {v}")
        return v


class WINDOWAVERAGEModel(BaseRegressor):
    """Window-average baseline for multi-horizon forecasting.

    Predicts the local mean of the last ``window_size`` observed target
    values in the input context for all forecast horizon steps.  The mean
    adapts to the current level of each window, unlike a global training
    mean.

    Args:
        model_config: Configuration object.  Defaults to
            :class:`WINDOWAVERAGEConfig` (full-window average).

    Example::

        # Average over the last 24 steps (1 day at hourly resolution)
        model = WINDOWAVERAGEModel(WINDOWAVERAGEConfig(window_size=24))
        model.fit(X_train, y_train)
        preds = model.predict(X_test)  # (B, L, H)
    """

    def __init__(self, model_config: WINDOWAVERAGEConfig | None = None) -> None:
        self.model_config = model_config or WINDOWAVERAGEConfig()
        self.num_targets: int | None = None
        self.horizon: int | None = None
        self.model = None  # no sklearn model

    @property
    def min_seq_len(self) -> int:
        """Minimum lookback window length required by the configured window_size.

        Returns ``window_size`` when set, or ``1`` when ``window_size=None``
        (full-window average adapts to any L).

        Example::

            model = WINDOWAVERAGEModel(WINDOWAVERAGEConfig(window_size=168))
            assert pipeline_config.seq_len >= model.min_seq_len
        """
        return self.model_config.window_size if self.model_config.window_size is not None else 1

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        eval_set: tuple[np.ndarray, np.ndarray] | None = None,
        verbose: bool = False,
    ) -> WINDOWAVERAGEModel:
        """Store target shape information.

        Args:
            X: Shape ``(B, L, F)``.
            y: Shape ``(B, L, H)``.
            eval_set: Accepted for API compatibility; silently ignored.
            verbose: Unused; included for interface consistency.

        Returns:
            Self for method chaining.

        Raises:
            ValueError: If ``X`` or ``y`` are not 3-dimensional, or if
                ``window_size`` exceeds the sequence length ``L``.
        """
        if X.ndim != 3 or y.ndim != 3:
            raise ValueError("X and y must be 3-dimensional arrays.")

        seq_len = X.shape[1]
        _, self.horizon, self.num_targets = y.shape

        w = self.model_config.window_size
        if w is not None and w > seq_len:
            raise ValueError(
                f"window_size ({w}) exceeds the input sequence length ({seq_len}).  "
                f"Set your lookback window to at least {w} steps, or reduce window_size.  "
                f"Hint: model.min_seq_len returns the minimum required lookback.",
            )
        return self

    # ------------------------------------------------------------------
    # Predict
    # ------------------------------------------------------------------

    def predict(self, x: np.ndarray) -> np.ndarray:
        """Return window-average predictions.

        Args:
            x: Shape ``(B, L, F)``.

        Returns:
            Predictions of shape ``(B, L_horizon, H)``.  All horizon
            steps receive the same local mean value.

        Raises:
            ValueError: If the model has not been fitted or x is not 3-D.
        """
        if self.num_targets is None:
            raise ValueError("Model has not been fitted yet.")
        if x.ndim != 3:
            raise ValueError("Input array x must be 3-dimensional.")

        batch_size, seq_len, _ = x.shape
        w = self.model_config.window_size or seq_len  # None → full window

        # Mean over last w steps of the first num_targets feature columns
        window = x[:, -w:, : self.num_targets]  # (B, w, H)
        avg = window.mean(axis=1)  # (B, H)

        # Broadcast to (B, horizon, num_targets)
        return np.broadcast_to(
            avg[:, np.newaxis, :],
            (batch_size, self.horizon, self.num_targets),  # type: ignore[arg-type]
        ).copy()

    def forecast(self, x: np.ndarray) -> np.ndarray:
        """Return window-average point forecast (raw array)."""
        return self.predict(x)

    # ------------------------------------------------------------------
    # HPO
    # ------------------------------------------------------------------

    def update(self, trial) -> None:
        """Rebuild config from an Optuna trial's suggested window_size."""
        params = self.model_config.get_optuna_params(trial=trial)
        new_w = params.get("window_size", self.model_config.window_size)
        self.model_config = WINDOWAVERAGEConfig(window_size=new_w)
