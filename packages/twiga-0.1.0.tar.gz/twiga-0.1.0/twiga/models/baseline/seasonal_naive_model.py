"""Seasonal naïve baseline model.

Implements the classical ``SeasonalNaive`` forecast:

    ŷ_{t+h} = y_{t + h - m}   for h = 1, …, H

where *m* is the seasonal period.  For horizons longer than one season
(H > m), the pattern wraps: step h uses the same source position as step
(h mod m).

**Feature-column convention (Option A)**:
The model reads the target series directly from the input array ``X``.
It assumes that ``X[:, t, :num_targets]`` contains the raw observed
target values at time step *t* within the lookback window - i.e. the
**first** ``num_targets`` feature columns at every time step are the
target variable(s) in chronological order.  Twiga's default
:class:`~twiga.core.data.pipeline.DataPipeline` satisfies this
convention because it places target lag features as the leading
columns.
"""

from __future__ import annotations

from typing import Literal

import numpy as np
import pandas as pd
from pydantic import Field, field_validator

from twiga.core.config import BaseModelConfig, BaseSearchSpace
from twiga.models.ml.core.base_regressor import BaseRegressor


def _resolve_period(period: int | str, freq: str) -> int:
    """Convert a period specification to an integer number of data steps.

    Args:
        period: Either a positive integer (already in data steps) or a
            pandas-compatible duration string such as ``"1D"``, ``"7D"``,
            ``"12H"``.  String values are resolved relative to *freq*.
        freq: Sampling frequency of the input data (e.g. ``"1H"``,
            ``"30min"``, ``"15min"``).  Ignored when *period* is an
            integer.

    Returns:
        Number of data steps corresponding to *period*.

    Raises:
        ValueError: If the resolved number of steps is not a positive
            integer, or if *period* is not a whole multiple of *freq*.
    """
    if isinstance(period, int):
        if period <= 0:
            raise ValueError(f"period must be a positive integer, got {period}")
        return period

    # pandas 2.x deprecated uppercase aliases (H→h, T→min, S→s).
    # Normalise both inputs so pd.Timedelta() does not emit FutureWarnings.
    _alias_map = {"H": "h", "T": "min", "S": "s", "U": "us", "N": "ns"}
    _norm = "".join(_alias_map.get(c, c) for c in str(period))
    _norm_freq = "".join(_alias_map.get(c, c) for c in str(freq))

    try:
        ratio = pd.Timedelta(_norm) / pd.Timedelta(_norm_freq)
    except Exception as exc:
        raise ValueError(f"Cannot resolve period={period!r} with freq={freq!r}: {exc}") from exc

    steps = int(ratio)
    if steps != ratio:
        raise ValueError(f"period {period!r} is not a whole multiple of freq {freq!r} (ratio = {ratio}).")
    if steps <= 0:
        raise ValueError(
            f"Resolved period ({period!r} / {freq!r}) = {steps} steps; "
            "period must be larger than the sampling frequency.",
        )
    return steps


class SEASONALNAIVEConfig(BaseModelConfig):
    """Configuration for the seasonal naïve baseline model.

    Attributes:
        name: Fixed to ``"seasonal_naive"``.
        domain: Fixed to ``"baseline"``.  Excluded from model params.
        period: Seasonal period.  Accepts either:

            * A **positive integer** - number of data steps directly
              (e.g. ``48`` for daily periodicity at 30-min resolution).
            * A **pandas duration string** - resolved against ``freq``
              (e.g. ``"1D"``, ``"7D"``, ``"12H"``).  This is the
              default form; ``"1D"`` resolves to 24 steps at ``"1H"``
              sampling and 48 steps at ``"30min"`` sampling.

        freq: Sampling frequency of the input data.  Used only when
            *period* is a string.  Common values: ``"1H"``, ``"30min"``,
            ``"15min"``.
        search_space: Optuna search space exposing ``period`` as a
            categorical knob so HPO sweeps can compare daily vs. weekly
            seasonality.
    """

    name: Literal["seasonal_naive"] = Field(  # type: ignore[assignment]
        default="seasonal_naive",
        description="Model identifier fixed to 'seasonal_naive'.",
        alias="model_name",
        exclude=True,
    )
    domain: Literal["baseline"] = Field(  # type: ignore[assignment]
        default="baseline",
        description="Modelling domain identifier, fixed to 'baseline'.",
        exclude=True,
    )
    period: int | str = Field(
        default="1D",
        description=(
            "Seasonal period: positive integer (data steps) or a pandas "
            "duration string resolved against `freq` (e.g. '1D', '7D')."
        ),
    )
    freq: str = Field(
        default="1h",
        description=(
            "Data sampling frequency used to resolve string periods. "
            "Common values: '1h', '30min', '15min'. Ignored when `period` "
            "is already an integer."
        ),
    )
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            period=["1D", "7D"],
        ),
        description="Optuna search space for the seasonal period.",
        exclude=True,
    )

    @field_validator("period")
    @classmethod
    def _validate_period(cls, v: int | str) -> int | str:
        if isinstance(v, int) and v <= 0:
            raise ValueError(f"period must be a positive integer, got {v}")
        return v


class SEASONALNAIVEModel(BaseRegressor):
    """Seasonal naïve baseline for multi-horizon forecasting.

    Repeats the value observed exactly *m* data steps before each
    forecast step, where *m* is the resolved seasonal period.  For
    forecast horizons longer than one season, the seasonal pattern wraps.

    The model has no trainable parameters.  ``fit`` validates the
    sequence length and resolves the period; all inference work happens
    in ``predict``.

    Args:
        model_config: Configuration object.  Defaults to
            :class:`SEASONALNAIVEConfig` (``period="1D"``, ``freq="1H"``).

    Example::

        # Daily naive on 30-min data (48 steps)
        model = SEASONALNAIVEModel(SEASONALNAIVEConfig(period="1D", freq="30min"))
        model.fit(X_train, y_train)
        preds = model.predict(X_test)  # (B, L, H)

        # Weekly naive on hourly data
        model = SEASONALNAIVEModel(SEASONALNAIVEConfig(period="7D", freq="1H"))
    """

    def __init__(self, model_config: SEASONALNAIVEConfig | None = None) -> None:
        self.model_config = model_config or SEASONALNAIVEConfig()
        self._period_steps: int | None = None
        self.num_targets: int | None = None
        self.horizon: int | None = None
        self.model = None  # no sklearn model

    @property
    def min_seq_len(self) -> int:
        """Minimum lookback window length required by the configured period.

        Use this to validate your data pipeline's lookback setting before
        fitting.  Raises ``ValueError`` if the period cannot be resolved
        (e.g. incompatible freq string).

        Example::

            model = SEASONALNAIVEModel(SEASONALNAIVEConfig(period="7D", freq="1h"))
            assert pipeline_config.seq_len >= model.min_seq_len
        """
        return _resolve_period(self.model_config.period, self.model_config.freq)

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        eval_set: tuple[np.ndarray, np.ndarray] | None = None,
        verbose: bool = False,
    ) -> SEASONALNAIVEModel:
        """Resolve the seasonal period and validate the sequence length.

        Args:
            X: Shape ``(B, L, F)``.  ``L`` must be ≥ resolved period.
            y: Shape ``(B, L, H)``.
            eval_set: Accepted for API compatibility; silently ignored.
            verbose: Unused; included for interface consistency.

        Returns:
            Self for method chaining.

        Raises:
            ValueError: If the resolved period exceeds the sequence length
                ``L``, or if ``X`` or ``y`` are not 3-dimensional.
        """
        if X.ndim != 3 or y.ndim != 3:
            raise ValueError("X and y must be 3-dimensional arrays.")

        _, seq_len, _ = X.shape
        _, self.horizon, self.num_targets = y.shape

        self._period_steps = _resolve_period(self.model_config.period, self.model_config.freq)

        if self._period_steps > seq_len:
            raise ValueError(
                f"Resolved period {self._period_steps} steps "
                f"(period={self.model_config.period!r} @ freq={self.model_config.freq!r}) "
                f"exceeds the input sequence length {seq_len}.  "
                f"Set your lookback window to at least {self._period_steps} steps, "
                f"or use a shorter period.  "
                f"Hint: model.min_seq_len returns the minimum required lookback.",
            )
        return self

    # ------------------------------------------------------------------
    # Predict
    # ------------------------------------------------------------------

    def predict(self, x: np.ndarray) -> np.ndarray:
        """Return seasonal naïve predictions.

        For forecast step h (0-indexed), the prediction is taken from
        position ``x[:, L - m + (h % m), :num_targets]`` in the input
        window, where L is the sequence length and m is the period.

        Args:
            x: Shape ``(B, L, F)``.  L must be ≥ fitted period.

        Returns:
            Predictions of shape ``(B, L_horizon, H)``.

        Raises:
            ValueError: If the model has not been fitted or x is not 3-D.
        """
        if self._period_steps is None:
            raise ValueError("Model has not been fitted yet.")
        if x.ndim != 3:
            raise ValueError("Input array x must be 3-dimensional.")

        seq_len = x.shape[1]
        m = self._period_steps

        if m > seq_len:
            raise ValueError(f"Period ({m} steps) exceeds test sequence length ({seq_len}).")

        # Source indices for each forecast step: vectorised gather
        indices = [seq_len - m + (h % m) for h in range(self.horizon)]  # type: ignore[arg-type]
        return x[:, indices, : self.num_targets].copy()

    def forecast(self, x: np.ndarray) -> np.ndarray:
        """Return seasonal naïve point forecast (raw array)."""
        return self.predict(x)

    # ------------------------------------------------------------------
    # HPO
    # ------------------------------------------------------------------

    def update(self, trial) -> None:
        """Rebuild config from an Optuna trial's suggested period."""
        params = self.model_config.get_optuna_params(trial=trial)
        new_period = params.get("period", self.model_config.period)
        self.model_config = SEASONALNAIVEConfig(period=new_period, freq=self.model_config.freq)
        self._period_steps = None
