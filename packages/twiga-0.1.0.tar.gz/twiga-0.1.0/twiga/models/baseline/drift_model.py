"""Drift (random walk with drift) baseline model.

Extrapolates the linear trend observed within each input window:

    drift   = (y_t − y_{t−L+1}) / (L − 1)
    ŷ_{t+h} = y_t + h · drift   for h = 1, …, H

where L is the lookback window length, y_t is the last observed value,
and y_{t−L+1} is the first observed value.  This is the *random walk
with drift* model from classical time-series analysis, applied
per-window.

When L = 1 the drift is undefined; the model falls back to persistence
(ŷ_{t+h} = y_t for all h).

**Feature-column convention**: ``X[:, t, :num_targets]`` must contain
the raw observed target values at time step *t* within the lookback
window.  See :mod:`twiga.models.baseline.seasonal_naive_model` for a
full explanation of this convention.
"""

from __future__ import annotations

from typing import Literal

import numpy as np
from pydantic import Field

from twiga.core.config import BaseModelConfig, BaseSearchSpace
from twiga.models.ml.core.base_regressor import BaseRegressor


class DRIFTConfig(BaseModelConfig):
    """Configuration for the drift baseline model.

    Attributes:
        name: Fixed to ``"drift"``.
        domain: Fixed to ``"baseline"``.  Excluded from model params.
        search_space: Empty search space - drift has no tunable
            hyperparameters.
    """

    name: Literal["drift"] = Field(  # type: ignore[assignment]
        default="drift",
        description="Model identifier fixed to 'drift'.",
        alias="model_name",
        exclude=True,
    )
    domain: Literal["baseline"] = Field(  # type: ignore[assignment]
        default="baseline",
        description="Modelling domain identifier, fixed to 'baseline'.",
        exclude=True,
    )
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(),  # type: ignore[call-arg]
        description="Empty search space (drift has no hyperparameters).",
        exclude=True,
    )


class DRIFTModel(BaseRegressor):
    """Drift (random walk with drift) baseline for multi-horizon forecasting.

    Computes the per-window linear slope from the first to the last
    observed target value in the input context, then extrapolates it
    forward for all forecast horizon steps.

    This is equivalent to StatsForecast's ``RandomWalkWithDrift``,
    applied to each sliding window independently.

    Args:
        model_config: Configuration object.  Defaults to
            :class:`DRIFTConfig`.

    Example::

        model = DRIFTModel()
        model.fit(X_train, y_train)
        preds = model.predict(X_test)  # (B, L, H)
    """

    def __init__(self, model_config: DRIFTConfig | None = None) -> None:
        self.model_config = model_config or DRIFTConfig()
        self.num_targets: int | None = None
        self.horizon: int | None = None
        self.model = None  # no sklearn model

    @property
    def min_seq_len(self) -> int:
        """Minimum lookback window length for a meaningful drift estimate.

        Returns ``2`` - the model requires at least a first and a last
        observation to compute a slope.  L=1 is handled gracefully (slope
        falls back to zero / pure persistence), but ``min_seq_len`` reflects
        the minimum for non-degenerate behaviour.
        """
        return 2

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        eval_set: tuple[np.ndarray, np.ndarray] | None = None,
        verbose: bool = False,
    ) -> DRIFTModel:
        """Store target shape information.

        Args:
            X: Shape ``(B, L, F)``.
            y: Shape ``(B, L, H)``.
            eval_set: Accepted for API compatibility; silently ignored.
            verbose: Unused; included for interface consistency.

        Returns:
            Self for method chaining.

        Raises:
            ValueError: If ``X`` or ``y`` are not 3-dimensional.
        """
        if X.ndim != 3 or y.ndim != 3:
            raise ValueError("X and y must be 3-dimensional arrays.")
        _, self.horizon, self.num_targets = y.shape
        return self

    # ------------------------------------------------------------------
    # Predict
    # ------------------------------------------------------------------

    def predict(self, x: np.ndarray) -> np.ndarray:
        """Return drift predictions.

        For each sample b and target t:

        * ``last  = x[b, -1, t]``
        * ``first = x[b,  0, t]``
        * ``drift = (last − first) / max(L − 1, 1)``
        * ``pred[b, h, t] = last + (h + 1) · drift``

        Args:
            x: Shape ``(B, L, F)``.

        Returns:
            Predictions of shape ``(B, L_horizon, H)``.

        Raises:
            ValueError: If the model has not been fitted or x is not 3-D.
        """
        if self.num_targets is None:
            raise ValueError("Model has not been fitted yet.")
        if x.ndim != 3:
            raise ValueError("Input array x must be 3-dimensional.")

        batch_size, seq_len, _ = x.shape

        last = x[:, -1, : self.num_targets]  # (B, num_targets)
        first = x[:, 0, : self.num_targets]  # (B, num_targets)
        slope = (last - first) / max(seq_len - 1, 1)  # (B, num_targets)

        # steps: h+1 for h in 0..horizon-1  →  shape (horizon,)
        steps = np.arange(1, self.horizon + 1, dtype=float)  # type: ignore[arg-type]

        # Vectorised: (B, 1, T) + (1, H, 1) * (B, 1, T) → (B, H, T)
        return last[:, np.newaxis, :] + steps[np.newaxis, :, np.newaxis] * slope[:, np.newaxis, :]

    def forecast(self, x: np.ndarray) -> np.ndarray:
        """Return drift point forecast (raw array)."""
        return self.predict(x)

    # ------------------------------------------------------------------
    # HPO
    # ------------------------------------------------------------------

    def update(self, trial) -> None:
        """No-op: drift has no tunable hyperparameters."""
        self.model_config.get_optuna_params(trial=trial)  # keeps interface
