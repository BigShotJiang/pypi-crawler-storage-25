"""Neural network backbone architectures for Twiga."""

from twiga.models.nn.net.mlpf import MLPF, MLPFNetwork
from twiga.models.nn.net.mlpfgaf import MLPGAF, MLPGAFNetwork
from twiga.models.nn.net.mlpfgam import MLPGAM, MLPGAMNetwork
from twiga.models.nn.net.nhits import NHITS, NHITSNetwork

__all__ = [
    "MLPF",
    "MLPGAF",
    "MLPGAM",
    "NHITS",
    "MLPFNetwork",
    "MLPGAFNetwork",
    "MLPGAMNetwork",
    "NHITSNetwork",
]
