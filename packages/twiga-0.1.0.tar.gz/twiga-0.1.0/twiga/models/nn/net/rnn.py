"""RNN forecast network and Lightning model wrapper."""

from __future__ import annotations

from typing import Literal

import torch
from torch import nn

from twiga.core.data.processing import unstack_features
from twiga.models.nn.core.base_arch import BaseArchitecture
from twiga.models.nn.core.base_model import BaseNeuralModel


class RNNForecastNetwork(BaseArchitecture):
    """Recurrent neural network for time series point forecasting.

    Processes historical features through a multi-layer GRU or LSTM encoder,
    then projects the final hidden state to the forecast horizon.

    Args:
        num_target_feature (int): Number of target series to predict.
        num_historical_features (int): Number of historical (unknown time-varying) features.
        num_calendar_features (int): Number of known calendar features.
        num_exogenous_features (int): Number of known continuous exogenous features.
        num_future_covariates (int): Number of future-known covariates.
        forecast_horizon (int): Number of future time steps to forecast.
        lookback_window_size (int): Size of the historical input window.
        hidden_size (int, optional): Width of the RNN hidden state. Defaults to 128.
        n_layers (int, optional): Number of stacked RNN layers. Defaults to 2.
        cell_type (str, optional): RNN cell type, either ``"gru"`` or ``"lstm"``.
            Defaults to ``"gru"``.
        bidirectional (bool, optional): Whether to use a bidirectional RNN.
            Defaults to False.
        dropout (float, optional): Dropout probability applied between RNN layers
            (only active when ``n_layers > 1``). Defaults to 0.25.
        alpha (float, optional): MSE/MAE mixture weight for the loss. Defaults to 0.1.
        out_activation_function (str, optional): Final output activation.
            Defaults to ``"Identity"``.

    Examples:
        >>> net = RNNForecastNetwork(
        ...     num_target_feature=1,
        ...     num_historical_features=5,
        ...     num_calendar_features=2,
        ...     num_exogenous_features=3,
        ...     num_future_covariates=0,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ... )
        >>> x = torch.zeros(8, 96 + 24, net.num_past_features)
        >>> net(x).shape
        torch.Size([8, 24, 1])
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        hidden_size: int = 128,
        n_layers: int = 2,
        cell_type: Literal["gru", "lstm"] = "gru",
        bidirectional: bool = False,
        dropout: float = 0.25,
        alpha: float = 0.1,
        out_activation_function: str = "Identity",
    ):
        super().__init__(
            num_target_feature=num_target_feature,
            num_historical_features=num_historical_features,
            num_calendar_features=num_calendar_features,
            num_exogenous_features=num_exogenous_features,
            num_future_covariates=num_future_covariates,
            forecast_horizon=forecast_horizon,
            lookback_window_size=lookback_window_size,
            dropout=dropout,
            alpha=alpha,
            output_activation=out_activation_function,
        )

        self.hidden_size = hidden_size
        self.n_layers = n_layers
        self.cell_type = cell_type
        self.bidirectional = bidirectional

        rnn_cls = nn.GRU if cell_type == "gru" else nn.LSTM
        self.rnn = rnn_cls(
            input_size=self.num_past_features,
            hidden_size=hidden_size,
            num_layers=n_layers,
            batch_first=True,
            bidirectional=bidirectional,
            dropout=dropout if n_layers > 1 else 0.0,
        )

        num_directions = 2 if bidirectional else 1
        self._encode_size = hidden_size * num_directions

        self.norm = nn.LayerNorm(hidden_size * num_directions)
        self.projection = nn.Linear(hidden_size * num_directions, num_target_feature * forecast_horizon)

    def _init_hidden(self, x: torch.Tensor) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor]:
        """Initialise the RNN hidden state from the input tensor's device and dtype.

        Args:
            x: Input tensor of shape ``(B, T, F)`` — used for device and dtype only.

        Returns:
            Zero hidden state tensor for GRU, or ``(h0, c0)`` tuple for LSTM.
        """
        batch = x.size(0)
        num_directions = 2 if self.bidirectional else 1
        h0 = torch.zeros(num_directions * self.n_layers, batch, self.hidden_size, device=x.device, dtype=x.dtype)
        if self.cell_type == "lstm":
            c0 = torch.zeros_like(h0)
            return (h0, c0)
        return h0

    def _extract_last_hidden(self, hidden: torch.Tensor | tuple[torch.Tensor, torch.Tensor]) -> torch.Tensor:
        """Extract and reshape the final-layer hidden state.

        Args:
            hidden: RNN hidden output — tensor for GRU, ``(h_n, c_n)`` for LSTM.

        Returns:
            Tensor of shape ``(B, hidden_size * D)``.
        """
        h = hidden[0] if self.cell_type == "lstm" else hidden
        if self.bidirectional:
            return torch.cat([h[-2], h[-1]], dim=-1)
        return h[-1]

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        """Return the latent hidden-state vector for probabilistic heads.

        Args:
            x: Input tensor of shape ``(B, lookback + horizon, num_features)``.

        Returns:
            Latent tensor of shape ``(B, hidden_size * D)``.
        """
        past, _ = unstack_features(
            x,
            lookback_window_size=self.lookback_window_size,
            forecast_horizon=self.forecast_horizon,
            num_padding=self.num_past_features - self.num_covariate_features,
        )
        hidden = self._init_hidden(past)
        _, hidden = self.rnn(past, hidden)
        z = self._extract_last_hidden(hidden)
        return self.norm(z)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass: encode lookback window and project to forecast horizon.

        Args:
            x: Input tensor of shape ``(B, lookback + horizon, num_features)``.

        Returns:
            Forecast tensor of shape ``(B, forecast_horizon, num_target_feature)``.
        """
        z = self.encode(x)
        out = self.projection(self.dropout(z))
        out = out.reshape(x.size(0), self.forecast_horizon, self.num_target_feature)
        return self.output_activation(out)


class RNN(BaseNeuralModel):
    """PyTorch Lightning training wrapper for :class:`RNNForecastNetwork`.

    Attributes:
        n_out (int): Number of target series.
        n_channels (int): Total number of input channels.
        model (RNNForecastNetwork): Underlying forecast network.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        hidden_size: int = 128,
        n_layers: int = 2,
        cell_type: Literal["gru", "lstm"] = "gru",
        bidirectional: bool = False,
        dropout: float = 0.25,
        alpha: float = 0.1,
        out_activation_function: str = "Identity",
        metric: str = "mae",
        optimizer_params: dict | None = None,
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        """Initialise the RNN Lightning model.

        Args:
            num_target_feature (int): Number of target series to predict.
            num_historical_features (int): Number of historical features.
            num_calendar_features (int): Number of calendar features.
            num_exogenous_features (int): Number of exogenous features.
            num_future_covariates (int): Number of future covariates.
            forecast_horizon (int): Number of future time steps to forecast.
            lookback_window_size (int): Size of the historical input window.
            hidden_size (int, optional): RNN hidden state width. Defaults to 128.
            n_layers (int, optional): Number of stacked RNN layers. Defaults to 2.
            cell_type (str, optional): ``"gru"`` or ``"lstm"``. Defaults to ``"gru"``.
            bidirectional (bool, optional): Bidirectional RNN. Defaults to False.
            dropout (float, optional): Dropout probability. Defaults to 0.25.
            alpha (float, optional): MSE/MAE mixture weight. Defaults to 0.1.
            out_activation_function (str, optional): Output activation. Defaults to ``"Identity"``.
            metric (str, optional): Validation metric. Defaults to ``"mae"``.
            optimizer_params (dict, optional): Optimizer parameter overrides. Defaults to None.
            optimizer_type (str, optional): Optimizer class name. Defaults to None.
            lr_scheduler_type (str, optional): Scheduler class name. Defaults to None.
            scheduler_params (dict, optional): Scheduler parameter overrides. Defaults to None.
            max_epochs (int, optional): Maximum training epochs. Defaults to 10.
        """
        super().__init__(
            metric=metric,
            optimizer_type=optimizer_type,
            optimizer_params=optimizer_params,
            lr_scheduler_type=lr_scheduler_type,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )

        self.n_out = num_target_feature
        self.n_channels = (
            num_historical_features + num_calendar_features + num_exogenous_features + num_future_covariates
        )
        self.model = RNNForecastNetwork(
            num_target_feature=num_target_feature,
            num_historical_features=num_historical_features,
            num_calendar_features=num_calendar_features,
            num_exogenous_features=num_exogenous_features,
            num_future_covariates=num_future_covariates,
            forecast_horizon=forecast_horizon,
            lookback_window_size=lookback_window_size,
            hidden_size=hidden_size,
            n_layers=n_layers,
            cell_type=cell_type,
            bidirectional=bidirectional,
            dropout=dropout,
            alpha=alpha,
            out_activation_function=out_activation_function,
        )
