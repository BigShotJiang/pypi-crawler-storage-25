from __future__ import annotations

from collections.abc import Callable

import torch
from torch import nn
import torch.nn.functional as F

from twiga.core.data.processing import unstack_features
from twiga.models.nn.core.base_arch import BaseArchitecture
from twiga.models.nn.core.base_model import BaseNeuralModel
from twiga.models.nn.core.linear import SUPPORTED_ACTIVATIONS, MLPEncoder


class MLPGAMNetwork(BaseArchitecture):
    """MLPGAM Forecast Network for time series point forecasting.

    This model uses a multilayer perceptron architecture to forecast future values of a time series.
    Processes historical, calendar, exogenous features, and future covariates to
    forecast future values of the target series. Uses MLPEncoder for feature
    encoding, linear transformations for past and future features, and a Lasso penalty
    for regularization.

    Attributes:
        past_feature_transform (nn.Linear): Linear layer for past feature transformation.
        future_feature_transform (nn.Linear, optional): Linear layer for future feature
            transformation (if covariates are present).
        encoder (MLPEncoder): Encoder for past features.
        horizon (MLPEncoder, optional): Encoder for future covariates (if present).
        bias (nn.Parameter): Bias term for the output.
        activation (nn.Module): Activation function for hidden layers.
        lambda_lasso (float): Lasso penalty coefficient.

    Examples:
        How to use:
            >>> # Instantiate the network with required parameters
            >>> model = MLPGAMNetwork(
            ...     num_target_feature=1,
            ...     num_historical_features=10,
            ...     num_calendar_features=3,
            ...     num_exogenous_features=5,
            ...     num_future_covariates=4,
            ...     forecast_horizon=24,
            ...     lookback_window_size=96,
            ... )
            >>> # Forward pass with a sample input (assuming proper preprocessing)
            >>> output = model(sample_input)
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str = "ConvEmb",
        latent_size: int = 256,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        num_layers: int = 2,
        activation_function: str = "SiLU",
        out_activation_function: str = "Identity",
        dropout: float = 0.25,
        alpha: float = 0.1,
        lambda_lasso: float = 1e-6,
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = True,
        use_temporal_mixer: bool = False,
        patch_len: int | None = None,
        stride: int | None = None,
    ):
        """Initializes the MLPGAMNetwork.

        Args:
            num_target_feature: Number of target series. Must be positive.
            num_historical_features: Number of historical (unknown time-varying)
                features. Must be non-negative.
            num_calendar_features: Number of known calendar (categorical) features.
                Must be non-negative.
            num_exogenous_features: Number of known continuous (exogenous) features.
                Must be non-negative.
            num_future_covariates: Number of future covariates. Must be non-negative.
            forecast_horizon: Number of future time steps to forecast. Must be positive.
            lookback_window_size: Size of the lookback window. Must be positive.
            embedding_size: Dimensionality of the embedding space. Must be positive.
                Defaults to 28.
            embedding_type: Type of positional embedding ('PosEmb', 'RotaryEmb', or
                None). Defaults to None.
            value_embed_type: Type of value embedding ('ConvEmb', 'LinearEmb', or
                None). Defaults to 'ConvEmb'.
            latent_size: Latent output dimension of each encoder (feeds projection).
                Must be positive. Defaults to 256.
            hidden_dim: Width of hidden layers inside the encoder MLPs. Independent
                of latent_size. Defaults to 256.
            width_multiplier: Expansion factor for hidden layer widths across encoder
                depth. Defaults to 2.0.
            num_layers: Number of MLP layers. Must be positive. Defaults to 2.
            activation_function: Activation function for hidden layers. Must be one of
                {'SiLU', 'ReLU', 'Identity', 'Tanh', 'Sigmoid'}. Defaults to 'SiLU'.
            out_activation_function: Activation function for output layer. Must be one
                of {'SiLU', 'ReLU', 'Identity', 'Tanh', 'Sigmoid'}. Defaults to
                'Identity'.
            dropout: Dropout probability. Must be in [0, 1]. Defaults to 0.25.
            alpha: Weight for MSE vs. L1 loss. Must be in [0, 1]. Defaults to 0.1.
            lambda_lasso: Lasso penalty coefficient. Must be non-negative. Defaults to
                1e-6.
            use_norm: Whether to use LayerNorm in encoders. Defaults to True.
            use_bias: Whether to use bias terms in encoder layers. Defaults to True.
            use_residual: Whether to use residual connections in encoders. Defaults to
                True.
            use_temporal_mixer: Whether to include a temporal mixing layer before the
                encoder. Defaults to False.
            patch_len: Patch window length for PatchEmbedding. Required when
                value_embed_type='PatchEmb'. Defaults to None.
            stride: Stride between patches for PatchEmbedding. Required when
                value_embed_type='PatchEmb'. Defaults to None.

        Raises:
            ValueError: If any parameter is invalid (e.g., negative dimensions, invalid
                activation or embedding types).
        """
        super().__init__(
            num_target_feature=num_target_feature,
            num_historical_features=num_historical_features,
            num_calendar_features=num_calendar_features,
            num_exogenous_features=num_exogenous_features,
            num_future_covariates=num_future_covariates,
            forecast_horizon=forecast_horizon,
            lookback_window_size=lookback_window_size,
            dropout=dropout,
            alpha=alpha,
            output_activation=out_activation_function,
        )

        # Ensure valid activation and embedding types
        if activation_function not in SUPPORTED_ACTIVATIONS:
            raise ValueError(f"Invalid activation_function. Please select from: {SUPPORTED_ACTIVATIONS}")

        # if out_activation_function not in ACTIVATIONS:
        #    raise ValueError(f"Invalid out_activation_function. Please select from: {ACTIVATIONS}")
        self._encode_size = num_target_feature * forecast_horizon
        self.lambda_lasso = lambda_lasso
        self.activation = getattr(nn, activation_function)()

        self.bias = nn.Parameter(torch.zeros(num_target_feature * forecast_horizon))
        self.past_feature_transform = nn.Linear(latent_size, num_target_feature * forecast_horizon, bias=False)
        self.encoder = MLPEncoder(
            embedding_size=embedding_size,
            pos_embed_type=embedding_type,
            value_embed_type=value_embed_type,
            latent_size=latent_size,
            hidden_dim=hidden_dim,
            width_multiplier=width_multiplier,
            num_layers=num_layers,
            context_size=self.lookback_window_size,
            activation=self.activation,
            dropout=dropout,
            num_channels=self.num_past_features,
            use_norm=use_norm,
            use_bias=use_bias,
            use_residual=use_residual,
            use_temporal_mixer=use_temporal_mixer,
            patch_len=patch_len,
            stride=stride,
        )
        if self.num_covariate_features > 0:
            self.horizon = MLPEncoder(
                embedding_size=embedding_size,
                value_embed_type=value_embed_type,
                pos_embed_type=embedding_type,
                latent_size=latent_size,
                hidden_dim=hidden_dim,
                width_multiplier=width_multiplier,
                num_layers=num_layers,
                context_size=self.forecast_horizon,
                activation=self.activation,
                dropout=dropout,
                num_channels=self.num_covariate_features,
                use_norm=use_norm,
                use_bias=use_bias,
                use_residual=use_residual,
                use_temporal_mixer=use_temporal_mixer,
                patch_len=patch_len,
                stride=stride,
            )
            self.future_feature_transform = nn.Linear(latent_size, num_target_feature * forecast_horizon, bias=False)

    def fuse_projection(self, x: torch.Tensor) -> torch.Tensor:
        """Encode past and future features and project to forecast space.

        Splits the combined input into past and future blocks, encodes
        each independently, applies linear projections, and sums them
        together with a learnable bias.

        Args:
            x: Combined input tensor of shape
                ``(batch, lookback + horizon, total_features)``.

        Returns:
            Flat forecast tensor of shape
            ``(batch, num_target_feature * forecast_horizon)``.
        """
        past_feature, covariate_feature = unstack_features(
            x,  # type: ignore[arg-type]
            lookback_window_size=self.lookback_window_size,
            forecast_horizon=self.forecast_horizon,
            num_padding=self.num_past_features - self.num_covariate_features,
        )

        hist_feature_space = self.encoder(past_feature)
        hist_feature_space = self.past_feature_transform(hist_feature_space)

        if self.num_covariate_features > 0:
            future_feature_space = self.horizon(covariate_feature)
            future_feature_space = self.future_feature_transform(future_feature_space)
            feature_space = hist_feature_space + future_feature_space
        else:
            feature_space = hist_feature_space

        return feature_space + self.bias

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        """Return flat latent tensor ``(B, num_target * forecast_horizon)`` for distribution heads.

        Args:
            x: Input tensor of shape ``(B, lookback + horizon, num_features)``.

        Returns:
            Flat tensor of shape ``(B, num_target_feature * forecast_horizon)``.
        """
        return self.fuse_projection(x)

    def penalty_dict(self, epoch: int | None = None) -> dict[str, torch.Tensor]:
        """Return the Lasso penalty for feature-selection regularisation."""
        return {"lasso": self.lasso_penalty()}

    def forward(self, x):

        latent_space = self.fuse_projection(x)
        forecast = self.output_activation(latent_space)
        forecast = forecast.reshape(x.size(0), self.forecast_horizon, self.num_target_feature)

        return forecast

    def lasso_penalty(self):
        """Computes the Lasso penalty for the given layer.

        Args:
            lambda_lasso (float): The Lasso penalty coefficient.

        Returns:
            float: The computed Lasso penalty.
        """
        l1_norm = self.lambda_lasso * self.past_feature_transform.weight.abs().mean()
        if self.num_covariate_features > 0:
            l1_norm += self.lambda_lasso * self.future_feature_transform.weight.abs().mean()

        return l1_norm

    def step(
        self,
        batch: tuple[torch.Tensor, torch.Tensor],
        metric_fn: Callable,
        epoch: int | None = None,  # type: ignore[valid-type]
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Perform a single training/validation step.

        Computes the combined MSE + MAE loss, adds
        and evaluates the provided metric function.

        Args:
            batch: Tuple of (input features, target values)
                   - x: shape [batch_size, input_features]
                   - y: shape [batch_size, output_size] or [batch_size]
            metric_fn: Callable that takes predictions and targets and returns a scalar metric
                       (often used for logging/validation, e.g. MAE, RMSE, MAPE, etc.)
            epoch: Current training epoch number (passed to regularization scheduler).
                   If None, no epoch-dependent behavior is applied.

        Returns:
            Tuple containing:
                - loss: Total loss value (MSE/MAE combination)
                - metric: Value returned by metric_fn(pred, target)
        """
        x, y = batch

        loc = self(x)
        loss = self.alpha * F.mse_loss(loc, y) + (1 - self.alpha) * F.l1_loss(loc, y)
        metric = loss
        loss += self.lasso_penalty()

        return loss, metric


class MLPGAM(BaseNeuralModel):
    """MLP model for time series point forecasting.

    Wraps `MLPGAMNetwork` with training hyperparameters for forecasting future values
    of a time series. Configures the network architecture, loss functions, and optimizer
    settings for use with PyTorch Lightning.

    Attributes:
        model (MLPGAMNetwork): The underlying forecasting network.
        data_pipeline (sklearn.pipeline.Pipeline, optional): Data preprocessing pipeline.
        tra_metric_fcn (torchmetrics.Metric): Metric function for training.
        val_metric_fcn (torchmetrics.Metric): Metric function for validation.
        checkpoints_path (str): Directory path for saving checkpoints.
        hparams (dict): Hyperparameters saved during initialization.

    Notes:
        Inherits from `BaseNeuralModel`, which provides optimizer and scheduler
        configurations, training/validation steps, and checkpoint handling.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str | None = None,
        latent_size: int = 256,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        num_layers: int = 2,
        activation_function: str = "SiLU",
        out_activation_function: str = "Identity",
        dropout: float = 0.25,
        alpha: float = 0.1,
        lambda_lasso: float = 1e-6,
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = True,
        use_temporal_mixer: bool = False,
        patch_len: int | None = None,
        stride: int | None = None,
        metric: str = "mae",
        optimizer_params: dict | None = None,
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        """Initialize the MLPGAM model.

        Args:
            num_target_feature (int): Number of target series to predict. Must be
                positive.
            num_historical_features (int): Number of historical features. Must be
                non-negative.
            num_calendar_features (int): Number of calendar features. Must be
                non-negative.
            num_exogenous_features (int): Number of exogenous features. Must be
                non-negative.
            num_future_covariates (int): Number of future covariates. Must be
                non-negative.
            forecast_horizon (int): Number of time steps to forecast. Must be positive.
            lookback_window_size (int): Size of the input window. Must be positive.
            embedding_size (int, optional): Dimensionality of the embedding space.
                Defaults to 28.
            embedding_type (str, optional): Type of positional embedding ("PosEmb",
                "RotaryEmb", or None). Defaults to None.
            value_embed_type (str, optional): Type of value embedding ("ConvEmb",
                "LinearEmb", or None). Defaults to None.
            latent_size (int, optional): Latent output dimension of each encoder.
                Defaults to 256.
            hidden_dim (int, optional): Width of hidden layers inside the encoder MLPs.
                Defaults to 256.
            width_multiplier (float, optional): Expansion factor for hidden layer
                widths. Defaults to 2.0.
            num_layers (int, optional): Number of MLP layers. Defaults to 2.
            activation_function (str, optional): Activation function for hidden layers.
                Defaults to "SiLU".
            out_activation_function (str, optional): Activation function for output
                layer. Defaults to "Identity".
            dropout (float, optional): Dropout rate, between 0 and 1. Defaults to
                0.25.
            alpha (float, optional): Weight for MSE vs. L1 loss, between 0 and 1.
                Defaults to 0.1.
            lambda_lasso (float, optional): Lasso penalty coefficient, non-negative.
                Defaults to 1e-6.
            use_norm (bool, optional): Whether to use LayerNorm in encoders.
                Defaults to True.
            use_bias (bool, optional): Whether to use bias terms in encoder layers.
                Defaults to True.
            use_residual (bool, optional): Whether to use residual connections in
                encoders. Defaults to True.
            use_temporal_mixer (bool, optional): Whether to include a temporal mixing
                layer. Defaults to False.
            patch_len (int, optional): Patch window length for PatchEmbedding.
                Defaults to None.
            stride (int, optional): Stride between patches for PatchEmbedding.
                Defaults to None.
            metric (str, optional): Evaluation metric ("mae", "mse", "smape").
                Defaults to "mae".
            optimizer_params (dict, optional): Optimizer parameters. Defaults to None.
            optimizer_type (str, optional): Type of optimizer to use (e.g., "adam", "sgd"). Defaults to None.
            lr_scheduler_type (str, optional): Type of learning rate scheduler to use (e.g., "step", "cosine").
                Defaults to None.
            scheduler_params (dict, optional): Scheduler parameters. Defaults to None.
            max_epochs (int, optional): Maximum training epochs. Defaults to 10.

        Examples:
            Initialize an MLPGAM model for forecasting:
                >>> model = MLPGAM(
                ...     num_target_feature=1,
                ...     num_historical_features=10,
                ...     num_calendar_features=3,
                ...     num_exogenous_features=5,
                ...     num_future_covariates=2,
                ...     forecast_horizon=24,
                ...     lookback_window_size=96,
                ...     embedding_size=20,
                ...     metric="mae",
                ...     max_epochs=10,
                ... )

        Raises:
            ValueError: If parameters do not meet constraints (e.g., negative values,
                invalid metric).
        """
        super().__init__(
            metric=metric,
            optimizer_type=optimizer_type,
            optimizer_params=optimizer_params,
            lr_scheduler_type=lr_scheduler_type,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )

        self.model = MLPGAMNetwork(
            num_target_feature=num_target_feature,
            num_historical_features=num_historical_features,
            num_calendar_features=num_calendar_features,
            num_exogenous_features=num_exogenous_features,
            num_future_covariates=num_future_covariates,
            lookback_window_size=lookback_window_size,
            forecast_horizon=forecast_horizon,
            embedding_size=embedding_size,
            embedding_type=embedding_type,
            value_embed_type=value_embed_type,  # type: ignore[arg-type]
            latent_size=latent_size,
            hidden_dim=hidden_dim,
            width_multiplier=width_multiplier,
            num_layers=num_layers,
            activation_function=activation_function,
            out_activation_function=out_activation_function,
            dropout=dropout,
            alpha=alpha,
            lambda_lasso=lambda_lasso,
            use_norm=use_norm,
            use_bias=use_bias,
            use_residual=use_residual,
            use_temporal_mixer=use_temporal_mixer,
            patch_len=patch_len,
            stride=stride,
        )
