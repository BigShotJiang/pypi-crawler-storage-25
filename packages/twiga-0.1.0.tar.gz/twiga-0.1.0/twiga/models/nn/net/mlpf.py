from __future__ import annotations

import torch
from torch import nn

from twiga.core.data.processing import unstack_features
from twiga.models.nn.core.base_arch import BaseArchitecture
from twiga.models.nn.core.base_model import BaseNeuralModel
from twiga.models.nn.core.linear import SUPPORTED_ACTIVATIONS, MLPEncoder


class MLPFNetwork(BaseArchitecture):
    """Multilayer Perceptron (MLP) Forecast Network for time series forecasting.

    This model implements a multilayer perceptron architecture for forecasting time series data.
    It processes historical, calendar, exogenous features, and future covariates to forecast future
    values of the target series.

    Args:
        num_target_feature (int): Number of target series.
        num_historical_features (int): Number of historical (unknown time-varying) features.
        num_calendar_features (int): Number of known calendar (categorical) features.
        num_exogenous_features (int): Number of known continuous (exogenous) features.
        num_future_covariates (int): Number of future covariates.
        forecast_horizon (int): Number of future time steps to forecast.
        lookback_window_size (int): Size of the lookback (input) window.
        embedding_size (int, optional): Dimensionality of the embedding space. Defaults to 28.
        embedding_type (str, optional): Type of positional embedding to use. Options include
            'PosEmb', 'RotaryEmb', or None. Defaults to None.
        value_embed_type (str, optional): Type of value embedding to use. Options include
            'ConvEmb', 'LinearEmb', or None. Defaults to None.
        combination_type (str, optional): Method to combine features. Options include 'attn-comb',
            'weighted-comb', or 'addition-comb'. Defaults to "attn-comb".
        latent_size (int, optional): Latent output dimension of each encoder (feeds projection).
            Defaults to 256.
        hidden_dim (int, optional): Width of hidden layers inside the encoder MLPs. Independent
            of latent_size. Defaults to 256.
        width_multiplier (float, optional): Expansion factor for hidden layer widths across
            encoder depth. Defaults to 2.0.
        num_layers (int, optional): Number of layers in the MLP. Defaults to 2.
        activation_function (str, optional): Activation function for the hidden layers.
            Defaults to "SiLU".
        out_activation_function (str, optional): Activation function for the output layer.
            Defaults to "Identity".
        dropout (float, optional): Dropout probability for regularization. Defaults to 0.25.
        alpha (float, optional): Alpha parameter for the loss function. Defaults to 0.1.
        num_attention_heads (int, optional): Number of heads in the multi-head attention
            mechanism. Defaults to 4.
        use_norm (bool, optional): Whether to use LayerNorm in encoders. Defaults to True.
        use_bias (bool, optional): Whether to use bias terms in encoder layers. Defaults to True.
        use_residual (bool, optional): Whether to use residual connections in encoders.
            Defaults to False.
        use_temporal_mixer (bool, optional): Whether to include a temporal mixing layer before
            the MLP encoder. Defaults to False.
        patch_len (int, optional): Patch window length for PatchEmbedding. Required when
            value_embed_type='PatchEmb'. Defaults to None.
        stride (int, optional): Stride between patches for PatchEmbedding. Required when
            value_embed_type='PatchEmb'. Defaults to None.

    Raises:
        ValueError: If any of the parameter values are invalid (e.g., negative dimensions).

    Examples:
        How to use:
            >>> # Instantiate the network with required parameters
            >>> model = MLPFNetwork(
            ...     num_target_feature=1,
            ...     num_historical_features=10,
            ...     num_calendar_features=3,
            ...     num_exogenous_features=5,
            ...     num_future_covariates=4,
            ...     forecast_horizon=24,
            ...     lookback_window_size=96,
            ... )
            >>> # Forward pass with a sample input (assuming proper preprocessing)
            >>> output = model(sample_input)
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str | None = None,
        combination_type: str = "addition-comb",
        latent_size: int = 256,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        num_layers: int = 2,
        activation_function: str = "SiLU",
        out_activation_function: str = "Identity",
        dropout: float = 0.25,
        alpha: float = 0.1,
        num_attention_heads: int = 4,
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = False,
        use_temporal_mixer: bool = False,
        patch_len: int | None = None,
        stride: int | None = None,
    ):
        super().__init__(
            num_target_feature=num_target_feature,
            num_historical_features=num_historical_features,
            num_calendar_features=num_calendar_features,
            num_exogenous_features=num_exogenous_features,
            num_future_covariates=num_future_covariates,
            forecast_horizon=forecast_horizon,
            lookback_window_size=lookback_window_size,
            dropout=dropout,
            alpha=alpha,
            output_activation=out_activation_function,
        )

        # Ensure valid activation and embedding types
        if activation_function not in SUPPORTED_ACTIVATIONS:
            raise ValueError(f"Invalid activation_function. Please select from: {SUPPORTED_ACTIVATIONS}")

        activation_function = getattr(nn, activation_function)()
        self.encoder = MLPEncoder(
            embedding_size=embedding_size,
            pos_embed_type=embedding_type,
            value_embed_type=value_embed_type,
            latent_size=latent_size,
            hidden_dim=hidden_dim,
            width_multiplier=width_multiplier,
            num_layers=num_layers,
            context_size=self.lookback_window_size,
            activation=activation_function,
            dropout=dropout,
            num_channels=self.num_past_features,
            use_norm=use_norm,
            use_bias=use_bias,
            use_residual=use_residual,
            use_temporal_mixer=use_temporal_mixer,
            patch_len=patch_len,
            stride=stride,
        )

        if self.num_covariate_features > 0:
            self.horizon = MLPEncoder(
                embedding_size=embedding_size,
                value_embed_type=value_embed_type,
                pos_embed_type=embedding_type,
                latent_size=latent_size,
                hidden_dim=hidden_dim,
                width_multiplier=width_multiplier,
                num_layers=num_layers,
                context_size=self.forecast_horizon,
                activation=activation_function,
                dropout=dropout,
                num_channels=self.num_covariate_features,
                use_norm=use_norm,
                use_bias=use_bias,
                use_residual=use_residual,
                use_temporal_mixer=use_temporal_mixer,
                patch_len=patch_len,
                stride=stride,
            )
            self.future_feature_transform = nn.Linear(
                latent_size,
                self.num_target_feature * forecast_horizon,
                bias=False,
            )

        self._encode_size = latent_size
        self.alpha = alpha
        self.combination_type = combination_type

        if self.combination_type == "attn-comb":
            self.attention = nn.MultiheadAttention(
                embed_dim=latent_size,
                num_heads=num_attention_heads,
                batch_first=True,
            )
        if self.combination_type == "weighted-comb":
            self.gate = nn.Linear(latent_size * 2, latent_size)

        self.mu = nn.Linear(latent_size, self.num_target_feature * forecast_horizon)

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        """Return latent vector of shape ``(B, latent_size)`` for distribution heads.

        Args:
            x: Input tensor of shape ``(B, lookback + horizon, num_features)``.

        Returns:
            Latent tensor of shape ``(B, latent_size)``.
        """
        return self.fuse_projection(x)

    def fuse_projection(self, x: torch.Tensor) -> torch.Tensor:
        """Get combined projection MLPFNetwork.

        Args:
            x (torch.Tensor): Input tensor.

        Returns:
            torch.Tensor: Output tensor after processing through the network.
        """
        past_feature, covarite_feature = unstack_features(
            x,  # type: ignore[arg-type]
            lookback_window_size=self.lookback_window_size,
            forecast_horizon=self.forecast_horizon,
            num_padding=self.num_past_features - self.num_covariate_features,
        )

        f = self.encoder(past_feature)

        if self.num_covariate_features > 0:
            h = self.horizon(covarite_feature)
            if self.combination_type == "attn-comb":
                z = self.attention(h.unsqueeze(0), f.unsqueeze(0), f.unsqueeze(0))[0].squeeze(0)
            elif self.combination_type == "weighted-comb":
                gate = self.gate(torch.cat((h, f), -1)).sigmoid()
                z = (1 - gate) * f + gate * h
            else:
                z = h + f
        else:
            z = f

        return z

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass of the MLPFNetwork.

        Args:
            x (torch.Tensor): Input tensor.

        Returns:
            torch.Tensor: Output tensor after processing through the network.
        """
        z = self.fuse_projection(x)
        loc = self.mu(z)
        loc = loc.reshape(z.size(0), self.forecast_horizon, self.num_target_feature)
        loc = self.output_activation(loc)

        return loc


class MLPF(BaseNeuralModel):
    """MLP model for time series point forecasting.

    Uses a multilayer perceptron (MLP) architecture to forecast future values of a time
    series. Configures the network architecture, input feature dimensions, and training
    hyperparameters for use with PyTorch Lightning.

    Attributes:
        n_out (int): Number of target series to forecast.
        n_channels (int): Total number of input channels (sum of historical, calendar,
            exogenous, and future covariate features).
        model (MLPFNetwork): The underlying forecasting network.
        data_pipeline (sklearn.pipeline.Pipeline, optional): Data preprocessing pipeline.
        tra_metric_fcn (torchmetrics.Metric): Metric function for training.
        val_metric_fcn (torchmetrics.Metric): Metric function for validation.
        checkpoints_path (str): Directory path for saving checkpoints.
        hparams (dict): Hyperparameters saved during initialization.

    Notes:
        Inherits from `BaseNeuralModel`, which provides optimizer and scheduler
        configurations, training/validation steps, and checkpoint handling.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str | None = None,
        combination_type: str = "addition-comb",
        latent_size: int = 128,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        num_layers: int = 2,
        activation_function: str = "SiLU",
        out_activation_function: str = "Identity",
        dropout: float = 0.25,
        alpha: float = 0.1,
        num_attention_heads: int = 4,
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = False,
        use_temporal_mixer: bool = False,
        patch_len: int | None = None,
        stride: int | None = None,
        metric: str = "mae",
        optimizer_params: dict | None = None,
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        """Initialize the MLPFModel.

        Args:
            num_target_feature (int): Number of target series to predict. Must be positive.
            num_historical_features (int): Number of historical features. Must be non-negative.
            num_calendar_features (int): Number of calendar features. Must be non-negative.
            num_exogenous_features (int): Number of exogenous features. Must be non-negative.
            num_future_covariates (int): Number of future covariates. Must be non-negative.
            forecast_horizon (int): Number of time steps to forecast. Must be positive.
            lookback_window_size (int): Size of the input window. Must be positive.
            embedding_size (int, optional): Dimensionality of the embedding space.
                Defaults to 28.
            embedding_type (str, optional): Type of positional embedding ("PosEmb",
                "RotaryEmb", or None). Defaults to None.
            value_embed_type (str, optional): Type of value embedding ("ConvEmb",
                "LinearEmb", or None). Defaults to None.
            combination_type (str, optional): Method to combine encoded features
                ("attn-comb", "weighted-comb", "addition-comb"). Defaults to "attn-comb".
            latent_size (int, optional): Latent output dimension of each encoder.
                Defaults to 128.
            hidden_dim (int, optional): Width of hidden layers inside the encoder MLPs.
                Defaults to 256.
            width_multiplier (float, optional): Expansion factor for hidden layer widths.
                Defaults to 2.0.
            num_layers (int, optional): Number of MLP layers. Defaults to 2.
            activation_function (str, optional): Activation function for hidden layers.
                Defaults to "SiLU".
            out_activation_function (str, optional): Activation function for output
                layer. Defaults to "Identity".
            dropout (float, optional): Dropout rate, between 0 and 1. Defaults to 0.25.
            alpha (float, optional): Weight for MSE vs. L1 loss, between 0 and 1.
                Defaults to 0.1.
            num_attention_heads (int, optional): Number of attention heads. Defaults to 4.
            use_norm (bool, optional): Whether to use LayerNorm in encoders. Defaults to True.
            use_bias (bool, optional): Whether to use bias terms in encoder layers.
                Defaults to True.
            use_residual (bool, optional): Whether to use residual connections in encoders.
                Defaults to False.
            use_temporal_mixer (bool, optional): Whether to include a temporal mixing layer.
                Defaults to False.
            patch_len (int, optional): Patch window length for PatchEmbedding. Defaults to None.
            stride (int, optional): Stride between patches for PatchEmbedding. Defaults to None.
            metric (str, optional): Evaluation metric ("mae", "mse", "smape"). Defaults to "mae".
            optimizer_params (dict, optional): Optimizer parameters. Defaults to None.
            optimizer_type (str, optional): Type of optimizer to use. Defaults to None.
            lr_scheduler_type (str, optional): Type of learning rate scheduler to use. Defaults to None.
            scheduler_params (dict, optional): Scheduler parameters. Defaults to None.
            max_epochs (int, optional): Maximum training epochs. Defaults to 10.

        Examples:
            Initialize an MLPFModel for forecasting:
                >>> model = MLPFModel(
                ...     num_target_feature=1,
                ...     num_historical_features=10,
                ...     num_calendar_features=3,
                ...     num_exogenous_features=5,
                ...     num_future_covariates=2,
                ...     forecast_horizon=24,
                ...     lookback_window_size=96,
                ...     embedding_size=20,
                ...     combination_type="attn-comb",
                ...     metric="mae",
                ...     max_epochs=10,
                ... )

        Raises:
            ValueError: If parameters do not meet constraints (e.g., negative values,
                invalid metric).
        """
        super().__init__(
            metric=metric,
            optimizer_type=optimizer_type,
            optimizer_params=optimizer_params,
            lr_scheduler_type=lr_scheduler_type,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )

        self.n_out = num_target_feature
        self.n_channels = (
            num_historical_features + num_calendar_features + num_exogenous_features + num_future_covariates
        )
        self.model = MLPFNetwork(
            num_target_feature=num_target_feature,
            num_historical_features=num_historical_features,
            num_calendar_features=num_calendar_features,
            num_exogenous_features=num_exogenous_features,
            num_future_covariates=num_future_covariates,
            lookback_window_size=lookback_window_size,
            forecast_horizon=forecast_horizon,
            embedding_size=embedding_size,
            embedding_type=embedding_type,
            value_embed_type=value_embed_type,
            combination_type=combination_type,
            latent_size=latent_size,
            hidden_dim=hidden_dim,
            width_multiplier=width_multiplier,
            num_layers=num_layers,
            activation_function=activation_function,
            out_activation_function=out_activation_function,
            dropout=dropout,
            alpha=alpha,
            num_attention_heads=num_attention_heads,
            use_norm=use_norm,
            use_bias=use_bias,
            use_residual=use_residual,
            use_temporal_mixer=use_temporal_mixer,
            patch_len=patch_len,
            stride=stride,
        )
