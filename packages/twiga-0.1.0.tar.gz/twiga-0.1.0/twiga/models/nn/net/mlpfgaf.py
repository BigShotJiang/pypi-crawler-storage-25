"""MLPGAF: Multi-Layer Perceptron with Gated Additive Features for Time Series.

This module implements MLPGAFNetwork, a neural forecasting model that combines
gated feature selection with past/future encoders for time series forecasting.

The key innovation is the learned feature gating mechanism that automatically learns
which features are important for each feature group, enabling interpretable feature
selection and sparsity through L1 regularization.

Classes:
    MLPGAFNetwork: Core forecasting network with gated feature selection.
    MLPGAF: PyTorch Lightning wrapper for training and evaluation.

Example:
    >>> model = MLPGAFNetwork(
    ...     num_target_feature=1,
    ...     num_historical_features=10,
    ...     num_calendar_features=3,
    ...     num_exogenous_features=5,
    ...     num_future_covariates=4,
    ...     forecast_horizon=24,
    ...     lookback_window_size=96,
    ... )
    >>> output = model(input_tensor)
"""

from __future__ import annotations

from collections.abc import Callable
from functools import partial

import torch
from torch import nn
import torch.nn.functional as F

from twiga.core.data.processing import define_feature_groups, split_features_by_group
from twiga.models.nn.core.base_arch import BaseArchitecture
from twiga.models.nn.core.base_model import BaseNeuralModel
from twiga.models.nn.core.linear import SUPPORTED_ACTIVATIONS

from .ganf.gates import compute_active_gate
from .ganf.groups import build_group_modules
from .ganf.losses import compute_gate_penalty, compute_weight_penalty


class MLPGAFNetwork(BaseArchitecture):
    """MLPGAF Forecast Network for time series point forecasting with gating.

    This model uses a multilayer perceptron architecture with learned feature
    gating to forecast future values of a time series. It processes historical,
    calendar, exogenous features, and future covariates through group-wise
    encoders and applies adaptive L1 regularization on feature gates for
    interpretable feature selection.

    Architecture Overview:
        1. Feature Groups: Splits input into semantic groups (target, historical,
           calendar, exogenous, future covariates)
        2. Group Encoders: Each group has independent MLPEncoder modules
        3. Feature Gating: Learned sigmoid/tanh gates control which features are active
        4. Additive Fusion: Group contributions are summed to produce forecast

    Attributes:
        lambda_gate (float): Regularization coefficient for gate sparsity penalty.
        warmup_epochs (int): Number of epochs for Lasso penalty warmup.
        gate_scale (float): Temperature scaling for gates.
        bias (nn.Parameter): Learnable bias term, shape (num_target * horizon,).
        groups (list[dict]): Feature group metadata from define_feature_groups.
        group_modules (nn.ModuleList): Encoder and projection layers per group.

    Example:
        >>> model = MLPGAFNetwork(
        ...     num_target_feature=1,
        ...     num_historical_features=10,
        ...     num_calendar_features=3,
        ...     num_exogenous_features=5,
        ...     num_future_covariates=4,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ... )
        >>> x = torch.randn(32, 1056)  # batch_size=32, features=1056
        >>> forecast = model(x)  # [32, 24, 1]
        >>> forecast, components = model(x, return_components=True)
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str = "ConvEmb",
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = True,
        use_revin: bool = True,
        use_temporal_mixer: bool = False,
        num_layers: int = 2,
        latent_size: int = 128,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        patch_len: int | None = None,
        stride: int | None = None,
        activation_function: str = "SiLU",
        out_activation_function: str = "Identity",
        dropout: float = 0.25,
        alpha: float = 0.1,
        lambda_weight: float = 1e-6,
        lambda_gate: float = 1e-2,
        delta: float = 1e-2,
        gate_scale: float = 5.0,
        gate_type: str = "sigmoid",
        warmup_epochs: int = 10,
    ):
        """Initializes the MLPGAFNetwork with configurable architecture.

        Args:
            num_target_feature (int): Number of target series to forecast. Must be
                positive. Example: 1 for univariate forecasting, >1 for multivariate.
            num_historical_features (int): Number of historical (unknown time-varying)
                features. Must be non-negative. These are included in past encoder.
            num_calendar_features (int): Number of known calendar features (day-of-week,
                month, etc.). Must be non-negative. Enables modeling seasonal patterns.
            num_exogenous_features (int): Number of known continuous (exogenous) features
                that vary over time. Must be non-negative. Example: external regressors.
            num_future_covariates (int): Number of future-known covariate features that
                span the forecast horizon. Must be non-negative. Example: holidays.
            forecast_horizon (int): Number of future time steps to forecast. Must be
                positive. Example: 24 for daily data means 24-hour ahead forecast.
            lookback_window_size (int): Size of the input/context window in time steps.
                Must be positive. Example: 96 for 4-day history in hourly data.
            embedding_size (int): Dimensionality of embeddings (if using positional
                embeddings). Must be positive. Defaults to 28.
            embedding_type (str, optional): Type of positional embedding to use.
                Options: ``'PosEmb'`` (absolute), ``'RotaryEmb'`` (rotary), ``None``.
                Defaults to None.
            value_embed_type (str): Type of value embedding for features. Options:
                ``'ConvEmb'`` (1D convolution), ``'LinearEmb'`` (linear), ``None``.
                Defaults to ``'ConvEmb'``.
            latent_size (int): Latent output dimension of each encoder (feeds
                projection). Must be positive. Defaults to 256.
            hidden_dim (int): Width of hidden layers inside the encoder MLPs. Must be
                positive. Defaults to 256. Independent of latent_size.
            width_multiplier (float): Expansion factor for hidden layer widths across
                encoder depth. Must be positive. Defaults to 2.0.
            num_layers (int): Number of MLP layers in encoders. Must be positive.
                Defaults to 2.
            activation_function (str): Activation function for hidden layers. Must be in
                SUPPORTED_ACTIVATIONS. Defaults to ``'SiLU'``.
            out_activation_function (str): Activation function for output layer. Must be
                in SUPPORTED_ACTIVATIONS. Defaults to ``'Identity'``.
            dropout (float): Dropout probability for regularization during training.
                Must be in [0, 1]. Defaults to 0.25.
            alpha (float): Weight for MSE vs. L1 loss in combined loss. Must be in [0, 1].
                Defaults to 0.1. ``alpha=0`` → pure L1, ``alpha=1`` → pure MSE.
            lambda_gate (float): Regularization coefficient for gate sparsity penalty.
                Must be non-negative. Defaults to 1e-2.
            lambda_weight (float): Regularization coefficient for feature weight L1
                penalty. Must be non-negative. Defaults to 1e-6.
            delta (float): Small constant for numerical stability. Defaults to 1e-2.
            gate_scale (float): Temperature scaling for gates. Must be positive.
                Defaults to 5.0.
            gate_type (str): Type of gating mechanism. Options: ``'sigmoid'``,
                ``'tanh'``. Defaults to ``'sigmoid'``.
            warmup_epochs (int): Number of epochs before full penalty strength.
                Defaults to 10.
            use_norm (bool): Whether to use LayerNorm in encoders. Defaults to True.
            use_bias (bool): Whether to use bias terms in encoder layers. Defaults to True.
            use_residual (bool): Whether to use residual connections in encoders.
                Defaults to True.
            use_revin (bool): Whether to apply reversible instance normalisation before
                encoding. Defaults to True. Helps with non-stationary time series.
            use_temporal_mixer (bool): Whether to include a temporal mixing layer before
                the MLP encoder. Defaults to False.
            patch_len (int | None): Patch window length for PatchEmbedding. Required when
                value_embed_type='PatchEmb'. Defaults to None.
            stride (int | None): Stride between patches for PatchEmbedding. Required when
                value_embed_type='PatchEmb'. Defaults to None.

        Raises:
            ValueError: If ``activation_function`` is not in SUPPORTED_ACTIVATIONS.
            ValueError: If ``gate_type`` is not ``'sigmoid'`` or ``'tanh'``.
        """
        super().__init__(
            num_target_feature=num_target_feature,
            num_historical_features=num_historical_features,
            num_calendar_features=num_calendar_features,
            num_exogenous_features=num_exogenous_features,
            num_future_covariates=num_future_covariates,
            forecast_horizon=forecast_horizon,
            lookback_window_size=lookback_window_size,
            dropout=dropout,
            alpha=alpha,
            output_activation=out_activation_function,
        )

        if activation_function not in SUPPORTED_ACTIVATIONS:
            raise ValueError(
                f"Invalid activation_function='{activation_function}'. Please select from: {SUPPORTED_ACTIVATIONS}",
            )

        self._encode_size = num_target_feature * forecast_horizon
        self.lambda_weight = lambda_weight
        self.warmup_epochs = warmup_epochs
        self.lambda_gate = lambda_gate
        self.delta = delta
        self.gate_scale = gate_scale
        self.gate_compute_fn = partial(compute_active_gate, gate_type=gate_type, gate_scale=gate_scale)

        activation_cls: type[nn.Module] = getattr(nn, activation_function)

        self.bias = nn.Parameter(torch.zeros(num_target_feature * forecast_horizon))
        self.groups = define_feature_groups(
            num_target=num_target_feature,
            num_hist=num_historical_features,
            num_cal=num_calendar_features,
            num_exo=num_exogenous_features,
            num_fut_cov=num_future_covariates,
            past_len=lookback_window_size,
            future_len=forecast_horizon,
        )
        self.group_modules = build_group_modules(
            groups=self.groups,
            forecast_horizon=forecast_horizon,
            lookback_window_size=lookback_window_size,
            activation=activation_cls,
            gate_scale=gate_scale,
            embedding_size=embedding_size,
            value_embed_type=value_embed_type,
            embedding_type=embedding_type,
            latent_size=latent_size,
            hidden_dim=hidden_dim,
            width_multiplier=width_multiplier,
            num_layers=num_layers,
            num_target_feature=num_target_feature,
            dropout=dropout,
            use_bias=use_bias,
            use_norm=use_norm,
            use_residual=use_residual,
            use_revin=use_revin,
            use_temporal_mixer=use_temporal_mixer,
            patch_len=patch_len,
            stride=stride,
        )

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        """Return flat latent tensor ``(B, num_target * forecast_horizon)`` for distribution heads.

        Args:
            x: Input tensor of shape ``(B, lookback + horizon, num_features)``.

        Returns:
            Flat tensor of shape ``(B, num_target_feature * forecast_horizon)``.
        """
        return self.fuse_projection(x)  # type: ignore[return-value]

    def penalty_dict(self, epoch: int | None = None) -> dict[str, torch.Tensor]:
        """Return gate and weight penalties for feature-selection regularisation."""
        return {
            "gate_penalty": compute_gate_penalty(
                self.group_modules,
                self.gate_compute_fn,
                lambda_gate=self.lambda_gate,
                delta=self.delta,
                epoch=epoch,
                warmup_epochs=self.warmup_epochs,
            ),
            "weight_penalty": compute_weight_penalty(
                self.group_modules,
                lambda_weight=self.lambda_weight,
            ),
        }

    def fuse_projection(
        self,
        x: torch.Tensor,
        return_components: bool = False,
    ) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
        """Compute pre-activation latent representation and per-group contributions.

        Splits the input into feature groups, applies learned gates, runs each group
        through its encoder and projection, then sums contributions and adds the
        learnable bias.

        Args:
            x (torch.Tensor): Input tensor of shape ``[B, total_input_dim]``.
            return_components (bool): weather to return components or not

        Returns:
            tuple[torch.Tensor, dict[str, torch.Tensor]]:
                - ``latent_space``: Summed contributions plus bias,
                  shape ``[B, num_target * forecast_horizon]``.
                - ``components``: Per-branch tensors keyed by
                  ``"{group_name}_past"`` / ``"{group_name}_fut"``,
                  each of shape ``[B, num_target * forecast_horizon]``.
        """
        past_groups, future_groups = split_features_by_group(
            x=x,
            lookback_window_size=self.lookback_window_size,
            forecast_horizon=self.forecast_horizon,
            groups=self.groups,
            num_past_features=self.num_past_features,
            num_covariate_features=self.num_covariate_features,
        )

        components = {}
        group_contribution = torch.zeros(
            (x.size(0), self.num_target_feature * self.forecast_horizon),
            device=x.device,
        )

        for i, branch in enumerate(self.group_modules):
            branch_name = self.groups[i]["name"]
            if hasattr(branch, "past_enc"):
                active_gate = self.gate_compute_fn(branch.past_feature_gate)  # type: ignore[arg-type]
                gated_past = past_groups[i] * active_gate + branch.past_gate_bias
                branch_emb = branch.past_enc(gated_past)  # type: ignore[operator]
                branch_contrib = branch.past_proj(branch_emb)  # type: ignore[operator]
                components[f"{branch_name}_past"] = branch_contrib
                group_contribution += branch_contrib
            if hasattr(branch, "fut_enc"):
                active_gate = self.gate_compute_fn(branch.fut_feature_gate)  # type: ignore[arg-type]
                gated_fut = future_groups[i] * active_gate + branch.fut_gate_bias
                branch_emb = branch.fut_enc(gated_fut)  # type: ignore[operator]
                branch_contrib = branch.fut_proj(branch_emb)  # type: ignore[operator]
                components[f"{branch_name}_fut"] = branch_contrib
                group_contribution += branch_contrib

        latent_space = group_contribution + self.bias
        if return_components:
            return latent_space, components
        return latent_space  # type: ignore[return-value]

    def forward(  # type: ignore[override]
        self,
        x: torch.Tensor,
        return_components: bool = False,
    ) -> torch.Tensor | tuple[torch.Tensor, dict[str, torch.Tensor]]:
        """Forward pass: compute multi-horizon point forecast.

        Args:
            x (torch.Tensor): Input features of shape ``[B, total_input_dim]``.
            return_components (bool): If ``True``, also return the per-group
                contribution dict. Defaults to ``False``.

        Returns:
            forecast (torch.Tensor): Shape ``[B, horizon, num_target]``.
            (forecast, components) if ``return_components=True``.
        """
        latent_space = self.fuse_projection(x, return_components)
        if return_components:
            latent_space, components = latent_space  # type: ignore[assignment,misc]
        forecast = self.output_activation(latent_space)
        forecast = forecast.reshape(x.size(0), self.forecast_horizon, self.num_target_feature)

        if return_components:
            return forecast, components
        return forecast

    def forecast(self, x: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        """Run inference and return the point forecast.

        Args:
            x (torch.Tensor): Input tensor of shape ``(B, total_input_dim)``.

        Returns:
            torch.Tensor: Forecast of shape ``(B, forecast_horizon, num_target)``.
        """
        with torch.no_grad():
            return self(x)

    def step(  # type: ignore[override]
        self,
        batch: tuple[torch.Tensor, torch.Tensor],
        metric_fn: Callable,
        epoch: int | None = None,
    ) -> tuple[dict[str, torch.Tensor], torch.Tensor]:
        """Perform single training/validation step with multi-objective loss.

        Args:
            batch (tuple[torch.Tensor, torch.Tensor]): ``(x, y)`` mini-batch.
            metric_fn (callable): Metric function (e.g. MAE, MSE).
            epoch (int | None): Current epoch for warmup scheduling.

        Returns:
            tuple[dict[str, torch.Tensor], torch.Tensor]:
                - ``loss_dict``: keys ``"loss"``, ``"loss_loc"``,
                  ``"weight_penalty"``, ``"gate_penalty"``.
                - ``total_loss``: scalar tensor for ``.backward()``.
        """
        x, y = batch
        loc = self(x)

        loss_loc = self.alpha * F.mse_loss(loc, y) + (1 - self.alpha) * F.l1_loss(loc, y)
        gate_penalty_loss = compute_gate_penalty(
            self.group_modules,
            self.gate_compute_fn,
            self.lambda_gate,
            self.warmup_epochs,
            self.delta,
            epoch=epoch,
        )
        group_lasso_loss = compute_weight_penalty(
            self.group_modules,
            self.lambda_weight,
            self.warmup_epochs,
            epoch=epoch,
        )

        total_loss = loss_loc + gate_penalty_loss + group_lasso_loss
        loss = {
            "loss": total_loss,
            "loss_loc": loss_loc,
            "weight_penalty": group_lasso_loss,
            "gate_penalty": gate_penalty_loss,
        }
        return loss, total_loss


class MLPGAF(BaseNeuralModel):
    """PyTorch Lightning module wrapping MLPGAFNetwork for time series forecasting.

    Integrates the MLPGAFNetwork architecture with training logic, loss computation,
    optimization, learning rate scheduling, and logging - all via PyTorch Lightning.

    This class handles:

    - Instantiation of the core model (`MLPGAFNetwork`)
    - Forward pass delegation
    - Training/validation/test step logic (inherited from base)
    - Hyperparameter-aware configuration for HPO compatibility

    Most architectural and regularization choices mirror those in :class:`MLPFConfig`,
    with additional gated mechanisms (lambda_gate, delta, gate_scale, gate_type).

    Example:
        >>> model = MLPGAF(
        ...     num_target_feature=1,
        ...     num_historical_features=12,
        ...     num_calendar_features=4,
        ...     num_exogenous_features=0,
        ...     num_future_covariates=6,
        ...     forecast_horizon=48,
        ...     lookback_window_size=168,
        ...     latent_size=192,
        ...     num_layers=3,
        ...     lambda_gate=5e-3,
        ...     metric="mae",
        ...     max_epochs=80,
        ... )
        >>> trainer = pl.Trainer(max_epochs=80, accelerator="gpu", devices=1)
        >>> trainer.fit(model, train_dataloaders=train_loader, val_dataloaders=val_loader)
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str | None = None,
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = True,
        use_revin: bool = True,
        use_temporal_mixer: bool = False,
        num_layers: int = 2,
        latent_size: int = 128,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        patch_len: int | None = None,
        stride: int | None = None,
        activation_function: str = "SiLU",
        out_activation_function: str = "Identity",
        dropout: float = 0.25,
        alpha: float = 0.1,
        lambda_weight: float = 1e-6,
        lambda_gate: float = 1e-2,
        delta: float = 1e-2,
        gate_scale: float = 5.0,
        gate_type: str = "sigmoid",
        warmup_epochs: int = 10,
        metric: str = "mae",
        optimizer_params: dict | None = None,
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        """Initialize the MLPGAF Lightning module.

        Args:
            num_target_feature: Number of variables to forecast.
            num_historical_features: Count of past observed covariates.
            num_calendar_features: Count of known calendar features.
            num_exogenous_features: Count of known static/slow-varying features.
            num_future_covariates: Count of future-known covariates.
            forecast_horizon: Number of steps to predict.
            lookback_window_size: Length of input historical sequence.

            embedding_size: Dimension of embeddings.
            embedding_type: Positional encoding variant (None = disabled).
            value_embed_type: Input value projection method (None = disabled).

            use_norm: Apply LayerNorm inside MLP blocks.
            use_bias: Include bias in linear layers.
            use_residual: Use residual connections in MLP blocks.
            use_revin: Apply RevIN (reversible instance normalization).
            use_temporal_mixer: Add temporal mixing layer before encoder.

            num_layers: Number of MLP blocks per encoder.
            latent_size: Dimension of encoded representation.
            hidden_dim: Base hidden dimension in MLP layers.
            width_multiplier: Expansion factor in feed-forward blocks.

            patch_len: Patch length for patching-based embedding.
            stride: Stride between patches.

            activation_function: Hidden-layer activation.
            out_activation_function: Output-layer activation.

            dropout: Dropout probability.
            alpha: Weight for MSE/MAE hybrid loss (0 = MAE only).

            lambda_weight: L2 regularization strength on weights.
            lambda_gate: Regularization strength on gating mechanism.
            delta: Small constant for numerical stability in gating.
            gate_scale: Scaling factor applied to gate logits.
            gate_type: Gating function ("sigmoid", "softplus", etc.).

            warmup_epochs: Number of warmup epochs for scheduler.
            metric: Primary validation metric ("mae", "mse", "rmse", ...).
            optimizer_params: Additional kwargs for optimizer.
            optimizer_type: Optimizer name (overrides base default if set).
            lr_scheduler_type: Scheduler name.
            scheduler_params: Additional scheduler kwargs.
            max_epochs: Maximum training epochs (used for scheduling).
        """
        super().__init__(
            metric=metric,
            optimizer_type=optimizer_type,
            optimizer_params=optimizer_params,
            lr_scheduler_type=lr_scheduler_type,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )

        self.model = MLPGAFNetwork(
            num_target_feature=num_target_feature,
            num_historical_features=num_historical_features,
            num_calendar_features=num_calendar_features,
            num_exogenous_features=num_exogenous_features,
            num_future_covariates=num_future_covariates,
            lookback_window_size=lookback_window_size,
            forecast_horizon=forecast_horizon,
            embedding_size=embedding_size,
            embedding_type=embedding_type,
            value_embed_type=value_embed_type,  # type: ignore[arg-type]
            use_norm=use_norm,
            use_bias=use_bias,
            use_residual=use_residual,
            use_revin=use_revin,
            use_temporal_mixer=use_temporal_mixer,
            latent_size=latent_size,
            hidden_dim=hidden_dim,
            width_multiplier=width_multiplier,
            patch_len=patch_len,
            stride=stride,
            num_layers=num_layers,
            activation_function=activation_function,
            out_activation_function=out_activation_function,
            dropout=dropout,
            alpha=alpha,
            lambda_weight=lambda_weight,
            lambda_gate=lambda_gate,
            delta=delta,
            gate_scale=gate_scale,
            gate_type=gate_type,
            warmup_epochs=warmup_epochs,
        )
