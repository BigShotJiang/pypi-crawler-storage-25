from __future__ import annotations

import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

from twiga.core.data.processing import unstack_features
from twiga.models.nn.core.base_arch import BaseArchitecture
from twiga.models.nn.core.base_model import BaseNeuralModel
from twiga.models.nn.core.linear import SUPPORTED_ACTIVATIONS

ACTIVATIONS = SUPPORTED_ACTIVATIONS
POOLING = ["MaxPool1d", "AvgPool1d"]


class CubicInterpolationError(Exception):
    """Custom exception for cubic interpolation errors."""


class _IdentityBasis(nn.Module):
    """Identity basis module using interpolation for NHITS model.

    Provides backcast and forecast projections through temporal interpolation.

    Args:
        backcast_size (int): Size of the backcast window.
        forecast_size (int): Size of the forecast horizon.
        interpolation_mode (str): Interpolation mode. One of 'linear', 'nearest',
            or a string containing 'cubic' for bicubic interpolation.
        out_features (int): Number of output features. Defaults to 1.

    Raises:
        ValueError: For invalid interpolation modes or cubic with multiple outputs.
    """

    def __init__(
        self,
        backcast_size: int,
        forecast_size: int,
        interpolation_mode: str,
        out_features: int = 1,
    ):
        super().__init__()
        valid_modes = ("linear", "nearest", "cubic")
        if interpolation_mode not in valid_modes and "cubic" not in interpolation_mode:
            raise ValueError(
                f"Invalid interpolation_mode: {interpolation_mode}. "
                f"Expected one of {valid_modes} or containing 'cubic'.",
            )

        self.forecast_size = forecast_size
        self.backcast_size = backcast_size
        self.interpolation_mode = interpolation_mode
        self.out_features = out_features

    def forward(self, theta: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Forward pass for identity basis projection.

        Args:
            theta (torch.Tensor): Basis coefficients tensor.
                Shape: (batch_size, backcast_size + num_knots)

        Returns:
            tuple[torch.Tensor, torch.Tensor]:
                - backcast: Backcast projection
                  Shape: (batch_size, backcast_size)
                - forecast: Forecast projection
                  Shape: (batch_size, forecast_size)

        Raises:
            ValueError: If using cubic interpolation with multiple output features
        """
        # Split theta into backcast and forecast components
        backcast = theta[:, : self.backcast_size]
        knots = theta[:, self.backcast_size :]

        # Reshape knots for interpolation [B, (out_features * num_knots)] -> [B, Q, K]
        knots = knots.reshape(theta.shape[0], self.out_features, -1)

        # Apply selected interpolation method
        if self.interpolation_mode in ["nearest", "linear"]:
            forecast = F.interpolate(
                knots,
                size=self.forecast_size,
                mode=self.interpolation_mode,
            )
        elif "cubic" in self.interpolation_mode:
            if self.out_features > 1:
                raise ValueError(f"Cubic interpolation requires out_features=1. Got {self.out_features} features.")

            # Process in batches to avoid memory issues
            knots = knots.unsqueeze(1)  # [B, 1, 1, K]
            forecast = torch.zeros((knots.size(0), self.forecast_size), device=knots.device)

            batch_size = knots.size(0)
            for i in range(0, batch_size, batch_size):  # Single iteration if no batching
                batch_knots = knots[i : i + batch_size]
                batch_forecast = F.interpolate(
                    batch_knots,
                    size=self.forecast_size,
                    mode="bicubic",
                )
                forecast[i : i + batch_size] = batch_forecast.squeeze([1, 2])

        # Permute to final shape [B, Q, H] -> [B, H, Q]
        forecast = forecast.permute(0, 2, 1)
        return backcast, forecast.squeeze(-1)


class NHITSBlock(nn.Module):
    """NHITS block implementing hierarchical pooling and basis projection.

    This block combines multi-layer perceptrons with hierarchical pooling operations
    and basis function projections for time series forecasting.

    Args:
        input_size (int): Size of the input window.
        h (int): Forecast horizon.
        n_theta (int): Number of basis function coefficients.
        mlp_units (list): List of tuples specifying MLP layer dimensions.
        basis (nn.Module): Basis function module for projection.
        futr_input_size (int): Number of future exogenous features.
        hist_input_size (int): Number of historical exogenous features.
        stat_input_size (int): Number of static exogenous features.
        n_pool_kernel_size (int): Kernel size for pooling operation.
        pooling_mode (str): Type of pooling ('MaxPool1d', 'AvgPool1d').
        dropout_prob (float): Dropout probability between MLP layers.
        activation (str): Activation function for MLP layers.

    Raises:
        ValueError: If invalid activation or pooling mode is provided.
    """

    def __init__(
        self,
        input_size: int,
        h: int,
        n_theta: int,
        mlp_units: list,
        basis: nn.Module,
        futr_input_size: int,
        hist_input_size: int,
        stat_input_size: int,
        n_pool_kernel_size: int,
        pooling_mode: str,
        dropout_prob: float,
        activation: str,
    ):
        super().__init__()

        # Calculate pooled dimensions
        pooled_hist_size = int(np.ceil(input_size / n_pool_kernel_size))
        pooled_futr_size = int(np.ceil((input_size + h) / n_pool_kernel_size))

        # Compute total input size for MLP
        input_size = (
            pooled_hist_size + hist_input_size * pooled_hist_size + futr_input_size * pooled_futr_size + stat_input_size
        )

        self.dropout_prob = dropout_prob
        self.futr_input_size = futr_input_size
        self.hist_input_size = hist_input_size
        self.stat_input_size = stat_input_size

        # Validate activation and pooling modes
        if activation not in SUPPORTED_ACTIVATIONS:
            raise ValueError(f"Activation {activation} not in {SUPPORTED_ACTIVATIONS}")
        if pooling_mode not in POOLING:
            raise ValueError(f"Pooling mode {pooling_mode} not in {POOLING}")

        activation = getattr(nn, activation)()

        # Configure pooling layer
        self.pooling_layer = getattr(nn, pooling_mode)(
            kernel_size=n_pool_kernel_size,
            stride=n_pool_kernel_size,
            ceil_mode=True,
        )

        # Construct MLP layers
        hidden_layers = [nn.Linear(in_features=input_size, out_features=mlp_units[0][0])]
        for layer in mlp_units:
            hidden_layers.append(nn.Linear(in_features=layer[0], out_features=layer[1]))
            hidden_layers.append(activation)  # type: ignore[arg-type]

            if self.dropout_prob > 0:
                hidden_layers.append(nn.Dropout(p=self.dropout_prob))  # type: ignore[arg-type]

        output_layer = [nn.Linear(in_features=mlp_units[-1][1], out_features=n_theta)]
        self.layers = nn.Sequential(*(hidden_layers + output_layer))
        self.basis = basis

    def forward(
        self,
        insample_y: torch.Tensor,
        futr_exog: torch.Tensor,
        hist_exog: torch.Tensor,
        stat_exog: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Forward pass through NHITS block.

        Args:
            insample_y (torch.Tensor): Historical target values.
                Shape: (batch_size, input_size)
            futr_exog (torch.Tensor): Future exogenous features.
                Shape: (batch_size, input_size + h, futr_input_size)
            hist_exog (torch.Tensor): Historical exogenous features.
                Shape: (batch_size, input_size, hist_input_size)
            stat_exog (torch.Tensor): Static exogenous features.
                Shape: (batch_size, stat_input_size)

        Returns:
            tuple[torch.Tensor, torch.Tensor]:
                - backcast: Residual component for input domain
                  Shape: (batch_size, input_size)
                - forecast: Forecast component for output domain
                  Shape: (batch_size, h)
        """
        # Temporal pooling
        insample_y = insample_y.unsqueeze(1)  # Add channel dimension
        insample_y = self.pooling_layer(insample_y)
        insample_y = insample_y.squeeze(1)

        batch_size = insample_y.size(0)
        features = [insample_y]

        # Process historical exogenous features
        if self.hist_input_size > 0:
            hist_exog = hist_exog.permute(0, 2, 1)  # [B, L, C] -> [B, C, L]
            hist_exog = self.pooling_layer(hist_exog)
            hist_exog = hist_exog.permute(0, 2, 1)  # [B, C, L] -> [B, L, C]
            features.append(hist_exog.reshape(batch_size, -1))

        # Process future exogenous features
        if self.futr_input_size > 0:
            futr_exog = futr_exog.permute(0, 2, 1)  # [B, L+H, C] -> [B, C, L+H]
            futr_exog = self.pooling_layer(futr_exog)
            futr_exog = futr_exog.permute(0, 2, 1)  # [B, C, L] -> [B, L, C]
            features.append(futr_exog.reshape(batch_size, -1))

        # Add static features
        if self.stat_input_size > 0:
            features.append(stat_exog.reshape(batch_size, -1))

        # Concatenate all features
        mlp_input = torch.cat(features, dim=1)

        # Compute basis weights and projections
        theta = self.layers(mlp_input)
        backcast, forecast = self.basis(theta)

        return backcast, forecast


def create_stack(
    h,
    input_size,
    stack_types,
    n_blocks,
    mlp_units,
    n_pool_kernel_size,
    n_freq_downsample,
    pooling_mode,
    interpolation_mode,
    dropout_prob_theta,
    activation,
    futr_input_size,
    hist_input_size,
    stat_input_size,
    n_out_size,
):
    """Create a stack of NHITS blocks.

    Args:
        h (int): Forecast horizon.
        input_size (int): Input size.
        stack_types (list[str]): List of stack types. Only 'identity' is currently supported.
        n_blocks (list[int]): Number of blocks for each stack type.
        mlp_units (list[int]): Number of units for each layer in the MLP.
        n_pool_kernel_size (list[int]): Pooling kernel sizes for each block.
        n_freq_downsample (list[int]): Frequency downsampling factors for each block.
        pooling_mode (str): Pooling mode ('max', 'avg', etc.).
        interpolation_mode (str): Interpolation mode for the basis function.
        dropout_prob_theta (float): Dropout probability for the theta layer.
        activation (str): Activation function for the MLP.
        futr_input_size (int): Future input size.
        hist_input_size (int): Historical input size.
        stat_input_size (int): Static input size.
        n_out_size (int): Output size for the basis function.

    Returns:
        list[NHITSBlock]: List of NHITSBlock instances.

    Raises:
        ValueError: If invalid stack type is encountered.
    """
    block_list = []
    for i in range(len(stack_types)):
        for _ in range(n_blocks[i]):
            if stack_types[i] != "identity":
                raise ValueError(f"Block type {stack_types[i]} not found!")

            n_theta = input_size + n_out_size * max(h // n_freq_downsample[i], 1)
            basis = _IdentityBasis(
                backcast_size=input_size,
                forecast_size=h,
                out_features=n_out_size,
                interpolation_mode=interpolation_mode,
            )

            nbeats_block = NHITSBlock(
                h=h,
                input_size=input_size,
                futr_input_size=futr_input_size,
                hist_input_size=hist_input_size,
                stat_input_size=stat_input_size,
                n_theta=n_theta,
                mlp_units=mlp_units,
                n_pool_kernel_size=n_pool_kernel_size[i],
                pooling_mode=pooling_mode,
                basis=basis,
                dropout_prob=dropout_prob_theta,
                activation=activation,
            )

            # Select type of evaluation and apply it to all layers of block
            block_list.append(nbeats_block)

    return block_list


class NHITSNetwork(BaseArchitecture):
    """NHITS: Neural Hierarchical Interpolation for Time Series Forecasting.

    A PyTorch module for univariate/multivariate time series forecasting using residual
    learning, forecast decomposition, and hierarchical pooling MLPs.

    Reference: [NeurIPS 2022](https://doi.org/10.1609/aaai.v37i6.25854)

    Args:
        num_target_feature (int): Number of target features to forecast.
        num_historical_features (int): Number of historical features.
        num_calendar_features (int): Number of calendar features.
        num_exogenous_features (int): Number of exogenous features.
        num_future_covariates (int): Number of future covariates.
        forecast_horizon (int): Length of forecasting horizon.
        lookback_window_size (int): Size of input window.
        out_activation_function (str): Output activation function. Defaults to "Identity".
        activation_function (str): Hidden layer activation. Defaults to "ReLU".
        dropout (float): Dropout probability. Defaults to 0.25.
        alpha (float): Loss weighting coefficient. Defaults to 0.1.
        stack_types (list | None): List of stack types. Defaults to None.
        n_blocks (list | None): Number of blocks per stack. Defaults to None.
        mlp_units (list | None): MLP layer sizes. Defaults to None.
        n_pool_kernel_size (list | None): Pooling kernel sizes. Defaults to None.
        n_freq_downsample (list | None): Downsampling factors. Defaults to None.
        pooling_mode (str): Pooling operation type. Defaults to "MaxPool1d".
        interpolation_mode (str): Interpolation method. Defaults to "linear".
        decompose_forecast (bool): Return component forecasts. Defaults to False.

    Attributes:
        blocks (nn.ModuleList): List of NHITS blocks in the network.
        pooling_mode (str): Type of pooling operation used.
        interpolation_mode (str): Basis function interpolation method.

    Raises:
        ValueError: If no exogenous features are provided.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        out_activation_function: str = "Identity",
        activation_function: str = "ReLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        stack_types: list | None = None,
        n_blocks: list | None = None,
        mlp_units: list | None = None,
        n_pool_kernel_size: list | None = None,
        n_freq_downsample: list | None = None,
        pooling_mode: str = "MaxPool1d",
        interpolation_mode: str = "linear",
        decompose_forecast: bool = False,
        encode_size: int = 256,
    ):
        super().__init__(
            num_target_feature=num_target_feature,
            num_historical_features=num_historical_features,
            num_calendar_features=num_calendar_features,
            num_exogenous_features=num_exogenous_features,
            num_future_covariates=num_future_covariates,
            forecast_horizon=forecast_horizon,
            lookback_window_size=lookback_window_size,
            dropout=dropout,
            alpha=alpha,
            output_activation=out_activation_function,
        )

        self.pooling_mode = pooling_mode
        self.interpolation_mode = interpolation_mode
        self.mlp_units = mlp_units or 3 * [[512, 512]]
        self.n_blocks = n_blocks or [1, 1, 1]
        self.n_pool_kernel_size = n_pool_kernel_size or [2, 2, 1]
        self.n_freq_downsample = n_freq_downsample or [4, 2, 1]
        self.stack_types = stack_types or ["identity", "identity", "identity"]
        self.decompose_forecast = decompose_forecast
        self.forecast_horizon = forecast_horizon
        self.lookback_window_size = lookback_window_size
        self.stat_exog_size = 0

        blocks = create_stack(
            h=self.forecast_horizon,
            input_size=self.lookback_window_size,
            stack_types=self.stack_types,
            futr_input_size=self.num_covariate_features,
            hist_input_size=self.num_historical_features,
            stat_input_size=self.stat_exog_size,
            n_blocks=self.n_blocks,
            mlp_units=self.mlp_units,
            n_pool_kernel_size=self.n_pool_kernel_size,
            n_freq_downsample=self.n_freq_downsample,
            pooling_mode=self.pooling_mode,
            interpolation_mode=self.interpolation_mode,
            dropout_prob_theta=dropout,
            activation=activation_function,
            n_out_size=self.num_target_feature,
        )
        self.blocks = torch.nn.ModuleList(blocks)

        # Latent projection for probabilistic heads: (B, H*Q) -> (B, encode_size)
        self._encode_size = encode_size
        self.encode_layer = nn.Linear(forecast_horizon * num_target_feature, encode_size)

        if self.num_covariate_features < 1:
            raise ValueError("Exogenous features must be provided in NHITS")

    def _prepare_input(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor | None, torch.Tensor]:
        """Prepare input tensor by separating components.

        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, seq_len, num_features)

        Returns:
            tuple[torch.Tensor, torch.Tensor | None, torch.Tensor]:
                - Historical target values
                - Historical features
                - Combined covariates
        """
        past_feature, covarite_feature = unstack_features(
            x,  # type: ignore[arg-type]
            lookback_window_size=self.lookback_window_size,
            forecast_horizon=self.forecast_horizon,
            num_padding=self.num_past_features - self.num_covariate_features,
        )
        insample_y = past_feature[:, :, : self.num_target_feature].squeeze(-1)
        hist_covarite = past_feature[:, :, self.num_target_feature + self.num_historical_features :]
        covarite_feature = torch.cat([hist_covarite, covarite_feature], dim=1)  # type: ignore[assignment, list-item]

        if self.num_historical_features > 0:
            hist_exog = past_feature[
                :,
                :,
                self.num_target_feature : self.num_target_feature + self.num_historical_features,
            ]
        else:
            hist_exog = None

        return insample_y, hist_exog, covarite_feature  # type: ignore[return-value]

    def _residual_stack(self, x: torch.Tensor, stat_exog: torch.Tensor | None = None) -> torch.Tensor:
        """Run the residual block stack and return the raw accumulated forecast.

        Shared by both :meth:`encode` and :meth:`forward` to avoid duplicating
        the block-iteration logic.

        Args:
            x: Input tensor of shape ``(B, seq_len, num_features)``.
            stat_exog: Static exogenous features. Defaults to None.

        Returns:
            Accumulated forecast of shape ``(B, forecast_horizon * num_target_feature)``.
        """
        insample_y, hist_exog, futr_exog = self._prepare_input(x)
        residuals = insample_y.flip(dims=(-1,))
        forecast = insample_y[:, -1:]
        for block in self.blocks:
            backcast, block_forecast = block(
                insample_y=residuals,
                futr_exog=futr_exog,
                hist_exog=hist_exog,
                stat_exog=stat_exog,
            )
            residuals = residuals - backcast
            forecast = forecast + block_forecast
        return forecast

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        """Map input to a fixed-size latent vector for probabilistic heads.

        Runs the full residual block stack, flattens the accumulated forecast
        ``(B, H * Q)``, and projects it through ``encode_layer`` to produce
        ``(B, encode_size)``.

        Args:
            x: Input tensor of shape ``(B, seq_len, num_features)``.

        Returns:
            Latent tensor of shape ``(B, encode_size)``.
        """
        forecast = self._residual_stack(x)
        z = forecast.reshape(forecast.shape[0], -1)  # (B, H * Q)
        return self.encode_layer(z)  # (B, encode_size)

    def forward(self, x: torch.Tensor, stat_exog: torch.Tensor | None = None) -> torch.Tensor:
        """Forward pass through NHITS architecture.

        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, seq_len, num_features)
            stat_exog (torch.Tensor | None): Static exogenous features. Defaults to None.

        Returns:
            torch.Tensor: Forecast tensor of shape (batch_size, forecast_horizon)
        """
        insample_y, hist_exog, futr_exog = self._prepare_input(x)
        residuals = insample_y.flip(dims=(-1,))
        forecast = insample_y[:, -1:]
        block_forecasts = [forecast.repeat(1, self.forecast_horizon * self.num_target_feature)]

        for _, block in enumerate(self.blocks):
            backcast, block_forecast = block(
                insample_y=residuals,
                futr_exog=futr_exog,
                hist_exog=hist_exog,
                stat_exog=stat_exog,
            )
            residuals = residuals - backcast
            forecast = forecast + block_forecast

            if self.decompose_forecast:
                block_forecasts.append(block_forecast)

        forecast = self.output_activation(forecast)
        forecast = forecast.reshape(forecast.shape[0], self.forecast_horizon, self.num_target_feature)
        if self.decompose_forecast:
            block_forecasts = torch.stack(block_forecasts)  # type: ignore[assignment]
            block_forecasts = block_forecasts.reshape(  # type: ignore[attr-defined]
                block_forecasts.shape[0],
                -1,
                self.forecast_horizon,
                self.num_target_feature,  # type: ignore[attr-defined]
            )
            return block_forecasts
        return forecast


class NHITS(BaseNeuralModel):
    """NHITS model for probabilistic time series forecasting.

    Implements the Neural Hierarchical Interpolation for Time Series (NHITS) architecture
    with configurable stacks, pooling operations, and basis functions. Suitable for both
    univariate and multivariate forecasting tasks.

    Attributes:
        model (NHITSNetwork): The underlying NHITS forecasting network.
        data_pipeline (sklearn.pipeline.Pipeline, optional): Data preprocessing pipeline.
        tra_metric_fcn (torchmetrics.Metric): Metric function for training.
        val_metric_fcn (torchmetrics.Metric): Metric function for validation.
        checkpoints_path (str): Directory path for saving checkpoints.
        hparams (dict): Hyperparameters saved during initialization.

    Notes:
        Inherits from `BaseNeuralModel`, which provides optimizer and scheduler
        configurations, training/validation steps, and checkpoint handling.

    References:
        Oreshkin, B. N., et al. "N-HiTS: Neural Hierarchical Interpolation for Time
        Series Forecasting." AAAI, vol. 37, no. 6, 2023, pp. 7389-7397,
        https://doi.org/10.1609/aaai.v37i6.25854.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        activation_function: str = "ReLU",
        out_activation_function: str = "Identity",
        dropout: float = 0.25,
        alpha: float = 0.1,
        stack_types: list[str] | None = None,
        n_blocks: list[int] | None = None,
        mlp_units: list[list[int]] | None = None,
        n_pool_kernel_size: list[int] | None = None,
        n_freq_downsample: list[int] | None = None,
        pooling_mode: str = "MaxPool1d",
        interpolation_mode: str = "linear",
        decompose_forecast: bool = False,
        encode_size: int = 256,
        metric: str = "mae",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        """Initialize the NHITS model.

        Args:
            num_target_feature (int): Number of target series to predict. Must be
                positive.
            num_historical_features (int): Number of historical features. Must be
                non-negative.
            num_calendar_features (int): Number of calendar features. Must be
                non-negative.
            num_exogenous_features (int): Number of exogenous features. Must be
                non-negative.
            num_future_covariates (int): Number of future covariates. Must be
                non-negative.
            forecast_horizon (int): Number of time steps to forecast. Must be positive.
            lookback_window_size (int): Size of the input window. Must be positive.
            activation_function (str, optional): Activation function for hidden layers
                ("ReLU", "Softplus", "Tanh", "SELU", "LeakyReLU", "PReLU", "Sigmoid").
                Defaults to "ReLU".
            out_activation_function (str, optional): Activation function for output
                layer. Defaults to "Identity".
            dropout (float, optional): Dropout rate, between 0 and 1. Defaults to
                0.25.
            alpha (float, optional): Weight for MSE vs. L1 loss, between 0 and 1.
                Defaults to 0.1.
            stack_types (list, optional): Types of NHITS stacks (e.g., ["identity"]).
                Defaults to ["identity", "identity", "identity"].
            n_blocks (list, optional): Number of blocks per stack. Defaults to
                [1, 1, 1].
            mlp_units (list, optional): MLP layer dimensions per stack (e.g.,
                [[512, 512]]). Defaults to [[512, 512], [512, 512], [512, 512]].
            n_pool_kernel_size (list, optional): Pooling kernel sizes per stack.
                Defaults to [2, 2, 1].
            n_freq_downsample (list, optional): Frequency downsampling factors per
                stack. Defaults to [4, 2, 1].
            pooling_mode (str, optional): Pooling operation ("MaxPool1d", "AvgPool1d").
                Defaults to "MaxPool1d".
            interpolation_mode (str, optional): Basis function interpolation ("linear",
                "nearest", "cubic"). Defaults to "linear".
            decompose_forecast (bool, optional): Return component forecasts. Defaults to
                False.
            encode_size (int, optional): Width of the latent vector produced by
                :meth:`~twiga.models.nn.net.nhits.NHITSNetwork.encode`, used by
                probabilistic heads.  Defaults to 256.
            metric (str, optional): Evaluation metric ("mae", "mse", "smape").
                Defaults to "mae".
            optimizer_params (dict, optional): Optimizer parameters (e.g.,
                {"adam": {"params": {"lr": 1e-4, "weight_decay": 1e-6}}}). Defaults
                to None.
            scheduler_params (dict, optional): Scheduler parameters (e.g.,
                {"multi_step": {"params": {"prob_decay_1": 0.5, "prob_decay_2": 0.9,
                "gamma": 0.1}}}). Defaults to None.
            max_epochs (int, optional): Maximum training epochs. Defaults to 10.

        Examples:
            Initialize an NHITS model for forecasting:
                >>> model = NHITS(
                ...     num_target_feature=1,
                ...     num_historical_features=10,
                ...     num_calendar_features=3,
                ...     num_exogenous_features=5,
                ...     num_future_covariates=2,
                ...     forecast_horizon=24,
                ...     lookback_window_size=96,
                ...     activation_function="ReLU",
                ...     metric="mae",
                ...     max_epochs=20,
                ... )

        Raises:
            ValueError: If parameters do not meet constraints (e.g., negative values,
                invalid metric).
        """
        super().__init__(
            metric=metric,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )

        # Set default values if None
        stack_types = stack_types or ["identity", "identity", "identity"]
        n_blocks = n_blocks or [1, 1, 1]
        mlp_units = mlp_units or [[512, 512], [512, 512], [512, 512]]
        n_pool_kernel_size = n_pool_kernel_size or [2, 2, 1]
        n_freq_downsample = n_freq_downsample or [4, 2, 1]

        self.model = NHITSNetwork(
            num_target_feature=num_target_feature,
            num_historical_features=num_historical_features,
            num_calendar_features=num_calendar_features,
            num_exogenous_features=num_exogenous_features,
            num_future_covariates=num_future_covariates,
            lookback_window_size=lookback_window_size,
            forecast_horizon=forecast_horizon,
            activation_function=activation_function,
            out_activation_function=out_activation_function,
            dropout=dropout,
            alpha=alpha,
            stack_types=stack_types,
            n_blocks=n_blocks,
            mlp_units=mlp_units,
            n_pool_kernel_size=n_pool_kernel_size,
            n_freq_downsample=n_freq_downsample,
            pooling_mode=pooling_mode,
            interpolation_mode=interpolation_mode,
            decompose_forecast=decompose_forecast,
            encode_size=encode_size,
        )
