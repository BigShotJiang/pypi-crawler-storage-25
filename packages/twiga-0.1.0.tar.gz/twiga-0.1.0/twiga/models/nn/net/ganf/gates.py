import torch


def _assert_1d(x: torch.Tensor, name: str = "tensor") -> None:
    """Validate tensor is 1D."""
    if x.dim() != 1:
        raise ValueError(f"{name} must be 1D, got shape {tuple(x.shape)}")


def compute_active_gate(
    gate_logits: torch.Tensor,
    gate_type: str = "sigmoid",
    gate_scale: float = 5.0,
    eps: float = 1e-4,
) -> torch.Tensor:
    _assert_1d(gate_logits, "gate_logits")

    def _cap(y: torch.Tensor) -> torch.Tensor:
        return torch.clamp(y, eps, 1.0 - eps)

    if gate_type == "tanh":
        gates = 0.5 * (torch.tanh(gate_logits * gate_scale) + 1)
        return _cap(gates)

    if gate_type == "sigmoid":
        gates = torch.sigmoid(gate_logits * gate_scale)
        return _cap(gates)

    raise ValueError(f"Unknown gate_type={gate_type}. Supported: 'sigmoid', 'tanh'")


def initialise_gate(num_channels: int, gate_scale: float) -> torch.Tensor:
    """Initialize feature gate logits with a sparsity-inducing strategy.

    Sets initial gate logits to encourage selective feature activation.
    Multi-channel groups start near zero (uncertain), while single-channel
    target groups start strongly positive (always active).

    The initialization strategy balances two goals:

    1. Allow flexibility in learning which features are important
       (multi-channel groups - random near zero).
    2. Ensure the target feature always contributes at the start of training
       (single-channel group - positive constant).

    Args:
        num_channels (int): Number of features in the group.  Determines the
            initialization strategy:

            - ``num_channels > 1`` → uniform random in ``[-0.1, 0.1] / gate_scale``
              giving sigmoid activations near 0.5 so learning can go either way.
            - ``num_channels == 1`` → constant ``2.0 / gate_scale``
              giving ``sigmoid(2.0) ≈ 0.88``, keeping the target feature active.

        gate_scale (float): Temperature multiplier used during forward gating.
            Logits are pre-divided by ``gate_scale`` so that the effective
            initialisation is independent of the chosen scale.

    Returns:
        torch.Tensor: Gate logits of shape ``(num_channels,)``.

    Example::

        >>> gates_multi  = initialise_gate(10, gate_scale=5.0)  # (10,) near zero
        >>> gates_target = initialise_gate(1,  gate_scale=5.0)  # (1,)  = [0.4]

    Note:
        Gates are logits (pre-activation).  The actual activation is computed
        during the forward pass via :func:`compute_active_gate`.
    """
    if num_channels > 1:
        return torch.empty(num_channels).uniform_(-0.1, 0.1) / gate_scale
    return torch.full((num_channels,), 2.0 / gate_scale)
