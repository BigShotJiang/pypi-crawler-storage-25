from __future__ import annotations

from typing import Literal, TypedDict

import pandas as pd
from scipy.stats import pearsonr, spearmanr
import torch
from torch import Tensor

from twiga.core.data.processing import split_features_by_group


class GroupWeightContributionRecord(TypedDict):
    """Type for a single group contribution entry from projection weights."""

    Group: str
    Branch: Literal["past", "fut"]
    Weight_Magnitude: float
    Importance: float


class GroupOutputContributionRecord(TypedDict):
    """Record for a group's output contribution on a specific input batch."""

    Group: str
    Branch: Literal["past", "fut"]
    Contribution: float


class FeatureImportanceRecord(TypedDict):
    """Type for a single feature importance entry."""

    Group: str
    Branch: Literal["past", "fut"]
    Feature: str | int
    Importance: float


class GroupVarianceRecord(TypedDict):
    """Record for variance-based group importance."""

    Group: str
    Branch: Literal["past", "fut"]
    Raw_Variance: float
    Importance: float


class SensitivityRecord(TypedDict):
    """Record for per-feature local sensitivity in a group branch."""

    Group: str
    Branch: Literal["past", "fut"]
    Feature: int | str
    Sensitivity: float


class GlobalSensitivityRecord(TypedDict):
    """Record for global input-to-forecast sensitivity per feature."""

    Group: str
    Feature: int | str
    Global_Sensitivity: float


def to_model_device_and_dtype(
    tensor: torch.Tensor,
    model: torch.nn.Module,
) -> torch.Tensor:
    """Move the input tensor to the same device and dtype as the model's parameters.

    This is a helper function commonly used in time-series / forecasting models
    to ensure the input batch matches the model's expected device and precision.

    Args:
        tensor: Input tensor to be prepared (usually a batch of data).
        model: The PyTorch model whose device and dtype should be matched.

    Returns:
        The input tensor moved to the correct device and dtype.

    Example:
        >>> x = torch.randn(32, 10)
        >>> prepared_x = to_model_device_and_dtype(x, model)
    """
    # Get the dtype from the first parameter (most reliable way in mixed-precision setups)
    target_dtype = next(model.parameters()).dtype
    target_device = next(model.parameters()).device

    return tensor.to(device=target_device, dtype=target_dtype)


def split_batch_into_past_and_future(
    batch: torch.Tensor,
    model: torch.nn.Module,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Split a batched input tensor into past (historical) and fut (covariates) parts.

    This function delegates to the model's internal feature splitting logic while
    providing a cleaner public interface.

    Args:
        batch: Input batch tensor of shape typically (batch_size, sequence_length, features)
        model: The forecasting model containing the splitting configuration.

    Returns:
        Tuple containing:
            - past_groups: Tensor(s) containing historical features + past covariates
            - future_groups: Tensor(s) containing fut-known covariates

    Raises:
        AttributeError: If the model is missing required attributes.
    """
    # Early validation of required model attributes (fail fast)
    required_attrs = {
        "lookback_window_size",
        "forecast_horizon",
        "groups",
        "num_past_features",
        "num_covariate_features",
    }
    missing = required_attrs - set(dir(model))
    if missing:
        raise AttributeError(f"Model is missing required attributes for splitting: {', '.join(missing)}")

    past_groups, future_groups = split_features_by_group(
        batch,
        lookback_window_size=model.lookback_window_size,  # type: ignore[arg-type]
        forecast_horizon=model.forecast_horizon,  # type: ignore[arg-type]
        groups=model.groups,  # type: ignore[arg-type]
        num_past_features=model.num_past_features,  # type: ignore[arg-type]
        num_covariate_features=model.num_covariate_features,  # type: ignore[arg-type]
    )

    return past_groups, future_groups


def compute_weight_norm(
    x: torch.Tensor,
    norm_type: Literal["l1", "l2", "spec"] = "l2",
) -> float:
    """Compute a norm-based magnitude of the weight matrix in a layer.

    Args:
        x: A torch.Tensor with weight or output.
        norm_type: Type of norm to compute:
            - "l1": Mean absolute value (sparsity-friendly)
            - "l2": Frobenius norm (L2 matrix norm, default)
            - "spec": Spectral norm (largest singular value)

    Returns:
        The computed scalar norm value (float).
    """
    if norm_type == "l1":
        return torch.abs(x).mean().item()

    if norm_type == "l2":
        return torch.linalg.matrix_norm(x, ord="fro").item()

    if norm_type == "spec":
        # Spectral norm requires detached CPU tensor for stability in some cases
        return torch.linalg.matrix_norm(x.detach().cpu(), ord=2).item()

    raise ValueError(f"Unsupported norm_type: {norm_type!r}. Choose 'l1', 'l2', or 'spec'.")


def extract_feature_importances(model: torch.nn.Module) -> list[FeatureImportanceRecord]:
    """Extract feature importance scores from gated branches of a grouped time-series model.

    Processes learnable feature gates (typically passed through sigmoid or similar)
    for past and fut branches across all groups.

    Importance scores (post-gating) indicate how strongly each feature contributes
    to its group: ~1.0 = fully used, ~0.0 = suppressed/masked by the model.

    Args:
        model: Trained model with `group_modules`, `groups`, and `gate_compute_fn`.

    Returns:
        List of dicts with group, branch, feature, and importance values.

    Raises:
        AttributeError: If required model attributes are missing.

    Example:
        >>> records = extract_feature_importances(model)
        >>> import pandas as pd
        >>> pd.DataFrame(records).sort_values("Importance", ascending=False).head(10)
    """
    if not all(hasattr(model, attr) for attr in ["group_modules", "groups", "gate_compute_fn"]):
        missing = [attr for attr in ["group_modules", "groups", "gate_compute_fn"] if not hasattr(model, attr)]
        raise AttributeError(f"Model missing required attributes: {', '.join(missing)}")

    records: list[FeatureImportanceRecord] = []

    for idx, branch_module in enumerate(model.group_modules):  # type: ignore[arg-type]
        group_config = model.groups[idx]  # type: ignore[index]
        group_name = group_config.get("name", f"Group_{idx}")  # type: ignore[union-attr]

        for branch_type in ("past", "fut"):
            gate_attr = f"{branch_type}_feature_gate"
            if not hasattr(branch_module, gate_attr):
                continue

            gate_weights = getattr(branch_module, gate_attr)
            scores = model.gate_compute_fn(gate_weights)  # type: ignore[operator]
            scores_np = scores.detach().cpu().numpy().flatten()

            feature_names = group_config.get(f"{branch_type}_feature_names", [])  # type: ignore[union-attr]

            for i, val in enumerate(scores_np):
                feature_label = feature_names[i] if i < len(feature_names) and isinstance(feature_names[i], str) else i

                records.append(
                    {
                        "Group": group_name,
                        "Branch": branch_type,
                        "Feature": feature_label,
                        "Importance": float(val),
                    },
                )

    return records


@torch.no_grad()
def extract_group_contributions(
    model: torch.nn.Module,
    norm_type: Literal["l1", "l2", "spec"] = "l2",
) -> list[GroupWeightContributionRecord]:
    """Extract normalized importance of each group via projection weight magnitudes.

    This measures how much the entire group (e.g., "Historical Targets" vs.
    "Exogenous Variables") contributes to the final forecast μ̂_θ. Because the
    model is additive, the final forecast is a sum of group outputs z⁽ᵐ⁾. The
    linear projection Wₘᵀ determines the scale of this contribution.

    Metric: Normalized norm of the projection weights.
    Calculation (for Frobenius norm):
    I_group(m) = ‖Wₘ‖_F / Σ_k ‖W_k‖_F

    Importance scores (post-normalization) indicate relative contribution:
    higher values mean the group's output has larger scale/impact on the final
    forecast.

    Args:
        model: Trained additive forecasting model with `group_modules` and `groups`.
        norm_type: Norm to use for magnitude ('fro' recommended for matrix scale).

    Returns:
        List of dicts with group, branch, raw magnitude, and normalized importance.

    Raises:
        AttributeError: If required model attributes are missing.
        ValueError: If invalid norm_type is provided.

    Example:
        >>> records = extract_group_contributions(model, norm_type="fro")
        >>> import pandas as pd
        >>> pd.DataFrame(records).sort_values("Importance", ascending=False)
    """
    if not all(hasattr(model, attr) for attr in ["group_modules", "groups"]):
        missing = [a for a in ["group_modules", "groups"] if not hasattr(model, a)]
        raise AttributeError(f"Model missing required attributes: {', '.join(missing)}")

    model.eval()

    records: list[GroupWeightContributionRecord] = []
    total_norm = 0.0

    branch_map = {
        "past_proj": "past",
        "fut_proj": "fut",
    }

    for idx, branch_module in enumerate(model.group_modules):  # type: ignore[arg-type]
        group_name = model.groups[idx].get("name", f"Group_{idx}")  # type: ignore[index, union-attr]

        for proj_attr, branch_name in branch_map.items():
            if not hasattr(branch_module, proj_attr):
                continue

            proj_layer = getattr(branch_module, proj_attr)
            magnitude = compute_weight_norm(proj_layer.weight, norm_type=norm_type)

            total_norm += magnitude

            records.append(
                {
                    "Group": group_name,
                    "Branch": branch_name,  # type: ignore[typeddict-item]
                    "Weight_Magnitude": magnitude,
                    "Importance": 0.0,  # placeholder - normalized later
                },
            )

    # Normalize after collecting all magnitudes (avoid division during loop)
    if total_norm > 0:
        for r in records:
            r["Importance"] = r["Weight_Magnitude"] / (total_norm + 1e-12)

    return records


@torch.no_grad()
def compute_group_output_contributions(
    model: torch.nn.Module,
    batch: torch.Tensor,
) -> list[GroupOutputContributionRecord]:
    """Compute per-group contribution magnitudes via L1 norm of projected outputs.

    Runs a forward pass through each group's encoder + projection, after gating,
    and measures the average absolute magnitude of the resulting projection.

    Interpretation:
        Higher `Contribution` values indicate that the group's output (after gating
        and encoding) has larger scale in the forecast space → stronger influence
        on the final additive prediction for this specific input batch.

    Args:
        model: Forecasting model with group_modules, groups, encoders, projectors,
               feature gates and gate_compute_fn.
        batch: Input tensor of shape [batch_size, total_length, features] or
               [total_length, features] (automatically unsqueezed).

    Returns:
        List of dicts containing group name, branch type and L1 contribution magnitude.

    Raises:
        AttributeError: If required model attributes are missing.

    Example:
        >>> batch = torch.randn(16, 336, 48)
        >>> contribs = compute_group_output_contributions(model, batch)
        >>> import pandas as pd
        >>> pd.DataFrame(contribs).sort_values("Contribution", ascending=False)
    """
    # Validate required model attributes
    required = {
        "group_modules",
        "groups",
        "lookback_window_size",
        "forecast_horizon",
        "num_past_features",
        "num_covariate_features",
        "gate_compute_fn",
    }
    missing = [attr for attr in required if not hasattr(model, attr)]
    if missing:
        raise AttributeError(f"Model missing required attributes: {', '.join(missing)}")

    # Prepare input (device + dtype + batch dim)
    batch = to_model_device_and_dtype(batch, model)

    # Split into past and fut groups once
    past_groups, future_groups = split_batch_into_past_and_future(batch, model)

    records: list[GroupOutputContributionRecord] = []

    branch_configs = [
        ("past", "past_enc", "past_proj", "past_feature_gate", past_groups),
        ("fut", "fut_enc", "fut_proj", "fut_feature_gate", future_groups),
    ]

    for group_idx, branch_module in enumerate(model.group_modules):  # type: ignore[arg-type]
        group_name = model.groups[group_idx].get("name", f"Group_{group_idx}")  # type: ignore[index, union-attr]

        for branch_name, enc_attr, proj_attr, gate_attr, group_data in branch_configs:
            if not hasattr(branch_module, enc_attr):
                continue

            # Get group-specific slice
            group_input = group_data[group_idx]

            # Apply gating
            gate_weights = getattr(branch_module, gate_attr)
            gate = model.gate_compute_fn(gate_weights)  # type: ignore[operator]

            # Encoder → gated latent representation
            z_m = getattr(branch_module, enc_attr)(group_input * gate)

            # Project to forecast space
            proj = getattr(branch_module, proj_attr)(z_m)

            # L1 norm along the output/forecast dimension, averaged over batch
            contrib = torch.norm(proj, p=1, dim=-1).mean().item()

            records.append(
                {
                    "Group": group_name,
                    "Branch": branch_name,  # type: ignore[typeddict-item]
                    "Contribution": contrib,
                },
            )

    return records


@torch.no_grad()
def compute_variance_based_importance(
    model: torch.nn.Module,
    batch: Tensor,
) -> list[GroupVarianceRecord]:
    """Compute group importance via variance of projected outputs across a batch.

    In additive forecasting models, the final prediction is the sum of group
    contributions: μ̂_θ = Σ_m (W_mᵀ z^(m)). A group that produces nearly constant
    output across diverse inputs acts like a fixed bias and has low effective
    importance for explaining variability in predictions.

    This method measures importance as the fraction of total output variance
    explained by each group:
        I_variance(m) = Var(W_mᵀ z^(m)) / Σ_k Var(W_kᵀ z^(k))

    Higher values → the group's output fluctuates more → it drives changes
    in the forecast across different inputs.

    Requires batch_size ≥ 2 (otherwise variance is undefined).

    Args:
        model: Trained additive forecasting model.
        batch: Input tensor [batch_size, total_length, features].
               Will be moved to model device/dtype automatically.

    Returns:
        List of records with raw variance and normalized importance.

    Raises:
        ValueError: If batch_size < 2.
        AttributeError: If required model attributes are missing.

    Example:
        >>> batch = next(iter(test_loader))  # shape: [B, T, F]
        >>> records = compute_variance_based_importance(model, batch)
        >>> import pandas as pd
        >>> df = pd.DataFrame(records)
        >>> df.sort_values("Importance", ascending=False)
    """
    if batch.dim() == 2:
        batch = batch.unsqueeze(0)
    if batch.size(0) < 2:
        raise ValueError("Variance importance requires batch_size >= 2")

    batch = to_model_device_and_dtype(batch, model)
    past_groups, future_groups = split_batch_into_past_and_future(batch, model)

    raw_variances: dict[str, float] = {}
    total_var = 0.0

    branch_configs = [
        ("past", "past_enc", "past_proj", "past_feature_gate", past_groups),
        ("fut", "fut_enc", "fut_proj", "fut_feature_gate", future_groups),
    ]

    for group_idx, branch in enumerate(model.group_modules):  # type: ignore[arg-type]
        group_name = model.groups[group_idx].get("name", f"Group_{group_idx}")  # type: ignore[index, union-attr]

        for b_name, enc_attr, proj_attr, gate_attr, data_source in branch_configs:
            if not hasattr(branch, enc_attr):
                continue

            x_group = data_source[group_idx]
            gate = model.gate_compute_fn(getattr(branch, gate_attr))  # type: ignore[operator]
            z_m = getattr(branch, enc_attr)(x_group * gate)
            proj = getattr(branch, proj_attr)(z_m)  # [B, H, out_dim]

            # Variance across batch (dim=0), then mean over horizon + output dim
            var_per_horizon = proj.var(dim=0, unbiased=False)  # [H, out_dim]
            group_var = var_per_horizon.mean().item()

            key = f"{group_name}_{b_name}"
            raw_variances[key] = group_var
            total_var += group_var

    records: list[GroupVarianceRecord] = []
    for key, var_val in raw_variances.items():
        group_name, branch_name = key.rsplit("_", 1)
        records.append(
            {
                "Group": group_name,
                "Branch": branch_name,  # type: ignore[arg-type, typeddict-item]
                "Raw_Variance": var_val,
                "Importance": var_val / (total_var + 1e-12),
            },
        )

    return records


@torch.no_grad()
def compute_variance_importance_over_dataset(model, loader):
    model.eval()
    all_records = []
    for batch, _ in loader:  # assuming DataLoader yields (x, y)
        records = compute_variance_based_importance(model, batch)
        all_records.extend(records)

    df = pd.DataFrame(all_records)
    return df.groupby(["Group", "Branch"]).mean().reset_index()


def compute_feature_sensitivity(
    model: torch.nn.Module,
    batch: Tensor,
    *,
    use_feature_names: bool = True,
) -> list[SensitivityRecord]:
    """Compute local sensitivity of group latent representations w.r.t. input features.

    This dynamic measure approximates the expected L2 norm of the Jacobian:

        S_j^(m) = E_x [ || ∂ z^(m) / ∂ x_j^(m) ||_2 ]

    It quantifies how sensitive the group's latent representation is to small
    changes in each input feature j. High sensitivity + high gate value → strong
    evidence that the gating mechanism is controlling information flow as intended.

    This is a **strong verification** of the interpretability of the learned gates:
    gates should suppress features that have low sensitivity (and vice versa).

    Computation:
    - Forward pass with gating → get z^(m)
    - Backpropagate unit gradients from z^(m) sum → inputs
    - Take L2 norm of per-feature gradients, averaged over batch & time

    Args:
        model: The forecasting model (must support autograd).
        batch: Input tensor [batch_size, total_length, features] or [total_length, features].
        use_feature_names: If True, try to use group["past/future_feature_names"] instead of indices.

    Returns:
        List of sensitivity records per feature per group/branch.

    Raises:
        RuntimeError: If autograd fails (e.g. model has detached ops).
        ValueError: If batch is too small or incompatible.

    Warning:
        Requires model to be in train mode (for dropout / batchnorm consistency) and
        inputs to require gradients. Computation can be memory-intensive for large
        latent dimensions or batches.

    Example:
        >>> batch = next(iter(val_loader))[0]  # features only
        >>> sens = compute_feature_sensitivity(model, batch)
        >>> import pandas as pd
        >>> df = pd.DataFrame(sens)
        >>> df.sort_values("Sensitivity", ascending=False).head(12)
    """
    if batch.dim() == 2:
        batch = batch.unsqueeze(0)
    if batch.size(0) < 1:
        raise ValueError("Batch must contain at least one sample")

    # Prepare input for gradient tracking
    batch = to_model_device_and_dtype(batch, model)
    batch = batch.detach().clone().requires_grad_(True)

    past_groups, future_groups = split_batch_into_past_and_future(batch, model)

    records: list[SensitivityRecord] = []

    branch_configs = [
        ("past", past_groups, "past_enc", "past_feature_gate"),
        ("fut", future_groups, "fut_enc", "fut_feature_gate"),
    ]

    for group_idx, branch_module in enumerate(model.group_modules):  # type: ignore[arg-type]
        group_name = model.groups[group_idx].get("name", f"Group_{group_idx}")  # type: ignore[index, union-attr]

        for b_name, group_data, enc_attr, gate_attr in branch_configs:
            if not hasattr(branch_module, enc_attr):
                continue

            group_input = group_data[group_idx]  # [B, seq, feat_m]

            gate_weights = getattr(branch_module, gate_attr)
            gate = model.gate_compute_fn(gate_weights)  # type: ignore[operator]

            # Forward: gated → encoder
            z_m = getattr(branch_module, enc_attr)(group_input * gate)  # [B, latent_dim]

            # Backpropagate unit gradients from sum(z_m) w.r.t. group_input
            grad_outputs = torch.ones_like(z_m)
            grads_tuple = torch.autograd.grad(
                outputs=z_m,
                inputs=group_input,
                grad_outputs=grad_outputs,
                retain_graph=False,
                create_graph=False,
                allow_unused=True,
            )

            if not grads_tuple or grads_tuple[0] is None:
                continue  # no gradient flow (possible if detached or no path)

            grads: Tensor = grads_tuple[0]  # [B, seq_len, feat_m]

            # L2 norm per feature, averaged over batch & time
            # → shape: [feat_m]
            per_feature_l2 = torch.sqrt((grads**2).mean(dim=(0, 1)))

            # Try to use feature names if requested and available
            feature_labels = []
            if use_feature_names:
                key = f"{b_name}_feature_names"
                names = model.groups[group_idx].get(key, [])  # type: ignore[index, union-attr]
                feature_labels = [
                    names[j] if j < len(names) and isinstance(names[j], str) else j for j in range(len(per_feature_l2))
                ]
            else:
                feature_labels = list(range(len(per_feature_l2)))

            for f_idx, f_label in enumerate(feature_labels):
                records.append(
                    {
                        "Group": group_name,
                        "Branch": b_name,  # type: ignore[typeddict-item]
                        "Feature": f_label,
                        "Sensitivity": per_feature_l2[f_idx].item(),
                    },
                )

    return records


def normalize_sensitivity_within_groups(
    sensitivity_records: list[dict],
    norm_strategy: str = "max",  # or "sum", "std", etc.
) -> pd.DataFrame:
    """Normalize sensitivity scores within each (Group, Branch) combination.

    Args:
        sensitivity_records: Output from compute_feature_sensitivity(...)
        norm_strategy: How to normalize ('max' → divide by group max, most common)

    Returns:
        DataFrame with added 'Normalized_Sensitivity' column
    """
    df = pd.DataFrame(sensitivity_records)

    def normalize_fn(x):
        if norm_strategy == "max":
            return x / (x.max() + 1e-10) if x.max() > 0 else x
        if norm_strategy == "sum":
            return x / (x.sum() + 1e-10)
        if norm_strategy == "std":
            return (x - x.mean()) / (x.std() + 1e-10)
        return x

    df["Normalized_Sensitivity"] = df.groupby(["Group", "Branch"])["Sensitivity"].transform(normalize_fn)

    return df


def compute_global_predictive_sensitivity(
    model: torch.nn.Module,
    batch: Tensor,
    *,
    use_feature_names: bool = True,
) -> list[GlobalSensitivityRecord]:
    """Compute global end-to-end sensitivity of the final forecast w.r.t. input features.

    This measures the L2 norm of the Jacobian:

        S_j = E_x [ || ∂ ŷ / ∂ x_j ||_2 ]

    where ŷ is the model's final forecast output. It quantifies how much small
    changes in each input feature j (across all groups) affect the prediction.

    Unlike group-level sensitivity, this is end-to-end: it includes effects from
    gating, encoding, projection, and additive combination across groups.

    High values indicate features that strongly influence the numerical forecast.

    Computation:
    - Full forward pass to get ŷ
    - Backpropagate unit gradients from ŷ → inputs
    - L2 norm per feature, averaged over batch & time dims

    Args:
        model: The forecasting model (must support autograd).
        batch: Input tensor [batch_size, total_length, features] or [total_length, features].
        use_feature_names: If True, attempt to map feature indices to names from group configs.

    Returns:
        List of sensitivity records per feature, grouped by group.

    Raises:
        RuntimeError: If autograd fails (e.g., no gradient path).
        ValueError: If batch is empty or incompatible.

    Warning:
        Requires inputs to require gradients. Use small batches for large models
        to avoid memory issues.

    Example:
        >>> batch = torch.randn(32, 336, 50)
        >>> sens = compute_global_predictive_sensitivity(model, batch)
        >>> import pandas as pd
        >>> pd.DataFrame(sens).sort_values("Global_Sensitivity", ascending=False).head(10)
    """
    if batch.dim() == 2:
        batch = batch.unsqueeze(0)
    if batch.size(0) < 1:
        raise ValueError("Batch must contain at least one sample")

    # Prepare input
    batch = to_model_device_and_dtype(batch, model)
    batch = batch.detach().clone().requires_grad_(True)

    # Full forward pass
    forecast = model(batch)  # ŷ [B, horizon, out_dim]

    # Backpropagate unit gradients from forecast
    grad_outputs = torch.ones_like(forecast)
    grads_tuple = torch.autograd.grad(
        outputs=forecast,
        inputs=batch,
        grad_outputs=grad_outputs,
        retain_graph=False,
        create_graph=False,
        allow_unused=True,
    )

    if not grads_tuple or grads_tuple[0] is None:
        raise RuntimeError("No gradient flow from forecast to inputs")

    grads: Tensor = grads_tuple[0]  # [B, total_length, total_features]

    # L2 norm per feature, averaged over batch & time
    per_feature_l2 = torch.sqrt((grads**2).mean(dim=(0, 1)))  # [total_features]

    # Map features to groups and optionally names
    id_to_group = {}
    id_to_name: dict[int, str | int] = {}
    current_idx = 0

    for group_idx, group in enumerate(model.groups):  # type: ignore[arg-type]
        g_name = group.get("name", f"Group_{group_idx}")
        g_size = group.get("size", 0)  # assuming 'size' is num_features in group

        # Past and fut features are concatenated in input x?
        # Assuming: input x = [past_all_groups, future_all_groups]
        # So we need to map past + fut separately if names differ
        # But for simplicity, assume group['size'] = past + fut for that group
        # Adjust if your input layout is different

        past_names = group.get("past_feature_names", []) if use_feature_names else []
        future_names = group.get("future_feature_names", []) if use_feature_names else []
        all_names = past_names + future_names  # assuming concat order

        for i in range(g_size):
            feat_id = current_idx + i
            id_to_group[feat_id] = g_name
            id_to_name[feat_id] = all_names[i] if i < len(all_names) and isinstance(all_names[i], str) else feat_id

        current_idx += g_size

    # Build records
    records: list[GlobalSensitivityRecord] = []
    for f_idx, s_val in enumerate(per_feature_l2):
        records.append(
            {
                "Group": id_to_group.get(f_idx, "unassigned"),
                "Feature": id_to_name.get(f_idx, f_idx) if use_feature_names else f_idx,
                "Global_Sensitivity": s_val.item(),
            },
        )

    return records


def compute_gate_sensitivity_correlation(
    gating_records: list[FeatureImportanceRecord],
    sensitivity_records: list[SensitivityRecord],
    sensitivity_col: str = "Sensitivity",  # or "Normalized_Sensitivity"
) -> pd.DataFrame:
    """Compute Pearson & Spearman correlation between gate importance and sensitivity.

    Returns correlations overall + per (Group, Branch).

    Args:
        gating_records: From extract_feature_importances(...)
        sensitivity_records: From compute_feature_sensitivity(...)
        sensitivity_col: Which sensitivity column to use

    Returns:
        DataFrame with correlation stats
    """
    df_gate = pd.DataFrame(gating_records)[["Group", "Branch", "Feature", "Importance"]]
    df_sens = pd.DataFrame(sensitivity_records)[["Group", "Branch", "Feature", sensitivity_col]]

    # Merge (inner join - only features present in both)
    merged = df_gate.merge(df_sens, on=["Group", "Branch", "Feature"], how="inner")

    correlations = []

    # Overall
    if len(merged) >= 2:
        p_r, p_p = pearsonr(merged["Importance"], merged[sensitivity_col])
        s_r, s_p = spearmanr(merged["Importance"], merged[sensitivity_col])
        correlations.append(
            {
                "Scope": "Overall",
                "Pearson_r": p_r,
                "Pearson_p-value": p_p,
                "Spearman_rho": s_r,
                "Spearman_p-value": s_p,
                "n_pairs": len(merged),
            },
        )

    # Per Group-Branch
    for (group, branch), subdf in merged.groupby(["Group", "Branch"]):
        if len(subdf) >= 2:
            p_r, p_p = pearsonr(subdf["Importance"], subdf[sensitivity_col])
            s_r, s_p = spearmanr(subdf["Importance"], subdf[sensitivity_col])
            correlations.append(
                {
                    "Scope": f"{group}-{branch}",
                    "Pearson_r": p_r,
                    "Pearson_p-value": p_p,
                    "Spearman_rho": s_r,
                    "Spearman_p-value": s_p,
                    "n_pairs": len(subdf),
                },
            )

    return pd.DataFrame(correlations)
