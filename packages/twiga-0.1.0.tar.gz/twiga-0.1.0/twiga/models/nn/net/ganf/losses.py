from __future__ import annotations

"""Loss and penalty functions for MLPGAF model training.

Provides regularization penalties for:
- Lasso/L1 sparsity on feature gates
- Orthogonality between group contributions
"""

from collections.abc import Callable
from typing import Any

import torch
import torch.nn.functional as F


def get_warmup_scale(epoch: int | None, warmup_epochs: int, power: float = -2.0) -> float:
    """Compute warmup scale factor based on current epoch.

    Args:
        epoch: Current epoch (0-based)
        warmup_epochs: Number of warmup epochs
        power: Exponent for warmup curve (default=2.0 for quadratic)

    Returns:
        Scale factor in [0, 1]
    """
    if epoch is None or warmup_epochs <= 0 or epoch >= warmup_epochs:
        return 1.0

    progress = min(max(epoch / warmup_epochs, 0.0), 1.0)
    if power <= 0:
        return 0.5 * (1 - torch.cos(torch.tensor(progress * 3.141592653589793))).item()
    return progress**power


def gate_penalty(gates: torch.Tensor, delta: float = 0.05) -> torch.Tensor:
    """Smooth L1 (Huber-like) penalty.

    This penalty encourages sparsity (making most things 0 and keeping only the essentials at 1)

    Args:
        gates: Tensor of gate values (typically after sigmoid, expected in [0, 1])
        delta: Threshold where behavior changes from quadratic → linear (small positive)

    Returns:
        Scalar tensor containing sum of penalties across all elements
    """
    return torch.where(gates < delta, 0.5 * gates**2 / delta, torch.abs(gates) - 0.5 * delta).sum()


def compute_gate_penalty(
    group_modules: torch.nn.ModuleList,
    gate_compute_fn: Callable[..., Any],
    lambda_gate: float = 1.0,
    warmup_epochs: int = 10,
    delta: float = 0.05,
    epoch: int | None = None,
) -> torch.Tensor:
    """Compute adaptive sparsity penalty on gate activations using Smooth-L1 (Huber).

    A quadratic warmup schedule is applied **only to the gate penalty** during the
    first `warmup_epochs` to allow gates to stabilize before strong sparsity pressure.

    Args:
        group_modules: Modules containing gate tensors
        gate_compute_fn: Function mapping gate logits → [0, 1]
        lambda_gate: Base strength of gate sparsity penalty
        warmup_epochs: Number of epochs for quadratic warmup
        delta: Smooth-L1 transition point
        epoch: Current epoch (0-based). If None → no warmup

    Returns:
        Gate sparsity penalty (scalar tensor)
    """
    device = next(group_modules.parameters()).device
    total_gate_penalty = torch.zeros((), device=device)

    scale = get_warmup_scale(epoch, warmup_epochs)

    for branch in group_modules:
        for gate_attr in ("fut_feature_gate", "past_feature_gate"):
            if hasattr(branch, gate_attr):
                gates = gate_compute_fn(getattr(branch, gate_attr))
                total_gate_penalty += gate_penalty(gates, delta)

    return lambda_gate * scale * total_gate_penalty


def compute_weight_penalty(
    group_modules: torch.nn.ModuleList,
    lambda_weight: float = 1.0,
    warmup_epochs: int = 10,
    epoch: int | None = None,
    eps: float = 1e-6,
) -> torch.Tensor:
    """Compute adaptive sparsity penalty on projection weight.

    A quadratic warmup schedule is applied  during the
    first `warmup_epochs` to allow gates to stabilize before strong sparsity pressure.

    Args:
        group_modules: Modules containing gate tensors
        lambda_weight: Base strength of gate sparsity penalty
        warmup_epochs: Number of epochs for quadratic warmup
        delta: Smooth-L1 transition point
        epoch: Current epoch (0-based). If None → no warmup
        eps: small constant to avoid sqrt(0)

    Returns:
        Gate sparsity penalty (scalar tensor)
    """
    device = next(group_modules.parameters()).device
    total_weight_penalty = torch.zeros((), device=device)

    scale = get_warmup_scale(epoch, warmup_epochs)

    for branch in group_modules:
        for gate_attr in ("fut_proj", "past_proj"):
            if hasattr(branch, gate_attr):
                weight = getattr(branch, gate_attr).weight
                group_lasso = torch.sqrt(torch.sum(weight**2) / weight.numel() + eps)
                total_weight_penalty += group_lasso

    return lambda_weight * scale * total_weight_penalty


def compute_sigma_loss(
    residual: torch.Tensor,
    scale: torch.Tensor,
    lambda_sigma: float,
    epoch: int,
    warmup_epochs: int,
    sigma_type: str = "Residual",
    eps: float = 1e-6,
) -> torch.Tensor:
    """Compute Huber loss between residual, weighted by sigma.

    Args:
        residual: Residual tensor
        scale:scale
        lambda_sigma: Base strength of sigma loss
        epoch: Current epoch (0-based)
        warmup_epochs: Number of epochs for quadratic warmup
        sigma_type: Type of sigma loss ("Gauss" or "Residual")
        eps: small constant to avoid numerical issues

    Returns:
        Scalar tensor representing the sigma loss
    """
    warm_up_schedules = get_warmup_scale(epoch, warmup_epochs)
    if sigma_type == "Gaussian":
        variance = scale.pow(2)
        loss = F.gaussian_nll_loss(input=torch.zeros_like(residual), target=residual, var=variance, reduction="mean")
    elif sigma_type == "Laplace":
        loss = (scale.log() + (residual / scale)).mean()
    else:
        loss = F.mse_loss(scale, residual, reduction="mean")
    return lambda_sigma * warm_up_schedules * loss
