"""Factory for per-feature-group encoder branches used in MLPGAFNetwork.

Provides :func:`build_group_modules`, which constructs one ``nn.Module``
branch per feature group, each containing optional past/future
:class:`~twiga.models.nn.core.linear_layer.MLPEncoder` instances together
with their learned projection and gate parameters.
"""

from __future__ import annotations

import torch
from torch import nn

from twiga.models.nn.core.linear import MLPEncoder

from .gates import initialise_gate


def build_group_modules(
    groups: list[dict],
    forecast_horizon: int,
    lookback_window_size: int,
    activation: type[nn.Module],
    gate_scale: float,
    embedding_size: int,
    value_embed_type: str | None,
    embedding_type: str | None,
    latent_size: int,
    hidden_dim: int,
    width_multiplier: float,
    num_layers: int,
    num_target_feature: int,
    dropout: float,
    use_norm: bool,
    use_bias: bool,
    use_residual: bool,
    use_revin: bool,
    use_temporal_mixer: bool,
    patch_len: int | None,
    stride: int | None,
) -> nn.ModuleList:
    """Instantiate encoder and projection modules for each feature group.

    Creates a ``nn.ModuleList`` where each element is a branch module
    containing optional past/future encoders and projections.  Each group
    gets independent encoder instances to learn group-specific temporal
    patterns.

    Args:
        groups (list[dict]): Feature group metadata produced by
            :func:`~twiga.core.data.processing.define_feature_groups`.
            Each dict must contain ``"size"``, ``"has_past"``,
            ``"has_future"``, and ``"name"`` keys.
        forecast_horizon (int): Number of future time steps to forecast.
            Used as ``context_size`` for future encoders and to compute
            ``output_dim``.
        lookback_window_size (int): Input context length in time steps.
            Used as ``context_size`` for past encoders.
        activation (type[nn.Module]): Activation class (e.g. ``nn.SiLU``).
            Called once per encoder to produce independent instances, avoiding
            shared-module registration across branches.
        gate_scale (float): Temperature multiplier forwarded to
            :func:`~twiga.models.nn.ganf.gates.initialise_gate` for
            gate logit initialisation.
        embedding_size (int): Dimensionality for value embeddings.
        value_embed_type (str | None): Type of value embedding
            (``'ConvEmb'``, ``'LinearEmb'``, or ``None``).
        embedding_type (str | None): Type of positional embedding
            (``'PosEmb'``, ``'RotaryEmb'``, or ``None``).
        latent_size (int): Latent output dimension of each encoder
            (feeds the projection layer).
        hidden_dim (int): Width of hidden layers inside encoder MLPs.
        width_multiplier (float): Expansion factor for hidden layer widths.
        num_layers (int): Number of MLP layers in encoders.
        num_target_feature (int): Number of target features.  Used to
            compute ``output_dim = num_target_feature * forecast_horizon``.
        dropout (float): Dropout probability in encoders.
        use_norm (bool): Whether to use LayerNorm in encoders.
        use_bias (bool): Whether to use bias terms in encoder layers.
        use_residual (bool): Whether to use residual connections in encoders.
        use_revin (bool): Whether to apply reversible instance normalisation.
        use_temporal_mixer (bool): Whether to include a temporal mixing layer.
        patch_len (int | None): Patch window length for ``PatchEmbedding``.
        stride (int | None): Stride between patches for ``PatchEmbedding``.

    Returns:
        nn.ModuleList: One branch per feature group.  Each branch contains:

        - ``past_enc`` (MLPEncoder, optional): Encodes past features.
        - ``past_proj`` (nn.Linear, optional): Projects encoder output to
          forecasts.
        - ``past_feature_gate`` (nn.Parameter): Gate logits for past
          features, shape ``(group_size,)``.
        - ``past_gate_bias`` (nn.Parameter): Learnable gate bias,
          shape ``(1,)``.
        - ``fut_enc`` (MLPEncoder, optional): Encodes future covariates.
        - ``fut_proj`` (nn.Linear, optional): Projects encoder output to
          forecasts.
        - ``fut_feature_gate`` (nn.Parameter): Gate logits for future
          features, shape ``(group_size,)``.
        - ``fut_gate_bias`` (nn.Parameter): Learnable gate bias,
          shape ``(1,)``.

    Note:
        - Groups without a past encoder will only have a future encoder
          (and vice versa).
        - Output dimension is always ``num_target_feature * forecast_horizon``.
        - Projection layers have no bias (the shared bias is learned in the
          parent ``MLPGAFNetwork``).
    """
    group_modules = nn.ModuleList()
    output_dim = num_target_feature * forecast_horizon

    for group in groups:
        branch = nn.Module()
        num_channels = group["size"]

        if group["has_past"]:
            branch.past_enc = MLPEncoder(
                embedding_size=embedding_size,
                value_embed_type=value_embed_type,
                pos_embed_type=embedding_type,
                latent_size=latent_size,
                hidden_dim=hidden_dim,
                width_multiplier=width_multiplier,
                num_layers=num_layers,
                context_size=lookback_window_size,
                activation=activation(),
                dropout=dropout,
                num_channels=num_channels,
                use_bias=use_bias,
                use_norm=use_norm,
                use_residual=use_residual,
                use_revin=use_revin,
                use_temporal_mixer=use_temporal_mixer,
                patch_len=patch_len,
                stride=stride,
            )
            branch.past_proj = nn.Linear(latent_size, output_dim, bias=False)
            branch.past_feature_gate = nn.Parameter(initialise_gate(num_channels, gate_scale))
            branch.past_gate_bias = nn.Parameter(torch.zeros(1))

        if group["has_future"]:
            branch.fut_enc = MLPEncoder(
                embedding_size=embedding_size,
                value_embed_type=value_embed_type,
                pos_embed_type=embedding_type,
                latent_size=latent_size,
                hidden_dim=hidden_dim,
                width_multiplier=width_multiplier,
                num_layers=num_layers,
                context_size=forecast_horizon,
                activation=activation(),
                dropout=dropout,
                num_channels=num_channels,
                use_bias=use_bias,
                use_norm=use_norm,
                use_residual=use_residual,
                use_revin=use_revin,
                use_temporal_mixer=use_temporal_mixer,
                patch_len=patch_len,
                stride=stride,
            )
            branch.fut_proj = nn.Linear(latent_size, output_dim, bias=False)
            branch.fut_feature_gate = nn.Parameter(initialise_gate(num_channels, gate_scale))
            branch.fut_gate_bias = nn.Parameter(torch.zeros(1))

        group_modules.append(branch)

    return group_modules
