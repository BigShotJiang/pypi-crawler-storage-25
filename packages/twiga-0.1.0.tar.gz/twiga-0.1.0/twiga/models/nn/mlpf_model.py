"""MLPF model configuration and experiment wrapper.

Provides :class:`MLPFConfig` for parameter validation and hyperparameter
search space definition, and :class:`MLPFModel` for training lifecycle
management via :class:`~twiga.models.nn.core.base.BaseNeuralForecast`.
"""

from __future__ import annotations

from typing import Literal

import optuna
import torch

from twiga.core.config import BaseSearchSpace
from twiga.core.config.neural import BaseMLPConfig, Field
from twiga.core.utils.logger import get_logger
from twiga.models.nn.core.base import BaseNeuralForecast
from twiga.models.nn.net.mlpf import MLPF

log = get_logger(__name__)


class MLPFConfig(BaseMLPConfig):
    """Configuration for the MLPF (Multi-Layer Perceptron Fusion) forecasting model.

    Extends the shared MLP base configuration with fusion-specific parameters for
    combining past and future representations (attention, weighted sum, or addition).

    Supports patch-based value embedding as an additional option compared to the
    base MLP configurations.

    Attributes:
        name: Fixed model identifier ("mlpf")
        combination_type: Strategy for fusing encoded past and future features
        num_attention_heads: Number of attention heads (used when combination_type = "attn-comb")
        patch_len: Length of each patch when using PatchEmb value embedding
        stride: Step size between consecutive patches (when patch_len is set)
        search_space: Hyperparameter ranges for Optuna HPO, extending the base MLP space
    """

    name: Literal["mlpf"] = Field(  # type: ignore[assignment]
        default="mlpf",
        alias="model_name",
        exclude=True,
        description="Fixed model identifier",
    )

    distribution: Literal["normal", "laplace", "lognormal", "gamma", "beta", "qr", "fpqr", "crc"] | None = Field(
        default=None,
        exclude=True,
        description=(
            "Output distribution type. When set, TwigaForecaster automatically resolves this config "
            "to the corresponding probabilistic variant (e.g. 'normal' → MLPFNormalConfig). "
            "Valid options: normal, laplace, lognormal, gamma, beta, qr, fpqr, crc."
        ),
    )

    # Fusion mechanism
    combination_type: Literal["attn-comb", "weighted-comb", "addition-comb"] = Field(
        "addition-comb",
        description="How past and future encoded representations are combined",
    )
    num_attention_heads: int = Field(4, description="Number of attention heads when using attention-based fusion")

    # Optional patching
    patch_len: int | None = Field(None, description="Patch length for PatchEmb value embedding (required when used)")
    stride: int | None = Field(None, description="Stride between patches for PatchEmb (required when used)")

    # HPO search space
    search_space: BaseSearchSpace = Field(
        default_factory=lambda: BaseSearchSpace(
            **(
                BaseMLPConfig.base_mlp_search
                | {
                    "combination_type": ["weighted-comb", "addition-comb"],
                }
            ),
        ),
        description="Hyperparameter search space for Optuna tuning",
        exclude=True,
    )


class MLPFModel(BaseNeuralForecast):
    """Training lifecycle wrapper for :class:`MLPFNetwork`.

    Instantiates :class:`~twiga.models.nn.net.mlpf.MLPFModel` from an
    :class:`MLPFConfig`, manages training via PyTorch Lightning, and
    supports Optuna hyperparameter optimisation.

    Example:
        >>> config = MLPFConfig(
        ...     num_target_feature=1,
        ...     num_historical_features=5,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ... )
        >>> model = MLPFModel(model_config=config)
    """

    def __init__(self, model_config: MLPFConfig) -> None:
        """Initialise with a validated :class:`MLPFConfig`.

        Args:
            model_config: Full model configuration.
        """
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        """Instantiate :class:`MLPFModel` from the current config."""
        cfg = self.model_config
        self.model = MLPF(
            # Feature counts
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            # Sequence dimensions
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            # Embedding
            embedding_size=cfg.embedding_size,
            embedding_type=cfg.embedding_type,
            value_embed_type=cfg.value_embed_type,
            # Combination
            combination_type=cfg.combination_type,
            num_attention_heads=cfg.num_attention_heads,
            # Architecture flags
            use_norm=cfg.use_norm,
            use_bias=cfg.use_bias,
            use_residual=cfg.use_residual,
            use_temporal_mixer=cfg.use_temporal_mixer,
            # Encoder dimensions
            latent_size=cfg.latent_size,
            hidden_dim=cfg.hidden_dim,
            width_multiplier=cfg.width_multiplier,
            num_layers=cfg.num_layers,
            # Patch embedding
            patch_len=cfg.patch_len,
            stride=cfg.stride,
            # Activation
            activation_function=cfg.activation_function,
            out_activation_function=cfg.out_activation_function,
            # Regularisation
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            # Training
            metric=cfg.metric,
            optimizer_type=cfg.optimizer_type,
            optimizer_params=cfg.optimizer_params,
            lr_scheduler_type=cfg.lr_scheduler_type,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        """Re-initialise model with Optuna-suggested hyperparameters.

        Args:
            trial: Optuna trial providing parameter suggestions via the
                search space defined in :attr:`MLPFConfig.search_space`.
        """
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = MLPFConfig(**params)
        self.batch_size = self.model_config.batch_size
        self.max_epochs = self.model_config.max_epochs
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        """Load the latest checkpoint and set model to eval mode."""
        self._load_checkpoints(model_instance=MLPF)  # type: ignore[arg-type]
        self.model.eval()
