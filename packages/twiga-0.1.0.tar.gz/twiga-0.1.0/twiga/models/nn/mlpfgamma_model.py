"""MLPF Gamma model configuration and experiment wrapper."""

from __future__ import annotations

from typing import Literal

import optuna
import torch

from twiga.core.config import BaseSearchSpace, Field
from twiga.models.nn.core.base import BaseNeuralForecast
from twiga.models.nn.mlpf_model import MLPFConfig
from twiga.models.nn.prob.mlpf_parametric import MLPFGamma


class MLPFGammaConfig(MLPFConfig):
    """Configuration for Gamma-distribution probabilistic MLPF.

    Best for: strictly positive targets with flexible skew - solar irradiance,
    wind power, aggregate load.

    Note:
        Targets must be strictly positive. GammaDistribution does not accept
        an ``out_activation_function`` - both shape parameters are constrained
        internally via softplus.

    Attributes:
        name: Fixed model identifier.
        out_activation_function: Fixed to Identity (not used by Gamma head).
        search_space: Optuna hyperparameter search space.
    """

    name: Literal["mlpfgamma"] = Field(  # type: ignore[assignment]
        default="mlpfgamma",
        description="Fixed model identifier.",
        alias="model_name",
        exclude=True,
    )

    # GammaDistribution does not accept out_activation_function - lock it out.
    out_activation_function: Literal["Identity"] = Field(
        "Identity",
        description="Not used by GammaDistribution. Fixed to Identity.",
    )

    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            latent_size=[64, 128, 256],
            hidden_dim=[64, 128, 256, 512],
            num_layers=(2, 5),
            width_multiplier=[0.5, 1.0, 1.5, 2.0, 3.0],
            embedding_size=[8, 16, 28, 32],
            value_embed_type=[None, "LinearEmb", "ConvEmb"],
            embedding_type=[None, "PosEmb", "LearnPosEmb"],
            combination_type=["attn-comb", "weighted-comb", "addition-comb"],
            dropout=(0.05, 0.35),
            alpha=(0.05, 0.4),
            use_norm=[False, True],
            use_bias=[True],
            use_residual=[False, True],
            activation_function=["SiLU", "ELU", "LeakyReLU"],
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


class MLPFGammaModel(BaseNeuralForecast):
    """Training lifecycle wrapper for Gamma-distribution probabilistic MLPF.

    Example:
        >>> config = MLPFGammaConfig(
        ...     num_target_feature=1,
        ...     num_historical_features=5,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ... )
        >>> model = MLPFGammaModel(model_config=config)
    """

    def __init__(self, model_config: MLPFGammaConfig) -> None:
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        cfg = self.model_config
        self.model = MLPFGamma(  # type: ignore[call-arg]
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            embedding_size=cfg.embedding_size,
            embedding_type=cfg.embedding_type,
            value_embed_type=cfg.value_embed_type,
            combination_type=cfg.combination_type,
            num_attention_heads=cfg.num_attention_heads,
            use_norm=cfg.use_norm,
            use_bias=cfg.use_bias,
            use_residual=cfg.use_residual,
            use_temporal_mixer=cfg.use_temporal_mixer,
            latent_size=cfg.latent_size,
            hidden_dim=cfg.hidden_dim,
            width_multiplier=cfg.width_multiplier,
            num_layers=cfg.num_layers,
            patch_len=cfg.patch_len,
            stride=cfg.stride,
            activation_function=cfg.activation_function,
            out_activation_function=cfg.out_activation_function,
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            metric=cfg.metric,
            optimizer_params=cfg.optimizer_params,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = MLPFGammaConfig(**params)
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        self._load_checkpoints(model_instance=MLPFGamma)  # type: ignore[arg-type]
        self.model.eval()
