"""RNN model configuration and experiment wrapper."""

from __future__ import annotations

from typing import Literal

import optuna
import torch

from twiga.core.config import BaseSearchSpace
from twiga.core.config.neural import BaseMLPConfig, Field
from twiga.core.utils.logger import get_logger
from twiga.models.nn.core.base import BaseNeuralForecast
from twiga.models.nn.net.rnn import RNN

log = get_logger(__name__)


class RNNConfig(BaseMLPConfig):
    """Configuration for the RNN forecasting model.

    Extends :class:`BaseMLPConfig` with RNN-specific parameters:
    hidden state width, number of stacked layers, cell type (GRU/LSTM),
    and bidirectionality.

    The three sequence-dimension fields (``num_target_feature``,
    ``forecast_horizon``, ``lookback_window_size``) default to 0 and are
    auto-populated from ``DataPipelineConfig`` when passed to
    ``TwigaForecaster``.

    Attributes:
        name: Fixed model identifier ``"rnn"``.
        hidden_size: Width of the RNN hidden state.
        n_layers: Number of stacked RNN layers.
        cell_type: RNN cell type — ``"gru"`` or ``"lstm"``.
        bidirectional: Whether to use a bidirectional RNN.
        search_space: Optuna hyperparameter search space.

    Examples:
        >>> config = RNNConfig(
        ...     num_target_feature=1,
        ...     num_historical_features=5,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ... )
        >>> model = RNNModel(model_config=config)
    """

    name: Literal["rnn"] = Field(  # type: ignore[assignment]
        default="rnn",
        alias="model_name",
        exclude=True,
        description="Fixed model identifier",
    )

    # RNN-specific architecture fields
    hidden_size: int = Field(128, description="Width of the RNN hidden state")
    n_layers: int = Field(2, description="Number of stacked RNN layers")
    cell_type: Literal["gru", "lstm"] = Field("gru", description="RNN cell type")
    bidirectional: bool = Field(False, description="Use a bidirectional RNN")

    search_space: BaseSearchSpace = Field(
        default_factory=lambda: BaseSearchSpace(
            **(
                BaseMLPConfig.base_mlp_search
                | {
                    "hidden_size": [64, 128, 256, 512],
                    "n_layers": (1, 3),
                    "cell_type": ["gru", "lstm"],
                    "bidirectional": [False, True],
                }
            ),
        ),
        description="Hyperparameter search space for Optuna tuning",
        exclude=True,
    )


class RNNModel(BaseNeuralForecast):
    """Training lifecycle wrapper for :class:`RNNForecastNetwork`.

    Instantiates :class:`~twiga.models.nn.net.rnn.RNN` from an
    :class:`RNNConfig`, manages training via PyTorch Lightning, and
    supports Optuna hyperparameter optimisation.

    Example:
        >>> config = RNNConfig(
        ...     num_target_feature=1,
        ...     num_historical_features=5,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ... )
        >>> model = RNNModel(model_config=config)
    """

    def __init__(self, model_config: RNNConfig) -> None:
        """Initialise with a validated :class:`RNNConfig`.

        Args:
            model_config: Full model configuration.
        """
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        """Instantiate :class:`RNN` from the current config."""
        cfg = self.model_config
        self.model = RNN(
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            hidden_size=cfg.hidden_size,
            n_layers=cfg.n_layers,
            cell_type=cfg.cell_type,
            bidirectional=cfg.bidirectional,
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            out_activation_function=cfg.out_activation_function,
            metric=cfg.metric,
            optimizer_type=cfg.optimizer_type,
            optimizer_params=cfg.optimizer_params,
            lr_scheduler_type=cfg.lr_scheduler_type,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        """Re-initialise model with Optuna-suggested hyperparameters.

        Args:
            trial: Optuna trial providing parameter suggestions via the
                search space defined in :attr:`RNNConfig.search_space`.
        """
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = RNNConfig(**params)
        self.batch_size = self.model_config.batch_size
        self.max_epochs = self.model_config.max_epochs
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        """Load the latest checkpoint and set model to eval mode."""
        self._load_checkpoints(model_instance=RNN)  # type: ignore[arg-type]
        self.model.eval()
