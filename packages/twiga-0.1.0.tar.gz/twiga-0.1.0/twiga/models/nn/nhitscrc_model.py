"""NHiTS CRC model configuration and experiment wrapper."""

from __future__ import annotations

from typing import Literal

import optuna

from twiga.core.config import BaseSearchSpace, Field
from twiga.models.nn.core.base import BaseNeuralForecast
from twiga.models.nn.net.nhits import ACTIVATIONS, POOLING
from twiga.models.nn.nhits_model import NHITSConfig
from twiga.models.nn.prob.nhits_crc import NHITSCrc


class NHITSCrcConfig(NHITSConfig):
    """Configuration for NHiTS + Conditional Residual Calibration.

    Pairs the NHiTS backbone with a CRC uncertainty head that approximates
    absolute residuals. Inherits all NHiTS architecture parameters.

    Attributes:
        name: Fixed model identifier.
        search_space: Optuna hyperparameter search space.
    """

    name: Literal["nhitscrc"] = Field(  # type: ignore[assignment]
        default="nhitscrc",
        description="Fixed model identifier.",
        alias="model_name",
        exclude=True,
    )

    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            dropout=(0.1, 0.5),
            alpha=(0.01, 0.5),
            activation_function=ACTIVATIONS,
            pooling_mode=POOLING,
            encode_size=[64, 128, 256, 512],
            mlp_units=[3 * [[64, 64]], 3 * [[128, 128]], 3 * [[256, 256]], 3 * [[512, 512]]],
            n_pool_kernel_size=[[2, 2, 1], 3 * [1], 3 * [2], [8, 4, 1]],
            n_freq_downsample=[[168, 24, 1], [24, 12, 1], [60, 8, 1], [1, 1, 1]],
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


class NHITSCrcModel(BaseNeuralForecast):
    """Training lifecycle wrapper for NHiTS + CRC.

    Example:
        >>> config = NHITSCrcConfig(
        ...     num_target_feature=1,
        ...     num_historical_features=5,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ... )
        >>> model = NHITSCrcModel(model_config=config)
    """

    def __init__(self, model_config: NHITSCrcConfig) -> None:
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        cfg = self.model_config
        self.model = NHITSCrc(
            # Feature counts
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            # Sequence dimensions
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            # Architecture
            activation_function=cfg.activation_function,
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            stack_types=cfg.stack_types,
            n_blocks=cfg.n_blocks,
            mlp_units=cfg.mlp_units,
            n_pool_kernel_size=cfg.n_pool_kernel_size,
            n_freq_downsample=cfg.n_freq_downsample,
            pooling_mode=cfg.pooling_mode,
            interpolation_mode=cfg.interpolation_mode,
            encode_size=cfg.encode_size,
            crc_alpha=cfg.alpha,
            # Training
            metric=cfg.metric,
            optimizer_type=cfg.optimizer_type,
            lr_scheduler_type=cfg.lr_scheduler_type,
            optimizer_params=cfg.optimizer_params,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = NHITSCrcConfig(**params)
        self.batch_size = self.model_config.batch_size
        self.max_epochs = self.model_config.max_epochs
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        self._load_checkpoints(model_instance=NHITSCrc)  # type: ignore[arg-type]
        self.model.eval()
