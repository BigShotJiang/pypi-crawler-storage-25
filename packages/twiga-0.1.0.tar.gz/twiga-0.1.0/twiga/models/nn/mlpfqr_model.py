"""MLPFQR and MLPFFPQR model configurations and experiment wrappers.

Provides:
    - :class:`MLPFQRConfig`  / :class:`MLPFQRModel`  - fixed-grid quantile regression
    - :class:`MLPFPQRConfig` / :class:`MLPFPQRModel` - flexible quantile proposal (FPQR)

Both configs extend :class:`MLPFConfig` and inherit all encoder/embedding parameters.
"""

from __future__ import annotations

from typing import Literal

import optuna
import torch

from twiga.core.config import BaseSearchSpace, Field
from twiga.models.nn.core.base import BaseNeuralForecast
from twiga.models.nn.mlpf_model import MLPFConfig
from twiga.models.nn.prob.mlpffpqr import MLPFFPQR
from twiga.models.nn.prob.mlpfqr import MLPFQR

# ── MLPFQRConfig ──────────────────────────────────────────────────────────────


class MLPFQRConfig(MLPFConfig):
    """Configuration for the MLPFQR fixed-grid quantile forecasting model.

    Extends :class:`MLPFConfig` with quantile regression parameters. The encoder
    architecture (latent_size, hidden_dim, width_multiplier, use_norm, etc.) is
    fully inherited and tunable.

    Attributes:
        name: Fixed model identifier.
        quantiles: Explicit quantile levels to forecast. If None, defaults inside
            QRDistribution apply.
        conf_level: Confidence level for symmetric interval construction.
        loss_fn: Pinball or Huber-pinball quantile loss.
        kappa: Huber transition parameter (only relevant for 'huber-pinball').
        eps: Numerical stability epsilon.
        search_space: Optuna hyperparameter search space.
    """

    name: Literal["mlpfqr"] = Field(  # type: ignore[assignment]
        default="mlpfqr",
        description="Fixed model identifier.",
        alias="model_name",
        exclude=True,
    )

    # ── Quantile-specific ─────────────────────────────────────────────────────
    quantiles: list[float] | None = Field(None, description="Explicit quantile levels to forecast.")
    conf_level: float = Field(0.05, description="Confidence level for quantile bounds.")
    loss_fn: Literal["pinball", "huber-pinball"] = Field("pinball", description="Quantile loss function.")
    kappa: float = Field(0.25, description="Huber transition parameter.")
    eps: float = Field(1e-6, description="Epsilon for numerical stability.")

    # ── Search space ──────────────────────────────────────────────────────────
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            # ── Encoder capacity ───────────────────────────────────────────
            latent_size=[64, 128, 256],
            hidden_dim=[64, 128, 256],
            num_layers=(2, 4),
            width_multiplier=[1.0, 1.5, 2.0, 3.0],
            # ── Value embedding ────────────────────────────────────────────
            embedding_size=[8, 16, 28, 32],
            value_embed_type=[None, "LinearEmb", "ConvEmb"],
            # ── Positional embedding ───────────────────────────────────────
            embedding_type=[None, "PosEmb", "LearnPosEmb"],
            # ── Combination ────────────────────────────────────────────────
            combination_type=["attn-comb", "weighted-comb", "addition-comb"],
            # ── Regularisation ─────────────────────────────────────────────
            dropout=(0.05, 0.35),
            alpha=(0.05, 0.4),
            # ── Architecture flags ─────────────────────────────────────────
            use_norm=[False, True],
            use_bias=[True],
            use_residual=[False, True],
            # ── Activation ─────────────────────────────────────────────────
            activation_function=["SiLU", "ELU", "LeakyReLU"],
            out_activation_function=["Identity", "Tanh"],
            # ── Quantile ───────────────────────────────────────────────────
            kappa=(0.01, 1.0),
            loss_fn=["pinball", "huber-pinball"],
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


# ── MLPFQRModel ───────────────────────────────────────────────────────────────


class MLPFQRModel(BaseNeuralForecast):
    """Training lifecycle wrapper for fixed-grid quantile regression (:class:`MLPFQR`).

    Instantiates :class:`~twiga.models.nn.prob.mlpfqr.MLPFQR` from an
    :class:`MLPFQRConfig`, manages training via PyTorch Lightning, and
    supports Optuna hyperparameter optimisation.

    Example:
        >>> config = MLPFQRConfig(
        ...     num_target_feature=1,
        ...     num_historical_features=5,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ...     quantiles=[0.1, 0.5, 0.9],
        ... )
        >>> model = MLPFQRModel(model_config=config)
    """

    def __init__(self, model_config: MLPFQRConfig) -> None:
        """Initialise with a validated :class:`MLPFQRConfig`.

        Args:
            model_config: Full model configuration.
        """
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        """Instantiate :class:`MLPFQR` from the current config."""
        cfg = self.model_config
        self.model = MLPFQR(
            # Feature counts
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            # Sequence dimensions
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            # Embedding
            embedding_size=cfg.embedding_size,
            embedding_type=cfg.embedding_type,
            value_embed_type=cfg.value_embed_type,
            # Combination
            combination_type=cfg.combination_type,
            num_attention_heads=cfg.num_attention_heads,
            # Architecture flags
            use_norm=cfg.use_norm,
            use_bias=cfg.use_bias,
            use_residual=cfg.use_residual,
            use_temporal_mixer=cfg.use_temporal_mixer,
            # Encoder dimensions
            latent_size=cfg.latent_size,
            hidden_dim=cfg.hidden_dim,
            width_multiplier=cfg.width_multiplier,
            num_layers=cfg.num_layers,
            # Patch embedding
            patch_len=cfg.patch_len,
            stride=cfg.stride,
            # Activation
            activation_function=cfg.activation_function,
            out_activation_function=cfg.out_activation_function,
            # Regularisation
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            # Quantile
            quantiles=cfg.quantiles,
            conf_level=cfg.conf_level,
            loss_fn=cfg.loss_fn,
            kappa=cfg.kappa,
            eps=cfg.eps,
            # Training
            metric=cfg.metric,
            optimizer_params=cfg.optimizer_params,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        """Re-initialise model with Optuna-suggested hyperparameters.

        Args:
            trial: Optuna trial providing parameter suggestions via the
                search space defined in :attr:`MLPFQRConfig.search_space`.
        """
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = MLPFQRConfig(**params)
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        """Load the latest checkpoint and set model to eval mode."""
        self._load_checkpoints(model_instance=MLPFQR)  # type: ignore[arg-type]
        self.model.eval()


# ── MLPFPQRConfig ─────────────────────────────────────────────────────────────


class MLPFPQRConfig(MLPFConfig):
    """Configuration for the MLPFFPQR flexible quantile proposal forecasting model.

    Extends :class:`MLPFConfig` with FPQR-specific parameters. Unlike
    :class:`MLPFQRConfig`, this model adaptively proposes its own quantile grid
    during training via :class:`FPQRDistribution`.

    Attributes:
        name: Fixed model identifier.
        n_quantiles: Number of quantile levels for the proposal network.
        conf_level: Confidence level for interval construction.
        loss_fn: Pinball or Huber-pinball quantile loss.
        kappa: Huber transition parameter.
        num_cosines: Cosine features for the quantile embedding layer.
        search_space: Optuna hyperparameter search space.
    """

    name: Literal["mlpffpqr"] = Field(  # type: ignore[assignment]
        default="mlpffpqr",
        description="Fixed model identifier.",
        alias="model_name",
        exclude=True,
    )

    # ── FPQR-specific ─────────────────────────────────────────────────────────
    n_quantiles: int = Field(9, description="Number of quantile levels for the proposal network.")
    conf_level: float = Field(0.05, description="Confidence level for quantile bounds.")
    loss_fn: Literal["pinball", "huber-pinball"] = Field("pinball", description="Quantile loss function.")
    kappa: float = Field(0.25, description="Huber transition parameter.")
    num_cosines: int = Field(32, description="Cosine features for quantile embedding.")

    # ── Search space ──────────────────────────────────────────────────────────
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            # ── Encoder capacity ───────────────────────────────────────────
            latent_size=[64, 128, 256],
            hidden_dim=[64, 128, 256, 512],
            num_layers=(2, 5),
            width_multiplier=[0.5, 1.0, 1.5, 2.0, 3.0],
            # ── Value embedding ────────────────────────────────────────────
            embedding_size=[8, 16, 28, 32],
            value_embed_type=[None, "LinearEmb", "ConvEmb"],
            # ── Positional embedding ───────────────────────────────────────
            embedding_type=[None, "PosEmb", "LearnPosEmb"],
            # ── Combination ────────────────────────────────────────────────
            combination_type=["attn-comb", "weighted-comb", "addition-comb"],
            # ── Regularisation ─────────────────────────────────────────────
            dropout=(0.05, 0.35),
            alpha=(0.05, 0.4),
            # ── Architecture flags ─────────────────────────────────────────
            use_norm=[False, True],
            use_bias=[True],
            use_residual=[False, True],
            # ── Activation ─────────────────────────────────────────────────
            activation_function=["SiLU", "ELU", "LeakyReLU"],
            out_activation_function=["Identity", "Tanh"],
            # ── FPQR ───────────────────────────────────────────────────────
            n_quantiles=[7, 9, 15, 21],
            kappa=(0.01, 1.0),
            loss_fn=["pinball", "huber-pinball"],
            num_cosines=[16, 32, 64],
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


# ── MLPFPQRModel ──────────────────────────────────────────────────────────────


class MLPFPQRModel(BaseNeuralForecast):
    """Training lifecycle wrapper for flexible quantile proposal regression (:class:`MLPFFPQR`).

    Instantiates :class:`~twiga.models.nn.prob.mlpffpqr.MLPFFPQR` from an
    :class:`MLPFPQRConfig`, manages training via PyTorch Lightning, and
    supports Optuna hyperparameter optimisation.

    Example:
        >>> config = MLPFPQRConfig(
        ...     num_target_feature=1,
        ...     num_historical_features=5,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ...     n_quantiles=9,
        ... )
        >>> model = MLPFPQRModel(model_config=config)
    """

    def __init__(self, model_config: MLPFPQRConfig) -> None:
        """Initialise with a validated :class:`MLPFPQRConfig`.

        Args:
            model_config: Full model configuration.
        """
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        """Instantiate :class:`MLPFFPQR` from the current config."""
        cfg = self.model_config
        self.model = MLPFFPQR(
            # Feature counts
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            # Sequence dimensions
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            # Embedding
            embedding_size=cfg.embedding_size,
            embedding_type=cfg.embedding_type,
            value_embed_type=cfg.value_embed_type,
            # Combination
            combination_type=cfg.combination_type,
            num_attention_heads=cfg.num_attention_heads,
            # Architecture flags
            use_norm=cfg.use_norm,
            use_bias=cfg.use_bias,
            use_residual=cfg.use_residual,
            use_temporal_mixer=cfg.use_temporal_mixer,
            # Encoder dimensions
            latent_size=cfg.latent_size,
            hidden_dim=cfg.hidden_dim,
            width_multiplier=cfg.width_multiplier,
            num_layers=cfg.num_layers,
            # Patch embedding
            patch_len=cfg.patch_len,
            stride=cfg.stride,
            # Activation
            activation_function=cfg.activation_function,
            out_activation_function=cfg.out_activation_function,
            # Regularisation
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            # FPQR
            n_quantiles=cfg.n_quantiles,
            conf_level=cfg.conf_level,
            loss_fn=cfg.loss_fn,
            kappa=cfg.kappa,
            num_cosines=cfg.num_cosines,
            # Training
            metric=cfg.metric,
            optimizer_params=cfg.optimizer_params,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        """Re-initialise model with Optuna-suggested hyperparameters.

        Args:
            trial: Optuna trial providing parameter suggestions via the
                search space defined in :attr:`MLPFPQRConfig.search_space`.
        """
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = MLPFPQRConfig(**params)
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        """Load the latest checkpoint and set model to eval mode."""
        self._load_checkpoints(model_instance=MLPFFPQR)  # type: ignore[arg-type]
        self.model.eval()
