from typing import Literal

import optuna
import torch

from twiga.core.config import BaseMLPConfig, BaseSearchSpace, Field
from twiga.models.nn.core.base import BaseNeuralForecast
from twiga.models.nn.net.nhits import ACTIVATIONS, NHITS, POOLING


class NHITSConfig(BaseMLPConfig):
    """Configuration for NHITS forecasting models.

    Extends `BaseMLPConfig` with parameters specific to the NHITS (Neural Hierarchical
    Interpolation for Time Series) model, which uses stacked blocks for hierarchical
    forecasting. Configures model architecture, training, and hyperparameter tuning.

    The three dimension fields (``num_target_feature``, ``forecast_horizon``,
    ``lookback_window_size``) default to 0 and are auto-populated from
    ``DataPipelineConfig`` when the config is passed to ``TwigaForecaster``.

    Args:
        name (Literal["nhits"], optional): Model type identifier. Fixed to "nhits".
            Defaults to "nhits".
        num_target_feature (int, optional): Number of target features to predict.
            Defaults to 0 (auto-populated by TwigaForecaster).
        num_historical_features (int, optional): Number of historical features.
            Defaults to 0.
        num_calendar_features (int, optional): Number of calendar features.
            Defaults to 0.
        num_exogenous_features (int, optional): Number of exogenous features.
            Defaults to 0.
        num_future_covariates (int, optional): Number of future covariates.
            Defaults to 0.
        forecast_horizon (int, optional): Number of time steps to forecast.
            Defaults to 0 (auto-populated by TwigaForecaster).
        lookback_window_size (int, optional): Size of the input lookback window.
            Defaults to 0 (auto-populated by TwigaForecaster).
        stack_types (list[Literal["identity"]], optional): Types of blocks in each stack
            (e.g., "identity" for standard forecasting). Defaults to ["identity", "identity", "identity"].
        n_blocks (list[int], optional): Number of blocks per stack. Defaults to [1, 1, 1].
        mlp_units (list[list[int]], optional): Number of units in MLP layers per block.
            Defaults to [[512, 512], [512, 512], [512, 512]].
        n_pool_kernel_size (list[int], optional): Pooling kernel sizes per stack.
            Defaults to [2, 2, 1].
        n_freq_downsample (list[int], optional): Frequency downsampling factors per stack.
            Defaults to [4, 2, 1].
        pooling_mode (Literal["MaxPool1d", "AvgPool1d"], optional): Pooling mode for stacks.
            Defaults to "MaxPool1d".
        interpolation_mode (Literal["linear", "nearest", "cubic"], optional): Interpolation
            mode for forecasting. Defaults to "linear".
        decompose_forecast (bool, optional): Decompose forecast into basis components.
            Defaults to False.
        activation_function (Literal[...], optional): Activation function for hidden layers.
            Defaults to "ReLU".
        out_activation_function (str, optional): Activation function for output layer.
            Defaults to "Identity".
        dropout (float, optional): Dropout rate for regularization (0 to 1).
            Defaults to 0.25.
        alpha (float, optional): Alpha parameter for the loss function (0 to 1).
            Defaults to 0.1.
        search_space (BaseSearchSpace, optional): Hyperparameter search space for tuning.
            Defaults to a predefined space.

    Notes:
        Inherits fields from `NeuralModelConfig` (e.g., `optimizer_params`, `max_epochs`).
        The `name` field is fixed and excluded from tuning. NHITS-specific parameters
        (e.g., `n_blocks`, `mlp_units`) configure the stacked block architecture.
    """

    name: Literal["nhits"] = Field(  # type: ignore[assignment]
        default="nhits",
        description="Model type identifier. Fixed to 'nhits' and excluded from tuning.",
        alias="model_name",
        exclude=True,
    )
    stack_types: list[Literal["identity"]] = Field(
        default=["identity", "identity", "identity"],
        description="Types of blocks in each NHITS stack (e.g., 'identity' for standard forecasting).",
    )
    n_blocks: list[int] | None = Field(
        default=[1, 1, 1],
        description="Number of blocks in each NHITS stack.",
    )
    mlp_units: list[list[int]] = Field(
        default=[[512, 512], [512, 512], [512, 512]],
        description="Number of units in MLP layers for each block in each stack.",
    )
    n_pool_kernel_size: list[int] | None = Field(
        default=[2, 2, 1],
        description="Pooling kernel sizes for each NHITS stack.",
    )
    n_freq_downsample: list[int] | None = Field(
        default=[4, 2, 1],
        description="Frequency downsampling factors for each NHITS stack.",
    )
    pooling_mode: Literal["MaxPool1d", "AvgPool1d"] = Field(
        default="MaxPool1d",
        description="Pooling mode for NHITS stacks ('MaxPool1d' or 'AvgPool1d').",
    )
    interpolation_mode: Literal["linear", "nearest", "cubic"] = Field(
        default="linear",
        description="Interpolation mode for forecasting output.",
    )
    decompose_forecast: bool = Field(
        default=False,
        description="Decompose forecast into basis components for interpretability.",
    )
    activation_function: Literal[
        "ReLU",
        "Softplus",
        "Tanh",
        "Sigmoid",
        "SiLU",
        "GELU",
        "ELU",
        "SELU",
        "LeakyReLU",
        "PReLU",
    ] = Field(  # type: ignore[assignment]
        default="ReLU",
        description="Activation function for hidden layers.",
    )
    out_activation_function: str = Field(  # type: ignore[assignment]
        default="Identity",
        description="Activation function for the output layer (e.g., 'Identity', 'ReLU').",
    )
    dropout: float = Field(
        default=0.25,
        description="Dropout rate for regularization, between 0 and 1.",
        ge=0.0,
        le=1.0,
    )
    alpha: float = Field(
        default=0.1,
        description="Alpha parameter for the loss function, between 0 and 1.",
        ge=0.0,
        le=1.0,
    )
    encode_size: int = Field(
        default=256,
        description="Width of the latent vector produced by encode(), used by probabilistic heads.",
        gt=0,
    )
    distribution: str | None = Field(
        default=None,
        description=(
            "Probabilistic distribution variant. When set, TwigaForecaster resolves this config "
            "to the corresponding probabilistic model (e.g. 'normal' → NHITSNormalConfig). "
            "Valid values: 'normal', 'laplace', 'lognormal', 'gamma', 'beta', 'studentt', "
            "'qr', 'fpqr'."
        ),
        exclude=True,
    )
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            dropout=(0.1, 0.9),
            alpha=(0.01, 0.9),
            activation_function=ACTIVATIONS,
            pooling_mode=POOLING,
            encode_size=[64, 128, 256, 512],
            mlp_units=[
                3 * [[16, 16]],
                3 * [[32, 32]],
                3 * [[64, 64]],
                3 * [[128, 128]],
                3 * [[256, 256]],
                3 * [[512, 512]],
            ],
            n_pool_kernel_size=[
                [2, 2, 1],
                3 * [1],
                3 * [2],
                3 * [4],
                [8, 4, 1],
                [16, 8, 1],
            ],
            n_freq_downsample=[[168, 24, 1], [24, 12, 1], [180, 60, 1], [60, 8, 1], [40, 20, 1], [1, 1, 1]],
        ),
        description="Hyperparameter search space for tuning NHITS parameters, including "
        "num_layers, dropout, alpha, activation_function, pooling_mode, "
        "interpolation_mode, mlp_units, n_pool_kernel_size, and n_freq_downsample.",
        exclude=True,
    )


class NHITSModel(BaseNeuralForecast):
    """MLP Forecast Model for time series point forecasting using configurable architecture.

    This model implements a multilayer perceptron-based forecaster with attention mechanisms
    and configurable feature processing. Model architecture and training parameters are
    controlled through the `MLPFConfig` configuration class.

    Attributes:
        model_config (MLPFConfig): Complete configuration object containing model architecture
            and training parameters. See `MLPFConfig` documentation for full details.
        model (MLPFNetwork): Instantiated neural network implementing the forecast logic.
        metric (str): Primary evaluation metric used for model selection (inherited from BaseNeuralModel).

    Example:
        >>> from twiga.forecasting.config import MLPFConfig
        >>> data_config = DataPipelineConfig(
        ...     target_feature=["energy_demand"],
        ...     historical_features=["temp", "humidity"],
        ...     forecast_horizon=24,
        ...     lookback_window_size=168,
        ... )
        >>> model_config = MLPFConfig.from_data_config(data_config)
        >>> model = MLPFModel(model_config=model_config)
        >>> model.update(trial=optuna_trial)  # Hyperparameter update
    """

    def __init__(self, model_config: NHITSConfig | None = None):
        """Initialize MLP forecast model with provided configuration.

        Args:
            model_config (MLPFConfig): Configuration object containing:
                - num_target_feature: Number of target series to forecast
                - num_historical_features: Historical feature dimensions
                - num_calendar_features: Calendar feature dimensions
                - num_exogenous_features: Exogenous feature dimensions
                - num_future_covariates: Future covariate dimensions
                - forecast_horizon: Prediction steps
                - lookback_window_size: Historical window size
                - hidden_size: Hidden layer dimensionality
                - num_layers: Number of MLP layers
                - activation_function: Hidden layer activation
                - dropout: Dropout probability
                - max_epochs: Training iterations
                - [Full parameter list in MLPFConfig docs]
        """
        # Pass configuration parameters to the parent class (MLPFModel)
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,  # type: ignore[union-attr]
            wandb_logging=model_config.wandb_logging,  # type: ignore[union-attr]
            drop_last=model_config.drop_last,  # type: ignore[union-attr]
            num_workers=model_config.num_workers,  # type: ignore[union-attr]
            batch_size=model_config.batch_size,  # type: ignore[union-attr]
            pin_memory=model_config.pin_memory,  # type: ignore[union-attr]
            max_epochs=model_config.max_epochs,  # type: ignore[union-attr]
            seed=model_config.seed,  # type: ignore[union-attr]
            patience=model_config.patience,  # type: ignore[union-attr]
            resume_training=model_config.resume_training,  # type: ignore[union-attr]
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        """Initialize the MLP forecast model.

        This method sets up the neural network architecture based on the provided configuration.
        It initializes the MLPFModel with the specified parameters and prepares it for training.
        """
        # Initialize the MLPFModel with parameters from the configuration
        self.model = NHITS(
            num_target_feature=self.model_config.num_target_feature,  # type: ignore[union-attr]
            num_historical_features=self.model_config.num_historical_features,  # type: ignore[union-attr]
            num_calendar_features=self.model_config.num_calendar_features,  # type: ignore[union-attr]
            num_exogenous_features=self.model_config.num_exogenous_features,  # type: ignore[union-attr]
            num_future_covariates=self.model_config.num_future_covariates,  # type: ignore[union-attr]
            forecast_horizon=self.model_config.forecast_horizon,  # type: ignore[union-attr]
            lookback_window_size=self.model_config.lookback_window_size,  # type: ignore[union-attr]
            activation_function=self.model_config.activation_function,  # type: ignore[union-attr]
            out_activation_function=self.model_config.out_activation_function,  # type: ignore[union-attr]
            dropout=self.model_config.dropout,  # type: ignore[union-attr]
            alpha=self.model_config.alpha,  # type: ignore[union-attr]
            stack_types=self.model_config.stack_types,  # type: ignore[arg-type, union-attr]
            n_blocks=self.model_config.n_blocks,  # type: ignore[union-attr]
            mlp_units=self.model_config.mlp_units,  # type: ignore[union-attr]
            n_pool_kernel_size=self.model_config.n_pool_kernel_size,  # type: ignore[union-attr]
            n_freq_downsample=self.model_config.n_freq_downsample,  # type: ignore[union-attr]
            pooling_mode=self.model_config.pooling_mode,  # type: ignore[union-attr]
            interpolation_mode=self.model_config.interpolation_mode,  # type: ignore[union-attr]
            decompose_forecast=self.model_config.decompose_forecast,  # type: ignore[union-attr]
            encode_size=self.model_config.encode_size,  # type: ignore[union-attr]
            metric=self.model_config.metric,  # type: ignore[union-attr]
            optimizer_params=self.model_config.optimizer_params,  # type: ignore[union-attr]
            scheduler_params=self.model_config.scheduler_params,  # type: ignore[union-attr]
        )

    def update(self, trial: optuna.Trial) -> None:
        """Update model hyperparameters using Optuna trial suggestions.

        Args:
            trial (optuna.Trial): Optuna optimization trial providing hyperparameter
                sampling and pruning capabilities. Interacts with the search space
                defined in `MLPFConfig.search_space`.

        Updates:
            Reinitializes the neural network with trial-suggested parameters while
            preserving configuration structure and validation rules.
        """
        # Get updated parameters from the trial
        params = self.model_config.get_optuna_params(trial=trial)  # type: ignore[union-attr]
        self.model_config = NHITSConfig(**params)

        # Reinitialize the model with updated parameters
        self._init_model()

    def load_checkpoint(self):
        """Load the latest checkpoint for the model.

        This method retrieves the path of the latest checkpoint and loads the model state into the current instance.
        """
        self._load_checkpoints(model_instance=NHITS)
        self.model.eval()
