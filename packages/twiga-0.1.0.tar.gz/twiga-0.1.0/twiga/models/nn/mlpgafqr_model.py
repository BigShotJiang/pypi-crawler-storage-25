"""MLPGAF quantile regression model configuration and experiment wrapper."""

from __future__ import annotations

from typing import Literal

import optuna
import torch

from twiga.core.config import BaseSearchSpace, Field
from twiga.core.config.neural import BaseMLPConfig
from twiga.models.nn.core.base import BaseNeuralForecast
from twiga.models.nn.mlpgaf_model import MLPGAFConfig
from twiga.models.nn.prob.mlpgafqr import MLPGAFQR


class MLPGAFQRConfig(MLPGAFConfig):
    """Configuration for the MLPGAF fixed-grid quantile forecasting model.

    Extends :class:`MLPGAFConfig` with quantile regression parameters. The GAF
    encoder architecture (including gating params) is fully inherited and tunable.

    Attributes:
        name: Fixed model identifier.
        quantiles: Explicit quantile levels to forecast. If None, defaults inside
            QRDistribution apply.
        conf_level: Confidence level for symmetric interval construction.
        loss_fn: Pinball or Huber-pinball quantile loss.
        kappa: Huber transition parameter (only relevant for 'huber-pinball').
        eps: Numerical stability epsilon.
        search_space: Optuna hyperparameter search space.
    """

    name: Literal["mlpgafqr"] = Field(  # type: ignore[assignment]
        default="mlpgafqr",
        description="Fixed model identifier.",
        alias="model_name",
        exclude=True,
    )

    # ── Quantile-specific ─────────────────────────────────────────────────────
    quantiles: list[float] | None = Field(None, description="Explicit quantile levels to forecast.")
    conf_level: float = Field(0.05, description="Confidence level for quantile bounds.")
    loss_fn: Literal["pinball", "huber-pinball"] = Field("pinball", description="Quantile loss function.")
    kappa: float = Field(0.5, description="Huber transition parameter.")
    eps: float = Field(1e-6, description="Epsilon for numerical stability.")

    # ── Search space ──────────────────────────────────────────────────────────
    search_space: BaseSearchSpace = Field(
        default_factory=lambda: BaseSearchSpace(
            **(
                BaseMLPConfig.base_mlp_search
                | {
                    "use_revin": [False, True],
                    "lambda_gate": (1e-7, 1e-2),
                    "lambda_weight": (1e-7, 1e-4),
                    "gate_scale": [1.0, 2.0, 3.0, 5.0],
                    "warmup_epochs": [0, 5, 10],
                    "delta": [1e-3, 5e-3, 0.01, 0.05],
                    "kappa": (0.01, 1.0),
                    "loss_fn": ["pinball", "huber-pinball"],
                }
            ),
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


class MLPGAFQRModel(BaseNeuralForecast):
    """Training lifecycle wrapper for fixed-grid quantile regression (:class:`MLPGAFQR`).

    Instantiates :class:`~twiga.models.nn.prob.mlpgafqr.MLPGAFQR` from an
    :class:`MLPGAFQRConfig`, manages training via PyTorch Lightning, and
    supports Optuna hyperparameter optimisation.

    Example:
        >>> config = MLPGAFQRConfig(
        ...     num_target_feature=1,
        ...     num_historical_features=5,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ...     quantiles=[0.1, 0.5, 0.9],
        ... )
        >>> model = MLPGAFQRModel(model_config=config)
    """

    def __init__(self, model_config: MLPGAFQRConfig) -> None:
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        cfg = self.model_config
        self.model = MLPGAFQR(
            # Feature counts
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            # Sequence dimensions
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            # Embedding
            embedding_size=cfg.embedding_size,
            embedding_type=cfg.embedding_type,
            value_embed_type=cfg.value_embed_type,
            # Architecture flags
            use_norm=cfg.use_norm,
            use_bias=cfg.use_bias,
            use_residual=cfg.use_residual,
            use_revin=cfg.use_revin,
            use_temporal_mixer=cfg.use_temporal_mixer,
            # Encoder dimensions
            num_layers=cfg.num_layers,
            latent_size=cfg.latent_size,
            hidden_dim=cfg.hidden_dim,
            width_multiplier=cfg.width_multiplier,
            # Activation & regularisation
            activation_function=cfg.activation_function,
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            lambda_weight=cfg.lambda_weight,
            lambda_gate=cfg.lambda_gate,
            delta=cfg.delta,
            # Gate
            gate_scale=cfg.gate_scale,
            gate_type=cfg.gate_type,
            warmup_epochs=cfg.warmup_epochs,
            # Quantile
            quantiles=cfg.quantiles,
            conf_level=cfg.conf_level,
            loss_fn=cfg.loss_fn,
            kappa=cfg.kappa,
            eps=cfg.eps,
            # Training
            metric=cfg.metric,
            optimizer_type=cfg.optimizer_type,
            lr_scheduler_type=cfg.lr_scheduler_type,
            optimizer_params=cfg.optimizer_params,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = MLPGAFQRConfig(**params)
        self.batch_size = self.model_config.batch_size
        self.max_epochs = self.model_config.max_epochs
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        self._load_checkpoints(model_instance=MLPGAFQR)  # type: ignore[arg-type]
        self.model.eval()
