"""MLPGAM model configuration and experiment wrapper.

Provides :class:`MLPGAMConfig` for parameter validation and hyperparameter
search space definition, and :class:`MLPGAMModel` for training lifecycle
management via :class:`~twiga.models.nn.core.base.BaseNeuralForecast`.
"""

from __future__ import annotations

from typing import Literal

import optuna
import torch

from twiga.core.config import BaseSearchSpace
from twiga.core.config.neural import BaseMLPConfig, Field
from twiga.core.utils.logger import get_logger
from twiga.models.nn.core.base import BaseNeuralForecast
from twiga.models.nn.net.mlpfgam import MLPGAM

log = get_logger(__name__)


class MLPGAMConfig(BaseMLPConfig):
    """Configuration for the MLPGAM (Generalized Additive Model-inspired MLP) forecasting model.

    Extends the shared MLP base configuration with a lightweight L1 (Lasso) penalty
    applied specifically to the final projection / readout weights. This encourages
    sparsity and improves interpretability of feature importance in the output layer.

    Attributes:
        name: Fixed model identifier ("mlpgam").
        lambda_lasso: L1 (Lasso) regularization strength applied to the final
            projection weights. Higher values promote sparsity in the output mapping.
        search_space: Hyperparameter ranges for Optuna-based tuning. Extends the base
            MLP search space with the `lambda_lasso` parameter.
    """

    name: Literal["mlpgam"] = Field(  # type: ignore[assignment]
        default="mlpgam",
        alias="model_name",
        exclude=True,
        description="Fixed model identifier.",
    )

    distribution: Literal["normal", "laplace", "lognormal", "gamma", "beta", "studentt", "qr", "fpqr", "crc"] | None = (
        Field(
            default=None,
            exclude=True,
            description=(
                "Output distribution type. When set, TwigaForecaster automatically resolves this config "
                "to the corresponding probabilistic variant (e.g. 'normal' → MLPGAMNormalConfig). "
                "Valid options: normal, laplace, lognormal, gamma, beta, studentt, qr, fpqr, crc."
            ),
        )
    )

    lambda_lasso: float = Field(
        1e-6,
        description=(
            "L1 (Lasso) penalty coefficient applied to the final projection "
            "layer weights. Encourages sparsity and interpretability."
        ),
    )
    search_space: BaseSearchSpace = Field(
        default_factory=lambda: BaseSearchSpace(**(BaseMLPConfig.base_mlp_search | {"lambda_lasso": (1e-7, 1e-4)})),
        description="Hyperparameter search space for Optuna tuning",
        exclude=True,
    )


class MLPGAMModel(BaseNeuralForecast):
    """Training lifecycle wrapper for :class:`MLPGAMNetwork`.

    Instantiates :class:`~twiga.models.nn.net.mlpgam.MLPGAM` from an
    :class:`MLPGAMConfig`, manages training via PyTorch Lightning, and
    supports Optuna hyperparameter optimisation.

    Example:
        >>> config = MLPGAMConfig(
        ...     num_target_feature=1,
        ...     num_historical_features=5,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ... )
        >>> model = MLPGAMModel(model_config=config)
    """

    def __init__(self, model_config: MLPGAMConfig) -> None:
        """Initialise with a validated :class:`MLPGAMConfig`.

        Args:
            model_config: Full model configuration.
        """
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        """Instantiate :class:`MLPGAM` from the current config."""
        cfg = self.model_config
        self.model = MLPGAM(
            # Feature counts
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            # Sequence dimensions
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            # Embedding
            embedding_size=cfg.embedding_size,
            embedding_type=cfg.embedding_type,
            value_embed_type=cfg.value_embed_type,
            # Architecture flags
            use_norm=cfg.use_norm,
            use_bias=cfg.use_bias,
            use_residual=cfg.use_residual,
            use_temporal_mixer=cfg.use_temporal_mixer,
            # Encoder dimensions
            latent_size=cfg.latent_size,
            hidden_dim=cfg.hidden_dim,
            width_multiplier=cfg.width_multiplier,
            num_layers=cfg.num_layers,
            # Activation
            activation_function=cfg.activation_function,
            out_activation_function=cfg.out_activation_function,
            # Regularisation
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            lambda_lasso=cfg.lambda_lasso,
            # Training
            metric=cfg.metric,
            optimizer_type=cfg.optimizer_type,
            optimizer_params=cfg.optimizer_params,
            lr_scheduler_type=cfg.lr_scheduler_type,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        """Re-initialise model with Optuna-suggested hyperparameters.

        Args:
            trial: Optuna trial providing parameter suggestions via the
                search space defined in :attr:`MLPGAMConfig.search_space`.
        """
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = MLPGAMConfig(**params)
        self.batch_size = self.model_config.batch_size
        self.max_epochs = self.model_config.max_epochs
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        """Load the latest checkpoint and set model to eval mode."""
        self._load_checkpoints(model_instance=MLPGAM)  # type: ignore[arg-type]
        self.model.eval()
