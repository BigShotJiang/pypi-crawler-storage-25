"""MLPGAM LogNormal model configuration and experiment wrapper."""

from __future__ import annotations

from typing import Literal

import optuna
import torch

from twiga.core.config import BaseSearchSpace, Field
from twiga.models.nn.core.base import BaseNeuralForecast
from twiga.models.nn.mlpgam_model import MLPGAMConfig
from twiga.models.nn.prob.mlpgam_parametric import MLPGAMLogNormal


class MLPGAMLogNormalConfig(MLPGAMConfig):
    """Configuration for LogNormal-distribution probabilistic MLPGAM.

    Best for: strictly positive, right-skewed targets - gas prices,
    generation ramp-up events.

    Attributes:
        name: Fixed model identifier.
        search_space: Optuna hyperparameter search space.
    """

    name: Literal["mlpgamlognormal"] = Field(  # type: ignore[assignment]
        default="mlpgamlognormal",
        description="Fixed model identifier.",
        alias="model_name",
        exclude=True,
    )

    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            latent_size=[64, 128, 256],
            hidden_dim=[64, 128, 256, 512],
            num_layers=(2, 5),
            width_multiplier=[0.5, 1.0, 1.5, 2.0, 3.0],
            embedding_size=[8, 16, 28, 32],
            value_embed_type=[None, "LinearEmb", "ConvEmb"],
            embedding_type=[None, "PosEmb", "LearnPosEmb"],
            dropout=(0.05, 0.35),
            alpha=(0.05, 0.4),
            use_norm=[False, True],
            use_bias=[True],
            use_residual=[False, True],
            activation_function=["SiLU", "ELU", "LeakyReLU"],
            out_activation_function=["Identity", "Tanh"],
            lambda_lasso=(1e-7, 1e-4),
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


class MLPGAMLogNormalModel(BaseNeuralForecast):
    """Training lifecycle wrapper for LogNormal-distribution probabilistic MLPGAM.

    Example:
        >>> config = MLPGAMLogNormalConfig(
        ...     num_target_feature=1,
        ...     num_historical_features=5,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ... )
        >>> model = MLPGAMLogNormalModel(model_config=config)
    """

    def __init__(self, model_config: MLPGAMLogNormalConfig) -> None:
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        cfg = self.model_config
        self.model = MLPGAMLogNormal(
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            embedding_size=cfg.embedding_size,
            embedding_type=cfg.embedding_type,
            value_embed_type=cfg.value_embed_type,
            use_norm=cfg.use_norm,
            use_bias=cfg.use_bias,
            use_residual=cfg.use_residual,
            use_temporal_mixer=cfg.use_temporal_mixer,
            latent_size=cfg.latent_size,
            hidden_dim=cfg.hidden_dim,
            width_multiplier=cfg.width_multiplier,
            num_layers=cfg.num_layers,
            activation_function=cfg.activation_function,
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            lambda_lasso=cfg.lambda_lasso,
            metric=cfg.metric,
            optimizer_type=cfg.optimizer_type,
            lr_scheduler_type=cfg.lr_scheduler_type,
            optimizer_params=cfg.optimizer_params,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = MLPGAMLogNormalConfig(**params)
        self.batch_size = self.model_config.batch_size
        self.max_epochs = self.model_config.max_epochs
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        self._load_checkpoints(model_instance=MLPGAMLogNormal)  # type: ignore[arg-type]
        self.model.eval()
