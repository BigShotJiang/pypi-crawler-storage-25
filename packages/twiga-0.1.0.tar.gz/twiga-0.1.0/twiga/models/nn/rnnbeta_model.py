"""RNN Beta model configuration and experiment wrapper."""

from __future__ import annotations

from typing import Literal

import optuna

from twiga.core.config import BaseSearchSpace, Field
from twiga.models.nn.core.base import BaseNeuralForecast
from twiga.models.nn.prob.rnn_parametric import RNNBeta
from twiga.models.nn.rnn_model import RNNConfig


class RNNBetaConfig(RNNConfig):
    """Configuration for Beta-distribution probabilistic RNN.

    Best for: bounded [0, 1] targets — capacity factors, state of charge.

    Attributes:
        name: Fixed model identifier ``"rnnbeta"``.
        search_space: Optuna hyperparameter search space.
    """

    name: Literal["rnnbeta"] = Field(  # type: ignore[assignment]
        default="rnnbeta",
        description="Fixed model identifier.",
        alias="model_name",
        exclude=True,
    )

    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            hidden_size=[64, 128, 256, 512],
            n_layers=(1, 3),
            cell_type=["gru", "lstm"],
            bidirectional=[False, True],
            dropout=(0.1, 0.5),
            alpha=(0.01, 0.5),
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


class RNNBetaModel(BaseNeuralForecast):
    """Training lifecycle wrapper for Beta-distribution probabilistic RNN."""

    def __init__(self, model_config: RNNBetaConfig) -> None:
        """Initialise with a validated :class:`RNNBetaConfig`.

        Args:
            model_config: Full model configuration.
        """
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        """Instantiate :class:`RNNBeta` from the current config."""
        cfg = self.model_config
        self.model = RNNBeta(
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            hidden_size=cfg.hidden_size,
            n_layers=cfg.n_layers,
            cell_type=cfg.cell_type,
            bidirectional=cfg.bidirectional,
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            metric=cfg.metric,
            optimizer_type=cfg.optimizer_type,
            optimizer_params=cfg.optimizer_params,
            lr_scheduler_type=cfg.lr_scheduler_type,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        """Re-initialise model with Optuna-suggested hyperparameters.

        Args:
            trial: Optuna trial providing parameter suggestions.
        """
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = RNNBetaConfig(**params)
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        """Load the latest checkpoint and set model to eval mode."""
        self._load_checkpoints(model_instance=RNNBeta)  # type: ignore[arg-type]
        self.model.eval()
