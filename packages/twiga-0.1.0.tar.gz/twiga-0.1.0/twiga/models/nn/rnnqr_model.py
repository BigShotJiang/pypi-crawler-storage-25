"""RNN QR and RNN FPQR model configurations and experiment wrappers."""

from __future__ import annotations

from typing import Literal

import optuna

from twiga.core.config import BaseSearchSpace, Field
from twiga.models.nn.core.base import BaseNeuralForecast
from twiga.models.nn.prob.rnn_qr import RNNFPQR, RNNQR
from twiga.models.nn.rnn_model import RNNConfig

# ── RNNQRConfig ───────────────────────────────────────────────────────────────


class RNNQRConfig(RNNConfig):
    """Configuration for RNN fixed-grid quantile regression.

    Extends :class:`RNNConfig` with quantile regression parameters.

    Attributes:
        name: Fixed model identifier.
        quantiles: Explicit quantile levels. If None, defaults inside QRDistribution apply.
        conf_level: Confidence level for interval construction.
        loss_fn: Pinball or Huber-pinball quantile loss.
        kappa: Huber transition parameter.
        eps: Numerical stability epsilon.
    """

    name: Literal["rnnqr"] = Field(  # type: ignore[assignment]
        default="rnnqr",
        description="Fixed model identifier.",
        alias="model_name",
        exclude=True,
    )

    quantiles: list[float] | None = Field(None, description="Explicit quantile levels to forecast.")
    conf_level: float = Field(0.05, description="Confidence level for quantile bounds.")
    loss_fn: Literal["pinball", "huber-pinball"] = Field("pinball", description="Quantile loss function.")
    kappa: float = Field(0.25, description="Huber transition parameter.")
    eps: float = Field(1e-6, description="Epsilon for numerical stability.")

    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            hidden_size=[64, 128, 256, 512],
            n_layers=(1, 3),
            cell_type=["gru", "lstm"],
            bidirectional=[False, True],
            dropout=(0.1, 0.5),
            alpha=(0.01, 0.5),
            kappa=(0.01, 1.0),
            loss_fn=["pinball", "huber-pinball"],
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


# ── RNNQRModel ────────────────────────────────────────────────────────────────


class RNNQRModel(BaseNeuralForecast):
    """Training lifecycle wrapper for RNN fixed-grid quantile regression."""

    def __init__(self, model_config: RNNQRConfig) -> None:
        """Initialise with a validated :class:`RNNQRConfig`.

        Args:
            model_config: Full model configuration.
        """
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        """Instantiate :class:`RNNQR` from the current config."""
        cfg = self.model_config
        self.model = RNNQR(
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            hidden_size=cfg.hidden_size,
            n_layers=cfg.n_layers,
            cell_type=cfg.cell_type,
            bidirectional=cfg.bidirectional,
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            quantiles=cfg.quantiles,
            conf_level=cfg.conf_level,
            loss_fn=cfg.loss_fn,
            kappa=cfg.kappa,
            eps=cfg.eps,
            metric=cfg.metric,
            optimizer_type=cfg.optimizer_type,
            optimizer_params=cfg.optimizer_params,
            lr_scheduler_type=cfg.lr_scheduler_type,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        """Re-initialise model with Optuna-suggested hyperparameters.

        Args:
            trial: Optuna trial providing parameter suggestions.
        """
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = RNNQRConfig(**params)
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        """Load the latest checkpoint and set model to eval mode."""
        self._load_checkpoints(model_instance=RNNQR)  # type: ignore[arg-type]
        self.model.eval()


# ── RNNFPQRConfig ─────────────────────────────────────────────────────────────


class RNNFPQRConfig(RNNConfig):
    """Configuration for RNN flexible-proposal quantile regression.

    Extends :class:`RNNConfig` with FPQR-specific parameters.

    Attributes:
        name: Fixed model identifier.
        n_quantiles: Number of quantile proposals.
        conf_level: Confidence level for interval construction.
        loss_fn: Pinball or Huber-pinball quantile loss.
        kappa: Huber transition parameter.
        num_cosines: Cosine features for the quantile embedding layer.
    """

    name: Literal["rnnfpqr"] = Field(  # type: ignore[assignment]
        default="rnnfpqr",
        description="Fixed model identifier.",
        alias="model_name",
        exclude=True,
    )

    n_quantiles: int = Field(9, description="Number of quantile levels for the proposal network.")
    conf_level: float = Field(0.05, description="Confidence level for quantile bounds.")
    loss_fn: Literal["pinball", "huber-pinball"] = Field("pinball", description="Quantile loss function.")
    kappa: float = Field(0.25, description="Huber transition parameter.")
    num_cosines: int = Field(32, description="Cosine features for quantile embedding.")

    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            hidden_size=[64, 128, 256, 512],
            n_layers=(1, 3),
            cell_type=["gru", "lstm"],
            bidirectional=[False, True],
            dropout=(0.1, 0.5),
            alpha=(0.01, 0.5),
            n_quantiles=[7, 9, 15, 21],
            kappa=(0.01, 1.0),
            loss_fn=["pinball", "huber-pinball"],
            num_cosines=[16, 32, 64],
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


# ── RNNFPQRModel ──────────────────────────────────────────────────────────────


class RNNFPQRModel(BaseNeuralForecast):
    """Training lifecycle wrapper for RNN flexible-proposal quantile regression."""

    def __init__(self, model_config: RNNFPQRConfig) -> None:
        """Initialise with a validated :class:`RNNFPQRConfig`.

        Args:
            model_config: Full model configuration.
        """
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        """Instantiate :class:`RNNFPQR` from the current config."""
        cfg = self.model_config
        self.model = RNNFPQR(
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            hidden_size=cfg.hidden_size,
            n_layers=cfg.n_layers,
            cell_type=cfg.cell_type,
            bidirectional=cfg.bidirectional,
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            n_quantiles=cfg.n_quantiles,
            conf_level=cfg.conf_level,
            loss_fn=cfg.loss_fn,
            kappa=cfg.kappa,
            num_cosines=cfg.num_cosines,
            metric=cfg.metric,
            optimizer_type=cfg.optimizer_type,
            optimizer_params=cfg.optimizer_params,
            lr_scheduler_type=cfg.lr_scheduler_type,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        """Re-initialise model with Optuna-suggested hyperparameters.

        Args:
            trial: Optuna trial providing parameter suggestions.
        """
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = RNNFPQRConfig(**params)
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        """Load the latest checkpoint and set model to eval mode."""
        self._load_checkpoints(model_instance=RNNFPQR)  # type: ignore[arg-type]
        self.model.eval()
