"""MLPGAF model configuration and experiment wrapper.

Provides :class:`MLPGAFConfig` for parameter validation and hyperparameter
search space definition, and :class:`MLPGAFModel` for training lifecycle
management via :class:`~twiga.models.nn.core.base.BaseNeuralForecast`.
"""

from __future__ import annotations

from typing import Literal

import optuna
import torch

from twiga.core.config import BaseSearchSpace
from twiga.core.config.neural import BaseMLPConfig, Field
from twiga.core.utils.logger import get_logger
from twiga.models.nn.core.base import BaseNeuralForecast
from twiga.models.nn.net.mlpfgaf import MLPGAF

log = get_logger(__name__)


class MLPGAFConfig(BaseMLPConfig):
    """Configuration for the MLPGAF (Gated Attention Fusion) forecasting model.

    Extends the shared MLP base configuration with lightweight channel-wise gating
    mechanisms and associated regularization terms. The gating allows the model to
    softly select or suppress feature channels in a learnable way.

    Default values and search space ranges reflect ablation study findings:

    * `value_embed_type='ConvEmb'` consistently performed best.
    * Disabling RevIN (`use_revin=False`) provided the largest single improvement.
    * Near-zero or no gate penalty (`lambda_gate` ≈ 1e-6 or disabled) outperformed
      stronger regularization.
    * Short/no warmup (`warmup_epochs` ≤ 5) was clearly superior to longer schedules.
    * `sigmoid` gating performed marginally better than alternatives.

    Attributes:
        name: Fixed model identifier ("mlpgaf").
        use_revin: Whether to apply Reversible Instance Normalization to input series.
        lambda_weight: L1 regularization coefficient applied to encoder weights.
        lambda_gate: Sparsity-inducing L1 penalty on the gating mechanism.
        delta: Small constant added for numerical stability in the gate penalty term.
        gate_scale: Scaling factor (temperature-like) applied to raw gate logits.
        gate_type: Nonlinearity used for the gating function.
        warmup_epochs: Number of epochs during which gate penalty is linearly ramped up.
        search_space: Hyperparameter ranges used for Optuna-based tuning. Extends the
            base MLP search space with gating-related parameters.
    """

    name: Literal["mlpgaf"] = Field(  # type: ignore[assignment]
        default="mlpgaf",
        alias="model_name",
        exclude=True,
        description="Fixed model identifier.",
    )

    distribution: Literal["normal", "laplace", "lognormal", "gamma", "beta", "studentt", "qr", "fpqr", "crc"] | None = (
        Field(
            default=None,
            exclude=True,
            description=(
                "Output distribution type. When set, TwigaForecaster automatically resolves this config "
                "to the corresponding probabilistic variant (e.g. 'normal' → MLPGAFNormalConfig). "
                "Valid options: normal, laplace, lognormal, gamma, beta, studentt, qr, fpqr, crc."
            ),
        )
    )

    use_revin: bool = Field(
        False,
        description=("Whether to apply Reversible Instance Normalization to the input time series."),
    )
    lambda_weight: float = Field(
        1e-6,
        description="L1 regularization strength on encoder weights.",
    )
    lambda_gate: float = Field(
        1e-6,
        description="Sparsity penalty coefficient on gating mechanism.",
    )
    delta: float = Field(
        0.05,
        description="Small stability constant in gate penalty computation.",
    )
    gate_scale: float = Field(
        3.0,
        description="Scaling factor applied to gate logits (temperature-like).",
    )
    gate_type: Literal["sigmoid"] = Field(
        "sigmoid",
        description="Activation function used for gating.",
    )
    warmup_epochs: int = Field(
        5,
        description=("Number of epochs over which gate penalty strength is linearly increased."),
    )
    search_space: BaseSearchSpace = Field(
        default_factory=lambda: BaseSearchSpace(
            **(
                BaseMLPConfig.base_mlp_search
                | {
                    "use_revin": [False, True],
                    "lambda_gate": (1e-7, 1e-2),
                    "lambda_weight": (1e-7, 1e-4),
                    "gate_scale": [1.0, 2.0, 3.0, 5.0],
                    "warmup_epochs": [0, 5, 10],
                    "delta": [1e-3, 5e-3, 0.01, 0.05],
                }
            ),
        ),
        description="Hyperparameter search space for Optuna tuning",
        exclude=True,
    )


class MLPGAFModel(BaseNeuralForecast):
    """Training lifecycle wrapper for :class:`MLPGAFNetwork`.

    Instantiates :class:`~twiga.models.nn.net.mlpfgaf.MLPGAF` from an
    :class:`MLPGAFConfig`, manages training via PyTorch Lightning, and
    supports Optuna hyperparameter optimisation.

    Example:
        >>> config = MLPGAFConfig(
        ...     num_target_feature=1,
        ...     num_historical_features=5,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ... )
        >>> model = MLPGAFModel(model_config=config)
    """

    def __init__(self, model_config: MLPGAFConfig) -> None:
        """Initialise with a validated :class:`MLPGAFConfig`.

        Args:
            model_config: Full model configuration.
        """
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        """Instantiate :class:`MLPGAF` from the current config."""
        cfg = self.model_config
        self.model = MLPGAF(
            # Feature counts
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            # Sequence dimensions
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            # Embedding
            embedding_size=cfg.embedding_size,
            embedding_type=cfg.embedding_type,
            value_embed_type=cfg.value_embed_type,
            # Architecture flags
            use_norm=cfg.use_norm,
            use_bias=cfg.use_bias,
            use_residual=cfg.use_residual,
            use_revin=cfg.use_revin,
            use_temporal_mixer=cfg.use_temporal_mixer,
            # Encoder dimensions
            latent_size=cfg.latent_size,
            hidden_dim=cfg.hidden_dim,
            width_multiplier=cfg.width_multiplier,
            num_layers=cfg.num_layers,
            # Patch embedding
            # Activation
            activation_function=cfg.activation_function,
            out_activation_function=cfg.out_activation_function,
            # Regularisation
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            lambda_weight=cfg.lambda_weight,
            lambda_gate=cfg.lambda_gate,
            delta=cfg.delta,
            # Gate
            gate_scale=cfg.gate_scale,
            gate_type=cfg.gate_type,
            warmup_epochs=cfg.warmup_epochs,
            # Training
            metric=cfg.metric,
            optimizer_type=cfg.optimizer_type,
            optimizer_params=cfg.optimizer_params,
            lr_scheduler_type=cfg.lr_scheduler_type,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        """Re-initialise model with Optuna-suggested hyperparameters.

        Args:
            trial: Optuna trial providing parameter suggestions via the
                search space defined in :attr:`MLPGAFConfig.search_space`.
        """
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = MLPGAFConfig(**params)
        self.batch_size = self.model_config.batch_size
        self.max_epochs = self.model_config.max_epochs
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        """Load the latest checkpoint and set model to eval mode."""
        self._load_checkpoints(model_instance=MLPGAF)  # type: ignore[arg-type]
        self.model.eval()
