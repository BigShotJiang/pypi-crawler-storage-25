from __future__ import annotations

import joblib
import lightning as pl
import torch
from torch import optim
import torchmetrics

from twiga.core.utils.logger import get_logger

from .defaults import OPTIMIZERS, SCHEDULERS

log = get_logger(__name__)

METRIC_MAPPING = {
    "mae": torchmetrics.MeanAbsoluteError,
    "mse": torchmetrics.MeanSquaredError,
    "smape": torchmetrics.SymmetricMeanAbsolutePercentageError,
}


class BaseNeuralModel(pl.LightningModule):
    """Base class for neural network models using PyTorch Lightning.

    Attributes:
        model (torch.nn.Module, optional): The PyTorch model for inference.
        data_pipeline (sklearn.pipeline.Pipeline, optional): Data preprocessing pipeline.
        tra_metric_fcn (torchmetrics.Metric): Metric function for training.
        val_metric_fcn (torchmetrics.Metric): Metric function for validation.
        checkpoints_path (str): Directory path for saving checkpoints.
        hparams (dict): Hyperparameters saved during initialization.
        OPTIMIZERS (dict): Dictionary of optimizer types, mapping to their classes and
            parameters (lr, weight_decay, prob_decay_1, prob_decay_2).
        SCHEDULERS (dict): Dictionary of scheduler types, mapping to their classes and
            parameters (gamma, scheduler-specific params).
    """

    def __init__(
        self,
        metric: str = "mae",
        max_epochs: int = 10,
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
    ):
        """Initializes the BaseNeuralModel.

        Args:
            metric: Evaluation metric. Must be one of {'mae', 'mse', 'smape'}.
                Defaults to 'mae'.
            max_epochs: Maximum number of training epochs. Must be positive.
                Defaults to 10.
            optimizer_type: Optimizer type to use. Must be one of the supported optimizers.
                Defaults to 'AdamW'.
            lr_scheduler_type: Learning rate scheduler type to use. Must be one of the supported schedulers.
                Defaults to 'multi_step'.
            checkpoints_path: Directory to save checkpoints. Must exist.
                Defaults to './'.
            optimizer_params: Dictionary of optimizer types, mapping to their classes and
                parameters. Each entry must include 'class' (callable) and 'params'
                (dict with 'lr', 'weight_decay', 'prob_decay_1', 'prob_decay_2').
                If None, uses default OPTIMIZERS. Defaults to None.
            scheduler_params: Dictionary of scheduler types, mapping to their classes and
                parameters. Each entry must include 'class' (callable) and 'params'
                (dict with 'gamma' and scheduler-specific parameters). If None, uses
                default SCHEDULERS. Defaults to None.

        Raises:
            ValueError: If any parameter is invalid (e.g., invalid metric, negative
                max_epochs, non-existent checkpoints_path, invalid dictionary format).
        """
        super().__init__()
        self.save_hyperparameters()

        self.opt_type = (optimizer_type or "adamw").lower()
        self.sch_type = (lr_scheduler_type or "multi_step").lower()

        opt_defaults = OPTIMIZERS.get(self.opt_type, OPTIMIZERS["adamw"])["params"]  # type: ignore[index]
        self.active_opt_params = {**opt_defaults, **(optimizer_params or {})}

        sch_defaults = SCHEDULERS.get(self.sch_type, SCHEDULERS["multi_step"])["params"]  # type: ignore[index]
        self.active_sch_params = {**sch_defaults, **(scheduler_params or {})}

        self.validate_params(
            metric,
            max_epochs,
            self.opt_type,
            self.active_opt_params,
            self.sch_type,
            self.active_sch_params,
        )

        self.model: torch.nn.Module | None = None
        self.data_pipeline = None
        self.checkpoints_path = checkpoints_path

        metric_class = METRIC_MAPPING[metric]
        self.tra_metric_fcn = metric_class()
        self.val_metric_fcn = metric_class()

    @staticmethod
    def validate_params(metric, max_epochs, opt_type, opt_params, sch_type, sch_params):
        """Full rigor validation logic without instance side-effects."""
        if not isinstance(max_epochs, int) or max_epochs <= 0:
            raise ValueError("max_epochs must be a positive integer")

        if metric not in METRIC_MAPPING:
            raise ValueError(f"Invalid metric '{metric}'. Choose from: {list(METRIC_MAPPING.keys())}")

        required_opt = {"lr", "weight_decay"}
        if not all(p in opt_params for p in required_opt):
            raise ValueError(f"OPTIMIZERS['{opt_type}']['params'] must include {required_opt}")

        for p in required_opt:
            if not isinstance(opt_params[p], (int, float)) or opt_params[p] < 0:
                raise ValueError(f"OPTIMIZERS['{opt_type}']['params']['{p}'] must be a non-negative number")

        if "gamma" not in sch_params:
            raise ValueError(f"SCHEDULERS['{sch_type}']['params'] must include 'gamma'")

        if not isinstance(sch_params["gamma"], (int, float)) or sch_params["gamma"] < 0:
            raise ValueError(f"SCHEDULERS['{sch_type}']['params']['gamma'] must be a non-negative number")

        if sch_type in {"multi_step", "warmup_multi_step"}:
            required_fracs = {"prob_decay_1", "prob_decay_2"}
            if not all(p in sch_params for p in required_fracs):
                raise ValueError(f"SCHEDULERS['{sch_type}']['params'] must include {required_fracs}")
            for p in required_fracs:
                if not isinstance(sch_params[p], (int, float)) or not 0 <= sch_params[p] <= 1:
                    raise ValueError(f"SCHEDULERS['{sch_type}']['params']['{p}'] must be a float in [0, 1]")

        if sch_type == "cosine_annealing" and "prob_T0" in sch_params:
            val = sch_params["prob_T0"]
            if not isinstance(val, (int, float)) or not 0 <= val <= 1:
                raise ValueError(f"SCHEDULERS['{sch_type}']['params']['prob_T0'] must be a float in [0, 1]")

        if sch_type == "reduce_on_plateau" and "prob_patience" in sch_params:
            val = sch_params["prob_patience"]
            if not isinstance(val, (int, float)) or not 0 <= val <= 1:
                raise ValueError(f"SCHEDULERS['{sch_type}']['params']['prob_patience'] must be a float in [0, 1]")

    def calculate_model_size(self) -> float:
        """Calculate the size of the model in MB.

        Returns:
            float: Model size in MB.
        """
        if self.model is None:
            raise ValueError("Model is not initialized.")

        param_size = sum(p.nelement() * p.element_size() for p in self.model.parameters())
        buffer_size = sum(b.nelement() * b.element_size() for b in self.model.buffers())
        size_mb = (param_size + buffer_size) / 1024**2
        log.info("Model size: %.3f MB", size_mb)
        return size_mb

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass of the model.

        Args:
            x (torch.Tensor): Input data.

        Returns:
            torch.Tensor: Output of the model.
        """
        return self.model(x)  # type: ignore[misc]

    def forecast(self, x: torch.Tensor) -> torch.Tensor:
        """Generate forecast for the given input.

        Args:
            x (torch.Tensor): Input data for forecasting.

        Returns:
            torch.Tensor: Forecasted values.
        """
        return self.model.forecast(x)  # type: ignore[operator, union-attr]

    def on_save_checkpoint(self, checkpoint: dict) -> None:
        """Save the data pipeline to a file and add the file path to the checkpoint dictionary.

        Args:
            checkpoint (dict): Checkpoint dictionary.
        """
        if self.data_pipeline is None:
            log.warning("data_pipeline is None - skipping pipeline serialisation in checkpoint")
            return
        data_pipeline_path = f"{self.checkpoints_path}/data_pipeline.pkl"
        joblib.dump(self.data_pipeline, data_pipeline_path)
        checkpoint["data_pipeline_path"] = data_pipeline_path

    def on_load_checkpoint(self, checkpoint: dict) -> None:
        """Load the data pipeline from a file.

        Args:
            checkpoint (dict): Checkpoint dictionary.
        """
        self.data_pipeline = joblib.load(checkpoint["data_pipeline_path"])

    def training_step(self, batch: tuple[torch.Tensor, torch.Tensor], batch_idx: int) -> torch.Tensor:
        """Perform a single training step.

        Args:
            batch (tuple): A batch of training data.
            batch_idx (int): Index of the batch.

        Returns:
            torch.Tensor: The loss value for the batch.
        """
        optimizers = self.optimizers()
        num_optimizers = len(optimizers) if isinstance(optimizers, list | tuple) else 1
        if num_optimizers == 2:
            opt_mu, opt_sigma = self.optimizers()  # type: ignore[attr-defined]
            self.toggle_optimizer(opt_mu)
            loss_mu, metric = self.model.step(batch, self.tra_metric_fcn, self.current_epoch)  # type: ignore[operator, union-attr]
            opt_mu.zero_grad()
            self.manual_backward(loss_mu)
            opt_mu.step()
            self.untoggle_optimizer(opt_mu)

            self.toggle_optimizer(opt_sigma)
            loss_sigma, metric = self.model.step_sigma(batch, self.tra_metric_fcn)  # type: ignore[operator, union-attr]
            opt_sigma.zero_grad()
            self.manual_backward(loss_sigma)
            opt_sigma.step()
            self.untoggle_optimizer(opt_sigma)
            self.log("train_mu_loss", loss_mu, prog_bar=True, logger=True, on_epoch=True, on_step=False)
            self.log("train_sigma_loss", loss_sigma, prog_bar=True, logger=True, on_epoch=True, on_step=False)
            return loss_mu
        loss, metric = self.model.step(batch, self.tra_metric_fcn, self.current_epoch)  # type: ignore[operator, union-attr]
        self.log(
            f"train_{self.hparams['metric']}",
            metric,
            prog_bar=True,
            logger=True,
            on_epoch=True,
            on_step=False,
        )
        if isinstance(loss, dict):
            for key, value in loss.items():
                self.log(f"train_{key}", value, prog_bar=True, logger=True, on_epoch=True, on_step=False)
            loss = loss["loss"]
        else:
            self.log("train_loss", loss, prog_bar=True, logger=True, on_epoch=True, on_step=False)
        return loss

    def validation_step(self, batch: tuple[torch.Tensor, torch.Tensor], batch_idx: int) -> None:
        """Perform a single validation step.

        Args:
            batch (tuple): A batch of validation data.
            batch_idx (int): Index of the batch.

        Returns:
            None
        """
        loss, metric = self.model.step(batch, self.val_metric_fcn, self.current_epoch)  # type: ignore[operator, union-attr]
        if isinstance(loss, dict):
            for key, value in loss.items():
                self.log(f"val_{key}", value, prog_bar=True, logger=True, on_epoch=True, on_step=False)
        else:
            self.log("val_loss", loss, prog_bar=True, logger=True)
        self.log(f"val_{self.hparams['metric']}", metric, prog_bar=True, logger=True, on_epoch=True, on_step=False)

    def _get_scheduler(self, optimizer):
        """Builds the scheduler using resolved active_sch_params."""
        # Use the resolved parameters from __init__
        params = self.active_sch_params
        max_epochs = self.hparams["max_epochs"]

        # We use self.sch_type resolved in __init__
        if self.sch_type == "step":
            step_size = max(1, int(params.get("prob_step_size", 0.33) * max_epochs))
            return optim.lr_scheduler.StepLR(optimizer, step_size=step_size, gamma=params["gamma"])

        if self.sch_type == "multi_step":
            p1 = int(params["prob_decay_1"] * max_epochs)
            p2 = int(params["prob_decay_2"] * max_epochs)
            return optim.lr_scheduler.MultiStepLR(optimizer, milestones=[p1, p2], gamma=params["gamma"])

        if self.sch_type == "multiplicative":
            gamma = params["gamma"]
            return optim.lr_scheduler.MultiplicativeLR(optimizer, lr_lambda=lambda epoch: gamma)

        if self.sch_type == "exponential":
            return optim.lr_scheduler.ExponentialLR(optimizer, gamma=params["gamma"])

        if self.sch_type == "constant":
            total_iters = max(1, int(params.get("prob_total_iters", 0.1) * max_epochs))
            return optim.lr_scheduler.ConstantLR(optimizer, factor=params.get("factor", 0.1), total_iters=total_iters)

        if self.sch_type == "linear_decay":
            total_iters = max(1, int(params.get("prob_total_iters", 1.0) * max_epochs))
            return optim.lr_scheduler.LinearLR(
                optimizer,
                start_factor=params.get("start_factor", 1.0),
                end_factor=params.get("end_factor", 0.01),
                total_iters=total_iters,
            )

        if self.sch_type == "polynomial":
            total_iters = max(1, int(params.get("prob_total_iters", 1.0) * max_epochs))
            return optim.lr_scheduler.PolynomialLR(optimizer, total_iters=total_iters, power=params.get("power", 1.0))

        if self.sch_type == "cosine_annealing":
            return optim.lr_scheduler.CosineAnnealingWarmRestarts(
                optimizer,
                T_0=max(1, int(params.get("prob_T0", 0.25) * max_epochs)),
                T_mult=params.get("T_mult", 2),
                eta_min=params.get("eta_min", 1e-6),
            )

        if self.sch_type == "cosine_annealing_lr":
            return optim.lr_scheduler.CosineAnnealingLR(
                optimizer,
                T_max=max_epochs,
                eta_min=params.get("eta_min", 1e-6),
            )

        if self.sch_type == "cyclic":
            # Uses active_opt_params resolved in __init__
            base_lr = self.active_opt_params["lr"]
            max_lr = base_lr * params.get("prob_max_lr_scale", 10.0)
            step_size_up = max(1, int(params.get("prob_step_size_up", 0.1) * max_epochs))
            return optim.lr_scheduler.CyclicLR(
                optimizer,
                base_lr=base_lr,
                max_lr=max_lr,
                step_size_up=step_size_up,
                mode=params.get("mode", "triangular2"),
                gamma=params["gamma"],
                cycle_momentum=False,
            )

        if self.sch_type == "reduce_on_plateau":
            return {
                "scheduler": optim.lr_scheduler.ReduceLROnPlateau(
                    optimizer,
                    mode=params.get("mode", "min"),
                    factor=params.get("factor", 0.1),
                    patience=max(1, int(params.get("prob_patience", 0.1) * max_epochs)),
                ),
                "monitor": "val_loss",
                "interval": "epoch",
                "frequency": 1,
            }

        if self.sch_type == "one_cycle":
            total_steps = getattr(self.trainer, "estimated_stepping_batches", None)
            if total_steps is None:
                log.warning("estimated_stepping_batches unavailable - falling back to warmup_cosine")
                # Resolve warmup_cosine defaults specifically for the fallback
                fallback_params = {**SCHEDULERS["warmup_cosine"]["params"], **(self.hparams.scheduler_params or {})}
                return self._build_warmup_cosine(optimizer, fallback_params)

            return optim.lr_scheduler.OneCycleLR(
                optimizer,
                max_lr=params.get("max_lr", self.active_opt_params["lr"] * 10),
                total_steps=total_steps,
                pct_start=params.get("pct_start", 0.3),
                anneal_strategy=params.get("anneal_strategy", "cos"),
            )

        if self.sch_type == "warmup_multi_step":
            warmup_epochs = params.get("warmup_epochs", 5)
            p1 = int(params["prob_decay_1"] * max_epochs) + warmup_epochs
            p2 = int(params["prob_decay_2"] * max_epochs) + warmup_epochs
            warmup = optim.lr_scheduler.LambdaLR(optimizer, lambda epoch: min(1.0, (epoch + 1) / warmup_epochs))
            main_sch = optim.lr_scheduler.MultiStepLR(optimizer, milestones=[p1, p2], gamma=params["gamma"])
            return optim.lr_scheduler.SequentialLR(optimizer, schedulers=[warmup, main_sch], milestones=[warmup_epochs])

        if self.sch_type == "warmup_cosine":
            return self._build_warmup_cosine(optimizer, params)

        # Default fallback
        return optim.lr_scheduler.ConstantLR(optimizer, factor=1.0)

    def _build_warmup_cosine(self, optimizer, scheduler_params):
        """Build a linear-warmup + cosine-decay sequential scheduler.

        Args:
            optimizer: The optimizer instance to schedule.
            scheduler_params: The resolved parameters (active_sch_params).
        """
        # Use .get() to handle cases where overrides might be missing specific keys
        warmup_epochs = scheduler_params.get("warmup_epochs", 5)
        eta_min = scheduler_params.get("eta_min", 1e-6)

        max_epochs = self.hparams["max_epochs"]
        cosine_epochs = max(1, max_epochs - warmup_epochs)

        # Warmup: Linear increase to 1.0
        warmup = optim.lr_scheduler.LambdaLR(
            optimizer,
            lr_lambda=lambda epoch: min(1.0, (epoch + 1) / max(1, warmup_epochs)),
        )

        # Decay: Cosine decrease to eta_min
        cosine = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=cosine_epochs, eta_min=eta_min)

        return optim.lr_scheduler.SequentialLR(optimizer, schedulers=[warmup, cosine], milestones=[warmup_epochs])

    def _get_optimizer(
        self,
        opt_class: type[optim.Optimizer],
        opt_params: dict,
        mu_params: list | None = None,
        sigma_params: list | None = None,
    ) -> optim.Optimizer | tuple[optim.Optimizer | None, optim.Optimizer | None]:
        """Configure and return optimizer(s) for model parameters.

        Args:
            opt_class (type[optim.Optimizer]): Optimizer class (e.g., optim.Adam, optim.AdamW).
            opt_params (dict): Parameters for the optimizer (e.g., lr, weight_decay).
            mu_params (list | None): List of parameters for mean optimization. Defaults to None.
            sigma_params (list | None): List of parameters for variance optimization. Defaults to None.

        Returns:
            optim.Optimizer | tuple[optim.Optimizer | None, optim.Optimizer | None]:
                - If both mu_params and sigma_params are None,
                returns a single optimizer for all model parameters.
                - Otherwise, returns a tuple of optimizers for mu_params and sigma_params
                (None if respective params are None).

        Raises:
            ValueError: If mu_params or sigma_params is an empty list.
        """
        if mu_params is not None and not mu_params:
            raise ValueError("mu_params cannot be an empty list")
        if sigma_params is not None and not sigma_params:
            raise ValueError("sigma_params cannot be an empty list")

        if mu_params is None and sigma_params is None:
            return opt_class(self.parameters(), **opt_params)

        return (
            opt_class(mu_params, **opt_params) if mu_params else None,
            opt_class(sigma_params, **opt_params) if sigma_params else None,
        )

    def configure_optimizers(self) -> list[optim.Optimizer] | dict:  # type: ignore[override]
        """Configures optimizers and learning rate schedulers.

        Uses parameters from OPTIMIZERS (lr, weight_decay) and SCHEDULERS
        (gamma, scheduler-specific params). Supported optimizers (all native
        torch.optim): 'adam', 'adamw', 'nadam', 'radam', 'adamax', 'adafactor',
        'adagrad', 'adadelta', 'rmsprop', 'rprop', 'asgd', 'sgd', 'muon'.
        Supported schedulers (all native torch.optim.lr_scheduler): 'step',
        'multi_step', 'multiplicative', 'exponential', 'constant', 'linear_decay',
        'polynomial', 'cosine_annealing', 'cosine_annealing_lr', 'cyclic',
        'reduce_on_plateau', 'one_cycle', 'warmup_multi_step', 'warmup_cosine'.

        Returns:
            list[optim.Optimizer] | dict: List of optimizers and schedulers,
                or a dictionary for schedulers requiring monitoring (e.g., ReduceLROnPlateau).

        Raises:
            ValueError: If optimizer or scheduler type is invalid.
            ImportError: If 'muon' or 'lion' is selected but the package is not installed.
        """
        # 1. We already validated optimizer_type in __init__, so just fetch class
        optimizer_type = (self.hparams.get("optimizer_type") or "adamw").lower()
        opt_class = self._resolve_optimizer_class(optimizer_type)

        # 2. Use the resolved active_opt_params (fixed state leakage)
        opt_params = self.active_opt_params

        # 3. Handle Probabilistic Parameter Groups
        mu_params = getattr(self, "mu_params", None)
        sigma_params = getattr(self, "sigma_params", None)

        optimizer = self._get_optimizer(opt_class, opt_params, mu_params=mu_params, sigma_params=sigma_params)

        # 4. Wrap Schedulers and Optimizers
        if isinstance(optimizer, tuple):
            schedulers = []
            optimizers = []
            for opt in optimizer:
                if opt:
                    # Note: We updated _get_scheduler to not need opt_params anymore
                    scheduler = self._get_scheduler(opt)

                    # Handle ReduceLROnPlateau which returns a dict
                    if isinstance(scheduler, dict):
                        schedulers.append(scheduler)
                    else:
                        schedulers.append({"scheduler": scheduler, "interval": "epoch", "frequency": 1})

                    optimizers.append(opt)
            return optimizers, schedulers  # type: ignore[return-value]

        # Single optimizer case
        scheduler = self._get_scheduler(optimizer)

        # Proper return format for Lightning
        if isinstance(scheduler, dict):  # ReduceLROnPlateau
            return {"optimizer": optimizer, "lr_scheduler": scheduler}

        return [optimizer], [{"scheduler": scheduler, "interval": "epoch", "frequency": 1}]  # type: ignore[return-value]

    def _resolve_optimizer_class(self, optimizer_type: str) -> type[optim.Optimizer]:
        """Resolve an optimizer type string to its torch.optim class.

        All supported optimizers are native ``torch.optim`` built-ins - no
        third-party packages are required. LBFGS is intentionally excluded as
        it requires a closure-based training loop incompatible with the
        standard ``training_step`` pattern.

        Args:
            optimizer_type: One of ``'adam'``, ``'adamw'``, ``'nadam'``,
                ``'radam'``, ``'adamax'``, ``'adafactor'``, ``'adagrad'``,
                ``'adadelta'``, ``'rmsprop'``, ``'rprop'``, ``'asgd'``,
                ``'sgd'``, ``'muon'``.

        Returns:
            Optimizer class from ``torch.optim`` corresponding to the
            requested type.

        Raises:
            ValueError: If ``optimizer_type`` is not in the supported set.
        """
        optimizer_map = {
            "adam": optim.Adam,
            "adamw": optim.AdamW,
            "nadam": optim.NAdam,
            "radam": optim.RAdam,
            "adamax": optim.Adamax,
            "adafactor": optim.Adafactor,
            "adagrad": optim.Adagrad,
            "adadelta": optim.Adadelta,
            "rmsprop": optim.RMSprop,
            "rprop": optim.Rprop,
            "asgd": optim.ASGD,
            "sgd": optim.SGD,
            "muon": optim.Muon if hasattr(optim, "Muon") else optim.AdamW,
        }
        if optimizer_type not in optimizer_map:
            raise ValueError(f"Invalid optimizer_type '{optimizer_type}'")
        return optimizer_map[optimizer_type]
