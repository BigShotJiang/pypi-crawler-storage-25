"""Base module for neural forecasting models in Twiga."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
import time
import uuid

import lightning.pytorch as pl
from lightning.pytorch.callbacks import (
    EarlyStopping,
    LearningRateMonitor,
    ModelCheckpoint,
    RichProgressBar,
    TQDMProgressBar,
)
from lightning.pytorch.callbacks.progress.rich_progress import RichProgressBarTheme
from lightning.pytorch.loggers import TensorBoardLogger, WandbLogger
import numpy as np
import optuna
from optuna import Trial
from optuna_integration.pytorch_lightning import PyTorchLightningPruningCallback
import torch

from twiga.core.data.loader import TimeseriesDataModule
from twiga.core.utils.logger import get_logger
from twiga.utils.utils import get_latest_checkpoint

log = get_logger(__name__)


class BaseNeuralForecast(ABC):
    """Base class for all neural forecasting models in Twiga.

    Attributes:
        wandb_logging: Whether to use Weights & Biases logging.
        rich_progress_bar: Whether to use rich progress bar.
        drop_last: Whether to drop last incomplete batch.
        num_workers: Number of workers for data loading.
        batch_size: Number of samples per batch.
        max_epochs: Maximum number of training epochs.
        pin_memory: Whether to pin memory for faster GPU transfer.
        seed: Random seed for reproducibility.
        resume_training: Whether to resume from latest checkpoint.
        model: The neural network model.
        trainer: PyTorch Lightning trainer instance.
        checkpoints_path: Path to save model checkpoints.
        logs_path: Path to save training logs.
        project_name: Name of the project for logging.
        file_name: Base name for log files.
    """

    def __init__(
        self,
        rich_progress_bar: bool = False,
        wandb_logging: bool = False,
        drop_last: bool = True,
        num_workers: int = 8,
        batch_size: int = 64,
        pin_memory: bool = True,
        max_epochs: int = 1,
        seed: int = 123,
        resume_training: bool = True,
        checkpoints_path: str | Path = "checkpoints",
        logs_path: str | Path = "logs",
        project_name: str = "twiga",
        # file_name: str | None = None,
        metric: str = "mae",
        patience: int | None = None,
        direction: str = "min",
    ) -> None:
        """Initialize base neural forecaster.

        Args:
            rich_progress_bar: Use rich progress bar. Defaults to True.
            wandb_logging: Enable Weights & Biases logging. Defaults to False.
            drop_last: Drop last incomplete batch. Defaults to True.
            num_workers: Number of data loader workers. Defaults to 8.
            batch_size: Batch size for training. Defaults to 64.
            pin_memory: Pin memory for faster GPU transfer. Defaults to True.
            max_epochs: Maximum training epochs. Defaults to 1.
            seed: Random seed. Defaults to 123.
            resume_training: Resume from latest checkpoint. Defaults to True.
            checkpoints_path: Path for model checkpoints. Defaults to "checkpoints".
            logs_path: Path for training logs. Defaults to "logs".
            project_name: Project name for logging. Defaults to "twiga".
            #file_name: Base filename for logs. Defaults to None.
            metric: Metric to optimize. Defaults to "mae".
            patience: Early stopping patience. Defaults to None.
            direction: Optimization direction. Defaults to "min".
        """
        super().__init__()
        torch.set_float32_matmul_precision("high")
        self.wandb_logging = wandb_logging
        self.rich_progress_bar = rich_progress_bar
        self.drop_last = drop_last
        self.num_workers = num_workers
        self.batch_size = batch_size
        self.max_epochs = max_epochs
        self.pin_memory = pin_memory
        self.seed = seed
        self.metric = metric
        self.early_stop_patience = patience
        self.direction = direction
        self.resume_training = resume_training
        self.logger: WandbLogger | TensorBoardLogger | None = None

        self.checkpoints_path = Path(checkpoints_path)
        self.logs_path = Path(logs_path)
        self.project_name = project_name
        self.file_name: str | None = None

    @abstractmethod
    def update(self, trial: Trial) -> None:
        """Update the model with new hyperparameters.

        Args:
            trial: Optuna trial object containing hyperparameters.
        """

    @abstractmethod
    def load_checkpoint(self, checkpoints_path):
        """Load model from a checkpoint.

        Args:
            checkpoints_path: Path to the checkpoint file.
        """

    def _validate_required_attributes(self) -> None:
        """Ensure required attributes are present."""
        required_attrs = ["checkpoints_path", "logs_path", "project_name"]
        for attr in required_attrs:
            if not getattr(self, attr, None):
                raise RuntimeError(f"Missing required attribute: {attr}")

    def _set_up_trainer(
        self,
        trial: Trial | None = None,
        num_sanity_val_steps: int = 0,
    ) -> None:
        """Configure the PyTorch Lightning trainer.

        Args:
            trial: Optuna trial for hyperparameter optimization.
            num_sanity_val_steps: Number of validation steps for sanity check.

        Raises:
            ValueError: If early_stop_patience not provided without trial.
            RuntimeError: If required attributes are missing.

        Returns:
            Configured PyTorch Lightning trainer.
        """
        self._validate_required_attributes()
        callbacks = []

        if self.seed is not None:
            pl.seed_everything(self.seed, workers=True)

        self._configure_logger()

        callbacks.append(self._get_stopping_callback(trial, self.metric, self.direction, self.early_stop_patience))

        if trial is None:
            callbacks.append(self._create_checkpoint_callback(self.metric, self.direction))

        callbacks.extend([LearningRateMonitor(), self._get_progress_bar()])
        self.trainer = pl.Trainer(
            logger=self.logger,
            max_epochs=self.max_epochs,
            callbacks=callbacks,
            num_sanity_val_steps=num_sanity_val_steps,
            accelerator="auto",
            enable_checkpointing=trial is None,
        )
        return self.trainer  # type: ignore[return-value]

    def _configure_logger(self) -> None:
        """Initialize appropriate logger based on configuration."""
        if self.file_name is None:
            self.file_name = f"{self.project_name}_{uuid.uuid4().hex[:6]}_{int(time.time())}"

        if self.wandb_logging:
            self.logger = WandbLogger(
                save_dir=str(self.logs_path),
                name=self.file_name,
                project=self.project_name,
                log_model="all",
            )
        else:
            self.logger = TensorBoardLogger(
                save_dir=str(self.logs_path),
                version=self.file_name,
            )

    def _get_stopping_callback(
        self,
        trial: Trial | None,
        metric: str,
        direction: str,
        patience: int | None = None,
    ) -> EarlyStopping | PyTorchLightningPruningCallback:
        """Create appropriate stopping callback.

        Args:
            trial: Optuna trial for pruning.
            metric: Metric to monitor.
            direction: Optimization direction.
            patience: Early stopping patience.

        Returns:
            Configured stopping callback.

        Raises:
            ValueError: If patience not specified without trial.
        """
        if trial:
            return PyTorchLightningPruningCallback(trial, monitor=f"val_{metric}")

        if patience is None:
            raise ValueError("early_stop_patience must be specified when not using Optuna trials")

        return EarlyStopping(
            monitor=f"val_{metric}",
            patience=patience,
            mode=direction,
            verbose=False,
            check_on_train_epoch_end=False,
        )

    def _create_checkpoint_callback(self, metric: str, direction: str) -> ModelCheckpoint:
        """Configure model checkpointing.

        Args:
            metric: Metric to monitor for checkpointing.
            direction: Optimization direction.

        Returns:
            Configured ModelCheckpoint callback.
        """
        self.checkpoints_path.mkdir(parents=True, exist_ok=True)
        return ModelCheckpoint(
            dirpath=self.checkpoints_path,
            monitor=f"val_{metric}",
            mode=direction,
            save_top_k=1,
            filename=f"best_{{epoch:02d}}_{{{metric}:.2f}}",
            auto_insert_metric_name=False,
            save_last=False,
        )

    def _get_progress_bar(self) -> RichProgressBar | TQDMProgressBar:
        """Get configured progress bar.

        Returns:
            RichProgressBar if enabled, else TQDMProgressBar.
        """
        if not self.rich_progress_bar:
            return TQDMProgressBar()

        theme = RichProgressBarTheme(
            description="green_yellow",
            progress_bar="green1",
            progress_bar_finished="green1",
            progress_bar_pulse="#6206E0",
            batch_progress="green_yellow",
            time="grey82",
            processing_speed="grey82",
            metrics="grey82",
        )
        return RichProgressBar(theme=theme)

    def fit(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        X_val: np.ndarray | None = None,
        y_val: np.ndarray | None = None,
        trial: Trial | None = None,
    ) -> None:
        """Train the model on given data.

        Args:
            model: The neural network model to train.
            X_train: Training input features.
            y_train: Training target values.
            X_val: Validation input features. Defaults to None.
            y_val: Validation target values. Defaults to None.
            trial: Optuna trial for hyperparameter optimization. Defaults to None.


        Raises:
            RuntimeError: If model not initialized or training fails.
        """
        if self.model is None:
            raise RuntimeError("Model must be initialized before training")

        trainer = self._set_up_trainer(  # type: ignore[func-returns-value]
            trial=trial,
        )
        self.model.data_pipeline = self.data_pipeline  # type: ignore[attr-defined]
        self.model.checkpoints_path = self.checkpoints_path  # type: ignore[assignment]
        datamodule = TimeseriesDataModule(
            train_inputs=X_train,
            train_targets=y_train,
            val_inputs=X_val,
            val_targets=y_val,
            num_workers=self.num_workers,
            batch_size=self.batch_size,
            pin_memory=self.pin_memory,
        )
        ckpt_path = get_latest_checkpoint(self.checkpoints_path) if self.resume_training and trial is None else None

        # PyTorch 2.6+ defaults torch.load to weights_only=True, which rejects
        # custom classes stored in Lightning checkpoints.  Register all nn.Module
        # subclasses found in the model so the checkpoint can be loaded safely.
        if ckpt_path is not None:
            _safe: set[type] = set()
            _queue = [self.model]
            while _queue:
                _m = _queue.pop()
                _safe.add(type(_m))
                _queue.extend(_m.children())
            torch.serialization.add_safe_globals(list(_safe))

        try:
            trainer.fit(
                self.model,
                datamodule=datamodule,
                ckpt_path=ckpt_path,
            )
        except optuna.exceptions.TrialPruned:
            raise
        except Exception as e:
            log.exception("Training failed with error")
            raise RuntimeError("Training failed") from e

    def forecast(self, features: torch.Tensor) -> torch.Tensor:
        """Generate forecasts using the trained model.

        Args:
            features: Input features for forecasting.

        Returns:
            Forecasted values as a numpy array.
        """
        if self.model is None:
            raise RuntimeError("Model must be initialized before forecasting")

        self.model.eval()
        with torch.no_grad():
            forecast = self.model.forecast(features.to(self.model.device))  # type: ignore[operator]
        self.model.train()
        if isinstance(forecast, dict):
            for key, value in forecast.items():
                if isinstance(value, torch.Tensor):
                    forecast[key] = value.cpu().numpy()
        elif isinstance(forecast, tuple):
            forecast = tuple(value.cpu().numpy() if isinstance(value, torch.Tensor) else value for value in forecast)
        else:
            forecast = forecast.cpu().numpy()

        return forecast

    def _load_checkpoints(self, model_instance: pl.LightningModule):
        """Load model checkpoints if available.

        Args:
            model_instance: The model instance to load checkpoints into.
        """
        if self.checkpoints_path.exists():
            checkpoint = get_latest_checkpoint(self.checkpoints_path)
            if checkpoint:
                self.model = model_instance.load_from_checkpoint(checkpoint, weights_only=False)
                log.info("Loaded model from checkpoint: %s", checkpoint)
