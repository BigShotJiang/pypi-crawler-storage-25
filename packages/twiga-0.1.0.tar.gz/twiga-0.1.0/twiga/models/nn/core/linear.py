from __future__ import annotations

import copy
import math
import warnings

import torch
from torch import nn

SUPPORTED_ACTIVATIONS = [
    "ReLU",
    "Softplus",
    "Tanh",
    "Sigmoid",
    "SiLU",
    "GELU",
    "ELU",
    "SELU",
    "LeakyReLU",
    "PReLU",
]


from .embedding import DataEmbedding, PatchEmbedding


def create_linear_layer(
    in_channels: int,
    out_channels: int,
    use_norm: bool = False,
    activation: str | nn.Module | None = None,
    use_bias: bool = True,
) -> nn.Module:
    """Creates a linear layer with optional batch normalization and activation-dependent initialization.

    The weight initialization is tailored to the specified activation function:
    - ReLU, Softplus, SiLU, GELU, ELU: Kaiming normal with ReLU nonlinearity.
    - LeakyReLU, PReLU: Kaiming normal with negative_slope=0.01.
    - Sigmoid, Tanh: Xavier normal.
    - SELU: LeCun normal.
    - None or unsupported: Kaiming normal with ReLU nonlinearity (default).

    Args:
        in_channels: Number of input channels.
        out_channels: Number of output channels.
        use_norm: If True, adds batch normalization after the linear layer. Defaults to False.
        activation: Activation function or type. Can be a string (e.g., 'relu', 'sigmoid', 'selu')
            or an nn.Module instance (e.g., nn.ReLU(), nn.SELU()). Defaults to None.
        use_bias : weather to use bias term

    Returns:
        nn.Module: Linear layer with optional batch normalization.

    Raises:
        ValueError: If in_channels or out_channels are not positive integers.
    """
    if not isinstance(in_channels, int) or in_channels <= 0:
        raise ValueError("in_channels must be a positive integer")
    if not isinstance(out_channels, int) or out_channels <= 0:
        raise ValueError("out_channels must be a positive integer")

    # Create linear layer, disable bias if batch normalization is used
    linear_layer = nn.Linear(in_channels, out_channels, bias=use_bias)

    # Determine activation type
    if isinstance(activation, nn.Module):
        activation_type = type(activation).__name__.lower()
    elif isinstance(activation, str):
        activation_type = activation.lower()
        activation = getattr(nn, activation)()
    else:
        activation_type = None
        activation = None

    # Initialize weights based on activation
    if activation_type in ("relu", "softplus", "silu", "gelu", "elu"):
        nn.init.kaiming_normal_(linear_layer.weight, nonlinearity="relu")
    elif activation_type in ("leakyrelu", "prelu"):
        nn.init.kaiming_normal_(linear_layer.weight, a=0.01, nonlinearity="leaky_relu")
    elif activation_type in ("sigmoid", "tanh"):
        nn.init.xavier_normal_(linear_layer.weight)
    elif activation_type == "selu":
        nn.init.normal_(linear_layer.weight, mean=0, std=1 / in_channels**0.5)
    else:
        nn.init.kaiming_uniform_(linear_layer.weight, a=math.sqrt(5))

    if linear_layer.bias is not None:
        nn.init.constant_(linear_layer.bias, 0)

    if not use_norm and activation is None:
        return linear_layer

    layer_stack: list[nn.Module] = [linear_layer]

    if use_norm:
        norm_layer = nn.LayerNorm(out_channels)
        nn.init.constant_(norm_layer.weight, 1.0)
        nn.init.constant_(norm_layer.bias, 0.0)
        layer_stack.append(norm_layer)

    if activation is not None:
        layer_stack.append(activation)  # type: ignore[arg-type]

    return nn.Sequential(*layer_stack)


class TemporalMixingLayer(nn.Module):
    """Mixes information across the time axis of the embedded tensor.

    Applied **after** the embedding produces ``(B, T, D)``.  A shared linear
    layer projects ``T → T`` for every feature dimension, letting the MLP
    head receive tokens that already encode temporal context.

    ``BatchNorm1d`` is explicitly blocked because it is incompatible with the
    3-D tensor ``(B, D, T)`` that flows through the layer after the transpose:
    ``BatchNorm1d(T)`` would normalise over ``B × T`` per feature dimension
    instead of over ``B × D`` per timestep, which is semantically wrong.
    ``LayerNorm(T)`` is used instead and is already handled by ``self.norm``.

    Args:
        seq_len: Sequence length ``T`` after embedding (or patch count ``N``
            when ``PatchEmb`` is used upstream).  Must be >= 1.
        dropout: Dropout probability.  Defaults to ``0.0``.
        activation: Activation name string or ``nn.Module`` instance.
            Defaults to ``"ReLU"``.

    Shape:
        - Input / Output: ``(B, T, D)``
    """

    def __init__(  # type: ignore[misc, return]
        self,
        num_timesteps: int,
        dropout: float = 0.0,
        activation: nn.Module | str = "ReLU",
    ) -> torch.Tensor:
        super().__init__()
        self.norm = nn.LayerNorm(num_timesteps)
        self.fc = create_linear_layer(num_timesteps, num_timesteps, activation=None)
        if isinstance(activation, str):
            self.act: nn.Module = getattr(nn, activation)()
        else:
            self.act = copy.deepcopy(activation)

        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Mix across timesteps for each feature dimension.

        Pipeline (on transposed view):
        ``norm(T) → linear(T→T) → act → dropout → residual add``

        Args:
            x: Embedded tensor of shape ``(B, T, D)``.

        Returns:
            torch.Tensor: Time-mixed tensor of shape ``(B, T, D)``.
        """
        residual = x
        x = x.permute(0, 2, 1)  # (B, D, T)
        x = self.drop(self.act(self.fc(self.norm(x))))
        return residual + x.permute(0, 2, 1)  # (B, T, D)


class FeedForwardMLP(nn.Module):
    """Multi-Layer Perceptron (MLP) block with configurable layers and options.

    Projects a flattened ``(B, num_timesteps * input_features)`` tensor to
    a fixed ``output_dim``-dimensional vector via a sequence of linear layers
    whose widths are controlled by ``hidden_dim``, ``width_multiplier``, and
    ``max_hidden_dim``.

    The layer schedule is:

    * First layer: ``flat_input_dim → hidden_dim``
    * Hidden layers (``num_layers - 2``): each width is
      ``floor(prev × width_multiplier)``, clipped to
      ``[output_dim, max_hidden_dim]``.
    * Final laye: ``last_hidden_dim → output_dim``

    Attributes:
        layers:          ``nn.ModuleList`` of all projection layers.
        input_features:  Dimensionality of each token / time-step (pre-flatten).
        num_timesteps:   Number of tokens / time-steps (sequence length).

    """

    def __init__(  # type: ignore[misc, return]
        self,
        input_features: int = 1,
        output_dim: int = 32,
        hidden_dim: int = 256,
        max_hidden_dim: int = 2048,
        width_multiplier: float = 1.0,
        num_layers: int = 4,
        num_timesteps: int = 96,
        activation: str | nn.Module = "ReLU",
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = True,
    ) -> torch.Tensor:
        """Initialise the MLPBlock.

        Args:
            input_features:  Dimensionality of each context element before
                             flattening (e.g. embedding size or channel count).
            output_dim:      Output dimension produced by the final layer.
            hidden_dim:      Width of the first hidden layer.
            max_hidden_dim:  Hard cap on hidden layer width.
            width_multiplier: Multiplicative factor applied to compute the
                              next hidden layer width.  ``1.0`` = flat;
                              ``>1.0`` = expanding; ``<1.0`` = compressing.
            num_layers:      Total number of linear layers (including the
                             input projection and output projection).  Min 1.
            num_timesteps:   Sequence length fed into this block (after any
                             patch compression).
            activation:      Activation - string name or ``nn.Module`` instance.
            use_norm:        Insert ``LayerNorm`` after each linear layer.
            use_bias:        Include bias terms in every linear layer.
            use_residual:    Apply ``x ← x + f(x)`` for same-width hidden layers.

        Raises:
            ValueError: If any integer dimension is not a positive integer,
                        or ``width_multiplier`` is not positive.
        """
        super().__init__()
        for name, value in [
            ("input_features", input_features),
            ("output_dim", output_dim),
            ("hidden_dim", hidden_dim),
            ("num_layers", num_layers),
            ("num_timesteps", num_timesteps),
            ("max_hidden_dim", max_hidden_dim),
        ]:
            if not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer, got {value!r}")

        if not isinstance(width_multiplier, (int, float)) or width_multiplier <= 0:
            raise ValueError(f"width_multiplier must be a positive number, got {width_multiplier!r}")

        # ── build hidden layer dimension schedule ─────────────────────────────
        hidden_layer_dims: list[tuple[int, int]] = []
        current_dim = hidden_dim
        for _ in range(num_layers - 2):
            next_dim = int(math.floor(current_dim * width_multiplier))
            next_dim = max(output_dim, min(max_hidden_dim, next_dim))
            hidden_layer_dims.append((current_dim, next_dim))
            current_dim = next_dim

        # ── residual feasibility warnings ─────────────────────────────────────
        if use_residual and num_layers <= 2:
            warnings.warn(
                f"use_residual=True has no effect when num_layers={num_layers} "
                f"(requires num_layers >= 3). "
                f"Network: {'input → first → final' if num_layers == 2 else 'input → proj'}.",
                UserWarning,
                stacklevel=2,
            )
        elif use_residual and hidden_layer_dims and not any(in_dim == out_dim for in_dim, out_dim in hidden_layer_dims):
            warnings.warn(
                f"use_residual=True has no effect: all hidden layers change width "
                f"(width_multiplier={width_multiplier}), so x + f(x) is never applied. "
                f"Set width_multiplier=1.0 for flat residual layers.",
                UserWarning,
                stacklevel=2,
            )

        self.input_features = input_features
        self.num_timesteps = num_timesteps
        self.use_residual = use_residual
        self._hidden_layer_dims = hidden_layer_dims  # stored for forward() and __repr__
        self._output_dim = output_dim

        # ── assemble layer stack ──────────────────────────────────────────────
        flat_input_dim = input_features * num_timesteps
        layer_stack: list[nn.Module] = []

        if num_layers == 1:
            layer_stack.append(
                create_linear_layer(
                    flat_input_dim,
                    output_dim,
                    use_norm=use_norm,
                    activation=activation,
                    use_bias=use_bias,
                ),
            )
        else:
            layer_stack.append(
                create_linear_layer(
                    flat_input_dim,
                    hidden_dim,
                    use_norm=use_norm,
                    activation=activation,
                    use_bias=use_bias,
                ),
            )
            for in_dim, out_dim in hidden_layer_dims:
                layer_stack.append(
                    create_linear_layer(in_dim, out_dim, use_norm=use_norm, activation=activation, use_bias=use_bias),
                )
            layer_stack.append(
                create_linear_layer(
                    current_dim,
                    output_dim,
                    use_norm=use_norm,
                    activation=activation,
                    use_bias=use_bias,
                ),
            )

        self.layers = nn.ModuleList(layer_stack)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Project input to ``output_dim``.

        Args:
            x: ``(B, num_timesteps, input_features)`` or the pre-flattened
               ``(B, num_timesteps * input_features)``.

        Returns:
            torch.Tensor: Shape ``(B, output_dim)``.

        Raises:
            ValueError: On shape mismatch or wrong number of dimensions.
        """
        if x.ndim not in (2, 3):
            raise ValueError(f"Expected 2D or 3D input, got {x.ndim}D tensor")

        if x.ndim == 3:
            if x.shape[1] != self.num_timesteps or x.shape[2] != self.input_features:
                raise ValueError(
                    f"Expected input shape (B, {self.num_timesteps}, {self.input_features}), got {tuple(x.shape)}",
                )
            x = x.flatten(1, 2)

        flat_input_dim = self.input_features * self.num_timesteps
        if x.shape[1] != flat_input_dim:
            raise ValueError(f"Expected flattened input of size {flat_input_dim}, got {x.shape[1]}")

        x = self.layers[0](x)
        for layer, (in_dim, out_dim) in zip(self.layers[1:-1], self._hidden_layer_dims, strict=True):
            same_width = in_dim == out_dim
            x = x + layer(x) if (self.use_residual and same_width) else layer(x)
        if len(self.layers) > 1:
            x = self.layers[-1](x)

        return x

    def __repr__(self) -> str:
        flat_input_dim = self.input_features * self.num_timesteps
        all_dims = (
            [flat_input_dim]
            + (
                [d for d, _ in self._hidden_layer_dims] + [self._hidden_layer_dims[-1][1]]
                if self._hidden_layer_dims
                else []
            )
            + [self._output_dim]
        )
        shape_str = " → ".join(str(d) for d in all_dims)
        return f"{self.__class__.__name__}(shapes=[{shape_str}], residual={self.use_residual})"


class ReversibleInstanceNorm(nn.Module):
    """Reversible Instance Normalization for non-stationary time series.

    Normalises each sample independently over the **time axis** before the
    model, then inverts the transform on the output.  This is applied on the
    raw ``(B, T, C)`` input *before* the embedding so the embedding never
    sees distribution-shifted values.

    The cached statistics (mean, std) are computed during ``"norm"`` and
    reused during ``"denorm"``, so the output is always in the original scale
    of the input regardless of what the MLP predicts internally.

    Args:
        num_channels: Number of input variates ``C``.  Must be >= 1.
        eps: Numerical stability constant.  Defaults to ``1e-5``.
        affine: If ``True``, adds learnable per-channel ``gamma`` / ``beta``
            applied after normalisation.  Defaults to ``True``.

    Shape:
        - Input / Output: ``(B, T, C)``

    Example:
        >>> revin = RevIN(num_channels=7)
        >>> x_norm = revin(x, mode="norm")  # (B, T, C) - before embedding
        >>> x_emb = embedding(x_norm)  # (B, T, D)
        >>> y_pred = mlp(x_emb)  # MLPBlock flattens internally
        >>> y_out = revin(y_pred_reshaped, mode="denorm")
    """

    def __init__(
        self,
        num_channels: int,
        eps: float = 1e-5,
        affine: bool = True,
    ) -> None:
        super().__init__()
        if num_channels < 1:
            raise ValueError(f"num_channels must be >= 1, got {num_channels}")
        self.eps = eps
        self.affine = affine
        if affine:
            self.gamma = nn.Parameter(torch.ones(1, 1, num_channels))
            self.beta = nn.Parameter(torch.zeros(1, 1, num_channels))

    def forward(self, x: torch.Tensor, mode: str) -> torch.Tensor:
        """Normalise or denormalise the input.

        Args:
            x: Tensor of shape ``(B, T, C)``.
            mode: ``"norm"`` to normalise and cache statistics;
                ``"denorm"`` to invert using cached statistics.

        Returns:
            torch.Tensor of shape ``(B, T, C)``.

        Raises:
            ValueError: If ``mode`` is not ``"norm"`` or ``"denorm"``.
        """
        if mode == "norm":
            self._mean = x.mean(dim=1, keepdim=True).detach()  # (B, 1, C)
            self._std = x.std(dim=1, keepdim=True, unbiased=False).detach() + self.eps
            x = (x - self._mean) / self._std
            if self.affine:
                x = x * self.gamma + self.beta
            return x
        if mode == "denorm":
            if self.affine:
                x = (x - self.beta) / (self.gamma + self.eps)
            return x * self._std + self._mean
        raise ValueError(f"mode must be 'norm' or 'denorm', got '{mode}'")


class MLPEncoder(nn.Module):
    """Encoder module.

    The module processes a 3D input tensor of shape `(batch_size, context_size, n_channels)`
    through optional reversible instance normalization (RevIN), value + positional embedding,
    optional temporal mixing, layer normalization, and a final MLP block that produces
    a fixed-size latent representation of shape `(batch_size, latent_size)`.

    Processing pipeline:

    1. ReversibleInstanceNorm (optional) - remove per-instance mean/std.
    2. DataEmbedding (optional) - value + positional embedding.
    3. TemporalMixer (optional) - mix across the time axis.
    4. LayerNorm - normalise over the feature/token dimension.
    5. MLPBlock - flatten and project to ``latent_size``.

    Typical use::

        z = encoder(x)  # (B, T, C) → (B, latent_size)
        y_norm = decoder(z)  # (B, H, C)
        y_out = encoder.denorm(y_norm)  # restore original scale

    Attributes:
        use_revin:            Whether RevIN is active.
        revin:                ``ReversibleInstanceNorm`` (present only if ``use_revin=True``).
        embedding:            ``DataEmbedding`` (present only if an embedding type is selected).
        temporal_mixer:       ``TemporalMixer`` (present only if ``use_temporal_mixer=True``
                              and ``value_embed_type != "PatchEmb"``).
        norm:                 ``LayerNorm`` over the token/feature dimension.
        encoder:              ``FeedForwardMLP`` that produces the latent vector.
    """

    _VALID_VALUE_EMBED: frozenset[str | None] = frozenset({None, "LinearEmb", "ConvEmb", "PatchEmb"})
    _VALID_POS_EMBED: frozenset[str | None] = frozenset({None, "PosEmb", "LearnPosEmb", "RotaryEmb"})

    def __init__(
        self,
        embedding_size: int = 28,
        latent_size: int = 64,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        max_hidden_dim: int = 2048,
        num_layers: int = 3,
        context_size: int = 96,
        activation: nn.Module | str = "ReLU",
        dropout: float = 0.25,
        num_channels: int = 1,
        pos_embed_type: str | None = None,
        value_embed_type: str | None = None,
        patch_len: int | None = None,
        stride: int | None = None,
        use_norm: bool = True,
        use_bias: bool = True,
        use_revin: bool = True,
        use_temporal_mixer: bool = False,
        use_residual: bool = True,
    ) -> None:
        """Initialise the PastFutureEncoder.

        Args:
            embedding_size:     Token dimension produced by the value embedding.
            latent_size:        Output dimension of the encoder (``MLPBlock`` output).
            hidden_dim:         Width of the first hidden layer in ``MLPBlock``.
            width_multiplier:   Width growth factor inside ``MLPBlock``.
            max_hidden_dim:     Hard cap on ``MLPBlock`` hidden layer width.
            num_layers:         Number of layers in ``MLPBlock``.
            context_size:       Input sequence length ``T``.
            activation:         Activation function - string name or ``nn.Module``.
            dropout:            Dropout probability applied after embedding.
            num_channels:       Number of input variates ``C``.
            pos_embed_type:     Positional embedding type.
                                One of ``{None, "PosEmb", "LearnPosEmb", "RotaryEmb"}``.
            value_embed_type:   Value embedding type.
                                One of ``{None, "LinearEmb", "ConvEmb", "PatchEmb"}``.
            patch_len:          Patch window length (used only with ``"PatchEmb"``).
            stride:             Patch stride (used only with ``"PatchEmb"``).
            use_norm:           Apply ``LayerNorm`` inside ``MLPBlock`` layers.
            use_bias:           Include bias terms in linear layers.
            use_revin:          Apply reversible instance normalisation.
            use_temporal_mixer: Apply ``TemporalMixer`` before the MLP.
                                Silently disabled when ``value_embed_type="PatchEmb"``
                                because patching already compresses the time axis.
            use_residual:       Apply residual connections inside ``MLPBlock``.

        Raises:
            ValueError: If any integer dimension is non-positive, ``dropout``
                        is outside ``[0, 1]``, or an unsupported embedding type
                        is given.
            TypeError:  If ``activation`` is neither a string nor an ``nn.Module``.
        """
        super().__init__()

        for name, value in [
            ("embedding_size", embedding_size),
            ("latent_size", latent_size),
            ("num_layers", num_layers),
            ("context_size", context_size),
            ("num_channels", num_channels),
        ]:
            if not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive integer")

        if not isinstance(dropout, float) or not 0 <= dropout <= 1:
            raise ValueError("dropout must be a float in [0, 1]")

        if isinstance(activation, str):
            activation = getattr(nn, activation)()
        if not isinstance(activation, nn.Module):
            raise TypeError(f"activation must be an nn.Module or a valid string name, got {type(activation)}")

        if value_embed_type not in self._VALID_VALUE_EMBED:
            raise ValueError(f"value_embed_type must be one of {self._VALID_VALUE_EMBED}, got '{value_embed_type}'")
        if pos_embed_type not in self._VALID_POS_EMBED:
            raise ValueError(f"pos_embed_type must be one of {self._VALID_POS_EMBED}, got '{pos_embed_type}'")

        self.context_size = context_size
        self.num_channels = num_channels
        self.embedding_size = embedding_size
        self.latent_size = latent_size

        self._uses_embedding = pos_embed_type is not None or value_embed_type is not None
        self._uses_value_embedding = value_embed_type is not None  # add this

        self._uses_patch_embedding = value_embed_type == "PatchEmb"
        self._encoder_seq_len = (
            PatchEmbedding.num_patches(context_size, patch_len, stride)
            if (self._uses_patch_embedding and patch_len is not None and stride is not None)
            else context_size
        )
        # Mixer is redundant after PatchEmb - patching already compresses T → N
        self._apply_temporal_mixer = use_temporal_mixer and not self._uses_patch_embedding
        # Only a value embedding actually projects c_in → embedding_size.
        # A positional embedding alone leaves the feature dim unchanged.
        self._token_dim = embedding_size if self._uses_value_embedding else num_channels

        self.use_revin = use_revin
        if use_revin:
            self.revin = ReversibleInstanceNorm(num_channels=num_channels)

        if self._uses_embedding:
            self.embedding = DataEmbedding(
                c_in=num_channels,
                hidden_size=embedding_size,
                value_embed_type=value_embed_type,
                pos_embed_type=pos_embed_type,
                dropout=dropout,
                max_seq_len=context_size,
                patch_len=patch_len,  # type: ignore[arg-type]
                stride=stride,  # type: ignore[arg-type]
            )

        if self._apply_temporal_mixer:
            self.temporal_mixer = TemporalMixingLayer(
                num_timesteps=self._encoder_seq_len,
                activation=activation,
            )

        self.norm = nn.LayerNorm(self._token_dim)

        self.encoder = FeedForwardMLP(
            input_features=self._token_dim,
            output_dim=latent_size,
            hidden_dim=hidden_dim,
            width_multiplier=width_multiplier,
            max_hidden_dim=max_hidden_dim,
            num_layers=num_layers,
            num_timesteps=self._encoder_seq_len,
            activation=activation,
            use_norm=use_norm,
            use_bias=use_bias,
            use_residual=use_residual,
        )

    def _validate_input(self, x: torch.Tensor) -> None:
        """Assert that ``x`` has shape ``(B, context_size, num_channels)``.

        Raises:
            ValueError: On any shape mismatch.
        """
        if x.ndim != 3:
            raise ValueError(f"Expected 3D input (B, T, C), got {x.ndim}D")
        _, t, c = x.shape
        if t != self.context_size:
            raise ValueError(f"Expected T={self.context_size}, got T={t}  shape={tuple(x.shape)}")
        if c != self.num_channels:
            raise ValueError(f"Expected C={self.num_channels}, got C={c}  shape={tuple(x.shape)}")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Encode a time-series window to a latent vector.

        Args:
            x: Input tensor of shape ``(B, context_size, num_channels)``.

        Returns:
            torch.Tensor: Shape ``(B, latent_size)``.
        """
        self._validate_input(x)

        if self.use_revin:
            x = self.revin(x, mode="norm")

        if self._uses_embedding:
            x = self.embedding(x)

        if self._apply_temporal_mixer:
            x = self.temporal_mixer(x)

        x = self.norm(x)
        return self.encoder(x)

    def denorm(self, y: torch.Tensor) -> torch.Tensor:
        """Restore decoder predictions to the original input scale.

        Uses the statistics cached during the most recent ``forward()`` call.
        Safe to call unconditionally - returns ``y`` unchanged when
        ``use_revin=False``.

        Args:
            y: Decoder output of shape ``(B, H, C)``.

        Returns:
            Denormalised predictions of shape ``(B, H, C)``.

        Raises:
            RuntimeError: If called before ``forward()`` has been called at
                          least once.
        """
        if not self.use_revin:
            return y
        if not hasattr(self.revin, "_cached_mean"):
            raise RuntimeError(
                "denorm() called before forward(). Run encoder(x) first to cache normalisation statistics.",
            )
        return self.revin(y, mode="denorm")


class FeedForwardBlock(nn.Module):
    """Position-wise feed-forward block used in transformer-style models.

    Structure::

        Linear(dim → dim * expansion_ratio) → [LayerNorm] → activation → Dropout
        Linear(dim * expansion_ratio → dim) → [LayerNorm] → activation → Dropout

    Args:
        dim:              Input and output feature dimension.
        expansion_ratio:  Ratio by which the intermediate layer is wider than
                          ``dim``.  Defaults to ``2``.
        dropout:          Dropout probability.  Defaults to ``0.0``.
        activation:       Activation function name.  Defaults to ``"GELU"``.
        use_norm:         Insert ``LayerNorm`` after each linear layer.
                          Defaults to ``True``.
        use_bias:         Include bias terms in linear layers.  Defaults to ``True``.
    """

    def __init__(
        self,
        dim: int,
        expansion_ratio: int = 2,
        dropout: float = 0.0,
        activation: str = "GELU",
        use_norm: bool = True,
        use_bias: bool = True,
    ) -> None:
        """Initialise the FeedForwardBlock.

        Args:
            dim:             Input / output feature dimension.
            expansion_ratio: Hidden layer width = ``dim * expansion_ratio``.
            dropout:         Dropout probability between the two linear layers.
            activation:      Activation function name (case-sensitive string).
            use_norm:        Apply LayerNorm after each linear layer.
            use_bias:        Include bias in linear layers.
        """
        super().__init__()
        intermediate_dim = dim * expansion_ratio
        self.block = nn.Sequential(
            create_linear_layer(dim, intermediate_dim, use_norm=use_norm, activation=activation, use_bias=use_bias),
            nn.Dropout(dropout),
            create_linear_layer(intermediate_dim, dim, use_norm=use_norm, activation=activation, use_bias=use_bias),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Apply the feed-forward projection.

        Args:
            x: Input tensor of shape ``(B, dim)``.

        Returns:
            torch.Tensor: Same shape as input.
        """
        return self.block(x)
