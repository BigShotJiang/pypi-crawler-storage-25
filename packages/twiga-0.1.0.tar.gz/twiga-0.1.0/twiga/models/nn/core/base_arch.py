from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any

import torch
from torch import nn
import torch.nn.functional as F


class BaseArchitecture(nn.Module, ABC):
    """A neural network architecture.

    Attributes:
        num_target_feature (int): Number of target series to predict.
        num_historical_features (int): Number of unknown exogenous features.
        num_calendar_features (int): Number of known calendar-based features.
        num_exogenous_features (int): Number of known continuous features.
        num_future_covariates (int): Number of future covariates that are available only in the future.
        forecast_horizon (int, optional): Forecast horizon (number of future time steps to predict).
        Defaults to 48.
        lookback_window_size (int, optional): Size of the input window (number of historical time steps).
        Defaults to 96.
        dropout (float, optional): Dropout rate for regularization, must be between 0 and 1. Defaults to 0.25.
        alpha (float, optional): Weighting parameter for certain loss or regularization functions. Defaults to 0.1.
        output_activation (str, optional): Activation function for the output layer. Defaults to "Identity".
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        dropout: float | None = 0.25,
        alpha: float = 0.1,
        output_activation: str = "Identity",
    ):
        """Initializes the BaseArchitecture class.

        Args:
            num_target_feature (int): Number of target series to predict.
            num_historical_features (int): Number of historical features.
            num_calendar_features (int): Number of calendar-based features.
            num_exogenous_features (int): Number of exogenous features.
            num_future_covariates (int): Number of future covariates that are available only in the future.
            forecast_horizon (int): Forecast horizon (number of future time steps to predict).
            lookback_window_size (int): Size of the input window (number of historical time steps).
            dropout (float, optional): Dropout rate for regularization, must be between 0 and 1. Defaults to 0.25.
            alpha (float, optional): Weighting parameter for certain loss or regularization functions. Defaults to 0.1.
            output_activation (str, optional): Activation function for the output layer. Defaults to "Identity".
        """
        super().__init__()

        # Define model dimensions
        self.num_target_feature = num_target_feature
        self.num_historical_features = num_historical_features
        self.num_calendar_features = num_calendar_features
        self.num_exogenous_features = num_exogenous_features
        self.num_future_covariates = num_future_covariates

        # Model hyperparameters
        self.lookback_window_size = lookback_window_size
        self.forecast_horizon = forecast_horizon
        self.dropout_rate: float = dropout if dropout is not None else 0.0
        self.alpha: float = alpha

        # Dropout layer for regularization
        self.dropout: nn.Dropout = nn.Dropout(p=self.dropout_rate)

        # Output activation function
        self.output_activation: nn.Module = getattr(nn, output_activation)()
        self.set_num_feature_covariate_column()

    def set_num_feature_covariate_column(self):
        self.num_past_features = (
            self.num_target_feature
            + self.num_historical_features
            + self.num_exogenous_features
            + self.num_calendar_features
        )
        self.num_covariate_features = (
            self.num_exogenous_features + self.num_calendar_features + self.num_future_covariates
        )

    @property
    def encode_size(self) -> int:
        """Width of the latent vector returned by :meth:`encode`.

        Set ``self._encode_size`` in subclass ``__init__`` before calling
        ``super().__init__``, or override this property directly.
        """
        return self._encode_size  # type: ignore[return-value]

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        """Return the latent representation used by probabilistic heads.

        Override in subclasses that support probabilistic forecasting.

        Args:
            x: Input tensor of shape (B, T, F).

        Returns:
            Latent tensor of shape (B, encode_size).

        Raises:
            NotImplementedError: If the subclass has not implemented this method.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not implement encode(). "
            "Add an encode() method to enable probabilistic forecasting.",
        )

    def penalty_dict(self, epoch: int | None = None) -> dict[str, torch.Tensor]:
        """Return backbone-specific regularisation penalties.

        Override in subclasses that apply regularisation (Lasso, gate sparsity, …).
        The default returns an empty dict - no penalty.

        Args:
            epoch: Current training epoch, forwarded for warmup-based schedules.

        Returns:
            Mapping of penalty name → scalar loss tensor.
        """
        return {}

    def forecast(self, x: torch.Tensor) -> dict[str, torch.Tensor]:
        """Generates forecasts for the input sequences.

        Args:
            x (torch.Tensor): Input tensor containing time series data.

        Returns:
            dict: A dictionary with the predicted forecast, where the key is 'predicted_values' and
                  the value is a tensor of predicted values.
        """
        with torch.no_grad():
            predicted_values = self(x)

        return predicted_values

    @abstractmethod
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Defines the computation performed at every call. Should be overridden by all subclasses.

        Args:
            x (torch.Tensor): Input tensor containing time series data.

        Returns:
            torch.Tensor: Output tensor containing the forecasted values.
        """

    def step(
        self,
        batch: tuple[torch.Tensor, torch.Tensor],
        metric_fn: Callable[..., Any],
        epoch: int | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Perform a single training/validation step.

        Computes the combined MSE + MAE loss, adds
        and evaluates the provided metric function.

        Args:
            batch: Tuple of (input features, target values)
                   - x: shape [batch_size, input_features]
                   - y: shape [batch_size, output_size] or [batch_size]
            metric_fn: Callable that takes predictions and targets and returns a scalar metric
                       (often used for logging/validation, e.g. MAE, RMSE, MAPE, etc.)
            epoch: Current training epoch number (passed to regularization scheduler).
                   If None, no epoch-dependent behavior is applied.

        Returns:
            Tuple containing:
                - loss: Total loss value (MSE/MAE combination)
                - metric: Value returned by metric_fn(pred, target)
        """
        x, y = batch

        y_pred = self(x)

        loss = self.alpha * F.mse_loss(y_pred, y) + (1 - self.alpha) * F.l1_loss(y_pred, y).mean()

        metric = metric_fn(y_pred, y)

        return loss, metric
