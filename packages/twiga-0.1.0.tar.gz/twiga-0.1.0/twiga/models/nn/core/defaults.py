# Default optimizer configurations.
# All entries use only torch.optim built-ins - no third-party packages required.
OPTIMIZERS = {
    "adam": {
        "params": {
            "lr": 1e-3,
            "weight_decay": 1e-6,
        },
    },
    "adamw": {
        # AdamW - Adam with decoupled weight decay (Loshchilov & Hutter, 2019).
        # Default choice for most deep learning tasks. Preferred over Adam when
        # regularisation matters.
        "params": {
            "lr": 1e-3,
            "weight_decay": 1e-5,
        },
    },
    "nadam": {
        # NAdam - Adam with Nesterov momentum (Dozat, 2016).
        # Incorporates a lookahead correction that often improves convergence
        # on non-stationary loss surfaces without extra cost.
        # Pairs well with cosine_annealing and reduce_on_plateau.
        "params": {
            "lr": 1e-3,
            "weight_decay": 1e-5,
            "momentum_decay": 4e-3,
        },
    },
    "radam": {
        # RAdam - Rectified Adam (Liu et al., 2020). Warms up the adaptive
        # learning rate automatically by rectifying the variance of the second
        # moment, removing the need for a manual warmup scheduler.
        "params": {
            "lr": 1e-3,
            "weight_decay": 1e-5,
        },
    },
    "adamax": {
        # Adamax - Adam variant based on the infinity norm (Kingma & Ba, 2015).
        # More stable than Adam when gradients have very large or sparse
        # magnitudes; useful for models with embedding layers.
        "params": {
            "lr": 2e-3,
            "weight_decay": 1e-5,
            "betas": (0.9, 0.999),
            "eps": 1e-8,
        },
    },
    "adafactor": {
        # Adafactor - memory-efficient adaptive optimizer (Shazeer & Stern, 2018).
        # Factorises the second moment matrix to reduce memory to O(n + m) instead
        # of O(n*m). Recommended for large models where AdamW memory is prohibitive.
        # lr=None enables the built-in adaptive learning rate schedule - set
        # relative_step=True in that case. Using a fixed lr here for consistency
        # with the rest of the training pipeline.
        "params": {
            "lr": 1e-3,
            "weight_decay": 1e-5,
        },
    },
    "adagrad": {
        # Adagrad - per-parameter adaptive learning rate (Duchi et al., 2011).
        # Accumulates squared gradients, so the effective lr decays over time.
        # Useful for sparse features but tends to over-shrink lr on dense tasks.
        "params": {
            "lr": 1e-2,
            "weight_decay": 1e-5,
            "lr_decay": 0.0,
            "eps": 1e-10,
        },
    },
    "adadelta": {
        # Adadelta - extension of Adagrad that limits accumulated gradient window
        # (Zeiler, 2012). Eliminates the need to set a global lr (rho controls
        # the decay). Rarely the best choice but useful as a hyperparameter-free
        # baseline.
        "params": {
            "lr": 1.0,
            "weight_decay": 1e-5,
            "rho": 0.9,
            "eps": 1e-6,
        },
    },
    "rmsprop": {
        # RMSprop - Root Mean Square Propagation (Hinton, 2012). Divides
        # gradients by a running average of their recent magnitudes. Well-suited
        # to recurrent architectures and non-stationary objectives. Often
        # competitive with Adam on time-series tasks.
        "params": {
            "lr": 1e-3,
            "weight_decay": 1e-5,
            "alpha": 0.99,
            "momentum": 0.0,
            "eps": 1e-8,
        },
    },
    "rprop": {
        # Rprop - Resilient Backpropagation (Riedmiller & Braun, 1993).
        # Uses only the sign of the gradient and adjusts per-parameter step
        # sizes independently. Typically used for full-batch training; less
        # common in mini-batch settings but stable when batch size is large.
        # Note: weight_decay is not supported by Rprop - set to 0.
        "params": {
            "lr": 1e-2,
            "weight_decay": 0.0,
            "etas": (0.5, 1.2),
            "step_sizes": (1e-6, 50.0),
        },
    },
    "asgd": {
        # ASGD - Averaged Stochastic Gradient Descent (Polyak & Juditsky, 1992).
        # SGD with a running average of iterates applied after a warmup period
        # (t0). The averaging smooths the trajectory and can improve generalisation
        # over plain SGD, especially on convex-like objectives.
        "params": {
            "lr": 1e-2,
            "weight_decay": 1e-5,
            "lambd": 1e-4,
            "alpha": 0.75,
            "t0": 1e6,
        },
    },
    "sgd": {
        # SGD with momentum - the classic baseline. Can generalise better than
        # adaptive methods at large batch sizes. Pair with warmup_cosine or
        # warmup_multi_step; set momentum >= 0.9 for best results.
        "params": {
            "lr": 1e-2,
            "weight_decay": 1e-4,
            "momentum": 0.9,
        },
    },
    "muon": {
        # Muon - Momentum + orthogonalisation via Newton-Schulz iteration
        # (Kosson et al., 2024). Native in torch.optim since PyTorch 2.x.
        # Designed for hidden-layer weight matrices; typically converges
        # faster than AdamW on transformer-style models with 2D weight tensors.
        # Best paired with warmup_cosine. Should only be applied to
        # non-embedding, non-output parameters - set mu_params / sigma_params
        # in subclasses accordingly.
        "params": {
            "lr": 2e-2,
            "weight_decay": 0.0,
            "momentum": 0.95,
            "nesterov": True,
            "ns_steps": 6,
        },
    },
}

# Default scheduler configurations.
# All entries use only torch.optim.lr_scheduler built-ins.
# LambdaLR, SequentialLR, and ChainedScheduler are intentionally excluded
# from SCHEDULERS - they are used internally as building blocks within
# composite schedulers (warmup_cosine, warmup_multi_step).
SCHEDULERS = {
    "step": {
        # StepLR - decays lr by gamma every step_size epochs.
        # Simple and predictable; a good default for SGD.
        # step_size is computed as int(prob_step_size * max_epochs).
        "params": {
            "prob_step_size": 0.33,
            "gamma": 0.1,
        },
    },
    "multi_step": {
        # MultiStepLR - decays lr by gamma at each milestone epoch.
        # Milestones are computed from prob_decay_1 / prob_decay_2 fractions
        # of max_epochs so the schedule scales with training length.
        "params": {
            "milestones": [],  # Computed dynamically
            "prob_decay_1": 0.50,
            "prob_decay_2": 0.90,
            "gamma": 0.1,
        },
    },
    "multiplicative": {
        # MultiplicativeLR - multiplies lr by gamma every epoch.
        # Use gamma close to 1.0 (e.g. 0.95) for gradual decay.
        "params": {
            "gamma": 0.95,
        },
    },
    "exponential": {
        # ExponentialLR - decays lr by gamma every epoch.
        # Semantically identical to multiplicative but signals exponential
        # decay intent explicitly. Use gamma in [0.90, 0.99].
        "params": {
            "gamma": 0.95,
        },
    },
    "constant": {
        # ConstantLR - multiplies lr by factor for total_iters epochs then
        # restores the original lr. Useful as a cooldown or to hold lr at a
        # reduced level before a subsequent decay phase.
        # total_iters is computed as int(prob_total_iters * max_epochs).
        "params": {
            "factor": 0.1,
            "prob_total_iters": 0.1,
            "gamma": 0.1,  # Convention field - not used by ConstantLR directly
        },
    },
    "linear_decay": {
        # LinearLR - linearly interpolates lr from start_factor to end_factor
        # over total_iters epochs. start_factor < end_factor = warmup;
        # start_factor > end_factor = linear cooldown.
        # total_iters is computed as int(prob_total_iters * max_epochs).
        "params": {
            "start_factor": 1.0,
            "end_factor": 0.01,
            "prob_total_iters": 1.0,
            "gamma": 0.1,  # Convention field - not used by LinearLR directly
        },
    },
    "polynomial": {
        # PolynomialLR - decays lr using a polynomial function over
        # total_iters epochs. power=1.0 gives linear decay; power=2.0
        # quadratic. lr reaches 0 at total_iters.
        # total_iters is computed as int(prob_total_iters * max_epochs).
        "params": {
            "power": 1.0,
            "prob_total_iters": 1.0,
            "gamma": 0.1,  # Convention field - not used by PolynomialLR directly
        },
    },
    "cosine_annealing": {
        # CosineAnnealingWarmRestarts - periodic cosine restarts (Loshchilov &
        # Hutter, 2017). T_0 is computed as int(prob_T0 * max_epochs); each
        # subsequent cycle is T_mult times longer. Best for longer runs where
        # escaping sharp minima periodically is beneficial.
        "params": {
            "prob_T0": 0.25,
            "T_mult": 2,
            "eta_min": 1e-6,
            "gamma": 0.1,
        },
    },
    "cosine_annealing_lr": {
        # CosineAnnealingLR - single cosine decay from lr to eta_min over
        # max_epochs with no restarts. Simpler than warm restarts; good default
        # for fixed-budget training.
        "params": {
            "eta_min": 1e-6,
            "gamma": 0.1,  # Convention field - not used by CosineAnnealingLR directly
        },
    },
    "cyclic": {
        # CyclicLR - cycles lr between base_lr and max_lr according to the
        # triangular/cosine CLR policy (Smith, 2017). max_lr is derived as
        # base_lr * prob_max_lr_scale; step_size_up is int(prob_step_size_up *
        # max_epochs). Well-suited to SGD and RMSprop.
        "params": {
            "prob_max_lr_scale": 10.0,
            "prob_step_size_up": 0.1,
            "mode": "triangular2",
            "gamma": 0.1,  # Used directly when mode='exp_range'
        },
    },
    "reduce_on_plateau": {
        # ReduceLROnPlateau - reduces lr by factor when val_loss stops
        # improving for patience epochs. Robust when the optimal schedule
        # is unknown. patience is computed as int(prob_patience * max_epochs).
        "params": {
            "mode": "min",
            "factor": 0.1,
            "prob_patience": 0.1,
            "gamma": 0.1,
        },
    },
    "one_cycle": {
        # OneCycleLR - single cycle: warmup to max_lr then anneal (Smith &
        # Touvron, 2018). Requires estimated_stepping_batches from the Lightning
        # trainer; falls back to warmup_cosine if unavailable.
        # Best paired with adam or adamw.
        "params": {
            "max_lr": 1e-3,
            "pct_start": 0.3,
            "anneal_strategy": "cos",
            "gamma": 0.1,
        },
    },
    "warmup_multi_step": {
        # Composite: LambdaLR linear warmup → MultiStepLR decay.
        # Built from SequentialLR internally.
        "params": {
            "warmup_epochs": 5,
            "milestones": [],  # Computed dynamically
            "gamma": 0.1,
            "prob_decay_1": 0.50,
            "prob_decay_2": 0.90,
        },
    },
    "warmup_cosine": {
        # Composite: LambdaLR linear warmup → CosineAnnealingLR decay.
        # Built from SequentialLR internally. Recommended for SGD, RMSprop,
        # and Muon which are sensitive to the initial learning rate.
        # Also used as the fallback when one_cycle cannot compute total_steps.
        "params": {
            "warmup_epochs": 5,
            "eta_min": 1e-6,
            "gamma": 0.1,
        },
    },
}
