"""Embedding modules for time-series inputs.

Provides value embeddings (``LinearEmbedding``, ``ConvEmbedding``,
``PatchEmbedding``) and positional embeddings (``PositionalEmbedding``,
``LearnablePositionalEmbedding``, ``RotaryEmbedding``, ``TimeEmbedding``)
together with the ``DataEmbedding`` combiner.

All classes are registered via decorators so ``DataEmbedding`` can look
them up by name string (e.g. ``"PatchEmb"``, ``"RotaryEmb"``).
"""

from __future__ import annotations

from typing import cast

import torch
from torch import nn
import torch.nn.functional as F

# ─────────────────────────────────────────────────────────────────────────────
# Registries
# ─────────────────────────────────────────────────────────────────────────────

_VALUE_EMBEDDING_REGISTRY: dict[str, type[nn.Module]] = {}
_POSITIONAL_EMBEDDING_REGISTRY: dict[str, type[nn.Module]] = {}


def register_value_embedding(name: str):
    """Decorator that registers a value-embedding class under ``name``."""

    def decorator(cls: type[nn.Module]) -> type[nn.Module]:
        _VALUE_EMBEDDING_REGISTRY[name] = cls
        return cls

    return decorator


def register_positional_embedding(name: str):
    """Decorator that registers a positional-embedding class under ``name``."""

    def decorator(cls: type[nn.Module]) -> type[nn.Module]:
        _POSITIONAL_EMBEDDING_REGISTRY[name] = cls
        return cls

    return decorator


# ─────────────────────────────────────────────────────────────────────────────
# Positional embeddings
# ─────────────────────────────────────────────────────────────────────────────


@register_positional_embedding("TimeEmb")
class TimeEmbedding(nn.Module):
    """Project temporal features into a higher-dimensional space.

    Applies a linear transformation followed by ReLU independently to each
    time step, preserving batch and horizon dimensions.

    Args:
        in_features:  Input feature dimension per time step.
        out_features: Output feature dimension per time step.
    """

    def __init__(self, in_features: int, out_features: int) -> None:
        super().__init__()
        self.projection = nn.Linear(in_features, out_features)
        nn.init.kaiming_normal_(self.projection.weight, nonlinearity="relu")
        nn.init.constant_(self.projection.bias, 0)
        self.activation = nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Project temporal features.

        Args:
            x: Input tensor of shape ``(B, T, in_features)`` or ``(B, in_features)``.
               2-D inputs are returned unchanged.

        Returns:
            ``(B, T, out_features)`` for 3-D input; ``x`` unchanged for 2-D input.
        """
        if x.ndim <= 2:
            return x
        x_flat = x.contiguous().view(-1, x.size(-1))
        out = self.activation(self.projection(x_flat))
        return out.contiguous().view(x.size(0), -1, out.size(-1))


@register_positional_embedding("RotaryEmb")
class RotaryEmbedding(nn.Module):
    """Rotary positional embedding (RoPE).

    Encodes position by rotating pairs of dimensions in the embedding space.
    Supports both regular integer positions and irregular custom timestamps.

    Args:
        embed_dim:             Embedding dimension (must be >= 2, preferably even).
        max_seq_len:           Maximum sequence length for precomputed tables.
        rotary_base_frequency: Base frequency for the rotation schedule.
                               Defaults to ``10000.0``.
        seq_dim:               Tensor axis representing sequence length.
                               Defaults to ``-2``.
        device:                Device for precomputed buffers.

    Raises:
        ValueError: If ``embed_dim < 2`` or ``max_seq_len < 1``.

    Example::

        >>> rope = RotaryEmbedding(embed_dim=64, max_seq_len=128)
        >>> rope(torch.randn(32, 100, 64)).shape
        torch.Size([32, 100, 64])
    """

    def __init__(
        self,
        embed_dim: int,
        max_seq_len: int,
        rotary_base_frequency: float = 10000.0,
        seq_dim: int = -2,
        device: torch.device | None = None,
    ) -> None:
        super().__init__()
        if embed_dim < 2:
            raise ValueError(f"embed_dim must be at least 2, got {embed_dim}")
        if max_seq_len < 1:
            raise ValueError(f"max_seq_len must be at least 1, got {max_seq_len}")

        self.embed_dim = embed_dim
        self.max_seq_len = max_seq_len
        self.seq_dim = seq_dim

        freqs = 1.0 / (rotary_base_frequency ** (torch.arange(0, embed_dim, 2, dtype=torch.float) / embed_dim))
        self.register_buffer("freqs", freqs.to(device))
        self._precompute_rotation_tables(device)

    def _precompute_rotation_tables(self, device: torch.device | None) -> None:
        """Precompute cos/sin rotation tables up to ``max_seq_len``."""
        positions = torch.arange(self.max_seq_len, dtype=torch.float).unsqueeze(1)
        rotation_angles = positions * cast("torch.Tensor", self.freqs)
        self.register_buffer("cos", torch.cos(rotation_angles).to(device))
        self.register_buffer("sin", torch.sin(rotation_angles).to(device))

    def _extend_rotation_tables(self, seq_len: int, device: torch.device) -> None:
        """Grow rotation tables when a longer sequence is encountered."""
        self.max_seq_len = max(seq_len, int(self.max_seq_len * 1.5))
        self._precompute_rotation_tables(device)

    def forward(
        self,
        x: torch.Tensor,
        positions: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Apply rotary positional encodings.

        Args:
            x:         Input tensor of shape ``(..., seq_len, embed_dim)``.
            positions: Optional position indices / timestamps of shape
                       ``(seq_len,)`` or ``(B, seq_len)``.

        Returns:
            Rotated tensor with the same shape as ``x``.

        Raises:
            ValueError: On shape incompatibility.
        """
        seq_len = x.shape[self.seq_dim]
        device = x.device
        input_dim = x.shape[-1]

        if input_dim > self.embed_dim:
            x = x[..., : self.embed_dim]
        elif input_dim < self.embed_dim:
            raise ValueError(f"Input dim {input_dim} < RoPE embed_dim {self.embed_dim}")

        if positions is None:
            if seq_len > self.max_seq_len:
                self._extend_rotation_tables(seq_len, device)
            cos = cast("torch.Tensor", self.cos)[:seq_len]
            sin = cast("torch.Tensor", self.sin)[:seq_len]
        else:
            expected_shape = (seq_len,) if positions.dim() == 1 else (x.shape[0], seq_len)
            if positions.shape != expected_shape:
                raise ValueError(f"positions shape {positions.shape} != expected {expected_shape}")
            positions = positions.to(device).float()
            positions = positions.unsqueeze(1) if positions.dim() == 1 else positions.unsqueeze(-1)
            rotation_angles = positions * cast("torch.Tensor", self.freqs)
            cos = torch.cos(rotation_angles)
            sin = torch.sin(rotation_angles)

        even_components = x[..., 0::2]
        odd_components = x[..., 1::2]
        rotated_pairs = torch.stack(
            [even_components * cos - odd_components * sin, odd_components * cos + even_components * sin],
            dim=-1,
        )
        return rotated_pairs.view_as(x)


@register_positional_embedding("PosEmb")
class PositionalEmbedding(nn.Module):
    """Sinusoidal positional encodings (fixed, non-learnable).

    Args:
        hidden_size: Embedding dimension.
        max_len:     Maximum sequence length.  Defaults to ``5000``.

    Raises:
        ValueError: If ``hidden_size < 1`` or ``max_len < 1``.

    Example::

        >>> pe = PositionalEmbedding(hidden_size=64)
        >>> pe(torch.randn(32, 100, 64)).shape
        torch.Size([32, 100, 64])
    """

    def __init__(self, hidden_size: int, max_len: int = 5000) -> None:
        super().__init__()
        if hidden_size < 1:
            raise ValueError(f"hidden_size must be at least 1, got {hidden_size}")
        if max_len < 1:
            raise ValueError(f"max_len must be at least 1, got {max_len}")

        pe = torch.zeros(max_len, hidden_size, dtype=torch.float)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)

        num_even = (hidden_size + 1) // 2
        num_odd = hidden_size // 2

        div_term = torch.exp(
            torch.arange(0, hidden_size, 2, dtype=torch.float) * (-torch.log(torch.tensor(10000.0)) / hidden_size),
        )

        pe[:, 0::2] = torch.sin(position * div_term[:num_even])
        pe[:, 1::2] = torch.cos(position * div_term[:num_odd])
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Add sinusoidal encodings to ``x``.

        Args:
            x: Value-embedded tensor of shape ``(B, T, D)``.

        Returns:
            Position-encoded tensor of shape ``(B, T, D)``.
        """
        return x + cast("torch.Tensor", self.pe)[:, : x.size(1)]


@register_positional_embedding("LearnPosEmb")
class LearnablePositionalEmbedding(nn.Module):
    """Learnable positional encodings (optimised during training).

    Args:
        hidden_size: Embedding dimension.  Must be >= 1.
        max_len:     Maximum supported sequence length.  Defaults to ``5000``.

    Raises:
        ValueError: If ``hidden_size < 1`` or ``max_len < 1``.

    Attributes:
        pe: Learnable parameter of shape ``(1, max_len, hidden_size)``.

    Example::

        >>> pe = LearnablePositionalEmbedding(hidden_size=64, max_len=512)
        >>> pe(torch.randn(32, 100, 64)).shape
        torch.Size([32, 100, 64])
    """

    def __init__(self, hidden_size: int, max_len: int = 5000) -> None:
        super().__init__()
        if hidden_size < 1:
            raise ValueError(f"hidden_size must be at least 1, got {hidden_size}")
        if max_len < 1:
            raise ValueError(f"max_len must be at least 1, got {max_len}")

        self.pe = nn.Parameter(torch.empty(1, max_len, hidden_size))
        nn.init.trunc_normal_(self.pe, std=0.02)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Add learned encodings to ``x``.

        Args:
            x: Value-embedded tensor of shape ``(B, T, D)``.

        Returns:
            Position-encoded tensor of shape ``(B, T, D)``.

        Raises:
            ValueError: If ``x.size(1) > max_len``.
        """
        seq_len = x.size(1)
        if seq_len > self.pe.size(1):
            raise ValueError(
                f"Sequence length {seq_len} exceeds max_len {self.pe.size(1)}. Increase max_len at construction time.",
            )
        return x + self.pe[:, :seq_len]


# ─────────────────────────────────────────────────────────────────────────────
# Value embeddings
# ─────────────────────────────────────────────────────────────────────────────


@register_value_embedding("PatchEmb")
class PatchEmbedding(nn.Module):
    """Patch-based value embedding for time series ``(B, T, C)``.

    Divides the time axis into overlapping or non-overlapping windows of
    length ``patch_len`` with step ``stride``, then projects each window into
    a ``hidden_size``-dimensional token via a shared ``Conv1d``.

    The time axis is right-padded with the minimum number of zeros needed so
    no timestep is ever silently discarded.

    Two channel strategies are supported:

    * **Channel-independent** (default): each variate is patched separately,
      producing ``(B * C, N, D)``.
    * **Channel-mixing**: all variates are projected jointly,
      producing ``(B, N, D)``.

    Args:
        c_in:                Number of input channels.  Must be >= 1.
        hidden_size:         Patch token dimension ``D``.  Must be >= 1.
        patch_len:           Time steps per patch.  Defaults to ``16``.
        stride:              Step between consecutive patches.  Defaults to ``8``.
        channel_independent: Channel strategy.  Defaults to ``True``.

    Example::

        >>> emb = PatchEmbedding(c_in=7, hidden_size=64, patch_len=16, stride=8)
        >>> emb(torch.randn(32, 336, 7)).shape
        torch.Size([224, 41, 64])
    """

    def __init__(
        self,
        c_in: int,
        hidden_size: int,
        patch_len: int = 16,
        stride: int = 8,
        channel_independent: bool = True,
    ) -> None:
        super().__init__()
        if c_in < 1:
            raise ValueError(f"c_in must be at least 1, got {c_in}")
        if hidden_size < 1:
            raise ValueError(f"hidden_size must be at least 1, got {hidden_size}")
        if patch_len < 1:
            raise ValueError(f"patch_len must be at least 1, got {patch_len}")
        if stride < 1:
            raise ValueError(f"stride must be at least 1, got {stride}")

        self.patch_len = patch_len
        self.stride = stride
        self.channel_independent = channel_independent

        in_channels = 1 if channel_independent else c_in
        self.projection = nn.Conv1d(
            in_channels=in_channels,
            out_channels=hidden_size,
            kernel_size=patch_len,
            stride=stride,
            bias=False,
        )
        nn.init.kaiming_normal_(self.projection.weight, mode="fan_in", nonlinearity="leaky_relu")

    @staticmethod
    def num_patches(seq_len: int, patch_len: int, stride: int) -> int:
        """Compute the number of patch tokens for a given sequence length.

        Accounts for the same minimum right-padding applied in ``forward``.

        Args:
            seq_len:   Sequence length ``T`` before padding.
            patch_len: Window length per patch.
            stride:    Step between consecutive patches.

        Returns:
            Number of patch tokens ``N``.

        Raises:
            ValueError: If any argument is non-positive, or ``patch_len > seq_len``.

        Example::

            >>> PatchEmbedding.num_patches(336, patch_len=16, stride=8)
            41
        """
        if seq_len <= 0 or patch_len <= 0 or stride <= 0:
            raise ValueError("seq_len, patch_len, and stride must all be positive")
        if patch_len > seq_len:
            raise ValueError(f"patch_len ({patch_len}) must be <= seq_len ({seq_len})")
        right_pad = (stride - (seq_len - patch_len) % stride) % stride
        return (seq_len + right_pad - patch_len) // stride + 1

    def _apply_right_padding(self, x: torch.Tensor) -> torch.Tensor:
        """Right-pad the time axis so no timestep is discarded.

        Args:
            x: Input tensor of shape ``(B, T, C)``.

        Returns:
            Padded tensor of shape ``(B, T + right_pad, C)``.
        """
        t = x.size(1)
        right_pad = (self.stride - (t - self.patch_len) % self.stride) % self.stride
        if right_pad > 0:
            x = F.pad(x, (0, 0, 0, right_pad))
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Project the input into a sequence of patch tokens.

        Args:
            x: Input tensor of shape ``(B, T, C)``.

        Returns:
            ``(B * C, N, D)`` when ``channel_independent=True``;
            ``(B, N, D)`` otherwise.
        """
        batch_size, _, num_variates = x.shape
        x = self._apply_right_padding(x)

        if self.channel_independent:
            x = x.permute(0, 2, 1).reshape(batch_size * num_variates, 1, -1)
            x = self.projection(x)
            return x.transpose(1, 2)  # (B*C, N, D)

        x = x.permute(0, 2, 1)  # (B, C, T)
        x = self.projection(x)
        return x.transpose(1, 2)  # (B, N, D)


@register_value_embedding("ConvEmb")
class ConvEmbedding(nn.Module):
    """1-D convolutional token projection.

    Projects each time step into ``hidden_size`` dimensions using a circular-
    padded ``Conv1d`` with kernel size 3, preserving sequence length.

    Args:
        c_in:        Number of input channels.  Must be >= 1.
        hidden_size: Number of output channels.  Must be >= 1.

    Raises:
        ValueError: If ``c_in < 1`` or ``hidden_size < 1``.

    Example::

        >>> conv = ConvEmbedding(c_in=2, hidden_size=64)
        >>> conv(torch.randn(32, 100, 2)).shape
        torch.Size([32, 100, 64])
    """

    def __init__(self, c_in: int, hidden_size: int) -> None:
        super().__init__()
        if c_in < 1:
            raise ValueError(f"c_in must be at least 1, got {c_in}")
        if hidden_size < 1:
            raise ValueError(f"hidden_size must be at least 1, got {hidden_size}")
        self.projection = nn.Conv1d(
            in_channels=c_in,
            out_channels=hidden_size,
            kernel_size=3,
            padding=1,
            padding_mode="circular",
            bias=False,
        )
        nn.init.kaiming_normal_(self.projection.weight, mode="fan_in", nonlinearity="leaky_relu")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Apply the convolutional projection.

        Args:
            x: Input tensor of shape ``(B, T, C)``.

        Returns:
            Projected tensor of shape ``(B, T, D)``.
        """
        return self.projection(x.permute(0, 2, 1)).transpose(1, 2)


@register_value_embedding("LinearEmb")
class LinearEmbedding(nn.Module):
    """Point-wise linear projection of input features.

    Each time step is projected independently from ``c_in`` to ``hidden_size``
    dimensions - no temporal mixing is performed.

    Args:
        c_in:        Input feature dimension.  Must be >= 1.
        hidden_size: Output embedding dimension.  Must be >= 1.

    Raises:
        ValueError: If ``c_in < 1`` or ``hidden_size < 1``.

    Example::

        >>> lin = LinearEmbedding(c_in=2, hidden_size=64)
        >>> lin(torch.randn(32, 100, 2)).shape
        torch.Size([32, 100, 64])
    """

    def __init__(self, c_in: int, hidden_size: int) -> None:
        super().__init__()
        if c_in < 1:
            raise ValueError(f"c_in must be at least 1, got {c_in}")
        if hidden_size < 1:
            raise ValueError(f"hidden_size must be at least 1, got {hidden_size}")
        self.projection = nn.Linear(c_in, hidden_size, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Project each time step independently.

        Args:
            x: Input tensor of shape ``(B, T, C)``.

        Returns:
            Projected tensor of shape ``(B, T, D)``.
        """
        return self.projection(x)


# ─────────────────────────────────────────────────────────────────────────────
# DataEmbedding combiner
# ─────────────────────────────────────────────────────────────────────────────


class DataEmbedding(nn.Module):
    """Combine a value embedding and a positional embedding.

    Looks up embedding classes from the registries, builds them, and applies
    them sequentially.  Either component may be omitted (pass ``None``), but
    at least one must be specified.

    Args:
        c_in:             Number of input channels.  Must be >= 1.
        hidden_size:      Embedding output dimension.  Must be >= 1.
        value_embed_type: Value embedding name or ``None``.
                          One of ``{"ConvEmb", "LinearEmb", "PatchEmb", None}``.
                          Defaults to ``"ConvEmb"``.
        pos_embed_type:   Positional embedding name or ``None``.
                          One of ``{"RotaryEmb", "PosEmb", "LearnPosEmb", None}``.
                          Defaults to ``None``.
        max_seq_len:      Maximum sequence length for positional embeddings.
        dropout:          Dropout probability.  Defaults to ``0.1``.
        rope_theta:       Base frequency for ``RotaryEmbedding``.
        patch_len:        Patch window length (only used with ``"PatchEmb"``).
        stride:           Patch stride (only used with ``"PatchEmb"``).

    Example::

        >>> embed = DataEmbedding(c_in=2, hidden_size=64, pos_embed_type="RotaryEmb")
        >>> embed(torch.randn(32, 100, 2)).shape
        torch.Size([32, 100, 64])
    """

    def __init__(
        self,
        c_in: int,
        hidden_size: int,
        value_embed_type: str | None = "ConvEmb",
        pos_embed_type: str | None = None,
        max_seq_len: int = 128,
        dropout: float = 0.1,
        rope_theta: float = 10000.0,
        patch_len: int = 16,
        stride: int = 8,
    ) -> None:
        super().__init__()
        if c_in < 1:
            raise ValueError(f"c_in must be at least 1, got {c_in}")
        if hidden_size < 1:
            raise ValueError(f"hidden_size must be at least 1, got {hidden_size}")
        if max_seq_len < 1:
            raise ValueError(f"max_seq_len must be at least 1, got {max_seq_len}")

        self.value_embed_type = value_embed_type
        self.pos_embed_type = pos_embed_type
        # Apply defaults for patch params when not explicitly provided
        patch_len = patch_len or 16
        stride = stride or 8
        self.value_embedding = self._build_value_embedding(value_embed_type, c_in, hidden_size, patch_len, stride)
        self.pos_embedding = self._build_positional_embedding(
            pos_embed_type,
            c_in,
            hidden_size,
            max_seq_len,
            rope_theta,
        )
        self.dropout = nn.Dropout(p=dropout)

    def _build_value_embedding(
        self,
        embed_type: str | None,
        c_in: int,
        hidden_size: int,
        patch_len: int,
        stride: int,
    ) -> nn.Module | None:
        """Instantiate and return the requested value-embedding module."""
        if embed_type is None:
            return None
        embedding_cls = _VALUE_EMBEDDING_REGISTRY.get(embed_type)
        if embedding_cls is None:
            raise ValueError(f"Unknown value_embed_type: '{embed_type}'")
        if embed_type == "PatchEmb":
            return embedding_cls(c_in=c_in, hidden_size=hidden_size, patch_len=patch_len, stride=stride)
        return embedding_cls(c_in=c_in, hidden_size=hidden_size)

    def _build_positional_embedding(
        self,
        embed_type: str | None,
        c_in: int,
        hidden_size: int,
        max_seq_len: int,
        rope_theta: float,
    ) -> nn.Module | None:

        if embed_type is None:
            return None
        embedding_cls = _POSITIONAL_EMBEDDING_REGISTRY.get(embed_type)
        if embedding_cls is None:
            raise ValueError(f"Unknown pos_embed_type: '{embed_type}'")

        # When no value embedding is used the raw input (c_in dims) flows
        # directly into the positional embedding, so it must be sized to c_in
        # rather than hidden_size to avoid a dimension mismatch on addition.
        effective_dim = c_in if self.value_embedding is None else hidden_size

        if embed_type == "RotaryEmb":
            return embedding_cls(
                embed_dim=effective_dim,
                max_seq_len=max_seq_len,
                rotary_base_frequency=rope_theta,
            )
        return embedding_cls(hidden_size=effective_dim, max_len=max_seq_len)

    def forward(
        self,
        x: torch.Tensor,
        positions: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Apply value and positional embeddings then dropout.

        Args:
            x:         Input tensor of shape ``(B, T, c_in)``.
            positions: Optional position tensor for ``RotaryEmbedding``.
                       Shape ``(T,)`` or ``(B, T)``.

        Returns:
            Embedded tensor of shape ``(B, T, hidden_size)``.

        Raises:
            ValueError: If both embeddings are ``None``.
        """
        if self.value_embedding is None and self.pos_embedding is None:
            raise ValueError("At least one of value_embed_type or pos_embed_type must be specified.")

        out = x
        if self.value_embedding is not None:
            out = self.value_embedding(out)
        if self.pos_embedding is not None:
            out = (
                self.pos_embedding(out, positions=positions)
                if isinstance(self.pos_embedding, RotaryEmbedding)
                else self.pos_embedding(out)
            )
        return self.dropout(out)
