"""Neural network forecasting models for Twiga.

Requires the ``torch`` and ``lightning`` extras::

    pip install 'twiga[torch,lightning]'
"""

__all__: list[str] = []

try:
    # ── Point models ──────────────────────────────────────────────────────────
    from twiga.models.nn.mlpf_model import MLPFConfig, MLPFModel
    from twiga.models.nn.mlpfbeta_model import MLPFBetaConfig, MLPFBetaModel
    from twiga.models.nn.mlpffpqr_model import MLPFFPQRConfig, MLPFFPQRModel
    from twiga.models.nn.mlpfgamma_model import MLPFGammaConfig, MLPFGammaModel
    from twiga.models.nn.mlpflaplace_model import MLPFLaplaceConfig, MLPFLaplaceModel
    from twiga.models.nn.mlpflognormal_model import MLPFLogNormalConfig, MLPFLogNormalModel
    from twiga.models.nn.mlpfnormal_model import MLPFNormalConfig, MLPFNormalModel
    from twiga.models.nn.mlpfqr_model import MLPFQRConfig, MLPFQRModel
    from twiga.models.nn.mlpfstudentt_model import MLPFStudentTConfig, MLPFStudentTModel

    # ── MLPGAF models ─────────────────────────────────────────────────────────
    from twiga.models.nn.mlpgaf_model import MLPGAFConfig, MLPGAFModel
    from twiga.models.nn.mlpgafbeta_model import MLPGAFBetaConfig, MLPGAFBetaModel
    from twiga.models.nn.mlpgaffpqr_model import MLPGAFFPQRConfig, MLPGAFFPQRModel
    from twiga.models.nn.mlpgafgamma_model import MLPGAFGammaConfig, MLPGAFGammaModel
    from twiga.models.nn.mlpgaflaplace_model import MLPGAFLaplaceConfig, MLPGAFLaplaceModel
    from twiga.models.nn.mlpgaflognormal_model import MLPGAFLogNormalConfig, MLPGAFLogNormalModel
    from twiga.models.nn.mlpgafnormal_model import MLPGAFNormalConfig, MLPGAFNormalModel
    from twiga.models.nn.mlpgafqr_model import MLPGAFQRConfig, MLPGAFQRModel
    from twiga.models.nn.mlpgafstudentt_model import MLPGAFStudentTConfig, MLPGAFStudentTModel

    # ── MLPGAM models ─────────────────────────────────────────────────────────
    from twiga.models.nn.mlpgam_model import MLPGAMConfig, MLPGAMModel
    from twiga.models.nn.mlpgambeta_model import MLPGAMBetaConfig, MLPGAMBetaModel
    from twiga.models.nn.mlpgamfpqr_model import MLPGAMFPQRConfig, MLPGAMFPQRModel
    from twiga.models.nn.mlpgamgamma_model import MLPGAMGammaConfig, MLPGAMGammaModel
    from twiga.models.nn.mlpgamlaplace_model import MLPGAMLaplaceConfig, MLPGAMLaplaceModel
    from twiga.models.nn.mlpgamlognormal_model import MLPGAMLogNormalConfig, MLPGAMLogNormalModel
    from twiga.models.nn.mlpgamnormal_model import MLPGAMNormalConfig, MLPGAMNormalModel
    from twiga.models.nn.mlpgamqr_model import MLPGAMQRConfig, MLPGAMQRModel
    from twiga.models.nn.mlpgamstudentt_model import MLPGAMStudentTConfig, MLPGAMStudentTModel

    # ── N-HiTS ────────────────────────────────────────────────────────────────
    from twiga.models.nn.nhits_model import NHITSConfig, NHITSModel

    # ── RNN ───────────────────────────────────────────────────────────────────
    from twiga.models.nn.rnn_model import RNNConfig, RNNModel
    from twiga.models.nn.rnnbeta_model import RNNBetaConfig, RNNBetaModel
    from twiga.models.nn.rnngamma_model import RNNGammaConfig, RNNGammaModel
    from twiga.models.nn.rnnlaplace_model import RNNLaplaceConfig, RNNLaplaceModel
    from twiga.models.nn.rnnlognormal_model import RNNLogNormalConfig, RNNLogNormalModel
    from twiga.models.nn.rnnnormal_model import RNNNormalConfig, RNNNormalModel
    from twiga.models.nn.rnnqr_model import RNNFPQRConfig, RNNFPQRModel, RNNQRConfig, RNNQRModel
    from twiga.models.nn.rnnstudentt_model import RNNStudentTConfig, RNNStudentTModel

    __all__ += [
        # MLPF
        "MLPFConfig",
        "MLPFModel",
        "MLPFNormalConfig",
        "MLPFNormalModel",
        "MLPFLaplaceConfig",
        "MLPFLaplaceModel",
        "MLPFLogNormalConfig",
        "MLPFLogNormalModel",
        "MLPFGammaConfig",
        "MLPFGammaModel",
        "MLPFBetaConfig",
        "MLPFBetaModel",
        "MLPFStudentTConfig",
        "MLPFStudentTModel",
        "MLPFQRConfig",
        "MLPFQRModel",
        "MLPFFPQRConfig",
        "MLPFFPQRModel",
        # MLPGAM
        "MLPGAMConfig",
        "MLPGAMModel",
        "MLPGAMNormalConfig",
        "MLPGAMNormalModel",
        "MLPGAMLaplaceConfig",
        "MLPGAMLaplaceModel",
        "MLPGAMLogNormalConfig",
        "MLPGAMLogNormalModel",
        "MLPGAMGammaConfig",
        "MLPGAMGammaModel",
        "MLPGAMBetaConfig",
        "MLPGAMBetaModel",
        "MLPGAMStudentTConfig",
        "MLPGAMStudentTModel",
        "MLPGAMQRConfig",
        "MLPGAMQRModel",
        "MLPGAMFPQRConfig",
        "MLPGAMFPQRModel",
        # MLPGAF
        "MLPGAFConfig",
        "MLPGAFModel",
        "MLPGAFNormalConfig",
        "MLPGAFNormalModel",
        "MLPGAFLaplaceConfig",
        "MLPGAFLaplaceModel",
        "MLPGAFLogNormalConfig",
        "MLPGAFLogNormalModel",
        "MLPGAFGammaConfig",
        "MLPGAFGammaModel",
        "MLPGAFBetaConfig",
        "MLPGAFBetaModel",
        "MLPGAFStudentTConfig",
        "MLPGAFStudentTModel",
        "MLPGAFQRConfig",
        "MLPGAFQRModel",
        "MLPGAFFPQRConfig",
        "MLPGAFFPQRModel",
        # N-HiTS
        "NHITSConfig",
        "NHITSModel",
        # RNN
        "RNNConfig",
        "RNNModel",
        "RNNNormalConfig",
        "RNNNormalModel",
        "RNNLaplaceConfig",
        "RNNLaplaceModel",
        "RNNLogNormalConfig",
        "RNNLogNormalModel",
        "RNNGammaConfig",
        "RNNGammaModel",
        "RNNBetaConfig",
        "RNNBetaModel",
        "RNNStudentTConfig",
        "RNNStudentTModel",
        "RNNQRConfig",
        "RNNQRModel",
        "RNNFPQRConfig",
        "RNNFPQRModel",
        # CRC variants must be imported directly (circular import via residual_conformal)
    ]
except ImportError:
    pass
