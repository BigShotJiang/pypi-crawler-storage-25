"""MLPGAM flexible-quantile regression model configuration and experiment wrapper."""

from __future__ import annotations

from typing import Literal

import optuna
import torch

from twiga.core.config import BaseSearchSpace, Field
from twiga.models.nn.core.base import BaseNeuralForecast
from twiga.models.nn.mlpgam_model import MLPGAMConfig
from twiga.models.nn.prob.mlpgamfpqr import MLPGAMFPQR


class MLPGAMFPQRConfig(MLPGAMConfig):
    """Configuration for the MLPGAM flexible quantile proposal forecasting model.

    Extends :class:`MLPGAMConfig` with FPQR-specific parameters. Unlike
    fixed-grid quantile regression, this model adaptively proposes its own
    quantile grid during training via :class:`FPQRDistribution`.

    Attributes:
        name: Fixed model identifier.
        n_quantiles: Number of quantile levels for the proposal network.
        conf_level: Confidence level for symmetric interval construction.
        loss_fn: Pinball or Huber-pinball quantile loss.
        kappa: Huber transition parameter (only relevant for 'huber-pinball').
        num_cosines: Cosine basis functions for the quantile embedding layer.
        search_space: Optuna hyperparameter search space.
    """

    name: Literal["mlpgamfpqr"] = Field(  # type: ignore[assignment]
        default="mlpgamfpqr",
        description="Fixed model identifier.",
        alias="model_name",
        exclude=True,
    )

    # ── FPQR-specific ─────────────────────────────────────────────────────────
    n_quantiles: int = Field(9, description="Number of quantile levels for the proposal network.")
    conf_level: float = Field(0.05, description="Confidence level for quantile bounds.")
    loss_fn: Literal["pinball", "huber-pinball"] = Field("pinball", description="Quantile loss function.")
    kappa: float = Field(0.25, description="Huber transition parameter.")
    num_cosines: int = Field(32, description="Cosine basis functions in the quantile embedding layer.")

    # ── Search space ──────────────────────────────────────────────────────────
    search_space: BaseSearchSpace = Field(
        default=BaseSearchSpace(  # type: ignore[call-arg]
            latent_size=[64, 128, 256],
            hidden_dim=[64, 128, 256, 512],
            num_layers=(2, 5),
            width_multiplier=[0.5, 1.0, 1.5, 2.0, 3.0],
            embedding_size=[8, 16, 28, 32],
            value_embed_type=[None, "LinearEmb", "ConvEmb"],
            embedding_type=[None, "PosEmb", "LearnPosEmb"],
            dropout=(0.05, 0.35),
            alpha=(0.05, 0.4),
            use_norm=[False, True],
            use_bias=[True],
            use_residual=[False, True],
            activation_function=["SiLU", "ELU", "LeakyReLU"],
            lambda_lasso=(1e-7, 1e-4),
            n_quantiles=[7, 9, 15, 21],
            kappa=(0.01, 1.0),
            loss_fn=["pinball", "huber-pinball"],
            num_cosines=[16, 32, 64],
        ),
        description="Optuna hyperparameter search space.",
        exclude=True,
    )


class MLPGAMFPQRModel(BaseNeuralForecast):
    """Training lifecycle wrapper for flexible quantile proposal regression (:class:`MLPGAMFPQR`).

    Instantiates :class:`~twiga.models.nn.prob.mlpgamfpqr.MLPGAMFPQR` from an
    :class:`MLPGAMFPQRConfig`, manages training via PyTorch Lightning, and
    supports Optuna hyperparameter optimisation.

    Example:
        >>> config = MLPGAMFPQRConfig(
        ...     num_target_feature=1,
        ...     num_historical_features=5,
        ...     forecast_horizon=24,
        ...     lookback_window_size=96,
        ...     n_quantiles=9,
        ... )
        >>> model = MLPGAMFPQRModel(model_config=config)
    """

    def __init__(self, model_config: MLPGAMFPQRConfig) -> None:
        super().__init__(
            rich_progress_bar=model_config.rich_progress_bar,
            wandb_logging=model_config.wandb_logging,
            drop_last=model_config.drop_last,
            num_workers=model_config.num_workers,
            batch_size=model_config.batch_size,
            pin_memory=model_config.pin_memory,
            max_epochs=model_config.max_epochs,
            seed=model_config.seed,
            patience=model_config.patience,
            resume_training=model_config.resume_training,
        )
        self.model_config = model_config
        self._init_model()

    def _init_model(self) -> None:
        cfg = self.model_config
        self.model = MLPGAMFPQR(
            # Feature counts
            num_target_feature=cfg.num_target_feature,
            num_historical_features=cfg.num_historical_features,
            num_calendar_features=cfg.num_calendar_features,
            num_exogenous_features=cfg.num_exogenous_features,
            num_future_covariates=cfg.num_future_covariates,
            # Sequence dimensions
            forecast_horizon=cfg.forecast_horizon,
            lookback_window_size=cfg.lookback_window_size,
            # Embedding
            embedding_size=cfg.embedding_size,
            embedding_type=cfg.embedding_type,
            value_embed_type=cfg.value_embed_type,
            # Architecture flags
            use_norm=cfg.use_norm,
            use_bias=cfg.use_bias,
            use_residual=cfg.use_residual,
            use_temporal_mixer=cfg.use_temporal_mixer,
            # Encoder dimensions
            latent_size=cfg.latent_size,
            hidden_dim=cfg.hidden_dim,
            width_multiplier=cfg.width_multiplier,
            num_layers=cfg.num_layers,
            # Activation & regularisation
            activation_function=cfg.activation_function,
            dropout=cfg.dropout,
            alpha=cfg.alpha,
            lambda_lasso=cfg.lambda_lasso,
            # FPQR
            n_quantiles=cfg.n_quantiles,
            conf_level=cfg.conf_level,
            loss_fn=cfg.loss_fn,
            kappa=cfg.kappa,
            num_cosines=cfg.num_cosines,
            # Training
            metric=cfg.metric,
            optimizer_type=cfg.optimizer_type,
            lr_scheduler_type=cfg.lr_scheduler_type,
            optimizer_params=cfg.optimizer_params,
            scheduler_params=cfg.scheduler_params,
            max_epochs=cfg.max_epochs,
        )

    def update(self, trial: optuna.Trial) -> None:
        params = self.model_config.get_optuna_params(trial=trial)
        self.model_config = MLPGAMFPQRConfig(**params)
        self.batch_size = self.model_config.batch_size
        self.max_epochs = self.model_config.max_epochs
        self._init_model()

    def load_checkpoint(self) -> None:  # type: ignore[override]
        self._load_checkpoints(model_instance=MLPGAMFPQR)  # type: ignore[arg-type]
        self.model.eval()
