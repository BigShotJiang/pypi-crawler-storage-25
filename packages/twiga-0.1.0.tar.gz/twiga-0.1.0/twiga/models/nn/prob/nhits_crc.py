"""NHiTS Conditional Residual Calibration model."""

from __future__ import annotations

import torch
from torch import nn

from twiga.distributions.nn.residual_conformal import CRCDistribution
from twiga.models.nn.net.nhits import NHITSNetwork
from twiga.models.nn.prob.core import ProbabilisticModel

_BACKBONE_KEYS = frozenset(
    {
        "num_target_feature",
        "num_historical_features",
        "num_calendar_features",
        "num_exogenous_features",
        "num_future_covariates",
        "forecast_horizon",
        "lookback_window_size",
        "activation_function",
        "dropout",
        "alpha",
        "stack_types",
        "n_blocks",
        "mlp_units",
        "n_pool_kernel_size",
        "n_freq_downsample",
        "pooling_mode",
        "interpolation_mode",
        "encode_size",
    },
)


def _backbone_kw(loc: dict) -> dict:
    kw = {k: v for k, v in loc.items() if k in _BACKBONE_KEYS}
    kw["out_activation_function"] = "Identity"
    kw["decompose_forecast"] = False
    return kw


class NHITSCrc(ProbabilisticModel):
    """NHiTS + Conditional Residual Calibration.

    Pairs :class:`~twiga.models.nn.net.nhits.NHITSNetwork` with
    :class:`~twiga.distributions.nn.residual_conformal.CRCDistribution`.
    The mean is projected from the latent via a linear layer; the scale MLP
    is conditioned on the detached mean to approximate absolute residuals.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        activation_function: str = "ReLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        stack_types: list | None = None,
        n_blocks: list | None = None,
        mlp_units: list | None = None,
        n_pool_kernel_size: list | None = None,
        n_freq_downsample: list | None = None,
        pooling_mode: str = "MaxPool1d",
        interpolation_mode: str = "linear",
        encode_size: int = 256,
        crc_alpha: float = 0.1,
        crc_activation: str = "ReLU",
        dist_out_activation: nn.Module | None = None,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=NHITSNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=CRCDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
                "alpha": crc_alpha,
                "activation": crc_activation,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:  # type: ignore[override]
        """Return ``(mu, sigma)`` at inference time."""
        z = self.model.backbone.encode(x)  # type: ignore[operator, union-attr]
        return self.model.head.forecast(z)  # type: ignore[operator, union-attr]
