"""RNN quantile regression models - thin wrappers using ProbabilisticModel."""

from __future__ import annotations

from typing import Literal

import torch

from twiga.distributions.nn.fpquantile import FPQRDistribution
from twiga.distributions.nn.quantile import QRDistribution
from twiga.models.nn.net.rnn import RNNForecastNetwork
from twiga.models.nn.prob.core import ProbabilisticModel

# ── Backbone kwarg keys ───────────────────────────────────────────────────────

_BACKBONE_KEYS = frozenset(
    {
        "num_target_feature",
        "num_historical_features",
        "num_calendar_features",
        "num_exogenous_features",
        "num_future_covariates",
        "forecast_horizon",
        "lookback_window_size",
        "hidden_size",
        "n_layers",
        "cell_type",
        "bidirectional",
        "dropout",
        "alpha",
    },
)


def _backbone_kw(loc: dict) -> dict:
    """Extract backbone kwargs from an ``__init__`` locals() dict."""
    kw = {k: v for k, v in loc.items() if k in _BACKBONE_KEYS}
    kw["out_activation_function"] = "Identity"  # distribution head owns activation
    return kw


# ── RNNQR ─────────────────────────────────────────────────────────────────────


class RNNQR(ProbabilisticModel):
    """RNN + fixed-grid quantile regression.

    Pairs :class:`~twiga.models.nn.net.rnn.RNNForecastNetwork` with
    :class:`~twiga.distributions.nn.quantile.QRDistribution`.

    Args:
        num_target_feature (int): Number of target series to predict.
        num_historical_features (int): Number of historical features.
        num_calendar_features (int): Number of calendar features.
        num_exogenous_features (int): Number of exogenous features.
        num_future_covariates (int): Number of future covariates.
        forecast_horizon (int): Number of future time steps to forecast.
        lookback_window_size (int): Size of the historical input window.
        hidden_size (int, optional): RNN hidden state width. Defaults to 128.
        n_layers (int, optional): Number of stacked RNN layers. Defaults to 2.
        cell_type (str, optional): ``"gru"`` or ``"lstm"``. Defaults to ``"gru"``.
        bidirectional (bool, optional): Bidirectional RNN. Defaults to False.
        dropout (float, optional): Dropout probability. Defaults to 0.25.
        alpha (float, optional): MSE/MAE mixture weight. Defaults to 0.1.
        quantiles (list[float], optional): Fixed quantile levels. Defaults to
            ``[0.1, ..., 0.9]`` plus ``conf_level`` bounds.
        conf_level (float, optional): Significance level. Defaults to 0.05.
        loss_fn (str, optional): ``"pinball"`` or ``"huber-pinball"``. Defaults to
            ``"pinball"``.
        kappa (float, optional): Smoothing kappa for the pinball loss. Defaults to 0.5.
        eps (float, optional): Numerical stability epsilon. Defaults to 1e-6.
        metric (str, optional): Training metric. Defaults to ``"mae"``.
        optimizer_type (str, optional): Optimizer name. Defaults to None.
        lr_scheduler_type (str, optional): Scheduler name. Defaults to None.
        optimizer_params (dict, optional): Optimizer overrides. Defaults to None.
        scheduler_params (dict, optional): Scheduler overrides. Defaults to None.
        max_epochs (int, optional): Maximum training epochs. Defaults to 10.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        hidden_size: int = 128,
        n_layers: int = 2,
        cell_type: Literal["gru", "lstm"] = "gru",
        bidirectional: bool = False,
        dropout: float = 0.25,
        alpha: float = 0.1,
        out_activation_function: str = "Identity",  # accepted but ignored; head owns activation
        quantiles: list[float] | None = None,
        conf_level: float = 0.05,
        loss_fn: str = "pinball",
        kappa: float = 0.5,
        eps: float = 1e-6,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=RNNForecastNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=QRDistribution,
            head_kwargs={
                "quantiles": quantiles,
                "num_outputs": num_target_feature,
                "horizon": forecast_horizon,
                "eps": eps,
                "kappa": kappa,
                "conf_level": conf_level,
                "loss_fn": loss_fn,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            optimizer_params=optimizer_params,
            lr_scheduler_type=lr_scheduler_type,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()

    def forward(self, x: torch.Tensor) -> dict:  # type: ignore[override]
        """Return forecast dict with ``loc`` and ``quantiles`` at inference time.

        Args:
            x: Input tensor of shape ``(B, lookback + horizon, num_features)``.

        Returns:
            Dict with keys ``loc``, ``quantiles``, ``conf_level``, ``quantile_levels``.
        """
        z = self.model.backbone.encode(x)  # type: ignore[operator, union-attr]
        return self.model.head.forecast(z)  # type: ignore[operator, union-attr]


# ── RNNFPQR ───────────────────────────────────────────────────────────────────


class RNNFPQR(ProbabilisticModel):
    """RNN + flexible-proposal quantile regression.

    Pairs :class:`~twiga.models.nn.net.rnn.RNNForecastNetwork` with
    :class:`~twiga.distributions.nn.fpquantile.FPQRDistribution`, which
    adaptively proposes quantile levels during training.

    Args:
        num_target_feature (int): Number of target series to predict.
        num_historical_features (int): Number of historical features.
        num_calendar_features (int): Number of calendar features.
        num_exogenous_features (int): Number of exogenous features.
        num_future_covariates (int): Number of future covariates.
        forecast_horizon (int): Number of future time steps to forecast.
        lookback_window_size (int): Size of the historical input window.
        hidden_size (int, optional): RNN hidden state width. Defaults to 128.
        n_layers (int, optional): Number of stacked RNN layers. Defaults to 2.
        cell_type (str, optional): ``"gru"`` or ``"lstm"``. Defaults to ``"gru"``.
        bidirectional (bool, optional): Bidirectional RNN. Defaults to False.
        dropout (float, optional): Dropout probability. Defaults to 0.25.
        alpha (float, optional): MSE/MAE mixture weight. Defaults to 0.1.
        n_quantiles (int, optional): Number of quantile proposals. Defaults to 9.
        conf_level (float, optional): Significance level. Defaults to 0.05.
        loss_fn (str, optional): ``"pinball"`` or ``"huber-pinball"``. Defaults to
            ``"pinball"``.
        kappa (float, optional): Smoothing kappa for the pinball loss. Defaults to 0.25.
        num_cosines (int, optional): Cosine features for tau embedding. Defaults to 32.
        metric (str, optional): Training metric. Defaults to ``"mae"``.
        optimizer_type (str, optional): Optimizer name. Defaults to None.
        lr_scheduler_type (str, optional): Scheduler name. Defaults to None.
        optimizer_params (dict, optional): Optimizer overrides. Defaults to None.
        scheduler_params (dict, optional): Scheduler overrides. Defaults to None.
        max_epochs (int, optional): Maximum training epochs. Defaults to 10.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        hidden_size: int = 128,
        n_layers: int = 2,
        cell_type: Literal["gru", "lstm"] = "gru",
        bidirectional: bool = False,
        dropout: float = 0.25,
        alpha: float = 0.1,
        out_activation_function: str = "Identity",  # accepted but ignored; head owns activation
        n_quantiles: int = 9,
        conf_level: float = 0.05,
        loss_fn: str = "pinball",
        kappa: float = 0.25,
        num_cosines: int = 32,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=RNNForecastNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=FPQRDistribution,
            head_kwargs={
                "n_quantiles": n_quantiles,
                "num_outputs": num_target_feature,
                "horizon": forecast_horizon,
                "dropout": dropout,
                "conf_level": conf_level,
                "kappa": kappa,
                "num_cosines": num_cosines,
                "loss_fn": loss_fn,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            optimizer_params=optimizer_params,
            lr_scheduler_type=lr_scheduler_type,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()

    def forward(self, x: torch.Tensor) -> dict:  # type: ignore[override]
        """Return forecast dict with ``loc`` and ``quantiles`` at inference time.

        Args:
            x: Input tensor of shape ``(B, lookback + horizon, num_features)``.

        Returns:
            Dict with keys ``loc``, ``quantiles``, ``conf_level``, ``quantile_levels``.
        """
        z = self.model.backbone.encode(x)  # type: ignore[operator, union-attr]
        return self.model.head.forecast(z)  # type: ignore[operator, union-attr]
