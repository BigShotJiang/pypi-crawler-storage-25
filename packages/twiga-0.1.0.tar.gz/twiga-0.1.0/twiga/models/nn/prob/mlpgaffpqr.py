"""MLPGAF flexible-quantile regression model - thin wrapper using ProbabilisticModel."""

from __future__ import annotations

import torch

from twiga.distributions.nn.fpquantile import FPQRDistribution
from twiga.models.nn.net.mlpfgaf import MLPGAFNetwork
from twiga.models.nn.prob.core import ProbabilisticModel

# ── Backbone kwarg keys ───────────────────────────────────────────────────────

_BACKBONE_KEYS = frozenset(
    {
        "num_target_feature",
        "num_historical_features",
        "num_calendar_features",
        "num_exogenous_features",
        "num_future_covariates",
        "forecast_horizon",
        "lookback_window_size",
        "embedding_size",
        "embedding_type",
        "value_embed_type",
        "use_norm",
        "use_bias",
        "use_residual",
        "use_revin",
        "use_temporal_mixer",
        "num_layers",
        "latent_size",
        "hidden_dim",
        "width_multiplier",
        "patch_len",
        "stride",
        "activation_function",
        "dropout",
        "alpha",
        "lambda_weight",
        "lambda_gate",
        "delta",
        "gate_scale",
        "gate_type",
        "warmup_epochs",
    },
)


def _backbone_kw(loc: dict) -> dict:
    """Extract backbone kwargs from an ``__init__`` locals() dict."""
    kw = {k: v for k, v in loc.items() if k in _BACKBONE_KEYS}
    kw["out_activation_function"] = "Identity"
    return kw


# ── MLPGAFFPQR ───────────────────────────────────────────────────────────────


class MLPGAFFPQR(ProbabilisticModel):
    """MLPGAF + flexible-proposal quantile regression.

    Pairs :class:`~twiga.models.nn.net.mlpfgaf.MLPGAFNetwork` with
    :class:`~twiga.distributions.nn.fpquantile.FPQRDistribution`, which
    adaptively proposes quantile levels during training rather than using a
    fixed grid.  The GAF backbone includes learned feature gating;
    regularisation penalties (gate_penalty, weight_penalty) are automatically
    logged via :class:`~twiga.models.nn.prob.core.ProbabilisticModel`.

    Args:
        n_quantiles: Number of quantile proposals. Defaults to 9.
        conf_level: Significance level for quantile bounds. Defaults to 0.05.
        kappa: Smoothing kappa for the pinball loss. Defaults to 0.25.
        num_cosines: Cosine features for tau embedding. Defaults to 32.
        loss_fn: ``'pinball'`` or ``'huber-pinball'``. Defaults to ``'pinball'``.
        lambda_weight: Weight L2 regularisation penalty. Defaults to 1e-6.
        lambda_gate: Gate sparsity regularisation penalty. Defaults to 1e-2.
        delta: Gate smoothing delta. Defaults to 1e-2.
        gate_scale: Gate sigmoid scale factor. Defaults to 5.0.
        gate_type: Gate activation type (``'sigmoid'`` or ``'hard'``). Defaults to ``'sigmoid'``.
        warmup_epochs: Epochs before gate regularisation is applied. Defaults to 10.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        n_quantiles: int = 9,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str | None = "ConvEmb",
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = True,
        use_revin: bool = True,
        use_temporal_mixer: bool = False,
        num_layers: int = 2,
        latent_size: int = 128,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        patch_len: int | None = None,
        stride: int | None = None,
        activation_function: str = "SiLU",
        out_activation_function: str = "Identity",  # accepted but ignored; head owns activation
        dropout: float = 0.25,
        alpha: float = 0.1,
        lambda_weight: float = 1e-6,
        lambda_gate: float = 1e-2,
        delta: float = 1e-2,
        gate_scale: float = 5.0,
        gate_type: str = "sigmoid",
        warmup_epochs: int = 10,
        conf_level: float = 0.05,
        loss_fn: str = "pinball",
        kappa: float = 0.25,
        num_cosines: int = 32,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=MLPGAFNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=FPQRDistribution,
            head_kwargs={
                "n_quantiles": n_quantiles,
                "num_outputs": num_target_feature,
                "horizon": forecast_horizon,
                "dropout": dropout,
                "conf_level": conf_level,
                "kappa": kappa,
                "num_cosines": num_cosines,
                "loss_fn": loss_fn,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:  # type: ignore[override]
        """Return ``(loc, quantile_values, tau_hats)`` at inference time.

        Args:
            x: Input tensor of shape ``(B, lookback + horizon, num_features)``.

        Returns:
            Tuple of ``(loc, quantile_values, tau_hats)`` - see
            :meth:`~twiga.distributions.nn.fpquantile.FPQRDistribution.forecast`.
        """
        z = self.model.backbone.encode(x)  # type: ignore[operator, union-attr]
        return self.model.head.forecast(z)  # type: ignore[operator, union-attr]
