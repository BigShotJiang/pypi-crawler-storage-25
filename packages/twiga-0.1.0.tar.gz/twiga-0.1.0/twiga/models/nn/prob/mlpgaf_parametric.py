"""Probabilistic MLPGAF models - one thin wrapper per distribution.

Each class pairs :class:`~twiga.models.nn.net.mlpfgaf.MLPGAFNetwork`
with one distribution head from
:mod:`twiga.distributions.nn.parametric`.  All shared logic lives in
:class:`~twiga.models.nn.prob.core.ProbabilisticModel`; these classes
contain **no logic** - they exist only to:

* expose an explicit, IDE-friendly ``__init__`` signature, and
* act as the checkpointing unit for PyTorch Lightning.

The GAF backbone includes learned feature gating; regularisation penalties
(gate_penalty, weight_penalty) are automatically logged via
:class:`~twiga.models.nn.prob.core.ProbabilisticNetwork`.

The location-parameter heads (Normal, Laplace, StudentT, LogNormal) use the
additive variants that skip the mu projection layer, preserving the additive
decomposition of :class:`~twiga.models.nn.net.mlpfgaf.MLPGAFNetwork`.

Supported combinations:

    MLPGAFNormal      - symmetric, unbounded targets (demand, temperature)
    MLPGAFLaplace     - heavy-tailed, outlier-robust (electricity prices)
    MLPGAFStudentT    - very heavy tails (spot prices, financial returns)
    MLPGAFLogNormal   - strictly positive, right-skewed (gas prices)
    MLPGAFGamma       - strictly positive, flexible skew (solar, wind)
    MLPGAFBeta        - bounded [0, 1] (capacity factors, SoC)
"""

from __future__ import annotations

from torch import nn

from twiga.distributions.nn.parametric import (
    AdditiveLaplaceDistribution,
    AdditiveLogNormalDistribution,
    AdditiveNormalDistribution,
    AdditiveStudentTDistribution,
    BetaDistribution,
    GammaDistribution,
)
from twiga.models.nn.net.mlpfgaf import MLPGAFNetwork
from twiga.models.nn.prob.core import ProbabilisticModel

# ── Backbone kwarg keys ───────────────────────────────────────────────────────

_BACKBONE_KEYS = frozenset(
    {
        "num_target_feature",
        "num_historical_features",
        "num_calendar_features",
        "num_exogenous_features",
        "num_future_covariates",
        "forecast_horizon",
        "lookback_window_size",
        "embedding_size",
        "embedding_type",
        "value_embed_type",
        "use_norm",
        "use_bias",
        "use_residual",
        "use_revin",
        "use_temporal_mixer",
        "num_layers",
        "latent_size",
        "hidden_dim",
        "width_multiplier",
        "patch_len",
        "stride",
        "activation_function",
        "dropout",
        "alpha",
        "lambda_weight",
        "lambda_gate",
        "delta",
        "gate_scale",
        "gate_type",
        "warmup_epochs",
    },
)


def _backbone_kw(loc: dict) -> dict:
    """Extract backbone kwargs from an ``__init__`` locals() dict."""
    kw = {k: v for k, v in loc.items() if k in _BACKBONE_KEYS}
    kw["out_activation_function"] = "Identity"  # distribution head owns activation
    return kw


# ── Normal ────────────────────────────────────────────────────────────────────


class MLPGAFNormal(ProbabilisticModel):
    """MLPGAF + Normal distribution - symmetric, unbounded targets."""

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str | None = "ConvEmb",
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = True,
        use_revin: bool = True,
        use_temporal_mixer: bool = False,
        num_layers: int = 2,
        latent_size: int = 128,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        patch_len: int | None = None,
        stride: int | None = None,
        activation_function: str = "SiLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        lambda_weight: float = 1e-6,
        lambda_gate: float = 1e-2,
        delta: float = 1e-2,
        gate_scale: float = 5.0,
        gate_type: str = "sigmoid",
        warmup_epochs: int = 10,
        dist_out_activation: nn.Module | None = None,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=MLPGAFNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=AdditiveNormalDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Laplace ───────────────────────────────────────────────────────────────────


class MLPGAFLaplace(ProbabilisticModel):
    """MLPGAF + Laplace distribution - heavy-tailed, outlier-robust targets."""

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str | None = "ConvEmb",
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = True,
        use_revin: bool = True,
        use_temporal_mixer: bool = False,
        num_layers: int = 2,
        latent_size: int = 128,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        patch_len: int | None = None,
        stride: int | None = None,
        activation_function: str = "SiLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        lambda_weight: float = 1e-6,
        lambda_gate: float = 1e-2,
        delta: float = 1e-2,
        gate_scale: float = 5.0,
        gate_type: str = "sigmoid",
        warmup_epochs: int = 10,
        dist_out_activation: nn.Module | None = None,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=MLPGAFNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=AdditiveLaplaceDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Student-T ─────────────────────────────────────────────────────────────────


class MLPGAFStudentT(ProbabilisticModel):
    """MLPGAF + Student-T distribution - very heavy tails, spot prices."""

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str | None = "ConvEmb",
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = True,
        use_revin: bool = True,
        use_temporal_mixer: bool = False,
        num_layers: int = 2,
        latent_size: int = 128,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        patch_len: int | None = None,
        stride: int | None = None,
        activation_function: str = "SiLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        lambda_weight: float = 1e-6,
        lambda_gate: float = 1e-2,
        delta: float = 1e-2,
        gate_scale: float = 5.0,
        gate_type: str = "sigmoid",
        warmup_epochs: int = 10,
        dist_out_activation: nn.Module | None = None,
        min_df: float = 2.1,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=MLPGAFNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=AdditiveStudentTDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
                "min_df": min_df,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Log-Normal ────────────────────────────────────────────────────────────────


class MLPGAFLogNormal(ProbabilisticModel):
    """MLPGAF + LogNormal distribution - strictly positive, right-skewed targets."""

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str | None = "ConvEmb",
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = True,
        use_revin: bool = True,
        use_temporal_mixer: bool = False,
        num_layers: int = 2,
        latent_size: int = 128,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        patch_len: int | None = None,
        stride: int | None = None,
        activation_function: str = "SiLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        lambda_weight: float = 1e-6,
        lambda_gate: float = 1e-2,
        delta: float = 1e-2,
        gate_scale: float = 5.0,
        gate_type: str = "sigmoid",
        warmup_epochs: int = 10,
        dist_out_activation: nn.Module | None = None,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=MLPGAFNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=AdditiveLogNormalDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Gamma ─────────────────────────────────────────────────────────────────────


class MLPGAFGamma(ProbabilisticModel):
    """MLPGAF + Gamma distribution - strictly positive, flexible skew."""

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str | None = "ConvEmb",
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = True,
        use_revin: bool = True,
        use_temporal_mixer: bool = False,
        num_layers: int = 2,
        latent_size: int = 128,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        patch_len: int | None = None,
        stride: int | None = None,
        activation_function: str = "SiLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        lambda_weight: float = 1e-6,
        lambda_gate: float = 1e-2,
        delta: float = 1e-2,
        gate_scale: float = 5.0,
        gate_type: str = "sigmoid",
        warmup_epochs: int = 10,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=MLPGAFNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=GammaDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Beta ──────────────────────────────────────────────────────────────────────


class MLPGAFBeta(ProbabilisticModel):
    """MLPGAF + Beta distribution - bounded [0, 1] targets."""

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str | None = "ConvEmb",
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = True,
        use_revin: bool = True,
        use_temporal_mixer: bool = False,
        num_layers: int = 2,
        latent_size: int = 128,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        patch_len: int | None = None,
        stride: int | None = None,
        activation_function: str = "SiLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        lambda_weight: float = 1e-6,
        lambda_gate: float = 1e-2,
        delta: float = 1e-2,
        gate_scale: float = 5.0,
        gate_type: str = "sigmoid",
        warmup_epochs: int = 10,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=MLPGAFNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=BetaDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Registry ──────────────────────────────────────────────────────────────────

MLPGAF_PARAMETRIC_MODELS: dict[str, type[ProbabilisticModel]] = {
    "normal": MLPGAFNormal,
    "laplace": MLPGAFLaplace,
    "student_t": MLPGAFStudentT,
    "log_normal": MLPGAFLogNormal,
    "gamma": MLPGAFGamma,
    "beta": MLPGAFBeta,
}
