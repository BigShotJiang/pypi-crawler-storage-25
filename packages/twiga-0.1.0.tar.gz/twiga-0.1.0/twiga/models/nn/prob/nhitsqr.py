"""NHiTS quantile regression model - thin wrapper using ProbabilisticModel."""

from __future__ import annotations

import torch

from twiga.distributions.nn.quantile import QRDistribution
from twiga.models.nn.net.nhits import NHITSNetwork
from twiga.models.nn.prob.core import ProbabilisticModel

# ── Backbone kwarg keys ───────────────────────────────────────────────────────

_BACKBONE_KEYS = frozenset(
    {
        "num_target_feature",
        "num_historical_features",
        "num_calendar_features",
        "num_exogenous_features",
        "num_future_covariates",
        "forecast_horizon",
        "lookback_window_size",
        "activation_function",
        "dropout",
        "alpha",
        "stack_types",
        "n_blocks",
        "mlp_units",
        "n_pool_kernel_size",
        "n_freq_downsample",
        "pooling_mode",
        "interpolation_mode",
        "encode_size",
    },
)


def _backbone_kw(loc: dict) -> dict:
    """Extract backbone kwargs from an ``__init__`` locals() dict."""
    kw = {k: v for k, v in loc.items() if k in _BACKBONE_KEYS}
    kw["out_activation_function"] = "Identity"  # distribution head owns activation
    kw["decompose_forecast"] = False  # decomposition is incompatible with probabilistic path
    return kw


# ── NHITSQR ───────────────────────────────────────────────────────────────────


class NHITSQR(ProbabilisticModel):
    """NHiTS + fixed-grid quantile regression.

    Pairs :class:`~twiga.models.nn.net.nhits.NHITSNetwork` with
    :class:`~twiga.distributions.nn.quantile.QRDistribution`.

    Args:
        quantiles: Fixed quantile levels to forecast.  Defaults to
            ``[0.1, 0.2, ..., 0.9]`` (plus conf_level bounds).
        conf_level: Significance level - lower/upper bounds added as
            ``conf_level/2`` and ``1 - conf_level/2``. Defaults to 0.05.
        kappa: Smoothing kappa for the pinball loss. Defaults to 0.5.
        eps: Numerical stability epsilon. Defaults to 1e-6.
        loss_fn: ``'pinball'`` or ``'huber-pinball'``. Defaults to ``'pinball'``.
        encode_size: Latent bottleneck width. Defaults to 256.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        quantiles: list[float] | None = None,
        activation_function: str = "ReLU",
        out_activation_function: str = "Identity",  # accepted but ignored; head owns activation
        dropout: float = 0.25,
        alpha: float = 0.1,
        stack_types: list[str] | None = None,
        n_blocks: list[int] | None = None,
        mlp_units: list[list[int]] | None = None,
        n_pool_kernel_size: list[int] | None = None,
        n_freq_downsample: list[int] | None = None,
        pooling_mode: str = "MaxPool1d",
        interpolation_mode: str = "linear",
        encode_size: int = 256,
        conf_level: float = 0.05,
        loss_fn: str = "pinball",
        kappa: float = 0.5,
        eps: float = 1e-6,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=NHITSNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=QRDistribution,
            head_kwargs={
                "quantiles": quantiles,
                "num_outputs": num_target_feature,
                "horizon": forecast_horizon,
                "eps": eps,
                "kappa": kappa,
                "conf_level": conf_level,
                "loss_fn": loss_fn,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            optimizer_params=optimizer_params,
            lr_scheduler_type=lr_scheduler_type,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:  # type: ignore[override]
        """Return ``(median, quantile_values)`` at inference time.

        Args:
            x: Input tensor of shape ``(B, lookback + horizon, num_features)``.

        Returns:
            Tuple of ``(median, quantile_values)`` - see
            :meth:`~twiga.distributions.nn.quantile.QRDistribution.forecast`.
        """
        z = self.model.backbone.encode(x)  # type: ignore[operator, union-attr]
        return self.model.head.forecast(z)  # type: ignore[operator, union-attr]
