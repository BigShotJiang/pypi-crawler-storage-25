"""Probabilistic RNN models - one thin wrapper per distribution.

Each class pairs :class:`~twiga.models.nn.net.rnn.RNNForecastNetwork`
with one distribution head from
:mod:`twiga.distributions.nn.parametric`.  All shared logic lives in
:class:`~twiga.models.nn.prob.core.ProbabilisticModel`; these classes
contain **no logic** - they exist only to:

* expose an explicit, IDE-friendly ``__init__`` signature, and
* act as the checkpointing unit for PyTorch Lightning.

Supported combinations:

    RNNNormal      - symmetric, unbounded targets (demand, temperature)
    RNNLaplace     - heavy-tailed, outlier-robust (electricity prices)
    RNNStudentT    - very heavy tails (spot prices, financial returns)
    RNNLogNormal   - strictly positive, right-skewed (gas prices)
    RNNGamma       - strictly positive, flexible skew (solar, wind)
    RNNBeta        - bounded [0, 1] (capacity factors, SoC)
"""

from __future__ import annotations

from typing import Literal

from torch import nn

from twiga.distributions.nn.parametric import (
    BetaDistribution,
    GammaDistribution,
    LaplaceDistribution,
    LogNormalDistribution,
    NormalDistribution,
    StudentTDistribution,
)
from twiga.models.nn.net.rnn import RNNForecastNetwork
from twiga.models.nn.prob.core import ProbabilisticModel

# ── Backbone kwarg keys ───────────────────────────────────────────────────────

_BACKBONE_KEYS = frozenset(
    {
        "num_target_feature",
        "num_historical_features",
        "num_calendar_features",
        "num_exogenous_features",
        "num_future_covariates",
        "forecast_horizon",
        "lookback_window_size",
        "hidden_size",
        "n_layers",
        "cell_type",
        "bidirectional",
        "dropout",
        "alpha",
    },
)


def _backbone_kw(loc: dict) -> dict:
    """Extract backbone kwargs from an ``__init__`` locals() dict."""
    kw = {k: v for k, v in loc.items() if k in _BACKBONE_KEYS}
    kw["out_activation_function"] = "Identity"  # distribution head owns activation
    return kw


# ── Normal ────────────────────────────────────────────────────────────────────


class RNNNormal(ProbabilisticModel):
    """RNN + Normal distribution — symmetric, unbounded targets.

    Args:
        num_target_feature (int): Number of target series to predict.
        num_historical_features (int): Number of historical features.
        num_calendar_features (int): Number of calendar features.
        num_exogenous_features (int): Number of exogenous features.
        num_future_covariates (int): Number of future covariates.
        forecast_horizon (int): Number of future time steps to forecast.
        lookback_window_size (int): Size of the historical input window.
        hidden_size (int, optional): RNN hidden state width. Defaults to 128.
        n_layers (int, optional): Number of stacked RNN layers. Defaults to 2.
        cell_type (str, optional): ``"gru"`` or ``"lstm"``. Defaults to ``"gru"``.
        bidirectional (bool, optional): Bidirectional RNN. Defaults to False.
        dropout (float, optional): Dropout probability. Defaults to 0.25.
        alpha (float, optional): MSE/MAE mixture weight. Defaults to 0.1.
        dist_out_activation (nn.Module, optional): Output activation for the
            distribution head. Defaults to None.
        metric (str, optional): Training metric. Defaults to ``"mae"``.
        optimizer_type (str, optional): Optimizer name. Defaults to None.
        lr_scheduler_type (str, optional): Scheduler name. Defaults to None.
        optimizer_params (dict, optional): Optimizer overrides. Defaults to None.
        scheduler_params (dict, optional): Scheduler overrides. Defaults to None.
        max_epochs (int, optional): Maximum training epochs. Defaults to 10.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        hidden_size: int = 128,
        n_layers: int = 2,
        cell_type: Literal["gru", "lstm"] = "gru",
        bidirectional: bool = False,
        dropout: float = 0.25,
        alpha: float = 0.1,
        dist_out_activation: nn.Module | None = None,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=RNNForecastNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=NormalDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            optimizer_params=optimizer_params,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Laplace ───────────────────────────────────────────────────────────────────


class RNNLaplace(ProbabilisticModel):
    """RNN + Laplace distribution — heavy-tailed, outlier-robust.

    Args:
        num_target_feature (int): Number of target series to predict.
        num_historical_features (int): Number of historical features.
        num_calendar_features (int): Number of calendar features.
        num_exogenous_features (int): Number of exogenous features.
        num_future_covariates (int): Number of future covariates.
        forecast_horizon (int): Number of future time steps to forecast.
        lookback_window_size (int): Size of the historical input window.
        hidden_size (int, optional): RNN hidden state width. Defaults to 128.
        n_layers (int, optional): Number of stacked RNN layers. Defaults to 2.
        cell_type (str, optional): ``"gru"`` or ``"lstm"``. Defaults to ``"gru"``.
        bidirectional (bool, optional): Bidirectional RNN. Defaults to False.
        dropout (float, optional): Dropout probability. Defaults to 0.25.
        alpha (float, optional): MSE/MAE mixture weight. Defaults to 0.1.
        dist_out_activation (nn.Module, optional): Output activation for the
            distribution head. Defaults to None.
        metric (str, optional): Training metric. Defaults to ``"mae"``.
        optimizer_type (str, optional): Optimizer name. Defaults to None.
        lr_scheduler_type (str, optional): Scheduler name. Defaults to None.
        optimizer_params (dict, optional): Optimizer overrides. Defaults to None.
        scheduler_params (dict, optional): Scheduler overrides. Defaults to None.
        max_epochs (int, optional): Maximum training epochs. Defaults to 10.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        hidden_size: int = 128,
        n_layers: int = 2,
        cell_type: Literal["gru", "lstm"] = "gru",
        bidirectional: bool = False,
        dropout: float = 0.25,
        alpha: float = 0.1,
        dist_out_activation: nn.Module | None = None,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=RNNForecastNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=LaplaceDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            optimizer_params=optimizer_params,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── StudentT ──────────────────────────────────────────────────────────────────


class RNNStudentT(ProbabilisticModel):
    """RNN + Student-T distribution — very heavy tails (spot prices, returns).

    Args:
        num_target_feature (int): Number of target series to predict.
        num_historical_features (int): Number of historical features.
        num_calendar_features (int): Number of calendar features.
        num_exogenous_features (int): Number of exogenous features.
        num_future_covariates (int): Number of future covariates.
        forecast_horizon (int): Number of future time steps to forecast.
        lookback_window_size (int): Size of the historical input window.
        hidden_size (int, optional): RNN hidden state width. Defaults to 128.
        n_layers (int, optional): Number of stacked RNN layers. Defaults to 2.
        cell_type (str, optional): ``"gru"`` or ``"lstm"``. Defaults to ``"gru"``.
        bidirectional (bool, optional): Bidirectional RNN. Defaults to False.
        dropout (float, optional): Dropout probability. Defaults to 0.25.
        alpha (float, optional): MSE/MAE mixture weight. Defaults to 0.1.
        dist_out_activation (nn.Module, optional): Output activation for the
            distribution head. Defaults to None.
        metric (str, optional): Training metric. Defaults to ``"mae"``.
        optimizer_type (str, optional): Optimizer name. Defaults to None.
        lr_scheduler_type (str, optional): Scheduler name. Defaults to None.
        optimizer_params (dict, optional): Optimizer overrides. Defaults to None.
        scheduler_params (dict, optional): Scheduler overrides. Defaults to None.
        max_epochs (int, optional): Maximum training epochs. Defaults to 10.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        hidden_size: int = 128,
        n_layers: int = 2,
        cell_type: Literal["gru", "lstm"] = "gru",
        bidirectional: bool = False,
        dropout: float = 0.25,
        alpha: float = 0.1,
        dist_out_activation: nn.Module | None = None,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=RNNForecastNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=StudentTDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            optimizer_params=optimizer_params,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── LogNormal ─────────────────────────────────────────────────────────────────


class RNNLogNormal(ProbabilisticModel):
    """RNN + LogNormal distribution — strictly positive, right-skewed.

    Args:
        num_target_feature (int): Number of target series to predict.
        num_historical_features (int): Number of historical features.
        num_calendar_features (int): Number of calendar features.
        num_exogenous_features (int): Number of exogenous features.
        num_future_covariates (int): Number of future covariates.
        forecast_horizon (int): Number of future time steps to forecast.
        lookback_window_size (int): Size of the historical input window.
        hidden_size (int, optional): RNN hidden state width. Defaults to 128.
        n_layers (int, optional): Number of stacked RNN layers. Defaults to 2.
        cell_type (str, optional): ``"gru"`` or ``"lstm"``. Defaults to ``"gru"``.
        bidirectional (bool, optional): Bidirectional RNN. Defaults to False.
        dropout (float, optional): Dropout probability. Defaults to 0.25.
        alpha (float, optional): MSE/MAE mixture weight. Defaults to 0.1.
        dist_out_activation (nn.Module, optional): Output activation for the
            distribution head. Defaults to None.
        metric (str, optional): Training metric. Defaults to ``"mae"``.
        optimizer_type (str, optional): Optimizer name. Defaults to None.
        lr_scheduler_type (str, optional): Scheduler name. Defaults to None.
        optimizer_params (dict, optional): Optimizer overrides. Defaults to None.
        scheduler_params (dict, optional): Scheduler overrides. Defaults to None.
        max_epochs (int, optional): Maximum training epochs. Defaults to 10.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        hidden_size: int = 128,
        n_layers: int = 2,
        cell_type: Literal["gru", "lstm"] = "gru",
        bidirectional: bool = False,
        dropout: float = 0.25,
        alpha: float = 0.1,
        dist_out_activation: nn.Module | None = None,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=RNNForecastNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=LogNormalDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            optimizer_params=optimizer_params,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Gamma ─────────────────────────────────────────────────────────────────────


class RNNGamma(ProbabilisticModel):
    """RNN + Gamma distribution — strictly positive, flexible skew (solar, wind).

    Args:
        num_target_feature (int): Number of target series to predict.
        num_historical_features (int): Number of historical features.
        num_calendar_features (int): Number of calendar features.
        num_exogenous_features (int): Number of exogenous features.
        num_future_covariates (int): Number of future covariates.
        forecast_horizon (int): Number of future time steps to forecast.
        lookback_window_size (int): Size of the historical input window.
        hidden_size (int, optional): RNN hidden state width. Defaults to 128.
        n_layers (int, optional): Number of stacked RNN layers. Defaults to 2.
        cell_type (str, optional): ``"gru"`` or ``"lstm"``. Defaults to ``"gru"``.
        bidirectional (bool, optional): Bidirectional RNN. Defaults to False.
        dropout (float, optional): Dropout probability. Defaults to 0.25.
        alpha (float, optional): MSE/MAE mixture weight. Defaults to 0.1.
        metric (str, optional): Training metric. Defaults to ``"mae"``.
        optimizer_type (str, optional): Optimizer name. Defaults to None.
        lr_scheduler_type (str, optional): Scheduler name. Defaults to None.
        optimizer_params (dict, optional): Optimizer overrides. Defaults to None.
        scheduler_params (dict, optional): Scheduler overrides. Defaults to None.
        max_epochs (int, optional): Maximum training epochs. Defaults to 10.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        hidden_size: int = 128,
        n_layers: int = 2,
        cell_type: Literal["gru", "lstm"] = "gru",
        bidirectional: bool = False,
        dropout: float = 0.25,
        alpha: float = 0.1,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=RNNForecastNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=GammaDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            optimizer_params=optimizer_params,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Beta ──────────────────────────────────────────────────────────────────────


class RNNBeta(ProbabilisticModel):
    """RNN + Beta distribution — bounded [0, 1] (capacity factors, SoC).

    Args:
        num_target_feature (int): Number of target series to predict.
        num_historical_features (int): Number of historical features.
        num_calendar_features (int): Number of calendar features.
        num_exogenous_features (int): Number of exogenous features.
        num_future_covariates (int): Number of future covariates.
        forecast_horizon (int): Number of future time steps to forecast.
        lookback_window_size (int): Size of the historical input window.
        hidden_size (int, optional): RNN hidden state width. Defaults to 128.
        n_layers (int, optional): Number of stacked RNN layers. Defaults to 2.
        cell_type (str, optional): ``"gru"`` or ``"lstm"``. Defaults to ``"gru"``.
        bidirectional (bool, optional): Bidirectional RNN. Defaults to False.
        dropout (float, optional): Dropout probability. Defaults to 0.25.
        alpha (float, optional): MSE/MAE mixture weight. Defaults to 0.1.
        metric (str, optional): Training metric. Defaults to ``"mae"``.
        optimizer_type (str, optional): Optimizer name. Defaults to None.
        lr_scheduler_type (str, optional): Scheduler name. Defaults to None.
        optimizer_params (dict, optional): Optimizer overrides. Defaults to None.
        scheduler_params (dict, optional): Scheduler overrides. Defaults to None.
        max_epochs (int, optional): Maximum training epochs. Defaults to 10.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        hidden_size: int = 128,
        n_layers: int = 2,
        cell_type: Literal["gru", "lstm"] = "gru",
        bidirectional: bool = False,
        dropout: float = 0.25,
        alpha: float = 0.1,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=RNNForecastNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=BetaDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            optimizer_params=optimizer_params,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()
