"""Probabilistic neural network wrappers for Twiga.

Modules NOT exported here due to cross-package circular imports:
  - MLPFFPQR, MLPGAMFPQR, MLPGAFFPQR - depend on fpquantile → models.nn.core.embedding
  - MLPFCRC, MLPGAMCRC, MLPGAFCRC - depend on residual_conformal → models.nn.core.linear

Import them directly, e.g.:
  from twiga.models.nn.prob.mlpf_crc import MLPFCRC
  from twiga.models.nn.prob.mlpffpqr import MLPFFPQR
"""

from twiga.models.nn.prob.core import ProbabilisticModel, ProbabilisticNetwork

# MLPF parametric
from twiga.models.nn.prob.mlpf_parametric import (
    MLPFBeta,
    MLPFGamma,
    MLPFLaplace,
    MLPFLogNormal,
    MLPFNormal,
    MLPFStudentT,
)

# MLPF quantile (QR only)
from twiga.models.nn.prob.mlpfqr import MLPFQR

# MLPGAF parametric
from twiga.models.nn.prob.mlpgaf_parametric import (
    MLPGAFBeta,
    MLPGAFGamma,
    MLPGAFLaplace,
    MLPGAFLogNormal,
    MLPGAFNormal,
    MLPGAFStudentT,
)

# MLPGAF quantile (QR only)
from twiga.models.nn.prob.mlpgafqr import MLPGAFQR

# MLPGAM parametric
from twiga.models.nn.prob.mlpgam_parametric import (
    MLPGAMBeta,
    MLPGAMGamma,
    MLPGAMLaplace,
    MLPGAMLogNormal,
    MLPGAMNormal,
    MLPGAMStudentT,
)

# MLPGAM quantile (QR only)
from twiga.models.nn.prob.mlpgamqr import MLPGAMQR

__all__ = [
    # Core
    "ProbabilisticModel",
    "ProbabilisticNetwork",
    # MLPF
    "MLPFBeta",
    "MLPFGamma",
    "MLPFLaplace",
    "MLPFLogNormal",
    "MLPFNormal",
    "MLPFStudentT",
    "MLPFQR",
    # MLPGAM
    "MLPGAMBeta",
    "MLPGAMGamma",
    "MLPGAMLaplace",
    "MLPGAMLogNormal",
    "MLPGAMNormal",
    "MLPGAMStudentT",
    "MLPGAMQR",
    # MLPGAF
    "MLPGAFBeta",
    "MLPGAFGamma",
    "MLPGAFLaplace",
    "MLPGAFLogNormal",
    "MLPGAFNormal",
    "MLPGAFStudentT",
    "MLPGAFQR",
]
