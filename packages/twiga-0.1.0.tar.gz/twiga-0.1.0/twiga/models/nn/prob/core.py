"""Core infrastructure for probabilistic neural forecasting.

Provides two composable building blocks that decouple backbone networks from
distribution heads:

    ProbabilisticNetwork  - ``nn.Module`` wiring any backbone + any head.
    ProbabilisticModel    - ``LightningModule`` wrapping the above for training.

Backbone contract
-----------------
Any ``nn.Module`` used as a backbone must implement:

    encode(x) -> torch.Tensor
        Map the raw input tensor ``(B, T, F)`` to a latent vector
        ``(B, encode_size)``.

    encode_size : int  (property)
        Width of the latent vector.  Set ``self._encode_size`` in
        ``__init__`` and inherit the property from ``BaseArchitecture``.

    penalty_dict(epoch=None) -> dict[str, Tensor]
        Return backbone-specific regularisation terms (Lasso, gate sparsity …).
        Return ``{}`` when no penalty applies (the default in ``BaseArchitecture``).

Distribution head contract
--------------------------
Any ``nn.Module`` used as a head must implement:

    forward(z) -> tuple[Tensor, ...]
        Map latent ``z`` to distribution parameters.

    step(z, y, metric_fn, epoch=None) -> (loss, metric)
        Compute the training loss and a scalar metric in one call.
        ``BaseDistribution`` provides a default NLL implementation;
        ``QRDistribution`` and ``FPQRDistribution`` provide their own.
"""

from __future__ import annotations

from collections.abc import Callable

import torch
from torch import nn

from twiga.models.nn.core.base_model import BaseNeuralModel


class ProbabilisticNetwork(nn.Module):
    """Generic backbone + distribution-head network.

    Composes any backbone that implements ``encode(x) → z`` with any
    distribution head that implements ``step(z, y, metric_fn, epoch)``.

    Args:
        backbone: Instantiated backbone network.
        head: Instantiated distribution head.
    """

    def __init__(self, backbone: nn.Module, head: nn.Module) -> None:
        super().__init__()
        self.backbone = backbone
        self.head = head

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, ...]:
        """Encode input and return distribution parameters.

        Args:
            x: Input tensor of shape ``(B, T, F)``.

        Returns:
            Tuple of distribution parameter tensors from the head.
        """
        return self.head(self.backbone.encode(x))  # type: ignore[operator]

    def forecast(self, x: torch.Tensor) -> tuple[torch.Tensor, ...] | dict:
        """Inference-mode forecast via the head's forecast method.

        Encodes ``x`` with the backbone then delegates to ``self.head.forecast(z)``
        so that heads with richer outputs (e.g. QR returning ``loc`` + ``quantiles``
        + ``quantile_levels``) produce the full dict rather than the raw tensor
        returned by their ``forward()`` method.

        Args:
            x: Input tensor of shape ``(B, T, F)``.

        Returns:
            Whatever ``self.head.forecast(z)`` returns - a tuple for parametric
            heads or a dict for quantile / conformal heads.
        """
        with torch.no_grad():
            z = self.backbone.encode(x)  # type: ignore[operator]
            return self.head.forecast(z)  # type: ignore[operator]

    def step(
        self,
        batch: tuple[torch.Tensor, torch.Tensor],
        metric_fn: Callable,
        epoch: int | None = None,
    ) -> tuple[torch.Tensor | dict, torch.Tensor]:
        """Single training/validation step.

        Encodes the input, delegates to the head's ``step()``, then adds any
        backbone regularisation penalties returned by ``penalty_dict()``.

        When the backbone returns non-empty penalties the loss is promoted to a
        ``dict`` so ``BaseNeuralModel.training_step`` can log each component
        individually.

        Args:
            batch: ``(x, y)`` pair.
            metric_fn: Callable returning a scalar metric.
            epoch: Current epoch (forwarded to ``penalty_dict`` for warmup).

        Returns:
            ``(loss_or_dict, metric)``
        """
        x, y = batch
        z = self.backbone.encode(x)  # type: ignore[operator]
        nll_loss, metric = self.head.step(z, y, metric_fn, epoch)  # type: ignore[operator]
        penalties = self.backbone.penalty_dict(epoch)  # type: ignore[operator]
        if penalties:
            total = nll_loss + sum(penalties.values())
            return {"loss": total, "nll": nll_loss, **penalties}, metric
        return nll_loss, metric


class ProbabilisticModel(BaseNeuralModel):
    """Generic Lightning wrapper for backbone + distribution head.

    Instantiates ``backbone_cls(**backbone_kwargs)`` then
    ``head_cls(hidden_size=backbone.encode_size, **head_kwargs)``,
    automatically injecting the backbone's latent size into the head so
    callers never need to specify ``hidden_size`` explicitly.

    Args:
        backbone_cls: Backbone class (e.g. ``MLPFNetwork``).
        backbone_kwargs: Constructor kwargs forwarded to the backbone.
        head_cls: Distribution head class (e.g. ``NormalDistribution``).
        head_kwargs: Constructor kwargs forwarded to the head.  Do **not**
            include ``hidden_size`` - it is injected automatically.
        metric: Training/validation metric.  Defaults to ``'mae'``.
        optimizer_type: Optimizer name (e.g. ``'adamw'``). Defaults to ``None``
            (falls back to ``BaseNeuralModel`` default of ``'adamw'``).
        lr_scheduler_type: Scheduler name (e.g. ``'cosine_annealing_lr'``).
            Defaults to ``None`` (falls back to ``'multi_step'``).
        checkpoints_path: Directory for saving Lightning checkpoints.
            Defaults to ``'./'``.
        optimizer_params: Override for ``BaseNeuralModel.OPTIMIZERS`` dict.
        scheduler_params: Override for ``BaseNeuralModel.SCHEDULERS`` dict.
        max_epochs: Maximum training epochs.  Defaults to ``10``.
    """

    def __init__(
        self,
        backbone_cls: type,
        backbone_kwargs: dict,
        head_cls: type,
        head_kwargs: dict,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ) -> None:
        super().__init__(
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.n_out = backbone_kwargs["num_target_feature"]
        self.n_channels = sum(
            backbone_kwargs[k]
            for k in (
                "num_historical_features",
                "num_calendar_features",
                "num_exogenous_features",
                "num_future_covariates",
            )
        )
        backbone = backbone_cls(**backbone_kwargs)
        full_head_kwargs = {"hidden_size": backbone.encode_size, **head_kwargs}
        head = head_cls(**full_head_kwargs)
        self.model = ProbabilisticNetwork(backbone, head)
        self.save_hyperparameters()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, ...]:  # type: ignore[override]
        """Return distribution parameters for the input batch.

        Args:
            x: Input tensor.

        Returns:
            Tuple of distribution parameter tensors.
        """
        return self.model.forecast(x)  # type: ignore[operator, union-attr]
