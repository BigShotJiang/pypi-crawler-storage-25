"""MLPF flexible-quantile regression model - thin wrapper using ProbabilisticModel."""

from __future__ import annotations

import torch

from twiga.distributions.nn.fpquantile import FPQRDistribution
from twiga.models.nn.net.mlpf import MLPFNetwork
from twiga.models.nn.prob.core import ProbabilisticModel

# ── Backbone kwarg keys (same as mlpf_parametric) ────────────────────────────

_BACKBONE_KEYS = frozenset(
    {
        "num_target_feature",
        "num_historical_features",
        "num_calendar_features",
        "num_exogenous_features",
        "num_future_covariates",
        "forecast_horizon",
        "lookback_window_size",
        "embedding_size",
        "embedding_type",
        "value_embed_type",
        "combination_type",
        "latent_size",
        "hidden_dim",
        "width_multiplier",
        "num_layers",
        "activation_function",
        "dropout",
        "alpha",
        "num_attention_heads",
        "use_norm",
        "use_bias",
        "use_residual",
        "use_temporal_mixer",
        "patch_len",
        "stride",
    },
)


def _backbone_kw(loc: dict) -> dict:
    """Extract backbone kwargs from an ``__init__`` locals() dict."""
    kw = {k: v for k, v in loc.items() if k in _BACKBONE_KEYS}
    kw["out_activation_function"] = "Identity"
    return kw


# ── MLPFFPQR ─────────────────────────────────────────────────────────────────


class MLPFFPQR(ProbabilisticModel):
    """MLPF + flexible-proposal quantile regression.

    Pairs :class:`~twiga.models.nn.net.mlpf.MLPFNetwork` with
    :class:`~twiga.distributions.nn.fpquantile.FPQRDistribution`, which
    adaptively proposes quantile levels during training rather than using a
    fixed grid.

    Args:
        n_quantiles: Number of quantile proposals. Defaults to 9.
        conf_level: Significance level for quantile bounds. Defaults to 0.05.
        kappa: Smoothing kappa for the pinball loss. Defaults to 0.25.
        num_cosines: Cosine features for tau embedding. Defaults to 32.
        loss_fn: ``'pinball'`` or ``'huber-pinball'``. Defaults to ``'pinball'``.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        n_quantiles: int = 9,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str | None = None,
        combination_type: str = "attn-comb",
        latent_size: int = 128,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        num_layers: int = 2,
        activation_function: str = "SiLU",
        out_activation_function: str = "Identity",  # accepted but ignored; head owns activation
        dropout: float = 0.25,
        alpha: float = 0.1,
        num_attention_heads: int = 4,
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = False,
        use_temporal_mixer: bool = False,
        patch_len: int | None = None,
        stride: int | None = None,
        conf_level: float = 0.05,
        loss_fn: str = "pinball",
        kappa: float = 0.25,
        num_cosines: int = 32,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=MLPFNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=FPQRDistribution,
            head_kwargs={
                "n_quantiles": n_quantiles,
                "num_outputs": num_target_feature,
                "horizon": forecast_horizon,
                "dropout": dropout,
                "conf_level": conf_level,
                "kappa": kappa,
                "num_cosines": num_cosines,
                "loss_fn": loss_fn,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:  # type: ignore[override]
        """Return ``(loc, quantile_values, tau_hats)`` at inference time.

        Args:
            x: Input tensor of shape ``(B, lookback + horizon, num_features)``.

        Returns:
            Tuple of ``(loc, quantile_values, tau_hats)`` - see
            :meth:`~twiga.distributions.nn.fpquantile.FPQRDistribution.forecast`.
        """
        z = self.model.backbone.encode(x)  # type: ignore[operator, union-attr]
        return self.model.head.forecast(z)  # type: ignore[operator, union-attr]
