"""MLPF Conditional Residual Calibration model."""

from __future__ import annotations

import torch
from torch import nn

from twiga.distributions.nn.residual_conformal import CRCDistribution
from twiga.models.nn.net.mlpf import MLPFNetwork
from twiga.models.nn.prob.core import ProbabilisticModel

_BACKBONE_KEYS = frozenset(
    {
        "num_target_feature",
        "num_historical_features",
        "num_calendar_features",
        "num_exogenous_features",
        "num_future_covariates",
        "forecast_horizon",
        "lookback_window_size",
        "embedding_size",
        "embedding_type",
        "value_embed_type",
        "combination_type",
        "latent_size",
        "hidden_dim",
        "width_multiplier",
        "num_layers",
        "activation_function",
        "dropout",
        "alpha",
        "num_attention_heads",
        "use_norm",
        "use_bias",
        "use_residual",
        "use_temporal_mixer",
        "patch_len",
        "stride",
    },
)


def _backbone_kw(loc: dict) -> dict:
    kw = {k: v for k, v in loc.items() if k in _BACKBONE_KEYS}
    kw["out_activation_function"] = "Identity"
    return kw


class MLPFCRC(ProbabilisticModel):
    """MLPF + Conditional Residual Calibration.

    Pairs :class:`~twiga.models.nn.net.mlpf.MLPFNetwork` with
    :class:`~twiga.distributions.nn.residual_conformal.CRCDistribution`.
    The mean is projected from the latent via a linear layer; the scale MLP
    is conditioned on the detached mean to approximate absolute residuals.
    """

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        embedding_size: int = 28,
        embedding_type: str | None = None,
        value_embed_type: str | None = None,
        combination_type: str = "attn-comb",
        latent_size: int = 128,
        hidden_dim: int = 256,
        width_multiplier: float = 2.0,
        num_layers: int = 2,
        activation_function: str = "SiLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        num_attention_heads: int = 4,
        use_norm: bool = True,
        use_bias: bool = True,
        use_residual: bool = False,
        use_temporal_mixer: bool = False,
        patch_len: int | None = None,
        stride: int | None = None,
        crc_alpha: float = 0.1,
        crc_activation: str = "ReLU",
        dist_out_activation: nn.Module | None = None,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=MLPFNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=CRCDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
                "alpha": crc_alpha,
                "activation": crc_activation,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:  # type: ignore[override]
        """Return ``(mu, sigma)`` at inference time."""
        z = self.model.backbone.encode(x)  # type: ignore[operator, union-attr]
        return self.model.head.forecast(z)  # type: ignore[operator, union-attr]
