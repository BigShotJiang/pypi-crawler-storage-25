"""Probabilistic NHiTS models - one thin wrapper per distribution.

Each class pairs :class:`~twiga.models.nn.net.nhits.NHITSNetwork`
with one distribution head from
:mod:`twiga.distributions.nn.parametric`.  All shared logic lives in
:class:`~twiga.models.nn.prob.core.ProbabilisticModel`; these classes
contain **no logic** - they exist only to:

* expose an explicit, IDE-friendly ``__init__`` signature, and
* act as the checkpointing unit for PyTorch Lightning.

Supported combinations:

    NHITSNormal      - symmetric, unbounded targets (demand, temperature)
    NHITSLaplace     - heavy-tailed, outlier-robust (electricity prices)
    NHITSStudentT    - very heavy tails (spot prices, financial returns)
    NHITSLogNormal   - strictly positive, right-skewed (gas prices)
    NHITSGamma       - strictly positive, flexible skew (solar, wind)
    NHITSBeta        - bounded [0, 1] (capacity factors, SoC)
"""

from __future__ import annotations

from torch import nn

from twiga.distributions.nn.parametric import (
    BetaDistribution,
    GammaDistribution,
    LaplaceDistribution,
    LogNormalDistribution,
    NormalDistribution,
    StudentTDistribution,
)
from twiga.models.nn.net.nhits import NHITSNetwork
from twiga.models.nn.prob.core import ProbabilisticModel

# ── Backbone kwarg keys ───────────────────────────────────────────────────────

_BACKBONE_KEYS = frozenset(
    {
        "num_target_feature",
        "num_historical_features",
        "num_calendar_features",
        "num_exogenous_features",
        "num_future_covariates",
        "forecast_horizon",
        "lookback_window_size",
        "activation_function",
        "dropout",
        "alpha",
        "stack_types",
        "n_blocks",
        "mlp_units",
        "n_pool_kernel_size",
        "n_freq_downsample",
        "pooling_mode",
        "interpolation_mode",
        "encode_size",
    },
)


def _backbone_kw(loc: dict) -> dict:
    """Extract backbone kwargs from an ``__init__`` locals() dict."""
    kw = {k: v for k, v in loc.items() if k in _BACKBONE_KEYS}
    kw["out_activation_function"] = "Identity"  # distribution head owns activation
    kw["decompose_forecast"] = False
    return kw


# ── Shared __init__ args for all parametric wrappers ─────────────────────────
# (stack_types / n_blocks / mlp_units / n_pool_kernel_size / n_freq_downsample
#  default to None so NHITSNetwork fills its own defaults)

# ── Normal ────────────────────────────────────────────────────────────────────


class NHITSNormal(ProbabilisticModel):
    """NHiTS + Normal distribution - symmetric, unbounded targets."""

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        activation_function: str = "ReLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        stack_types: list[str] | None = None,
        n_blocks: list[int] | None = None,
        mlp_units: list[list[int]] | None = None,
        n_pool_kernel_size: list[int] | None = None,
        n_freq_downsample: list[int] | None = None,
        pooling_mode: str = "MaxPool1d",
        interpolation_mode: str = "linear",
        encode_size: int = 256,
        dist_out_activation: nn.Module | None = None,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=NHITSNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=NormalDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Laplace ───────────────────────────────────────────────────────────────────


class NHITSLaplace(ProbabilisticModel):
    """NHiTS + Laplace distribution - heavy-tailed, outlier-robust targets."""

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        activation_function: str = "ReLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        stack_types: list[str] | None = None,
        n_blocks: list[int] | None = None,
        mlp_units: list[list[int]] | None = None,
        n_pool_kernel_size: list[int] | None = None,
        n_freq_downsample: list[int] | None = None,
        pooling_mode: str = "MaxPool1d",
        interpolation_mode: str = "linear",
        encode_size: int = 256,
        dist_out_activation: nn.Module | None = None,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=NHITSNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=LaplaceDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Student-T ─────────────────────────────────────────────────────────────────


class NHITSStudentT(ProbabilisticModel):
    """NHiTS + Student-T distribution - very heavy tails, spot prices."""

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        activation_function: str = "ReLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        stack_types: list[str] | None = None,
        n_blocks: list[int] | None = None,
        mlp_units: list[list[int]] | None = None,
        n_pool_kernel_size: list[int] | None = None,
        n_freq_downsample: list[int] | None = None,
        pooling_mode: str = "MaxPool1d",
        interpolation_mode: str = "linear",
        encode_size: int = 256,
        dist_out_activation: nn.Module | None = None,
        min_df: float = 2.1,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=NHITSNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=StudentTDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
                "min_df": min_df,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Log-Normal ────────────────────────────────────────────────────────────────


class NHITSLogNormal(ProbabilisticModel):
    """NHiTS + LogNormal distribution - strictly positive, right-skewed targets."""

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        activation_function: str = "ReLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        stack_types: list[str] | None = None,
        n_blocks: list[int] | None = None,
        mlp_units: list[list[int]] | None = None,
        n_pool_kernel_size: list[int] | None = None,
        n_freq_downsample: list[int] | None = None,
        pooling_mode: str = "MaxPool1d",
        interpolation_mode: str = "linear",
        encode_size: int = 256,
        dist_out_activation: nn.Module | None = None,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=NHITSNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=LogNormalDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
                "out_activation_function": dist_out_activation,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Gamma ─────────────────────────────────────────────────────────────────────


class NHITSGamma(ProbabilisticModel):
    """NHiTS + Gamma distribution - strictly positive, flexible skew."""

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        activation_function: str = "ReLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        stack_types: list[str] | None = None,
        n_blocks: list[int] | None = None,
        mlp_units: list[list[int]] | None = None,
        n_pool_kernel_size: list[int] | None = None,
        n_freq_downsample: list[int] | None = None,
        pooling_mode: str = "MaxPool1d",
        interpolation_mode: str = "linear",
        encode_size: int = 256,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=NHITSNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=GammaDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Beta ──────────────────────────────────────────────────────────────────────


class NHITSBeta(ProbabilisticModel):
    """NHiTS + Beta distribution - bounded [0, 1] targets."""

    def __init__(
        self,
        num_target_feature: int,
        num_historical_features: int,
        num_calendar_features: int,
        num_exogenous_features: int,
        num_future_covariates: int,
        forecast_horizon: int,
        lookback_window_size: int,
        activation_function: str = "ReLU",
        dropout: float = 0.25,
        alpha: float = 0.1,
        stack_types: list[str] | None = None,
        n_blocks: list[int] | None = None,
        mlp_units: list[list[int]] | None = None,
        n_pool_kernel_size: list[int] | None = None,
        n_freq_downsample: list[int] | None = None,
        pooling_mode: str = "MaxPool1d",
        interpolation_mode: str = "linear",
        encode_size: int = 256,
        metric: str = "mae",
        optimizer_type: str | None = None,
        lr_scheduler_type: str | None = None,
        checkpoints_path: str = "./",
        optimizer_params: dict | None = None,
        scheduler_params: dict | None = None,
        max_epochs: int = 10,
    ):
        super().__init__(
            backbone_cls=NHITSNetwork,
            backbone_kwargs=_backbone_kw(locals()),
            head_cls=BetaDistribution,
            head_kwargs={
                "num_target_output": num_target_feature,
                "forecast_horizon": forecast_horizon,
            },
            metric=metric,
            optimizer_type=optimizer_type,
            lr_scheduler_type=lr_scheduler_type,
            checkpoints_path=checkpoints_path,
            optimizer_params=optimizer_params,
            scheduler_params=scheduler_params,
            max_epochs=max_epochs,
        )
        self.save_hyperparameters()


# ── Registry ──────────────────────────────────────────────────────────────────

NHITS_PARAMETRIC_MODELS: dict[str, type[ProbabilisticModel]] = {
    "normal": NHITSNormal,
    "laplace": NHITSLaplace,
    "student_t": NHITSStudentT,
    "log_normal": NHITSLogNormal,
    "gamma": NHITSGamma,
    "beta": NHITSBeta,
}
