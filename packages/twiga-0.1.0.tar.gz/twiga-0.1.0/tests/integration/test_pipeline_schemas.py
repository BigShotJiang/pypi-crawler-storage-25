"""Integration tests for pipeline schemas and the ModelLoader.

Validates that:
- :class:`DriftSummary`, :class:`TrainingResult`, :class:`RetrainingResult`
  round-trip from dicts correctly.
- :class:`ModelLoader` enforces thread-safe loading under concurrency.
- Checkpoint manifest is written and read correctly.
"""

from __future__ import annotations

import json
from pathlib import Path
import threading
from unittest.mock import MagicMock

import pytest

pytest.importorskip("prefect", reason="prefect not installed")


# ---------------------------------------------------------------------------
# DriftSummary
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_drift_summary_from_dict_full():
    from twiga.pipeline.schemas import DriftSummary

    raw = {
        "drift_detected": True,
        "dataset_drift_score": 0.6,
        "n_drifted": 3,
        "total": 5,
        "feature_drift": {"temp": 0.8, "hour": 0.2},
        "report_path": "/tmp/report.html",  # noqa: S108
        "timestamp": "2026-01-01T00:00:00+00:00",
    }
    ds = DriftSummary.from_dict(raw)
    assert ds.drift_detected is True
    assert ds.dataset_drift_score == pytest.approx(0.6)
    assert ds.n_drifted == 3
    assert ds.feature_drift["temp"] == pytest.approx(0.8)
    assert ds.report_path == "/tmp/report.html"  # noqa: S108


@pytest.mark.integration
def test_drift_summary_from_dict_partial():
    from twiga.pipeline.schemas import DriftSummary

    ds = DriftSummary.from_dict({"drift_detected": False})
    assert ds.n_drifted == 0
    assert ds.feature_drift == {}
    assert ds.report_path is None


@pytest.mark.integration
def test_drift_summary_ignores_unknown_keys():
    from twiga.pipeline.schemas import DriftSummary

    ds = DriftSummary.from_dict({"unknown_key": "value", "n_drifted": 1, "total": 4})
    assert ds.n_drifted == 1


# ---------------------------------------------------------------------------
# TrainingResult / RetrainingResult
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_training_result_attributes():
    from twiga.pipeline.schemas import TrainingResult

    r = TrainingResult(
        checkpoint_path="/ckpt/dir",
        mlflow_run_id="abc123",
        metrics={"lgbm": {"mae": 0.12}},
    )
    assert r.checkpoint_path == "/ckpt/dir"
    assert r.mlflow_run_id == "abc123"
    assert r.metrics["lgbm"]["mae"] == pytest.approx(0.12)


@pytest.mark.integration
def test_retraining_result_not_promoted():
    from twiga.pipeline.schemas import DriftSummary, RetrainingResult

    r = RetrainingResult(
        retrained=False,
        promoted=False,
        drift_summary=DriftSummary(),
    )
    assert r.retrained is False
    assert r.checkpoint_path is None
    assert r.metrics is None


# ---------------------------------------------------------------------------
# ModelLoader thread safety
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_model_loader_thread_safe_load(tmp_path):
    """Concurrent load() calls must only invoke on_load_checkpoint once."""
    from twiga.serve.loader import ModelLoader

    # Create a dummy pkl file so _do_load passes the "no files" check
    (tmp_path / "model.pkl").write_bytes(b"fake")

    fc = MagicMock()
    fc.checkpoints_path = str(tmp_path)
    fc.data_pipeline.target_feature = ["load"]
    fc.data_pipeline.forecast_horizon = 24
    fc.models = [MagicMock(model_type="lgbm")]

    loader = ModelLoader(fc)
    call_count = []

    original = loader._do_load

    def slow_load():
        import time

        time.sleep(0.05)
        original()
        call_count.append(1)

    loader._do_load = slow_load

    threads = [threading.Thread(target=loader.load) for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert sum(call_count) == 1, f"Expected 1 load, got {sum(call_count)}"


# ---------------------------------------------------------------------------
# Checkpoint manifest
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_checkpoint_manifest_written_on_save(tmp_path):
    """on_save_checkpoint writes a _checkpoint_manifest.json alongside the pkl."""
    import joblib

    from twiga.core.config.forecaster import ForecasterConfig

    fc_mock = MagicMock()
    fc_mock.domain = "ml"
    fc_mock.checkpoints_path = tmp_path
    fc_mock.model = MagicMock()
    fc_mock.data_pipeline = MagicMock()
    fc_mock.model_type = "lgbm"

    # Patch joblib.dump to avoid real serialisation
    from unittest.mock import patch

    with patch("twiga.forecaster.base.joblib.dump"):
        from twiga.forecaster.base import BaseForecaster

        # Call the method directly on the class using the mock as self
        BaseForecaster.on_save_checkpoint(fc_mock)

    manifest_path = tmp_path / "_checkpoint_manifest.json"
    assert manifest_path.exists(), "Manifest file was not created"

    manifest = json.loads(manifest_path.read_text())
    assert manifest["version"] == 1
    assert manifest["checkpoint_file"] == "model_and_pipeline.pkl"
    assert manifest["model_type"] == "lgbm"
    assert "saved_at" in manifest


@pytest.mark.integration
def test_checkpoint_manifest_version_increments(tmp_path):
    """Each save increments the version in the manifest."""
    from unittest.mock import patch

    fc_mock = MagicMock()
    fc_mock.domain = "ml"
    fc_mock.checkpoints_path = tmp_path
    fc_mock.model_type = "lgbm"

    from twiga.forecaster.base import BaseForecaster

    with patch("twiga.forecaster.base.joblib.dump"):
        BaseForecaster.on_save_checkpoint(fc_mock)
        BaseForecaster.on_save_checkpoint(fc_mock)

    manifest = json.loads((tmp_path / "_checkpoint_manifest.json").read_text())
    assert manifest["version"] == 2
