# Integration tests — require optional MLOps dependencies (mlops extra).
# Run with: pytest tests/integration/ -m integration
