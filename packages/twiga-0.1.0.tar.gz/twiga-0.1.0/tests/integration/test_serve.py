"""Integration tests for the Twiga serving layer.

These tests wire together the real FastAPI app, ModelLoader, and ForecastMonitor
without mocking the framework internals — only the forecaster model itself is
stubbed to keep tests fast and dependency-free.

Run with::

    pytest tests/integration/ -m integration -v
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from fastapi.testclient import TestClient
import numpy as np
import pandas as pd
import pytest

pytest.importorskip("fastapi", reason="fastapi not installed")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_records(n: int = 5) -> list[dict]:
    dates = pd.date_range("2024-01-01", periods=n, freq="h", tz="UTC")
    return [{"timestamp": str(d), "feature": float(i)} for i, d in enumerate(dates)]


def _make_forecaster_stub(n_models: int = 1, horizon: int = 2, n_targets: int = 1):
    """Return a MagicMock that satisfies the ModelLoader and API contracts."""
    fc = MagicMock()

    # Data pipeline metadata
    fc.data_pipeline.target_feature = ["load"] * n_targets
    fc.data_pipeline.forecast_horizon = horizon
    fc.data_pipeline.data = pd.DataFrame({"feature": [1.0, 2.0]})

    # Model names
    fc.models = [MagicMock(model_type=f"model_{i}") for i in range(n_models)]
    fc.checkpoints_path = "/fake/checkpoints"

    # Predictions: (B=1, H=horizon, T=n_targets)
    arr = np.ones((1, horizon, n_targets))
    preds = {f"model_{i}": arr for i in range(n_models)}
    times = {f"model_{i}": 0.01 for i in range(n_models)}
    fc.predict.return_value = (preds, times)

    interval_preds = {f"model_{i}": (arr * 0.9, arr, arr * 1.1) for i in range(n_models)}
    fc.predict_interval.return_value = (interval_preds, times)

    return fc


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def app_client():
    """Create a TestClient wrapping a real create_app() with a stubbed forecaster."""
    from twiga.serve.app import create_app, get_forecaster

    fc = _make_forecaster_stub(horizon=2, n_targets=1)

    with (
        patch("twiga.serve.loader.ModelLoader._do_load"),
        patch("twiga.serve.monitor.ForecastMonitor.set_reference"),
    ):
        application = create_app(forecaster=fc, api_key=None)
        application.dependency_overrides[get_forecaster] = lambda: fc

        with TestClient(application) as client:
            yield client, fc


# ---------------------------------------------------------------------------
# /health
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_health_returns_ok(app_client):
    client, _ = app_client
    resp = client.get("/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] in ("ok", "degraded")
    assert "models" in body
    assert "forecast_horizon" in body
    assert "targets" in body


# ---------------------------------------------------------------------------
# /predict
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_predict_returns_forecasts(app_client):
    client, _ = app_client
    payload = {"records": _make_records(5)}
    resp = client.post("/predict", json=payload)
    assert resp.status_code == 200
    body = resp.json()
    assert "forecasts" in body
    assert len(body["forecasts"]) >= 1
    first = body["forecasts"][0]
    assert "model" in first
    assert "predictions" in first
    assert "inference_time" in first


@pytest.mark.integration
def test_predict_empty_records_rejected(app_client):
    client, _ = app_client
    resp = client.post("/predict", json={"records": []})
    assert resp.status_code == 422


@pytest.mark.integration
def test_predict_ensemble_strategy_forwarded(app_client):
    client, fc = app_client
    payload = {"records": _make_records(3), "ensemble_strategy": "mean"}
    client.post("/predict", json=payload)
    _, kwargs = fc.predict.call_args
    assert kwargs.get("ensemble_strategy") == "mean"


# ---------------------------------------------------------------------------
# /predict-interval
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_predict_interval_returns_bounds(app_client):
    client, _ = app_client
    payload = {"records": _make_records(5), "alpha": 0.1}
    resp = client.post("/predict-interval", json=payload)
    assert resp.status_code == 200
    body = resp.json()
    assert "forecasts" in body
    first = body["forecasts"][0]
    assert "lower" in first
    assert "upper" in first
    assert "forecast" in first
    assert abs(first["coverage"] - 0.9) < 1e-6


@pytest.mark.integration
def test_predict_interval_alpha_out_of_range(app_client):
    client, _ = app_client
    resp = client.post("/predict-interval", json={"records": _make_records(3), "alpha": 1.5})
    assert resp.status_code == 422


# ---------------------------------------------------------------------------
# /monitor/drift
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_monitor_drift_returns_response(app_client):
    client, _ = app_client
    with patch("twiga.serve.monitor.ForecastMonitor.run_data_drift") as mock_drift:
        mock_drift.return_value = (
            False,
            {
                "drift_detected": False,
                "n_drifted": 0,
                "feature_drift": {},
                "report_path": None,
                "dataset_drift_score": 0.0,
            },
        )
        resp = client.post("/monitor/drift", json={"records": _make_records(5)})
    assert resp.status_code == 200
    body = resp.json()
    assert "drift_detected" in body
    assert "n_drifted_features" in body


# ---------------------------------------------------------------------------
# /reload
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_reload_returns_reloaded_status(app_client):
    client, _ = app_client
    with (
        patch("twiga.serve.loader.ModelLoader._do_load"),
        patch("twiga.serve.monitor.ForecastMonitor.set_reference"),
    ):
        resp = client.post("/reload")
    assert resp.status_code == 200
    assert resp.json()["status"] == "reloaded"


# ---------------------------------------------------------------------------
# Auth enforcement
# ---------------------------------------------------------------------------


@pytest.mark.integration
def test_auth_rejects_missing_key():
    """When an API key is configured, requests without the header return 403."""
    from twiga.serve.app import create_app, get_forecaster

    fc = _make_forecaster_stub()
    with (
        patch("twiga.serve.loader.ModelLoader._do_load"),
        patch("twiga.serve.monitor.ForecastMonitor.set_reference"),
    ):
        application = create_app(forecaster=fc, api_key="secret-key")
        application.dependency_overrides[get_forecaster] = lambda: fc
        with TestClient(application) as client:
            resp = client.post("/predict", json={"records": _make_records(3)})
    assert resp.status_code == 403


@pytest.mark.integration
def test_auth_accepts_correct_key():
    """Correct X-API-Key header is accepted."""
    from twiga.serve.app import create_app, get_forecaster

    fc = _make_forecaster_stub()
    with (
        patch("twiga.serve.loader.ModelLoader._do_load"),
        patch("twiga.serve.monitor.ForecastMonitor.set_reference"),
    ):
        application = create_app(forecaster=fc, api_key="secret-key")
        application.dependency_overrides[get_forecaster] = lambda: fc
        with TestClient(application) as client:
            resp = client.post(
                "/predict",
                json={"records": _make_records(3)},
                headers={"X-API-Key": "secret-key"},
            )
    assert resp.status_code == 200
