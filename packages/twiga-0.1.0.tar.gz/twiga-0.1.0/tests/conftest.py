"""Root conftest: configure the test environment before any imports."""

from __future__ import annotations


def pytest_configure(config):
    """Suppress the spurious Prefect logging error on teardown.

    Prefect 3.x starts an ephemeral subprocess server. When pytest exits it
    closes stdout/stderr before the server teardown runs. Prefect's emit()
    catches the ValueError from Rich internally and delegates to handleError(),
    which is what prints the '--- Logging error ---' traceback to stderr.

    Silencing handleError on PrefectConsoleHandler removes the noise without
    affecting test behaviour — all tests have already passed at that point.
    """
    try:
        from prefect.logging.handlers import PrefectConsoleHandler

        PrefectConsoleHandler.handleError = lambda self, record: None
    except ImportError:
        pass  # prefect not installed — nothing to do
