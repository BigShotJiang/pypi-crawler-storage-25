"""Unit tests for twiga.serve.monitor.ForecastMonitor with comprehensive edge case coverage."""

from __future__ import annotations

from datetime import UTC
import logging
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import pandas as pd
import pytest

from twiga.serve.monitor import ForecastMonitor

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_df(n: int = 50, cols: list[str] | None = None) -> pd.DataFrame:
    """Create a random DataFrame for testing."""
    cols = cols or ["temp", "hour", "load"]
    rng = np.random.default_rng(42)
    return pd.DataFrame(rng.standard_normal((n, len(cols))), columns=cols)


# ---------------------------------------------------------------------------
# Mocks for Evidently components
# ---------------------------------------------------------------------------


class MockDriftedColumnsCount:
    """Mock for Evidently's DriftedColumnsCount metric."""

    def __init__(self, n_drifted=2, total=5):
        self._n_drifted = n_drifted
        self._total = total

    def get_result(self):
        class Result:
            number_of_drifted_columns = self._n_drifted
            number_of_columns = self._total

        return Result()


class MockCountValue:
    """Minimal stand-in for evidently.core.metric_types.CountValue."""

    def __init__(self, count: float, share: float):
        class _Val:
            def __init__(self, v):
                self.value = v

        self.count = _Val(count)
        self.share = _Val(share)


class MockSnapshot:
    """Mock for the Snapshot object returned by Report.run()."""

    def __init__(self, n_drifted=2, total=5, mae=4.23, rmse=6.11, mape=0.034):
        self._n_drifted = n_drifted
        self._total = total
        self._mae = mae
        self._rmse = rmse
        self._mape = mape

    @property
    def metric_results(self) -> dict:
        share = self._n_drifted / self._total if self._total else 0.0
        return {"mock_key": MockCountValue(count=self._n_drifted, share=share)}

    def json(self) -> str:
        import json

        return json.dumps(
            {
                "metrics": [
                    {"metric_name": "MAE(regression_name=default)", "value": {"mean": self._mae, "std": 0.0}},
                    {"metric_name": "RMSE(regression_name=default)", "value": self._rmse},
                    {"metric_name": "MAPE(regression_name=default)", "value": {"mean": self._mape, "std": 0.0}},
                ]
            }
        )

    def save_html(self, path: str):
        Path(path).touch()

    def save_json(self, path: str):
        Path(path).touch()


class MockReport:
    """Mock Evidently Report that behaves like the real one for drift tests."""

    def __init__(self, n_drifted=2, total=5):
        self._n_drifted = n_drifted
        self._total = total

    def run(self, reference_data, current_data):
        return MockSnapshot(n_drifted=self._n_drifted, total=self._total)


class MockPerformanceReport:
    """Mock Evidently Report for performance (regression) tests."""

    def __init__(self, mae=4.23, rmse=6.11, mape=0.034):
        self._mae = mae
        self._rmse = rmse
        self._mape = mape

    def run(self, reference_data, current_data):
        return MockSnapshot(mae=self._mae, rmse=self._rmse, mape=self._mape)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def monitor(tmp_path: Path) -> ForecastMonitor:
    """Return a monitor with reference data and a temporary report directory."""
    m = ForecastMonitor(report_dir=tmp_path, target_col="load", prediction_col="pred")
    m.set_reference(_make_df())
    return m


@pytest.fixture
def monitor_no_ref(tmp_path: Path) -> ForecastMonitor:
    """Return a monitor without reference data (for tests that set it later)."""
    return ForecastMonitor(report_dir=tmp_path)


# ---------------------------------------------------------------------------
# Basic Tests
# ---------------------------------------------------------------------------


def test_set_reference_logs_info(monitor_no_ref: ForecastMonitor, caplog):
    """Verify that set_reference logs the dataset shape correctly."""
    caplog.set_level(logging.INFO)
    with patch("twiga.serve.monitor.log") as mock_log:
        df = _make_df(n=75)
        monitor_no_ref.set_reference(df)
        mock_log.info.assert_called_once_with("Reference dataset set | shape=%s", (75, 3))


# ---------------------------------------------------------------------------
# run_data_drift Tests + Edge Cases
# ---------------------------------------------------------------------------


def test_run_data_drift_requires_reference(monitor_no_ref: ForecastMonitor):
    """Check that run_data_drift raises an error if no reference is set."""
    with pytest.raises(RuntimeError, match="Reference data not set"):
        monitor_no_ref.run_data_drift(_make_df())


def test_run_data_drift_empty_current(monitor: ForecastMonitor):
    """Ensure empty current DataFrame returns early with drift score 0."""
    empty = pd.DataFrame(columns=["temp", "hour", "load"])
    is_alert, summary = monitor.run_data_drift(empty)
    assert is_alert is False
    assert summary.get("dataset_drift_score") == 0.0
    assert summary.get("error") == "empty_current_data"


def test_run_data_drift_all_nan_column(monitor: ForecastMonitor):
    """Handle a column that is completely NaN with skip policy."""
    df = _make_df(20)
    df["temp"] = np.nan
    monitor.nan_policy = "skip"
    with patch("twiga.serve.monitor.Report", return_value=MockReport()):
        monitor.run_data_drift(df)  # should not raise


def test_run_data_drift_nan_policy_skip(monitor: ForecastMonitor):
    """Test that skip policy does not drop rows with NaNs."""
    df = _make_df(10)
    df.iloc[0:3, 0] = np.nan
    monitor.nan_policy = "skip"
    with patch("twiga.serve.monitor.Report", return_value=MockReport()):
        monitor.run_data_drift(df)


def test_run_data_drift_100_percent_drift(monitor: ForecastMonitor):
    """Simulate 100% drift and verify alert is triggered."""
    with (
        patch.object(monitor, "_extract_drift_summary", return_value={"dataset_drift_score": 1.0}),
        patch.object(monitor, "_log_drift_alert") as mock_log_alert,
        patch("twiga.serve.monitor.Report", return_value=MockReport()),
    ):
        is_alert, summary = monitor.run_data_drift(_make_df(), drift_threshold=0.1)
        assert is_alert is True
        assert summary["dataset_drift_score"] == 1.0
        mock_log_alert.assert_called_once_with("DATA", True, 1.0, 0.1)


def test_run_data_drift_mismatched_columns_no_error(monitor: ForecastMonitor):
    """When no feature_cols given, monitor uses column intersection -> no error."""
    cur = _make_df(cols=["temp", "hour"])
    with patch("twiga.serve.monitor.Report", return_value=MockReport()):
        monitor.run_data_drift(cur)  # should not raise


def test_run_data_drift_missing_requested_column_raises(monitor: ForecastMonitor):
    """Requesting a column not in current data raises KeyError."""
    cur = _make_df(cols=["temp", "hour"])
    with pytest.raises(KeyError, match="not in index"):
        monitor.run_data_drift(cur, feature_cols=["temp", "hour", "load"])


# ---------------------------------------------------------------------------
# run_prediction_drift Tests + Edge Cases
# ---------------------------------------------------------------------------


def test_run_prediction_drift_empty_array(monitor: ForecastMonitor):
    """Empty prediction arrays should be handled gracefully (drift score 0)."""
    empty = np.array([], dtype=float)
    with patch("twiga.serve.monitor.Report", return_value=MockReport(n_drifted=0, total=1)):
        is_alert, summary = monitor.run_prediction_drift(empty, empty)
        assert is_alert is False
        assert summary["dataset_drift_score"] == 0.0


def test_run_prediction_drift_zero_dimensional(monitor: ForecastMonitor):
    """Scalar (0‑dim) prediction arrays are converted to 1x1 DataFrame."""
    scalar = np.array(42.0)
    with patch("twiga.serve.monitor.Report", return_value=MockReport()):
        is_alert, summary = monitor.run_prediction_drift(scalar, scalar)
        assert isinstance(is_alert, bool)


def test_run_prediction_drift_all_same(monitor: ForecastMonitor):
    """Identical reference and current predictions -> no drift."""
    same = np.full(100, 42.0)
    with patch("twiga.serve.monitor.Report", return_value=MockReport(n_drifted=0, total=1)):
        is_alert, summary = monitor.run_prediction_drift(same, same)
        assert is_alert is False
        assert summary.get("dataset_drift_score") == 0.0


# ---------------------------------------------------------------------------
# run_performance Tests + Edge Cases
# ---------------------------------------------------------------------------


# Patch DataDefinition to avoid version incompatibility
@pytest.fixture(autouse=True)
def mock_datadefinition():
    """Mock DataDefinition to bypass Evidently version differences."""
    with patch("twiga.serve.monitor.DataDefinition", return_value=MagicMock()):
        yield


def test_run_performance_empty_df(monitor_no_ref: ForecastMonitor):
    """Empty DataFrame should still produce a report path."""
    empty = pd.DataFrame(columns=["load", "pred"])
    with patch("twiga.serve.monitor.Report", return_value=MockPerformanceReport()):
        summary = monitor_no_ref.run_performance(empty, target_col="load", prediction_col="pred")
        assert "report_path" in summary


def test_run_performance_all_nan(monitor_no_ref: ForecastMonitor):
    """All-NaN target/prediction should skip metric extraction."""
    df = pd.DataFrame({"load": [np.nan] * 10, "pred": [np.nan] * 10})
    with patch("twiga.serve.monitor.Report", return_value=MockPerformanceReport(mae=np.nan, rmse=np.nan, mape=np.nan)):
        summary = monitor_no_ref.run_performance(df, target_col="load", prediction_col="pred")
        assert "mae" not in summary


def test_run_performance_single_row(monitor_no_ref: ForecastMonitor):
    """Single row of data should compute metrics correctly."""
    df = pd.DataFrame({"load": [10.0], "pred": [11.5]})
    with patch("twiga.serve.monitor.Report", return_value=MockPerformanceReport()):
        summary = monitor_no_ref.run_performance(df, target_col="load", prediction_col="pred")
        assert "mae" in summary


# ---------------------------------------------------------------------------
# run_full_monitoring
# ---------------------------------------------------------------------------


def test_run_full_monitoring(monitor: ForecastMonitor):
    """Combined monitoring run returns overall alert flag."""
    with (
        patch.object(monitor, "run_data_drift", return_value=(False, {})),
        patch.object(monitor, "run_prediction_drift", return_value=(True, {})),
        patch.object(monitor, "run_performance", return_value={"mae": 2.5}),
    ):
        result = monitor.run_full_monitoring(
            current_df=_make_df(),
            current_predictions=np.random.randn(50),
            reference_predictions=np.random.randn(50),
        )
        assert result["overall_alert"] is True


# ---------------------------------------------------------------------------
# Report Saving & MLflow
# ---------------------------------------------------------------------------


def test_save_report_creates_both_files(monitor: ForecastMonitor):
    """_save_report should create HTML and JSON report files."""
    report = MockSnapshot()
    path = monitor._save_report(report, "data_drift")
    assert path.suffix == ".html"
    assert path.with_suffix(".json").exists()


def test_mlflow_only_when_active(monitor: ForecastMonitor):
    """Metrics are logged only when an MLflow run is active."""
    with patch("mlflow.active_run", return_value=False), patch("mlflow.log_metric") as mock_log:
        with patch("twiga.serve.monitor.Report", return_value=MockReport()):
            monitor.run_data_drift(_make_df())
        mock_log.assert_not_called()


# ---------------------------------------------------------------------------
# Extraction Fallbacks
# ---------------------------------------------------------------------------


def test_drift_extraction_fallback(monitor: ForecastMonitor):
    """When extraction fails, monitor logs and returns a zeroed summary (no silent fallback)."""
    bad_report = MagicMock()
    bad_report.metrics.side_effect = Exception("fail")
    with patch("twiga.serve.monitor.Report", return_value=bad_report):
        _, summary = monitor.run_data_drift(_make_df())
        assert summary["dataset_drift_score"] == 0.0
        assert summary["drift_detected"] is False


# ---------------------------------------------------------------------------
# Optional Real Integration Test (skip if Evidently not available or <0.7.0)
# ---------------------------------------------------------------------------


@pytest.mark.skip(reason="Requires Evidently 0.7.0+ with correct API and full installation")
def test_real_evidently_smoke(monitor: ForecastMonitor):
    """Smoke test with real Evidently installation (if present)."""
    pytest.importorskip("evidently", minversion="0.7.0")
    ref = _make_df(30)
    cur = _make_df(30)
    monitor.set_reference(ref)
    is_alert, summary = monitor.run_data_drift(cur)
    assert Path(summary["report_path"]).exists()
    perf = monitor.run_performance(_make_df(cols=["load", "pred"]), target_col="load", prediction_col="pred")
    assert isinstance(perf.get("mae"), (int, float, type(None)))
