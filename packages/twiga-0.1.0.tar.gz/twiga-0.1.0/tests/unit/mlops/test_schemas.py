"""Unit tests for twiga.serve.schemas — no heavy dependencies required."""

from __future__ import annotations

import numpy as np
from pydantic import ValidationError
import pytest

from twiga.serve.schemas import (
    ForecastRequest,
    ForecastResponse,
    HealthResponse,
    IntervalRequest,
    IntervalResponse,
    ModelPrediction,
    MonitorResponse,
)

# ---------------------------------------------------------------------------
# ForecastRequest
# ---------------------------------------------------------------------------


def test_forecast_request_minimal():
    req = ForecastRequest(records=[{"timestamp": "2024-01-01", "temp": 12.5}])
    assert len(req.records) == 1
    assert req.ensemble_strategy is None
    assert req.prepare_test_data is True


def test_forecast_request_empty_records_raises():
    with pytest.raises(ValidationError):
        ForecastRequest(records=[])


def test_forecast_request_ensemble_strategy():
    req = ForecastRequest(
        records=[{"timestamp": "2024-01-01"}],
        ensemble_strategy="mean",
    )
    assert req.ensemble_strategy == "mean"


# ---------------------------------------------------------------------------
# IntervalRequest
# ---------------------------------------------------------------------------


def test_interval_request_defaults():
    req = IntervalRequest(records=[{"timestamp": "2024-01-01"}])
    assert req.alpha == 0.1


def test_interval_request_custom_alpha():
    req = IntervalRequest(records=[{"timestamp": "2024-01-01"}], alpha=0.05)
    assert req.alpha == 0.05


def test_interval_request_alpha_out_of_range():
    with pytest.raises(ValidationError):
        IntervalRequest(records=[{"timestamp": "2024-01-01"}], alpha=1.5)


# ---------------------------------------------------------------------------
# ForecastResponse.from_arrays
# ---------------------------------------------------------------------------


def test_forecast_response_from_arrays():
    preds = {"lgbm": np.ones((2, 24, 1)), "catboost": np.zeros((2, 24, 1))}
    times = {"lgbm": 0.03, "catboost": 0.02}
    resp = ForecastResponse.from_arrays(
        predictions=preds,
        inference_times=times,
        targets=["Load(MW)"],
        forecast_horizon=24,
    )
    assert resp.forecast_horizon == 24
    assert resp.targets == ["Load(MW)"]
    assert len(resp.forecasts) == 2
    model_names = {f.model for f in resp.forecasts}
    assert model_names == {"lgbm", "catboost"}


def test_forecast_response_predictions_shape():
    arr = np.ones((1, 4, 2))
    resp = ForecastResponse.from_arrays(
        predictions={"m": arr},
        inference_times={"m": 0.0},
        targets=["a", "b"],
        forecast_horizon=4,
    )
    pred = resp.forecasts[0]
    assert len(pred.predictions) == 1  # batch
    assert len(pred.predictions[0]) == 4  # horizon
    assert len(pred.predictions[0][0]) == 2  # targets


# ---------------------------------------------------------------------------
# IntervalResponse.from_arrays
# ---------------------------------------------------------------------------


def test_interval_response_from_arrays():
    lower = np.zeros((1, 12, 1))
    point = np.ones((1, 12, 1))
    upper = np.full((1, 12, 1), 2.0)
    preds = {"lgbm": (lower, point, upper)}
    resp = IntervalResponse.from_arrays(
        predictions=preds,
        inference_times={"lgbm": 0.01},
        targets=["Load"],
        forecast_horizon=12,
        alpha=0.1,
    )
    assert resp.forecast_horizon == 12
    iv = resp.forecasts[0]
    assert iv.coverage == pytest.approx(0.9)
    assert iv.lower[0][0][0] == pytest.approx(0.0)
    assert iv.upper[0][0][0] == pytest.approx(2.0)


# ---------------------------------------------------------------------------
# HealthResponse
# ---------------------------------------------------------------------------


def test_health_response_ok():
    h = HealthResponse(
        status="ok",
        models=["lgbm"],
        forecast_horizon=24,
        targets=["Load"],
    )
    assert h.status == "ok"


def test_health_response_degraded():
    h = HealthResponse(
        status="degraded",
        models=[],
        forecast_horizon=0,
        targets=[],
    )
    assert h.status == "degraded"


# ---------------------------------------------------------------------------
# MonitorResponse
# ---------------------------------------------------------------------------


def test_monitor_response():
    m = MonitorResponse(
        drift_detected=True,
        n_drifted_features=3,
        feature_drift={"temp": 0.12, "hour": 0.01},
        report_path="/tmp/report.html",  # noqa: S108
    )
    assert m.drift_detected is True
    assert m.n_drifted_features == 3
    assert m.feature_drift["temp"] == pytest.approx(0.12)


def test_monitor_response_no_report_path():
    m = MonitorResponse(
        drift_detected=False,
        n_drifted_features=0,
        feature_drift={},
    )
    assert m.report_path is None
