from unittest.mock import MagicMock, patch

from fastapi.testclient import TestClient
import numpy as np
import pandas as pd
from pydantic import ValidationError
import pytest

from twiga.forecaster.core import TwigaForecaster
from twiga.serve.app import create_app, get_forecaster
from twiga.serve.schemas import IntervalRequest

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_forecaster():
    """Mock TwigaForecaster with dictionary returns to match schema requirements."""
    forecaster = MagicMock(spec=TwigaForecaster)

    # from_arrays expects: dict[str, np.ndarray] and dict[str, float]
    mock_preds = {"test_model": np.array([[[1.0]]])}
    mock_times = {"test_model": 0.1}
    forecaster.predict.return_value = (mock_preds, mock_times)

    # predict_interval expects: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]]
    mock_interval_preds = {"test_model": (np.array([[[0.9]]]), np.array([[[1.0]]]), np.array([[[1.1]]]))}
    forecaster.predict_interval.return_value = (mock_interval_preds, mock_times)

    forecaster.data_pipeline = MagicMock()
    forecaster.data_pipeline.data = pd.DataFrame({"feature": [1, 2, 3]})
    return forecaster


@pytest.fixture
def app(mock_forecaster):
    """Create app and ensure dependency and internal component injection."""
    with (
        patch("twiga.serve.app.ModelLoader") as mock_loader_cls,
        patch("twiga.serve.app.ForecastMonitor") as mock_monitor_cls,
    ):
        # Loader metadata setup
        loader_instance = mock_loader_cls.return_value
        loader_instance.load.return_value = mock_forecaster
        loader_instance.is_loaded = True
        loader_instance.model_names = ["test_model"]
        loader_instance.targets = ["target"]
        loader_instance.forecast_horizon = 1

        # Monitor results setup (run_data_drift returns (is_alert, summary) tuple)
        monitor_instance = mock_monitor_cls.return_value
        monitor_instance.run_data_drift.return_value = (
            False,
            {
                "drift_detected": False,
                "n_drifted": 0,
                "feature_drift": {},
                "report_path": "rp",
                "dataset_drift_score": 0.0,
            },
        )
        monitor_instance.run_performance.return_value = {"mae": 0.1, "rmse": 0.1, "mape": 1.0, "report_path": "rp"}

        test_app = create_app(forecaster=mock_forecaster)

        # Override the global dependency defined at the module level in app.py
        test_app.dependency_overrides[get_forecaster] = lambda: mock_forecaster

        yield test_app, monitor_instance
        test_app.dependency_overrides.clear()


@pytest.fixture
def client(app):
    """Test client with lifespan context enabled."""
    test_app, _ = app
    with TestClient(test_app) as c:
        yield c


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_predict_success(client):
    """Verifies predict endpoint. Fixes the 'list has no attribute items' error."""
    payload = {"records": [{"timestamp": "2024-01-01T00:00:00Z", "feature": 1}], "ensemble_strategy": "mean"}
    response = client.post("/predict", json=payload)

    assert response.status_code == 200
    data = response.json()
    # Schema check: ForecastResponse has 'forecasts' (list of ModelPrediction)
    assert "forecasts" in data
    assert data["forecasts"][0]["model"] == "test_model"


def test_interval_request_validation():
    """Fixes 'DID NOT RAISE' by targeting specific schema constraints."""
    # 1. Test alpha 'ge=0.0, lt=1.0' constraint
    with pytest.raises(ValidationError):
        IntervalRequest(records=[{"t": 1}], alpha=1.5)

    # 2. Test 'min_length=1' on records
    with pytest.raises(ValidationError):
        IntervalRequest(records=[], alpha=0.05)

    # 3. Test invalid ensemble_strategy Literal
    with pytest.raises(ValidationError):
        IntervalRequest(records=[{"t": 1}], ensemble_strategy="invalid_option")


def test_monitor_performance_key_error(app, client):
    """Verifies that KeyError in monitor logic returns a 422 via the app logic."""
    _, mock_monitor = app
    # Simulate the monitor failing to find 'actuals' in the provided dataframe
    mock_monitor.run_performance.side_effect = KeyError("actual")

    payload = {"records": [{"timestamp": "2024-01-01T00:00:00Z"}], "ensemble_strategy": "mean"}
    response = client.post("/monitor/performance", json=payload)

    assert response.status_code == 422
    assert "Missing expected column" in response.json()["detail"]


def test_value_error_exception_handler(client):
    """Ensures malformed date strings trigger our custom 422 handler."""
    payload = {"records": [{"timestamp": "this-is-not-a-date"}], "ensemble_strategy": "mean"}
    response = client.post("/predict", json=payload)

    assert response.status_code == 422
    assert "Data validation error" in response.json()["detail"]
