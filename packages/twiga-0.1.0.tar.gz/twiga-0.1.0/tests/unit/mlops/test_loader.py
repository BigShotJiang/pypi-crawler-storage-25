"""Unit tests for twiga.serve.loader.ModelLoader."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, Mock, patch

import pytest

from twiga.core.exceptions import NotFittedError
from twiga.serve.loader import ModelLoader

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_forecaster(tmp_path):
    """A mock forecaster with a valid checkpoints_path."""
    fc = Mock()
    fc.checkpoints_path = str(tmp_path)
    fc.data_pipeline = Mock()
    fc.data_pipeline.target_feature = ["Load(MW)"]
    fc.data_pipeline.forecast_horizon = 24
    fc.models = [Mock(model_type="lightgbm"), Mock(model_type="catboost")]
    return fc


@pytest.fixture
def checkpoint_file(tmp_path):
    """Create a dummy checkpoint file."""
    f = tmp_path / "model.pkl"
    f.write_bytes(b"fake-checkpoint")
    return f


# ---------------------------------------------------------------------------
# load()
# ---------------------------------------------------------------------------


def test_load_calls_on_load_checkpoint(mock_forecaster, checkpoint_file):
    loader = ModelLoader(mock_forecaster)
    loader.load()
    mock_forecaster.on_load_checkpoint.assert_called_once()


def test_load_idempotent(mock_forecaster, checkpoint_file):
    loader = ModelLoader(mock_forecaster)
    loader.load()
    loader.load()
    # on_load_checkpoint should only be called once
    mock_forecaster.on_load_checkpoint.assert_called_once()


def test_load_returns_forecaster(mock_forecaster, checkpoint_file):
    loader = ModelLoader(mock_forecaster)
    result = loader.load()
    assert result is mock_forecaster


def test_load_raises_if_no_checkpoints_path(tmp_path):
    fc = Mock()
    fc.checkpoints_path = None
    loader = ModelLoader(fc)
    with pytest.raises(ValueError, match="checkpoints_path"):
        loader.load()


def test_load_raises_if_dir_missing(tmp_path):
    fc = Mock()
    fc.checkpoints_path = str(tmp_path / "nonexistent")
    loader = ModelLoader(fc)
    with pytest.raises(NotFittedError, match="does not exist"):
        loader.load()


def test_load_raises_if_dir_empty(tmp_path):
    fc = Mock()
    fc.checkpoints_path = str(tmp_path)
    loader = ModelLoader(fc)
    with pytest.raises(NotFittedError, match="No checkpoint files"):
        loader.load()


# ---------------------------------------------------------------------------
# reload()
# ---------------------------------------------------------------------------


def test_reload_forces_fresh_load(mock_forecaster, checkpoint_file):
    loader = ModelLoader(mock_forecaster)
    loader.load()
    loader.reload()
    assert mock_forecaster.on_load_checkpoint.call_count == 2


def test_reload_returns_forecaster(mock_forecaster, checkpoint_file):
    loader = ModelLoader(mock_forecaster)
    result = loader.reload()
    assert result is mock_forecaster


# ---------------------------------------------------------------------------
# is_loaded property
# ---------------------------------------------------------------------------


def test_is_loaded_false_before_load(mock_forecaster):
    loader = ModelLoader(mock_forecaster)
    assert loader.is_loaded is False


def test_is_loaded_true_after_load(mock_forecaster, checkpoint_file):
    loader = ModelLoader(mock_forecaster)
    loader.load()
    assert loader.is_loaded is True


# ---------------------------------------------------------------------------
# Properties
# ---------------------------------------------------------------------------


def test_targets_property(mock_forecaster, checkpoint_file):
    loader = ModelLoader(mock_forecaster)
    loader.load()
    assert loader.targets == ["Load(MW)"]


def test_targets_wraps_scalar_in_list(mock_forecaster, checkpoint_file):
    mock_forecaster.data_pipeline.target_feature = "Load(MW)"
    loader = ModelLoader(mock_forecaster)
    loader.load()
    assert loader.targets == ["Load(MW)"]


def test_forecast_horizon_property(mock_forecaster, checkpoint_file):
    loader = ModelLoader(mock_forecaster)
    loader.load()
    assert loader.forecast_horizon == 24


def test_model_names_property(mock_forecaster, checkpoint_file):
    loader = ModelLoader(mock_forecaster)
    loader.load()
    assert loader.model_names == ["lightgbm", "catboost"]


def test_properties_raise_if_not_loaded(mock_forecaster):
    loader = ModelLoader(mock_forecaster)
    with pytest.raises(NotFittedError):
        _ = loader.targets
    with pytest.raises(NotFittedError):
        _ = loader.forecast_horizon
    with pytest.raises(NotFittedError):
        _ = loader.model_names
