"""Unit tests for twiga.tracking.TwigaTracker (MLflow mocked)."""

from __future__ import annotations

from pathlib import Path
import subprocess
from unittest.mock import MagicMock, Mock, patch

import pandas as pd
import pytest

from twiga.tracking.tracker import TwigaTracker

# ---------------------------------------------------------------------------
# Simple Helper Class for Metadata Testing
# ---------------------------------------------------------------------------


class MockForecaster:
    """A simple class to avoid Mock.__dict__ iteration issues."""

    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)
        # Ensure standard attributes exist for getattr calls
        self.data_pipeline = getattr(self, "data_pipeline", None)
        self.conformal_params = getattr(self, "conformal_params", None)
        self.train_params = getattr(self, "train_params", None)
        self.model_params = getattr(self, "model_params", None)
        self.project_name = getattr(self, "project_name", "test_project")
        self.model_type = getattr(self, "model_type", "test_model")


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_mlflow(monkeypatch):
    """Patch the mlflow module used inside tracker.py."""
    mlflow_mock = MagicMock()
    run_info = MagicMock()
    run_info.run_id = "test-run-id-abc123"
    active_run = MagicMock()
    active_run.info = run_info
    mlflow_mock.start_run.return_value = active_run

    mlflow_mock.pyfunc.get_default_conda_env.return_value = {"dependencies": [{"pip": []}]}

    monkeypatch.setattr("twiga.tracking.tracker.mlflow", mlflow_mock)
    return mlflow_mock


@pytest.fixture
def tracker(mock_mlflow):
    """Returns a TwigaTracker instance with mocked MLflow."""
    return TwigaTracker(experiment="test-exp", run_name="test-run", tags={"env": "test"})


# ---------------------------------------------------------------------------
# Context Manager & Git Logic
# ---------------------------------------------------------------------------


def test_enter_starts_run_with_git(tracker: TwigaTracker, mock_mlflow: MagicMock) -> None:
    """Verifies that __enter__ captures Git context correctly."""
    # Since the code uses text=True, the mock should return a STRING
    mock_git_output = "fake_commit_hash\n"

    with (
        patch("shutil.which", return_value="/usr/bin/git"),
        patch("subprocess.check_output", return_value=mock_git_output),
    ):
        tracker.__enter__()

        actual_tags = mock_mlflow.start_run.call_args.kwargs["tags"]
        actual_val = actual_tags["mlflow.source.git.commit"]

        # Now it's String vs String. Victory!
        assert actual_val == "fake_commit_hash"
        assert isinstance(actual_val, str)


# ---------------------------------------------------------------------------
# Metadata & Parameter Harvesting
# ---------------------------------------------------------------------------


def test_log_forecaster_metadata_harvesting(tracker: TwigaTracker, mock_mlflow: MagicMock) -> None:
    """Tests the 'Investigator' pattern for gathering hyperparameters."""
    tracker.__enter__()

    # Mock a data pipeline that behaves like a Pydantic model
    mock_pipeline = Mock()
    mock_pipeline.model_dump.return_value = {"batch_size": 32}

    # Use our helper class instead of a standard Mock to avoid __dict__ issues
    forecaster = MockForecaster(
        learning_rate=0.001, project_name="test_project", _internal_state="hidden", data_pipeline=mock_pipeline
    )

    tracker.log_forecaster_metadata(forecaster)

    logged_params = mock_mlflow.log_params.call_args[0][0]
    assert logged_params["data.batch_size"] == "32"
    assert logged_params["learning_rate"] == "0.001"
    assert "_internal_state" not in logged_params


def test_log_forecaster_metadata_large_param_safety(tracker: TwigaTracker, mock_mlflow: MagicMock) -> None:
    """Tests character-limit safety (both for specific and general cases)."""
    tracker.__enter__()

    large_val = "x" * 5000
    forecaster = MockForecaster(feature_list=large_val)

    tracker.log_forecaster_metadata(forecaster)

    logged_params = mock_mlflow.log_params.call_args[0][0]
    # Check that it triggered the 'logged_as_artifact' logic
    assert logged_params["feature_list"] == "logged_as_artifact"
    mock_mlflow.log_text.assert_called_with(large_val, "params/feature_list.json")


# ---------------------------------------------------------------------------
# Model Logging (PyFunc Wrapper)
# ---------------------------------------------------------------------------


def test_log_model_signature_and_wrapper(tracker, mock_mlflow):
    tracker.__enter__()
    # Here standard Mock is fine because we aren't iterating over __dict__
    forecaster = Mock()
    forecaster.project_name = "twiga"
    forecaster.model_type = "nhits"

    sample_df = pd.DataFrame({"x": [1, 2, 3]})
    preds = pd.DataFrame({"y": [0.1, 0.2, 0.3]})
    forecaster.evaluate_point_forecast.return_value = (preds, None)

    tracker.log_model(forecaster, sample_df)

    assert mock_mlflow.pyfunc.log_model.called
    args = mock_mlflow.pyfunc.log_model.call_args.kwargs
    assert args["registered_model_name"] == "twiga_nhits"
    assert "twiga" in args["conda_env"]["dependencies"][-1]["pip"]


# ---------------------------------------------------------------------------
# Evaluation & Dataset Lineage
# ---------------------------------------------------------------------------


def test_log_dataset_lineage(tracker, mock_mlflow):
    tracker.__enter__()
    df = pd.DataFrame({"a": [1]})
    tracker.log_dataset(df, name="raw_sales", source="s3://bucket/data.csv")

    assert mock_mlflow.data.from_pandas.called
    assert mock_mlflow.log_input.called


def test_log_evaluation_table_and_metrics(tracker, mock_mlflow):
    tracker.__enter__()
    metrics_df = pd.DataFrame({"mae": [1.0, 2.0], "rmse": [4.0, 5.0]})
    results_df = pd.DataFrame({"actual": [10, 20], "pred": [11, 19]})

    tracker.log_evaluation(metrics_df, results_df)

    mock_mlflow.log_metrics.assert_called_once_with({"mae": 1.5, "rmse": 4.5})
    mock_mlflow.log_table.assert_called_once()
