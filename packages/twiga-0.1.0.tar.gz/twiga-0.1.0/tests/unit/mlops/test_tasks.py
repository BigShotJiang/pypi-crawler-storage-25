"""Unit tests for twiga.pipeline.tasks and twiga.pipeline.flows (Prefect decorators mocked)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, Mock, patch

import numpy as np
import pandas as pd
import pytest

# ---------------------------------------------------------------------------
# Fixture to disable Prefect decorators for unit tests
# ---------------------------------------------------------------------------


def _noop_decorator(*args, **kwargs):
    """Handles both @task and @task(name=...) calling conventions."""
    if args and callable(args[0]) and not kwargs:
        return args[0]
    return lambda func: func


_PIPELINE_MODULES = [
    "twiga.pipeline.tasks",
    "twiga.pipeline.flows",
    "twiga.pipeline",
]


@pytest.fixture(autouse=True)
def mock_prefect_decorators():
    """Replace @task and @flow decorators with no-ops, and mock get_run_logger.

    twiga.pipeline.__init__ eagerly imports tasks, so by the time tests run the
    real @task wrappers (with retries/delays) are already applied. We evict those
    modules from sys.modules before patching so the fresh import sees the no-op
    decorators instead.
    """
    import sys

    saved = {k: sys.modules.pop(k) for k in _PIPELINE_MODULES if k in sys.modules}
    try:
        with (
            patch("prefect.task", _noop_decorator),
            patch("prefect.flow", _noop_decorator),
            patch("prefect.get_run_logger", return_value=Mock()),
        ):
            yield
    finally:
        # Evict freshly imported modules so next test also gets a clean slate.
        for k in _PIPELINE_MODULES:
            sys.modules.pop(k, None)
        # Restore originals so the rest of the suite isn't affected.
        sys.modules.update(saved)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_df(n: int = 100) -> pd.DataFrame:
    dates = pd.date_range("2023-01-01", periods=n, freq="h", tz="UTC")
    rng = np.random.default_rng(0)
    return pd.DataFrame({"timestamp": dates, "load": rng.standard_normal(n), "temp": rng.standard_normal(n)})


# ===========================================================================
# TASKS TESTS (decorators are no-ops, so call directly)
# ===========================================================================

# ---------------------------------------------------------------------------
# load_data
# ---------------------------------------------------------------------------


def test_load_data_parquet(tmp_path):
    from twiga.pipeline.tasks import load_data

    df = _make_df()
    path = tmp_path / "data.parquet"
    df.to_parquet(path, index=False)

    train, test = load_data(data_path=path, date_col="timestamp")
    assert len(train) + len(test) == len(df)
    assert len(train) == int(len(df) * 0.8)


def test_load_data_csv(tmp_path):
    from twiga.pipeline.tasks import load_data

    df = _make_df(50)
    path = tmp_path / "data.csv"
    df.to_csv(path, index=False)

    train, test = load_data(data_path=path, date_col="timestamp")
    assert len(train) > 0
    assert len(test) > 0


def test_load_data_custom_split(tmp_path):
    from twiga.pipeline.tasks import load_data

    df = _make_df(200)
    path = tmp_path / "data.parquet"
    df.to_parquet(path, index=False)

    train, test = load_data(
        data_path=path,
        date_col="timestamp",
        train_end="2023-01-05",
        test_start="2023-01-06",
    )
    assert len(train) > 0
    assert len(test) > 0


def test_load_data_file_not_found(tmp_path):
    from twiga.pipeline.tasks import load_data

    with pytest.raises(FileNotFoundError):
        load_data(data_path=tmp_path / "missing.parquet")


def test_load_data_unsupported_format(tmp_path):
    from twiga.pipeline.tasks import load_data

    path = tmp_path / "data.xlsx"
    path.write_bytes(b"fake")
    with pytest.raises(ValueError, match="Unsupported"):
        load_data(data_path=path)


def test_load_data_missing_date_col(tmp_path):
    from twiga.pipeline.tasks import load_data

    df = pd.DataFrame({"a": [1, 2, 3]})
    path = tmp_path / "data.parquet"
    df.to_parquet(path, index=False)
    with pytest.raises(ValueError, match="Date column"):
        load_data(data_path=path, date_col="timestamp")


# ---------------------------------------------------------------------------
# fit_forecaster
# ---------------------------------------------------------------------------


def test_fit_forecaster_calls_fit():
    from twiga.pipeline.tasks import fit_forecaster

    fc = Mock()
    train_df = _make_df()
    result = fit_forecaster(forecaster=fc, train_df=train_df)
    fc.fit.assert_called_once_with(train_df, None)
    assert result is fc


def test_fit_forecaster_with_tuning():
    from twiga.pipeline.tasks import fit_forecaster

    fc = Mock()
    train_df = _make_df()
    fit_forecaster(forecaster=fc, train_df=train_df, tune=True, num_trials=5)
    fc.tune.assert_called_once()
    fc.fit.assert_called_once()


def test_fit_forecaster_with_val_df():
    from twiga.pipeline.tasks import fit_forecaster

    fc = Mock()
    train_df = _make_df(80)
    val_df = _make_df(20)
    fit_forecaster(forecaster=fc, train_df=train_df, val_df=val_df)
    fc.fit.assert_called_once_with(train_df, val_df)


# ---------------------------------------------------------------------------
# evaluate_model
# ---------------------------------------------------------------------------


def test_evaluate_model_returns_dfs():
    from twiga.pipeline.tasks import evaluate_model

    fc = Mock()
    preds_df = pd.DataFrame({"pred": [1.0, 2.0]})
    metrics_df = pd.DataFrame({"Model": ["lgbm"], "mae": [4.1], "rmse": [6.0]})
    fc.evaluate.return_value = (preds_df, metrics_df)

    preds, metrics = evaluate_model(forecaster=fc, test_df=_make_df())
    assert list(metrics.columns) == ["Model", "mae", "rmse"]


def test_evaluate_model_passes_ensemble_strategy():
    from twiga.pipeline.tasks import evaluate_model

    fc = Mock()
    fc.evaluate.return_value = (pd.DataFrame(), pd.DataFrame({"Model": [], "mae": [], "rmse": []}))
    test_df = _make_df()
    evaluate_model(forecaster=fc, test_df=test_df, ensemble_strategy="mean")
    _, call_kwargs = fc.evaluate.call_args
    assert call_kwargs.get("ensemble_strategy") == "mean"


# ---------------------------------------------------------------------------
# save_checkpoint
# ---------------------------------------------------------------------------


def test_save_checkpoint_calls_on_save(tmp_path):
    from twiga.pipeline.tasks import save_checkpoint

    fc = Mock()
    fc.checkpoints_path = str(tmp_path)
    fc.on_save_checkpoint.return_value = str(tmp_path)
    result = save_checkpoint(forecaster=fc)
    fc.on_save_checkpoint.assert_called_once()
    assert result == str(tmp_path)


def test_save_checkpoint_raises_if_no_path():
    from twiga.pipeline.tasks import save_checkpoint

    fc = Mock()
    fc.checkpoints_path = None
    with pytest.raises(RuntimeError, match="checkpoints_path is not configured"):
        save_checkpoint(forecaster=fc)


def test_save_checkpoint_raises_if_attr_missing():
    from twiga.pipeline.tasks import save_checkpoint

    fc = object()
    with pytest.raises(RuntimeError, match="checkpoints_path is not configured"):
        save_checkpoint(forecaster=fc)


# ---------------------------------------------------------------------------
# run_drift_check
# ---------------------------------------------------------------------------


def test_run_drift_check_returns_summary(tmp_path):
    from twiga.pipeline.tasks import run_drift_check

    monitor = Mock()
    monitor.run_data_drift.return_value = (
        True,
        {
            "drift_detected": True,
            "n_drifted": 2,
            "dataset_drift_score": 0.4,
            "feature_drift": {},
            "report_path": str(tmp_path / "report.html"),
        },
    )

    with patch("twiga.pipeline.tasks.ForecastMonitor", return_value=monitor):
        summary = run_drift_check(
            reference_df=_make_df(),
            current_df=_make_df(),
            report_dir=tmp_path,
        )
    assert summary["drift_detected"] is True
    assert summary["n_drifted"] == 2
    monitor.set_reference.assert_called_once()
    monitor.run_data_drift.assert_called_once()


def test_run_drift_check_passes_feature_cols(tmp_path):
    from twiga.pipeline.tasks import run_drift_check

    monitor = Mock()
    monitor.run_data_drift.return_value = (
        False,
        {
            "drift_detected": False,
            "n_drifted": 0,
            "dataset_drift_score": 0.0,
            "feature_drift": {},
            "report_path": None,
        },
    )

    with patch("twiga.pipeline.tasks.ForecastMonitor", return_value=monitor):
        run_drift_check(
            reference_df=_make_df(),
            current_df=_make_df(),
            feature_cols=["load"],
        )
    call_kwargs = monitor.run_data_drift.call_args[1]
    assert call_kwargs.get("feature_cols") == ["load"]


# ---------------------------------------------------------------------------
# decide_retrain
# ---------------------------------------------------------------------------


def test_decide_retrain_logic():
    from twiga.pipeline.tasks import decide_retrain

    # Drift triggers retrain
    assert (
        decide_retrain(
            drift_summary={"dataset_drift_score": 0.8},
            incumbent_metric=0.1,
            drift_threshold=0.5,
        )
        is True
    )

    # Performance triggers retrain (minimize=True)
    assert (
        decide_retrain(
            drift_summary={"dataset_drift_score": 0.1},
            incumbent_metric=0.9,
            performance_threshold=0.5,
            minimize=True,
        )
        is True
    )

    # No trigger
    assert (
        decide_retrain(
            drift_summary={"dataset_drift_score": 0.2},
            incumbent_metric=0.4,
            drift_threshold=0.5,
            performance_threshold=0.5,
            minimize=True,
        )
        is False
    )


# ---------------------------------------------------------------------------
# log_to_mlflow
# ---------------------------------------------------------------------------


def test_log_to_mlflow_returns_run_id():
    from twiga.pipeline.tasks import log_to_mlflow

    tracker = MagicMock()
    tracker.__enter__ = Mock(return_value=tracker)
    tracker.__exit__ = Mock(return_value=False)
    # run_id is now a property on TwigaTracker; set it as an attribute on the mock.
    tracker.run_id = "run-abc-123"
    tracker_cls = Mock(return_value=tracker)

    fc = Mock()
    metrics_df = pd.DataFrame({"Model": ["lgbm"], "mae": [4.0]})

    with patch("twiga.tracking.tracker.TwigaTracker", tracker_cls):
        run_id = log_to_mlflow(
            forecaster=fc,
            metrics_df=metrics_df,
            experiment="test-exp",
            run_name="run-1",
        )
    assert run_id == "run-abc-123"


# ===========================================================================
# FLOWS TESTS (decorators are no-ops, tasks are mocked)
# ===========================================================================

# ---------------------------------------------------------------------------
# training_flow
# ---------------------------------------------------------------------------


def test_training_flow_calls_all_tasks(tmp_path):
    from twiga.pipeline.flows import training_flow

    with (
        patch("twiga.pipeline.flows.load_data") as mock_load,
        patch("twiga.pipeline.flows.fit_forecaster") as mock_fit,
        patch("twiga.pipeline.flows.evaluate_model") as mock_eval,
        patch("twiga.pipeline.flows.save_checkpoint") as mock_save,
        patch("twiga.pipeline.flows.log_to_mlflow") as mock_log,
        patch("twiga.pipeline.flows._publish_metrics_artifact") as mock_publish,
    ):
        mock_load.return_value = (pd.DataFrame(), pd.DataFrame())
        fitted_fc = Mock()
        mock_fit.return_value = fitted_fc
        pred_df = pd.DataFrame()
        metrics_df = pd.DataFrame({"Model": ["lgbm"], "mae": [2.0]})
        mock_eval.return_value = (pred_df, metrics_df)
        mock_save.return_value = "/fake/checkpoint"
        mock_log.return_value = "run-123"

        forecaster = Mock()
        result = training_flow(
            forecaster=forecaster,
            data_path=tmp_path / "data.parquet",
            experiment="test",
            run_name="test-run",
        )

        mock_load.assert_called_once()
        mock_fit.assert_called_once()
        mock_eval.assert_called_once()
        mock_save.assert_called_once_with(forecaster=fitted_fc)
        mock_log.assert_called_once()
        mock_publish.assert_called_once()

        assert result.checkpoint_path == "/fake/checkpoint"
        assert result.mlflow_run_id == "run-123"
        assert "lgbm" in result.metrics


# ---------------------------------------------------------------------------
# retraining_flow
# ---------------------------------------------------------------------------


def test_retraining_flow_skips_retrain_when_no_drift_and_performance_ok(tmp_path):
    from twiga.pipeline.flows import retraining_flow

    with (
        patch("twiga.pipeline.flows.load_data") as mock_load,
        patch("twiga.pipeline.flows.run_drift_check") as mock_drift,
        patch("twiga.pipeline.flows.evaluate_model") as mock_eval,
        patch("twiga.pipeline.flows.decide_retrain") as mock_decide,
        patch("twiga.pipeline.flows.TwigaTracker"),
        patch("twiga.pipeline.flows.fit_forecaster") as mock_fit,
        patch("twiga.pipeline.flows.save_checkpoint") as mock_save,
        patch("twiga.pipeline.flows.log_to_mlflow"),
        patch("twiga.pipeline.flows.requests.post") as mock_post,
    ):
        mock_load.side_effect = [
            (pd.DataFrame(), pd.DataFrame()),
            (pd.DataFrame(), pd.DataFrame()),
        ]
        mock_drift.return_value = {"dataset_drift_score": 0.2, "n_drifted": 1}
        incumbent_metrics = pd.DataFrame({"mae": [0.5]})
        mock_eval.return_value = (None, incumbent_metrics)
        mock_decide.return_value = False

        forecaster = Mock()
        forecaster.on_load_checkpoint = Mock()

        result = retraining_flow(
            forecaster=forecaster,
            reference_data_path=tmp_path / "ref.parquet",
            current_data_path=tmp_path / "cur.parquet",
            drift_threshold=0.5,
            performance_threshold=0.8,
        )

        assert result.retrained is False
        assert result.promoted is False
        assert result.checkpoint_path is None
        mock_fit.assert_not_called()
        mock_save.assert_not_called()
        mock_post.assert_not_called()


def test_retraining_flow_triggers_retrain_and_promotes_when_better(tmp_path):
    from twiga.pipeline.flows import retraining_flow

    with (
        patch("twiga.pipeline.flows.load_data") as mock_load,
        patch("twiga.pipeline.flows.run_drift_check") as mock_drift,
        patch("twiga.pipeline.flows.evaluate_model") as mock_eval,
        patch("twiga.pipeline.flows.decide_retrain") as mock_decide,
        patch("twiga.pipeline.flows.TwigaTracker") as mock_tracker,
        patch("twiga.pipeline.flows.fit_forecaster") as mock_fit,
        patch("twiga.pipeline.flows.save_checkpoint") as mock_save,
        patch("twiga.pipeline.flows.log_to_mlflow") as mock_log,
        patch("twiga.pipeline.flows.requests.post") as mock_post,
    ):
        mock_load.side_effect = [
            (pd.DataFrame(), pd.DataFrame()),
            (pd.DataFrame(), pd.DataFrame()),
        ]
        mock_drift.return_value = {"dataset_drift_score": 0.7, "n_drifted": 4}
        incumbent_metrics = pd.DataFrame({"mae": [0.8]})
        new_metrics = pd.DataFrame({"mae": [0.6]})
        mock_eval.side_effect = [
            (None, incumbent_metrics),
            (pd.DataFrame(), new_metrics),
        ]
        mock_decide.return_value = True
        new_fc = Mock()
        mock_fit.return_value = new_fc
        mock_save.return_value = "/new/checkpoint"
        mock_log.return_value = "run-456"
        mock_tracker_instance = MagicMock()
        mock_tracker_instance.__enter__ = Mock(return_value=mock_tracker_instance)
        mock_tracker_instance.__exit__ = Mock(return_value=False)
        # run_id is a property on TwigaTracker; mock it as a plain attribute.
        mock_tracker_instance.run_id = "run-456"
        mock_tracker.return_value = mock_tracker_instance

        forecaster = Mock()
        forecaster.on_load_checkpoint = Mock()

        result = retraining_flow(
            forecaster=forecaster,
            reference_data_path=tmp_path / "ref.parquet",
            current_data_path=tmp_path / "cur.parquet",
            drift_threshold=0.5,
            performance_threshold=None,
            metric_key="mae",
            minimize=True,
            fastapi_reload_url="http://api:8000",
            fastapi_reload_api_key_secret=None,
        )

        assert result.retrained is True
        assert result.promoted is True
        assert result.checkpoint_path == "/new/checkpoint"
        assert result.mlflow_run_id == "run-456"
        mock_fit.assert_called_once()
        mock_save.assert_called_once_with(forecaster=new_fc)
        mock_post.assert_called_once_with("http://api:8000/reload", headers={}, timeout=5)


def test_retraining_flow_does_not_promote_when_new_model_worse(tmp_path):
    from twiga.pipeline.flows import retraining_flow

    with (
        patch("twiga.pipeline.flows.load_data") as mock_load,
        patch("twiga.pipeline.flows.run_drift_check") as mock_drift,
        patch("twiga.pipeline.flows.evaluate_model") as mock_eval,
        patch("twiga.pipeline.flows.decide_retrain") as mock_decide,
        patch("twiga.pipeline.flows.TwigaTracker") as mock_tracker,
        patch("twiga.pipeline.flows.fit_forecaster") as mock_fit,
        patch("twiga.pipeline.flows.save_checkpoint") as mock_save,
        patch("twiga.pipeline.flows.log_to_mlflow") as mock_log,
    ):
        mock_load.side_effect = [
            (pd.DataFrame(), pd.DataFrame()),
            (pd.DataFrame(), pd.DataFrame()),
        ]
        mock_drift.return_value = {"dataset_drift_score": 0.7}
        incumbent_metrics = pd.DataFrame({"mae": [0.5]})
        new_metrics = pd.DataFrame({"mae": [0.7]})
        mock_eval.side_effect = [
            (None, incumbent_metrics),
            (pd.DataFrame(), new_metrics),
        ]
        mock_decide.return_value = True
        new_fc = Mock()
        mock_fit.return_value = new_fc
        mock_save.return_value = "/new/checkpoint"
        mock_log.return_value = "run-456"
        mock_tracker_instance = MagicMock()
        mock_tracker_instance.__enter__ = Mock(return_value=mock_tracker_instance)
        mock_tracker_instance.__exit__ = Mock(return_value=False)
        mock_tracker_instance.run_id = "run-456"
        mock_tracker.return_value = mock_tracker_instance

        forecaster = Mock()
        forecaster.on_load_checkpoint = Mock()

        result = retraining_flow(
            forecaster=forecaster,
            reference_data_path=tmp_path / "ref.parquet",
            current_data_path=tmp_path / "cur.parquet",
            drift_threshold=0.5,
            metric_key="mae",
            minimize=True,
        )

        assert result.retrained is True
        assert result.promoted is False
        assert result.checkpoint_path is None
        assert result.mlflow_run_id is None
        mock_save.assert_not_called()
        mock_log.assert_not_called()


def test_retraining_flow_handles_incumbent_evaluation_failure(tmp_path):
    from twiga.pipeline.flows import retraining_flow

    with (
        patch("twiga.pipeline.flows.load_data") as mock_load,
        patch("twiga.pipeline.flows.run_drift_check") as mock_drift,
        patch("twiga.pipeline.flows.evaluate_model") as mock_eval,
        patch("twiga.pipeline.flows.decide_retrain"),
        patch("twiga.pipeline.flows.TwigaTracker") as mock_tracker,
        patch("twiga.pipeline.flows.fit_forecaster") as mock_fit,
        patch("twiga.pipeline.flows.save_checkpoint") as mock_save,
        patch("twiga.pipeline.flows.log_to_mlflow"),
    ):
        mock_load.side_effect = [
            (pd.DataFrame(), pd.DataFrame()),
            (pd.DataFrame(), pd.DataFrame()),
        ]
        mock_drift.return_value = {"dataset_drift_score": 0.3}
        mock_eval.return_value = (pd.DataFrame(), pd.DataFrame({"mae": [0.1]}))
        mock_fit.return_value = Mock()
        mock_save.return_value = "/new/checkpoint"
        mock_tracker_instance = MagicMock()
        mock_tracker_instance.__enter__ = Mock(return_value=mock_tracker_instance)
        mock_tracker_instance.__exit__ = Mock(return_value=False)
        mock_tracker.return_value = mock_tracker_instance

        forecaster = Mock()
        forecaster.on_load_checkpoint = Mock(side_effect=Exception("No checkpoint"))

        result = retraining_flow(
            forecaster=forecaster,
            reference_data_path=tmp_path / "ref.parquet",
            current_data_path=tmp_path / "cur.parquet",
            drift_threshold=0.5,
        )

        assert result.retrained is True
        assert result.promoted is True
        assert result.checkpoint_path == "/new/checkpoint"
