from datetime import datetime

import pandas as pd
import pytest

from twiga.core.backtester import TimeBasedCV


# Fixture for sample data
@pytest.fixture
def sample_data():
    """Fixture providing sample time series data for testing.

    Returns:
        pd.DataFrame: A DataFrame with a 'timestamp' column containing daily dates
            from 2020-01-01 to 2020-01-10 and a 'value' column with incremental integers.
    """
    dates = pd.date_range(start="2020-01-01", end="2020-01-10", freq="D")
    return pd.DataFrame({"timestamp": dates, "value": range(len(dates))})


# --- Initialization Tests ---
def test_timebasedcv_init_valid_train_size():
    """Test initialization of TimeBasedCV with valid train_size.

    This test verifies that the TimeBasedCV class correctly sets its attributes
    when initialized with a valid train_size parameter.

    It checks:
    - The split_freq is set to 'days'.
    - The train_size is set to 5.
    - The test_size is set to 2.
    - The gap defaults to 0.
    - The stride defaults to the test_size (2).
    - The window defaults to 'rolling'.
    """
    splitter = TimeBasedCV(split_freq="days", test_size=2, train_size=5)
    assert splitter.split_freq == "days"
    assert splitter.train_size == 5
    assert splitter.test_size == 2
    assert splitter.gap == 0
    assert splitter.stride == 2  # Defaults to test_size
    assert splitter.window == "rolling"


def test_timebasedcv_init_invalid_frequency():
    """Test initialization with invalid split_freq.

    This test ensures that a ValueError is raised when an invalid split_freq
    is passed to the TimeBasedCV constructor.

    Raises:
        ValueError: With a message indicating that the split_freq must be one of
            the supported values.
    """
    with pytest.raises(ValueError, match="split_freq must be one of"):
        TimeBasedCV(split_freq="invalid", test_size=2, train_size=5)


def test_timebasedcv_init_invalid_window():
    """Test initialization with invalid window type.

    This test checks that a ValueError is raised when an invalid window type
    is provided to the TimeBasedCV constructor.

    Raises:
        ValueError: With a message specifying that the window must be either
            'rolling' or 'expanding'.
    """
    with pytest.raises(ValueError, match=r"window must be either 'rolling' or 'expanding'\."):
        TimeBasedCV(split_freq="days", test_size=2, train_size=5, window="invalid")


def test_timebasedcv_init_negative_params():
    """Test initialization with negative parameters.

    This test verifies that a ValueError is raised when negative values are
    provided for parameters that must be positive integers, such as test_size.

    Raises:
        ValueError: With a message indicating that test_size must be a
            positive integer.
    """
    with pytest.raises(ValueError, match="test_size must be a positive integer"):
        TimeBasedCV(split_freq="days", test_size=-1, train_size=5)


def test_timebasedcv_init_negative_gap():
    """Test initialization with negative gap.

    This test ensures that a ValueError is raised when a negative value is
    provided for the gap parameter.

    Raises:
        ValueError: With a message stating that the gap must be a non-negative integer.
    """
    with pytest.raises(ValueError, match="gap must be a non-negative integer"):
        TimeBasedCV(split_freq="days", test_size=2, train_size=5, gap=-1)


def test_timebasedcv_init_no_train_size_or_num_splits():
    """Test initialization without train_size or num_splits.

    This test checks that a ValueError is raised when neither train_size nor
    num_splits is provided to the TimeBasedCV constructor.

    Raises:
        ValueError: With a message indicating that at least one of train_size or
            num_splits must be specified.
    """
    with pytest.raises(ValueError, match=r"Either train_size or num_splits must be provided, not both None\."):
        TimeBasedCV(split_freq="days", test_size=2)


# --- Split Generation Tests ---
def test_splits_from_period_rolling():
    """Test split generation with rolling window.

    This test verifies that the _splits_from_period method correctly generates
    splits for a rolling window setup.

    It checks:
    - The number of splits generated (5 splits over 10 days with stride=1).
    - The start and end times of the training and forecasting periods for the
      first split.
    """
    splitter = TimeBasedCV(
        split_freq="days", train_size=3, test_size=2, stride=1, window="rolling", date_column="timestamp"
    )
    splits = list(splitter._splits_from_period(datetime(2020, 1, 1), datetime(2020, 1, 10)))
    assert len(splits) == 5  # 5 possible splits with stride=1 over 10 days
    first_split = splits[0]
    assert first_split.train_start == datetime(2020, 1, 1)
    assert first_split.train_end == datetime(2020, 1, 4)
    assert first_split.forecast_start == datetime(2020, 1, 4)
    assert first_split.forecast_end == datetime(2020, 1, 6)


def test_splits_from_period_expanding():
    """Test split generation with expanding window.

    This test ensures that the _splits_from_period method generates the correct
    splits for an expanding window configuration.

    It verifies:
    - The number of splits (5 splits over 10 days with stride=1).
    - The training and forecasting periods for the first split.
    """
    splitter = TimeBasedCV(
        split_freq="days", train_size=3, test_size=2, stride=1, window="expanding", date_column="timestamp"
    )
    splits = list(splitter._splits_from_period(datetime(2020, 1, 1), datetime(2020, 1, 10)))
    assert len(splits) == 5
    first_split = splits[0]
    assert first_split.train_start == datetime(2020, 1, 1)
    assert first_split.train_end == datetime(2020, 1, 4)


def test_set_split_scheme_with_train_size(sample_data):
    """Test setting split scheme with train_size.

    This test checks that the split scheme is correctly set when train_size is
    provided.

    It verifies:
    - The number of splits generated based on the sample data (2 splits).
    """
    splitter = TimeBasedCV(split_freq="days", test_size=2, train_size=5)
    splitter.set_split_scheme(sample_data["timestamp"])
    assert len(splitter._split_scheme) == 2


def test_set_split_scheme_with_num_splits(sample_data):
    """Test setting split scheme with num_splits.

    This test ensures that the split scheme is correctly set when num_splits is
    provided.

    It checks:
    - The number of splits generated (2 splits).
    - The calculated train_size (5).
    """
    splitter = TimeBasedCV(split_freq="days", test_size=2, num_splits=2)
    splitter.set_split_scheme(sample_data["timestamp"])
    assert len(splitter._split_scheme) == 2
    assert splitter.train_size == 5


def test_set_split_scheme_invalid_time_values():
    """Test setting split scheme with invalid time values.

    This test verifies that a ValueError is raised when the time_values series
    is not of datetime type.

    Raises:
        ValueError: With a message indicating that time_values must be a datetime series.
    """
    with pytest.raises(ValueError, match=r"time_values must be a datetime series\."):
        splitter = TimeBasedCV(split_freq="days", test_size=2, train_size=5)
        splitter.set_split_scheme(pd.Series([1, 2, 3]))


def test_split_method(sample_data):
    """Test the split method with valid data.

    This test ensures that the split method generates the correct number of
    splits and that each split contains the expected data.

    It checks:
    - The number of splits produced (2 splits).
    """
    splitter = TimeBasedCV(split_freq="days", train_size=5, test_size=2, date_column="timestamp")
    splits = list(splitter.split(sample_data))
    assert len(splits) == 2


def test_split_method_missing_time_col():
    """Test split method with missing time column.

    This test verifies that a ValueError is raised when the specified time
    column is not present in the data.

    Raises:
        ValueError: With a message indicating that the time column is missing.
    """
    splitter = TimeBasedCV(split_freq="days", test_size=2, train_size=5)
    bad_data = pd.DataFrame({"value": range(10)})
    with pytest.raises(ValueError, match="Missing time column"):
        list(splitter.split(bad_data))


def test_plot_split_scheme_runs(sample_data):
    """Test that plot_split_scheme runs without errors.

    This test ensures that the plot_split_scheme method executes successfully
    and returns a plot object.

    It checks:
    - The plot object is not None.
    """
    splitter = TimeBasedCV(split_freq="days", test_size=2, train_size=5)
    splitter.set_split_scheme(sample_data["timestamp"])
    plot = splitter.plot_split_scheme(data=sample_data)
    assert plot is not None


def test_plot_split_scheme_invalid_train_ratio():
    """Test plot_split_scheme with invalid train_ratio.

    This test checks that a ValueError is raised when train_ratio is outside
    the valid range of 0 to 1.

    Raises:
        ValueError: With a message indicating that train_ratio must be between 0 and 1.
    """
    splitter = TimeBasedCV(split_freq="days", test_size=2, train_size=5)
    with pytest.raises(ValueError, match="train_ratio must be between 0 and 1"):
        splitter.plot_split_scheme(train_ratio=1.5)


# --- Edge Case Tests ---
def test_minimal_data():
    """Test split generation with minimal data.

    This test verifies that the splitter can handle a small dataset and
    generates the expected number of splits.

    It checks:
    - The number of splits (1 split possible with 3 days).
    """
    dates = pd.date_range(start="2020-01-01", end="2020-01-03", freq="D")
    data = pd.DataFrame({"timestamp": dates, "value": range(len(dates))})
    splitter = TimeBasedCV(split_freq="days", test_size=1, train_size=1)
    splitter.set_split_scheme(data["timestamp"])
    splits = list(splitter.split(data))
    assert len(splits) == 1


def test_irregular_time_series():
    """Test split generation with irregular time series.

    This test ensures that the splitter can handle non-uniformly spaced
    timestamps and generates splits accordingly.

    It checks:
    - At least one split is generated.
    """
    irregular_dates = pd.to_datetime(["2020-01-01", "2020-01-03", "2020-01-06"])
    data = pd.DataFrame({"timestamp": irregular_dates, "value": [1, 2, 3]})
    splitter = TimeBasedCV(split_freq="days", train_size=2, test_size=1, date_column="timestamp")
    splitter.set_split_scheme(data["timestamp"])
    splits = list(splitter.split(data))
    assert len(splits) > 0


# Mock model class to simulate training and evaluation
class MockModel:
    def __init__(self, fail_on_fold=None):
        """Initialize the mock model.

        Args:
            fail_on_fold (int, optional): Fold number (1-based) on which to raise an error during _fit.
        """
        self.fail_on_fold = fail_on_fold
        self.fold_count = 0

    def fit_backtester(self, train_df):
        """Simulate model training, raising an error on a specified fold if set."""
        self.fold_count += 1
        if self.fail_on_fold == self.fold_count:
            raise ValueError("Simulated training error")

    def evaluate(self, test_df):
        """Simulate model evaluation, returning mock predictions and metrics."""
        pred = pd.DataFrame({"pred": [1] * len(test_df)}, index=test_df.index)
        metric = pd.DataFrame({"MAE": [0.1]}, index=[0])
        return pred, metric
