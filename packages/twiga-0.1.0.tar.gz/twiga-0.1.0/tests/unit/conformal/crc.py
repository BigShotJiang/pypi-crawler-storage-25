import numpy as np
import pytest

from twiga.distributions.conformal.crc import ConformalResidualFitting


def test_conformal_residual_fitting():
    rng = np.random.RandomState(0)
    preds = rng.normal(0, 1, 100)
    sigma = np.abs(rng.normal(1, 0.1, 100))
    targets = preds + rng.normal(0, 0.5, 100)

    model = ConformalResidualFitting(score_type="res", alpha=0.1)
    model.calibrate(preds, sigma, targets)
    lower, upper = model.generate_intervals(preds, sigma)
    assert lower.shape == upper.shape == targets.shape
    assert np.all(upper >= lower)


def test_invalid_score_type():
    with pytest.raises(ValueError):
        ConformalResidualFitting(score_type="oops")
