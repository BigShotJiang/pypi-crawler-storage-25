"""Tests for twiga.distributions.conformal.core.Conformal factory."""

from __future__ import annotations

import pytest

from twiga.distributions.conformal.base import SplitConformal
from twiga.distributions.conformal.core import Conformal
from twiga.distributions.conformal.cqr import ConformalQuantileRegressor
from twiga.distributions.conformal.crc import ConformalResidualFitting


class TestConformalFactory:
    """Tests for the Conformal factory class."""

    def test_residual_returns_split_conformal(self) -> None:
        """method='residual' returns a SplitConformal instance."""
        model = Conformal(method="residual", score_type="res", alpha=0.1)
        assert isinstance(model, SplitConformal)

    def test_quantile_returns_conformal_quantile_regressor(self) -> None:
        """method='quantile' returns a ConformalQuantileRegressor instance."""
        model = Conformal(method="quantile", score_type="scaled", alpha=0.1)
        assert isinstance(model, ConformalQuantileRegressor)

    def test_residual_fitting_returns_conformal_residual_fitting(self) -> None:
        """method='residual-fitting' returns a ConformalResidualFitting instance."""
        model = Conformal(method="residual-fitting", score_type="res", alpha=0.1)
        assert isinstance(model, ConformalResidualFitting)

    def test_invalid_method_raises(self) -> None:
        """Invalid method raises ValueError."""
        with pytest.raises(ValueError, match="Invalid method"):
            Conformal(method="unknown")

    def test_alpha_is_forwarded(self) -> None:
        """Alpha kwarg is passed through to the created instance."""
        model = Conformal(method="residual", alpha=0.05)
        assert model.alpha == pytest.approx(0.05)
