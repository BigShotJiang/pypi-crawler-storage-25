"""Tests for twiga.distributions.conformal.cqr.ConformalQuantileRegressor.

Covers:
- Constructor: valid/invalid score_type, alpha range
- get_scores: scaled and unscaled branches
- _calculate_unscaled_cqr_score: residual scores
- _calculate_scaled_cqr_score: scaled scores
- generate_intervals: scaled and unscaled variants
"""

from __future__ import annotations

import numpy as np
import pytest

from twiga.distributions.conformal.cqr import ConformalQuantileRegressor

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def rng() -> np.random.Generator:
    """Return a seeded RNG."""
    return np.random.default_rng(0)


@pytest.fixture
def calib_data(rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return (lower, upper, targets) arrays of shape (100,)."""
    lower = rng.uniform(0, 2, 100)
    upper = lower + rng.uniform(0.5, 1.5, 100)
    targets = lower + rng.uniform(0, 1.0, 100)
    return lower, upper, targets


# ---------------------------------------------------------------------------
# Constructor
# ---------------------------------------------------------------------------


class TestConformalQuantileRegressorInit:
    """Tests for ConformalQuantileRegressor.__init__."""

    def test_valid_scaled(self) -> None:
        """score_type='scaled' initialises without error."""
        model = ConformalQuantileRegressor(score_type="scaled", alpha=0.1)
        assert model.score_type == "scaled"
        assert model.alpha == 0.1

    def test_valid_unscaled(self) -> None:
        """score_type='unscaled' initialises without error."""
        model = ConformalQuantileRegressor(score_type="unscaled", alpha=0.2)
        assert model.score_type == "unscaled"

    def test_invalid_score_type_raises(self) -> None:
        """Invalid score_type raises ValueError."""
        with pytest.raises(ValueError, match="Invalid score_type"):
            ConformalQuantileRegressor(score_type="invalid")

    def test_alpha_zero_raises(self) -> None:
        """alpha=0 raises ValueError."""
        with pytest.raises(ValueError):
            ConformalQuantileRegressor(alpha=0.0)

    def test_alpha_one_raises(self) -> None:
        """alpha=1 raises ValueError."""
        with pytest.raises(ValueError):
            ConformalQuantileRegressor(alpha=1.0)


# ---------------------------------------------------------------------------
# get_scores
# ---------------------------------------------------------------------------


class TestGetScores:
    """Tests for ConformalQuantileRegressor.get_scores."""

    def test_unscaled_scores_shape(self, calib_data: tuple) -> None:
        """Unscaled scores have same shape as targets."""
        lower, upper, targets = calib_data
        model = ConformalQuantileRegressor(score_type="unscaled", alpha=0.1)
        scores = model.get_scores(lower, upper, targets)
        assert scores.shape == targets.shape

    def test_scaled_scores_shape(self, calib_data: tuple) -> None:
        """Scaled scores have same shape as targets."""
        lower, upper, targets = calib_data
        model = ConformalQuantileRegressor(score_type="scaled", alpha=0.1)
        scores = model.get_scores(lower, upper, targets)
        assert scores.shape == targets.shape

    def test_unscaled_score_formula(self) -> None:
        """Unscaled score = max(lower - targets, targets - upper)."""
        lower = np.array([0.0, 2.0])
        upper = np.array([1.0, 3.0])
        targets = np.array([0.5, 4.0])  # second target is above upper
        model = ConformalQuantileRegressor(score_type="unscaled", alpha=0.1)
        scores = model.get_scores(lower, upper, targets)
        expected = np.maximum(lower - targets, targets - upper)
        np.testing.assert_array_equal(scores, expected)

    def test_scaled_score_uses_interval_width(self) -> None:
        """Scaled score normalises by (upper - lower + eps)."""
        lower = np.array([0.0])
        upper = np.array([2.0])
        targets = np.array([0.0])  # at lower → lower - targets = 0, targets - upper = -2
        model = ConformalQuantileRegressor(score_type="scaled", alpha=0.1)
        scores = model.get_scores(lower, upper, targets)
        eps = ConformalQuantileRegressor._EPS
        scale = upper - lower + eps
        expected = np.maximum((lower - targets) / scale, (targets - upper) / scale)
        np.testing.assert_allclose(scores, expected)

    def test_get_scores_shape_mismatch_raises(self) -> None:
        """Shape mismatch between lower and targets raises ValueError."""
        model = ConformalQuantileRegressor(score_type="unscaled", alpha=0.1)
        with pytest.raises(ValueError, match="Shape mismatch"):
            model.get_scores(np.ones((3, 2)), np.ones((3, 2)), np.ones((4, 2)))


# ---------------------------------------------------------------------------
# generate_intervals
# ---------------------------------------------------------------------------


class TestGenerateIntervals:
    """Tests for ConformalQuantileRegressor.generate_intervals."""

    def test_unscaled_intervals_shape(self, calib_data: tuple) -> None:
        """Unscaled intervals have same shape as input quantiles."""
        lower, upper, targets = calib_data
        model = ConformalQuantileRegressor(score_type="unscaled", alpha=0.1)
        model.calibrate(lower, upper, targets)
        lo, hi = model.generate_intervals(lower, upper)
        assert lo.shape == lower.shape
        assert hi.shape == upper.shape

    def test_scaled_intervals_shape(self, calib_data: tuple) -> None:
        """Scaled intervals have same shape as input quantiles."""
        lower, upper, targets = calib_data
        model = ConformalQuantileRegressor(score_type="scaled", alpha=0.1)
        model.calibrate(lower, upper, targets)
        lo, hi = model.generate_intervals(lower, upper)
        assert lo.shape == lower.shape
        assert hi.shape == upper.shape

    def test_unscaled_intervals_upper_gte_lower(self, calib_data: tuple) -> None:
        """Upper interval bound >= lower interval bound for unscaled."""
        lower, upper, targets = calib_data
        model = ConformalQuantileRegressor(score_type="unscaled", alpha=0.1)
        model.calibrate(lower, upper, targets)
        lo, hi = model.generate_intervals(lower, upper)
        assert np.all(hi >= lo)

    def test_scaled_intervals_upper_gte_lower(self, calib_data: tuple) -> None:
        """Upper interval bound >= lower interval bound for scaled."""
        lower, upper, targets = calib_data
        model = ConformalQuantileRegressor(score_type="scaled", alpha=0.1)
        model.calibrate(lower, upper, targets)
        lo, hi = model.generate_intervals(lower, upper)
        assert np.all(hi >= lo)

    def test_unscaled_intervals_formula(self) -> None:
        """Unscaled intervals: lower_out = lower - q_hat, upper_out = upper + q_hat."""
        lower = np.array([1.0, 2.0])
        upper = lower + 1.0
        targets = lower + 0.5
        model = ConformalQuantileRegressor(score_type="unscaled", alpha=0.1)
        model.calibrate(lower, upper, targets)
        lo, hi = model.generate_intervals(lower, upper)
        np.testing.assert_allclose(lo, lower - model.q_hat, atol=1e-10)
        np.testing.assert_allclose(hi, upper + model.q_hat, atol=1e-10)
