import numpy as np
import pytest

from twiga.distributions.conformal.cqr import ConformalQuantileRegressor


def test_conformal_quantile_unscaled():
    rng = np.random.RandomState(0)
    lower = rng.uniform(0, 2, 100)
    upper = lower + 1.0
    targets = lower + rng.uniform(0, 1.0, 100)

    model = ConformalQuantileRegressor(score_type="unscaled", alpha=0.1)
    model.calibrate(lower, upper, targets)
    low_i, up_i = model.generate_intervals(lower, upper)
    assert low_i.shape == up_i.shape == targets.shape
    assert np.all(up_i >= low_i)


def test_conformal_quantile_scaled():
    rng = np.random.RandomState(0)
    lower = rng.uniform(0, 2, 100)
    upper = lower + 1.0
    targets = lower + rng.uniform(0, 1.0, 100)

    model = ConformalQuantileRegressor(score_type="scaled", alpha=0.1)
    model.calibrate(lower, upper, targets)
    low_i, up_i = model.generate_intervals(lower, upper)
    assert low_i.shape == up_i.shape == targets.shape
    assert np.all(up_i >= low_i)


def test_invalid_score_type():
    with pytest.raises(ValueError):
        ConformalQuantileRegressor(score_type="invalid")
