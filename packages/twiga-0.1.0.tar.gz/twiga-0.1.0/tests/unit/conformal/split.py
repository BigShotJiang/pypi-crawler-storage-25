import numpy as np
import pytest

from twiga.distributions.conformal.base import SplitConformal


@pytest.fixture
def regression_data():
    rng = np.random.RandomState(42)
    preds = rng.normal(0, 1, 100)
    targets = preds + rng.normal(0, 0.5, 100)
    return preds, targets


def test_split_conformal_residual(regression_data):
    preds, targets = regression_data
    model = SplitConformal(score_type="res", alpha=0.1)
    model.calibrate(preds, targets)
    lower, upper = model.generate_intervals(preds)
    assert lower.shape == upper.shape == preds.shape
    assert np.all(upper >= lower)


def test_split_conformal_signed_residual(regression_data):
    preds, targets = regression_data
    model = SplitConformal(score_type="sign-res", alpha=0.1)
    model.calibrate(preds, targets)
    lower, upper = model.generate_intervals(preds)
    assert lower.shape == upper.shape == preds.shape
    assert np.all(upper >= lower)


class TestSplitConformal:
    """Test suite for the SplitConformal class."""

    def test_init_invalid_alpha(self):
        """Test initialization with invalid alpha values."""
        with pytest.raises(ValueError):
            SplitConformal(alpha=0.0)
        with pytest.raises(ValueError):
            SplitConformal(alpha=1.0)
        with pytest.raises(ValueError):
            SplitConformal(alpha=1.1)
        with pytest.raises(ValueError):
            SplitConformal(alpha=-0.1)

    def test_init_valid_alpha(self):
        """Test initialization with valid alpha values."""
        SplitConformal(alpha=0.1)
        SplitConformal(alpha=0.5)
        SplitConformal(alpha=0.9)

    def test_init_invalid_score_type(self):
        """Test initialization with an invalid score_type."""
        with pytest.raises(ValueError):
            SplitConformal(score_type="invalid")

    def test_init_valid_score_type(self):
        """Test initialization with valid score_type values."""
        SplitConformal(score_type="res")
        SplitConformal(score_type="sign-res")

    def test_get_scores_residuals(self):
        """Test get_scores with 'res' score_type returns absolute residuals."""
        sc = SplitConformal(score_type="res")
        predicts = np.array([1, 2, 3])
        targets = np.array([2, 1, 4])
        scores = sc.get_scores(predicts, targets)
        expected = np.abs(targets - predicts)
        np.testing.assert_array_equal(scores, expected)

    def test_get_scores_signed_residuals(self):
        """Test get_scores with 'sign-res' score_type returns signed residuals."""
        sc = SplitConformal(score_type="sign-res")
        predicts = np.array([1, 2, 3])
        targets = np.array([2, 1, 4])
        scores = sc.get_scores(predicts, targets)
        expected = targets - predicts
        np.testing.assert_array_equal(scores, expected)

    def test_validate_inputs_shape_mismatch(self):
        """Test validation raises error on shape mismatch between predictions and targets."""
        sc = SplitConformal()
        predicts = np.array([1, 2])
        targets = np.array([1])
        with pytest.raises(ValueError):
            sc.get_scores(predicts, targets)

    def test_generate_intervals(self):
        """Test generate_intervals correctly computes intervals using q_hat."""
        sc = SplitConformal()
        sc.q_hat = 2.0
        mu_pred = np.array([10, 20, 30])
        lower, upper = sc.generate_intervals(mu_pred)
        np.testing.assert_array_equal(lower, mu_pred - 2.0)
        np.testing.assert_array_equal(upper, mu_pred + 2.0)

    def test_calculate_conformal_quantile_valid(self):
        """Test conformal quantile calculation with valid inputs."""
        sc = SplitConformal(alpha=0.1)
        scores = np.arange(10)  # Scores [0, 1, ..., 9]
        q_hat = sc._calculate_conformal_quantile(scores)
        assert q_hat == 9.0  # Max score as quantile_level=1 (0.99 -> ceil=1)

    def test_calculate_conformal_quantile_empty_scores(self):
        """Test quantile calculation raises error with empty scores array."""
        sc = SplitConformal()
        with pytest.raises(ValueError):
            sc._calculate_conformal_quantile(np.array([]))

    def test_calculate_conformal_quantile_quantile_over_one(self):
        """Test quantile calculation raises error when quantile_level exceeds 1."""
        sc = SplitConformal(alpha=0.05)
        scores = np.array([1, 2, 3, 4, 5])
        with pytest.raises(ValueError) as exc_info:
            sc._calculate_conformal_quantile(scores)
        assert "Quantile level exceeds 1" in str(exc_info.value)

    def test_calibrate_sets_q_hat(self):
        """Test calibration sets q_hat correctly with valid inputs."""
        sc = SplitConformal(alpha=0.2)
        predicts = np.ones(10)
        targets = np.ones(10)
        sc.calibrate(predicts, targets)
        assert sc.q_hat == 0.0  # All residuals are zero

    def test_calibrate_raises_error_for_small_n(self):
        """Test calibration raises error when quantile_level exceeds 1 due to small n."""
        sc = SplitConformal(alpha=0.1)
        predicts = np.array([1, 2, 3])  # n=3
        targets = np.array([2, 1, 4])
        with pytest.raises(ValueError):
            sc.calibrate(predicts, targets)


@pytest.mark.parametrize("alpha", [-0.1, 0, 1, 1.5])
def test_invalid_alpha(alpha):
    with pytest.raises(ValueError):
        SplitConformal(alpha=alpha)
