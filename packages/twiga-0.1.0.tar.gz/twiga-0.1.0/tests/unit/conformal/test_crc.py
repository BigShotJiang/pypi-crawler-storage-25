"""Tests for twiga.distributions.conformal.crc.ConformalResidualFitting.

Covers:
- Constructor: valid/invalid score_type, alpha validation
- _validate_scale: invalid sigma (zeros, negatives, NaN), shape mismatch
- get_scores: 'res' and 'sign-res' branches
- _calculate_signed_residuals / _calculate_absolute_residuals
- generate_intervals
"""

from __future__ import annotations

import numpy as np
import pytest

from twiga.distributions.conformal.crc import ConformalResidualFitting

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def rng() -> np.random.Generator:
    """Return a seeded RNG."""
    return np.random.default_rng(42)


@pytest.fixture
def calib_data(rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return (preds, sigma, targets) arrays of shape (50, 2)."""
    preds = rng.standard_normal((50, 2))
    sigma = np.abs(rng.standard_normal((50, 2))) + 0.1
    targets = preds + rng.standard_normal((50, 2)) * 0.2
    return preds, sigma, targets


# ---------------------------------------------------------------------------
# Constructor
# ---------------------------------------------------------------------------


class TestConformalResidualFittingInit:
    """Tests for ConformalResidualFitting.__init__."""

    def test_valid_res(self) -> None:
        """score_type='res' initialises without error."""
        model = ConformalResidualFitting(score_type="res", alpha=0.1)
        assert model.score_type == "res"
        assert model.alpha == 0.1

    def test_valid_sign_res(self) -> None:
        """score_type='sign-res' initialises without error."""
        model = ConformalResidualFitting(score_type="sign-res", alpha=0.05)
        assert model.score_type == "sign-res"

    def test_invalid_score_type_raises(self) -> None:
        """Invalid score_type raises ValueError."""
        with pytest.raises(ValueError, match="Invalid score_type"):
            ConformalResidualFitting(score_type="oops")

    def test_alpha_zero_raises(self) -> None:
        """alpha=0 raises ValueError."""
        with pytest.raises(ValueError):
            ConformalResidualFitting(alpha=0.0)

    def test_alpha_one_raises(self) -> None:
        """alpha=1 raises ValueError."""
        with pytest.raises(ValueError):
            ConformalResidualFitting(alpha=1.0)


# ---------------------------------------------------------------------------
# _validate_scale
# ---------------------------------------------------------------------------


class TestValidateScale:
    """Tests for ConformalResidualFitting._validate_scale."""

    def test_zero_sigma_raises(self) -> None:
        """Zero sigma values raise ValueError."""
        model = ConformalResidualFitting(alpha=0.1)
        sigma = np.array([0.0, 1.0])
        targets = np.array([0.5, 0.5])
        with pytest.raises(ValueError, match="Scale factors must be positive"):
            model._validate_scale(sigma, targets)

    def test_negative_sigma_raises(self) -> None:
        """Negative sigma values raise ValueError."""
        model = ConformalResidualFitting(alpha=0.1)
        sigma = np.array([-0.5, 1.0])
        targets = np.array([0.5, 0.5])
        with pytest.raises(ValueError, match="Scale factors must be positive"):
            model._validate_scale(sigma, targets)

    def test_nan_sigma_raises(self) -> None:
        """NaN sigma values raise ValueError."""
        model = ConformalResidualFitting(alpha=0.1)
        sigma = np.array([np.nan, 1.0])
        targets = np.array([0.5, 0.5])
        with pytest.raises(ValueError, match="Scale factors must be positive"):
            model._validate_scale(sigma, targets)

    def test_shape_mismatch_raises(self) -> None:
        """Shape mismatch between sigma and targets raises ValueError."""
        model = ConformalResidualFitting(alpha=0.1)
        sigma = np.array([1.0, 1.0, 1.0])
        targets = np.array([0.5, 0.5])
        with pytest.raises(ValueError, match="Shape mismatch"):
            model._validate_scale(sigma, targets)

    def test_valid_sigma_passes(self) -> None:
        """Positive sigma passes validation without error."""
        model = ConformalResidualFitting(alpha=0.1)
        sigma = np.array([0.5, 1.0, 2.0])
        targets = np.array([1.0, 2.0, 3.0])
        model._validate_scale(sigma, targets)  # should not raise


# ---------------------------------------------------------------------------
# get_scores
# ---------------------------------------------------------------------------


class TestGetScores:
    """Tests for ConformalResidualFitting.get_scores."""

    def test_res_scores_shape(self, calib_data: tuple) -> None:
        """score_type='res' produces scores with same shape as inputs."""
        preds, sigma, targets = calib_data
        model = ConformalResidualFitting(score_type="res", alpha=0.1)
        scores = model.get_scores(preds, sigma, targets)
        assert scores.shape == preds.shape

    def test_sign_res_scores_non_negative(self, calib_data: tuple) -> None:
        """score_type='sign-res' produces non-negative absolute residuals."""
        preds, sigma, targets = calib_data
        model = ConformalResidualFitting(score_type="sign-res", alpha=0.1)
        scores = model.get_scores(preds, sigma, targets)
        assert np.all(scores >= 0)

    def test_res_formula(self) -> None:
        """score_type='res' computes (loc - targets) / sigma (signed)."""
        preds = np.array([1.0, 2.0])
        sigma = np.array([0.5, 1.0])
        targets = np.array([1.5, 1.0])
        model = ConformalResidualFitting(score_type="res", alpha=0.1)
        scores = model.get_scores(preds, sigma, targets)
        expected = (preds - targets) / sigma
        np.testing.assert_allclose(scores, expected)

    def test_sign_res_formula(self) -> None:
        """score_type='sign-res' computes |loc - targets| / sigma (absolute)."""
        preds = np.array([1.0, 2.0])
        sigma = np.array([0.5, 1.0])
        targets = np.array([1.5, 1.0])
        model = ConformalResidualFitting(score_type="sign-res", alpha=0.1)
        scores = model.get_scores(preds, sigma, targets)
        expected = np.abs(preds - targets) / sigma
        np.testing.assert_allclose(scores, expected)

    def test_invalid_sigma_raises(self) -> None:
        """get_scores propagates _validate_scale ValueError for bad sigma."""
        model = ConformalResidualFitting(score_type="res", alpha=0.1)
        with pytest.raises(ValueError):
            model.get_scores(np.ones(3), np.zeros(3), np.ones(3))


# ---------------------------------------------------------------------------
# generate_intervals
# ---------------------------------------------------------------------------


class TestGenerateIntervals:
    """Tests for ConformalResidualFitting.generate_intervals."""

    def test_intervals_shape(self, calib_data: tuple) -> None:
        """generate_intervals returns arrays with same shape as loc."""
        preds, sigma, targets = calib_data
        model = ConformalResidualFitting(score_type="res", alpha=0.1)
        model.calibrate(preds, sigma, targets)
        lower, upper = model.generate_intervals(preds, sigma)
        assert lower.shape == preds.shape
        assert upper.shape == preds.shape

    def test_upper_gte_lower(self, calib_data: tuple) -> None:
        """Upper interval bound is always >= lower bound after calibration."""
        preds, sigma, targets = calib_data
        model = ConformalResidualFitting(score_type="res", alpha=0.1)
        model.calibrate(preds, sigma, targets)
        lower, upper = model.generate_intervals(preds, sigma)
        assert np.all(upper >= lower)

    def test_intervals_formula(self, calib_data: tuple) -> None:
        """Intervals: lower = loc - sigma * q_hat, upper = loc + sigma * q_hat."""
        preds, sigma, targets = calib_data
        model = ConformalResidualFitting(score_type="res", alpha=0.1)
        model.calibrate(preds, sigma, targets)
        lower, upper = model.generate_intervals(preds, sigma)
        expected_lower = preds - sigma * model.q_hat
        expected_upper = preds + sigma * model.q_hat
        np.testing.assert_allclose(lower, expected_lower, atol=1e-10)
        np.testing.assert_allclose(upper, expected_upper, atol=1e-10)

    def test_full_workflow_sign_res(self, calib_data: tuple) -> None:
        """Full calibrate → generate_intervals workflow with sign-res scores."""
        preds, sigma, targets = calib_data
        model = ConformalResidualFitting(score_type="sign-res", alpha=0.1)
        model.calibrate(preds, sigma, targets)
        lower, upper = model.generate_intervals(preds, sigma)
        assert lower.shape == preds.shape
        assert upper.shape == preds.shape
