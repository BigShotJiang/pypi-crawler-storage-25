"""Tests for twiga.distributions.conformal.base.

Covers:
- calculate_conformal_value: normal case, empty scores, exceeds-1 quantile, invalid alpha
- BaseConformal: validation, calibrate, calculate_conformal_quantile
- SplitConformal: residual and signed-residual scores, invalid score_type, generate_intervals
"""

from __future__ import annotations

import warnings

import numpy as np
import pytest

from twiga.distributions.conformal.base import (
    BaseConformal,
    SplitConformal,
    calculate_conformal_value,
)

# ---------------------------------------------------------------------------
# calculate_conformal_value
# ---------------------------------------------------------------------------


class TestCalculateConformalValue:
    """Tests for calculate_conformal_value."""

    def test_returns_correct_quantile(self) -> None:
        """Returns the (1-alpha) quantile of scores."""
        scores = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        # alpha=0.2 → mid_point = ceil(6 * 0.8) = ceil(4.8) = 5 → index 4 → value 5.0
        result = calculate_conformal_value(scores, alpha=0.2)
        assert result == pytest.approx(5.0)

    def test_2d_scores_axis_0(self) -> None:
        """Works along axis 0 for 2-D score arrays."""
        scores = np.array([[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]])
        result = calculate_conformal_value(scores, alpha=0.5, axis=0)
        assert result.shape == (2,)

    def test_empty_scores_returns_inf_with_warning(self) -> None:
        """Empty score array returns inf and emits a UserWarning."""
        empty = np.empty((0, 2))
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            result = calculate_conformal_value(empty, alpha=0.1)
        assert np.all(np.isinf(result))
        assert len(caught) == 1

    def test_exceeds_quantile_returns_inf_with_warning(self) -> None:
        """Too few samples for the requested alpha returns inf and warns."""
        # 1 sample, alpha=0.01 → mid_point = ceil(2 * 0.99) = ceil(1.98) = 2 > N=1
        scores = np.array([[1.0]])  # shape (1, 1)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            result = calculate_conformal_value(scores, alpha=0.01)
        assert np.all(np.isinf(result))
        assert len(caught) == 1

    def test_alpha_zero_raises(self) -> None:
        """alpha=0 raises ValueError."""
        with pytest.raises(ValueError, match="alpha"):
            calculate_conformal_value(np.ones(5), alpha=0.0)

    def test_alpha_one_raises(self) -> None:
        """alpha=1 raises ValueError."""
        with pytest.raises(ValueError, match="alpha"):
            calculate_conformal_value(np.ones(5), alpha=1.0)

    def test_alpha_negative_raises(self) -> None:
        """Negative alpha raises ValueError."""
        with pytest.raises(ValueError, match="alpha"):
            calculate_conformal_value(np.ones(5), alpha=-0.1)

    def test_alpha_above_one_raises(self) -> None:
        """Alpha > 1 raises ValueError."""
        with pytest.raises(ValueError, match="alpha"):
            calculate_conformal_value(np.ones(5), alpha=1.5)


# ---------------------------------------------------------------------------
# BaseConformal (via SplitConformal — concrete subclass)
# ---------------------------------------------------------------------------


class TestBaseConformal:
    """Tests for BaseConformal interface via SplitConformal."""

    def test_invalid_alpha_below_zero_raises(self) -> None:
        """Alpha <= 0 raises ValueError on construction."""
        with pytest.raises(ValueError):
            SplitConformal(alpha=0.0)

    def test_invalid_alpha_above_one_raises(self) -> None:
        """Alpha >= 1 raises ValueError on construction."""
        with pytest.raises(ValueError):
            SplitConformal(alpha=1.0)

    def test_valid_alpha(self) -> None:
        """Valid alpha is stored as attribute."""
        model = SplitConformal(alpha=0.1)
        assert model.alpha == 0.1

    def test_validate_inputs_shape_mismatch_raises(self) -> None:
        """_validate_inputs raises ValueError for shape mismatch."""
        model = SplitConformal(alpha=0.1)
        preds = np.ones((3, 4))
        targets = np.ones((4, 3))
        with pytest.raises(ValueError, match="Shape mismatch"):
            model._validate_inputs(preds, targets)

    def test_calculate_conformal_quantile_empty_raises(self) -> None:
        """calculate_conformal_quantile raises for empty scores."""
        model = SplitConformal(alpha=0.1)
        with pytest.raises(ValueError, match="empty"):
            model.calculate_conformal_quantile(np.empty((0,)))

    def test_calibrate_sets_q_hat(self) -> None:
        """Calibrate computes and stores q_hat."""
        model = SplitConformal(alpha=0.1)
        rng = np.random.default_rng(0)
        preds = rng.standard_normal((50, 1))
        targets = rng.standard_normal((50, 1))
        model.calibrate(preds, targets)
        assert model.q_hat is not None
        assert not np.isinf(model.q_hat).all()


# ---------------------------------------------------------------------------
# SplitConformal
# ---------------------------------------------------------------------------


class TestSplitConformal:
    """Tests for SplitConformal."""

    @pytest.fixture
    def rng(self) -> np.random.Generator:
        """Return a seeded RNG."""
        return np.random.default_rng(7)

    @pytest.fixture
    def data(self, rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray]:
        """Return (predictions, targets) of shape (30, 2)."""
        preds = rng.standard_normal((30, 2))
        targets = preds + rng.standard_normal((30, 2)) * 0.1
        return preds, targets

    def test_invalid_score_type_raises(self) -> None:
        """Invalid score_type raises ValueError."""
        with pytest.raises(ValueError, match="Invalid score_type"):
            SplitConformal(score_type="invalid")

    def test_residual_scores_are_non_negative(self, data: tuple) -> None:
        """score_type='res' produces non-negative absolute residuals."""
        model = SplitConformal(score_type="res", alpha=0.1)
        preds, targets = data
        scores = model.get_scores(preds, targets)
        assert np.all(scores >= 0)

    def test_signed_residual_scores_can_be_negative(self, data: tuple) -> None:
        """score_type='sign-res' produces signed residuals (may be negative)."""
        model = SplitConformal(score_type="sign-res", alpha=0.1)
        preds, targets = data
        scores = model.get_scores(preds, targets)
        assert scores.shape == preds.shape
        # signed residuals: targets - preds (not necessarily non-negative)
        np.testing.assert_array_equal(scores, targets - preds)

    def test_get_scores_shape_mismatch_raises(self) -> None:
        """Shape mismatch between preds and targets raises ValueError."""
        model = SplitConformal(score_type="res", alpha=0.1)
        with pytest.raises(ValueError, match="Shape mismatch"):
            model.get_scores(np.ones((3, 2)), np.ones((4, 2)))

    def test_generate_intervals_shape(self, data: tuple) -> None:
        """generate_intervals returns lower/upper with same shape as mu_pred."""
        model = SplitConformal(score_type="res", alpha=0.1)
        preds, targets = data
        model.calibrate(preds, targets)
        lower, upper = model.generate_intervals(preds)
        assert lower.shape == preds.shape
        assert upper.shape == preds.shape

    def test_generate_intervals_upper_greater_than_lower(self, data: tuple) -> None:
        """Upper bound is always >= lower bound after calibration."""
        model = SplitConformal(score_type="res", alpha=0.1)
        preds, targets = data
        model.calibrate(preds, targets)
        lower, upper = model.generate_intervals(preds)
        assert np.all(upper >= lower)

    def test_generate_intervals_symmetric_around_pred(self, data: tuple) -> None:
        """Intervals are symmetric: upper - pred == pred - lower == q_hat (broadcast)."""
        model = SplitConformal(score_type="res", alpha=0.1)
        preds, targets = data
        model.calibrate(preds, targets)
        lower, upper = model.generate_intervals(preds)
        # q_hat broadcasts over rows; verify each row satisfies the symmetry
        np.testing.assert_allclose(preds - lower, np.broadcast_to(model.q_hat, preds.shape), atol=1e-10)
        np.testing.assert_allclose(upper - preds, np.broadcast_to(model.q_hat, preds.shape), atol=1e-10)

    def test_full_workflow_residual(self, data: tuple, rng: np.random.Generator) -> None:
        """Full calibrate → generate_intervals workflow with residual scores."""
        model = SplitConformal(score_type="res", alpha=0.1)
        preds, targets = data
        model.calibrate(preds, targets)
        test_preds = rng.standard_normal((10, 2))
        lower, upper = model.generate_intervals(test_preds)
        assert lower.shape == (10, 2)
        assert upper.shape == (10, 2)

    def test_full_workflow_signed_residual(self, data: tuple, rng: np.random.Generator) -> None:
        """Full calibrate → generate_intervals workflow with sign-res scores."""
        model = SplitConformal(score_type="sign-res", alpha=0.1)
        preds, targets = data
        model.calibrate(preds, targets)
        test_preds = rng.standard_normal((10, 2))
        lower, upper = model.generate_intervals(test_preds)
        assert lower.shape == (10, 2)
        assert upper.shape == (10, 2)
