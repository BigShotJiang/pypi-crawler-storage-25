import numpy as np
import pytest
from scipy.special import expit  # Used in some metric calculations

from twiga.core.metrics.interval import (
    ace,
    cwe_score,
    gamma_coverage_score,
    gamma_nmpi_score,
    get_interval_metrics,
    interval_coverage,
    nmpi,
    standardized_gamma_nmpi,
    winkler_score,
)

# Sample test data
true_values = np.array([10, 15, 20, 25, 30])
lower_bounds = np.array([8, 14, 18, 22, 28])
upper_bounds = np.array([12, 16, 22, 28, 32])
predicted_values = np.array([9, 14, 19, 24, 29])


# Test for Winkler Score
def test_winkler_score():
    """Test Winkler score calculation with valid inputs."""
    score = winkler_score(predicted_values, true_values, lower_bounds, upper_bounds, alpha=0.05)
    expected_score = np.median(
        upper_bounds
        - lower_bounds
        + (2 / 0.05) * (lower_bounds - true_values) * (true_values < lower_bounds)
        + (2 / 0.05) * (true_values - upper_bounds) * (true_values > upper_bounds)
    )
    assert np.isclose(score, expected_score), f"Expected {expected_score}, got {score}"


def test_winkler_score_alpha_none():
    """Test Winkler score raises ValueError when alpha is None."""
    with pytest.raises(ValueError, match="Alpha cannot be None"):
        winkler_score(predicted_values, true_values, lower_bounds, upper_bounds, alpha=None)


# Test for Interval Coverage
def test_interval_coverage():
    """Test interval coverage calculation."""
    coverage = interval_coverage(true_values, lower_bounds, upper_bounds)
    expected_coverage = np.mean((true_values >= lower_bounds) & (true_values <= upper_bounds))
    assert np.isclose(coverage, expected_coverage), f"Expected {expected_coverage}, got {coverage}"


# Test for ACE (Average Coverage Error)
def test_ace():
    """Test ACE calculation with valid coverage and alpha."""
    coverage = 0.95
    alpha = 0.05
    error = ace(coverage, alpha)
    expected_error = coverage - (1 - alpha)
    assert np.isclose(error, expected_error), f"Expected {expected_error}, got {error}"


# Test for NMPI (Normalized Median Prediction Interval)
def test_nmpi():
    """Test NMPI calculation."""
    width = nmpi(lower_bounds, upper_bounds, scale=1.0)
    expected_width = np.median(np.abs(upper_bounds - lower_bounds))
    assert np.isclose(width, expected_width), f"Expected {expected_width}, got {width}"


# Test for Gamma NMPI Score
def test_gamma_nmpi_score():
    """Test Gamma NMPI score calculation."""
    nmpi_val = 4.0
    true_nmpic_val = 3.5
    k = 1.0
    smoothing = 0.5
    score = gamma_nmpi_score(nmpi_val, true_nmpic_val, k, smoothing)
    nmpic_diff = np.abs(nmpi_val - true_nmpic_val)
    expected_score = 1 - expit(k * (nmpic_diff - smoothing) ** 2)
    assert np.isclose(score, expected_score), f"Expected {expected_score}, got {score}"


# Test for Standardized Gamma NMPI
def test_standardized_gamma_nmpi():
    """Test standardized Gamma NMPI calculation."""
    nmpi_val = 0.1
    true_nmpic_val = 1.0
    k = 1.0
    smoothing = 1e-10
    score = standardized_gamma_nmpi(nmpi_val, true_nmpic_val, k, smoothing)
    base_score = gamma_nmpi_score(nmpi_val, true_nmpic_val, k, smoothing)
    max_score = gamma_nmpi_score(true_nmpic_val, true_nmpic_val, k, smoothing)
    min_score_left = gamma_nmpi_score(0.0, true_nmpic_val, k, smoothing)
    expected_score = (base_score - min_score_left) / (max_score - min_score_left)
    assert np.isclose(score, expected_score), f"Expected {expected_score}, got {score}"


# Test for Gamma Coverage Score
def test_gamma_coverage_score():
    """Test Gamma Coverage Score calculation with valid inputs."""
    picp = 0.95
    alpha = 0.05
    score = gamma_coverage_score(picp, alpha)
    diff = 0.0 if picp > 1 - alpha else (1 - alpha - picp)
    expected_score = (np.exp(-diff) - np.exp(-(1 - alpha))) / (1 - np.exp(-(1 - alpha)))
    assert np.isclose(score, expected_score), f"Expected {expected_score}, got {score}"


def test_gamma_coverage_score_invalid_picp():
    """Test Gamma Coverage Score raises ValueError for invalid PICP."""
    with pytest.raises(ValueError, match="PICP must be between 0 and 1"):
        gamma_coverage_score(picp=1.1, alpha=0.05)


def test_gamma_coverage_score_invalid_alpha():
    """Test Gamma Coverage Score raises ValueError for invalid alpha."""
    with pytest.raises(ValueError, match="alpha must be between 0 and 1"):
        gamma_coverage_score(picp=0.95, alpha=1.1)


# Test for CWE Score
def test_cwe_score():
    """Test CWE score calculation with valid inputs."""
    nmpi_val = 4.0
    picp_val = 0.95
    error_val = 0.1
    true_nmpic_val = 3.5
    alpha_val = 0.05
    beta_val = 1
    k_val = 1.0
    smoothing_val = 1e-6

    gamma_pic = gamma_coverage_score(picp_val, alpha_val)
    gamma_nmpic = standardized_gamma_nmpi(nmpi_val, true_nmpic_val, k_val, smoothing_val)
    if nmpi_val <= true_nmpic_val and picp_val >= alpha_val:
        gamma_nmpic = gamma_pic
    num = (1 + beta_val**2) * gamma_pic * gamma_nmpic
    denom = (beta_val**2 * gamma_nmpic) + gamma_pic
    cwe = num / denom
    cwe *= 1 - error_val
    if picp_val <= 0.5:
        cwe *= picp_val

    score = cwe_score(nmpi_val, picp_val, error_val, true_nmpic_val, alpha_val, beta_val, k_val, smoothing_val)
    assert np.isclose(score, cwe), f"Expected {cwe}, got {score}"


def test_cwe_score_no_error():
    """Test CWE score when error is None (no adjustment)."""
    nmpi_val = 4.0
    picp_val = 0.95
    true_nmpic_val = 3.5
    alpha_val = 0.05

    gamma_pic = gamma_coverage_score(picp_val, alpha_val)
    gamma_nmpic = standardized_gamma_nmpi(nmpi_val, true_nmpic_val)
    if nmpi_val <= true_nmpic_val and picp_val >= alpha_val:
        gamma_nmpic = gamma_pic
    num = (1 + 1**2) * gamma_pic * gamma_nmpic
    denom = (1**2 * gamma_nmpic) + gamma_pic
    expected_cwe = num / denom

    score = cwe_score(nmpi_val, picp_val, None, true_nmpic_val, alpha_val)
    assert np.isclose(score, expected_cwe), f"Expected {expected_cwe}, got {score}"


def test_cwe_score_picp_below_half():
    """Test CWE score adjustment when picp <= 0.5."""
    nmpi_val = 4.0
    picp_val = 0.4  # Below 0.5
    error_val = 0.1
    true_nmpic_val = 3.5
    alpha_val = 0.05

    gamma_pic = gamma_coverage_score(picp_val, alpha_val)
    gamma_nmpic = standardized_gamma_nmpi(nmpi_val, true_nmpic_val)
    if nmpi_val <= true_nmpic_val and picp_val >= alpha_val:
        gamma_nmpic = gamma_pic
    num = (1 + 1**2) * gamma_pic * gamma_nmpic
    denom = (1**2 * gamma_nmpic) + gamma_pic
    cwe = num / denom
    cwe *= 1 - error_val
    cwe *= picp_val  # Adjustment for picp <= 0.5

    score = cwe_score(nmpi_val, picp_val, error_val, true_nmpic_val, alpha_val)
    assert np.isclose(score, cwe), f"Expected {cwe}, got {score}"


# ---------------------------------------------------------------------------
# get_interval_metrics — validation branches (lines 305, 307)
# ---------------------------------------------------------------------------


def test_get_interval_metrics_invalid_alpha_raises() -> None:
    """get_interval_metrics raises ValueError when alpha is not in (0, 1)."""
    pred = np.array([1.0, 2.0, 3.0])
    true = np.array([1.1, 2.1, 3.1])
    lower = np.array([0.5, 1.5, 2.5])
    upper = np.array([1.5, 2.5, 3.5])
    with pytest.raises(ValueError, match="alpha must be between 0 and 1"):
        get_interval_metrics(pred, true, lower, upper, alpha=0.0)
    with pytest.raises(ValueError, match="alpha must be between 0 and 1"):
        get_interval_metrics(pred, true, lower, upper, alpha=1.0)


def test_get_interval_metrics_invalid_true_nmpi_raises() -> None:
    """get_interval_metrics raises ValueError when true_nmpi <= 0."""
    pred = np.array([1.0, 2.0, 3.0])
    true = np.array([1.1, 2.1, 3.1])
    lower = np.array([0.5, 1.5, 2.5])
    upper = np.array([1.5, 2.5, 3.5])
    with pytest.raises(ValueError, match="true_nmpi must be positive"):
        get_interval_metrics(pred, true, lower, upper, alpha=0.1, true_nmpi=-1.0)
    with pytest.raises(ValueError, match="true_nmpi must be positive"):
        get_interval_metrics(pred, true, lower, upper, alpha=0.1, true_nmpi=0.0)


def test_get_interval_metrics_valid_returns_dataframe() -> None:
    """get_interval_metrics returns a DataFrame with expected metric columns."""
    pred = np.array([1.0, 2.0, 3.0])
    true = np.array([1.1, 2.1, 3.1])
    lower = np.array([0.5, 1.5, 2.5])
    upper = np.array([1.5, 2.5, 3.5])
    result = get_interval_metrics(pred, true, lower, upper, alpha=0.1)
    expected_cols = {"winkle-score", "picp", "ace", "nmpi", "cwe"}
    assert expected_cols.issubset(set(result.columns))
