"""Unit tests for twiga.core.metrics.

Covers:
- All evaluate_* functions via ForecastResult fixtures.
- The evaluate_forecast dispatcher.
- Low-level helpers: get_quantile_metrics, get_samples_metrics, get_parametric_metrics,
  continuous_ranked_probability_score.
- Primitives now in quantile.py: pinball_score, calibration_coverage, quantile_sharpness.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from twiga.core.metrics import (
    evaluate_forecast,
    evaluate_interval_forecast,
    evaluate_parametric_forecast,
    evaluate_point_forecast,
    evaluate_quantile_forecast,
    evaluate_samples_forecast,
)
from twiga.core.metrics.prob import (
    continuous_ranked_probability_score,
    get_parametric_metrics,
    get_samples_metrics,
)
from twiga.core.metrics.quantile import (
    calibration_coverage,
    get_quantile_metrics,
    pinball_score,
    quantile_sharpness,
)
from twiga.forecaster.result import ForecastKind, ForecastResult

# ---------------------------------------------------------------------------
# Shared constants
# ---------------------------------------------------------------------------

N_DAYS = 3
N_STEPS = 24
N_TARGETS = 2
N_Q = 3
N_SAMPLES = 50
TARGETS = ["load", "pv"]
QUANTILE_LEVELS = [0.1, 0.5, 0.9]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_timestamps(n_days: int, n_steps: int, n_targets: int) -> np.ndarray:
    """Build a synthetic timestamp array in nanosecond int64 format."""
    base = pd.date_range("2024-01-01", periods=n_days * n_steps, freq="h")
    ts = base.asi8.reshape(n_days, n_steps, 1)
    return np.repeat(ts, n_targets, axis=2)


# ---------------------------------------------------------------------------
# Fixtures — all return ForecastResult with ground_truth set
# ---------------------------------------------------------------------------


@pytest.fixture()
def point_result() -> ForecastResult:
    rng = np.random.default_rng(0)
    true = rng.standard_normal((N_DAYS, N_STEPS, N_TARGETS)) + 5
    loc = true + rng.standard_normal((N_DAYS, N_STEPS, N_TARGETS)) * 0.5
    ts = _make_timestamps(N_DAYS, N_STEPS, N_TARGETS)
    return ForecastResult(
        timestamps=ts,
        loc=loc,
        targets=TARGETS,
        model_name="test_model",
        kind=ForecastKind.POINT,
        ground_truth=true,
    )


@pytest.fixture()
def interval_result() -> ForecastResult:
    rng = np.random.default_rng(1)
    true = rng.standard_normal((N_DAYS, N_STEPS, N_TARGETS)) + 5
    loc = true + rng.standard_normal((N_DAYS, N_STEPS, N_TARGETS)) * 0.5
    ts = _make_timestamps(N_DAYS, N_STEPS, N_TARGETS)
    return ForecastResult(
        timestamps=ts,
        loc=loc,
        targets=TARGETS,
        model_name="test_model",
        kind=ForecastKind.INTERVAL,
        ground_truth=true,
        lower=loc - rng.uniform(0.5, 1.0, loc.shape),
        upper=loc + rng.uniform(0.5, 1.0, loc.shape),
    )


@pytest.fixture()
def quantile_result() -> ForecastResult:
    rng = np.random.default_rng(2)
    true = rng.standard_normal((N_DAYS, N_STEPS, N_TARGETS)) + 5
    loc = true + rng.standard_normal((N_DAYS, N_STEPS, N_TARGETS)) * 0.2
    ts = _make_timestamps(N_DAYS, N_STEPS, N_TARGETS)
    offsets = np.sort(rng.standard_normal((N_DAYS, N_Q, N_STEPS, N_TARGETS)), axis=1)
    quantiles = true[:, np.newaxis, :, :] + offsets
    return ForecastResult(
        timestamps=ts,
        loc=loc,
        targets=TARGETS,
        model_name="test_model",
        kind=ForecastKind.QUANTILE,
        ground_truth=true,
        quantiles=quantiles,
        quantile_levels=QUANTILE_LEVELS,
    )


@pytest.fixture()
def samples_result() -> ForecastResult:
    rng = np.random.default_rng(3)
    true = rng.standard_normal((N_DAYS, N_STEPS, N_TARGETS)) + 5
    loc = true + rng.standard_normal((N_DAYS, N_STEPS, N_TARGETS)) * 0.2
    ts = _make_timestamps(N_DAYS, N_STEPS, N_TARGETS)
    samples = true[:, np.newaxis, :, :] + rng.standard_normal((N_DAYS, N_SAMPLES, N_STEPS, N_TARGETS))
    return ForecastResult(
        timestamps=ts,
        loc=loc,
        targets=TARGETS,
        model_name="test_model",
        kind=ForecastKind.SAMPLES,
        ground_truth=true,
        samples=samples,
    )


@pytest.fixture()
def parametric_result() -> ForecastResult:
    rng = np.random.default_rng(4)
    true = rng.standard_normal((N_DAYS, N_STEPS, N_TARGETS)) + 5
    loc = true + rng.standard_normal((N_DAYS, N_STEPS, N_TARGETS)) * 0.3
    ts = _make_timestamps(N_DAYS, N_STEPS, N_TARGETS)
    return ForecastResult(
        timestamps=ts,
        loc=loc,
        targets=TARGETS,
        model_name="test_model",
        kind=ForecastKind.PARAMETRIC,
        ground_truth=true,
        scale=rng.uniform(0.1, 1.0, loc.shape),
    )


# ---------------------------------------------------------------------------
# evaluate_point_forecast
# ---------------------------------------------------------------------------


class TestEvaluatePointForecast:
    def test_returns_dataframe(self, point_result: ForecastResult) -> None:
        assert isinstance(evaluate_point_forecast(point_result), pd.DataFrame)

    def test_index_is_datetime(self, point_result: ForecastResult) -> None:
        result = evaluate_point_forecast(point_result)
        assert pd.api.types.is_datetime64_any_dtype(result.index)

    def test_row_count(self, point_result: ForecastResult) -> None:
        assert len(evaluate_point_forecast(point_result)) == N_DAYS * N_TARGETS

    def test_target_column(self, point_result: ForecastResult) -> None:
        result = evaluate_point_forecast(point_result)
        assert "target" in result.columns
        assert set(result["target"].unique()) == set(TARGETS)

    def test_mae_column_present(self, point_result: ForecastResult) -> None:
        assert "mae" in evaluate_point_forecast(point_result).columns

    def test_metric_subset(self, point_result: ForecastResult) -> None:
        result = evaluate_point_forecast(point_result, metric_names=["mae", "rmse"])
        assert "mae" in result.columns
        assert "rmse" in result.columns
        assert "mape" not in result.columns

    def test_mae_non_negative(self, point_result: ForecastResult) -> None:
        assert (evaluate_point_forecast(point_result)["mae"] >= 0).all()

    def test_perfect_forecast_zero_mae(self) -> None:
        ts = _make_timestamps(2, 24, 1)
        true = np.ones((2, 24, 1))
        result = ForecastResult(
            timestamps=ts,
            loc=true.copy(),
            targets=["load"],
            model_name="perfect",
            kind=ForecastKind.POINT,
            ground_truth=true,
        )
        df = evaluate_point_forecast(result, metric_names=["mae"])
        np.testing.assert_allclose(df["mae"].to_numpy(), 0.0, atol=1e-12)

    def test_missing_ground_truth_raises(self) -> None:
        ts = _make_timestamps(1, 24, 1)
        result = ForecastResult(
            timestamps=ts,
            loc=np.ones((1, 24, 1)),
            targets=["load"],
            model_name="m",
            kind=ForecastKind.POINT,
        )
        with pytest.raises(ValueError, match="ground_truth"):
            evaluate_forecast(result)


# ---------------------------------------------------------------------------
# evaluate_interval_forecast
# ---------------------------------------------------------------------------


class TestEvaluateIntervalForecast:
    def test_returns_dataframe(self, interval_result: ForecastResult) -> None:
        assert isinstance(evaluate_interval_forecast(interval_result), pd.DataFrame)

    def test_row_count(self, interval_result: ForecastResult) -> None:
        assert len(evaluate_interval_forecast(interval_result)) == N_DAYS * N_TARGETS

    def test_interval_metric_columns(self, interval_result: ForecastResult) -> None:
        result = evaluate_interval_forecast(interval_result)
        for col in ("picp", "nmpi", "ace", "winkle-score"):
            assert col in result.columns, f"Missing column: {col}"

    def test_coverage_in_unit_interval(self, interval_result: ForecastResult) -> None:
        result = evaluate_interval_forecast(interval_result)
        assert (result["picp"] >= 0).all()
        assert (result["picp"] <= 1).all()


# ---------------------------------------------------------------------------
# evaluate_quantile_forecast
# ---------------------------------------------------------------------------


class TestEvaluateQuantileForecast:
    def test_returns_dataframe(self, quantile_result: ForecastResult) -> None:
        assert isinstance(evaluate_quantile_forecast(quantile_result), pd.DataFrame)

    def test_row_count(self, quantile_result: ForecastResult) -> None:
        assert len(evaluate_quantile_forecast(quantile_result)) == N_DAYS * N_TARGETS

    def test_prob_columns_present(self, quantile_result: ForecastResult) -> None:
        result = evaluate_quantile_forecast(quantile_result)
        for col in ("pinball", "calibration_error", "sharpness"):
            assert col in result.columns, f"Missing column: {col}"

    def test_point_columns_present(self, quantile_result: ForecastResult) -> None:
        assert "mae" in evaluate_quantile_forecast(quantile_result).columns

    def test_target_column(self, quantile_result: ForecastResult) -> None:
        result = evaluate_quantile_forecast(quantile_result)
        assert set(result["target"].unique()) == set(TARGETS)

    def test_uses_loc_not_ground_truth_for_point_metrics(self, quantile_result: ForecastResult) -> None:
        """Regression: pred_vals must come from loc, not ground_truth."""
        df = evaluate_quantile_forecast(quantile_result)
        # If there is noise between loc and ground_truth, MAE > 0.
        assert (df["mae"] > 0).all()


# ---------------------------------------------------------------------------
# evaluate_samples_forecast
# ---------------------------------------------------------------------------


class TestEvaluateSamplesForecast:
    def test_returns_dataframe(self, samples_result: ForecastResult) -> None:
        assert isinstance(evaluate_samples_forecast(samples_result), pd.DataFrame)

    def test_row_count(self, samples_result: ForecastResult) -> None:
        assert len(evaluate_samples_forecast(samples_result)) == N_DAYS * N_TARGETS

    def test_crps_column_present(self, samples_result: ForecastResult) -> None:
        assert "crps" in evaluate_samples_forecast(samples_result).columns

    def test_crps_non_negative(self, samples_result: ForecastResult) -> None:
        assert (evaluate_samples_forecast(samples_result)["crps"] >= 0).all()


# ---------------------------------------------------------------------------
# evaluate_parametric_forecast
# ---------------------------------------------------------------------------


class TestEvaluateParametricForecast:
    def test_returns_dataframe(self, parametric_result: ForecastResult) -> None:
        assert isinstance(evaluate_parametric_forecast(parametric_result), pd.DataFrame)

    def test_row_count(self, parametric_result: ForecastResult) -> None:
        assert len(evaluate_parametric_forecast(parametric_result)) == N_DAYS * N_TARGETS

    def test_nll_column_present(self, parametric_result: ForecastResult) -> None:
        assert "nll" in evaluate_parametric_forecast(parametric_result).columns


# ---------------------------------------------------------------------------
# evaluate_forecast dispatcher
# ---------------------------------------------------------------------------


class TestEvaluateForecastDispatcher:
    def test_dispatches_point(self, point_result: ForecastResult) -> None:
        result = evaluate_forecast(point_result)
        assert isinstance(result, pd.DataFrame)
        assert "mae" in result.columns

    def test_dispatches_interval(self, interval_result: ForecastResult) -> None:
        assert "picp" in evaluate_forecast(interval_result).columns

    def test_dispatches_quantile(self, quantile_result: ForecastResult) -> None:
        assert "pinball" in evaluate_forecast(quantile_result).columns

    def test_dispatches_samples(self, samples_result: ForecastResult) -> None:
        assert "crps" in evaluate_forecast(samples_result).columns

    def test_dispatches_parametric(self, parametric_result: ForecastResult) -> None:
        assert "nll" in evaluate_forecast(parametric_result).columns

    def test_missing_ground_truth_raises(self, point_result: ForecastResult) -> None:
        point_result.ground_truth = None
        with pytest.raises(ValueError, match="ground_truth"):
            evaluate_forecast(point_result)

    def test_kwargs_forwarded(self, interval_result: ForecastResult) -> None:
        result = evaluate_forecast(interval_result, alpha=0.05)
        assert isinstance(result, pd.DataFrame)

    def test_result_indexed_by_timestamp(self, point_result: ForecastResult) -> None:
        result = evaluate_forecast(point_result)
        assert pd.api.types.is_datetime64_any_dtype(result.index)

    def test_forecast_result_evaluate_method(self, point_result: ForecastResult) -> None:
        """ForecastResult.evaluate() delegates to evaluate_forecast correctly."""
        df = point_result.evaluate()
        assert isinstance(df, pd.DataFrame)
        assert "mae" in df.columns

    def test_evaluate_method_with_explicit_ground_truth(self, point_result: ForecastResult) -> None:
        """evaluate() accepts an explicit ground_truth override."""
        gt = point_result.ground_truth
        point_result.ground_truth = None
        df = point_result.evaluate(ground_truth=gt)
        assert isinstance(df, pd.DataFrame)

    def test_evaluate_method_raises_without_ground_truth(self, point_result: ForecastResult) -> None:
        point_result.ground_truth = None
        with pytest.raises(ValueError, match="ground_truth"):
            point_result.evaluate()


# ---------------------------------------------------------------------------
# Low-level helpers (quantile.py primitives)
# ---------------------------------------------------------------------------


class TestPinballScore:
    def test_returns_scalar(self) -> None:
        y = np.ones(10)
        q = np.stack([y + 0.1, y - 0.1])  # (2, 10)
        score = pinball_score(y, q, quantile_levels=[0.1, 0.9], quantile_axis=0)
        assert isinstance(score, float)

    def test_zero_for_perfect(self) -> None:
        y = np.ones(20)
        q = np.stack([y, y, y])  # perfect at any tau
        score = pinball_score(y, q, quantile_levels=[0.1, 0.5, 0.9], quantile_axis=0)
        assert score == pytest.approx(0.0, abs=1e-12)

    def test_lower_score_for_better_forecast(self) -> None:
        rng = np.random.default_rng(0)
        y = rng.standard_normal(100) + 5
        good = np.stack([y + 0.01, y - 0.01])
        bad = np.stack([y + 2.0, y - 2.0])
        taus = [0.1, 0.9]
        assert pinball_score(y, good, taus, quantile_axis=0) < pinball_score(y, bad, taus, quantile_axis=0)


class TestCalibrationCoverage:
    def test_returns_per_level_array(self) -> None:
        rng = np.random.default_rng(0)
        y = rng.standard_normal(200)
        levels = [0.1, 0.5, 0.9]
        q = np.stack([np.full(200, np.quantile(y, lv)) for lv in levels])
        cov = calibration_coverage(y, q, levels, quantile_axis=0)
        assert cov.shape == (len(levels),)

    def test_coverage_in_unit_interval(self) -> None:
        rng = np.random.default_rng(1)
        y = rng.standard_normal(200)
        levels = [0.1, 0.5, 0.9]
        q = np.stack([np.full(200, np.quantile(y, lv)) for lv in levels])
        cov = calibration_coverage(y, q, levels, quantile_axis=0)
        assert np.all(cov >= 0) and np.all(cov <= 1)

    def test_perfect_calibration(self) -> None:
        """Quantiles equal to empirical quantiles should yield coverage ≈ level."""
        rng = np.random.default_rng(42)
        y = rng.standard_normal(5000)
        levels = [0.1, 0.5, 0.9]
        q = np.stack([np.full(5000, np.quantile(y, lv)) for lv in levels])
        cov = calibration_coverage(y, q, levels, quantile_axis=0)
        np.testing.assert_allclose(cov, levels, atol=0.02)


class TestQuantileSharpness:
    def test_zero_with_no_symmetric_pairs(self) -> None:
        q = np.ones((2, 10))
        assert quantile_sharpness(q, quantile_levels=[0.1, 0.3], quantile_axis=0) == 0.0

    def test_positive_for_wide_intervals(self) -> None:
        rng = np.random.default_rng(0)
        n = 100
        levels = [0.1, 0.5, 0.9]
        narrow = np.stack([rng.standard_normal(n) * 0.1 + lv for lv in levels])
        wide = np.stack([rng.standard_normal(n) * 5.0 + lv for lv in levels])
        assert quantile_sharpness(wide, levels, quantile_axis=0) > quantile_sharpness(narrow, levels, quantile_axis=0)


class TestGetQuantileMetrics:
    def test_returns_single_row_dataframe(self) -> None:
        rng = np.random.default_rng(0)
        y = rng.standard_normal(24)
        levels = [0.1, 0.5, 0.9]
        qs = np.stack([y + rng.standard_normal(24) * 0.2 * i for i in range(3)])
        result = get_quantile_metrics(true=y, quantiles=qs, quantile_levels=levels)
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1

    def test_required_columns(self) -> None:
        rng = np.random.default_rng(1)
        y = rng.standard_normal(24)
        levels = [0.1, 0.5, 0.9]
        qs = np.stack([y - 1, y, y + 1])
        result = get_quantile_metrics(true=y, quantiles=qs, quantile_levels=levels)
        for col in ("pinball", "calibration_error", "sharpness"):
            assert col in result.columns


class TestGetSamplesMetrics:
    def test_returns_dataframe_with_crps(self) -> None:
        rng = np.random.default_rng(0)
        y = rng.standard_normal(24)
        loc = y + rng.standard_normal(24) * 0.1
        samples = rng.standard_normal((50, 24))
        result = get_samples_metrics(y, loc, samples)
        assert isinstance(result, pd.DataFrame)
        assert "crps" in result.columns

    def test_crps_non_negative(self) -> None:
        rng = np.random.default_rng(0)
        y = rng.standard_normal(48)
        result = get_samples_metrics(y, y.copy(), rng.standard_normal((30, 48)))
        assert result["crps"].iloc[0] >= 0


class TestGetParametricMetrics:
    def test_returns_dataframe_with_nll(self) -> None:
        rng = np.random.default_rng(0)
        y = rng.standard_normal(24) + 5
        result = get_parametric_metrics(y, y + rng.standard_normal(24) * 0.1, np.full(24, 1.0))
        assert isinstance(result, pd.DataFrame)
        assert "nll" in result.columns

    def test_nll_lower_for_smaller_residuals(self) -> None:
        rng = np.random.default_rng(0)
        y = rng.standard_normal(100) + 5
        scale = np.ones(100)
        nll_good = get_parametric_metrics(y, y + rng.standard_normal(100) * 0.1, scale)["nll"].iloc[0]
        nll_bad = get_parametric_metrics(y, y + rng.standard_normal(100) * 3.0, scale)["nll"].iloc[0]
        assert nll_good < nll_bad

    def test_negative_scale_raises(self) -> None:
        y = np.ones(10)
        with pytest.raises(ValueError, match="strictly positive"):
            get_parametric_metrics(y, y.copy(), -np.ones(10))

    def test_precomputed_log_likelihood(self) -> None:
        y = np.ones(24)
        ll = np.full(24, -1.0)  # NLL should be 1.0
        result = get_parametric_metrics(y, y.copy(), np.ones(24), log_likelihood=ll)
        assert result["nll"].iloc[0] == pytest.approx(1.0)


class TestCRPS:
    def test_zero_for_perfect_deterministic(self) -> None:
        y = np.array([2.0, 3.0, 4.0])
        samples = np.repeat(y[np.newaxis, :], 50, axis=0)
        assert continuous_ranked_probability_score(y, samples) == pytest.approx(0.0, abs=1e-6)

    def test_increases_with_spread(self) -> None:
        rng = np.random.default_rng(42)
        y = np.zeros(200)
        narrow = rng.normal(0, 0.1, (100, 200))
        wide = rng.normal(0, 5.0, (100, 200))
        assert continuous_ranked_probability_score(y, narrow) < continuous_ranked_probability_score(y, wide)

    def test_returns_scalar(self) -> None:
        rng = np.random.default_rng(0)
        y = rng.standard_normal(24)
        result = continuous_ranked_probability_score(y, rng.standard_normal((20, 24)))
        assert isinstance(result, float)
