import logging
from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest

from twiga.core.metrics.point import (
    abs_error,
    abs_scaled_error,
    absolute_percentage_error,
    corr,
    error,
    get_pointwise_metrics,
    get_scaled,
    mae,
    mape,
    mase,
    mse,
    msse,
    nbias,
    nrmse,
    ope,
    res,
    rmse,
    rmsse,
    smape,
    squared_error,
    squared_scaled_error,
    symmetrical_abs_percent_error,
    wmape,
)  # Adjust import based on file location


# Fixtures for reusable test data
@pytest.fixture
def sample_y():
    """Provide sample actual values for testing.

    Returns:
        np.ndarray: A 5-element array of float32 values.
    """
    return np.array([1, 2, 3, 4, 5], dtype=np.float32)


@pytest.fixture
def sample_y_hat():
    """Provide sample predicted values for testing.

    Returns:
        np.ndarray: A 5-element array of float32 values.
    """
    return np.array([1.1, 2.2, 3.1, 4.3, 5.2], dtype=np.float32)


@pytest.fixture
def mismatched_y_hat():
    """Provide mismatched predicted values for testing error cases.

    Returns:
        np.ndarray: A 3-element array of float32 values, shorter than sample_y.
    """
    return np.array([1.1, 2.2, 3.1], dtype=np.float32)


# Tests for error
def test_error(sample_y, sample_y_hat):
    """Test the error function."""
    result = error(sample_y, sample_y_hat)
    expected = np.array([-0.1, -0.2, -0.1, -0.3, -0.2], dtype=np.float32)
    np.testing.assert_array_almost_equal(result, expected)


def test_error_shape_mismatch(sample_y, mismatched_y_hat):
    """Test error handling for mismatched shapes in error function."""
    with pytest.raises(ValueError, match="Shapes of y .* and y_hat .* must match"):
        error(sample_y, mismatched_y_hat)


# Tests for abs_error
def test_abs_error(sample_y, sample_y_hat):
    """Test the abs_error function."""
    result = abs_error(sample_y, sample_y_hat)
    expected = np.array([0.1, 0.2, 0.1, 0.3, 0.2], dtype=np.float32)
    np.testing.assert_array_almost_equal(result, expected)


# Tests for res
def test_res(sample_y, sample_y_hat):
    """Test the res function (mean error)."""
    result = res(sample_y, sample_y_hat)
    expected = np.mean([-0.1, -0.2, -0.1, -0.3, -0.2])
    assert np.isclose(result, expected)


def test_res_with_nans():
    """Test res with NaN values."""
    y = np.array([1, 2, np.nan, 4])
    y_hat = np.array([1.1, 2.2, 3.1, 4.3])
    result = res(y, y_hat)
    expected = np.nanmean([-0.1, -0.2, -0.3])
    assert np.isclose(result, expected)


def test_res_2d():
    """Test res with 2D inputs."""
    y = np.array([[1, 2], [3, 4]], dtype=np.float32)
    y_hat = np.array([[1.1, 2.2], [3.1, 4.3]], dtype=np.float32)
    result = res(y, y_hat, axis=0)
    expected = np.array([-0.1, -0.25])  # Mean along axis 0: [-0.1, -0.1], [-0.2, -0.3]
    np.testing.assert_allclose(result, expected, rtol=1e-5)


# Tests for mae
def test_mae(sample_y, sample_y_hat):
    """Test the mae function."""
    result = mae(sample_y, sample_y_hat)
    expected = np.mean([0.1, 0.2, 0.1, 0.3, 0.2])
    assert np.isclose(result, expected)


def test_mae_with_nans():
    """Test mae with NaN values."""
    y = np.array([1, 2, np.nan, 4])
    y_hat = np.array([1.1, 2.2, 3.1, 4.3])
    result = mae(y, y_hat)
    expected = np.nanmean([0.1, 0.2, 0.3])
    assert np.isclose(result, expected)


def test_mae_2d():
    """Test mae with 2D inputs."""
    y = np.array([[1, 2], [3, 4]], dtype=np.float32)
    y_hat = np.array([[1.1, 2.2], [3.1, 4.3]], dtype=np.float32)
    result = mae(y, y_hat, axis=0)
    expected = np.array([0.1, 0.25])  # Mean along axis 0: [0.1, 0.1], [0.2, 0.3]
    np.testing.assert_allclose(result, expected, rtol=1e-5)


def test_mae_series():
    """Test mae with pandas Series inputs."""
    y = pd.Series([1, 2, 3])
    y_hat = pd.Series([1.1, 2.2, 3.1])
    result = mae(y, y_hat)
    expected = np.mean([0.1, 0.2, 0.1])
    assert np.isclose(result, expected)


# Tests for get_scaled
def test_get_scaled_mae(sample_y):
    """Test get_scaled with MAE metric."""
    result = get_scaled(sample_y, h=1, metric="mae")
    diff = sample_y[1:] - sample_y[:-1]  # [1, 1, 1, 1]
    expected = np.nanmean(np.abs(diff))  # 1.0
    assert np.isclose(result, expected)


def test_get_scaled_mse(sample_y):
    """Test get_scaled with MSE metric."""
    result = get_scaled(sample_y, h=1, metric="mse")
    diff = sample_y[1:] - sample_y[:-1]  # [1, 1, 1, 1]
    expected = np.nanmean(np.power(diff, 2))  # 1.0
    assert np.isclose(result, expected)


def test_get_scaled_rmse(sample_y):
    """Test get_scaled with RMSE metric."""
    result = get_scaled(sample_y, h=1, metric="rmse")
    diff = sample_y[1:] - sample_y[:-1]  # [1, 1, 1, 1]
    expected = np.sqrt(np.nanmean(np.power(diff, 2)))  # sqrt(1.0) = 1.0
    assert np.isclose(result, expected)


def test_get_scaled_invalid_metric(sample_y):
    """Test get_scaled with an invalid metric."""
    with pytest.raises(ValueError, match="Unknown `metric=invalid`.*"):
        get_scaled(sample_y, h=1, metric="invalid")


def test_get_scaled_invalid_h(sample_y):
    """Test get_scaled with an invalid lag h."""
    with pytest.raises(ValueError, match="Lag h=5 must be less than the length of y=5"):
        get_scaled(sample_y, h=5)


# Tests for abs_scaled_error
def test_abs_scaled_error_mae(sample_y, sample_y_hat):
    """Test abs_scaled_error with MAE metric."""
    result = abs_scaled_error(sample_y, sample_y_hat, h=1, metric="mae")
    expected = np.array([0.1, 0.2, 0.1, 0.3, 0.2]) / 1.0
    np.testing.assert_array_almost_equal(result, expected)


def test_abs_scaled_error_zero_scale():
    """Test abs_scaled_error with zero scale factor."""
    y = np.array([1, 1, 1])
    y_hat = np.array([1.1, 1.2, 1.1])
    with pytest.raises(ValueError, match="Scale factor is zero or NaN"):
        abs_scaled_error(y, y_hat, h=1, metric="mae")


# Tests for mase
def test_mase_basic(sample_y, sample_y_hat):
    """Test the mase function with default parameters."""
    result = mase(sample_y, sample_y_hat, h=1)
    expected = np.mean([0.1, 0.2, 0.1, 0.3, 0.2]) / 1.0
    assert np.isclose(result, expected)


def test_mase_zero_scale():
    """Test mase with zero scale factor."""
    y = np.array([1, 1, 1])
    y_hat = np.array([1.1, 1.2, 1.1])
    with pytest.raises(ValueError, match="Scale factor is zero or NaN"):
        mase(y, y_hat, h=1)


# Tests for squared_error
def test_squared_error(sample_y, sample_y_hat):
    """Test the squared_error function."""
    result = squared_error(sample_y, sample_y_hat)
    expected = np.array([0.01, 0.04, 0.01, 0.09, 0.04], dtype=np.float32)
    np.testing.assert_array_almost_equal(result, expected)


# Tests for mse
def test_mse(sample_y, sample_y_hat):
    """Test the mse function."""
    result = mse(sample_y, sample_y_hat)
    expected = np.mean([0.01, 0.04, 0.01, 0.09, 0.04])
    assert np.isclose(result, expected)


def test_mse_with_nans():
    """Test mse with NaN values."""
    y = np.array([1, 2, np.nan, 4])
    y_hat = np.array([1.1, 2.2, 3.1, 4.3])
    result = mse(y, y_hat)
    expected = np.nanmean([0.01, 0.04, 0.09])
    assert np.isclose(result, expected)


# Tests for squared_scaled_error
def test_squared_scaled_error(sample_y, sample_y_hat):
    """Test the squared_scaled_error function."""
    result = squared_scaled_error(sample_y, sample_y_hat, h=1)
    expected = np.array([0.01, 0.04, 0.01, 0.09, 0.04]) / 1.0  # Scale = MSE of [1, 1, 1, 1]
    np.testing.assert_array_almost_equal(result, expected)


def test_squared_scaled_error_zero_scale():
    """Test squared_scaled_error with a zero scale factor."""
    y = np.array([1, 1, 1, 1])
    y_hat = np.array([1.1, 1.2, 1.1, 1.3])
    with pytest.raises(ValueError, match="Scale factor is zero or NaN"):
        squared_scaled_error(y, y_hat, h=1)


# Tests for msse
def test_msse(sample_y, sample_y_hat):
    """Test the msse function."""
    result = msse(sample_y, sample_y_hat, h=1)
    expected = np.mean([0.01, 0.04, 0.01, 0.09, 0.04]) / 1.0
    assert np.isclose(result, expected)


# Tests for rmse
def test_rmse(sample_y, sample_y_hat):
    """Test the rmse function."""
    result = rmse(sample_y, sample_y_hat)
    expected = np.sqrt(np.mean([0.01, 0.04, 0.01, 0.09, 0.04]))
    assert np.isclose(result, expected)


# Tests for rmsse
def test_rmsse(sample_y, sample_y_hat):
    """Test the rmsse function."""
    result = rmsse(sample_y, sample_y_hat, h=1)
    rmse_val = np.sqrt(np.mean([0.01, 0.04, 0.01, 0.09, 0.04]))
    scale = np.sqrt(1.0)  # RMSE of [1, 1, 1, 1]
    expected = rmse_val / scale
    assert np.isclose(result, expected)


def test_rmsse_zero_scale():
    """Test rmsse with a zero scale factor."""
    y = np.array([1, 1, 1, 1])
    y_hat = np.array([1.1, 1.2, 1.1, 1.3])
    with pytest.raises(ValueError, match="Scale factor is zero or NaN"):
        rmsse(y, y_hat, h=1)


# Tests for nrmse
def test_nrmse_max(sample_y, sample_y_hat):
    """Test nrmse with max scaling method."""
    result = nrmse(sample_y, sample_y_hat, scale_method="max")
    rmse_val = np.sqrt(np.mean([0.01, 0.04, 0.01, 0.09, 0.04]))
    expected = rmse_val / np.max(sample_y)
    assert np.isclose(result, expected)


def test_nrmse_range(sample_y, sample_y_hat):
    """Test nrmse with range scaling method."""
    result = nrmse(sample_y, sample_y_hat, scale_method="range")
    rmse_val = np.sqrt(np.mean([0.01, 0.04, 0.01, 0.09, 0.04]))
    expected = rmse_val / np.ptp(sample_y)
    assert np.isclose(result, expected)


def test_nrmse_mean(sample_y, sample_y_hat):
    """Test nrmse with mean scaling method."""
    result = nrmse(sample_y, sample_y_hat, scale_method="mean")
    rmse_val = np.sqrt(np.mean([0.01, 0.04, 0.01, 0.09, 0.04]))
    expected = rmse_val / np.mean(sample_y)
    assert np.isclose(result, expected)


def test_nrmse_custom_scale(sample_y, sample_y_hat):
    """Test nrmse with custom scale."""
    result = nrmse(sample_y, sample_y_hat, scale=2.0)
    rmse_val = np.sqrt(np.mean([0.01, 0.04, 0.01, 0.09, 0.04]))
    expected = rmse_val / 2.0
    assert np.isclose(result, expected)


def test_nrmse_zero_scale():
    """Test nrmse with zero scale."""
    with pytest.raises(ValueError, match="Scale factor must be non-zero"):
        nrmse(sample_y, sample_y_hat, scale=0)


def test_nrmse_invalid_scale_method(sample_y, sample_y_hat):
    """Test nrmse with invalid scale method."""
    with pytest.raises(ValueError, match="Unknown scale_method 'invalid'"):
        nrmse(sample_y, sample_y_hat, scale_method="invalid")


# Tests for absolute_percentage_error
def test_absolute_percentage_error():
    """Test the absolute_percentage_error function."""
    y = np.array([1, 2, 3, 4, 5])
    y_hat = np.array([1.1, 2.2, 3.1, 4.3, 5.2])
    result = absolute_percentage_error(y, y_hat)
    expected = 100 * np.array([0.1 / 1, 0.2 / 2, 0.1 / 3, 0.3 / 4, 0.2 / 5])
    np.testing.assert_allclose(result, expected, rtol=1e-5)


def test_absolute_percentage_error_zero():
    """Test absolute_percentage_error with zero in actual values."""
    y = np.array([1, 0, 3])
    y_hat = np.array([1.1, 1.9, 3.2])
    with pytest.raises(ValueError, match="`actual_series` must be strictly positive"):
        absolute_percentage_error(y, y_hat)


# Tests for mape
def test_mape(sample_y, sample_y_hat):
    """Test the mape function."""
    result = mape(sample_y, sample_y_hat)
    expected = np.mean(100 * np.array([0.1 / 1, 0.2 / 2, 0.1 / 3, 0.3 / 4, 0.2 / 5]))
    assert np.isclose(result, expected)


# Tests for wmape
def test_wmape(sample_y, sample_y_hat):
    """Test the wmape function."""
    result = wmape(sample_y, sample_y_hat)
    expected = 100 * np.sum([0.1, 0.2, 0.1, 0.3, 0.2]) / np.sum([1, 2, 3, 4, 5])
    assert np.isclose(result, expected)


def test_wmape_zero_sum():
    """Test wmape with zero sum of actual values."""
    y = np.array([0, 0])
    y_hat = np.array([0.1, 0.2])
    with pytest.raises(ValueError, match="Sum of actual values must be non-zero"):
        wmape(y, y_hat)


# Tests for symmetrical_abs_percent_error
def test_symmetrical_abs_percent_error():
    """Test the symmetrical_abs_percent_error function."""
    y = np.array([1, 2, 3, 4, 5])
    y_hat = np.array([1.1, 2.2, 3.1, 4.3, 5.2])
    result = symmetrical_abs_percent_error(y, y_hat)
    expected = 200 * np.array([0.1 / (1 + 1.1), 0.2 / (2 + 2.2), 0.1 / (3 + 3.1), 0.3 / (4 + 4.3), 0.2 / (5 + 5.2)])
    np.testing.assert_allclose(result, expected, rtol=1e-5)


def test_symmetrical_abs_percent_error_zero():
    """Test symmetrical_abs_percent_error with zero denominator."""
    y = np.array([0, 0])
    y_hat = np.array([0, 0])
    with pytest.raises(ValueError, match="Both `y` and `y_hat` must not be zero"):
        symmetrical_abs_percent_error(y, y_hat)


# Tests for smape
def test_smape(sample_y, sample_y_hat):
    """Test the smape function."""
    result = smape(sample_y, sample_y_hat)
    expected = np.mean(
        200 * np.array([0.1 / (1 + 1.1), 0.2 / (2 + 2.2), 0.1 / (3 + 3.1), 0.3 / (4 + 4.3), 0.2 / (5 + 5.2)])
    )
    assert np.isclose(result, expected)


# Tests for ope
def test_ope(sample_y, sample_y_hat):
    """Test the ope function."""
    result = ope(sample_y, sample_y_hat)
    y_sum = np.sum(sample_y)
    y_hat_sum = np.sum(sample_y_hat)
    expected = 100 * np.abs((y_sum - y_hat_sum) / y_sum)
    assert np.isclose(result, expected)


def test_ope_zero_sum():
    """Test ope with zero sum of actual values."""
    y = np.array([0, 0])
    y_hat = np.array([0.1, 0.2])
    with pytest.raises(ValueError, match="Sum of actual values must be non-zero"):
        ope(y, y_hat)


# Tests for corr
def test_corr(sample_y, sample_y_hat):
    """Test the corr function."""
    result = corr(sample_y, sample_y_hat)
    expected = np.corrcoef(sample_y, sample_y_hat)[0, 1]
    assert np.isclose(result, expected)


def test_corr_non_1d():
    """Test corr with non-1D input."""
    y = np.array([[1, 2], [3, 4]])
    y_hat = np.array([[1.1, 2.2], [3.1, 4.3]])
    with pytest.raises(ValueError, match="Inputs must be 1D"):
        corr(y, y_hat)


# Tests for nbias
def test_nbias(sample_y, sample_y_hat):
    """Test the nbias function."""
    result = nbias(sample_y, sample_y_hat)
    expected = np.sum(np.array([-0.1, -0.2, -0.1, -0.3, -0.2]) / (sample_y + sample_y_hat))
    assert np.isclose(result, expected)


def test_nbias_zero_scale():
    """Test nbias with zero scale."""
    y = np.array([1, -1])
    y_hat = np.array([1, 1])
    with pytest.raises(ValueError, match="Scale \\(y \\+ y_hat\\) must be non-zero"):
        nbias(y, y_hat)


# Tests for get_pointwise_metrics
def test_get_pointwise_metrics(sample_y, sample_y_hat):
    """Test get_pointwise_metrics with valid metrics."""
    metrics = get_pointwise_metrics(sample_y, sample_y_hat, ["mae", "mse"])
    assert "mae" in metrics
    assert "mse" in metrics
    assert np.isclose(metrics["mae"], mae(sample_y, sample_y_hat))
    assert np.isclose(metrics["mse"], mse(sample_y, sample_y_hat))


def test_get_pointwise_metrics_unknown_metric(sample_y, sample_y_hat):
    """Test get_pointwise_metrics with an unknown metric."""
    with pytest.raises(ValueError, match="Unknown metric name: unknown"):
        get_pointwise_metrics(sample_y, sample_y_hat, ["unknown"])


def test_get_pointwise_metrics_error(monkeypatch):
    """Test get_pointwise_metrics logs a warning and skips a metric that raises an error."""
    y = np.array([0, 1, 2])
    y_hat = np.array([0.1, 1.1, 2.2])

    # Define a failing mape function.
    def failing_mape(y, y_hat):
        class CustomMetricError(Exception):
            """Custom exception for metric calculation errors."""

            pass

        raise CustomMetricError("Intentional error")

    # Patch the mape function in the module where get_pointwise_metrics is defined.
    monkeypatch.setattr("twiga.core.metrics.point.mape", failing_mape)

    # Patch the module-level logger to capture warning calls directly.
    # (The twiga logger has propagate=False so pytest caplog cannot intercept it.)
    with patch("twiga.core.metrics.point.log") as mock_log:
        result_df = get_pointwise_metrics(y, y_hat, ["mape"])

    # Check that a warning was logged with the expected message.
    mock_log.warning.assert_called_once()
    call_args = mock_log.warning.call_args
    # Support both f-string style (single-arg) and %-formatting style (multi-arg)
    rendered = call_args[0][0] % call_args[0][1:] if len(call_args[0]) > 1 else call_args[0][0]
    assert "mape" in rendered
    assert "Intentional error" in rendered

    # Verify that the returned DataFrame does not include the failing metric.
    assert result_df.empty or "mape" not in result_df.columns


def test_get_pointwise_metrics_non_1d():
    """Test get_pointwise_metrics with non-1D inputs."""
    y = np.array([[1, 2], [3, 4]])
    y_hat = np.array([[1.1, 2.2], [3.1, 4.3]])
    with pytest.raises(ValueError, match="Inputs must be 1D"):
        get_pointwise_metrics(y, y_hat, ["mae"])


def test_nrmse_shape_mismatch_raises() -> None:
    """Nrmse raises ValueError when y and y_hat shapes differ (line 430)."""
    y = np.array([1.0, 2.0, 3.0])
    y_hat = np.array([1.0, 2.0])
    with pytest.raises(ValueError, match="Shapes of y"):
        nrmse(y, y_hat, scale_method="max")
