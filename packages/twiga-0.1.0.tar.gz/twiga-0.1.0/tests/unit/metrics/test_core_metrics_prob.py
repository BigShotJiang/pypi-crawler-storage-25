"""Unit tests for low-level probabilistic metric primitives.

pinball_loss and pinball_score have moved to twiga.core.metrics.quantile
with a unified array-based API.  The CRPS functions remain in prob.
"""

from __future__ import annotations

import numpy as np

from twiga.core.metrics.prob import (
    continuous_ranked_probability_score,
    continuous_ranked_probability_score_pwm,
)
from twiga.core.metrics.quantile import pinball_score


def test_pinball_loss_via_score_symmetric():
    """At tau=0.5, pinball loss is 0.5 * |y - q| per element.

    Verified via pinball_score with a single quantile level.
    """
    y = np.array([3.0, 5.0, 7.0])
    q = np.array([[2.5, 5.5, 6.5]])  # shape (1, 3) — quantile axis=0
    # element-wise: [0.25, 0.25, 0.25] → mean = 0.25
    result = pinball_score(y, q, quantile_levels=[0.5], quantile_axis=0)
    np.testing.assert_allclose(result, 0.25)


def test_pinball_score():
    """Test mean pinball score across two quantile levels."""
    true = np.array([3.0, 5.0, 7.0])
    q_values = np.stack([np.array([2.5, 5.5, 6.5]), np.array([2.0, 5.0, 7.5])])  # (2, 3)
    taus = [0.5, 0.9]
    expected = 0.2833333333333333
    result = pinball_score(true, q_values, quantile_levels=taus, quantile_axis=0)
    np.testing.assert_allclose(result, expected, rtol=1e-5, atol=1e-7)


def test_continuous_ranked_probability_score():
    """Test ranked prob score."""
    true = np.array([1.0, 2.0, 3.0])
    samples = np.array([[1.2, 2.1, 2.9], [1.0, 2.0, 3.0], [0.8, 1.9, 3.1]])
    expected = 0.02963
    result = continuous_ranked_probability_score(true, samples)
    np.testing.assert_allclose(result, expected, atol=1e-6)


def test_continuous_ranked_probability_score_pwm():
    """Test ranked prob score (PWM estimator)."""
    true = np.array([1.0, 2.0, 3.0])
    samples = np.array([[1.2, 2.1, 2.9], [1.0, 2.0, 3.0], [0.8, 1.9, 3.1]])
    expected = 0.02963
    result = continuous_ranked_probability_score_pwm(true, samples)
    np.testing.assert_allclose(result, expected, atol=1e-6)


def test_continuous_ranked_probability_score_pwm_single_sample():
    """With one sample, CRPS-PWM equals mean absolute error."""
    true = np.array([1.0, 2.0, 3.0])
    samples = np.array([[1.2, 2.1, 2.9]])
    expected = np.mean(np.abs(samples - true))
    result = continuous_ranked_probability_score_pwm(true, samples)
    np.testing.assert_allclose(result, expected)
