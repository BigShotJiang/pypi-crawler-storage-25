"""Unit tests for twiga.utils.data_loading."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import pandas as pd
import pytest

from twiga.utils.data_loading import (
    get_best_autoregessive_features,
    get_best_temporal_features,
    load_dataset,
)

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def hourly_ts() -> pd.DataFrame:
    """Minimal hourly time-series with timestamp and target."""
    idx = pd.date_range("2020-01-01", periods=200, freq="h")
    rng = np.random.default_rng(42)
    return pd.DataFrame(
        {
            "timestamp": idx,
            "target": rng.uniform(10, 100, size=200),
        }
    )


@pytest.fixture
def ts_with_exog(hourly_ts: pd.DataFrame) -> pd.DataFrame:
    """Hourly time-series with an exogenous column."""
    rng = np.random.default_rng(0)
    hourly_ts["exog"] = rng.uniform(0, 1, size=len(hourly_ts))
    return hourly_ts


# ── get_best_autoregessive_features ──────────────────────────────────────────


def test_autoregressive_returns_list(hourly_ts):
    """Returns a Python list."""
    result = get_best_autoregessive_features(
        data=hourly_ts,
        target_series="target",
        periods=[1, 2],
        n_samples=24,
        top_k=2,
    )
    assert isinstance(result, list)


def test_autoregressive_default_args(hourly_ts):
    """Works without supplying optional rolling_type and periods."""
    result = get_best_autoregessive_features(
        data=hourly_ts,
        target_series="target",
        n_samples=24,
        top_k=2,
    )
    assert isinstance(result, list)


def test_autoregressive_top_k_bounds(hourly_ts):
    """top_k is enforced to at least 1 internally (top_k=1 → top_k-1=0 → max(1,0)=1)."""
    result = get_best_autoregessive_features(
        data=hourly_ts,
        target_series="target",
        periods=[1],
        n_samples=24,
        top_k=1,
    )
    assert isinstance(result, list)


def test_autoregressive_does_not_mutate_input(hourly_ts):
    """Input DataFrame is not modified in place."""
    original_cols = list(hourly_ts.columns)
    get_best_autoregessive_features(
        data=hourly_ts,
        target_series="target",
        periods=[1, 2],
        n_samples=24,
        top_k=2,
    )
    assert list(hourly_ts.columns) == original_cols


# ── get_best_temporal_features ────────────────────────────────────────────────


def test_temporal_returns_list(hourly_ts):
    """Returns a Python list."""
    result = get_best_temporal_features(
        data=hourly_ts,
        target_series="target",
        top_k=2,
    )
    assert isinstance(result, list)


def test_temporal_with_lat_lon(hourly_ts):
    """Day/night feature is added when lat/lon are provided."""
    result = get_best_temporal_features(
        data=hourly_ts,
        target_series="target",
        latitude=38.7,
        longitude=-9.1,
        top_k=3,
    )
    assert isinstance(result, list)


def test_temporal_without_lat_lon(hourly_ts):
    """No error when lat/lon are omitted (day/night skipped)."""
    result = get_best_temporal_features(
        data=hourly_ts,
        target_series="target",
        top_k=2,
    )
    assert isinstance(result, list)


def test_temporal_custom_date_col():
    """Custom date column name is handled correctly."""
    idx = pd.date_range("2021-06-01", periods=100, freq="h")
    rng = np.random.default_rng(7)
    df = pd.DataFrame({"dt": idx, "load": rng.uniform(50, 150, size=100)})
    result = get_best_temporal_features(
        data=df,
        target_series="load",
        date_col_name="dt",
        top_k=2,
    )
    assert isinstance(result, list)


# ── load_dataset ──────────────────────────────────────────────────────────────


def test_load_dataset_unsupported_raises(tmp_path):
    """Unsupported dataset name raises ValueError."""
    with pytest.raises(ValueError, match="Unsupported dataset"):
        load_dataset(dataset="NONEXISTENT", data_path=tmp_path)


@pytest.mark.parametrize(
    "dataset,parquet_file,target_col,exog_cols",
    [
        ("ALBANIA", "albania_res.parquet", "NetLoad", ["Humidity", "Temperature"]),
        ("PV-MLVS-UK", "MLVS-UK.parquet", "PV(MW)", ["Ghi"]),
        ("PV-UK", "hybrid_res.parquet", "PV(MW)", ["Ghi", "Temperature"]),
    ],
)
def test_load_dataset_known_datasets(tmp_path, dataset, parquet_file, target_col, exog_cols):
    """load_dataset returns correct 7-tuple for parquet-backed datasets."""
    idx = pd.date_range("2020-01-01", periods=200, freq="30min")
    rng = np.random.default_rng(1)
    cols = {"timestamp": idx, target_col: rng.uniform(0, 100, size=200)}
    for col in exog_cols:
        cols[col] = rng.uniform(0, 1, size=200)
    df = pd.DataFrame(cols)
    df.to_parquet(tmp_path / parquet_file, index=True)

    with (
        patch("twiga.utils.data_loading.get_best_autoregessive_features", return_value=["lag_1"]),
        patch("twiga.utils.data_loading.get_best_temporal_features", return_value=["hour_sin_1"]),
        patch("twiga.utils.data_loading.AutoregressTransformer") as mock_auto,
    ):
        mock_instance = MagicMock()
        mock_instance.fit_transform.return_value = df.copy()
        mock_auto.return_value = mock_instance

        result = load_dataset(dataset=dataset, data_path=tmp_path, top_k=1, periods=[1], n_samples=2)

    assert isinstance(result, tuple)
    assert len(result) == 7
    data_out, tgt, cal, exog, hist, lat, lon = result
    assert isinstance(data_out, pd.DataFrame)
    assert tgt == target_col
    assert isinstance(cal, list)
    assert isinstance(exog, list)
    assert isinstance(hist, list)
    assert isinstance(lat, float)
    assert isinstance(lon, float)


def test_load_dataset_etth1_missing_file(tmp_path):
    """ETTh1 raises FileNotFoundError when CSV is absent."""
    with pytest.raises(FileNotFoundError, match="not found"):
        load_dataset(dataset="ETTh1", data_path=tmp_path / "no_such_dir")


def test_load_dataset_etth1_with_csv(tmp_path):
    """ETTh1 loads when the expected CSV is present."""
    idx = pd.date_range("2016-07-01", periods=200, freq="h")
    rng = np.random.default_rng(3)
    cols_data = {
        "date": idx.strftime("%Y-%m-%d %H:%M:%S"),
        "OT": rng.uniform(1, 50, 200),  # codespell:ignore ot
        "HUFL": rng.uniform(0, 1, 200),
        "HULL": rng.uniform(0, 1, 200),
        "MUFL": rng.uniform(0, 1, 200),
        "MULL": rng.uniform(0, 1, 200),
        "LUFL": rng.uniform(0, 1, 200),
        "LULL": rng.uniform(0, 1, 200),
    }
    df = pd.DataFrame(cols_data)
    df.to_csv(tmp_path / "ETTh1.csv", index=False)

    with (
        patch("twiga.utils.data_loading.get_best_autoregessive_features", return_value=["lag_1"]),
        patch("twiga.utils.data_loading.get_best_temporal_features", return_value=["hour_sin_1"]),
        patch("twiga.utils.data_loading.AutoregressTransformer") as mock_auto,
    ):
        mock_instance = MagicMock()
        ts_df = pd.DataFrame(
            {
                "timestamp": pd.date_range("2016-07-01", periods=200, freq="h"),
                "OT": rng.uniform(1, 50, 200),  # codespell:ignore ot
                "HUFL": rng.uniform(0, 1, 200),
                "HULL": rng.uniform(0, 1, 200),
                "MUFL": rng.uniform(0, 1, 200),
                "MULL": rng.uniform(0, 1, 200),
                "LUFL": rng.uniform(0, 1, 200),
                "LULL": rng.uniform(0, 1, 200),
            }
        )
        mock_instance.fit_transform.return_value = ts_df
        mock_auto.return_value = mock_instance

        result = load_dataset(dataset="ETTh1", data_path=tmp_path, top_k=1, periods=[1], n_samples=2)

    assert len(result) == 7
    assert result[1] == "OT"  # codespell:ignore ot
