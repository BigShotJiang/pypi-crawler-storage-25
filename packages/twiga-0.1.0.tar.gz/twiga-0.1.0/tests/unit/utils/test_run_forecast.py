"""Unit tests for twiga.utils.run_forecast pipeline helpers."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

from twiga.utils.run_forecast import (
    PipelineConfig,
    _resolve_output_dirs,
    build_data_config,
    build_forecaster,
    build_forecaster_config,
    build_model_configs,
    save_metrics,
    save_predictions,
    setup_environment,
    split_data,
)

# ── PipelineConfig ─────────────────────────────────────────────────────────────


def test_pipeline_config_defaults():
    """PipelineConfig initialises with expected default values."""
    cfg = PipelineConfig()
    assert cfg.dataset_name == "MLVS-PT"
    assert cfg.forecast_horizon == 48
    assert cfg.input_window_size == 48
    assert cfg.period == "30min"
    assert cfg.epochs == 50
    assert cfg.train_val_split == 0.7
    assert cfg.num_trials == 10
    assert cfg.num_threads == 1
    assert cfg.metrics == ["rmse", "mae", "corr"]
    assert cfg.ensemble_strategy is None


def test_pipeline_config_override():
    """PipelineConfig accepts overrides at construction."""
    cfg = PipelineConfig(dataset_name="ALBANIA", forecast_horizon=24, epochs=5)
    assert cfg.dataset_name == "ALBANIA"
    assert cfg.forecast_horizon == 24
    assert cfg.epochs == 5


# ── _resolve_output_dirs ──────────────────────────────────────────────────────


def test_resolve_output_dirs_creates_subdirs(tmp_path):
    """All three sub-directories are created under the root."""
    dirs = _resolve_output_dirs(tmp_path / "results")
    assert dirs["plots"].is_dir()
    assert dirs["predictions"].is_dir()
    assert dirs["metrics"].is_dir()


def test_resolve_output_dirs_returns_paths(tmp_path):
    """Return value maps string keys to Path objects."""
    dirs = _resolve_output_dirs(tmp_path / "out")
    assert all(isinstance(p, Path) for p in dirs.values())
    assert set(dirs.keys()) == {"plots", "predictions", "metrics"}


def test_resolve_output_dirs_idempotent(tmp_path):
    """Calling twice on the same root does not raise."""
    _resolve_output_dirs(tmp_path / "out")
    _resolve_output_dirs(tmp_path / "out")  # should not raise
    assert (tmp_path / "out" / "plots").is_dir()


# ── setup_environment ─────────────────────────────────────────────────────────


def test_setup_environment_sets_threads():
    """OMP_NUM_THREADS is set to cfg.num_threads."""
    cfg = PipelineConfig(num_threads=4)
    setup_environment(cfg)
    assert os.environ.get("OMP_NUM_THREADS") == "4"


def test_setup_environment_default_threads():
    """Default num_threads=1 sets env variable to '1'."""
    cfg = PipelineConfig()
    setup_environment(cfg)
    assert os.environ.get("OMP_NUM_THREADS") == "1"


# ── build_data_config ─────────────────────────────────────────────────────────


def test_build_data_config_returns_config():
    """Returns a DataPipelineConfig with correct field values."""
    from twiga.core.config import DataPipelineConfig

    cfg = PipelineConfig(forecast_horizon=24, input_window_size=96, period="1h")
    result = build_data_config(
        cfg,
        target_series="load",
        lags=["lag_1"],
        calendar_variables=["hour"],
        exogenous_features=["temp"],
        latitude=38.7,
        longitude=-9.1,
    )
    assert isinstance(result, DataPipelineConfig)
    assert result.forecast_horizon == 24
    assert result.lookback_window_size == 96
    assert result.period == "1h"
    assert result.target_feature == "load"


def test_build_data_config_scalers_are_fresh():
    """Two calls produce independent scaler instances (no shared state)."""
    from sklearn.preprocessing import MinMaxScaler, StandardScaler

    cfg = PipelineConfig()
    a = build_data_config(cfg, "y", [], [], [], 0.0, 0.0)
    b = build_data_config(cfg, "y", [], [], [], 0.0, 0.0)
    assert a.input_scaler is not b.input_scaler
    assert a.target_scaler is not b.target_scaler


# ── build_model_configs ───────────────────────────────────────────────────────


def test_build_model_configs_returns_list():
    """Returns a non-empty list of model configs."""
    cfg = PipelineConfig(epochs=5, out_activation="Identity")
    result = build_model_configs(cfg)
    assert isinstance(result, list)
    assert len(result) > 0


def test_build_model_configs_types():
    """All returned items are model config objects (have a name attribute)."""
    from twiga.models.nn.mlpf_model import MLPFConfig
    from twiga.models.nn.mlpgaf_model import MLPGAFConfig
    from twiga.models.nn.mlpgam_model import MLPGAMConfig

    cfg = PipelineConfig(epochs=2)
    configs = build_model_configs(cfg)
    types = {type(c) for c in configs}
    assert MLPFConfig in types
    assert MLPGAMConfig in types
    assert MLPGAFConfig in types


def test_build_model_configs_max_epochs_propagated():
    """Epoch count from PipelineConfig propagates to model configs."""
    cfg = PipelineConfig(epochs=7)
    for model_cfg in build_model_configs(cfg):
        assert model_cfg.max_epochs == 7


# ── build_forecaster_config ───────────────────────────────────────────────────


def test_build_forecaster_config_returns_config():
    """Returns a ForecasterConfig with correct fields."""
    from twiga.core.config import ForecasterConfig

    cfg = PipelineConfig(split_freq="months", cv_train_size=4, cv_test_size=2)
    result = build_forecaster_config(cfg)
    assert isinstance(result, ForecasterConfig)
    assert result.split_freq == "months"
    assert result.train_size == 4
    assert result.test_size == 2


def test_build_forecaster_config_project_name_fallback():
    """project_name falls back to dataset_name when not set."""
    cfg = PipelineConfig(dataset_name="ALBANIA", project_name=None)
    result = build_forecaster_config(cfg)
    assert result.project_name == "ALBANIA"


def test_build_forecaster_config_explicit_project_name():
    """Explicit project_name overrides dataset_name."""
    cfg = PipelineConfig(dataset_name="ALBANIA", project_name="MyProject")
    result = build_forecaster_config(cfg)
    assert result.project_name == "MyProject"


# ── split_data ────────────────────────────────────────────────────────────────


@pytest.fixture
def time_series_df() -> pd.DataFrame:
    idx = pd.date_range("2019-01-01", periods=365 * 48, freq="30min")
    return pd.DataFrame({"timestamp": idx, "load": range(len(idx))})


def test_split_data_returns_two_frames(time_series_df):
    """Returns a 2-tuple of DataFrames."""
    cfg = PipelineConfig(
        train_start="2019-01",
        train_end="2019-06",
        test_start="2019-07",
        test_end="2019-09",
    )
    train, test = split_data(time_series_df, cfg)
    assert isinstance(train, pd.DataFrame)
    assert isinstance(test, pd.DataFrame)


def test_split_data_no_overlap(time_series_df):
    """Train and test windows do not overlap."""
    cfg = PipelineConfig(
        train_start="2019-01",
        train_end="2019-06",
        test_start="2019-07",
        test_end="2019-09",
    )
    train, test = split_data(time_series_df, cfg)
    if len(train) > 0 and len(test) > 0:
        assert train["timestamp"].max() < test["timestamp"].min()


def test_split_data_sizes(time_series_df):
    """Both splits are non-empty for a reasonable date range."""
    cfg = PipelineConfig(
        train_start="2019-01",
        train_end="2019-03",
        test_start="2019-04",
        test_end="2019-06",
    )
    train, test = split_data(time_series_df, cfg)
    assert len(train) > 0
    assert len(test) > 0


# ── build_forecaster ─────────────────────────────────────────────────────────


def test_build_forecaster_returns_twiga_forecaster():
    """build_forecaster returns a TwigaForecaster instance."""
    from twiga.forecaster.core import TwigaForecaster

    cfg = PipelineConfig(epochs=1)
    data_cfg = build_data_config(cfg, "load", [], [], [], 0.0, 0.0)
    model_cfgs = build_model_configs(cfg)
    forecaster_cfg = build_forecaster_config(cfg)

    forecaster = build_forecaster(data_cfg, model_cfgs, forecaster_cfg)
    assert isinstance(forecaster, TwigaForecaster)


# ── save_predictions / save_metrics ──────────────────────────────────────────


@pytest.fixture
def output_dirs(tmp_path) -> dict[str, Path]:
    dirs = {
        "plots": tmp_path / "plots",
        "predictions": tmp_path / "predictions",
        "metrics": tmp_path / "metrics",
    }
    for d in dirs.values():
        d.mkdir(parents=True)
    return dirs


@pytest.fixture
def mock_pred() -> pd.DataFrame:
    return pd.DataFrame({"timestamp": pd.date_range("2020-01-01", periods=5, freq="h"), "forecast": range(5)})


@pytest.fixture
def mock_metric() -> pd.DataFrame:
    return pd.DataFrame({"Model": ["A", "B"], "mae": [0.1, 0.2]})


def test_save_predictions_creates_file(output_dirs, mock_pred):
    """CSV file is created in the predictions directory."""
    cfg = PipelineConfig(dataset_name="TEST", test_start="2020-01", test_end="2020-03")
    path = save_predictions(mock_pred, output_dirs, cfg)
    assert path.exists()
    assert path.suffix == ".csv"
    assert "TEST" in path.name


def test_save_predictions_filename(output_dirs, mock_pred):
    """Filename encodes dataset name and test window."""
    cfg = PipelineConfig(dataset_name="DS", test_start="2020-01", test_end="2020-06")
    path = save_predictions(mock_pred, output_dirs, cfg)
    assert "DS" in path.name
    assert "2020-01" in path.name
    assert "2020-06" in path.name


def test_save_metrics_creates_file(output_dirs, mock_metric):
    """CSV file is created in the metrics directory."""
    cfg = PipelineConfig(dataset_name="TEST", test_start="2020-01", test_end="2020-03")
    path = save_metrics(mock_metric, output_dirs, cfg)
    assert path.exists()
    assert path.suffix == ".csv"


def test_save_metrics_content(output_dirs, mock_metric):
    """Saved CSV contains the expected columns."""
    cfg = PipelineConfig(dataset_name="DS", test_start="2020-01", test_end="2020-03")
    path = save_metrics(mock_metric, output_dirs, cfg)
    loaded = pd.read_csv(path)
    assert "Model" in loaded.columns
    assert "mae" in loaded.columns
