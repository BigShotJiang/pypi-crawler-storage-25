import numpy as np
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.net.nhits import (
    NHITS,
    NHITSBlock,
    NHITSNetwork,
    _IdentityBasis,
    create_stack,
)


# Test components
def test_identity_basis_initialization():
    """Test initialization of _IdentityBasis class.

    Verifies that the forecast_size and backcast_size attributes are set correctly.
    """
    basis = _IdentityBasis(
        backcast_size=10,
        forecast_size=5,
        interpolation_mode="linear",
        out_features=1,
    )
    assert basis.forecast_size == 5
    assert basis.backcast_size == 10


def test_identity_basis_invalid_interpolation():
    """Test _IdentityBasis with invalid interpolation mode.

    Ensures ValueError is raised for an invalid interpolation mode.
    """
    with pytest.raises(ValueError):
        _IdentityBasis(10, 5, "invalid_mode")


def test_identity_basis_forward_shapes():
    """Test forward pass shape of _IdentityBasis.

    Verifies that the backcast and forecast outputs have the expected shapes.
    """
    basis = _IdentityBasis(10, 5, "linear")
    theta = torch.randn(32, 15)  # 10 (backcast) + 5 (forecast knots)
    backcast, forecast = basis(theta)
    assert backcast.shape == (32, 10)
    assert forecast.shape == (32, 5)


def test_identity_basis_cubic_interpolation_error():
    """Test cubic interpolation error in _IdentityBasis.

    Ensures ValueError is raised for invalid theta size in cubic interpolation.
    """
    basis = _IdentityBasis(backcast_size=10, forecast_size=6, interpolation_mode="cubic", out_features=2)
    theta = torch.randn(32, 16)  # 10 + 6 = 16
    with pytest.raises(ValueError):
        basis(theta)


@pytest.fixture
def nhits_block_args():
    """Fixture for NHITSBlock arguments.

    Returns:
        dict: Configuration parameters for NHITSBlock.
    """
    return {
        "input_size": 24,
        "h": 12,
        "n_theta": 36,
        "mlp_units": [[64, 64], [64, 64]],
        "basis": _IdentityBasis(24, 12, "linear"),
        "futr_input_size": 3,
        "hist_input_size": 2,
        "stat_input_size": 1,
        "n_pool_kernel_size": 2,
        "pooling_mode": "MaxPool1d",
        "dropout_prob": 0.1,
        "activation": "ReLU",
    }


def test_nhits_block_initialization(nhits_block_args):
    """Test initialization of NHITSBlock.

    Verifies that the block has the expected number of layers.
    """
    block = NHITSBlock(**nhits_block_args)
    assert len(block.layers) == 8  # Initial + 2*(Linear + ReLU + Dropout) + Output


def test_nhits_block_invalid_activation(nhits_block_args):
    """Test NHITSBlock with invalid activation function.

    Ensures ValueError is raised for an invalid activation.
    """
    nhits_block_args["activation"] = "InvalidActivation"
    with pytest.raises(ValueError):
        NHITSBlock(**nhits_block_args)


def test_nhits_block_forward(nhits_block_args):
    """Test forward pass of NHITSBlock.

    Verifies that the backcast and forecast outputs have the expected shapes.
    """
    block = NHITSBlock(**nhits_block_args)
    insample_y = torch.randn(32, 24)
    futr_exog = torch.randn(32, 36, 3)  # input_size + h
    hist_exog = torch.randn(32, 24, 2)
    stat_exog = torch.randn(32, 1)
    backcast, forecast = block(insample_y, futr_exog, hist_exog, stat_exog)
    assert backcast.shape == (32, 24)
    assert forecast.shape == (32, 12)


@pytest.fixture
def nhits_network_args():
    """Fixture for NHITSNetwork arguments.

    Returns:
        dict: Configuration parameters for NHITSNetwork.
    """
    return {
        "num_target_feature": 1,
        "num_historical_features": 1,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 0,
        "forecast_horizon": 12,
        "lookback_window_size": 24,
        "activation_function": "ReLU",
        "stack_types": ["identity", "identity", "identity"],
        "n_blocks": [1, 1, 1],
        "decompose_forecast": False,
    }


@pytest.fixture
def sample_input(nhits_network_args):
    """Fixture for sample input to NHITSNetwork.

    Args:
        nhits_network_args (dict): NHITSNetwork configuration.

    Returns:
        torch.Tensor: Stacked input features for testing.
    """
    batch_size = 4
    past_features = (
        nhits_network_args["num_target_feature"]
        + nhits_network_args["num_historical_features"]
        + nhits_network_args["num_calendar_features"]
        + nhits_network_args["num_exogenous_features"]
    )
    future_features = (
        nhits_network_args["num_future_covariates"]
        + nhits_network_args["num_calendar_features"]
        + nhits_network_args["num_exogenous_features"]
    )
    features = np.ones((batch_size, nhits_network_args["lookback_window_size"], past_features))
    covariates = 2 * np.ones((batch_size, nhits_network_args["forecast_horizon"], future_features))
    features = stack_features(past_features=features, future_covariates=covariates)
    return torch.from_numpy(features).float()


def test_nhits_network_initialization(nhits_network_args):
    """Test initialization of NHITSNetwork.

    Verifies that the network has the expected number of blocks and forecast horizon.
    """
    model = NHITSNetwork(**nhits_network_args)
    assert len(model.blocks) == 3
    assert model.forecast_horizon == 12


def test_nhits_network_forward(nhits_network_args, sample_input):
    """Test forward pass of NHITSNetwork.

    Verifies that the output has the expected shape.
    """
    model = NHITSNetwork(**nhits_network_args)
    output = model(sample_input)
    assert output.shape == (
        sample_input.size(0),
        nhits_network_args["forecast_horizon"],
        nhits_network_args["num_target_feature"],
    )


def test_prepare_input_historical_features(nhits_network_args, sample_input):
    """Test _prepare_input method of NHITSNetwork.

    Verifies that the input shapes for insample_y, hist_exog, and futr_exog are correct.
    """
    model = NHITSNetwork(**nhits_network_args)
    insample_y, hist_exog, futr_exog = model._prepare_input(sample_input)
    assert insample_y.shape == (sample_input.size(0), 24)
    assert hist_exog.shape == (sample_input.size(0), 24, 1)
    assert futr_exog.shape == (sample_input.size(0), 36, 3)


def test_nhits_model_initialization(nhits_network_args):
    """Test initialization of NHITS.

    Verifies that the model is initialized correctly.
    """
    model = NHITS(**nhits_network_args)
    assert isinstance(model, NHITS)
    assert isinstance(model.model, NHITSNetwork)


@pytest.mark.parametrize("decompose_forecast", [True, False])
def test_nhits_decompose_forecast(decompose_forecast, nhits_network_args, sample_input):
    """Test NHITSNetwork with decompose_forecast option.

    Args:
        decompose_forecast (bool): Whether to decompose the forecast.
        nhits_network_args (dict): NHITSNetwork configuration.
        sample_input (torch.Tensor): Sample input tensor.

    Verifies that the output shape matches the decompose_forecast setting.
    """
    nhits_network_args["decompose_forecast"] = decompose_forecast
    model = NHITSNetwork(**nhits_network_args)
    output = model(sample_input)
    if decompose_forecast:
        assert output.shape == (
            sample_input.size(0),
            4,
            nhits_network_args["forecast_horizon"],
            nhits_network_args["num_target_feature"],
        )
    else:
        assert output.shape == (
            sample_input.size(0),
            nhits_network_args["forecast_horizon"],
            nhits_network_args["num_target_feature"],
        )


def test_create_stack_valid():
    """Test create_stack function with valid inputs.

    Verifies that the correct number of blocks is created.
    """
    blocks = create_stack(
        h=12,
        input_size=24,
        stack_types=["identity", "identity"],
        n_blocks=[1, 2],
        mlp_units=[[64, 64]],
        n_pool_kernel_size=[2, 2],
        n_freq_downsample=[4, 2],
        pooling_mode="MaxPool1d",
        interpolation_mode="linear",
        dropout_prob_theta=0.1,
        activation="ReLU",
        futr_input_size=3,
        hist_input_size=2,
        stat_input_size=1,
        n_out_size=1,
    )
    assert len(blocks) == 3  # 1 + 2 blocks


def test_create_stack_invalid_type():
    """Test create_stack with invalid stack type.

    Ensures ValueError is raised for an invalid stack type.
    """
    with pytest.raises(ValueError):
        create_stack(
            h=12,
            input_size=24,
            stack_types=["invalid"],
            n_blocks=[1],
            mlp_units=[[64, 64]],
            n_pool_kernel_size=[2],
            n_freq_downsample=[4],
            pooling_mode="MaxPool1d",
            interpolation_mode="linear",
            dropout_prob_theta=0.1,
            activation="ReLU",
            futr_input_size=3,
            hist_input_size=2,
            stat_input_size=1,
            n_out_size=1,
        )


def test_nhits_exogenous_validation():
    """Test NHITSNetwork with invalid exogenous features.

    Ensures ValueError is raised when no exogenous features are provided.
    """
    with pytest.raises(ValueError):
        NHITSNetwork(
            num_target_feature=1,
            num_historical_features=0,
            num_calendar_features=0,
            num_exogenous_features=0,
            num_future_covariates=0,
            forecast_horizon=12,
            lookback_window_size=24,
        )


def test_cubic_interpolation_error():
    """Test cubic interpolation error in _IdentityBasis.

    Ensures ValueError is raised for invalid theta size in cubic interpolation.
    """
    basis = _IdentityBasis(10, 6, "cubic", out_features=2)
    theta = torch.randn(32, 16)  # backcast(10) + knots(6)
    with pytest.raises(ValueError):
        basis(theta)


# ── NHITSNetwork.encode() Tests ───────────────────────────────────────────────


def test_encode_output_shape(nhits_network_args, sample_input):
    """encode() returns a (B, encode_size) tensor."""
    encode_size = 128
    model = NHITSNetwork(**nhits_network_args, encode_size=encode_size)
    z = model.encode(sample_input)
    assert z.shape == (sample_input.size(0), encode_size)


def test_encode_size_property(nhits_network_args):
    """encode_size property matches the constructor argument."""
    model = NHITSNetwork(**nhits_network_args, encode_size=64)
    assert model.encode_size == 64


def test_encode_no_nan(nhits_network_args, sample_input):
    """encode() output contains no NaN values."""
    model = NHITSNetwork(**nhits_network_args, encode_size=128)
    z = model.encode(sample_input)
    assert not torch.isnan(z).any()


def test_encode_default_size(nhits_network_args, sample_input):
    """encode() uses default encode_size=256 when not specified."""
    model = NHITSNetwork(**nhits_network_args)
    z = model.encode(sample_input)
    assert z.shape == (sample_input.size(0), 256)
