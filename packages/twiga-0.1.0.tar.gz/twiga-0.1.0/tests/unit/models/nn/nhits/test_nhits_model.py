from unittest.mock import MagicMock

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.nhits_model import NHITS, NHITSConfig, NHITSModel


# Test Configuration Fixtures
@pytest.fixture
def valid_data_config():
    return MagicMock(
        target_feature=["target"],
        historical_features=["hist1", "hist2"],
        calendar_features=["hour", "day"],
        exogenous_features=["exog1"],
        future_covariates=["covar1"],
        forecast_horizon=24,
        lookback_window_size=168,
    )


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 0,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "hidden_size": 256,
        "num_layers": 2,
        "activation_function": "SiLU",
        "max_epochs": 10,
    }


# MLPGAMConfig Tests
def test_mlpgamconfig_initialization(base_config):
    """Test valid MLPGAMConfig initialization."""
    config = NHITSConfig(**base_config)

    assert config.name == "nhits"
    assert config.domain == "nn"
    assert config.hidden_size == 256
    assert config.search_space is not None


def test_mlpgamconfig_from_data_config(valid_data_config):
    """Test config creation from data pipeline config."""
    config = NHITSConfig.from_data_config(valid_data_config)

    assert config.num_target_feature == 1
    assert config.num_historical_features == 2
    assert config.forecast_horizon == 24
    assert config.lookback_window_size == 168


def test_invalid_activation_function():
    """Test validation of activation functions."""
    with pytest.raises(ValidationError) as excinfo:
        NHITSConfig(
            num_target_feature=1,
            num_historical_features=2,
            forecast_horizon=24,
            lookback_window_size=168,
            activation_function="InvalidActivation",
        )
    assert "activation_function" in str(excinfo.value)


@pytest.fixture
def sample_input(base_config):
    batch_size = 32
    past_features = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future_features = (
        base_config["num_future_covariates"]
        + +base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )

    features = np.ones((batch_size, base_config["lookback_window_size"], past_features))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future_features))

    features = stack_features(past_features=features, future_covariates=covariates)

    return torch.from_numpy(features).float()


def test_mlpfmodel_initialization(base_config):
    """Test model initialization with valid config."""
    config = NHITSConfig(**base_config)
    model = NHITSModel(config)

    assert isinstance(model.model, NHITS)
    assert model.model_config == config


def test_forward_pass_shape(base_config, sample_input):
    """Test model forward pass dimensions."""
    config = NHITSConfig(**base_config)
    model = NHITSModel(config)

    output = model.model(sample_input)
    assert output.shape == (sample_input.size(0), base_config["forecast_horizon"], base_config["num_target_feature"])


# Integration Tests
def test_config_model_integration(valid_data_config):
    """Test end-to-end config and model integration."""
    config = NHITSConfig.from_data_config(valid_data_config)
    model = NHITSModel(config)

    assert model.model_config.num_historical_features == 2
    assert model.model_config.num_calendar_features == 2
    assert isinstance(model.model, NHITS)


# Error Handling Tests
def test_dim_fields_default_to_zero():
    """Dim fields default to 0 so TwigaForecaster can auto-populate them."""
    cfg = NHITSConfig()
    assert cfg.num_target_feature == 0
    assert cfg.forecast_horizon == 0
    assert cfg.lookback_window_size == 0


def test_dim_fields_explicit_values():
    """Explicitly set dim fields are accepted and preserved."""
    cfg = NHITSConfig(num_target_feature=2, forecast_horizon=48, lookback_window_size=96)
    assert cfg.num_target_feature == 2
    assert cfg.forecast_horizon == 48
    assert cfg.lookback_window_size == 96


# Device Compatibility Tests
@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_gpu_compatibility(base_config, sample_input):
    """Test model operation on GPU."""
    config = NHITSConfig(**base_config)
    model = NHITSModel(config).cuda()

    output = model.model(sample_input.cuda())
    assert output.device.type == "cuda"
