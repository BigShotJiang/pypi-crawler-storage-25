"""Unit tests for NHITSCrcConfig and NHITSCrcModel.

Network under test: NHITSCrc (NHITSNetwork + CRCDistribution).
Config under test:  NHITSCrcConfig (extends NHITSConfig).

NHiTS uses the standard CRCDistribution (not additive) — the latent is
projected through a mu_layer, matching the MLPFCRC pattern.
"""

from __future__ import annotations

from unittest.mock import patch

import numpy as np
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.distributions.nn.residual_conformal import CRCDistribution
from twiga.models.nn.nhitscrc_model import NHITSCrcConfig, NHITSCrcModel
from twiga.models.nn.prob.nhits_crc import NHITSCrc

# ── Fixtures ───────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 0,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "encode_size": 64,
        "max_epochs": 5,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 8
    past = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    features = np.ones((batch_size, base_config["lookback_window_size"], past))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future))
    return torch.from_numpy(stack_features(past_features=features, future_covariates=covariates)).float()


# ── Config Tests ───────────────────────────────────────────────────────────────


def test_config_name(base_config):
    config = NHITSCrcConfig(**base_config)
    assert config.name == "nhitscrc"


def test_config_search_space_present(base_config):
    config = NHITSCrcConfig(**base_config)
    assert config.search_space is not None


def test_config_dim_fields_default_to_zero():
    """Dim fields default to 0 so TwigaForecaster can auto-populate them."""
    cfg = NHITSCrcConfig()
    assert cfg.num_target_feature == 0
    assert cfg.forecast_horizon == 0
    assert cfg.lookback_window_size == 0


def test_config_dim_fields_explicit_values():
    """Explicitly set dim fields are accepted and preserved."""
    cfg = NHITSCrcConfig(num_target_feature=2, forecast_horizon=48, lookback_window_size=96)
    assert cfg.num_target_feature == 2
    assert cfg.forecast_horizon == 48
    assert cfg.lookback_window_size == 96


def test_config_inherits_nhits_params(base_config):
    """Stack types and pooling fields from NHITSConfig are accessible."""
    config = NHITSCrcConfig(**base_config)
    assert config.stack_types is not None
    assert config.pooling_mode is not None


# ── Model Initialization Tests ─────────────────────────────────────────────────


def test_model_initialization(base_config):
    config = NHITSCrcConfig(**base_config)
    model = NHITSCrcModel(model_config=config)
    assert isinstance(model.model, NHITSCrc)
    assert model.model_config == config


def test_model_uses_standard_crc_head(base_config):
    """NHiTS uses CRCDistribution (has mu_layer — backbone is not additive)."""
    config = NHITSCrcConfig(**base_config)
    model = NHITSCrcModel(model_config=config)
    head = model.model.model.head
    assert isinstance(head, CRCDistribution)
    assert hasattr(head, "mu_layer"), "Standard CRC must have mu_layer"


# ── Forward Shape Tests ────────────────────────────────────────────────────────


def test_forward_output_shapes(base_config, sample_input):
    config = NHITSCrcConfig(**base_config)
    model = NHITSCrcModel(model_config=config)
    model.model.eval()
    with torch.no_grad():
        mu, sigma = model.model(sample_input)
    batch = sample_input.size(0)
    horizon = base_config["forecast_horizon"]
    n_out = base_config["num_target_feature"]
    assert mu.shape == (batch, horizon, n_out)
    assert sigma.shape == (batch, horizon, n_out)


def test_sigma_positive(base_config, sample_input):
    config = NHITSCrcConfig(**base_config)
    model = NHITSCrcModel(model_config=config)
    model.model.eval()
    with torch.no_grad():
        _, sigma = model.model(sample_input)
    assert (sigma > 0).all()


def test_no_nan_in_output(base_config, sample_input):
    config = NHITSCrcConfig(**base_config)
    model = NHITSCrcModel(model_config=config)
    model.model.eval()
    with torch.no_grad():
        mu, sigma = model.model(sample_input)
    assert not torch.isnan(mu).any()
    assert not torch.isnan(sigma).any()


# ── Lifecycle Tests ────────────────────────────────────────────────────────────


def test_update_reinitialises_model(base_config):
    config = NHITSCrcConfig(**base_config)
    model = NHITSCrcModel(model_config=config)
    import optuna

    study = optuna.create_study(direction="minimize")
    trial = study.ask()

    with patch.object(NHITSCrcConfig, "get_optuna_params", return_value=base_config):
        model.update(trial)

    assert isinstance(model.model_config, NHITSCrcConfig)
    assert isinstance(model.model, NHITSCrc)


def test_load_checkpoint_calls_load(base_config):
    config = NHITSCrcConfig(**base_config)
    model = NHITSCrcModel(model_config=config)
    with patch.object(model, "_load_checkpoints") as mock_load:
        model.load_checkpoint()
        mock_load.assert_called_once_with(model_instance=NHITSCrc)


def test_load_checkpoint_sets_eval_mode(base_config):
    config = NHITSCrcConfig(**base_config)
    model = NHITSCrcModel(model_config=config)
    with patch.object(model, "_load_checkpoints"):
        model.load_checkpoint()
    assert not model.model.training


# ── Registry Test ──────────────────────────────────────────────────────────────


def test_registry_resolves_nhitscrc():
    from twiga.forecaster.registry import get_model

    model_cls, config_cls = get_model("nhitscrc", domain="nn")
    assert model_cls is NHITSCrcModel
    assert config_cls is NHITSCrcConfig
