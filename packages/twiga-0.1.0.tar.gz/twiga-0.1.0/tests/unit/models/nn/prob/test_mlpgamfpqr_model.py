"""Unit tests for MLPGAMFPQRConfig and MLPGAMFPQRModel.

Network under test: MLPGAMFPQR (MLPGAMNetwork + FPQRDistribution).
Config under test:  MLPGAMFPQRConfig (extends MLPGAMConfig).

Pattern follows test_mlpffpqr_model.py.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.mlpgamfpqr_model import MLPGAMFPQRConfig, MLPGAMFPQRModel
from twiga.models.nn.prob.mlpgamfpqr import MLPGAMFPQR

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 64,
        "hidden_dim": 64,
        "num_layers": 1,
        "dropout": 0.0,
        "max_epochs": 5,
        # ── FPQR-specific ──────────────────────────────────────────────────
        "n_quantiles": 9,
        "conf_level": 0.05,
        "loss_fn": "pinball",
        "kappa": 0.25,
        "num_cosines": 32,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 16
    past = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    features = np.ones((batch_size, base_config["lookback_window_size"], past))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future))
    return torch.from_numpy(stack_features(past_features=features, future_covariates=covariates)).float()


# ── MLPGAMFPQRConfig ──────────────────────────────────────────────────────────


def test_config_initialization(base_config):
    config = MLPGAMFPQRConfig(**base_config)
    assert config.name == "mlpgamfpqr"
    assert config.n_quantiles == 9
    assert config.conf_level == 0.05
    assert config.loss_fn == "pinball"
    assert config.kappa == 0.25
    assert config.num_cosines == 32
    assert config.lambda_lasso == 1e-6
    assert config.search_space is not None


def test_config_no_quantiles_field():
    config = MLPGAMFPQRConfig(
        num_target_feature=1,
        forecast_horizon=24,
        lookback_window_size=96,
    )
    assert not hasattr(config, "quantiles")
    assert not hasattr(config, "eps")
    assert hasattr(config, "n_quantiles")
    assert hasattr(config, "num_cosines")


def test_config_invalid_loss_fn():
    with pytest.raises(ValidationError) as exc:
        MLPGAMFPQRConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            loss_fn="bad_fn",
        )
    assert "loss_fn" in str(exc.value)


def test_config_invalid_activation():
    with pytest.raises(ValidationError) as exc:
        MLPGAMFPQRConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            activation_function="BadAct",
        )
    assert "activation_function" in str(exc.value)


def test_config_missing_required_field():
    """Omitting NN dimension fields defaults to 0 (sentinel for TwigaForecaster auto-fill)."""
    config = MLPGAMFPQRConfig(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0


def test_config_search_space_has_fpqr_keys():
    config = MLPGAMFPQRConfig(num_target_feature=1, forecast_horizon=24, lookback_window_size=96)
    for key in ("n_quantiles", "kappa", "loss_fn", "num_cosines", "lambda_lasso"):
        assert hasattr(config.search_space, key), f"Missing search_space key: '{key}'"


# ── MLPGAMFPQRModel ───────────────────────────────────────────────────────────


def test_model_initialization(base_config):
    config = MLPGAMFPQRConfig(**base_config)
    model = MLPGAMFPQRModel(model_config=config)
    assert isinstance(model.model, MLPGAMFPQR)
    assert model.model_config == config


@pytest.mark.parametrize("n_quantiles", [7, 9, 15, 21])
def test_n_quantiles_variants(n_quantiles, base_config):
    base_config["n_quantiles"] = n_quantiles
    config = MLPGAMFPQRConfig(**base_config)
    model = MLPGAMFPQRModel(model_config=config)
    assert model.model_config.n_quantiles == n_quantiles


@pytest.mark.parametrize("num_cosines", [16, 32, 64])
def test_num_cosines_variants(num_cosines, base_config):
    base_config["num_cosines"] = num_cosines
    config = MLPGAMFPQRConfig(**base_config)
    model = MLPGAMFPQRModel(model_config=config)
    assert model.model_config.num_cosines == num_cosines


@pytest.mark.parametrize("loss_fn", ["pinball", "huber-pinball"])
def test_loss_fn_variants(loss_fn, base_config):
    base_config["loss_fn"] = loss_fn
    config = MLPGAMFPQRConfig(**base_config)
    model = MLPGAMFPQRModel(model_config=config)
    assert model.model_config.loss_fn == loss_fn


@pytest.mark.parametrize("lambda_lasso", [0.0, 1e-6, 1e-4])
def test_lambda_lasso_variants(lambda_lasso, base_config, sample_input):
    base_config["lambda_lasso"] = lambda_lasso
    config = MLPGAMFPQRConfig(**base_config)
    model = MLPGAMFPQRModel(model_config=config)
    output = model.model(sample_input)
    loc, quantiles, tau_hats = output["loc"], output["quantiles"], output["quantile_levels"]
    assert not torch.isnan(loc).any()
    assert not torch.isnan(quantiles).any()
    assert not np.any(np.isnan(tau_hats))


def test_forward_output_shapes(base_config, sample_input):
    config = MLPGAMFPQRConfig(**base_config)
    model = MLPGAMFPQRModel(model_config=config)

    output = model.model(sample_input)
    loc = output["loc"]
    quantiles = output["quantiles"]
    tau_hats = output["quantile_levels"]

    batch_size = sample_input.size(0)
    horizon = base_config["forecast_horizon"]
    num_targets = base_config["num_target_feature"]
    num_quantiles = base_config["n_quantiles"]

    assert loc.shape == (batch_size, horizon, num_targets), (
        f"loc: expected {(batch_size, horizon, num_targets)}, got {loc.shape}"
    )
    assert quantiles.shape == (batch_size, num_quantiles, horizon, num_targets), (
        f"quantiles: expected {(batch_size, num_quantiles, horizon, num_targets)}, got {quantiles.shape}"
    )
    # quantile_levels is a 3-D ndarray (batch, n_quantiles, horizon) — per-sample per-step taus
    assert tau_hats.shape == (batch_size, num_quantiles, horizon), (
        f"quantile_levels: expected ({batch_size}, {num_quantiles}, {horizon}), got {tau_hats.shape}"
    )


def test_forward_no_nan(base_config, sample_input):
    config = MLPGAMFPQRConfig(**base_config)
    model = MLPGAMFPQRModel(model_config=config)
    output = model.model(sample_input)
    loc, quantiles, tau_hats = output["loc"], output["quantiles"], output["quantile_levels"]
    assert not torch.isnan(loc).any()
    assert not torch.isnan(quantiles).any()
    assert not np.any(np.isnan(tau_hats))


# ── Device compatibility ──────────────────────────────────────────────────────


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_gpu_compatibility(base_config, sample_input):
    config = MLPGAMFPQRConfig(**base_config)
    model = MLPGAMFPQRModel(model_config=config)
    model.model.cuda()
    loc, quantiles, tau_hats = model.model(sample_input.cuda())
    assert loc.device.type == "cuda"
    assert quantiles.device.type == "cuda"
    assert tau_hats.device.type == "cuda"


def test_update_reinitialises_model(base_config):
    """update() calls get_optuna_params and rebuilds the model."""
    config = MLPGAMFPQRConfig(**base_config)
    model = MLPGAMFPQRModel(model_config=config)
    mock_trial = MagicMock()

    with patch.object(MLPGAMFPQRConfig, "get_optuna_params", return_value=base_config):
        model.update(mock_trial)

    assert isinstance(model.model_config, MLPGAMFPQRConfig)
    assert isinstance(model.model, MLPGAMFPQR)


def test_load_checkpoint_sets_eval_mode(base_config):
    """load_checkpoint() delegates to _load_checkpoints and sets model to eval."""
    config = MLPGAMFPQRConfig(**base_config)
    model = MLPGAMFPQRModel(model_config=config)

    with patch.object(MLPGAMFPQRModel, "_load_checkpoints"):
        model.load_checkpoint()

    assert not model.model.training
