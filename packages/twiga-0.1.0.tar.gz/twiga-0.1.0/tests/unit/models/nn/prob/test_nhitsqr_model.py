"""Unit tests for NHITSQRConfig, NHITSQRModel, NHITSFPQRConfig, NHITSFPQRModel."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.nhitsqr_model import NHITSFPQRConfig, NHITSFPQRModel, NHITSQRConfig, NHITSQRModel
from twiga.models.nn.prob.nhitsfpqr import NHITSFPQR
from twiga.models.nn.prob.nhitsqr import NHITSQR

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 0,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "encode_size": 64,
        "max_epochs": 5,
        "quantiles": [0.1, 0.5, 0.9],
        "conf_level": 0.05,
        "loss_fn": "pinball",
        "kappa": 0.25,
        "eps": 1e-6,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 8
    past = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    features = np.ones((batch_size, base_config["lookback_window_size"], past))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future))
    return torch.from_numpy(stack_features(past_features=features, future_covariates=covariates)).float()


# ── NHITSQRConfig Tests ───────────────────────────────────────────────────────


def test_nhitsqr_config_initialization(base_config):
    config = NHITSQRConfig(**base_config)
    assert config.name == "nhitsqr"
    assert config.quantiles == [0.1, 0.5, 0.9]
    assert config.loss_fn == "pinball"
    assert config.search_space is not None


def test_nhitsqr_config_default_quantiles():
    config = NHITSQRConfig(num_target_feature=1, forecast_horizon=24, lookback_window_size=96)
    assert config.quantiles is None


def test_nhitsqr_config_invalid_loss_fn():
    with pytest.raises(ValidationError) as exc:
        NHITSQRConfig(num_target_feature=1, forecast_horizon=24, lookback_window_size=96, loss_fn="bad")
    assert "loss_fn" in str(exc.value)


def test_nhitsqr_config_dim_fields_default_to_zero():
    """Dim fields default to 0 so TwigaForecaster can auto-populate them."""
    cfg = NHITSQRConfig()
    assert cfg.num_target_feature == 0
    assert cfg.forecast_horizon == 0
    assert cfg.lookback_window_size == 0


def test_nhitsqr_config_dim_fields_explicit_values():
    """Explicitly set dim fields are accepted and preserved."""
    cfg = NHITSQRConfig(num_target_feature=2, forecast_horizon=48, lookback_window_size=96)
    assert cfg.num_target_feature == 2
    assert cfg.forecast_horizon == 48
    assert cfg.lookback_window_size == 96


# ── NHITSQRModel Tests ────────────────────────────────────────────────────────


def test_nhitsqr_model_initialization(base_config):
    config = NHITSQRConfig(**base_config)
    model = NHITSQRModel(model_config=config)
    assert isinstance(model.model, NHITSQR)
    assert model.model_config == config


def test_nhitsqr_forward_output_shapes(base_config, sample_input):
    config = NHITSQRConfig(**base_config)
    model = NHITSQRModel(model_config=config)

    output = model.model(sample_input)
    median = output["loc"]
    quantile_values = output["quantiles"]

    batch_size = sample_input.size(0)
    horizon = base_config["forecast_horizon"]
    num_targets = base_config["num_target_feature"]

    assert median.shape == (batch_size, horizon, num_targets)
    assert quantile_values.shape[0] == batch_size
    assert quantile_values.shape[-2] == horizon
    assert quantile_values.shape[-1] == num_targets


def test_nhitsqr_forward_no_nan(base_config, sample_input):
    config = NHITSQRConfig(**base_config)
    model = NHITSQRModel(model_config=config)
    output = model.model(sample_input)
    median, quantile_values = output["loc"], output["quantiles"]
    assert not torch.isnan(median).any()
    assert not torch.isnan(quantile_values).any()


@pytest.mark.parametrize("loss_fn", ["pinball", "huber-pinball"])
def test_nhitsqr_loss_fn_variants(loss_fn, base_config):
    base_config["loss_fn"] = loss_fn
    config = NHITSQRConfig(**base_config)
    model = NHITSQRModel(model_config=config)
    assert model.model_config.loss_fn == loss_fn


def test_nhitsqr_update_reinitialises_model(base_config):
    config = NHITSQRConfig(**base_config)
    model = NHITSQRModel(model_config=config)
    mock_trial = MagicMock()

    with patch.object(NHITSQRConfig, "get_optuna_params", return_value=base_config):
        model.update(mock_trial)

    assert isinstance(model.model_config, NHITSQRConfig)
    assert isinstance(model.model, NHITSQR)


def test_nhitsqr_load_checkpoint_sets_eval_mode(base_config):
    config = NHITSQRConfig(**base_config)
    model = NHITSQRModel(model_config=config)

    with patch.object(NHITSQRModel, "_load_checkpoints"):
        model.load_checkpoint()

    assert not model.model.training


# ── NHITSFPQRConfig Tests ─────────────────────────────────────────────────────


@pytest.fixture
def fpqr_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 0,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "encode_size": 64,
        "max_epochs": 5,
        "n_quantiles": 9,
        "conf_level": 0.05,
        "loss_fn": "pinball",
        "kappa": 0.25,
        "num_cosines": 32,
    }


def test_nhitsfpqr_config_initialization(fpqr_config):
    config = NHITSFPQRConfig(**fpqr_config)
    assert config.name == "nhitsfpqr"
    assert config.n_quantiles == 9
    assert config.loss_fn == "pinball"
    assert config.search_space is not None


def test_nhitsfpqr_config_dim_fields_default_to_zero():
    """Dim fields default to 0 so TwigaForecaster can auto-populate them."""
    cfg = NHITSFPQRConfig()
    assert cfg.num_target_feature == 0
    assert cfg.forecast_horizon == 0
    assert cfg.lookback_window_size == 0


def test_nhitsfpqr_config_dim_fields_explicit_values():
    """Explicitly set dim fields are accepted and preserved."""
    cfg = NHITSFPQRConfig(num_target_feature=2, forecast_horizon=48, lookback_window_size=96)
    assert cfg.num_target_feature == 2
    assert cfg.forecast_horizon == 48
    assert cfg.lookback_window_size == 96


# ── NHITSFPQRModel Tests ──────────────────────────────────────────────────────


def test_nhitsfpqr_model_initialization(fpqr_config):
    config = NHITSFPQRConfig(**fpqr_config)
    model = NHITSFPQRModel(model_config=config)
    assert isinstance(model.model, NHITSFPQR)
    assert model.model_config == config


def test_nhitsfpqr_forward_output_shapes(fpqr_config, sample_input):
    config = NHITSFPQRConfig(**fpqr_config)
    model = NHITSFPQRModel(model_config=config)

    output = model.model(sample_input)
    loc = output["loc"]
    quantile_values = output["quantiles"]
    batch_size = sample_input.size(0)
    horizon = fpqr_config["forecast_horizon"]
    num_targets = fpqr_config["num_target_feature"]

    assert loc.shape == (batch_size, horizon, num_targets)
    assert quantile_values.shape[0] == batch_size
    assert quantile_values.shape[-2] == horizon
    assert not torch.isnan(loc).any()
    assert not torch.isnan(quantile_values).any()


def test_nhitsfpqr_update_reinitialises_model(fpqr_config):
    config = NHITSFPQRConfig(**fpqr_config)
    model = NHITSFPQRModel(model_config=config)
    mock_trial = MagicMock()

    with patch.object(NHITSFPQRConfig, "get_optuna_params", return_value=fpqr_config):
        model.update(mock_trial)

    assert isinstance(model.model_config, NHITSFPQRConfig)
    assert isinstance(model.model, NHITSFPQR)


def test_nhitsfpqr_load_checkpoint_sets_eval_mode(fpqr_config):
    config = NHITSFPQRConfig(**fpqr_config)
    model = NHITSFPQRModel(model_config=config)

    with patch.object(NHITSFPQRModel, "_load_checkpoints"):
        model.load_checkpoint()

    assert not model.model.training
