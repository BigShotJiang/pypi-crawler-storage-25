"""Unit tests for MLPFFPQRConfig and MLPFFPQRModel.

Network under test: MLPFFPQR (wraps MLPFFPQuantile + FPQRDistribution).
Config under test:  MLPFFPQRConfig (extends MLPFConfig).
"""

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.mlpffpqr_model import MLPFFPQRConfig, MLPFFPQRModel
from twiga.models.nn.prob.mlpffpqr import MLPFFPQR

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 128,
        "num_layers": 2,
        "activation_function": "SiLU",
        "max_epochs": 10,
        # ── FPQR-specific ──────────────────────────────────────────────────
        "n_quantiles": 9,
        "conf_level": 0.05,
        "loss_fn": "pinball",
        "kappa": 0.25,
        "num_cosines": 32,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 32
    past_features = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future_features = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )

    features = np.ones((batch_size, base_config["lookback_window_size"], past_features))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future_features))

    features = stack_features(past_features=features, future_covariates=covariates)
    return torch.from_numpy(features).float()


# ── MLPFFPQRConfig Tests ──────────────────────────────────────────────────────


def test_mlpffpqrconfig_initialization(base_config):
    """Test valid MLPFFPQRConfig initialization."""
    config = MLPFFPQRConfig(**base_config)

    assert config.name == "mlpffpqr"
    assert config.latent_size == 128
    assert config.n_quantiles == 9
    assert config.conf_level == 0.05
    assert config.loss_fn == "pinball"
    assert config.kappa == 0.25
    assert config.num_cosines == 32
    assert config.search_space is not None


def test_mlpffpqrconfig_no_quantiles_field():
    """Test that MLPFFPQRConfig has no quantiles field (unlike MLPFQRConfig)."""
    config = MLPFFPQRConfig(
        num_target_feature=1,
        forecast_horizon=24,
        lookback_window_size=96,
    )
    assert not hasattr(config, "quantiles")
    assert not hasattr(config, "eps")
    assert hasattr(config, "n_quantiles")
    assert hasattr(config, "num_cosines")


def test_invalid_loss_fn():
    """Test that an unsupported loss function raises ValidationError."""
    with pytest.raises(ValidationError) as excinfo:
        MLPFFPQRConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            loss_fn="invalid_loss",
        )
    assert "loss_fn" in str(excinfo.value)


def test_invalid_activation_function():
    """Test that an unsupported activation function raises ValidationError."""
    with pytest.raises(ValidationError) as excinfo:
        MLPFFPQRConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            activation_function="InvalidActivation",
        )
    assert "activation_function" in str(excinfo.value)


def test_missing_required_field():
    """Omitting NN dimension fields defaults to 0 (sentinel for TwigaForecaster auto-fill)."""
    config = MLPFFPQRConfig(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0


def test_mlpffpqrmodel_initialization(base_config):
    """Test model initialization with valid config."""
    config = MLPFFPQRConfig(**base_config)
    model = MLPFFPQRModel(model_config=config)

    assert isinstance(model.model, MLPFFPQR)
    assert model.model_config == config


@pytest.mark.parametrize("n_quantiles", [7, 9, 15, 21])
def test_n_quantiles_variants(n_quantiles, base_config):
    """Test supported n_quantiles values initialise without error."""
    base_config["n_quantiles"] = n_quantiles
    config = MLPFFPQRConfig(**base_config)
    model = MLPFFPQRModel(model_config=config)
    assert model.model_config.n_quantiles == n_quantiles


@pytest.mark.parametrize("num_cosines", [16, 32, 64])
def test_num_cosines_variants(num_cosines, base_config):
    """Test supported num_cosines values initialise without error."""
    base_config["num_cosines"] = num_cosines
    config = MLPFFPQRConfig(**base_config)
    model = MLPFFPQRModel(model_config=config)
    assert model.model_config.num_cosines == num_cosines


@pytest.mark.parametrize("loss_fn", ["pinball", "huber-pinball"])
def test_loss_fn_variants(loss_fn, base_config):
    """Test both supported loss functions initialise without error."""
    base_config["loss_fn"] = loss_fn
    config = MLPFFPQRConfig(**base_config)
    model = MLPFFPQRModel(model_config=config)
    assert model.model_config.loss_fn == loss_fn


@pytest.mark.parametrize("comb_type", ["attn-comb", "weighted-comb", "addition-comb"])
def test_combination_types(comb_type, base_config, sample_input):
    """Test all valid combination types produce finite outputs."""
    base_config["combination_type"] = comb_type
    config = MLPFFPQRConfig(**base_config)
    model = MLPFFPQRModel(model_config=config)

    output = model.model(sample_input)
    loc, quantiles, tau_hats = output["loc"], output["quantiles"], output["quantile_levels"]
    assert not torch.isnan(loc).any()
    assert not torch.isnan(quantiles).any()
    assert not np.any(np.isnan(tau_hats))


def test_forecast_output_shapes(base_config, sample_input):
    """Test forecast returns correct shapes for all three outputs."""
    config = MLPFFPQRConfig(**base_config)
    model = MLPFFPQRModel(model_config=config)

    output = model.model(sample_input)
    loc, quantiles, tau_hats = output["loc"], output["quantiles"], output["quantile_levels"]

    batch_size = sample_input.size(0)
    horizon = base_config["forecast_horizon"]
    num_targets = base_config["num_target_feature"]
    num_quantiles = base_config["n_quantiles"]

    assert loc.shape == (batch_size, horizon, num_targets), (
        f"loc: expected {(batch_size, horizon, num_targets)}, got {loc.shape}"
    )
    assert quantiles.shape == (batch_size, num_quantiles, horizon, num_targets), (
        f"quantiles: expected {(batch_size, num_quantiles, horizon, num_targets)}, got {quantiles.shape}"
    )
    # quantile_levels is a 3-D ndarray (batch, n_quantiles, horizon) — per-sample per-step taus
    assert tau_hats.shape == (batch_size, num_quantiles, horizon), (
        f"quantile_levels: expected ({batch_size}, {num_quantiles}, {horizon}), got {tau_hats.shape}"
    )


# ── Device Compatibility ──────────────────────────────────────────────────────


def test_mlpffpqrmodel_update(base_config):
    """update() re-initialises model with Optuna-suggested hyperparameters."""
    config = MLPFFPQRConfig(**base_config)
    model = MLPFFPQRModel(model_config=config)
    mock_trial = MagicMock()

    with patch.object(MLPFFPQRConfig, "get_optuna_params", return_value=base_config):
        model.update(mock_trial)

    assert isinstance(model.model_config, MLPFFPQRConfig)
    assert isinstance(model.model, MLPFFPQR)


def test_mlpffpqrmodel_load_checkpoint(base_config):
    """load_checkpoint() delegates to _load_checkpoints and sets eval mode."""
    config = MLPFFPQRConfig(**base_config)
    model = MLPFFPQRModel(model_config=config)

    with patch.object(MLPFFPQRModel, "_load_checkpoints"):
        model.load_checkpoint()

    assert not model.model.training


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_gpu_compatibility(base_config, sample_input):
    """Test model operation on GPU."""
    config = MLPFFPQRConfig(**base_config)
    model = MLPFFPQRModel(model_config=config).cuda()

    output = model.model(sample_input.cuda())
    loc, quantiles = output["loc"], output["quantiles"]
    assert loc.device.type == "cuda"
    assert quantiles.device.type == "cuda"
