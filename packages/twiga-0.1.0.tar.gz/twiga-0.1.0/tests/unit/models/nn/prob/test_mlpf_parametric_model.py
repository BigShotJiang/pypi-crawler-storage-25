"""Unit tests for MLPF parametric distribution model configs.

Covers: MLPFNormalConfig, MLPFLaplaceConfig, MLPFLogNormalConfig,
        MLPFGammaConfig, MLPFBetaConfig — config init, update, load_checkpoint.

Note: The model _init_model() has a known incompatibility (out_activation_function
kwarg mismatch) so model instantiation tests mock _init_model.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from twiga.models.nn.mlpfbeta_model import MLPFBetaConfig, MLPFBetaModel
from twiga.models.nn.mlpfgamma_model import MLPFGammaConfig, MLPFGammaModel
from twiga.models.nn.mlpflaplace_model import MLPFLaplaceConfig, MLPFLaplaceModel
from twiga.models.nn.mlpflognormal_model import MLPFLogNormalConfig, MLPFLogNormalModel
from twiga.models.nn.mlpfnormal_model import MLPFNormalConfig, MLPFNormalModel
from twiga.models.nn.prob.mlpf_parametric import (
    MLPFBeta,
    MLPFGamma,
    MLPFLaplace,
    MLPFLogNormal,
    MLPFNormal,
)

# ── Fixtures ──────────────────────────────────────────────────────────────────

PARAMETRIC_MODELS = [
    ("normal", MLPFNormalConfig, MLPFNormalModel, MLPFNormal),
    ("laplace", MLPFLaplaceConfig, MLPFLaplaceModel, MLPFLaplace),
    ("lognormal", MLPFLogNormalConfig, MLPFLogNormalModel, MLPFLogNormal),
    ("gamma", MLPFGammaConfig, MLPFGammaModel, MLPFGamma),
    ("beta", MLPFBetaConfig, MLPFBetaModel, MLPFBeta),
]


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 64,
        "num_layers": 1,
        "max_epochs": 5,
    }


# ── Config Tests ──────────────────────────────────────────────────────────────


@pytest.mark.parametrize("dist,ConfigCls,ModelCls,NetworkCls", PARAMETRIC_MODELS)
def test_config_initialization(dist, ConfigCls, ModelCls, NetworkCls, base_config):
    config = ConfigCls(**base_config)
    assert config.name == f"mlpf{dist}"
    assert config.search_space is not None
    assert config.num_target_feature == 1
    assert config.forecast_horizon == 24


@pytest.mark.parametrize("dist,ConfigCls,ModelCls,NetworkCls", PARAMETRIC_MODELS)
def test_config_missing_required_field(dist, ConfigCls, ModelCls, NetworkCls):
    """Omitting NN dimension fields defaults to 0 (sentinel for TwigaForecaster auto-fill)."""
    config = ConfigCls(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0


# ── Model Lifecycle Tests (with _init_model mocked) ──────────────────────────


@pytest.mark.parametrize("dist,ConfigCls,ModelCls,NetworkCls", PARAMETRIC_MODELS)
def test_update_reinitialises_model(dist, ConfigCls, ModelCls, NetworkCls, base_config):
    """update() calls get_optuna_params and rebuilds the model."""
    with patch.object(ModelCls, "_init_model"):
        config = ConfigCls(**base_config)
        model = ModelCls(model_config=config)
        model.model = MagicMock()
        mock_trial = MagicMock()

        with patch.object(ConfigCls, "get_optuna_params", return_value=base_config):
            model.update(mock_trial)

    assert isinstance(model.model_config, ConfigCls)


@pytest.mark.parametrize("dist,ConfigCls,ModelCls,NetworkCls", PARAMETRIC_MODELS)
def test_load_checkpoint_sets_eval_mode(dist, ConfigCls, ModelCls, NetworkCls, base_config):
    """load_checkpoint() delegates to _load_checkpoints and sets model to eval."""
    with patch.object(ModelCls, "_init_model"):
        config = ConfigCls(**base_config)
        model = ModelCls(model_config=config)
        mock_net = MagicMock()
        model.model = mock_net

    with patch.object(ModelCls, "_load_checkpoints"):
        model.load_checkpoint()

    mock_net.eval.assert_called_once()
