"""Unit tests for MLPFCRCConfig and MLPFCRCModel.

Network under test: MLPFCRC (MLPFNetwork + CRCDistribution).
Config under test:  MLPFCRCConfig (extends MLPFConfig).

Unlike MLPGAM/MLPGAF, MLPF uses the standard CRCDistribution which projects
the latent through a mu_layer (the backbone is not additive).
"""

from __future__ import annotations

from unittest.mock import patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.distributions.nn.residual_conformal import CRCDistribution
from twiga.models.nn.mlpfcrc_model import MLPFCRCConfig, MLPFCRCModel
from twiga.models.nn.prob.mlpf_crc import MLPFCRC

# ── Fixtures ───────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 64,
        "hidden_dim": 64,
        "num_layers": 1,
        "dropout": 0.0,
        "max_epochs": 5,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 8
    past = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future = base_config["num_future_covariates"] + base_config["num_calendar_features"]
    features = np.ones((batch_size, base_config["lookback_window_size"], past))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future))
    return torch.from_numpy(stack_features(past_features=features, future_covariates=covariates)).float()


# ── MLPFCRCConfig ──────────────────────────────────────────────────────────────


def test_config_name(base_config):
    config = MLPFCRCConfig(**base_config)
    assert config.name == "mlpfcrc"


def test_config_search_space_present(base_config):
    config = MLPFCRCConfig(**base_config)
    assert config.search_space is not None


def test_config_invalid_activation():
    with pytest.raises(ValidationError) as exc:
        MLPFCRCConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            activation_function="BadAct",
        )
    assert "activation_function" in str(exc.value)


def test_config_missing_required_field():
    """Omitting NN dimension fields defaults to 0 (sentinel for TwigaForecaster auto-fill)."""
    config = MLPFCRCConfig(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0


def test_model_initialization(base_config):
    config = MLPFCRCConfig(**base_config)
    model = MLPFCRCModel(model_config=config)
    assert isinstance(model.model, MLPFCRC)
    assert model.model_config == config


def test_model_uses_standard_crc_head(base_config):
    """Standard MLPF uses CRCDistribution (has mu_layer for projection)."""
    config = MLPFCRCConfig(**base_config)
    model = MLPFCRCModel(model_config=config)
    head = model.model.model.head
    assert isinstance(head, CRCDistribution)
    assert hasattr(head, "mu_layer"), "Standard CRC must have mu_layer"


def test_model_forward_output_shapes(base_config, sample_input):
    config = MLPFCRCConfig(**base_config)
    model = MLPFCRCModel(model_config=config)
    with torch.no_grad():
        mu, sigma = model.model(sample_input)
    batch = sample_input.size(0)
    horizon = base_config["forecast_horizon"]
    n_out = base_config["num_target_feature"]
    assert mu.shape == (batch, horizon, n_out)
    assert sigma.shape == (batch, horizon, n_out)


def test_sigma_positive(base_config, sample_input):
    config = MLPFCRCConfig(**base_config)
    model = MLPFCRCModel(model_config=config)
    with torch.no_grad():
        _, sigma = model.model(sample_input)
    assert (sigma > 0).all()


def test_no_nan_in_output(base_config, sample_input):
    config = MLPFCRCConfig(**base_config)
    model = MLPFCRCModel(model_config=config)
    with torch.no_grad():
        mu, sigma = model.model(sample_input)
    assert not torch.isnan(mu).any()
    assert not torch.isnan(sigma).any()


def test_encode_size_is_latent_size(base_config):
    """MLPF encode_size == latent_size (NOT H*O — backbone is not additive)."""
    config = MLPFCRCConfig(**base_config)
    model = MLPFCRCModel(model_config=config)
    backbone = model.model.model.backbone
    assert backbone.encode_size == base_config["latent_size"]


def test_model_update(base_config):
    config = MLPFCRCConfig(**base_config)
    model = MLPFCRCModel(model_config=config)
    import optuna

    study = optuna.create_study(direction="minimize")
    trial = study.ask()
    model.update(trial=trial)
    assert isinstance(model.model, MLPFCRC)


def test_load_checkpoint_calls_load(base_config):
    config = MLPFCRCConfig(**base_config)
    model = MLPFCRCModel(model_config=config)
    with patch.object(model, "_load_checkpoints") as mock_load:
        model.load_checkpoint()
        mock_load.assert_called_once_with(model_instance=MLPFCRC)
