"""Unit tests for MLPGAFQRConfig and MLPGAFQRModel.

Network under test: MLPGAFQR (MLPGAFNetwork + QRDistribution).
Config under test:  MLPGAFQRConfig (extends MLPGAFConfig).

Pattern follows test_mplfqr_model.py and test_ganf_model.py.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.mlpgafqr_model import MLPGAFQRConfig, MLPGAFQRModel
from twiga.models.nn.prob.mlpgafqr import MLPGAFQR

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 64,
        "hidden_dim": 64,
        "num_layers": 1,
        "dropout": 0.0,
        "max_epochs": 5,
        # ── QR-specific ────────────────────────────────────────────────────
        "quantiles": [0.1, 0.5, 0.9],
        "conf_level": 0.05,
        "loss_fn": "pinball",
        "kappa": 0.5,
        "eps": 1e-6,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 16
    past = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    features = np.ones((batch_size, base_config["lookback_window_size"], past))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future))
    return torch.from_numpy(stack_features(past_features=features, future_covariates=covariates)).float()


# ── MLPGAFQRConfig ────────────────────────────────────────────────────────────


def test_config_initialization(base_config):
    config = MLPGAFQRConfig(**base_config)
    assert config.name == "mlpgafqr"
    assert config.quantiles == [0.1, 0.5, 0.9]
    assert config.conf_level == 0.05
    assert config.loss_fn == "pinball"
    assert config.kappa == 0.5
    assert config.eps == 1e-6
    assert config.search_space is not None


def test_config_has_gaf_fields(base_config):
    config = MLPGAFQRConfig(**base_config)
    assert hasattr(config, "lambda_weight")
    assert hasattr(config, "lambda_gate")
    assert hasattr(config, "gate_type")
    assert hasattr(config, "warmup_epochs")
    assert hasattr(config, "use_revin")


def test_config_default_quantiles():
    config = MLPGAFQRConfig(
        num_target_feature=1,
        forecast_horizon=24,
        lookback_window_size=96,
    )
    assert config.quantiles is None


def test_config_invalid_loss_fn():
    with pytest.raises(ValidationError) as exc:
        MLPGAFQRConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            loss_fn="bad_fn",
        )
    assert "loss_fn" in str(exc.value)


def test_config_invalid_activation():
    with pytest.raises(ValidationError) as exc:
        MLPGAFQRConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            activation_function="BadAct",
        )
    assert "activation_function" in str(exc.value)


def test_config_invalid_gate_type():
    with pytest.raises(ValidationError) as exc:
        MLPGAFQRConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            gate_type="gumbel",
        )
    assert "gate_type" in str(exc.value)


def test_config_missing_required_field():
    """Omitting NN dimension fields defaults to 0 (sentinel for TwigaForecaster auto-fill)."""
    config = MLPGAFQRConfig(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0


def test_config_search_space_has_gaf_and_qr_keys():
    config = MLPGAFQRConfig(num_target_feature=1, forecast_horizon=24, lookback_window_size=96)
    for key in ("use_revin", "lambda_gate", "lambda_weight", "kappa", "loss_fn"):
        assert hasattr(config.search_space, key), f"Missing search_space key: '{key}'"


# ── MLPGAFQRModel ─────────────────────────────────────────────────────────────


def test_model_initialization(base_config):
    config = MLPGAFQRConfig(**base_config)
    model = MLPGAFQRModel(model_config=config)
    assert isinstance(model.model, MLPGAFQR)
    assert model.model_config == config


def test_model_no_quantiles(base_config):
    base_config["quantiles"] = None
    config = MLPGAFQRConfig(**base_config)
    model = MLPGAFQRModel(model_config=config)
    assert isinstance(model.model, MLPGAFQR)


@pytest.mark.parametrize("loss_fn", ["pinball", "huber-pinball"])
def test_loss_fn_variants(loss_fn, base_config):
    base_config["loss_fn"] = loss_fn
    config = MLPGAFQRConfig(**base_config)
    model = MLPGAFQRModel(model_config=config)
    assert model.model_config.loss_fn == loss_fn


@pytest.mark.parametrize("use_revin", [False, True])
def test_use_revin_variants(use_revin, base_config, sample_input):
    base_config["use_revin"] = use_revin
    config = MLPGAFQRConfig(**base_config)
    model = MLPGAFQRModel(model_config=config)
    output = model.model(sample_input)
    median, quantile_values = output["loc"], output["quantiles"]
    assert not torch.isnan(median).any()
    assert not torch.isnan(quantile_values).any()


@pytest.mark.parametrize("lambda_gate", [0.0, 1e-6, 1e-2])
def test_lambda_gate_variants(lambda_gate, base_config, sample_input):
    base_config["lambda_gate"] = lambda_gate
    config = MLPGAFQRConfig(**base_config)
    model = MLPGAFQRModel(model_config=config)
    output = model.model(sample_input)
    median, quantile_values = output["loc"], output["quantiles"]
    assert not torch.isnan(median).any()
    assert not torch.isnan(quantile_values).any()


def test_forward_output_shapes(base_config, sample_input):
    config = MLPGAFQRConfig(**base_config)
    model = MLPGAFQRModel(model_config=config)

    output = model.model(sample_input)
    median = output["loc"]
    quantile_values = output["quantiles"]

    batch_size = sample_input.size(0)
    horizon = base_config["forecast_horizon"]
    num_targets = base_config["num_target_feature"]

    assert median.shape == (batch_size, horizon, num_targets), (
        f"median: expected {(batch_size, horizon, num_targets)}, got {median.shape}"
    )
    assert quantile_values.shape[0] == batch_size
    assert quantile_values.shape[-2] == horizon
    assert quantile_values.shape[-1] == num_targets


def test_forward_no_nan(base_config, sample_input):
    config = MLPGAFQRConfig(**base_config)
    model = MLPGAFQRModel(model_config=config)
    output = model.model(sample_input)
    median, quantile_values = output["loc"], output["quantiles"]
    assert not torch.isnan(median).any()
    assert not torch.isnan(quantile_values).any()


# ── Device compatibility ──────────────────────────────────────────────────────


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_gpu_compatibility(base_config, sample_input):
    config = MLPGAFQRConfig(**base_config)
    model = MLPGAFQRModel(model_config=config)
    model.model.cuda()
    output = model.model(sample_input.cuda())
    median, quantile_values = output["loc"], output["quantiles"]
    assert median.device.type == "cuda"
    assert quantile_values.device.type == "cuda"


def test_update_reinitialises_model(base_config):
    """update() calls get_optuna_params and rebuilds the model."""
    config = MLPGAFQRConfig(**base_config)
    model = MLPGAFQRModel(model_config=config)
    mock_trial = MagicMock()

    with patch.object(MLPGAFQRConfig, "get_optuna_params", return_value=base_config):
        model.update(mock_trial)

    assert isinstance(model.model_config, MLPGAFQRConfig)
    assert isinstance(model.model, MLPGAFQR)


def test_load_checkpoint_sets_eval_mode(base_config):
    """load_checkpoint() delegates to _load_checkpoints and sets model to eval."""
    config = MLPGAFQRConfig(**base_config)
    model = MLPGAFQRModel(model_config=config)

    with patch.object(MLPGAFQRModel, "_load_checkpoints"):
        model.load_checkpoint()

    assert not model.model.training
