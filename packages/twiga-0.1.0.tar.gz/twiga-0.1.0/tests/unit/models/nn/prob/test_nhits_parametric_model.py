"""Unit tests for NHiTS parametric distribution model configs and wrappers.

Covers: NHITSNormalConfig, NHITSLaplaceConfig, NHITSLogNormalConfig,
        NHITSGammaConfig, NHITSBetaConfig, NHITSStudentTConfig —
        config init, model init, forward shapes, update, load_checkpoint.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.nhitsbeta_model import NHITSBetaConfig, NHITSBetaModel
from twiga.models.nn.nhitsgamma_model import NHITSGammaConfig, NHITSGammaModel
from twiga.models.nn.nhitslaplace_model import NHITSLaplaceConfig, NHITSLaplaceModel
from twiga.models.nn.nhitslognormal_model import NHITSLogNormalConfig, NHITSLogNormalModel
from twiga.models.nn.nhitsnormal_model import NHITSNormalConfig, NHITSNormalModel
from twiga.models.nn.nhitsstudentt_model import NHITSStudentTConfig, NHITSStudentTModel
from twiga.models.nn.prob.nhits_parametric import (
    NHITSBeta,
    NHITSGamma,
    NHITSLaplace,
    NHITSLogNormal,
    NHITSNormal,
    NHITSStudentT,
)

# ── Parametric model registry ─────────────────────────────────────────────────

PARAMETRIC_MODELS = [
    ("normal", NHITSNormalConfig, NHITSNormalModel, NHITSNormal),
    ("laplace", NHITSLaplaceConfig, NHITSLaplaceModel, NHITSLaplace),
    ("lognormal", NHITSLogNormalConfig, NHITSLogNormalModel, NHITSLogNormal),
    ("gamma", NHITSGammaConfig, NHITSGammaModel, NHITSGamma),
    ("beta", NHITSBetaConfig, NHITSBetaModel, NHITSBeta),
    ("studentt", NHITSStudentTConfig, NHITSStudentTModel, NHITSStudentT),
]

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 0,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "encode_size": 64,
        "max_epochs": 5,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 8
    past = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    features = np.ones((batch_size, base_config["lookback_window_size"], past))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future))
    return torch.from_numpy(stack_features(past_features=features, future_covariates=covariates)).float()


# ── Config Tests ──────────────────────────────────────────────────────────────


@pytest.mark.parametrize("dist,ConfigCls,ModelCls,NetworkCls", PARAMETRIC_MODELS)
def test_config_initialization(dist, ConfigCls, ModelCls, NetworkCls, base_config):
    config = ConfigCls(**base_config)
    assert config.name == f"nhits{dist}"
    assert config.search_space is not None
    assert config.num_target_feature == 1
    assert config.forecast_horizon == 24


@pytest.mark.parametrize("dist,ConfigCls,ModelCls,NetworkCls", PARAMETRIC_MODELS)
def test_config_dim_fields_default_to_zero(dist, ConfigCls, ModelCls, NetworkCls):
    """Dim fields default to 0 so TwigaForecaster can auto-populate them."""
    cfg = ConfigCls()
    assert cfg.num_target_feature == 0
    assert cfg.forecast_horizon == 0
    assert cfg.lookback_window_size == 0


@pytest.mark.parametrize("dist,ConfigCls,ModelCls,NetworkCls", PARAMETRIC_MODELS)
def test_config_dim_fields_explicit_values(dist, ConfigCls, ModelCls, NetworkCls):
    """Explicitly set dim fields are accepted and preserved."""
    cfg = ConfigCls(num_target_feature=2, forecast_horizon=48, lookback_window_size=96)
    assert cfg.num_target_feature == 2
    assert cfg.forecast_horizon == 48
    assert cfg.lookback_window_size == 96


# ── Model Initialization Tests ────────────────────────────────────────────────


@pytest.mark.parametrize("dist,ConfigCls,ModelCls,NetworkCls", PARAMETRIC_MODELS)
def test_model_initialization(dist, ConfigCls, ModelCls, NetworkCls, base_config):
    config = ConfigCls(**base_config)
    model = ModelCls(model_config=config)
    assert isinstance(model.model, NetworkCls)
    assert model.model_config == config


# ── Forward Shape Tests ───────────────────────────────────────────────────────


@pytest.mark.parametrize("dist,ConfigCls,ModelCls,NetworkCls", PARAMETRIC_MODELS)
def test_forward_output_shapes(dist, ConfigCls, ModelCls, NetworkCls, base_config, sample_input):
    config = ConfigCls(**base_config)
    model = ModelCls(model_config=config)
    model.model.eval()

    with torch.no_grad():
        output = model.model(sample_input)

    # parametric forward returns (loc, scale) or (loc, scale, df) — first tensor is loc
    loc = output[0]
    horizon = base_config["forecast_horizon"]
    num_targets = base_config["num_target_feature"]
    batch_size = sample_input.size(0)

    assert loc.shape == (batch_size, horizon, num_targets)
    assert not torch.isnan(loc).any()


# ── Model Lifecycle Tests ─────────────────────────────────────────────────────


@pytest.mark.parametrize("dist,ConfigCls,ModelCls,NetworkCls", PARAMETRIC_MODELS)
def test_update_reinitialises_model(dist, ConfigCls, ModelCls, NetworkCls, base_config):
    """update() calls get_optuna_params and rebuilds the model."""
    config = ConfigCls(**base_config)
    model = ModelCls(model_config=config)
    mock_trial = MagicMock()

    with patch.object(ConfigCls, "get_optuna_params", return_value=base_config):
        model.update(mock_trial)

    assert isinstance(model.model_config, ConfigCls)
    assert isinstance(model.model, NetworkCls)


@pytest.mark.parametrize("dist,ConfigCls,ModelCls,NetworkCls", PARAMETRIC_MODELS)
def test_load_checkpoint_sets_eval_mode(dist, ConfigCls, ModelCls, NetworkCls, base_config):
    """load_checkpoint() delegates to _load_checkpoints and sets model to eval."""
    config = ConfigCls(**base_config)
    model = ModelCls(model_config=config)

    with patch.object(ModelCls, "_load_checkpoints"):
        model.load_checkpoint()

    assert not model.model.training


# ── StudentT-specific Tests ───────────────────────────────────────────────────


def test_studentt_config_min_df_default():
    config = NHITSStudentTConfig(num_target_feature=1, forecast_horizon=24, lookback_window_size=96)
    assert config.min_df > 2.0


def test_studentt_config_min_df_custom(base_config):
    config = NHITSStudentTConfig(**base_config, min_df=3.5)
    assert config.min_df == 3.5
