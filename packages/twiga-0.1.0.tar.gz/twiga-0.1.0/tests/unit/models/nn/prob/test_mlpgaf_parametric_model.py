"""Unit tests for MLPGAF parametric model configs and wrappers.

Covers all six distribution heads:
    MLPGAFNormal, MLPGAFLaplace, MLPGAFStudentT,
    MLPGAFLogNormal, MLPGAFGamma, MLPGAFBeta

Pattern follows test_mlpgaf_model.py and test_mlpgam_parametric_model.py.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.mlpgafbeta_model import MLPGAFBetaConfig, MLPGAFBetaModel
from twiga.models.nn.mlpgafgamma_model import MLPGAFGammaConfig, MLPGAFGammaModel
from twiga.models.nn.mlpgaflaplace_model import MLPGAFLaplaceConfig, MLPGAFLaplaceModel
from twiga.models.nn.mlpgaflognormal_model import MLPGAFLogNormalConfig, MLPGAFLogNormalModel
from twiga.models.nn.mlpgafnormal_model import MLPGAFNormalConfig, MLPGAFNormalModel
from twiga.models.nn.mlpgafstudentt_model import MLPGAFStudentTConfig, MLPGAFStudentTModel
from twiga.models.nn.prob.mlpgaf_parametric import (
    MLPGAFBeta,
    MLPGAFGamma,
    MLPGAFLaplace,
    MLPGAFLogNormal,
    MLPGAFNormal,
    MLPGAFStudentT,
)

# ── Parametrized registry ─────────────────────────────────────────────────────

PARAMETRIC_CASES = [
    ("normal", MLPGAFNormalConfig, MLPGAFNormalModel, MLPGAFNormal, "mlpgafnormal"),
    ("laplace", MLPGAFLaplaceConfig, MLPGAFLaplaceModel, MLPGAFLaplace, "mlpgaflaplace"),
    ("student_t", MLPGAFStudentTConfig, MLPGAFStudentTModel, MLPGAFStudentT, "mlpgafstudentt"),
    ("log_normal", MLPGAFLogNormalConfig, MLPGAFLogNormalModel, MLPGAFLogNormal, "mlpgaflognormal"),
    ("gamma", MLPGAFGammaConfig, MLPGAFGammaModel, MLPGAFGamma, "mlpgafgamma"),
    ("beta", MLPGAFBetaConfig, MLPGAFBetaModel, MLPGAFBeta, "mlpgafbeta"),
]
IDS = [c[0] for c in PARAMETRIC_CASES]

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 64,
        "hidden_dim": 64,
        "num_layers": 1,
        "dropout": 0.0,
        "max_epochs": 5,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 16
    past = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    features = np.ones((batch_size, base_config["lookback_window_size"], past))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future))
    return torch.from_numpy(stack_features(past_features=features, future_covariates=covariates)).float()


# ── Config: shared validation ─────────────────────────────────────────────────


@pytest.mark.parametrize("cfg_cls, name", [(c[1], c[4]) for c in PARAMETRIC_CASES], ids=IDS)
def test_config_name(base_config, cfg_cls, name):
    config = cfg_cls(**base_config)
    assert config.name == name


@pytest.mark.parametrize("cfg_cls", [c[1] for c in PARAMETRIC_CASES], ids=IDS)
def test_config_gaf_fields_present(base_config, cfg_cls):
    """All GAF configs must expose the gating hyperparameters."""
    config = cfg_cls(**base_config)
    assert hasattr(config, "lambda_weight")
    assert hasattr(config, "lambda_gate")
    assert hasattr(config, "gate_type")
    assert hasattr(config, "warmup_epochs")
    assert hasattr(config, "use_revin")


@pytest.mark.parametrize("cfg_cls", [c[1] for c in PARAMETRIC_CASES], ids=IDS)
def test_config_search_space_present(base_config, cfg_cls):
    config = cfg_cls(**base_config)
    assert config.search_space is not None


@pytest.mark.parametrize("cfg_cls", [c[1] for c in PARAMETRIC_CASES], ids=IDS)
def test_config_search_space_has_gaf_keys(base_config, cfg_cls):
    config = cfg_cls(**base_config)
    for key in ("use_revin", "lambda_gate", "lambda_weight", "gate_scale", "warmup_epochs", "delta"):
        assert hasattr(config.search_space, key), f"Missing search_space key: '{key}'"


@pytest.mark.parametrize("cfg_cls", [c[1] for c in PARAMETRIC_CASES], ids=IDS)
def test_config_invalid_activation(cfg_cls):
    with pytest.raises(ValidationError) as exc:
        cfg_cls(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            activation_function="BadAct",
        )
    assert "activation_function" in str(exc.value)


@pytest.mark.parametrize("cfg_cls", [c[1] for c in PARAMETRIC_CASES], ids=IDS)
def test_config_invalid_gate_type(cfg_cls):
    with pytest.raises(ValidationError) as exc:
        cfg_cls(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            gate_type="gumbel",
        )
    assert "gate_type" in str(exc.value)


@pytest.mark.parametrize("cfg_cls", [c[1] for c in PARAMETRIC_CASES], ids=IDS)
def test_config_missing_required_field(cfg_cls):
    """Omitting NN dimension fields defaults to 0 (sentinel for TwigaForecaster auto-fill)."""
    config = cfg_cls(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0


# ── Config: distribution-specific ─────────────────────────────────────────────


def test_student_t_config_has_min_df(base_config):
    config = MLPGAFStudentTConfig(**base_config)
    assert config.min_df == 2.1


def test_student_t_config_custom_min_df(base_config):
    config = MLPGAFStudentTConfig(**base_config, min_df=4.0)
    assert config.min_df == 4.0


def test_gamma_config_locks_out_activation(base_config):
    config = MLPGAFGammaConfig(**base_config)
    assert config.out_activation_function == "Identity"


def test_gamma_search_space_no_out_activation(base_config):
    config = MLPGAFGammaConfig(**base_config)
    assert not hasattr(config.search_space, "out_activation_function")


def test_beta_config_locks_out_activation(base_config):
    config = MLPGAFBetaConfig(**base_config)
    assert config.out_activation_function == "Identity"


def test_beta_search_space_no_out_activation(base_config):
    config = MLPGAFBetaConfig(**base_config)
    assert not hasattr(config.search_space, "out_activation_function")


# ── Model: initialization ─────────────────────────────────────────────────────


@pytest.mark.parametrize("cfg_cls, mdl_cls, net_cls", [(c[1], c[2], c[3]) for c in PARAMETRIC_CASES], ids=IDS)
def test_model_initialization(base_config, cfg_cls, mdl_cls, net_cls):
    config = cfg_cls(**base_config)
    model = mdl_cls(model_config=config)
    assert isinstance(model.model, net_cls)
    assert model.model_config == config


# ── Model: forward pass ───────────────────────────────────────────────────────


@pytest.mark.parametrize("cfg_cls, mdl_cls", [(c[1], c[2]) for c in PARAMETRIC_CASES], ids=IDS)
def test_forward_returns_tuple(base_config, sample_input, cfg_cls, mdl_cls):
    config = cfg_cls(**base_config)
    model = mdl_cls(model_config=config)
    model.model.eval()
    with torch.no_grad():
        out = model.model(sample_input)
    assert isinstance(out, tuple)
    assert len(out) >= 2


@pytest.mark.parametrize("cfg_cls, mdl_cls", [(c[1], c[2]) for c in PARAMETRIC_CASES], ids=IDS)
def test_forward_no_nan(base_config, sample_input, cfg_cls, mdl_cls):
    config = cfg_cls(**base_config)
    model = mdl_cls(model_config=config)
    model.model.eval()
    with torch.no_grad():
        out = model.model(sample_input)
    for t in out:
        assert not torch.isnan(t).any(), f"{cfg_cls.__name__}: NaN in output"


@pytest.mark.parametrize("cfg_cls, mdl_cls", [(c[1], c[2]) for c in PARAMETRIC_CASES], ids=IDS)
def test_forward_loc_shape(base_config, sample_input, cfg_cls, mdl_cls):
    """First output tensor (location/mean) must be (B, H, O)."""
    config = cfg_cls(**base_config)
    model = mdl_cls(model_config=config)
    model.model.eval()
    batch_size = sample_input.size(0)
    horizon = base_config["forecast_horizon"]
    num_targets = base_config["num_target_feature"]
    with torch.no_grad():
        loc = model.model(sample_input)[0]
    assert loc.shape == (batch_size, horizon, num_targets)


def test_student_t_forward_has_three_params(base_config, sample_input):
    config = MLPGAFStudentTConfig(**base_config)
    model = MLPGAFStudentTModel(model_config=config)
    model.model.eval()
    with torch.no_grad():
        out = model.model(sample_input)
    assert len(out) == 3, f"StudentT should return 3 params, got {len(out)}"


# ── Gate regularisation ───────────────────────────────────────────────────────


@pytest.mark.parametrize("use_revin", [False, True])
def test_normal_use_revin(base_config, sample_input, use_revin):
    base_config["use_revin"] = use_revin
    config = MLPGAFNormalConfig(**base_config)
    model = MLPGAFNormalModel(model_config=config)
    model.model.eval()
    with torch.no_grad():
        out = model.model(sample_input)
    assert not torch.isnan(out[0]).any()


@pytest.mark.parametrize("lambda_gate", [0.0, 1e-6, 1e-2])
def test_normal_lambda_gate_range(base_config, sample_input, lambda_gate):
    base_config["lambda_gate"] = lambda_gate
    config = MLPGAFNormalConfig(**base_config)
    model = MLPGAFNormalModel(model_config=config)
    model.model.eval()
    with torch.no_grad():
        out = model.model(sample_input)
    assert not torch.isnan(out[0]).any()


# ── Device compatibility ──────────────────────────────────────────────────────


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
@pytest.mark.parametrize("cfg_cls, mdl_cls", [(c[1], c[2]) for c in PARAMETRIC_CASES], ids=IDS)
def test_gpu_compatibility(base_config, sample_input, cfg_cls, mdl_cls):
    config = cfg_cls(**base_config)
    model = mdl_cls(model_config=config)
    model.model.cuda().eval()
    with torch.no_grad():
        out = model.model(sample_input.cuda())
    assert out[0].device.type == "cuda"


# ── Model: update and load_checkpoint ────────────────────────────────────────


@pytest.mark.parametrize("cfg_cls, mdl_cls, net_cls", [(c[1], c[2], c[3]) for c in PARAMETRIC_CASES], ids=IDS)
def test_update_reinitialises_model(base_config, cfg_cls, mdl_cls, net_cls):
    """update() calls get_optuna_params and rebuilds the model."""
    config = cfg_cls(**base_config)
    model = mdl_cls(model_config=config)
    mock_trial = MagicMock()

    with patch.object(cfg_cls, "get_optuna_params", return_value=base_config):
        model.update(mock_trial)

    assert isinstance(model.model_config, cfg_cls)
    assert isinstance(model.model, net_cls)


@pytest.mark.parametrize("cfg_cls, mdl_cls, net_cls", [(c[1], c[2], c[3]) for c in PARAMETRIC_CASES], ids=IDS)
def test_load_checkpoint_sets_eval_mode(base_config, cfg_cls, mdl_cls, net_cls):
    """load_checkpoint() calls _load_checkpoints and sets model to eval mode."""
    config = cfg_cls(**base_config)
    model = mdl_cls(model_config=config)

    with patch.object(mdl_cls, "_load_checkpoints"):
        model.load_checkpoint()

    assert not model.model.training
