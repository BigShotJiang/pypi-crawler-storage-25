"""Unit tests for MLPFQRConfig and MLPFQRModel.

Network under test: MLPFQR (wraps MLPFQuantile + QRDistribution).
Config under test:  MLPFQRConfig (extends MLPFConfig).
"""

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.mlpfqr_model import MLPFQRConfig, MLPFQRModel
from twiga.models.nn.prob.mlpfqr import MLPFQR

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 128,  # inherited from MLPFConfig; network param is latent_size
        "num_layers": 2,
        "activation_function": "SiLU",
        "max_epochs": 10,
        # ── QR-specific ────────────────────────────────────────────────────
        "quantiles": [0.1, 0.5, 0.9],
        "conf_level": 0.05,
        "loss_fn": "pinball",
        "kappa": 0.25,
        "eps": 1e-6,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 32
    past_features = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future_features = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )

    features = np.ones((batch_size, base_config["lookback_window_size"], past_features))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future_features))

    features = stack_features(past_features=features, future_covariates=covariates)
    return torch.from_numpy(features).float()


# ── MLPFQRConfig Tests ────────────────────────────────────────────────────────


def test_mlpfqrconfig_initialization(base_config):
    """Test valid MLPFQRConfig initialization."""
    config = MLPFQRConfig(**base_config)

    assert config.name == "mlpfqr"
    assert config.latent_size == 128
    assert config.quantiles == [0.1, 0.5, 0.9]
    assert config.conf_level == 0.05
    assert config.loss_fn == "pinball"
    assert config.kappa == 0.25
    assert config.eps == 1e-6
    assert config.search_space is not None


def test_mlpfqrconfig_default_quantiles():
    """Test that quantiles defaults to None when not provided."""
    config = MLPFQRConfig(
        num_target_feature=1,
        forecast_horizon=24,
        lookback_window_size=96,
    )
    assert config.quantiles is None


def test_invalid_loss_fn():
    """Test that an unsupported loss function raises ValidationError."""
    with pytest.raises(ValidationError) as excinfo:
        MLPFQRConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            loss_fn="invalid_loss",
        )
    assert "loss_fn" in str(excinfo.value)


def test_invalid_activation_function():
    """Test that an unsupported activation function raises ValidationError."""
    with pytest.raises(ValidationError) as excinfo:
        MLPFQRConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            activation_function="InvalidActivation",
        )
    assert "activation_function" in str(excinfo.value)


def test_missing_required_field():
    """Omitting NN dimension fields defaults to 0 (sentinel for TwigaForecaster auto-fill)."""
    config = MLPFQRConfig(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0


def test_mlpfqrmodel_initialization(base_config):
    """Test model initialization with valid config."""
    config = MLPFQRConfig(**base_config)
    model = MLPFQRModel(model_config=config)

    assert isinstance(model.model, MLPFQR)
    assert model.model_config == config


def test_mlpfqrmodel_no_quantiles(base_config):
    """Test model initialises when quantiles=None (QRDistribution applies defaults)."""
    base_config["quantiles"] = None
    config = MLPFQRConfig(**base_config)
    model = MLPFQRModel(model_config=config)
    assert isinstance(model.model, MLPFQR)


@pytest.mark.parametrize("loss_fn", ["pinball", "huber-pinball"])
def test_loss_fn_variants(loss_fn, base_config):
    """Test both supported loss functions initialise without error."""
    base_config["loss_fn"] = loss_fn
    config = MLPFQRConfig(**base_config)
    model = MLPFQRModel(model_config=config)
    assert model.model_config.loss_fn == loss_fn


@pytest.mark.parametrize("comb_type", ["attn-comb", "weighted-comb", "addition-comb"])
def test_combination_types(comb_type, base_config, sample_input):
    """Test all valid combination types produce finite outputs."""
    base_config["combination_type"] = comb_type
    config = MLPFQRConfig(**base_config)
    model = MLPFQRModel(model_config=config)

    output = model.model(sample_input)
    median, quantile_values = output["loc"], output["quantiles"]
    assert not torch.isnan(median).any()
    assert not torch.isnan(quantile_values).any()


# ── Device Compatibility ──────────────────────────────────────────────────────


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_gpu_compatibility(base_config, sample_input):
    """Test model operation on GPU."""
    config = MLPFQRConfig(**base_config)
    model = MLPFQRModel(model_config=config).cuda()

    median, quantile_values = model.model(sample_input.cuda())
    assert median.device.type == "cuda"
