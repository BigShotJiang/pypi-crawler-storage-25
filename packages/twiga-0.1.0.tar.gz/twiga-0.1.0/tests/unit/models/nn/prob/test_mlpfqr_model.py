"""Unit tests for MLPFQRConfig and MLPFQRModel."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.mlpfqr_model import MLPFQRConfig, MLPFQRModel
from twiga.models.nn.prob.mlpfqr import MLPFQR

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 64,
        "num_layers": 1,
        "max_epochs": 5,
        "quantiles": [0.1, 0.5, 0.9],
        "conf_level": 0.05,
        "loss_fn": "pinball",
        "kappa": 0.25,
        "eps": 1e-6,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 8
    past = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    features = np.ones((batch_size, base_config["lookback_window_size"], past))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future))
    return torch.from_numpy(stack_features(past_features=features, future_covariates=covariates)).float()


# ── MLPFQRConfig Tests ────────────────────────────────────────────────────────


def test_config_initialization(base_config):
    config = MLPFQRConfig(**base_config)
    assert config.name == "mlpfqr"
    assert config.quantiles == [0.1, 0.5, 0.9]
    assert config.loss_fn == "pinball"
    assert config.search_space is not None


def test_config_default_quantiles():
    config = MLPFQRConfig(num_target_feature=1, forecast_horizon=24, lookback_window_size=96)
    assert config.quantiles is None


def test_config_invalid_loss_fn():
    with pytest.raises(ValidationError) as exc:
        MLPFQRConfig(num_target_feature=1, forecast_horizon=24, lookback_window_size=96, loss_fn="bad")
    assert "loss_fn" in str(exc.value)


def test_config_missing_required_field():
    """Omitting NN dimension fields defaults to 0 (sentinel for TwigaForecaster auto-fill)."""
    config = MLPFQRConfig(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0


def test_model_initialization(base_config):
    config = MLPFQRConfig(**base_config)
    model = MLPFQRModel(model_config=config)
    assert isinstance(model.model, MLPFQR)
    assert model.model_config == config


def test_forward_output_shapes(base_config, sample_input):
    config = MLPFQRConfig(**base_config)
    model = MLPFQRModel(model_config=config)

    output = model.model(sample_input)
    median = output["loc"]
    quantile_values = output["quantiles"]

    batch_size = sample_input.size(0)
    horizon = base_config["forecast_horizon"]
    num_targets = base_config["num_target_feature"]

    assert median.shape == (batch_size, horizon, num_targets)
    assert quantile_values.shape[0] == batch_size
    assert quantile_values.shape[-2] == horizon
    assert quantile_values.shape[-1] == num_targets


def test_forward_no_nan(base_config, sample_input):
    config = MLPFQRConfig(**base_config)
    model = MLPFQRModel(model_config=config)
    output = model.model(sample_input)
    median, quantile_values = output["loc"], output["quantiles"]
    assert not torch.isnan(median).any()
    assert not torch.isnan(quantile_values).any()


@pytest.mark.parametrize("loss_fn", ["pinball", "huber-pinball"])
def test_loss_fn_variants(loss_fn, base_config):
    base_config["loss_fn"] = loss_fn
    config = MLPFQRConfig(**base_config)
    model = MLPFQRModel(model_config=config)
    assert model.model_config.loss_fn == loss_fn


def test_update_reinitialises_model(base_config):
    """update() calls get_optuna_params and rebuilds the model."""
    config = MLPFQRConfig(**base_config)
    model = MLPFQRModel(model_config=config)
    mock_trial = MagicMock()

    with patch.object(MLPFQRConfig, "get_optuna_params", return_value=base_config):
        model.update(mock_trial)

    assert isinstance(model.model_config, MLPFQRConfig)
    assert isinstance(model.model, MLPFQR)


def test_load_checkpoint_sets_eval_mode(base_config):
    """load_checkpoint() delegates to _load_checkpoints and sets model to eval."""
    config = MLPFQRConfig(**base_config)
    model = MLPFQRModel(model_config=config)

    with patch.object(MLPFQRModel, "_load_checkpoints"):
        model.load_checkpoint()

    assert not model.model.training
