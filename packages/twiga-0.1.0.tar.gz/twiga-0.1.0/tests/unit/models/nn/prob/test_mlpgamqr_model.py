"""Unit tests for MLPGAMQRConfig and MLPGAMQRModel.

Network under test: MLPGAMQR (MLPGAMNetwork + QRDistribution).
Config under test:  MLPGAMQRConfig (extends MLPGAMConfig).

Pattern follows test_mplfqr_model.py.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.mlpgamqr_model import MLPGAMQRConfig, MLPGAMQRModel
from twiga.models.nn.prob.mlpgamqr import MLPGAMQR

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 64,
        "hidden_dim": 64,
        "num_layers": 1,
        "dropout": 0.0,
        "max_epochs": 5,
        # ── QR-specific ────────────────────────────────────────────────────
        "quantiles": [0.1, 0.5, 0.9],
        "conf_level": 0.05,
        "loss_fn": "pinball",
        "kappa": 0.5,
        "eps": 1e-6,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 16
    past = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    features = np.ones((batch_size, base_config["lookback_window_size"], past))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future))
    return torch.from_numpy(stack_features(past_features=features, future_covariates=covariates)).float()


# ── MLPGAMQRConfig ────────────────────────────────────────────────────────────


def test_config_initialization(base_config):
    config = MLPGAMQRConfig(**base_config)
    assert config.name == "mlpgamqr"
    assert config.quantiles == [0.1, 0.5, 0.9]
    assert config.conf_level == 0.05
    assert config.loss_fn == "pinball"
    assert config.kappa == 0.5
    assert config.eps == 1e-6
    assert config.lambda_lasso == 1e-6
    assert config.search_space is not None


def test_config_default_quantiles():
    config = MLPGAMQRConfig(
        num_target_feature=1,
        forecast_horizon=24,
        lookback_window_size=96,
    )
    assert config.quantiles is None


def test_config_invalid_loss_fn():
    with pytest.raises(ValidationError) as exc:
        MLPGAMQRConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            loss_fn="bad_fn",
        )
    assert "loss_fn" in str(exc.value)


def test_config_invalid_activation():
    with pytest.raises(ValidationError) as exc:
        MLPGAMQRConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            activation_function="BadAct",
        )
    assert "activation_function" in str(exc.value)


def test_config_missing_required_field():
    """Omitting NN dimension fields defaults to 0 (sentinel for TwigaForecaster auto-fill)."""
    config = MLPGAMQRConfig(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0


def test_config_search_space_has_quantile_keys():
    config = MLPGAMQRConfig(num_target_feature=1, forecast_horizon=24, lookback_window_size=96)
    assert hasattr(config.search_space, "kappa")
    assert hasattr(config.search_space, "loss_fn")
    assert hasattr(config.search_space, "lambda_lasso")


# ── MLPGAMQRModel ─────────────────────────────────────────────────────────────


def test_model_initialization(base_config):
    config = MLPGAMQRConfig(**base_config)
    model = MLPGAMQRModel(model_config=config)
    assert isinstance(model.model, MLPGAMQR)
    assert model.model_config == config


def test_model_no_quantiles(base_config):
    """Model initialises when quantiles=None (QRDistribution applies defaults)."""
    base_config["quantiles"] = None
    config = MLPGAMQRConfig(**base_config)
    model = MLPGAMQRModel(model_config=config)
    assert isinstance(model.model, MLPGAMQR)


@pytest.mark.parametrize("loss_fn", ["pinball", "huber-pinball"])
def test_loss_fn_variants(loss_fn, base_config):
    base_config["loss_fn"] = loss_fn
    config = MLPGAMQRConfig(**base_config)
    model = MLPGAMQRModel(model_config=config)
    assert model.model_config.loss_fn == loss_fn


@pytest.mark.parametrize("lambda_lasso", [0.0, 1e-6, 1e-4])
def test_lambda_lasso_variants(lambda_lasso, base_config, sample_input):
    base_config["lambda_lasso"] = lambda_lasso
    config = MLPGAMQRConfig(**base_config)
    model = MLPGAMQRModel(model_config=config)
    output = model.model(sample_input)
    median = output["loc"]
    quantile_values = output["quantiles"]
    assert not torch.isnan(median).any()
    assert not torch.isnan(quantile_values).any()


def test_forward_output_shapes(base_config, sample_input):
    config = MLPGAMQRConfig(**base_config)
    model = MLPGAMQRModel(model_config=config)

    output = model.model(sample_input)
    median = output["loc"]
    quantile_values = output["quantiles"]

    batch_size = sample_input.size(0)
    horizon = base_config["forecast_horizon"]
    num_targets = base_config["num_target_feature"]

    assert median.shape == (batch_size, horizon, num_targets), (
        f"median: expected {(batch_size, horizon, num_targets)}, got {median.shape}"
    )
    assert quantile_values.shape[0] == batch_size
    assert quantile_values.shape[-2] == horizon
    assert quantile_values.shape[-1] == num_targets


def test_forward_no_nan(base_config, sample_input):
    config = MLPGAMQRConfig(**base_config)
    model = MLPGAMQRModel(model_config=config)
    output = model.model(sample_input)
    median = output["loc"]
    quantile_values = output["quantiles"]
    assert not torch.isnan(median).any()
    assert not torch.isnan(quantile_values).any()


# ── Device compatibility ──────────────────────────────────────────────────────


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_gpu_compatibility(base_config, sample_input):
    config = MLPGAMQRConfig(**base_config)
    model = MLPGAMQRModel(model_config=config)
    model.model.cuda()
    median, quantile_values = model.model(sample_input.cuda())
    assert median.device.type == "cuda"
    assert quantile_values.device.type == "cuda"


def test_update_reinitialises_model(base_config):
    """update() calls get_optuna_params and rebuilds the model."""
    config = MLPGAMQRConfig(**base_config)
    model = MLPGAMQRModel(model_config=config)
    mock_trial = MagicMock()

    with patch.object(MLPGAMQRConfig, "get_optuna_params", return_value=base_config):
        model.update(mock_trial)

    assert isinstance(model.model_config, MLPGAMQRConfig)
    assert isinstance(model.model, MLPGAMQR)


def test_load_checkpoint_sets_eval_mode(base_config):
    """load_checkpoint() delegates to _load_checkpoints and sets model to eval."""
    config = MLPGAMQRConfig(**base_config)
    model = MLPGAMQRModel(model_config=config)

    with patch.object(MLPGAMQRModel, "_load_checkpoints"):
        model.load_checkpoint()

    assert not model.model.training
