"""Unit tests for MLPFStudentTConfig and MLPFStudentTModel.

Network under test: MLPFStudentT (MLPFNetwork + StudentTDistribution).
Config under test:  MLPFStudentTConfig (extends MLPFConfig).
"""

from __future__ import annotations

from unittest.mock import patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.distributions.nn.parametric import StudentTDistribution
from twiga.models.nn.mlpfstudentt_model import MLPFStudentTConfig, MLPFStudentTModel
from twiga.models.nn.prob.mlpf_parametric import MLPFStudentT

# ── Fixtures ───────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 64,
        "hidden_dim": 64,
        "num_layers": 1,
        "dropout": 0.0,
        "max_epochs": 5,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 8
    past = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future = base_config["num_future_covariates"] + base_config["num_calendar_features"]
    features = np.ones((batch_size, base_config["lookback_window_size"], past))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future))
    return torch.from_numpy(stack_features(past_features=features, future_covariates=covariates)).float()


# ── Config Tests ───────────────────────────────────────────────────────────────


def test_config_name(base_config):
    config = MLPFStudentTConfig(**base_config)
    assert config.name == "mlpfstudentt"


def test_config_search_space_present(base_config):
    config = MLPFStudentTConfig(**base_config)
    assert config.search_space is not None


def test_config_min_df_default(base_config):
    config = MLPFStudentTConfig(**base_config)
    assert config.min_df > 2.0


def test_config_min_df_custom(base_config):
    config = MLPFStudentTConfig(**base_config, min_df=3.5)
    assert config.min_df == 3.5


def test_config_min_df_must_be_gt_2(base_config):
    """min_df must be strictly greater than 2.0 (finite variance requirement)."""
    with pytest.raises(ValidationError):
        MLPFStudentTConfig(**base_config, min_df=1.5)


def test_config_missing_required_fields_defaults_to_sentinel():
    """Omitting NN dimension fields defaults to 0 (auto-filled by TwigaForecaster)."""
    config = MLPFStudentTConfig(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0


def test_config_invalid_activation(base_config):
    with pytest.raises(ValidationError) as exc:
        MLPFStudentTConfig(**base_config, activation_function="BadAct")
    assert "activation_function" in str(exc.value)


# ── Model Initialization Tests ─────────────────────────────────────────────────


def test_model_initialization(base_config):
    config = MLPFStudentTConfig(**base_config)
    model = MLPFStudentTModel(model_config=config)
    assert isinstance(model.model, MLPFStudentT)
    assert model.model_config == config


def test_model_uses_studentt_head(base_config):
    config = MLPFStudentTConfig(**base_config)
    model = MLPFStudentTModel(model_config=config)
    head = model.model.model.head
    assert isinstance(head, StudentTDistribution)


def test_model_head_has_df_layer(base_config):
    """StudentT head must have a degrees-of-freedom output layer."""
    config = MLPFStudentTConfig(**base_config)
    model = MLPFStudentTModel(model_config=config)
    head = model.model.model.head
    assert hasattr(head, "df_layer"), "StudentT head must expose df_layer"


# ── Forward Shape Tests ────────────────────────────────────────────────────────


def test_forward_output_is_three_tuple(base_config, sample_input):
    """StudentT forward returns (mu, sigma, df)."""
    config = MLPFStudentTConfig(**base_config)
    model = MLPFStudentTModel(model_config=config)
    model.model.eval()
    with torch.no_grad():
        output = model.model(sample_input)
    assert len(output) == 3, "Expected (mu, sigma, df)"


def test_forward_output_shapes(base_config, sample_input):
    config = MLPFStudentTConfig(**base_config)
    model = MLPFStudentTModel(model_config=config)
    model.model.eval()
    with torch.no_grad():
        mu, sigma, df = model.model(sample_input)
    batch = sample_input.size(0)
    horizon = base_config["forecast_horizon"]
    n_out = base_config["num_target_feature"]
    assert mu.shape == (batch, horizon, n_out)
    assert sigma.shape == (batch, horizon, n_out)


def test_sigma_positive(base_config, sample_input):
    config = MLPFStudentTConfig(**base_config)
    model = MLPFStudentTModel(model_config=config)
    model.model.eval()
    with torch.no_grad():
        _, sigma, _ = model.model(sample_input)
    assert (sigma > 0).all()


def test_df_above_min_df(base_config, sample_input):
    """Degrees of freedom must be clamped above min_df."""
    config = MLPFStudentTConfig(**base_config, min_df=2.5)
    model = MLPFStudentTModel(model_config=config)
    model.model.eval()
    with torch.no_grad():
        _, _, df = model.model(sample_input)
    assert (df >= 2.5).all()


def test_no_nan_in_output(base_config, sample_input):
    config = MLPFStudentTConfig(**base_config)
    model = MLPFStudentTModel(model_config=config)
    model.model.eval()
    with torch.no_grad():
        mu, sigma, df = model.model(sample_input)
    assert not torch.isnan(mu).any()
    assert not torch.isnan(sigma).any()
    assert not torch.isnan(df).any()


# ── Lifecycle Tests ────────────────────────────────────────────────────────────


def test_update_reinitialises_model(base_config):
    config = MLPFStudentTConfig(**base_config)
    model = MLPFStudentTModel(model_config=config)
    import optuna

    study = optuna.create_study(direction="minimize")
    trial = study.ask()

    with patch.object(MLPFStudentTConfig, "get_optuna_params", return_value=base_config):
        model.update(trial)

    assert isinstance(model.model_config, MLPFStudentTConfig)
    assert isinstance(model.model, MLPFStudentT)


def test_load_checkpoint_calls_load(base_config):
    config = MLPFStudentTConfig(**base_config)
    model = MLPFStudentTModel(model_config=config)
    with patch.object(model, "_load_checkpoints") as mock_load:
        model.load_checkpoint()
        mock_load.assert_called_once_with(model_instance=MLPFStudentT)


def test_load_checkpoint_sets_eval_mode(base_config):
    config = MLPFStudentTConfig(**base_config)
    model = MLPFStudentTModel(model_config=config)
    with patch.object(model, "_load_checkpoints"):
        model.load_checkpoint()
    assert not model.model.training


# ── Registry Test ──────────────────────────────────────────────────────────────


def test_registry_resolves_mlpfstudentt():
    from twiga.forecaster.registry import get_model

    model_cls, config_cls = get_model("mlpfstudentt", domain="nn")
    assert model_cls is MLPFStudentTModel
    assert config_cls is MLPFStudentTConfig
