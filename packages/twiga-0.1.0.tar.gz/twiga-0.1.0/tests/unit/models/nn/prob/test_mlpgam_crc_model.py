"""Unit tests for MLPGAMCRCConfig and MLPGAMCRCModel.

Network under test: MLPGAMCRC (MLPGAMNetwork + AdditiveCRCDistribution).
Config under test:  MLPGAMCRCConfig (extends MLPGAMConfig).

Key invariant: the backbone's additive mean (reshape of encode()) is used
directly — no mu_layer projection — to preserve the GAM decomposition.
"""

from __future__ import annotations

from unittest.mock import patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.distributions.nn.residual_conformal import AdditiveCRCDistribution
from twiga.models.nn.mlpgamcrc_model import MLPGAMCRCConfig, MLPGAMCRCModel
from twiga.models.nn.prob.mlpgam_crc import MLPGAMCRC

# ── Fixtures ───────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 64,
        "hidden_dim": 64,
        "num_layers": 1,
        "dropout": 0.0,
        "max_epochs": 5,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 8
    past = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future = base_config["num_future_covariates"] + base_config["num_calendar_features"]
    features = np.ones((batch_size, base_config["lookback_window_size"], past))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future))
    return torch.from_numpy(stack_features(past_features=features, future_covariates=covariates)).float()


# ── MLPGAMCRCConfig ────────────────────────────────────────────────────────────


def test_config_name(base_config):
    config = MLPGAMCRCConfig(**base_config)
    assert config.name == "mlpgamcrc"


def test_config_search_space_present(base_config):
    config = MLPGAMCRCConfig(**base_config)
    assert config.search_space is not None


def test_config_invalid_activation():
    with pytest.raises(ValidationError) as exc:
        MLPGAMCRCConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=168,
            activation_function="BadAct",
        )
    assert "activation_function" in str(exc.value)


def test_config_missing_required_field():
    """Omitting NN dimension fields defaults to 0 (sentinel for TwigaForecaster auto-fill)."""
    config = MLPGAMCRCConfig(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0


def test_config_lambda_lasso_default(base_config):
    config = MLPGAMCRCConfig(**base_config)
    assert config.lambda_lasso == 1e-6


# ── MLPGAMCRCModel ─────────────────────────────────────────────────────────────


def test_model_initialization(base_config):
    config = MLPGAMCRCConfig(**base_config)
    model = MLPGAMCRCModel(model_config=config)
    assert isinstance(model.model, MLPGAMCRC)
    assert model.model_config == config


def test_model_uses_additive_crc_head(base_config):
    """The distribution head must be AdditiveCRCDistribution (no mu_layer)."""
    config = MLPGAMCRCConfig(**base_config)
    model = MLPGAMCRCModel(model_config=config)
    head = model.model.model.head
    assert isinstance(head, AdditiveCRCDistribution)
    assert not hasattr(head, "mu_layer"), "Additive head must not have mu_layer"


def test_additive_invariant(base_config, sample_input):
    """encode() output reshaped == mu (the backbone's additive mean is used directly)."""
    config = MLPGAMCRCConfig(**base_config)
    model = MLPGAMCRCModel(model_config=config)
    net = model.model.model
    with torch.no_grad():
        z = net.backbone.encode(sample_input)
        mu, _ = net.head(z)
    horizon = base_config["forecast_horizon"]
    n_out = base_config["num_target_feature"]
    expected = z.view(z.size(0), horizon, n_out)
    assert torch.allclose(mu, expected), "mu must equal reshape(encode(x))"


def test_model_forward_output_shapes(base_config, sample_input):
    config = MLPGAMCRCConfig(**base_config)
    model = MLPGAMCRCModel(model_config=config)
    with torch.no_grad():
        mu, sigma = model.model(sample_input)
    batch = sample_input.size(0)
    horizon = base_config["forecast_horizon"]
    n_out = base_config["num_target_feature"]
    assert mu.shape == (batch, horizon, n_out)
    assert sigma.shape == (batch, horizon, n_out)


def test_sigma_positive(base_config, sample_input):
    config = MLPGAMCRCConfig(**base_config)
    model = MLPGAMCRCModel(model_config=config)
    with torch.no_grad():
        _, sigma = model.model(sample_input)
    assert (sigma > 0).all()


def test_no_nan_in_output(base_config, sample_input):
    config = MLPGAMCRCConfig(**base_config)
    model = MLPGAMCRCModel(model_config=config)
    with torch.no_grad():
        mu, sigma = model.model(sample_input)
    assert not torch.isnan(mu).any()
    assert not torch.isnan(sigma).any()


def test_encode_size_is_h_times_o(base_config):
    """MLPGAM encode_size == H * O (the additive backbone invariant)."""
    config = MLPGAMCRCConfig(**base_config)
    model = MLPGAMCRCModel(model_config=config)
    backbone = model.model.model.backbone
    expected = base_config["forecast_horizon"] * base_config["num_target_feature"]
    assert backbone.encode_size == expected


def test_model_update(base_config):
    config = MLPGAMCRCConfig(**base_config)
    model = MLPGAMCRCModel(model_config=config)
    import optuna

    study = optuna.create_study(direction="minimize")
    trial = study.ask()
    model.update(trial=trial)
    assert isinstance(model.model, MLPGAMCRC)


def test_load_checkpoint_calls_load(base_config):
    config = MLPGAMCRCConfig(**base_config)
    model = MLPGAMCRCModel(model_config=config)
    with patch.object(model, "_load_checkpoints") as mock_load:
        model.load_checkpoint()
        mock_load.assert_called_once_with(model_instance=MLPGAMCRC)
