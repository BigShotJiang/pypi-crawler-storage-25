import numpy as np
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.net.mlpfgam import MLPGAM, MLPGAMNetwork


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 10,
        "num_calendar_features": 3,
        "num_exogenous_features": 5,
        "num_future_covariates": 4,
        "forecast_horizon": 24,
        "lookback_window_size": 96,
        "embedding_size": 28,
        "embedding_type": None,
        "latent_size": 256,  # was: hidden_size (not a param on MLPGAMNetwork)
        "num_layers": 2,
        "activation_function": "SiLU",
        "out_activation_function": "Identity",
        "dropout": 0.25,
        "alpha": 0.1,
        "lambda_lasso": 1e-6,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 32
    past_features = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future_features = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )

    features = np.ones((batch_size, base_config["lookback_window_size"], past_features))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future_features))

    features = stack_features(past_features=features, future_covariates=covariates)
    return torch.from_numpy(features).float()


def test_network_initialization(base_config):
    """Test model initialization with valid parameters."""
    model = MLPGAMNetwork(**base_config)
    assert isinstance(model, MLPGAMNetwork)
    assert hasattr(model, "past_feature_transform")
    assert hasattr(model, "future_feature_transform")
    assert model.lambda_lasso == 1e-6


def test_no_future_covariates_initialization(base_config):
    """Test model initialization with zero future covariates."""
    args = base_config.copy()
    args["num_calendar_features"] = 0
    args["num_exogenous_features"] = 0
    args["num_future_covariates"] = 0
    model = MLPGAMNetwork(**args)
    assert not hasattr(model, "future_feature_transform")
    assert not hasattr(model, "horizon")


def test_forward_pass_shape(base_config, sample_input):
    """Test forward pass shape."""
    model = MLPGAMNetwork(**base_config)
    output = model(sample_input)
    expected_shape = (sample_input.shape[0], base_config["forecast_horizon"], base_config["num_target_feature"])
    assert output.shape == expected_shape


def test_lasso_penalty_with_covariates(base_config):
    """Test Lasso penalty with covariates."""
    model = MLPGAMNetwork(**base_config)
    penalty = model.lasso_penalty()
    past_weights = model.past_feature_transform.weight.abs().mean()
    future_weights = model.future_feature_transform.weight.abs().mean()
    expected = model.lambda_lasso * (past_weights + future_weights)
    assert torch.isclose(penalty, expected)


def test_lasso_penalty_without_covariates(base_config):
    """Test Lasso penalty without covariates."""
    args = base_config.copy()
    args["num_calendar_features"] = 0
    args["num_exogenous_features"] = 0
    args["num_future_covariates"] = 0
    model = MLPGAMNetwork(**args)
    penalty = model.lasso_penalty()
    past_weights = model.past_feature_transform.weight.abs().mean()
    expected = model.lambda_lasso * past_weights
    assert torch.isclose(penalty, expected)


def test_step_loss_computation(base_config, sample_input):
    """Test step function loss computation."""
    model = MLPGAMNetwork(**base_config)
    x = sample_input
    y = torch.randn(sample_input.shape[0], base_config["forecast_horizon"], base_config["num_target_feature"])
    batch = (x, y)
    loss, metric = model.step(batch, metric_fn=lambda x, y: x)
    assert torch.isclose(loss, metric)


def test_model_initialization(base_config):
    """Test MLPGAM wrapper initialization."""
    model = MLPGAM(**base_config)
    assert isinstance(model.model, MLPGAMNetwork)
