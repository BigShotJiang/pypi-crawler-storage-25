from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.mlpf_model import MLPFConfig, MLPFModel
from twiga.models.nn.net.mlpf import MLPF

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 128,
        "num_layers": 2,
        "activation_function": "SiLU",
        "max_epochs": 10,
        "optimizer_type": "adamw",
        "lr_scheduler_type": "multi_step",
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 32
    past_features = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future_features = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )

    features = np.ones((batch_size, base_config["lookback_window_size"], past_features))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future_features))

    features = stack_features(past_features=features, future_covariates=covariates)
    return torch.from_numpy(features).float()


# ── MLPFConfig Tests ──────────────────────────────────────────────────────────


def test_mlpfconfig_initialization(base_config):
    """Test valid MLPFConfig initialization."""
    config = MLPFConfig(**base_config)

    assert config.name == "mlpf"
    assert config.latent_size == 128
    assert config.search_space is not None


def test_invalid_activation_function():
    """Test that an unsupported activation function raises ValidationError."""
    with pytest.raises(ValidationError) as excinfo:
        MLPFConfig(
            num_target_feature=1,
            num_historical_features=2,
            forecast_horizon=24,
            lookback_window_size=168,
            activation_function="InvalidActivation",
        )
    assert "activation_function" in str(excinfo.value)


def test_missing_dims_default_to_zero():
    """Test that omitting NN dimension fields defaults to 0 (sentinel for TwigaForecaster auto-fill)."""
    config = MLPFConfig(
        num_historical_features=2,
        forecast_horizon=24,
        # num_target_feature and lookback_window_size intentionally omitted
    )
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0
    assert config.forecast_horizon == 24


# ── MLPFModel Tests ───────────────────────────────────────────────────────────


def test_mlpfmodel_initialization(base_config):
    """Test model initialization with valid config."""
    config = MLPFConfig(**base_config)
    model = MLPFModel(model_config=config)

    assert isinstance(model.model, MLPF)
    assert model.model_config == config


def test_forward_pass_shape(base_config, sample_input):
    """Test model forward pass output dimensions."""
    config = MLPFConfig(**base_config)
    model = MLPFModel(model_config=config)

    output = model.model(sample_input)
    assert output.shape == (
        sample_input.size(0),
        base_config["forecast_horizon"],
        base_config["num_target_feature"],
    )


@pytest.mark.parametrize("comb_type", ["attn-comb", "weighted-comb", "addition-comb"])
def test_combination_types(comb_type, base_config, sample_input):
    """Test all valid combination types produce finite, grad-tracked outputs."""
    base_config["combination_type"] = comb_type
    config = MLPFConfig(**base_config)
    model = MLPFModel(model_config=config)

    output = model.model(sample_input)
    assert not torch.isnan(output).any()
    assert output.requires_grad


# ── Device Compatibility ──────────────────────────────────────────────────────


def test_mlpfmodel_update(base_config):
    """update() re-initialises model with Optuna-suggested hyperparameters."""
    config = MLPFConfig(**base_config)
    model = MLPFModel(model_config=config)
    mock_trial = MagicMock()

    with patch.object(MLPFConfig, "get_optuna_params", return_value=base_config):
        model.update(mock_trial)

    assert isinstance(model.model_config, MLPFConfig)
    assert isinstance(model.model, MLPF)


def test_mlpfmodel_load_checkpoint(base_config):
    """load_checkpoint() delegates to _load_checkpoints and sets eval mode."""
    config = MLPFConfig(**base_config)
    model = MLPFModel(model_config=config)

    with patch.object(MLPFModel, "_load_checkpoints"):
        model.load_checkpoint()

    assert not model.model.training


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_gpu_compatibility(base_config, sample_input):
    """Test model operation on GPU."""
    config = MLPFConfig(**base_config)
    model = MLPFModel(model_config=config).cuda()

    output = model.model(sample_input.cuda())
    assert output.device.type == "cuda"
