from unittest.mock import patch

import numpy as np
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.net.mlpf import MLPF, MLPFNetwork


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 10,
        "num_calendar_features": 3,
        "num_exogenous_features": 5,
        "num_future_covariates": 2,
        "forecast_horizon": 24,
        "lookback_window_size": 96,
        "embedding_size": 28,
        "embedding_type": None,
        "value_embed_type": None,
        "combination_type": "attn-comb",
        "latent_size": 256,
        "num_layers": 2,
        "activation_function": "SiLU",
        "out_activation_function": "Identity",
        "dropout": 0.25,
        "alpha": 0.1,
        "num_attention_heads": 4,
        "metric": "mae",
        "max_epochs": 10,
        "optimizer_type": "adamw",
        "lr_scheduler_type": "multi_step",
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 32
    past_features = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future_features = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )

    features = np.ones((batch_size, base_config["lookback_window_size"], past_features))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future_features))

    features = stack_features(past_features=features, future_covariates=covariates)
    features = torch.from_numpy(features).float()

    targets = torch.randn(batch_size, base_config["forecast_horizon"], base_config["num_target_feature"])

    return features, targets


def test_model_initialization(base_config):
    """Test model initialization with valid parameters."""
    model = MLPF(**base_config)
    assert isinstance(model, MLPF)
    assert isinstance(model.model, MLPFNetwork)


@pytest.mark.parametrize("comb_type", ["attn-comb", "weighted-comb", "addition-comb"])
def test_combination_types(comb_type, base_config, sample_input):
    """Test all valid combination types."""
    base_config["combination_type"] = comb_type
    model = MLPF(**base_config)
    x, y = sample_input
    output = model.model(x)

    assert not torch.isnan(output).any()
    assert output.requires_grad  # Verify gradient tracking


def test_invalid_activation_function(base_config):
    """Test invalid activation function raises error."""
    base_config["activation_function"] = "InvalidActivation"

    with pytest.raises(ValueError) as excinfo:
        MLPF(**base_config)

    assert "Invalid activation_function" in str(excinfo.value)


def test_validation_step(base_config, sample_input):
    """Test validation step execution and logging."""
    model = MLPF(**base_config)
    batch = sample_input

    with patch.object(model, "log"):
        model.validation_step(batch, 0)


def test_configure_optimizers(base_config):
    """Test optimizer and scheduler configuration."""
    model = MLPF(**base_config)
    optimizers, schedulers = model.configure_optimizers()

    assert len(optimizers) == 1
    assert isinstance(optimizers[0], torch.optim.AdamW)
    assert len(schedulers) == 1


@pytest.mark.parametrize("device", ["cpu", "cuda"])
def test_device_compatibility(base_config, sample_input, device):
    """Test model operation on different devices."""
    if device == "cuda" and not torch.cuda.is_available():
        pytest.skip("CUDA not available")

    model = MLPF(**base_config).to(device)
    x, y = sample_input

    output = model(x)
    assert output.device.type == device
