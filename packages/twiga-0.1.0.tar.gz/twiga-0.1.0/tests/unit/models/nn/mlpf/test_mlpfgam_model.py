from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.mlpgam_model import MLPGAMConfig, MLPGAMModel
from twiga.models.nn.net.mlpfgam import MLPGAM

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 128,  # was: hidden_size (not a field on MLPGAMConfig)
        "num_layers": 2,
        "activation_function": "SiLU",
        # learning_rate removed — not a field on MLPGAMConfig; use optimizer_params instead
        "max_epochs": 10,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 32
    past_features = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future_features = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )

    features = np.ones((batch_size, base_config["lookback_window_size"], past_features))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future_features))

    features = stack_features(past_features=features, future_covariates=covariates)
    return torch.from_numpy(features).float()


# ── MLPGAMConfig Tests ────────────────────────────────────────────────────────


def test_mlpgamconfig_initialization(base_config):
    """Test valid MLPGAMConfig initialization."""
    config = MLPGAMConfig(**base_config)

    assert config.name == "mlpgam"
    assert config.latent_size == 128
    assert config.lambda_lasso == 1e-6
    assert config.search_space is not None


def test_invalid_activation_function():
    """Test that an unsupported activation function raises ValidationError."""
    with pytest.raises(ValidationError) as excinfo:
        MLPGAMConfig(
            num_target_feature=1,
            num_historical_features=2,
            forecast_horizon=24,
            lookback_window_size=168,
            activation_function="InvalidActivation",
        )
    assert "activation_function" in str(excinfo.value)


def test_missing_required_field():
    """Omitting NN dimension fields defaults to 0 (sentinel for TwigaForecaster auto-fill)."""
    config = MLPGAMConfig(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0


def test_mlpgammodel_initialization(base_config):
    """Test model initialization with valid config."""
    config = MLPGAMConfig(**base_config)
    model = MLPGAMModel(model_config=config)

    assert isinstance(model.model, MLPGAM)
    assert model.model_config == config


def test_forward_pass_shape(base_config, sample_input):
    """Test model forward pass output dimensions."""
    config = MLPGAMConfig(**base_config)
    model = MLPGAMModel(model_config=config)

    output = model.model(sample_input)
    assert output.shape == (
        sample_input.size(0),
        base_config["forecast_horizon"],
        base_config["num_target_feature"],
    )


@pytest.mark.parametrize("lambda_lasso", [0.0, 1e-6, 1e-4])
def test_lambda_lasso_values(lambda_lasso, base_config, sample_input):
    """Test model trains without error across a range of lasso penalties."""
    base_config["lambda_lasso"] = lambda_lasso
    config = MLPGAMConfig(**base_config)
    model = MLPGAMModel(model_config=config)

    output = model.model(sample_input)
    assert not torch.isnan(output).any()


# ── Device Compatibility ──────────────────────────────────────────────────────


def test_mlpgammodel_update(base_config):
    """update() re-initialises model with Optuna-suggested hyperparameters."""
    config = MLPGAMConfig(**base_config)
    model = MLPGAMModel(model_config=config)

    mock_trial = MagicMock()
    with patch.object(config.__class__, "get_optuna_params", return_value=base_config) as mock_get:
        model.update(mock_trial)
        mock_get.assert_called_once_with(trial=mock_trial)

    assert isinstance(model.model_config, MLPGAMConfig)
    assert isinstance(model.model, MLPGAM)


def test_mlpgammodel_load_checkpoint(base_config):
    """load_checkpoint() delegates to _load_checkpoints and sets eval mode."""
    config = MLPGAMConfig(**base_config)
    model = MLPGAMModel(model_config=config)

    with patch.object(MLPGAMModel, "_load_checkpoints") as mock_load:
        model.load_checkpoint()
        mock_load.assert_called_once_with(model_instance=MLPGAM)

    # After load_checkpoint the model must be in eval mode
    assert not model.model.training


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_gpu_compatibility(base_config, sample_input):
    """Test model operation on GPU."""
    config = MLPGAMConfig(**base_config)
    model = MLPGAMModel(model_config=config).cuda()

    output = model.model(sample_input.cuda())
    assert output.device.type == "cuda"
