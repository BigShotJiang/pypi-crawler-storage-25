"""Unit tests for probabilistic RNN model wrappers."""

from unittest.mock import MagicMock, patch

import numpy as np
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.prob.rnn_parametric import (
    RNNBeta,
    RNNGamma,
    RNNLaplace,
    RNNLogNormal,
    RNNNormal,
    RNNStudentT,
)
from twiga.models.nn.prob.rnn_qr import RNNFPQR, RNNQR
from twiga.models.nn.rnnbeta_model import RNNBetaConfig, RNNBetaModel
from twiga.models.nn.rnngamma_model import RNNGammaConfig, RNNGammaModel
from twiga.models.nn.rnnlaplace_model import RNNLaplaceConfig, RNNLaplaceModel
from twiga.models.nn.rnnlognormal_model import RNNLogNormalConfig, RNNLogNormalModel
from twiga.models.nn.rnnnormal_model import RNNNormalConfig, RNNNormalModel
from twiga.models.nn.rnnqr_model import RNNFPQRConfig, RNNFPQRModel, RNNQRConfig, RNNQRModel
from twiga.models.nn.rnnstudentt_model import RNNStudentTConfig, RNNStudentTModel

# ── Fixtures ──────────────────────────────────────────────────────────────────

BASE_DIMS = {
    "num_target_feature": 1,
    "num_historical_features": 5,
    "num_calendar_features": 2,
    "num_exogenous_features": 3,
    "num_future_covariates": 0,
    "forecast_horizon": 12,
    "lookback_window_size": 48,
    "hidden_size": 32,
    "n_layers": 1,
    "cell_type": "gru",
    "bidirectional": False,
    "dropout": 0.1,
    "alpha": 0.1,
    "max_epochs": 2,
    "optimizer_type": "adamw",
    "lr_scheduler_type": "multi_step",
}


@pytest.fixture
def base_config():
    return dict(BASE_DIMS)


@pytest.fixture
def sample_input(base_config):
    batch_size = 4
    past_features = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future_features = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    features = np.ones((batch_size, base_config["lookback_window_size"], past_features))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future_features))
    stacked = stack_features(past_features=features, future_covariates=covariates)
    return torch.from_numpy(stacked).float()


# ── Parametric distribution helpers ──────────────────────────────────────────


PARAMETRIC_CLASSES = [
    (RNNNormalConfig, RNNNormalModel, RNNNormal, "rnnnormal"),
    (RNNLaplaceConfig, RNNLaplaceModel, RNNLaplace, "rnnlaplace"),
    (RNNLogNormalConfig, RNNLogNormalModel, RNNLogNormal, "rnnlognormal"),
    (RNNGammaConfig, RNNGammaModel, RNNGamma, "rnngamma"),
    (RNNBetaConfig, RNNBetaModel, RNNBeta, "rnnbeta"),
    (RNNStudentTConfig, RNNStudentTModel, RNNStudentT, "rnnstudentt"),
]


# ── Config Tests ──────────────────────────────────────────────────────────────


@pytest.mark.parametrize("config_cls,_model_cls,_prob_cls,expected_name", PARAMETRIC_CLASSES)
def test_parametric_config_name(config_cls, _model_cls, _prob_cls, expected_name, base_config):
    """Each config carries the correct fixed name identifier."""
    config = config_cls(**base_config)
    assert config.name == expected_name


@pytest.mark.parametrize("config_cls,_model_cls,_prob_cls,_name", PARAMETRIC_CLASSES)
def test_parametric_config_search_space(config_cls, _model_cls, _prob_cls, _name, base_config):
    """Each config exposes a non-None search space."""
    config = config_cls(**base_config)
    assert config.search_space is not None


# ── Model Instantiation Tests ─────────────────────────────────────────────────


@pytest.mark.parametrize("config_cls,model_cls,prob_cls,_name", PARAMETRIC_CLASSES)
def test_parametric_model_instantiation(config_cls, model_cls, prob_cls, _name, base_config):
    """Each Model wrapper instantiates the correct probabilistic Lightning module."""
    config = config_cls(**base_config)
    wrapper = model_cls(model_config=config)
    assert isinstance(wrapper.model, prob_cls)
    assert wrapper.model_config == config


# ── Forward / Encode Tests ────────────────────────────────────────────────────


@pytest.mark.parametrize("config_cls,model_cls,_prob_cls,_name", PARAMETRIC_CLASSES)
def test_parametric_encode_shape(config_cls, model_cls, _prob_cls, _name, base_config, sample_input):
    """encode() returns (B, hidden_size) latent vector."""
    config = config_cls(**base_config)
    wrapper = model_cls(model_config=config)
    wrapper.model.eval()
    with torch.no_grad():
        z = wrapper.model.model.backbone.encode(sample_input)
    assert z.shape == (sample_input.size(0), base_config["hidden_size"])


@pytest.mark.parametrize("config_cls,model_cls,_prob_cls,_name", PARAMETRIC_CLASSES)
def test_parametric_no_nan_output(config_cls, model_cls, _prob_cls, _name, base_config, sample_input):
    """Distribution parameter outputs contain no NaN values."""
    config = config_cls(**base_config)
    wrapper = model_cls(model_config=config)
    wrapper.model.eval()
    with torch.no_grad():
        z = wrapper.model.model.backbone.encode(sample_input)
        out = wrapper.model.model.head(z)
    if isinstance(out, tuple):
        for t in out:
            assert not torch.isnan(t).any(), "NaN in distribution parameter output"
    else:
        assert not torch.isnan(out).any()


# ── Update Tests ──────────────────────────────────────────────────────────────


@pytest.mark.parametrize("config_cls,model_cls,prob_cls,_name", PARAMETRIC_CLASSES)
def test_parametric_model_update(config_cls, model_cls, prob_cls, _name, base_config):
    """update() re-instantiates the probabilistic model from Optuna trial params."""
    config = config_cls(**base_config)
    wrapper = model_cls(model_config=config)
    mock_trial = MagicMock()

    with patch.object(config_cls, "get_optuna_params", return_value=base_config):
        wrapper.update(mock_trial)

    assert isinstance(wrapper.model_config, config_cls)
    assert isinstance(wrapper.model, prob_cls)


# ── Checkpoint Tests ──────────────────────────────────────────────────────────


@pytest.mark.parametrize("config_cls,model_cls,_prob_cls,_name", PARAMETRIC_CLASSES)
def test_parametric_load_checkpoint(config_cls, model_cls, _prob_cls, _name, base_config):
    """load_checkpoint() calls _load_checkpoints and sets eval mode."""
    config = config_cls(**base_config)
    wrapper = model_cls(model_config=config)

    with patch.object(model_cls, "_load_checkpoints"):
        wrapper.load_checkpoint()

    assert not wrapper.model.training


# ── RNNQR Tests ───────────────────────────────────────────────────────────────


@pytest.fixture
def qr_config(base_config):
    return RNNQRConfig(**base_config)


@pytest.fixture
def fpqr_config(base_config):
    return RNNFPQRConfig(**base_config)


def test_rnnqr_config_name(qr_config):
    assert qr_config.name == "rnnqr"


def test_rnnqr_model_instantiation(qr_config):
    """RNNQRModel instantiates an RNNQR Lightning module."""
    wrapper = RNNQRModel(model_config=qr_config)
    assert isinstance(wrapper.model, RNNQR)


def test_rnnqr_forward_shape(qr_config, sample_input):
    """RNNQR forward returns a dict with loc and quantiles."""
    wrapper = RNNQRModel(model_config=qr_config)
    wrapper.model.eval()
    with torch.no_grad():
        result = wrapper.model(sample_input)
    assert "loc" in result
    assert "quantiles" in result
    assert result["loc"].shape[0] == sample_input.size(0)
    assert not torch.isnan(result["loc"]).any()
    assert not torch.isnan(result["quantiles"]).any()


def test_rnnqr_update(qr_config, base_config):
    """RNNQRModel.update() re-instantiates from Optuna trial params."""
    wrapper = RNNQRModel(model_config=qr_config)
    mock_trial = MagicMock()

    with patch.object(RNNQRConfig, "get_optuna_params", return_value=base_config):
        wrapper.update(mock_trial)

    assert isinstance(wrapper.model_config, RNNQRConfig)
    assert isinstance(wrapper.model, RNNQR)


def test_rnnqr_load_checkpoint(qr_config):
    wrapper = RNNQRModel(model_config=qr_config)

    with patch.object(RNNQRModel, "_load_checkpoints"):
        wrapper.load_checkpoint()

    assert not wrapper.model.training


# ── RNNFPQR Tests ─────────────────────────────────────────────────────────────


def test_rnnfpqr_config_name(fpqr_config):
    assert fpqr_config.name == "rnnfpqr"


def test_rnnfpqr_model_instantiation(fpqr_config):
    """RNNFPQRModel instantiates an RNNFPQR Lightning module."""
    wrapper = RNNFPQRModel(model_config=fpqr_config)
    assert isinstance(wrapper.model, RNNFPQR)


def test_rnnfpqr_forward_shape(fpqr_config, sample_input):
    """RNNFPQR forward returns a dict with loc and quantiles."""
    wrapper = RNNFPQRModel(model_config=fpqr_config)
    wrapper.model.eval()
    with torch.no_grad():
        result = wrapper.model(sample_input)
    assert "loc" in result
    assert "quantiles" in result
    assert result["loc"].shape[0] == sample_input.size(0)
    assert not torch.isnan(result["loc"]).any()
    assert not torch.isnan(result["quantiles"]).any()


def test_rnnfpqr_update(fpqr_config, base_config):
    """RNNFPQRModel.update() re-instantiates from Optuna trial params."""
    wrapper = RNNFPQRModel(model_config=fpqr_config)
    mock_trial = MagicMock()

    with patch.object(RNNFPQRConfig, "get_optuna_params", return_value=base_config):
        wrapper.update(mock_trial)

    assert isinstance(wrapper.model_config, RNNFPQRConfig)
    assert isinstance(wrapper.model, RNNFPQR)


def test_rnnfpqr_load_checkpoint(fpqr_config):
    wrapper = RNNFPQRModel(model_config=fpqr_config)

    with patch.object(RNNFPQRModel, "_load_checkpoints"):
        wrapper.load_checkpoint()

    assert not wrapper.model.training


# ── GPU ───────────────────────────────────────────────────────────────────────


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_rnnqr_gpu_compatibility(qr_config, sample_input):
    """RNNQR forward pass works on GPU."""
    wrapper = RNNQRModel(model_config=qr_config)
    wrapper.model.cuda()
    result = wrapper.model(sample_input.cuda())
    assert result["loc"].device.type == "cuda"
