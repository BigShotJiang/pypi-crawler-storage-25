from unittest.mock import patch

import numpy as np
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.net.rnn import RNN, RNNForecastNetwork

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 5,
        "num_calendar_features": 2,
        "num_exogenous_features": 3,
        "num_future_covariates": 0,
        "forecast_horizon": 24,
        "lookback_window_size": 96,
        "hidden_size": 64,
        "n_layers": 2,
        "cell_type": "gru",
        "bidirectional": False,
        "dropout": 0.25,
        "alpha": 0.1,
        "out_activation_function": "Identity",
        "metric": "mae",
        "max_epochs": 5,
        "optimizer_type": "adamw",
        "lr_scheduler_type": "multi_step",
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 8
    past_features = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future_features = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )

    features = np.ones((batch_size, base_config["lookback_window_size"], past_features))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future_features))

    stacked = stack_features(past_features=features, future_covariates=covariates)
    return torch.from_numpy(stacked).float()


# ── RNNForecastNetwork Tests ──────────────────────────────────────────────────


def test_network_initialization(base_config):
    """Network initialises with correct submodules and sizes."""
    cfg = base_config
    net = RNNForecastNetwork(
        num_target_feature=cfg["num_target_feature"],
        num_historical_features=cfg["num_historical_features"],
        num_calendar_features=cfg["num_calendar_features"],
        num_exogenous_features=cfg["num_exogenous_features"],
        num_future_covariates=cfg["num_future_covariates"],
        forecast_horizon=cfg["forecast_horizon"],
        lookback_window_size=cfg["lookback_window_size"],
        hidden_size=cfg["hidden_size"],
        n_layers=cfg["n_layers"],
        cell_type=cfg["cell_type"],
    )
    assert isinstance(net.rnn, torch.nn.GRU)
    assert net._encode_size == cfg["hidden_size"]
    assert net.num_past_features == (
        cfg["num_target_feature"]
        + cfg["num_historical_features"]
        + cfg["num_exogenous_features"]
        + cfg["num_calendar_features"]
    )


def test_forward_output_shape(base_config, sample_input):
    """forward() returns tensor of shape (B, horizon, n_targets)."""
    cfg = base_config
    net = RNNForecastNetwork(
        num_target_feature=cfg["num_target_feature"],
        num_historical_features=cfg["num_historical_features"],
        num_calendar_features=cfg["num_calendar_features"],
        num_exogenous_features=cfg["num_exogenous_features"],
        num_future_covariates=cfg["num_future_covariates"],
        forecast_horizon=cfg["forecast_horizon"],
        lookback_window_size=cfg["lookback_window_size"],
        hidden_size=cfg["hidden_size"],
    )
    out = net(sample_input)
    assert out.shape == (sample_input.size(0), cfg["forecast_horizon"], cfg["num_target_feature"])
    assert not torch.isnan(out).any()


def test_forward_gradient_tracking(base_config, sample_input):
    """Output tracks gradients (enables backprop)."""
    cfg = base_config
    net = RNNForecastNetwork(
        num_target_feature=cfg["num_target_feature"],
        num_historical_features=cfg["num_historical_features"],
        num_calendar_features=cfg["num_calendar_features"],
        num_exogenous_features=cfg["num_exogenous_features"],
        num_future_covariates=cfg["num_future_covariates"],
        forecast_horizon=cfg["forecast_horizon"],
        lookback_window_size=cfg["lookback_window_size"],
        hidden_size=cfg["hidden_size"],
    )
    out = net(sample_input)
    assert out.requires_grad


def test_encode_output_shape(base_config, sample_input):
    """encode() returns latent vector of shape (B, encode_size)."""
    cfg = base_config
    net = RNNForecastNetwork(
        num_target_feature=cfg["num_target_feature"],
        num_historical_features=cfg["num_historical_features"],
        num_calendar_features=cfg["num_calendar_features"],
        num_exogenous_features=cfg["num_exogenous_features"],
        num_future_covariates=cfg["num_future_covariates"],
        forecast_horizon=cfg["forecast_horizon"],
        lookback_window_size=cfg["lookback_window_size"],
        hidden_size=cfg["hidden_size"],
    )
    enc = net.encode(sample_input)
    assert enc.shape == (sample_input.size(0), net._encode_size)


@pytest.mark.parametrize("cell_type", ["gru", "lstm"])
def test_cell_types(cell_type, base_config, sample_input):
    """Both GRU and LSTM cell types produce correctly shaped output."""
    cfg = base_config
    net = RNNForecastNetwork(
        num_target_feature=cfg["num_target_feature"],
        num_historical_features=cfg["num_historical_features"],
        num_calendar_features=cfg["num_calendar_features"],
        num_exogenous_features=cfg["num_exogenous_features"],
        num_future_covariates=cfg["num_future_covariates"],
        forecast_horizon=cfg["forecast_horizon"],
        lookback_window_size=cfg["lookback_window_size"],
        hidden_size=cfg["hidden_size"],
        cell_type=cell_type,
    )
    expected_rnn_cls = torch.nn.GRU if cell_type == "gru" else torch.nn.LSTM
    assert isinstance(net.rnn, expected_rnn_cls)

    out = net(sample_input)
    assert out.shape == (sample_input.size(0), cfg["forecast_horizon"], cfg["num_target_feature"])


def test_bidirectional_doubles_encode_size(base_config):
    """Bidirectional flag doubles _encode_size."""
    cfg = base_config
    kwargs = {
        "num_target_feature": cfg["num_target_feature"],
        "num_historical_features": cfg["num_historical_features"],
        "num_calendar_features": cfg["num_calendar_features"],
        "num_exogenous_features": cfg["num_exogenous_features"],
        "num_future_covariates": cfg["num_future_covariates"],
        "forecast_horizon": cfg["forecast_horizon"],
        "lookback_window_size": cfg["lookback_window_size"],
        "hidden_size": cfg["hidden_size"],
    }
    uni = RNNForecastNetwork(**kwargs, bidirectional=False)
    bi = RNNForecastNetwork(**kwargs, bidirectional=True)
    assert bi._encode_size == 2 * uni._encode_size


def test_bidirectional_forward_shape(base_config, sample_input):
    """Bidirectional network still produces (B, horizon, n_targets)."""
    cfg = base_config
    net = RNNForecastNetwork(
        num_target_feature=cfg["num_target_feature"],
        num_historical_features=cfg["num_historical_features"],
        num_calendar_features=cfg["num_calendar_features"],
        num_exogenous_features=cfg["num_exogenous_features"],
        num_future_covariates=cfg["num_future_covariates"],
        forecast_horizon=cfg["forecast_horizon"],
        lookback_window_size=cfg["lookback_window_size"],
        hidden_size=cfg["hidden_size"],
        bidirectional=True,
    )
    out = net(sample_input)
    assert out.shape == (sample_input.size(0), cfg["forecast_horizon"], cfg["num_target_feature"])


# ── RNN (Lightning wrapper) Tests ─────────────────────────────────────────────


def test_rnn_model_initialization(base_config):
    """RNN Lightning wrapper initialises with correct network and attributes."""
    cfg = base_config
    model = RNN(**cfg)
    assert isinstance(model.model, RNNForecastNetwork)
    assert model.n_out == cfg["num_target_feature"]


def test_rnn_validation_step(base_config, sample_input):
    """validation_step() runs without error."""
    cfg = base_config
    model = RNN(**cfg)
    targets = torch.randn(
        sample_input.size(0),
        cfg["forecast_horizon"],
        cfg["num_target_feature"],
    )
    with patch.object(model, "log"):
        model.validation_step((sample_input, targets), 0)


def test_rnn_configure_optimizers(base_config):
    """configure_optimizers() returns one optimizer and one scheduler."""
    model = RNN(**base_config)
    optimizers, schedulers = model.configure_optimizers()
    assert len(optimizers) == 1
    assert isinstance(optimizers[0], torch.optim.AdamW)
    assert len(schedulers) == 1


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_gpu_compatibility(base_config, sample_input):
    """Model forward pass works on GPU."""
    model = RNN(**base_config).cuda()
    out = model.model(sample_input.cuda())
    assert out.device.type == "cuda"
