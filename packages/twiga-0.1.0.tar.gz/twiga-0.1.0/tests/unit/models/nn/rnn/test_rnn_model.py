from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.net.rnn import RNN
from twiga.models.nn.rnn_model import RNNConfig, RNNModel

# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 5,
        "num_calendar_features": 2,
        "num_exogenous_features": 3,
        "num_future_covariates": 0,
        "forecast_horizon": 24,
        "lookback_window_size": 96,
        "hidden_size": 64,
        "n_layers": 2,
        "cell_type": "gru",
        "bidirectional": False,
        "dropout": 0.25,
        "max_epochs": 5,
        "optimizer_type": "adamw",
        "lr_scheduler_type": "multi_step",
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 8
    past_features = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future_features = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    features = np.ones((batch_size, base_config["lookback_window_size"], past_features))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future_features))
    stacked = stack_features(past_features=features, future_covariates=covariates)
    return torch.from_numpy(stacked).float()


# ── RNNConfig Tests ───────────────────────────────────────────────────────────


def test_config_initialization(base_config):
    """RNNConfig initialises with correct defaults and identifier."""
    config = RNNConfig(**base_config)
    assert config.name == "rnn"
    assert config.hidden_size == 64
    assert config.cell_type == "gru"
    assert config.search_space is not None


def test_config_defaults_to_zero_dims():
    """Omitting dimension fields defaults to 0 (auto-filled by TwigaForecaster)."""
    config = RNNConfig(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0
    assert config.forecast_horizon == 24


def test_config_invalid_cell_type():
    """Invalid cell_type raises ValidationError."""
    with pytest.raises(ValidationError):
        RNNConfig(cell_type="transformer")


@pytest.mark.parametrize("cell_type", ["gru", "lstm"])
def test_config_valid_cell_types(cell_type, base_config):
    """Both cell_type values are accepted."""
    base_config["cell_type"] = cell_type
    config = RNNConfig(**base_config)
    assert config.cell_type == cell_type


# ── RNNModel Tests ────────────────────────────────────────────────────────────


def test_model_initialization(base_config):
    """RNNModel instantiates a RNN Lightning model."""
    config = RNNConfig(**base_config)
    model = RNNModel(model_config=config)
    assert isinstance(model.model, RNN)
    assert model.model_config == config


def test_forward_pass_shape(base_config, sample_input):
    """Forward pass returns (B, horizon, n_targets)."""
    config = RNNConfig(**base_config)
    model = RNNModel(model_config=config)
    out = model.model(sample_input)
    assert out.shape == (
        sample_input.size(0),
        base_config["forecast_horizon"],
        base_config["num_target_feature"],
    )
    assert not torch.isnan(out).any()


def test_model_update(base_config):
    """update() re-initialises model from Optuna trial params."""
    config = RNNConfig(**base_config)
    model = RNNModel(model_config=config)
    mock_trial = MagicMock()

    with patch.object(RNNConfig, "get_optuna_params", return_value=base_config):
        model.update(mock_trial)

    assert isinstance(model.model_config, RNNConfig)
    assert isinstance(model.model, RNN)


def test_model_load_checkpoint(base_config):
    """load_checkpoint() delegates to _load_checkpoints and sets eval mode."""
    config = RNNConfig(**base_config)
    model = RNNModel(model_config=config)

    with patch.object(RNNModel, "_load_checkpoints"):
        model.load_checkpoint()

    assert not model.model.training


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_gpu_compatibility(base_config, sample_input):
    """Model forward pass works on GPU."""
    config = RNNConfig(**base_config)
    model = RNNModel(model_config=config)
    model.model.cuda()
    out = model.model(sample_input.cuda())
    assert out.device.type == "cuda"
