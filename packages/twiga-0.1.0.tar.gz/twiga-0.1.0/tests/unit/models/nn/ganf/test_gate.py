"""Tests for twiga.models.nn.ganf.gates.

Covers:
    - _assert_1d: shape validation
    - compute_active_gate: sigmoid and tanh gate types, clamping, gradient
      flow, determinism, unknown type error
    - initialise_gate: single-channel, multi-channel, scale independence,
      shape, dtype, value bounds
"""

from __future__ import annotations

import pytest
import torch

from twiga.models.nn.net.ganf.gates import _assert_1d, compute_active_gate, initialise_gate

# ─────────────────────────────────────────────────────────────────────────────
# Shared fixtures
# ─────────────────────────────────────────────────────────────────────────────

EPS = 1e-4
GATE_SCALE = 5.0

ALL_GATE_TYPES = ["sigmoid", "tanh"]


@pytest.fixture
def zero_logits() -> torch.Tensor:
    return torch.zeros(8)


@pytest.fixture
def pos_logits() -> torch.Tensor:
    return torch.tensor([0.5, 1.0, 2.0, 5.0])


@pytest.fixture
def mixed_logits() -> torch.Tensor:
    return torch.tensor([-3.0, -1.0, 0.0, 1.0, 3.0])


# ─────────────────────────────────────────────────────────────────────────────
# _assert_1d
# ─────────────────────────────────────────────────────────────────────────────


class TestAssert1d:
    def test_accepts_1d(self):
        _assert_1d(torch.zeros(5))

    def test_accepts_1d_size_one(self):
        _assert_1d(torch.zeros(1))

    @pytest.mark.parametrize("shape", [(3, 4), (2, 3, 4), (1, 1)])
    def test_rejects_non_1d(self, shape):
        with pytest.raises(ValueError, match="must be 1D"):
            _assert_1d(torch.zeros(shape))

    def test_error_message_contains_name(self):
        with pytest.raises(ValueError, match="my_tensor"):
            _assert_1d(torch.zeros(2, 3), name="my_tensor")

    def test_error_message_contains_shape(self):
        with pytest.raises(ValueError, match=r"\(2, 3\)"):
            _assert_1d(torch.zeros(2, 3))

    def test_rejects_0d_scalar(self):
        with pytest.raises(ValueError, match="must be 1D"):
            _assert_1d(torch.tensor(1.0))


# ─────────────────────────────────────────────────────────────────────────────
# compute_active_gate — shared contract (both gate types)
# ─────────────────────────────────────────────────────────────────────────────


class TestComputeActiveGateContract:
    """Properties that must hold for every supported gate type."""

    @pytest.mark.parametrize("gate_type", ALL_GATE_TYPES)
    def test_output_shape_matches_input(self, mixed_logits, gate_type):
        out = compute_active_gate(mixed_logits, gate_type=gate_type)
        assert out.shape == mixed_logits.shape

    @pytest.mark.parametrize("gate_type", ALL_GATE_TYPES)
    def test_output_within_eps_bounds(self, mixed_logits, gate_type):
        out = compute_active_gate(mixed_logits, gate_type=gate_type, eps=EPS)
        assert (out >= EPS).all(), f"{gate_type}: value below eps"
        assert (out <= 1.0 - EPS).all(), f"{gate_type}: value above 1-eps"

    @pytest.mark.parametrize("gate_type", ALL_GATE_TYPES)
    def test_output_is_1d(self, mixed_logits, gate_type):
        out = compute_active_gate(mixed_logits, gate_type=gate_type)
        assert out.dim() == 1

    @pytest.mark.parametrize("gate_type", ALL_GATE_TYPES)
    def test_rejects_2d_input(self, gate_type):
        with pytest.raises(ValueError, match="must be 1D"):
            compute_active_gate(torch.zeros(3, 4), gate_type=gate_type)

    @pytest.mark.parametrize("gate_type", ALL_GATE_TYPES)
    def test_rejects_0d_input(self, gate_type):
        with pytest.raises(ValueError, match="must be 1D"):
            compute_active_gate(torch.tensor(1.0), gate_type=gate_type)

    @pytest.mark.parametrize("gate_type", ALL_GATE_TYPES)
    def test_gradients_flow(self, mixed_logits, gate_type):
        logits = mixed_logits.clone().requires_grad_(True)
        out = compute_active_gate(logits, gate_type=gate_type)
        out.sum().backward()
        assert logits.grad is not None
        assert not torch.isnan(logits.grad).any()

    @pytest.mark.parametrize("gate_type", ALL_GATE_TYPES)
    def test_deterministic(self, mixed_logits, gate_type):
        out1 = compute_active_gate(mixed_logits, gate_type=gate_type)
        out2 = compute_active_gate(mixed_logits, gate_type=gate_type)
        assert torch.allclose(out1, out2)

    @pytest.mark.parametrize("gate_type", ALL_GATE_TYPES)
    def test_custom_eps_respected(self, mixed_logits, gate_type):
        custom_eps = 0.1
        out = compute_active_gate(mixed_logits, gate_type=gate_type, eps=custom_eps)
        assert (out >= custom_eps).all()
        assert (out <= 1.0 - custom_eps).all()

    def test_unknown_gate_type_raises(self, mixed_logits):
        with pytest.raises(ValueError, match="Unknown gate_type"):
            compute_active_gate(mixed_logits, gate_type="bad_type")

    def test_unknown_gate_type_error_mentions_supported(self, mixed_logits):
        with pytest.raises(ValueError, match="sigmoid"):
            compute_active_gate(mixed_logits, gate_type="bad_type")


# ─────────────────────────────────────────────────────────────────────────────
# compute_active_gate — sigmoid
# ─────────────────────────────────────────────────────────────────────────────


class TestSigmoidGate:
    def test_zero_logit_gives_half(self, zero_logits):
        out = compute_active_gate(zero_logits, gate_type="sigmoid", gate_scale=GATE_SCALE)
        assert torch.allclose(out, torch.full_like(out, 0.5), atol=1e-5)

    def test_large_positive_logit_near_one(self):
        out = compute_active_gate(torch.tensor([10.0]), gate_type="sigmoid", gate_scale=GATE_SCALE)
        assert out[0] > 0.99

    def test_large_negative_logit_near_zero(self):
        out = compute_active_gate(torch.tensor([-10.0]), gate_type="sigmoid", gate_scale=GATE_SCALE)
        assert out[0] < 0.01

    def test_monotonically_increasing(self, pos_logits):
        out = compute_active_gate(pos_logits, gate_type="sigmoid", gate_scale=GATE_SCALE)
        assert (out[1:] >= out[:-1]).all()

    def test_scale_sharpens_gate(self):
        logits = torch.tensor([0.5])
        low_scale = compute_active_gate(logits, gate_type="sigmoid", gate_scale=1.0)
        hi_scale = compute_active_gate(logits, gate_type="sigmoid", gate_scale=10.0)
        assert hi_scale[0] > low_scale[0]

    def test_antisymmetry(self, mixed_logits):
        """sigmoid(-x*s) + sigmoid(x*s) == 1 before clamping."""
        pos = compute_active_gate(mixed_logits.abs(), gate_type="sigmoid", gate_scale=1.0, eps=0.0)
        neg = compute_active_gate(-mixed_logits.abs(), gate_type="sigmoid", gate_scale=1.0, eps=0.0)
        assert torch.allclose(pos + neg, torch.ones_like(pos), atol=1e-5)

    def test_numerical_values(self):
        logits = torch.tensor([0.0, 1.0, -1.0])
        out = compute_active_gate(logits, gate_type="sigmoid", gate_scale=5.0, eps=0.0)
        expected = torch.sigmoid(logits * 5.0)
        assert torch.allclose(out, expected, atol=1e-5)


# ─────────────────────────────────────────────────────────────────────────────
# compute_active_gate — tanh
# ─────────────────────────────────────────────────────────────────────────────


class TestTanhGate:
    def test_zero_logit_gives_half(self, zero_logits):
        """tanh(0 * s * 0.5) = 0  ->  0.5 * (0 + 1) = 0.5."""
        out = compute_active_gate(zero_logits, gate_type="tanh", gate_scale=GATE_SCALE)
        assert torch.allclose(out, torch.full_like(out, 0.5), atol=1e-5)

    def test_large_positive_logit_near_one(self):
        out = compute_active_gate(torch.tensor([10.0]), gate_type="tanh", gate_scale=GATE_SCALE)
        assert out[0] > 0.99

    def test_large_negative_logit_near_zero(self):
        out = compute_active_gate(torch.tensor([-10.0]), gate_type="tanh", gate_scale=GATE_SCALE)
        assert out[0] < 0.01

    def test_monotonically_increasing(self, pos_logits):
        out = compute_active_gate(pos_logits, gate_type="tanh", gate_scale=GATE_SCALE)
        assert (out[1:] >= out[:-1]).all()

    def test_scale_sharpens_gate(self):
        logits = torch.tensor([0.5])
        low_scale = compute_active_gate(logits, gate_type="tanh", gate_scale=1.0)
        hi_scale = compute_active_gate(logits, gate_type="tanh", gate_scale=10.0)
        assert hi_scale[0] > low_scale[0]

    def test_antisymmetry(self, mixed_logits):
        """Tanh gate is symmetric around 0.5: f(-x) + f(x) == 1."""
        pos = compute_active_gate(mixed_logits.abs(), gate_type="tanh", gate_scale=1.0, eps=0.0)
        neg = compute_active_gate(-mixed_logits.abs(), gate_type="tanh", gate_scale=1.0, eps=0.0)
        assert torch.allclose(pos + neg, torch.ones_like(pos), atol=1e-5)

    def test_numerical_values(self):
        logits = torch.tensor([0.0, 1.0, -1.0])
        out = compute_active_gate(logits, gate_type="tanh", gate_scale=5.0, eps=0.0)
        expected = 0.5 * (torch.tanh(logits * 5.0) + 1.0)
        assert torch.allclose(out, expected, atol=1e-5)

    def test_differs_from_sigmoid(self, mixed_logits):
        """Tanh and sigmoid gates produce different outputs for the same logits."""
        tanh_out = compute_active_gate(mixed_logits, gate_type="tanh", gate_scale=GATE_SCALE, eps=0.0)
        sig_out = compute_active_gate(mixed_logits, gate_type="sigmoid", gate_scale=GATE_SCALE, eps=0.0)
        assert not torch.allclose(tanh_out, sig_out)

    def test_tanh_softer_than_sigmoid(self):
        """Tanh."""
        logits = torch.tensor([1.0])
        tanh_out = compute_active_gate(logits, gate_type="tanh", gate_scale=GATE_SCALE, eps=0.0)
        sig_out = compute_active_gate(logits, gate_type="sigmoid", gate_scale=GATE_SCALE, eps=0.0)
        assert abs(tanh_out[0].item() - 0.5) > abs(sig_out[0].item() - 0.5)


# ─────────────────────────────────────────────────────────────────────────────
# initialise_gate
# ─────────────────────────────────────────────────────────────────────────────


class TestInitialiseGate:
    # ── shape & dtype ────────────────────────────────────────────────────────

    @pytest.mark.parametrize("n", [1, 2, 5, 10, 64])
    def test_output_shape(self, n):
        out = initialise_gate(n, gate_scale=GATE_SCALE)
        assert out.shape == (n,)

    @pytest.mark.parametrize("n", [1, 5])
    def test_output_is_float(self, n):
        out = initialise_gate(n, gate_scale=GATE_SCALE)
        assert out.dtype == torch.float32

    # ── single-channel ───────────────────────────────────────────────────────

    def test_single_channel_constant_value(self):
        out = initialise_gate(1, gate_scale=GATE_SCALE)
        assert torch.allclose(out, torch.tensor([2.0 / GATE_SCALE]))

    @pytest.mark.parametrize("scale", [1.0, 2.0, 5.0, 10.0])
    def test_single_channel_different_scales(self, scale):
        out = initialise_gate(1, gate_scale=scale)
        assert torch.allclose(out, torch.tensor([2.0 / scale]))

    def test_single_channel_high_sigmoid_activation(self):
        """sigmoid(logit * scale) should be > 0.8 for single-channel init."""
        logit = initialise_gate(1, gate_scale=GATE_SCALE)
        active = torch.sigmoid(logit * GATE_SCALE)
        assert active[0].item() > 0.8

    def test_single_channel_deterministic(self):
        out1 = initialise_gate(1, gate_scale=GATE_SCALE)
        out2 = initialise_gate(1, gate_scale=GATE_SCALE)
        assert torch.allclose(out1, out2)

    # ── multi-channel ────────────────────────────────────────────────────────

    @pytest.mark.parametrize("n", [2, 10, 100])
    def test_multi_channel_bounded(self, n):
        """Multi-channel logits must lie in [-0.1/scale, 0.1/scale]."""
        out = initialise_gate(n, gate_scale=GATE_SCALE)
        bound = 0.1 / GATE_SCALE
        assert (out >= -bound - 1e-6).all()
        assert (out <= bound + 1e-6).all()

    def test_multi_channel_near_zero_activation(self):
        """Mean sigmoid activation over many channels should be close to 0.5."""
        out = initialise_gate(200, gate_scale=GATE_SCALE)
        active = torch.sigmoid(out * GATE_SCALE)
        assert active.mean().item() == pytest.approx(0.5, abs=0.05)

    def test_multi_channel_stochastic(self):
        results = {initialise_gate(10, GATE_SCALE).sum().item() for _ in range(20)}
        assert len(results) > 1

    # ── scale independence ───────────────────────────────────────────────────

    def test_scale_divides_logit_single(self):
        """Doubling gate_scale halves the single-channel logit."""
        out1 = initialise_gate(1, gate_scale=1.0)
        out2 = initialise_gate(1, gate_scale=2.0)
        assert torch.allclose(out1, out2 * 2.0)

    @pytest.mark.parametrize("scale", [1.0, 5.0, 10.0])
    def test_scale_divides_bound_multi(self, scale):
        """Bound [-0.1/s, 0.1/s] scales inversely with gate_scale."""
        out = initialise_gate(50, gate_scale=scale)
        bound = 0.1 / scale
        assert (out.abs() <= bound + 1e-6).all()

    # ── n == 1 boundary ──────────────────────────────────────────────────────

    def test_n_equals_1_is_constant_not_random(self):
        vals = {initialise_gate(1, gate_scale=GATE_SCALE).item() for _ in range(20)}
        assert len(vals) == 1, "n=1 must always return the same constant"

    def test_n_equals_2_is_random(self):
        vals = {initialise_gate(2, gate_scale=GATE_SCALE).sum().item() for _ in range(20)}
        assert len(vals) > 1, "n=2 must produce random values"
