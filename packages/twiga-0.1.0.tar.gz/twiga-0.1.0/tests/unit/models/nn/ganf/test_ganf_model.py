"""Tests for MLPGAFConfig and MLPGAFModel.

Follows the same pattern as test_mlpgam:
    - Flat test functions with shared fixtures
    - ValidationError assertions with field name checks
    - sample_input fixture exercising model.model() forward pass
    - Integration test: from_data_config → MLPGAFModel → forward
    - GPU compatibility test
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest
import torch

from twiga.core.data.processing import stack_features
from twiga.models.nn.mlpgaf_model import MLPGAFConfig, MLPGAFModel
from twiga.models.nn.net.mlpfgaf import MLPGAF

# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────


@pytest.fixture
def valid_data_config():
    return MagicMock(
        target_feature=["target"],
        historical_features=["hist1", "hist2"],
        calendar_features=["hour", "day"],
        exogenous_features=["exog1"],
        future_covariates=["covar1"],
        forecast_horizon=24,
        lookback_window_size=168,
    )


@pytest.fixture
def base_config():
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 2,
        "num_exogenous_features": 1,
        "num_future_covariates": 1,
        "forecast_horizon": 24,
        "lookback_window_size": 168,
        "latent_size": 64,
        "hidden_dim": 64,
        "num_layers": 1,
        "dropout": 0.0,
        "activation_function": "SiLU",
        "max_epochs": 5,
    }


@pytest.fixture
def sample_input(base_config):
    batch_size = 16
    past_features = (
        base_config["num_target_feature"]
        + base_config["num_historical_features"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    future_features = (
        base_config["num_future_covariates"]
        + base_config["num_calendar_features"]
        + base_config["num_exogenous_features"]
    )
    features = np.ones((batch_size, base_config["lookback_window_size"], past_features))
    covariates = 2 * np.ones((batch_size, base_config["forecast_horizon"], future_features))
    features = stack_features(past_features=features, future_covariates=covariates)
    return torch.from_numpy(features).float()


# ─────────────────────────────────────────────────────────────────────────────
# MLPGAFConfig
# ─────────────────────────────────────────────────────────────────────────────


def test_mlpgafconfig_initialization(base_config):
    """Test valid MLPGAFConfig initialization."""
    config = MLPGAFConfig(**base_config)

    assert config.name == "mlpgaf"
    assert config.latent_size == 64
    assert config.num_layers == 1
    assert config.search_space is not None


def test_mlpgafconfig_from_data_config(valid_data_config):
    """Test config creation from data pipeline config."""
    config = MLPGAFConfig.from_data_config(valid_data_config)

    assert config.num_target_feature == 1
    assert config.num_historical_features == 2
    assert config.num_calendar_features == 2
    assert config.num_exogenous_features == 1
    assert config.num_future_covariates == 1
    assert config.forecast_horizon == 24
    assert config.lookback_window_size == 168


def test_invalid_activation_function():
    """Test that an unsupported activation_function raises ValidationError."""
    with pytest.raises(ValidationError) as excinfo:
        MLPGAFConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=96,
            activation_function="Swish",
        )
    assert "activation_function" in str(excinfo.value)


def test_invalid_gate_type():
    """Test that an unsupported gate_type raises ValidationError."""
    with pytest.raises(ValidationError) as excinfo:
        MLPGAFConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=96,
            gate_type="gumbel_softmax",
        )
    assert "gate_type" in str(excinfo.value)


def test_invalid_value_embed_type():
    """Test that PatchEmb (excluded) raises ValidationError."""
    with pytest.raises(ValidationError) as excinfo:
        MLPGAFConfig(
            num_target_feature=1,
            forecast_horizon=24,
            lookback_window_size=96,
            value_embed_type="PatchEmb",
        )
    assert "value_embed_type" in str(excinfo.value)


def test_missing_required_fields():
    """Omitting NN dimension fields defaults to 0 (sentinel for TwigaForecaster auto-fill)."""
    config = MLPGAFConfig(forecast_horizon=24)
    assert config.num_target_feature == 0
    assert config.lookback_window_size == 0


def test_mlpgafconfig_no_patch_params():
    """Config must not expose patch_len or stride."""
    config = MLPGAFConfig(num_target_feature=1, forecast_horizon=24, lookback_window_size=96)
    assert not hasattr(config, "patch_len")
    assert not hasattr(config, "stride")


def test_mlpgafconfig_search_space_keys():
    """All tunable parameters must be present in search_space."""
    config = MLPGAFConfig(num_target_feature=1, forecast_horizon=24, lookback_window_size=96)
    expected = [
        "latent_size",
        "hidden_dim",
        "num_layers",
        "width_multiplier",
        "embedding_size",
        "value_embed_type",
        "embedding_type",
        "dropout",
        "alpha",
        "lambda_gate",
        "lambda_weight",
        "delta",
        "gate_scale",
        "use_norm",
        "use_residual",
        "activation_function",
    ]
    for key in expected:
        assert hasattr(config.search_space, key), f"Missing search_space key: '{key}'"


def test_mlpgafconfig_search_space_excludes_patch():
    """PatchEmb and patch params must not appear in search_space."""
    config = MLPGAFConfig(num_target_feature=1, forecast_horizon=24, lookback_window_size=96)
    assert "PatchEmb" not in config.search_space.value_embed_type
    assert not hasattr(config.search_space, "patch_len")
    assert not hasattr(config.search_space, "stride")


# ─────────────────────────────────────────────────────────────────────────────
# MLPGAFModel
# ─────────────────────────────────────────────────────────────────────────────


def test_mlpgafmodel_initialization(base_config):
    """Test model initialization with valid config."""
    config = MLPGAFConfig(**base_config)
    model = MLPGAFModel(config)

    assert isinstance(model.model, MLPGAF)
    assert model.model_config == config


def test_forward_pass_shape(base_config, sample_input):
    """Test model forward pass output dimensions."""
    config = MLPGAFConfig(**base_config)
    model = MLPGAFModel(config)

    output = model.model(sample_input)
    assert output.shape == (
        sample_input.size(0),
        base_config["forecast_horizon"],
        base_config["num_target_feature"],
    )


def test_forward_pass_no_nan(base_config, sample_input):
    """Forward pass output must not contain NaN values."""
    config = MLPGAFConfig(**base_config)
    model = MLPGAFModel(config)

    output = model.model(sample_input)
    assert not torch.isnan(output).any()


# ─────────────────────────────────────────────────────────────────────────────
# Integration
# ─────────────────────────────────────────────────────────────────────────────


def test_config_model_integration(valid_data_config):
    """Test end-to-end config and model integration."""
    config = MLPGAFConfig.from_data_config(valid_data_config)
    model = MLPGAFModel(config)

    assert model.model_config.num_historical_features == 2
    assert model.model_config.num_calendar_features == 2
    assert isinstance(model.model, MLPGAF)


def test_integration_forward_pass(valid_data_config):
    """Test that a model built from from_data_config runs a forward pass."""
    config = MLPGAFConfig.from_data_config(valid_data_config)
    model = MLPGAFModel(config)

    past_features = (
        config.num_target_feature
        + config.num_historical_features
        + config.num_calendar_features
        + config.num_exogenous_features
    )
    future_features = config.num_future_covariates + config.num_calendar_features + config.num_exogenous_features
    features = np.ones((4, config.lookback_window_size, past_features))
    covariates = np.ones((4, config.forecast_horizon, future_features))
    x = torch.from_numpy(stack_features(past_features=features, future_covariates=covariates)).float()

    output = model.model(x)
    assert output.shape == (4, config.forecast_horizon, config.num_target_feature)


# ─────────────────────────────────────────────────────────────────────────────
# Device compatibility
# ─────────────────────────────────────────────────────────────────────────────


def test_mlpgafmodel_update(base_config):
    """update() re-initialises model with Optuna-suggested hyperparameters."""
    config = MLPGAFConfig(**base_config)
    model = MLPGAFModel(config)
    mock_trial = MagicMock()

    with patch.object(MLPGAFConfig, "get_optuna_params", return_value=base_config):
        model.update(mock_trial)

    assert isinstance(model.model_config, MLPGAFConfig)
    assert isinstance(model.model, MLPGAF)


def test_mlpgafmodel_load_checkpoint(base_config):
    """load_checkpoint() delegates to _load_checkpoints and sets eval mode."""
    config = MLPGAFConfig(**base_config)
    model = MLPGAFModel(config)

    with patch.object(MLPGAFModel, "_load_checkpoints"):
        model.load_checkpoint()

    assert not model.model.training


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA not available")
def test_gpu_compatibility(base_config, sample_input):
    """Test model operation on GPU."""
    config = MLPGAFConfig(**base_config)
    model = MLPGAFModel(config)
    model.model.cuda()

    output = model.model(sample_input.cuda())
    assert output.device.type == "cuda"
    assert output.shape == (
        sample_input.size(0),
        base_config["forecast_horizon"],
        base_config["num_target_feature"],
    )
