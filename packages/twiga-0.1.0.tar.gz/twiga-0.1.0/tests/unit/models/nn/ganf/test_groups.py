"""Tests for twiga.models.nn.ganf.group_modules.build_group_modules.

Covers:
    - Return type and length
    - Branch attribute presence/absence based on has_past / has_future
    - Projection layer shape (output_dim = num_target * horizon) and no bias
    - Gate parameter shapes and types
    - Gate bias shape and type
    - Encoder context_size routing (past → lookback, future → horizon)
    - Multi-channel vs single-channel gate init values
    - Empty branch (has_past=False, has_future=False)
    - Groups with mixed past-only / future-only / both
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
import torch
import torch.nn as nn

import twiga.models.nn.net.ganf.groups as _group_modules_mod
from twiga.models.nn.net.ganf.groups import build_group_modules

# ─────────────────────────────────────────────────────────────────────────────
# Constants & helpers
# ─────────────────────────────────────────────────────────────────────────────

FORECAST_HORIZON = 12
LOOKBACK_WINDOW_SIZE = 48
LATENT_SIZE = 32
HIDDEN_DIM = 64
WIDTH_MULTIPLIER = 2.0
NUM_LAYERS = 2
NUM_TARGET_FEATURE = 3
DROPOUT = 0.1
GATE_SCALE = 5.0
EMBEDDING_SIZE = 16

OUTPUT_DIM = NUM_TARGET_FEATURE * FORECAST_HORIZON  # 36


def _activation() -> type:
    return nn.SiLU


def _base_kwargs(**overrides) -> dict:
    """Return a complete valid kwargs dict for build_group_modules."""
    kwargs = {
        "forecast_horizon": FORECAST_HORIZON,
        "lookback_window_size": LOOKBACK_WINDOW_SIZE,
        "activation": _activation(),
        "gate_scale": GATE_SCALE,
        "embedding_size": EMBEDDING_SIZE,
        "value_embed_type": None,
        "embedding_type": None,
        "latent_size": LATENT_SIZE,
        "hidden_dim": HIDDEN_DIM,
        "width_multiplier": WIDTH_MULTIPLIER,
        "num_layers": NUM_LAYERS,
        "num_target_feature": NUM_TARGET_FEATURE,
        "dropout": DROPOUT,
        "use_norm": True,
        "use_bias": True,
        "use_residual": True,
        "use_revin": False,
        "use_temporal_mixer": False,
        "patch_len": None,
        "stride": None,
    }
    kwargs.update(overrides)
    return kwargs


def _group(*, size: int, has_past: bool, has_future: bool, name: str = "g") -> dict:
    return {"size": size, "has_past": has_past, "has_future": has_future, "name": name}


# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────


@pytest.fixture
def past_only_group():
    """Single group that has past data only."""
    return [_group(size=4, has_past=True, has_future=False, name="past_only")]


@pytest.fixture
def future_only_group():
    """Single group that has future data only."""
    return [_group(size=2, has_past=False, has_future=True, name="fut_only")]


@pytest.fixture
def both_group():
    """Single group that has both past and future data."""
    return [_group(size=3, has_past=True, has_future=True, name="both")]


@pytest.fixture
def mixed_groups():
    """Three groups: past-only, future-only, both."""
    return [
        _group(size=4, has_past=True, has_future=False, name="past"),
        _group(size=2, has_past=False, has_future=True, name="fut"),
        _group(size=3, has_past=True, has_future=True, name="both"),
    ]


@pytest.fixture
def empty_group():
    """Single group with neither past nor future — produces a bare branch."""
    return [_group(size=1, has_past=False, has_future=False, name="empty")]


# ─────────────────────────────────────────────────────────────────────────────
# Return type & length
# ─────────────────────────────────────────────────────────────────────────────


class TestReturnType:
    def test_returns_module_list(self, mixed_groups):
        """build_group_modules must return an nn.ModuleList."""
        result = build_group_modules(mixed_groups, **_base_kwargs())
        assert isinstance(result, nn.ModuleList)

    def test_length_matches_groups(self, mixed_groups):
        """ModuleList length must equal the number of input groups."""
        result = build_group_modules(mixed_groups, **_base_kwargs())
        assert len(result) == len(mixed_groups)

    def test_empty_groups_list(self):
        """An empty group list must produce an empty ModuleList."""
        result = build_group_modules([], **_base_kwargs())
        assert isinstance(result, nn.ModuleList)
        assert len(result) == 0

    def test_each_element_is_module(self, mixed_groups):
        """Every element of the returned list must be an nn.Module."""
        result = build_group_modules(mixed_groups, **_base_kwargs())
        for branch in result:
            assert isinstance(branch, nn.Module)


# ─────────────────────────────────────────────────────────────────────────────
# Branch attribute presence
# ─────────────────────────────────────────────────────────────────────────────


class TestBranchAttributes:
    def test_past_only_has_past_attrs(self, past_only_group):
        """A past-only group must have all four past_* attributes."""
        branch = build_group_modules(past_only_group, **_base_kwargs())[0]
        assert hasattr(branch, "past_enc")
        assert hasattr(branch, "past_proj")
        assert hasattr(branch, "past_feature_gate")
        assert hasattr(branch, "past_gate_bias")

    def test_past_only_has_no_future_attrs(self, past_only_group):
        """A past-only group must not have any fut_* attributes."""
        branch = build_group_modules(past_only_group, **_base_kwargs())[0]
        assert not hasattr(branch, "fut_enc")
        assert not hasattr(branch, "fut_proj")
        assert not hasattr(branch, "fut_feature_gate")
        assert not hasattr(branch, "fut_gate_bias")

    def test_future_only_has_future_attrs(self, future_only_group):
        """A future-only group must have all four fut_* attributes."""
        branch = build_group_modules(future_only_group, **_base_kwargs())[0]
        assert hasattr(branch, "fut_enc")
        assert hasattr(branch, "fut_proj")
        assert hasattr(branch, "fut_feature_gate")
        assert hasattr(branch, "fut_gate_bias")

    def test_future_only_has_no_past_attrs(self, future_only_group):
        """A future-only group must not have any past_* attributes."""
        branch = build_group_modules(future_only_group, **_base_kwargs())[0]
        assert not hasattr(branch, "past_enc")
        assert not hasattr(branch, "past_proj")
        assert not hasattr(branch, "past_feature_gate")
        assert not hasattr(branch, "past_gate_bias")

    def test_both_has_all_attrs(self, both_group):
        """A group with both past and future must have all eight attributes."""
        branch = build_group_modules(both_group, **_base_kwargs())[0]
        for attr in (
            "past_enc",
            "past_proj",
            "past_feature_gate",
            "past_gate_bias",
            "fut_enc",
            "fut_proj",
            "fut_feature_gate",
            "fut_gate_bias",
        ):
            assert hasattr(branch, attr), f"Missing attribute: {attr}"

    def test_empty_branch_has_no_enc_attrs(self, empty_group):
        """A group with has_past=False and has_future=False must have no enc/proj attrs."""
        branch = build_group_modules(empty_group, **_base_kwargs())[0]
        for attr in ("past_enc", "past_proj", "fut_enc", "fut_proj"):
            assert not hasattr(branch, attr)


# ─────────────────────────────────────────────────────────────────────────────
# Projection layers
# ─────────────────────────────────────────────────────────────────────────────


class TestProjectionLayers:
    def test_past_proj_output_dim(self, past_only_group):
        """past_proj must map latent_size → num_target * horizon."""
        branch = build_group_modules(past_only_group, **_base_kwargs())[0]
        assert branch.past_proj.out_features == OUTPUT_DIM

    def test_past_proj_input_dim(self, past_only_group):
        """past_proj input features must equal latent_size."""
        branch = build_group_modules(past_only_group, **_base_kwargs())[0]
        assert branch.past_proj.in_features == LATENT_SIZE

    def test_past_proj_no_bias(self, past_only_group):
        """past_proj must be instantiated without a bias term."""
        branch = build_group_modules(past_only_group, **_base_kwargs())[0]
        assert branch.past_proj.bias is None

    def test_fut_proj_output_dim(self, future_only_group):
        """fut_proj must map latent_size → num_target * horizon."""
        branch = build_group_modules(future_only_group, **_base_kwargs())[0]
        assert branch.fut_proj.out_features == OUTPUT_DIM

    def test_fut_proj_input_dim(self, future_only_group):
        """fut_proj input features must equal latent_size."""
        branch = build_group_modules(future_only_group, **_base_kwargs())[0]
        assert branch.fut_proj.in_features == LATENT_SIZE

    def test_fut_proj_no_bias(self, future_only_group):
        """fut_proj must be instantiated without a bias term."""
        branch = build_group_modules(future_only_group, **_base_kwargs())[0]
        assert branch.fut_proj.bias is None

    def test_output_dim_scales_with_target_and_horizon(self):
        """output_dim must equal num_target_feature * forecast_horizon."""
        for n_tgt, horizon in [(1, 6), (4, 24), (7, 1)]:
            groups = [_group(size=2, has_past=True, has_future=False)]
            branch = build_group_modules(groups, **_base_kwargs(num_target_feature=n_tgt, forecast_horizon=horizon))[0]
            assert branch.past_proj.out_features == n_tgt * horizon


# ─────────────────────────────────────────────────────────────────────────────
# Gate parameters
# ─────────────────────────────────────────────────────────────────────────────


class TestGateParameters:
    def test_past_feature_gate_is_parameter(self, past_only_group):
        """past_feature_gate must be an nn.Parameter."""
        branch = build_group_modules(past_only_group, **_base_kwargs())[0]
        assert isinstance(branch.past_feature_gate, nn.Parameter)

    def test_past_feature_gate_shape(self, past_only_group):
        """past_feature_gate shape must equal (group_size,)."""
        group_size = past_only_group[0]["size"]
        branch = build_group_modules(past_only_group, **_base_kwargs())[0]
        assert branch.past_feature_gate.shape == (group_size,)

    def test_fut_feature_gate_is_parameter(self, future_only_group):
        """fut_feature_gate must be an nn.Parameter."""
        branch = build_group_modules(future_only_group, **_base_kwargs())[0]
        assert isinstance(branch.fut_feature_gate, nn.Parameter)

    def test_fut_feature_gate_shape(self, future_only_group):
        """fut_feature_gate shape must equal (group_size,)."""
        group_size = future_only_group[0]["size"]
        branch = build_group_modules(future_only_group, **_base_kwargs())[0]
        assert branch.fut_feature_gate.shape == (group_size,)

    def test_gate_shape_respects_group_size(self):
        """Gate shape must track the per-group size independently."""
        groups = [
            _group(size=1, has_past=True, has_future=False, name="a"),
            _group(size=5, has_past=True, has_future=False, name="b"),
        ]
        modules = build_group_modules(groups, **_base_kwargs())
        assert modules[0].past_feature_gate.shape == (1,)
        assert modules[1].past_feature_gate.shape == (5,)

    def test_past_gate_bias_is_parameter(self, past_only_group):
        """past_gate_bias must be an nn.Parameter."""
        branch = build_group_modules(past_only_group, **_base_kwargs())[0]
        assert isinstance(branch.past_gate_bias, nn.Parameter)

    def test_past_gate_bias_shape(self, past_only_group):
        """past_gate_bias must have shape (1,)."""
        branch = build_group_modules(past_only_group, **_base_kwargs())[0]
        assert branch.past_gate_bias.shape == (1,)

    def test_past_gate_bias_initialised_to_zero(self, past_only_group):
        """past_gate_bias must be initialised to zero."""
        branch = build_group_modules(past_only_group, **_base_kwargs())[0]
        assert branch.past_gate_bias.item() == pytest.approx(0.0)

    def test_fut_gate_bias_shape(self, future_only_group):
        """fut_gate_bias must have shape (1,)."""
        branch = build_group_modules(future_only_group, **_base_kwargs())[0]
        assert branch.fut_gate_bias.shape == (1,)

    def test_fut_gate_bias_initialised_to_zero(self, future_only_group):
        """fut_gate_bias must be initialised to zero."""
        branch = build_group_modules(future_only_group, **_base_kwargs())[0]
        assert branch.fut_gate_bias.item() == pytest.approx(0.0)

    def test_single_channel_gate_is_deterministic(self):
        """n=1 gate logits must be identical across two build calls."""
        groups = [_group(size=1, has_past=True, has_future=False)]
        b1 = build_group_modules(groups, **_base_kwargs())[0]
        b2 = build_group_modules(groups, **_base_kwargs())[0]
        assert torch.allclose(b1.past_feature_gate.data, b2.past_feature_gate.data)

    def test_multi_channel_gate_differs_across_builds(self):
        """n>1 gate logits should differ between independent build calls (random init)."""
        groups = [_group(size=10, has_past=True, has_future=False)]
        vals = {build_group_modules(groups, **_base_kwargs())[0].past_feature_gate.data.sum().item() for _ in range(10)}
        assert len(vals) > 1


# ─────────────────────────────────────────────────────────────────────────────
# Encoder context_size routing
# ─────────────────────────────────────────────────────────────────────────────


class TestEncoderContextSize:
    """Verify that past encoders receive lookback_window_size and future.

    encoders receive forecast_horizon as their context_size argument.
    """

    def test_past_enc_receives_lookback_context(self):
        """MLPEncoder for past must be called with context_size=lookback_window_size."""
        groups = [_group(size=2, has_past=True, has_future=False)]
        with patch.object(_group_modules_mod, "MLPEncoder", autospec=True) as mock_enc:
            build_group_modules(groups, **_base_kwargs())
            _, kwargs = mock_enc.call_args
            assert kwargs["context_size"] == LOOKBACK_WINDOW_SIZE

    def test_fut_enc_receives_horizon_context(self):
        """MLPEncoder for future must be called with context_size=forecast_horizon."""
        groups = [_group(size=2, has_past=False, has_future=True)]
        with patch.object(_group_modules_mod, "MLPEncoder", autospec=True) as mock_enc:
            build_group_modules(groups, **_base_kwargs())
            _, kwargs = mock_enc.call_args
            assert kwargs["context_size"] == FORECAST_HORIZON

    def test_both_group_makes_two_encoder_calls(self):
        """A both-group must trigger exactly two MLPEncoder instantiations."""
        groups = [_group(size=2, has_past=True, has_future=True)]
        with patch.object(_group_modules_mod, "MLPEncoder", autospec=True) as mock_enc:
            build_group_modules(groups, **_base_kwargs())
            assert mock_enc.call_count == 2

    def test_context_sizes_differ_for_both_group(self):
        """The two encoder calls for a both-group must use different context_sizes."""
        groups = [_group(size=2, has_past=True, has_future=True)]
        with patch.object(_group_modules_mod, "MLPEncoder", autospec=True) as mock_enc:
            build_group_modules(groups, **_base_kwargs())
            context_sizes = [c.kwargs["context_size"] for c in mock_enc.call_args_list]
            assert set(context_sizes) == {LOOKBACK_WINDOW_SIZE, FORECAST_HORIZON}


# ─────────────────────────────────────────────────────────────────────────────
# Encoder kwargs forwarding
# ─────────────────────────────────────────────────────────────────────────────


class TestEncoderKwargsForwarding:
    """Verify that scalar hyperparameters reach MLPEncoder unchanged."""

    @pytest.fixture(autouse=True)
    def patch_encoder(self):
        with patch.object(_group_modules_mod, "MLPEncoder", autospec=True) as mock_enc:
            self.mock_enc = mock_enc
            yield

    def _call_and_get_kwargs(self, groups, **overrides):
        build_group_modules(groups, **_base_kwargs(**overrides))
        return self.mock_enc.call_args.kwargs

    def test_num_channels_forwarded(self):
        """MLPEncoder must receive num_channels equal to the group size."""
        groups = [_group(size=7, has_past=True, has_future=False)]
        kw = self._call_and_get_kwargs(groups)
        assert kw["num_channels"] == 7

    def test_dropout_forwarded(self):
        """MLPEncoder must receive the dropout value from build_group_modules."""
        groups = [_group(size=2, has_past=True, has_future=False)]
        kw = self._call_and_get_kwargs(groups, dropout=0.42)
        assert kw["dropout"] == pytest.approx(0.42)

    def test_hidden_dim_forwarded(self):
        """MLPEncoder must receive the hidden_dim value."""
        groups = [_group(size=2, has_past=True, has_future=False)]
        kw = self._call_and_get_kwargs(groups, hidden_dim=128)
        assert kw["hidden_dim"] == 128

    def test_num_layers_forwarded(self):
        """MLPEncoder must receive the num_layers value."""
        groups = [_group(size=2, has_past=True, has_future=False)]
        kw = self._call_and_get_kwargs(groups, num_layers=4)
        assert kw["num_layers"] == 4

    def test_patch_len_forwarded(self):
        """MLPEncoder must receive patch_len when supplied."""
        groups = [_group(size=2, has_past=True, has_future=False)]
        kw = self._call_and_get_kwargs(groups, patch_len=16, stride=8)
        assert kw["patch_len"] == 16

    def test_stride_forwarded(self):
        """MLPEncoder must receive stride when supplied."""
        groups = [_group(size=2, has_past=True, has_future=False)]
        kw = self._call_and_get_kwargs(groups, patch_len=16, stride=8)
        assert kw["stride"] == 8


# ─────────────────────────────────────────────────────────────────────────────
# Multi-group independence
# ─────────────────────────────────────────────────────────────────────────────


class TestMultiGroupIndependence:
    def test_branches_are_distinct_objects(self, mixed_groups):
        """Each branch must be a distinct nn.Module instance."""
        modules = build_group_modules(mixed_groups, **_base_kwargs())
        ids = [id(b) for b in modules]
        assert len(ids) == len(set(ids))

    def test_encoders_are_distinct_objects(self):
        """Encoders across branches must not be shared instances."""
        groups = [
            _group(size=2, has_past=True, has_future=False, name="a"),
            _group(size=2, has_past=True, has_future=False, name="b"),
        ]
        modules = build_group_modules(groups, **_base_kwargs())
        assert modules[0].past_enc is not modules[1].past_enc

    def test_gate_params_are_distinct_objects(self):
        """Gate parameters across branches must not be shared."""
        groups = [
            _group(size=2, has_past=True, has_future=False, name="a"),
            _group(size=2, has_past=True, has_future=False, name="b"),
        ]
        modules = build_group_modules(groups, **_base_kwargs())
        assert modules[0].past_feature_gate is not modules[1].past_feature_gate

    def test_group_count_three(self, mixed_groups):
        """The mixed fixture must produce exactly three branches."""
        modules = build_group_modules(mixed_groups, **_base_kwargs())
        assert len(modules) == 3

    def test_correct_attrs_per_branch(self, mixed_groups):
        """Each branch in mixed_groups must have only the expected attributes."""
        modules = build_group_modules(mixed_groups, **_base_kwargs())
        assert hasattr(modules[0], "past_enc") and not hasattr(modules[0], "fut_enc")
        assert not hasattr(modules[1], "past_enc") and hasattr(modules[1], "fut_enc")
        assert hasattr(modules[2], "past_enc") and hasattr(modules[2], "fut_enc")
