"""Tests for MLPGAFNetwork and MLPGAF.

Covers:
    - Initialisation: valid config, attribute presence, invalid params
    - Group structure: sizes, has_past/has_future flags
    - forward(): output shape, return_components, gradient flow
    - forecast(): shape, no_grad context
    - step(): loss dict keys, total_loss composition, scalar outputs
    - Gate compute fn: sigmoid/tanh, invalid type
    - Bias: shape, zero init
    - MLPGAF wrapper: delegates to MLPGAFNetwork
"""

from __future__ import annotations

from functools import partial
from unittest.mock import MagicMock

import pytest
import torch
import torch.nn as nn

from twiga.core.data.processing import stack_features
from twiga.models.nn.net.mlpfgaf import MLPGAF, MLPGAFNetwork

# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────


@pytest.fixture
def base_config() -> dict:
    """Full config with all four feature groups active."""
    return {
        "num_target_feature": 1,
        "num_historical_features": 2,
        "num_calendar_features": 3,
        "num_exogenous_features": 5,
        "num_future_covariates": 2,
        "forecast_horizon": 24,
        "lookback_window_size": 96,
        "embedding_size": 28,
        "embedding_type": None,
        "value_embed_type": None,
        "latent_size": 64,
        "hidden_dim": 64,
        "num_layers": 1,
        "use_norm": True,
        "use_bias": True,
        "use_residual": True,
        "use_revin": False,
        "use_temporal_mixer": False,
        "activation_function": "SiLU",
        "out_activation_function": "Identity",
        "dropout": 0.0,
        "alpha": 0.1,
        "lambda_weight": 1e-6,
        "lambda_gate": 1e-2,
        "delta": 1e-2,
        "gate_scale": 5.0,
        "gate_type": "sigmoid",
        "warmup_epochs": 10,
    }


@pytest.fixture
def minimal_config() -> dict:
    """Only targets + historical — no calendar, exogenous, or future covariates."""
    return {
        "num_target_feature": 3,
        "num_historical_features": 6,
        "num_calendar_features": 0,
        "num_exogenous_features": 0,
        "num_future_covariates": 0,
        "forecast_horizon": 12,
        "lookback_window_size": 48,
        "latent_size": 32,
        "hidden_dim": 32,
        "num_layers": 1,
        "dropout": 0.0,
    }


@pytest.fixture
def base_model(base_config) -> MLPGAFNetwork:
    return MLPGAFNetwork(**base_config)


@pytest.fixture
def sample_batch(base_config):
    """Correctly shaped (x, y) batch matching base_config dimensions."""
    batch_size = 16
    cfg = base_config
    n_past = (
        cfg["num_target_feature"]
        + cfg["num_historical_features"]
        + cfg["num_calendar_features"]
        + cfg["num_exogenous_features"]
    )
    n_future = cfg["num_future_covariates"] + cfg["num_calendar_features"] + cfg["num_exogenous_features"]
    past = torch.randn(batch_size, cfg["lookback_window_size"], n_past)
    fut = torch.randn(batch_size, cfg["forecast_horizon"], n_future)
    x = torch.from_numpy(
        stack_features(
            past_features=past.numpy(),
            future_covariates=fut.numpy(),
        )
    ).float()
    y = torch.randn(batch_size, cfg["forecast_horizon"], cfg["num_target_feature"])
    return x, y


# ─────────────────────────────────────────────────────────────────────────────
# Initialisation
# ─────────────────────────────────────────────────────────────────────────────


class TestInitialisation:
    def test_returns_correct_type(self, base_config):
        """MLPGAFNetwork must be an instance of itself."""
        assert isinstance(MLPGAFNetwork(**base_config), MLPGAFNetwork)

    def test_bias_shape(self, base_config):
        """Bias must have shape (num_target * forecast_horizon,)."""
        model = MLPGAFNetwork(**base_config)
        expected = base_config["num_target_feature"] * base_config["forecast_horizon"]
        assert model.bias.shape == (expected,)

    def test_bias_initialised_to_zero(self, base_config):
        """Bias must be initialised to zero."""
        model = MLPGAFNetwork(**base_config)
        assert model.bias.data.abs().max().item() == pytest.approx(0.0)

    def test_bias_is_parameter(self, base_config):
        """Bias must be a learnable nn.Parameter."""
        model = MLPGAFNetwork(**base_config)
        assert isinstance(model.bias, nn.Parameter)

    def test_group_modules_is_module_list(self, base_model):
        """group_modules must be an nn.ModuleList."""
        assert isinstance(base_model.group_modules, nn.ModuleList)

    def test_groups_attribute_present(self, base_model):
        """model.groups must be a non-empty list of dicts."""
        assert isinstance(base_model.groups, list)
        assert len(base_model.groups) > 0

    def test_gate_compute_fn_is_partial(self, base_model):
        """gate_compute_fn must be a functools.partial."""
        assert isinstance(base_model.gate_compute_fn, partial)

    def test_invalid_activation_raises(self, base_config):
        """An unrecognised activation_function must raise ValueError."""
        cfg = {**base_config, "activation_function": "NotAnActivation"}
        with pytest.raises(ValueError, match="activation_function"):
            MLPGAFNetwork(**cfg)

    def test_invalid_gate_type_raises(self, base_config):
        """An unrecognised gate_type must raise ValueError when gate_compute_fn is called."""
        cfg = {**base_config, "gate_type": "gumbel_softmax"}
        model = MLPGAFNetwork(**cfg)
        with pytest.raises(ValueError, match="Unknown gate_type"):
            model.gate_compute_fn(torch.randn(4))


# ─────────────────────────────────────────────────────────────────────────────
# Group structure
# ─────────────────────────────────────────────────────────────────────────────


class TestGroupStructure:
    def test_all_groups_active_with_full_config(self, base_model, base_config):
        """All feature groups must be present when all counts are > 0."""
        names = {g["name"] for g in base_model.groups}
        assert "calendar" in names
        assert "exogenous" in names
        assert "future_covariates" in names
        # At least one past-only group must exist (target / historical)
        assert any(g["has_past"] and not g["has_future"] for g in base_model.groups)

    def test_empty_groups_absent(self):
        """Groups with zero features must not appear in model.groups."""
        model = MLPGAFNetwork(
            num_target_feature=1,
            num_historical_features=2,
            num_calendar_features=0,
            num_exogenous_features=0,
            num_future_covariates=0,
            forecast_horizon=12,
            lookback_window_size=48,
            latent_size=16,
            hidden_dim=16,
            num_layers=1,
            dropout=0.0,
        )
        names = {g["name"] for g in model.groups}
        assert "calendar" not in names
        assert "exogenous" not in names
        assert "future_covariates" not in names

    def test_past_only_groups_have_correct_flags(self, base_model):
        """Every past-only group must have has_past=True and has_future=False."""
        past_only = [g for g in base_model.groups if g["has_past"] and not g["has_future"]]
        assert len(past_only) > 0, "Expected at least one past-only group"
        for g in past_only:
            assert g["has_past"] is True
            assert g["has_future"] is False

    def test_future_covariates_group_has_future_not_past(self, base_model):
        """The future_covariates group must have has_future=True and has_past=False."""
        fut = next(g for g in base_model.groups if g["name"] == "future_covariates")
        assert fut["has_future"] is True
        assert fut["has_past"] is False

    def test_group_sizes_match_feature_counts(self, base_model, base_config):
        """Sum of all group sizes must equal total feature count."""
        expected_total = (
            base_config["num_target_feature"]
            + base_config["num_historical_features"]
            + base_config["num_calendar_features"]
            + base_config["num_exogenous_features"]
            + base_config["num_future_covariates"]
        )
        actual_total = sum(g["size"] for g in base_model.groups)
        assert actual_total == expected_total, f"Total group sizes {actual_total} != expected {expected_total}"

    def test_group_modules_length_matches_groups(self, base_model):
        """group_modules must have one entry per group."""
        assert len(base_model.group_modules) == len(base_model.groups)

    def test_minimal_config_no_future_groups(self, minimal_config):
        """With no future features, every group must be past-only."""
        model = MLPGAFNetwork(**minimal_config)
        assert len(model.groups) >= 1
        for g in model.groups:
            assert g["has_past"] is True, f"{g['name']} missing has_past"
            assert g["has_future"] is False, f"{g['name']} unexpectedly has_future"


# ─────────────────────────────────────────────────────────────────────────────
# forward()
# ─────────────────────────────────────────────────────────────────────────────


class TestForward:
    def test_output_shape(self, base_model, sample_batch, base_config):
        """forward() must return (B, horizon, num_target)."""
        x, _ = sample_batch
        out = base_model(x)
        assert out.shape == (
            x.size(0),
            base_config["forecast_horizon"],
            base_config["num_target_feature"],
        )

    def test_return_components_type(self, base_model, sample_batch):
        """With return_components=True, forward() must return (Tensor, dict)."""
        x, _ = sample_batch
        result = base_model(x, return_components=True)
        assert isinstance(result, tuple) and len(result) == 2
        forecast, comps = result
        assert isinstance(forecast, torch.Tensor)
        assert isinstance(comps, dict)

    def test_return_components_keys(self, base_model, sample_batch):
        """Component keys must follow the '{group_name}_past/fut' pattern."""
        x, _ = sample_batch
        _, comps = base_model(x, return_components=True)
        for key in comps:
            assert key.endswith("_past") or key.endswith("_fut"), f"Unexpected component key: {key}"

    def test_return_components_shapes(self, base_model, sample_batch, base_config):
        """Each component tensor must have shape (B, num_target * horizon)."""
        x, _ = sample_batch
        _, comps = base_model(x, return_components=True)
        expected_flat = base_config["num_target_feature"] * base_config["forecast_horizon"]
        for key, val in comps.items():
            assert val.shape == (x.size(0), expected_flat), f"Bad shape for {key}"

    def test_gradients_flow(self, base_model, sample_batch):
        """Gradients must reach the bias parameter after backward()."""
        x, _ = sample_batch
        x = x.requires_grad_(False)
        out = base_model(x)
        out.sum().backward()
        assert base_model.bias.grad is not None
        assert not torch.isnan(base_model.bias.grad).any()

    def test_no_return_components_by_default(self, base_model, sample_batch):
        """forward() without flag must return a plain Tensor, not a tuple."""
        x, _ = sample_batch
        out = base_model(x)
        assert isinstance(out, torch.Tensor)

    def test_output_is_float(self, base_model, sample_batch):
        """Output dtype must be float32."""
        x, _ = sample_batch
        assert base_model(x).dtype == torch.float32

    def test_tanh_gate_type_forward(self, base_config, sample_batch):
        """Model with gate_type='tanh' must produce a valid float output."""
        model = MLPGAFNetwork(**{**base_config, "gate_type": "tanh"})
        x, _ = sample_batch
        out = model(x)
        assert out.shape[1:] == (base_config["forecast_horizon"], base_config["num_target_feature"])
        assert not torch.isnan(out).any()


# ─────────────────────────────────────────────────────────────────────────────
# forecast()
# ─────────────────────────────────────────────────────────────────────────────


class TestForecast:
    def test_output_shape(self, base_model, sample_batch, base_config):
        """forecast() must return (B, horizon, num_target)."""
        x, _ = sample_batch
        out = base_model.forecast(x)
        assert out.shape == (
            x.size(0),
            base_config["forecast_horizon"],
            base_config["num_target_feature"],
        )

    def test_no_grad_context(self, base_model, sample_batch):
        """forecast() must run inside a no_grad context — no grad on output."""
        x, _ = sample_batch
        out = base_model.forecast(x)
        assert not out.requires_grad

    def test_matches_forward_in_eval_mode(self, base_model, sample_batch):
        """forecast() must agree with forward() when the model is in eval mode."""
        base_model.eval()
        x, _ = sample_batch
        with torch.no_grad():
            expected = base_model(x)
        result = base_model.forecast(x)
        assert torch.allclose(result, expected)


# ─────────────────────────────────────────────────────────────────────────────
# step()
# ─────────────────────────────────────────────────────────────────────────────


class TestStep:
    def _dummy_metric(self, pred, target):
        return torch.mean((pred - target).abs())

    def test_returns_dict_and_tensor(self, base_model, sample_batch):
        """step() must return (dict, Tensor)."""
        loss_dict, total_loss = base_model.step(sample_batch, self._dummy_metric)
        assert isinstance(loss_dict, dict)
        assert isinstance(total_loss, torch.Tensor)

    def test_loss_dict_keys(self, base_model, sample_batch):
        """loss_dict must contain exactly the four expected keys."""
        loss_dict, _ = base_model.step(sample_batch, self._dummy_metric)
        assert set(loss_dict.keys()) == {"loss", "loss_loc", "weight_penalty", "gate_penalty"}

    def test_total_loss_is_scalar(self, base_model, sample_batch):
        """total_loss must be a 0-dimensional scalar tensor."""
        _, total_loss = base_model.step(sample_batch, self._dummy_metric)
        assert total_loss.ndim == 0

    def test_total_loss_matches_loss_key(self, base_model, sample_batch):
        """loss_dict['loss'] must be the same object as total_loss."""
        loss_dict, total_loss = base_model.step(sample_batch, self._dummy_metric)
        assert loss_dict["loss"] is total_loss

    def test_total_loss_composition(self, base_model, sample_batch):
        """total_loss must equal loss_loc + gate_penalty + weight_penalty."""
        loss_dict, total_loss = base_model.step(sample_batch, self._dummy_metric)
        expected = loss_dict["loss_loc"] + loss_dict["gate_penalty"] + loss_dict["weight_penalty"]
        assert torch.allclose(total_loss, expected)

    def test_all_losses_are_non_negative(self, base_model, sample_batch):
        """All penalty terms must be ≥ 0."""
        loss_dict, _ = base_model.step(sample_batch, self._dummy_metric)
        for key in ("loss_loc", "gate_penalty", "weight_penalty"):
            assert loss_dict[key].item() >= 0.0, f"{key} is negative"

    def test_loss_is_differentiable(self, base_model, sample_batch):
        """total_loss must be differentiable (backward() must not raise)."""
        _, total_loss = base_model.step(sample_batch, self._dummy_metric)
        total_loss.backward()  # must not raise

    def test_epoch_none_runs_without_error(self, base_model, sample_batch):
        """Passing epoch=None must not raise (post-warmup full penalty)."""
        base_model.step(sample_batch, self._dummy_metric, epoch=None)

    def test_epoch_zero_runs_without_error(self, base_model, sample_batch):
        """Passing epoch=0 (warmup start) must not raise."""
        base_model.step(sample_batch, self._dummy_metric, epoch=0)


# ─────────────────────────────────────────────────────────────────────────────
# Gate compute function
# ─────────────────────────────────────────────────────────────────────────────


class TestGateComputeFn:
    @pytest.mark.parametrize("gate_type", ["sigmoid", "tanh"])
    def test_gate_compute_fn_output_bounded(self, base_config, gate_type):
        """gate_compute_fn must produce values strictly inside (0, 1)."""
        model = MLPGAFNetwork(**{**base_config, "gate_type": gate_type})
        logits = torch.randn(4)
        out = model.gate_compute_fn(logits)
        assert (out > 0.0).all()
        assert (out < 1.0).all()

    @pytest.mark.parametrize("gate_type", ["sigmoid", "tanh"])
    def test_gate_compute_fn_shape_preserved(self, base_config, gate_type):
        """gate_compute_fn must preserve the input shape."""
        model = MLPGAFNetwork(**{**base_config, "gate_type": gate_type})
        logits = torch.randn(7)
        assert model.gate_compute_fn(logits).shape == (7,)

    def test_gate_scale_stored(self, base_config):
        """gate_scale must be stored as an attribute."""
        model = MLPGAFNetwork(**{**base_config, "gate_scale": 3.0})
        assert model.gate_scale == pytest.approx(3.0)


# ─────────────────────────────────────────────────────────────────────────────
# MLPGAF Lightning wrapper
# ─────────────────────────────────────────────────────────────────────────────


class TestMLPGAF:
    def _wrapper_config(self, base_config) -> dict:
        return {
            **base_config,
            "metric": "mae",
            "optimizer_params": None,
            "scheduler_params": None,
            "max_epochs": 5,
        }

    def test_wraps_mlpgaf_network(self, base_config):
        """MLPGAF.model must be an MLPGAFNetwork."""
        wrapper = MLPGAF(**self._wrapper_config(base_config))
        assert isinstance(wrapper.model, MLPGAFNetwork)

    def test_latent_size_forwarded(self, base_config):
        """MLPGAF must forward latent_size to the inner MLPGAFNetwork."""
        cfg = {**base_config, "latent_size": 128}
        wrapper = MLPGAF(**self._wrapper_config(cfg))
        # Verify projection layer input matches latent_size
        branch = wrapper.model.group_modules[0]
        proj = branch.past_proj if hasattr(branch, "past_proj") else branch.fut_proj
        assert proj.in_features == 128

    def test_gate_type_forwarded(self, base_config):
        """MLPGAF must forward gate_type to gate_compute_fn in the inner network."""
        cfg = {**base_config, "gate_type": "tanh"}
        wrapper = MLPGAF(**self._wrapper_config(cfg))
        # gate_compute_fn keywords must contain gate_type='tanh'
        assert wrapper.model.gate_compute_fn.keywords["gate_type"] == "tanh"

    def test_default_latent_size_consistent(self):
        """MLPGAF and MLPGAFNetwork must share the same latent_size default."""
        import inspect

        gaf_default = inspect.signature(MLPGAFNetwork).parameters["latent_size"].default
        wrap_default = inspect.signature(MLPGAF).parameters["latent_size"].default
        assert gaf_default == wrap_default, f"Default mismatch: MLPGAFNetwork={gaf_default}, MLPGAF={wrap_default}"
