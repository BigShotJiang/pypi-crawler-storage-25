import pytest
import torch

from twiga.models.nn.core.base_arch import BaseArchitecture


class TestNeuralNet(BaseArchitecture):
    """A mock neural network class for testing purposes.

    Inherits from:
        BaseArchitecture: The base class for neural network architectures.

    Methods:
        forward(x: torch.Tensor) -> torch.Tensor:
            Performs a forward pass through the network. This is a mock implementation
            that returns random tensor values for testing purposes.

    Attributes:
        forecast_horizon (int): The number of time steps to forecast.
        num_target_feature (int): The number of target features to predict.
    """

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Perform a forward pass through the network.

        Args:
            x (torch.Tensor): Input tensor of shape (batch_size, lookback_window_size, num_features).

        Returns:
            torch.Tensor: Output tensor of shape (batch_size, forecast_horizon, num_target_feature).
        """
        batch_size, lookback_window_size, _ = x.shape
        return torch.randn(batch_size, self.forecast_horizon, self.num_target_feature)


@pytest.fixture
def model() -> TestNeuralNet:
    """Fixture for creating a TestNeuralNet model instance.

    Returns:
        TestNeuralNet: An instance of the TestNeuralNet class with the specified parameters.
    """
    return TestNeuralNet(
        num_target_feature=1,
        num_historical_features=10,
        num_calendar_features=5,
        num_exogenous_features=3,
        num_future_covariates=1,
        forecast_horizon=48,
        lookback_window_size=96,
        dropout=0.25,
        alpha=0.1,
        output_activation="ReLU",
    )


def test_forecast(model: TestNeuralNet):
    """Test the forecast method of the model.

    Args:
        model (TestNeuralNet): The model instance to test.

    Asserts:
        - Output tensor has correct shape (10, 48, 1)
        - Batch dimension is preserved (10)
        - Forecast horizon matches model config (48)
        - Target feature dimension is correct (1)
    """
    x = torch.randn(10, 96, 10)  # Batch size 10, input window size 96, 10 features
    result = model.forecast(x)
    assert result.shape == (10, 48, 1)  # Batch size 10, forecast horizon 48, 1 target series


def test_step(model: TestNeuralNet):
    """Test the step method of the model.

    Args:
        model (TestNeuralNet): The model instance to test.

    Asserts:
        - Loss is a valid PyTorch tensor
        - Metric is a valid PyTorch tensor
        - Loss value is non-negative (>=0)
        - Metric value matches mock function (0.0)

    Notes:
        This test verifies:
        - Forward pass computation
        - Loss calculation
        - Metric computation
        - Type consistency of outputs
        - Valid range of loss values
    """
    x = torch.randn(10, 96, 10)  # Batch size 10, input window size 96, 10 features
    y = torch.randn(10, 48, 1)  # Batch size 10, forecast horizon 48, 1 target series

    def mock_metric_fn(y_pred: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        return torch.tensor(0.0)  # Mock metric function

    loss, metric = model.step((x, y), mock_metric_fn)
    assert isinstance(loss, torch.Tensor)
    assert isinstance(metric, torch.Tensor)
    assert loss.item() >= 0  # Ensure loss is non-negative
    assert metric <= loss.item()  # Ensure metric is as expected
