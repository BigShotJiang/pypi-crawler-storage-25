"""Tests for create_linear_layer, FeedForwardMLP, MLPEncoder.

FeedForwardBlock, and ReversibleInstanceNorm.
"""

from __future__ import annotations

import math
import warnings

import pytest
import torch
import torch.nn as nn

from twiga.models.nn.core.linear import (
    FeedForwardBlock,
    FeedForwardMLP,
    MLPEncoder,
    ReversibleInstanceNorm,
    create_linear_layer,
)

# ═══════════════════════════════════════════════════════════════════════════════
# create_linear_layer
# ═══════════════════════════════════════════════════════════════════════════════


class TestCreateLinearLayer:
    def test_no_norm_no_activation_returns_linear(self):
        """use_norm=False and no activation returns a bare nn.Linear."""
        layer = create_linear_layer(10, 20, use_norm=False, activation=None)
        assert isinstance(layer, nn.Linear)
        assert layer.in_features == 10
        assert layer.out_features == 20
        assert layer.bias is not None

    def test_no_norm_with_activation_returns_sequential(self):
        """use_norm=False with activation returns Sequential([Linear, activation])."""
        layer = create_linear_layer(10, 20, use_norm=False, activation="ReLU")
        assert isinstance(layer, nn.Sequential)
        assert len(layer) == 2
        assert isinstance(layer[0], nn.Linear)
        assert isinstance(layer[1], nn.ReLU)

    def test_norm_no_activation_returns_sequential(self):
        """use_norm=True with no activation returns Sequential([Linear, LayerNorm])."""
        layer = create_linear_layer(10, 20, use_norm=True, activation=None)
        assert isinstance(layer, nn.Sequential)
        assert len(layer) == 2
        assert isinstance(layer[0], nn.Linear)
        assert isinstance(layer[1], nn.LayerNorm)
        assert layer[1].normalized_shape[0] == 20

    def test_norm_and_activation_returns_sequential(self):
        """use_norm=True with activation returns Sequential([Linear, LayerNorm, activation])."""
        layer = create_linear_layer(10, 20, use_norm=True, activation="ReLU")
        assert isinstance(layer, nn.Sequential)
        assert len(layer) == 3
        assert isinstance(layer[0], nn.Linear)
        assert isinstance(layer[1], nn.LayerNorm)
        assert isinstance(layer[2], nn.ReLU)

    def test_use_bias_false(self):
        """use_bias=False produces a Linear with no bias term."""
        layer = create_linear_layer(10, 20, use_bias=False)
        assert layer.bias is None

    def test_invalid_in_channels(self):
        """Non-positive or non-integer in_channels raises ValueError."""
        for bad in [0, -1, 1.5]:
            with pytest.raises(ValueError, match="in_channels must be a positive integer"):
                create_linear_layer(bad, 20)

    def test_invalid_out_channels(self):
        """Non-positive or non-integer out_channels raises ValueError."""
        for bad in [0, -1, 20.5]:
            with pytest.raises(ValueError, match="out_channels must be a positive integer"):
                create_linear_layer(10, bad)

    def test_invalid_activation_string_raises(self):
        """An unrecognised activation string raises AttributeError or ValueError."""
        with pytest.raises((AttributeError, ValueError)):
            create_linear_layer(10, 20, activation="InvalidActivation")

    def test_activation_string_is_case_sensitive(self):
        """create_linear_layer uses getattr(nn, name) — 'relu' fails, 'ReLU' succeeds."""
        with pytest.raises(AttributeError):
            create_linear_layer(10, 20, activation="relu")
        layer = create_linear_layer(10, 20, activation="ReLU")
        assert isinstance(layer[1], nn.ReLU)

    def test_activation_as_module_instance(self):
        """Passing an nn.Module instance as activation is accepted."""
        layer = create_linear_layer(10, 20, use_norm=False, activation=nn.ReLU())
        assert isinstance(layer, nn.Sequential)
        assert isinstance(layer[1], nn.ReLU)

    def test_bias_initialised_to_zero(self):
        """Bias is always initialised to zero regardless of activation."""
        layer = create_linear_layer(64, 32, use_norm=False, activation="ReLU")
        assert torch.all(layer[0].bias == 0)

    def test_norm_gamma_beta_init(self):
        """LayerNorm gamma (weight) is initialised to 1 and beta (bias) to 0."""
        layer = create_linear_layer(10, 20, use_norm=True, activation=None)
        ln = layer[1]
        assert torch.all(ln.weight == 1.0), "gamma should be 1"
        assert torch.all(ln.bias == 0.0), "beta should be 0"

    @pytest.mark.parametrize(
        "activation,init_type",
        [
            ("ReLU", "kaiming"),
            ("Softplus", "kaiming"),
            ("SiLU", "kaiming"),
            ("GELU", "kaiming"),
            ("ELU", "kaiming"),
            ("Tanh", "xavier"),
            ("Sigmoid", "xavier"),
            ("SELU", "lecun"),
            ("LeakyReLU", "kaiming_leaky"),
            ("PReLU", "kaiming_leaky"),
        ],
    )
    def test_weight_initialisation(self, activation, init_type):
        """Weights are initialised according to the activation's recommended scheme."""
        in_ch, out_ch = 128, 64
        layer = create_linear_layer(in_ch, out_ch, use_norm=False, activation=activation)
        w = layer[0].weight.data
        mean, std = w.mean().item(), w.std().item()

        assert abs(mean) < 0.05, f"mean not near 0 for {activation}"

        if init_type == "kaiming":
            expected = math.sqrt(2 / in_ch)
        elif init_type == "kaiming_leaky":
            expected = math.sqrt(2 / (in_ch * (1 + 0.01**2)))
        elif init_type == "xavier":
            expected = math.sqrt(2 / (in_ch + out_ch))
        else:  # lecun
            expected = 1 / math.sqrt(in_ch)

        assert abs(std - expected) / expected < 0.25, (
            f"std={std:.4f} too far from expected={expected:.4f} for {activation}"
        )


# ═══════════════════════════════════════════════════════════════════════════════
# FeedForwardMLP
# ═══════════════════════════════════════════════════════════════════════════════


class TestFeedForwardMLP:
    # ── construction ──────────────────────────────────────────────────────────

    def test_layer_count_and_shapes_num_layers_3(self):
        """num_layers=3 builds first(8→16) + hidden(16→16) + final(16→8)."""
        mlp = FeedForwardMLP(
            input_features=2, num_timesteps=4, output_dim=8, hidden_dim=16, num_layers=3, use_norm=True
        )
        assert len(mlp.layers) == 3
        assert mlp.layers[0][0].in_features == 2 * 4
        assert mlp.layers[0][0].out_features == 16
        assert mlp.layers[1][0].in_features == 16
        assert mlp.layers[1][0].out_features == 16  # fixed width, not doubled
        assert mlp.layers[2][0].in_features == 16
        assert mlp.layers[2][0].out_features == 8

    def test_layer_count_num_layers_1(self):
        """num_layers=1 produces exactly one projection layer."""
        mlp = FeedForwardMLP(input_features=2, num_timesteps=4, output_dim=8, num_layers=1)
        assert len(mlp.layers) == 1

    def test_layer_count_num_layers_2(self):
        """num_layers=2 produces first + final with no hidden layers."""
        mlp = FeedForwardMLP(input_features=2, num_timesteps=4, output_dim=8, num_layers=2)
        assert len(mlp.layers) == 2

    def test_width_multiplier_gt1_produces_growing_hidden_dims(self):
        """width_multiplier=2 doubles each hidden layer width on each step."""
        mlp = FeedForwardMLP(
            input_features=2,
            num_timesteps=4,
            output_dim=8,
            hidden_dim=16,
            width_multiplier=2.0,
            max_hidden_dim=512,
            num_layers=4,
            use_norm=False,
        )
        assert mlp._hidden_layer_dims == [(16, 32), (32, 64)]

    def test_width_multiplier_lt1_clips_to_output_dim(self):
        """width_multiplier<1 shrinks each layer but never below output_dim."""
        mlp = FeedForwardMLP(
            input_features=2,
            num_timesteps=4,
            output_dim=16,
            hidden_dim=64,
            width_multiplier=0.5,
            num_layers=4,
            use_norm=False,
        )
        assert mlp._hidden_layer_dims[-1][1] >= 16

    def test_max_hidden_dim_caps_width(self):
        """max_hidden_dim prevents unbounded growth when width_multiplier > 1."""
        mlp = FeedForwardMLP(
            input_features=2,
            num_timesteps=4,
            output_dim=8,
            hidden_dim=64,
            width_multiplier=2.0,
            max_hidden_dim=100,
            num_layers=6,
            use_norm=False,
        )
        assert all(w <= 100 for _, w in mlp._hidden_layer_dims)

    def test_residual_fires_only_on_same_width_layers(self):
        """width_multiplier=2 makes all hidden layers change width — residual never fires."""
        mlp = FeedForwardMLP(
            input_features=2,
            num_timesteps=4,
            output_dim=8,
            hidden_dim=16,
            width_multiplier=2.0,
            num_layers=4,
            use_norm=False,
            use_residual=True,
        )
        assert not any(a == b for a, b in mlp._hidden_layer_dims)

    def test_residual_warning_no_hidden_layers(self):
        """use_residual=True warns when num_layers<=2 (no hidden layers exist)."""
        with pytest.warns(UserWarning, match="use_residual=True has no effect"):
            FeedForwardMLP(num_layers=2, use_residual=True)

    def test_residual_warning_all_different_width(self):
        """use_residual=True warns when width_multiplier makes all hidden layers change width."""
        with pytest.warns(UserWarning, match="use_residual=True has no effect"):
            FeedForwardMLP(
                input_features=2,
                num_timesteps=4,
                output_dim=8,
                hidden_dim=16,
                width_multiplier=2.0,
                num_layers=4,
                use_residual=True,
            )

    def test_no_warning_when_use_residual_false(self):
        """No warning is emitted when use_residual=False."""
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            FeedForwardMLP(num_layers=2, use_residual=False)

    def test_norm_layers_present_and_initialised(self):
        """All layers have LayerNorm with gamma=1, beta=0 when use_norm=True."""
        mlp = FeedForwardMLP(
            input_features=2, num_timesteps=4, output_dim=8, hidden_dim=16, num_layers=3, use_norm=True
        )
        for i in range(3):
            ln = mlp.layers[i][1]
            assert isinstance(ln, nn.LayerNorm), f"layer {i} missing LayerNorm"
            assert torch.all(ln.weight == 1.0)
            assert torch.all(ln.bias == 0.0)

    def test_activation_as_module(self):
        """Passing an nn.Module activation is stored correctly in every layer."""
        mlp = FeedForwardMLP(activation=nn.GELU())
        assert isinstance(mlp.layers[0][-1], nn.GELU)

    def test_repr_contains_shapes(self):
        """__repr__ shows the shape schedule and residual flag."""
        mlp = FeedForwardMLP(
            input_features=2, num_timesteps=4, output_dim=8, hidden_dim=16, num_layers=3, use_norm=False
        )
        r = repr(mlp)
        assert "shapes=" in r
        assert "residual=" in r

    # ── invalid params ────────────────────────────────────────────────────────

    @pytest.mark.parametrize(
        "param,value",
        [
            ("input_features", 0),
            ("input_features", -1),
            ("input_features", 1.5),
            ("output_dim", 0),
            ("output_dim", -1),
            ("hidden_dim", 0),
            ("hidden_dim", -1),
            ("hidden_dim", 1.5),
            ("num_layers", 0),
            ("num_layers", -1),
            ("num_layers", 1.5),
            ("num_timesteps", 0),
            ("num_timesteps", -1),
            ("num_timesteps", 1.5),
        ],
    )
    def test_invalid_int_params_raise(self, param, value):
        """Non-positive or non-integer dimension params raise ValueError."""
        with pytest.raises(ValueError, match=f"{param} must be a positive integer"):
            FeedForwardMLP(**{param: value})

    def test_invalid_width_multiplier(self):
        """Non-positive width_multiplier raises ValueError."""
        with pytest.raises(ValueError, match="width_multiplier must be a positive number"):
            FeedForwardMLP(width_multiplier=-1.0)
        with pytest.raises(ValueError, match="width_multiplier must be a positive number"):
            FeedForwardMLP(width_multiplier=0)

    # ── forward ───────────────────────────────────────────────────────────────

    def test_forward_3d_input(self):
        """3D input (B, T, D) is flattened and produces (B, output_dim)."""
        mlp = FeedForwardMLP(input_features=2, num_timesteps=4, output_dim=8, num_layers=2)
        assert mlp(torch.randn(32, 4, 2)).shape == (32, 8)

    def test_forward_2d_input(self):
        """Pre-flattened 2D input (B, T*D) is accepted directly."""
        mlp = FeedForwardMLP(input_features=2, num_timesteps=4, output_dim=8, num_layers=2)
        assert mlp(torch.randn(32, 8)).shape == (32, 8)

    def test_forward_num_layers_1(self):
        """Single-layer MLP correctly projects input to output_dim."""
        mlp = FeedForwardMLP(input_features=2, num_timesteps=4, output_dim=8, num_layers=1)
        assert mlp(torch.randn(32, 4, 2)).shape == (32, 8)

    def test_forward_wrong_3d_shape_raises(self):
        """Swapped (B, D, T) input raises ValueError with a clear message."""
        mlp = FeedForwardMLP(input_features=2, num_timesteps=4)
        with pytest.raises(ValueError, match=r"Expected input shape \(B, 4, 2\)"):
            mlp(torch.randn(32, 2, 4))

    def test_forward_wrong_2d_shape_raises(self):
        """Wrong flattened size raises ValueError with a clear message."""
        mlp = FeedForwardMLP(input_features=2, num_timesteps=4)
        with pytest.raises(ValueError, match="Expected flattened input of size 8"):
            mlp(torch.randn(32, 10))

    def test_forward_wrong_ndim_raises(self):
        """4D input raises ValueError."""
        mlp = FeedForwardMLP(input_features=2, num_timesteps=4)
        with pytest.raises(ValueError, match="Expected 2D or 3D input"):
            mlp(torch.randn(32, 2, 4, 1))

    def test_gradient_flows_through_residual(self):
        """Gradients propagate back through the residual skip connections."""
        mlp = FeedForwardMLP(
            input_features=2,
            num_timesteps=4,
            output_dim=8,
            hidden_dim=16,
            num_layers=4,
            width_multiplier=1.0,
            use_norm=False,
            use_residual=True,
        )
        x = torch.randn(4, 4, 2, requires_grad=True)
        mlp(x).sum().backward()
        assert x.grad is not None and not torch.all(x.grad == 0)


# ═══════════════════════════════════════════════════════════════════════════════
# ReversibleInstanceNorm
# ═══════════════════════════════════════════════════════════════════════════════


class TestReversibleInstanceNorm:
    def test_norm_denorm_is_identity(self):
        """Norm followed by denorm recovers the original tensor."""
        revin = ReversibleInstanceNorm(num_channels=3)
        x = torch.randn(8, 96, 3)
        assert torch.allclose(revin(revin(x, mode="norm"), mode="denorm"), x, atol=1e-5)

    def test_norm_zero_mean_unit_std(self):
        """After norm with affine=False, each instance has mean≈0 and std≈1."""
        revin = ReversibleInstanceNorm(num_channels=3, affine=False)
        x = torch.randn(16, 96, 3) * 10 + 5
        x_norm = revin(x, mode="norm")
        assert torch.allclose(x_norm.mean(dim=1), torch.zeros(16, 3), atol=1e-4)
        assert torch.allclose(x_norm.std(dim=1), torch.ones(16, 3), atol=1e-2)

    def test_affine_false_no_gamma_beta(self):
        """affine=False does not create gamma or beta parameters."""
        revin = ReversibleInstanceNorm(num_channels=3, affine=False)
        assert not hasattr(revin, "gamma")
        assert not hasattr(revin, "beta")

    def test_affine_true_has_gamma_beta(self):
        """affine=True creates learnable gamma and beta of shape (1, 1, C)."""
        revin = ReversibleInstanceNorm(num_channels=3, affine=True)
        assert revin.gamma.shape == (1, 1, 3)
        assert revin.beta.shape == (1, 1, 3)

    def test_invalid_mode_raises(self):
        """An unrecognised mode string raises ValueError."""
        revin = ReversibleInstanceNorm(num_channels=3)
        revin(torch.randn(4, 10, 3), mode="norm")
        with pytest.raises(ValueError, match="mode must be 'norm' or 'denorm'"):
            revin(torch.randn(4, 10, 3), mode="invalid")

    def test_invalid_num_channels_raises(self):
        """num_channels < 1 raises ValueError."""
        with pytest.raises(ValueError, match="num_channels must be >= 1"):
            ReversibleInstanceNorm(num_channels=0)


# ═══════════════════════════════════════════════════════════════════════════════
# MLPEncoder
# ═══════════════════════════════════════════════════════════════════════════════


class TestMLPEncoder:
    # ── construction ──────────────────────────────────────────────────────────

    def test_valid_init_with_embedding(self):
        """Valid init with embedding creates norm, encoder, and embedding submodules."""
        enc = MLPEncoder(
            embedding_size=28,
            latent_size=64,
            num_layers=2,
            context_size=96,
            num_channels=1,
            pos_embed_type="RotaryEmb",
            value_embed_type="ConvEmb",
        )
        assert isinstance(enc.encoder, FeedForwardMLP)
        assert isinstance(enc.norm, nn.LayerNorm)
        assert enc._uses_embedding
        assert hasattr(enc, "embedding")
        assert enc.encoder.input_features == 28

    def test_valid_init_no_embedding(self):
        """Without embedding, encoder input_features equals num_channels."""
        enc = MLPEncoder(
            embedding_size=28,
            latent_size=64,
            num_layers=2,
            context_size=96,
            num_channels=1,
            pos_embed_type=None,
            value_embed_type=None,
        )
        assert not enc._uses_embedding
        assert not hasattr(enc, "embedding")
        assert enc.encoder.input_features == 1

    def test_patch_emb_sets_encoder_seq_len(self):
        """PatchEmb compresses context_size T to N patches for the FeedForwardMLP."""
        from twiga.models.nn.core.embedding import PatchEmbedding

        enc = MLPEncoder(
            context_size=96,
            num_channels=1,
            value_embed_type="PatchEmb",
            patch_len=16,
            stride=8,
        )
        expected_n_patches = PatchEmbedding.num_patches(96, 16, 8)
        assert enc._encoder_seq_len == expected_n_patches
        assert enc.encoder.num_timesteps == expected_n_patches

    def test_use_temporal_mixer_true_creates_mixer(self):
        """use_temporal_mixer=True with a non-patch embedding creates a TemporalMixingLayer."""
        enc = MLPEncoder(
            context_size=96,
            num_channels=1,
            value_embed_type="LinearEmb",
            use_temporal_mixer=True,
        )
        assert enc._apply_temporal_mixer
        assert hasattr(enc, "temporal_mixer")

    def test_use_temporal_mixer_with_patch_emb_disables_mixer(self):
        """Mixer is silently disabled when PatchEmb already compresses T → N."""
        enc = MLPEncoder(
            context_size=96,
            num_channels=1,
            value_embed_type="PatchEmb",
            use_temporal_mixer=True,
        )
        assert not enc._apply_temporal_mixer
        assert not hasattr(enc, "temporal_mixer")

    # ── invalid params ────────────────────────────────────────────────────────

    @pytest.mark.parametrize(
        "param,value",
        [
            ("embedding_size", 0),
            ("embedding_size", -1),
            ("embedding_size", 1.5),
            ("latent_size", 0),
            ("latent_size", -1),
            ("num_layers", 0),
            ("num_layers", -1),
            ("context_size", 0),
            ("context_size", -1),
            ("num_channels", 0),
            ("num_channels", -1),
        ],
    )
    def test_invalid_int_params_raise(self, param, value):
        """Non-positive or non-integer dimension params raise ValueError."""
        with pytest.raises(ValueError, match=f"{param} must be a positive integer"):
            MLPEncoder(**{param: value})

    def test_invalid_dropout(self):
        """Dropout outside [0, 1] raises ValueError."""
        with pytest.raises(ValueError, match="dropout must be a float"):
            MLPEncoder(dropout=-0.1)
        with pytest.raises(ValueError, match="dropout must be a float"):
            MLPEncoder(dropout=1.1)

    def test_invalid_value_embed_type(self):
        """Unrecognised value_embed_type raises ValueError."""
        with pytest.raises(ValueError, match="value_embed_type must be one of"):
            MLPEncoder(value_embed_type="BogusEmb")

    def test_invalid_pos_embed_type(self):
        """Unrecognised pos_embed_type raises ValueError."""
        with pytest.raises(ValueError, match="pos_embed_type must be one of"):
            MLPEncoder(pos_embed_type="BogusPos")

    # ── _validate_input ───────────────────────────────────────────────────────

    def test_validate_wrong_ndim(self):
        """2D input raises ValueError before any processing."""
        enc = MLPEncoder(context_size=96, num_channels=1)
        with pytest.raises(ValueError, match="Expected 3D"):
            enc._validate_input(torch.randn(4, 96))

    def test_validate_wrong_seq_len(self):
        """Wrong sequence length raises ValueError with expected vs got."""
        enc = MLPEncoder(context_size=96, num_channels=1)
        with pytest.raises(ValueError, match="Expected T=96"):
            enc._validate_input(torch.randn(4, 48, 1))

    def test_validate_wrong_channel_count(self):
        """Wrong channel count raises ValueError with expected vs got."""
        enc = MLPEncoder(context_size=96, num_channels=3)
        with pytest.raises(ValueError, match="Expected C=3"):
            enc._validate_input(torch.randn(4, 96, 1))

    # ── forward ───────────────────────────────────────────────────────────────

    def test_forward_output_shape_with_embedding(self):
        """Forward with embedding produces (B, latent_size) output."""
        enc = MLPEncoder(
            embedding_size=28,
            latent_size=64,
            num_layers=2,
            context_size=96,
            num_channels=1,
            pos_embed_type="RotaryEmb",
            value_embed_type="ConvEmb",
        )
        assert enc(torch.randn(4, 96, 1)).shape == (4, 64)

    def test_forward_output_shape_no_embedding(self):
        """Forward without embedding produces (B, latent_size) output."""
        enc = MLPEncoder(
            latent_size=64,
            num_layers=2,
            context_size=96,
            num_channels=1,
            pos_embed_type=None,
            value_embed_type=None,
        )
        assert enc(torch.randn(32, 96, 1)).shape == (32, 64)

    def test_revin_caches_statistics_during_forward(self):
        """RevIN caches per-instance mean and std during forward().

        LayerNorm(C) inside MLPEncoder normalises each token over the
        feature dimension.  When C=1, LayerNorm produces identically-zero
        outputs regardless of input scale, making output comparisons
        uninformative.  The correct observable property is that RevIN caches
        _mean and _std during forward() — confirming it ran — and that the
        cached mean matches the per-instance mean of the raw input.
        """
        enc = MLPEncoder(
            context_size=96,
            num_channels=1,
            use_revin=True,
            pos_embed_type=None,
            value_embed_type=None,
        )
        x = torch.randn(4, 96, 1) * 100 + 50
        enc(x)

        assert hasattr(enc.revin, "_mean"), "revin._mean not set after forward()"
        assert hasattr(enc.revin, "_std"), "revin._std not set after forward()"
        expected_mean = x.mean(dim=1, keepdim=True)
        assert torch.allclose(enc.revin._mean, expected_mean, atol=1e-4)

    # ── denorm ────────────────────────────────────────────────────────────────

    def test_denorm_noop_when_use_revin_false(self):
        """denorm() returns y unchanged when use_revin=False."""
        enc = MLPEncoder(context_size=96, num_channels=1, use_revin=False, pos_embed_type=None, value_embed_type=None)
        y = torch.randn(4, 12, 1)
        assert torch.equal(enc.denorm(y), y)

    def test_denorm_raises_before_forward(self):
        """denorm() raises RuntimeError when called before forward()."""
        enc = MLPEncoder(context_size=96, num_channels=1, use_revin=True, pos_embed_type=None, value_embed_type=None)
        with pytest.raises(RuntimeError, match="denorm\\(\\) called before forward\\(\\)"):
            enc.denorm(torch.randn(4, 12, 1))

    def test_denorm_roundtrip(self):
        """ReversibleInstanceNorm norm→denorm is identity when affine=False.

        With affine=True the denorm applies ``(x - beta) / (gamma + eps)``,
        where the eps in the denominator introduces error ≈ x_norm * std * 1e-5
        (~1e-4 for typical inputs), exceeding atol=1e-5.  Using affine=False
        eliminates the affine transform entirely so the roundtrip is exact up
        to floating-point precision.
        """
        revin = ReversibleInstanceNorm(num_channels=3, affine=False)
        x = torch.randn(4, 96, 3) * 10 + 5
        x_normed = revin(x, mode="norm")
        x_recovered = revin(x_normed, mode="denorm")
        assert torch.allclose(x_recovered, x, atol=1e-5), "denorm(norm(x)) should recover x exactly when affine=False"


# ═══════════════════════════════════════════════════════════════════════════════
# FeedForwardBlock
# ═══════════════════════════════════════════════════════════════════════════════


class TestFeedForwardBlock:
    @pytest.fixture
    def ff(self):
        """Default FeedForwardBlock: dim=64, expansion_ratio=2, dropout=0.1, GELU, norm."""
        return FeedForwardBlock(dim=64, expansion_ratio=2, dropout=0.1, activation="GELU", use_norm=True)

    def test_structure(self, ff):
        """Block is Sequential with 4 elements: sub-block, dropout, sub-block, dropout."""
        assert isinstance(ff.block, nn.Sequential)
        assert len(ff.block) == 4
        assert isinstance(ff.block[1], nn.Dropout)
        assert isinstance(ff.block[3], nn.Dropout)

    def test_output_shape(self, ff):
        """Output shape matches input shape (dim-preserving block)."""
        assert ff(torch.randn(32, 64)).shape == (32, 64)

    def test_no_nan_or_inf(self, ff):
        """Forward pass produces finite values."""
        out = ff(torch.randn(32, 64))
        assert not torch.isnan(out).any()
        assert not torch.isinf(out).any()

    def test_expansion_ratio_sets_intermediate_dim(self):
        """expansion_ratio=4 sets intermediate layer width to dim * 4."""
        ff = FeedForwardBlock(dim=64, expansion_ratio=4, dropout=0.0, use_norm=True)
        assert ff.block[0][0].out_features == 256
        assert ff.block[2][0].in_features == 256

    def test_no_norm_activation_in_second_slot(self):
        """Without norm, activation is the second element in each sub-block."""
        ff = FeedForwardBlock(dim=64, expansion_ratio=2, dropout=0.0, activation="GELU", use_norm=False)
        assert isinstance(ff.block[0][1], nn.GELU)

    def test_dropout_probability(self, ff):
        """Dropout layers carry the specified probability."""
        assert ff.block[1].p == pytest.approx(0.1)
        assert ff.block[3].p == pytest.approx(0.1)

    def test_eval_mode_deterministic(self, ff):
        """Dropout is disabled in eval mode producing identical outputs."""
        x = torch.randn(32, 64)
        ff.eval()
        assert torch.allclose(ff(x), ff(x))

    def test_different_activation(self):
        """Activation type is correctly embedded in the sub-block."""
        ff = FeedForwardBlock(dim=64, expansion_ratio=2, dropout=0.0, activation="ReLU", use_norm=True)
        assert isinstance(ff.block[0][-1], nn.ReLU)

    def test_invalid_dim_raises(self):
        """dim=0 raises ValueError via create_linear_layer validation."""
        with pytest.raises(ValueError):
            FeedForwardBlock(dim=0)

    def test_invalid_dropout_raises(self):
        """Dropout outside [0, 1] raises an exception."""
        with pytest.raises((ValueError, Exception)):
            FeedForwardBlock(dim=64, dropout=-0.1)
        with pytest.raises((ValueError, Exception)):
            FeedForwardBlock(dim=64, dropout=1.1)

    def test_different_input_shape(self):
        """Works correctly for a different dim."""
        ff = FeedForwardBlock(dim=128, expansion_ratio=2, dropout=0.0)
        assert ff(torch.randn(16, 128)).shape == (16, 128)
