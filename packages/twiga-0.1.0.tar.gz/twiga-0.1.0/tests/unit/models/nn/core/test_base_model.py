from unittest.mock import MagicMock, patch

import pytest
import torch
import torch.nn as nn
import torch.optim as optim
import torchmetrics

from twiga.models.nn.core.base_model import BaseNeuralModel


@pytest.fixture
def base_model() -> BaseNeuralModel:
    """Fixture for creating a BaseNeuralModel instance.

    Returns:
        BaseNeuralModel: An instance of the BaseNeuralModel class with a mocked data pipeline and model.
    """
    data_pipeline = MagicMock()
    model = MagicMock()
    # Initialize with default types to trigger parameter resolution
    model_instance = BaseNeuralModel(metric="mae")
    model_instance.model = model
    model_instance.data_pipeline = data_pipeline
    return model_instance


def test_init_valid_params():
    """Test initialization with valid parameters.

    Verifies that BaseNeuralModel initializes correctly with valid inputs and default
    dictionaries.

    Asserts:
        - Model attributes are set correctly.
        - Hyperparameters are saved.
        - Metric functions are initialized.
    """
    model = BaseNeuralModel(
        metric="mae",
        max_epochs=10,
        checkpoints_path="./checkpoints",
    )
    assert model.hparams.metric == "mae"
    assert model.hparams.max_epochs == 10
    assert model.checkpoints_path == "./checkpoints"
    assert isinstance(model.tra_metric_fcn, torchmetrics.MeanAbsoluteError)
    assert isinstance(model.val_metric_fcn, torchmetrics.MeanAbsoluteError)

    # Verify parameter resolution occurred correctly
    assert "lr" in model.active_opt_params
    assert "gamma" in model.active_sch_params


def test_init_invalid_params():
    """Test initialization with invalid parameters.

    Verifies that BaseNeuralModel raises appropriate errors for invalid inputs.

    Asserts:
        - ValueError for invalid metric.
        - ValueError for negative max_epochs.
        - ValueError for invalid optimizer parameters.
    """
    with pytest.raises(ValueError, match=r"Invalid metric 'invalid'"):
        BaseNeuralModel(metric="invalid")

    with pytest.raises(ValueError, match=r"max_epochs must be a positive integer"):
        BaseNeuralModel(metric="mae", max_epochs=0)

    # Note: Updated match string to reflect new resolution-based validation
    with pytest.raises(ValueError, match=r"must be a non-negative number"):
        BaseNeuralModel(metric="mae", optimizer_type="adam", optimizer_params={"lr": -1})


def test_validate_params(base_model: BaseNeuralModel):
    """Test the validate_params method.

    Verifies that validate_params correctly validates metric and max_epochs.

    Args:
        base_model: The BaseNeuralModel instance to test.

    Asserts:
        - Valid parameters pass without errors.
        - Invalid parameters raise appropriate ValueError.
    """
    # Use the static method with the new signature (full resolution)
    BaseNeuralModel.validate_params(
        metric="mae",
        max_epochs=10,
        opt_type="adamw",
        opt_params=base_model.active_opt_params,
        sch_type="multi_step",
        sch_params=base_model.active_sch_params,
    )

    with pytest.raises(ValueError, match=r"Invalid metric 'invalid'"):
        BaseNeuralModel.validate_params(
            "invalid", 10, "adamw", base_model.active_opt_params, "multi_step", base_model.active_sch_params
        )

    with pytest.raises(ValueError, match=r"max_epochs must be a positive integer"):
        BaseNeuralModel.validate_params(
            "mae", -1, "adamw", base_model.active_opt_params, "multi_step", base_model.active_sch_params
        )


def test_calculate_model_size(base_model: BaseNeuralModel):
    """Test the calculate_model_size method.

    Verifies that the model size is calculated correctly in MB.

    Args:
        base_model: The BaseNeuralModel instance to test.

    Asserts:
        - Correct size calculation for a mocked model.
        - ValueError raised if model is None.
    """
    base_model.model = nn.Linear(10, 2)  # 10*2 weights + 2 biases = 22 parameters
    size_mb = base_model.calculate_model_size()
    param_size = (10 * 2 + 2) * 4  # 4 bytes per float32
    expected_size = param_size / 1024**2
    assert abs(size_mb - expected_size) < 1e-6

    base_model.model = None
    with pytest.raises(ValueError, match=r"Model is not initialized"):
        base_model.calculate_model_size()


def test_forward(base_model: BaseNeuralModel):
    """Test the forward method of the BaseNeuralModel.

    Verifies that the model's forward method correctly processes input tensors
    and delegates to the underlying neural network model.
    """
    x = torch.randn(10, 5)
    base_model.model.return_value = torch.randn(10, 1)
    output = base_model.forward(x)
    base_model.model.assert_called_once_with(x)
    assert torch.equal(output, base_model.model.return_value)


def test_forecast(base_model: BaseNeuralModel):
    """Test the forecast method of the BaseNeuralModel.

    Verifies that the model's forecast method properly generates
    predictions using the underlying neural network model.
    """
    x = torch.randn(10, 5)
    base_model.model.forecast.return_value = torch.randn(10, 1)
    output = base_model.forecast(x)
    base_model.model.forecast.assert_called_once_with(x)
    assert torch.equal(output, base_model.model.forecast.return_value)


@patch("joblib.dump")
def test_on_save_checkpoint(mock_dump: MagicMock, base_model: BaseNeuralModel):
    """Test the on_save_checkpoint method of the BaseNeuralModel."""
    checkpoint = {}
    base_model.on_save_checkpoint(checkpoint)

    expected_path = f"{base_model.checkpoints_path}/data_pipeline.pkl"
    mock_dump.assert_called_once_with(base_model.data_pipeline, expected_path)
    assert checkpoint["data_pipeline_path"] == expected_path


@patch("joblib.load")
def test_on_load_checkpoint(mock_load: MagicMock, base_model: BaseNeuralModel):
    """Test the on_load_checkpoint method of the BaseNeuralModel."""
    checkpoint = {"data_pipeline_path": "./data_pipeline.pkl"}
    mock_load.return_value = base_model.data_pipeline
    base_model.on_load_checkpoint(checkpoint)
    mock_load.assert_called_once_with("./data_pipeline.pkl")
    assert base_model.data_pipeline == mock_load.return_value


def test_training_step(base_model: BaseNeuralModel):
    """Test the training_step method of the BaseNeuralModel."""
    batch = (torch.randn(10, 5), torch.randn(10, 1))
    batch_idx = 0
    base_model.model.step.return_value = (torch.tensor(0.5), torch.tensor(0.1))
    with (
        patch.object(base_model, "optimizers", return_value=MagicMock()) as _,
        patch.object(base_model, "log") as mock_log,
    ):
        loss = base_model.training_step(batch, batch_idx)
        base_model.model.step.assert_called_once_with(batch, base_model.tra_metric_fcn, base_model.current_epoch)
        mock_log.assert_any_call(
            "train_loss", torch.tensor(0.5), prog_bar=True, logger=True, on_epoch=True, on_step=False
        )
        mock_log.assert_any_call(
            f"train_{base_model.hparams.metric}",
            torch.tensor(0.1),
            prog_bar=True,
            logger=True,
            on_epoch=True,
            on_step=False,
        )
        assert loss == torch.tensor(0.5)


def test_validation_step(base_model: BaseNeuralModel):
    """Test the validation_step method of the BaseNeuralModel."""
    batch = (torch.randn(10, 5), torch.randn(10, 1))
    batch_idx = 0
    base_model.model.step.return_value = (torch.tensor(0.5), torch.tensor(0.1))
    with patch.object(base_model, "log") as mock_log:
        base_model.validation_step(batch, batch_idx)
        base_model.model.step.assert_called_once_with(batch, base_model.val_metric_fcn, base_model.current_epoch)
        mock_log.assert_any_call("val_loss", torch.tensor(0.5), prog_bar=True, logger=True)
        mock_log.assert_any_call(
            f"val_{base_model.hparams.metric}",
            torch.tensor(0.1),
            prog_bar=True,
            logger=True,
            on_epoch=True,
            on_step=False,
        )


@pytest.mark.parametrize(
    "optimizer_type,scheduler_type,expected_optimizer,expected_scheduler",
    [
        ("adamw", "multi_step", optim.AdamW, optim.lr_scheduler.MultiStepLR),
        ("adam", "cosine_annealing", optim.Adam, optim.lr_scheduler.CosineAnnealingWarmRestarts),
        ("adamw", "reduce_on_plateau", optim.AdamW, optim.lr_scheduler.ReduceLROnPlateau),
        ("adam", "one_cycle", optim.Adam, optim.lr_scheduler.OneCycleLR),
        ("adamw", "warmup_multi_step", optim.AdamW, optim.lr_scheduler.SequentialLR),
    ],
)
def test_configure_optimizers(
    base_model: BaseNeuralModel,
    optimizer_type: str,
    scheduler_type: str,
    expected_optimizer: type,
    expected_scheduler: type,
):
    """Test the configure_optimizers method using resolved active parameters."""
    # Setup new state for resolution
    model = BaseNeuralModel(optimizer_type=optimizer_type, lr_scheduler_type=scheduler_type, max_epochs=10)
    model.model = nn.Sequential(nn.Linear(5, 1))

    if scheduler_type == "one_cycle":
        model.trainer = MagicMock()
        model.trainer.estimated_stepping_batches = None

    result = model.configure_optimizers()

    # Handle ReduceLROnPlateau return format (Dict vs Tuple)
    if scheduler_type == "reduce_on_plateau":
        assert isinstance(result, dict)
        optimizer = result["optimizer"]
        scheduler = result["lr_scheduler"]["scheduler"]
    else:
        optimizers, scheduler_dicts = result
        optimizer = optimizers[0]
        scheduler = scheduler_dicts[0]["scheduler"]
        assert scheduler_dicts[0]["interval"] == "epoch"

    assert isinstance(optimizer, expected_optimizer)

    # Verify scheduler logic
    if scheduler_type == "multi_step":
        params = model.active_sch_params
        expected_milestones = [
            int(params["prob_decay_1"] * 10),
            int(params["prob_decay_2"] * 10),
        ]
        assert sorted(scheduler.milestones) == sorted(expected_milestones)

    elif scheduler_type == "one_cycle":
        # Fallback to warmup_cosine (SequentialLR) when batches are None
        assert isinstance(scheduler, optim.lr_scheduler.SequentialLR)
