"""Unit tests for BaseNeuralForecast."""

import logging
from pathlib import Path
from unittest.mock import Mock

import numpy as np
from optuna import Trial
import pytest

# Set up logging for debugging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

from twiga.models.nn.core.base import BaseNeuralForecast


# Concrete subclass for testing
class TestNeuralForecast(BaseNeuralForecast):
    """Concrete subclass of BaseNeuralForecast for testing."""

    def update(self, trial: Trial) -> None:
        pass

    def load_checkpoint(self, checkpoints_path: str | Path) -> None:
        pass


# Fixtures
@pytest.fixture
def tmp_path(tmp_path):
    """Fixture for temporary directory."""
    return tmp_path


@pytest.fixture
def mock_model():
    """Fixture for a mock neural network model."""
    model = Mock()
    model.configure_optimizers = Mock(return_value=None)
    return model


@pytest.fixture
def mock_trainer():
    """Fixture for a mock PyTorch Lightning trainer."""
    trainer = Mock()
    trainer.fit = Mock()
    return trainer


@pytest.fixture
def mock_datamodule():
    """Fixture for a mock TimeseriesDataModule."""
    datamodule = Mock()
    datamodule.train_dataloader = Mock(return_value="train_loader")
    datamodule.val_dataloader = Mock(return_value="val_loader")
    return datamodule


@pytest.fixture
def base_neural_forecast(tmp_path):
    """Fixture for TestNeuralForecast instance with default config."""
    return TestNeuralForecast(
        checkpoints_path=tmp_path / "checkpoints",
        logs_path=tmp_path / "logs",
        project_name="test_project",
        rich_progress_bar=True,
        wandb_logging=False,
        batch_size=32,
        num_workers=4,
        max_epochs=2,
        seed=42,
        resume_training=True,
        metric="mae",
        patience=3,
        direction="min",
    )


# Test initialization
def test_init_default(base_neural_forecast, tmp_path):
    """Test initialization with default parameters."""
    logger.debug("Testing init_default")
    assert base_neural_forecast.wandb_logging is False
    assert base_neural_forecast.rich_progress_bar is True
    assert base_neural_forecast.drop_last is True
    assert base_neural_forecast.num_workers == 4
    assert base_neural_forecast.batch_size == 32
    assert base_neural_forecast.max_epochs == 2
    assert base_neural_forecast.pin_memory is True
    assert base_neural_forecast.seed == 42
    assert base_neural_forecast.resume_training is True
    assert base_neural_forecast.checkpoints_path == tmp_path / "checkpoints"
    assert base_neural_forecast.logs_path == tmp_path / "logs"
    assert base_neural_forecast.project_name == "test_project"
    assert base_neural_forecast.metric == "mae"
    assert base_neural_forecast.early_stop_patience == 3
    assert base_neural_forecast.direction == "min"


@pytest.mark.parametrize(
    "wandb_logging, rich_progress_bar, num_workers, batch_size",
    [
        (True, False, 0, 16),
        (False, True, 2, 128),
        (True, True, 8, 64),
    ],
)
def test_init_custom(tmp_path, wandb_logging, rich_progress_bar, num_workers, batch_size):
    """Test initialization with custom parameters."""
    logger.debug("Testing init_custom with wandb_logging=%s", wandb_logging)
    forecaster = TestNeuralForecast(
        wandb_logging=wandb_logging,
        rich_progress_bar=rich_progress_bar,
        num_workers=num_workers,
        batch_size=batch_size,
        checkpoints_path=tmp_path / "checkpoints",
        logs_path=tmp_path / "logs",
        project_name="custom_project",
    )
    assert forecaster.wandb_logging == wandb_logging
    assert forecaster.rich_progress_bar == rich_progress_bar
    assert forecaster.num_workers == num_workers
    assert forecaster.batch_size == batch_size
    assert forecaster.project_name == "custom_project"


# Test abstract methods
def test_abstract_methods():
    """Test that abstract methods prevent instantiation of incomplete subclasses."""
    logger.debug("Testing abstract_methods")

    class IncompleteForecaster(BaseNeuralForecast):
        pass

    with pytest.raises(TypeError, match="Can't instantiate abstract class"):
        IncompleteForecaster()

    class PartialForecaster(BaseNeuralForecast):
        def load_checkpoint(self, checkpoints_path):
            pass

    with pytest.raises(TypeError, match="Can't instantiate abstract class"):
        PartialForecaster()


def test_get_stopping_callback_no_patience(base_neural_forecast):
    """Test error when patience is missing without trial."""
    logger.debug("Testing get_stopping_callback_no_patience")
    base_neural_forecast.early_stop_patience = None
    with pytest.raises(ValueError, match="early_stop_patience must be specified"):
        base_neural_forecast._get_stopping_callback(None, "mae", "min", None)


def test_fit_no_model(base_neural_forecast):
    """Test fit raises error when model is not initialized."""
    logger.debug("Testing fit_no_model")
    base_neural_forecast.model = None
    x_train = np.random.rand(100, 10)
    y_train = np.random.rand(100, 1)
    with pytest.raises(RuntimeError, match="Model must be initialized before training"):
        base_neural_forecast.fit(x_train, y_train)


# @patch("lightning.pytorch.seed_everything")
# @patch("lightning.pytorch.Trainer")
# @patch("twiga.core.data.loader.TimeseriesDataModule")
# @patch("twiga.utils.utils.get_latest_checkpoint")
# def test_fit_training_failure(
#     mock_get_checkpoint, mock_datamodule, mock_trainer, mock_seed, base_neural_forecast, mock_model
# ):
#     """Test fit handles training exceptions."""
#     logger.debug("Testing fit_training_failure")
#     base_neural_forecast.model = mock_model
#     base_neural_forecast._configure_logger = Mock()
#     base_neural_forecast._get_stopping_callback = Mock()
#     base_neural_forecast._create_checkpoint_callback = Mock()
#     base_neural_forecast._get_progress_bar = Mock()
#     mock_trainer_instance = Mock()
#     mock_trainer_instance.fit.side_effect = RuntimeError("Training crash")
#     mock_trainer.return_value = mock_trainer_instance
#     mock_datamodule_instance = Mock()
#     mock_datamodule.return_value = mock_datamodule_instance
#     mock_get_checkpoint.return_value = None

#     x_train = np.random.rand(100, 10)
#     y_train = np.random.rand(100, 1)

#     with pytest.raises(RuntimeError, match="Training failed"):
#         base_neural_forecast.fit(x_train, y_train)
