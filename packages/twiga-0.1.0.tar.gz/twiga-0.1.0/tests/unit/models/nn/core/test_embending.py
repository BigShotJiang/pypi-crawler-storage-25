"""Tests for embedding.py — covers bugs in naive tests, and all remaining gaps."""

from __future__ import annotations

import pytest
import torch
import torch.nn as nn

from twiga.models.nn.core.embedding import (
    ConvEmbedding,
    DataEmbedding,
    LearnablePositionalEmbedding,
    LinearEmbedding,
    PatchEmbedding,
    PositionalEmbedding,
    RotaryEmbedding,
)

# ═══════════════════════════════════════════════════════════════════════════════
# Bugs in the prior test suite — document correct behaviour
# ═══════════════════════════════════════════════════════════════════════════════


class TestPositionalEmbeddingExistingBugs:
    """The two assertions in the old test_positional_embedding are wrong."""

    @pytest.mark.parametrize("hidden_size,max_len", [(64, 128), (32, 200)])
    def test_forward_shape_is_b_t_d_not_1_t_d(self, hidden_size, max_len):
        """forward() returns x + pe whose shape is (B, T, D), not (1, T, D)."""
        pe = PositionalEmbedding(hidden_size=hidden_size, max_len=max_len)
        x = torch.randn(32, 100, hidden_size)
        assert pe(x).shape == (32, 100, hidden_size)

    @pytest.mark.parametrize("hidden_size,max_len", [(64, 128), (32, 200)])
    def test_forward_values_not_bounded_to_minus1_plus1(self, hidden_size, max_len):
        """X + pe is NOT bounded to [-1, 1] when x contains large values."""
        pe = PositionalEmbedding(hidden_size=hidden_size, max_len=max_len)
        x = torch.randn(32, 100, hidden_size) * 5
        out = pe(x)
        assert not (torch.all(out >= -1.0) and torch.all(out <= 1.0))

    def test_raw_pe_buffer_is_bounded(self):
        """The raw sinusoidal buffer itself IS bounded to [-1, 1]."""
        pe = PositionalEmbedding(hidden_size=64, max_len=128)
        assert pe.pe.min() >= -1.0
        assert pe.pe.max() <= 1.0


class TestPatchEmbeddingNumPatchesBug:
    """Old test asserted num_patches(100, 16, 8)==11; correct answer is 12."""

    def test_correct_value_for_seq_100(self):
        """pad=(8-(100-16)%8)%8=4  →  (104-16)//8+1 = 12."""
        assert PatchEmbedding.num_patches(100, patch_len=16, stride=8) == 12


# ═══════════════════════════════════════════════════════════════════════════════
# RotaryEmbedding
# ═══════════════════════════════════════════════════════════════════════════════


class TestRotaryEmbeddingValidation:
    """Guard-clause tests for RotaryEmbedding constructor and forward."""

    def test_embed_dim_less_than_2_raises(self):
        """embed_dim=1 is rejected — RoPE requires pairs of dimensions."""
        with pytest.raises(ValueError, match="embed_dim must be at least 2"):
            RotaryEmbedding(embed_dim=1, max_seq_len=128)

    def test_max_seq_len_zero_raises(self):
        """max_seq_len=0 is rejected at construction time."""
        with pytest.raises(ValueError, match="max_seq_len must be at least 1"):
            RotaryEmbedding(embed_dim=64, max_seq_len=0)

    def test_input_dim_less_than_rope_dim_raises(self):
        """Input embedding dim smaller than RoPE embed_dim must raise."""
        rope = RotaryEmbedding(embed_dim=64, max_seq_len=128)
        x = torch.randn(4, 50, 32)  # 32 < 64
        with pytest.raises(ValueError, match="Input dim"):
            rope(x)

    def test_positions_wrong_length_raises(self):
        """Positions tensor whose length != seq_len must raise."""
        rope = RotaryEmbedding(embed_dim=64, max_seq_len=128)
        x = torch.randn(4, 50, 64)
        bad_pos = torch.arange(30).float()  # 30 != 50
        with pytest.raises(ValueError, match="positions shape"):
            rope(x, positions=bad_pos)


class TestRotaryEmbeddingExtendRotationTables:
    """Buffer growth when sequence length exceeds the precomputed table."""

    def test_auto_extends_on_forward(self):
        """forward() must not raise when seq_len > initial max_seq_len."""
        rope = RotaryEmbedding(embed_dim=64, max_seq_len=50)
        out = rope(torch.randn(2, 100, 64))
        assert out.shape == (2, 100, 64)

    def test_growth_factor_at_least_1_5x(self):
        """Rotation tables grow by at least 1.5× to avoid frequent reallocations."""
        rope = RotaryEmbedding(embed_dim=64, max_seq_len=50)
        rope._extend_rotation_tables(51, torch.device("cpu"))
        assert rope.max_seq_len >= 75  # 50 * 1.5 = 75

    def test_max_seq_len_updated_after_extend(self):
        """max_seq_len attribute reflects the new table size after extension."""
        rope = RotaryEmbedding(embed_dim=64, max_seq_len=50)
        rope._extend_rotation_tables(200, torch.device("cpu"))
        assert rope.max_seq_len >= 200


class TestRotaryEmbeddingBatchPositions:
    """RoPE with per-sample position tensors of shape (B, T)."""

    def test_batch_positions_accepted(self):
        """2-D positions tensor (B, T) is accepted and produces the correct shape."""
        rope = RotaryEmbedding(embed_dim=64, max_seq_len=128)
        x = torch.randn(4, 50, 64)
        positions = torch.linspace(0, 5, 50).unsqueeze(0).expand(4, -1)
        assert rope(x, positions=positions).shape == (4, 50, 64)


class TestRotaryEmbeddingNormPreservation:
    """Rotation is an isometry — the Frobenius norm of x must be unchanged."""

    def test_norm_preserved_no_positions(self):
        """Integer positions preserve the input norm."""
        rope = RotaryEmbedding(embed_dim=64, max_seq_len=128)
        x = torch.randn(8, 100, 64)
        assert torch.allclose(rope(x).norm(), x.norm(), atol=1e-4)

    def test_norm_preserved_with_positions(self):
        """Custom timestamp positions also preserve the input norm."""
        rope = RotaryEmbedding(embed_dim=64, max_seq_len=128)
        x = torch.randn(8, 100, 64)
        positions = torch.linspace(0, 10, 100)
        assert torch.allclose(rope(x, positions=positions).norm(), x.norm(), atol=1e-4)


# ═══════════════════════════════════════════════════════════════════════════════
# DataEmbedding
# ═══════════════════════════════════════════════════════════════════════════════


class TestDataEmbeddingBothNoneGuard:
    """DataEmbedding must reject the degenerate case where both embeddings are None."""

    def test_both_none_raises_on_forward(self):
        """forward() raises ValueError when neither embedding is set."""
        embed = DataEmbedding(c_in=2, hidden_size=64, value_embed_type=None, pos_embed_type=None)
        with pytest.raises(ValueError, match="At least one of"):
            embed(torch.randn(4, 50, 2))


class TestDataEmbeddingInitValidation:
    """Constructor rejects non-positive integers for all size arguments."""

    @pytest.mark.parametrize("bad", [0, -1])
    def test_invalid_c_in(self, bad):
        """c_in <= 0 raises at construction time."""
        with pytest.raises(ValueError, match="c_in must be at least 1"):
            DataEmbedding(c_in=bad, hidden_size=64)

    @pytest.mark.parametrize("bad", [0, -1])
    def test_invalid_hidden_size(self, bad):
        """hidden_size <= 0 raises at construction time."""
        with pytest.raises(ValueError, match="hidden_size must be at least 1"):
            DataEmbedding(c_in=2, hidden_size=bad)

    @pytest.mark.parametrize("bad", [0, -1])
    def test_invalid_max_seq_len(self, bad):
        """max_seq_len <= 0 raises at construction time."""
        with pytest.raises(ValueError, match="max_seq_len must be at least 1"):
            DataEmbedding(c_in=2, hidden_size=64, max_seq_len=bad)


class TestDataEmbeddingLearnPosEmb:
    """DataEmbedding composed with LearnablePositionalEmbedding."""

    @pytest.mark.parametrize("value_type", ["LinearEmb", "ConvEmb"])
    def test_output_shape(self, value_type):
        """Output shape is (B, T, D) for both LinearEmb and ConvEmb value types."""
        embed = DataEmbedding(
            c_in=2, hidden_size=64, value_embed_type=value_type, pos_embed_type="LearnPosEmb", max_seq_len=128
        )
        assert embed(torch.randn(8, 100, 2)).shape == (8, 100, 64)

    def test_pe_parameter_in_state_dict(self):
        """The learnable pe parameter must appear in state_dict for checkpointing."""
        embed = DataEmbedding(
            c_in=2, hidden_size=64, value_embed_type="LinearEmb", pos_embed_type="LearnPosEmb", max_seq_len=128
        )
        assert any("pe" in k for k in embed.state_dict())

    def test_output_differs_from_value_only(self):
        """Adding a positional encoding must change the output vs value-only."""
        x = torch.randn(4, 50, 2)
        val_only = DataEmbedding(
            c_in=2, hidden_size=64, value_embed_type="LinearEmb", pos_embed_type=None, max_seq_len=128, dropout=0.0
        )
        with_pos = DataEmbedding(
            c_in=2,
            hidden_size=64,
            value_embed_type="LinearEmb",
            pos_embed_type="LearnPosEmb",
            max_seq_len=128,
            dropout=0.0,
        )
        # Share value-embedding weights so only position differs
        with_pos.value_embedding.projection.weight.data = val_only.value_embedding.projection.weight.data.clone()
        assert not torch.allclose(val_only(x), with_pos(x))


class TestDataEmbeddingPatchEmb:
    """DataEmbedding composed with PatchEmbedding as the value encoder."""

    def test_channel_independent_output_shape(self):
        """Channel-independent mode merges batch and channel dims: (B*C, N, D)."""
        embed = DataEmbedding(c_in=7, hidden_size=64, value_embed_type="PatchEmb", pos_embed_type=None, max_seq_len=128)
        assert embed(torch.randn(32, 336, 7)).shape == (224, 41, 64)

    def test_output_non_trivial(self):
        """Patch embedding must produce a non-constant output."""
        embed = DataEmbedding(c_in=7, hidden_size=64, value_embed_type="PatchEmb", pos_embed_type=None, max_seq_len=128)
        assert embed(torch.randn(4, 336, 7)).std().item() > 0


class TestDataEmbeddingDropout:
    """Dropout is active in train mode and inactive in eval mode."""

    def test_dropout_zeroes_output_in_train_mode(self):
        """dropout=1.0 in train mode zeros every output element."""
        embed = DataEmbedding(c_in=2, hidden_size=64, value_embed_type="LinearEmb", pos_embed_type=None, dropout=1.0)
        embed.train()
        assert torch.all(embed(torch.randn(4, 50, 2)) == 0)

    def test_dropout_inactive_in_eval_mode(self):
        """dropout=1.0 in eval mode leaves the output non-zero."""
        embed = DataEmbedding(c_in=2, hidden_size=64, value_embed_type="LinearEmb", pos_embed_type=None, dropout=1.0)
        embed.eval()
        assert not torch.all(embed(torch.randn(4, 50, 2)) == 0)


class TestDataEmbeddingPositionsKwarg:
    """positions= kwarg is forwarded to RoPE only; all other embeddings ignore it."""

    def test_positions_kwarg_for_non_rope_does_not_raise(self):
        """Passing positions= to PosEmb / LearnPosEmb must not raise."""
        for pos_type in ("PosEmb", "LearnPosEmb"):
            embed = DataEmbedding(
                c_in=2, hidden_size=64, value_embed_type="LinearEmb", pos_embed_type=pos_type, max_seq_len=128
            )
            out = embed(torch.randn(4, 50, 2), positions=torch.linspace(0, 5, 50))
            assert out.shape == (4, 50, 64)


# ═══════════════════════════════════════════════════════════════════════════════
# ConvEmbedding
# ═══════════════════════════════════════════════════════════════════════════════


class TestConvEmbeddingValidation:
    """ConvEmbedding rejects non-positive size arguments."""

    @pytest.mark.parametrize("bad", [0, -1])
    def test_invalid_c_in(self, bad):
        """c_in <= 0 raises at construction time."""
        with pytest.raises(ValueError, match="c_in must be at least 1"):
            ConvEmbedding(c_in=bad, hidden_size=64)

    @pytest.mark.parametrize("bad", [0, -1])
    def test_invalid_hidden_size(self, bad):
        """hidden_size <= 0 raises at construction time."""
        with pytest.raises(ValueError, match="hidden_size must be at least 1"):
            ConvEmbedding(c_in=2, hidden_size=bad)


class TestConvEmbeddingProperties:
    """Structural and gradient properties of ConvEmbedding."""

    def test_projection_has_no_bias(self):
        """Projection Conv1d is initialised without a bias term (bias=False)."""
        conv = ConvEmbedding(c_in=2, hidden_size=64)
        assert conv.projection.bias is None

    def test_gradient_flows(self):
        """Gradients must propagate back to the input tensor."""
        conv = ConvEmbedding(c_in=2, hidden_size=64)
        x = torch.randn(4, 100, 2, requires_grad=True)
        conv(x).sum().backward()
        assert x.grad is not None
        assert not torch.all(x.grad == 0)

    def test_sequence_length_preserved(self):
        """kernel=3, padding=1 preserves T for any sequence length."""
        conv = ConvEmbedding(c_in=3, hidden_size=16)
        assert conv(torch.randn(2, 77, 3)).shape[1] == 77


# ═══════════════════════════════════════════════════════════════════════════════
# LinearEmbedding
# ═══════════════════════════════════════════════════════════════════════════════


class TestLinearEmbeddingValidation:
    """LinearEmbedding rejects non-positive size arguments."""

    @pytest.mark.parametrize("bad", [0, -1])
    def test_invalid_c_in(self, bad):
        """c_in <= 0 raises at construction time."""
        with pytest.raises(ValueError, match="c_in must be at least 1"):
            LinearEmbedding(c_in=bad, hidden_size=64)

    @pytest.mark.parametrize("bad", [0, -1])
    def test_invalid_hidden_size(self, bad):
        """hidden_size <= 0 raises at construction time."""
        with pytest.raises(ValueError, match="hidden_size must be at least 1"):
            LinearEmbedding(c_in=2, hidden_size=bad)


class TestLinearEmbeddingProperties:
    """Structural and gradient properties of LinearEmbedding."""

    def test_projection_has_no_bias(self):
        """Projection Linear is initialised without a bias term (bias=False)."""
        assert LinearEmbedding(c_in=2, hidden_size=64).projection.bias is None

    def test_gradient_flows(self):
        """Gradients must propagate back to the input tensor."""
        linear = LinearEmbedding(c_in=2, hidden_size=64)
        x = torch.randn(4, 100, 2, requires_grad=True)
        linear(x).sum().backward()
        assert x.grad is not None

    def test_timestep_independence(self):
        """Perturbing t=0 must not affect the output at t=1 (point-wise projection)."""
        linear = LinearEmbedding(c_in=4, hidden_size=16)
        x = torch.randn(1, 10, 4)
        x_pert = x.clone()
        x_pert[0, 0, :] += 100.0
        out_orig = linear(x)
        out_pert = linear(x_pert)
        assert not torch.allclose(out_orig[0, 0], out_pert[0, 0])
        assert torch.allclose(out_orig[0, 1], out_pert[0, 1])


# ═══════════════════════════════════════════════════════════════════════════════
# PatchEmbedding
# ═══════════════════════════════════════════════════════════════════════════════


class TestPatchEmbeddingGradient:
    """Gradients must flow through both channel strategies."""

    def test_gradient_flows_channel_independent(self):
        """Backward pass reaches the input in channel-independent mode."""
        emb = PatchEmbedding(c_in=7, hidden_size=64, patch_len=16, stride=8)
        x = torch.randn(4, 336, 7, requires_grad=True)
        emb(x).sum().backward()
        assert x.grad is not None
        assert not torch.all(x.grad == 0)

    def test_gradient_flows_channel_mixing(self):
        """Backward pass reaches the input in channel-mixing mode."""
        emb = PatchEmbedding(c_in=7, hidden_size=64, patch_len=16, stride=8, channel_independent=False)
        x = torch.randn(4, 336, 7, requires_grad=True)
        emb(x).sum().backward()
        assert x.grad is not None


class TestPatchEmbeddingRightPaddingBehaviour:
    """_apply_right_padding adds zeros only when T does not evenly fill patches."""

    def test_no_padding_when_already_exact(self):
        """No padding when (T - patch_len) is exactly divisible by stride."""
        emb = PatchEmbedding(c_in=1, hidden_size=8, patch_len=16, stride=16)
        x = torch.zeros(1, 96, 1)  # (96-16) % 16 == 0  → no pad
        assert emb._apply_right_padding(x).shape[1] == 96

    def test_correct_padding_amount(self):
        """Padding equals stride - remainder to reach the next complete patch."""
        emb = PatchEmbedding(c_in=1, hidden_size=8, patch_len=16, stride=8)
        x = torch.zeros(1, 100, 1)  # remainder=4 → right_pad=4
        assert emb._apply_right_padding(x).shape[1] == 104

    def test_padding_does_not_alter_channel_dim(self):
        """Padding only extends the time axis; channel count is unchanged."""
        emb = PatchEmbedding(c_in=5, hidden_size=8, patch_len=16, stride=8)
        x = torch.zeros(2, 101, 5)
        assert emb._apply_right_padding(x).shape[2] == 5


class TestPatchEmbeddingNumPatchesMatchesForward:
    """num_patches static method must agree with the N dimension from forward."""

    @pytest.mark.parametrize(
        "seq_len,patch_len,stride",
        [
            (336, 16, 8),
            (100, 16, 8),
            (96, 16, 16),
            (720, 32, 16),
        ],
    )
    def test_static_matches_forward(self, seq_len, patch_len, stride):
        """N from forward equals num_patches(seq_len, patch_len, stride)."""
        emb = PatchEmbedding(c_in=3, hidden_size=32, patch_len=patch_len, stride=stride)
        n_expected = PatchEmbedding.num_patches(seq_len, patch_len, stride)
        assert emb(torch.randn(2, seq_len, 3)).shape[1] == n_expected


# ═══════════════════════════════════════════════════════════════════════════════
# LearnablePositionalEmbedding
# ═══════════════════════════════════════════════════════════════════════════════


class TestLearnablePositionalEmbeddingInit:
    """Initialisation properties of LearnablePositionalEmbedding."""

    def test_init_std_near_002(self):
        """trunc_normal_(std=0.02) produces weights with std ≈ 0.02."""
        pe = LearnablePositionalEmbedding(hidden_size=256, max_len=512)
        assert abs(pe.pe.data.std().item() - 0.02) < 0.01

    def test_init_mean_near_zero(self):
        """trunc_normal_ is zero-centred; mean must be close to 0."""
        pe = LearnablePositionalEmbedding(hidden_size=256, max_len=512)
        assert abs(pe.pe.data.mean().item()) < 0.05

    def test_pe_in_state_dict(self):
        """Pe must appear in state_dict so it is saved with checkpoints."""
        pe = LearnablePositionalEmbedding(hidden_size=64, max_len=128)
        assert "pe" in pe.state_dict()

    @pytest.mark.parametrize("bad", [0, -1])
    def test_invalid_hidden_size_raises(self, bad):
        """hidden_size <= 0 raises at construction time."""
        with pytest.raises(ValueError, match="hidden_size must be at least 1"):
            LearnablePositionalEmbedding(hidden_size=bad, max_len=128)

    @pytest.mark.parametrize("bad", [0, -1])
    def test_invalid_max_len_raises(self, bad):
        """max_len <= 0 raises at construction time."""
        with pytest.raises(ValueError, match="max_len must be at least 1"):
            LearnablePositionalEmbedding(hidden_size=64, max_len=bad)


class TestLearnablePositionalEmbeddingForward:
    """Forward-pass correctness and gradient properties."""

    def test_output_equals_x_plus_pe_slice(self):
        """Output must equal x + pe[:, :T] exactly."""
        pe = LearnablePositionalEmbedding(hidden_size=64, max_len=512)
        x = torch.randn(4, 50, 64)
        expected = x + pe.pe[:, :50]
        assert torch.allclose(pe(x), expected)

    def test_gradient_accumulates_on_pe_parameter(self):
        """pe.grad must be populated after backward so the optimiser can update it."""
        pe = LearnablePositionalEmbedding(hidden_size=64, max_len=128)
        pe(torch.randn(2, 50, 64)).sum().backward()
        assert pe.pe.grad is not None

    def test_encoding_identical_across_batch_sizes(self):
        """The positional slice is batch-independent — only x varies."""
        pe = LearnablePositionalEmbedding(hidden_size=64, max_len=128)
        enc1 = pe(torch.zeros(1, 50, 64))
        enc8 = pe(torch.zeros(8, 50, 64))[:1]
        assert torch.allclose(enc1, enc8)

    def test_seq_exceeds_max_len_raises(self):
        """Sequence length > max_len must raise a clear ValueError."""
        pe = LearnablePositionalEmbedding(hidden_size=64, max_len=32)
        with pytest.raises(ValueError, match="Sequence length"):
            pe(torch.randn(2, 50, 64))
