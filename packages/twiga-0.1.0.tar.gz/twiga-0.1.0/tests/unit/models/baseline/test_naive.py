"""Unit tests for NAIVEConfig and NAIVEModel."""

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest

from twiga.core.config import BaseSearchSpace
from twiga.models.baseline.naive_model import NAIVEConfig, NAIVEModel

# ── Fixtures ──────────────────────────────────────────────────────────────────

BATCH, SEQ, FEATURES, HORIZONS = 20, 4, 6, 2


@pytest.fixture()
def xy():
    rng = np.random.default_rng(0)
    x = rng.standard_normal((BATCH, SEQ, FEATURES))
    y = rng.standard_normal((BATCH, SEQ, HORIZONS))
    return x, y


# ── Config ────────────────────────────────────────────────────────────────────


def test_naive_config_defaults():
    cfg = NAIVEConfig()
    assert cfg.name == "naive"
    assert cfg.domain == "baseline"
    assert cfg.strategy == "window_last"
    assert isinstance(cfg.search_space, BaseSearchSpace)
    assert set(cfg.search_space.strategy) == {"last", "window_last", "mean", "zero"}

    d = cfg.model_dump()
    assert "domain" not in d
    assert "name" not in d
    assert "search_space" not in d
    assert d["strategy"] == "window_last"


def test_naive_config_alias():
    cfg = NAIVEConfig(model_name="naive", strategy="last")
    assert cfg.name == "naive"
    assert cfg.strategy == "last"


def test_naive_config_invalid_strategy():
    with pytest.raises(ValidationError):
        NAIVEConfig(strategy="drift")


# ── Model instantiation ───────────────────────────────────────────────────────


def test_naive_model_instantiation():
    model = NAIVEModel()
    assert isinstance(model.model_config, NAIVEConfig)
    assert model._constant is None
    assert model.num_targets is None
    assert model.horizon is None


def test_naive_model_predict_unfitted():
    with pytest.raises(ValueError, match="not been fitted"):
        NAIVEModel().predict(np.random.randn(5, 3, 4))


def test_naive_model_predict_wrong_ndim():
    model = NAIVEModel()
    model.num_targets = 2
    model.horizon = 3
    with pytest.raises(ValueError, match="3-dimensional"):
        model.predict(np.random.randn(5, 4))


# ── Strategy: window_last ─────────────────────────────────────────────────────


def test_window_last_fit_returns_self(xy):
    x, y = xy
    model = NAIVEModel(NAIVEConfig(strategy="window_last"))
    assert model.fit(x, y) is model
    assert model.horizon == SEQ
    assert model.num_targets == HORIZONS
    assert model._constant is None  # window_last needs no stored constant


def test_window_last_predict_shape(xy):
    x, y = xy
    model = NAIVEModel(NAIVEConfig(strategy="window_last"))
    model.fit(x, y)
    preds = model.predict(x)
    assert preds.shape == (BATCH, SEQ, HORIZONS)


def test_window_last_uses_last_timestep(xy):
    x, y = xy
    model = NAIVEModel(NAIVEConfig(strategy="window_last"))
    model.fit(x, y)
    preds = model.predict(x)
    # Every horizon step of sample i should equal x[i, -1, :HORIZONS]
    for i in range(BATCH):
        expected = x[i, -1, :HORIZONS]
        np.testing.assert_array_equal(preds[i, 0, :], expected)
        np.testing.assert_array_equal(preds[i, -1, :], expected)


def test_window_last_each_sample_independent(xy):
    x, y = xy
    model = NAIVEModel(NAIVEConfig(strategy="window_last"))
    model.fit(x, y)
    preds = model.predict(x)
    # Different samples should (in general) differ
    assert not np.allclose(preds[0], preds[1])


# ── Strategy: last ────────────────────────────────────────────────────────────


def test_last_stores_final_training_sample(xy):
    x, y = xy
    model = NAIVEModel(NAIVEConfig(strategy="last"))
    model.fit(x, y)
    assert model._constant is not None
    assert model._constant.shape == (SEQ * HORIZONS,)


def test_last_predict_broadcasts_constant(xy):
    x, y = xy
    model = NAIVEModel(NAIVEConfig(strategy="last"))
    model.fit(x, y)
    preds = model.predict(x)
    assert preds.shape == (BATCH, SEQ, HORIZONS)
    # All samples should be identical (same constant)
    for i in range(1, BATCH):
        np.testing.assert_array_equal(preds[0], preds[i])


# ── Strategy: mean ────────────────────────────────────────────────────────────


def test_mean_stores_per_output_mean(xy):
    x, y = xy
    model = NAIVEModel(NAIVEConfig(strategy="mean"))
    model.fit(x, y)
    y_fmt = y.reshape(BATCH, -1)
    np.testing.assert_allclose(model._constant, y_fmt.mean(axis=0))


def test_mean_predict_shape(xy):
    x, y = xy
    model = NAIVEModel(NAIVEConfig(strategy="mean"))
    model.fit(x, y)
    preds = model.predict(x)
    assert preds.shape == (BATCH, SEQ, HORIZONS)


def test_mean_predict_broadcasts_constant(xy):
    x, y = xy
    model = NAIVEModel(NAIVEConfig(strategy="mean"))
    model.fit(x, y)
    preds = model.predict(x)
    for i in range(1, BATCH):
        np.testing.assert_array_equal(preds[0], preds[i])


# ── Strategy: zero ────────────────────────────────────────────────────────────


def test_zero_predict_all_zeros(xy):
    x, y = xy
    model = NAIVEModel(NAIVEConfig(strategy="zero"))
    model.fit(x, y)
    preds = model.predict(x)
    assert preds.shape == (BATCH, SEQ, HORIZONS)
    np.testing.assert_array_equal(preds, 0.0)


# ── eval_set ignored ─────────────────────────────────────────────────────────


def test_fit_ignores_eval_set(xy):
    x, y = xy
    x_val = np.random.randn(5, SEQ, FEATURES)
    y_val = np.random.randn(5, SEQ, HORIZONS)
    model = NAIVEModel()
    model.fit(x, y, eval_set=(x_val, y_val))
    assert model.predict(x).shape == (BATCH, SEQ, HORIZONS)


# ── forecast ─────────────────────────────────────────────────────────────────


def test_forecast_returns_array(xy):
    x, y = xy
    model = NAIVEModel()
    model.fit(x, y)
    out = model.forecast(x)
    assert isinstance(out, np.ndarray)
    assert out.shape == (BATCH, SEQ, HORIZONS)


# ── update (HPO) ──────────────────────────────────────────────────────────────


def test_update_changes_strategy(xy):
    x, y = xy
    model = NAIVEModel(NAIVEConfig(strategy="last"))
    model.fit(x, y)
    mock_trial = MagicMock()
    with patch.object(NAIVEConfig, "get_optuna_params", return_value={"strategy": "mean"}):
        model.update(mock_trial)
    assert model.model_config.strategy == "mean"
    assert model._constant is None  # reset after update
