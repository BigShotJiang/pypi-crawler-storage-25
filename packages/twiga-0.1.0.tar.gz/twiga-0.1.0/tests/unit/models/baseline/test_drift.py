"""Unit tests for DRIFTConfig and DRIFTModel."""

from unittest.mock import MagicMock

import numpy as np
import pytest

from twiga.models.baseline.drift_model import DRIFTConfig, DRIFTModel

# ── Fixtures ──────────────────────────────────────────────────────────────────

BATCH, SEQ, FEATURES, HORIZONS = 12, 8, 5, 4


# ── Config ────────────────────────────────────────────────────────────────────


def test_drift_config_defaults():
    cfg = DRIFTConfig()
    assert cfg.name == "drift"
    assert cfg.domain == "baseline"

    d = cfg.model_dump()
    assert "domain" not in d
    assert "name" not in d
    assert "search_space" not in d


def test_drift_config_alias():
    cfg = DRIFTConfig(model_name="drift")
    assert cfg.name == "drift"


# ── Model instantiation ───────────────────────────────────────────────────────


def test_drift_model_instantiation():
    model = DRIFTModel()
    assert isinstance(model.model_config, DRIFTConfig)
    assert model.num_targets is None
    assert model.horizon is None


def test_drift_model_predict_unfitted():
    with pytest.raises(ValueError, match="not been fitted"):
        DRIFTModel().predict(np.random.randn(5, 8, 4))


def test_drift_model_predict_wrong_ndim():
    model = DRIFTModel()
    model.num_targets = 2
    model.horizon = 4
    with pytest.raises(ValueError, match="3-dimensional"):
        model.predict(np.random.randn(5, 4))


# ── Fit ───────────────────────────────────────────────────────────────────────


def test_fit_returns_self():
    model = DRIFTModel()
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    assert model.fit(x, y) is model
    assert model.horizon == SEQ
    assert model.num_targets == HORIZONS


def test_fit_ignores_eval_set():
    model = DRIFTModel()
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model.fit(x, y, eval_set=(np.random.randn(4, SEQ, FEATURES), np.random.randn(4, SEQ, HORIZONS)))
    assert model.num_targets == HORIZONS


# ── Predict — shape ───────────────────────────────────────────────────────────


def test_predict_shape():
    model = DRIFTModel()
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model.fit(x, y)
    preds = model.predict(x)
    assert preds.shape == (BATCH, SEQ, HORIZONS)


# ── Predict — correctness ─────────────────────────────────────────────────────


def test_predict_linear_series_exact():
    """For a perfectly linear series the drift should extrapolate exactly."""
    # Build x where each sample is a linear ramp in the target channel
    batch, seq, feat, horiz = 3, 6, 4, 4
    x = np.zeros((batch, seq, feat))
    # Target channels 0 and 1: y_t = slope * t for different slopes
    slopes = np.array([[1.0, 2.0], [0.5, -1.0], [3.0, 0.0]])  # (B, 2)
    for t in range(seq):
        x[:, t, :2] = slopes * t  # x[b, t, :2] = slope * t

    y = np.zeros((batch, horiz, 2))
    model = DRIFTModel()
    model.fit(x, y)
    preds = model.predict(x)

    # Expected: last = slopes * (seq-1), drift = slopes (since first=0)
    # pred[b, h, :] = last[b, :] + (h+1) * drift[b, :]
    #               = slopes[b] * (seq-1) + (h+1) * slopes[b]
    #               = slopes[b] * (seq + h)
    for b in range(batch):
        for h in range(horiz):
            expected = slopes[b] * (seq + h)
            np.testing.assert_allclose(preds[b, h, :2], expected, rtol=1e-6)


def test_predict_constant_series_zero_drift():
    """A constant series should produce the same value for all horizon steps."""
    x = np.ones((BATCH, SEQ, FEATURES)) * 5.0
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model = DRIFTModel()
    model.fit(x, y)
    preds = model.predict(x)
    # drift = 0, so all predictions = last = 5.0
    np.testing.assert_allclose(preds[:, :, :HORIZONS], 5.0, rtol=1e-6)


def test_predict_single_step_window_no_error():
    """seq_len=1 should fall back to persistence (drift=0)."""
    x = np.random.randn(BATCH, 1, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model = DRIFTModel()
    model.fit(x, y)
    preds = model.predict(x)
    assert preds.shape == (BATCH, SEQ, HORIZONS)
    # All predictions equal the single observed value
    for h in range(SEQ):
        np.testing.assert_array_equal(preds[:, h, :], x[:, 0, :HORIZONS])


def test_predict_negative_trend():
    """Negative drift should produce decreasing predictions."""
    x = np.zeros((BATCH, SEQ, FEATURES))
    # Decreasing target: starts at seq-1, ends at 0
    for t in range(SEQ):
        x[:, t, 0] = SEQ - 1 - t
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model = DRIFTModel()
    model.fit(x, y)
    preds = model.predict(x)
    # drift = (0 - (seq-1)) / (seq-1) = -1
    # pred[:, h, 0] = 0 + (h+1)*(-1)
    for h in range(SEQ):
        np.testing.assert_allclose(preds[:, h, 0], -(h + 1), rtol=1e-6)


def test_predict_independent_samples():
    """Different input windows should produce different drift predictions."""
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model = DRIFTModel()
    model.fit(x, y)
    preds = model.predict(x)
    assert not np.allclose(preds[0], preds[1])


def test_forecast_returns_array():
    model = DRIFTModel()
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model.fit(x, y)
    out = model.forecast(x)
    assert isinstance(out, np.ndarray)
    assert out.shape == (BATCH, SEQ, HORIZONS)


# ── Update (HPO) ──────────────────────────────────────────────────────────────


def test_update_is_noop():
    """Drift has no hyperparameters; update should not raise."""
    model = DRIFTModel()
    mock_trial = MagicMock()
    mock_trial.suggest_categorical = MagicMock(return_value=None)
    # Should not raise; model_config unchanged
    model.update(mock_trial)
    assert isinstance(model.model_config, DRIFTConfig)
