"""Unit tests for CONTEXTPARROTConfig and CONTEXTPARROTModel."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest

from twiga.core.config import BaseSearchSpace
from twiga.models.baseline.context_parrot_model import CONTEXTPARROTConfig, CONTEXTPARROTModel

# ── Constants ─────────────────────────────────────────────────────────────────

BATCH = 8
SEQ = 50  # lookback window length L
FEATURES = 4  # total feature columns (first num_targets are target columns)
HORIZONS = 6  # forecast horizon H
NUM_TARGETS = 2
DIM = 10  # embedding_dim D (default); min_seq_len = 2*10+1 = 21


# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture()
def rng() -> np.random.Generator:
    return np.random.default_rng(42)


@pytest.fixture()
def xy(rng):
    """Valid (X, y) pair satisfying shape contracts."""
    x = rng.standard_normal((BATCH, SEQ, FEATURES))
    y = rng.standard_normal((BATCH, HORIZONS, NUM_TARGETS))
    return x, y


@pytest.fixture()
def fitted_model(xy):
    x, y = xy
    model = CONTEXTPARROTModel()
    model.fit(x, y)
    return model


# ── Config: defaults ──────────────────────────────────────────────────────────


class TestCONTEXTPARROTConfig:
    def test_defaults(self):
        cfg = CONTEXTPARROTConfig()
        assert cfg.name == "context_parrot"
        assert cfg.domain == "baseline"
        assert cfg.embedding_dim == 10

    def test_name_alias(self):
        cfg = CONTEXTPARROTConfig(model_name="context_parrot")
        assert cfg.name == "context_parrot"

    def test_excluded_fields_not_in_dump(self):
        cfg = CONTEXTPARROTConfig()
        d = cfg.model_dump()
        assert "name" not in d
        assert "domain" not in d
        assert "search_space" not in d
        assert d["embedding_dim"] == 10

    def test_search_space_is_base_search_space(self):
        cfg = CONTEXTPARROTConfig()
        assert isinstance(cfg.search_space, BaseSearchSpace)
        assert 10 in cfg.search_space.embedding_dim

    def test_custom_embedding_dim(self):
        cfg = CONTEXTPARROTConfig(embedding_dim=24)
        assert cfg.embedding_dim == 24

    def test_embedding_dim_must_be_positive(self):
        with pytest.raises(ValidationError):
            CONTEXTPARROTConfig(embedding_dim=0)
        with pytest.raises(ValidationError):
            CONTEXTPARROTConfig(embedding_dim=-5)


# ── Model: instantiation ──────────────────────────────────────────────────────


class TestCONTEXTPARROTModelInstantiation:
    def test_default_config_assigned(self):
        model = CONTEXTPARROTModel()
        assert isinstance(model.model_config, CONTEXTPARROTConfig)

    def test_custom_config_accepted(self):
        cfg = CONTEXTPARROTConfig(embedding_dim=24)
        model = CONTEXTPARROTModel(cfg)
        assert model.model_config.embedding_dim == 24

    def test_initial_state_none(self):
        model = CONTEXTPARROTModel()
        assert model.num_targets is None
        assert model.horizon is None
        assert model.model is None  # no sklearn model

    def test_min_seq_len_formula(self):
        for d in [5, 10, 24, 48]:
            model = CONTEXTPARROTModel(CONTEXTPARROTConfig(embedding_dim=d))
            assert model.min_seq_len == 2 * d + 1


# ── Model: fit ────────────────────────────────────────────────────────────────


class TestCONTEXTPARROTModelFit:
    def test_fit_returns_self(self, xy):
        x, y = xy
        model = CONTEXTPARROTModel()
        assert model.fit(x, y) is model

    def test_fit_stores_horizon_and_num_targets(self, xy):
        x, y = xy
        model = CONTEXTPARROTModel()
        model.fit(x, y)
        assert model.horizon == HORIZONS
        assert model.num_targets == NUM_TARGETS

    def test_fit_accepts_eval_set(self, xy, rng):
        x, y = xy
        x_val = rng.standard_normal((3, SEQ, FEATURES))
        y_val = rng.standard_normal((3, HORIZONS, NUM_TARGETS))
        model = CONTEXTPARROTModel()
        model.fit(x, y, eval_set=(x_val, y_val))
        assert model.horizon == HORIZONS

    def test_fit_rejects_2d_x(self, rng):
        model = CONTEXTPARROTModel()
        with pytest.raises(ValueError, match="3-dimensional"):
            model.fit(rng.standard_normal((BATCH, SEQ)), rng.standard_normal((BATCH, HORIZONS, NUM_TARGETS)))

    def test_fit_rejects_2d_y(self, rng):
        model = CONTEXTPARROTModel()
        with pytest.raises(ValueError, match="3-dimensional"):
            model.fit(rng.standard_normal((BATCH, SEQ, FEATURES)), rng.standard_normal((BATCH, HORIZONS)))

    def test_fit_rejects_seq_too_short(self, rng):
        d = 10
        model = CONTEXTPARROTModel(CONTEXTPARROTConfig(embedding_dim=d))
        short_seq = 2 * d  # needs 2*d+1
        x = rng.standard_normal((BATCH, short_seq, FEATURES))
        y = rng.standard_normal((BATCH, HORIZONS, NUM_TARGETS))
        with pytest.raises(ValueError, match="Sequence length"):
            model.fit(x, y)

    def test_fit_accepts_exactly_min_seq_len(self, rng):
        d = 5
        model = CONTEXTPARROTModel(CONTEXTPARROTConfig(embedding_dim=d))
        min_len = model.min_seq_len  # 11
        x = rng.standard_normal((4, min_len, FEATURES))
        y = rng.standard_normal((4, HORIZONS, NUM_TARGETS))
        model.fit(x, y)
        assert model.horizon == HORIZONS


# ── Model: predict ────────────────────────────────────────────────────────────


class TestCONTEXTPARROTModelPredict:
    def test_predict_unfitted_raises(self, rng):
        model = CONTEXTPARROTModel()
        with pytest.raises(ValueError, match="not been fitted"):
            model.predict(rng.standard_normal((BATCH, SEQ, FEATURES)))

    def test_predict_2d_input_raises(self, fitted_model, rng):
        with pytest.raises(ValueError, match="3-dimensional"):
            fitted_model.predict(rng.standard_normal((BATCH, SEQ)))

    def test_predict_seq_too_short_raises(self, fitted_model, rng):
        short_seq = fitted_model.min_seq_len - 1
        with pytest.raises(ValueError, match="Sequence length"):
            fitted_model.predict(rng.standard_normal((BATCH, short_seq, FEATURES)))

    def test_predict_output_shape(self, fitted_model, xy):
        x, _ = xy
        preds = fitted_model.predict(x)
        assert preds.shape == (BATCH, HORIZONS, NUM_TARGETS)

    def test_predict_dtype_float(self, fitted_model, xy):
        x, _ = xy
        preds = fitted_model.predict(x)
        assert preds.dtype == float

    def test_predict_finite_values(self, fitted_model, xy):
        x, _ = xy
        preds = fitted_model.predict(x)
        assert np.isfinite(preds).all()

    def test_forecast_matches_predict(self, fitted_model, xy):
        x, _ = xy
        np.testing.assert_array_equal(fitted_model.forecast(x), fitted_model.predict(x))


# ── Algorithm correctness ─────────────────────────────────────────────────────


class TestContextParrotAlgorithm:
    def test_nearest_neighbour_copies_correct_segment(self):
        """Construct a context where the NN match is deterministic and verify the output."""
        # L=30, D=5, H=4, T=1
        d, h, t = 5, 4, 1
        seq_len = 30
        model = CONTEXTPARROTModel(CONTEXTPARROTConfig(embedding_dim=d))

        rng = np.random.default_rng(0)
        x_single = rng.standard_normal((seq_len, t + 2))

        # Plant an exact copy of the last D steps at position 0
        query = x_single[-d:, :t].copy()  # the motif the algorithm will search for
        x_single[:d, :t] = query  # position 0 is an exact match → distance = 0

        x_batch = x_single[np.newaxis]  # (1, L, F)
        y = rng.standard_normal((1, h, t))
        model.fit(x_batch, y)

        preds = model.predict(x_batch)  # (1, H, T)

        # Best match is i=0; forecast_start = 0 + d = d
        expected = x_single[d : d + h, :t]  # context[d:d+h] — the segment after the match
        np.testing.assert_allclose(preds[0], expected, atol=1e-12)

    def test_cyclic_tiling_when_tail_shorter_than_horizon(self):
        """When the matched segment is followed by fewer steps than H, tiling fills the horizon."""
        d, h, t = 5, 10, 1
        # Set seq_len so that the best match near the end leaves a short tail.
        # n_candidates = seq_len - 2*d; best match at n_candidates-1 → forecast_start = (seq_len - 2d - 1) + d
        # tail length = seq_len - forecast_start = d + 1
        seq_len = 3 * d  # n_candidates = d; best at position d-1 → forecast_start = 2d-1, tail=d+1
        # But we want to be explicit: put an exact match at position n_candidates - 1
        model = CONTEXTPARROTModel(CONTEXTPARROTConfig(embedding_dim=d))

        rng = np.random.default_rng(1)
        x_single = rng.standard_normal((seq_len, t + 1))

        # Force query match at last candidate position to get a short tail
        n_candidates = seq_len - 2 * d
        best_i = n_candidates - 1  # last candidate
        query = x_single[-d:, :t].copy()
        x_single[best_i : best_i + d, :t] = query  # exact match at best_i

        x_batch = x_single[np.newaxis]
        y = rng.standard_normal((1, h, t))
        model.fit(x_batch, y)

        preds = model.predict(x_batch)
        assert preds.shape == (1, h, t)
        assert np.isfinite(preds).all()

        # Verify tiling: tail = x_single[best_i+d:, :t]
        tail = x_single[best_i + d :, :t]
        assert len(tail) < h, "tail must be shorter than horizon for tiling to be tested"
        # Reconstruct expected tiled output
        repeats = h // len(tail) + 1
        expected = np.tile(tail, (repeats, 1))[:h]
        np.testing.assert_allclose(preds[0], expected, atol=1e-12)

    def test_fallback_when_no_candidates(self):
        """When n_candidates < 1, the last observed value is broadcast for the full horizon.

        The n_candidates < 1 path is normally unreachable because predict() validates
        seq_len >= min_seq_len = 2*D+1, which guarantees n_candidates >= 1.  We reach
        the defensive branch by patching min_seq_len to seq_len == 2*D so the guard
        passes while n_candidates = 0.
        """
        d, h, t = 5, 3, 1
        seq_len = 2 * d  # n_candidates = seq_len - 2*D = 0 → fallback

        rng = np.random.default_rng(2)
        x = rng.standard_normal((2, seq_len, t + 2))

        model = CONTEXTPARROTModel(CONTEXTPARROTConfig(embedding_dim=d))
        model.num_targets = t
        model.horizon = h

        # Patch min_seq_len so that seq_len passes the guard inside predict()
        with patch.object(type(model), "min_seq_len", new_callable=lambda: property(lambda self: seq_len)):
            preds = model.predict(x)

        # Fallback: every horizon step equals the last observed target value
        for b in range(2):
            last_val = x[b, -1, :t]
            expected = np.broadcast_to(last_val, (h, t))
            np.testing.assert_allclose(preds[b], expected)

    def test_different_samples_produce_different_forecasts(self, xy, fitted_model):
        """Each sample does its own NN lookup → forecasts differ across the batch."""
        x, _ = xy
        preds = fitted_model.predict(x)
        # Not all identical (extremely unlikely with random data)
        assert not np.allclose(preds[0], preds[1])

    def test_single_target_matches_knn_intuition(self):
        """With T=1, the algorithm is equivalent to 1-NN on D lag features."""
        d, h, t = 3, 2, 1
        seq_len = 20
        model = CONTEXTPARROTModel(CONTEXTPARROTConfig(embedding_dim=d))

        rng = np.random.default_rng(7)
        x = rng.standard_normal((3, seq_len, t))
        y = rng.standard_normal((3, h, t))
        model.fit(x, y)

        preds = model.predict(x)
        assert preds.shape == (3, h, t)
        assert np.isfinite(preds).all()


# ── HPO: update ───────────────────────────────────────────────────────────────


class TestCONTEXTPARROTModelUpdate:
    def test_update_rebuilds_config(self, fitted_model):
        mock_trial = MagicMock()
        with patch.object(CONTEXTPARROTConfig, "get_optuna_params", return_value={"embedding_dim": 24}):
            fitted_model.update(mock_trial)
        assert fitted_model.model_config.embedding_dim == 24

    def test_update_keeps_default_when_param_absent(self, fitted_model):
        mock_trial = MagicMock()
        with patch.object(CONTEXTPARROTConfig, "get_optuna_params", return_value={}):
            fitted_model.update(mock_trial)
        # Falls back to existing embedding_dim
        assert fitted_model.model_config.embedding_dim == DIM
