"""Unit tests for WINDOWAVERAGEConfig and WINDOWAVERAGEModel."""

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest

from twiga.core.config import BaseSearchSpace
from twiga.models.baseline.window_average_model import WINDOWAVERAGEConfig, WINDOWAVERAGEModel

# ── Fixtures ──────────────────────────────────────────────────────────────────

BATCH, SEQ, FEATURES, HORIZONS = 16, 12, 5, 3


# ── Config ────────────────────────────────────────────────────────────────────


def test_window_average_config_defaults():
    cfg = WINDOWAVERAGEConfig()
    assert cfg.name == "window_average"
    assert cfg.domain == "baseline"
    assert cfg.window_size is None
    assert isinstance(cfg.search_space, BaseSearchSpace)
    # All search_space values should be positive integers
    assert all(v > 0 for v in cfg.search_space.window_size)

    d = cfg.model_dump()
    assert "domain" not in d
    assert "name" not in d
    assert "search_space" not in d
    assert d["window_size"] is None


def test_window_average_config_explicit_window():
    cfg = WINDOWAVERAGEConfig(window_size=24)
    assert cfg.window_size == 24


def test_window_average_config_alias():
    cfg = WINDOWAVERAGEConfig(model_name="window_average", window_size=48)
    assert cfg.name == "window_average"
    assert cfg.window_size == 48


def test_window_average_config_invalid_window_zero():
    with pytest.raises(ValidationError):
        WINDOWAVERAGEConfig(window_size=0)


def test_window_average_config_invalid_window_negative():
    with pytest.raises(ValidationError):
        WINDOWAVERAGEConfig(window_size=-5)


# ── Model instantiation ───────────────────────────────────────────────────────


def test_window_average_model_instantiation():
    model = WINDOWAVERAGEModel()
    assert isinstance(model.model_config, WINDOWAVERAGEConfig)
    assert model.num_targets is None
    assert model.horizon is None


def test_window_average_model_predict_unfitted():
    with pytest.raises(ValueError, match="not been fitted"):
        WINDOWAVERAGEModel().predict(np.random.randn(5, 12, 5))


def test_window_average_model_predict_wrong_ndim():
    model = WINDOWAVERAGEModel()
    model.num_targets = 2
    model.horizon = 3
    with pytest.raises(ValueError, match="3-dimensional"):
        model.predict(np.random.randn(5, 5))


# ── Fit ───────────────────────────────────────────────────────────────────────


def test_fit_stores_shape():
    model = WINDOWAVERAGEModel()
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    assert model.fit(x, y) is model
    assert model.horizon == SEQ
    assert model.num_targets == HORIZONS


def test_fit_window_exceeds_seq_len_raises():
    model = WINDOWAVERAGEModel(WINDOWAVERAGEConfig(window_size=20))
    x = np.random.randn(BATCH, SEQ, FEATURES)  # seq_len=12 < 20
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    with pytest.raises(ValueError, match="exceeds"):
        model.fit(x, y)


def test_fit_ignores_eval_set():
    model = WINDOWAVERAGEModel()
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model.fit(x, y, eval_set=(np.random.randn(4, SEQ, FEATURES), np.random.randn(4, SEQ, HORIZONS)))
    assert model.num_targets == HORIZONS


# ── Predict — correctness ─────────────────────────────────────────────────────


def test_predict_shape_full_window():
    model = WINDOWAVERAGEModel()
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model.fit(x, y)
    preds = model.predict(x)
    assert preds.shape == (BATCH, SEQ, HORIZONS)


def test_predict_shape_partial_window():
    model = WINDOWAVERAGEModel(WINDOWAVERAGEConfig(window_size=4))
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model.fit(x, y)
    preds = model.predict(x)
    assert preds.shape == (BATCH, SEQ, HORIZONS)


def test_predict_full_window_equals_column_mean():
    """All horizon steps should equal mean(X[:, :, :H], axis=1)."""
    model = WINDOWAVERAGEModel()  # window_size=None → full window
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model.fit(x, y)
    preds = model.predict(x)

    expected_mean = x[:, :, :HORIZONS].mean(axis=1)  # (B, H)
    for h in range(SEQ):
        np.testing.assert_allclose(preds[:, h, :], expected_mean, rtol=1e-6)


def test_predict_partial_window_exact():
    """With window_size=w, mean should be over last w steps only."""
    w = 3
    model = WINDOWAVERAGEModel(WINDOWAVERAGEConfig(window_size=w))
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model.fit(x, y)
    preds = model.predict(x)

    expected = x[:, -w:, :HORIZONS].mean(axis=1)  # (B, H)
    np.testing.assert_allclose(preds[:, 0, :], expected, rtol=1e-6)


def test_predict_all_horizon_steps_identical():
    """Every forecast step should carry the same value (local mean)."""
    model = WINDOWAVERAGEModel(WINDOWAVERAGEConfig(window_size=6))
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model.fit(x, y)
    preds = model.predict(x)
    for h in range(1, SEQ):
        np.testing.assert_array_equal(preds[:, h, :], preds[:, 0, :])


def test_predict_different_samples_different_means():
    """Different windows should (generally) produce different predictions."""
    model = WINDOWAVERAGEModel()
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model.fit(x, y)
    preds = model.predict(x)
    # Very unlikely that two random windows have exactly the same mean
    assert not np.allclose(preds[0], preds[1])


def test_forecast_returns_array():
    model = WINDOWAVERAGEModel()
    x = np.random.randn(BATCH, SEQ, FEATURES)
    y = np.random.randn(BATCH, SEQ, HORIZONS)
    model.fit(x, y)
    out = model.forecast(x)
    assert isinstance(out, np.ndarray)
    assert out.shape == (BATCH, SEQ, HORIZONS)


# ── Update (HPO) ──────────────────────────────────────────────────────────────


def test_update_changes_window_size():
    model = WINDOWAVERAGEModel(WINDOWAVERAGEConfig(window_size=24))
    mock_trial = MagicMock()
    with patch.object(WINDOWAVERAGEConfig, "get_optuna_params", return_value={"window_size": 48}):
        model.update(mock_trial)
    assert model.model_config.window_size == 48
