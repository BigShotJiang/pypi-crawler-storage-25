"""Unit tests for SEASONALNAIVEConfig, SEASONALNAIVEModel, and _resolve_period."""

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest

from twiga.core.config import BaseSearchSpace
from twiga.models.baseline.seasonal_naive_model import (
    SEASONALNAIVEConfig,
    SEASONALNAIVEModel,
    _resolve_period,
)

# ── _resolve_period ───────────────────────────────────────────────────────────


def test_resolve_period_integer_passthrough():
    assert _resolve_period(24, "1H") == 24
    assert _resolve_period(48, "30min") == 48


def test_resolve_period_string_hourly():
    assert _resolve_period("1D", "1H") == 24
    assert _resolve_period("7D", "1H") == 168
    assert _resolve_period("12H", "1H") == 12


def test_resolve_period_string_30min():
    assert _resolve_period("1D", "30min") == 48
    assert _resolve_period("7D", "30min") == 336
    assert _resolve_period("6H", "30min") == 12


def test_resolve_period_string_15min():
    assert _resolve_period("1H", "15min") == 4
    assert _resolve_period("1D", "15min") == 96


def test_resolve_period_integer_zero_raises():
    with pytest.raises(ValueError, match="positive integer"):
        _resolve_period(0, "1H")


def test_resolve_period_integer_negative_raises():
    with pytest.raises(ValueError, match="positive integer"):
        _resolve_period(-1, "1H")


def test_resolve_period_non_multiple_raises():
    # 25 minutes is not a whole multiple of 30 minutes
    with pytest.raises(ValueError, match="whole multiple"):
        _resolve_period("25min", "30min")


def test_resolve_period_invalid_string_raises():
    with pytest.raises(ValueError, match="Cannot resolve"):
        _resolve_period("not_a_freq", "1H")


# ── Config ────────────────────────────────────────────────────────────────────


def test_seasonal_naive_config_defaults():
    cfg = SEASONALNAIVEConfig()
    assert cfg.name == "seasonal_naive"
    assert cfg.domain == "baseline"
    assert cfg.period == "1D"
    assert cfg.freq == "1h"
    assert isinstance(cfg.search_space, BaseSearchSpace)
    assert "1D" in cfg.search_space.period
    assert "7D" in cfg.search_space.period

    d = cfg.model_dump()
    assert "domain" not in d
    assert "name" not in d
    assert "search_space" not in d
    assert d["period"] == "1D"
    assert d["freq"] == "1h"


def test_seasonal_naive_config_integer_period():
    cfg = SEASONALNAIVEConfig(period=48, freq="30min")
    assert cfg.period == 48


def test_seasonal_naive_config_alias():
    cfg = SEASONALNAIVEConfig(model_name="seasonal_naive", period="7D", freq="30min")
    assert cfg.name == "seasonal_naive"
    assert cfg.period == "7D"


def test_seasonal_naive_config_invalid_period_zero():
    with pytest.raises(ValidationError):
        SEASONALNAIVEConfig(period=0)


# ── Model instantiation ───────────────────────────────────────────────────────


def test_seasonal_naive_model_instantiation():
    model = SEASONALNAIVEModel()
    assert isinstance(model.model_config, SEASONALNAIVEConfig)
    assert model._period_steps is None
    assert model.num_targets is None
    assert model.horizon is None


def test_seasonal_naive_model_predict_unfitted():
    with pytest.raises(ValueError, match="not been fitted"):
        SEASONALNAIVEModel().predict(np.random.randn(5, 24, 6))


def test_seasonal_naive_model_predict_wrong_ndim():
    model = SEASONALNAIVEModel()
    model._period_steps = 4
    model.num_targets = 2
    model.horizon = 3
    with pytest.raises(ValueError, match="3-dimensional"):
        model.predict(np.random.randn(5, 4))


# ── Fit ───────────────────────────────────────────────────────────────────────


def test_fit_resolves_period_string():
    model = SEASONALNAIVEModel(SEASONALNAIVEConfig(period="1D", freq="1H"))
    x = np.random.randn(10, 48, 6)
    y = np.random.randn(10, 24, 2)
    model.fit(x, y)
    assert model._period_steps == 24
    assert model.horizon == 24
    assert model.num_targets == 2


def test_fit_resolves_period_integer():
    model = SEASONALNAIVEModel(SEASONALNAIVEConfig(period=48, freq="30min"))
    x = np.random.randn(10, 96, 6)
    y = np.random.randn(10, 48, 2)
    model.fit(x, y)
    assert model._period_steps == 48


def test_fit_period_exceeds_seq_len_raises():
    model = SEASONALNAIVEModel(SEASONALNAIVEConfig(period=168, freq="1H"))
    x = np.random.randn(10, 48, 6)  # seq_len=48 < 168
    y = np.random.randn(10, 24, 2)
    with pytest.raises(ValueError, match="exceeds"):
        model.fit(x, y)


def test_fit_ignores_eval_set():
    model = SEASONALNAIVEModel(SEASONALNAIVEConfig(period="1D", freq="1H"))
    x = np.random.randn(10, 48, 6)
    y = np.random.randn(10, 24, 2)
    model.fit(x, y, eval_set=(np.random.randn(5, 48, 6), np.random.randn(5, 24, 2)))
    assert model._period_steps == 24


# ── Predict — correctness ─────────────────────────────────────────────────────


def test_predict_shape():
    model = SEASONALNAIVEModel(SEASONALNAIVEConfig(period=4, freq="1H"))
    x = np.random.randn(20, 8, 6)
    y = np.random.randn(20, 4, 2)
    model.fit(x, y)
    preds = model.predict(x)
    assert preds.shape == (20, 4, 2)


def test_predict_daily_exact_values():
    """First forecast step h=0 should equal x[:, L-m, :H]."""
    m = 4
    batch, seq, feat, horiz = 3, 8, 6, 4
    model = SEASONALNAIVEModel(SEASONALNAIVEConfig(period=m))
    x = np.random.randn(batch, seq, feat)
    y = np.random.randn(batch, horiz, 2)
    model.fit(x, y)
    preds = model.predict(x)
    # h=0: source index = seq - m + 0 = 4
    np.testing.assert_array_equal(preds[:, 0, :], x[:, seq - m, :2])
    # h=m-1: source index = seq - 1
    np.testing.assert_array_equal(preds[:, m - 1, :], x[:, seq - 1, :2])


def test_predict_wrap_beyond_one_season():
    """For H > m the pattern wraps: step m equals step 0."""
    m = 3
    seq, horiz = 6, 6  # H=6 > m=3, so wraps twice
    model = SEASONALNAIVEModel(SEASONALNAIVEConfig(period=m))
    x = np.random.randn(5, seq, 4)
    y = np.random.randn(5, horiz, 2)
    model.fit(x, y)
    preds = model.predict(x)
    # Step m should equal step 0
    np.testing.assert_array_equal(preds[:, m, :], preds[:, 0, :])
    # Step m+1 should equal step 1
    np.testing.assert_array_equal(preds[:, m + 1, :], preds[:, 1, :])


def test_predict_weekly_30min():
    """Weekly seasonal naive at 30-min: period = 7*48 = 336 steps."""
    model = SEASONALNAIVEModel(SEASONALNAIVEConfig(period="7D", freq="30min"))
    x = np.random.randn(4, 340, 3)
    y = np.random.randn(4, 48, 2)
    model.fit(x, y)
    assert model._period_steps == 336
    preds = model.predict(x)
    assert preds.shape == (4, 48, 2)


# ── Update (HPO) ──────────────────────────────────────────────────────────────


def test_update_resets_period():
    model = SEASONALNAIVEModel(SEASONALNAIVEConfig(period="1D", freq="1H"))
    x = np.random.randn(5, 48, 4)
    y = np.random.randn(5, 24, 2)
    model.fit(x, y)

    mock_trial = MagicMock()
    with patch.object(SEASONALNAIVEConfig, "get_optuna_params", return_value={"period": "7D"}):
        model.update(mock_trial)

    assert model.model_config.period == "7D"
    assert model._period_steps is None  # reset; will re-resolve on next fit
