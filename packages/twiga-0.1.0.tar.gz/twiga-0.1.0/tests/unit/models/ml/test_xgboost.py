"""Unit tests for XGBOOSTConfig and XGBOOSTModel."""

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest
from xgboost import XGBRegressor

from twiga.core.config import BaseSearchSpace
from twiga.models.ml.xgboost_model import XGBOOSTConfig, XGBOOSTModel

# ── Config ────────────────────────────────────────────────────────────────────


def test_xgboost_config_defaults():
    config = XGBOOSTConfig()
    assert config.name == "xgboost"
    assert config.domain == "ml"
    assert config.random_state == 42
    assert config.verbose == 0
    assert config.device == "cpu"
    assert config.tree_method == "hist"
    assert config.objective == "reg:squarederror"
    assert config.early_stopping_rounds == 50

    assert isinstance(config.search_space, BaseSearchSpace)
    assert config.search_space.learning_rate == (1e-3, 0.3)
    assert config.search_space.n_estimators == (100, 2000)
    assert config.search_space.max_depth == (3, 10)
    assert config.search_space.subsample == (0.5, 1.0)
    assert config.search_space.gamma == (0.0, 5.0)
    assert config.search_space.colsample_bytree == (0.3, 1.0)
    assert config.search_space.min_child_weight == (1, 20)
    assert config.search_space.reg_alpha == (0.0, 10.0)
    assert config.search_space.reg_lambda == (0.1, 10.0)

    config_dict = config.model_dump()
    assert "search_space" not in config_dict
    assert "domain" not in config_dict
    # early_stopping_rounds IS excluded — injected at fit-time only when eval_set provided
    assert "early_stopping_rounds" not in config_dict


def test_xgboost_config_alias():
    config = XGBOOSTConfig(model_name="xgboost", random_state=7)
    assert config.name == "xgboost"
    assert config.random_state == 7


def test_invalid_random_state():
    with pytest.raises(ValidationError):
        XGBOOSTConfig(random_state=0)


def test_invalid_verbose():
    with pytest.raises(ValidationError):
        XGBOOSTConfig(verbose=3)


def test_invalid_device():
    with pytest.raises(ValidationError):
        XGBOOSTConfig(device="tpu")


def test_invalid_tree_method():
    with pytest.raises(ValidationError):
        XGBOOSTConfig(tree_method="gpu_hist")


def test_invalid_early_stopping_rounds():
    with pytest.raises(ValidationError):
        XGBOOSTConfig(early_stopping_rounds=0)


# ── Model ─────────────────────────────────────────────────────────────────────


def test_xgboost_model_instantiation():
    model = XGBOOSTModel()
    assert isinstance(model.model_config, XGBOOSTConfig)
    assert isinstance(model.model, XGBRegressor)
    assert model.model.get_params().get("random_state") == 42


def test_xgboost_model_fit_predict():
    model = XGBOOSTModel(model_config=XGBOOSTConfig(n_estimators=20))
    batch, seq, features, horizons = 30, 2, 4, 2
    x = np.random.randn(batch, seq, features)
    y = np.random.randn(batch, seq, horizons)

    result = model.fit(x, y)
    assert result is model
    preds = model.predict(x)
    assert preds.shape == (batch, seq, horizons)


def test_xgboost_model_fit_with_eval_set():
    model = XGBOOSTModel(model_config=XGBOOSTConfig(n_estimators=20, early_stopping_rounds=5))
    x = np.random.randn(30, 2, 4)
    y = np.random.randn(30, 2, 2)
    x_val = np.random.randn(10, 2, 4)
    y_val = np.random.randn(10, 2, 2)

    model.fit(x, y, eval_set=(x_val, y_val))
    assert model.predict(x).shape == (30, 2, 2)


def test_xgboost_model_update():
    model = XGBOOSTModel()
    mock_trial = MagicMock()
    params = model.model_config.model_dump()
    with patch.object(XGBOOSTConfig, "get_optuna_params", return_value=params):
        model.update(mock_trial)
    assert isinstance(model.model, XGBRegressor)
