from __future__ import annotations

import numpy as np
import pytest

from twiga.models.ml.core.base_regressor import BaseRegressor


class DummyModel:
    """A dummy regression model for testing purposes."""

    def __init__(self) -> None:
        self.fitted = False

    def fit(self, x: np.ndarray, y: np.ndarray) -> None:
        """Fit the dummy model by setting the fitted flag to True."""
        self.fitted = True

    def predict(self, x: np.ndarray) -> np.ndarray:
        """Predict by returning an array of ones with shape (N, 5).

        In BaseRegressor, this output will be reshaped to (N, -1, num_targets).

        Args:
            x (np.ndarray): Input features.

        Returns:
            np.ndarray: Predicted values as ones.
        """
        num_samples = x.shape[0]
        return np.ones((num_samples, 5))


@pytest.fixture
def dummy_data() -> tuple[np.ndarray, np.ndarray]:
    """Fixture to generate dummy data.

    Returns:
        tuple:
            x (np.ndarray): 3D array (10, 5, 3) of input features.
            y (np.ndarray): 2D array (10, 5) of target values.
    """
    x = np.random.rand(10, 5, 3)
    y = np.random.rand(10, 5)
    return x, y


@pytest.fixture
def regressor() -> BaseRegressor:
    """Fixture to create a BaseRegressor instance with a dummy model.

    Returns:
        BaseRegressor: Instance initialized with DummyModel.
    """
    reg = BaseRegressor()
    reg.model = DummyModel()
    return reg


def test_format_features() -> None:
    """Test if features are correctly reshaped by format_features."""
    reg = BaseRegressor()
    x = np.random.rand(10, 5, 3)
    x_formatted = reg.format_features(x)
    assert x_formatted.shape == (10, 15)


def test_fit_without_model(dummy_data: tuple[np.ndarray, np.ndarray]) -> None:
    """Test fitting without setting a model raises an error.

    Args:
        dummy_data (tuple): Tuple containing sample input data.
    """
    x, y = dummy_data
    reg = BaseRegressor()
    with pytest.raises(ValueError, match="No model has been set"):
        reg.fit(x, y)


def test_fit_with_model(dummy_data: tuple[np.ndarray, np.ndarray], regressor: BaseRegressor) -> None:
    """Test fitting BaseRegressor with a valid model.

    Args:
        dummy_data (tuple): Sample input data.
        regressor (BaseRegressor): Regressor instance with DummyModel.
    """
    x, y = dummy_data
    regressor.fit(x, y, verbose=True)
    assert regressor.num_targets == 1
    assert regressor.model.fitted


def test_predict_without_model(dummy_data: tuple[np.ndarray, np.ndarray]) -> None:
    """Test predicting without setting a model raises an error.

    Args:
        dummy_data (tuple): Tuple containing sample input data.
    """
    x, _ = dummy_data
    reg = BaseRegressor()
    with pytest.raises(ValueError, match="No model has been set"):
        reg.predict(x)


def test_predict_with_model(dummy_data: tuple[np.ndarray, np.ndarray], regressor: BaseRegressor) -> None:
    """Test prediction outputs shape after fitting a model.

    Args:
        dummy_data (tuple): Sample input data.
        regressor (BaseRegressor): Regressor instance with DummyModel.
    """
    x, y = dummy_data
    regressor.fit(x, y)
    predictions = regressor.predict(x)
    assert predictions.shape == (10, 5, 1)


def test_forecast(regressor: BaseRegressor, dummy_data: tuple[np.ndarray, np.ndarray]) -> None:
    """Test forecast method returns correct data type after fitting.

    Args:
        regressor (BaseRegressor): Regressor instance with DummyModel.
        dummy_data (tuple): Sample input data.
    """
    x, y = dummy_data
    regressor.fit(x, y)
    forecast_output = regressor.forecast(x)
    assert isinstance(forecast_output, np.ndarray)


def test_get_set_params(regressor: BaseRegressor) -> None:
    """Test set_params and get_params functionality.

    Args:
        regressor (BaseRegressor): Regressor instance with DummyModel.
    """
    regressor.set_params(model="dummy_model")
    params = regressor.get_params()
    assert params["model"] == "dummy_model"
