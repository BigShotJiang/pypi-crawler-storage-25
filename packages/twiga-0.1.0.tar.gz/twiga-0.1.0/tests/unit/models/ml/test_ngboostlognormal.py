"""Unit tests for NGBOOSTLOGNORMALConfig and NGBOOSTLOGNORMALModel."""

from unittest.mock import Mock

import numpy as np
import optuna
from pydantic import ValidationError
import pytest

from twiga.core.config import BaseSearchSpace
from twiga.models.ml.ngboostlognormal_model import NGBOOSTLOGNORMALConfig, NGBOOSTLOGNORMALModel

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def config():
    return NGBOOSTLOGNORMALConfig()


@pytest.fixture
def sample_inputs():
    """Strictly positive targets required for LogNormal distribution."""
    rng = np.random.default_rng(2)
    x_data = rng.standard_normal((60, 6, 5))
    y = np.abs(rng.standard_normal((60, 6, 1))) + 0.5  # strictly positive
    return x_data, y


@pytest.fixture
def fitted_model(sample_inputs):
    x_data, y = sample_inputs
    model = NGBOOSTLOGNORMALModel(NGBOOSTLOGNORMALConfig(n_estimators=5))
    model.fit(x_data, y)
    return model, x_data, y


# ---------------------------------------------------------------------------
# Config tests
# ---------------------------------------------------------------------------


def test_config_defaults(config):
    assert config.name == "ngboostlognormal"
    assert config.domain == "ml"
    assert config.n_estimators == 500
    assert config.learning_rate == pytest.approx(0.01)
    assert config.minibatch_frac == pytest.approx(1.0)
    assert config.col_sample == pytest.approx(1.0)
    assert config.random_state == 42
    assert config.score == "LogScore"
    assert isinstance(config.search_space, BaseSearchSpace)


def test_config_alias():
    cfg = NGBOOSTLOGNORMALConfig(model_name="ngboostlognormal", n_estimators=200)
    assert cfg.name == "ngboostlognormal"
    assert cfg.n_estimators == 200


def test_config_excludes_domain_search_space_score(config):
    d = config.model_dump()
    assert "domain" not in d
    assert "search_space" not in d
    assert "score" not in d


def test_config_invalid_random_state():
    with pytest.raises(ValidationError):
        NGBOOSTLOGNORMALConfig(random_state=0)


def test_config_crps_score():
    cfg = NGBOOSTLOGNORMALConfig(score="CRPScore")
    assert cfg.score == "CRPScore"


def test_config_invalid_score():
    with pytest.raises(ValidationError):
        NGBOOSTLOGNORMALConfig(score="InvalidScore")


# ---------------------------------------------------------------------------
# Model instantiation tests
# ---------------------------------------------------------------------------


def test_model_default_instantiation():
    model = NGBOOSTLOGNORMALModel()
    assert isinstance(model.model_config, NGBOOSTLOGNORMALConfig)
    assert model._models == []
    assert model.num_targets is None


def test_model_custom_config():
    cfg = NGBOOSTLOGNORMALConfig(n_estimators=50, score="CRPScore")
    model = NGBOOSTLOGNORMALModel(model_config=cfg)
    assert model.model_config.n_estimators == 50
    assert model.model_config.score == "CRPScore"


# ---------------------------------------------------------------------------
# Fit / predict tests
# ---------------------------------------------------------------------------


def test_fit_returns_self(sample_inputs):
    x_data, y = sample_inputs
    model = NGBOOSTLOGNORMALModel(NGBOOSTLOGNORMALConfig(n_estimators=5))
    assert model.fit(x_data, y) is model


def test_fit_sets_internal_state(sample_inputs):
    x_data, y = sample_inputs
    model = NGBOOSTLOGNORMALModel(NGBOOSTLOGNORMALConfig(n_estimators=5))
    model.fit(x_data, y)
    assert model.num_targets == 1
    assert model._horizon == 6
    assert len(model._models) == 6


def test_predict_output_shapes(fitted_model):
    model, x_data, _ = fitted_model
    loc, scale = model.predict(x_data)
    assert loc.shape == (60, 6, 1)
    assert scale.shape == (60, 6, 1)


def test_predict_loc_positive(fitted_model):
    """Loc = exp(mu_log) (geometric mean) must be strictly positive."""
    model, x_data, _ = fitted_model
    loc, _ = model.predict(x_data)
    assert np.all(loc > 0), "LogNormal loc (geometric mean) must be strictly positive"


def test_predict_scale_positive(fitted_model):
    """Scale = sigma_log must be strictly positive."""
    model, x_data, _ = fitted_model
    _, scale = model.predict(x_data)
    assert np.all(scale > 0), "LogNormal scale (sigma_log) must be strictly positive"


def test_fit_invalid_dims():
    model = NGBOOSTLOGNORMALModel(NGBOOSTLOGNORMALConfig(n_estimators=5))
    with pytest.raises(ValueError, match="3-dimensional"):
        model.fit(np.random.randn(40, 4), np.random.randn(40, 4, 1))


def test_predict_before_fit():
    model = NGBOOSTLOGNORMALModel()
    with pytest.raises(ValueError, match="not been fitted"):
        model.predict(np.random.randn(10, 5, 3))


# ---------------------------------------------------------------------------
# forecast() tests
# ---------------------------------------------------------------------------


def test_forecast_returns_dict(fitted_model):
    model, x_data, _ = fitted_model
    out = model.forecast(x_data)
    assert set(out.keys()) == {"loc", "scale"}
    assert out["loc"].shape == (60, 6, 1)
    assert out["scale"].shape == (60, 6, 1)
    assert np.all(out["loc"] > 0)


# ---------------------------------------------------------------------------
# update() tests
# ---------------------------------------------------------------------------


def test_update_resets_models(sample_inputs):
    x_data, y = sample_inputs
    model = NGBOOSTLOGNORMALModel(NGBOOSTLOGNORMALConfig(n_estimators=5))
    model.fit(x_data, y)
    assert len(model._models) > 0

    trial = Mock(spec=optuna.trial.Trial)
    trial.suggest_int.return_value = 150
    trial.suggest_float.return_value = 0.03

    model.update(trial)
    assert model._models == []
    assert model.num_targets is None
    assert model._horizon is None
