from pydantic import ValidationError
import pytest
from sklearn.linear_model import LinearRegression
from sklearn.multioutput import MultiOutputRegressor

from twiga.core.config import BaseSearchSpace
from twiga.models.ml.lineareg_model import LINEAREGConfig, LINEAREGModel


def test_lineareg_config_defaults():
    """Test default instantiation of LINEAREGConfig.

    Ensures that:
      - The 'name' field is set to 'lineareg'.
      - The 'domain' defaults to 'ml'.
      - The 'fit_intercept' defaults to True.
      - The search_space field is properly instantiated and excluded from the dict output.
    """
    config = LINEAREGConfig()
    assert config.name == "lineareg"
    assert config.domain == "ml"
    assert config.fit_intercept is True

    # Check that search_space exists and has the expected default values.
    assert isinstance(config.search_space, BaseSearchSpace)
    assert config.search_space.fit_intercept == [True, False]

    # Verify that search_space is excluded from the dict representation.
    config_dict = config.dict()
    assert "search_space" not in config_dict
    assert config_dict["fit_intercept"] is True


def test_lineareg_config_alias():
    """Test that using the alias 'model_name' correctly sets the 'name' field.

    When passing the alias 'model_name' to LINEAREGConfig, the internal 'name'
    field should be updated accordingly.
    """
    config = LINEAREGConfig(model_name="lineareg")
    assert config.name == "lineareg"


def test_lineareg_config_validation():
    """Test that LINEAREGConfig raises ValidationError for invalid 'name' values."""
    with pytest.raises(ValidationError):
        LINEAREGConfig(model_name="invalid_name")


def test_lineareg_model_instantiation():
    """Test that LINEAREGModel instantiation creates the expected model.

    Checks that:
      - The model_config attribute is an instance of LINEAREGConfig.
      - The model attribute is an instance of MultiOutputRegressor.
      - The underlying estimator is an instance of LinearRegression.
      - The underlying parameters (e.g., fit_intercept) are correctly passed to the model.
    """
    model_instance = LINEAREGModel()
    assert isinstance(model_instance.model_config, LINEAREGConfig)
    assert isinstance(model_instance.model, MultiOutputRegressor)
    assert isinstance(model_instance.model.estimator, LinearRegression)
    params = model_instance.model.estimator.get_params()
    assert params.get("fit_intercept") == model_instance.model_config.fit_intercept


def test_lineareg_model_update():
    """Test that LINEAREGModel update changes its parameters based on trial suggestions.

    The update method should re-instantiate the LinearRegression with new hyperparameters
    obtained from the configuration's search space.
    """

    class DummyTrial:
        """Dummy trial for testing update method."""

        def suggest_categorical(self, name, choices):
            return choices[0]

    def dummy_get_optuna_params(trial):
        return {
            "fit_intercept": trial.suggest_categorical("fit_intercept", [True, False]),
        }

    config = LINEAREGConfig()
    # Monkey-patch the get_optuna_params method for testing.
    config.get_optuna_params = dummy_get_optuna_params
    model_instance = LINEAREGModel(model_config=config)
    dummy_trial = DummyTrial()
    model_instance.update(dummy_trial)
    # Check that the updated model's parameters match the dummy trial choice.
    estimator = model_instance.model.estimator
    updated_params = estimator.get_params()
    assert updated_params.get("fit_intercept") is True
