"""Unit tests for LIGHTGBMConfig and LIGHTGBMModel."""

from unittest.mock import MagicMock, patch

from lightgbm import LGBMRegressor
import numpy as np
from pydantic import ValidationError
import pytest

from twiga.core.config import BaseSearchSpace
from twiga.models.ml.lightgbm_model import LIGHTGBMConfig, LIGHTGBMModel

# ── Config ────────────────────────────────────────────────────────────────────


def test_lightgbm_config_defaults():
    config = LIGHTGBMConfig()
    assert config.name == "lightgbm"
    assert config.domain == "ml"
    assert config.random_state == 42
    assert config.verbose == -1
    assert config.boosting_type == "gbdt"
    assert config.objective == "regression"
    assert config.metric == "rmse"
    assert config.bagging_freq == 1
    assert config.early_stopping_rounds == 50

    assert isinstance(config.search_space, BaseSearchSpace)
    assert config.search_space.learning_rate == (1e-3, 0.3)
    assert config.search_space.num_leaves == (16, 256)
    assert config.search_space.n_estimators == (100, 2000)
    assert config.search_space.subsample == (0.5, 1.0)
    assert config.search_space.colsample_bytree == (0.3, 1.0)
    assert config.search_space.min_data_in_leaf == (5, 100)
    assert config.search_space.reg_alpha == (0.0, 10.0)
    assert config.search_space.reg_lambda == (0.0, 10.0)
    assert config.search_space.linear_tree == [True, False]

    config_dict = config.model_dump()
    assert "search_space" not in config_dict
    assert "domain" not in config_dict
    # early_stopping_rounds IS excluded — handled via callbacks
    assert "early_stopping_rounds" not in config_dict


def test_lightgbm_config_alias():
    config = LIGHTGBMConfig(model_name="lightgbm", random_state=7)
    assert config.name == "lightgbm"
    assert config.random_state == 7


def test_invalid_random_state():
    with pytest.raises(ValidationError):
        LIGHTGBMConfig(random_state=0)


def test_invalid_verbose():
    with pytest.raises(ValidationError):
        LIGHTGBMConfig(verbose=2)


def test_invalid_early_stopping_rounds():
    with pytest.raises(ValidationError):
        LIGHTGBMConfig(early_stopping_rounds=0)


# ── Model ─────────────────────────────────────────────────────────────────────


def test_lightgbm_model_instantiation():
    model = LIGHTGBMModel()
    assert isinstance(model.model_config, LIGHTGBMConfig)
    assert isinstance(model.models, list)
    assert len(model.models) == 0
    assert model.num_targets is None


def test_lightgbm_model_fit_predict():
    model = LIGHTGBMModel(model_config=LIGHTGBMConfig(n_estimators=20))
    batch, seq, features, horizons = 30, 2, 4, 2
    x = np.random.randn(batch, seq, features)
    y = np.random.randn(batch, seq, horizons)

    result = model.fit(x, y)
    assert result is model
    assert len(model.models) == seq * horizons
    assert all(isinstance(m, LGBMRegressor) for m in model.models)
    assert model.num_targets == horizons

    preds = model.predict(x)
    assert preds.shape == (batch, seq, horizons)


def test_lightgbm_model_fit_with_eval_set():
    model = LIGHTGBMModel(model_config=LIGHTGBMConfig(n_estimators=20, early_stopping_rounds=5))
    x = np.random.randn(30, 2, 4)
    y = np.random.randn(30, 2, 2)
    x_val = np.random.randn(10, 2, 4)
    y_val = np.random.randn(10, 2, 2)

    model.fit(x, y, eval_set=(x_val, y_val))
    assert model.predict(x).shape == (30, 2, 2)


def test_lightgbm_model_predict_unfitted():
    model = LIGHTGBMModel()
    with pytest.raises(ValueError, match="not been fitted"):
        model.predict(np.random.randn(5, 3, 4))


def test_lightgbm_model_update():
    model = LIGHTGBMModel()
    mock_trial = MagicMock()
    params = model.model_config.model_dump()
    with patch.object(LIGHTGBMConfig, "get_optuna_params", return_value=params):
        model.update(mock_trial)
    assert model.models == []
    assert model.num_targets is None
