"""Unit tests for RANDOMFORESTConfig and RANDOMFORESTModel."""

from unittest.mock import MagicMock, patch

import numpy as np
from pydantic import ValidationError
import pytest
from sklearn.ensemble import RandomForestRegressor

from twiga.core.config import BaseSearchSpace
from twiga.models.ml.randomforest_model import RANDOMFORESTConfig, RANDOMFORESTModel

# ── Config ────────────────────────────────────────────────────────────────────


def test_randomforest_config_defaults():
    config = RANDOMFORESTConfig()
    assert config.name == "randomforest"
    assert config.domain == "ml"
    assert config.random_state == 42
    assert config.n_jobs == -1

    assert isinstance(config.search_space, BaseSearchSpace)
    assert config.search_space.n_estimators == (100, 1000)
    assert config.search_space.max_depth == (3, 20)
    assert config.search_space.min_samples_split == (2, 20)
    assert config.search_space.min_samples_leaf == (1, 20)
    assert config.search_space.max_features == ["sqrt", "log2"]

    config_dict = config.model_dump()
    assert "search_space" not in config_dict
    assert "domain" not in config_dict
    assert "name" not in config_dict


def test_randomforest_config_alias():
    config = RANDOMFORESTConfig(model_name="randomforest", random_state=7)
    assert config.name == "randomforest"
    assert config.random_state == 7


def test_invalid_random_state():
    with pytest.raises(ValidationError):
        RANDOMFORESTConfig(random_state=0)


# ── Model ─────────────────────────────────────────────────────────────────────


def test_randomforest_model_instantiation():
    model = RANDOMFORESTModel()
    assert isinstance(model.model_config, RANDOMFORESTConfig)
    assert isinstance(model.model, RandomForestRegressor)


def test_randomforest_model_fit_predict():
    model = RANDOMFORESTModel(model_config=RANDOMFORESTConfig(n_estimators=10))
    batch, seq, features, horizons = 30, 2, 4, 2
    x = np.random.randn(batch, seq, features)
    y = np.random.randn(batch, seq, horizons)

    result = model.fit(x, y)
    assert result is model
    assert model.num_targets == horizons

    preds = model.predict(x)
    assert preds.shape == (batch, seq, horizons)


def test_randomforest_model_fit_ignores_eval_set():
    """eval_set is accepted but silently ignored (RF has no early stopping)."""
    model = RANDOMFORESTModel(model_config=RANDOMFORESTConfig(n_estimators=10))
    x = np.random.randn(30, 2, 4)
    y = np.random.randn(30, 2, 2)
    x_val = np.random.randn(10, 2, 4)
    y_val = np.random.randn(10, 2, 2)

    model.fit(x, y, eval_set=(x_val, y_val))
    assert model.predict(x).shape == (30, 2, 2)


def test_randomforest_model_update():
    model = RANDOMFORESTModel()
    mock_trial = MagicMock()
    params = model.model_config.model_dump()
    with patch.object(RANDOMFORESTConfig, "get_optuna_params", return_value=params):
        model.update(mock_trial)
    assert isinstance(model.model, RandomForestRegressor)
