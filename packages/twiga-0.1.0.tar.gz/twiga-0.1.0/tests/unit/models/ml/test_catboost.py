"""Unit tests for CATBOOSTConfig and CATBOOSTModel."""

from unittest.mock import MagicMock, patch

from catboost import CatBoostRegressor
from pydantic import ValidationError
import pytest
from sklearn.multioutput import MultiOutputRegressor

from twiga.core.config import BaseSearchSpace
from twiga.models.ml.catboost_model import CATBOOSTConfig, CATBOOSTModel

# ── Config ────────────────────────────────────────────────────────────────────


def test_catboost_config_defaults():
    config = CATBOOSTConfig()
    assert config.name == "catboost"
    assert config.task_type == "CPU"
    assert config.random_state == 42
    assert config.verbose == 0
    assert config.allow_writing_files is False
    assert config.l2_leaf_reg == 3.0
    assert config.bagging_temperature == 1.0

    # search_space bounds
    assert isinstance(config.search_space, BaseSearchSpace)
    assert config.search_space.learning_rate == (1e-3, 0.3)
    assert config.search_space.depth == (4, 8)
    assert config.search_space.iterations == (100, 2000)
    assert config.search_space.min_data_in_leaf == (1, 100)
    assert config.search_space.l2_leaf_reg == (1.0, 10.0)
    assert config.search_space.bagging_temperature == (0.0, 1.0)

    # excluded fields absent from serialisation
    config_dict = config.dict()
    assert "search_space" not in config_dict
    assert "domain" not in config_dict


def test_catboost_config_alias():
    config = CATBOOSTConfig(model_name="catboost", random_state=1)
    assert config.name == "catboost"
    assert config.random_state == 1


def test_invalid_random_state():
    with pytest.raises(ValidationError):
        CATBOOSTConfig(random_state=0)


def test_invalid_verbose():
    with pytest.raises(ValidationError):
        CATBOOSTConfig(verbose=3)


def test_invalid_task_type():
    with pytest.raises(ValidationError):
        CATBOOSTConfig(task_type="INVALID")


def test_l2_leaf_reg_negative_raises():
    with pytest.raises(ValidationError):
        CATBOOSTConfig(l2_leaf_reg=-1.0)


def test_bagging_temperature_negative_raises():
    with pytest.raises(ValidationError):
        CATBOOSTConfig(bagging_temperature=-0.1)


# ── Model ─────────────────────────────────────────────────────────────────────


def test_catboost_model_instantiation():
    model = CATBOOSTModel()
    assert isinstance(model.model_config, CATBOOSTConfig)
    assert isinstance(model.model, MultiOutputRegressor)
    assert isinstance(model.model.estimator, CatBoostRegressor)


def test_catboost_model_update():
    model = CATBOOSTModel()
    mock_trial = MagicMock()
    params = model.model_config.dict()
    with patch.object(CATBOOSTConfig, "get_optuna_params", return_value=params):
        model.update(mock_trial)
    assert isinstance(model.model, MultiOutputRegressor)
    assert isinstance(model.model.estimator, CatBoostRegressor)
