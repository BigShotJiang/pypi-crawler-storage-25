"""Unit tests for GAUSSCATBOOSTConfig and GAUSSCATBOOSTModel."""

from unittest.mock import MagicMock, patch

from catboost import CatBoostRegressor
import numpy as np
from pydantic import ValidationError
import pytest

from twiga.core.config import BaseSearchSpace
from twiga.models.ml.gausscatboost_model import GAUSSCATBOOSTConfig, GAUSSCATBOOSTModel

# ── Config ────────────────────────────────────────────────────────────────────


def test_gausscatboost_config_defaults():
    config = GAUSSCATBOOSTConfig()
    assert config.name == "gausscatboost"
    assert config.task_type == "CPU"
    assert config.random_state == 42
    assert config.verbose == 0
    assert config.allow_writing_files is False
    assert config.od_type == "Iter"
    assert config.od_wait == 20
    assert config.virtual_ensembles_count == 10

    assert isinstance(config.search_space, BaseSearchSpace)
    assert config.search_space.learning_rate == (1e-3, 0.3)
    assert config.search_space.depth == (4, 8)
    assert config.search_space.iterations == (100, 2000)
    assert config.search_space.min_data_in_leaf == (1, 50)
    assert config.search_space.l2_leaf_reg == (1.0, 10.0)
    assert config.search_space.bagging_temperature == (0.0, 1.0)

    config_dict = config.dict()
    assert "search_space" not in config_dict
    assert "domain" not in config_dict
    assert "virtual_ensembles_count" not in config_dict


def test_gausscatboost_config_alias():
    config = GAUSSCATBOOSTConfig(model_name="gausscatboost", random_state=7)
    assert config.name == "gausscatboost"
    assert config.random_state == 7


def test_gausscatboost_config_invalid_random_state():
    with pytest.raises(ValidationError):
        GAUSSCATBOOSTConfig(random_state=0)


def test_gausscatboost_config_invalid_verbose():
    with pytest.raises(ValidationError):
        GAUSSCATBOOSTConfig(verbose=3)


def test_gausscatboost_config_invalid_task_type():
    with pytest.raises(ValidationError):
        GAUSSCATBOOSTConfig(task_type="INVALID")


def test_gausscatboost_config_invalid_od_type():
    with pytest.raises(ValidationError):
        GAUSSCATBOOSTConfig(od_type="WrongType")


def test_gausscatboost_config_od_wait_negative():
    with pytest.raises(ValidationError):
        GAUSSCATBOOSTConfig(od_wait=0)


def test_gausscatboost_config_virtual_ensembles_count_negative():
    with pytest.raises(ValidationError):
        GAUSSCATBOOSTConfig(virtual_ensembles_count=0)


# ── Model instantiation ───────────────────────────────────────────────────────


def test_gausscatboost_model_instantiation():
    model = GAUSSCATBOOSTModel()
    assert isinstance(model.model_config, GAUSSCATBOOSTConfig)
    assert isinstance(model.models, list)
    assert len(model.models) == 0
    assert model.num_targets is None
    assert model._base_params["loss_function"] == "RMSEWithUncertainty"


def test_gausscatboost_model_custom_config():
    config = GAUSSCATBOOSTConfig(od_wait=50, virtual_ensembles_count=5)
    model = GAUSSCATBOOSTModel(model_config=config)
    assert model.model_config.od_wait == 50
    assert model.virtual_ensembles_count == 5


# ── Fit / Predict ─────────────────────────────────────────────────────────────


def test_gausscatboost_model_fit_invalid_input():
    model = GAUSSCATBOOSTModel()

    with pytest.raises(ValueError, match="3-dimensional"):
        model.fit(np.random.randn(10, 5), np.random.randn(10, 4, 1))

    with pytest.raises(ValueError, match="3-dimensional"):
        model.fit(np.random.randn(10, 4, 5), np.random.randn(10, 3))


def test_gausscatboost_model_predict_unfitted():
    model = GAUSSCATBOOSTModel()
    with pytest.raises(ValueError, match="not been fitted"):
        model.predict(np.random.randn(5, 4, 3))


def test_gausscatboost_model_fit_predict():
    config = GAUSSCATBOOSTConfig(iterations=50)
    model = GAUSSCATBOOSTModel(model_config=config)

    batch, seq, features, horizons = 30, 2, 4, 2
    x = np.random.randn(batch, seq, features)
    y = np.random.randn(batch, seq, horizons)

    model.fit(x, y)
    assert len(model.models) == seq * horizons
    assert all(isinstance(m, CatBoostRegressor) for m in model.models)
    assert model.num_targets == horizons

    mu, sigma = model.predict(x)
    assert mu.shape == (batch, seq, horizons)
    assert sigma.shape == (batch, seq, horizons)
    assert np.all(sigma > 0), "sigma must be positive (exp of log-sigma)"


# ── HPO update ────────────────────────────────────────────────────────────────


def test_gausscatboost_model_update():
    model = GAUSSCATBOOSTModel()
    mock_trial = MagicMock()
    params = model.model_config.dict()
    with patch.object(GAUSSCATBOOSTConfig, "get_optuna_params", return_value=params):
        model.update(mock_trial)

    assert model._base_params["loss_function"] == "RMSEWithUncertainty"
    assert isinstance(model.models, list)
    assert len(model.models) == 0
    assert model.num_targets is None
