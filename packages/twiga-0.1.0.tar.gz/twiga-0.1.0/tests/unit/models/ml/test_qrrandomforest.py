"""Unit tests for QRRANDOMFORESTConfig and QRRANDOMFORESTModel."""

from unittest.mock import MagicMock, patch

import numpy as np
import pytest
from quantile_forest import RandomForestQuantileRegressor

from twiga.models.ml.qrrandomforest_model import QRRANDOMFORESTConfig, QRRANDOMFORESTModel
from twiga.models.ml.randomforest_model import RANDOMFORESTConfig

# ── Config ────────────────────────────────────────────────────────────────────


def test_qrrandomforest_config_defaults():
    config = QRRANDOMFORESTConfig()
    assert config.name == "qrrandomforest"
    assert config.domain == "ml"
    assert config.random_state == 42
    assert config.n_jobs == -1
    assert config.quantiles == sorted([0.05, 0.25, 0.5, 0.75, 0.95])
    assert config.conf_level == 0.1

    config_dict = config.model_dump()
    assert "quantiles" not in config_dict
    assert "conf_level" not in config_dict
    assert "domain" not in config_dict


def test_qrrandomforest_config_inherits_randomforest():
    assert issubclass(QRRANDOMFORESTConfig, RANDOMFORESTConfig)


def test_qrrandomforest_config_alias():
    config = QRRANDOMFORESTConfig(model_name="qrrandomforest", random_state=7)
    assert config.name == "qrrandomforest"
    assert config.random_state == 7


# ── Model ─────────────────────────────────────────────────────────────────────


def test_qrrandomforest_model_instantiation():
    model = QRRANDOMFORESTModel()
    assert isinstance(model.model_config, QRRANDOMFORESTConfig)
    assert isinstance(model.model, RandomForestQuantileRegressor)
    assert model.num_targets is None
    assert model.horizon is None
    assert 0.5 in model.quantiles
    assert model.conf_level == 0.1


def test_qrrandomforest_quantile_list_includes_conf_bounds():
    config = QRRANDOMFORESTConfig(conf_level=0.1)
    model = QRRANDOMFORESTModel(model_config=config)
    assert 0.05 in model.quantiles  # conf_level / 2
    assert 0.95 in model.quantiles  # 1 - conf_level / 2


def test_qrrandomforest_model_fit_predict():
    config = QRRANDOMFORESTConfig(n_estimators=10)
    model = QRRANDOMFORESTModel(model_config=config)
    batch, seq, features, horizons = 30, 2, 4, 2
    x = np.random.randn(batch, seq, features)
    y = np.random.randn(batch, seq, horizons)

    result = model.fit(x, y)
    assert result is model
    assert model.horizon == seq
    assert model.num_targets == horizons

    median, quantiles = model.predict(x)
    assert median.shape == (batch, seq, horizons)
    assert quantiles.shape == (batch, len(model.quantiles), seq, horizons)


def test_qrrandomforest_model_fit_ignores_eval_set():
    """eval_set is accepted but silently ignored (QRF has no early stopping)."""
    config = QRRANDOMFORESTConfig(n_estimators=10)
    model = QRRANDOMFORESTModel(model_config=config)
    x = np.random.randn(30, 2, 4)
    y = np.random.randn(30, 2, 2)
    x_val = np.random.randn(10, 2, 4)
    y_val = np.random.randn(10, 2, 2)

    model.fit(x, y, eval_set=(x_val, y_val))
    median, _ = model.predict(x)
    assert median.shape == (30, 2, 2)


def test_qrrandomforest_forecast_returns_dict():
    config = QRRANDOMFORESTConfig(n_estimators=10)
    model = QRRANDOMFORESTModel(model_config=config)
    x = np.random.randn(20, 2, 4)
    y = np.random.randn(20, 2, 2)
    model.fit(x, y)

    result = model.forecast(x)
    assert "loc" in result
    assert "quantiles" in result
    assert "conf_level" in result
    assert "quantile_levels" in result
    assert result["conf_level"] == 0.1
    assert result["quantile_levels"] == model.quantiles


def test_qrrandomforest_forecast_sigma_mode():
    config = QRRANDOMFORESTConfig(n_estimators=10)
    model = QRRANDOMFORESTModel(model_config=config)
    x = np.random.randn(20, 2, 4)
    y = np.random.randn(20, 2, 2)
    model.fit(x, y)

    result = model.forecast(x, sigma=True)
    assert "loc" in result
    assert "scale" in result
    assert "quantiles" not in result


def test_qrrandomforest_model_update():
    model = QRRANDOMFORESTModel()
    mock_trial = MagicMock()
    params = model.model_config.model_dump()
    with patch.object(QRRANDOMFORESTConfig, "get_optuna_params", return_value=params):
        model.update(mock_trial)
    assert isinstance(model.model, RandomForestQuantileRegressor)
