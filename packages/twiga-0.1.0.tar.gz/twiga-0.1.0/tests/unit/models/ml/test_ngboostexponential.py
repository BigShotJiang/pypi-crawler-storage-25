"""Unit tests for NGBOOSTEXPONENTIALConfig and NGBOOSTEXPONENTIALModel."""

from unittest.mock import Mock

import numpy as np
import optuna
from pydantic import ValidationError
import pytest

from twiga.core.config import BaseSearchSpace
from twiga.models.ml.ngboostexponential_model import NGBOOSTEXPONENTIALConfig, NGBOOSTEXPONENTIALModel

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def config():
    return NGBOOSTEXPONENTIALConfig()


@pytest.fixture
def sample_inputs():
    """Non-negative exponentially distributed targets."""
    rng = np.random.default_rng(3)
    x_data = rng.standard_normal((60, 6, 5))
    y = rng.exponential(scale=2.0, size=(60, 6, 1))
    return x_data, y


@pytest.fixture
def fitted_model(sample_inputs):
    x_data, y = sample_inputs
    model = NGBOOSTEXPONENTIALModel(NGBOOSTEXPONENTIALConfig(n_estimators=5))
    model.fit(x_data, y)
    return model, x_data, y


# ---------------------------------------------------------------------------
# Config tests
# ---------------------------------------------------------------------------


def test_config_defaults(config):
    assert config.name == "ngboostexponential"
    assert config.domain == "ml"
    assert config.n_estimators == 500
    assert config.learning_rate == pytest.approx(0.01)
    assert config.minibatch_frac == pytest.approx(1.0)
    assert config.col_sample == pytest.approx(1.0)
    assert config.random_state == 42
    assert config.score == "LogScore"
    assert isinstance(config.search_space, BaseSearchSpace)


def test_config_alias():
    cfg = NGBOOSTEXPONENTIALConfig(model_name="ngboostexponential", n_estimators=300)
    assert cfg.name == "ngboostexponential"
    assert cfg.n_estimators == 300


def test_config_excludes_domain_search_space_score(config):
    d = config.model_dump()
    assert "domain" not in d
    assert "search_space" not in d
    assert "score" not in d


def test_config_invalid_random_state():
    with pytest.raises(ValidationError):
        NGBOOSTEXPONENTIALConfig(random_state=-1)


def test_config_crps_score():
    cfg = NGBOOSTEXPONENTIALConfig(score="CRPScore")
    assert cfg.score == "CRPScore"


def test_config_invalid_score():
    with pytest.raises(ValidationError):
        NGBOOSTEXPONENTIALConfig(score="NegLogScore")


def test_config_get_optuna_params(config):
    trial = Mock(spec=optuna.trial.Trial)
    trial.suggest_int.return_value = 400
    trial.suggest_float.return_value = 0.02
    params = config.get_optuna_params(trial)
    assert "n_estimators" in params
    assert "learning_rate" in params
    assert "minibatch_frac" in params
    assert "col_sample" in params


# ---------------------------------------------------------------------------
# Model instantiation tests
# ---------------------------------------------------------------------------


def test_model_default_instantiation():
    model = NGBOOSTEXPONENTIALModel()
    assert isinstance(model.model_config, NGBOOSTEXPONENTIALConfig)
    assert model._models == []
    assert model.num_targets is None
    assert model._horizon is None


def test_model_custom_config():
    cfg = NGBOOSTEXPONENTIALConfig(n_estimators=50, learning_rate=0.05)
    model = NGBOOSTEXPONENTIALModel(model_config=cfg)
    assert model.model_config.n_estimators == 50
    assert model.model_config.learning_rate == pytest.approx(0.05)


# ---------------------------------------------------------------------------
# Fit / predict tests
# ---------------------------------------------------------------------------


def test_fit_returns_self(sample_inputs):
    x_data, y = sample_inputs
    model = NGBOOSTEXPONENTIALModel(NGBOOSTEXPONENTIALConfig(n_estimators=5))
    assert model.fit(x_data, y) is model


def test_fit_sets_internal_state(sample_inputs):
    x_data, y = sample_inputs
    model = NGBOOSTEXPONENTIALModel(NGBOOSTEXPONENTIALConfig(n_estimators=5))
    model.fit(x_data, y)
    assert model.num_targets == 1
    assert model._horizon == 6
    assert model._n_out == 6
    assert len(model._models) == 6


def test_predict_output_shapes(fitted_model):
    model, x_data, _ = fitted_model
    loc, scale = model.predict(x_data)
    assert loc.shape == (60, 6, 1)
    assert scale.shape == (60, 6, 1)


def test_predict_loc_equals_scale(fitted_model):
    """For Exponential, loc and scale both map to the same 'scale' param."""
    model, x_data, _ = fitted_model
    loc, scale = model.predict(x_data)
    np.testing.assert_array_equal(loc, scale)


def test_predict_scale_positive(fitted_model):
    """Exponential scale = 1/λ must be strictly positive."""
    model, x_data, _ = fitted_model
    _, scale = model.predict(x_data)
    assert np.all(scale > 0), "Exponential scale must be strictly positive"


def test_fit_multi_target():
    rng = np.random.default_rng(4)
    x_data = rng.standard_normal((40, 3, 4))
    y = rng.exponential(1.5, size=(40, 3, 2))
    model = NGBOOSTEXPONENTIALModel(NGBOOSTEXPONENTIALConfig(n_estimators=5))
    model.fit(x_data, y)
    loc, scale = model.predict(x_data)
    assert loc.shape == (40, 3, 2)
    assert scale.shape == (40, 3, 2)
    assert len(model._models) == 6  # 3 horizon * 2 targets


def test_fit_invalid_dims():
    model = NGBOOSTEXPONENTIALModel(NGBOOSTEXPONENTIALConfig(n_estimators=5))
    with pytest.raises(ValueError, match="3-dimensional"):
        model.fit(np.random.randn(40, 4), np.random.randn(40, 4, 1))
    with pytest.raises(ValueError, match="3-dimensional"):
        model.fit(np.random.randn(40, 4, 3), np.random.randn(40, 4))


def test_predict_before_fit():
    model = NGBOOSTEXPONENTIALModel()
    with pytest.raises(ValueError, match="not been fitted"):
        model.predict(np.random.randn(10, 5, 3))


# ---------------------------------------------------------------------------
# forecast() tests
# ---------------------------------------------------------------------------


def test_forecast_returns_dict(fitted_model):
    model, x_data, _ = fitted_model
    out = model.forecast(x_data)
    assert set(out.keys()) == {"loc", "scale"}
    assert out["loc"].shape == (60, 6, 1)
    assert out["scale"].shape == (60, 6, 1)
    assert np.all(out["scale"] > 0)


def test_forecast_loc_equals_scale(fitted_model):
    """Exponential: forecast loc and scale must be identical arrays."""
    model, x_data, _ = fitted_model
    out = model.forecast(x_data)
    np.testing.assert_array_equal(out["loc"], out["scale"])


# ---------------------------------------------------------------------------
# update() tests
# ---------------------------------------------------------------------------


def test_update_resets_state(sample_inputs):
    x_data, y = sample_inputs
    model = NGBOOSTEXPONENTIALModel(NGBOOSTEXPONENTIALConfig(n_estimators=5))
    model.fit(x_data, y)
    assert len(model._models) > 0

    trial = Mock(spec=optuna.trial.Trial)
    trial.suggest_int.return_value = 200
    trial.suggest_float.return_value = 0.04

    model.update(trial)
    assert model._models == []
    assert model.num_targets is None
    assert model._horizon is None
    assert model._n_out is None
