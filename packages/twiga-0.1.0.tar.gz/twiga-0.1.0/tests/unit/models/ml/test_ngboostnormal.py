"""Unit tests for NGBOOSTNORMALConfig and NGBOOSTNORMALModel."""

from unittest.mock import Mock

import numpy as np
import optuna
from pydantic import ValidationError
import pytest

from twiga.core.config import BaseSearchSpace
from twiga.models.ml.ngboostnormal_model import NGBOOSTNORMALConfig, NGBOOSTNORMALModel

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def config():
    return NGBOOSTNORMALConfig()


@pytest.fixture
def sample_inputs():
    rng = np.random.default_rng(0)
    x_data = rng.standard_normal((60, 6, 5))
    y = np.sum(x_data, axis=2, keepdims=True) * 0.3 + rng.standard_normal((60, 6, 1)) * 0.1 + 1.0
    return x_data, y


@pytest.fixture
def fitted_model(sample_inputs):
    x_data, y = sample_inputs
    model = NGBOOSTNORMALModel(NGBOOSTNORMALConfig(n_estimators=5))
    model.fit(x_data, y)
    return model, x_data, y


# ---------------------------------------------------------------------------
# Config tests
# ---------------------------------------------------------------------------


def test_config_defaults(config):
    assert config.name == "ngboostnormal"
    assert config.domain == "ml"
    assert config.n_estimators == 500
    assert config.learning_rate == pytest.approx(0.01)
    assert config.minibatch_frac == pytest.approx(1.0)
    assert config.col_sample == pytest.approx(1.0)
    assert config.random_state == 42
    assert config.score == "LogScore"
    assert isinstance(config.search_space, BaseSearchSpace)


def test_config_alias():
    cfg = NGBOOSTNORMALConfig(model_name="ngboostnormal", random_state=7)
    assert cfg.name == "ngboostnormal"
    assert cfg.random_state == 7


def test_config_excludes_domain_search_space_score(config):
    d = config.model_dump()
    assert "domain" not in d
    assert "search_space" not in d
    assert "score" not in d


def test_config_invalid_random_state():
    with pytest.raises(ValidationError):
        NGBOOSTNORMALConfig(random_state=0)


def test_config_invalid_minibatch_frac():
    with pytest.raises(ValidationError):
        NGBOOSTNORMALConfig(minibatch_frac=1.5)


def test_config_invalid_col_sample():
    with pytest.raises(ValidationError):
        NGBOOSTNORMALConfig(col_sample=0.0)


def test_config_invalid_score():
    with pytest.raises(ValidationError):
        NGBOOSTNORMALConfig(score="MSEScore")


def test_config_crps_score():
    cfg = NGBOOSTNORMALConfig(score="CRPScore")
    assert cfg.score == "CRPScore"


def test_config_get_optuna_params(config):
    trial = Mock(spec=optuna.trial.Trial)
    trial.suggest_int.return_value = 300
    trial.suggest_float.return_value = 0.05
    params = config.get_optuna_params(trial)
    assert "n_estimators" in params
    assert "learning_rate" in params
    assert "minibatch_frac" in params
    assert "col_sample" in params


# ---------------------------------------------------------------------------
# Model instantiation tests
# ---------------------------------------------------------------------------


def test_model_default_instantiation():
    model = NGBOOSTNORMALModel()
    assert isinstance(model.model_config, NGBOOSTNORMALConfig)
    assert model._models == []
    assert model.num_targets is None
    assert model._horizon is None
    assert model._n_out is None


def test_model_custom_config():
    cfg = NGBOOSTNORMALConfig(n_estimators=100, random_state=7)
    model = NGBOOSTNORMALModel(model_config=cfg)
    assert model.model_config.n_estimators == 100
    assert model.model_config.random_state == 7


# ---------------------------------------------------------------------------
# Fit / predict tests
# ---------------------------------------------------------------------------


def test_fit_returns_self(sample_inputs):
    x_data, y = sample_inputs
    model = NGBOOSTNORMALModel(NGBOOSTNORMALConfig(n_estimators=5))
    result = model.fit(x_data, y)
    assert result is model


def test_fit_sets_internal_state(sample_inputs):
    x_data, y = sample_inputs
    model = NGBOOSTNORMALModel(NGBOOSTNORMALConfig(n_estimators=5))
    model.fit(x_data, y)
    assert model.num_targets == 1
    assert model._horizon == 6
    assert model._n_out == 6  # horizon * n_targets = 6 * 1
    assert len(model._models) == 6


def test_predict_output_shapes(fitted_model):
    model, x_data, _ = fitted_model
    loc, scale = model.predict(x_data)
    assert loc.shape == (60, 6, 1)
    assert scale.shape == (60, 6, 1)


def test_predict_scale_positive(fitted_model):
    model, x_data, _ = fitted_model
    _, scale = model.predict(x_data)
    assert np.all(scale > 0), "Normal scale (σ) must be strictly positive"


def test_fit_multi_target():
    rng = np.random.default_rng(1)
    x_data = rng.standard_normal((50, 4, 4))
    y = rng.standard_normal((50, 4, 2))
    model = NGBOOSTNORMALModel(NGBOOSTNORMALConfig(n_estimators=5))
    model.fit(x_data, y)
    loc, scale = model.predict(x_data)
    assert loc.shape == (50, 4, 2)
    assert scale.shape == (50, 4, 2)
    assert len(model._models) == 8  # 4 horizon * 2 targets


def test_fit_invalid_dims():
    model = NGBOOSTNORMALModel(NGBOOSTNORMALConfig(n_estimators=5))
    with pytest.raises(ValueError, match="3-dimensional"):
        model.fit(np.random.randn(50, 5), np.random.randn(50, 5, 1))
    with pytest.raises(ValueError, match="3-dimensional"):
        model.fit(np.random.randn(50, 5, 3), np.random.randn(50, 5))


def test_predict_before_fit():
    model = NGBOOSTNORMALModel()
    with pytest.raises(ValueError, match="not been fitted"):
        model.predict(np.random.randn(10, 5, 3))


# ---------------------------------------------------------------------------
# forecast() tests
# ---------------------------------------------------------------------------


def test_forecast_returns_dict(fitted_model):
    model, x_data, _ = fitted_model
    out = model.forecast(x_data)
    assert "loc" in out
    assert "scale" in out
    assert out["loc"].shape == (60, 6, 1)
    assert out["scale"].shape == (60, 6, 1)


def test_forecast_no_extra_keys(fitted_model):
    model, x_data, _ = fitted_model
    out = model.forecast(x_data)
    assert set(out.keys()) == {"loc", "scale"}


# ---------------------------------------------------------------------------
# update() tests
# ---------------------------------------------------------------------------


def test_update_resets_state(sample_inputs):
    x_data, y = sample_inputs
    model = NGBOOSTNORMALModel(NGBOOSTNORMALConfig(n_estimators=5))
    model.fit(x_data, y)
    assert len(model._models) > 0

    trial = Mock(spec=optuna.trial.Trial)
    trial.suggest_int.return_value = 200
    trial.suggest_float.return_value = 0.05

    model.update(trial)
    assert model._models == []
    assert model.num_targets is None
    assert model._horizon is None
    assert model._n_out is None


def test_update_patches_config(sample_inputs):
    x_data, y = sample_inputs
    model = NGBOOSTNORMALModel(NGBOOSTNORMALConfig(n_estimators=5))
    model.fit(x_data, y)

    trial = Mock(spec=optuna.trial.Trial)
    trial.suggest_int.return_value = 250
    trial.suggest_float.return_value = 0.02

    model.update(trial)
    assert model.model_config.n_estimators == 250
