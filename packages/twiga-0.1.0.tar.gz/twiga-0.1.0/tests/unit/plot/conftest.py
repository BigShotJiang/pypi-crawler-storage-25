"""Shared fixtures for plot unit tests."""

import numpy as np
import pandas as pd
import pytest


@pytest.fixture
def forecast_df():
    """DataFrame with actual + forecast columns spanning 48 hourly periods."""
    rng = np.random.default_rng(0)
    n = 48
    dates = pd.date_range("2024-01-01", periods=n, freq="h")
    actual = rng.standard_normal(n).cumsum() + 10
    return pd.DataFrame(
        {
            "ds": dates,
            "Actual": actual,
            "forecast": actual + rng.standard_normal(n) * 0.5,
            "lower": actual - 1.0,
            "upper": actual + 1.0,
            "split": ["train"] * 32 + ["test"] * 16,
        }
    )


@pytest.fixture
def distribution_df():
    """Long-format DataFrame for distribution plots."""
    rng = np.random.default_rng(1)
    n = 200
    return pd.DataFrame(
        {
            "value": np.concatenate([rng.standard_normal(n), rng.standard_normal(n) + 2]),
            "distribution": ["A"] * n + ["B"] * n,
        }
    )


@pytest.fixture
def metrics_df():
    """Metrics summary DataFrame for bar chart."""
    return pd.DataFrame(
        {
            "model": ["ModelA", "ModelB", "ModelC"],
            "MAE": [0.5, 0.8, 0.3],
            "RMSE": [0.7, 1.0, 0.5],
        }
    )


@pytest.fixture
def residual_df():
    """DataFrame for residual diagnostic plots."""
    rng = np.random.default_rng(5)
    n = 80
    fitted = rng.standard_normal(n)
    return pd.DataFrame(
        {
            "fitted": fitted,
            "residuals": rng.standard_normal(n) * 0.3,
            "split": ["train"] * 50 + ["test"] * 30,
        }
    )


@pytest.fixture
def acf_series():
    """A simple AR(1) time series for ACF testing."""
    rng = np.random.default_rng(2)
    n = 200
    series = np.zeros(n)
    for i in range(1, n):
        series[i] = 0.7 * series[i - 1] + rng.standard_normal()
    return pd.Series(series)
