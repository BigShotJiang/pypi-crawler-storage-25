"""Tests for twiga.core.plot.timeseries.

All functions return Lets-Plot PlotSpec objects.  Tests verify:
- No exception is raised for valid inputs.
- Return type is a Lets-Plot ``PlotSpec``.
"""

from lets_plot.plot.core import PlotSpec
import numpy as np
import pandas as pd
import pytest

from twiga.core.plot import (
    plot_forecast,
    plot_forecast_grid,
    plot_forecast_intervals,
    plot_quantile_fan,
    plot_timeseries,
)


def _is_plot_spec(obj) -> bool:
    return isinstance(obj, PlotSpec)


class TestPlotForecast:
    def test_returns_plot_spec(self, forecast_df):
        p = plot_forecast(forecast_df, actual_col="Actual", forecast_col="forecast")
        assert _is_plot_spec(p)

    def test_with_intervals(self, forecast_df):
        p = plot_forecast(
            forecast_df,
            actual_col="Actual",
            forecast_col="forecast",
            lower_col="lower",
            upper_col="upper",
        )
        assert _is_plot_spec(p)

    def test_with_date_col(self, forecast_df):
        p = plot_forecast(forecast_df, date_col="ds", actual_col="Actual", forecast_col="forecast")
        assert _is_plot_spec(p)

    def test_custom_labels(self, forecast_df):
        p = plot_forecast(
            forecast_df,
            actual_col="Actual",
            forecast_col="forecast",
            title="My Forecast",
            x_label="Time",
            y_label="Power (MW)",
        )
        assert _is_plot_spec(p)


class TestPlotTimeseries:
    def test_returns_plot_spec(self, forecast_df):
        p = plot_timeseries(forecast_df, "Actual")
        assert _is_plot_spec(p)

    def test_with_date_col(self, forecast_df):
        p = plot_timeseries(forecast_df, "Actual", date_col="ds")
        assert _is_plot_spec(p)

    def test_multiple_y_cols(self, forecast_df):
        p = plot_timeseries(forecast_df, ["Actual", "forecast"])
        assert _is_plot_spec(p)


class TestPlotForecastGrid:
    def test_returns_plot_spec(self, forecast_df):
        # plot_forecast_grid takes a DataFrame with a model_col column
        df = forecast_df.copy()
        df2 = forecast_df.copy()
        df["Model"] = "ModelA"
        df2["Model"] = "ModelB"
        combined = pd.concat([df, df2], ignore_index=True)
        p = plot_forecast_grid(combined, actual_col="Actual", forecast_col="forecast", model_col="Model")
        assert _is_plot_spec(p)


class TestPlotQuantileFan:
    def test_returns_plot_spec(self):
        rng = np.random.default_rng(3)
        n = 48
        dates = pd.date_range("2024-01-01", periods=n, freq="h")
        actual = rng.standard_normal(n) + 5
        df = pd.DataFrame(
            {
                "ds": dates,
                "Actual": actual,
                "q10": actual - 1.5,
                "q50": actual,
                "q90": actual + 1.5,
            }
        )
        # quantile_pairs: list of (lower_col, upper_col) tuples from widest to narrowest
        p = plot_quantile_fan(
            df,
            date_col="ds",
            actual_col="Actual",
            median_col="q50",
            quantile_pairs=[("q10", "q90")],
        )
        assert _is_plot_spec(p)


class TestPlotForecastIntervals:
    def test_returns_plot_spec(self, forecast_df):
        # interval_specs is a list of dicts describing each interval
        interval_specs = [
            {"lower_col": "lower", "upper_col": "upper", "label": "Model A"},
        ]
        p = plot_forecast_intervals(
            forecast_df,
            interval_specs,
            actual_col="Actual",
            date_col="ds",
        )
        assert _is_plot_spec(p)
