"""Tests for twiga.core.plot.distribution."""

from lets_plot.plot.core import PlotSpec
import numpy as np
import pandas as pd
import pytest

from twiga.core.plot import plot_cdf, plot_density, plot_distribution, plot_kde


def _is_plot_spec(obj) -> bool:
    return isinstance(obj, PlotSpec)


class TestPlotDensity:
    def test_returns_plot_spec(self, distribution_df):
        p = plot_density(distribution_df)
        assert _is_plot_spec(p)

    def test_custom_cols(self, distribution_df):
        p = plot_density(distribution_df, x_col="value", color_col="distribution")
        assert _is_plot_spec(p)

    def test_with_n_samples(self, distribution_df):
        p = plot_density(distribution_df, n_samples=50)
        assert _is_plot_spec(p)


class TestPlotKde:
    def test_returns_plot_spec(self, distribution_df):
        p = plot_kde(distribution_df, x_col="value")
        assert _is_plot_spec(p)

    def test_with_color_col(self, distribution_df):
        p = plot_kde(distribution_df, x_col="value", color_col="distribution")
        assert _is_plot_spec(p)

    def test_custom_title(self, distribution_df):
        p = plot_kde(distribution_df, x_col="value", title="KDE Plot")
        assert _is_plot_spec(p)


class TestPlotCdf:
    def test_returns_plot_spec(self, distribution_df):
        p = plot_cdf(distribution_df, x_col="value")
        assert _is_plot_spec(p)

    def test_with_color_col(self, distribution_df):
        p = plot_cdf(distribution_df, x_col="value", color_col="distribution")
        assert _is_plot_spec(p)


class TestPlotDistribution:
    def test_returns_plot_spec(self):
        rng = np.random.default_rng(5)
        n = 120
        hours = np.tile(np.arange(24), n // 24 + 1)[:n]
        df = pd.DataFrame({"hour": hours, "value": rng.standard_normal(n)})
        p = plot_distribution(df, x_col="hour", y_col="value")
        assert _is_plot_spec(p)
