"""Tests for twiga.core.plot.residuals (Lets-Plot) and matplot_theme.plot_prediction (matplotlib).

Lets-Plot functions are smoke-tested for correct return type.
plot_prediction is a matplotlib function tested with pytest-mpl image comparison.
"""

from lets_plot.plot.core import PlotSpec
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pytest

from twiga.core.plot import normal_q_qplot, residual_leverage_plot, residual_plot, squared_residual_plot
from twiga.core.plot.matplot_theme import plot_prediction


def _is_plot_spec(obj) -> bool:
    return isinstance(obj, PlotSpec)


# ---------------------------------------------------------------------------
# Lets-Plot residual diagnostics
# ---------------------------------------------------------------------------


class TestResidualPlot:
    def test_returns_plot_spec(self, residual_df):
        p = residual_plot(residual_df)
        assert _is_plot_spec(p)

    def test_custom_columns(self, residual_df):
        p = residual_plot(residual_df, x_col="fitted", y_col="residuals", color_col="split")
        assert _is_plot_spec(p)


class TestNormalQQPlot:
    def test_returns_plot_spec(self, residual_df):
        p = normal_q_qplot(residual_df)
        assert _is_plot_spec(p)


class TestSquaredResidualPlot:
    def test_returns_plot_spec(self, residual_df):
        p = squared_residual_plot(residual_df)
        assert _is_plot_spec(p)


class TestResidualLeveragePlot:
    def test_returns_plot_spec(self):
        rng = np.random.default_rng(3)
        n = 60
        df = pd.DataFrame(
            {
                "leverage": rng.uniform(0.01, 0.5, n),
                "std_residuals": rng.standard_normal(n),
                "cooks_d": rng.uniform(0, 1, n),
                "split": ["train"] * 40 + ["test"] * 20,
            }
        )
        p = residual_leverage_plot(df)
        assert _is_plot_spec(p)


# ---------------------------------------------------------------------------
# matplotlib plot_prediction — pytest-mpl image comparison
# ---------------------------------------------------------------------------


@pytest.mark.mpl_image_compare(baseline_dir="baseline", tolerance=10, style="default")
def test_plot_prediction_basic():
    """Baseline: true vs predicted scatter + line on clean sine-wave data."""
    n = 50
    x = np.linspace(0, 4 * np.pi, n)
    true = np.sin(x) * 5 + 10
    mu = true + np.random.default_rng(0).standard_normal(n) * 0.3

    fig, ax = plt.subplots(figsize=(6, 3))
    plot_prediction(ax, true=true, mu=mu)
    fig.tight_layout()
    return fig


@pytest.mark.mpl_image_compare(baseline_dir="baseline", tolerance=10, style="default")
def test_plot_prediction_with_dates():
    """Baseline: plot_prediction using explicit date array on x-axis."""
    n = 30
    dates = np.arange(n)
    true = np.linspace(1, 3, n)
    mu = true + np.random.default_rng(1).standard_normal(n) * 0.1

    fig, ax = plt.subplots(figsize=(6, 3))
    plot_prediction(ax, true=true, mu=mu, date=dates)
    return fig


class TestPlotPredictionSmoke:
    """Non-image tests that run without --mpl."""

    def test_returns_axes(self):
        fig, ax = plt.subplots()
        result = plot_prediction(ax, true=[1, 2, 3], mu=[1.1, 2.1, 3.1])
        assert result is ax
        plt.close(fig)

    def test_legend_contains_actual_and_forecast(self):
        fig, ax = plt.subplots()
        plot_prediction(ax, true=[1, 2, 3], mu=[1.1, 2.1, 3.1])
        labels = [t.get_text() for t in ax.get_legend().get_texts()]
        assert "Actual" in labels
        assert "Forecast" in labels
        plt.close(fig)
