"""Tests for twiga.core.plot.stats (ACF, metrics bar, PIT, reliability)."""

from lets_plot.plot.core import PlotSpec
import numpy as np
import pandas as pd
import pytest

from twiga.core.plot import plot_acf, plot_metrics_bar, plot_pit_histogram, plot_reliability_diagram


def _is_plot_spec(obj) -> bool:
    return isinstance(obj, PlotSpec)


class TestPlotAcf:
    def test_returns_plot_spec(self, acf_series):
        p = plot_acf(acf_series)
        assert _is_plot_spec(p)

    def test_partial_acf(self, acf_series):
        p = plot_acf(acf_series, partial=True)
        assert _is_plot_spec(p)

    def test_custom_max_lag(self, acf_series):
        p = plot_acf(acf_series, max_lag=20)
        assert _is_plot_spec(p)

    def test_numpy_array_input(self, acf_series):
        p = plot_acf(acf_series.values)
        assert _is_plot_spec(p)


class TestPlotMetricsBar:
    def test_returns_plot_spec(self, metrics_df):
        # model_col default is "Model" (capital M)
        df = metrics_df.rename(columns={"model": "Model"})
        p = plot_metrics_bar(df, metric_col="MAE")
        assert _is_plot_spec(p)

    def test_custom_model_col(self, metrics_df):
        p = plot_metrics_bar(metrics_df, metric_col="MAE", model_col="model")
        assert _is_plot_spec(p)


class TestPlotPitHistogram:
    def test_returns_plot_spec(self):
        rng = np.random.default_rng(42)
        pit_values = rng.uniform(0, 1, 200)
        p = plot_pit_histogram(pit_values)
        assert _is_plot_spec(p)

    def test_with_series_input(self):
        rng = np.random.default_rng(0)
        pit_series = pd.Series(rng.uniform(0, 1, 100))
        p = plot_pit_histogram(pit_series)
        assert _is_plot_spec(p)


class TestPlotReliabilityDiagram:
    def test_returns_plot_spec(self):
        nominal = [0.1, 0.5, 0.9]
        empirical = [0.12, 0.48, 0.88]
        p = plot_reliability_diagram(nominal, empirical)
        assert _is_plot_spec(p)

    def test_with_numpy_arrays(self):
        nominal = np.array([0.1, 0.25, 0.5, 0.75, 0.9])
        empirical = np.array([0.08, 0.22, 0.51, 0.77, 0.91])
        p = plot_reliability_diagram(nominal, empirical)
        assert _is_plot_spec(p)
