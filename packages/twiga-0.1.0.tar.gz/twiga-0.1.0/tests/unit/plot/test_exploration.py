"""Tests for twiga.core.plot.exploration."""

from lets_plot.plot.core import PlotSpec
import numpy as np
import pandas as pd
import pytest

from twiga.core.plot import correlation_heatmap, line_plot, scatter_matrix, scatter_plot


def _is_plot_spec(obj) -> bool:
    return isinstance(obj, PlotSpec)


@pytest.fixture
def tabular_df():
    rng = np.random.default_rng(10)
    n = 80
    return pd.DataFrame(
        {
            "x1": rng.standard_normal(n),
            "x2": rng.standard_normal(n),
            "x3": rng.standard_normal(n),
            "group": ["A"] * 40 + ["B"] * 40,
        }
    )


class TestLinePlot:
    def test_returns_plot_spec(self):
        y = list(range(20))
        p = line_plot(y=y, x=None)
        assert _is_plot_spec(p)

    def test_with_x(self):
        y = list(range(20))
        x = list(range(20))
        p = line_plot(y=y, x=x)
        assert _is_plot_spec(p)

    def test_custom_labels(self):
        p = line_plot(y=list(range(10)), x=None, title="My Chart", y_label="Energy")
        assert _is_plot_spec(p)


class TestScatterPlot:
    def test_returns_plot_spec(self, tabular_df):
        p = scatter_plot(tabular_df, x_col="x1", y_col="x2")
        assert _is_plot_spec(p)

    def test_with_color_col(self, tabular_df):
        p = scatter_plot(tabular_df, x_col="x1", y_col="x2", color_col="group")
        assert _is_plot_spec(p)


class TestScatterMatrix:
    def test_returns_plot_spec(self, tabular_df):
        # n_sample must be <= len(data); disable sampling with n_sample=None
        p = scatter_matrix(tabular_df, variables=["x1", "x2"], targets=["x3"], n_sample=None)
        assert _is_plot_spec(p)


class TestCorrelationHeatmap:
    def test_returns_plot_spec(self):
        rng = np.random.default_rng(7)
        n = 20
        df = pd.DataFrame(
            {
                "col1": [f"feature_{i}" for i in range(n)],
                "col2": ["target"] * n,
                "correlation": rng.uniform(-1, 1, n),
            }
        )
        p = correlation_heatmap(df)
        assert _is_plot_spec(p)
