"""Unit tests for forecaster utility functions."""

import numpy as np
import pandas as pd
import pytest

from twiga.core.data.pipeline import DataPipeline
from twiga.forecaster.utils import (
    build_ground_truth_df,
    merge_and_format_results,
    validate_shapes,
)


@pytest.fixture
def data_pipeline():
    """Fixture providing a mock DataPipeline instance for testing.

    Returns:
        MockDataPipeline: Mock pipeline with target_feature and date_column attributes.
    """

    class MockDataPipeline:
        target_feature = ["target1"]
        date_column = "timestamp"

    return MockDataPipeline()


@pytest.fixture
def sample_data():
    """Fixture providing sample data for forecasting tests.

    Returns:
        dict: Dictionary containing:
            - timestamps: numpy array of timestamps
            - ground_truth: numpy array of ground truth values
            - prediction: numpy array of point predictions
            - interval_prediction: Tuple of numpy arrays for interval predictions
            - shape: Original data shape (num_samples, horizon, num_targets)
    """
    num_samples = 2
    horizon = 3
    num_targets = 1
    shape = (num_samples, horizon, num_targets)

    timestamps = np.array(
        [
            [[pd.Timestamp("2023-01-01").asm8], [pd.Timestamp("2023-01-02").asm8], [pd.Timestamp("2023-01-03").asm8]],
            [[pd.Timestamp("2023-01-04").asm8], [pd.Timestamp("2023-01-05").asm8], [pd.Timestamp("2023-01-06").asm8]],
        ]
    )

    return {
        "timestamps": timestamps,
        "ground_truth": np.random.rand(*shape),
        "prediction": np.random.rand(*shape),
        "interval_prediction": (np.random.rand(*shape), np.random.rand(*shape), np.random.rand(*shape)),
        "shape": shape,
    }


def test_validate_shapes_valid(sample_data):
    """Test shape validation with valid inputs.

    Args:
        sample_data: Fixture containing test data configurations
    """
    prediction_dict = {"model1": sample_data["prediction"]}
    assert validate_shapes(
        prediction_dict, sample_data["timestamps"], sample_data["ground_truth"], is_interval=False
    ) == (2, 3, 1)


def test_validate_shapes_invalid_ground_truth(sample_data):
    """Test shape validation with invalid ground truth dimensions.

    Args:
        sample_data: Fixture containing test data configurations
    """
    prediction_dict = {"model1": sample_data["prediction"]}
    invalid_gt = np.random.rand(2, 4, 1)
    with pytest.raises(ValueError) as e:
        validate_shapes(prediction_dict, sample_data["timestamps"], invalid_gt, False)
    assert "Ground truth shape" in str(e.value)


def test_validate_shapes_invalid_model_prediction(sample_data):
    """Test shape validation with invalid model prediction dimensions.

    Verifies detection of model predictions with mismatched target dimensions.

    Args:
        sample_data: Fixture containing test data configurations
    """
    prediction_dict = {"valid_model": sample_data["prediction"], "invalid_model": np.random.rand(2, 3, 2)}

    with pytest.raises(ValueError) as e:
        validate_shapes(prediction_dict, sample_data["timestamps"], sample_data["ground_truth"], is_interval=False)
    assert "Model invalid_model prediction shape" in str(e.value)


def test_validate_shapes_interval(sample_data):
    """Test shape validation with interval predictions.

    Args:
        sample_data: Fixture containing test data configurations
    """
    prediction_dict = {"model1": sample_data["interval_prediction"]}
    assert validate_shapes(
        prediction_dict, sample_data["timestamps"], sample_data["ground_truth"], is_interval=True
    ) == (2, 3, 1)


def test_build_ground_truth_df(sample_data, data_pipeline):
    """Test construction of ground truth DataFrame.

    Args:
        sample_data: Fixture containing test data configurations
        data_pipeline: Fixture providing mock DataPipeline instance
    """
    df = build_ground_truth_df(sample_data["timestamps"], sample_data["ground_truth"], data_pipeline)

    assert df.shape == (6, 3)
    assert list(df.columns) == ["timestamp", "target", "Actual"]
    assert (df["target"] == "target1").all()
    assert df["timestamp"].is_monotonic_increasing


def test_merge_and_format_results(sample_data, data_pipeline):
    """Test merging and formatting of prediction results.

    Args:
        sample_data: Fixture containing test data configurations
        data_pipeline: Fixture providing mock DataPipeline instance
    """
    ground_truth_df = build_ground_truth_df(sample_data["timestamps"], sample_data["ground_truth"], data_pipeline)

    predictions_df = pd.DataFrame(
        {
            "timestamp": pd.date_range(start="2023-01-01", periods=6, freq="D").tz_localize("UTC"),
            "Model": ["MODEL"] * 6,
            "target": ["target1"] * 6,
            "forecast": np.random.rand(6),
        }
    )

    merged_df = merge_and_format_results(predictions_df, ground_truth_df, data_pipeline)

    assert merged_df.index.name == "timestamp"
    assert "Actual" in merged_df.columns
    assert merged_df.shape[0] == 6
    assert not merged_df.isna().any().any()
