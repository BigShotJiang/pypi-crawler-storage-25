"""Unit tests for twiga.forecaster.result and twiga.forecaster.utils.build_forecast_result.

Covers:
- ForecastKind enum values and string behaviour.
- ForecastResult construction, validation, to_dataframe, to_metrics_inputs,
  and evaluate integration.
- ForecastCollection add, access, iteration, and to_dataframe.
- build_forecast_result factory for every supported raw prediction format.
"""

from __future__ import annotations

from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest

from twiga.forecaster.result import ForecastCollection, ForecastKind, ForecastResult
from twiga.forecaster.utils import build_forecast_result

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

N_BATCH = 3
N_HORIZON = 24
N_TARGETS = 2
N_Q = 3
N_SAMPLES = 20
TARGETS = ["load", "pv"]
QUANTILE_LEVELS = [0.1, 0.5, 0.9]


def _make_timestamps(n_batch: int, n_horizon: int, n_targets: int) -> np.ndarray:
    """Return a synthetic timestamp array in nanosecond int64 format."""
    base = pd.date_range("2024-01-01", periods=n_batch * n_horizon, freq="h")
    ts = base.asi8.reshape(n_batch, n_horizon, 1)
    return np.repeat(ts, n_targets, axis=2)


@pytest.fixture()
def loc() -> np.ndarray:
    """Point predictions, shape (N_BATCH, N_HORIZON, N_TARGETS)."""
    return np.random.default_rng(0).standard_normal((N_BATCH, N_HORIZON, N_TARGETS)) + 5


@pytest.fixture()
def ground_truth(loc: np.ndarray) -> np.ndarray:
    """Ground truth close to loc."""
    return loc + np.random.default_rng(1).standard_normal(loc.shape) * 0.1


@pytest.fixture()
def timestamps() -> np.ndarray:
    """Timestamp array compatible with loc shape."""
    return _make_timestamps(N_BATCH, N_HORIZON, N_TARGETS)


@pytest.fixture()
def scale(loc: np.ndarray) -> np.ndarray:
    """Positive scale array matching loc shape."""
    return np.random.default_rng(2).uniform(0.1, 1.0, loc.shape)


@pytest.fixture()
def quantiles(loc: np.ndarray) -> np.ndarray:
    """Sorted quantile array, shape (N_BATCH, N_Q, N_HORIZON, N_TARGETS)."""
    rng = np.random.default_rng(3)
    offsets = rng.standard_normal((N_BATCH, N_Q, N_HORIZON, N_TARGETS))
    return loc[:, np.newaxis, :, :] + np.sort(offsets, axis=1)


@pytest.fixture()
def samples(loc: np.ndarray) -> np.ndarray:
    """Sample array, shape (N_BATCH, N_SAMPLES, N_HORIZON, N_TARGETS)."""
    rng = np.random.default_rng(4)
    return loc[:, np.newaxis, :, :] + rng.standard_normal((N_BATCH, N_SAMPLES, N_HORIZON, N_TARGETS))


@pytest.fixture()
def lower(loc: np.ndarray) -> np.ndarray:
    """Lower bound, loc minus a positive offset."""
    return loc - np.random.default_rng(5).uniform(0.5, 1.0, loc.shape)


@pytest.fixture()
def upper(loc: np.ndarray) -> np.ndarray:
    """Upper bound, loc plus a positive offset."""
    return loc + np.random.default_rng(6).uniform(0.5, 1.0, loc.shape)


# ---------------------------------------------------------------------------
# ForecastKind
# ---------------------------------------------------------------------------


class TestForecastKind:
    """Tests for ForecastKind enum."""

    def test_values_are_strings(self) -> None:
        """All enum values are plain strings (str mixin)."""
        for kind in ForecastKind:
            assert isinstance(kind.value, str)

    def test_equality_with_string(self) -> None:
        """Kind can be compared to its string value."""
        assert ForecastKind.POINT == "point"
        assert ForecastKind.PARAMETRIC == "parametric"
        assert ForecastKind.QUANTILE == "quantile"
        assert ForecastKind.SAMPLES == "samples"
        assert ForecastKind.INTERVAL == "interval"

    def test_all_five_kinds_exist(self) -> None:
        """Exactly five kinds are defined."""
        assert len(list(ForecastKind)) == 5


# ---------------------------------------------------------------------------
# ForecastResult construction
# ---------------------------------------------------------------------------


class TestForecastResultConstruction:
    """Tests for ForecastResult __init__ and __post_init__ validation."""

    def test_point_construction(self, loc: np.ndarray, timestamps: np.ndarray) -> None:
        """Point ForecastResult constructs without error."""
        result = ForecastResult(
            timestamps=timestamps, loc=loc, targets=TARGETS, model_name="catboost", kind=ForecastKind.POINT
        )
        assert result.kind == ForecastKind.POINT
        assert result.model_name == "catboost"

    def test_parametric_requires_scale(self, loc: np.ndarray, timestamps: np.ndarray) -> None:
        """PARAMETRIC kind raises ValueError when scale is absent."""
        with pytest.raises(ValueError, match="scale"):
            ForecastResult(
                timestamps=timestamps, loc=loc, targets=TARGETS, model_name="mlpf", kind=ForecastKind.PARAMETRIC
            )

    def test_quantile_requires_quantiles(self, loc: np.ndarray, timestamps: np.ndarray) -> None:
        """QUANTILE kind raises ValueError when quantiles is absent."""
        with pytest.raises(ValueError, match="quantiles"):
            ForecastResult(
                timestamps=timestamps, loc=loc, targets=TARGETS, model_name="mlpf", kind=ForecastKind.QUANTILE
            )

    def test_samples_requires_samples(self, loc: np.ndarray, timestamps: np.ndarray) -> None:
        """SAMPLES kind raises ValueError when samples is absent."""
        with pytest.raises(ValueError, match="samples"):
            ForecastResult(
                timestamps=timestamps, loc=loc, targets=TARGETS, model_name="mlpf", kind=ForecastKind.SAMPLES
            )

    def test_interval_requires_lower_and_upper(self, loc: np.ndarray, timestamps: np.ndarray) -> None:
        """INTERVAL kind raises ValueError when lower or upper is absent."""
        with pytest.raises(ValueError, match="lower|upper"):
            ForecastResult(
                timestamps=timestamps, loc=loc, targets=TARGETS, model_name="mlpf", kind=ForecastKind.INTERVAL
            )

    def test_ground_truth_optional(self, loc: np.ndarray, timestamps: np.ndarray) -> None:
        """ground_truth defaults to None and can be set later."""
        result = ForecastResult(
            timestamps=timestamps, loc=loc, targets=TARGETS, model_name="catboost", kind=ForecastKind.POINT
        )
        assert result.ground_truth is None

    def test_inference_time_defaults_to_zero(self, loc: np.ndarray, timestamps: np.ndarray) -> None:
        """inference_time defaults to 0.0."""
        result = ForecastResult(
            timestamps=timestamps, loc=loc, targets=TARGETS, model_name="catboost", kind=ForecastKind.POINT
        )
        assert result.inference_time == 0.0


# ---------------------------------------------------------------------------
# ForecastResult.to_dataframe — POINT
# ---------------------------------------------------------------------------


class TestToDataFramePoint:
    """Tests for ForecastResult.to_dataframe with ForecastKind.POINT."""

    @pytest.fixture()
    def point_result(self, loc: np.ndarray, timestamps: np.ndarray, ground_truth: np.ndarray) -> ForecastResult:
        """Construct a POINT ForecastResult."""
        return ForecastResult(
            timestamps=timestamps,
            loc=loc,
            targets=TARGETS,
            model_name="catboost",
            kind=ForecastKind.POINT,
            ground_truth=ground_truth,
        )

    def test_returns_dataframe(self, point_result: ForecastResult) -> None:
        """to_dataframe returns a DataFrame."""
        assert isinstance(point_result.to_dataframe(), pd.DataFrame)

    def test_row_count(self, point_result: ForecastResult) -> None:
        """Row count equals n_batch × n_horizon × n_targets."""
        df = point_result.to_dataframe()
        assert len(df) == N_BATCH * N_HORIZON * N_TARGETS

    def test_required_columns(self, point_result: ForecastResult) -> None:
        """All base columns are present."""
        df = point_result.to_dataframe()
        for col in ("timestamp", "target", "model", "forecast"):
            assert col in df.columns

    def test_actual_column_when_ground_truth_set(self, point_result: ForecastResult) -> None:
        """'actual' column is appended when ground_truth is provided."""
        df = point_result.to_dataframe()
        assert "actual" in df.columns

    def test_no_actual_column_without_ground_truth(self, loc: np.ndarray, timestamps: np.ndarray) -> None:
        """'actual' column is absent when ground_truth is None."""
        result = ForecastResult(
            timestamps=timestamps, loc=loc, targets=TARGETS, model_name="catboost", kind=ForecastKind.POINT
        )
        df = result.to_dataframe()
        assert "actual" not in df.columns

    def test_model_column_value(self, point_result: ForecastResult) -> None:
        """'model' column contains the model name."""
        df = point_result.to_dataframe()
        assert (df["model"] == "catboost").all()

    def test_target_values(self, point_result: ForecastResult) -> None:
        """'target' column contains the expected target names."""
        df = point_result.to_dataframe()
        assert set(df["target"].unique()) == set(TARGETS)

    def test_invalid_fmt_raises(self, point_result: ForecastResult) -> None:
        """Raises ValueError for unsupported fmt values."""
        with pytest.raises(ValueError, match="fmt must be"):
            point_result.to_dataframe(fmt="invalid")


# ---------------------------------------------------------------------------
# ForecastResult.to_dataframe — PARAMETRIC
# ---------------------------------------------------------------------------


class TestToDataFrameParametric:
    """Tests for ForecastResult.to_dataframe with ForecastKind.PARAMETRIC."""

    @pytest.fixture()
    def parametric_result(self, loc: np.ndarray, timestamps: np.ndarray, scale: np.ndarray) -> ForecastResult:
        """Construct a PARAMETRIC ForecastResult."""
        return ForecastResult(
            timestamps=timestamps,
            loc=loc,
            targets=TARGETS,
            model_name="mlpf_normal",
            kind=ForecastKind.PARAMETRIC,
            scale=scale,
        )

    def test_scale_column_present(self, parametric_result: ForecastResult) -> None:
        """'scale' column is added."""
        df = parametric_result.to_dataframe()
        assert "scale" in df.columns

    def test_scale_values_positive(self, parametric_result: ForecastResult) -> None:
        """All scale values are positive."""
        df = parametric_result.to_dataframe()
        assert (df["scale"] > 0).all()


# ---------------------------------------------------------------------------
# ForecastResult.to_dataframe — INTERVAL
# ---------------------------------------------------------------------------


class TestToDataFrameInterval:
    """Tests for ForecastResult.to_dataframe with ForecastKind.INTERVAL."""

    @pytest.fixture()
    def interval_result(
        self, loc: np.ndarray, timestamps: np.ndarray, lower: np.ndarray, upper: np.ndarray
    ) -> ForecastResult:
        """Construct an INTERVAL ForecastResult."""
        return ForecastResult(
            timestamps=timestamps,
            loc=loc,
            targets=TARGETS,
            model_name="mlpf_conformal",
            kind=ForecastKind.INTERVAL,
            lower=lower,
            upper=upper,
        )

    def test_lower_upper_columns_present(self, interval_result: ForecastResult) -> None:
        """'lower' and 'upper' columns are present."""
        df = interval_result.to_dataframe()
        assert "lower" in df.columns
        assert "upper" in df.columns

    def test_lower_leq_upper(self, interval_result: ForecastResult) -> None:
        """Lower ≤ upper for every row."""
        df = interval_result.to_dataframe()
        assert (df["lower"] <= df["upper"]).all()


# ---------------------------------------------------------------------------
# ForecastResult.to_dataframe — QUANTILE
# ---------------------------------------------------------------------------


class TestToDataFrameQuantile:
    """Tests for ForecastResult.to_dataframe with ForecastKind.QUANTILE."""

    @pytest.fixture()
    def quantile_result(self, loc: np.ndarray, timestamps: np.ndarray, quantiles: np.ndarray) -> ForecastResult:
        """Construct a QUANTILE ForecastResult."""
        return ForecastResult(
            timestamps=timestamps,
            loc=loc,
            targets=TARGETS,
            model_name="mlpf_qr",
            kind=ForecastKind.QUANTILE,
            quantiles=quantiles,
            quantile_levels=QUANTILE_LEVELS,
        )

    def test_long_format_has_q_level_column(self, quantile_result: ForecastResult) -> None:
        """Long format includes 'q_level' and 'quantile_forecast' columns."""
        df = quantile_result.to_dataframe(fmt="long")
        assert "q_level" in df.columns
        assert "quantile_forecast" in df.columns

    def test_long_format_row_count(self, quantile_result: ForecastResult) -> None:
        """Long format has n_batch × n_horizon × n_targets × n_q rows."""
        df = quantile_result.to_dataframe(fmt="long")
        assert len(df) == N_BATCH * N_HORIZON * N_TARGETS * N_Q

    def test_wide_format_has_q_columns(self, quantile_result: ForecastResult) -> None:
        """Wide format has one column per quantile level."""
        df = quantile_result.to_dataframe(fmt="wide")
        for level in QUANTILE_LEVELS:
            assert f"q_{level:.2f}" in df.columns

    def test_wide_format_row_count(self, quantile_result: ForecastResult) -> None:
        """Wide format has n_batch × n_horizon × n_targets rows (same as point)."""
        df = quantile_result.to_dataframe(fmt="wide")
        assert len(df) == N_BATCH * N_HORIZON * N_TARGETS


# ---------------------------------------------------------------------------
# ForecastResult.to_dataframe — SAMPLES
# ---------------------------------------------------------------------------


class TestToDataFrameSamples:
    """Tests for ForecastResult.to_dataframe with ForecastKind.SAMPLES."""

    @pytest.fixture()
    def samples_result(self, loc: np.ndarray, timestamps: np.ndarray, samples: np.ndarray) -> ForecastResult:
        """Construct a SAMPLES ForecastResult."""
        return ForecastResult(
            timestamps=timestamps,
            loc=loc,
            targets=TARGETS,
            model_name="mlpf_vi",
            kind=ForecastKind.SAMPLES,
            samples=samples,
        )

    def test_summary_quantile_columns_present(self, samples_result: ForecastResult) -> None:
        """Empirical summary quantile columns are added."""
        df = samples_result.to_dataframe()
        for q in ("q_0.10", "q_0.50", "q_0.90"):
            assert q in df.columns, f"Missing column: {q}"

    def test_row_count_same_as_point(self, samples_result: ForecastResult) -> None:
        """Row count is n_batch × n_horizon × n_targets (no sample explosion)."""
        df = samples_result.to_dataframe()
        assert len(df) == N_BATCH * N_HORIZON * N_TARGETS

    def test_quantiles_ordered(self, samples_result: ForecastResult) -> None:
        """q_0.10 ≤ q_0.50 ≤ q_0.90 for every row."""
        df = samples_result.to_dataframe()
        assert (df["q_0.10"] <= df["q_0.50"]).all()
        assert (df["q_0.50"] <= df["q_0.90"]).all()


# ---------------------------------------------------------------------------
# ForecastResult.evaluate
# ---------------------------------------------------------------------------


class TestForecastResultEvaluate:
    """Tests for ForecastResult.evaluate integration."""

    def test_evaluate_point_returns_dataframe(self, loc: np.ndarray, timestamps: np.ndarray) -> None:
        """evaluate() returns a DataFrame for POINT kind."""
        result = ForecastResult(
            timestamps=timestamps, loc=loc, targets=TARGETS, model_name="m", kind=ForecastKind.POINT
        )
        gt = loc + np.random.default_rng(0).standard_normal(loc.shape) * 0.2
        df = result.evaluate(gt)
        assert isinstance(df, pd.DataFrame)
        assert "mae" in df.columns

    def test_evaluate_delegates_to_evaluate_forecast(self, loc: np.ndarray, timestamps: np.ndarray) -> None:
        """evaluate() calls evaluate_forecast with the ForecastResult (kind inferred from result)."""
        result = ForecastResult(
            timestamps=timestamps, loc=loc, targets=TARGETS, model_name="m", kind=ForecastKind.POINT
        )
        gt = loc.copy()
        # evaluate_forecast is imported locally inside ForecastResult.evaluate;
        # patch it at the source module level.
        with patch("twiga.core.metrics.evaluate_forecast") as mock_ef:
            mock_ef.return_value = pd.DataFrame()
            result.evaluate(gt)
            mock_ef.assert_called_once()
            call_args, _ = mock_ef.call_args
            # First positional arg must be a ForecastResult whose ground_truth is set
            assert call_args[0].kind == ForecastKind.POINT
            assert call_args[0].ground_truth is not None


# ---------------------------------------------------------------------------
# ForecastCollection
# ---------------------------------------------------------------------------


class TestForecastCollection:
    """Tests for ForecastCollection."""

    @pytest.fixture()
    def point_result_a(self, loc: np.ndarray, timestamps: np.ndarray) -> ForecastResult:
        """First POINT result."""
        return ForecastResult(
            timestamps=timestamps, loc=loc, targets=TARGETS, model_name="catboost", kind=ForecastKind.POINT
        )

    @pytest.fixture()
    def point_result_b(self, loc: np.ndarray, timestamps: np.ndarray) -> ForecastResult:
        """Second POINT result with a different model name."""
        loc_b = loc + 0.5
        return ForecastResult(
            timestamps=timestamps, loc=loc_b, targets=TARGETS, model_name="lightgbm", kind=ForecastKind.POINT
        )

    def test_add_and_access(self, point_result_a: ForecastResult, point_result_b: ForecastResult) -> None:
        """add() stores and __getitem__ retrieves results by model name."""
        col = ForecastCollection()
        col.add(point_result_a)
        col.add(point_result_b)
        assert col["catboost"] is point_result_a
        assert col["lightgbm"] is point_result_b

    def test_contains(self, point_result_a: ForecastResult) -> None:
        """__contains__ returns True for stored model names."""
        col = ForecastCollection()
        col.add(point_result_a)
        assert "catboost" in col
        assert "xgboost" not in col

    def test_len(self, point_result_a: ForecastResult, point_result_b: ForecastResult) -> None:
        """__len__ returns number of models in collection."""
        col = ForecastCollection()
        assert len(col) == 0
        col.add(point_result_a)
        col.add(point_result_b)
        assert len(col) == 2

    def test_model_names(self, point_result_a: ForecastResult, point_result_b: ForecastResult) -> None:
        """model_names property returns all model names in insertion order."""
        col = ForecastCollection()
        col.add(point_result_a)
        col.add(point_result_b)
        assert col.model_names == ["catboost", "lightgbm"]

    def test_iter(self, point_result_a: ForecastResult, point_result_b: ForecastResult) -> None:
        """Iterating yields ForecastResult objects (checked by identity)."""
        col = ForecastCollection()
        col.add(point_result_a)
        col.add(point_result_b)
        results = list(col)
        assert any(r is point_result_a for r in results)
        assert any(r is point_result_b for r in results)

    def test_to_dataframe_combines_models(self, point_result_a: ForecastResult, point_result_b: ForecastResult) -> None:
        """to_dataframe concatenates all models into one DataFrame."""
        col = ForecastCollection()
        col.add(point_result_a)
        col.add(point_result_b)
        df = col.to_dataframe()
        assert isinstance(df, pd.DataFrame)
        assert set(df["model"].unique()) == {"catboost", "lightgbm"}

    def test_to_dataframe_empty_raises(self) -> None:
        """to_dataframe raises ValueError when the collection is empty."""
        col = ForecastCollection()
        with pytest.raises(ValueError, match="empty"):
            col.to_dataframe()

    def test_constructor_accepts_dict(self, point_result_a: ForecastResult, point_result_b: ForecastResult) -> None:
        """ForecastCollection can be initialised with a pre-built dict."""
        col = ForecastCollection(results={"catboost": point_result_a, "lightgbm": point_result_b})
        assert len(col) == 2


# ---------------------------------------------------------------------------
# build_forecast_result
# ---------------------------------------------------------------------------


class TestBuildForecastResult:
    """Tests for build_forecast_result factory."""

    @pytest.fixture()
    def kwargs(self, timestamps: np.ndarray) -> dict:
        """Common factory keyword arguments."""
        return {"model_name": "test_model", "timestamps": timestamps, "targets": TARGETS}

    def test_ndarray_produces_point(self, loc: np.ndarray, kwargs: dict) -> None:
        """np.ndarray input is interpreted as a POINT result."""
        result = build_forecast_result(pred=loc, **kwargs)
        assert result.kind == ForecastKind.POINT
        np.testing.assert_array_equal(result.loc, loc)

    def test_tuple_produces_interval(self, loc: np.ndarray, lower: np.ndarray, upper: np.ndarray, kwargs: dict) -> None:
        """3-tuple (lower, loc, upper) is interpreted as an INTERVAL result."""
        result = build_forecast_result(pred=(lower, loc, upper), **kwargs)
        assert result.kind == ForecastKind.INTERVAL
        np.testing.assert_array_equal(result.lower, lower)
        np.testing.assert_array_equal(result.upper, upper)

    def test_tuple_wrong_length_raises(self, loc: np.ndarray, kwargs: dict) -> None:
        """Tuple with ≠ 3 elements raises ValueError."""
        with pytest.raises(ValueError, match="3 elements"):
            build_forecast_result(pred=(loc, loc), **kwargs)

    def test_dict_loc_only_produces_point(self, loc: np.ndarray, kwargs: dict) -> None:
        """Dict with only 'loc' is treated as a POINT result."""
        result = build_forecast_result(pred={"loc": loc}, **kwargs)
        assert result.kind == ForecastKind.POINT

    def test_dict_with_scale_produces_parametric(self, loc: np.ndarray, scale: np.ndarray, kwargs: dict) -> None:
        """Dict with 'loc' and 'scale' is interpreted as a PARAMETRIC result."""
        result = build_forecast_result(pred={"loc": loc, "scale": scale}, **kwargs)
        assert result.kind == ForecastKind.PARAMETRIC
        np.testing.assert_array_equal(result.scale, scale)

    def test_dict_with_quantiles_produces_quantile(self, loc: np.ndarray, quantiles: np.ndarray, kwargs: dict) -> None:
        """Dict with 'loc' and 'quantiles' is interpreted as a QUANTILE result."""
        pred = {"loc": loc, "quantiles": quantiles, "quantile_levels": QUANTILE_LEVELS}
        result = build_forecast_result(pred=pred, **kwargs)
        assert result.kind == ForecastKind.QUANTILE
        assert result.quantile_levels == QUANTILE_LEVELS

    def test_dict_with_samples_produces_samples(self, loc: np.ndarray, samples: np.ndarray, kwargs: dict) -> None:
        """Dict with 'loc' and 'samples' is interpreted as a SAMPLES result."""
        result = build_forecast_result(pred={"loc": loc, "samples": samples}, **kwargs)
        assert result.kind == ForecastKind.SAMPLES

    def test_dict_missing_loc_raises(self, kwargs: dict) -> None:
        """Dict without 'loc' key raises ValueError."""
        with pytest.raises(ValueError, match="'loc'"):
            build_forecast_result(pred={"scale": np.ones((N_BATCH, N_HORIZON, N_TARGETS))}, **kwargs)

    def test_unsupported_type_raises(self, kwargs: dict) -> None:
        """Unsupported pred type raises TypeError."""
        with pytest.raises(TypeError, match="Unsupported prediction type"):
            build_forecast_result(pred="not_an_array", **kwargs)

    def test_ground_truth_forwarded(self, loc: np.ndarray, kwargs: dict) -> None:
        """ground_truth is stored on the result when provided."""
        gt = loc + 0.1
        result = build_forecast_result(pred=loc, ground_truth=gt, **kwargs)
        np.testing.assert_array_equal(result.ground_truth, gt)

    def test_inference_time_forwarded(self, loc: np.ndarray, kwargs: dict) -> None:
        """inference_time is stored on the result."""
        result = build_forecast_result(pred=loc, inference_time=0.42, **kwargs)
        assert result.inference_time == pytest.approx(0.42)

    def test_model_name_stored(self, loc: np.ndarray, kwargs: dict) -> None:
        """model_name from kwargs is stored on the result."""
        result = build_forecast_result(pred=loc, **kwargs)
        assert result.model_name == "test_model"
