"""Tests for the unified distribution= API on base arch configs.

Verifies that ModelConfig(distribution="X", **extra_params) resolves to
the correct concrete config class with all extra params preserved.
"""

from __future__ import annotations

from pydantic import ValidationError
import pytest

from twiga.forecaster.core import TwigaForecaster
from twiga.models.nn import (
    MLPFConfig,
    MLPFFPQRConfig,
    MLPFNormalConfig,
    MLPFQRConfig,
    MLPGAFConfig,
    MLPGAFFPQRConfig,
    MLPGAFNormalConfig,
    MLPGAFQRConfig,
    MLPGAMConfig,
    MLPGAMFPQRConfig,
    MLPGAMNormalConfig,
    MLPGAMQRConfig,
)

# ── helpers ───────────────────────────────────────────────────────────────────


def _resolve(cfg):
    """Run _resolve_distribution and return the single resolved config."""
    return TwigaForecaster._resolve_distribution(cfg)[0]


# ── parametric distributions ─────────────────────────────────────────────────


@pytest.mark.parametrize(
    "arch_cls,dist,expected_cls",
    [
        (MLPFConfig, "normal", MLPFNormalConfig),
        (MLPGAMConfig, "normal", MLPGAMNormalConfig),
        (MLPGAFConfig, "normal", MLPGAFNormalConfig),
    ],
)
def test_parametric_resolution(arch_cls, dist, expected_cls):
    cfg = arch_cls(distribution=dist)
    resolved = _resolve(cfg)
    assert isinstance(resolved, expected_cls)


# ── QR distributions ─────────────────────────────────────────────────────────


@pytest.mark.parametrize(
    "arch_cls,expected_cls",
    [
        (MLPFConfig, MLPFQRConfig),
        (MLPGAMConfig, MLPGAMQRConfig),
        (MLPGAFConfig, MLPGAFQRConfig),
    ],
)
def test_qr_resolution(arch_cls, expected_cls):
    cfg = arch_cls(distribution="qr", max_epochs=3)
    resolved = _resolve(cfg)
    assert isinstance(resolved, expected_cls)
    assert resolved.max_epochs == 3


# ── FPQR: extra params forwarded ─────────────────────────────────────────────


@pytest.mark.parametrize(
    "arch_cls,expected_cls",
    [
        (MLPFConfig, MLPFFPQRConfig),
        (MLPGAMConfig, MLPGAMFPQRConfig),
        (MLPGAFConfig, MLPGAFFPQRConfig),
    ],
)
def test_fpqr_resolution_with_params(arch_cls, expected_cls):
    cfg = arch_cls(
        distribution="fpqr",
        n_quantiles=9,
        conf_level=0.05,
        max_epochs=5,
        rich_progress_bar=False,
    )
    resolved = _resolve(cfg)

    assert isinstance(resolved, expected_cls)
    assert resolved.n_quantiles == 9
    assert resolved.conf_level == 0.05
    assert resolved.max_epochs == 5
    assert resolved.rich_progress_bar is False


def test_fpqr_default_params_preserved():
    """Extra FPQR params not supplied should fall back to defaults."""
    cfg = MLPGAMConfig(distribution="fpqr")
    resolved = _resolve(cfg)

    assert isinstance(resolved, MLPGAMFPQRConfig)
    # n_quantiles default is 9
    assert resolved.n_quantiles == MLPGAMFPQRConfig(num_target_feature=0, forecast_horizon=0).n_quantiles


# ── no distribution set — pass-through ───────────────────────────────────────


def test_no_distribution_passthrough():
    cfg = MLPGAMConfig(max_epochs=10)
    resolved = _resolve(cfg)
    assert type(resolved) is MLPGAMConfig
    assert resolved.max_epochs == 10


# ── invalid distribution raises ──────────────────────────────────────────────


def test_invalid_distribution_raises():
    """Pydantic rejects unknown distribution values at config construction."""
    with pytest.raises(ValidationError):
        MLPFConfig(distribution="banana")


# ── list input ───────────────────────────────────────────────────────────────


def test_list_of_mixed_configs():
    configs = [
        MLPFConfig(distribution="qr"),
        MLPGAMConfig(distribution="fpqr", n_quantiles=7),
        MLPGAFConfig(distribution="normal"),
    ]
    resolved = TwigaForecaster._resolve_distribution(configs)
    assert isinstance(resolved[0], MLPFQRConfig)
    assert isinstance(resolved[1], MLPGAMFPQRConfig)
    assert resolved[1].n_quantiles == 7
    assert isinstance(resolved[2], MLPGAFNormalConfig)


# ── equivalence: unified API == direct instantiation ─────────────────────────


@pytest.mark.parametrize(
    "dist,n_quantiles,conf_level",
    [
        ("fpqr", 9, 0.05),
        ("fpqr", 15, 0.10),
        ("fpqr", 7, 0.20),
    ],
)
def test_unified_api_equiv_direct(dist, n_quantiles, conf_level):
    """MLPGAMConfig(distribution='fpqr', ...) == MLPGAMFPQRConfig(...)."""
    via_unified = _resolve(MLPGAMConfig(distribution=dist, n_quantiles=n_quantiles, conf_level=conf_level))
    direct = MLPGAMFPQRConfig(n_quantiles=n_quantiles, conf_level=conf_level)

    assert type(via_unified) is type(direct)
    assert via_unified.n_quantiles == direct.n_quantiles
    assert via_unified.conf_level == direct.conf_level
