from pathlib import Path
from unittest.mock import MagicMock, Mock, patch

import numpy as np
import pandas as pd
import pytest

from twiga.core.config import ConformalConfig, DataPipelineConfig, ForecasterConfig
from twiga.forecaster.core import TwigaForecaster
from twiga.models.ml.lightgbm_model import LIGHTGBMConfig


@pytest.fixture
def data_params():
    """Fixture for DataPipelineConfig."""
    return DataPipelineConfig(target_feature="sales", period="1h", forecast_horizon=24, lookback_window_size=24)


@pytest.fixture
def model_params():
    """Fixture for BaseModelConfig."""
    return LIGHTGBMConfig()


@pytest.fixture
def train_params():
    """Fixture for ForecasterConfig."""
    return ForecasterConfig(
        split_freq="months",
        test_size=1,
        train_size=1,
        gap=0,
        project_name="Tanesco",
        seed=42,
        root_dir="./tests",
        metrics=["mae", "rmse"],
    )


@pytest.fixture
def sample_data():
    """Fixture to create sample DataFrame for testing."""
    return pd.DataFrame(
        {
            "timestamp": pd.date_range(start="2020-01-01", periods=24 * 30 * 1, freq="h"),
            "sales": np.linspace(0, 1, 24 * 30 * 1),
        }
    )


def test_twiga_forecaster_init(data_params, model_params, train_params):
    """Test initialization of TwigaForecaster."""
    forecaster = TwigaForecaster(data_params, model_params, train_params)
    assert isinstance(forecaster, TwigaForecaster)
    assert forecaster.domain == "ml"
    assert forecaster.split_freq == "months"
    assert forecaster.project_name == "Tanesco"
    assert forecaster.metrics == ["mae", "rmse"]
    assert isinstance(forecaster.root_dir, Path)


def test_twiga_forecaster_init_with_list_model_params(data_params, model_params, train_params):
    """Test initialization with a list of model parameters."""
    model_params_list = [model_params, model_params.copy()]
    forecaster = TwigaForecaster(data_params, model_params_list, train_params)
    assert len(forecaster.models) == 2


def test_fit(data_params, model_params, train_params, sample_data):
    """Test fit method for multiple models."""
    forecaster = TwigaForecaster(data_params, [model_params], train_params)

    forecaster._fit = Mock()
    forecaster._create_folder = Mock()
    forecaster.fit(sample_data, train_ratio=0.8)

    assert forecaster._fit.called
    assert forecaster._create_folder.called
    assert forecaster.domain == "ml"


def test_format_keys_single(data_params, model_params, train_params):
    """Test _format_keys_single utility method."""
    forecaster = TwigaForecaster(data_params, model_params, train_params)
    input_dict = {"linear_time": 10, "linear_model": "x", "leng": 10}
    result = forecaster._format_keys_single(input_dict, "linear")
    expected = {"time": 10, "model": "x", "leng": 10}
    assert result == expected


# ---------------------------------------------------------------------------
# calibrate() — per-method argument routing
# ---------------------------------------------------------------------------


def _make_forecaster(data_params, model_params, train_params, method, score_type="res"):
    """Helper: build a TwigaForecaster with conformal_params pre-set."""
    forecaster = TwigaForecaster(data_params, model_params, train_params)
    forecaster.conformal_params = ConformalConfig(method=method, score_type=score_type, alpha=0.1)
    return forecaster


def _stub_forecaster(forecaster, forecast_value, ground_truth):
    """Stub prepare_test_data, get_ground_truth, and predict so calibrate() runs in isolation."""
    forecaster.prepare_test_data = Mock(return_value=MagicMock())
    forecaster.get_ground_truth = Mock(return_value=(None, ground_truth))
    forecaster.predict = Mock(return_value=({"lightgbm": forecast_value}, {}))


@pytest.fixture
def gt():
    return np.random.rand(20, 24, 1)


def test_calibrate_residual_plain_array(data_params, model_params, train_params, gt):
    """method='residual': plain ndarray forecast routes to SplitConformal(loc, targets)."""
    forecaster = _make_forecaster(data_params, model_params, train_params, method="residual")
    loc = np.random.rand(20, 24, 1)
    _stub_forecaster(forecaster, loc, gt)

    forecaster.calibrate(calibrate_df=MagicMock())

    assert "lightgbm" in forecaster.conformal
    assert hasattr(forecaster.conformal["lightgbm"], "q_hat")


def test_calibrate_residual_dict_forecast(data_params, model_params, train_params, gt):
    """method='residual': dict forecast extracts 'loc' before calling SplitConformal."""
    forecaster = _make_forecaster(data_params, model_params, train_params, method="residual")
    loc = np.random.rand(20, 24, 1)
    _stub_forecaster(forecaster, {"loc": loc}, gt)

    forecaster.calibrate(calibrate_df=MagicMock())

    assert hasattr(forecaster.conformal["lightgbm"], "q_hat")


def test_calibrate_quantile_method(data_params, model_params, train_params, gt):
    """method='quantile': (loc, quantiles_hat) tuple → lower/upper extracted correctly."""
    forecaster = _make_forecaster(data_params, model_params, train_params, method="quantile", score_type="unscaled")
    loc = np.random.rand(20, 24, 1)
    # 5 quantiles: bounds at index 0 and -1
    quantiles_hat = np.random.rand(20, 5, 24, 1)
    _stub_forecaster(forecaster, (loc, quantiles_hat), gt)

    forecaster.calibrate(calibrate_df=MagicMock())

    assert "lightgbm" in forecaster.conformal
    assert hasattr(forecaster.conformal["lightgbm"], "q_hat")


def test_calibrate_quantile_wrong_forecast_type(data_params, model_params, train_params, gt):
    """method='quantile' with a plain array forecast raises a clear ValueError."""
    forecaster = _make_forecaster(data_params, model_params, train_params, method="quantile", score_type="unscaled")
    _stub_forecaster(forecaster, np.random.rand(20, 24, 1), gt)

    with pytest.raises(ValueError, match="requires a QR model"):
        forecaster.calibrate(calibrate_df=MagicMock())


def test_calibrate_residual_fitting_dict(data_params, model_params, train_params, gt):
    """method='residual-fitting': dict forecast extracts loc + scale for ConformalResidualFitting."""
    forecaster = _make_forecaster(data_params, model_params, train_params, method="residual-fitting", score_type="res")
    loc = np.random.rand(20, 24, 1)
    scale = np.abs(np.random.rand(20, 24, 1)) + 1e-6
    _stub_forecaster(forecaster, {"loc": loc, "scale": scale}, gt)

    forecaster.calibrate(calibrate_df=MagicMock())

    assert "lightgbm" in forecaster.conformal
    assert hasattr(forecaster.conformal["lightgbm"], "q_hat")


def test_calibrate_residual_fitting_wrong_type(data_params, model_params, train_params, gt):
    """method='residual-fitting' with a plain array raises a clear ValueError."""
    forecaster = _make_forecaster(data_params, model_params, train_params, method="residual-fitting", score_type="res")
    _stub_forecaster(forecaster, np.random.rand(20, 24, 1), gt)

    with pytest.raises(ValueError, match="requires a model returning both loc and scale"):
        forecaster.calibrate(calibrate_df=MagicMock())


def test_calibrate_raises_without_conformal_params(data_params, model_params, train_params):
    """calibrate() raises ValueError when conformal_params is None."""
    forecaster = TwigaForecaster(data_params, model_params, train_params)
    assert forecaster.conformal_params is None

    with pytest.raises(ValueError, match="Conformal parameters are not set"):
        forecaster.calibrate(calibrate_df=MagicMock())


# ---------------------------------------------------------------------------
# _predict_core() — generate_intervals routing for ConformalQuantileRegressor
# ---------------------------------------------------------------------------


def _calibrated_qr_forecaster(data_params, model_params, train_params, gt):
    """Return a forecaster already calibrated with method='quantile'."""
    forecaster = _make_forecaster(data_params, model_params, train_params, method="quantile", score_type="unscaled")
    loc = np.random.default_rng(0).random((20, 24, 1))
    quantiles_hat = np.random.default_rng(1).random((20, 5, 24, 1))
    _stub_forecaster(forecaster, (loc, quantiles_hat), gt)
    forecaster.calibrate(calibrate_df=MagicMock())
    return forecaster, loc, quantiles_hat


def test_predict_core_quantile_generate_intervals(data_params, model_params, train_params, gt):
    """_predict_core with is_interval=True routes generate_intervals correctly for CQR."""
    forecaster, loc, quantiles_hat = _calibrated_qr_forecaster(data_params, model_params, train_params, gt)
    # Stub predict to return the same QR tuple for interval prediction
    forecaster.predict_interval = None  # ensure we call _predict_core directly

    # Simulate what _predict_core does: conformal model must accept (lower, upper)
    from twiga.distributions.conformal.cqr import ConformalQuantileRegressor

    conf_model = forecaster.conformal["lightgbm"]
    assert isinstance(conf_model, ConformalQuantileRegressor)

    q_lower = quantiles_hat[:, 0, :, :]
    q_upper = quantiles_hat[:, -1, :, :]
    lower_out, upper_out = conf_model.generate_intervals(q_lower, q_upper)

    assert lower_out.shape == q_lower.shape
    assert upper_out.shape == q_upper.shape
    assert np.all(upper_out >= lower_out)


def test_predict_core_quantile_wrong_forecast_raises(data_params, model_params, train_params, gt):
    """_predict_core raises ValueError if CQR conformal model gets a non-tuple forecast."""
    from twiga.distributions.conformal.cqr import ConformalQuantileRegressor
    from twiga.forecaster.abstract import AbstractForecaster

    forecaster, loc, quantiles_hat = _calibrated_qr_forecaster(data_params, model_params, train_params, gt)
    conf_model = forecaster.conformal["lightgbm"]
    assert isinstance(conf_model, ConformalQuantileRegressor)

    # Calling generate_intervals with only one arg should raise TypeError
    with pytest.raises(TypeError):
        conf_model.generate_intervals(loc)
