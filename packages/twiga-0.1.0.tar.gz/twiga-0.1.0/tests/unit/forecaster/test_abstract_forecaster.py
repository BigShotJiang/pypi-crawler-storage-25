from unittest.mock import Mock, patch

import numpy as np
import pandas as pd
import pytest

from twiga.core.config import BaseModelConfig
from twiga.forecaster.abstract import AbstractForecaster, EnsembleStrategy


@pytest.fixture
def forecaster():
    """Fixture to create a mock AbstractForecaster instance."""

    class TestForecaster(AbstractForecaster):
        def _fit(self, train_df, val_df, train_ratio):
            pass

        def _evaluate(self, test_df, covariate_df, time_stamp, ground_truth):
            pass

        def _tune(self, train_df, val_df, num_trials, reduction_factor, patience, load_if_exists):
            pass

        def _create_folder(self):
            pass

        def prepare_test_data(self, test_df):
            pass

        def get_ground_truth(self, test_df, **kwargs):
            pass

        def _backtester(self, data, train_ratio, start_dt, end_dt, verbose):
            pass

        def _predict(self, test_df, covariate_df):
            pass

        def split(self, data, start_dt, end_dt):
            """Mock split method to yield train/test splits for backtesting."""
            # Simulate one fold for backtesting
            train_df = data.iloc[:80].copy()
            test_df = data.iloc[80:].copy()
            scheme = {
                "train_period": (data["timestamp"].iloc[0], data["timestamp"].iloc[79]),
                "test_period": (data["timestamp"].iloc[80], data["timestamp"].iloc[-1]),
            }
            yield train_df, test_df, scheme, 0  # Single fold

    forecaster = TestForecaster()
    forecaster.models = []
    forecaster.data_pipeline = Mock(data_pipeline=None, target_feature=["sales"], date_column="timestamp")
    forecaster.metrics = ["mae", "rmse"]
    return forecaster


@pytest.fixture
def sample_data():
    """Fixture to create sample DataFrame with enough rows for testing."""
    dates = pd.date_range(start="2023-01-01", periods=100, freq="h")
    return pd.DataFrame(
        {"timestamp": dates, "sales": np.random.randn(len(dates)), "feature": np.random.randn(len(dates))}
    )


@pytest.fixture
def model_config():
    """Fixture to create a mock BaseModelConfig."""

    class MockConfig(BaseModelConfig):
        name: str = "xgboost"
        domain: str = "ml"
        learning_rate: float = 0.1

    return MockConfig()


@pytest.fixture
def model_dict():
    """Fixture to create a dictionary model configuration."""
    return {"name": "xgboost", "domain": "ml", "learning_rate": 0.1}


def test_get_model_from_registry_pydantic(forecaster, model_config, sample_data):
    """Test get_model_from_registry with Pydantic config."""
    mock_model_cls = Mock()
    mock_config_cls = Mock(return_value=model_config)
    with (
        patch("twiga.forecaster.abstract.get_model", return_value=(mock_model_cls, mock_config_cls)),
        patch("twiga.forecaster.abstract.isinstance", side_effect=lambda x, y: isinstance(x, BaseModelConfig | dict)),
    ):
        forecaster.get_model_from_registry([model_config])
        assert len(forecaster.models) == 1
        assert forecaster.models[0] == mock_model_cls.return_value
        mock_model_cls.assert_called_with(model_config)


def test_fit(forecaster, sample_data):
    """Test fit method iterating over models."""
    forecaster.models = [
        Mock(model_config=Mock(name="xgboost", domain="ml")),
        Mock(model_config=Mock(name="lstm", domain="dl")),
    ]
    forecaster._fit = Mock()
    forecaster._create_folder = Mock()
    forecaster.data_pipeline.fit = Mock()

    forecaster.fit(sample_data, train_ratio=0.8)
    assert forecaster._create_folder.call_count == 2
    assert forecaster._fit.call_count == 2
    assert forecaster.model == forecaster.models[1]  # Last model
    assert forecaster.domain == "dl"


def test_predict_core_point(forecaster, sample_data):
    """Test _predict_core for point forecasts."""
    forecaster.models = [Mock(model_config=Mock(name="xgboost", domain="ml"))]
    forecaster._predict = Mock(return_value=np.random.randn(10, 24, 1))
    forecaster.prepare_test_data = Mock(return_value=sample_data)
    forecaster.test_walltime = 1.0

    pred_dict, test_times = forecaster._predict_core(sample_data, prepare_test_data=True, is_interval=False)
    forecaster._predict.assert_called_once_with(sample_data, None)
    forecaster.prepare_test_data.assert_called_once_with(sample_data)


def test_predict_core_ensemble(forecaster, sample_data):
    """Test _predict_core with ensemble strategy."""
    forecaster.models = [
        Mock(model_config=Mock(name="xgboost", domain="ml")),
        Mock(model_config=Mock(name="lstm", domain="dl")),
    ]
    forecaster._predict = Mock(side_effect=[np.random.randn(10, 24, 1), np.random.randn(10, 24, 1)])
    forecaster.prepare_test_data = Mock(return_value=sample_data)
    forecaster.test_walltime = 1.0

    with patch(
        "twiga.forecaster.abstract.compute_ensemble_predictions", return_value=np.random.randn(10, 24, 1)
    ) as mock_ensemble:
        pred_dict, test_times = forecaster._predict_core(
            sample_data, ensemble_strategy="mean", prepare_test_data=True, is_interval=False
        )
        assert pred_dict["Ensemble"].shape == (10, 24, 1)
        assert test_times["Ensemble"] == 1.0
        assert mock_ensemble.call_count == 1


def test_predict_core_no_models(forecaster, sample_data):
    """Test _predict_core with no models."""
    with pytest.raises(ValueError, match="No models available for prediction"):
        forecaster._predict_core(sample_data)


def test_predict_core_missing_conformal(forecaster, sample_data):
    """Test _predict_core with missing conformal params for interval forecast."""
    forecaster.models = [Mock(model_config=Mock(name="xgboost", domain="ml"))]
    forecaster._predict = Mock(return_value=np.random.randn(10, 24, 1))
    forecaster.conformal_params = None
    with pytest.raises(ValueError, match="Conformal parameters are not set"):
        forecaster._predict_core(sample_data, is_interval=True)


def test_get_ensemble_predictions_point(forecaster):
    """Test _get_ensemble_predictions for point forecasts."""
    predictions = [np.random.randn(10, 24, 1), np.random.randn(10, 24, 1)]
    model_names = ["xgboost", "lstm"]
    ensemble_strategy = EnsembleStrategy.MEAN
    with patch(
        "twiga.forecaster.abstract.compute_ensemble_predictions", return_value=np.random.randn(10, 24, 1)
    ) as mock_ensemble:
        result = forecaster._get_ensemble_predictions(
            predictions, model_names, ensemble_strategy, None, is_interval=False
        )
        assert result.shape == (10, 24, 1)
        mock_ensemble.assert_called_once_with(predictions, model_names, ensemble_strategy, None)


def test_get_ensemble_predictions_interval(forecaster):
    """Test _get_ensemble_predictions for interval forecasts."""
    predictions = [
        (np.random.randn(10, 24, 1), np.random.randn(10, 24, 1), np.random.randn(10, 24, 1)),
        (np.random.randn(10, 24, 1), np.random.randn(10, 24, 1), np.random.randn(10, 24, 1)),
    ]
    model_names = ["xgboost", "lstm"]
    ensemble_strategy = EnsembleStrategy.MEAN
    with patch(
        "twiga.forecaster.abstract.compute_ensemble_predictions",
        side_effect=[np.random.randn(10, 24, 1), np.random.randn(10, 24, 1), np.random.randn(10, 24, 1)],
    ) as mock_ensemble:
        lower, point, upper = forecaster._get_ensemble_predictions(
            predictions, model_names, ensemble_strategy, None, is_interval=True
        )
        assert lower.shape == (10, 24, 1)
        assert point.shape == (10, 24, 1)
        assert upper.shape == (10, 24, 1)
        assert mock_ensemble.call_count == 3


def test_predict(forecaster, sample_data):
    """Test predict method for point forecasts."""
    forecaster._predict_core = Mock(return_value=({"xgboost": np.random.randn(10, 24, 1)}, {"xgboost": 1.0}))
    pred_dict, test_times = forecaster.predict(sample_data)
    assert "xgboost" in pred_dict
    assert pred_dict["xgboost"].shape == (10, 24, 1)
    assert test_times == {"xgboost": 1.0}
    forecaster._predict_core.assert_called_once_with(
        test_df=sample_data,
        covariate_df=None,
        ensemble_strategy=None,
        ensemble_weights=None,
        prepare_test_data=True,
        is_interval=False,
    )


def test_predict_interval(forecaster, sample_data):
    """Test predict_interval method for interval forecasts."""
    forecaster._predict_core = Mock(
        return_value=(
            {"xgboost": (np.random.randn(10, 24, 1), np.random.randn(10, 24, 1), np.random.randn(10, 24, 1))},
            {"xgboost": 1.0},
        )
    )
    pred_dict, test_times = forecaster.predict_interval(sample_data)
    assert "xgboost" in pred_dict
    lower, point, upper = pred_dict["xgboost"]
    assert lower.shape == (10, 24, 1)
    assert point.shape == (10, 24, 1)
    assert upper.shape == (10, 24, 1)
    assert test_times == {"xgboost": 1.0}
    forecaster._predict_core.assert_called_once_with(
        test_df=sample_data,
        covariate_df=None,
        ensemble_strategy=None,
        ensemble_weights=None,
        prepare_test_data=True,
        is_interval=True,
    )


def test_evaluate_core_point(forecaster, sample_data):
    """Test _evaluate_core for point forecasts."""
    timestamps = np.zeros((2, 3, 1), dtype="datetime64[ns]")
    ground_truth = np.random.randn(2, 3, 1)
    forecaster.prepare_test_data = Mock(return_value=sample_data)
    forecaster.get_ground_truth = Mock(return_value=(timestamps, ground_truth))
    forecaster._predict_core = Mock(return_value=({"xgboost": np.random.randn(2, 3, 1)}, {"xgboost": 1.0}))

    mock_result = Mock()
    mock_result.kind.value = "point"
    mock_result.evaluate.return_value = pd.DataFrame({"MetricName": ["MAE"], "Value": [0.1], "target": ["sales"]})
    mock_result.loc = np.random.randn(2, 3, 1)
    mock_result.lower = None
    mock_result.upper = None

    mock_results_df = pd.DataFrame({"sales": [1.0, 2.0]})

    with (
        patch("twiga.forecaster.abstract.build_forecast_result", return_value=mock_result),
        patch("twiga.forecaster.abstract.build_ground_truth_df", return_value=pd.DataFrame()),
        patch("twiga.forecaster.abstract.merge_and_format_results", return_value=mock_results_df),
    ):
        results_df, metrics_df = forecaster._evaluate_core(
            expected_kind="point",
            test_df=sample_data,
            covariate_df=None,
            ensemble_strategy=None,
            ensemble_weights=None,
        )
        assert isinstance(results_df, pd.DataFrame)
        assert isinstance(metrics_df, pd.DataFrame)
        assert metrics_df["Model"].iloc[0] == "XGBOOST"


def test_evaluate_core_interval(forecaster, sample_data):
    """Test _evaluate_core for interval forecasts includes lower/upper columns."""
    timestamps = np.zeros((2, 3, 1), dtype="datetime64[ns]")
    ground_truth = np.random.randn(2, 3, 1)
    forecaster.prepare_test_data = Mock(return_value=sample_data)
    forecaster.get_ground_truth = Mock(return_value=(timestamps, ground_truth))
    forecaster._predict_core = Mock(
        return_value=(
            {"xgboost": (np.random.randn(2, 3, 1), np.random.randn(2, 3, 1), np.random.randn(2, 3, 1))},
            {"xgboost": 1.0},
        )
    )

    mock_result = Mock()
    mock_result.kind.value = "interval"
    mock_result.evaluate.return_value = pd.DataFrame({"MetricName": ["Coverage"], "Value": [0.9], "target": ["sales"]})
    mock_result.loc = np.random.randn(2, 3, 1)
    mock_result.lower = np.random.randn(2, 3, 1)
    mock_result.upper = np.random.randn(2, 3, 1)

    mock_results_df = pd.DataFrame({"sales": [1.0]})

    with (
        patch("twiga.forecaster.abstract.build_forecast_result", return_value=mock_result),
        patch("twiga.forecaster.abstract.build_ground_truth_df", return_value=pd.DataFrame()),
        patch("twiga.forecaster.abstract.merge_and_format_results", return_value=mock_results_df),
    ):
        results_df, metrics_df = forecaster._evaluate_core(
            expected_kind="interval",
            test_df=sample_data,
            covariate_df=None,
            ensemble_strategy=None,
            ensemble_weights=None,
            is_interval=True,
        )
        assert isinstance(results_df, pd.DataFrame)
        assert isinstance(metrics_df, pd.DataFrame)


def test_evaluate_point_forecast(forecaster, sample_data):
    """Test evaluate_point_forecast delegates to _evaluate_core."""
    mock_results_df = pd.DataFrame({"sales": [1.0]})
    mock_metrics_df = pd.DataFrame({"Model": ["XGBOOST"], "mae": [0.1]})
    forecaster._evaluate_core = Mock(return_value=(mock_results_df, mock_metrics_df))

    results_df, metrics_df = forecaster.evaluate_point_forecast(sample_data)
    assert isinstance(results_df, pd.DataFrame)
    assert isinstance(metrics_df, pd.DataFrame)
    forecaster._evaluate_core.assert_called_once_with(
        expected_kind="point",
        test_df=sample_data,
        covariate_df=None,
        ensemble_strategy=None,
        ensemble_weights=None,
    )


def test_evaluate_interval_forecast(forecaster, sample_data):
    """Test evaluate_interval_forecast delegates to _evaluate_core."""
    mock_results_df = pd.DataFrame({"sales": [1.0]})
    mock_metrics_df = pd.DataFrame({"Model": ["XGBOOST"], "mae": [0.1]})
    forecaster._evaluate_core = Mock(return_value=(mock_results_df, mock_metrics_df))

    results_df, metrics_df = forecaster.evaluate_interval_forecast(sample_data)
    assert isinstance(results_df, pd.DataFrame)
    assert isinstance(metrics_df, pd.DataFrame)
    forecaster._evaluate_core.assert_called_once_with(
        expected_kind="interval",
        test_df=sample_data,
        covariate_df=None,
        ensemble_strategy=None,
        ensemble_weights=None,
        is_interval=True,
    )


def test_backtesting(forecaster, sample_data):
    """Test backtesting method iterating over models."""
    forecaster.models = [
        Mock(model_config=Mock(name="xgboost", domain="ml")),
        Mock(model_config=Mock(name="lstm", domain="dl")),
    ]
    # Mock predictions and metrics to match evaluate_point_forecast output
    mock_predictions = pd.DataFrame(
        {"timestamp": sample_data["timestamp"][80:90], "sales_forecast": sample_data["sales"][80:90] + 0.5, "Folds": 1}
    )
    mock_metrics = pd.DataFrame(
        {"Model": ["xgboost", "lstm"], "mae": [0.1, 0.15], "rmse": [0.2, 0.25], "Folds": [1, 1]}
    )
    forecaster._create_folder = Mock()
    forecaster.fit = Mock()
    forecaster.evaluate_point_forecast = Mock(return_value=(mock_predictions, mock_metrics))

    # Mock logger to avoid issues with logging calls
    with patch("twiga.forecaster.abstract.log") as mock_logger:
        predictions, metrics = forecaster.backtesting(sample_data, train_ratio=0.8, verbose=True)

    assert isinstance(predictions, pd.DataFrame)
    assert isinstance(metrics, pd.DataFrame)
    assert len(predictions) == 10  # One fold, 10 rows from mock_predictions
    assert len(metrics) == 2  # One fold, two models
    # assert forecaster._create_folder.call_count == 1  # One fold

    assert mock_logger.info.call_count == 3  # Three log messages per fold


def test_backtesting_no_models(forecaster, sample_data):
    """Test backtesting with no models."""
    with pytest.raises(ValueError, match="No models available for backtesting"):
        forecaster.backtesting(sample_data)


def test_format_keys_single(forecaster):
    """Test _format_keys_single for dictionary key formatting."""
    input_dict = {"xgboost_time": 10, "xgboost_model": "x", "length": 5}
    result = forecaster._format_keys_single(input_dict, "xgboost")
    expected = {"time": 10, "model": "x", "length": 5}
    assert result == expected
