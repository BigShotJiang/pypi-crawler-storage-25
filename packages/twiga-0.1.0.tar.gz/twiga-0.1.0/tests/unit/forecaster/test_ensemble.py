from enum import Enum, StrEnum

import numpy as np
import pytest

from twiga.forecaster.ensemble import EnsembleStrategy, compute_ensemble_predictions  # Replace with actual module name


@pytest.fixture
def sample_predictions():
    """Provide sample predictions for testing ensemble strategies.

    Returns:
        List of three 3D NumPy arrays, each with shape (2, 3, 2), representing
        predictions from three models with values 1.0, 2.0, and 3.0 respectively.
    """
    shape = (2, 3, 2)
    pred1 = np.ones(shape) * 1.0
    pred2 = np.ones(shape) * 2.0
    pred3 = np.ones(shape) * 3.0
    return [pred1, pred2, pred3]


@pytest.fixture
def model_names():
    """Provide sample model names for testing.

    Returns:
        List of three model names: ["model1", "model2", "model3"].
    """
    return ["model1", "model2", "model3"]


def test_mean_strategy(sample_predictions, model_names):
    """Test the MEAN ensemble strategy.

    Verifies that compute_ensemble_predictions correctly computes the mean of
    multiple model predictions when using EnsembleStrategy.MEAN.

    Args:
        sample_predictions: Fixture providing sample predictions.
        model_names: Fixture providing sample model names.
    """
    result = compute_ensemble_predictions(
        predictions=sample_predictions, model_names=model_names, ensemble_strategy=EnsembleStrategy.MEAN
    )
    expected = np.ones((2, 3, 2)) * 2.0
    np.testing.assert_array_almost_equal(result, expected)


def test_median_strategy(sample_predictions, model_names):
    """Test the MEDIAN ensemble strategy.

    Verifies that compute_ensemble_predictions correctly computes the median of
    multiple model predictions when using EnsembleStrategy.MEDIAN.

    Args:
        sample_predictions: Fixture providing sample predictions.
        model_names: Fixture providing sample model names.
    """
    result = compute_ensemble_predictions(
        predictions=sample_predictions, model_names=model_names, ensemble_strategy=EnsembleStrategy.MEDIAN
    )
    expected = np.ones((2, 3, 2)) * 2.0
    np.testing.assert_array_almost_equal(result, expected)


def test_weighted_strategy(sample_predictions, model_names):
    """Test the WEIGHTED ensemble chopping strategy with valid weights.

    Verifies that compute_ensemble_predictions correctly computes the weighted sum
    of predictions when using EnsembleStrategy.WEIGHTED with valid weights.

    Args:
        sample_predictions: Fixture providing sample predictions.
        model_names: Fixture providing sample model names.
    """
    weights = {"model1": 0.5, "model2": 0.3, "model3": 0.2}
    result = compute_ensemble_predictions(
        predictions=sample_predictions,
        model_names=model_names,
        ensemble_strategy=EnsembleStrategy.WEIGHTED,
        ensemble_weights=weights,
    )
    expected = np.ones((2, 3, 2)) * 1.7
    np.testing.assert_array_almost_equal(result, expected)


def test_single_prediction(model_names):
    """Test ensemble with a single prediction.

    Verifies that compute_ensemble_predictions works correctly with a single
    prediction, returning the prediction unchanged for EnsembleStrategy.MEAN.

    Args:
        model_names: Fixture providing sample model names.
    """
    pred = [np.ones((2, 3, 2))]

    result = compute_ensemble_predictions(
        predictions=pred, model_names=["model1"], ensemble_strategy=EnsembleStrategy.MEAN
    )
    expected = np.ones((2, 3, 2))
    np.testing.assert_array_almost_equal(result, expected)


def test_empty_predictions():
    """Test handling of empty predictions.

    Verifies that compute_ensemble_predictions raises a ValueError when given an
    empty list of predictions.
    """
    with pytest.raises(ValueError, match="At least one prediction is required"):
        compute_ensemble_predictions(predictions=[], model_names=[], ensemble_strategy=EnsembleStrategy.MEAN)


def test_inconsistent_shapes(model_names):
    """Test handling of inconsistent prediction shapes.

    Verifies that compute_ensemble_predictions raises a ValueError when predictions
    have inconsistent shapes.

    Args:
        model_names: Fixture providing sample model names.
    """
    pred1 = np.ones((2, 3, 2))
    pred2 = np.ones((2, 3, 1))
    with pytest.raises(ValueError, match="Inconsistent prediction shapes"):
        compute_ensemble_predictions(
            predictions=[pred1, pred2], model_names=model_names[:2], ensemble_strategy=EnsembleStrategy.MEAN
        )


def test_weighted_no_weights(sample_predictions, model_names):
    """Test WEIGHTED strategy without weights.

    Verifies that compute_ensemble_predictions raises a ValueError when
    EnsembleStrategy.WEIGHTED is used without providing weights.

    Args:
        sample_predictions: Fixture providing sample predictions.
        model_names: Fixture providing sample model names.
    """
    with pytest.raises(ValueError, match="Weights required for weighted ensemble strategy"):
        compute_ensemble_predictions(
            predictions=sample_predictions, model_names=model_names, ensemble_strategy=EnsembleStrategy.WEIGHTED
        )


def test_weighted_mismatched_weights(sample_predictions, model_names):
    """Test WEIGHTED strategy with partial weights.

    Verifies that compute_ensemble_predictions handles missing weights by assigning
    zero to unspecified models and computes the correct weighted sum.

    Args:
        sample_predictions: Fixture providing sample predictions.
        model_names: Fixture providing sample model names.
    """
    weights = {"model1": 0.5, "model2": 0.5}
    result = compute_ensemble_predictions(
        predictions=sample_predictions,
        model_names=model_names,
        ensemble_strategy=EnsembleStrategy.WEIGHTED,
        ensemble_weights=weights,
    )
    expected = np.ones((2, 3, 2)) * 1.5
    np.testing.assert_array_almost_equal(result, expected)


def test_invalid_strategy(sample_predictions, model_names):
    """Test handling of an invalid ensemble strategy.

    Verifies that compute_ensemble_predictions raises a ValueError when an unknown
    ensemble strategy is provided.

    Args:
        sample_predictions: Fixture providing sample predictions.
        model_names: Fixture providing sample model names.
    """

    class InvalidStrategy(StrEnum):
        INVALID = "invalid"

    with pytest.raises(ValueError, match="Unknown ensemble strategy"):
        compute_ensemble_predictions(
            predictions=sample_predictions, model_names=model_names, ensemble_strategy=InvalidStrategy.INVALID
        )


def test_weighted_strategy_unnormalized_weights(sample_predictions, model_names):
    """Test WEIGHTED strategy raises ValueError when weights don't sum to 1.

    Args:
        sample_predictions: Fixture providing sample predictions.
        model_names: Fixture providing sample model names.
    """
    weights = {"model1": 5.0, "model2": 3.0, "model3": 2.0}
    with pytest.raises(ValueError, match="must sum to 1.0"):
        compute_ensemble_predictions(
            predictions=sample_predictions,
            model_names=model_names,
            ensemble_strategy=EnsembleStrategy.WEIGHTED,
            ensemble_weights=weights,
        )


def test_weighted_strategy_normalized_weights(sample_predictions, model_names):
    """Test WEIGHTED strategy with weights that sum to 1.

    Verifies that compute_ensemble_predictions correctly computes the weighted sum.

    Args:
        sample_predictions: Fixture providing sample predictions.
        model_names: Fixture providing sample model names.
    """
    weights = {"model1": 0.5, "model2": 0.3, "model3": 0.2}
    result = compute_ensemble_predictions(
        predictions=sample_predictions,
        model_names=model_names,
        ensemble_strategy=EnsembleStrategy.WEIGHTED,
        ensemble_weights=weights,
    )
    expected = np.ones((2, 3, 2)) * 1.7
    np.testing.assert_array_almost_equal(result, expected)


def test_weighted_ensemble_weights_mismatch(sample_predictions):
    """Raises ValueError when number of model_names doesn't match number of predictions."""
    # 5 model names but only 3 predictions → weights array length mismatch
    extra_names = ["model1", "model2", "model3", "model4", "model5"]
    weights = dict.fromkeys(extra_names, 1.0)
    with pytest.raises(ValueError, match="Number of weights must match"):
        compute_ensemble_predictions(
            predictions=sample_predictions,
            model_names=extra_names,
            ensemble_strategy=EnsembleStrategy.WEIGHTED,
            ensemble_weights=weights,
        )
