from unittest.mock import Mock, patch

import pytest

from twiga.forecaster.registry import get_model, get_model_from_dict


@pytest.fixture
def mock_model_module():
    """Fixture to create a mock module with model and config classes."""
    module = Mock()
    module.LINEARModel = Mock()
    module.LINEARConfig = Mock()
    return module


@pytest.fixture
def mock_config_dict():
    """Fixture for a sample configuration dictionary."""
    return {"name": "linear", "param1": "value1", "domain": "ml"}


def test_get_model_success_ml(mock_model_module):
    """Test get_model successfully loads a model from the 'ml' domain."""
    with patch("importlib.import_module", return_value=mock_model_module) as mock_import:
        model_cls, config_cls = get_model("linear", domain="ml")

    assert model_cls == mock_model_module.LINEARModel
    assert config_cls == mock_model_module.LINEARConfig
    mock_import.assert_called_once_with("twiga.models.ml.linear_model")
    # Verify caching
    assert "linear" in get_model.__globals__["_model_cache"]
    assert get_model.__globals__["_model_cache"]["linear"]["model"] == model_cls


def test_get_model_cached(mock_model_module):
    """Test get_model uses cache for subsequent calls."""
    with patch("importlib.import_module", return_value=mock_model_module):
        model_cls, config_cls = get_model("linear", domain="ml")
        # Call again to test cache
        with patch("importlib.import_module") as mock_import:
            cached_model_cls, cached_config_cls = get_model("linear", domain="ml")

    assert model_cls == cached_model_cls
    assert config_cls == cached_config_cls
    mock_import.assert_not_called()


def test_get_model_from_dict_success(mock_model_module, mock_config_dict):
    """Test get_model_from_dict successfully creates a model instance."""
    mock_config_instance = Mock()
    mock_model_instance = Mock()
    mock_config_cls = Mock(return_value=mock_config_instance)
    mock_model_cls = Mock(return_value=mock_model_instance)

    with patch("twiga.forecaster.registry.get_model", return_value=(mock_model_cls, mock_config_cls)):
        model_cls, config_cls = get_model_from_dict(mock_config_dict, domain="ml")

    mock_config_cls.assert_called_once_with(**mock_config_dict)
    assert model_cls == mock_model_cls
    assert config_cls == mock_config_instance


def test_get_model_from_dict_missing_name(mock_config_dict):
    """Test get_model_from_dict raises ValueError for missing name."""
    mock_config_dict.pop("name")
    with pytest.raises(ValueError, match="Model name must be provided"):
        get_model_from_dict(mock_config_dict, domain="ml")


def test_get_model_from_dict_invalid_config(mock_config_dict):
    """Test get_model_from_dict handles invalid config validation."""
    mock_config_cls = Mock(side_effect=ValueError("Invalid config"))
    with (
        patch("twiga.forecaster.registry.get_model", return_value=(Mock(), mock_config_cls)),
        pytest.raises(ValueError, match="Invalid config"),
    ):
        get_model_from_dict(mock_config_dict, domain="ml")


def test_get_model_from_dict_no_domain(mock_model_module, mock_config_dict):
    """Test get_model_from_dict without specifying domain."""
    mock_config_instance = Mock()
    mock_model_instance = Mock()
    mock_config_cls = Mock(return_value=mock_config_instance)
    mock_model_cls = Mock(return_value=mock_model_instance)

    with patch("twiga.forecaster.registry.get_model", return_value=(mock_model_cls, mock_config_cls)):
        model_cls, config_cls = get_model_from_dict(mock_config_dict)

    mock_config_cls.assert_called_once_with(**mock_config_dict)
    assert model_cls == mock_model_cls
    assert config_cls == mock_config_instance
