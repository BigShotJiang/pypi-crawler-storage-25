from pathlib import Path
from unittest.mock import Mock, patch

import numpy as np
import optuna
import pandas as pd
import pytest

from twiga.forecaster.base import BaseForecaster


@pytest.fixture
def forecaster():
    """Fixture to create a BaseForecaster instance with default parameters."""
    return BaseForecaster(
        split_freq="months",
        test_size=1,
        train_size=1,
        gap=0,
        domain="ml",
        project_name="Tanesco",
        seed=42,
        root_dir="./tests",
        metrics=["mae", "rmse"],
    )


@pytest.fixture
def sample_data():
    """Fixture to create sample DataFrame with enough rows for testing."""
    dates = pd.date_range(start="2023-01-01", periods=100, freq="h")
    return pd.DataFrame(
        {"timestamp": dates, "sales": np.random.randn(len(dates)), "feature": np.random.randn(len(dates))}
    )


@pytest.fixture
def data_pipeline():
    """Fixture to create a mock data pipeline."""
    pipeline = Mock()
    pipeline.data_pipeline = Mock(named_steps={"scaling": Mock(named_transformers_={"target_scaling": Mock()})})
    pipeline.date_column = "timestamp"
    pipeline.target_feature = ["sales"]
    pipeline.max_data_drop = 2
    pipeline.lookback_window_size = 24
    pipeline.forecast_horizon = 24
    pipeline.transform = Mock(return_value=(np.random.randn(96, 3), np.random.randn(96, 1)))
    pipeline.transform_features = Mock(return_value=np.random.randn(96, 3))
    pipeline.fit = Mock()
    return pipeline


def test_init(forecaster):
    """Test initialization of BaseForecaster."""
    assert forecaster.split_freq == "months"
    assert forecaster.test_size == 1
    assert forecaster.train_size == 1
    assert forecaster.project_name == "Tanesco"
    assert forecaster.seed == 42
    assert forecaster.metrics == ["mae", "rmse"]
    assert isinstance(forecaster.root_dir, Path)


def test_create_folder(forecaster, tmp_path):
    """Test folder creation for experiment artifacts."""
    forecaster.root_dir = tmp_path
    forecaster.model_type = "test_model"
    forecaster._create_folder()

    expected_paths = [
        tmp_path / "results" / "Tanesco" / "test_model",
        tmp_path / "logs" / "Tanesco" / "test_model",
        tmp_path / "figures" / "Tanesco" / "test_model",
        tmp_path / "checkpoints" / "Tanesco" / "test_model",
    ]
    for path in expected_paths:
        assert path.exists()


def test_create_folder_missing_attributes(forecaster):
    """Test folder creation with missing required attributes."""
    forecaster.model_type = None
    with pytest.raises(RuntimeError, match="Missing required directory configuration attributes"):
        forecaster._create_folder()


def test_create_folder_permission_error(forecaster, tmp_path):
    """Test folder creation with permission error."""
    forecaster.root_dir = tmp_path
    forecaster.model_type = "test_model"
    with patch("pathlib.Path.mkdir", side_effect=PermissionError), pytest.raises(PermissionError):
        forecaster._create_folder()


def test_on_save_checkpoint_ml(forecaster, tmp_path):
    """Test saving checkpoint for ML domain."""
    forecaster.domain = "ml"
    forecaster.checkpoints_path = tmp_path / "checkpoints"
    forecaster.checkpoints_path.mkdir()
    forecaster.model = Mock()
    forecaster.data_pipeline = Mock()

    with patch("joblib.dump") as mock_dump:
        forecaster.on_save_checkpoint()
        mock_dump.assert_called_once_with(
            {"model": forecaster.model, "data_pipeline": forecaster.data_pipeline},
            forecaster.checkpoints_path / "model_and_pipeline.pkl",
        )


def test_on_load_checkpoint_ml(forecaster, tmp_path):
    """Test loading checkpoint for ML domain."""
    forecaster.domain = "ml"
    forecaster.checkpoints_path = tmp_path / "checkpoints"
    forecaster.checkpoints_path.mkdir()
    checkpoint_file = forecaster.checkpoints_path / "model_and_pipeline.pkl"
    checkpoint_file.touch()

    mock_data = {"model": Mock(), "data_pipeline": Mock()}
    with (
        patch("joblib.load", return_value=mock_data) as mock_load,
        patch("pathlib.Path.glob", return_value=[checkpoint_file]),
    ):
        forecaster.on_load_checkpoint()
        mock_load.assert_called_once_with(checkpoint_file)
        assert forecaster.model == mock_data["model"]
        assert forecaster.data_pipeline == mock_data["data_pipeline"]


def test_load_and_prepare_data(forecaster, sample_data, data_pipeline):
    """Test loading and preparing data for evaluation."""
    forecaster.data_pipeline = data_pipeline
    forecaster.train_df = sample_data.copy()
    forecaster.on_load_checkpoint = Mock()

    forecaster.load_checkpoint_and_datapipe()
    forecaster.on_load_checkpoint.assert_called_once()


def test_prepare_features(forecaster, sample_data, data_pipeline):
    """Test feature preparation for training and validation."""
    forecaster.data_pipeline = data_pipeline
    forecaster.model = Mock()
    forecaster.train_df = sample_data.copy()

    with patch.object(
        data_pipeline,
        "transform",
        side_effect=[
            (np.random.randn(80, 3), np.random.randn(80, 1)),  # Train split
            (np.random.randn(20, 3), np.random.randn(20, 1)),  # Val split
        ],
    ) as mock_transform:
        train_features, train_target, val_features, val_target = forecaster._prepare_features(
            sample_data, train_ratio=0.8
        )
        assert train_features.shape == (80, 3)
        assert train_target.shape == (80, 1)
        assert val_features.shape == (20, 3)
        assert val_target.shape == (20, 1)
        assert mock_transform.call_count == 2


def test_prepare_features_no_pipeline(forecaster, sample_data):
    """Test prepare_features with uninitialized pipeline."""
    forecaster.model = Mock()
    forecaster.data_pipeline = Mock(data_pipeline=None)
    with pytest.raises(ValueError, match="Data pipeline not initialized"):
        forecaster._prepare_features(sample_data)


def test_apply_temporal_filtering(forecaster, sample_data, data_pipeline):
    """Test temporal filtering of training data."""
    forecaster.data_pipeline = data_pipeline
    forecaster.train_df = sample_data.copy()

    forecaster._apply_temporal_filtering()
    expected_length = min(len(sample_data), data_pipeline.max_data_drop + data_pipeline.lookback_window_size)
    assert len(forecaster.train_df) == expected_length
    assert forecaster.train_df["timestamp"].is_monotonic_increasing


def test_apply_temporal_filtering_insufficient_data(forecaster, sample_data, data_pipeline):
    """Test temporal filtering with insufficient data."""
    forecaster.data_pipeline = data_pipeline
    forecaster.train_df = sample_data.iloc[:5].copy()  # Less than required
    with pytest.raises(ValueError, match="Not enough data to train the model"):
        forecaster._apply_temporal_filtering()


def test_fit_ml(forecaster, sample_data, data_pipeline):
    """Test fitting the model for ML domain."""
    forecaster.domain = "ml"
    forecaster.data_pipeline = data_pipeline
    forecaster.model = Mock()
    forecaster._create_folder = Mock()
    forecaster.on_save_checkpoint = Mock()

    with patch.object(
        forecaster, "_prepare_features", return_value=(np.random.randn(100, 3), np.random.randn(100, 1), None, None)
    ):
        wall_time = forecaster._fit(sample_data)
        forecaster.model.fit.assert_called_once()
        assert isinstance(wall_time, float)
        forecaster.on_save_checkpoint.assert_called_once()


def test_fit_ml_with_val_df(forecaster, sample_data, data_pipeline):
    """Test fitting the model with a validation DataFrame."""
    forecaster.domain = "ml"
    forecaster.data_pipeline = data_pipeline
    forecaster.model = Mock()
    forecaster._create_folder = Mock()
    forecaster.on_save_checkpoint = Mock()

    val_df = sample_data.iloc[-20:].copy()
    with patch.object(
        forecaster, "_prepare_features", return_value=(np.random.randn(100, 3), np.random.randn(100, 1), None, None)
    ):
        wall_time = forecaster._fit(sample_data, val_df=val_df)
        forecaster.model.fit.assert_called_once()
        assert isinstance(wall_time, float)
        forecaster.on_save_checkpoint.assert_called_once()


def test_objective_fn(forecaster, sample_data, data_pipeline):
    """Test objective function for hyperparameter tuning."""
    forecaster.data_pipeline = data_pipeline
    forecaster.model = Mock()
    forecaster.model.model.parameters.return_value = []
    mock_trial = Mock()
    forecaster._fit = Mock(return_value=1.0)
    forecaster._evaluate = Mock(
        return_value=(pd.DataFrame(), pd.DataFrame({"mae": [0.15], "rmse": [0.2], "Model": ["test_model"]}))
    )

    cost = forecaster._objective_fn(mock_trial, sample_data, sample_data)
    assert cost == 0.15  # Single MAE value
    forecaster.model.update.assert_called_once_with(mock_trial)
    forecaster._fit.assert_called_once_with(sample_data, sample_data, trial=mock_trial)
    forecaster._evaluate.assert_called_once_with(sample_data)


def test_create_optuna_study(forecaster, tmp_path):
    """Test creation of Optuna study for hyperparameter optimization."""
    forecaster.logs_path = tmp_path
    forecaster.model_type = "test_model"
    study = forecaster.create_optuna_study(num_trials=10, reduction_factor=3, patience=2)
    assert isinstance(study, optuna.Study)
    assert study.study_name == "Tanesco_test_model"
    assert isinstance(study.pruner, optuna.pruners.HyperbandPruner)
    assert isinstance(study.sampler, optuna.samplers.TPESampler)


def test_tune(forecaster, sample_data, data_pipeline, tmp_path):
    """Test hyperparameter tuning with Optuna."""
    forecaster.data_pipeline = data_pipeline
    forecaster.model = Mock()
    forecaster.results_path = tmp_path / "results"
    forecaster.results_path.mkdir(parents=True, exist_ok=True)

    with patch.object(forecaster, "create_optuna_study", return_value=Mock(spec=optuna.Study)) as mock_study:
        mock_study.return_value.optimize = Mock()
        mock_study.return_value.best_trial.params = {"param1": 1}
        # Add this line:
        mock_study.return_value.trials = []

        forecaster._tune(sample_data, sample_data, num_trials=5)


def test_prepare_test_data(forecaster, sample_data, data_pipeline):
    """Test preparation of test data for prediction."""
    forecaster.data_pipeline = data_pipeline
    forecaster.train_df = sample_data.iloc[:26].copy()  # lookback_window_size (24) + max_data_drop (2)
    test_df = forecaster.prepare_test_data(sample_data)
    assert isinstance(test_df, pd.DataFrame)
    assert test_df["timestamp"].is_monotonic_increasing
    expected = pd.concat([forecaster.train_df, sample_data]).sort_values(by="timestamp")
    pd.testing.assert_frame_equal(test_df.reset_index(drop=True), expected.reset_index(drop=True), check_dtype=False)


def test_prepare_test_data_no_train_df(forecaster, sample_data, data_pipeline):
    """Test prepare_test_data with no train_df."""
    forecaster.data_pipeline = data_pipeline
    forecaster.train_df = None
    test_df = forecaster.prepare_test_data(sample_data)
    assert isinstance(test_df, pd.DataFrame)
    assert test_df["timestamp"].is_monotonic_increasing
    pd.testing.assert_frame_equal(
        test_df.reset_index(drop=True),
        sample_data.sort_values(by="timestamp").reset_index(drop=True),
        check_dtype=False,
    )


def test_prepare_test_data_no_data(forecaster, data_pipeline):
    """Test prepare_test_data with no train_df or test_df."""
    forecaster.data_pipeline = data_pipeline
    forecaster.train_df = None
    with pytest.raises(ValueError, match="You cannot call prediction without specifying test data"):
        forecaster.prepare_test_data(None)


def test_create_results_df(forecaster, data_pipeline):
    """Test creation of results DataFrame."""
    forecaster.data_pipeline = data_pipeline
    time_stamp = np.array([pd.Timestamp("2023-01-01").value, pd.Timestamp("2023-01-02").value])
    ground_truth = np.array([[[1.0]], [[2.0]]])
    predictions = np.array([[[1.5]], [[2.5]]])
    target_feature = ["sales"]
    date_column = "timestamp"

    results_df = forecaster.create_results_df(time_stamp, ground_truth, predictions, target_feature, date_column)
    assert isinstance(results_df, pd.DataFrame)
    assert list(results_df.columns) == ["sales", "sales_forecast"]
    assert results_df.index.name == "timestamp"
    assert len(results_df) == 2
    assert results_df["sales"].tolist() == [1.0, 2.0]
    assert results_df["sales_forecast"].tolist() == [1.5, 2.5]


def test_create_results_df_shape_mismatch(forecaster, data_pipeline):
    """Test create_results_df with shape mismatch."""
    forecaster.data_pipeline = data_pipeline
    time_stamp = np.array([pd.Timestamp("2023-01-01").value])
    ground_truth = np.array([[[1.0]], [[2.0]]])  # More rows than timestamp
    predictions = np.array([[[1.5]]])
    with pytest.raises(ValueError, match="Shape mismatch"):
        forecaster.create_results_df(time_stamp, ground_truth, predictions, ["sales"], "timestamp")


def test_get_ground_truth(forecaster, sample_data, data_pipeline):
    """Test retrieval of ground truth data."""
    forecaster.data_pipeline = data_pipeline
    forecaster.load_checkpoint_and_datapipe = Mock()

    # Configure the return value as a tuple of two arrays
    data_pipeline.get_ground_truth_sequences = Mock(return_value=(np.array([1, 2]), np.random.randn(2, 1, 1)))
    # Ensure rescale_predictions doesn't crash on mocks
    forecaster._rescale_predictions = Mock(side_effect=lambda x: x)

    time_stamp, ground_truth = forecaster.get_ground_truth(sample_data)
    assert isinstance(time_stamp, np.ndarray)
    assert isinstance(ground_truth, np.ndarray)


def test_inverse_scale_predictions(forecaster, data_pipeline):
    """Test inverse scaling of predictions."""
    forecaster.data_pipeline = data_pipeline
    data_pipeline.data_pipeline.named_steps = {"scaling": Mock(named_transformers_={"target_scaling": Mock()})}
    scaled_predictions = np.random.randn(10, 1, 1)
    data_pipeline.data_pipeline.named_steps["scaling"].named_transformers_["target_scaling"].inverse_transform = Mock(
        return_value=np.random.randn(10, 1)
    )

    result = forecaster._inverse_scale_predictions(scaled_predictions)
    assert result.shape == scaled_predictions.shape
    data_pipeline.data_pipeline.named_steps["scaling"].named_transformers_[
        "target_scaling"
    ].inverse_transform.assert_called_once()


def test_inverse_scale_predictions_missing_scaler(forecaster, data_pipeline):
    """Test inverse scaling with missing scaler."""
    forecaster.data_pipeline = data_pipeline
    data_pipeline.data_pipeline.named_steps = {"scaling": Mock(named_transformers_={})}
    with pytest.raises(RuntimeError, match="Missing pipeline component"):
        forecaster._inverse_scale_predictions(np.random.randn(10, 24, 1))


def test_validate_data_pipeline(forecaster, data_pipeline):
    """Test data pipeline validation."""
    forecaster.data_pipeline = data_pipeline
    forecaster._validate_data_pipeline()  # Should not raise
    data_pipeline.data_pipeline = None
    with pytest.raises(ValueError, match="Data pipeline not initialized"):
        forecaster._validate_data_pipeline()


def test_predict(forecaster, sample_data, data_pipeline):
    """Test prediction workflow."""
    forecaster.data_pipeline = data_pipeline
    forecaster.model = Mock(forecast=Mock(return_value=np.random.randn(10, 24, 1)))
    forecaster._inverse_scale_predictions = Mock(return_value=np.random.randn(10, 24, 1))
    forecaster._validate_data_pipeline = Mock()

    from twiga.forecaster.result import RawPrediction

    result = forecaster._predict(sample_data, None)
    assert isinstance(result, RawPrediction)
    assert result.loc.shape == (10, 24, 1)
    forecaster.model.forecast.assert_called_once()
    forecaster._inverse_scale_predictions.assert_called_once()
    forecaster._validate_data_pipeline.assert_called_once()


def test_evaluate(forecaster, sample_data, data_pipeline):
    """Test evaluation of predictions."""
    forecaster.data_pipeline = data_pipeline
    forecaster.model_type = "test_model"
    forecaster.model = Mock(forecast=Mock(return_value=np.random.randn(10, 1, 1)))
    forecaster._inverse_scale_predictions = Mock(return_value=np.random.randn(10, 1, 1))
    forecaster.get_ground_truth = Mock(
        return_value=(np.zeros((10, 1, 1), dtype="datetime64[ns]"), np.random.randn(10, 1, 1))
    )
    forecaster.create_results_df = Mock(return_value=pd.DataFrame())

    results_df, metrics_df = forecaster._evaluate(sample_data)
    assert isinstance(results_df, pd.DataFrame)
    assert isinstance(metrics_df, pd.DataFrame)
    assert "Model" in metrics_df.columns
    assert metrics_df["Model"].iloc[0] == "TEST_MODEL"
    assert "test-time" in metrics_df.columns
    assert isinstance(metrics_df["test-time"].iloc[0], float)


def test_backtester(forecaster, sample_data, data_pipeline):
    """Test backtesting functionality."""
    forecaster.data_pipeline = data_pipeline
    forecaster._fit = Mock()
    forecaster._evaluate = Mock(
        return_value=(pd.DataFrame({"sales": [1.0]}), pd.DataFrame({"mae": [0.1], "rmse": [0.2]}))
    )
    forecaster.split = Mock(
        return_value=[
            (
                sample_data,
                sample_data,
                {"train_period": ["2023-01-01", "2023-06-30"], "test_period": ["2023-07-01", "2023-12-31"]},
                0,
            )
        ]
    )

    forecast, metrics = forecaster._backtester(sample_data, train_ratio=0.8, verbose=True)
    assert isinstance(forecast, pd.DataFrame)
    assert isinstance(metrics, pd.DataFrame)
    assert "Folds" in metrics.columns
    forecaster._fit.assert_called_once()
    forecaster._evaluate.assert_called_once()
    forecaster.data_pipeline.fit.assert_called_once()
