"""Tests for twiga.utils.utils.

Covers:
- format_target: default stride=1, custom stride, delegates to get_target_sequences
- get_latest_checkpoint: directory with .ckpt files, empty directory
"""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestFormatTarget:
    """Tests for format_target."""

    def test_default_stride_calls_get_target_sequences(self) -> None:
        """format_target with default stride=1 delegates to get_target_sequences."""
        mock_targets = MagicMock()
        expected = MagicMock()

        with patch("twiga.utils.utils.get_target_sequences", return_value=expected) as mock_target:
            from twiga.utils.utils import format_target

            result = format_target(mock_targets, input_window_size=48, forecast_horizon=24)

        mock_target.assert_called_once_with(mock_targets, 48, 24, stride=1)
        assert result is expected

    def test_custom_stride_passed_through(self) -> None:
        """format_target passes custom stride to get_target_sequences."""
        mock_targets = MagicMock()
        expected = MagicMock()

        with patch("twiga.utils.utils.get_target_sequences", return_value=expected) as mock_target:
            from twiga.utils.utils import format_target

            result = format_target(mock_targets, input_window_size=24, forecast_horizon=12, stride=12)

        mock_target.assert_called_once_with(mock_targets, 24, 12, stride=12)
        assert result is expected


class TestGetLatestCheckpoint:
    """Tests for get_latest_checkpoint."""

    def test_returns_path_of_latest_ckpt(self, tmp_path: Path) -> None:
        """Returns the path of the most recently created .ckpt file."""
        ckpt_a = tmp_path / "epoch=0.ckpt"
        ckpt_b = tmp_path / "epoch=1.ckpt"
        ckpt_a.write_text("a")
        ckpt_b.write_text("b")

        # Touch ckpt_b to make it newer
        os.utime(ckpt_b, (ckpt_a.stat().st_atime + 1, ckpt_a.stat().st_mtime + 1))

        from twiga.utils.utils import get_latest_checkpoint

        result = get_latest_checkpoint(str(tmp_path))
        assert result is not None
        assert result.endswith(".ckpt")

    def test_returns_none_when_no_ckpt_files(self, tmp_path: Path) -> None:
        """Returns None when the directory contains no .ckpt files."""
        (tmp_path / "model.pt").write_text("not a checkpoint")

        from twiga.utils.utils import get_latest_checkpoint

        result = get_latest_checkpoint(str(tmp_path))
        assert result is None

    def test_single_ckpt_file(self, tmp_path: Path) -> None:
        """Returns the only .ckpt file when exactly one exists."""
        ckpt = tmp_path / "only.ckpt"
        ckpt.write_text("checkpoint")

        from twiga.utils.utils import get_latest_checkpoint

        result = get_latest_checkpoint(str(tmp_path))
        assert result == str(ckpt)

    def test_accepts_path_object(self, tmp_path: Path) -> None:
        """Accepts a Path object as well as a string."""
        ckpt = tmp_path / "run.ckpt"
        ckpt.write_text("data")

        from twiga.utils.utils import get_latest_checkpoint

        result = get_latest_checkpoint(tmp_path)
        assert result == str(ckpt)
