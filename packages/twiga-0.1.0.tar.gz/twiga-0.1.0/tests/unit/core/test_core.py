import numpy as np
import pandas as pd
import pytest

from twiga.core.stats.utils import _fit_model_for_lag, get_optimal_lags

"""
Unit tests for core time series analysis utilities.

Tests lag selection functions with various data scenarios.
"""


class TestFitModelForLag:
    """Tests for _fit_model_for_lag function."""

    def test_insufficient_data_returns_none(self):
        """Test that insufficient data (n - lag < 10) returns None."""
        series = np.random.randn(15)
        result = _fit_model_for_lag(series, lag=10, n=15, lb_test=False)
        assert result is None

    def test_valid_model_fit_returns_dict(self):
        """Test that valid data produces a result dictionary."""
        series = np.random.randn(50)
        result = _fit_model_for_lag(series, lag=3, n=50, lb_test=False)

        assert result is not None
        assert isinstance(result, dict)
        assert "lag" in result
        assert "aic" in result
        assert "bic" in result
        assert "hqic" in result
        assert "lb_pvalue" in result
        assert result["lag"] == 3

    def test_lb_test_disabled(self):
        """Test that Ljung-Box test is skipped when lb_test=False."""
        series = np.random.randn(50)
        result = _fit_model_for_lag(series, lag=2, n=50, lb_test=False)

        assert result is not None
        assert result["lb_pvalue"] is None

    def test_lb_test_enabled(self):
        """Test that Ljung-Box test is computed when lb_test=True."""
        series = np.random.randn(50)
        result = _fit_model_for_lag(series, lag=2, n=50, lb_test=True)

        assert result is not None
        assert result["lb_pvalue"] is not None

    def test_model_fitting_failure_returns_none(self):
        """Test that model fitting failure returns None gracefully."""
        series = np.array([np.nan] * 50)
        result = _fit_model_for_lag(series, lag=2, n=50, lb_test=False)

        assert result is None

    def test_boundary_case_exact_threshold(self):
        """Test boundary case where n - lag > 10 (sufficient data)."""
        series = np.random.randn(22)
        result = _fit_model_for_lag(series, lag=10, n=22, lb_test=False)

        assert result is not None

    def test_boundary_case_below_threshold(self):
        """Test boundary case where n - lag <= 10 (insufficient data)."""
        series = np.random.randn(20)
        result = _fit_model_for_lag(series, lag=10, n=20, lb_test=False)

        assert result is None


class TestSelectOptimalLags:
    """Tests for get_optimal_lags function."""

    def test_minimum_data_requirement(self):
        """Test that function raises error for insufficient data."""
        series = np.random.randn(20)

        with pytest.raises(ValueError, match="Series too short"):
            get_optimal_lags(series, min_data_points=30)

    def test_valid_series_returns_expected_keys(self):
        """Test that valid series returns all expected keys."""
        series = np.random.randn(100)
        result = get_optimal_lags(series)

        assert "AIC" in result
        assert "BIC" in result
        assert "HQIC" in result
        assert "criteria_values" in result
        assert "max_lags_tested" in result
        assert "valid_models" in result

    def test_criteria_values_structure(self):
        """Test that criteria_values has correct structure."""
        series = np.random.randn(100)
        result = get_optimal_lags(series)

        criteria = result["criteria_values"]
        assert "lags" in criteria
        assert "aic" in criteria
        assert "bic" in criteria
        assert "hqic" in criteria
        assert "lb_pvalue" in criteria
        assert len(criteria["lags"]) == len(criteria["aic"])
        assert len(criteria["lags"]) == result["valid_models"]

    def test_schwert_rule_applied(self):
        """Test that Schwert (1989) rule is applied for max_lags."""
        series = np.random.randn(100)
        result = get_optimal_lags(series, max_lags=None)

        expected_max = min(int(12 * (100 / 100) ** 0.25), 100 // 3)
        assert result["max_lags_tested"] <= expected_max

    def test_explicit_max_lags(self):
        """Test that explicit max_lags parameter is respected."""
        series = np.random.randn(100)
        result = get_optimal_lags(series, max_lags=5)

        assert result["max_lags_tested"] == 5
        assert max(result["criteria_values"]["lags"]) == 5

    def test_seasonal_period_adjustment(self):
        """Test that seasonal period adjusts max_lags."""
        series = np.random.randn(100)
        # period="2h" → 12 samples/day; max_lags should be raised to at least 12
        result = get_optimal_lags(series, max_lags=5, period="2h")

        assert result["max_lags_tested"] >= 12

    def test_invalid_seasonal_period_handled(self):
        """Test that invalid seasonal period string is handled gracefully."""
        series = np.random.randn(100)
        result = get_optimal_lags(series, period="invalid")

        assert result is not None

    def test_numpy_array_input(self):
        """Test that numpy array input works correctly."""
        series = np.random.randn(100)
        result = get_optimal_lags(series)

        assert result["valid_models"] > 0

    def test_pandas_series_input(self):
        """Test that pandas Series input works correctly."""
        series = pd.Series(np.random.randn(100))
        result = get_optimal_lags(series)

        assert result["valid_models"] > 0

    def test_optimal_lags_are_valid(self):
        """Test that returned optimal lags are within valid range."""
        series = np.random.randn(100)
        result = get_optimal_lags(series, max_lags=10)

        assert 1 <= result["AIC"] <= 10
        assert 1 <= result["BIC"] <= 10
        assert 1 <= result["HQIC"] <= 10

    def test_lb_test_disabled(self):
        """Test that Ljung-Box test is skipped when lb_test=False."""
        series = np.random.randn(100)
        result = get_optimal_lags(series, lb_test=False)

        assert all(v is None for v in result["criteria_values"]["lb_pvalue"])

    def test_lb_test_enabled(self):
        """Test that Ljung-Box test is computed when lb_test=True."""
        series = np.random.randn(100)
        result = get_optimal_lags(series, lb_test=True)

        assert any(v is not None for v in result["criteria_values"]["lb_pvalue"])

    def test_no_valid_models_raises_error(self):
        """Test that error is raised when no valid models can be fitted."""
        # Use series with NaN values which will cause all model fits to fail
        series = np.full(50, np.nan)

        with pytest.raises(ValueError, match="No valid lag models could be fitted"):
            get_optimal_lags(series, max_lags=5, min_data_points=30)

    def test_custom_min_data_points(self):
        """Test custom min_data_points parameter."""
        series = np.random.randn(50)

        result = get_optimal_lags(series, min_data_points=40)
        assert result["valid_models"] > 0

    def test_insufficient_data_for_custom_min(self):
        """Test that custom min_data_points threshold is enforced."""
        series = np.random.randn(50)

        with pytest.raises(ValueError, match="Series too short"):
            get_optimal_lags(series, min_data_points=60)

    def test_max_lags_bounded_by_series_length(self):
        """Test that max_lags is bounded by n // 2."""
        series = np.random.randn(100)
        result = get_optimal_lags(series, max_lags=500)

        assert result["max_lags_tested"] <= 100 // 2
