import numpy as np
import pandas as pd
import pytest

from twiga.core.stats.stationarity import adf_test, kpss_test

"""Tests for stationarity test utilities."""


class TestADFTest:
    """Tests for the adf_test function."""

    def test_adf_with_valid_series(self):
        """Test ADF with valid time series data."""
        values = np.random.randn(100)
        result = adf_test(values)
        assert isinstance(result, tuple)
        assert len(result) > 0

    def test_adf_with_pandas_series(self):
        """Test ADF with pandas Series input."""
        values = pd.Series(np.random.randn(100))
        result = adf_test(values)
        assert isinstance(result, tuple)

    def test_adf_with_custom_maxlag(self):
        """Test ADF with custom maxlag parameter."""
        values = np.random.randn(100)
        result = adf_test(values, maxlag=5)
        assert isinstance(result, tuple)

    def test_adf_insufficient_data(self):
        """Test ADF raises ValueError with insufficient data."""
        values = np.random.randn(5)
        with pytest.raises(ValueError, match="Insufficient data"):
            adf_test(values)

    def test_adf_invalid_maxlag_negative(self):
        """Test ADF raises ValueError with negative maxlag."""
        values = np.random.randn(100)
        with pytest.raises(ValueError, match="Invalid maxlag"):
            adf_test(values, maxlag=-1)

    def test_adf_invalid_maxlag_too_large(self):
        """Test ADF raises ValueError with maxlag >= n."""
        values = np.random.randn(50)
        with pytest.raises(ValueError, match="Invalid maxlag"):
            adf_test(values, maxlag=50)

    def test_adf_regression_parameter(self):
        """Test ADF with different regression parameters."""
        values = np.random.randn(100)
        for regression in ["c", "ct", "ctt", "n"]:
            result = adf_test(values, regression=regression)
            assert isinstance(result, tuple)

    def test_adf_autolag_parameter(self):
        """Test ADF with different autolag parameters."""
        values = np.random.randn(100)
        for autolag in ["BIC", "AIC"]:
            result = adf_test(values, autolag=autolag)
            assert isinstance(result, tuple)


class TestKPSSTest:
    """Tests for the kpss_test function."""

    def test_kpss_with_valid_series(self):
        """Test KPSS with valid time series data."""
        values = np.random.randn(100)
        result = kpss_test(values)
        assert isinstance(result, tuple)
        assert len(result) > 0

    def test_kpss_with_pandas_series(self):
        """Test KPSS with pandas Series input."""
        values = pd.Series(np.random.randn(100))
        result = kpss_test(values)
        assert isinstance(result, tuple)

    def test_kpss_with_custom_maxlag(self):
        """Test KPSS with custom maxlag parameter."""
        values = np.random.randn(100)
        result = kpss_test(values, maxlag=3)
        assert isinstance(result, tuple)

    def test_kpss_insufficient_data(self):
        """Test KPSS raises ValueError with insufficient data."""
        values = np.random.randn(5)
        with pytest.raises(ValueError, match="Insufficient data"):
            kpss_test(values)

    def test_kpss_invalid_maxlag_negative(self):
        """Test KPSS raises ValueError with negative maxlag."""
        values = np.random.randn(100)
        with pytest.raises(ValueError, match="Invalid maxlag"):
            kpss_test(values, maxlag=-1)

    def test_kpss_invalid_maxlag_too_large(self):
        """Test KPSS raises ValueError with maxlag >= n."""
        values = np.random.randn(50)
        with pytest.raises(ValueError, match="Invalid maxlag"):
            kpss_test(values, maxlag=50)

    def test_kpss_regression_parameter(self):
        """Test KPSS with different regression parameters."""
        values = np.random.randn(100)
        for regression in ["c", "ct"]:
            result = kpss_test(values, regression=regression)
            assert isinstance(result, tuple)

    def test_kpss_minimum_valid_data(self):
        """Test KPSS with minimum valid data size."""
        values = np.random.randn(10)
        result = kpss_test(values)
        assert isinstance(result, tuple)

    def test_adf_minimum_valid_data(self):
        """Test ADF with minimum valid data size."""
        values = np.random.randn(10)
        result = adf_test(values)
        assert isinstance(result, tuple)
