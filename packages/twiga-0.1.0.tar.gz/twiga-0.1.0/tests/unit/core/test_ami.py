"""Tests for twiga.core.stats.ami.get_ami_profile."""

from __future__ import annotations

from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest

from twiga.core.stats.ami import get_ami_profile

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def stationary_series() -> np.ndarray:
    """Short stationary white-noise series (n=80)."""
    rng = np.random.default_rng(0)
    return rng.standard_normal(80)


@pytest.fixture
def periodic_series() -> np.ndarray:
    """Deterministic sine with period 24 plus light noise (n=300)."""
    rng = np.random.default_rng(1)
    t = np.arange(300)
    return np.sin(2 * np.pi * t / 24) + 0.05 * rng.standard_normal(300)


@pytest.fixture
def pandas_series(stationary_series) -> pd.Series:
    return pd.Series(stationary_series)


# ---------------------------------------------------------------------------
# Return-shape contracts
# ---------------------------------------------------------------------------


class TestGetAmiProfileShape:
    def test_returns_two_arrays(self, stationary_series):
        horizons, ami_values = get_ami_profile(stationary_series)
        assert isinstance(horizons, np.ndarray)
        assert isinstance(ami_values, np.ndarray)

    def test_arrays_equal_length(self, stationary_series):
        horizons, ami_values = get_ami_profile(stationary_series)
        assert len(horizons) == len(ami_values)

    def test_horizons_start_at_one(self, stationary_series):
        horizons, _ = get_ami_profile(stationary_series)
        assert len(horizons) > 0
        assert horizons[0] == 1

    def test_horizons_are_consecutive(self, stationary_series):
        horizons, _ = get_ami_profile(stationary_series)
        diffs = np.diff(horizons)
        assert (diffs == 1).all()

    def test_max_horizons_cap(self, periodic_series):
        cap = 20
        horizons, ami_values = get_ami_profile(periodic_series, max_horizons=cap)
        assert len(horizons) <= cap
        assert len(ami_values) <= cap

    def test_default_max_h_formula(self, stationary_series):
        """max_h == n_diff - (n_neighbors + 1) when max_horizons is None."""
        n_neighbors = 8
        horizons, _ = get_ami_profile(stationary_series, n_neighbors=n_neighbors)
        expected_max_h = len(stationary_series) - 1 - (n_neighbors + 1)
        assert len(horizons) == expected_max_h


# ---------------------------------------------------------------------------
# Value contracts
# ---------------------------------------------------------------------------


class TestGetAmiProfileValues:
    def test_ami_values_non_negative(self, stationary_series):
        _, ami_values = get_ami_profile(stationary_series)
        assert (ami_values >= 0).all()

    def test_ami_values_are_finite(self, stationary_series):
        _, ami_values = get_ami_profile(stationary_series)
        assert np.isfinite(ami_values).all()

    def test_ami_dtype_float(self, stationary_series):
        _, ami_values = get_ami_profile(stationary_series)
        assert ami_values.dtype == float

    def test_horizons_dtype_int(self, stationary_series):
        horizons, _ = get_ami_profile(stationary_series)
        assert np.issubdtype(horizons.dtype, np.integer)

    def test_periodic_series_has_positive_ami_at_h1(self, periodic_series):
        """A strongly periodic series should have AMI(h=1) > 0."""
        _, ami_values = get_ami_profile(periodic_series, n_neighbors=4)
        assert ami_values[0] > 0.0


# ---------------------------------------------------------------------------
# Input variants
# ---------------------------------------------------------------------------


class TestGetAmiProfileInputs:
    def test_accepts_pandas_series(self, pandas_series):
        horizons, ami_values = get_ami_profile(pandas_series)
        assert len(horizons) > 0

    def test_accepts_numpy_array(self, stationary_series):
        horizons, ami_values = get_ami_profile(stationary_series)
        assert len(horizons) > 0

    def test_2d_input_raises(self):
        arr = np.ones((50, 2))
        with pytest.raises(ValueError, match="1-D"):
            get_ami_profile(arr)

    def test_custom_n_neighbors(self, stationary_series):
        h1, v1 = get_ami_profile(stationary_series, n_neighbors=4)
        h2, v2 = get_ami_profile(stationary_series, n_neighbors=12)
        # Both should return arrays; lengths may differ
        assert len(h1) > 0
        assert len(h2) > 0

    def test_reproducible_with_fixed_seed(self, stationary_series):
        _, v1 = get_ami_profile(stationary_series, random_state=7)
        _, v2 = get_ami_profile(stationary_series, random_state=7)
        np.testing.assert_array_equal(v1, v2)

    def test_different_seeds_may_differ(self, stationary_series):
        """Different seeds can produce different estimates (stochastic estimator)."""
        _, v1 = get_ami_profile(stationary_series, random_state=1)
        _, v2 = get_ami_profile(stationary_series, random_state=999)
        # Not guaranteed to differ but almost certain with enough data.
        # We just check both succeed and return valid arrays.
        assert len(v1) > 0
        assert len(v2) > 0


# ---------------------------------------------------------------------------
# Edge cases — too-short series
# ---------------------------------------------------------------------------


class TestGetAmiProfileEdgeCases:
    def test_too_short_returns_empty(self):
        """Series shorter than n_neighbors + 2 (after diff) returns empty arrays."""
        short = np.array([1.0, 2.0, 3.0])  # n_diff=2, needs >= 10
        horizons, ami_values = get_ami_profile(short, n_neighbors=8)
        assert len(horizons) == 0
        assert len(ami_values) == 0

    def test_empty_arrays_have_correct_dtype(self):
        short = np.array([1.0, 2.0])
        horizons, ami_values = get_ami_profile(short, n_neighbors=8)
        assert np.issubdtype(horizons.dtype, np.integer)
        assert ami_values.dtype == float

    def test_max_horizons_zero_after_cap_returns_empty(self):
        """max_horizons=1 on a very short series may still yield empty."""
        short = np.ones(5)
        horizons, ami_values = get_ami_profile(short, n_neighbors=8, max_horizons=1)
        assert len(horizons) == 0

    def test_sklearn_error_propagation(self, stationary_series):
        """If mutual_info_regression raises, the exception propagates."""
        with (
            patch(
                "twiga.core.stats.ami.mutual_info_regression",
                side_effect=ValueError("estimator error"),
            ),
            pytest.raises(ValueError, match="estimator error"),
        ):
            get_ami_profile(stationary_series)
