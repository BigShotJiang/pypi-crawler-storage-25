"""Unit tests for autocorrelation analysis functions.

Tests PACF analysis, AR order estimation, and Durbin-Watson statistics.
"""

import numpy as np
import pandas as pd

from twiga.core.stats.autocorr import (
    calculate_durbin_watson,
    estimate_ar_order,
    get_pacf_values,
)


class TestGetPacfValues:
    """Tests for get_pacf_values function."""

    def test_returns_tuple_with_two_elements(self):
        """Test that function returns a tuple of (pacf_values, pacf_confint)."""
        series = np.random.randn(100)
        result = get_pacf_values(series, maxlag=5)

        assert isinstance(result, tuple)
        assert len(result) == 2

    def test_removes_lag_zero(self):
        """Test that lag 0 is removed from both outputs."""
        series = np.random.randn(100)
        pacf_vals, pacf_conf = get_pacf_values(series, maxlag=5)

        # Should have maxlag elements (lag 0 removed)
        assert len(pacf_vals) == 5
        assert len(pacf_conf) == 5

    def test_confidence_intervals_structure(self):
        """Test that confidence intervals have correct structure."""
        series = np.random.randn(100)
        pacf_vals, pacf_conf = get_pacf_values(series, maxlag=5)

        # Each confidence interval should be a tuple of (lower, upper)
        assert len(pacf_conf) == 5
        assert all(len(ci) == 2 for ci in pacf_conf)

    def test_numpy_array_input(self):
        """Test with numpy array input."""
        series = np.random.randn(100)
        pacf_vals, pacf_conf = get_pacf_values(series, maxlag=10)

        assert pacf_vals is not None
        assert len(pacf_vals) == 10

    def test_pandas_series_input(self):
        """Test with pandas Series input."""
        series = pd.Series(np.random.randn(100))
        pacf_vals, pacf_conf = get_pacf_values(series, maxlag=10)

        assert pacf_vals is not None
        assert len(pacf_vals) == 10

    def test_different_alpha_levels(self):
        """Test that different alpha values affect confidence intervals."""
        series = np.random.randn(100)

        pacf_vals_95, pacf_conf_95 = get_pacf_values(series, maxlag=5, alpha=0.05)
        pacf_vals_99, pacf_conf_99 = get_pacf_values(series, maxlag=5, alpha=0.01)

        # PACF values should be the same
        np.testing.assert_array_almost_equal(pacf_vals_95, pacf_vals_99)

        # But confidence intervals should be wider for 99% (alpha=0.01)
        # Check first interval as example
        width_95 = pacf_conf_95[0][1] - pacf_conf_95[0][0]
        width_99 = pacf_conf_99[0][1] - pacf_conf_99[0][0]
        assert width_99 > width_95

    def test_different_methods(self):
        """Test that different methods produce results."""
        series = np.random.randn(100)

        # Test Yule-Walker method (default)
        pacf_yw, _ = get_pacf_values(series, maxlag=5, method="ywm")

        # Test OLS method
        pacf_ols, _ = get_pacf_values(series, maxlag=5, method="ols")

        # Both should produce valid results
        assert len(pacf_yw) == 5
        assert len(pacf_ols) == 5

    def test_short_series(self):
        """Test with minimum viable series length."""
        series = np.random.randn(20)
        pacf_vals, pacf_conf = get_pacf_values(series, maxlag=5)

        assert len(pacf_vals) == 5


class TestEstimateArOrder:
    """Tests for estimate_ar_order function."""

    def test_returns_tuple_with_two_elements(self):
        """Test that function returns (significant_lags, suggested_ar_order)."""
        series = np.random.randn(100)
        result = estimate_ar_order(series, maxlag=10)

        assert isinstance(result, tuple)
        assert len(result) == 2

    def test_significant_lags_is_list(self):
        """Test that significant_lags is a list of integers."""
        series = np.random.randn(100)
        sig_lags, ar_order = estimate_ar_order(series, maxlag=10)

        assert isinstance(sig_lags, list)
        assert all(isinstance(lag, (int, np.integer)) for lag in sig_lags)

    def test_ar_order_is_integer(self):
        """Test that suggested AR order is an integer."""
        series = np.random.randn(100)
        sig_lags, ar_order = estimate_ar_order(series, maxlag=10)

        assert isinstance(ar_order, int)

    def test_ar_order_within_bounds(self):
        """Test that AR order is within valid range."""
        series = np.random.randn(100)
        sig_lags, ar_order = estimate_ar_order(series, maxlag=10)

        assert 0 <= ar_order <= 10

    def test_white_noise_low_ar_order(self):
        """Test that white noise suggests low/zero AR order."""
        # White noise should have no significant autocorrelation
        np.random.seed(42)
        series = np.random.randn(500)
        sig_lags, ar_order = estimate_ar_order(series, maxlag=20)

        # For white noise, AR order should be low (often 0 or 1)
        assert ar_order <= 3

    def test_ar_order_is_last_consecutive_significant_lag(self):
        """Test that AR order represents cutoff, not max significant lag."""
        series = np.random.randn(100)
        sig_lags, ar_order = estimate_ar_order(series, maxlag=10)

        # If ar_order > 0, all lags from 1 to ar_order should be significant
        if ar_order > 0:
            actual_consecutive = [lag for lag in sig_lags if lag <= ar_order]
            # Should have consecutive significant lags up to ar_order
            assert len(actual_consecutive) == ar_order

    def test_numpy_array_input(self):
        """Test with numpy array input."""
        series = np.random.randn(100)
        sig_lags, ar_order = estimate_ar_order(series, maxlag=5)

        assert isinstance(sig_lags, list)
        assert isinstance(ar_order, int)

    def test_pandas_series_input(self):
        """Test with pandas Series input."""
        series = pd.Series(np.random.randn(100))
        sig_lags, ar_order = estimate_ar_order(series, maxlag=5)

        assert isinstance(sig_lags, list)
        assert isinstance(ar_order, int)

    def test_constant_series_returns_zero_order(self):
        """Test that constant series suggests AR(0)."""
        series = np.ones(100)
        sig_lags, ar_order = estimate_ar_order(series, maxlag=5)

        # Constant series should suggest AR(0) or very low order
        assert ar_order <= 1

    def test_maxlag_parameter_respected(self):
        """Test that maxlag parameter limits the analysis."""
        series = np.random.randn(100)
        sig_lags, ar_order = estimate_ar_order(series, maxlag=5)

        # No significant lag should exceed maxlag
        assert all(lag <= 5 for lag in sig_lags)
        assert ar_order <= 5


class TestCalculateDurbinWatson:
    """Tests for calculate_durbin_watson function."""

    def test_returns_float(self):
        """Test that function returns a float."""
        series = np.random.randn(100)
        result = calculate_durbin_watson(series)

        assert isinstance(result, (float, np.floating))

    def test_value_in_valid_range(self):
        """Test that DW statistic is between 0 and 4."""
        series = np.random.randn(100)
        dw = calculate_durbin_watson(series)

        # Valid range for Durbin-Watson is [0, 4]
        assert 0 <= dw <= 4 or np.isnan(dw)

    def test_white_noise_near_two(self):
        """Test that white noise produces DW near 2."""
        np.random.seed(42)
        series = np.random.randn(500)
        dw = calculate_durbin_watson(series, use_diff=False)

        # White noise should have DW close to 2 (no autocorrelation)
        # Allow some variance due to randomness
        assert 1.5 <= dw <= 2.5

    def test_positive_autocorrelation_below_two(self):
        """Test that positively autocorrelated series has DW < 2."""
        # Create series with positive autocorrelation
        np.random.seed(42)
        series = np.cumsum(np.random.randn(100))  # Random walk
        dw = calculate_durbin_watson(series, use_diff=False)

        # Should show positive autocorrelation (DW < 2)
        assert dw < 2

    def test_use_diff_true(self):
        """Test with first differencing enabled."""
        series = np.random.randn(100)
        dw = calculate_durbin_watson(series, use_diff=True)

        assert isinstance(dw, (float, np.floating))
        assert not np.isnan(dw)

    def test_use_diff_false(self):
        """Test without differencing."""
        series = np.random.randn(100)
        dw = calculate_durbin_watson(series, use_diff=False)

        assert isinstance(dw, (float, np.floating))
        assert not np.isnan(dw)

    def test_series_too_short_returns_nan(self):
        """Test that series with n < 2 returns NaN."""
        series = np.array([1.0])
        dw = calculate_durbin_watson(series)

        assert np.isnan(dw)

    def test_series_too_short_after_diff_returns_nan(self):
        """Test that series with < 3 points after differencing returns NaN."""
        series = np.array([1.0, 2.0])  # After diff: 1 point
        dw = calculate_durbin_watson(series, use_diff=True)

        assert np.isnan(dw)

    def test_numpy_array_input(self):
        """Test with numpy array input."""
        series = np.random.randn(100)
        dw = calculate_durbin_watson(series)

        assert isinstance(dw, (float, np.floating))

    def test_pandas_series_input(self):
        """Test with pandas Series input."""
        series = pd.Series(np.random.randn(100))
        dw = calculate_durbin_watson(series)

        assert isinstance(dw, (float, np.floating))

    def test_nan_values_handled(self):
        """Test that NaN values are handled gracefully."""
        series = np.array([1.0, 2.0, np.nan, 4.0, 5.0])
        dw = calculate_durbin_watson(series)

        # Should return NaN due to invalid data
        assert np.isnan(dw)

    def test_invalid_data_returns_nan(self):
        """Test that invalid data returns NaN without crashing."""
        series = np.array([np.inf, -np.inf, 1.0, 2.0])
        dw = calculate_durbin_watson(series)

        # Should handle gracefully and return NaN
        assert np.isnan(dw)

    def test_minimum_valid_series_with_diff(self):
        """Test minimum valid series length with differencing."""
        series = np.random.randn(4)  # After diff: 3 points (minimum)
        dw = calculate_durbin_watson(series, use_diff=True)

        # Should succeed with exactly 3 points after differencing
        assert isinstance(dw, (float, np.floating))
        assert not np.isnan(dw)

    def test_constant_series_handled(self):
        """Test that constant series is handled appropriately."""
        series = np.ones(100)
        dw = calculate_durbin_watson(series)

        # May return NaN or a valid value depending on implementation
        # Just verify it doesn't crash
        assert isinstance(dw, (float, np.floating))


class TestIntegration:
    """Integration tests for autocorr functions working together."""

    def test_pacf_to_ar_order_workflow(self):
        """Test typical workflow from PACF to AR order selection."""
        series = np.random.randn(200)

        # First get raw PACF values
        pacf_vals, pacf_conf = get_pacf_values(series, maxlag=15)

        # Then use AR order estimation
        sig_lags, ar_order = estimate_ar_order(series, maxlag=15)

        # Results should be consistent
        assert len(pacf_vals) == 15
        assert ar_order <= 15
        assert all(lag <= 15 for lag in sig_lags)

    def test_ar_model_residual_testing(self):
        """Test workflow of fitting AR model and testing residuals."""
        # Simulate testing residuals after model fitting
        np.random.seed(42)
        residuals = np.random.randn(100)  # Simulated white noise residuals

        dw = calculate_durbin_watson(residuals, use_diff=False)

        # Good residuals should have DW near 2
        assert 1.5 <= dw <= 2.5
