"""Tests for entropy measures module."""

from unittest.mock import patch

import numpy as np
import pandas as pd

from twiga.core.stats.entropy import (
    get_approx_entropy,
    get_dfa_exponent,
    get_hurst_exponent,
    get_permutation_entropy,
    get_sample_entropy,
)


class TestApproxEntropy:
    """Tests for approximate entropy calculation."""

    def test_regular_series(self):
        """Test with a regular repeating pattern."""
        regular_series = np.array([1, 2, 1, 2, 1, 2, 1, 2])
        result = get_approx_entropy(regular_series)
        assert isinstance(result, float)
        assert result >= 0

    def test_random_series(self):
        """Test with random data."""
        np.random.seed(42)
        random_series = np.random.rand(100)
        result = get_approx_entropy(random_series)
        assert isinstance(result, float)
        assert result >= 0

    def test_pandas_series_input(self):
        """Test with pandas Series input."""
        series = pd.Series([1, 2, 1, 2, 1, 2])
        result = get_approx_entropy(series)
        assert isinstance(result, float)
        assert result >= 0

    def test_custom_order(self):
        """Test with custom embedding dimension."""
        series = np.array([1, 2, 3, 1, 2, 3, 1, 2, 3])
        result = get_approx_entropy(series, order=3)
        assert isinstance(result, float)

    def test_custom_metric(self):
        """Test with custom distance metric."""
        series = np.array([1, 2, 1, 2, 1, 2])
        result = get_approx_entropy(series, metric="euclidean")
        assert isinstance(result, float)

    def test_custom_tolerance(self):
        """Test with custom tolerance threshold."""
        series = np.array([1, 2, 1, 2, 1, 2])
        result = get_approx_entropy(series, r=0.5)
        assert isinstance(result, float)

    def test_default_tolerance_calculation(self):
        """Test that default tolerance is calculated correctly."""
        series = np.array([1, 2, 3, 4, 5])
        result = get_approx_entropy(series)
        assert isinstance(result, float)

    def test_exception_handling(self):
        """Test that exceptions are caught and np.nan is returned."""
        with patch("twiga.core.stats.entropy.ant.app_entropy", side_effect=ValueError("Test error")):
            result = get_approx_entropy(np.array([1, 2, 3]))
            assert np.isnan(result)


class TestPermutationEntropy:
    """Tests for permutation entropy calculation."""

    def test_regular_series(self):
        """Test with a regular repeating pattern."""
        regular_series = np.array([1, 2, 3, 1, 2, 3, 1, 2, 3])
        result = get_permutation_entropy(regular_series)
        assert isinstance(result, float)
        assert 0 <= result <= 1

    def test_random_series(self):
        """Test with random data."""
        np.random.seed(42)
        random_series = np.random.rand(100)
        result = get_permutation_entropy(random_series)
        assert isinstance(result, float)
        assert 0 <= result <= 1

    def test_pandas_series_input(self):
        """Test with pandas Series input."""
        series = pd.Series([1, 2, 3, 1, 2, 3])
        result = get_permutation_entropy(series)
        assert isinstance(result, float)

    def test_custom_order(self):
        """Test with custom embedding dimension."""
        series = np.array([1, 2, 3, 4, 1, 2, 3, 4])
        result = get_permutation_entropy(series, order=4)
        assert isinstance(result, float)

    def test_custom_delay(self):
        """Test with custom time delay."""
        series = np.array([1, 2, 3, 4, 5, 6, 7, 8])
        result = get_permutation_entropy(series, delay=2)
        assert isinstance(result, float)

    def test_non_normalized(self):
        """Test with normalization disabled."""
        series = np.array([1, 2, 3, 1, 2, 3])
        result = get_permutation_entropy(series, normalize=False)
        assert isinstance(result, float)

    def test_exception_handling(self):
        """Test that exceptions are caught and np.nan is returned."""
        with patch("twiga.core.stats.entropy.ant.perm_entropy", side_effect=RuntimeError("Test error")):
            result = get_permutation_entropy(np.array([1, 2, 3]))
            assert np.isnan(result)


class TestSampleEntropy:
    """Tests for sample entropy calculation."""

    def test_regular_series(self):
        """Test with a regular repeating pattern."""
        regular_series = np.array([1, 2, 1, 2, 1, 2, 1, 2])
        result = get_sample_entropy(regular_series)
        assert isinstance(result, float)
        assert result >= 0 or np.isnan(result)

    def test_random_series(self):
        """Test with random data."""
        np.random.seed(42)
        random_series = np.random.rand(100)
        result = get_sample_entropy(random_series)
        assert isinstance(result, float)

    def test_pandas_series_input(self):
        """Test with pandas Series input."""
        series = pd.Series([1, 2, 1, 2, 1, 2])
        result = get_sample_entropy(series)
        assert isinstance(result, float)

    def test_custom_order(self):
        """Test with custom embedding dimension."""
        series = np.array([1, 2, 3, 4, 5, 6, 7, 8])
        result = get_sample_entropy(series, order=3)
        assert isinstance(result, float)

    def test_custom_tolerance(self):
        """Test with custom tolerance threshold."""
        series = np.array([1, 2, 1, 2, 1, 2])
        result = get_sample_entropy(series, r=0.1)
        assert isinstance(result, float)

    def test_default_tolerance_calculation(self):
        """Test that default tolerance is calculated correctly."""
        series = np.array([1, 2, 3, 4, 5])
        result = get_sample_entropy(series)
        assert isinstance(result, float)

    def test_exception_handling(self):
        """Test that exceptions are caught and np.nan is returned."""
        with patch("twiga.core.stats.entropy.ant.sample_entropy", side_effect=ValueError("Test error")):
            result = get_sample_entropy(np.array([1, 2, 3]))
            assert np.isnan(result)


class TestHurstExponent:
    """Tests for Hurst exponent calculation."""

    def test_random_walk(self):
        """Test with random walk data."""
        np.random.seed(42)
        random_walk = np.cumsum(np.random.randn(100))
        result = get_hurst_exponent(random_walk)
        assert isinstance(result, float)

    def test_mean_reverting_series(self):
        """Test with mean-reverting series."""
        series = np.sin(np.linspace(0, 10 * np.pi, 100))
        result = get_hurst_exponent(series)
        assert isinstance(result, float)

    def test_pandas_series_input(self):
        """Test with pandas Series input."""
        series = pd.Series(np.random.rand(100))
        result = get_hurst_exponent(series)
        assert isinstance(result, float)

    def test_exception_handling(self):
        """Test that exceptions are caught and np.nan is returned."""
        with patch("hurst.compute_Hc", side_effect=RuntimeError("Test error")):
            result = get_hurst_exponent(np.array([1, 2, 3]))
            assert np.isnan(result)

    def test_short_series(self):
        """Test with short series."""
        short_series = np.array([1, 2, 3])
        result = get_hurst_exponent(short_series)
        assert isinstance(result, float) or np.isnan(result)


class TestDfaExponent:
    """Tests for DFA exponent calculation."""

    def test_random_walk(self):
        """Test with random walk data."""
        np.random.seed(42)
        random_walk = np.cumsum(np.random.randn(100))
        result = get_dfa_exponent(random_walk)
        assert isinstance(result, float)

    def test_pandas_series_input(self):
        """Test with pandas Series input."""
        series = pd.Series(np.random.rand(100))
        result = get_dfa_exponent(series)
        assert isinstance(result, float)

    def test_exception_handling(self):
        """Test that exceptions are caught and np.nan is returned."""
        with patch("twiga.core.stats.entropy.ant.detrended_fluctuation", side_effect=RuntimeError("Test error")):
            result = get_dfa_exponent(np.array([1, 2, 3]))
            assert np.isnan(result)

    def test_constant_series_returns_nan(self):
        """Test with constant series that fails normalization."""
        series = np.ones(100)
        result = get_dfa_exponent(series)
        assert np.isnan(result)


class TestEntropyComparison:
    """Tests comparing entropy values between different series."""

    def test_regular_vs_random_approx_entropy(self):
        """Regular series should have lower approx entropy than random."""
        regular = np.array([1, 2, 1, 2, 1, 2, 1, 2] * 10)
        np.random.seed(42)
        random = np.random.rand(80)

        regular_entropy = get_approx_entropy(regular)
        random_entropy = get_approx_entropy(random)

        assert regular_entropy < random_entropy

    def test_regular_vs_random_permutation_entropy(self):
        """Regular series should have lower permutation entropy than random."""
        regular = np.array([1, 2, 3, 1, 2, 3] * 10)
        np.random.seed(42)
        random = np.random.rand(60)

        regular_entropy = get_permutation_entropy(regular)
        random_entropy = get_permutation_entropy(random)

        assert regular_entropy < random_entropy

    def test_regular_vs_random_sample_entropy(self):
        """Regular series should have lower sample entropy than random."""
        regular = np.array([1, 2, 1, 2, 1, 2, 1, 2] * 10)
        np.random.seed(42)
        random = np.random.rand(80)

        regular_entropy = get_sample_entropy(regular)
        random_entropy = get_sample_entropy(random)

        assert regular_entropy <= random_entropy
