"""Tests for twiga.core.utils.logger.

Covers:
- _ColourFormatter.format (normal + exc_info branch)
- _PlainFormatter.format (normal + exc_info branch)
- get_logger (with and without twiga prefix)
- configure (console only, with file handler, capture_warnings, idempotent calls)
- LogContext.__enter__ / __exit__ (message augmentation)
- log_section (section divider format)
- _trim_name (short / long dotted names)
- _parse_level (str, int, invalid)
- _is_tty (TTY stream, non-TTY stream, stream without isatty)
"""

from __future__ import annotations

import logging
from pathlib import Path
import sys
import tempfile
from unittest.mock import MagicMock, patch

import pytest

from twiga.core.utils.logger import (
    LogContext,
    _ColourFormatter,
    _is_tty,
    _parse_level,
    _PlainFormatter,
    _trim_name,
    configure,
    get_logger,
    log_section,
)

# ---------------------------------------------------------------------------
# _trim_name
# ---------------------------------------------------------------------------


class TestTrimName:
    """Tests for the _trim_name helper."""

    def test_short_name_unchanged(self) -> None:
        """Names with two or fewer segments are returned unchanged."""
        assert _trim_name("twiga") == "twiga"
        assert _trim_name("twiga.core") == "twiga.core"

    def test_long_name_trimmed_to_two_segments(self) -> None:
        """Long dotted names are shortened to the last two segments."""
        assert _trim_name("twiga.forecaster.core") == "forecaster.core"
        assert _trim_name("a.b.c.d") == "c.d"


# ---------------------------------------------------------------------------
# _parse_level
# ---------------------------------------------------------------------------


class TestParseLevel:
    """Tests for the _parse_level helper."""

    def test_integer_passthrough(self) -> None:
        """Integer levels are returned as-is."""
        assert _parse_level(logging.DEBUG) == logging.DEBUG
        assert _parse_level(logging.WARNING) == logging.WARNING

    def test_string_level_case_insensitive(self) -> None:
        """String level names resolve correctly, case-insensitively."""
        assert _parse_level("DEBUG") == logging.DEBUG
        assert _parse_level("info") == logging.INFO
        assert _parse_level("WARNING") == logging.WARNING
        assert _parse_level("error") == logging.ERROR
        assert _parse_level("CRITICAL") == logging.CRITICAL

    def test_invalid_string_raises_type_error(self) -> None:
        """Unrecognised string raises TypeError."""
        with pytest.raises(TypeError, match="Unknown log level"):
            _parse_level("NONSENSE")


# ---------------------------------------------------------------------------
# _is_tty
# ---------------------------------------------------------------------------


class TestIsTty:
    """Tests for the _is_tty helper."""

    def test_stream_with_isatty_true(self) -> None:
        """Returns True when isatty() returns True."""
        mock_stream = MagicMock()
        mock_stream.isatty.return_value = True
        assert _is_tty(mock_stream) is True

    def test_stream_with_isatty_false(self) -> None:
        """Returns False when isatty() returns False."""
        mock_stream = MagicMock()
        mock_stream.isatty.return_value = False
        assert _is_tty(mock_stream) is False

    def test_stream_without_isatty_returns_false(self) -> None:
        """Returns False when the stream has no isatty attribute."""

        class _NoTTY:
            pass

        assert _is_tty(_NoTTY()) is False


# ---------------------------------------------------------------------------
# _ColourFormatter
# ---------------------------------------------------------------------------


class TestColourFormatter:
    """Tests for _ColourFormatter."""

    def _make_record(self, msg: str = "hello", level: int = logging.INFO) -> logging.LogRecord:
        record = logging.LogRecord(
            name="twiga.forecaster.core",
            level=level,
            pathname="",
            lineno=0,
            msg=msg,
            args=(),
            exc_info=None,
        )
        return record

    def test_format_plain_message(self) -> None:
        """Formatted string contains the message text."""
        fmt = _ColourFormatter()
        record = self._make_record("Test message")
        result = fmt.format(record)
        assert "Test message" in result

    def test_format_includes_level_abbreviation(self) -> None:
        """Formatted string contains the abbreviated level name."""
        fmt = _ColourFormatter()
        record = self._make_record("x", logging.WARNING)
        result = fmt.format(record)
        assert "WRN" in result

    def test_format_with_exc_info(self) -> None:
        """Traceback is appended when exc_info is set."""
        fmt = _ColourFormatter()
        try:
            raise ValueError("boom")  # noqa: TRY301
        except ValueError:
            exc_info = sys.exc_info()

        record = self._make_record("Error occurred")
        record.exc_info = exc_info
        result = fmt.format(record)
        assert "ValueError" in result
        assert "boom" in result

    def test_format_all_levels(self) -> None:
        """All known level abbreviations render without error."""
        fmt = _ColourFormatter()
        abbrevs = {"DEBUG": "DBG", "INFO": "INF", "WARNING": "WRN", "ERROR": "ERR", "CRITICAL": "CRT"}
        for levelname, abbrev in abbrevs.items():
            record = self._make_record("msg", getattr(logging, levelname))
            result = fmt.format(record)
            assert abbrev in result


# ---------------------------------------------------------------------------
# _PlainFormatter
# ---------------------------------------------------------------------------


class TestPlainFormatter:
    """Tests for _PlainFormatter."""

    def _make_record(self, msg: str = "hello", level: int = logging.INFO) -> logging.LogRecord:
        return logging.LogRecord(
            name="twiga.core",
            level=level,
            pathname="",
            lineno=0,
            msg=msg,
            args=(),
            exc_info=None,
        )

    def test_format_plain_message(self) -> None:
        """Formatted string contains the message without ANSI codes."""
        fmt = _PlainFormatter()
        record = self._make_record("plain text")
        result = fmt.format(record)
        assert "plain text" in result
        assert "\033[" not in result

    def test_format_with_exc_info(self) -> None:
        """Traceback is appended when exc_info is set."""
        fmt = _PlainFormatter()
        try:
            raise RuntimeError("oops")  # noqa: TRY301
        except RuntimeError:
            exc_info = sys.exc_info()

        record = self._make_record("Error occurred")
        record.exc_info = exc_info
        result = fmt.format(record)
        assert "RuntimeError" in result
        assert "oops" in result

    def test_format_includes_level_name(self) -> None:
        """Formatted string includes the level name."""
        fmt = _PlainFormatter()
        record = self._make_record("x", logging.ERROR)
        result = fmt.format(record)
        assert "ERROR" in result


# ---------------------------------------------------------------------------
# get_logger
# ---------------------------------------------------------------------------


class TestGetLogger:
    """Tests for get_logger."""

    def test_returns_logger_instance(self) -> None:
        """get_logger returns a logging.Logger."""
        logger = get_logger("twiga.test_module")
        assert isinstance(logger, logging.Logger)

    def test_adds_twiga_prefix_if_missing(self) -> None:
        """Names not starting with 'twiga' are prefixed automatically."""
        logger = get_logger("mymodule")
        assert logger.name == "twiga.mymodule"

    def test_no_double_prefix(self) -> None:
        """Names already starting with 'twiga' are not double-prefixed."""
        logger = get_logger("twiga.forecaster.core")
        assert logger.name == "twiga.forecaster.core"


# ---------------------------------------------------------------------------
# configure
# ---------------------------------------------------------------------------


class TestConfigure:
    """Tests for the configure function."""

    def test_configure_returns_root_logger(self) -> None:
        """Configure returns the 'twiga' root logger."""
        root = configure(level="WARNING", colour=False)
        assert root.name == "twiga"

    def test_configure_clears_old_handlers(self) -> None:
        """Calling configure twice does not accumulate handlers."""
        configure(level="INFO", colour=False)
        configure(level="INFO", colour=False)
        root = logging.getLogger("twiga")
        assert len(root.handlers) == 1

    def test_configure_with_file_handler(self, tmp_path: Path) -> None:
        """A FileHandler is added when log_file is specified."""
        log_file = tmp_path / "subdir" / "run.log"
        root = configure(level="INFO", colour=False, log_file=log_file)
        handler_types = [type(h).__name__ for h in root.handlers]
        assert "FileHandler" in handler_types
        assert log_file.exists()

    def test_configure_file_creates_parent_dirs(self, tmp_path: Path) -> None:
        """Parent directories for log_file are created automatically."""
        log_file = tmp_path / "a" / "b" / "c" / "run.log"
        configure(level="DEBUG", colour=False, log_file=log_file)
        assert log_file.parent.exists()

    def test_configure_with_colour_false_uses_plain_formatter(self) -> None:
        """Console handler uses _PlainFormatter when colour=False."""
        root = configure(level="INFO", colour=False)
        console_handlers = [
            h for h in root.handlers if isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler)
        ]
        assert len(console_handlers) >= 1
        assert isinstance(console_handlers[0].formatter, _PlainFormatter)

    def test_configure_with_colour_true_on_tty_uses_colour_formatter(self) -> None:
        """Console handler uses _ColourFormatter when colour=True and stream is a TTY."""
        with patch("twiga.core.utils.logger._is_tty", return_value=True):
            root = configure(level="INFO", colour=True)
        console_handlers = [
            h for h in root.handlers if isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler)
        ]
        assert isinstance(console_handlers[0].formatter, _ColourFormatter)

    def test_configure_capture_warnings(self) -> None:
        """Configure with capture_warnings=True does not raise."""
        configure(level="INFO", colour=False, capture_warnings=True)

    def test_configure_invalid_level_raises(self) -> None:
        """Configure with an unrecognised level raises TypeError."""
        with pytest.raises(TypeError, match="Unknown log level"):
            configure(level="BADLEVEL", colour=False)


# ---------------------------------------------------------------------------
# LogContext
# ---------------------------------------------------------------------------


class TestLogContext:
    """Tests for LogContext context manager."""

    def test_context_appends_key_value_to_messages(self) -> None:
        """Messages emitted inside the context include key=value pairs."""
        logger = get_logger("twiga.test_context")

        captured: list[str] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                captured.append(self.format(record))

        capture_handler = _Capture()
        logger.addHandler(capture_handler)
        logger.setLevel(logging.DEBUG)

        with LogContext(logger, model="MLP", fold=2):
            logger.info("Training started")

        logger.removeHandler(capture_handler)

        assert len(captured) == 1
        assert "model=MLP" in captured[0]
        assert "fold=2" in captured[0]

    def test_context_removes_filter_on_exit(self) -> None:
        """Filter is removed after the context exits."""
        logger = get_logger("twiga.test_context_exit")
        initial_filter_count = len(logger.filters)

        with LogContext(logger, key="val"):
            assert len(logger.filters) == initial_filter_count + 1

        assert len(logger.filters) == initial_filter_count

    def test_context_returns_self(self) -> None:
        """__enter__ returns the LogContext instance."""
        logger = get_logger("twiga.test_context_self")
        ctx = LogContext(logger, x=1)
        result = ctx.__enter__()
        assert result is ctx
        ctx.__exit__(None, None, None)

    def test_message_not_augmented_after_exit(self) -> None:
        """Messages after the context are not augmented."""
        logger = get_logger("twiga.test_context_after")
        captured: list[str] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                captured.append(record.getMessage())

        capture_handler = _Capture()
        logger.addHandler(capture_handler)
        logger.setLevel(logging.DEBUG)

        with LogContext(logger, z=99):
            pass

        logger.info("after context")
        logger.removeHandler(capture_handler)

        assert any("after context" in m for m in captured)
        assert all("z=99" not in m for m in captured)


# ---------------------------------------------------------------------------
# log_section
# ---------------------------------------------------------------------------


class TestLogSection:
    """Tests for log_section."""

    def test_log_section_emits_info_record(self) -> None:
        """log_section calls logger.info with a divider string."""
        logger = get_logger("twiga.test_section")
        captured: list[str] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                captured.append(record.getMessage())

        h = _Capture()
        logger.addHandler(h)
        logger.setLevel(logging.DEBUG)

        log_section(logger, "Data Loading")
        logger.removeHandler(h)

        assert len(captured) == 1
        assert "Data Loading" in captured[0]
        assert "─" in captured[0]

    def test_log_section_default_width(self) -> None:
        """Section divider total length is approximately the configured width."""
        logger = get_logger("twiga.test_section_width")
        captured: list[str] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                captured.append(record.getMessage())

        h = _Capture()
        logger.addHandler(h)
        logger.setLevel(logging.DEBUG)
        log_section(logger, "X", width=20)
        logger.removeHandler(h)

        # Total len should be roughly width (title + padding + spaces)
        assert captured[0] != ""

    def test_log_section_long_title_no_padding(self) -> None:
        """Long title produces a divider with zero or minimal padding."""
        logger = get_logger("twiga.test_section_long")
        captured: list[str] = []

        class _Capture(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                captured.append(record.getMessage())

        h = _Capture()
        logger.addHandler(h)
        logger.setLevel(logging.DEBUG)
        long_title = "A" * 100
        log_section(logger, long_title, width=10)
        logger.removeHandler(h)

        assert long_title in captured[0]
