import numpy as np
import pandas as pd
import pytest

from twiga.core.stats.utils import _validate_input, get_optimal_lags, get_sample_per_day, normalise_series, prepare_data


class TestValidateInput:
    def test_valid_input(self):
        """Test validation passes with valid input."""
        data = pd.DataFrame({"value": [1.0, 2.0, 3.0], "timestamp": pd.date_range("2023-01-01", periods=3)})
        _validate_input(data, "value", "timestamp")

    def test_input_not_dataframe(self):
        """Test raises ValueError when input is not a DataFrame."""
        with pytest.raises(TypeError, match="Input data must be a pandas DataFrame"):
            _validate_input([1, 2, 3], "value", "timestamp")

    def test_empty_dataframe(self):
        """Test raises ValueError for empty DataFrame."""
        data = pd.DataFrame()
        with pytest.raises(ValueError, match="Input DataFrame is empty"):
            _validate_input(data, "value", "timestamp")

    def test_missing_value_column(self):
        """Test raises ValueError when value column missing."""
        data = pd.DataFrame({"timestamp": [1, 2, 3]})
        with pytest.raises(ValueError, match="Value column 'value' not found"):
            _validate_input(data, "value", "timestamp")

    def test_missing_timestamp_column(self):
        """Test raises ValueError when timestamp column missing."""
        data = pd.DataFrame({"value": [1, 2, 3]})
        with pytest.raises(ValueError, match="Timestamp column 'timestamp' not found"):
            _validate_input(data, "value", "timestamp")

    def test_all_nan_value_column(self):
        """Test raises ValueError when value column contains only NaN."""
        data = pd.DataFrame({"value": [np.nan, np.nan, np.nan], "timestamp": [1, 2, 3]})
        with pytest.raises(ValueError, match="Value column 'value' contains only NaN values"):
            _validate_input(data, "value", "timestamp")


class TestNormaliseSeries:
    def test_normalize_valid_series(self):
        """Test normalization of valid series."""
        series = pd.Series([1.0, 2.0, 3.0, 4.0, 5.0])
        result = normalise_series(series)
        assert np.isclose(result.mean(), 0.0, atol=1e-10)
        assert np.isclose(result.std(), 1.0)

    def test_normalize_with_nan_values(self):
        """Test normalization drops NaN values."""
        series = pd.Series([1.0, np.nan, 3.0, 4.0, 5.0])
        result = normalise_series(series)
        assert len(result) == 4
        assert np.isclose(result.mean(), 0.0, atol=1e-10)

    def test_normalize_empty_after_dropna(self):
        """Test raises ValueError for series empty after dropping NaN."""
        series = pd.Series([np.nan, np.nan, np.nan])
        with pytest.raises(ValueError, match="Input series is empty after dropping NaN"):
            normalise_series(series)

    def test_normalize_zero_variance(self):
        """Test raises ValueError for series with zero variance."""
        series = pd.Series([5.0, 5.0, 5.0, 5.0])
        with pytest.raises(ValueError, match="Series has zero or invalid variance"):
            normalise_series(series)

    def test_normalize_np_array_input(self):
        """Test normalization accepts numpy array input."""
        array = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        result = normalise_series(array)
        assert isinstance(result, pd.Series)
        assert np.isclose(result.mean(), 0.0, atol=1e-10)


class TestPrepareData:
    def test_prepare_valid_data(self):
        """Test data preparation with valid input."""
        data = pd.DataFrame(
            {"value": np.arange(1, 35, dtype=float), "timestamp": pd.date_range("2023-01-01", periods=34)}
        )
        result = prepare_data(data, "value", "timestamp")
        assert len(result) == 34
        assert (result > 0).all()

    def test_prepare_data_removes_zeros(self):
        """Test data preparation removes zero values."""
        data = pd.DataFrame({"value": [0.0, 1.0, 2.0, 3.0] * 10, "timestamp": pd.date_range("2023-01-01", periods=40)})
        result = prepare_data(data, "value", "timestamp", min_data_points=20)
        assert (result > 0).all()

    def test_prepare_data_insufficient_points(self):
        """Test raises ValueError when insufficient data points."""
        data = pd.DataFrame({"value": [1.0, 2.0, 3.0], "timestamp": pd.date_range("2023-01-01", periods=3)})
        with pytest.raises(ValueError, match="Insufficient non-zero data points"):
            prepare_data(data, "value", "timestamp", min_data_points=10)

    def test_prepare_data_sorts_by_timestamp(self):
        """Test data is sorted by timestamp."""
        data = pd.DataFrame({"value": [3.0, 1.0, 2.0] * 15, "timestamp": pd.date_range("2023-01-01", periods=45)[::-1]})
        result = prepare_data(data, "value", "timestamp")
        assert result.is_monotonic_increasing or len(result) > 0

    def test_prepare_data_removes_nan(self):
        """Test data preparation removes NaN values."""
        data = pd.DataFrame(
            {"value": [1.0, np.nan, 2.0, 3.0] * 10, "timestamp": pd.date_range("2023-01-01", periods=40)}
        )
        result = prepare_data(data, "value", "timestamp", min_data_points=30)
        assert not result.isna().any()

    def test_prepare_data_constant_series(self):
        """Test raises ValueError for constant series."""
        data = pd.DataFrame({"value": [5.0] * 40, "timestamp": pd.date_range("2023-01-01", periods=40)})
        with pytest.raises(ValueError, match="Series has zero or invalid variance"):
            prepare_data(data, "value", "timestamp")

    def test_prepare_data_with_non_finite_values(self):
        """Test raises ValueError for non-finite values."""
        data = pd.DataFrame(
            {"value": [1.0, 2.0, np.inf, 4.0] * 10, "timestamp": pd.date_range("2023-01-01", periods=40)}
        )
        with pytest.raises(ValueError, match="non-finite values"):
            prepare_data(data, "value", "timestamp")

            class TestGetSamplePerDay:
                def test_get_sample_per_day_30min(self):
                    """Test sample calculation for 30 minute frequency."""
                    result = get_sample_per_day("30min")
                    assert result == 48

                def test_get_sample_per_day_1h(self):
                    """Test sample calculation for 1 hour frequency."""
                    result = get_sample_per_day("1h")
                    assert result == 24

                def test_get_sample_per_day_h_shorthand(self):
                    """Test sample calculation for hour shorthand."""
                    result = get_sample_per_day("h")
                    assert result == 24

                def test_get_sample_per_day_15t(self):
                    """Test sample calculation for 15 minute frequency."""
                    result = get_sample_per_day("15T")
                    assert result == 96

                def test_get_sample_per_day_timedelta(self):
                    """Test sample calculation with pandas Timedelta."""
                    result = get_sample_per_day(pd.Timedelta(hours=1))
                    assert result == 24

                def test_get_sample_per_day_seconds(self):
                    """Test sample calculation for seconds frequency."""
                    result = get_sample_per_day("1s")
                    assert result == 86400

                def test_get_sample_per_day_invalid_string(self):
                    """Test raises ValueError for invalid frequency string."""
                    with pytest.raises(ValueError, match="Unable to parse frequency"):
                        get_sample_per_day("invalid")

                def test_get_sample_per_day_empty_string(self):
                    """Test raises ValueError for empty frequency string."""
                    with pytest.raises(ValueError, match="Frequency must be a non-empty string"):
                        get_sample_per_day("")

                def test_get_sample_per_day_negative_timedelta(self):
                    """Test raises ValueError for negative Timedelta."""
                    with pytest.raises(ValueError, match="Frequency must represent a positive time duration"):
                        get_sample_per_day(pd.Timedelta(hours=-1))

                def test_get_sample_per_day_not_string_or_timedelta(self):
                    """Test raises ValueError for non-string, non-Timedelta input."""
                    with pytest.raises(ValueError, match="Frequency must be a non-empty string"):
                        get_sample_per_day(123)

            class TestGetOptimalLags:
                def test_get_optimal_lags_valid_series(self):
                    """Test optimal lag selection with valid series."""
                    series = pd.Series(np.random.randn(100))
                    result = get_optimal_lags(series, lb_test=False)
                    assert "AIC" in result
                    assert "BIC" in result
                    assert "HQIC" in result
                    assert result["valid_models"] > 0
                    assert isinstance(result["AIC"], (int, np.integer))

                def test_get_optimal_lags_insufficient_points(self):
                    """Test raises ValueError for series with insufficient data points."""
                    series = pd.Series([1.0, 2.0, 3.0])
                    with pytest.raises(ValueError, match="Series too short"):
                        get_optimal_lags(series)

                def test_get_optimal_lags_with_custom_max_lags(self):
                    """Test optimal lag selection with custom max_lags."""
                    series = pd.Series(np.random.randn(100))
                    result = get_optimal_lags(series, max_lags=10, lb_test=False)
                    assert result["max_lags_tested"] <= 10

                def test_get_optimal_lags_with_period(self):
                    """Test optimal lag selection with seasonal period."""
                    series = pd.Series(np.random.randn(200))
                    result = get_optimal_lags(series, period="h", lb_test=False)
                    assert result["max_lags_tested"] >= 24

                def test_get_optimal_lags_with_invalid_period(self):
                    """Test optimal lag selection handles invalid period gracefully."""
                    series = pd.Series(np.random.randn(100))
                    result = get_optimal_lags(series, period="invalid", lb_test=False)
                    assert "AIC" in result

                def test_get_optimal_lags_with_lb_test(self):
                    """Test optimal lag selection includes Ljung-Box p-values."""
                    series = pd.Series(np.random.randn(100))
                    result = get_optimal_lags(series, lb_test=True)
                    assert any(p is not None or np.isnan(p) for p in result["criteria_values"]["lb_pvalue"])

                def test_get_optimal_lags_numpy_array_input(self):
                    """Test optimal lag selection accepts numpy array input."""
                    series = np.random.randn(100)
                    result = get_optimal_lags(series, lb_test=False)
                    assert "AIC" in result

                def test_get_optimal_lags_returns_consistent_structure(self):
                    """Test optimal lag result has expected structure."""
                    series = pd.Series(np.random.randn(100))
                    result = get_optimal_lags(series, lb_test=False)
                    assert "criteria_values" in result
                    assert "max_lags_tested" in result
                    assert "valid_models" in result
                    assert isinstance(result["criteria_values"], dict)
                    assert "lags" in result["criteria_values"]
                    assert "aic" in result["criteria_values"]
                    assert "bic" in result["criteria_values"]
                    assert "hqic" in result["criteria_values"]
