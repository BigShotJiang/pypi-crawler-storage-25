"""Tests for theory-informed entropy parameter recommendation."""

import numpy as np

from twiga.core.stats.utils import get_entropy_parameters as recommend_entropy_parameters


def test_recommend_sample_params_in_theoretical_range() -> None:
    series = np.random.default_rng(42).normal(0.0, 1.0, 300)
    params = recommend_entropy_parameters(series, method="sample")

    assert params["order"] in {2, 3}
    assert params["r"] > 0
    assert np.isclose(params["r"], params["tolerance"])


def test_recommend_approximate_params_respects_m_bounds() -> None:
    series = np.random.default_rng(123).normal(0.0, 1.0, 80)
    params = recommend_entropy_parameters(series, method="approximate", period="1h")

    assert params["order"] in {2, 3}


def test_recommend_permutation_params_order_and_delay() -> None:
    series = np.random.default_rng(7).normal(0.0, 1.0, 1200)
    params = recommend_entropy_parameters(series, method="permutation")

    assert 3 <= params["order"] <= 7
    assert params["delay"] >= 1


def test_recommend_params_invalid_method_raises() -> None:
    series = np.random.default_rng(99).normal(0.0, 1.0, 200)

    try:
        recommend_entropy_parameters(series, method="unknown")
    except ValueError as exc:
        assert "Unsupported method" in str(exc)
    else:
        raise AssertionError("Expected ValueError for unknown method")
