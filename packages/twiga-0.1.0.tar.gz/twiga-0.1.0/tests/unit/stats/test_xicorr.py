"""Tests for twiga.core.stats.xicorr."""

import numpy as np
import pandas as pd
import pytest

from twiga.core.stats.xicorr import compute_xicorr


@pytest.fixture
def sample_data():
    rng = np.random.default_rng(42)
    n = 100
    x = rng.standard_normal(n)
    return pd.DataFrame(
        {
            "x1": x,
            "x2": rng.standard_normal(n),
            "x3": x**2,  # non-linear relationship
            "target": x + rng.standard_normal(n) * 0.2,
        }
    )


class TestComputeXicorr:
    def test_returns_dataframe(self, sample_data):
        result = compute_xicorr(sample_data, "target", ["x1", "x2"])
        assert isinstance(result, pd.DataFrame)

    def test_columns(self, sample_data):
        result = compute_xicorr(sample_data, "target", ["x1", "x2"])
        assert set(result.columns) >= {"col1", "col2", "xicor", "p_value"}

    def test_row_count_matches_features(self, sample_data):
        features = ["x1", "x2", "x3"]
        result = compute_xicorr(sample_data, "target", features)
        assert len(result) == len(features)

    def test_xicor_sorted_descending(self, sample_data):
        result = compute_xicorr(sample_data, "target", ["x1", "x2", "x3"])
        scores = result["xicor"].dropna().tolist()
        assert scores == sorted(scores, reverse=True)

    def test_correlated_feature_higher_than_noise(self, sample_data):
        result = compute_xicorr(sample_data, "target", ["x1", "x2"])
        scores = result.set_index("col2")["xicor"]
        assert scores["x1"] > scores["x2"]

    def test_constant_column_returns_nan(self):
        df = pd.DataFrame({"target": [1.0, 2.0, 3.0], "const": [5.0, 5.0, 5.0]})
        result = compute_xicorr(df, "target", ["const"])
        assert result["xicor"].isna().all()

    def test_insufficient_data_returns_empty(self):
        df = pd.DataFrame({"target": [1.0], "x": [1.0]})
        result = compute_xicorr(df, "target", ["x"])
        assert result.empty

    def test_ties_false_no_error(self, sample_data):
        result = compute_xicorr(sample_data, "target", ["x1"], ties=False)
        assert len(result) == 1

    def test_col1_is_target(self, sample_data):
        result = compute_xicorr(sample_data, "target", ["x1"])
        assert (result["col1"] == "target").all()
