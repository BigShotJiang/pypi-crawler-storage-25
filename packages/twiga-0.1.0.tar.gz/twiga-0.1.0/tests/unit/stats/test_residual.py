"""Tests for twiga.core.stats.residual.

Covers:
- leverage_statistic: 1D input auto-reshape, 2D input, output range
- get_standardized_residual: shape, near-zero residuals
- cooks_distance: formula verification, shape
"""

from __future__ import annotations

import numpy as np
import pytest

from twiga.core.stats.residual import (
    cooks_distance,
    get_standardized_residual,
    leverage_statistic,
)

# ---------------------------------------------------------------------------
# leverage_statistic
# ---------------------------------------------------------------------------


class TestLeverageStatistic:
    """Tests for leverage_statistic."""

    def test_1d_input_reshaped(self) -> None:
        """1-D input array is reshaped to (n, 1) internally."""
        x = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        result = leverage_statistic(x)
        assert result.shape == (5,)

    def test_2d_input(self) -> None:
        """2-D input returns leverage values of shape (n_samples,)."""
        rng = np.random.default_rng(0)
        x = rng.standard_normal((20, 3))
        result = leverage_statistic(x)
        assert result.shape == (20,)

    def test_leverage_values_in_0_1(self) -> None:
        """Leverage values are between 0 and 1 inclusive."""
        rng = np.random.default_rng(1)
        x = rng.standard_normal((30, 4))
        result = leverage_statistic(x)
        assert np.all(result >= 0)
        assert np.all(result <= 1.0 + 1e-10)

    def test_leverage_sum_equals_n_params(self) -> None:
        """Sum of leverage values equals n_params = n_features + 1 (intercept)."""
        # Use full-rank x to ensure trace(H) = n_params
        rng = np.random.default_rng(42)
        x = rng.standard_normal((20, 3))
        result = leverage_statistic(x)
        # p+1 = 4 (3 features + intercept)
        np.testing.assert_allclose(result.sum(), 4.0, rtol=1e-5)

    def test_simple_case_known_values(self) -> None:
        """Leverage values are finite and non-negative for a simple 2-point case."""
        x = np.array([[1.0], [2.0], [3.0]])
        result = leverage_statistic(x)
        assert result.shape == (3,)
        assert np.all(np.isfinite(result))


# ---------------------------------------------------------------------------
# get_standardized_residual
# ---------------------------------------------------------------------------


class TestGetStandardizedResidual:
    """Tests for get_standardized_residual."""

    def test_output_shape(self) -> None:
        """Output has same shape as y_true."""
        rng = np.random.default_rng(42)
        n = 20
        x = rng.standard_normal((n, 3))
        y_true = rng.standard_normal(n)
        y_pred = y_true + rng.standard_normal(n) * 0.1
        result = get_standardized_residual(y_true, y_pred, x)
        assert result.shape == (n,)

    def test_standardized_residuals_are_finite(self) -> None:
        """Standardized residuals are finite for well-conditioned inputs."""
        rng = np.random.default_rng(7)
        n = 30
        x = rng.standard_normal((n, 2))
        y_true = rng.standard_normal(n)
        y_pred = y_true + rng.standard_normal(n) * 0.5
        result = get_standardized_residual(y_true, y_pred, x)
        assert np.all(np.isfinite(result))

    def test_perfect_prediction_near_zero_residuals(self) -> None:
        """Nearly perfect predictions yield residuals close to zero."""
        rng = np.random.default_rng(3)
        n = 50
        x = rng.standard_normal((n, 2))
        y_true = rng.standard_normal(n)
        y_pred = y_true + rng.standard_normal(n) * 1e-9
        result = get_standardized_residual(y_true, y_pred, x)
        assert np.all(np.isfinite(result))


# ---------------------------------------------------------------------------
# cooks_distance
# ---------------------------------------------------------------------------


class TestCooksDistance:
    """Tests for cooks_distance."""

    def test_output_shape(self) -> None:
        """Output has same shape as standardized_residuals."""
        std_res = np.array([1.0, 0.5, 2.0, 1.5])
        lev = np.array([0.2, 0.3, 0.4, 0.1])
        result = cooks_distance(std_res, lev, n_features=2)
        assert result.shape == (4,)

    def test_non_negative_values(self) -> None:
        """Cook's distance values are non-negative."""
        rng = np.random.default_rng(0)
        n = 20
        x = rng.standard_normal((n, 3))
        y_true = rng.standard_normal(n)
        y_pred = y_true + rng.standard_normal(n) * 0.3
        std_res = get_standardized_residual(y_true, y_pred, x)
        lev = leverage_statistic(x)
        result = cooks_distance(std_res, lev, n_features=3)
        assert np.all(result >= 0)

    def test_formula_simple_case(self) -> None:
        """Verify Cook's distance formula: (r^2 / (p+1)) * h / (1 - h)."""
        std_res = np.array([2.0])
        lev = np.array([0.5])
        n_features = 1
        result = cooks_distance(std_res, lev, n_features=n_features)
        expected = (2.0**2 / (n_features + 1)) * (0.5 / (1 - 0.5))
        np.testing.assert_allclose(result, [expected], rtol=1e-6)

    def test_end_to_end_with_leverage(self) -> None:
        """End-to-end: leverage → standardized residual → cooks_distance."""
        rng = np.random.default_rng(99)
        n, p = 40, 2
        x = rng.standard_normal((n, p))
        y_true = rng.standard_normal(n)
        y_pred = y_true + rng.standard_normal(n) * 0.2
        lev = leverage_statistic(x)
        std_res = get_standardized_residual(y_true, y_pred, x)
        dist = cooks_distance(std_res, lev, n_features=p)
        assert dist.shape == (n,)
        assert np.all(np.isfinite(dist))
