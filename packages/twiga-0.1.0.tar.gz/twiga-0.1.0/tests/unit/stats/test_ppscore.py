"""Tests for twiga.core.stats.ppscore."""

import numpy as np
import pandas as pd
import pytest

from twiga.core.stats.ppscore import compute_ppscore


@pytest.fixture
def regression_df():
    rng = np.random.default_rng(7)
    n = 200
    x = rng.standard_normal(n)
    return pd.DataFrame({"x": x, "noise": rng.standard_normal(n), "y": x * 3 + rng.standard_normal(n) * 0.5})


class TestComputePpscore:
    def test_returns_dict(self, regression_df):
        result = compute_ppscore(regression_df, "x", "y")
        assert isinstance(result, dict)

    def test_required_keys_present(self, regression_df):
        result = compute_ppscore(regression_df, "x", "y")
        assert {"x", "y", "ppscore", "case", "baseline_score", "model_score", "error"} == set(result.keys())

    def test_ppscore_in_0_1(self, regression_df):
        result = compute_ppscore(regression_df, "x", "y")
        assert 0.0 <= result["ppscore"] <= 1.0

    def test_correlated_feature_beats_noise(self, regression_df):
        pps_signal = compute_ppscore(regression_df, "x", "y")["ppscore"]
        pps_noise = compute_ppscore(regression_df, "noise", "y")["ppscore"]
        assert pps_signal >= pps_noise

    def test_insufficient_data_returns_error_dict(self):
        df = pd.DataFrame({"x": [1, 2], "y": [1, 2]})
        result = compute_ppscore(df, "x", "y", cross_validation=4)
        assert result["ppscore"] == 0.0
        assert result["error"] is not None

    def test_constant_target_returns_error_dict(self):
        df = pd.DataFrame({"x": np.arange(50, dtype=float), "y": np.ones(50)})
        result = compute_ppscore(df, "x", "y")
        assert result["ppscore"] == 0.0

    def test_catch_errors_true_returns_error_dict_on_bad_input(self):
        # Constant target → early-exit error dict, catch_errors has no effect here
        df = pd.DataFrame({"x": np.arange(50, dtype=float), "y": np.ones(50)})
        result = compute_ppscore(df, "x", "y", catch_errors=True)
        assert result["ppscore"] == 0.0
        assert result["error"] is not None

    def test_classification_case_detected(self):
        rng = np.random.default_rng(1)
        n = 100
        df = pd.DataFrame({"x": rng.standard_normal(n), "y": rng.choice(["A", "B"], n)})
        result = compute_ppscore(df, "x", "y")
        assert result["case"] == "classification"
