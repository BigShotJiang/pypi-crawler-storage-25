"""Tests for twiga.core.stats.association.

Covers:
- rank_correlation: output shape/columns, supported methods, NaN handling
- compute_anova_f: regression and classification tasks, normalize flag
- compute_chi2: basic output, negative-value guard
"""

import numpy as np
import pandas as pd
import pytest

from twiga.core.stats.association import compute_anova_f, compute_chi2, rank_correlation


@pytest.fixture
def sample_data():
    rng = np.random.default_rng(42)
    n = 100
    return pd.DataFrame(
        {
            "x1": rng.standard_normal(n),
            "x2": np.linspace(0, 1, n),
            "x3": rng.integers(0, 10, n).astype(float),
            "target": rng.standard_normal(n),
        }
    )


# ---------------------------------------------------------------------------
# rank_correlation
# ---------------------------------------------------------------------------


class TestRankCorrelation:
    def test_returns_dataframe(self, sample_data):
        result = rank_correlation(sample_data, "target", ["x1", "x2"])
        assert isinstance(result, pd.DataFrame)

    def test_columns(self, sample_data):
        result = rank_correlation(sample_data, "target", ["x1", "x2"])
        assert list(result.columns) == ["target", "feature", "correlation"]

    def test_row_count_matches_features(self, sample_data):
        features = ["x1", "x2", "x3"]
        result = rank_correlation(sample_data, "target", features)
        assert len(result) == len(features)

    def test_target_column_filled(self, sample_data):
        result = rank_correlation(sample_data, "target", ["x1"])
        assert (result["target"] == "target").all()

    @pytest.mark.parametrize("method", ["pearson", "spearman", "kendall"])
    def test_supported_methods(self, sample_data, method):
        result = rank_correlation(sample_data, "target", ["x1", "x2"], method=method)
        assert not result["correlation"].isna().any()

    def test_sorted_by_absolute_correlation(self, sample_data):
        result = rank_correlation(sample_data, "target", ["x1", "x2", "x3"])
        abs_vals = result["correlation"].abs().tolist()
        assert abs_vals == sorted(abs_vals, reverse=True)

    def test_all_nan_column_returns_empty(self):
        df = pd.DataFrame({"target": [1.0, 2.0, 3.0], "x": [np.nan, np.nan, np.nan]})
        result = rank_correlation(df, "target", ["x"])
        assert result.empty or result["correlation"].isna().all()


# ---------------------------------------------------------------------------
# compute_anova_f
# ---------------------------------------------------------------------------


class TestComputeAnovaF:
    def test_returns_two_dataframes(self, sample_data):
        f_df, p_df = compute_anova_f(sample_data, "target", ["x1", "x2"])
        assert isinstance(f_df, pd.DataFrame)
        assert isinstance(p_df, pd.DataFrame)

    def test_f_scores_columns(self, sample_data):
        f_df, _ = compute_anova_f(sample_data, "target", ["x1", "x2"])
        assert "f_score" in f_df.columns
        assert "feature" in f_df.columns

    def test_p_values_between_0_and_1(self, sample_data):
        _, p_df = compute_anova_f(sample_data, "target", ["x1", "x2"])
        assert (p_df["p_value"] >= 0).all()
        assert (p_df["p_value"] <= 1).all()

    def test_normalize_scales_to_0_1(self, sample_data):
        f_df, _ = compute_anova_f(sample_data, "target", ["x1", "x2"], normalize=True)
        assert f_df["f_score"].max() <= 1.0 + 1e-9

    def test_invalid_task_raises(self, sample_data):
        with pytest.raises(ValueError, match="task must be"):
            compute_anova_f(sample_data, "target", ["x1"], task="unknown")

    def test_string_features_coerced_to_list(self, sample_data):
        f_df, _ = compute_anova_f(sample_data, "target", "x1")
        assert len(f_df) == 1


# ---------------------------------------------------------------------------
# compute_chi2
# ---------------------------------------------------------------------------


class TestComputeChi2:
    @pytest.fixture
    def classification_data(self):
        rng = np.random.default_rng(0)
        n = 80
        return pd.DataFrame(
            {
                "x1": rng.integers(0, 5, n).astype(float),
                "x2": rng.integers(0, 3, n).astype(float),
                "label": rng.integers(0, 2, n),
            }
        )

    def test_returns_dataframe(self, classification_data):
        result = compute_chi2(classification_data, "label", ["x1", "x2"])
        assert isinstance(result, pd.DataFrame)

    def test_output_columns(self, classification_data):
        result = compute_chi2(classification_data, "label", ["x1", "x2"])
        assert "chi2_score" in result.columns
        assert "p_value" in result.columns

    def test_negative_features_raises(self, classification_data):
        classification_data["x1"] -= 10  # introduce negatives
        with pytest.raises(ValueError, match="non-negative"):
            compute_chi2(classification_data, "label", ["x1"])

    def test_row_count_matches_features(self, classification_data):
        result = compute_chi2(classification_data, "label", ["x1", "x2"])
        assert len(result) == 2
