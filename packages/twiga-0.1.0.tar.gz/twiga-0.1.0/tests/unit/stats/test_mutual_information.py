"""Tests for twiga.core.stats.mutual_information."""

import numpy as np
import pandas as pd
import pytest

from twiga.core.stats.mutual_information import compute_mutual_information


@pytest.fixture
def regression_data():
    rng = np.random.default_rng(0)
    n = 120
    x = rng.standard_normal(n)
    return pd.DataFrame({"x1": x, "x2": rng.standard_normal(n), "target": x * 2 + rng.standard_normal(n) * 0.1})


class TestComputeMutualInformation:
    def test_returns_pivoted_dataframe_by_default(self, regression_data):
        result = compute_mutual_information(regression_data, "target", ["x1", "x2"])
        assert isinstance(result, pd.DataFrame)
        assert result.index.name == "feature"

    def test_non_pivoted_has_expected_columns(self, regression_data):
        result = compute_mutual_information(regression_data, "target", ["x1", "x2"], pivot=False)
        assert set(result.columns) == {"target", "feature", "score"}

    def test_scores_are_non_negative(self, regression_data):
        result = compute_mutual_information(regression_data, "target", ["x1", "x2"], pivot=False)
        assert (result["score"] >= 0).all()

    def test_row_count_matches_features(self, regression_data):
        result = compute_mutual_information(regression_data, "target", ["x1", "x2"], pivot=False)
        assert len(result) == 2

    def test_correlated_feature_has_higher_mi(self, regression_data):
        result = compute_mutual_information(regression_data, "target", ["x1", "x2"], pivot=False)
        scores = result.set_index("feature")["score"]
        assert scores["x1"] > scores["x2"]

    def test_threshold_filters_low_scores(self, regression_data):
        result = compute_mutual_information(regression_data, "target", ["x1", "x2"], threshold=0.5, pivot=False)
        assert (result["score"] >= 0.5).all()

    def test_invalid_task_raises(self, regression_data):
        with pytest.raises(ValueError, match="task must be"):
            compute_mutual_information(regression_data, "target", ["x1"], task="bad")

    def test_string_features_coerced(self, regression_data):
        result = compute_mutual_information(regression_data, "target", "x1", pivot=False)
        assert len(result) == 1

    def test_empty_after_dropna_returns_empty(self):
        df = pd.DataFrame({"target": [1.0, 2.0], "x": [np.nan, np.nan]})
        result = compute_mutual_information(df, "target", ["x"], pivot=False)
        assert result.empty
