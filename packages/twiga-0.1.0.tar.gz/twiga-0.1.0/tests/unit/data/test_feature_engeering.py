import logging
import multiprocessing

import numpy as np
import pandas as pd
from pandas.testing import assert_frame_equal
import pytest

from twiga.core.data.processing import (
    augment_lags,
    augment_rolling,
    augment_timeseries_signature,
    check_dataframe_or_groupby,
    check_date_column,
    check_value_column,
    conditional_tqdm,
    get_threads,
    get_timeseries_signature,
    reduce_memory_usage,
    sort_dataframe,
)


@pytest.fixture
def timeseries_df():
    """Create a DataFrame for testing timeseries signature."""
    return pd.DataFrame(
        {
            "date": pd.to_datetime(
                [
                    "2020-01-01 12:00:00",
                    "2020-02-29 23:59:59",
                    "2020-12-31 00:00:00",
                ]
            ),
            "value": [100, 200, 300],
            "group": ["X", "X", "Y"],
        }
    )


@pytest.fixture
def simple_df():
    """Create a simple DataFrame for testing."""
    return pd.DataFrame(
        {
            "date": pd.to_datetime(["2023-01-01", "2023-01-02", "2023-01-03"]),
            "value": [10, 20, 30],
            "id": ["A", "A", "A"],
        }
    )


@pytest.fixture
def grouped_df():
    """Create a DataFrame with multiple groups for testing."""
    return pd.DataFrame(
        {
            "date": pd.to_datetime(
                [
                    "2023-01-01",
                    "2023-01-02",
                    "2023-01-01",
                    "2023-01-02",
                ]
            ),
            "value": [10, 20, 30, 40],
            "id": ["A", "A", "B", "B"],
        }
    )


@pytest.fixture
def nan_df():
    """Create a DataFrame with NaN values for testing drop_na."""
    return pd.DataFrame(
        {
            "col1": [1, np.nan, 3, np.nan],
            "col2": [np.nan, 2, np.nan, 4],
            "col3": [1, 2, np.nan, np.nan],
        }
    )


@pytest.fixture(autouse=True)
def setup_logging(caplog):
    """Set up logging to capture logger output."""
    caplog.set_level(logging.WARNING)
    return caplog


def test_check_dataframe_or_groupby(simple_df, grouped_df):
    """Test check_dataframe_or_groupby function."""
    check_dataframe_or_groupby(simple_df)
    check_dataframe_or_groupby(grouped_df.groupby("id"))
    with pytest.raises(TypeError, match="Data must be a pandas DataFrame or GroupBy object"):
        check_dataframe_or_groupby([1, 2, 3])


def test_check_date_column(simple_df):
    """Test check_date_column function."""
    check_date_column(simple_df, "date")
    check_date_column(simple_df.groupby("id"), "date")


def test_check_value_column(simple_df):
    """Test check_value_column function."""
    check_value_column(simple_df, "value")
    check_value_column(simple_df, ["value", "id"])
    check_value_column(simple_df.groupby("id"), "value")
    with pytest.raises(ValueError, match="Value column 'invalid' not found in DataFrame"):
        check_value_column(simple_df, "invalid")
    with pytest.raises(ValueError, match="Value column 'id' must be numeric"):
        check_value_column(simple_df, "id", require_numeric_dtype=True)


def test_reduce_memory_usage(simple_df):
    """Test reduce_memory_usage function."""
    df = pd.DataFrame(
        {
            "float": [1.0, 2.0, 3.0],
            "int": [1, 2, 3],
            "object": ["a", "b", "a"],
        }
    )
    optimized_df = reduce_memory_usage(df)
    assert optimized_df["float"].dtype == "float32"
    assert optimized_df["int"].dtype == "int32"
    assert optimized_df["object"].dtype == "category"
    assert_frame_equal(optimized_df, df.astype({"float": "float32", "int": "int32", "object": "category"}))


def test_sort_dataframe(simple_df, grouped_df):
    """Test sort_dataframe function."""
    # DataFrame
    sorted_data, idx = sort_dataframe(simple_df, "date")
    assert_frame_equal(sorted_data, simple_df)
    assert idx.equals(simple_df.index)
    # GroupBy
    grouped = grouped_df.groupby("id")
    sorted_groupby, idx = sort_dataframe(grouped, "date", keep_grouped_df=True)
    assert isinstance(sorted_groupby, pd.core.groupby.generic.DataFrameGroupBy)
    assert idx.equals(grouped_df.index)


def test_get_threads():
    """Test get_threads function."""
    max_threads = multiprocessing.cpu_count()
    assert get_threads(-1) == max_threads
    assert get_threads(1) == 1
    assert get_threads(max_threads + 1) == max_threads
    with pytest.raises(ValueError, match="Threads must be -1"):
        get_threads(0)


def test_conditional_tqdm():
    """Test conditional_tqdm function."""
    items = [1, 2, 3]
    result = conditional_tqdm(items, total=len(items), desc="Test", display=False)
    assert result == items
    # Progress bar output is tested indirectly via augment_rolling


def test_augment_rolling_simple_df(simple_df):
    """Test augment_rolling on a single DataFrame."""
    result = augment_rolling(
        simple_df,
        date_column="date",
        value_column="value",
        window_func=["mean", ("range", lambda x: x.max() - x.min())],
        window=[2],
        threads=1,
        show_progress=False,
    )
    expected = pd.DataFrame(
        {
            "date": pd.to_datetime(["2023-01-01", "2023-01-02", "2023-01-03"]),
            "value": [10, 20, 30],
            "id": ["A", "A", "A"],
            "value_rolling_mean_win_2": [np.nan, 15.0, 25.0],
            "value_rolling_range_win_2": [np.nan, 10.0, 10.0],
        }
    )
    assert_frame_equal(result, expected, check_dtype=False)


def test_augment_rolling_multiple_columns(simple_df):
    """Test augment_rolling with multiple value columns."""
    df = simple_df.copy()
    df["value2"] = [100, 200, 300]
    result = augment_rolling(
        df,
        date_column="date",
        value_column=["value", "value2"],
        window_func="mean",
        window=2,
        threads=1,
        show_progress=False,
    )
    expected = pd.DataFrame(
        {
            "date": pd.to_datetime(["2023-01-01", "2023-01-02", "2023-01-03"]),
            "value": [10, 20, 30],
            "id": ["A", "A", "A"],
            "value2": [100, 200, 300],
            "value_rolling_mean_win_2": [np.nan, 15.0, 25.0],
            "value2_rolling_mean_win_2": [np.nan, 150.0, 250.0],
        }
    )
    assert_frame_equal(result, expected, check_dtype=False)


def test_augment_rolling_center_min_periods(simple_df):
    """Test augment_rolling with center=True and min_periods."""
    result = augment_rolling(
        simple_df,
        date_column="date",
        value_column="value",
        window_func="mean",
        window=3,
        min_periods=1,
        center=True,
        threads=1,
        show_progress=False,
    )
    expected = pd.DataFrame(
        {
            "date": pd.to_datetime(["2023-01-01", "2023-01-02", "2023-01-03"]),
            "value": [10, 20, 30],
            "id": ["A", "A", "A"],
            "value_rolling_mean_win_3": [15.0, 20.0, 25.0],
        }
    )
    assert_frame_equal(result, expected, check_dtype=False)


def test_augment_rolling_reduce_memory(simple_df):
    """Test augment_rolling with reduce_memory=True."""
    result = augment_rolling(
        simple_df,
        date_column="date",
        value_column="value",
        window_func="mean",
        window=2,
        reduce_memory=True,
        threads=1,
        show_progress=False,
    )
    assert result["value"].dtype == "int32"
    assert result["value_rolling_mean_win_2"].dtype == "float32"


def test_augment_rolling_quantile(simple_df, caplog):
    """Test augment_rolling with quantile function."""
    # Use the context manager to ensure INFO level is captured
    with caplog.at_level(logging.INFO):
        result = augment_rolling(
            simple_df,
            date_column="date",
            value_column="value",
            window_func="quantile",
            window=2,
            threads=1,
            show_progress=False,
        )

    expected = pd.DataFrame(
        {
            "date": pd.to_datetime(["2023-01-01", "2023-01-02", "2023-01-03"]),
            "value": [10, 20, 30],
            "id": ["A", "A", "A"],
            "value_rolling_quantile_50_win_2": [np.nan, 15.0, 25.0],
        }
    )

    assert_frame_equal(result, expected, check_dtype=False)


def test_augment_rolling_errors(simple_df):
    """Test augment_rolling error handling."""
    with pytest.raises(TypeError, match="Data must be a pandas DataFrame or GroupBy object"):
        augment_rolling([1, 2, 3], "date", "value")
    with pytest.raises(ValueError, match="Date column 'invalid' not found"):
        augment_rolling(simple_df, "invalid", "value")
    with pytest.raises(ValueError, match="Value column 'invalid' not found"):
        augment_rolling(simple_df, "date", "invalid")
    with pytest.raises(TypeError, match="`window` must be an integer, tuple, or list"):
        augment_rolling(simple_df, "date", "value", window="invalid")
    with pytest.raises(ValueError, match="Invalid function name: invalid"):
        augment_rolling(simple_df, "date", "value", window_func="invalid")
    with pytest.raises(ValueError, match="Invalid tuple format for window_func"):
        augment_rolling(simple_df, "date", "value", window_func=("invalid",))
    with pytest.raises(TypeError, match="Invalid callable for 'invalid'"):
        augment_rolling(simple_df, "date", "value", window_func=("invalid", "not_callable"))


def test_augment_lags_simple_df(simple_df):
    """Test augment_lags on a single DataFrame."""
    result = augment_lags(simple_df, date_column="date", value_column="value", lags=[1, 2])
    expected = pd.DataFrame(
        {
            "date": pd.to_datetime(["2023-01-01", "2023-01-02", "2023-01-03"]),
            "value": [10, 20, 30],
            "id": ["A", "A", "A"],
            "value_lag_1": [np.nan, 10.0, 20.0],
            "value_lag_2": [np.nan, np.nan, 10.0],
        }
    )
    assert_frame_equal(result, expected, check_dtype=False)


def test_augment_lags_groupby(grouped_df):
    """Test augment_lags on a GroupBy object."""
    result = augment_lags(
        grouped_df.groupby("id"),
        date_column="date",
        value_column="value",
        lags=(1, 2),
    )
    expected = pd.DataFrame(
        {
            "date": pd.to_datetime(
                [
                    "2023-01-01",
                    "2023-01-02",
                    "2023-01-01",
                    "2023-01-02",
                ]
            ),
            "value": [10, 20, 30, 40],
            "id": ["A", "A", "B", "B"],
            "value_lag_1": [np.nan, 10.0, np.nan, 30.0],
            "value_lag_2": [np.nan, np.nan, np.nan, np.nan],
        }
    )
    assert_frame_equal(result, expected, check_dtype=False)


def test_augment_lags_multiple_columns(simple_df):
    """Test augment_lags with multiple value columns."""
    df = simple_df.copy()
    df["value2"] = [100, 200, 300]
    result = augment_lags(df, date_column="date", value_column=["value", "value2"], lags=1)
    expected = pd.DataFrame(
        {
            "date": pd.to_datetime(["2023-01-01", "2023-01-02", "2023-01-03"]),
            "value": [10, 20, 30],
            "id": ["A", "A", "A"],
            "value2": [100, 200, 300],
            "value_lag_1": [np.nan, 10.0, 20.0],
            "value2_lag_1": [np.nan, 100.0, 200.0],
        }
    )
    assert_frame_equal(result, expected, check_dtype=False)


def test_augment_lags_reduce_memory(simple_df):
    """Test augment_lags with reduce_memory=True."""
    result = augment_lags(
        simple_df,
        date_column="date",
        value_column="value",
        lags=1,
        reduce_memory=True,
    )
    assert result["value"].dtype == "int32"
    assert result["value_lag_1"].dtype == "float32"


def test_augment_lags_errors(simple_df):
    """Test augment_lags error handling."""
    with pytest.raises(TypeError, match="Data must be a pandas DataFrame or GroupBy object"):
        augment_lags([1, 2, 3], "date", "value")
    with pytest.raises(ValueError, match="Date column 'invalid' not found"):
        augment_lags(simple_df, "invalid", "value")
    with pytest.raises(ValueError, match="Value column 'invalid' not found"):
        augment_lags(simple_df, "date", "invalid")
    with pytest.raises(TypeError, match="Invalid lags specification"):
        augment_lags(simple_df, "date", "value", lags="invalid")


def test_augment_rolling_groupby(grouped_df):
    """Test augment_rolling on a GroupBy object."""
    result = augment_rolling(
        grouped_df.groupby("id"),
        date_column="date",
        value_column="value",
        window_func="sum",
        window=(1, 2),
        threads=1,
        show_progress=False,
    )
    expected = pd.DataFrame(
        {
            "date": pd.to_datetime(
                [
                    "2023-01-01",
                    "2023-01-02",
                    "2023-01-01",
                    "2023-01-02",
                ]
            ),
            "value": [10, 20, 30, 40],
            "id": ["A", "A", "B", "B"],
            "value_rolling_sum_win_1": [10.0, 20.0, 30.0, 40.0],
            "value_rolling_sum_win_2": [np.nan, 30.0, np.nan, 70.0],
        }
    )
    assert_frame_equal(result, expected, check_dtype=False)


def test_augment_timeseries_signature(timeseries_df):
    """Test augment_timeseries_signature on a DataFrame."""
    result = augment_timeseries_signature(timeseries_df, date_column="date", engine="pandas")
    expected_columns = [
        "date",
        "value",
        "group",
        "date_index_num",
        "date_year",
        "date_year_iso",
        "date_yearstart",
        "date_yearend",
        "date_leapyear",
        "date_half",
        "date_quarter",
        "date_quarteryear",
        "date_quarterstart",
        "date_quarterend",
        "date_month",
        "date_month_lbl",
        "date_monthstart",
        "date_monthend",
        "date_yweek",
        "date_mweek",
        "date_wday",
        "date_wday_lbl",
        "date_mday",
        "date_qday",
        "date_yday",
        "date_weekend",
        "date_hour",
        "date_minute",
        "date_second",
        "date_msecond",
        "date_nsecond",
        "date_am_pm",
    ]
    assert list(result.columns) == expected_columns
    assert result["date_year"].tolist() == [2020, 2020, 2020]
    assert result["date_month"].tolist() == [1, 2, 12]
    assert result["date_leapyear"].tolist() == [1, 1, 1]
    assert result["date_half"].tolist() == [1, 1, 2]
    assert result["date_quarteryear"].tolist() == ["2020Q1", "2020Q1", "2020Q4"]
    assert result["date_wday"].tolist() == [3, 6, 4]
    assert result["date_weekend"].tolist() == [0, 1, 0]
    assert result["date_hour"].tolist() == [12, 23, 0]
    assert result["date_am_pm"].tolist() == ["am", "pm", "am"]


def test_augment_timeseries_signature_groupby(timeseries_df):
    """Test augment_timeseries_signature on a GroupBy object."""
    result = augment_timeseries_signature(timeseries_df.groupby("group"), date_column="date", engine="pandas")
    expected_columns = [
        "date",
        "value",
        "group",
        "date_index_num",
        "date_year",
        "date_year_iso",
        "date_yearstart",
        "date_yearend",
        "date_leapyear",
        "date_half",
        "date_quarter",
        "date_quarteryear",
        "date_quarterstart",
        "date_quarterend",
        "date_month",
        "date_month_lbl",
        "date_monthstart",
        "date_monthend",
        "date_yweek",
        "date_mweek",
        "date_wday",
        "date_wday_lbl",
        "date_mday",
        "date_qday",
        "date_yday",
        "date_weekend",
        "date_hour",
        "date_minute",
        "date_second",
        "date_msecond",
        "date_nsecond",
        "date_am_pm",
    ]
    assert list(result.columns) == expected_columns
    assert result["date_year"].tolist() == [2020, 2020, 2020]
    assert result["date_month"].tolist() == [1, 2, 12]
    assert result["date_leapyear"].tolist() == [1, 1, 1]
    assert result["date_half"].tolist() == [1, 1, 2]
    assert result["date_quarteryear"].tolist() == ["2020Q1", "2020Q1", "2020Q4"]
    assert result["date_wday"].tolist() == [3, 6, 4]
    assert result["date_weekend"].tolist() == [0, 1, 0]
    assert result["date_hour"].tolist() == [12, 23, 0]
    assert result["date_am_pm"].tolist() == ["am", "pm", "am"]


def test_augment_timeseries_signature_reduce_memory(timeseries_df):
    """Test augment_timeseries_signature with reduce_memory=True."""
    result = augment_timeseries_signature(timeseries_df, date_column="date", reduce_memory=True, engine="pandas")
    assert result["value"].dtype == "int32"
    assert result["date_year"].dtype == "int32"
    assert result["date_month_lbl"].dtype == "category"
    assert result["date_am_pm"].dtype == "category"


def test_augment_timeseries_signature_errors(timeseries_df):
    """Test augment_timeseries_signature error handling."""
    with pytest.raises(TypeError, match="Data must be a pandas DataFrame or GroupBy object"):
        augment_timeseries_signature([1, 2, 3], "date")
    with pytest.raises(ValueError, match="Date column 'invalid' not found"):
        augment_timeseries_signature(timeseries_df, "invalid")
    with pytest.raises(ValueError, match="Only 'pandas' engine is supported"):
        augment_timeseries_signature(timeseries_df, "date", engine="polars")


def test_get_timeseries_signature(timeseries_df):
    """Test get_timeseries_signature on a Series."""
    result = get_timeseries_signature(timeseries_df["date"], engine="pandas")
    expected_columns = [
        "date",
        "date_index_num",
        "date_year",
        "date_year_iso",
        "date_yearstart",
        "date_yearend",
        "date_leapyear",
        "date_half",
        "date_quarter",
        "date_quarteryear",
        "date_quarterstart",
        "date_quarterend",
        "date_month",
        "date_month_lbl",
        "date_monthstart",
        "date_monthend",
        "date_yweek",
        "date_mweek",
        "date_wday",
        "date_wday_lbl",
        "date_mday",
        "date_qday",
        "date_yday",
        "date_weekend",
        "date_hour",
        "date_minute",
        "date_second",
        "date_msecond",
        "date_nsecond",
        "date_am_pm",
    ]
    assert list(result.columns) == expected_columns
    assert result["date_year"].tolist() == [2020, 2020, 2020]
    assert result["date_month"].tolist() == [1, 2, 12]
    assert result["date_leapyear"].tolist() == [1, 1, 1]
    assert result["date_half"].tolist() == [1, 1, 2]
    assert result["date_quarteryear"].tolist() == ["2020Q1", "2020Q1", "2020Q4"]
    assert result["date_wday"].tolist() == [3, 6, 4]
    assert result["date_weekend"].tolist() == [0, 1, 0]
    assert result["date_hour"].tolist() == [12, 23, 0]
    assert result["date_am_pm"].tolist() == ["am", "pm", "am"]


def test_get_timeseries_signature_datetimeindex():
    """Test get_timeseries_signature on a DatetimeIndex."""
    idx = pd.DatetimeIndex(["2020-01-01 12:00:00", "2020-02-29 23:59:59"])
    result = get_timeseries_signature(idx, engine="pandas")
    expected_columns = [
        "idx",
        "idx_index_num",
        "idx_year",
        "idx_year_iso",
        "idx_yearstart",
        "idx_yearend",
        "idx_leapyear",
        "idx_half",
        "idx_quarter",
        "idx_quarteryear",
        "idx_quarterstart",
        "idx_quarterend",
        "idx_month",
        "idx_month_lbl",
        "idx_monthstart",
        "idx_monthend",
        "idx_yweek",
        "idx_mweek",
        "idx_wday",
        "idx_wday_lbl",
        "idx_mday",
        "idx_qday",
        "idx_yday",
        "idx_weekend",
        "idx_hour",
        "idx_minute",
        "idx_second",
        "idx_msecond",
        "idx_nsecond",
        "idx_am_pm",
    ]
    assert list(result.columns) == expected_columns
    assert result["idx_year"].tolist() == [2020, 2020]
    assert result["idx_month"].tolist() == [1, 2]
    assert result["idx_leapyear"].tolist() == [1, 1]
    assert result["idx_half"].tolist() == [1, 1]
    assert result["idx_quarteryear"].tolist() == ["2020Q1", "2020Q1"]
    assert result["idx_wday"].tolist() == [3, 6]
    assert result["idx_weekend"].tolist() == [0, 1]
    assert result["idx_hour"].tolist() == [12, 23]
    assert result["idx_am_pm"].tolist() == ["am", "pm"]


def test_get_timeseries_signature_reduce_memory(timeseries_df):
    """Test get_timeseries_signature with reduce_memory=True."""
    result = get_timeseries_signature(timeseries_df["date"], reduce_memory=True, engine="pandas")
    assert result["date_year"].dtype == "int32"
    assert result["date_month_lbl"].dtype == "category"
    assert result["date_am_pm"].dtype == "category"


def test_get_timeseries_signature_errors(timeseries_df):
    """Test get_timeseries_signature error handling."""
    with pytest.raises(TypeError, match="idx must be a pandas Series or DatetimeIndex object"):
        get_timeseries_signature([1, 2, 3])
    with pytest.raises(ValueError, match="Only 'pandas' engine is supported"):
        get_timeseries_signature(timeseries_df["date"], engine="polars")
