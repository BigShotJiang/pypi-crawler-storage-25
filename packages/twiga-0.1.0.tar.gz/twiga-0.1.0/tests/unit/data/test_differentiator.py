"""Unit tests for TimeSeriesDifferentiator."""

import numpy as np
import pytest

from twiga.core.data.diff import TimeSeriesDifferentiator

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def linear_series():
    """1-D array with a strong linear trend: 0, 2, 4, …, 18."""
    return np.arange(0, 20, 2, dtype=float)


@pytest.fixture()
def constant_series():
    """Constant series — 1st-order diff should be all zeros."""
    return np.ones(10, dtype=float) * 5.0


@pytest.fixture()
def quadratic_series():
    """Y = t² — 2nd-order diff removes the trend perfectly."""
    t = np.arange(10, dtype=float)
    return t**2


# ---------------------------------------------------------------------------
# Initialisation
# ---------------------------------------------------------------------------


class TestInit:
    def test_default_order(self):
        d = TimeSeriesDifferentiator()
        assert d.order == 1

    def test_custom_order(self):
        d = TimeSeriesDifferentiator(order=3)
        assert d.order == 3

    def test_invalid_order_raises(self):
        with pytest.raises(ValueError, match="Order must be >= 1"):
            TimeSeriesDifferentiator(order=0)

    def test_negative_order_raises(self):
        with pytest.raises(ValueError, match="Order must be >= 1"):
            TimeSeriesDifferentiator(order=-2)


# ---------------------------------------------------------------------------
# fit
# ---------------------------------------------------------------------------


class TestFit:
    def test_fit_returns_self(self, linear_series):
        d = TimeSeriesDifferentiator()
        result = d.fit(linear_series)
        assert result is d

    def test_fit_stores_history(self, linear_series):
        d = TimeSeriesDifferentiator()
        d.fit(linear_series)
        assert "initial_values" in d.history_
        assert "last_values" in d.history_

    def test_fit_first_order_stores_single_anchor(self, linear_series):
        d = TimeSeriesDifferentiator(order=1)
        d.fit(linear_series)
        assert len(d.history_["initial_values"]) == 1
        assert len(d.history_["last_values"]) == 1

    def test_fit_second_order_stores_two_anchors(self, quadratic_series):
        d = TimeSeriesDifferentiator(order=2)
        d.fit(quadratic_series)
        assert len(d.history_["initial_values"]) == 2
        assert len(d.history_["last_values"]) == 2

    def test_fit_stores_correct_initial_value(self, linear_series):
        d = TimeSeriesDifferentiator(order=1)
        d.fit(linear_series)
        assert d.history_["initial_values"][0] == pytest.approx(linear_series[0])

    def test_fit_stores_correct_last_value(self, linear_series):
        d = TimeSeriesDifferentiator(order=1)
        d.fit(linear_series)
        assert d.history_["last_values"][0] == pytest.approx(linear_series[-1])

    def test_fit_accepts_2d_input(self, linear_series):
        d = TimeSeriesDifferentiator()
        d.fit(linear_series.reshape(-1, 1))  # should not raise
        assert d.history_["initial_values"][0] == pytest.approx(linear_series[0])


# ---------------------------------------------------------------------------
# transform
# ---------------------------------------------------------------------------


class TestTransform:
    def test_output_length_preserved(self, linear_series):
        d = TimeSeriesDifferentiator(order=1)
        out = d.transform(linear_series)
        assert len(out) == len(linear_series)

    def test_leading_nans_equal_order(self, linear_series):
        order = 2
        d = TimeSeriesDifferentiator(order=order)
        out = d.transform(linear_series)
        assert np.all(np.isnan(out[:order]))

    def test_first_order_linear_trend_removed(self, linear_series):
        """1st diff of a linear series should be constant (step size)."""
        d = TimeSeriesDifferentiator(order=1)
        out = d.transform(linear_series)
        valid = out[~np.isnan(out)]
        np.testing.assert_allclose(valid, 2.0)

    def test_first_order_constant_series_is_zero(self, constant_series):
        d = TimeSeriesDifferentiator(order=1)
        out = d.transform(constant_series)
        valid = out[~np.isnan(out)]
        np.testing.assert_allclose(valid, 0.0)

    def test_second_order_quadratic_trend_removed(self, quadratic_series):
        """2nd diff of y=t² is the constant 2."""
        d = TimeSeriesDifferentiator(order=2)
        out = d.transform(quadratic_series)
        valid = out[~np.isnan(out)]
        np.testing.assert_allclose(valid, 2.0)

    def test_transform_does_not_depend_on_fit(self, linear_series):
        """Transform is stateless — it should work without fitting."""
        d = TimeSeriesDifferentiator(order=1)
        out = d.transform(linear_series)
        assert len(out) == len(linear_series)


# ---------------------------------------------------------------------------
# inverse_transform
# ---------------------------------------------------------------------------


class TestInverseTransform:
    def test_roundtrip_first_order(self, linear_series):
        d = TimeSeriesDifferentiator(order=1)
        d.fit(linear_series)
        diff = d.transform(linear_series)
        recovered = d.inverse_transform(diff)
        np.testing.assert_allclose(recovered, linear_series, atol=1e-10)

    def test_roundtrip_second_order(self, quadratic_series):
        d = TimeSeriesDifferentiator(order=2)
        d.fit(quadratic_series)
        diff = d.transform(quadratic_series)
        recovered = d.inverse_transform(diff)
        np.testing.assert_allclose(recovered, quadratic_series, atol=1e-10)

    def test_roundtrip_constant_series(self, constant_series):
        d = TimeSeriesDifferentiator(order=1)
        d.fit(constant_series)
        diff = d.transform(constant_series)
        recovered = d.inverse_transform(diff)
        np.testing.assert_allclose(recovered, constant_series, atol=1e-10)

    def test_inverse_transform_strips_leading_nans(self, linear_series):
        """inverse_transform should ignore leading NaNs and return full series."""
        d = TimeSeriesDifferentiator(order=1)
        d.fit(linear_series)
        diff = d.transform(linear_series)
        assert np.isnan(diff[0])
        recovered = d.inverse_transform(diff)
        assert len(recovered) == len(linear_series)
        assert not np.any(np.isnan(recovered))

    def test_inverse_output_length(self, linear_series):
        d = TimeSeriesDifferentiator(order=1)
        d.fit(linear_series)
        diff = d.transform(linear_series)
        recovered = d.inverse_transform(diff)
        assert len(recovered) == len(linear_series)


# ---------------------------------------------------------------------------
# forecast_inverse
# ---------------------------------------------------------------------------


class TestForecastInverse:
    def test_forecast_inverse_first_order(self, linear_series):
        """Forecast diffs should integrate back to the original continuation."""
        d = TimeSeriesDifferentiator(order=1)
        d.fit(linear_series)

        # Simulate future diffs: constant step of 2 for 5 steps
        future_diffs = np.array([2.0, 2.0, 2.0, 2.0, 2.0])
        future_reconstructed = d.forecast_inverse(future_diffs)

        # Expected: starts from last value (18) + each step
        expected = np.array([20.0, 22.0, 24.0, 26.0, 28.0])
        np.testing.assert_allclose(future_reconstructed, expected, atol=1e-10)

    def test_forecast_inverse_second_order(self, quadratic_series):
        """2nd-order forecast inverse should correctly chain two integrations."""
        d = TimeSeriesDifferentiator(order=2)
        d.fit(quadratic_series)

        # 2nd diff of t² is always 2
        future_second_diffs = np.array([2.0, 2.0, 2.0])
        result = d.forecast_inverse(future_second_diffs)

        # Must return an array of the same length
        assert len(result) == 3
        assert not np.any(np.isnan(result))

    def test_forecast_inverse_output_shape(self, linear_series):
        d = TimeSeriesDifferentiator(order=1)
        d.fit(linear_series)
        diffs = np.zeros(7)
        result = d.forecast_inverse(diffs)
        assert result.shape == (7,)

    def test_forecast_inverse_zero_diffs_returns_last_value(self, linear_series):
        """Zero diffs → flat forecast at the last value."""
        d = TimeSeriesDifferentiator(order=1)
        d.fit(linear_series)
        diffs = np.zeros(5)
        result = d.forecast_inverse(diffs)
        # cumsum([0,0,0,0,0]) + last_value(18)
        np.testing.assert_allclose(result, linear_series[-1], atol=1e-10)


# ---------------------------------------------------------------------------
# sklearn API compatibility
# ---------------------------------------------------------------------------


class TestSklearnAPI:
    def test_get_set_params(self):
        d = TimeSeriesDifferentiator(order=2)
        params = d.get_params()
        assert params == {"order": 2}

    def test_set_params(self):
        d = TimeSeriesDifferentiator(order=1)
        d.set_params(order=3)
        assert d.order == 3

    def test_fit_transform_pipeline(self, linear_series):
        """fit_transform should be equivalent to fit then transform."""
        d1 = TimeSeriesDifferentiator(order=1)
        d1.fit(linear_series)
        expected = d1.transform(linear_series)

        d2 = TimeSeriesDifferentiator(order=1)
        result = d2.fit_transform(linear_series)

        np.testing.assert_allclose(result, expected)
