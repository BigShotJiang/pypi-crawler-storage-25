import pandas as pd
import pytest

from twiga.core.data.autores import AutoregressTransformer  # Adjust module path as needed


# Fixtures for test data
@pytest.fixture
def sample_df():
    """Create a sample DataFrame for testing."""
    dates = pd.date_range("2023-01-01", periods=50, freq="D")
    return pd.DataFrame({"timestamp": dates, "value": range(50)})


# Test initialization and parameter validation
def test_init_default():
    """Test default initialization."""
    transformer = AutoregressTransformer()
    assert transformer.n_samples == 1
    assert transformer.lags is None
    assert transformer.windows is None
    assert transformer.window_funcs is None
    assert transformer.date_column == "timestamp"
    assert transformer.value_column == "value"
    assert transformer.max_data_drop == 0


def test_init_custom_params():
    """Test initialization with custom parameters."""
    transformer = AutoregressTransformer(
        n_samples=2, lags=[1, 2], windows=3, window_funcs=["mean"], date_column="date", value_column="target"
    )
    assert transformer.n_samples == 2
    assert transformer.lags == [1, 2]
    assert transformer.windows == [3]
    assert transformer.window_funcs == ["mean"]
    assert transformer.date_column == "date"
    assert transformer.value_column == "target"


@pytest.mark.parametrize("n_samples, expected_error", [(0, ValueError), (-1, ValueError), ("invalid", ValueError)])
def test_validate_n_samples(n_samples, expected_error):
    """Test validation of n_samples parameter."""
    with pytest.raises(expected_error):
        AutoregressTransformer(n_samples=n_samples)


@pytest.mark.parametrize(
    "lags, expected_error", [(0, ValueError), (-1, ValueError), ([0, 1], ValueError), (["invalid"], ValueError)]
)
def test_validate_lags(lags, expected_error):
    """Test validation of lags parameter."""
    with pytest.raises(expected_error):
        AutoregressTransformer(lags=lags)


@pytest.mark.parametrize(
    "windows, expected_error", [(0, ValueError), (-1, ValueError), ([0, 1], ValueError), (["invalid"], ValueError)]
)
def test_validate_windows(windows, expected_error):
    """Test validation of windows parameter."""
    with pytest.raises(expected_error):
        AutoregressTransformer(windows=windows)


@pytest.mark.parametrize("window_funcs, expected_error", [(1, ValueError), ([1, 2], ValueError)])
def test_validate_window_funcs(window_funcs, expected_error):
    """Test validation of window_funcs parameter."""
    with pytest.raises(expected_error):
        AutoregressTransformer(window_funcs=window_funcs)


# Test fit method
def test_fit_valid_input(sample_df):
    """Test fit with valid input."""
    transformer = AutoregressTransformer()
    result = transformer.fit(sample_df)
    assert result is transformer  # Should return self


def test_fit_invalid_type():
    """Test fit with invalid input type."""
    transformer = AutoregressTransformer()
    with pytest.raises(TypeError):
        transformer.fit([1, 2, 3])


def test_fit_missing_columns(sample_df):
    """Test fit with missing columns."""
    transformer = AutoregressTransformer(date_column="nonexistent")
    with pytest.raises(ValueError):
        transformer.fit(sample_df)


def test_fit_missing_value_column(sample_df):
    """Test fit raises ValueError when value_column is not in DataFrame."""
    transformer = AutoregressTransformer(date_column="timestamp", value_column="nonexistent_value")
    with pytest.raises(ValueError, match="value_column"):
        transformer.fit(sample_df)


# Test transform method
def test_transform_basic(sample_df):
    """Test basic transform functionality."""
    transformer = AutoregressTransformer()
    transformer.fit(sample_df)
    result = transformer.transform(sample_df)
    assert isinstance(result, pd.DataFrame)
    assert len(result) == len(sample_df)  # No features added, so same length


def test_transform_with_lags(sample_df):
    """Test transform with lag features."""
    transformer = AutoregressTransformer(lags=[1, 2], n_samples=1)
    transformer.fit(sample_df)
    result = transformer.transform(sample_df)
    assert f"{transformer.value_column}_lag_{1}" in result.columns
    assert f"{transformer.value_column}_lag_{2}" in result.columns
    assert len(result) == len(sample_df) - 2  # 2 rows dropped due to max lag
    assert transformer.max_data_drop == 2


def test_transform_with_rolling(sample_df):
    """Test transform with rolling statistics."""
    transformer = AutoregressTransformer(windows=2, window_funcs="mean", n_samples=1)
    transformer.fit(sample_df)
    result = transformer.transform(sample_df)
    assert f"{transformer.value_column}_rolling_mean_win_2" in result.columns
    assert len(result) == len(sample_df) - 2  # 2 rows dropped due to window size
    assert transformer.max_data_drop == 2


def test_transform_invalid_type():
    """Test transform with invalid input type."""
    transformer = AutoregressTransformer()
    transformer.fit(
        pd.DataFrame({"timestamp": [pd.Timestamp("2023-01-01")], "value": [1]})
    )  # Fit with minimal valid DataFrame
    with pytest.raises(TypeError):
        transformer.transform([1, 2, 3])


def test_transform_empty_lags(sample_df):
    """Test transform with empty lags list."""
    transformer = AutoregressTransformer(lags=[])
    transformer.fit(sample_df)
    result = transformer.transform(sample_df)
    assert isinstance(result, pd.DataFrame)
    assert len(result.columns) == len(sample_df.columns)  # No new columns added
    assert len(result) == len(sample_df)  # No rows dropped


# Test fit_transform combination
def test_fit_transform(sample_df):
    """Test fit_transform functionality."""
    transformer = AutoregressTransformer(lags=1)
    result = transformer.fit_transform(sample_df)
    assert isinstance(result, pd.DataFrame)
    assert f"{transformer.value_column}_lag_{1}" in result.columns
