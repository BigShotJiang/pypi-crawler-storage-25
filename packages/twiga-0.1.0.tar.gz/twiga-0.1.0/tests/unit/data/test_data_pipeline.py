from unittest.mock import Mock, patch

import numpy as np
import pandas as pd
import pytest
from sklearn.preprocessing import FunctionTransformer, MinMaxScaler

from twiga.core.data.pipeline import DataPipeline


# Fixtures
@pytest.fixture
def sample_df():
    """Create a sample DataFrame with hourly timestamp data for testing.

    This fixture generates a pandas DataFrame containing one week of hourly
    timestamp data and sequential integer values. It provides consistent
    test data for validating the DataPipeline class's functionality.

    Returns:
        pd.DataFrame: A DataFrame with 'timestamp' column containing hourly
                      timestamps for one week (168 records) and a 'value'
                      column containing sequential integers.
    """
    dates = pd.date_range("2023-01-01", periods=24 * 7, freq="h")
    return pd.DataFrame({"timestamp": dates, "value": range(24 * 7)})


@pytest.fixture
def sample_df_with_features():
    """Create a sample DataFrame with timestamp data and additional features.

    This fixture extends the basic sample DataFrame with additional columns
    for testing more complex pipeline transformations. It includes temperature
    values and hour-of-day features to test both numerical and calendar feature
    handling.

    Returns:
        pd.DataFrame: A DataFrame with 'timestamp', 'value', 'temp', and 'hour'
                      columns for testing feature extraction and transformation.
    """
    dates = pd.date_range("2023-01-01", periods=24 * 7, freq="h")
    return pd.DataFrame(
        {
            "timestamp": dates,
            "value": range(24 * 7),
            "temp": np.random.randn(24 * 7),
            "hour": dates.hour,
        }
    )


# Initialization Tests
def test_init_basic():
    """Test basic initialization with minimal parameters."""
    transformer = DataPipeline(
        target_feature="value",
        period="1h",
        lookback_window_size=24,
        forecast_horizon=12,
    )
    assert transformer.target_feature == ["value"]
    assert transformer.period == "1h"
    assert transformer.lookback_window_size == 24
    assert transformer.forecast_horizon == 12
    assert transformer.historical_features == []
    assert transformer.calendar_features == []
    assert transformer.exogenous_features == []
    assert transformer.future_covariates == []
    assert isinstance(transformer.input_scaler, FunctionTransformer)
    assert isinstance(transformer.target_scaler, FunctionTransformer)
    assert transformer.lags == []
    assert transformer.windows == []
    assert transformer.window_funcs == []
    assert transformer.date_column == "timestamp"
    assert transformer.n_samples == 24  # 24 hours in a day


def test_init_custom_params():
    """Test initialization with custom parameters."""
    transformer = DataPipeline(
        target_feature=["value", "temp"],
        period="30min",
        lookback_window_size=48,
        forecast_horizon=24,
        latitude=40.7128,
        longitude=-74.0060,
        historical_features=["temp"],
        calendar_features=["hour"],
        exogenous_features=["weather"],
        future_covariates=["holiday"],
        lags=[1, 2],
        windows=3,
        window_funcs="mean",
        date_column="date",
    )
    assert transformer.target_feature == ["value", "temp"]
    assert transformer.period == "30min"
    assert transformer.lookback_window_size == 48
    assert transformer.forecast_horizon == 24
    assert transformer.latitude == 40.7128
    assert transformer.longitude == -74.0060
    assert transformer.historical_features == ["temp"]
    assert transformer.calendar_features == ["hour"]
    assert transformer.exogenous_features == ["weather"]
    assert transformer.future_covariates == ["holiday"]
    assert transformer.lags == [1, 2]
    assert transformer.windows == [3]
    assert transformer.window_funcs == ["mean"]
    assert transformer.date_column == "date"
    assert transformer.n_samples == 48  # 48 half-hours in a day


@pytest.mark.parametrize(
    "period, expected_error",
    [
        ("invalid", ValueError),
        ("1X", ValueError),
        (123, ValueError),
    ],
)
def test_validate_period(period, expected_error):
    """Test validation of the period parameter.

    This test verifies that DataPipeline correctly validates the period parameter
    and raises an appropriate error when an invalid time frequency string is provided.

    Args:
        period: The invalid period value to test
        expected_error: The type of exception that should be raised

    Asserts:
        - The expected error is raised when an invalid period is provided
    """
    with pytest.raises(expected_error):
        DataPipeline(
            target_feature="value",
            period=period,
            lookback_window_size=24,
            forecast_horizon=12,
        )


@pytest.mark.parametrize(
    "lookback, horizon, expected_error",
    [
        (0, 12, ValueError),
        (-1, 12, ValueError),
        (24, 0, ValueError),
        (24, -1, ValueError),
    ],
)
def test_init_invalid_window_sizes(lookback, horizon, expected_error):
    """Test initialization with invalid lookback_window_size or forecast_horizon.

    This test verifies that DataPipeline correctly validates the window size
    parameters and raises appropriate errors when non-positive values are provided.

    Args:
        lookback: The lookback window size to test
        horizon: The forecast horizon to test
        expected_error: The type of exception that should be raised

    Asserts:
        - The expected error is raised when invalid window sizes are provided
    """
    with pytest.raises(expected_error):
        DataPipeline(
            target_feature="value",
            period="1h",
            lookback_window_size=lookback,
            forecast_horizon=horizon,
        )


# Pipeline Building Tests
@patch("twiga.core.data.pipeline.TemporalFeatureTransformer")
@patch("twiga.core.data.pipeline.AutoregressTransformer")
def test_build_feature_pipeline(mock_autoregress, mock_temporal):
    """Test feature pipeline construction."""
    transformer = DataPipeline(
        target_feature="value",
        period="1h",
        lookback_window_size=24,
        forecast_horizon=12,
        calendar_features=["hour"],
        lags=[1],
        windows=2,
        window_funcs="mean",
    )
    pipeline = transformer._build_feature_pipeline()
    assert len(pipeline.steps) == 2  # Temporal and Autoregress steps
    assert pipeline.steps[0][0] == "temporal_features"
    assert pipeline.steps[1][0] == "autoregress"


def test_build_scaling_pipeline():
    """Test scaling pipeline construction."""
    transformer = DataPipeline(
        target_feature="value",
        period="1h",
        lookback_window_size=24,
        forecast_horizon=12,
        historical_features=["temp"],
        exogenous_features=["weather"],
    )
    scaling_pipeline = transformer._build_scaling_pipeline()
    assert len(scaling_pipeline.transformers) == 2  # Target and numerical scaling
    assert scaling_pipeline.transformers[0][1] == transformer.target_scaler
    assert scaling_pipeline.transformers[1][1] == transformer.input_scaler


# Fit and Transform Tests
@patch("twiga.core.data.pipeline.TemporalFeatureTransformer")
@patch("twiga.core.data.pipeline.AutoregressTransformer")
def test_fit(mock_autoregress, mock_temporal, sample_df):
    """Test fitting the transformer."""
    mock_pipeline = Mock()
    transformer = DataPipeline(
        target_feature="value",
        period="1h",
        lookback_window_size=24,
        forecast_horizon=12,
    )
    transformer.data_pipeline = mock_pipeline
    result = transformer.fit(sample_df)
    assert result is transformer


@patch("twiga.core.data.pipeline.TemporalFeatureTransformer")
@patch("twiga.core.data.pipeline.AutoregressTransformer")
@patch("twiga.core.data.pipeline.get_feature_sequences")
@patch("twiga.core.data.pipeline.get_target_sequences")
@patch("twiga.core.data.pipeline.stack_features")
def test_transform(
    mock_stack, mock_target_seq, mock_feature_seq, mock_autoregress, mock_temporal, sample_df_with_features
):
    """Test transforming data into features and targets."""
    transformer = DataPipeline(
        target_feature="value",
        period="1h",
        lookback_window_size=24,
        forecast_horizon=12,
        historical_features=["temp"],
    )
    mock_pipeline = Mock()
    transformed_df = sample_df_with_features.copy()
    mock_pipeline.transform.return_value = transformed_df
    transformer.data_pipeline = mock_pipeline

    transformer.fit(sample_df_with_features)

    mock_features = np.random.randn(132, 24, 2)  # 168 - 24 - 12 + 1 = 133 samples
    mock_targets = np.random.randn(132, 12)
    mock_feature_seq.return_value = mock_features
    mock_target_seq.return_value = mock_targets
    mock_stack.return_value = mock_features

    features, targets = transformer.transform(sample_df_with_features)
    assert features.shape == (132, 24, 2)  # samples, lookback, features
    assert targets.shape == (132, 12)  # samples, horizon
    # assert transformer.data.equals(transformed_df.sort_values(by="timestamp"))


@patch("twiga.core.data.pipeline.TemporalFeatureTransformer")
@patch("twiga.core.data.pipeline.AutoregressTransformer")
@patch("twiga.core.data.pipeline.get_feature_sequences")
@patch("twiga.core.data.pipeline.stack_features")
def test_transform_features(mock_stack, mock_feature_seq, mock_autoregress, mock_temporal, sample_df_with_features):
    """Test transforming data into features only."""
    # transformer = DataPipeline(
    #     target_feature="value",
    #     period="1h",
    #     lookback_window_size=24,
    #     forecast_horizon=12,
    #     historical_features=["temp"],
    #     calendar_features=["hour"],
    # )

    mock_pipeline = Mock()
    transformed_df = sample_df_with_features.copy()
    mock_pipeline.transform.return_value = transformed_df
    mock_temporal.return_value.transform.return_value = transformed_df  # Ensure TemporalFeatureTransformer returns Data
