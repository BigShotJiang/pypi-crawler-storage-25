from unittest.mock import patch

import pandas as pd
import pytest

from twiga.core.data.processing import augment_timeseries_signature
from twiga.core.data.temporal import TemporalFeatureTransformer


@pytest.fixture
def sample_df():
    dates = pd.date_range("2023-01-01", periods=24 * 7, freq="h")
    return pd.DataFrame({"timestamp": dates, "value": range(24 * 7)})


@pytest.fixture
def sample_df_with_features():
    dates = pd.date_range("2023-01-01", periods=10, freq="h")
    return pd.DataFrame({"timestamp": dates, "hour": dates.hour, "day_of_week": dates.dayofweek, "value": range(10)})


def test_init_default():
    transformer = TemporalFeatureTransformer()
    assert transformer.calendar_features is None
    assert transformer.latitude is None
    assert transformer.longitude is None
    assert transformer.date_column == "timestamp"
    assert transformer.calendar_trig == []
    assert transformer.calendar_non_trig == []
    assert transformer.exog_periods is None


def test_init_custom_params():
    transformer = TemporalFeatureTransformer(
        calendar_features=["hour", "day_night"], latitude=40.7128, longitude=-74.0060, date_column="date"
    )
    assert transformer.calendar_features == ["hour", "day_night"]
    assert transformer.latitude == 40.7128
    assert transformer.longitude == -74.0060
    assert transformer.date_column == "date"


@pytest.mark.parametrize(
    "calendar_features, expected_error", [(1, ValueError), ([1, 2], ValueError), ({"invalid": 1}, ValueError)]
)
def test_validate_calendar_features(calendar_features, expected_error):
    with pytest.raises(expected_error):
        TemporalFeatureTransformer(calendar_features=calendar_features)


def test_validate_date_column():
    with pytest.raises(TypeError):
        TemporalFeatureTransformer(date_column=123)


def test_validate_day_night_missing_coords():
    with pytest.raises(ValueError):
        TemporalFeatureTransformer(calendar_features=["day_night"])


def test_fit_valid_input(sample_df):
    transformer = TemporalFeatureTransformer()
    result = transformer.fit(sample_df)
    assert result is transformer


@patch("twiga.core.data.temporal.separate_trigonometric_features")
def test_fit_with_trig_features(mock_separate, sample_df):
    # Mock to return two trig features matching the two input features (hour_sin, hour_cos)
    mock_separate.return_value = (["hour", "hour"], [])
    transformer = TemporalFeatureTransformer(calendar_features=["hour_sin", "hour_cos"])
    transformer.fit(sample_df)
    assert transformer.calendar_non_trig == []
    assert transformer.exog_periods == [24, 24], f"Expected [24, 24], got {transformer.exog_periods}"


def test_fit_invalid_type():
    transformer = TemporalFeatureTransformer()
    with pytest.raises(TypeError):
        transformer.fit([1, 2, 3])


def test_fit_missing_date_column(sample_df):
    transformer = TemporalFeatureTransformer(date_column="nonexistent")
    with pytest.raises(ValueError):
        transformer.fit(sample_df)


@patch("twiga.core.data.processing.separate_trigonometric_features")
def test_fit_insufficient_unique_values(mock_separate):
    df = pd.DataFrame(
        {
            "timestamp": pd.date_range("2023-01-01", periods=1, freq="h"),
            "hour": [0],  # Only one unique value
        }
    )
    mock_separate.return_value = (["hour"], [])
    transformer = TemporalFeatureTransformer(calendar_features=["hour_sin"])
    with pytest.raises(ValueError, match="Feature 'hour' has too few unique values"):
        transformer.fit(df)


@patch("twiga.core.data.feature.add_day_night_feature")
@patch("twiga.core.data.feature.add_fourier_features")
def test_transform_basic(mock_fourier, mock_day_night, sample_df):
    mock_day_night.return_value = sample_df
    mock_fourier.return_value = sample_df
    transformer = TemporalFeatureTransformer()
    transformer.fit(sample_df)
    result = transformer.transform(sample_df)
    assert isinstance(result, pd.DataFrame)
    assert len(result) == len(sample_df)


@patch("twiga.core.data.feature.add_day_night_feature")
@patch("twiga.core.data.feature.add_fourier_features")
def test_transform_with_features(mock_fourier, mock_day_night, sample_df):
    # Simulate augmentation and feature addition
    augmented_df = augment_timeseries_signature(sample_df, date_column="timestamp")
    augmented_df.rename(columns=lambda x: x.replace("timestamp_", ""), inplace=True)
    augmented_df = augmented_df.loc[:, ~augmented_df.columns.duplicated(keep="first")]
    mock_day_night.return_value = augmented_df.assign(day_night=1)
    mock_fourier.return_value = mock_day_night.return_value.assign(hour_sin=0, hour_cos=0)
    transformer = TemporalFeatureTransformer(
        calendar_features=["hour_sin", "day_night"], latitude=40.7128, longitude=-74.0060
    )
    transformer.fit(sample_df)
    result = transformer.transform(sample_df)
    assert "hour" in result.columns, f"Columns present: {result.columns}"
    assert "day_night" in result.columns
    # assert mock_day_night.called
    # assert mock_fourier.called


def test_transform_invalid_type():
    transformer = TemporalFeatureTransformer()
    transformer.fit(pd.DataFrame({"timestamp": [pd.Timestamp("2023-01-01")], "value": [1]}))
    with pytest.raises(TypeError):
        transformer.transform([1, 2, 3])


def test_transform_missing_date_column(sample_df):
    transformer = TemporalFeatureTransformer(date_column="nonexistent")
    transformer.date_column = "timestamp"  # Fit with valid column
    transformer.fit(sample_df)
    transformer.date_column = "nonexistent"  # Transform with invalid column
    with pytest.raises(ValueError, match="date_column 'nonexistent' not found in X"):
        transformer.transform(sample_df)


@patch("twiga.core.data.feature.add_day_night_feature")
@patch("twiga.core.data.feature.add_fourier_features")
def test_fit_transform(mock_fourier, mock_day_night, sample_df):
    mock_day_night.return_value = sample_df
    mock_fourier.return_value = sample_df
    transformer = TemporalFeatureTransformer(calendar_features=["hour"])
    result = transformer.fit(sample_df).transform(sample_df)
    assert isinstance(result, pd.DataFrame)
    assert "hour" in result.columns


def test_init_string_calendar_features():
    """calendar_features as a string is normalised to a list."""
    transformer = TemporalFeatureTransformer(calendar_features="hour")
    assert transformer.calendar_features == ["hour"]


def test_fit_transform_method(sample_df):
    """fit_transform() returns the same result as fit().transform()."""
    transformer = TemporalFeatureTransformer()
    result = transformer.fit_transform(sample_df)
    assert isinstance(result, pd.DataFrame)
