"""Tests for twiga.core.data.relevance.AssociationAnalyzer."""

import numpy as np
import pandas as pd
import pytest

from twiga.core.data.relevance import AssociationAnalyzer


@pytest.fixture
def regression_data():
    rng = np.random.default_rng(99)
    n = 150
    x = rng.standard_normal(n)
    return pd.DataFrame(
        {
            "x1": x,
            "x2": rng.standard_normal(n),
            "x3": np.abs(rng.standard_normal(n)),  # non-negative for chi2
            "target": x * 2 + rng.standard_normal(n) * 0.3,
        }
    )


@pytest.fixture
def classification_data():
    rng = np.random.default_rng(0)
    n = 100
    return pd.DataFrame(
        {
            "x1": rng.integers(0, 5, n).astype(float),
            "x2": rng.integers(0, 3, n).astype(float),
            "label": rng.integers(0, 2, n),
        }
    )


STANDARD_COLUMNS = {"target", "feature", "score"}


class TestAssociationAnalyzerInit:
    def test_instantiation(self):
        a = AssociationAnalyzer(method="pearson", task="regression")
        assert a.method == "pearson"
        assert a.task == "regression"


class TestAssociationAnalyzerCompute:
    @pytest.mark.parametrize("method", ["pearson", "spearman", "kendall"])
    def test_rank_methods_return_standard_columns(self, regression_data, method):
        result = AssociationAnalyzer.compute(regression_data, "target", ["x1", "x2"], method=method)
        assert set(result.columns) >= STANDARD_COLUMNS

    def test_xicor_method(self, regression_data):
        result = AssociationAnalyzer.compute(regression_data, "target", ["x1", "x2"], method="xicor")
        assert set(result.columns) >= STANDARD_COLUMNS
        assert len(result) == 2

    def test_pps_method(self, regression_data):
        result = AssociationAnalyzer.compute(regression_data, "target", ["x1", "x2"], method="pps")
        assert set(result.columns) >= STANDARD_COLUMNS

    def test_mi_method(self, regression_data):
        result = AssociationAnalyzer.compute(regression_data, "target", ["x1", "x2"], method="mi")
        assert set(result.columns) >= STANDARD_COLUMNS
        assert (result["score"] >= 0).all()

    def test_anova_method_includes_p_value(self, regression_data):
        result = AssociationAnalyzer.compute(regression_data, "target", ["x1", "x2"], method="anova")
        assert "p_value" in result.columns

    def test_chi2_method_classification(self, classification_data):
        result = AssociationAnalyzer.compute(
            classification_data, "label", ["x1", "x2"], method="chi2", task="classification"
        )
        assert set(result.columns) >= STANDARD_COLUMNS

    def test_invalid_method_raises(self, regression_data):
        with pytest.raises(ValueError, match="Unsupported method"):
            AssociationAnalyzer.compute(regression_data, "target", ["x1"], method="bogus")

    def test_correlated_feature_ranks_first_spearman(self, regression_data):
        result = AssociationAnalyzer.compute(regression_data, "target", ["x1", "x2"], method="spearman")
        top_feature = result.iloc[0]["feature"]
        assert top_feature == "x1"


class TestAssociationAnalyzerPlotHeatmap:
    def test_empty_df_returns_none(self):
        df = pd.DataFrame(columns=["target", "feature", "score"])
        result = AssociationAnalyzer.plot_heatmap(df)
        assert result is None

    def test_non_empty_returns_plot_object(self, regression_data):
        result = AssociationAnalyzer.compute(regression_data, "target", ["x1", "x2"], method="spearman")
        plot = AssociationAnalyzer.plot_heatmap(result)
        assert plot is not None
