import numpy as np
import pandas as pd
import pytest

from twiga.core.data.processing import (
    _validate_target_feature,
    get_daily_sequences,
    get_feature_sequences,
    get_index,
    get_n_sample_per_day,
    get_target_sequences,
    stack_features,
    unstack_features,
)


def test_stack_historical_future_features_2d_basic():
    """Tests stacking 2D past and future features.

    Asserts:
        - Output is 3D with correct shape (batch_size=1, total_timesteps, max_features).
        - Past and future features are combined with padding applied.
    """
    past = np.ones((96, 2))  # 96 timesteps, 2 features
    future = np.ones((48, 10))  # 48 timesteps, 10 features
    result = stack_features(past, future)

    assert result.shape == (1, 144, 10)  # batch_size=1, 96+48 timesteps, max(2,10) features
    assert np.all(result[0, :96, :2] == 1)  # Past features preserved
    assert np.all(result[0, :96, 2:] == 0)  # Past padded with zeros
    assert np.all(result[0, 96:, :] == 1)  # Future features preserved


def test_unstack_features_past():
    past = np.ones((1, 96, 2))
    future = 2 * np.ones((1, 48, 10))
    combined = stack_features(past, future)

    recovered_past, recovered_future = unstack_features(
        combined_features=combined, lookback_window_size=96, forecast_horizon=48, num_padding=-8
    )

    assert past.shape == recovered_past.shape
    assert future.shape == recovered_future.shape


def test_unstack_features_future():
    past = np.ones((1, 96, 10))
    future = 2 * np.ones((1, 48, 2))
    combined = stack_features(past, future)

    recovered_past, recovered_future = unstack_features(
        combined_features=combined, lookback_window_size=96, forecast_horizon=48, num_padding=8
    )

    assert past.shape == recovered_past.shape
    assert future.shape == recovered_future.shape


def test_stack_historical_future_features_3d_basic():
    """Tests stacking 3D past and future features.

    Asserts:
        - Output shape is correct for batch_size > 1.
        - Features are combined and padded correctly across batches.
    """
    past = np.ones((2, 96, 2))  # 2 batches, 96 timesteps, 2 features
    future = np.ones((2, 48, 10))  # 2 batches, 48 timesteps, 10 features
    result = stack_features(past, future)

    assert result.shape == (2, 144, 10)  # 2 batches, 96+48 timesteps, max(2,10) features
    for b in range(2):
        assert np.all(result[b, :96, :2] == 1)  # Past features
        assert np.all(result[b, :96, 2:] == 0)  # Past padding
        assert np.all(result[b, 96:, :] == 1)  # Future features


def test_stack_historical_future_features_no_future():
    """Tests stacking with only past features (no future covariates).

    Asserts:
        - Output is the reshaped past features with batch_size=1 if 2D.
        - No changes to feature dimension when future is None.
    """
    past = np.ones((96, 2))  # 96 timesteps, 2 features
    result = stack_features(past, None)

    assert result.shape == (1, 96, 2)  # batch_size=1, 96 timesteps, 2 features
    assert np.all(result == 1)  # Past features unchanged


def test_stack_historical_future_features_padding_future():
    """Tests stacking when future has fewer features than past.

    Asserts:
        - Future features are padded to match past feature count.
        - Output shape and values are correct.
    """
    past = np.ones((96, 10))  # 96 timesteps, 10 features
    future = np.ones((48, 2))  # 48 timesteps, 2 features
    result = stack_features(past, future)

    assert result.shape == (1, 144, 10)  # batch_size=1, 96+48 timesteps, max(10,2) features
    assert np.all(result[0, :96, :] == 1)  # Past features unchanged
    assert np.all(result[0, 96:, :2] == 1)  # Future features preserved
    assert np.all(result[0, 96:, 2:] == 0)  # Future padded with zeros


def test_stack_historical_future_features_invalid_past_dim():
    """Tests error handling for invalid past_features dimensions.

    Asserts:
        - Raises ValueError for 1D or 4D past_features.
    """
    # 1D past_features
    past_1d = np.ones(96)
    with pytest.raises(ValueError) as exc_info:
        stack_features(past_1d, None)
    assert "past_features must be a 2D or 3D array, got 1 dimensions" in str(exc_info.value)

    # 4D past_features
    past_4d = np.ones((1, 1, 96, 2))
    with pytest.raises(ValueError) as exc_info:
        stack_features(past_4d, None)
    assert "past_features must be a 2D or 3D array, got 4 dimensions" in str(exc_info.value)


def test_stack_historical_future_features_invalid_future_dim():
    """Tests error handling for invalid future_covariates dimensions.

    Asserts:
        - Raises ValueError for 1D or 4D future_covariates.
    """
    past = np.ones((96, 2))
    # 1D future_covariates
    future_1d = np.ones(48)
    with pytest.raises(ValueError) as exc_info:
        stack_features(past, future_1d)
    assert "future_covariates must be a 2D or 3D array, got 1 dimensions" in str(exc_info.value)

    # 4D future_covariates
    future_4d = np.ones((1, 1, 48, 2))
    with pytest.raises(ValueError) as exc_info:
        stack_features(past, future_4d)
    assert "future_covariates must be a 2D or 3D array, got 4 dimensions" in str(exc_info.value)


def test_stack_historical_future_features_batch_mismatch():
    """Tests error handling for batch size mismatch between past and future.

    Asserts:
        - Raises ValueError when batch sizes differ.
    """
    past = np.ones((2, 96, 2))  # batch_size=2
    future = np.ones((3, 48, 2))  # batch_size=3
    with pytest.raises(ValueError) as exc_info:
        stack_features(past, future)
    assert "Batch size mismatch: past_features has 2, future_covariates has 3" in str(exc_info.value)


def test_get_index_insufficient_data():
    """Test the function with insufficient data."""
    # Create a sample DataFrame with insufficient data
    data = {"timestamp": pd.date_range(start="2023-01-01", periods=3, freq="D")}
    df = pd.DataFrame(data)

    lookback_window_size = 3
    forecast_horizon = 2

    # Call the function and expect an empty array
    result = get_index(df, lookback_window_size, forecast_horizon, test=True)

    # Assert that the result is an empty array
    assert result.size == 0, "Insufficient data test case failed"


def test_get_index_invalid_date_col():
    """Test the function with an invalid date column name."""
    # Create a sample DataFrame
    data = {"timestamp": pd.date_range(start="2023-01-01", periods=10, freq="D")}
    df = pd.DataFrame(data)

    lookback_window_size = 3
    forecast_horizon = 2

    # Test with an invalid date column name
    with pytest.raises(KeyError, match="Column 'invalid_col' not found in dataframe"):
        get_index(df, lookback_window_size, forecast_horizon, test=True, date_col_name="invalid_col")


def test_get_index_non_positive_window():
    """Test the function with non-positive lookback_window_size or forecast_horizon."""
    # Create a sample DataFrame
    data = {"timestamp": pd.date_range(start="2023-01-01", periods=10, freq="D")}
    df = pd.DataFrame(data)

    # Test with non-positive lookback_window_size
    with pytest.raises(ValueError, match="lookback_window_size or forecast_horizon are non-positive"):
        get_index(df, -1, 2, test=True)

    # Test with non-positive forecast_horizon
    with pytest.raises(ValueError, match="lookback_window_size or forecast_horizon are non-positive"):
        get_index(df, 3, 0, test=True)


# Tests for get_target_sequences
def test_get_target_sequences_basic():
    """Tests get_target_sequences with a simple univariate target array.

    Asserts:
        - Output shape is (n_sequences, forecast_horizon, n_features).
        - Sequences are correctly extracted starting after lookback_window_size.
    """
    targets = np.arange(10).reshape(-1, 1)  # [0, 1, 2, ..., 9], shape (10, 1)
    lookback_window_size = 3
    forecast_horizon = 2
    result = get_target_sequences(targets, lookback_window_size, forecast_horizon)

    assert result.shape == (6, 2, 1)  # 10 - 3 - 2 + 1 = 7 sequences
    assert np.all(result[0] == [[3], [4]])  # First sequence after window
    assert np.all(result[1] == [[4], [5]])  # Second sequence
    assert np.all(result[-1] == [[8], [9]])  # Last sequence


def test_get_target_sequences_multivariate():
    """Tests get_target_sequences with a multivariate target array.

    Asserts:
        - Output shape reflects multiple features.
        - Sequences preserve feature dimensions.
    """
    targets = np.array([[1, 2], [3, 4], [5, 6], [7, 8], [9, 10]])  # Shape (5, 2)
    lookback_window_size = 2
    forecast_horizon = 1
    result = get_target_sequences(targets, lookback_window_size, forecast_horizon)

    assert result.shape == (3, 1, 2)  # 5 - 2 - 1 + 1 = 3 sequences
    assert np.all(result[0] == [[5, 6]])  # First sequence
    assert np.all(result[1] == [[7, 8]])  # Second sequence
    assert np.all(result[2] == [[9, 10]])  # Last sequence


def test_get_target_sequences_exact_fit():
    """Tests get_target_sequences when input matches window plus horizon.

    Asserts:
        - Output has exactly one sequence when data fits perfectly.
    """
    targets = np.ones((5, 1))  # Shape (5, 1)
    lookback_window_size = 3
    forecast_horizon = 2
    result = get_target_sequences(targets, lookback_window_size, forecast_horizon)

    assert result.shape == (1, 2, 1)  # 5 - 3 - 2 + 1 = 1 sequence
    assert np.all(result[0] == [[1], [1]])  # Single sequence


# Tests for get_feature_sequences
def test_get_feature_sequences_basic():
    """Tests get_feature_sequences with a simple univariate feature array.

    Asserts:
        - Output shape is (n_sequences, lookback_window_size, n_features).
        - Sequences align with target sequences by trimming forecast_horizon.
    """
    features = np.arange(10).reshape(-1, 1)  # [0, 1, 2, ..., 9], shape (10, 1)
    lookback_window_size = 3
    forecast_horizon = 2
    result = get_feature_sequences(features, lookback_window_size, forecast_horizon)

    assert result.shape == (6, 3, 1)  # 10 - 3 + 1 - 2 = 7 sequences


def test_get_feature_sequences_multivariate():
    """Tests get_feature_sequences with a multivariate feature array.

    Asserts:
        - Output shape reflects multiple features.
        - Sequences preserve feature dimensions and trim correctly.
    """
    features = np.array([[1, 2], [3, 4], [5, 6], [7, 8], [9, 10]])  # Shape (5, 2)
    lookback_window_size = 2
    forecast_horizon = 1
    result = get_feature_sequences(features, lookback_window_size, forecast_horizon)

    assert result.shape == (3, 2, 2)  # 5 - 2 + 1 - 1 = 3 sequences
    assert np.all(result[0] == [[1, 2], [3, 4]])  # First sequence
    assert np.all(result[1] == [[3, 4], [5, 6]])  # Second sequence
    assert np.all(result[2] == [[5, 6], [7, 8]])  # Last sequence


def test_get_feature_sequences_exact_fit():
    """Tests get_feature_sequences when input matches window plus horizon.

    Asserts:
        - Output has exactly one sequence when data fits with trimming.
    """
    features = np.ones((5, 1))  # Shape (5, 1)
    lookback_window_size = 3
    forecast_horizon = 1
    result = get_feature_sequences(features, lookback_window_size, forecast_horizon)

    assert result.shape == (2, 3, 1)  # 5 - 3 + 1 - 1 = 2 sequences
    assert np.all(result[0] == [[1], [1], [1]])  # First sequence
    assert np.all(result[1] == [[1], [1], [1]])  # Second sequence


def test_get_feature_sequences_target_alignment():
    """Tests alignment between feature and target sequences.

    Asserts:
        - Feature sequences match the number of target sequences.
        - Last feature sequence ends before forecast horizon starts.
    """
    data = np.arange(10).reshape(-1, 1)  # Shape (10, 1)
    lookback_window_size = 3
    forecast_horizon = 2
    target_seq = get_target_sequences(data, lookback_window_size, forecast_horizon)
    feature_seq = get_feature_sequences(data, lookback_window_size, forecast_horizon)

    assert feature_seq.shape[0] == target_seq.shape[0]  # Same number of sequences (7)
    assert feature_seq.shape[1] == lookback_window_size  # 3 timesteps
    assert target_seq.shape[1] == forecast_horizon  # 2 timesteps


def test_get_feature_sequences_stride():
    """Tests that stride correctly subsamples feature windows.

    Asserts:
        - stride=1 (default) returns all windows.
        - stride=2 returns every other window with correct values.
        - stride=forecast_horizon produces non-overlapping windows.
        - Feature and target window counts match for any stride.
    """
    data = np.arange(12).reshape(-1, 1)  # [0..11], shape (12, 1)
    lookback_window_size = 3
    forecast_horizon = 2

    # stride=1: baseline — all windows (12 - 3 + 1 - 2 = 8 windows)
    result_s1 = get_feature_sequences(data, lookback_window_size, forecast_horizon, stride=1)
    assert result_s1.shape == (8, 3, 1)

    # stride=2: every other window → ceil(8/2) = 4 windows
    result_s2 = get_feature_sequences(data, lookback_window_size, forecast_horizon, stride=2)
    assert result_s2.shape == (4, 3, 1)
    assert np.all(result_s2[0] == [[0], [1], [2]])  # window 0
    assert np.all(result_s2[1] == [[2], [3], [4]])  # window 2
    assert np.all(result_s2[2] == [[4], [5], [6]])  # window 4
    assert np.all(result_s2[3] == [[6], [7], [8]])  # window 6

    # stride=forecast_horizon: non-overlapping — count = ceil(8/2) = 4
    result_sh = get_feature_sequences(data, lookback_window_size, forecast_horizon, stride=forecast_horizon)
    assert result_sh.shape[0] == result_s2.shape[0]


def test_get_target_sequences_stride():
    """Tests that stride correctly subsamples target windows.

    Asserts:
        - stride=1 (default) returns all windows.
        - stride=2 returns every other window with correct values.
        - Feature and target counts stay aligned for the same stride.
    """
    data = np.arange(12).reshape(-1, 1)  # [0..11], shape (12, 1)
    lookback_window_size = 3
    forecast_horizon = 2

    # stride=1: all windows (12 - 3 - 2 + 1 = 8 windows)
    result_s1 = get_target_sequences(data, lookback_window_size, forecast_horizon, stride=1)
    assert result_s1.shape == (8, 2, 1)

    # stride=2: every other window → 4 windows
    result_s2 = get_target_sequences(data, lookback_window_size, forecast_horizon, stride=2)
    assert result_s2.shape == (4, 2, 1)
    assert np.all(result_s2[0] == [[3], [4]])  # window 0: data[3:5]
    assert np.all(result_s2[1] == [[5], [6]])  # window 2: data[5:7]
    assert np.all(result_s2[2] == [[7], [8]])  # window 4: data[7:9]
    assert np.all(result_s2[3] == [[9], [10]])  # window 6: data[9:11]


def test_feature_target_alignment_with_stride():
    """Tests that feature and target windows stay aligned for any stride.

    Asserts:
        - For stride s, feature window k covers data[k*s : k*s+L].
        - The corresponding target window k covers data[k*s+L : k*s+L+H].
        - The last feature value (data[k*s+L-1]) immediately precedes the
          first target value (data[k*s+L]) for each k.
    """
    data = np.arange(20).reshape(-1, 1)
    lookback_window_size = 4
    forecast_horizon = 3

    for stride in (1, 2, 3):
        feat = get_feature_sequences(data, lookback_window_size, forecast_horizon, stride=stride)
        tgt = get_target_sequences(data, lookback_window_size, forecast_horizon, stride=stride)
        assert feat.shape[0] == tgt.shape[0], f"count mismatch for stride={stride}"
        for k in range(feat.shape[0]):
            # Last feature timestep + 1 == first target timestep
            assert feat[k, -1, 0] + 1 == tgt[k, 0, 0], f"alignment broken at k={k}, stride={stride}"


def test_get_daily_sequences_feature_mode():
    """Test daily sequence generation in feature mode (target_mode=False).

    Verifies that the function correctly extracts feature sequences from input data
    when target_mode is False. Tests sequence generation with multiple features
    and sliding window approach.

    Asserts:
        - Correct sequence extraction with sliding window
        - Proper shape preservation (n_sequences, lookback_window_size, n_features)
        - Accurate feature values in extracted sequences
    """
    # Create a sample data array
    data = np.array([[1, 2], [3, 4], [5, 6], [7, 8], [9, 10], [11, 12]])
    lookback_window_size = 2
    forecast_horizon = 1

    # Expected output for feature mode
    expected_output = np.array(
        [
            [[1, 2], [3, 4]],  # First sequence
            [[3, 4], [5, 6]],  # Second sequence
            [[5, 6], [7, 8]],  # Third sequence
            [[7, 8], [9, 10]],  # Fourth sequence
        ]
    )

    # Call the function
    result = get_daily_sequences(data, lookback_window_size, forecast_horizon, target_mode=False)

    # Assert that the result matches the expected output
    assert np.array_equal(result, expected_output), "Feature mode test failed"


def test_get_daily_sequences_target_mode():
    """Test daily sequence generation in target mode (target_mode=True).

    Verifies that the function correctly extracts target sequences from input data
    when target_mode is True. Tests proper offset and sequence extraction for
    forecast targets.

    Asserts:
        - Correct sequence extraction with proper offset
        - Target sequences start after lookback window
        - Proper shape preservation (n_sequences, forecast_horizon, n_features)
        - Accurate target values in extracted sequences
    """
    # Create a sample data array
    data = np.array([[1, 2], [3, 4], [5, 6], [7, 8], [9, 10], [11, 12]])
    lookback_window_size = 2
    forecast_horizon = 1

    # Expected output for target mode
    expected_output = np.array(
        [
            [[5, 6]],  # First sequence
            [[7, 8]],  # Second sequence
            [[9, 10]],  # Third sequence
            [[11, 12]],  # Fourth sequence
        ]
    )

    # Call the function
    result = get_daily_sequences(data, lookback_window_size, forecast_horizon, target_mode=True)

    # Assert that the result matches the expected output
    assert np.array_equal(result, expected_output), "Target mode test failed"


def test_get_daily_sequences_insufficient_data():
    """Test handling of insufficient data for sequence generation.

    Verifies that the function returns an empty array when input data length
    is less than required for creating even one sequence based on the lookback
    window and forecast horizon.

    Asserts:
        - Returns empty array when data is insufficient
        - No sequences generated for small datasets
    """
    # Create a sample data array with insufficient data
    data = np.array([[1, 2], [3, 4]])
    lookback_window_size = 3
    forecast_horizon = 1

    # Call the function and expect an empty array
    result = get_daily_sequences(data, lookback_window_size, forecast_horizon, target_mode=False)

    # Assert that the result is an empty array
    assert result.size == 0, "Insufficient data test failed"


def test_get_daily_sequences_large_forecast_horizon():
    """Test sequence generation with large forecast horizon.

    Verifies correct handling of cases where the forecast horizon significantly
    reduces the number of possible sequences due to required future data points.

    Asserts:
        - Correct number of sequences with large horizon
        - Proper sequence content despite limited data
        - Accurate handling of remaining valid sequences
    """
    # Create a sample data array
    data = np.array([[1, 2], [3, 4], [5, 6], [7, 8], [9, 10], [11, 12]])
    lookback_window_size = 2
    forecast_horizon = 4

    # Expected output for feature mode
    expected_output = np.array(
        [
            [[1, 2], [3, 4]]  # First sequence
        ]
    )

    # Call the function
    result = get_daily_sequences(data, lookback_window_size, forecast_horizon, target_mode=False)

    # Assert that the result matches the expected output
    assert np.array_equal(result, expected_output), "Large forecast horizon test failed"


def test_get_daily_sequences_single_feature():
    """Test sequence generation with univariate data.

    Verifies that the function correctly handles single-feature input data,
    maintaining proper dimensionality and sequence extraction.

    Asserts:
        - Correct handling of single-feature sequences
        - Proper shape preservation (n_sequences, window_size, 1)
        - Accurate sequence content for univariate data
    """
    # Create a sample data array with a single feature
    data = np.array([[1], [2], [3], [4], [5], [6]])
    lookback_window_size = 2
    forecast_horizon = 1

    # Expected output for feature mode
    expected_output = np.array(
        [
            [[1], [2]],  # First sequence
            [[2], [3]],  # Second sequence
            [[3], [4]],  # Third sequence
            [[4], [5]],  # Fourth sequence
        ]
    )

    # Call the function
    result = get_daily_sequences(data, lookback_window_size, forecast_horizon, target_mode=False)

    # Assert that the result matches the expected output
    assert np.array_equal(result, expected_output), "Single feature test failed"


def test_get_n_sample_per_day_minutes():
    """Test sample count calculation for minute-based periods.

    Verifies correct calculation of daily sample counts for various
    minute-based time periods common in time series data.

    Asserts:
        - Correct sample counts for each period
        - Consistent handling of alternative formats
    """
    assert get_n_sample_per_day("30min") == 48
    assert get_n_sample_per_day("15min") == 96
    assert get_n_sample_per_day("60T") == 24


def test_get_n_sample_per_day_hours():
    """Test sample count calculation for hour-based periods.

    Verifies correct calculation of daily sample counts for various
    hourly time periods used in time series data.

    Asserts:
        - Correct sample counts for each period
        - Proper division of 24-hour day
    """
    assert get_n_sample_per_day("1h") == 24
    assert get_n_sample_per_day("2h") == 12
    assert get_n_sample_per_day("4h") == 6


def test_get_n_sample_per_day_invalid_units():
    """Test error handling for invalid time period units.

    Verifies that the function properly rejects time periods with unsupported
    units, ensuring data consistency and proper time handling.

    Asserts:
        - Raises ValueError with appropriate message
        - Consistent error handling across invalid units
        - Clear indication of allowed units in error message
    """
    with pytest.raises(ValueError, match=r"Period unit 'D' is not allowed. Use 'min' or 'h' only"):
        get_n_sample_per_day("1D")
    with pytest.raises(ValueError, match=r"Period unit 'd' is not allowed. Use 'min' or 'h' only"):
        get_n_sample_per_day("2d")
    with pytest.raises(ValueError, match=r"Period unit 's' is not allowed. Use 'min' or 'h' only"):
        get_n_sample_per_day("30s")


def test_validate_target_feature_valid_string():
    """Test target series validation with valid string input.

    Verifies that the validation function correctly handles a single string input
    by converting it to a single-element list containing that string.

    Asserts:
        - Returns list containing the input string
        - Maintains string value integrity
    """
    assert _validate_target_feature("series1") == ["series1"]


def test_validate_target_feature_valid_list():
    """Test target series validation with valid string list.

    Verifies that the validation function correctly processes a list of strings,
    maintaining the order and content of the input list.

    Asserts:
        - Returns identical list of strings
        - Preserves order of elements
        - Maintains all string values
    """
    assert _validate_target_feature(["series1", "series2"]) == ["series1", "series2"]


def test_validate_target_feature_valid_single_list():
    """Test target series validation with single-element list.

    Verifies that the validation function correctly handles a list containing
    a single string element, preserving the list structure.

    Asserts:
        - Returns identical single-element list
        - Maintains list structure
        - Preserves string value
    """
    assert _validate_target_feature(["series1"]) == ["series1"]


def test_validate_target_feature_invalid_input_non_string():
    """Test target series validation with invalid non-string input.

    Verifies that the validation function correctly rejects non-string inputs,
    raising an appropriate error with a descriptive message.

    Asserts:
        - Raises ValueError with correct error message
        - Error message includes the invalid input value
        - Error message explains expected input type
    """
    target = 123  # Invalid input (not a string or list of strings)
    with pytest.raises(ValueError) as exc_info:
        _validate_target_feature(target)
    assert str(exc_info.value) == "target_feature: 123 should be a string or a list of strings"


def test_validate_target_feature_invalid_input_mixed_list():
    """Test target series validation with mixed-type list.

    Verifies that the validation function correctly rejects lists containing
    non-string elements, ensuring data type consistency.

    Asserts:
        - Raises ValueError with correct error message
        - Error message includes the invalid list content
        - Clearly indicates presence of non-string elements
    """
    target = ["series1", 123]  # Invalid input (mixed types in list)
    with pytest.raises(ValueError) as exc_info:
        _validate_target_feature(target)
    assert str(exc_info.value) == "target_feature: ['series1', 123] contains non-string elements"


def test_validate_target_feature_empty_list():
    """Test target series validation with empty list.

    Verifies that the validation function correctly handles empty lists,
    returning them unchanged to support optional target features.

    Asserts:
        - Returns empty list unchanged
        - Maintains list type
        - Provides informative assertion message
    """
    target = []
    result = _validate_target_feature(target)
    assert result == [], f"Expected [], but got {result}"
