import numpy as np
import pytest
import torch
from torch.utils.data import DataLoader, TensorDataset

from twiga.core.data.loader import TimeseriesDataModule


# Fixtures for reusable test data
@pytest.fixture
def sample_inputs():
    """Provide sample input data for testing.

    Returns:
        np.ndarray: A 3x2 array of float32 input features.
    """
    return np.array([[1, 2], [3, 4], [5, 6]], dtype=np.float32)


@pytest.fixture
def sample_targets():
    """Provide sample target data for testing.

    Returns:
        np.ndarray: A 3x1 array of float32 target values.
    """
    return np.array([[0], [1], [0]], dtype=np.float32)


@pytest.fixture
def sample_val_inputs():
    """Provide sample validation input data for testing.

    Returns:
        np.ndarray: A 2x2 array of float32 validation input features.
    """
    return np.array([[7, 8], [9, 10]], dtype=np.float32)


@pytest.fixture
def sample_val_targets():
    """Provide sample validation target data for testing.

    Returns:
        np.ndarray: A 2x1 array of float32 validation target values.
    """
    return np.array([[1], [0]], dtype=np.float32)


# Tests for TimeseriesDataModule
@pytest.fixture
def data_module(sample_inputs, sample_targets):
    """Provide a TimeseriesDataModule instance with training data only.

    Args:
        sample_inputs (np.ndarray): Input features fixture.
        sample_targets (np.ndarray): Target values fixture.

    Returns:
        TimeseriesDataModule: Initialized data module with batch_size=2 and num_workers=0.
    """
    return TimeseriesDataModule(
        train_inputs=sample_inputs,
        train_targets=sample_targets,
        batch_size=2,
        num_workers=0,
        persistent_workers=False,
    )


@pytest.fixture
def data_module_with_validation(sample_inputs, sample_targets, sample_val_inputs, sample_val_targets):
    """Provide a TimeseriesDataModule instance with training and validation data.

    Args:
        sample_inputs (np.ndarray): Input features fixture.
        sample_targets (np.ndarray): Target values fixture.
        sample_val_inputs (np.ndarray): Validation input features fixture.
        sample_val_targets (np.ndarray): Validation target values fixture.

    Returns:
        TimeseriesDataModule: Initialized data module with validation data, batch_size=2, and num_workers=0.
    """
    return TimeseriesDataModule(
        train_inputs=sample_inputs,
        train_targets=sample_targets,
        val_inputs=sample_val_inputs,
        val_targets=sample_val_targets,
        batch_size=2,
        num_workers=0,
        persistent_workers=False,
    )


def test_data_module_init(data_module, sample_inputs, sample_targets):
    """Test the initialization of TimeseriesDataModule with training data only.

    Args:
        data_module (TimeseriesDataModule): Data module fixture with training data.
        sample_inputs (np.ndarray): Input features fixture.
        sample_targets (np.ndarray): Target values fixture.

    Asserts:
        Attributes are correctly set, and no validation dataset is present.
    """
    assert np.array_equal(data_module.train_inputs, sample_inputs)
    assert np.array_equal(data_module.train_targets, sample_targets)
    assert data_module.val_inputs is None
    assert data_module.val_targets is None
    assert data_module.batch_size == 2
    assert data_module.num_workers == 0
    assert not data_module.persistent_workers
    assert data_module.pin_memory


def test_data_module_init_with_validation(
    data_module_with_validation, sample_inputs, sample_targets, sample_val_inputs, sample_val_targets
):
    """Test the initialization of TimeseriesDataModule with validation data.

    Args:
        data_module_with_validation (TimeseriesDataModule): Data module fixture with validation data.
        sample_inputs (np.ndarray): Input features fixture.
        sample_targets (np.ndarray): Target values fixture.
        sample_val_inputs (np.ndarray): Validation input features fixture.
        sample_val_targets (np.ndarray): Validation target values fixture.

    Asserts:
        Training and validation attributes are correctly set.
    """
    assert np.array_equal(data_module_with_validation.train_inputs, sample_inputs)
    assert np.array_equal(data_module_with_validation.train_targets, sample_targets)
    assert np.array_equal(data_module_with_validation.val_inputs, sample_val_inputs)
    assert np.array_equal(data_module_with_validation.val_targets, sample_val_targets)
    assert data_module_with_validation.batch_size == 2
    assert data_module_with_validation.num_workers == 0
    assert not data_module_with_validation.persistent_workers


def test_data_module_invalid_input_type(sample_targets):
    """Test error handling for non-numpy input arrays in TimeseriesDataModule.

    Args:
        sample_targets (np.ndarray): Target values fixture.

    Asserts:
        Raises TypeError when train_inputs is not a numpy array.
    """
    with pytest.raises(TypeError, match="All input arrays must be numpy ndarrays"):
        TimeseriesDataModule(
            train_inputs=[[1, 2], [3, 4]],  # List instead of np.ndarray
            train_targets=sample_targets,
        )


def test_data_module_mismatched_validation(sample_inputs, sample_targets):
    """Test error handling for mismatched validation inputs and targets in TimeseriesDataModule.

    Args:
        sample_inputs (np.ndarray): Input features fixture.
        sample_targets (np.ndarray): Target values fixture.

    Asserts:
        Raises ValueError when only val_inputs is provided without val_targets.
    """
    val_inputs = np.array([[7, 8]], dtype=np.float32)
    with pytest.raises(ValueError, match="Must provide both val_inputs and val_targets or neither"):
        TimeseriesDataModule(
            train_inputs=sample_inputs,
            train_targets=sample_targets,
            val_inputs=val_inputs,
            val_targets=None,
        )


def test_data_module_setup(data_module):
    """Test the setup method of TimeseriesDataModule with training data only.

    Args:
        data_module (TimeseriesDataModule): Data module fixture with training data.

    Asserts:
        Train dataset is a TensorDataset with correct tensor shapes and types.
    """
    data_module.setup("fit")
    assert isinstance(data_module.train_dataset, TensorDataset)
    assert len(data_module.train_dataset.tensors) == 2
    inputs, targets = data_module.train_dataset.tensors
    assert inputs.shape == (3, 2)
    assert targets.shape == (3, 1)
    assert inputs.dtype == torch.float32
    assert targets.dtype == torch.float32
    assert not hasattr(data_module, "val_dataset")


def test_data_module_setup_with_validation(data_module_with_validation):
    """Test the setup method of TimeseriesDataModule with validation data.

    Args:
        data_module_with_validation (TimeseriesDataModule): Data module fixture with validation data.

    Asserts:
        Train and validation datasets are TensorDatasets with correct tensor shapes and types.
    """
    data_module_with_validation.setup("fit")
    assert isinstance(data_module_with_validation.train_dataset, TensorDataset)
    assert isinstance(data_module_with_validation.val_dataset, TensorDataset)

    train_inputs, train_targets = data_module_with_validation.train_dataset.tensors
    assert train_inputs.shape == (3, 2)
    assert train_targets.shape == (3, 1)
    assert train_inputs.dtype == torch.float32
    assert train_targets.dtype == torch.float32

    val_inputs, val_targets = data_module_with_validation.val_dataset.tensors
    assert val_inputs.shape == (2, 2)
    assert val_targets.shape == (2, 1)
    assert val_inputs.dtype == torch.float32
    assert val_targets.dtype == torch.float32


def test_train_dataloader(data_module):
    """Test the train_dataloader method of TimeseriesDataModule.

    Args:
        data_module (TimeseriesDataModule): Data module fixture with training data.

    Asserts:
        DataLoader is correctly configured and yields expected batch shapes.
    """
    data_module.setup("fit")
    loader = data_module.train_dataloader()
    assert isinstance(loader, DataLoader)
    assert loader.batch_size == 2
    # assert loader.shuffle
    assert not loader.drop_last  # False when num_workers=0
    assert loader.num_workers == 0
    assert not loader.persistent_workers
    assert loader.prefetch_factor is None  # None when num_workers=0

    batches = list(loader)
    assert len(batches) == 2  # 3 samples, batch_size=2, no drop_last -> 2 batches
    features, targets = batches[0]
    assert features.shape == (2, 2)  # batch_size x num_features
    assert targets.shape == (2, 1)  # batch_size x target_dim


def test_val_dataloader(data_module_with_validation):
    """Test the val_dataloader method of TimeseriesDataModule.

    Args:
        data_module_with_validation (TimeseriesDataModule): Data module fixture with validation data.

    Asserts:
        DataLoader is correctly configured and yields expected batch shapes for validation data.
    """
    data_module_with_validation.setup("fit")
    loaders = data_module_with_validation.val_dataloader()
    assert isinstance(loaders, list)
    assert len(loaders) == 1
    loader = loaders[0]
    assert isinstance(loader, DataLoader)
    assert loader.batch_size == 2
    # assert not loader.shuffle
    assert not loader.drop_last
    assert loader.num_workers == 0
    assert not loader.persistent_workers
    assert loader.prefetch_factor is None

    batches = list(loader)
    assert len(batches) == 1  # 2 samples, batch_size=2 -> 1 batch
    features, targets = batches[0]
    assert features.shape == (2, 2)
    assert targets.shape == (2, 1)


def test_val_dataloader_empty(data_module):
    """Test val_dataloader when no validation data is provided.

    Args:
        data_module (TimeseriesDataModule): Data module fixture with training data only.

    Asserts:
        val_dataloader returns an empty list when no validation data is present.
    """
    data_module.setup("fit")
    assert data_module.val_dataloader() == []


def test_data_module_persistent_workers_with_num_workers(sample_inputs, sample_targets):
    """Test persistent_workers behavior when num_workers > 0.

    Args:
        sample_inputs (np.ndarray): Input features fixture.
        sample_targets (np.ndarray): Target values fixture.

    Asserts:
        persistent_workers is True when num_workers > 0 and persistent_workers=True.
    """
    data_module = TimeseriesDataModule(
        train_inputs=sample_inputs,
        train_targets=sample_targets,
        batch_size=2,
        num_workers=2,
        persistent_workers=True,
    )
    assert data_module.persistent_workers
    data_module.setup("fit")
    loader = data_module.train_dataloader()
    assert loader.drop_last  # True when num_workers > 0
    assert loader.prefetch_factor == 2  # Default when num_workers > 0
