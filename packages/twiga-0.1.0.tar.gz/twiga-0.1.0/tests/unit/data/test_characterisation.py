"""Tests for twiga.core.data.characterisation."""

from __future__ import annotations

from unittest.mock import patch

import numpy as np
import pandas as pd
from pydantic import ValidationError
import pytest

from twiga.core.data.characterisation import (
    CharacterisationConfig,
    CharacterisationResult,
    ComplexityProfile,
    PredictabilityResult,
    SignalCharacteriser,
    StationarityResult,
    TemporalStructureResult,
)

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def rng() -> np.random.Generator:
    return np.random.default_rng(42)


@pytest.fixture(scope="module")
def stationary_arr(rng) -> np.ndarray:
    """250-obs white-noise series — long enough for all tests."""
    return rng.standard_normal(250)


@pytest.fixture(scope="module")
def periodic_arr() -> np.ndarray:
    """400-obs series with clear daily periodicity (period=48)."""
    rng = np.random.default_rng(0)
    t = np.arange(400)
    return np.sin(2 * np.pi * t / 48) + 0.05 * rng.standard_normal(400)


@pytest.fixture(scope="module")
def stationary_df(stationary_arr) -> pd.DataFrame:
    return pd.DataFrame(
        {
            "timestamp": pd.date_range("2024-01-01", periods=len(stationary_arr), freq="30min"),
            "net_load": stationary_arr,
        }
    )


@pytest.fixture(scope="module")
def default_config() -> CharacterisationConfig:
    return CharacterisationConfig(n_samples_per_day=48, ami_max_horizons=30)


@pytest.fixture(scope="module")
def result(stationary_arr, default_config) -> CharacterisationResult:
    """Pre-computed result shared by multiple tests (slow AMI skipped via cap)."""
    return SignalCharacteriser(default_config).analyse(stationary_arr, target_column="net_load")


# ---------------------------------------------------------------------------
# CharacterisationConfig
# ---------------------------------------------------------------------------


class TestCharacterisationConfig:
    def test_defaults(self):
        cfg = CharacterisationConfig()
        assert cfg.alpha == pytest.approx(0.05)
        assert cfg.n_samples_per_day == 48
        assert cfg.ramp_threshold_pct == pytest.approx(90.0)
        assert cfg.max_seasonal_periods == 3
        assert cfg.n_neighbors_ami == 8
        assert cfg.ami_max_horizons is None
        assert cfg.ami_noise_floor == pytest.approx(0.10)
        assert cfg.ami_h1_low == pytest.approx(0.15)
        assert cfg.rel_auc_low == pytest.approx(0.15)
        assert cfg.rel_auc_high == pytest.approx(0.33)

    def test_alpha_bounds(self):
        with pytest.raises(ValidationError):
            CharacterisationConfig(alpha=0.0)
        with pytest.raises(ValidationError):
            CharacterisationConfig(alpha=1.0)

    def test_ramp_threshold_bounds(self):
        with pytest.raises(ValidationError):
            CharacterisationConfig(ramp_threshold_pct=0.0)
        with pytest.raises(ValidationError):
            CharacterisationConfig(ramp_threshold_pct=101.0)

    def test_n_samples_per_day_positive(self):
        with pytest.raises(ValidationError):
            CharacterisationConfig(n_samples_per_day=0)

    def test_ami_noise_floor_bounds(self):
        with pytest.raises(ValidationError):
            CharacterisationConfig(ami_noise_floor=0.0)
        with pytest.raises(ValidationError):
            CharacterisationConfig(ami_noise_floor=1.0)

    def test_ami_max_horizons_none_allowed(self):
        cfg = CharacterisationConfig(ami_max_horizons=None)
        assert cfg.ami_max_horizons is None

    def test_ami_max_horizons_positive(self):
        cfg = CharacterisationConfig(ami_max_horizons=50)
        assert cfg.ami_max_horizons == 50
        with pytest.raises(ValidationError):
            CharacterisationConfig(ami_max_horizons=0)


# ---------------------------------------------------------------------------
# StationarityResult
# ---------------------------------------------------------------------------


class TestStationarityResult:
    def test_frozen(self, result):
        with pytest.raises(ValidationError):
            result.stationarity.verdict = "stationary"  # type: ignore[misc]

    def test_verdict_values(self, result):
        assert result.stationarity.verdict in {"stationary", "non-stationary", "near-integrated", "fractional"}

    def test_integration_order_range(self, result):
        assert result.stationarity.integration_order in {0, 1, 2}

    def test_pvalue_in_unit_interval(self, result):
        s = result.stationarity
        assert 0.0 <= s.adf_pvalue <= 1.0
        assert 0.0 <= s.kpss_pvalue <= 1.0

    def test_recommendation_non_empty(self, result):
        assert len(result.stationarity.recommendation) > 0


# ---------------------------------------------------------------------------
# ComplexityProfile
# ---------------------------------------------------------------------------


class TestComplexityProfile:
    def test_three_regimes(self, result):
        assert len(result.complexity) == 3

    def test_regime_names(self, result):
        names = {p.regime for p in result.complexity}
        assert names == {"full", "stable", "ramp"}

    def test_regime_order(self, result):
        assert result.complexity[0].regime == "full"
        assert result.complexity[1].regime == "stable"
        assert result.complexity[2].regime == "ramp"

    def test_n_observations_non_negative(self, result):
        for profile in result.complexity:
            assert profile.n_observations >= 0

    def test_full_n_obs_equals_total(self, result, stationary_arr):
        full = next(p for p in result.complexity if p.regime == "full")
        assert full.n_observations == len(stationary_arr)

    def test_frozen(self, result):
        with pytest.raises(ValidationError):
            result.complexity[0].regime = "full"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# TemporalStructureResult
# ---------------------------------------------------------------------------


class TestTemporalStructureResult:
    def test_ar_order_non_negative(self, result):
        assert result.temporal.ar_order >= 0

    def test_significant_lags_sorted(self, result):
        lags = result.temporal.significant_lags
        assert lags == sorted(lags)

    def test_seasonal_periods_sorted(self, result):
        periods = result.temporal.seasonal_periods
        assert periods == sorted(periods)

    def test_suggested_lags_sorted(self, result):
        lags = result.temporal.suggested_lags
        assert lags == sorted(lags)

    def test_dominant_period_in_seasonal_or_none(self, result):
        dp = result.temporal.dominant_period
        if dp is not None:
            assert dp in result.temporal.seasonal_periods

    def test_frozen(self, result):
        with pytest.raises(ValidationError):
            result.temporal.ar_order = 99  # type: ignore[misc]


# ---------------------------------------------------------------------------
# PredictabilityResult
# ---------------------------------------------------------------------------


class TestPredictabilityResult:
    def test_frozen(self, result):
        with pytest.raises(ValidationError):
            result.predictability.label = "high"  # type: ignore[misc]

    def test_label_values(self, result):
        assert result.predictability.label in {"low", "moderate", "high"}

    def test_ami_h1_non_negative(self, result):
        assert result.predictability.ami_h1 >= 0.0

    def test_auc_non_negative(self, result):
        assert result.predictability.auc >= 0.0

    def test_rel_auc_non_negative(self, result):
        assert result.predictability.rel_auc >= 0.0

    def test_peak_ami_non_negative(self, result):
        assert result.predictability.peak_ami >= 0.0

    def test_peak_horizon_positive(self, result):
        assert result.predictability.peak_horizon >= 1

    def test_n_horizons_positive(self, result):
        assert result.predictability.n_horizons >= 1

    def test_effective_horizon_none_or_positive(self, result):
        eff = result.predictability.effective_horizon
        assert eff is None or eff >= 1

    def test_rel_auc_zero_when_ami_h1_zero(self):
        p = PredictabilityResult(
            ami_h1=0.0,
            auc=0.0,
            rel_auc=0.0,
            peak_ami=0.0,
            peak_horizon=1,
            effective_horizon=None,
            n_horizons=1,
            label="low",
        )
        assert p.rel_auc == 0.0
        assert p.effective_horizon is None


# ---------------------------------------------------------------------------
# CharacterisationResult — structure and to_pipeline_hints
# ---------------------------------------------------------------------------


class TestCharacterisationResult:
    def test_target_column_preserved(self, result):
        assert result.target_column == "net_load"

    def test_n_observations_matches_input(self, result, stationary_arr):
        assert result.n_observations == len(stationary_arr)

    def test_all_four_dimensions_present(self, result):
        assert isinstance(result.stationarity, StationarityResult)
        assert isinstance(result.complexity, list)
        assert isinstance(result.temporal, TemporalStructureResult)
        assert isinstance(result.predictability, PredictabilityResult)

    def test_frozen(self, result):
        with pytest.raises(ValidationError):
            result.target_column = "other"  # type: ignore[misc]

    def test_to_pipeline_hints_keys(self, result):
        hints = result.to_pipeline_hints()
        assert set(hints.keys()) == {"lags", "lookback_window_size", "integration_order", "max_forecast_horizon"}

    def test_to_pipeline_hints_lags_list(self, result):
        hints = result.to_pipeline_hints()
        assert isinstance(hints["lags"], list)

    def test_to_pipeline_hints_lookback_positive(self, result):
        hints = result.to_pipeline_hints()
        assert hints["lookback_window_size"] > 0

    def test_to_pipeline_hints_integration_order(self, result):
        hints = result.to_pipeline_hints()
        assert hints["integration_order"] in {0, 1, 2}

    def test_to_pipeline_hints_max_forecast_horizon(self, result):
        hints = result.to_pipeline_hints()
        eff = hints["max_forecast_horizon"]
        assert eff is None or isinstance(eff, int)


# ---------------------------------------------------------------------------
# SignalCharacteriser — input variants
# ---------------------------------------------------------------------------


class TestSignalCharacteriserInputs:
    def test_accepts_numpy_array(self, stationary_arr, default_config):
        r = SignalCharacteriser(default_config).analyse(stationary_arr)
        assert r.n_observations == len(stationary_arr)

    def test_accepts_pandas_series(self, stationary_arr, default_config):
        r = SignalCharacteriser(default_config).analyse(pd.Series(stationary_arr))
        assert r.n_observations == len(stationary_arr)

    def test_accepts_dataframe_with_target_column(self, stationary_df, default_config):
        r = SignalCharacteriser(default_config).analyse(stationary_df, target_column="net_load")
        assert r.target_column == "net_load"

    def test_dataframe_missing_column_raises(self, stationary_df, default_config):
        with pytest.raises(ValueError, match="not found in DataFrame"):
            SignalCharacteriser(default_config).analyse(stationary_df, target_column="missing")

    def test_too_short_raises(self, default_config):
        with pytest.raises(ValueError):
            SignalCharacteriser(default_config).analyse(np.ones(5))

    def test_nan_raises(self, default_config):
        arr = np.ones(50)
        arr[10] = np.nan
        with pytest.raises(ValueError, match="NaN"):
            SignalCharacteriser(default_config).analyse(arr)

    def test_2d_raises(self, default_config):
        with pytest.raises(ValueError):
            SignalCharacteriser(default_config).analyse(np.ones((50, 2)))

    def test_default_config_used_when_none(self, stationary_arr):
        r = SignalCharacteriser(None).analyse(stationary_arr)
        assert r.n_observations == len(stationary_arr)

    def test_default_target_column_label(self, stationary_arr, default_config):
        r = SignalCharacteriser(default_config).analyse(stationary_arr)
        assert r.target_column == "target"


# ---------------------------------------------------------------------------
# SignalCharacteriser — summary()
# ---------------------------------------------------------------------------


class TestSignalCharacteriserSummary:
    def test_returns_dataframe(self, result):
        df = SignalCharacteriser.summary(result)
        assert isinstance(df, pd.DataFrame)

    def test_columns(self, result):
        df = SignalCharacteriser.summary(result)
        assert list(df.columns) == ["Dimension", "Value"]

    def test_predictability_rows_present(self, result):
        df = SignalCharacteriser.summary(result)
        dims = df["Dimension"].tolist()
        assert any("Predictability" in d for d in dims)
        assert any("AMI(h=1)" in d for d in dims)
        assert any("effective horizon" in d for d in dims)

    def test_all_values_strings(self, result):
        df = SignalCharacteriser.summary(result)
        assert df["Value"].apply(lambda v: isinstance(v, str)).all()


# ---------------------------------------------------------------------------
# Predictability fallback — AMI failure is handled gracefully
# ---------------------------------------------------------------------------


class TestPredictabilityFallback:
    def test_fallback_on_ami_error(self, stationary_arr, default_config):
        """When get_ami_profile raises, _compute_predictability returns a low fallback."""
        with patch(
            "twiga.core.data.characterisation.get_ami_profile",
            side_effect=RuntimeError("mock failure"),
        ):
            r = SignalCharacteriser(default_config).analyse(stationary_arr)
        assert r.predictability.label == "low"
        assert r.predictability.ami_h1 == pytest.approx(0.0)

    def test_fallback_on_empty_ami(self, stationary_arr, default_config):
        """When get_ami_profile returns empty arrays, fallback is used."""
        with patch(
            "twiga.core.data.characterisation.get_ami_profile",
            return_value=(np.empty(0, dtype=int), np.empty(0, dtype=float)),
        ):
            r = SignalCharacteriser(default_config).analyse(stationary_arr)
        assert r.predictability.label == "low"


# ---------------------------------------------------------------------------
# Classification thresholds
# ---------------------------------------------------------------------------


class TestPredictabilityClassification:
    """Verify the three-tier classification rule by patching ami profile."""

    def _make_ami(self, ami_h1: float, mean_ami: float, n: int = 20) -> tuple[np.ndarray, np.ndarray]:
        horizons = np.arange(1, n + 1)
        # Build a profile whose mean equals mean_ami and first value equals ami_h1.
        values = np.full(n, mean_ami)
        values[0] = ami_h1
        return horizons, values

    def test_low_because_ami_h1_below_threshold(self, stationary_arr, default_config):
        cfg = CharacterisationConfig(ami_h1_low=0.15, ami_max_horizons=20)
        with patch(
            "twiga.core.data.characterisation.get_ami_profile",
            return_value=self._make_ami(0.05, 0.05),
        ):
            r = SignalCharacteriser(cfg).analyse(stationary_arr)
        assert r.predictability.label == "low"

    def test_low_because_rel_auc_below_threshold(self, stationary_arr):
        cfg = CharacterisationConfig(ami_h1_low=0.01, rel_auc_low=0.15, ami_max_horizons=20)
        with patch(
            "twiga.core.data.characterisation.get_ami_profile",
            return_value=self._make_ami(0.50, 0.05),  # rel_auc = 0.05/0.50 = 0.10 < 0.15
        ):
            r = SignalCharacteriser(cfg).analyse(stationary_arr)
        assert r.predictability.label == "low"

    def test_high_when_rel_auc_above_threshold(self, stationary_arr):
        cfg = CharacterisationConfig(ami_h1_low=0.01, rel_auc_high=0.33, ami_max_horizons=20)
        with patch(
            "twiga.core.data.characterisation.get_ami_profile",
            return_value=self._make_ami(0.50, 0.40),  # rel_auc = 0.40/0.50 = 0.80 >= 0.33
        ):
            r = SignalCharacteriser(cfg).analyse(stationary_arr)
        assert r.predictability.label == "high"

    def test_moderate_between_thresholds(self, stationary_arr):
        cfg = CharacterisationConfig(ami_h1_low=0.01, rel_auc_low=0.15, rel_auc_high=0.33, ami_max_horizons=20)
        with patch(
            "twiga.core.data.characterisation.get_ami_profile",
            return_value=self._make_ami(0.50, 0.12),  # rel_auc = 0.12/0.50 = 0.24 in (0.15, 0.33)
        ):
            r = SignalCharacteriser(cfg).analyse(stationary_arr)
        assert r.predictability.label == "moderate"
