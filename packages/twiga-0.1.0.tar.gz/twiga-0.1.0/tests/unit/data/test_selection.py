"""Tests for twiga.core.data.selection.

Covers:
- compute_rf_importance: pivot/long, regression/classification, edge cases
- select_top_features: top-k, alpha filter, rank aggregation, return_scores
"""

from functools import reduce

import numpy as np
import pandas as pd
import pytest

from twiga.core.data.selection import compute_rf_importance, select_top_features


@pytest.fixture
def regression_df():
    rng = np.random.default_rng(42)
    n = 80
    x1 = rng.standard_normal(n)
    x2 = rng.standard_normal(n) * 2
    x3 = rng.standard_normal(n) * 0.5
    target = 0.8 * x1 - 0.5 * x2 + rng.standard_normal(n) * 0.1
    return pd.DataFrame({"f1": x1, "f2": x2, "f3": x3, "target": target})


@pytest.fixture
def classification_df():
    rng = np.random.default_rng(42)
    n = 80
    f1 = rng.standard_normal(n)
    f2 = rng.standard_normal(n)
    f3 = rng.standard_normal(n)
    label = np.where(f1 > 0, "A", "B")
    return pd.DataFrame({"f1": f1, "f2": f2, "f3": f3, "target": label})


@pytest.fixture
def classification_df_encoded():
    rng = np.random.default_rng(42)
    n = 80
    f1 = rng.standard_normal(n)
    f2 = rng.standard_normal(n)
    f3 = rng.standard_normal(n)
    return pd.DataFrame({"f1": f1, "f2": f2, "f3": f3, "target": (f1 > 0).astype(int)})


@pytest.fixture
def chi2_df():
    rng = np.random.default_rng(0)
    n = 80
    return pd.DataFrame(
        {
            "f1": rng.integers(0, 2, n).astype(float),
            "f2": rng.integers(0, 5, n).astype(float),
            "f3": rng.integers(0, 3, n).astype(float),
            "target": rng.choice(["X", "Y"], n),
        }
    )


# ---------------------------------------------------------------------------
# compute_rf_importance
# ---------------------------------------------------------------------------


class TestComputeRfImportance:
    def test_long_format_columns(self, regression_df):
        result = compute_rf_importance(
            regression_df, "target", ["f1", "f2"], task="regression", n_estimators=10, pivot=False
        )
        assert list(result.columns) == ["feature", "rf_importance"]

    def test_row_count_matches_features(self, regression_df):
        result = compute_rf_importance(
            regression_df, "target", ["f1", "f2"], task="regression", n_estimators=10, pivot=False
        )
        assert result.shape[0] == 2

    def test_importances_non_negative(self, regression_df):
        result = compute_rf_importance(
            regression_df, "target", ["f1", "f2"], task="regression", n_estimators=10, pivot=False
        )
        assert (result["rf_importance"] >= 0).all()

    def test_importances_sum_to_one(self, regression_df):
        result = compute_rf_importance(
            regression_df, "target", ["f1", "f2", "f3"], task="regression", n_estimators=10, pivot=False
        )
        assert np.isclose(result["rf_importance"].sum(), 1.0)

    def test_pivot_sets_feature_index(self, regression_df):
        result = compute_rf_importance(
            regression_df, "target", ["f1", "f2"], task="regression", n_estimators=10, pivot=True
        )
        assert result.index.name == "feature"
        assert "rf_importance" in result.columns

    def test_classification_task(self, classification_df_encoded):
        result = compute_rf_importance(
            classification_df_encoded,
            "target",
            ["f1", "f2"],
            task="classification",
            n_estimators=10,
            pivot=False,
        )
        assert np.isclose(result["rf_importance"].sum(), 1.0)

    def test_single_feature_string(self, regression_df):
        result = compute_rf_importance(regression_df, "target", "f1", n_estimators=10, pivot=False)
        assert result.shape[0] == 1


# ---------------------------------------------------------------------------
# select_top_features
# ---------------------------------------------------------------------------


class TestSelectTopFeatures:
    def test_returns_list_regression(self, regression_df):
        top = select_top_features(regression_df, ["f1", "f2", "f3"], "target", task="regression", top_k=2, alpha=1.0)
        assert isinstance(top, list)
        assert len(top) == 2
        assert all(f in ["f1", "f2", "f3"] for f in top)

    def test_correlated_features_preferred(self, regression_df):
        top = select_top_features(
            regression_df,
            ["f1", "f2", "f3"],
            "target",
            task="regression",
            top_k=2,
            alpha=1.0,
            include_rf=False,
            include_pps=False,
            include_xi=False,
        )
        # f1 and f2 have signal; f3 is noise
        assert set(top) == {"f1", "f2"}

    def test_classification_task(self, classification_df):
        top = select_top_features(
            classification_df, ["f1", "f2", "f3"], "target", task="classification", top_k=2, alpha=1.0
        )
        assert len(top) == 2
        assert all(f in ["f1", "f2", "f3"] for f in top)

    def test_return_scores_tuple(self, regression_df):
        result = select_top_features(regression_df, ["f1", "f2"], "target", return_scores=True, alpha=1.0)
        assert isinstance(result, tuple)
        top, scores = result
        assert isinstance(top, list)
        assert isinstance(scores, pd.DataFrame)
        assert "feature" in scores.columns
        assert "borda_count" in scores.columns

    def test_alpha_filter_removes_noise(self, regression_df):
        rng = np.random.default_rng(1)
        regression_df["noise"] = rng.standard_normal(len(regression_df))
        top = select_top_features(
            regression_df, ["f1", "f2", "noise"], "target", task="regression", alpha=0.01, top_k=3
        )
        # With strict alpha the pure-noise feature should be filtered out
        assert len(top) <= 3

    def test_empty_features_returns_empty(self, regression_df):
        top = select_top_features(regression_df, [], "target")
        assert top == []

    def test_alpha_none_keeps_all(self, regression_df):
        top, _ = select_top_features(
            regression_df, ["f1", "f2", "f3"], "target", alpha=None, top_k=3, return_scores=True
        )
        assert len(top) == 3

    def test_borda_count_aggregation(self, regression_df):
        top = select_top_features(
            regression_df, ["f1", "f2", "f3"], "target", rank_aggregation="borda_count", top_k=2, alpha=1.0
        )
        assert len(top) == 2

    def test_geom_rank_aggregation(self, regression_df):
        top = select_top_features(
            regression_df, ["f1", "f2", "f3"], "target", rank_aggregation="geom_rank", top_k=2, alpha=1.0
        )
        assert len(top) == 2

    def test_include_rf_flag(self, regression_df):
        _, scores_with = select_top_features(
            regression_df, ["f1", "f2"], "target", include_rf=True, return_scores=True, alpha=1.0
        )
        _, scores_without = select_top_features(
            regression_df, ["f1", "f2"], "target", include_rf=False, return_scores=True, alpha=1.0
        )
        assert "rf_importance" in scores_with.columns
        assert "rf_importance" not in scores_without.columns

    def test_chi2_included_for_classification(self, chi2_df):
        _, scores = select_top_features(
            chi2_df,
            ["f1", "f2", "f3"],
            "target",
            task="classification",
            include_chi2=True,
            return_scores=True,
            alpha=1.0,
        )
        assert "chi2_score" in scores.columns

    def test_all_filtered_returns_empty(self, regression_df):
        top, scores = select_top_features(regression_df, ["f1", "f2"], "target", alpha=1e-100, return_scores=True)
        assert top == []
        assert scores.empty
