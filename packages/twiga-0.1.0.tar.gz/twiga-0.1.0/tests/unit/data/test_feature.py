from datetime import datetime

import numpy as np
import pandas as pd
import pytest

from twiga.core.data.feature import (
    add_day_night_feature,
    add_fourier_features,
    add_temporal_feature,  # Adjust import path
    compute_netload_ghi,  # Replace 'your_module' with the actual module name
    get_fourier_series,
    get_sunrise_sunset,
)


# Mock the internal _pandas_timeseries_signature function
@pytest.fixture
def mock_pandas_timeseries_signature(monkeypatch):
    """Fixture to mock _pandas_timeseries_signature with predictable temporal features.

    This fixture replaces the internal _pandas_timeseries_signature function with
    a simplified mock implementation that adds year, month, and day features
    to the DataFrame. This enables consistent, predictable testing of the
    feature generation functions that use this underlying functionality.

    Args:
        monkeypatch (pytest.MonkeyPatch): Pytest fixture for patching module attributes.

    Returns:
        None: Modifies twiga.core.data.feature._pandas_timeseries_signature in-place.
    """

    def mock_signature(data, date_column):
        # Mock output: add year, month, day features prefixed with "timestamp_"
        result = data.copy()
        dt = result[date_column].dt
        result[f"{date_column}_year"] = dt.year
        result[f"{date_column}_month"] = dt.month
        result[f"{date_column}_day"] = dt.day
        return result

    monkeypatch.setattr("twiga.core.data.feature._pandas_timeseries_signature", mock_signature)


def test_add_temporal_feature_basic(mock_pandas_timeseries_signature):
    """Test basic functionality of add_temporal_feature using default parameters.

    This test verifies that the add_temporal_feature function correctly adds
    basic temporal features (year, month, day) to a DataFrame using the default
    'timestamp' column. It checks both the presence of new features and the
    preservation of original data.

    Args:
        mock_pandas_timeseries_signature (fixture): Mock for temporal feature generation.

    Asserts:
        - Year, month, and day columns are added
        - Original column prefixes are removed
        - Original data length is preserved
        - Feature values are correct for each timestamp
        - Original columns remain unchanged
    """
    dates = pd.date_range("2023-01-01", periods=3, freq="D")
    data = pd.DataFrame({"timestamp": dates, "value": [1, 2, 3]})
    result = add_temporal_feature(data)

    assert "year" in result.columns
    assert "month" in result.columns
    assert "day" in result.columns
    assert "timestamp_year" not in result.columns  # Prefix removed
    assert len(result) == 3
    assert result["year"].tolist() == [2023, 2023, 2023]
    assert result["month"].tolist() == [1, 1, 1]
    assert result["day"].tolist() == [1, 2, 3]
    assert result["value"].tolist() == [1, 2, 3]  # Original column unchanged


def test_add_temporal_feature_custom_column_name(mock_pandas_timeseries_signature):
    """Tests add_temporal_feature with a custom datetime column name.

    Args:
        mock_pandas_timeseries_signature: Fixture mocking temporal feature extraction.

    Asserts:
        - Temporal features are added based on custom column.
        - Prefix is removed from feature names.
    """
    dates = pd.date_range("2023-01-01", periods=2, freq="D")
    data = pd.DataFrame({"custom_date": dates, "value": [10, 20]})
    result = add_temporal_feature(data, date_col_name="custom_date")

    assert "year" in result.columns
    assert "month" in result.columns
    assert "day" in result.columns
    assert "custom_date_year" not in result.columns  # Prefix removed
    assert len(result) == 2
    assert result["year"].tolist() == [2023, 2023]
    assert result["month"].tolist() == [1, 1]
    assert result["day"].tolist() == [1, 2]
    assert result["value"].tolist() == [10, 20]


def test_add_temporal_feature_missing_column():
    """Tests add_temporal_feature with a missing datetime column.

    Asserts:
        - Raises KeyError with appropriate message.
    """
    data = pd.DataFrame({"value": [1, 2, 3]})
    with pytest.raises(KeyError) as exc_info:
        add_temporal_feature(data, date_col_name="timestamp")
    assert "Column 'timestamp' not found in DataFrame" in str(exc_info.value)


def test_add_temporal_feature_non_datetime_column():
    """Tests add_temporal_feature with a non-datetime column.

    Asserts:
        - Raises ValueError with appropriate message.
    """
    data = pd.DataFrame({"timestamp": [1, 2, 3]})  # Integers, not datetime
    with pytest.raises(ValueError) as exc_info:
        add_temporal_feature(data, date_col_name="timestamp")
    assert "Column 'timestamp' must be datetime-like" in str(exc_info.value)


def test_get_fourier_series_datetime_input():
    """Tests get_fourier_series with a pandas Series of datetime values.

    Asserts:
        - Output shape is (len(dates), 2 * series_order).
        - Sine and cosine terms are correctly computed for absolute days since epoch.
    """
    dates = pd.date_range("2023-01-01", periods=3, freq="D")
    period = 365.25  # Yearly seasonality
    series_order = 1  # 1 sine/cosine pair
    result = get_fourier_series(dates, period, series_order)

    assert result.shape == (3, 2)  # 3 timesteps, 2 columns (sin, cos)
    t = np.array([19358, 19359, 19360])  # Days since 1970-01-01
    omega = 2 * np.pi / period
    assert np.allclose(result[:, 0], np.sin(omega * t), atol=1e-6)  # Sine terms
    assert np.allclose(result[:, 1], np.cos(omega * t), atol=1e-6)  # Cosine terms


def test_get_fourier_series_numpy_input():
    """Tests get_fourier_series with a numpy array of days since epoch.

    Asserts:
        - Output shape is correct.
        - Values match expected Fourier series for given days.
    """
    dates = np.array([0, 1, 2])  # Days since epoch
    period = 7.0  # Weekly seasonality
    series_order = 2  # 2 sine/cosine pairs
    result = get_fourier_series(dates, period, series_order)

    assert result.shape == (3, 4)  # 3 timesteps, 4 columns (sin1, cos1, sin2, cos2)
    t = np.array([0, 1, 2])
    omega = 2 * np.pi / period
    assert np.allclose(result[:, 0], np.sin(omega * t), atol=1e-6)  # sin(2πt/period)
    assert np.allclose(result[:, 1], np.cos(omega * t), atol=1e-6)  # cos(2πt/period)
    assert np.allclose(result[:, 2], np.sin(2 * omega * t), atol=1e-6)  # sin(4πt/period)
    assert np.allclose(result[:, 3], np.cos(2 * omega * t), atol=1e-6)  # cos(4πt/period)


def test_get_fourier_series_list_input():
    """Tests get_fourier_series with a list of datetime values.

    Asserts:
        - Output shape is correct.
        - Values are consistent with datetime input as days since epoch.
    """
    dates = [pd.Timestamp("2023-01-01"), pd.Timestamp("2023-01-02")]
    period = 365.25
    series_order = 1
    result = get_fourier_series(dates, period, series_order)

    assert result.shape == (2, 2)  # 2 timesteps, 2 columns
    t = np.array([19358, 19359])  # Days since 1970-01-01 for 2023-01-01, 2023-01-02
    omega = 2 * np.pi / period
    assert np.allclose(result[:, 0], np.sin(omega * t), atol=1e-6)
    assert np.allclose(result[:, 1], np.cos(omega * t), atol=1e-6)


def test_get_fourier_series_multiple_orders():
    """Tests get_fourier_series with multiple Fourier orders.

    Asserts:
        - Output shape reflects multiple sine/cosine pairs.
        - Higher-order terms are correctly computed for absolute days.
    """
    dates = pd.Series([pd.Timestamp("2023-01-01"), pd.Timestamp("2023-01-02")])
    period = 7.0
    series_order = 3  # 3 sine/cosine pairs
    result = get_fourier_series(dates, period, series_order)

    assert result.shape == (2, 6)  # 2 timesteps, 6 columns
    t = np.array([19358, 19359])  # Days since 1970-01-01
    omega = 2 * np.pi / period
    for k in range(1, 4):  # Orders 1, 2, 3
        assert np.allclose(result[:, 2 * (k - 1)], np.sin(k * omega * t), atol=1e-6)
        assert np.allclose(result[:, 2 * (k - 1) + 1], np.cos(k * omega * t), atol=1e-6)


def test_get_fourier_series_negative_period():
    """Tests get_fourier_series with a negative period.

    Asserts:
        - Raises ValueError with appropriate message.
    """
    dates = pd.Series([pd.Timestamp("2023-01-01")])
    with pytest.raises(ValueError) as exc_info:
        get_fourier_series(dates, period=-1.0, series_order=1)
    assert "Period must be a positive number, got -1.0" in str(exc_info.value)


def test_get_fourier_series_zero_period():
    """Tests get_fourier_series with a zero period.

    Asserts:
        - Raises ValueError with appropriate message.
    """
    dates = pd.Series([pd.Timestamp("2023-01-01")])
    with pytest.raises(ValueError) as exc_info:
        get_fourier_series(dates, period=0.0, series_order=1)
    assert "Period must be a positive number, got 0.0" in str(exc_info.value)


def test_get_fourier_series_negative_series_order():
    """Tests get_fourier_series with a negative series order.

    Asserts:
        - Raises ValueError with appropriate message.
    """
    dates = pd.Series([pd.Timestamp("2023-01-01")])
    with pytest.raises(ValueError) as exc_info:
        get_fourier_series(dates, period=365.25, series_order=-1)
    assert "Series order must be a non-negative integer, got -1" in str(exc_info.value)


def test_get_fourier_series_non_integer_series_order():
    """Tests get_fourier_series with a non-integer series order.

    Asserts:
        - Raises ValueError with appropriate message.
    """
    dates = pd.Series([pd.Timestamp("2023-01-01")])
    with pytest.raises(ValueError) as exc_info:
        get_fourier_series(dates, period=365.25, series_order=1.5)
    assert "Series order must be a non-negative integer, got 1.5" in str(exc_info.value)


def test_get_fourier_series_empty_input():
    """Tests get_fourier_series with an empty input.

    Asserts:
        - Raises ValueError with appropriate message.
    """
    dates = pd.Series([])
    with pytest.raises(ValueError) as exc_info:
        get_fourier_series(dates, period=365.25, series_order=1)
    assert "Dates array cannot be empty" in str(exc_info.value)


# Mock astral.sun.sun to return predictable sunrise/sunset times
@pytest.fixture
def mock_sun(monkeypatch):
    """Fixture to mock astral.sun.sun with fixed sunrise/sunset times.

    Args:
        monkeypatch: Pytest fixture for patching module attributes.

    Returns:
        None: Modifies the behavior of twiga.utils.sun in-place.
    """

    def mock_sun_function(observer, date, **kwargs):
        # Mock sunrise at 6:00 AM UTC and sunset at 6:00 PM UTC
        base_date = pd.Timestamp(date).replace(tzinfo=None).replace(hour=0, minute=0, second=0)
        return {
            "sunrise": base_date.replace(hour=6, minute=0, second=0),
            "sunset": base_date.replace(hour=18, minute=0, second=0),
        }

    monkeypatch.setattr("twiga.core.data.feature.sun", mock_sun_function)


# Tests for get_sunrise_sunset
def test_get_sunrise_sunset_basic(mock_sun):
    """Tests get_sunrise_sunset with a two-day range.

    Args:
        mock_sun: Fixture that mocks sunrise/sunset times.

    Asserts:
        - Result has 2 days.
        - Keys are correct dates.
        - Sunrise is 6 AM and sunset is 6 PM for Jan 1, 2023.
    """
    start_date = pd.Timestamp("2023-01-01")
    end_date = pd.Timestamp("2023-01-02")
    result = get_sunrise_sunset(start_date, end_date, latitude=40.7128, longitude=-74.0060)

    assert len(result) == 2
    assert list(result.keys()) == [datetime(2023, 1, 1).date(), datetime(2023, 1, 2).date()]
    assert isinstance(result[datetime(2023, 1, 1).date()], dict)
    assert "sunrise" in result[datetime(2023, 1, 1).date()]
    assert "sunset" in result[datetime(2023, 1, 1).date()]
    assert result[datetime(2023, 1, 1).date()]["sunrise"] == pd.Timestamp("2023-01-01 06:00:00")
    assert result[datetime(2023, 1, 1).date()]["sunset"] == pd.Timestamp("2023-01-01 18:00:00")


def test_get_sunrise_sunset_single_day(mock_sun):
    """Tests get_sunrise_sunset with a single-day range.

    Args:
        mock_sun: Fixture that mocks sunrise/sunset times.

    Asserts:
        - Result has 1 day.
        - Sunrise is at 6 AM and sunset at 6 PM.
    """
    start_date = pd.Timestamp("2023-01-01")
    end_date = pd.Timestamp("2023-01-01")
    result = get_sunrise_sunset(start_date, end_date)

    assert len(result) == 1
    assert datetime(2023, 1, 1).date() in result
    assert result[datetime(2023, 1, 1).date()]["sunrise"].hour == 6
    assert result[datetime(2023, 1, 1).date()]["sunset"].hour == 18


def test_get_sunrise_sunset_default_coordinates(mock_sun):
    """Tests get_sunrise_sunset with default latitude/longitude.

    Args:
        mock_sun: Fixture that mocks sunrise/sunset times.

    Asserts:
        - Result has 1 day.
        - Sunrise and sunset are Timestamps with expected hours.
    """
    start_date = pd.Timestamp("2023-01-01")
    end_date = pd.Timestamp("2023-01-01")
    result = get_sunrise_sunset(start_date, end_date)  # Uses defaults: 32.738274, -16.738519

    assert len(result) == 1
    assert isinstance(result[datetime(2023, 1, 1).date()]["sunrise"], pd.Timestamp)
    assert isinstance(result[datetime(2023, 1, 1).date()]["sunset"], pd.Timestamp)
    assert result[datetime(2023, 1, 1).date()]["sunrise"].hour == 6
    assert result[datetime(2023, 1, 1).date()]["sunset"].hour == 18


# Tests for add_day_night_feature
def test_add_day_night_feature_basic(mock_sun):
    """Tests add_day_night_feature with a single day of hourly data.

    Args:
        mock_sun: Fixture that mocks sunrise/sunset times.

    Asserts:
        - 'day_night' column is added.
        - Correct day/night values (0 before 6 AM, 1 from 6 AM to 6 PM, 0 after 6 PM).
    """
    timestamps = pd.date_range("2023-01-01 00:00", "2023-01-01 23:00", freq="h")
    data = pd.DataFrame({"timestamp": timestamps, "value": np.random.rand(len(timestamps))})
    result = add_day_night_feature(data, latitude=40.7128, longitude=-74.0060, date_col_name="timestamp")

    assert "day_night" in result.columns
    assert len(result) == 24
    assert result.loc[result["timestamp"] == "2023-01-01 05:00", "day_night"].iloc[0] == 0  # Before sunrise
    assert result.loc[result["timestamp"] == "2023-01-01 12:00", "day_night"].iloc[0] == 1  # Daytime
    assert result.loc[result["timestamp"] == "2023-01-01 19:00", "day_night"].iloc[0] == 0  # After sunset


def test_add_day_night_feature_missing_column():
    """Tests add_day_night_feature with a missing datetime column.

    Asserts:
        - Raises KeyError with appropriate message.
    """
    data = pd.DataFrame({"value": [1, 2, 3]})
    with pytest.raises(KeyError) as exc_info:
        add_day_night_feature(data, latitude=40.7128, longitude=-74.0060, date_col_name="timestamp")
    assert "Column 'timestamp' not found in DataFrame" in str(exc_info.value)


def test_add_day_night_feature_non_datetime_column():
    """Tests add_day_night_feature with a non-datetime column.

    Asserts:
        - Raises ValueError with appropriate message.
    """
    data = pd.DataFrame({"timestamp": [1, 2, 3]})
    with pytest.raises(ValueError) as exc_info:
        add_day_night_feature(data, latitude=40.7128, longitude=-74.0060, date_col_name="timestamp")
    assert "Column 'timestamp' must be datetime-like" in str(exc_info.value)


def test_add_day_night_feature_custom_column_name(mock_sun):
    """Tests add_day_night_feature with a custom datetime column name.

    Args:
        mock_sun: Fixture that mocks sunrise/sunset times.

    Asserts:
        - 'day_night' column is added.
        - Correct daytime value at 12 PM.
    """
    timestamps = pd.date_range("2023-01-01 00:00", "2023-01-01 23:00", freq="h")
    data = pd.DataFrame({"datetime_col": timestamps, "value": np.random.rand(len(timestamps))})
    result = add_day_night_feature(data, latitude=40.7128, longitude=-74.0060, date_col_name="datetime_col")

    assert "day_night" in result.columns
    assert result.loc[result["datetime_col"] == "2023-01-01 12:00", "day_night"].iloc[0] == 1


def test_add_day_night_feature_multi_day(mock_sun):
    """Tests add_day_night_feature with multiple days of hourly data.

    Args:
        mock_sun: Fixture that mocks sunrise/sunset times.

    Asserts:
        - Correct length (48 hours).
        - All day_night values are 0 or 1.
        - Correct value at sunrise (6 AM).
    """
    timestamps = pd.date_range("2023-01-01 00:00", "2023-01-02 23:00", freq="h")
    data = pd.DataFrame({"timestamp": timestamps, "value": np.random.rand(len(timestamps))})

    result = add_day_night_feature(data, latitude=40.7128, longitude=-74.0060)
    assert len(result) == 48
    assert result["day_night"].isin([0, 1]).all()
    assert result.loc[result["timestamp"] == "2023-01-02 06:00", "day_night"].iloc[0] == 1  # At sunrise


def test_empty_input():
    """Test compute_netload_ghi with insufficient data samples.

    Verifies that the function returns an empty array when the input data
    has fewer elements than required for a full day of samples.

    Asserts:
        - Result array is empty when input length < num_samples_per_day
    """
    load = np.array([1, 2, 3])
    ghi = np.array([4, 5, 6])
    num_samples_per_day = 5
    result = compute_netload_ghi(load, ghi, num_samples_per_day)
    assert result.size == 0, "Expected empty array for insufficient data"


def test_exact_one_day():
    """Test compute_netload_ghi with exactly one day of data.

    Verifies correct normalization and difference calculation when provided
    with exactly enough data points for one day after the offset period.

    Notes:
        - Input arrays have length num_samples_per_day * 2
        - First half is used for load, second half for GHI
        - Values are normalized by their respective maximum absolutes

    Asserts:
        - Output matches expected normalized difference calculation
        - Proper handling of array slicing and normalization
    """
    load = np.array([1, 2, 3, 4, 5, 6])  # 6 elements, enough for 1 day
    ghi = np.array([2, 4, 6, 8, 10, 12])
    num_samples_per_day = 3
    result = compute_netload_ghi(load, ghi, num_samples_per_day)
    expected_load_norm = load[0:3] / np.max(np.abs(load[0:3]))  # [1, 2, 3] / 3
    expected_ghi_norm = ghi[3:6] / np.max(np.abs(ghi[3:6]))  # [8, 10, 12] / 12
    expected = expected_load_norm - expected_ghi_norm
    np.testing.assert_almost_equal(result, expected, decimal=6, err_msg="Failed for exact one day data")


def test_multiple_days():
    """Test compute_netload_ghi with multiple days of data.

    Verifies correct processing of multi-day data including:
    - Proper segmentation into daily chunks
    - Correct normalization per day
    - Accurate difference calculation

    Notes:
        - Tests with 2 days of data (9 samples total)
        - Each day uses 3 samples
        - Values are normalized per day before subtraction

    Asserts:
        - Output contains expected number of days
        - Each day's values are properly normalized and differenced
    """
    load = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])
    ghi = np.array([2, 4, 6, 8, 10, 12, 14, 16, 18])
    num_samples_per_day = 3
    result = compute_netload_ghi(load, ghi, num_samples_per_day)
    # Expected: 2 days -> [1,2,3] - [8,10,12] and [4,5,6] - [14,16,18]
    load_day1 = load[0:3] / 3.0  # [1/3, 2/3, 1]
    ghi_day1 = ghi[3:6] / 12.0  # [8/12, 10/12, 1]
    load_day2 = load[3:6] / 6.0  # [4/6, 5/6, 1]
    ghi_day2 = ghi[6:9] / 18.0  # [14/18, 16/18, 1]
    expected = np.concatenate([load_day1 - ghi_day1, load_day2 - ghi_day2])
    np.testing.assert_almost_equal(result, expected, decimal=6, err_msg="Failed for multiple days")


def test_zero_load_ghi():
    """Test compute_netload_ghi with zero values in load or GHI.

    Verifies correct handling of zero values in either load or GHI arrays,
    ensuring proper normalization when maximum values are zero.

    Notes:
        - Tests with zeros in both load and corresponding GHI periods
        - Checks handling of division by zero prevention

    Asserts:
        - Correct handling of zero maximum values
        - Output maintains expected shape
        - Values are properly normalized and differenced
    """
    load = np.array([0, 0, 0, 1, 2, 3])
    ghi = np.array([1, 2, 3, 0, 0, 0])
    num_samples_per_day = 3
    result = compute_netload_ghi(load, ghi, num_samples_per_day)
    # Day 1: load [0,0,0] / 1 (due to zero max), ghi [0,0,0] / 1 (due to zero max)
    expected = np.array([0, 0, 0])  # [0/1 - 0/1] for all
    np.testing.assert_almost_equal(result, expected, decimal=6, err_msg="Failed for zero load/GHI handling")


def test_negative_values():
    """Test compute_netload_ghi with negative input values.

    Verifies correct processing of negative values in both load and GHI arrays,
    ensuring proper normalization and difference calculation.

    Notes:
        - Tests with negative values in both arrays
        - Checks normalization using absolute maximum values
        - Verifies correct sign handling in differences

    Asserts:
        - Proper normalization of negative values
        - Correct difference calculation
        - Preservation of expected signs
    """
    load = np.array([-2, -1, 0, -4, -3, -2])
    ghi = np.array([1, 2, 3, -3, -2, -1])
    num_samples_per_day = 3
    result = compute_netload_ghi(load, ghi, num_samples_per_day)
    # Day 1: load [-2,-1,0] / 2, ghi [-3,-2,-1] / 3
    load_norm = np.array([-2, -1, 0]) / 2.0  # [-1, -0.5, 0]
    ghi_norm = np.array([-3, -2, -1]) / 3.0  # [-1, -2/3, -1/3]
    expected = load_norm - ghi_norm
    np.testing.assert_almost_equal(result, expected, decimal=6, err_msg="Failed for negative values")


def test_large_dataset():
    """Test compute_netload_ghi with a large dataset.

    Verifies the function's scalability and correct handling of larger arrays,
    ensuring consistent behavior with more data points.

    Notes:
        - Tests with 100 random samples
        - Uses different scales for load and GHI
        - Verifies proper handling of floating-point operations

    Asserts:
        - Output shape matches expected dimensions
        - No NaN values in result
        - Correct number of days processed
    """
    load = np.random.rand(100) * 100
    ghi = np.random.rand(100) * 50
    num_samples_per_day = 10
    result = compute_netload_ghi(load, ghi, num_samples_per_day)
    n_days = (len(load) - num_samples_per_day) // num_samples_per_day  # 9 days
    assert result.shape == (n_days * num_samples_per_day,), "Incorrect output size for large dataset"
    assert not np.any(np.isnan(result)), "Result contains NaN values"


def test_non_numpy_input():
    """Test compute_netload_ghi with Python list inputs.

    Verifies that the function correctly handles non-NumPy array inputs,
    properly converting them to NumPy arrays and maintaining accuracy.

    Notes:
        - Tests with Python lists instead of NumPy arrays
        - Verifies automatic type conversion
        - Checks normalization and difference calculation

    Asserts:
        - Correct handling of list inputs
        - Proper normalization of converted arrays
        - Accurate difference calculation
    """
    load = [1, 2, 3, 4, 5, 6]
    ghi = [2, 4, 6, 8, 10, 12]
    num_samples_per_day = 3
    result = compute_netload_ghi(load, ghi, num_samples_per_day)
    expected_load_norm = np.array([1, 2, 3]) / 3.0
    expected_ghi_norm = np.array([8, 10, 12]) / 12.0
    expected = expected_load_norm - expected_ghi_norm
    np.testing.assert_almost_equal(result, expected, decimal=6, err_msg="Failed for non-NumPy input")


def test_add_fourier_features_skips_existing_columns():
    """Test that add_fourier_features skips variables that already have sin/cos columns."""
    dates = pd.date_range("2023-01-01", periods=10, freq="h")
    df = pd.DataFrame({"hour": dates.hour})
    # Add first time normally
    result1 = add_fourier_features(df, calendar_variables=["hour"], periods=[24])
    assert "hour_sin" in result1.columns
    # Call again — should skip the already-present columns
    result2 = add_fourier_features(result1, calendar_variables=["hour"], periods=[24])
    assert result1.equals(result2)
