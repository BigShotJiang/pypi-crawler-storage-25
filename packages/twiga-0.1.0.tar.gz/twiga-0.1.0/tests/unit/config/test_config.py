"""Unit tests for twiga configs package.

Coverage
--------
search_space.py  — BaseSearchSpace validation, Optuna sampling, log-scale detection
base.py          — BaseModelConfig construction, get_optuna_params with/without search space
neural.py        — NeuralModelConfig defaults, field validation, ClassVar dicts,
                   sample_training_params (all 9 optimizer×scheduler combos),
                   from_data_config, subclass override pattern
domain/data.py   — DataPipelineConfig defaults, feature count helpers
domain/forecaster.py — ForecasterConfig defaults and field types
domain/conformal.py  — ConformalConfig validation, method/score_type compatibility,
                        alpha boundary warnings
"""

from __future__ import annotations

import sys
import types
from typing import Any
from unittest.mock import MagicMock, patch

import optuna
import pytest

from twiga.core.config import (
    BaseModelConfig,
    BaseSearchSpace,
    ConformalConfig,
    DataPipelineConfig,
    ForecasterConfig,
    NeuralModelConfig,
)
from twiga.core.config.search_space import make_hashable


def _make_trial(suggestions: dict[str, Any]) -> MagicMock:
    """Return a mock optuna.Trial that returns fixed values for each param name."""
    trial = MagicMock()

    def _suggest(name, *args, **kwargs):
        if name in suggestions:
            return suggestions[name]
        # Return first choice for categoricals, midpoint for floats/ints
        if args:
            if isinstance(args[0], list):
                return args[0][0]
            return args[0]  # low
        return 0

    trial.suggest_categorical.side_effect = lambda name, choices: suggestions.get(name, choices[0])
    trial.suggest_float.side_effect = lambda name, low, high, **kw: suggestions.get(name, low)
    trial.suggest_int.side_effect = lambda name, low, high: suggestions.get(name, low)
    return trial


def _make_data_config(**kwargs) -> DataPipelineConfig:
    defaults = {
        "target_feature": "load",
        "period": "1h",
        "lookback_window_size": 96,
        "forecast_horizon": 48,
    }
    defaults.update(kwargs)
    return DataPipelineConfig(**defaults)


# ===========================================================================
# make_hashable
# ===========================================================================


class TestMakeHashable:
    def test_plain_value_unchanged(self):
        assert make_hashable(42) == 42
        assert make_hashable("relu") == "relu"

    def test_flat_list_becomes_tuple(self):
        assert make_hashable([1, 2, 3]) == (1, 2, 3)

    def test_nested_list_fully_converted(self):
        assert make_hashable([[1, 2], [3, 4]]) == ((1, 2), (3, 4))


# ===========================================================================
# BaseSearchSpace — validation
# ===========================================================================


class TestBaseSearchSpaceValidation:
    def test_valid_categorical(self):
        s = BaseSearchSpace(act=["relu", "tanh"])
        assert s.model_dump()["act"] == ["relu", "tanh"]

    def test_valid_float_range(self):
        s = BaseSearchSpace(lr=(1e-4, 1e-2))
        assert s.model_dump()["lr"] == (1e-4, 1e-2)

    def test_valid_int_range(self):
        s = BaseSearchSpace(depth=(2, 8))
        assert s.model_dump()["depth"] == (2, 8)

    def test_multiple_mixed_fields(self):
        s = BaseSearchSpace(lr=(1e-4, 1e-2), hidden=[64, 128], depth=(2, 6))
        d = s.model_dump()
        assert d["lr"] == (1e-4, 1e-2)
        assert d["hidden"] == [64, 128]
        assert d["depth"] == (2, 6)

    # -- Tuple errors ---------------------------------------------------------

    def test_tuple_wrong_length_raises(self):
        with pytest.raises(Exception, match="2 elements"):
            BaseSearchSpace(lr=(1e-4, 1e-3, 1e-2))

    def test_tuple_low_ge_high_raises(self):
        with pytest.raises(Exception, match="low < high"):
            BaseSearchSpace(lr=(0.1, 0.05))

    def test_tuple_equal_bounds_raises(self):
        with pytest.raises(Exception, match="low < high"):
            BaseSearchSpace(lr=(0.1, 0.1))

    def test_tuple_non_numeric_raises(self):
        with pytest.raises(Exception):  # noqa: B017
            BaseSearchSpace(lr=("a", "b"))

    # -- List errors ----------------------------------------------------------

    def test_empty_list_raises(self):
        with pytest.raises(Exception, match="at least one choice"):
            BaseSearchSpace(act=[])

    def test_duplicate_list_values_raises(self):
        with pytest.raises(Exception, match="duplicate"):
            BaseSearchSpace(act=["relu", "relu"])

    # -- Wrong type -----------------------------------------------------------

    def test_scalar_value_raises(self):
        with pytest.raises(Exception):  # noqa: B017
            BaseSearchSpace(lr=0.001)

    def test_none_value_raises(self):
        with pytest.raises(Exception):  # noqa: B017
            BaseSearchSpace(lr=None)


# ===========================================================================
# BaseSearchSpace — log scale detection
# ===========================================================================


class TestShouldUseLog:
    def test_three_orders_of_magnitude(self):
        assert BaseSearchSpace._should_use_log(1e-4, 1e-1) is True

    def test_exactly_one_order(self):
        # ratio=10, log10(10)=1 — boundary, should be True
        assert BaseSearchSpace._should_use_log(0.01, 0.1) is True

    def test_less_than_one_order(self):
        assert BaseSearchSpace._should_use_log(0.1, 0.5) is False

    def test_zero_low_returns_false(self):
        assert BaseSearchSpace._should_use_log(0.0, 1.0) is False

    def test_negative_low_returns_false(self):
        assert BaseSearchSpace._should_use_log(-1e-4, 1e-2) is False


# ===========================================================================
# BaseSearchSpace — Optuna sampling
# ===========================================================================


class TestBaseSearchSpaceOptunaSampling:
    def test_categorical_calls_suggest_categorical(self):
        space = BaseSearchSpace(act=["relu", "tanh"])
        trial = _make_trial({"act": "tanh"})
        params = space.get_optuna_params(trial)
        assert params["act"] == "tanh"
        trial.suggest_categorical.assert_called_once_with("act", ["relu", "tanh"])

    def test_float_range_calls_suggest_float(self):
        space = BaseSearchSpace(lr=(1e-4, 1e-2))
        trial = _make_trial({"lr": 5e-4})
        params = space.get_optuna_params(trial)
        assert params["lr"] == 5e-4
        trial.suggest_float.assert_called_once_with("lr", 1e-4, 1e-2, log=True)

    def test_int_range_calls_suggest_int(self):
        space = BaseSearchSpace(depth=(2, 8))
        trial = _make_trial({"depth": 4})
        params = space.get_optuna_params(trial)
        assert params["depth"] == 4
        trial.suggest_int.assert_called_once_with("depth", 2, 8)

    def test_prefix_applied_to_trial_name_not_return_key(self):
        space = BaseSearchSpace(lr=(1e-4, 1e-2))
        trial = _make_trial({"mymodel_lr": 1e-3})
        trial.suggest_float.side_effect = lambda name, low, high, **kw: 1e-3 if name == "mymodel_lr" else low
        params = space.get_optuna_params(trial, prefix="mymodel")
        # Return dict key must be unprefixed
        assert "lr" in params
        assert "mymodel_lr" not in params
        trial.suggest_float.assert_called_once_with("mymodel_lr", 1e-4, 1e-2, log=True)

    def test_linear_float_range_log_false(self):
        space = BaseSearchSpace(momentum=(0.9, 0.99))
        trial = _make_trial({"momentum": 0.95})
        space.get_optuna_params(trial)
        trial.suggest_float.assert_called_once_with("momentum", 0.9, 0.99, log=False)

    def test_empty_search_space_returns_empty_dict(self):
        space = BaseSearchSpace()
        trial = _make_trial({})
        assert space.get_optuna_params(trial) == {}


# ===========================================================================
# BaseModelConfig
# ===========================================================================


class TestBaseModelConfig:
    def test_default_construction(self):
        cfg = BaseModelConfig()
        assert cfg.search_space is None

    def test_name_excluded_from_dump(self):
        cfg = BaseModelConfig()
        assert "name" not in cfg.model_dump()

    def test_search_space_excluded_from_dump(self):
        cfg = BaseModelConfig(search_space=BaseSearchSpace(lr=(1e-4, 1e-2)))
        assert "search_space" not in cfg.model_dump()

    def test_get_optuna_params_no_search_space(self):
        cfg = BaseModelConfig()
        trial = _make_trial({})
        params = cfg.get_optuna_params(trial)
        assert "name" not in params
        assert "search_space" not in params

    def test_get_optuna_params_with_search_space_merges(self):
        cfg = BaseModelConfig(search_space=BaseSearchSpace(lr=(1e-4, 1e-2)))
        trial = _make_trial({"base_model_lr": 5e-4})
        trial.suggest_float.side_effect = lambda name, low, high, **kw: 5e-4
        params = cfg.get_optuna_params(trial)
        assert "lr" in params

    def test_search_space_overrides_fixed_field(self):
        """A search_space key that matches a fixed field should win."""
        # We give the config an extra field and also a search_space entry for it
        cfg = BaseModelConfig(
            hidden_size=64,
            search_space=BaseSearchSpace(hidden_size=[64, 128, 256]),
        )
        trial = _make_trial({})
        trial.suggest_categorical.side_effect = lambda name, choices: 128
        params = cfg.get_optuna_params(trial)
        assert params["hidden_size"] == 128


# ===========================================================================
# NeuralModelConfig — construction and defaults
# ===========================================================================


class TestNeuralModelConfigDefaults:
    def test_default_construction(self):
        cfg = NeuralModelConfig()
        assert cfg.batch_size == 64
        assert cfg.max_epochs == 10
        assert cfg.patience == 10
        assert cfg.optimizer_type == "adamw"
        assert cfg.lr_scheduler_type == "multi_step"

        assert cfg.optimizer_params == {"lr": 1e-3, "weight_decay": 1e-6}
        assert cfg.scheduler_params == {
            "milestones": [],
            "prob_decay_1": 0.50,
            "prob_decay_2": 0.90,
            "gamma": 0.1,
        }
        assert cfg.metric == "mae"
        assert cfg.seed == 42

    def test_valid_optimizer_type(self):
        for opt in ("adam", "adamw", "nadam", "radam", "muon", "sgd"):
            cfg = NeuralModelConfig(optimizer_type=opt)
            assert cfg.optimizer_type == opt

    def test_invalid_optimizer_type_raises(self):
        with pytest.raises(Exception):  # noqa: B017
            NeuralModelConfig(optimizer_type="lbfgs")

    def test_valid_scheduler_type(self):
        for sched in ("multi_step", "warmup_cosine", "reduce_on_plateau", "cosine_annealing"):
            cfg = NeuralModelConfig(lr_scheduler_type=sched)
            assert cfg.lr_scheduler_type == sched

    def test_invalid_scheduler_type_raises(self):
        with pytest.raises(Exception):  # noqa: B017
            NeuralModelConfig(lr_scheduler_type="unknown_scheduler")

    def test_valid_metrics(self):
        for m in ("mae", "mse", "smape"):
            cfg = NeuralModelConfig(metric=m)
            assert cfg.metric == m

    def test_invalid_metric_raises(self):
        with pytest.raises(Exception):  # noqa: B017
            NeuralModelConfig(metric="rmse")

    def test_seed_must_be_positive(self):
        with pytest.raises(Exception):  # noqa: B017
            NeuralModelConfig(seed=0)
        with pytest.raises(Exception):  # noqa: B017
            NeuralModelConfig(seed=-1)

    def test_optimizer_params_partial_override(self):
        cfg = NeuralModelConfig(optimizer_params={"lr": 2e-4})
        assert cfg.optimizer_params == {"lr": 2e-4}

    def test_scheduler_params_partial_override(self):
        cfg = NeuralModelConfig(scheduler_params={"gamma": 0.05})
        assert cfg.scheduler_params == {"gamma": 0.05}


# ===========================================================================
# NeuralModelConfig — ClassVar search space dicts
# ===========================================================================


class TestNeuralModelConfigClassVars:
    def test_base_training_search_space_keys(self):
        # Access via model_dump() because it's no longer a raw dict
        search_dict = NeuralModelConfig.BASE_TRAINING_SEARCH_SPACE.model_dump()
        assert "optimizer_type" in search_dict
        assert "batch_size" in search_dict

    def test_optimizer_param_search_covers_all_base_optimizers(self):
        base_opts = NeuralModelConfig.BASE_TRAINING_SEARCH_SPACE.model_dump()["optimizer_type"]
        for opt in base_opts:
            assert opt in NeuralModelConfig.OPTIMIZER_PARAM_SEARCH
            assert isinstance(NeuralModelConfig.OPTIMIZER_PARAM_SEARCH[opt], BaseSearchSpace)

    def test_optimizer_param_ranges_are_tuples_or_lists(self):
        for _opt, space_obj in NeuralModelConfig.OPTIMIZER_PARAM_SEARCH.items():
            # space_obj is a BaseSearchSpace, so we dump it to iterate
            for _key, rng in space_obj.model_dump().items():
                assert isinstance(rng, (tuple, list))


# ===========================================================================
# NeuralModelConfig — sample_training_params
# ===========================================================================


class TestSampleTrainingParams:
    """Each optimizer × scheduler combination should produce correct keys."""

    def _run(self, optimizer_type: str, scheduler_type: str) -> dict:
        # We need to simulate the suggestions that optuna would provide
        suggestions = {
            "optimizer_type": optimizer_type,
            "lr_scheduler_type": scheduler_type,
            "batch_size": 64,
        }

        # FIX: Access param search objects via .model_dump()
        opt_space = NeuralModelConfig.OPTIMIZER_PARAM_SEARCH.get(optimizer_type)
        if opt_space:
            for key, rng in opt_space.model_dump().items():
                # optuna names are prefixed with 'opt_' in the actual implementation
                suggestions[f"opt_{key}"] = rng[0] if isinstance(rng, (list, tuple)) else rng

        sch_space = NeuralModelConfig.SCHEDULER_PARAM_SEARCH.get(scheduler_type)
        if sch_space:
            for key, rng in sch_space.model_dump().items():
                # optuna names are prefixed with 'sch_' in the actual implementation
                suggestions[f"sch_{key}"] = rng[0] if isinstance(rng, (list, tuple)) else rng

        # Use your existing _make_trial helper
        trial = _make_trial(suggestions)
        return NeuralModelConfig.sample_training_params(trial)

    def test_return_keys_always_present(self):
        result = self._run("adamw", "multi_step")
        # Ensure top level keys are present
        assert "optimizer_type" in result
        assert "lr_scheduler_type" in result
        assert "batch_size" in result
        assert "optimizer_params" in result
        assert "scheduler_params" in result

    def test_muon_warmup_cosine(self):
        result = self._run("muon", "warmup_cosine")
        assert result["optimizer_type"] == "muon"
        # optimizer_params should be a flat dict of the sampled values
        assert "lr" in result["optimizer_params"]
        assert "momentum" in result["optimizer_params"]
        assert "ns_steps" in result["optimizer_params"]

    def test_adam_multi_step(self):
        result = self._run("adam", "multi_step")
        assert "lr" in result["optimizer_params"]
        assert "weight_decay" in result["optimizer_params"]

    def test_adamw_reduce_on_plateau(self):
        result = self._run("adamw", "reduce_on_plateau")
        assert "factor" in result["scheduler_params"]
        assert "prob_patience" in result["scheduler_params"]

    def test_muon_multi_step(self):
        result = self._run("muon", "multi_step")
        assert "prob_decay_1" in result["scheduler_params"]
        assert "prob_decay_2" in result["scheduler_params"]

    def test_batch_size_is_in_valid_choices(self):
        result = self._run("adamw", "warmup_cosine")
        # FIX: Use model_dump() to check against the allowed list
        valid_batches = NeuralModelConfig.BASE_TRAINING_SEARCH_SPACE.model_dump()["batch_size"]
        assert result["batch_size"] in valid_batches

    def test_patience_not_in_returned_dict(self):
        result = self._run("adamw", "multi_step")
        assert "patience" not in result

    def test_subclass_inherits_and_samples(self):
        """Verify get_optuna_params properly merges architecture and training params."""

        class MockSubConfig(NeuralModelConfig):
            # Architecture search space
            search_space: BaseSearchSpace = BaseSearchSpace(hidden_dim=[128, 256])

        # search_space.get_optuna_params uses prefix=self.name which is "neural_model"
        # so the trial key for hidden_dim is "neural_model_hidden_dim"
        trial_suggestions = {
            "neural_model_hidden_dim": 256,
            "optimizer_type": "adamw",
            "lr_scheduler_type": "multi_step",
            "batch_size": 64,
            "opt_lr": 1e-3,
            "opt_weight_decay": 1e-6,
            "sch_gamma": 0.1,
        }

        trial = _make_trial(trial_suggestions)
        cfg = MockSubConfig(num_target_feature=1, forecast_horizon=24, lookback_window_size=168)
        params = cfg.get_optuna_params(trial)

        assert params["hidden_dim"] == 256
        assert params["optimizer_type"] == "adamw"


# ===========================================================================
# NeuralModelConfig — from_data_config
# ===========================================================================


class TestFromDataConfig:
    def test_str_target_gives_num_target_1(self):
        dc = _make_data_config(target_feature="load")
        cfg = NeuralModelConfig.from_data_config(dc)
        assert cfg.model_dump(exclude={"name", "search_space"})["num_target_feature"] == 1

    def test_list_target_counts_correctly(self):
        dc = _make_data_config(target_feature=["load", "temperature", "price"])
        cfg = NeuralModelConfig.from_data_config(dc)
        assert cfg.model_dump(exclude={"name", "search_space"})["num_target_feature"] == 3

    def test_feature_counts_from_data_config(self):
        dc = _make_data_config(
            historical_features=["h1", "h2"],
            calendar_features=["hour", "dow"],
            exogenous_features=["temp"],
            future_covariates=["price", "solar"],
        )
        cfg = NeuralModelConfig.from_data_config(dc)
        d = cfg.model_dump()
        assert d["num_historical_features"] == 2
        assert d["num_calendar_features"] == 2
        assert d["num_exogenous_features"] == 1
        assert d["num_future_covariates"] == 2

    def test_none_feature_groups_give_zero(self):
        dc = _make_data_config()  # all feature groups default to None
        cfg = NeuralModelConfig.from_data_config(dc)
        d = cfg.model_dump()
        assert d["num_historical_features"] == 0
        assert d["num_calendar_features"] == 0
        assert d["num_exogenous_features"] == 0
        assert d["num_future_covariates"] == 0

    def test_forecast_horizon_and_lookback_propagated(self):
        dc = _make_data_config(forecast_horizon=24, lookback_window_size=168)
        cfg = NeuralModelConfig.from_data_config(dc)
        d = cfg.model_dump()
        assert d["forecast_horizon"] == 24
        assert d["lookback_window_size"] == 168

    def test_kwargs_override_derived_values(self):
        dc = _make_data_config()
        cfg = NeuralModelConfig.from_data_config(dc, max_epochs=50, batch_size=32)
        assert cfg.max_epochs == 50
        assert cfg.batch_size == 32

    def test_invalid_target_type_raises(self):
        dc = _make_data_config()
        dc.target_feature = 42  # type: ignore[assignment]
        with pytest.raises(TypeError, match="str or list"):
            NeuralModelConfig.from_data_config(dc)

    def test_missing_forecast_horizon_raises(self):
        dc = _make_data_config()
        del dc.__dict__["forecast_horizon"]

        # Pydantic still has it — simulate by using a plain object
        class BadConfig:
            target_feature = "load"
            lookback_window_size = 96
            historical_features = None
            calendar_features = None
            exogenous_features = None
            future_covariates = None

        with pytest.raises(AttributeError, match="forecast_horizon"):
            NeuralModelConfig.from_data_config(BadConfig())


# ===========================================================================
# DataPipelineConfig
# ===========================================================================


class TestDataPipelineConfig:
    def test_minimal_required_fields(self):
        cfg = _make_data_config()
        assert cfg.target_feature == "load"
        assert cfg.forecast_horizon == 48
        assert cfg.lookback_window_size == 96

    def test_defaults(self):
        cfg = _make_data_config()
        assert cfg.date_column == "timestamp"
        assert cfg.stride == 1
        assert cfg.latitude is None
        assert cfg.longitude is None
        assert cfg.historical_features is None
        assert cfg.lags is None
        assert cfg.windows is None
        assert cfg.window_funcs is None

    def test_list_target_feature(self):
        cfg = _make_data_config(target_feature=["load", "price"])
        assert cfg.target_feature == ["load", "price"]

    def test_optional_features_set(self):
        cfg = _make_data_config(
            historical_features=["a", "b"],
            calendar_features=["hour"],
            exogenous_features=["temp"],
            future_covariates=["solar"],
        )
        assert len(cfg.historical_features) == 2
        assert len(cfg.calendar_features) == 1
        assert len(cfg.exogenous_features) == 1
        assert len(cfg.future_covariates) == 1

    def test_lags_and_windows(self):
        cfg = _make_data_config(lags=[1, 2, 24], windows=[6, 12], window_funcs=["mean", "std"])
        assert cfg.lags == [1, 2, 24]
        assert cfg.windows == [6, 12]
        assert cfg.window_funcs == ["mean", "std"]

    def test_scalar_windows_accepted(self):
        cfg = _make_data_config(windows=24)
        assert cfg.windows == 24

    def test_geo_coords(self):
        cfg = _make_data_config(latitude=52.5, longitude=-8.2)
        assert cfg.latitude == pytest.approx(52.5)
        assert cfg.longitude == pytest.approx(-8.2)


# ===========================================================================
# ForecasterConfig
# ===========================================================================


class TestForecasterConfig:
    def test_default_construction(self):
        cfg = ForecasterConfig()
        assert cfg.split_freq == "months"
        assert cfg.test_size == 1
        assert cfg.train_size == 1
        assert cfg.gap == 0
        assert cfg.stride is None
        assert cfg.window == "expanding"
        assert cfg.num_splits is None
        assert cfg.project_name == "experiment"
        assert cfg.file_name is None
        assert cfg.seed == 42
        assert cfg.date_column == "timestamp"
        assert cfg.root_dir == "../"
        assert cfg.metrics is None

    def test_valid_split_freqs(self):
        for freq in ("days", "minutes", "hours", "weeks", "months", "years"):
            cfg = ForecasterConfig(split_freq=freq)
            assert cfg.split_freq == freq

    def test_invalid_split_freq_raises(self):
        with pytest.raises(Exception):  # noqa: B017
            ForecasterConfig(split_freq="quarters")

    def test_window_options(self):
        for w in ("expanding", "rolling"):
            cfg = ForecasterConfig(window=w)
            assert cfg.window == w

    def test_invalid_window_raises(self):
        with pytest.raises(Exception):  # noqa: B017
            ForecasterConfig(window="sliding")

    def test_domain_excluded_from_dump(self):
        cfg = ForecasterConfig()
        assert "domain" not in cfg.model_dump()

    def test_metrics_as_list(self):
        cfg = ForecasterConfig(metrics=["mae", "rmse"])
        assert cfg.metrics == ["mae", "rmse"]

    def test_metrics_as_tuple(self):
        cfg = ForecasterConfig(metrics=("mae",))
        assert "mae" in cfg.metrics

    def test_override_fields(self):
        cfg = ForecasterConfig(test_size=3, train_size=12, gap=1, num_splits=5)
        assert cfg.test_size == 3
        assert cfg.train_size == 12
        assert cfg.gap == 1
        assert cfg.num_splits == 5


# ===========================================================================
# ConformalConfig
# ===========================================================================


class TestConformalConfigDefaults:
    def test_default_construction(self):
        cfg = ConformalConfig()
        assert cfg.method == "residual"
        assert cfg.score_type == "res"
        assert cfg.alpha == pytest.approx(0.1)

    def test_no_extra_fields_allowed(self):
        with pytest.raises(Exception):  # noqa: B017
            ConformalConfig(unknown_field=True)


class TestConformalConfigMethodScoreCompatibility:
    # -- Valid combinations ---------------------------------------------------
    def test_residual_res(self):
        cfg = ConformalConfig(method="residual", score_type="res")
        assert cfg.method == "residual"

    def test_residual_sign_res(self):
        cfg = ConformalConfig(method="residual", score_type="sign-res")
        assert cfg.score_type == "sign-res"

    def test_residual_fitting_res(self):
        cfg = ConformalConfig(method="residual-fitting", score_type="res")
        assert cfg.method == "residual-fitting"

    def test_residual_fitting_sign_res(self):
        cfg = ConformalConfig(method="residual-fitting", score_type="sign-res")
        assert cfg.score_type == "sign-res"

    def test_quantile_scaled(self):
        cfg = ConformalConfig(method="quantile", score_type="scaled")
        assert cfg.method == "quantile"

    def test_quantile_unscaled(self):
        cfg = ConformalConfig(method="quantile", score_type="unscaled")
        assert cfg.score_type == "unscaled"

    # -- Invalid combinations -------------------------------------------------
    def test_quantile_with_res_raises(self):
        with pytest.raises(ValueError, match="quantile"):
            ConformalConfig(method="quantile", score_type="res")

    def test_quantile_with_sign_res_raises(self):
        with pytest.raises(ValueError, match="quantile"):
            ConformalConfig(method="quantile", score_type="sign-res")

    def test_residual_with_scaled_raises(self):
        with pytest.raises(ValueError, match="residual"):
            ConformalConfig(method="residual", score_type="scaled")

    def test_residual_fitting_with_unscaled_raises(self):
        with pytest.raises(ValueError, match="residual-fitting"):
            ConformalConfig(method="residual-fitting", score_type="unscaled")


class TestConformalConfigAlpha:
    def test_alpha_bounds(self):
        cfg = ConformalConfig(alpha=0.05)
        assert cfg.alpha == pytest.approx(0.05)

    def test_alpha_zero_raises(self):
        with pytest.raises(Exception):  # noqa: B017
            ConformalConfig(alpha=0.0)

    def test_alpha_one_raises(self):
        with pytest.raises(Exception):  # noqa: B017
            ConformalConfig(alpha=1.0)

    def test_alpha_below_zero_raises(self):
        with pytest.raises(Exception):  # noqa: B017
            ConformalConfig(alpha=-0.1)

    def test_alpha_above_one_raises(self):
        with pytest.raises(Exception):  # noqa: B017
            ConformalConfig(alpha=1.5)

    def test_extreme_low_alpha_prints_warning(self):
        import warnings

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            ConformalConfig(alpha=0.005)
        assert any("excessively wide" in str(warning.message) for warning in w)

    def test_extreme_high_alpha_prints_warning(self):
        import warnings

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            ConformalConfig(alpha=0.6)
        assert any("excessively narrow" in str(warning.message) for warning in w)

    def test_normal_alpha_no_warning(self):
        import warnings

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            ConformalConfig(alpha=0.1)
        assert not any(issubclass(warning.category, UserWarning) for warning in w)
