import pytest
import torch
import torch.nn as nn
import torch.nn.functional as F

from twiga.distributions.nn.custom_loss import QuantileHuberLoss, QuantileLoss, QuantileProposalLoss
from twiga.distributions.nn.fpquantile import (  # Replace with actual module name
    CosinetauEmbedding,
    FPQRDistribution,
    QuantileProposal,
)
from twiga.models.nn.core.embedding import DataEmbedding, TimeEmbedding


# Fixtures for common test data
@pytest.fixture
def batch_size():
    return 2


@pytest.fixture
def z_dim():
    return 64


@pytest.fixture
def horizon():
    return 4


@pytest.fixture
def num_outputs():
    return 1


@pytest.fixture
def n_quantiles():
    return 3


@pytest.fixture
def input_tensor(batch_size, z_dim):
    return torch.rand(batch_size, z_dim)


@pytest.fixture
def target_tensor(batch_size, horizon, num_outputs):
    return torch.rand(batch_size, horizon, num_outputs)


@pytest.fixture
def taus(batch_size, horizon, num_outputs):
    return torch.rand(batch_size, horizon, num_outputs)


# Tests for CosinetauEmbedding
def test_cosinetau_embedding_forward(taus, batch_size, horizon, num_outputs):
    embedding = CosinetauEmbedding(num_cosines=4, z_dim=16, num_outputs=num_outputs)
    output = embedding(taus)
    assert output.shape == (batch_size, horizon, 16)
    assert output.dtype == taus.dtype
    assert output.device == taus.device


# Tests for QuantileProposal
def test_quantile_proposal_init():
    model = QuantileProposal(n_quantiles=5, z_dim=32, dropout=0.2, conf_level=0.1, n_outputs=4)
    assert model.n_quantiles == 5
    assert model.z_dim == 32
    assert model.dropout.p == 0.2
    assert model.conf_level.item() == pytest.approx(0.1)
    assert model.n_outputs == 4
    assert isinstance(model.net, nn.Linear)


def test_quantile_proposal_invalid_inputs():
    with pytest.raises(ValueError, match="n_quantiles must be positive"):
        QuantileProposal(n_quantiles=0)
    with pytest.raises(ValueError, match="z_dim must be positive"):
        QuantileProposal(z_dim=0)
    with pytest.raises(ValueError, match="dropout must be non-negative"):
        QuantileProposal(dropout=-0.1)
    with pytest.raises(ValueError, match="conf_level must be between 0 and 1"):
        QuantileProposal(conf_level=1.5)
    with pytest.raises(ValueError, match="n_outputs must be positive"):
        QuantileProposal(n_outputs=0)


def test_quantile_proposal_forward(input_tensor, batch_size, n_quantiles, num_outputs):
    model = QuantileProposal(n_quantiles=n_quantiles, z_dim=64, n_outputs=num_outputs)
    taus, tau_hats, entropies = model(input_tensor)

    assert taus.shape == (batch_size, n_quantiles + 1, num_outputs)
    assert tau_hats.shape == (batch_size, n_quantiles, num_outputs)
    assert entropies.shape == (batch_size, num_outputs)
    assert torch.all(tau_hats >= model.conf_level.item() / 2.0)
    assert torch.all(tau_hats <= 1 - model.conf_level.item() / 2.0)


def test_quantile_proposal_invalid_input_shape(batch_size):
    model = QuantileProposal(z_dim=64)
    invalid_input = torch.rand(batch_size, 32)  # Wrong z_dim
    with pytest.raises(ValueError, match="Expected z shape"):
        model(invalid_input)


# Tests for FPQRDistribution
@pytest.fixture
def fpqr_distribution(n_quantiles, num_outputs, horizon, z_dim):
    return FPQRDistribution(
        n_quantiles=n_quantiles,
        num_outputs=num_outputs,
        hidden_size=z_dim,
        horizon=horizon,
        dropout=0.1,
        conf_level=0.05,
        num_cosines=4,
        loss_fn="pinball",
    )


def test_fpqr_distribution_init(n_quantiles, num_outputs, horizon, z_dim):
    model = FPQRDistribution(
        n_quantiles=n_quantiles,
        num_outputs=num_outputs,
        hidden_size=z_dim,
        horizon=horizon,
        dropout=0.1,
        conf_level=0.05,
        num_cosines=4,
        loss_fn="huber-pinball",
    )
    assert model.n_quantiles == n_quantiles
    assert model.num_outputs == num_outputs
    assert model.horizon == horizon
    assert isinstance(model.quantile_proposal, QuantileProposal)
    assert isinstance(model.quantile_cosine, CosinetauEmbedding)
    assert isinstance(model.quantile_loss, QuantileHuberLoss)


def test_fpqr_distribution_invalid_inputs():
    with pytest.raises(ValueError, match="n_quantiles must be positive"):
        FPQRDistribution(n_quantiles=0)
    with pytest.raises(ValueError, match="num_outputs must be positive"):
        FPQRDistribution(num_outputs=0)
    with pytest.raises(ValueError, match="hidden_size must be positive"):
        FPQRDistribution(hidden_size=0)
    with pytest.raises(ValueError, match="horizon must be positive"):
        FPQRDistribution(horizon=0)
    with pytest.raises(ValueError, match="dropout must be between 0 and 1"):
        FPQRDistribution(dropout=-0.1)
    with pytest.raises(ValueError, match="conf_level must be between 0 and 1"):
        FPQRDistribution(conf_level=1.5)
    with pytest.raises(ValueError, match="Unknown loss function"):
        FPQRDistribution(loss_fn="invalid")


def test_fpqr_distribution_forward(fpqr_distribution, input_tensor, batch_size, n_quantiles, horizon, num_outputs):
    quantiles, taus, tau_hats, entropies = fpqr_distribution(input_tensor)

    assert quantiles.shape == (batch_size, n_quantiles, horizon, num_outputs)
    assert taus.shape == (batch_size, n_quantiles + 1, horizon)
    assert tau_hats.shape == (batch_size, n_quantiles, horizon)
    assert entropies.shape == (batch_size, horizon)


def test_fpqr_distribution_forecast(fpqr_distribution, input_tensor, batch_size, n_quantiles, horizon, num_outputs):
    output = fpqr_distribution.forecast(input_tensor)
    loc = output["loc"]
    quantiles = output["quantiles"]
    tau_hats = output["quantile_levels"]

    assert loc.shape == (batch_size, horizon, num_outputs)
    assert quantiles.shape == (batch_size, n_quantiles, horizon, num_outputs)
    assert tau_hats.shape == (batch_size, n_quantiles, horizon)


def test_fpqr_distribution_step(fpqr_distribution, input_tensor, target_tensor, batch_size):
    def metric_fn(y_pred, y_true):
        return torch.mean((y_pred - y_true) ** 2)

    loss, metric = fpqr_distribution.step(input_tensor, target_tensor, metric_fn)

    assert isinstance(loss, torch.Tensor)
    assert loss.dim() == 0  # Scalar loss
    assert isinstance(metric, torch.Tensor)
    assert metric.dim() == 0  # Scalar metric


@pytest.mark.parametrize("loss_fn", ["pinball", "huber-pinball"])
def test_fpqr_distribution_loss_functions(loss_fn, input_tensor, target_tensor, z_dim, horizon, num_outputs):
    model = FPQRDistribution(
        n_quantiles=3, num_outputs=num_outputs, hidden_size=z_dim, horizon=horizon, loss_fn=loss_fn
    )

    def metric_fn(y_pred, y_true):
        return torch.mean((y_pred - y_true) ** 2)

    loss, metric = model.step(input_tensor, target_tensor, metric_fn)

    assert isinstance(loss, torch.Tensor)
    assert isinstance(metric, torch.Tensor)


def test_fpqr_distribution_no_cosines(n_quantiles, num_outputs, horizon, z_dim):
    model = FPQRDistribution(
        n_quantiles=n_quantiles, num_outputs=num_outputs, hidden_size=z_dim, horizon=horizon, num_cosines=0
    )
    assert isinstance(model.quantile_cosine, DataEmbedding)
