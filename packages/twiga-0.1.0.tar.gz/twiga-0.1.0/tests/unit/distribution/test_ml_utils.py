"""Tests for twiga.distributions.ml.utils.

Covers:
- interpolate_quantile: exact match, linear interpolation, out-of-range,
  empty quantiles, unsorted quantiles, shape mismatch
- get_median_prediction: exact 0.5 match, interpolated median
- get_sigma_prediction: IQR-based sigma computation
"""

from __future__ import annotations

import numpy as np
import pytest

from twiga.distributions.ml.utils import (
    get_median_prediction,
    get_sigma_prediction,
    interpolate_quantile,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def rng() -> np.random.Generator:
    """Return a seeded random number generator for reproducibility."""
    return np.random.default_rng(42)


@pytest.fixture
def predictions(rng: np.random.Generator) -> np.ndarray:
    """Create a (B=2, Q=5, C=3) predictions array.

    Quantile levels: [0.1, 0.25, 0.5, 0.75, 0.9]
    """
    return rng.standard_normal((2, 5, 3)).astype(np.float64)


@pytest.fixture
def quantile_levels() -> list[float]:
    """Sorted quantile levels matching the fixture predictions."""
    return [0.1, 0.25, 0.5, 0.75, 0.9]


# ---------------------------------------------------------------------------
# interpolate_quantile
# ---------------------------------------------------------------------------


class TestInterpolateQuantile:
    """Tests for interpolate_quantile."""

    def test_exact_match_returns_slice(self, predictions: np.ndarray, quantile_levels: list[float]) -> None:
        """When target_quantile is in sorted_quantiles, the slice is returned directly."""
        result = interpolate_quantile(predictions, quantile_levels, target_quantile=0.5)
        expected = predictions[:, 2, :]
        np.testing.assert_array_equal(result, expected)

    def test_exact_match_first_quantile(self, predictions: np.ndarray, quantile_levels: list[float]) -> None:
        """Exact match at the first quantile level."""
        result = interpolate_quantile(predictions, quantile_levels, target_quantile=0.1)
        np.testing.assert_array_equal(result, predictions[:, 0, :])

    def test_exact_match_last_quantile(self, predictions: np.ndarray, quantile_levels: list[float]) -> None:
        """Exact match at the last quantile level."""
        result = interpolate_quantile(predictions, quantile_levels, target_quantile=0.9)
        np.testing.assert_array_equal(result, predictions[:, 4, :])

    def test_interpolation_midpoint(self) -> None:
        """Linear interpolation between two adjacent quantile levels."""
        # Simple 1-batch, 2-quantile, 1-channel array
        preds = np.array([[[0.0], [1.0]]], dtype=np.float64)  # (1, 2, 1)
        quantiles = [0.0, 1.0]
        result = interpolate_quantile(preds, quantiles, target_quantile=0.5)
        # weight = (0.5 - 0.0) / (1.0 - 0.0) = 0.5 → 0.0 + 0.5 * 1.0 = 0.5
        np.testing.assert_allclose(result, np.array([[0.5]]))

    def test_interpolation_quarter(self) -> None:
        """Linear interpolation at one quarter of the range."""
        preds = np.array([[[0.0], [4.0]]], dtype=np.float64)  # (1, 2, 1)
        quantiles = [0.0, 1.0]
        result = interpolate_quantile(preds, quantiles, target_quantile=0.25)
        np.testing.assert_allclose(result, np.array([[1.0]]))

    def test_empty_quantiles_raises(self, predictions: np.ndarray) -> None:
        """Empty sorted_quantiles raises ValueError."""
        with pytest.raises(ValueError, match="cannot be empty"):
            interpolate_quantile(predictions, [], target_quantile=0.5)

    def test_shape_mismatch_raises(self) -> None:
        """Mismatch between Q dimension and len(sorted_quantiles) raises ValueError."""
        preds = np.ones((2, 3, 1), dtype=np.float64)
        with pytest.raises(ValueError, match="Number of quantiles"):
            interpolate_quantile(preds, [0.1, 0.5], target_quantile=0.3)

    def test_unsorted_quantiles_raises(self) -> None:
        """Unsorted quantiles raises ValueError."""
        preds = np.ones((2, 2, 1), dtype=np.float64)
        with pytest.raises(ValueError, match="sorted in ascending order"):
            interpolate_quantile(preds, [0.9, 0.1], target_quantile=0.5)

    def test_target_below_range_raises(self, predictions: np.ndarray, quantile_levels: list[float]) -> None:
        """target_quantile below the minimum quantile level raises ValueError."""
        with pytest.raises(ValueError, match="outside the range"):
            interpolate_quantile(predictions, quantile_levels, target_quantile=0.01)

    def test_target_above_range_raises(self, predictions: np.ndarray, quantile_levels: list[float]) -> None:
        """target_quantile above the maximum quantile level raises ValueError."""
        with pytest.raises(ValueError, match="outside the range"):
            interpolate_quantile(predictions, quantile_levels, target_quantile=0.99)

    def test_output_shape(self, predictions: np.ndarray, quantile_levels: list[float]) -> None:
        """Result shape is (B, C) — quantile dimension collapsed."""
        result = interpolate_quantile(predictions, quantile_levels, target_quantile=0.3)
        assert result.shape == (2, 3)

    def test_multi_batch_interpolation(self) -> None:
        """Interpolation is consistent across batch dimension."""
        preds = np.array([[[0.0], [2.0]], [[4.0], [6.0]]], dtype=np.float64)  # (2, 2, 1)
        quantiles = [0.0, 1.0]
        result = interpolate_quantile(preds, quantiles, target_quantile=0.5)
        np.testing.assert_allclose(result, np.array([[1.0], [5.0]]))


# ---------------------------------------------------------------------------
# get_median_prediction
# ---------------------------------------------------------------------------


class TestGetMedianPrediction:
    """Tests for get_median_prediction."""

    def test_median_with_exact_0_5(self, predictions: np.ndarray, quantile_levels: list[float]) -> None:
        """Returns the 0.5 slice when 0.5 is in quantiles."""
        result = get_median_prediction(predictions, quantile_levels)
        np.testing.assert_array_equal(result, predictions[:, 2, :])

    def test_median_output_shape(self, predictions: np.ndarray, quantile_levels: list[float]) -> None:
        """Output shape is (B, C)."""
        result = get_median_prediction(predictions, quantile_levels)
        assert result.shape == (2, 3)

    def test_median_unsorted_same_as_sorted(self, predictions: np.ndarray, quantile_levels: list[float]) -> None:
        """Passing unsorted quantiles yields the same result as sorted, since sorting is internal."""
        import random

        shuffled = quantile_levels[:]
        random.seed(0)
        random.shuffle(shuffled)
        # Both calls should reach the same 0.5 slice (index 2 in sorted order)
        result_sorted = get_median_prediction(predictions, quantile_levels)
        result_shuffled = get_median_prediction(predictions, shuffled)
        np.testing.assert_array_equal(result_sorted, result_shuffled)

    def test_median_interpolated(self) -> None:
        """Median is interpolated when 0.5 is not in quantiles."""
        preds = np.array([[[0.0], [2.0]]], dtype=np.float64)  # (1, 2, 1)
        quantiles = [0.25, 0.75]
        result = get_median_prediction(preds, quantiles)
        np.testing.assert_allclose(result, np.array([[1.0]]))


# ---------------------------------------------------------------------------
# get_sigma_prediction
# ---------------------------------------------------------------------------


class TestGetSigmaPrediction:
    """Tests for get_sigma_prediction."""

    def test_sigma_output_shape(self, predictions: np.ndarray, quantile_levels: list[float]) -> None:
        """Output shape is (B, C)."""
        result = get_sigma_prediction(predictions, quantile_levels)
        assert result.shape == (2, 3)

    def test_sigma_is_finite(self, predictions: np.ndarray, quantile_levels: list[float]) -> None:
        """Sigma values are finite (no inf / nan)."""
        result = get_sigma_prediction(predictions, quantile_levels)
        assert np.all(np.isfinite(result))

    def test_sigma_formula(self) -> None:
        """Sigma = (Q75 - Q25) / (2 * 0.6745)."""
        # Construct simple case: Q25 = 1.0, Q75 = 3.0 for batch 0, channel 0
        preds = np.array([[[1.0, 0.0], [2.0, 0.0], [3.0, 0.0]]], dtype=np.float64)  # (1, 3, 2)
        quantiles = [0.25, 0.5, 0.75]
        result = get_sigma_prediction(preds, quantiles)
        # (3.0 - 1.0) / (2 * 0.6745)
        expected_sigma_0 = (3.0 - 1.0) / (2 * 0.6745)
        np.testing.assert_allclose(result[0, 0], expected_sigma_0, rtol=1e-5)

    def test_sigma_raises_for_missing_iqr_quantiles(self) -> None:
        """Raises ValueError when 0.25 or 0.75 cannot be interpolated."""
        # Use a range that does not bracket 0.25.
        preds2 = np.ones((2, 2, 1), dtype=np.float64)
        quantiles2 = [0.3, 0.8]  # 0.25 is outside → should raise
        with pytest.raises(ValueError):
            get_sigma_prediction(preds2, quantiles2)
