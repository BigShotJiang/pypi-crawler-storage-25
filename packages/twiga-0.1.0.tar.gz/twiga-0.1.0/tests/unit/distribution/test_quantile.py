import numpy as np
import pytest
import torch
import torch.nn as nn

from twiga.distributions.nn.custom_loss import QuantileHuberLoss, QuantileLoss
from twiga.distributions.nn.quantile import QRDistribution, get_median_quantile  # Replace with actual module name


# Fixtures for common test data
@pytest.fixture
def quantile_hats():
    # Shape: (B=2, N=3, T=4, C=1)
    return torch.rand(2, 3, 4, 1)


@pytest.fixture
def probs():
    return [0.1, 0.3, 0.7, 0.9]


@pytest.fixture
def quantile_hats_with_median():
    # Shape: (B=2, N=5, T=4, C=1) with probs including 0.5
    return torch.rand(2, 5, 4, 1)


@pytest.fixture
def probs_with_median():
    return [0.1, 0.3, 0.5, 0.7, 0.9]


# Tests for get_median_quantile
def test_get_median_quantile_invalid_dims(quantile_hats):
    # Test invalid tensor dimensions
    invalid_hats = quantile_hats.squeeze(-1)  # Shape: (2, 3, 4)
    with pytest.raises(ValueError, match="Expected 4D tensor"):
        get_median_quantile(invalid_hats, [0.5])


def test_get_median_quantile_invalid_num_quantiles():
    # Test empty quantiles
    empty_hats = torch.rand(2, 0, 4, 1)
    with pytest.raises(ValueError, match="Number of quantiles 0 must be at least 1"):
        get_median_quantile(empty_hats, [])


def test_get_median_quantile_invalid_probs_shape(quantile_hats, probs):
    # Test mismatched probs length
    invalid_probs = probs[:2]  # Length 2, but quantile_hats has 3 quantiles
    with pytest.raises(ValueError, match="probs must have length 3"):
        get_median_quantile(quantile_hats, invalid_probs)


def test_get_median_quantile_direct_median(quantile_hats_with_median, probs_with_median):
    # Test when 0.5 quantile is directly available
    quantile_hats = quantile_hats_with_median
    probs = probs_with_median
    median = get_median_quantile(quantile_hats, probs)

    # Median should be the quantile at prob=0.5 (index 2)
    expected = quantile_hats[:, 2, :, :].contiguous()
    assert torch.equal(median, expected)
    assert median.shape == (2, 4, 1)


def test_get_median_quantile_interpolation():
    # Test interpolation between quantiles — use self-consistent local data
    probs = torch.tensor([0.1, 0.3, 0.7, 0.9])
    quantile_hats = torch.rand(2, 4, 4, 1)  # 4 quantiles to match probs

    # Sort probs and quantiles
    sorted_indices = torch.argsort(probs)
    probs = probs[sorted_indices]
    quantile_hats = quantile_hats[:, sorted_indices, :, :]

    # Interpolation between probs[1]=0.3 and probs[2]=0.7 for 0.5
    median = get_median_quantile(quantile_hats, probs)

    p_lower, p_upper = probs[1], probs[2]  # 0.3, 0.7
    q_lower, q_upper = quantile_hats[:, 1, :, :], quantile_hats[:, 2, :, :]
    weight = (0.5 - p_lower) / (p_upper - p_lower)  # (0.5 - 0.3) / (0.7 - 0.3) = 0.5
    expected = q_lower + (q_upper - q_lower) * weight

    assert torch.allclose(median, expected)
    assert median.shape == (2, 4, 1)


def test_get_median_quantile_no_interpolation_possible(quantile_hats):
    # Test when 0.5 is outside quantile range
    probs = [0.6, 0.7, 0.8]  # All > 0.5, matches 3 quantiles
    with pytest.raises(ValueError, match="Cannot interpolate: 0.5 is outside the range of provided quantiles"):
        get_median_quantile(quantile_hats, probs)


@pytest.fixture
def qr_distribution():
    return QRDistribution(
        quantiles=[0.1, 0.3, 0.5, 0.7, 0.9],
        num_outputs=1,
        hidden_size=16,
        horizon=4,
        loss_fn="pinball",
        conf_level=0.05,
    )


def test_qr_distribution_init():
    # Test initialization with valid parameters
    model = QRDistribution(
        quantiles=[0.1, 0.5, 0.9], num_outputs=2, hidden_size=32, horizon=8, loss_fn="huber-pinball", conf_level=0.1
    )
    assert model.taus.shape == (5,)  # 0.05, 0.1, 0.5, 0.9, 0.95
    assert isinstance(model.quantile_loss, QuantileHuberLoss)
    assert model.num_outputs == 2
    assert model.horizon == 8


def test_qr_distribution_invalid_conf_level():
    # Test invalid confidence level
    with pytest.raises(ValueError, match="conf_level must be between 0 and 1"):
        QRDistribution(conf_level=1.5)


def test_qr_distribution_invalid_loss_fn():
    # Test invalid loss function
    with pytest.raises(ValueError, match="Unknown loss function"):
        QRDistribution(loss_fn="invalid")


def test_qr_distribution_forward(qr_distribution):
    # Test forward pass
    x = torch.rand(2, 16)  # Batch size 2, hidden size 16
    output = qr_distribution(x)

    # Expected shape: (B=2, N=7, T=4, C=1) (7 quantiles including bounds)
    assert output.shape == (2, 7, 4, 1)


def test_qr_distribution_step(qr_distribution):
    # Test training step
    x = torch.rand(2, 16)  # Batch size 2, hidden size 16
    y = torch.rand(2, 4, 1)  # Targets: (B=2, T=4, C=1)

    def metric_fn(y_pred, y_true):
        return torch.mean((y_pred - y_true) ** 2)

    loss, metric = qr_distribution.step(x, y, metric_fn)

    assert isinstance(loss, torch.Tensor)
    assert loss.dim() == 0  # Scalar loss
    assert isinstance(metric, torch.Tensor)
    assert metric.dim() == 0  # Scalar metric


@pytest.mark.parametrize("loss_fn", ["pinball", "huber-pinball"])
def test_qr_distribution_loss_functions(loss_fn):
    # Test different loss functions
    model = QRDistribution(loss_fn=loss_fn, hidden_size=16, horizon=4)
    x = torch.rand(2, 16)
    y = torch.rand(2, 4, 1)

    def metric_fn(y_pred, y_true):
        return torch.mean((y_pred - y_true) ** 2)

    loss, metric = model.step(x, y, metric_fn)

    assert isinstance(loss, torch.Tensor)
    assert isinstance(metric, torch.Tensor)
