import pytest
import torch
from torch import Tensor
import torch.nn as nn

# Assuming the loss functions are in a module named 'losses.py'
from twiga.distributions.nn.custom_loss import (
    QuantileHuberLoss,
    QuantileLoss,
    QuantileProposalLoss,
    loss_reduction,
    pin_ball_loss,
    quantile_huber_loss,
    quantile_proposal_loss,
)


@pytest.fixture
def sample_tensor() -> Tensor:
    return torch.tensor([1.0, 2.0, 3.0])


def test_loss_reduction(sample_tensor) -> None:
    """Test the loss_reduction function with various reduction methods.

    Verifies:
        - Correct computation of mean reduction
        - Correct computation of sum reduction
        - Proper handling of 'none' reduction
        - ValueError raising for invalid reduction types

    Args:
        sample_tensor (Tensor): Fixture providing a sample tensor of shape (3,).

    Raises:
        ValueError: When an invalid reduction type is provided.
    """
    # Test mean reduction
    assert loss_reduction(sample_tensor, "mean") == torch.tensor(2.0)
    # Test sum reduction
    assert loss_reduction(sample_tensor, "sum") == torch.tensor(6.0)
    # Test none reduction
    assert torch.all(loss_reduction(sample_tensor, "none") == sample_tensor)
    # Test invalid reduction
    with pytest.raises(ValueError):
        loss_reduction(sample_tensor, "invalid")


def test_pin_ball_loss() -> None:
    """Test the pin_ball_loss function with different error scenarios.

    Verifies:
        - Correct loss calculation for positive errors (target > input)
        - Correct loss calculation for negative errors (target < input)
        - Proper handling of softplus approximation with kappa > 0
        - Shape validation between inputs and targets
    """
    quantiles = torch.tensor([0.1, 0.5, 0.9])
    inputs = torch.tensor([[[[1.0]], [[2.0]], [[3.0]]]])
    targets = torch.tensor([[[[2.0]], [[2.0]], [[2.0]]]])

    # Case: target > input (error positive)
    loss = pin_ball_loss(inputs, targets, quantiles, kappa=0.0)
    error = targets - inputs  # [[[[1.0]], [[0.0]], [[-1.0]]]]
    expected_loss = torch.max(quantiles * error, (quantiles - 1) * error).sum(dim=1)
    assert torch.allclose(loss, expected_loss)

    # Case: target < input (error negative)
    inputs_high = torch.tensor([[[[3.0]], [[4.0]], [[5.0]]]])
    loss = pin_ball_loss(inputs_high, targets, quantiles, kappa=0.0)
    error = targets - inputs_high
    expected_loss = torch.max(quantiles * error, (quantiles - 1) * error).sum(dim=1)
    assert torch.allclose(loss, expected_loss)

    # Test with kappa > 0 (softplus)
    loss_softplus = pin_ball_loss(inputs, targets, quantiles, kappa=0.1)
    assert loss_softplus.shape == (1, 1, 3)

    # Shape mismatch
    with pytest.raises(ValueError):
        pin_ball_loss(inputs, torch.randn(2, 3, 4), quantiles)


def test_quantile_huber_loss() -> None:
    """Test the quantile_huber_loss function with different error magnitudes.

    Verifies:
        - Correct handling of errors larger than kappa threshold
        - Correct handling of errors smaller than kappa threshold
        - Non-negativity of computed loss values
        - Proper shape maintenance through computation
    """
    quantiles = torch.tensor([0.25, 0.75])
    inputs = torch.ones(2, 2, 1, 1)  # Shape: (2, 2, 1, 1)
    targets = torch.zeros(2, 2, 1, 1)  # Shape: (2, 2, 1, 1)

    quantiles = quantiles.view(1, 2, 1, 1).expand_as(inputs)

    # Error is -1 (> kappa)
    loss = quantile_huber_loss(inputs, targets, quantiles, kappa=0.25)
    assert loss.shape == (2, 1, 1)  # Should hold if reduction is correct

    # Error within kappa
    inputs = torch.ones(2, 2, 1, 1) * 0.1
    targets = torch.zeros(2, 2, 1, 1)
    loss = quantile_huber_loss(inputs, targets, quantiles, kappa=1.0)
    assert torch.all(loss >= 0)
    assert loss.shape == (2, 1, 1)


def test_quantile_proposal_loss() -> None:
    """Test the quantile_proposal_loss function.

    Verifies:
        - Correct output shape for valid inputs
        - Proper gradient checks for input tensors
        - Valid forward pass execution
    """
    quantile = torch.randn(2, 2, 4, 5)
    quantile_hats = torch.randn(2, 3, 4, 5)
    taus = torch.rand(2, 3, 4)  # Shape: (2, 2, 4, 1)

    # Test valid forward pass
    loss = quantile_proposal_loss(quantile, quantile_hats, taus)
    assert loss.shape == (2, 4, 5)

    # Test requires_grad checks
    taus.requires_grad_(True)
    with pytest.raises(ValueError):
        quantile_proposal_loss(quantile, quantile_hats, taus)


def test_quantile_loss_module() -> None:
    """Test the QuantileLoss module.

    Verifies:
        - Correct forward pass execution
        - Proper output shape with mean reduction
        - Valid parameter handling in module initialization
    """
    quantiles = torch.tensor([0.5])
    inputs = torch.tensor([[1.0], [2.0]])
    targets = torch.tensor([[2.0], [1.0]])

    loss_fn = QuantileLoss(reduction="mean")
    loss = loss_fn(inputs, quantiles, targets)
    assert loss.shape == ()


def test_quantile_huber_loss_module() -> None:
    """Test the QuantileHuberLoss module.

    Verifies:
        - Correct integration of Huber loss calculation
        - Proper output shape with mean reduction
        - Valid parameter validation during initialization
    """
    quantiles = torch.tensor([0.25, 0.75])
    inputs = torch.ones(2, 2, 1, 1)
    targets = torch.zeros(2, 2, 1, 1)

    loss_fn = QuantileHuberLoss(kappa=0.5, reduction="mean")
    loss = loss_fn(inputs, quantiles, targets)
    assert loss.shape == ()


def test_quantile_proposal_loss_module() -> None:
    """Test the QuantileProposalLoss module.

    Verifies:
        - Correct implementation of non-crossing quantile logic
        - Proper output shape with sum reduction
        - Valid forward pass execution
    """
    quantile = torch.randn(2, 2, 4, 5)
    quantile_hats = torch.randn(2, 3, 4, 5)
    taus = torch.rand(2, 3, 4)

    loss_fn = QuantileProposalLoss(reduction="sum")
    loss = loss_fn(quantile, quantile_hats, taus)
    assert loss.shape == ()


# ---------------------------------------------------------------------------
# Additional tests for previously uncovered branches
# ---------------------------------------------------------------------------


def test_interval_loss_valid() -> None:
    """interval_loss computes without error for valid inputs."""
    from twiga.distributions.nn.custom_loss import interval_loss

    boundaries = torch.tensor([[[[1.0, 2.0], [3.0, 4.0]], [[2.0, 3.0], [4.0, 5.0]]]])
    # Shape: (N=1, Q=2, T=2, C=2); targets shape: (N=1, T=2, C=2)
    targets = torch.tensor([[[1.5, 2.5], [3.5, 4.5]]])
    result = interval_loss(boundaries, targets)
    assert result.numel() >= 1


def test_interval_loss_invalid_q_raises() -> None:
    """interval_loss raises ValueError when Q < 2."""
    from twiga.distributions.nn.custom_loss import interval_loss

    boundaries = torch.ones(2, 1, 3, 1)  # Q=1 → invalid
    targets = torch.ones(2, 3, 1)
    with pytest.raises(ValueError, match="Q >= 2"):
        interval_loss(boundaries, targets)


def test_interval_loss_invalid_targets_ndim_raises() -> None:
    """interval_loss raises ValueError when targets has fewer than 2 dims."""
    from twiga.distributions.nn.custom_loss import interval_loss

    boundaries = torch.ones(2, 2, 3, 1)
    targets = torch.ones(6)  # 1-D targets → invalid
    with pytest.raises(ValueError, match="Targets must have at least 2 dimensions"):
        interval_loss(boundaries, targets)


def test_interval_loss_shape_mismatch_raises() -> None:
    """interval_loss raises ValueError when boundaries/targets shapes are incompatible."""
    from twiga.distributions.nn.custom_loss import interval_loss

    boundaries = torch.ones(2, 2, 3, 1)
    targets = torch.ones(3, 3, 1)  # batch size mismatch
    with pytest.raises(ValueError, match="Shapes incompatible"):
        interval_loss(boundaries, targets)


def test_quantile_huber_loss_shape_mismatch_raises() -> None:
    """quantile_huber_loss raises ValueError when targets/inputs shapes differ."""
    inputs = torch.ones(2, 2, 1, 1)
    targets = torch.ones(3, 2, 1, 1)  # batch mismatch
    quantiles = torch.tensor([0.25, 0.75]).view(1, 2, 1, 1).expand_as(inputs)
    with pytest.raises(ValueError, match="Targets shape"):
        quantile_huber_loss(inputs, targets, quantiles)


def test_quantile_proposal_loss_quantile_hats_requires_grad_raises() -> None:
    """quantile_proposal_loss raises ValueError when quantile_hats requires grad."""
    quantile = torch.randn(2, 2, 4, 5)
    quantile_hats = torch.randn(2, 3, 4, 5, requires_grad=True)
    taus = torch.rand(2, 3, 4)
    with pytest.raises(ValueError, match="quantile_hats.*should not require gradients"):
        quantile_proposal_loss(quantile, quantile_hats, taus)


def test_quantile_proposal_loss_quantile_requires_grad_raises() -> None:
    """quantile_proposal_loss raises ValueError when quantile requires grad."""
    quantile = torch.randn(2, 2, 4, 5, requires_grad=True)
    quantile_hats = torch.randn(2, 3, 4, 5)
    taus = torch.rand(2, 3, 4)
    with pytest.raises(ValueError, match="True quantile.*should not require gradients"):
        quantile_proposal_loss(quantile, quantile_hats, taus)


def test_quantile_loss_module_negative_kappa_raises() -> None:
    """QuantileLoss raises ValueError when kappa < 0."""
    with pytest.raises(ValueError, match="kappa must be non-negative"):
        QuantileLoss(kappa=-0.5)


def test_quantile_huber_loss_module_invalid_kappa_raises() -> None:
    """QuantileHuberLoss raises ValueError when kappa <= 0."""
    with pytest.raises(ValueError, match="kappa must be positive"):
        QuantileHuberLoss(kappa=0.0)


def test_quantile_huber_loss_module_invalid_eps_raises() -> None:
    """QuantileHuberLoss raises ValueError when eps <= 0."""
    with pytest.raises(ValueError, match="eps must be positive"):
        QuantileHuberLoss(kappa=1.0, eps=0.0)
