"""Unit tests for distributions.py probabilistic output heads.

Tests cover:
    - Construction (valid and invalid args)
    - forward() output shapes and parameter constraints
    - get_distribution() returns correct torch.distributions type
    - get_log_likelihood() is scalar, finite, and differentiable
    - build_distribution() factory
    - Gradient flow through all heads

Run with:
    pytest test_distributions.py -v
"""

from __future__ import annotations

import pytest
import torch
import torch.nn as nn

from twiga.distributions.nn.parametric import (
    DISTRIBUTIONS,
    AdditiveLaplaceDistribution,
    AdditiveLogNormalDistribution,
    AdditiveNormalDistribution,
    AdditiveStudentTDistribution,
    BetaDistribution,
    GammaDistribution,
    LaplaceDistribution,
    LogNormalDistribution,
    NormalDistribution,
    StudentTDistribution,
    build_distribution,
)

# ── Shared fixtures ────────────────────────────────────────────────────────────

BATCH = 4
HIDDEN = 32
HORIZON = 6
N_OUTPUTS = 2
EXPECTED_SHAPE = (BATCH, HORIZON, N_OUTPUTS)

# Additive distributions require hidden_size == forecast_horizon * num_target_output
ADDITIVE_NAMES = frozenset({"additive_normal", "additive_laplace", "additive_student_t", "additive_log_normal"})
ADDITIVE_HIDDEN = HORIZON * N_OUTPUTS  # 12


def _hidden_for(name: str, n_out: int = N_OUTPUTS) -> int:
    """Return the correct hidden_size for a given distribution name."""
    return HORIZON * n_out if name in ADDITIVE_NAMES else HIDDEN


@pytest.fixture
def x() -> torch.Tensor:
    """Random latent input of shape (B, hidden_size)."""
    return torch.randn(BATCH, HIDDEN)


@pytest.fixture
def targets_unbounded() -> torch.Tensor:
    """Arbitrary real-valued targets (B, H, O)."""
    return torch.randn(BATCH, HORIZON, N_OUTPUTS)


@pytest.fixture
def targets_positive() -> torch.Tensor:
    """Strictly positive targets (B, H, O)."""
    return torch.rand(BATCH, HORIZON, N_OUTPUTS).abs() + 1e-3


@pytest.fixture
def targets_unit() -> torch.Tensor:
    """Strictly (0, 1) bounded targets (B, H, O)."""
    return torch.rand(BATCH, HORIZON, N_OUTPUTS).clamp(1e-4, 1 - 1e-4)


def _make(cls, **kwargs) -> nn.Module:
    defaults = {"num_target_output": N_OUTPUTS, "hidden_size": HIDDEN, "forecast_horizon": HORIZON}
    defaults.update(kwargs)
    return cls(**defaults)


# ── BaseDistribution construction guards ──────────────────────────────────────


class TestBaseValidation:
    """Shared construction validation inherited by all heads."""

    @pytest.mark.parametrize("cls", DISTRIBUTIONS.values())
    def test_rejects_zero_num_target_output(self, cls):
        with pytest.raises(ValueError, match="num_target_output"):
            _make(cls, num_target_output=0)

    @pytest.mark.parametrize("cls", DISTRIBUTIONS.values())
    def test_rejects_negative_num_target_output(self, cls):
        with pytest.raises(ValueError, match="num_target_output"):
            _make(cls, num_target_output=-1)

    @pytest.mark.parametrize("cls", DISTRIBUTIONS.values())
    def test_rejects_zero_hidden_size(self, cls):
        with pytest.raises(ValueError, match="hidden_size"):
            _make(cls, hidden_size=0)

    @pytest.mark.parametrize("cls", DISTRIBUTIONS.values())
    def test_rejects_zero_forecast_horizon(self, cls):
        with pytest.raises(ValueError, match="forecast_horizon"):
            _make(cls, forecast_horizon=0)

    @pytest.mark.parametrize("cls", DISTRIBUTIONS.values())
    def test_stores_attributes(self, cls):
        head = _make(cls)
        assert head.num_target_output == N_OUTPUTS
        assert head.hidden_size == HIDDEN
        assert head.forecast_horizon == HORIZON


# ── NormalDistribution ────────────────────────────────────────────────────────


class TestNormalDistribution:
    @pytest.fixture
    def head(self):
        return _make(NormalDistribution)

    def test_forward_output_count(self, head, x):
        out = head(x)
        assert len(out) == 2, "forward should return (mu, sigma)"

    def test_forward_shapes(self, head, x):
        mu, sigma = head(x)
        assert mu.shape == EXPECTED_SHAPE
        assert sigma.shape == EXPECTED_SHAPE

    def test_sigma_positive(self, head, x):
        _, sigma = head(x)
        assert (sigma > 0).all(), "sigma must be strictly positive"

    def test_get_distribution_type(self, head, x):
        mu, sigma = head(x)
        dist = head.get_distribution(mu, sigma)
        assert isinstance(dist, torch.distributions.Normal)

    def test_log_likelihood_scalar(self, head, x, targets_unbounded):
        mu, sigma = head(x)
        nll = head.get_log_likelihood(mu, sigma, targets_unbounded)
        assert nll.shape == ()

    def test_log_likelihood_finite(self, head, x, targets_unbounded):
        mu, sigma = head(x)
        nll = head.get_log_likelihood(mu, sigma, targets_unbounded)
        assert torch.isfinite(nll)

    def test_log_likelihood_is_nll(self, head, x, targets_unbounded):
        """get_log_likelihood should return negative log-likelihood (positive for typical inputs)."""
        mu, sigma = head(x)
        nll = head.get_log_likelihood(mu, sigma, targets_unbounded)
        direct = -torch.distributions.Normal(mu, sigma).log_prob(targets_unbounded).mean()
        assert torch.allclose(nll, direct)

    def test_gradients_flow(self, head, x, targets_unbounded):
        x_req = x.requires_grad_(True)
        mu, sigma = head(x_req)
        nll = head.get_log_likelihood(mu, sigma, targets_unbounded)
        nll.backward()
        assert x_req.grad is not None

    def test_custom_output_activation(self, x):
        head = _make(NormalDistribution, out_activation_function=nn.Tanh())
        mu, _ = head(x)
        assert (mu >= -1).all() and (mu <= 1).all()

    @pytest.mark.parametrize("batch", [1, 8, 16])
    def test_variable_batch_sizes(self, head, batch):
        x = torch.randn(batch, HIDDEN)
        mu, sigma = head(x)
        assert mu.shape == (batch, HORIZON, N_OUTPUTS)


# ── LaplaceDistribution ───────────────────────────────────────────────────────


class TestLaplaceDistribution:
    @pytest.fixture
    def head(self):
        return _make(LaplaceDistribution)

    def test_forward_output_count(self, head, x):
        assert len(head(x)) == 2

    def test_forward_shapes(self, head, x):
        mu, scale = head(x)
        assert mu.shape == EXPECTED_SHAPE
        assert scale.shape == EXPECTED_SHAPE

    def test_scale_positive(self, head, x):
        _, scale = head(x)
        assert (scale > 0).all()

    def test_get_distribution_type(self, head, x):
        mu, scale = head(x)
        assert isinstance(head.get_distribution(mu, scale), torch.distributions.Laplace)

    def test_log_likelihood_scalar_and_finite(self, head, x, targets_unbounded):
        mu, scale = head(x)
        nll = head.get_log_likelihood(mu, scale, targets_unbounded)
        assert nll.shape == () and torch.isfinite(nll)

    def test_gradients_flow(self, head, x, targets_unbounded):
        x_req = x.requires_grad_(True)
        mu, scale = head(x_req)
        head.get_log_likelihood(mu, scale, targets_unbounded).backward()
        assert x_req.grad is not None

    def test_scale_uses_exp_not_half_exp(self, head, x):
        """Laplace scale = exp(raw), Normal sigma = exp(0.5 * raw). Verify Laplace is larger."""
        # Both heads use the same weight initialisation range; exp > exp(0.5*x) for x > 0
        with torch.no_grad():
            _, scale = head(x)
        assert (scale > 0).all()


# ── StudentTDistribution ──────────────────────────────────────────────────────


class TestStudentTDistribution:
    @pytest.fixture
    def head(self):
        return _make(StudentTDistribution)

    def test_forward_output_count(self, head, x):
        assert len(head(x)) == 3, "forward should return (mu, sigma, df)"

    def test_forward_shapes(self, head, x):
        mu, sigma, df = head(x)
        assert mu.shape == EXPECTED_SHAPE
        assert sigma.shape == EXPECTED_SHAPE
        # df is (B, 1, O) — broadcast-compatible with (B, H, O)
        assert df.shape == (BATCH, 1, N_OUTPUTS)

    def test_sigma_positive(self, head, x):
        _, sigma, _ = head(x)
        assert (sigma > 0).all()

    def test_df_above_min(self, head, x):
        _, _, df = head(x)
        assert (df >= 2.1).all(), "df must be >= min_df for finite variance"

    def test_custom_min_df(self, x):
        head = _make(StudentTDistribution, min_df=3.0)
        _, _, df = head(x)
        assert (df >= 3.0).all()

    def test_get_distribution_type(self, head, x):
        mu, sigma, df = head(x)
        assert isinstance(head.get_distribution(mu, sigma, df), torch.distributions.StudentT)

    def test_log_likelihood_scalar_and_finite(self, head, x, targets_unbounded):
        mu, sigma, df = head(x)
        nll = head.get_log_likelihood(mu, sigma, df, targets_unbounded)
        assert nll.shape == () and torch.isfinite(nll)

    def test_gradients_flow(self, head, x, targets_unbounded):
        x_req = x.requires_grad_(True)
        mu, sigma, df = head(x_req)
        head.get_log_likelihood(mu, sigma, df, targets_unbounded).backward()
        assert x_req.grad is not None


# ── LogNormalDistribution ─────────────────────────────────────────────────────


class TestLogNormalDistribution:
    @pytest.fixture
    def head(self):
        return _make(LogNormalDistribution)

    def test_forward_output_count(self, head, x):
        assert len(head(x)) == 2

    def test_forward_shapes(self, head, x):
        mu, sigma = head(x)
        assert mu.shape == EXPECTED_SHAPE
        assert sigma.shape == EXPECTED_SHAPE

    def test_sigma_positive(self, head, x):
        _, sigma = head(x)
        assert (sigma > 0).all()

    def test_get_distribution_type(self, head, x):
        mu, sigma = head(x)
        assert isinstance(head.get_distribution(mu, sigma), torch.distributions.LogNormal)

    def test_log_likelihood_requires_positive_targets(self, head, x, targets_positive):
        mu, sigma = head(x)
        nll = head.get_log_likelihood(mu, sigma, targets_positive)
        assert nll.shape == () and torch.isfinite(nll)

    def test_log_likelihood_invalid_on_nonpositive_targets(self, head, x):
        """LogNormal support is (0, inf).

        Zero targets should either raise ValueError (torch distribution constraint check)
        or produce a non-finite NLL.
        """
        mu, sigma = head(x)
        bad_targets = torch.zeros(BATCH, HORIZON, N_OUTPUTS)
        try:
            nll = head.get_log_likelihood(mu, sigma, bad_targets)
            assert not torch.isfinite(nll), "LogNormal NLL must be non-finite for zero targets"
        except ValueError:
            pass  # distribution raised a support violation — equally valid

    def test_gradients_flow(self, head, x, targets_positive):
        x_req = x.requires_grad_(True)
        mu, sigma = head(x_req)
        head.get_log_likelihood(mu, sigma, targets_positive).backward()
        assert x_req.grad is not None


# ── GammaDistribution ─────────────────────────────────────────────────────────


class TestGammaDistribution:
    @pytest.fixture
    def head(self):
        return _make(GammaDistribution)

    def test_forward_output_count(self, head, x):
        assert len(head(x)) == 2

    def test_forward_shapes(self, head, x):
        concentration, rate = head(x)
        assert concentration.shape == EXPECTED_SHAPE
        assert rate.shape == EXPECTED_SHAPE

    def test_concentration_positive(self, head, x):
        concentration, _ = head(x)
        assert (concentration > 0).all()

    def test_rate_positive(self, head, x):
        _, rate = head(x)
        assert (rate > 0).all()

    def test_get_distribution_type(self, head, x):
        concentration, rate = head(x)
        assert isinstance(head.get_distribution(concentration, rate), torch.distributions.Gamma)

    def test_log_likelihood_scalar_and_finite(self, head, x, targets_positive):
        concentration, rate = head(x)
        nll = head.get_log_likelihood(concentration, rate, targets_positive)
        assert nll.shape == () and torch.isfinite(nll)

    def test_log_likelihood_invalid_on_nonpositive_targets(self, head, x):
        """Gamma support is (0, inf). Zero targets should either raise ValueError or produce non-finite NLL."""
        concentration, rate = head(x)
        bad = torch.zeros(BATCH, HORIZON, N_OUTPUTS)
        try:
            nll = head.get_log_likelihood(concentration, rate, bad)
            assert not torch.isfinite(nll), "Gamma NLL must be non-finite for zero targets"
        except ValueError:
            pass

    def test_gradients_flow(self, head, x, targets_positive):
        x_req = x.requires_grad_(True)
        concentration, rate = head(x_req)
        head.get_log_likelihood(concentration, rate, targets_positive).backward()
        assert x_req.grad is not None

    def test_gamma_has_no_activation_arg(self):
        """GammaDistribution intentionally omits out_activation_function."""
        with pytest.raises(TypeError):
            GammaDistribution(
                num_target_output=N_OUTPUTS,
                hidden_size=HIDDEN,
                forecast_horizon=HORIZON,
                out_activation_function=nn.Identity(),
            )


# ── BetaDistribution ──────────────────────────────────────────────────────────


class TestBetaDistribution:
    @pytest.fixture
    def head(self):
        return _make(BetaDistribution)

    def test_forward_output_count(self, head, x):
        assert len(head(x)) == 2

    def test_forward_shapes(self, head, x):
        alpha, beta = head(x)
        assert alpha.shape == EXPECTED_SHAPE
        assert beta.shape == EXPECTED_SHAPE

    def test_alpha_positive(self, head, x):
        alpha, _ = head(x)
        assert (alpha > 0).all()

    def test_beta_positive(self, head, x):
        _, beta = head(x)
        assert (beta > 0).all()

    def test_get_distribution_type(self, head, x):
        alpha, beta = head(x)
        assert isinstance(head.get_distribution(alpha, beta), torch.distributions.Beta)

    def test_log_likelihood_scalar_and_finite(self, head, x, targets_unit):
        alpha, beta = head(x)
        nll = head.get_log_likelihood(alpha, beta, targets_unit)
        assert nll.shape == () and torch.isfinite(nll)

    def test_log_likelihood_invalid_on_boundary_targets(self, head, x):
        """Beta support is (0, 1). Boundary targets should either raise ValueError or produce non-finite NLL."""
        alpha, beta = head(x)
        bad = torch.zeros(BATCH, HORIZON, N_OUTPUTS)
        try:
            nll = head.get_log_likelihood(alpha, beta, bad)
            assert not torch.isfinite(nll), "Beta NLL must be non-finite for boundary targets"
        except ValueError:
            pass

    def test_gradients_flow(self, head, x, targets_unit):
        x_req = x.requires_grad_(True)
        alpha, beta = head(x_req)
        head.get_log_likelihood(alpha, beta, targets_unit).backward()
        assert x_req.grad is not None

    def test_beta_has_no_activation_arg(self):
        with pytest.raises(TypeError):
            BetaDistribution(
                num_target_output=N_OUTPUTS,
                hidden_size=HIDDEN,
                forecast_horizon=HORIZON,
                out_activation_function=nn.Identity(),
            )


# ── build_distribution factory ────────────────────────────────────────────────


class TestBuildDistribution:
    @pytest.mark.parametrize("name,cls", DISTRIBUTIONS.items())
    def test_returns_correct_type(self, name, cls):
        head = build_distribution(name, N_OUTPUTS, HIDDEN, HORIZON)
        assert isinstance(head, cls)

    @pytest.mark.parametrize("name", DISTRIBUTIONS.keys())
    def test_returned_head_is_nn_module(self, name):
        head = build_distribution(name, N_OUTPUTS, HIDDEN, HORIZON)
        assert isinstance(head, nn.Module)

    def test_raises_on_unknown_distribution(self):
        with pytest.raises(ValueError, match="Unknown distribution"):
            build_distribution("poisson", N_OUTPUTS, HIDDEN, HORIZON)

    def test_kwargs_forwarded_to_student_t(self):
        head = build_distribution("student_t", N_OUTPUTS, HIDDEN, HORIZON, min_df=5.0)
        assert head.min_df == 5.0

    def test_kwargs_forwarded_activation(self):
        head = build_distribution("normal", N_OUTPUTS, HIDDEN, HORIZON, out_activation_function=nn.Tanh())
        x = torch.randn(BATCH, HIDDEN)
        mu, _ = head(x)
        assert (mu >= -1).all() and (mu <= 1).all()

    def test_registry_is_complete(self):
        expected = {
            "normal",
            "laplace",
            "student_t",
            "log_normal",
            "gamma",
            "beta",
            "additive_normal",
            "additive_laplace",
            "additive_student_t",
            "additive_log_normal",
        }
        assert set(DISTRIBUTIONS.keys()) == expected

    @pytest.mark.parametrize("name", DISTRIBUTIONS.keys())
    def test_forward_runs_end_to_end(self, name):
        hidden = _hidden_for(name)
        head = build_distribution(name, N_OUTPUTS, hidden, HORIZON)
        x = torch.randn(BATCH, hidden)
        out = head(x)
        assert all(torch.isfinite(p).all() for p in out)


# ── Cross-distribution sanity checks ──────────────────────────────────────────


class TestCrossDistribution:
    """Properties that should hold for every distribution head."""

    @pytest.mark.parametrize("name", DISTRIBUTIONS.keys())
    def test_eval_mode_no_dropout_effect(self, name):
        hidden = _hidden_for(name)
        head = build_distribution(name, N_OUTPUTS, hidden, HORIZON)
        head.eval()
        x = torch.randn(BATCH, hidden)
        with torch.no_grad():
            out1 = head(x)
            out2 = head(x)
        for p1, p2 in zip(out1, out2, strict=True):
            assert torch.equal(p1, p2), "Deterministic in eval mode"

    @pytest.mark.parametrize("name", DISTRIBUTIONS.keys())
    def test_output_shapes_multioutput(self, name):
        n_out = 3
        hidden = _hidden_for(name, n_out)
        head = build_distribution(name, num_target_output=n_out, hidden_size=hidden, forecast_horizon=HORIZON)
        x = torch.randn(BATCH, hidden)
        out = head(x)
        for p in out:
            # df in StudentT is (B, 1, O) — skip the horizon dim check
            if p.dim() == 3:
                assert p.shape[-1] == n_out

    @pytest.mark.parametrize("name", DISTRIBUTIONS.keys())
    def test_no_nan_in_forward(self, name):
        torch.manual_seed(0)
        hidden = _hidden_for(name)
        head = build_distribution(name, N_OUTPUTS, hidden, HORIZON)
        x = torch.randn(BATCH, hidden)
        for p in head(x):
            assert not torch.isnan(p).any(), f"{name}: NaN in forward output"

    @pytest.mark.parametrize("name", DISTRIBUTIONS.keys())
    def test_parameter_count_nonzero(self, name):
        hidden = _hidden_for(name)
        head = build_distribution(name, N_OUTPUTS, hidden, HORIZON)
        n_params = sum(p.numel() for p in head.parameters())
        assert n_params > 0


# ── Additive distribution-specific tests ──────────────────────────────────────


ADDITIVE_CASES = [
    ("additive_normal", AdditiveNormalDistribution),
    ("additive_laplace", AdditiveLaplaceDistribution),
    ("additive_student_t", AdditiveStudentTDistribution),
    ("additive_log_normal", AdditiveLogNormalDistribution),
]
ADDITIVE_IDS = [c[0] for c in ADDITIVE_CASES]


@pytest.fixture
def additive_x():
    """Input whose size equals H*O (the additive backbone's encode_size)."""
    return torch.randn(BATCH, ADDITIVE_HIDDEN)


@pytest.fixture
def additive_head():
    return AdditiveNormalDistribution(
        num_target_output=N_OUTPUTS, hidden_size=ADDITIVE_HIDDEN, forecast_horizon=HORIZON
    )


class TestAdditiveDistributions:
    """Tests specific to additive distribution heads.

    Additive heads require ``hidden_size == forecast_horizon * num_target_output``
    because the backbone's encode() output IS the additive mean and is reshaped
    directly without an intermediate projection.
    """

    @pytest.mark.parametrize("name, cls", ADDITIVE_CASES, ids=ADDITIVE_IDS)
    def test_mu_equals_reshape_of_input(self, name, cls):
        """Core invariant: mu must be reshape(x) — no learned projection on the mean."""
        head = cls(num_target_output=N_OUTPUTS, hidden_size=ADDITIVE_HIDDEN, forecast_horizon=HORIZON)
        x = torch.randn(BATCH, ADDITIVE_HIDDEN)
        params = head(x)
        mu = params[0]
        expected = x.view(BATCH, HORIZON, N_OUTPUTS)
        assert torch.allclose(mu, expected), "Additive head must return reshape(x) as mu"

    @pytest.mark.parametrize("name, cls", ADDITIVE_CASES, ids=ADDITIVE_IDS)
    def test_forward_shapes(self, name, cls):
        head = cls(num_target_output=N_OUTPUTS, hidden_size=ADDITIVE_HIDDEN, forecast_horizon=HORIZON)
        x = torch.randn(BATCH, ADDITIVE_HIDDEN)
        for p in head(x):
            assert p.shape[0] == BATCH
            assert p.shape[-1] == N_OUTPUTS

    @pytest.mark.parametrize(
        "name, cls",
        [c for c in ADDITIVE_CASES if "student_t" not in c[0]],
        ids=[i for i in ADDITIVE_IDS if "student_t" not in i],
    )
    def test_scale_positive(self, name, cls):
        """Second output (scale) must be strictly positive."""
        head = cls(num_target_output=N_OUTPUTS, hidden_size=ADDITIVE_HIDDEN, forecast_horizon=HORIZON)
        x = torch.randn(BATCH, ADDITIVE_HIDDEN)
        _, scale = head(x)
        assert (scale > 0).all(), f"{name}: scale must be strictly positive"

    def test_student_t_df_above_min(self, additive_x):
        head = AdditiveStudentTDistribution(
            num_target_output=N_OUTPUTS, hidden_size=ADDITIVE_HIDDEN, forecast_horizon=HORIZON
        )
        _, _, df = head(additive_x)
        assert (df >= 2.1).all()

    @pytest.mark.parametrize("name, cls", ADDITIVE_CASES, ids=ADDITIVE_IDS)
    def test_log_likelihood_scalar_finite(self, name, cls):
        head = cls(num_target_output=N_OUTPUTS, hidden_size=ADDITIVE_HIDDEN, forecast_horizon=HORIZON)
        x = torch.randn(BATCH, ADDITIVE_HIDDEN)
        y = torch.randn(BATCH, HORIZON, N_OUTPUTS).abs() + 1e-3
        params = head(x)
        nll = head.get_log_likelihood(*params, targets=y)
        assert nll.shape == () and torch.isfinite(nll)

    @pytest.mark.parametrize("name, cls", ADDITIVE_CASES, ids=ADDITIVE_IDS)
    def test_gradients_flow_through_scale_only(self, name, cls):
        """Gradient must flow through scale layer; mu has no parameters so x.grad comes from scale."""
        head = cls(num_target_output=N_OUTPUTS, hidden_size=ADDITIVE_HIDDEN, forecast_horizon=HORIZON)
        x = torch.randn(BATCH, ADDITIVE_HIDDEN, requires_grad=True)
        y = torch.randn(BATCH, HORIZON, N_OUTPUTS).abs() + 1e-3
        params = head(x)
        nll = head.get_log_likelihood(*params, targets=y)
        nll.backward()
        assert x.grad is not None

    @pytest.mark.parametrize("name, cls", ADDITIVE_CASES, ids=ADDITIVE_IDS)
    def test_custom_out_activation_applied_to_mu(self, name, cls):
        head = cls(
            num_target_output=N_OUTPUTS,
            hidden_size=ADDITIVE_HIDDEN,
            forecast_horizon=HORIZON,
            out_activation_function=nn.Tanh(),
        )
        x = torch.randn(BATCH, ADDITIVE_HIDDEN) * 5  # large values to test Tanh clipping
        mu = head(x)[0]
        assert (mu >= -1).all() and (mu <= 1).all()

    def test_no_mu_layer_attribute(self, additive_head):
        """Additive heads must NOT have a mu_layer (that would add a projection)."""
        assert not hasattr(additive_head, "mu_layer"), "Additive head must not have mu_layer"

    def test_has_log_scale_or_scale_layer(self, additive_head):
        """Scale must be learned via a dedicated layer."""
        has_scale = hasattr(additive_head, "log_scale_layer") or hasattr(additive_head, "sigma_layer")
        assert has_scale

    @pytest.mark.parametrize("name, cls", ADDITIVE_CASES, ids=ADDITIVE_IDS)
    def test_mismatched_hidden_size_raises(self, name, cls):
        """Additive heads fail if hidden_size != H*O (misuse protection)."""
        head = cls(num_target_output=N_OUTPUTS, hidden_size=ADDITIVE_HIDDEN, forecast_horizon=HORIZON)
        bad_x = torch.randn(BATCH, HIDDEN)  # HIDDEN != ADDITIVE_HIDDEN
        with pytest.raises(RuntimeError):
            head(bad_x)

    @pytest.mark.parametrize("name, cls", ADDITIVE_CASES, ids=ADDITIVE_IDS)
    def test_step_returns_loss_and_metric(self, name, cls):
        head = cls(num_target_output=N_OUTPUTS, hidden_size=ADDITIVE_HIDDEN, forecast_horizon=HORIZON)
        x = torch.randn(BATCH, ADDITIVE_HIDDEN)
        # Use strictly positive targets to satisfy LogNormal support
        y = torch.rand(BATCH, HORIZON, N_OUTPUTS).abs() + 1e-3
        loss, metric = head.step(x, y, lambda pred, tgt: (pred - tgt).abs().mean())
        assert loss.shape == ()
        assert torch.isfinite(loss)
