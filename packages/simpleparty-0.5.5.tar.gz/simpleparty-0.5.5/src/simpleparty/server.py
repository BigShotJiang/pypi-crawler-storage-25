#!/usr/bin/env python3
"""SimpleParty - Easily enjoy your private video collection."""

import argparse
import json
import os
import random
import re
import shutil
import subprocess
import sys
import threading
import urllib.parse
from functools import partial
from html import escape as esc
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from socketserver import ThreadingMixIn

VIDEO_EXTENSIONS = frozenset({
    '.mp4', '.mkv', '.webm', '.mov', '.avi', '.m4v', '.ogv',
})

BROWSER_NATIVE = frozenset({'.mp4', '.webm', '.ogv', '.m4v'})

_config = {
    'has_ffmpeg': False,
    'has_vlc': False,
    'allow_delete': True,
    'allow_transcode': True,
    'allow_tag': True,
    'tag_jobs': {},  # path -> progress dict
    'thumb_jobs': set(),  # directories currently generating thumbs
}

MIME_TYPES = {
    '.mp4': 'video/mp4',
    '.webm': 'video/webm',
    '.mkv': 'video/x-matroska',
    '.mov': 'video/quicktime',
    '.avi': 'video/x-msvideo',
    '.m4v': 'video/mp4',
    '.ogv': 'video/ogg',
}


# --- Filesystem ---

def is_video(name):
    return Path(name).suffix.lower() in VIDEO_EXTENSIONS


def resolve_path(root, relative):
    """Resolve a path relative to root, following symlinks."""
    if not relative:
        return Path(root).resolve()
    return (Path(root) / relative).resolve()


def list_directory(root, rel_path):
    """List directory contents. Returns dict with dirs, videos, or error/locked."""
    resolved = resolve_path(root, rel_path)

    if not resolved.exists():
        locked = find_locked_ancestor(root, rel_path)
        if locked is not None:
            return {'locked': True, 'path': rel_path, 'encryptedDir': locked}
        return {'error': 'Not found'}

    if not resolved.is_dir():
        return {'error': 'Not a directory'}

    status = get_fscrypt_status(resolved)
    if status['encrypted'] and not status['unlocked']:
        return {'locked': True, 'path': rel_path, 'encryptedDir': rel_path}

    try:
        entries = sorted(os.listdir(resolved))
    except (PermissionError, OSError):
        return {'error': 'Cannot read directory'}

    encrypted_root = find_encrypted_ancestor(root, rel_path)

    dirs, videos = [], []
    for name in entries:
        if name.startswith('.'):
            continue
        full = resolved / name
        child_path = os.path.join(rel_path, name) if rel_path else name
        if full.is_dir():
            dir_status = get_fscrypt_status(full)
            dirs.append({
                'name': name, 'path': child_path,
                'encrypted': dir_status['encrypted'],
                'unlocked': dir_status['unlocked'],
            })
        elif full.is_file() and is_video(name):
            try:
                size = full.stat().st_size
            except OSError:
                size = 0
            videos.append({'name': name, 'path': child_path, 'size': size})

    return {
        'path': rel_path, 'dirs': dirs, 'videos': videos,
        'encryptedDir': encrypted_root,
    }


# --- fscrypt ---

def get_fscrypt_status(dir_path):
    try:
        result = subprocess.run(
            ['fscrypt', 'status', str(dir_path)],
            capture_output=True, text=True, timeout=5,
        )
        output = result.stdout + result.stderr
        if 'is encrypted with fscrypt' not in output:
            return {'encrypted': False, 'unlocked': True}
        unlocked = bool(re.search(r'Unlocked:\s*Yes', output))
        return {'encrypted': True, 'unlocked': unlocked}
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return {'encrypted': False, 'unlocked': True}


def fscrypt_unlock(dir_path, passphrase):
    try:
        proc = subprocess.Popen(
            ['fscrypt', 'unlock', str(dir_path)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True,
        )
        stdout, stderr = proc.communicate(
            input=(passphrase + '\n').encode('utf-8'),
            timeout=10,
        )
        return proc.returncode == 0, (stdout.decode() + stderr.decode()).strip()
    except subprocess.TimeoutExpired:
        proc.kill()
        return False, 'Timed out'
    except FileNotFoundError:
        return False, 'fscrypt not found'


def fscrypt_lock(dir_path):
    try:
        result = subprocess.run(
            ['fscrypt', 'lock', str(dir_path)],
            capture_output=True, text=True, timeout=5,
        )
        return result.returncode == 0, (result.stdout + result.stderr).strip()
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        return False, str(e)


def find_encrypted_ancestor(root, rel_path):
    if not rel_path or rel_path == '.':
        status = get_fscrypt_status(Path(root))
        return '' if status['encrypted'] else None
    parts = Path(rel_path).parts
    for i in range(len(parts)):
        ancestor_rel = os.path.join(*parts[:i + 1])
        ancestor_abs = Path(root) / ancestor_rel
        if ancestor_abs.is_dir():
            status = get_fscrypt_status(ancestor_abs)
            if status['encrypted']:
                return ancestor_rel
    return None


def find_locked_ancestor(root, rel_path):
    if not rel_path or rel_path == '.':
        status = get_fscrypt_status(Path(root))
        if status['encrypted'] and not status['unlocked']:
            return ''
        return None
    parts = Path(rel_path).parts
    for i in range(len(parts)):
        ancestor_rel = os.path.join(*parts[:i + 1])
        ancestor_abs = Path(root) / ancestor_rel
        if ancestor_abs.is_dir():
            status = get_fscrypt_status(ancestor_abs)
            if status['encrypted'] and not status['unlocked']:
                return ancestor_rel
    return None


# --- URL + format helpers ---

def parse_query(url):
    params = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
    return {k: v[0] for k, v in params.items()}


def url_for_browse(path='', tags=None):
    params = {}
    if path:
        params['path'] = path
    if tags:
        params['tags'] = ','.join(tags)
    return '/' if not params else '/browse?' + urllib.parse.urlencode(params)


def url_for_play(dir_path, idx, shuffle=False, seed=None, pos=None, tags=None):
    params = {'path': dir_path, 'idx': str(idx)}
    if shuffle:
        params['shuffle'] = '1'
        if seed is not None:
            params['seed'] = str(seed)
        if pos is not None:
            params['pos'] = str(pos)
    if tags:
        params['tags'] = ','.join(tags)
    return '/play?' + urllib.parse.urlencode(params)


def url_for_video(path):
    return '/video/' + '/'.join(urllib.parse.quote(p, safe='') for p in path.split('/'))


def fmt_size(b):
    if b < 1024:
        return f'{b} B'
    if b < 1048576:
        return f'{b / 1024:.1f} KB'
    if b < 1073741824:
        return f'{b / 1048576:.1f} MB'
    return f'{b / 1073741824:.1f} GB'


def parse_tags_param(params):
    """Parse comma-separated tags from URL params into a list."""
    raw = params.get('tags', '')
    return [t.strip() for t in raw.split(',') if t.strip()] if raw else []


def filter_videos_by_tags(videos, tags_map, selected_tags):
    """Filter video list to those having ALL selected tags (AND logic)."""
    if not selected_tags or not tags_map:
        return videos
    selected_lower = {t.lower() for t in selected_tags}
    return [
        v for v in videos
        if v['name'] in tags_map
        and selected_lower <= {t.lower() for t in tags_map[v['name']].get('tags', [])}
    ]


def shuffle_indices(n, seed):
    rng = random.Random(seed)
    indices = list(range(n))
    rng.shuffle(indices)
    return indices


def safe_int(s, default=0):
    try:
        return int(s)
    except (ValueError, TypeError):
        return default


# --- HTML rendering ---

CSS = """\
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
html{height:100%}
body{
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;
  background:#0f0f1a;color:#e2e8f0;min-height:100%;overflow-x:hidden;max-width:100vw;
}
a{color:inherit;text-decoration:none}
nav{
  position:sticky;top:0;background:#1a1a2e;padding:12px 16px;
  display:flex;align-items:center;gap:4px;
  border-bottom:1px solid #2d2d44;z-index:10;flex-wrap:wrap;min-height:48px;
  overflow:hidden;max-width:100vw;
}
.crumb{
  color:#94a3b8;padding:4px 6px;border-radius:4px;
  font-size:15px;white-space:nowrap;
}
.crumb:hover{color:#c4b5fd;background:rgba(167,139,250,0.1)}
.crumb-sep{color:#4a4a6a;padding:0 2px;user-select:none}
.nav-spacer{flex:1}
.btn{
  background:#16213e;color:#e2e8f0;border:1px solid #2d2d44;
  padding:8px 14px;border-radius:6px;cursor:pointer;font-size:14px;
  min-height:40px;white-space:nowrap;transition:all .15s;
  display:inline-flex;align-items:center;
}
.btn:hover{background:#1e3054;border-color:#a78bfa}
.btn.active{background:#7c3aed;color:#fff;border-color:#7c3aed}
.btn-lock{border-color:#991b1b}
.btn-lock:hover{background:#7f1d1d;border-color:#dc2626}
#player-area{position:sticky;top:0;z-index:5;background:#000}
video{width:100%;max-height:70vh;display:block;background:#000}
#controls{
  display:flex;align-items:center;padding:8px 16px;gap:8px;
  background:#1a1a2e;border-bottom:1px solid #2d2d44;flex-wrap:wrap;
}
#now-playing{
  flex:1;text-align:center;overflow:hidden;text-overflow:ellipsis;
  white-space:nowrap;color:#94a3b8;font-size:13px;padding:0 8px;
}
#file-list{
  padding:16px;
  display:grid;grid-template-columns:repeat(auto-fill,minmax(min(220px,100%),1fr));gap:8px;
  overflow:hidden;max-width:100%;
}
.item{
  display:flex;align-items:center;gap:10px;padding:12px 14px;
  background:#16213e;border-radius:8px;min-height:48px;
  transition:background .15s;border:2px solid transparent;min-width:0;overflow:hidden;
  flex-wrap:wrap;
}
.item-video{
  flex-direction:column;align-items:stretch;padding:0;gap:0;
}
.item-video .item-link{flex-direction:column;align-items:stretch;gap:0}
.item-video .item-info{display:flex;align-items:center;gap:8px;padding:8px 10px;min-width:0}
.item-thumb{width:100%;aspect-ratio:16/9;object-fit:cover;border-radius:6px 6px 0 0;display:block;background:#0f0f1a}
.item-thumb-placeholder{display:flex;align-items:center;justify-content:center;font-size:32px;color:#4a4a6a}
.item:hover{background:#1e3054}
.item-video:hover{background:#1e3054}
.item.playing{border-color:#7c3aed}
.item-link{display:flex;align-items:center;gap:10px;flex:1;min-width:0}
.item-icon{font-size:18px;flex-shrink:0;line-height:1}
.item-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:14px;flex:1}
.item-size{color:#64748b;font-size:12px;flex-shrink:0}
.btn-del{
  background:none;border:none;color:#64748b;cursor:pointer;font-size:16px;
  padding:4px;border-radius:4px;flex-shrink:0;line-height:1;
}
.btn-del:hover{color:#f87171;background:rgba(248,113,113,0.1)}
.item-video .btn-del{position:absolute;top:4px;right:4px;z-index:2;background:rgba(0,0,0,0.5);border-radius:50%;padding:4px 6px}
.item-video{position:relative}
.item-video .item-tags{padding:0 10px 8px;width:100%}
.empty{grid-column:1/-1;color:#64748b;text-align:center;padding:40px 20px;font-size:15px}
.action-bar{grid-column:1/-1;display:flex;gap:8px;padding-bottom:4px;flex-wrap:wrap;overflow:hidden}
.unlock-box{
  max-width:380px;margin:40px auto;background:#1a1a2e;border:1px solid #2d2d44;
  border-radius:12px;padding:24px;
}
.unlock-box h3{margin-bottom:16px;font-size:18px}
.unlock-box input[type="password"]{
  width:100%;padding:12px;background:#0f0f1a;border:1px solid #2d2d44;
  border-radius:6px;color:#e2e8f0;font-size:16px;outline:none;
}
.unlock-box input:focus{border-color:#7c3aed}
.unlock-actions{display:flex;gap:8px;justify-content:flex-end;margin-top:16px}
.unlock-error{color:#f87171;font-size:13px;margin-top:10px;min-height:1.2em}
.error-page{color:#f87171;text-align:center;padding:60px 20px;font-size:16px}
.item-tags{color:#64748b;font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:100%;padding-top:2px}
.item-tags.suggested{color:#a78bfa;opacity:0.5;font-style:italic}
.btn-train.htmx-request{opacity:0.6;pointer-events:none}
.btn-train.htmx-request .btn-label{display:none}
.btn-train.htmx-request .btn-spinner{display:inline-block}
.btn-train:disabled,.btn-train.busy{opacity:0.5;cursor:not-allowed;pointer-events:none;border-color:#4a4a6a}
.btn-spinner{display:none;width:14px;height:14px;border:2px solid #64748b;border-top-color:#a78bfa;border-radius:50%;animation:spin .6s linear infinite;vertical-align:middle}
@keyframes spin{to{transform:rotate(360deg)}}
.tag-progress-panel{display:flex;align-items:center;gap:10px;min-height:0;transition:all .3s ease}
.tag-progress-panel:empty{display:none}
.tag-progress-bar-wrap{flex:0 1 200px;min-width:80px;height:6px;background:#2d2d44;border-radius:3px;overflow:hidden}
.tag-progress-bar{height:100%;background:#7c3aed;border-radius:3px;transition:width .4s ease}
.tag-progress-text{color:#94a3b8;font-size:13px;white-space:nowrap}
.tag-progress-phase{color:#a78bfa;font-size:13px;font-weight:500}
.tag-progress-panel.active .tag-progress-phase{animation:pulse 1.5s ease infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.6}}
.tag-done{color:#4ade80;font-size:13px;font-weight:500;display:flex;align-items:center;gap:8px;animation:fadeIn .3s ease}
.tag-error{color:#f87171;font-size:13px;font-weight:500;animation:fadeIn .3s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}
.tag-filter{padding:8px 16px;border-bottom:1px solid #2d2d44;display:flex;flex-wrap:wrap;align-items:center;gap:8px}
.tag-selected-pills{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
.tag-pill{display:inline-flex;align-items:center;background:#2d2d44;color:#a78bfa;padding:4px 10px;border-radius:12px;font-size:12px;white-space:nowrap;cursor:pointer;text-decoration:none;transition:all .15s;gap:4px}
.tag-pill:hover{background:#3d3d5c}
.tag-pill.active{background:#7c3aed;color:#fff}
.tag-pill-count{color:#64748b;font-size:11px}
.tag-pill.active .tag-pill-count{color:rgba(255,255,255,0.7)}
.tag-pill-x{font-size:10px;opacity:0.7;margin-left:2px}
.tag-pill-x:hover{opacity:1}
.tag-clear{color:#94a3b8;font-size:12px;cursor:pointer;text-decoration:underline;padding:4px 8px}
.tag-dropdown-wrap{position:relative;display:inline-block}
.tag-search{background:#0f0f1a;border:1px solid #2d2d44;border-radius:6px;color:#e2e8f0;padding:6px 10px;font-size:13px;width:220px}
.tag-search:focus{border-color:#7c3aed;outline:none}
.tag-dropdown{display:none;position:absolute;top:100%;left:0;z-index:50;background:#1a1a2e;border:1px solid #2d2d44;border-radius:6px;margin-top:4px;max-height:240px;overflow-y:auto;min-width:220px;box-shadow:0 4px 12px rgba(0,0,0,0.4)}
.tag-dropdown.open{display:block}
.tag-dropdown a{display:flex;justify-content:space-between;padding:6px 12px;color:#a78bfa;text-decoration:none;font-size:12px;transition:background .1s}
.tag-dropdown a:hover{background:#2d2d44}
.tag-dropdown a .cnt{color:#64748b;font-size:11px}
.video-meta{padding:8px 16px;background:#1a1a2e;border-bottom:1px solid #2d2d44;display:flex;flex-wrap:wrap;align-items:center;gap:8px}
.video-meta .item-tags{width:100%}
.video-meta input[type="text"]{background:#0f0f1a;border:1px solid #2d2d44;border-radius:6px;color:#e2e8f0;padding:6px 10px;font-size:13px;flex:1;min-width:200px}
.video-meta input:focus{border-color:#7c3aed;outline:none}
.video-tag-pills{display:flex;flex-wrap:wrap;gap:6px;align-items:center;width:100%}
.video-tag-pill{display:inline-flex;align-items:center;background:#2d2d44;color:#a78bfa;padding:4px 10px;border-radius:12px;font-size:12px;white-space:nowrap;gap:4px}
.video-tag-pill.suggested{background:transparent;border:1px dashed #a78bfa;opacity:0.7}
.btn-confirm{color:#4ade80;border-color:#4ade80;font-size:12px;padding:2px 8px}
.btn-confirm:hover{background:#166534}
.btn-reject{color:#f87171;border-color:#f87171;font-size:12px;padding:2px 8px}
.btn-reject:hover{background:#7f1d1d}
.video-tag-remove{background:none;border:none;color:#a78bfa;cursor:pointer;font-size:10px;padding:0 0 0 2px;opacity:0.6;line-height:1}
.video-tag-remove:hover{opacity:1;color:#f87171}
.video-tag-add{background:#0f0f1a;border:1px solid #2d2d44;border-radius:12px;color:#e2e8f0;padding:4px 10px;font-size:12px;width:120px;outline:none}
.video-tag-add:focus{border-color:#7c3aed}
@media(max-width:640px){
  #file-list{grid-template-columns:1fr;padding:8px;gap:6px}
  nav{padding:8px 12px}
  #controls{padding:6px 12px;justify-content:center}
}"""


def render_page(title, body):
    return (
        '<!DOCTYPE html>\n<html lang="en">\n<head>\n'
        '<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n'
        f'<title>{esc(title)}</title>\n'
        f'<style>{CSS}</style>\n'
        '<script src="https://unpkg.com/htmx.org@2.0.4"></script>\n'
        '</head>\n<body>\n'
        f'{body}\n'
        '</body>\n</html>'
    )


def render_nav(path, encrypted_dir=None):
    parts = path.split('/') if path else []
    pieces = ['<a class="crumb" href="/">SimpleParty</a>']
    acc = ''
    for part in parts:
        acc += ('/' if acc else '') + part
        pieces.append(f'<span class="crumb-sep">/</span>')
        pieces.append(f'<a class="crumb" href="{esc(url_for_browse(acc))}">{esc(part)}</a>')
    pieces.append('<span class="nav-spacer"></span>')
    if encrypted_dir is not None:
        parent = str(Path(encrypted_dir).parent)
        if parent == '.':
            parent = ''
        pieces.append(
            f'<form hx-post="/lock" hx-confirm="Lock this directory?" style="display:inline">'
            f'<input type="hidden" name="path" value="{esc(encrypted_dir)}">'
            f'<input type="hidden" name="redirect" value="{esc(url_for_browse(parent))}">'
            f'<button type="submit" class="btn btn-lock">Lock</button>'
            f'</form>'
        )
    return '<nav>' + ''.join(pieces) + '</nav>'


def _render_train_btn(path_param, is_busy):
    cls = 'btn btn-train busy' if is_busy else 'btn btn-train'
    disabled = ' disabled' if is_busy else ''
    label = '\U0001F9E0 Training\u2026' if is_busy else '\U0001F9E0 Train'
    return (
        f'<form hx-post="/train" style="display:inline" id="train-form">'
        f'<input type="hidden" name="path" value="{path_param}">'
        f'<button class="{cls}"{disabled} hx-disabled-elt="this">'
        f'<span class="btn-spinner"></span>'
        f'<span class="btn-label">{label}</span>'
        f'</button>'
        f'</form>'
    )


def render_file_list(data, current_idx=-1, show_shuffle=True, tags_map=None, selected_tags=None):
    pieces = ['<div id="file-list">']

    if show_shuffle and data['videos']:
        shuffle_params = {'path': data['path'], 'shuffle': '1'}
        if selected_tags:
            shuffle_params['tags'] = ','.join(selected_tags)
        shuffle_url = '/play?' + urllib.parse.urlencode(shuffle_params)
        tag_html = ''
        if _config['allow_tag'] and _config['has_ffmpeg']:
            path_param = esc(data['path'])
            # Check if model exists for this directory
            from simpleparty.tagger import model_path as _model_path
            resolved_dir = resolve_path(_config.get('root', '.'), data['path'])
            has_model = _model_path(resolved_dir).exists() if resolved_dir.is_dir() else False
            resolved_str = str(resolved_dir)
            job = _config['tag_jobs'].get(resolved_str)
            is_busy = bool(job and job.get('running'))
            tag_html = _render_train_btn(path_param, is_busy)
            if has_model:
                tag_html += (
                    f'<form hx-post="/suggest" style="display:inline">'
                    f'<input type="hidden" name="path" value="{path_param}">'
                    f'<button class="btn">\U0001F3F7 Suggest tags</button>'
                    f'</form>'
                )
            # Show "Confirm all" if there are suggested tags
            if tags_map:
                has_suggested = any(
                    e.get('status') == 'suggested' for e in tags_map.values()
                )
                if has_suggested:
                    tag_html += (
                        f'<form hx-post="/confirm-all" style="display:inline">'
                        f'<input type="hidden" name="path" value="{path_param}">'
                        f'<button class="btn btn-confirm">\u2714 Confirm all</button>'
                        f'</form>'
                    )
            status_url = f'/tag-status?{urllib.parse.urlencode({"path": data["path"]})}'
            poll = 'every 2s' if is_busy else 'every 10s'
            tag_html += (
                f'<div hx-get="{status_url}" '
                f'hx-trigger="load,{poll}" hx-swap="outerHTML" '
                f'class="tag-progress-panel{" active" if is_busy else ""}" '
                f'id="tag-progress"></div>'
            )
        pieces.append(
            f'<div class="action-bar">'
            f'<a class="btn" href="{esc(shuffle_url)}">\u21C5 Shuffle Play</a>'
            f'{tag_html}'
            f'</div>'
        )

    for d in data['dirs']:
        if d['encrypted'] and not d['unlocked']:
            icon = '\U0001F512'
        elif d['encrypted']:
            icon = '\U0001F513'
        else:
            icon = '\U0001F4C1'
        pieces.append(
            f'<a class="item" href="{esc(url_for_browse(d["path"]))}">'
            f'<span class="item-icon">{icon}</span>'
            f'<span class="item-name">{esc(d["name"])}</span>'
            f'</a>'
        )

    from simpleparty.tagger import thumb_path
    root_dir = _config.get('root', '.')
    for i, v in enumerate(data['videos']):
        cls = ' playing' if i == current_idx else ''
        play_url = url_for_play(data['path'], i, tags=selected_tags)
        resolved_dir = resolve_path(root_dir, data['path'])
        has_thumb = thumb_path(str(resolved_dir), v['name']).exists()
        pieces.append(f'<div class="item item-video{cls}">')
        thumb_url = f'/thumb/{urllib.parse.quote(v["path"])}'
        if has_thumb:
            thumb_html = f'<img src="{thumb_url}" loading="lazy" class="item-thumb" alt="">'
        else:
            thumb_html = '<div class="item-thumb item-thumb-placeholder">\U0001F3AC</div>'
        pieces.append(
            f'<a class="item-link" href="{esc(play_url)}">'
            f'{thumb_html}'
            f'<span class="item-info">'
            f'<span class="item-name">{esc(v["name"])}</span>'
            f'<span class="item-size">{fmt_size(v["size"])}</span>'
            f'</span>'
            f'</a>'
        )
        if _config['allow_delete']:
            pieces.append(
                f'<form hx-post="/delete" hx-target="closest .item" hx-swap="delete" '
                f'hx-confirm="Delete {esc(v["name"])}?">'
                f'<input type="hidden" name="path" value="{esc(v["path"])}">'
                f'<button type="submit" class="btn-del" title="Delete">\U0001F5D1</button>'
                f'</form>'
            )
        if tags_map and v['name'] in tags_map:
            entry = tags_map[v['name']]
            video_tags = entry.get('tags', [])
            if video_tags:
                is_suggested = entry.get('status') == 'suggested'
                tags_text = esc(' \u00B7 '.join(video_tags[:8]))
                cls = ' suggested' if is_suggested else ''
                prefix = '\u2753 ' if is_suggested else ''
                pieces.append(f'<div class="item-tags{cls}">{prefix}{tags_text}</div>')
        pieces.append('</div>')

    if not data['dirs'] and not data['videos']:
        pieces.append('<div class="empty">Empty directory</div>')

    pieces.append('</div>')
    return ''.join(pieces)


def _compute_viable_tags(tags_map, selected_tags):
    """Return set of lowercased tags that can be added without producing zero results."""
    selected_lower = {t.lower() for t in selected_tags} if selected_tags else set()
    viable = set()
    for video_data in tags_map.values():
        vtags = {t.lower().strip() for t in video_data.get('tags', [])}
        if selected_lower <= vtags:
            viable |= vtags
    # Remove already-selected tags from viable set
    viable -= selected_lower
    return viable


def render_tag_filter(tags_map, selected_tags, path):
    """Render tag filter: selected pills + searchable dropdown of viable tags."""
    if not tags_map:
        return ''
    # Count all tags
    counts = {}
    for video_data in tags_map.values():
        for tag in video_data.get('tags', []):
            key = tag.lower().strip()
            if key:
                counts[key] = counts.get(key, 0) + 1
    if not counts:
        return ''

    selected_lower = {t.lower() for t in selected_tags} if selected_tags else set()
    viable = _compute_viable_tags(tags_map, selected_tags)

    pieces = ['<div class="tag-filter">']

    # Selected tag pills
    if selected_tags:
        pieces.append('<div class="tag-selected-pills">')
        for tag in selected_tags:
            remove_tags = [t for t in selected_tags if t.lower() != tag.lower()]
            href = url_for_browse(path, tags=remove_tags if remove_tags else None)
            pieces.append(
                f'<a class="tag-pill active" href="{esc(href)}">'
                f'{esc(tag)} <span class="tag-pill-x">\u00d7</span></a>'
            )
        pieces.append(
            f'<a class="tag-clear" href="{esc(url_for_browse(path))}">Clear all</a>'
        )
        pieces.append('</div>')

    # Search input + dropdown
    viable_sorted = sorted(
        [(tag, counts[tag]) for tag in viable if tag in counts],
        key=lambda x: (-x[1], x[0]),
    )

    if viable_sorted:
        pieces.append('<div class="tag-dropdown-wrap">')
        pieces.append(
            '<input type="text" id="tag-search" class="tag-search" '
            'placeholder="Filter by tag\u2026" autocomplete="off">'
        )
        pieces.append('<div class="tag-dropdown" id="tag-dropdown">')
        for tag, count in viable_sorted:
            new_tags = list(selected_tags or []) + [tag]
            href = url_for_browse(path, tags=new_tags)
            cnt = f' <span class="cnt">({count})</span>' if count > 1 else ''
            pieces.append(f'<a href="{esc(href)}">{esc(tag)}{cnt}</a>')
        pieces.append('</div></div>')

        # JS: show/hide dropdown, filter, close on outside click
        pieces.append(
            '<script>'
            '(function(){'
            'var s=document.getElementById("tag-search"),'
            'd=document.getElementById("tag-dropdown"),'
            'items=d.querySelectorAll("a");'
            # Show dropdown on focus (with top items visible)
            's.addEventListener("focus",function(){d.classList.add("open")});'
            # Filter on input
            's.addEventListener("input",function(){'
            'var q=this.value.toLowerCase();'
            'items.forEach(function(a){'
            'a.style.display=a.textContent.toLowerCase().includes(q)?"":"none"'
            '});d.classList.add("open")});'
            # Close on outside click
            'document.addEventListener("click",function(e){'
            'if(!e.target.closest(".tag-dropdown-wrap"))d.classList.remove("open")});'
            '})();'
            '</script>'
        )

    pieces.append('</div>')
    return ''.join(pieces)


def render_browse_page(data, tags_map=None, selected_tags=None):
    title = f'SimpleParty \u2014 {data["path"].split("/")[-1]}' if data['path'] else 'SimpleParty'
    body = render_nav(data['path'], data.get('encryptedDir'))
    body += render_tag_filter(tags_map, selected_tags, data['path'])
    body += render_file_list(data, tags_map=tags_map, selected_tags=selected_tags)
    return render_page(title, body)


def render_locked_page(path, encrypted_dir, redirect_path=None, error=None):
    body = render_nav(path)
    dir_name = encrypted_dir.split('/')[-1] if encrypted_dir else 'directory'
    redir = redirect_path or path
    parent = str(Path(path).parent) if '/' in path else ''
    if parent == '.':
        parent = ''
    body += (
        f'<div class="unlock-box">'
        f'<h3>Unlock {esc(dir_name)}</h3>'
        f'<form hx-post="/unlock" hx-target="#unlock-error" hx-swap="innerHTML">'
        f'<input type="hidden" name="path" value="{esc(encrypted_dir)}">'
        f'<input type="hidden" name="redirect" value="{esc(url_for_browse(redir))}">'
        f'<input type="password" name="passphrase" placeholder="Passphrase" autofocus>'
        f'<div id="unlock-error" class="unlock-error">{esc(error) if error else ""}</div>'
        f'<div class="unlock-actions">'
        f'<a class="btn" href="{esc(url_for_browse(parent))}">Cancel</a>'
        f'<button class="btn active" type="submit">Unlock</button>'
        f'</div></form></div>'
    )
    return render_page('SimpleParty \u2014 Unlock', body)


def render_error_page(path, error):
    body = render_nav(path)
    body += f'<div class="error-page">{esc(error)}</div>'
    return render_page('SimpleParty \u2014 Error', body)


def render_video_tags_inline(rel_path, video_name, tags_list, status='confirmed'):
    """Render tag pills with inline add/remove for the video play page."""
    is_suggested = status == 'suggested'
    pieces = ['<div class="video-tag-pills">']

    if is_suggested:
        pieces.append(
            f'<form hx-post="/confirm-tags" hx-target="#video-meta" hx-swap="innerHTML" '
            f'style="display:inline;margin:0;padding:0">'
            f'<input type="hidden" name="path" value="{esc(rel_path)}">'
            f'<input type="hidden" name="video" value="{esc(video_name)}">'
            f'<button type="submit" class="btn btn-confirm" title="Accept suggested tags">'
            f'\u2714 Accept</button></form> '
            f'<form hx-post="/reject-tags" hx-target="#video-meta" hx-swap="innerHTML" '
            f'style="display:inline;margin:0;padding:0">'
            f'<input type="hidden" name="path" value="{esc(rel_path)}">'
            f'<input type="hidden" name="video" value="{esc(video_name)}">'
            f'<button type="submit" class="btn btn-reject" title="Reject suggested tags">'
            f'\u2718 Reject</button></form> '
        )

    pill_class = 'video-tag-pill suggested' if is_suggested else 'video-tag-pill'
    for i, tag in enumerate(tags_list):
        remaining = ', '.join(t for j, t in enumerate(tags_list) if j != i)
        pieces.append(
            f'<span class="{pill_class}">{esc(tag)}'
            f'<form hx-post="/save-tags" hx-target="#video-meta" hx-swap="innerHTML" '
            f'style="display:inline;margin:0;padding:0">'
            f'<input type="hidden" name="path" value="{esc(rel_path)}">'
            f'<input type="hidden" name="video" value="{esc(video_name)}">'
            f'<input type="hidden" name="tags" value="{esc(remaining)}">'
            f'<button type="submit" class="video-tag-remove" title="Remove tag">\u00d7</button>'
            f'</form></span>'
        )
    # Inline add input
    all_csv = ', '.join(tags_list)
    prefix = (all_csv + ', ') if all_csv else ''
    pieces.append(
        f'<form hx-post="/save-tags" hx-target="#video-meta" hx-swap="innerHTML" '
        f'style="display:inline;margin:0;padding:0" data-prefix="{esc(prefix)}" '
        f'onsubmit="var f=this,i=f.querySelector(&quot;.video-tag-add&quot;);'
        f'f.querySelector(&quot;[name=tags]&quot;).value=f.dataset.prefix+i.value;return true">'
        f'<input type="hidden" name="path" value="{esc(rel_path)}">'
        f'<input type="hidden" name="video" value="{esc(video_name)}">'
        f'<input type="hidden" name="tags" value="">'
        f'<input type="text" class="video-tag-add" placeholder="add tag\u2026">'
        f'</form>'
    )
    pieces.append('</div>')
    return ''.join(pieces)


def render_play_page(data, idx, next_url, prev_url, shuffle_url, is_shuffled, pos_info, tags_map=None, selected_tags=None):
    v = data['videos'][idx]
    video_src = url_for_video(v['path'])
    browse_url = url_for_browse(data['path'], tags=selected_tags)

    body = render_nav(data['path'], data.get('encryptedDir'))
    body += (
        f'<div id="player-area">'
        f'<video id="video" src="{esc(video_src)}" controls playsinline autoplay></video>'
        f'<div id="controls">'
        f'<a class="btn" href="{esc(prev_url)}" title="Previous (p)">\u25C0 Prev</a>'
        f'<span id="now-playing">{esc(v["name"])} ({pos_info})</span>'
        f'<a class="btn" href="{esc(next_url)}" title="Next (n)">Next \u25B6</a>'
        f'<a class="btn{" active" if is_shuffled else ""}" '
        f'href="{esc(shuffle_url)}" title="Shuffle (s)">\u21C5 Shuffle</a>'
    )
    if _config['allow_delete']:
        body += (
            f'<form id="delete-form" hx-post="/delete" hx-confirm="Delete {esc(v["name"])}?">'
            f'<input type="hidden" name="path" value="{esc(v["path"])}">'
            f'<input type="hidden" name="redirect" value="{esc(browse_url)}">'
            f'<button type="submit" class="btn btn-lock" title="Delete (d)">'
            f'\U0001F5D1</button></form>'
        )
    body += '</div></div>'

    if _config['allow_tag']:
        video_entry = tags_map.get(v['name'], {}) if tags_map else {}
        video_tags = video_entry.get('tags', [])
        video_status = video_entry.get('status', 'confirmed')
        body += (
            f'<div class="video-meta" id="video-meta">'
            + render_video_tags_inline(data['path'], v['name'], video_tags, status=video_status)
            + '</div>'
        )

    body += render_file_list(data, current_idx=idx, show_shuffle=False, tags_map=tags_map, selected_tags=selected_tags)

    body += (
        '<script>\n'
        f'const video=document.getElementById("video");\n'
        f'const nextUrl={json.dumps(next_url)};\n'
        f'const prevUrl={json.dumps(prev_url)};\n'
        f'const browseUrl={json.dumps(browse_url)};\n'
        'video.addEventListener("ended",()=>{window.location.href=nextUrl});\n'
        'video.play().catch(()=>{});\n'
        'document.addEventListener("keydown",e=>{\n'
        '  if(e.target.tagName==="INPUT")return;\n'
        '  switch(e.key){\n'
        '    case"n":case"ArrowRight":window.location.href=nextUrl;break;\n'
        '    case"p":case"ArrowLeft":window.location.href=prevUrl;break;\n'
        '    case" ":e.preventDefault();video.paused?video.play():video.pause();break;\n'
        '    case"f":e.preventDefault();document.fullscreenElement?document.exitFullscreen():video.requestFullscreen();break;\n'
        '    case"m":video.muted=!video.muted;break;\n'
        '    case"Escape":window.location.href=browseUrl;break;\n'
        '    case"d":document.querySelector("#delete-form button")?.click();break;\n'
        '  }\n'
        '});\n'
        '</script>'
    )

    return render_page(f'SimpleParty \u2014 {v["name"]}', body)


# --- Video serving ---

def _is_mpegts(path):
    try:
        with open(path, 'rb') as f:
            header = f.read(377)
        return len(header) >= 377 and header[0] == 0x47 and header[188] == 0x47 and header[376] == 0x47
    except OSError:
        return False


def _needs_transcode(path):
    if path.suffix.lower() not in BROWSER_NATIVE:
        return True
    return path.suffix.lower() == '.mp4' and _is_mpegts(path)


def _remux_mpegts(path):
    tmp = path.with_suffix('.tmp.mp4')
    try:
        result = subprocess.run(
            ['ffmpeg', '-fflags', '+genpts', '-i', str(path),
             '-c', 'copy', '-bsf:a', 'aac_adtstoasc',
             '-f', 'mp4', '-loglevel', 'error', '-y', str(tmp)],
            capture_output=True, timeout=300,
        )
        if result.returncode == 0:
            os.replace(str(tmp), str(path))
            return True
        return False
    except (subprocess.TimeoutExpired, OSError):
        return False
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


def _serve_transcoded(handler, path):
    if _config['has_ffmpeg']:
        cmd = [
            'ffmpeg', '-i', str(path), '-c:v', 'copy', '-c:a', 'aac',
            '-movflags', 'frag_keyframe+empty_moov',
            '-f', 'mp4', '-loglevel', 'error', 'pipe:1',
        ]
    else:
        cmd = [
            'cvlc', str(path),
            '--sout', '#transcode{acodec=mpga}:std{access=file,mux=mp4,dst=-}',
            'vlc://quit', '--no-repeat', '--no-loop',
        ]

    handler.send_response(200)
    handler.send_header('Content-Type', 'video/mp4')
    handler.send_header('Transfer-Encoding', 'chunked')
    handler.end_headers()

    if handler.command == 'HEAD':
        return

    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        while True:
            chunk = proc.stdout.read(65536)
            if not chunk:
                break
            handler.wfile.write(f'{len(chunk):x}\r\n'.encode())
            handler.wfile.write(chunk)
            handler.wfile.write(b'\r\n')
        handler.wfile.write(b'0\r\n\r\n')
        proc.wait()
    except (BrokenPipeError, ConnectionResetError):
        proc.kill()
    except Exception:
        if proc.poll() is None:
            proc.kill()


def _stream_range(handler, path, start, length):
    try:
        with open(path, 'rb') as f:
            f.seek(start)
            remaining = length
            while remaining > 0:
                chunk = f.read(min(65536, remaining))
                if not chunk:
                    break
                handler.wfile.write(chunk)
                remaining -= len(chunk)
    except (BrokenPipeError, ConnectionResetError):
        pass


def _stream_file(handler, path):
    try:
        with open(path, 'rb') as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                handler.wfile.write(chunk)
    except (BrokenPipeError, ConnectionResetError):
        pass


# --- HTTP helpers ---

def send_html(handler, content, status=200):
    body = content.encode('utf-8')
    handler.send_response(status)
    handler.send_header('Content-Type', 'text/html; charset=utf-8')
    handler.send_header('Content-Length', str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def send_redirect(handler, url):
    handler.send_response(302)
    handler.send_header('Location', url)
    handler.send_header('Content-Length', '0')
    handler.end_headers()


def send_hx_redirect(handler, url):
    handler.send_response(200)
    handler.send_header('HX-Redirect', url)
    handler.send_header('Content-Length', '0')
    handler.end_headers()


def read_form_body(handler):
    length = int(handler.headers.get('Content-Length', 0))
    body = handler.rfile.read(length).decode('utf-8')
    params = urllib.parse.parse_qs(body)
    return {k: v[0] for k, v in params.items()}


# --- Thumbnail generation ---

def _generate_thumbnails(directory, videos):
    """Background worker: extract thumbnails for videos missing them."""
    from simpleparty.tagger import thumb_path, extract_thumbnail
    try:
        for v in videos:
            tp = thumb_path(directory, v['name'])
            if tp.exists():
                continue
            video_file = Path(directory) / v['name']
            if video_file.exists():
                extract_thumbnail(str(video_file), str(tp))
    finally:
        _config['thumb_jobs'].discard(str(directory))


def _maybe_start_thumbs(directory, videos):
    """Spawn background thumbnail generation if needed and not already running."""
    if not _config['has_ffmpeg'] or not videos:
        return
    dir_str = str(directory)
    if dir_str in _config['thumb_jobs']:
        return
    from simpleparty.tagger import thumb_path
    missing = any(not thumb_path(directory, v['name']).exists() for v in videos)
    if not missing:
        return
    _config['thumb_jobs'].add(dir_str)
    t = threading.Thread(
        target=_generate_thumbnails,
        args=(directory, videos),
        daemon=True,
    )
    t.start()


# --- Route handlers ---

def handle_browse(handler, root):
    params = parse_query(handler.path)
    rel_path = params.get('path', '')
    data = list_directory(root, rel_path)
    if data.get('locked'):
        send_html(handler, render_locked_page(rel_path, data['encryptedDir']))
    elif 'error' in data:
        status = 404 if data['error'] == 'Not found' else 400
        send_html(handler, render_error_page(rel_path, data['error']), status)
    else:
        tags_map = None
        selected_tags = parse_tags_param(params)
        resolved = resolve_path(root, rel_path)
        if _config['allow_tag']:
            from simpleparty.tagger import load_tags
            tags_map = load_tags(resolved)
            data['videos'] = filter_videos_by_tags(data['videos'], tags_map, selected_tags)
        _maybe_start_thumbs(resolved, data['videos'])
        send_html(handler, render_browse_page(data, tags_map=tags_map, selected_tags=selected_tags))


def handle_play(handler, root):
    params = parse_query(handler.path)
    dir_path = params.get('path', '')
    data = list_directory(root, dir_path)

    if data.get('locked'):
        send_html(handler, render_locked_page(dir_path, data['encryptedDir']))
        return

    selected_tags = parse_tags_param(params)
    tags_map = None
    if _config['allow_tag']:
        from simpleparty.tagger import load_tags
        resolved = resolve_path(root, dir_path)
        tags_map = load_tags(resolved)
        data['videos'] = filter_videos_by_tags(data['videos'], tags_map, selected_tags)

    if 'error' in data or not data.get('videos'):
        send_redirect(handler, url_for_browse(dir_path, tags=selected_tags))
        return

    n = len(data['videos'])
    shuffled = params.get('shuffle') == '1'

    if shuffled:
        seed = safe_int(params.get('seed'), random.randint(0, 2**31))
        pos = safe_int(params.get('pos')) % n
        order = shuffle_indices(n, seed)
        idx = order[pos]
        next_pos = (pos + 1) % n
        prev_pos = (pos - 1) % n
        next_url = url_for_play(dir_path, order[next_pos], shuffle=True, seed=seed, pos=next_pos, tags=selected_tags)
        prev_url = url_for_play(dir_path, order[prev_pos], shuffle=True, seed=seed, pos=prev_pos, tags=selected_tags)
        pos_info = f'{pos + 1}/{n}'
        shuffle_url = url_for_play(dir_path, idx, tags=selected_tags)
    else:
        idx = max(0, min(safe_int(params.get('idx')), n - 1))
        next_url = url_for_play(dir_path, (idx + 1) % n, tags=selected_tags)
        prev_url = url_for_play(dir_path, (idx - 1) % n, tags=selected_tags)
        pos_info = f'{idx + 1}/{n}'
        shuffle_params = {'path': dir_path, 'shuffle': '1'}
        if selected_tags:
            shuffle_params['tags'] = ','.join(selected_tags)
        shuffle_url = '/play?' + urllib.parse.urlencode(shuffle_params)

    send_html(handler, render_play_page(data, idx, next_url, prev_url, shuffle_url, shuffled, pos_info, tags_map=tags_map, selected_tags=selected_tags))


def handle_video(handler, root):
    parsed = urllib.parse.urlparse(handler.path)
    rel_path = urllib.parse.unquote(parsed.path[len('/video/'):])
    resolved = resolve_path(root, rel_path)

    if not resolved.is_file():
        handler.send_error(404)
        return

    if _config['allow_transcode'] and _needs_transcode(resolved) and (_config['has_ffmpeg'] or _config['has_vlc']):
        if _is_mpegts(resolved) and _config['has_ffmpeg'] and _remux_mpegts(resolved):
            pass  # file is now a proper MP4, fall through to normal serving
        else:
            _serve_transcoded(handler, resolved)
            return

    file_size = resolved.stat().st_size
    content_type = MIME_TYPES.get(resolved.suffix.lower(), 'application/octet-stream')
    range_header = handler.headers.get('Range')

    if range_header:
        match = re.match(r'bytes=(\d+)-(\d*)', range_header)
        if match:
            start = int(match.group(1))
            end = int(match.group(2)) if match.group(2) else file_size - 1
            end = min(end, file_size - 1)
            if start > end or start >= file_size:
                handler.send_response(416)
                handler.send_header('Content-Range', f'bytes */{file_size}')
                handler.end_headers()
                return
            length = end - start + 1
            handler.send_response(206)
            handler.send_header('Content-Type', content_type)
            handler.send_header('Content-Range', f'bytes {start}-{end}/{file_size}')
            handler.send_header('Content-Length', str(length))
            handler.send_header('Accept-Ranges', 'bytes')
            handler.end_headers()
            if handler.command != 'HEAD':
                _stream_range(handler, resolved, start, length)
            return

    handler.send_response(200)
    handler.send_header('Content-Type', content_type)
    handler.send_header('Content-Length', str(file_size))
    handler.send_header('Accept-Ranges', 'bytes')
    handler.end_headers()
    if handler.command != 'HEAD':
        _stream_file(handler, resolved)


def handle_delete(handler, root):
    if not _config['allow_delete']:
        handler.send_error(403, 'Delete disabled')
        return
    form = read_form_body(handler)
    rel_path = form.get('path', '')
    redirect_url = form.get('redirect')
    resolved = resolve_path(root, rel_path)
    if not resolved.is_file() or not is_video(resolved.name):
        handler.send_error(400, 'Invalid video path')
        return
    try:
        os.remove(resolved)
    except OSError as e:
        handler.send_error(500, str(e))
        return
    if redirect_url:
        send_hx_redirect(handler, redirect_url)
    else:
        handler.send_response(200)
        handler.send_header('Content-Length', '0')
        handler.end_headers()


def handle_unlock(handler, root):
    form = read_form_body(handler)
    encrypted_path = form.get('path', '')
    passphrase = form.get('passphrase', '')
    redirect_url = form.get('redirect', url_for_browse(encrypted_path))
    resolved = resolve_path(root, encrypted_path)
    ok, msg = fscrypt_unlock(resolved, passphrase)
    del passphrase
    if ok:
        send_hx_redirect(handler, redirect_url)
    else:
        send_html(handler, esc(msg or 'Unlock failed'))


def handle_lock(handler, root):
    form = read_form_body(handler)
    path = form.get('path', '')
    redirect_url = form.get('redirect', url_for_browse(''))
    resolved = resolve_path(root, path)
    fscrypt_lock(resolved)
    send_hx_redirect(handler, redirect_url)


def handle_train(handler, root):
    if not _config['allow_tag']:
        handler.send_error(403, 'Tagging not enabled')
        return
    from simpleparty.classifier import train

    form = read_form_body(handler)
    rel_path = form.get('path', '')
    max_frames = int(form.get('frames', '1'))
    resolved = resolve_path(root, rel_path)
    if not resolved.is_dir():
        handler.send_error(400, 'Not a directory')
        return

    resolved_str = str(resolved)
    existing = _config['tag_jobs'].get(resolved_str)
    if existing and existing.get('running'):
        send_hx_redirect(handler, url_for_browse(rel_path))
        return

    progress = {'running': True, 'done': 0, 'total': 0, 'current': '', 'phase': 'preparing'}
    _config['tag_jobs'][resolved_str] = progress

    t = threading.Thread(
        target=train,
        args=(resolved_str,),
        kwargs={'max_frames': max_frames, 'progress': progress},
        daemon=True,
    )
    t.start()
    send_hx_redirect(handler, url_for_browse(rel_path))


def handle_suggest(handler, root):
    if not _config['allow_tag']:
        handler.send_error(403, 'Tagging not enabled')
        return
    from simpleparty.classifier import suggest_for_directory
    from simpleparty.tagger import model_path as _model_path

    form = read_form_body(handler)
    rel_path = form.get('path', '')
    resolved = resolve_path(root, rel_path)
    if not resolved.is_dir():
        handler.send_error(400, 'Not a directory')
        return

    mp = _model_path(resolved)
    model_path = str(mp)
    if not mp.exists():
        handler.send_error(400, 'No trained model found. Train first.')
        return

    resolved_str = str(resolved)
    existing = _config['tag_jobs'].get(resolved_str)
    if existing and existing.get('running'):
        send_hx_redirect(handler, url_for_browse(rel_path))
        return

    progress = {'running': True, 'done': 0, 'total': 0, 'current': '', 'phase': 'suggesting'}
    _config['tag_jobs'][resolved_str] = progress

    t = threading.Thread(
        target=suggest_for_directory,
        args=(resolved_str, model_path),
        kwargs={'progress': progress},
        daemon=True,
    )
    t.start()
    send_hx_redirect(handler, url_for_browse(rel_path))


def handle_confirm_tags(handler, root):
    if not _config['allow_tag']:
        handler.send_error(403, 'Tagging not enabled')
        return
    from simpleparty.tagger import load_tags, save_tags

    form = read_form_body(handler)
    rel_path = form.get('path', '')
    video_name = form.get('video', '')
    resolved = resolve_path(root, rel_path)

    if not resolved.is_dir() or not video_name:
        handler.send_error(400, 'Invalid request')
        return

    all_tags = load_tags(resolved)
    entry = all_tags.get(video_name, {})
    entry['status'] = 'confirmed'
    from datetime import datetime, timezone
    entry['confirmed_at'] = datetime.now(timezone.utc).isoformat()
    all_tags[video_name] = entry
    save_tags(resolved, all_tags)

    tags_list = entry.get('tags', [])
    send_html(handler, render_video_tags_inline(rel_path, video_name, tags_list, status='confirmed'))


def handle_confirm_all(handler, root):
    if not _config['allow_tag']:
        handler.send_error(403, 'Tagging not enabled')
        return
    from simpleparty.tagger import load_tags, save_tags

    form = read_form_body(handler)
    rel_path = form.get('path', '')
    resolved = resolve_path(root, rel_path)

    if not resolved.is_dir():
        handler.send_error(400, 'Invalid request')
        return

    all_tags = load_tags(resolved)
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc).isoformat()
    count = 0
    for entry in all_tags.values():
        if entry.get('status') == 'suggested':
            entry['status'] = 'confirmed'
            entry['confirmed_at'] = now
            count += 1
    save_tags(resolved, all_tags)
    send_hx_redirect(handler, url_for_browse(rel_path))


def handle_reject_tags(handler, root):
    if not _config['allow_tag']:
        handler.send_error(403, 'Tagging not enabled')
        return
    from simpleparty.tagger import load_tags, save_tags

    form = read_form_body(handler)
    rel_path = form.get('path', '')
    video_name = form.get('video', '')
    resolved = resolve_path(root, rel_path)

    if not resolved.is_dir() or not video_name:
        handler.send_error(400, 'Invalid request')
        return

    all_tags = load_tags(resolved)
    if video_name in all_tags:
        del all_tags[video_name]
        save_tags(resolved, all_tags)

    send_html(handler, render_video_tags_inline(rel_path, video_name, []))


def handle_tag_status(handler, root):
    if not _config['allow_tag']:
        send_html(handler, '')
        return
    params = parse_query(handler.path)
    rel_path = params.get('path', '')
    resolved = str(resolve_path(root, rel_path))
    status_url = f'/tag-status?{urllib.parse.urlencode({"path": rel_path})}'
    path_param = esc(rel_path)

    progress = _config['tag_jobs'].get(resolved)

    # OOB swap to keep train button in sync
    def train_btn_oob(busy):
        btn = _render_train_btn(path_param, busy)
        return btn.replace('id="train-form"', 'id="train-form" hx-swap-oob="true"', 1)

    def wrap(inner, poll=None, active=False):
        if poll:
            return (
                f'<div hx-get="{status_url}" hx-trigger="{poll}" '
                f'hx-swap="outerHTML" class="tag-progress-panel'
                f'{" active" if active else ""}" id="tag-progress">'
                f'{inner}</div>'
            )
        return f'<div class="tag-progress-panel" id="tag-progress">{inner}</div>'

    if not progress:
        send_html(handler, wrap('', poll='every 10s'))
        return

    if progress.get('error'):
        send_html(handler,
            wrap(f'<span class="tag-error">\u274C {esc(progress["error"])}</span>')
            + train_btn_oob(False))
        return

    if not progress.get('running'):
        if progress.get('phase') == 'done':
            msg = esc(progress.get('current', 'Done'))
            suggest = (
                f'<form hx-post="/suggest" style="display:inline">'
                f'<input type="hidden" name="path" value="{path_param}">'
                f'<button class="btn">\U0001F3F7 Suggest tags</button>'
                f'</form>'
            )
            send_html(handler,
                wrap(f'<span class="tag-done">\u2705 {msg} {suggest}</span>')
                + train_btn_oob(False))
        else:
            send_html(handler, wrap('', poll='every 10s'))
        return

    phase = progress.get('phase', '')
    done = progress.get('done', 0)
    total = progress.get('total', 0)
    current = progress.get('current', '')

    pct = int(done * 100 / total) if total > 0 else 0
    bar = (
        f'<div class="tag-progress-bar-wrap">'
        f'<div class="tag-progress-bar" style="width:{pct}%"></div>'
        f'</div>'
    ) if total > 0 else ''

    phase_label = phase.replace('_', ' ').replace('(', '(').title()
    text = f'{done}/{total}' if total else ''
    if current:
        text += f' \u2014 {esc(current)}' if text else esc(current)
    text += '\u2026'

    inner = (
        f'<span class="tag-progress-phase">{esc(phase_label)}</span>'
        f'{bar}'
        f'<span class="tag-progress-text">{text}</span>'
    )
    send_html(handler,
        wrap(inner, poll='every 2s', active=True)
        + train_btn_oob(True))


def handle_save_tags(handler, root):
    if not _config['allow_tag']:
        handler.send_error(403, 'Tagging not enabled')
        return
    from simpleparty.tagger import load_tags, save_tags

    form = read_form_body(handler)
    rel_path = form.get('path', '')
    video_name = form.get('video', '')
    raw_tags = form.get('tags', '')

    resolved = resolve_path(root, rel_path)
    if not resolved.is_dir() or not video_name:
        handler.send_error(400, 'Invalid request')
        return

    tags_list = [t.strip() for t in raw_tags.split(',') if t.strip()]

    all_tags = load_tags(resolved)
    entry = all_tags.get(video_name, {})
    entry['tags'] = tags_list
    entry['status'] = 'confirmed'
    from datetime import datetime, timezone
    entry['tagged_at'] = datetime.now(timezone.utc).isoformat()
    all_tags[video_name] = entry
    save_tags(resolved, all_tags)

    # Return updated pill HTML for HTMX swap
    send_html(handler, render_video_tags_inline(rel_path, video_name, tags_list))


def handle_thumb(handler, root):
    """Serve a thumbnail JPEG from .simpleparty/thumbs/."""
    raw = urllib.parse.urlparse(handler.path).path
    rel = raw[len('/thumb/'):]  # strip prefix
    rel = urllib.parse.unquote(rel)
    if not rel:
        handler.send_error(404)
        return
    # rel is "dir/subdir/video.mp4" — thumb is at dir/subdir/.simpleparty/thumbs/video.mp4.jpg
    from simpleparty.tagger import thumb_path
    video_dir = Path(root) / Path(rel).parent
    video_name = Path(rel).name
    tp = thumb_path(str(video_dir), video_name)
    if not tp.exists():
        handler.send_error(404)
        return
    data = tp.read_bytes()
    handler.send_response(200)
    handler.send_header('Content-Type', 'image/jpeg')
    handler.send_header('Content-Length', str(len(data)))
    handler.send_header('Cache-Control', 'public, max-age=3600')
    handler.end_headers()
    handler.wfile.write(data)


# --- Server ---

class RequestHandler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def __init__(self, root, *args, **kwargs):
        self.root = root
        super().__init__(*args, **kwargs)

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path == '/' or path == '/browse':
            handle_browse(self, self.root)
        elif path == '/play':
            handle_play(self, self.root)
        elif path.startswith('/video/'):
            handle_video(self, self.root)
        elif path == '/tag-status':
            handle_tag_status(self, self.root)
        elif path.startswith('/thumb/'):
            handle_thumb(self, self.root)
        else:
            self.send_error(404)

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path == '/delete':
            handle_delete(self, self.root)
        elif path == '/unlock':
            handle_unlock(self, self.root)
        elif path == '/lock':
            handle_lock(self, self.root)
        elif path == '/train':
            handle_train(self, self.root)
        elif path == '/suggest':
            handle_suggest(self, self.root)
        elif path == '/confirm-tags':
            handle_confirm_tags(self, self.root)
        elif path == '/confirm-all':
            handle_confirm_all(self, self.root)
        elif path == '/reject-tags':
            handle_reject_tags(self, self.root)
        elif path == '/save-tags':
            handle_save_tags(self, self.root)
        else:
            self.send_error(404)

    def do_HEAD(self):
        path = urllib.parse.urlparse(self.path).path
        if path.startswith('/video/'):
            handle_video(self, self.root)
        else:
            self.do_GET()


class ThreadedServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


def main():
    parser = argparse.ArgumentParser(
        description='SimpleParty - Easily enjoy your private video collection',
    )
    parser.add_argument('root', nargs='?', default='.', help='Root directory to serve (default: current directory)')
    parser.add_argument('-p', '--port', type=int, default=1312, help='Port (default: 1312)')
    parser.add_argument('-b', '--bind', default='0.0.0.0', help='Bind address (default: 0.0.0.0)')
    parser.add_argument('--no-delete', action='store_true', help='Disable video deletion')
    parser.add_argument('--no-transcode', action='store_true', help='Disable ffmpeg/VLC transcoding')
    parser.add_argument('--no-tag', action='store_true', help='Disable all tagging features')
    args = parser.parse_args()

    root = str(Path(args.root).resolve())
    if not Path(root).is_dir():
        print(f'Error: {root} is not a directory', file=sys.stderr)
        raise SystemExit(1)

    _config['has_ffmpeg'] = shutil.which('ffmpeg') is not None
    _config['has_vlc'] = shutil.which('cvlc') is not None
    _config['allow_delete'] = not args.no_delete
    _config['allow_transcode'] = not args.no_transcode

    _config['root'] = root
    if args.no_tag:
        _config['allow_tag'] = False

    handler = partial(RequestHandler, root)
    server = ThreadedServer((args.bind, args.port), handler)

    features = []
    if _config['allow_transcode']:
        if _config['has_ffmpeg']:
            features.append('transcode: ffmpeg')
        elif _config['has_vlc']:
            features.append('transcode: vlc')
    if _config['allow_delete']:
        features.append('delete: on')
    if shutil.which('fscrypt'):
        features.append('fscrypt: on')
    has_torch = False
    if _config['allow_tag']:
        try:
            import torch
            has_torch = True
            features.append('tag: on')
        except ImportError:
            features.append('tag: on (tagger unavailable)')

    from simpleparty import __version__
    url = f'http://{args.bind}:{args.port}'
    print(f'SimpleParty {__version__} serving {root}')
    print(f'  {url}')
    if features:
        print(f'  [{", ".join(features)}]')
    if _config['allow_tag'] and not has_torch:
        print(f'  To train a tagger: uvx simpleparty[classifier]=={__version__}')

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nShutting down.')
        server.shutdown()


if __name__ == '__main__':
    main()
