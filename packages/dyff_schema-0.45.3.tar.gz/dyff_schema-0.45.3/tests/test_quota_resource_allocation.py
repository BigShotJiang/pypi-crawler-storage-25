# SPDX-FileCopyrightText: 2024 UL Research Institutes
# SPDX-License-Identifier: Apache-2.0
"""Unit tests for resource_allocation() methods used by quota system."""

from datetime import datetime

from dyff.schema.platform import (
    Accelerator,
    AcceleratorGPU,
    Analysis,
    Audit,
    DataSchema,
    Dataset,
    Evaluation,
    ForeignInferenceService,
    InferenceInterface,
    InferenceSession,
    InferenceSessionSpec,
    Measurement,
    Model,
    Report,
    SafetyCase,
)


def _make_inference_session(*, replicas: int = 1, accelerator=None) -> InferenceSession:
    return InferenceSession(
        id="test-session-id",
        account="test-account",
        creationTime=datetime.now(),
        status="Created",
        inferenceService=ForeignInferenceService(
            id="test-service-id",
            account="test-account",
            name="test-service",
            interface=InferenceInterface(
                endpoint="http://test/infer",
                outputSchema=DataSchema(arrowSchema="test-schema"),
            ),
        ),
        replicas=replicas,
        accelerator=accelerator,
    )


def _make_evaluation(
    *, replications: int = 1, session_replicas: int = 1, session_accelerator=None
) -> Evaluation:
    return Evaluation(
        id="test-eval-id",
        account="test-account",
        creationTime=datetime.now(),
        status="Created",
        dataset="test-dataset-id",
        inferenceSession=InferenceSessionSpec(
            inferenceService=ForeignInferenceService(
                id="test-service-id",
                account="test-account",
                name="test-service",
                interface=InferenceInterface(
                    endpoint="http://test/infer",
                    outputSchema=DataSchema(arrowSchema="test-schema"),
                ),
            ),
            replicas=session_replicas,
            accelerator=session_accelerator,
        ),
        replications=replications,
    )


def _make_analysis() -> Analysis:
    return Analysis.model_construct(
        id="test-analysis-id",
        account="test-account",
        creationTime=datetime.now(),
        status="Created",
    )


def _make_measurement() -> Measurement:
    return Measurement.model_construct(
        id="test-measurement-id",
        account="test-account",
        creationTime=datetime.now(),
        status="Created",
    )


def _make_model() -> Model:
    return Model.model_construct(
        id="test-model-id",
        account="test-account",
        creationTime=datetime.now(),
        status="Created",
    )


def _make_audit() -> Audit:
    return Audit.model_construct(
        id="test-audit-id",
        account="test-account",
        creationTime=datetime.now(),
        status="Created",
    )


def _make_dataset() -> Dataset:
    return Dataset.model_construct(
        id="test-dataset-id",
        account="test-account",
        creationTime=datetime.now(),
        status="Created",
    )


def _make_report() -> Report:
    return Report.model_construct(
        id="test-report-id",
        account="test-account",
        creationTime=datetime.now(),
        status="Created",
    )


def _make_safetycase() -> SafetyCase:
    return SafetyCase.model_construct(
        id="test-safetycase-id",
        account="test-account",
        creationTime=datetime.now(),
        status="Created",
    )


class TestGPUWorkflowsIncludeAdmissionSlot:
    def test_inference_session_with_gpu(self):
        session = _make_inference_session(
            replicas=4,
            accelerator=Accelerator(
                kind="GPU",
                gpu=AcceleratorGPU(hardwareTypes=["nvidia.com/gpu-t4"], count=2),
            ),
        )

        alloc = session.resource_allocation()

        assert alloc is not None
        assert alloc.quantities["nvidia.com/gpu-t4"] == "8"
        assert alloc.quantities["workflows.dyff.io/admitted"] == "1"

    def test_evaluation_with_gpu(self):
        eval = _make_evaluation(
            replications=5,  # replications don't affect hardware
            session_accelerator=Accelerator(
                kind="GPU",
                gpu=AcceleratorGPU(hardwareTypes=["nvidia.com/gpu-a100"], count=2),
            ),
        )

        alloc = eval.resource_allocation()

        assert alloc is not None
        assert alloc.quantities["nvidia.com/gpu-a100"] == "2"
        assert alloc.quantities["workflows.dyff.io/admitted"] == "1"


class TestReplicasMultiplier:
    def test_inference_session_multiplies_by_replicas(self):
        session = _make_inference_session(
            replicas=3,
            accelerator=Accelerator(
                kind="GPU",
                gpu=AcceleratorGPU(hardwareTypes=["nvidia.com/gpu-l4"], count=4),
            ),
        )

        alloc = session.resource_allocation()

        assert alloc is not None
        assert alloc.quantities["nvidia.com/gpu-l4"] == "12"

    def test_evaluation_replications_dont_affect_gpu_count(self):
        eval = _make_evaluation(
            replications=10,  # replications rerun data, don't multiply hardware
            session_accelerator=Accelerator(
                kind="GPU",
                gpu=AcceleratorGPU(hardwareTypes=["nvidia.com/gpu-t4"], count=1),
            ),
        )

        alloc = eval.resource_allocation()

        assert alloc is not None
        assert alloc.quantities["nvidia.com/gpu-t4"] == "1"

    def test_inference_session_single_replica(self):
        session = _make_inference_session(
            replicas=1,
            accelerator=Accelerator(
                kind="GPU",
                gpu=AcceleratorGPU(hardwareTypes=["nvidia.com/gpu-a100"], count=8),
            ),
        )

        alloc = session.resource_allocation()

        assert alloc is not None
        assert alloc.quantities["nvidia.com/gpu-a100"] == "8"

    def test_evaluation_multiplies_replicas_not_replications(self):
        eval = _make_evaluation(
            replications=2,  # ignored for hardware
            session_replicas=2,
            session_accelerator=Accelerator(
                kind="GPU",
                gpu=AcceleratorGPU(hardwareTypes=["nvidia.com/gpu-t4"], count=2),
            ),
        )

        alloc = eval.resource_allocation()

        assert alloc is not None
        assert alloc.quantities["nvidia.com/gpu-t4"] == "4"  # 2 replicas × 2 GPUs


class TestCPUOnlyWorkflowDefaults:
    def test_inference_session(self):
        session = _make_inference_session(replicas=2, accelerator=None)

        alloc = session.resource_allocation()

        assert alloc is not None
        assert alloc.quantities["cpu"] == "1"
        assert alloc.quantities["memory"] == "1Gi"
        assert alloc.quantities["workflows.dyff.io/admitted"] == "1"

    def test_evaluation(self):
        eval = _make_evaluation(replications=5, session_accelerator=None)

        alloc = eval.resource_allocation()

        assert alloc is not None
        assert alloc.quantities["cpu"] == "2"
        assert alloc.quantities["memory"] == "2Gi"
        assert alloc.quantities["workflows.dyff.io/admitted"] == "1"

    def test_measurement(self):
        alloc = _make_measurement().resource_allocation()

        assert alloc is not None
        assert alloc.quantities["cpu"] == "2"
        assert alloc.quantities["memory"] == "2Gi"
        assert alloc.quantities["workflows.dyff.io/admitted"] == "1"

    def test_model(self):
        alloc = _make_model().resource_allocation()

        assert alloc is not None
        assert alloc.quantities["cpu"] == "1"
        assert alloc.quantities["memory"] == "1Gi"
        assert alloc.quantities["workflows.dyff.io/admitted"] == "1"

    def test_audit(self):
        alloc = _make_audit().resource_allocation()

        assert alloc is not None
        assert alloc.quantities["cpu"] == "2"
        assert alloc.quantities["memory"] == "2Gi"
        assert alloc.quantities["workflows.dyff.io/admitted"] == "1"

    def test_dataset(self):
        alloc = _make_dataset().resource_allocation()

        assert alloc is not None
        assert alloc.quantities["cpu"] == "1"
        assert alloc.quantities["memory"] == "1Gi"
        assert alloc.quantities["workflows.dyff.io/admitted"] == "1"

    def test_report(self):
        alloc = _make_report().resource_allocation()

        assert alloc is not None
        assert alloc.quantities["cpu"] == "2"
        assert alloc.quantities["memory"] == "2Gi"
        assert alloc.quantities["workflows.dyff.io/admitted"] == "1"

    def test_safetycase(self):
        alloc = _make_safetycase().resource_allocation()

        assert alloc is not None
        assert alloc.quantities["cpu"] == "1"
        assert alloc.quantities["memory"] == "1Gi"
        assert alloc.quantities["workflows.dyff.io/admitted"] == "1"


class TestEvaluationSessionReference:
    def test_only_consumes_admission_slot(self):
        eval = _make_evaluation()
        eval.inferenceSessionReference = "existing-session-id"

        alloc = eval.resource_allocation()

        assert alloc is not None
        assert alloc.quantities == {"workflows.dyff.io/admitted": "1"}


class TestMultipleHardwareTypes:
    def test_inference_session_allocates_for_each_type(self):
        session = _make_inference_session(
            replicas=2,
            accelerator=Accelerator(
                kind="GPU",
                gpu=AcceleratorGPU(
                    hardwareTypes=["nvidia.com/gpu-t4", "nvidia.com/gpu-a100"], count=4
                ),
            ),
        )

        alloc = session.resource_allocation()

        assert alloc is not None
        assert alloc.quantities["nvidia.com/gpu-t4"] == "8"
        assert alloc.quantities["nvidia.com/gpu-a100"] == "8"
        assert alloc.quantities["workflows.dyff.io/admitted"] == "1"
