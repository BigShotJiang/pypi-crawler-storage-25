# This file is part of datacube-ows, part of the Open Data Cube project.
# See https://opendatacube.org for more information.
#
# Copyright (c) 2017-2024 OWS Contributors
# SPDX-License-Identifier: Apache-2.0

"""Gunicorn config for Prometheus internal metrics"""

import os


def child_exit(server, worker) -> None:
    if os.environ.get("PROMETHEUS_MULTIPROC_DIR", False):
        from prometheus_flask_exporter.multiprocess import (
            GunicornInternalPrometheusMetrics,
        )

        GunicornInternalPrometheusMetrics.mark_process_dead_on_child_exit(worker.pid)
