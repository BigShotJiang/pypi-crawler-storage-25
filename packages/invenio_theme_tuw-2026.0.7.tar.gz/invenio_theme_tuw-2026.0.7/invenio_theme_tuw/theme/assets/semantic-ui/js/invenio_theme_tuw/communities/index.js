/*
 * This file is part of Invenio.
 * Copyright (C) 2016-2021 CERN.
 * Copyright (C) 2023 Northwestern University.
 * Copyright (C) 2026 TU Wien.
 *
 * Invenio is free software; you can redistribute it and/or modify it
 * under the terms of the MIT License; see LICENSE file for more details.
 */

import React from "react";
import ReactDOM from "react-dom";
import { i18next } from "@translations/invenio_communities/i18next";

import CommunitiesCardGroup from "@js/invenio_communities/community/CommunitiesCardGroup";

const themedCommunitiesContainer = document.getElementById("themed-communities");

if (themedCommunitiesContainer) {
  ReactDOM.render(
    <CommunitiesCardGroup
      fetchDataUrl="/api/communities?q=theme:*&sort=newest&page=1&size=5"
      emptyMessage={i18next.t("There are no themed communities yet.")}
      defaultLogo="/static/images/square-placeholder.png"
    />,
    themedCommunitiesContainer
  );
}
