#!/bin/bash


large_bump=0
while getopts "bh" opt; do
    case "${opt}" in
        b)
            large_bump=1
            ;;
        h)
            echo "usage: ${0} [-b]"
            echo "calculate the next version number and create a release commit and tag"
            exit 0
            ;;
        *)
            echo "ignoring unknown option: ${opt}"
            ;;
    esac
done


# (0) Sanity checks
# -----------------

init_file=$(compgen -G "invenio_*/__init__.py" | head -n 1)
changes_file=CHANGES.rst
if [[ ! -f "${init_file}" ]]; then
    echo >&2 "cannot find package-level __init__.py"
    exit 1
elif [[ ! -f "${changes_file}" ]]; then
    echo >&2 "cannot find CHANGES.rst"
    exit 1
fi

# safety check if the current commit already has a tag
if current_tag="$(git describe --tags --exact-match 2> /dev/null)"; then
    echo >&2 "already tagged: ${current_tag}"
    exit 1
fi


# (1) Gather information
# ----------------------

# print version tags sorted by tagger date (newest first)
latest_tag="$(git tag --format="%(tag)" --sort=-taggerdate --list "v*" | head -n 1)"
current_version=$(sed --silent --regexp-extended 's/__version__\s+=\s+"([0-9]+\.[0-9]+\.[0-9]+)"/\1/p' "${init_file}")
if [[ "v${current_version}" != "${latest_tag}" ]]; then
    echo "mismatch between latest tag '${latest_tag}' and current version '${current_version}'"
    exit 2
fi


# (2) Calculate updates
# ---------------------

# parse the current version, and perform version bumping magic
IFS="." read -r year minor patch <<< "${current_version}"

new_version=
current_year="$(date +%Y)"
if [[ "${current_year}" != "${year}" ]]; then
    # for the first release in the new year we always go YYYY.0.0
    new_version="${current_year}.0.0"

elif [[ "${large_bump}" -eq 1 ]]; then
    new_version="${current_year}.$(( minor + 1 )).0"

else
    new_version="${current_year}.${minor}.$(( patch + 1 ))"

fi

# calculate the new tag
new_tag="v${new_version}"
new_message="Release: ${new_tag}"


# (3) Write changes
# -----------------

# update the package version in the source code
sed --regexp-extended --in-place "s/__version__\s+=\s+\"([0-9]+\.[0-9]+\.[0-9]+)\"/__version__ = \"${new_version}\"/" "${init_file}"

# update the changelog with formatted commit messages since the latest tag
# (only insert the new lines above the latest release's notes)
sed --regexp-extended --in-place "/^Version\s+v?${year}\.${minor}\.${patch}+\s+\(released .+\)$/{
    e echo 'Version v${new_version} (released $(date -I))\n'
    e git log --pretty='- %s' ${latest_tag}..
    e echo '\n'
}" "${changes_file}"

# create the new commit and tag
git add "${changes_file}" "${init_file}"
git commit --quiet --message "Bump version to ${new_tag}"
git tag --annotate --message "${new_message}" "${new_tag}"
echo "${new_tag}"
