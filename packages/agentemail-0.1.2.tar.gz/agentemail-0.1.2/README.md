# agentemail

Official Python SDK for the [AgentEmail](https://agentemail.co) API.

Create and manage email inboxes programmatically for your AI agents and applications.

## Installation

```bash
pip install agentemail
```

## Quick Start

```python
from agentemail import AgentemailApi

client = AgentemailApi(api_key="aem_your_api_key_here")

# List your inboxes
inboxes = client.sdk.sdk_list_inboxes()
print(inboxes.data)

# Create a new inbox
inbox = client.sdk.sdk_create_inbox(name="hello")
print(inbox.name)  # "hello"
# Full address: hello@agentemail.co

# List email threads
threads = client.sdk.sdk_list_threads(inbox.id)
for thread in threads.data:
    print(thread.subject, thread.message_count)

# Get a full thread with all messages
thread = client.sdk.sdk_get_thread(inbox.id, threads.data[0].id)
for message in (thread.messages or []):
    print(message.from_address, message.body_text)

# Check usage vs plan limits
usage = client.sdk.sdk_get_usage()
print(usage)
```

## Async Usage

```python
import asyncio
from agentemail import AsyncAgentemailApi

async def main():
    client = AsyncAgentemailApi(api_key="aem_your_api_key_here")
    inboxes = await client.sdk.sdk_list_inboxes()
    print(inboxes.data)

asyncio.run(main())
```

## Authentication

Generate an API key from your [AgentEmail dashboard](https://app.agentemail.co/api-keys).

```python
import os
from agentemail import AgentemailApi

client = AgentemailApi(api_key=os.environ["AGENTEMAIL_API_KEY"])
```

## API Reference

### Inboxes

| Method | Description |
|--------|-------------|
| `client.sdk.sdk_list_inboxes(limit=None, offset=None)` | List all your inboxes (paginated) |
| `client.sdk.sdk_create_inbox(name=...)` | Create a new inbox |

### Emails & Threads

| Method | Description |
|--------|-------------|
| `client.sdk.sdk_list_threads(inbox_id, limit=None, offset=None, unread_only=None)` | List email threads for an inbox |
| `client.sdk.sdk_get_thread(inbox_id, thread_id, mark_read=None)` | Get a thread with all messages |

### Usage

| Method | Description |
|--------|-------------|
| `client.sdk.sdk_get_usage()` | Get current usage vs plan limits |

## Links

- [Documentation](https://agentemail.co/docs)
- [Dashboard](https://app.agentemail.co)
- [GitHub](https://github.com/mbaiswar/agentemailpy)

## License

MIT
