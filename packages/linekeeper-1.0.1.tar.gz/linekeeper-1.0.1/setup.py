# setup.py mínimo para compatibilidad con herramientas antiguas
# La configuración principal está en pyproject.toml
from setuptools import setup
setup()