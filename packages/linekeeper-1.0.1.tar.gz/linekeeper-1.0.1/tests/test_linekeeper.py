#!/usr/bin/env python3
"""
Tests unitarios para LineKeeper
"""

import unittest
import sys
import os

# Agregar el directorio padre al path para poder importar linekeeper
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from linekeeper import numerar_lineas, limpiar_respuesta, extraer_referencias, detectar_idioma


class TestNumerarLineas(unittest.TestCase):
    """Pruebas para la función numerar_lineas"""
    
    def test_lineas_basicas(self):
        """Caso básico: líneas simples"""
        texto = "Linea 1\nLinea 2\nLinea 3"
        resultado = numerar_lineas(texto)
        esperado = "[L001] Linea 1\n[L002] Linea 2\n[L003] Linea 3"
        self.assertEqual(resultado, esperado)
    
    def test_lineas_con_espacios(self):
        """Líneas con espacios al inicio"""
        texto = "  Linea con espacios\n    Mas espacios"
        resultado = numerar_lineas(texto)
        esperado = "[L001]   Linea con espacios\n[L002]     Mas espacios"
        self.assertEqual(resultado, esperado)
    
    def test_lineas_vacias_sin_marcador(self):
        """Líneas vacías no deben tener marcador (por defecto)"""
        texto = "Linea 1\n\nLinea 3\n\n\nLinea 6"
        resultado = numerar_lineas(texto, solo_no_vacias=True)
        esperado = "[L001] Linea 1\n\n[L003] Linea 3\n\n\n[L006] Linea 6"
        self.assertEqual(resultado, esperado)
    
    def test_incluir_marcador_en_vacias(self):
        """Incluir marcador en líneas vacías cuando se solicita"""
        texto = "Linea 1\n\nLinea 3"
        resultado = numerar_lineas(texto, solo_no_vacias=False)
        esperado = "[L001] Linea 1\n[L002] \n[L003] Linea 3"
        self.assertEqual(resultado, esperado)
    
    def test_inicio_personalizado(self):
        """Número de línea inicial personalizado"""
        texto = "Primera\nSegunda"
        resultado = numerar_lineas(texto, inicio=10)
        esperado = "[L010] Primera\n[L011] Segunda"
        self.assertEqual(resultado, esperado)
    
    def test_inicio_muy_alto(self):
        """Número de línea inicial muy alto (4 dígitos)"""
        texto = "Solo una"
        resultado = numerar_lineas(texto, inicio=1000)
        esperado = "[L1000] Solo una"
        self.assertEqual(resultado, esperado)
    
    def test_texto_vacio(self):
        """Texto vacío debe devolver cadena vacía"""
        texto = ""
        resultado = numerar_lineas(texto)
        esperado = ""
        self.assertEqual(resultado, esperado)
    
    def test_solo_lineas_vacias(self):
        """Solo líneas vacías sin marcadores"""
        texto = "\n\n\n"
        resultado = numerar_lineas(texto, solo_no_vacias=True)
        esperado = "\n\n\n"
        self.assertEqual(resultado, esperado)
    
    def test_caracteres_unicode(self):
        """Caracteres Unicode deben preservarse"""
        texto = "ñandú\ncafé\n😊 emoji\nárbol\nniño"
        resultado = numerar_lineas(texto)
        lineas = resultado.split('\n')
        self.assertTrue("[L001] ñandú" in lineas[0])
        self.assertTrue("[L002] café" in lineas[1])
        self.assertTrue("[L003] 😊 emoji" in lineas[2])


class TestLimpiarRespuesta(unittest.TestCase):
    """Pruebas para la función limpiar_respuesta"""
    
    def test_limpiar_marcadores_simples(self):
        """Eliminar marcadores [Lxxx] básicos"""
        respuesta = "En [L005] hay un error. Revisa [L012] también."
        resultado = limpiar_respuesta(respuesta)
        esperado = "En  hay un error. Revisa  también."
        self.assertEqual(resultado, esperado)
    
    def test_sin_marcadores(self):
        """Respuesta sin marcadores no debe cambiar"""
        respuesta = "Esto es una respuesta normal sin marcadores"
        resultado = limpiar_respuesta(respuesta)
        self.assertEqual(resultado, respuesta)
    
    def test_marcadores_varios_digitos(self):
        """Marcadores con 2, 3 y 4 dígitos"""
        respuesta = "Líneas: [L01], [L123], [L9999]"
        resultado = limpiar_respuesta(respuesta)
        esperado = "Líneas: , , "
        # El espacio después del marcador también se elimina
        self.assertEqual(resultado, esperado)
    
    def test_marcadores_pegados(self):
        """Marcadores sin espacio después"""
        respuesta = "[L001]inicio sin espacio"
        resultado = limpiar_respuesta(respuesta)
        esperado = "inicio sin espacio"
        self.assertEqual(resultado, esperado)


class TestExtraerReferencias(unittest.TestCase):
    """Pruebas para la función extraer_referencias"""
    
    def test_extraer_una_referencia(self):
        """Extraer una sola referencia"""
        respuesta = "El error está en [L042]"
        resultado = extraer_referencias(respuesta)
        esperado = ['042']
        self.assertEqual(resultado, esperado)
    
    def test_extraer_multiples_referencias(self):
        """Extraer múltiples referencias"""
        respuesta = "[L001] y [L123] y [L999] y [L005]"
        resultado = extraer_referencias(respuesta)
        esperado = ['001', '123', '999', '005']
        self.assertEqual(resultado, esperado)
    
    def test_sin_referencias(self):
        """Respuesta sin referencias debe devolver lista vacía"""
        respuesta = "No hay números de línea aquí"
        resultado = extraer_referencias(respuesta)
        esperado = []
        self.assertEqual(resultado, esperado)
    
    def test_no_confundir_con_numeros_normales(self):
        """No debe extraer números que no están en formato [Lxxx]"""
        respuesta = "El número 123 no es una referencia, pero [L123] sí"
        resultado = extraer_referencias(respuesta)
        esperado = ['123']
        self.assertEqual(resultado, esperado)


class TestDetectarIdioma(unittest.TestCase):
    """Pruebas para la función detectar_idioma"""
    
    def test_idioma_siempre_devuelve_algo(self):
        """Siempre debe devolver un string (idioma por defecto)"""
        idioma = detectar_idioma()
        self.assertIsInstance(idioma, str)
        self.assertIn(idioma, ['es', 'en', 'fr', 'zh', 'de', 'ja'])
    
    def test_idioma_no_vacio(self):
        """El idioma no debe ser cadena vacía"""
        idioma = detectar_idioma()
        self.assertTrue(len(idioma) > 0)


class TestIntegracion(unittest.TestCase):
    """Pruebas de integración (casos de uso reales)"""
    
    def test_flujo_completo_numerar_y_limpiar(self):
        """Simular: numerar código, enviar a IA, limpiar respuesta"""
        # 1. Código original
        codigo = "def suma(a, b):\n    return a + b"
        
        # 2. Numerar líneas
        numerado = numerar_lineas(codigo)
        esperado = "[L001] def suma(a, b):\n[L002]     return a + b"
        self.assertEqual(numerado, esperado)
        
        # 3. Simular respuesta de IA que referencia líneas
        respuesta_ia = "En [L002] hay un error. Cambia 'return a + b' por 'return a + b + 1'"
        
        # 4. Extraer referencias
        referencias = extraer_referencias(respuesta_ia)
        self.assertEqual(referencias, ['002'])
        
        # 5. Limpiar respuesta para el usuario
        respuesta_limpia = limpiar_respuesta(respuesta_ia)
        esperado_limpio = "En  hay un error. Cambia 'return a + b' por 'return a + b + 1'"
        self.assertEqual(respuesta_limpia, esperado_limpio)
    
    def test_ejemplo_archivo_entrenamiento(self):
        """Caso real: el archivo Entrenamiento.cs que usamos en la conversación"""
        codigo = """// Este en un Archivo de entrenamiento para DeepSeek, 
para que logre recordar el contexto de codigo y las lineas de forma correcta 
o de lo contrario realizaremos una aplicacion que sirva de intermediario para lograrlo.
//
Cafe
Pimienta
Libro
Registro
Tecnologia
DeepSeek"""
        
        numerado = numerar_lineas(codigo)
        lineas = numerado.split('\n')
        
        # Verificar que la línea 7 tiene "Libro"
        # (las líneas vacías no tienen marcador, por eso hay que contar bien)
        self.assertIn(len(lineas), [10, 11])
        self.assertIn("[L001]", lineas[0])
        self.assertIn("Cafe", lineas[4])  # Línea 5: Cafe
        self.assertIn("Pimienta", lineas[5])  # Línea 6: Pimienta
        self.assertIn("Libro", lineas[6])  # Línea 7: Libro
        self.assertIn("Registro", lineas[7])  # Línea 8: Registro


if __name__ == "__main__":
    unittest.main()