import pathlib
from typing import Dict, List, Optional, Set, Tuple
import pandas as pd
from pydantic import BaseModel, Field

class RelationshipMeta(BaseModel):
    from_table: str
    from_column: str
    to_table: str
    to_column: str
    relationship_type: str 
    confidence: float 
    inference_method: str 
    
    class Config:
        extra = 'allow'

def normalize_column_name(col_name: str) -> str:
    normalized = col_name.lower().strip().replace(" ", "_").replace("-", "_")
    for suffix in ['_id', 'id', '_key', 'key', '_code', 'code']:
        if normalized.endswith(suffix) and len(normalized) > len(suffix):
            normalized = normalized[:-len(suffix)]
            break
    return normalized

def calculate_containment(child: pd.Series, parent: pd.Series, sample_size: int = 10000) -> float:
    child_clean = child.dropna()
    parent_clean = parent.dropna()
    if len(child_clean) == 0 or len(parent_clean) == 0:
        return 0.0
    if len(child_clean) > sample_size:
        child_clean = child_clean.sample(sample_size, random_state=42)
    child_set = set(child_clean.astype(str).unique())
    parent_set = set(parent_clean.astype(str).unique())
    if not child_set:
        return 0.0

    return len(child_set.intersection(parent_set)) / len(child_set)

def infer_cardinality(parent_series: pd.Series, child_series: pd.Series) -> str:
    parent_unique = parent_series.nunique() / len(parent_series) if len(parent_series) > 0 else 0
    child_unique = child_series.nunique() / len(child_series) if len(child_series) > 0 else 0
    if parent_unique > 0.98 and child_unique < 0.98:
        return "1:N"
    elif parent_unique > 0.98 and child_unique > 0.98:
        return "1:1"
    else:
        return "N:M"

def detect_relationships_between_tables(
    table1_name: str, table1_meta, table1_df: pd.DataFrame,
    table2_name: str, table2_meta, table2_df: pd.DataFrame,
    min_containment_threshold: float = 0.9,
    min_confidence: float = 0.7
) -> List[RelationshipMeta]:
    relationships = []
    temporal_keywords = ["time", "date", "timestamp"]
    def is_valid(col_name, col_meta, series):
        name = col_name.lower()
        if any(k in name for k in temporal_keywords):
            return False
        if col_meta.data_type in ["datetime", "float"]:
            return False
        if series.nunique() < 20:
            return False
        return True

    for parent_table_name, parent_meta, parent_df, child_table_name, child_meta, child_df in [
        (table1_name, table1_meta, table1_df, table2_name, table2_meta, table2_df),
        (table2_name, table2_meta, table2_df, table1_name, table1_meta, table1_df),
    ]:
        for parent_col_name, parent_col_meta in parent_meta.columns.items():
            parent_series = parent_df[parent_col_name]
            if not is_valid(parent_col_name, parent_col_meta, parent_series):
                continue
            parent_unique_ratio = parent_series.nunique() / len(parent_series)
            if parent_unique_ratio < 0.98:
                continue
            for child_col_name, child_col_meta in child_meta.columns.items():
                child_series = child_df[child_col_name]
                if not is_valid(child_col_name, child_col_meta, child_series):
                    continue
                if parent_col_meta.data_type != child_col_meta.data_type:
                    continue
                norm_parent = normalize_column_name(parent_col_name)
                norm_child = normalize_column_name(child_col_name)
                name_match_score = 0.0
                inference_methods = []
                if norm_parent == norm_child:
                    name_match_score = 0.2
                    inference_methods.append("name_match")
                containment = calculate_containment(child_series, parent_series)
                if containment < min_containment_threshold:
                    continue
                inference_methods.append(f"containment_{containment:.2f}")
                confidence = name_match_score + (containment * 0.8)
                if confidence < min_confidence:
                    continue
                cardinality = infer_cardinality(parent_series, child_series)

                relationships.append(
                    RelationshipMeta(
                        from_table=parent_table_name,
                        from_column=parent_col_name,
                        to_table=child_table_name,
                        to_column=child_col_name,
                        relationship_type=cardinality,
                        confidence=confidence,
                        inference_method=" + ".join(inference_methods)
                    )
                )
    return relationships

def infer_all_relationships(
    dataset_meta, 
    dataframes: Dict[str, pd.DataFrame], 
    min_containment_threshold: float, 
    min_confidence: float
) -> List[RelationshipMeta]:
    all_relationships = []
    table_names = list(dataset_meta.tables.keys())
    
    for i, t1_name in enumerate(table_names):
        for t2_name in table_names[i+1:]:
            rels = detect_relationships_between_tables(
                t1_name, dataset_meta.tables[t1_name], dataframes[t1_name],
                t2_name, dataset_meta.tables[t2_name], dataframes[t2_name],
                min_containment_threshold, min_confidence
            )
            all_relationships.extend(rels)
    return all_relationships

def deduplicate_relationships(relationships: List[RelationshipMeta]) -> List[RelationshipMeta]:
    relationship_map = {}
    for rel in relationships:
        table_pair = tuple(sorted([rel.from_table, rel.to_table]))
        key = (table_pair, rel.from_column if rel.from_table < rel.to_table else rel.to_column)
        
        if key not in relationship_map or rel.confidence > relationship_map[key].confidence:
            relationship_map[key] = rel
    return list(relationship_map.values())
