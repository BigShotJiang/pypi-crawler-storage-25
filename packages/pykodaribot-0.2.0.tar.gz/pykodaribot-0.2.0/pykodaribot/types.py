from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .bot import Bot


@dataclass
class User:
    id: int
    is_bot: bool
    first_name: str
    username: Optional[str] = None

    @classmethod
    def from_dict(cls, d: dict) -> "User":
        return cls(
            id=d["id"],
            is_bot=d.get("is_bot", False),
            first_name=d.get("first_name", ""),
            username=d.get("username"),
        )


@dataclass
class ChatPermissions:
    send_messages: bool = True
    send_media: bool = True
    embed_links: bool = True
    invite_users: bool = True
    pin_messages: bool = False
    change_info: bool = False

    @classmethod
    def from_dict(cls, d: dict) -> "ChatPermissions":
        return cls(
            send_messages=d.get("send_messages", True),
            send_media=d.get("send_media", True),
            embed_links=d.get("embed_links", True),
            invite_users=d.get("invite_users", True),
            pin_messages=d.get("pin_messages", False),
            change_info=d.get("change_info", False),
        )

    def to_dict(self) -> dict:
        return {
            "send_messages": self.send_messages,
            "send_media": self.send_media,
            "embed_links": self.embed_links,
            "invite_users": self.invite_users,
            "pin_messages": self.pin_messages,
            "change_info": self.change_info,
        }


@dataclass
class ChatAdministratorRights:
    delete_messages: bool = False
    remove_users: bool = False
    block_users: bool = False
    pin_messages: bool = False
    invite_users: bool = True
    change_info: bool = False
    add_admins: bool = False
    post_messages: bool = False
    edit_messages: bool = False

    @classmethod
    def from_dict(cls, d: dict) -> "ChatAdministratorRights":
        return cls(
            delete_messages=d.get("delete_messages", False),
            remove_users=d.get("remove_users", False),
            block_users=d.get("block_users", False),
            pin_messages=d.get("pin_messages", False),
            invite_users=d.get("invite_users", True),
            change_info=d.get("change_info", False),
            add_admins=d.get("add_admins", False),
            post_messages=d.get("post_messages", False),
            edit_messages=d.get("edit_messages", False),
        )

    def to_dict(self) -> dict:
        return {
            "delete_messages": self.delete_messages,
            "remove_users": self.remove_users,
            "block_users": self.block_users,
            "pin_messages": self.pin_messages,
            "invite_users": self.invite_users,
            "change_info": self.change_info,
            "add_admins": self.add_admins,
            "post_messages": self.post_messages,
            "edit_messages": self.edit_messages,
        }


@dataclass
class ChatMember:
    user: User
    status: str
    custom_title: Optional[str] = None
    permissions: Optional[ChatAdministratorRights] = None

    @classmethod
    def from_dict(cls, d: dict) -> "ChatMember":
        role = d.get("role", "member")
        status_map = {"owner": "creator", "admin": "administrator", "member": "member"}
        status = status_map.get(role, role)
        perms = ChatAdministratorRights.from_dict(d.get("permissions") or {}) if role in ("owner", "admin") else None
        return cls(
            user=User.from_dict({
                "id": d.get("user_id", 0),
                "is_bot": d.get("is_bot", False),
                "first_name": d.get("name") or d.get("login") or "",
                "username": d.get("login"),
            }),
            status=status,
            custom_title=d.get("custom_title"),
            permissions=perms,
        )


@dataclass
class ChatInviteLink:
    invite_link: str
    name: Optional[str] = None
    expire_date: Optional[int] = None
    member_limit: Optional[int] = None
    uses_count: int = 0
    is_revoked: bool = False

    @classmethod
    def from_dict(cls, d: dict) -> "ChatInviteLink":
        import re
        hash_ = d.get("hash", "")
        url = d.get("url") or ("https://msg.kodari.ru/?invite=" + hash_ if hash_ else "")
        return cls(
            invite_link=url,
            name=d.get("name"),
            expire_date=d.get("expires_at"),
            member_limit=d.get("member_limit"),
            uses_count=d.get("uses_count", 0),
            is_revoked=bool(d.get("revoked", False)),
        )


@dataclass
class ChatAdminLogEntry:
    id: int
    action: str
    actor_user_id: int
    target_user_id: Optional[int] = None
    target_message_id: Optional[int] = None
    payload: Optional[dict] = None
    created_at: Optional[str] = None

    @classmethod
    def from_dict(cls, d: dict) -> "ChatAdminLogEntry":
        import json as _json
        payload = None
        raw = d.get("payload_json")
        if raw:
            try:
                payload = _json.loads(raw)
            except Exception:
                pass
        return cls(
            id=d.get("id", 0),
            action=d.get("action", ""),
            actor_user_id=d.get("actor_user_id", 0),
            target_user_id=d.get("target_user_id"),
            target_message_id=d.get("target_message_id"),
            payload=payload,
            created_at=d.get("created_at"),
        )


@dataclass
class Chat:
    id: int
    type: str
    title: Optional[str] = None
    username: Optional[str] = None
    description: Optional[str] = None
    slow_mode_delay: int = 0
    who_can_send: str = "all"
    permissions: Optional[ChatPermissions] = None
    pinned_message: Optional["Message"] = None
    member_count: Optional[int] = None

    @classmethod
    def from_dict(cls, d: dict, bot: Any = None) -> "Chat":
        pinned = None
        if d.get("pinned_message"):
            pinned = Message.from_dict(d["pinned_message"], bot)
        perms = None
        if d.get("default_permissions"):
            perms = ChatPermissions.from_dict(d["default_permissions"])
        return cls(
            id=d["id"],
            type=d.get("type", ""),
            title=d.get("name") or d.get("title"),
            username=d.get("username"),
            description=d.get("description"),
            slow_mode_delay=d.get("slow_mode_delay") or d.get("slow_mode_seconds") or 0,
            who_can_send=d.get("who_can_send", "all"),
            permissions=perms,
            pinned_message=pinned,
            member_count=d.get("member_count"),
        )


@dataclass
class InlineKeyboardButton:
    text: str
    callback_data: Optional[str] = None
    url: Optional[str] = None

    def to_dict(self) -> dict:
        d: dict = {"text": self.text}
        if self.callback_data is not None:
            d["callback_data"] = self.callback_data
        if self.url is not None:
            d["url"] = self.url
        return d


@dataclass
class InlineKeyboardMarkup:
    inline_keyboard: List[List[InlineKeyboardButton]] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "inline_keyboard": [
                [btn.to_dict() for btn in row]
                for row in self.inline_keyboard
            ]
        }


@dataclass
class Message:
    message_id: int
    chat: Chat
    date: int
    from_user: Optional[User] = None
    text: Optional[str] = None
    _bot: Any = field(default=None, repr=False, compare=False)

    @classmethod
    def from_dict(cls, d: dict, bot: Any = None) -> "Message":
        if "chat" in d:
            chat = Chat.from_dict(d["chat"], bot)
        else:
            chat = Chat(id=d.get("chat_id", 0), type="")
        return cls(
            message_id=d.get("message_id") or d.get("id") or 0,
            chat=chat,
            date=d.get("date", 0),
            from_user=User.from_dict(d["from"]) if "from" in d else None,
            text=d.get("text"),
            _bot=bot,
        )

    async def answer(self, text: str, **kwargs) -> "Message":
        return await self._bot.send_message(self.chat.id, text, **kwargs)

    async def reply(self, text: str, **kwargs) -> "Message":
        return await self._bot.send_message(
            self.chat.id, text, reply_to_message_id=self.message_id, **kwargs
        )


@dataclass
class CallbackQuery:
    id: str
    from_user: User
    data: Optional[str] = None
    message: Optional[Message] = None
    _bot: Any = field(default=None, repr=False, compare=False)

    @classmethod
    def from_dict(cls, d: dict, bot: Any = None) -> "CallbackQuery":
        return cls(
            id=d["id"],
            from_user=User.from_dict(d["from"]),
            data=d.get("data"),
            message=Message.from_dict(d["message"], bot) if "message" in d else None,
            _bot=bot,
        )

    async def answer(self) -> None:
        await self._bot.answer_callback_query(self.id)


@dataclass
class Update:
    update_id: int
    message: Optional[Message] = None
    edited_message: Optional[Message] = None
    callback_query: Optional[CallbackQuery] = None

    @classmethod
    def from_dict(cls, d: dict, bot: Any = None) -> "Update":
        return cls(
            update_id=d["update_id"],
            message=Message.from_dict(d["message"], bot) if "message" in d else None,
            edited_message=Message.from_dict(d["edited_message"], bot) if "edited_message" in d else None,
            callback_query=CallbackQuery.from_dict(d["callback_query"], bot) if "callback_query" in d else None,
        )


@dataclass
class BotCommand:
    command: str
    description: str

    def to_dict(self) -> dict:
        return {"command": self.command, "description": self.description}
