from __future__ import annotations
import re
from typing import Union

from .types import CallbackQuery, Message


class Filter:
    async def __call__(self, obj) -> bool:
        raise NotImplementedError


class CommandFilter(Filter):
    def __init__(self, *commands: str):
        self.commands = {c.lstrip("/") for c in commands}

    async def __call__(self, msg: Message) -> bool:
        if not msg.text:
            return False
        first = msg.text.split()[0].lstrip("/").split("@")[0]
        return first in self.commands


class TextFilter(Filter):
    def __init__(self, pattern: Union[str, re.Pattern]):
        self.pattern = re.compile(pattern) if isinstance(pattern, str) else pattern

    async def __call__(self, msg: Message) -> bool:
        return bool(msg.text and self.pattern.search(msg.text))


class CallbackDataFilter(Filter):
    def __init__(self, data: str):
        self.data = data

    async def __call__(self, cb: CallbackQuery) -> bool:
        return cb.data == self.data


class CallbackDataPrefixFilter(Filter):
    def __init__(self, prefix: str):
        self.prefix = prefix

    async def __call__(self, cb: CallbackQuery) -> bool:
        return cb.data is not None and cb.data.startswith(self.prefix)


def command(*commands: str) -> CommandFilter:
    return CommandFilter(*commands)


def text(pattern: Union[str, re.Pattern]) -> TextFilter:
    return TextFilter(pattern)


def callback_data(data: str) -> CallbackDataFilter:
    return CallbackDataFilter(data)


def callback_data_prefix(prefix: str) -> CallbackDataPrefixFilter:
    return CallbackDataPrefixFilter(prefix)
