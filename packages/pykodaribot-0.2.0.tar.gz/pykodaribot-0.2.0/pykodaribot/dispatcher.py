from __future__ import annotations
import asyncio
import logging
from typing import Callable, List, Tuple

from .bot import Bot, BotError
from .filters import Filter
from .types import CallbackQuery, Message, Update

logger = logging.getLogger(__name__)

HandlerList = List[Tuple[List[Filter], Callable]]


class Router:
    def __init__(self):
        self._message_handlers: HandlerList = []
        self._edited_message_handlers: HandlerList = []
        self._callback_query_handlers: HandlerList = []

    def message(self, *filters: Filter):
        def decorator(func: Callable):
            self._message_handlers.append((list(filters), func))
            return func
        return decorator

    def edited_message(self, *filters: Filter):
        def decorator(func: Callable):
            self._edited_message_handlers.append((list(filters), func))
            return func
        return decorator

    def callback_query(self, *filters: Filter):
        def decorator(func: Callable):
            self._callback_query_handlers.append((list(filters), func))
            return func
        return decorator

    async def _run_handlers(self, handlers: HandlerList, obj) -> None:
        for filters, handler in handlers:
            if all([await f(obj) for f in filters]):
                try:
                    await handler(obj)
                except Exception:
                    logger.exception("Ошибка в обработчике %s", handler.__name__)
                return

    async def process_update(self, update: Update) -> None:
        if update.message:
            await self._run_handlers(self._message_handlers, update.message)
        elif update.edited_message:
            await self._run_handlers(self._edited_message_handlers, update.edited_message)
        elif update.callback_query:
            await self._run_handlers(self._callback_query_handlers, update.callback_query)


class Dispatcher(Router):
    async def start_polling(self, bot: Bot, timeout: int = 20) -> None:
        offset = 0
        logger.info("Поллинг запущен")
        try:
            while True:
                try:
                    updates = await bot.get_updates(offset=offset, timeout=timeout)
                    for update in updates:
                        offset = update.update_id + 1
                        await self.process_update(update)
                except BotError as e:
                    if e.error_code == 409:
                        logger.warning("Конфликт getUpdates — ожидание завершения предыдущей сессии")
                        await asyncio.sleep(timeout + 5)
                    else:
                        logger.error("Ошибка API: %s", e)
                        await asyncio.sleep(1)
                except asyncio.CancelledError:
                    raise
                except Exception:
                    logger.exception("Ошибка поллинга")
                    await asyncio.sleep(1)
        finally:
            await bot.close()
            logger.info("Поллинг остановлен")
