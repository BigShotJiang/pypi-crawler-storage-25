from __future__ import annotations
from pathlib import Path
from typing import BinaryIO, List, Optional, Union

import aiohttp

from .types import (
    BotCommand, Chat, ChatAdministratorRights, ChatAdminLogEntry,
    ChatInviteLink, ChatMember, ChatPermissions,
    InlineKeyboardMarkup, Message, Update, User,
)

MediaInput = Union[str, bytes, Path, BinaryIO]


class BotError(Exception):
    def __init__(self, error_code: int, description: str):
        self.error_code = error_code
        self.description = description
        super().__init__(f"[{error_code}] {description}")


class Bot:
    BASE_URL = "https://api.kodari.ru/msg/bot.php"

    def __init__(self, token: str):
        self._token = token
        self._headers = {"Authorization": f"Bearer {token}"}
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(headers=self._headers)
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def __aenter__(self) -> "Bot":
        return self

    async def __aexit__(self, *_) -> None:
        await self.close()

    async def _get(self, method: str, **params) -> object:
        session = await self._get_session()
        params["method"] = method
        async with session.get(self.BASE_URL, params=params) as r:
            data = await r.json()
        if not data.get("ok"):
            raise BotError(data.get("error_code", 0), data.get("description", "Unknown"))
        return data["result"]

    async def _post(self, method: str, **body) -> object:
        session = await self._get_session()
        url = f"{self.BASE_URL}?method={method}"
        body = {k: v for k, v in body.items() if v is not None}
        async with session.post(url, json=body) as r:
            data = await r.json()
        if not data.get("ok"):
            raise BotError(data.get("error_code", 0), data.get("description", "Unknown"))
        return data["result"]

    async def _post_media(self, method: str, chat_id: int, media: MediaInput,
                          caption: Optional[str], reply_to_message_id: Optional[int]) -> object:
        session = await self._get_session()
        url = f"{self.BASE_URL}?method={method}"
        form = aiohttp.FormData()
        form.add_field("chat_id", str(chat_id))
        if caption is not None:
            form.add_field("caption", caption)
        if reply_to_message_id is not None:
            form.add_field("reply_to_message_id", str(reply_to_message_id))
        if isinstance(media, (str, Path)):
            path = Path(media)
            with open(path, "rb") as f:
                form.add_field("media", f, filename=path.name)
                async with session.post(url, data=form) as r:
                    data = await r.json()
        else:
            filename = getattr(media, "name", "file")
            form.add_field("media", media, filename=Path(filename).name)
            async with session.post(url, data=form) as r:
                data = await r.json()
        if not data.get("ok"):
            raise BotError(data.get("error_code", 0), data.get("description", "Unknown"))
        return data["result"]

    def _markup(self, reply_markup) -> Optional[dict]:
        if reply_markup is None:
            return None
        return reply_markup.to_dict() if hasattr(reply_markup, "to_dict") else reply_markup

    async def get_me(self) -> User:
        return User.from_dict(await self._get("getMe"))

    async def send_message(
        self,
        chat_id: int,
        text: str,
        reply_to_message_id: Optional[int] = None,
        reply_markup: Optional[Union[InlineKeyboardMarkup, dict]] = None,
    ) -> Message:
        return Message.from_dict(
            await self._post(
                "sendMessage",
                chat_id=chat_id,
                text=text,
                reply_to_message_id=reply_to_message_id,
                reply_markup=self._markup(reply_markup),
            ),
            self,
        )

    async def send_photo(
        self,
        chat_id: int,
        media: MediaInput,
        caption: Optional[str] = None,
        reply_to_message_id: Optional[int] = None,
    ) -> Message:
        return Message.from_dict(
            await self._post_media("sendPhoto", chat_id, media, caption, reply_to_message_id),
            self,
        )

    async def send_document(
        self,
        chat_id: int,
        media: MediaInput,
        caption: Optional[str] = None,
        reply_to_message_id: Optional[int] = None,
    ) -> Message:
        return Message.from_dict(
            await self._post_media("sendDocument", chat_id, media, caption, reply_to_message_id),
            self,
        )

    async def send_video(
        self,
        chat_id: int,
        media: MediaInput,
        caption: Optional[str] = None,
        reply_to_message_id: Optional[int] = None,
    ) -> Message:
        return Message.from_dict(
            await self._post_media("sendVideo", chat_id, media, caption, reply_to_message_id),
            self,
        )

    async def send_audio(
        self,
        chat_id: int,
        media: MediaInput,
        caption: Optional[str] = None,
        reply_to_message_id: Optional[int] = None,
    ) -> Message:
        return Message.from_dict(
            await self._post_media("sendAudio", chat_id, media, caption, reply_to_message_id),
            self,
        )

    async def edit_message_text(
        self,
        chat_id: int,
        message_id: int,
        text: str,
        reply_markup: Optional[Union[InlineKeyboardMarkup, dict]] = None,
    ) -> Message:
        return Message.from_dict(
            await self._post("editMessageText", chat_id=chat_id, message_id=message_id,
                             text=text, reply_markup=self._markup(reply_markup)),
            self,
        )

    async def delete_message(self, chat_id: int, message_id: int) -> bool:
        return bool(await self._post("deleteMessage", chat_id=chat_id, message_id=message_id))

    async def get_updates(
        self,
        offset: int = 0,
        timeout: int = 20,
        limit: int = 100,
    ) -> List[Update]:
        result = await self._get("getUpdates", offset=offset, timeout=timeout, limit=limit)
        return [Update.from_dict(u, self) for u in result]

    async def answer_callback_query(self, callback_query_id: str) -> bool:
        return bool(await self._post("answerCallbackQuery", callback_query_id=callback_query_id))

    async def set_my_commands(self, commands: List[BotCommand]) -> bool:
        return bool(await self._post("setMyCommands", commands=[c.to_dict() for c in commands]))

    async def get_my_commands(self) -> List[BotCommand]:
        result = await self._get("getMyCommands")
        return [BotCommand(c["command"], c["description"]) for c in result]

    async def set_my_name(self, name: str) -> bool:
        return bool(await self._post("setMyName", name=name))

    async def set_my_description(self, description: str) -> bool:
        return bool(await self._post("setMyDescription", description=description))

    async def set_my_short_description(self, short_description: str) -> bool:
        return bool(await self._post("setMyShortDescription", short_description=short_description))

    async def get_chat(self, chat_id: int) -> Chat:
        return Chat.from_dict(await self._get("getChat", chat_id=chat_id), self)

    async def get_or_create_chat(self, student_id: str, id_city: Optional[str] = None) -> dict:
        body: dict = {"student_id": student_id}
        if id_city:
            body["id_city"] = id_city
        return await self._post("getOrCreateChat", **body)

    async def resolve_user(self, user_id: int) -> dict:
        return await self._get("resolveUser", user_id=user_id)

    async def pin_message(self, chat_id: int, message_id: int) -> bool:
        return bool(await self._post("pinMessage", chat_id=chat_id, message_id=message_id))

    async def unpin_message(self, chat_id: int) -> bool:
        return bool(await self._post("unpinMessage", chat_id=chat_id))

    async def set_chat_title(self, chat_id: int, title: str) -> bool:
        return bool(await self._post("setChatTitle", chat_id=chat_id, title=title))

    async def set_chat_description(self, chat_id: int, description: str) -> bool:
        return bool(await self._post("setChatDescription", chat_id=chat_id, description=description))

    async def set_chat_photo(self, chat_id: int, media: MediaInput) -> bool:
        return bool(await self._post_media("setChatPhoto", chat_id, media, None, None))

    async def delete_chat_photo(self, chat_id: int) -> bool:
        return bool(await self._post("deleteChatPhoto", chat_id=chat_id))

    async def set_chat_permissions(
        self,
        chat_id: int,
        permissions: Union[ChatPermissions, dict],
    ) -> bool:
        perms = permissions.to_dict() if hasattr(permissions, "to_dict") else permissions
        return bool(await self._post("setChatPermissions", chat_id=chat_id, permissions=perms))

    async def set_chat_slow_mode(self, chat_id: int, seconds: int) -> bool:
        return bool(await self._post("setChatSlowMode", chat_id=chat_id, seconds=seconds))

    async def ban_chat_member(
        self,
        chat_id: int,
        user_id: int,
        reason: Optional[str] = None,
    ) -> bool:
        return bool(await self._post("banChatMember", chat_id=chat_id, user_id=user_id, reason=reason))

    async def unban_chat_member(self, chat_id: int, user_id: int) -> bool:
        return bool(await self._post("unbanChatMember", chat_id=chat_id, user_id=user_id))

    async def kick_chat_member(self, chat_id: int, user_id: int) -> bool:
        return bool(await self._post("kickChatMember", chat_id=chat_id, user_id=user_id))

    async def promote_chat_member(
        self,
        chat_id: int,
        user_id: int,
        permissions: Union[ChatAdministratorRights, dict],
        custom_title: Optional[str] = None,
    ) -> bool:
        perms = permissions.to_dict() if hasattr(permissions, "to_dict") else permissions
        return bool(await self._post(
            "promoteChatMember",
            chat_id=chat_id,
            user_id=user_id,
            permissions=perms,
            custom_title=custom_title,
        ))

    async def demote_chat_member(self, chat_id: int, user_id: int) -> bool:
        return bool(await self._post("demoteChatMember", chat_id=chat_id, user_id=user_id))

    async def set_chat_administrator_custom_title(
        self,
        chat_id: int,
        user_id: int,
        custom_title: str,
    ) -> bool:
        return bool(await self._post(
            "setChatAdministratorCustomTitle",
            chat_id=chat_id,
            user_id=user_id,
            custom_title=custom_title,
        ))

    async def get_chat_administrators(self, chat_id: int) -> List[ChatMember]:
        result = await self._get("getChatAdministrators", chat_id=chat_id)
        return [ChatMember.from_dict(m) for m in result]

    async def get_chat_member_count(self, chat_id: int) -> int:
        return int(await self._get("getChatMemberCount", chat_id=chat_id))

    async def get_chat_member(self, chat_id: int, user_id: int) -> ChatMember:
        return ChatMember.from_dict(await self._get("getChatMember", chat_id=chat_id, user_id=user_id))

    async def export_chat_invite_link(self, chat_id: int) -> str:
        result = await self._get("exportChatInviteLink", chat_id=chat_id)
        return str(result)

    async def create_chat_invite_link(
        self,
        chat_id: int,
        name: Optional[str] = None,
        expire_date: Optional[int] = None,
        member_limit: Optional[int] = None,
    ) -> ChatInviteLink:
        return ChatInviteLink.from_dict(
            await self._post(
                "createChatInviteLink",
                chat_id=chat_id,
                name=name,
                expire_date=expire_date,
                member_limit=member_limit,
            )
        )

    async def revoke_chat_invite_link(self, chat_id: int, invite_link: str) -> bool:
        return bool(await self._post("revokeChatInviteLink", chat_id=chat_id, invite_link=invite_link))

    async def get_chat_admin_log(
        self,
        chat_id: int,
        limit: int = 50,
        offset: int = 0,
    ) -> List[ChatAdminLogEntry]:
        result = await self._get("getChatAdminLog", chat_id=chat_id, limit=limit, offset=offset)
        entries = result if isinstance(result, list) else result.get("log", [])
        return [ChatAdminLogEntry.from_dict(e) for e in entries]
