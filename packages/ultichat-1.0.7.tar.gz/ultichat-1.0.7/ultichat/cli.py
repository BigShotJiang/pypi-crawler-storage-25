from .chat import UltraChat

def main():
    chat = UltraChat()
    chat.start()