import firebase_admin
from firebase_admin import credentials, db
import threading
import time
import random
import string
import os

FIREBASE_CONFIG_PATH = "firebase.json"
FIREBASE_DB_URL = "https://pinor-web-default-rtdb.firebaseio.com/"

class UltraChat:

    def __init__(self):

        if not firebase_admin._apps:
            cred = credentials.Certificate(FIREBASE_CONFIG_PATH)
            firebase_admin.initialize_app(cred, {
                "databaseURL": FIREBASE_DB_URL
            })

        self.room = "random_global_room"
        self.user = None
        self.running = True

        self.ref = db.reference(f"ultichat/{self.room}")

    def set_username(self, name):
        self.user = name

    def send(self, msg):
        self.ref.push({
            "user": self.user,
            "msg": msg,
            "time": time.time()
        })

    def listen(self):
        last_data = None

        while self.running:
            data = self.ref.get()

            if data != last_data:
                last_data = data
                os.system("cls" if os.name == "nt" else "clear")

                print("ULTICHAT RANDOM ROOM")
                print("=" * 40)

                if data:
                    for k, v in data.items():
                        print(f"{v['user']}: {v['msg']}")

                print("\nType /exit to leave\n")

            time.sleep(1)

    def start(self):

        print("ULTICHAT - RANDOM TERMINAL CHAT")
        name = input("Enter username: ")
        self.set_username(name)

        print("\nConnecting to random room...\n")

        t = threading.Thread(target=self.listen)
        t.daemon = True
        t.start()

        while self.running:
            msg = input("> ")

            if msg == "/exit":
                self.running = False
                break

            self.send(msg)