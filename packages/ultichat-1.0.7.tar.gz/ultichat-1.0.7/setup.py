from setuptools import setup, find_packages
import pathlib

BASE_DIR = pathlib.Path(__file__).parent
README = (BASE_DIR / "README.md").read_text(encoding="utf-8")

setup(
    name="ultichat",

    version="1.0.7",

    author="Esfar",
    author_email="esfarajmain12@gmail.com",

    description="Terminal-based anonymous real-time chat system powered by Firebase Realtime Database.",

    long_description=README,
    long_description_content_type="text/markdown",

    packages=find_packages(),

    include_package_data=True,

    install_requires=[
        "firebase-admin>=6.0.0",
        "requests>=2.31.0"
    ],

    python_requires=">=3.8",

    entry_points={
        "console_scripts": [
            "ultichat=ultichat.cli:main",
            "chat=ultichat.cli:main"
        ]
    },

    license="MIT",

    keywords=[
        # chat core
        "chat", "terminal chat", "cli chat", "realtime chat", "anonymous chat",
        "random chat", "global chat", "chat system", "messenger", "messaging",

        # firebase
        "firebase", "firebase chat", "firebase realtime", "realtime database",
        "firebase integration", "google firebase", "backend chat",

        # networking
        "networking", "socket alternative", "real-time communication",
        "live messaging", "instant messaging", "distributed chat",

        # python tools
        "python package", "python library", "python tool", "developer tool",
        "cli tool", "terminal tool", "automation tool", "utility",

        # apps
        "chat application", "messaging app", "terminal application",
        "command line app", "console app", "chat client",

        # dev tools
        "developer utilities", "backend tool", "api tool",
        "integration tool", "sdk style package",

        # systems
        "real time system", "event system", "message system",
        "data sync", "live sync", "multi user system",

        # education
        "learning project", "beginner project", "open source learning",
        "python learning", "firebase learning",

        # advanced
        "scalable chat", "lightweight chat", "fast chat system",
        "minimal chat", "secure messaging base",

        # ui/terminal
        "terminal messenger", "console messenger", "cli messenger",
        "text based chat", "hacker chat style",

        # social
        "anonymous messaging", "random users", "chat rooms",
        "public chat room", "group chat",

        # esfar branding
        "esfar", "ultichat", "esfar tools", "esfar dev",

        # misc useful
        "communication", "collaboration", "social tool",
        "chat platform", "messaging platform", "real time platform",
        "firebase app", "python firebase", "realtime app"
    ],

    classifiers=[
        "Development Status :: 4 - Beta",

        "Intended Audience :: Developers",
        "Intended Audience :: End Users/Desktop",
        "Intended Audience :: System Administrators",

        "Topic :: Communications",
        "Topic :: Communications :: Chat",
        "Topic :: Internet",
        "Topic :: Software Development",
        "Topic :: Software Development :: Libraries",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Utilities",

        "Operating System :: OS Independent",

        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",

        "License :: OSI Approved :: MIT License",
        "Natural Language :: English"
    ],

    project_urls={
        "Instagram": "https://www.instagram.com/fatti.ozzz/"
    },

    extras_require={
        "dev": [
            "twine",
            "build",
            "wheel",
            "pytest"
        ]
    },

    zip_safe=False,
)