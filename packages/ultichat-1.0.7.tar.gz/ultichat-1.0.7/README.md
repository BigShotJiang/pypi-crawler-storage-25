# ULTICHAT

ULTICHAT is a terminal-based anonymous real-time chat system powered by Firebase Realtime Database. It allows users to instantly join a global chat room from the command line and communicate with random users in real time without any registration, login system, or personal data requirement.

The project is designed to demonstrate how real-time distributed messaging systems can be built using Python and Firebase. It is intended for developers, learners, and system designers who want to understand how live messaging, synchronization, and event-driven communication systems work in practical environments.

ULTICHAT focuses on simplicity, minimal setup, and real-time interaction. Once installed, users can immediately start chatting in a shared global environment using only a terminal command.

---

# PROJECT GOAL

The main goal of ULTICHAT is to provide a lightweight and educational real-time chat system that runs directly in the terminal. It demonstrates how multiple users can communicate through a shared database in real time without needing a traditional backend server.

It is useful for:
- Learning Firebase integration
- Understanding real-time databases
- Building CLI applications
- Experimenting with distributed messaging
- Creating minimal communication systems

---

# FEATURES

ULTICHAT includes the following features:

- Terminal-based real-time chat system
- Anonymous user communication
- Global shared chat room
- Instant message synchronization
- Firebase Realtime Database backend
- Lightweight and fast execution
- Cross-platform support (Windows, Linux, MacOS)
- Simple command-based interface
- No login or registration required
- Exit chat anytime using command
- Minimal configuration setup
- Beginner-friendly design
- Developer-oriented architecture

---

# INSTALLATION

Install ULTICHAT using pip:

```bash
pip install ultichat
```

Install dependencies manually if required:

```bash
pip install firebase-admin
```

---

# REQUIREMENTS

- Python 3.8 or higher
- Firebase Realtime Database project
- Firebase service account JSON file

---

# FIREBASE SETUP

To use ULTICHAT, you must set up Firebase Realtime Database.

## Steps:

1. Go to Firebase Console
2. Create a new project
3. Enable Realtime Database
4. Go to Project Settings
5. Generate Service Account Key
6. Download JSON file
7. Save it as:

```txt
firebase.json
```

Place this file in your project directory.

---

# USAGE

Run the chat system using:

```bash
ultichat
```

or:

```bash
chat
```

---

# HOW IT WORKS

When the program starts:

1. User enters a username
2. System connects to Firebase database
3. User joins a shared global chat room
4. Messages are pushed to Firebase
5. All connected users receive live updates instantly

---

# COMMANDS

Inside the chat system:

- Send message: type normally and press enter
- Exit chat: type

```txt
/exit
```

---

# EXAMPLE SESSION

```txt
ULTICHAT - TERMINAL CHAT SYSTEM
Enter username: Esfar

Connecting to global room...

> hello everyone
> who is here
> this is awesome
> /exit
```

---

# DATA STRUCTURE

Messages are stored in Firebase Realtime Database in the following structure:

```txt
ultichat/
  random_global_room/
    message_id/
      user: "username"
      msg: "message content"
      time: 1234567890
```

---

# ARCHITECTURE

ULTICHAT uses a simple architecture:

Terminal Client (Python)
        ↓
Firebase Realtime Database
        ↓
Other Connected Clients

Every message is pushed to the database and automatically synchronized across all users in real time.

---

# LIMITATIONS

- No encryption system
- No authentication system
- No private rooms (current version)
- Requires internet connection
- Depends on Firebase quota limits

---

# SECURITY NOTICE

ULTICHAT is intended for educational and experimental purposes only. It does not provide encryption, privacy protection, or secure communication features.

Users should not use this system for sensitive or confidential communication.

---

# DISCLAIMER

ULTICHAT is not affiliated with Firebase, Google, or Alphabet Inc.

Firebase is used strictly as a backend real-time database service.

---

# FUTURE PLANS

Future versions of ULTICHAT may include:

- Private chat rooms
- Room code system
- User online status tracking
- Typing indicators
- Message encryption
- Better terminal UI interface
- Chat history system
- Friend system
- Direct messaging
- Improved performance optimization

---

# PROJECT PHILOSOPHY

ULTICHAT is built on the idea that communication systems should be simple, accessible, and educational. It is designed to show how real-time messaging can be implemented with minimal code and infrastructure.

The project focuses on:

- Simplicity over complexity
- Learning over production use
- Minimal setup requirements
- Real-time interaction principles
- Developer understanding

---

# USE CASES

ULTICHAT can be used for:

- Learning Firebase Realtime Database
- Building CLI applications
- Testing real-time systems
- Educational demonstrations
- Prototype messaging systems
- Terminal-based communication experiments

---

# INSTALLATION VERIFICATION

After installation, verify with:

```bash
ultichat --help
```

or simply:

```bash
ultichat
```

---

# AUTHOR

Created and maintained by Esfar

Instagram:
https://www.instagram.com/fatti.ozzz/

---

# LICENSE

This project is licensed under the MIT License.

You are free to use, modify, and distribute this software for personal or commercial purposes under the terms of the license.

---

# FINAL NOTE

ULTICHAT is an experimental real-time chat system built for developers who want to explore terminal-based communication and Firebase integration in Python applications. It is designed to be simple, educational, and extensible.