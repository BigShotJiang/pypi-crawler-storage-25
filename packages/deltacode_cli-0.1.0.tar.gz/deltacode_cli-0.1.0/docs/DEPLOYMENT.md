# DeltaCode Security CLI — Deployment Guide

## Requirements

| Component | Requirement | Notes |
|-----------|-------------|-------|
| **Python** | >= 3.10 | Tested on 3.10–3.12 |
| **DeltaAI API** | v1.0+ | Required for LLM features (scan, chat, fix, agent) |
| **Docker** | Optional | Required for sandbox execution |
| **Playwright** | Optional | Required for browser-based research |

## Installation

### From PyPI (Recommended)

```bash
pip install deltacode-cli
```

Verify installation:

```bash
deltacode --version
deltacode --help
```

### With Optional Features

```bash
# Security scanners (Bandit, Semgrep)
pip install deltacode-cli[security]

# Vector search (ChromaDB)
pip install deltacode-cli[search]

# Browser agent (Playwright)
pip install deltacode-cli[research]
pip install playwright
playwright install chromium

# Everything
pip install deltacode-cli[all]
```

### From Source

```bash
git clone https://github.com/deltaai/deltacode.git
cd deltacode
pip install -e .
```

## Initial Configuration

### 1. Authenticate with DeltaAI API

```bash
deltacode auth login \
  --api-url https://your-server:8100 \
  --api-key YOUR_API_KEY \
  --license-key YOUR_LICENSE_KEY \
  --organization your-org
```

Your DeltaAI API credentials will be provided upon license purchase.

### 2. Verify Connection

```bash
deltacode status
```

Expected output:
```
API: Connected
License: Valid
Tier: enterprise
```

### 3. Initialize a Workspace

```bash
cd /path/to/your/project
deltacode init
```

## CI/CD Integration

### GitHub Actions Example

```yaml
name: Security Scan

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  security-scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"

      - name: Install DeltaCode
        run: pip install deltacode-cli[security]

      - name: Authenticate
        run: |
          deltacode auth login \
            --api-url ${{ secrets.DELTAAI_API_URL }} \
            --api-key ${{ secrets.DELTAAI_API_KEY }} \
            --license-key ${{ secrets.DELTACODE_LICENSE_KEY }} \
            --organization ${{ secrets.DELTACODE_ORG }}

      - name: Dependency Scan
        run: deltacode deps --brief

      - name: Secret Detection
        run: deltacode secrets --no-trufflehog --brief

      - name: Full Audit
        run: deltacode audit .
```

### GitLab CI Example

```yaml
stages:
  - security

delta-security-scan:
  stage: security
  image: python:3.11
  script:
    - pip install deltacode-cli[security]
    - deltacode auth login --api-url $DELTAAI_API_URL --api-key $DELTAAI_API_KEY --license-key $DELTACODE_LICENSE_KEY --organization $DELTACODE_ORG
    - deltacode deps --brief
    - deltacode secrets --no-trufflehog --brief
```

## Docker Usage

```bash
# Run in sandboxed environment
deltacode sandbox create --image python:3.10-slim
deltacode sandbox exec --container-id <id> --command "pip install -r requirements.txt && bandit -r ."

# Or using the run action with Python code
deltacode sandbox run --code "print('hello from sandbox')"
```

## Security Notes

- **API Keys**: Store API keys in environment variables or use `deltacode auth login` which encrypts credentials with Fernet (machine-bound).
- **Network**: The CLI connects to your DeltaAI API server. No data is sent to third parties.
- **Sandbox**: Docker sandboxes have network disabled by default and use read-only root filesystems.
- **Logging**: All operations are logged locally under `~/.deltacode/audit/`.

## Troubleshooting

| Issue | Solution |
|-------|----------|
| `deltacode: command not found` | Ensure Python Scripts directory is in PATH: `pip show deltacode-cli` shows location |
| `API: Disconnected` | Check DeltaAI server is running: `curl http://your-server:8100/health` |
| `License invalid` | Contact support to verify your license key |
| `Docker not available` | Install Docker Desktop. Or use `--no-sandbox` flags on commands that support it |
| `Playwright not found` | Run `playwright install chromium` |

## Getting Help

```bash
# General help
deltacode --help

# Command-specific help
deltacode scan --help
deltacode mcp --help

# System diagnostics
deltacode doctor

# Export diagnostics for support
deltacode doctor --export
```
