# DeltaCode Security CLI — Command Reference

**Version:** 0.1.0 | **41 commands** | **8 MCP connectors (34 tools)**

## Authentication & Configuration

- **`deltacode auth login`** — Configure API credentials and license.
- **`deltacode auth logout`** — Remove stored credentials.
- **`deltacode auth check`** — Verify current license status.
- **`deltacode status`** — Show current configuration and license status.
- **`deltacode version`** — Show DeltaCode version.
- **`deltacode init`** — Initialize DeltaCode in a project directory.
- **`deltacode cache`** — Manage DeltaCode cache (diskcache-based persistent caching).

## Vulnerability Detection

- **`deltacode deps`** — Scan dependencies for known vulnerabilities.
- **`deltacode supply-chain`** — Assess supply chain risk for project dependencies.
- **`deltacode secrets`** — Scan for hardcoded secrets, API keys, and credentials.
- **`deltacode rules`** — Manage and apply custom security rules.
- **`deltacode cwe lookup`** — Look up CWE entries and remediation patterns.
- **`deltacode audit`** — Run local security audit (semgrep + bandit) on a codebase.

## Security Analysis

- **`deltacode scan`** — Run a single security scan query via DeltaAI.
- **`deltacode search`** — Semantic code search across the codebase.
- **`deltacode workspace index`** — Index codebase for analysis.
- **`deltacode workspace reset`** — Reset workspace index.

## Remediation

- **`deltacode autofix`** — Auto-fix security vulnerabilities found by audit.
- **`deltacode plan`** — Create a prioritized remediation plan from findings.
- **`deltacode testregression`** — Regression testing — compare before/after fix results.
- **`deltacode testmutation`** — Mutation testing — evaluate test suite quality.
- **`deltacode testcoverage`** — Test coverage analysis — line and branch coverage.
- **`deltacode exploitverify`** — Exploit fix verification — check if fixes block attacks.

## Autonomous Workflows

- **`deltacode assess`** — Security assessment plan with prioritized tasks and attack surface analysis.
- **`deltacode pipeline run`** — Run autonomous scan→analyze→fix→validate→compliance pipeline.
- **`deltacode schedule`** — Manage scheduled security assessments.
- **`deltacode agent`** — Multi-agent security team (6 agents).
- **`deltacode sandbox`** — Isolated Docker sandbox for safe testing.

## Incident Response

- **`deltacode incident`** — Incident response — detect, contain, resolve, postmortem.
- **`deltacode anomaly`** — Detect anomalous usage patterns and misuse.
- **`deltacode trail`** — View action logs and audit trail.
- **`deltacode review`** — Review and resolve pending agent decisions.

## Threat Intelligence

- **`deltacode threat intel`** — CVE threat assessment.
- **`deltacode threat trending`** — Trending CVEs.
- **`deltacode threat iocs`** — IOC extraction from text.
- **`deltacode dataflow`** — Data flow analysis — inputs, outputs, sensitive data.
- **`deltacode taint`** — Taint tracking — source-to-sink propagation.
- **`deltacode attackpath`** — Attack path modeling — exploit chain detection and scoring.

## Compliance & Reporting

- **`deltacode compliance report`** — Generate compliance report (SOC2, ISO27001, PCI-DSS, HIPAA, GDPR).
- **`deltacode compliance summary`** — Executive summary.
- **`deltacode trend`** — Security finding trend analysis.
- **`deltacode risk`** — Risk scoring dashboard.
- **`deltacode evidence`** — Compliance evidence collection.

## Knowledge & Feedback

- **`deltacode knowledge`** — Organizational knowledge base.
- **`deltacode feedback`** — Feedback loop — ratings, suggestions, effectiveness tracking.

## Research

- **`deltacode research`** — Browser-based CVE research, vendor advisories, RSS aggregation.
- **`deltacode mcp`** — MCP tool integration (8 connectors, 34 tools).

## Interactive Session

- **`deltacode chat`** — Start an interactive security assessment session.

## Diagnostics

- **`deltacode doctor`** — System diagnostics and health check.

## Global Options

| Flag | Description |
|------|-------------|
| `--help` | Show help message and exit |
| `--version` | Show version and exit |

## Common Usage Examples

```bash
# Full security audit of a project
deltacode deps
deltacode secrets
deltacode rules scan ./src
deltacode audit ./src
deltacode assess
deltacode plan

# Quick security check
deltacode supply-chain --brief
deltacode deps --brief
deltacode cwe 79 --remediation

# Compliance report
deltacode compliance report --framework hipaa --target ./
deltacode compliance summary --framework soc2

# Autonomous pipeline
deltacode pipeline run --auto-approve
deltacode trend snapshot
deltacode trend summary

# Threat intelligence
deltacode threat intel --query "CVE-2024-21626"
deltacode threat trending --limit 10

# Sandbox testing
deltacode sandbox create --image python:3.10-slim
deltacode sandbox exec --container-id <id> --command "bandit -r /workspace"

# MCP research
deltacode mcp search-cve --query "nginx"
deltacode mcp get-cve --cve-id "CVE-2024-21626"
deltacode mcp search-cwe --query "injection"

# Diagnostics
deltacode doctor
deltacode doctor --fix
deltacode doctor --export report.json
```
