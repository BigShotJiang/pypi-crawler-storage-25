"""Interactive security assessment chat session with streaming and token tracking."""

from __future__ import annotations

from typing import Optional

from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text

from deltacode.client.api import ChatMessage, DeltaAIClient
from deltacode.core.config import DATA_DIR, DeltaCodeConfig
from deltacode.core.prompts import get_prompt_template
from deltacode.core.logger import get_logger

logger = get_logger(__name__)
console = Console()


class InteractiveChat:
    def __init__(
        self,
        config: DeltaCodeConfig,
        category: str = "pentesting",
        model: str = "deltaai-rag",
        temperature: float = 0.3,
        max_tokens: int = 8192,
        stream: bool = True,
    ):
        self.config = config
        self.category = category
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.stream = stream
        self.client = DeltaAIClient(config)
        self.history: list[ChatMessage] = []
        self._refusal_retries = 0
        self._max_retries = 3
        self._session_tokens = 0
        self._session_requests = 0

    def run(self):
        console.print(Panel(
            f"[bold]DeltaCode Security Assessment[/bold]\n"
            f"Category: {self.category}\n"
            f"Model: {self.model}\n"
            f"Streaming: {'on' if self.stream else 'off'}\n"
            f"Commands: /clear, /category, /model, /stream, /status, /retry, /context, /help, /quit",
            title="DeltaCode Chat",
        ))

        history_file = DATA_DIR / "chat_history"
        history_file.parent.mkdir(parents=True, exist_ok=True)
        session: PromptSession = PromptSession(history=FileHistory(str(history_file)))

        while True:
            try:
                user_input = session.prompt(
                    "\n[deltacode]> ",
                ).strip()
            except (KeyboardInterrupt, EOFError):
                break

            if not user_input:
                continue

            if user_input.startswith("/"):
                if self._handle_command(user_input):
                    continue
                else:
                    break

            self.history.append(ChatMessage(role="user", content=user_input))
            self._send_query()

        self._print_session_summary()
        self.client.close()
        console.print("[dim]Session ended.[/dim]")

    def _handle_command(self, cmd: str) -> bool:
        parts = cmd.split(maxsplit=1)
        command = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        if command in ("/quit", "/exit", "/q"):
            return False
        elif command == "/clear":
            self.history.clear()
            self._refusal_retries = 0
            console.print("[green]History cleared.[/green]")
        elif command == "/category":
            if arg:
                self.category = arg.strip()
                console.print(f"[green]Category:[/green] {self.category}")
            else:
                console.print(f"Current category: {self.category}")
        elif command == "/model":
            if arg:
                self.model = arg.strip()
                console.print(f"[green]Model:[/green] {self.model}")
            else:
                console.print(f"Current model: {self.model}")
        elif command == "/stream":
            self.stream = not self.stream
            console.print(f"Streaming: {'on' if self.stream else 'off'}")
        elif command == "/status":
            stats = self.client.usage_stats
            console.print(
                f"Category: {self.category}\n"
                f"Model: {self.model}\n"
                f"Streaming: {'on' if self.stream else 'off'}\n"
                f"Messages: {len(self.history)}\n"
                f"Session requests: {self._session_requests}\n"
                f"Session tokens: {self._session_tokens}\n"
                f"Total requests: {stats['total_requests']}\n"
                f"Total tokens: {stats['total_tokens']}\n"
                f"Prompt tokens: {stats['total_prompt_tokens']}\n"
                f"Completion tokens: {stats['total_completion_tokens']}"
            )
        elif command == "/retry":
            if self.history:
                console.print("[cyan]Retrying last query with different temperature...[/cyan]")
                self._refusal_retries = 0
                self._send_query(temperature_override=1.0)
        elif command == "/context":
            self._show_context_info()
        elif command == "/help":
            console.print(
                "Commands:\n"
                "  /clear    - Clear conversation history\n"
                "  /category - Set/view security category\n"
                "  /model    - Set/view model\n"
                "  /stream   - Toggle streaming on/off\n"
                "  /status   - Show session stats\n"
                "  /retry    - Retry with different temperature\n"
                "  /context  - Show context window info\n"
                "  /quit     - Exit session"
            )
        else:
            console.print(f"[yellow]Unknown command:[/yellow] {command}")
        return True

    def _show_context_info(self):
        template = get_prompt_template(self.category)
        system_msg = self._build_system_message()
        all_messages = [system_msg] + self.history
        tokens = self.client.estimate_tokens(system_msg.content)
        for m in self.history:
            tokens += self.client.estimate_tokens(m.content)
        console.print(
            f"Context window estimate:\n"
            f"  Total messages: {len(all_messages)}\n"
            f"  Estimated tokens: {tokens}\n"
            f"  Max context: 128K tokens\n"
            f"  Reserve for response: {self.max_tokens} tokens\n"
            f"  Available: ~{128000 - self.max_tokens - tokens} tokens remaining"
        )

    def _build_system_message(self) -> ChatMessage:
        template = get_prompt_template(self.category)
        system_content = template["system"]
        if len(self.history) > 2:
            system_content += "\n\nPrevious conversation context is available. Continue the analysis."
        return ChatMessage(role="system", content=system_content)

    def _send_query(self, temperature_override: Optional[float] = None):
        temperature = temperature_override if temperature_override is not None else self.temperature
        system_msg = self._build_system_message()

        messages = [system_msg] + self.history[-20:]
        messages, was_truncated = self.client.check_context_window(
            messages, max_context_tokens=128000, reserve_for_response=self.max_tokens,
        )
        if was_truncated:
            console.print("[yellow]Context truncated to fit within token limit.[/yellow]")

        self._session_requests += 1

        try:
            if self.stream:
                self._send_query_stream(messages, temperature)
            else:
                self._send_query_sync(messages, temperature)
        except Exception as e:
            logger.error(f"Query failed: {e}")
            console.print(f"[red]Error:[/red] {e}")

    def _send_query_sync(self, messages, temperature):
        result = self.client.chat_completion(
            messages=messages,
            model=self.model,
            category=self.category,
            temperature=temperature,
            max_tokens=self.max_tokens,
        )

        if result.was_refused and self._refusal_retries < self._max_retries:
            self._refusal_retries += 1
            temps = [1.0, 0.7, 1.2]
            next_temp = temps[self._refusal_retries % len(temps)]
            console.print(f"[yellow]Refusal detected, retry {self._refusal_retries}/{self._max_retries} (temp={next_temp})[/yellow]")
            self._send_query(temperature_override=next_temp)
            return

        self._refusal_retries = 0
        self.history.append(ChatMessage(role="assistant", content=result.content))
        self._session_tokens += result.total_tokens

        console.print(Panel(
            Markdown(result.content),
            title=f"DeltaCode [{self.category}]",
            subtitle=f"Tokens: {result.prompt_tokens}+{result.completion_tokens}={result.total_tokens} | Model: {result.model}",
        ))

    def _send_query_stream(self, messages, temperature):
        accumulated = ""
        model_name = self.model
        final_usage = None

        try:
            with Live(console=console, refresh_per_second=8) as live:
                for chunk in self.client.chat_completion_stream(
                    messages=messages,
                    model=self.model,
                    category=self.category,
                    temperature=temperature,
                    max_tokens=self.max_tokens,
                ):
                    if chunk.content:
                        accumulated += chunk.content
                        live.update(Panel(
                            Markdown(accumulated),
                            title=f"DeltaCode [{self.category}]",
                            subtitle="Streaming...",
                        ))
                    if chunk.model:
                        model_name = chunk.model
                    if chunk.finish_reason == "stop":
                        final_usage = chunk.usage

            if accumulated and self._is_stream_refusal(accumulated):
                if self._refusal_retries < self._max_retries:
                    self._refusal_retries += 1
                    temps = [1.0, 0.7, 1.2]
                    next_temp = temps[self._refusal_retries % len(temps)]
                    console.print(f"[yellow]Refusal detected, retry {self._refusal_retries}/{self._max_retries}[/yellow]")
                    self._send_query(temperature_override=next_temp)
                    return

            self._refusal_retries = 0
            self.history.append(ChatMessage(role="assistant", content=accumulated))

            prompt_tokens = 0
            completion_tokens = 0
            total_tokens = 0
            if final_usage:
                prompt_tokens = final_usage.get("prompt_tokens", 0)
                completion_tokens = final_usage.get("completion_tokens", 0)
                total_tokens = final_usage.get("total_tokens", 0)
            else:
                total_tokens = self.client.estimate_tokens(accumulated)

            self._session_tokens += total_tokens

            console.print(Panel(
                Markdown(accumulated),
                title=f"DeltaCode [{self.category}]",
                subtitle=f"Tokens: est {total_tokens} | Model: {model_name}",
            ))

        except Exception as e:
            if accumulated:
                console.print(Panel(
                    Markdown(accumulated),
                    title=f"DeltaCode [{self.category}] (stream interrupted)",
                    subtitle=f"Error: {e}",
                ))
            raise

    @staticmethod
    def _is_stream_refusal(text: str) -> bool:
        markers = [
            "i cannot provide", "i can't provide", "i'm unable to",
            "i will not", "not appropriate", "unethical",
        ]
        lower = text[:600].lower()
        return any(m in lower for m in markers)

    def _print_session_summary(self):
        stats = self.client.usage_stats
        console.print(Panel(
            f"Session Summary\n"
            f"Messages: {len(self.history)}\n"
            f"Requests: {self._session_requests}\n"
            f"Session tokens: {self._session_tokens}\n"
            f"Total tokens: {stats['total_tokens']}\n"
            f"Prompt tokens: {stats['total_prompt_tokens']}\n"
            f"Completion tokens: {stats['total_completion_tokens']}",
            title="DeltaCode Session",
        ))