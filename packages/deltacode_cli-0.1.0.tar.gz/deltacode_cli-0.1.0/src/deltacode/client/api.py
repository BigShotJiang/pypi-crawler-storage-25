"""DeltaAI API client for DeltaCode Security CLI.

Communicates with DeltaAI backend for security analysis, vulnerability detection,
and remediation suggestions. Supports streaming and token tracking.
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Generator, Optional

import httpx

from deltacode.core.config import DeltaCodeConfig
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class ChatMessage:
    role: str
    content: str


@dataclass
class ChatCompletionResponse:
    id: str
    content: str
    model: str
    created: int
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    sources: list[dict] = field(default_factory=list)
    category: str = ""
    confidence: float = 0.0
    was_refused: bool = False


@dataclass
class StreamChunk:
    content: str
    model: str = ""
    finish_reason: Optional[str] = None
    usage: Optional[dict] = None


class DeltaAIClient:
    def __init__(self, config: Optional[DeltaCodeConfig] = None):
        self.config = config or DeltaCodeConfig.load()
        self._client: Optional[httpx.Client] = None
        self._total_tokens_used = 0
        self._total_requests = 0
        self._total_prompt_tokens = 0
        self._total_completion_tokens = 0

    @property
    def client(self) -> httpx.Client:
        if self._client is None or self._client.is_closed:
            self._client = httpx.Client(
                base_url=self.config.api_url,
                timeout=180,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self.config.api_key}",
                    "X-DeltaCode-Version": "0.1.0",
                    "X-License-Key": self.config.license_key,
                    "X-Organization": self.config.organization,
                },
            )
        return self._client

    def chat_completion(
        self,
        messages: list[ChatMessage],
        model: str = "deltaai-rag",
        category: str = "general",
        temperature: float = 0.7,
        max_tokens: int = 8192,
        stream: bool = False,
    ) -> ChatCompletionResponse:
        self._total_requests += 1

        payload = {
            "model": model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
            "category": category,
        }

        try:
            resp = self.client.post("/v1/chat/completions", json=payload)
            resp.raise_for_status()
            data = resp.json()

            choice = data.get("choices", [{}])[0]
            message = choice.get("message", {})
            usage = data.get("usage", {})

            content = message.get("content", "")
            was_refused = self._is_refusal(content)

            prompt_tokens = usage.get("prompt_tokens", 0)
            completion_tokens = usage.get("completion_tokens", 0)
            self._total_tokens_used += prompt_tokens + completion_tokens
            self._total_prompt_tokens += prompt_tokens
            self._total_completion_tokens += completion_tokens

            return ChatCompletionResponse(
                id=data.get("id", f"dc-{uuid.uuid4().hex[:12]}"),
                content=content,
                model=data.get("model", model),
                created=data.get("created", int(time.time())),
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=usage.get("total_tokens", 0),
                was_refused=was_refused,
                sources=data.get("sources", []),
                category=data.get("category", category),
            )

        except httpx.ConnectError:
            logger.error(f"Connection failed: {self.config.api_url}")
            raise
        except httpx.TimeoutException:
            logger.error("Request timed out")
            raise
        except httpx.HTTPStatusError as e:
            logger.error(f"API error {e.response.status_code}: {e.response.text[:200]}")
            raise

    def chat_completion_stream(
        self,
        messages: list[ChatMessage],
        model: str = "deltaai-rag",
        category: str = "general",
        temperature: float = 0.7,
        max_tokens: int = 8192,
    ) -> Generator[StreamChunk, None, None]:
        self._total_requests += 1

        payload = {
            "model": model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
            "category": category,
        }

        chunk_content = ""
        chunk_model = model

        try:
            with self.client.stream("POST", "/v1/chat/completions", json=payload, timeout=300) as response:
                response.raise_for_status()
                for line in response.iter_lines():
                    if not line:
                        continue
                    if line.startswith("data: "):
                        data_str = line[6:]
                        if data_str.strip() == "[DONE]":
                            yield StreamChunk(
                                content="",
                                model=chunk_model,
                                finish_reason="stop",
                            )
                            break
                        try:
                            data = json.loads(data_str)
                        except json.JSONDecodeError:
                            continue

                        choices = data.get("choices", [])
                        if choices:
                            delta = choices[0].get("delta", {})
                            content = delta.get("content", "")
                            finish_reason = choices[0].get("finish_reason")
                            chunk_model = data.get("model", chunk_model)

                            if content:
                                chunk_content += content
                                yield StreamChunk(
                                    content=content,
                                    model=chunk_model,
                                    finish_reason=finish_reason,
                                )

                            if finish_reason == "stop":
                                usage = data.get("usage", {})
                                if usage:
                                    pt = usage.get("prompt_tokens", 0)
                                    ct = usage.get("completion_tokens", 0)
                                    self._total_tokens_used += pt + ct
                                    self._total_prompt_tokens += pt
                                    self._total_completion_tokens += ct
                                yield StreamChunk(
                                    content="",
                                    model=chunk_model,
                                    finish_reason="stop",
                                    usage=usage,
                                )
                                break

        except httpx.ConnectError:
            logger.error(f"Connection failed (stream): {self.config.api_url}")
            raise
        except httpx.TimeoutException:
            logger.error("Stream timed out")
            raise
        except httpx.HTTPStatusError as e:
            logger.error(f"Stream API error {e.response.status_code}: {e.response.text[:200]}")
            raise

    def estimate_tokens(self, text: str) -> int:
        char_count = len(text)
        word_count = len(text.split())
        return max(char_count // 4, word_count)

    def check_context_window(
        self,
        messages: list[ChatMessage],
        max_context_tokens: int = 128000,
        reserve_for_response: int = 4096,
    ) -> tuple[list[ChatMessage], bool]:
        estimated_tokens = sum(self.estimate_tokens(m.content) for m in messages)
        available = max_context_tokens - reserve_for_response

        if estimated_tokens <= available:
            return messages, False

        system_messages = [m for m in messages if m.role == "system"]
        non_system = [m for m in messages if m.role != "system"]

        system_tokens = sum(self.estimate_tokens(m.content) for m in system_messages)
        remaining = available - system_tokens

        truncated = list(non_system)
        while truncated:
            token_estimate = sum(self.estimate_tokens(m.content) for m in truncated)
            if token_estimate <= remaining:
                break
            truncated.pop(0)

        result = system_messages + truncated
        was_truncated = len(result) < len(messages)
        if was_truncated:
            logger.info(f"Context truncated: {len(messages)} -> {len(result)} messages")

        return result, was_truncated

    def security_scan(
        self,
        query: str,
        category: str = "pentesting",
        top_k: int = 5,
        context: str = "",
    ) -> ChatCompletionResponse:
        system_msg = ChatMessage(
            role="system",
            content=(
                "You are DeltaCode, a security analysis engine. "
                "Analyze the provided code/context for security vulnerabilities. "
                "Identify: vulnerability type, severity (CRITICAL/HIGH/MEDIUM/LOW/INFO), "
                "affected code, remediation steps. Be specific and technical. "
                "Respond in the same language as the query."
            ),
        )

        user_content = query
        if context:
            user_content = f"Context:\n{context}\n\nQuery: {query}"

        user_msg = ChatMessage(role="user", content=user_content)

        return self.chat_completion(
            messages=[system_msg, user_msg],
            model="deltaai-rag",
            category=category,
            temperature=0.3,
        )

    def validate_license(self) -> dict:
        try:
            resp = self.client.post(
                "/api/license/validate",
                json={
                    "license_key": self.config.license_key,
                    "organization": self.config.organization,
                    "version": "0.1.0",
                },
            )
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                return {"valid": False, "error": "Invalid license key"}
            if e.response.status_code == 403:
                return {"valid": False, "error": "License expired or suspended"}
            return {"valid": False, "error": f"Server error: {e.response.status_code}"}
        except Exception as e:
            return {"valid": False, "error": str(e)}

    def health_check(self) -> dict:
        try:
            resp = self.client.get("/health")
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            return {"status": "error", "detail": str(e)}

    def get_stats(self) -> dict:
        try:
            resp = self.client.get("/api/knowledge/stats")
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            return {"error": str(e)}

    @property
    def usage_stats(self) -> dict:
        return {
            "total_requests": self._total_requests,
            "total_tokens": self._total_tokens_used,
            "total_prompt_tokens": self._total_prompt_tokens,
            "total_completion_tokens": self._total_completion_tokens,
        }

    @staticmethod
    def _is_refusal(text: str) -> bool:
        markers = [
            "i cannot provide", "i can't provide", "i'm unable to",
            "i will not", "not appropriate", "unethical",
            "yasadisi", "etik degil", "yardimci olamam",
            "bu konuda bilgi veremem", "rehberi detaylandiramam",
            "hangi kurum", "yapamam", "veremem",
        ]
        lower = text[:600].lower()
        return any(m in lower for m in markers)

    def close(self):
        if self._client and not self._client.is_closed:
            self._client.close()