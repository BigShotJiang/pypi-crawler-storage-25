"""DeltaCode Security CLI entry point."""

from __future__ import annotations

import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from deltacode import __version__
from deltacode.auth.license import validate_license, check_feature
from deltacode.client.api import DeltaAIClient, ChatMessage
from deltacode.core.audit import audit_logger
from deltacode.core.config import DeltaCodeConfig, CONFIG_DIR, CONFIG_FILE, DATA_DIR
from deltacode.core.logger import get_logger

logger = get_logger(__name__)
console = Console()
app = typer.Typer(
    name="deltacode",
    help="DeltaCode Security CLI - AI-powered security analysis and remediation.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)


def _ensure_configured() -> DeltaCodeConfig:
    config = DeltaCodeConfig.load()
    if not config.is_configured:
        console.print("[red]DeltaCode is not configured.[/red] Run [bold]deltacode auth login[/bold] first.")
        raise typer.Exit(1)
    if not _check_legal_acceptance(config):
        console.print("[yellow]Legal terms not yet accepted.[/yellow] Run [bold]deltacode init[/bold] to accept.")
        raise typer.Exit(1)
    return config


@app.command()
def version():
    """Show DeltaCode version."""
    console.print(f"DeltaCode v{__version__}")
    audit_logger.log_command("version")


DISCLAIMER = """
DeltaCode Security CLI v{version}

By using this software, you agree to the following terms:

1. AUTHORIZATION: You will ONLY scan systems, networks, and applications that
   you own or have explicit written authorization to test.

2. LAWFUL USE: You will NOT use this tool for any illegal, unauthorized,
   or unethical purposes, including but not limited to unauthorized access,
   data theft, or system damage.

3. RESPONSIBILITY: You accept full legal and ethical responsibility for your
   use of this tool. DeltaCode is a security assessment tool, not a weapon.

4. NO WARRANTY: This software is provided "AS IS" without warranty of any kind,
   express or implied. The entire risk as to the quality and performance of the
   software is with you.

5. LIMITATION OF LIABILITY: In no event shall the authors or copyright holders
   be liable for any claim, damages, or other liability arising from your use
   of this software.

6. EXPORT CONTROL: You agree to comply with all applicable export control laws
   and regulations.

Type 'yes' to accept these terms (or 'no' to exit):
"""


def _check_legal_acceptance(config: DeltaCodeConfig) -> bool:
    legal_file = Path(config.config_dir) / "legal_acceptance.json"
    if legal_file.exists():
        try:
            import json
            data = json.loads(legal_file.read_text(encoding="utf-8"))
            if data.get("accepted", False):
                return True
        except Exception:
            pass
    return False


def _accept_legal(config: DeltaCodeConfig):
    legal_file = Path(config.config_dir) / "legal_acceptance.json"
    legal_file.parent.mkdir(parents=True, exist_ok=True)
    import json
    legal_file.write_text(json.dumps({
        "accepted": True,
        "version": __version__,
        "accepted_at": datetime.utcnow().isoformat(),
    }, indent=2), encoding="utf-8")


@app.command()
def init(
    path: Optional[str] = typer.Argument(None, help="Project directory (default: current)"),
):
    """Initialize DeltaCode in a project directory."""
    config = DeltaCodeConfig.load()

    if not _check_legal_acceptance(config):
        console.print(Panel(
            DISCLAIMER.format(version=__version__),
            title="Legal Disclaimer",
            border_style="yellow",
        ))
        response = input(">>> ").strip().lower()
        if response != "yes":
            console.print("[red]You must accept the terms to use DeltaCode.[/red]")
            raise typer.Exit(1)
        _accept_legal(config)
        console.print("[green]Terms accepted.[/green]\n")

    project_dir = Path(path or ".").resolve()

    if not project_dir.exists():
        project_dir.mkdir(parents=True, exist_ok=True)

    delta_dir = project_dir / ".deltacode"
    delta_dir.mkdir(exist_ok=True)

    config_file = delta_dir / "config.yaml"
    if not config_file.exists():
        default_project = DeltaCodeConfig()
        default_project.save(config_file)
        console.print(f"[green]Created[/green] {config_file}")
    else:
        console.print(f"[dim]Already exists:[/dim] {config_file}")

    gitignore = project_dir / ".gitignore"
    gitignore_entry = ".deltacode/"
    if gitignore.exists():
        content = gitignore.read_text(encoding="utf-8")
        if gitignore_entry not in content:
            with open(gitignore, "a", encoding="utf-8") as f:
                f.write(f"\n{gitignore_entry}\n")
            console.print(f"[green]Added[/green] .deltacode/ to .gitignore")
    else:
        gitignore.write_text(f"{gitignore_entry}\n", encoding="utf-8")
        console.print(f"[green]Created[/green] .gitignore with .deltacode/")

    console.print(Panel(
        f"[bold green]DeltaCode initialized[/bold green]\n"
        f"Project: {project_dir}\n"
        f"Config:  {config_file}",
        title="Init Complete",
    ))


@app.command()
def status():
    """Show current configuration and license status."""
    config = DeltaCodeConfig.load()

    table = Table(title="DeltaCode Status", show_header=True, header_style="bold")
    table.add_column("Setting", style="cyan")
    table.add_column("Value")

    masked = config.mask_secrets()
    for key, value in masked.items():
        table.add_row(key, str(value) if value else "[dim]not set[/dim]")

    table.add_row("version", __version__)
    table.add_row("config_dir", str(CONFIG_DIR))
    table.add_row("data_dir", str(DATA_DIR))
    table.add_row("configured", "[green]yes[/green]" if config.is_configured else "[red]no[/red]")
    table.add_row("authenticated", "[green]yes[/green]" if config.is_authenticated else "[red]no[/red]")

    console.print(table)

    if config.is_configured:
        license_info = validate_license(config)
        if license_info.valid:
            console.print(Panel(
                f"[green]License: Valid[/green]\n"
                f"Tier: {license_info.tier}\n"
                f"Org: {license_info.organization}\n"
                f"Expires: {license_info.expires_at or 'N/A'}\n"
                f"Features: {', '.join(license_info.features) or 'all'}",
                title="License",
            ))
        else:
            console.print(Panel(
                f"[red]License: Invalid[/red]\n{license_info.error}",
                title="License",
            ))

        client = DeltaAIClient(config)
        try:
            health = client.health_check()
            if health.get("status") == "ok":
                console.print("[green]API:[/green] Connected")
            else:
                console.print(f"[yellow]API:[/yellow] {health}")
        except Exception:
            console.print("[red]API:[/red] Unreachable")
        finally:
            client.close()


auth_app = typer.Typer(help="Authentication and license management.")
app.add_typer(auth_app, name="auth")


@auth_app.command("login")
def auth_login(
    api_url: str = typer.Option(..., prompt=True, help="DeltaAI API base URL (e.g. https://api.example.com)"),
    api_key: str = typer.Option(..., prompt=True, hide_input=True, help="API key"),
    license_key: str = typer.Option(..., prompt=True, help="DeltaCode license key"),
    organization: str = typer.Option(..., prompt=True, help="Organization domain"),
):
    """Configure API credentials and license."""
    config = DeltaCodeConfig(
        api_url=api_url.rstrip("/"),
        api_key=api_key,
        license_key=license_key,
        organization=organization,
    )

    client = DeltaAIClient(config)
    try:
        health = client.health_check()
    except Exception:
        console.print(f"[red]Cannot reach API at {api_url}[/red]")
        raise typer.Exit(1)
    finally:
        client.close()

    if health.get("status") != "ok":
        console.print(f"[red]API health check failed: {health}[/red]")
        raise typer.Exit(1)

    client2 = DeltaAIClient(config)
    try:
        result = client2.validate_license()
    except Exception as e:
        console.print(f"[red]License validation error: {e}[/red]")
        raise typer.Exit(1)
    finally:
        client2.close()

    if not result.get("valid"):
        console.print(f"[red]License invalid: {result.get('error', 'unknown')}[/red]")
        raise typer.Exit(1)

    config.save()
    audit_logger.log_auth("login", success=True, details={"org": organization, "tier": result.get("tier")})
    console.print(Panel(
        f"[bold green]Authentication successful[/bold green]\n"
        f"API:  {api_url}\n"
        f"Org:  {organization}\n"
        f"Tier: {result.get('tier', 'N/A')}\n"
        f"Config saved to: {CONFIG_FILE}",
        title="Authenticated",
    ))


@auth_app.command("logout")
def auth_logout():
    """Remove stored credentials."""
    config = DeltaCodeConfig()
    config.save()
    console.print("[green]Credentials cleared.[/green]")


@auth_app.command("check")
def auth_check():
    """Verify current license status."""
    config = _ensure_configured()
    license_info = validate_license(config)
    if license_info.valid:
        console.print(f"[green]License valid[/green] — Tier: {license_info.tier}, Org: {license_info.organization}")
    else:
        console.print(f"[red]License invalid[/red] — {license_info.error}")


@app.command()
def chat(
    category: str = typer.Option("pentesting", help="Security category (pentesting, code-review, compliance)"),
    model: str = typer.Option("deltaai-rag", help="Model to use"),
    temperature: float = typer.Option(0.3, help="Temperature (0.0-2.0)"),
):
    """Start an interactive security assessment session."""
    config = _ensure_configured()
    license_info = validate_license(config)
    if not license_info.valid:
        console.print(f"[red]License required.[/red] {license_info.error}")
        raise typer.Exit(1)

    from deltacode.commands.chat import InteractiveChat
    session = InteractiveChat(config, category=category, model=model, temperature=temperature)
    session.run()


@app.command()
def scan(
    query: str = typer.Argument(..., help="Security query or target description"),
    category: str = typer.Option("pentesting", help="Security category"),
    context: Optional[str] = typer.Option(None, help="Additional context (file path or string)"),
):
    """Run a single security scan query."""
    config = _ensure_configured()

    client = DeltaAIClient(config)
    try:
        ctx_text = ""
        if context:
            ctx_path = Path(context)
            if ctx_path.exists():
                ctx_text = ctx_path.read_text(encoding="utf-8", errors="replace")
            else:
                ctx_text = context

        console.print(f"[cyan]Scanning...[/cyan] ({category})")
        result = client.security_scan(query, category=category, context=ctx_text)

        if result.was_refused:
            console.print("[yellow]Warning: Response may contain a refusal.[/yellow]")

        console.print(Panel(result.content, title=f"DeltaCode [{result.model}]", subtitle=f"Tokens: {result.total_tokens}"))
        audit_logger.log_api_call("/v1/chat/completions", "POST", status=200, tokens=result.total_tokens)
    finally:
        client.close()


@app.command()
def autofix(
    path: str = typer.Argument(".", help="Directory or file to auto-fix"),
    findings: Optional[str] = typer.Option(None, help="Findings file (from deltacode audit --output)"),
    category: str = typer.Option("remediation", help="Prompt category for fix generation"),
    max_rounds: int = typer.Option(3, help="Maximum fix-reflection rounds"),
    dry_run: bool = typer.Option(False, help="Show what would be changed without writing"),
):
    """Auto-fix security vulnerabilities found by deltacode audit."""
    from deltacode.core.auto_fix import AutoFixEngine
    from deltacode.core.security_linter import SecurityLinter, scan_directory

    target = Path(path).resolve()
    if not target.exists():
        console.print(f"[red]Path not found:[/red] {target}")
        raise typer.Exit(1)

    config = _ensure_configured()

    findings_list = []

    if findings:
        try:
            import json
            data = json.loads(Path(findings).read_text(encoding="utf-8"))
            if isinstance(data, list):
                findings_list = data
            elif isinstance(data, dict) and "findings" in data:
                findings_list = data["findings"]
        except Exception as e:
            console.print(f"[red]Failed to parse findings file:[/red] {e}")
            raise typer.Exit(1)

    if not findings_list:
        console.print("[cyan]Running security audit to find vulnerabilities...[/cyan]")
        has_semgrep = shutil.which("semgrep") is not None
        has_bandit = shutil.which("bandit") is not None
        if not has_semgrep and not has_bandit:
            console.print("[yellow]No security scanners found.[/yellow] Install at least one:")
            console.print("  pip install semgrep")
            console.print("  pip install bandit")
            raise typer.Exit(1)

        if target.is_file():
            linter = SecurityLinter(root=str(target.parent))
            result = linter.security_scan(str(target))
            if result:
                findings_list.append(result)
        else:
            scan_results = scan_directory(str(target), root=str(target))
            for filepath, report in scan_results:
                findings_list.append(f"File: {filepath}\n{report}")

    if not findings_list:
        console.print("[green]No vulnerabilities found. Nothing to fix.[/green]")
        raise typer.Exit()

    console.print(Panel(f"[bold]Auto-Fix Engine[/bold]\nFindings: {len(findings_list)}\nMax rounds: {max_rounds}\nDry run: {dry_run}", title="DeltaCode Auto-Fix"))

    engine = AutoFixEngine(
        config=config,
        max_reflections=max_rounds,
        dry_run=dry_run,
    )

    session = engine.fix_findings(
        findings=findings_list,
        root_path=str(target) if target.is_dir() else str(target.parent),
        category=category,
    )

    console.print(Panel(
        f"Fixes applied: {session.total_fixes_applied}\n"
        f"Lint failures: {session.total_lint_failures}\n"
        f"Rollbacks: {session.total_rollbacks}\n"
        f"Results: {len(session.results)}",
        title="Auto-Fix Summary",
    ))

    if not dry_run:
        engine.cleanup_backups(str(target) if target.is_dir() else str(target.parent))

    audit_logger.log_command("autofix", {
        "path": str(target),
        "findings": len(findings_list),
        "fixes_applied": session.total_fixes_applied,
        "rollbacks": session.total_rollbacks,
    })


@app.command()
def audit(
    path: str = typer.Argument(".", help="Directory or file to audit"),
    rules: Optional[str] = typer.Option(None, help="semgrep rules (e.g. p/security-audit or comma-separated)"),
    severity: Optional[str] = typer.Option(None, help="Filter by severity (low/medium/high)"),
    ai_analysis: bool = typer.Option(True, help="Send findings to DeltaAI for remediation suggestions"),
):
    """Run local security audit (semgrep + bandit) on a codebase."""
    import shutil
    from deltacode.core.security_linter import SecurityLinter, scan_directory

    target = Path(path).resolve()
    if not target.exists():
        console.print(f"[red]Path not found:[/red] {target}")
        raise typer.Exit(1)

    has_semgrep = shutil.which("semgrep") is not None
    has_bandit = shutil.which("bandit") is not None
    if not has_semgrep and not has_bandit:
        console.print("[yellow]No security scanners found.[/yellow] Install at least one:")
        console.print("  pip install semgrep")
        console.print("  pip install bandit")
        raise typer.Exit(1)

    scanners = []
    if has_semgrep:
        scanners.append("semgrep")
    if has_bandit:
        scanners.append("bandit")
    console.print(f"[dim]Scanners: {', '.join(scanners)}[/dim]")

    rule_list = rules.split(",") if rules else None

    if target.is_file():
        linter = SecurityLinter(root=str(target.parent))
        console.print(f"[cyan]Auditing[/cyan] {target.name}...")
        result = linter.security_scan(str(target), rules=rule_list, severity=severity)
        if result:
            console.print(Panel(result, title="Security Audit"))
            if ai_analysis and config_is_configured():
                _ai_remediation(result, target.name)
        else:
            console.print("[green]No security findings.[/green]")
    else:
        console.print(f"[cyan]Scanning directory[/cyan] {target}...")
        findings = scan_directory(str(target), rules=rule_list, severity=severity, root=str(target))
        if findings:
            console.print(f"[yellow]{len(findings)} file(s) with findings:[/yellow]")
            full_report = ""
            for filepath, report in findings:
                rel = os.path.relpath(filepath, str(target))
                console.print(f"  [dim]{rel}[/dim]")
                full_report += f"\n\n=== {rel} ===\n{report}"

            console.print(Panel(full_report[:8000], title=f"Security Audit — {len(findings)} files"))

            scan_severity = "HIGH" if any("CRITICAL" in r or "HIGH" in r for _, r in findings) else "MEDIUM"
            audit_logger.log_scan(str(target), len(findings), severity=scan_severity)

            if ai_analysis and config_is_configured():
                _ai_remediation(full_report[:8000], str(target))
        else:
            console.print("[green]No security findings.[/green]")
            audit_logger.log_scan(str(target), 0, severity="INFO")


def config_is_configured():
    config = DeltaCodeConfig.load()
    return config.is_configured


def _ai_remediation(report_text, target_name):
    from deltacode.client.api import DeltaAIClient, ChatMessage

    config = DeltaCodeConfig.load()
    client = DeltaAIClient(config)
    try:
        msg = ChatMessage(
            role="user",
            content=(
                f"I ran a security audit on {target_name}. Here are the findings:\n\n"
                f"{report_text}\n\n"
                "Please analyze these findings and provide:\n"
                "1. Severity ranking (most critical first)\n"
                "2. Specific remediation steps for each finding\n"
                "3. Any false positives to ignore\n"
                "Respond in the same language as the findings."
            ),
        )
        system = ChatMessage(
            role="system",
            content="You are DeltaCode, a security analysis engine. Provide detailed remediation advice.",
        )
        console.print("[cyan]Getting AI remediation suggestions...[/cyan]")
        result = client.chat_completion(
            messages=[system, msg],
            model=config.default_model,
            category="code-review",
            temperature=0.3,
        )
        console.print(Panel(result.content, title="AI Remediation", subtitle=f"Model: {result.model}"))
    except Exception as e:
        console.print(f"[yellow]AI analysis unavailable:[/yellow] {e}")
    finally:
        client.close()


@app.command()
def workspace(
    action: str = typer.Argument(..., help="Action: index, list, reset, search"),
    path: Optional[str] = typer.Argument(None, help="Project path"),
    force: bool = typer.Option(False, help="Force re-index (delete existing)"),
):
    """Manage workspace security index."""
    project_dir = Path(path or ".").resolve()

    if action == "index":
        delta_dir = project_dir / ".deltacode"
        delta_dir.mkdir(exist_ok=True)

        from deltacode.core.context_builder import SecurityContextBuilder
        from deltacode.core.semantic_search import SemanticSearch

        builder = SecurityContextBuilder(root_path=str(project_dir))
        scan_result = builder.scan_directory()

        import json
        context_file = delta_dir / "security_context.json"
        context_file.write_text(json.dumps(scan_result, indent=2, ensure_ascii=False))

        summary = scan_result.get("summary", {})
        console.print(f"[green]Workspace indexed:[/green] {project_dir}")
        console.print(f"  Files scanned: {scan_result.get('total_files_scanned', 0)}")
        console.print(f"  Security-relevant: {scan_result.get('security_relevant_files', 0)}")
        console.print(f"  Hotspots: {summary.get('total_hotspots', 0)}")
        console.print(f"  High-risk files: {summary.get('high_risk_files', 0)}")
        console.print(f"  Context saved: {context_file}")

        searcher = SemanticSearch()
        if searcher._is_available:
            idx_result = searcher.index_directory(str(project_dir), force=force)
            console.print(f"  Semantic index: {idx_result.get('indexed', 0)} chunks from {idx_result.get('files_processed', 0)} files")
        else:
            console.print("  [yellow]Semantic search disabled[/yellow] — install chromadb: pip install chromadb")

        console.print("Run [bold]deltacode audit[/bold] to scan or [bold]deltacode search[/bold] to query.")
        audit_logger.log_command("workspace_index", {"path": str(project_dir)})
    elif action == "list":
        delta_dir = project_dir / ".deltacode"
        if delta_dir.exists():
            console.print(f"[green]Workspace found:[/green] {project_dir}")
        else:
            console.print(f"[yellow]No DeltaCode workspace in:[/yellow] {project_dir}")
    elif action == "reset":
        delta_dir = project_dir / ".deltacode"
        if delta_dir.exists():
            import shutil
            shutil.rmtree(delta_dir)
            console.print(f"[green]Workspace reset:[/green] {project_dir}")
        else:
            console.print(f"[yellow]No workspace to reset.[/yellow]")
    else:
        console.print(f"[red]Unknown action:[/red] {action}. Use: index, list, reset, search")


@app.command()
def search(
    query: str = typer.Argument(..., help="Search query for semantic code search"),
    path: str = typer.Option(".", help="Directory to search in"),
    n: int = typer.Option(10, help="Number of results"),
    category: str = typer.Option(None, help="Filter by language category"),
    vulns: bool = typer.Option(False, help="Prioritize vulnerability-relevant results"),
):
    """Semantic code search across the codebase."""
    from deltacode.core.semantic_search import SemanticSearch

    searcher = SemanticSearch()
    if not searcher._is_available:
        console.print("[red]chromadb not installed.[/red] Install: pip install chromadb")
        raise typer.Exit(1)

    target = Path(path).resolve()

    if vulns:
        results = searcher.search_vulnerabilities(str(target), query=query, n_results=n)
    else:
        results = searcher.search(query, n_results=n, category=category)

    if not results:
        console.print("[yellow]No results found. Try indexing first:[/yellow] deltacode workspace index")
        console.print("[dim]Or the index may be empty. Re-index with: deltacode workspace index --force[/dim]")
        raise typer.Exit()

    console.print(Panel(f"Search: [bold]{query}[/bold] ({len(results)} results)", title="DeltaCode Search"))

    for i, r in enumerate(results, 1):
        score_info = ""
        if r.get("security_score"):
            score_info = f" | sec-score: {r['security_score']:.0f}"
        if r.get("hotspot_count"):
            score_info += f" | hotspots: {r['hotspot_count']}"

        distance = r.get("distance", 0)
        console.print(
            f"[bold]{i}.[/bold] {r['path']}:{r['start_line']}-{r['end_line']} "
            f"[dim](distance: {distance:.3f}{score_info})[/dim]"
        )
        preview = r["content"][:120].replace("\n", " ")
        console.print(f"   [dim]{preview}...[/dim]")

    audit_logger.log_command("search", {"query": query, "path": str(target), "results": len(results)})


@app.command()
def deps(
    path: str = typer.Argument(".", help="Project directory to scan"),
    licenses: bool = typer.Option(False, help="Include license compliance check"),
    brief: bool = typer.Option(False, help="Brief output format"),
):
    """Scan dependencies for known vulnerabilities."""
    from deltacode.core.dependency_analyzer import DependencyAnalyzer

    target = Path(path).resolve()
    if not target.exists():
        console.print(f"[red]Path not found:[/red] {target}")
        raise typer.Exit(1)

    analyzer = DependencyAnalyzer(root_path=str(target))
    ecosystems = analyzer.detect_ecosystems()

    if not ecosystems:
        console.print("[yellow]No recognized dependency files found.[/yellow]")
        console.print("[dim]Supported: requirements.txt, package.json, Pipfile, Cargo.toml, go.mod, pom.xml[/dim]")
        raise typer.Exit()

    console.print(f"[cyan]Detected ecosystems:[/cyan] {', '.join(ecosystems.keys())}")

    reports = analyzer.analyze(check_licenses=licenses)
    output = analyzer.format_report(reports, brief=brief)
    console.print(Panel(output, title="Dependency Vulnerability Report"))

    total = sum(len(r.vulnerabilities) for r in reports)
    critical = sum(1 for r in reports for v in r.vulnerabilities if v.severity == "CRITICAL")
    audit_logger.log_command("deps", {"path": str(target), "vulnerabilities": total, "critical": critical})


@app.command("supply-chain")
def supply_chain(
    path: str = typer.Argument(".", help="Project directory to scan"),
    package: str = typer.Option("", help="Detailed report for a specific package"),
    brief: bool = typer.Option(False, help="Brief output format"),
):
    """Assess supply chain risk for project dependencies."""
    from deltacode.core.supply_chain import SupplyChainAnalyzer

    target = Path(path).resolve()
    if not target.exists():
        console.print(f"[red]Path not found:[/red] {target}")
        raise typer.Exit(1)

    analyzer = SupplyChainAnalyzer(root_path=str(target))

    if package:
        report = analyzer.detailed_report(package)
        console.print(Panel(report, title=f"Supply Chain: {package}"))
        return

    risks = analyzer.analyze()
    output = analyzer.format_report(risks, brief=brief)
    console.print(Panel(output, title="Supply Chain Risk Report"))

    critical = sum(1 for r in risks if r.risk_level == "CRITICAL")
    high = sum(1 for r in risks if r.risk_level == "HIGH")
    audit_logger.log_command("supply_chain", {
        "path": str(target), "packages": len(risks),
        "critical": critical, "high": high,
    })


@app.command()
def rules(
    language: str = typer.Option("", help="Filter by language (python, javascript, go)"),
    list_all: bool = typer.Option(False, help="List all available rules"),
    action: str = typer.Argument("scan", help="Action: scan, list, count"),
    path: str = typer.Argument(".", help="Directory or file to scan with custom rules"),
):
    """Manage and apply custom security rules."""
    from deltacode.core.custom_rules import CustomRuleEngine

    if action == "count":
        engine = CustomRuleEngine()
        total = engine.get_rule_count()
        console.print(f"[green]Total custom rules loaded:[/green] {total}")
        return

    if action == "list":
        engine = CustomRuleEngine()
        rules_by_lang = engine.list_rules(language or None)
        count = sum(len(rules) for rules in rules_by_lang.values())
        console.print(f"[green]Custom Rules ({count} total):[/green]")
        for lang, lang_rules in rules_by_lang.items():
            console.print(f"\n  [bold cyan]{lang}[/bold cyan] ({len(lang_rules)} rules)")
            for rule in lang_rules:
                console.print(f"    [{rule.severity}] {rule.message} [dim]{rule.cwe}[/dim]")
                console.print(f"      Pattern: {rule.pattern[:80]}...")
        return

    if action == "scan":
        target_path = Path(path).resolve()
        if not target_path.exists():
            console.print(f"[red]Path not found:[/red] {target_path}")
            raise typer.Exit(1)

        engine = CustomRuleEngine()

        if target_path.is_file():
            files_to_scan = [target_path]
        else:
            files_to_scan = sorted(target_path.rglob("*"))

        findings = []
        for fpath in files_to_scan:
            if not fpath.is_file():
                continue
            ext = fpath.suffix.lower()
            lang = None
            ext_map = {".py": "python", ".pyw": "python", ".js": "javascript", ".ts": "javascript",
                       ".jsx": "javascript", ".tsx": "javascript", ".go": "go"}
            lang = ext_map.get(ext)
            if not lang:
                continue
            try:
                code = fpath.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            matches = engine.scan(code, lang)
            if matches:
                findings.append((str(fpath.relative_to(target_path) if target_path.is_dir() else fpath.name), matches))

        if not findings:
            console.print("[green]No custom rule violations found.[/green]")
            return

        console.print(f"[yellow]Custom rule findings:[/yellow]")
        for fname, matches in findings:
            console.print(f"\n  [bold]{fname}[/bold] ({len(matches)} issues)")
            for m in matches:
                sev = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(m.severity, "⚪")
                cwe_tag = f" ({m.cwe})" if m.cwe else ""
                console.print(f"    L{m.line}: {sev} [{m.severity}]{cwe_tag} {m.message}")
        return

    console.print(f"[red]Unknown action:[/red] {action}. Use: scan, list, count")


@app.command()
def secrets(
    path: str = typer.Argument(".", help="Directory to scan for secrets"),
    no_trufflehog: bool = typer.Option(False, help="Disable TruffleHog scanner"),
    no_gitleaks: bool = typer.Option(False, help="Disable GitLeaks scanner"),
    no_entropy: bool = typer.Option(False, help="Disable entropy-based detection"),
    brief: bool = typer.Option(False, help="Brief output format"),
):
    """Scan for hardcoded secrets, API keys, and credentials."""
    from deltacode.core.secret_scanner import SecretScanner

    target = Path(path).resolve()
    if not target.exists():
        console.print(f"[red]Path not found:[/red] {target}")
        raise typer.Exit(1)

    console.print(f"[cyan]Scanning for secrets in[/cyan] {target}...")
    scanner = SecretScanner(root_path=str(target))

    results = scanner.scan(
        use_trufflehog=not no_trufflehog,
        use_gitleaks=not no_gitleaks,
        scan_entropy=not no_entropy,
    )

    output = scanner.format_findings(results, brief=brief)
    console.print(Panel(output, title="Secret Detection Report"))

    total = results.get("total", 0)
    by_sev = results.get("by_severity", {})
    audit_logger.log_command("secrets", {
        "path": str(target), "total": total,
        "critical": by_sev.get("CRITICAL", 0),
        "high": by_sev.get("HIGH", 0),
        "medium": by_sev.get("MEDIUM", 0),
    })


@app.command(name="cwe")
def cwe_lookup(
    query: str = typer.Argument(None, help="CWE ID (e.g. 79) or keyword search"),
    language: str = typer.Option(None, help="Filter by language (python, javascript, etc.)"),
    category: str = typer.Option(None, help="Filter by category (injection, auth, crypto, etc.)"),
    severity: str = typer.Option(None, help="Filter by severity (CRITICAL, HIGH, MEDIUM, LOW)"),
    remediation: bool = typer.Option(False, help="Show remediation snippet"),
    list_categories: bool = typer.Option(False, help="List all categories"),
):
    """Look up CWE entries and remediation patterns."""
    from deltacode.core.best_practices import (
        get_cwe, search_cwe, get_remediation_snippet,
        get_all_categories, get_cwes_by_category, format_cwe_list,
    )

    if list_categories:
        cats = get_all_categories()
        console.print(Panel("\n".join(f"  [cyan]{c}[/cyan]" for c in cats), title="CWE Categories"))
        return

    if query is None:
        console.print("[yellow]Provide a CWE ID or search keyword.[/yellow] Example: deltacode cwe 79")
        console.print("[dim]Use --list-categories to see all categories.[/dim]")
        raise typer.Exit()

    if query.isdigit() or query.upper().startswith("CWE"):
        entry = get_cwe(query)
        if entry:
            if remediation:
                snippet = get_remediation_snippet(entry.cwe_id, language or "python")
                console.print(Panel(snippet, title=f"{entry.cwe_id}: {entry.name}"))
            else:
                sev_icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(entry.severity, "⚪")
                info = (
                    f"{sev_icon} [bold]{entry.cwe_id}: {entry.name}[/bold]\n\n"
                    f"Severity: {entry.severity}\n"
                    f"Category: {entry.category}\n"
                    f"OWASP: {entry.owasp_mapping}\n"
                    f"Languages: {', '.join(entry.languages)}\n\n"
                    f"{entry.description}\n\n"
                    f"[dim]Use --remediation to see secure code patterns.[/dim]"
                )
                console.print(Panel(info, title="CWE Details"))
                if entry.compliance_mapping:
                    console.print("[dim]Compliance:[/dim] " + ", ".join(f"{k}: {v}" for k, v in entry.compliance_mapping.items()))
        else:
            console.print(f"[yellow]CWE not found in local database:[/yellow] {query}")
    else:
        results = search_cwe(query, language=language, category=category, severity=severity)
        if results:
            output = format_cwe_list(results, brief=False)
            console.print(Panel(output, title=f"Search: {query}"))
        else:
            console.print(f"[yellow]No CWE entries matching:[/yellow] {query}")


@app.command()
def mcp(
    action: str = typer.Argument("info", help="Action: info, tools, execute, stdio, search-cve, get-cve, search-cwe, get-tactic"),
    tool: str = typer.Option("", help="Tool name for execute action (e.g. 'advisory.search_advisories')"),
    params: str = typer.Option("{}", help="JSON params for tool execution"),
    query: str = typer.Option("", help="Search query for search actions"),
    cve_id: str = typer.Option("", help="CVE ID for get-cve action"),
    max_results: int = typer.Option(10, help="Max results for search actions"),
):
    """MCP (Model Context Protocol) server — security tool integration layer.

    Connects to CVE/NVD, MITRE ATT&CK, CWE/CAPEC, Burp Suite, and OWASP ZAP.
    """
    from deltacode.core.mcp_server import MCPServer
    from deltacode.core.mcp_connectors.advisory import AdvisoryConnector
    from deltacode.core.mcp_connectors.knowledge_base import KnowledgeBaseConnector
    from deltacode.core.mcp_connectors.threat_intel import ThreatIntelConnector
    from deltacode.core.mcp_connectors.burp import BurpConnector
    from deltacode.core.mcp_connectors.zap import ZAPConnector
    from deltacode.core.mcp_connectors.vendor_docs import VendorDocsConnector
    from deltacode.core.mcp_connectors.metasploit import MetasploitConnector
    from deltacode.core.mcp_connectors.nessus import NessusConnector

    import json

    server = MCPServer()
    server.register_connector(AdvisoryConnector())
    server.register_connector(KnowledgeBaseConnector())
    server.register_connector(ThreatIntelConnector())
    server.register_connector(BurpConnector())
    server.register_connector(ZAPConnector())
    server.register_connector(VendorDocsConnector())
    server.register_connector(MetasploitConnector())
    server.register_connector(NessusConnector())

    if action == "info":
        info = server.get_info_response()
        console.print(Panel(f"MCP Server Active\nConnectors: {len(info['connectors'])}\nTotal Tools: {info['total_tools']}", title=f"DeltaCode {info['server']} v{info['version']}"))
        for conn in info["connectors"]:
            console.print(f"  [bold cyan]{conn['name']}[/bold cyan] — {conn['description']} [dim]v{conn['version']}[/dim]")
        audit_logger.log_command("mcp_info", {})

    elif action == "tools":
        tools = server.list_tools()
        if not tools:
            console.print("[yellow]No tools registered.[/yellow]")
            return
        console.print(f"[green]MCP Tools ({len(tools)}):[/green]")
        for t in tools:
            console.print(f"  [bold]{t['connector']}.{t['name']}[/bold] — {t['description']} [dim]({t['category']})[/dim]")
        audit_logger.log_command("mcp_tools", {"count": len(tools)})

    elif action == "execute":
        if not tool:
            console.print("[red]Provide --tool (e.g. 'advisory.search_advisories')[/red]")
            raise typer.Exit(1)
        try:
            parsed_params = json.loads(params) if isinstance(params, str) else params
        except json.JSONDecodeError:
            console.print("[red]Invalid JSON for --params[/red]")
            raise typer.Exit(1)

        result = server.handle_request({"tool": tool, "params": parsed_params})
        if result.get("success"):
            data = result.get("data", {})
            console.print(Panel(
                json.dumps(data, indent=2, ensure_ascii=False)[:3000],
                title=f"MCP Result: {tool}",
            ))
        else:
            console.print(f"[red]MCP Error:[/red] {result.get('error', 'unknown')}")
        audit_logger.log_command("mcp_execute", {"tool": tool})

    elif action == "stdio":
        console.print("[yellow]Starting MCP stdio mode...[/yellow]")
        server.handle_stdio()

    elif action == "search-cve":
        keyword = query or tool
        if not keyword:
            console.print("[red]Provide --query for CVE search[/red]")
            raise typer.Exit(1)
        result = server.handle_request({
            "tool": "advisory.search_advisories",
            "params": {"keyword": keyword, "max_results": max_results},
        })
        if result.get("success"):
            data = result.get("data", {})
            results = data.get("results", [])
            console.print(f"[green]Found {len(results)} advisories[/green] for [bold]{keyword}[/bold]")
            for r in results[:max_results]:
                console.print(f"  [bold cyan]{r['id']}[/bold cyan] (CVSS {r.get('score', 'N/A')}, {r.get('severity', 'N/A')})")
                console.print(f"  [dim]{r.get('description', '')[:150]}...[/dim]")
                if r.get("cwes"):
                    console.print(f"  CWEs: {', '.join(r['cwes'])}")
                console.print("")
        else:
            console.print(f"[red]Error:[/red] {result.get('error')}")

    elif action == "get-cve":
        cid = cve_id or query or tool
        if not cid:
            console.print("[red]Provide --cve-id (e.g. 'CVE-2024-21626')[/red]")
            raise typer.Exit(1)
        result = server.handle_request({
            "tool": "advisory.get_cve_details",
            "params": {"cve_id": cid},
        })
        if result.get("success"):
            data = result.get("data", {})
            if data.get("found"):
                cvss = data.get("cvss", {})
                console.print(Panel(
                    f"[bold]{data['cve_id']}[/bold]\n\n"
                    f"Score: {cvss.get('score', 'N/A')} ({cvss.get('severity', 'N/A')})\n"
                    f"Vector: {cvss.get('vector', 'N/A')}\n"
                    f"Published: {data.get('published', 'N/A')}\n"
                    f"Description: {data.get('description', '')[:300]}",
                    title="CVE Details"
                ))
            else:
                console.print(f"[yellow]CVE not found:[/yellow] {cid}")
        else:
            console.print(f"[red]Error:[/red] {result.get('error')}")

    elif action == "search-cwe":
        keyword = query or tool
        if not keyword:
            console.print("[red]Provide --query for CWE search[/red]")
            raise typer.Exit(1)
        result = server.handle_request({
            "tool": "knowledge_base.search_cwe",
            "params": {"query": keyword},
        })
        if result.get("success"):
            data = result.get("data", {})
            results = data.get("results", [])
            console.print(f"[green]Found {len(results)} CWE entries[/green] for [bold]{keyword}[/bold]")
            for r in results[:max_results]:
                console.print(f"  [bold cyan]{r['cwe_id']}[/bold cyan]: {r['name']}")
                console.print(f"  [dim]{r['description'][:150]}...[/dim]")
                console.print(f"  Severity: {r['severity']} | Category: {r['category']}")
                console.print("")
        else:
            console.print(f"[red]Error:[/red] {result.get('error')}")

    elif action == "get-tactic":
        tactic_name = query or tool
        if not tactic_name:
            console.print("[red]Provide --query for tactic (e.g. 'initial-access')[/red]")
            raise typer.Exit(1)
        result = server.handle_request({
            "tool": "threat_intel.get_tactic_techniques",
            "params": {"tactic": tactic_name},
        })
        if result.get("success"):
            data = result.get("data", {})
            techniques = data.get("techniques", [])
            console.print(f"[green]Tactic: {data.get('tactic', tactic_name)}[/green] ({len(techniques)} techniques)")
            for t in techniques[:max_results]:
                console.print(f"  [bold cyan]{t.get('id', '')}[/bold cyan]: {t.get('name', '')}")
                console.print(f"  [dim]{t.get('description', '')[:150]}...[/dim]")
                console.print("")
        else:
            console.print(f"[red]Error:[/red] {result.get('error')}")

    else:
        console.print(f"[red]Unknown action:[/red] {action}")
        console.print("[dim]Available: info, tools, execute, stdio, search-cve, get-cve, search-cwe, get-tactic[/dim]")


@app.command()
def research(
    query: str = typer.Argument(..., help="CVE ID, keyword, or topic to research"),
    cve: str = typer.Option("", help="Specific CVE ID to research (e.g. CVE-2024-21626)"),
    vendor: str = typer.Option("", help="Scrape advisories from a specific vendor (apache, microsoft, etc.)"),
    rss: bool = typer.Option(True, help="Include RSS feed analysis"),
    no_rss: bool = typer.Option(False, help="Skip RSS feed analysis"),
    brief: bool = typer.Option(False, help="Brief output format"),
    export: str = typer.Option("", help="Export results to JSON file"),
):
    """Security research automation — browser agent based CVE research, vendor advisory scraping, and RSS aggregation.

    Uses Playwright headless browser to research CVEs, scrape vendor advisories,
    and aggregate security news from RSS feeds.
    """
    from deltacode.core.security_researcher import SecurityResearcher
    import asyncio

    target_cve = cve or query

    console.print(f"[cyan]Researching:[/cyan] {query}")

    async def _run():
        researcher = SecurityResearcher()
        try:
            has_cve = target_cve.strip().upper().startswith("CVE-")

            if has_cve or not vendor:
                result = await researcher.full_research(
                    query=target_cve,
                    include_vendors=not has_cve and not vendor,
                    include_rss=not no_rss and rss,
                )
            else:
                result = await researcher.scrape_vendor_advisories(vendor)

            if vendor:
                vendor_result = await researcher.scrape_vendor_advisories(vendor)
                result.findings.extend(vendor_result.findings)
                result.citations.extend(vendor_result.citations)

            return result, researcher
        finally:
            await researcher.close()

    try:
        result, researcher = asyncio.run(_run())
    except Exception as e:
        console.print(f"[red]Research failed:[/red] {e}")
        raise typer.Exit(1)

    if not result.findings:
        from deltacode.core.security_researcher import run_research
        api_result = run_research(query=target_cve, include_vendors=bool(vendor), include_rss=not no_rss and rss)
        if api_result.get("findings"):
            for f in api_result["findings"]:
                result.findings.append(f)

    if result.findings:
        report = researcher.format_report(result, brief=brief)
        total_findings = len([f for f in result.findings if "error" not in f])
        console.print(Panel(report[:3000] + ("\n..." if len(report) > 3000 else ""), title=f"Research Results ({total_findings} findings)"))

        if result.ethical_warnings:
            for w in result.ethical_warnings:
                console.print(f"[yellow]Ethical Warning:[/yellow] {w}")

        if export:
            export_path = Path(export)
            data = {
                "query": query,
                "findings": result.findings,
                "citations": [{"url": c.url, "title": c.title, "snippet": c.snippet} for c in result.citations],
                "ethical_warnings": result.ethical_warnings,
            }
            export_path.write_text(json.dumps(data, indent=2, ensure_ascii=False))
            console.print(f"[green]Exported to:[/green] {export_path}")

        audit_logger.log_command("research", {"query": query, "findings": total_findings})
    else:
        console.print("[yellow]No results found for the query.[/yellow]")


@app.command()
def cache(
    action: str = typer.Argument("stats", help="Action: stats, clear, prune"),
    namespace: str = typer.Option("", help="Namespace to clear (leave empty for all)"),
):
    """Manage DeltaCode cache (diskcache-based persistent caching)."""
    from deltacode.core.cache import DeltaCacheManager, DeltaCache

    if action == "stats":
        stats = DeltaCacheManager.get_stats()
        if stats and isinstance(stats, dict):
            has_data = any(isinstance(v, dict) and v.get("size_mb", 0) > 0 for v in stats.values())
            if has_data:
                console.print("[green]Cache Stats:[/green]")
                table = Table(show_header=True, header_style="bold cyan")
                table.add_column("Namespace")
                table.add_column("Size (MB)")
                for ns, info in stats.items():
                    if isinstance(info, dict):
                        table.add_row(ns, str(info.get("size_mb", 0)))
                console.print(table)
            else:
                console.print("[yellow]Cache is empty (no namespaces with data).[/yellow]")
        else:
            console.print("[yellow]Cache is empty or unavailable.[/yellow]")
        total_mb = DeltaCacheManager.size_mb()
        console.print(f"Total cache size: [bold]{total_mb} MB[/bold]")
        audit_logger.log_command("cache_stats", {})

    elif action == "clear":
        if namespace:
            DeltaCache.clear(namespace)
            console.print(f"[green]Cache cleared:[/green] {namespace}")
        else:
            DeltaCacheManager.clear_all()
            console.print("[green]All caches cleared.[/green]")
        audit_logger.log_command("cache_clear", {"namespace": namespace or "all"})

    elif action == "prune":
        DeltaCacheManager.prune_expired()
        console.print("[green]Expired cache entries pruned.[/green]")

    else:
        console.print(f"[red]Unknown action:[/red] {action}. Use: stats, clear, prune")


@app.command()
def assess(
    path: str = typer.Argument(".", help="Project directory to assess"),
    name: str = typer.Option("Security Assessment", help="Assessment plan name"),
    compliance: str = typer.Option("", help="Compliance frameworks (comma-separated: soc2, iso27001, pci_dss, hipaa)"),
    threat_model: bool = typer.Option(False, help="Show STRIDE threat model"),
    brief: bool = typer.Option(False, help="Brief output format"),
    export: str = typer.Option("", help="Export plan to file"),
):
    """Create a security assessment plan with prioritized tasks and attack surface analysis."""
    from deltacode.core.assessment_planner import SecurityAssessmentPlanner

    target = Path(path).resolve()
    if not target.exists():
        console.print(f"[red]Path not found:[/red] {target}")
        raise typer.Exit(1)

    planner = SecurityAssessmentPlanner(project_path=str(target))

    compliance_list = [c.strip() for c in compliance.split(",") if c.strip()] if compliance else None

    try:
        ctx = planner._context_builder
        if ctx is None:
            from deltacode.core.context_builder import SecurityContextBuilder
            ctx = SecurityContextBuilder(root_path=str(target))
            planner._context_builder = ctx
        context_result = ctx.scan_directory()
    except Exception:
        context_result = None

    plan = planner.create_assessment_plan(name, compliance_frameworks=compliance_list, context_result=context_result)

    if threat_model:
        output = planner.get_threat_model(plan)
        console.print(Panel(output[:5000], title=f"Threat Model: {name}"))
    else:
        output = planner.format_plan(plan, brief=brief)
        console.print(Panel(output[:5000], title=f"Assessment Plan: {name}"))

    summary = plan.summary
    console.print(f"\n[bold cyan]Summary:[/bold cyan] {summary.get('total_tasks', 0)} tasks, ~{summary.get('estimated_hours', 0)}h est.")
    if summary.get("compliance_frameworks"):
        console.print(f"[bold green]Compliance:[/bold green] {', '.join(summary['compliance_frameworks'])}")
    console.print(f"[bold]By Severity:[/bold] {', '.join(f'{k}: {v}' for k, v in summary.get('by_severity', {}).items())}")

    if export:
        Path(export).write_text(output, encoding="utf-8")
        console.print(f"[green]Plan exported to:[/green] {export}")

    audit_logger.log_command("assess", {
        "path": str(target), "name": name,
        "tasks": summary.get("total_tasks", 0),
        "compliance": compliance_list,
    })


@app.command()
def plan(
    path: str = typer.Argument(".", help="Project directory with findings"),
    name: str = typer.Option("Remediation Plan", help="Plan name"),
    from_scan: str = typer.Option("", help="Import findings from a scan results file (JSON)"),
    brief: bool = typer.Option(False, help="Brief output format"),
    export: str = typer.Option("", help="Export plan to file"),
):
    """Create a prioritized remediation plan from security findings."""
    from deltacode.core.remediation_planner import RemediationPlanner

    target = Path(path).resolve()
    if not target.exists():
        console.print(f"[red]Path not found:[/red] {target}")
        raise typer.Exit(1)

    findings = []
    if from_scan:
        scan_path = Path(from_scan)
        if scan_path.exists():
            try:
                data = json.loads(scan_path.read_text(encoding="utf-8"))
                findings = data.get("findings", data.get("results", []))
            except Exception:
                console.print(f"[red]Failed to parse scan results:[/red] {from_scan}")
                raise typer.Exit(1)
        else:
            console.print(f"[red]File not found:[/red] {from_scan}")
            raise typer.Exit(1)
    else:
        from deltacode.core.context_builder import SecurityContextBuilder
        ctx = SecurityContextBuilder(root_path=str(target))
        context_result = ctx.scan_directory()
        findings = context_result.get("files", [])
        findings = [
            {
                "id": f"finding_{i}",
                "title": f.get("path", "Unknown"),
                "severity": "HIGH" if f.get("score", 0) > 50 else "MEDIUM" if f.get("score", 0) > 20 else "LOW",
                "effort": "MEDIUM",
                "category": f.get("categories", ["general"])[0] if f.get("categories") else "general",
                "file": f.get("path", ""),
            }
            for i, f in enumerate(findings)
        ]

    if not findings:
        console.print("[yellow]No findings to plan remediation for.[/yellow]")
        raise typer.Exit()

    planner = RemediationPlanner()
    remediation = planner.build_remediation_plan(findings)

    output = planner.format_plan(remediation, brief=brief)
    console.print(Panel(output[:5000], title=f"Remediation Plan: {name}"))

    summary = remediation.summary
    console.print(f"\n[bold cyan]Summary:[/bold cyan] {summary.get('total_tasks', 0)} tasks, ~{summary.get('estimated_hours', 0)}h est.")
    console.print(f"[bold]Critical:[/bold] {summary.get('critical_fixes', 0)} | [bold]High:[/bold] {summary.get('high_fixes', 0)}")
    console.print(f"[bold]High Breakage Risk:[/bold] {summary.get('high_breakage_risk', 0)} | [bold]Phases:[/bold] {summary.get('phases', 0)}")

    if export:
        Path(export).write_text(output, encoding="utf-8")
        console.print(f"[green]Plan exported to:[/green] {export}")

    audit_logger.log_command("plan", {
        "path": str(target), "name": name,
        "tasks": summary.get("total_tasks", 0),
        "critical": summary.get("critical_fixes", 0),
    })


@app.command()
def agent(
    action: str = typer.Argument("status", help="Action: status, run, approve, stop, resume, list"),
    workflow: str = typer.Option("full_assessment", help="Workflow type: full_assessment, quick_scan, analyze_and_fix, compliance_check"),
    target: str = typer.Option(".", help="Target directory for scan/fix"),
    query: str = typer.Option("", help="Research query for researcher agent"),
    cve_id: str = typer.Option("", help="CVE ID for researcher"),
    framework: str = typer.Option("soc2", help="Compliance framework for compliance agent"),
    approval_id: str = typer.Option("", help="Approval ID to approve/reject"),
    approve_action: bool = typer.Option(False, help="Approve a pending approval"),
):
    """Multi-agent security team — Analyzer, Researcher, Fixer, Validator, Compliance, Coordinator.

    Orchestrates automated security workflows with safety controls.
    """
    import asyncio

    from deltacode.core.agents.base import AgentTeam, MessageType, AgentMessage
    from deltacode.core.agents.analyzer import AnalyzerAgent
    from deltacode.core.agents.researcher import ResearcherAgent
    from deltacode.core.agents.fixer import FixerAgent
    from deltacode.core.agents.validator import ValidatorAgent
    from deltacode.core.agents.compliance import ComplianceAgent
    from deltacode.core.agents.coordinator import CoordinatorAgent

    team = AgentTeam(name="delta-security-team")
    coordinator = CoordinatorAgent(team.bus, team=team)
    team.register_agent(AnalyzerAgent(team.bus))
    team.register_agent(ResearcherAgent(team.bus))
    team.register_agent(FixerAgent(team.bus))
    team.register_agent(ValidatorAgent(team.bus))
    team.register_agent(ComplianceAgent(team.bus))
    team.register_agent(coordinator)

    if action == "status":
        status = team.request_status()
        console.print(f"[bold cyan]Agent Team:[/bold cyan] {status.get('team', 'unknown')}")
        console.print(f"[bold]Emergency Stop:[/bold] {'ACTIVE' if status.get('emergency_stop') else 'Inactive'}")
        console.print(f"[bold]Pending Approvals:[/bold] {status.get('pending_approvals', 0)}")
        console.print(f"\n[green]Registered Agents:[/green]")
        for a in status.get("agents", []):
            console.print(f"  [bold]{a['name']}[/bold] ({a['role']}) — {a['status']} — {a['tasks_completed']} tasks")
        audit_logger.log_command("agent_status", {"agents": len(status.get("agents", []))})

    elif action == "list":
        console.print(f"[bold cyan]Agent Team:[/bold cyan] {team.name}")
        for name, agent_obj in team._agents.items():
            caps = agent_obj.get_capabilities()
            console.print(f"\n  [bold]{name}[/bold] ({agent_obj.role.value})")
            for c in caps:
                console.print(f"    - {c}")

    elif action == "run":
        query_target = cve_id or query or target
        console.print(f"[yellow]Running:[/yellow] {workflow} on {query_target}")

        async def _run():
            plan_result = await coordinator.execute_task({
                "action": workflow if workflow in ("full_assessment", "analyze_and_fix", "research_and_report", "compliance_check") else "full_assessment",
                "target": target,
                "query": query_target,
                "frameworks": [framework] if framework else ["soc2"],
                "name": f"Agent Workflow: {workflow}",
            })

            if plan_result.success:
                sub_tasks = plan_result.data.get("sub_tasks", plan_result.data.get("workflow", []))
                if isinstance(sub_tasks, list):
                    all_results = []
                    for t in sub_tasks[:5]:
                        agent_name = t.get("agent", "")
                        agent_obj = team.get_agent(agent_name)
                        if not agent_obj:
                            continue
                        action_name = t.get("action", "scan")
                        approval = team._safety.check_action(action_name, agent_name)
                        if approval == 3:
                            console.print(f"[yellow]Approval required for {agent_name}: {action_name}[/yellow]")
                            continue
                        result = await agent_obj.run_task(t)
                        all_results.append(result)
                        if result.success:
                            console.print(f"[green]{agent_name}:[/green] {result.data.get('total_findings', 'OK')}")
                        else:
                            console.print(f"[red]{agent_name}:[/red] {result.error or 'failed'}")
                    return all_results

            return [plan_result]

        async def _run_simple():
            coordinator_result = await coordinator.execute_task({
                "action": "plan_workflow",
                "workflow": workflow,
                "target": target,
            })
            console.print(f"[bold]Coordinator Plan:[/bold] {coordinator_result.data.get('description', 'N/A')}")
            for phase in coordinator_result.data.get("phases", []):
                console.print(f"  [bold]{phase.get('name', 'Phase')}[/bold]")
                for t in phase.get("tasks", []):
                    console.print(f"    - {t.get('agent')}: {t.get('action')}")
            return [coordinator_result]

        results = asyncio.run(_run_simple())
        console.print(f"[green]Agent workflow completed:[/green] {len(results)} results")
        audit_logger.log_command("agent_run", {"workflow": workflow, "target": target, "results": len(results)})

    elif action == "approve":
        if not approval_id:
            pending = team._safety.pending_approvals
            if not pending:
                console.print("[green]No pending approvals.[/green]")
                return
            console.print(f"[yellow]{len(pending)} pending approvals:[/yellow]")
            for msg in pending:
                console.print(f"  [bold]{msg.id}[/bold]: {msg.sender} — {msg.payload.get('action', 'unknown')}")
                console.print(f"    [dim]Use --approval-id {msg.id} to approve[/dim]")
        else:
            approved = team._safety.approve(approval_id)
            if approved:
                console.print(f"[green]Approved:[/green] {approval_id}")
            else:
                console.print(f"[red]Approval ID not found:[/red] {approval_id}")

    elif action == "stop":
        team.emergency_stop()
        console.print("[red]EMERGENCY STOP ACTIVATED[/red] — all agents stopped")
        audit_logger.log_command("agent_stop", {})

    elif action == "resume":
        team.resume()
        console.print("[green]System resumed[/green]")
        audit_logger.log_command("agent_resume", {})

    else:
        console.print(f"[red]Unknown action:[/red] {action}")
        console.print("[dim]Available: status, list, run, approve, stop, resume[/dim]")


@app.command()
def sandbox(
    action: str = typer.Argument("create", help="Action: create, exec, run, stop, list, snap, cleanup"),
    image: str = typer.Option("python:3.10-slim", help="Docker image to use"),
    command: str = typer.Option("", help="Command to execute in container"),
    code: str = typer.Option("", help="Python code to run in sandbox"),
    memory: str = typer.Option("512m", help="Memory limit (e.g. 256m, 1g)"),
    cpu: float = typer.Option(0.5, help="CPU limit (e.g. 0.5, 1.0, 2.0)"),
    timeout: int = typer.Option(300, help="Timeout in seconds"),
    no_network: bool = typer.Option(True, help="Disable network access"),
    read_only: bool = typer.Option(True, help="Read-only root filesystem"),
    name: str = typer.Option("", help="Container name or snapshot name"),
    container_id: str = typer.Option("", help="Container ID for exec/stop/snap actions"),
):
    """Isolated Docker sandbox for safe security testing.

    Create, manage, and execute code in sandboxed containers with
    enforced resource limits, network isolation, and filesystem constraints.
    """
    from deltacode.core.sandbox import SandboxConfig, SandboxManager, SandboxEnvironment

    if not SandboxManager().is_available:
        console.print("[red]Docker is not available.[/red] Please install Docker Desktop.")
        raise typer.Exit(1)

    if action == "create":
        cfg = SandboxConfig(
            image=image,
            container_name=name or "",
            memory_limit=memory,
            cpu_limit=cpu,
            timeout_seconds=timeout,
            network_disabled=no_network,
            read_only_rootfs=read_only,
        )
        manager = SandboxManager(config=cfg)
        console.print(f"[cyan]Creating sandbox:[/cyan] {image}")
        result = manager.create_container()
        if result.success:
            console.print(f"[green]Sandbox created:[/green] {result.container_id}")
            console.print(f"[dim]Duration: {result.duration_seconds}s[/dim]")
        else:
            console.print(f"[red]Failed:[/red] {result.error}")
        audit_logger.log_command("sandbox_create", {"image": image, "success": result.success})

    elif action == "exec":
        cid = container_id or name
        if not cid:
            console.print("[red]Provide --container-id or --name[/red]")
            raise typer.Exit(1)
        if not command:
            console.print("[red]Provide --command to execute[/red]")
            raise typer.Exit(1)

        manager = SandboxManager()
        result = manager.exec_command(cid, command, timeout=timeout)
        if result.stdout:
            console.print(result.stdout)
        if result.stderr:
            console.print(f"[yellow]{result.stderr}[/yellow]")
        console.print(f"Exit code: {result.exit_code} | Duration: {result.duration_seconds}s")
        audit_logger.log_command("sandbox_exec", {"container": cid, "exit_code": result.exit_code})

    elif action == "run":
        cfg = SandboxConfig(
            image=image,
            memory_limit=memory,
            cpu_limit=cpu,
            timeout_seconds=timeout,
            network_disabled=no_network,
            read_only_rootfs=read_only,
            remove_on_exit=True,
        )
        manager = SandboxManager(config=cfg)

        if code:
            console.print(f"[cyan]Running Python code in sandbox:[/cyan] {image}")
            result = manager.run_isolated_python(code, timeout=timeout)
        elif command:
            container_result = manager.create_container()
            if not container_result.success:
                console.print(f"[red]Container creation failed:[/red] {container_result.error}")
                raise typer.Exit(1)
            result = manager.exec_command(container_result.container_id, command, timeout=timeout)
            manager.stop_container(container_result.container_id, remove=True)
        else:
            console.print("[red]Provide --code or --command to run[/red]")
            raise typer.Exit(1)

        if result.success:
            console.print(f"[green]Success:[/green]")
            if result.stdout:
                console.print(result.stdout[:2000])
            if result.stderr:
                console.print(f"[yellow]stderr:[/yellow] {result.stderr[:500]}")
        else:
            console.print(f"[red]Error:[/red] {result.error}")
        console.print(f"[dim]Exit: {result.exit_code} | Duration: {result.duration_seconds}s[/dim]")
        audit_logger.log_command("sandbox_run", {"image": image, "success": result.success})

    elif action == "stop":
        cid = container_id or name
        if not cid:
            console.print("[red]Provide --container-id or --name[/red]")
            raise typer.Exit(1)
        manager = SandboxManager()
        result = manager.stop_container(cid, remove=True)
        if result.success:
            console.print(f"[green]Container stopped and removed:[/green] {cid}")
        else:
            console.print(f"[red]Failed:[/red] {result.error}")

    elif action == "list":
        manager = SandboxManager()
        containers = manager.list_containers(all_containers=True)
        if not containers:
            console.print("[yellow]No containers found.[/yellow]")
            return
        for c in containers:
            image_name = c.get("Image", "?")
            cid = c.get("ID", "?")[:12]
            status = c.get("Status", "?")
            name = c.get("Names", c.get("Name", "?"))
            if isinstance(name, list):
                name = name[0]
            console.print(f"  {cid} {image_name} {status} [dim]{name}[/dim]")

    elif action == "snap":
        cid = container_id or name
        if not cid:
            console.print("[red]Provide --container-id or --name[/red]")
            raise typer.Exit(1)
        manager = SandboxManager()
        snapshot = manager.create_snapshot(cid, name or "snapshot")
        console.print(f"[green]Snapshot created:[/green] {snapshot.name}")
        console.print(f"[dim]Container: {snapshot.container_id} at {snapshot.created_at}[/dim]")

    elif action == "cleanup":
        from deltacode.core.sandbox import SandboxManager as SM
        manager = SM()
        manager.cleanup_all()
        console.print("[green]All sandbox containers cleaned up.[/green]")

    else:
        console.print(f"[red]Unknown action:[/red] {action}")
        console.print("[dim]Available: create, exec, run, stop, list, snap, cleanup[/dim]")


@app.command()
def pipeline(
    action: str = typer.Argument("run", help="Action: run, rollback, status"),
    target: str = typer.Option(".", help="Target directory"),
    name: str = typer.Option("pipeline", help="Pipeline name"),
    auto_approve: bool = typer.Option(False, help="Auto-approve all stages"),
    skip: str = typer.Option("", help="Comma-separated stages to skip"),
):
    """Run autonomous security pipeline: scan → analyze → fix → validate → compliance."""
    import asyncio
    from deltacode.core.pipeline import SecurityPipeline

    if action == "run":
        pipeline_obj = SecurityPipeline(target=str(Path(target).resolve()), name=name)
        skip_stages = [s.strip() for s in skip.split(",") if s.strip()] if skip else []
        console.print(f"[cyan]Pipeline:[/cyan] {name} on {target}")
        console.print(f"[dim]Stages: scan, analyze, research, plan, fix, validate, compliance[/dim]")
        if auto_approve:
            console.print("[dim]Auto-approve: enabled[/dim]")
        if skip_stages:
            console.print(f"[dim]Skipping: {', '.join(skip_stages)}[/dim]")

        result = asyncio.run(pipeline_obj.run(auto_approve=auto_approve, skip_stages=skip_stages))
        summary = result.to_dict()
        console.print(f"\n[bold]Result:[/bold] {summary.get('status', 'unknown')}")
        console.print(f"Findings: {summary.get('total_findings', 0)} | Fixes: {summary.get('fixes_applied', 0)}")
        console.print(f"Validations passed: {summary.get('validation_passed', 0)} | failed: {summary.get('validation_failed', 0)}")
        console.print(f"[dim]Duration: {summary.get('total_duration_ms', 0)}ms[/dim]")
        if summary.get("requires_human_review"):
            console.print("[yellow]Human review required — some validations failed.[/yellow]")
        audit_logger.log_command("pipeline_run", {"name": name, "status": summary.get("status")})

    elif action == "rollback":
        console.print("[yellow]Rollback requires a previous pipeline result ID.[/yellow]")

    elif action == "status":
        pipeline_obj = SecurityPipeline(target=str(Path(target).resolve()), name=name)
        status = pipeline_obj.get_status()
        console.print(f"[bold]Pipeline:[/bold] {status.get('name')}")
        console.print(f"Target: {status.get('target')}")
        team_status = status.get("team_status", {})
        for agent in team_status.get("agents", []):
            console.print(f"  {agent.get('name')}: {agent.get('status')} ({agent.get('tasks_completed')} tasks)")
    else:
        console.print(f"[red]Unknown action: {action}[/red]")


@app.command()
def schedule(
    action: str = typer.Argument("list", help="Action: list, add, remove, run, start, stop"),
    name: str = typer.Option("", help="Schedule name"),
    interval: int = typer.Option(60, help="Interval in minutes"),
    target: str = typer.Option(".", help="Target directory"),
    auto_approve: bool = typer.Option(False, help="Auto-approve pipeline stages"),
):
    """Manage scheduled security assessments."""
    from deltacode.core.scheduler import PipelineScheduler, ScheduleConfig

    scheduler = PipelineScheduler()

    if action == "list":
        schedules = scheduler.list_schedules()
        if not schedules:
            console.print("[yellow]No schedules configured.[/yellow]")
            return
        console.print(f"[green]{len(schedules)} schedules:[/green]")
        for s in schedules:
            status_icon = "✅" if s.enabled else "⏸"
            console.print(f"  {status_icon} [bold]{s.name}[/bold] — every {s.interval_minutes}min, target: {s.target}")
            runs = scheduler.get_runs(s.name, limit=3)
            if runs:
                latest = runs[-1]
                console.print(f"    Last run: {latest.status} at {latest.started_at[:19]}")

    elif action == "add":
        if not name:
            console.print("[red]Provide --name for the schedule[/red]")
            raise typer.Exit(1)
        cfg = ScheduleConfig(name=name, target=str(Path(target).resolve()), interval_minutes=interval, auto_approve=auto_approve)
        scheduler.add_schedule(cfg)
        console.print(f"[green]Schedule added:[/green] {name} (every {interval}min)")

    elif action == "remove":
        if not name:
            console.print("[red]Provide --name to remove[/red]")
            raise typer.Exit(1)
        if scheduler.remove_schedule(name):
            console.print(f"[green]Schedule removed:[/green] {name}")
        else:
            console.print(f"[red]Schedule not found:[/red] {name}")

    elif action == "run":
        if not name:
            console.print("[red]Provide --name to run[/red]")
            raise typer.Exit(1)
        console.print(f"[cyan]Running schedule:[/cyan] {name}")
        result = scheduler.run_once(name)
        run = result.get("run", {})
        console.print(f"Status: {run.get('status', 'unknown')}")
        console.print(f"[dim]Run ID: {run.get('run_id', '')}[/dim]")
        audit_logger.log_command("schedule_run", {"name": name, "status": run.get("status")})

    elif action == "start":
        scheduler.start()
        console.print("[green]Scheduler started (background thread)[/green]")
        audit_logger.log_command("schedule_start", {})

    elif action == "stop":
        scheduler.stop()
        console.print("[yellow]Scheduler stopped[/yellow]")

    else:
        console.print(f"[red]Unknown action: {action}[/red]")

    scheduler._save()


@app.command()
def incident(
    action: str = typer.Argument("list", help="Action: list, create, contain, resolve, postmortem"),
    title: str = typer.Option("", help="Incident title"),
    severity: str = typer.Option("HIGH", help="Incident severity (CRITICAL, HIGH, MEDIUM, LOW)"),
    source: str = typer.Option("delta-pipeline", help="Incident source"),
    description: str = typer.Option("", help="Incident description"),
    incident_id: str = typer.Option("", help="Incident ID for contain/resolve/postmortem"),
    resolution: str = typer.Option("", help="Resolution notes for resolve action"),
    export: str = typer.Option("", help="Export path for postmortem"),
):
    """Incident response automation — detect, contain, resolve, postmortem."""
    from deltacode.core.incident_response import IncidentResponder

    responder = IncidentResponder()

    if action == "list":
        incidents = responder.list_incidents(limit=20)
        if not incidents:
            console.print("[yellow]No incidents recorded.[/yellow]")
            return
        console.print(f"[green]{len(incidents)} incidents:[/green]")
        for inc in incidents:
            icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(inc.severity, "⚪")
            console.print(f"  {icon} [bold]{inc.id}[/bold] — {inc.title[:60]}")
            console.print(f"    Severity: {inc.severity} | Status: {inc.status} | {inc.detected_at[:19]}")

    elif action == "create":
        if not title or not description:
            console.print("[red]Provide --title and --description[/red]")
            raise typer.Exit(1)
        inc = responder.create_incident(title=title, severity=severity, source=source, description=description)
        console.print(f"[red]Incident created:[/red] {inc.id} ({severity})")
        console.print(f"Title: {inc.title}")
        console.print(f"[dim]Run auto-containment: deltacode incident contain --incident-id {inc.id}[/dim]")
        audit_logger.log_command("incident_create", {"id": inc.id, "severity": severity})

    elif action == "contain":
        if not incident_id:
            console.print("[red]Provide --incident-id[/red]")
            raise typer.Exit(1)
        result = responder.auto_contain(incident_id)
        if "error" in result:
            console.print(f"[red]{result['error']}[/red]")
        else:
            console.print(f"[yellow]Containment actions for {incident_id}:[/yellow]")
            for action_item in result.get("actions", []):
                console.print(f"  ✅ {action_item.get('action')}: {action_item.get('details', '')}")
            audit_logger.log_command("incident_contain", {"id": incident_id})

    elif action == "resolve":
        if not incident_id or not resolution:
            console.print("[red]Provide --incident-id and --resolution[/red]")
            raise typer.Exit(1)
        result = responder.resolve_incident(incident_id, resolution)
        if "error" in result:
            console.print(f"[red]{result['error']}[/red]")
        else:
            console.print(f"[green]Incident {incident_id} resolved.[/green]")
            audit_logger.log_command("incident_resolve", {"id": incident_id})

    elif action == "postmortem":
        if not incident_id:
            console.print("[red]Provide --incident-id[/red]")
            raise typer.Exit(1)
        report = responder.generate_postmortem(incident_id)
        if export:
            Path(export).write_text(report, encoding="utf-8")
            console.print(f"[green]Post-mortem exported to:[/green] {export}")
        else:
            console.print(Panel(report[:3000], title=f"Post-Mortem: {incident_id}"))

    else:
        console.print(f"[red]Unknown action: {action}[/red]")


@app.command()
def anomaly(
    action: str = typer.Argument("stats", help="Action: stats, alerts, patterns, resolve"),
    severity: str = typer.Option("", help="Filter by severity (HIGH, MEDIUM, LOW)"),
    alert_index: int = typer.Option(-1, help="Alert index to resolve"),
):
    """Detect and monitor anomalous usage patterns and misuse."""
    from deltacode.core.anomaly_detector import AnomalyDetector

    detector = AnomalyDetector()

    if action == "stats":
        stats = detector.get_stats()
        console.print(f"[bold cyan]Anomaly Detector Stats:[/bold cyan]")
        console.print(f"Total events: {stats.get('total_events', 0)}")
        console.print(f"Last hour: {stats.get('events_last_hour', 0)} | Last 24h: {stats.get('events_last_24h', 0)}")
        console.print(f"Active alerts: {stats.get('active_alerts', 0)}")
        console.print(f"Alerts by severity: {stats.get('alerts_by_severity', {})}")
        audit_logger.log_command("anomaly_stats", {})

    elif action == "alerts":
        alerts = detector.get_alerts(severity=severity if severity else None, limit=30)
        if not alerts:
            console.print("[green]No alerts.[/green]")
            return
        console.print(f"[yellow]{len(alerts)} alerts:[/yellow]")
        for i, a in enumerate(alerts):
            status = "✅ Resolved" if a.resolved else "⚠ Active"
            icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(a.severity, "⚪")
            console.print(f"  [{i}] {icon} [{a.severity}] {a.message[:80]} {status}")
            console.print(f"      {a.timestamp[:19]} | {a.alert_type}")

    elif action == "patterns":
        patterns = detector.get_usage_patterns()
        console.print("[bold cyan]Usage Patterns:[/bold cyan]")
        console.print(f"Success rate: {patterns.get('success_rate', 0)}%")
        console.print(f"\nTop commands:")
        for cmd, count in patterns.get("top_commands", []):
            console.print(f"  {cmd}: {count}")
        console.print(f"\nHour distribution:")
        for h, count in sorted(patterns.get("hour_distribution", {}).items()):
            bar = "█" * min(count, 20)
            console.print(f"  {h:02d}:00 {bar} {count}")

    elif action == "resolve":
        if alert_index < 0:
            alerts = detector.get_alerts(limit=50)
            unresolved = [(i, a) for i, a in enumerate(alerts) if not a.resolved]
            if not unresolved:
                console.print("[green]No unresolved alerts.[/green]")
                return
            console.print("[yellow]Unresolved alerts (use --alert-index N to resolve):[/yellow]")
            for i, a in unresolved[:10]:
                console.print(f"  [{i}] [{a.severity}] {a.message[:80]}")
        else:
            if detector.resolve_alert(alert_index):
                console.print(f"[green]Alert {alert_index} resolved.[/green]")
            else:
                console.print(f"[red]Alert index {alert_index} not found.[/red]")

    else:
        console.print(f"[red]Unknown action: {action}[/red]")


@app.command()
def trail(
    action: str = typer.Argument("log", help="Action: log, trail, stats"),
    limit: int = typer.Option(50, help="Number of entries to show"),
):
    """View action logs and audit trail for all security operations."""
    from deltacode.core.agents.base import AgentTeam

    team = AgentTeam()

    if action == "log":
        log = team.get_action_log(limit=limit)
        if not log:
            console.print("[yellow]No action log entries.[/yellow]")
            return
        console.print(f"[bold cyan]Action Log ({len(log)} entries):[/bold cyan]")
        for entry in log[-limit:]:
            ts = entry.get("timestamp", "")[:19]
            action_name = entry.get("action", entry.get("type", "unknown"))
            agent = entry.get("agent", "")
            approved = entry.get("approved", False)
            status = "✅" if approved else "⏳"
            console.print(f"  {status} [{ts}] {action_name} by {agent}")

    elif action == "trail":
        trail = team.get_audit_trail()
        if not trail:
            console.print("[yellow]No audit trail entries.[/yellow]")
            return
        console.print(f"[bold cyan]Audit Trail ({len(trail)} entries):[/bold cyan]")
        for entry in trail[-limit:]:
            console.print(f"  [{entry.get('timestamp', '')[:19]}] {entry.get('sender', '?')} -> {entry.get('recipient', '?')} | {entry.get('type', '?')}")

    elif action == "stats":
        log = team.get_action_log()
        trail = team.get_audit_trail()
        console.print(f"[bold cyan]Audit Statistics:[/bold cyan]")
        console.print(f"Action log entries: {len(log)}")
        console.print(f"Audit trail entries: {len(trail)}")
        audit_logger.log_command("audit_stats", {"action_log": len(log), "trail": len(trail)})

    else:
        console.print(f"[red]Unknown action: {action}[/red]")


@app.command()
def review(
    action: str = typer.Argument("list", help="Action: list, resolve, submit"),
    title: str = typer.Option("", help="Decision title for submit action"),
    description: str = typer.Option("", help="Decision description"),
    decision_id: str = typer.Option("", help="Decision ID to resolve"),
    outcome: str = typer.Option("approved", help="Outcome: approved, rejected, deferred"),
):
    """Review and resolve pending agent decisions."""
    from deltacode.core.agents.base import AgentTeam

    team = AgentTeam()

    if action == "list":
        decisions = team.get_pending_decisions()
        if not decisions:
            console.print("[green]No pending decisions.[/green]")
            return
        console.print(f"[yellow]{len(decisions)} pending decisions:[/yellow]")
        for d in decisions:
            console.print(f"  [bold]{d.get('id', '?')}[/bold]: {d.get('title', '?')}")
            console.print(f"    {d.get('description', '')}")

    elif action == "resolve":
        if not decision_id:
            console.print("[red]Provide --decision-id[/red]")
            raise typer.Exit(1)
        if team.resolve_decision(decision_id, outcome):
            console.print(f"[green]Decision {decision_id} resolved: {outcome}[/green]")
            audit_logger.log_command("review_resolve", {"decision_id": decision_id, "outcome": outcome})
        else:
            console.print(f"[red]Decision {decision_id} not found.[/red]")

    elif action == "submit":
        if not title or not description:
            console.print("[red]Provide --title and --description[/red]")
            raise typer.Exit(1)
        did = team.submit_for_review(title, description)
        console.print(f"[green]Decision submitted for review:[/green] {did}")
        audit_logger.log_command("review_submit", {"id": did})

    else:
        console.print(f"[red]Unknown action: {action}[/red]")


@app.command()
def knowledge(
    action: str = typer.Argument("list", help="Action: list, add, search, get, delete, tags, rules, projects"),
    query: str = typer.Option("", help="Search query"),
    entry_type: str = typer.Option("", help="Entry type filter"),
    title: str = typer.Option("", help="Entry title for add action"),
    content: str = typer.Option("", help="Entry content for add action"),
    tags: str = typer.Option("", help="Comma-separated tags"),
    project: str = typer.Option("", help="Project path filter"),
    entry_id: str = typer.Option("", help="Entry ID for get/delete"),
    language: str = typer.Option("", help="Language filter for rules"),
    limit: int = typer.Option(20, help="Max results"),
):
    """Organizational knowledge base — vulnerability patterns, context, learned rules."""
    from deltacode.core.knowledge_base import OrgKnowledgeBase

    kb = OrgKnowledgeBase()

    if action == "list":
        if entry_type:
            entries = kb.get_entries_by_type(entry_type)
        else:
            entries = kb._entries
        if not entries:
            console.print("[yellow]No knowledge entries.[/yellow]")
            return
        console.print(f"[green]{len(entries)} entries:[/green]")
        for e in entries[-limit:]:
            console.print(f"  [bold]{e.id}[/bold] ({e.entry_type}) {e.title[:60]}")
            console.print(f"    [dim]Tags: {', '.join(e.tags[:5])}[/dim]")

    elif action == "add":
        if not title or not content:
            console.print("[red]Provide --title and --content[/red]")
            raise typer.Exit(1)
        tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []
        entry = kb.add_entry(
            entry_type=entry_type or "general",
            title=title,
            content=content,
            tags=tag_list,
            project=project or "",
        )
        console.print(f"[green]Entry added:[/green] {entry.id}")

    elif action == "search":
        if not query:
            console.print("[red]Provide --query[/red]")
            raise typer.Exit(1)
        results = kb.search_entries(query, entry_type=entry_type or None,
                                    project=project or None, limit=limit)
        if not results:
            console.print("[yellow]No matching entries.[/yellow]")
            return
        console.print(f"[green]{len(results)} results for:[/green] {query}")
        for e in results:
            sev = e.metadata.get("severity", "")
            icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡"}.get(sev, "📄")
            console.print(f"  {icon} [bold]{e.id}[/bold] {e.title[:60]}")
            console.print(f"    [dim]{e.content[:120]}...[/dim]")

    elif action == "get":
        if not entry_id:
            console.print("[red]Provide --entry-id[/red]")
            raise typer.Exit(1)
        entry = kb.get_entry(entry_id)
        if not entry:
            console.print(f"[red]Entry not found:[/red] {entry_id}")
            return
        console.print(f"[bold]{entry.title}[/bold] ({entry.entry_type})")
        console.print(f"ID: {entry.id} | Created: {entry.created_at[:19]}")
        console.print(f"Tags: {', '.join(entry.tags)}")
        console.print(f"Content:")
        console.print(f"  {entry.content[:1000]}")

    elif action == "delete":
        if not entry_id:
            console.print("[red]Provide --entry-id[/red]")
            raise typer.Exit(1)
        if kb.delete_entry(entry_id):
            console.print(f"[green]Entry deleted:[/green] {entry_id}")
        else:
            console.print(f"[red]Entry not found:[/red] {entry_id}")

    elif action == "tags":
        tags = kb.get_tags_cloud()
        console.print(f"[bold cyan]Tag Cloud ({len(tags)}):[/bold cyan]")
        for tag, count in tags.items():
            bar = "█" * min(count, 20)
            console.print(f"  {tag}: {bar} {count}")

    elif action == "rules":
        rules = kb.get_active_rules(language=language or None)
        if not rules:
            console.print("[yellow]No learned rules.[/yellow]")
            return
        console.print(f"[green]{len(rules)} learned rules:[/green]")
        for r in rules:
            icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(r.severity, "⚪")
            console.print(f"  {icon} {r.message[:60]} [{r.severity}, {r.language}]")
            console.print(f"    Accuracy: {r.accuracy:.0%} | Findings: {r.source_findings_count}")

    elif action == "projects":
        projects = kb.list_projects()
        if not projects:
            console.print("[yellow]No project contexts.[/yellow]")
            return
        for p in projects:
            console.print(f"  [bold]{p['name']}[/bold] ({p['path']})")
            console.print(f"    Patterns: {p['patterns']} | Team: {p['team_members']}")

    else:
        console.print(f"[red]Unknown action: {action}[/red]")


@app.command()
def feedback(
    action: str = typer.Argument("stats", help="Action: stats, submit, list, suggestions, approve, reject"),
    rating: int = typer.Option(3, help="Rating 1-5"),
    comment: str = typer.Option("", help="Feedback comment"),
    target_id: str = typer.Option("", help="Target finding/rule ID"),
    source: str = typer.Option("human", help="Feedback source"),
    feedback_type: str = typer.Option("fix_quality", help="Feedback type"),
    suggestion_id: str = typer.Option("", help="Suggestion ID for approve/reject"),
    days: int = typer.Option(7, help="Lookback days"),
    metadata_json: str = typer.Option("{}", help="JSON metadata"),
):
    """Feedback loop — submit ratings, manage pattern suggestions, track effectiveness."""
    from deltacode.core.feedback_loop import FeedbackLoop
    import json as _json

    fl = FeedbackLoop()

    if action == "stats":
        stats = fl.get_stats()
        console.print(f"[bold cyan]Feedback Loop Stats:[/bold cyan]")
        console.print(f"Total feedback: {stats.get('total_feedback', 0)}")
        console.print(f"Avg rating: {stats.get('avg_rating', 0)}/5")
        console.print(f"Pending suggestions: {stats.get('pending_suggestions', 0)}")
        console.print(f"Approved suggestions: {stats.get('approved_suggestions', 0)}")
        console.print(f"Knowledge entries: {stats.get('knowledge_entries', 0)}")
        eff = stats.get("effectiveness", {})
        if eff:
            console.print(f"Fix success rate (30d): {eff.get('success_rate', 'N/A')}%")

    elif action == "submit":
        try:
            meta = _json.loads(metadata_json) if isinstance(metadata_json, str) else metadata_json
        except _json.JSONDecodeError:
            meta = {}
        item = fl.submit_feedback(
            feedback_type=feedback_type,
            source=source,
            target_id=target_id or "manual",
            rating=rating,
            comment=comment,
            metadata=meta,
        )
        console.print(f"[green]Feedback submitted:[/green] {item.id} (rating: {rating}/5)")
        audit_logger.log_command("feedback_submit", {"id": item.id, "rating": rating})

    elif action == "list":
        items = fl.get_feedback(feedback_type=feedback_type or None,
                                source=source if source != "human" else None,
                                since_days=days)
        if not items:
            console.print("[yellow]No feedback in this period.[/yellow]")
            return
        console.print(f"[green]{len(items)} feedback items:[/green]")
        for item in items:
            stars = "⭐" * item.rating + "☆" * (5 - item.rating)
            console.print(f"  {stars} [{item.feedback_type}] from {item.source}")
            console.print(f"    {item.comment[:100]}")

    elif action == "suggestions":
        pending = fl.get_pending_suggestions()
        if not pending:
            console.print("[green]No pending suggestions.[/green]")
            return
        console.print(f"[yellow]{len(pending)} pending suggestions:[/yellow]")
        for s in pending:
            console.print(f"  [bold]{s.id}[/bold] — {s.message[:60]}")
            console.print(f"    Severity: {s.severity} | Lang: {s.language} | Confidence: {s.confidence:.0%}")

    elif action == "approve":
        if not suggestion_id:
            console.print("[red]Provide --suggestion-id[/red]")
            raise typer.Exit(1)
        if fl.approve_suggestion(suggestion_id):
            console.print(f"[green]Suggestion approved:[/green] {suggestion_id}")
            audit_logger.log_command("feedback_approve", {"id": suggestion_id})
        else:
            console.print(f"[red]Suggestion not found:[/red] {suggestion_id}")

    elif action == "reject":
        if not suggestion_id:
            console.print("[red]Provide --suggestion-id[/red]")
            raise typer.Exit(1)
        if fl.reject_suggestion(suggestion_id):
            console.print(f"[red]Suggestion rejected:[/red] {suggestion_id}")
        else:
            console.print(f"[red]Suggestion not found:[/red] {suggestion_id}")

    else:
        console.print(f"[red]Unknown action: {action}[/red]")


@app.command()
def compliance(
    action: str = typer.Argument("report", help="Action: report, summary, rules, list-frameworks"),
    framework: str = typer.Option("soc2", help="Framework: soc2, iso27001, pci_dss, hipaa, gdpr"),
    target: str = typer.Option(".", help="Project directory"),
    export: str = typer.Option("", help="Export report to file"),
):
    """Generate compliance reports against SOC2, ISO27001, PCI-DSS, HIPAA, GDPR."""
    from deltacode.core.compliance_reporter import ComplianceReporter
    from deltacode.core.context_builder import SecurityContextBuilder
    from deltacode.core.compliance_rules import CustomComplianceEngine

    if action == "report" or action == "summary":
        reporter = ComplianceReporter()
        builder = SecurityContextBuilder(root_path=str(Path(target).resolve()))
        context = builder.scan_directory()
        findings = context.get("files", [])
        simplified = [
            {"title": f.get("path", ""), "severity": "HIGH" if f.get("score", 0) > 50 else "MEDIUM",
             "file": f.get("path", ""), "cwe": "", "category": (f.get("categories") or ["general"])[0]}
            for f in findings[:50]
        ]

        if action == "report":
            report = reporter.generate_report(framework, simplified, target)
            console.print(f"[bold cyan]Compliance Report: {report.framework}[/bold cyan]")
            console.print(f"Total Controls: {report.total_controls}")
            console.print(f"[green]Passing: {report.passing_controls}[/green] | [red]Failing: {report.failing_controls}[/red]")
            console.print(f"Overall: {report.overall_status.upper()}")
            for ca in report.control_assessments:
                icon = "✅" if ca["status"] == "passing" else "❌"
                console.print(f"  {icon} {ca['control_id']}: {ca['control_name']} ({ca['finding_count']} findings)")
            if export:
                reporter.save_report(report, export)
                console.print(f"[green]Report saved:[/green] {export}")
        else:
            summary = reporter.generate_executive_summary(framework, simplified, target)
            console.print(Panel(summary[:3000], title=f"Executive Summary: {framework.upper()}"))

    elif action == "rules":
        engine = CustomComplianceEngine()
        rules = engine.list_rules(framework=framework if framework != "soc2" else None)
        if not rules:
            console.print("[yellow]No rules found for this framework.[/yellow]")
            return
        console.print(f"[green]{len(rules)} rules:[/green]")
        for r in rules:
            cwes = ", ".join(r.cwe_patterns) if r.cwe_patterns else "keywords"
            console.print(f"  [bold]{r.control_id}[/bold] {r.name} ({r.framework})")
            console.print(f"    {r.description[:80]} | Patterns: {cwes}")

    elif action == "list-frameworks":
        from deltacode.core.compliance_reporter import COMPLIANCE_CONTROLS
        for fw_id, fw_data in COMPLIANCE_CONTROLS.items():
            console.print(f"  [bold]{fw_id}[/bold] — {fw_data['name']} ({len(fw_data['controls'])} controls)")

    else:
        console.print(f"[red]Unknown action: {action}[/red]")


@app.command()
def trend(
    action: str = typer.Argument("summary", help="Action: summary, snapshot, chart"),
    days: int = typer.Option(90, help="Lookback period in days"),
    target: str = typer.Option(".", help="Project directory"),
):
    """Analyze security finding trends over time."""
    from deltacode.core.trend_analyzer import TrendAnalyzer

    analyzer = TrendAnalyzer()

    if action == "snapshot":
        from deltacode.core.context_builder import SecurityContextBuilder
        builder = SecurityContextBuilder(root_path=str(Path(target).resolve()))
        context = builder.scan_directory()
        findings = context.get("files", [])
        analyzer.record_snapshot(findings)
        console.print(f"[green]Snapshot recorded:[/green] {len(findings)} findings")

    elif action == "summary":
        report = analyzer.format_trend_report(days=days)
        console.print(Panel(report, title=f"Trend Analysis ({days}d)"))

    elif action == "chart":
        trends = analyzer.get_trend("total_findings", days=days)
        if not trends:
            console.print("[yellow]No trend data. Run 'deltacode trend snapshot' first.[/yellow]")
            return
        values = [t["value"] for t in trends]
        if values:
            max_val = max(values)
            for t, v in zip(trends, values):
                bar = "█" * max(int(v / max(max_val, 1) * 30), 1) if v > 0 else ""
                console.print(f"  {t['date']} {bar} {v}")
    else:
        console.print(f"[red]Unknown action: {action}[/red]")


@app.command()
def risk(
    action: str = typer.Argument("dashboard", help="Action: dashboard, score"),
    target: str = typer.Option(".", help="Project directory"),
    export: str = typer.Option("", help="Export report to file"),
):
    """Risk scoring dashboard — severity/effort/trend combined."""
    from deltacode.core.risk_dashboard import RiskDashboard
    from deltacode.core.context_builder import SecurityContextBuilder

    builder = SecurityContextBuilder(root_path=str(Path(target).resolve()))
    context = builder.scan_directory()
    findings = context.get("files", [])
    simplified = [
        {"severity": "HIGH" if f.get("score", 0) > 50 else "MEDIUM" if f.get("score", 0) > 20 else "LOW",
         "effort": "MEDIUM", "category": (f.get("categories") or ["general"])[0],
         "cwe": f.get("cwe", ""), "file": f.get("path", "")}
        for f in findings[:100]
    ]

    dashboard = RiskDashboard()
    score = dashboard.calculate_risk(simplified)

    if action == "dashboard":
        output = dashboard.format_dashboard(score)
        console.print(Panel(output, title="Risk Dashboard"))
    elif action == "score":
        console.print(f"Risk Level: {score.risk_level}")
        console.print(f"Health Score: {score.health_score}/100")
        console.print(f"Weighted Risk: {score.weighted_score}%")
        console.print(f"Raw Risk Points: {score.raw_score}")
        console.print(f"Estimated Effort: {score.effort_cost} units")
    else:
        console.print(f"[red]Unknown action: {action}[/red]")

    if export:
        Path(export).write_text(json.dumps(score.__dict__, indent=2, ensure_ascii=False))
        console.print(f"[green]Risk data exported:[/green] {export}")


@app.command()
def evidence(
    action: str = typer.Argument("list", help="Action: list, add, verify, export, stats"),
    evidence_type: str = typer.Option("scan_result", help="Evidence type for add action"),
    title: str = typer.Option("", help="Evidence title"),
    description: str = typer.Option("", help="Evidence description"),
    source: str = typer.Option("deltacode", help="Evidence source"),
    content: str = typer.Option("", help="Evidence content"),
    control_id: str = typer.Option("", help="Control ID for export filter"),
    output: str = typer.Option("", help="Export output path"),
    content_file: str = typer.Option("", help="Read content from file"),
):
    """Compliance evidence collection and audit trail."""
    from deltacode.core.evidence_collector import EvidenceCollector

    collector = EvidenceCollector()

    if action == "list":
        artifacts = collector.get_artifacts(evidence_type=evidence_type if evidence_type != "scan_result" else None)
        if not artifacts:
            console.print("[yellow]No evidence artifacts.[/yellow]")
            return
        for a in artifacts:
            status = "✅ Verified" if a.verified else "📄 Unverified"
            console.print(f"  [bold]{a.id}[/bold] {a.title[:50]} ({a.evidence_type}) {status}")

    elif action == "add":
        if not title:
            console.print("[red]Provide --title[/red]")
            raise typer.Exit(1)
        content_data = content
        if content_file:
            try:
                content_data = Path(content_file).read_text(encoding="utf-8")
            except Exception as e:
                console.print(f"[red]Failed to read file:[/red] {e}")
                raise typer.Exit(1)
        a = collector.add_artifact(
            evidence_type=evidence_type,
            title=title,
            description=description or title,
            source=source,
            content=content_data or f"Evidence: {title}",
        )
        console.print(f"[green]Evidence added:[/green] {a.id}")
        audit_logger.log_command("evidence_add", {"id": a.id, "type": evidence_type})

    elif action == "verify":
        all_artifacts = collector.get_artifacts(limit=100)
        verified = 0
        for a in all_artifacts:
            if collector.verify_artifact(a.id):
                verified += 1
        console.print(f"[green]Verified {verified}/{len(all_artifacts)} artifacts.[/green]")

    elif action == "export":
        if not output:
            output = str(Path.home() / ".deltacode" / "evidence" / "package.json")
        path = collector.export_package(output, control_id=control_id or None)
        console.print(f"[green]Evidence package exported:[/green] {path}")

    elif action == "stats":
        stats = collector.get_stats()
        console.print(f"[bold cyan]Evidence Stats:[/bold cyan]")
        console.print(f"Total: {stats.get('total', 0)}")
        console.print(f"Verified: {stats.get('verified', 0)}")
        console.print(f"By type: {stats.get('by_type', {})}")
        total_kb = round(stats.get('total_size_bytes', 0) / 1024, 1)
        console.print(f"Total size: {total_kb} KB")

    else:
        console.print(f"[red]Unknown action: {action}[/red]")


@app.command()
def threat(
    action: str = typer.Argument("intel", help="Action: intel, check, trending, iocs"),
    query: str = typer.Option("", help="CVE ID or keyword"),
    cve_ids: str = typer.Option("", help="Comma-separated CVE IDs"),
    limit: int = typer.Option(20, help="Max results"),
    text: str = typer.Option("", help="Text to extract IOCs from"),
):
    """Threat intelligence — CVE threat assessment, trending, IOC extraction."""
    from deltacode.core.threat_intel import ThreatIntelAggregator

    intel = ThreatIntelAggregator()

    if action == "intel":
        if query:
            result = intel.check_cve_threat(query.strip().upper())
            console.print(f"[bold]CVE:[/bold] {result.get('cve_id', query)}")
            console.print(f"  CVSS: {result.get('cvss_score', 'N/A')}")
            console.print(f"  Exploited: {'🔴 Yes' if result.get('is_exploited') else '✅ No'}")
            console.print(f"  PoC Available: {'📄 Yes' if result.get('has_poc') else 'No'}")
            console.print(f"  Zero-Day Candidate: {'⚠ Yes' if result.get('is_zero_day') else 'No'}")
            if result.get("sources"):
                console.print(f"  Sources: {', '.join(result['sources'][:3])}")
        elif cve_ids:
            ids = [c.strip() for c in cve_ids.split(",") if c.strip()]
            results = intel.bulk_intel_check(ids)
            for r in results:
                icon = "🔴" if r.get("is_exploited") else "⚠" if r.get("is_zero_day") else "📄"
                console.print(f"  {icon} {r['cve_id']} (CVSS {r.get('cvss_score', 'N/A')})")
        else:
            console.print("[red]Provide --query or --cve-ids[/red]")
            raise typer.Exit(1)

    elif action == "trending":
        results = intel.get_trending_cves(limit=limit)
        if not results:
            console.print("[yellow]No trending CVEs found.[/yellow]")
            return
        console.print(f"[bold cyan]Trending CVEs (Last 7 Days):[/bold cyan]")
        for r in results:
            icon = "🔴" if r.get("is_exploited") else "⚠" if r.get("is_zero_day") else ""
            console.print(f"  {icon} {r['cve_id']} (CVSS {r.get('score', 'N/A')}, {r.get('severity', 'N/A')})")
            console.print(f"    {r.get('description', '')[:120]}")

    elif action == "iocs":
        if not text:
            console.print("[red]Provide --text to extract IOCs from[/red]")
            raise typer.Exit(1)
        iocs = ThreatIntelAggregator.extract_iocs(text)
        if not iocs:
            console.print("[yellow]No IOCs found.[/yellow]")
            return
        console.print(f"[bold cyan]Extracted {len(iocs)} IOCs:[/bold cyan]")
        for ioc in iocs:
            console.print(f"  [{ioc.ioc_type}] {ioc.value} (confidence: {ioc.confidence:.0%})")

    intel.close()


@app.command()
def dataflow(
    action: str = typer.Argument("analyze", help="Action: analyze"),
    target: str = typer.Option(".", help="Project directory"),
):
    """Data flow analysis — track inputs, outputs, and sensitive data paths."""
    from deltacode.core.data_flow import DataFlowAnalyzer

    target_path = Path(target).resolve()
    if not target_path.exists():
        console.print(f"[red]Path not found:[/red] {target_path}")
        raise typer.Exit(1)

    analyzer = DataFlowAnalyzer(root_path=str(target_path))
    console.print(f"[cyan]Analyzing data flows in:[/cyan] {target_path}")
    results = analyzer.analyze()
    report = analyzer.format_report(results)
    console.print(Panel(report[:3000], title="Data Flow Analysis"))
    audit_logger.log_command("dataflow", {"target": str(target_path)})


@app.command()
def taint(
    action: str = typer.Argument("track", help="Action: track"),
    target: str = typer.Option(".", help="Project directory"),
):
    """Taint tracking — source-to-sink propagation of untrusted data."""
    from deltacode.core.taint_tracker import TaintTracker

    target_path = Path(target).resolve()
    if not target_path.exists():
        console.print(f"[red]Path not found:[/red] {target_path}")
        raise typer.Exit(1)

    tracker = TaintTracker(root_path=str(target_path))
    console.print(f"[cyan]Tracking taint in:[/cyan] {target_path}")
    paths = tracker.analyze()
    report = tracker.format_report(paths)
    console.print(Panel(report[:3000], title="Taint Tracking Report"))
    audit_logger.log_command("taint", {"target": str(target_path), "paths": len(paths)})


@app.command()
def attackpath(
    action: str = typer.Argument("model", help="Action: model"),
    target: str = typer.Option(".", help="Project directory"),
):
    """Attack path modeling — exploit chain detection and scoring."""
    from deltacode.core.attack_path import AttackPathModeler
    from deltacode.core.context_builder import SecurityContextBuilder

    target_path = Path(target).resolve()
    if not target_path.exists():
        console.print(f"[red]Path not found:[/red] {target_path}")
        raise typer.Exit(1)

    builder = SecurityContextBuilder(root_path=str(target_path))
    context = builder.scan_directory()
    findings = context.get("files", [])
    simplified = [{"cwe": "", "severity": "HIGH" if f.get("score", 0) > 50 else "MEDIUM", "file": f.get("path", "")} for f in findings[:50]]

    modeler = AttackPathModeler(root_path=str(target_path))
    console.print(f"[cyan]Modeling attack paths for:[/cyan] {target_path}")
    paths = modeler.analyze(simplified)
    report = modeler.format_report(paths)
    console.print(Panel(report[:3000], title="Attack Path Model"))
    audit_logger.log_command("attackpath", {"target": str(target_path), "paths": len(paths)})


@app.command()
def testregression(
    action: str = typer.Argument("run", help="Action: run"),
    test_command: str = typer.Option("pytest", help="Test command to run"),
    target: str = typer.Option(".", help="Project directory"),
):
    """Regression testing — compare before/after fix test results."""
    from deltacode.core.regression_tester import RegressionTester

    target_path = Path(target).resolve()
    if not target_path.exists():
        console.print(f"[red]Path not found:[/red] {target_path}")
        raise typer.Exit(1)

    tester = RegressionTester(project_path=str(target_path))
    console.print(f"[cyan]Running regression test (before):[/cyan] {test_command}")
    before = tester.run_test_suite(test_command)
    console.print(f"Before: {'PASSED' if before.passed else 'FAILED'} ({before.duration_ms}ms)")

    console.print(f"\n[yellow]Apply your fix, then press Enter to run 'after' test...[/yellow]")
    import sys
    sys.stdin.readline()

    console.print(f"[cyan]Running regression test (after):[/cyan] {test_command}")
    after = tester.run_test_suite(test_command)
    console.print(f"After: {'PASSED' if after.passed else 'FAILED'} ({after.duration_ms}ms)")

    result = tester.run_regression_check(before, after)
    report = tester.format_report(result)
    console.print(Panel(report, title="Regression Test Results"))
    audit_logger.log_command("testregression", {"target": str(target_path), "before": before.passed, "after": after.passed})


@app.command()
def testmutation(
    action: str = typer.Argument("run", help="Action: run, templates"),
    target: str = typer.Option(".", help="File to mutate (relative to project)"),
    count: int = typer.Option(10, help="Number of mutations to generate"),
    test_command: str = typer.Option("pytest", help="Test command"),
):
    """Mutation testing — evaluate test suite quality by introducing code mutations."""
    from deltacode.core.mutation_tester import MutationTester

    tester = MutationTester(project_path=str(Path(target).resolve()))

    if action == "templates":
        console.print("[cyan]Mutation types:[/cyan] replace_operator, negate_condition, remove_call")
        return

    files_to_mutate = [str(f.relative_to(Path(target).resolve())) for f in Path(target).rglob("*.py") if f.is_file() and "test_" not in f.name][:5]
    if not files_to_mutate:
        console.print("[yellow]No Python files to mutate.[/yellow]")
        return

    all_mutations = []
    for f in files_to_mutate:
        mutations = tester.generate_mutations(f, count=max(1, count // len(files_to_mutate)))
        all_mutations.extend(mutations)

    console.print(f"[cyan]Generated {len(all_mutations)} mutations across {len(files_to_mutate)} files[/cyan]")
    result = tester.run_mutation_test(all_mutations, test_command=test_command)
    report = tester.format_report(result)
    console.print(Panel(report, title="Mutation Test Results"))
    audit_logger.log_command("testmutation", {"total": result.total, "score": result.score})


@app.command()
def testcoverage(
    action: str = typer.Argument("run", help="Action: run"),
    test_command: str = typer.Option("pytest --cov=src --cov-report=json", help="Coverage command"),
    target: str = typer.Option(".", help="Project directory"),
):
    """Test coverage analysis — line and branch coverage reporting."""
    from deltacode.core.test_coverage import CoverageAnalyzer

    target_path = Path(target).resolve()
    if not target_path.exists():
        console.print(f"[red]Path not found:[/red] {target_path}")
        raise typer.Exit(1)

    analyzer = CoverageAnalyzer(project_path=str(target_path))
    console.print(f"[cyan]Running coverage analysis:[/cyan] {test_command}")
    result = analyzer.run_coverage(test_command)
    report = analyzer.format_report(result)
    console.print(Panel(report, title="Coverage Report"))
    audit_logger.log_command("testcoverage", {"target": str(target_path), "line_rate": result.total_line_rate})


@app.command()
def exploitverify(
    action: str = typer.Argument("run", help="Action: run, templates"),
    cwe: str = typer.Option("", help="CWE ID to verify fix for (e.g. CWE-89)"),
    unpatched_file: str = typer.Option("", help="Unpatched source file"),
    patched_file: str = typer.Option("", help="Patched source file"),
):
    """Exploit fix verification — safely check if fixes block known attack patterns."""
    from deltacode.core.exploit_verifier import ExploitVerifier

    verifier = ExploitVerifier()

    if action == "templates":
        templates = verifier.list_templates()
        console.print(f"[green]Available PoC templates:[/green]")
        for t in templates:
            console.print(f"  {t['cwe']}: {t['name']}")
            console.print(f"    {t['description']}")
        return

    if not cwe or not unpatched_file or not patched_file:
        console.print("[red]Provide --cwe, --unpatched-file, and --patched-file[/red]")
        raise typer.Exit(1)

    try:
        unpatched = Path(unpatched_file).read_text(encoding="utf-8")
        patched = Path(patched_file).read_text(encoding="utf-8")
    except Exception as e:
        console.print(f"[red]Failed to read files:[/red] {e}")
        raise typer.Exit(1)

    result = verifier.verify_fix(cwe.upper(), unpatched, patched)
    if result.fix_verified:
        console.print(f"[green]✅ Fix verified for {cwe.upper()}[/green]")
    elif result.error:
        console.print(f"[yellow]⚠ {result.error}[/yellow]")
    else:
        console.print(f"[red]🔴 Fix verification failed for {cwe.upper()}[/red]")
    console.print(f"Payload: {result.payload}")
    console.print(f"[dim]Unpatched: {'Vulnerable' if result.unpatched_vulnerable else 'Safe'} | Patched: {'Vulnerable' if result.patched_vulnerable else 'Safe'}[/dim]")
    audit_logger.log_command("exploitverify", {"cwe": cwe, "verified": result.fix_verified})


@app.command()
def doctor(
    fix: bool = typer.Option(False, "--fix", help="Attempt to auto-fix detected issues"),
    export: str = typer.Option("", help="Export diagnostics report to file"),
):
    """System diagnostics and health check — verify all components are working."""
    from deltacode.core.diagnostics import Diagnostics
    import json

    d = Diagnostics()
    results = d.run_all()

    console.print("[bold cyan]DeltaCode Diagnostics[/bold cyan]\n")

    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Component")
    table.add_column("Status")
    table.add_column("Detail")

    for r in results:
        icon = {"OK": "✅", "WARN": "⚠️ ", "FAIL": "🔴", "SKIP": "⏭"}.get(r.status, "❓")
        table.add_row(r.component, f"{icon} {r.status}", r.detail)

    console.print(table)

    has_issues = any(r.status in ("FAIL",) for r in results)
    has_warnings = any(r.status in ("WARN",) for r in results)

    if has_issues:
        console.print("\n[red]Issues found that may prevent DeltaCode from working correctly.[/red]")
    if has_warnings:
        console.print("\n[yellow]Warnings — some optional features may be unavailable.[/yellow]")

    if fix:
        console.print("\n[cyan]Attempting to fix issues...[/cyan]")
        fixable = [r for r in results if r.fixable and r.status != "OK" and r.fix_command]
        fixed_count = 0
        for r in fixable:
            if r.fix_command.startswith("pip"):
                console.print(f"  Installing {r.component}...")
                import subprocess
                try:
                    subprocess.run(r.fix_command.split(), capture_output=True, text=True, timeout=120)
                    console.print(f"  [green]✓ {r.component} fix attempted[/green]")
                    fixed_count += 1
                except Exception as e:
                    console.print(f"  [red]✗ Failed: {e}[/red]")
            else:
                console.print(f"  [yellow]Manual fix needed:[/yellow] {r.fix_command}")
        console.print(f"\n[green]Auto-fix completed for {fixed_count} issues.[/green]")

    if export:
        data = [{"component": r.component, "status": r.status, "detail": r.detail} for r in results]
        Path(export).write_text(json.dumps(data, indent=2, ensure_ascii=False))
        console.print(f"\n[green]Report exported:[/green] {export}")

    audit_logger.log_command("doctor", {"issues": len([r for r in results if r.status == "FAIL"])})


if __name__ == "__main__":
    app()