"""Risk scoring dashboard for DeltaCode CLI.

Combines:
- Severity-weighted risk scoring
- Effort-based remediation cost
- Trend-adjusted risk multipliers
- Compliance impact weighting
- Overall security health score
"""

from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


SEVERITY_WEIGHTS = {"CRITICAL": 10, "HIGH": 7, "MEDIUM": 4, "LOW": 1, "INFO": 0}
EFFORT_COST = {"HIGH": 5, "MEDIUM": 3, "LOW": 1}


@dataclass
class RiskScore:
    raw_score: float = 0.0
    weighted_score: float = 0.0
    max_possible: float = 0.0
    by_severity: dict = field(default_factory=dict)
    by_category: dict = field(default_factory=dict)
    by_compliance: dict = field(default_factory=dict)
    effort_cost: float = 0.0
    health_score: float = 100.0
    risk_level: str = "LOW"
    top_risks: list = field(default_factory=list)


class RiskDashboard:
    def __init__(self):
        self._history: list[dict] = []

    def calculate_risk(self, findings: list[dict], compliance_report: dict = None) -> RiskScore:
        score = RiskScore()

        severity_totals = defaultdict(float)
        category_totals = defaultdict(int)
        compliance_totals = defaultdict(int)
        effort_total = 0

        for f in findings:
            sev = f.get("severity", "MEDIUM")
            weight = SEVERITY_WEIGHTS.get(sev, 1)
            severity_totals[sev] += 1
            score.raw_score += weight

            cat = f.get("category", "general")
            category_totals[cat] += 1

            effort = f.get("effort", "MEDIUM")
            effort_total += EFFORT_COST.get(effort, 2)

            cwe = f.get("cwe", f.get("cwe_id", ""))
            if compliance_report and cwe:
                controls = compliance_report.get("cwe_to_all", {}).get(cwe, {})
                for fw in controls:
                    compliance_totals[fw] += weight

        score.by_severity = dict(severity_totals)
        score.by_category = dict(category_totals)
        score.by_compliance = dict(compliance_totals)
        score.effort_cost = effort_total

        total_findings = max(len(findings), 1)
        max_possible = total_findings * max(SEVERITY_WEIGHTS.values())
        score.max_possible = max_possible
        score.weighted_score = round(score.raw_score / max(max_possible, 1) * 100, 1)

        health = 100.0
        sev_counts = severity_totals
        health -= sev_counts.get("CRITICAL", 0) * 15
        health -= sev_counts.get("HIGH", 0) * 8
        health -= sev_counts.get("MEDIUM", 0) * 3
        health -= sev_counts.get("LOW", 0) * 1
        health = max(0, min(100, health))
        score.health_score = round(health, 1)

        if score.weighted_score >= 50:
            score.risk_level = "CRITICAL"
        elif score.weighted_score >= 30:
            score.risk_level = "HIGH"
        elif score.weighted_score >= 15:
            score.risk_level = "MEDIUM"
        else:
            score.risk_level = "LOW"

        score.top_risks = sorted(
            [{"severity": sev, "count": int(cnt), "weight": SEVERITY_WEIGHTS.get(sev, 0) * cnt}
             for sev, cnt in severity_totals.items()],
            key=lambda x: -x["weight"],
        )[:5]

        return score

    def format_dashboard(self, score: RiskScore) -> str:
        icons = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🟢"}

        lines = ["# Risk Dashboard\n"]
        lines.append(f"## Overall Risk: {icons.get(score.risk_level, '⚪')} {score.risk_level}")
        lines.append(f"Health Score: {score.health_score}/100")
        lines.append(f"Weighted Risk: {score.weighted_score}%")
        lines.append(f"Total Raw Risk Points: {score.raw_score}")
        lines.append("")
        lines.append("## By Severity")
        for sev, count in sorted(score.by_severity.items(), key=lambda x: -SEVERITY_WEIGHTS.get(x[0], 0)):
            bar = "█" * min(int(count * 2), 30)
            lines.append(f"  {icons.get(sev, '⚪')} {sev}: {bar} {count}")
        lines.append("")
        lines.append(f"## Remediation Cost")
        lines.append(f"Estimated Effort: {score.effort_cost} units")
        if score.by_category:
            lines.append("## By Category")
            for cat, count in sorted(score.by_category.items(), key=lambda x: -x[1])[:8]:
                lines.append(f"  {cat}: {count}")
        if score.by_compliance:
            lines.append("## Compliance Impact")
            for fw, weight in sorted(score.by_compliance.items(), key=lambda x: -x[1]):
                lines.append(f"  {fw}: risk weight {weight}")
        return "\n".join(lines)