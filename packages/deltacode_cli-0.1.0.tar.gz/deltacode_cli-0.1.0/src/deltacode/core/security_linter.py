"""Security-focused linter for DeltaCode CLI.

Standalone implementation — does not depend on Aider's linter.
Supports semgrep (multi-language) and bandit (Python) integration.
"""

import json
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from deltacode.core.custom_rules import CustomRuleEngine


@dataclass
class LintResult:
    text: str
    lines: list = field(default_factory=list)


SEMGREP_RULES = [
    "p/security-audit",
    "p/owasp-top-ten",
    "p/cwe-top-25",
    "p/jwt",
    "p/xss",
    "p/sql-injection",
    "p/command-injection",
    "p/insecure-transport",
    "p/crypto",
]

SKIP_DIRS = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", ".env",
    "dist", "build", ".tox", ".mypy_cache", ".pytest_cache",
    "site-packages", ".eggs", "eggs", ".aider",
}

SECURITY_EXTENSIONS = {
    ".py", ".pyw",
    ".js", ".ts", ".jsx", ".tsx",
    ".java", ".go", ".rb", ".php",
    ".c", ".cpp", ".h", ".hpp",
    ".rs", ".cs", ".scala", ".kt",
    ".sh", ".bash", ".yaml", ".yml",
    ".json", ".xml", ".dockerfile",
}




def find_filenames_and_linenums(text, fnames):
    pattern = re.compile(
        r"(\b(?:" + "|".join(re.escape(fname) for fname in fnames) + r"):\d+\b)"
    )
    matches = pattern.findall(text)
    result = {}
    for match in matches:
        fname, linenum = match.rsplit(":", 1)
        if fname not in result:
            result[fname] = set()
        result[fname].add(int(linenum))
    return result


class SecurityLinter:
    def __init__(self, encoding="utf-8", root=None, custom_rules_path: str = None):
        self.encoding = encoding
        self.root = root or os.getcwd()
        self._has_semgrep = shutil.which("semgrep") is not None
        self._has_bandit = shutil.which("bandit") is not None
        self._has_codeql = shutil.which("codeql") is not None
        self._custom_rules = CustomRuleEngine(rules_path=custom_rules_path)

    def get_rel_fname(self, fname):
        if self.root:
            try:
                return os.path.relpath(fname, self.root)
            except ValueError:
                return fname
        return fname

    def security_scan(self, fname, rules=None, severity=None):
        rel_fname = self.get_rel_fname(fname)
        try:
            code = Path(fname).read_text(encoding=self.encoding, errors="replace")
        except OSError as err:
            return f"Unable to read {fname}: {err}"

        no_external = not self._has_semgrep and not self._has_bandit and not self._has_codeql
        results = []

        semgrep_res = self.semgrep_scan(fname, rel_fname, code, rules=rules, severity=severity)
        if semgrep_res:
            results.append(semgrep_res)

        bandit_res = self.bandit_scan(fname, rel_fname, code, severity=severity)
        if bandit_res:
            results.append(bandit_res)

        codeql_res = self.codeql_scan(fname, rel_fname, code, severity=severity)
        if codeql_res:
            results.append(codeql_res)

        ext = Path(fname).suffix.lower()
        custom_matches = self._custom_rules.scan(code, CustomRuleEngine.ext_to_lang(ext) or "")
        if custom_matches:
            custom_text = self._custom_rules.format_results(custom_matches)
            if custom_text:
                results.append(LintResult(text=custom_text))

        if not results:
            return None

        text = ""
        lines = set()
        for res in results:
            if text:
                text += "\n\n"
            text += res.text
            if res.lines:
                lines.update(res.lines)

        output = "# Security findings — fix if applicable.\n\n"
        output += text
        output += "\n"
        return output

    CODEQL_QUERY_SUITES = [
        "codeql-suite/security-and-quality",
        "codeql-suite/security-extended",
    ]

    def codeql_scan(self, fname, rel_fname, code, severity=None):
        if not self._has_codeql:
            return None

        db_path = None
        for candidate in ["codeql_db", ".deltacode/codeql-db"]:
            p = os.path.join(self.root, candidate)
            if os.path.isdir(p):
                db_path = p
                break

        if db_path is None:
            return None

        import tempfile
        tmp = tempfile.NamedTemporaryFile(suffix=".sarif", delete=False)
        tmp_path = tmp.name
        tmp.close()

        try:
            result = subprocess.run(
                [shutil.which("codeql"), "database", "analyze", db_path, "--format=sarif-latest", f"--output={tmp_path}"],
                capture_output=True,
                text=True,
                check=False,
                encoding=self.encoding,
                errors="replace",
                cwd=self.root,
                timeout=300,
            )
            if result.returncode != 0:
                return None
        except subprocess.TimeoutExpired:
            return LintResult(text="## codeql timed out\n", lines=[])
        except Exception as e:
            return LintResult(text=f"## codeql error: {e}\n", lines=[])

        try:
            with open(tmp_path, "r", encoding="utf-8") as f:
                sarif = json.load(f)
        except Exception:
            return None
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass

        severity_map = {"error": "HIGH", "warning": "MEDIUM", "note": "LOW"}
        findings = []
        for run in sarif.get("runs", []):
            for r in run.get("results", []):
                rule_id = r.get("ruleId", "unknown")
                level = r.get("level", "note")
                sev = severity_map.get(level, "LOW")
                message = r.get("message", {}).get("text", "")
                locations = r.get("locations", [])
                line = 0
                if locations:
                    line = locations[0].get("physicalLocation", {}).get("artifactLocation", {}).get("uri", "").rsplit(":", 1)[-1]
                    try:
                        line = int(locations[0].get("physicalLocation", {}).get("region", {}).get("startLine", 0))
                    except (ValueError, TypeError):
                        line = 0
                findings.append((sev, rule_id, message, line))

        if not findings:
            return None

        text = f"## codeql findings ({len(findings)} issues)\n\n"
        for sev, rule_id, message, line in findings:
            text += f"- [{sev}] {rule_id}: {message} (line {line})\n"

        return LintResult(text=text, lines=[])

    def codeql_create_database(self, target_path=None):
        if not self._has_codeql:
            return {"created": False, "error": "codeql CLI not found"}

        target = target_path or self.root

        py_files = list(Path(target).rglob("*.py")) + list(Path(target).rglob("*.pyw"))
        js_files = list(Path(target).rglob("*.js")) + list(Path(target).rglob("*.ts"))

        language = None
        if py_files:
            language = "python"
        elif js_files:
            language = "javascript"
        else:
            return {"created": False, "error": "no supported language files found"}

        db_dir = os.path.join(self.root, ".deltacode", "codeql-db")
        os.makedirs(os.path.dirname(db_dir), exist_ok=True)

        try:
            result = subprocess.run(
                [shutil.which("codeql"), "database", "create", db_dir, f"--language={language}", "--overwrite", target],
                capture_output=True,
                text=True,
                check=False,
                encoding=self.encoding,
                errors="replace",
                cwd=self.root,
                timeout=600,
            )
            if result.returncode != 0:
                return {"created": False, "database_path": db_dir, "error": result.stderr.strip()}
            return {"created": True, "database_path": db_dir, "error": None}
        except subprocess.TimeoutExpired:
            return {"created": False, "database_path": db_dir, "error": "codeql database create timed out"}
        except Exception as e:
            return {"created": False, "database_path": db_dir, "error": str(e)}

    def semgrep_scan(self, fname, rel_fname, code, rules=None, severity=None):
        if not self._has_semgrep:
            return None

        cmd = [shutil.which("semgrep"), "--json", "--timeout", "30"]

        scan_rules = rules if rules else "p/security-audit"
        if isinstance(scan_rules, list):
            for rule in scan_rules:
                cmd.extend(["--config", rule])
        else:
            cmd.extend(["--config", scan_rules])

        if severity:
            cmd.extend(["--severity", severity])

        cmd.append(rel_fname)

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=False,
                encoding=self.encoding,
                errors="replace",
                cwd=self.root,
                timeout=120,
            )
        except subprocess.TimeoutExpired:
            return LintResult(text="## semgrep timed out\n", lines=[])
        except Exception as e:
            return LintResult(text=f"## semgrep error: {e}\n", lines=[])

        try:
            data = json.loads(result.stdout)
        except Exception:
            return None

        findings = data.get("results", [])
        if not findings:
            return None

        text = f"## semgrep findings ({len(findings)} issues)\n\n"

        for finding in findings:
            check_id = finding.get("check_id", "unknown")
            f_severity = finding.get("extra", {}).get("severity", "INFO")
            message = finding.get("extra", {}).get("message", "")
            line_start = finding.get("start", {}).get("line", 0)

            text += f"- [{f_severity}] {check_id}: {message} (line {line_start})\n"

        return LintResult(text=text, lines=[])

    def bandit_scan(self, fname, rel_fname, code, severity=None):
        if not self._has_bandit:
            return None

        ext = Path(fname).suffix.lower()
        if ext not in (".py", ".pyw"):
            return None

        cmd = [shutil.which("bandit"), "-f", "json", "-q", rel_fname]

        if severity == "high":
            cmd.extend(["-ll", "-lll"])
        elif severity == "medium":
            cmd.extend(["-ll"])

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=False,
                encoding=self.encoding,
                errors="replace",
                cwd=self.root,
                timeout=60,
            )
        except subprocess.TimeoutExpired:
            return LintResult(text="## bandit timed out\n", lines=[])
        except Exception as e:
            return LintResult(text=f"## bandit error: {e}\n", lines=[])

        try:
            data = json.loads(result.stdout)
        except Exception:
            return None

        results = data.get("results", [])
        if not results:
            return None

        text = f"## bandit findings ({len(results)} issues)\n\n"

        for issue in results:
            test_id = issue.get("test_id", "unknown")
            issue_severity = issue.get("issue_severity", "LOW")
            issue_text = issue.get("issue_text", "")
            line_start = issue.get("line_number", 0)

            text += f"- [{issue_severity}] {test_id}: {issue_text} (line {line_start})\n"

        return LintResult(text=text, lines=[])


def scan_directory(
    directory,
    rules=None,
    severity=None,
    extensions=None,
    root=None,
):
    linter = SecurityLinter(root=root or directory)
    target_exts = extensions or SECURITY_EXTENSIONS
    findings = []
    dir_path = Path(directory)

    for filepath in sorted(dir_path.rglob("*")):
        if not filepath.is_file():
            continue
        if filepath.stat().st_size > 1024 * 1024:
            continue
        if filepath.suffix.lower() not in target_exts:
            continue
        if any(part in SKIP_DIRS for part in filepath.parts):
            continue

        result = linter.security_scan(str(filepath), rules=rules, severity=severity)
        if result:
            findings.append((str(filepath), result))

    return findings