"""Threat intelligence integration for DeltaCode CLI.

Aggregates threat data from:
- CVE/NVD feeds
- Known exploit indicators
- IOC pattern matching
- Vendor security advisories
- Zero-day awareness via anomaly detection
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import httpx

from deltacode.core.logger import get_logger
from deltacode.core.cache import DeltaCache

logger = get_logger(__name__)


KNOWN_EXPLOITED_CVES_CACHE_KEY = "threatintel:known_exploited"
CISA_KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
NVD_RECENT_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"


@dataclass
class ThreatIntel:
    cve_id: str
    title: str
    description: str
    cvss_score: float
    severity: str
    is_exploited: bool
    has_poc: bool
    is_zero_day: bool
    vendor: str
    published: str
    sources: list = field(default_factory=list)


@dataclass
class IOCIndicator:
    ioc_type: str
    value: str
    source: str
    confidence: float
    first_seen: str
    tags: list = field(default_factory=list)


class ThreatIntelAggregator:
    def __init__(self):
        self._http = httpx.Client(timeout=30, follow_redirects=True)

    def get_known_exploited(self) -> list[dict]:
        cached = DeltaCache.get("threat_intel", "known_exploited")
        if cached:
            return cached

        try:
            resp = self._http.get(CISA_KEV_URL)
            resp.raise_for_status()
            data = resp.json()
            vulns = data.get("vulnerabilities", [])
            DeltaCache.set("threat_intel", "known_exploited", vulns, ttl=86400)
            return vulns
        except Exception:
            return []

    def check_cve_threat(self, cve_id: str) -> dict:
        result = {
            "cve_id": cve_id,
            "is_exploited": False,
            "has_poc": False,
            "is_zero_day": False,
            "cvss_score": 0.0,
            "sources": [],
        }

        exploited = self.get_known_exploited()
        for v in exploited:
            if v.get("cveID", "").upper() == cve_id.upper():
                result["is_exploited"] = True
                result["sources"].append("CISA KEV")
                result["title"] = v.get("vulnerabilityName", "")
                result["description"] = v.get("shortDescription", "")
                break

        poc_indicators = ["exploit-db", "metasploit", "poc", "github.com/exploit"]
        try:
            resp = self._http.get(
                f"{NVD_RECENT_URL}?cveId={cve_id}&resultsPerPage=1",
                timeout=15,
            )
            if resp.status_code == 200:
                data = resp.json()
                vulns = data.get("vulnerabilities", [])
                if vulns:
                    cve = vulns[0].get("cve", {})
                    metrics = cve.get("metrics", {})
                    cvss_data = (metrics.get("cvssMetricV31", [{}]) or metrics.get("cvssMetricV30", [{}]) or metrics.get("cvssMetricV2", [{}]))[0].get("cvssData", {})
                    result["cvss_score"] = cvss_data.get("baseScore", 0)

                    refs = [ref.get("url", "") for ref in cve.get("references", [])]
                    for ref in refs:
                        ref_lower = ref.lower()
                        for indicator in poc_indicators:
                            if indicator in ref_lower:
                                result["has_poc"] = True
                                result["sources"].append(ref)
                                break

                    descriptions = cve.get("descriptions", [{}])
                    for d in descriptions:
                        if d.get("lang") == "en":
                            result["description"] = d.get("value", "")
                            break
        except Exception:
            pass

        score = result.get("cvss_score", 0)
        if score >= 9.0 and not result["is_exploited"] and not result["has_poc"]:
            result["is_zero_day"] = True

        return result

    def bulk_intel_check(self, cve_ids: list[str]) -> list[dict]:
        return [self.check_cve_threat(cid) for cid in cve_ids]

    def get_trending_cves(self, days: int = 7, limit: int = 20) -> list[dict]:
        cache_key = f"trending_{days}_{limit}"
        cached = DeltaCache.get("threat_intel", cache_key)
        if cached:
            return cached

        try:
            start_date = (datetime.utcnow() - timedelta(days=days)).strftime("%Y-%m-%dT00:00:00.000")
            end_date = datetime.utcnow().strftime("%Y-%m-%dT23:59:59.999")
            url = f"{NVD_RECENT_URL}?pubStartDate={start_date}&pubEndDate={end_date}&resultsPerPage={limit}"
            resp = self._http.get(url, timeout=30)
            resp.raise_for_status()
            data = resp.json()

            results = []
            for vuln in data.get("vulnerabilities", []):
                cve = vuln.get("cve", {})
                metrics = cve.get("metrics", {})
                cvss = (metrics.get("cvssMetricV31", [{}]) or metrics.get("cvssMetricV30", [{}]) or metrics.get("cvssMetricV2", [{}]))[0].get("cvssData", {})
                score = cvss.get("baseScore", 0)
                sev = cvss.get("baseSeverity", "N/A")

                descriptions = cve.get("descriptions", [{}])
                desc = ""
                for d in descriptions:
                    if d.get("lang") == "en":
                        desc = d.get("value", "")
                        break

                cve_id = cve.get("id", "")
                intel = self.check_cve_threat(cve_id)

                results.append({
                    "cve_id": cve_id,
                    "score": score,
                    "severity": sev,
                    "description": desc[:200],
                    "published": cve.get("published", ""),
                    "is_exploited": intel["is_exploited"],
                    "has_poc": intel["has_poc"],
                    "is_zero_day": intel["is_zero_day"],
                })

            DeltaCache.set("threat_intel", cache_key, results, ttl=3600)
            return results

        except Exception:
            return []

    @staticmethod
    def extract_iocs(text: str) -> list[IOCIndicator]:
        iocs = []

        ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
        for match in re.finditer(ip_pattern, text):
            iocs.append(IOCIndicator(ioc_type="ip", value=match.group(), source="regex", confidence=0.8,
                                      first_seen=datetime.utcnow().isoformat(), tags=["network"]))

        domain_pattern = r'\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}\b'
        for match in re.finditer(domain_pattern, text):
            iocs.append(IOCIndicator(ioc_type="domain", value=match.group(), source="regex", confidence=0.7,
                                      first_seen=datetime.utcnow().isoformat(), tags=["network"]))

        url_pattern = r'https?://[^\s<>"\'"]+|www\.[^\s<>"\'"]+'
        for match in re.finditer(url_pattern, text):
            iocs.append(IOCIndicator(ioc_type="url", value=match.group(), source="regex", confidence=0.6,
                                      first_seen=datetime.utcnow().isoformat(), tags=["web"]))

        hash_pattern = r'\b[a-fA-F0-9]{32}\b|\b[a-fA-F0-9]{40}\b|\b[a-fA-F0-9]{64}\b'
        for match in re.finditer(hash_pattern, text):
            hlen = len(match.group())
            hash_type = "md5" if hlen == 32 else "sha1" if hlen == 40 else "sha256"
            iocs.append(IOCIndicator(ioc_type=f"hash_{hash_type}", value=match.group(), source="regex", confidence=0.9,
                                      first_seen=datetime.utcnow().isoformat(), tags=["malware"]))

        return iocs

    def format_intel_report(self, cve_threats: list[dict]) -> str:
        if not cve_threats:
            return "No threat intelligence data."

        parts = ["# Threat Intelligence Report\n"]
        exploited = [t for t in cve_threats if t.get("is_exploited")]
        zero_days = [t for t in cve_threats if t.get("is_zero_day")]
        with_poc = [t for t in cve_threats if t.get("has_poc")]

        if exploited:
            parts.append(f"## Known Exploited ({len(exploited)})\n")
            for t in exploited:
                parts.append(f"  🔴 {t['cve_id']} (CVSS {t.get('cvss_score', 'N/A')})")
                parts.append(f"     {t.get('description', '')[:150]}")
        if zero_days:
            parts.append(f"\n## Zero-Day Risk ({len(zero_days)})\n")
            for t in zero_days:
                parts.append(f"  ⚠ {t['cve_id']} (CVSS {t.get('cvss_score', 'N/A')})")
        if with_poc:
            parts.append(f"\n## Proof-of-Concept Available ({len(with_poc)})\n")
            for t in with_poc:
                parts.append(f"  📄 {t['cve_id']}")
        parts.append("")
        parts.append(f"## Summary")
        parts.append(f"Total CVEs: {len(cve_threats)}")
        parts.append(f"Known Exploited: {len(exploited)}")
        parts.append(f"Zero-Day Candidates: {len(zero_days)}")
        parts.append(f"PoC Available: {len(with_poc)}")

        return "\n".join(parts)

    def close(self):
        self._http.close()