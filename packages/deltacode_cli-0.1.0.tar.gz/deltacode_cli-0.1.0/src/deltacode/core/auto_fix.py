"""Auto-Fix Engine for DeltaCode CLI.

Implements an autonomous security fix loop:
1. Detect vulnerabilities via linters (bandit, semgrep) or DeltaAI
2. Generate remediation via LLM (SEARCH/REPLACE format)
3. Apply patches with dry-run validation
4. Lint to verify the fix
5. Rollback on failure
6. Iterate up to max_reflections times

Uses Aider's editblock parser and flexible search/replace for robust patching.
"""

import os
import re
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from deltacode.client.api import ChatMessage, DeltaAIClient
from deltacode.core.config import DeltaCodeConfig
from deltacode.core.logger import get_logger
from deltacode.core.prompts import get_prompt_template
from deltacode.core.security_linter import SecurityLinter

logger = get_logger(__name__)

SEARCH_HEADER = re.compile(r"^<{5,9}\s*SEARCH>?\s*$", re.MULTILINE)
DIVIDER = re.compile(r"^={5,9}\s*$", re.MULTILINE)
REPLACE_HEADER = re.compile(r"^>{5,9}\s*REPLACE\s*$", re.MULTILINE)

AUTO_FIX_SYSTEM_PROMPT = """You are DeltaCode Auto-Fix, a security remediation engine.

You receive vulnerability findings and must produce precise fixes using SEARCH/REPLACE blocks.

RULES:
1. For each vulnerability, produce exactly one SEARCH/REPLACE block
2. The SEARCH section must match the EXACT original code (including whitespace)
3. The REPLACE section must be the corrected code
4. Precede each block with the filename on its own line
5. Use triple backtick fences around SEARCH/REPLACE content
6. Only fix the reported vulnerability — do not refactor surrounding code
7. If a fix requires multiple files, produce blocks for each file
8. If you cannot safely fix an issue, add a comment explaining why

FORMAT:
```
filename.py
```python
<<<<<<< SEARCH
vulnerable code here
=======
fixed code here
>>>>>>> REPLACE
```

Respond in the same language as the findings."""


@dataclass
class FixResult:
    vulnerability: str
    file: str
    original_code: str
    fixed_code: str
    success: bool = False
    lint_clean: bool = False
    rolled_back: bool = False
    error: str = ""


@dataclass
class AutoFixSession:
    findings: list = field(default_factory=list)
    results: list = field(default_factory=list)
    total_fixes_applied: int = 0
    total_rollbacks: int = 0
    total_lint_failures: int = 0


class AutoFixEngine:
    def __init__(
        self,
        config: DeltaCodeConfig,
        max_reflections: int = 3,
        max_files_per_round: int = 10,
        backup_suffix: str = ".deltacode.bak",
        dry_run: bool = False,
    ):
        self.config = config
        self.client = DeltaAIClient(config)
        self.max_reflections = max_reflections
        self.max_files_per_round = max_files_per_round
        self.backup_suffix = backup_suffix
        self.dry_run = dry_run
        self.linter = SecurityLinter()
        self.session = AutoFixSession()

    def fix_findings(
        self,
        findings: list[str],
        root_path: str = ".",
        category: str = "remediation",
    ) -> AutoFixSession:
        self.session = AutoFixSession(findings=findings)

        findings_text = "\n\n".join(
            f"Finding {i+1}:\n{f}" for i, f in enumerate(findings)
        )

        context_files = self._gather_relevant_files(findings_text, root_path)
        context_content = self._build_context(context_files, root_path)

        user_content = findings_text
        if context_content:
            user_content = f"Source code context:\n{context_content}\n\nVulnerabilities to fix:\n{findings_text}"

        messages = [
            ChatMessage(role="system", content=AUTO_FIX_SYSTEM_PROMPT),
            ChatMessage(role="user", content=user_content),
        ]

        for reflection in range(self.max_reflections):
            console_log(f"Auto-fix round {reflection + 1}/{self.max_reflections}")

            try:
                result = self.client.chat_completion(
                    messages=messages,
                    model=self.config.default_model or "deltaai-rag",
                    category=category,
                    temperature=0.2,
                    max_tokens=8192,
                )
            except Exception as e:
                console_log(f"LLM call failed: {e}")
                break

            if result.was_refused:
                console_log("LLM refused to generate fixes")
                break

            edits = parse_search_replace_blocks(result.content, root_path)
            if not edits:
                console_log("No valid SEARCH/REPLACE blocks found in response")
                if reflection < self.max_reflections - 1:
                    messages.append(ChatMessage(role="assistant", content=result.content))
                    messages.append(ChatMessage(role="user", content="No valid SEARCH/REPLACE blocks were found. Please provide fixes in the exact format with <<<<<<< SEARCH and >>>>>>> REPLACE markers."))
                    continue
                break

            applied = self._apply_edits(edits, root_path)
            if not applied:
                console_log("No edits could be applied")
                break

            lint_results = self._lint_edited(applied, root_path)
            all_clean = all(r.lint_clean for r in lint_results)

            if all_clean:
                console_log(f"All {len(applied)} fixes passed lint")
                break
            else:
                failed = [r for r in lint_results if not r.lint_clean]
                lint_errors = "\n".join(r.error for r in failed)
                console_log(f"{len(failed)} fix(es) have lint errors, retrying...")
                messages.append(ChatMessage(role="assistant", content=result.content))
                messages.append(ChatMessage(role="user", content=f"The following fixes have lint errors:\n\n{lint_errors}\n\nPlease correct these errors and provide updated SEARCH/REPLACE blocks."))

        self.client.close()
        return self.session

    def _gather_relevant_files(self, findings_text: str, root_path: str) -> list[str]:
        relevant = set()
        for line in findings_text.split("\n"):
            line = line.strip()
            if ":" in line:
                potential_file = line.split(":")[0].strip()
                full_path = os.path.join(root_path, potential_file)
                if os.path.isfile(full_path):
                    relevant.add(potential_file)
        return sorted(relevant)[:self.max_files_per_round]

    def _build_context(self, files: list[str], root_path: str) -> str:
        if not files:
            return ""
        parts = []
        for fname in files[:5]:
            fpath = os.path.join(root_path, fname)
            try:
                content = Path(fpath).read_text(encoding="utf-8", errors="replace")
                if len(content) > 3000:
                    content = content[:3000] + "\n... (truncated)"
                parts.append(f"--- {fname} ---\n{content}")
            except Exception:
                pass
        return "\n\n".join(parts)

    def _apply_edits(self, edits: list, root_path: str) -> list[str]:
        applied_files = []
        for edit in edits:
            fname, search_text, replace_text = edit
            fpath = os.path.join(root_path, fname)

            if not os.path.isfile(fpath):
                continue

            try:
                original = Path(fpath).read_text(encoding="utf-8", errors="replace")
            except Exception as e:
                continue

            if search_text not in original:
                best_match = fuzzy_find_chunk(original, search_text)
                if best_match:
                    search_text = best_match
                else:
                    continue

            backup_path = fpath + self.backup_suffix
            shutil.copy2(fpath, backup_path)

            if self.dry_run:
                console_log(f"[DRY RUN] Would apply fix to {fname}")
                applied_files.append(fname)
                continue

            new_content = original.replace(search_text, replace_text, 1)
            try:
                Path(fpath).write_text(new_content, encoding="utf-8")
                applied_files.append(fname)
                self.session.total_fixes_applied += 1
                console_log(f"Applied fix to {fname}")
            except Exception as e:
                console_log(f"Failed to write {fname}: {e}")
                self._restore_backup(fpath)

        return applied_files

    def _lint_edited(self, files: list[str], root_path: str) -> list[FixResult]:
        results = []
        for fname in files:
            fpath = os.path.join(root_path, fname)
            lint_result = self.linter.lint(fpath)
            is_clean = lint_result is None
            fix_result = FixResult(
                vulnerability="",
                file=fname,
                original_code="",
                fixed_code="",
                success=True,
                lint_clean=is_clean,
                error=lint_result or "",
            )

            if not is_clean:
                self.session.total_lint_failures += 1
                self._restore_backup(fpath)
                fix_result.rolled_back = True
                self.session.total_rollbacks += 1
                console_log(f"Lint errors in {fname}, rolled back")

            results.append(fix_result)

        return results

    def _restore_backup(self, fpath: str):
        backup = fpath + self.backup_suffix
        if os.path.exists(backup):
            shutil.copy2(backup, fpath)
            os.remove(backup)

    def cleanup_backups(self, root_path: str = "."):
        for backup in Path(root_path).rglob(f"*{self.backup_suffix}"):
            backup.unlink()


def parse_search_replace_blocks(content: str, root_path: str = ".") -> list[tuple]:
    edits = []
    lines = content.split("\n")
    i = 0

    while i < len(lines):
        if SEARCH_HEADER.match(lines[i].strip()):
            filename = ""
            search_start = i - 1
            for j in range(max(0, i - 3), i):
                stripped = lines[j].strip()
                if stripped and not stripped.startswith("```") and not stripped.startswith("<") and not stripped.startswith("#"):
                    candidate = os.path.join(root_path, stripped) if not os.path.isabs(stripped) else stripped
                    if os.path.isfile(candidate):
                        filename = stripped
                        break

            search_lines = []
            i += 1
            while i < len(lines) and not DIVIDER.match(lines[i].strip()):
                search_lines.append(lines[i])
                i += 1

            if i >= len(lines):
                break
            i += 1

            replace_lines = []
            while i < len(lines) and not REPLACE_HEADER.match(lines[i].strip()):
                replace_lines.append(lines[i])
                i += 1

            if filename and search_lines:
                search_text = "\n".join(search_lines)
                replace_text = "\n".join(replace_lines)
                edits.append((filename, search_text, replace_text))

        i += 1

    return edits


def fuzzy_find_chunk(original: str, search: str, threshold: float = 0.8) -> Optional[str]:
    import difflib
    search_lines = search.split("\n")
    original_lines = original.split("\n")
    search_len = len(search_lines)

    if search_len == 0:
        return None

    best_ratio = 0
    best_chunk = None

    step = max(1, search_len // 4)
    for i in range(0, len(original_lines) - search_len + 1, step):
        chunk = original_lines[i:i + search_len]
        chunk_text = "\n".join(chunk)
        ratio = difflib.SequenceMatcher(None, search, chunk_text).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_chunk = chunk_text

    if best_ratio >= threshold:
        return best_chunk
    return None


def console_log(msg: str):
    try:
        from rich.console import Console
        Console().print(f"[dim]{msg}[/dim]")
    except Exception:
        print(msg)