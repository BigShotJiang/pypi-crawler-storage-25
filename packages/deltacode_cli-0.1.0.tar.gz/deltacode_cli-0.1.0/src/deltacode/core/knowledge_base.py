"""Organizational Knowledge Base for DeltaCode CLI.

Persistent storage and retrieval of:
- Organization-specific vulnerability patterns
- Learned custom rules from past findings
- Project-specific security context
- Remediation patterns and their success rates
- Team knowledge sharing artifacts
"""

from __future__ import annotations

import json
import hashlib
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional

from deltacode.core.cache import DeltaCache
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class KnowledgeEntry:
    id: str
    entry_type: str
    title: str
    content: str
    tags: list = field(default_factory=list)
    project: str = ""
    author: str = ""
    created_at: str = ""
    updated_at: str = ""
    source: str = ""
    confidence: float = 1.0
    metadata: dict = field(default_factory=dict)
    embedding_id: str = ""


@dataclass
class LearnedRule:
    pattern: str
    message: str
    severity: str
    cwe: str
    category: str
    language: str
    source_findings_count: int
    accuracy: float
    created_at: str
    last_matched: str = ""
    is_active: bool = True


@dataclass
class ProjectContext:
    project_path: str
    project_name: str
    architecture_notes: str = ""
    known_patterns: list = field(default_factory=list)
    excluded_paths: list = field(default_factory=list)
    custom_ignore_rules: list = field(default_factory=list)
    last_scan: str = ""
    team_members: list = field(default_factory=list)
    tags: dict = field(default_factory=dict)


class OrgKnowledgeBase:
    def __init__(self, data_dir: str = None):
        self.data_dir = Path(data_dir or Path.home() / ".deltacode" / "knowledge")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._entries: list[KnowledgeEntry] = []
        self._learned_rules: list[LearnedRule] = []
        self._project_contexts: dict[str, ProjectContext] = {}
        self._load()

    def _load(self):
        entries_file = self.data_dir / "entries.json"
        if entries_file.exists():
            try:
                data = json.loads(entries_file.read_text(encoding="utf-8"))
                self._entries = [KnowledgeEntry(**e) for e in data]
            except Exception:
                pass

        rules_file = self.data_dir / "learned_rules.json"
        if rules_file.exists():
            try:
                data = json.loads(rules_file.read_text(encoding="utf-8"))
                self._learned_rules = [LearnedRule(**r) for r in data]
            except Exception:
                pass

        projects_file = self.data_dir / "projects.json"
        if projects_file.exists():
            try:
                data = json.loads(projects_file.read_text(encoding="utf-8"))
                self._project_contexts = {k: ProjectContext(**v) for k, v in data.items()}
            except Exception:
                pass

    def _save(self):
        entries_file = self.data_dir / "entries.json"
        entries_file.write_text(json.dumps(
            [e.__dict__ for e in self._entries], indent=2, ensure_ascii=False
        ), encoding="utf-8")

        rules_file = self.data_dir / "learned_rules.json"
        rules_file.write_text(json.dumps(
            [r.__dict__ for r in self._learned_rules], indent=2, ensure_ascii=False
        ), encoding="utf-8")

        projects_file = self.data_dir / "projects.json"
        projects_file.write_text(json.dumps(
            {k: v.__dict__ for k, v in self._project_contexts.items()},
            indent=2, ensure_ascii=False,
        ), encoding="utf-8")

    # ── Entry Management ──────────────────────────────────────────────────

    def add_entry(self, entry_type: str, title: str, content: str, tags: list = None,
                  project: str = "", author: str = "", source: str = "",
                  metadata: dict = None) -> KnowledgeEntry:
        entry = KnowledgeEntry(
            id=uuid.uuid4().hex[:12],
            entry_type=entry_type,
            title=title,
            content=content,
            tags=tags or [],
            project=project,
            author=author,
            created_at=datetime.utcnow().isoformat(),
            updated_at=datetime.utcnow().isoformat(),
            source=source,
            metadata=metadata or {},
        )
        self._entries.append(entry)
        self._save()
        return entry

    def search_entries(self, query: str, entry_type: str = None, tags: list = None,
                       project: str = None, limit: int = 20) -> list[KnowledgeEntry]:
        query_lower = query.lower()
        results = []

        for e in self._entries:
            if entry_type and e.entry_type != entry_type:
                continue
            if tags and not any(t in e.tags for t in tags):
                continue
            if project and e.project != project:
                continue

            searchable = f"{e.title} {e.content} {' '.join(e.tags)}".lower()
            if query_lower in searchable:
                results.append(e)

        return sorted(results, key=lambda e: e.confidence, reverse=True)[:limit]

    def get_entry(self, entry_id: str) -> Optional[KnowledgeEntry]:
        for e in self._entries:
            if e.id == entry_id:
                return e
        return None

    def delete_entry(self, entry_id: str) -> bool:
        for i, e in enumerate(self._entries):
            if e.id == entry_id:
                self._entries.pop(i)
                self._save()
                return True
        return False

    def get_entries_by_type(self, entry_type: str) -> list[KnowledgeEntry]:
        return [e for e in self._entries if e.entry_type == entry_type]

    def get_tags_cloud(self) -> dict:
        tag_counts = {}
        for e in self._entries:
            for tag in e.tags:
                tag_counts[tag] = tag_counts.get(tag, 0) + 1
        return dict(sorted(tag_counts.items(), key=lambda x: -x[1])[:30])

    # ── Learned Rules ─────────────────────────────────────────────────────

    def learn_rule_from_finding(self, finding: dict, language: str) -> Optional[LearnedRule]:
        description = finding.get("description", finding.get("message", ""))
        cwe = finding.get("cwe", finding.get("cwe_id", ""))
        severity = finding.get("severity", "MEDIUM")
        file_path = finding.get("file", "")
        code_snippet = finding.get("code", "")

        if not description or len(description) < 10:
            return None

        pattern_base = re.sub(r'[^a-zA-Z0-9\s]', '', description)[:40].lower().replace(' ', '_')
        similar = [r for r in self._learned_rules if pattern_base[:20] in r.pattern]

        if similar:
            similar[0].source_findings_count += 1
            similar[0].last_matched = datetime.utcnow().isoformat()
            similar[0].accuracy = min(similar[0].accuracy + 0.05, 1.0)
            self._save()
            return similar[0]

        rule = LearnedRule(
            pattern=f"learned_{pattern_base[:30]}",
            message=f"[Learned] {description[:100]}",
            severity=severity,
            cwe=cwe,
            category=finding.get("category", "learned"),
            language=language,
            source_findings_count=1,
            accuracy=0.5,
            created_at=datetime.utcnow().isoformat(),
            last_matched=datetime.utcnow().isoformat(),
        )
        self._learned_rules.append(rule)
        self._save()
        return rule

    def get_active_rules(self, language: str = None) -> list[LearnedRule]:
        rules = [r for r in self._learned_rules if r.is_active]
        if language:
            rules = [r for r in rules if r.language == language]
        return sorted(rules, key=lambda r: r.accuracy, reverse=True)

    def deactivate_rule(self, rule_index: int) -> bool:
        rules = self._learned_rules
        if 0 <= rule_index < len(rules):
            rules[rule_index].is_active = False
            self._save()
            return True
        return False

    def get_rule_stats(self) -> dict:
        active = [r for r in self._learned_rules if r.is_active]
        return {
            "total_rules": len(self._learned_rules),
            "active_rules": len(active),
            "total_findings": sum(r.source_findings_count for r in self._learned_rules),
            "avg_accuracy": round(
                sum(r.accuracy for r in active) / max(len(active), 1), 2
            ),
        }

    # ── Project Context ───────────────────────────────────────────────────

    def get_project_context(self, project_path: str) -> ProjectContext:
        if project_path not in self._project_contexts:
            name = Path(project_path).name
            self._project_contexts[project_path] = ProjectContext(
                project_path=project_path,
                project_name=name,
            )
            self._save()

        return self._project_contexts[project_path]

    def update_project_context(self, project_path: str, updates: dict):
        ctx = self.get_project_context(project_path)
        for key, value in updates.items():
            if hasattr(ctx, key):
                setattr(ctx, key, value)
        self._save()

    def add_project_pattern(self, project_path: str, pattern: str, notes: str = ""):
        ctx = self.get_project_context(project_path)
        ctx.known_patterns.append({
            "pattern": pattern,
            "notes": notes,
            "added_at": datetime.utcnow().isoformat(),
        })
        self._save()

    def list_projects(self) -> list[dict]:
        return [
            {
                "path": p.project_path,
                "name": p.project_name,
                "patterns": len(p.known_patterns),
                "team_members": len(p.team_members),
                "last_scan": p.last_scan,
            }
            for p in self._project_contexts.values()
        ]

    def get_all_rules_as_custom_rules(self) -> list[dict]:
        return [
            {
                "pattern": r.pattern,
                "message": r.message,
                "severity": r.severity,
                "cwe": r.cwe,
                "language": r.language,
                "category": r.category,
            }
            for r in self._learned_rules
            if r.is_active and r.accuracy >= 0.6
        ]

    # ── Stats ─────────────────────────────────────────────────────────────

    def get_stats(self) -> dict:
        return {
            "total_entries": len(self._entries),
            "by_type": {
                t: len([e for e in self._entries if e.entry_type == t])
                for t in set(e.entry_type for e in self._entries)
            },
            "rules": self.get_rule_stats(),
            "projects": len(self._project_contexts),
            "tags": len(self.get_tags_cloud()),
        }