"""Continuous assessment scheduler for DeltaCode CLI.

Schedules and manages recurring security pipelines:
- Cron-based scheduling
- Event-driven triggers (git push, CI hook)
- Result persistence and history
- Notification on completion/failure
- Configurable policies per project
"""

from __future__ import annotations

import asyncio
import json
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Optional

from deltacode.core.logger import get_logger
from deltacode.core.pipeline import SecurityPipeline, PipelineResult

logger = get_logger(__name__)


@dataclass
class ScheduleConfig:
    name: str
    target: str = "."
    interval_minutes: int = 60
    cron_expression: str = ""
    auto_approve: bool = False
    skip_stages: list = field(default_factory=list)
    notify_on: list = field(default_factory=lambda: ["failure", "critical_findings"])
    max_history: int = 50
    enabled: bool = True
    project_id: str = ""


@dataclass
class ScheduleRun:
    run_id: str
    schedule_name: str
    started_at: str
    completed_at: str = ""
    status: str = "running"
    result: Optional[dict] = None
    error: str = ""


class PipelineScheduler:
    def __init__(self, data_dir: str = None):
        self.data_dir = Path(data_dir or Path.home() / ".deltacode" / "scheduler")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._schedules: dict[str, ScheduleConfig] = {}
        self._runs: dict[str, list[ScheduleRun]] = {}
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._notifications: list[Callable] = []
        self._load()

    def _load(self):
        schedules_file = self.data_dir / "schedules.json"
        if schedules_file.exists():
            try:
                data = json.loads(schedules_file.read_text(encoding="utf-8"))
                for item in data:
                    cfg = ScheduleConfig(**item)
                    self._schedules[cfg.name] = cfg
            except Exception:
                pass

        runs_file = self.data_dir / "runs.json"
        if runs_file.exists():
            try:
                self._runs = json.loads(runs_file.read_text(encoding="utf-8"))
            except Exception:
                pass

    def _save(self):
        schedules_file = self.data_dir / "schedules.json"
        schedules_file.write_text(json.dumps(
            [s.__dict__ for s in self._schedules.values()],
            indent=2, ensure_ascii=False,
        ), encoding="utf-8")

        runs_file = self.data_dir / "runs.json"
        runs_file.write_text(json.dumps(self._runs, indent=2, ensure_ascii=False), encoding="utf-8")

    def add_schedule(self, config: ScheduleConfig) -> str:
        self._schedules[config.name] = config
        self._runs.setdefault(config.name, [])
        self._save()
        logger.info(f"Schedule added: {config.name} (every {config.interval_minutes}min)")
        return config.name

    def remove_schedule(self, name: str) -> bool:
        if name in self._schedules:
            del self._schedules[name]
            self._runs.pop(name, None)
            self._save()
            return True
        return False

    def get_schedule(self, name: str) -> Optional[ScheduleConfig]:
        return self._schedules.get(name)

    def list_schedules(self) -> list[ScheduleConfig]:
        return list(self._schedules.values())

    def get_runs(self, schedule_name: str = None, limit: int = 20) -> list[ScheduleRun]:
        if schedule_name:
            return (self._runs.get(schedule_name, []) or [])[-limit:]
        all_runs = []
        for runs in self._runs.values():
            all_runs.extend(runs or [])
        all_runs.sort(key=lambda r: r.started_at, reverse=True)
        return all_runs[:limit]

    def on_notify(self, callback: Callable):
        self._notifications.append(callback)

    def _notify(self, event: str, data: dict):
        for cb in self._notifications:
            try:
                cb(event, data)
            except Exception:
                pass

    def run_once(self, schedule_name: str) -> dict:
        config = self._schedules.get(schedule_name)
        if not config:
            return {"error": f"Schedule '{schedule_name}' not found"}

        import asyncio

        run = ScheduleRun(
            run_id=uuid.uuid4().hex[:12],
            schedule_name=schedule_name,
            started_at=datetime.utcnow().isoformat(),
        )

        try:
            pipeline = SecurityPipeline(target=config.target, name=f"{schedule_name}-{run.run_id}")
            result = asyncio.run(pipeline.run(
                auto_approve=config.auto_approve,
                skip_stages=config.skip_stages,
            ))
            run.status = result.status
            run.result = result.to_dict()
            run.completed_at = result.completed_at

            critical = len([f for f in result.findings if f.get("severity") == "CRITICAL"])
            if "critical_findings" in config.notify_on and critical > 0:
                self._notify("critical_findings", {"schedule": schedule_name, "critical": critical})

        except Exception as e:
            run.status = "failed"
            run.error = str(e)[:500]
            if "failure" in config.notify_on:
                self._notify("schedule_failed", {"schedule": schedule_name, "error": run.error})

        self._runs.setdefault(schedule_name, [])
        self._runs[schedule_name].append(run)
        history = self._runs[schedule_name]
        if len(history) > config.max_history:
            self._runs[schedule_name] = history[-config.max_history:]
        self._save()
        return {"run": run, "config": config, "status": run.status}

    def run_all(self) -> list[dict]:
        results = []
        for name in self._schedules:
            if self._schedules[name].enabled:
                results.append(self.run_once(name))
        return results

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        logger.info("Scheduler started")

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=10)
        logger.info("Scheduler stopped")

    def _loop(self):
        last_run: dict[str, float] = {}
        for name, cfg in self._schedules.items():
            last_run[name] = time.time()

        while self._running:
            now = time.time()
            for name, cfg in list(self._schedules.items()):
                if not cfg.enabled:
                    continue
                elapsed = now - last_run.get(name, 0)
                if elapsed >= cfg.interval_minutes * 60:
                    logger.info(f"Schedule triggered: {name}")
                    try:
                        self.run_once(name)
                    except Exception as e:
                        logger.error(f"Schedule {name} failed: {e}")
                    last_run[name] = now
            time.sleep(30)  # check every 30s

    def get_status(self) -> dict:
        return {
            "running": self._running,
            "schedules": len(self._schedules),
            "enabled": sum(1 for s in self._schedules.values() if s.enabled),
            "runs": sum(len(r) for r in self._runs.values()),
        }