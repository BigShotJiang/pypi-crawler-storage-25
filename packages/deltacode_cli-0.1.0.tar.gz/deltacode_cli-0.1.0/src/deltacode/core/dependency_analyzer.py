"""Dependency vulnerability analyzer for DeltaCode CLI.

Scans project dependencies for known vulnerabilities using:
- pip-audit (Python)
- safety (Python)
- npm audit (JavaScript/TypeScript)
- cargo audit (Rust)
-license compliance checking
-transitive dependency analysis
"""

import json
import os
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class Vulnerability:
    package: str
    version: str
    vuln_id: str
    severity: str
    description: str
    fixed_version: str = ""
    cwe: str = ""
    url: str = ""
    ecosystem: str = ""


@dataclass
class DependencyReport:
    scanner: str
    ecosystem: str
    vulnerabilities: list = field(default_factory=list)
    total_scanned: int = 0
    total_vulnerable: int = 0
    raw_output: str = ""


class DependencyAnalyzer:
    def __init__(self, root_path: str = "."):
        self.root_path = Path(root_path).resolve()
        self._detected_ecosystems: dict = {}

    def detect_ecosystems(self) -> dict:
        ecosystem_files = {
            "python": [
                "requirements.txt", "Pipfile", "Pipfile.lock",
                "pyproject.toml", "setup.py", "setup.cfg",
                "poetry.lock", "Pipfile.lock",
            ],
            "javascript": [
                "package.json", "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
            ],
            "rust": ["Cargo.toml", "Cargo.lock"],
            "go": ["go.mod", "go.sum"],
            "java": ["pom.xml", "build.gradle", "build.gradle.kts"],
            "dotnet": ["packages.config", "*.csproj"],
            "ruby": ["Gemfile", "Gemfile.lock"],
            "php": ["composer.json", "composer.lock"],
        }

        detected = {}
        for ecosystem, files in ecosystem_files.items():
            for fname in files:
                if fname.startswith("*"):
                    matches = list(self.root_path.glob(fname))
                    if matches:
                        detected[ecosystem] = [str(m.relative_to(self.root_path)) for m in matches]
                        break
                else:
                    fpath = self.root_path / fname
                    if fpath.exists():
                        detected.setdefault(ecosystem, []).append(fname)

        self._detected_ecosystems = detected
        return detected

    def analyze(self, check_licenses: bool = False, check_transitive: bool = True) -> list[DependencyReport]:
        if not self._detected_ecosystems:
            self.detect_ecosystems()

        reports = []

        if "python" in self._detected_ecosystems:
            reports.extend(self._scan_python(check_transitive=check_transitive))

        if "javascript" in self._detected_ecosystems:
            reports.extend(self._scan_javascript())

        if "rust" in self._detected_ecosystems:
            reports.append(self._scan_rust())

        if "go" in self._detected_ecosystems:
            reports.append(self._scan_go())

        if check_licenses:
            reports.append(self._scan_licenses())

        return reports

    def _scan_python(self, check_transitive: bool = True) -> list[DependencyReport]:
        reports = []

        pip_audit_report = self._run_pip_audit()
        if pip_audit_report:
            reports.append(pip_audit_report)

        safety_report = self._run_safety()
        if safety_report:
            reports.append(safety_report)

        if not pip_audit_report and not safety_report:
            reports.append(self._scan_requirements_txt())

        return reports

    def _run_pip_audit(self) -> Optional[DependencyReport]:
        if not self._tool_available("pip-audit"):
            return None

        try:
            result = subprocess.run(
                ["pip-audit", "--format", "json", "--desc"],
                capture_output=True, text=True, timeout=120,
                cwd=str(self.root_path),
            )

            if result.returncode not in (0, 1):
                return DependencyReport(
                    scanner="pip-audit",
                    ecosystem="python",
                    raw_output=result.stderr,
                )

            try:
                data = json.loads(result.stdout)
            except json.JSONDecodeError:
                return DependencyReport(
                    scanner="pip-audit",
                    ecosystem="python",
                    raw_output=result.stdout or result.stderr,
                )

            vulns = []
            for dep in data.get("dependencies", []):
                for skel in dep.get("skipped", []):
                    pass
                for vuln in dep.get("vulns", []):
                    vulns.append(Vulnerability(
                        package=dep.get("name", ""),
                        version=dep.get("version", ""),
                        vuln_id=vuln.get("id", ""),
                        severity=self._severity_from_pip_audit(vuln),
                        description=vuln.get("description", ""),
                        fixed_version=vuln.get("fix_versions", [""])[0] if vuln.get("fix_versions") else "",
                        url=vuln.get("advisory", {}).get("url", ""),
                        ecosystem="python",
                    ))

            return DependencyReport(
                scanner="pip-audit",
                ecosystem="python",
                vulnerabilities=vulns,
                total_scanned=len(data.get("dependencies", [])),
                total_vulnerable=len(vulns),
                raw_output=result.stdout[:2000],
            )

        except subprocess.TimeoutExpired:
            return DependencyReport(scanner="pip-audit", ecosystem="python", raw_output="timeout")
        except Exception as e:
            return DependencyReport(scanner="pip-audit", ecosystem="python", raw_output=str(e))

    def _run_safety(self) -> Optional[DependencyReport]:
        if not self._tool_available("safety"):
            return None

        try:
            result = subprocess.run(
                ["safety", "check", "--json"],
                capture_output=True, text=True, timeout=120,
                cwd=str(self.root_path),
            )

            try:
                data = json.loads(result.stdout)
            except json.JSONDecodeError:
                return DependencyReport(
                    scanner="safety",
                    ecosystem="python",
                    raw_output=result.stdout or result.stderr,
                )

            vulns = []
            issues = data.get("vulnerabilities", []) or data.get("scanned", data)
            if isinstance(issues, list):
                for item in issues:
                    if isinstance(item, dict):
                        vulns.append(Vulnerability(
                            package=item.get("package_name", item.get("name", "")),
                            version=item.get("installed_version", item.get("version", "")),
                            vuln_id=item.get("vulnerability_id", item.get("id", "")),
                            severity=item.get("severity", "MEDIUM").upper(),
                            description=item.get("advisory", ""),
                            fixed_version=item.get("safe_versions", [""])[0] if isinstance(item.get("safe_versions"), list) else str(item.get("safe_versions", "")),
                            ecosystem="python",
                        ))

            return DependencyReport(
                scanner="safety",
                ecosystem="python",
                vulnerabilities=vulns,
                total_vulnerable=len(vulns),
                raw_output=(result.stdout or result.stderr)[:2000],
            )

        except subprocess.TimeoutExpired:
            return DependencyReport(scanner="safety", ecosystem="python", raw_output="timeout")
        except Exception as e:
            return DependencyReport(scanner="safety", ecosystem="python", raw_output=str(e))

    def _scan_requirements_txt(self) -> DependencyReport:
        vulns = []
        req_files = ["requirements.txt", "requirements-dev.txt", "requirements-prod.txt"]
        scanned = []

        for fname in req_files:
            fpath = self.root_path / fname
            if not fpath.exists():
                continue
            scanned.append(fname)
            try:
                content = fpath.read_text(encoding="utf-8", errors="replace")
                for line in content.splitlines():
                    line = line.strip()
                    if not line or line.startswith("#") or line.startswith("-"):
                        continue

                    known_vulnerable = {
                        "django": {"<2.2": "CVE-2019-6975", "<3.2": "CVE-2021-31542"},
                        "flask": {"<1.0": "CVE-2018-1000656"},
                        "requests": {"<2.20.0": "CVE-2018-18074"},
                        "pyyaml": {"<5.3.1": "CVE-2020-14343"},
                        "pillow": {"<8.1.1": "CVE-2021-27945"},
                        "urllib3": {"<1.26.5": "CVE-2021-33503"},
                        "cryptography": {"<3.4": "CVE-2021-2336"},
                    }

                    pkg_match = re.match(r'^([A-Za-z0-9_.-]+)\s*[=~<>!]+\s*([0-9.]+)', line)
                    if pkg_match:
                        pkg_name = pkg_match.group(1).lower().replace("-", "_")
                        version = pkg_match.group(2)

                        if pkg_name in known_vulnerable:
                            for ver_spec, cve_id in known_vulnerable[pkg_name].items():
                                vulns.append(Vulnerability(
                                    package=pkg_match.group(1),
                                    version=version,
                                    vuln_id=cve_id,
                                    severity="MEDIUM",
                                    description=f"Known vulnerability in {pkg_match.group(1)} {ver_spec}",
                                    ecosystem="python",
                                ))

            except Exception:
                pass

        return DependencyReport(
            scanner="requirements_txt_static",
            ecosystem="python",
            vulnerabilities=vulns,
            total_scanned=len(scanned),
            total_vulnerable=len(vulns),
        )

    def _scan_javascript(self) -> list[DependencyReport]:
        reports = []
        npm_report = self._run_npm_audit()
        if npm_report:
            reports.append(npm_report)
        return reports

    def _run_npm_audit(self) -> Optional[DependencyReport]:
        if not self._tool_available("npm"):
            return None

        try:
            result = subprocess.run(
                ["npm", "audit", "--json"],
                capture_output=True, text=True, timeout=120,
                cwd=str(self.root_path),
            )

            try:
                data = json.loads(result.stdout or result.stderr)
            except json.JSONDecodeError:
                return DependencyReport(
                    scanner="npm_audit",
                    ecosystem="javascript",
                    raw_output=(result.stdout or result.stderr)[:2000],
                )

            vulns = []
            vulnerabilities = data.get("vulnerabilities", {})

            for pkg_name, info in vulnerabilities.items():
                if isinstance(info, dict):
                    severity = info.get("severity", "medium").upper()
                    via = info.get("via", [])
                    if isinstance(via, list):
                        for v in via:
                            if isinstance(v, dict):
                                vulns.append(Vulnerability(
                                    package=pkg_name,
                                    version=info.get("version", ""),
                                    vuln_id=v.get("url", ""),
                                    severity=severity,
                                    description=v.get("title", v.get("url", "")),
                                    url=v.get("url", ""),
                                    ecosystem="javascript",
                                ))
                                break
                        else:
                            vulns.append(Vulnerability(
                                package=pkg_name,
                                version=info.get("version", ""),
                                vuln_id="",
                                severity=severity,
                                description=str(via)[:200] if via else "",
                                ecosystem="javascript",
                            ))

            metadata = data.get("metadata", {})
            total_deps = metadata.get("dependencies", {}).get("production", 0) + metadata.get("dependencies", {}).get("development", 0)

            return DependencyReport(
                scanner="npm_audit",
                ecosystem="javascript",
                vulnerabilities=vulns,
                total_scanned=total_deps or len(vulnerabilities),
                total_vulnerable=len(vulns),
                raw_output=(result.stdout or result.stderr)[:2000],
            )

        except subprocess.TimeoutExpired:
            return DependencyReport(scanner="npm_audit", ecosystem="javascript", raw_output="timeout")
        except Exception as e:
            return DependencyReport(scanner="npm_audit", ecosystem="javascript", raw_output=str(e))

    def _scan_rust(self) -> DependencyReport:
        if not self._tool_available("cargo"):
            return DependencyReport(scanner="cargo_audit", ecosystem="rust")

        try:
            result = subprocess.run(
                ["cargo", "audit", "--json"],
                capture_output=True, text=True, timeout=120,
                cwd=str(self.root_path),
            )

            try:
                data = json.loads(result.stdout)
            except json.JSONDecodeError:
                return DependencyReport(
                    scanner="cargo_audit",
                    ecosystem="rust",
                    raw_output=result.stdout or result.stderr,
                )

            vulns = []
            for vuln in data.get("vulnerabilities", {}).get("list", []):
                vulns.append(Vulnerability(
                    package=vuln.get("advisory", {}).get("package", ""),
                    version="",
                    vuln_id=vuln.get("advisory", {}).get("id", ""),
                    severity=vuln.get("advisory", {}).get("severity", "MEDIUM").upper(),
                    description=vuln.get("advisory", {}).get("title", ""),
                    url=vuln.get("advisory", {}).get("url", ""),
                    ecosystem="rust",
                ))

            return DependencyReport(
                scanner="cargo_audit",
                ecosystem="rust",
                vulnerabilities=vulns,
                total_vulnerable=len(vulns),
                raw_output=(result.stdout or result.stderr)[:2000],
            )

        except subprocess.TimeoutExpired:
            return DependencyReport(scanner="cargo_audit", ecosystem="rust", raw_output="timeout")
        except Exception as e:
            return DependencyReport(scanner="cargo_audit", ecosystem="rust", raw_output=str(e))

    def _scan_go(self) -> DependencyReport:
        if not self._tool_available("go"):
            return DependencyReport(scanner="govulncheck", ecosystem="go")

        try:
            result = subprocess.run(
                ["go", "run", "golang.org/x/vuln/cmd/govulncheck@latest", "-json", "./..."],
                capture_output=True, text=True, timeout=180,
                cwd=str(self.root_path),
            )

            vulns = []
            for line in result.stdout.splitlines():
                try:
                    entry = json.loads(line)
                    if entry.get("config"):
                        continue
                    finding = entry.get("finding", entry)
                    if isinstance(finding, dict) and finding.get("osv"):
                        vulns.append(Vulnerability(
                            package=finding.get("module", finding.get("package", "")),
                            version="",
                            vuln_id=finding.get("osv", ""),
                            severity=finding.get("severity", "MEDIUM").upper(),
                            description=finding.get("message", ""),
                            ecosystem="go",
                        ))
                except (json.JSONDecodeError, AttributeError):
                    continue

            return DependencyReport(
                scanner="govulncheck",
                ecosystem="go",
                vulnerabilities=vulns,
                total_vulnerable=len(vulns),
                raw_output=result.stdout[:2000],
            )

        except subprocess.TimeoutExpired:
            return DependencyReport(scanner="govulncheck", ecosystem="go", raw_output="timeout")
        except Exception as e:
            return DependencyReport(scanner="govulncheck", ecosystem="go", raw_output=str(e))

    def _scan_licenses(self) -> DependencyReport:
        license_categories = {
            "permissive": [
                "mit", "apache-2.0", "apache-2.0-with-classpath-exception",
                "bsd-2-clause", "bsd-3-clause", "isc", "0bsd",
                "unlicense", "zlib", "psf-2.0",
            ],
            "copyleft": [
                "gpl-2.0", "gpl-3.0", "agpl-3.0", "lgpl-2.1", "lgpl-3.0",
            ],
            "restrictive": [
                "sspl-1.0", "bsl-1.0", "elastic-2.0",
            ],
        }

        issues = []

        if "python" in self._detected_ecosystems:
            issues.extend(self._check_python_licenses(license_categories))

        if "javascript" in self._detected_ecosystems:
            issues.extend(self._check_npm_licenses(license_categories))

        return DependencyReport(
            scanner="license_check",
            ecosystem="multi",
            vulnerabilities=issues,
            total_vulnerable=len(issues),
        )

    def _check_python_licenses(self, categories: dict) -> list:
        issues = []

        lock_files = ["poetry.lock", "Pipfile.lock"]
        req_files = ["requirements.txt"]

        all_files = lock_files + req_files
        for fname in all_files:
            fpath = self.root_path / fname
            if not fpath.exists():
                continue

            try:
                content = fpath.read_text(encoding="utf-8", errors="replace")
                for line in content.splitlines():
                    line = line.strip()
                    if not line or line.startswith("#") or line.startswith("-"):
                        continue
                    pkg_match = re.match(r'^([A-Za-z0-9_.-]+)', line)
                    if pkg_match:
                        pkg_name = pkg_match.group(1)
                        issues.append(Vulnerability(
                            package=pkg_name,
                            version="",
                            vuln_id="LICENSE-UNKNOWN",
                            severity="LOW",
                            description=f"License for {pkg_name} could not be verified automatically",
                            ecosystem="python",
                        ))
            except Exception:
                pass

        return issues

    def _check_npm_licenses(self, categories: dict) -> list:
        issues = []

        pkg_lock = self.root_path / "package-lock.json"
        if not pkg_lock.exists():
            return issues

        try:
            data = json.loads(pkg_lock.read_text(encoding="utf-8"))
            packages = data.get("packages", {})
            for pkg_path, pkg_info in packages.items():
                if not pkg_path:
                    continue
                pkg_name = pkg_path.replace("node_modules/", "")
                license_str = pkg_info.get("license", "")

                if not license_str:
                    issues.append(Vulnerability(
                        package=pkg_name,
                        version=pkg_info.get("version", ""),
                        vuln_id="LICENSE-UNKNOWN",
                        severity="LOW",
                        description=f"No license specified for {pkg_name}",
                        ecosystem="javascript",
                    ))
                elif isinstance(license_str, str) and license_str.lower() in categories["copyleft"]:
                    issues.append(Vulnerability(
                        package=pkg_name,
                        version=pkg_info.get("version", ""),
                        vuln_id="LICENSE-COPLYLEFT",
                        severity="MEDIUM",
                        description=f"Copyleft license {license_str} may have restrictions",
                        ecosystem="javascript",
                    ))
        except Exception:
            pass

        return issues

    @staticmethod
    def _severity_from_pip_audit(vuln: dict) -> str:
        severity_map = {
            "HIGH": "HIGH",
            "MODERATE": "MEDIUM",
            "LOW": "LOW",
            "CRITICAL": "CRITICAL",
        }
        for key in ("severity", "rating"):
            val = vuln.get(key, "")
            if val:
                return severity_map.get(val.upper(), "MEDIUM")
        return "MEDIUM"

    @staticmethod
    def _tool_available(tool_name: str) -> bool:
        try:
            result = subprocess.run(
                [tool_name, "--version"] if tool_name != "go" else ["go", "version"],
                capture_output=True, text=True, timeout=10,
            )
            return result.returncode == 0
        except Exception:
            return False

    def format_report(self, reports: list[DependencyReport], brief: bool = False) -> str:
        if not reports:
            return "No dependency analysis results."

        parts = []
        total_vulns = 0

        for report in reports:
            if report.raw_output and report.raw_output in ("timeout",) and not report.vulnerabilities:
                parts.append(f"## {report.scanner} ({report.ecosystem})\n⏱ Scan timed out\n")
                continue

            if not report.vulnerabilities:
                parts.append(f"## {report.scanner} ({report.ecosystem})\n✓ No vulnerabilities found\n")
                continue

            total_vulns += len(report.vulnerabilities)
            parts.append(f"## {report.scanner} ({report.ecosystem}) — {len(report.vulnerabilities)} finding(s)")

            severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
            sorted_vulns = sorted(report.vulnerabilities, key=lambda v: severity_order.get(v.severity, 3))

            for v in sorted_vulns:
                sev_icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(v.severity, "⚪")
                if brief:
                    parts.append(f"  {sev_icon} {v.package} {v.version} — {v.vuln_id} ({v.severity})")
                else:
                    parts.append(f"  {sev_icon} {v.package} {v.version}")
                    parts.append(f"     ID: {v.vuln_id}")
                    parts.append(f"     Severity: {v.severity}")
                    if v.description:
                        parts.append(f"     Description: {v.description[:200]}")
                    if v.fixed_version:
                        parts.append(f"     Fixed in: {v.fixed_version}")
                    if v.url:
                        parts.append(f"     URL: {v.url}")
                    parts.append("")

            parts.append("")

        summary = f"Total vulnerabilities: {total_vulns}"
        if total_vulns > 0:
            crit = sum(1 for r in reports for v in r.vulnerabilities if v.severity == "CRITICAL")
            high = sum(1 for r in reports for v in r.vulnerabilities if v.severity == "HIGH")
            med = sum(1 for r in reports for v in r.vulnerabilities if v.severity == "MEDIUM")
            low = sum(1 for r in reports for v in r.vulnerabilities if v.severity == "LOW")
            summary += f"\n  CRITICAL: {crit} | HIGH: {high} | MEDIUM: {med} | LOW: {low}"

        return "\n".join(parts) + f"\n{'='*50}\n{summary}"

    def quick_scan(self, check_licenses: bool = False) -> str:
        reports = self.analyze(check_licenses=check_licenses)
        return self.format_report(reports, brief=False)