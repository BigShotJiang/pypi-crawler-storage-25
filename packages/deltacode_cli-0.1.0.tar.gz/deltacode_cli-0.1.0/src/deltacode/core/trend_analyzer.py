"""Trend analysis engine for DeltaCode CLI.

Tracks finding patterns over time:
- Vulnerability type frequency trends
- Severity distribution changes
- Fix time trends
- False positive rate trends
- Compliance score trends
"""

from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class FindingSnapshot:
    timestamp: str
    total_findings: int
    by_severity: dict
    by_cwe: dict
    by_category: dict
    fix_rate: float = 0.0
    false_positive_rate: float = 0.0
    compliance_score: float = 0.0


class TrendAnalyzer:
    def __init__(self, data_dir: str = None):
        self.data_dir = Path(data_dir or Path.home() / ".deltacode" / "trends")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._snapshots: list[FindingSnapshot] = []
        self._load()

    def _load(self):
        sf = self.data_dir / "snapshots.json"
        if sf.exists():
            try:
                data = json.loads(sf.read_text(encoding="utf-8"))
                self._snapshots = [FindingSnapshot(**s) for s in data]
            except Exception:
                pass

    def _save(self):
        sf = self.data_dir / "snapshots.json"
        sf.write_text(json.dumps(
            [s.__dict__ for s in self._snapshots], indent=2, ensure_ascii=False
        ), encoding="utf-8")

    def record_snapshot(self, findings: list, fix_rate: float = 0.0,
                        fp_rate: float = 0.0, compliance_score: float = 0.0) -> FindingSnapshot:
        by_severity = defaultdict(int)
        by_cwe = defaultdict(int)
        by_category = defaultdict(int)

        for f in findings:
            sev = f.get("severity", "MEDIUM")
            cwe = f.get("cwe", f.get("cwe_id", "CWE-unknown"))
            cat = f.get("category", "general")

            by_severity[sev] += 1
            by_cwe[cwe] += 1
            by_category[cat] += 1

        snapshot = FindingSnapshot(
            timestamp=datetime.utcnow().isoformat(),
            total_findings=len(findings),
            by_severity=dict(by_severity),
            by_cwe=dict(sorted(by_cwe.items(), key=lambda x: -x[1])[:10]),
            by_category=dict(by_category),
            fix_rate=fix_rate,
            false_positive_rate=fp_rate,
            compliance_score=compliance_score,
        )
        self._snapshots.append(snapshot)
        self._save()
        return snapshot

    def get_trend(self, metric: str = "total_findings", days: int = 90) -> list[dict]:
        cutoff = datetime.utcnow() - timedelta(days=days)
        recent = [s for s in self._snapshots if datetime.fromisoformat(s.timestamp) > cutoff]

        if metric == "total_findings":
            return [{"date": s.timestamp[:10], "value": s.total_findings} for s in recent]
        elif metric == "by_severity":
            result = []
            for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
                result.append({
                    "metric": f"severity_{sev.lower()}",
                    "data": [{"date": s.timestamp[:10], "value": s.by_severity.get(sev, 0)} for s in recent],
                })
            return result
        elif metric == "fix_rate":
            return [{"date": s.timestamp[:10], "value": s.fix_rate} for s in recent if s.fix_rate > 0]
        elif metric == "compliance_score":
            return [{"date": s.timestamp[:10], "value": s.compliance_score} for s in recent if s.compliance_score > 0]
        return []

    def get_summary(self, days: int = 90) -> dict:
        cutoff = datetime.utcnow() - timedelta(days=days)
        recent = [s for s in self._snapshots if datetime.fromisoformat(s.timestamp) > cutoff]

        if not recent:
            return {"message": "No data in period", "days": days}

        first = recent[0]
        last = recent[-1]

        total_trend = last.total_findings - first.total_findings if recent else 0

        cwe_accum = defaultdict(int)
        for s in recent:
            for cwe, count in s.by_cwe.items():
                cwe_accum[cwe] += count
        top_cwes = dict(sorted(cwe_accum.items(), key=lambda x: -x[1])[:5])

        severity_trend = {}
        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            start = first.by_severity.get(sev, 0)
            end = last.by_severity.get(sev, 0)
            severity_trend[sev] = {"start": start, "end": end, "change": end - start}

        avg_fix_rate = round(sum(s.fix_rate for s in recent if s.fix_rate > 0) / max(sum(1 for s in recent if s.fix_rate > 0), 1), 1)
        avg_compliance = round(sum(s.compliance_score for s in recent if s.compliance_score > 0) / max(sum(1 for s in recent if s.compliance_score > 0), 1), 1)

        return {
            "period_days": days,
            "snapshots": len(recent),
            "total_findings_trend": total_trend,
            "first_total": first.total_findings,
            "last_total": last.total_findings,
            "top_cwes": top_cwes,
            "severity_trend": severity_trend,
            "avg_fix_rate": avg_fix_rate,
            "avg_compliance_score": avg_compliance,
        }

    def format_trend_report(self, days: int = 90) -> str:
        summary = self.get_summary(days)
        if "message" in summary:
            return f"No trend data in the last {days} days."

        lines = [f"# Trend Analysis Report (Last {days} Days)\n"]
        lines.append(f"Snapshots: {summary['snapshots']}")
        lines.append(f"Findings: {summary['first_total']} → {summary['last_total']} (change: {summary['total_findings_trend']:+d})")
        lines.append("")
        lines.append("## Severity Trends")
        for sev, data in summary.get("severity_trend", {}).items():
            arrow = "↑" if data['change'] > 0 else "↓" if data['change'] < 0 else "→"
            lines.append(f"  {sev}: {data['start']} → {data['end']} ({arrow}{abs(data['change'])})")
        lines.append("")
        lines.append("## Top CWEs (Total)")
        for cwe, count in summary.get("top_cwes", {}).items():
            lines.append(f"  {cwe}: {count}")
        lines.append("")
        lines.append(f"## Metrics")
        lines.append(f"Avg Fix Rate: {summary.get('avg_fix_rate', 0)}%")
        lines.append(f"Avg Compliance Score: {summary.get('avg_compliance_score', 0)}%")
        return "\n".join(lines)