"""Security-focused Git integration for DeltaCode CLI.

Extends Aider's GitRepo with security-aware commit messages,
pre-commit hooks, diff scanning, and baseline snapshots.
"""

import hashlib
import json
import os
import re
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


SECURITY_COMMIT_PREFIXES = {
    "fix": "fix(security):",
    "refactor": "refactor(security):",
    "feat": "feat(security):",
    "remove": "remove(security):",
    "add": "add(security):",
}

SENSITIVE_PATTERNS = [
    (re.compile(r'(?:password|passwd|pwd)\s*[:=]\s*["\'][^"\']+["\']', re.I), "Hardcoded password"),
    (re.compile(r'(?:api[_-]?key|apikey)\s*[:=]\s*["\'][^"\']+["\']', re.I), "Hardcoded API key"),
    (re.compile(r'(?:secret|token|auth)\s*[:=]\s*["\'][^"\']+["\']', re.I), "Hardcoded secret/token"),
    (re.compile(r'-----BEGIN (?:RSA |EC |DSA )?PRIVATE KEY-----'), "Private key in code"),
    (re.compile(r'(?:AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}'), "AWS Access Key"),
    (re.compile(r'eyJ[A-Za-z0-9-_]+\.eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+'), "JWT token"),
    (re.compile(r'(?:mongodb|postgres|mysql|redis)://[^\s"\']+:[^\s"\']+@[^\s"\']+', re.I), "Database connection string with credentials"),
]


class SecurityGitIntegration:
    def __init__(self, repo_path: str = ".", config=None):
        self.repo_path = Path(repo_path).resolve()
        self.config = config
        self._baseline_dir = self.repo_path / ".deltacode" / "baselines"

    def scan_diff_for_secrets(self, diff_text: str) -> list:
        findings = []
        for pattern, description in SENSITIVE_PATTERNS:
            for match in pattern.finditer(diff_text):
                line_start = diff_text[:match.start()].count("\n") + 1
                findings.append({
                    "type": "secret",
                    "description": description,
                    "line": line_start,
                    "match": match.group()[:50] + "..." if len(match.group()) > 50 else match.group(),
                    "severity": "CRITICAL",
                })
        return findings

    def scan_diff_for_vulnerabilities(self, diff_text: str) -> list:
        findings = []
        dangerous_additions = [
            (re.compile(r'^\+.*eval\s*\(', re.M), "eval() usage — potential code injection"),
            (re.compile(r'^\+.*shell\s*=\s*True', re.M), "shell=True — potential command injection"),
            (re.compile(r'^\+.*innerHTML\s*=', re.M), "innerHTML assignment — potential XSS"),
            (re.compile(r'^\+.*document\.write\s*\(', re.M), "document.write — potential XSS"),
            (re.compile(r'^\+.*SELECT\s+.*\+\s*.*FROM', re.I | re.M), "String concatenation in SQL — potential injection"),
            (re.compile(r'^\+.*hashlib\.(md5|sha1)\s*\(', re.M), "Weak hash algorithm MD5/SHA1"),
            (re.compile(r'^\+.*random\.(random|randint|choice)\s*\(', re.M), "Insecure random for security context"),
            (re.compile(r'^\+.*\bTODO\b.*(?:security|vuln|hack|fixme)', re.I), "Security TODO in code — unresolved issue"),
        ]
        for pattern, description in dangerous_additions:
            for match in pattern.finditer(diff_text):
                line_start = diff_text[:match.start()].count("\n") + 1
                findings.append({
                    "type": "vulnerability",
                    "description": description,
                    "line": line_start,
                    "match": match.group().strip()[:80],
                    "severity": "HIGH",
                })
        return findings

    def scan_diff(self, diff_text: str) -> dict:
        secrets = self.scan_diff_for_secrets(diff_text)
        vulns = self.scan_diff_for_vulnerabilities(diff_text)
        all_findings = secrets + vulns
        return {
            "safe": not any(f["severity"] == "CRITICAL" for f in all_findings),
            "findings": all_findings,
            "summary": {
                "critical": sum(1 for f in all_findings if f["severity"] == "CRITICAL"),
                "high": sum(1 for f in all_findings if f["severity"] == "HIGH"),
                "total": len(all_findings),
            },
        }

    def generate_security_commit_message(self, diff_text: str, findings: list = None) -> str:
        if findings is None:
            result = self.scan_diff(diff_text)
            findings = result["findings"]

        if not findings:
            return "chore: security review — no issues found"

        severities = set(f["severity"] for f in findings)
        types = set(f["type"] for f in findings)

        if "CRITICAL" in severities or "secret" in types:
            prefix = "fix(security):"
        elif "HIGH" in severities:
            prefix = "fix(security):"
        else:
            prefix = "refactor(security):"

        top_findings = findings[:3]
        desc_parts = []
        for f in top_findings:
            short_desc = f["description"].split("—")[0].strip() if "—" in f["description"] else f["description"]
            desc_parts.append(short_desc.lower().replace(" ", "-"))

        body = ", ".join(desc_parts)
        return f"{prefix} address {body}" + (f" (+{len(findings) - 3} more)" if len(findings) > 3 else "")

    def create_security_baseline(self, name: str = None) -> dict:
        self._baseline_dir.mkdir(parents=True, exist_ok=True)

        if name is None:
            name = datetime.now().strftime("%Y%m%d_%H%M%S")

        git_result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True, text=True, cwd=str(self.repo_path)
        )
        commit_sha = git_result.stdout.strip() if git_result.returncode == 0 else "unknown"

        tracked_result = subprocess.run(
            ["git", "ls-files"],
            capture_output=True, text=True, cwd=str(self.repo_path)
        )
        tracked_files = tracked_result.stdout.strip().split("\n") if tracked_result.returncode == 0 else []

        file_hashes = {}
        for fname in tracked_files:
            fpath = self.repo_path / fname
            if fpath.exists():
                try:
                    content = fpath.read_bytes()
                    file_hashes[fname] = hashlib.sha256(content).hexdigest()[:16]
                except Exception:
                    pass

        baseline = {
            "name": name,
            "created_at": datetime.now().isoformat(),
            "commit_sha": commit_sha,
            "file_count": len(tracked_files),
            "files": tracked_files,
            "file_hashes": file_hashes,
        }

        baseline_path = self._baseline_dir / f"{name}.json"
        baseline_path.write_text(json.dumps(baseline, indent=2))

        return baseline

    def compare_with_baseline(self, name: str) -> dict:
        baseline_path = self._baseline_dir / f"{name}.json"
        if not baseline_path.exists():
            return {"error": f"Baseline '{name}' not found"}

        baseline = json.loads(baseline_path.read_text())
        current_hashes = {}

        added_files = []
        removed_files = []
        modified_files = []

        for fname in baseline.get("files", []):
            fpath = self.repo_path / fname
            if not fpath.exists():
                removed_files.append(fname)
                continue
            try:
                content = fpath.read_bytes()
                current_hash = hashlib.sha256(content).hexdigest()[:16]
                current_hashes[fname] = current_hash
                old_hash = baseline.get("file_hashes", {}).get(fname)
                if old_hash and current_hash != old_hash:
                    modified_files.append(fname)
            except Exception:
                pass

        git_result = subprocess.run(
            ["git", "ls-files"],
            capture_output=True, text=True, cwd=str(self.repo_path)
        )
        if git_result.returncode == 0:
            current_tracked = set(git_result.stdout.strip().split("\n"))
            baseline_tracked = set(baseline.get("files", []))
            for fname in current_tracked - baseline_tracked:
                if fname not in current_hashes:
                    added_files.append(fname)

        return {
            "baseline_name": name,
            "baseline_commit": baseline.get("commit_sha"),
            "current_vs_baseline": {
                "added": added_files,
                "removed": removed_files,
                "modified": modified_files,
            },
            "total_changes": len(added_files) + len(removed_files) + len(modified_files),
            "safe": len(removed_files) == 0,
        }

    def list_baselines(self) -> list:
        if not self._baseline_dir.exists():
            return []
        baselines = []
        for f in self._baseline_dir.glob("*.json"):
            try:
                data = json.loads(f.read_text())
                baselines.append({
                    "name": data.get("name", f.stem),
                    "created_at": data.get("created_at"),
                    "commit_sha": data.get("commit_sha"),
                    "file_count": data.get("file_count", 0),
                })
            except Exception:
                pass
        baselines.sort(key=lambda x: x.get("created_at", ""), reverse=True)
        return baselines

    def create_security_branch(self, branch_name: str = None, base: str = "main") -> dict:
        try:
            if branch_name is None:
                timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
                branch_name = f"security/fix-{timestamp}"

            result = subprocess.run(
                ["git", "branch", branch_name, base],
                capture_output=True, text=True, cwd=str(self.repo_path)
            )
            if result.returncode != 0:
                return {"branch_name": branch_name, "created": False, "base": base, "error": result.stderr.strip()}

            return {"branch_name": branch_name, "created": True, "base": base, "error": None}
        except Exception as e:
            return {"branch_name": branch_name, "created": False, "base": base, "error": str(e)}

    def switch_to_branch(self, branch_name: str) -> dict:
        try:
            stashed = False
            status_result = subprocess.run(
                ["git", "status", "--porcelain"],
                capture_output=True, text=True, cwd=str(self.repo_path)
            )
            has_changes = bool(status_result.stdout.strip()) if status_result.returncode == 0 else False

            if has_changes:
                stash_result = subprocess.run(
                    ["git", "stash", "push", "-m", f"deltacode-auto-stash-before-{branch_name}"],
                    capture_output=True, text=True, cwd=str(self.repo_path)
                )
                stashed = stash_result.returncode == 0

            checkout_result = subprocess.run(
                ["git", "checkout", branch_name],
                capture_output=True, text=True, cwd=str(self.repo_path)
            )
            if checkout_result.returncode != 0:
                if stashed:
                    subprocess.run(
                        ["git", "stash", "pop"],
                        capture_output=True, text=True, cwd=str(self.repo_path)
                    )
                return {"switched": False, "branch": branch_name, "stashed": stashed, "error": checkout_result.stderr.strip()}

            return {"switched": True, "branch": branch_name, "stashed": stashed, "error": None}
        except Exception as e:
            return {"switched": False, "branch": branch_name, "stashed": False, "error": str(e)}

    def auto_security_branch(self, findings: list, base: str = "main") -> dict:
        try:
            if not findings:
                return {"error": "No findings provided", "branch_created": False, "switched": False}

            top_cwe = findings[0].get("cwe", "")
            top_desc = findings[0].get("description", "unknown").lower().replace(" ", "-")[:40]
            if top_cwe:
                branch_name = f"security/{top_cwe}-{top_desc}"
            else:
                short_hash = hashlib.md5(str(findings).encode()).hexdigest()[:8]
                branch_name = f"security/fix-{short_hash}"

            create_result = self.create_security_branch(branch_name, base)
            if not create_result["created"]:
                return {"error": create_result.get("error"), "branch_created": False, "switched": False}

            switch_result = self.switch_to_branch(branch_name)
            if not switch_result["switched"]:
                return {"error": switch_result.get("error"), "branch_created": True, "switched": False}

            fix_result = {"applied": False, "message": "auto_fix not available, manual fix needed"}
            if hasattr(self, "auto_fix") and callable(self.auto_fix):
                try:
                    fix_result = self.auto_fix(findings)
                except Exception as fx:
                    fix_result = {"applied": False, "message": str(fx)}

            commit_result = {"committed": False}
            if fix_result.get("applied"):
                commit_result = self.commit_with_security_message(findings=findings)

            return {
                "branch_name": branch_name,
                "base": base,
                "branch_created": True,
                "switched": True,
                "fix_applied": fix_result.get("applied", False),
                "fix_message": fix_result.get("message", ""),
                "committed": commit_result.get("committed", False),
                "commit_hash": commit_result.get("hash"),
                "needs_manual_fix": not fix_result.get("applied", False),
                "needs_manual_commit": not commit_result.get("committed", False),
                "error": None,
            }
        except Exception as e:
            return {"error": str(e), "branch_created": False, "switched": False}

    def list_security_branches(self) -> list:
        try:
            result = subprocess.run(
                ["git", "branch", "--list", "security/*", "fix/*"],
                capture_output=True, text=True, cwd=str(self.repo_path)
            )
            if result.returncode != 0:
                return []

            branches = []
            for line in result.stdout.strip().split("\n"):
                if not line.strip():
                    continue
                name = line.strip().replace("* ", "").strip()

                log_result = subprocess.run(
                    ["git", "log", "-1", "--format=%H %s", name],
                    capture_output=True, text=True, cwd=str(self.repo_path)
                )
                latest_commit = ""
                if log_result.returncode == 0 and log_result.stdout.strip():
                    parts = log_result.stdout.strip().split(" ", 1)
                    latest_commit = parts[0] if parts else ""

                ahead_result = subprocess.run(
                    ["git", "rev-list", "--count", f"{name}..{name}@{'{upstream}'}"],
                    capture_output=True, text=True, cwd=str(self.repo_path)
                )
                ahead = 0
                if ahead_result.returncode == 0 and ahead_result.stdout.strip().isdigit():
                    ahead = int(ahead_result.stdout.strip())

                branches.append({
                    "name": name,
                    "latest_commit": latest_commit,
                    "ahead": ahead,
                })

            return branches
        except Exception:
            return []

    def delete_security_branch(self, branch_name: str) -> dict:
        try:
            result = subprocess.run(
                ["git", "branch", "--delete", branch_name],
                capture_output=True, text=True, cwd=str(self.repo_path)
            )
            if result.returncode != 0:
                return {"deleted": False, "branch": branch_name, "error": result.stderr.strip()}

            return {"deleted": True, "branch": branch_name, "error": None}
        except Exception as e:
            return {"deleted": False, "branch": branch_name, "error": str(e)}

    def commit_with_security_message(self, paths: list = None, findings: list = None) -> dict:
        try:
            if paths:
                add_result = subprocess.run(
                    ["git", "add", "--"] + paths,
                    capture_output=True, text=True, cwd=str(self.repo_path)
                )
                if add_result.returncode != 0:
                    return {"committed": False, "message": "", "hash": "", "error": add_result.stderr.strip()}
            else:
                add_result = subprocess.run(
                    ["git", "add", "-A"],
                    capture_output=True, text=True, cwd=str(self.repo_path)
                )
                if add_result.returncode != 0:
                    return {"committed": False, "message": "", "hash": "", "error": add_result.stderr.strip()}

            diff_result = subprocess.run(
                ["git", "diff", "--cached"],
                capture_output=True, text=True, cwd=str(self.repo_path)
            )
            diff_text = diff_result.stdout if diff_result.returncode == 0 else ""
            commit_msg = self.generate_security_commit_message(diff_text, findings)

            commit_result = subprocess.run(
                ["git", "commit", "-m", commit_msg],
                capture_output=True, text=True, cwd=str(self.repo_path)
            )
            if commit_result.returncode != 0:
                return {"committed": False, "message": commit_msg, "hash": "", "error": commit_result.stderr.strip()}

            sha_result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                capture_output=True, text=True, cwd=str(self.repo_path)
            )
            commit_hash = sha_result.stdout.strip() if sha_result.returncode == 0 else ""

            return {"committed": True, "message": commit_msg, "hash": commit_hash, "error": None}
        except Exception as e:
            return {"committed": False, "message": "", "hash": "", "error": str(e)}

    def generate_pre_commit_hook(self) -> str:
        hook_content = '''#!/usr/bin/env python3
"""DeltaCode pre-commit hook — scans staged diffs for security issues."""

import subprocess
import sys
import json

def main():
    result = subprocess.run(
        ["git", "diff", "--cached"],
        capture_output=True, text=True
    )
    diff = result.stdout
    if not diff:
        sys.exit(0)

    sensitive_patterns = [
        ("password|passwd|pwd", "Hardcoded password"),
        ("api_key|apikey|API_KEY", "Hardcoded API key"),
        ("secret|SECRET|token|TOKEN", "Hardcoded secret/token"),
        ("PRIVATE KEY", "Private key"),
        ("AKIA[0-9A-Z]{16}", "AWS access key"),
    ]

    findings = []
    lines = diff.split("\\n")
    for i, line in enumerate(lines):
        if not line.startswith("+"):
            continue
        for pattern, desc in sensitive_patterns:
            import re
            if re.search(pattern, line):
                findings.append(f"  Line {i+1}: {desc}")

    if findings:
        print(" SECURITY ISSUE DETECTED IN STAGED CHANGES ")
        print("The following potential secrets were found:")
        for f in findings:
            print(f)
        print()
        print("If these are intentional, commit with: git commit --no-verify")
        print("Otherwise, remove the secrets before committing.")
        sys.exit(1)

    sys.exit(0)

if __name__ == "__main__":
    main()
'''
        return hook_content

    def install_pre_commit_hook(self) -> bool:
        git_dir_result = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            capture_output=True, text=True, cwd=str(self.repo_path)
        )
        if git_dir_result.returncode != 0:
            logger.warning("Not a git repository")
            return False

        git_dir = Path(git_dir_result.stdout.strip())
        hooks_dir = self.repo_path / git_dir / "hooks"
        hooks_dir.mkdir(exist_ok=True)

        hook_path = hooks_dir / "pre-commit"
        if hook_path.exists():
            existing = hook_path.read_text()
            if "DeltaCode" in existing:
                return True
            backup = hook_path.with_suffix(".bak")
            hook_path.rename(backup)
            logger.info(f"Existing hook backed up to {backup}")

        hook_content = self.generate_pre_commit_hook()
        hook_path.write_text(hook_content)
        hook_path.chmod(0o755)

        return True