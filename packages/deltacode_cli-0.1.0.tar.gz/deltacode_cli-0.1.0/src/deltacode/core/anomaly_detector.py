"""Anomaly detection for misuse monitoring in DeltaCode CLI.

Detects unusual usage patterns:
- Abnormal scan frequency (potential abuse)
- Unauthorized target patterns
- Unusual command combinations
- Out-of-hours activity
- Rapid-fire command execution
"""

from __future__ import annotations

import json
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


ANOMALY_THRESHOLDS = {
    "max_commands_per_hour": 60,
    "max_scans_per_hour": 10,
    "max_unique_targets_per_day": 20,
    "max_failed_scans_per_hour": 5,
    "out_of_hours_window": (22, 6),
    "rapid_fire_window_seconds": 2,
    "rapid_fire_max_count": 15,
}


@dataclass
class AnomalyAlert:
    alert_type: str
    severity: str
    message: str
    details: dict
    timestamp: str
    actor: str = "system"
    resolved: bool = False


class AnomalyDetector:
    def __init__(self, data_dir: str = None):
        self.data_dir = Path(data_dir or Path.home() / ".deltacode" / "anomaly")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._event_log: deque = deque(maxlen=10000)
        self._alerts: list[AnomalyAlert] = []
        self._load()

    def _load(self):
        alerts_file = self.data_dir / "alerts.json"
        if alerts_file.exists():
            try:
                data = json.loads(alerts_file.read_text(encoding="utf-8"))
                self._alerts = [AnomalyAlert(**a) for a in data]
            except Exception:
                pass

    def _save(self):
        alerts_file = self.data_dir / "alerts.json"
        alerts_file.write_text(json.dumps(
            [a.__dict__ for a in self._alerts],
            indent=2, ensure_ascii=False,
        ), encoding="utf-8")

    def record_event(self, command: str, target: str = "", success: bool = True, actor: str = "system"):
        self._event_log.append({
            "command": command,
            "target": target,
            "success": success,
            "actor": actor,
            "timestamp": datetime.utcnow().isoformat(),
            "epoch": time.time(),
        })
        self._check_anomalies(command, target, success)

    def _check_anomalies(self, command: str, target: str, success: bool):
        now = datetime.utcnow()

        hour_events = [e for e in self._event_log if now - datetime.fromisoformat(e["timestamp"]) < timedelta(hours=1)]

        cmds_per_hour = len(hour_events)
        if cmds_per_hour > ANOMALY_THRESHOLDS["max_commands_per_hour"]:
            self._alert("command_flood", "HIGH",
                        f"Command flood detected: {cmds_per_hour} commands in last hour",
                        {"count": cmds_per_hour, "threshold": ANOMALY_THRESHOLDS["max_commands_per_hour"]})

        scans_per_hour = len([e for e in hour_events if e["command"] in ("scan", "audit", "deps")])
        if scans_per_hour > ANOMALY_THRESHOLDS["max_scans_per_hour"]:
            self._alert("scan_flood", "MEDIUM",
                        f"Scan flood: {scans_per_hour} scans in last hour",
                        {"count": scans_per_hour})

        failed_per_hour = len([e for e in hour_events if not e["success"]])
        if failed_per_hour > ANOMALY_THRESHOLDS["max_failed_scans_per_hour"]:
            self._alert("failure_spike", "HIGH",
                        f"Failure spike: {failed_per_hour} failed commands in last hour",
                        {"count": failed_per_hour})

        day_targets = set()
        for e in self._event_log:
            if now - datetime.fromisoformat(e["timestamp"]) < timedelta(hours=24):
                if e["target"]:
                    day_targets.add(e["target"])
        if len(day_targets) > ANOMALY_THRESHOLDS["max_unique_targets_per_day"]:
            self._alert("target_spray", "HIGH",
                        f"Target spray: {len(day_targets)} unique targets today",
                        {"count": len(day_targets)})

        hour = now.hour
        out_start, out_end = ANOMALY_THRESHOLDS["out_of_hours_window"]
        if out_start <= hour or hour < out_end:
            recent_out_of_hours = len([e for e in self._event_log
                                       if datetime.fromisoformat(e["timestamp"]).hour >= out_start
                                       or datetime.fromisoformat(e["timestamp"]).hour < out_end])
            if recent_out_of_hours > 10:
                self._alert("off_hours_activity", "LOW",
                            f"Off-hours activity: {recent_out_of_hours} events",
                            {"count": recent_out_of_hours, "window": f"{out_start}:00-{out_end}:00"})

        window = ANOMALY_THRESHOLDS["rapid_fire_window_seconds"]
        recent = [e for e in self._event_log if now.timestamp() - e["epoch"] < window]
        if len(recent) > ANOMALY_THRESHOLDS["rapid_fire_max_count"]:
            self._alert("rapid_fire", "HIGH",
                        f"Rapid-fire commands: {len(recent)} in {window}s",
                        {"count": len(recent), "window_s": window})

    def _alert(self, alert_type: str, severity: str, message: str, details: dict):
        existing = [a for a in self._alerts if a.alert_type == alert_type and not a.resolved]
        recent = [a for a in existing if datetime.utcnow() - datetime.fromisoformat(a.timestamp) < timedelta(minutes=5)]
        if recent:
            return

        alert = AnomalyAlert(
            alert_type=alert_type,
            severity=severity,
            message=message,
            details=details,
            timestamp=datetime.utcnow().isoformat(),
        )
        self._alerts.append(alert)
        logger.warning(f"Anomaly [{severity}]: {message}")
        self._save()

    def get_alerts(self, severity: str = None, limit: int = 50) -> list[AnomalyAlert]:
        alerts = self._alerts
        if severity:
            alerts = [a for a in alerts if a.severity == severity]
        return alerts[-limit:]

    def resolve_alert(self, alert_index: int) -> bool:
        if 0 <= alert_index < len(self._alerts):
            self._alerts[alert_index].resolved = True
            self._save()
            return True
        return False

    def get_stats(self) -> dict:
        now = datetime.utcnow()
        hour_events = [e for e in self._event_log if now - datetime.fromisoformat(e["timestamp"]) < timedelta(hours=1)]
        day_events = [e for e in self._event_log if now - datetime.fromisoformat(e["timestamp"]) < timedelta(hours=24)]
        return {
            "total_events": len(self._event_log),
            "events_last_hour": len(hour_events),
            "events_last_24h": len(day_events),
            "active_alerts": len([a for a in self._alerts if not a.resolved]),
            "total_alerts": len(self._alerts),
            "alerts_by_severity": {
                "HIGH": len([a for a in self._alerts if a.severity == "HIGH" and not a.resolved]),
                "MEDIUM": len([a for a in self._alerts if a.severity == "MEDIUM" and not a.resolved]),
                "LOW": len([a for a in self._alerts if a.severity == "LOW" and not a.resolved]),
            },
        }

    def get_usage_patterns(self) -> dict:
        command_counts = defaultdict(int)
        target_counts = defaultdict(int)
        hour_distribution = defaultdict(int)

        for e in self._event_log:
            command_counts[e["command"]] += 1
            if e["target"]:
                target_counts[e["target"]] += 1
            try:
                h = datetime.fromisoformat(e["timestamp"]).hour
                hour_distribution[h] += 1
            except Exception:
                pass

        return {
            "top_commands": sorted(command_counts.items(), key=lambda x: -x[1])[:10],
            "top_targets": sorted(target_counts.items(), key=lambda x: -x[1])[:10],
            "hour_distribution": dict(sorted(hour_distribution.items())),
            "success_rate": round(
                sum(1 for e in self._event_log if e["success"]) / max(len(self._event_log), 1) * 100, 1
            ),
        }