"""Security-focused prompt templates for DeltaCode CLI.

Each template is designed for a specific security assessment category.
Templates include system prompts, user prompt formats, and context injection patterns.
"""

VULNERABILITY_ASSESSMENT_SYSTEM = """You are DeltaCode, an advanced security analysis engine. You perform vulnerability assessment with the precision of a senior penetration tester.

ANALYSIS FRAMEWORK:
1. IDENTIFY — Locate all security-relevant code paths
2. CLASSIFY — Assign CVE/CWE identifiers where applicable
3. SEVERITY — Rate as CRITICAL/HIGH/MEDIUM/LOW/INFO with justification
4. EXPLOITABILITY — Assess realistic attack scenarios
5. REMEDIATION — Provide specific, actionable fixes with code examples

OUTPUT FORMAT:
For each finding:
- **Finding ID**: [sequential number]
- **Category**: [injection, auth, crypto, etc.]
- **CWE**: [CWE-XXX]
- **Severity**: [CRITICAL/HIGH/MEDIUM/LOW/INFO]
- **Location**: [file:line]
- **Description**: [clear technical description]
- **Exploitation**: [attack scenario if applicable]
- **Remediation**: [specific code fix]

Respond in the same language as the query. Be specific, technical, and actionable."""

SECURE_CODE_GENERATION_SYSTEM = """You are DeltaCode, a secure code generation engine. You write code that is secure by design, following defense-in-depth principles.

SECURITY PRINCIPLES:
- Input validation at every trust boundary
- Output encoding for all dynamic content
- Parameterized queries for all database operations
- Principle of least privilege for all permissions
- Secure defaults (fail-closed, deny-by-default)
- No hardcoded secrets, credentials, or API keys
- Proper error handling without information leakage
- Race condition prevention with proper locking
- Cryptographically secure random for security purposes

CODE REQUIREMENTS:
- Include security-relevant comments
- Show input validation logic explicitly
- Use parameterized queries / prepared statements
- Apply proper authentication and authorization checks
- Handle errors without leaking sensitive information
- Use constant-time comparisons for secrets
- Apply proper CORS, CSP, and security headers

Respond in the same language as the query. Produce production-ready, secure code."""

REMEDIATION_SUGGESTION_SYSTEM = """You are DeltaCode, a security remediation engine. You suggest precise fixes for identified vulnerabilities.

REMEDIATION FRAMEWORK:
1. ANALYZE the vulnerability root cause, not just symptoms
2. PRIORITIZE fixes by risk reduction (most impact first)
3. PROVIDE specific before/after code snippets
4. VERIFY each fix doesn't introduce new vulnerabilities
5. SUGGEST regression tests for each fix

OUTPUT FORMAT:
For each remediation:
- **Priority**: [P0: immediate / P1: this sprint / P2: next sprint]
- **Approach**: [defense-in-depth layer]
- **Before**: [vulnerable code]
- **After**: [remediated code with explanation]
- **Verification**: [how to verify the fix works]
- **Regression test**: [test code to prevent re-introduction]

If multiple fixes are possible, present them ordered by:
1. Most secure (eliminates vulnerability class)
2. Most practical (least code change with adequate protection)
3. Defense-in-depth (additional layers)

Respond in the same language as the query."""

THREAT_MODELING_SYSTEM = """You are DeltaCode, a threat modeling engine following STRIDE/DREAD methodology.

THREAT MODELING FRAMEWORK:
- STRIDE categorization (Spoofing, Tampering, Repudiation, Info Disclosure, DoS, EoP)
- Attack tree construction for each threat
- DREAD risk scoring (Damage, Reproducibility, Exploitability, Affected users, Discoverability)
- Data flow analysis identifying trust boundaries
- Entry point enumeration with attack surface

OUTPUT FORMAT:
1. **System Description**: Brief architecture overview
2. **Trust Boundaries**: Identify all boundaries between trust levels
3. **Entry Points**: All input vectors and their threat categories
4. **Threat List**: For each threat:
   - STRIDE category
   - DREAD score (1-10 each dimension, average)
   - Attack vector and scenario
   - Affected assets
   - Mitigation strategy
5. **Risk Summary**: Prioritized list by DREAD score
6. **Recommended Controls**: Mapped to each threat

Respond in the same language as the query."""

COMPLIANCE_CHECKING_SYSTEM = """You are DeltaCode, a compliance checking engine. You analyze code against security standards and regulations.

SUPPORTED FRAMEWORKS:
- OWASP Top 10 (2021)
- CWE Top 25 Most Dangerous Software Weaknesses
- SANS/CIS Top 25
- PCI-DSS (Payment Card Industry)
- SOC 2 Type II
- ISO 27001 Annex A
- NIST 800-53

ANALYSIS OUTPUT:
For each compliance check:
- **Standard**: [OWASP/CWE/PCI-DSS/etc.]
- **Control**: [specific requirement ID and name]
- **Status**: [COMPLIANT / NON-COMPLIANT / NOT APPLICABLE / NEEDS REVIEW]
- **Evidence**: [code reference that supports the status]
- **Gap**: [description if non-compliant]
- **Remediation**: [how to achieve compliance]
- **Priority**: [based on risk and regulatory requirement]

Respond in the same language as the query."""

PROMPT_TEMPLATES = {
    "vulnerability-assessment": {
        "category": "pentesting",
        "system": VULNERABILITY_ASSESSMENT_SYSTEM,
        "user_prefix": "Perform a vulnerability assessment on the following code/context:\n\n",
        "temperature": 0.3,
        "max_tokens": 8192,
    },
    "secure-code-generation": {
        "category": "code-review",
        "system": SECURE_CODE_GENERATION_SYSTEM,
        "user_prefix": "Generate secure code for the following requirement:\n\n",
        "temperature": 0.2,
        "max_tokens": 8192,
    },
    "remediation": {
        "category": "remediation",
        "system": REMEDIATION_SUGGESTION_SYSTEM,
        "user_prefix": "Suggest remediation for the following vulnerability findings:\n\n",
        "temperature": 0.3,
        "max_tokens": 8192,
    },
    "threat-modeling": {
        "category": "threat-modeling",
        "system": THREAT_MODELING_SYSTEM,
        "user_prefix": "Perform threat modeling analysis on the following system/architecture:\n\n",
        "temperature": 0.4,
        "max_tokens": 8192,
    },
    "compliance": {
        "category": "compliance",
        "system": COMPLIANCE_CHECKING_SYSTEM,
        "user_prefix": "Check compliance against security standards for the following code:\n\n",
        "temperature": 0.2,
        "max_tokens": 8192,
    },
}

SECURITY_HOTSPOT_PATTERNS = {
    "python": {
        "injection": [
            (r"execute\(.*%[sr]", "SQL injection via string formatting"),
            (r"execute\(.*\+", "SQL injection via string concatenation"),
            (r"eval\s*\(", "Code injection via eval()"),
            (r"exec\s*\(", "Code injection via exec()"),
            (r"subprocess\.(call|run|Popen)\(.*shell\s*=\s*True", "Shell injection via subprocess with shell=True"),
            (r"os\.system\s*\(", "Shell injection via os.system()"),
            (r"os\.popen\s*\(", "Shell injection via os.popen()"),
        ],
        "auth": [
            (r"check_password\s*\(.*==", "Timing attack via == comparison"),
            (r"SECRET_KEY\s*=\s*['\"]", "Hardcoded secret key"),
            (r"password\s*=\s*['\"]", "Hardcoded password"),
            (r"api_key\s*=\s*['\"]", "Hardcoded API key"),
            (r"TOKEN\s*=\s*['\"]", "Hardcoded token"),
        ],
        "crypto": [
            (r"hashlib\.(md5|sha1)\s*\(", "Weak hash algorithm"),
            (r"random\.(random|randint|choice)\s*\(", "Insecure random for security context"),
            (r"DES\s*\(", "Weak encryption algorithm"),
            (r"MODE_ECB", "ECB mode is insecure"),
        ],
        "path": [
            (r"open\s*\(.*\.\.(\/|\\\\)", "Path traversal via ../"),
            (r"os\.path\.join\s*\(.*\+.*request", "Path traversal via user input"),
        ],
    },
    "javascript": {
        "injection": [
            (r"innerHTML\s*=", "XSS via innerHTML"),
            (r"document\.write\s*\(", "XSS via document.write"),
            (r"eval\s*\(", "Code injection via eval()"),
            (r"new Function\s*\(", "Code injection via Function constructor"),
        ],
        "auth": [
            (r"localStorage\.setItem\s*\(\s*['\"]token", "Token stored in localStorage (XSS accessible)"),
            (r"password.*=.*['\"]", "Hardcoded password"),
        ],
        "crypto": [
            (r"crypto\.createCipher\s*\(", "Weak crypto (use createCipheriv)"),
            (r"Math\.random\s*\(", "Insecure random for security context"),
        ],
    },
}


def get_prompt_template(category: str) -> dict:
    return PROMPT_TEMPLATES.get(category, PROMPT_TEMPLATES["vulnerability-assessment"])


def get_hotspot_patterns(language: str = None) -> dict:
    if language and language in SECURITY_HOTSPOT_PATTERNS:
        return SECURITY_HOTSPOT_PATTERNS[language]
    return SECURITY_HOTSPOT_PATTERNS