"""Data flow analysis for DeltaCode CLI.

Tracks how data moves through the codebase:
- Input sources (API endpoints, file reads, user input)
- Data transformations (processing, encoding, encryption)
- Sensitive data detection (PII, credentials, secrets)
- Output sinks (database writes, file writes, network calls)
- Data flow path visualization
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


INPUT_SOURCES = {
    "python": [
        r"request\.(get|post|put|delete|json|form|args|values|cookies|headers)",
        r"input\s*\(",
        r"sys\.argv",
        r"open\s*\([^)]+\)",
        r"environ\.(get|__getitem__)",
        r"json\.loads?\s*\(",
        r"yaml\.load\s*\(",
        r"pickle\.loads?\s*\(",
        r"stdin\.read",
        r"from_request",
        r"parse_qs",
        r"urllib\.(parse|request)",
    ],
}

OUTPUT_SINKS = {
    "python": [
        r"db\.execute",
        r"cursor\.execute",
        r"session\.(add|commit|execute)",
        r"\.save\s*\(",
        r"\.write\s*\(",
        r"print\s*\(",
        r"open\s*\([^)]+,\s*['\"]w",
        r"send_email",
        r"requests\.(post|put|get)\s*\(",
        r"json\.dumps?\s*\(",
        r"render_template",
        r"render_to_string",
        r"return\s+Response",
        r"return\s+jsonify",
        r"log\.(info|warning|error|debug)",
        r"subprocess\.(call|run|Popen)",
    ],
}

SENSITIVE_DATA_PATTERNS = [
    (r"(?i)password", "password"),
    (r"(?i)(ssn|social.security)", "ssn"),
    (r"(?i)(credit.card|cc_number|card_number)", "credit_card"),
    (r"(?i)(email|e-mail)", "email"),
    (r"(?i)(phone|telephone|mobile)", "phone"),
    (r"(?i)(address|street|city|zip)", "address"),
    (r"(?i)(birth|dob|date.of.birth)", "dob"),
    (r"(?i)(health|medical|diagnosis)", "health"),
    (r"(?i)(bank|account|routing)", "banking"),
    (r"(?i)(secret|token|api_key|apikey)", "credential"),
    (r"(?i)(passport|driver.license)", "id_document"),
]


@dataclass
class DataFlowNode:
    file: str
    line: int
    node_type: str
    name: str
    sensitive_types: list = field(default_factory=list)


@dataclass
class DataFlowPath:
    source: DataFlowNode
    sinks: list = field(default_factory=list)
    sensitive_data: list = field(default_factory=list)
    risk_score: float = 0.0


class DataFlowAnalyzer:
    def __init__(self, root_path: str = "."):
        self.root_path = Path(root_path).resolve()

    def analyze(self, target_files: list[str] = None) -> dict:
        sources = []
        sinks = []
        sensitive_vars = set()
        flows = []

        if target_files is None:
            target_files = [str(f) for f in self.root_path.rglob("*.py") if f.is_file()]

        for fpath in target_files:
            try:
                content = Path(fpath).read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            rel = Path(fpath).relative_to(self.root_path) if self.root_path in Path(fpath).parents else fpath

            for pattern in INPUT_SOURCES.get("python", []):
                for match in re.finditer(pattern, content):
                    line = content[:match.start()].count("\n") + 1
                    sources.append(DataFlowNode(file=str(rel), line=line, node_type="input", name=match.group()))

            for pattern in OUTPUT_SINKS.get("python", []):
                for match in re.finditer(pattern, content):
                    line = content[:match.start()].count("\n") + 1
                    sinks.append(DataFlowNode(file=str(rel), line=line, node_type="sink", name=match.group()))

            for pattern, stype in SENSITIVE_DATA_PATTERNS:
                for match in re.finditer(pattern, content):
                    line = content[:match.start()].count("\n") + 1
                    sensitive_vars.add((str(rel), line, stype))

            try:
                tree = ast.parse(content)
                self._walk_ast(tree, content, rel, sources, sinks, sensitive_vars, flows)
            except SyntaxError:
                pass

        return {
            "sources_count": len(sources),
            "sinks_count": len(sinks),
            "sensitive_variables": len(sensitive_vars),
            "flows_count": len(flows),
            "sources": sorted([s.__dict__ for s in sources], key=lambda x: x["file"])[:30],
            "sinks": sorted([s.__dict__ for s in sinks], key=lambda x: x["file"])[:30],
            "sensitive_data": sorted(
                [{"file": f, "line": l, "type": t} for f, l, t in sensitive_vars],
                key=lambda x: x["file"],
            )[:30],
            "flows": flows[:20],
            "risk_summary": self._summarize_risk(sources, sinks, sensitive_vars, flows),
        }

    def _walk_ast(self, tree, content, rel, sources, sinks, sensitive_vars, flows, context=None):
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                func = self._get_call_name(node)
                if func and ("request" in func or "input" in func or "open" in func):
                    line = getattr(node, "lineno", 0)
                    sources.append(DataFlowNode(file=str(rel), line=line, node_type="input", name=func))

                if func and ("execute" in func or "save" in func or "write" in func or "send" in func):
                    line = getattr(node, "lineno", 0)
                    sinks.append(DataFlowNode(file=str(rel), line=line, node_type="sink", name=func))

    def _get_call_name(self, node):
        if isinstance(node.func, ast.Attribute):
            return f"{self._get_attribute_chain(node.func)}"
        elif isinstance(node.func, ast.Name):
            return node.func.id
        return ""

    def _get_attribute_chain(self, node):
        parts = []
        while isinstance(node, ast.Attribute):
            parts.append(node.attr)
            node = node.value
        if isinstance(node, ast.Name):
            parts.append(node.id)
        return ".".join(reversed(parts))

    def _summarize_risk(self, sources, sinks, sensitive_vars, flows):
        total = len(sources) + len(sinks) + len(sensitive_vars)
        high_sinks = len([s for s in sinks if any(kw in s.name for kw in ["execute", "Popen", "send_email"])])
        score = min(total * 2 + high_sinks * 5, 100)
        level = "CRITICAL" if score >= 50 else "HIGH" if score >= 30 else "MEDIUM" if score >= 15 else "LOW"

        return {"risk_score": score, "risk_level": level, "inputs": len(sources), "sinks": len(sinks), "sensitive": len(sensitive_vars)}

    def format_report(self, results: dict) -> str:
        risk = results.get("risk_summary", {})
        parts = [f"# Data Flow Analysis\n"]
        parts.append(f"Risk: {risk.get('risk_level', 'N/A')} (score: {risk.get('risk_score', 0)}/100)")
        parts.append("")
        parts.append(f"## Summary")
        parts.append(f"Input Sources: {results.get('sources_count', 0)}")
        parts.append(f"Output Sinks: {results.get('sinks_count', 0)}")
        parts.append(f"Sensitive Data References: {results.get('sensitive_variables', 0)}")
        parts.append(f"Data Flow Paths: {results.get('flows_count', 0)}")
        parts.append("")
        if results.get("sensitive_data"):
            parts.append("## Sensitive Data Found")
            for sd in results["sensitive_data"][:15]:
                parts.append(f"  [{sd['type']}] {sd['file']}:{sd['line']}")
        if results.get("sinks"):
            parts.append("\n## High-Risk Output Sinks")
            for s in results["sinks"][:10]:
                parts.append(f"  🔴 {s['file']}:{s['line']} — {s['name']}")
        if results.get("sources"):
            parts.append("\n## Input Sources")
            for s in results["sources"][:10]:
                parts.append(f"  📥 {s['file']}:{s['line']} — {s['name']}")
        return "\n".join(parts)