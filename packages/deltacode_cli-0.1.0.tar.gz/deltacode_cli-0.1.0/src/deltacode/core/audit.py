"""Audit logging and encrypted credential storage for DeltaCode CLI.

All CLI operations are logged to ~/.deltacode/audit.log with timestamps,
and API keys/license keys are stored encrypted at rest using Fernet symmetric
encryption derived from a machine-specific key.
"""

import base64
import hashlib
import json
import os
import platform
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

from deltacode.core.config import DATA_DIR

try:
    from cryptography.fernet import Fernet
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


AUDIT_LOG_DIR = DATA_DIR / "audit"
AUDIT_LOG_FILE = AUDIT_LOG_DIR / "audit.log"
CREDENTIALS_FILE = DATA_DIR / "credentials.enc"


def _get_machine_key() -> bytes:
    machine_id = f"{platform.node()}-{platform.machine()}-{uuid.getnode()}"
    return hashlib.sha256(machine_id.encode()).digest()


def _get_fernet() -> Optional["Fernet"]:
    if not HAS_CRYPTO:
        return None
    key = base64.urlsafe_b64encode(_get_machine_key())
    return Fernet(key)


class AuditLogger:
    def __init__(self, log_dir: Path = None):
        self.log_dir = log_dir or AUDIT_LOG_DIR
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.log_file = self.log_dir / "audit.log"

    def log(self, action: str, details: dict = None, level: str = "INFO"):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "level": level,
            "details": details or {},
            "platform": platform.system(),
            "hostname": platform.node(),
        }

        line = json.dumps(entry, ensure_ascii=False)

        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception as e:
            logger.warning(f"Failed to write audit log: {e}")

    def log_command(self, command: str, args: dict = None):
        self.log("command", {"command": command, "args": args or {}})

    def log_auth(self, action: str, success: bool, details: dict = None):
        self.log("auth", {
            "action": action,
            "success": success,
            **(details or {}),
        }, level="INFO" if success else "WARNING")

    def log_scan(self, target: str, findings_count: int, severity: str = None):
        self.log("scan", {
            "target": target,
            "findings_count": findings_count,
            "max_severity": severity,
        })

    def log_api_call(self, endpoint: str, method: str = "POST", status: int = None, tokens: int = 0):
        self.log("api_call", {
            "endpoint": endpoint,
            "method": method,
            "status": status,
            "tokens_used": tokens,
        })

    def get_recent(self, count: int = 50, action: str = None) -> list:
        if not self.log_file.exists():
            return []

        entries = []
        try:
            with open(self.log_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                        if action and entry.get("action") != action:
                            continue
                        entries.append(entry)
                    except json.JSONDecodeError:
                        continue
        except Exception:
            pass

        return entries[-count:]


class CredentialStore:
    def __init__(self):
        self._fernet = _get_fernet()

    def store(self, key: str, value: str) -> bool:
        if not self._fernet:
            logger.warning("cryptography package not available — storing credentials in plain text")
            return self._store_plain(key, value)

        encrypted = self._fernet.encrypt(value.encode()).decode()

        data = self._load_all()
        data[key] = encrypted
        return self._save_all(data)

    def retrieve(self, key: str) -> Optional[str]:
        if not self._fernet:
            return self._retrieve_plain(key)

        data = self._load_all()
        encrypted = data.get(key)
        if not encrypted:
            return None

        try:
            return self._fernet.decrypt(encrypted.encode()).decode()
        except Exception:
            logger.warning(f"Failed to decrypt credential '{key}' — may have been encrypted on another machine")
            return None

    def delete(self, key: str) -> bool:
        data = self._load_all()
        if key not in data:
            return False
        del data[key]
        return self._save_all(data)

    def list_keys(self) -> list:
        data = self._load_all()
        return list(data.keys())

    def _load_all(self) -> dict:
        if not CREDENTIALS_FILE.exists():
            return {}
        try:
            return json.loads(CREDENTIALS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save_all(self, data: dict) -> bool:
        CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True)
        try:
            CREDENTIALS_FILE.write_text(
                json.dumps(data, ensure_ascii=False),
                encoding="utf-8",
            )
            return True
        except Exception as e:
            logger.error(f"Failed to save credentials: {e}")
            return False

    def _store_plain(self, key: str, value: str) -> bool:
        data = self._load_all()
        data[key] = base64.b64encode(value.encode()).decode()
        return self._save_all(data)

    def _retrieve_plain(self, key: str) -> Optional[str]:
        data = self._load_all()
        encoded = data.get(key)
        if not encoded:
            return None
        try:
            return base64.b64decode(encoded).decode()
        except Exception:
            return None


audit_logger = AuditLogger()
credential_store = CredentialStore()