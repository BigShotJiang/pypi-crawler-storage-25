"""Best practice library for DeltaCode CLI.

Provides CWE-based secure coding patterns, vulnerability-specific remediation
snippets, and compliance mapping. Used by auto-fix engine and chat for
generating secure code recommendations.
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class CWEEntry:
    cwe_id: str
    name: str
    severity: str
    category: str
    description: str
    languages: list = field(default_factory=list)
    vulnerable_pattern: str = ""
    secure_pattern: str = ""
    remediation: str = ""
    owasp_mapping: str = ""
    compliance_mapping: dict = field(default_factory=dict)


CWE_DATABASE = {
    "CWE-78": CWEEntry(
        cwe_id="CWE-78",
        name="OS Command Injection",
        severity="CRITICAL",
        category="injection",
        description="The software constructs an OS command using externally-influenced input, allowing arbitrary command execution.",
        languages=["python", "javascript", "go", "java", "php", "ruby"],
        vulnerable_pattern="""# Python - VULNERABLE
import os
import subprocess

def ping_host(user_input):
    # VULNERABLE: direct string interpolation into shell command
    os.system(f"ping -c 4 {user_input}")
    subprocess.run(f"ping -c 4 {user_input}", shell=True)
    os.popen(f"ping -c 4 {user_input}")""",
        secure_pattern="""# Python - SECURE
import subprocess

def ping_host(user_input):
    # SECURE: validate input, use list form (no shell)
    if not user_input.replace(".", "").replace("-", "").isdigit():
        raise ValueError("Invalid hostname")
    subprocess.run(["ping", "-c", "4", user_input], shell=False)""",
        remediation="Never pass user input to shell commands. Use parameterized/exec-list forms. Validate input against strict allowlists.",
        owasp_mapping="A03:2021-Injection",
        compliance_mapping={"PCI-DSS": "6.5.1", "NIST 800-53": "SI-10", "SOC 2": "CC6.1"},
    ),
    "CWE-79": CWEEntry(
        cwe_id="CWE-79",
        name="Cross-site Scripting (XSS)",
        severity="HIGH",
        category="injection",
        description="The software does not neutralize or incorrectly neutralizes user-controllable input before it is placed in output as web page content.",
        languages=["javascript", "python", "java", "php", "ruby"],
        vulnerable_pattern="""// JavaScript - VULNERABLE
document.getElementById("output").innerHTML = userInput;
document.write("<div>" + userInput + "</div>");
element.insertAdjacentHTML("beforeend", userInput);""",
        secure_pattern="""// JavaScript - SECURE
document.getElementById("output").textContent = userInput;
element.textContent = userInput;

// If HTML is needed, use a sanitizer
import DOMPurify from 'dompurify';
element.innerHTML = DOMPurify.sanitize(userInput);""",
        remediation="Always use textContent instead of innerHTML. When HTML rendering is necessary, sanitize with DOMPurify. Apply Content-Security-Policy headers.",
        owasp_mapping="A03:2021-Injection",
        compliance_mapping={"PCI-DSS": "6.5.7", "NIST 800-53": "SI-10", "SOC 2": "CC6.1"},
    ),
    "CWE-89": CWEEntry(
        cwe_id="CWE-89",
        name="SQL Injection",
        severity="CRITICAL",
        category="injection",
        description="The software constructs an SQL command using externally-influenced input, allowing arbitrary SQL execution.",
        languages=["python", "java", "php", "ruby", "javascript"],
        vulnerable_pattern="""# Python - VULNERABLE
import sqlite3

def get_user(username):
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM users WHERE username = '{username}'")
    return cursor.fetchone()""",
        secure_pattern="""# Python - SECURE
import sqlite3

def get_user(username):
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    # SECURE: parameterized query
    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
    return cursor.fetchone()""",
        remediation="Always use parameterized queries / prepared statements. Never concatenate user input into SQL strings. Use ORM abstractions where possible.",
        owasp_mapping="A03:2021-Injection",
        compliance_mapping={"PCI-DSS": "6.5.1", "NIST 800-53": "SI-10", "SOC 2": "CC6.1"},
    ),
    "CWE-200": CWEEntry(
        cwe_id="CWE-200",
        name="Exposure of Sensitive Information",
        severity="MEDIUM",
        category="information_disclosure",
        description="The software exposes sensitive information to an actor not authorized to access it.",
        languages=["python", "javascript", "java", "go", "php"],
        vulnerable_pattern="""# Python - VULNERABLE
from flask import Flask, jsonify

app = Flask(__name__)

@app.errorhandler(Exception)
def handle_error(e):
    # VULNERABLE: exposes internal error details
    return jsonify({"error": str(e), "traceback": traceback.format_exc()}), 500""",
        secure_pattern="""# Python - SECURE
import logging
from flask import Flask, jsonify

app = Flask(__name__)
logger = logging.getLogger(__name__)

@app.errorhandler(Exception)
def handle_error(e):
    # SECURE: log internally, return generic message
    logger.exception("Unhandled error")
    return jsonify({"error": "An internal error occurred"}), 500""",
        remediation="Never expose stack traces, internal paths, or SQL errors to users. Log full details server-side, return generic messages to clients.",
        owasp_mapping="A01:2021-Broken Access Control",
        compliance_mapping={"PCI-DSS": "6.5.5", "NIST 800-53": "AC-4", "SOC 2": "CC6.1"},
    ),
    "CWE-256": CWEEntry(
        cwe_id="CWE-256",
        name="Plaintext Storage of Password",
        severity="CRITICAL",
        category="credential_management",
        description="The software stores passwords in plaintext, making them accessible to anyone with access to the storage.",
        languages=["python", "java", "javascript", "go", "php"],
        vulnerable_pattern="""# Python - VULNERABLE
import sqlite3

def store_password(username, password):
    conn = sqlite3.connect("app.db")
    # VULNERABLE: storing password in plaintext
    conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))""",
        secure_pattern="""# Python - SECURE
import sqlite3
import bcrypt

def store_password(username, password):
    conn = sqlite3.connect("app.db")
    # SECURE: hash password with bcrypt before storing
    hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt(rounds=12))
    conn.execute("INSERT INTO users (username, password_hash) VALUES (?, ?)", (username, hashed))""",
        remediation="Always hash passwords with bcrypt, scrypt, or Argon2. Never store passwords in plaintext. Use appropriate work factors (bcrypt cost >= 12).",
        owasp_mapping="A02:2021-Cryptographic Failures",
        compliance_mapping={"PCI-DSS": "8.2.1", "NIST 800-53": "IA-5", "SOC 2": "CC6.1"},
    ),
    "CWE-287": CWEEntry(
        cwe_id="CWE-287",
        name="Improper Authentication",
        severity="CRITICAL",
        category="authentication",
        description="The software does not prove or insufficiently proves the claimed identity of a user.",
        languages=["python", "javascript", "java", "go", "php"],
        vulnerable_pattern="""# Python - VULNERABLE
from flask import request, jsonify

@app.route("/login", methods=["POST"])
def login():
    username = request.json["username"]
    password = request.json["password"]
    user = db.get_user(username)
    # VULNERABLE: timing attack via == comparison
    if user and user.password == password:
        return jsonify({"token": create_token(user)})
    return jsonify({"error": "Invalid credentials"}), 401""",
        secure_pattern="""# Python - SECURE
import bcrypt
from flask import request, jsonify

@app.route("/login", methods=["POST"])
def login():
    username = request.json["username"]
    password = request.json["password"]
    user = db.get_user(username)
    # SECURE: constant-time comparison with bcrypt
    if user and bcrypt.checkpw(password.encode('utf-8'), user.password_hash):
        return jsonify({"token": create_token(user)})
    # Rate limiting should be applied
    return jsonify({"error": "Invalid credentials"}), 401""",
        remediation="Use constant-time comparison for credential checks. Implement rate limiting and account lockout. Use well-vetted auth libraries.",
        owasp_mapping="A07:2021-Identification and Authentication Failures",
        compliance_mapping={"PCI-DSS": "8.3", "NIST 800-53": "IA-2", "SOC 2": "CC6.1"},
    ),
    "CWE-327": CWEEntry(
        cwe_id="CWE-327",
        name="Use of Broken or Risky Cryptographic Algorithm",
        severity="HIGH",
        category="cryptography",
        description="The software uses a broken or risky cryptographic algorithm or protocol.",
        languages=["python", "javascript", "java", "go", "php"],
        vulnerable_pattern="""# Python - VULNERABLE
import hashlib
import ssl

# VULNERABLE: MD5 and SHA1 are broken
hash = hashlib.md5(data).hexdigest()
hash = hashlib.sha1(data).hexdigest()

# VULNERABLE: weak DES cipher
from Crypto.Cipher import DES""",
        secure_pattern="""# Python - SECURE
import hashlib

# SECURE: Use SHA-256 or SHA-3
hash = hashlib.sha256(data).hexdigest()

# For password hashing, use bcrypt/scrypt/argon2
import bcrypt
hashed = bcrypt.hashpw(password, bcrypt.gensalt(12))

# For encryption, use AES-256-GCM
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes""",
        remediation="Replace MD5/SHA1 with SHA-256+. Use bcrypt/scrypt/Argon2 for passwords. Use AES-256-GCM for encryption. Never use DES/RC4/ECB mode.",
        owasp_mapping="A02:2021-Cryptographic Failures",
        compliance_mapping={"PCI-DSS": "6.5.3", "NIST 800-53": "SC-13", "SOC 2": "CC6.7"},
    ),
    "CWE-328": CWEEntry(
        cwe_id="CWE-328",
        name="Reversible One-Way Hash",
        severity="HIGH",
        category="cryptography",
        description="The software uses an algorithm that produces a hash that is not cryptographically strong enough to protect against reversal.",
        languages=["python", "javascript", "java", "go"],
        vulnerable_pattern="""# Python - VULNERABLE
import hashlib

def hash_password(password):
    # VULNERABLE: unsalted simple hash
    return hashlib.sha256(password.encode()).hexdigest()""",
        secure_pattern="""# Python - SECURE
import bcrypt

def hash_password(password):
    # SECURE: bcrypt with proper work factor
    salt = bcrypt.gensalt(rounds=12)
    return bcrypt.hashpw(password.encode(), salt)

def verify_password(password, hashed):
    return bcrypt.checkpw(password.encode(), hashed)""",
        remediation="Use bcrypt (cost >= 12), scrypt, or Argon2 for password hashing. Never use plain SHA/MD5 for passwords. Always include a salt.",
        owasp_mapping="A02:2021-Cryptographic Failures",
        compliance_mapping={"PCI-DSS": "8.2.1", "NIST 800-53": "IA-5", "SOC 2": "CC6.1"},
    ),
    "CWE-330": CWEEntry(
        cwe_id="CWE-330",
        name="Use of Insufficiently Random Values",
        severity="MEDIUM",
        category="cryptography",
        description="The software uses insufficiently random numbers in security contexts.",
        languages=["python", "javascript", "java", "go", "php"],
        vulnerable_pattern="""# Python - VULNERABLE
import random

# VULNERABLE: random module is not cryptographically secure
token = ''.join(random.choices(string.ascii_letters, k=32))
session_id = random.randint(0, 999999)
nonce = random.getrandbits(128)""",
        secure_pattern="""# Python - SECURE
import secrets

# SECURE: use secrets module for security-sensitive values
token = secrets.token_urlsafe(32)
session_id = secrets.randbelow(10**6)
nonce = secrets.randbits(128)

# Or for broader contexts
import os
token = os.urandom(32).hex()""",
        remediation="Use secrets module (Python), crypto.getRandomValues (JS), or SecureRandom (Java) for all security-relevant random values. Never use random/math.random for tokens, IDs, or nonces.",
        owasp_mapping="A02:2021-Cryptographic Failures",
        compliance_mapping={"PCI-DSS": "6.5.3", "NIST 800-53": "SC-13", "SOC 2": "CC6.7"},
    ),
    "CWE-611": CWEEntry(
        cwe_id="CWE-611",
        name="XXE (XML External Entity)",
        severity="HIGH",
        category="injection",
        description="The software processes an XML document that can contain a reference to an external entity, leading to information disclosure or SSRF.",
        languages=["python", "java", "javascript", "php"],
        vulnerable_pattern="""# Python - VULNERABLE
from xml.etree import ElementTree

def parse_xml(xml_data):
    # VULNERABLE: default parser allows external entities
    return ElementTree.fromstring(xml_data)""",
        secure_pattern="""# Python - SECURE
from defusedxml import ElementTree
import xml.etree.ElementTree as ET

def parse_xml(xml_data):
    # SECURE: use defusedxml which disables entities by default
    return defusedxml.fromstring(xml_data)

# Or manually disable entities:
parser = ET.XMLParser()
parser.entity = {}
return ET.fromstring(xml_data, parser=parser)""",
        remediation="Use defusedxml (Python) or disable external entities in your XML parser. Never accept raw XML from untrusted sources without hardening.",
        owasp_mapping="A05:2021-Security Misconfiguration",
        compliance_mapping={"PCI-DSS": "6.5.1", "NIST 800-53": "SI-10", "SOC 2": "CC6.1"},
    ),
    "CWE-798": CWEEntry(
        cwe_id="CWE-798",
        name="Use of Hard-coded Credentials",
        severity="CRITICAL",
        category="credential_management",
        description="The software contains hard-coded credentials used for authentication or encryption.",
        languages=["python", "javascript", "java", "go", "php"],
        vulnerable_pattern="""# Python - VULNERABLE
DB_PASSWORD = "super_secret_123"
API_KEY = "sk-abc123def456"
SECRET_KEY = "django-insecure-key"

conn = psycopg2.connect(password=DB_PASSWORD)
requests.get(url, headers={"Authorization": f"Bearer {API_KEY}"})""",
        secure_pattern="""# Python - SECURE
import os
from dotenv import load_dotenv

load_dotenv()

DB_PASSWORD = os.environ["DB_PASSWORD"]
API_KEY = os.environ["API_KEY"]
SECRET_KEY = os.environ["SECRET_KEY"]

# .env file (add to .gitignore!)
# DB_PASSWORD=super_secret_123
# API_KEY=sk-abc123def456""",
        remediation="Store all credentials in environment variables or a secrets manager. Never hardcode credentials in source code. Add .env files to .gitignore.",
        owasp_mapping="A07:2021-Identification and Authentication Failures",
        compliance_mapping={"PCI-DSS": "6.5.3", "NIST 800-53": "IA-5", "SOC 2": "CC6.1"},
    ),
    "CWE-918": CWEEntry(
        cwe_id="CWE-918",
        name="Server-Side Request Forgery (SSRF)",
        severity="HIGH",
        category="injection",
        description="The software receives a URL from a user and fetches it, allowing the user to access internal resources.",
        languages=["python", "javascript", "java", "go", "php"],
        vulnerable_pattern="""# Python - VULNERABLE
import requests
from flask import request

@app.route("/fetch")
def fetch_url():
    url = request.args.get("url")
    # VULNERABLE: no URL validation
    response = requests.get(url)
    return response.text""",
        secure_pattern="""# Python - SECURE
import requests
from flask import request
from urllib.parse import urlparse
import ipaddress

BLOCKED_HOSTS = {"localhost", "127.0.0.1", "0.0.0.0"}
BLOCKED_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
]

@app.route("/fetch")
def fetch_url():
    url = request.args.get("url")
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        return "Invalid scheme", 400
    if parsed.hostname in BLOCKED_HOSTS:
        return "Blocked host", 403
    # SECURE: validate against internal networks
    try:
        ip = ipaddress.ip_address(parsed.hostname)
        if any(ip in net for net in BLOCKED_NETWORKS):
            return "Blocked", 403
    except ValueError:
        pass
    response = requests.get(url, timeout=5)
    return response.text""",
        remediation="Validate URLs against allowlists. Block internal/private IP ranges. Use allowlists of permitted domains. Never follow redirects to internal networks.",
        owasp_mapping="A10:2021-Server-Side Request Forgery",
        compliance_mapping={"PCI-DSS": "6.5.1", "NIST 800-53": "AC-4", "SOC 2": "CC6.1"},
    ),
    "CWE-22": CWEEntry(
        cwe_id="CWE-22",
        name="Path Traversal",
        severity="HIGH",
        category="injection",
        description="The software uses external input to construct a pathname that resolves to a directory outside the intended directory.",
        languages=["python", "java", "go", "php", "javascript"],
        vulnerable_pattern="""# Python - VULNERABLE
from flask import request, send_file

@app.route("/download")
def download():
    filename = request.args.get("file")
    # VULNERABLE: no path validation
    filepath = f"/var/data/uploads/{filename}"
    return send_file(filepath)""",
        secure_pattern="""# Python - SECURE
import os
from pathlib import Path
from flask import request, send_file, abort

UPLOAD_DIR = Path("/var/data/uploads").resolve()

@app.route("/download")
def download():
    filename = request.args.get("file")
    if not filename or ".." in filename or "/" in filename:
        abort(400)
    # SECURE: resolve and verify it stays within UPLOAD_DIR
    filepath = (UPLOAD_DIR / filename).resolve()
    if not filepath.is_relative_to(UPLOAD_DIR):
        abort(403)
    return send_file(filepath)""",
        remediation="Always resolve and validate paths relative to a base directory. Reject paths containing '..' or absolute paths. Use Path.resolve() and is_relative_to() checks.",
        owasp_mapping="A01:2021-Broken Access Control",
        compliance_mapping={"PCI-DSS": "6.5.4", "NIST 800-53": "AC-4", "SOC 2": "CC6.1"},
    ),
    "CWE-352": CWEEntry(
        cwe_id="CWE-352",
        name="Cross-Site Request Forgery (CSRF)",
        severity="MEDIUM",
        category="authentication",
        description="The web application does not verify the source of a request, allowing an attacker to trick users into performing actions.",
        languages=["python", "javascript", "java", "php"],
        vulnerable_pattern="""# Python - VULNERABLE
from flask import request

@app.route("/transfer", methods=["POST"])
def transfer():
    # VULNERABLE: no CSRF token validation
    amount = request.form["amount"]
    recipient = request.form["recipient"]
    do_transfer(amount, recipient)
    return 'OK'
""",
        secure_pattern="""# Python - SECURE
from flask import request, session
from flask_wtf.csrf import CSRFProtect

app.config["SECRET_KEY"] = os.environ["SECRET_KEY"]
csrf = CSRFProtect(app)

@app.route("/transfer", methods=["POST"])
def transfer():
    # SECURE: CSRF token validated automatically by flask_wtf
    amount = request.form["amount"]
    recipient = request.form["recipient"]
    do_transfer(amount, recipient)
    return "OK"
""",
        remediation="Implement CSRF tokens on all state-changing requests. Use SameSite cookie attribute. Verify Origin and Referer headers.",
        owasp_mapping="A01:2021-Broken Access Control",
        compliance_mapping={"PCI-DSS": "6.5.5", "NIST 800-53": "AC-4", "SOC 2": "CC6.1"},
    ),
    "CWE-502": CWEEntry(
        cwe_id="CWE-502",
        name="Deserialization of Untrusted Data",
        severity="HIGH",
        category="injection",
        description="The application deserializes untrusted data without verifying its content, potentially allowing remote code execution.",
        languages=["python", "java", "php"],
        vulnerable_pattern="""# Python - VULNERABLE
import pickle

def load_data(data):
    # VULNERABLE: pickle can execute arbitrary code
    return pickle.loads(data)

# Java - VULNERABLE
ObjectInputStream ois = new ObjectInputStream(input);
Object obj = ois.readObject();""",
        secure_pattern="""# Python - SECURE
import json

def load_data(data):
    # SECURE: use JSON instead of pickle
    return json.loads(data)

# If you must deserialize, sign and verify:
import hmac
import json

def load_signed_data(data, signature, key):
    expected_sig = hmac.new(key, data.encode(), "sha256").hexdigest()
    if not hmac.compare_digest(expected_sig, signature):
        raise ValueError("Invalid signature")
    return json.loads(data)""",
        remediation="Never deserialize untrusted data with pickle/marshal. Use JSON or Protocol Buffers. Sign serialized data if deserialization is required.",
        owasp_mapping="A08:2021-Software and Data Integrity Failures",
        compliance_mapping={"PCI-DSS": "6.5.1", "NIST 800-53": "SI-10", "SOC 2": "CC6.1"},
    ),
}


def get_cwe(cwe_id: str) -> Optional[CWEEntry]:
    normalized = cwe_id.upper().strip()
    if not normalized.startswith("CWE"):
        normalized = f"CWE-{normalized}" if normalized.isdigit() else normalized
    if not normalized.startswith("CWE-"):
        normalized = f"CWE-{normalized.replace('CWE', '').strip('-')}"
    return CWE_DATABASE.get(normalized)


def search_cwe(query: str, language: str = None, category: str = None, severity: str = None) -> list[CWEEntry]:
    query_lower = query.lower()
    results = []

    for cwe in CWE_DATABASE.values():
        if language and language.lower() not in [lang.lower() for lang in cwe.languages]:
            continue
        if category and category.lower() != cwe.category.lower():
            continue
        if severity and severity.upper() != cwe.severity.upper():
            continue

        searchable = f"{cwe.cwe_id} {cwe.name} {cwe.description} {cwe.category}".lower()
        if query_lower in searchable:
            results.append(cwe)

    return sorted(results, key=lambda c: {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}.get(c.severity, 4))


def get_remediation_snippet(cwe_id: str, language: str = "python") -> str:
    cwe = get_cwe(cwe_id)
    if not cwe:
        return f"No remediation snippet found for {cwe_id}"

    parts = [f"## {cwe.cwe_id}: {cwe.name}"]
    parts.append(f"Severity: {cwe.severity} | Category: {cwe.category}")
    parts.append(f"OWASP: {cwe.owasp_mapping}")
    parts.append(f"\n{cwe.description}")
    parts.append(f"\n### Vulnerable Pattern ({language}):")
    parts.append(cwe.vulnerable_pattern)
    parts.append(f"\n### Secure Pattern ({language}):")
    parts.append(cwe.secure_pattern)
    parts.append(f"\n### Remediation:")
    parts.append(cwe.remediation)

    if cwe.compliance_mapping:
        parts.append("\n### Compliance Mapping:")
        for standard, control in cwe.compliance_mapping.items():
            parts.append(f"  - {standard}: {control}")

    return "\n".join(parts)


def get_all_categories() -> list[str]:
    return sorted(set(c.category for c in CWE_DATABASE.values()))


def get_cwes_by_category(category: str) -> list[CWEEntry]:
    return [c for c in CWE_DATABASE.values() if c.category == category]


def format_cwe_list(cwes: list[CWEEntry], brief: bool = False) -> str:
    if not cwes:
        return "No matching CWE entries found."

    parts = [f"CWE Database Results — {len(cwes)} entries\n"]

    for cwe in cwes:
        sev_icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(cwe.severity, "⚪")
        if brief:
            parts.append(f"  {sev_icon} {cwe.cwe_id}: {cwe.name} [{cwe.severity}]")
        else:
            parts.append(f"  {sev_icon} {cwe.cwe_id}: {cwe.name}")
            parts.append(f"     Category: {cwe.category} | Severity: {cwe.severity} | OWASP: {cwe.owasp_mapping}")
            parts.append(f"     Languages: {', '.join(cwe.languages)}")
            parts.append(f"     {cwe.description[:120]}...")
            parts.append("")

    return "\n".join(parts)