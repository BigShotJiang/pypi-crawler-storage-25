"""Custom compliance rules engine for DeltaCode CLI.

User-defined YAML/JSON compliance rules that map finding patterns
to compliance controls across any framework.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class CustomComplianceRule:
    name: str
    framework: str
    control_id: str
    description: str
    cwe_patterns: list = field(default_factory=list)
    keyword_patterns: list = field(default_factory=list)
    severity_threshold: str = "MEDIUM"
    enabled: bool = True


class CustomComplianceEngine:
    def __init__(self, rules_path: str = None):
        self._rules: list[CustomComplianceRule] = []
        if rules_path:
            self.load_file(rules_path)
        self._load_defaults()

    def _load_defaults(self):
        defaults = [
            CustomComplianceRule(name="SSRF Detection", framework="custom", control_id="C-001",
                description="Ensure server-side request forgery protections", cwe_patterns=["CWE-918"]),
            CustomComplianceRule(name="Injection Prevention", framework="custom", control_id="C-002",
                description="Protect against injection attacks", cwe_patterns=["CWE-89", "CWE-78", "CWE-79"]),
            CustomComplianceRule(name="Secure Authentication", framework="custom", control_id="C-003",
                description="Strong authentication mechanisms", cwe_patterns=["CWE-287", "CWE-798"]),
            CustomComplianceRule(name="Data Protection", framework="custom", control_id="C-004",
                description="Protect data at rest and in transit", cwe_patterns=["CWE-327", "CWE-200", "CWE-256"]),
            CustomComplianceRule(name="Logging and Monitoring", framework="custom", control_id="C-005",
                description="Adequate logging and monitoring", keyword_patterns=["log", "audit", "monitor"]),
        ]
        for rule in defaults:
            if rule.name not in [r.name for r in self._rules]:
                self._rules.append(rule)

    def load_file(self, path: str):
        try:
            p = Path(path)
            if p.suffix == ".json":
                data = json.loads(p.read_text(encoding="utf-8"))
            elif p.suffix in (".yaml", ".yml"):
                import yaml
                data = yaml.safe_load(p.read_text(encoding="utf-8"))
            else:
                return

            for entry in data if isinstance(data, list) else data.get("rules", []):
                rule = CustomComplianceRule(
                    name=entry.get("name", ""),
                    framework=entry.get("framework", "custom"),
                    control_id=entry.get("control_id", ""),
                    description=entry.get("description", ""),
                    cwe_patterns=entry.get("cwe_patterns", []),
                    keyword_patterns=entry.get("keyword_patterns", []),
                    severity_threshold=entry.get("severity_threshold", "MEDIUM"),
                    enabled=entry.get("enabled", True),
                )
                existing = [r for r in self._rules if r.name == rule.name and r.framework == rule.framework]
                if not existing:
                    self._rules.append(rule)

        except Exception as e:
            pass

    def evaluate(self, findings: list[dict]) -> list[dict]:
        results = []
        for rule in self._rules:
            if not rule.enabled:
                continue

            matched = []
            for f in findings:
                f_cwe = f.get("cwe", f.get("cwe_id", ""))
                f_sev = f.get("severity", "MEDIUM")
                f_desc = (f.get("title", "") + " " + f.get("description", "") + " " + f.get("message", "")).lower()

                if rule.cwe_patterns:
                    if not any(cwe.upper() in f_cwe.upper() for cwe in rule.cwe_patterns):
                        if not any(kw.lower() in f_desc for kw in rule.keyword_patterns):
                            continue

                if rule.keyword_patterns and not f_cwe:
                    if not any(kw.lower() in f_desc for kw in rule.keyword_patterns):
                        continue

                sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
                if sev_order.get(f_sev, 3) > sev_order.get(rule.severity_threshold, 3):
                    continue

                matched.append(f)

            results.append({
                "rule_name": rule.name,
                "framework": rule.framework,
                "control_id": rule.control_id,
                "description": rule.description,
                "status": "failing" if matched else "passing",
                "matched_findings": len(matched),
                "findings": matched[:5],
            })

        return results

    def list_rules(self, framework: str = None) -> list[CustomComplianceRule]:
        if framework:
            return [r for r in self._rules if r.framework == framework]
        return list(self._rules)

    def add_rule(self, rule: CustomComplianceRule):
        self._rules.append(rule)

    def to_json(self) -> str:
        return json.dumps([r.__dict__ for r in self._rules], indent=2, ensure_ascii=False)