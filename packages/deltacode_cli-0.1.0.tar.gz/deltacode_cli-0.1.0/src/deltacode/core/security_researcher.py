"""Security research automation module.

Combines browser agent with multiple data sources:
- NVD/CVE database search (via MCP advisory connector)
- Vendor advisory scraping (Apache, Microsoft, Red Hat, etc.)
- Security blog RSS aggregation
- PoC/exploit status checking (ethical boundaries enforced)
"""

from __future__ import annotations

import re
import json
import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import httpx

from deltacode.core.logger import get_logger
from deltacode.core.browser_agent import BrowserAgent, PageResult
from deltacode.core.ethical_boundaries import EthicalBoundary, ResearchTracker, Citation, ResearchResult

logger = get_logger(__name__)


VENDOR_FEEDS = {
    "apache": "https://www.apache.org/security/announcements.xml",
    "microsoft": "https://msrc.microsoft.com/update-guide/rss",
    "redhat": "https://access.redhat.com/security/updates/advisory.rss",
    "ubuntu": "https://ubuntu.com/security/notices/rss.xml",
    "debian": "https://www.debian.org/security/dsa.rdf",
    "nvd": "https://nvd.nist.gov/feeds/xml/cve/nvdcve-2.0-Modified.xml",
    "mitre": "https://cve.mitre.org/data/downloads/allitems.xml",
    "thehackernews": "https://feeds.feedburner.com/TheHackersNews",
    "bleepingcomputer": "https://www.bleepingcomputer.com/feed/",
    "securityweek": "https://feeds.feedburner.com/Securityweek",
    "portswigger": "https://portswigger.net/research/rss",
    "snyk": "https://snyk.io/blog/feed.xml",
}

VENDOR_ADVISORY_URLS = {
    "apache": "https://www.apache.org/security/",
    "microsoft": "https://msrc.microsoft.com/update-guide/vulnerability",
    "redhat": "https://access.redhat.com/security/security-updates",
    "ubuntu": "https://ubuntu.com/security/notices",
    "cloudflare": "https://blog.cloudflare.com/security/",
    "github": "https://github.blog/category/security/",
    "google": "https://security.googleblog.com/",
}


@dataclass
class ResearchFinding:
    title: str
    description: str
    source: str
    url: str
    severity: str = "MEDIUM"
    cve_ids: list = field(default_factory=list)
    published: str = ""
    content_type: str = "advisory"


class SecurityResearcher:
    def __init__(self, data_dir: str = None):
        self.data_dir = Path(data_dir or Path.home() / ".deltacode" / "research_data")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.browser = BrowserAgent(headless=True, data_dir=str(self.data_dir))
        self.boundary = EthicalBoundary()
        self.tracker = ResearchTracker()
        self._http = httpx.Client(timeout=30, follow_redirects=True)

    async def research_cve(self, cve_id: str) -> ResearchResult:
        result = ResearchResult(query=f"CVE: {cve_id}")
        cve_id = cve_id.strip().upper()

        sources = [
            f"https://nvd.nist.gov/vuln/detail/{cve_id}",
            f"https://www.cve.org/CVERecord?id={cve_id}",
            f"https://vuldb.com/?id.{cve_id.replace('-', '.')}",
        ]

        for url in sources:
            page = await self.browser.navigate(url)
            if page.error:
                continue

            citation = self.boundary.create_citation(url, f"{cve_id} - {page.title[:100]}", page.text_content[:300])
            result.citations.append(citation)

            is_safe, warnings = self.boundary.check_content(page.text_content)
            if not is_safe:
                result.ethical_warnings.extend(warnings)
                result.blocked.append(url)
                continue

            content_type = self.boundary.classify_content_type(page.text_content, page.title)
            result.findings.append({
                "cve_id": cve_id,
                "title": page.title,
                "url": url,
                "content_type": content_type,
                "has_exploit_info": "exploit" in page.text_content.lower()[:1000],
                "cvss_scores": self._extract_cvss(page.text_content),
                "summary": page.text_content[:500],
            })

        return result

    def _extract_cvss(self, text: str) -> dict:
        scores = {}
        cvss_patterns = [
            (r'CVSS\s*(?:v3\.1|v3|3)\s*(?:Score|Base\s*Score)?\s*[:\s]*([0-9]+\.[0-9]+)', "cvss_v3"),
            (r'CVSS\s*(?:v2|2)\s*(?:Score|Base\s*Score)?\s*[:\s]*([0-9]+\.[0-9]+)', "cvss_v2"),
        ]
        for pattern, key in cvss_patterns:
            match = re.search(pattern, text, re.I)
            if match:
                try:
                    scores[key] = float(match.group(1))
                except ValueError:
                    pass
        return scores

    async def search_cve_by_keyword(self, keyword: str, days_back: int = 90) -> ResearchResult:
        result = ResearchResult(query=f"Search CVEs: {keyword}")

        search_url = f"https://nvd.nist.gov/vuln/search/results?query={keyword.replace(' ', '+')}&results_page=1&pub_date_range=custom&pub_start_date={datetime.utcnow() - timedelta(days=days_back)}&pub_end_date={datetime.utcnow()}"

        page = await self.browser.navigate(search_url)
        if page.error:
            result.findings.append({"error": page.error})
            return result

        cve_links = [l for l in page.links if "/vuln/detail/CVE-" in l][:20]
        for link in cve_links[:10]:
            detail = await self.browser.navigate(link)
            if detail.error:
                continue
            citation = self.boundary.create_citation(link, detail.title[:100], detail.text_content[:300])
            result.citations.append(citation)

            cve_match = re.search(r'CVE-\d{4}-\d{4,7}', link)
            cve_id = cve_match.group() if cve_match else ""
            result.findings.append({
                "cve_id": cve_id,
                "title": detail.title,
                "url": link,
                "summary": detail.text_content[:400],
            })

        return result

    async def scrape_vendor_advisories(self, vendor: str = None) -> ResearchResult:
        vendors = [vendor] if vendor else list(VENDOR_ADVISORY_URLS.keys())
        result = ResearchResult(query=f"Vendor advisories: {', '.join(vendors)}")

        for v_name in vendors:
            url = VENDOR_ADVISORY_URLS.get(v_name)
            if not url:
                continue

            page = await self.browser.navigate(url)
            if page.error:
                result.findings.append({"vendor": v_name, "error": page.error, "url": url})
                continue

            result.findings.append({
                "vendor": v_name,
                "title": page.title,
                "url": url,
                "page_summary": page.text_content[:500],
                "links_found": len(page.links),
                "cve_mentions": list(set(re.findall(r'CVE-\d{4}-\d{4,7}', page.text_content)))[:10],
            })

        return result

    def read_rss_feeds(self, feeds: list[str] = None) -> ResearchResult:
        import feedparser

        if feeds is None:
            feeds = list(VENDOR_FEEDS.values())

        target_feeds = feeds[:5]
        result = ResearchResult(query=f"RSS feeds: {len(target_feeds)} sources")

        for feed_url in target_feeds:
            try:
                resp = self._http.get(feed_url)
                resp.raise_for_status()
                parsed = feedparser.parse(resp.text)

                for entry in parsed.entries[:5]:
                    title = entry.get("title", "")
                    link = entry.get("link", "")
                    summary = entry.get("summary", entry.get("description", ""))[:300]
                    published = entry.get("published", datetime.now().isoformat())

                    cve_ids = re.findall(r'CVE-\d{4}-\d{4,7}', title + " " + summary)
                    severity = "MEDIUM"
                    if any(w in title.lower() for w in ["critical", "emergency", "0day"]):
                        severity = "CRITICAL"
                    elif any(w in title.lower() for w in ["high", "important"]):
                        severity = "HIGH"

                    result.findings.append({
                        "title": title,
                        "url": link,
                        "summary": summary,
                        "published": published,
                        "cve_ids": cve_ids,
                        "severity": severity,
                        "source": feed_url,
                    })

            except Exception as e:
                result.findings.append({"source": feed_url, "error": str(e)[:100]})

        return result

    async def full_research(self, query: str, include_vendors: bool = True, include_rss: bool = True) -> ResearchResult:
        result = ResearchResult(query=query)

        cve_match = re.match(r'CVE-\d{4}-\d{4,7}', query.strip().upper())
        if cve_match:
            cve_result = await self.research_cve(cve_match.group())
            result.findings.extend(cve_result.findings)
            result.citations.extend(cve_result.citations)
            result.ethical_warnings.extend(cve_result.ethical_warnings)
        else:
            cve_search = await self.search_cve_by_keyword(query, days_back=365)
            result.findings.extend(cve_search.findings)
            result.citations.extend(cve_search.citations)

        if include_vendors:
            vendor_result = await self.scrape_vendor_advisories()
            result.findings.extend(vendor_result.findings)
            result.citations.extend(vendor_result.citations)

        if include_rss:
            rss_result = self.read_rss_feeds()
            result.findings.extend(rss_result.findings)

        result.findings.sort(key=lambda f: {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}.get(f.get("severity", "MEDIUM"), 4))
        self.tracker.add_result(result)
        return result

    async def close(self):
        await self.browser.close()
        self._http.close()

    def format_report(self, result: ResearchResult, brief: bool = False) -> str:
        if not result.findings or (isinstance(result.findings[0], dict) and "error" in result.findings[0]):
            return "No research results found."

        parts = [f"## Research: {result.query}\n"]

        for f in result.findings:
            title = f.get("title", f.get("finding", "Unknown"))
            url = f.get("url", f.get("source", ""))
            severity = f.get("severity", "")
            sev_icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(severity, "⚪")

            if brief:
                parts.append(f"  {sev_icon} {title} [dim]{url[:80]}[/dim]")
            else:
                parts.append(f"### {sev_icon} {title}")
                parts.append(f"  URL: {url}")
                if f.get("cve_ids"):
                    parts.append(f"  CVEs: {', '.join(f['cve_ids'])}")
                if f.get("cvss_scores"):
                    parts.append(f"  CVSS: {f['cvss_scores']}")
                summary = f.get("summary", f.get("description", ""))
                if summary:
                    parts.append(f"  {summary[:200]}")
                parts.append("")

        if result.citations:
            parts.append("## Sources")
            for c in result.citations[:5]:
                parts.append(f"  - [{c.title[:80]}]({c.url})")

        if result.ethical_warnings:
            parts.append("\n## ⚠ Ethical Warnings")
            for w in result.ethical_warnings:
                parts.append(f"  - {w}")

        return "\n".join(parts)


def run_research(query: str, include_vendors: bool = True, include_rss: bool = True) -> dict:
    async def _run():
        researcher = SecurityResearcher()
        try:
            result = await researcher.full_research(query, include_vendors, include_rss)
            findings = result.findings
            citations = [{"url": c.url, "title": c.title} for c in result.citations]
            return {"findings": findings, "citations": citations, "ethical_warnings": result.ethical_warnings}
        finally:
            await researcher.close()

    return asyncio.run(_run())