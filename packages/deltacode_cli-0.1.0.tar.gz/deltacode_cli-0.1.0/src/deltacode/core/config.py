"""DeltaCode configuration management.

Config stored in ~/.deltacode/config.yaml — no hardcoded API URLs.
All settings are per-customer and set via `deltacode auth login` or manual edit.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import yaml
from platformdirs import user_config_dir, user_data_dir
from pydantic import BaseModel, Field

APP_NAME = "deltacode"
CONFIG_DIR = Path(user_config_dir(APP_NAME))
DATA_DIR = Path(user_data_dir(APP_NAME))
CONFIG_FILE = CONFIG_DIR / "config.yaml"


class DeltaCodeConfig(BaseModel):
    api_url: str = Field(default="", description="DeltaAI API base URL (per customer)")
    api_key: str = Field(default="", description="DeltaAI API key")
    license_key: str = Field(default="", description="DeltaCode license key")
    organization: str = Field(default="", description="Organization domain")
    default_model: str = Field(default="deltaai-rag", description="Default model for security analysis")
    default_category: str = Field(default="pentesting", description="Default security category")
    temperature: float = Field(default=0.3, description="LLM temperature (lower = more precise)")
    max_tokens: int = Field(default=8192, description="Max tokens per request")
    top_k: int = Field(default=5, description="RAG top-k results")
    auto_commit: bool = Field(default=True, description="Auto-commit security fixes")
    audit_log: bool = Field(default=True, description="Audit log all operations")

    @classmethod
    def load(cls, path: Optional[Path] = None) -> "DeltaCodeConfig":
        config_path = path or CONFIG_FILE
        if config_path.exists():
            with open(config_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            return cls(**data)
        return cls()

    def save(self, path: Optional[Path] = None) -> None:
        config_path = path or CONFIG_FILE
        config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(self.model_dump(), f, default_flow_style=False, allow_unicode=True)

    @property
    def is_configured(self) -> bool:
        return bool(self.api_url and self.api_key and self.license_key)

    @property
    def is_authenticated(self) -> bool:
        return self.is_configured and bool(self.organization)

    def mask_secrets(self) -> dict:
        data = self.model_dump()
        if data.get("api_key"):
            data["api_key"] = data["api_key"][:4] + "****" + data["api_key"][-4:]
        if data.get("license_key"):
            data["license_key"] = data["license_key"][:4] + "****" + data["license_key"][-4:]
        return data