"""Taint tracking for DeltaCode CLI.

Source-to-sink taint propagation analysis:
- Tainted input sources (user input, file, network)
- Propagation through assignments and function calls
- Sanitization detection
- Sink verification (is data properly sanitized before reaching sinks?)
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


TAINT_SOURCES = ["request", "input", "sys.argv", "environ", "stdin", "args", "form", "query_params"]
SANITIZATION_FUNCTIONS = ["escape", "sanitize", "clean", "validate", "strip_tags", "bleach.clean",
                          "DOMPurify", "html.escape", "urllib.parse.quote", "re.sub"]
DANGEROUS_SINKS = ["execute", "Popen", "system", "eval", "exec", "innerHTML", "document.write",
                   "html", "render_template_string"]


@dataclass
class TaintPath:
    source: str
    source_line: int
    sink: str
    sink_line: int
    intermediate_vars: list = field(default_factory=list)
    sanitized: bool = False
    sanitizer: str = ""
    severity: str = "HIGH"


class TaintTracker:
    def __init__(self, root_path: str = "."):
        self.root_path = Path(root_path).resolve()

    def analyze(self, target_files: list[str] = None) -> list[TaintPath]:
        paths = []

        if target_files is None:
            target_files = [str(f) for f in self.root_path.rglob("*.py") if f.is_file()]

        for fpath in target_files:
            try:
                content = Path(fpath).read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            rel = Path(fpath).relative_to(self.root_path) if self.root_path in Path(fpath).parents else fpath

            tainted_vars = set()
            sanitized_vars = set()
            source_info = {}

            lines = content.splitlines()
            for i, line in enumerate(lines):
                line_num = i + 1

                for src in TAINT_SOURCES:
                    if src in line.lower():
                        var_match = re.match(r'\s*(\w+)\s*=', line)
                        if var_match:
                            var_name = var_match.group(1)
                            tainted_vars.add(var_name)
                            source_info[var_name] = {"source": src, "line": line_num, "file": str(rel)}

                for san in SANITIZATION_FUNCTIONS:
                    if san.lower() in line.lower():
                        result_var = None
                        assign_match = re.match(r'\s*(\w+)\s*=', line)
                        if assign_match:
                            result_var = assign_match.group(1)
                            sanitized_vars.add(result_var)
                        for tv in list(tainted_vars):
                            if tv in line and result_var:
                                if tv not in sanitized_vars:
                                    tainted_vars.discard(tv)
                                    sanitized_vars.add(result_var)

                for sink in DANGEROUS_SINKS:
                    if sink.lower() in line.lower():
                        for tv in list(tainted_vars):
                            if tv in line:
                                info = source_info.get(tv, {"source": "?", "line": 0, "file": str(rel)})
                                is_sanitized = tv in sanitized_vars
                                sanitizer_name = ""
                                if is_sanitized:
                                    for s in lines[:i]:
                                        if tv in s and any(sn in s for sn in SANITIZATION_FUNCTIONS):
                                            sanitizer_name = s.strip()[:60]
                                            break

                                paths.append(TaintPath(
                                    source=info["source"],
                                    source_line=info["line"],
                                    sink=sink,
                                    sink_line=line_num,
                                    intermediate_vars=[tv],
                                    sanitized=is_sanitized,
                                    sanitizer=sanitizer_name,
                                    severity="LOW" if is_sanitized else "HIGH",
                                ))

        paths.sort(key=lambda p: {"HIGH": 0, "MEDIUM": 1, "LOW": 2}.get(p.severity, 3))
        return paths

    def format_report(self, paths: list[TaintPath]) -> str:
        if not paths:
            return "No taint paths detected."

        unsanitized = [p for p in paths if not p.sanitized]
        sanitized = [p for p in paths if p.sanitized]

        parts = [f"# Taint Tracking Report\n"]
        parts.append(f"Total paths: {len(paths)}")
        parts.append(f"Unsanitized: {len(unsanitized)} 🔴")
        parts.append(f"Sanitized: {len(sanitized)} ✅")
        parts.append("")

        if unsanitized:
            parts.append("## Unsanitized Paths (HIGH)\n")
            for p in unsanitized[:20]:
                parts.append(f"  🔴 {p.source}(L{p.source_line}) → ... → {p.sink}(L{p.sink_line})")
                parts.append(f"     Variables: {', '.join(p.intermediate_vars)}")

        if sanitized:
            parts.append("\n## Sanitized Paths (LOW)\n")
            for p in sanitized[:10]:
                parts.append(f"  ✅ {p.source}(L{p.source_line}) → {p.sanitizer[:40]} → {p.sink}(L{p.sink_line})")

        return "\n".join(parts)