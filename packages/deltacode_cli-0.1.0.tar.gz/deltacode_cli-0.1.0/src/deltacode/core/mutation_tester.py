"""Mutation testing module for DeltaCode CLI.

Evaluates test quality by introducing code mutations:
- Mutates source code (operator swaps, condition flips, etc.)
- Runs test suite against mutated code
- If tests pass → mutation survived → test gap detected
- Reports mutation score (killed / total)
"""

from __future__ import annotations

import ast
import random
import re
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


MUTATION_TYPES = ["replace_operator", "negate_condition", "remove_call"]


@dataclass
class Mutation:
    file: str
    line: int
    original: str
    mutated: str
    mutation_type: str
    killed: bool = False


@dataclass
class MutationResult:
    mutations: list = field(default_factory=list)
    total: int = 0
    killed: int = 0
    survived: int = 0
    score: float = 0.0
    duration_ms: int = 0


class MutationTester:
    def __init__(self, project_path: str = "."):
        self.project_path = Path(project_path).resolve()
        self._rng = random.Random(42)

    def generate_mutations(self, file_path: str, count: int = 10) -> list[Mutation]:
        fpath = self.project_path / file_path
        if not fpath.exists():
            return []

        content = fpath.read_text(encoding="utf-8", errors="replace")

        mutations = []
        try:
            tree = ast.parse(content)
        except SyntaxError:
            return []

        for node in ast.walk(tree):
            if len(mutations) >= count:
                break
            line = getattr(node, "lineno", 0)
            lines = content.split("\n")
            original = lines[line - 1] if 0 < line <= len(lines) else ""
            if not original or original.strip().startswith("#"):
                continue

            if isinstance(node, ast.If):
                mutated = re.sub(r'\bif\s+(.+?):', lambda m: f"if not ({m.group(1)}):", original)
                if mutated != original:
                    mutations.append(Mutation(file=str(file_path), line=line, original=original, mutated=mutated, mutation_type="negate_condition"))

            elif isinstance(node, ast.Compare):
                op_map = {"==": "!=", "!=": "==", ">": "<=", ">=": "<", "<": ">=", "<=": ">", "in": "not in", "not in": "in"}
                for old_op, new_op in op_map.items():
                    if old_op in original:
                        mutated = original.replace(old_op, new_op)
                        if mutated != original:
                            mutations.append(Mutation(file=str(file_path), line=line, original=original, mutated=mutated, mutation_type="replace_operator"))
                            break

            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id not in ("print", "len", "range", "int", "str", "list", "dict", "set", "type", "isinstance", "hasattr", "getattr", "super", "open", "enumerate", "zip", "map", "filter", "sorted", "reversed"):
                if self._rng.random() < 0.3:
                    mutated = f"# MUTATION-REMOVED: {original.strip()}"
                    mutations.append(Mutation(file=str(file_path), line=line, original=original, mutated=mutated, mutation_type="remove_call"))

        return mutations[:count]

    def run_mutation_test(self, mutations: list[Mutation], test_command: str = "pytest") -> MutationResult:
        result = MutationResult(mutations=mutations, total=len(mutations))
        orig_contents = {}

        for m in mutations:
            fpath = self.project_path / m.file
            if not fpath.exists():
                continue
            try:
                orig_contents[m.file] = fpath.read_text(encoding="utf-8")
            except Exception:
                continue

        for m in mutations:
            fpath = self.project_path / m.file
            content = orig_contents.get(m.file)
            if content is None:
                result.survived += 1
                continue

            try:
                mutated_content = content.replace(m.original, m.mutated)
                fpath.write_text(mutated_content, encoding="utf-8")

                start = time.time()
                test_result = subprocess.run(
                    test_command.split(),
                    capture_output=True, text=True, timeout=60,
                    cwd=str(self.project_path),
                )
                result.duration_ms += int((time.time() - start) * 1000)

                m.killed = (test_result.returncode != 0)
            except subprocess.TimeoutExpired:
                m.killed = False
            except Exception:
                m.killed = False
            finally:
                try:
                    fpath.write_text(content, encoding="utf-8")
                except Exception:
                    pass

            if m.killed:
                result.killed += 1
            else:
                result.survived += 1

        result.score = round(result.killed / max(result.total, 1) * 100, 1)
        return result

    def format_report(self, result: MutationResult) -> str:
        parts = [f"# Mutation Testing Report\n"]
        parts.append(f"Mutations: {result.total}")
        parts.append(f"Killed: {result.killed}")
        parts.append(f"Survived: {result.survived}")
        parts.append(f"Mutation Score: {result.score}%")
        parts.append(f"Duration: {result.duration_ms}ms")
        parts.append("")

        if result.survived > 0:
            parts.append(f"## Survived Mutations (test gaps)")
            for m in result.mutations:
                if not m.killed:
                    parts.append(f"  {m.file}:{m.line} [{m.mutation_type}]")
                    parts.append(f"     Original: {m.original.strip()[:60]}")
        else:
            parts.append("All mutations killed — test suite is robust")

        return "\n".join(parts)