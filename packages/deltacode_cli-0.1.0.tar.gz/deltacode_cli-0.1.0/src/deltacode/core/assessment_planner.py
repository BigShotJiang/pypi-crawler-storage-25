"""Security assessment planner for DeltaCode CLI.

Breaks down security audits into actionable tasks with:
- Risk-based prioritization
- Attack surface analysis
- Threat modeling automation
- Compliance framework mapping (SOC2, ISO27001, PCI-DSS)
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


COMPLIANCE_FRAMEWORKS = {
    "soc2": {
        "name": "SOC 2",
        "controls": [
            "CC6.1 Logical and Physical Access",
            "CC6.2 User Access Management",
            "CC6.3 Data Encryption",
            "CC6.4 Firewall and Network Security",
            "CC6.6 Vulnerability Management",
            "CC7.1 Detection and Monitoring",
            "CC7.2 Incident Response",
            "CC7.3 Remediation",
            "CC8.1 Change Management",
            "CC9.1 Risk Assessment",
        ],
    },
    "iso27001": {
        "name": "ISO 27001",
        "controls": [
            "A.5 Information Security Policies",
            "A.6 Organization of Information Security",
            "A.7 Human Resource Security",
            "A.8 Asset Management",
            "A.9 Access Control",
            "A.10 Cryptography",
            "A.11 Physical and Environmental Security",
            "A.12 Operations Security",
            "A.13 Communications Security",
            "A.14 System Acquisition and Development",
            "A.16 Incident Management",
        ],
    },
    "pci_dss": {
        "name": "PCI-DSS v4.0",
        "controls": [
            "Requirement 1: Network Security Controls",
            "Requirement 2: Secure Configuration",
            "Requirement 3: Stored Account Data Protection",
            "Requirement 4: Encryption of Cardholder Data",
            "Requirement 5: Malware Protection",
            "Requirement 6: Secure Development",
            "Requirement 7: Access Control",
            "Requirement 8: Authentication",
            "Requirement 9: Physical Security",
            "Requirement 10: Logging and Monitoring",
            "Requirement 11: Regular Testing",
        ],
    },
    "hipaa": {
        "name": "HIPAA",
        "controls": [
            "Administrative Safeguards: Security Management",
            "Administrative Safeguards: Workforce Security",
            "Administrative Safeguards: Information Access Management",
            "Physical Safeguards: Facility Access Controls",
            "Physical Safeguards: Workstation Security",
            "Technical Safeguards: Access Control",
            "Technical Safeguards: Audit Controls",
            "Technical Safeguards: Integrity Controls",
            "Technical Safeguards: Transmission Security",
        ],
    },
}

TASK_TEMPLATES = {
    "injection": {
        "sql_injection": {
            "title": "SQL Injection Assessment",
            "cwe": "CWE-89",
            "severity": "CRITICAL",
            "effort": "MEDIUM",
            "steps": [
                "Identify all SQL query construction points (raw SQL, ORM, stored procedures)",
                "Test for parameterized query usage",
                "Check input validation on all user-facing parameters",
                "Review database user permissions (least privilege)",
                "Test for second-order SQLi in stored data flows",
            ],
            "tools": ["semgrep", "custom_rules", "manual_review"],
        },
        "command_injection": {
            "title": "Command Injection Assessment",
            "cwe": "CWE-78",
            "severity": "CRITICAL",
            "effort": "MEDIUM",
            "steps": [
                "Find all os.system, subprocess, exec.Command calls",
                "Verify shell=False on all subprocess calls",
                "Check input validation on arguments passed to commands",
                "Review file path handling for injection vectors",
            ],
            "tools": ["semgrep", "custom_rules", "manual_review"],
        },
    },
    "xss": {
        "reflected_xss": {
            "title": "Reflected/Stored XSS Assessment",
            "cwe": "CWE-79",
            "severity": "HIGH",
            "effort": "MEDIUM",
            "steps": [
                "Find all innerHTML, document.write, v-html usages",
                "Check template rendering engines for auto-escaping",
                "Verify Content-Security-Policy headers",
                "Test sanitization libraries (DOMPurify, bleach)",
            ],
            "tools": ["semgrep", "custom_rules", "manual_review"],
        },
    },
    "auth": {
        "authentication": {
            "title": "Authentication Security Assessment",
            "cwe": "CWE-287",
            "severity": "CRITICAL",
            "effort": "HIGH",
            "steps": [
                "Review authentication flow (login, MFA, password reset)",
                "Check session management (token expiration, rotation)",
                "Verify password policies (complexity, hashing algorithm)",
                "Test for brute-force protection (rate limiting, lockout)",
                "Check OAuth/SSO implementation security",
                "Verify JWT handling (algorithm validation, expiration)",
            ],
            "tools": ["semgrep", "manual_review", "auth_flow_test"],
        },
    },
    "crypto": {
        "cryptographic_assessment": {
            "title": "Cryptographic Security Assessment",
            "cwe": "CWE-327",
            "severity": "HIGH",
            "effort": "MEDIUM",
            "steps": [
                "Verify encryption at rest and in transit",
                "Check TLS configuration (minimum TLS 1.2)",
                "Review certificate management (validity, revocation)",
                "Ensure proper key management (rotation, storage)",
                "Verify password hashing (bcrypt/argon2/scrypt)",
            ],
            "tools": ["custom_rules", "manual_review", "tls_scan"],
        },
    },
    "config": {
        "security_configuration": {
            "title": "Security Configuration Assessment",
            "cwe": "CWE-200",
            "severity": "HIGH",
            "effort": "LOW",
            "steps": [
                "Review environment variable exposure",
                "Check for debug mode in production",
                "Verify CORS configuration",
                "Review error handling (no stack traces to clients)",
                "Check rate limiting configuration",
                "Verify HSTS, CSP, X-Frame-Options headers",
            ],
            "tools": ["custom_rules", "dependency_scan", "manual_review"],
        },
    },
    "network": {
        "network_security": {
            "title": "Network Security Assessment",
            "cwe": "CWE-200",
            "severity": "MEDIUM",
            "effort": "HIGH",
            "steps": [
                "Review exposed ports and services",
                "Check firewall rules",
                "Verify network segmentation",
                "Review API endpoint exposure",
                "Check for internal service exposure",
            ],
            "tools": ["nmap", "zap", "burp", "manual_review"],
        },
    },
}


@dataclass
class AssessmentTask:
    id: str
    title: str
    cwe: str
    severity: str
    effort: str
    category: str
    steps: list
    tools: list
    status: str = "pending"
    findings: list = field(default_factory=list)
    estimated_time_minutes: int = 30

    @property
    def priority_score(self) -> int:
        sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
        effort_order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
        return (sev_order.get(self.severity, 3) * 3) + effort_order.get(self.effort, 2)


@dataclass
class AttackSurface:
    entry_points: list = field(default_factory=list)
    data_flows: list = field(default_factory=list)
    exposed_apis: list = field(default_factory=list)
    authentication_points: list = field(default_factory=list)
    third_party_components: list = field(default_factory=list)
    risk_score: float = 0.0


@dataclass
class AssessmentPlan:
    name: str
    created_at: str = ""
    tasks: list = field(default_factory=list)
    attack_surface: Optional[AttackSurface] = None
    compliance_mappings: dict = field(default_factory=dict)
    summary: dict = field(default_factory=dict)


class SecurityAssessmentPlanner:
    def __init__(self, project_path: str = "."):
        self.project_path = Path(project_path).resolve()
        self._context_builder = None
        self._dependency_analyzer = None

    def analyze_attack_surface(self, context_result: dict = None) -> AttackSurface:
        surface = AttackSurface()
        scanned_files = context_result.get("files", []) if context_result else []

        for f in scanned_files:
            path = f.get("path", "")
            categories = f.get("categories", [])

            if "api" in categories:
                surface.exposed_apis.append(path)
            if "auth" in categories:
                surface.authentication_points.append(path)

        surface.entry_points = list(set(
            surface.exposed_apis + surface.authentication_points
        ))

        surface.risk_score = len(surface.entry_points) * 5 + len(surface.exposed_apis) * 3

        return surface

    def create_assessment_plan(self, name: str, compliance_frameworks: list = None, context_result: dict = None) -> AssessmentPlan:
        plan = AssessmentPlan(
            name=name,
            created_at=datetime.utcnow().isoformat(),
            attack_surface=self.analyze_attack_surface(context_result),
        )

        for category, templates in TASK_TEMPLATES.items():
            for template_id, template in templates.items():
                task = AssessmentTask(
                    id=template_id,
                    title=template["title"],
                    cwe=template["cwe"],
                    severity=template["severity"],
                    effort=template["effort"],
                    category=category,
                    steps=template["steps"],
                    tools=template["tools"],
                )
                plan.tasks.append(task)

        plan.tasks.sort(key=lambda t: t.priority_score)

        if compliance_frameworks:
            for framework_id in compliance_frameworks:
                framework_id = framework_id.lower().replace("-", "_").replace(" ", "_")
                if framework_id in COMPLIANCE_FRAMEWORKS:
                    plan.compliance_mappings[framework_id] = COMPLIANCE_FRAMEWORKS[framework_id]

        plan.summary = self._generate_summary(plan)
        return plan

    def _generate_summary(self, plan: AssessmentPlan) -> dict:
        total = len(plan.tasks)
        by_severity = {}
        by_effort = {}
        for t in plan.tasks:
            by_severity[t.severity] = by_severity.get(t.severity, 0) + 1
            by_effort[t.effort] = by_effort.get(t.effort, 0) + 1

        total_estimated_minutes = sum(t.estimated_time_minutes for t in plan.tasks)

        return {
            "total_tasks": total,
            "by_severity": by_severity,
            "by_effort": by_effort,
            "estimated_hours": round(total_estimated_minutes / 60, 1),
            "attack_surface_risk": round(plan.attack_surface.risk_score, 1) if plan.attack_surface else 0,
            "compliance_frameworks": list(plan.compliance_mappings.keys()) if plan.compliance_mappings else [],
        }

    def get_threat_model(self, plan: AssessmentPlan) -> str:
        parts = ["# Threat Model\n"]
        parts.append(f"Assessment: {plan.name}")
        parts.append(f"Created: {plan.created_at}")
        parts.append("")

        if plan.attack_surface:
            surface = plan.attack_surface
            parts.append("## Attack Surface")
            parts.append(f"Risk Score: {surface.risk_score}")
            parts.append(f"Entry Points: {len(surface.entry_points)}")
            parts.append(f"Exposed APIs: {len(surface.exposed_apis)}")
            parts.append(f"Auth Points: {len(surface.authentication_points)}")
            parts.append("")

        parts.append("## Risk Assessment by STRIDE Category\n")
        stride_map = {
            "Spoofing": ["CWE-287", "CWE-294", "CWE-306"],
            "Tampering": ["CWE-89", "CWE-78", "CWE-79", "CWE-22"],
            "Repudiation": ["CWE-778"],
            "Information Disclosure": ["CWE-200", "CWE-327", "CWE-328"],
            "Denial of Service": ["CWE-400", "CWE-770"],
            "Elevation of Privilege": ["CWE-269", "CWE-287"],
        }

        task_cwes = set(t.cwe for t in plan.tasks)
        for stride, cwes in stride_map.items():
            matched = [c for c in cwes if c in task_cwes]
            if matched:
                tasks_with_cwe = [t for t in plan.tasks if t.cwe in matched]
                parts.append(f"### {stride} ({len(tasks_with_cwe)} related tasks)")
                for t in tasks_with_cwe:
                    parts.append(f"  - {t.title} [{t.severity}]")
            else:
                parts.append(f"### {stride} (no specific tasks)")
            parts.append("")

        parts.append("## Prioritized Task List\n")
        for i, t in enumerate(plan.tasks, 1):
            icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(t.severity, "⚪")
            parts.append(f"{i}. {icon} **{t.title}** ({t.severity}, effort: {t.effort})")
            for step in t.steps:
                parts.append(f"   - {step}")
            parts.append("")

        if plan.compliance_mappings:
            parts.append("## Compliance Mapping")
            for framework_id, framework in plan.compliance_mappings.items():
                parts.append(f"\n### {framework['name']}")
                for control in framework["controls"]:
                    parts.append(f"  - {control}")

        return "\n".join(parts)

    def format_plan(self, plan: AssessmentPlan, brief: bool = False) -> str:
        summary = plan.summary
        parts = [f"# Security Assessment: {plan.name}"]
        parts.append(f"Created: {plan.created_at}")
        parts.append("")

        parts.append(f"## Summary")
        parts.append(f"Total Tasks: {summary.get('total_tasks', 0)}")
        parts.append(f"Est. Hours: {summary.get('estimated_hours', 0)}")
        if "by_severity" in summary:
            parts.append(f"By Severity: {dict(summary['by_severity'])}")
        if "by_effort" in summary:
            parts.append(f"By Effort: {dict(summary['by_effort'])}")
        parts.append("")

        if plan.compliance_mappings:
            parts.append(f"Compliance: {', '.join(summary.get('compliance_frameworks', []))}")
            parts.append("")

        parts.append(f"## Tasks ({len(plan.tasks)})\n")
        for i, t in enumerate(plan.tasks, 1):
            icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(t.severity, "⚪")
            if brief:
                parts.append(f"{i}. {icon} {t.title} [{t.severity}, {t.effort}]")
            else:
                parts.append(f"{i}. {icon} **{t.title}**")
                parts.append(f"   CWE: {t.cwe} | Severity: {t.severity} | Effort: {t.effort}")
                parts.append(f"   Tools: {', '.join(t.tools)}")
                for step in t.steps:
                    parts.append(f"   * {step}")
                parts.append("")

        return "\n".join(parts)