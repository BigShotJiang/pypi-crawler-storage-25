"""Remediation planner for DeltaCode CLI.

Sequences security fixes based on:
- Dependency graph analysis (what breaks if we fix X first)
- Impact assessment (business risk vs engineering cost)
- Rollback planning
- Validation checkpoints
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class RemediationTask:
    id: str
    title: str
    cwe: str
    severity: str
    effort: str
    category: str
    dependent_tasks: list = field(default_factory=list)
    prerequisites: list = field(default_factory=list)
    estimated_hours: float = 1.0
    impact_score: float = 5.0
    risk_of_breakage: float = 3.0
    status: str = "pending"
    has_rollback: bool = False
    validation_steps: list = field(default_factory=list)


@dataclass
class RemediationPlan:
    name: str
    tasks: list = field(default_factory=list)
    dependencies: dict = field(default_factory=dict)
    sequence: list = field(default_factory=list)
    summary: dict = field(default_factory=dict)
    rollback_plan: dict = field(default_factory=dict)


class RemediationPlanner:
    def __init__(self, dependency_graph: dict = None):
        self.dependency_graph = dependency_graph or {}

    def build_remediation_plan(self, findings: list, graph: dict = None) -> RemediationPlan:
        plan = RemediationPlan(name=f"remediation_{datetime.now().strftime('%Y%m%d_%H%M%S')}")

        graph = graph or self.dependency_graph

        for finding in findings:
            task = RemediationTask(
                id=finding.get("id", f"task_{len(plan.tasks)}"),
                title=finding.get("title", finding.get("description", "Unknown issue")),
                cwe=finding.get("cwe", ""),
                severity=finding.get("severity", "MEDIUM"),
                effort=finding.get("effort", "MEDIUM"),
                category=finding.get("category", "general"),
            )

            file_path = finding.get("file", "")
            if file_path and graph:
                dependents = graph.get("dependents", {}).get(file_path, [])
                if dependents:
                    task.risk_of_breakage = min(task.risk_of_breakage + len(dependents) * 2, 10)
                    task.dependent_tasks = dependents

            task.validation_steps = self._generate_validation_steps(task)
            plan.tasks.append(task)

        plan.tasks.sort(key=lambda t: self._priority_weight(t))

        plan.dependencies = self._build_dependency_chain(plan.tasks)
        plan.sequence = self._sequence_tasks(plan.tasks, plan.dependencies)
        plan.rollback_plan = self._build_rollback_plan(plan.tasks)
        plan.summary = self._summarize(plan)

        return plan

    def _priority_weight(self, task: RemediationTask) -> float:
        sev_weights = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
        impact_vs_risk = task.impact_score / max(task.risk_of_breakage, 0.5)
        return sev_weights.get(task.severity, 3) * 2 + (5 - impact_vs_risk)

    def _build_dependency_chain(self, tasks: list[RemediationTask]) -> dict:
        deps = {}
        for task in tasks:
            affected = []
            for other in tasks:
                if other.id == task.id:
                    continue
                if any(dep == task.id for dep in other.prerequisites):
                    affected.append(other.id)
            deps[task.id] = affected
        return deps

    def _sequence_tasks(self, tasks: list[RemediationTask], deps: dict) -> list:
        sequenced = []
        visited = set()
        task_map = {t.id: t for t in tasks}

        def visit(task_id):
            if task_id in visited:
                return
            visited.add(task_id)
            for dep_id in task_map.get(task_id, RemediationTask).prerequisites:
                if dep_id in task_map:
                    visit(dep_id)
            sequenced.append(task_id)

        for task in tasks:
            visit(task.id)

        return [task_map.get(tid) for tid in sequenced if tid in task_map]

    def _generate_validation_steps(self, task: RemediationTask) -> list:
        steps = [
            "Verify fix compiles/passes syntax check",
            "Run existing test suite",
            "Check for regressions in affected files",
        ]
        if task.severity in ("CRITICAL", "HIGH"):
            steps.append("Run security scanner on patched code")
            steps.append("Peer review required")
        if task.risk_of_breakage > 5:
            steps.append("Run integration tests on dependent components")
            steps.append("Verify dependent module functionality")
        return steps

    def _build_rollback_plan(self, tasks: list[RemediationTask]) -> dict:
        return {
            "strategy": "git revert + stash restore",
            "prerequisites": [
                "Commit before each fix with descriptive message",
                "Tag pre-fix commits for easy revert",
            ],
            "recovery_steps": [
                "git revert <commit> for each applied fix in reverse order",
                "git stash pop if auto-fix created unsaved changes",
                "Run test suite to verify rollback succeeded",
            ],
            "estimated_rollback_time": f"{len(tasks) * 2} minutes",
        }

    def _summarize(self, plan: RemediationPlan) -> dict:
        total_hours = sum(t.estimated_hours for t in plan.tasks)
        critical = sum(1 for t in plan.tasks if t.severity == "CRITICAL")
        high = sum(1 for t in plan.tasks if t.severity == "HIGH")
        high_breakage = sum(1 for t in plan.tasks if t.risk_of_breakage > 7)

        phases = []
        current_phase = []
        phase_hours = 0
        for task in plan.sequence:
            current_phase.append(task)
            phase_hours += task.estimated_hours
            if phase_hours >= 4:
                phases.append(current_phase)
                current_phase = []
                phase_hours = 0
        if current_phase:
            phases.append(current_phase)

        return {
            "total_tasks": len(plan.tasks),
            "estimated_hours": round(total_hours, 1),
            "critical_fixes": critical,
            "high_fixes": high,
            "high_breakage_risk": high_breakage,
            "phases": len(phases),
            "rollback_ready": all(t.has_rollback for t in plan.tasks) if plan.tasks else False,
        }

    def format_plan(self, plan: RemediationPlan, brief: bool = False) -> str:
        parts = [f"# Remediation Plan: {plan.name}"]
        parts.append("")

        summary = plan.summary
        parts.append(f"## Summary")
        parts.append(f"Total Tasks: {summary.get('total_tasks', 0)}")
        parts.append(f"Est. Hours: {summary.get('estimated_hours', 0)}")
        parts.append(f"Critical: {summary.get('critical_fixes', 0)} | High: {summary.get('high_fixes', 0)}")
        parts.append(f"High Breakage Risk: {summary.get('high_breakage_risk', 0)}")
        parts.append(f"Phases: {summary.get('phases', 0)}")

        if summary.get("rollback_ready"):
            parts.append("Rollback Ready: ✅")
        parts.append("")

        if plan.rollback_plan:
            parts.append("## Rollback Plan")
            parts.append(f"Strategy: {plan.rollback_plan.get('strategy', 'N/A')}")
            for step in plan.rollback_plan.get("recovery_steps", []):
                parts.append(f"  - {step}")
            parts.append("")

        parts.append(f"## Execution Sequence ({len(plan.sequence)} tasks)\n")
        for i, task in enumerate(plan.sequence, 1):
            breakage_warn = " ⚠" if task.risk_of_breakage > 7 else ""
            icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(task.severity, "⚪")

            if brief:
                parts.append(f"{i}. {icon} {task.title} [{task.severity}, {task.effort}, ~{task.estimated_hours}h]{breakage_warn}")
            else:
                parts.append(f"{i}. {icon} **[bold]{task.title}[/bold]**")
                parts.append(f"   CWE: {task.cwe} | Severity: {task.severity} | Effort: {task.effort}")
                parts.append(f"   Est. Time: {task.estimated_hours}h | Breakage Risk: {task.risk_of_breakage}/10")
                if task.dependent_tasks:
                    parts.append(f"   Affects: {', '.join(task.dependent_tasks)}")
                parts.append(f"   Validation:")
                for step in task.validation_steps[:3]:
                    parts.append(f"     - {step}")
                parts.append("")

        return "\n".join(parts)