"""Supply chain risk assessment module for DeltaCode CLI.

Evaluates third-party dependency risk based on:
- Package freshness (last update date)
- Download popularity / community adoption
- Number of maintainers
- Known vulnerability history
- License risk
- Source provenance (official vs fork vs suspicious)
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import httpx

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class SupplyChainRisk:
    package: str
    version: str
    ecosystem: str
    risk_score: float = 0.0
    risk_level: str = "UNKNOWN"
    freshness_days: int = 0
    download_count: int = 0
    maintainer_count: int = 0
    known_vulns: int = 0
    license_risk: str = "UNKNOWN"
    is_fork: bool = False
    is_deprecated: bool = False
    has_maintainer_activity: bool = True
    warnings: list = field(default_factory=list)
    details: dict = field(default_factory=dict)

    def calculate_risk(self):
        score = 0.0
        warnings = []

        if self.freshness_days > 365:
            score += 2.0
            warnings.append(f"No update in {self.freshness_days} days")
        elif self.freshness_days > 180:
            score += 1.0
            warnings.append(f"No update in {self.freshness_days} days")

        if self.known_vulns > 5:
            score += 3.0
            warnings.append(f"{self.known_vulns} known vulnerabilities")
        elif self.known_vulns > 2:
            score += 1.5
            warnings.append(f"{self.known_vulns} known vulnerabilities")
        elif self.known_vulns > 0:
            score += 0.5
            warnings.append(f"{self.known_vulns} known vulnerabilities")

        if self.download_count < 1000:
            score += 1.5
            warnings.append(f"Low download count ({self.download_count})")
        elif self.download_count < 10000:
            score += 0.5
            warnings.append(f"Moderate download count ({self.download_count})")

        if self.maintainer_count == 0:
            score += 2.0
            warnings.append("No maintainer data available")
        elif self.maintainer_count == 1:
            score += 1.0
            warnings.append("Single maintainer — bus factor risk")

        if self.license_risk == "RESTRICTIVE":
            score += 2.0
            warnings.append(f"Restrictive license")
        elif self.license_risk == "UNKNOWN":
            score += 0.5
            warnings.append("Unknown license")

        if self.is_fork:
            score += 1.0
            warnings.append("Package is a fork")

        if self.is_deprecated:
            score += 3.0
            warnings.append("Package is deprecated")

        if not self.has_maintainer_activity:
            score += 1.0
            warnings.append("No recent maintainer activity")

        if score >= 7:
            self.risk_level = "CRITICAL"
        elif score >= 5:
            self.risk_level = "HIGH"
        elif score >= 3:
            self.risk_level = "MEDIUM"
        elif score > 0:
            self.risk_level = "LOW"
        else:
            self.risk_level = "NONE"

        self.risk_score = round(score, 1)
        self.warnings = warnings


class SupplyChainAnalyzer:
    def __init__(self, root_path: str = "."):
        self.root_path = Path(root_path).resolve()
        self._pypi_cache: dict = {}

    def analyze(self) -> list[SupplyChainRisk]:
        risks = []
        risks.extend(self._analyze_python())
        risks.extend(self._analyze_javascript())
        for r in risks:
            r.calculate_risk()
        risks.sort(key=lambda r: r.risk_score, reverse=True)
        return risks

    def _analyze_python(self) -> list[SupplyChainRisk]:
        req_files = [
            self.root_path / "requirements.txt",
            self.root_path / "requirements-dev.txt",
            self.root_path / "requirements-prod.txt",
            self.root_path / "Pipfile",
            self.root_path / "pyproject.toml",
        ]

        packages = set()
        for fpath in req_files:
            if not fpath.exists():
                continue
            try:
                content = fpath.read_text(encoding="utf-8", errors="replace")
                for line in content.splitlines():
                    line = line.strip()
                    if not line or line.startswith("#") or line.startswith("-"):
                        continue
                    pkg_match = re.match(r'^([A-Za-z0-9_.-]+)', line)
                    if pkg_match:
                        packages.add(pkg_match.group(1).lower().replace("_", "-"))
            except Exception:
                pass

        results = []
        for pkg in sorted(packages):
            info = self._query_pypi(pkg)
            if info:
                results.append(info)

        return results

    def _query_pypi(self, package: str) -> Optional[SupplyChainRisk]:
        if package in self._pypi_cache:
            return self._pypi_cache[package]

        try:
            resp = httpx.get(f"https://pypi.org/pypi/{package}/json", timeout=15)
            if resp.status_code != 200:
                return None

            data = resp.json()
            info = data.get("info", {})

            releases = data.get("releases", {})
            release_dates = []
            for version, files in releases.items():
                for f in files:
                    upload_time = f.get("upload_time", "")
                    if upload_time:
                        try:
                            release_dates.append(datetime.fromisoformat(upload_time.replace("Z", "+00:00")))
                        except ValueError:
                            pass

            freshness_days = 0
            if release_dates:
                latest = max(release_dates)
                freshness_days = (datetime.utcnow() - latest.replace(tzinfo=None)).days

            download_count = 0
            try:
                stats_resp = httpx.get(f"https://pypistats.org/api/packages/{package}/recent", timeout=10)
                if stats_resp.status_code == 200:
                    stats_data = stats_resp.json()
                    download_count = stats_data.get("data", {}).get("last_month", 0)
            except Exception:
                pass

            author = info.get("author", "")
            author_email = info.get("author_email", "")
            maintainers = info.get("maintainers", []) or info.get("maintainer", "")
            maintainer_count = 0
            if isinstance(maintainers, list):
                maintainer_count = len(maintainers)
            elif maintainers:
                maintainer_count = 1

            license_raw = (info.get("license", "") or "").lower()
            license_risk = "UNKNOWN"
            restrictive_licenses = ["sspl", "bsl", "elastic", "proprietary", "commercial", "business source"]
            permissive_licenses = ["mit", "apache", "bsd", "isc", "unlicense", "psf", "cc0", "zlib"]
            if any(r in license_raw for r in restrictive_licenses):
                license_risk = "RESTRICTIVE"
            elif any(p in license_raw for p in permissive_licenses):
                license_risk = "PERMISSIVE"
            elif license_raw:
                license_risk = "COPLEFT"

            classifiers = info.get("classifiers", [])
            deprecated = any("deprecated" in c.lower() for c in classifiers)

            description = info.get("summary", "") or ""
            is_fork = "fork" in description.lower() or "forked from" in description.lower()

            project_urls = info.get("project_urls", {}) or {}
            home_page = info.get("home_page", "") or ""
            has_repo = bool(project_urls.get("Source") or project_urls.get("Repository") or home_page)

            risk = SupplyChainRisk(
                package=package,
                version=info.get("version", "unknown"),
                ecosystem="python",
                freshness_days=freshness_days,
                download_count=download_count,
                maintainer_count=maintainer_count,
                known_vulns=0,
                license_risk=license_risk,
                is_fork=is_fork,
                is_deprecated=deprecated,
                has_maintainer_activity=bool(author or author_email or has_repo),
                details={
                    "summary": description[:200],
                    "author": author,
                    "home_page": home_page,
                    "python_versions": info.get("requires_python", ""),
                    "classifiers_count": len(classifiers),
                },
            )

            self._pypi_cache[package] = risk
            return risk

        except httpx.TimeoutException:
            return None
        except Exception as e:
            return None

    def _analyze_javascript(self) -> list[SupplyChainRisk]:
        pkg_path = self.root_path / "package.json"
        if not pkg_path.exists():
            return []

        try:
            data = json.loads(pkg_path.read_text(encoding="utf-8"))
        except Exception:
            return []

        all_deps = {}
        all_deps.update(data.get("dependencies", {}))
        all_deps.update(data.get("devDependencies", {}))

        results = []
        for pkg_name, version in all_deps.items():
            info = self._query_npm(pkg_name, version)
            if info:
                results.append(info)

        return results

    def _query_npm(self, package: str, version: str) -> Optional[SupplyChainRisk]:
        try:
            resp = httpx.get(f"https://registry.npmjs.org/{package}", timeout=15)
            if resp.status_code != 200:
                return None

            data = resp.json()

            latest_version = data.get("dist-tags", {}).get("latest", version)
            versions_data = data.get("versions", {})

            version_info = versions_data.get(latest_version, {})
            if not version_info:
                version_info = versions_data.get(version, {})

            time_data = data.get("time", {})
            publish_dates = []
            for v_name, v_time in time_data.items():
                if v_name != "created" and v_name != "modified":
                    try:
                        publish_dates.append(datetime.fromisoformat(v_time.replace("Z", "+00:00")))
                    except (ValueError, TypeError):
                        pass

            freshness_days = 0
            if publish_dates:
                latest = max(publish_dates)
                freshness_days = (datetime.utcnow() - latest.replace(tzinfo=None)).days

            maintainers = data.get("maintainers", [])
            maintainer_count = len(maintainers)

            downloads = 0
            try:
                dl_resp = httpx.get(f"https://api.npmjs.org/downloads/point/last-month/{package}", timeout=10)
                if dl_resp.status_code == 200:
                    downloads = dl_resp.json().get("downloads", 0)
            except Exception:
                pass

            license_raw = (version_info.get("license", "") or "").lower()
            license_risk = "UNKNOWN"
            restrictive = ["sspl", "bsl", "elastic", "proprietary", "commercial", "unlicensed"]
            permissive = ["mit", "apache", "bsd", "isc", "unlicense", "cc0", "zlib"]
            if any(r in license_raw for r in restrictive):
                license_risk = "RESTRICTIVE"
            elif any(p in license_raw for p in permissive):
                license_risk = "PERMISSIVE"
            elif license_raw:
                license_risk = "COPLEFT"

            deprecated = version_info.get("deprecated") is not None
            description = version_info.get("description", "") or ""
            is_fork = "fork" in description.lower()

            risk = SupplyChainRisk(
                package=package,
                version=latest_version,
                ecosystem="javascript",
                freshness_days=freshness_days,
                download_count=downloads,
                maintainer_count=maintainer_count,
                known_vulns=0,
                license_risk=license_risk,
                is_fork=is_fork,
                is_deprecated=deprecated,
                has_maintainer_activity=maintainer_count > 0,
                details={
                    "summary": description[:200],
                    "home_page": data.get("homepage", ""),
                },
            )

            return risk

        except httpx.TimeoutException:
            return None
        except Exception as e:
            return None

    def format_report(self, risks: list[SupplyChainRisk], brief: bool = False) -> str:
        if not risks:
            return "No supply chain risk data available."

        parts = [f"Supply Chain Risk Assessment — {len(risks)} packages\n"]

        risks_by_level = {"CRITICAL": [], "HIGH": [], "MEDIUM": [], "LOW": [], "NONE": []}
        for r in risks:
            risks_by_level.setdefault(r.risk_level, []).append(r)

        for level in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "NONE"):
            level_risks = risks_by_level.get(level, [])
            if not level_risks:
                continue
            icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵", "NONE": "✅"}[level]
            parts.append(f"\n## {icon} {level} ({len(level_risks)} packages)\n")
            for r in level_risks:
                parts.append(f"  {r.package} {r.version} [{r.ecosystem}]")
                parts.append(f"     Risk: {r.risk_score}/10 | Freshness: {r.freshness_days}d | Downloads: {r.download_count:,}")
                parts.append(f"     License: {r.license_risk} | Maintainers: {r.maintainer_count}")
                if r.warnings:
                    for w in r.warnings[:3]:
                        parts.append(f"     ⚠ {w}")
                parts.append("")

        total_critical = sum(1 for r in risks if r.risk_level == "CRITICAL")
        total_high = sum(1 for r in risks if r.risk_level == "HIGH")

        summary = f"Total dependencies assessed: {len(risks)} | CRITICAL: {total_critical} | HIGH: {total_high}"
        parts.append(f"\n{'='*50}\n{summary}")

        return "\n".join(parts)

    def detailed_report(self, package: str) -> Optional[str]:
        for risk in self._analyze_python():
            if risk.package == package:
                return self.format_report([risk], brief=False)
        for risk in self._analyze_javascript():
            if risk.package == package:
                return self.format_report([risk], brief=False)
        return f"Package '{package}' not found in project dependencies."