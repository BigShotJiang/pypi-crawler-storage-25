"""Ethical boundaries and content filtering for DeltaCode Browser Agent.

Enforces responsible use:
- Blocks exploit/PoC download pages
- Filters malicious content
- Requires explicit authorization for certain targets
- Maintains citation trail
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional


BLOCKED_DOMAINS = [
    "exploit-db.com/download",
    "raw.githubusercontent.com/exploit",
    "pastebin.com/raw",
    "github.com/rapid7/metasploit-framework/blob/master/modules/exploits",
]

SENSITIVE_KEYWORDS = [
    r"exploit\s*code", r"proof[-\s]of[-\s]concept",
    r"0day", r"zero[-\s]day", r"remote\s*code\s*execution\s*payload",
    r"shellcode", r"buffer\s*overflow\s*exploit",
]

ALLOWED_CONTENT_TYPES = [
    "advisory", "patch", "mitigation", "update", "changelog",
    "release notes", "security bulletin", "cve detail",
    "vulnerability disclosure", "security advisory",
]


@dataclass
class Citation:
    url: str
    title: str
    accessed_at: str
    content_hash: str = ""
    snippet: str = ""


@dataclass
class ResearchResult:
    query: str
    citations: list = field(default_factory=list)
    findings: list = field(default_factory=list)
    blocked: list = field(default_factory=list)
    ethical_warnings: list = field(default_factory=list)


class EthicalBoundary:
    def __init__(self, data_dir: str = None):
        self.data_dir = Path(data_dir or Path.home() / ".deltacode" / "research_data")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._authorized_targets: set = set()

    def check_url(self, url: str) -> bool:
        url_lower = url.lower()
        for blocked in BLOCKED_DOMAINS:
            if blocked in url_lower:
                return False
        return True

    def check_content(self, text: str) -> tuple[bool, list[str]]:
        warnings = []
        for pattern in SENSITIVE_KEYWORDS:
            if re.search(pattern, text, re.I):
                warnings.append(f"Content contains potentially sensitive pattern: {pattern}")
        return len(warnings) == 0, warnings

    def classify_content_type(self, text: str, title: str) -> str:
        lower = (title + " " + text[:500]).lower()
        for ctype in ALLOWED_CONTENT_TYPES:
            if ctype in lower:
                return ctype
        return "unknown"

    def create_citation(self, url: str, title: str, snippet: str = "") -> Citation:
        return Citation(
            url=url,
            title=title,
            accessed_at=datetime.utcnow().isoformat(),
            content_hash="",
            snippet=snippet[:200],
        )

    def record_finding(self, finding: str, source_url: str, severity: str = "INFO") -> dict:
        return {
            "finding": finding,
            "source": source_url,
            "severity": severity,
            "timestamp": datetime.utcnow().isoformat(),
            "citation_required": True,
        }


class ResearchTracker:
    def __init__(self, session_name: str = None):
        self.session_name = session_name or datetime.now().strftime("%Y%m%d_%H%M%S")
        self.results: list[ResearchResult] = []
        self.citations: list[Citation] = []
        self._boundary = EthicalBoundary()

    def add_result(self, result: ResearchResult):
        self.results.append(result)

    def add_citation(self, citation: Citation):
        self.citations.append(citation)

    def get_report(self, include_blocked: bool = False) -> str:
        parts = [f"# Security Research Session: {self.session_name}\n"]
        parts.append(f"Total results: {len(self.results)}")
        parts.append(f"Total citations: {len(self.citations)}")
        parts.append("")

        for i, result in enumerate(self.results, 1):
            parts.append(f"## Research Query {i}: {result.query}")
            if result.ethical_warnings:
                for w in result.ethical_warnings:
                    parts.append(f"  [!] ETHICAL WARNING: {w}")
            if result.findings:
                parts.append("  Findings:")
                for f in result.findings:
                    parts.append(f"    - {f.get('finding', f)}")
            if result.citations:
                parts.append("  Sources:")
                for c in result.citations:
                    parts.append(f"    - [{c.title}]({c.url})")
            if include_blocked and result.blocked:
                parts.append("  Blocked sources:")
                for b in result.blocked:
                    parts.append(f"    - {b}")
            parts.append("")

        if self.citations:
            parts.append("## References")
            for c in self.citations:
                parts.append(f"- [{c.title}]({c.url}) — accessed {c.accessed_at}")

        return "\n".join(parts)

    def export_json(self, path: str = None) -> str:
        data = {
            "session": self.session_name,
            "created_at": datetime.utcnow().isoformat(),
            "results": [
                {
                    "query": r.query,
                    "findings": r.findings,
                    "citations": [{"url": c.url, "title": c.title, "accessed_at": c.accessed_at} for c in r.citations],
                    "ethical_warnings": r.ethical_warnings,
                }
                for r in self.results
            ],
            "citations": [{"url": c.url, "title": c.title, "accessed_at": c.accessed_at} for c in self.citations],
        }

        if path:
            Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False))
        return json.dumps(data, indent=2, ensure_ascii=False)