"""Browser agent framework for DeltaCode CLI.

Playwright-based headless browser for security research automation.
Supports page navigation, content extraction, screenshot capture,
and safe browsing with ethical boundary enforcement.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger
from deltacode.core.ethical_boundaries import EthicalBoundary

logger = get_logger(__name__)


@dataclass
class PageResult:
    url: str
    title: str = ""
    text_content: str = ""
    markdown_content: str = ""
    html_snippet: str = ""
    links: list = field(default_factory=list)
    screenshot_path: str = ""
    status_code: int = 0
    load_time_ms: int = 0
    error: str = ""
    fetched_at: str = ""


class BrowserAgent:
    def __init__(self, headless: bool = True, data_dir: str = None):
        self.headless = headless
        self.data_dir = Path(data_dir or Path.home() / ".deltacode" / "browser_data")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._browser = None
        self._context = None
        self._page = None
        self._boundary = EthicalBoundary()

    async def _ensure_browser(self):
        if self._browser is None:
            from playwright.async_api import async_playwright
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                args=[
                    "--no-sandbox",
                    "--disable-setuid-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-web-security",
                ],
            )
            self._context = await self._browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                viewport={"width": 1280, "height": 800},
                ignore_https_errors=False,
                java_script_enabled=True,
                extra_http_headers={
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    "Accept-Language": "en-US,en;q=0.5",
                },
            )
            self._page = await self._context.new_page()
        return self._page

    async def navigate(self, url: str, timeout_ms: int = 30000) -> PageResult:
        if not self._boundary.check_url(url):
            return PageResult(url=url, error=f"URL blocked by ethical boundary: {url}")

        result = PageResult(url=url, fetched_at=datetime.utcnow().isoformat())

        try:
            page = await self._ensure_browser()
            start = time.time()
            resp = await page.goto(url, wait_until="domcontentloaded", timeout=timeout_ms)
            result.load_time_ms = int((time.time() - start) * 1000)

            if resp:
                result.status_code = resp.status

            result.title = await page.title()
            result.text_content = await page.inner_text("body")
            result.markdown_content = await self._convert_to_markdown(page)
            result.html_snippet = await page.inner_html("body")
            links = await page.eval_on_selector_all("a[href]", "els => els.map(e => e.href)")
            result.links = [l for l in links if l.startswith("http")][:50]

        except Exception as e:
            result.error = str(e)[:200]

        return result

    async def _convert_to_markdown(self, page) -> str:
        try:
            md = await page.evaluate("""
                () => {
                    function convert(node) {
                        if (node.nodeType === 3) return node.textContent;
                        if (node.nodeType !== 1) return '';
                        const tag = node.tagName.toLowerCase();
                        const children = Array.from(node.childNodes).map(convert).join('');
                        if (['script', 'style', 'noscript'].includes(tag)) return '';
                        if (tag === 'h1') return '# ' + children + '\\n\\n';
                        if (tag === 'h2') return '## ' + children + '\\n\\n';
                        if (tag === 'h3') return '### ' + children + '\\n\\n';
                        if (tag === 'p') return children + '\\n\\n';
                        if (tag === 'li') return '- ' + children + '\\n';
                        if (tag === 'a') {
                            const href = node.href || '';
                            return '[' + children + '](' + href + ')';
                        }
                        if (tag === 'code') return '`' + children + '`';
                        if (tag === 'pre') return '```\\n' + children + '\\n```\\n\\n';
                        if (tag === 'br') return '\\n';
                        if (['div', 'span', 'section', 'article', 'main'].includes(tag)) return children + '\\n';
                        if (tag === 'tr') return '| ' + children.trim() + ' |\\n';
                        if (tag === 'th') return children;
                        if (tag === 'td') return children;
                        return children;
                    }
                    const body = document.querySelector('body');
                    if (!body) return '';
                    return convert(body).replace(/\\n{3,}/g, '\\n\\n').trim();
                }
            """)
            return md[:50000] if md else ""
        except Exception:
            return self._strip_html_to_text(await page.inner_text("body"))

    def _strip_html_to_text(self, html: str) -> str:
        import re
        text = re.sub(r'<[^>]+>', ' ', html)
        text = re.sub(r'\s+', ' ', text)
        return text.strip()[:50000]

    async def screenshot(self, url: str, name: str = None) -> Optional[str]:
        if not self._boundary.check_url(url):
            return None

        try:
            page = await self._ensure_browser()
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(1)

            if name is None:
                name = hashlib.md5(url.encode()).hexdigest()[:12]

            screenshot_dir = self.data_dir / "screenshots"
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            path = str(screenshot_dir / f"{name}.png")
            await page.screenshot(path=path, full_page=False)
            return path

        except Exception as e:
            return None

    async def search_web(self, query: str, max_results: int = 10) -> list[dict]:
        results = []
        search_urls = [
            f"https://duckduckgo.com/html/?q={query.replace(' ', '+')}",
        ]

        for url in search_urls:
            result = await self.navigate(url)
            if result.error:
                continue

            import re
            link_pattern = re.compile(r'<a[^>]+class="result__a[^"]*"[^>]*href="([^"]+)"[^>]*>([^<]+)</a>', re.I)
            for match in link_pattern.finditer(result.html_snippet[:100000]):
                href, title = match.groups()
                if not href.startswith("http"):
                    continue
                results.append({"title": title.strip(), "url": href})
                if len(results) >= max_results:
                    break

        return results

    async def extract_security_content(self, url: str) -> dict:
        result = await self.navigate(url)
        if result.error:
            return {"error": result.error, "url": url}

        cve_patterns = []
        import re
        for match in re.finditer(r'CVE-\d{4}-\d{4,7}', result.text_content):
            cve_patterns.append(match.group())

        tech_mentions = []
        tech_keywords = ["apache", "nginx", "linux", "windows", "docker", "kubernetes",
                         "python", "node", "java", "openssl", "ssh", "tls", "oauth", "jwt"]
        lower_text = result.text_content.lower()
        for kw in tech_keywords:
            if kw in lower_text:
                tech_mentions.append(kw)

        return {
            "url": url,
            "title": result.title,
            "cve_mentions": list(set(cve_patterns))[:20],
            "tech_mentions": list(set(tech_mentions)),
            "load_time_ms": result.load_time_ms,
            "status_code": result.status_code,
            "text_length": len(result.text_content),
            "markdown": result.markdown_content[:10000],
            "links": result.links[:20],
        }

    async def close(self):
        if self._browser:
            await self._browser.close()
        if hasattr(self, "_playwright"):
            await self._playwright.stop()
        self._browser = None
        self._context = None
        self._page = None


def run_async(coro):
    return asyncio.run(coro)