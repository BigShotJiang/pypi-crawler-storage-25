"""System diagnostics for DeltaCode CLI.

Checks all components and dependencies:
- Python version
- DeltaAI API connectivity
- License validity
- Docker availability
- Git availability
- External tools (bandit, semgrep, etc.)
- Playwright availability
- Config file integrity
- Disk space
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger
from deltacode.core.config import DeltaCodeConfig, DATA_DIR
from deltacode.auth.license import validate_license
from deltacode.client.api import DeltaAIClient

logger = get_logger(__name__)


@dataclass
class DiagnosticResult:
    component: str
    status: str
    detail: str = ""
    fixable: bool = False
    fix_command: str = ""


class Diagnostics:
    def __init__(self):
        self._results: list[DiagnosticResult] = []
        self._config = None
        try:
            self._config = DeltaCodeConfig.load()
        except Exception:
            pass

    def run_all(self):
        self._results = []
        self.check_python()
        self.check_config()
        self.check_api_connection()
        self.check_license()
        self.check_docker()
        self.check_git()
        self.check_tools()
        self.check_optional_deps()
        self.check_disk_space()
        return self._results

    def add(self, component: str, status: str, detail: str = "", fixable: bool = False, fix: str = ""):
        self._results.append(DiagnosticResult(component=component, status=status, detail=detail, fixable=fixable, fix_command=fix))

    def check_python(self):
        v = sys.version_info
        if v.major >= 3 and v.minor >= 10:
            self.add("Python", "OK", f"{v.major}.{v.minor}.{v.micro}")
        else:
            self.add("Python", "FAIL", f"{v.major}.{v.minor}.{v.micro} — need >= 3.10", fixable=True, fix="Install Python 3.10+")

    def check_config(self):
        if self._config and self._config.is_configured:
            url = self._config.api_url or "not set"
            self.add("Configuration", "OK", f"API: {url}")
        else:
            self.add("Configuration", "WARN", "Not configured. Run `deltacode auth login`", fixable=True, fix="deltacode auth login ...")

    def check_api_connection(self):
        if not self._config or not self._config.is_configured:
            self.add("DeltaAI API", "SKIP", "Not configured")
            return
        try:
            client = DeltaAIClient(self._config)
            result = client.health_check()
            client.close()
            if result:
                self.add("DeltaAI API", "OK", f"Connected ({self._config.api_url})")
            else:
                self.add("DeltaAI API", "FAIL", f"Could not reach {self._config.api_url}")
        except Exception as e:
            self.add("DeltaAI API", "FAIL", str(e)[:80])

    def check_license(self):
        if not self._config or not self._config.is_configured:
            self.add("License", "SKIP", "Not configured")
            return
        info = validate_license(self._config)
        if info.valid:
            self.add("License", "OK", f"{info.tier} — expires {info.expires_at}")
        else:
            self.add("License", "FAIL", info.error or "Invalid license", fixable=True, fix="Contact DeltaAI support")

    def check_docker(self):
        try:
            result = subprocess.run(["docker", "--version"], capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                version = result.stdout.strip()[:30]
                self.add("Docker", "OK", version)
            else:
                self.add("Docker", "WARN", "Not available (optional)", fixable=True, fix="Install Docker Desktop")
        except FileNotFoundError:
            self.add("Docker", "WARN", "Not installed (optional)", fixable=True, fix="Install Docker Desktop")
        except subprocess.TimeoutExpired:
            self.add("Docker", "WARN", "Daemon not responding (optional)")

    def check_git(self):
        try:
            result = subprocess.run(["git", "--version"], capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                self.add("Git", "OK", result.stdout.strip()[:30])
            else:
                self.add("Git", "WARN", "Not available (optional)")
        except FileNotFoundError:
            self.add("Git", "WARN", "Not installed (optional)", fixable=True, fix="Install git")

    def check_tools(self):
        tools = {
            "bandit": "bandit --version",
            "semgrep": "semgrep --version",
        }
        for name, cmd in tools.items():
            try:
                result = subprocess.run(cmd.split(), capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    self.add(name.capitalize(), "OK", result.stdout.strip()[:30])
                else:
                    self.add(name.capitalize(), "WARN", "Not available (optional)", fixable=True, fix=f"pip install {name}")
            except FileNotFoundError:
                self.add(name.capitalize(), "WARN", "Not installed (optional)", fixable=True, fix=f"pip install {name}")

    def check_optional_deps(self):
        checks = {
            "Playwright": ("playwright", "playwright install chromium"),
            "ChromaDB": ("chromadb", "pip install chromadb"),
            "msgpack": ("msgpack", "pip install msgpack"),
        }
        for name, (module, fix_cmd) in checks.items():
            try:
                __import__(module)
                self.add(name, "OK", "Installed")
            except ImportError:
                self.add(name, "WARN", f"Not installed (optional)", fixable=True, fix=fix_cmd)

    def check_disk_space(self):
        try:
            data_path = DATA_DIR
            if data_path.exists():
                total = sum(f.stat().st_size for f in data_path.rglob("*") if f.is_file())
                mb = total / (1024 * 1024)
                self.add("Disk Space", "OK", f"{mb:.1f} MB used")
            else:
                self.add("Disk Space", "OK", "Empty")
        except Exception:
            self.add("Disk Space", "OK", "Could not check")

    def format_report(self, fixable_only: bool = False) -> str:
        results = [r for r in self._results if not fixable_only or (r.fixable and r.status != "OK")]
        if not results:
            return "All checks passed."

        parts = []
        for r in results:
            icon = {"OK": "✅", "WARN": "⚠️ ", "FAIL": "🔴", "SKIP": "⏭"}.get(r.status, "❓")
            parts.append(f"  {icon} {r.component}: {r.status}")
            parts.append(f"     {r.detail}")
            if r.fixable and r.fix_command:
                parts.append(f"     Fix: {r.fix_command}")
        return "\n".join(parts)

    def get_json(self) -> list[dict]:
        return [{"component": r.component, "status": r.status, "detail": r.detail} for r in self._results]


def run_diagnostics() -> list[DiagnosticResult]:
    d = Diagnostics()
    return d.run_all()


def run_diagnostics_and_fix() -> dict:
    d = Diagnostics()
    results = d.run_all()
    fixes = []
    for r in results:
        if r.fixable and r.status != "OK" and r.fix_command and r.fix_command.startswith("pip"):
            try:
                subprocess.run(r.fix_command.split(), capture_output=True, text=True, timeout=120)
                fixes.append({"component": r.component, "action": r.fix_command, "result": "attempted"})
            except Exception as e:
                fixes.append({"component": r.component, "action": r.fix_command, "result": f"failed: {e}"})
    return {"results": [{"component": r.component, "status": r.status} for r in results], "fixes": fixes}