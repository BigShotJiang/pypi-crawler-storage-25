"""Disk-based caching layer for DeltaCode CLI.

Uses diskcache.Cache for persistent, TTL-based caching of:
- Workspace security context scans
- Semantic search indexes  
- Dependency analysis results
- CWE database lookups
- External API responses (NVD, MITRE ATT&CK, CAPEC)

All caches are stored under DATA_DIR / "cache" with namespaced directories.
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Callable, Optional

from diskcache import Cache

from deltacode.core.config import DATA_DIR
from deltacode.core.logger import get_logger

logger = get_logger(__name__)

CACHE_ROOT = DATA_DIR / "cache"
DEFAULT_TTL = 3600  # 1 hour
LONG_TTL = 86400  # 24 hours
VERY_LONG_TTL = 604800  # 7 days


def _make_key(prefix: str, *parts: str) -> str:
    key_parts = [prefix]
    for p in parts:
        if isinstance(p, str):
            key_parts.append(p.lower().strip())
        else:
            key_parts.append(str(p))
    return ":".join(key_parts)


def _content_hash(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]


class DeltaCache:
    _instances: dict[str, "Cache"] = {}

    @classmethod
    def _get_cache(cls, namespace: str) -> Cache:
        if namespace not in cls._instances:
            CACHE_ROOT.mkdir(parents=True, exist_ok=True)
            cache_path = CACHE_ROOT / namespace
            cache_path.mkdir(parents=True, exist_ok=True)
            cls._instances[namespace] = Cache(str(cache_path))
        return cls._instances[namespace]

    @classmethod
    def get(cls, namespace: str, key: str) -> Optional[Any]:
        try:
            cache = cls._get_cache(namespace)
            value = cache.get(key, default=None)
            if value is not None:
                return value
            return None
        except Exception:
            return None

    @classmethod
    def set(cls, namespace: str, key: str, value: Any, ttl: int = DEFAULT_TTL):
        try:
            cache = cls._get_cache(namespace)
            cache.set(key, value, expire=ttl)
        except Exception as e:
            pass

    @classmethod
    def delete(cls, namespace: str, key: str) -> bool:
        try:
            cache = cls._get_cache(namespace)
            return bool(cache.delete(key))
        except Exception:
            return False

    @classmethod
    def clear(cls, namespace: str = None):
        if namespace:
            try:
                cache = cls._get_cache(namespace)
                cache.clear()
            except Exception:
                pass
            if namespace in cls._instances:
                cls._instances[namespace].close()
                del cls._instances[namespace]
        else:
            for ns in list(cls._instances.keys()):
                cls.clear(ns)

    @classmethod
    def get_or_compute(cls, namespace: str, key: str, compute: Callable, ttl: int = DEFAULT_TTL) -> Any:
        cached = cls.get(namespace, key)
        if cached is not None:
            return cached
        value = compute()
        cls.set(namespace, key, value, ttl=ttl)
        return value

    @classmethod
    def stats(cls, namespace: str = None) -> dict:
        if not CACHE_ROOT.exists():
            return {"error": "cache directory does not exist", "namespace": namespace or "all"}

        if namespace:
            try:
                cache = cls._get_cache(namespace)
                stats = cache.volume()
                return {
                    "namespace": namespace,
                    "size_bytes": stats,
                    "size_mb": round(stats / (1024 * 1024), 2) if stats else 0,
                }
            except Exception:
                return {"namespace": namespace, "error": "failed"}
        else:
            all_stats = {}
            if CACHE_ROOT.exists():
                for ns_dir in CACHE_ROOT.iterdir():
                    if ns_dir.is_dir():
                        all_stats[ns_dir.name] = cls.stats(ns_dir.name)
            return all_stats


class WorkspaceScanCache:
    NAMESPACE = "workspace_scan"

    @classmethod
    def get_scan(cls, root_path: str, content_hash: str) -> Optional[dict]:
        key = _make_key("scan", root_path, content_hash)
        return DeltaCache.get(cls.NAMESPACE, key)

    @classmethod
    def set_scan(cls, root_path: str, content_hash: str, result: dict, ttl: int = VERY_LONG_TTL):
        key = _make_key("scan", root_path, content_hash)
        DeltaCache.set(cls.NAMESPACE, key, result, ttl=ttl)

    @classmethod
    def invalidate_scan(cls, root_path: str):
        try:
            cache = DeltaCache._get_cache(cls.NAMESPACE)
            prefix = _make_key("scan", root_path, "")
            for key in list(cache.iterkeys()):
                if key.startswith(prefix):
                    cache.delete(key)
        except Exception:
            pass


class DependencyCache:
    NAMESPACE = "dependency_scan"

    @classmethod
    def get(cls, root_path: str, file_hashes: str) -> Optional[list]:
        key = _make_key("deps", root_path, file_hashes)
        return DeltaCache.get(cls.NAMESPACE, key)

    @classmethod
    def set(cls, root_path: str, file_hashes: str, result: list, ttl: int = LONG_TTL):
        key = _make_key("deps", root_path, file_hashes)
        DeltaCache.set(cls.NAMESPACE, key, result, ttl=ttl)


class CWECache:
    NAMESPACE = "cwe"

    @classmethod
    def get_cwe(cls, cwe_id: str) -> Optional[dict]:
        return DeltaCache.get(cls.NAMESPACE, cwe_id.upper())

    @classmethod
    def set_cwe(cls, cwe_id: str, data: dict, ttl: int = VERY_LONG_TTL):
        DeltaCache.set(cls.NAMESPACE, cwe_id.upper(), data, ttl=ttl)


class SearchResultCache:
    NAMESPACE = "search"

    @classmethod
    def get(cls, query: str, directory: str, n_results: int) -> Optional[list]:
        key = _make_key("search", query, directory, str(n_results))
        return DeltaCache.get(cls.NAMESPACE, key)

    @classmethod
    def set(cls, query: str, directory: str, n_results: int, results: list, ttl: int = LONG_TTL):
        key = _make_key("search", query, directory, str(n_results))
        DeltaCache.set(cls.NAMESPACE, key, results, ttl=ttl)


class APICache:
    NAMESPACE = "api_responses"

    @classmethod
    def get(cls, endpoint: str, params: dict) -> Optional[dict]:
        param_str = json.dumps(params, sort_keys=True)
        key = _make_key(endpoint, _content_hash(param_str))
        return DeltaCache.get(cls.NAMESPACE, key)

    @classmethod
    def set(cls, endpoint: str, params: dict, response: dict, ttl: int = LONG_TTL):
        param_str = json.dumps(params, sort_keys=True)
        key = _make_key(endpoint, _content_hash(param_str))
        DeltaCache.set(cls.NAMESPACE, key, response, ttl=ttl)


class DeltaCacheManager:
    @staticmethod
    def clear_all():
        DeltaCache.clear()

    @staticmethod
    def get_stats() -> dict:
        return DeltaCache.stats()

    @staticmethod
    def prune_expired():
        if not CACHE_ROOT.exists():
            return
        for ns_dir in CACHE_ROOT.iterdir():
            if ns_dir.is_dir():
                try:
                    cache = Cache(str(ns_dir))
                    cache.cull()
                    cache.close()
                except Exception:
                    pass

    @staticmethod
    def size_mb() -> float:
        if not CACHE_ROOT.exists():
            return 0.0
        total = 0
        for ns_dir in CACHE_ROOT.iterdir():
            if ns_dir.is_dir():
                try:
                    cache = Cache(str(ns_dir))
                    total += cache.volume() or 0
                    cache.close()
                except Exception:
                    pass
        return round(total / (1024 * 1024), 2)