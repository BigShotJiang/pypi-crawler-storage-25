"""Attack path modeling and exploit chain detection for DeltaCode CLI.

Models attack paths through the codebase:
- Entry points (exposed APIs, auth points)
- Attack steps (vulnerabilities chained together)
- Path scoring (likelihood × impact)
- Exploit chain detection (requires A → requires B → requires C)
- Mitigation points identification
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class AttackStep:
    step_id: str
    name: str
    cwe: str
    description: str
    severity: str
    likelihood: float
    impact: float
    prerequisites: list = field(default_factory=list)
    mitigations: list = field(default_factory=list)
    score: float = 0.0

    def calc_score(self):
        self.score = round(self.likelihood * self.impact, 1)


@dataclass
class AttackPath:
    entry_point: str
    steps: list = field(default_factory=list)
    total_score: float = 0.0
    risk_level: str = "LOW"
    mitigations: list = field(default_factory=list)


COMMON_ATTACK_PATTERNS = [
    AttackStep(
        step_id="A1", name="SQL Injection", cwe="CWE-89",
        description="Inject SQL through input parameters",
        severity="CRITICAL", likelihood=0.8, impact=9.0,
        prerequisites=["input_reachable"],
        mitigations=["parameterized_queries", "input_validation"],
    ),
    AttackStep(
        step_id="A2", name="Authentication Bypass", cwe="CWE-287",
        description="Bypass authentication controls",
        severity="CRITICAL", likelihood=0.6, impact=9.0,
        prerequisites=["input_reachable"],
        mitigations=["strong_auth", "mfa"],
    ),
    AttackStep(
        step_id="A3", name="Command Injection", cwe="CWE-78",
        description="Execute OS commands through application",
        severity="CRITICAL", likelihood=0.5, impact=9.0,
        prerequisites=["input_reachable", "shell_access"],
        mitigations=["avoid_shell", "input_validation"],
    ),
    AttackStep(
        step_id="A4", name="XSS", cwe="CWE-79",
        description="Cross-site scripting via user input",
        severity="HIGH", likelihood=0.7, impact=7.0,
        prerequisites=["input_reachable", "no_sanitization"],
        mitigations=["output_encoding", "csp"],
    ),
    AttackStep(
        step_id="A5", name="Sensitive Data Exposure", cwe="CWE-200",
        description="Expose sensitive information in responses",
        severity="HIGH", likelihood=0.6, impact=7.0,
        prerequisites=["data_reachable"],
        mitigations=["encryption", "access_control"],
    ),
    AttackStep(
        step_id="A6", name="Privilege Escalation", cwe="CWE-269",
        description="Escalate privileges to gain unauthorized access",
        severity="HIGH", likelihood=0.4, impact=8.0,
        prerequisites=["authentication_present", "weak_authorization"],
        mitigations=["rbac", "authorization_checks"],
    ),
    AttackStep(
        step_id="A7", name="SSRF", cwe="CWE-918",
        description="Server-side request forgery to access internal resources",
        severity="HIGH", likelihood=0.4, impact=7.0,
        prerequisites=["input_reachable", "network_access"],
        mitigations=["url_validation", "network_isolation"],
    ),
    AttackStep(
        step_id="A8", name="Insecure Deserialization", cwe="CWE-502",
        description="Deserialize untrusted data for RCE",
        severity="CRITICAL", likelihood=0.3, impact=9.0,
        prerequisites=["pickle_load", "untrusted_input"],
        mitigations=["avoid_pickle", "signing"],
    ),
]

ENTRY_POINT_INDICATORS = [
    r"@app\.route", r"@router\.", r"def (get|post|put|delete)\(", r"APIView",
    r"urlpatterns", r"path\(", r"re_path\(", r"add_resource",
    r"endpoint", r"route", r"Blueprint",
]


class AttackPathModeler:
    def __init__(self, root_path: str = "."):
        self.root_path = Path(root_path).resolve()
        self._patterns = {s.cwe: s for s in COMMON_ATTACK_PATTERNS}
        self._steps = [s for s in COMMON_ATTACK_PATTERNS]

    def analyze(self, findings: list[dict], files: list[str] = None) -> list[AttackPath]:
        if files is None:
            files = [str(f) for f in self.root_path.rglob("*.py") if f.is_file()]

        entry_points = self._find_entry_points(files)
        cwes_found = set()
        for f in findings:
            cwe = f.get("cwe", f.get("cwe_id", ""))
            if cwe:
                cwes_found.add(cwe)

        paths = []
        for ep in entry_points[:5]:
            path_steps = []
            for step in self._steps:
                if step.cwe in cwes_found or any(
                    cwe in step.cwe for cwe in cwes_found
                ):
                    step.calc_score()
                    path_steps.append(step)

            if path_steps:
                total = sum(s.score for s in path_steps)
                level = "CRITICAL" if total >= 15 else "HIGH" if total >= 10 else "MEDIUM"
                mitigations = list(set(m for s in path_steps for m in s.mitigations))
                paths.append(AttackPath(
                    entry_point=ep,
                    steps=path_steps,
                    total_score=round(total, 1),
                    risk_level=level,
                    mitigations=mitigations,
                ))

        return sorted(paths, key=lambda p: p.total_score, reverse=True)

    def _find_entry_points(self, files: list[str]) -> list[str]:
        found = []
        for fpath in files:
            try:
                content = Path(fpath).read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            rel = Path(fpath).relative_to(self.root_path) if self.root_path in Path(fpath).parents else fpath
            patterns_found = []
            for pattern in ENTRY_POINT_INDICATORS:
                matches = re.findall(pattern, content)
                if matches:
                    patterns_found.extend(matches)
            if patterns_found:
                found.append(f"{rel} ({', '.join(patterns_found[:3])})")

        return found[:10]

    def format_report(self, paths: list[AttackPath]) -> str:
        if not paths:
            return "No attack paths identified."

        parts = ["# Attack Path Modeling\n"]
        parts.append(f"Total attack paths identified: {len(paths)}\n")

        for i, path in enumerate(paths, 1):
            icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🟢"}.get(path.risk_level, "⚪")
            parts.append(f"## Path {i}: {icon} {path.risk_level} ({path.total_score}/100)")
            parts.append(f"Entry: {path.entry_point}")
            parts.append("")

            for step in path.steps:
                parts.append(f"  {step.step_id}: {step.name} ({step.cwe}) [{step.severity}]")
                if step.prerequisites:
                    parts.append(f"     Requires: {', '.join(step.prerequisites)}")
                parts.append("")

            if path.mitigations:
                parts.append(f"  Recommended Mitigations:")
                for m in path.mitigations[:5]:
                    parts.append(f"    - {m}")
            parts.append("")

        critical = sum(1 for p in paths if p.risk_level == "CRITICAL")
        high = sum(1 for p in paths if p.risk_level == "HIGH")
        parts.append("## Summary")
        parts.append(f"CRITICAL: {critical} | HIGH: {high} | Total: {len(paths)}")

        return "\n".join(parts)

    @staticmethod
    def get_chain_description(path: AttackPath) -> str:
        steps_desc = " → ".join(s.cwe for s in path.steps)
        return f"[{path.risk_level}] {path.entry_point}: {steps_desc} ({path.total_score}/100)"

    def get_mitigation_plan(self, path: AttackPath) -> list[str]:
        return list(set(m for s in path.steps for m in s.mitigations))