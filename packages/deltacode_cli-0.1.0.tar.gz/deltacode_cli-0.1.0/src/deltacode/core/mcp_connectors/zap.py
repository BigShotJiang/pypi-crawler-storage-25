"""OWASP ZAP MCP connector.

Tools:
  - start_zap_scan: start an automated scan on a target URL
  - get_zap_alerts: retrieve ZAP scan alerts
  - get_zap_status: check active scan progress
  - zap_passive_scan: perform passive scan only
  - get_zap_context: get ZAP context information
"""

from __future__ import annotations

import time
from typing import Optional

import httpx

from deltacode.core.mcp_server import (
    MCPConnector, MCPConnectorInfo, MCPResponse, MCPTool, MCPToolDef,
)
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


ZAP_API_BASE = "http://127.0.0.1:8080"
ZAP_API_KEY = ""


class StartZAPScan(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="start_zap_scan",
            description="Start an automated ZAP scan on a target URL (spider + active scan)",
            category="zap",
            input_schema={
                "type": "object",
                "properties": {
                    "url": {"type": "string", "description": "Target URL to scan (e.g. 'http://localhost:8081')"},
                    "recurse": {"type": "boolean", "description": "Recursively spider", "default": True},
                    "max_children": {"type": "integer", "description": "Max children to spider", "default": 50},
                    "scan_policy_name": {"type": "string", "description": "Scan policy to use", "default": ""},
                },
                "required": ["url"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        url = params.get("url", "")
        if not url:
            return MCPResponse(id="", success=False, error="URL is required")

        try:
            base = ZAP_API_BASE
            api_key_param = f"apikey={ZAP_API_KEY}&" if ZAP_API_KEY else ""

            with httpx.Client(base_url=base, timeout=120) as client:
                access_check = client.get(f"/JSON/core/view/version/?{api_key_param}formMethod=GET")
                if access_check.status_code != 200:
                    return MCPResponse(id="", success=False, data={
                        "error": "ZAP API unavailable",
                        "howto": "1. Start ZAP 2. Tools > Options > API > Enable UI/API 3. Set port 8080"
                    })

                spider_resp = client.get(
                    f"/JSON/spider/action/scan/?{api_key_param}url={httpx.utils.quote(url, safe='')}"
                    f"&maxChildren={params.get('max_children', 50)}"
                    f"&recurse={str(params.get('recurse', True)).lower()}",
                )
                spider_resp.raise_for_status()
                spider_scan_id = spider_resp.json().get("scan", "")

                spider_complete = False
                for _ in range(60):
                    status_resp = client.get(
                        f"/JSON/spider/view/status/?{api_key_param}scanId={spider_scan_id}"
                    )
                    status = status_resp.json().get("status", "0")
                    if status == "100":
                        spider_complete = True
                        break
                    time.sleep(2)

                if not spider_complete:
                    return MCPResponse(id="", success=True, data={
                        "status": "spider_in_progress",
                        "spider_scan_id": spider_scan_id,
                        "message": "Spider still running, active scan will start when complete"
                    })

                ascan_resp = client.get(
                    f"/JSON/ascanner/action/scan/?{api_key_param}url={httpx.utils.quote(url, safe='')}"
                    f"&recurse={str(params.get('recurse', True)).lower()}",
                )
                ascan_resp.raise_for_status()
                active_scan_id = ascan_resp.json().get("scan", "")

                return MCPResponse(
                    id="", success=True,
                    data={
                        "status": "scan_started",
                        "url": url,
                        "spider_scan_id": spider_scan_id,
                        "active_scan_id": active_scan_id,
                    },
                    mime_type="application/json",
                )

        except httpx.ConnectError:
            return MCPResponse(id="", success=False, data={
                "error": "ZAP API not available",
                "howto": "Install ZAP: https://www.zaproxy.org/download/  Start it, then enable API on port 8080"
            })
        except Exception as e:
            return MCPResponse(id="", success=False, error=f"ZAP scan failed: {e}")


class GetZAPAlerts(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_zap_alerts",
            description="Get alerts from ZAP scans, filterable by risk level",
            category="zap",
            input_schema={
                "type": "object",
                "properties": {
                    "risk_level": {
                        "type": "string",
                        "enum": ["all", "high", "medium", "low", "info"],
                        "description": "Filter by risk level",
                        "default": "all"
                    },
                    "max_results": {"type": "integer", "default": 100},
                    "base_url": {"type": "string", "description": "Filter alerts by base URL"},
                },
                "required": [],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        try:
            risk_map = {"high": 3, "medium": 2, "low": 1, "info": 0}
            risk_filter = risk_map.get(params.get("risk_level", "all").lower(), None)

            base = ZAP_API_BASE
            api_key_param = f"apikey={ZAP_API_KEY}&" if ZAP_API_KEY else ""

            with httpx.Client(base_url=base, timeout=30) as client:
                resp = client.get(f"/JSON/core/view/alerts/?{api_key_param}formMethod=GET")
                resp.raise_for_status()
                alerts = resp.json().get("alerts", [])

            base_url = params.get("base_url", "")
            max_results = params.get("max_results", 100)

            filtered = []
            for alert in alerts:
                url = alert.get("url", "")
                if base_url and base_url not in url:
                    continue
                risk_id = alert.get("riskId", 1)
                if risk_filter is not None and risk_id != risk_filter:
                    continue
                filtered.append({
                    "url": url,
                    "method": alert.get("method", ""),
                    "param": alert.get("param", ""),
                    "alert": alert.get("alert", ""),
                    "description": alert.get("description", "")[:200],
                    "solution": alert.get("solution", "")[:200],
                    "risk": alert.get("risk", ""),
                    "confidence": alert.get("confidence", ""),
                    "cwe_id": alert.get("cweid", ""),
                    "wasc_id": alert.get("wascid", ""),
                    "evidence": alert.get("evidence", ""),
                })

            return MCPResponse(
                id="", success=True,
                data={
                    "total": len(filtered),
                    "alerts": filtered[:max_results],
                    "summary": {
                        "high": sum(1 for a in filtered if a["risk"] == "High"),
                        "medium": sum(1 for a in filtered if a["risk"] == "Medium"),
                        "low": sum(1 for a in filtered if a["risk"] == "Low"),
                        "info": sum(1 for a in filtered if a["risk"] == "Information"),
                    },
                },
                mime_type="application/json",
            )

        except httpx.ConnectError:
            return MCPResponse(id="", success=False, data={"error": "ZAP API not available"})
        except Exception as e:
            return MCPResponse(id="", success=False, error=f"Get alerts failed: {e}")


class GetZAPStatus(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_zap_status",
            description="Get ZAP scan status and progress",
            category="zap",
            input_schema={
                "type": "object",
                "properties": {
                    "scan_id": {"type": "string", "description": "Active scan ID to check"},
                    "scan_type": {
                        "type": "string",
                        "enum": ["active", "spider"],
                        "default": "active"
                    },
                },
                "required": [],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        scan_id = params.get("scan_id", "0")
        scan_type = params.get("scan_type", "active")

        try:
            api_key_param = f"apikey={ZAP_API_KEY}&" if ZAP_API_KEY else ""
            endpoint = f"/JSON/{scan_type}/view/status/" if scan_type == "spider" else f"/JSON/ascanner/view/status/"
            url = f"{ZAP_API_BASE}{endpoint}?{api_key_param}scanId={scan_id}"

            resp = httpx.get(url, timeout=30)
            resp.raise_for_status()
            status = resp.json().get("status", "0")

            return MCPResponse(
                id="", success=True,
                data={
                    "scan_id": scan_id,
                    "scan_type": scan_type,
                    "progress": f"{status}%",
                    "complete": status == "100",
                },
                mime_type="application/json",
            )

        except httpx.ConnectError:
            return MCPResponse(id="", success=False, data={"error": "ZAP API not available"})
        except Exception as e:
            return MCPResponse(id="", success=False, error=f"Status check failed: {e}")


class ZAPPassiveScan(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="zap_passive_scan",
            description="Perform passive scanning only (no active exploits) on a URL",
            category="zap",
            input_schema={
                "type": "object",
                "properties": {
                    "url": {"type": "string", "description": "URL to passively scan"},
                },
                "required": ["url"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        url = params.get("url", "")

        try:
            api_key_param = f"apikey={ZAP_API_KEY}&" if ZAP_API_KEY else ""
            resp = httpx.get(
                f"{ZAP_API_BASE}/JSON/spider/action/scan/?{api_key_param}"
                f"url={httpx.utils.quote(url, safe='')}&maxChildren=10&recurse=false",
                timeout=120,
            )
            resp.raise_for_status()

            return MCPResponse(
                id="", success=True,
                data={
                    "status": "passive_scan_started",
                    "url": url,
                    "note": "Passive scan captures traffic and alerts without sending attack payloads."
                },
                mime_type="application/json",
            )

        except httpx.ConnectError:
            return MCPResponse(id="", success=False, data={"error": "ZAP API not available"})


class ZAPConnector(MCPConnector):
    def get_info(self) -> MCPConnectorInfo:
        return MCPConnectorInfo(
            name="zap",
            description="OWASP ZAP web application security scanner integration",
            version="1.0.0",
        )

    def _register_tools(self):
        self._tools = {
            "start_zap_scan": StartZAPScan(),
            "get_zap_alerts": GetZAPAlerts(),
            "get_zap_status": GetZAPStatus(),
            "zap_passive_scan": ZAPPassiveScan(),
        }