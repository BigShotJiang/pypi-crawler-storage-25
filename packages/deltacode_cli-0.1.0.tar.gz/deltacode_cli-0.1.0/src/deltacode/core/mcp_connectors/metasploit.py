"""Metasploit Framework MCP connector.

Tools:
  - search_modules: search Metasploit modules by keyword and type
  - get_module_info: get detailed information about a specific module
  - list_exploits: list available exploit modules by category
  - get_session_info: query active msfrpc sessions
  - check_target: check if a target is likely vulnerable (module + version match)

NOTE: Requires msfrpc daemon running on localhost:55553 (default).
Only available for licensed enterprise organizations.
"""

from __future__ import annotations

import json
from typing import Optional

from deltacode.core.mcp_server import (
    MCPConnector, MCPConnectorInfo, MCPResponse, MCPTool, MCPToolDef,
)
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


MSFRPC_HOST = "127.0.0.1"
MSFRPC_PORT = 55553
MSFRPC_TOKEN = ""


def _try_msfrpc(method: str, params: list = None) -> dict:
    try:
        import msgpack
        import socket

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        sock.connect((MSFRPC_HOST, MSFRPC_PORT))

        if not MSFRPC_TOKEN:
            auth_req = msgpack.packb({"method": "auth.login", "params": ["msf", "msf"], "id": 1})
            sock.send(auth_req)
            resp = msgpack.unpackb(sock.recv(4096))
            token = resp.get("result", "")
        else:
            token = MSFRPC_TOKEN

        req = msgpack.packb({"method": method, "params": params or [], "id": 1, "token": token})
        sock.send(req)
        resp = msgpack.unpackb(sock.recv(65536))
        sock.close()
        return {"success": True, "data": resp}
    except ImportError:
        return {"success": False, "error": "msgpack library not installed (pip install msgpack)"}
    except ConnectionRefusedError:
        return {"success": False, "error": "msfrpc not available on localhost:55553. Start msfrpcd first."}
    except Exception as e:
        return {"success": False, "error": str(e)}


METASPLOIT_MODULES_DB = {
    "exploit": [
        {"fullname": "exploit/multi/http/struts2_content_type_ognl", "name": "Apache Struts2 OGNL Injection", "rank": "excellent", "cve": "CVE-2017-5638"},
        {"fullname": "exploit/multi/script/web_delivery", "name": "Web Delivery Script", "rank": "excellent", "cve": ""},
        {"fullname": "exploit/multi/http/tomcat_mgr_upload", "name": "Tomcat Manager Upload", "rank": "excellent", "cve": "CVE-2017-12617"},
        {"fullname": "exploit/multi/http/jenkins_script_console", "name": "Jenkins Script Console", "rank": "manual", "cve": ""},
        {"fullname": "exploit/unix/webapp/wp_admin_shell_upload", "name": "WordPress Admin Shell Upload", "rank": "excellent", "cve": ""},
    ],
    "auxiliary": [
        {"fullname": "auxiliary/scanner/portscan/tcp", "name": "TCP Port Scanner", "rank": "normal", "cve": ""},
        {"fullname": "auxiliary/scanner/http/sql_injection", "name": "SQL Injection Scanner", "rank": "normal", "cve": ""},
        {"fullname": "auxiliary/scanner/ssh/ssh_login", "name": "SSH Login Check", "rank": "normal", "cve": ""},
    ],
    "post": [
        {"fullname": "post/multi/gather/credentials", "name": "Multi Credentials Gather", "rank": "manual", "cve": ""},
    ],
}


class SearchMetasploitModules(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="search_modules",
            description="Search Metasploit modules by keyword and module type",
            category="metasploit",
            input_schema={
                "type": "object",
                "properties": {
                    "keyword": {"type": "string", "description": "Search keyword (e.g. 'struts', 'tomcat', 'wordpress')"},
                    "module_type": {"type": "string", "enum": ["exploit", "auxiliary", "post", "payload"], "default": "exploit"},
                    "max_results": {"type": "integer", "default": 20},
                },
                "required": ["keyword"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        keyword = params.get("keyword", "").lower()
        module_type = params.get("module_type", "exploit")
        max_results = params.get("max_results", 20)

        api_result = _try_msfrpc("module.search", [keyword])
        if api_result.get("success"):
            modules = api_result.get("data", {}).get("data", [])
            return MCPResponse(id="", success=True, data={
                "total": len(modules), "results": modules[:max_results],
            }, mime_type="application/json")

        modules = METASPLOIT_MODULES_DB.get(module_type, [])
        results = [m for m in modules if keyword in m["name"].lower() or keyword in m["fullname"].lower()]
        return MCPResponse(id="", success=True, data={
            "total": len(results), "results": results[:max_results],
            "note": "msfrpc unavailable — using local module database",
        }, mime_type="application/json")


class GetModuleInfo(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_module_info",
            description="Get detailed information about a specific Metasploit module",
            category="metasploit",
            input_schema={
                "type": "object",
                "properties": {
                    "module_path": {"type": "string", "description": "Full module path (e.g. 'exploit/multi/http/struts2_content_type_ognl')"},
                },
                "required": ["module_path"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        module_path = params.get("module_path", "")

        api_result = _try_msfrpc("module.info", [module_path])
        if api_result.get("success"):
            return MCPResponse(id="", success=True, data={"module_path": module_path, "info": api_result.get("data", {})}, mime_type="application/json")

        for type_key, mods in METASPLOIT_MODULES_DB.items():
            for m in mods:
                if m["fullname"] == module_path:
                    return MCPResponse(id="", success=True, data={
                        "module_path": module_path,
                        "name": m["name"],
                        "type": type_key,
                        "rank": m["rank"],
                        "cve": m["cve"],
                        "note": "msfrpc unavailable — limited local data",
                    }, mime_type="application/json")

        return MCPResponse(id="", success=False, error=f"Module '{module_path}' not found")


class ListExploits(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="list_exploits",
            description="List available Metasploit exploit modules by category or CVE",
            category="metasploit",
            input_schema={
                "type": "object",
                "properties": {
                    "cve_id": {"type": "string", "description": "Filter by CVE ID"},
                    "rank": {"type": "string", "enum": ["excellent", "great", "good", "normal", "manual"], "default": ""},
                    "max_results": {"type": "integer", "default": 20},
                },
                "required": [],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        cve_id = params.get("cve_id", "").upper()
        rank = params.get("rank", "").lower()
        max_results = params.get("max_results", 20)

        results = METASPLOIT_MODULES_DB.get("exploit", [])
        if cve_id:
            results = [m for m in results if cve_id in m.get("cve", "").upper()]
        if rank:
            results = [m for m in results if m.get("rank", "").lower() == rank]

        return MCPResponse(id="", success=True, data={
            "total": len(results), "results": results[:max_results],
        }, mime_type="application/json")


class GetSessionInfo(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_session_info",
            description="Query active Metasploit sessions (requires msfrpc)",
            category="metasploit",
            input_schema={
                "type": "object",
                "properties": {},
                "required": [],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        api_result = _try_msfrpc("session.list", [])
        if api_result.get("success"):
            sessions = api_result.get("data", {})
            return MCPResponse(id="", success=True, data={
                "active_sessions": len(sessions), "sessions": sessions,
            }, mime_type="application/json")

        return MCPResponse(id="", success=False, error="msfrpc not available — cannot query sessions")


class CheckTarget(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="check_target",
            description="Check if a software/version combination has known Metasploit modules (safe lookup only)",
            category="metasploit",
            input_schema={
                "type": "object",
                "properties": {
                    "software": {"type": "string", "description": "Software name (e.g. 'apache struts', 'wordpress', 'tomcat')"},
                    "version": {"type": "string", "description": "Software version"},
                },
                "required": ["software"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        software = params.get("software", "").lower()
        version = params.get("version", "")

        matches = []
        for type_key, mods in METASPLOIT_MODULES_DB.items():
            for m in mods:
                if software in m["name"].lower() or software in m["fullname"].lower():
                    matches.append({
                        "module": m["fullname"],
                        "name": m["name"],
                        "type": type_key,
                        "rank": m["rank"],
                        "cve": m["cve"],
                    })

        return MCPResponse(id="", success=True, data={
            "software": software,
            "version": version,
            "matching_modules": len(matches),
            "exploits": matches,
            "note": "msfrpc unavailable — using local module database. Install msgpack + start msfrpcd for live queries.",
        }, mime_type="application/json")


class MetasploitConnector(MCPConnector):
    def get_info(self) -> MCPConnectorInfo:
        return MCPConnectorInfo(
            name="metasploit",
            description="Metasploit Framework integration for exploit research and session management (enterprise only)",
            version="1.0.0",
        )

    def _register_tools(self):
        self._tools = {
            "search_modules": SearchMetasploitModules(),
            "get_module_info": GetModuleInfo(),
            "list_exploits": ListExploits(),
            "get_session_info": GetSessionInfo(),
            "check_target": CheckTarget(),
        }