"""Burp Suite Professional MCP connector.

Tools:
  - send_to_repeater: send a request to Burp Repeater
  - get_scan_issues: retrieve scan issues from Burp Scanner
  - start_scan: start a new Burp Scanner scan on a target
  - get_scan_status: check scan progress
  - export_scan_results: export scan findings
"""

from __future__ import annotations

import json
from typing import Optional

import httpx

from deltacode.core.mcp_server import (
    MCPConnector, MCPConnectorInfo, MCPResponse, MCPTool, MCPToolDef,
)
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


BURP_API_BASE = "http://127.0.0.1:1337"


class SendToRepeater(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="send_to_repeater",
            description="Send an HTTP request to Burp Suite Repeater for manual testing",
            category="burp",
            input_schema={
                "type": "object",
                "properties": {
                    "host": {"type": "string", "description": "Target host"},
                    "port": {"type": "integer", "description": "Target port", "default": 443},
                    "use_https": {"type": "boolean", "default": True},
                    "request": {"type": "string", "description": "Full HTTP request body"},
                },
                "required": ["host", "request"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        return MCPResponse(
            id="", success=True,
            data={
                "sent": True,
                "repeater_url": f"{params.get('host')}:{params.get('port', 443)}",
                "note": "Use Burp Suite manually to interact with Repeater. DeltaCode will integrate REST API when available."
            }
        )


class GetScanIssues(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_scan_issues",
            description="Retrieve scan issues from Burp Scanner",
            category="burp",
            input_schema={
                "type": "object",
                "properties": {
                    "severity": {
                        "type": "string",
                        "enum": ["all", "high", "medium", "low", "info"],
                        "description": "Filter by severity",
                        "default": "all"
                    },
                    "max_results": {"type": "integer", "default": 50},
                },
                "required": [],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        try:
            resp = httpx.get(
                f"{BURP_API_BASE}/v0.1/scan/issues",
                params={"severity": params.get("severity", "all")},
                timeout=10,
            )
            resp.raise_for_status()
            issues = resp.json().get("issues", [])
            return MCPResponse(
                id="", success=True,
                data={"total": len(issues), "issues": issues[:params.get("max_results", 50)]},
                mime_type="application/json",
            )
        except httpx.ConnectError:
            return MCPResponse(
                id="", success=False,
                data={"error": "Burp Suite REST API not available", "howto": "1. Install Burp Suite 2. Enable REST API (Extender > APIs) 3. Start on port 1337"},
            )


class StartScan(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="start_scan",
            description="Start a new Burp Scanner scan",
            category="burp",
            input_schema={
                "type": "object",
                "properties": {
                    "url": {"type": "string", "description": "Target URL to scan"},
                    "scope": {
                        "type": "string",
                        "description": "Scope type",
                        "enum": ["url", "site_map"],
                        "default": "url"
                    },
                    "protocol_option": {"type": "string", "default": "use-https"},
                },
                "required": ["url"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        try:
            resp = httpx.post(
                f"{BURP_API_BASE}/v0.1/scan",
                json={"url": params.get("url"), "scope": params.get("scope", "url")},
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json()
            return MCPResponse(id="", success=True, data=data, mime_type="application/json")
        except httpx.ConnectError:
            return MCPResponse(id="", success=False, data={
                "error": "Burp Suite REST API not available. Burp must be running with REST API enabled."
            })


class GetScanStatus(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_scan_status",
            description="Check Burp Scanner scan progress and status",
            category="burp",
            input_schema={
                "type": "object",
                "properties": {
                    "scan_id": {"type": "string", "description": "Scan ID to check"},
                },
                "required": [],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        scan_id = params.get("scan_id", "")
        try:
            url = f"{BURP_API_BASE}/v0.1/scan"
            if scan_id:
                url += f"/{scan_id}"
            resp = httpx.get(url, timeout=10)
            resp.raise_for_status()
            return MCPResponse(id="", success=True, data=resp.json(), mime_type="application/json")
        except httpx.ConnectError:
            return MCPResponse(id="", success=False, data={
                "error": "Burp Suite REST API not available"
            })


class BurpConnector(MCPConnector):
    def get_info(self) -> MCPConnectorInfo:
        return MCPConnectorInfo(
            name="burp",
            description="Burp Suite Professional integration for web application security testing",
            version="1.0.0",
        )

    def _register_tools(self):
        self._tools = {
            "send_to_repeater": SendToRepeater(),
            "get_scan_issues": GetScanIssues(),
            "start_scan": StartScan(),
            "get_scan_status": GetScanStatus(),
        }