"""Nessus/OpenVAS MCP connector.

Tools:
  - list_scans: list available scans and their status
  - create_scan: create a new vulnerability scan
  - get_scan_results: get vulnerabilities from a completed scan
  - get_scan_status: check scan progress
  - export_report: export scan results in standard format

NOTE: Requires Nessus Professional or OpenVAS with REST API.
Supports both Nessus (localhost:8834) and OpenVAS (localhost:9392) APIs.
"""

from __future__ import annotations

import json
from typing import Optional

import httpx

from deltacode.core.mcp_server import (
    MCPConnector, MCPConnectorInfo, MCPResponse, MCPTool, MCPToolDef,
)
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


NESSUS_BASE = "https://127.0.0.1:8834"
NESSUS_ACCESS_KEY = ""
NESSUS_SECRET_KEY = ""

OPENVAS_BASE = "http://127.0.0.1:9392"
OPENVAS_USERNAME = "admin"
OPENVAS_PASSWORD = "admin"


SAMPLE_VULNERABILITIES = {
    "apache": [
        {"plugin_id": 12345, "name": "Apache HTTP Server Version", "severity": "MEDIUM", "cvss": 5.0, "description": "Apache version disclosure"},
        {"plugin_id": 67890, "name": "Apache mod_negotiation XSS", "severity": "MEDIUM", "cvss": 6.1, "description": "XSS via mod_negotiation"},
    ],
    "ssh": [
        {"plugin_id": 11111, "name": "SSH Server Key Exchange Algorithm", "severity": "LOW", "cvss": 2.6, "description": "Weak key exchange algorithm"},
    ],
    "default": [
        {"plugin_id": 99999, "name": "SSL/TLS Version Detection", "severity": "MEDIUM", "cvss": 5.0, "description": "SSL/TLS version detected"},
        {"plugin_id": 88888, "name": "TLSv1.0 Protocol Detection", "severity": "MEDIUM", "cvss": 5.0, "description": "Deprecated TLS version detected"},
        {"plugin_id": 77777, "name": "Self-Signed Certificate", "severity": "MEDIUM", "cvss": 4.3, "description": "Self-signed SSL certificate"},
        {"plugin_id": 66666, "name": "OpenSSL CCS Injection", "severity": "HIGH", "cvss": 7.5, "description": "OpenSSL CCS Man-in-the-Middle vulnerability"},
    ],
}


def _try_nessus(method: str, endpoint: str, params: dict = None) -> dict:
    try:
        headers = {"X-ApiKeys": f"accessKey={NESSUS_ACCESS_KEY}; secretKey={NESSUS_SECRET_KEY}"}
        if not NESSUS_ACCESS_KEY:
            return {"success": False, "error": "Nessus API keys not configured"}

        url = f"{NESSUS_BASE}{endpoint}"
        with httpx.Client(verify=False, timeout=30) as client:
            if method == "GET":
                resp = client.get(url, headers=headers)
            elif method == "POST":
                resp = client.post(url, headers=headers, json=params or {})
            elif method == "DELETE":
                resp = client.delete(url, headers=headers)
            else:
                return {"success": False, "error": f"Method {method} not supported"}
            resp.raise_for_status()
            return {"success": True, "data": resp.json()}
    except httpx.ConnectError:
        return {"success": False, "error": "Nessus API not available on localhost:8834"}
    except httpx.HTTPStatusError as e:
        return {"success": False, "error": f"Nessus HTTP error: {e.response.status_code}"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _try_openvas(method: str, endpoint: str, params: dict = None) -> dict:
    try:
        url = f"{OPENVAS_BASE}{endpoint}"
        auth = (OPENVAS_USERNAME, OPENVAS_PASSWORD) if OPENVAS_USERNAME else None
        with httpx.Client(timeout=30) as client:
            if method == "GET":
                resp = client.get(url, auth=auth)
            elif method == "POST":
                resp = client.post(url, auth=auth, json=params or {})
            else:
                return {"success": False, "error": f"Method {method} not supported"}
            resp.raise_for_status()
            return {"success": True, "data": resp.json()}
    except httpx.ConnectError:
        return {"success": False, "error": "OpenVAS API not available on localhost:9392"}
    except Exception as e:
        return {"success": False, "error": str(e)}


class ListScans(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="list_scans",
            description="List available vulnerability scans and their status",
            category="nessus",
            input_schema={
                "type": "object",
                "properties": {
                    "engine": {"type": "string", "enum": ["nessus", "openvas"], "default": "nessus"},
                },
                "required": [],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        engine = params.get("engine", "nessus")
        if engine == "nessus":
            result = _try_nessus("GET", "/scans")
            if result.get("success"):
                scans = result["data"].get("scans", [])
                return MCPResponse(id="", success=True, data={
                    "total": len(scans), "scans": scans,
                }, mime_type="application/json")
            return MCPResponse(id="", success=False, data={
                "error": result.get("error", "Nessus unavailable"),
                "howto": "Start Nessus Professional and configure API keys",
            })
        else:
            result = _try_openvas("GET", "/scans")
            if result.get("success"):
                return MCPResponse(id="", success=True, data=result["data"], mime_type="application/json")
            return MCPResponse(id="", success=False, data={
                "error": result.get("error", "OpenVAS unavailable"),
            })


class CreateScan(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="create_scan",
            description="Create a new vulnerability scan on a target",
            category="nessus",
            input_schema={
                "type": "object",
                "properties": {
                    "target": {"type": "string", "description": "Target IP or hostname"},
                    "name": {"type": "string", "description": "Scan name", "default": ""},
                    "template": {"type": "string", "description": "Scan template", "default": "basic"},
                    "engine": {"type": "string", "enum": ["nessus", "openvas"], "default": "nessus"},
                },
                "required": ["target"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        target = params.get("target", "")
        name = params.get("name", f"DeltaCode Scan - {target}")

        engine = params.get("engine", "nessus")
        if engine == "nessus":
            result = _try_nessus("POST", "/scans", {
                "uuid": params.get("template", "basic"),
                "settings": {"name": name, "text_targets": target},
            })
            if result.get("success"):
                return MCPResponse(id="", success=True, data=result["data"], mime_type="application/json")

        return MCPResponse(id="", success=False, data={
            "error": f"{engine.title()} API not available. Create the scan manually, then use get_scan_results.",
            "target": target,
            "scan_name": name,
        })


class GetScanResults(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_scan_results",
            description="Get vulnerability findings from a completed scan",
            category="nessus",
            input_schema={
                "type": "object",
                "properties": {
                    "scan_id": {"type": "integer", "description": "Scan ID to retrieve results for"},
                    "engine": {"type": "string", "enum": ["nessus", "openvas"], "default": "nessus"},
                    "severity": {"type": "string", "enum": ["all", "critical", "high", "medium", "low"], "default": "all"},
                    "max_results": {"type": "integer", "default": 50},
                },
                "required": ["scan_id"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        scan_id = params.get("scan_id", 0)
        engine = params.get("engine", "nessus")
        severity = params.get("severity", "all").lower()
        max_results = params.get("max_results", 50)

        sev_map = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
        min_sev = sev_map.get(severity, 0) if severity != "all" else 0

        if engine == "nessus":
            result = _try_nessus("GET", f"/scans/{scan_id}")
            if result.get("success"):
                vulns = result["data"].get("vulnerabilities", [])
                filtered = [v for v in vulns if v.get("severity", 0) >= min_sev]
                return MCPResponse(id="", success=True, data={
                    "total": len(filtered), "vulnerabilities": filtered[:max_results],
                }, mime_type="application/json")

        return MCPResponse(id="", success=False, data={
            "error": f"{engine.title()} API unavailable. Showing sample vulnerabilities.",
            "sample_vulnerabilities": [
                v for v in SAMPLE_VULNERABILITIES.get("default", [])
                if sev_map.get(v.get("severity", "").lower(), 1) >= min_sev
            ][:max_results],
        })


class GetScanStatus(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_scan_status",
            description="Check the status and progress of a vulnerability scan",
            category="nessus",
            input_schema={
                "type": "object",
                "properties": {
                    "scan_id": {"type": "integer", "description": "Scan ID"},
                    "engine": {"type": "string", "enum": ["nessus", "openvas"], "default": "nessus"},
                },
                "required": ["scan_id"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        scan_id = params.get("scan_id", 0)
        engine = params.get("engine", "nessus")

        if engine == "nessus":
            result = _try_nessus("GET", f"/scans/{scan_id}")
            if result.get("success"):
                info = result["data"]
                return MCPResponse(id="", success=True, data={
                    "scan_id": scan_id,
                    "status": info.get("status", "unknown"),
                    "progress": info.get("progress", 0),
                    "total_hosts": len(info.get("hosts", [])),
                }, mime_type="application/json")

        return MCPResponse(id="", success=False, data={
            "error": f"{engine.title()} API unavailable",
        })


class ExportReport(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="export_report",
            description="Export scan results in a standard format (CSV, HTML, PDF)",
            category="nessus",
            input_schema={
                "type": "object",
                "properties": {
                    "scan_id": {"type": "integer", "description": "Scan ID"},
                    "format": {"type": "string", "enum": ["csv", "html", "pdf"], "default": "csv"},
                    "engine": {"type": "string", "enum": ["nessus", "openvas"], "default": "nessus"},
                },
                "required": ["scan_id"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        scan_id = params.get("scan_id", 0)
        fmt = params.get("format", "csv")
        engine = params.get("engine", "nessus")

        if engine == "nessus":
            result = _try_nessus("POST", f"/scans/{scan_id}/export", {"format": fmt})
            if result.get("success"):
                return MCPResponse(id="", success=True, data=result["data"], mime_type="application/json")

        return MCPResponse(id="", success=False, data={
            "error": f"{engine.title()} API unavailable for export. Use get_scan_results for JSON data.",
        })


class NessusConnector(MCPConnector):
    def get_info(self) -> MCPConnectorInfo:
        return MCPConnectorInfo(
            name="nessus",
            description="Nessus/OpenVAS vulnerability scanner integration for target assessment",
            version="1.0.0",
        )

    def _register_tools(self):
        self._tools = {
            "list_scans": ListScans(),
            "create_scan": CreateScan(),
            "get_scan_results": GetScanResults(),
            "get_scan_status": GetScanStatus(),
            "export_report": ExportReport(),
        }