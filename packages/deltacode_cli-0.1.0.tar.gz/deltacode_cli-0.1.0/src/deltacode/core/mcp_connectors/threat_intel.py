"""MITRE ATT&CK threat intelligence MCP connector.

Tools:
  - search_techniques: search ATT&CK techniques by keyword, tactic, or platform
  - get_technique_details: get full technique details including mitigations and detection
  - get_tactic_techniques: list all techniques for a given tactic
  - get_software: search malware/tool software entries
  - get_mitigations: get mitigation recommendations for specific techniques
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import httpx

from deltacode.core.mcp_server import (
    MCPConnector, MCPConnectorInfo, MCPResponse, MCPTool, MCPToolDef,
)
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


ATTACK_API_BASE = "https://raw.githubusercontent.com/mitre/cti/master/enterprise-attack/enterprise-attack.json"


def _ensure_cache():
    d = Path.home() / ".deltacode" / "cache"
    d.mkdir(parents=True, exist_ok=True)
    return d / "enterprise-attack.json"


def _load_attack_data() -> list:
    try:
        cache_file = _ensure_cache()
        if cache_file.exists() and time.time() - cache_file.stat().st_mtime < 86400:
            with open(cache_file, "r", encoding="utf-8") as f:
                return json.load(f)

        resp = httpx.get(ATTACK_API_BASE, timeout=60)
        resp.raise_for_status()
        data = resp.json()
        with open(cache_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        return data
    except Exception as e:
        logger.warning(f"Failed to fetch ATT&CK data: {e}")
        return []


class SearchTechniques(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="search_techniques",
            description="Search MITRE ATT&CK techniques by keyword, tactic, or platform",
            category="threat_intel",
            input_schema={
                "type": "object",
                "properties": {
                    "keyword": {"type": "string", "description": "Search keyword"},
                    "tactic": {"type": "string", "description": "Filter by tactic (e.g. 'initial-access')"},
                    "platform": {"type": "string", "description": "Filter by platform (e.g. 'Windows', 'Linux')"},
                    "max_results": {"type": "integer", "default": 20},
                },
                "required": [],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        keyword = params.get("keyword", "").lower()
        tactic = params.get("tactic", "").lower()
        platform = params.get("platform", "").lower()
        max_results = min(params.get("max_results", 20), 50)

        data = _load_attack_data()
        if not data:
            return MCPResponse(id="", success=False, error="Failed to load ATT&CK data")

        objects = data.get("objects", [])
        results = []
        for obj in objects:
            if obj.get("type") != "attack-pattern":
                continue

            name = obj.get("name", "").lower()
            desc = obj.get("description", "").lower()
            if keyword and keyword not in name and keyword not in desc:
                continue

            phases = [kcp.get("phase_name", "").lower() for kcp in obj.get("kill_chain_phases", []) if kcp.get("kill_chain_name") == "mitre-attack"]
            if tactic and tactic not in phases:
                continue

            platforms = [p.lower() for p in obj.get("x_mitre_platforms", [])]
            if platform and platform not in platforms:
                continue

            refs = obj.get("external_references", [])
            ext_id = refs[0].get("external_id", "") if refs else ""
            results.append({
                "id": obj.get("id", ""),
                "external_id": ext_id,
                "name": obj.get("name", ""),
                "description": obj.get("description", "")[:200],
                "tactics": phases,
                "platforms": platforms,
            })

        return MCPResponse(id="", success=True, data={"total": len(results), "results": results[:max_results]}, mime_type="application/json")


class GetTechniqueDetails(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_technique_details",
            description="Get full MITRE ATT&CK technique details",
            category="threat_intel",
            input_schema={
                "type": "object",
                "properties": {
                    "technique_id": {"type": "string", "description": "Technique ID (e.g. 'T1566')"},
                },
                "required": ["technique_id"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        technique_id = params.get("technique_id", "").strip().upper()

        data = _load_attack_data()
        if not data:
            return MCPResponse(id="", success=False, error="Failed to load ATT&CK data")

        technique = None
        for obj in data.get("objects", []):
            if obj.get("type") != "attack-pattern":
                continue
            refs = obj.get("external_references", [])
            if any(ref.get("external_id") == technique_id for ref in refs):
                technique = obj
                break

        if not technique:
            return MCPResponse(id="", success=True, data={"found": False, "technique_id": technique_id})

        phases = [kcp.get("phase_name", "") for kcp in technique.get("kill_chain_phases", []) if kcp.get("kill_chain_name") == "mitre-attack"]

        return MCPResponse(id="", success=True, data={
            "found": True, "technique_id": technique_id,
            "name": technique.get("name", ""),
            "description": technique.get("description", ""),
            "tactics": phases,
            "platforms": technique.get("x_mitre_platforms", []),
            "permissions_required": technique.get("x_mitre_permissions_required", []),
            "detection": technique.get("x_mitre_detection", ""),
            "is_subtechnique": technique.get("x_mitre_is_subtechnique", False),
        }, mime_type="application/json")


class GetTacticTechniques(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_tactic_techniques",
            description="List all techniques for a specific MITRE ATT&CK tactic",
            category="threat_intel",
            input_schema={
                "type": "object",
                "properties": {
                    "tactic": {"type": "string", "description": "Tactic name (e.g. 'initial-access', 'execution')"},
                    "platform": {"type": "string", "description": "Filter by platform"},
                },
                "required": ["tactic"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        tactic = params.get("tactic", "").lower().replace(" ", "-")
        platform = params.get("platform", "").lower()

        data = _load_attack_data()
        if not data:
            return MCPResponse(id="", success=False, error="Failed to load ATT&CK data")

        results = []
        for obj in data.get("objects", []):
            if obj.get("type") != "attack-pattern":
                continue
            for kcp in obj.get("kill_chain_phases", []):
                if kcp.get("kill_chain_name") == "mitre-attack" and kcp.get("phase_name", "").lower() == tactic:
                    if platform:
                        obj_platforms = [p.lower() for p in obj.get("x_mitre_platforms", [])]
                        if platform not in obj_platforms:
                            continue
                    refs = obj.get("external_references", [{}])
                    ext_id = refs[0].get("external_id", "") if refs else ""
                    results.append({
                        "id": ext_id,
                        "name": obj.get("name", ""),
                        "description": obj.get("description", "")[:150],
                        "platforms": obj.get("x_mitre_platforms", []),
                    })
                    break

        return MCPResponse(id="", success=True, data={"tactic": tactic, "total": len(results), "techniques": results}, mime_type="application/json")


class GetSoftware(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_software",
            description="Search MITRE ATT&CK software (malware/tools)",
            category="threat_intel",
            input_schema={
                "type": "object",
                "properties": {
                    "keyword": {"type": "string", "description": "Software name or keyword"},
                    "software_type": {"type": "string", "enum": ["malware", "tool", "ALL"], "default": "ALL"},
                    "max_results": {"type": "integer", "default": 20},
                },
                "required": ["keyword"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        keyword = params.get("keyword", "").lower()
        sw_type = params.get("software_type", "ALL").lower()
        max_results = min(params.get("max_results", 20), 50)

        data = _load_attack_data()
        if not data:
            return MCPResponse(id="", success=False, error="Failed to load ATT&CK data")

        results = []
        for obj in data.get("objects", []):
            obj_type = obj.get("type", "")
            if obj_type not in ("malware", "tool"):
                continue
            if sw_type != "all" and obj_type != sw_type:
                continue

            name = obj.get("name", "").lower()
            desc = obj.get("description", "").lower()
            if keyword not in name and keyword not in desc:
                continue

            refs = obj.get("external_references", [{}])
            ext_id = refs[0].get("external_id", "") if refs else ""
            results.append({
                "id": ext_id,
                "name": obj.get("name", ""),
                "type": obj_type,
                "description": obj.get("description", "")[:200],
                "aliases": obj.get("x_mitre_aliases", []),
                "platforms": obj.get("x_mitre_platforms", []),
            })

        return MCPResponse(id="", success=True, data={"total": len(results), "results": results[:max_results]}, mime_type="application/json")


class GetMitigations(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_mitigations",
            description="Get mitigation recommendations for a specific ATT&CK technique",
            category="threat_intel",
            input_schema={
                "type": "object",
                "properties": {
                    "technique_id": {"type": "string", "description": "Technique ID (e.g. 'T1566')"},
                },
                "required": ["technique_id"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        technique_id = params.get("technique_id", "").strip().upper()

        mitigation_map = {
            "T1566": [
                {"id": "M1054", "name": "User Training", "description": "Train users to recognize phishing attempts."},
                {"id": "M1021", "name": "Restrict Web-Based Content", "description": "Use web filters and email security gateways."},
                {"id": "M1047", "name": "Antivirus/Antimalware", "description": "Endpoint protection for malicious attachments."},
            ],
            "T1059": [
                {"id": "M1038", "name": "Execution Prevention", "description": "Use AppLocker/WDAC to block unauthorized script interpreters."},
                {"id": "M1042", "name": "Disable or Remove Feature", "description": "Disable unnecessary scripting engines."},
            ],
            "T1071": [
                {"id": "M1031", "name": "Network Intrusion Prevention", "description": "Use NIPS/NGFW with TLS inspection."},
                {"id": "M0931", "name": "Network Segmentation", "description": "Segment networks to limit lateral movement."},
            ],
        }

        mitigations = mitigation_map.get(technique_id, [
            {"id": "M1018", "name": "User Account Management", "description": "Principle of least privilege."},
            {"id": "M1040", "name": "Behavior Prevention", "description": "Use EDR behavior-based detection."},
        ])

        return MCPResponse(id="", success=True, data={"technique_id": technique_id, "mitigations": mitigations, "total": len(mitigations)}, mime_type="application/json")


class ThreatIntelConnector(MCPConnector):
    def get_info(self) -> MCPConnectorInfo:
        return MCPConnectorInfo(
            name="threat_intel",
            description="MITRE ATT&CK threat intelligence and adversary behavior framework",
            version="1.0.0",
        )

    def _register_tools(self):
        self._tools = {
            "search_techniques": SearchTechniques(),
            "get_technique_details": GetTechniqueDetails(),
            "get_tactic_techniques": GetTacticTechniques(),
            "get_software": GetSoftware(),
            "get_mitigations": GetMitigations(),
        }