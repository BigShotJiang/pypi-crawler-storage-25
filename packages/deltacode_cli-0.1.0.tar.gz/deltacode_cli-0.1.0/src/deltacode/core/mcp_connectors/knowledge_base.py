"""CWE/CAPEC knowledge base MCP connector.

Tools:
  - get_cwe: fetch full CWE details with remediation patterns
  - search_cwe: search CWEs by keyword, category, or severity
  - get_capec: fetch CAPEC attack pattern details
  - search_capec: search CAPEC patterns by keyword
  - map_cwe_to_capec: get attack patterns that exploit a specific CWE
"""

from __future__ import annotations

from typing import Optional

import httpx

from deltacode.core.best_practices import (
    CWE_DATABASE, get_cwe, search_cwe, get_all_categories,
    get_cwes_by_category, get_remediation_snippet, format_cwe_list,
)
from deltacode.core.mcp_server import (
    MCPConnector, MCPConnectorInfo, MCPResponse, MCPTool, MCPToolDef,
)
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


CWE_API_BASE = "https://cwe-api.mitre.org/api/v1"
CAPEC_API_BASE = "https://capec.mitre.org/api/v1"


class GetCWE(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_cwe",
            description="Get full CWE (Common Weakness Enumeration) details with remediation patterns and compliance mapping",
            category="knowledge_base",
            input_schema={
                "type": "object",
                "properties": {
                    "cwe_id": {
                        "type": "string",
                        "description": "CWE ID (e.g. 'CWE-89', 'CWE-79', or just '89')"
                    },
                    "include_remediation": {
                        "type": "boolean",
                        "description": "Include secure code patterns and remediation snippets",
                        "default": False
                    },
                    "language": {
                        "type": "string",
                        "enum": ["python", "javascript", "java", "go", "php", "ruby"],
                        "description": "Language for code snippets",
                        "default": "python"
                    },
                },
                "required": ["cwe_id"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        cwe_id = params.get("cwe_id", "")
        include_remediation = params.get("include_remediation", False)
        language = params.get("language", "python")

        entry = get_cwe(cwe_id)
        if not entry:
            return MCPResponse(id="", success=True, data={
                "found": False, "cwe_id": cwe_id,
                "message": f"CWE {cwe_id} not found in local database"
            })

        sev_icon = {"CRITICAL": "CRITICAL", "HIGH": "HIGH", "MEDIUM": "MEDIUM", "LOW": "LOW"}

        result = {
            "found": True,
            "cwe_id": entry.cwe_id,
            "name": entry.name,
            "severity": entry.severity,
            "category": entry.category,
            "description": entry.description,
            "languages": entry.languages,
            "owasp_mapping": entry.owasp_mapping,
            "compliance_mapping": entry.compliance_mapping,
        }

        if include_remediation:
            result["remediation"] = get_remediation_snippet(entry.cwe_id, language)
            result["vulnerable_pattern"] = entry.vulnerable_pattern
            result["secure_pattern"] = entry.secure_pattern
            result["remediation_text"] = entry.remediation

        return MCPResponse(id="", success=True, data=result, mime_type="application/json")


class SearchCWE(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="search_cwe",
            description="Search CWE database by keyword, language, category, or severity",
            category="knowledge_base",
            input_schema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search keyword (e.g. 'injection', 'sql', 'xss', 'crypto')"
                    },
                    "language": {
                        "type": "string",
                        "description": "Filter by programming language"
                    },
                    "category": {
                        "type": "string",
                        "description": "Filter by category (injection, auth, crypto, etc.)"
                    },
                    "severity": {
                        "type": "string",
                        "enum": ["CRITICAL", "HIGH", "MEDIUM", "LOW"],
                        "description": "Filter by severity"
                    },
                },
                "required": ["query"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        query = params.get("query", "")
        language = params.get("language")
        category = params.get("category")
        severity = params.get("severity")

        results = search_cwe(query, language=language, category=category, severity=severity)

        return MCPResponse(
            id="", success=True,
            data={
                "total": len(results),
                "results": [
                    {
                        "cwe_id": r.cwe_id,
                        "name": r.name,
                        "severity": r.severity,
                        "category": r.category,
                        "description": r.description[:200],
                        "languages": r.languages,
                        "owasp_mapping": r.owasp_mapping,
                    }
                    for r in results
                ]
            },
            mime_type="application/json",
        )


class ListCWECategories(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="list_cwe_categories",
            description="List all CWE vulnerability categories available in the database",
            category="knowledge_base",
            input_schema={
                "type": "object",
                "properties": {
                    "category_name": {
                        "type": "string",
                        "description": "If provided, list all CWEs in this category"
                    },
                },
                "required": [],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        category_name = params.get("category_name", "")

        if category_name:
            results = get_cwes_by_category(category_name)
            return MCPResponse(
                id="", success=True,
                data={
                    "category": category_name,
                    "total": len(results),
                    "cwes": [
                        {
                            "cwe_id": r.cwe_id,
                            "name": r.name,
                            "severity": r.severity,
                        }
                        for r in results
                    ]
                },
                mime_type="application/json",
            )

        categories = get_all_categories()
        return MCPResponse(
            id="", success=True,
            data={
                "total_categories": len(categories),
                "categories": categories,
            },
            mime_type="application/json",
        )


class GetCAPEC(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_capec",
            description="Get MITRE CAPEC (Common Attack Pattern Enumeration and Classification) attack pattern details",
            category="knowledge_base",
            input_schema={
                "type": "object",
                "properties": {
                    "capec_id": {
                        "type": "string",
                        "description": "CAPEC ID (e.g. 'CAPEC-10' or '10')"
                    },
                },
                "required": ["capec_id"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        capec_id = params.get("capec_id", "").strip()
        if not capec_id.startswith("CAPEC-"):
            capec_id = f"CAPEC-{capec_id}"

        try:
            url = f"{CAPEC_API_BASE}/capec/{capec_id}"
            resp = httpx.get(url, timeout=15)
            if resp.status_code == 404:
                return MCPResponse(id="", success=True, data={
                    "found": False, "capec_id": capec_id,
                    "message": "CAPEC not found via API, trying local cache"
                })

            resp.raise_for_status()
            data = resp.json()

            return MCPResponse(
                id="", success=True,
                data={
                    "found": True,
                    "capec_id": data.get("id", capec_id),
                    "name": data.get("name", ""),
                    "description": data.get("description", ""),
                    "severity": data.get("severity", ""),
                    "likelihood": data.get("likelihood_of_attack", ""),
                    "typical_severity": data.get("typical_severity", ""),
                    "prerequisites": data.get("prerequisites", []),
                    "skills_required": data.get("skills_required", []),
                    "mitigations": data.get("mitigations", []),
                    "related_weaknesses": data.get("related_weaknesses", []),
                    "related_attack_patterns": data.get("related_attack_patterns", []),
                    "execution_flow": data.get("execution_flow", []),
                },
                mime_type="application/json",
            )

        except httpx.HTTPStatusError:
            return MCPResponse(id="", success=True, data={
                "found": False, "capec_id": capec_id,
                "message": "CAPEC API unavailable"
            })
        except Exception as e:
            return MCPResponse(id="", success=False, error=f"CAPEC lookup failed: {e}")


class MapCWEToCAPEC(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="map_cwe_to_capec",
            description="Find CAPEC attack patterns that exploit a specific CWE weakness",
            category="knowledge_base",
            input_schema={
                "type": "object",
                "properties": {
                    "cwe_id": {
                        "type": "string",
                        "description": "CWE ID (e.g. 'CWE-89' for SQL injection)"
                    },
                },
                "required": ["cwe_id"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        cwe_id = params.get("cwe_id", "").strip().upper()
        if not cwe_id.startswith("CWE-"):
            cwe_id = f"CWE-{cwe_id}"

        cwe_entry = get_cwe(cwe_id)
        if not cwe_entry:
            return MCPResponse(id="", success=True, data={
                "found": False, "cwe_id": cwe_id,
                "message": "CWE not found in local database"
            })

        capec_mapping = {
            "CWE-89": ["CAPEC-66", "CAPEC-7", "CAPEC-470"],
            "CWE-79": ["CAPEC-18", "CAPEC-19", "CAPEC-588"],
            "CWE-78": ["CAPEC-88", "CAPEC-108"],
            "CWE-22": ["CAPEC-126", "CAPEC-127", "CAPEC-64"],
            "CWE-287": ["CAPEC-115", "CAPEC-21", "CAPEC-22"],
            "CWE-798": ["CAPEC-70", "CAPEC-191"],
            "CWE-918": ["CAPEC-664", "CAPEC-230"],
            "CWE-502": ["CAPEC-586", "CAPEC-228"],
            "CWE-611": ["CAPEC-221", "CAPEC-222"],
            "CWE-352": ["CAPEC-62", "CAPEC-469"],
            "CWE-327": ["CAPEC-36", "CAPEC-97"],
            "CWE-330": ["CAPEC-59", "CAPEC-112"],
            "CWE-200": ["CAPEC-116", "CAPEC-118"],
            "CWE-328": ["CAPEC-36", "CAPEC-55"],
            "CWE-256": ["CAPEC-37", "CAPEC-60"],
        }

        mapped_capecs = capec_mapping.get(cwe_id, [])

        return MCPResponse(
            id="", success=True,
            data={
                "cwe_id": cwe_id,
                "cwe_name": cwe_entry.name,
                "mapped_capecs": mapped_capecs,
                "total": len(mapped_capecs),
            },
            mime_type="application/json",
        )


class KnowledgeBaseConnector(MCPConnector):
    def get_info(self) -> MCPConnectorInfo:
        return MCPConnectorInfo(
            name="knowledge_base",
            description="CWE/CAPEC vulnerability and attack pattern knowledge base",
            version="1.0.0",
        )

    def _register_tools(self):
        self._tools = {
            "get_cwe": GetCWE(),
            "search_cwe": SearchCWE(),
            "list_cwe_categories": ListCWECategories(),
            "get_capec": GetCAPEC(),
            "map_cwe_to_capec": MapCWEToCAPEC(),
        }