"""Vendor security documentation scraper MCP connector.

Scrapes security documentation from major vendors:
- Apache security advisories
- Microsoft Security Response Center
- Red Hat security updates
- Ubuntu security notices
- Cloudflare security blog
- GitHub Security Lab
"""

from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Optional

import httpx
import feedparser

from deltacode.core.mcp_server import (
    MCPConnector, MCPConnectorInfo, MCPResponse, MCPTool, MCPToolDef,
)
from deltacode.core.logger import get_logger
from deltacode.core.cache import DeltaCache

logger = get_logger(__name__)


VENDOR_FEEDS = {
    "apache": "https://www.apache.org/security/announcements.xml",
    "microsoft": "https://msrc.microsoft.com/update-guide/rss",
    "redhat": "https://access.redhat.com/security/updates/advisory.rss",
    "ubuntu": "https://ubuntu.com/security/notices/rss.xml",
    "cloudflare": "https://blog.cloudflare.com/rss/",
    "github_security": "https://github.blog/category/security/feed/",
    "portswigger": "https://portswigger.net/research/rss",
    "snyk": "https://snyk.io/blog/feed.xml",
}


class GetVendorSecurityNews(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_vendor_security_news",
            description="Get latest security advisories from major vendors",
            category="vendor_docs",
            input_schema={
                "type": "object",
                "properties": {
                    "vendors": {
                        "type": "string",
                        "description": "Comma-separated vendor names (apache, microsoft, redhat, ubuntu, cloudflare, github_security, portswigger, snyk). Empty for all.",
                        "default": ""
                    },
                    "max_per_vendor": {
                        "type": "integer",
                        "default": 5
                    },
                    "days_back": {
                        "type": "integer",
                        "default": 30
                    },
                },
                "required": [],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        vendor_filter = [v.strip().lower() for v in params.get("vendors", "").split(",") if v.strip()] if params.get("vendors") else []
        max_per = params.get("max_per_vendor", 5)
        days_back = params.get("days_back", 30)

        cutoff = datetime.utcnow() - timedelta(days=days_back)
        results = []

        for vendor, feed_url in VENDOR_FEEDS.items():
            if vendor_filter and vendor not in vendor_filter:
                continue

            cache_key = f"vendor_feed_{vendor}"
            cached = DeltaCache.get("vendor_docs", cache_key)
            if cached:
                entries = cached
            else:
                try:
                    resp = httpx.get(feed_url, timeout=20, follow_redirects=True)
                    resp.raise_for_status()
                    parsed = feedparser.parse(resp.text)
                    entries = []
                    for entry in parsed.entries[:max_per]:
                        published = entry.get("published", "")
                        try:
                            pub_date = datetime(*entry.published_parsed[:6]) if entry.get("published_parsed") else datetime.min
                        except Exception:
                            pub_date = datetime.min

                        cve_ids = re.findall(r'CVE-\d{4}-\d{4,7}', entry.get("title", "") + " " + entry.get("summary", ""))

                        entries.append({
                            "vendor": vendor,
                            "title": entry.get("title", ""),
                            "url": entry.get("link", ""),
                            "published": published,
                            "summary": (entry.get("summary", "") or "")[:300],
                            "cve_ids": cve_ids[:5],
                        })
                    DeltaCache.set("vendor_docs", cache_key, entries, ttl=3600)
                except Exception:
                    entries = []

            for e in entries:
                try:
                    pub = e.get("published", "")
                    pub_date = e.get("published_parsed", None)
                    if pub_date:
                        from time import mktime
                        from datetime import datetime as dt
                        dt_obj = dt.fromtimestamp(mktime(pub_date))
                        if dt_obj < cutoff:
                            continue
                except Exception:
                    pass
                results.append(e)

        return MCPResponse(
            id="", success=True,
            data={"total": len(results), "results": results},
            mime_type="application/json",
        )


class SearchVendorAdvisories(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="search_vendor_advisories",
            description="Search vendor security advisories by CVE or keyword",
            category="vendor_docs",
            input_schema={
                "type": "object",
                "properties": {
                    "keyword": {
                        "type": "string",
                        "description": "CVE ID or keyword to search"
                    },
                    "vendors": {
                        "type": "string",
                        "description": "Comma-separated vendor filter",
                        "default": ""
                    },
                },
                "required": ["keyword"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        keyword = params.get("keyword", "").lower()
        vendor_filter = [v.strip().lower() for v in params.get("vendors", "").split(",") if v.strip()] if params.get("vendors") else []

        results = []

        for vendor, feed_url in VENDOR_FEEDS.items():
            if vendor_filter and vendor not in vendor_filter:
                continue

            cache_key = f"vendor_feed_{vendor}"
            cached = DeltaCache.get("vendor_docs", cache_key)
            if cached:
                entries = cached
            else:
                try:
                    resp = httpx.get(feed_url, timeout=20, follow_redirects=True)
                    resp.raise_for_status()
                    parsed = feedparser.parse(resp.text)
                    entries = []
                    for entry in parsed.entries[:20]:
                        entries.append({
                            "vendor": vendor,
                            "title": entry.get("title", ""),
                            "url": entry.get("link", ""),
                            "published": entry.get("published", ""),
                            "summary": (entry.get("summary", "") or "")[:300],
                        })
                    DeltaCache.set("vendor_docs", cache_key, entries, ttl=3600)
                except Exception:
                    entries = []

            for e in entries:
                searchable = f"{e.get('title', '')} {e.get('summary', '')}".lower()
                if keyword in searchable:
                    results.append(e)

        return MCPResponse(
            id="", success=True,
            data={"keyword": keyword, "total": len(results), "results": results},
            mime_type="application/json",
        )


class VendorDocsConnector(MCPConnector):
    def get_info(self) -> MCPConnectorInfo:
        return MCPConnectorInfo(
            name="vendor_docs",
            description="Vendor security documentation and advisory scraping",
            version="1.0.0",
        )

    def _register_tools(self):
        self._tools = {
            "get_vendor_security_news": GetVendorSecurityNews(),
            "search_vendor_advisories": SearchVendorAdvisories(),
        }