"""CVE/NVD security advisory MCP connector.

Tools:
  - search_advisories: search CVE database by keyword, product, or vendor
  - get_cve_details: fetch full CVE details including CVSS, references, CWEs
  - get_recent_advisories: list recent CVEs by severity or date range
  - get_exploit_status: check if a CVE has known exploits
"""

from __future__ import annotations

import json
import re
import urllib.parse
from datetime import datetime, timedelta
from typing import Optional

import httpx

from deltacode.core.mcp_server import (
    MCPConnector, MCPConnectorInfo, MCPResponse, MCPTool, MCPToolDef,
)
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


NVD_API_BASE = "https://services.nvd.nist.gov/rest/json/cves/2.0"
NVD_API_KEY_PARAM = ""


class SearchAdvisories(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="search_advisories",
            description="Search CVE/NVD for security advisories by keyword, product, vendor, or CWE",
            category="advisory",
            input_schema={
                "type": "object",
                "properties": {
                    "keyword": {
                        "type": "string",
                        "description": "Search keyword (e.g. 'sql injection', 'apache', 'openssl')"
                    },
                    "cwe_id": {
                        "type": "string",
                        "description": "Filter by CWE ID (e.g. 'CWE-89')"
                    },
                    "severity": {
                        "type": "string",
                        "enum": ["CRITICAL", "HIGH", "MEDIUM", "LOW"],
                        "description": "Filter by CVSS v3 severity"
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum number of results (1-50)",
                        "default": 10
                    },
                    "days_back": {
                        "type": "integer",
                        "description": "Only advisories from last N days",
                        "default": 90
                    },
                },
                "required": ["keyword"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        keyword = params.get("keyword", "")
        cwe_id = params.get("cwe_id", "")
        severity = params.get("severity", "")
        max_results = min(params.get("max_results", 10), 50)
        days_back = params.get("days_back", 90)

        if not keyword and not cwe_id:
            return MCPResponse(id="", success=False, error="Provide keyword or cwe_id")

        try:
            query_parts = {}
            if keyword:
                query_parts["keywordSearch"] = keyword
            if cwe_id:
                cwe_clean = cwe_id.replace("CWE-", "").replace("cwe-", "")
                query_parts["cweId"] = cwe_clean

            if days_back and keyword:
                start_date = (datetime.utcnow() - timedelta(days=days_back)).strftime("%Y-%m-%dT00:00:00.000")
                end_date = datetime.utcnow().strftime("%Y-%m-%dT23:59:59.999")
                query_parts["pubStartDate"] = start_date
                query_parts["pubEndDate"] = end_date

            query_parts["resultsPerPage"] = str(max_results)

            url = f"{NVD_API_BASE}?{urllib.parse.urlencode(query_parts)}"

            headers = {}
            if NVD_API_KEY_PARAM:
                headers["apiKey"] = NVD_API_KEY_PARAM

            resp = httpx.get(url, headers=headers, timeout=30)
            resp.raise_for_status()
            data = resp.json()

            vulnerabilities = data.get("vulnerabilities", [])
            results = []

            for vuln in vulnerabilities:
                cve = vuln.get("cve", {})
                metrics = cve.get("metrics", {})
                cvss_v3 = metrics.get("cvssMetricV31", [{}])[0].get("cvssData", {})
                cvss_v2 = metrics.get("cvssMetricV2", [{}])[0].get("cvssData", {})

                base_score = cvss_v3.get("baseScore") or cvss_v2.get("baseScore") or "N/A"
                severity_label = cvss_v3.get("baseSeverity") or cvss_v2.get("baseSeverity") or "N/A"

                if severity and severity.upper() != severity_label.upper():
                    continue

                descriptions = cve.get("descriptions", [{}])
                description = ""
                for desc in descriptions:
                    if desc.get("lang") == "en":
                        description = desc.get("value", "")
                        break
                if not description:
                    description = descriptions[0].get("value", "") if descriptions else ""

                references = [
                    ref.get("url", "")
                    for ref in cve.get("references", [])
                    if "url" in ref
                ][:5]

                cwes = set()
                for weakness in cve.get("weaknesses", []):
                    for desc in weakness.get("description", []):
                        val = desc.get("value", "")
                        if val.startswith("CWE-"):
                            cwes.add(val)

                results.append({
                    "id": cve.get("id", ""),
                    "description": description[:300],
                    "score": base_score,
                    "severity": severity_label,
                    "published": cve.get("published", ""),
                    "cwes": list(cwes)[:3],
                    "references": references,
                    "exploit_available": cve.get("exploitAvailable", False),
                })

            if not results:
                return MCPResponse(
                    id="", success=True,
                    data={"total": 0, "results": [], "message": "No advisories found"}
                )

            return MCPResponse(
                id="", success=True,
                data={"total": len(results), "results": results},
                mime_type="application/json",
            )

        except httpx.HTTPStatusError as e:
            return MCPResponse(id="", success=False, error=f"NVD API error: {e.response.status_code}")
        except httpx.TimeoutException:
            return MCPResponse(id="", success=False, error="NVD API timeout")
        except Exception as e:
            return MCPResponse(id="", success=False, error=f"Search failed: {e}")


class GetCVEDetails(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_cve_details",
            description="Get full CVE details including CVSS score, vector, CWEs, and references",
            category="advisory",
            input_schema={
                "type": "object",
                "properties": {
                    "cve_id": {
                        "type": "string",
                        "description": "CVE ID (e.g. 'CVE-2024-21626', 'CVE-2023-44487')"
                    },
                },
                "required": ["cve_id"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        cve_id = params.get("cve_id", "").strip().upper()
        if not cve_id:
            return MCPResponse(id="", success=False, error="Provide cve_id")

        try:
            url = f"{NVD_API_BASE}?cveId={urllib.parse.quote(cve_id)}"
            headers = {}
            if NVD_API_KEY_PARAM:
                headers["apiKey"] = NVD_API_KEY_PARAM

            resp = httpx.get(url, headers=headers, timeout=30)
            resp.raise_for_status()
            data = resp.json()

            vulns = data.get("vulnerabilities", [])
            if not vulns:
                return MCPResponse(id="", success=True, data={"found": False, "cve_id": cve_id})

            cve = vulns[0].get("cve", {})
            metrics = cve.get("metrics", {})

            cvss_v31 = metrics.get("cvssMetricV31", [{}])
            cvss_v30 = metrics.get("cvssMetricV30", [{}])
            cvss_v2 = metrics.get("cvssMetricV2", [{}])

            cvss_data = (cvss_v31 or cvss_v30 or cvss_v2)[0].get("cvssData", {})
            exploitability = (cvss_v31 or cvss_v30 or cvss_v2)[0].get("exploitabilityScore", "N/A")
            impact_score = (cvss_v31 or cvss_v30 or cvss_v2)[0].get("impactScore", "N/A")

            descriptions = cve.get("descriptions", [{}])
            en_desc = ""
            for desc in descriptions:
                if desc.get("lang") == "en":
                    en_desc = desc.get("value", "")
                    break

            return MCPResponse(
                id="", success=True,
                data={
                    "found": True,
                    "cve_id": cve.get("id", cve_id),
                    "description": en_desc,
                    "published": cve.get("published", ""),
                    "last_modified": cve.get("lastModified", ""),
                    "source_identifier": cve.get("sourceIdentifier", ""),
                    "cvss": {
                        "version": cvss_data.get("version", ""),
                        "score": cvss_data.get("baseScore", ""),
                        "severity": cvss_data.get("baseSeverity", ""),
                        "vector": cvss_data.get("vectorString", ""),
                        "attack_vector": cvss_data.get("attackVector", ""),
                        "attack_complexity": cvss_data.get("attackComplexity", ""),
                        "privileges_required": cvss_data.get("privilegesRequired", ""),
                        "user_interaction": cvss_data.get("userInteraction", ""),
                        "scope": cvss_data.get("scope", ""),
                        "confidentiality": cvss_data.get("confidentialityImpact", ""),
                        "integrity": cvss_data.get("integrityImpact", ""),
                        "availability": cvss_data.get("availabilityImpact", ""),
                        "exploitability_score": exploitability,
                        "impact_score": impact_score,
                    },
                    "cwes": [
                        desc.get("value", "")
                        for weakness in cve.get("weaknesses", [])
                        for desc in weakness.get("description", [])
                        if desc.get("value", "").startswith("CWE-")
                    ],
                    "references": [
                        {
                            "url": ref.get("url", ""),
                            "source": ref.get("source", ""),
                            "tags": ref.get("tags", []),
                        }
                        for ref in cve.get("references", [])
                    ],
                    "configurations": cve.get("configurations", []),
                },
                mime_type="application/json",
            )

        except httpx.HTTPStatusError as e:
            return MCPResponse(id="", success=False, error=f"NVD API error: {e.response.status_code}")
        except httpx.TimeoutException:
            return MCPResponse(id="", success=False, error="NVD API timeout")
        except Exception as e:
            return MCPResponse(id="", success=False, error=f"Failed to fetch CVE: {e}")


class GetRecentAdvisories(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_recent_advisories",
            description="Get recently published CVEs filtered by severity",
            category="advisory",
            input_schema={
                "type": "object",
                "properties": {
                    "severity": {
                        "type": "string",
                        "enum": ["CRITICAL", "HIGH", "MEDIUM", "LOW", "ALL"],
                        "description": "Filter by CVSS severity",
                        "default": "ALL"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Number of results (1-50)",
                        "default": 10
                    },
                    "days": {
                        "type": "integer",
                        "description": "Days to look back",
                        "default": 7
                    },
                },
                "required": [],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        severity = params.get("severity", "ALL").upper()
        limit = min(params.get("limit", 10), 50)
        days = params.get("days", 7)

        try:
            start_date = (datetime.utcnow() - timedelta(days=days)).strftime("%Y-%m-%dT00:00:00.000")
            end_date = datetime.utcnow().strftime("%Y-%m-%dT23:59:59.999")
            query_parts = {
                "pubStartDate": start_date,
                "pubEndDate": end_date,
                "resultsPerPage": str(limit),
            }
            url = f"{NVD_API_BASE}?{urllib.parse.urlencode(query_parts)}"

            headers = {}
            if NVD_API_KEY_PARAM:
                headers["apiKey"] = NVD_API_KEY_PARAM

            resp = httpx.get(url, headers=headers, timeout=30)
            resp.raise_for_status()
            data = resp.json()

            results = []
            for vuln in data.get("vulnerabilities", []):
                cve = vuln.get("cve", {})
                metrics = cve.get("metrics", {})
                cvss = metrics.get("cvssMetricV31", [{}])[0].get("cvssData", {})

                sev = cvss.get("baseSeverity", "N/A")
                if severity != "ALL" and sev != severity:
                    continue

                descriptions = cve.get("descriptions", [{}])
                desc = ""
                for d in descriptions:
                    if d.get("lang") == "en":
                        desc = d.get("value", "")
                        break

                results.append({
                    "id": cve.get("id", ""),
                    "description": desc[:200],
                    "score": cvss.get("baseScore", "N/A"),
                    "severity": sev,
                    "published": cve.get("published", ""),
                })

            return MCPResponse(
                id="", success=True,
                data={"total": len(results), "results": results},
                mime_type="application/json",
            )

        except Exception as e:
            return MCPResponse(id="", success=False, error=f"Failed: {e}")


class GetExploitStatus(MCPTool):
    def get_definition(self) -> MCPToolDef:
        return MCPToolDef(
            name="get_exploit_status",
            description="Check if a CVE has known public exploits or PoCs",
            category="advisory",
            input_schema={
                "type": "object",
                "properties": {
                    "cve_id": {
                        "type": "string",
                        "description": "CVE ID to check (e.g. 'CVE-2024-21626')"
                    },
                },
                "required": ["cve_id"],
            },
            handler=self.execute,
        )

    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        cve_id = params.get("cve_id", "").strip().upper()
        if not cve_id:
            return MCPResponse(id="", success=False, error="Provide cve_id")

        try:
            from deltacode.core.best_practices import CWE_DATABASE

            score_total = 0
            findings = []

            url = f"{NVD_API_BASE}?cveId={urllib.parse.quote(cve_id)}"
            headers = {}
            if NVD_API_KEY_PARAM:
                headers["apiKey"] = NVD_API_KEY_PARAM

            resp = httpx.get(url, headers=headers, timeout=30)
            resp.raise_for_status()
            data = resp.json()
            vulns = data.get("vulnerabilities", [])

            if not vulns:
                return MCPResponse(id="", success=True, data={"cve_id": cve_id, "found": False})

            cve = vulns[0].get("cve", {})
            metrics = cve.get("metrics", {})
            cvss_data = (metrics.get("cvssMetricV31", [{}]) or metrics.get("cvssMetricV30", [{}]) or metrics.get("cvssMetricV2", [{}]))[0].get("cvssData", {})
            base_score = cvss_data.get("baseScore", 0)

            descriptions = cve.get("descriptions", [{}])
            en_desc = ""
            for desc in descriptions:
                if desc.get("lang") == "en":
                    en_desc = desc.get("value", "")
                    break

            refs = [ref.get("url", "") for ref in cve.get("references", [])]

            exploit_indicators = {
                "exploit-db": {"found": False, "confidence": 0.8},
                "metasploit": {"found": False, "confidence": 0.9},
                "poc": {"found": False, "confidence": 0.6},
            }

            for ref in refs:
                ref_lower = ref.lower()
                if "exploit-db.com" in ref_lower:
                    exploit_indicators["exploit-db"]["found"] = True
                if "metasploit" in ref_lower:
                    exploit_indicators["metasploit"]["found"] = True
                if "poc" in ref_lower or "proof" in ref_lower:
                    exploit_indicators["poc"]["found"] = True

            for key, val in exploit_indicators.items():
                if val["found"]:
                    score_total += val["confidence"]
                    findings.append(key)

            exploit_likely = bool(findings) or (base_score and base_score >= 7.0)
            severity_label = cvss_data.get("baseSeverity", "N/A")
            if severity_label in ("CRITICAL",) and not exploit_likely:
                score_total += 0.5

            return MCPResponse(
                id="", success=True,
                data={
                    "cve_id": cve_id,
                    "score": base_score,
                    "severity": severity_label,
                    "exploit_likely": exploit_likely,
                    "exploit_confidence": score_total,
                    "exploit_indicators": findings,
                    "exploit_details": {
                        "exploit_db": exploit_indicators["exploit-db"]["found"],
                        "metasploit_module": exploit_indicators["metasploit"]["found"],
                        "poc_available": exploit_indicators["poc"]["found"],
                    },
                    "description": en_desc[:300],
                },
                mime_type="application/json",
            )

        except Exception as e:
            return MCPResponse(id="", success=False, error=f"Exploit check failed: {e}")


class AdvisoryConnector(MCPConnector):
    def get_info(self) -> MCPConnectorInfo:
        return MCPConnectorInfo(
            name="advisory",
            description="CVE/NVD security advisory research tools",
            version="1.0.0",
        )

    def _register_tools(self):
        self.advisory_tools = {
            "search_advisories": SearchAdvisories(),
            "get_cve_details": GetCVEDetails(),
            "get_recent_advisories": GetRecentAdvisories(),
            "get_exploit_status": GetExploitStatus(),
        }
        self._tools.update(self.advisory_tools)