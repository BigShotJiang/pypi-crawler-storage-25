"""Semantic search for DeltaCode CLI using ChromaDB.

Provides codebase-wide semantic search with:
- Code embeddings via DeltaAI API
- Vulnerability pattern matching
- Security hotspot detection via context builder
- API endpoint discovery
"""

import hashlib
import os
from pathlib import Path
from typing import Optional

from deltacode.core.config import DATA_DIR
from deltacode.core.logger import get_logger
from deltacode.core.prompts import SECURITY_HOTSPOT_PATTERNS

logger = get_logger(__name__)


def _safe_log(level, msg):
    try:
        if level == "info":
            logger.info(msg)
        elif level == "warning":
            logger.warning(msg)
        elif level == "error":
            logger.error(msg)
    except Exception:
        pass

CHUNK_SIZE = 1500
CHUNK_OVERLAP = 200
SUPPORTED_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".rb", ".php",
    ".c", ".cpp", ".h", ".hpp", ".rs", ".cs", ".scala", ".kt",
    ".sh", ".bash", ".yaml", ".yml", ".json", ".xml", ".dockerfile",
    ".env", ".cfg", ".ini", ".toml",
}


class CodeChunk:
    __slots__ = ("id", "path", "content", "start_line", "end_line", "language", "hash")

    def __init__(self, id: str, path: str, content: str, start_line: int, end_line: int, language: str, hash: str):
        self.id = id
        self.path = path
        self.content = content
        self.start_line = start_line
        self.end_line = end_line
        self.language = language
        self.hash = hash


def chunk_file(filepath: str, content: str, language: str = "") -> list[CodeChunk]:
    chunks = []
    lines = content.split("\n")
    start = 0
    chunk_idx = 0

    while start < len(lines):
        end = min(start + CHUNK_SIZE, len(lines))
        chunk_text = "\n".join(lines[start:end])
        chunk_hash = hashlib.sha256(chunk_text.encode()).hexdigest()[:16]
        chunk_id = f"{filepath}:{start}:{chunk_hash}"

        chunks.append(CodeChunk(
            id=chunk_id,
            path=filepath,
            content=chunk_text,
            start_line=start + 1,
            end_line=end,
            language=language,
            hash=chunk_hash,
        ))

        start += CHUNK_SIZE - CHUNK_OVERLAP
        chunk_idx += 1

        if end >= len(lines):
            break

    return chunks


class SemanticSearch:
    def __init__(self, persist_dir: str = None):
        self.persist_dir = persist_dir or str(DATA_DIR / "chroma")
        self._collection = None
        self._client = None
        self._embedding_fn = None
        self._is_available = False
        self._init_chroma()

    def _init_chroma(self):
        try:
            import chromadb
            self._client = chromadb.PersistentClient(path=self.persist_dir)
            self._is_available = True
        except ImportError:
            self._is_available = False
        except Exception:
            self._is_available = False

    def _get_or_create_collection(self, name: str = "deltacode_code"):
        if not self._is_available:
            return None

        from chromadb.utils.embedding_functions import DefaultEmbeddingFunction
        self._embedding_fn = DefaultEmbeddingFunction()

        try:
            collection = self._client.get_collection(name=name, embedding_function=self._embedding_fn)
        except Exception:
            collection = self._client.create_collection(
                name=name,
                embedding_function=self._embedding_fn,
                metadata={"hnsw:space": "cosine"},
            )
        self._collection = collection
        return collection

    def index_directory(self, directory: str, force: bool = False) -> dict:
        if not self._is_available:
            return {"indexed": 0, "error": "chromadb not available"}

        collection = self._get_or_create_collection()
        if not collection:
            return {"indexed": 0, "error": "failed to create collection"}

        dir_path = Path(directory).resolve()
        if not dir_path.exists():
            return {"indexed": 0, "error": f"directory not found: {directory}"}

        ext_to_lang = {
            ".py": "python", ".js": "javascript", ".ts": "typescript",
            ".java": "java", ".go": "go", ".rb": "ruby", ".php": "php",
            ".c": "c", ".cpp": "cpp", ".rs": "rust", ".cs": "csharp",
        }

        skip_dirs = {
            ".git", "node_modules", "__pycache__", ".venv", "venv",
            ".env", "dist", "build", ".tox", ".mypy_cache", ".pytest_cache",
            "site-packages", ".deltacode", ".aider",
        }

        chunks = []
        files_processed = 0

        for filepath in sorted(dir_path.rglob("*")):
            if not filepath.is_file():
                continue
            if filepath.stat().st_size > 512 * 1024:
                continue
            if filepath.suffix.lower() not in SUPPORTED_EXTENSIONS:
                continue
            if any(part in skip_dirs for part in filepath.parts):
                continue

            try:
                content = filepath.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            rel_path = str(filepath.relative_to(dir_path)).replace("\\", "/")
            language = ext_to_lang.get(filepath.suffix.lower(), "")
            file_chunks = chunk_file(rel_path, content, language)
            chunks.extend(file_chunks)
            files_processed += 1

        if not chunks:
            return {"indexed": 0, "files_processed": 0, "error": "no supported files found"}

        if force:
            try:
                self._client.delete_collection(name="deltacode_code")
            except Exception:
                pass
            collection = self._get_or_create_collection()

        batch_size = 100
        for i in range(0, len(chunks), batch_size):
            batch = chunks[i:i + batch_size]
            ids = [c.id for c in batch]
            documents = [c.content for c in batch]
            metadatas = [
                {"path": c.path, "start_line": c.start_line, "end_line": c.end_line, "language": c.language, "hash": c.hash}
                for c in batch
            ]

            try:
                collection.upsert(ids=ids, documents=documents, metadatas=metadatas)
            except Exception as e:
                logger.warning(f"Failed to index batch {i}: {e}")

        return {
            "indexed": len(chunks),
            "files_processed": files_processed,
            "directory": str(dir_path),
        }

    def search(self, query: str, n_results: int = 10, category: str = None) -> list[dict]:
        if not self._is_available:
            return []

        collection = self._collection or self._get_or_create_collection()
        if not collection:
            return []

        where_filter = None
        if category:
            where_filter = {"language": category}

        try:
            results = collection.query(
                query_texts=[query],
                n_results=n_results,
                where=where_filter,
            )
        except Exception as e:
            logger.warning(f"Search failed: {e}")
            return []

        search_results = []
        ids = results.get("ids", [[]])[0]
        documents = results.get("documents", [[]])[0]
        metadatas = results.get("metadatas", [[]])[0]
        distances = results.get("distances", [[]])[0]

        for i, doc_id in enumerate(ids):
            result = {
                "id": doc_id,
                "content": documents[i] if i < len(documents) else "",
                "path": metadatas[i].get("path", "") if i < len(metadatas) else "",
                "start_line": metadatas[i].get("start_line", 0) if i < len(metadatas) else 0,
                "end_line": metadatas[i].get("end_line", 0) if i < len(metadatas) else 0,
                "language": metadatas[i].get("language", "") if i < len(metadatas) else "",
                "distance": distances[i] if i < len(distances) else 0,
            }
            search_results.append(result)

        return search_results

    def search_vulnerabilities(self, directory: str, query: str = "security vulnerability", n_results: int = 20) -> list[dict]:
        results = self.search(query, n_results=n_results)
        if not results and self._is_available:
            try:
                self.index_directory(directory)
                results = self.search(query, n_results=n_results)
            except Exception:
                pass

        from deltacode.core.context_builder import SecurityContextBuilder
        builder = SecurityContextBuilder(directory)
        sec_info_map = {}
        scan_result = builder.scan_directory()
        for f in scan_result.get("files", []):
            sec_info_map[f["path"]] = f

        enriched = []
        for r in results:
            path = r.get("path", "")
            sec_info = sec_info_map.get(path, {})
            r["security_score"] = sec_info.get("score", 0)
            r["security_categories"] = sec_info.get("categories", [])
            r["hotspot_count"] = sec_info.get("hotspots", 0)
            enriched.append(r)

        enriched.sort(key=lambda x: x.get("security_score", 0), reverse=True)
        return enriched

    def get_stats(self) -> dict:
        if not self._is_available or not self._collection:
            return {"available": False}

        try:
            count = self._collection.count()
            return {"available": True, "document_count": count}
        except Exception:
            return {"available": True, "document_count": 0}