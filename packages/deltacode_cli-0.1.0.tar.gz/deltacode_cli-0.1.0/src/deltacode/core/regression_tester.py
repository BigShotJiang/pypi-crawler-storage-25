"""Regression testing module for DeltaCode CLI.

Automates before/after comparison when fixes are applied:
- Captures test output pre-fix and post-fix
- Compares pass/fail counts
- Detects regressions (previously passing tests that now fail)
- Reports detailed diffs per test
"""

from __future__ import annotations

import json
import subprocess
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class TestResult:
    test_name: str
    passed: bool
    output: str = ""
    duration_ms: int = 0


@dataclass
class RegressionResult:
    test_suite: str
    before_passed: int = 0
    before_failed: int = 0
    after_passed: int = 0
    after_failed: int = 0
    regressions: list = field(default_factory=list)
    improvements: list = field(default_factory=list)
    total_duration_ms: int = 0


class RegressionTester:
    def __init__(self, project_path: str = "."):
        self.project_path = Path(project_path).resolve()

    def run_test_suite(self, test_command: str = "pytest", timeout: int = 300) -> TestResult:
        try:
            start = time.time()
            result = subprocess.run(
                test_command.split(),
                capture_output=True, text=True, timeout=timeout,
                cwd=str(self.project_path),
            )
            duration = int((time.time() - start) * 1000)
            passed = result.returncode == 0

            if test_command == "pytest" and not passed:
                failed_lines = [l for l in result.stdout.split("\n") if "FAILED" in l]
                output = "\n".join(failed_lines[:20]) if failed_lines else result.stdout[:1000]
            else:
                output = (result.stdout or result.stderr)[:1000]

            return TestResult(
                test_name=test_command,
                passed=passed,
                output=output,
                duration_ms=duration,
            )
        except subprocess.TimeoutExpired:
            return TestResult(test_name=test_command, passed=False, output="Timed out", duration_ms=timeout * 1000)
        except FileNotFoundError:
            return TestResult(test_name=test_command, passed=False, output="Test command not found")
        except Exception as e:
            return TestResult(test_name=test_command, passed=False, output=str(e))

    def run_regression_check(self, before_result: TestResult, after_result: TestResult) -> RegressionResult:
        result = RegressionResult(test_suite=before_result.test_name)

        if before_result.passed:
            result.before_passed = 1
        else:
            result.before_failed = 1

        if after_result.passed:
            result.after_passed = 1
        else:
            result.after_failed = 1

        if before_result.passed and not after_result.passed:
            result.regressions.append({
                "test": before_result.test_name,
                "before": "passed",
                "after": "failed",
                "output": after_result.output[:300],
            })
        elif not before_result.passed and after_result.passed:
            result.improvements.append({
                "test": before_result.test_name,
                "before": "failed",
                "after": "passed",
            })

        result.total_duration_ms = before_result.duration_ms + after_result.duration_ms
        return result

    def format_report(self, result: RegressionResult) -> str:
        parts = [f"# Regression Test Report"]
        parts.append(f"Suite: {result.test_suite}")
        parts.append("")
        parts.append(f"Before: {result.before_passed} passed / {result.before_failed} failed")
        parts.append(f"After:  {result.after_passed} passed / {result.after_failed} failed")
        parts.append(f"Duration: {result.total_duration_ms}ms")
        parts.append("")

        if result.regressions:
            parts.append(f"## Regressions ({len(result.regressions)})")
            for r in result.regressions:
                parts.append(f"  🔴 {r['test']}: {r['before']} → {r['after']}")
                if r.get("output"):
                    parts.append(f"     {r['output'][:200]}")
        else:
            parts.append("✅ No regressions detected")

        if result.improvements:
            parts.append(f"\n## Improvements ({len(result.improvements)})")
            for r in result.improvements:
                parts.append(f"  🟢 {r['test']}: {r['before']} → {r['after']}")

        return "\n".join(parts)