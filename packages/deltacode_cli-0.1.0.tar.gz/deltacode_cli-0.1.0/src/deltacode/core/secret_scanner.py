"""Secret detection scanner for DeltaCode CLI.

Combines:
- TruffleHog integration (git history scanning)
- GitLeaks integration (regex + entropy-based detection)
- Enhanced regex patterns for AWS, GCP, Azure, GitHub, Stripe, etc.
- Private key detection
- Certificate detection
- Entropy-based detection for unknown secrets
"""

import os
import re
import math
import subprocess
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class SecretFinding:
    type: str
    category: str
    severity: str
    file: str
    line: int
    match: str
    description: str
    confidence: float = 0.8
    scanner: str = "deltacode"


SECRET_PATTERNS = {
    "aws_access_key": {
        "pattern": r'(?:AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}',
        "description": "AWS Access Key ID",
        "severity": "CRITICAL",
        "category": "cloud_credential",
    },
    "aws_secret_key": {
        "pattern": r'(?:aws_secret_access_key|AWS_SECRET_ACCESS_KEY)\s*[=:]\s*[A-Za-z0-9/+=]{40}',
        "description": "AWS Secret Access Key",
        "severity": "CRITICAL",
        "category": "cloud_credential",
    },
    "gcp_service_account": {
        "pattern": r'"{type\s*:\s*"service_account"[^}]*private_key[^}]*}"',
        "description": "GCP Service Account JSON",
        "severity": "CRITICAL",
        "category": "cloud_credential",
    },
    "gcp_api_key": {
        "pattern": r'AIza[A-Za-z0-9_\\-]{35}',
        "description": "GCP API Key",
        "severity": "HIGH",
        "category": "cloud_credential",
    },
    "azure_connection_string": {
        "pattern": r'DefaultEndpointsProtocol=https?;AccountName=[^;]+;AccountKey=[^;]+;',
        "description": "Azure Storage Connection String",
        "severity": "CRITICAL",
        "category": "cloud_credential",
    },
    "azure_tenant": {
        "pattern": r'(?:tenant|AZURE_TENANT_ID)\s*[=:]\s*[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
        "description": "Azure Tenant ID with context",
        "severity": "MEDIUM",
        "category": "cloud_credential",
    },
    "github_token": {
        "pattern": r'(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{36,}',
        "description": "GitHub Personal Access Token",
        "severity": "CRITICAL",
        "category": "vcs_token",
    },
    "gitlab_token": {
        "pattern": r'glpat-[A-Za-z0-9\-]{20,}',
        "description": "GitLab Personal Access Token",
        "severity": "CRITICAL",
        "category": "vcs_token",
    },
    "slack_token": {
        "pattern": r'xox[bporsa]-[0-9]{10,13}-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24,34}',
        "description": "Slack Token",
        "severity": "HIGH",
        "category": "messaging_token",
    },
    "slack_webhook": {
        "pattern": r'https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[A-Za-z0-9]+',
        "description": "Slack Webhook URL",
        "severity": "MEDIUM",
        "category": "messaging_token",
    },
    "stripe_key": {
        "pattern": r'(?:sk|pk)_(?:test|live)_[A-Za-z0-9]{24,}',
        "description": "Stripe API Key",
        "severity": "CRITICAL",
        "category": "payment_credential",
    },
    "paypal_token": {
        "pattern": r'(?:PAYID|PAYPAL)[-A-Za-z0-9]+',
        "description": "PayPal Token",
        "severity": "HIGH",
        "category": "payment_credential",
    },
    "sendgrid_key": {
        "pattern": r'SG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43}',
        "description": "SendGrid API Key",
        "severity": "HIGH",
        "category": "email_credential",
    },
    "mailgun_key": {
        "pattern": r'key-[0-9a-z]{32,}',
        "description": "Mailgun API Key",
        "severity": "HIGH",
        "category": "email_credential",
    },
    "twilio_key": {
        "pattern": r'SK[A-Za-z0-9]{32}',
        "description": "Twilio API Key",
        "severity": "HIGH",
        "category": "communication_credential",
    },
    "twilio_account_sid": {
        "pattern": r'AC[a-z0-9]{32}',
        "description": "Twilio Account SID",
        "severity": "MEDIUM",
        "category": "communication_credential",
    },
    "heroku_key": {
        "pattern": r'(?:HEROKU_API_KEY|heroku_api_key)\s*[=:]\s*[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
        "description": "Heroku API Key",
        "severity": "HIGH",
        "category": "cloud_credential",
    },
    "private_key": {
        "pattern": r'-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----',
        "description": "Private Key",
        "severity": "CRITICAL",
        "category": "key_material",
    },
    "certificate": {
        "pattern": r'-----BEGIN CERTIFICATE-----',
        "description": "X.509 Certificate",
        "severity": "MEDIUM",
        "category": "key_material",
    },
    "jwt_token": {
        "pattern": r'eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+',
        "description": "JSON Web Token",
        "severity": "HIGH",
        "category": "auth_token",
    },
    "generic_password": {
        "pattern": r'(?:password|passwd|pwd)\s*[=:]\s*["\'][^"\']{6,}["\']',
        "description": "Hardcoded password",
        "severity": "HIGH",
        "category": "credential",
    },
    "generic_api_key": {
        "pattern": r'(?:api[_-]?key|apikey|API_KEY|API_SECRET)\s*[=:]\s*["\'][A-Za-z0-9_\-]{20,}["\']',
        "description": "Hardcoded API key",
        "severity": "HIGH",
        "category": "credential",
    },
    "generic_secret": {
        "pattern": r'(?:SECRET_KEY|secret_key|auth_token|AUTH_TOKEN|ACCESS_TOKEN)\s*[=:]\s*["\'][A-Za-z0-9_\-]{16,}["\']',
        "description": "Hardcoded secret/token",
        "severity": "HIGH",
        "category": "credential",
    },
    "database_url": {
        "pattern": r'(?:mongodb|postgres|mysql|redis|mssql)://[^\s"\']+: [^\s"\']+@[^\s"\']+',
        "description": "Database connection string with credentials",
        "severity": "CRITICAL",
        "category": "database_credential",
    },
    "db_url_encoded": {
        "pattern": r'(?:mongodb|postgres|mysql|redis|mssql)://[^\s"\']+%40[^\s"\']+',
        "description": "Database URL with encoded credentials",
        "severity": "CRITICAL",
        "category": "database_credential",
    },
    "django_secret": {
        "pattern": r'SECRET_KEY\s*=\s*["\'][^"\']{32,}["\']',
        "description": "Django SECRET_KEY",
        "severity": "HIGH",
        "category": "framework_secret",
    },
    "flask_secret": {
        "pattern": r'(?:FLASK_SECRET_KEY|SECRET_KEY)\s*=\s*["\'][^"\']{8,}["\']',
        "description": "Flask SECRET_KEY",
        "severity": "HIGH",
        "category": "framework_secret",
    },
    "env_file_var": {
        "pattern": r'(?:DATABASE_URL|REDIS_URL|SMTP_URL|MONGO_URI)\s*=\s*[a-z+]+://[^\s#]+:[^\s#]+@[^\s#]+',
        "description": "Environment variable with embedded credentials",
        "severity": "MEDIUM",
        "category": "credential",
    },
}

FALSE_POSITIVE_PATTERNS = [
    r'(?i)(?:example|test|dummy|fake|placeholder|sample|xxx|changeme|todo|fixme)',
    r'(?i)(?:your[_-]?(?:api|secret|key)|my[_-]?(?:api|secret|key)|<your|<insert)',
    r'(?i)(?:xxx+|redacted|\[REDACTED\]|\*\*\*|\.\.\.)',
    r'^\s*#',
    r'^\s*//',
    r'(?i)none|null|undefined|""',
    r'(?i)\b(localhost|127\.0\.0\.1|0\.0\.0\.0)\b',
    r'(?i)\b(test|spec|mock|fixture|example)\b',
    r'(?i)\b(DEFAULT_|default_)',
]

SKIP_DIRECTORIES = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", "venv",
    ".env", "dist", "build", ".tox", ".mypy_cache", ".pytest_cache",
    "site-packages", ".eggs", "eggs", ".aider", ".deltacode",
    ".idea", ".vscode", "vendor", ".gradle", "target",
}

SKIP_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg", ".mp4", ".mp3",
    ".wav", ".avi", ".mov", ".wmv", ".pdf", ".zip", ".tar", ".gz",
    ".rar", ".7z", ".exe", ".dll", ".so", ".dylib", ".o", ".obj",
    ".pyc", ".pyo", ".class", ".jar", ".war", ".woff", ".woff2",
    ".ttf", ".eot", ".map",
}

SKIP_FILENAMES = {
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml", "Gemfile.lock",
    "Cargo.lock", "go.sum", ".gitmodules", "poetry.lock", "Pipfile.lock",
}


class SecretScanner:
    def __init__(self, root_path: str = ".", entropy_threshold: float = 4.5):
        self.root_path = Path(root_path).resolve()
        self.entropy_threshold = entropy_threshold
        self._compiled_patterns = {}
        self._compiled_false_positives = []
        self._compile_patterns()

    def _compile_patterns(self):
        for name, info in SECRET_PATTERNS.items():
            try:
                self._compiled_patterns[name] = (re.compile(info["pattern"]), info)
            except re.error:
                pass
        for pattern in FALSE_POSITIVE_PATTERNS:
            try:
                self._compiled_false_positives.append(re.compile(pattern))
            except re.error:
                pass

    def scan(self, use_trufflehog: bool = True, use_gitleaks: bool = True, scan_entropy: bool = True) -> dict:
        findings = []

        regex_findings = self._scan_with_regex()
        findings.extend(regex_findings)

        if use_trufflehog and self._tool_available("trufflehog"):
            th_findings = self._scan_trufflehog()
            existing_matches = {(f.file, f.line, f.type) for f in findings}
            for f in th_findings:
                if (f.file, f.line, f.type) not in existing_matches:
                    findings.append(f)

        if use_gitleaks and self._tool_available("gitleaks"):
            gl_findings = self._scan_gitleaks()
            existing_matches = {(f.file, f.line, f.type) for f in findings}
            for f in gl_findings:
                if (f.file, f.line, f.type) not in existing_matches:
                    findings.append(f)

        if scan_entropy:
            entropy_findings = self._scan_entropy()
            existing_matches = {(f.file, f.line) for f in findings}
            for f in entropy_findings:
                if (f.file, f.line) not in existing_matches:
                    findings.append(f)

        findings.sort(key=lambda f: {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}.get(f.severity, 4))

        return {
            "findings": findings,
            "total": len(findings),
            "by_severity": {
                "CRITICAL": sum(1 for f in findings if f.severity == "CRITICAL"),
                "HIGH": sum(1 for f in findings if f.severity == "HIGH"),
                "MEDIUM": sum(1 for f in findings if f.severity == "MEDIUM"),
                "LOW": sum(1 for f in findings if f.severity == "LOW"),
            },
            "by_category": dict(Counter(f.category for f in findings)),
            "scanners_used": list(set(f.scanner for f in findings)),
        }

    def _scan_with_regex(self) -> list[SecretFinding]:
        findings = []

        for filepath in self._iter_files():
            try:
                content = filepath.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            lines = content.splitlines()
            for line_idx, line in enumerate(lines):
                if self._is_false_positive(line):
                    continue

                for name, (compiled, info) in self._compiled_patterns.items():
                    for match in compiled.finditer(line):
                        match_text = match.group()
                        if self._is_false_positive_match(match_text, name):
                            continue

                        findings.append(SecretFinding(
                            type=name,
                            category=info["category"],
                            severity=info["severity"],
                            file=str(filepath.relative_to(self.root_path)),
                            line=line_idx + 1,
                            match=self._mask_secret(match_text, name),
                            description=info["description"],
                            confidence=0.9,
                            scanner="deltacode_regex",
                        ))

        return findings

    def _scan_entropy(self) -> list[SecretFinding]:
        findings = []
        high_entropy_pattern = re.compile(r'["\']([A-Za-z0-9+/=_\-]{20,})["\']')

        for filepath in self._iter_files():
            try:
                content = filepath.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            lines = content.splitlines()
            for line_idx, line in enumerate(lines):
                if self._is_false_positive(line):
                    continue

                for match in high_entropy_pattern.finditer(line):
                    candidate = match.group(1)
                    entropy = self._calculate_entropy(candidate)

                    if entropy >= self.entropy_threshold:
                        findings.append(SecretFinding(
                            type="high_entropy_string",
                            category="potential_secret",
                            severity="MEDIUM",
                            file=str(filepath.relative_to(self.root_path)),
                            line=line_idx + 1,
                            match=self._mask_secret(match.group()),
                            description=f"High entropy string (entropy: {entropy:.2f})",
                            confidence=min(0.5 + (entropy - self.entropy_threshold) * 0.1, 0.95),
                            scanner="deltacode_entropy",
                        ))

        return findings

    def _scan_trufflehog(self) -> list[SecretFinding]:
        try:
            result = subprocess.run(
                ["trufflehog", "filesystem", "--json", str(self.root_path)],
                capture_output=True, text=True, timeout=300,
            )

            findings = []
            for line in result.stdout.splitlines():
                try:
                    import json
                    data = json.loads(line)
                    findings.append(SecretFinding(
                        type=data.get("DetectorType", "trufflehog"),
                        category="external_scanner",
                        severity=self._trufflehog_severity(data),
                        file=data.get("SourceMetadata", {}).get("File", ""),
                        line=data.get("SourceMetadata", {}).get("Line", 0),
                        match=self._mask_secret(data.get("Raw", "")[:60]),
                        description=data.get("DetectorType", "Secret detected by TruffleHog"),
                        confidence=0.95,
                        scanner="trufflehog",
                    ))
                except (json.JSONDecodeError, Exception):
                    continue
            return findings

        except subprocess.TimeoutExpired:
            return []
        except Exception:
            return []

    def _scan_gitleaks(self) -> list[SecretFinding]:
        try:
            result = subprocess.run(
                ["gitleaks", "detect", "--source", str(self.root_path), "--report-format", "json", "--no-git"],
                capture_output=True, text=True, timeout=300,
            )

            try:
                import json
                data = json.loads(result.stdout)
            except (json.JSONDecodeError, Exception):
                return []

            findings = []
            for leak in data:
                findings.append(SecretFinding(
                    type=leak.get("RuleID", "gitleaks"),
                    category="external_scanner",
                    severity=self._gitleaks_severity(leak.get("RuleID", "")),
                    file=leak.get("File", ""),
                    line=leak.get("StartLine", 0),
                    match=self._mask_secret(leak.get("Secret", "")[:60]),
                    description=f"GitLeaks: {leak.get('RuleID', 'unknown rule')}",
                    confidence=0.9,
                    scanner="gitleaks",
                ))
            return findings

        except subprocess.TimeoutExpired:
            return []
        except Exception:
            return []

    def _is_false_positive(self, line: str) -> bool:
        stripped = line.strip()
        if stripped.startswith("#") or stripped.startswith("//") or stripped.startswith("*"):
            return True
        if any(fp.match(stripped) for fp in self._compiled_false_positives):
            return True
        return False

    def _is_false_positive_match(self, match_text: str, pattern_name: str) -> bool:
        lower = match_text.lower()
        for fp_pattern in FALSE_POSITIVE_PATTERNS:
            if re.search(fp_pattern, lower):
                return True
        return False

    def _mask_secret(self, secret: str, pattern_name: str = "") -> str:
        if pattern_name in ("private_key", "certificate"):
            return secret[:30] + "..."
        if pattern_name == "jwt_token":
            parts = secret.split(".")
            if len(parts) == 3:
                return f"{parts[0]}.{parts[1]}.[REDACTED]"
        if len(secret) > 20:
            return secret[:8] + "..." + secret[-4:]
        if len(secret) > 8:
            return secret[:4] + "..." + secret[-2:]
        return "[REDACTED]"

    @staticmethod
    def _calculate_entropy(data: str) -> float:
        if not data:
            return 0.0
        counter = Counter(data)
        length = len(data)
        entropy = 0.0
        for count in counter.values():
            p = count / length
            if p > 0:
                entropy -= p * math.log2(p)
        return entropy

    @staticmethod
    def _trufflehog_severity(data: dict) -> str:
        detector = data.get("DetectorType", "").lower()
        critical_detectors = ["aws", "private_key", "gcp", "azure"]
        high_detectors = ["github", "gitlab", "slack", "stripe"]
        if any(c in detector for c in critical_detectors):
            return "CRITICAL"
        if any(h in detector for h in high_detectors):
            return "HIGH"
        return "MEDIUM"

    @staticmethod
    def _gitleaks_severity(rule_id: str) -> str:
        critical_rules = ["aws", "private-key", "gcp", "azure"]
        high_rules = ["github", "gitlab", "slack", "stripe", "sendgrid"]
        rule_lower = rule_id.lower()
        if any(c in rule_lower for c in critical_rules):
            return "CRITICAL"
        if any(h in rule_lower for h in high_rules):
            return "HIGH"
        return "MEDIUM"

    def _iter_files(self):
        for filepath in sorted(self.root_path.rglob("*")):
            if not filepath.is_file():
                continue
            if filepath.suffix.lower() in SKIP_EXTENSIONS:
                continue
            if filepath.name in SKIP_FILENAMES:
                continue
            if any(part in SKIP_DIRECTORIES for part in filepath.parts):
                continue
            try:
                if filepath.stat().st_size > 512 * 1024:
                    continue
            except OSError:
                continue
            yield filepath

    @staticmethod
    def _tool_available(tool_name: str) -> bool:
        try:
            result = subprocess.run(
                [tool_name, "--version"],
                capture_output=True, text=True, timeout=10,
            )
            return result.returncode == 0
        except Exception:
            return False

    def format_findings(self, results: dict, brief: bool = False) -> str:
        findings = results.get("findings", [])
        if not findings:
            return "No secrets detected."

        parts = [f"Secret Detection Results — {len(findings)} finding(s)\n"]

        by_severity = results.get("by_severity", {})
        parts.append(f"  CRITICAL: {by_severity.get('CRITICAL', 0)} | HIGH: {by_severity.get('HIGH', 0)} | MEDIUM: {by_severity.get('MEDIUM', 0)} | LOW: {by_severity.get('LOW', 0)}")

        by_category = results.get("by_category", {})
        if by_category:
            parts.append(f"  Categories: {', '.join(f'{k}({v})' for k, v in sorted(by_category.items(), key=lambda x: -x[1]))}")

        scanners = results.get("scanners_used", [])
        if scanners:
            parts.append(f"  Scanners: {', '.join(scanners)}")

        parts.append("")

        current_file = None
        for f in findings:
            if f.file != current_file:
                current_file = f.file
                parts.append(f"\n📄 {f.file}")

            sev_icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵"}.get(f.severity, "⚪")

            if brief:
                parts.append(f"  L{f.line}: {sev_icon} {f.description}")
            else:
                parts.append(f"  L{f.line}: {sev_icon} [{f.severity}] {f.description}")
                parts.append(f"         Type: {f.type} | Category: {f.category}")
                parts.append(f"         Match: {f.match} | Confidence: {f.confidence:.0%} | Scanner: {f.scanner}")

        return "\n".join(parts)

    def quick_scan(self, use_trufflehog: bool = True, use_gitleaks: bool = True) -> str:
        results = self.scan(use_trufflehog=use_trufflehog, use_gitleaks=use_gitleaks)
        return self.format_findings(results)