"""Fixer Agent — auto-remediation application.

Applies security fixes using:
- Auto-fix engine for SEARCH/REPLACE patches
- Branch management for isolated fix branches
- Commit with security-focused messages
- Fix validation via linting
"""

from __future__ import annotations

from deltacode.core.agents.base import BaseAgent, AgentRole, AgentTaskResult
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


class FixerAgent(BaseAgent):
    def __init__(self, bus, name: str = "fixer-1"):
        super().__init__(name, AgentRole.FIXER, bus)
        self._capabilities = [
            "auto_fix", "patch_application", "branch_management",
            "security_commit", "fix_validation",
        ]

    async def execute_task(self, task: dict) -> AgentTaskResult:
        action = task.get("action", "auto_fix")

        if action == "auto_fix":
            return await self._auto_fix(task)
        elif action == "create_branch":
            return self._create_branch(task)
        elif action == "apply_patch":
            return self._apply_patch(task)
        elif action == "commit_fix":
            return self._commit_fix(task)
        elif action == "rollback":
            return self._rollback(task)
        else:
            return AgentTaskResult(agent=self.name, success=False, error=f"Unknown action: {action}")

    async def _auto_fix(self, task: dict) -> AgentTaskResult:
        from deltacode.core.auto_fix import AutoFixEngine

        engine = AutoFixEngine()
        target = task.get("target", ".")
        findings = task.get("findings", [])

        results = []
        for finding in findings:
            result = engine.fix(finding)
            results.append(result)

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={"total_attempted": len(results), "results": results},
            findings=results,
        )

    def _create_branch(self, task: dict) -> AgentTaskResult:
        from deltacode.core.git_security import SecurityGitIntegration

        git = SecurityGitIntegration(repo_path=task.get("target", "."))
        branch_name = task.get("branch_name", "")
        base = task.get("base", "main")

        result = git.create_security_branch(branch_name=branch_name, base=base)

        return AgentTaskResult(
            agent=self.name,
            success=result.get("created", result.get("branch", "")),
            data=result,
        )

    def _apply_patch(self, task: dict) -> AgentTaskResult:
        from deltacode.core.auto_fix import AutoFixEngine

        engine = AutoFixEngine()
        patch_content = task.get("patch", "")
        target_file = task.get("file", "")

        result = engine.apply_patch(patch_content, target_file)

        return AgentTaskResult(
            agent=self.name,
            success=result.get("success", False),
            data=result,
            error=result.get("error", ""),
        )

    def _commit_fix(self, task: dict) -> AgentTaskResult:
        from deltacode.core.git_security import SecurityGitIntegration

        git = SecurityGitIntegration(repo_path=task.get("target", "."))
        findings = task.get("findings", [])

        result = git.commit_with_security_message(paths=task.get("paths"), findings=findings)

        return AgentTaskResult(
            agent=self.name,
            success=result.get("committed", False),
            data=result,
            error=result.get("error", ""),
        )

    def _rollback(self, task: dict) -> AgentTaskResult:
        from deltacode.core.git_security import SecurityGitIntegration

        git = SecurityGitIntegration(repo_path=task.get("target", "."))
        branch_name = task.get("branch", "")

        if branch_name:
            result = git.delete_security_branch(branch_name)
        else:
            result = {"error": "No branch specified"}

        return AgentTaskResult(
            agent=self.name,
            success=result.get("deleted", False),
            data=result,
        )