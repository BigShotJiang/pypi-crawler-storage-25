"""Coordinator Agent — orchestration and delegation.

Orchestrates the full security workflow:
- Receives assessment requests
- Decomposes into sub-tasks
- Delegates to appropriate agents
- Aggregates results
- Manages approval gates
"""

from __future__ import annotations

from datetime import datetime

from deltacode.core.agents.base import BaseAgent, AgentRole, AgentTeam, AgentTaskResult, ApprovalLevel, AgentMessage, MessageType
from deltacode.core.assessment_planner import SecurityAssessmentPlanner
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


class CoordinatorAgent(BaseAgent):
    def __init__(self, bus, team: AgentTeam = None, name: str = "coordinator-1"):
        super().__init__(name, AgentRole.COORDINATOR, bus)
        self._team = team
        self._capabilities = [
            "workflow_planning", "task_decomposition", "agent_delegation",
            "result_aggregation", "progress_tracking", "approval_management",
        ]

    def set_team(self, team: AgentTeam):
        self._team = team

    async def execute_task(self, task: dict) -> AgentTaskResult:
        action = task.get("action", "full_assessment")

        if action == "full_assessment":
            return await self._plan_full_assessment(task)
        elif action == "analyze_and_fix":
            return await self._analyze_and_fix(task)
        elif action == "research_and_report":
            return await self._research_and_report(task)
        elif action == "compliance_check":
            return await self._compliance_check(task)
        elif action == "plan_workflow":
            return self._plan_workflow(task)
        else:
            return AgentTaskResult(agent=self.name, success=False, error=f"Unknown action: {action}")

    async def _plan_full_assessment(self, task: dict) -> AgentTaskResult:
        target = task.get("target", ".")
        plan_name = task.get("name", "Full Assessment")

        planner = SecurityAssessmentPlanner(project_path=target)
        plan = planner.create_assessment_plan(plan_name)

        sub_tasks = []
        for t in plan.tasks:
            sub_tasks.append({
                "agent": "analyzer-1",
                "action": "scan",
                "target": target,
                "category": t.category,
                "cwe": t.cwe,
                "description": t.title,
                "steps": t.steps,
            })

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={
                "plan_name": plan_name,
                "sub_tasks": sub_tasks,
                "total_tasks": len(sub_tasks),
                "estimated_hours": plan.summary.get("estimated_hours", 0),
                "attack_surface_risk": plan.summary.get("attack_surface_risk", 0),
            },
        )

    async def _analyze_and_fix(self, task: dict) -> AgentTaskResult:
        target = task.get("target", ".")
        findings = task.get("findings", [])

        if not findings:
            analyzer = self._team.get_agent("analyzer-1") if self._team else None
            if analyzer:
                scan_result = await analyzer.execute_task({"action": "scan", "target": target})
                findings = scan_result.findings

        workflow = [
            {"agent": "analyzer-1", "action": "classify", "target": target, "findings": findings},
            {"agent": "fixer-1", "action": "auto_fix", "target": target, "findings": findings[:5]},
            {"agent": "validator-1", "action": "validate_fix", "target": target, "findings": findings[:5]},
        ]

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={
                "workflow": workflow,
                "total_findings": len(findings),
                "fix_targets": len(findings[:5]),
                "note": "Run workflow sub_tasks sequentially for full analyze-fix-validate pipeline",
            },
        )

    async def _research_and_report(self, task: dict) -> AgentTaskResult:
        query = task.get("query", task.get("target", ""))

        workflow = [
            {"agent": "researcher-1", "action": "research_cve", "cve_id": query},
        ]
        if task.get("include_rss", True):
            workflow.append({"agent": "researcher-1", "action": "rss_feeds"})

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={"workflow": workflow, "query": query, "total_sub_tasks": len(workflow)},
        )

    async def _compliance_check(self, task: dict) -> AgentTaskResult:
        findings = task.get("findings", [])
        frameworks = task.get("frameworks", ["soc2", "iso27001"])

        workflow = [
            {"agent": "compliance-1", "action": "map_findings", "findings": findings, "frameworks": frameworks},
            {"agent": "compliance-1", "action": "gap_analysis", "findings": findings},
            {"agent": "compliance-1", "action": "generate_report", "findings": findings, "frameworks": frameworks},
        ]

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={
                "workflow": workflow,
                "total_findings": len(findings),
                "frameworks": frameworks,
                "total_sub_tasks": len(workflow),
            },
        )

    def _plan_workflow(self, task: dict) -> AgentTaskResult:
        workflow_type = task.get("workflow", "full_assessment")
        target = task.get("target", ".")

        workflows = {
            "full_assessment": {
                "description": "Complete security assessment (scan, research, fix, validate, compliance)",
                "phases": [
                    {"name": "Analysis", "parallel": True, "tasks": [
                        {"agent": "analyzer-1", "action": "scan", "target": target},
                        {"agent": "researcher-1", "action": "rss_feeds"},
                    ]},
                    {"name": "Classification", "tasks": [
                        {"agent": "analyzer-1", "action": "classify"},
                    ]},
                    {"name": "Remediation", "tasks": [
                        {"agent": "fixer-1", "action": "auto_fix"},
                    ]},
                    {"name": "Validation", "tasks": [
                        {"agent": "validator-1", "action": "validate_fix"},
                    ]},
                    {"name": "Compliance", "tasks": [
                        {"agent": "compliance-1", "action": "gap_analysis"},
                    ]},
                ],
            },
            "quick_scan": {
                "description": "Quick scan and report (no fixes)",
                "phases": [
                    {"name": "Scan", "tasks": [{"agent": "analyzer-1", "action": "scan", "target": target}]},
                    {"name": "Classify", "tasks": [{"agent": "analyzer-1", "action": "classify"}]},
                ],
            },
        }

        selected = workflows.get(workflow_type, workflows["full_assessment"])

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={
                "workflow_type": workflow_type,
                "description": selected["description"],
                "phases": selected["phases"],
                "total_phases": len(selected["phases"]),
                "requires_approval": True,
            },
        )