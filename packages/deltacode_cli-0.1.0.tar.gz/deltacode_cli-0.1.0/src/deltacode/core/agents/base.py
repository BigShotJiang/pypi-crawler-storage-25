"""Core multi-agent framework for DeltaCode CLI.

Architecture:
- BaseAgent: abstract base with lifecycle, capabilities registry
- AgentMessage: typed message passing between agents
- MessageBus: pub/sub message routing
- AgentTeam: orchestrates agent lifecycle and workflow
- AgentTaskResult: standardized task output

Safety controls:
- Human-in-the-loop gates for critical actions
- Approval workflows for destructive operations
- Action logging and audit trails
- Blast radius limitation
- Emergency stop mechanism
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


class AgentRole(Enum):
    ANALYZER = "analyzer"
    RESEARCHER = "researcher"
    FIXER = "fixer"
    VALIDATOR = "validator"
    COMPLIANCE = "compliance"
    COORDINATOR = "coordinator"


class MessageType(Enum):
    TASK_ASSIGN = "task_assign"
    TASK_RESULT = "task_result"
    TASK_PROGRESS = "task_progress"
    FINDING_REPORT = "finding_report"
    APPROVAL_REQUEST = "approval_request"
    APPROVAL_RESPONSE = "approval_response"
    EMERGENCY_STOP = "emergency_stop"
    STATUS_REQUEST = "status_request"
    STATUS_RESPONSE = "status_response"
    LOG = "log"
    ERROR = "error"
    CONFLICT_DETECTED = "conflict_detected"
    CONFLICT_RESOLUTION = "conflict_resolution"
    DECISION_REVIEW = "decision_review"
    DECISION_RESULT = "decision_result"


class ApprovalLevel(Enum):
    NONE = 0
    LOG_ONLY = 1
    NOTIFY = 2
    REQUIRED = 3


@dataclass
class AgentMessage:
    id: str = ""
    type: MessageType = MessageType.LOG
    sender: str = ""
    recipient: str = ""
    payload: dict = field(default_factory=dict)
    timestamp: str = ""
    requires_approval: bool = False
    approval_level: ApprovalLevel = ApprovalLevel.NONE

    def __post_init__(self):
        if not self.id:
            self.id = uuid.uuid4().hex[:12]
        if not self.timestamp:
            self.timestamp = datetime.utcnow().isoformat()


@dataclass
class AgentTaskResult:
    task_id: str = ""
    agent: str = ""
    success: bool = False
    data: Any = None
    error: str = ""
    findings: list = field(default_factory=list)
    duration_ms: int = 0
    requires_human_review: bool = False
    human_review_notes: str = ""
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.utcnow().isoformat()

    def to_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "agent": self.agent,
            "success": self.success,
            "data": self.data,
            "error": self.error,
            "findings": self.findings,
            "duration_ms": self.duration_ms,
            "requires_human_review": self.requires_human_review,
        }


class SafetyController:
    def __init__(self):
        self._emergency_stop = False
        self._approval_queue: list[AgentMessage] = []
        self._decision_queue: list[AgentMessage] = []
        self._action_log: list[dict] = []
        self._hitl_gates: dict[str, ApprovalLevel] = {}

    def register_gate(self, action: str, level: ApprovalLevel):
        self._hitl_gates[action] = level

    def check_action(self, action: str, agent: str) -> ApprovalLevel:
        return self._hitl_gates.get(action, ApprovalLevel.NONE)

    def request_approval(self, message: AgentMessage) -> bool:
        if self._emergency_stop:
            return False
        level = self.check_action(message.payload.get("action", ""), message.sender)
        if level == ApprovalLevel.NONE:
            return True
        if level == ApprovalLevel.LOG_ONLY:
            self._action_log.append({
                "action": message.payload.get("action", ""),
                "agent": message.sender,
                "timestamp": message.timestamp,
                "approved": True,
            })
            return True
        if level == ApprovalLevel.NOTIFY:
            logger.info(f"Agent {message.sender} performing: {message.payload.get('action', '')}")
            return True
        if level == ApprovalLevel.REQUIRED:
            self._approval_queue.append(message)
            return False
        return True

    def approve(self, message_id: str) -> bool:
        for msg in self._approval_queue:
            if msg.id == message_id:
                self._approval_queue.remove(msg)
                self._action_log.append({
                    "action": msg.payload.get("action", ""),
                    "agent": msg.sender,
                    "timestamp": msg.timestamp,
                    "approved": True,
                    "approved_at": datetime.utcnow().isoformat(),
                })
                return True
        return False

    def reject(self, message_id: str) -> bool:
        for msg in self._approval_queue:
            if msg.id == message_id:
                self._approval_queue.remove(msg)
                return True
        return False

    def submit_decision(self, message: AgentMessage):
        self._decision_queue.append(message)

    def review_decisions(self) -> list[AgentMessage]:
        return list(self._decision_queue)

    def resolve_decision(self, message_id: str, outcome: str) -> bool:
        for msg in self._decision_queue:
            if msg.id == message_id:
                self._decision_queue.remove(msg)
                self._action_log.append({
                    "type": "decision_resolved",
                    "message_id": message_id,
                    "outcome": outcome,
                    "timestamp": datetime.utcnow().isoformat(),
                })
                return True
        return False

    def emergency_stop(self):
        self._emergency_stop = True
        logger.warning("EMERGENCY STOP ACTIVATED")

    def resume(self):
        self._emergency_stop = False
        logger.info("System resumed after emergency stop")

    @property
    def is_stopped(self) -> bool:
        return self._emergency_stop

    @property
    def pending_approvals(self) -> list[AgentMessage]:
        return list(self._approval_queue)

    @property
    def action_log(self) -> list[dict]:
        return list(self._action_log)


class MessageBus:
    def __init__(self):
        self._subscribers: dict[str, list[Callable]] = {}
        self._history: list[AgentMessage] = []
        self._safety = SafetyController()

    def subscribe(self, agent_name: str, handler: Callable):
        if agent_name not in self._subscribers:
            self._subscribers[agent_name] = []
        self._subscribers[agent_name].append(handler)

    def publish(self, message: AgentMessage):
        self._history.append(message)

        if not self._safety.check_action(message):
            logger.warning(f"Message {message.id} blocked by safety controller")
            return

        if message.recipient and message.recipient in self._subscribers:
            for handler in self._subscribers[message.recipient]:
                try:
                    handler(message)
                except Exception as e:
                    logger.error(f"Handler error for {message.recipient}: {e}")

        if message.type == MessageType.EMERGENCY_STOP:
            self._safety.emergency_stop()

    def broadcast(self, message: AgentMessage, exclude: str = None):
        for agent_name in self._subscribers:
            if agent_name == exclude:
                continue
            msg = AgentMessage(
                type=message.type,
                sender=message.sender,
                recipient=agent_name,
                payload=message.payload,
            )
            self.publish(msg)

    def get_history(self, agent: str = None, limit: int = 50) -> list[AgentMessage]:
        if agent:
            return [m for m in self._history if m.sender == agent or m.recipient == agent][-limit:]
        return self._history[-limit:]

    @property
    def safety(self) -> SafetyController:
        return self._safety


class BaseAgent(ABC):
    def __init__(self, name: str, role: AgentRole, bus: MessageBus):
        self.name = name
        self.role = role
        self.bus = bus
        self._capabilities: list[str] = []
        self._status = "idle"
        self._task_history: list[AgentTaskResult] = []
        self._start_time = time.time()

        bus.subscribe(name, self._handle_message)

    @abstractmethod
    async def execute_task(self, task: dict) -> AgentTaskResult:
        ...

    def get_capabilities(self) -> list[str]:
        return self._capabilities

    def get_status(self) -> dict:
        return {
            "name": self.name,
            "role": self.role.value,
            "status": self._status,
            "tasks_completed": len(self._task_history),
            "uptime_seconds": int(time.time() - self._start_time),
        }

    def _handle_message(self, message: AgentMessage):
        if message.type == MessageType.STATUS_REQUEST:
            self.bus.publish(AgentMessage(
                type=MessageType.STATUS_RESPONSE,
                sender=self.name,
                recipient=message.sender,
                payload=self.get_status(),
            ))
        elif message.type == MessageType.EMERGENCY_STOP:
            self._status = "stopped"
            logger.warning(f"Agent {self.name} received emergency stop")

    async def run_task(self, task: dict) -> AgentTaskResult:
        if self.bus.safety.is_stopped:
            return AgentTaskResult(
                agent=self.name,
                success=False,
                error="Emergency stop active",
            )

        self._status = "running"
        start = time.time()

        try:
            result = await self.execute_task(task)
            result.duration_ms = int((time.time() - start) * 1000)
            result.agent = self.name

            self.bus.publish(AgentMessage(
                type=MessageType.TASK_RESULT,
                sender=self.name,
                payload=result.to_dict(),
            ))

        except Exception as e:
            result = AgentTaskResult(
                agent=self.name,
                success=False,
                error=str(e),
                duration_ms=int((time.time() - start) * 1000),
            )

        self._task_history.append(result)
        self._status = "idle"
        return result


class AgentTeam:
    def __init__(self, name: str = "security-team"):
        self.name = name
        self.bus = MessageBus()
        self._agents: dict[str, BaseAgent] = {}
        self._coordinator: Optional[BaseAgent] = None
        self._safety = self.bus.safety
        self._register_default_gates()

    def _register_default_gates(self):
        self._safety.register_gate("apply_fix", ApprovalLevel.REQUIRED)
        self._safety.register_gate("create_branch", ApprovalLevel.NOTIFY)
        self._safety.register_gate("push_changes", ApprovalLevel.REQUIRED)
        self._safety.register_gate("delete_code", ApprovalLevel.REQUIRED)
        self._safety.register_gate("run_exploit", ApprovalLevel.REQUIRED)
        self._safety.register_gate("external_scan", ApprovalLevel.NOTIFY)
        self._safety.register_gate("install_dependency", ApprovalLevel.NOTIFY)

    def register_agent(self, agent: BaseAgent):
        self._agents[agent.name] = agent
        logger.info(f"Agent registered: {agent.name} ({agent.role.value})")
        if agent.role == AgentRole.COORDINATOR:
            self._coordinator = agent

    def get_agent(self, name: str) -> Optional[BaseAgent]:
        return self._agents.get(name)

    def get_agents_by_role(self, role: AgentRole) -> list[BaseAgent]:
        return [a for a in self._agents.values() if a.role == role]

    async def run_workflow(self, workflow: str, params: dict = None) -> list[AgentTaskResult]:
        results = []

        if self._coordinator:
            plan_task = {"workflow": workflow, "params": params or {}}
            plan_result = await self._coordinator.run_task(plan_task)
            results.append(plan_result)

            sub_tasks = plan_result.data if plan_result.success else []
            for task in sub_tasks if isinstance(sub_tasks, list) else []:
                agent_name = task.get("agent", "")
                agent = self._agents.get(agent_name)
                if not agent:
                    continue

                action = task.get("action", "")
                approval = self._safety.check_action(action, agent_name)
                if approval == ApprovalLevel.REQUIRED:
                    approval_msg = AgentMessage(
                        type=MessageType.APPROVAL_REQUEST,
                        sender=agent_name,
                        recipient="human",
                        payload={"action": action, "task": task},
                        requires_approval=True,
                        approval_level=approval,
                    )
                    self.bus.publish(approval_msg)
                    logger.warning(f"Approval required for {agent_name}: {action}")
                    continue

                sub_result = await agent.run_task(task)
                results.append(sub_result)

        return results

    def request_status(self) -> dict:
        return {
            "team": self.name,
            "agents": [a.get_status() for a in self._agents.values()],
            "pending_approvals": len(self._safety.pending_approvals),
            "emergency_stop": self._safety.is_stopped,
            "total_messages": len(self.bus.get_history()),
        }

    def emergency_stop(self):
        self._safety.emergency_stop()

    def resume(self):
        self._safety.resume()

    # ── Conflict Resolution ───────────────────────────────────────────
    def detect_conflicts(self, results: list[AgentTaskResult]) -> list[dict]:
        conflicts = []
        for i, a in enumerate(results):
            for j, b in enumerate(results):
                if i >= j:
                    continue
                if not a.success or not b.success:
                    continue
                a_findings = {(f.get("file", ""), f.get("type", "")) for f in (a.findings or []) if isinstance(f, dict)}
                b_findings = {(f.get("file", ""), f.get("type", "")) for f in (b.findings or []) if isinstance(f, dict)}
                overlap = a_findings & b_findings
                if overlap:
                    conflicts.append({
                        "agents": [a.agent, b.agent],
                        "overlapping_findings": list(overlap)[:5],
                        "count": len(overlap),
                        "resolution": "pending",
                    })
                    msg = AgentMessage(
                        type=MessageType.CONFLICT_DETECTED,
                        sender="coordinator",
                        payload={"agents": [a.agent, b.agent], "overlap_count": len(overlap)},
                    )
                    self.bus.publish(msg)
        return conflicts

    def resolve_conflict(self, conflict: dict, resolution: str) -> bool:
        conflict["resolution"] = resolution
        conflict["resolved_at"] = datetime.utcnow().isoformat()
        msg = AgentMessage(
            type=MessageType.CONFLICT_RESOLUTION,
            sender="coordinator",
            payload=conflict,
        )
        self.bus.publish(msg)
        return True

    # ── Decision Review ────────────────────────────────────────────────
    def submit_for_review(self, title: str, description: str, payload: dict = None) -> str:
        msg = AgentMessage(
            type=MessageType.DECISION_REVIEW,
            sender="coordinator",
            recipient="human",
            payload={
                "title": title,
                "description": description,
                "data": payload or {},
            },
        )
        self._safety.submit_decision(msg)
        return msg.id

    def get_pending_decisions(self) -> list[dict]:
        return [
            {"id": m.id, "title": m.payload.get("title", ""), "description": m.payload.get("description", "")[:100]}
            for m in self._safety.review_decisions()
        ]

    def resolve_decision(self, decision_id: str, outcome: str) -> bool:
        return self._safety.resolve_decision(decision_id, outcome)

    # ── Audit Trail ────────────────────────────────────────────────────
    def get_action_log(self, limit: int = 100) -> list[dict]:
        return self._safety.action_log[-limit:]

    def get_audit_trail(self) -> list[dict]:
        history = self.bus.get_history(limit=200)
        return [
            {
                "id": m.id,
                "type": m.type.value,
                "sender": m.sender,
                "recipient": m.recipient,
                "timestamp": m.timestamp,
                "summary": str(m.payload)[:100],
            }
            for m in history
        ]