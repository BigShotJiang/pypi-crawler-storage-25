"""Analyzer Agent — vulnerability detection and classification.

Detects security issues using:
- Static analysis (semgrep, bandit, CodeQL, custom rules)
- Secret scanning
- Dependency analysis
- Context builder hotspot detection
"""

from __future__ import annotations

from deltacode.core.agents.base import BaseAgent, AgentRole, AgentTaskResult, AgentMessage, MessageType
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


class AnalyzerAgent(BaseAgent):
    def __init__(self, bus, name: str = "analyzer-1"):
        super().__init__(name, AgentRole.ANALYZER, bus)
        self._capabilities = [
            "static_analysis", "secret_scanning", "dependency_analysis",
            "hotspot_detection", "cwe_classification", "severity_scoring",
        ]
        self._linter = None
        self._scanner = None
        self._dep_analyzer = None

    async def execute_task(self, task: dict) -> AgentTaskResult:
        action = task.get("action", "scan")
        target = task.get("target", ".")

        if action == "scan":
            return await self._run_full_scan(target, task)
        elif action == "static_analysis":
            return await self._run_static_analysis(target, task)
        elif action == "secret_scan":
            return await self._run_secret_scan(target, task)
        elif action == "dependency_check":
            return await self._run_dependency_check(target, task)
        elif action == "classify":
            return self._classify_findings(task.get("findings", []))
        else:
            return AgentTaskResult(agent=self.name, success=False, error=f"Unknown action: {action}")

    async def _run_full_scan(self, target: str, task: dict) -> AgentTaskResult:
        from deltacode.core.context_builder import SecurityContextBuilder

        builder = SecurityContextBuilder(root_path=target)
        context = builder.scan_directory()
        entry_points = builder.detect_entry_points()
        dep_graph = builder.build_dependency_graph()

        findings = []
        for f in context.get("files", []):
            findings.append({
                "type": "high_risk_file",
                "file": f.get("path", ""),
                "score": f.get("score", 0),
                "categories": f.get("categories", []),
                "hotspot_count": f.get("hotspots", 0),
                "severity": "HIGH" if f.get("score", 0) >= 50 else "MEDIUM" if f.get("score", 0) >= 20 else "LOW",
            })

        requires_review = len([f for f in findings if f.get("severity") == "HIGH"]) > 10

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={
                "target": target,
                "findings": findings[:50],
                "entry_points": entry_points[:20],
                "dependency_graph": dep_graph,
                "summary": context.get("summary", {}),
                "total_files_scanned": context.get("total_files_scanned", 0),
            },
            findings=findings[:50],
            requires_human_review=requires_review,
        )

    async def _run_static_analysis(self, target: str, task: dict) -> AgentTaskResult:
        from deltacode.core.security_linter import SecurityLinter

        linter = SecurityLinter(root=target)
        findings = []
        files = task.get("files", [])

        for fname in files:
            result = linter.security_scan(fname)
            if result:
                findings.append({"file": fname, "result": result})

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={"total_files": len(files), "findings_with_issues": len(findings)},
            findings=findings,
        )

    async def _run_secret_scan(self, target: str, task: dict) -> AgentTaskResult:
        from deltacode.core.secret_scanner import SecretScanner

        scanner = SecretScanner(root_path=target)
        results = scanner.scan(
            use_trufflehog=task.get("use_trufflehog", True),
            use_gitleaks=task.get("use_gitleaks", True),
            scan_entropy=task.get("scan_entropy", True),
        )

        secrets = results.get("findings", [])
        critical = sum(1 for s in secrets if s.severity == "CRITICAL")

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={
                "total_findings": results.get("total", 0),
                "by_severity": results.get("by_severity", {}),
                "scanners_used": results.get("scanners_used", []),
            },
            findings=[{"type": "secret", "file": s.file, "severity": s.severity, "description": s.description} for s in secrets[:50]],
            requires_human_review=critical > 0,
        )

    async def _run_dependency_check(self, target: str, task: dict) -> AgentTaskResult:
        from deltacode.core.dependency_analyzer import DependencyAnalyzer

        analyzer = DependencyAnalyzer(root_path=str(target))
        analyzer.detect_ecosystems()
        reports = analyzer.analyze(check_licenses=task.get("check_licenses", False))

        findings = []
        for r in reports:
            for v in r.vulnerabilities:
                findings.append({
                    "type": "dependency_vuln",
                    "package": v.package,
                    "version": v.version,
                    "vuln_id": v.vuln_id,
                    "severity": v.severity,
                    "ecosystem": v.ecosystem,
                })

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={"ecosystems": list(analyzer.detect_ecosystems().keys()), "reports": len(reports)},
            findings=findings,
        )

    def _classify_findings(self, findings: list) -> AgentTaskResult:
        from deltacode.core.best_practices import search_cwe

        classified = []
        for f in findings:
            cwe_results = search_cwe(f.get("description", ""))
            cwe_id = cwe_results[0].cwe_id if cwe_results else "CWE-unknown"
            cwe_name = cwe_results[0].name if cwe_results else "Unknown"
            classified.append({**f, "cwe_id": cwe_id, "cwe_name": cwe_name})

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={"classified": len(classified), "findings": classified},
            findings=classified,
        )