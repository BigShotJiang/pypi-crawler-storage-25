"""Validator Agent — testing and verification.

Validates fixes using:
- Lint checks after fix application
- Regression test execution
- Security scanner re-runs on patched code
- Comparison with baseline
"""

from __future__ import annotations

from deltacode.core.agents.base import BaseAgent, AgentRole, AgentTaskResult
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


class ValidatorAgent(BaseAgent):
    def __init__(self, bus, name: str = "validator-1"):
        super().__init__(name, AgentRole.VALIDATOR, bus)
        self._capabilities = [
            "lint_validation", "security_re_scan", "regression_check",
            "baseline_comparison", "fix_verification",
        ]

    async def execute_task(self, task: dict) -> AgentTaskResult:
        action = task.get("action", "validate")

        if action == "validate_fix":
            return await self._validate_fix(task)
        elif action == "lint_check":
            return await self._lint_check(task)
        elif action == "regression_test":
            return await self._regression_test(task)
        elif action == "baseline_compare":
            return self._baseline_compare(task)
        else:
            return AgentTaskResult(agent=self.name, success=False, error=f"Unknown action: {action}")

    async def _validate_fix(self, task: dict) -> AgentTaskResult:
        findings = task.get("findings", [])
        target = task.get("target", ".")

        validation_results = []
        for f in findings:
            file_path = f.get("file", "")
            if not file_path:
                continue

            lint_result = await self._lint_file(file_path)
            sev_result = await self._rescan_file(file_path)

            passed = True
            if lint_result and "ERROR" in lint_result:
                passed = False

            validation_results.append({
                "file": file_path,
                "passed": passed,
                "issues": f,
                "lint_output": lint_result[:500] if lint_result else "",
                "re_scan_output": sev_result[:500] if sev_result else "",
            })

        all_passed = all(v.get("passed", False) for v in validation_results)

        return AgentTaskResult(
            agent=self.name,
            success=all_passed,
            data={
                "total_validated": len(validation_results),
                "passed": sum(1 for v in validation_results if v.get("passed")),
                "failed": sum(1 for v in validation_results if not v.get("passed")),
                "results": validation_results,
            },
            requires_human_review=not all_passed,
        )

    async def _lint_check(self, task: dict) -> AgentTaskResult:
        target = task.get("target", ".")
        files = task.get("files", [])

        results = []
        for f in files:
            result = await self._lint_file(f)
            if result:
                results.append({"file": f, "output": result[:500]})

        return AgentTaskResult(
            agent=self.name,
            success=len(results) == 0,
            data={"files_checked": len(files), "files_with_issues": len(results), "results": results},
        )

    async def _lint_file(self, file_path: str) -> str:
        import subprocess
        try:
            ext = file_path.split(".")[-1].lower()
            if ext == "py":
                result = subprocess.run(["python", "-m", "py_compile", file_path], capture_output=True, text=True, timeout=30)
                return result.stderr if result.returncode != 0 else ""
            return ""
        except Exception:
            return ""

    async def _rescan_file(self, file_path: str) -> str:
        from deltacode.core.security_linter import SecurityLinter

        linter = SecurityLinter(root=".")
        result = linter.security_scan(file_path)
        return result or ""

    async def _regression_test(self, task: dict) -> AgentTaskResult:
        target = task.get("target", ".")
        test_command = task.get("test_command", "pytest")

        import subprocess
        try:
            result = subprocess.run(
                test_command.split(),
                capture_output=True, text=True, timeout=120,
                cwd=target,
            )
            passed = result.returncode == 0
            return AgentTaskResult(
                agent=self.name,
                success=passed,
                data={
                    "command": test_command,
                    "passed": passed,
                    "output": (result.stdout or result.stderr)[:1000],
                    "return_code": result.returncode,
                },
                requires_human_review=not passed,
            )
        except subprocess.TimeoutExpired:
            return AgentTaskResult(
                agent=self.name,
                success=False,
                error="Test execution timed out",
                data={"command": test_command, "timed_out": True},
            )
        except Exception as e:
            return AgentTaskResult(agent=self.name, success=False, error=str(e))

    def _baseline_compare(self, task: dict) -> AgentTaskResult:
        from deltacode.core.git_security import SecurityGitIntegration

        git = SecurityGitIntegration(repo_path=task.get("target", "."))
        baseline_name = task.get("baseline", "")

        if baseline_name:
            result = git.compare_with_baseline(baseline_name)
        else:
            baselines = git.list_baselines()
            if baselines:
                result = git.compare_with_baseline(baselines[0]["name"])
            else:
                result = {"error": "No baselines found"}

        return AgentTaskResult(
            agent=self.name,
            success="error" not in result,
            data=result,
        )