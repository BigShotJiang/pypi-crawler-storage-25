"""Compliance Agent — regulatory checking.

Maps findings to compliance frameworks:
- SOC 2, ISO 27001, PCI-DSS, HIPAA
- CWE-to-compliance control mapping
- Compliance gap analysis
- Evidence collection
"""

from __future__ import annotations

from deltacode.core.agents.base import BaseAgent, AgentRole, AgentTaskResult
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


CWE_TO_COMPLIANCE = {
    "CWE-89": {"soc2": "CC6.1", "pci_dss": "6.5.1", "iso27001": "A.14.2.5", "hipaa": "Technical Safeguards: Access Control"},
    "CWE-78": {"soc2": "CC6.1", "pci_dss": "6.5.1", "iso27001": "A.14.2.5"},
    "CWE-79": {"soc2": "CC6.1", "pci_dss": "6.5.7", "iso27001": "A.14.2.5"},
    "CWE-287": {"soc2": "CC6.2", "pci_dss": "8.3", "iso27001": "A.9.4.2", "hipaa": "Technical Safeguards: Access Control"},
    "CWE-798": {"soc2": "CC6.3", "pci_dss": "8.2.1", "iso27001": "A.9.2.1"},
    "CWE-327": {"soc2": "CC6.3", "pci_dss": "6.5.3", "iso27001": "A.10.1.1", "hipaa": "Technical Safeguards: Transmission Security"},
    "CWE-200": {"soc2": "CC6.1", "pci_dss": "6.5.5", "iso27001": "A.13.2.1", "hipaa": "Technical Safeguards: Integrity Controls"},
    "CWE-352": {"soc2": "CC6.1", "pci_dss": "6.5.5", "iso27001": "A.14.2.5"},
    "CWE-502": {"soc2": "CC6.1", "pci_dss": "6.5.1", "iso27001": "A.14.2.5"},
    "CWE-918": {"soc2": "CC6.1", "pci_dss": "6.5.1", "iso27001": "A.13.1.1"},
    "CWE-22": {"soc2": "CC6.1", "pci_dss": "6.5.4", "iso27001": "A.14.2.5"},
    "CWE-256": {"soc2": "CC6.3", "pci_dss": "8.2.1", "iso27001": "A.9.4.3"},
    "CWE-330": {"soc2": "CC6.3", "pci_dss": "6.5.3", "iso27001": "A.10.1.2"},
    "CWE-611": {"soc2": "CC6.1", "pci_dss": "6.5.1", "iso27001": "A.14.2.5"},
}

COMPLIANCE_FRAMEWORKS = {
    "soc2": {"name": "SOC 2", "version": "2023"},
    "pci_dss": {"name": "PCI-DSS", "version": "4.0"},
    "iso27001": {"name": "ISO 27001", "version": "2022"},
    "hipaa": {"name": "HIPAA", "version": "2013"},
}


class ComplianceAgent(BaseAgent):
    def __init__(self, bus, name: str = "compliance-1"):
        super().__init__(name, AgentRole.COMPLIANCE, bus)
        self._capabilities = [
            "compliance_mapping", "gap_analysis", "evidence_collection",
            "framework_checklist", "compliance_report",
        ]

    async def execute_task(self, task: dict) -> AgentTaskResult:
        action = task.get("action", "map_findings")

        if action == "map_findings":
            return self._map_findings(task)
        elif action == "gap_analysis":
            return self._gap_analysis(task)
        elif action == "generate_report":
            return self._generate_report(task)
        elif action == "checklist":
            return self._checklist(task)
        else:
            return AgentTaskResult(agent=self.name, success=False, error=f"Unknown action: {action}")

    def _map_findings(self, task: dict) -> AgentTaskResult:
        findings = task.get("findings", [])
        frameworks = task.get("frameworks", ["soc2", "iso27001", "pci_dss"])

        mapped = []
        for f in findings:
            cwe = f.get("cwe", f.get("cwe_id", ""))
            if cwe in CWE_TO_COMPLIANCE:
                control_map = CWE_TO_COMPLIANCE[cwe]
                applicable = {k: v for k, v in control_map.items() if k in frameworks}
                mapped.append({
                    **f,
                    "compliance_controls": applicable,
                    "frameworks_affected": list(applicable.keys()),
                })
            else:
                mapped.append({**f, "compliance_controls": {}, "frameworks_affected": []})

        affected = set()
        for m in mapped:
            affected.update(m.get("frameworks_affected", []))
        affected_count = {fw: sum(1 for m in mapped if fw in m.get("frameworks_affected", [])) for fw in affected}

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={
                "total_mapped": len(mapped),
                "with_compliance_impact": sum(1 for m in mapped if m.get("frameworks_affected")),
                "affected_frameworks": dict(affected_count),
                "findings": mapped,
            },
            findings=mapped,
        )

    def _gap_analysis(self, task: dict) -> AgentTaskResult:
        framework = task.get("framework", "soc2")
        findings = task.get("findings", [])

        framework_info = COMPLIANCE_FRAMEWORKS.get(framework, {})
        mapped = [f for f in findings if f.get("cwe", f.get("cwe_id", "")) in CWE_TO_COMPLIANCE]
        unmapped = [f for f in findings if f not in mapped]

        total_controls = len(CWE_TO_COMPLIANCE)
        covered_controls = set()
        for m in mapped:
            cwe = m.get("cwe", m.get("cwe_id", ""))
            if cwe in CWE_TO_COMPLIANCE and framework in CWE_TO_COMPLIANCE[cwe]:
                covered_controls.add(CWE_TO_COMPLIANCE[cwe][framework])

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={
                "framework": framework,
                "framework_name": framework_info.get("name", framework),
                "total_findings": len(findings),
                "mapped_to_compliance": len(mapped),
                "unmapped": len(unmapped),
                "compliance_coverage": f"{len(covered_controls)}/{total_controls} controls",
                "coverage_pct": round(len(covered_controls) / total_controls * 100, 1) if total_controls else 0,
            },
            requires_human_review=len(unmapped) > 5,
        )

    def _generate_report(self, task: dict) -> AgentTaskResult:
        findings = task.get("findings", [])
        frameworks = task.get("frameworks", ["soc2", "iso27001", "pci_dss"])

        mapped_result = self._map_findings({"findings": findings, "frameworks": frameworks})
        mapped_data = mapped_result.data

        report_parts = ["# Compliance Assessment Report\n"]
        report_parts.append(f"Generated: {__import__('datetime').datetime.utcnow().isoformat()}")
        report_parts.append(f"Frameworks: {', '.join(frameworks)}")
        report_parts.append(f"Total Findings: {len(findings)}")
        report_parts.append("")

        for fw in frameworks:
            fw_info = COMPLIANCE_FRAMEWORKS.get(fw, {"name": fw})
            mapped_fw = [m for m in mapped_data.get("findings", []) if fw in m.get("frameworks_affected", [])]
            report_parts.append(f"## {fw_info['name']}")
            report_parts.append(f"Affected Controls: {len(mapped_fw)}")
            for m in mapped_fw:
                controls = m.get("compliance_controls", {})
                control_id = controls.get(fw, "N/A")
                report_parts.append(f"  - {m.get('title', m.get('description', 'Finding'))} -> {control_id}")
            report_parts.append("")

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data=mapped_data,
            findings=mapped_data.get("findings", []),
        )

    def _checklist(self, task: dict) -> AgentTaskResult:
        framework = task.get("framework", "soc2")
        from deltacode.core.assessment_planner import COMPLIANCE_FRAMEWORKS as FW

        framework_data = {
            "soc2": {"name": "SOC 2", "controls": [
                "Logical and Physical Access", "User Access Management", "Data Encryption",
                "Firewall and Network Security", "Vulnerability Management",
            ]},
            "pci_dss": {"name": "PCI-DSS", "controls": [
                "Network Security Controls", "Secure Configuration", "Stored Data Protection",
                "Encryption of Cardholder Data", "Malware Protection",
            ]},
            "iso27001": {"name": "ISO 27001", "controls": [
                "Information Security Policies", "Access Control", "Cryptography",
                "Operations Security", "Communications Security",
            ]},
        }

        selected = framework_data.get(framework, framework_data["soc2"])

        checklist = []
        for control in selected["controls"]:
            checklist.append({
                "control": control,
                "status": "not_assessed",
                "evidence_required": True,
            })

        return AgentTaskResult(
            agent=self.name,
            success=True,
            data={
                "framework": selected["name"],
                "controls": checklist,
                "total_controls": len(checklist),
                "assessed": 0,
                "remaining": len(checklist),
            },
        )