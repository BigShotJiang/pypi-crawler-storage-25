"""Researcher Agent — threat intelligence gathering.

Researches CVEs, vulnerabilities, and security advisories using:
- Browser agent for web research
- CVE/NVD API queries
- Vendor advisory scraping
- RSS feed aggregation
"""

from __future__ import annotations

import asyncio
from datetime import datetime

from deltacode.core.agents.base import BaseAgent, AgentRole, AgentTaskResult
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


class ResearcherAgent(BaseAgent):
    def __init__(self, bus, name: str = "researcher-1"):
        super().__init__(name, AgentRole.RESEARCHER, bus)
        self._capabilities = [
            "cve_research", "vendor_advisory_scrape", "rss_aggregation",
            "threat_intel_query", "exploit_status_check",
        ]

    async def execute_task(self, task: dict) -> AgentTaskResult:
        action = task.get("action", "research")

        if action == "research_cve":
            return await self._research_cve(task)
        elif action == "vendor_advisory":
            return await self._vendor_advisory(task)
        elif action == "rss_feeds":
            return self._rss_feeds(task)
        elif action == "threat_intel":
            return await self._threat_intel(task)
        elif action == "bulk_research":
            return await self._bulk_research(task)
        else:
            return AgentTaskResult(agent=self.name, success=False, error=f"Unknown action: {action}")

    async def _research_cve(self, task: dict) -> AgentTaskResult:
        cve_id = task.get("cve_id", task.get("query", "")).strip().upper()

        from deltacode.core.security_researcher import SecurityResearcher

        researcher = SecurityResearcher()
        try:
            result = await researcher.research_cve(cve_id)
            await researcher.close()

            return AgentTaskResult(
                agent=self.name,
                success=True,
                data={
                    "cve_id": cve_id,
                    "citations": [{"url": c.url, "title": c.title} for c in result.citations],
                    "findings": result.findings,
                },
                findings=result.findings,
            )
        except Exception as e:
            return AgentTaskResult(agent=self.name, success=False, error=str(e))

    async def _vendor_advisory(self, task: dict) -> AgentTaskResult:
        vendor = task.get("vendor", "")

        from deltacode.core.security_researcher import SecurityResearcher

        researcher = SecurityResearcher()
        try:
            result = await researcher.scrape_vendor_advisories(vendor)
            await researcher.close()

            return AgentTaskResult(
                agent=self.name,
                success=True,
                data={"vendor": vendor, "findings": result.findings},
                findings=result.findings,
            )
        except Exception as e:
            return AgentTaskResult(agent=self.name, success=False, error=str(e))

    def _rss_feeds(self, task: dict) -> AgentTaskResult:
        feeds = task.get("feeds", [])

        from deltacode.core.security_researcher import SecurityResearcher

        researcher = SecurityResearcher()
        try:
            result = researcher.read_rss_feeds(feeds if feeds else None)

            return AgentTaskResult(
                agent=self.name,
                success=True,
                data={"sources": len(feeds) if feeds else "all", "findings": result.findings},
                findings=result.findings,
            )
        except Exception as e:
            return AgentTaskResult(agent=self.name, success=False, error=str(e))

    async def _threat_intel(self, task: dict) -> AgentTaskResult:
        technique_id = task.get("technique_id", "")
        query = task.get("query", "")

        from deltacode.core.mcp_server import MCPServer
        from deltacode.core.mcp_connectors.threat_intel import ThreatIntelConnector

        server = MCPServer()
        server.register_connector(ThreatIntelConnector())

        if technique_id:
            result = server.handle_request({
                "tool": "threat_intel.get_technique_details",
                "params": {"technique_id": technique_id},
            })
        elif query:
            result = server.handle_request({
                "tool": "threat_intel.search_techniques",
                "params": {"keyword": query},
            })
        else:
            return AgentTaskResult(agent=self.name, success=False, error="Provide technique_id or query")

        return AgentTaskResult(
            agent=self.name,
            success=result.get("success", False),
            data=result.get("data", {}),
            findings=[result.get("data", {})] if result.get("success") else [],
            error=result.get("error", "") if not result.get("success") else "",
        )

    async def _bulk_research(self, task: dict) -> AgentTaskResult:
        queries = task.get("queries", [task.get("query", "")])
        if isinstance(queries, str):
            queries = [queries]

        from deltacode.core.security_researcher import SecurityResearcher

        researcher = SecurityResearcher()
        try:
            all_results = []
            all_findings = []
            for q in queries[:5]:
                result = await researcher.full_research(q)
                all_results.append({"query": q, "findings": result.findings})
                all_findings.extend(result.findings)

            await researcher.close()
            return AgentTaskResult(
                agent=self.name,
                success=True,
                data={"total_queries": len(queries), "results": all_results},
                findings=all_findings,
            )
        except Exception as e:
            return AgentTaskResult(agent=self.name, success=False, error=str(e))