"""MCP (Model Context Protocol) server framework for DeltaCode CLI.

Provides a standardized way for LLMs to interact with security tools
through tool registration, discovery, and execution.

Architecture:
  - MCPRequest / MCPResponse: standard message envelope
  - MCPTool: base class for all tools
  - MCPConnector: groups related tools under one connector
  - MCPServer: orchestrates connectors, handles requests
  - Transport: supports stdio and HTTP modes
"""

from __future__ import annotations

import json
import sys
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class MCPRequest:
    id: str
    tool: str
    params: dict = field(default_factory=dict)
    context: dict = field(default_factory=dict)


@dataclass
class MCPResponse:
    id: str
    success: bool
    data: Any = None
    error: str = ""
    mime_type: str = "text/plain"


@dataclass
class MCPToolDef:
    name: str
    description: str
    input_schema: dict
    handler: Callable
    category: str = ""
    required_license: str = ""


@dataclass
class MCPConnectorInfo:
    name: str
    description: str
    version: str = "1.0.0"


class MCPTool(ABC):
    @abstractmethod
    def execute(self, params: dict, context: dict = None) -> MCPResponse:
        ...

    @abstractmethod
    def get_definition(self) -> MCPToolDef:
        ...


class MCPConnector(ABC):
    def __init__(self):
        self._tools: dict[str, MCPTool] = {}
        self._register_tools()

    @abstractmethod
    def _register_tools(self):
        ...

    @abstractmethod
    def get_info(self) -> MCPConnectorInfo:
        ...

    def get_tool(self, name: str) -> Optional[MCPTool]:
        return self._tools.get(name)

    def list_tools(self) -> list[MCPToolDef]:
        return [t.get_definition() for t in self._tools.values()]

    def execute_tool(self, tool_name: str, params: dict, context: dict = None) -> MCPResponse:
        tool = self.get_tool(tool_name)
        if not tool:
            return MCPResponse(
                id="", success=False,
                error=f"Tool '{tool_name}' not found in connector '{self.get_info().name}'"
            )
        return tool.execute(params, context or {})


class MCPServer:
    def __init__(self, name: str = "deltacode-mcp", version: str = "1.0.0"):
        self.name = name
        self.version = version
        self._connectors: dict[str, MCPConnector] = {}

    def register_connector(self, connector: MCPConnector):
        info = connector.get_info()
        self._connectors[info.name] = connector
        logger.info(f"MCP connector registered: {info.name} v{info.version}")

    def list_connectors(self) -> list[dict]:
        return [
            {"name": name, **conn.get_info().__dict__}
            for name, conn in self._connectors.items()
        ]

    def list_tools(self) -> list[dict]:
        all_tools = []
        for conn_name, conn in self._connectors.items():
            for tool_def in conn.list_tools():
                all_tools.append({
                    "connector": conn_name,
                    **tool_def.__dict__,
                })
        return all_tools

    def execute(self, request: MCPRequest) -> MCPResponse:
        tool_path = request.tool.split(".")
        if len(tool_path) == 2:
            conn_name, tool_name = tool_path
        else:
            for conn_name, conn in self._connectors.items():
                if conn.get_tool(request.tool):
                    break
            else:
                return MCPResponse(
                    id=request.id, success=False,
                    error=f"Tool '{request.tool}' not found. Use 'connector.tool_name' or list tools."
                )

        connector = self._connectors.get(conn_name)
        if not connector:
            return MCPResponse(
                id=request.id, success=False,
                error=f"Connector '{conn_name}' not found. Available: {list(self._connectors.keys())}"
            )

        return connector.execute_tool(tool_name, request.params, request.context)

    def handle_stdio(self):
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            try:
                raw = json.loads(line)
                request = MCPRequest(
                    id=raw.get("id", uuid.uuid4().hex[:8]),
                    tool=raw.get("tool", ""),
                    params=raw.get("params", {}),
                    context=raw.get("context", {}),
                )
                response = self.execute(request)
                sys.stdout.write(json.dumps(response.__dict__, ensure_ascii=False) + "\n")
                sys.stdout.flush()
            except json.JSONDecodeError:
                sys.stdout.write(json.dumps({
                    "id": "error", "success": False, "error": "Invalid JSON input"
                }) + "\n")
                sys.stdout.flush()
            except Exception as e:
                sys.stdout.write(json.dumps({
                    "id": "error", "success": False, "error": str(e)
                }) + "\n")
                sys.stdout.flush()

    def handle_request(self, raw: dict) -> dict:
        request = MCPRequest(
            id=raw.get("id", uuid.uuid4().hex[:8]),
            tool=raw.get("tool", ""),
            params=raw.get("params", {}),
            context=raw.get("context", {}),
        )
        response = self.execute(request)
        return response.__dict__

    def tools_list_schema(self) -> dict:
        tools = self.list_tools()
        return {
            "tools": [
                {
                    "name": t["name"],
                    "description": t["description"],
                    "input_schema": t["input_schema"],
                    "connector": t["connector"],
                }
                for t in tools
            ]
        }

    def get_info_response(self) -> dict:
        return {
            "server": self.name,
            "version": self.version,
            "connectors": self.list_connectors(),
            "total_tools": len(self.list_tools()),
        }