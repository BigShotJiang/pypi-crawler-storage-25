"""Fix effectiveness tracker for DeltaCode CLI.

Tracks:
- Fix success/failure rates per CWE category
- False positive learning (mark findings that were wrong)
- Pattern refinement over time
- Feedback loop integration from agents and humans
"""

from __future__ import annotations

import json
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class FixRecord:
    id: str
    cwe: str
    severity: str
    file: str
    fix_type: str
    applied_at: str
    success: bool
    validation_passed: bool
    rolled_back: bool = False
    duration_ms: int = 0
    error: str = ""
    reviewer_notes: str = ""
    is_false_positive: bool = False
    false_positive_reason: str = ""


@dataclass
class FalsePositiveReport:
    cwe: str
    pattern: str
    count: int
    reason: str
    first_seen: str
    last_seen: str
    suppressed: bool = False


class EffectivenessTracker:
    def __init__(self, data_dir: str = None):
        self.data_dir = Path(data_dir or Path.home() / ".deltacode" / "effectiveness")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._fixes: list[FixRecord] = []
        self._false_positives: list[FalsePositiveReport] = []
        self._load()

    def _load(self):
        fixes_file = self.data_dir / "fixes.json"
        if fixes_file.exists():
            try:
                data = json.loads(fixes_file.read_text(encoding="utf-8"))
                self._fixes = [FixRecord(**f) for f in data]
            except Exception:
                pass

        fp_file = self.data_dir / "false_positives.json"
        if fp_file.exists():
            try:
                data = json.loads(fp_file.read_text(encoding="utf-8"))
                self._false_positives = [FalsePositiveReport(**f) for f in data]
            except Exception:
                pass

    def _save(self):
        fixes_file = self.data_dir / "fixes.json"
        fixes_file.write_text(json.dumps(
            [f.__dict__ for f in self._fixes], indent=2, ensure_ascii=False
        ), encoding="utf-8")

        fp_file = self.data_dir / "false_positives.json"
        fp_file.write_text(json.dumps(
            [f.__dict__ for f in self._false_positives], indent=2, ensure_ascii=False
        ), encoding="utf-8")

    def record_fix(self, cwe: str, severity: str, file: str, fix_type: str,
                   success: bool, validation_passed: bool = False,
                   duration_ms: int = 0, error: str = "",
                   reviewer_notes: str = "") -> FixRecord:
        record = FixRecord(
            id=uuid.uuid4().hex[:12],
            cwe=cwe,
            severity=severity,
            file=file,
            fix_type=fix_type,
            applied_at=datetime.utcnow().isoformat(),
            success=success,
            validation_passed=validation_passed,
            duration_ms=duration_ms,
            error=error,
            reviewer_notes=reviewer_notes,
        )
        self._fixes.append(record)
        self._save()
        return record

    def mark_rollback(self, fix_id: str) -> bool:
        for fix in self._fixes:
            if fix.id == fix_id:
                fix.rolled_back = True
                fix.success = False
                self._save()
                return True
        return False

    def report_false_positive(self, cwe: str, pattern: str, reason: str) -> FalsePositiveReport:
        existing = [fp for fp in self._false_positives if fp.cwe == cwe and fp.pattern == pattern]
        if existing:
            existing[0].count += 1
            existing[0].last_seen = datetime.utcnow().isoformat()
            self._save()
            return existing[0]

        report = FalsePositiveReport(
            cwe=cwe,
            pattern=pattern,
            count=1,
            reason=reason,
            first_seen=datetime.utcnow().isoformat(),
            last_seen=datetime.utcnow().isoformat(),
        )
        self._false_positives.append(report)
        self._save()
        return report

    def suppress_false_positive(self, fp_index: int) -> bool:
        if 0 <= fp_index < len(self._false_positives):
            self._false_positives[fp_index].suppressed = True
            self._save()
            return True
        return False

    def get_fix_stats(self, days: int = 30) -> dict:
        cutoff = datetime.utcnow() - timedelta(days=days)
        recent = [f for f in self._fixes if datetime.fromisoformat(f.applied_at) > cutoff]

        total = len(recent)
        successful = sum(1 for f in recent if f.success)
        validated = sum(1 for f in recent if f.validation_passed)
        rolled_back = sum(1 for f in recent if f.rolled_back)
        false_positives = sum(1 for f in recent if f.is_false_positive)

        by_cwe = defaultdict(lambda: {"total": 0, "success": 0})
        for f in recent:
            by_cwe[f.cwe]["total"] += 1
            if f.success:
                by_cwe[f.cwe]["success"] += 1
        by_cwe = dict(sorted(by_cwe.items(), key=lambda x: x[1]["total"], reverse=True)[:10])

        by_severity = defaultdict(lambda: {"total": 0, "success": 0})
        for f in recent:
            by_severity[f.severity]["total"] += 1
            if f.success:
                by_severity[f.severity]["success"] += 1

        avg_duration = round(sum(f.duration_ms for f in recent) / max(total, 1))

        return {
            "period_days": days,
            "total_fixes": total,
            "success_rate": round(successful / max(total, 1) * 100, 1),
            "validation_rate": round(validated / max(total, 1) * 100, 1),
            "rollback_rate": round(rolled_back / max(total, 1) * 100, 1),
            "false_positive_rate": round(false_positives / max(total, 1) * 100, 1),
            "avg_duration_ms": avg_duration,
            "by_cwe": by_cwe,
            "by_severity": dict(by_severity),
        }

    def get_false_positive_stats(self) -> dict:
        active = [fp for fp in self._false_positives if not fp.suppressed]
        suppressed = [fp for fp in self._false_positives if fp.suppressed]
        return {
            "total_reported": sum(fp.count for fp in self._false_positives),
            "active_patterns": len(active),
            "suppressed_patterns": len(suppressed),
            "top_false_positives": sorted(
                [{"cwe": fp.cwe, "pattern": fp.pattern, "count": fp.count, "reason": fp.reason}
                 for fp in active],
                key=lambda x: -x["count"],
            )[:10],
        }

    def get_effectiveness_summary(self) -> str:
        fix_stats = self.get_fix_stats()
        fp_stats = self.get_false_positive_stats()

        lines = ["# Fix Effectiveness Report"]
        lines.append("")
        lines.append("## Fix Statistics")
        lines.append(f"Total fixes (30d): {fix_stats['total_fixes']}")
        lines.append(f"Success rate: {fix_stats['success_rate']}%")
        lines.append(f"Validation rate: {fix_stats['validation_rate']}%")
        lines.append(f"Rollback rate: {fix_stats['rollback_rate']}%")
        lines.append(f"Avg duration: {fix_stats['avg_duration_ms']}ms")
        lines.append("")
        lines.append("## By CWE")
        for cwe, data in fix_stats.get('by_cwe', {}).items():
            rate = round(data['success'] / max(data['total'], 1) * 100, 1)
            lines.append(f"  {cwe}: {data['success']}/{data['total']} ({rate}%)")
        lines.append("")
        lines.append("## False Positives")
        lines.append(f"Total reported: {fp_stats.get('total_reported', 0)}")
        lines.append(f"Active patterns: {fp_stats.get('active_patterns', 0)}")
        for fp in fp_stats.get('top_false_positives', [])[:5]:
            lines.append(f"  {fp['cwe']} ({fp['pattern']}): x{fp['count']} — {fp['reason']}")

        return "\n".join(lines)