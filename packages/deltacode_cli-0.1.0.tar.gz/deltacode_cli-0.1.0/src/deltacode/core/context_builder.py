"""Security-aware context builder for DeltaCode CLI.

Extends Aider's RepoMap concept with security ranking:
- Prioritizes files with security-relevant patterns (auth, crypto, input handling)
- Builds dependency graphs for impact analysis
- Detects security hotspots and entry points
"""

import os
import re
import subprocess
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger
from deltacode.core.prompts import SECURITY_HOTSPOT_PATTERNS

logger = get_logger(__name__)


SECURITY_FILE_PATTERNS = {
    "auth": [
        r"auth", r"login", r"session", r"token", r"credential", r"password",
        r"oauth", r"jwt", r"middleware", r"permission", r"rbac",
    ],
    "crypto": [
        r"crypto", r"cipher", r"encrypt", r"decrypt", r"hash", r"hmac",
        r"cert", r"ssl", r"tls", r"key", r"pki",
    ],
    "input": [
        r"input", r"form", r"request", r"param", r"query", r"upload",
        r"validate", r"sanitize", r"filter", r"escape",
    ],
    "config": [
        r"config", r"settings", r"env", r"secret", r"dotenv",
    ],
    "database": [
        r"model", r"schema", r"migration", r"query", r"sql", r"db",
        r"repository", r"dao", r"orm",
    ],
    "api": [
        r"route", r"endpoint", r"api", r"controller", r"handler",
        r"views?", r"resources?", r"blueprint",
    ],
    "network": [
        r"http", r"request", r"response", r"socket", r"proxy",
        r"client", r"server", r"fetch", r"axios",
    ],
}

SECURITY_PRIORITY_BOOST = {
    "auth": 50,
    "crypto": 40,
    "input": 35,
    "config": 30,
    "database": 25,
    "api": 20,
    "network": 15,
}

SUPPORTED_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".rb", ".php",
    ".c", ".cpp", ".h", ".hpp", ".rs", ".cs", ".scala", ".kt",
    ".sh", ".bash", ".yaml", ".yml", ".json", ".xml", ".dockerfile",
    ".env", ".cfg", ".ini", ".toml",
}


@dataclass
class SecurityFileInfo:
    path: str
    category_scores: dict = field(default_factory=dict)
    hotspot_matches: list = field(default_factory=list)
    total_score: float = 0.0
    imports: list = field(default_factory=list)
    imported_by: list = field(default_factory=list)
    entry_points: list = field(default_factory=list)


@dataclass
class DependencyEdge:
    source: str
    target: str
    edge_type: str = "import"


class SecurityContextBuilder:
    def __init__(self, root_path: str = ".", max_files: int = 50):
        self.root_path = Path(root_path).resolve()
        self.max_files = max_files
        self._file_cache: dict = {}
        self._dependency_graph: dict[str, set[str]] = defaultdict(set)
        self._reverse_graph: dict[str, set[str]] = defaultdict(set)
        self._security_info: dict[str, SecurityFileInfo] = {}
        self._git_history_cache: dict | None = None

    def _run_git(self, args: list[str]) -> list[str] | None:
        try:
            result = subprocess.run(
                ["git"] + args,
                capture_output=True,
                text=True,
                cwd=str(self.root_path),
                timeout=30,
            )
            if result.returncode != 0:
                return None
            return result.stdout.splitlines()
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            return None

    def analyze_git_history(self) -> dict:
        if self._git_history_cache is not None:
            return self._git_history_cache

        empty = {
            "has_git_history": False,
            "total_commits": 0,
            "security_commits": [],
            "file_security_modifications": {},
            "recent_security_files": [],
        }

        lines = self._run_git(["log", "--oneline", "--all", "-100", "--format=%H|%s|%aI"])
        if lines is None:
            self._git_history_cache = empty
            return empty

        security_pattern = re.compile(r"(fix\(security\)|fix\(cve\)|fix\(vuln\)|CVE-\d+|security)", re.I)
        security_commits = []
        file_mods: dict[str, int] = defaultdict(int)
        cutoff = datetime.now(timezone.utc) - timedelta(days=30)

        for line in lines:
            parts = line.split("|", 2)
            if len(parts) < 3:
                continue
            h, msg, date_str = parts[0], parts[1], parts[2]
            try:
                dt = datetime.fromisoformat(date_str)
            except ValueError:
                dt = datetime.now(timezone.utc)

            match = security_pattern.search(msg)
            if match:
                security_commits.append({"hash": h, "message": msg, "date": date_str})

                files_out = self._run_git(["diff-tree", "--no-commit-id", "--name-only", "-r", h])
                if files_out:
                    for fpath in files_out:
                        if fpath.strip():
                            file_mods[fpath.strip()] += 1

        recent_security_files = [
            fp for fp, count in file_mods.items()
            if any(
                sc["date"] >= cutoff.isoformat()
                for sc in security_commits
            )
        ]

        result = {
            "has_git_history": True,
            "total_commits": len(lines),
            "security_commits": security_commits,
            "file_security_modifications": dict(file_mods),
            "recent_security_files": recent_security_files,
        }
        self._git_history_cache = result
        return result

    def get_file_blame_stats(self, target_files: list = None) -> dict:
        result: dict[str, int] = {}

        if target_files is None:
            target_files = [
                str(f.relative_to(self.root_path))
                for f in sorted(self.root_path.rglob("*"))
                if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS
            ]

        for rel_path in target_files[:20]:
            lines = self._run_git(["blame", "--line-porcelain", rel_path])
            if lines is None:
                continue
            for line in lines:
                if line.startswith("author "):
                    author = line[7:].strip()
                    if author:
                        result[author] = result.get(author, 0) + 1

        return result

    def get_commit_frequency(self, days: int = 90) -> dict:
        since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        lines = self._run_git(["log", "--all", "--since", since, "--name-only", "--format=", "--diff-filter=AM"])
        if not lines:
            return {}

        frequency: dict[str, int] = defaultdict(int)
        for fpath in lines:
            stripped = fpath.strip()
            if stripped:
                frequency[stripped] += 1

        return dict(frequency)

    def scan_file_security(self, file_path: str) -> SecurityFileInfo:
        if file_path in self._security_info:
            return self._security_info[file_path]

        path = Path(file_path)
        fname = path.name.lower()
        rel_path = str(path.relative_to(self.root_path)) if path.is_relative_to(self.root_path) else str(path)

        info = SecurityFileInfo(path=rel_path)
        category_scores = {}

        for category, patterns in SECURITY_FILE_PATTERNS.items():
            score = 0
            for pattern in patterns:
                if re.search(pattern, rel_path.lower()):
                    score += SECURITY_PRIORITY_BOOST.get(category, 10)
            if score > 0:
                category_scores[category] = score

        ext = path.suffix.lower()
        lang_map = {".py": "python", ".js": "javascript", ".ts": "javascript", ".jsx": "javascript", ".tsx": "javascript"}
        lang = lang_map.get(ext)

        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            info.category_scores = category_scores
            info.total_score = sum(category_scores.values())
            self._security_info[file_path] = info
            return info

        line_count = content.count("\n") + 1
        category_scores["size"] = min(line_count / 50, 10)

        hotspot_matches = []
        if lang and lang in SECURITY_HOTSPOT_PATTERNS:
            for category, patterns in SECURITY_HOTSPOT_PATTERNS[lang].items():
                for pattern, description in patterns:
                    matches = list(re.finditer(pattern, content))
                    if matches:
                        hotspot_matches.extend([
                            {"pattern": description, "line": m.start(), "category": category}
                            for m in matches
                        ])
                        score = len(matches) * 5
                        category_scores[category] = category_scores.get(category, 0) + score

        for dangerous_pattern, desc in [
            (r'eval\s*\(', "eval usage"),
            (r'subprocess\.(call|run|Popen)\(.*shell\s*=\s*True', "shell=True"),
            (r'os\.system\s*\(', "os.system"),
            (r'innerHTML\s*=', "innerHTML"),
            (r'password\s*=\s*["\']', "hardcoded password"),
            (r'api_key\s*=\s*["\']', "hardcoded API key"),
        ]:
            matches = list(re.finditer(dangerous_pattern, content, re.I))
            if matches:
                category_scores["dangerous_pattern"] = category_scores.get("dangerous_pattern", 0) + len(matches) * 10

        imports = self._extract_imports(content, ext)

        git_data = self.analyze_git_history()
        if git_data["has_git_history"] and rel_path in git_data["recent_security_files"]:
            category_scores["git_security_history"] = 15

        info.category_scores = category_scores
        info.hotspot_matches = hotspot_matches
        info.total_score = sum(category_scores.values())
        info.imports = imports
        self._security_info[file_path] = info
        return info

    def _extract_imports(self, content: str, ext: str) -> list:
        imports = []
        patterns = {
            ".py": [r'^import\s+(\S+)', r'^from\s+(\S+)\s+import'],
            ".js": [r'(?:(?:import|require)\s*\(?[\'"]([^\'"]+)[\'"])', r'import\s+(\S+)\s+from'],
            ".ts": [r'(?:(?:import|require)\s*\(?[\'"]([^\'"]+)[\'"])', r'import\s+(\S+)\s+from'],
            ".go": [r'import\s+"([^"]+)"'],
            ".java": [r'import\s+([\w.]+);'],
            ".rb": [r'require\s+[\'"]([^\'"]+)[\'"]', r'require_relative\s+[\'"]([^\'"]+)[\'"]'],
        }
        import_patterns = patterns.get(ext, [])
        for pattern in import_patterns:
            for match in re.finditer(pattern, content, re.MULTILINE):
                imports.append(match.group(1))
        return imports

    def scan_directory(self) -> dict:
        files_info = []
        skip_dirs = {
            ".git", "node_modules", "__pycache__", ".venv", "venv",
            ".env", "dist", "build", ".tox", ".mypy_cache", ".pytest_cache",
            "site-packages", ".eggs", "eggs", ".aider", ".deltacode",
        }

        for filepath in sorted(self.root_path.rglob("*")):
            if not filepath.is_file():
                continue
            if filepath.stat().st_size > 1024 * 1024:
                continue

            parts = filepath.parts
            if any(part in skip_dirs for part in parts):
                continue

            if filepath.suffix.lower() not in SUPPORTED_EXTENSIONS:
                continue

            info = self.scan_file_security(str(filepath))
            if info.total_score > 0 or info.hotspot_matches:
                files_info.append({
                    "path": str(filepath.relative_to(self.root_path)),
                    "score": info.total_score,
                    "categories": list(info.category_scores.keys()),
                    "hotspots": len(info.hotspot_matches),
                    "imports": info.imports,
                })

        files_info.sort(key=lambda x: x["score"], reverse=True)

        return {
            "root": str(self.root_path),
            "total_files_scanned": len(self._security_info),
            "security_relevant_files": len(files_info),
            "git_history": self.analyze_git_history(),
            "files": files_info[:self.max_files],
            "summary": {
                "categories": defaultdict(int, {
                    cat: sum(1 for f in files_info if cat in f["categories"])
                    for cat in SECURITY_PRIORITY_BOOST
                }),
                "total_hotspots": sum(f["hotspots"] for f in files_info),
                "high_risk_files": sum(1 for f in files_info if f["score"] >= 50),
                "critical_files": sum(1 for f in files_info if f["score"] >= 100),
            },
        }

    def build_dependency_graph(self) -> dict:
        for file_path, info in self._security_info.items():
            for imp in info.imports:
                rel_path = str(Path(file_path).relative_to(self.root_path)) if Path(file_path).is_relative_to(self.root_path) else file_path
                for other_path, other_info in self._security_info.items():
                    other_rel = str(Path(other_path).relative_to(self.root_path)) if Path(other_path).is_relative_to(self.root_path) else other_path
                    base = Path(other_path).stem
                    if imp == base or imp.endswith(f".{base}"):
                        self._dependency_graph[rel_path].add(other_rel)
                        self._reverse_graph[other_rel].add(rel_path)

        return {
            "dependencies": {k: list(v) for k, v in self._dependency_graph.items()},
            "dependents": {k: list(v) for k, v in self._reverse_graph.items()},
        }

    def get_security_context(self, focus_files: list = None, max_tokens: int = 4000) -> str:
        scan_result = self.scan_directory()
        if not scan_result["files"]:
            return "No security-relevant files found in workspace."

        context_parts = ["# Security Context\n"]
        context_parts.append(f"Total files scanned: {scan_result['total_files_scanned']}")
        context_parts.append(f"Security-relevant files: {scan_result['security_relevant_files']}")
        context_parts.append(f"Total hotspots: {scan_result['summary']['total_hotspots']}")
        context_parts.append(f"High-risk files: {scan_result['summary']['high_risk_files']}")
        context_parts.append("")

        if focus_files:
            prioritized = []
            for f in scan_result["files"]:
                if any(fg in f["path"] for fg in focus_files):
                    prioritized.append(f)
            remaining = [f for f in scan_result["files"] if f not in prioritized]
            ordered = prioritized + remaining
        else:
            ordered = scan_result["files"]

        char_budget = max_tokens * 4
        used = 0
        for f in ordered[:self.max_files]:
            entry = f"## {f['path']} (score: {f['score']:.0f}, categories: {', '.join(f['categories'])})\n"
            if f["hotspots"] > 0:
                entry += f"   [!] {f['hotspots']} security hotspot(s)\n"
            entry += "\n"

            if used + len(entry) > char_budget:
                break
            context_parts.append(entry)
            used += len(entry)

        return "".join(context_parts)

    def detect_entry_points(self) -> list:
        entry_point_patterns = {
            ".py": [r'@app\.(?:route|get|post|put|delete|patch)\s*\(', r'urlpatterns\s*=',
                     r'APIRouter\s*\(', r'def\s+main\s*\(', r'if\s+__name__\s*==\s*["\']__main__["\']'],
            ".js": [r'app\.(?:get|post|put|delete|patch)\s*\(', r'router\.(?:get|post)\s*\(',
                     r'module\.exports\s*=', r'exports\s*=\s*\{'],
            ".go": [r'func\s+\w+\(\w+\s+\*?\w+\)\s*\{', r'http\.HandleFunc\s*\('],
            ".java": [r'@(?:GetMapping|PostMapping|RequestMapping|DeleteMapping|PutMapping)\s*\('],
        }

        entry_points = []
        for file_path, info in self._security_info.items():
            ext = Path(file_path).suffix.lower()
            if ext not in entry_point_patterns:
                continue

            try:
                content = Path(file_path).read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            for pattern in entry_point_patterns[ext]:
                for match in re.finditer(pattern, content):
                    line = content[:match.start()].count("\n") + 1
                    entry_points.append({
                        "file": str(Path(file_path).relative_to(self.root_path)) if Path(file_path).is_relative_to(self.root_path) else file_path,
                        "line": line,
                        "match": match.group(),
                        "type": "api_endpoint" if "route" in pattern or "get" in pattern or "post" in pattern else "entry_point",
                    })

        return entry_points