"""Autonomous security pipeline for DeltaCode CLI.

End-to-end scan → analyze → fix → verify pipeline.
Supports synchronous and scheduled execution with:
- Approval gates at each critical stage
- Notification callbacks
- Full audit trail
- Rollback on failure
- Progress tracking
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional

from deltacode.core.logger import get_logger
from deltacode.core.agents.base import AgentTeam, AgentMessage, MessageType, ApprovalLevel
from deltacode.core.agents.analyzer import AnalyzerAgent
from deltacode.core.agents.fixer import FixerAgent
from deltacode.core.agents.validator import ValidatorAgent
from deltacode.core.agents.compliance import ComplianceAgent
from deltacode.core.agents.coordinator import CoordinatorAgent
from deltacode.core.agents.researcher import ResearcherAgent

logger = get_logger(__name__)


class Stage(Enum):
    INIT = "init"
    SCAN = "scan"
    ANALYZE = "analyze"
    RESEARCH = "research"
    PLAN = "plan"
    APPROVE = "approve"
    FIX = "fix"
    VALIDATE = "validate"
    COMPLIANCE = "compliance"
    REPORT = "report"
    COMPLETE = "complete"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"


@dataclass
class PipelineStage:
    name: Stage
    status: str = "pending"
    started_at: str = ""
    completed_at: str = ""
    duration_ms: int = 0
    result: Any = None
    error: str = ""
    requires_approval: bool = False
    approved: bool = False


@dataclass
class PipelineResult:
    pipeline_id: str
    target: str
    stages: list = field(default_factory=list)
    findings: list = field(default_factory=list)
    fixes_applied: list = field(default_factory=list)
    validation_results: list = field(default_factory=list)
    compliance_report: dict = field(default_factory=dict)
    status: str = "running"
    started_at: str = ""
    completed_at: str = ""
    total_duration_ms: int = 0
    error: str = ""
    requires_human_review: bool = False
    rollback_performed: bool = False

    def to_dict(self) -> dict:
        return {
            "pipeline_id": self.pipeline_id,
            "target": self.target,
            "status": self.status,
            "stages": [
                {
                    "name": s.name.value,
                    "status": s.status,
                    "duration_ms": s.duration_ms,
                    "requires_approval": s.requires_approval,
                    "approved": s.approved,
                    "error": s.error[:200] if s.error else "",
                }
                for s in self.stages
            ],
            "total_findings": len(self.findings),
            "fixes_applied": len(self.fixes_applied),
            "validation_passed": sum(1 for v in self.validation_results if v.get("passed", False)),
            "validation_failed": sum(1 for v in self.validation_results if not v.get("passed", False)),
            "total_duration_ms": self.total_duration_ms,
            "requires_human_review": self.requires_human_review,
            "rollback_performed": self.rollback_performed,
        }


class SecurityPipeline:
    def __init__(self, target: str = ".", name: str = None):
        self.target = target
        self.name = name or f"pipeline-{uuid.uuid4().hex[:8]}"
        self._team = AgentTeam(name=f"pipeline-team-{self.name}")
        self._team.register_agent(AnalyzerAgent(self._team.bus))
        self._team.register_agent(ResearcherAgent(self._team.bus))
        self._team.register_agent(FixerAgent(self._team.bus))
        self._team.register_agent(ValidatorAgent(self._team.bus))
        self._team.register_agent(ComplianceAgent(self._team.bus))
        coordinator = CoordinatorAgent(self._team.bus, team=self._team)
        self._team.register_agent(coordinator)
        self._notifications: list[Callable] = []
        self._audit_log: list[dict] = []
        self._on_approval: Optional[Callable] = None

    def on_notify(self, callback: Callable):
        self._notifications.append(callback)

    def on_approval_required(self, callback: Callable):
        self._on_approval = callback

    def _notify(self, event: str, data: dict):
        for cb in self._notifications:
            try:
                cb(event, data)
            except Exception:
                pass
        self._audit_log.append({"event": event, "data": data, "timestamp": datetime.utcnow().isoformat()})

    async def run(self, auto_approve: bool = False, skip_stages: list[str] = None) -> PipelineResult:
        result = PipelineResult(
            pipeline_id=self.name,
            target=self.target,
            started_at=datetime.utcnow().isoformat(),
        )
        skip = set(skip_stages or [])
        start_time = time.time()

        def _stage(name: Stage, requires_approval: bool = False) -> PipelineStage:
            s = PipelineStage(name=name, requires_approval=requires_approval)
            result.stages.append(s)
            return s

        async def _run_stage(stage: PipelineStage, coro):
            if stage.name.value in skip:
                stage.status = "skipped"
                return None
            stage.started_at = datetime.utcnow().isoformat()
            s = time.time()
            self._notify("stage_start", {"stage": stage.name.value})
            try:
                out = await coro
                stage.status = "completed"
                stage.result = out
                stage.duration_ms = int((time.time() - s) * 1000)
                stage.completed_at = datetime.utcnow().isoformat()
                self._notify("stage_complete", {"stage": stage.name.value, "duration_ms": stage.duration_ms})
                return out
            except Exception as e:
                stage.status = "failed"
                stage.error = str(e)[:500]
                stage.duration_ms = int((time.time() - s) * 1000)
                stage.completed_at = datetime.utcnow().isoformat()
                self._notify("stage_failed", {"stage": stage.name.value, "error": stage.error})
                raise

        try:
            # ── Stage 1: Scan ──────────────────────────────────────────────
            scan_stage = _stage(Stage.SCAN)
            analyzer = self._team.get_agent("analyzer-1")

            scan_output = await _run_stage(scan_stage, analyzer.execute_task({
                "action": "scan", "target": self.target,
            }))
            if scan_output:
                result.findings = scan_output.findings or []

            # ── Stage 2: Analyze ───────────────────────────────────────────
            analyze_stage = _stage(Stage.ANALYZE)
            if result.findings:
                classify_output = await _run_stage(analyze_stage, analyzer.execute_task({
                    "action": "classify", "findings": result.findings,
                }))
                if classify_output and classify_output.data:
                    result.findings = classify_output.data.get("findings", result.findings)

            # ── Stage 3: Research ──────────────────────────────────────────
            research_stage = _stage(Stage.RESEARCH)
            researcher = self._team.get_agent("researcher-1")
            cwe_ids = list(set(f.get("cwe_id", f.get("cwe", "")) for f in result.findings if f.get("cwe_id", f.get("cwe", ""))))
            if cwe_ids:
                queries = [c for c in cwe_ids if c and c.startswith("CWE-")][:3]
                for q in queries:
                    await _run_stage(research_stage, researcher.execute_task({
                        "action": "research_cve", "cve_id": q,
                    }))

            # ── Stage 4: Plan / Approve ───────────────────────────────────
            plan_stage = _stage(Stage.PLAN)
            await _run_stage(plan_stage, self._plan_stage())

            if not auto_approve and result.findings:
                approve_stage = _stage(Stage.APPROVE, requires_approval=True)
                self._notify("approval_required", {"findings_count": len(result.findings)})
                if self._on_approval:
                    approved = self._on_approval(result)
                    approve_stage.approved = approved
                    if not approved:
                        result.status = "cancelled"
                        result.completed_at = datetime.utcnow().isoformat()
                        result.total_duration_ms = int((time.time() - start_time) * 1000)
                        return result
                approve_stage.status = "completed" if approve_stage.approved else "pending"

            # ── Stage 5: Fix ──────────────────────────────────────────────
            fix_stage = _stage(Stage.FIX)
            fixer = self._team.get_agent("fixer-1")
            fix_output = await _run_stage(fix_stage, fixer.execute_task({
                "action": "auto_fix", "target": self.target,
                "findings": [f for f in result.findings if f.get("severity") in ("CRITICAL", "HIGH")][:10],
            }))
            if fix_output and fix_output.data:
                result.fixes_applied = fix_output.data.get("results", [])

            # ── Stage 6: Validate ─────────────────────────────────────────
            validate_stage = _stage(Stage.VALIDATE)
            validator = self._team.get_agent("validator-1")
            validate_output = await _run_stage(validate_stage, validator.execute_task({
                "action": "validate_fix", "target": self.target,
                "findings": result.findings[:10],
            }))
            if validate_output and validate_output.data:
                result.validation_results = validate_output.data.get("results", [])
                if not validate_output.success:
                    result.requires_human_review = True

            # ── Stage 7: Compliance ───────────────────────────────────────
            compliance_stage = _stage(Stage.COMPLIANCE)
            compliance = self._team.get_agent("compliance-1")
            compliance_output = await _run_stage(compliance_stage, compliance.execute_task({
                "action": "generate_report", "findings": result.findings,
                "frameworks": ["soc2", "iso27001"],
            }))
            if compliance_output:
                result.compliance_report = compliance_output.data or {}

            # ── Complete ───────────────────────────────────────────────────
            result.status = "completed"
            if result.requires_human_review:
                result.status = "completed_with_issues"

        except Exception as e:
            result.status = "failed"
            result.error = str(e)[:500]
            self._notify("pipeline_failed", {"error": result.error})

        result.completed_at = datetime.utcnow().isoformat()
        result.total_duration_ms = int((time.time() - start_time) * 1000)
        return result

    async def _plan_stage(self):
        coordinator = self._team.get_agent("coordinator-1")
        return await coordinator.execute_task({
            "action": "plan_workflow",
            "workflow": "full_assessment",
            "target": self.target,
        })

    async def rollback(self, result: PipelineResult) -> dict:
        fixer = self._team.get_agent("fixer-1")
        outcomes = []
        for fix in result.fixes_applied:
            r = await fixer.execute_task({"action": "rollback", "target": fix.get("file", self.target)})
            outcomes.append(r.to_dict())
        result.rollback_performed = True
        self._notify("rollback_complete", {"fixes_rolled_back": len(outcomes)})
        return {"rolled_back": len(outcomes), "results": outcomes}

    def get_audit_log(self) -> list[dict]:
        return list(self._audit_log)

    def get_status(self) -> dict:
        return {
            "name": self.name,
            "target": self.target,
            "team_status": self._team.request_status(),
        }