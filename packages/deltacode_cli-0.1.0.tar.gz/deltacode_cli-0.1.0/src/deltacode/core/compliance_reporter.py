"""Compliance reporting automation for DeltaCode CLI.

Generates compliance reports from pipeline findings:
- Executive summary
- Control-by-control assessment
- Evidence collection
- Gap analysis
- Trend tracking across multiple runs
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


COMPLIANCE_CONTROLS = {
    "soc2": {
        "name": "SOC 2",
        "controls": [
            ("CC6.1", "Logical and Physical Access", "Access controls for data and systems"),
            ("CC6.2", "User Access Management", "User provisioning and de-provisioning"),
            ("CC6.3", "Data Encryption", "Encryption at rest and in transit"),
            ("CC6.4", "Firewall and Network Security", "Network segmentation and firewall rules"),
            ("CC6.6", "Vulnerability Management", "Regular vulnerability scanning and remediation"),
            ("CC7.1", "Detection and Monitoring", "Continuous monitoring for security events"),
            ("CC7.2", "Incident Response", "Incident detection, response, and recovery"),
            ("CC7.3", "Remediation", "Timely remediation of identified issues"),
            ("CC8.1", "Change Management", "Controlled change management process"),
            ("CC9.1", "Risk Assessment", "Regular risk assessments"),
        ],
    },
    "iso27001": {
        "name": "ISO 27001",
        "controls": [
            ("A.5", "Information Security Policies", "Security policy framework"),
            ("A.6", "Organization of Security", "Roles and responsibilities"),
            ("A.8", "Asset Management", "Asset inventory and classification"),
            ("A.9", "Access Control", "Access control policy and user access management"),
            ("A.10", "Cryptography", "Cryptographic controls and key management"),
            ("A.12", "Operations Security", "Operational procedures and change management"),
            ("A.13", "Communications Security", "Network security and information transfer"),
            ("A.14", "System Acquisition", "Secure development lifecycle"),
            ("A.16", "Incident Management", "Incident response and reporting"),
        ],
    },
    "pci_dss": {
        "name": "PCI-DSS v4.0",
        "controls": [
            ("R1", "Network Security Controls", "Firewalls and network segmentation"),
            ("R2", "Secure Configuration", "Configuration standards for systems"),
            ("R3", "Stored Data Protection", "Protection of stored cardholder data"),
            ("R4", "Encryption in Transit", "Strong cryptography for cardholder data"),
            ("R5", "Malware Protection", "Anti-malware controls"),
            ("R6", "Secure Development", "Secure coding and application security"),
            ("R7", "Access Control", "Need-to-know access controls"),
            ("R8", "Authentication", "Strong authentication for system access"),
            ("R10", "Logging and Monitoring", "Audit trails and log monitoring"),
            ("R11", "Regular Testing", "Security testing and scanning"),
        ],
    },
    "hipaa": {
        "name": "HIPAA Security Rule",
        "controls": [
            ("164.308(a)(1)", "Security Management Process", "Risk analysis and risk management"),
            ("164.308(a)(2)", "Assigned Security Responsibility", "Designate security officer"),
            ("164.308(a)(3)", "Workforce Security", "Authorization and supervision"),
            ("164.308(a)(4)", "Information Access Management", "Access authorization and establishment"),
            ("164.308(a)(5)", "Security Awareness and Training", "Security reminders and training"),
            ("164.308(a)(6)", "Security Incident Procedures", "Response and reporting"),
            ("164.308(a)(7)", "Contingency Plan", "Data backup and disaster recovery"),
            ("164.308(a)(8)", "Evaluation", "Periodic technical and non-technical evaluation"),
            ("164.310(a)(1)", "Facility Access Controls", "Physical facility access controls"),
            ("164.310(b)", "Workstation Use", "Workstation policies and procedures"),
            ("164.310(c)", "Workstation Security", "Physical safeguards for workstations"),
            ("164.310(d)(1)", "Device and Media Controls", "Disposal and media re-use"),
            ("164.312(a)(1)", "Access Control", "Unique user identification and emergency access"),
            ("164.312(a)(2)", "Access Control: Automatic Logoff", "Electronic session timeouts"),
            ("164.312(a)(4)", "Access Control: Encryption and Decryption", "Encrypt e-PHI"),
            ("164.312(b)", "Audit Controls", "Hardware, software, transaction logging"),
            ("164.312(c)(1)", "Integrity Controls", "Mechanism to authenticate e-PHI"),
            ("164.312(c)(2)", "Integrity Controls: Authentication", "Electronic authentication of e-PHI"),
            ("164.312(d)", "Person or Entity Authentication", "User authentication mechanisms"),
            ("164.312(e)(1)", "Transmission Security", "Integrity and encryption controls"),
        ],
    },
    "gdpr": {
        "name": "GDPR",
        "controls": [
            ("Art. 5", "Principles of Processing", "Lawfulness, fairness, transparency"),
            ("Art. 6", "Lawfulness of Processing", "Valid legal basis for processing"),
            ("Art. 7", "Consent", "Clear consent mechanisms"),
            ("Art. 15", "Right of Access", "Data subject access rights"),
            ("Art. 16", "Right to Rectification", "Correct inaccurate data"),
            ("Art. 17", "Right to Erasure", "Right to be forgotten"),
            ("Art. 20", "Data Portability", "Portability of personal data"),
            ("Art. 25", "Data Protection by Design", "Privacy by design and default"),
            ("Art. 30", "Records of Processing", "Processing activity records"),
            ("Art. 32", "Security of Processing", "Appropriate technical and organizational measures"),
            ("Art. 33", "Breach Notification", "Notification of personal data breaches"),
            ("Art. 35", "Data Protection Impact Assessment", "DPIA for high-risk processing"),
            ("Art. 37", "Data Protection Officer", "Designation of DPO"),
            ("Art. 44", "International Transfers", "Cross-border data transfer safeguards"),
            ("Art. 46", "Transfer Safeguards", "Standard contractual clauses and BCRs"),
        ],
    },
}

CWE_TO_HIPAA = {
    "CWE-200": "164.312(a)(1)",
    "CWE-287": "164.312(d)",
    "CWE-798": "164.312(a)(1)",
    "CWE-327": "164.312(e)(1)",
    "CWE-256": "164.312(a)(4)",
    "CWE-89": "164.312(b)",
    "CWE-78": "164.312(a)(1)",
    "CWE-79": "164.312(b)",
    "CWE-22": "164.312(a)(1)",
    "CWE-502": "164.312(c)(1)",
    "CWE-918": "164.312(a)(1)",
    "CWE-295": "164.312(e)(1)",
    "CWE-330": "164.312(a)(1)",
    "CWE-611": "164.312(c)(1)",
    "CWE-352": "164.312(a)(1)",
}

CWE_TO_GDPR = {
    "CWE-200": "Art. 32",
    "CWE-256": "Art. 32",
    "CWE-287": "Art. 32",
    "CWE-327": "Art. 32",
    "CWE-798": "Art. 32",
    "CWE-89": "Art. 32",
    "CWE-78": "Art. 32",
    "CWE-79": "Art. 32",
    "CWE-22": "Art. 32",
    "CWE-502": "Art. 32",
}

CWE_TO_ALL = {
    "CWE-89": {"soc2": "CC6.1", "pci_dss": "6.5.1", "iso27001": "A.14.2.5", "hipaa": "164.312(b)", "gdpr": "Art. 32"},
    "CWE-78": {"soc2": "CC6.1", "pci_dss": "6.5.1", "iso27001": "A.14.2.5", "hipaa": "164.312(a)(1)", "gdpr": "Art. 32"},
    "CWE-79": {"soc2": "CC6.1", "pci_dss": "6.5.7", "iso27001": "A.14.2.5", "hipaa": "164.312(b)", "gdpr": "Art. 32"},
    "CWE-287": {"soc2": "CC6.2", "pci_dss": "8.3", "iso27001": "A.9.4.2", "hipaa": "164.312(d)", "gdpr": "Art. 32"},
    "CWE-798": {"soc2": "CC6.3", "pci_dss": "8.2.1", "iso27001": "A.9.2.1", "hipaa": "164.312(a)(1)", "gdpr": "Art. 32"},
    "CWE-327": {"soc2": "CC6.3", "pci_dss": "6.5.3", "iso27001": "A.10.1.1", "hipaa": "164.312(e)(1)", "gdpr": "Art. 32"},
    "CWE-200": {"soc2": "CC6.1", "pci_dss": "6.5.5", "iso27001": "A.13.2.1", "hipaa": "164.312(a)(1)", "gdpr": "Art. 32"},
    "CWE-352": {"soc2": "CC6.1", "pci_dss": "6.5.5", "iso27001": "A.14.2.5", "hipaa": "164.312(a)(1)"},
    "CWE-502": {"soc2": "CC6.1", "pci_dss": "6.5.1", "iso27001": "A.14.2.5", "hipaa": "164.312(c)(1)"},
    "CWE-918": {"soc2": "CC6.1", "pci_dss": "6.5.1", "iso27001": "A.13.1.1", "hipaa": "164.312(a)(1)"},
    "CWE-22": {"soc2": "CC6.1", "pci_dss": "6.5.4", "iso27001": "A.14.2.5", "hipaa": "164.312(a)(1)"},
    "CWE-611": {"soc2": "CC6.1", "pci_dss": "6.5.1", "iso27001": "A.14.2.5", "hipaa": "164.312(c)(1)"},
    "CWE-295": {"soc2": "CC6.3", "pci_dss": "4.1", "iso27001": "A.13.2.1", "hipaa": "164.312(e)(1)"},
    "CWE-330": {"soc2": "CC6.3", "pci_dss": "6.5.3", "iso27001": "A.10.1.2", "hipaa": "164.312(a)(1)"},
}


@dataclass
class ComplianceReport:
    framework: str
    project: str
    generated_at: str
    control_assessments: list = field(default_factory=list)
    findings_by_control: dict = field(default_factory=dict)
    total_controls: int = 0
    passing_controls: int = 0
    failing_controls: int = 0
    not_assessed: int = 0
    evidence_count: int = 0
    overall_status: str = "not_assessed"


class ComplianceReporter:
    def __init__(self, data_dir: str = None):
        self.data_dir = Path(data_dir or Path.home() / ".deltacode" / "compliance")
        self.data_dir.mkdir(parents=True, exist_ok=True)

    def generate_report(self, framework: str, findings: list, project: str = ".") -> ComplianceReport:
        framework_id = framework.lower().replace("-", "_")
        framework_def = COMPLIANCE_CONTROLS.get(framework_id)
        if not framework_def:
            framework_def = COMPLIANCE_CONTROLS["soc2"]

        report = ComplianceReport(
            framework=framework_def["name"],
            project=str(Path(project).resolve()),
            generated_at=datetime.utcnow().isoformat(),
        )

        cwe_map = self._build_cwe_map(findings)

        for control_id, control_name, control_desc in framework_def["controls"]:
            matched = self._match_findings_to_control(control_id, control_name, findings, cwe_map)
            status = "passing" if not matched else "failing"
            report.control_assessments.append({
                "control_id": control_id,
                "control_name": control_name,
                "description": control_desc,
                "status": status,
                "finding_count": len(matched),
                "findings": matched[:5],
            })
            if status == "passing":
                report.passing_controls += 1
            else:
                report.failing_controls += 1
            report.findings_by_control[control_id] = matched

        report.total_controls = len(framework_def["controls"])
        report.overall_status = "failing" if report.failing_controls > 0 else "passing"

        return report

    def _build_cwe_map(self, findings: list) -> dict:
        return CWE_TO_ALL

    def _match_findings_to_control(self, control_id: str, control_name: str, findings: list, cwe_map: dict) -> list:
        matched = []
        related_cwes = {cwe for cwe, controls in cwe_map.items() if control_id in controls.values()}

        for f in findings:
            f_cwe = f.get("cwe", f.get("cwe_id", ""))
            if f_cwe in related_cwes:
                matched.append(f)
                continue
            desc = (f.get("title", "") + " " + f.get("description", "") + " " + control_name).lower()
            keywords = control_name.lower().split()
            if any(kw in desc for kw in keywords if len(kw) > 3):
                matched.append(f)

        return matched

    def generate_executive_summary(self, framework: str, findings: list, project: str = ".") -> str:
        report = self.generate_report(framework, findings, project)

        parts = [f"# Compliance Executive Summary: {report.framework}"]
        parts.append(f"Project: {report.project}")
        parts.append(f"Generated: {report.generated_at}")
        parts.append("")
        parts.append(f"## Overall Status: {report.overall_status.upper()}")
        parts.append("")
        parts.append(f"### Control Assessment Summary")
        parts.append(f"Total Controls: {report.total_controls}")
        parts.append(f"Passing: {report.passing_controls}")
        parts.append(f"Failing: {report.failing_controls}")
        parts.append(f"Not Assessed: {report.not_assessed}")
        parts.append("")
        parts.append(f"### Failing Controls ({report.failing_controls})")
        for ca in report.control_assessments:
            if ca["status"] == "failing":
                parts.append(f"\n#### {ca['control_id']}: {ca['control_name']}")
                parts.append(f"Findings: {ca['finding_count']}")
                for f in ca["findings"][:3]:
                    desc = f.get("title", f.get("description", "Finding"))
                    sev = f.get("severity", "MEDIUM")
                    parts.append(f"- [{sev}] {desc[:100]}")
        parts.append("")
        parts.append(f"### Passing Controls ({report.passing_controls})")
        for ca in report.control_assessments:
            if ca["status"] == "passing":
                parts.append(f"- {ca['control_id']}: {ca['control_name']}")
        parts.append("")
        pass_pct = round(report.passing_controls / max(report.total_controls, 1) * 100, 1)
        parts.append(f"## Coverage: {pass_pct}% ({report.passing_controls}/{report.total_controls})")
        parts.append(f"Evidence Items: {report.evidence_count}")

        return "\n".join(parts)

    def save_report(self, report: ComplianceReport, path: str = None) -> str:
        if path is None:
            path = str(self.data_dir / f"compliance_{report.framework.lower().replace(' ', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        Path(path).write_text(json.dumps({
            "framework": report.framework,
            "project": report.project,
            "generated_at": report.generated_at,
            "overall_status": report.overall_status,
            "total_controls": report.total_controls,
            "passing": report.passing_controls,
            "failing": report.failing_controls,
            "not_assessed": report.not_assessed,
            "controls": report.control_assessments,
        }, indent=2, ensure_ascii=False), encoding="utf-8")
        return path