"""Test coverage analyzer for DeltaCode CLI.

Extracts coverage data from pytest-cov, coverage.py, or custom runners:
- Line coverage percentage
- Branch coverage
- Missed lines report
- Coverage trends over time
"""

from __future__ import annotations

import json
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class FileCoverage:
    file: str
    line_rate: float
    branch_rate: float
    missed_lines: list = field(default_factory=list)
    total_lines: int = 0
    covered_lines: int = 0


@dataclass
class CoverageResult:
    files: list = field(default_factory=list)
    total_line_rate: float = 0.0
    total_branch_rate: float = 0.0
    total_lines: int = 0
    total_covered: int = 0
    total_missed: int = 0
    duration_ms: int = 0


class CoverageAnalyzer:
    def __init__(self, project_path: str = "."):
        self.project_path = Path(project_path).resolve()

    def run_coverage(self, test_command: str = "pytest --cov=src --cov-report=json") -> CoverageResult:
        import time
        start = time.time()

        result = CoverageResult()

        try:
            cmd = test_command.split()
            subprocess.run(cmd, capture_output=True, text=True, timeout=300, cwd=str(self.project_path))
            result.duration_ms = int((time.time() - start) * 1000)
        except subprocess.TimeoutExpired:
            result.duration_ms = 300000
        except FileNotFoundError:
            return result
        except Exception:
            pass

        cov_file = self.project_path / "coverage.json"
        if cov_file.exists():
            try:
                data = json.loads(cov_file.read_text(encoding="utf-8"))
                files = data.get("files", {})
                total_lines = 0
                total_covered = 0
                for fpath, fdata in files.items():
                    summary = fdata.get("summary", {})
                    line_rate = summary.get("covered_lines", 0) / max(summary.get("num_statements", 1), 1)
                    branch_rate = summary.get("covered_branches", 0) / max(summary.get("num_branches", 1), 1) if summary.get("num_branches", 0) > 0 else 0
                    fc = FileCoverage(
                        file=fpath,
                        line_rate=round(line_rate * 100, 1),
                        branch_rate=round(branch_rate * 100, 1),
                        total_lines=summary.get("num_statements", 0),
                        covered_lines=summary.get("covered_lines", 0),
                    )
                    result.files.append(fc)
                    total_lines += summary.get("num_statements", 0)
                    total_covered += summary.get("covered_lines", 0)

                result.total_lines = total_lines
                result.total_covered = total_covered
                result.total_missed = total_lines - total_covered
                result.total_line_rate = round(total_covered / max(total_lines, 1) * 100, 1)
                result.total_branch_rate = round(
                    sum(f.branch_rate for f in result.files) / max(len(result.files), 1), 1
                )
            except Exception:
                pass

        return result

    def format_report(self, result: CoverageResult) -> str:
        parts = [f"# Test Coverage Report\n"]
        parts.append(f"Line Coverage: {result.total_line_rate}%")
        parts.append(f"Branch Coverage: {result.total_branch_rate}%")
        parts.append(f"Total Lines: {result.total_lines}")
        parts.append(f"Covered: {result.total_covered}")
        parts.append(f"Missed: {result.total_missed}")
        parts.append(f"Duration: {result.duration_ms}ms")
        parts.append("")

        if result.files:
            parts.append(f"## Per File")
            parts.append(f"{'File':40} {'Line%':8} {'Branch%':8} {'Status':10}")
            parts.append("-" * 66)
            for f in sorted(result.files, key=lambda x: x.line_rate)[:20]:
                icon = "✅" if f.line_rate >= 80 else "⚠️ " if f.line_rate >= 50 else "🔴"
                parts.append(f"{f.file[:38]:40} {f.line_rate:>7.1f}% {f.branch_rate:>7.1f}% {icon:10}")

        return "\n".join(parts)