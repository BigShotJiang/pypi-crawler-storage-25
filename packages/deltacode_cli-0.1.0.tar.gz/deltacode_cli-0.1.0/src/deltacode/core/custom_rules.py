"""Custom rule engine for SecurityLinter.

Regex-based custom security rules organized by language and category.
Supports severity levels, custom messages, and CWE references.
Built-in rules cover Python, JavaScript, and Go with ~30 patterns.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class CustomRule:
    pattern: str
    message: str
    severity: str = "MEDIUM"
    cwe: str = ""
    category: str = "general"
    compiled: Optional[re.Pattern] = None

    def __post_init__(self):
        try:
            self.compiled = re.compile(self.pattern, re.I)
        except re.error:
            self.compiled = None


@dataclass
class CustomRuleMatch:
    rule: CustomRule
    line: int
    match_text: str
    severity: str
    cwe: str
    message: str


def _rules_from_list(entries: list[tuple]) -> list[CustomRule]:
    return [
        CustomRule(pattern=p, message=m, severity=s, cwe=c)
        for p, m, s, c in entries
    ]


BUILTIN_RULES = {
    "python": {
        "dangerous_apis": _rules_from_list([
            (r'eval\s*\(', "Avoid eval — potential code injection", "HIGH", "CWE-95"),
            (r'exec\s*\(', "Avoid exec — potential code injection", "HIGH", "CWE-95"),
            (r'pickle\.loads?\s*\(', "pickle deserialization can execute code", "HIGH", "CWE-502"),
            (r'marshal\.loads?\s*\(', "marshal deserialization can execute code", "HIGH", "CWE-502"),
            (r'subprocess\.(?:call|run|Popen)\(.*shell\s*=\s*True', "shell=True enables command injection", "HIGH", "CWE-78"),
            (r'os\.system\s*\(', "os.system enables command injection", "HIGH", "CWE-78"),
            (r'os\.popen\s*\(', "os.popen enables command injection", "HIGH", "CWE-78"),
            (r'tempfile\.mktemp\s*\(', "mktemp is insecure — use TemporaryFile", "MEDIUM", "CWE-377"),
            (r'hashlib\.md5\s*\(', "MD5 is cryptographically broken", "MEDIUM", "CWE-327"),
            (r'hashlib\.sha1\s*\(', "SHA-1 is cryptographically broken", "MEDIUM", "CWE-328"),
            (r'random\.(?:random|randint|choice|uniform|shuffle)\s*\(', "random module not cryptographically secure", "LOW", "CWE-330"),
        ]),
        "crypto": _rules_from_list([
            (r'DES\.new\s*\(', "DES is a weak cipher — use AES", "HIGH", "CWE-326"),
            (r'ARC4|RC4', "RC4 is a broken cipher", "HIGH", "CWE-327"),
            (r'ECB\s*Mode', "ECB mode is insecure — use GCM or CBC", "HIGH", "CWE-327"),
            (r'PKCS1_v1_5', "PKCS1 v1.5 vulnerable to Bleichenbacher attacks", "HIGH", "CWE-780"),
        ]),
        "network": _rules_from_list([
            (r'requests\.get\(.*verify\s*=\s*False', "SSL verification disabled", "HIGH", "CWE-295"),
            (r'allow_origins\s*=\s*\[\s*\*\s*\]', "CORS allows any origin", "MEDIUM", "CWE-942"),
        ]),
    },
    "javascript": {
        "injection": _rules_from_list([
            (r'innerHTML\s*=', "Unsafe innerHTML — use textContent", "HIGH", "CWE-79"),
            (r'document\.write\s*\(', "document.write can lead to DOM XSS", "HIGH", "CWE-79"),
            (r'eval\s*\(', "eval enables code injection", "HIGH", "CWE-95"),
            (r'new\s+Function\s*\(', "Function constructor enables code injection", "HIGH", "CWE-95"),
        ]),
        "crypto": _rules_from_list([
        ]),
    },
    "go": {
        "injection": _rules_from_list([
            (r'exec\.Command\s*\(.*\+', "String concat in exec.Command risk", "HIGH", "CWE-78"),
            (r'sql\.Open\s*\(.*\+', "Potential SQL injection via string concat", "HIGH", "CWE-89"),
        ]),
    },
}


class CustomRuleEngine:
    def __init__(self, rules_path: str = None):
        self._rules: dict[str, list[CustomRule]] = {}
        self._load_builtin()
        if rules_path:
            self._load_file(rules_path)

    def _load_builtin(self):
        for lang, categories in BUILTIN_RULES.items():
            self._rules[lang] = []
            for category, rules in categories.items():
                for rule in rules:
                    rule.category = category
                    if rule.compiled:
                        self._rules[lang].append(rule)

    def _load_file(self, path: str):
        try:
            import json
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            for entry in data if isinstance(data, list) else data.get("rules", []):
                rule = CustomRule(
                    pattern=entry["pattern"],
                    message=entry.get("message", "Custom rule match"),
                    severity=entry.get("severity", "MEDIUM"),
                    cwe=entry.get("cwe", ""),
                    category=entry.get("category", "custom"),
                )
                lang = entry.get("language", "python")
                if lang not in self._rules:
                    self._rules[lang] = []
                if rule.compiled:
                    self._rules[lang].append(rule)
        except Exception as e:
            pass

    def scan(self, code: str, language: str) -> list[CustomRuleMatch]:
        lang = language.lower()
        if lang not in self._rules:
            return []

        matches = []
        for rule in self._rules[lang]:
            if not rule.compiled:
                continue
            for match in rule.compiled.finditer(code):
                line_pos = code[:match.start()].count("\n") + 1
                matches.append(CustomRuleMatch(
                    rule=rule,
                    line=line_pos,
                    match_text=match.group()[:80],
                    severity=rule.severity,
                    cwe=rule.cwe,
                    message=rule.message,
                ))

        matches.sort(key=lambda m: {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}.get(m.severity, 4))
        return matches

    def format_results(self, matches: list[CustomRuleMatch]) -> Optional[str]:
        if not matches:
            return None
        text = f"## custom rules ({len(matches)} issues)\n\n"
        for m in matches:
            cwe_tag = f" ({m.cwe})" if m.cwe else ""
            text += f"- [{m.severity}]{cwe_tag} {m.message} (line {m.line})\n"
        return text

    def list_rules(self, language: str = None) -> dict:
        if language:
            return {language: self._rules.get(language, [])}
        return dict(self._rules)

    def get_rule_count(self) -> int:
        return sum(len(rules) for rules in self._rules.values())

    @staticmethod
    def ext_to_lang(ext: str) -> Optional[str]:
        mapping = {".py": "python", ".pyw": "python", ".js": "javascript", ".jsx": "javascript", ".ts": "javascript", ".tsx": "javascript", ".go": "go"}
        return mapping.get(ext.lower())


def scan_with_custom_rules(code: str, ext: str, rules_path: str = None) -> Optional[list]:
    engine = CustomRuleEngine(rules_path=rules_path)
    lang = CustomRuleEngine.ext_to_lang(ext)
    if not lang:
        return None
    return engine.scan(code, lang)