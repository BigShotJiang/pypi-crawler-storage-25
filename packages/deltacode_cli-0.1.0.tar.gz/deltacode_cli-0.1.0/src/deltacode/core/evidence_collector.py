"""Compliance evidence collection for DeltaCode CLI.

Gathers and packages evidence for compliance audits:
- Scan results as evidence artifacts
- Fix records with timestamps
- Policy check results
- Screenshots and reports
- Chain of custody metadata
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class EvidenceArtifact:
    id: str
    evidence_type: str
    title: str
    description: str
    source: str
    created_at: str
    content_type: str
    content_path: str
    control_mappings: list = field(default_factory=list)
    hash: str = ""
    size_bytes: int = 0
    verified: bool = False


class EvidenceCollector:
    def __init__(self, data_dir: str = None):
        self.data_dir = Path(data_dir or Path.home() / ".deltacode" / "evidence")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._artifacts: list[EvidenceArtifact] = []
        self._load()

    def _load(self):
        ef = self.data_dir / "evidence.json"
        if ef.exists():
            try:
                data = json.loads(ef.read_text(encoding="utf-8"))
                self._artifacts = [EvidenceArtifact(**a) for a in data]
            except Exception:
                pass

    def _save(self):
        ef = self.data_dir / "evidence.json"
        ef.write_text(json.dumps(
            [a.__dict__ for a in self._artifacts], indent=2, ensure_ascii=False
        ), encoding="utf-8")

    def add_artifact(self, evidence_type: str, title: str, description: str, source: str,
                     content: str, content_type: str = "text", control_mappings: list = None) -> EvidenceArtifact:
        import hashlib
        artifact_id = f"EV-{uuid.uuid4().hex[:8].upper()}"
        file_name = f"{artifact_id}.{content_type.split('/')[-1] if '/' in content_type else 'txt'}"
        file_path = self.data_dir / "files" / file_name
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")

        artifact = EvidenceArtifact(
            id=artifact_id,
            evidence_type=evidence_type,
            title=title,
            description=description,
            source=source,
            created_at=datetime.utcnow().isoformat(),
            content_type=content_type,
            content_path=str(file_path),
            control_mappings=control_mappings or [],
            hash=hashlib.sha256(content.encode()).hexdigest()[:16],
            size_bytes=len(content.encode()),
            verified=False,
        )
        self._artifacts.append(artifact)
        self._save()
        return artifact

    def verify_artifact(self, artifact_id: str) -> bool:
        for a in self._artifacts:
            if a.id == artifact_id:
                try:
                    content = Path(a.content_path).read_text(encoding="utf-8")
                    import hashlib
                    expected = hashlib.sha256(content.encode()).hexdigest()[:16]
                    a.verified = (expected == a.hash)
                    self._save()
                    return a.verified
                except Exception:
                    return False
        return False

    def get_artifacts(self, evidence_type: str = None, limit: int = 50) -> list[EvidenceArtifact]:
        arts = self._artifacts
        if evidence_type:
            arts = [a for a in arts if a.evidence_type == evidence_type]
        return arts[-limit:]

    def get_by_control(self, control_id: str) -> list[EvidenceArtifact]:
        return [a for a in self._artifacts if control_id in a.control_mappings]

    def export_package(self, output_path: str, control_id: str = None) -> str:
        if control_id:
            artifacts = self.get_by_control(control_id)
        else:
            artifacts = self._artifacts

        package = {
            "exported_at": datetime.utcnow().isoformat(),
            "total_artifacts": len(artifacts),
            "artifacts": [a.__dict__ for a in artifacts],
        }

        out = Path(output_path)
        out.write_text(json.dumps(package, indent=2, ensure_ascii=False), encoding="utf-8")
        return str(out)

    def get_stats(self) -> dict:
        by_type = {}
        for a in self._artifacts:
            by_type[a.evidence_type] = by_type.get(a.evidence_type, 0) + 1
        return {
            "total": len(self._artifacts),
            "verified": sum(1 for a in self._artifacts if a.verified),
            "by_type": by_type,
            "total_size_bytes": sum(a.size_bytes for a in self._artifacts),
        }