"""Docker Sandbox module for DeltaCode CLI.

Isolated execution environment for security testing:
- Container lifecycle management (create, start, stop, remove)
- Network isolation (no egress, internal-only)
- Filesystem constraints (read-only mounts, tempfs volumes)
- Resource limits (CPU, memory, disk)
- Secure image management (verified images only)
- Snapshot/restore for test environments
- Result extraction
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tarfile
import tempfile
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger

logger = get_logger(__name__)


# ─── data classes ────────────────────────────────────────────────────────────

@dataclass
class SandboxConfig:
    image: str = "python:3.10-slim"
    container_name: str = ""
    memory_limit: str = "512m"
    cpu_limit: float = 0.5
    disk_limit: str = "1g"
    network_disabled: bool = True
    read_only_rootfs: bool = True
    workdir: str = "/workspace"
    timeout_seconds: int = 300
    remove_on_exit: bool = True
    expose_ports: list = field(default_factory=list)
    env_vars: dict = field(default_factory=dict)
    tmpfs_mounts: list = field(default_factory=lambda: ["/tmp:size=100m"])
    allowed_images: list = field(default_factory=lambda: [
        "python:3.10-slim", "python:3.11-slim",
        "alpine:3.19", "busybox:latest",
        "node:20-slim", "node:18-slim",
    ])


@dataclass
class SandboxResult:
    success: bool = False
    container_id: str = ""
    exit_code: int = -1
    stdout: str = ""
    stderr: str = ""
    duration_seconds: float = 0.0
    error: str = ""
    artifacts: list = field(default_factory=list)
    snapshot_name: str = ""


@dataclass
class SandboxSnapshot:
    name: str
    container_id: str
    created_at: str
    image_id: str = ""
    size_bytes: int = 0


# ─── image security ──────────────────────────────────────────────────────────

class ImageSecurityPolicy:
    def __init__(self, allowed_images: list[str] = None):
        self.allowed_images = set(allowed_images or [])
        self._trusted_registries = {"docker.io/library/", "docker.io/python", "docker.io/node", "docker.io/alpine", "docker.io/busybox"}

    def check_image(self, image: str) -> tuple[bool, str]:
        if not image:
            return False, "No image specified"

        if self.allowed_images and image in self.allowed_images:
            return True, ""

        image_lower = image.lower()
        blocked_keywords = ["exploit", "hacking", "crack", "malware", "backdoor"]
        for kw in blocked_keywords:
            if kw in image_lower:
                return False, f"Image '{image}' blocked by security policy: contains '{kw}'"

        trusted = any(image.startswith(r) or f"/{image}" in r for r in self._trusted_registries)
        if not trusted and not any(c in image for c in ["/", ":"]):
            return False, f"Image '{image}' is not from a trusted registry"

        return True, ""

    def add_allowed(self, image: str):
        self.allowed_images.add(image)


# ─── sandbox manager ─────────────────────────────────────────────────────────

class SandboxManager:
    def __init__(self, config: SandboxConfig = None):
        self.config = config or SandboxConfig()
        self._active_containers: dict[str, dict] = {}
        self._snapshots: dict[str, SandboxSnapshot] = {}
        self._data_dir = Path.home() / ".deltacode" / "sandbox"
        self._data_dir.mkdir(parents=True, exist_ok=True)
        self._image_policy = ImageSecurityPolicy(allowed_images=self.config.allowed_images)
        self._docker_available = self._check_docker()

    def _check_docker(self) -> bool:
        try:
            result = subprocess.run(["docker", "--version"], capture_output=True, text=True, timeout=10)
            return result.returncode == 0
        except Exception:
            return False

    @property
    def is_available(self) -> bool:
        return self._docker_available

    def create_container(self, config: SandboxConfig = None) -> SandboxResult:
        cfg = config or self.config

        if not self._docker_available:
            return SandboxResult(success=False, error="Docker is not available")

        allowed, reason = self._image_policy.check_image(cfg.image)
        if not allowed:
            return SandboxResult(success=False, error=reason)

        container_name = cfg.container_name or f"deltacode-sandbox-{uuid.uuid4().hex[:8]}"
        start_time = time.time()

        try:
            pull_cmd = ["docker", "pull", cfg.image]
            subprocess.run(pull_cmd, capture_output=True, text=True, timeout=300)

            run_args = [
                "docker", "run", "-d",
                "--name", container_name,
                "-m", cfg.memory_limit,
                "--cpus", str(cfg.cpu_limit),
                "-w", cfg.workdir,
                cfg.image,
            ]

            if cfg.read_only_rootfs:
                run_args.insert(3, "--read-only")

            run_args = [a for a in run_args if a]

            result = subprocess.run(run_args, capture_output=True, text=True, timeout=60)
            if result.returncode != 0:
                return SandboxResult(success=False, error=f"Container creation failed: {result.stderr.strip()}")

            container_id = result.stdout.strip()

            self._apply_resource_limits(container_id, cfg)
            self._apply_network_isolation(container_id, cfg)
            self._apply_tmpfs(container_id, cfg)

            self._active_containers[container_name] = {
                "id": container_id,
                "config": cfg,
                "created_at": datetime.utcnow().isoformat(),
            }

            duration = time.time() - start_time

            return SandboxResult(
                success=True,
                container_id=container_id,
                duration_seconds=round(duration, 2),
                stdout=container_id,
            )

        except subprocess.TimeoutExpired:
            return SandboxResult(success=False, error="Container creation timed out")
        except Exception as e:
            return SandboxResult(success=False, error=str(e))

    def _apply_resource_limits(self, container_id: str, cfg: SandboxConfig):
        try:
            subprocess.run(
                ["docker", "update", f"--memory={cfg.memory_limit}", f"--cpus={str(cfg.cpu_limit)}", container_id],
                capture_output=True, text=True, timeout=30,
            )
        except Exception:
            pass

    def _apply_network_isolation(self, container_id: str, cfg: SandboxConfig):
        if cfg.network_disabled:
            try:
                cmd = ["docker", "network", "disconnect", "bridge", container_id]
                subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            except Exception:
                pass

    def _apply_tmpfs(self, container_id: str, cfg: SandboxConfig):
        for mount in cfg.tmpfs_mounts:
            try:
                cmd = ["docker", "update", f"--tmpfs={mount}", container_id]
                subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            except Exception:
                pass

    def exec_command(self, container_id: str, command: str | list, workdir: str = None, timeout: int = None) -> SandboxResult:
        if isinstance(command, str):
            import shlex
            command = shlex.split(command)

        cfg_timeout = timeout or self.config.timeout_seconds
        start = time.time()

        try:
            exec_args = ["docker", "exec", "-i"]

            if workdir:
                exec_args.extend(["-w", workdir])

            exec_args.append(container_id)
            exec_args.extend(command)

            result = subprocess.run(
                exec_args,
                capture_output=True, text=True, timeout=cfg_timeout,
            )

            sandbox_result = SandboxResult(
                success=result.returncode == 0,
                container_id=container_id,
                exit_code=result.returncode,
                stdout=result.stdout,
                stderr=result.stderr,
                duration_seconds=round(time.time() - start, 2),
            )

            if result.returncode != 0:
                sandbox_result.error = result.stderr.strip()[:500]

            return sandbox_result

        except subprocess.TimeoutExpired:
            return SandboxResult(success=False, error=f"Command timed out ({cfg_timeout}s)", container_id=container_id)
        except Exception as e:
            return SandboxResult(success=False, error=str(e), container_id=container_id)

    def exec_python(self, container_id: str, code: str, timeout: int = 60) -> SandboxResult:
        return self.exec_command(
            container_id,
            ["python3", "-c", code],
            timeout=timeout,
        )

    def copy_file_to_container(self, container_id: str, host_path: str, container_path: str) -> SandboxResult:
        try:
            result = subprocess.run(
                ["docker", "cp", host_path, f"{container_id}:{container_path}"],
                capture_output=True, text=True, timeout=30,
            )
            return SandboxResult(
                success=result.returncode == 0,
                container_id=container_id,
                error=result.stderr.strip() if result.returncode != 0 else "",
            )
        except Exception as e:
            return SandboxResult(success=False, error=str(e), container_id=container_id)

    def copy_file_from_container(self, container_id: str, container_path: str, host_path: str) -> SandboxResult:
        try:
            result = subprocess.run(
                ["docker", "cp", f"{container_id}:{container_path}", host_path],
                capture_output=True, text=True, timeout=30,
            )
            return SandboxResult(
                success=result.returncode == 0,
                container_id=container_id,
                error=result.stderr.strip() if result.returncode != 0 else "",
            )
        except Exception as e:
            return SandboxResult(success=False, error=str(e), container_id=container_id)

    def extract_results(self, container_id: str, result_dir: str) -> list[SandboxResult]:
        dest = Path(result_dir)
        dest.mkdir(parents=True, exist_ok=True)

        results = []
        paths_to_check = ["/workspace/output", "/workspace/reports", "/workspace/results"]
        for cpath in paths_to_check:
            result = self.exec_command(container_id, ["test", "-d", cpath])
            if result.success:
                host_dir = dest / Path(cpath).name
                host_dir.mkdir(exist_ok=True)
                copy_result = self.copy_file_from_container(container_id, f"{cpath}/.", str(host_dir))
                results.append(copy_result)

        output = self.exec_command(container_id, ["find", "/workspace", "-type", "f", "-name", "*.json", "-o", "-name", "*.xml", "-o", "-name", "*.txt"])
        if output.success and output.stdout.strip():
            for fpath in output.stdout.strip().split("\n"):
                fpath = fpath.strip()
                if fpath:
                    host_file = dest / Path(fpath).name
                    r = self.copy_file_from_container(container_id, fpath, str(host_file))
                    results.append(r)

        return results

    def stop_container(self, container_id: str, remove: bool = True) -> SandboxResult:
        try:
            subprocess.run(["docker", "stop", container_id], capture_output=True, text=True, timeout=30)
            if remove:
                subprocess.run(["docker", "rm", container_id], capture_output=True, text=True, timeout=30)
            return SandboxResult(success=True, container_id=container_id)
        except Exception as e:
            return SandboxResult(success=False, error=str(e), container_id=container_id)

    def cleanup_all(self):
        for name, info in list(self._active_containers.items()):
            try:
                self.stop_container(info["id"])
            except Exception:
                pass
        self._active_containers.clear()

    def container_status(self, container_id: str) -> dict:
        try:
            result = subprocess.run(
                ["docker", "inspect", container_id],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode != 0:
                return {"exists": False, "id": container_id}

            data = json.loads(result.stdout)
            state = data[0].get("State", {})
            return {
                "exists": True,
                "id": container_id,
                "status": state.get("Status", "unknown"),
                "running": state.get("Running", False),
                "exit_code": state.get("ExitCode", -1),
                "started_at": state.get("StartedAt", ""),
                "finished_at": state.get("FinishedAt", ""),
                "pid": state.get("Pid", 0),
                "oom_killed": state.get("OOMKilled", False),
            }
        except Exception:
            return {"exists": False, "id": container_id}

    def list_containers(self, all_containers: bool = True) -> list[dict]:
        try:
            cmd = ["docker", "ps", "-a" if all_containers else "", "--format", "{{json .}}"]
            cmd = [c for c in cmd if c]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            containers = []
            for line in result.stdout.strip().split("\n"):
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    containers.append(data)
                except json.JSONDecodeError:
                    pass
            return containers
        except Exception:
            return []

    def create_snapshot(self, container_id: str, name: str = None) -> SandboxSnapshot:
        snapshot_name = name or f"snapshot-{uuid.uuid4().hex[:8]}"
        timestamp = datetime.utcnow().isoformat()
        commit_cmd = ["docker", "commit", container_id, f"deltacode-snapshot:{snapshot_name}"]

        try:
            result = subprocess.run(commit_cmd, capture_output=True, text=True, timeout=60)
            if result.returncode != 0:
                return SandboxSnapshot(name=snapshot_name, container_id=container_id, created_at=timestamp)

            snapshot = SandboxSnapshot(
                name=snapshot_name,
                container_id=container_id,
                created_at=timestamp,
            )
            self._snapshots[snapshot_name] = snapshot
            return snapshot
        except Exception as e:
            return SandboxSnapshot(name=snapshot_name, container_id=container_id, created_at=timestamp)

    def restore_snapshot(self, snapshot_name: str, new_config: SandboxConfig = None) -> SandboxResult:
        snapshot = self._snapshots.get(snapshot_name)
        if not snapshot:
            return SandboxResult(success=False, error=f"Snapshot '{snapshot_name}' not found")

        cfg = new_config or self.config
        cfg.image = f"deltacode-snapshot:{snapshot_name}"
        return self.create_container(cfg)

    def list_snapshots(self) -> list[SandboxSnapshot]:
        return list(self._snapshots.values())

    def run_isolated_python(self, code: str, libraries: list[str] = None, timeout: int = 120) -> SandboxResult:
        cfg = SandboxConfig(
            image="python:3.10-slim",
            memory_limit="256m",
            cpu_limit=0.25,
            timeout_seconds=timeout,
        )

        create_result = self.create_container(cfg)
        if not create_result.success:
            return create_result

        container_id = create_result.container_id
        try:
            if libraries:
                install_cmd = f"pip install {' '.join(libraries)} -q"
                install_result = self.exec_command(container_id, install_cmd, timeout=60)
                if not install_result.success:
                    return SandboxResult(success=False, error=f"Library install failed: {install_result.stderr}")

            exec_result = self.exec_python(container_id, code, timeout=timeout)
            return exec_result
        finally:
            if cfg.remove_on_exit:
                self.stop_container(container_id, remove=True)


# ─── safe testing infrastructure ─────────────────────────────────────────────

class SandboxEnvironment:
    def __init__(self, base_image: str = "python:3.10-slim"):
        self.base_image = base_image
        self.manager = SandboxManager()

    def create_test_env(self, name: str = None) -> dict:
        cfg = SandboxConfig(
            image=self.base_image,
            container_name=name or f"test-env-{uuid.uuid4().hex[:8]}",
            remove_on_exit=False,
            network_disabled=True,
            read_only_rootfs=True,
        )
        result = self.manager.create_container(cfg)
        return {"success": result.success, "container_id": result.container_id, "error": result.error}

    def create_live_env(self, name: str = None) -> dict:
        cfg = SandboxConfig(
            image=self.base_image,
            container_name=name or f"live-env-{uuid.uuid4().hex[:8]}",
            remove_on_exit=False,
            network_disabled=False,
            read_only_rootfs=False,
            memory_limit="1g",
            cpu_limit=1.0,
        )
        result = self.manager.create_container(cfg)
        return {"success": result.success, "container_id": result.container_id, "error": result.error}

    def cleanup_env(self, container_id: str) -> dict:
        self.manager.stop_container(container_id, remove=True)
        return {"cleaned": True, "container_id": container_id}


def run_sandboxed_scan(project_path: str, scanner_type: str = "bandit", timeout: int = 300) -> SandboxResult:
    cfg = SandboxConfig(
        image="python:3.10-slim",
        memory_limit="1g",
        cpu_limit=1.0,
        timeout_seconds=timeout,
        tmpfs_mounts=["/tmp:size=256m"],
    )

    manager = SandboxManager(config=cfg)
    container_result = manager.create_container()
    if not container_result.success:
        return container_result

    container_id = container_result.container_id
    try:
        tools = {"bandit": "bandit", "semgrep": "semgrep", "pip-audit": "pip-audit"}
        tool_pkg = tools.get(scanner_type)
        if tool_pkg:
            manager.exec_command(container_id, f"pip install {tool_pkg} -q", timeout=60)

        scan_cmds = {
            "bandit": f"bandit -r /workspace -q -f json",
            "semgrep": f"semgrep --config=auto --json /workspace",
            "pip-audit": f"pip-audit -r /workspace/requirements.txt --format=json 2>/dev/null",
        }

        scan_cmd = scan_cmds.get(scanner_type, f"find /workspace -type f -name '*.py' | head -5")
        return manager.exec_command(container_id, scan_cmd, timeout=timeout)
    finally:
        manager.stop_container(container_id, remove=True)