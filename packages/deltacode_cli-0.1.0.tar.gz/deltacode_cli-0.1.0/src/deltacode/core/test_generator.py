"""Security test case generator for DeltaCode CLI.

Auto-generates security test cases based on:
- CWE patterns and vulnerabilities
- Code analysis findings
- Common attack vectors per language
- OWASP testing methodologies
"""

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from deltacode.core.best_practices import CWE_DATABASE, get_cwe, get_cwes_by_category
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class SecurityTestCase:
    name: str
    cwe_id: str
    category: str
    severity: str
    language: str
    test_code: str
    description: str
    attack_vector: str = ""
    expected_result: str = ""


SECURITY_TEST_TEMPLATES = {
    "python": {
        "injection": {
            "sql_injection": SecurityTestCase(
                name="test_sql_injection",
                cwe_id="CWE-89",
                category="injection",
                severity="CRITICAL",
                language="python",
                test_code="""import pytest
from app import app, db

class TestSQLInjection:
    def test_sql_injection_login(self):
        \"\"\"Test that SQL injection in login is prevented (CWE-89).\"\"\"
        payloads = [
            \"' OR '1'='1\",
            \"' OR '1'='1' --\",
            \"admin'--\",
            \"1; DROP TABLE users--\",
            \"' UNION SELECT * FROM users--\",
        ]
        for payload in payloads:
            response = app.test_client().post("/login", json={
                "username": payload,
                "password": "anything"
            })
            assert response.status_code in (401, 400), f"SQL injection possible with payload: {payload}"
            assert "error" in response.json or response.status_code != 200

    def test_parameterized_queries(self):
        \"\"\"Verify parameterized queries are used.\"\"\"
        import inspect
        from app import get_user
        source = inspect.getsource(get_user)
        assert "f\"" not in source or "SELECT" not in source, "String formatting in SQL detected"
        assert ".format(" not in source or "SELECT" not in source, "String format in SQL detected"
        assert "%" not in source or "SELECT" not in source, "Percent formatting in SQL detected"
""",
                description="Tests for SQL injection vulnerabilities in login and verifies parameterized queries.",
                attack_vector="SQL injection via login form fields",
                expected_result="All injection payloads should return 401/400, never 200 with data.",
            ),
            "command_injection": SecurityTestCase(
                name="test_command_injection",
                cwe_id="CWE-78",
                category="injection",
                severity="CRITICAL",
                language="python",
                test_code="""import pytest
from unittest.mock import patch

class TestCommandInjection:
    def test_os_system_not_used(self):
        \"\"\"Verify os.system is not called with user input (CWE-78).\"\"\"
        import app
        import inspect
        source = inspect.getsource(app)
        assert "os.system(" not in source, "os.system() detected - use subprocess with shell=False"

    def test_subprocess_shell_false(self):
        \"\"\"Verify subprocess calls use shell=False.\"\"\"
        import inspect
        from app import ping_host
        source = inspect.getsource(ping_host)
        if "subprocess" in source:
            assert "shell=True" not in source, "subprocess with shell=True detected"
            assert "shell=False" in source or "=False" in source, "Explicitly set shell=False"

    def test_command_injection_payloads(self):
        \"\"\"Test command injection payloads are rejected.\"\"\"
        payloads = [
            "; cat /etc/passwd",
            "| cat /etc/passwd",
            "$(cat /etc/passwd)",
            "`cat /etc/passwd`",
            "& whoami",
            "|| whoami",
            "\n/bin/sh",
        ]
        for payload in payloads:
            response = app.test_client().post("/ping", json={"host": payload})
            assert response.status_code in (400, 422), f"Command injection possible: {payload}"
""",
                description="Tests for OS command injection prevention and validates subprocess usage.",
                attack_vector="Command injection via host/parameter fields",
                expected_result="All injection payloads should be rejected with 400/422.",
            ),
        },
        "xss": {
            "reflected_xss": SecurityTestCase(
                name="test_reflected_xss",
                cwe_id="CWE-79",
                category="injection",
                severity="HIGH",
                language="python",
                test_code="""import pytest
from app import app

class TestReflectedXSS:
    def test_xss_in_search(self):
        \"\"\"Test that XSS payloads are sanitized in search results (CWE-79).\"\"\"
        payloads = [
            '<script>alert(1)</script>',
            '<img src=x onerror=alert(1)>',
            '"><script>alert(1)</script>',
            "javascript:alert(1)",
            '<svg/onload=alert(1)>',
        ]
        for payload in payloads:
            response = app.test_client().get(f"/search?q={payload}")
            assert response.status_code == 200
            response_text = response.data.decode()
            assert "<script>" not in response_text.lower(), f"Unescaped script tag in response"
            assert "onerror=" not in response_text.lower(), f"Unescaped event handler in response"
            assert "javascript:" not in response_text.lower(), f"Unescaped javascript URI in response"

    def test_content_type_header(self):
        \"\"\"Verify X-Content-Type-Options header is set.\"\"\"
        response = app.test_client().get("/api/data")
        assert response.headers.get("X-Content-Type-Options") == "nosniff"

    def test_csp_header(self):
        \"\"\"Verify Content-Security-Policy header is present.\"\"\"
        response = app.test_client().get("/")
        csp = response.headers.get("Content-Security-Policy", "")
        assert csp, "Content-Security-Policy header is missing"
""",
                description="Tests for reflected XSS prevention and security headers.",
                attack_vector="XSS via search/query parameters",
                expected_result="Script tags and event handlers should be escaped/removed. Security headers present.",
            ),
        },
        "auth": {
            "brute_force": SecurityTestCase(
                name="test_brute_force_protection",
                cwe_id="CWE-287",
                category="authentication",
                severity="HIGH",
                language="python",
                test_code="""import pytest
from app import app

class TestBruteForceProtection:
    def test_rate_limiting_login(self):
        \"\"\"Test that login rate limiting is enforced (CWE-287).\"\"\"
        for i in range(10):
            response = app.test_client().post("/login", json={
                "username": "testuser",
                "password": f"wrong_password_{i}"
            })
            if i >= 5:
                assert response.status_code in (429, 403, 401), \
                    f"Rate limiting not enforced after {i+1} attempts"

    def test_account_lockout(self):
        \"\"\"Test that accounts are locked after failed attempts.\"\"\"
        for i in range(5):
            app.test_client().post("/login", json={
                "username": "locktest",
                "password": "wrong"
            })
        response = app.test_client().post("/login", json={
            "username": "locktest",
            "password": "correct_password"
        })
        assert response.status_code in (403, 423, 401), "Account should be locked after multiple failures"
""",
                description="Tests for brute-force and account lockout protection.",
                attack_vector="Brute-force password guessing",
                expected_result="Rate limiting triggered after 5 attempts. Account lockout enforced.",
            ),
        },
        "crypto": {
            "weak_hashing": SecurityTestCase(
                name="test_weak_hashing",
                cwe_id="CWE-328",
                category="cryptography",
                severity="HIGH",
                language="python",
                test_code="""import pytest
import inspect

class TestWeakHashing:
    def test_no_md5_sha1_for_passwords(self):
        \"\"\"Verify MD5/SHA1 are not used for password hashing (CWE-328).\"\"\"
        import app
        source = inspect.getsource(app)
        assert "hashlib.md5" not in source, "MD5 detected - use bcrypt/argon2 for passwords"
        assert "hashlib.sha1" not in source, "SHA1 detected - use SHA-256+ or bcrypt for passwords"

    def test_bcrypt_used_for_passwords(self):
        \"\"\"Verify bcrypt is used for password hashing.\"\"\"
        from app import hash_password
        import inspect
        source = inspect.getsource(hash_password)
        assert "bcrypt" in source or "argon2" in source or "scrypt" in source, \
            "Use bcrypt, argon2, or scrypt for password hashing"

    def test_no_hardcoded_secrets(self):
        \"\"\"Verify no hardcoded secrets in source (CWE-798).\"\"\"
        import app
        source = inspect.getsource(app)
        patterns = [
            r'password\s*=\s*["\'][^"\']{4,}["\']',
            r'secret_key\s*=\s*["\'][^"\']{4,}["\']',
            r'api_key\s*=\s*["\'][^"\']{4,}["\']',
        ]
        for pattern in patterns:
            matches = re.findall(pattern, source, re.I)
            assert not matches, f"Hardcoded secret detected: {matches}"
""",
                description="Tests for weak cryptographic patterns and hardcoded secrets.",
                attack_vector="Cryptographic weakness exploitation",
                expected_result="No MD5/SHA1 for passwords. No hardcoded secrets.",
            ),
        },
    },
    "javascript": {
        "injection": {
            "xss_dom": SecurityTestCase(
                name="test_dom_xss",
                cwe_id="CWE-79",
                category="injection",
                severity="HIGH",
                language="javascript",
                test_code="""describe('DOM XSS Prevention (CWE-79)', () => {
  const xssPayloads = [
    '<script>alert(1)</script>',
    '<img src=x onerror=alert(1)>',
    'javascript:alert(1)',
    '<svg/onload=alert(1)>',
    '"><script>alert(1)</script>',
  ];

  xssPayloads.forEach((payload) => {
    it(`should sanitize XSS payload: ${payload.substring(0, 20)}`, () => {
      const sanitized = sanitizeInput(payload);
      expect(sanitized).not.toContain('<script>');
      expect(sanitized).not.toContain('onerror=');
      expect(sanitized).not.toContain('javascript:');
    });
  });

  it('should use textContent not innerHTML', () => {
    const sourceCode = fs.readFileSync('src/renderer.js', 'utf8');
    expect(sourceCode).not.toMatch(/\\.innerHTML\\s*=.*\\$\\{/);
  });

  it('should set CSP header', () => {
    const response = request(app).get('/');
    expect(response.headers['content-security-policy']).toBeDefined();
  });
});""",
                description="Tests for DOM-based XSS prevention in JavaScript.",
                attack_vector="DOM manipulation via user input",
                expected_result="All XSS payloads sanitized. textContent used over innerHTML.",
            ),
        },
    },
}


def generate_tests_for_findings(findings: list, language: str = "python") -> str:
    if not findings:
        return "No findings to generate tests for."

    parts = [f'"""Auto-generated security test cases by DeltaCode."""\n']
    imports_set = set()
    test_classes = []

    cwe_seen = set()
    for finding in findings:
        cwe_match = re.search(r'CWE-\d+', str(finding), re.I)
        if cwe_match:
            cwe_id = cwe_match.group().upper()
            if cwe_id in cwe_seen:
                continue
            cwe_seen.add(cwe_id)

            cwe = get_cwe(cwe_id)
            if cwe:
                test_classes.append(f"# Tests for {cwe.cwe_id}: {cwe.name}\n{cwe.secure_pattern}")

    category_seen = set()
    for finding in findings:
        finding_str = str(finding).lower()
        for category in ["injection", "xss", "auth", "crypto", "credential"]:
            if category in finding_str and category not in category_seen:
                category_seen.add(category)
                lang_tests = SECURITY_TEST_TEMPLATES.get(language, {}).get(category, {})
                for test_name, test_case in lang_tests.items():
                    parts.append(f"\n# {test_case.description}")
                    parts.append(f"# Attack vector: {test_case.attack_vector}")
                    parts.append(test_case.test_code)

    if len(parts) == 1:
        parts.append("\n# No matching security test templates found for the provided findings.")
        for cwe_id in cwe_seen:
            entry = get_cwe(cwe_id)
            if entry:
                parts.append(f"\n# TODO: Generate tests for {cwe_id} - {entry.name}")
                parts.append(f"# Remediation: {entry.remediation}")

    return "\n".join(parts)


def generate_test_file(target_path: str, findings: list = None, language: str = None) -> str:
    path = Path(target_path)

    if not language:
        ext_map = {".py": "python", ".js": "javascript", ".ts": "javascript", ".java": "java"}
        language = ext_map.get(path.suffix.lower(), "python")

    if findings:
        return generate_tests_for_findings(findings, language)

    content = ""
    if path.exists():
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            pass

    detected_cwes = []
    cwe_keywords = {
        "CWE-89": ["execute", "cursor", "SELECT", "INSERT", "UPDATE", "DELETE"],
        "CWE-78": ["os.system", "subprocess", "shell=True", "os.popen", "eval("],
        "CWE-79": ["innerHTML", "document.write", "v-html", "|safe"],
        "CWE-22": ["open(", "read_file", "send_file", "Path("],
        "CWE-200": ["traceback", "exception", "str(e)", "error_page"],
        "CWE-256": ["password", "hashlib", "md5", "sha1"],
        "CWE-287": ["authenticate", "login", "session", "jwt"],
        "CWE-327": ["md5", "sha1", "DES", "ECB", "random."],
        "CWE-798": ["password =", "api_key =", "secret =", "token ="],
    }

    if content:
        for cwe_id, keywords in cwe_keywords.items():
            for keyword in keywords:
                if keyword.lower() in content.lower():
                    detected_cwes.append(cwe_id)
                    break

    return generate_tests_for_findings(detected_cwes or ["CWE-89", "CWE-78", "CWE-79", "CWE-798"], language)


def list_available_tests(language: str = None) -> str:
    parts = ["Available Security Test Templates\n"]

    for lang, categories in SECURITY_TEST_TEMPLATES.items():
        if language and language.lower() != lang:
            continue
        parts.append(f"\n### {lang.upper()}")
        for category, tests in categories.items():
            parts.append(f"\n  [{category}]")
            for test_name, test_case in tests.items():
                parts.append(f"    {test_case.name} ({test_case.cwe_id}, {test_case.severity})")
                parts.append(f"      {test_case.description}")

    return "\n".join(parts)