"""Feedback loop integration for DeltaCode CLI.

Aggregates feedback from:
- Agent task results (success/failure patterns)
- Human reviewer feedback on fixes
- False positive reports
- Pattern refinement triggers

Feeds into:
- Knowledge base (learned rules)
- Effectiveness tracker (accuracy improvement)
- Custom rule engine (pattern refinement)
"""

from __future__ import annotations

import json
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from deltacode.core.logger import get_logger
from deltacode.core.knowledge_base import OrgKnowledgeBase
from deltacode.core.effectiveness_tracker import EffectivenessTracker

logger = get_logger(__name__)


@dataclass
class FeedbackItem:
    id: str
    feedback_type: str
    source: str
    target_id: str
    rating: int
    comment: str
    created_at: str
    metadata: dict = field(default_factory=dict)


@dataclass
class PatternSuggestion:
    id: str
    pattern: str
    message: str
    severity: str
    language: str
    source_count: int
    confidence: float
    status: str
    similar_cwe: str = ""


class FeedbackLoop:
    def __init__(self, data_dir: str = None):
        self.data_dir = Path(data_dir or Path.home() / ".deltacode" / "feedback")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._feedback: list[FeedbackItem] = []
        self._suggestions: list[PatternSuggestion] = []
        self._knowledge_base = OrgKnowledgeBase()
        self._effectiveness = EffectivenessTracker()
        self._load()

    def _load(self):
        fb_file = self.data_dir / "feedback.json"
        if fb_file.exists():
            try:
                data = json.loads(fb_file.read_text(encoding="utf-8"))
                self._feedback = [FeedbackItem(**f) for f in data]
            except Exception:
                pass

        sg_file = self.data_dir / "suggestions.json"
        if sg_file.exists():
            try:
                data = json.loads(sg_file.read_text(encoding="utf-8"))
                self._suggestions = [PatternSuggestion(**s) for s in data]
            except Exception:
                pass

    def _save(self):
        fb_file = self.data_dir / "feedback.json"
        fb_file.write_text(json.dumps(
            [f.__dict__ for f in self._feedback], indent=2, ensure_ascii=False
        ), encoding="utf-8")

        sg_file = self.data_dir / "suggestions.json"
        sg_file.write_text(json.dumps(
            [s.__dict__ for s in self._suggestions], indent=2, ensure_ascii=False
        ), encoding="utf-8")

    def submit_feedback(self, feedback_type: str, source: str, target_id: str,
                        rating: int, comment: str = "", metadata: dict = None) -> FeedbackItem:
        item = FeedbackItem(
            id=uuid.uuid4().hex[:12],
            feedback_type=feedback_type,
            source=source,
            target_id=target_id,
            rating=max(1, min(5, rating)),
            comment=comment,
            created_at=datetime.utcnow().isoformat(),
            metadata=metadata or {},
        )
        self._feedback.append(item)
        self._save()

        if rating <= 2 and metadata:
            cwe = metadata.get("cwe", "CWE-unknown")
            pattern = metadata.get("pattern", "unknown")
            self._effectiveness.report_false_positive(cwe, pattern, comment or "Low rating feedback")

        return item

    def get_feedback(self, feedback_type: str = None, source: str = None,
                     since_days: int = 7) -> list[FeedbackItem]:
        cutoff = datetime.utcnow() - timedelta(days=since_days)
        results = []
        for item in self._feedback:
            try:
                dt = datetime.fromisoformat(item.created_at)
            except Exception:
                dt = datetime.min
            if dt < cutoff:
                continue
            if feedback_type and item.feedback_type != feedback_type:
                continue
            if source and item.source != source:
                continue
            results.append(item)
        return sorted(results, key=lambda x: x.created_at, reverse=True)

    def get_avg_rating(self, target_id: str = None, feedback_type: str = None) -> float:
        items = self._feedback
        if target_id:
            items = [i for i in items if i.target_id == target_id]
        if feedback_type:
            items = [i for i in items if i.feedback_type == feedback_type]
        if not items:
            return 0.0
        return round(sum(i.rating for i in items) / len(items), 1)

    # ── Pattern Suggestion from Agent Results ────────────────────────────

    def process_agent_result(self, agent_name: str, result: dict, findings: list):
        suggestion_count = 0
        for f in findings[:10]:
            if not isinstance(f, dict):
                continue
            cwe = f.get("cwe", f.get("cwe_id", ""))
            severity = f.get("severity", "MEDIUM")
            desc = f.get("description", f.get("message", ""))
            file_path = f.get("file", "")

            if not desc or len(desc) < 15:
                continue

            import re
            pattern_base = re.sub(r'[^a-zA-Z0-9\s]', '', desc)[:30].lower().replace(' ', '_')

            similar = [s for s in self._suggestions if pattern_base[:15] in s.pattern]
            if similar:
                similar[0].source_count += 1
                similar[0].confidence = min(similar[0].confidence + 0.05, 1.0)
            else:
                suggestion = PatternSuggestion(
                    id=uuid.uuid4().hex[:12],
                    pattern=f"suggested_{pattern_base}",
                    message=desc[:120],
                    severity=severity,
                    language=Path(file_path).suffix[1:] if file_path else "python",
                    source_count=1,
                    confidence=0.3,
                    status="pending",
                    similar_cwe=cwe,
                )
                self._suggestions.append(suggestion)
                suggestion_count += 1

            self._knowledge_base.learn_rule_from_finding(f, Path(file_path).suffix[1:] if file_path else "python")

        if suggestion_count > 0:
            self._save()
        return suggestion_count

    def approve_suggestion(self, suggestion_id: str) -> bool:
        for s in self._suggestions:
            if s.id == suggestion_id:
                s.status = "approved"
                s.confidence = min(s.confidence + 0.2, 1.0)
                self._knowledge_base.add_entry(
                    entry_type="learned_rule",
                    title=s.message,
                    content=f"Auto-learned: {s.pattern}",
                    tags=["learned", s.language, s.severity.lower()],
                    metadata={
                        "pattern": s.pattern,
                        "severity": s.severity,
                        "language": s.language,
                        "cwe": s.similar_cwe,
                        "source_count": s.source_count,
                    },
                )
                self._save()
                return True
        return False

    def reject_suggestion(self, suggestion_id: str) -> bool:
        for s in self._suggestions:
            if s.id == suggestion_id:
                s.status = "rejected"
                self._save()
                return True
        return False

    def get_pending_suggestions(self) -> list[PatternSuggestion]:
        return [s for s in self._suggestions if s.status == "pending"]

    def get_stats(self) -> dict:
        total = len(self._feedback)
        ratings = [f.rating for f in self._feedback]
        return {
            "total_feedback": total,
            "avg_rating": round(sum(ratings) / max(len(ratings), 1), 1) if ratings else 0,
            "by_type": dict(
                (t, len([f for f in self._feedback if f.feedback_type == t]))
                for t in set(f.feedback_type for f in self._feedback)
            ),
            "pending_suggestions": len(self.get_pending_suggestions()),
            "approved_suggestions": len([s for s in self._suggestions if s.status == "approved"]),
            "knowledge_entries": self._knowledge_base.get_stats().get("total_entries", 0),
            "effectiveness": self._effectiveness.get_fix_stats(),
        }