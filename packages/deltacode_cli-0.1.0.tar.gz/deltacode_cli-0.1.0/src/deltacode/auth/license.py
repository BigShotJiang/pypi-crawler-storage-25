"""DeltaCode license validation.

Validates license keys against DeltaAI backend.
License + organization are set per-customer via `deltacode auth login`.
No hardcoded credentials.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from deltacode.client.api import DeltaAIClient
from deltacode.core.config import DeltaCodeConfig
from deltacode.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class LicenseInfo:
    valid: bool
    organization: str = ""
    tier: str = "community"
    expires_at: str = ""
    features: list[str] = None
    error: str = ""

    def __post_init__(self):
        if self.features is None:
            self.features = []


def validate_license(config: Optional[DeltaCodeConfig] = None) -> LicenseInfo:
    cfg = config or DeltaCodeConfig.load()

    if not cfg.license_key:
        return LicenseInfo(valid=False, error="No license key configured. Run: deltacode auth login")

    if not cfg.api_url:
        return LicenseInfo(valid=False, error="No API URL configured. Run: deltacode auth login")

    client = DeltaAIClient(cfg)
    try:
        result = client.validate_license()

        if result.get("valid"):
            return LicenseInfo(
                valid=True,
                organization=result.get("organization", cfg.organization),
                tier=result.get("tier", "enterprise"),
                expires_at=result.get("expires_at", ""),
                features=result.get("features", []),
            )
        else:
            return LicenseInfo(
                valid=False,
                error=result.get("error", "License validation failed"),
            )
    except Exception as e:
        logger.warning(f"License validation failed: {e}")
        return LicenseInfo(valid=False, error=f"Connection error: {e}")
    finally:
        client.close()


def check_feature(feature: str, config: Optional[DeltaCodeConfig] = None) -> bool:
    info = validate_license(config)
    if not info.valid:
        return False
    if info.tier == "enterprise":
        return True
    return feature in info.features


def validate_ip_whitelist(config: Optional[DeltaCodeConfig] = None) -> dict:
    """Validate the current IP against the license's IP whitelist.

    Returns dict with keys: allowed (bool), ip (str), message (str).
    """
    import socket

    cfg = config or DeltaCodeConfig.load()

    if not cfg.license_key:
        return {"allowed": False, "ip": "", "message": "No license key configured"}

    client = DeltaAIClient(cfg)
    try:
        result = client.validate_license()
        if not result.get("valid"):
            return {"allowed": False, "ip": "", "message": result.get("error", "Invalid license")}

        allowed_ips = result.get("allowed_ips", [])
        if not allowed_ips:
            return {"allowed": True, "ip": "", "message": "No IP restrictions on this license"}

        hostname = socket.gethostname()
        try:
            local_ip = socket.gethostbyname(hostname)
        except socket.gaierror:
            local_ip = "127.0.0.1"

        import httpx
        try:
            resp = httpx.get("https://api.ipify.org", timeout=5)
            public_ip = resp.text.strip() if resp.status_code == 200 else local_ip
        except Exception:
            public_ip = local_ip

        for ip_entry in allowed_ips:
            if "/" in ip_entry:
                import ipaddress
                try:
                    network = ipaddress.ip_network(ip_entry, strict=False)
                    if ipaddress.ip_address(public_ip) in network:
                        return {"allowed": True, "ip": public_ip, "message": "IP within allowed range"}
                except ValueError:
                    continue
            elif ip_entry == public_ip or ip_entry == local_ip:
                return {"allowed": True, "ip": public_ip, "message": "IP is whitelisted"}

        return {"allowed": False, "ip": public_ip, "message": f"IP {public_ip} not in whitelist: {allowed_ips}"}
    except Exception as e:
        return {"allowed": False, "ip": "", "message": f"IP whitelist check failed: {e}"}
    finally:
        client.close()