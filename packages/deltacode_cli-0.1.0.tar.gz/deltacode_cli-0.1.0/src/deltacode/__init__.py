"""DeltaCode Security CLI - AI-powered security analysis and remediation."""

__version__ = "0.1.0"