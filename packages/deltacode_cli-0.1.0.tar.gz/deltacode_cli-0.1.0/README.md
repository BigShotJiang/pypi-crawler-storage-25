<div align="center">

# DeltaCode Security CLI

**AI-powered security analysis, vulnerability detection, and autonomous remediation.**

[![Version](https://img.shields.io/badge/version-0.1.0-blue.svg)]()
[![License](https://img.shields.io/badge/license-Apache%202.0-green.svg)]()
[![Python](https://img.shields.io/badge/python-3.10%2B-purple.svg)]()

</div>

---

## Quick Start

```bash
# Install
pip install deltacode-cli

# Authenticate with your DeltaAI license
deltacode auth login --api-url https://your-deltaai-server:8100 --api-key YOUR_API_KEY --license-key YOUR_LICENSE_KEY --organization YOUR_ORG

# Check status
deltacode status

# Scan a project for vulnerabilities
deltacode deps
deltacode secrets
deltacode rules scan ./src

# Generate a security assessment plan
deltacode assess

# Run the autonomous security pipeline
deltacode pipeline run
```

---

## Features

| Category | Features |
|----------|----------|
| **Vulnerability Detection** | Static analysis (Semgrep, Bandit, CodeQL, 23 custom rules), secret scanning (30+ patterns, TruffleHog, GitLeaks, entropy detection), dependency analysis (pip, npm, cargo, go), supply chain risk assessment |
| **Intelligent Remediation** | Auto-fix engine (SEARCH/REPLACE, rollback, validation), 16 CWE best-practice library, security test generation, regression/mutation/coverage testing, exploit fix verification |
| **Threat Intelligence** | CVE/NVD search & details, CISA Known Exploited Vulns, MITRE ATT&CK framework, CWE/CAPEC knowledge base, IOC extraction, trending CVEs, vendor advisory RSS (8 sources) |
| **Autonomous Workflows** | 6-agent security team (Analyzer, Researcher, Fixer, Validator, Compliance, Coordinator), scan→analyze→fix→validate→compliance pipeline, scheduled audits, incident response automation |
| **Enterprise Compliance** | SOC 2 (10 controls), ISO 27001 (9 controls), PCI-DSS v4.0 (10 controls), HIPAA Security Rule (20 controls), GDPR (15 articles), custom compliance rules, evidence collection, risk dashboard, trend analysis |
| **Tool Integration (MCP)** | Burp Suite, OWASP ZAP, Metasploit, Nessus/OpenVAS, NVD, MITRE ATT&CK, CWE/CAPEC, vendor docs — 8 connectors, 34 tools |
| **Security Research** | Playwright-based browser agent, CVE researcher, vendor advisory scraper, 12 RSS security feeds, citation & attribution system |
| **Operational Security** | Audit trail, anomaly detection, decision review, feedback loop, role-based approval gates, emergency stop, encrypted credential storage |

---

## Quick Examples

```bash
# Dependency vulnerability scan
deltacode deps

# Secret detection
deltacode secrets

# CWE lookup with remediation patterns
deltacode cwe 89 --remediation

# Supply chain risk assessment
deltacode supply-chain

# CVE threat intelligence check
deltacode threat intel --query "CVE-2024-21626"

# Trend analysis
deltacode trend snapshot --target ./project
deltacode trend summary

# Risk dashboard
deltacode risk dashboard

# Compliance report (HIPAA, GDPR, SOC2, etc.)
deltacode compliance report --framework hipaa

# Mutation testing
deltacode testmutation --target ./src

# MCP tool execution
deltacode mcp search-cve --query "apache struts"

# Autonomous pipeline
deltacode pipeline run --target ./project --auto-approve
```

---

## Documentation

- [Deployment Guide](docs/DEPLOYMENT.md)
- [CLI Reference](docs/CLI_REFERENCE.md)
- [Security & Compliance](docs/DEPLOYMENT.md#security-notes)

---

## System Requirements

- **Python**: 3.10 or later
- **Operating System**: Linux, macOS, Windows
- **DeltaAI API**: A running DeltaAI server instance for LLM-powered features
- **Optional**: Docker (for sandboxed execution), Playwright (for browser research)

---

## License

Apache 2.0. See [LICENSE](LICENSE) for details.

**Legal Notice:** This tool is intended for authorized security testing only. Users must have explicit permission to scan any systems. Misuse for unauthorized access is prohibited.

---

## Support

- Enterprise support: [dev@deltaai.com](mailto:dev@deltaai.com)
- Report issues: [GitHub Issues](https://github.com/deltaai/deltacode/issues)
- Documentation: [docs.deltaai.com](https://docs.deltaai.com)
