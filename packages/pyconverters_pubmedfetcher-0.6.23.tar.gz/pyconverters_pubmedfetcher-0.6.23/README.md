# pyconverters_pubmedfetcher

[![license](https://img.shields.io/github/license/oterrier/pyconverters_pubmedfetcher)](https://github.com/oterrier/pyconverters_pubmedfetcher/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyconverters_pubmedfetcher/workflows/tests/badge.svg)](https://github.com/oterrier/pyconverters_pubmedfetcher/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyconverters_pubmedfetcher)](https://codecov.io/gh/oterrier/pyconverters_pubmedfetcher)
[![docs](https://img.shields.io/readthedocs/pyconverters_pubmedfetcher)](https://pyconverters_pubmedfetcher.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyconverters_pubmedfetcher)](https://pypi.org/project/pyconverters_pubmedfetcher/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyconverters_pubmedfetcher)](https://pypi.org/project/pyconverters_pubmedfetcher/)

Fetch articles from Pubmed

## Installation

You can simply `pip install pyconverters_pubmedfetcher`.

## Developing

### Pre-requesites

You will need to install `uv` (for managing dependencies and running tasks):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyconverters_pubmedfetcher
```

### Running the test suite

You can run the full test suite with:

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

You can build the HTML documentation with:

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
