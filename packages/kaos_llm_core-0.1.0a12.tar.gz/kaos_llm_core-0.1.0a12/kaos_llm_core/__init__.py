"""kaos-llm-core — LLM programming primitives for KAOS.

Typed, composable, optimizable LLM functions built on kaos-llm-client.

Core abstractions:
- ``Signature`` — typed I/O contract for LLM functions
- ``Call`` — single LLM invocation with a Signature
- ``Program`` — composed LLM function (multiple Calls)
- ``Codec`` — bidirectional format translation (Signature ↔ messages)
- ``Example`` — few-shot training instance
- ``@llm_call`` — decorator syntax for simple LLM functions

Higher-level "starter" API (Phase 8): :func:`text`, :func:`extract`,
:func:`classify`, :func:`summarize` (and ``_sync`` variants) for the
80% case where you just want a one-shot LLM call.

Composed program primitives: :class:`ReAct`, :class:`Refine`,
:class:`BestOfN`, :class:`Judge`, :class:`Ensemble`, :class:`ChainOfThought`.

Observability: :class:`ExecutionTrace`, :class:`CallHooks`,
:class:`ProgramHooks`, :func:`collect_traces`, :func:`push_trace`.

Optimization: :class:`Budget`, :class:`BudgetTracker`, the optimizer
classes, the recipe layer, and the Pareto frontier helpers.
"""

from kaos_llm_core._version import __version__
from kaos_llm_core.cache import SemanticCache
from kaos_llm_core.codecs import ChatCodec, Codec, JSONCodec, XMLCodec
from kaos_llm_core.composition import (
    Aggregator,
    IntersectionAggregator,
    MajorityAggregator,
    MapReduce,
    MaxScoreAggregator,
    Reducer,
    Tree,
    UnionAggregator,
    VoteAggregator,
    WeightedAggregator,
)

# NOTE: ``kaos_llm_core.composition.Refine`` (a reducer) intentionally
# is not re-exported here — the existing ``kaos_llm_core.programs.Refine``
# (an iterative-refinement Program) holds the short ``Refine`` name on
# the public top-level surface. Reach the reducer via
# ``kaos_llm_core.composition.Refine``.
from kaos_llm_core.errors import (
    CallError,
    CodecError,
    KaosLLMCoreError,
    SignatureError,
    ValidationRetryExhaustedError,
)
from kaos_llm_core.labels import ABSTAIN_LABEL, Label, LabelSet
from kaos_llm_core.observability import ExecutionTrace
from kaos_llm_core.observability.collectors import collect_traces, push_trace
from kaos_llm_core.observability.cost import apply_cost_estimates, estimate_cost, format_cost_report
from kaos_llm_core.observability.export import export_jsonl, load_jsonl
from kaos_llm_core.optimization import (
    BootstrapOptimizer,
    Budget,
    BudgetTracker,
    CodecOptimizationResult,
    CodecOptimizer,
    CoOptimizer,
    EvalResult,
    HyperparameterOptimizer,
    InstructionOptimizer,
    MiproLiteOptimizer,
    MiproLiteResult,
    MiproV2Config,
    MiproV2Optimizer,
    MiproV2Result,
    ModelOptimizationResult,
    ModelOptimizer,
    Mutation,
    MutationLog,
    ParetoOptimizer,
    ParetoResult,
    ReflectiveOptimizer,
    StopReason,
    compute_pareto_frontier,
    evaluate,
)
from kaos_llm_core.optimization.recipes import (
    CostAwareModelSelector,
    ExampleFirstTuner,
    FriendlyPromptTuner,
)
from kaos_llm_core.programs import (
    RAG,
    BatchError,
    BatchInputSource,
    BatchItem,
    BatchProgress,
    BatchResult,
    BatchResumeMismatchError,
    BatchStopAfterNError,
    BatchUnsupportedBackendError,
    BestOfN,
    BestOfNResult,
    Call,
    CallHooks,
    CallPlan,
    ClientSpec,
    CorpusQA,
    EnvelopeStep,
    HasOutputs,
    InputSpec,
    Invocation,
    JsonlBatchWriter,
    JsonlInputSource,
    ListInputSource,
    MultiChainComparison,
    MultiChainComparisonResult,
    OutputForwardingMixin,
    PdfPagesInputSource,
    Program,
    ProgramEnvelope,
    ProgramEnvelopeError,
    ProgramHooks,
    ProgramOfThought,
    ProgramOfThoughtError,
    ProgramOfThoughtResult,
    RAGResult,
    Refine,
    RefineHistoryEntry,
    RefineResult,
    TabularRowsInputSource,
    TokenUsage,
    Tool,
    Tunable,
    batch_run,
    build_passage_context,
    current_invocation,
    from_envelope,
    jsonl_input_source,
    list_input_source,
    llm_call,
    pdf_pages_input_source,
    program_hash,
    tabular_rows_input_source,
)
from kaos_llm_core.programs.chain_of_thought import ChainOfThought
from kaos_llm_core.programs.classify import (
    ChunkedClassify,
    EnsembleClassify,
    FewShotClassify,
    HierarchicalClassify,
    MultiLabelClassify,
    ZeroShotClassify,
)
from kaos_llm_core.programs.ensemble import Ensemble
from kaos_llm_core.programs.grounded import Grounded, GroundedResult
from kaos_llm_core.programs.judge import Judge, JudgedResult
from kaos_llm_core.programs.react import Iteration, ReAct, ReActResult, ToolObservation
from kaos_llm_core.programs.reranker import JudgeReranker
from kaos_llm_core.programs.summarize import (
    AbstractiveSummary,
    AbstractiveSummarySignature,
    CitedSummary,
    HierarchicalSummary,
    MapReduceSummary,
    RefineSummary,
    StructuredSummary,
)
from kaos_llm_core.results import (
    Classification,
    Entities,
    EntitySpan,
    SourceSpan,
    Summary,
    SummaryMethod,
)
from kaos_llm_core.router import CascadeRouter, Router, Rule, RuleRouter
from kaos_llm_core.settings import KaosLLMCoreSettings
from kaos_llm_core.signatures import (
    Cited,
    InputField,
    OutputField,
    Signature,
    tag_paragraphs,
    tag_passages,
    validate_cited_output,
)
from kaos_llm_core.signatures.multimodal import Audio, Document, Image
from kaos_llm_core.starter import (
    classify,
    classify_sync,
    extract,
    extract_sync,
    summarize,
    summarize_sync,
    text,
    text_sync,
)
from kaos_llm_core.types import Example

__all__ = [
    "ABSTAIN_LABEL",
    "RAG",
    "AbstractiveSummary",
    "AbstractiveSummarySignature",
    "Aggregator",
    "Audio",
    "BatchError",
    "BatchInputSource",
    "BatchItem",
    "BatchProgress",
    "BatchResult",
    "BatchResumeMismatchError",
    "BatchStopAfterNError",
    "BatchUnsupportedBackendError",
    "BestOfN",
    "BestOfNResult",
    "BootstrapOptimizer",
    "Budget",
    "BudgetTracker",
    "Call",
    "CallError",
    "CallHooks",
    "CallPlan",
    "CascadeRouter",
    "ChainOfThought",
    "ChatCodec",
    "ChunkedClassify",
    "Cited",
    "CitedSummary",
    "Classification",
    "ClientSpec",
    "CoOptimizer",
    "Codec",
    "CodecError",
    "CodecOptimizationResult",
    "CodecOptimizer",
    "CorpusQA",
    "CostAwareModelSelector",
    "Document",
    "Ensemble",
    "EnsembleClassify",
    "Entities",
    "EntitySpan",
    "EnvelopeStep",
    "EvalResult",
    "Example",
    "ExampleFirstTuner",
    "ExecutionTrace",
    "FewShotClassify",
    "FriendlyPromptTuner",
    "Grounded",
    "GroundedResult",
    "HasOutputs",
    "HierarchicalClassify",
    "HierarchicalSummary",
    "HyperparameterOptimizer",
    "Image",
    "InputField",
    "InputSpec",
    "InstructionOptimizer",
    "IntersectionAggregator",
    "Invocation",
    "Iteration",
    "JSONCodec",
    "JsonlBatchWriter",
    "JsonlInputSource",
    "Judge",
    "JudgeReranker",
    "JudgedResult",
    "KaosLLMCoreError",
    "KaosLLMCoreSettings",
    "Label",
    "LabelSet",
    "ListInputSource",
    "MajorityAggregator",
    "MapReduce",
    "MapReduceSummary",
    "MaxScoreAggregator",
    "MiproLiteOptimizer",
    "MiproLiteResult",
    "MiproV2Config",
    "MiproV2Optimizer",
    "MiproV2Result",
    "ModelOptimizationResult",
    "ModelOptimizer",
    "MultiChainComparison",
    "MultiChainComparisonResult",
    "MultiLabelClassify",
    "Mutation",
    "MutationLog",
    "OutputField",
    "OutputForwardingMixin",
    "ParetoOptimizer",
    "ParetoResult",
    "PdfPagesInputSource",
    "Program",
    "ProgramEnvelope",
    "ProgramEnvelopeError",
    "ProgramHooks",
    "ProgramOfThought",
    "ProgramOfThoughtError",
    "ProgramOfThoughtResult",
    "RAGResult",
    "ReAct",
    "ReActResult",
    "Reducer",
    "Refine",
    "RefineHistoryEntry",
    "RefineResult",
    "RefineSummary",
    "ReflectiveOptimizer",
    "Router",
    "Rule",
    "RuleRouter",
    "SemanticCache",
    "Signature",
    "SignatureError",
    "SourceSpan",
    "StopReason",
    "StructuredSummary",
    "Summary",
    "SummaryMethod",
    "TabularRowsInputSource",
    "TokenUsage",
    "Tool",
    "ToolObservation",
    "Tree",
    "Tunable",
    "UnionAggregator",
    "ValidationRetryExhaustedError",
    "VoteAggregator",
    "WeightedAggregator",
    "XMLCodec",
    "ZeroShotClassify",
    "__version__",
    "apply_cost_estimates",
    "batch_run",
    "build_passage_context",
    "classify",
    "classify_sync",
    "collect_traces",
    "compute_pareto_frontier",
    "current_invocation",
    "estimate_cost",
    "evaluate",
    "export_jsonl",
    "extract",
    "extract_sync",
    "format_cost_report",
    "from_envelope",
    "jsonl_input_source",
    "list_input_source",
    "llm_call",
    "load_jsonl",
    "pdf_pages_input_source",
    "program_hash",
    "push_trace",
    "summarize",
    "summarize_sync",
    "tabular_rows_input_source",
    "tag_paragraphs",
    "tag_passages",
    "text",
    "text_sync",
    "validate_cited_output",
]


# KC6 / F2 follow-up: the kaos-agents test recorder needs LLM calls
# made inside subprocesses (kaos-agents-serve, MCP shells, CLI tools)
# to be captured the same way as in-process calls. Setting
# ``KAOS_LLM_CORE_RECORDER_DIR=<path>`` in the subprocess environment
# triggers the patch below at import time. No-op when the env var is
# unset, which is the production default. Failures are swallowed —
# telemetry must never break execution.
try:
    from kaos_llm_core.observability.env_recorder import (
        install_from_env as _install_env_recorder,
    )

    _install_env_recorder()
except Exception:
    pass
