"""Tests for PGNotificationHub."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from shared.pg_listener import PGNotificationHub, QUEUE_MAXSIZE


@pytest.fixture
def hub():
    return PGNotificationHub(dsn="postgresql://test/test")


@pytest.fixture
def mock_conn():
    conn = MagicMock()
    conn.is_closed.return_value = False
    conn.add_listener = AsyncMock()
    conn.remove_listener = AsyncMock()
    conn.add_termination_listener = MagicMock()
    conn.close = AsyncMock()
    return conn


# ---------------------------------------------------------------------------
# subscribe / listen lifecycle
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_subscribe_first_subscriber_calls_add_listener(hub, mock_conn):
    with patch("asyncpg.connect", new=AsyncMock(return_value=mock_conn)):
        async with hub.subscribe("chan_a") as _:
            mock_conn.add_listener.assert_called_once_with(
                "chan_a", hub._callbacks["chan_a"]
            )


@pytest.mark.asyncio
async def test_subscribe_second_subscriber_does_not_call_add_listener_again(
    hub, mock_conn
):
    with patch("asyncpg.connect", new=AsyncMock(return_value=mock_conn)):
        async with hub.subscribe("chan_a"):
            async with hub.subscribe("chan_a"):
                assert mock_conn.add_listener.call_count == 1


@pytest.mark.asyncio
async def test_last_subscriber_calls_remove_listener(hub, mock_conn):
    with patch("asyncpg.connect", new=AsyncMock(return_value=mock_conn)):
        async with hub.subscribe("chan_a"):
            pass
        mock_conn.remove_listener.assert_called_once_with(
            "chan_a", mock_conn.add_listener.call_args[0][1]
        )


@pytest.mark.asyncio
async def test_non_last_subscriber_does_not_call_remove_listener(hub, mock_conn):
    with patch("asyncpg.connect", new=AsyncMock(return_value=mock_conn)):
        async with hub.subscribe("chan_a"):
            async with hub.subscribe("chan_a"):
                pass
            # Second exited — first still active, should NOT remove yet
            mock_conn.remove_listener.assert_not_called()


# ---------------------------------------------------------------------------
# reconnect behaviour
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_reconnect_relistens_all_active_channels(hub, mock_conn):
    with patch("asyncpg.connect", new=AsyncMock(return_value=mock_conn)):
        async with hub.subscribe("chan_a"):
            async with hub.subscribe("chan_b"):
                # Simulate termination + reconnect
                hub._conn = None
                hub._callbacks.clear()
                await hub._ensure_connection_locked()

                listened = [c[0][0] for c in mock_conn.add_listener.call_args_list]
                assert "chan_a" in listened
                assert "chan_b" in listened


@pytest.mark.asyncio
async def test_reconnect_count_increments_on_each_reconnect(hub, mock_conn):
    assert hub.reconnect_count == 0
    with patch("asyncpg.connect", new=AsyncMock(return_value=mock_conn)):
        await hub._ensure_connection_locked()
        assert hub.reconnect_count == 1

        hub._conn = None
        hub._callbacks.clear()
        await hub._ensure_connection_locked()
        assert hub.reconnect_count == 2


@pytest.mark.asyncio
async def test_reconnect_count_does_not_increment_when_already_connected(
    hub, mock_conn
):
    with patch("asyncpg.connect", new=AsyncMock(return_value=mock_conn)):
        await hub._ensure_connection_locked()
        first_count = hub.reconnect_count
        await hub._ensure_connection_locked()
        assert hub.reconnect_count == first_count


# ---------------------------------------------------------------------------
# queue overflow
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_full_queue_logs_warning_and_drops_payload(hub, mock_conn, caplog):
    with patch("asyncpg.connect", new=AsyncMock(return_value=mock_conn)):
        async with hub.subscribe("chan_a") as queue:
            # Fill queue to capacity
            for i in range(QUEUE_MAXSIZE):
                queue.put_nowait(f"payload_{i}")

            callback = hub._callbacks["chan_a"]
            import logging

            with caplog.at_level(logging.WARNING, logger="shared.pg_listener"):
                callback(None, None, "chan_a", "overflow_payload")

            assert queue.full()
            assert (
                "queue full" in caplog.text.lower() or "dropping" in caplog.text.lower()
            )
