"""Async input request management for Claude Code Wrapper.

Receives user messages via SSE subscription to the servers
``/api/v1/agents/instances/{id}/stream`` endpoint instead of polling.

Two concurrent async tasks run in the same event loop:
- ``sse_listener_loop``: subscribes to SSE and delivers user messages instantly.
- ``idle_monitor_loop``: detects when Claude is idle and calls
  ``PATCH /messages/{id}/request-input`` to mark the last message as needing
  input (sets ``requires_user_input=True``, transitions status to
  ``AWAITING_INPUT``, fires push notifications to web/app).
"""

import asyncio
import base64
import json
import threading
import time
from typing import Any, Callable, Optional, Set, TYPE_CHECKING
from urllib.parse import urljoin

import aiohttp

if TYPE_CHECKING:
    from vicoa.sdk.async_client import AsyncVicoaClient
    from .processor import MessageProcessor
    from .queue_manager import MessageQueue
    from ..state.session_state import SessionState
    from ..state.toggle_manager import ToggleManager
    from ..terminal.pty_manager import PTYManager
from ..config import CONTROL_JSON_PATTERN


class InputRequestManager:
    """Manages user input delivery from Vicoa web/app UI to the CLI wrapper.

    Connects to the servers SSE endpoint and receives ``user_message`` events
    in real-time, replacing the previous 1.5 s control poller and 3 s
    long-poll input-request loop.
    """

    def __init__(
        self,
        agent_instance_id: str,
        agent_name: str,
        vicoa_client_async: Optional["AsyncVicoaClient"],
        vicoa_client_sync,  # VicoaClient
        message_processor: "MessageProcessor",
        message_queue: "MessageQueue",
        session_state: "SessionState",
        toggle_manager: "ToggleManager",
        pty_manager: "PTYManager",
        log_func: Callable[[str], None],
    ):
        """Initialize input request manager.

        Args:
            agent_instance_id: Agent instance ID
            agent_name: Agent display name
            vicoa_client_async: Async Vicoa client for long-polling
            vicoa_client_sync: Sync Vicoa client for feedback messages
            message_processor: Message processor instance
            message_queue: Message queue for queuing responses to CLI
            session_state: Session state manager
            toggle_manager: Toggle manager for control settings
            pty_manager: PTY manager for sending interrupts
            log_func: Logging function
        """
        self.agent_instance_id = agent_instance_id
        self.agent_name = agent_name
        self.vicoa_client_async = vicoa_client_async
        self.vicoa_client_sync = vicoa_client_sync
        self.message_processor = message_processor
        self.message_queue = message_queue
        self.session_state = session_state
        self.toggle_manager = toggle_manager
        self.pty_manager = pty_manager
        self.log = log_func

        # State
        self.running = True
        self.async_loop: Optional[asyncio.AbstractEventLoop] = None
        self.async_thread: Optional[threading.Thread] = None
        self.requested_input_messages: Set[str] = set()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start the SSE listener and idle monitor in a background thread."""

        async def run_both():
            await asyncio.gather(
                self.sse_listener_loop(),
                self.idle_monitor_loop(),
            )

        def run_async_loop():
            try:
                self.async_loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self.async_loop)
                self.async_loop.run_until_complete(run_both())
            except (KeyboardInterrupt, RuntimeError):
                pass
            except Exception as e:
                self.log(f"[ERROR] Error in async loop: {e}")

        self.async_thread = threading.Thread(target=run_async_loop, daemon=True)
        self.async_thread.start()

    def stop(self) -> None:
        """Stop the SSE listener."""
        self.running = False
        if self.async_loop and self.async_loop.is_running():
            self.async_loop.call_soon_threadsafe(self.async_loop.stop)

    # ------------------------------------------------------------------
    # SSE listener
    # ------------------------------------------------------------------

    async def sse_listener_loop(self) -> None:
        """Connect to the servers SSE endpoint and process user_message events.

        Reconnects with exponential back-off (1 s → 2 s → 4 s … capped at 60 s)
        so transient network blips are handled transparently.
        """
        if not self.vicoa_client_async:
            self.log(
                "[ERROR] Vicoa async client not initialized; SSE listener will not start"
            )
            return

        await self.vicoa_client_async._ensure_session()

        base_url = self.vicoa_client_async.base_url
        stream_url = urljoin(
            base_url.rstrip("/") + "/",
            f"api/v1/agents/instances/{self.agent_instance_id}/stream",
        )
        headers = {
            "Authorization": f"Bearer {self.vicoa_client_async.api_key}",
            "Accept": "text/event-stream",
            "Cache-Control": "no-cache",
        }

        backoff = 1.0
        max_backoff = 60.0

        while self.running:
            try:
                self.log(f"[INFO] SSE connecting to {stream_url}")
                ssl_ctx = self.vicoa_client_async.session.connector._ssl  # type: ignore[union-attr]

                timeout = aiohttp.ClientTimeout(total=None, sock_read=60)
                async with aiohttp.ClientSession(
                    headers=headers,
                    timeout=timeout,
                ) as sse_session:
                    async with sse_session.get(stream_url, ssl=ssl_ctx) as resp:
                        if resp.status != 200:
                            body = await resp.text()
                            self.log(
                                f"[WARNING] SSE endpoint returned {resp.status}: {body}"
                            )
                            await asyncio.sleep(backoff)
                            backoff = min(backoff * 2, max_backoff)
                            continue

                        self.log("[INFO] SSE stream connected")
                        backoff = 1.0  # reset on success

                        await self._read_sse_stream(resp)

            except asyncio.CancelledError:
                break
            except Exception as e:
                if self.running:
                    self.log(
                        f"[WARNING] SSE connection error: {e}; reconnecting in {backoff:.0f}s"
                    )
                    await asyncio.sleep(backoff)
                    backoff = min(backoff * 2, max_backoff)

    async def _read_sse_stream(self, resp: aiohttp.ClientResponse) -> None:
        """Parse the SSE byte stream and dispatch events."""
        event_name = "message"
        data_lines: list[str] = []

        async for raw_line in resp.content:
            if not self.running:
                break

            line = raw_line.decode("utf-8", errors="replace").rstrip("\r\n")

            if line.startswith("event:"):
                event_name = line[len("event:") :].strip()
            elif line.startswith("data:"):
                data_lines.append(line[len("data:") :].strip())
            elif line == "":
                # Blank line = end of event
                if data_lines:
                    raw_data = "\n".join(data_lines)
                    self._dispatch_event(event_name, raw_data)
                event_name = "message"
                data_lines = []

    def _dispatch_event(self, event_name: str, raw_data: str) -> None:
        """Handle a fully-parsed SSE event."""
        if event_name == "heartbeat":
            return

        if event_name == "connected":
            self.log("[INFO] SSE stream acknowledged by server")
            return

        if event_name == "error":
            self.log(f"[WARNING] SSE server sent error event: {raw_data}")
            return

        if event_name == "user_message":
            try:
                data = json.loads(raw_data)
            except json.JSONDecodeError:
                self.log(
                    f"[WARNING] Could not parse user_message payload: {raw_data[:200]}"
                )
                return

            content = data.get("content", "")
            if not content:
                return

            # If this message was originated from the TUI, the JSONL monitor
            # already tracked it in the deduplicator before forwarding it to the
            # backend. Drop the SSE echo so we don't send the message to Claude
            # a second time.
            if self.message_processor.deduplicator.is_duplicate(content):
                self.log(f"[DEBUG] SSE echo suppressed (TUI origin): {content[:80]!r}")
                # Still clear the pending-input state — the user did reply.
                self.message_processor.pending_input_message_id = None
                self.message_processor.last_message_id = None
                self.requested_input_messages.clear()
                return

            # Message originated from web/app UI — track it and forward to Claude.
            self.message_processor.process_user_message_sync(content, from_web=True)

            # Clear pending input state — user replied; allows idle monitor to re-arm
            self.message_processor.pending_input_message_id = None
            self.message_processor.last_message_id = None
            self.requested_input_messages.clear()

            # Dispatch: control commands are handled in-place; real input is queued
            if not self._handle_control_command(content):
                self.message_queue.append(content)

    # ------------------------------------------------------------------
    # Idle monitor: signals web/app that Claude is waiting for input
    # ------------------------------------------------------------------

    async def idle_monitor_loop(self) -> None:
        """Detect when Claude is idle and call PATCH /messages/{id}/request-input.

        Runs every 500 ms. When ``should_request_input`` returns a message_id,
        calls the PATCH endpoint to mark the message as requiring user input.
        This triggers the ``AWAITING_INPUT`` status transition and push
        notifications on web/app — SSE then delivers the user's reply.
        """
        if not self.vicoa_client_async:
            self.log(
                "[ERROR] Vicoa async client not initialized; idle monitor will not start"
            )
            return

        await self.vicoa_client_async._ensure_session()
        self.log("[INFO] Idle monitor started")

        while self.running:
            await asyncio.sleep(0.5)

            try:
                message_id = self.message_processor.should_request_input(
                    self.session_state.is_claude_idle
                )
                if not message_id:
                    continue

                if message_id in self.requested_input_messages:
                    continue

                self.log(
                    f"[INFO] Claude idle — requesting input for message {message_id}"
                )
                self.requested_input_messages.add(message_id)
                self.message_processor.mark_input_requested(message_id)

                try:
                    await self.vicoa_client_async._make_request(
                        "PATCH", f"/api/v1/messages/{message_id}/request-input"
                    )
                except Exception as patch_err:
                    err_str = str(patch_err)
                    if "already requires user input" in err_str:
                        pass  # benign race — message already marked
                    else:
                        self.log(
                            f"[WARNING] Failed to request input for {message_id}: {patch_err}"
                        )
                        self.requested_input_messages.discard(message_id)
                        self.message_processor.pending_input_message_id = None

            except Exception as e:
                self.log(f"[ERROR] Idle monitor error: {e}")

    # ------------------------------------------------------------------
    # Control command handling (unchanged from previous implementation)
    # ------------------------------------------------------------------

    def request_input_now(self, message_id: str) -> None:
        """No-op: SSE stream delivers messages immediately without explicit requests."""

    def cancel_pending_input_request(self) -> None:
        """No-op: there is no long-poll task to cancel."""

    def _handle_control_command(self, content: str) -> bool:
        """Handle JSON control commands from the web UI.

        Returns True if the content was a control command (consumed), False otherwise.
        """
        try:
            control = self._parse_control_json(content)
            if not control:
                return False

            setting = control.get("setting", "").strip()
            if not setting:
                return False

            # Handle interrupt
            if setting == "interrupt":
                return self._handle_interrupt_action()

            if setting == "ask_user_question":
                return self._handle_ask_user_question_action(
                    str(control.get("value") or "")
                )

            # Persist-only metadata/control messages from UI.
            # They should be stored by backend but never forwarded to Claude
            # or treated as toggle commands.
            if setting == "persist_only":
                return True

            # Handle toggle settings
            value = (control.get("value") or "").strip()
            if not value:
                self._send_feedback_message(f"Missing value for setting '{setting}'")
                return True

            # Delegate to toggle manager
            success = self.toggle_manager.handle_toggle_request(setting, value)

            # Only send feedback on failure
            # Success feedback will come from terminal detection when change is confirmed
            if not success:
                target_slug = self.toggle_manager.normalize_value(setting, value)
                display_value = (
                    self.toggle_manager.humanize_value(setting, target_slug)
                    if target_slug
                    else value
                )
                self._send_feedback_message(
                    f"Failed to set {setting.replace('_', ' ')} to {display_value}"
                )

            return True

        except json.JSONDecodeError:
            return False
        except Exception as e:
            self.log(f"[ERROR] Error handling control command: {e}")
            return False

    def _parse_control_json(self, content: str) -> Optional[dict]:
        """Parse JSON control command from text (can be embedded).

        Supports both formats for backwards compatibility:
        - {"type": "control", "setting": "X", "value": "Y"}
        - {"type": "control", "action": "interrupt"}
        """
        if not content:
            return None

        match = CONTROL_JSON_PATTERN.search(content)
        if not match:
            return None

        json_str = match.group(0)
        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            return None

        if not isinstance(data, dict) or data.get("type") != "control":
            return None

        # Support both "setting" (new format) and "action" (old format)
        setting = data.get("setting") or data.get("action")
        if not setting:
            return None

        value = data.get("value")
        if value is not None:
            return {"setting": str(setting), "value": str(value)}
        return {"setting": str(setting)}

    def _handle_ask_user_question_action(self, value: str) -> bool:
        """Handle AskUserQuestion submit/cancel control commands."""
        command = value.strip()
        if not command:
            self._send_feedback_message("Missing AskUserQuestion command")
            return True

        if command == "cancel":
            try:
                self.pty_manager.write_to_pty(b"\x1b")
            except Exception as e:
                self.log(f"[ERROR] Failed to cancel AskUserQuestion: {e}")
                self._send_feedback_message("Failed to cancel AskUserQuestion")
            return True

        if not command.startswith("submit:"):
            self._send_feedback_message("Invalid AskUserQuestion command")
            return True

        encoded = command[len("submit:") :].strip()
        payload = self._decode_ask_user_question_payload(encoded)
        if not payload:
            self._send_feedback_message("Invalid AskUserQuestion answers payload")
            return True

        answers = payload.get("answers")
        if not isinstance(answers, list):
            self._send_feedback_message("AskUserQuestion payload missing answers")
            return True

        try:
            self.message_processor.suppress_cli_user_echo_until = time.time() + 10.0
            self.log(f"[DEBUG] Submitting AskUserQuestion answers count={len(answers)}")
            self._submit_ask_user_question_answers(answers)
        except Exception as e:
            self.log(f"[ERROR] Failed to submit AskUserQuestion answers: {e}")
            self._send_feedback_message("Failed to submit AskUserQuestion answers")

        return True

    def _decode_ask_user_question_payload(
        self, encoded: str
    ) -> Optional[dict[str, Any]]:
        if not encoded:
            return None
        try:
            padding = "=" * (-len(encoded) % 4)
            raw = base64.urlsafe_b64decode(encoded + padding)
            payload = json.loads(raw.decode("utf-8"))
            if isinstance(payload, dict):
                return payload
        except Exception:
            return None
        return None

    def _submit_ask_user_question_answers(self, answers: list[Any]) -> None:
        """Send key sequence to terminal to answer AskUserQuestion and submit."""
        auto_advanced_from_prev = False
        for index, answer in enumerate(answers):
            if index > 0 and not auto_advanced_from_prev:
                self.log(f"[DEBUG] AskUserQuestion move to next tab index={index}")
                self._write_pty_key(b"\t")
            elif index > 0 and auto_advanced_from_prev:
                self.log(
                    f"[DEBUG] AskUserQuestion next tab already active after text confirm index={index}"
                )

            auto_advanced_from_prev = False

            if isinstance(answer, dict):
                mode = str(answer.get("mode") or "option").strip()
                if mode == "text":
                    option_count_raw = answer.get("option_count")
                    option_count = self._parse_int_value(option_count_raw, default=4)
                    self.log(
                        f"[DEBUG] AskUserQuestion answer[{index}] mode=text option_count={option_count}"
                    )
                    self._answer_question_with_text(
                        str(answer.get("text") or ""),
                        option_count=option_count,
                    )
                    # In AskUserQuestion, Enter on text answer moves to the next tab.
                    auto_advanced_from_prev = True
                else:
                    option_index = answer.get("option_index")
                    question_multi_select = bool(answer.get("question_multi_select"))
                    option_count_raw = answer.get("option_count")
                    option_count = self._parse_int_value(option_count_raw, default=4)
                    parsed_option_index = self._parse_int_value(option_index, default=0)
                    parsed_option_indexes: list[int] = []
                    raw_indexes = answer.get("option_indexes")
                    if isinstance(raw_indexes, list):
                        for raw_idx in raw_indexes:
                            parsed = self._parse_int_value(raw_idx, default=-1)
                            if parsed < 0:
                                continue
                            parsed_option_indexes.append(parsed)
                    if (
                        not question_multi_select
                        and not parsed_option_indexes
                        and parsed_option_index >= 0
                    ):
                        parsed_option_indexes = [parsed_option_index]
                    # de-duplicate while preserving order
                    deduped_indexes: list[int] = []
                    for idx_value in parsed_option_indexes:
                        if idx_value not in deduped_indexes:
                            deduped_indexes.append(idx_value)
                    self.log(
                        f"[DEBUG] AskUserQuestion answer[{index}] mode=option option_index={parsed_option_index} option_indexes={deduped_indexes} multi_select={question_multi_select}"
                    )
                    if question_multi_select:
                        # Select each requested option then submit this question to advance.
                        for option_idx in deduped_indexes:
                            self._answer_question_with_option(option_idx, True)
                        self._submit_multi_select_question()
                        # We explicitly moved to the next tab.
                        auto_advanced_from_prev = True
                        self.log(
                            f"[DEBUG] AskUserQuestion multi-select advanced to next tab index={index}"
                        )
                    else:
                        self._answer_question_with_option(parsed_option_index, False)
                        # Single-select auto-advances after numeric key.
                        auto_advanced_from_prev = True
                        self.log(
                            f"[DEBUG] AskUserQuestion option confirm auto-advanced index={index}"
                        )
            else:
                self._answer_question_with_option(0, False)
                auto_advanced_from_prev = True

        # Move to Submit tab and confirm submission.
        if auto_advanced_from_prev:
            self.log(
                "[DEBUG] AskUserQuestion submit tab already active after final text answer"
            )
        else:
            self.log("[DEBUG] AskUserQuestion move to submit tab")
            self._write_pty_key(b"\t")
        time.sleep(0.12)
        self.log("[DEBUG] AskUserQuestion confirm submit")
        self._write_pty_key(b"\r")

    def _parse_int_value(self, value: object, default: int) -> int:
        """Parse loose JSON-like payload values into ints for terminal actions."""
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            return int(value)
        if isinstance(value, str):
            try:
                return int(value)
            except ValueError:
                return default
        return default

    def _answer_question_with_option(
        self, option_index: int, multi_select: bool
    ) -> None:
        option_number = max(1, min(option_index + 1, 6))
        self._write_pty_key(str(option_number).encode("ascii"))

    def _submit_multi_select_question(self) -> None:
        self._write_pty_key(b"\x1b[C")

    def _answer_question_with_text(self, text: str, option_count: int) -> None:
        option_count = max(0, min(option_count, 20))
        self.log(
            f"[DEBUG] AskUserQuestion text flow: move_down={option_count} text_len={len(text)}"
        )
        for _ in range(option_count):
            self._write_pty_key(b"\x1b[B")
        self.log("[DEBUG] AskUserQuestion text flow: typing on type row")
        time.sleep(0.08)
        if text:
            self.log("[DEBUG] AskUserQuestion text flow: typing text")
            self._write_pty_key(text.encode("utf-8"), delay=0.02)
        self.log("[DEBUG] AskUserQuestion text flow: confirm text")
        self._write_pty_key(b"\r")
        # Give the UI a beat to register and auto-advance.
        time.sleep(0.08)

    def _write_pty_key(self, data: bytes, delay: float = 0.08) -> None:
        self.pty_manager.write_to_pty(data)
        time.sleep(delay)

    def _handle_interrupt_action(self) -> bool:
        """Handle interrupt action from web UI.

        Clears queued messages, sends Escape key to Claude Code,
        and sends confirmation feedback to user.

        Returns: True (command was handled)
        """
        # Clear all queued messages
        if len(self.message_queue) > 0:
            self.message_queue.clear()

        # Always send the escape key - if Claude is idle it won't hurt,
        # if Claude is busy it will interrupt. The user clicked "Stop" so
        # we should respect that regardless of our detection state.
        try:
            self.pty_manager.write_to_pty(b"\x1b")
        except Exception as e:
            self.log(f"[ERROR] Failed to send interrupt signal: {e}")
            self._send_feedback_message("Failed to interrupt Claude")
            return True

        # Cancel any pending input request since we're interrupting
        self.cancel_pending_input_request()

        # Clear the pending input message ID to allow new input requests
        self.message_processor.pending_input_message_id = None

        # Clear last_was_tool_use to allow input requests after interrupt
        self.message_processor.last_was_tool_use = False

        # Send confirmation feedback to web UI (this will set last_message_id and last_message_time)
        self._send_feedback_message("Interrupted · What should Claude do instead?")

        # Important: The feedback message above will get a message_id in response.
        # We need to immediately check for any follow-up user messages that might
        # have been queued while we were processing the interrupt.
        # The response from _send_feedback_message already processes queued messages,
        # so we don't need to do anything extra here.

        return True

    def _send_feedback_message(self, message: str) -> None:
        """Send a status update to Vicoa about local control actions."""
        if not self.vicoa_client_sync or not self.agent_instance_id:
            self.log(
                "[WARNING] Cannot send feedback: vicoa_client_sync or agent_instance_id not initialized"
            )
            return

        try:
            response = self.vicoa_client_sync.send_message(
                content=message,
                agent_type=self.agent_name,
                agent_instance_id=self.agent_instance_id,
                requires_user_input=False,
            )

            if response and hasattr(response, "message_id"):
                self.message_processor.last_message_id = response.message_id
                self.message_processor.last_message_time = time.time()

            # Queued messages delivered via SSE — no need to process inline here
        except Exception as e:
            self.log(f"[ERROR] Failed to send feedback message: {e}")
