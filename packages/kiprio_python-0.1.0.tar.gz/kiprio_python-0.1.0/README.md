# kiprio-python

Official Python SDK for the [Kiprio API](https://kiprio.com) — developer tools available as clean REST endpoints.

```bash
pip install kiprio-python
```

## Quick Start

```python
from kiprio import KiprioClient

client = KiprioClient(api_key="your-api-key")
```

Get a free API key at [kiprio.com](https://kiprio.com).

---

## Examples

### Redact PII from text

```python
result = client.redact("Hi, I'm John and my number is 555-1234")
print(result.redacted)
# "Hi, I'm [NAME] and my number is [PHONE]"
print(result.entities_found)
# [{"type": "PERSON", "text": "John"}, {"type": "PHONE", "text": "555-1234"}]
```

### Convert HTML to Markdown

```python
result = client.html_to_markdown(url="https://example.com/article")
print(result.markdown)
# "# Article Title\n\nArticle content..."

# Or pass raw HTML directly
result = client.html_to_markdown(html="<h1>Hello</h1><p>World</p>")
print(result.markdown)
# "# Hello\n\nWorld"
```

### Extract clean article text

```python
result = client.readability("https://example.com/article")
print(result.title)     # "Article Title"
print(result.content)   # Clean article text, ads/nav removed
print(result.author)    # "Jane Smith"
print(result.word_count)  # 847
```

### Look up WHOIS data

```python
result = client.whois("python.org")
print(result.registrar)    # "PSI-USA, Inc."
print(result.created)      # "1995-03-27"
print(result.expires)      # "2026-03-28"
print(result.nameservers)  # ["ns1.osuosl.org", "ns2.osuosl.org"]
```

### Extract text from a PDF

```python
# From a URL
result = client.pdf_extract(url="https://example.com/document.pdf")
print(result.text)   # Extracted text
print(result.pages)  # 12

# From a local file
with open("document.pdf", "rb") as f:
    result = client.pdf_extract(file=f)
print(result.text)
```

### Parse a cron expression

```python
result = client.cron_parse("0 9 * * 1-5")
print(result.description)  # "At 09:00, Monday through Friday"
print(result.next_runs)    # ["2026-04-28T09:00:00", "2026-04-29T09:00:00", ...]
```

### Infer a JSON Schema

```python
data = [{"id": 1, "name": "Alice", "active": True}]
result = client.schema(data)
print(result.schema)
# {"type": "array", "items": {"type": "object", "properties": {"id": {"type": "integer"}, ...}}}
```

### LLM context window + pricing index

```python
# All models
index = client.llm_index()
print(f"{index.model_count} models indexed")

# Filter to open-source multimodal models
result = client.llm_index(open_source=True, multimodal=True)
for model in result.models:
    print(f"{model['provider']}/{model['model']}: {model['context_window_tokens']:,} tokens")
```

### Generate a QR code

```python
result = client.qr("https://kiprio.com", size=400)
with open("qr.png", "wb") as f:
    f.write(result.image_bytes)
```

---

## Self-Hosted

Enterprise customers can point the SDK at a self-hosted Kiprio instance:

```python
client = KiprioClient(
    api_key="your-key",
    base_url="https://api.your-company.com",
)
```

---

## Error Handling

```python
from kiprio import KiprioClient
from kiprio.client import KiprioError

client = KiprioClient(api_key="your-key")
try:
    result = client.whois("example.com")
except KiprioError as e:
    print(f"API error {e.status_code}: {e.message}")
```

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| `client.redact(text)` | `POST /v1/redact` | Redact PII from text |
| `client.schema(data)` | `POST /v1/schema` | Infer JSON Schema |
| `client.screenshot(url)` | `POST /v1/screenshot` | Screenshot a URL |
| `client.html_to_markdown(html, url)` | `POST /v1/html-to-markdown` | Convert HTML to Markdown |
| `client.readability(url)` | `POST /v1/readability` | Extract article text |
| `client.whois(domain)` | `GET /v1/whois/{domain}` | WHOIS lookup |
| `client.pdf_extract(file, url)` | `POST /v1/pdf-extract` | Extract PDF text |
| `client.cron_parse(expr)` | `POST /v1/cron-parse` | Parse cron expression |
| `client.llm_index()` | `GET /v1/llm-index` | LLM pricing + context index |
| `client.qr(text)` | `GET /v1/qr` | Generate QR code |

Full API docs at [kiprio.com/docs](https://kiprio.com/docs).

---

## License

MIT
