"""KiprioClient — typed Python wrapper for the Kiprio API."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, BinaryIO

import urllib.request
import urllib.error
import urllib.parse
import json as _json

DEFAULT_BASE_URL = "https://kiprio.com"
DEFAULT_TIMEOUT = 30
MAX_RETRIES = 3
RETRY_STATUSES = {429, 500, 502, 503, 504}


# ---------------------------------------------------------------------------
# Response dataclasses
# ---------------------------------------------------------------------------

@dataclass
class RedactResult:
    redacted: str
    original_length: int
    redacted_length: int
    entities_found: list[dict] = field(default_factory=list)
    raw: dict = field(default_factory=dict)


@dataclass
class SchemaResult:
    schema: dict
    raw: dict = field(default_factory=dict)


@dataclass
class ScreenshotResult:
    url: str
    image_bytes: bytes
    content_type: str = "image/png"
    raw: dict = field(default_factory=dict)


@dataclass
class HtmlToMarkdownResult:
    markdown: str
    title: str = ""
    length: int = 0
    raw: dict = field(default_factory=dict)


@dataclass
class ReadabilityResult:
    title: str
    content: str
    author: str = ""
    published: str = ""
    word_count: int = 0
    raw: dict = field(default_factory=dict)


@dataclass
class WhoisResult:
    domain: str
    registrar: str = ""
    created: str = ""
    expires: str = ""
    updated: str = ""
    nameservers: list[str] = field(default_factory=list)
    status: list[str] = field(default_factory=list)
    raw: dict = field(default_factory=dict)


@dataclass
class PdfExtractResult:
    text: str
    pages: int = 0
    title: str = ""
    author: str = ""
    raw: dict = field(default_factory=dict)


@dataclass
class CronParseResult:
    expression: str
    description: str
    next_runs: list[str] = field(default_factory=list)
    is_valid: bool = True
    raw: dict = field(default_factory=dict)


@dataclass
class LlmIndexResult:
    models: list[dict]
    model_count: int
    generated_at: str = ""
    raw: dict = field(default_factory=dict)


@dataclass
class QrResult:
    image_bytes: bytes
    content_type: str = "image/png"
    raw: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class KiprioClient:
    """Official Python SDK for the Kiprio API.

    Args:
        api_key: Your Kiprio API key (get one at kiprio.com).
        base_url: Override the default API base URL (for self-hosted deployments).
        timeout: Request timeout in seconds (default 30).
        max_retries: Number of retries on transient errors (default 3).
    """

    def __init__(
        self,
        api_key: str = "",
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _headers(self) -> dict[str, str]:
        h: dict[str, str] = {"Content-Type": "application/json"}
        if self.api_key:
            h["X-API-Key"] = self.api_key
        return h

    def _request(
        self,
        method: str,
        path: str,
        data: dict | None = None,
        raw_body: bytes | None = None,
        content_type: str | None = None,
        params: dict | None = None,
    ) -> Any:
        url = self.base_url + path
        if params:
            url += "?" + urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})

        headers = self._headers()
        if content_type:
            headers["Content-Type"] = content_type

        body: bytes | None = None
        if raw_body is not None:
            body = raw_body
        elif data is not None:
            body = _json.dumps(data).encode()

        last_exc: Exception | None = None
        for attempt in range(self.max_retries):
            try:
                req = urllib.request.Request(url, data=body, headers=headers, method=method)
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    ct = resp.headers.get("Content-Type", "")
                    raw = resp.read()
                    if "json" in ct:
                        return _json.loads(raw)
                    return raw
            except urllib.error.HTTPError as exc:
                if exc.code in RETRY_STATUSES and attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)
                    last_exc = exc
                    continue
                body_text = ""
                try:
                    body_text = exc.read().decode(errors="replace")
                except Exception:
                    pass
                raise KiprioError(exc.code, body_text) from exc
            except Exception as exc:
                if attempt < self.max_retries - 1:
                    time.sleep(2 ** attempt)
                    last_exc = exc
                    continue
                raise
        raise last_exc  # type: ignore[misc]

    # ------------------------------------------------------------------
    # Endpoints
    # ------------------------------------------------------------------

    def redact(self, text: str, entities: list[str] | None = None) -> RedactResult:
        """Redact PII from text.

        Args:
            text: The text to redact.
            entities: Optional list of entity types to redact (e.g. ["phone", "email"]).

        Returns:
            RedactResult with redacted text and entity details.
        """
        payload: dict[str, Any] = {"text": text}
        if entities:
            payload["entities"] = entities
        r = self._request("POST", "/v1/redact", data=payload)
        return RedactResult(
            redacted=r.get("redacted", ""),
            original_length=r.get("original_length", len(text)),
            redacted_length=r.get("redacted_length", 0),
            entities_found=r.get("entities_found", []),
            raw=r,
        )

    def schema(self, data: Any, format: str = "json-schema") -> SchemaResult:
        """Infer a JSON Schema from arbitrary data.

        Args:
            data: Any JSON-serialisable value to infer schema from.
            format: Output format — "json-schema" (default) or "typescript".

        Returns:
            SchemaResult with the inferred schema.
        """
        r = self._request("POST", "/v1/schema", data={"data": data, "format": format})
        return SchemaResult(schema=r.get("schema", r), raw=r)

    def screenshot(self, url: str, width: int = 1280, height: int = 800) -> ScreenshotResult:
        """Take a screenshot of a URL.

        Args:
            url: The URL to screenshot.
            width: Viewport width in pixels (default 1280).
            height: Viewport height in pixels (default 800).

        Returns:
            ScreenshotResult with PNG image bytes.
        """
        r = self._request(
            "POST", "/v1/screenshot",
            data={"url": url, "width": width, "height": height},
        )
        if isinstance(r, bytes):
            return ScreenshotResult(url=url, image_bytes=r, content_type="image/png")
        return ScreenshotResult(
            url=url,
            image_bytes=r.get("image", b""),
            content_type="image/png",
            raw=r if isinstance(r, dict) else {},
        )

    def html_to_markdown(self, html: str | None = None, url: str | None = None) -> HtmlToMarkdownResult:
        """Convert HTML to clean Markdown.

        Args:
            html: Raw HTML string to convert.
            url: URL to fetch and convert (alternative to html).

        Returns:
            HtmlToMarkdownResult with Markdown text.
        """
        if not html and not url:
            raise ValueError("Provide either html or url")
        payload: dict[str, Any] = {}
        if html:
            payload["html"] = html
        if url:
            payload["url"] = url
        r = self._request("POST", "/v1/html-to-markdown", data=payload)
        return HtmlToMarkdownResult(
            markdown=r.get("markdown", r.get("result", "")),
            title=r.get("title", ""),
            length=r.get("length", 0),
            raw=r if isinstance(r, dict) else {},
        )

    def readability(self, url: str) -> ReadabilityResult:
        """Extract clean article text from a URL.

        Args:
            url: URL of the article to extract.

        Returns:
            ReadabilityResult with title, content, and metadata.
        """
        r = self._request("POST", "/v1/readability", data={"url": url})
        return ReadabilityResult(
            title=r.get("title", ""),
            content=r.get("content", r.get("text", "")),
            author=r.get("author", ""),
            published=r.get("published", ""),
            word_count=r.get("word_count", 0),
            raw=r if isinstance(r, dict) else {},
        )

    def whois(self, domain: str) -> WhoisResult:
        """Look up WHOIS information for a domain.

        Args:
            domain: Domain name to look up (e.g. "example.com").

        Returns:
            WhoisResult with registrar, dates, and nameservers.
        """
        r = self._request("GET", f"/v1/whois/{domain}")
        return WhoisResult(
            domain=domain,
            registrar=r.get("registrar", ""),
            created=r.get("creation_date", r.get("created", "")),
            expires=r.get("expiration_date", r.get("expires", "")),
            updated=r.get("updated_date", r.get("updated", "")),
            nameservers=r.get("name_servers", r.get("nameservers", [])),
            status=r.get("status", []),
            raw=r if isinstance(r, dict) else {},
        )

    def pdf_extract(self, file: BinaryIO | None = None, url: str | None = None) -> PdfExtractResult:
        """Extract text from a PDF.

        Args:
            file: Open file-like object of the PDF.
            url: URL of a PDF to download and extract.

        Returns:
            PdfExtractResult with extracted text and metadata.
        """
        if file is not None:
            import email.mime.multipart as _mp
            import email.mime.base as _mb
            import email.encoders as _enc
            import io
            content = file.read() if hasattr(file, "read") else file
            boundary = b"kiprioboundary"
            body = (
                b"--" + boundary + b"\r\n"
                b'Content-Disposition: form-data; name="file"; filename="upload.pdf"\r\n'
                b"Content-Type: application/pdf\r\n\r\n" + content + b"\r\n"
                b"--" + boundary + b"--\r\n"
            )
            ct = f"multipart/form-data; boundary={boundary.decode()}"
            r = self._request("POST", "/v1/pdf-extract", raw_body=body, content_type=ct)
        elif url is not None:
            r = self._request("POST", "/v1/pdf-extract/url", data={"url": url})
        else:
            raise ValueError("Provide either file or url")
        if isinstance(r, dict):
            return PdfExtractResult(
                text=r.get("text", ""),
                pages=r.get("pages", 0),
                title=r.get("title", ""),
                author=r.get("author", ""),
                raw=r,
            )
        return PdfExtractResult(text=str(r), raw={})

    def cron_parse(self, expression: str, count: int = 5) -> CronParseResult:
        """Parse and describe a cron expression.

        Args:
            expression: Cron expression (e.g. "0 9 * * 1-5").
            count: Number of future run times to return (default 5).

        Returns:
            CronParseResult with human-readable description and next runs.
        """
        r = self._request("POST", "/v1/cron-parse", data={"expression": expression, "count": count})
        return CronParseResult(
            expression=expression,
            description=r.get("description", r.get("human", "")),
            next_runs=r.get("next_runs", r.get("next", [])),
            is_valid=r.get("valid", r.get("is_valid", True)),
            raw=r if isinstance(r, dict) else {},
        )

    def llm_index(
        self,
        provider: str | None = None,
        open_source: bool | None = None,
        multimodal: bool | None = None,
        min_context_k: int | None = None,
    ) -> LlmIndexResult:
        """Get the LLM context window and pricing index.

        Args:
            provider: Filter by provider (e.g. "openai", "anthropic").
            open_source: Filter to open-source models only.
            multimodal: Filter to multimodal models only.
            min_context_k: Minimum context window in thousands of tokens.

        Returns:
            LlmIndexResult with list of models and metadata.
        """
        params: dict[str, Any] = {}
        if provider:
            params["provider"] = provider
        if open_source is not None:
            params["open_source"] = str(open_source).lower()
        if multimodal is not None:
            params["multimodal"] = str(multimodal).lower()
        if min_context_k is not None:
            params["min_context_k"] = min_context_k
        r = self._request("GET", "/v1/llm-index", params=params)
        return LlmIndexResult(
            models=r.get("models", []),
            model_count=r.get("model_count", 0),
            generated_at=r.get("generated_at", ""),
            raw=r if isinstance(r, dict) else {},
        )

    def qr(self, text: str, size: int = 300) -> QrResult:
        """Generate a QR code.

        Args:
            text: Text or URL to encode.
            size: Image size in pixels (default 300).

        Returns:
            QrResult with PNG image bytes.
        """
        r = self._request("GET", "/v1/qr", params={"text": text, "size": size})
        if isinstance(r, bytes):
            return QrResult(image_bytes=r, content_type="image/png")
        return QrResult(image_bytes=b"", raw=r if isinstance(r, dict) else {})


class KiprioError(Exception):
    """Raised when the Kiprio API returns an error response."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        self.message = message
        super().__init__(f"HTTP {status_code}: {message}")
