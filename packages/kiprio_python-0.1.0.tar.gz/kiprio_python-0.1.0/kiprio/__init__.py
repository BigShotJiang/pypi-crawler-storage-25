"""kiprio-python — Official Python SDK for the Kiprio API.

Usage:
    from kiprio import KiprioClient
    client = KiprioClient(api_key="your-key")
    result = client.redact("Call me at 555-1234")
"""
from .client import KiprioClient

__version__ = "0.1.0"
__all__ = ["KiprioClient"]
