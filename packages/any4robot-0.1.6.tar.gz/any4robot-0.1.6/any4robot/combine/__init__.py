"""Dataset combination utilities."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, Optional

from any4robot.combine.discovery import discover_lerobot_datasets
from any4robot.combine.overview import build_lerobot_overview
from any4robot.combine.task_edit import (
    edit_task_language,
    get_task_language_edit_inventory,
    preview_task_language_edit,
)
from any4robot.combine.task_subset import (
    default_task_subset_output_path,
    extract_lerobot_tasks_subset,
    get_lerobot_task_inventory,
)
from any4robot.lerobot_editor.operations_v21 import DatasetOperationsV21


def merge_lerobot_datasets(
    source_datasets: Iterable[str | Path],
    output_path: str | Path,
    task_mapping: Optional[Dict[str, str]] = None,
    dry_run: bool = False,
) -> bool:
    """
    Merge multiple LeRobot datasets into a single dataset.

    This delegates to the LERO DatasetOperations merge implementation.
    """
    source_paths = [Path(p) for p in source_datasets]
    output = Path(output_path)

    if not source_paths:
        raise ValueError("source_datasets must contain at least one dataset path")

    # Use the first dataset path to bootstrap operations for merging.
    ops = DatasetOperationsV21(source_paths[0])
    return ops.merge_datasets(source_paths, output, task_mapping=task_mapping, dry_run=dry_run)


def merge_lerobot_datasets_from_folder(
    source_root: str | Path,
    output_path: str | Path,
    task_mapping: Optional[Dict[str, str]] = None,
    dry_run: bool = False,
) -> bool:
    """
    Discover and merge all LeRobot datasets under a folder.
    """
    source_paths = discover_lerobot_datasets(source_root)
    output = Path(output_path)
    output_resolved = output.resolve()

    source_paths = [path for path in source_paths if path.resolve() != output_resolved]
    if not source_paths:
        raise ValueError(
            f"No LeRobot datasets found under source_root: {source_root}"
        )

    return merge_lerobot_datasets(
        source_datasets=source_paths,
        output_path=output,
        task_mapping=task_mapping,
        dry_run=dry_run,
    )


__all__ = [
    "build_lerobot_overview",
    "discover_lerobot_datasets",
    "edit_task_language",
    "extract_lerobot_tasks_subset",
    "get_task_language_edit_inventory",
    "get_lerobot_task_inventory",
    "merge_lerobot_datasets",
    "merge_lerobot_datasets_from_folder",
    "preview_task_language_edit",
    "default_task_subset_output_path",
]
