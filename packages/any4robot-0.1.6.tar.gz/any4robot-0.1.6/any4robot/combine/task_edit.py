"""Task language editing helpers for LeRobot v2.1 metadata."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

from any4robot.combine.discovery import discover_lerobot_datasets
from any4robot.lerobot_editor.constants import EPISODES_FILE, META_DIR, TASKS_FILE


def _load_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def _save_jsonl(rows: List[Dict[str, Any]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def _episode_mentions_task(episode: Dict[str, Any], old_task: str) -> bool:
    if episode.get("task") == old_task:
        return True
    tasks = episode.get("tasks")
    return isinstance(tasks, list) and old_task in tasks


def _episode_task_names(episode: Dict[str, Any], task_by_index: Dict[int, str]) -> List[str]:
    names = []
    task = episode.get("task")
    if isinstance(task, str) and task:
        names.append(task)
    tasks = episode.get("tasks")
    if isinstance(tasks, list):
        names.extend(task for task in tasks if isinstance(task, str) and task)
    task_index = episode.get("task_index")
    if isinstance(task_index, int) and task_index in task_by_index:
        names.append(task_by_index[task_index])
    return list(dict.fromkeys(names))


def _replace_episode_task(episode: Dict[str, Any], old_task: str, new_task: str) -> bool:
    changed = False
    if episode.get("task") == old_task:
        episode["task"] = new_task
        changed = True

    tasks = episode.get("tasks")
    if isinstance(tasks, list):
        replaced = [new_task if task == old_task else task for task in tasks]
        if replaced != tasks:
            episode["tasks"] = replaced
            changed = True

    return changed


def get_task_language_edit_inventory(source_root: str | Path) -> Dict[str, Dict[str, Any]]:
    """Return task language inventory from tasks.jsonl and episodes.jsonl."""
    inventory: Dict[str, Dict[str, Any]] = {}
    for dataset_path in discover_lerobot_datasets(source_root):
        tasks = _load_jsonl(dataset_path / META_DIR / TASKS_FILE)
        episodes = _load_jsonl(dataset_path / META_DIR / EPISODES_FILE)
        task_by_index = {
            int(task["task_index"]): str(task.get("task", ""))
            for task in tasks
            if "task_index" in task
        }

        for task in tasks:
            task_name = task.get("task")
            if not isinstance(task_name, str):
                continue
            entry = inventory.setdefault(
                task_name,
                {"task": task_name, "task_rows": 0, "episodes": 0, "datasets": set()},
            )
            entry["task_rows"] += 1
            entry["datasets"].add(str(dataset_path))

        for episode in episodes:
            for task_name in _episode_task_names(episode, task_by_index):
                if task_name in inventory:
                    entry = inventory[task_name]
                    entry["episodes"] += 1

    for entry in inventory.values():
        entry["datasets"] = sorted(entry["datasets"])
    return inventory


def preview_task_language_edit(source_root: str | Path, old_task: str) -> Dict[str, Any]:
    """Build a dry preview of which files/rows would change for a task language edit."""
    datasets = []
    total_task_rows = 0
    total_episode_rows = 0

    for dataset_path in discover_lerobot_datasets(source_root):
        tasks = _load_jsonl(dataset_path / META_DIR / TASKS_FILE)
        episodes = _load_jsonl(dataset_path / META_DIR / EPISODES_FILE)
        task_rows = sum(1 for task in tasks if task.get("task") == old_task)
        episode_rows = sum(1 for episode in episodes if _episode_mentions_task(episode, old_task))
        if task_rows or episode_rows:
            datasets.append(
                {
                    "dataset_path": str(dataset_path),
                    "task_rows": task_rows,
                    "episode_rows": episode_rows,
                }
            )
            total_task_rows += task_rows
            total_episode_rows += episode_rows

    return {
        "old_task": old_task,
        "datasets": datasets,
        "total_datasets": len(datasets),
        "total_task_rows": total_task_rows,
        "total_episode_rows": total_episode_rows,
    }


def edit_task_language(
    source_root: str | Path,
    old_task: str,
    new_task: str,
    inplace: bool = False,
) -> Dict[str, Any]:
    """
    Replace task text in tasks.jsonl and episode task text.

    If ``inplace`` is False, writes ``tasks_new.jsonl`` and ``episodes_new.jsonl``
    beside the original metadata files. Parquet task indexes are intentionally
    untouched because this operation changes language only, not task ids.
    """
    if not old_task:
        raise ValueError("old_task must not be empty")
    if not new_task:
        raise ValueError("new_task must not be empty")

    changed_datasets = []
    total_task_rows = 0
    total_episode_rows = 0

    for dataset_path in discover_lerobot_datasets(source_root):
        meta_path = dataset_path / META_DIR
        tasks_path = meta_path / TASKS_FILE
        episodes_path = meta_path / EPISODES_FILE
        tasks = _load_jsonl(tasks_path)
        episodes = _load_jsonl(episodes_path)

        task_rows = 0
        for task in tasks:
            if task.get("task") == old_task:
                task["task"] = new_task
                task_rows += 1

        episode_rows = 0
        for episode in episodes:
            if _replace_episode_task(episode, old_task, new_task):
                episode_rows += 1

        if not task_rows and not episode_rows:
            continue

        out_tasks = tasks_path if inplace else meta_path / "tasks_new.jsonl"
        out_episodes = episodes_path if inplace else meta_path / "episodes_new.jsonl"
        _save_jsonl(tasks, out_tasks)
        _save_jsonl(episodes, out_episodes)

        changed_datasets.append(
            {
                "dataset_path": str(dataset_path),
                "task_rows": task_rows,
                "episode_rows": episode_rows,
                "tasks_path": str(out_tasks),
                "episodes_path": str(out_episodes),
            }
        )
        total_task_rows += task_rows
        total_episode_rows += episode_rows

    return {
        "old_task": old_task,
        "new_task": new_task,
        "inplace": inplace,
        "datasets": changed_datasets,
        "total_datasets": len(changed_datasets),
        "total_task_rows": total_task_rows,
        "total_episode_rows": total_episode_rows,
    }
