"""Task-based LeRobot v2.1 subset extraction."""

from __future__ import annotations

import json
import re
import shutil
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import pandas as pd

from any4robot.combine.discovery import discover_lerobot_datasets
from any4robot.lerobot_editor.constants import EPISODES_FILE, INFO_FILE, META_DIR, TASKS_FILE
from any4robot.lerobot_editor.operations_v21 import DatasetOperationsV21


def _load_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def _save_jsonl(rows: List[Dict[str, Any]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def _episode_task_names(
    episode: Dict[str, Any],
    task_by_index: Dict[int, str],
) -> List[str]:
    tasks = episode.get("tasks")
    if isinstance(tasks, list):
        names = [task for task in tasks if isinstance(task, str)]
        if names:
            return names

    task = episode.get("task")
    if isinstance(task, str) and task:
        return [task]

    task_index = episode.get("task_index")
    if isinstance(task_index, int) and task_index in task_by_index:
        return [task_by_index[task_index]]

    return []


def _stats_row_episode_index(row: Dict[str, Any]) -> Optional[int]:
    """
    Resolve episode index from meta/episodes_stats.jsonl.

    LeRobot normally stores a scalar ``episode_index``. Some pipelines instead
    store the same per-feature stats shape (dict with min/max/mean/std lists),
    in which case the episode id is typically in ``mean[0]`` (and matches min/max).
    """
    raw = row.get("episode_index")
    if raw is None:
        return None
    if isinstance(raw, bool):
        return int(raw)
    if isinstance(raw, int):
        return raw
    if isinstance(raw, float):
        return int(raw)
    if isinstance(raw, str):
        try:
            return int(float(raw.strip()))
        except (ValueError, TypeError):
            return None
    if isinstance(raw, dict):
        for key in ("mean", "min", "max"):
            block = raw.get(key)
            if isinstance(block, list) and block and isinstance(block[0], (int, float)):
                return int(block[0])
        return None
    return None


def _safe_output_suffix(task_names: Iterable[str], max_length: int = 80) -> str:
    pieces = []
    for task_name in task_names:
        piece = re.sub(r"[^A-Za-z0-9._-]+", "_", task_name.strip()).strip("._-")
        if piece:
            pieces.append(piece)
    suffix_body = "_with_".join(pieces) or "selected_tasks"
    if len(suffix_body) > max_length:
        suffix_body = suffix_body[:max_length].rstrip("._-")
    return f"_subset_{suffix_body}"


def default_task_subset_output_path(source_root: str | Path, task_names: Iterable[str]) -> Path:
    """Build the default output path for a task subset extraction."""
    root = Path(source_root)
    suffix = _safe_output_suffix(task_names)
    return root.with_name(f"{root.name}{suffix}")


def get_lerobot_task_inventory(source_root: str | Path) -> Dict[str, Dict[str, Any]]:
    """Return task counts discovered in a LeRobot dataset or folder of datasets."""
    inventory: Dict[str, Dict[str, Any]] = {}
    for dataset_path in discover_lerobot_datasets(source_root):
        tasks = _load_jsonl(dataset_path / META_DIR / TASKS_FILE)
        task_by_index = {
            int(task["task_index"]): str(task.get("task", ""))
            for task in tasks
            if "task_index" in task
        }
        episodes = _load_jsonl(dataset_path / META_DIR / EPISODES_FILE)
        for episode in episodes:
            for task_name in _episode_task_names(episode, task_by_index):
                entry = inventory.setdefault(
                    task_name,
                    {"task": task_name, "episodes": 0, "datasets": set()},
                )
                entry["episodes"] += 1
                entry["datasets"].add(str(dataset_path))

    for entry in inventory.values():
        entry["datasets"] = sorted(entry["datasets"])
    return inventory


def extract_lerobot_tasks_subset(
    source_root: str | Path,
    task_names: Iterable[str],
    output_path: str | Path | None = None,
    dry_run: bool = False,
) -> Dict[str, Any]:
    """
    Extract episodes whose task matches selected task names into a new LeRobot v2.1 dataset.

    `source_root` may be a single dataset root or a folder containing multiple dataset roots.
    Episodes are renumbered contiguously, parquet frame indexes are shifted, task indexes are
    remapped, and videos are copied into the destination v2.1 chunk layout.
    """
    source_paths = discover_lerobot_datasets(source_root)
    selected_tasks = [str(task) for task in task_names if str(task).strip()]
    selected_set = set(selected_tasks)
    if not selected_set:
        raise ValueError("task_names must contain at least one task")

    output = Path(output_path) if output_path else default_task_subset_output_path(source_root, selected_tasks)
    if output.exists() and not dry_run:
        raise FileExistsError(f"Output already exists: {output}")

    if not source_paths:
        raise ValueError(f"No LeRobot datasets found under source_root: {source_root}")

    ops = DatasetOperationsV21(source_paths[0])
    selected_episode_rows: List[Dict[str, Any]] = []
    selected_stats_rows: List[Dict[str, Any]] = []
    episode_copy_plan: List[Dict[str, Any]] = []
    task_to_new_index: Dict[str, int] = {}
    new_tasks: List[Dict[str, Any]] = []
    total_frames = 0
    cumulative_frame_index = 0

    with (source_paths[0] / META_DIR / INFO_FILE).open("r", encoding="utf-8") as handle:
        base_info = json.load(handle)
    chunks_size = int(base_info.get("chunks_size", 1000))

    for dataset_path in source_paths:
        tasks = _load_jsonl(dataset_path / META_DIR / TASKS_FILE)
        task_by_index = {
            int(task["task_index"]): str(task.get("task", ""))
            for task in tasks
            if "task_index" in task
        }
        episodes = _load_jsonl(dataset_path / META_DIR / EPISODES_FILE)
        stats_rows = _load_jsonl(dataset_path / META_DIR / "episodes_stats.jsonl")
        stats_by_episode: Dict[int, Dict[str, Any]] = {}
        for row in stats_rows:
            ep_idx = _stats_row_episode_index(row)
            if ep_idx is not None:
                stats_by_episode[ep_idx] = row

        for episode in episodes:
            old_index = int(episode["episode_index"])
            episode_tasks = _episode_task_names(episode, task_by_index)
            matched_tasks = [task for task in episode_tasks if task in selected_set]
            if not matched_tasks:
                continue

            task_name = matched_tasks[0]
            if task_name not in task_to_new_index:
                task_to_new_index[task_name] = len(new_tasks)
                new_tasks.append({"task_index": task_to_new_index[task_name], "task": task_name})

            new_index = len(selected_episode_rows)
            new_task_index = task_to_new_index[task_name]
            new_episode = dict(episode)
            new_episode["episode_index"] = new_index
            new_episode["task"] = task_name
            new_episode["task_index"] = new_task_index
            if isinstance(new_episode.get("tasks"), list):
                new_episode["tasks"] = [task_name]
            selected_episode_rows.append(new_episode)

            if old_index in stats_by_episode:
                new_stat = dict(stats_by_episode[old_index])
                new_stat["episode_index"] = new_index
                selected_stats_rows.append(new_stat)

            length = int(episode.get("length", 0) or 0)
            episode_copy_plan.append(
                {
                    "dataset_path": dataset_path,
                    "old_index": old_index,
                    "new_index": new_index,
                    "new_task_index": new_task_index,
                    "first_frame_index": cumulative_frame_index,
                }
            )
            cumulative_frame_index += length
            total_frames += length

    if not selected_episode_rows:
        raise ValueError(f"No episodes matched selected tasks: {sorted(selected_set)}")

    if dry_run:
        return {
            "output_path": str(output),
            "source_datasets": [str(path) for path in source_paths],
            "selected_tasks": selected_tasks,
            "total_episodes": len(selected_episode_rows),
            "total_frames": total_frames,
            "dry_run": True,
        }

    (output / META_DIR).mkdir(parents=True, exist_ok=True)
    _save_jsonl(selected_episode_rows, output / META_DIR / EPISODES_FILE)
    _save_jsonl(selected_stats_rows, output / META_DIR / "episodes_stats.jsonl")
    _save_jsonl(new_tasks, output / META_DIR / TASKS_FILE)

    video_keys = [
        feature_name
        for feature_name, feature_info in base_info.get("features", {}).items()
        if isinstance(feature_info, dict) and feature_info.get("dtype") == "video"
    ]
    video_path_template = base_info.get("video_path", "videos/{video_key}/episode_{episode_index:06d}.mp4")
    copied_videos = 0

    for plan in episode_copy_plan:
        source_dataset = plan["dataset_path"]
        old_index = plan["old_index"]
        new_index = plan["new_index"]

        source_parquet = ops._find_episode_parquet(source_dataset, old_index)
        df = pd.read_parquet(source_parquet)
        if "episode_index" in df.columns:
            df["episode_index"] = new_index
        if "index" in df.columns:
            first_frame_index = int(plan["first_frame_index"])
            df["index"] = [first_frame_index + i for i in range(len(df))]
        if "task_index" in df.columns:
            df["task_index"] = int(plan["new_task_index"])

        chunk_index = new_index // chunks_size
        dest_parquet = output / "data" / f"chunk-{chunk_index:03d}" / f"episode_{new_index:06d}.parquet"
        dest_parquet.parent.mkdir(parents=True, exist_ok=True)
        df.to_parquet(dest_parquet, index=False)

        for video_key in video_keys:
            source_video = ops._find_video_path(
                source_dataset,
                video_path_template,
                chunks_size,
                video_key,
                old_index,
            )
            dest_video = output / video_path_template.format(
                episode_chunk=chunk_index,
                video_key=video_key,
                episode_index=new_index,
            )
            dest_video.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source_video, dest_video)
            copied_videos += 1

    stats_for_merge = []
    for row in selected_stats_rows:
        stats_for_merge.append({key: value for key, value in row.items() if key != "episode_index"})
    if stats_for_merge:
        merged_stats = ops._merge_stats(stats_for_merge)
        with (output / META_DIR / "stats.json").open("w", encoding="utf-8") as handle:
            json.dump(merged_stats, handle, indent=2, ensure_ascii=False)

    info = dict(base_info)
    info["total_episodes"] = len(selected_episode_rows)
    info["total_frames"] = total_frames
    info["total_tasks"] = len(new_tasks)
    info["total_chunks"] = (len(selected_episode_rows) + chunks_size - 1) // chunks_size
    info["total_videos"] = copied_videos
    info["splits"] = {"train": f"0:{len(selected_episode_rows)}"}
    with (output / META_DIR / INFO_FILE).open("w", encoding="utf-8") as handle:
        json.dump(info, handle, indent=2, ensure_ascii=False)

    return {
        "output_path": str(output),
        "source_datasets": [str(path) for path in source_paths],
        "selected_tasks": selected_tasks,
        "total_episodes": len(selected_episode_rows),
        "total_frames": total_frames,
        "total_videos": copied_videos,
        "dry_run": False,
    }
