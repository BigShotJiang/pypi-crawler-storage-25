"""LeRobot dataset discovery helpers."""

from __future__ import annotations

from pathlib import Path
from typing import List

from any4robot.lerobot_editor.constants import EPISODES_FILE, INFO_FILE, META_DIR, TASKS_FILE


def is_lerobot_dataset(path: Path) -> bool:
    """Return True if path looks like a LeRobot dataset root."""
    meta_dir = path / META_DIR
    return (
        meta_dir.is_dir()
        and (meta_dir / INFO_FILE).exists()
        and (meta_dir / EPISODES_FILE).exists()
        and (meta_dir / TASKS_FILE).exists()
    )


def discover_lerobot_datasets(source_root: str | Path) -> List[Path]:
    """
    Discover LeRobot dataset roots under a folder.

    If `source_root` is itself a dataset, it returns `[source_root]`.
    Otherwise, it returns direct child folders that look like datasets.
    """
    root = Path(source_root)
    if not root.exists():
        raise FileNotFoundError(f"source_root does not exist: {root}")
    if not root.is_dir():
        raise NotADirectoryError(f"source_root is not a directory: {root}")

    if is_lerobot_dataset(root):
        return [root]

    datasets = [path for path in root.iterdir() if path.is_dir() and is_lerobot_dataset(path)]
    return sorted(datasets)
