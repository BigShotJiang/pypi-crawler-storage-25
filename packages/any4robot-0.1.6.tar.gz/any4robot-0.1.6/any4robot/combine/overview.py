"""Overview statistics for LeRobot v2.1 datasets."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from statistics import mean, median
from typing import Any, Callable, Dict, List, Optional

from any4robot.combine.discovery import discover_lerobot_datasets
from any4robot.lerobot_editor.constants import EPISODES_FILE, INFO_FILE, META_DIR, TASKS_FILE


def _load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _load_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def _episode_task(episode: Dict[str, Any], task_by_index: Dict[int, str]) -> str:
    task = episode.get("task")
    if isinstance(task, str) and task:
        return task
    tasks = episode.get("tasks")
    if isinstance(tasks, list) and tasks and isinstance(tasks[0], str):
        return tasks[0]
    task_index = episode.get("task_index")
    if isinstance(task_index, int) and task_index in task_by_index:
        return task_by_index[task_index]
    return "UNKNOWN"


def _length_stats(lengths: List[int]) -> Dict[str, Any]:
    if not lengths:
        return {"min": 0, "max": 0, "mean": 0.0, "median": 0.0}
    return {
        "min": min(lengths),
        "max": max(lengths),
        "mean": mean(lengths),
        "median": median(lengths),
    }


def _length_histogram(lengths: List[int], buckets: int = 10) -> Dict[str, int]:
    if not lengths:
        return {}

    min_len = min(lengths)
    max_len = max(lengths)
    if min_len == max_len:
        return {str(min_len): len(lengths)}

    bucket_count = max(1, min(buckets, len(set(lengths))))
    span = max_len - min_len + 1
    bucket_size = max(1, (span + bucket_count - 1) // bucket_count)
    histogram: Dict[str, int] = {}

    for i in range(bucket_count):
        start = min_len + i * bucket_size
        end = min(max_len, start + bucket_size - 1)
        histogram[f"{start}-{end}"] = 0

    for length in lengths:
        index = min((length - min_len) // bucket_size, bucket_count - 1)
        start = min_len + index * bucket_size
        end = min(max_len, start + bucket_size - 1)
        histogram[f"{start}-{end}"] += 1

    return histogram


def _path_size(path: Path) -> int:
    if not path.exists():
        return 0
    if path.is_file():
        return path.stat().st_size
    total = 0
    for item in path.rglob("*"):
        if item.is_file():
            total += item.stat().st_size
    return total


def build_lerobot_overview(
    source_root: str | Path,
    progress_callback: Optional[Callable[[int, int, Path], None]] = None,
) -> Dict[str, Any]:
    """Build a rich metadata overview for one dataset or a root containing datasets."""
    dataset_paths = discover_lerobot_datasets(source_root)
    datasets = []
    task_counts: Counter[str] = Counter()
    declared_tasks = set()
    robot_types: Counter[str] = Counter()
    fps_values: Counter[str] = Counter()
    video_features: Counter[str] = Counter()
    all_lengths: List[int] = []
    total_frames = 0
    total_episodes = 0
    total_videos = 0
    total_meta_size = 0
    total_data_size = 0
    total_video_size = 0
    total_parquet_files = 0
    total_video_files = 0
    dataset_errors = []

    total_dataset_paths = len(dataset_paths)
    for dataset_number, dataset_path in enumerate(dataset_paths, start=1):
        if progress_callback:
            progress_callback(dataset_number, total_dataset_paths, dataset_path)

        try:
            info = _load_json(dataset_path / META_DIR / INFO_FILE)
            tasks = _load_jsonl(dataset_path / META_DIR / TASKS_FILE)
            episodes = _load_jsonl(dataset_path / META_DIR / EPISODES_FILE)
        except Exception as exc:
            dataset_errors.append({"dataset_path": str(dataset_path), "error": str(exc)})
            continue

        task_by_index = {
            int(task["task_index"]): str(task.get("task", ""))
            for task in tasks
            if "task_index" in task
        }
        declared_tasks.update(task for task in task_by_index.values() if task)
        dataset_task_counts: Counter[str] = Counter()
        lengths: List[int] = []
        for episode in episodes:
            task = _episode_task(episode, task_by_index)
            task_counts[task] += 1
            dataset_task_counts[task] += 1
            length = episode.get("length")
            if isinstance(length, int):
                lengths.append(length)
                all_lengths.append(length)

        features = info.get("features", {})
        dataset_video_features = [
            name
            for name, spec in features.items()
            if isinstance(spec, dict) and spec.get("dtype") == "video"
        ]
        for name in dataset_video_features:
            video_features[name] += 1

        parquet_files = list((dataset_path / "data").rglob("*.parquet")) if (dataset_path / "data").exists() else []
        video_files = list((dataset_path / "videos").rglob("*.mp4")) if (dataset_path / "videos").exists() else []
        data_size = _path_size(dataset_path / "data")
        video_size = _path_size(dataset_path / "videos")
        meta_size = _path_size(dataset_path / META_DIR)

        dataset_total_frames = sum(lengths)
        dataset_total_episodes = len(episodes)
        dataset_total_videos = int(info.get("total_videos", len(video_files)) or 0)
        robot_type = str(info.get("robot_type", "UNKNOWN"))
        fps = str(info.get("fps", "UNKNOWN"))

        robot_types[robot_type] += 1
        fps_values[fps] += 1
        total_frames += dataset_total_frames
        total_episodes += dataset_total_episodes
        total_videos += dataset_total_videos
        total_meta_size += meta_size
        total_data_size += data_size
        total_video_size += video_size
        total_parquet_files += len(parquet_files)
        total_video_files += len(video_files)

        datasets.append(
            {
                "path": str(dataset_path),
                "name": dataset_path.name,
                "episodes": dataset_total_episodes,
                "frames": dataset_total_frames,
                "tasks": len(task_by_index),
                "task_counts": dict(dataset_task_counts),
                "length_stats": _length_stats(lengths),
                "robot_type": robot_type,
                "fps": fps,
                "codebase_version": info.get("codebase_version", "UNKNOWN"),
                "chunks_size": info.get("chunks_size", "UNKNOWN"),
                "total_chunks": info.get("total_chunks", "UNKNOWN"),
                "total_videos_meta": dataset_total_videos,
                "video_features": dataset_video_features,
                "parquet_files": len(parquet_files),
                "video_files": len(video_files),
                "meta_size_bytes": meta_size,
                "data_size_bytes": data_size,
                "video_size_bytes": video_size,
            }
        )

    return {
        "source_root": str(source_root),
        "datasets": datasets,
        "dataset_errors": dataset_errors,
        "dataset_count": len(datasets),
        "total_episodes": total_episodes,
        "total_frames": total_frames,
        "total_tasks": len(declared_tasks or set(task_counts)),
        "total_declared_task_rows": sum(row["tasks"] for row in datasets),
        "total_episode_task_names": len(task_counts),
        "task_counts": dict(task_counts),
        "length_stats": _length_stats(all_lengths),
        "episode_length_histogram": _length_histogram(all_lengths),
        "robot_types": dict(robot_types),
        "fps_values": dict(fps_values),
        "video_features": dict(video_features),
        "total_videos_meta": total_videos,
        "total_parquet_files": total_parquet_files,
        "total_video_files": total_video_files,
        "total_meta_size_bytes": total_meta_size,
        "total_data_size_bytes": total_data_size,
        "total_video_size_bytes": total_video_size,
        "total_size_bytes": total_meta_size + total_data_size + total_video_size,
    }
