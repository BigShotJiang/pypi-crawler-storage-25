"""Conversion utilities (placeholder for future formats)."""

from __future__ import annotations

from pathlib import Path


def convert_to_lerobot_v2_1(source_path: str | Path, output_path: str | Path, dry_run: bool = False) -> None:
    """
    Placeholder for converting datasets into LeRobot v2.1 format.

    This function intentionally raises until a concrete converter is implemented.
    """
    raise NotImplementedError("Conversion pipeline is not yet implemented")


__all__ = ["convert_to_lerobot_v2_1"]
