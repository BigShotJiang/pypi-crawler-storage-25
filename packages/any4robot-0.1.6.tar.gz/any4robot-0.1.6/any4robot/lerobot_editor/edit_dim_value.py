'''

Changing action or state dimension value
for scale etc.
'''
