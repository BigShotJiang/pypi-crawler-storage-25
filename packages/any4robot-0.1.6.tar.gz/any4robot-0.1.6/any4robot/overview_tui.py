"""Textual UI for dataset overview."""

from __future__ import annotations

from typing import Any, Dict, List, Tuple


def format_bytes(value: int) -> str:
    size = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} B"
        size /= 1024
    return f"{value} B"


def _top_items(items: Dict[str, int], limit: int) -> List[Tuple[str, int]]:
    return sorted(items.items(), key=lambda item: (-item[1], item[0]))[:limit]


def _length_summary(overview: Dict[str, Any]) -> str:
    stats = overview["length_stats"]
    return (
        f"min / median / mean / max: {stats['min']} / {stats['median']:.1f} / "
        f"{stats['mean']:.1f} / {stats['max']}"
    )


def run_overview_tui(overview: Dict[str, Any], top: int = 20) -> None:
    try:
        from textual.app import App, ComposeResult
        from textual.containers import Container, Horizontal, VerticalScroll
        from textual.widgets import DataTable, Footer, Header, Label, ProgressBar, Static
    except Exception as exc:  # pragma: no cover - depends on optional runtime package
        raise RuntimeError(
            "Textual is required for the overview panel. Install with: pip install textual"
        ) from exc

    class MetricCard(Static):
        def __init__(self, title: str, value: str, detail: str = ""):
            super().__init__()
            self.title = title
            self.value = value
            self.detail = detail

        def compose(self) -> ComposeResult:
            yield Label(self.title, classes="metric-title")
            yield Label(self.value, classes="metric-value")
            if self.detail:
                yield Label(self.detail, classes="metric-detail")

    class BarRow(Static):
        def __init__(self, label: str, count: int, max_count: int, total: int):
            super().__init__()
            self.label_text = label
            self.count = count
            self.max_count = max(max_count, 1)
            self.total = total

        def compose(self) -> ComposeResult:
            ratio = self.count / self.total if self.total else 0
            yield Label(self.label_text[:30], classes="bar-label")
            yield ProgressBar(total=self.max_count, show_eta=False, show_percentage=False, classes="bar-meter")
            yield Label(f"{self.count} ({ratio:.1%})", classes="bar-value")

        def on_mount(self) -> None:
            self.query_one(ProgressBar).update(progress=self.count)

    class ChartPanel(Static):
        def __init__(
            self,
            title: str,
            items: Dict[str, int],
            total: int,
            limit: int,
            subtitle: str = "",
            **kwargs: Any,
        ):
            super().__init__(**kwargs)
            self.title = title
            self.items = items
            self.total = total
            self.limit = limit
            self.subtitle = subtitle

        def compose(self) -> ComposeResult:
            yield Label(self.title, classes="panel-title")
            if self.subtitle:
                yield Label(self.subtitle, classes="panel-subtitle")

            rows = _top_items(self.items, self.limit)
            if not rows:
                yield Label("No data available.", classes="muted")
                return

            max_count = max((count for _, count in rows), default=1)
            for label, count in rows:
                yield BarRow(label, count, max_count, self.total)

    class OverviewApp(App):
        TITLE = "Any4Robot Overview"
        CSS = """
        Screen {
            background: #111418;
            color: #e9edf1;
        }
        Header {
            background: #18202a;
            color: #f4f7fb;
        }
        Footer {
            background: #18202a;
        }
        .page {
            padding: 1 2;
            height: 1fr;
        }
        .cards {
            height: 8;
            margin-bottom: 1;
        }
        .chart-row {
            height: auto;
            margin-bottom: 1;
        }
        MetricCard {
            width: 1fr;
            height: 7;
            border: round #3a4656;
            background: #171c22;
            padding: 1 2;
            margin-right: 1;
        }
        .metric-title {
            color: #94a3b8;
            text-style: bold;
        }
        .metric-value {
            color: #f8fafc;
            text-style: bold;
            margin-top: 1;
        }
        .metric-detail {
            color: #a6b4c4;
        }
        VerticalScroll {
            height: 1fr;
        }
        .panel {
            border: round #3a4656;
            background: #151a20;
            padding: 1 2;
            margin-bottom: 1;
            height: auto;
        }
        ChartPanel {
            border: round #3a4656;
            background: #151a20;
            padding: 1 2;
            margin-bottom: 1;
            height: auto;
        }
        .half-panel {
            width: 1fr;
            margin-right: 1;
        }
        .panel-title {
            color: #f8fafc;
            text-style: bold;
            margin-bottom: 1;
        }
        .panel-subtitle {
            color: #94a3b8;
            margin-bottom: 1;
        }
        BarRow {
            layout: horizontal;
            height: 1;
            margin-bottom: 1;
        }
        .bar-label {
            width: 32;
            color: #d8dee9;
        }
        .bar-meter {
            width: 1fr;
            color: #7dd3fc;
        }
        .bar-value {
            width: 16;
            text-align: right;
            color: #cbd5e1;
        }
        .chart-panel {
            color: #d8dee9;
            text-style: none;
        }
        .muted {
            color: #94a3b8;
        }
        DataTable {
            height: 16;
            border: round #3a4656;
            background: #151a20;
            margin-bottom: 1;
        }
        """

        BINDINGS = [("q", "quit", "Quit")]

        def compose(self) -> ComposeResult:
            with Container(classes="page"):
                yield Header()
                with Horizontal(classes="cards"):
                    yield MetricCard("Datasets", str(overview["dataset_count"]), overview["source_root"])
                    yield MetricCard("Episodes", str(overview["total_episodes"]), f"{overview['total_frames']} frames")
                    yield MetricCard(
                        "Tasks",
                        str(overview["total_tasks"]),
                        f"{overview['total_declared_task_rows']} task rows",
                    )
                    yield MetricCard(
                        "Storage",
                        format_bytes(overview["total_size_bytes"]),
                        f"videos {format_bytes(overview['total_video_size_bytes'])}",
                    )

                with VerticalScroll():
                    with Horizontal(classes="chart-row"):
                        yield ChartPanel(
                            "Episode Length Histogram",
                            overview.get("episode_length_histogram", {}),
                            overview["total_episodes"],
                            top,
                            subtitle=_length_summary(overview),
                            classes="half-panel",
                        )
                        yield ChartPanel(
                            "Dataset Episodes",
                            {row["name"]: row["episodes"] for row in overview["datasets"]},
                            overview["total_episodes"],
                            top,
                            classes="half-panel",
                        )

                    yield ChartPanel(
                        "Task Distribution",
                        overview["task_counts"],
                        overview["total_episodes"],
                        top,
                    )

                    table = DataTable(zebra_stripes=True)
                    table.add_columns("Dataset", "Episodes", "Frames", "Tasks", "FPS", "Robot", "Videos", "Size")
                    for row in sorted(overview["datasets"], key=lambda item: item["episodes"], reverse=True)[:top]:
                        table.add_row(
                            row["name"],
                            str(row["episodes"]),
                            str(row["frames"]),
                            str(row["tasks"]),
                            str(row["fps"]),
                            str(row["robot_type"]),
                            str(row["video_files"]),
                            format_bytes(row["meta_size_bytes"] + row["data_size_bytes"] + row["video_size_bytes"]),
                        )
                    yield table

                    yield Static(
                        "Metadata\n"
                        f"robot types: {overview['robot_types'] or {}}\n"
                        f"fps values : {overview['fps_values'] or {}}\n"
                        f"video keys : {overview['video_features'] or {}}\n"
                        f"parquet files={overview['total_parquet_files']}  "
                        f"video files={overview['total_video_files']}  "
                        f"meta total_videos={overview['total_videos_meta']}",
                        classes="panel chart-panel",
                    )

                    if overview["dataset_errors"]:
                        error_lines = ["Dataset Errors"]
                        error_lines.extend(
                            f"{entry['dataset_path']}: {entry['error']}"
                            for entry in overview["dataset_errors"]
                        )
                        yield Static("\n".join(error_lines), classes="panel chart-panel")

                yield Footer()

    OverviewApp().run()
