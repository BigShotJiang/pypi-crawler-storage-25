"""Any4Robot command line interface."""

from __future__ import annotations

import argparse
import sys
import threading
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, TypeVar

from any4robot.combine import (
    build_lerobot_overview,
    default_task_subset_output_path,
    edit_task_language,
    extract_lerobot_tasks_subset,
    get_lerobot_task_inventory,
    get_task_language_edit_inventory,
    merge_lerobot_datasets_from_folder,
    preview_task_language_edit,
)
from any4robot.qualitycheck import check_lerobot_v2_1_quality, delete_invalid_episodes
from any4robot.lerobot_editor.constants import header, highlight, info, success, warning, error


T = TypeVar("T")


def _run_with_spinner(worker: Callable[[], T], status: Dict[str, str], initial_message: str) -> T:
    if not sys.stdout.isatty():
        print(info(initial_message))
        return worker()

    done = threading.Event()
    result: Dict[str, T] = {}
    failure: Dict[str, BaseException] = {}

    def target() -> None:
        try:
            result["value"] = worker()
        except BaseException as exc:
            failure["error"] = exc
        finally:
            done.set()

    thread = threading.Thread(target=target, daemon=True)
    thread.start()

    frames = "-\\|/"
    started = time.monotonic()
    index = 0
    while not done.is_set():
        elapsed = time.monotonic() - started
        message = status.get("message", initial_message)
        sys.stdout.write(f"\r{frames[index % len(frames)]} {message} ({elapsed:0.1f}s)")
        sys.stdout.flush()
        index += 1
        time.sleep(0.12)

    thread.join()
    sys.stdout.write("\r" + " " * 100 + "\r")
    sys.stdout.flush()

    if "error" in failure:
        raise failure["error"]
    return result["value"]


def _format_ratio(value: Any) -> str:
    if value is None:
        return "-"
    try:
        return f"{value:.3f}"
    except Exception:
        return str(value)


def _format_bytes(value: int) -> str:
    size = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} B"
        size /= 1024
    return f"{value} B"


def _confirm(prompt: str, default: bool = False) -> bool:
    suffix = " [Y/n]: " if default else " [y/N]: "
    raw = input(prompt + suffix).strip().lower()
    if not raw:
        return default
    return raw in {"y", "yes"}


def _print_bar_chart(items: Dict[str, int], total: Optional[int] = None, width: int = 34, limit: int = 20) -> None:
    if not items:
        print(warning("No data available."))
        return
    sorted_items = sorted(items.items(), key=lambda item: (-item[1], item[0]))[:limit]
    max_count = max(count for _, count in sorted_items) or 1
    denominator = total if total is not None else sum(items.values())
    for label, count in sorted_items:
        bar_len = max(1, int(width * count / max_count)) if count else 0
        bar = "#" * bar_len
        ratio = count / denominator if denominator else 0
        print(f"{label[:42]:42s} | {bar:<{width}s} | {count:7d} | {ratio:7.2%}")


def _print_task_distribution(task_counts: Dict[str, int], total: int) -> None:
    print("\n" + "=" * 70)
    print(header("TASK DISTRIBUTION"))
    print("=" * 70)

    if not task_counts:
        print(warning("No task counts available."))
        return

    sorted_tasks = sorted(task_counts.items(), key=lambda item: -item[1])
    print(f"Total tasks        : {len(task_counts)}")
    print(f"Total task episodes: {total}")
    print()
    print(f"{'Task':50s} | {'Count':>8s} | {'Ratio':>8s}")
    print("-" * 70)
    for task, count in sorted_tasks:
        ratio = count / total if total else 0
        print(f"{task[:50]:50s} | {count:8d} | {ratio:7.2%}")


def _group_invalid_by_dataset(invalid_episodes: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for entry in invalid_episodes:
        dataset = entry.get("dataset_path", "UNKNOWN")
        grouped[dataset].append(entry)
    return grouped


def _print_invalid_report(report: Dict[str, Any]) -> None:
    invalid_episodes = report.get("invalid_episodes", [])
    grouped = _group_invalid_by_dataset(invalid_episodes)

    print("\n" + "=" * 70)
    print(header("INVALID EPISODES"))
    print("=" * 70)

    if not invalid_episodes:
        print(success("No invalid episodes found."))
        return

    for dataset_path, entries in grouped.items():
        dataset_name = Path(dataset_path).name
        print("\n" + highlight(f"Dataset: {dataset_name}"))
        print(info(f"Path: {dataset_path}"))
        print(info(f"Invalid episodes: {len(entries)}"))

        entries_sorted = sorted(entries, key=lambda item: item.get("episode_index", -1))
        for entry in entries_sorted:
            episode_index = entry.get("episode_index")
            task = entry.get("task")
            length = entry.get("length")
            avg_len = entry.get("avg_length")
            ratio = entry.get("ratio")
            errors = entry.get("errors", [])
            error_str = ", ".join(errors) if errors else "UNKNOWN"

            print(
                f"  {highlight(str(entry.get('episode_name', episode_index)))} "
                f"task={task} length={length} avg={avg_len} ratio={_format_ratio(ratio)}"
            )
            print(f"    {warning(error_str)}")


def _print_summary(report: Dict[str, Any]) -> None:
    print("\n" + "=" * 70)
    print(header("SUMMARY"))
    print("=" * 70)

    print(f"Total episodes      : {report.get('total_episodes', 0)}")
    print(f"Total tasks         : {report.get('total_tasks', 0)}")
    print(f"Total invalid       : {report.get('total_invalid', 0)}")
    print(f"Invalid ratio       : {report.get('invalid_ratio', 0.0):.6f}")
    print(f"Min ratio threshold : {report.get('min_ratio', 0.0)}")
    print(f"Max ratio threshold : {report.get('max_ratio', 0.0)}")


def _print_dataset_errors(report: Dict[str, Any]) -> None:
    dataset_errors = report.get("dataset_errors", [])
    if not dataset_errors:
        return

    print("\n" + "=" * 70)
    print(header("DATASET ERRORS"))
    print("=" * 70)

    for entry in dataset_errors:
        dataset = entry.get("dataset", "UNKNOWN")
        err = entry.get("error", "UNKNOWN")
        print(error(f"{dataset}: {err}"))


def _run_check(args: argparse.Namespace) -> int:
    report = check_lerobot_v2_1_quality(
        args.path,
        min_ratio=args.thresh,
        max_ratio=args.max_ratio,
    )

    print(header("Any4Robot Quality Check"))
    print(info(f"Root: {args.path}"))

    _print_summary(report)
    _print_dataset_errors(report)
    _print_invalid_report(report)
    _print_task_distribution(report.get("task_counts", {}), report.get("total_episodes", 0))

    if args.delete:
        deletion = delete_invalid_episodes(
            args.path,
            report=report,
            dry_run=args.dry_run,
        )
        deleted = deletion.get("deleted", [])
        failed = deletion.get("failed", [])

        print("\n" + "=" * 70)
        print(header("DELETE RESULTS"))
        print("=" * 70)

        if args.dry_run:
            print(warning("Dry run enabled. No files deleted."))

        if deleted:
            print(success(f"Deleted episodes: {len(deleted)}"))
        if failed:
            print(error(f"Failed to delete: {len(failed)}"))

    return 0


def _run_merge(args: argparse.Namespace) -> int:
    source_root = Path(args.source_root)
    output_path = Path(args.output)

    try:
        result = merge_lerobot_datasets_from_folder(
            source_root=source_root,
            output_path=output_path,
            dry_run=args.dry_run,
        )
    except Exception as exc:
        print(error(f"Merge failed: {exc}"))
        return 1

    if not result:
        print(error("Merge did not complete successfully."))
        return 1

    print(success(f"Merged datasets from {source_root} -> {output_path}"))
    return 0


def _run_overview(args: argparse.Namespace) -> int:
    status = {"message": "Loading dataset overview..."}

    def progress(current: int, total: int, dataset_path: Path) -> None:
        status["message"] = f"Scanning datasets {current}/{total}: {dataset_path.name}"

    try:
        overview = _run_with_spinner(
            lambda: build_lerobot_overview(args.path, progress_callback=progress),
            status,
            "Loading dataset overview...",
        )
    except Exception as exc:
        print(error(f"Overview failed: {exc}"))
        return 1

    if not args.plain:
        try:
            from any4robot.overview_tui import run_overview_tui

            run_overview_tui(overview, top=args.top)
            return 0
        except Exception as exc:
            print(warning(str(exc)))
            print(warning("Falling back to plain overview output."))

    _print_plain_overview(overview, top=args.top)
    return 0


def _print_plain_overview(overview: Dict[str, Any], top: int = 20) -> None:
    print(header("Any4Robot Dataset Overview"))
    print(info(f"Root: {overview['source_root']}"))

    print("\n" + "=" * 70)
    print(header("SUMMARY"))
    print("=" * 70)
    print(f"Datasets           : {overview['dataset_count']}")
    print(f"Total episodes     : {overview['total_episodes']}")
    print(f"Total frames       : {overview['total_frames']}")
    print(f"Unique tasks       : {overview['total_tasks']}")
    print(f"Task rows          : {overview['total_declared_task_rows']}")
    print(f"Episode task names : {overview['total_episode_task_names']}")
    print(f"Video files        : {overview['total_video_files']} (meta total_videos={overview['total_videos_meta']})")
    print(f"Parquet files      : {overview['total_parquet_files']}")
    print(f"Meta size          : {_format_bytes(overview['total_meta_size_bytes'])}")
    print(f"Data size          : {_format_bytes(overview['total_data_size_bytes'])}")
    print(f"Video size         : {_format_bytes(overview['total_video_size_bytes'])}")
    print(f"Total known size   : {_format_bytes(overview['total_size_bytes'])}")

    length_stats = overview["length_stats"]
    print("\n" + "=" * 70)
    print(header("EPISODE LENGTH"))
    print("=" * 70)
    print(f"Min / Median / Mean / Max: {length_stats['min']} / {length_stats['median']:.1f} / {length_stats['mean']:.1f} / {length_stats['max']}")
    print()
    _print_bar_chart(overview.get("episode_length_histogram", {}), total=overview["total_episodes"], limit=top)

    print("\n" + "=" * 70)
    print(header("TASK DISTRIBUTION"))
    print("=" * 70)
    _print_bar_chart(overview["task_counts"], total=overview["total_episodes"], limit=top)

    print("\n" + "=" * 70)
    print(header("DATASET EPISODES"))
    print("=" * 70)
    dataset_counts = {row["name"]: row["episodes"] for row in overview["datasets"]}
    _print_bar_chart(dataset_counts, total=overview["total_episodes"], limit=top)

    print("\n" + "=" * 70)
    print(header("DATASETS"))
    print("=" * 70)
    print(f"{'Dataset':28s} | {'Episodes':>8s} | {'Frames':>10s} | {'Tasks':>5s} | {'FPS':>8s} | {'Robot':18s}")
    print("-" * 90)
    for row in sorted(overview["datasets"], key=lambda item: item["episodes"], reverse=True)[:top]:
        print(
            f"{row['name'][:28]:28s} | {row['episodes']:8d} | {row['frames']:10d} | "
            f"{row['tasks']:5d} | {str(row['fps'])[:8]:>8s} | {str(row['robot_type'])[:18]:18s}"
        )

    print("\n" + "=" * 70)
    print(header("FEATURES"))
    print("=" * 70)
    print(f"Robot types: {overview['robot_types'] or {}}")
    print(f"FPS values : {overview['fps_values'] or {}}")
    print(f"Video keys : {overview['video_features'] or {}}")

    if overview["dataset_errors"]:
        print("\n" + "=" * 70)
        print(header("DATASET ERRORS"))
        print("=" * 70)
        for entry in overview["dataset_errors"]:
            print(error(f"{entry['dataset_path']}: {entry['error']}"))


def _parse_number_selection(raw: str, max_number: int) -> List[int]:
    selected: List[int] = []
    seen = set()
    for part in raw.replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            start_raw, end_raw = part.split("-", 1)
            start = int(start_raw)
            end = int(end_raw)
            numbers = range(start, end + 1)
        else:
            numbers = [int(part)]
        for number in numbers:
            if number < 1 or number > max_number:
                raise ValueError(f"Selection {number} is outside 1-{max_number}")
            if number not in seen:
                selected.append(number)
                seen.add(number)
    return selected


def _print_available_tasks(task_rows: List[Dict[str, Any]]) -> None:
    print("\n" + "=" * 70)
    print(header("AVAILABLE TASKS"))
    print("=" * 70)
    for index, row in enumerate(task_rows, start=1):
        task = row["task"]
        episodes = row.get("episodes", 0)
        datasets = len(row.get("datasets", []))
        print(f"{index:3d}. {task[:54]:54s} | episodes={episodes:6d} | datasets={datasets:3d}")


def _select_tasks_interactively(task_rows: List[Dict[str, Any]]) -> List[str]:
    _print_available_tasks(task_rows)
    prompt = "\nSelect task numbers to extract (example: 1,3 or 2-4): "
    raw = input(prompt).strip()
    numbers = _parse_number_selection(raw, len(task_rows))
    if not numbers:
        raise ValueError("No tasks selected")
    return [task_rows[number - 1]["task"] for number in numbers]


def _run_extract_tasks(args: argparse.Namespace) -> int:
    source_root = Path(args.source_root)
    try:
        inventory = get_lerobot_task_inventory(source_root)
    except Exception as exc:
        print(error(f"Failed to read task inventory: {exc}"))
        return 1

    if not inventory:
        print(error(f"No tasks found under {source_root}"))
        return 1

    task_rows = sorted(inventory.values(), key=lambda row: (-int(row.get("episodes", 0)), row["task"]))

    try:
        if args.tasks:
            _print_available_tasks(task_rows)
            selected_tasks = args.tasks
            missing = [task for task in selected_tasks if task not in inventory]
            if missing:
                print(error(f"Unknown task(s): {', '.join(missing)}"))
                return 1
        elif args.task_numbers:
            _print_available_tasks(task_rows)
            numbers = _parse_number_selection(args.task_numbers, len(task_rows))
            selected_tasks = [task_rows[number - 1]["task"] for number in numbers]
        else:
            selected_tasks = _select_tasks_interactively(task_rows)
    except Exception as exc:
        print(error(f"Invalid task selection: {exc}"))
        return 1

    output_path = Path(args.output) if args.output else default_task_subset_output_path(source_root, selected_tasks)

    print(info(f"Source: {source_root}"))
    print(info(f"Output: {output_path}"))
    print(info(f"Selected tasks: {', '.join(selected_tasks)}"))

    try:
        result = extract_lerobot_tasks_subset(
            source_root=source_root,
            task_names=selected_tasks,
            output_path=output_path,
            dry_run=args.dry_run,
        )
    except Exception as exc:
        print(error(f"Task extraction failed: {exc}"))
        return 1

    if args.dry_run:
        print(warning("Dry run enabled. No files written."))

    print(success(f"Extracted {result['total_episodes']} episodes -> {result['output_path']}"))
    print(info(f"Total frames: {result['total_frames']}"))
    if "total_videos" in result:
        print(info(f"Total videos: {result['total_videos']}"))
    return 0


def _run_edit_task_lan(args: argparse.Namespace) -> int:
    source_root = Path(args.source_root)
    try:
        inventory = get_task_language_edit_inventory(source_root)
    except Exception as exc:
        print(error(f"Failed to read task inventory: {exc}"))
        return 1

    if not inventory:
        print(error(f"No tasks found under {source_root}"))
        return 1

    task_rows = sorted(inventory.values(), key=lambda row: (-int(row.get("episodes", 0)), row["task"]))
    _print_available_tasks(task_rows)

    try:
        if args.task_number:
            numbers = _parse_number_selection(args.task_number, len(task_rows))
            if len(numbers) != 1:
                raise ValueError("edit-task-lan expects exactly one task number")
            old_task = task_rows[numbers[0] - 1]["task"]
        else:
            raw = input("\nSelect one task number to edit: ").strip()
            numbers = _parse_number_selection(raw, len(task_rows))
            if len(numbers) != 1:
                raise ValueError("Please select exactly one task number")
            old_task = task_rows[numbers[0] - 1]["task"]
    except Exception as exc:
        print(error(f"Invalid task selection: {exc}"))
        return 1

    new_task = args.new_task if args.new_task is not None else input("New task language/string: ").strip()
    if not new_task:
        print(error("New task string must not be empty."))
        return 1

    preview = preview_task_language_edit(source_root, old_task)
    if not preview["total_datasets"]:
        print(error(f"No metadata rows matched task: {old_task}"))
        return 1

    print("\n" + "=" * 70)
    print(header("EDIT PREVIEW"))
    print("=" * 70)
    print(f"Old task     : {old_task}")
    print(f"New task     : {new_task}")
    print(f"Datasets     : {preview['total_datasets']}")
    print(f"tasks rows   : {preview['total_task_rows']}")
    print(f"episode rows : {preview['total_episode_rows']}")
    for row in preview["datasets"]:
        print(
            f"  {Path(row['dataset_path']).name}: "
            f"tasks={row['task_rows']} episodes={row['episode_rows']}"
        )

    if not args.yes and not _confirm("Confirm this task language edit?", default=False):
        print(warning("Canceled."))
        return 0

    if args.inplace:
        inplace = True
    elif args.no_inplace:
        inplace = False
    else:
        inplace = _confirm("Write changes inplace to original episodes.jsonl/tasks.jsonl?", default=False)

    try:
        result = edit_task_language(
            source_root=source_root,
            old_task=old_task,
            new_task=new_task,
            inplace=inplace,
        )
    except Exception as exc:
        print(error(f"Task language edit failed: {exc}"))
        return 1

    print(success("Task language edit completed."))
    print(info(f"Inplace: {result['inplace']}"))
    print(info(f"Datasets changed: {result['total_datasets']}"))
    print(info(f"tasks rows changed: {result['total_task_rows']}"))
    print(info(f"episode rows changed: {result['total_episode_rows']}"))
    if not result["inplace"]:
        print(info("Generated files:"))
        for row in result["datasets"]:
            print(f"  {row['tasks_path']}")
            print(f"  {row['episodes_path']}")
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Any4Robot CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  any4robot check /data/folder
  any4robot check /data/folder --delete --thresh 0.25
  any4robot check /data/folder --delete --thresh 0.25 --dry-run
  any4robot overview /data/folder
  any4robot merge /data/folder --output /data/merged_dataset
  any4robot extract-tasks /data/dataset
  any4robot extract-tasks /data/folder --task-numbers 1,3
  any4robot extract-tasks /data/folder --tasks "pick cube" "place cube"
  any4robot edit-task-lan /data/folder
        """,
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    check_parser = subparsers.add_parser("check", help="Check dataset quality")
    check_parser.add_argument("path", help="Dataset root or parent folder")
    check_parser.add_argument(
        "--thresh",
        type=float,
        default=0.25,
        help="Minimum length ratio vs task average to accept (default: 0.25)",
    )
    check_parser.add_argument(
        "--max-ratio",
        type=float,
        default=4.0,
        help="Maximum length ratio vs task average to accept (default: 4.0)",
    )
    check_parser.add_argument(
        "--delete",
        action="store_true",
        help="Delete invalid episodes after checking",
    )
    check_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be deleted without deleting",
    )
    check_parser.set_defaults(func=_run_check)

    overview_parser = subparsers.add_parser(
        "overview",
        help="Show rich overview stats for a LeRobot v2.1 dataset or parent folder",
    )
    overview_parser.add_argument(
        "path",
        help="LeRobot v2.1 dataset root or folder containing multiple dataset roots",
    )
    overview_parser.add_argument(
        "--top",
        type=int,
        default=20,
        help="Maximum rows to show in charts/tables (default: 20)",
    )
    overview_parser.add_argument(
        "--plain",
        action="store_true",
        help="Print plain terminal overview instead of launching the Textual panel",
    )
    overview_parser.set_defaults(func=_run_overview)

    merge_parser = subparsers.add_parser(
        "merge",
        help="Merge multiple LeRobot datasets discovered under one folder",
    )
    merge_parser.add_argument(
        "source_root",
        help="Folder containing multiple LeRobot datasets (or a single dataset root)",
    )
    merge_parser.add_argument(
        "--output",
        required=True,
        help="Output path for merged dataset",
    )
    merge_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show merge plan without writing files",
    )
    merge_parser.set_defaults(func=_run_merge)

    extract_parser = subparsers.add_parser(
        "extract-tasks",
        aliases=["tasks-subset"],
        help="Extract selected LeRobot v2.1 tasks into a new dataset subset",
    )
    extract_parser.add_argument(
        "source_root",
        help="LeRobot v2.1 dataset root or folder containing multiple dataset roots",
    )
    extract_parser.add_argument(
        "--output",
        help="Output path for extracted subset (default: source name plus _subset_<tasks>)",
    )
    extract_parser.add_argument(
        "--tasks",
        nargs="+",
        help="Task names to extract; quote task names that contain spaces",
    )
    extract_parser.add_argument(
        "--task-numbers",
        help="Task numbers to extract after sorting by episode count, e.g. 1,3 or 2-4",
    )
    extract_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show extraction plan without writing files",
    )
    extract_parser.set_defaults(func=_run_extract_tasks)

    edit_task_parser = subparsers.add_parser(
        "edit-task-lan",
        aliases=["edit-task-lang"],
        help="Interactively edit task language text in LeRobot v2.1 metadata",
    )
    edit_task_parser.add_argument(
        "source_root",
        help="LeRobot v2.1 dataset root or folder containing multiple dataset roots",
    )
    edit_task_parser.add_argument(
        "--task-number",
        help="Task number to edit after listing tasks; normally selected interactively",
    )
    edit_task_parser.add_argument(
        "--new-task",
        help="New task string; normally entered interactively",
    )
    inplace_group = edit_task_parser.add_mutually_exclusive_group()
    inplace_group.add_argument(
        "--inplace",
        action="store_true",
        help="Overwrite original meta/tasks.jsonl and meta/episodes.jsonl",
    )
    inplace_group.add_argument(
        "--no-inplace",
        action="store_true",
        help="Write meta/tasks_new.jsonl and meta/episodes_new.jsonl",
    )
    edit_task_parser.add_argument(
        "--yes",
        action="store_true",
        help="Skip final edit confirmation; still lists the task table and preview",
    )
    edit_task_parser.set_defaults(func=_run_edit_task_lan)

    return parser


def main(argv: List[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
