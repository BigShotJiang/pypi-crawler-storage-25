# Any4Robot

`any4robot` provides dataset conversion and management utilities for training VLA / WM / VAM robot control models. Data preparation is crucial for robot model development. Any4Robot provides a standardized, verified way to produce the right data so you can focus on model design.

## Install

```bash
pip install any4robot
```

## Quick start (LeRobot editor)

```python
from any4robot import LeRobotDatasetEditor

editor = LeRobotDatasetEditor("/path/to/lerobot-dataset")
editor.list_episodes(0, 5)
editor.delete_episode(12, dry_run=True)
```

## Combine datasets

```python
from any4robot.combine import merge_lerobot_datasets

merge_lerobot_datasets(
    ["/path/to/dataset_a", "/path/to/dataset_b"],
    "/path/to/output_dataset",
)
```

## Quality check (LeRobot v2.1 layout)

```python
from any4robot.qualitycheck import validate_lerobot_v2_1

result = validate_lerobot_v2_1("/path/to/lerobot-dataset")
print(result)
```

## Modules

- `any4robot.editing`: LeRobot dataset editing helpers (delete episode, copy episode, list episodes)
- `any4robot.combine`: Merge multiple LeRobot datasets into a single dataset
- `any4robot.qualitycheck`: Validate datasets (LeRobot v2.1 layout)
- `any4robot.conversion`: Placeholder for future dataset conversion pipelines

## Notes

- The LeRobot editor code is copied from `vendor/lero` and organized under `any4robot/lerobot_editor`.
- Optional GUI dependencies are available with `pip install any4robot[gui]`.
