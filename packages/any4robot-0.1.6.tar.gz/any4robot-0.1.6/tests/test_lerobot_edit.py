from any4robot import LeRobotDatasetEditor

# local dataset folder path
dataset_path = "data/towel05/towl05_35_0106"

# indices to delete
delete_indices = [10]

editor = LeRobotDatasetEditor(dataset_path)

for idx in sorted(delete_indices, reverse=True):
    editor.delete_episode(idx)

print("Deleted episodes:", delete_indices)
