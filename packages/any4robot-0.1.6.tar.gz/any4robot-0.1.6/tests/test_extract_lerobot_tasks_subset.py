import json
from pathlib import Path
from typing import Dict, List

import pandas as pd

from any4robot.combine import extract_lerobot_tasks_subset, get_lerobot_task_inventory


def _write_json(path: Path, payload: Dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


def _write_jsonl(path: Path, rows: List[Dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row) + "\n")


def _create_dataset(root: Path, name: str, episode_tasks: List[str]) -> Path:
    dataset_root = root / name
    meta_root = dataset_root / "meta"
    data_root = dataset_root / "data" / "chunk-000"
    data_root.mkdir(parents=True, exist_ok=True)

    task_names = sorted(set(episode_tasks))
    task_to_index = {task: index for index, task in enumerate(task_names)}
    lengths = [2 for _ in episode_tasks]

    _write_json(
        meta_root / "info.json",
        {
            "codebase_version": "0.1.0",
            "data_path": "data/chunk-{episode_chunk:03d}/episode_{episode_index:06d}.parquet",
            "video_path": "videos/chunk-{episode_chunk:03d}/{video_key}/episode_{episode_index:06d}.mp4",
            "features": {},
            "total_episodes": len(episode_tasks),
            "total_frames": sum(lengths),
            "total_tasks": len(task_names),
            "total_chunks": 1,
            "total_videos": 0,
            "chunks_size": 1000,
            "splits": {"train": f"0:{len(episode_tasks)}"},
            "robot_type": "test_bot",
            "fps": 30,
        },
    )
    _write_jsonl(
        meta_root / "tasks.jsonl",
        [{"task_index": index, "task": task} for task, index in task_to_index.items()],
    )

    episodes = []
    stats = []
    global_index = 0
    for episode_index, task in enumerate(episode_tasks):
        task_index = task_to_index[task]
        episodes.append(
            {
                "episode_index": episode_index,
                "task": task,
                "task_index": task_index,
                "length": 2,
            }
        )
        stats.append(
            {
                "episode_index": episode_index,
                "action": {
                    "mean": [float(episode_index)],
                    "std": [0.0],
                    "min": [0.0],
                    "max": [float(episode_index)],
                    "count": [2],
                },
            }
        )
        pd.DataFrame(
            {
                "index": [global_index, global_index + 1],
                "frame_index": [0, 1],
                "episode_index": [episode_index, episode_index],
                "task_index": [task_index, task_index],
                "action": [[0.1], [0.2]],
            }
        ).to_parquet(data_root / f"episode_{episode_index:06d}.parquet", index=False)
        global_index += 2

    _write_jsonl(meta_root / "episodes.jsonl", episodes)
    _write_jsonl(meta_root / "episodes_stats.jsonl", stats)
    return dataset_root


def test_extract_lerobot_tasks_subset_from_folder(tmp_path: Path) -> None:
    source_root = tmp_path / "source"
    _create_dataset(source_root, "dataset_a", ["pick", "place"])
    _create_dataset(source_root, "dataset_b", ["pick"])

    inventory = get_lerobot_task_inventory(source_root)
    assert inventory["pick"]["episodes"] == 2
    assert inventory["place"]["episodes"] == 1

    output = tmp_path / "pick_subset"
    result = extract_lerobot_tasks_subset(source_root, ["pick"], output_path=output)

    assert result["total_episodes"] == 2
    assert result["total_frames"] == 4

    episodes = [
        json.loads(line)
        for line in (output / "meta" / "episodes.jsonl").read_text(encoding="utf-8").splitlines()
    ]
    tasks = [
        json.loads(line)
        for line in (output / "meta" / "tasks.jsonl").read_text(encoding="utf-8").splitlines()
    ]
    info = json.loads((output / "meta" / "info.json").read_text(encoding="utf-8"))
    stats_rows = (output / "meta" / "episodes_stats.jsonl").read_text(encoding="utf-8").splitlines()

    assert [episode["episode_index"] for episode in episodes] == [0, 1]
    assert {episode["task"] for episode in episodes} == {"pick"}
    assert [episode["task_index"] for episode in episodes] == [0, 0]
    assert tasks == [{"task_index": 0, "task": "pick"}]
    assert info["total_episodes"] == 2
    assert info["total_frames"] == 4
    assert info["total_tasks"] == 1
    assert info["splits"] == {"train": "0:2"}
    assert len(stats_rows) == 2
    assert (output / "meta" / "stats.json").exists()

    first = pd.read_parquet(output / "data" / "chunk-000" / "episode_000000.parquet")
    second = pd.read_parquet(output / "data" / "chunk-000" / "episode_000001.parquet")
    assert first["episode_index"].tolist() == [0, 0]
    assert second["episode_index"].tolist() == [1, 1]
    assert first["task_index"].tolist() == [0, 0]
    assert second["task_index"].tolist() == [0, 0]
    assert first["index"].tolist() == [0, 1]
    assert second["index"].tolist() == [2, 3]
