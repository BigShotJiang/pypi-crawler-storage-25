"""IMDb person (name) pages — ported from php-imdb ``Imdb\\Person``."""

from __future__ import annotations

import html as html_module
import json
import os
import re
import urllib.request
from pathlib import Path
from typing import Any

import requests
from lxml import html as lhtml

from .auteur_config import AuteurConfig
from .lib.imdb_http import ImdbClient, ImdbHttpError, normalize_person_id, person_page_url

TITLE_MOVIE = "Movie"
TITLE_TV_SERIES = "TV Series"
TITLE_TV_EPISODE = "TV Episode"
TITLE_TV_MINI_SERIES = "TV Mini Series"
TITLE_TV_MOVIE = "TV Movie"
TITLE_TV_SPECIAL = "TV Special"
TITLE_TV_SHORT = "TV Short"
TITLE_GAME = "Video Game"
TITLE_VIDEO = "Video"
TITLE_SHORT = "Short"

TITLE_TYPE_MAP: dict[str, str] = {
    TITLE_MOVIE: TITLE_MOVIE,
    TITLE_TV_SERIES: TITLE_TV_SERIES,
    TITLE_TV_EPISODE: TITLE_TV_EPISODE,
    TITLE_TV_MINI_SERIES: TITLE_TV_MINI_SERIES,
    TITLE_TV_MOVIE: TITLE_TV_MOVIE,
    TITLE_TV_SPECIAL: TITLE_TV_SPECIAL,
    TITLE_TV_SHORT: TITLE_TV_SHORT,
    TITLE_GAME: TITLE_GAME,
    TITLE_VIDEO: TITLE_VIDEO,
    TITLE_SHORT: TITLE_SHORT,
    "Documentary": TITLE_MOVIE,
    "TV Movie documentary": TITLE_TV_MOVIE,
    "TV Series documentary": TITLE_TV_SERIES,
    "Video documentary short": TITLE_VIDEO,
    "Video documentary": TITLE_VIDEO,
}

MONTH_NO: dict[str, str] = {
    "January": "01",
    "Jan": "01",
    "February": "02",
    "Feb": "02",
    "March": "03",
    "Mar": "03",
    "April": "04",
    "Apr": "04",
    "May": "05",
    "June": "06",
    "Jun": "06",
    "July": "07",
    "Jul": "07",
    "August": "08",
    "Aug": "08",
    "September": "09",
    "Sep": "09",
    "October": "10",
    "Oct": "10",
    "November": "11",
    "Nov": "11",
    "December": "12",
    "Dec": "12",
}


def _month_no(mon: str) -> str:
    m = (mon or "").strip()
    return MONTH_NO.get(m, "")


def _strip_imdb_page_title(s: str) -> str:
    t = s.strip()
    t = re.sub(r"\s*-\s*IMDb\s*$", "", t, flags=re.I)
    t = re.sub(r"^IMDb\s*-\s*", "", t, flags=re.I)
    return t


def strip_tags_simple(s: str) -> str:
    return re.sub(r"<[^>]+>", "", s)


class ImdbPerson:
    """A person on IMDb (mirrors php-imdb ``Imdb\\Person``)."""

    PAGE_URLS = {
        "Name": "/",
        "Bio": "/bio",
        "Publicity": "/publicity",
        "Fullcredits": "/fullcredits",
    }

    def __init__(
        self,
        imdb_id: str,
        config: AuteurConfig | None = None,
        client: ImdbClient | None = None,
    ) -> None:
        self._c = config or AuteurConfig()
        self._id = normalize_person_id(imdb_id)
        self._http = client or ImdbClient(self._c)
        self._pages: dict[str, str] = {}
        self._xpath_cache: dict[str, Any] = {}

        self._fullname = ""
        self._main_photo: str | bool | None = None
        self._json_ld: Any = None

        self._allfilms: list[dict[str, Any]] | None = None
        self._actorsfilms: list[dict[str, Any]] | None = None
        self._actressfilms: list[dict[str, Any]] | None = None
        self._producersfilms: list[dict[str, Any]] | None = None
        self._soundtrackfilms: list[dict[str, Any]] | None = None
        self._directorsfilms: list[dict[str, Any]] | None = None
        self._crewsfilms: list[dict[str, Any]] | None = None
        self._thanxfilms: list[dict[str, Any]] | None = None
        self._writerfilms: list[dict[str, Any]] | None = None
        self._selffilms: list[dict[str, Any]] | None = None
        self._archivefilms: list[dict[str, Any]] | None = None

        self._birth_name = ""
        self._nick_name: list[str] | None = None
        self._birthday: list[Any] | dict[str, Any] | None = None
        self._deathday: list[Any] | dict[str, Any] | None = None
        self._bodyheight: list[Any] | dict[str, str] | None = None
        self._spouses: list[dict[str, Any]] | None = None
        self._bio_bio: list[dict[str, Any]] | None = None
        self._bio_trivia: list[str] | None = None
        self._bio_tm: list[str] | None = None
        self._bio_salary: list[dict[str, Any]] | None = None
        self._bio_quotes: list[str] | None = None

        self._pub_prints: list[dict[str, str]] | None = None
        self._pub_movies: list[dict[str, str]] | None = None
        self._pub_portraits: list[dict[str, str]] | None = None
        self._pub_interviews: list[dict[str, Any]] | None = None
        self._pub_articles: list[dict[str, Any]] | None = None
        self._pub_pictorials: list[dict[str, Any]] | None = None
        self._pub_magcovers: list[dict[str, Any]] | None = None

        self._search_details: dict[str, Any] = {}

        # ensure an exception is thrown if the item does not exist
        self.name()

    @classmethod
    def from_search_results(
        cls,
        imdb_id: str,
        name: str,
        config: AuteurConfig | None = None,
        client: ImdbClient | None = None,
    ) -> ImdbPerson:
        p = cls(imdb_id, config, client)
        p._fullname = name
        return p

    def imdbid(self) -> str:
        return self._id

    @property
    def imdb_id(self) -> str:
        return self._id

    @property
    def imdbsite(self) -> str:
        return self._c.imdbsite

    def main_url(self) -> str:
        return person_page_url(self._id, self._c, "/")

    def _build_url(self, page: str = "Name") -> str:
        suf = self.PAGE_URLS.get(page, "/")
        return person_page_url(self._id, self._c, suf)

    def _get_page(self, page: str = "Name") -> str:
        if page in self._pages:
            return self._pages[page]
        url = self._build_url(page)
        try:
            raw = self._http.get(url)
        except (ImdbHttpError, OSError, requests.RequestException):
            if self._c.throw_http_exceptions:
                raise
            raw = ""
        self._pages[page] = raw
        return raw

    def _xp(self, page: str):
        if page not in self._xpath_cache:
            raw = self._get_page(page)
            self._xpath_cache[page] = lhtml.fromstring(raw)
        return self._xpath_cache[page]

    def _json_ld_name(self) -> Any:
        if self._json_ld is not None:
            return self._json_ld
        page = self._get_page("Name")
        self._json_ld = False
        m = re.search(r'<script type="application/ld\+json">(.+?)</script>', page, re.I | re.S)
        if m:
            try:
                self._json_ld = json.loads(m.group(1))
            except json.JSONDecodeError:
                self._json_ld = False
        return self._json_ld

    def name(self) -> str:
        if self._fullname:
            return self._fullname
        page = self._get_page("Name")
        m = re.search(r"<title>(.*?)\s*-\s*IMDb</title>", page, re.I | re.S)
        if m:
            self._fullname = _strip_imdb_page_title(m.group(1))
        else:
            m2 = re.search(r"<title>IMDb\s*-\s*(.*?)</title>", page, re.I | re.S)
            self._fullname = _strip_imdb_page_title(m2.group(1)) if m2 else ""
        return self._fullname

    def photo(self, thumb: bool = True) -> str | bool:
        """Matches php-imdb: one cached URL; only the first call’s ``thumb`` affects fetch."""
        if self._main_photo is None:
            page = self._get_page("Name")
            self._main_photo = False
            m = re.search(
                r"ipc-(?:poster--baseAlt|media--poster-m).*?<img.*?src=\"(.*?)\"",
                page,
                re.I | re.S,
            )
            if m:
                src = m.group(1)
                self._main_photo = src if thumb else re.sub(r"(_V1_).*(\.[a-z]+$)", r"\1\2", src, flags=re.I)
            else:
                ld = self._json_ld_name()
                if ld and isinstance(ld, dict) and ld.get("image"):
                    self._main_photo = str(ld["image"])
                else:
                    tree = self._xp("Name")
                    th = tree.xpath(
                        "//div[contains(@class,'ipc-poster')]"
                        "//img[contains(@class,'ipc-image')]/@src"
                    )
                    if not th:
                        th = tree.xpath("//img[contains(@src,'media-amazon.com/images')]/@src")
                    if th:
                        src = th[0]
                        self._main_photo = src if thumb else re.sub(
                            r"(_V1_).*(\.[a-z]+$)", r"\1\2", src, flags=re.I
                        )

        if self._main_photo is False:
            return False
        assert isinstance(self._main_photo, str)
        return self._main_photo

    def savephoto(self, path: str, thumb: bool = True, rerun: bool = False) -> bool:
        url = self.photo(thumb)
        if not url or not isinstance(url, str):
            return False
        try:
            req = urllib.request.Request(url, headers={"User-Agent": self._c.user_agent()})
            with urllib.request.urlopen(req, timeout=30) as r:
                data = r.read()
            ct = r.headers.get("Content-Type", "")
            if not (
                ct.startswith("image/jpeg")
                or ct.startswith("image/gif")
                or ct.startswith("image/bmp")
                or ct.startswith("image/webp")
            ):
                if rerun:
                    return False
                return self.savephoto(path, thumb, True)
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            with open(path, "wb") as f:
                f.write(data)
            return True
        except OSError:
            return False

    def photo_localurl(self, thumb: bool = True) -> str | bool:
        pd = Path(str(self._c.photodir))
        ext = "" if thumb else "_big"
        nm = f"nm{self._id}{ext}.jpg"
        path = pd / nm
        pr = str(self._c.photoroot).rstrip("/") + "/"
        if not pd.is_dir():
            return False
        if path.is_file():
            return pr + nm
        if not os.access(str(pd), os.W_OK):
            return False
        if self.savephoto(str(path), thumb):
            return pr + nm
        return False

    def _filmograf(self, res: list[dict[str, Any]], section_type: str) -> None:
        page = self._get_page("Fullcredits")
        if not section_type:
            block = page
        else:
            m = re.search(
                rf'<a name="{re.escape(section_type)}"(.*?(<div id="filmo|<script))',
                page,
                re.I | re.S,
            )
            match_inner = m.group(1) if m else ""
            if not match_inner:
                cap = section_type[:1].upper() + section_type[1:] if section_type else ""
                pos = page.find(f'<a name="{cap}"')
                if pos >= 0:
                    epos = page.find("<div id=", pos)
                    block = page[pos:epos] if epos > pos else page[pos:]
                else:
                    return
            else:
                block = match_inner
        if not block:
            return
        rows = re.findall(r'<div class="filmo-row[^"]*".*?>\s*(.*?)\s*</div>', block, re.I | re.S)
        for raw_row in rows:
            title_type = TITLE_MOVIE
            mov = re.search(
                r'href="/title/tt(\d{7,8})/[^"]*"\s*>(.*?)</a>\s*</b>\s*(.*)',
                raw_row,
                re.I | re.S,
            )
            if not mov:
                continue
            mid, title_name, rest = mov.group(1), mov.group(2), mov.group(3)
            year = ""
            ty = re.search(r'<span class="year_column">[^<]*(\d{4})(.*?)</span>', raw_row, re.I | re.S)
            if ty:
                year = ty.group(1)
            chid = ""
            chm = re.search(r'href="/character/ch(\d{7,8})[^"]*"\s*>(.*?)</a>', raw_row, re.I | re.S)
            if chm:
                chid = chm.group(1)
                chname = chm.group(2)
            else:
                br = re.search(r"<br\s*/>\s*([^>]+)\s*</*div", raw_row, re.I | re.S)
                chname = br.group(1).strip() if br else ""
            if not chname.strip():
                if section_type == "director":
                    chname = "Director"
                elif section_type == "producer":
                    chname = "Producer"
            tm = re.search(r"\(([^\)]+)\)", rest)
            if tm:
                for orig, mapped in TITLE_TYPE_MAP.items():
                    if tm.group(1) == orig:
                        title_type = mapped
                        break
            addons: list[str] = []
            if re.findall(r"\((.+)\)", chname):
                addons = re.findall(r"\((.+)\)", chname)
                chname = re.sub(r"\((.+)\)", "", chname).strip()
            res.append(
                {
                    "mid": mid,
                    "name": title_name,
                    "year": year,
                    "title_type": title_type,
                    "chid": chid,
                    "chname": chname.strip(),
                    "addons": addons,
                }
            )

    def movies_all(self) -> list[dict[str, Any]]:
        if self._allfilms is None:
            self._allfilms = []
            self._filmograf(self._allfilms, "")
        return self._allfilms

    def movies_actor(self) -> list[dict[str, Any]]:
        if self._actorsfilms is None:
            self._actorsfilms = []
            self._filmograf(self._actorsfilms, "actor")
            self._filmograf(self._actorsfilms, "actress")
        return self._actorsfilms

    def movies_actress(self) -> list[dict[str, Any]]:
        if self._actressfilms is None:
            self._actressfilms = []
            self._filmograf(self._actressfilms, "actress")
        return self._actressfilms

    def movies_producer(self) -> list[dict[str, Any]]:
        if self._producersfilms is None:
            self._producersfilms = []
            self._filmograf(self._producersfilms, "producer")
        return self._producersfilms

    def movies_director(self) -> list[dict[str, Any]]:
        if self._directorsfilms is None:
            self._directorsfilms = []
            self._filmograf(self._directorsfilms, "director")
        return self._directorsfilms

    def movies_soundtrack(self) -> list[dict[str, Any]]:
        if self._soundtrackfilms is None:
            self._soundtrackfilms = []
            self._filmograf(self._soundtrackfilms, "soundtrack")
        return self._soundtrackfilms

    def movies_crew(self) -> list[dict[str, Any]]:
        if self._crewsfilms is None:
            self._crewsfilms = []
            self._filmograf(self._crewsfilms, "miscellaneous")
        return self._crewsfilms

    def movies_thanx(self) -> list[dict[str, Any]]:
        if self._thanxfilms is None:
            self._thanxfilms = []
            self._filmograf(self._thanxfilms, "thanks")
        return self._thanxfilms

    def movies_self(self) -> list[dict[str, Any]]:
        if self._selffilms is None:
            self._selffilms = []
            self._filmograf(self._selffilms, "self")
        return self._selffilms

    def movies_writer(self) -> list[dict[str, Any]]:
        if self._writerfilms is None:
            self._writerfilms = []
            self._filmograf(self._writerfilms, "writer")
        return self._writerfilms

    def movies_archive(self) -> list[dict[str, Any]]:
        if self._archivefilms is None:
            self._archivefilms = []
            self._filmograf(self._archivefilms, "archive_footage")
        return self._archivefilms

    def birthname(self) -> str:
        if not self._birth_name:
            page = self._get_page("Bio")
            m = re.search(r"Birth Name</td>\s*<td>(.*?)</td>", page, re.M | re.S)
            if m:
                self._birth_name = html_module.unescape(re.sub(r"<[^>]+>", "", m.group(1)).strip())
        return self._birth_name

    def nickname(self) -> list[str]:
        if self._nick_name is None:
            self._nick_name = []
            page = self._get_page("Bio")
            m = re.search(r"Nicknames</td>\s*<td>\s*(.*?)</td>\s*</tr>", page, re.M | re.S)
            if m:
                for part in re.split(r"<br\s*/?>", m.group(1), flags=re.I):
                    n = re.sub(r"<[^>]+>", "", part).strip()
                    if n:
                        self._nick_name.append(n)
            else:
                m2 = re.search(r"Nickname</td><td>\s*([^<]+)\s*</td>", page)
                if m2:
                    self._nick_name.append(m2.group(1).strip())
        return self._nick_name

    def born(self) -> Any:
        if self._birthday is None:
            self._birthday = []
            page = self._get_page("Bio")
            m = re.search(r"Born</td>(.*)</td", page, re.I | re.S | re.M)
            if not m:
                return self._birthday
            inner = m.group(1)
            daymon = re.search(
                r"/search/name\?birth_monthday=(\d+)-(\d+).*?\n?>(.*?) \d+<",
                inner,
                re.S,
            )
            dyear = re.search(r"/search/name\?birth_year=(\d{4})", inner, re.I | re.S)
            dloc = re.search(r'/search/name\?birth_place=.*?"\s*>(.*?)<', inner, re.I | re.S)
            self._birthday = {
                "day": daymon.group(2) if daymon else "",
                "month": daymon.group(3) if daymon else "",
                "mon": daymon.group(1) if daymon else "",
                "year": dyear.group(1) if dyear else "",
                "place": dloc.group(1) if dloc else "",
            }
        return self._birthday

    def died(self) -> Any:
        if self._deathday is None:
            self._deathday = []
            page = self._get_page("Bio")
            m = re.search(r"Died</td>(.*?)</td", page, re.I | re.S | re.M)
            if not m:
                return self._deathday
            inner = m.group(1)
            dmy = re.search(
                r"/search/name\?death_date=(\d+)-(\d+)-(\d+).*?\n?>(.*?) \d+<",
                inner,
                re.S,
            )
            dloc = re.search(r'/search/name\?death_place=.*?"\s*>(.*?)<', inner, re.I | re.S)
            dcause = re.search(r"\(([^\)]+)\)", inner, re.I | re.S)
            place = ""
            if dloc:
                place = re.sub(r"<[^>]+>", "", dloc.group(1)).strip()
            self._deathday = {
                "day": dmy.group(3) if dmy else "",
                "month": dmy.group(4) if dmy else "",
                "mon": dmy.group(2) if dmy else "",
                "year": dmy.group(1) if dmy else "",
                "place": place,
                "cause": dcause.group(1) if dcause else "",
            }
        return self._deathday

    def height(self) -> Any:
        if self._bodyheight is None:
            self._bodyheight = []
            page = self._get_page("Bio")
            m = re.search(
                r"Height</td>\s*<td>\s*(.+?)\s*\((.+?)\)</td>",
                page.replace("&nbsp;", "\xa0"),
                re.M | re.S,
            )
            if m:
                imp = re.sub(r"\s+", " ", m.group(1).replace("\xa0", " ")).strip()
                metric = re.sub(r"\s+", " ", m.group(2).replace("\xa0", " ")).strip()
                self._bodyheight = {"imperial": imp, "metric": metric}
        return self._bodyheight

    def spouse(self) -> list[dict[str, Any]]:
        if self._spouses is None:
            self._spouses = []
        return self._spouses

    def bio(self) -> list[dict[str, Any]]:
        if self._bio_bio is None:
            self._bio_bio = []
            page = self._get_page("Bio")
            if not page:
                return self._bio_bio
            m = re.search(
                r'<h4 class="li_group">Mini Bio[^>]+?>(.+?)<(h4 class="li_group"|div class="article")',
                page,
                re.I | re.S,
            )
            if not m:
                return self._bio_bio
            block = m.group(1)
            for bio_m in re.finditer(
                r'<div class="soda.*?\s*<p>\s*(?P<bio>.+?)\s</p>\s*<p><em>- IMDb Mini Biography By:\s*(?P<author>.+?)\s*</em>',
                block,
                re.I | re.S,
            ):
                raw_bio = bio_m.group("bio")
                raw_bio = raw_bio.replace('href="/name/nm', f'href="https://{self._c.imdbsite}/name/nm')
                raw_bio = raw_bio.replace('href="/title/tt', f'href="https://{self._c.imdbsite}/title/tt')
                raw_bio = raw_bio.replace("/search/name", f"https://{self._c.imdbsite}/search/name")
                auth_raw = bio_m.group("author")
                author_line = "Written by " + auth_raw.replace(
                    "/search/name", f"https://{self._c.imdbsite}/search/name"
                )
                am = re.search(r'href="(.+?)"[^>]*>\s*(.*?)\s*</a>', author_line)
                if am:
                    author = {"url": am.group(1), "name": am.group(2)}
                else:
                    author = {"url": "", "name": html_module.unescape(strip_tags_simple(auth_raw)).strip()}
                self._bio_bio.append({"desc": raw_bio, "author": author})
        return self._bio_bio

    def _parparse(self, section: str) -> list[str]:
        page = self._get_page("Bio")
        pos_s = page.find(f'<h4 class="li_group">{section}')
        if pos_s < 0:
            return []
        pos_e = page.find("<h4", pos_s + 1)
        if pos_e < 0:
            pos_e = page.find("</tbody", pos_s + 1)
        block = page[pos_s : pos_e if pos_e > pos_s else pos_s + 1]
        out: list[str] = []
        for m in re.finditer(r'<div class="soda[^>]*>(.*?)</div>', block, re.I | re.S):
            chunk = m.group(1)
            chunk = chunk.replace('href="/name/nm', f'href="https://{self._c.imdbsite}/name/nm')
            chunk = chunk.replace('href="/title/tt', f'href="https://{self._c.imdbsite}/title/tt')
            out.append(chunk)
        return out

    def trivia(self) -> list[str]:
        if self._bio_trivia is None:
            self._bio_trivia = self._parparse("Trivia")
        return self._bio_trivia

    def quotes(self) -> list[str]:
        if self._bio_quotes is None:
            self._bio_quotes = self._parparse("Personal Quotes")
        return self._bio_quotes

    def trademark(self) -> list[str]:
        if self._bio_tm is None:
            self._bio_tm = self._parparse("Trade Mark")
        return self._bio_tm

    def salary(self) -> list[dict[str, Any]]:
        if self._bio_salary is None:
            self._bio_salary = []
            page = self._get_page("Bio")
            pos_s = page.find('<table id="salariesTable"')
            if pos_s < 0:
                return self._bio_salary
            pos_e = page.find("</table", pos_s)
            block = page[pos_s:pos_e]
            for tr in re.finditer(r"<tr.*?>(.*?)</tr>", block, re.I | re.S):
                row = tr.group(1)
                tds = re.findall(r"<td.*?>(.*?)</td>", row, re.I | re.S)
                if len(tds) < 2:
                    continue
                cell_movie, cell_sal = tds[0], tds[1]
                mm = re.search(r'/title/tt(\d{7,8})/">(.*?)</a>\s*\((\d{4})\)', cell_movie)
                if mm:
                    movie = {"imdb": mm.group(1), "name": mm.group(2), "year": mm.group(3)}
                else:
                    movie = {"name": strip_tags_simple(cell_movie)}
                self._bio_salary.append({"movie": movie, "salary": strip_tags_simple(cell_sal)})
        return self._bio_salary

    def pubprints(self) -> list[dict[str, str]]:
        if self._pub_prints is None:
            self._pub_prints = []
            page = self._get_page("Publicity")
            pos_s = page.find('<h4 class="li_group">Print Biographies (')
            if pos_s < 0:
                return self._pub_prints
            pos_e = page.find("</table", pos_s)
            block = page[pos_s:pos_e]
            for td_chunk in re.split(r"<td", block)[1:]:
                m = re.search(
                    r"(.*).\s*<i>(.*)</i>\s*((.*):|)((.*),|)\s*((\d+)\.|)\s*ISBN\s*<a href=\"(.*)\">(.*)</a>",
                    td_chunk,
                    re.I | re.S,
                )
                if m:
                    self._pub_prints.append(
                        {
                            "author": strip_tags_simple(m.group(1)),
                            "title": html_module.unescape(m.group(2)),
                            "place": m.group(4).strip() if m.group(4) else "",
                            "publisher": html_module.unescape(m.group(6).strip()) if m.group(6) else "",
                            "year": m.group(8) or "",
                            "isbn": m.group(10) or "",
                            "url": m.group(9) or "",
                        }
                    )
                else:
                    m2 = re.search(
                        r"(.*).\s*<i>(.*)</i>\s*((.*):|)((.*),|)\s*((\d+)\.)",
                        td_chunk,
                        re.I | re.S,
                    )
                    if m2:
                        self._pub_prints.append(
                            {
                                "author": strip_tags_simple(m2.group(1)),
                                "title": html_module.unescape(m2.group(2)),
                                "place": m2.group(4).strip() if m2.group(4) else "",
                                "publisher": html_module.unescape(m2.group(6).strip()) if m2.group(6) else "",
                                "year": m2.group(8) or "",
                                "isbn": "",
                                "url": "",
                            }
                        )
        return self._pub_prints

    def _parse_pubmovies(self, header: str) -> list[dict[str, str]]:
        page = self._get_page("Publicity")
        pos_s = page.find(f'<h4 class="li_group">{header} (')
        if pos_s < 0:
            return []
        pos_e = page.find("<h4", pos_s + 5)
        skip = len(header) + 9
        block = page[pos_s + skip : pos_e if pos_e > pos_s else pos_s + skip]
        out: list[dict[str, str]] = []
        for part in block.split("<li"):
            mm = re.search(r'href="/title/tt(\d+)/">(.*)</a>\s*(\((\d+)\)|)', part)
            if mm:
                out.append({"imdb": mm.group(1), "name": mm.group(2), "year": mm.group(4) or ""})
        return out

    def pubmovies(self) -> list[dict[str, str]]:
        if self._pub_movies is None:
            self._pub_movies = self._parse_pubmovies("Film Biographies")
        return self._pub_movies

    def pubportraits(self) -> list[dict[str, str]]:
        if self._pub_portraits is None:
            self._pub_portraits = self._parse_pubmovies("Portrayals")
        return self._pub_portraits

    def _parsearticles(self, title: str) -> list[dict[str, Any]]:
        page = self._get_page("Publicity")
        pos_s = page.find(f'<h4 class="li_group">{title} (')
        if pos_s < 0:
            return []
        pos_e = page.find("</table", pos_s)
        block = page[pos_s:pos_e]
        res: list[dict[str, Any]] = []
        for mrow in re.finditer(r"<tr(.*)</tr>", block, re.I | re.S):
            row = mrow.group(1)
            rm = re.search(r"<td.*?>(.*?)</td>.*<td.*?>(.*?)</td>", row, re.I | re.S)
            if not rm:
                continue
            c1, c2 = rm.group(1), rm.group(2)
            dat = re.search(r"(\d{1,2}|)\s*(\S+|)\s*(\d{4}|)", c2, re.I)
            datum: dict[str, str] = {
                "day": "",
                "month": "",
                "mon": "",
                "year": "",
                "full": "",
            }
            rest = c2
            if dat and dat.group(0):
                datum = {
                    "day": dat.group(1) or "",
                    "month": (dat.group(2) or "").strip(),
                    "mon": _month_no((dat.group(2) or "").strip()),
                    "year": (dat.group(3) or "").strip(),
                    "full": dat.group(0).strip(),
                }
                rest = c2[len(dat.group(0)) :].strip()
            auth_m = re.search(r'<a name="author">(.*?)</a>', rest, re.I | re.S)
            author = ""
            if auth_m:
                rest = rest.replace(", by: " + auth_m.group(0), "").strip()
                author = auth_m.group(1)
            res.append(
                {
                    "inturl": "",
                    "name": strip_tags_simple(c1).strip(),
                    "date": datum,
                    "details": rest.strip(),
                    "auturl": "",
                    "author": author,
                }
            )
        return res

    def interviews(self) -> list[dict[str, Any]]:
        if self._pub_interviews is None:
            self._pub_interviews = self._parsearticles("Interviews")
        return self._pub_interviews

    def articles(self) -> list[dict[str, Any]]:
        if self._pub_articles is None:
            self._pub_articles = self._parsearticles("Articles")
        return self._pub_articles

    def pictorials(self) -> list[dict[str, Any]]:
        if self._pub_pictorials is None:
            self._pub_pictorials = self._parsearticles("Pictorials")
        return self._pub_pictorials

    def magcovers(self) -> list[dict[str, Any]]:
        if self._pub_magcovers is None:
            self._pub_magcovers = self._parsearticles("Magazine Covers")
        return self._pub_magcovers

    def set_search_details(self, role: str, mid: str, moviename: str, year: int) -> None:
        self._search_details = {
            "role": role,
            "mid": mid,
            "moviename": moviename,
            "year": year,
        }

    def get_search_details(self) -> dict[str, Any]:
        return dict(self._search_details)

    def real_id(self) -> str | None:
        page = self._get_page("Name")
        m = re.search(r'<meta property="imdb:pageConst" content="nm(\d+)"', page)
        if m:
            return m.group(1)
        return None
