"""Public exceptions for the auteur package."""

from __future__ import annotations

from typing import Literal


class AuteurItemNotFoundError(Exception):
    """Raised when IMDb has no title or name page for the requested id (e.g. HTTP 404)."""

    def __init__(
        self,
        message: str,
        *,
        kind: Literal["title", "person"],
        imdb_id: str,
    ) -> None:
        super().__init__(message)
        self.kind = kind
        self.imdb_id = imdb_id
