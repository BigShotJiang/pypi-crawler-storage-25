"""IMDb client library"""

from .auteur import Auteur
from .auteur_config import AuteurConfig
from .exceptions import AuteurItemNotFoundError
from .lib.imdb_http import (
    ImdbClient,
    ImdbHttpError,
    normalize_person_id,
    normalize_title_id,
    person_page_url,
    title_page_url,
)

__all__ = [
    "Auteur",
    "AuteurConfig",
    "AuteurItemNotFoundError",
    "ImdbClient",
    "ImdbHttpError",
    "normalize_person_id",
    "normalize_title_id",
    "person_page_url",
    "title_page_url",
]
__version__ = "1.0.0"
