from __future__ import annotations

import html as html_module
import json
import os
import re
import urllib.request
from pathlib import Path
from typing import Any, Iterator

import requests
from lxml import html as lhtml

from .auteur_config import AuteurConfig
from .lib.imdb_http import ImdbClient, ImdbHttpError, normalize_title_id, title_page_url
from .lib.title_parser import (
    get_imdbname,
    get_row_cells,
    get_table_rows,
    get_table_rows_cast,
    parse_cast_entries,
    strip_tags,
)

_SCHEMA_TYPE: dict[str, str] = {
    "Movie": "Movie",
    "TVSeries": "TV Series",
    "TVEpisode": "TV Episode",
    "TVSeason": "TV Series",
    "TVMiniSeries": "TV Mini Series",
    "TVMovie": "TV Movie",
    "VideoObject": "Video",
    "VideoGame": "Video Game",
    "Short": "Short",
}

PAGE_URLS: dict[str, str] = {
    "AlternateVersions": "/alternateversions",
    "Awards": "/awards",
    "CrazyCredits": "/crazycredits",
    "Credits": "/fullcredits",
    "Episodes": "/episodes",
    "Goofs": "/goofs",
    "Keywords": "/keywords",
    "Locations": "/locations",
    "OfficialSites": "/officialsites",
    "ParentalGuide": "/parentalguide",
    "Quotes": "/quotes",
    "ReleaseInfo": "/releaseinfo",
    "Soundtrack": "/soundtrack",
    "Technical": "/technical",
    "Title": "/",
    "Trailers": "/videogallery/content_type-trailer",
    "Trivia": "/trivia",
    "VideoSites": "/externalsites",
}

GQL_RUNTIMES_FULL = """
query Runtimes($id: ID!) {
  title(id: $id) {
    runtimes(first: 9999) {
      edges {
        node {
          attributes { text }
          country { id text }
          seconds
        }
      }
    }
  }
}
"""

GQL_RECOMMENDATIONS = """
query Recommendations($id: ID!) {
  title(id: $id) {
    moreLikeThisTitles(first: 12) {
      edges {
        node {
          id
          titleText { text }
          ratingsSummary { aggregateRating }
          primaryImage { url }
        }
      }
    }
  }
}
"""

GQL_ALSOKNOW = """
query AlsoKnow($id: ID!) {
  title(id: $id) {
    akas(first: 9999) {
      edges {
        node {
          country { id text }
          language { text id }
          displayableProperty {
            qualifiersInMarkdownList { plainText }
            value { plainText }
          }
        }
      }
    }
  }
}
"""

GQL_PLOTS = """
query Plots($id: ID!) {
  title(id: $id) {
    plots(first: 9999) {
      edges {
        node {
          author
          plotType
          plotText { plainText }
        }
      }
    }
  }
}
"""

GQL_TAGLINES = """
query Taglines($id: ID!) {
  title(id: $id) {
    taglines(first: 9999) {
      edges {
        node { text }
      }
    }
  }
}
"""

GQL_ALT_VERSIONS = """
query AlternateVersions($id: ID!) {
  title(id: $id) {
    alternateVersions(first: 9999) {
      edges {
        node {
          text { plainText }
        }
      }
    }
  }
}
"""

GQL_RELEASE_DATES = """
query ReleaseDates($id: ID!) {
  title(id: $id) {
    releaseDates(first: 9999) {
      edges {
        node {
          country { id text }
          day
          month
          year
          attributes { text }
        }
      }
    }
  }
}
"""

GQL_COMPANY_CREDITS = """
query CompanyCredits($id: ID!) {
  title(id: $id) {
    companyCredits(first: 9999) {
      edges {
        node {
          attributes { text }
          displayableProperty { value { plainText } }
          countries { text }
          yearsInvolved { year }
          category { id }
          company { id }
        }
      }
    }
  }
}
"""

GQL_CONNECTIONS = """
query Connections($id: ID!, $after: ID) {
  title(id: $id) {
    connections(first: 9999, after: $after) {
      edges {
        node {
          associatedTitle {
            id
            releaseYear { year }
            titleText { text }
          }
          category { id }
          text
        }
      }
      pageInfo { endCursor hasNextPage }
    }
  }
}
"""

GQL_EXTERNAL_LINKS = """
query ExternalLinks($id: ID!, $after: ID) {
  title(id: $id) {
    externalLinks(first: 9999, after: $after) {
      edges {
        node {
          label
          url
          externalLinkCategory { id }
        }
      }
      pageInfo { endCursor hasNextPage }
    }
  }
}
"""


def _iter_ld_nodes(obj: Any) -> Iterator[dict[str, Any]]:
    if obj is None:
        return
    if isinstance(obj, list):
        for o in obj:
            yield from _iter_ld_nodes(o)
        return
    if not isinstance(obj, dict):
        return
    if "@graph" in obj:
        yield from _iter_ld_nodes(obj["@graph"])
        return
    yield obj
    for v in obj.values():
        if isinstance(v, (list, dict)):
            yield from _iter_ld_nodes(v)


def _parse_iso_duration(s: str | None) -> int | None:
    if not s or not isinstance(s, str):
        return None
    m = re.match(r"PT(?:(?P<h>\d+)H)?(?:(?P<m>\d+)M)?", s, re.I)
    if not m:
        return None
    h = int(m.group("h") or 0)
    mi = int(m.group("m") or 0)
    out = h * 60 + mi
    return out or None


def _strip_imdb_page_title(s: str) -> str:
    t = s.strip()
    t = re.sub(r"\s*-\s*IMDb\s*$", "", t, flags=re.I)
    t = re.sub(r"^IMDb\s*-\s*", "", t, flags=re.I)
    return t


def _next_data_props(page: str) -> dict[str, Any]:
    m = re.search(r'<script[^>]+id="__NEXT_DATA__"[^>]*>([\s\S]*?)</script>', page)
    if not m:
        return {}
    try:
        d = json.loads(m.group(1))
        return d.get("props", {}).get("pageProps", {}) or {}
    except json.JSONDecodeError:
        return {}


def _walk_find_genres(obj: Any, out: list[list[str]]) -> None:
    if isinstance(obj, dict):
        if (
            obj.get("__typename") == "Genres"
            and isinstance(obj.get("genres"), list)
            and obj["genres"]
        ):
            first = obj["genres"][0]
            if isinstance(first, dict) and first.get("__typename") == "Genre":
                glist = [g.get("text") for g in obj["genres"] if isinstance(g, dict) and g.get("text")]
                if glist and len(glist) <= 12:
                    out.append([str(x) for x in glist if x])
        for v in obj.values():
            _walk_find_genres(v, out)
    elif isinstance(obj, list):
        for v in obj:
            _walk_find_genres(v, out)


def _genres_from_next_data(page: str) -> list[str]:
    m = re.search(r'<script[^>]+id="__NEXT_DATA__"[^>]*>([\s\S]*?)</script>', page)
    if not m:
        return []
    try:
        data = json.loads(m.group(1))
    except json.JSONDecodeError:
        return []
    found: list[list[str]] = []
    _walk_find_genres(data, found)
    if not found:
        return []
    for cand in found:
        if 1 <= len(cand) <= 12 and any(x in cand for x in ("Action", "Drama", "Comedy", "Horror", "Sci-Fi")):
            return list(cand)
    return list(found[0])


class ImdbTitle:
    TV_EPISODE = "TV Episode"

    def __init__(
        self,
        imdb_id: str,
        config: AuteurConfig | None = None,
        client: ImdbClient | None = None,
        *,
        validate_exists: bool = True,
    ) -> None:
        self._c = config or AuteurConfig()
        self._id = normalize_title_id(imdb_id)
        self._http = client or ImdbClient(self._c)
        self._pages: dict[str, str] = {}
        self._xpath_cache: dict[str, Any] = {}
        self._main_title = ""
        self._main_year: Any = -1
        self._main_endyear: Any = -1
        self._main_movietype = ""
        self._main_yearspan: dict[str, str] | None = None
        self._main_movietypes: list[str] | None = None
        self._ld_raw: Any = None
        self._movieruntimes: list[dict[str, Any]] | None = None
        self._movierecommendations: list[dict[str, Any]] | None = None
        self._akas: list[dict[str, Any]] | None = None
        self._plots_plain: list[str] | None = None
        self._plots_split: list[dict[str, Any]] | None = None
        self._synopsis_wiki = ""
        self._taglines_list: list[str] | None = None
        self._main_tagline = ""
        self._main_plotoutline = ""
        self._main_storyline = ""
        self._main_comment = ""
        self._split_comment: list[Any] | None = None
        self._seasoncount = -1
        self._is_serial: bool | None = None
        self._episode_season: Any = None
        self._episode_episode: Any = None
        self._aspectratio = ""
        self._main_top250 = -1
        self._mpaas: dict[str, Any] | None = None
        self._mpaas_hist: dict[str, list[str]] | None = None
        self._mpaa_justification = ""
        self._credits_director: list[dict[str, Any]] | None = None
        self._credits_cast: list[dict[str, Any]] | None = None
        self._credits_cast_short: list[dict[str, Any]] | None = None
        self._credits_writing: list[dict[str, Any]] | None = None
        self._credits_producer: list[dict[str, Any]] | None = None
        self._credits_cinematographer: list[dict[str, Any]] | None = None
        self._credits_composer: list[dict[str, Any]] | None = None
        self._moviecolors: list[str] | None = None
        self._langs: list[str] | None = None
        self._langs_full: list[dict[str, str]] | None = None
        self._main_keywords: list[str] | None = None
        self._all_keywords: list[str] | None = None
        self._moviequotes: list[str] | None = None
        self._split_moviequotes: list[list[dict[str, Any]]] | None = None
        self._trailers_l: list[Any] | None = None
        self._trivia_l: list[str] | None = None
        self._soundtracks: list[dict[str, str]] | None = None
        self._goofs_l: list[dict[str, str]] | None = None
        self._crazy_credits: list[str] | None = None
        self._movieconnections: dict[str, list[dict[str, Any]]] | None = None
        self._extreviews: list[dict[str, str]] | None = None
        self._release_info: list[dict[str, Any]] | None = None
        self._locations_l: list[str] | None = None
        self._compcred_prod: list[dict[str, str]] | None = None
        self._compcred_dist: list[dict[str, str]] | None = None
        self._compcred_special: list[dict[str, str]] | None = None
        self._compcred_other: list[dict[str, str]] | None = None
        self._parental_guide: dict[str, list[str]] | None = None
        self._official_sites: list[dict[str, str]] | None = None
        self._moviealternateversions: list[str] | None = None
        self._budget: int | None = None
        self._budget_computed = False
        self._filming_dates: dict[str, str] | None = None
        self._filming_dates_computed = False
        self._main_poster = ""
        self._main_poster_thumb = ""

        if validate_exists:
            # ensure an exception is thrown if the item does not exist
            self.title()

    @classmethod
    def from_search_result(
        cls,
        imdb_id: str,
        title: str,
        year: int,
        movietype: str,
        config: AuteurConfig | None = None,
        client: ImdbClient | None = None,
    ) -> ImdbTitle:
        t = cls(imdb_id, config, client, validate_exists=False)
        t._main_title = title
        t._main_year = int(year)
        t._main_movietype = movietype
        return t

    def imdbid(self) -> str:
        return self._id

    @property
    def imdb_id(self) -> str:
        return self._id

    @property
    def imdbsite(self) -> str:
        return self._c.imdbsite

    def main_url(self) -> str:
        return f"https://{self._c.imdbsite}/title/tt{self._id}/"

    def _build_url(self, page: str | None) -> str:
        if page is None or page == "Title":
            return title_page_url(self._id, self._c, "/")
        suf = PAGE_URLS.get(page)
        if suf is None:
            raise ValueError(f"Unknown page {page!r}")
        return title_page_url(self._id, self._c, suf)

    def _get_page(self, page: str = "Title") -> str:
        if page in self._pages:
            return self._pages[page]
        url = self._build_url(page)
        try:
            raw = self._http.get(url)
        except (ImdbHttpError, OSError, requests.RequestException):
            if self._c.throw_http_exceptions:
                raise
            raw = ""
        self._pages[page] = raw
        return raw

    def _xp(self, page: str):
        if page not in self._xpath_cache:
            raw = self._get_page(page)
            self._xpath_cache[page] = lhtml.fromstring(raw)
        return self._xpath_cache[page]

    def _graphql(self, query: str, op: str, variables: dict[str, Any]) -> dict[str, Any]:
        try:
            return self._http.post_json(
                "https://api.graphql.imdb.com/",
                {"operationName": op, "query": query, "variables": variables},
            )
        except (ImdbHttpError, OSError, requests.RequestException):
            return {}

    def _json_ld_main(self) -> dict[str, Any]:
        if self._ld_raw is not None:
            return self._ld_raw if isinstance(self._ld_raw, dict) else {}
        page = self._get_page("Title")
        tree = lhtml.fromstring(page)
        for node in tree.xpath('//script[@type="application/ld+json"]'):
            raw = (node.text or "").strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                continue
            for item in _iter_ld_nodes(data):
                if not isinstance(item, dict):
                    continue
                t = item.get("@type", "")
                ts = t if isinstance(t, list) else [t]
                st = " ".join(map(str, ts))
                if any(x in st for x in ("Movie", "TVSeries", "TVEpisode")):
                    self._ld_raw = item
                    return item
        self._ld_raw = {}
        return {}

    def _title_year(self) -> None:
        if self._main_title != "":
            return
        page = self._get_page("Title")
        im = re.search(
            r"<title>(?:IMDb\s*-\s*)?(?P<ititle>.*?)(?:\s*-\s*IMDb)?</title>",
            page,
            re.I | re.S,
        )
        if not im:
            return
        ititle = _strip_imdb_page_title(im.group("ititle"))
        if re.match(
            r"(?P<title>.*) \((?P<movietype>.*)(?P<year>\d{4}|\?{4})((&nbsp;|–)(?P<endyear>\d{4}|)).*\)(.*)",
            ititle,
        ):
            m = re.match(
                r"(?P<title>.*) \((?P<movietype>.*)(?P<year>\d{4}|\?{4})((?:&nbsp;|–)(?P<endyear>\d{4}|))?.*\)(.*)",
                ititle,
            )
            if m:
                self._main_movietype = m.group("movietype").strip()
                self._main_year = m.group("year")
                ey = m.groupdict().get("endyear") or ""
                self._main_endyear = ey if ey else "0"
                self._main_title = html_module.unescape(m.group("title").strip())
        elif re.match(r"(?P<title>.*) \((?P<movietype>.*)(?P<year>\d{4}|\?{4}).*\)(.*)", ititle):
            m = re.match(r"(?P<title>.*) \((?P<movietype>.*)(?P<year>\d{4}|\?{4}).*\)(.*)", ititle)
            if m:
                self._main_movietype = m.group("movietype").strip()
                self._main_year = m.group("year")
                self._main_endyear = m.group("year")
                self._main_title = html_module.unescape(m.group("title").strip())
        elif re.match(r"(?P<title>.*) \((?P<movietype>.*)\)(.*)", ititle):
            m = re.match(r"(?P<title>.*) \((?P<movietype>.*)\)(.*)", ititle)
            if m:
                self._main_movietype = m.group("movietype").strip()
                self._main_title = html_module.unescape(m.group("title").strip())
                self._main_year = "0"
                self._main_endyear = "0"
        if self._main_year == "????":
            self._main_year = ""

    def title(self) -> str:
        if self._main_title == "":
            self._title_year()
        if self._main_title != "":
            return self._main_title
        ld = self._json_ld_main()
        n = ld.get("name")
        if isinstance(n, str) and n:
            return n
        raise ImdbHttpError("Could not read title")

    def orig_title(self) -> str | None:
        ld = self._json_ld_main()
        original = ld.get("name")
        alt = ld.get("alternateName")
        if original and alt and original != alt:
            return str(original)
        return None

    def year(self) -> Any:
        if self._main_year == -1:
            self._title_year()
        return self._main_year

    def endyear(self) -> Any:
        if self._main_endyear == -1:
            self._title_year()
        return self._main_endyear

    def yearspan(self) -> dict[str, str]:
        if self._main_yearspan is None:
            self._main_yearspan = {"start": str(self.year()), "end": str(self.endyear())}
        return dict(self._main_yearspan)

    def movieTypes(self) -> list[str]:
        if self._main_movietypes is None:
            self._get_page("Title")
            # First `<title>` only — `(.*)</title>` greedily spans to the last `</title>` on the page.
            m = re.search(r"<title>([^<]*)</title>", self._pages["Title"], re.I)
            self._main_movietypes = []
            if m:
                for par in re.findall(r"\(([^)]*)\)", m.group(1)):
                    if not re.match(r"^\d{4}$", par.strip()):
                        self._main_movietypes.append(par.strip())
        return list(self._main_movietypes or [])

    def movietype(self) -> str:
        if self._main_movietype == "":
            if self._main_title == "":
                self._title_year()
            if self._main_movietype:
                return self._main_movietype
            page = self._get_page("Title")
            if 'title="See more release dates" >TV Special' in page:
                self._main_movietype = "TV Special"
            if not self._main_movietype:
                self._main_movietype = "Movie"
        return self._main_movietype

    def runtime(self) -> int | None:
        ld = self._json_ld_main()
        dur = ld.get("duration") or ld.get("timeRequired")
        if isinstance(dur, str):
            r = _parse_iso_duration(dur)
            if r:
                return r
        rt = self.runtimes()
        if rt and rt[0].get("time"):
            return int(rt[0]["time"])
        return None

    def runtimes(self) -> list[dict[str, Any]]:
        if self._movieruntimes is None:
            j = self._graphql(GQL_RUNTIMES_FULL, "Runtimes", {"id": f"tt{self._id}"})
            edges = ((j.get("data") or {}).get("title") or {}).get("runtimes", {}).get("edges") or []
            self._movieruntimes = []
            for e in edges:
                n = e.get("node") or {}
                secs = n.get("seconds") or 0
                attrs = [a.get("text") for a in (n.get("attributes") or []) if isinstance(a, dict)]
                c = n.get("country") or {}
                self._movieruntimes.append(
                    {
                        "time": int(secs // 60) if secs else 0,
                        "annotations": [x for x in attrs if x],
                        "country": c.get("text"),
                        "countryCode": c.get("id"),
                    }
                )
        return list(self._movieruntimes)

    def aspect_ratio(self) -> str:
        if self._aspectratio == "":
            tree = self._xp("Title")
            ext = tree.xpath(
                "//li[@data-testid='title-techspec_aspectratio']//span[contains(@class,'ipc-metadata-list-item__list-content-item')]/text()"
            )
            if ext:
                self._aspectratio = (ext[0] or "").strip()
        return self._aspectratio

    def rating(self) -> Any:
        ld = self._json_ld_main()
        ag = ld.get("aggregateRating") or {}
        return ag.get("ratingValue", "")

    def votes(self) -> int:
        ld = self._json_ld_main()
        ag = ld.get("aggregateRating") or {}
        return int(ag.get("ratingCount") or 0)

    def metacriticRating(self) -> int | None:
        tree = self._xp("Title")
        nodes = tree.xpath("//span[contains(@class,'metacritic-score-box')]/text()")
        if nodes:
            try:
                return int(str(nodes[0]).strip())
            except ValueError:
                return None
        return None

    def metacriticNumReviews(self) -> None:
        return None

    def comment(self) -> str:
        if self._main_comment == "":
            tree = self._xp("Title")
            rev = tree.xpath("//div[@data-testid='review-overflow']")
            if rev:
                self._main_comment = (rev[0].text_content() or "").strip()
        return self._main_comment

    def comment_split(self) -> list[Any]:
        if self._split_comment is None:
            self._split_comment = []
            comm = self.comment()
            if comm and re.search(
                r"<strong[^>]*>(.*?)</strong>.*?<div class=\"comment-meta\">\s*(.*?)\s*\|\s*by\s*(.*?</a>).*?<p[^>]*>(.*?)\s*</div",
                comm,
                re.I | re.S,
            ):
                m = re.search(
                    r"<strong[^>]*>(.*?)</strong>.*?<div class=\"comment-meta\">\s*(.*?)\s*\|\s*by\s*(.*?</a>).*?<p[^>]*>(.*?)\s*</div",
                    comm,
                    re.I | re.S,
                )
                if m:
                    au = re.search(r'href="(.*?)"[^>]*><span[^>]*>(.*)</span', m.group(3), re.I)
                    self._split_comment = [
                        {
                            "title": m.group(1),
                            "date": m.group(2),
                            "author": {"url": au.group(1), "name": au.group(2)} if au else {"url": "", "name": ""},
                            "comment": strip_tags(m.group(4)).strip(),
                        }
                    ]
        return list(self._split_comment or [])

    def movie_recommendations(self) -> list[dict[str, Any]]:
        if self._movierecommendations is None:
            j = self._graphql(GQL_RECOMMENDATIONS, "Recommendations", {"id": f"tt{self._id}"})
            edges = (
                ((j.get("data") or {}).get("title") or {}).get("moreLikeThisTitles") or {}
            ).get("edges") or []
            self._movierecommendations = []
            for e in edges:
                n = e.get("node") or {}
                tid = (n.get("id") or "").replace("tt", "")
                tit = (n.get("titleText") or {}).get("text")
                rat = (n.get("ratingsSummary") or {}).get("aggregateRating")
                img = (n.get("primaryImage") or {}).get("url")
                self._movierecommendations.append(
                    {"title": tit, "imdbid": tid, "rating": rat, "img": img or ""}
                )
        return list(self._movierecommendations)

    def keywords(self) -> list[str]:
        if self._main_keywords is None:
            ld = self._json_ld_main()
            kw = ld.get("keywords")
            if isinstance(kw, str) and kw.strip():
                self._main_keywords = [x.strip() for x in kw.split(",") if x.strip()]
            else:
                self._main_keywords = []
        return list(self._main_keywords)

    def language(self) -> str:
        if self._langs is None:
            self.languages()
        return self._langs[0] if self._langs else ""

    def languages(self) -> list[str]:
        if self._langs is None:
            page = self._get_page("Title")
            self._langs = []
            self._langs_full = []
            for m in re.finditer(
                r'href="/search/title\?.+?primary_language=([^&]*)[^>]*>\s*(.*?)\s*</a>(\s+\((.*?)\)|)',
                page,
                re.M,
            ):
                self._langs.append(m.group(2).strip())
                self._langs_full.append(
                    {"name": m.group(2).strip(), "code": m.group(1), "comment": (m.group(4) or "").strip()}
                )
        return list(self._langs)

    def languages_detailed(self) -> list[dict[str, str]]:
        if self._langs_full is None:
            self.languages()
        return list(self._langs_full or [])

    def genre(self) -> str:
        g = self.genres()
        return g[0] if g else ""

    def genres(self) -> list[str]:
        page = self._get_page("Title")
        g = _genres_from_next_data(page)
        if g:
            return g
        tree = lhtml.fromstring(page)
        a = tree.xpath("//li[@data-testid='storyline-genres']//li[contains(@class,'ipc-inline-list__item')]/a/text()")
        out = []
        for t in a:
            s = (t or "").strip().replace("&amp;", "&")
            if s and s not in out:
                out.append(s)
        return out

    def colors(self) -> list[str]:
        if self._moviecolors is None:
            page = self._get_page("Title")
            self._moviecolors = re.findall(
                r'/search/title/?\?colors=[^>]+?>\s?(.*?)</a',
                page,
            )
        return list(self._moviecolors)

    def creator(self) -> list[dict[str, str]]:
        ld = self._json_ld_main()
        if ld.get("@type") != "TVSeries":
            return []
        cr = ld.get("creator")
        if not cr:
            return []
        rows = cr if isinstance(cr, list) else [cr]
        out = []
        for c in rows:
            if isinstance(c, dict) and c.get("@type") == "Person":
                url = c.get("url") or ""
                m = re.search(r"name/nm(\d+)", url)
                out.append({"name": c.get("name") or "", "imdb": m.group(1) if m else ""})
        return out

    def taglines(self) -> list[str]:
        if self._taglines_list is None:
            j = self._graphql(GQL_TAGLINES, "Taglines", {"id": f"tt{self._id}"})
            edges = (((j.get("data") or {}).get("title") or {}).get("taglines") or {}).get("edges") or []
            self._taglines_list = []
            for e in edges:
                t = (e.get("node") or {}).get("text")
                if t:
                    self._taglines_list.append(str(t))
        return list(self._taglines_list)

    def tagline(self) -> str:
        if self._main_tagline == "":
            tls = self.taglines()
            self._main_tagline = tls[0] if tls else ""
        return self._main_tagline

    def seasons(self) -> int:
        if self._seasoncount == -1:
            tree = self._xp("Title")
            opts = tree.xpath('//select[@id="browse-episodes-season"]//option/@value')
            self._seasoncount = 0
            for v in opts:
                try:
                    iv = int(v)
                    if iv > self._seasoncount:
                        self._seasoncount = iv
                except ValueError:
                    pass
            if self._seasoncount == 0 and re.search(
                r'href="/title/tt\d{7,8}/episodes\?season=\d+',
                self._get_page("Title"),
                re.I,
            ):
                self._seasoncount = 1
        return self._seasoncount

    def is_serial(self) -> bool:
        if self._is_serial is not None:
            return self._is_serial
        self._is_serial = bool(
            re.search(r'href="/title/tt\d{7,8}/episodes\?', self._get_page("Title"), re.I)
        )
        return self._is_serial

    def isEpisode(self) -> bool:
        return self.movietype() == self.TV_EPISODE

    def episodeTitle(self) -> str:
        if not self.isEpisode():
            return ""
        return str(self._json_ld_main().get("name") or "")

    def _populate_episode_season_episode(self) -> None:
        if self._episode_season is not None and self._episode_episode is not None:
            return
        tree = self._xp("Title")
        sec = tree.xpath("//div[@data-testid='hero-subnav-bar-season-episode-numbers-section']")
        if sec:
            txt = sec[0].text_content() or ""
            m = re.search(r"S(\d+).+E(\d+)", txt)
            if m:
                self._episode_season = int(m.group(1))
                self._episode_episode = int(m.group(2))
                return
        self._episode_season = 0
        self._episode_episode = 0

    def episodeSeason(self) -> int:
        if not self.isEpisode():
            return 0
        self._populate_episode_season_episode()
        return int(self._episode_season or 0)

    def episodeEpisode(self) -> int:
        if not self.isEpisode():
            return 0
        self._populate_episode_season_episode()
        return int(self._episode_episode or 0)

    def episodeAirDate(self) -> str:
        if not self.isEpisode():
            return ""
        dp = self._json_ld_main().get("datePublished")
        return str(dp or "")

    def get_episode_details(self) -> dict[str, Any] | list[Any]:
        if not self.isEpisode():
            return []
        tree = self._xp("Title")
        el = tree.xpath("//a[@data-testid='hero-title-block__series-link']")
        if not el:
            return {}
        href = el[0].get("href") or ""
        m = re.search(r"(?:nm|tt)(\d{7,8})", href)
        if not m:
            return {}
        return {
            "imdbid": m.group(1),
            "seriestitle": (el[0].text_content() or "").strip(),
            "episodetitle": self.episodeTitle(),
            "season": self.episodeSeason(),
            "episode": self.episodeEpisode(),
            "airdate": self.episodeAirDate(),
        }

    def plotoutline(self, fallback: bool = False) -> str:
        if self._main_plotoutline == "":
            ld = self._json_ld_main()
            if ld.get("description"):
                self._main_plotoutline = html_module.unescape(str(ld["description"]))
            else:
                page = self._get_page("Title")
                m = re.search(r'class="summary_text">\s*(.*?)\s*</div>', page, re.I | re.S)
                if m:
                    self._main_plotoutline = strip_tags(m.group(1)).strip()
                elif fallback:
                    self._main_plotoutline = self.storyline()
        s = self._main_plotoutline
        s = re.sub(
            r'\s*<a href="/title/tt\d{7,8}/(plotsummary|synopsis)[^>]*>See full (summary|synopsis).*$',
            "",
            s,
            flags=re.I,
        )
        s = re.sub(
            r'<a href="[^"]+"\s+>Add a Plot</a>&nbsp;&raquo;',
            "",
            s,
        )
        return s

    def _plot_edges(self) -> list[dict[str, Any]]:
        j = self._graphql(GQL_PLOTS, "Plots", {"id": f"tt{self._id}"})
        return (((j.get("data") or {}).get("title") or {}).get("plots") or {}).get("edges") or []

    def plot(self) -> list[str]:
        if self._plots_plain is None:
            self._plots_plain = []
            for e in self._plot_edges():
                n = e.get("node") or {}
                if n.get("plotType") == "SYNOPSIS":
                    continue
                pt = ((n.get("plotText") or {}).get("plainText")) or ""
                if pt:
                    self._plots_plain.append(pt)
        return list(self._plots_plain)

    def plot_split(self) -> list[dict[str, Any]]:
        if self._plots_split is None:
            self._plots_split = []
            for e in self._plot_edges():
                n = e.get("node") or {}
                if n.get("plotType") == "SYNOPSIS":
                    continue
                auth = n.get("author") or ""
                pt = ((n.get("plotText") or {}).get("plainText")) or ""
                url = (
                    f"https://www.imdb.com/search/title?plot_author={auth}&view=simple&sort=alpha&ref_=ttpl_pl_1"
                    if auth
                    else ""
                )
                self._plots_split.append({"plot": pt, "author": {"name": auth, "url": url}})
        return list(self._plots_split)

    def synopsis(self) -> str:
        if self._synopsis_wiki == "":
            for e in self._plot_edges():
                n = e.get("node") or {}
                if n.get("plotType") == "SYNOPSIS":
                    self._synopsis_wiki = ((n.get("plotText") or {}).get("plainText")) or ""
                    break
        return self._synopsis_wiki

    def storyline(self) -> str:
        if self._main_storyline == "":
            pl = self.plot()
            if not pl:
                return ""
            story = pl[1] if len(pl) >= 2 else pl[0]
            story = re.sub(r"\n-\n<a[^>]+>.*?</a>", "", story, flags=re.I | re.S)
            self._main_storyline = strip_tags(story).strip()
        return self._main_storyline

    def _populate_poster(self) -> None:
        ld = self._json_ld_main()
        if ld.get("image"):
            self._main_poster = str(ld["image"])
        page = self._get_page("Title")
        m = re.search(r'<img [^>]+title="[^"]+Poster"[^>]+src="([^"]+)"', page, re.I | re.S)
        if m:
            self._main_poster_thumb = m.group(1)
        else:
            tree = self._xp("Title")
            th = tree.xpath(
                "//div[contains(@class,'ipc-poster') and contains(@data-testid,'hero-media__poster')]//img/@src"
            )
            if th:
                self._main_poster_thumb = th[0]

    def photo(self, thumb: bool = True) -> str | bool:
        if self._main_poster == "":
            self._populate_poster()
        if not thumb and not self._main_poster:
            return False
        if thumb and not self._main_poster_thumb:
            return False
        return self._main_poster_thumb if thumb else self._main_poster

    def savephoto(self, path: str, thumb: bool = True) -> bool:
        url = self.photo(thumb)
        if not url or not isinstance(url, str):
            return False
        try:
            req = urllib.request.Request(url, headers={"User-Agent": self._c.user_agent()})
            with urllib.request.urlopen(req, timeout=30) as r:
                data = r.read()
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            with open(path, "wb") as f:
                f.write(data)
            return True
        except OSError:
            return False

    def photo_localurl(self, thumb: bool = True) -> str | bool:
        pd = Path(str(self._c.photodir))
        ext = "" if thumb else "_big"
        if not pd.is_dir():
            return False
        path = pd / f"{self._id}{ext}.jpg"
        pr = str(self._c.photoroot).rstrip("/") + "/"
        if path.is_file():
            return pr + f"{self._id}{ext}.jpg"
        if not os.access(str(pd), os.W_OK):
            return False
        if self.savephoto(str(path), thumb):
            return pr + f"{self._id}{ext}.jpg"
        return False

    def country(self) -> list[str]:
        page = self._get_page("Title")
        m = re.findall(r'/search/title/?\?country_of_origin=[^>]+?>(.*?)<', page)
        if m:
            return [x.strip() for x in m]
        tree = lhtml.fromstring(page)
        sec = tree.xpath('//*[@data-testid="title-details-origin"]')
        if sec:
            return [x.strip() for x in sec[0].xpath(".//a/text()") if x.strip()]
        return []

    def alsoknow(self) -> list[dict[str, Any]]:
        if self._akas is None:
            j = self._graphql(GQL_ALSOKNOW, "AlsoKnow", {"id": f"tt{self._id}"})
            edges = (((j.get("data") or {}).get("title") or {}).get("akas") or {}).get("edges") or []
            self._akas = []
            ot = self.orig_title()
            if ot:
                self._akas.append(
                    {
                        "title": ot,
                        "country": "",
                        "countryCode": None,
                        "comments": ["original title"],
                        "comment": "original title",
                        "language": "",
                        "languageCode": None,
                    }
                )
            for e in edges:
                n = e.get("node") or {}
                qual = n.get("displayableProperty") or {}
                quals = qual.get("qualifiersInMarkdownList") or []
                qtext = [q.get("plainText") for q in quals if isinstance(q, dict) and q.get("plainText")]
                val = ((qual.get("value") or {}).get("plainText")) or ""
                co = n.get("country") or {}
                lang = n.get("language") or {}
                self._akas.append(
                    {
                        "title": val,
                        "country": co.get("text") or "",
                        "countryCode": co.get("id"),
                        "comments": qtext,
                        "comment": ", ".join(qtext),
                        "language": lang.get("text") or "",
                        "languageCode": lang.get("id"),
                    }
                )
        return list(self._akas)

    def sound(self) -> list[str]:
        page = self._get_page("Title")
        return re.findall(r'/search/title/?\?sound_mixes=[^>]+>\s*(.*?)</', page)

    def mpaa(self, ratings: bool = False) -> dict[str, Any]:
        if self._mpaas is None:
            self._mpaas = {}
            tree = self._xp("ParentalGuide")
            cells = tree.xpath('//section[@id="certificates"]//li[contains(@class,"ipl-inline-list__item")]')
            for cell in cells:
                a = cell.xpath(".//a")
                if not a:
                    continue
                txt = (a[0].text_content() or "").strip()
                mp = txt.split(":", 1)
                country = mp[0].strip()
                rating = mp[1].strip() if len(mp) > 1 else ""
                if ratings:
                    self._mpaas.setdefault(country, [])
                    if isinstance(self._mpaas[country], list):
                        self._mpaas[country].append(rating)
                else:
                    self._mpaas[country] = rating
        return dict(self._mpaas)

    def mpaa_hist(self) -> dict[str, list[str]]:
        if self._mpaas_hist is None:
            page = self._get_page("ParentalGuide")
            self._mpaas_hist = {}
            for m in re.finditer(r'/search/title\?certificates=[^>]*>\s*(.*?):(.*?)<', page):
                c = m.group(1).strip()
                self._mpaas_hist.setdefault(c, []).append(m.group(2).strip())
        return dict(self._mpaas_hist)

    def mpaa_reason(self) -> str:
        if self._mpaa_justification == "":
            page = self._get_page("ParentalGuide")
            m = re.search(
                r'id="mpaa-rating"\s*>\s*<td[^>]*>.*</td>\s*<td[^>]*>(.*)</td>',
                page,
                re.I | re.S,
            )
            if m:
                self._mpaa_justification = strip_tags(m.group(1)).strip()
        return self._mpaa_justification

    def top250(self) -> int:
        if self._main_top250 == -1:
            tree = self._xp("Title")
            nodes = tree.xpath("//a[@data-testid='award_top-rated']/text()")
            self._main_top250 = 0
            if nodes:
                mm = re.search(r"#(\d+)", nodes[0])
                if mm:
                    self._main_top250 = int(mm.group(1))
        return self._main_top250

    def director(self) -> list[dict[str, Any]]:
        if self._credits_director is None:
            page = self._get_page("Credits")
            rows = get_table_rows(page, "Directed by") or get_table_rows(page, "Series Directed by")
            self._credits_director = []
            for row in rows:
                cells = get_row_cells(row)
                if not cells:
                    continue
                role = None
                if len(cells) > 2 and cells[2]:
                    role = strip_tags(cells[2]).strip() or None
                self._credits_director.append(
                    {"imdb": get_imdbname(cells[0]), "name": strip_tags(cells[0]).strip(), "role": role}
                )
        return list(self._credits_director)

    def actor_stars(self) -> list[dict[str, str]]:
        ld = self._json_ld_main()
        act = ld.get("actor")
        if not act:
            return []
        actors = act if isinstance(act, list) else [act]
        out = []
        for a in actors:
            if not isinstance(a, dict):
                continue
            url = a.get("url") or ""
            m = re.search(r"/name/nm(\d+)/", url)
            out.append({"imdb": m.group(1) if m else "", "name": str(a.get("name") or "")})
        return out

    def cast(self, short: bool = False) -> list[dict[str, Any]]:
        if short:
            return self._cast_short()
        if self._credits_cast is None:
            page = self._get_page("Credits")
            cast_rows = get_table_rows_cast(page)
            self._credits_cast = parse_cast_entries(cast_rows)
        return list(self._credits_cast)

    def _cast_short(self) -> list[dict[str, Any]]:
        if self._credits_cast_short is None:
            tree = self._xp("Title")
            nodes = tree.xpath("//div[@data-testid='title-cast-item']")
            self._credits_cast_short = []
            for node in nodes:
                row: dict[str, Any] = {
                    "imdb": None,
                    "name": None,
                    "name_alias": None,
                    "credited": True,
                    "role": None,
                    "role_episodes": None,
                    "role_start_year": None,
                    "role_end_year": None,
                    "role_other": [],
                    "thumb": "",
                    "photo": "",
                }
                an = node.xpath(".//a[@data-testid='title-cast-item__actor']")
                if not an:
                    continue
                href = an[0].get("href") or ""
                m = re.search(r"/name/nm(\d+)", href)
                row["imdb"] = m.group(1) if m else None
                row["name"] = (an[0].text_content() or "").strip()
                if not row["name"]:
                    continue
                rl = node.xpath(".//a[@data-testid='cast-item-characters-link']/span[1]/text()")
                if rl:
                    row["role"] = rl[0].strip()
                img = node.xpath(".//img[@class='ipc-image']/@src")
                if img:
                    row["thumb"] = img[0]
                    if "._V1" in row["thumb"]:
                        row["photo"] = re.sub(r"\._V1_.+?(\.\w+)$", r"\1", row["thumb"])
                self._credits_cast_short.append(row)
        return list(self._credits_cast_short)

    def writing(self) -> list[dict[str, Any]]:
        if self._credits_writing is None:
            page = self._get_page("Credits")
            rows = get_table_rows(page, "Writing Credits") or get_table_rows(page, "Series Writing Credits")
            self._credits_writing = []
            if not rows:
                return list(self._credits_writing)
            for row in rows:
                wrt: dict[str, Any] = {}
                m = re.search(r'<a\s+href="/name/nm(\d+)/[^>]*>\s*(.+)\s*</a>', row, re.I | re.S)
                if m:
                    wrt["imdb"] = m.group(1)
                    wrt["name"] = strip_tags(m.group(2)).strip()
                elif re.search(r'<td\s+class="name">(.+?)</td', row, re.I | re.S):
                    mm = re.search(r'<td\s+class="name">(.+?)</td', row, re.I | re.S)
                    wrt["imdb"] = ""
                    wrt["name"] = strip_tags(mm.group(1)).strip()
                else:
                    continue
                cr = re.search(r'<td\s+class="credit"\s*>\s*(.+?)\s*</td>', row, re.I | re.S)
                wrt["role"] = strip_tags(cr.group(1)).strip() if cr else None
                self._credits_writing.append(wrt)
        return list(self._credits_writing or [])

    def producer(self) -> list[dict[str, Any]]:
        if self._credits_producer is None:
            page = self._get_page("Credits")
            rows = get_table_rows(page, "Produced by") or get_table_rows(page, "Series Produced by")
            self._credits_producer = []
            for row in rows:
                cells = get_row_cells(row)
                if len(cells) <= 2:
                    continue
                role = strip_tags(cells[2]).strip() if len(cells) > 2 else None
                if role:
                    role = re.sub(r" \(as .+\)$", "", role)
                self._credits_producer.append(
                    {"imdb": get_imdbname(cells[0]), "name": strip_tags(cells[0]).strip(), "role": role or None}
                )
        return list(self._credits_producer)

    def cinematographer(self) -> list[dict[str, Any]]:
        if self._credits_cinematographer is None:
            page = self._get_page("Credits")
            rows = get_table_rows(page, "Cinematography by")
            self._credits_cinematographer = []
            for row in rows:
                cine: dict[str, Any] = {}
                m = re.search(r'<a\s+href="/name/nm(\d+)/[^>]*>\s*(.+)\s*</a>', row, re.I | re.S)
                if m:
                    cine["imdb"] = m.group(1)
                    cine["name"] = strip_tags(m.group(2)).strip()
                elif re.search(r'<td\s+class="name">(.+?)</td', row, re.I | re.S):
                    mm = re.search(r'<td\s+class="name">(.+?)</td', row, re.I | re.S)
                    cine["imdb"] = ""
                    cine["name"] = strip_tags(mm.group(1)).strip()
                else:
                    continue
                cr = re.search(r'<td\s+class="credit"\s*>\s*(.+?)\s*</td>', row, re.I | re.S)
                cine["role"] = strip_tags(cr.group(1)).strip() if cr else None
                self._credits_cinematographer.append(cine)
        return list(self._credits_cinematographer)

    def composer(self) -> list[dict[str, Any]]:
        if self._credits_composer is None:
            page = self._get_page("Credits")
            rows = get_table_rows(page, "Music by") or get_table_rows(page, "Series Music by")
            self._credits_composer = []
            for row in rows:
                comp: dict[str, Any] = {}
                m = re.search(r'<a\s+href="/name/nm(\d+)/[^>]*>\s*(.+)\s*</a>', row, re.I | re.S)
                if m:
                    comp["imdb"] = m.group(1)
                    comp["name"] = strip_tags(m.group(2)).strip()
                elif re.search(r'<td\s+class="name">(.+?)</td', row, re.I | re.S):
                    mm = re.search(r'<td\s+class="name">(.+?)</td', row, re.I | re.S)
                    comp["imdb"] = ""
                    comp["name"] = strip_tags(mm.group(1)).strip()
                else:
                    continue
                cr = re.search(r'<td\s+class="credit"\s*>\s*(.+?)\s*</td>', row, re.I | re.S)
                comp["role"] = strip_tags(cr.group(1)).strip() if cr else None
                self._credits_composer.append(comp)
        return list(self._credits_composer)

    def crazy_credits(self) -> list[str]:
        if self._crazy_credits is None:
            page = self._get_page("CrazyCredits")
            self._crazy_credits = []
            for m in re.finditer(r'<p class="crazy-credit-text">\s*(.*?)\s*</p>', page, re.I | re.S):
                self._crazy_credits.append(
                    re.sub(r"[\r\n]", " ", strip_tags(html_module.unescape(m.group(1))).strip())
                )
        return list(self._crazy_credits)

    def episodes(self) -> list[Any] | dict[str, Any]:
        if not (self.is_serial() or self.isEpisode()):
            return []
        return {}

    def goofs(self) -> list[dict[str, str]]:
        if self._goofs_l is None:
            tree = self._xp("Goofs")
            self._goofs_l = []
            spans = tree.xpath("//h3[@class='ipc-title__text']//span")
            ids: dict[str, str] = {}
            for sp in spans:
                i = sp.get("id")
                if i:
                    ids[i] = (sp.text_content() or "").strip()
            for sid, title in sorted(ids.items()):
                cells = tree.xpath(f"//div[@data-testid='sub-section-{sid}']//div[@class='ipc-html-content-inner-div']")
                for c in cells:
                    self._goofs_l.append(
                        {
                            "type": title,
                            "content": (c.text_content() or "").strip().replace('href="/', f'href="https://{self._c.imdbsite}/'),
                        }
                    )
        return list(self._goofs_l)

    def quotes(self) -> list[str]:
        if self._moviequotes is None:
            page = self._get_page("Quotes").replace("\n", " ")
            self._moviequotes = []
            for m in re.finditer(r'<div class="ipc-html-content-inner-div">\s*(.*?)\s*</div>', page, re.I | re.S):
                q = m.group(1)
                q = re.sub(r'<span class="linksoda".+?</span>', "", q, flags=re.I | re.S)
                q = q.replace('href="/name/', f'href="https://{self._c.imdbsite}/name/')
                self._moviequotes.append(q)
        return list(self._moviequotes)

    def quotes_split(self) -> list[list[dict[str, Any]]]:
        if self._split_moviequotes is None:
            if not self._moviequotes:
                self.quotes()
            self._split_moviequotes = []
            for block in self._moviequotes or []:
                chunk: list[dict[str, Any]] = []
                for lm in re.finditer(r"<li>\s*(.*?)\s*</li>", block, re.I | re.S):
                    quote = lm.group(1)
                    mm = re.search(r'href="([^"]*)"\s*>(.*?)</a>:(.*)', quote, re.S)
                    if mm:
                        chunk.append(
                            {
                                "quote": strip_tags(mm.group(3)).strip(),
                                "character": {"url": mm.group(1), "name": mm.group(2)},
                            }
                        )
                    else:
                        chunk.append({"quote": strip_tags(quote).strip(), "character": {"url": "", "name": ""}})
                self._split_moviequotes.append(chunk)
        return list(self._split_moviequotes)

    def trailers(self, full: bool = False) -> list[Any]:
        if self._trailers_l is None:
            page = self._get_page("Trailers")
            self._trailers_l = []
            idx = page.find('<div class="search-results"><ol>')
            if idx != -1:
                end = page.find("</ol>", idx)
                if end != -1:
                    block = page[idx:end]
                    doc = lhtml.fromstring(block)
                    for li in doc.xpath("//li"):
                        links = li.xpath(".//a")
                        if len(links) < 2:
                            continue
                        title_node = links[1]
                        tit = title_node.text_content() or ""
                        url = "https://" + self._c.imdbsite + (title_node.get("href") or "")
                        imgs = li.xpath(".//img/@loadlate")
                        image_url = imgs[0] if imgs else ""
                        res = "HD" if "HDIcon" in image_url else "SD"
                        if full:
                            self._trailers_l.append(
                                {"title": tit, "url": url, "resolution": res, "lang": "", "restful_url": ""}
                            )
                        else:
                            self._trailers_l.append(url)
        return list(self._trailers_l)

    def soundclipsites(self) -> list[dict[str, str]]:
        return self._parse_videosites_segment("soundclips")

    def photosites(self) -> list[dict[str, str]]:
        return self._parse_videosites_segment("photo")

    def miscsites(self) -> list[dict[str, str]]:
        return self._parse_videosites_segment("misc")

    def videosites(self) -> list[dict[str, str]]:
        return self._parse_videosites_segment("video")

    def _parse_videosites_segment(self, kind: str) -> list[dict[str, str]]:
        page = self._get_page("VideoSites")
        out: list[dict[str, str]] = []
        if kind == "soundclips":
            title = "Sound Clips"
        elif kind == "photo":
            title = "Photographs"
        elif kind == "misc":
            title = "Miscellaneous Sites"
        else:
            title = "Video Clips"
        m = re.search(
            rf"<h4 class=\"li_group\">{re.escape(title)}\s*</h4>\s*(.+?)<(h4|div)",
            page,
            re.I | re.S,
        )
        if not m:
            return []
        part = m.group(1)
        for lm in re.finditer(r"<li>(.+?)</li>", part, re.I | re.S):
            li = lm.group(1)
            em = re.search(
                r'<a .*href="(?P<url>.+?)".*?>(?P<site>.*?) - (?P<desc>.*) \((?P<type>.*?)\)</a>',
                li,
                re.S,
            )
            if em:
                out.append(
                    {
                        "site": strip_tags(em.group("site")).strip(),
                        "url": em.group("url"),
                        "type": em.group("type"),
                        "desc": strip_tags(em.group("desc")).strip(),
                    }
                )
        return out

    def trivia(self, spoil: bool = False) -> list[str]:
        if self._trivia_l is None:
            page = self._get_page("Trivia").replace("\n", " ")
            self._trivia_l = []
            if not spoil:
                for m in re.finditer(r'<div class="ipc-html-content-inner-div">\s*(.*?)\s*</div>', page, re.I | re.S):
                    self._trivia_l.append(
                        m.group(1).replace('href="/name/', f'href="https://{self._c.imdbsite}/name/')
                    )
        return [] if spoil else list(self._trivia_l or [])

    def soundtrack(self) -> list[dict[str, str]]:
        if self._soundtracks is None:
            page = self._get_page("Soundtrack")
            self._soundtracks = []
            for m in re.finditer(
                r'class="soundTrack soda (?:odd|even)"\s*>\s*(?P<title>.+?)<br\s*/>(?P<desc>.+?)</div>',
                page,
                re.I | re.S,
            ):
                self._soundtracks.append(
                    {
                        "soundtrack": m.group("title").strip(),
                        "credits": re.sub(r"\s*\n\s*", "\n", strip_tags(m.group("desc")).strip()),
                        "credits_raw": m.group("desc").strip(),
                    }
                )
        return list(self._soundtracks)

    def movieconnection(self) -> dict[str, list[dict[str, Any]]]:
        if self._movieconnections is None:
            cmap = {
                "alternate_language_version_of": "alternate_language_version_of",
                "edited_from": "editedFrom",
                "edited_into": "editedInto",
                "featured_in": "featured",
                "features": "features",
                "followed_by": "followedBy",
                "follows": "follows",
                "referenced_in": "referenced",
                "references": "references",
                "remade_as": "remadeAs",
                "remake_of": "remakeOf",
                "spin_off": "spinOff",
                "spin_off_from": "spinOffFrom",
                "spoofed_in": "spoofed",
                "spoofs": "spoofs",
                "version_of": "versionOf",
            }
            self._movieconnections = {v: [] for v in cmap.values()}
            q = (
                "query Connections($id: ID!, $after: ID) {\n"
                "  title(id: $id) {\n"
                "    connections(first: 9999, after: $after) {\n"
                "      edges {\n"
                "        node {\n"
                "          associatedTitle { id releaseYear { year } titleText { text } }\n"
                "          category { id }\n"
                "          text\n"
                "        }\n"
                "      }\n"
                "      pageInfo { endCursor hasNextPage }\n"
                "    }\n"
                "  }\n"
                "}\n"
            )
            after = None
            while True:
                vars_: dict[str, Any] = {"id": f"tt{self._id}"}
                if after:
                    vars_["after"] = after
                j = self._graphql(q, "Connections", vars_)
                conn = (((j.get("data") or {}).get("title") or {}).get("connections") or {})
                for e in conn.get("edges") or []:
                    n = e.get("node") or {}
                    cat = ((n.get("category") or {}).get("id")) or ""
                    key = cmap.get(cat)
                    if not key:
                        continue
                    at = n.get("associatedTitle") or {}
                    mid = (at.get("id") or "").replace("tt", "")
                    yr = (at.get("releaseYear") or {}).get("year")
                    self._movieconnections[key].append(
                        {
                            "mid": mid,
                            "name": ((at.get("titleText") or {}).get("text")) or "",
                            "year": yr,
                            "comment": n.get("text") or "",
                        }
                    )
                pi = conn.get("pageInfo") or {}
                if not pi.get("hasNextPage"):
                    break
                after = pi.get("endCursor")
                if not after:
                    break
        return dict(self._movieconnections or {})

    def extReviews(self) -> list[dict[str, str]]:
        if self._extreviews is None:
            self._extreviews = []
            q = (
                "query ExternalLinks($id: ID!, $after: ID) {\n"
                "  title(id: $id) {\n"
                "    externalLinks(first: 9999, after: $after) {\n"
                "      edges { node { label url externalLinkCategory { id } } }\n"
                "      pageInfo { endCursor hasNextPage }\n"
                "    }\n"
                "  }\n"
                "}\n"
            )
            after = None
            while True:
                v: dict[str, Any] = {"id": f"tt{self._id}"}
                if after:
                    v["after"] = after
                j = self._graphql(q, "ExternalLinks", v)
                conn = (((j.get("data") or {}).get("title") or {}).get("externalLinks") or {})
                for e in conn.get("edges") or []:
                    n = e.get("node") or {}
                    if (n.get("externalLinkCategory") or {}).get("id") != "review":
                        continue
                    self._extreviews.append({"url": n.get("url") or "", "desc": n.get("label") or ""})
                pi = conn.get("pageInfo") or {}
                if not pi.get("hasNextPage"):
                    break
                after = pi.get("endCursor")
                if not after:
                    break
        return list(self._extreviews)

    def releaseInfo(self) -> list[dict[str, Any]]:
        if self._release_info is None:
            j = self._graphql(GQL_RELEASE_DATES, "ReleaseDates", {"id": f"tt{self._id}"})
            edges = (((j.get("data") or {}).get("title") or {}).get("releaseDates") or {}).get("edges") or []
            self._release_info = []
            for e in edges:
                n = e.get("node") or {}
                attrs = n.get("attributes") or []
                attr_text = [a.get("text") for a in attrs if isinstance(a, dict)]
                c = n.get("country") or {}
                self._release_info.append(
                    {
                        "country": c.get("text"),
                        "day": n.get("day"),
                        "mon": n.get("month"),
                        "year": n.get("year"),
                        "comment": " ".join(f"({t})" for t in attr_text if t),
                        "attributes": attr_text,
                    }
                )
        return list(self._release_info)

    def locations(self) -> list[str]:
        if self._locations_l is None:
            page = self._get_page("Locations")
            tree = lhtml.fromstring(page)
            texts = tree.xpath("//*[contains(@class,'ipc-html-content-inner-div')]/text()")
            self._locations_l = [t.strip() for t in texts if t and len(t.strip()) > 3][:50]
            if not self._locations_l:
                nd = _next_data_props(page)
                self._locations_l = self._extract_card_texts(nd)
        return list(self._locations_l or [])

    def _extract_card_texts(self, d: Any) -> list[str]:
        out: list[str] = []
        if isinstance(d, dict):
            if "cardText" in d and isinstance(d["cardText"], str):
                out.append(d["cardText"].strip())
            for v in d.values():
                out.extend(self._extract_card_texts(v))
        elif isinstance(d, list):
            for x in d:
                out.extend(self._extract_card_texts(x))
        return out

    def _company_credits(self, category: str) -> list[dict[str, str]]:
        j = self._graphql(GQL_COMPANY_CREDITS, "CompanyCredits", {"id": f"tt{self._id}"})
        edges = (((j.get("data") or {}).get("title") or {}).get("companyCredits") or {}).get("edges") or []
        results: list[dict[str, str]] = []
        for e in edges:
            credit = e.get("node") or {}
            if (credit.get("category") or {}).get("id") != category:
                continue
            notes: list[str] = []
            yi = (credit.get("yearsInvolved") or {}).get("year")
            if yi:
                notes.append(str(yi))
            countries = credit.get("countries") or []
            if countries and isinstance(countries[0], dict) and countries[0].get("text"):
                notes.append(countries[0]["text"])
            for a in credit.get("attributes") or []:
                if isinstance(a, dict) and a.get("text"):
                    notes.append(a["text"])
            name = ((credit.get("displayableProperty") or {}).get("value") or {}).get("plainText") or ""
            cid = ((credit.get("company") or {}).get("id")) or ""
            note_s = " ".join(f"({n})" for n in notes)
            results.append(
                {"name": name, "url": f"https://{self._c.imdbsite}/company/{cid}", "notes": note_s}
            )
        return results

    def prodCompany(self) -> list[dict[str, str]]:
        if self._compcred_prod is None:
            self._compcred_prod = self._company_credits("production")
        return list(self._compcred_prod)

    def distCompany(self) -> list[dict[str, str]]:
        if self._compcred_dist is None:
            self._compcred_dist = self._company_credits("distribution")
        return list(self._compcred_dist)

    def specialCompany(self) -> list[dict[str, str]]:
        if self._compcred_special is None:
            self._compcred_special = self._company_credits("specialEffects")
        return list(self._compcred_special)

    def otherCompany(self) -> list[dict[str, str]]:
        if self._compcred_other is None:
            self._compcred_other = self._company_credits("miscellaneous")
        return list(self._compcred_other)

    def parentalGuide(self, spoil: bool = False) -> dict[str, list[str]]:
        if self._parental_guide is None:
            page = self._get_page("ParentalGuide")
            self._parental_guide = {}
            for m in re.finditer(
                r'<section id="advisory-([^"]*)(?<!spoilers)">.+?<h\d[^>]+>(.*?)</h\d>',
                page,
                re.S | re.I,
            ):
                sid = m.group(1)
                sname = html_module.unescape(strip_tags(m.group(2))).strip()
                if spoil and not sid.startswith("spoiler"):
                    continue
                if not spoil and sid.startswith("spoiler"):
                    continue
                key = sname
                if sname == "Alcohol, Drugs & Smoking":
                    key = "Drugs"
                elif sname == "Sex & Nudity":
                    key = "Sex"
                elif sname == "Violence & Gore":
                    key = "Violence"
                elif sname == "Frightening & Intense Scenes":
                    key = "Frightening"
                tag_s = page.find(f'<section id="advisory-{sid}"')
                if tag_s == -1:
                    continue
                tag_e = page.find("</section", tag_s)
                block = page[tag_s:tag_e]
                items = re.findall(r'<li class="ipl[^"]+">\s*(.*?)\s*<div', block, re.S | re.I)
                self._parental_guide[key] = [html_module.unescape(strip_tags(x)).strip() for x in items]
        return dict(self._parental_guide or {})

    def officialSites(self) -> list[dict[str, str]]:
        if self._official_sites is None:
            self._official_sites = []
            q = (
                "query ExternalLinks($id: ID!, $after: ID) {\n"
                "  title(id: $id) {\n"
                "    externalLinks(first: 9999, after: $after) {\n"
                "      edges { node { label url externalLinkCategory { id } } }\n"
                "      pageInfo { endCursor hasNextPage }\n"
                "    }\n"
                "  }\n"
                "}\n"
            )
            after = None
            while True:
                v: dict[str, Any] = {"id": f"tt{self._id}"}
                if after:
                    v["after"] = after
                j = self._graphql(q, "ExternalLinks", v)
                conn = (((j.get("data") or {}).get("title") or {}).get("externalLinks") or {})
                for e in conn.get("edges") or []:
                    n = e.get("node") or {}
                    if (n.get("externalLinkCategory") or {}).get("id") != "official":
                        continue
                    self._official_sites.append({"url": n.get("url") or "", "name": n.get("label") or ""})
                pi = conn.get("pageInfo") or {}
                if not pi.get("hasNextPage"):
                    break
                after = pi.get("endCursor")
                if not after:
                    break
        return list(self._official_sites)

    def keywords_all(self) -> list[str]:
        if self._all_keywords is None:
            page = self._get_page("Keywords")
            self._all_keywords = re.findall(r'<a.*?href="/search/keyword[^>]+?>(.*?)</a>', page)
        return list(self._all_keywords)

    def awards(self, compat: bool = True) -> dict[str, Any]:
        _ = compat
        return {}

    def budget(self) -> int | None:
        if not self._budget_computed:
            self._budget_computed = True
            pp = _next_data_props(self._get_page("Title"))
            self._budget = self._dig_budget(pp)
        return self._budget

    def _dig_budget(self, d: Any) -> int | None:
        if isinstance(d, dict):
            if "productionBudget" in d:
                pb = d["productionBudget"]
                if isinstance(pb, dict):
                    b = pb.get("budget") or {}
                    a = b.get("amount")
                    if a is not None:
                        try:
                            return int(str(a).replace(",", ""))
                        except ValueError:
                            pass
            for v in d.values():
                r = self._dig_budget(v)
                if r is not None:
                    return r
        elif isinstance(d, list):
            for x in d:
                r = self._dig_budget(x)
                if r is not None:
                    return r
        return None

    def filmingDates(self) -> dict[str, str] | None:
        if not self._filming_dates_computed:
            self._filming_dates_computed = True
            page = self._get_page("Locations")
            m = re.search(
                r'sub-section-flmg_dates"[^>]*?>(.*?)</section>',
                page,
                re.I | re.S,
            )
            if m:
                fd = strip_tags(m.group(1))
                dm = re.search(r"(\w+ \d+, \d{4}) - (\w+ \d+, \d{4})", fd)
                if dm:
                    from datetime import datetime

                    def _parse_us_date(s: str) -> datetime | None:
                        s = s.strip()
                        for fmt in ("%b %d, %Y", "%B %d, %Y"):
                            try:
                                return datetime.strptime(s, fmt)
                            except ValueError:
                                continue
                        return None

                    d1 = _parse_us_date(dm.group(1))
                    d2 = _parse_us_date(dm.group(2))
                    if d1 and d2:
                        self._filming_dates = {
                            "beginning": d1.strftime("%Y-%m-%d"),
                            "end": d2.strftime("%Y-%m-%d"),
                        }
                    else:
                        self._filming_dates = None
                else:
                    self._filming_dates = None
            else:
                self._filming_dates = None
        return self._filming_dates

    def alternateVersions(self) -> list[str]:
        if self._moviealternateversions is None:
            j = self._graphql(GQL_ALT_VERSIONS, "AlternateVersions", {"id": f"tt{self._id}"})
            edges = (((j.get("data") or {}).get("title") or {}).get("alternateVersions") or {}).get("edges") or []
            self._moviealternateversions = []
            for e in edges:
                t = ((e.get("node") or {}).get("text") or {}).get("plainText")
                if t:
                    self._moviealternateversions.append(str(t))
        return list(self._moviealternateversions)

    def real_id(self) -> str | None:
        page = self._get_page("Title")
        m = re.search(r'<meta property="imdb:pageConst" content="tt(\d+)"', page)
        return m.group(1) if m else None

    # --- Names matching older Python tests (`movie.title` property, etc.) ---
    @property
    def movie_type(self) -> str:
        return self.movietype()

    @property
    def genres_list(self) -> list[str]:
        return self.genres()
