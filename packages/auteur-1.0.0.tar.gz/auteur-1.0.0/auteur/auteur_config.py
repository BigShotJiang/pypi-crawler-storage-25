"""IMDb client configuration."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Default Accept-Language for IMDb (matches typical browser `en-US` with English fallback).
DEFAULT_IMDB_LANGUAGE = "en-US,en"


@dataclass
class AuteurConfig:
    """
    HTTP and locale settings for IMDb requests.

    ``language`` sets the ``Accept-Language`` header. If omitted or empty, it defaults
    to :data:`DEFAULT_IMDB_LANGUAGE` (``"en-US,en"``).
    """

    language: str = DEFAULT_IMDB_LANGUAGE
    imdbsite: str = "www.imdb.com"
    #: Local directory for `Title.savephoto` / `Title.photo_localurl`.
    photodir: str | Path = "./images/"
    #: URL prefix matching `photodir`
    photoroot: str = "./images/"
    cachedir: str | Path = field(default_factory=lambda: Path.home() / ".cache" / "auteur_imdb")
    usecache: bool = True
    throw_http_exceptions: bool = True
    debug: bool = False
    default_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0"
    )
    force_agent: str = ""
    use_proxy: bool = False
    ip_address: str = ""
    proxy_host: str | None = None
    proxy_port: int | None = None
    proxy_user: str | None = None
    proxy_pw: str = ""
    waf_token_max_age_sec: int = 280

    def __post_init__(self) -> None:
        if not self.language:
            self.language = DEFAULT_IMDB_LANGUAGE

    def user_agent(self) -> str:
        return self.force_agent or self.default_agent

    def cache_path(self) -> Path:
        p = Path(self.cachedir)
        p.mkdir(parents=True, exist_ok=True)
        return p

    def waf_token_file(self) -> Path:
        return self.cache_path() / "imdb_waf_token"

    @staticmethod
    def from_mapping(d: dict[str, Any]) -> "AuteurConfig":
        c = AuteurConfig()
        for k, v in d.items():
            if hasattr(c, k):
                setattr(c, k, v)
        if not c.language:
            c.language = DEFAULT_IMDB_LANGUAGE
        return c
