"""IMDb title find (`/find/?s=tt&q=...`) — mirrors `php-imdb/src/Imdb/TitleSearch.php`."""

from __future__ import annotations

import re
from urllib.parse import quote

from lxml import html as lhtml

from .auteur_config import AuteurConfig
from .imdb_title import ImdbTitle
from .lib.imdb_http import ImdbClient, normalize_title_id

_YEAR_TYPE_LINE = re.compile(
    r"^(?P<year>\d{4})?(?:-(?P<y2>\d{4})?)?(?:s\d+\.e\d+)?(?P<type>.*)$",
    re.I,
)


def _parse_title_type(s: str) -> str:
    """Map find-page type chip text to :class:`TitleSearch` constants (same strings as PHP ``Title``)."""
    u = s.upper()
    if "TV SERIES" in u and "TV MINI SERIES" not in u:
        return "TV Series"
    if "TV EPISODE" in u:
        return "TV Episode"
    if "TV MINI SERIES" in u:
        return "TV Mini Series"
    if "TV MOVIE" in u:
        return "TV Movie"
    if "TV SPECIAL" in u:
        return "TV Special"
    if "TV SHORT" in u:
        return "TV Short"
    if "VIDEO GAME" in u:
        return "Video Game"
    if "MUSIC VIDEO" in u:
        return "Music Video"
    if "VIDEO" in u:
        return "Video"
    if "SHORT" in u:
        return "Short"
    if "PODCAST EPISODE" in u:
        return "Podcast Episode"
    if "PODCAST SERIES" in u:
        return "Podcast Series"
    return "Movie"


def _metadata_chips(cell) -> list[str]:
    lis = cell.xpath(".//div[contains(@class, 'cli-title-metadata')]//li")
    out: list[str] = []
    for li in lis:
        t = (li.text_content() or "").strip()
        if t:
            out.append(t)
    return out


def _year_from_first_chip(parts: list[str]) -> int:
    if not parts:
        return 0
    m = re.match(r"^(\d{4})", parts[0])
    return int(m.group(1)) if m else 0


def _year_and_type_from_cell(cell) -> tuple[int, str]:
    meta_els = cell.xpath(".//div[contains(@class, 'cli-title-metadata')]")
    parts = _metadata_chips(cell)
    if parts:
        return _year_from_first_chip(parts), _parse_title_type(" ".join(parts))
    if meta_els:
        raw = (meta_els[0].text_content() or "").strip()
        m = _YEAR_TYPE_LINE.match(raw)
        if m:
            y = m.group("year") or ""
            typ = _parse_title_type(m.group("type") or "")
            return (int(y) if y else 0), typ
    return 0, "Movie"


class TitleSearch:
    """Search IMDb by title; result objects are :class:`ImdbTitle` instances from the find list."""

    MOVIE = "Movie"
    TV_SERIES = "TV Series"
    TV_EPISODE = "TV Episode"
    TV_MINI_SERIES = "TV Mini Series"
    TV_MOVIE = "TV Movie"
    TV_SPECIAL = "TV Special"
    TV_SHORT = "TV Short"
    GAME = "Video Game"
    VIDEO = "Video"
    MUSIC_VIDEO = "Music Video"
    SHORT = "Short"
    PODCAST_EPISODE = "Podcast Episode"
    PODCAST_SERIES = "Podcast Series"

    def __init__(self, config: AuteurConfig, client: ImdbClient | None = None) -> None:
        self._c = config
        self._http = client or ImdbClient(config)

    def _build_url(self, search_terms: str) -> str:
        return f"https://{self._c.imdbsite}/find/?s=tt&q={quote(search_terms, safe='')}"

    def search(
        self,
        search_terms: str,
        wanted_types: list[str] | None = None,
        max_results: int = -1,
    ) -> list[ImdbTitle]:
        raw = self._http.get(self._build_url(search_terms))
        if not raw:
            return []
        tree = lhtml.fromstring(raw)
        cells = tree.xpath(
            "//section[@data-testid='find-results-section-title']"
            "//div[contains(@class,'ipc-metadata-list-summary-item__tc')]"
        )
        results: list[ImdbTitle] = []
        n = 0
        for cell in cells:
            year, movietype = _year_and_type_from_cell(cell)
            if wanted_types is not None and movietype not in wanted_types:
                continue

            ep_sel = ".//div[contains(@class, 'cli-ep-title')]"
            ep_block = cell.xpath(ep_sel)
            if ep_block:
                link_els = cell.xpath(ep_sel + "//a[contains(@class,'ipc-title-link-wrapper')]")
                ep_year_els = cell.xpath(".//span[contains(@class, 'cli-ep-year')]")
                if ep_year_els:
                    ym = re.search(r"(?P<year>\d{4})", ep_year_els[0].text_content() or "")
                    if ym:
                        year = int(ym.group("year"))
            else:
                link_els = cell.xpath(".//a[contains(@class,'ipc-title-link-wrapper')]")

            if not link_els:
                continue
            a = link_els[0]
            href = a.get("href") or ""
            mm = re.search(r"tt(\d+)", href)
            if not mm:
                continue
            imdb_id = normalize_title_id(mm.group(1))
            title = (a.text_content() or "").strip()
            results.append(
                ImdbTitle.from_search_result(
                    imdb_id,
                    title,
                    year,
                    movietype,
                    self._c,
                    self._http,
                )
            )
            n += 1
            if max_results != -1 and n == max_results:
                break
        return results
