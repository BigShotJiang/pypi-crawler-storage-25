"""IMDb person find (`/find?q=...&s=nm`) — mirrors `php-imdb/src/Imdb/PersonSearch.php`."""

from __future__ import annotations

import re
from urllib.parse import quote

from lxml import html as lhtml

from .auteur_config import AuteurConfig
from .imdb_person import ImdbPerson
from .lib.imdb_http import ImdbClient, normalize_person_id

_LEGACY_NAME_ROW = re.compile(
    r"<tr[^>]*>\s*<td[^>]*>.*?</td>\s*<td[^>]*<a href=\"/name/nm(\d+)[^\"]*\"[^>]*>([^<]+)</a>\s*(.*?)</td>",
    re.I | re.S,
)

_DETAIL_LINE = re.compile(
    r"<small>\(([^,]*),\s*<a href=\"/title/tt(\d{7,8})[^\"]*\"\s*>([^<]*)</a>\s*\((\d{4})\)\)",
    re.I | re.S,
)


class PersonSearch:
    """Search IMDb by person name; hits are :class:`ImdbPerson` rows from the find list."""

    def __init__(self, config: AuteurConfig, client: ImdbClient | None = None) -> None:
        self._c = config
        self._http = client or ImdbClient(config)
        self._name: str | None = None

    def _build_url(self) -> str:
        q = quote(self._name or "", safe="")
        return f"https://{self._c.imdbsite}/find?q={q}&s=nm"

    def set_search_name(self, name: str) -> None:
        """Set the query string (same role as php-imdb ``setsearchname``)."""
        self._name = name

    def results(self) -> list[ImdbPerson]:
        if not self._name:
            return []
        raw = self._http.get(self._build_url())
        if not raw:
            return []
        return self._parse_page(raw)

    def search(self, search_terms: str) -> list[ImdbPerson]:
        self.set_search_name(search_terms)
        return self.results()

    def _parse_page(self, raw: str) -> list[ImdbPerson]:
        tree = lhtml.fromstring(raw)
        links = tree.xpath(
            "//section[@data-testid='find-results-section-name']"
            "//a[contains(@href,'/name/nm')][normalize-space(.)!='']"
        )
        results: list[ImdbPerson] = []
        seen: set[str] = set()

        if links:
            for link in links:
                href = link.get("href") or ""
                mm = re.search(r"nm(\d+)", href)
                if not mm:
                    continue
                pid = normalize_person_id(mm.group(1))
                if pid in seen:
                    continue
                seen.add(pid)
                display_name = (link.text_content() or "").strip()
                if not display_name:
                    continue
                results.append(ImdbPerson.from_search_results(pid, display_name, self._c, self._http))
            return results

        for m in _LEGACY_NAME_ROW.finditer(raw):
            pid = normalize_person_id(m.group(1))
            if pid in seen:
                continue
            seen.add(pid)
            display_name = m.group(2).strip()
            info = m.group(3)
            person = ImdbPerson.from_search_results(pid, display_name, self._c, self._http)
            if info.strip():
                dm = _DETAIL_LINE.search(info)
                if dm:
                    person.set_search_details(
                        dm.group(1).strip(),
                        dm.group(2),
                        dm.group(3),
                        int(dm.group(4)),
                    )
            results.append(person)
        return results
