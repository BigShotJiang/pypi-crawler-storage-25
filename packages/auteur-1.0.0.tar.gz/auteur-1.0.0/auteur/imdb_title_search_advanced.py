"""IMDb advanced title search (`/search/title/`) — mirrors `php-imdb/src/Imdb/TitleSearchAdvanced.php`."""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import urlencode

from lxml import html as lhtml

from .auteur_config import AuteurConfig
from .imdb_title_search import TitleSearch, _parse_title_type
from .lib.imdb_http import ImdbClient, normalize_title_id

_YEAR_TYPE_METADATA = re.compile(
    r"^(?P<year>\d{4})?(-(?P<y2>\d{4})?)?(?:s\d+\.e\d+)?(?P<type>.*)$",
    re.I,
)

_TYPE_CHIP = re.compile(
    r"^(TV Series|TV Episode|Movie|TV Mini Series|TV Movie|Short|Video Game|Music Video|Video|TV Special|TV Short|Podcast Episode|Podcast Series)$",
    re.I,
)

_YEAR_RANGE_FULL = re.compile(r"^(?P<y1>\d{4})\s*[–-]\s*(?P<y2>\d{4})\s*$", re.U)
_YEAR_RANGE_OPEN = re.compile(r"^(?P<y1>\d{4})\s*[–-]\s*$", re.U)
_YEAR_ALONE = re.compile(r"^\d{4}$")
_RANK_PREFIX = re.compile(r"^\d+\.\s+")
_TT_ID = re.compile(r"tt(\d{7,8})")


def _norm_id_from_href(href: str) -> str | None:
    m = _TT_ID.search(href or "")
    if not m:
        return None
    return normalize_title_id(m.group(1))


class TitleSearchAdvanced:
    """Filtered lists from IMDb advanced search; :meth:`search` returns dict rows like PHP ``TitleSearchAdvanced``."""

    MOVIE = "feature"
    TV_SERIES = "tv_series"
    TV_EPISODE = "tv_episode"
    TV_MINI_SERIES = "tv_miniseries"
    TV_MOVIE = "tv_movie"
    TV_SPECIAL = "tv_special"
    TV_SHORT = "tv_short"
    GAME = "video_game"
    VIDEO = "video"
    SHORT = "short"
    MUSIC_VIDEO = "music_video"
    PODCAST_EPISODE = "podcast_episode"
    PODCAST_SERIES = "podcast_series"

    SORT_MOVIEMETER = ""
    SORT_ALPHA = "alpha,asc"
    SORT_USER_RATING = "user_rating,desc"
    SORT_NUM_VOTES = "num_votes,desc"
    SORT_US_BOX_OFFICE_GROSS = "boxoffice_gross_us,desc"
    SORT_RUNTIME = "runtime,asc"
    SORT_YEAR = "year,asc"
    SORT_RELEASE_DATE = "release_date,asc"

    def __init__(self, config: AuteurConfig, client: ImdbClient | None = None) -> None:
        self._c = config
        self._http = client or ImdbClient(config)
        self._title: str | None = None
        self._title_types: list[str] = []
        self._year: int | None = None
        self._countries: list[str] = []
        self._languages: list[str] = []
        self._sort: str | None = None
        self._start = 1
        self._count = 25

    def set_title(self, title: str) -> None:
        self._title = title

    def set_title_types(self, types: list[str]) -> None:
        self._title_types = types

    def set_year(self, year: int) -> None:
        self._year = year

    def set_countries(self, countries: list[str]) -> None:
        self._countries = countries

    def set_languages(self, languages: list[str]) -> None:
        self._languages = languages

    def set_sort(self, sort: str) -> None:
        self._sort = sort

    def set_count(self, count: int) -> None:
        self._count = count

    def set_start(self, start: int) -> None:
        self._start = start

    def _build_url(self) -> str:
        q: dict[str, str] = {}
        if self._title:
            q["title"] = self._title
        if self._title_types:
            q["title_type"] = ",".join(self._title_types)
        if self._year is not None:
            q["year"] = str(self._year)
        if self._countries:
            q["countries"] = ",".join(self._countries)
        if self._languages:
            q["languages"] = ",".join(self._languages)
        if self._sort:
            q["sort"] = self._sort
        q["view"] = "simple"
        return f"https://{self._c.imdbsite}/search/title/?{urlencode(q)}"

    def search(self) -> list[dict[str, Any]]:
        raw = self._http.get(self._build_url())
        if not raw:
            return []
        return self._parse_results(raw)

    def _parse_results(self, page: str) -> list[dict[str, Any]]:
        tree = lhtml.fromstring(page)
        sections = tree.xpath("//ul[contains(@class, 'detailed-list-view')]//li")
        ret: list[dict[str, Any]] = []
        counter = 0

        for result_section in sections:
            title_els = result_section.xpath(".//div[contains(@class, 'dli-title')]/a")
            title_element = title_els[0] if title_els else None
            if title_element is None:
                continue
            main_href = title_element.get("href") or ""
            main_id = _norm_id_from_href(main_href)
            if not main_id:
                continue

            inline_texts: list[str] = []
            for node in result_section.xpath(".//li[contains(@class, 'ipc-inline-list__item')]"):
                t = (node.text_content() or "").strip()
                if t:
                    inline_texts.append(t)

            series_els = result_section.xpath(".//div[contains(@class, 'dli-ep-title')]//a")
            series_title_el = series_els[0] if series_els else None

            if series_title_el is not None:
                series_href = series_title_el.get("href") or ""
                series_id = _norm_id_from_href(series_href)
                if series_id:
                    episode_title = _RANK_PREFIX.sub("", (title_element.text_content() or "").strip())
                    episode_imdbid = main_id
                    title = re.sub(r"\s+", " ", (series_title_el.text_content() or "").strip())

                    year: int | None = None
                    episode_year: int | None = None
                    for t in inline_texts:
                        mfull = _YEAR_RANGE_FULL.match(t)
                        if mfull:
                            year = int(mfull.group("y1"))
                            episode_year = int(mfull.group("y2"))
                            break
                        mopen = _YEAR_RANGE_OPEN.match(t)
                        if mopen:
                            y = int(mopen.group("y1"))
                            year = y
                            episode_year = y
                            break

                    ep_year_els = result_section.xpath(".//span[contains(@class, 'li-ep-year')]")
                    if ep_year_els:
                        ey = re.search(r"(?P<year>\d{4})", ep_year_els[0].text_content() or "")
                        if ey:
                            episode_year = int(ey.group("year"))

                    ret.append(
                        {
                            "rank": self._start + counter,
                            "imdbid": series_id,
                            "title": title,
                            "year": year,
                            "type": TitleSearch.TV_EPISODE,
                            "serial": True,
                            "episode_imdbid": episode_imdbid,
                            "episode_title": episode_title,
                            "episode_year": episode_year,
                        }
                    )
                    counter += 1
                    continue

            title = _RANK_PREFIX.sub("", (title_element.text_content() or "").strip())
            imdbid = main_id
            ep_id: str | None = None
            ep_name: str | None = None
            ep_year: int | None = None
            is_serial = False
            list_year: int | None = None
            typ_raw = ""

            meta_els = result_section.xpath(".//div[contains(@class, 'dli-title-metadata')]")
            if meta_els:
                raw_meta = (meta_els[0].text_content() or "").strip()
                mm = _YEAR_TYPE_METADATA.match(raw_meta)
                if mm:
                    yg = mm.group("year") or ""
                    if yg:
                        list_year = int(yg)
                    typ_raw = mm.group("type") or ""

            for t in inline_texts:
                if _TYPE_CHIP.match(t):
                    typ_raw = t
                    break

            if list_year is None:
                for t in inline_texts:
                    if _YEAR_ALONE.match(t):
                        list_year = int(t)
                        break

            mtype = _parse_title_type(typ_raw)

            if mtype in (TitleSearch.TV_SERIES, TitleSearch.TV_EPISODE, TitleSearch.TV_MINI_SERIES):
                is_serial = True

            if mtype == TitleSearch.TV_EPISODE:
                ep_els = result_section.xpath(".//div[contains(@class, 'dli-ep-title')]/a")
                ep_title_el = ep_els[0] if ep_els else None
                if ep_title_el is not None:
                    ep_name = (ep_title_el.text_content() or "").strip()
                    ep_href = ep_title_el.get("href") or ""
                    ep_mid = _norm_id_from_href(ep_href)
                    if ep_mid:
                        ep_id = ep_mid
                    ep_year_nodes = result_section.xpath(".//span[contains(@class, 'li-ep-year')]")
                    if ep_year_nodes:
                        em = re.search(r"(?P<year>\d{4})", ep_year_nodes[0].text_content() or "")
                        if em:
                            ep_year = int(em.group("year"))

            ret.append(
                {
                    "rank": self._start + counter,
                    "imdbid": imdbid,
                    "title": title,
                    "year": list_year,
                    "type": mtype,
                    "serial": is_serial,
                    "episode_imdbid": ep_id,
                    "episode_title": ep_name,
                    "episode_year": ep_year,
                }
            )
            counter += 1

        return ret
