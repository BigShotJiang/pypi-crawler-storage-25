"""High-level entry point for IMDb title and person clients."""

from __future__ import annotations

from .auteur_config import AuteurConfig
from .imdb_person import ImdbPerson
from .imdb_person_search import PersonSearch
from .imdb_title import ImdbTitle
from .imdb_title_search import TitleSearch
from .imdb_title_search_advanced import TitleSearchAdvanced
from .lib.imdb_http import ImdbClient


class Auteur:
    """Facade around :class:`ImdbTitle` and :class:`ImdbPerson` with shared config and HTTP client."""

    def __init__(self, config: AuteurConfig | None = None) -> None:
        self._config = config or AuteurConfig()
        self._client: ImdbClient | None = None

    def _http(self) -> ImdbClient:
        if self._client is None:
            self._client = ImdbClient(self._config)
        return self._client

    def imdb_title(self, imdb_id: str) -> ImdbTitle:
        return ImdbTitle(imdb_id, self._config, self._http())

    def imdb_person(self, imdb_id: str) -> ImdbPerson:
        return ImdbPerson(imdb_id, self._config, self._http())

    def person_search(self, search_terms: str) -> list[ImdbPerson]:
        return PersonSearch(self._config, self._http()).search(search_terms)

    def person_search_session(self) -> PersonSearch:
        """Person find client sharing this facade's config and HTTP session (``search`` / ``set_search_name`` / ``results``)."""
        return PersonSearch(self._config, self._http())

    def title_search(
        self,
        search_terms: str,
        wanted_types: list[str] | None = None,
        max_results: int = -1,
    ) -> list[ImdbTitle]:
        return TitleSearch(self._config, self._http()).search(search_terms, wanted_types, max_results)

    def title_search_advanced(self) -> TitleSearchAdvanced:
        """IMDb `/search/title/` advanced search (structured dict rows)."""
        return TitleSearchAdvanced(self._config, self._http())
