"""HTML table parsing helpers."""

from __future__ import annotations

import html as html_module
import re
from typing import Any


def strip_tags(s: str) -> str:
    return re.sub(r"<[^>]+>", "", s)


def get_table_rows(html: str, table_start: str) -> list[str]:
    if table_start in ("Writing Credits", "Series Writing Credits"):
        row_s = html.find(">" + table_start)
    else:
        row_s = html.find(">" + table_start + "&nbsp;<")
    if row_s == 0:
        return []
    endtable = html.find("</table>", row_s)
    if endtable == -1:
        return []
    block = html[row_s:endtable]
    m = re.findall(r"<tr>(.+?)</tr>", block, flags=re.I | re.S)
    return m


def get_row_cells(row: str) -> list[str]:
    m = re.findall(r"<td.*?>(.*?)</td>", row, flags=re.I | re.S)
    return m


def get_imdbname(href_fragment: str) -> str:
    m = re.search(r"nm(\d+)", href_fragment)
    return m.group(1) if m else ""


def get_table_rows_cast(html: str) -> list[str]:
    row_s = html.find('<table class="cast_list">')
    if row_s == 0:
        return []
    endtable = html.find("</table>", row_s)
    if endtable == -1:
        return []
    block = html[row_s:endtable]
    m = re.findall(r"<tr.*?>(.*?)</tr>", block, flags=re.I | re.S)
    return m


def parse_cast_entries(cast_rows: list[str]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for cast_row in cast_rows:
        cels = get_row_cells(cast_row)
        if len(cels) != 4:
            continue
        dir_: dict[str, Any] = {
            "imdb": None,
            "name": None,
            "name_alias": None,
            "credited": True,
            "role": None,
            "role_episodes": None,
            "role_start_year": None,
            "role_end_year": None,
            "role_other": [],
            "thumb": None,
            "photo": None,
        }
        m = re.search(r'href="/name/nm(\d+)/', cels[1])
        dir_["imdb"] = m.group(1) if m else None
        dir_["name"] = strip_tags(cels[1]).strip()
        if not dir_["name"]:
            continue
        role_cell = strip_tags(cels[3].replace("&nbsp;", "")).strip()
        if role_cell:
            role_lines = role_cell.split("\n")
            role_parts: list[str] = []
            while role_lines:
                role_line = role_lines.pop(0).strip()
                if not role_line:
                    continue
                if role_line[0] == "(" or re.search(r"\d+ episode", role_line, re.I):
                    role_lines.insert(0, role_line)
                    break
                role_parts.append(role_line)
            dir_["role"] = " ".join(role_parts) if role_parts else None
            if dir_["role"]:
                dir_["role"] = dir_["role"].replace(" / ...", "")
            cleaned_role_cell = "\n".join(role_lines)
            mas = re.search(r"\(as (.+?)\)", cleaned_role_cell, re.S)
            if mas:
                dir_["name_alias"] = mas.group(1)
                cleaned_role_cell = re.sub(r"\(as (.+?)\)", "", cleaned_role_cell, flags=re.S)
            ep = re.search(r"(\d+) episodes?, (\d+)(?:-(\d+))?", cleaned_role_cell)
            if ep:
                dir_["role_episodes"] = int(ep.group(1))
                dir_["role_start_year"] = int(ep.group(2))
                dir_["role_end_year"] = int(ep.group(3)) if ep.group(3) else int(ep.group(2))
                cleaned_role_cell = re.sub(
                    r"\((\d+) episodes?, (\d+)(?:-(\d+))?\)",
                    "",
                    cleaned_role_cell,
                )
            for um in re.finditer(r"\((.+?)\)", cleaned_role_cell):
                ri = um.group(1).strip()
                if ri == "uncredited":
                    dir_["credited"] = False
                else:
                    dir_["role_other"].append(ri)
        imgm = re.search(r'<img [^>]*loadlate="([^"]+)"', cels[0], re.I | re.S)
        if imgm:
            dir_["thumb"] = imgm.group(1)
            th = dir_["thumb"]
            if th and "._V1" in th:
                dir_["photo"] = re.sub(r"\._V1_.+?(\.\w+)$", r"\1", th)
        else:
            dir_["thumb"] = ""
            dir_["photo"] = ""
        out.append(dir_)
    return out
