"""
AWS WAF token solver for IMDb.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import random
import struct
import time
from dataclasses import dataclass
from typing import Any, Optional

import requests
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ALPHABET = "0123456789abcdef"
IEEE_POLYNOMIAL = 0xEDB88320
KEY_HEX = "6f71a512b1e035eaab53d8be73120d3fb68a0ca346b9560aab3e5cdf753d5e98"
BANDWIDTH_CHALLENGE = "ha9faaffd31b4d5ede2a2e19d2d7fd525f66fee61911511960dcbb52d3c48ce25"
CHALLENGES: dict[str, str] = {
    "h72f957df656e80ba55f5d8ce2e8c7ccb59687dba3bfb273d54b08a261b2f3002": "compute_scrypt",
    "h7b0c470f0cfe3a80a9e26526ad185f484f6817d0832712a4a37a908786a6a67f": "compute_pow",
    "ha9faaffd31b4d5ede2a2e19d2d7fd525f66fee61911511960dcbb52d3c48ce25": "compute_bandwidth",
}
GPU_EXTENSIONS = (
    "ANGLE_instanced_arrays;EXT_blend_minmax;EXT_clip_control;EXT_color_buffer_half_float;"
    "EXT_depth_clamp;EXT_disjoint_timer_query;EXT_float_blend;EXT_frag_depth;EXT_polygon_offset_clamp;"
    "EXT_shader_texture_lod;EXT_texture_compression_bptc;EXT_texture_compression_rgtc;"
    "EXT_texture_filter_anisotropic;EXT_texture_mirror_clamp_to_edge;EXT_sRGB;KHR_parallel_shader_compile;"
    "OES_element_index_uint;OES_fbo_render_mipmap;OES_standard_derivatives;OES_texture_float;"
    "OES_texture_float_linear;OES_texture_half_float;OES_texture_half_float_linear;OES_vertex_array_object;"
    "WEBGL_blend_func_extended;WEBGL_color_buffer_float;WEBGL_compressed_texture_astc;"
    "WEBGL_compressed_texture_etc;WEBGL_compressed_texture_etc1;WEBGL_compressed_texture_pvrtc;"
    "WEBGL_compressed_texture_s3tc;WEBGL_compressed_texture_s3tc_srgb;WEBGL_debug_renderer_info;"
    "WEBGL_debug_shaders;WEBGL_depth_texture;WEBGL_draw_buffers;WEBGL_lose_context;WEBGL_multi_draw;"
    "WEBGL_polygon_mode"
)


@dataclass
class AwsConfig:
    """Optional proxy settings"""

    use_proxy: bool = False
    proxy_host: str | None = None
    proxy_port: int | None = None
    proxy_user: str | None = None
    proxy_pw: str | None = None


def _build_crc_table() -> list[int]:
    table: list[int] = []
    for i in range(256):
        v = i
        for _ in range(8):
            if v & 1:
                v = (v >> 1) ^ IEEE_POLYNOMIAL
            else:
                v >>= 1
        table.append(v)
    return table


_CRC_TABLE = _build_crc_table()


def _calculate_crc(data: bytes) -> int:
    v51 = 0xFFFFFFFF
    for byte in data:
        v50 = 255 & (v51 ^ byte)
        v51 = (v51 >> 8) ^ _CRC_TABLE[v50]
    result = 0xFFFFFFFF ^ (v51 & 0xFFFFFFFF)
    if result >= 0x80000000:
        result -= 0x100000000
    return int(result)


def _encode_number(num: int) -> str:
    num = num & 0xFFFFFFFF
    return (
        f"{ALPHABET[(num >> 28) & 15]}{ALPHABET[(num >> 24) & 15]}"
        f"{ALPHABET[(num >> 20) & 15]}{ALPHABET[(num >> 16) & 15]}"
        f"{ALPHABET[(num >> 12) & 15]}{ALPHABET[(num >> 8) & 15]}"
        f"{ALPHABET[(num >> 4) & 15]}{ALPHABET[num & 15]}"
    ).upper()


def _v4_uuid() -> str:
    b = bytearray(os.urandom(16))
    b[6] = (b[6] & 0x0F) | 0x40
    b[8] = (b[8] & 0x3F) | 0x80
    h = b.hex()
    parts = [h[i : i + 4] for i in range(0, 32, 4)]
    return (
        f"{parts[0]}{parts[1]}-{parts[2]}-{parts[3]}-{parts[4]}-{parts[5]}{parts[6]}{parts[7]}"
    )


def _encrypt_payload(payload_str: str) -> str:
    key = bytes.fromhex(KEY_HEX)
    iv = os.urandom(12)
    iv_b64 = base64.b64encode(iv).decode("ascii")
    aesgcm = AESGCM(key)
    ct_with_tag = aesgcm.encrypt(iv, payload_str.encode("utf-8"), None)
    tag = ct_with_tag[-16:]
    ciphertext = ct_with_tag[:-16]
    return iv_b64 + "::" + tag.hex() + "::" + ciphertext.hex()


class AwsWafSolver:
    def __init__(self, user_agent: str, domain: str, config: AwsConfig | None = None) -> None:
        self._user_agent = user_agent
        d = (domain or "www.imdb.com").lower()
        self._domain = d if d.startswith("www.") else f"www.{d}"
        self._config = config
        self._base_headers: dict[str, str] = {
            "Connection": "keep-alive",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Accept-Language": "de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7,fr;q=0.6",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
            "Priority": "u=0, i",
            "sec-ch-ua": '"Not(A:Brand";v="8", "Chromium";v="144", "Google Chrome";v="144"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"macOS"',
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "same-origin",
            "Upgrade-Insecure-Requests": "1",
            "User-Agent": self._user_agent,
        }

    def _request_kwargs(self) -> dict[str, Any]:
        if not self._config or not self._config.use_proxy or not self._config.proxy_host:
            return {}
        if self._config.proxy_user and self._config.proxy_pw and self._config.proxy_port:
            p = f"http://{self._config.proxy_user}:{self._config.proxy_pw}@{self._config.proxy_host}:{self._config.proxy_port}"
        else:
            p = f"http://{self._config.proxy_host}"
            if self._config.proxy_port:
                p += f":{self._config.proxy_port}"
        return {"proxies": {"http": p, "https": p}}

    def _get(self, url: str, timeout: int = 10) -> str:
        r = requests.get(
            url, headers={**self._base_headers, "User-Agent": self._user_agent}, timeout=timeout, **self._request_kwargs()
        )
        r.raise_for_status()
        return r.text

    def _get_fp(self) -> dict[str, Any]:
        start = int(time.time() * 1000)
        gpu_ex = list(GPU_EXTENSIONS.split(";"))
        hist = [random.randint(0, 39) for _ in range(256)]
        return {
            "metrics": {
                "fp2": 1,
                "browser": 0,
                "capabilities": 1,
                "gpu": 7,
                "dnt": 0,
                "math": 0,
                "screen": 0,
                "navigator": 0,
                "auto": 1,
                "stealth": 0,
                "subtle": 0,
                "canvas": 5,
                "formdetector": 1,
                "be": 0,
            },
            "start": start,
            "flashVersion": None,
            "plugins": [
                {"name": "PDF Viewer", "str": "PDF Viewer "},
                {"name": "Chrome PDF Viewer", "str": "Chrome PDF Viewer "},
                {"name": "Chromium PDF Viewer", "str": "Chromium PDF Viewer "},
                {"name": "Microsoft Edge PDF Viewer", "str": "Microsoft Edge PDF Viewer "},
                {"name": "WebKit built-in PDF", "str": "WebKit built-in PDF "},
            ],
            "dupedPlugins": "PDF Viewer Chrome PDF Viewer Chromium PDF Viewer Microsoft Edge PDF Viewer WebKit built-in PDF ||1920-1080-1032-24-*-*-*",
            "screenInfo": "1920-1080-1032-24-*-*-*",
            "referrer": "",
            "userAgent": self._user_agent,
            "location": "",
            "webDriver": False,
            "capabilities": {
                "css": {
                    "textShadow": 1,
                    "WebkitTextStroke": 1,
                    "boxShadow": 1,
                    "borderRadius": 1,
                    "borderImage": 1,
                    "opacity": 1,
                    "transform": 1,
                    "transition": 1,
                },
                "js": {
                    "audio": True,
                    "geolocation": bool(random.randint(0, 1)),
                    "localStorage": "supported",
                    "touch": False,
                    "video": True,
                    "webWorker": bool(random.randint(0, 1)),
                },
                "elapsed": 1,
            },
            "gpu": {
                "vendor": "Google Inc. (Apple)",
                "model": "ANGLE (Apple, ANGLE Metal Renderer: Apple M2 Pro, Unspecified Version)",
                "extensions": gpu_ex,
            },
            "dnt": None,
            "math": {
                "tan": "-1.4214488238747245",
                "sin": "0.8178819121159085",
                "cos": "-0.5753861119575491",
            },
            "automation": {
                "wd": {"properties": {"document": [], "window": [], "navigator": []}},
                "phantom": {"properties": {"window": []}},
            },
            "stealth": {"t1": 0, "t2": 0, "i": 1, "mte": 0, "mtd": False},
            "crypto": {
                "crypto": 1,
                "subtle": 1,
                "encrypt": True,
                "decrypt": True,
                "wrapKey": True,
                "unwrapKey": True,
                "sign": True,
                "verify": True,
                "digest": True,
                "deriveBits": True,
                "deriveKey": True,
                "getRandomValues": True,
                "randomUUID": True,
            },
            "canvas": {
                "hash": random.randint(645172295, 735192295),
                "emailHash": None,
                "histogramBins": hist,
            },
            "formDetected": False,
            "numForms": 0,
            "numFormElements": 0,
            "be": {"si": False},
            "end": start + random.randint(1, 5),
            "errors": [],
            "version": "2.4.0",
            "id": _v4_uuid(),
        }

    def _encode_fp(self) -> tuple[str, str]:
        fp = self._get_fp()
        payload = json.dumps(fp, ensure_ascii=False, separators=(",", ":"), sort_keys=False)
        payload_b = payload.encode("utf-8")
        crc_result = _calculate_crc(payload_b)
        checksum = _encode_number(crc_result)
        return checksum + "#" + payload, checksum

    def _build_everything(self) -> dict[str, str]:
        encoded, checksum = self._encode_fp()
        return {"checksum": checksum, "encoded": encoded, "encrypted": _encrypt_payload(encoded)}

    @staticmethod
    def _check(difficulty: int, hex_hash: str) -> bool:
        full_chars = difficulty // 4
        remain = difficulty % 4
        for i in range(min(full_chars, len(hex_hash))):
            if hex_hash[i] != "0":
                return False
        if remain > 0 and full_chars < len(hex_hash):
            val = int(hex_hash[full_chars], 16)
            if (val >> (4 - remain)) != 0:
                return False
        return True

    @staticmethod
    def _sha256_hashcash(s: str) -> str:
        h = hashlib.sha256(s.encode("utf-8")).digest()
        parts = []
        for i in range(0, 32, 4):
            (u32,) = struct.unpack("!I", h[i : i + 4])
            parts.append(f"{u32:08x}")
        return "".join(parts)

    def compute_scrypt(
        self, challenge_b64: str, checksum: str, difficulty: int, max_nonce: int = 1_000_000_00
    ) -> str:
        salt = checksum.encode("utf-8")
        for nonce in range(max_nonce):
            password = f"{challenge_b64}{checksum}{nonce}".encode("utf-8")
            raw = hashlib.scrypt(password, salt=salt, n=128, r=8, p=1, dklen=16)
            h = raw.hex()
            if self._check(difficulty, h):
                return str(nonce)
        raise RuntimeError("scrypt proof-of-work did not complete")

    def compute_pow(self, input_str: str, checksum: str, difficulty: int) -> str:
        base = f"{input_str}{checksum}"
        for nonce in range(10_000_000_00):
            hx = self._sha256_hashcash(f"{base}{nonce}")
            if self._check(difficulty, hx):
                return str(nonce)
        raise RuntimeError("sha256 pow did not complete")

    @staticmethod
    def compute_bandwidth(
        _challenge_b64: str, _checksum: str, difficulty: int
    ) -> str:  # noqa: ARG003
        sizes = {1: 1024, 2: 10240, 3: 102400, 4: 1048576, 5: 10485760}
        n = sizes.get(difficulty, 0)
        if n <= 0:
            return ""
        return base64.b64encode(b"\0" * n).decode("ascii")

    @staticmethod
    def extract(html: str) -> tuple[dict[str, Any], str]:
        parts = html.split("window.gokuProps = ", 1)
        goku_json = parts[1].split(";", 1)[0]
        goku_props = json.loads(goku_json)
        p2 = html.split('src="https://', 1)
        host = p2[1].split("/challenge.js", 1)[0]
        return goku_props, host

    def _get_final_values(self, host: str) -> dict[str, Any]:
        u = f"https://{host}/inputs?client=browser"
        t = self._get(u)
        return json.loads(t)

    def _build_metrics(self) -> list[dict[str, Any]]:
        r = random.random
        return [
            {"name": "2", "value": r(), "unit": "2"},
            {"name": "100", "value": 0, "unit": "2"},
            {"name": "101", "value": 0, "unit": "2"},
            {"name": "102", "value": 0, "unit": "2"},
            {"name": "103", "value": 8, "unit": "2"},
            {"name": "104", "value": 0, "unit": "2"},
            {"name": "105", "value": 0, "unit": "2"},
            {"name": "106", "value": 0, "unit": "2"},
            {"name": "107", "value": 0, "unit": "2"},
            {"name": "108", "value": 1, "unit": "2"},
            {"name": "undefined", "value": 0, "unit": "2"},
            {"name": "110", "value": 0, "unit": "2"},
            {"name": "111", "value": 2, "unit": "2"},
            {"name": "112", "value": 0, "unit": "2"},
            {"name": "undefined", "value": 0, "unit": "2"},
            {"name": "3", "value": 4, "unit": "2"},
            {"name": "7", "value": 0, "unit": "4"},
            {"name": "1", "value": 5 + r() * 15, "unit": "2"},
            {"name": "4", "value": 36.5, "unit": "2"},
            {"name": "5", "value": r(), "unit": "2"},
            {"name": "6", "value": 100 + r() * 400, "unit": "2"},
            {"name": "0", "value": 135 + r() * 365, "unit": "2"},
            {"name": "8", "value": 1, "unit": "4"},
        ]

    def _build_payload(self, input_payload: dict[str, Any], goku: dict[str, Any]) -> dict[str, Any]:
        challenge_type = input_payload["challenge_type"]
        if challenge_type not in CHALLENGES:
            raise NotImplementedError(f"Unknown WAF challenge type: {challenge_type!r}")
        method_name = CHALLENGES[challenge_type]
        be = self._build_everything()
        is_bw = challenge_type == BANDWIDTH_CHALLENGE
        if is_bw:
            m = getattr(self, method_name)
            sol = m("", "", int(input_payload["difficulty"]))
            met = {
                "challenge": input_payload["challenge"],
                "solution": None,
                "signals": [{"name": "Zoey", "value": {"Present": be["encrypted"]}}],
                "checksum": be["checksum"],
                "client": "Browser",
                "domain": self._domain,
                "metrics": self._build_metrics(),
                "goku_props": goku,
            }
            return {"_is_bandwidth": True, "solution_data": sol, "solution_metadata": met}
        m = getattr(self, method_name)
        sol = m(
            str(input_payload["challenge"]),
            be["checksum"],
            int(input_payload["difficulty"]),
        )
        return {
            "_is_bandwidth": False,
            "challenge": input_payload["challenge"],
            "solution": sol,
            "signals": [{"name": "Zoey", "value": {"Present": be["encrypted"]}}],
            "checksum": be["checksum"],
            "client": "Browser",
            "domain": self._domain,
            "metrics": self._build_metrics(),
            "goku_props": goku,
        }

    def _post_payload(self, host: str, payload: dict[str, Any]) -> dict[str, Any]:
        url = f"https://{host}"
        kw = self._request_kwargs()
        if payload.get("_is_bandwidth"):
            met = json.dumps(
                payload["solution_metadata"],
                ensure_ascii=False,
                separators=(",", ":"),
            )
            r = requests.post(
                f"{url}/mp_verify",
                files={
                    "solution_data": (None, payload["solution_data"]),
                    "solution_metadata": (None, met),
                },
                headers={**self._base_headers, "User-Agent": self._user_agent},
                timeout=10,
                **kw,
            )
        else:
            p = {k: v for k, v in payload.items() if k != "_is_bandwidth"}
            h = {**self._base_headers, "User-Agent": self._user_agent, "Content-Type": "application/json"}
            r = requests.post(f"{url}/verify", json=p, timeout=10, headers=h, **kw)
        r.raise_for_status()
        return r.json()

    def solve(self, site_html: str) -> str:
        goku, host = self.extract(site_html)
        values = self._get_final_values(host)
        p = self._build_payload(values, goku)
        r = self._post_payload(host, p)
        return str(r["token"])
