"""HTTP layer: request IMDb through AWS WAF"""

from __future__ import annotations

import re
import time
from typing import Optional
from urllib.parse import urlparse

import requests

from .aws_waf import AwsConfig, AwsWafSolver
from ..auteur_config import AuteurConfig
from ..exceptions import AuteurItemNotFoundError


class ImdbHttpError(Exception):
    """Raised when an IMDb request fails in a way callers should not ignore."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class ImdbClient:
    """
    Fetches IMDb HTML with browser-like headers and WAF token handling.
    """

    def __init__(self, config: AuteurConfig) -> None:
        self._c = config
        self._session = requests.Session()
        self._waf_token: str | None = self._load_stored_waf_token()

    def _load_stored_waf_token(self) -> str | None:
        path = self._c.waf_token_file()
        if not path.is_file():
            return None
        if time.time() - path.stat().st_mtime > self._c.waf_token_max_age_sec:
            return None
        try:
            return path.read_text(encoding="utf-8").strip() or None
        except OSError:
            return None

    def _store_waf_token(self, token: str) -> None:
        if not token:
            return
        try:
            self._c.waf_token_file().write_text(token, encoding="utf-8")
        except OSError:
            pass

    def _aws_config(self) -> Optional[AwsConfig]:
        c = self._c
        if c.use_proxy and c.proxy_host:
            return AwsConfig(
                use_proxy=True,
                proxy_host=c.proxy_host,
                proxy_port=c.proxy_port,
                proxy_user=c.proxy_user,
                proxy_pw=c.proxy_pw or None,
            )
        return None

    def _headers(self) -> dict[str, str]:
        h: dict[str, str] = {
            "User-Agent": self._c.user_agent(),
            "Referer": f"https://{self._c.imdbsite}/",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": self._c.language,
            "DNT": "1",
        }
        if self._c.ip_address:
            h["X-Forwarded-For"] = self._c.ip_address
        return h

    def _proxies(self) -> dict | None:
        c = self._c
        if not c.use_proxy or not c.proxy_host:
            return None
        auth = ""
        if c.proxy_user and c.proxy_pw:
            auth = f"{c.proxy_user}:{c.proxy_pw}@"
        port = f":{c.proxy_port}" if c.proxy_port else ""
        u = f"http://{auth}{c.proxy_host}{port}"
        return {"http": u, "https": u}

    def _waf_cookies(self) -> dict[str, str]:
        if not self._waf_token:
            return {}
        return {"aws-waf-token": self._waf_token}

    def _get_once(self, url: str) -> requests.Response:
        return self._session.get(
            url,
            headers=self._headers(),
            cookies=self._waf_cookies(),
            allow_redirects=True,
            timeout=30,
            proxies=self._proxies() or None,
        )

    def _fetch_challenge_landing(self) -> str:
        u = f"https://{self._c.imdbsite}/"
        r = self._session.get(
            u,
            headers={**self._headers(), "Referer": u},
            timeout=15,
            proxies=self._proxies() or None,
        )
        r.raise_for_status()
        return r.text

    def get(self, url: str) -> str:
        for attempt in range(3):
            r = self._get_once(url)
            if r.status_code == 200:
                return r.text
            if r.status_code == 404:
                meta = _imdb_title_or_name_404(url)
                if meta is not None:
                    kind, imdb_id = meta
                    raise AuteurItemNotFoundError(
                        f"No IMDb {kind} found for id {imdb_id!r}",
                        kind=kind,
                        imdb_id=imdb_id,
                    )
            if r.status_code != 202:
                if self._c.throw_http_exceptions:
                    raise ImdbHttpError(
                        f"IMDb returned HTTP {r.status_code} for {url}",
                        r.status_code,
                    )
                return ""
            ch = r.text
            if not ch or "gokuProps" not in ch:
                try:
                    ch = self._fetch_challenge_landing()
                except Exception:
                    if self._c.throw_http_exceptions:
                        raise
                    return ""
            if "gokuProps" not in ch and self._c.throw_http_exceptions:
                raise ImdbHttpError("AWS WAF challenge page did not include gokuProps; cannot solve.", 202)
            try:
                solver = AwsWafSolver(self._c.user_agent(), self._c.imdbsite, self._aws_config())
                self._waf_token = solver.solve(ch)
            except Exception as e:
                if self._c.throw_http_exceptions:
                    raise ImdbHttpError(f"AWS WAF challenge failed: {e}", 202) from e
                return ""
            self._store_waf_token(self._waf_token)
            if attempt < 2:
                continue
        if self._c.throw_http_exceptions:
            raise ImdbHttpError("IMDb still behind WAF after retries", 202)
        return ""

    def post_json(self, url: str, payload: object) -> dict:
        """
        JSON POST (used for IMDb GraphQL) with the same WAF session cookie when available.
        """
        h = {**self._headers(), "Content-Type": "application/json", "Referer": f"https://{self._c.imdbsite}/"}
        r = self._session.post(
            url,
            headers=h,
            cookies=self._waf_cookies(),
            json=payload,
            timeout=30,
            proxies=self._proxies() or None,
        )
        if r.status_code != 200:
            if self._c.throw_http_exceptions:
                raise ImdbHttpError(
                    f"IMDb API returned HTTP {r.status_code} for {url}",
                    r.status_code,
                )
            return {}
        return r.json() if r.text else {}


def _imdb_title_or_name_404(url: str) -> tuple[str, str] | None:
    """If ``url`` is the root title or name page (not a subpath), return (kind, 7-digit id) for 404 handling.

    Only the canonical ``/title/tt…`` or ``/name/nm…`` path counts: subsection URLs may return 404 after
    IMDb layout changes even when the title or person still exists.
    """
    path = urlparse(url).path.rstrip("/")
    m = re.fullmatch(r"/title/(?:tt)?(\d{6,8})", path, flags=re.I)
    if m:
        return ("title", m.group(1).zfill(7)[:7])
    m = re.fullmatch(r"/name/(?:nm)?(\d{6,})", path, flags=re.I)
    if m:
        try:
            return ("person", normalize_person_id(m.group(1)))
        except ValueError:
            return ("person", m.group(1))
    return None


def normalize_title_id(id_str: str) -> str:
    """7-digit IMDb title id without the ``tt`` prefix (e.g. ``'0133093'``)."""
    s = id_str.strip()
    m = re.match(r"tt(\d+)", s, re.I)
    if m:
        s = m.group(1)
    if s.isdigit() and 6 <= len(s) <= 8:
        return s.zfill(7)[:7]
    m2 = re.search(r"(?:nm|tt)?(\d{6,8})", s)
    if m2:
        d = m2.group(1)
        return d.zfill(7)[:7] if len(d) <= 8 else d[:7]
    if s.isdigit():
        return s.zfill(7)[:7]
    raise ValueError(f"Unrecognized IMDb id: {id_str!r}")


def normalize_person_id(id_str: str) -> str:
    """IMDb name id without the ``nm`` prefix. Pads short numeric ids to 7 digits; keeps 8+ as-is."""
    s = id_str.strip()
    m = re.match(r"nm(\d+)", s, re.I)
    if m:
        s = m.group(1)
    elif not s.isdigit():
        m2 = re.search(r"(?:nm)?(\d+)", s)
        if m2:
            s = m2.group(1)
        else:
            raise ValueError(f"Unrecognized IMDb person id: {id_str!r}")
    if not s.isdigit():
        raise ValueError(f"Unrecognized IMDb person id: {id_str!r}")
    if len(s) <= 7:
        return s.zfill(7)
    return s


def title_page_url(imdb_id: str, config: AuteurConfig, subpath: str = "/") -> str:
    n = normalize_title_id(imdb_id)
    return f"https://{config.imdbsite}/title/tt{n}{subpath}"


def person_page_url(imdb_id: str, config: AuteurConfig, subpath: str = "/") -> str:
    """Canonical person URL (``nm`` + numeric id). Short ids are zero-padded to 7 digits."""
    n = normalize_person_id(imdb_id)
    return f"https://{config.imdbsite}/name/nm{n}{subpath}"
