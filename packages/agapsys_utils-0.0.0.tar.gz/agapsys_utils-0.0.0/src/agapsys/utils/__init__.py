# Copyright (c) 2026 Leandro José Britto de Oliveira
# Licensed under the MIT License.
