# Copyright (c) 2026 Leandro José Britto de Oliveira
# Licensed under the MIT License.

from .           import assertions
from abc         import ABC, abstractmethod
from dataclasses import dataclass
from io          import IOBase, BytesIO, TextIOWrapper
from typing      import Any, IO

import locale
import os
import selectors
import shlex
import subprocess
import sys
import time

@dataclass(frozen=True)
class Result:
    """
    Process execution result.

    Args:
        exit_code (int): Process exit code.

        stdout (str | bytes | None):
            Data captured from process stdout. It process was open in text mode,
            it is a string, otherwise it is composed by raw bytes. If capturing
            was not set during process creation, it is `None`.

        stderr (str | bytes | None):
            Data captured from process stderr. It process was open in text mode,
            it is a string, otherwise it is composed by raw bytes. If capturing
            was not set during process creation, it is `None`.
    """
    exit_code: int
    stdout: str | bytes | None
    stderr: str | bytes | None

class Error(Exception):
    """
    Process execution error.
    """

    def __init__(self, result: Result) -> None:
        """
        Process execution error.

        Args:
            result (Result): Execution result.
        """
        assertions.isinstance(result, Result)
        assertions.check_value(result.exit_code != 0)

        super().__init__(f"Process exited with code {result.exit_code}")
        self.__result = result

    @property
    def result(self) -> Result:
        """
        Execution result.

        Returns:
            Result: Execution result.
        """
        return self.__result

class Listener(ABC):
    """
    Listener for a process.
    """
    @classmethod
    def decode(cls, data: bytes) -> str:
        """
        Decodes raw bytes into a string using system defaults.

        Args:
            data (bytes): raw bytes.

        Returns:
            str: Decoded string.
        """

        if not hasattr(Listener.decode, "encoding"):
            encoding = locale.getpreferredencoding(False)

        return data.decode(encoding, errors="replace")

    def __init__(self, interactive: bool = True):
        """
        Listener for a process.

        Args:
            interactive (bool, optional):
                Defines if this listener interacts with the process.
                Defaults to True.
        """
        assertions.isinstance(interactive, bool)
        self.__interactive = interactive
        super().__init__()

    @property
    def interactive(self) -> bool:
        """_summary_

        Returns:
            bool: _description_
        """
        return self.__interactive

    def on_open(self, stdin: IOBase | None):
        """
        Called upon process start.

        Default implementation does nothing.

        Args:
            stdin (IOBase | None):
                Process stdin. Use it to send data to the process. If listener
                is interactive, this will be a valide pipe to communicate
                with the process. Otherwise, it is `None`.
        """
        pass

    @abstractmethod
    def on_read(
        self,
        stdin: IOBase | None,
        stdout_data: str | bytes | None,
        stderr_data: str | bytes | None
    ):
        """Called upon data is read from the process.

        This is an abstract method.

        Args:
            stdin (IOBase):
                Process stdin. Use it to send data to the process. If listener
                is interactive, this will be a valide pipe to communicate
                with the process. Otherwise, it is `None`.

            stdout_data (str | bytes | None):
                Read data. `None` if no data was read from stdout.
                If process was open in text mode, this argument will be a
                string. Otherwise it will be raw data.

            stderr_data (str | bytes | None):
                Read data. `None` if no data was read from stderr.
                If process was open in text mode, this argument will be a
                string. Otherwise it will be raw data.
        """
        pass

    def on_close(self, exit_code: int):
        """
        Called upon process finish.

        Default implementation does nothing.

        Args:
            exit_code (int):
                Process exit code.
        """
        pass

def open(
    cmd: str|list[str],
    text_mode: bool = True,
    env: dict[str, str] | None = None,
    stdin: IO[Any] | None = None,
    stdout: IO[Any] | None = None,
    stderr: IO[Any] | None = None,
    capture_output: bool = False,
    listener: Listener | None = None,
    check_exit: bool = False,
    timeout: float | None = None
) -> Result:
    """
    Executes a process and wait for its completion.

    Args:
        cmd (str | list[str]):
            Command to be executed.

        text_mode (bool, Optional):
            Interpret output as text. Defaults to `True`.

        env (dict[str, str] | None, Optional):
            Custom environment for the process. Passsing `None` means inheriting
            parent environment. Defaults to `None`.

        stdin (IOBase, Optional):
            IOBase instance to attach to process stdin. Defaults to `None`.

        stdout (IOBase | None, Optional):
            IOBase instance to attach to process stdout. Defaults to `None`.

        stderr (IOBase | None, Optional):
            IOBase instance to attach to process stderr. Defaults to `None`.

        capture_output (bool, Optional):
            Defines if output shall be captured to be read after process
            finishes.

        listener (Listener | None, Optional):
            Listener instance used to monitor/interact with process. Defaults
            to `None`. NOTE: It is not possible to pass an interactive
            listener along with `stdin`.

        check_exit (bool, Optional):
            If `True`, raises an _Error_ if exit code is not zero.

        timeout (int | None):
            Timeout (in seconds) waiting for process to terminate. Passing
            `None` means waiting until ti finishes. Defaults to `None`

    Raises:
        Error:
            If process exited with a non-zero code and `check_exit` is `True`.

        TimeoutError:
            If a timeout was reached an process did not terminate (it will
            be killed).

        ValueError:
            If `stdin` was given along with an interactive `listener`.

    Returns:
        Result: Result of process execution (note that function does not return
        if process exited with a non-zero value and `check_exit` was `True`. For
        this case use raised exception to get details about execution result).
    """
    assertions.check_value(assertions.isinstance(cmd, (str, list)) and bool(cmd))
    assertions.isinstance(text_mode, bool)
    assertions.isinstance(env, (dict, type(None)))
    assertions.isinstance(stdin, (type(None), IOBase))
    assertions.isinstance(stdout, (type(None), IOBase))
    assertions.isinstance(stderr, (type(None), IOBase))
    assertions.isinstance(capture_output, bool)
    assertions.isinstance(check_exit, bool)
    assertions.isinstance(listener, (type(None), Listener))
    assertions.isinstance(timeout, (float, int, type(None)))

    if timeout is not None:
        if isinstance(timeout, int):
            timeout = float(timeout)

        assert timeout > 0.0

    if isinstance(cmd, str):
        cmd = shlex.split(cmd)

    if stdin is None:
        proc_stdin = subprocess.DEVNULL # proc.stdin is None
    else:
        if listener is not None and listener.interactive:
            raise ValueError("Cannot pass an interactive listener along with stdin")

        if stdin is sys.stdin:
            proc_stdin = None # proc.stdin is None (process inherits parent)
        else:
            proc_stdin = stdin # proc.stdin is NOT None and it will be provided one

    if listener is not None and listener.interactive:
        proc_stdin = subprocess.PIPE # Listener will communicate with the process

    proc = subprocess.Popen(
        cmd,
        stdin=proc_stdin,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=text_mode,
        env=env
    )

    assert proc.stdout is not None
    assert proc.stderr is not None

    sel = selectors.DefaultSelector()

    sel.register(proc.stdout, selectors.EVENT_READ)
    sel.register(proc.stderr, selectors.EVENT_READ)

    stdout_buffer = None if not capture_output else BytesIO()
    stderr_buffer = None if not capture_output else BytesIO()

    def decode(data: bytes) -> bytes | str:
        """
        Returns either given data or decoded version if `text_mode` is `True`.

        Args:
            data (bytes): raw bytes.

        Returns:
            bytes | str: `data` if `text_mode` is `False`. Otherwise, returns
            string resulting from decoding given data.
        """
        if not text_mode:
            return data
        else:
            return Listener.decode(data)

    def read(stream: IOBase) -> bytes:
        """
        Read all data (raw bytes) currently available from an IO

        Args:
            stream (IOBase): IO object to read from.

        Returns:
            bytes: Read data (raw bytes).
        """
        chunks = []
        while True:
            try:
                if isinstance(stream, TextIOWrapper):
                    chunk = stream.buffer.read()
                else:
                    chunk = stream.read()

                if not chunk:
                    break

                chunks.append(chunk)
            except BlockingIOError:
                # No more data available right now
                break

        return b"".join(chunks)

        #if isinstance(stream, TextIOWrapper):
        #    return stream.buffer.read1(chunk_size)
        #else:
        #    return stream.read1(chunk_size)

    def write(data: bytes, stream: IO[Any]):
        """
        Writes raw bytes into an IO object.

        Args:
            data (bytes): Raw data to be written.
            stream (IO[Any]): IO object.
        """
        if isinstance(stream, TextIOWrapper):
            stream.buffer.write(data)
            stream.buffer.flush()
        else:
            stream.write(data)
            stream.flush()

    # Make pipes non-block so it is possible to read all data available
    # upon selector events (Works on all platforms, including Windows)
    os.set_blocking(proc.stdout.fileno(), False)
    os.set_blocking(proc.stderr.fileno(), False)

    listener_stdin = None
    if stdin is None and listener is not None:
        # Pass the pipe to the listener so it can communicate with the process.
        listener_stdin = proc.stdin

    if proc.poll() is None and listener is not None:
        listener.on_open(listener_stdin)

    mark = time.perf_counter()
    remaining: float | None = timeout

    while remaining is None or remaining >= 0:
        events = sel.select(remaining)
        for key, _ in events:
            while True:
                data = read(key.fileobj)
                decoded_data = decode(data)

                if not data:
                    break

                if key.fileobj is proc.stdout:
                    # process stdout
                    if capture_output:
                        stdout_buffer.write(data)

                    if stdout is not None:
                        write(data, stdout)

                    if listener is not None:
                        listener.on_read(listener_stdin, decoded_data, None)

                elif key.fileobj is proc.stderr:
                    # process stderr
                    if capture_output:
                        stderr_buffer.write(data)

                    if stderr:
                        write(data, stderr)

                    if listener is not None:
                        listener.on_read(listener_stdin, None, decoded_data)

        # If process exited, break
        if proc.poll() is not None:
            exit_code = proc.wait()

            if listener is not None:
                listener.on_close(exit_code)

            stdout_data = None if not capture_output else decode(stdout_buffer.getvalue())
            stderr_data = None if not capture_output else decode(stderr_buffer.getvalue())

            result = Result(exit_code, stdout_data, stderr_data)

            if exit_code != 0 and check_exit:
                raise Error(result)

            return result

        elapsed = time.perf_counter() - mark
        remaining = None if remaining is None else remaining - elapsed

    proc.kill()
    raise TimeoutError()
