# Copyright (c) 2026 Leandro José Britto de Oliveira
# Licensed under the MIT License.

from typing import Any, Type

import builtins

def check(condition: bool, exc_type: Type[BaseException], err_msg: str | None = None) -> bool:
    """
    Asserts a given condition is `True`.

    Args:
        condition (bool): Condition which must evaluate to `True`.
        exc_type (Type[BaseException]): Type of the exception to be raised if condition is `False`.
        err_msg (str | None, optional): Custom error message used if assertion fails.

    Raises:
        exc_type: If condition is `False`.

    Returns:
        bool: If function returns, it will always return `True`.
    """
    assert builtins.isinstance(condition, bool)
    assert builtins.issubclass(exc_type, BaseException)
    assert builtins.isinstance(err_msg, (str, type(None)))

    if not condition:
        if err_msg is None:
            err_msg = "Condition is False"

        raise exc_type(err_msg)

    return True

def isinstance(obj: Any, class_or_tuple: Type | tuple[Type, ...], err_msg: str | None = None) -> bool:
    """
    Standardized assert for isinstance checks.

    Args:
        obj (Any):
            Inspected object.

        class_or_tuple (type | tuple[type, ...]):
            A type or a list of types.

        err_msg (str | None, optional):
            Custom error message used if assertion fails.

    Raises:
        TypeError: If `obj` is not an instance of expected types.

    Returns:
        bool: If function returns, it will always return `True`.
    """
    return check(
        builtins.isinstance(obj, class_or_tuple),
        TypeError,
        f"Invalid type: {'None' if type(obj) == type(None) else type(obj).__name__}" if err_msg is None else err_msg
    )

def issubclass(cls: Type, class_or_tuple: Type | tuple[Type, ...], err_msg: str | None = None) -> bool:
    """
    Standardized assert for issubclass checks.

    Args:
        cls (Type):
            Inspected given type.

        class_or_tuple (type | tuple[type, ...]):
            Accepted parent classes.

        err_msg (str | None, optional):
            Custom error message used if assertion fails.

    Raises:
        TypeError: If `cls` is not a subclass of any of provided types.

    Returns:
        bool: If function returns, it will always return `True`.
    """
    return check(
        builtins.issubclass(cls, class_or_tuple),
        TypeError,
        f"{cls.__name__} is not a valid type" if err_msg is None else err_msg
    )

def check_value(condition: bool, err_msg: str | None = None) -> bool:
    """
    Standardized way of check if a value meets a certain criteria.

    Args:
        condition (bool):
            Tested condition.

        var_name (str, optional):
            Variable name (used upon error).

        err_msg (str | None, optional):
            Custom error message used if assertion fails.

    Raises:
        ValueError: If `condition` is `False`.
    """
    return check(condition, ValueError, err_msg)
