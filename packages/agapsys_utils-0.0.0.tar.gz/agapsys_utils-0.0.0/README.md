# agapsys-utils

This project provides general purpose utiltities that individually thet do not fit in a dedicated library.

## License

m-conf is distributed under MIT License. Please see the [LICENSE](LICENSE) file for details on copying and distribution.

## Basic usage

  ```py
  import agapsys.utils as utils

  # That's it... use the available modules
  ```
