# -*- coding: utf-8 -*-
#
# Copyright (C) 2018-2026 CERN.
#
# invenio-app-ils is free software; you can redistribute it and/or modify it
# under the terms of the MIT License; see LICENSE file for more details.

"""invenio-app-ils."""

__version__ = "7.2.1"

__all__ = ("__version__",)
