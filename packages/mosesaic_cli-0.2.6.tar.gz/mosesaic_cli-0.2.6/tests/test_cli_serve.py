"""Tests for `mosesaic serve` CLI command and _auto_start_server helper."""
from __future__ import annotations

import sys
from unittest.mock import MagicMock, call, patch

import httpx
import pytest
from typer.testing import CliRunner

from mosesaic.cli.main import app, _auto_start_server

runner = CliRunner()


def test_serve_delegates_to_serve_main():
    """mosesaic serve delegates to mosesaic.team.serve.main."""
    mock_serve = MagicMock()
    with patch.dict("sys.modules", {"mosesaic.team.serve": MagicMock(main=mock_serve)}):
        result = runner.invoke(app, ["serve"])
    assert result.exit_code == 0
    mock_serve.assert_called_once_with(host=None, port=None, with_mcp=False)


def test_serve_with_mcp_flag():
    """mosesaic serve --with-mcp passes with_mcp=True."""
    mock_serve = MagicMock()
    with patch.dict("sys.modules", {"mosesaic.team.serve": MagicMock(main=mock_serve)}):
        result = runner.invoke(app, ["serve", "--with-mcp"])
    assert result.exit_code == 0
    mock_serve.assert_called_once_with(host=None, port=None, with_mcp=True)


def test_serve_host_port_flags():
    """mosesaic serve --host / --port are forwarded to serve.main."""
    mock_serve = MagicMock()
    with patch.dict("sys.modules", {"mosesaic.team.serve": MagicMock(main=mock_serve)}):
        result = runner.invoke(app, ["serve", "--host", "0.0.0.0", "--port", "9000"])
    assert result.exit_code == 0
    mock_serve.assert_called_once_with(host="0.0.0.0", port=9000, with_mcp=False)


# ── _auto_start_server tests ──────────────────────────────────────────────────

def test_auto_start_uses_shutil_which_not_argv0():
    """_auto_start_server must use shutil.which('mosesaic'), never sys.argv[0].

    The original bug: in a uv/pytest environment sys.argv[0] is the pytest
    binary, so [sys.argv[0], 'serve'] would spawn 'pytest serve' instead of
    'mosesaic serve'.
    """
    popen_calls: list = []

    fake_health = MagicMock()
    fake_health.is_success = True

    fake_client = MagicMock()
    fake_client.__enter__ = MagicMock(return_value=fake_client)
    fake_client.__exit__ = MagicMock(return_value=False)
    fake_client.get = MagicMock(return_value=fake_health)

    with (
        patch("mosesaic.cli.main.shutil.which", return_value="/usr/local/bin/mosesaic") as mock_which,
        patch("mosesaic.cli.main.subprocess.Popen", side_effect=lambda *a, **kw: popen_calls.append(a[0])) as mock_popen,
        patch("mosesaic.cli.main.httpx.Client", return_value=fake_client),
        patch("mosesaic.cli.main.time.sleep"),
    ):
        result = _auto_start_server("http://localhost:8000")

    # shutil.which must be consulted
    mock_which.assert_called_once_with("mosesaic")

    # The spawned command must use the which result, not sys.argv[0]
    assert len(popen_calls) == 1
    cmd = popen_calls[0]
    assert cmd[0] == "/usr/local/bin/mosesaic", (
        f"Expected /usr/local/bin/mosesaic but got {cmd[0]!r} — "
        "looks like sys.argv[0] was used instead of shutil.which"
    )
    assert cmd[1] == "serve"
    assert result is True


def test_auto_start_falls_back_to_python_module_when_not_in_path():
    """When mosesaic is not on PATH, fall back to python -m mosesaic serve."""
    popen_calls: list = []

    fake_health = MagicMock()
    fake_health.is_success = True
    fake_client = MagicMock()
    fake_client.__enter__ = MagicMock(return_value=fake_client)
    fake_client.__exit__ = MagicMock(return_value=False)
    fake_client.get = MagicMock(return_value=fake_health)

    with (
        patch("mosesaic.cli.main.shutil.which", return_value=None),
        patch("mosesaic.cli.main.subprocess.Popen", side_effect=lambda *a, **kw: popen_calls.append(a[0])),
        patch("mosesaic.cli.main.httpx.Client", return_value=fake_client),
        patch("mosesaic.cli.main.time.sleep"),
    ):
        result = _auto_start_server("http://localhost:8000")

    assert len(popen_calls) == 1
    cmd = popen_calls[0]
    assert cmd[0] == sys.executable
    assert cmd[1:] == ["-m", "mosesaic", "serve"]
    assert result is True


def test_auto_start_returns_false_when_server_does_not_come_up():
    """_auto_start_server returns False if /health never succeeds within timeout."""
    with (
        patch("mosesaic.cli.main.shutil.which", return_value="/usr/local/bin/mosesaic"),
        patch("mosesaic.cli.main.subprocess.Popen"),
        patch("mosesaic.cli.main.httpx.Client", side_effect=httpx.ConnectError("refused")),
        patch("mosesaic.cli.main.time.sleep"),
    ):
        result = _auto_start_server("http://localhost:8000")

    assert result is False


def test_serve_import_error_prints_install_hint():
    """mosesaic serve prints a helpful error and exits 1 if mosesaic-team is not installed."""
    import sys
    # Setting sys.modules entry to None causes ImportError when the module is imported.
    # Save + restore all mosesaic.team.* entries around the test.
    saved = {k: v for k, v in sys.modules.items() if "mosesaic.team" in k}
    for k in saved:
        del sys.modules[k]
    sys.modules["mosesaic.team.serve"] = None  # type: ignore[assignment]
    try:
        result = runner.invoke(app, ["serve"])
    finally:
        for k in [k for k in sys.modules if "mosesaic.team" in k]:
            del sys.modules[k]
        sys.modules.update(saved)
    assert result.exit_code == 1
    assert "mosesaic-team" in result.output
