"""Tests for omx export --format metricflow.

Covers:
  - build_semantic_model: measures, dimensions, entities from joins
  - build_metric: simple / derived / opaque type_params
  - export_metricflow: full output structure, header, dry-run, opaque handling
  - CLI integration: --dry-run output, exit codes
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from onlymetrix.cli import cli
from onlymetrix.metricflow import (
    DEFAULT_OUTPUT_PATH,
    _parse_dim_type,
    _to_label,
    _yaml_str,
    build_metric,
    build_semantic_model,
    export_metricflow,
)


# ---------------------------------------------------------------------------
# Fixtures — IR metric shapes matching live /v1/compiler/status output
# ---------------------------------------------------------------------------

STRUCTURED_SIMPLE = {
    "name": "total_revenue",
    "kind": "structured",
    "datasource": "default",
    "measures": [{"alias": "revenue_usd", "function": "Sum"}],
    "dimensions": [],
    "joins": [],
    "semantic": {
        "description": "Total paid revenue in USD",
        "importance": 7,
        "is_primary": True,
        "tags": ["revenue", "sum"],
        "taxonomy_path": ["Business", "Revenue", "Core"],
        "ontology": [],
    },
    "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
    "warnings": [],
}

STRUCTURED_WITH_DIM = {
    "name": "customer_count_by_tier",
    "kind": "structured",
    "datasource": "default",
    "measures": [{"alias": "count", "function": "Count"}],
    "dimensions": [{"name": "tier", "type": "Categorical { values: [] }", "source_table": None}],
    "joins": [],
    "semantic": {
        "description": "Number of customers in each tier",
        "importance": 3,
        "is_primary": False,
        "tags": ["customers"],
        "taxonomy_path": ["Business", "Customers"],
        "ontology": [],
    },
    "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
    "warnings": [],
}

STRUCTURED_MULTI_MEASURE = {
    "name": "top_products",
    "kind": "structured",
    "datasource": "default",
    "measures": [
        {"alias": "revenue_usd", "function": "Sum"},
        {"alias": "units_sold", "function": "Sum"},
    ],
    "dimensions": [{"name": "product", "type": "Categorical { values: [] }", "source_table": None}],
    "joins": [
        {"from": "order_items", "to": "products", "cardinality": None, "fanout_risk": False},
        {"from": "products", "to": "order_items", "cardinality": None, "fanout_risk": False},
    ],
    "semantic": {
        "description": "Top products by revenue",
        "importance": 6,
        "is_primary": False,
        "tags": ["products"],
        "taxonomy_path": ["Business", "Products"],
        "ontology": [],
    },
    "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
    "warnings": [],
}

STRUCTURED_FANOUT = {
    "name": "orders_per_customer",
    "kind": "structured",
    "datasource": "default",
    "measures": [{"alias": "order_count", "function": "Count"}],
    "dimensions": [],
    "joins": [
        {"from": "orders", "to": "customers", "cardinality": "many_to_one", "fanout_risk": True},
    ],
    "semantic": {
        "description": "Average orders per customer",
        "importance": 4,
        "is_primary": False,
        "tags": [],
        "taxonomy_path": [],
        "ontology": [],
    },
    "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
    "warnings": [],
}

OPAQUE_METRIC = {
    "name": "enterprise_churn_rate",
    "kind": "opaque",
    "datasource": "default",
    "measures": [],
    "dimensions": [],
    "joins": [],
    "semantic": {
        "description": "Enterprise churn rate",
        "importance": 5,
        "is_primary": False,
        "tags": [],
        "taxonomy_path": [],
        "ontology": [],
    },
    "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
    "warnings": [],
}

ALL_9_METRICS = [
    STRUCTURED_SIMPLE,
    STRUCTURED_WITH_DIM,
    STRUCTURED_MULTI_MEASURE,
    OPAQUE_METRIC,
    {
        "name": "NPS_segmented_by_tier",
        "kind": "structured",
        "datasource": "default",
        "measures": [{"alias": "nps", "function": "Avg"}],
        "dimensions": [{"name": "tier", "type": "Categorical { values: [] }", "source_table": None}],
        "joins": [],
        "semantic": {
            "description": "Net Promoter Score by customer tier",
            "importance": 5,
            "is_primary": False,
            "tags": ["customer_feedback", "average"],
            "taxonomy_path": ["Business", "Operations", "Segmented"],
            "ontology": [],
        },
        "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
        "warnings": [],
    },
    {
        "name": "order_volume_by_status",
        "kind": "structured",
        "datasource": "default",
        "measures": [
            {"alias": "order_count", "function": "Count"},
            {"alias": "total_usd", "function": "Sum"},
        ],
        "dimensions": [{"name": "status", "type": "Categorical { values: [] }", "source_table": None}],
        "joins": [],
        "semantic": {
            "description": "Order count and total by status",
            "importance": 4,
            "is_primary": False,
            "tags": ["orders"],
            "taxonomy_path": ["Business", "Operations"],
            "ontology": [],
        },
        "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
        "warnings": [],
    },
    {
        "name": "active_customers",
        "kind": "opaque",
        "datasource": "default",
        "measures": [],
        "dimensions": [],
        "joins": [],
        "semantic": {
            "description": "Customers with orders in last 90 days",
            "importance": 8,
            "is_primary": True,
            "tags": ["customers"],
            "taxonomy_path": ["Business", "Customers"],
            "ontology": [],
        },
        "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
        "warnings": [],
    },
    {
        "name": "revenue_by_month",
        "kind": "opaque",
        "datasource": "default",
        "measures": [],
        "dimensions": [],
        "joins": [],
        "semantic": {
            "description": "Monthly revenue breakdown",
            "importance": 6,
            "is_primary": False,
            "tags": ["revenue"],
            "taxonomy_path": ["Business", "Revenue"],
            "ontology": [],
        },
        "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
        "warnings": [],
    },
    {
        "name": "revenue_by",
        "kind": "opaque",
        "datasource": "default",
        "measures": [],
        "dimensions": [],
        "joins": [],
        "semantic": {
            "description": "Revenue by any dimension",
            "importance": 5,
            "is_primary": False,
            "tags": ["revenue"],
            "taxonomy_path": ["Business", "Revenue"],
            "ontology": [],
        },
        "provenance": {"compiler_version": "0.1.0", "source_format": "RawSql"},
        "warnings": [],
    },
]


# ---------------------------------------------------------------------------
# _parse_dim_type
# ---------------------------------------------------------------------------

class TestParseDimType:
    def test_categorical_ir_format(self):
        assert _parse_dim_type("Categorical { values: [] }") == "categorical"

    def test_time_ir_format(self):
        assert _parse_dim_type("Time { grain: Day }") == "time"

    def test_lowercase_passthrough(self):
        assert _parse_dim_type("categorical") == "categorical"
        assert _parse_dim_type("time") == "time"

    def test_unknown_falls_back_to_categorical(self):
        assert _parse_dim_type("Boolean") == "categorical"


# ---------------------------------------------------------------------------
# build_semantic_model
# ---------------------------------------------------------------------------

class TestBuildSemanticModel:
    def test_simple_single_measure_no_dims(self):
        # Without catalog_meta: loud placeholder (dbt compile will fail clearly)
        sm = build_semantic_model(STRUCTURED_SIMPLE)
        assert sm["name"] == "total_revenue"
        assert "__UNKNOWN__" in sm["model"]
        assert len(sm["measures"]) == 1
        assert sm["measures"][0] == {"name": "revenue_usd", "agg": "sum", "expr": "revenue_usd"}
        assert sm["dimensions"] == []
        assert "entities" not in sm

    def test_measure_expr_uses_source_expr_when_present(self):
        # source_expr from IR → used as measure expr (the actual column, not alias)
        metric = {**STRUCTURED_SIMPLE, "measures": [
            {"alias": "total_revenue", "function": "Sum", "source_expr": "total_amount"}
        ]}
        sm = build_semantic_model(metric)
        assert sm["measures"][0]["expr"] == "total_amount"
        assert sm["measures"][0]["name"] == "total_revenue"

    def test_measure_expr_falls_back_to_alias_without_source_expr(self):
        # No source_expr → fallback to alias (backward compat with old IR)
        sm = build_semantic_model(STRUCTURED_SIMPLE)
        assert sm["measures"][0]["expr"] == "revenue_usd"  # alias fallback

    def test_model_ref_from_catalog_meta(self):
        # With catalog_meta: correct dbt model ref, schema prefix stripped
        meta = {"total_revenue": {"source": "dbt", "source_tables": ["default.stg_orders"]}}
        sm = build_semantic_model(STRUCTURED_SIMPLE, catalog_meta=meta)
        assert sm["model"] == "ref('stg_orders')"

    def test_model_ref_no_schema_prefix(self):
        # source_tables without schema prefix passes through unchanged
        meta = {"total_revenue": {"source": "dbt", "source_tables": ["stg_orders"]}}
        sm = build_semantic_model(STRUCTURED_SIMPLE, catalog_meta=meta)
        assert sm["model"] == "ref('stg_orders')"

    def test_agg_mapping_count(self):
        sm = build_semantic_model(STRUCTURED_WITH_DIM)
        assert sm["measures"][0]["agg"] == "count"

    def test_agg_mapping_avg(self):
        nps = next(m for m in ALL_9_METRICS if m["name"] == "NPS_segmented_by_tier")
        sm = build_semantic_model(nps)
        assert sm["measures"][0]["agg"] == "average"

    def test_dimension_categorical(self):
        sm = build_semantic_model(STRUCTURED_WITH_DIM)
        assert len(sm["dimensions"]) == 1
        d = sm["dimensions"][0]
        assert d["name"] == "tier"
        assert d["type"] == "categorical"
        assert "type_params" not in d

    def test_entities_from_joins(self):
        sm = build_semantic_model(STRUCTURED_MULTI_MEASURE)
        assert "entities" in sm
        entity_names = {e["name"] for e in sm["entities"]}
        assert "order_items" in entity_names
        assert "products" in entity_names

    def test_entity_primary_is_first_join_source(self):
        sm = build_semantic_model(STRUCTURED_MULTI_MEASURE)
        primary = next(e for e in sm["entities"] if e["type"] == "primary")
        assert primary["name"] == "order_items"
        assert primary["expr"] == "order_items_id"

    def test_opaque_gets_placeholder_measure(self):
        sm = build_semantic_model(OPAQUE_METRIC)
        assert len(sm["measures"]) == 1
        assert sm["measures"][0]["agg"] == "count"
        assert sm["measures"][0]["meta"]["om_opaque_placeholder"] is True

    def test_no_entities_when_no_joins(self):
        sm = build_semantic_model(STRUCTURED_SIMPLE)
        assert "entities" not in sm


# ---------------------------------------------------------------------------
# build_metric
# ---------------------------------------------------------------------------

class TestBuildMetric:
    def test_simple_type_single_measure(self):
        sm = build_semantic_model(STRUCTURED_SIMPLE)
        m = build_metric(STRUCTURED_SIMPLE, sm)
        assert m["type"] == "simple"
        assert m["type_params"] == {"measure": "revenue_usd"}

    def test_derived_type_multi_measure(self):
        sm = build_semantic_model(STRUCTURED_MULTI_MEASURE)
        m = build_metric(STRUCTURED_MULTI_MEASURE, sm)
        assert m["type"] == "derived"
        # expr must reference individual measures via measure(), not the metric itself
        expr = m["type_params"]["expr"]
        assert "measure('revenue_usd')" in expr
        assert "measure('units_sold')" in expr
        assert "metric(" not in expr  # must NOT be a self-referential metric() call

    def test_ratio_type_on_fanout(self):
        sm = build_semantic_model(STRUCTURED_FANOUT)
        m = build_metric(STRUCTURED_FANOUT, sm)
        assert m["type"] == "ratio"
        assert "numerator" in m["type_params"]
        assert "denominator" in m["type_params"]

    def test_opaque_type_derived(self):
        sm = build_semantic_model(OPAQUE_METRIC)
        m = build_metric(OPAQUE_METRIC, sm)
        assert m["type"] == "derived"
        assert m["meta"]["om_opaque"] is True

    def test_label_generation(self):
        sm = build_semantic_model(STRUCTURED_SIMPLE)
        m = build_metric(STRUCTURED_SIMPLE, sm)
        assert m["label"] == "Total Revenue"

    def test_meta_taxonomy(self):
        sm = build_semantic_model(STRUCTURED_SIMPLE)
        m = build_metric(STRUCTURED_SIMPLE, sm)
        assert m["meta"]["om_taxonomy"] == "Business › Revenue › Core"

    def test_meta_importance(self):
        sm = build_semantic_model(STRUCTURED_SIMPLE)
        m = build_metric(STRUCTURED_SIMPLE, sm)
        assert m["meta"]["om_importance"] == 7

    def test_meta_is_primary(self):
        sm = build_semantic_model(STRUCTURED_SIMPLE)
        m = build_metric(STRUCTURED_SIMPLE, sm)
        assert m["meta"]["om_is_primary"] is True

    def test_meta_generated_flag(self):
        sm = build_semantic_model(STRUCTURED_SIMPLE)
        m = build_metric(STRUCTURED_SIMPLE, sm)
        assert m["meta"]["om_generated"] is True

    def test_meta_tags(self):
        sm = build_semantic_model(STRUCTURED_SIMPLE)
        m = build_metric(STRUCTURED_SIMPLE, sm)
        assert "revenue" in m["meta"]["om_tags"]

    def test_meta_no_generated_at(self):
        # om_generated_at must not be in meta — it causes git churn.
        # The generation timestamp belongs in the file header comment only.
        sm = build_semantic_model(STRUCTURED_SIMPLE)
        m = build_metric(STRUCTURED_SIMPLE, sm)
        assert "om_generated_at" not in m["meta"]


# ---------------------------------------------------------------------------
# _yaml_str — dbt Jinja expression passthrough
# ---------------------------------------------------------------------------

class TestYamlStr:
    def test_ref_not_quoted(self):
        result = _yaml_str("ref('total_revenue')", indent=0)
        assert result == "ref('total_revenue')"
        assert result[0] != '"'

    def test_source_not_quoted(self):
        result = _yaml_str("source('schema', 'orders')", indent=0)
        assert result == "source('schema', 'orders')"
        assert result[0] != '"'

    def test_metric_expr_not_quoted(self):
        result = _yaml_str("metric('nps')", indent=0)
        assert result == "metric('nps')"
        assert result[0] != '"'

    def test_measure_expr_not_quoted(self):
        result = _yaml_str("measure('revenue_usd')", indent=0)
        assert result == "measure('revenue_usd')"
        assert result[0] != '"'

    def test_plain_string_with_special_chars_still_quoted(self):
        # A string with parens that is NOT a dbt expression must still be quoted
        result = _yaml_str("some string: with colon", indent=0)
        assert result.startswith('"')

    def test_ref_appears_bare_in_export_output(self, tmp_path):
        out_path = str(tmp_path / "metrics.yml")
        meta = {"total_revenue": {"source": "dbt", "source_tables": ["stg_orders"]}}
        _, content, _, _ = export_metricflow([STRUCTURED_SIMPLE], output_path=out_path, dry_run=True, catalog_meta=meta)
        # model: ref('stg_orders') must appear bare, not "ref('stg_orders')"
        assert "model: ref('stg_orders')" in content
        assert 'model: "ref(' not in content


# ---------------------------------------------------------------------------
# export_metricflow
# ---------------------------------------------------------------------------

class TestExportMetricflow:
    def test_dry_run_returns_content_no_file(self, tmp_path):
        out_path = str(tmp_path / "metrics.yml")
        path, content, structured, opaque = export_metricflow(
            [STRUCTURED_SIMPLE],
            output_path=out_path,
            dry_run=True,
        )
        assert not Path(out_path).exists()
        assert "semantic_models:" in content
        assert "metrics:" in content

    def test_writes_file(self, tmp_path):
        out_path = str(tmp_path / "metrics.yml")
        path, content, structured, opaque = export_metricflow(
            [STRUCTURED_SIMPLE],
            output_path=out_path,
        )
        assert Path(out_path).exists()
        written = Path(out_path).read_text()
        assert written == content

    def test_header_comment_in_output(self, tmp_path):
        out_path = str(tmp_path / "metrics.yml")
        _, content, _, _ = export_metricflow([STRUCTURED_SIMPLE], output_path=out_path, dry_run=True)
        assert "DO NOT EDIT THIS FILE MANUALLY" in content
        assert "omx export --format metricflow" in content
        assert "Generated by OM Compiler" in content

    def test_structured_count(self, tmp_path):
        out_path = str(tmp_path / "metrics.yml")
        _, _, structured, opaque = export_metricflow(
            [STRUCTURED_SIMPLE, OPAQUE_METRIC],
            output_path=out_path,
            dry_run=True,
        )
        assert structured == 1
        assert opaque == 1

    def test_all_9_metrics_no_exception(self, tmp_path):
        out_path = str(tmp_path / "metrics.yml")
        _, content, structured, opaque = export_metricflow(
            ALL_9_METRICS,
            output_path=out_path,
            dry_run=True,
        )
        assert structured == 5
        assert opaque == 4
        assert content.count("name:") >= 9  # at least 9 semantic model + metric names

    def test_output_contains_all_metric_names(self, tmp_path):
        out_path = str(tmp_path / "metrics.yml")
        _, content, _, _ = export_metricflow(ALL_9_METRICS, output_path=out_path, dry_run=True)
        for m in ALL_9_METRICS:
            assert m["name"] in content

    def test_creates_parent_dirs(self, tmp_path):
        out_path = str(tmp_path / "models" / "marts" / "metrics.yml")
        export_metricflow([STRUCTURED_SIMPLE], output_path=out_path)
        assert Path(out_path).exists()

    def test_metricflow_keys_present(self, tmp_path):
        out_path = str(tmp_path / "metrics.yml")
        _, content, _, _ = export_metricflow([STRUCTURED_SIMPLE], output_path=out_path, dry_run=True)
        assert "semantic_models:" in content
        assert "metrics:" in content
        assert "measures:" in content
        assert "om_importance:" in content
        assert "om_generated:" in content

    def test_opaque_meta_flag_in_output(self, tmp_path):
        out_path = str(tmp_path / "metrics.yml")
        _, content, _, _ = export_metricflow([OPAQUE_METRIC], output_path=out_path, dry_run=True)
        assert "om_opaque:" in content


# ---------------------------------------------------------------------------
# CLI integration
# ---------------------------------------------------------------------------

class TestExportCLI:
    def _mock_client(self, metrics: list[dict]):
        """Return a mock OM client whose compiler.status() returns given metrics."""
        client = MagicMock()
        client.__enter__ = MagicMock(return_value=client)
        client.__exit__ = MagicMock(return_value=False)
        client.compiler.status.return_value = {"metrics": metrics}
        return client

    def test_dry_run_prints_yaml_to_stdout(self, tmp_path):
        runner = CliRunner()
        with patch("onlymetrix.cli._get_client") as mock_gc:
            mock_gc.return_value = self._mock_client([STRUCTURED_SIMPLE])
            result = runner.invoke(cli, ["export", "--format", "metricflow", "--dry-run"])

        assert "semantic_models:" in result.output
        assert "metrics:" in result.output
        assert "DRY RUN" in result.output

    def test_writes_file_and_prints_summary(self, tmp_path):
        runner = CliRunner()
        out_path = str(tmp_path / "out.yml")
        with patch("onlymetrix.cli._get_client") as mock_gc:
            mock_gc.return_value = self._mock_client([STRUCTURED_SIMPLE])
            result = runner.invoke(cli, [
                "export", "--format", "metricflow",
                "--output", out_path,
            ])

        assert Path(out_path).exists()
        assert "Written:" in result.output
        assert "structured" in result.output

    def test_exit_code_0_all_structured(self, tmp_path):
        runner = CliRunner()
        out_path = str(tmp_path / "out.yml")
        with patch("onlymetrix.cli._get_client") as mock_gc:
            mock_gc.return_value = self._mock_client([STRUCTURED_SIMPLE])
            result = runner.invoke(cli, [
                "export", "--format", "metricflow",
                "--output", out_path,
            ])

        assert result.exit_code == 0

    def test_exit_code_2_with_opaque(self, tmp_path):
        runner = CliRunner()
        out_path = str(tmp_path / "out.yml")
        with patch("onlymetrix.cli._get_client") as mock_gc:
            mock_gc.return_value = self._mock_client([STRUCTURED_SIMPLE, OPAQUE_METRIC])
            result = runner.invoke(cli, [
                "export", "--format", "metricflow",
                "--output", out_path,
            ])

        assert result.exit_code == 2

    def test_summary_shows_structured_checkmark(self, tmp_path):
        runner = CliRunner()
        out_path = str(tmp_path / "out.yml")
        with patch("onlymetrix.cli._get_client") as mock_gc:
            mock_gc.return_value = self._mock_client([STRUCTURED_SIMPLE])
            result = runner.invoke(cli, [
                "export", "--format", "metricflow",
                "--output", out_path,
            ])

        assert "✓ total_revenue" in result.output
        assert "importance 7" in result.output

    def test_summary_shows_opaque_tilde(self, tmp_path):
        runner = CliRunner()
        out_path = str(tmp_path / "out.yml")
        with patch("onlymetrix.cli._get_client") as mock_gc:
            mock_gc.return_value = self._mock_client([OPAQUE_METRIC])
            result = runner.invoke(cli, [
                "export", "--format", "metricflow",
                "--output", out_path,
            ])

        assert "~ enterprise_churn_rate" in result.output

    def test_no_metrics_error(self):
        runner = CliRunner()
        with patch("onlymetrix.cli._get_client") as mock_gc:
            mock_gc.return_value = self._mock_client([])
            result = runner.invoke(cli, ["export", "--format", "metricflow", "--dry-run"])

        assert result.exit_code == 1

    def test_all_9_metrics_dry_run(self, tmp_path):
        runner = CliRunner()
        with patch("onlymetrix.cli._get_client") as mock_gc:
            mock_gc.return_value = self._mock_client(ALL_9_METRICS)
            result = runner.invoke(cli, ["export", "--format", "metricflow", "--dry-run"])

        assert result.exit_code == 2  # 4 opaque → exit 2
        assert "9 compiled metrics" in result.output
        assert "5 structured" in result.output
        assert "4 opaque" in result.output
