"""
crewai-mnemopay — MnemoPay tools for CrewAI.

Give any CrewAI agent persistent cognitive memory and micropayment capabilities
via the MnemoPay MCP server.

Quick start:
    from crewai_mnemopay import mnemopay_tools

    agent = Agent(role="Assistant", tools=mnemopay_tools())

Individual tools:
    from crewai_mnemopay import MnemoPayRememberTool, MnemoPayRecallTool

    agent = Agent(role="Assistant", tools=[MnemoPayRememberTool(), MnemoPayRecallTool()])
"""

from crewai_mnemopay.tools import (
    MnemoPayBalanceTool,
    MnemoPayChargeTool,
    MnemoPayConsolidateTool,
    MnemoPayForgetTool,
    MnemoPayHistoryTool,
    MnemoPayLogsTool,
    MnemoPayProfileTool,
    MnemoPayRecallTool,
    MnemoPayRefundTool,
    MnemoPayReinforceTool,
    MnemoPayRememberTool,
    MnemoPaySettleTool,
    mnemopay_tools,
)

__version__ = "0.1.0"

__all__ = [
    "MnemoPayBalanceTool",
    "MnemoPayChargeTool",
    "MnemoPayConsolidateTool",
    "MnemoPayForgetTool",
    "MnemoPayHistoryTool",
    "MnemoPayLogsTool",
    "MnemoPayProfileTool",
    "MnemoPayRecallTool",
    "MnemoPayRefundTool",
    "MnemoPayReinforceTool",
    "MnemoPayRememberTool",
    "MnemoPaySettleTool",
    "mnemopay_tools",
]
