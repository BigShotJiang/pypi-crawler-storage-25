# crewai-mnemopay

MnemoPay tools for [CrewAI](https://github.com/crewAIInc/crewAI) -- give any agent persistent cognitive memory and micropayment capabilities.

Built as a standalone package per [crewAI custom tool publishing guide](https://docs.crewai.com/en/guides/tools/publish-custom-tools), extracted from [crewAIInc/crewAI#5251](https://github.com/crewAIInc/crewAI/pull/5251).

## Installation

```bash
pip install crewai-mnemopay
```

The MnemoPay MCP server requires Node.js:

```bash
npm install -g @mnemopay/sdk
```

## Quick Start

```python
from crewai import Agent
from crewai_mnemopay import mnemopay_tools

agent = Agent(
    role="Research Assistant",
    goal="Help users with research and remember preferences",
    tools=mnemopay_tools(),
)
```

### Individual tools

```python
from crewai import Agent
from crewai_mnemopay import (
    MnemoPayRememberTool,
    MnemoPayRecallTool,
    MnemoPayChargeTool,
)

agent = Agent(
    role="Paid Research Assistant",
    goal="Research topics, remember findings, and charge for work",
    tools=[
        MnemoPayRememberTool(),
        MnemoPayRecallTool(),
        MnemoPayChargeTool(),
    ],
)
```

### Connect to a remote MnemoPay server

```python
from crewai_mnemopay import mnemopay_tools

tools = mnemopay_tools(server_url="https://mnemopay-mcp.fly.dev")
```

## Available Tools

### Memory Tools

| Tool | Description |
|------|-------------|
| `MnemoPayRememberTool` | Store a memory that persists across sessions |
| `MnemoPayRecallTool` | Recall memories with optional semantic search |
| `MnemoPayForgetTool` | Permanently delete a memory by ID |
| `MnemoPayReinforceTool` | Boost a memory's importance score |
| `MnemoPayConsolidateTool` | Prune stale memories below decay threshold |

### Payment Tools

| Tool | Description |
|------|-------------|
| `MnemoPayChargeTool` | Create an escrow charge for work delivered |
| `MnemoPaySettleTool` | Finalize a pending escrow transaction |
| `MnemoPayRefundTool` | Refund a transaction (docks reputation) |
| `MnemoPayBalanceTool` | Check wallet balance and reputation |
| `MnemoPayProfileTool` | Full agent stats |
| `MnemoPayHistoryTool` | Transaction history |
| `MnemoPayLogsTool` | Immutable audit trail |

## How It Works

MnemoPay communicates with the MnemoPay MCP server via JSON-RPC. By default it spawns a local server via stdio. You can also point it at a remote server URL.

**Memory** works like human cognition: memories decay over time unless reinforced. This keeps the agent's context relevant without unbounded growth.

**Payments** use escrow: agents charge after delivering value, users settle to release funds. A reputation system tracks agent trustworthiness.

## Development

```bash
git clone https://github.com/mnemopay/crewai-mnemopay.git
cd crewai-mnemopay
pip install -e ".[dev]"
pytest
```

## License

MIT
