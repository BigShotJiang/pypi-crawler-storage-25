"""Tests for crewai-mnemopay tools."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from crewai_mnemopay import (
    MnemoPayBalanceTool,
    MnemoPayChargeTool,
    MnemoPayConsolidateTool,
    MnemoPayForgetTool,
    MnemoPayHistoryTool,
    MnemoPayLogsTool,
    MnemoPayProfileTool,
    MnemoPayRecallTool,
    MnemoPayRefundTool,
    MnemoPayReinforceTool,
    MnemoPayRememberTool,
    MnemoPaySettleTool,
    mnemopay_tools,
)
from crewai_mnemopay.tools import _MCPClient, _get_client


# -- _MCPClient tests -----------------------------------------------------------------


class TestMCPClientHTTP:
    """Test HTTP transport."""

    def test_call_http_success(self):
        client = _MCPClient(server_url="http://localhost:3000")
        mock_response = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"content": [{"text": "memory stored"}]},
        }).encode()

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_ctx = MagicMock()
            mock_ctx.__enter__ = MagicMock(return_value=MagicMock(read=lambda: mock_response))
            mock_ctx.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_ctx

            result = client.call_tool("remember", {"content": "test"})
            assert result == "memory stored"

    def test_call_http_error_response(self):
        client = _MCPClient(server_url="http://localhost:3000")
        mock_response = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "error": {"code": -32600, "message": "Invalid request"},
        }).encode()

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_ctx = MagicMock()
            mock_ctx.__enter__ = MagicMock(return_value=MagicMock(read=lambda: mock_response))
            mock_ctx.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_ctx

            result = client.call_tool("remember", {"content": "test"})
            assert "Error:" in result
            assert "Invalid request" in result

    def test_call_http_network_failure(self):
        client = _MCPClient(server_url="http://localhost:3000")

        with patch("urllib.request.urlopen", side_effect=ConnectionError("refused")):
            result = client.call_tool("remember", {"content": "test"})
            assert "MCP call failed" in result

    def test_call_http_empty_content(self):
        client = _MCPClient(server_url="http://localhost:3000")
        mock_response = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"content": []},
        }).encode()

        with patch("urllib.request.urlopen") as mock_urlopen:
            mock_ctx = MagicMock()
            mock_ctx.__enter__ = MagicMock(return_value=MagicMock(read=lambda: mock_response))
            mock_ctx.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_ctx

            result = client.call_tool("balance", {})
            assert result == "OK"


class TestMCPClientStdio:
    """Test stdio transport."""

    def test_call_stdio_success(self):
        client = _MCPClient()
        mock_proc = MagicMock()
        mock_proc.poll.return_value = None
        mock_proc.stdin = MagicMock()
        response_line = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "result": {"content": [{"text": "recalled 3 memories"}]},
        }).encode() + b"\n"
        mock_proc.stdout.readline.return_value = response_line
        client._process = mock_proc

        result = client.call_tool("recall", {"limit": 3})
        assert result == "recalled 3 memories"

    def test_call_stdio_broken_pipe(self):
        client = _MCPClient()
        mock_proc = MagicMock()
        mock_proc.poll.return_value = None
        mock_proc.stdin.write.side_effect = BrokenPipeError("pipe closed")
        client._process = mock_proc

        result = client.call_tool("recall", {})
        assert "MCP call failed" in result

    def test_close_terminates_process(self):
        client = _MCPClient()
        mock_proc = MagicMock()
        mock_proc.poll.return_value = None
        client._process = mock_proc

        client.close()
        mock_proc.terminate.assert_called_once()

    def test_close_no_process(self):
        client = _MCPClient()
        client.close()  # Should not raise


class TestMCPClientRequestId:
    """Test request ID incrementing."""

    def test_request_id_increments(self):
        client = _MCPClient()
        assert client._next_id() == 1
        assert client._next_id() == 2
        assert client._next_id() == 3


# -- Tool class tests ------------------------------------------------------------------


class TestToolMetadata:
    """Verify tool names, descriptions, and schemas are set correctly."""

    def test_all_tools_have_name(self):
        tools = mnemopay_tools()
        for tool in tools:
            assert tool.name, f"Tool {type(tool).__name__} missing name"
            assert tool.name.startswith("MnemoPay ")

    def test_all_tools_have_description(self):
        tools = mnemopay_tools()
        for tool in tools:
            assert len(tool.description) > 10, f"Tool {tool.name} has short description"

    def test_mnemopay_tools_returns_12(self):
        tools = mnemopay_tools()
        assert len(tools) == 12

    def test_mnemopay_tools_with_server_url(self):
        tools = mnemopay_tools(server_url="http://example.com")
        for tool in tools:
            assert tool.server_url == "http://example.com"

    def test_tool_names_are_unique(self):
        tools = mnemopay_tools()
        names = [t.name for t in tools]
        assert len(names) == len(set(names)), "Duplicate tool names found"


class TestRememberTool:
    def test_run_with_content(self):
        tool = MnemoPayRememberTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "stored"
            result = tool._run(content="test memory")
            mock.return_value.call_tool.assert_called_once_with(
                "remember", {"content": "test memory"}
            )
            assert result == "stored"

    def test_run_with_importance(self):
        tool = MnemoPayRememberTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "stored"
            tool._run(content="important", importance=0.9)
            mock.return_value.call_tool.assert_called_once_with(
                "remember", {"content": "important", "importance": 0.9}
            )


class TestRecallTool:
    def test_run_with_query(self):
        tool = MnemoPayRecallTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "[]"
            tool._run(query="preferences", limit=3)
            mock.return_value.call_tool.assert_called_once_with(
                "recall", {"query": "preferences", "limit": 3}
            )

    def test_run_without_query(self):
        tool = MnemoPayRecallTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "[]"
            tool._run()
            mock.return_value.call_tool.assert_called_once_with("recall", {"limit": 5})


class TestForgetTool:
    def test_run(self):
        tool = MnemoPayForgetTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "deleted"
            tool._run(id="mem_123")
            mock.return_value.call_tool.assert_called_once_with(
                "forget", {"id": "mem_123"}
            )


class TestReinforceTool:
    def test_run_with_boost(self):
        tool = MnemoPayReinforceTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "boosted"
            tool._run(id="mem_123", boost=0.3)
            mock.return_value.call_tool.assert_called_once_with(
                "reinforce", {"id": "mem_123", "boost": 0.3}
            )

    def test_run_default_boost(self):
        tool = MnemoPayReinforceTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "boosted"
            tool._run(id="mem_123")
            mock.return_value.call_tool.assert_called_once_with(
                "reinforce", {"id": "mem_123", "boost": 0.1}
            )


class TestChargeTool:
    def test_run(self):
        tool = MnemoPayChargeTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "tx_abc"
            tool._run(amount=5.0, reason="Research completed")
            mock.return_value.call_tool.assert_called_once_with(
                "charge", {"amount": 5.0, "reason": "Research completed"}
            )


class TestSettleTool:
    def test_run(self):
        tool = MnemoPaySettleTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "settled"
            tool._run(txId="tx_abc")
            mock.return_value.call_tool.assert_called_once_with(
                "settle", {"txId": "tx_abc"}
            )


class TestRefundTool:
    def test_run(self):
        tool = MnemoPayRefundTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "refunded"
            tool._run(txId="tx_abc")
            mock.return_value.call_tool.assert_called_once_with(
                "refund", {"txId": "tx_abc"}
            )


class TestBalanceTool:
    def test_run(self):
        tool = MnemoPayBalanceTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "$10.00"
            result = tool._run()
            mock.return_value.call_tool.assert_called_once_with("balance", {})
            assert result == "$10.00"


class TestConsolidateTool:
    def test_run(self):
        tool = MnemoPayConsolidateTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "pruned 2"
            result = tool._run()
            mock.return_value.call_tool.assert_called_once_with("consolidate", {})
            assert result == "pruned 2"


class TestProfileTool:
    def test_run(self):
        tool = MnemoPayProfileTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "{}"
            tool._run()
            mock.return_value.call_tool.assert_called_once_with("profile", {})


class TestHistoryTool:
    def test_run(self):
        tool = MnemoPayHistoryTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "[]"
            tool._run()
            mock.return_value.call_tool.assert_called_once_with("history", {"limit": 10})


class TestLogsTool:
    def test_run(self):
        tool = MnemoPayLogsTool()
        with patch("crewai_mnemopay.tools._get_client") as mock:
            mock.return_value.call_tool.return_value = "[]"
            tool._run()
            mock.return_value.call_tool.assert_called_once_with("logs", {"limit": 20})


# -- Import tests ----------------------------------------------------------------------


class TestImports:
    """Verify the public API surface."""

    def test_import_all_tools(self):
        import crewai_mnemopay

        assert hasattr(crewai_mnemopay, "MnemoPayRememberTool")
        assert hasattr(crewai_mnemopay, "MnemoPayRecallTool")
        assert hasattr(crewai_mnemopay, "MnemoPayForgetTool")
        assert hasattr(crewai_mnemopay, "MnemoPayReinforceTool")
        assert hasattr(crewai_mnemopay, "MnemoPayConsolidateTool")
        assert hasattr(crewai_mnemopay, "MnemoPayChargeTool")
        assert hasattr(crewai_mnemopay, "MnemoPaySettleTool")
        assert hasattr(crewai_mnemopay, "MnemoPayRefundTool")
        assert hasattr(crewai_mnemopay, "MnemoPayBalanceTool")
        assert hasattr(crewai_mnemopay, "MnemoPayProfileTool")
        assert hasattr(crewai_mnemopay, "MnemoPayHistoryTool")
        assert hasattr(crewai_mnemopay, "MnemoPayLogsTool")
        assert hasattr(crewai_mnemopay, "mnemopay_tools")

    def test_version(self):
        import crewai_mnemopay

        assert crewai_mnemopay.__version__ == "0.1.0"

    def test_all_exports(self):
        import crewai_mnemopay

        assert len(crewai_mnemopay.__all__) == 13  # 12 tools + mnemopay_tools
