from setuptools import setup

setup(
    name='wifida',
    version='0.2.5',  # Increment version
    py_modules=['wifida'],
    entry_points={
        'console_scripts': [
            'wifida = wifida:main',  # Changed to 'main' (the function we created)
        ],
    },
    author='ssskingsss12',
    author_email='smalls3000i@gmail.com',
    description='WiFi deauthentication tool for security testing',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Education',
        'Intended Audience :: Information Technology',
        'Topic :: Security',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: POSIX :: Linux',
    ],
    python_requires='>=2.7',
    install_requires=[],  # No pip dependencies, uses system packages
    package_data={
        'wifida': [],  # No additional files
    },
    zip_safe=False,
)
