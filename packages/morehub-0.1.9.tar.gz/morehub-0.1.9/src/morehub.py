from __future__ import annotations

try:
    from .hub import Hub
except ImportError:
    from hub import Hub

__all__ = ["Hub"]