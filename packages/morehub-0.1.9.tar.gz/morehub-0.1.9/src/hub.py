from __future__ import annotations

import json
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence
try:
    from .runner import build_embeddings_command
except ImportError:
    from runner import build_embeddings_command

try:
    from .data_manager import infer_molecule_kind
except ImportError:
    from data_manager import infer_molecule_kind


WORKSPACE_MARKER_NAME = ".morehub_workspace.json"
VALID_PYTHON_PROVIDERS = {"pyenv", "manual"}


@dataclass
class SetupResult:
    completed: subprocess.CompletedProcess[str]
    command: list[str]
    cwd: Path


@dataclass
class EmbeddingsResult:
    completed: subprocess.CompletedProcess[str]
    command: list[str]
    cwd: Path
    output_path: Path
    run_dir: Path
    run_id: str


@dataclass
class SetupHandle:
    process: subprocess.Popen[str]
    command: list[str]
    cwd: Path


@dataclass
class EmbeddingsHandle:
    process: subprocess.Popen[str]
    command: list[str]
    cwd: Path
    output_path: Path
    run_dir: Path
    run_id: str


class Hub:
    """CLI-friendly wrapper that orchestrates model setup and embeddings runs.

    This class reuses the same setup and runner mechanics used by the GUI, but
    without importing Qt or opening windows.
    """

    def __init__(
        self,
        workspace_root: str | Path,
        *,
        metadata_root: str | Path | None = None,
        python_provider: str = "pyenv",
        python_version: str | None = None,
        python_executable: str | Path | None = None,
    ) -> None:
        self.package_root = Path(__file__).resolve().parent
        self.workspace_root = self._resolve_workspace_root(Path(workspace_root))
        self.models_root = self.workspace_root / "models"
        self.metadata_root = Path(metadata_root).resolve() if metadata_root else (self.package_root / "metadata")
        self.python_provider = self._normalize_python_provider(python_provider)
        self.python_version = self._normalize_optional_value(python_version)
        self.python_executable = str(Path(python_executable).resolve()) if python_executable else None
        self._setup_launcher_python = sys.executable

        self._ensure_workspace_layout()

    def available_models(self) -> list[str]:
        """Return model names discovered under metadata/ that contain model JSON."""
        if not self.metadata_root.exists():
            return []

        names: list[str] = []
        for entry in sorted(self.metadata_root.iterdir(), key=lambda p: p.name.lower()):
            if not entry.is_dir():
                continue
            if (entry / f"{entry.name}.json").exists() or (entry / "model.json").exists():
                names.append(entry.name.upper())
        return names

    def setup(
        self,
        model_name: str,
        *,
        download_only: bool = False,
        check: bool = True,
        stream_output: bool = True,
        env: Mapping[str, str] | None = None,
    ) -> SetupResult:
        """Run model setup.py in subprocess.

        Equivalent to GUI setup behavior for a model tab.
        """
        command, cwd = self._build_setup_command(model_name, download_only=download_only)
        completed = self._run_command(
            command,
            cwd=cwd,
            check=check,
            stream_output=stream_output,
            env=env,
        )
        return SetupResult(completed=completed, command=command, cwd=cwd)

    def setup_async(
        self,
        model_name: str,
        *,
        download_only: bool = False,
        env: Mapping[str, str] | None = None,
    ) -> SetupHandle:
        """Start model setup.py in subprocess and return process handle."""
        command, cwd = self._build_setup_command(model_name, download_only=download_only)
        process = self._spawn_command(command, cwd=cwd, env=env)
        return SetupHandle(process=process, command=command, cwd=cwd)

    def run(
        self,
        model_name: str,
        *,
        input_file: str | Path,
        output_dir: str | Path,
        output_stem: str,
        input_format: str | None = "auto",
        extra_params: Mapping[str, Any] | None = None,
        extra_args: Sequence[str] | None = None,
        check: bool = True,
        stream_output: bool = True,
        env: Mapping[str, str] | None = None,
    ) -> EmbeddingsResult:
        """Run embeddings.py for a model in its local model .venv.

        By default, ``input_format`` is resolved automatically from the input
        file using the same heuristic used by data-instance ingestion. Pass
        ``"smiles"`` or ``"selfies"`` to force an explicit format.
        """
        command, cwd, output_path, run_dir, run_id = self._build_embeddings_invocation(
            model_name=model_name,
            input_file=Path(input_file),
            input_format=input_format,
            output_dir=Path(output_dir),
            output_stem=output_stem,
            extra_params=extra_params,
            extra_args=extra_args,
        )
        completed = self._run_command(
            command,
            cwd=cwd,
            check=check,
            stream_output=stream_output,
            env=env,
        )
        return EmbeddingsResult(
            completed=completed,
            command=command,
            cwd=cwd,
            output_path=output_path,
            run_dir=run_dir,
            run_id=run_id,
        )

    def run_async(
        self,
        model_name: str,
        *,
        input_file: str | Path,
        output_dir: str | Path,
        output_stem: str,
        input_format: str | None = "auto",
        extra_params: Mapping[str, Any] | None = None,
        extra_args: Sequence[str] | None = None,
        env: Mapping[str, str] | None = None,
    ) -> EmbeddingsHandle:
        """Start embeddings.py in subprocess and return process handle.

        ``input_format`` behavior matches :meth:`run`: default auto inference,
        with optional explicit override (``"smiles"`` or ``"selfies"``).
        """
        command, cwd, output_path, run_dir, run_id = self._build_embeddings_invocation(
            model_name=model_name,
            input_file=Path(input_file),
            input_format=input_format,
            output_dir=Path(output_dir),
            output_stem=output_stem,
            extra_params=extra_params,
            extra_args=extra_args,
        )
        process = self._spawn_command(command, cwd=cwd, env=env)
        return EmbeddingsHandle(
            process=process,
            command=command,
            cwd=cwd,
            output_path=output_path,
            run_dir=run_dir,
            run_id=run_id,
        )

    def _resolve_workspace_root(self, provided: Path) -> Path:
        resolved = provided.expanduser().resolve()
        # Allow Hub(".../models") for convenience.
        if resolved.name.lower() == "models":
            return resolved.parent
        return resolved

    def _workspace_marker_path(self) -> Path:
        return self.workspace_root / WORKSPACE_MARKER_NAME

    def _ensure_workspace_layout(self) -> None:
        self.workspace_root.mkdir(parents=True, exist_ok=True)
        self.models_root.mkdir(parents=True, exist_ok=True)

        marker = self._workspace_marker_path()
        if not marker.exists():
            marker.write_text(
                json.dumps({"format": "morehub-workspace", "version": 1}, indent=2) + "\n",
                encoding="utf-8",
            )

    def _normalize_model_name(self, model_name: str) -> str:
        if not model_name or not str(model_name).strip():
            raise ValueError("model_name is required")
        normalized = str(model_name).strip().upper()
        metadata_dir = self.metadata_root / normalized
        if not metadata_dir.exists():
            raise FileNotFoundError(f"Model metadata directory not found: {metadata_dir}")
        return normalized

    def _build_setup_command(self, model_name: str, *, download_only: bool) -> tuple[list[str], Path]:
        normalized = self._normalize_model_name(model_name)
        metadata_dir = self.metadata_root / normalized
        setup_script = metadata_dir / "setup.py"
        if not setup_script.exists():
            raise FileNotFoundError(f"setup.py not found for {normalized}: {setup_script}")

        command = [
            self._setup_launcher_python,
            str(setup_script),
            "--model",
            normalized,
            "--workspace",
            str(self.workspace_root),
        ]
        command.extend(["--python-provider", self.python_provider])
        if self.python_version:
            command.extend(["--python-version", self.python_version])
        if self.python_executable:
            command.extend(["--python-executable", self.python_executable])
        if download_only:
            command.append("--download-only")

        return command, metadata_dir

    def _normalize_python_provider(self, python_provider: str) -> str:
        normalized = str(python_provider).strip().lower() or "pyenv"
        if normalized not in VALID_PYTHON_PROVIDERS:
            raise ValueError(
                f"Unsupported python_provider: {python_provider!r}. "
                "Use 'pyenv' or 'manual'."
            )
        return normalized

    def _normalize_optional_value(self, value: str | Path | None) -> str | None:
        if value is None:
            return None
        normalized = str(value).strip()
        return normalized or None

    def _build_embeddings_invocation(
        self,
        *,
        model_name: str,
        input_file: Path,
        input_format: str | None,
        output_dir: Path,
        output_stem: str,
        extra_params: Mapping[str, Any] | None,
        extra_args: Sequence[str] | None,
    ) -> tuple[list[str], Path, Path, Path, str]:
        normalized = self._normalize_model_name(model_name)

        resolved_input_file = input_file.expanduser().resolve()
        if not resolved_input_file.exists():
            raise FileNotFoundError(f"Input file not found: {resolved_input_file}")
        resolved_input_format = self._resolve_input_format(
            input_file=resolved_input_file,
            requested=input_format,
        )

        resolved_output_dir = output_dir.expanduser().resolve()
        resolved_output_dir.mkdir(parents=True, exist_ok=True)

        if not output_stem or not str(output_stem).strip():
            raise ValueError("output_stem is required")
        resolved_output_path = resolved_output_dir / f"{output_stem}.npy"

        extras = self._flatten_extra_args(extra_params=extra_params, extra_args=extra_args)

        program, args, cwd, output_path, run_dir, run_id = build_embeddings_command(
            workspace_root=self.workspace_root,
            model_name=normalized,
            input_file=resolved_input_file,
            input_format=resolved_input_format,
            output_file=resolved_output_path,
            extra_args=extras,
            metadata_root=self.metadata_root,
        )

        command = [program, *args]
        return command, Path(cwd), output_path, run_dir, run_id

    def _resolve_input_format(self, *, input_file: Path, requested: str | None) -> str:
        """Resolve runtime input format for embeddings execution.

        Accepted ``requested`` values:
        - ``None`` / ``""`` / ``"auto"``: infer from input file
        - ``"smiles"`` or ``"selfies"``: explicit override
        """
        if requested is None:
            normalized = "auto"
        else:
            normalized = str(requested).strip().lower() or "auto"

        if normalized == "auto":
            inferred = str(infer_molecule_kind(input_file)).strip().lower()
            if inferred not in {"smiles", "selfies"}:
                raise ValueError(
                    f"Could not infer input format for {input_file}. "
                    f"Expected smiles/selfies, got: {inferred!r}"
                )
            return inferred

        if normalized not in {"smiles", "selfies"}:
            raise ValueError(
                f"Unsupported input_format: {requested!r}. "
                "Use 'auto', 'smiles', or 'selfies'."
            )
        return normalized

    def _flatten_extra_args(
        self,
        *,
        extra_params: Mapping[str, Any] | None,
        extra_args: Sequence[str] | None,
    ) -> list[str]:
        args: list[str] = []

        if extra_params:
            for key, value in extra_params.items():
                if value is None or value is False:
                    continue

                flag = str(key)
                if not flag.startswith("--"):
                    flag = "--" + flag.replace("_", "-")

                if value is True:
                    args.append(flag)
                    continue

                if isinstance(value, (list, tuple)):
                    for item in value:
                        args.extend([flag, str(item)])
                    continue

                args.extend([flag, str(value)])

        if extra_args:
            args.extend(str(item) for item in extra_args)

        return args

    def _compose_env(self, env: Mapping[str, str] | None) -> dict[str, str]:
        merged = os.environ.copy()
        if env:
            merged.update({str(k): str(v) for k, v in env.items()})
        return merged

    def _run_command(
        self,
        command: list[str],
        *,
        cwd: Path,
        check: bool,
        stream_output: bool,
        env: Mapping[str, str] | None,
    ) -> subprocess.CompletedProcess[str]:
        kwargs: dict[str, Any] = {
            "cwd": str(cwd),
            "env": self._compose_env(env),
            "text": True,
            "check": check,
        }

        if not stream_output:
            kwargs["capture_output"] = True

        return subprocess.run(command, **kwargs)

    def _spawn_command(
        self,
        command: list[str],
        *,
        cwd: Path,
        env: Mapping[str, str] | None,
    ) -> subprocess.Popen[str]:
        return subprocess.Popen(
            command,
            cwd=str(cwd),
            env=self._compose_env(env),
            text=True,
        )
