﻿"""Thin COULOMB setup wrapper.

Delegates shared installation behavior to root-level core.py.
"""

import argparse
import sys
from pathlib import Path


def build_hooks():
    """Return optional hook callbacks for model-specific custom steps."""
    return {}


def main() -> None:
    parser = argparse.ArgumentParser(description="Set up COULOMB model artifacts and environment")
    parser.add_argument("--model", default="COULOMB", help="Model name (e.g., COULOMB)")
    parser.add_argument(
        "--download-only",
        action="store_true",
        help="Only download/checkpoint artifacts; skip venv/dependency installation",
    )
    parser.add_argument(
        "--workspace",
        default="",
        help="Workspace root where models/ artifacts are written",
    )
    parser.add_argument(
        "--python-provider",
        default="pyenv",
        help="Python environment provider: pyenv or manual",
    )
    parser.add_argument(
        "--python-version",
        default="",
        help="Optional Python version override or validation target",
    )
    parser.add_argument(
        "--python-executable",
        default="",
        help="Optional explicit Python interpreter path",
    )
    args = parser.parse_args()

    metadata_dir = Path(__file__).resolve().parent
    package_root = metadata_dir.parent.parent
    workspace_root = Path(args.workspace).resolve() if args.workspace else package_root

    sys.path.insert(0, str(package_root))
    from core import run_setup_pipeline

    run_setup_pipeline(
        workspace_root=workspace_root,
        metadata_dir=metadata_dir,
        model_name=args.model,
        hooks=build_hooks(),
        stage="download_only" if args.download_only else "full",
        python_provider=args.python_provider,
        python_version_override=args.python_version or None,
        python_executable_override=Path(args.python_executable).resolve() if args.python_executable else None,
    )


if __name__ == "__main__":
    main()
