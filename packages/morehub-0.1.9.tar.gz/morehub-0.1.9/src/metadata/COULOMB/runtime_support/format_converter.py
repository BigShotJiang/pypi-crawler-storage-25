﻿#!/usr/bin/env python3
"""Convert a CSV of SMILES strings into flat XYZ files for main.py.

The script reads a CSV file, generates 3D coordinates with RDKit, and writes
one .xyz file per molecule into an output folder named after the source data.
The generated folder can then be passed directly to main.py.
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

from rdkit import Chem
from rdkit.Chem import AllChem


@dataclass
class SmilesRecord:
    """One row from the input CSV."""

    index: int
    smiles: str
    name: str


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments for the CSV-to-XYZ conversion."""

    parser = argparse.ArgumentParser(
        description="Convert a CSV of SMILES strings into XYZ files."
    )
    parser.add_argument("--input", required=True, type=Path, help="Path to the CSV file.")
    parser.add_argument(
        "--output-dir",
        required=True,
        type=Path,
        help="Directory where the XYZ folder will be written.",
    )
    parser.add_argument(
        "--smiles-column",
        default="smiles",
        help="CSV column containing SMILES strings (default: smiles).",
    )
    parser.add_argument(
        "--name-column",
        default=None,
        help="Optional CSV column containing molecule names.",
    )
    parser.add_argument(
        "--max-rows",
        type=int,
        default=None,
        help="Optional limit on the number of rows to convert.",
    )
    parser.add_argument(
        "--embed-seed",
        type=int,
        default=0,
        help="Random seed for RDKit conformer generation.",
    )
    parser.add_argument(
        "--add-hydrogens",
        action="store_true",
        default=True,
        help="Add explicit hydrogens before embedding (enabled by default).",
    )
    parser.add_argument(
        "--no-add-hydrogens",
        action="store_false",
        dest="add_hydrogens",
        help="Disable addition of explicit hydrogens before embedding.",
    )
    return parser.parse_args()


def read_smiles_csv(csv_path: Path, smiles_column: str, name_column: Optional[str], max_rows: Optional[int]) -> List[SmilesRecord]:
    """Read SMILES records from a CSV file."""

    with csv_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"CSV file has no header row: {csv_path}")

        if smiles_column not in reader.fieldnames:
            raise ValueError(
                f"Missing SMILES column '{smiles_column}'. Available columns: {reader.fieldnames}"
            )

        records: List[SmilesRecord] = []
        for index, row in enumerate(reader):
            if max_rows is not None and len(records) >= max_rows:
                break

            smiles = (row.get(smiles_column) or "").strip()
            if not smiles:
                continue

            if name_column and name_column in row and row[name_column].strip():
                name = row[name_column].strip()
            else:
                name = f"molecule_{index:05d}"

            records.append(SmilesRecord(index=index, smiles=smiles, name=name))

    if not records:
        raise ValueError(f"No valid SMILES entries were found in {csv_path}")

    return records


def sanitize_filename(text: str) -> str:
    """Make a filesystem-friendly name from an arbitrary string."""

    cleaned = [character if character.isalnum() or character in ("-", "_", ".") else "_" for character in text]
    result = "".join(cleaned).strip("._")
    return result or "molecule"


def smiles_to_xyz_lines(mol: Chem.Mol) -> List[str]:
    """Convert an RDKit molecule with conformers into XYZ file lines."""

    conformer = mol.GetConformer()
    atom_lines: List[str] = []
    for atom in mol.GetAtoms():
        position = conformer.GetAtomPosition(atom.GetIdx())
        atom_lines.append(
            f"{atom.GetSymbol():<2} {position.x: .8f} {position.y: .8f} {position.z: .8f}"
        )
    return atom_lines


def write_xyz_file(output_path: Path, mol: Chem.Mol, name: str) -> None:
    """Write one RDKit molecule to an XYZ file."""

    atom_lines = smiles_to_xyz_lines(mol)
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        handle.write(f"{mol.GetNumAtoms()}\n")
        handle.write(f"{name}\n")
        for line in atom_lines:
            handle.write(f"{line}\n")


def embed_smiles(smiles: str, add_hydrogens: bool, seed: int) -> Chem.Mol:
    """Build a 3D RDKit molecule from a SMILES string."""

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Invalid SMILES: {smiles}")

    mol = Chem.Mol(mol)
    if add_hydrogens:
        mol = Chem.AddHs(mol)

    status = AllChem.EmbedMolecule(mol, randomSeed=seed)
    if status != 0:
        raise ValueError(f"RDKit failed to embed SMILES: {smiles}")

    AllChem.UFFOptimizeMolecule(mol)
    return mol


def convert_smiles_csv_to_xyz(
    csv_path: Path,
    output_root: Path,
    smiles_column: str = "smiles",
    name_column: Optional[str] = None,
    max_rows: Optional[int] = None,
    embed_seed: int = 0,
    add_hydrogens: bool = True,
) -> Tuple[Path, Path, int]:
    """Convert a SMILES CSV into a dataset folder of XYZ files.

    Returns a tuple of (xyz_dir, manifest_path, converted_count).
    """

    output_root.mkdir(parents=True, exist_ok=True)

    dataset_name = sanitize_filename(csv_path.stem)
    xyz_dir = output_root / dataset_name
    xyz_dir.mkdir(parents=True, exist_ok=True)

    records = read_smiles_csv(csv_path, smiles_column, name_column, max_rows)

    manifest_path = xyz_dir / "metadata.csv"
    with manifest_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["index", "name", "smiles", "xyz_file"])
        writer.writeheader()

        for record in records:
            mol = embed_smiles(record.smiles, add_hydrogens=add_hydrogens, seed=embed_seed)
            file_name = f"{record.index:05d}_{sanitize_filename(record.name)}.xyz"
            xyz_path = xyz_dir / file_name
            write_xyz_file(xyz_path, mol, record.name)
            writer.writerow(
                {
                    "index": record.index,
                    "name": record.name,
                    "smiles": record.smiles,
                    "xyz_file": str(xyz_path),
                }
            )

    return xyz_dir, manifest_path, len(records)


def main() -> None:
    """Convert CSV SMILES to a folder of XYZ files."""

    args = parse_args()
    xyz_dir, manifest_path, converted_count = convert_smiles_csv_to_xyz(
        csv_path=args.input,
        output_root=args.output_dir,
        smiles_column=args.smiles_column,
        name_column=args.name_column,
        max_rows=args.max_rows,
        embed_seed=args.embed_seed,
        add_hydrogens=args.add_hydrogens,
    )

    print(f"Saved XYZ files to: {xyz_dir}")
    print(f"Saved manifest to:  {manifest_path}")
    print(f"Converted molecules: {converted_count}")


if __name__ == "__main__":
    main()
