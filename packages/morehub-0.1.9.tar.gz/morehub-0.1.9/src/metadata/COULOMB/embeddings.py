from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
import shutil
from typing import Any, Dict, List, Sequence, Tuple

import numpy as np
from numba import njit, prange
from rdkit import Chem

from embeddings_preprocess import (
    load_input_lines,
    preprocess_lines,
    resolve_output_paths,
    write_failures_csv,
    write_mapping_csv,
)
from format_converter import embed_smiles, sanitize_filename, write_xyz_file


_PERIODIC_TABLE = Chem.GetPeriodicTable()


@dataclass
class Molecule:
    """Container for one molecule's charges and 3D coordinates."""

    atomic_charges: np.ndarray
    coordinates: np.ndarray


def symbol_to_atomic_number(symbol: str) -> int:
    raw = str(symbol).strip()
    if not raw:
        raise ValueError("Empty element symbol in XYZ input.")

    if raw.isdigit():
        z = int(raw)
        if 1 <= z <= 118:
            return z

    canonical = raw[0].upper() + raw[1:].lower()
    z = int(_PERIODIC_TABLE.GetAtomicNumber(canonical))
    if z > 0:
        return z

    raise ValueError(f"Unsupported element symbol '{symbol}'.")


def load_xyz_file(path: Path) -> Molecule:
    with path.open("r", encoding="utf-8") as handle:
        lines = [line.strip() for line in handle if line.strip()]

    if len(lines) < 3:
        raise ValueError(f"File {path} does not look like a valid XYZ file.")

    try:
        natoms = int(lines[0])
    except ValueError as exc:
        raise ValueError(f"First line of {path} must be the atom count.") from exc

    atom_lines = lines[2 : 2 + natoms]
    if len(atom_lines) != natoms:
        raise ValueError(f"File {path} is truncated: expected {natoms} atom lines.")

    atomic_charges = np.zeros(natoms, dtype=np.float64)
    coordinates = np.zeros((natoms, 3), dtype=np.float64)

    for i, line in enumerate(atom_lines):
        parts = line.split()
        if len(parts) < 4:
            raise ValueError(f"Malformed atom line in {path}: '{line}'")
        atomic_charges[i] = symbol_to_atomic_number(parts[0])
        coordinates[i, 0] = float(parts[1])
        coordinates[i, 1] = float(parts[2])
        coordinates[i, 2] = float(parts[3])

    return Molecule(atomic_charges=atomic_charges, coordinates=coordinates)


def _failure_from_record(record: Dict[str, Any], reason: str) -> Dict[str, Any]:
    failure: Dict[str, Any] = {
        "original_line": str(record.get("original_line", "")),
        "input_text": record.get("input_text", ""),
        "reason": reason,
    }
    if "source_type" in record:
        failure["source_type"] = record.get("source_type")
    if "source_header" in record:
        failure["source_header"] = record.get("source_header")
    if "source_row" in record:
        failure["source_row"] = record.get("source_row")
    return failure


def _convert_records_to_xyz(
    records: List[Dict[str, Any]],
    xyz_dir: Path,
    add_hydrogens: bool,
    embed_seed: int,
) -> Tuple[List[Path], List[Dict[str, Any]], List[Dict[str, Any]]]:
    xyz_dir.mkdir(parents=True, exist_ok=True)
    xyz_paths: List[Path] = []
    kept_records: List[Dict[str, Any]] = []
    failures: List[Dict[str, Any]] = []

    for idx, record in enumerate(records):
        smiles = str(record.get("smiles", "")).strip()
        if not smiles:
            failures.append(_failure_from_record(record, "missing_smiles_after_preprocess"))
            continue
        try:
            molecule = embed_smiles(smiles, add_hydrogens=add_hydrogens, seed=embed_seed)
            name = sanitize_filename(f"{idx:06d}_line_{record.get('original_line', idx + 1)}")
            xyz_path = xyz_dir / f"{name}.xyz"
            write_xyz_file(xyz_path, molecule, name)
            xyz_paths.append(xyz_path)
            kept_records.append(record)
        except Exception as exc:
            failures.append(_failure_from_record(record, f"xyz_conversion_failed: {exc}"))

    return xyz_paths, kept_records, failures


@njit(cache=True)
def euclidean_distance(coords_i: np.ndarray, coords_j: np.ndarray) -> float:
    dx = coords_i[0] - coords_j[0]
    dy = coords_i[1] - coords_j[1]
    dz = coords_i[2] - coords_j[2]
    return np.sqrt(dx * dx + dy * dy + dz * dz)


@njit(cache=True)
def extract_lower_triangle_diagonal(matrix: np.ndarray) -> np.ndarray:
    size = matrix.shape[0]
    result = np.zeros(size * (size + 1) // 2, dtype=np.float64)
    idx = 0
    for i in range(size):
        for j in range(i + 1):
            result[idx] = matrix[i, j]
            idx += 1
    return result


@njit(cache=True)
def generate_coulomb_matrix(
    atomic_charges: np.ndarray,
    coordinates: np.ndarray,
    size: int,
) -> np.ndarray:
    natoms = atomic_charges.shape[0]
    if natoms > size:
        raise ValueError("Number of atoms exceeds requested Coulomb matrix size.")

    cm = np.zeros((natoms, natoms), dtype=np.float64)
    summation = np.zeros(natoms, dtype=np.float64)

    for i in range(natoms):
        for j in range(i, natoms):
            if i == j:
                cm[i, j] = 0.5 * (atomic_charges[i] ** 2.4)
            else:
                dist = euclidean_distance(coordinates[i, :], coordinates[j, :])
                cm[i, j] = (atomic_charges[i] * atomic_charges[j]) / dist
                cm[j, i] = cm[i, j]
                summation[j] += cm[i, j] ** 2
            summation[i] += cm[i, j] ** 2

    sorted_indices = np.argsort(summation)[::-1]
    sorted_mat = cm[sorted_indices][:, sorted_indices]

    padded = np.zeros((size, size), dtype=np.float64)
    padded[:natoms, :natoms] = sorted_mat
    return extract_lower_triangle_diagonal(padded)


@njit(cache=True)
def calculate_pair_norm(coords_i, coords_j, charge_i, charge_j):
    return charge_i * charge_j / euclidean_distance(coords_i, coords_j)


@njit(cache=True)
def get_indices(nuclear_charges: np.ndarray, atom_type: int) -> np.ndarray:
    n = 0
    type_indices = np.zeros(nuclear_charges.shape[0], dtype=np.int64)
    for j in range(nuclear_charges.shape[0]):
        if nuclear_charges[j] == atom_type:
            type_indices[n] = j
            n += 1
    return type_indices[:n]


def get_bob_bags(
    nuclear_charges_list: Sequence[np.ndarray],
    elements: np.ndarray,
) -> np.ndarray:
    bags = np.zeros(elements.shape[0], dtype=np.int64)
    for nuclear_charges in nuclear_charges_list:
        for element_id, element in enumerate(elements):
            element_count = np.where(nuclear_charges == element)[0].shape[0]
            bags[element_id] = max(element_count, bags[element_id])
    return bags


def compute_ncm(bags: np.ndarray) -> int:
    ncm = 0
    for i in range(len(bags)):
        ncm += bags[i] * (1 + bags[i])
        for j in range(i):
            ncm += 2 * bags[i] * bags[j]
    return ncm // 2


def get_coulomb_size(molecules: Sequence[Molecule]) -> int:
    return max(mol.atomic_charges.shape[0] for mol in molecules)


@njit(parallel=True, cache=True)
def generate_bob(
    nuclear_charges: np.ndarray,
    coordinates: np.ndarray,
    bags: np.ndarray,
    ncm: int,
    elements: np.ndarray,
) -> np.ndarray:
    natoms = nuclear_charges.shape[0]
    nelements = elements.shape[0]
    pair_distance_matrix = np.zeros((natoms, natoms), dtype=np.float64)

    for i in prange(natoms):
        for j in range(i + 1, natoms):
            pair_distance_matrix[i, j] = calculate_pair_norm(
                coordinates[i], coordinates[j], nuclear_charges[i], nuclear_charges[j]
            )
            pair_distance_matrix[j, i] = pair_distance_matrix[i, j]

    cm = np.zeros(ncm, dtype=np.float64)
    start_indices = np.zeros(nelements, dtype=np.int64)

    start_indices[0] = 0
    for i in range(1, nelements):
        start_indices[i] = start_indices[i - 1] + (bags[i - 1] * (bags[i - 1] + 1)) // 2
        for j in range(i, nelements):
            start_indices[i] += bags[j] * bags[i - 1]

    for i in range(nelements):
        type1 = elements[i]
        type1_indices = get_indices(nuclear_charges, type1)
        natoms1 = len(type1_indices)

        bag = np.zeros(bags[i] * (bags[i] - 1) // 2, dtype=np.float64)

        for j in prange(natoms1):
            idx1 = type1_indices[j]
            cm[start_indices[i] + j] = 0.5 * nuclear_charges[idx1] ** 2.4
            k = (j * j - j) // 2
            for l in range(j):
                idx2 = type1_indices[l]
                bag[k + l] = pair_distance_matrix[idx1, idx2]

        start_indices[i] += bags[i]

        nbag = (bags[i] * bags[i] - bags[i]) // 2
        cm[start_indices[i] : start_indices[i] + nbag] = np.sort(bag[:nbag])[::-1]
        start_indices[i] += nbag

        for j in range(i + 1, nelements):
            type2 = elements[j]
            type2_indices = get_indices(nuclear_charges, type2)
            natoms2 = len(type2_indices)

            bag = np.zeros(bags[i] * bags[j], dtype=np.float64)
            for k in prange(natoms1):
                idx1 = type1_indices[k]
                for l in range(natoms2):
                    idx2 = type2_indices[l]
                    bag[natoms2 * k + l] = pair_distance_matrix[idx1, idx2]

            nbag = bags[i] * bags[j]
            cm[start_indices[i] : start_indices[i] + nbag] = np.sort(bag[:nbag])[::-1]
            start_indices[i] += nbag

    return cm


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate Coulomb or Bag-of-Bonds embeddings.")
    parser.add_argument("--file", required=True, type=Path, help="Path to input file.")
    parser.add_argument(
        "--input-format",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Format of rows in input file.",
    )
    parser.add_argument(
        "--model-input-type",
        default="smiles",
        choices=["selfies", "smiles"],
        help="Expected model input type from metadata.",
    )
    parser.add_argument("--output-dir", type=Path, default=Path("."), help="Directory for outputs.")
    parser.add_argument("--output-stem", default="embeddings", help="Base output filename stem.")
    parser.add_argument(
        "--variant",
        default="bob",
        choices=["bob", "coulomb"],
        help="Embedding representation variant.",
    )
    parser.add_argument(
        "--embed-seed",
        type=int,
        default=0,
        help="Random seed for RDKit conformer generation.",
    )
    parser.add_argument(
        "--add-hydrogens",
        action="store_true",
        default=True,
        help="Add explicit hydrogens before embedding (enabled by default).",
    )
    parser.add_argument(
        "--no-add-hydrogens",
        action="store_false",
        dest="add_hydrogens",
        help="Disable explicit hydrogens before embedding.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    input_path = Path(args.file).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    npy_path, map_path, failures_path = resolve_output_paths(output_dir, args.output_stem)

    lines = load_input_lines(input_path)
    preprocessed_records, failures = preprocess_lines(
        lines,
        input_format=args.input_format,
        model_input_type=args.model_input_type,
    )

    if not preprocessed_records:
        np.save(str(npy_path), np.empty((0, 0), dtype=np.float32))
        write_mapping_csv(map_path, [])
        write_failures_csv(failures_path, failures)
        print("No valid molecules after preprocessing. Saved empty outputs.")
        return

    xyz_dir = output_dir / f"{args.output_stem}_xyz"
    if xyz_dir.exists():
        shutil.rmtree(xyz_dir, ignore_errors=True)

    xyz_paths, valid_records, xyz_failures = _convert_records_to_xyz(
        preprocessed_records,
        xyz_dir=xyz_dir,
        add_hydrogens=bool(args.add_hydrogens),
        embed_seed=int(args.embed_seed),
    )
    failures.extend(xyz_failures)

    if not xyz_paths:
        np.save(str(npy_path), np.empty((0, 0), dtype=np.float32))
        write_mapping_csv(map_path, [])
        write_failures_csv(failures_path, failures)
        print("No molecules could be converted to XYZ. Saved empty outputs.")
        return

    molecules = [load_xyz_file(path) for path in xyz_paths]
    representation = str(args.variant).strip().lower()

    if representation == "coulomb":
        coulomb_size = get_coulomb_size(molecules)
        embeddings = np.vstack(
            [
                generate_coulomb_matrix(mol.atomic_charges, mol.coordinates, size=coulomb_size)
                for mol in molecules
            ]
        )
    elif representation == "bob":
        unique_elements = sorted({int(z) for mol in molecules for z in mol.atomic_charges.astype(np.int64)})
        elements = np.asarray(unique_elements, dtype=np.int64)
        print(f"Auto-selected BoB elements: {unique_elements}")
        nuclear_charges_list = [mol.atomic_charges.astype(np.int64) for mol in molecules]
        bags = get_bob_bags(nuclear_charges_list, elements)
        ncm = compute_ncm(bags)

        embeddings = np.vstack(
            [
                generate_bob(
                    mol.atomic_charges.astype(np.int64),
                    mol.coordinates,
                    bags=bags,
                    ncm=ncm,
                    elements=elements,
                )
                for mol in molecules
            ]
        )

        np.save(output_dir / "bob_bags.npy", bags)
        np.save(output_dir / "bob_elements.npy", elements)
    else:
        raise ValueError(f"Unsupported representation variant: {representation}")

    np.save(str(npy_path), embeddings.astype(np.float32, copy=False))
    write_mapping_csv(map_path, valid_records)
    write_failures_csv(failures_path, failures)

    print(f"Saved embeddings to: {npy_path}")
    print(f"Saved failures to:   {failures_path}")


if __name__ == "__main__":
    main()





