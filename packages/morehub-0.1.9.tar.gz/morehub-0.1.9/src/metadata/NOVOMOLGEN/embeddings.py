import argparse
import inspect
import os
import sys
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import torch
import torch.nn.functional as F

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_HF_HOME = SCRIPT_DIR / ".cache" / "huggingface"
DEFAULT_TRANSFORMERS_CACHE = DEFAULT_HF_HOME / "transformers"

MODEL_VARIANTS: Dict[str, Dict[str, str]] = {
    "32m-atomwise": {
        "repo_id": "chandar-lab/NovoMolGen_32M_SMILES_AtomWise",
        "cache_subdir": "NovoMolGen_32M_SMILES_AtomWise",
        "revision": "hf-checkpoint",
    },
    "157m-atomwise": {
        "repo_id": "chandar-lab/NovoMolGen_157M_SMILES_AtomWise",
        "cache_subdir": "NovoMolGen_157M_SMILES_AtomWise",
        "revision": "hf-checkpoint",
    },
    "300m-atomwise": {
        "repo_id": "chandar-lab/NovoMolGen_300M_SMILES_AtomWise",
        "cache_subdir": "NovoMolGen_300M_SMILES_AtomWise",
        "revision": "hf-checkpoint",
    },
    "32m-bpe": {
        "repo_id": "chandar-lab/NovoMolGen_32M_SMILES_BPE",
        "cache_subdir": "NovoMolGen_32M_SMILES_BPE",
        "revision": "hf-checkpoint",
    },
    "157m-bpe": {
        "repo_id": "chandar-lab/NovoMolGen_157M_SMILES_BPE",
        "cache_subdir": "NovoMolGen_157M_SMILES_BPE",
        "revision": "hf-checkpoint",
    },
    "300m-bpe": {
        "repo_id": "chandar-lab/NovoMolGen_300M_SMILES_BPE",
        "cache_subdir": "NovoMolGen_300M_SMILES_BPE",
        "revision": "hf-checkpoint",
    },
}

# Ensure huggingface cache is model-local by default.
os.environ.setdefault("HF_HOME", str(DEFAULT_HF_HOME))
os.environ.setdefault("TRANSFORMERS_CACHE", str(DEFAULT_TRANSFORMERS_CACHE))
os.environ.setdefault("HF_HUB_CACHE", str(DEFAULT_HF_HOME / "hub"))
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
os.environ.setdefault("HF_HUB_DISABLE_IMPLICIT_TOKEN", "1")

try:
    from transformers import AutoModelForCausalLM, AutoTokenizer  # type: ignore
except Exception as exc:
    raise ImportError(
        "Could not import transformers AutoTokenizer/AutoModelForCausalLM. "
        "Ensure NOVOMOLGEN setup completed successfully."
    ) from exc


PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from embeddings_preprocess import (
    load_input_lines,
    preprocess_lines,
    resolve_output_paths,
    write_failures_csv,
    write_mapping_csv,
)


def _normalize_variant(variant: str) -> str:
    normalized = variant.strip().lower()
    if normalized not in MODEL_VARIANTS:
        allowed = ", ".join(sorted(MODEL_VARIANTS.keys()))
        raise ValueError(f"Unsupported NOVOMOLGEN variant: {variant}. Allowed: {allowed}")
    return normalized


def _resolve_device(device_arg: str) -> torch.device:
    normalized = device_arg.strip().lower()
    if normalized == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if normalized not in {"cpu", "cuda"}:
        raise ValueError(f"Unsupported device: {device_arg}")
    if normalized == "cuda" and not torch.cuda.is_available():
        print("CUDA requested but unavailable; falling back to CPU.", file=sys.stderr)
        return torch.device("cpu")
    return torch.device(normalized)


def _resolve_model_source(
    model_path: str,
    variant: str,
) -> Tuple[str, bool]:
    explicit = model_path.strip()
    if explicit:
        candidate = Path(explicit).expanduser()
        if candidate.exists():
            return str(candidate.resolve()), True
        return explicit, False

    variant_cfg = MODEL_VARIANTS[variant]
    local_dir = DEFAULT_HF_HOME / variant_cfg["cache_subdir"]
    if local_dir.exists():
        return str(local_dir.resolve()), True

    return variant_cfg["repo_id"], False


def _resolve_revision(variant: str, revision_override: str) -> str:
    override = revision_override.strip()
    if override:
        return override
    return MODEL_VARIANTS[variant]["revision"]


def _build_model(
    model_source: str,
    revision: str,
    local_files_only: bool,
    device: torch.device,
):
    tokenizer = AutoTokenizer.from_pretrained(
        model_source,
        trust_remote_code=True,
        local_files_only=local_files_only,
        revision=revision,
    )

    if tokenizer.pad_token is None and tokenizer.eos_token is not None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        model_source,
        trust_remote_code=True,
        local_files_only=local_files_only,
        revision=revision,
    ).to(device).eval()

    forward_params = set(inspect.signature(model.forward).parameters.keys())
    return tokenizer, model, forward_params


@torch.inference_mode()
def _encode_batches(
    model_inputs: List[str],
    model,
    tokenizer,
    model_forward_params: set[str],
    device: torch.device,
    batch_size: int,
    max_length: int,
    normalize: bool,
) -> np.ndarray:
    chunks = []

    for start in range(0, len(model_inputs), batch_size):
        batch_texts = model_inputs[start : start + batch_size]
        encoded = tokenizer(
            batch_texts,
            padding=True,
            truncation=True,
            max_length=max_length,
            return_tensors="pt",
        )

        model_payload = {
            key: value.to(device)
            for key, value in encoded.items()
            if key in model_forward_params
        }

        outputs = model(
            **model_payload,
            output_hidden_states=True,
            return_dict=True,
        )

        last_hidden = outputs.hidden_states[-1]
        attention_mask = encoded.get("attention_mask")
        if attention_mask is None:
            attention_mask = torch.ones(last_hidden.shape[:2], dtype=torch.long)

        mask = attention_mask.to(device).unsqueeze(-1).type_as(last_hidden)
        emb = (last_hidden * mask).sum(1) / mask.sum(1).clamp(min=1e-6)

        if normalize:
            emb = F.normalize(emb, dim=-1)

        chunks.append(emb.cpu().numpy().astype(np.float32, copy=False))

    if not chunks:
        raise RuntimeError("No embeddings were produced by NOVOMOLGEN.")
    return np.concatenate(chunks, axis=0)


def main() -> None:
    parser = argparse.ArgumentParser(description="Encode molecules with NOVOMOLGEN and save embeddings")
    parser.add_argument("--file", required=True, help="Path to input .txt file")
    parser.add_argument(
        "--input-format",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Format of rows in input file",
    )
    parser.add_argument(
        "--model-input-type",
        default="smiles",
        choices=["selfies", "smiles"],
        help="Expected model input type from metadata",
    )
    parser.add_argument("--output-dir", default=".", help="Directory to write outputs")
    parser.add_argument("--output-stem", default="embeddings", help="Base output filename stem")
    parser.add_argument(
        "--variant",
        default="32m-atomwise",
        choices=sorted(MODEL_VARIANTS.keys()),
        help="NovoMolGen checkpoint variant",
    )
    parser.add_argument(
        "--model-path",
        default="",
        help="Optional explicit local model directory (highest priority)",
    )
    parser.add_argument(
        "--revision",
        default="",
        help="Optional model revision override (defaults to variant revision)",
    )
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--max-length", type=int, default=256)
    parser.add_argument(
        "--device",
        default="auto",
        choices=["auto", "cpu", "cuda"],
        help="Inference device",
    )
    parser.add_argument(
        "--no-normalize",
        dest="normalize",
        action="store_false",
        help="Disable L2-normalization before saving",
    )
    parser.set_defaults(normalize=True)
    args = parser.parse_args()

    input_path = Path(args.file).resolve()
    if not input_path.exists():
        print(f"Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    output_dir = Path(args.output_dir).resolve()
    npy_path, map_path, fail_path = resolve_output_paths(output_dir, args.output_stem)

    lines = load_input_lines(input_path)
    records, failures = preprocess_lines(lines, args.input_format, args.model_input_type)
    if not records:
        print("No valid molecules after circularity validation. Aborting.", file=sys.stderr)
        if failures:
            print(f"Failures: {len(failures)} (see {fail_path})", file=sys.stderr)
            write_failures_csv(fail_path, failures)
        sys.exit(1)

    model_inputs = [record["model_input"] for record in records]

    variant = _normalize_variant(args.variant)
    model_source, local_files_only = _resolve_model_source(
        model_path=args.model_path,
        variant=variant,
    )
    revision = _resolve_revision(variant, args.revision)
    device = _resolve_device(args.device)

    tokenizer, model, model_forward_params = _build_model(
        model_source=model_source,
        revision=revision,
        local_files_only=local_files_only,
        device=device,
    )

    embeddings = _encode_batches(
        model_inputs=model_inputs,
        model=model,
        tokenizer=tokenizer,
        model_forward_params=model_forward_params,
        device=device,
        batch_size=args.batch_size,
        max_length=args.max_length,
        normalize=args.normalize,
    )

    np.save(npy_path, embeddings)
    write_mapping_csv(map_path, records)
    if failures:
        write_failures_csv(fail_path, failures)

    print(f"Saved embeddings to {npy_path} with shape {embeddings.shape}.")
    print(f"Saved row mapping to {map_path}.")
    print(f"NovoMolGen variant: {variant}")
    print(f"Model source: {model_source} (local_files_only={local_files_only})")
    print(f"Revision: {revision}")
    if failures:
        print(f"Filtered {len(failures)} invalid rows. See {fail_path}.")


if __name__ == "__main__":
    main()
