from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

try:
    from rdkit import Chem
    from rdkit.Chem import rdFingerprintGenerator
except Exception as exc:  # pragma: no cover
    raise ImportError("RDKit is required for MORGAN embeddings. Install rdkit in the model venv.") from exc

from embeddings_preprocess import (
    load_input_lines,
    preprocess_lines,
    resolve_output_paths,
    write_failures_csv,
    write_mapping_csv,
)


def _failure_from_record(record: dict[str, object], reason: str) -> dict[str, object]:
    failure: dict[str, object] = {
        "original_line": str(record.get("original_line", "")),
        "input_text": record.get("input_text", ""),
        "reason": reason,
    }
    if "source_type" in record:
        failure["source_type"] = record.get("source_type")
    if "source_header" in record:
        failure["source_header"] = record.get("source_header")
    if "source_row" in record:
        failure["source_row"] = record.get("source_row")
    return failure


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate Morgan fingerprint embeddings")
    parser.add_argument("--file", required=True, help="Path to input file (.txt or .csv)")
    parser.add_argument(
        "--input-format",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Format of rows in input file",
    )
    parser.add_argument(
        "--model-input-type",
        default="smiles",
        choices=["selfies", "smiles"],
        help="Expected model input type from metadata",
    )
    parser.add_argument("--output-dir", default=".", help="Directory to write outputs")
    parser.add_argument("--output-stem", default="embeddings", help="Base output filename stem")
    parser.add_argument("--radius", type=int, default=2, help="Morgan fingerprint radius")
    parser.add_argument("--fp-size", type=int, default=2048, help="Morgan fingerprint size")
    parser.add_argument("--count-fp", action="store_true", help="Use count fingerprints")
    parser.add_argument("--include-chirality", action="store_true", help="Include chirality")
    parser.add_argument("--no-bond-types", action="store_true", help="Disable bond type encoding")
    parser.add_argument("--skip-invalid", action="store_true", help="Skip invalid molecules after preprocess")
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    input_path = Path(args.file).resolve()
    if not input_path.exists():
        print(f"Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    output_dir = Path(args.output_dir).resolve()
    npy_path, map_path, fail_path = resolve_output_paths(output_dir, args.output_stem)

    lines = load_input_lines(input_path)
    records, failures = preprocess_lines(lines, args.input_format, args.model_input_type)

    if not records:
        print("No valid molecules after circularity validation. Aborting.", file=sys.stderr)
        if failures:
            write_failures_csv(fail_path, failures)
            print(f"Failures: {len(failures)} (see {fail_path})", file=sys.stderr)
        sys.exit(1)

    generator = rdFingerprintGenerator.GetMorganGenerator(
        radius=int(args.radius),
        fpSize=int(args.fp_size),
        countSimulation=bool(args.count_fp),
        includeChirality=bool(args.include_chirality),
        useBondTypes=not bool(args.no_bond_types),
    )

    embeddings: list[np.ndarray] = []
    kept_records: list[dict[str, object]] = []

    for record in records:
        smiles = str(record.get("smiles", "")).strip()
        molecule = Chem.MolFromSmiles(smiles)
        if molecule is None:
            failures.append(_failure_from_record(record, "invalid_smiles_for_morgan"))
            if args.skip_invalid:
                continue
            write_failures_csv(fail_path, failures)
            print("Encountered invalid SMILES after preprocess. Use --skip-invalid to continue.", file=sys.stderr)
            sys.exit(1)

        if args.count_fp:
            fp = generator.GetCountFingerprintAsNumPy(molecule)
        else:
            fp = generator.GetFingerprintAsNumPy(molecule)

        embeddings.append(np.asarray(fp, dtype=np.int32))
        kept_records.append(record)

    if not embeddings:
        print("No fingerprints were generated. Aborting.", file=sys.stderr)
        if failures:
            write_failures_csv(fail_path, failures)
        sys.exit(1)

    matrix = np.stack(embeddings, axis=0)
    np.save(npy_path, matrix)
    write_mapping_csv(map_path, kept_records)
    if failures:
        write_failures_csv(fail_path, failures)

    print(f"Saved embeddings to {npy_path} with shape {matrix.shape}.")
    print(f"Saved row mapping to {map_path}.")
    if failures:
        print(f"Filtered {len(failures)} invalid rows. See {fail_path}.")


if __name__ == "__main__":
    main()