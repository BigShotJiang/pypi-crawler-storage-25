﻿#!/usr/bin/env python
"""Generate ChemFormer embeddings under MoreHub CLI-v2 protocol."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch

from importlib.abc import Loader, MetaPathFinder
from importlib.machinery import ModuleSpec

from embeddings_preprocess import (
    load_input_lines,
    preprocess_lines,
    resolve_output_paths,
    write_failures_csv,
    write_mapping_csv,
)


class _DeepspeedShimLoader(Loader):
    """Provide placeholder objects for checkpoints that reference DeepSpeed."""

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        module.__dict__.setdefault("__path__", [])
        module.__dict__.setdefault("__all__", [])
        module.__dict__.setdefault("__version__", "0.0-shim")

        def __getattr__(name):
            placeholder = type(
                name,
                (),
                {
                    "__module__": module.__name__,
                    "__init__": lambda self, *args, **kwargs: None,
                    "__repr__": lambda self: "<%s.%s shim>" % (module.__name__, name),
                },
            )
            setattr(module, name, placeholder)
            return placeholder

        module.__getattr__ = __getattr__


class _DeepspeedShimFinder(MetaPathFinder):
    """Intercept DeepSpeed imports so old checkpoints can be loaded."""

    def find_spec(self, fullname, path, target=None):
        if fullname == "deepspeed" or fullname.startswith("deepspeed."):
            return ModuleSpec(fullname, _DeepspeedShimLoader(), is_package=True)
        return None


if not any(isinstance(finder, _DeepspeedShimFinder) for finder in sys.meta_path):
    sys.meta_path.insert(0, _DeepspeedShimFinder())


try:
    from molbart.models.transformer_models import BARTModel
    from molbart.utils.tokenizers import ChemformerTokenizer
except Exception as exc:
    raise ImportError(
        "Could not import ChemFormer modules from molbart. Ensure editable install completed successfully."
    ) from exc


VARIANT_TO_SUBDIR: Dict[str, Tuple[str, ...]] = {
    "pretrained/combined-large": ("pre-trained", "combined-large"),
    "pretrained/combined": ("pre-trained", "combined"),
    "pretrained/augment": ("pre-trained", "augment"),
    "pretrained/mask": ("pre-trained", "mask"),
    "finetuned/uspto_sep": ("fined-tuned", "uspto_sep"),
    "finetuned/uspto_mixed": ("fined-tuned", "uspto_mixed"),
    "finetuned/uspto_50": ("fined-tuned", "uspto_50"),
    "randinit/uspto_sep": ("rand_init_downstream", "uspto_sep"),
    "randinit/uspto_50": ("rand_init_downstream", "uspto_50"),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Encode molecules with ChemFormer and save embeddings")
    parser.add_argument("--file", required=True, help="Path to input file (.txt or .csv)")
    parser.add_argument(
        "--input-format",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Format of rows in input file",
    )
    parser.add_argument(
        "--model-input-type",
        default="smiles",
        choices=["selfies", "smiles"],
        help="Expected model input type from metadata",
    )
    parser.add_argument("--output-dir", default=".", help="Directory to write outputs")
    parser.add_argument("--output-stem", default="embeddings", help="Base output filename stem")
    parser.add_argument(
        "--variant",
        default="pretrained/combined",
        choices=sorted(VARIANT_TO_SUBDIR.keys()),
        help="ChemFormer checkpoint variant",
    )
    parser.add_argument(
        "--model-root",
        default=None,
        help="Optional checkpoint root override (contains pre-trained/, fined-tuned/, rand_init_downstream/)",
    )
    parser.add_argument("--vocab-path", default=None, help="Optional path to vocabulary JSON")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    parser.add_argument("--normalize", action="store_true", help="Apply L2 normalization")
    parser.add_argument(
        "--pooling",
        default="auto",
        choices=["auto", "mean", "task_token"],
        help=(
            "Embedding extraction mode. "
            "'auto' chooses a variant-specific task token when available; otherwise mean."
        ),
    )
    parser.add_argument(
        "--task-token",
        default=None,
        help=(
            "Optional explicit task token. "
            "When omitted and pooling=auto, a variant-specific default token is selected if possible."
        ),
    )
    parser.add_argument(
        "--list-task-tokens",
        action="store_true",
        help="List discovered task-token candidates for the selected variant and exit.",
    )
    return parser.parse_args()


def _resolve_repo_dir(script_dir: Path) -> Path:
    candidates = [
        (script_dir / ".repo" / "Chemformer").resolve(),
        (script_dir / "Chemformer").resolve(),
    ]
    for candidate in candidates:
        if candidate.exists() and candidate.is_dir():
            return candidate
    raise FileNotFoundError(
        "ChemFormer repository directory not found. Expected one of:\n%s"
        % "\n".join(str(path) for path in candidates)
    )


def _resolve_model_root(script_dir: Path, model_root_arg: Optional[str]) -> Path:
    if model_root_arg:
        root = Path(model_root_arg).expanduser().resolve()
    else:
        root = (script_dir / "models" / "models").resolve()
    if not root.exists():
        raise FileNotFoundError(
            "ChemFormer checkpoint root not found at %s. "
            "Place manually downloaded checkpoints under models/CHEMFORMER/models/models."
            % root
        )
    return root


def _resolve_model_dir(model_root: Path, variant: str) -> Path:
    subdir = VARIANT_TO_SUBDIR.get(variant)
    if subdir is None:
        raise ValueError("Unsupported ChemFormer variant: %s" % variant)
    model_dir = model_root.joinpath(*subdir)
    if not model_dir.exists():
        raise FileNotFoundError("ChemFormer variant directory not found: %s" % model_dir)
    return model_dir


def _find_checkpoint_file(model_dir: Path) -> Path:
    checkpoints = sorted(model_dir.glob("*.ckpt"))
    if not checkpoints:
        raise FileNotFoundError("No .ckpt file found in %s" % model_dir)
    if len(checkpoints) > 1:
        print("Warning: multiple checkpoints found in %s. Using %s" % (model_dir, checkpoints[0]))
    return checkpoints[0]


def _maybe_patch_checkpoint(ckpt_path: Path) -> Path:
    patched_path = ckpt_path.with_name("%s_v2%s" % (ckpt_path.stem, ckpt_path.suffix))
    if patched_path.exists():
        return patched_path

    ckpt = torch.load(str(ckpt_path), map_location="cpu")
    if (
        isinstance(ckpt, dict)
        and isinstance(ckpt.get("hyper_parameters"), dict)
        and "vocab_size" in ckpt["hyper_parameters"]
        and "vocabulary_size" not in ckpt["hyper_parameters"]
    ):
        ckpt["hyper_parameters"]["vocabulary_size"] = ckpt["hyper_parameters"].pop("vocab_size")
        torch.save(ckpt, str(patched_path))
        print("Patched checkpoint written to: %s" % patched_path)
        return patched_path
    return ckpt_path


def _variant_uses_downstream_vocab(variant: str) -> bool:
    return variant.startswith("finetuned/") or variant.startswith("randinit/")


def _resolve_vocab_path(repo_dir: Path, variant: str, vocab_path_arg: Optional[str]) -> Path:
    if vocab_path_arg:
        vocab_path = Path(vocab_path_arg).expanduser().resolve()
        if not vocab_path.exists():
            raise FileNotFoundError("Vocabulary file not found: %s" % vocab_path)
        return vocab_path

    default_name = "bart_vocab_downstream.json" if _variant_uses_downstream_vocab(variant) else "bart_vocab.json"
    vocab_path = (repo_dir / default_name).resolve()
    if not vocab_path.exists():
        raise FileNotFoundError("Vocabulary file not found: %s" % vocab_path)
    return vocab_path


def _load_vocab_token_lookup(vocab_path: Path) -> Dict[str, int]:
    data = json.loads(vocab_path.read_text(encoding="utf-8"))

    if isinstance(data, dict):
        if isinstance(data.get("vocabulary"), list):
            tokens = data["vocabulary"]
            return {str(token): idx for idx, token in enumerate(tokens)}

        if isinstance(data.get("vocab"), dict):
            return {str(k): int(v) for k, v in data["vocab"].items()}

        if data and all(isinstance(v, int) for v in data.values()):
            return {str(k): int(v) for k, v in data.items()}

    raise RuntimeError("Unsupported ChemFormer vocabulary format at %s" % vocab_path)


def _discover_task_token_families(token_lookup: Dict[str, int]) -> Dict[str, List[str]]:
    tokens = list(token_lookup.keys())

    rx_tokens = [
        token
        for token in tokens
        if re.fullmatch(r"<RX_\d+>", token)
    ]
    rx_tokens.sort(key=lambda token: int(token.strip("<>").split("_")[1]))

    property_tokens = [
        token
        for token in tokens
        if token.startswith("LogD_change_")
        or token.startswith("Solubility_")
        or token.startswith("Clint_")
    ]

    return {
        "rx": rx_tokens,
        "property": property_tokens,
    }


def _select_default_task_token(variant: str, families: Dict[str, List[str]]) -> Optional[str]:
    if variant.startswith("finetuned/uspto") or variant.startswith("randinit/uspto"):
        if "<RX_1>" in families["rx"]:
            return "<RX_1>"
        if families["rx"]:
            return families["rx"][0]
        return None

    # Pretrained checkpoints are generic and do not map to one canonical downstream token.
    return None


def _format_task_token_suggestions(families: Dict[str, List[str]], max_items: int = 20) -> str:
    merged: List[str] = []
    merged.extend(families["rx"])
    merged.extend(families["property"])
    merged = list(dict.fromkeys(merged))
    if not merged:
        return "(none discovered)"
    if len(merged) <= max_items:
        return ", ".join(merged)
    return ", ".join(merged[:max_items]) + ", ..."


def _resolve_task_pooling_config(
    *,
    pooling: str,
    task_token_arg: Optional[str],
    variant: str,
    token_lookup: Dict[str, int],
    families: Dict[str, List[str]],
) -> Tuple[str, Optional[str], Optional[int], List[str]]:
    notices: List[str] = []

    normalized_arg = ""
    if task_token_arg is not None:
        normalized_arg = str(task_token_arg).strip()

    explicit_requested = bool(normalized_arg) and normalized_arg.lower() not in {"auto", "none", "null"}

    if pooling == "mean":
        if explicit_requested:
            notices.append("Ignoring --task-token because pooling=mean.")
        return "mean", None, None, notices

    if pooling == "task_token":
        if explicit_requested:
            token = normalized_arg
        else:
            token = _select_default_task_token(variant, families)
            if not token:
                raise ValueError(
                    "No default task token available for variant %s. "
                    "Provide --task-token explicitly. Candidates: %s"
                    % (variant, _format_task_token_suggestions(families))
                )
            notices.append("No task token provided; selected variant default token %s." % token)

        if token not in token_lookup:
            raise ValueError(
                "Task token %r not found in tokenizer vocabulary for variant %s. Candidates: %s"
                % (token, variant, _format_task_token_suggestions(families))
            )
        return "task_token", token, int(token_lookup[token]), notices

    # pooling == auto
    if explicit_requested:
        token = normalized_arg
        if token not in token_lookup:
            raise ValueError(
                "Task token %r not found in tokenizer vocabulary for variant %s. Candidates: %s"
                % (token, variant, _format_task_token_suggestions(families))
            )
        return "task_token", token, int(token_lookup[token]), notices

    token = _select_default_task_token(variant, families)
    if token and token in token_lookup:
        notices.append("Auto mode selected task-token pooling with default token %s." % token)
        return "task_token", token, int(token_lookup[token]), notices

    notices.append("Auto mode selected mean pooling (no canonical task token for this variant).")
    return "mean", None, None, notices


def _build_tokenizer(vocab_path: Path):
    try:
        return ChemformerTokenizer(str(vocab_path))
    except TypeError:
        try:
            return ChemformerTokenizer(vocab_path=str(vocab_path))
        except TypeError as exc:
            raise RuntimeError("Could not initialize ChemformerTokenizer with expected signatures") from exc


def _get_pad_token_id(tokenizer) -> int:
    for attr in ["pad_token_idx", "pad_token_id"]:
        if hasattr(tokenizer, attr):
            value = getattr(tokenizer, attr)
            if value is not None:
                return int(value)

    for attr in ["token_to_id", "vocab", "_vocabulary"]:
        if hasattr(tokenizer, attr):
            mapping = getattr(tokenizer, attr)
            if isinstance(mapping, dict):
                for key in ["<PAD>", "[PAD]", "PAD", "<pad>"]:
                    if key in mapping:
                        return int(mapping[key])

    raise RuntimeError("Could not determine pad token id from tokenizer")


def _normalize_token_ids(ids: Any) -> List[int]:
    if isinstance(ids, torch.Tensor):
        return [int(item) for item in ids.reshape(-1).tolist()]

    if hasattr(ids, "tolist") and not isinstance(ids, (list, tuple)):
        ids = ids.tolist()

    if isinstance(ids, (list, tuple)):
        if len(ids) == 1 and isinstance(ids[0], (list, tuple, torch.Tensor)):
            return _normalize_token_ids(ids[0])
        if ids and all(isinstance(item, (int, np.integer)) for item in ids):
            return [int(item) for item in ids]

    return [int(item) for item in ids]


def _encode_single_smiles(tokenizer, text: str) -> List[int]:
    if hasattr(tokenizer, "encode"):
        return _normalize_token_ids(tokenizer.encode(text))

    if hasattr(tokenizer, "tokenize") and hasattr(tokenizer, "convert_tokens_to_ids"):
        tokens = tokenizer.tokenize(text)
        token_ids = tokenizer.convert_tokens_to_ids(tokens)
        return _normalize_token_ids(token_ids)

    raise RuntimeError("Tokenizer does not expose a recognized encode/tokenize API")


def _find_first_token_position(sequence: List[int], token_id: int) -> int:
    for idx, value in enumerate(sequence):
        if int(value) == int(token_id):
            return idx
    return -1


def _encode_smiles_batch(
    tokenizer,
    smiles_batch: List[str],
    task_token: Optional[str] = None,
    task_token_id: Optional[int] = None,
) -> Tuple[torch.Tensor, torch.Tensor, Optional[torch.Tensor], bool]:
    token_id_lists: List[List[int]] = []
    task_positions: List[int] = []
    fallback_used = False

    for smiles in smiles_batch:
        if task_token is None:
            ids = _encode_single_smiles(tokenizer, smiles)
            task_positions.append(-1)
        else:
            if task_token_id is None:
                raise RuntimeError("Internal error: task token id missing while task token is set")
            prefixed_text = "%s %s" % (task_token, smiles)
            ids = _encode_single_smiles(tokenizer, prefixed_text)
            pos = _find_first_token_position(ids, int(task_token_id))
            if pos < 0:
                # Some tokenizer variants rewrite token boundaries even if token exists in vocab.
                # Deterministic fallback: prepend the canonical task-token id directly.
                base_ids = _encode_single_smiles(tokenizer, smiles)
                ids = [int(task_token_id)] + base_ids
                pos = 0
                fallback_used = True
            task_positions.append(pos)

        token_id_lists.append(ids)

    pad_id = _get_pad_token_id(tokenizer)
    max_len = max(len(ids) for ids in token_id_lists)
    batch_size = len(token_id_lists)

    encoder_input = torch.full((max_len, batch_size), pad_id, dtype=torch.long)
    encoder_pad_mask = torch.ones((max_len, batch_size), dtype=torch.bool)

    for col, ids in enumerate(token_id_lists):
        seq_len = len(ids)
        encoder_input[:seq_len, col] = torch.tensor(ids, dtype=torch.long)
        encoder_pad_mask[:seq_len, col] = False

    if task_token is not None:
        task_positions_tensor: Optional[torch.Tensor] = torch.tensor(task_positions, dtype=torch.long)
    else:
        task_positions_tensor = None

    return encoder_input, encoder_pad_mask, task_positions_tensor, fallback_used


def _masked_mean_pool(memory: torch.Tensor, pad_mask: torch.Tensor) -> torch.Tensor:
    valid_mask = (~pad_mask).unsqueeze(-1).to(memory.dtype)
    masked_memory = memory * valid_mask
    summed = masked_memory.sum(dim=0)
    counts = valid_mask.sum(dim=0).clamp(min=1e-9)
    return summed / counts


def _gather_positions(memory: torch.Tensor, positions: torch.Tensor) -> torch.Tensor:
    """Gather per-sample token states from encoder memory.

    memory: [seq_len, batch, hidden]
    positions: [batch]
    returns: [batch, hidden]
    """
    if memory.ndim != 3:
        raise RuntimeError("Expected memory shape [seq_len, batch, hidden], got %s" % (tuple(memory.shape),))
    batch_first = memory.transpose(0, 1)
    batch_indices = torch.arange(batch_first.shape[0], device=batch_first.device)
    return batch_first[batch_indices, positions, :]


@torch.no_grad()
def _extract_embeddings(
    smiles_list: List[str],
    model: Any,
    tokenizer: Any,
    device: torch.device,
    batch_size: int,
    pooling_mode: str,
    task_token: Optional[str],
    task_token_id: Optional[int],
) -> np.ndarray:
    chunks: List[np.ndarray] = []

    warned_task_token_fallback = False

    for start in range(0, len(smiles_list), batch_size):
        batch_smiles = smiles_list[start : start + batch_size]

        encoder_input, encoder_pad_mask, task_positions, used_fallback = _encode_smiles_batch(
            tokenizer=tokenizer,
            smiles_batch=batch_smiles,
            task_token=task_token if pooling_mode == "task_token" else None,
            task_token_id=task_token_id if pooling_mode == "task_token" else None,
        )
        if used_fallback and not warned_task_token_fallback:
            print(
                "Note: Task token %r was not recoverable as a direct encoded id in prefixed text for this tokenizer. "
                "Using deterministic id-prepend fallback for task-token pooling." % task_token
            )
            warned_task_token_fallback = True
        encoder_input = encoder_input.to(device)
        encoder_pad_mask = encoder_pad_mask.to(device)
        if task_positions is not None:
            task_positions = task_positions.to(device)

        memory = model.encode({"encoder_input": encoder_input, "encoder_pad_mask": encoder_pad_mask})

        if pooling_mode == "mean":
            pooled = _masked_mean_pool(memory, encoder_pad_mask)
        elif pooling_mode == "task_token":
            if task_positions is None:
                raise RuntimeError("Internal error: task positions missing for task_token pooling")
            pooled = _gather_positions(memory, task_positions)
        else:
            raise ValueError("Unsupported pooling mode: %s" % pooling_mode)

        chunks.append(np.asarray(pooled.detach().cpu().tolist(), dtype=np.float32))

    if not chunks:
        return np.empty((0, 0), dtype=np.float32)
    return np.vstack(chunks)


def _l2_normalize(vectors: np.ndarray) -> np.ndarray:
    if vectors.size == 0:
        return vectors
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms[norms == 0.0] = 1.0
    return (vectors / norms).astype(np.float32, copy=False)


def main() -> None:
    args = parse_args()

    script_dir = Path(__file__).resolve().parent
    repo_dir = _resolve_repo_dir(script_dir)
    model_root = _resolve_model_root(script_dir, args.model_root)
    variant_dir = _resolve_model_dir(model_root, args.variant)
    ckpt_path = _maybe_patch_checkpoint(_find_checkpoint_file(variant_dir))
    vocab_path = _resolve_vocab_path(repo_dir, args.variant, args.vocab_path)

    token_lookup = _load_vocab_token_lookup(vocab_path)
    families = _discover_task_token_families(token_lookup)

    if args.list_task_tokens:
        print("variant=%s" % args.variant)
        print("vocabulary=%s" % vocab_path)
        print("rx_tokens=%s" % (", ".join(families["rx"]) if families["rx"] else "(none)"))
        print(
            "property_tokens=%s"
            % (", ".join(families["property"]) if families["property"] else "(none)")
        )
        default_token = _select_default_task_token(args.variant, families)
        print("auto_default_task_token=%s" % (default_token if default_token else "None"))
        return

    pooling_mode, resolved_task_token, resolved_task_token_id, notices = _resolve_task_pooling_config(
        pooling=args.pooling,
        task_token_arg=args.task_token,
        variant=args.variant,
        token_lookup=token_lookup,
        families=families,
    )
    for notice in notices:
        print("Note: %s" % notice)

    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    input_path = Path(args.file).expanduser().resolve()
    if not input_path.exists():
        raise FileNotFoundError("Input file not found: %s" % input_path)

    output_dir = Path(args.output_dir).expanduser().resolve()
    npy_path, map_path, failures_path = resolve_output_paths(output_dir, args.output_stem)

    records, failures = preprocess_lines(
        lines=load_input_lines(input_path),
        input_format=args.input_format,
        model_input_type=args.model_input_type,
    )
    if not records:
        raise ValueError("No valid molecules remained after preprocessing")

    tokenizer = _build_tokenizer(vocab_path)
    model = BARTModel.load_from_checkpoint(str(ckpt_path), decode_sampler=None, map_location=device)
    model.to(device)
    model.eval()

    smiles_list = [str(record["model_input"]) for record in records]
    embeddings = _extract_embeddings(
        smiles_list=smiles_list,
        model=model,
        tokenizer=tokenizer,
        device=device,
        batch_size=max(1, int(args.batch_size)),
        pooling_mode=pooling_mode,
        task_token=resolved_task_token,
        task_token_id=resolved_task_token_id,
    )

    if args.normalize:
        embeddings = _l2_normalize(embeddings)

    np.save(str(npy_path), embeddings)
    write_mapping_csv(map_path, records)

    if failures:
        write_failures_csv(failures_path, failures)
    elif failures_path.exists():
        failures_path.unlink()

    print("Saved embeddings to %s with shape %s." % (npy_path, embeddings.shape))
    print("variant=%s" % args.variant)
    print("checkpoint=%s" % ckpt_path)
    print("vocabulary=%s" % vocab_path)
    print("pooling=%s" % pooling_mode)
    print("task_token=%s" % (resolved_task_token if resolved_task_token is not None else "None"))


if __name__ == "__main__":
    main()

