"""Shared utility helpers for seeding, tensor conversion, and objective direction."""

from __future__ import annotations

import random
from typing import Tuple

import numpy as np
import torch


def set_global_seed(seed: int) -> None:
    """Set Python, NumPy, and Torch RNG seeds."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def resolve_torch_device_dtype(device_name: str, dtype_name: str) -> Tuple[torch.device, torch.dtype]:
    """Resolve and validate Torch device + dtype from strings."""
    if device_name == "cuda" and not torch.cuda.is_available():
        raise ValueError("device='cuda' requested but CUDA is not available")
    dtype_map = {"float32": torch.float32, "float64": torch.float64}
    if dtype_name not in dtype_map:
        raise ValueError("dtype_name must be 'float32' or 'float64'")
    return torch.device(device_name), dtype_map[dtype_name]


def to_torch(array: np.ndarray, *, dtype: torch.dtype, device: torch.device) -> torch.Tensor:
    """Convert a NumPy array to a Torch tensor on the requested device/dtype."""
    return torch.as_tensor(array, dtype=dtype, device=device)


def apply_objective_direction(y: np.ndarray, maximize: bool) -> np.ndarray:
    """Convert minimization to maximization internally by negating the target."""
    return y if maximize else -y


def best_value(values: np.ndarray, maximize: bool) -> float:
    """Return current best objective value under maximize/minimize semantics."""
    return float(np.max(values) if maximize else np.min(values))
