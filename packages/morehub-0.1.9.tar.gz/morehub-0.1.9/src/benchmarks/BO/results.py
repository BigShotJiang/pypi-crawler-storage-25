"""Result containers and artifact persistence helpers."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np

from config import BOConfig


@dataclass(slots=True)
class TrialHistory:
    """History for one trial: sampled points, values, and running best."""

    initial_indices: np.ndarray
    selected_indices: np.ndarray
    observed_targets: np.ndarray
    best_so_far: np.ndarray


@dataclass(slots=True)
class BOExperimentResult:
    """Aggregated output for a multi-trial BO run."""

    config: BOConfig
    trial_histories: list[TrialHistory]
    best_so_far_matrix: np.ndarray
    trial_seeds: list[int]
    metadata: dict[str, Any]


def _to_jsonable(obj: Any) -> Any:
    """Recursively convert objects to JSON-serializable values."""
    if isinstance(obj, (float, int, str, bool)) or obj is None:
        return obj
    if isinstance(obj, np.generic):
        return obj.item()
    if isinstance(obj, dict):
        return {str(k): _to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_jsonable(v) for v in obj]
    return str(obj)


def save_experiment_result(result: BOExperimentResult, output_dir: str | Path) -> Path:
    """Persist run artifacts and return the created run directory."""
    root = Path(output_dir)
    root.mkdir(parents=True, exist_ok=True)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = root / f"bo_run_{stamp}"
    suffix = 1
    while run_dir.exists():
        run_dir = root / f"bo_run_{stamp}_{suffix:02d}"
        suffix += 1
    run_dir.mkdir(parents=True, exist_ok=False)

    np.save(run_dir / "best_so_far.npy", result.best_so_far_matrix)

    np.savez(
        run_dir / "initial_indices.npz",
        **{f"trial_{i}": t.initial_indices for i, t in enumerate(result.trial_histories)},
    )
    np.savez(
        run_dir / "selected_indices.npz",
        **{f"trial_{i}": t.selected_indices for i, t in enumerate(result.trial_histories)},
    )
    np.savez(
        run_dir / "observed_targets.npz",
        **{f"trial_{i}": t.observed_targets for i, t in enumerate(result.trial_histories)},
    )

    (run_dir / "config.json").write_text(
        json.dumps(result.config.to_dict(), indent=2),
        encoding="utf-8",
    )
    metadata = {
        "trial_seeds": result.trial_seeds,
        **result.metadata,
    }
    (run_dir / "metadata.json").write_text(
        json.dumps(_to_jsonable(metadata), indent=2),
        encoding="utf-8",
    )
    return run_dir


def load_run_artifacts(run_dir: str | Path) -> dict[str, Any]:
    """Load core artifacts (`best_so_far`, config, metadata) for plotting/analysis."""
    run_path = Path(run_dir)
    best_so_far = np.load(run_path / "best_so_far.npy")
    config = json.loads((run_path / "config.json").read_text(encoding="utf-8"))
    metadata = json.loads((run_path / "metadata.json").read_text(encoding="utf-8"))
    return {
        "best_so_far": best_so_far,
        "config": config,
        "metadata": metadata,
    }
